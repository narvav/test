# AGENTS.md — IDGraph Events Helper

> AI coding assistant context for `apm0045194-idgraph-idgrapheventshelper`.

---

## Build Commands

```bash
# Compile
mvn clean compile

# Full build (compile + test + package)
mvn clean install

# Run all tests (Spock + JUnit)
mvn test

# Run a single Spock test
mvn test -Dtest="EventPublisherImplTest"
mvn test -Dtest="ResilientEventPublisherTest"
mvn test -Dtest="ResilientEventConsumerTest"
mvn test -Dtest="StreamOperationsHelperTest"

# Deploy artifact to Maven repository
mvn clean deploy

# Generate JaCoCo coverage report
mvn verify
# Report at: target/site/jacoco/index.html
```

---

## Key File Paths

| Category | Path |
|----------|------|
| **Source Root** | `src/main/java/com/att/idp/idgraph/events/` |
| **Test Root** | `src/test/groovy/com/att/idp/idgraph/events/` |
| **Resources** | `src/main/resources/eventshelper.properties` |
| **Build File** | `pom.xml` |
| **CI Pipeline** | `Jenkinsfile` |
| **Documentation** | `docs/` |
| **Architecture Diagrams** | `docs/diagrams.md` |
| **Event Hub Sequence Flows** | `docs/eventhubs-sequence-diagrams.md` |
| **Resiliency Framework Design** | `docs/kafka-resiliency-framework.md` |
| **Code Owners** | `CODEOWNERS` |

### Key Source Files

| File | Purpose |
|------|---------|
| `service/EventPublisher.java` | Publisher interface (sync, async, callback) |
| `service/impl/EventPublisherImpl.java` | Publisher implementation with primary/secondary binder failover |
| `service/ResilientEventPublisher.java` | Publisher wrapper with Cosmos DB fallback on Kafka failure |
| `service/ResilientEventConsumer.java` | Consumer-side dedup + sequence checking for batch-retried messages |
| `helper/StreamOperationsHelper.java` | Spring Cloud Stream `StreamOperations` wrapper with `@Retryable` |
| `config/EventsConfiguration.java` | `@Configuration` — component scan, retry enablement, property source |
| `annotation/EnableEventPublisher.java` | `@EnableEventPublisher` — zero-config library activation annotation |
| `model/IDGraphEvent.java` | Canonical event model |
| `model/ConsumerAction.java` | Enum: `PROCESS`, `SKIP_DUPLICATE`, `SKIP_STALE` |
| `exception/EventPublisherException.java` | Primary publishing failure exception |

---

## Coding Conventions

### Language & Framework

- **Java 17** with **Maven** build
- **Spring Boot 3.x** / **Spring Cloud Stream** (Kafka binder)
- **Spring Retry** for transient failure handling
- **Lombok**: `@Slf4j`, `@Data`, `@Builder`, `@AllArgsConstructor`
- **Parent POM**: `sdk-java-library-parent:3.0.1`

### Naming Conventions

| Element | Convention |
|---------|-----------|
| **Packages** | `com.att.idp.idgraph.events.{layer}` — `service`, `service.impl`, `helper`, `model`, `config`, `annotation`, `exception` |
| **Interfaces** | `EventPublisher` (no `I` prefix) |
| **Implementations** | `EventPublisherImpl` (suffix `Impl`) |
| **Exceptions** | `{Description}Exception` |
| **Enums** | PascalCase names, UPPER_SNAKE values |
| **Test Files** | `{ClassName}Test.groovy` (Spock) |

### Hard-Stops (IDGraph Platform)

- **No wildcard imports** — all imports must be explicit
- **No empty catch blocks** — every `catch` must log and handle
- **No `System.out.println`** — use `@Slf4j` structured logging
- **No hardcoded secrets** — use `${SASL_JAAS_CONFIG}` / Key Vault references
- **No raw exceptions to consumers** — use domain-specific exceptions
- **Sanitize logs via ESAPI** — use `StringEscapeUtils.escapeJava()` for external values in error logs
- **Preserve Kafka auth patterns** — do not change PLAIN/OAUTHBEARER config per environment

### Log Code Convention

- Publisher log codes: `REP_01` through `REP_08`
- Consumer log codes: `REC_01` through `REC_08`
- Format: `log.{level}("{CODE}: {message}", args...)`

---

## Domain-Specific Patterns

### Primary/Secondary Binder Failover

- `EventPublisherImpl` constructs binder names as `{bindingName}-primary` and `{bindingName}-secondary`
- Primary is attempted first; on failure, secondary is attempted
- Both use `StreamOperationsHelper` which has `@Retryable` (3 attempts, exponential backoff)

### Cosmos DB Fallback (Resilient Publishing)

- `ResilientEventPublisher.sendWithFallback()` catches `EventPublisherException` after all retries exhausted
- Feature flag `kafka.resiliency.use-unified-entity`:
  - `false` (default): saves as `IdgraphFailedEvents` (legacy entity)
  - `true`: saves as `KafkaEventRecord` with sequence number and idempotency key

### Consumer Deduplication (Resilient Consuming)

- `ResilientEventConsumer` is conditionally enabled via `kafka.resiliency.use-unified-entity=true`
- Happy-path messages (no `x-idg-sequence` header) → always `PROCESS`
- Batch-retried messages (with `x-idg-sequence` header) → dedup check + sequence comparison
- Custom headers: `x-idg-sequence`, `x-idg-idempotency-key`, `x-idg-is-retry`, `x-idg-origin-region`, `x-idg-entity-key`

### Sequence Number Format

- `{epochMillis}.{region}.{counter}` — e.g., `1714567890123.east.00001`
- Counter is per-entity, thread-safe (`AtomicInteger`)

### Idempotency Key Generation

- `SHA-256(bindingName + "|" + entityKey + "|" + sequenceNumber)` — deterministic, hex-encoded

---

## Integration Points

### Kafka (Outbound)

| Binder Type | Auth Mechanism | Config Pattern |
|-------------|---------------|----------------|
| Azure Event Hubs | SASL_SSL / PLAIN | `spring.cloud.stream.binders.{name}-primary.type=kafka` |
| Confluent (ISBUS) | SASL_SSL / OAUTHBEARER | `spring.cloud.stream.binders.{name}-primary.type=kafka` |

### Cosmos DB (Outbound — via idgraphdbhelper)

| Helper | Entity | Purpose |
|--------|--------|---------|
| `CosmosFailedEventsDBHelper` | `IdgraphFailedEvents` | Legacy failed event persistence |
| `KafkaEventRecordDBHelper` | `KafkaEventRecord` | Unified entity with sequence/idempotency |

### Library Dependency

| Library | Version | Purpose |
|---------|---------|---------|
| `idgraphdbhelper` | `3.5.0` | Cosmos DB data access layer |

---

## Testing

### Framework

- **Spock 2.3** (Groovy 3.0) for all unit tests
- **Spring Boot Test** for integration context

### Test Files

| Test | Covers |
|------|--------|
| `EventPublisherImplTest.groovy` | `EventPublisherImpl` — primary/secondary failover, validation |
| `ResilientEventPublisherTest.groovy` | `ResilientEventPublisher` — Kafka send, Cosmos fallback, sequence/idempotency |
| `ResilientEventConsumerTest.groovy` | `ResilientEventConsumer` — dedup, sequence, happy path, skip audit |
| `StreamOperationsHelperTest.groovy` | `StreamOperationsHelper` — retry, message construction, error handling |

### Test Data Locations

- Test data is inline within Spock specs (no external fixtures)

### Coverage

- **Tool**: JaCoCo (via `jacoco-maven-plugin`)
- **Report**: `target/site/jacoco/index.html`
- **Exclusions**: `model/**`, `exception/**`, `annotation/**`, `config/**`, `*Application.*`, `entity/**`, `repository/**`, `cache/**`, `util/**`
- **Quality Gate**: SonarQube (via Jenkins pipeline)

### Running Tests

```bash
# All tests
mvn test

# Single test class
mvn test -Dtest="ResilientEventPublisherTest"

# With coverage report
mvn verify
```
