---
title: IDGraph Events Helper
version: 4.2.0
last_updated: 2026-05-01
author: IDGraph Platform Team
---

# IDGraph Events Helper — Shared Kafka Event Publishing & Resiliency Library

| Field | Value |
|---|---|
| **Domain / Team** | `IDGraph Platform` |
| **Artifact ID** | `idgrapheventshelper` |
| **Version** | `4.2.0` |
| **Component Type** | `Shared Library` |
| **Runtime / Parent** | `sdk-java-library-parent 3.0.1` |
| **Language / Java Version** | `Java 17` |
| **Base Path / Entry Point** | `com.att.idp.idgraph.events` (package root) |
| **API / Contract Docs** | `N/A — consumed as Maven dependency` |

## Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Project Structure](#project-structure)
4. [Domain Capability Map](#domain-capability-map)
5. [Integration Context](#integration-context)
6. [Process Flows](#process-flows)
7. [Interfaces & Endpoints](#interfaces--endpoints)
8. [Data Stores & State Management](#data-stores--state-management)
9. [Configuration](#configuration)
10. [Dependencies](#dependencies)
11. [Observability and Operations](#observability-and-operations)
12. [Security and Compliance](#security-and-compliance)
13. [Build and Test](#build-and-test)
14. [Deployment](#deployment)
15. [Change Log / History](#change-log--history)

## Overview

**IDGraph Events Helper** is an IDGraph platform shared library responsible for **abstracting Kafka event publishing and consuming with built-in resiliency patterns**.
It acts as the canonical eventing toolkit for IDGraph microservices, handling:

- **Event Publishing**: Synchronous and asynchronous Kafka message publishing via Spring Cloud Stream bindings with primary/secondary binder failover
- **Resilient Publishing**: Automatic Cosmos DB fallback when Kafka publish fails — failed events are persisted for later batch retry
- **Resilient Consuming**: Consumer-side deduplication and sequence checking for batch-retried messages, with skip audit to Cosmos DB
- **Stream Operations**: Low-level Spring Cloud Stream `StreamOperations` wrapper with configurable Spring Retry (exponential backoff, jitter)
- **Event Modeling**: Canonical event model (`IDGraphEvent`, `EventCategory`, `EventType`, `EventSubCategory`) with Jackson serialization
- **Auto-Configuration**: `@EnableEventPublisher` annotation for zero-config library activation in consuming microservices
- **Unified Entity Support**: Feature-flagged migration from legacy `IdgraphFailedEvents` to new `KafkaEventRecord` entity with sequence/idempotency support

This library uses `Spring Cloud Stream`, `Spring Retry`, and `Cosmos DB` (via `idgraphdbhelper`) to provide reliable event-driven communication across the IDGraph platform.

## Architecture

```mermaid
graph TD
    subgraph ConsumingMicroservices["Consuming Microservices"]
        MS1["idgraphsubsvcms"]
        MS2["idgraphaccteventsms"]
        MS3["idgraphusereventsms"]
        MS4["idgraphbatchms"]
    end

    subgraph IDGraphEventsHelper["idgrapheventshelper"]
        subgraph PublishLayer["Publishing Layer"]
            EP["EventPublisher (Interface)"]
            EPI["EventPublisherImpl"]
            REP["ResilientEventPublisher"]
        end
        subgraph ConsumerLayer["Consumer Layer"]
            REC["ResilientEventConsumer"]
            CA["ConsumerAction (PROCESS / SKIP_DUPLICATE / SKIP_STALE)"]
        end
        subgraph CoreLayer["Core / Helpers"]
            SOH["StreamOperationsHelper"]
            EC["EventsConfiguration"]
            ANN["@EnableEventPublisher"]
        end
        subgraph ModelLayer["Event Models"]
            IDG["IDGraphEvent"]
            ENUMS["EventCategory / EventType / EventSubCategory"]
        end
    end

    subgraph ExternalDependencies["External Dependencies"]
        KAFKA["Kafka / Azure Event Hubs / ISBUS"]
        COSMOS["Cosmos DB (Failed Events)"]
        DBH["idgraphdbhelper"]
    end

    MS1 & MS2 & MS3 & MS4 --> EP
    MS1 & MS2 & MS3 & MS4 --> REP
    MS1 & MS2 & MS3 & MS4 --> REC
    EP --> EPI
    EPI --> SOH
    REP --> EP
    REP --> DBH
    REC --> DBH
    SOH -->|"StreamOperations.send()"| KAFKA
    DBH --> COSMOS
    ANN -->|"@Import"| EC
```

### Key Architectural Patterns

- **Primary/Secondary Binder Failover**: `EventPublisherImpl` attempts the primary Kafka binder first; on failure, falls back to a secondary binder
- **Cosmos DB Fallback**: `ResilientEventPublisher` catches exhausted retries and persists failed events to Cosmos DB for batch retry
- **Consumer Deduplication**: `ResilientEventConsumer` uses in-memory `ConcurrentHashMap` for dedup and sequence tracking of batch-retried messages
- **Spring Retry with Backoff**: `StreamOperationsHelper` uses `@Retryable` with exponential backoff and jitter for transient Kafka failures
- **Feature-Flagged Migration**: `kafka.resiliency.use-unified-entity` toggles between legacy `IdgraphFailedEvents` and new `KafkaEventRecord` entity

## Project Structure

```bash
apm0045194-idgraph-idgrapheventshelper/
├── pom.xml                                          # Maven build (sdk-java-library-parent 3.0.1)
├── Jenkinsfile                                      # CI pipeline (pl_idp_library)
├── CODEOWNERS                                       # Code ownership
├── README.md                                        # This file
├── AGENTS.md                                        # AI coding assistant context
├── docs/
│   ├── diagrams.md                                  # Architecture diagrams
│   ├── eventhubs-sequence-diagrams.md               # Event Hub sequence flows
│   └── kafka-resiliency-framework.md                # Resiliency framework design doc
├── src/
│   ├── main/
│   │   ├── java/com/att/idp/idgraph/events/
│   │   │   ├── EventsHelperSampleApplication.java   # Sample/test application
│   │   │   ├── annotation/
│   │   │   │   └── EnableEventPublisher.java         # @EnableEventPublisher annotation
│   │   │   ├── config/
│   │   │   │   └── EventsConfiguration.java          # Component scan + retry + properties
│   │   │   ├── exception/
│   │   │   │   ├── EventPublisherException.java      # Publishing failure exception
│   │   │   │   ├── InvalidInputException.java        # Input validation exception
│   │   │   │   └── MissingConfigurationException.java # Missing config exception
│   │   │   ├── helper/
│   │   │   │   └── StreamOperationsHelper.java       # StreamOperations wrapper with retry
│   │   │   ├── model/
│   │   │   │   ├── Attribute.java                    # Generic attribute model
│   │   │   │   ├── ConsumerAction.java               # Consumer evaluation result enum
│   │   │   │   ├── EventCategory.java                # Event category enum
│   │   │   │   ├── EventDetails.java                 # Event details model
│   │   │   │   ├── EventSubCategory.java             # Event subcategory enum
│   │   │   │   ├── EventType.java                    # Event type enum
│   │   │   │   ├── IDGraphEvent.java                 # Canonical event model
│   │   │   │   └── JsonSealizable.java               # Serialization marker interface
│   │   │   └── service/
│   │   │       ├── EventPublisher.java               # Publisher interface
│   │   │       ├── ResilientEventConsumer.java       # Consumer dedup + sequencing
│   │   │       ├── ResilientEventPublisher.java      # Publisher with Cosmos fallback
│   │   │       └── impl/
│   │   │           └── EventPublisherImpl.java       # Publisher implementation
│   │   └── resources/
│   │       └── eventshelper.properties               # Default library configuration
│   └── test/
│       └── groovy/com/att/idp/idgraph/events/
│           ├── helper/
│           │   └── StreamOperationsHelperTest.groovy
│           └── service/
│               ├── ResilientEventConsumerTest.groovy
│               ├── ResilientEventPublisherTest.groovy
│               └── impl/
│                   └── EventPublisherImplTest.groovy
└── .github/
    └── copilot-instructions.md                       # AI coding assistant context
```

## Domain Capability Map

| Capability | Description | Primary Interfaces / Entry Points |
|------------|-------------|-----------------------------------|
| **Event Publishing** | Synchronous Kafka message publishing with primary/secondary binder failover | `EventPublisher.send()`, `EventPublisherImpl` |
| **Async Event Publishing** | Asynchronous Kafka publishing with `CompletableFuture` and callback support | `EventPublisher.sendAsync()`, `EventPublisher.sendAsyncWithCallback()` |
| **Resilient Publishing** | Kafka publish with automatic Cosmos DB fallback on failure | `ResilientEventPublisher.sendWithFallback()` |
| **Async Resilient Publishing** | Async resilient publish with callbacks | `ResilientEventPublisher.sendWithFallbackAsync()`, `sendWithFallbackAsyncCallback()` |
| **Consumer Deduplication** | Consumer-side dedup and sequence checking for batch-retried messages | `ResilientEventConsumer.evaluate()` |
| **Stream Operations** | Low-level Spring Cloud Stream send with Spring Retry | `StreamOperationsHelper.sendToStreamOperations()` |
| **Header-Enriched Publishing** | Publishing with custom resiliency headers (batch retry) | `StreamOperationsHelper.sendToStreamOperationsWithHeaders()` |
| **Event Modeling** | Canonical IDGraph event model with category/type/subcategory enums | `IDGraphEvent`, `EventCategory`, `EventType`, `EventSubCategory` |
| **Auto-Configuration** | Zero-config library enablement via annotation | `@EnableEventPublisher` |

## Integration Context

| Interface / Dependency | Direction | Type | Purpose | Notes |
|------------------------|-----------|------|---------|-------|
| **Consuming Microservices** | Inbound | Library | IDGraph services include this as a Maven dependency | `@EnableEventPublisher` on application class |
| **Kafka / Azure Event Hubs** | Outbound | Kafka | Primary event publishing target | Spring Cloud Stream binder (SASL_SSL / PLAIN) |
| **Kafka / Confluent (ISBUS)** | Outbound | Kafka | Secondary event publishing target | Spring Cloud Stream binder (SASL_SSL / OAUTHBEARER) |
| **Cosmos DB** | Outbound | DB | Failed event persistence for batch retry | Via `idgraphdbhelper` (`CosmosFailedEventsDBHelper`, `KafkaEventRecordDBHelper`) |
| **idgraphdbhelper** | Outbound | Library | Cosmos DB data access layer | `IdgraphFailedEvents`, `KafkaEventRecord` entities |

## Process Flows

### 1. Resilient Event Publishing (Happy Path)

```mermaid
sequenceDiagram
    participant MS as Consuming Microservice
    participant REP as ResilientEventPublisher
    participant EP as EventPublisherImpl
    participant SOH as StreamOperationsHelper
    participant K as Kafka

    MS->>REP: sendWithFallback(bindingName, publisherName, key, payload)
    REP->>EP: send(bindingName, key, payload)
    EP->>SOH: sendToStreamOperations(primaryBinder, bindingName, key, payload)
    SOH->>K: StreamOperations.send()
    K-->>SOH: success
    SOH-->>EP: true
    EP-->>REP: true
    REP-->>MS: true (published to Kafka)
```

| Input | Output |
|-------|--------|
| `bindingName` (String), `publisherName` (String), `key` (String), `payload` (Object) | `true` — message published to Kafka successfully |

> **Code Reference**: `ResilientEventPublisher.sendWithFallback()` → `EventPublisherImpl.send()` → `StreamOperationsHelper.sendToStreamOperations()`

### 2. Resilient Event Publishing (Failure + Cosmos Fallback)

```mermaid
sequenceDiagram
    participant MS as Consuming Microservice
    participant REP as ResilientEventPublisher
    participant EP as EventPublisherImpl
    participant SOH as StreamOperationsHelper
    participant K as Kafka
    participant COSMOS as Cosmos DB

    MS->>REP: sendWithFallback(bindingName, publisherName, key, payload)
    REP->>EP: send(bindingName, key, payload)
    EP->>SOH: sendToStreamOperations(primaryBinder, ...)
    SOH->>K: StreamOperations.send() [retries exhausted]
    K-->>SOH: failure
    SOH-->>EP: EventPublisherException
    EP->>SOH: sendToStreamOperations(secondaryBinder, ...)
    SOH->>K: StreamOperations.send() [retries exhausted]
    K-->>SOH: failure
    SOH-->>EP: EventPublisherException
    EP-->>REP: EventPublisherException
    REP->>COSMOS: saveToCosmosDb / saveToCosmosDbUnified
    COSMOS-->>REP: saved
    REP-->>MS: false (saved to Cosmos fallback)
```

| Input | Output |
|-------|--------|
| `bindingName` (String), `publisherName` (String), `key` (String), `payload` (Object) | `false` — message saved to Cosmos DB for batch retry |

> **Code Reference**: `ResilientEventPublisher.sendWithFallback()` → `EventPublisherImpl.send()` → `ResilientEventPublisher.saveToCosmosDb()` / `saveToCosmosDbUnified()`

### 3. Consumer Message Evaluation (Dedup + Sequencing)

```mermaid
sequenceDiagram
    participant LISTENER as @KafkaListener
    participant REC as ResilientEventConsumer
    participant COSMOS as Cosmos DB (Audit)

    LISTENER->>REC: evaluate(headers, entityKey)
    alt No x-idg-sequence header (happy path)
        REC-->>LISTENER: PROCESS
    else Retried message — duplicate detected
        REC->>COSMOS: writeSkipAudit(DUPLICATE_SKIPPED)
        REC-->>LISTENER: SKIP_DUPLICATE
    else Retried message — stale sequence
        REC->>COSMOS: writeSkipAudit(STALE_SKIPPED)
        REC-->>LISTENER: SKIP_STALE
    else Retried message — in order
        REC-->>LISTENER: PROCESS
    end
```

| Input | Output |
|-------|--------|
| `headers` (MessageHeaders), `entityKey` (String) | `ConsumerAction` — `PROCESS`, `SKIP_DUPLICATE`, or `SKIP_STALE` |

> **Code Reference**: `ResilientEventConsumer.evaluate()` → dedup store check → sequence comparison → `writeSkipAudit()`

### 4. Primary/Secondary Binder Failover

```mermaid
sequenceDiagram
    participant EPI as EventPublisherImpl
    participant SOH as StreamOperationsHelper
    participant PK as Primary Kafka Binder
    participant SK as Secondary Kafka Binder

    EPI->>SOH: sendToStreamOperations(primaryBinder, ...)
    SOH->>PK: StreamOperations.send() [with retry]
    PK-->>SOH: failure (all retries exhausted)
    SOH-->>EPI: Exception
    EPI->>SOH: sendToStreamOperations(secondaryBinder, ...)
    SOH->>SK: StreamOperations.send() [with retry]
    SK-->>SOH: success
    SOH-->>EPI: true
```

| Input | Output |
|-------|--------|
| `bindingName` (String), `key` (String), `payload` (Object) | `true` — sent via secondary binder, or `EventPublisherException` if both fail |

> **Code Reference**: `EventPublisherImpl.send()` → `StreamOperationsHelper.sendToStreamOperations()`

## Interfaces & Endpoints

### Public Library API

| # | Interface | Method / Trigger | Signature | Description | Code Reference |
|---|-----------|------------------|-----------|-------------|----------------|
| 1 | Library | `send` | `boolean send(String bindingName, String key, Object payload)` | Synchronous Kafka publish with primary/secondary failover | `EventPublisher.send()` |
| 2 | Library | `sendAsync` | `CompletableFuture<Boolean> sendAsync(...)` | Asynchronous Kafka publish | `EventPublisher.sendAsync()` |
| 3 | Library | `sendAsyncWithCallback` | `void sendAsyncWithCallback(..., Consumer<Boolean>, Consumer<Throwable>)` | Async publish with success/failure callbacks | `EventPublisher.sendAsyncWithCallback()` |
| 4 | Library | `sendWithFallback` | `boolean sendWithFallback(String bindingName, String publisherName, String key, Object payload)` | Resilient publish with Cosmos DB fallback | `ResilientEventPublisher.sendWithFallback()` |
| 5 | Library | `sendWithFallbackAsync` | `CompletableFuture<Boolean> sendWithFallbackAsync(...)` | Async resilient publish | `ResilientEventPublisher.sendWithFallbackAsync()` |
| 6 | Library | `sendWithFallbackAsyncCallback` | `void sendWithFallbackAsyncCallback(..., Consumer<Boolean>, Consumer<Throwable>)` | Async resilient publish with callbacks | `ResilientEventPublisher.sendWithFallbackAsyncCallback()` |
| 7 | Library | `evaluate` | `ConsumerAction evaluate(MessageHeaders headers, String entityKey)` | Consumer-side dedup + sequencing evaluation | `ResilientEventConsumer.evaluate()` |

### Downstream Service Integrations

| # | Dependency | Protocol | Purpose | Code Reference |
|---|------------|----------|---------|----------------|
| 1 | Kafka / Azure Event Hubs | Kafka (SASL_SSL/PLAIN) | Primary event publishing | `StreamOperationsHelper.sendToStreamOperations()` |
| 2 | Kafka / Confluent (ISBUS) | Kafka (SASL_SSL/OAUTHBEARER) | Secondary event publishing | `StreamOperationsHelper.sendToStreamOperations()` |
| 3 | Cosmos DB (Failed Events) | Cosmos SDK | Failed event persistence | `CosmosFailedEventsDBHelper.addFailedEvents()` |
| 4 | Cosmos DB (Kafka Event Records) | Cosmos SDK | Unified event record persistence | `KafkaEventRecordDBHelper.saveEventRecord()` |

## Data Stores & State Management

| Store / State | Type | Purpose | Access Pattern | Notes |
|---------------|------|---------|----------------|-------|
| **Cosmos DB (Failed Events)** | DB | Persists failed Kafka publish events for batch retry | `CosmosFailedEventsDBHelper` (via `idgraphdbhelper`) | Legacy entity: `IdgraphFailedEvents` |
| **Cosmos DB (Kafka Event Records)** | DB | Unified entity with sequence/idempotency support | `KafkaEventRecordDBHelper` (via `idgraphdbhelper`) | Feature-flagged: `kafka.resiliency.use-unified-entity=true` |
| **In-Memory Dedup Store** | Cache | Tracks processed idempotency keys for consumer dedup | `ConcurrentHashMap` in `ResilientEventConsumer` | Per-instance; resets on restart |
| **In-Memory Sequence Tracker** | Cache | Tracks last processed sequence per entity key | `ConcurrentHashMap` in `ResilientEventConsumer` | Per-instance; resets on restart |
| **In-Memory Entity Counters** | Cache | Thread-safe counters for sequence number generation | `ConcurrentHashMap<String, AtomicInteger>` in `ResilientEventPublisher` | Per-instance; resets on restart |

## Configuration

| Setting Group | File / Source | Purpose |
|---------------|---------------|---------|
| **Library Defaults** | `eventshelper.properties` | Default Kafka binder config, retry settings, serializer config |
| **Application Overrides** | Consumer's `application.properties` | Binding destinations, binder brokers, SASL config |
| **Feature Flags** | `kafka.resiliency.use-unified-entity` | Toggles between legacy and unified Cosmos entity |
| **Secrets** | `${SASL_JAAS_CONFIG}`, `${ISBUS_SASL_JAAS_CONFIG}` | Kafka SASL credentials (environment variables / Key Vault) |

### Key Configuration Properties

| Property | Default | Description |
|----------|---------|-------------|
| `idp.idgraph.event.publisher.retry.maxAttempts` | `3` | Max retry attempts per binder |
| `idp.idgraph.event.publisher.retry.backoff.delay.ms` | `100` | Initial retry delay (ms) |
| `idp.idgraph.event.publisher.retry.backoff.multiplier` | `1.5` | Exponential backoff multiplier |
| `idp.idgraph.event.publisher.retry.backoff.maxDelay.ms` | `5000` | Max retry delay (ms) |
| `kafka.resiliency.use-unified-entity` | `false` | Use `KafkaEventRecord` instead of `IdgraphFailedEvents` |
| `kafka.event.record.ttl.seconds` | `604800` | TTL for Cosmos event records (7 days) |
| `kafka.resiliency.payload.account-fields` | `accountNumber,billingAccountNumber` | JSON fields to extract account number from payload |
| `idp.idgraph.env.prefix` | `` | Environment prefix for Cosmos records |
| `spring.application.name` | `unknown` | Source API identifier in Cosmos records |
| `environment.region` | `east` | Region identifier for sequence numbers and audit |

## Dependencies

### Runtime / Parent

| Dependency | Version | Purpose |
|------------|---------|---------|
| `sdk-java-library-parent` | `3.0.1` | Parent POM for IDGraph shared libraries |

### Key Dependencies

| Dependency | Version | Purpose |
|------------|---------|---------|
| `spring-cloud-stream-binder-kafka` | (managed) | Spring Cloud Stream Kafka binder |
| `spring-cloud-dependencies` | `2023.0.1` | Spring Cloud BOM |
| `spring-retry` | (managed) | Retry with exponential backoff |
| `spring-aspects` | (managed) | AOP support for `@Retryable` |
| `idgraphdbhelper` | `3.5.0` | Cosmos DB data access (failed events, event records) |
| `lombok` | `1.18.28` | Boilerplate reduction |
| `jackson-datatype-jsr310` | `2.15.2` | Java 8+ date/time serialization |

### Test Dependencies

| Dependency | Version | Purpose |
|------------|---------|---------|
| `spock-core` | `2.3-groovy-3.0` | Spock test framework |
| `spock-spring` | `2.3-groovy-3.0` | Spock Spring integration |
| `groovy` | `3.0.21` | Groovy runtime for Spock |
| `spring-boot-starter-test` | (managed) | Spring Boot test support |

## Observability and Operations

| Area | Mechanism | Notes |
|------|-----------|-------|
| **Logging** | SLF4J + Logback (via `@Slf4j`) | Structured log codes: `REP_01`–`REP_08` (publisher), `REC_01`–`REC_08` (consumer) |
| **Tracing / Correlation** | `idp-trace-id` via MDC | Propagated to Cosmos fallback records |
| **Client ID** | `x-att-clientid` via MDC | Stored as `updatedBy` in legacy failed events |
| **Operational Tasks** | Batch retry via `idgraphbatchms` | Reads failed events from Cosmos DB and republishes with resiliency headers |
| **Metrics** | N/A (library) | Consuming services are responsible for metrics collection |

### Log Code Reference

| Code | Level | Component | Description |
|------|-------|-----------|-------------|
| `REP_01` | INFO | ResilientEventPublisher | Message published successfully |
| `REP_02` | ERROR | ResilientEventPublisher | All Kafka publish attempts exhausted |
| `REP_03` | INFO | ResilientEventPublisher | Failed message saved to Cosmos (legacy) |
| `REP_04` | ERROR | ResilientEventPublisher | CRITICAL — Cosmos DB save also failed (legacy) |
| `REP_05` | INFO | ResilientEventPublisher | Failed message saved as KafkaEventRecord (unified) |
| `REP_06` | ERROR | ResilientEventPublisher | CRITICAL — KafkaEventRecord save also failed |
| `REP_07` | WARN | ResilientEventPublisher | Failed to parse payload for account extraction |
| `REP_08` | DEBUG | ResilientEventPublisher | Using Kafka key as account number fallback |
| `REC_01` | DEBUG | ResilientEventConsumer | Happy-path message (no sequence header) |
| `REC_02` | INFO | ResilientEventConsumer | Retried message detected |
| `REC_03` | INFO | ResilientEventConsumer | Duplicate detected |
| `REC_04` | INFO | ResilientEventConsumer | Stale message detected |
| `REC_05` | INFO | ResilientEventConsumer | Retried message in order |
| `REC_06` | DEBUG | ResilientEventConsumer | KafkaEventRecordDBHelper not available |
| `REC_07` | INFO | ResilientEventConsumer | Skip audit written |
| `REC_08` | WARN | ResilientEventConsumer | Failed to write skip audit (non-fatal) |

## Security and Compliance

| Area | Approach | Notes |
|------|----------|-------|
| **Authentication / Authorization** | Kafka SASL_SSL (PLAIN for AEH, OAUTHBEARER for ISBUS) | Credentials via environment variables / Key Vault |
| **Sensitive Data Handling** | ESAPI log sanitization (`StringEscapeUtils.escapeJava`) | Applied to binding names, keys, error messages, payloads in error logs |
| **Secrets Management** | `${SASL_JAAS_CONFIG}`, `${ISBUS_SASL_JAAS_CONFIG}` | Must be injected via Key Vault or environment variables |
| **Compliance Considerations** | Account numbers in Cosmos fallback records | Consuming services must ensure PII handling compliance |

## Build and Test

### Build

```bash
mvn clean install
```

### Run Tests

```bash
mvn test
```

### Run Single Test

```bash
mvn test -Dtest="EventPublisherImplTest"
mvn test -Dtest="ResilientEventPublisherTest"
```

### Profiles

| Profile | Description |
|---------|-------------|
| (default) | Standard build with Spock tests and JaCoCo coverage |

### Code Coverage

- **Coverage Report**: `target/site/jacoco/index.html`
- **Quality Dashboard**: SonarQube (via Jenkins pipeline)
- **Exclusions**: model, exception, annotation, config packages; `*Application` classes

## Deployment

### Build Artifact

```bash
mvn clean deploy
```

### Pipeline

- **Jenkins**: `Jenkinsfile` — uses `pl_idp_library` from `idp-shared-library@release/3.0.0`
- **MOTS ID**: `33944`
- **Repo Project**: `ST_IDGRAPH`

### Runtime Notes

| Area | Value |
|------|-------|
| **Deployment Target** | Maven artifact (library release) — not independently deployed |
| **Environment Notes** | Consumed as a Maven dependency by IDGraph microservices; not a standalone deployable |

## Change Log / History

| Ticket | Description |
|--------|-------------|
| **2026-05-01** | README refreshed following OMNI template standard |
| **2025-04-18** | README generated following OMNI template standard |

## Development Guide

### Versioning Strategy

- **Major Version**: Increment when making breaking changes, such as removing deprecated fields or methods.
- **Minor Version**: Increment when adding new features, such as new containers, repositories, or helper methods.
- **Build Version**: Increment for bug fixes, performance improvements, or non-functional changes.

Ensure that the `pom.xml` file is updated with the new version number before releasing the library.

## License

Internal use only.

## Support

Contact the development team at [MPSScrumTeam1](DL-MPSScrumTeam1@att.com) or contact one of the team members directly:
- [Prasad Gaikwad](pg1277@att.com)
- [Sajeev Sahajnandan](ss254y@att.com)
- [Vikas Saini](vs3652@att.com)
