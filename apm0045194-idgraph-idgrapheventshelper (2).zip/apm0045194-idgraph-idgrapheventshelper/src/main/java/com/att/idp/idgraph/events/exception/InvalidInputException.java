package com.att.idp.idgraph.events.exception;

public class InvalidInputException extends EventPublisherException {
    public InvalidInputException(String message) {
        super(message);
    }
}
