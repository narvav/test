package com.att.idp.idgraph.events.exception;

public class MissingConfigurationException extends EventPublisherException {
    public MissingConfigurationException(String message) {
        super(message);
    }
}
