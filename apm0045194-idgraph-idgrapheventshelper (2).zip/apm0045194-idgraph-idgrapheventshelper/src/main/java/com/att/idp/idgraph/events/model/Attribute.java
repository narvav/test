package com.att.idp.idgraph.events.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class Attribute implements JsonSealizable {
    private String attributeName;
    private String attributeValue;
}