package com.att.idp.idgraph.events.model;

import com.fasterxml.jackson.annotation.JsonValue;

public enum EventCategory {
    PASSCODE("Passcode");

    private final String value;

    EventCategory(String value) {
        this.value = value;
    }

    @JsonValue
    public String getValue() {
        return value;
    }
}
