package com.att.idp.idgraph.events;

import com.att.idp.idgraph.events.annotation.EnableEventPublisher;
import com.att.idp.idgraph.events.model.*;
import com.att.idp.idgraph.events.service.EventPublisher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * Application class for publishing messages using EventPublisher.
 * This class demonstrates how to publish messages synchronously and
 * asynchronously.
 *
 * @author Prasad Gaikwad
 */
@Slf4j
@SpringBootApplication
@ConditionalOnProperty(name = "idp.idgraph-events-helper.sample.enabled", havingValue = "true")
@EnableEventPublisher
public class EventsHelperSampleApplication implements CommandLineRunner {

    // applications may have multiple bindings for publisher, Azure Events Hub, ISBus or both
    private static final String AEH_BINDING = "publishHello";
    private static final String ISBUS_BINDING = "anotherPublishHello";

    @Autowired
    private EventPublisher eventPublisher;

    public static void main(String[] args) {
        SpringApplication.run(EventsHelperSampleApplication.class, args);
    }

    @Override
    public void run(String... args) throws InterruptedException {
        log.info("attempting to publish a message");

        try {
            // Example: publish IDGraphEvent synchronously
            publishIDGraphEventSync();
            // Example: publish IDGraphEvent asynchronously
            publishIDGraphEventAsync();
            // Example: publish IDGraphEvent asynchronously with callback
            publishIDGraphEventAsyncWithCallback();
            // Example: publish custom object synchronously
            publishCustomObjectSync();
            log.info("done publishing messages");
        } catch (Exception e) {
            log.error("Error occurred while publishing messages", e);
        }

        Thread.sleep(1000); // needed to wait for async messages to be sent
        System.exit(0);
    }

    private void publishIDGraphEventSync() {
        log.info("attempting to publish an IDGraphEvent (sync)");
        IDGraphEvent event = getEvent();

        boolean syncResult = eventPublisher.send(AEH_BINDING, "sync " + event.getEventDetails().getIndividualId(), event);
        if (syncResult) {
            log.info("published IDGraphEvent successfully (sync) to first binding");
        } else {
            log.error("failed to publish IDGraphEvent (sync) to first binding");
        }

        syncResult = eventPublisher.send(ISBUS_BINDING, "sync - second binding " + event.getEventDetails().getIndividualId(), event);
        if (syncResult) {
            log.info("published IDGraphEvent successfully (sync) to second binding");
        } else {
            log.error("failed to publish IDGraphEvent (sync) to second binding");
        }
    }

    private void publishIDGraphEventAsync() {
        log.info("attempting to publish an IDGraphEvent (async)");
        IDGraphEvent event = getEvent();

        eventPublisher
                .sendAsync(AEH_BINDING, "async " + event.getEventDetails().getIndividualId(), event)
                .thenAccept(result -> log.info("published IDGraphEvent successfully (async) to first binding"))
                .exceptionally(ex -> {
                    log.error("failed to publish IDGraphEvent (async) to first binding", ex);
                    return null;
                });
    }

    private void publishIDGraphEventAsyncWithCallback() {
        log.info("attempting to publish an IDGraphEvent (async callback)");
        IDGraphEvent event = getEvent();

        eventPublisher.sendAsyncWithCallback(
                AEH_BINDING, "async callback " + event.getEventDetails().getIndividualId(), event,
                result -> log.info("published IDGraphEvent successfully (async callback) to first binding"),
                ex -> log.error("failed to publish IDGraphEvent (async callback) to first binding", ex));
    }

    private IDGraphEvent getEvent() {
        return IDGraphEvent.builder()
                .eventId("IDGraphUserAssociationMs-" + "1234")
                .eventType(EventType.PROFILE_UPDATE)
                .category(EventCategory.PASSCODE)
                .subCategory(EventSubCategory.INDIVIDUALID_PASSCODE)
                .eventTime(Instant.now())
                .eventDetails(EventDetails.builder()
                        .individualId("123e4567-e89b-12d3-a456-426614174000")
                        .clientId("TEST_CLIENT_ID")
                        .attributes(List.of(Attribute.builder()
                                .attributeName("passcode")
                                .attributeValue("passcode-value")
                                .build()))
                        .build())
                .build();
    }

    private void publishCustomObjectSync() {
        log.info("attempting to publish a custom object (sync)");
        Map<String, Object> customObject = Map.of(
                "id", "custom-object-1234",
                "name", "Custom Object Name",
                "description", "This is a custom object for testing purposes.",
                "createdAt", Instant.now(),
                "attributes", Map.of(
                        "attribute1", "value1",
                        "attribute2", 42,
                        "attribute3", true
                )
        );

        boolean syncResult = eventPublisher.send(AEH_BINDING, "custom-object-sync " + customObject.get("id"), customObject);
        if (syncResult) {
            log.info("published CustomObject successfully (sync) to first binding");
        } else {
            log.error("failed to publish CustomObject (sync) to first binding");
        }
    }
}