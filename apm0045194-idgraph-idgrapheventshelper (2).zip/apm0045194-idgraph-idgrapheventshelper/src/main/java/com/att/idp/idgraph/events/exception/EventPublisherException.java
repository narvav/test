package com.att.idp.idgraph.events.exception;

/**
 * EventPublisherException is a custom exception class that extends RuntimeException.
 * It is used to indicate errors that occur during the event publishing process.
 * This exception can be thrown with a message, a cause, or both.
 *
 * @author Prasad Gaikwad
 */
public class EventPublisherException extends RuntimeException {
    public EventPublisherException(String message) {
        super(message);
    }

    public EventPublisherException(String message, Throwable cause) {
        super(message, cause);
    }

    public EventPublisherException(Throwable cause) {
        super(cause);
    }
}
