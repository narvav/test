package com.att.idp.idgraph.events.service;

import com.att.idp.idgraph.events.exception.EventPublisherException;

import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 * EventPublisher is an interface that defines methods for sending messages to a specified binding using Spring Cloud Stream.
 * It supports both synchronous and asynchronous message sending, with fallback mechanisms for different binders.
 * 
 * @author Prasad Gaikwad
 */
public interface EventPublisher {

    boolean send(String bindingName, String key, Object payload) throws EventPublisherException;

    CompletableFuture<Boolean> sendAsync(String bindingName, String key, Object payload);

    void sendAsyncWithCallback(String bindingName, String key, Object payload,
            Consumer<Boolean> onSuccess,
            Consumer<Throwable> onFailure);
}