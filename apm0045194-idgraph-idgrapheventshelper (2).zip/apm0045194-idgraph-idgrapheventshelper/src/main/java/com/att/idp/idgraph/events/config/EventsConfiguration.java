package com.att.idp.idgraph.events.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.retry.annotation.EnableRetry;

/**
 * Configuration class for the Events module.
 * This class scans for components in the specified package and loads properties from the specified file.
 *
 * @author Prasad Gaikwad
 */
@EnableRetry
@Configuration
@ComponentScan(basePackages = "com.att.idp.idgraph.events")
@PropertySource("classpath:eventshelper.properties")
public class EventsConfiguration {

}
