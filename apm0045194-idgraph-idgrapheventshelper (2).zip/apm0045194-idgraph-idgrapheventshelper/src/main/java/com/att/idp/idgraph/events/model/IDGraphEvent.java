package com.att.idp.idgraph.events.model;

import java.time.Instant;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class IDGraphEvent implements JsonSealizable {
    private String eventId;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", shape = Shape.STRING, timezone = "UTC")
    private Instant eventTime;
    private EventType eventType;
    private EventCategory category;
    private EventSubCategory subCategory;
    private EventDetails eventDetails;
}