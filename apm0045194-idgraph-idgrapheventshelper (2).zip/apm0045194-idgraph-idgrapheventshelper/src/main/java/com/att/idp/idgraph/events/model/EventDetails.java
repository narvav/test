package com.att.idp.idgraph.events.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
public class EventDetails implements JsonSealizable {
    private String clientId;

    private String individualId;

    private String accountId;
    private String accountType;

    private List<Attribute> attributes;

    // for future use
    private String langPreference;
    private String customerType;
    private String channel;
}