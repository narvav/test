package com.att.idp.idgraph.events.service.impl;

import com.att.idp.idgraph.events.exception.EventPublisherException;
import com.att.idp.idgraph.events.exception.InvalidInputException;
import com.att.idp.idgraph.events.exception.MissingConfigurationException;
import com.att.idp.idgraph.events.helper.StreamOperationsHelper;
import com.att.idp.idgraph.events.service.EventPublisher;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 * EventPublisherImpl is a service that provides methods to send messages to a specified binding using Spring Cloud Stream.
 * It supports both synchronous and asynchronous message sending, with fallback mechanisms for different binders.
 *
 * @author Prasad Gaikwad
 */
@Slf4j
@Service
public class EventPublisherImpl implements EventPublisher {

    private static final String BINDER_PRIMARY = "primary";
    private static final String BINDER_SECONDARY = "secondary";
    private static final String BINDING_SUFFIX = "-out-0";
    private static final String PROPERTY_BINDER_TYPE = "spring.cloud.stream.binders.%s.type";
    private static final String PROPERTY_DESTINATION = "spring.cloud.stream.bindings.%s.destination";

    @Autowired
    private Environment environment;

    @Autowired
    private StreamOperationsHelper streamOperationsHelper;

    /**
     * Sends a message to the specified binding name with the given key and payload.
     * If sending to the primary binder fails, it attempts to send to the secondary binder.
     *
     * @param bindingName The name of the binding to send the message to.
     * @param key         The key for the message.
     * @param payload     The payload of the message.
     * @return true if the message was sent successfully, false otherwise.
     * @throws EventPublisherException if an error occurs while sending the message.
     */
    @Override
    public boolean send(String bindingName, String key, Object payload) throws EventPublisherException {
        try {
            Assert.hasText(bindingName, "Binding name must not be empty");

            String primaryBinder = getBinder(bindingName, BINDER_PRIMARY);
            String secondaryBinder = getBinder(bindingName, BINDER_SECONDARY);
            String configuredBindingName = bindingName + BINDING_SUFFIX;

            String destination = environment.getProperty(String.format(PROPERTY_DESTINATION, configuredBindingName));
            if (!StringUtils.hasText(destination)) {
                throw new MissingConfigurationException("Destination must be configured for binding: " + bindingName);
            }

            return send(primaryBinder, secondaryBinder, configuredBindingName, key, payload);
        } catch (IllegalArgumentException e) {
            log.error("Invalid argument provided: {}", e.getMessage());
            throw new InvalidInputException(e.getMessage());
        }
    }

    @NotNull
    private String getBinder(String bindingName, String binderName) {
        return bindingName + "-" + binderName;
    }

    /**
     * Sends a message to the specified primary and secondary binders with the given binding name, key, and payload.
     * If sending to the primary binder fails, it attempts to send to the secondary binder.
     *
     * @param primaryBinder   The name of the primary binder to send the message to.
     * @param secondaryBinder The name of the secondary binder to send the message to.
     * @param bindingName     The name of the binding to send the message to.
     * @param key             The key for the message.
     * @param payload         The payload of the message.
     * @return true if the message was sent successfully, false otherwise.
     * @throws EventPublisherException if an error occurs while sending the message.
     */
    private boolean send(String primaryBinder, String secondaryBinder, String bindingName, String key, Object payload) throws EventPublisherException {
        log.info("Sending message to primary binder: {}, secondary binder: {}, binding: {}, key: {}, payload: {}",
                primaryBinder, secondaryBinder, bindingName, key, payload);

        Assert.hasText(primaryBinder, "Primary binder name must not be empty");
        Assert.hasText(secondaryBinder, "Secondary binder name must not be empty");
        Assert.hasText(bindingName, "Binding name must not be empty");
        Assert.hasText(key, "Key must not be empty");
        Assert.notNull(payload, "Payload must not be empty");

        String primaryBinderType = environment.getProperty(String.format(PROPERTY_BINDER_TYPE, primaryBinder));
        String secondaryBinderType = environment.getProperty(String.format(PROPERTY_BINDER_TYPE, secondaryBinder));

        if (!StringUtils.hasText(primaryBinderType)) {
            throw new MissingConfigurationException("Primary binder type must be configured for binder: " + primaryBinder);
        }

        try {
            log.debug("Attempting to send message to primary binder, binding: {}, key: {}, payload: {}",
                    bindingName, key, payload);
            return streamOperationsHelper.sendToStreamOperations(primaryBinder, bindingName, key, payload);
        } catch (Exception exception) {
            log.warn("Failed to send message to primary binder so sending to secondary binder, " +
                            "binding: {}, key: {}, payload: {}, error: {}",
                    bindingName, key, payload, exception.getMessage());

            // If primary binder fails, check if secondary binder is configured and try sending there
            if (StringUtils.hasText(secondaryBinderType)) {
                log.debug("Attempting to send message to secondary binder, binding: {}, key: {}, payload: {}",
                        bindingName, key, payload);
                try {
                    return streamOperationsHelper.sendToStreamOperations(secondaryBinder, bindingName, key, payload);
                } catch (Exception e) {
                    log.warn("Failed to send message to secondary binder, binding: {}, key: {}, payload: {}, error: {}",
                            bindingName, key, payload, e.getMessage());
                    throw new EventPublisherException(String.format("Failed to send message [bindingName=%s, key=%s]",
                            bindingName, key), e);
                }
            } else {
                log.error("Secondary binder is not configured, cannot send message [bindingName={}, key={}]",
                        bindingName, key);
                throw new EventPublisherException(String.format("Failed to send message [bindingName=%s, key=%s]",
                        bindingName, key), exception);
            }
        }
    }

    /**
     * Sends a message to the specified binder and binding name with the given key and payload asynchronously.
     *
     * @param bindingName The name of the binding to send the message to.
     * @param key         The key for the message.
     * @param payload     The payload of the message.
     * @return CompletableFuture that will be completed with true if the message was sent successfully, false otherwise.
     * @throws EventPublisherException if an error occurs while sending the message.
     */
    @Override
    public CompletableFuture<Boolean> sendAsync(String bindingName, String key, Object payload) {
        return CompletableFuture.supplyAsync(() -> send(bindingName, key, payload));
    }

    /**
     * Sends a message to the specified binder and binding name with the given key and payload asynchronously.
     * This method also accepts callbacks for success and failure scenarios.
     *
     * @param bindingName The name of the binding to send the message to.
     * @param key         The key for the message.
     * @param payload     The payload of the message.
     * @param onSuccess   Callback to be executed on successful sending of the message.
     * @param onFailure   Callback to be executed on failure to send the message.
     * @throws EventPublisherException if an error occurs while sending the message.
     */
    @Override
    public void sendAsyncWithCallback(String bindingName, String key, Object payload,
                                      Consumer<Boolean> onSuccess,
                                      Consumer<Throwable> onFailure) {
        sendAsync(bindingName, key, payload)
                .thenAccept(onSuccess)
                .exceptionally(ex -> {
                    onFailure.accept(ex);
                    return null;
                });
    }
}
