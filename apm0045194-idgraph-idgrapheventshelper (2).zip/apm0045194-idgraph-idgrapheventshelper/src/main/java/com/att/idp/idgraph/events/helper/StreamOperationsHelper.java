package com.att.idp.idgraph.events.helper;

import com.att.idp.idgraph.events.exception.EventPublisherException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.function.StreamOperations;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.retry.support.RetrySynchronizationManager;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.util.Map;

/**
 * StreamOperationsHelper is a helper class that provides methods to send messages to a specified binder and binding name.
 * It uses Spring Cloud Stream's StreamOperations for message sending and includes retry logic for transient failures.
 *
 * @author Prasad Gaikwad
 */
@Slf4j
@Component
public class StreamOperationsHelper {

    @Autowired
    private StreamOperations streamOperations;

    /**
     * Sends a message to the specified binder and binding name with the given key and payload.
     *
     * @param binderName  The name of the binder to send the message to.
     * @param bindingName The name of the binding to send the message to.
     * @param key         The key for the message.
     * @param payload     The payload of the message.
     * @return true if the message was sent successfully, false otherwise.
     * @throws EventPublisherException if an error occurs while sending the message.
     */
    @Retryable(retryFor = {EventPublisherException.class},
            maxAttemptsExpression = "${idp.idgraph.event.publisher.retry.maxAttempts:3}",
            backoff = @Backoff(
                    delayExpression = "${idp.idgraph.event.publisher.retry.backoff.delay.ms:100}",
                    multiplierExpression = "${idp.idgraph.event.publisher.retry.backoff.multiplier:1.5}",
                    maxDelayExpression = "${idp.idgraph.event.publisher.retry.backoff.maxDelay.ms:5000}",
                    random = true))
    public boolean sendToStreamOperations(String binderName, String bindingName, String key, Object payload) throws EventPublisherException {
        int retryCount = RetrySynchronizationManager.getContext() != null ? RetrySynchronizationManager.getContext().getRetryCount() : 0;

        log.info("Retry: {} - Sending message to binder: {}, binding: {}, key: {}, payload: {}",
                retryCount, binderName, bindingName, key, payload);
        Assert.hasText(binderName, "Binder name must not be empty");
        Assert.hasText(bindingName, "Binding name must not be empty");
        Assert.hasText(key, "Key must not be empty");
        Assert.notNull(payload, "Payload must not be empty");

        try {
            boolean result = streamOperations.send(bindingName, binderName, getMessage(key, payload));
            if (!result) {
                log.error("StreamOperations send returned false");
                throw new EventPublisherException(String.format("StreamOperations send returned false [binderName=%s, bindingName=%s, key=%s]", binderName, bindingName, key));
            }
            log.info("Message sent successfully to binder: {}, binding: {}, key: {}, payload: {}", binderName, bindingName, key, payload);
            return true;
        } catch (Exception e) {
            throw handleException(binderName, bindingName, key, payload, e);
        }
    }

    /**
     * Handles exceptions that occur during message sending.
     *
     * @param binderName  The name of the binder where the message was being sent.
     * @param bindingName The name of the binding where the message was being sent.
     * @param key         The key for the message.
     * @param payload     The payload of the message.
     * @param exception   The exception that occurred.
     * @return An EventPublisherException with a detailed error message.
     */
    private EventPublisherException handleException(String binderName, String bindingName, String key, Object payload, Exception exception) {
        log.error("Failed to send message to binder: {}, binding: {}, key: {}, payload: {}, error: {}", binderName, bindingName, key, payload, exception.getMessage());
        if (exception instanceof EventPublisherException) {
            return (EventPublisherException) exception;
        }
        return new EventPublisherException("Failed to send message after retries", exception);
    }

    /**
     * Sends a message with additional custom headers (e.g., resiliency headers for batch retry).
     *
     * @param binderName   The name of the binder to send the message to.
     * @param bindingName  The name of the binding to send the message to.
     * @param key          The key for the message.
     * @param payload      The payload of the message.
     * @param extraHeaders Additional headers to include (e.g., x-idg-sequence, x-idg-is-retry).
     * @return true if the message was sent successfully, false otherwise.
     * @throws EventPublisherException if an error occurs while sending the message.
     */
    @Retryable(retryFor = {EventPublisherException.class},
            maxAttemptsExpression = "${idp.idgraph.event.publisher.retry.maxAttempts:3}",
            backoff = @Backoff(
                    delayExpression = "${idp.idgraph.event.publisher.retry.backoff.delay.ms:100}",
                    multiplierExpression = "${idp.idgraph.event.publisher.retry.backoff.multiplier:1.5}",
                    maxDelayExpression = "${idp.idgraph.event.publisher.retry.backoff.maxDelay.ms:5000}",
                    random = true))
    public boolean sendToStreamOperationsWithHeaders(String binderName, String bindingName, String key,
                                                      Object payload, Map<String, String> extraHeaders) throws EventPublisherException {
        int retryCount = RetrySynchronizationManager.getContext() != null ? RetrySynchronizationManager.getContext().getRetryCount() : 0;

        log.info("Retry: {} - Sending message with headers to binder: {}, binding: {}, key: {}",
                retryCount, binderName, bindingName, key);
        Assert.hasText(binderName, "Binder name must not be empty");
        Assert.hasText(bindingName, "Binding name must not be empty");
        Assert.hasText(key, "Key must not be empty");
        Assert.notNull(payload, "Payload must not be empty");

        try {
            boolean result = streamOperations.send(bindingName, binderName, getMessageWithHeaders(key, payload, extraHeaders));
            if (!result) {
                log.error("StreamOperations send returned false");
                throw new EventPublisherException(String.format("StreamOperations send returned false [binderName=%s, bindingName=%s, key=%s]", binderName, bindingName, key));
            }
            log.info("Message with headers sent successfully to binder: {}, binding: {}, key: {}", binderName, bindingName, key);
            return true;
        } catch (Exception e) {
            throw handleException(binderName, bindingName, key, payload, e);
        }
    }

    /**
     * Constructs a Message object with the specified key and payload.
     *
     * @param key     The key for the message.
     * @param payload The payload of the message.
     * @return A Message object containing the key and payload.
     */
    private Message<?> getMessage(String key, Object payload) {
        return MessageBuilder.withPayload(payload)
                .setHeader(KafkaHeaders.KEY, key)
                .build();
    }

    /**
     * Constructs a Message object with the specified key, payload, and additional custom headers.
     * Used by batch retry to add resiliency headers (x-idg-sequence, x-idg-is-retry, etc.).
     *
     * @param key          The key for the message.
     * @param payload      The payload of the message.
     * @param extraHeaders Additional headers to include in the message.
     * @return A Message object containing the key, payload, and extra headers.
     */
    private Message<?> getMessageWithHeaders(String key, Object payload, Map<String, String> extraHeaders) {
        MessageBuilder<?> builder = MessageBuilder.withPayload(payload)
                .setHeader(KafkaHeaders.KEY, key);
        if (extraHeaders != null) {
            extraHeaders.forEach(builder::setHeader);
        }
        return builder.build();
    }
}
