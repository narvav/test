package com.att.idp.idgraph.events.model;

/**
 * Result of {@link com.att.idp.idgraph.events.service.ResilientEventConsumer#evaluate} indicating
 * what action the consumer should take for the current message.
 * <ul>
 *     <li>{@code PROCESS} — Happy-path message (no {@code x-idg-sequence} header) or first-time
 *         retried message whose sequence is in order. The consumer should process this message normally.</li>
 *     <li>{@code SKIP_DUPLICATE} — Retried message that has already been processed (idempotency key
 *         found in the dedup store). The consumer should acknowledge without processing.</li>
 *     <li>{@code SKIP_STALE} — Retried message whose sequence is older than the last processed
 *         sequence for this entity. The consumer should acknowledge without processing.</li>
 * </ul>
 */
public enum ConsumerAction {
    PROCESS,
    SKIP_DUPLICATE,
    SKIP_STALE
}
