package com.att.idp.idgraph.events.service;

import com.att.idp.idgraph.db.cosmos.entity.KafkaEventRecord;
import com.att.idp.idgraph.db.cosmos.entity.KafkaEventStatus;
import com.att.idp.idgraph.db.cosmos.helper.KafkaEventRecordDBHelper;
import com.att.idp.idgraph.events.exception.EventPublisherException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.text.StringEscapeUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

/**
 * ResilientEventPublisher wraps {@link EventPublisher} with Cosmos DB fallback.
 * <p>
 * On the happy path, Kafka's partition offset provides sequencing — no application-level
 * sequence numbers, locks, or extra headers are needed.
 * </p>
 * <p>
 * On publish failure (after primary + secondary retries are exhausted inside EventPublisher),
 * this class generates a sequence number and deterministic idempotency key, then persists
 * the failed event to Cosmos DB so that the batch microservice can retry it later.
 * </p>
 * <p>
 * When {@code kafka.resiliency.use-unified-entity=true}, the new {@link KafkaEventRecord}
 * entity is used (with sequence/idempotency support). When resiliency is disabled, Kafka
 * failures propagate as {@link EventPublisherException} — no Cosmos fallback is attempted.
 * </p>
 */
@Slf4j
@Component
public class ResilientEventPublisher {

    private static final String PROPERTY_DESTINATION = "spring.cloud.stream.bindings.%s-out-0.destination";
    private static final String COUNTER_FORMAT = "%05d";

    private final ConcurrentHashMap<String, AtomicInteger> entityCounters = new ConcurrentHashMap<>();

    @Autowired
    private EventPublisher eventPublisher;

    @Autowired(required = false)
    private KafkaEventRecordDBHelper kafkaEventRecordDBHelper;

    @Autowired
    private Environment environment;

    @Value("${idp.idgraph.env.prefix:}")
    private String processedEnvPrefix;

    @Value("${spring.application.name:unknown}")
    private String sourceAPI;

    @Value("${environment.region:east}")
    private String region;

    @Value("${kafka.resiliency.use-unified-entity:false}")
    private boolean useUnifiedEntity;

    @Value("${kafka.event.record.ttl.seconds:604800}")
    private int ttlSeconds;

    @Value("${kafka.resiliency.payload.account-fields:accountNumber,billingAccountNumber}")
    private List<String> accountFields;

    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Serialize the payload as JSON so that (a) the probe's
     * {@link #extractAccountNumberFromPayload} can parse it with Jackson, and
     * (b) {@code KafkaRetryProcessingService} can deserialize and republish it.
     * Falls back to {@code toString()} if the payload is not Jackson-serializable
     * — better to have a debuggable string than to lose the message entirely.
     */
    private String serializePayloadAsJson(Object payload) {
        if (payload == null) {
            return "";
        }
        if (payload instanceof String s) {
            return s;
        }
        try {
            return objectMapper.writeValueAsString(payload);
        } catch (Exception ex) {
            log.warn("REP_11: Falling back to toString for payload type {} — JSON serialization failed: {}",
                    payload.getClass().getSimpleName(), ex.getMessage());
            return payload.toString();
        }
    }

    /**
     * Publishes a message with automatic Cosmos DB fallback on failure.
     *
     * @param bindingName   Spring Cloud Stream binding name (e.g., "subscriber")
     * @param publisherName human-readable publisher label / event name (e.g., "AccountActivation")
     * @param key           Kafka message key (typically accountId or BAN)
     * @param payload       serialized JSON message body
     * @return {@code true} if published to Kafka successfully, {@code false} if saved to Cosmos fallback
     */
    public boolean sendWithFallback(String bindingName, String publisherName,
                                     String key, Object payload) {
        // Per-account ordering circuit breaker.
        // If prior events for this account on this binding are still pending in Cosmos
        // (status FAILED / CIRCUIT_OPEN / RETRY_CLAIMED / RETRY_EXHAUSTED), route this event directly to
        // Cosmos with status=CIRCUIT_OPEN so it is distinguishable from true publish failures,
        // while still remaining retryable by batch in sequence-number order.
        // order. Without this, a CloseAccount could win the race and reach Kafka before a
        // failed UpdateAccount predecessor is replayed, violating per-account ordering.
        // Only active when the unified-entity rollout flag is on AND the Cosmos helper bean
        // is wired in — preserves the legacy code path bit-for-bit when the feature is off.
        if (useUnifiedEntity && kafkaEventRecordDBHelper != null) {
            String payloadStrForProbe = serializePayloadAsJson(payload);
            String accountNumberForProbe = extractAccountNumberFromPayload(payloadStrForProbe, key);
            if (kafkaEventRecordDBHelper.hasPendingEvents(accountNumberForProbe, bindingName)) {
                String sanitizedAccountNumber = ESAPI.encoder().encodeForHTML(accountNumberForProbe);
                log.warn("REP_09: Circuit breaker engaged — pending events for accountNumber={}, " +
                                "binding={}; routing this event to Cosmos to preserve per-account order",
                        sanitizedAccountNumber, bindingName);
                saveToCosmosDbUnified(bindingName, publisherName, key, payload,
                        "Blocked by circuit breaker — pending events for accountNumber=" + sanitizedAccountNumber,
                        KafkaEventStatus.CIRCUIT_OPEN);
                return false;
            }
        }

        // HAPPY PATH: Kafka partition offset provides sequencing — no app-level sequence needed
        try {
            boolean result = eventPublisher.send(bindingName, key, payload);
            if (result) {
                log.info("REP_01: Message published successfully via binding: {}, key: {}", bindingName, key);
            }
            return result;
        } catch (EventPublisherException e) {
            // FAILURE PATH: persist to Cosmos (unified) or propagate (resiliency disabled)
            log.error("REP_02: All Kafka publish attempts exhausted for binding: {}, key: {}, error: {}",
                    bindingName, key, e.getMessage());
            if (useUnifiedEntity && kafkaEventRecordDBHelper != null) {
                saveToCosmosDbUnified(bindingName, publisherName, key, payload, e.getMessage(), KafkaEventStatus.FAILED);
            } else {
                throw e;
            }
            return false;
        } catch (Exception unexpected) {
            // An unchecked exception escaped EventPublisher (e.g., NPE in payload
            // serialization, RuntimeException in a binder). When resiliency is enabled, persist to
            // Cosmos so JMS (CLIENT_ACKNOWLEDGE) can redeliver on failure. When disabled, propagate.
            log.error("REP_UNEXPECTED: Unexpected error in sendWithFallback for binding: {}, key: {}, error: {}",
                    bindingName, key, unexpected.getMessage(), unexpected);
            if (useUnifiedEntity && kafkaEventRecordDBHelper != null) {
                saveToCosmosDbUnified(bindingName, publisherName, key, payload, unexpected.getMessage(), KafkaEventStatus.FAILED);
            } else {
                throw new EventPublisherException(
                        "Unexpected publish error; resiliency not enabled for this publisher: " + unexpected.getMessage(), unexpected);
            }
            return false;
        }
    }

    /**
     * Asynchronous version of {@link #sendWithFallback(String, String, String, Object)}.
     *
     * @param bindingName   Spring Cloud Stream binding name
     * @param publisherName human-readable publisher label / event name
     * @param key           Kafka message key
     * @param payload       serialized JSON message body
     * @return CompletableFuture resolving to {@code true} if published, {@code false} if saved to Cosmos
     */
    public CompletableFuture<Boolean> sendWithFallbackAsync(String bindingName, String publisherName,
                                                             String key, Object payload) {
        return CompletableFuture.supplyAsync(() -> sendWithFallback(bindingName, publisherName, key, payload));
    }

    /**
     * Asynchronous version with callbacks.
     *
     * @param bindingName   Spring Cloud Stream binding name
     * @param publisherName human-readable publisher label / event name
     * @param key           Kafka message key
     * @param payload       serialized JSON message body
     * @param onSuccess     callback on successful send or Cosmos fallback
     * @param onFailure     callback if both Kafka send and Cosmos fallback fail
     */
    public void sendWithFallbackAsyncCallback(String bindingName, String publisherName,
                                               String key, Object payload,
                                               Consumer<Boolean> onSuccess,
                                               Consumer<Throwable> onFailure) {
        sendWithFallbackAsync(bindingName, publisherName, key, payload)
                .thenAccept(onSuccess)
                .exceptionally(ex -> {
                    onFailure.accept(ex);
                    return null;
                });
    }

    /**
     * Persists a failed Kafka publish event to the Cosmos DB fallback container
     * using the new unified {@link KafkaEventRecord} entity with sequence/idempotency support.
     * <p>
     * The {@code accountNumber} is extracted from the payload JSON using the configured
     * field names ({@code kafka.resiliency.payload.account-fields}). The {@code entityKey}
     * is computed as {@code accountNumber + "|" + publisherName}.
     * </p>
     */
    private void saveToCosmosDbUnified(String bindingName, String publisherName,
                                        String key, Object payload, String errorMessage,
                                        KafkaEventStatus status) {
        try {
            String payloadStr = serializePayloadAsJson(payload);
            String accountNumber = extractAccountNumberFromPayload(payloadStr, key);
            String entityKey = accountNumber + "|" + publisherName;
            String seq = generateSequenceNumber(entityKey);
            String idempotencyKey = generateIdempotencyKey(bindingName, entityKey, seq);
            String topicDestination = environment.getProperty(
                    String.format(PROPERTY_DESTINATION, bindingName), "unknown");

            KafkaEventRecord record = KafkaEventRecord.builder()
                    .accountNumber(accountNumber)
                    .idempotencyKey(idempotencyKey)
                    .entityKey(entityKey)
                    .kafkaPartitionKey(key)
                    .sequenceNumber(seq)
                    .bindingName(bindingName)
                    .topicDestination(topicDestination)
                    .publisherName(publisherName)
                    .sourceAPI(sourceAPI)
                    .requestPayload(payloadStr)
                    .errorMessage(errorMessage)
                    .traceId(MDC.get("idp-trace-id"))
                    .processedRegion(region)
                    .processedEnvPrefix(processedEnvPrefix)
                    .status(status)
                    .retryCount(0)
                    .ttl(ttlSeconds)
                    .build();

            kafkaEventRecordDBHelper.saveEventRecord(record);
            log.info("REP_05: Failed Kafka message saved as KafkaEventRecord — binding: {}, topic: {}, " +
                            "accountNumber: {}, entityKey: {}, seq: {}, idempotencyKey: {}, traceId: {}",
                    bindingName, topicDestination, accountNumber, entityKey, seq, idempotencyKey,
                    MDC.get("idp-trace-id"));
        } catch (Exception cosmosEx) {
            log.error("REP_06: CRITICAL — Failed to save KafkaEventRecord to Cosmos DB. " +
                            "Binding: {}, Key: {}, Error: {}, Original Payload: {}",
                    StringEscapeUtils.escapeJava(bindingName),
                    StringEscapeUtils.escapeJava(key),
                    StringEscapeUtils.escapeJava(cosmosEx.getMessage()),
                    StringEscapeUtils.escapeJava(payload != null ? payload.toString() : "null"));
            throw new EventPublisherException(
                    "Message publishing failed for binding " + bindingName
                            + " and Cosmos DB fallback also failed: " + cosmosEx.getMessage(), cosmosEx);
        }
    }

    /**
     * Persists a pre-Kafka validation failure to the Cosmos DB audit container
     * using the unified {@link KafkaEventRecord} entity with {@code status=VALIDATION_FAILED}.
     * <p>
     * These records are <b>non-retryable</b>: {@code batchms} only queries
     * {@code status='FAILED'}, so VALIDATION_FAILED rows are never replayed. They are stored
     * exclusively for audit / dead-letter inspection.
     * </p>
     * <p>
     * If the unified entity is not enabled or Cosmos save fails, the failure is logged at ERROR
     * level but no exception is propagated — the JMS layer has already decided whether to
     * acknowledge this message, and a secondary Cosmos failure must not swallow the original
     * validation context.
     * </p>
     *
     * @param bindingName     Spring Cloud Stream binding name (e.g., "gddnSubscriberNotifications")
     * @param publisherName   event name (e.g., "AccountActivation"), used as publisherName field and in entityKey
     * @param rawPayload      the raw JSON string that failed validation
     * @param validationError description of why validation failed
     */
    public void saveValidationFailure(String bindingName, String publisherName,
                                      String rawPayload, String validationError) {
        if (!useUnifiedEntity || kafkaEventRecordDBHelper == null) {
            String sanitizedValidationError = ESAPI.encoder().encodeForHTML(validationError);
            log.warn("REP_VAL_01: Validation failure received but unified entity is disabled — not persisted. " +
                    "binding={}, error={}", bindingName, sanitizedValidationError);
            return;
        }
        try {
            String accountNumber = extractAccountNumberFromPayload(rawPayload, "UNKNOWN");
            String entityKey = accountNumber + "|" + publisherName;
            String seq = generateSequenceNumber(entityKey);
            String idempotencyKey = generateIdempotencyKey(bindingName, entityKey, seq);
            String topicDestination = environment.getProperty(
                    String.format(PROPERTY_DESTINATION, bindingName), "unknown");

            KafkaEventRecord record = KafkaEventRecord.builder()
                    .accountNumber(accountNumber)
                    .idempotencyKey(idempotencyKey)
                    .entityKey(entityKey)
                    .kafkaPartitionKey("UNKNOWN")
                    .sequenceNumber(seq)
                    .bindingName(bindingName)
                    .topicDestination(topicDestination)
                    .publisherName(publisherName)
                    .sourceAPI(sourceAPI)
                    .requestPayload(rawPayload != null ? rawPayload : "")
                    .errorMessage(validationError)
                    .traceId(MDC.get("idp-trace-id"))
                    .processedRegion(region)
                    .processedEnvPrefix(processedEnvPrefix)
                    .status(KafkaEventStatus.VALIDATION_FAILED)
                    .retryCount(0)
                    .ttl(ttlSeconds)
                    .build();

            kafkaEventRecordDBHelper.saveEventRecord(record);
            String sanitizedAccountNumber = ESAPI.encoder().encodeForHTML(accountNumber);
            String sanitizedValidationError = ESAPI.encoder().encodeForHTML(validationError);
            log.warn("REP_VAL_02: Validation failure persisted to Cosmos — binding={}, accountNumber={}, " +
                            "validationError={}, traceId={}",
                    bindingName, sanitizedAccountNumber,
                    sanitizedValidationError,
                    MDC.get("idp-trace-id"));
        } catch (Exception e) {
            log.error("REP_VAL_03: CRITICAL — Failed to persist validation failure to Cosmos — " +
                    "binding={}, error={}", StringEscapeUtils.escapeJava(bindingName), e.getMessage());
        }
    }

    /**
     * Generates a sequence number for the failure path.
     * Format: {@code <epochMillis>.<region>.<counter>}
     * <p>
     * The counter is per-entity and uses {@link AtomicInteger} for thread safety.
     * No locks are needed — AtomicInteger.incrementAndGet() is lock-free.
     * </p>
     *
     * @param entityKey the entity key (e.g., BAN)
     * @return the generated sequence number
     */
    String generateSequenceNumber(String entityKey) {
        long epochMillis = System.currentTimeMillis();
        AtomicInteger counter = entityCounters.computeIfAbsent(entityKey, k -> new AtomicInteger(0));
        int count = counter.incrementAndGet();
        return epochMillis + "." + region + "." + String.format(COUNTER_FORMAT, count);
    }

    /**
     * Generates a deterministic idempotency key using SHA-256.
     * Format: {@code SHA-256(bindingName + "|" + entityKey + "|" + sequenceNumber)}
     *
     * @param bindingName the Spring Cloud Stream binding name
     * @param entityKey   the entity key (e.g., BAN)
     * @param seq         the sequence number
     * @return hex-encoded SHA-256 hash
     */
    String generateIdempotencyKey(String bindingName, String entityKey, String seq) {
        String input = bindingName + "|" + entityKey + "|" + seq;
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 algorithm not available", e);
        }
    }

    /**
     * Extracts the account number from the payload JSON using the configured field names.
     * Tries each field in {@code kafka.resiliency.payload.account-fields} order,
     * returning the first non-null, non-empty value found.
     * Falls back to the Kafka key if extraction fails.
     *
     * @param payloadStr the serialized JSON payload
     * @param kafkaKey   the Kafka message key (fallback)
     * @return the extracted account number, or the Kafka key, or "unknown"
     */
    String extractAccountNumberFromPayload(String payloadStr, String kafkaKey) {
        if (payloadStr != null && !payloadStr.isEmpty()) {
            try {
                JsonNode root = objectMapper.readTree(payloadStr);
                if (accountFields != null) {
                    for (String field : accountFields) {
                        JsonNode node = root.get(field.trim());
                        if (node != null && !node.isNull() && !node.asText().isEmpty()) {
                            return node.asText();
                        }
                    }
                }
            } catch (Exception e) {
                log.warn("REP_07: Failed to parse payload JSON for accountNumber extraction: {}", e.getMessage());
            }
        }
        // Fallback to Kafka key
        if (kafkaKey != null && !kafkaKey.isEmpty()) {
            log.debug("REP_08: Using Kafka key as accountNumber fallback: {}", kafkaKey);
            return kafkaKey;
        }
        return "unknown";
    }
}
