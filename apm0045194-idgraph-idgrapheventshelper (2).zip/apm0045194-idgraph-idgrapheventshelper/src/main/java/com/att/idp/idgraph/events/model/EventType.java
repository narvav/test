package com.att.idp.idgraph.events.model;

import com.fasterxml.jackson.annotation.JsonValue;

public enum EventType {
    PROFILE_UPDATE("ProfileUpdate");

    private final String value;

    EventType(String value) {
        this.value = value;
    }

    @JsonValue
    public String getValue() {
        return value;
    }
}
