package com.att.idp.idgraph.events.annotation;

import com.att.idp.idgraph.events.config.EventsConfiguration;
import org.springframework.context.annotation.Import;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation to enable event publishing capabilities in a Spring application.
 * This annotation imports the necessary configuration for event publishing.
 *
 * Usage:
 * <pre>
 * {@code
 * @EnableEventPublisher
 * public class MyApplication {
 *     // Application code
 * }
 * }
 * </pre>
 *
 * @author Prasad Gaikwad
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@Import(EventsConfiguration.class)
public @interface EnableEventPublisher {
}
