package com.att.idp.idgraph.events.model;

import com.fasterxml.jackson.annotation.JsonValue;

public enum EventSubCategory {
    INDIVIDUALID_PASSCODE("individualIdPasscode"),
    BSSE_WIRELESS_PASSCODE("bsseWirelessPasscode");

    private final String value;

    EventSubCategory(String value) {
        this.value = value;
    }

    @JsonValue
    public String getValue() {
        return value;
    }
}