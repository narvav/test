package com.att.idp.idgraph.events.service;

import com.att.idp.idgraph.db.cosmos.entity.KafkaEventRecord;
import com.att.idp.idgraph.db.cosmos.entity.KafkaEventStatus;
import com.att.idp.idgraph.db.cosmos.helper.KafkaEventRecordDBHelper;
import com.att.idp.idgraph.events.model.ConsumerAction;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Reusable consumer-side resiliency component for Kafka message deduplication and sequencing.
 * <p>
 * Any {@code @KafkaListener} can inject this component and call {@link #evaluate(MessageHeaders, String)}
 * to determine whether to process, skip (duplicate), or skip (stale) the current message.
 * </p>
 * <p>
 * <strong>Happy-path messages</strong> (no {@code x-idg-sequence} header) are always returned as
 * {@link ConsumerAction#PROCESS} — Kafka partition offset provides sequencing.
 * </p>
 * <p>
 * <strong>Batch-retried messages</strong> (with {@code x-idg-sequence} header) trigger dedup and
 * sequence comparison checks.
 * </p>
 */
@Slf4j
@Component
@ConditionalOnProperty(name = "kafka.resiliency.use-unified-entity", havingValue = "true", matchIfMissing = false)
public class ResilientEventConsumer {

    public static final String HEADER_SEQUENCE = "x-idg-sequence";
    public static final String HEADER_IDEMPOTENCY_KEY = "x-idg-idempotency-key";
    public static final String HEADER_IS_RETRY = "x-idg-is-retry";
    public static final String HEADER_ORIGIN_REGION = "x-idg-origin-region";
    public static final String HEADER_ENTITY_KEY = "x-idg-entity-key";

    private final ConcurrentHashMap<String, Boolean> dedupStore = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, String> sequenceTracker = new ConcurrentHashMap<>();

    @Autowired(required = false)
    private KafkaEventRecordDBHelper kafkaEventRecordDBHelper;

    @Value("${environment.region:east}")
    private String region;

    /**
     * Evaluates a Kafka message and determines the appropriate consumer action.
     * <p>
     * For happy-path messages (no {@code x-idg-sequence} header), always returns {@link ConsumerAction#PROCESS}.
     * For batch-retried messages, performs dedup check and sequence comparison.
     * The {@code entityKey} for retried messages is read from the {@code x-idg-entity-key} header
     * if present, otherwise the caller-provided entityKey is used.
     * </p>
     *
     * @param headers   the Kafka message headers
     * @param entityKey the entity key (fallback if x-idg-entity-key header not present)
     * @return the action the consumer should take
     */
    public ConsumerAction evaluate(MessageHeaders headers, String entityKey) {
        // Prefer x-idg-entity-key header for retried messages (set by batch retry)
        String headerEntityKey = getHeaderAsString(headers, HEADER_ENTITY_KEY);
        if (headerEntityKey != null && !headerEntityKey.isEmpty()) {
            entityKey = headerEntityKey;
        }
        String sequenceHeader = getHeaderAsString(headers, HEADER_SEQUENCE);

        // Happy path: no x-idg-sequence header → Kafka partition offset provides ordering
        if (sequenceHeader == null || sequenceHeader.isEmpty()) {
            log.debug("REC_01: No x-idg-sequence header — happy-path message for entityKey={}", entityKey);
            return ConsumerAction.PROCESS;
        }

        // Batch-retried message: run dedup + sequence checks
        log.info("REC_02: Retried message detected — entityKey={}, sequence={}", entityKey, sequenceHeader);

        String topic = getHeaderAsString(headers, "kafka_receivedTopic");
        String consumerDedupKey = generateConsumerDedupKey(topic, entityKey, sequenceHeader);

        // 1. Dedup check — has this exact retried message been processed before?
        if (dedupStore.putIfAbsent(consumerDedupKey, Boolean.TRUE) != null) {
            log.info("REC_03: DUPLICATE detected — entityKey={}, sequence={}, dedupKey={}",
                    entityKey, sequenceHeader, consumerDedupKey);
            writeSkipAudit(entityKey, sequenceHeader, KafkaEventStatus.DUPLICATE_SKIPPED);
            return ConsumerAction.SKIP_DUPLICATE;
        }

        // 2. Sequence comparison — is this retried message newer than the last processed?
        String lastProcessedSeq = sequenceTracker.get(entityKey);
        if (lastProcessedSeq != null && sequenceHeader.compareTo(lastProcessedSeq) <= 0) {
            log.info("REC_04: STALE detected — entityKey={}, sequence={} <= lastProcessed={}",
                    entityKey, sequenceHeader, lastProcessedSeq);
            writeSkipAudit(entityKey, sequenceHeader, KafkaEventStatus.STALE_SKIPPED);
            return ConsumerAction.SKIP_STALE;
        }

        // 3. In order — update tracker and process
        sequenceTracker.put(entityKey, sequenceHeader);
        log.info("REC_05: Retried message IN ORDER — entityKey={}, sequence={}", entityKey, sequenceHeader);
        return ConsumerAction.PROCESS;
    }

    /**
     * Extracts a header value as a String from MessageHeaders.
     *
     * @param headers   the message headers
     * @param headerKey the header key to extract
     * @return the header value as a string, or null if not present
     */
    private String getHeaderAsString(MessageHeaders headers, String headerKey) {
        Object value = headers.get(headerKey);
        if (value == null) {
            return null;
        }
        if (value instanceof byte[]) {
            return new String((byte[]) value, StandardCharsets.UTF_8);
        }
        return value.toString();
    }

    /**
     * Generates a consumer-side dedup key using SHA-256.
     * Format: {@code SHA-256(topic + "|" + entityKey + "|" + sequenceNumber)}
     *
     * @param topic      the Kafka topic name
     * @param entityKey  the entity key
     * @param sequenceNumber the sequence number from the message header
     * @return hex-encoded SHA-256 hash
     */
    String generateConsumerDedupKey(String topic, String entityKey, String sequenceNumber) {
        String input = (topic != null ? topic : "unknown") + "|" + entityKey + "|" + sequenceNumber;
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 algorithm not available", e);
        }
    }

    /**
     * Writes a skip audit record to Cosmos DB for observability.
     * This is a best-effort write — failures are logged but do not affect consumer processing.
     *
     * @param entityKey      the entity key
     * @param sequenceNumber the sequence number of the skipped message
     * @param status         the skip reason (DUPLICATE_SKIPPED or STALE_SKIPPED)
     */
    private void writeSkipAudit(String entityKey, String sequenceNumber, KafkaEventStatus status) {
        if (kafkaEventRecordDBHelper == null) {
            log.debug("REC_06: KafkaEventRecordDBHelper not available — skipping audit write");
            return;
        }
        try {
            KafkaEventRecord auditRecord = KafkaEventRecord.builder()
                    .accountNumber(entityKey)
                    .entityKey(entityKey)
                    .sequenceNumber(sequenceNumber)
                    .status(status)
                    .processedRegion(region)
                    .build();
            kafkaEventRecordDBHelper.saveEventRecord(auditRecord);
            log.info("REC_07: Skip audit written — entityKey={}, sequence={}, status={}",
                    entityKey, sequenceNumber, status);
        } catch (Exception e) {
            log.warn("REC_08: Failed to write skip audit (non-fatal) — entityKey={}, sequence={}, error={}",
                    entityKey, sequenceNumber, e.getMessage());
        }
    }
}
