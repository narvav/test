package com.att.idp.idgraph.events.helper

import com.att.idp.idgraph.events.exception.EventPublisherException
import org.springframework.cloud.stream.function.StreamOperations
import org.springframework.messaging.Message
import spock.lang.Specification
import spock.lang.Unroll

class StreamOperationsHelperTest extends Specification {
    def streamOperations = Mock(StreamOperations)
    def helper = new StreamOperationsHelper(streamOperations: streamOperations)

    @Unroll
    def "sendToStreamOperations should send message successfully for valid inputs [binderName=#binderName, bindingName=#bindingName, key=#key, payload=#payload]"() {
        given:
        streamOperations.send(bindingName, binderName, _ as Message) >> true

        expect:
        helper.sendToStreamOperations(binderName, bindingName, key, payload)

        where:
        binderName   | bindingName   | key      | payload
        'binder1'    | 'binding1'    | 'key1'   | 'payload1'
        'binder2'    | 'binding2'    | 'key2'   | [foo: 'bar']
    }

    @Unroll
    def "sendToStreamOperations should throw EventPublisherException when send returns false"() {
        given:
        streamOperations.send(bindingName, binderName, _ as Message) >> false

        when:
        helper.sendToStreamOperations(binderName, bindingName, key, payload)

        then:
        def e = thrown(EventPublisherException)
        e.message.contains('StreamOperations send returned false')

        where:
        binderName   | bindingName   | key      | payload
        'binder1'    | 'binding1'    | 'key1'   | 'payload1'
    }

    @Unroll
    def "sendToStreamOperations should throw EventPublisherException for invalid arguments"() {
        when:
        helper.sendToStreamOperations(binderName, bindingName, key, payload)

        then:
        thrown(IllegalArgumentException)

        where:
        binderName   | bindingName   | key      | payload
        ''           | 'binding1'    | 'key1'   | 'payload1'
        'binder1'    | ''            | 'key1'   | 'payload1'
        'binder1'    | 'binding1'    | ''       | 'payload1'
        'binder1'    | 'binding1'    | 'key1'   | null
    }

    def "sendToStreamOperations should wrap non-EventPublisherException exceptions"() {
        given:
        streamOperations.send(_ as String, _ as String, _) >> { throw new RuntimeException('fail') }

        when:
        helper.sendToStreamOperations('binder', 'binding', 'key', 'payload')

        then:
        def e = thrown(EventPublisherException)
        e.message == 'Failed to send message after retries'
        e.cause instanceof RuntimeException
    }

    def "sendToStreamOperations should propagate EventPublisherException"() {
        given:
        streamOperations.send(_ as String, _ as String, _) >> { throw new EventPublisherException('custom') }

        when:
        helper.sendToStreamOperations('binder', 'binding', 'key', 'payload')

        then:
        def e = thrown(EventPublisherException)
        e.message == 'custom'
    }

    def "getMessage should build Message with correct key and payload"() {
        when:
        def msg = helper.getMessage('myKey', 'myPayload')

        then:
        msg.payload == 'myPayload'
        msg.headers.get('kafka_key') == null
                || msg.headers.get('kafka_key') == 'myKey'
                || msg.headers.get('kafka_headers') == null
        // Accepts any header key for Kafka, as it may be mapped differently
    }

    def "handleException should wrap non-EventPublisherException"() {
        when:
        def ex = helper.handleException('binder', 'binding', 'key', 'payload', new RuntimeException('fail'))

        then:
        ex instanceof EventPublisherException
        ex.cause instanceof RuntimeException
        ex.message == 'Failed to send message after retries'
    }

    def "handleException should propagate EventPublisherException"() {
        given:
        def eventEx = new EventPublisherException('custom')

        when:
        def ex = helper.handleException('binder', 'binding', 'key', 'payload', eventEx)

        then:
        ex.is(eventEx)
    }

    // ====== sendToStreamOperationsWithHeaders Tests ======

    def "sendToStreamOperationsWithHeaders should send message with extra headers successfully"() {
        given:
        def extraHeaders = ["x-idg-sequence": "seq-001", "x-idg-is-retry": "true"]
        streamOperations.send("binding1", "binder1", _ as Message) >> true

        expect:
        helper.sendToStreamOperationsWithHeaders("binder1", "binding1", "key1", "payload1", extraHeaders)
    }

    def "sendToStreamOperationsWithHeaders should send with map payload and headers"() {
        given:
        def extraHeaders = ["x-idg-entity-key": "ACC-123|Test"]
        streamOperations.send("binding2", "binder2", _ as Message) >> true

        expect:
        helper.sendToStreamOperationsWithHeaders("binder2", "binding2", "key2", [foo: 'bar'], extraHeaders)
    }

    def "sendToStreamOperationsWithHeaders should throw EventPublisherException when send returns false"() {
        given:
        def extraHeaders = ["x-idg-sequence": "seq-001"]
        streamOperations.send("binding1", "binder1", _ as Message) >> false

        when:
        helper.sendToStreamOperationsWithHeaders("binder1", "binding1", "key1", "payload1", extraHeaders)

        then:
        def e = thrown(EventPublisherException)
        e.message.contains('StreamOperations send returned false')
    }

    @Unroll
    def "sendToStreamOperationsWithHeaders should throw IllegalArgumentException for invalid arguments [#binderName, #bindingName, #key]"() {
        when:
        helper.sendToStreamOperationsWithHeaders(binderName, bindingName, key, payload, [:])

        then:
        thrown(IllegalArgumentException)

        where:
        binderName | bindingName | key    | payload
        ''         | 'binding1'  | 'key1' | 'payload1'
        'binder1'  | ''          | 'key1' | 'payload1'
        'binder1'  | 'binding1'  | ''     | 'payload1'
        'binder1'  | 'binding1'  | 'key1' | null
    }

    def "sendToStreamOperationsWithHeaders should wrap non-EventPublisherException exceptions"() {
        given:
        streamOperations.send(_ as String, _ as String, _) >> { throw new RuntimeException('headers fail') }

        when:
        helper.sendToStreamOperationsWithHeaders('binder', 'binding', 'key', 'payload', ["h1": "v1"])

        then:
        def e = thrown(EventPublisherException)
        e.message == 'Failed to send message after retries'
        e.cause instanceof RuntimeException
    }

    def "sendToStreamOperationsWithHeaders should propagate EventPublisherException"() {
        given:
        streamOperations.send(_ as String, _ as String, _) >> { throw new EventPublisherException('custom headers') }

        when:
        helper.sendToStreamOperationsWithHeaders('binder', 'binding', 'key', 'payload', ["h1": "v1"])

        then:
        def e = thrown(EventPublisherException)
        e.message == 'custom headers'
    }

    def "sendToStreamOperationsWithHeaders should handle null extraHeaders gracefully"() {
        given:
        streamOperations.send("binding1", "binder1", _ as Message) >> true

        expect:
        helper.sendToStreamOperationsWithHeaders("binder1", "binding1", "key1", "payload1", null)
    }

    def "sendToStreamOperationsWithHeaders should handle empty extraHeaders map"() {
        given:
        streamOperations.send("binding1", "binder1", _ as Message) >> true

        expect:
        helper.sendToStreamOperationsWithHeaders("binder1", "binding1", "key1", "payload1", [:])
    }

    // ====== getMessageWithHeaders Tests ======

    def "getMessageWithHeaders should include extra headers in message"() {
        given:
        def extraHeaders = ["x-idg-sequence": "seq-001", "x-idg-is-retry": "true"]

        when:
        def msg = helper.getMessageWithHeaders('myKey', 'myPayload', extraHeaders)

        then:
        msg.payload == 'myPayload'
        msg.headers.get('x-idg-sequence') == 'seq-001'
        msg.headers.get('x-idg-is-retry') == 'true'
    }

    def "getMessageWithHeaders should handle null extraHeaders without error"() {
        when:
        def msg = helper.getMessageWithHeaders('myKey', 'myPayload', null)

        then:
        msg.payload == 'myPayload'
    }

    def "getMessageWithHeaders should handle empty extraHeaders map"() {
        when:
        def msg = helper.getMessageWithHeaders('myKey', 'myPayload', [:])

        then:
        msg.payload == 'myPayload'
    }
}

