package com.att.idp.idgraph.events.service

import com.att.idp.idgraph.db.cosmos.entity.KafkaEventRecord
import com.att.idp.idgraph.db.cosmos.entity.KafkaEventStatus
import com.att.idp.idgraph.db.cosmos.helper.KafkaEventRecordDBHelper
import com.att.idp.idgraph.events.exception.EventPublisherException
import org.springframework.core.env.Environment
import spock.lang.Specification
import java.util.concurrent.CompletionException

class ResilientEventPublisherTest extends Specification {

    def eventPublisher = Mock(EventPublisher)
    def environment = Mock(Environment)

    def resilientPublisher = new ResilientEventPublisher(
            eventPublisher: eventPublisher,
            environment: environment,
            processedEnvPrefix: "test-env",
            sourceAPI: "test-ms"
    )

    def "sendWithFallback should return true when EventPublisher succeeds"() {
        given:
        String bindingName = "subscriber"
        String publisherName = "AccountActivation"
        String key = "123456"
        String payload = '{"event":"test"}'
        eventPublisher.send(bindingName, key, payload) >> true

        when:
        def result = resilientPublisher.sendWithFallback(bindingName, publisherName, key, payload)

        then:
        result == true
    }

    def "sendWithFallback should throw EventPublisherException when resiliency disabled and Kafka fails"() {
        given:
        String bindingName = "subscriber"
        String publisherName = "AccountActivation"
        String key = "123456"
        String payload = '{"event":"test"}'
        eventPublisher.send(bindingName, key, payload) >> {
            throw new EventPublisherException("All retries exhausted")
        }

        when:
        resilientPublisher.sendWithFallback(bindingName, publisherName, key, payload)

        then:
        def ex = thrown(EventPublisherException)
        ex.message == "All retries exhausted"
    }

    def "sendWithFallback should propagate original EventPublisherException when resiliency disabled"() {
        given:
        String bindingName = "subscriber"
        String publisherName = "AccountActivation"
        String key = "123456"
        String payload = '{"event":"test"}'
        eventPublisher.send(bindingName, key, payload) >> {
            throw new EventPublisherException("Kafka failed")
        }

        when:
        resilientPublisher.sendWithFallback(bindingName, publisherName, key, payload)

        then:
        def ex = thrown(EventPublisherException)
        ex.message == "Kafka failed"
    }

    def "sendWithFallback throws EventPublisherException for null payload when resiliency disabled"() {
        given:
        String bindingName = "subscriber"
        String publisherName = "AccountActivation"
        String key = "123456"
        eventPublisher.send(bindingName, key, null) >> {
            throw new EventPublisherException("Payload null failure")
        }

        when:
        resilientPublisher.sendWithFallback(bindingName, publisherName, key, null)

        then:
        thrown(EventPublisherException)
    }

    def "R6: sendWithFallback should throw EventPublisherException wrapping unexpected RuntimeException when resiliency disabled"() {
        given: "EventPublisher throws an unchecked exception that is NOT an EventPublisherException"
        String bindingName = "subscriber"
        String publisherName = "AccountActivation"
        String key = "999999"
        String payload = '{"event":"unexpected"}'
        eventPublisher.send(bindingName, key, payload) >> {
            throw new NullPointerException("Unexpected NPE in binder")
        }

        when:
        resilientPublisher.sendWithFallback(bindingName, publisherName, key, payload)

        then: "EventPublisherException is thrown wrapping the original cause; Cosmos is never touched"
        def ex = thrown(EventPublisherException)
        ex.cause instanceof NullPointerException
    }

    def "R6: sendWithFallback should throw EventPublisherException wrapping IllegalStateException when resiliency disabled"() {
        given: "EventPublisher throws a RuntimeException and resiliency is disabled"
        String bindingName = "subscriber"
        String publisherName = "AccountActivation"
        String key = "111111"
        String payload = '{"event":"both-down"}'
        eventPublisher.send(bindingName, key, payload) >> {
            throw new IllegalStateException("Binder in bad state")
        }

        when:
        resilientPublisher.sendWithFallback(bindingName, publisherName, key, payload)

        then: "EventPublisherException wraps the original cause; Cosmos is never touched"
        def ex = thrown(EventPublisherException)
        ex.cause instanceof IllegalStateException
    }

    def "sendWithFallbackAsync should complete with true on success"() {
        given:
        String bindingName = "subscriber"
        String publisherName = "AccountActivation"
        String key = "123456"
        String payload = '{"event":"test"}'
        eventPublisher.send(bindingName, key, payload) >> true

        when:
        def future = resilientPublisher.sendWithFallbackAsync(bindingName, publisherName, key, payload)

        then:
        future.get() == true
    }

    def "sendWithFallbackAsync should complete exceptionally when resiliency disabled and Kafka fails"() {
        given:
        String bindingName = "subscriber"
        String publisherName = "AccountActivation"
        String key = "123456"
        String payload = '{"event":"test"}'
        eventPublisher.send(bindingName, key, payload) >> {
            throw new EventPublisherException("Kafka failed")
        }

        when:
        def future = resilientPublisher.sendWithFallbackAsync(bindingName, publisherName, key, payload)
        future.join()  // blocks until done; throws CompletionException wrapping EventPublisherException

        then:
        def ex = thrown(CompletionException)
        ex.cause instanceof EventPublisherException
    }

    def "sendWithFallback unified should set correct timestamp format in KafkaEventRecord"() {
        given:
        String bindingName = "subscriber"
        String publisherName = "Test"
        String key = "123"
        String payload = '{"accountNumber":"ACC-TS"}'
        eventPublisher.send(bindingName, key, payload) >> {
            throw new EventPublisherException("fail")
        }
        environment.getProperty("spring.cloud.stream.bindings.subscriber-out-0.destination", "unknown") >> "topic"

        when:
        unifiedPublisher.sendWithFallback(bindingName, publisherName, key, payload)

        then:
        1 * kafkaEventRecordDBHelper.saveEventRecord({ KafkaEventRecord r ->
            r.accountNumber == "ACC-TS" &&
            r.status == KafkaEventStatus.FAILED
        })
        1 * kafkaEventRecordDBHelper.hasPendingEvents(_, _) >> false
    }

    // ====== Unified KafkaEventRecord Path Tests ======

    def kafkaEventRecordDBHelper = Mock(KafkaEventRecordDBHelper)

    def unifiedPublisher = new ResilientEventPublisher(
            eventPublisher: eventPublisher,
            kafkaEventRecordDBHelper: kafkaEventRecordDBHelper,
            environment: environment,
            processedEnvPrefix: "test-env",
            sourceAPI: "test-ms",
            region: "east",
            useUnifiedEntity: true,
            ttlSeconds: 604800,
            accountFields: ["accountNumber", "billingAccountNumber"]
    )

    def "generateSequenceNumber should produce correct format"() {
        when:
        def seq = unifiedPublisher.generateSequenceNumber("ACC-123|TestEvent")

        then:
        seq ==~ /\d+\.east\.\d{5}/
    }

    def "generateSequenceNumber should increment counter per entity"() {
        when:
        def seq1 = unifiedPublisher.generateSequenceNumber("ACC-AAA|Evt")
        def seq2 = unifiedPublisher.generateSequenceNumber("ACC-AAA|Evt")

        then:
        def counter1 = seq1.split(/\./)[2] as Integer
        def counter2 = seq2.split(/\./)[2] as Integer
        counter2 == counter1 + 1
    }

    def "generateSequenceNumber should have independent counters per entity"() {
        when:
        def seq1 = unifiedPublisher.generateSequenceNumber("X|Evt")
        def seq2 = unifiedPublisher.generateSequenceNumber("Y|Evt")

        then:
        def counter1 = seq1.split(/\./)[2] as Integer
        def counter2 = seq2.split(/\./)[2] as Integer
        counter1 == counter2  // both start at 1
    }

    def "generateIdempotencyKey should be deterministic"() {
        when:
        def key1 = unifiedPublisher.generateIdempotencyKey("binding", "ACC-123|Evt", "seq-001")
        def key2 = unifiedPublisher.generateIdempotencyKey("binding", "ACC-123|Evt", "seq-001")

        then:
        key1 == key2
        key1.length() == 64  // SHA-256 hex length
    }

    def "generateIdempotencyKey should differ for different inputs"() {
        when:
        def key1 = unifiedPublisher.generateIdempotencyKey("binding", "ACC-123|Evt", "seq-001")
        def key2 = unifiedPublisher.generateIdempotencyKey("binding", "ACC-123|Evt", "seq-002")

        then:
        key1 != key2
    }

    def "extractAccountNumberFromPayload should extract accountNumber field"() {
        when:
        def result = unifiedPublisher.extractAccountNumberFromPayload('{"accountNumber":"ACC-999","eventName":"Test"}', "kafka-key")

        then:
        result == "ACC-999"
    }

    def "extractAccountNumberFromPayload should fallback to billingAccountNumber"() {
        when:
        def result = unifiedPublisher.extractAccountNumberFromPayload('{"billingAccountNumber":"BAN-888","eventName":"Test"}', "kafka-key")

        then:
        result == "BAN-888"
    }

    def "extractAccountNumberFromPayload should fallback to Kafka key when field missing"() {
        when:
        def result = unifiedPublisher.extractAccountNumberFromPayload('{"eventName":"Test"}', "kafka-key")

        then:
        result == "kafka-key"
    }

    def "extractAccountNumberFromPayload should return unknown when all fallbacks fail"() {
        when:
        def result = unifiedPublisher.extractAccountNumberFromPayload("", null)

        then:
        result == "unknown"
    }

    def "extractAccountNumberFromPayload should handle invalid JSON gracefully"() {
        when:
        def result = unifiedPublisher.extractAccountNumberFromPayload("not-json", "fallback-key")

        then:
        result == "fallback-key"
    }

    def "sendWithFallback unified should save KafkaEventRecord with accountNumber from payload"() {
        given:
        def payload = '{"accountNumber":"ACC-999","eventName":"Activation"}'
        eventPublisher.send("subscriber", "kafka-key-1", payload) >> {
            throw new EventPublisherException("Kafka down")
        }
        environment.getProperty("spring.cloud.stream.bindings.subscriber-out-0.destination", "unknown") >> "test-topic"

        when:
        def result = unifiedPublisher.sendWithFallback("subscriber", "AccountActivation", "kafka-key-1", payload)

        then:
        result == false
        1 * kafkaEventRecordDBHelper.saveEventRecord({ KafkaEventRecord r ->
            r.accountNumber == "ACC-999" &&
            r.entityKey == "ACC-999|AccountActivation" &&
            r.kafkaPartitionKey == "kafka-key-1" &&
            r.idempotencyKey != null &&
            r.idempotencyKey.length() == 64 &&
            r.bindingName == "subscriber" &&
            r.publisherName == "AccountActivation" &&
            r.topicDestination == "test-topic" &&
            r.sourceAPI == "test-ms" &&
            r.status == KafkaEventStatus.FAILED &&
            r.retryCount == 0 &&
            r.processedRegion == "east" &&
            r.sequenceNumber != null
        })
    }

    def "sendWithFallback unified should use Kafka key as accountNumber when field missing in payload"() {
        given:
        def payload = '{"eventName":"Test"}'
        eventPublisher.send("subscriber", "fallback-key", payload) >> {
            throw new EventPublisherException("Kafka down")
        }
        environment.getProperty("spring.cloud.stream.bindings.subscriber-out-0.destination", "unknown") >> "topic"

        when:
        unifiedPublisher.sendWithFallback("subscriber", "Test", "fallback-key", payload)

        then:
        1 * kafkaEventRecordDBHelper.saveEventRecord({ KafkaEventRecord r ->
            r.accountNumber == "fallback-key" &&
            r.entityKey == "fallback-key|Test" &&
            r.kafkaPartitionKey == "fallback-key"
        })
        1 * kafkaEventRecordDBHelper.hasPendingEvents(_, _) >> false
    }

    def "sendWithFallback with unified entity disabled should throw EventPublisherException when Kafka fails"() {
        given:
        def noResiliencyPublisher = new ResilientEventPublisher(
                eventPublisher: eventPublisher,
                kafkaEventRecordDBHelper: kafkaEventRecordDBHelper,
                environment: environment,
                processedEnvPrefix: "test-env",
                sourceAPI: "test-ms",
                region: "east",
                useUnifiedEntity: false,
                ttlSeconds: 604800,
                accountFields: ["accountNumber"]
        )
        eventPublisher.send("subscriber", "BAN-111", '{"x":"y"}') >> {
            throw new EventPublisherException("fail")
        }

        when:
        noResiliencyPublisher.sendWithFallback("subscriber", "Test", "BAN-111", '{"x":"y"}')

        then:
        thrown(EventPublisherException)
        0 * kafkaEventRecordDBHelper.saveEventRecord(_)
    }

    def "sendWithFallback unified should throw when both Kafka and Cosmos fail"() {
        given:
        eventPublisher.send("subscriber", "BAN-ERR", '{"accountNumber":"ACC-ERR"}') >> {
            throw new EventPublisherException("Kafka fail")
        }
        environment.getProperty(_, _) >> "topic"
        kafkaEventRecordDBHelper.saveEventRecord(_) >> { throw new RuntimeException("Cosmos fail") }

        when:
        unifiedPublisher.sendWithFallback("subscriber", "Test", "BAN-ERR", '{"accountNumber":"ACC-ERR"}')

        then:
        def ex = thrown(EventPublisherException)
        ex.message.contains("Cosmos DB fallback also failed")
        1 * kafkaEventRecordDBHelper.hasPendingEvents(_, _) >> false
    }

    // ====== R1: Per-Account Ordering Circuit Breaker ======

    def "R1: circuit breaker engages when pending events exist \u2014 routes to Cosmos and never calls Kafka"() {
        given: "an account with pending events in Cosmos and a freshly arriving event for it"
        def payload = '{"accountNumber":"ACC-CB-1","eventName":"CloseAccount"}'
        environment.getProperty("spring.cloud.stream.bindings.subscriber-out-0.destination", "unknown") >> "test-topic"
        kafkaEventRecordDBHelper.hasPendingEvents("ACC-CB-1", "subscriber") >> true

        when:
        def result = unifiedPublisher.sendWithFallback("subscriber", "CloseAccount", "kafka-key-cb", payload)

        then: "the new event is parked directly in Cosmos with REP_09 / circuit-breaker reason and Kafka is never touched"
        result == false
        1 * kafkaEventRecordDBHelper.saveEventRecord({ KafkaEventRecord r ->
            r.accountNumber == "ACC-CB-1" &&
            r.entityKey == "ACC-CB-1|CloseAccount" &&
            r.bindingName == "subscriber" &&
            r.publisherName == "CloseAccount" &&
            r.status == KafkaEventStatus.CIRCUIT_OPEN &&
            r.errorMessage != null &&
            r.errorMessage.contains("circuit breaker") &&
            r.errorMessage.contains("ACC-CB-1")
        })
        0 * eventPublisher.send(_, _, _)
    }

    def "R1: circuit breaker does not engage when no pending events \u2014 normal Kafka publish proceeds"() {
        given: "no pending events for this account"
        def payload = '{"accountNumber":"ACC-CB-2","eventName":"Activate"}'
        kafkaEventRecordDBHelper.hasPendingEvents("ACC-CB-2", "subscriber") >> false
        eventPublisher.send("subscriber", "kafka-key-ok", payload) >> true

        when:
        def result = unifiedPublisher.sendWithFallback("subscriber", "Activate", "kafka-key-ok", payload)

        then: "Kafka publish proceeds and Cosmos is not touched"
        result == true
        1 * kafkaEventRecordDBHelper.hasPendingEvents("ACC-CB-2", "subscriber")
        1 * eventPublisher.send("subscriber", "kafka-key-ok", payload) >> true
        0 * kafkaEventRecordDBHelper.saveEventRecord(_)
    }

    def "R1: legacy path (useUnifiedEntity=false) bypasses circuit breaker probe entirely"() {
        given: "a legacy publisher with the unified flag off"
        def legacyPublisher = new ResilientEventPublisher(
                eventPublisher: eventPublisher,
                kafkaEventRecordDBHelper: kafkaEventRecordDBHelper,
                environment: environment,
                processedEnvPrefix: "test-env",
                sourceAPI: "test-ms",
                region: "east",
                useUnifiedEntity: false,
                ttlSeconds: 604800,
                accountFields: ["accountNumber"]
        )
        eventPublisher.send("subscriber", "BAN-LEGACY", '{"accountNumber":"ACC-LEG"}') >> true

        when:
        def result = legacyPublisher.sendWithFallback("subscriber", "Test", "BAN-LEGACY", '{"accountNumber":"ACC-LEG"}')

        then: "hasPendingEvents is never called — legacy adopters do not pay the Cosmos read cost"
        result == true
        0 * kafkaEventRecordDBHelper.hasPendingEvents(_, _)
    }

    // ====== serializePayloadAsJson Tests ======

    def "serializePayloadAsJson should return empty string for null payload"() {
        expect:
        unifiedPublisher.serializePayloadAsJson(null) == ""
    }

    def "serializePayloadAsJson should return string payload as-is"() {
        expect:
        unifiedPublisher.serializePayloadAsJson('{"key":"value"}') == '{"key":"value"}'
    }

    def "serializePayloadAsJson should return plain string payload as-is"() {
        expect:
        unifiedPublisher.serializePayloadAsJson("simple-text") == "simple-text"
    }

    def "serializePayloadAsJson should serialize map payload to JSON"() {
        given:
        def payload = [accountNumber: "ACC-123", eventName: "Test"]

        when:
        def result = unifiedPublisher.serializePayloadAsJson(payload)

        then:
        result.contains("ACC-123")
        result.contains("Test")
    }

    def "serializePayloadAsJson should fallback to toString when Jackson serialization fails"() {
        given: "an object whose getter throws during serialization"
        def payload = new Object() {
            Object getFailing() { throw new RuntimeException("cannot serialize") }
            String toString() { return "fallback-toString-value" }
        }

        when:
        def result = unifiedPublisher.serializePayloadAsJson(payload)

        then:
        result == "fallback-toString-value"
    }

    // ====== sendWithFallback Additional Coverage ======

    def "sendWithFallback should return false when EventPublisher.send returns false"() {
        given:
        eventPublisher.send("subscriber", "key1", '{"event":"test"}') >> false

        when:
        def result = resilientPublisher.sendWithFallback("subscriber", "Test", "key1", '{"event":"test"}')

        then:
        result == false
    }

    def "sendWithFallback should skip circuit breaker when useUnifiedEntity is true but kafkaEventRecordDBHelper is null"() {
        given:
        def noHelperUnifiedPublisher = new ResilientEventPublisher(
                eventPublisher: eventPublisher,
                environment: environment,
                processedEnvPrefix: "test-env",
                sourceAPI: "test-ms",
                region: "east",
                useUnifiedEntity: true,
                kafkaEventRecordDBHelper: null,
                ttlSeconds: 604800,
                accountFields: ["accountNumber"]
        )
        eventPublisher.send("subscriber", "key-null-helper", '{"event":"test"}') >> true

        when:
        def result = noHelperUnifiedPublisher.sendWithFallback("subscriber", "Test", "key-null-helper", '{"event":"test"}')

        then:
        result == true
    }

    def "sendWithFallback should throw EventPublisherException when Kafka fails, useUnifiedEntity true, but helper null"() {
        given:
        def noHelperUnifiedPublisher = new ResilientEventPublisher(
                eventPublisher: eventPublisher,
                environment: environment,
                processedEnvPrefix: "test-env",
                sourceAPI: "test-ms",
                region: "east",
                useUnifiedEntity: true,
                kafkaEventRecordDBHelper: null,
                ttlSeconds: 604800,
                accountFields: ["accountNumber"]
        )
        eventPublisher.send("subscriber", "key-epe", '{"event":"fail"}') >> {
            throw new EventPublisherException("Kafka failed")
        }

        when:
        noHelperUnifiedPublisher.sendWithFallback("subscriber", "Test", "key-epe", '{"event":"fail"}')

        then:
        thrown(EventPublisherException)
    }

    def "sendWithFallback legacy should wrap unexpected RuntimeException in EventPublisherException"() {
        given: "a legacy publisher (resiliency disabled) where send throws a non-EventPublisherException"
        eventPublisher.send("subscriber", "key-legacy-npe", '{"event":"test"}') >> {
            throw new NullPointerException("Unexpected NPE in legacy path")
        }

        when:
        resilientPublisher.sendWithFallback("subscriber", "Test", "key-legacy-npe", '{"event":"test"}')

        then:
        def e = thrown(EventPublisherException)
        e.message.contains("resiliency not enabled")
        e.cause instanceof NullPointerException
    }

    def "sendWithFallback should throw EventPublisherException when unified true, helper null, and unexpected exception"() {
        given:
        def noHelperUnifiedPublisher = new ResilientEventPublisher(
                eventPublisher: eventPublisher,
                environment: environment,
                processedEnvPrefix: "test-env",
                sourceAPI: "test-ms",
                region: "east",
                useUnifiedEntity: true,
                kafkaEventRecordDBHelper: null,
                ttlSeconds: 604800,
                accountFields: ["accountNumber"]
        )
        eventPublisher.send("subscriber", "key-unexpected", '{"event":"fail"}') >> {
            throw new IllegalStateException("Unexpected")
        }

        when:
        noHelperUnifiedPublisher.sendWithFallback("subscriber", "Test", "key-unexpected", '{"event":"fail"}')

        then:
        def e = thrown(EventPublisherException)
        e.message.contains("resiliency not enabled")
    }

    def "R6: sendWithFallback unified should save to Cosmos on unexpected RuntimeException"() {
        given: "EventPublisher throws an unchecked exception that is NOT EventPublisherException"
        eventPublisher.send("subscriber", "key-npe", '{"accountNumber":"ACC-NPE"}') >> {
            throw new NullPointerException("Unexpected NPE in binder")
        }
        environment.getProperty("spring.cloud.stream.bindings.subscriber-out-0.destination", "unknown") >> "test-topic"
        kafkaEventRecordDBHelper.hasPendingEvents(_, _) >> false

        when:
        def result = unifiedPublisher.sendWithFallback("subscriber", "TestEvent", "key-npe", '{"accountNumber":"ACC-NPE"}')

        then: "event is persisted to Cosmos instead of propagating the exception"
        result == false
        1 * kafkaEventRecordDBHelper.saveEventRecord({ KafkaEventRecord r ->
            r.accountNumber == "ACC-NPE" &&
            r.status == KafkaEventStatus.FAILED &&
            r.errorMessage.contains("Unexpected NPE")
        })
    }

    def "R6: sendWithFallback unified should save to Cosmos on IllegalStateException"() {
        given:
        eventPublisher.send("subscriber", "key-ise", '{"accountNumber":"ACC-ISE"}') >> {
            throw new IllegalStateException("Binder in bad state")
        }
        environment.getProperty("spring.cloud.stream.bindings.subscriber-out-0.destination", "unknown") >> "topic"
        kafkaEventRecordDBHelper.hasPendingEvents(_, _) >> false

        when:
        def result = unifiedPublisher.sendWithFallback("subscriber", "TestEvent", "key-ise", '{"accountNumber":"ACC-ISE"}')

        then:
        result == false
        1 * kafkaEventRecordDBHelper.saveEventRecord({ KafkaEventRecord r ->
            r.status == KafkaEventStatus.FAILED &&
            r.errorMessage.contains("Binder in bad state")
        })
    }

    def "sendWithFallback unified circuit breaker should throw when Cosmos save fails"() {
        given: "circuit breaker engages but Cosmos save also fails"
        def payload = '{"accountNumber":"ACC-CB-FAIL"}'
        kafkaEventRecordDBHelper.hasPendingEvents("ACC-CB-FAIL", "subscriber") >> true
        environment.getProperty("spring.cloud.stream.bindings.subscriber-out-0.destination", "unknown") >> "topic"
        kafkaEventRecordDBHelper.saveEventRecord(_) >> { throw new RuntimeException("Cosmos save failed") }

        when:
        unifiedPublisher.sendWithFallback("subscriber", "CloseAccount", "key-cb", payload)

        then:
        def ex = thrown(EventPublisherException)
        ex.message.contains("Cosmos DB fallback also failed")
        0 * eventPublisher.send(_, _, _)
    }

    def "sendWithFallback unified should handle non-String object payload via serializePayloadAsJson"() {
        given: "a Map payload that Jackson can serialize"
        def payload = [accountNumber: "ACC-OBJ", eventName: "ObjectPayload"]
        eventPublisher.send("subscriber", "key-obj", payload) >> {
            throw new EventPublisherException("Kafka down")
        }
        environment.getProperty("spring.cloud.stream.bindings.subscriber-out-0.destination", "unknown") >> "topic"
        kafkaEventRecordDBHelper.hasPendingEvents(_, _) >> false

        when:
        def result = unifiedPublisher.sendWithFallback("subscriber", "ObjTest", "key-obj", payload)

        then:
        result == false
        1 * kafkaEventRecordDBHelper.saveEventRecord({ KafkaEventRecord r ->
            r.accountNumber == "ACC-OBJ" &&
            r.requestPayload.contains("ACC-OBJ")
        })
    }

    def "sendWithFallback unified should handle non-serializable payload via toString fallback"() {
        given: "a payload whose Jackson serialization throws, triggering toString() fallback"
        def payload = new Object() {
            Object getFailing() { throw new RuntimeException("no serialize") }
            String toString() { return '{"accountNumber":"ACC-TOSTR"}' }
        }
        eventPublisher.send("subscriber", "key-ts", payload) >> {
            throw new EventPublisherException("Kafka down")
        }
        environment.getProperty("spring.cloud.stream.bindings.subscriber-out-0.destination", "unknown") >> "topic"
        kafkaEventRecordDBHelper.hasPendingEvents(_, _) >> false

        when:
        def result = unifiedPublisher.sendWithFallback("subscriber", "ToStrTest", "key-ts", payload)

        then:
        result == false
        1 * kafkaEventRecordDBHelper.saveEventRecord({ KafkaEventRecord r ->
            r.requestPayload.contains("ACC-TOSTR") &&
            r.accountNumber == "ACC-TOSTR"
        })
    }

    def "sendWithFallback unified should save processedEnvPrefix and sourceAPI in record"() {
        given:
        def payload = '{"accountNumber":"ACC-META"}'
        eventPublisher.send("subscriber", "key-meta", payload) >> {
            throw new EventPublisherException("fail")
        }
        environment.getProperty("spring.cloud.stream.bindings.subscriber-out-0.destination", "unknown") >> "test-topic"
        kafkaEventRecordDBHelper.hasPendingEvents(_, _) >> false

        when:
        unifiedPublisher.sendWithFallback("subscriber", "MetaTest", "key-meta", payload)

        then:
        1 * kafkaEventRecordDBHelper.saveEventRecord({ KafkaEventRecord r ->
            r.processedEnvPrefix == "test-env" &&
            r.sourceAPI == "test-ms" &&
            r.processedRegion == "east" &&
            r.ttl == 604800
        })
    }

    // ====== sendWithFallbackAsync Additional Tests ======

    def "sendWithFallbackAsync unified should complete with false when Kafka fails and Cosmos saves"() {
        given:
        eventPublisher.send("subscriber", "key-async", '{"accountNumber":"ACC-ASYNC"}') >> {
            throw new EventPublisherException("Kafka down")
        }
        environment.getProperty("spring.cloud.stream.bindings.subscriber-out-0.destination", "unknown") >> "topic"
        kafkaEventRecordDBHelper.hasPendingEvents(_, _) >> false

        when:
        def future = unifiedPublisher.sendWithFallbackAsync("subscriber", "AsyncTest", "key-async", '{"accountNumber":"ACC-ASYNC"}')

        then:
        future.get() == false
    }

    // ====== sendWithFallbackAsyncCallback Tests ======

    def "sendWithFallbackAsyncCallback should call onSuccess callback on successful send"() {
        given:
        eventPublisher.send("subscriber", "key-cb-ok", '{"event":"test"}') >> true
        def successResult = null
        def failureResult = null

        when:
        resilientPublisher.sendWithFallbackAsyncCallback("subscriber", "Test", "key-cb-ok", '{"event":"test"}',
                { result -> successResult = result },
                { error -> failureResult = error })
        Thread.sleep(300)

        then:
        successResult == true
        failureResult == null
    }

    def "sendWithFallbackAsyncCallback should call onFailure callback when send fails and resiliency disabled"() {
        given:
        eventPublisher.send("subscriber", "key-cb-fail", '{"event":"fail"}') >> {
            throw new EventPublisherException("Kafka failed")
        }
        def successResult = null
        def failureResult = null

        when:
        resilientPublisher.sendWithFallbackAsyncCallback("subscriber", "Test", "key-cb-fail", '{"event":"fail"}',
                { result -> successResult = result },
                { error -> failureResult = error })
        Thread.sleep(300)

        then:
        successResult == null
        failureResult != null
    }

    def "sendWithFallbackAsyncCallback unified should call onSuccess with false when Cosmos fallback used"() {
        given:
        eventPublisher.send("subscriber", "key-cb-cos", '{"accountNumber":"ACC-CB-COS"}') >> {
            throw new EventPublisherException("fail")
        }
        environment.getProperty("spring.cloud.stream.bindings.subscriber-out-0.destination", "unknown") >> "topic"
        kafkaEventRecordDBHelper.hasPendingEvents(_, _) >> false
        def successResult = null
        def failureResult = null

        when:
        unifiedPublisher.sendWithFallbackAsyncCallback("subscriber", "Test", "key-cb-cos", '{"accountNumber":"ACC-CB-COS"}',
                { result -> successResult = result },
                { error -> failureResult = error })
        Thread.sleep(300)

        then:
        successResult == false
        failureResult == null
    }

    // ====== saveValidationFailure Tests ======

    def "saveValidationFailure should log warning and return when unified entity disabled"() {
        given:
        def noResiliencyPublisher = new ResilientEventPublisher(
                eventPublisher: eventPublisher,
                environment: environment,
                processedEnvPrefix: "test-env",
                sourceAPI: "test-ms",
                region: "east",
                useUnifiedEntity: false,
                ttlSeconds: 604800,
                accountFields: ["accountNumber"]
        )

        when:
        noResiliencyPublisher.saveValidationFailure("binding", "publisher", '{"x":"y"}', "invalid payload")

        then: "no Cosmos interaction — method returns silently"
        0 * kafkaEventRecordDBHelper.saveEventRecord(_)
    }

    def "saveValidationFailure should log warning and return when kafkaEventRecordDBHelper is null"() {
        given:
        def noHelperPublisher = new ResilientEventPublisher(
                eventPublisher: eventPublisher,
                environment: environment,
                processedEnvPrefix: "test-env",
                sourceAPI: "test-ms",
                region: "east",
                useUnifiedEntity: true,
                kafkaEventRecordDBHelper: null,
                ttlSeconds: 604800,
                accountFields: ["accountNumber"]
        )

        when:
        noHelperPublisher.saveValidationFailure("binding", "publisher", '{"x":"y"}', "invalid payload")

        then: "no Cosmos interaction"
        0 * kafkaEventRecordDBHelper.saveEventRecord(_)
    }

    def "saveValidationFailure should save record with VALIDATION_FAILED status and correct fields"() {
        given:
        environment.getProperty("spring.cloud.stream.bindings.subscriber-out-0.destination", "unknown") >> "test-topic"

        when:
        unifiedPublisher.saveValidationFailure("subscriber", "AccountActivation",
                '{"accountNumber":"ACC-VAL-1"}', "Missing required field")

        then:
        1 * kafkaEventRecordDBHelper.saveEventRecord({ KafkaEventRecord r ->
            r.accountNumber == "ACC-VAL-1" &&
            r.entityKey == "ACC-VAL-1|AccountActivation" &&
            r.bindingName == "subscriber" &&
            r.publisherName == "AccountActivation" &&
            r.sourceAPI == "test-ms" &&
            r.status == KafkaEventStatus.VALIDATION_FAILED &&
            r.errorMessage == "Missing required field" &&
            r.retryCount == 0 &&
            r.kafkaPartitionKey == "UNKNOWN" &&
            r.idempotencyKey != null &&
            r.idempotencyKey.length() == 64 &&
            r.sequenceNumber != null &&
            r.processedRegion == "east" &&
            r.processedEnvPrefix == "test-env" &&
            r.ttl == 604800
        })
    }

    def "saveValidationFailure should not throw when Cosmos save fails"() {
        given:
        environment.getProperty(_, _) >> "topic"
        kafkaEventRecordDBHelper.saveEventRecord(_) >> { throw new RuntimeException("Cosmos down") }

        when:
        unifiedPublisher.saveValidationFailure("subscriber", "Test", '{"accountNumber":"ACC-X"}', "bad payload")

        then:
        notThrown(Exception)
    }

    def "saveValidationFailure should handle null rawPayload"() {
        given:
        environment.getProperty(_, _) >> "topic"

        when:
        unifiedPublisher.saveValidationFailure("subscriber", "Test", null, "null payload error")

        then:
        1 * kafkaEventRecordDBHelper.saveEventRecord({ KafkaEventRecord r ->
            r.requestPayload == "" &&
            r.status == KafkaEventStatus.VALIDATION_FAILED &&
            r.errorMessage == "null payload error"
        })
    }

    def "saveValidationFailure should handle empty rawPayload"() {
        given:
        environment.getProperty(_, _) >> "topic"

        when:
        unifiedPublisher.saveValidationFailure("subscriber", "Test", "", "empty payload error")

        then:
        1 * kafkaEventRecordDBHelper.saveEventRecord({ KafkaEventRecord r ->
            r.requestPayload == "" &&
            r.status == KafkaEventStatus.VALIDATION_FAILED
        })
    }

    def "saveValidationFailure should extract billingAccountNumber when accountNumber missing"() {
        given:
        environment.getProperty(_, _) >> "topic"

        when:
        unifiedPublisher.saveValidationFailure("subscriber", "Test",
                '{"billingAccountNumber":"BAN-VAL-1"}', "validation error")

        then:
        1 * kafkaEventRecordDBHelper.saveEventRecord({ KafkaEventRecord r ->
            r.accountNumber == "BAN-VAL-1" &&
            r.entityKey == "BAN-VAL-1|Test"
        })
    }

    // ====== extractAccountNumberFromPayload Additional Tests ======

    def "extractAccountNumberFromPayload should return unknown for null payload and empty kafkaKey"() {
        expect:
        unifiedPublisher.extractAccountNumberFromPayload(null, "") == "unknown"
    }

    def "extractAccountNumberFromPayload should return kafkaKey for null payload"() {
        expect:
        unifiedPublisher.extractAccountNumberFromPayload(null, "my-key") == "my-key"
    }

    def "extractAccountNumberFromPayload should return unknown for null payload and null kafkaKey"() {
        expect:
        unifiedPublisher.extractAccountNumberFromPayload(null, null) == "unknown"
    }

    def "extractAccountNumberFromPayload should handle null accountFields list"() {
        given:
        def publisherNoFields = new ResilientEventPublisher(
                eventPublisher: eventPublisher,
                environment: environment,
                processedEnvPrefix: "test-env",
                sourceAPI: "test-ms",
                region: "east",
                useUnifiedEntity: true,
                kafkaEventRecordDBHelper: kafkaEventRecordDBHelper,
                ttlSeconds: 604800,
                accountFields: null
        )

        expect:
        publisherNoFields.extractAccountNumberFromPayload('{"accountNumber":"ACC-999"}', "fallback") == "fallback"
    }

    def "extractAccountNumberFromPayload should skip null field values in JSON"() {
        when:
        def result = unifiedPublisher.extractAccountNumberFromPayload(
                '{"accountNumber":null,"billingAccountNumber":"BAN-OK"}', "key")

        then:
        result == "BAN-OK"
    }

    def "extractAccountNumberFromPayload should skip empty string field values"() {
        when:
        def result = unifiedPublisher.extractAccountNumberFromPayload(
                '{"accountNumber":"","billingAccountNumber":"BAN-OK"}', "key")

        then:
        result == "BAN-OK"
    }

    def "extractAccountNumberFromPayload should return kafkaKey when all configured fields are missing"() {
        when:
        def result = unifiedPublisher.extractAccountNumberFromPayload(
                '{"someOtherField":"value"}', "fallback-key")

        then:
        result == "fallback-key"
    }

    def "extractAccountNumberFromPayload should fallback to kafkaKey for empty payloadStr"() {
        expect:
        unifiedPublisher.extractAccountNumberFromPayload("", "fallback-key") == "fallback-key"
    }

    def "extractAccountNumberFromPayload should fallback to kafkaKey for invalid JSON"() {
        when:
        def result = unifiedPublisher.extractAccountNumberFromPayload("not-valid-json{{{", "fallback-key")

        then: "catch block handles the JSON parse exception gracefully"
        result == "fallback-key"
    }

    def "extractAccountNumberFromPayload should handle empty accountFields list"() {
        given:
        def publisherEmptyFields = new ResilientEventPublisher(
                eventPublisher: eventPublisher,
                environment: environment,
                processedEnvPrefix: "test-env",
                sourceAPI: "test-ms",
                region: "east",
                useUnifiedEntity: true,
                kafkaEventRecordDBHelper: kafkaEventRecordDBHelper,
                ttlSeconds: 604800,
                accountFields: []
        )

        expect:
        publisherEmptyFields.extractAccountNumberFromPayload('{"accountNumber":"ACC-999"}', "fallback") == "fallback"
    }

    // ====== generateSequenceNumber Additional Tests ======

    def "generateSequenceNumber should contain region in format"() {
        when:
        def seq = unifiedPublisher.generateSequenceNumber("ACC-REG|Evt")

        then:
        seq.contains(".east.")
    }

    def "generateSequenceNumber should have 5 digit counter with leading zeros"() {
        when:
        def seq = unifiedPublisher.generateSequenceNumber("ACC-ZERO|Evt")

        then:
        def parts = seq.split(/\./)
        parts.length == 3
        parts[2].length() == 5
    }

    // ====== generateIdempotencyKey Additional Tests ======

    def "generateIdempotencyKey should produce valid hex string"() {
        when:
        def key = unifiedPublisher.generateIdempotencyKey("b", "e", "s")

        then:
        key ==~ /^[0-9a-f]{64}$/
    }

    def "generateIdempotencyKey should differ when binding changes"() {
        when:
        def key1 = unifiedPublisher.generateIdempotencyKey("binding-a", "ACC|Evt", "seq-001")
        def key2 = unifiedPublisher.generateIdempotencyKey("binding-b", "ACC|Evt", "seq-001")

        then:
        key1 != key2
    }

    def "generateIdempotencyKey should differ when entityKey changes"() {
        when:
        def key1 = unifiedPublisher.generateIdempotencyKey("binding", "ACC-1|Evt", "seq-001")
        def key2 = unifiedPublisher.generateIdempotencyKey("binding", "ACC-2|Evt", "seq-001")

        then:
        key1 != key2
    }
}
