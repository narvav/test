package com.att.idp.idgraph.events.service

import com.att.idp.idgraph.db.cosmos.entity.KafkaEventRecord
import com.att.idp.idgraph.db.cosmos.entity.KafkaEventStatus
import com.att.idp.idgraph.db.cosmos.helper.KafkaEventRecordDBHelper
import com.att.idp.idgraph.events.model.ConsumerAction
import org.springframework.messaging.MessageHeaders
import spock.lang.Specification

class ResilientEventConsumerTest extends Specification {

    ResilientEventConsumer consumer
    KafkaEventRecordDBHelper kafkaEventRecordDBHelper = Mock()

    def setup() {
        consumer = new ResilientEventConsumer()
        consumer.@kafkaEventRecordDBHelper = kafkaEventRecordDBHelper
        consumer.@region = "east"
    }

    def "should return PROCESS for happy-path message without x-idg-sequence header"() {
        given:
        def headers = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                "kafka_receivedKey": "BAN-123".getBytes()
        ])

        when:
        def action = consumer.evaluate(headers, "BAN-123")

        then:
        action == ConsumerAction.PROCESS
        0 * kafkaEventRecordDBHelper.saveEventRecord(_)
    }

    def "should return PROCESS for message with null x-idg-sequence header"() {
        given:
        def headers = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): null
        ])

        when:
        def action = consumer.evaluate(headers, "BAN-456")

        then:
        action == ConsumerAction.PROCESS
    }

    def "should return PROCESS for message with empty x-idg-sequence header"() {
        given:
        def headers = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): ""
        ])

        when:
        def action = consumer.evaluate(headers, "BAN-789")

        then:
        action == ConsumerAction.PROCESS
    }

    def "should return PROCESS for first-time retried message with valid sequence"() {
        given:
        def headers = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000000.east.00001",
                (ResilientEventConsumer.HEADER_IS_RETRY): "true"
        ])

        when:
        def action = consumer.evaluate(headers, "BAN-NEW")

        then:
        action == ConsumerAction.PROCESS
    }

    def "should return SKIP_DUPLICATE for duplicate retried message"() {
        given:
        def headers = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000000.east.00010",
                (ResilientEventConsumer.HEADER_IS_RETRY): "true"
        ])

        when: "first call processes normally"
        def action1 = consumer.evaluate(headers, "BAN-DUP")

        then:
        action1 == ConsumerAction.PROCESS

        when: "second call with same sequence is duplicate"
        def action2 = consumer.evaluate(headers, "BAN-DUP")

        then:
        action2 == ConsumerAction.SKIP_DUPLICATE
        1 * kafkaEventRecordDBHelper.saveEventRecord(_)
    }

    def "should return SKIP_STALE for retried message with older sequence"() {
        given:
        def newerHeaders = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000002.east.00002",
                (ResilientEventConsumer.HEADER_IS_RETRY): "true"
        ])
        def olderHeaders = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000001.east.00001",
                (ResilientEventConsumer.HEADER_IS_RETRY): "true"
        ])

        when: "process newer message first"
        consumer.evaluate(newerHeaders, "BAN-STALE")

        and: "then receive older message"
        def action = consumer.evaluate(olderHeaders, "BAN-STALE")

        then:
        action == ConsumerAction.SKIP_STALE
        1 * kafkaEventRecordDBHelper.saveEventRecord(_)
    }

    def "should handle byte[] header values correctly"() {
        given:
        def headers = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000000.east.00099".getBytes()
        ])

        when:
        def action = consumer.evaluate(headers, "BAN-BYTES")

        then:
        action == ConsumerAction.PROCESS
    }

    def "should not throw when audit write fails"() {
        given:
        def headers = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000000.east.00050"
        ])
        // Process first to populate dedup store
        consumer.evaluate(headers, "BAN-AUDIT-FAIL")

        kafkaEventRecordDBHelper.saveEventRecord(_) >> { throw new RuntimeException("Cosmos down") }

        when: "duplicate triggers audit write which fails"
        def action = consumer.evaluate(headers, "BAN-AUDIT-FAIL")

        then:
        action == ConsumerAction.SKIP_DUPLICATE
        notThrown(Exception)
    }

    def "should not throw when kafkaEventRecordDBHelper is null"() {
        given:
        def consumerNoHelper = new ResilientEventConsumer()
        consumerNoHelper.@kafkaEventRecordDBHelper = null
        consumerNoHelper.@region = "east"

        def headers = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000000.east.00060"
        ])
        // Process first to populate dedup store
        consumerNoHelper.evaluate(headers, "BAN-NO-HELPER")

        when: "duplicate triggers audit write but helper is null"
        def action = consumerNoHelper.evaluate(headers, "BAN-NO-HELPER")

        then:
        action == ConsumerAction.SKIP_DUPLICATE
        notThrown(Exception)
    }

    def "generateConsumerDedupKey should be deterministic"() {
        when:
        def key1 = consumer.generateConsumerDedupKey("topic-a", "BAN-100", "seq-001")
        def key2 = consumer.generateConsumerDedupKey("topic-a", "BAN-100", "seq-001")

        then:
        key1 == key2
        key1.length() == 64
    }

    def "generateConsumerDedupKey should differ for different inputs"() {
        when:
        def key1 = consumer.generateConsumerDedupKey("topic-a", "BAN-100", "seq-001")
        def key2 = consumer.generateConsumerDedupKey("topic-b", "BAN-100", "seq-001")

        then:
        key1 != key2
    }

    def "should use x-idg-entity-key header over caller-provided entityKey for retried messages"() {
        given:
        def headers = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000000.east.00070",
                (ResilientEventConsumer.HEADER_IS_RETRY): "true",
                (ResilientEventConsumer.HEADER_ENTITY_KEY): "ACC-999|AccountActivation"
        ])

        when: "first call with header entityKey"
        def action1 = consumer.evaluate(headers, "fallback-key")

        then: "processes using header entityKey"
        action1 == ConsumerAction.PROCESS

        when: "second call with same header entityKey is duplicate"
        def action2 = consumer.evaluate(headers, "fallback-key")

        then:
        action2 == ConsumerAction.SKIP_DUPLICATE
    }

    def "should ignore empty x-idg-entity-key header and use caller-provided key"() {
        given:
        def headers = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000000.east.00080",
                (ResilientEventConsumer.HEADER_ENTITY_KEY): ""
        ])

        when:
        def action = consumer.evaluate(headers, "caller-key")

        then:
        action == ConsumerAction.PROCESS
    }

    // ====== generateConsumerDedupKey Additional Tests ======

    def "generateConsumerDedupKey should handle null topic by substituting unknown"() {
        when:
        def key = consumer.generateConsumerDedupKey(null, "BAN-100", "seq-001")

        then:
        key.length() == 64
    }

    def "generateConsumerDedupKey should produce same key for null and explicit unknown topic"() {
        when:
        def key1 = consumer.generateConsumerDedupKey(null, "BAN-100", "seq-001")
        def key2 = consumer.generateConsumerDedupKey("unknown", "BAN-100", "seq-001")

        then: "null topic maps to 'unknown' internally"
        key1 == key2
    }

    def "generateConsumerDedupKey should produce valid hex string"() {
        when:
        def key = consumer.generateConsumerDedupKey("topic", "entity", "seq")

        then:
        key ==~ /^[0-9a-f]{64}$/
    }

    def "generateConsumerDedupKey should differ for different entity keys"() {
        when:
        def key1 = consumer.generateConsumerDedupKey("topic", "BAN-A", "seq-001")
        def key2 = consumer.generateConsumerDedupKey("topic", "BAN-B", "seq-001")

        then:
        key1 != key2
    }

    def "generateConsumerDedupKey should differ for different sequence numbers"() {
        when:
        def key1 = consumer.generateConsumerDedupKey("topic", "BAN-100", "seq-001")
        def key2 = consumer.generateConsumerDedupKey("topic", "BAN-100", "seq-002")

        then:
        key1 != key2
    }

    // ====== evaluate Additional Edge Cases ======

    def "evaluate should handle Integer header value for sequence"() {
        given: "a header value that is neither String nor byte[]"
        def headers = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): 12345
        ])

        when:
        def action = consumer.evaluate(headers, "BAN-INT")

        then: "Integer.toString() is used; message is treated as retried"
        action == ConsumerAction.PROCESS
    }

    def "evaluate should handle x-idg-entity-key as byte array"() {
        given:
        def consumerFresh = new ResilientEventConsumer()
        consumerFresh.@kafkaEventRecordDBHelper = kafkaEventRecordDBHelper
        consumerFresh.@region = "east"
        def headers = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000000.east.00090",
                (ResilientEventConsumer.HEADER_ENTITY_KEY): "ACC-BYTE|Test".getBytes()
        ])

        when: "first call processes"
        def action1 = consumerFresh.evaluate(headers, "fallback-key")

        then:
        action1 == ConsumerAction.PROCESS

        when: "second call with same headers is duplicate"
        def action2 = consumerFresh.evaluate(headers, "fallback-key")

        then:
        action2 == ConsumerAction.SKIP_DUPLICATE
    }

    def "evaluate should track sequences independently per entity"() {
        given:
        def consumerFresh = new ResilientEventConsumer()
        consumerFresh.@kafkaEventRecordDBHelper = kafkaEventRecordDBHelper
        consumerFresh.@region = "east"
        def newerHeaders = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000002.east.00002"
        ])
        def olderHeaders = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000001.east.00001"
        ])

        when: "process newer sequence for entity A"
        consumerFresh.evaluate(newerHeaders, "ENTITY-A")

        and: "process older sequence for different entity B"
        def action = consumerFresh.evaluate(olderHeaders, "ENTITY-B")

        then: "entity B is independent, so older sequence is processed"
        action == ConsumerAction.PROCESS
    }

    def "evaluate should write audit record with DUPLICATE_SKIPPED status and correct fields"() {
        given:
        def consumerFresh = new ResilientEventConsumer()
        consumerFresh.@kafkaEventRecordDBHelper = kafkaEventRecordDBHelper
        consumerFresh.@region = "east"
        def headers = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000000.east.00110"
        ])
        consumerFresh.evaluate(headers, "BAN-AUDIT-DUP")

        when:
        consumerFresh.evaluate(headers, "BAN-AUDIT-DUP")

        then:
        1 * kafkaEventRecordDBHelper.saveEventRecord({ KafkaEventRecord r ->
            r.status == KafkaEventStatus.DUPLICATE_SKIPPED &&
            r.entityKey == "BAN-AUDIT-DUP" &&
            r.sequenceNumber == "1700000000000.east.00110" &&
            r.processedRegion == "east"
        })
    }

    def "evaluate should write audit record with STALE_SKIPPED status and correct fields"() {
        given:
        def consumerFresh = new ResilientEventConsumer()
        consumerFresh.@kafkaEventRecordDBHelper = kafkaEventRecordDBHelper
        consumerFresh.@region = "east"
        def newerHeaders = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000002.east.00002"
        ])
        def olderHeaders = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000001.east.00001"
        ])
        consumerFresh.evaluate(newerHeaders, "BAN-AUDIT-STALE")

        when:
        consumerFresh.evaluate(olderHeaders, "BAN-AUDIT-STALE")

        then:
        1 * kafkaEventRecordDBHelper.saveEventRecord({ KafkaEventRecord r ->
            r.status == KafkaEventStatus.STALE_SKIPPED &&
            r.entityKey == "BAN-AUDIT-STALE" &&
            r.sequenceNumber == "1700000000001.east.00001" &&
            r.processedRegion == "east"
        })
    }

    def "evaluate should process multiple in-order messages for same entity"() {
        given:
        def consumerFresh = new ResilientEventConsumer()
        consumerFresh.@kafkaEventRecordDBHelper = kafkaEventRecordDBHelper
        consumerFresh.@region = "east"
        def headers1 = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000001.east.00001"
        ])
        def headers2 = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000002.east.00002"
        ])
        def headers3 = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000003.east.00003"
        ])

        when:
        def action1 = consumerFresh.evaluate(headers1, "BAN-ORDER")
        def action2 = consumerFresh.evaluate(headers2, "BAN-ORDER")
        def action3 = consumerFresh.evaluate(headers3, "BAN-ORDER")

        then:
        action1 == ConsumerAction.PROCESS
        action2 == ConsumerAction.PROCESS
        action3 == ConsumerAction.PROCESS
        0 * kafkaEventRecordDBHelper.saveEventRecord(_)
    }

    def "evaluate should handle missing kafka_receivedTopic header gracefully"() {
        given:
        def headers = new MessageHeaders([
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000000.east.00120"
        ])

        when:
        def action = consumer.evaluate(headers, "BAN-NO-TOPIC")

        then: "processes without error — null topic is handled in generateConsumerDedupKey"
        action == ConsumerAction.PROCESS
    }

    def "evaluate should return SKIP_STALE for sequence equal to last processed"() {
        given: "a consumer with a known processed sequence"
        def consumerFresh = new ResilientEventConsumer()
        consumerFresh.@kafkaEventRecordDBHelper = kafkaEventRecordDBHelper
        consumerFresh.@region = "east"
        def seq = "1700000000005.east.00005"
        def headers = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): seq
        ])
        // Process first message to set the sequence tracker
        consumerFresh.evaluate(headers, "BAN-EQ-SEQ")

        and: "a different message arrives with same entity but same sequence (different dedup key via different topic)"
        def headers2 = new MessageHeaders([
                "kafka_receivedTopic": "test-topic-2",
                (ResilientEventConsumer.HEADER_SEQUENCE): seq
        ])

        when:
        def action = consumerFresh.evaluate(headers2, "BAN-EQ-SEQ")

        then: "stale because sequence <= last processed"
        action == ConsumerAction.SKIP_STALE
    }

    def "evaluate should handle headers with only x-idg-sequence present"() {
        given:
        def headers = new MessageHeaders([
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000000.east.00130"
        ])

        when:
        def action = consumer.evaluate(headers, "BAN-MINIMAL")

        then:
        action == ConsumerAction.PROCESS
    }

    def "evaluate should handle all custom headers present"() {
        given:
        def headers = new MessageHeaders([
                "kafka_receivedTopic": "test-topic",
                (ResilientEventConsumer.HEADER_SEQUENCE): "1700000000000.east.00140",
                (ResilientEventConsumer.HEADER_IDEMPOTENCY_KEY): "idem-key-123",
                (ResilientEventConsumer.HEADER_IS_RETRY): "true",
                (ResilientEventConsumer.HEADER_ORIGIN_REGION): "east",
                (ResilientEventConsumer.HEADER_ENTITY_KEY): "ACC-ALL|FullTest"
        ])

        when:
        def action = consumer.evaluate(headers, "fallback-key")

        then: "x-idg-entity-key header overrides caller-provided key"
        action == ConsumerAction.PROCESS
    }

    // ====== Constants Verification ======

    def "header constants should have correct values"() {
        expect:
        ResilientEventConsumer.HEADER_SEQUENCE == "x-idg-sequence"
        ResilientEventConsumer.HEADER_IDEMPOTENCY_KEY == "x-idg-idempotency-key"
        ResilientEventConsumer.HEADER_IS_RETRY == "x-idg-is-retry"
        ResilientEventConsumer.HEADER_ORIGIN_REGION == "x-idg-origin-region"
        ResilientEventConsumer.HEADER_ENTITY_KEY == "x-idg-entity-key"
    }
}
