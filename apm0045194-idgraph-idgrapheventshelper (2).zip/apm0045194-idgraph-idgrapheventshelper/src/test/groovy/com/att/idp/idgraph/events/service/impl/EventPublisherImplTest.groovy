package com.att.idp.idgraph.events.service.impl

import com.att.idp.idgraph.events.exception.EventPublisherException
import com.att.idp.idgraph.events.exception.InvalidInputException
import com.att.idp.idgraph.events.exception.MissingConfigurationException
import com.att.idp.idgraph.events.helper.StreamOperationsHelper
import org.springframework.cloud.stream.function.StreamOperations
import org.springframework.core.env.Environment
import spock.lang.Specification

import java.util.concurrent.CompletableFuture
import java.util.concurrent.CompletionException
import java.util.function.Consumer

class EventPublisherImplTest extends Specification {
    def streamOperationsHelper = Mock(StreamOperationsHelper)
    def environment = Mock(Environment)
    def publisher = new EventPublisherImpl(streamOperationsHelper: streamOperationsHelper, environment: environment)

    def setup() {
        String bindingName = "testBinding"
        environment.getProperty("spring.cloud.stream.bindings.${bindingName}-out-0.destination") >> "destination"
        environment.getProperty("spring.cloud.stream.binders.${bindingName}-primary.type") >> "primary"
        environment.getProperty("spring.cloud.stream.binders.${bindingName}-secondary.type") >> "secondary"
    }

    def "send should send message successfully via primary binder"() {
        given:
        String bindingName = "testBinding"
        String internalBindingName = bindingName + "-out-0"
        String key = "testKey"
        String payload = "testPayload"
        streamOperationsHelper.sendToStreamOperations("testBinding-primary", internalBindingName, key, payload) >> true

        expect:
        publisher.send(bindingName, key, payload)
    }

    def "send should fallback to secondary binder on primary failure and succeed"() {
        given:
        String bindingName = "testBinding"
        String internalBindingName = bindingName + "-out-0"
        String key = "testKey"
        String payload = "testPayload"
        streamOperationsHelper.sendToStreamOperations("testBinding-primary", internalBindingName, key, payload) >> { throw new RuntimeException("Primary failed") }
        streamOperationsHelper.sendToStreamOperations("testBinding-secondary", internalBindingName, key, payload) >> true

        expect:
        publisher.send(bindingName, key, payload)
    }

    def "send should throw EventPublisherException if both primary and secondary fail"() {
        given:
        String bindingName = "testBinding"
        String internalBindingName = bindingName + "-out-0"
        String key = "testKey"
        String payload = "testPayload"
        streamOperationsHelper.sendToStreamOperations("testBinding-primary", internalBindingName, key, payload) >> { throw new RuntimeException("Primary failed") }
        streamOperationsHelper.sendToStreamOperations("testBinding-secondary", internalBindingName, key, payload) >> { throw new RuntimeException("Secondary failed") }

        when:
        publisher.send(bindingName, key, payload)

        then:
        def ex = thrown(EventPublisherException)
        ex.message.contains("Failed to send message")
    }

    def "sendAsync should complete successfully when send returns true"() {
        given:
        String bindingName = "testBinding"
        String internalBindingName = bindingName + "-out-0"
        String key = "testKey"
        String payload = "testPayload"
        streamOperationsHelper.sendToStreamOperations("testBinding-primary", internalBindingName, key, payload) >> true

        when:
        CompletableFuture<Boolean> future = publisher.sendAsync(bindingName, key, payload)

        then:
        future.get() == true
    }

    def "sendAsync should throw EventPublisherException when send returns false"() {
        given:
        String bindingName = "testBinding"
        String internalBindingName = bindingName + "-out-0"
        String key = "testKey"
        String payload = "testPayload"
        streamOperationsHelper.sendToStreamOperations("testBinding-primary", internalBindingName, key, payload) >> { throw new EventPublisherException("StreamOperations send returned false") }
        streamOperationsHelper.sendToStreamOperations("testBinding-secondary", internalBindingName, key, payload) >> { throw new EventPublisherException("StreamOperations send returned false") }

        when:
        CompletableFuture<Boolean> future = publisher.sendAsync(bindingName, key, payload)
        future.get()

        then:
        def ex = thrown(Exception)
        ex.cause instanceof EventPublisherException
    }

    def "sendAsync should throw EventPublisherException when send throws exception"() {
        given:
        String bindingName = "testBinding"
        String internalBindingName = bindingName + "-out-0"
        String key = "testKey"
        String payload = "testPayload"
        streamOperationsHelper.sendToStreamOperations("testBinding-primary", internalBindingName, key, payload) >> { throw new RuntimeException("Primary failed") }
        streamOperationsHelper.sendToStreamOperations("testBinding-secondary", internalBindingName, key, payload) >> { throw new RuntimeException("Secondary failed") }

        when:
        CompletableFuture<Boolean> future = publisher.sendAsync(bindingName, key, payload)
        future.get()

        then:
        def ex = thrown(Exception)
        ex.cause instanceof EventPublisherException
    }

    def "sendAsyncWithCallback should call onSuccess on success"() {
        given:
        String bindingName = "testBinding"
        String internalBindingName = bindingName + "-out-0"
        String key = "testKey"
        String payload = "testPayload"
        streamOperationsHelper.sendToStreamOperations("testBinding-primary", internalBindingName, key, payload) >> true
        def onSuccess = Mock(Consumer)
        def onFailure = Mock(Consumer)

        when:
        publisher.sendAsyncWithCallback(bindingName, key, payload, onSuccess, onFailure)
        Thread.sleep(100) // allow async to complete

        then:
        1 * onSuccess.accept(true)
        0 * onFailure.accept(_)
    }

    def "sendAsyncWithCallback should call onFailure if send throws exception"() {
        given:
        String bindingName = "testBinding"
        String internalBindingName = bindingName + "-out-0"
        String key = "testKey"
        String payload = "testPayload"
        streamOperationsHelper.sendToStreamOperations("testBinding-primary", internalBindingName, key, payload) >> { throw new RuntimeException("Primary failed") }
        streamOperationsHelper.sendToStreamOperations("testBinding-secondary", internalBindingName, key, payload) >> { throw new RuntimeException("Secondary failed") }
        def onSuccess = Mock(Consumer)
        def onFailure = Mock(Consumer)

        when:
        publisher.sendAsyncWithCallback(bindingName, key, payload, onSuccess, onFailure)
        Thread.sleep(100) // allow async to complete

        then:
        0 * onSuccess.accept(_)
        1 * onFailure.accept({ it instanceof CompletionException && it.cause instanceof EventPublisherException })
    }

    def "send should handle valid and invalid binding names"() {
        given:
        String key = "testKey"
        String payload = "testPayload"
        String internalBindingName = bindingName + "-out-0"
        streamOperationsHelper.sendToStreamOperations(bindingName + "-primary", internalBindingName, key, payload) >> true

        when:
        def result = null
        def thrownEx = null
        try {
            result = publisher.send(bindingName, key, payload)
        } catch (Exception ex) {
            thrownEx = ex
        }

        then:
        isValid ? result : thrownEx instanceof InvalidInputException

        where:
        bindingName   | isValid
        "testBinding" | true
        null          | false
        ""            | false
    }

    def "send should handle valid and invalid key"() {
        given:
        String bindingName = "testBinding"
        String internalBindingName = bindingName + "-out-0"
        String payload = "testPayload"
        streamOperationsHelper.sendToStreamOperations("testBinding-primary", internalBindingName, key, payload) >> true

        when:
        def result = null
        def thrownEx = null
        try {
            result = publisher.send(bindingName, key, payload)
        } catch (Exception ex) {
            thrownEx = ex
        }

        then:
        isValid ? result : thrownEx instanceof InvalidInputException

        where:
        key       | isValid
        "testKey" | true
        null      | false
        ""        | false
    }

    def "send should handle valid and invalid payload"() {
        given:
        String bindingName = "testBinding"
        String internalBindingName = bindingName + "-out-0"
        String key = "testKey"
        streamOperationsHelper.sendToStreamOperations("testBinding-primary", internalBindingName, key, payload) >> true

        when:
        def result = null
        def thrownEx = null
        try {
            result = publisher.send(bindingName, key, payload)
        } catch (Exception ex) {
            thrownEx = ex
        }

        then:
        isValid ? result : thrownEx instanceof InvalidInputException

        where:
        payload    | isValid
        "testData" | true
        null       | false
    }

    def "send should throw exception for missing destination configuration"() {
        given:
        String bindingName = "testBinding-unconfigured"
        String key = "testKey"
        String payload = "testPayload"
        environment.getProperty("spring.cloud.stream.bindings.${bindingName}-out-0.destination") >> null

        when:
        publisher.send(bindingName, key, payload)

        then:
        def ex = thrown(MissingConfigurationException)
        ex.message.contains("Destination must be configured for binding: testBinding-unconfigured")
    }

    def "send should throw exception for missing primary binding configuration"() {
        given:
        String bindingName = "testBinding-primary-binder-missing"
        String key = "testKey"
        String payload = "testPayload"
        environment.getProperty("spring.cloud.stream.bindings.${bindingName}-out-0.destination") >> "destination"
        environment.getProperty("spring.cloud.stream.binders.${bindingName}-primary.type") >> null

        when:
        publisher.send(bindingName, key, payload)

        then:
        def ex = thrown(MissingConfigurationException)
        ex.message.contains("Primary binder type must be configured for binder: testBinding-primary-binder-missing-primary")
    }

    def "send should throw exception when primary fails and no secondary configured"() {
        given:
        String bindingName = "testBinding-primary-binder-failed"
        String key = "testKey"
        String payload = "testPayload"
        environment.getProperty("spring.cloud.stream.bindings.${bindingName}-out-0.destination") >> "destination"
        environment.getProperty("spring.cloud.stream.binders.${bindingName}-primary.type") >> "primary"
        streamOperationsHelper.sendToStreamOperations("${bindingName}-primary", "${bindingName}-out-0", key, payload) >> { throw new RuntimeException("Primary failed") }

        when:
        publisher.send(bindingName, key, payload)

        then:
        def ex = thrown(EventPublisherException)
        ex.message.contains("Failed to send message")
    }
}
