# AGENTS.md — IDGraphAcctEventsMs

> AI agent onboarding guide for `apm0045194-idgraph-idgraphaccteventsms`.

---

## Build Commands

```bash
# Compile (skip tests)
mvn clean package -DskipTests

# Unit tests (default profile — Spock + JUnit)
mvn clean test

# Integration tests only
mvn clean verify -P integration-test

# Full build with coverage
mvn clean install

# Coverage report location
# target/site/jacoco/index.html

# Vulnerability scan
mvn dependency-check:check -DfailBuildOnCVSS=7
```

---

## Key File Paths

| Category | Path | Description |
|---|---|---|
| **Source Root** | `src/main/java/com/att/idp/idgraphaccteventsms/` | Main application code |
| **Entry Point** | `src/main/java/com/att/idp/idgraphaccteventsms/Application.java` | Spring Boot main class |
| **Config (Spring)** | `src/main/java/com/att/idp/idgraphaccteventsms/config/` | Solace JMS, Jersey, shutdown configs |
| **Config (Azure App)** | `src/main/java/com/att/idp/idgraphaccteventsms/appconfig/config/` | Azure App Config, scheduler |
| **JMS Consumers** | `src/main/java/com/att/idp/idgraphaccteventsms/service/` | 5 JMS consumers + base class + user service |
| **Kafka Publishers** | `src/main/java/com/att/idp/idgraphaccteventsms/service/` | `GenericNotificationPublisher` via `NotificationPublisher` interface |
| **Helpers** | `src/main/java/com/att/idp/idgraphaccteventsms/helper/` | `MessageParserHelper` (XML→JSON) |
| **Models** | `src/main/java/com/att/idp/idgraphaccteventsms/model/` | Domain POJOs (account, subscriber, product, rg, platformhandler, common) |
| **REST Resources** | `src/main/java/com/att/idp/idgraphaccteventsms/resource/` | JAX-RS interface + impl (User API) |
| **Runtime Config** | `opt/ajsc/etc/config/application.properties` | Primary runtime configuration |
| **Secrets Loader** | `idpsecretsloader.yaml` | Azure Key Vault secret definitions |
| **Test (Spock)** | `src/test/groovy/com/att/idp/idgraphaccteventsms/` | Spock BDD specs |
| **Test (JUnit)** | `src/test/java/com/att/idp/` | JUnit tests (unit, component, integration) |
| **Test Resources** | `src/test/resources/` | `application-test.properties`, `testmessages.properties` |
| **IST Tests** | `src/test/ist/cadevtest/IDGraphAcctEventsMs/` | Integration service tests (LISA) |
| **Docker** | `src/main/docker/Dockerfile` | Container image definition |
| **Jenkins** | `Jenkinsfile` | CI/CD pipeline (`idp-shared-library@release/3.0.1`) |
| **Execution Plans** | `docs/{TICKET-ID}/` | Per-ticket execution plans |
| **Logback** | `opt/ajsc/etc/config/logback.xml`, `opt/ajsc/etc/config/logback/baselogback.xml` | Logging configuration |

---

## Coding Conventions

### Language & Framework
- **Java 17** with `maven.compiler.release=17`
- **Spring Boot 3.x** via `sdk-java-parent:3.0.1`
- **JAX-RS (Jersey)** — interface + implementation split pattern
- **Groovy 3.0** for Spock test specs

### Hard-Stops (Non-Negotiable)

- **No `@Autowired` on fields** — constructor injection only (`@RequiredArgsConstructor` + `private final`)
- **No hardcoded secrets** — use Azure Key Vault (`${idp-secrets-v1:secret-name}`)
- **No PII/SPI in logs** — sanitize via ESAPI (`ESAPI.encoder().encodeForHTML()`)
- **No `System.out.println`** — use SLF4J structured logging
- **No empty catch blocks** — every `catch` must log and handle
- **No hardcoded strings/numbers** — centralize in `*Constants.java` or `application.properties`
- **No removing existing code without approval** — default is ADD, not REPLACE
- **No wildcard imports** — all imports must be explicit
- **Use `CommonErrorMap` + `CErrorDefs`** for error responses
- **Reuse shared helpers** (`idgrapheventshelper`, `idgraphcommonhelper`, etc.) before creating new code
- **`0 * _` mandatory** in every Spock `then:` block

### Naming Conventions

| Element | Convention |
|---|---|
| **Packages** | `com.att.idp.idgraphaccteventsms.{layer}` |
| **Constants** | `UPPER_SNAKE_CASE` in `*Constants.java` |
| **JMS Consumers** | `Jms{Domain}NotificationConsumer extends AbstractJmsNotificationConsumer` |
| **Kafka Publishers** | `{domain}NotificationPublisher` bean name |
| **Spock Tests** | `{ClassName}Spec.groovy` in `src/test/groovy/` |
| **Feature Flags** | `svc-idgraph-accteventsms-{feature-name}-enabled` |

### Layered Architecture

```
Resource → Validator → Service → Helper → DB / Integration / Event Publisher
```

---

## Domain-Specific Patterns

### JMS Consumer Pattern
All JMS consumers extend `AbstractJmsNotificationConsumer`:
1. `@PostConstruct` creates JMS Connection/Session/Queue/Consumer with `onMessage` listener
2. `MessageParserHelper.parseMessage()` converts XML → JSON
3. Subclass `processMessage(String jsonString)` routes by `eventName`
4. Publishes via `NotificationPublisher.sendToPrimary()`
5. `@PreDestroy` cleanup

### Kafka Dual-Cluster Failover
`GenericNotificationPublisher` implements automatic failover:
- `sendToPrimary()` → on failure → `recover()` → `sendToSecondary()`
- If both fail → throws `SecondaryProducerException`
- 5 publisher beans: account, subscriber, product, rgactivation, pfhandler

### Adding a New Consumer
1. Create model POJOs under `model/{newdomain}/`
2. Extend `AbstractJmsNotificationConsumer` as `@Service`
3. Implement `processMessage(String jsonString)`
4. Register `NotificationPublisher` bean in `KafkaProducerUnifiedConfig`
5. Add Kafka properties (`idgraph.kafka.producer.<name>-primary/secondary`)
6. Add Solace queue name property
7. Write Spock specs

---

## Integration Points

| Dependency | Protocol | Direction | Config Key |
|---|---|---|---|
| **Solace JMS (primary)** | JMS/JNDI | Inbound | `solace.jms.*` |
| **Solace JMS (PF Handler)** | JMS/JNDI | Inbound | `platform.handler.*` |
| **Azure Event Hub (primary)** | Kafka SASL_SSL | Outbound | `idgraph.kafka.producer.<key>-primary.*` |
| **Azure Event Hub (secondary)** | Kafka SASL_SSL | Outbound | `idgraph.kafka.producer.<key>-secondary.*` |
| **Azure Key Vault** | Secret API | Config | `idpsecretsloader.yaml` |
| **Azure App Configuration** | HTTP | Config | `IDGraphAzureAppConfig` |
| **idgrapheventshelper** | Library | Compile | `pom.xml` (v4.0.2) |

### Kafka Topics (configured per environment)

| Domain | Config Prefix |
|---|---|
| Account | `idgraph.kafka.producer.account-primary/secondary` |
| Subscriber | `idgraph.kafka.producer.subscriber-primary/secondary` |
| Product | `idgraph.kafka.producer.product-primary/secondary` |
| RG Activation | `idgraph.kafka.producer.rgactivation-primary/secondary` |
| Platform Handler | `idgraph.kafka.producer.pfhandler-primary/secondary` |

### Solace Queues

| Queue Property | Consumer |
|---|---|
| `solace.jms.acct.queue-name` | `JmsAccountNotificationConsumer` |
| `solace.jms.subr.queue-name` | `JmsSubscriberNotificationConsumer` |
| `solace.jms.prodhbo.queue-name` | `JmsProductNotificationConsumer` |
| `solace.jms.rgactn.queue-name` | `JmsRgActivationNotificationConsumer` |
| `platform.handler.queue.name` | `JmsPlatformHandlerNotificationConsumer` |

---

## Testing

### Framework
- **Spock 2.3-groovy-3.0** for BDD-style unit tests (`src/test/groovy/`)
- **JUnit** for additional unit/integration tests (`src/test/java/`)
- **Spring Kafka Test** for embedded Kafka in integration tests

### Test Coverage Commands

```bash
# Run unit tests with coverage
mvn clean test
# Report: target/site/jacoco/index.html

# Run integration tests
mvn clean verify -P integration-test
```

### Minimum Coverage
- **80%** for new code (enforced by JaCoCo)
- Coverage exclusions: `Application`, `config/*`, `exception/*`, `message/*`, `model/*`, `utils/*`, `kafka/*`

### Spock Rules
- **`0 * _`** mandatory in every `then:` block
- Use **concrete types** — never use `def` for variable declarations
- Use `@Unroll` with `#scenarioName` for parameterized tests
- Include negative/error-path coverage for validations

### Test Data
- Test properties: `src/test/resources/application-test.properties`
- Test messages: `src/test/resources/testmessages.properties`

### Key Spock Specs

| Spec | Coverage |
|---|---|
| `JmsAcctNotificationServiceSpec` | Account event routing (Activate, Close, Update) |
| `JmsConsumerServiceSpec` | Base consumer message handling |
| `JmsPlatformHandlerNotificationConsumerSpec` | Platform handler validation |
| `JmsProdNotificationServiceSpec` | Product HBOCG gate logic |
| `JmsRgActivationNotificationConsumerSpec` | RG activation processing |
| `MessageParserHelperSpec` | XML to JSON parsing |
