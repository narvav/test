---
title: IDGraphAcctEventsMs
version: 4.0.0
last_updated: 2026-05-01
author: IDGraph Platform Team
---

# IDGraphAcctEventsMs — Solace-to-Kafka Account Events Bridge

| Field | Value |
|---|---|
| **Domain / Team** | `IDGraph Platform` |
| **Artifact ID** | `IDGraphAcctEventsMs` |
| **Version** | `0.0.1-SNAPSHOT` |
| **Component Type** | `REST + Kafka Processor` |
| **Runtime / Parent** | `sdk-java-parent:3.0.1` |
| **Language / Java Version** | `Java 17` |
| **Base Path / Entry Point** | `/msapi/idgraphaccteventsms/v1` |
| **API / Contract Docs** | `Swagger UI: /msapi/apm0045194-IDGraphAcctEventsMs/swagger/index.html` |

## Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Project Structure](#project-structure)
4. [Domain Capability Map](#domain-capability-map)
5. [Integration Context](#integration-context)
6. [Process Flows](#process-flows)
7. [Interfaces & Endpoints](#interfaces--endpoints)
8. [Data Stores & State Management](#data-stores--state-management)
9. [Configuration](#configuration)
10. [Dependencies](#dependencies)
11. [Observability and Operations](#observability-and-operations)
12. [Security and Compliance](#security-and-compliance)
13. [Build and Test](#build-and-test)
14. [Deployment](#deployment)
15. [Change Log / History](#change-log--history)

---

## Overview

**IDGraphAcctEventsMs** is a Spring Boot microservice in the
IDGraph platform that bridges Solace JMS queues and Apache
Kafka topics. It consumes XML lifecycle notifications from
five Solace queues, converts them to JSON, routes by event
type, transforms into lean Kafka event objects, and publishes
to dual-cluster Kafka (primary + failover secondary).

| Attribute | Value |
|---|---|
| **Group ID** | `com.att.idp` |
| **Artifact ID** | `IDGraphAcctEventsMs` |
| **Parent POM** | `sdk-java-parent:3.0.1` |
| **Java** | 17 |
| **Framework** | Spring Boot 3.x, JAX-RS (Jersey) |
| **Namespace** | `com-att-idp-idgraph` |

**Key capabilities:**

- **Five JMS consumers** on dedicated Solace queues
  (Account, Subscriber, Product, RG Activation,
  Platform Handler)
- **Dual-cluster Kafka publishing** with automatic
  failover per notification domain
- **XML-to-JSON parsing** via Jackson `XmlMapper`
- **Spring Cache** for user-data lookups
- **Async processing** (`@EnableAsync`)
- **Graceful shutdown** via IDP Shutdown Library
  with Jersey request-counting filters
- **OpenAPI/Swagger** auto-generated at compile time
- **OWASP ESAPI** encoding in all log statements

---

## Architecture

```mermaid
flowchart LR
    subgraph Solace["Solace JMS Brokers"]
        Q1["Account Queue"]
        Q2["Subscriber Queue"]
        Q3["Product Queue"]
        Q4["RG Activation Queue"]
        Q5["Platform Handler Queue"]
    end

    subgraph MS["IDGraphAcctEventsMs"]
        direction TB
        ABS["AbstractJmsNotificationConsumer"]
        MPH["MessageParserHelper<br/>XML to JSON"]
        C1["JmsAccountNotificationConsumer"]
        C2["JmsSubscriberNotificationConsumer"]
        C3["JmsProductNotificationConsumer"]
        C4["JmsRgActivationNotificationConsumer"]
        C5["JmsPlatformHandlerNotificationConsumer"]
        GNP["GenericNotificationPublisher<br/>Primary + Secondary KafkaTemplate"]
    end

    subgraph Kafka["Azure Event Hubs / Kafka"]
        PK["Primary Cluster"]
        SK["Secondary Cluster<br/>failover"]
    end

    subgraph REST["REST Layer"]
        JC["JerseyConfiguration<br/>/idgraphaccteventsms/v1"]
        UR["UserResourceImpl"]
    end

    Q1 --> C1
    Q2 --> C2
    Q3 --> C3
    Q4 --> C4
    Q5 --> C5
    C1 --> GNP
    C2 --> GNP
    C3 --> GNP
    C4 --> GNP
    C5 --> GNP
    GNP --> PK
    GNP -.->|failover| SK
```

---

## Process Flows

### High-Level Data Flow

```mermaid
sequenceDiagram
    participant SQ as "Solace Queue"
    participant JMS as "JMS Consumer"
    participant MP as "MessageParserHelper"
    participant Route as "Event Router"
    participant KP as "GenericNotificationPublisher"
    participant PK as "Primary Kafka"
    participant SK as "Secondary Kafka"

    SQ->>JMS: XML notification
    JMS->>MP: parseMessage(xml)
    MP-->>JMS: JSON string
    JMS->>Route: processMessage(json)
    Route->>Route: Deserialize and route by eventName
    Route->>KP: sendToPrimary(eventJson)
    KP->>PK: KafkaTemplate.send(primaryTopic)
    alt Primary fails
        KP->>SK: sendToSecondary(eventJson)
    end
```

### Account Notification Flow

- **Consumer:** `JmsAccountNotificationConsumer`
- **Queue:** `solace.jms.acct.queue-name`
- **Publisher:** `accountNotificationPublisher`

```mermaid
flowchart TD
    A["XML from Solace account queue"]
    B["AbstractJmsNotificationConsumer.onMessage"]
    C["MessageParserHelper.parseMessage"]
    D["JmsAccountNotificationConsumer.processMessage"]
    E["Deserialize to AccountNotificationMessage"]
    F{"eventName?"}
    G["AccountActivationEvent"]
    H["AccountCloseEvent"]
    I["AccountUpdateEvent"]
    J["Serialize to JSON"]
    K["sendToPrimary"]
    A --> B --> C --> D --> E --> F
    F -->|ActivateAccount| G --> J
    F -->|CloseAccount| H --> J
    F -->|UpdateAccount| I --> J
    J --> K
```

| Event Name | Output Model | Key Fields |
|---|---|---|
| `ActivateAccount` | `AccountActivationEvent` | `billingAccountNumber`, `sorId` ("13"), `serviceName` ("MOBILITY"), `firstName`, `lastName`, `contactEmail`, `tlgMessageId`, `eventId`, `eventTime` |
| `CloseAccount` | `AccountCloseEvent` | `billingAccountNumber`, `tlgMessageId`, `eventId`, `eventTime` |
| `UpdateAccount` | `AccountUpdateEvent` | `mobilityBan`, `titanBan`, `tlgMessageId`, `eventId`, `eventTime` |

### Subscriber Notification Flow

- **Consumer:** `JmsSubscriberNotificationConsumer`
- **Queue:** `solace.jms.subr.queue-name`
- **Publisher:** `subscriberNotificationPublisher`
- **Events:** `ChangeData`, `CancelSubscriber`,
  `SuspendSubscriber`, `RestoreSubscriber`

Status mapping for Cancel/Suspend/Restore:

| Raw Status | Mapped Status |
|---|---|
| `C` | `Terminated` |
| `S` | `Suspended` |
| `A` | `Active` |

| Output Model | Key Fields |
|---|---|
| `ChangeData` | `eventName`, `subId`, `subscriberNumber`, `billingAccountNumber`, `subscriberStatus`, `tlgMessageId`, `eventId`, `eventTime` |

### Product Notification Flow

- **Consumer:** `JmsProductNotificationConsumer`
- **Queue:** `solace.jms.prodhbo.queue-name`
- **Publisher:** `productNotificationPublisher`

Processing is gated by **two conditions**:

1. `billingAccountNumber` must be present and non-empty
2. At least one `AdditionalOffering` must have a
   `ProductAttribute` named `HBOCG` with value `Y`

| Output Model | Key Fields |
|---|---|
| `ChangeProduct` | `eventName`, `billingAccountNumber`, `sorId` ("13"), `serviceName` ("MOBILITY"), `isConnectedCar` ("Y"), `firstName`, `lastName`, `contactEmail`, `tlgMessageId`, `eventId`, `eventTime` |

### RG Activation Notification Flow

- **Consumer:** `JmsRgActivationNotificationConsumer`
- **Queue:** `solace.jms.rgactn.queue-name`
- **Publisher:** `rgActivationNotificationPublisher`

All messages are processed unconditionally.

| Output Model | Key Fields |
|---|---|
| `RgActivationEvent` | `eventName`, `accountNumber`, `serialNumber`, `tlgMessageId`, `eventId`, `eventTime` |

### Platform Handler Notification Flow

- **Consumer:** `JmsPlatformHandlerNotificationConsumer`
- **Queue:** `platform.handler.queue.name`
- **Connection:** Separate `solacePFHandlerConnectionFactory`
  via `SolacePlatformHandlerJmsConfig`
- **Publisher:** `platformHandlerNotificationPublisher`

Processing requires both `foundationAccountNumber` and
`billingAccountNumber` to be non-null.

| Output Model | Key Fields |
|---|---|
| `PlatformHandlerEvent` | `foundationAccountNumber`, `billingAccountNumber`, `platformHandler`, `eventId`, `eventTime` |

### Kafka Dual-Cluster Failover

Each domain has a primary and secondary Kafka producer
pair in `KafkaProducerUnifiedConfig`.
`GenericNotificationPublisher` handles failover:

```mermaid
flowchart TD
    A["sendToPrimary"]
    B{"Primary succeeds?"}
    C["Log success with offset/partition"]
    D["recover: sendToSecondary"]
    E{"Secondary succeeds?"}
    F["Log success on secondary"]
    G["throw SecondaryProducerException"]
    A --> B
    B -->|Yes| C
    B -->|No| D --> E
    E -->|Yes| F
    E -->|No| G
```

| Publisher Bean | Primary Key | Secondary Key |
|---|---|---|
| `accountNotificationPublisher` | `account-primary` | `account-secondary` |
| `subscriberNotificationPublisher` | `subscriber-primary` | `subscriber-secondary` |
| `productNotificationPublisher` | `product-primary` | `product-secondary` |
| `rgActivationNotificationPublisher` | `rgactivation-primary` | `rgactivation-secondary` |
| `platformHandlerNotificationPublisher` | `pfhandler-primary` | `pfhandler-secondary` |

Producer defaults: **3 retries**, **3000 ms retry backoff**,
`max.block.ms` = `2000`. Auth: **SASL/PLAIN** with Azure
Event Hub connection strings.

---

## Interfaces & Endpoints

### Inputs — Solace JMS Queues / Outputs — Kafka Topics

#### Inbound — Solace JMS Queues

| Queue Property | Consumer | Format | Connection Bean |
|---|---|---|---|
| `solace.jms.acct.queue-name` | `JmsAccountNotificationConsumer` | XML | `solaceConnectionFactory` |
| `solace.jms.subr.queue-name` | `JmsSubscriberNotificationConsumer` | XML | `solaceConnectionFactory` |
| `solace.jms.prodhbo.queue-name` | `JmsProductNotificationConsumer` | XML | `solaceConnectionFactory` |
| `solace.jms.rgactn.queue-name` | `JmsRgActivationNotificationConsumer` | XML | `solaceConnectionFactory` |
| `platform.handler.queue.name` | `JmsPlatformHandlerNotificationConsumer` | XML | `solacePFHandlerConnectionFactory` |

`MessageParserHelper` converts XML to JSON via Jackson
`XmlMapper` before `processMessage()`.

#### Outbound — Kafka Topics

Topic names configured via
`idgraph.kafka.producer.<key>.topic`.

| Domain | Output Events | Config Prefix |
|---|---|---|
| Account | `AccountActivationEvent`, `AccountCloseEvent`, `AccountUpdateEvent` | `idgraph.kafka.producer.account-*` |
| Subscriber | `ChangeData` | `idgraph.kafka.producer.subscriber-*` |
| Product | `ChangeProduct` | `idgraph.kafka.producer.product-*` |
| RG Activation | `RgActivationEvent` | `idgraph.kafka.producer.rgactivation-*` |
| Platform Handler | `PlatformHandlerEvent` | `idgraph.kafka.producer.pfhandler-*` |

---

### REST Endpoints

**Base path:** `/msapi/idgraphaccteventsms/v1/users`

| Method | Path | Description | Response |
|---|---|---|---|
| `GET` | `/users/{userId}` | Retrieve user by ID | `200` with `Resource<User>` + HATEOAS self link |
| `POST` | `/users` | Create user (auto-generates ID) | `201` with location header |
| `GET` | `/users/string/{userId}` | Get user as raw JSON | `200` with `Resource<String>` + HATEOAS self link |

| Code | Error Key | Description |
|---|---|---|
| `400` | `ERROR_VALIDATION_FAILED` | Missing required fields |
| `404` | `ERROR_USER_NOT_FOUND` | User ID not found |
| `409` | `ERROR_DUPLICATE_USER` | Duplicate user ID |

**Swagger UI:**
`/msapi/apm0045194-IDGraphAcctEventsMs/swagger/index.html`

---

### Schema Definitions

### AccountNotificationMessage (Input)

| Field Path | Type | Description |
|---|---|---|
| `messageHeader.trackingMessageHeader.messageId` | String | Correlation ID |
| `messageHeader.trackingMessageHeader.dateTimeStamp` | String | Event timestamp |
| `accountNotification.eventName` | String | `ActivateAccount`, `CloseAccount`, `UpdateAccount` |
| `accountNotification.account.billingAccountNumber` | String | Billing account number |
| `accountNotification.account.customer.name.firstName` | String | First name |
| `accountNotification.account.customer.name.lastName` | String | Last name |
| `accountNotification.account.customer.email.emailAddress` | String | Email |
| `accountNotification.account.titan.titanBan` | String | Titan BAN (UpdateAccount) |

### SubscriberNotificationEvent (Input)

| Field Path | Type | Description |
|---|---|---|
| `subscriberNotification.eventName` | String | `ChangeData`, `CancelSubscriber`, `SuspendSubscriber`, `RestoreSubscriber` |
| `subscriberNotification.subscriber.subId` | String | Subscriber ID |
| `subscriberNotification.subscriber.subscriberNumber` | String | Phone number |
| `subscriberNotification.subscriber.subscriberStatus` | String | Status code (`C`, `S`, `A`) |
| `subscriberNotification.account.billingAccountNumber` | String | Billing account number |

### ProductNotificationEvent (Input)

| Field Path | Type | Description |
|---|---|---|
| `productNotification.eventName` | String | Product event name |
| `productNotification.account.billingAccountNumber` | String | Billing account number |
| `productNotification.product.additionalOfferings[].valueAddedParameters.productAttributes[]` | List | Must contain `HBOCG=Y` |
| `productNotification.subscriber.contactName.firstName` | String | First name |
| `productNotification.subscriber.contactName.lastName` | String | Last name |

### RGActivationNotification (Input)

| Field Path | Type | Description |
|---|---|---|
| `rgActivationNotification.eventName` | String | Event name |
| `rgActivationNotification.accountNumber` | String | Account number |
| `rgActivationNotification.serialNumber` | String | Device serial |

### Change — Platform Handler (Input)

| Field Path | Type | Description |
|---|---|---|
| `upsert.entity.upsert.foundationAccountNumber` | String | Foundation account |
| `upsert.entity.upsert.billingAccountNumber` | String | Billing account |
| `upsert.entity.upsert.platformHandler` | String | Handler ID |
| `header.transactionID` | String | Transaction ID |
| `header.txnReceivedTS` | String | Received timestamp |

### User (REST Model)

| Field | Type | Description |
|---|---|---|
| `id` | String | UUID (auto-generated if empty) |
| `name` | String | Display name (required) |

---

## Data Stores & State Management

| Store / State | Type | Purpose | Access Pattern | Notes |
|---|---|---|---|---|
| In-memory `ConcurrentHashMap` | Cache | User repository for REST API | `UserRepositoryImpl` | Not persisted; demo/placeholder store |
| Spring Cache (`@Cacheable`) | Cache | User data lookup caching | `UserServiceImpl.getUser()` / `createUser()` | Cache name: `IDGraphAcctEventsMs.com.att.idp.default.users` |

> **Note**: This service has no persistent database. It is an event bridge that transforms and forwards messages. State is transient.

---

## Configuration

### Solace JMS Properties

| Property | Description | Source |
|---|---|---|
| `solace.jms.initial-context-factory` | JNDI context factory | Helm values |
| `solace.jms.provider-url` | Solace broker URL | Helm values |
| `solace.jms.username` | Solace user | Key Vault (`idgraph-solace-jms-username`) |
| `solace.jms.password` | Solace password | Key Vault (`idgraph-solace-jms-password`) |
| `solace.jms.vpn` | Solace VPN name | Helm values |
| `solace.jms.cf-jndi-name` | Connection factory JNDI | Helm values |
| `solace.jms.compression-level` | Compression level | Helm values |
| `solace.jms.optimize-direct` | Optimize direct flag | Helm values |
| `platform.handler.*` | Separate Solace config for PF Handler | Helm values + Key Vault |

### Kafka Producer Properties

Per-producer config under
`idgraph.kafka.producer.<key>.*`:

| Property | Description | Default |
|---|---|---|
| `topic` | Kafka topic name | — |
| `bootstrap-servers` | Broker endpoints | — |
| `client-id` | Producer client ID | — |
| `jaas-endpoint` | Azure Event Hub endpoint | — |
| `jaas-sharedaccesskeyname` | SAS key name | — |
| `jaas-sharedaccesskey` | SAS key | Key Vault |
| `security-protocol` | Security protocol | `SASL_SSL` |
| `sasl-mechanism` | SASL mechanism | `PLAIN` |
| `key-serializer` | Key serializer class | — |
| `max-block-ms-config` | Max block time (ms) | `2000` |
| `retry-max-attempts` | Retry attempts | `2` |
| `retry-backoff-delay` | Retry backoff (ms) | `3000` |

### Key Vault Secrets

Loaded at startup via `idpsecretsloader.yaml`:

| Secret | Usage |
|---|---|
| `idgraph-solace-jms-username` | Solace authentication |
| `idgraph-solace-jms-password` | Solace authentication |
| `idgraph-gddn-subnotif-write-kafka-jaas-sharedaccesskey` | Subscriber Kafka SAS key |
| `idgraph-gddn-accnotif-write-kafka-jaas-sharedaccesskey` | Account Kafka SAS key |
| `idgraph-gddn-rgphosnotif-write-kafka-jaas-sharedaccesskey` | Product, PF Handler, RG Activation Kafka SAS key |
| `aaf-id`, `aaf-password` | AAF authentication |
| `cadi-truststore-*`, `cadi-keyfile-*` | mTLS keystores |

---

## Key Classes

### Bootstrap and Configuration

| Class | Role |
|---|---|
| `Application` | Entry point: validates args, loads system properties, initializes Key Vault secrets, starts Spring context. `@SpringBootApplication`, `@EnableAsync`, `@EnableCaching`. Excludes DataSource, Hibernate, Cassandra, Redis auto-config. |
| `SolaceJmsConfig` | Creates primary `solaceConnectionFactory` via JNDI. Used by Account, Subscriber, Product, RG Activation consumers. |
| `SolacePlatformHandlerJmsConfig` | Creates separate `solacePFHandlerConnectionFactory` for Platform Handler (different VPN/endpoint). |
| `KafkaProducerUnifiedConfig` | Wires five `NotificationPublisher` beans, each with primary + secondary `KafkaTemplate`. |
| `KafkaProducersConfig` | Maps `idgraph.kafka.producer.*` to `Map<String, KafkaProducerProperties>`. |
| `KafkaProducerConfigSupport` | Static utility building producer config with SASL/PLAIN + Azure Event Hub connection strings. |
| `KafkaProducerProperties` | POJO: `topic`, `bootstrapServers`, `clientId`, `jaasEndpoint`, `securityProtocol`, `saslMechanism`, `maxBlockMsConfig` (default `2000`), `retryMaxAttempts` (default `2`), `retryBackoffDelay` (default `3000`). |
| `JerseyConfiguration` | Registers `UserResourceImpl` and shutdown filters. Path: `/idgraphaccteventsms/v1`. |
| `ManagedShutdownConfiguration` | Activates IDP graceful shutdown. |

### JMS Consumer Layer

| Class | Role |
|---|---|
| `AbstractJmsNotificationConsumer` | Base class: `@PostConstruct` creates JMS Connection/Session/Queue/Consumer with `onMessage` listener. XML-to-JSON via `MessageParserHelper`, delegates to subclass `processMessage()`. `@PreDestroy` cleanup. |
| `JmsAccountNotificationConsumer` | Routes by `eventName`: `ActivateAccount`, `CloseAccount`, `UpdateAccount`. Publishes via `accountNotificationPublisher`. |
| `JmsSubscriberNotificationConsumer` | Handles `ChangeData`, `CancelSubscriber`, `SuspendSubscriber`, `RestoreSubscriber`. Maps status codes. Publishes via `subscriberNotificationPublisher`. |
| `JmsProductNotificationConsumer` | Gates on `billingAccountNumber` + `HBOCG=Y`. Publishes `ChangeProduct` via `productNotificationPublisher`. |
| `JmsRgActivationNotificationConsumer` | Unconditionally publishes `RgActivationEvent` via `rgActivationNotificationPublisher`. |
| `JmsPlatformHandlerNotificationConsumer` | Validates `foundationAccountNumber` + `billingAccountNumber` non-null. Publishes via `platformHandlerNotificationPublisher`. |

### Kafka Publisher Layer

| Class | Role |
|---|---|
| `NotificationPublisher` | Interface: `sendToPrimary(String)`, `getPrimaryTopicName()`, `getSecondaryTopicName()`, `getPublisherName()`. |
| `GenericNotificationPublisher` | Holds primary + secondary `KafkaTemplate`. Async publish with `CompletableFuture`. On primary failure, `recover()` calls `sendToSecondary()`. If both fail, throws `SecondaryProducerException`. MDC propagation for `idp-trace-id`. |

### Helper and Utility

| Class | Role |
|---|---|
| `MessageParserHelper` | XML to JSON via `XmlMapper` then `ObjectMapper.writeValueAsString()`. |
| `JsonService` | Static JSON utilities: `convertToObject()`, `getJsonFromObject()`, `toJsonString()`, `isValidJson()`. |

### REST / User Management

| Class | Role |
|---|---|
| `UserResource` | JAX-RS interface: `GET /users/{userId}`, `POST /users`, `GET /users/string/{userId}`. OpenAPI annotations. |
| `UserResourceImpl` | Controller: returns `Resource<User>` with HATEOAS self-link. |
| `UserServiceImpl` | `@Cacheable` on `getUser()` / `createUser()`. Cache: `IDGraphAcctEventsMs.com.att.idp.default.users`. |
| `UserRepositoryImpl` | In-memory `ConcurrentHashMap`. Auto-generates UUID. |

### Domain Models

| Domain | Key Classes |
|---|---|
| **Account** | `AccountNotificationMessage`, `AccountActivationEvent`, `AccountCloseEvent`, `AccountUpdateEvent`, `Account`, `Customer`, `Email`, `Name`, `Titan` |
| **Subscriber** | `SubscriberNotificationEvent`, `ChangeData`, `Subscriber` |
| **Product** | `ProductNotificationEvent`, `ChangeProduct`, `AdditionalOffering`, `ValueAddedParameters`, `ProductAttribute` |
| **RG Activation** | `RGActivationNotification`, `RgActivationEvent` |
| **Platform Handler** | `Change`, `PlatformHandlerEvent`, `Header`, `Upsert`, `Entity` |
| **Common** | `MessageHeader`, `TrackingMessageHeader` |

### Exception Handling

| Class | Role |
|---|---|
| `PrimaryProducerException` | Thrown on primary Kafka publish failure. Fields: `errorId`, `message`, `httpCode`. |
| `SecondaryProducerException` | Thrown when secondary also fails. Same structure. |

---

## Dependencies

### Runtime / Parent

| Dependency | Version | Purpose |
|---|---|---|
| `sdk-java-parent` | `3.0.1` | IDP parent POM — manages Spring Boot, Jersey, logging, shutdown |

### Key Dependencies

| Dependency | Version | Purpose |
|---|---|---|
| **Spring Boot** | Managed by `sdk-java-parent:3.0.1` | Application framework, auto-configuration |
| **Spring JMS** | Managed | JMS abstraction for Solace consumption |
| **Spring Kafka** | Managed | Kafka producer template |
| **Apache Kafka Clients** | `3.9.1` | Kafka producer protocol |
| **Spring Cache** | Managed | Cache abstraction |
| **Solace JMS** (`sol-jms`, `sol-jcsmp`) | `10.28.2` | Solace messaging client |
| **Jakarta JMS API** | `3.0.0` | JMS 3.0 interfaces |
| **Jackson Dataformat XML** | `2.15.3` | XML-to-JSON in `MessageParserHelper` |
| **Jackson Databind** | Managed | JSON serialization |
| **Lombok** | `1.18.38` | Boilerplate reduction |
| **Swagger / OpenAPI v3** | Managed | API documentation generation |
| **SpringDoc OpenAPI** | `2.6.0` | Swagger UI |
| **OWASP ESAPI** | Managed | Log injection prevention |
| **Apache Commons Text** | Managed | `StringEscapeUtils` for log escaping |
| **IDP Secrets** | Managed | Azure Key Vault decryption |
| **IDP Config** | Managed | Base Jersey configuration |
| **IDP Shutdown** | Managed | Graceful shutdown with request tracking |
| **Spock Framework** | `2.3-groovy-3.0` | BDD-style unit testing (Groovy) |
| **Spring Kafka Test** | Managed | Embedded Kafka for integration tests |

---

## Project Structure

```
apm0045194-idgraph-idgraphaccteventsms/
├── pom.xml                          # Maven build with sdk-java-parent:3.0.1
├── Jenkinsfile                      # CI/CD pipeline definition
├── idpsecretsloader.yaml            # Secrets loader config (Key Vault keys)
├── CODEOWNERS                       # Code ownership rules
├── sum_junit_tests.sh               # Script to aggregate JUnit test counts
├── opt/ajsc/                        # AJSC configuration
├── voltageTrustStore/               # Voltage encryption trust store
└── src/
    ├── main/
    │   ├── java/com/att/idp/idgraphaccteventsms/
    │   │   ├── Application.java
    │   │   ├── config/              # SolaceJmsConfig, SolacePlatformHandlerJmsConfig,
    │   │   │                        # JerseyConfiguration, ManagedShutdownConfiguration,
    │   │   │                        # IdpSecretsCacheHelper
    │   │   ├── exception/           # PrimaryProducerException, SecondaryProducerException
    │   │   ├── helper/              # MessageParserHelper
    │   │   ├── kafka/               # NotificationPublisher, GenericNotificationPublisher
    │   │   │   └── config/          # KafkaProducerUnifiedConfig, KafkaProducersConfig,
    │   │   │                        # KafkaProducerConfigSupport, KafkaProducerProperties
    │   │   ├── message/             # ErrorMessages, LogMessages
    │   │   ├── model/
    │   │   │   ├── User.java
    │   │   │   ├── accountnotification/   # AccountNotificationMessage, events, entities
    │   │   │   ├── subscription/          # SubscriberNotificationEvent, ChangeData
    │   │   │   ├── productnotification/   # ProductNotificationEvent, ChangeProduct
    │   │   │   ├── rgnotification/        # RGActivationNotification, RgActivationEvent
    │   │   │   ├── platformhandler/       # Change, PlatformHandlerEvent
    │   │   │   └── common/                # MessageHeader, ProductAttribute, etc.
    │   │   ├── repository/          # UserRepository, UserRepositoryImpl
    │   │   ├── resource/            # UserResource, UserResourceImpl
    │   │   ├── service/             # AbstractJmsNotificationConsumer (base)
    │   │   │                        # JmsAccountNotificationConsumer
    │   │   │                        # JmsSubscriberNotificationConsumer
    │   │   │                        # JmsProductNotificationConsumer
    │   │   │                        # JmsRgActivationNotificationConsumer
    │   │   │                        # JmsPlatformHandlerNotificationConsumer
    │   │   │                        # UserService, UserServiceImpl
    │   │   └── utils/               # JsonService
    │   └── resources/
    │       ├── errormessages.properties
    │       ├── logmessages.properties
    │       └── banner.txt
    └── test/
        ├── groovy/                  # Spock specs (BDD)
        │   ├── JmsAcctNotificationServiceSpec.groovy
        │   ├── JmsConsumerServiceSpec.groovy
        │   ├── JmsPlatformHandlerNotificationConsumerSpec.groovy
        │   ├── JmsProdNotificationServiceSpec.groovy
        │   ├── JmsRgActivationNotificationConsumerSpec.groovy
        │   ├── MessageParserHelperSpec.groovy
        │   └── component/ (UserResourceCT, CompTestBase)
        └── java/                    # JUnit tests
            ├── UserResourceImplTest.java
            ├── UserServiceImplTest.java
            ├── UserRepositoryImplTest.java
            ├── UserTest.java
            ├── UserResponseTest.java
            ├── LogMessagesTest.java
            └── integration/ (UserServiceIT)
```

---

## Domain Capability Map

| Capability | Description | Primary Interfaces / Entry Points |
|---|---|---|
| **Account Event Bridging** | Consumes Solace account lifecycle notifications (activate, close, update) and publishes to Kafka | `JmsAccountNotificationConsumer` → `accountNotificationPublisher` |
| **Subscriber Event Bridging** | Consumes subscriber change/cancel/suspend/restore events and publishes to Kafka | `JmsSubscriberNotificationConsumer` → `subscriberNotificationPublisher` |
| **Product Event Bridging** | Consumes product notifications gated by HBOCG=Y and publishes to Kafka | `JmsProductNotificationConsumer` → `productNotificationPublisher` |
| **RG Activation Bridging** | Consumes RG activation notifications and publishes unconditionally to Kafka | `JmsRgActivationNotificationConsumer` → `rgActivationNotificationPublisher` |
| **Platform Handler Bridging** | Consumes platform handler upsert events and publishes to Kafka | `JmsPlatformHandlerNotificationConsumer` → `platformHandlerNotificationPublisher` |
| **Dual-Cluster Failover** | Automatic primary-to-secondary Kafka failover per notification domain | `GenericNotificationPublisher.sendToPrimary()` → `recover()` → `sendToSecondary()` |
| **User Management REST API** | Basic CRUD for user resources with caching and HATEOAS | `GET/POST /msapi/idgraphaccteventsms/v1/users` |

---

## Integration Context

| Interface / Dependency | Direction | Type | Purpose | Notes |
|---|---|---|---|---|
| Solace JMS Broker (primary) | Inbound | JMS | Account, Subscriber, Product, RG Activation queues | `solaceConnectionFactory` via JNDI |
| Solace JMS Broker (PF Handler) | Inbound | JMS | Platform Handler queue | Separate `solacePFHandlerConnectionFactory` (different VPN) |
| Azure Event Hub (primary cluster) | Outbound | Kafka | Publish transformed events to primary topics | SASL/PLAIN auth with SAS keys |
| Azure Event Hub (secondary cluster) | Outbound | Kafka | Failover publish when primary fails | Same auth pattern, triggered by `GenericNotificationPublisher.recover()` |
| Azure Key Vault | Config | Secret | Solace credentials, Kafka SAS keys, AAF/CADI certs | Loaded at startup via `idpsecretsloader.yaml` |
| Azure App Configuration | Config | Feature Flag / Dynamic Config | Runtime configuration refresh | `IDGraphAzureAppConfig` + `ScheduledTaskConfiguration` |
| `idgrapheventshelper` | Library | Shared Lib | Common event helper abstractions | Version `4.0.2` |

---

## Workflows

### Application Startup Sequence

```mermaid
sequenceDiagram
    participant App as "Application.main()"
    participant Val as "ValueAnnotationValidator"
    participant Sys as "SystemPropertiesLoader"
    participant KV as "Key Vault Secrets"
    participant Ctx as "Spring Context"
    participant Sol as "Solace Configs"
    participant Kfk as "Kafka Config"
    participant JMS as "JMS Consumers x5"

    App->>Val: checkArgs(args)
    App->>Sys: addSystemProperties()
    App->>KV: init() via idpsecretsloader.yaml
    App->>Ctx: start Spring Boot
    Ctx->>Sol: SolaceJmsConfig + SolacePlatformHandlerJmsConfig
    Ctx->>Kfk: KafkaProducerUnifiedConfig (5 publishers)
    Ctx->>JMS: @PostConstruct init() per consumer
    Note right of JMS: Listening on 5 Solace queues
```

### Adding a New JMS Consumer

1. Create model package under `model/newdomain/`
2. Create input/output POJOs with `@Data`, `@Builder`,
   `@JsonIgnoreProperties`
3. Extend `AbstractJmsNotificationConsumer` as `@Service`
4. Inject `ConnectionFactory`, `MessageParserHelper`,
   `NotificationPublisher`, queue name
5. Implement `processMessage(String jsonString)`
6. Register `NotificationPublisher` bean in
   `KafkaProducerUnifiedConfig`
7. Add Kafka properties under
   `idgraph.kafka.producer.<name>-primary/secondary`
8. Add Solace queue name property
9. Write Spock specs in `src/test/groovy/`

### Adding a New Event Type

1. Add `eventName` branch in consumer's `processMessage()`
2. Create output event POJO in `model/` package
3. Implement handler method calling
   `getNotificationPublisher().sendToPrimary()`
4. Add unit test cases

### Adding a New Kafka Producer Pair

1. Add properties in `application.properties`:

```properties
idgraph.kafka.producer.<name>-primary.topic=...
idgraph.kafka.producer.<name>-primary.bootstrap-servers=...
idgraph.kafka.producer.<name>-secondary.topic=...
idgraph.kafka.producer.<name>-secondary.bootstrap-servers=...
```

2. Add `@Bean` in `KafkaProducerUnifiedConfig`:

```java
@Bean("<name>NotificationPublisher")
public NotificationPublisher np() {
    return createPublisher(
        "<name>-primary",
        "<name>-secondary",
        "<DisplayName>");
}
```

---

## Build and Test

### Test Suites

**Spock (Groovy BDD)** + **JUnit** test suite.

### Spock Specs

| Spec | Coverage |
|---|---|
| `JmsAcctNotificationServiceSpec` | Account event routing (Activate, Close, Update) |
| `JmsConsumerServiceSpec` | Base consumer message handling |
| `JmsPlatformHandlerNotificationConsumerSpec` | Platform handler validation |
| `JmsProdNotificationServiceSpec` | Product HBOCG gate logic |
| `JmsRgActivationNotificationConsumerSpec` | RG activation processing |
| `MessageParserHelperSpec` | XML to JSON parsing |

### JUnit Tests

| Test | Coverage |
|---|---|
| `UserResourceImplTest` | REST endpoint logic |
| `UserServiceImplTest` | Service layer + caching |
| `UserRepositoryImplTest` | In-memory repository CRUD |
| `UserTest` / `UserResponseTest` | Model serialization |
| `LogMessagesTest` | Log message properties |

### Component and Integration

| Test | Coverage |
|---|---|
| `UserResourceCT` | Component test for REST resource |
| `UserServiceIT` | Integration test with Spring context |

### Running Tests

```bash
# Unit tests (default profile)
mvn clean test

# Integration tests
mvn clean verify -P integration-test

# Full build with coverage
mvn clean install
# Coverage report: target/site/jacoco/index.html
```

### Prerequisites

- **Java 17** (`maven.compiler.release=17`)
- **Maven 3.8+**
- Access to `sdk-java-parent:3.0.1` parent POM repository

### Build

```bash
mvn clean package -DskipTests
```

### Run Locally

```bash
# Ensure application.properties and secrets are configured
java -jar target/IDGraphAcctEventsMs.jar
```

The service starts on the configured port and begins
listening on all five Solace queues.

---

## Deployment

Defined in `Jenkinsfile` using
`idp-shared-library@release/3.0.1`:

```groovy
def ovrParams = [
    SKIP_QGS                  : "QG4,QG5,QG6,QG7",
    VERACODE_PROFILE_NAME     : "33944-IDGraph-IDGraphAcctEventsMs",
    VERACODE_CRED_ID_OVERRIDE : true,
    GITHUB_MIGRATED           : true,
    DEFAULT_CLUSTER_NAME      : "Graph1EUS2-dev2",
    DEFAULT_CLUSTER_NAMESPACE : "com-att-idp-idgraph-dev2"
]
pl_idp_ms(ovrParams)
```

**Pipeline stages:** build, unit test, SonarQube analysis,
Veracode security scan, Docker image build, Helm chart
packaging, deployment to default AKS cluster.

### Runtime Notes

| Area | Value |
|---|---|
| **Deployment Target** | AKS (`com-att-idp-idgraph` namespace) |
| **Default Dev Cluster** | `Graph1EUS2-dev2` / `com-att-idp-idgraph-dev2` |
| **Helm Chart Repo** | `apm0045194-idgraph-idgraphaccteventsms-helm` |
| **Deployment Pipeline** | https://pipeline.web.att.com/uui |
| **Build Server** | https://jenkins-community-gateway.az.3pc.att.com/idp-ui/jenkins/job/com.att.idp/job/com.att.idp.IDGraphAcctEventsMs/job/master |

---

## Observability and Operations

| Area | Mechanism | Notes |
|---|---|---|
| **Logging** | SLF4J + Logback (`idp-logging-core`) | ESAPI-sanitized; structured MDC context (`idp-trace-id`, `x-att-clientid`) |
| **Metrics** | Spring Boot Actuator | Health, readiness, and disk space endpoints enabled |
| **Tracing / Correlation** | `idp-trace-id` header | Propagated across JMS consumers, Kafka publishers, and REST layer |
| **Log Masking** | `masking.properties` | Configured PII field masking in log output |
| **Operational Tasks** | Health: `/actuator/health` | Kafka, DB, Redis, and JMS health checks disabled (event-driven, no DB) |

### Metrics Glossary

| Metric | Type | Description |
|---|---|---|
| JMS message received | Counter | Messages consumed per Solace queue |
| JMS processing duration | Timer | Processing time (ms) per JMS message |
| Kafka publish success (primary) | Counter | Events published to primary topic |
| Kafka publish success (secondary) | Counter | Events published to secondary after primary failure |
| Kafka publish failure | Counter | Events failing both primary and secondary |
| Cache hit (users) | Counter | Hits on `IDGraphAcctEventsMs.com.att.idp.default.users` |

---

## Security and Compliance

| Area | Approach | Notes |
|---|---|---|
| **Authentication / Authorization** | AAF (disabled by default: `idp.aaf.enabled=false`); CADI trust stores for mTLS | CADI properties in `opt/ajsc/etc/config/cadi.properties` |
| **Sensitive Data Handling** | ESAPI log encoding; `masking.properties` for PII field masking | All external values sanitized before logging |
| **Secrets Management** | Azure Key Vault via `idpsecretsloader.yaml` | Solace creds, Kafka SAS keys, AAF creds, CADI keystores |
| **XSS Protection** | `idp.xss.filter.enabled=true` | XSS filter enabled on inbound requests |
| **Kafka Auth** | SASL/PLAIN over SSL (`SASL_SSL`) | Azure Event Hub connection strings with SAS keys |
| **Vulnerability Scanning** | Veracode profile: `33944-IDGraph-IDGraphAcctEventsMs` | Scanned in CI/CD pipeline |
| **Compliance Considerations** | No persistent PII storage; event bridge only forwards transformed data | No database retention concerns |

---

## Change Log / History

| Ticket / Version | Date | Description |
|---|---|---|
| **4.0.0** | 2026-05-01 | Restructured README to OMNI template compliance: added YAML frontmatter, Domain Capability Map, Integration Context, Data Stores & State Management, Observability and Operations, Security and Compliance, Deployment sections; renumbered TOC; added `AGENTS.md` |
| **3.0.0** | 2026-03-20 | Recreated README: updated `sdk-java-parent` to `3.0.1`, `idp-shared-library` to `3.0.0`, added Configuration Reference section, added Key Vault secrets inventory, added Mermaid architecture and startup diagrams, added subscriber status mapping table, added Change Log section, streamlined all sections for constitution compliance |
| **2.0.0** | 2025-02-28 | Comprehensive documentation with all process flows, schema definitions, and class references |
| **1.0.0** | — | Initial README |
