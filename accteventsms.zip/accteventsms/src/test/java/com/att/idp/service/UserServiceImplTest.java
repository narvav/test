package com.att.idp.service;

import com.att.ajsc.common.utility.SystemPropertiesLoader;
import com.att.idp.idgraphaccteventsms.model.User;
import com.att.idp.idgraphaccteventsms.repository.UserRepository;
import com.att.idp.idgraphaccteventsms.repository.UserRepositoryImpl;
import com.att.idp.idgraphaccteventsms.service.UserService;
import com.att.idp.idgraphaccteventsms.service.UserServiceImpl;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowableOfType;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;


@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = { UserServiceImpl.class, UserRepositoryImpl.class })
public class UserServiceImplTest {

	static {
		SystemPropertiesLoader.addSystemProperties();
	}

	@Spy
	UserRepository userRepository = new UserRepositoryImpl();

	@InjectMocks
	UserService userService = new UserServiceImpl();

	@Test
	void testGetUser_Success() {
		User mockUser = new User("12345");
		mockUser.setName("John Doe");
		when(userRepository.getUser("12345")).thenReturn(mockUser);

		User result = userService.getUser("12345");

		assertNotNull(result);
		assertEquals("12345", result.getId());
		assertEquals("John Doe", result.getName());
		verify(userRepository, times(1)).getUser("12345");
	}

	@Test
	void testCreateUser_Success() {
		User mockUser = new User("12345");
		mockUser.setName("John Doe");
		when(userRepository.createUser(mockUser)).thenReturn(mockUser);

		User result = userService.createUser(mockUser);

		assertNotNull(result);
		assertEquals("12345", result.getId());
		assertEquals("John Doe", result.getName());
		verify(userRepository, times(1)).createUser(mockUser);
	}

	@Test
	void testUpdateUser_NullInput() {
		User result = userService.updateUser(null);

		assertNull(result);
	}

	@Test
	void testCreateUserFromString_Success() {
		String userString = "Test123";
		when(userRepository.createUserFromString(userString)).thenReturn(userString);

		String result = userService.createUserFromString(userString);

		assertEquals("Test123", result);
		verify(userRepository, times(1)).createUserFromString(userString);
	}

	@Test
	void testGetUserString_Success() {
		String userString = "{\"id\":\"12345\",\"name\":\"John Doe\"}";
		when(userRepository.getUserString("12345")).thenReturn(userString);

		String result = userService.getUserString("12345");

		assertNotNull(result);
		assertEquals(userString, result);
		verify(userRepository, times(1)).getUserString("12345");
	}

	@Test
	public void testCreateUser() throws Exception {
		User user = new User();
		user.setId("1234");
		user.setName("john");
		doReturn(user).when(userRepository).createUser(user);
		User created = userService.createUser(user);
		assertThat(created).isNotNull();
		assertThat(created.getId()).isNotNull();
		assertThat(created.getName()).isEqualTo("john");
	}

	@Test
	public void testGetUser() throws Exception {
		User user = new User();
		user.setId("123");
		user.setName("Doe");
		when(userRepository.getUser(user.getId())).thenReturn(user);
		User created = userService.createUser(user);

		User read = userService.getUser(created.getId());
		assertThat(read).isNotNull();
		assertThat(read).isEqualTo(created);
	}

	@Test
	public void testUpdateUser() throws Exception {
		User updated = userService.updateUser(null);

		assertThat(updated).isNull();
	}

}
