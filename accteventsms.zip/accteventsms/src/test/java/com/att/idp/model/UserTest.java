package com.att.idp.model;

import com.att.idp.idgraphaccteventsms.model.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;

import static org.assertj.core.api.Assertions.assertThat;


public class UserTest {

	@Autowired
	public User user;
	
	@BeforeEach
	public void setUp() throws Exception {
		user = new User("12345", "John Doe");

	}

	@Test
	public void testEquals() throws Exception {
	
		Object obj = null;
		boolean result;

		// test 1
		obj = user;
		result = user.equals(obj);
		assertThat(result).isTrue();

		obj = null;
		result = user.equals(obj);
		assertThat(result).isFalse();

		obj = new ArrayList<Object>();
		result = user.equals(obj);
		assertThat(result).isFalse();

		user.setId(null);
		obj = new User("17951","David");
		result = user.equals(obj);
		assertThat(result).isFalse();

		user.setId(null);
		obj = new User(null,"David");
		result = user.equals(obj);
		assertThat(result).isFalse();

		obj = new User("17951","David");
		user.setId("17954");
		result = user.equals(obj);
		assertThat(result).isFalse();
		
		user.setId("17951");
		user.setName(null);
		result = user.equals(obj);
		assertThat(result).isFalse();
		
		obj = new User("17951",null);
		result = user.equals(obj);
		assertThat(result).isTrue();
		
		obj = new User("17951","David");
		user.setId("17951");		
		user.setName("Doss");	// name.equals(other.name)
		result = user.equals(obj);
		assertThat(result).isFalse();
		
		user.setName("David");
		result = user.equals(obj);
		assertThat(result).isTrue();
	}

	@Test
	public void testToString() throws Exception {
		// default test
		user.setName("David");
		String result = user.toString();
		assertThat(result).isEqualTo("{id:12345, name=David]");
	}

	@Test
	public void testHashcode() throws Exception {
		int result;

		// default test
		user.setName("David");
		result = user.hashCode();
		assertThat(result).isEqualTo(1516382274);
		user.setId(null);
		result = user.hashCode();
		assertThat(result).isEqualTo(65806869);
		user.setName(null);
		result = user.hashCode();
		assertThat(result).isEqualTo(961);
	}



	@Test
	void testGettersAndSetters() {
		user.setId("67890");
		user.setName("Jane Doe");

		assertThat(user.getId()).isEqualTo("67890");
		assertThat(user.getName()).isEqualTo("Jane Doe");
	}

	@Test
	void testEquals_SameObject() {
		assertThat(user.equals(user)).isTrue();
	}

	@Test
	void testEquals_NullObject() {
		assertThat(user.equals(null)).isFalse();
	}

	@Test
	void testEquals_DifferentClass() {
		assertThat(user.equals(new Object())).isFalse();
	}

	@Test
	void testEquals_DifferentId() {
		User other = new User("67890", "John Doe");
		assertThat(user.equals(other)).isFalse();
	}

	@Test
	void testEquals_DifferentName() {
		User other = new User("12345", "Jane Doe");
		assertThat(user.equals(other)).isFalse();
	}

	@Test
	void testEquals_SameValues() {
		User other = new User("12345", "John Doe");
		assertThat(user.equals(other)).isTrue();
	}

	@Test
	void testHashCode() {
		User other = new User("12345", "John Doe");
		assertThat(user.hashCode()).isEqualTo(other.hashCode());
	}

	@Test
	void testToString1() {
		assertThat(user.toString()).isEqualTo("{id:12345, name=John Doe]");
	}
}