package com.att.idp.model.swagger;

import com.att.idp.idgraphaccteventsms.model.swagger.UserResponse;
import com.att.idp.idgraphaccteventsms.model.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import static org.assertj.core.api.Assertions.assertThat;
public class UserResponseTest {

	@Autowired
	UserResponse userResponse;
	
	@BeforeEach
	public void setUp() throws Exception {
		userResponse= new UserResponse(new User("DP5252"));
	}

	@Test
	public void testGetContent() throws Exception {
		User result;
		// default test
		result = userResponse.getContent();
		assertThat(result.getId()).isEqualTo("DP5252");
	}
}