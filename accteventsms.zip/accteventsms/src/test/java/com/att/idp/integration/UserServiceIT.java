package com.att.idp.integration;

import com.att.idp.idgraphaccteventsms.model.User;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.core.IsEqual.equalTo;

public class UserServiceIT extends IntegrationTestBase {
	
	private String uri = "/users";

	@Test
	public void createUserSuccess() {
		User user = new User();
		user.setId("123");
		user.setName("test-user");
		
		Map<String, String> headers = new HashMap<>();
		//headers.put("idp-trace-id", getTraceId());
		
		givenBaseSpec()
		.headers(headers)
		.body(user)
		.when()
			.post(uri)
			.then()
				.statusCode(201);
	}
	
	@Test
	public void createUserFailure() {
		User user = new User();
		user.setId("123");
				
		givenBaseSpec()
		.body(user)
		.when()
			.post(uri)
			.then()
				.statusCode(400);
		
		givenBaseSpec()
		.body("")
		.when()
			.post(uri)
			.then()
				.statusCode(400);
	}
	
	@Test
	public void getUser() {
		
		//As we don't have the ITKO setup for this service so first create user
		User user = new User();
		user.setId("1234");
		user.setName("test-user");
		
		givenBaseSpec()
		.body(user)
		.when()
			.post(uri)
			.then()
				.statusCode(201);
		
		givenBaseSpec()
		.when().get(uri+"/1234")
		.then().statusCode(200)
				.assertThat().body("content.id", equalTo("1234"))
				.assertThat().body("content.name", equalTo("test-user"));
	}

}
