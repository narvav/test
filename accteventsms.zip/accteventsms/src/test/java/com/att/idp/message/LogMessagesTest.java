package com.att.idp.message;

import com.att.idp.i18n.ResourceManager;
import com.att.idp.idgraphaccteventsms.message.LogMessages;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class LogMessagesTest {

	@Test
	public void testLogMessages() {
		LogMessages[] values = LogMessages.values();
		assertThat(values).isNotNull();
	}
	@Test
	void testEnumValues() {
		LogMessages[] values = LogMessages.values();
		assertNotNull(values, "Enum values should not be null");
		assertTrue(values.length > 0, "Enum should have at least one value");
	}

	@Test
	void testResourceManagerInitialization() {
		// Verify that the ResourceManager loads the message bundle correctly
		assertDoesNotThrow(() -> ResourceManager.loadMessageBundle("logmessages"),
				"ResourceManager should load the message bundle without throwing exceptions");
	}
}
