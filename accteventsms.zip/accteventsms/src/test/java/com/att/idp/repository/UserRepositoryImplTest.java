package com.att.idp.repository;

import com.att.idp.core.exception.ServiceException;
import com.att.idp.idgraphaccteventsms.repository.UserRepository;
import com.att.idp.idgraphaccteventsms.repository.UserRepositoryImpl;
import com.att.idp.idgraphaccteventsms.model.User;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowableOfType;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = UserRepositoryImpl.class)
public class UserRepositoryImplTest {

	@Autowired
	UserRepository userRepository;


		@Test
		void testGetUser_Success() {
			User user = new User(UUID.randomUUID().toString());
			user.setName("Test User");
			userRepository.createUser(user);

			User retrievedUser = userRepository.getUser(user.getId());
			assertNotNull(retrievedUser);
			assertEquals(user.getId(), retrievedUser.getId());
			assertEquals(user.getName(), retrievedUser.getName());
		}

		@Test
		void testGetUser_NotFound() {
			User retrievedUser = userRepository.getUser("NonExistentId");
			assertNull(retrievedUser);
		}

		@Test
		void testCreateUser_WithId() {
			User user = new User("CustomId");
			user.setName("Test User");
			User createdUser = userRepository.createUser(user);

			assertNotNull(createdUser);
			assertEquals("CustomId", createdUser.getId());
			assertEquals("Test User", createdUser.getName());
		}

		@Test
		void testCreateUser_WithoutId() {
			User user = new User();
			user.setName("Test User");
			User createdUser = userRepository.createUser(user);

			assertNotNull(createdUser);
			assertNotNull(createdUser.getId());
			assertEquals("Test User", createdUser.getName());
		}

		@Test
		void testCreateUserFromString() {
			String strUser = "Test123";
			String result = userRepository.createUserFromString(strUser);

			assertEquals(strUser, result);
			User retrievedUser = userRepository.getUser("Test123");
			assertNotNull(retrievedUser);
			assertEquals("Test123", retrievedUser.getId());
			assertEquals("String User", retrievedUser.getName());
		}

		@Test
		void testGetUserString_Success() throws JsonProcessingException {
			User user = new User("Test123");
			user.setName("Test User");
			userRepository.createUser(user);

			String userString = userRepository.getUserString("Test123");
			assertNotNull(userString);
		}


		@Test
		void testGetUserString_ExceptionHandling() {
			User user = new User("InvalidUser");
			user.setName(null); // Simulate invalid user data
			userRepository.createUser(user);

			String userString = userRepository.getUserString("InvalidUser");
			userString.contains("InvalidUser");
		}

	@Test
	public void testCreateUser() throws Exception {
		User user = new User("dp5252");
		User saved = userRepository.createUser(user);

		assertThat(saved.getId()).isEqualTo(user.getId());
		assertThat(saved.getName()).isEqualTo(user.getName());

		user.setId(null);
		saved = userRepository.createUser(user);
		assertThat(saved.getId()).isNotNull();

		user.setId("");
		saved = userRepository.createUser(user);
		assertThat(saved.getId()).isNotNull();
	}

	@Test
	public void testGetUser() throws Exception {
		User user = new User("12345");
		user.setName("Doe");
		userRepository.createUser(user);

		User retrieved = userRepository.getUser(user.getId());

		assertThat(retrieved.getId()).isEqualTo(user.getId());
		assertThat(retrieved.getName()).isEqualTo(user.getName());
		assertThat(userRepository).isInstanceOf(UserRepositoryImpl.class);
	}







	}