package com.att.idp.resource;

import com.att.idp.core.exception.ServiceException;
import com.att.idp.idgraphaccteventsms.model.User;
import com.att.idp.idgraphaccteventsms.resource.UserResourceImpl;
import com.att.idp.idgraphaccteventsms.service.UserService;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriBuilder;
import jakarta.ws.rs.core.UriInfo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserResourceImplTest {

    @Mock
    private UserService userService;

    @Mock
    private UriInfo uriInfo;

    @InjectMocks
    private UserResourceImpl userResource;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetUser_Success() {
        User mockUser = new User("12345");
        mockUser.setName("John Doe");
        when(userService.getUser("12345")).thenReturn(mockUser);

        Response response = userResource.getUser("12345");

        assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
        assertNotNull(response.getEntity());
        verify(userService, times(1)).getUser("12345");
    }

    @Test
    void testCreateUser_Success() {
        User mockUser = new User("12345");
        mockUser.setName("John Doe");
        when(userService.createUser(any(User.class))).thenReturn(mockUser);
        when(uriInfo.getRequestUriBuilder()).thenReturn(mock(UriBuilder.class));

        Response response = userResource.createUser(mockUser, uriInfo);

        assertEquals(Response.Status.CREATED.getStatusCode(), response.getStatus());
        verify(userService, times(1)).createUser(mockUser);
    }

    @Test
    void testCreateUser_ValidationFailure() {
        ServiceException exception = assertThrows(ServiceException.class, () -> {
            userResource.createUser(null, uriInfo);
        });
        String exceptionMessage = exception.getMessage();
        assertTrue(exceptionMessage.contains("ERROR_VALIDATION_FAILED"), exception.getMessage());
    }

    @Test
    void testGetUserString_Success() {
        when(userService.getUserString("12345")).thenReturn("{\"id\":\"12345\"}");

        Response response = userResource.getUserString("12345");

        assertEquals(Response.Status.OK.getStatusCode(), response.getStatus());
        assertNotNull(response.getEntity());
        verify(userService, times(1)).getUserString("12345");
    }

    @Test
    void testGetUserString_ValidationFailure() {
        ServiceException exception = assertThrows(ServiceException.class, () -> {
            userResource.getUserString(null);
        });
        String exceptionMessage = exception.getMessage();
        assertTrue(exceptionMessage.contains("ERROR_VALIDATION_FAILED"), exception.getMessage());
    }
}