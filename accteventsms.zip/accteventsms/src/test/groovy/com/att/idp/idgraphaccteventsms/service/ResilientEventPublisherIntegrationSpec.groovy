package com.att.idp.idgraphaccteventsms.service

import com.att.idp.idgraph.events.service.ResilientEventPublisher
import com.att.idp.idgraphaccteventsms.helper.MessageParserHelper
import spock.lang.Specification
import spock.lang.Unroll

import javax.jms.ConnectionFactory
import javax.jms.TextMessage

/**
 * Tests verifying the ResilientEventPublisher integration across JMS consumers.
 * Validates sendWithFallback return values and Cosmos DB fallback logging paths.
 */
class ResilientEventPublisherIntegrationSpec extends Specification {

    ResilientEventPublisher resilientEventPublisher
    ConnectionFactory connectionFactory
    MessageParserHelper messageParserHelper

    def setup() {
        connectionFactory = Mock(ConnectionFactory)
        messageParserHelper = Mock(MessageParserHelper)
        resilientEventPublisher = Mock(ResilientEventPublisher)
    }

    def "should publish event successfully via sendWithFallback for Account consumer"() {
        given: "An Account notification consumer with mocked resilient publisher"
        def consumer = new JmsAccountNotificationConsumer(
                connectionFactory,
                messageParserHelper,
                resilientEventPublisher,
                "testQueue",
                true)

        and: "A valid TextMessage"
        TextMessage message = Mock(TextMessage)
        String payload = '{"AccountNotification":{"eventName":"ActivateAccount","Account":{"billingAccountNumber":"123456789","Customer":{"name":{"firstName":"John","lastName":"Doe"}}}}}'
        String parsedJson = payload

        when: "onMessage is called"
        consumer.onMessage(message)

        then: "Message is parsed and resilient publisher is invoked"
        1 * message.getText() >> payload
        1 * messageParserHelper.parseMessage(payload) >> parsedJson
        1 * messageParserHelper.generateTraceId() >> "test-trace-id"
        1 * resilientEventPublisher.sendWithFallback("gddnAccountNotifications", "Account", _, _) >> true
        1 * message.acknowledge()
        0 * _
    }

    def "should handle Cosmos DB fallback when sendWithFallback returns false"() {
        given: "A Subscriber notification consumer with mocked resilient publisher returning false"
        def consumer = new JmsSubscriberNotificationConsumer(
                connectionFactory,
                messageParserHelper,
                resilientEventPublisher,
                "testQueue",
                true)

        and: "A valid TextMessage"
        TextMessage message = Mock(TextMessage)
        String payload = '{"SubscriberNotification":{"eventName":"CancelSubscriber","Account":{"billingAccountNumber":"534442032153"},"Subscriber":{"subId":"sub123","subscriberNumber":"2339588004","subscriberStatus":"C"}}}'
        String parsedJson = payload

        when: "onMessage is called"
        consumer.onMessage(message)

        then: "Message is parsed and resilient publisher returns false (fallback to Cosmos)"
        1 * message.getText() >> payload
        1 * messageParserHelper.parseMessage(payload) >> parsedJson
        1 * messageParserHelper.generateTraceId() >> "test-trace-id"
        1 * resilientEventPublisher.sendWithFallback("gddnSubscriberNotifications", "Subscriber", _, _) >> false
        1 * message.acknowledge()
        0 * _
    }

    @Unroll
    def "should invoke sendWithFallback with correct binding for #consumerType"() {
        given: "A mock resilient event publisher"
        resilientEventPublisher.sendWithFallback(expectedBinding, expectedConsumerName, _, _) >> true

        expect: "Binding name and consumer name match expected values"
        expectedBinding != null
        expectedConsumerName != null

        where:
        consumerType        | expectedBinding               | expectedConsumerName
        "Account"           | "gddnAccountNotifications"    | "Account"
        "Subscriber"        | "gddnSubscriberNotifications" | "Subscriber"
        "Product"           | "gddnRgphosNotifications"     | "Product"
        "RG Activation"     | "gddnRgphosNotifications"     | "RG Activation"
        "Platform Handler"  | "gddnRgphosNotifications"     | "Platform Handler"
    }

    def "should handle RuntimeException from sendWithFallback gracefully"() {
        given: "An Account consumer where sendWithFallback throws"
        def consumer = new JmsAccountNotificationConsumer(
                connectionFactory,
                messageParserHelper,
                resilientEventPublisher,
                "testQueue",
                true)

        and: "A valid TextMessage"
        TextMessage message = Mock(TextMessage)
        String payload = '{"AccountNotification":{"eventName":"ActivateAccount","Account":{"billingAccountNumber":"999999999","Customer":{"name":{"firstName":"Test","lastName":"User"}}}}}'
        String parsedJson = payload

        when: "onMessage is called"
        consumer.onMessage(message)

        then: "Message is parsed but sendWithFallback throws RuntimeException"
        1 * message.getText() >> payload
        1 * messageParserHelper.parseMessage(payload) >> parsedJson
        1 * messageParserHelper.generateTraceId() >> "test-trace-id"
        1 * resilientEventPublisher.sendWithFallback(_, _, _, _) >> { throw new RuntimeException("Kafka and Cosmos both failed") }
        0 * _

        and: "No exception propagates (consumer handles it)"
        noExceptionThrown()
    }
}
