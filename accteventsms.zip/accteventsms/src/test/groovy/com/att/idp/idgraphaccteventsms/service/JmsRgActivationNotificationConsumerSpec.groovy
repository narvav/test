package com.att.idp.idgraphaccteventsms.service;

import com.att.idp.idgraphaccteventsms.model.rgnotification.RGActivationNotification
import com.att.idp.idgraphaccteventsms.service.JmsRgActivationNotificationConsumer
import com.att.idp.idgraphaccteventsms.model.rgnotification.RgActivationEvent
import com.att.idp.idgraphaccteventsms.model.common.MessageHeader
import com.att.idp.idgraphaccteventsms.model.common.TrackingMessageHeader
import com.att.idp.idgraphaccteventsms.model.rgnotification.RGActivationNotificationBody
import com.att.idp.idgraph.events.service.ResilientEventPublisher

import org.owasp.esapi.ESAPI
import spock.lang.Specification
import spock.lang.Unroll

import com.att.idp.idgraphaccteventsms.helper.MessageParserHelper
import com.att.idp.idgraphaccteventsms.utils.JsonService

import javax.jms.Connection
import javax.jms.ConnectionFactory
import javax.jms.MessageConsumer
import javax.jms.Queue
import javax.jms.Session
import javax.jms.TextMessage
import javax.jms.*;
import org.springframework.test.util.ReflectionTestUtils

class JmsRgActivationNotificationConsumerSpec extends Specification {

    def consumerService
    ConnectionFactory connectionFactory
    MessageParserHelper messageParserHelper
    ResilientEventPublisher resilientEventPublisher
    Connection connection
    Session session
    Queue queue
    MessageConsumer consumer

    def setup() {
        connectionFactory = Mock(ConnectionFactory)
        messageParserHelper = Mock(MessageParserHelper)
        resilientEventPublisher = Mock(ResilientEventPublisher)
        connection = Mock(Connection)
        session = Mock(Session)
        queue = Mock(Queue)
        consumer = Mock(MessageConsumer)

        consumerService = new JmsRgActivationNotificationConsumer(
                connectionFactory,
                messageParserHelper,
                resilientEventPublisher,
                "testQueue",
                true)
    }

    def "should persist VALIDATION_FAILED when rg activation event is missing accountNumber"() {
        given: "A payload that has eventName but no accountNumber"
        TextMessage message = Mock(TextMessage)
        String payload = '{"RgActivationNotification":{"eventName":"ActivateRG"}}'
        String parsedJson = payload

        RGActivationNotification notification = new RGActivationNotification()
        RGActivationNotificationBody body = new RGActivationNotificationBody()
        body.setEventName("ActivateRG")
        notification.setRgActivationNotification(body)

        when: "onMessage is called"
        JsonService.metaClass.static.convertToObject = { String json ->
            assert json == parsedJson
            return notification
        }
        consumerService.onMessage(message)

        then: "Validation failure is persisted and Kafka publish is skipped"
        1 * message.getText() >> payload
        1 * messageParserHelper.parseMessage(payload) >> parsedJson
        1 * messageParserHelper.generateTraceId() >> "test-trace-id"
        1 * resilientEventPublisher.saveValidationFailure(
                "gddnRgphosNotifications",
                "RG Activation",
                parsedJson,
                "Missing or unparseable RgActivationNotification / eventName / accountNumber")
        1 * message.acknowledge()
        0 * resilientEventPublisher.sendWithFallback(_, _, _, _)
        0 * _
    }

    @Unroll
    def "should persist VALIDATION_FAILED for invalid payload #scenarioName"() {
        given: "A valid TextMessage and mocked dependencies"
        String payload = inputPayload
        TextMessage message = Mock(TextMessage)
        String parsedJson = "{\"result\":\"ok\"}"

        when: "onMessage is called"
        consumerService.onMessage(message)

        then: "Message is parsed and validation failure is persisted"
        1 * message.getText() >> payload
        1 * messageParserHelper.parseMessage(payload) >> parsedJson
        1 * messageParserHelper.generateTraceId() >> "test-trace-id"
        1 * resilientEventPublisher.saveValidationFailure(
                "gddnRgphosNotifications",
                "RG Activation",
                parsedJson,
                "Missing or unparseable RgActivationNotification / eventName / accountNumber")
        1 * message.acknowledge()
        0 * _

        where: "Different invalid payload scenarios"
        scenarioName         | inputPayload
        "malformed payload"   | '{"foo":"bar"}'

    }

    def "should process valid RGActivationNotification message through onMessage flow"() {
        given: "A valid TextMessage with RGActivationNotification payload"
        String payload = '{"RgActivationNotification":{"eventName":"ACTIVATION","accountNumber":"ACC123","serialNumber":"SER456"}}'
        TextMessage message = Mock(TextMessage)
        String parsedJson = payload

        RGActivationNotification notification = new RGActivationNotification()
        RGActivationNotificationBody body = new RGActivationNotificationBody()
        body.setEventName("ACTIVATION")
        body.setAccountNumber("ACC123")
        body.setSerialNumber("SER456")
        notification.setRgActivationNotification(body)

        when: "onMessage is called"
        JsonService.metaClass.static.convertToObject = { String json ->
            assert json == parsedJson
            return notification
        }
        consumerService.onMessage(message)

        then: "Message is parsed, processed, and published to Kafka"
        1 * message.getText() >> payload
        1 * messageParserHelper.parseMessage(payload) >> parsedJson
        1 * messageParserHelper.generateTraceId() >> "test-trace-id"
        1 * resilientEventPublisher.sendWithFallback("gddnRgphosNotifications", "RG Activation", "ACC123", { it instanceof RgActivationEvent && it.eventName == "ACTIVATION" && it.accountNumber == "ACC123" && it.serialNumber == "SER456" }) >> true
        1 * message.acknowledge()
        0 * resilientEventPublisher.saveValidationFailure(_, _, _, _)
        0 * _
    }

    def "should handle empty payload gracefully"() {
        given: "A TextMessage with empty payload"
        String payload = ""
        TextMessage message = Mock(TextMessage)
        message.getText() >> payload

        when: "onMessage is called"
        consumerService.onMessage(message)

        then: "No parsing or processing occurs"
        1 * message.getText() >> payload
        0 * messageParserHelper.parseMessage(_)
        1 * message.acknowledge()
        0 * _
    }

    def "should handle non-TextMessage gracefully"() {
        given: "A non-TextMessage JMS Message"
        Message message = Mock(Message)
        message.toString() >> "nonTextPayload"

        when: "onMessage is called"
        consumerService.onMessage(message)

        then: "Message is parsed and processed"
        1 * message.toString() >> "nonTextPayload"
        1 * messageParserHelper.parseMessage("nonTextPayload") >> "{}"
        1 * messageParserHelper.generateTraceId() >> "test-trace-id"
        1 * resilientEventPublisher.saveValidationFailure(
                "gddnRgphosNotifications",
                "RG Activation",
                "{}",
                "Missing or unparseable RgActivationNotification / eventName / accountNumber")
        1 * message.acknowledge()
        0 * _
    }

    def "should log error when message parsing throws exception"() {
        given: "A TextMessage and parseMessage throws exception"
        String payload = '{"foo":"bar"}'
        TextMessage message = Mock(TextMessage)
        message.getText() >> payload
        RuntimeException parseException = new RuntimeException("Parse error")
        messageParserHelper.parseMessage(payload) >> { throw parseException }

        when: "onMessage is called"
        consumerService.onMessage(message)

        then: "Exception is caught and logged"
        1 * message.getText() >> payload
        1 * messageParserHelper.parseMessage(payload) >> { throw parseException }
        0 * _
    }

    @Unroll
    def "should process RGActivationNotification for #scenarioName"() {
        given: "A RGActivationNotification with specific attributes"
        RGActivationNotification notification = new RGActivationNotification()
        notification.setRgActivationNotification(rgActivationNotification)
        notification.setMessageHeader(messageHeader)

        when: "processRgActivationNotification is called"
        consumerService."processRgActivationNotification"(notification, "test-trace-id")

        then: "Event is created with expected attributes and serialized"
        1 * resilientEventPublisher.sendWithFallback("gddnRgphosNotifications", "RG Activation", expectedAccountNumber, { it instanceof RgActivationEvent && it.eventName == expectedEventName && it.accountNumber == expectedAccountNumber && it.serialNumber == expectedSerialNumber }) >> true
        0 * _

        and: "Attributes are set as expected"
        rgActivationNotification.getEventName() == expectedEventName
        rgActivationNotification.getAccountNumber() == expectedAccountNumber
        rgActivationNotification.getSerialNumber() == expectedSerialNumber
        if (messageHeader != null && messageHeader.getTrackingMessageHeader() != null) {
            messageHeader.getTrackingMessageHeader().getMessageId() == expectedMessageId
        }

        where: "Different notification scenarios"
        scenarioName           | rgActivationNotification                                 | messageHeader                                 | expectedEventName | expectedAccountNumber | expectedSerialNumber | expectedMessageId | expectedJson
        "full attributes"      | createRgActivationNotification("ACTIVATION", "ACC123", "SER456") | createMessageHeader("MSG789")                | "ACTIVATION"     | "ACC123"             | "SER456"            | "MSG789"         | '{"eventName":"ACTIVATION","tlgMessageId":"MSG789","accountNumber":"ACC123","serialNumber":"SER456","eventId":"test-trace-id"}'
        "missing header"       | createRgActivationNotification("DEACTIVATION", "ACC999", "SER888") | null                                         | "DEACTIVATION"   | "ACC999"             | "SER888"            | null             | '{"eventName":"DEACTIVATION","accountNumber":"ACC999","serialNumber":"SER888","eventId":"test-trace-id"}'

    }

    static RGActivationNotificationBody createRgActivationNotification(String eventName, String accountNumber, String serialNumber) {
        RGActivationNotificationBody notif = new RGActivationNotificationBody()
        notif.setEventName(eventName)
        notif.setAccountNumber(accountNumber)
        notif.setSerialNumber(serialNumber)
        return notif
    }

    static MessageHeader createMessageHeader(String messageId) {
        MessageHeader header = new MessageHeader()
        TrackingMessageHeader trackingHeader = new TrackingMessageHeader()
        trackingHeader.setMessageId(messageId)
        header.setTrackingMessageHeader(trackingHeader)
        return header
    }

    def "should initialize JMS consumer on init"() {
        given: "Mocked JMS setup"
        // connectionFactory is already set via constructor

        when: "init is called"
        consumerService.init()

        then: "JMS connection/session/consumer are created and started"
        1 * connectionFactory.createConnection() >> connection
        1 * connection.createSession(false, Session.CLIENT_ACKNOWLEDGE) >> session
        1 * session.createQueue("testQueue") >> queue
        1 * session.createConsumer(queue) >> consumer
        1 * consumer.setMessageListener({ it != null })
        1 * connection.start()
        0 * _
    }

    def "should cleanup JMS resources on shutdown"() {
        given: "JMS resources are set"
        ReflectionTestUtils.setField(consumerService, "consumer", consumer)
        ReflectionTestUtils.setField(consumerService, "session", session)
        ReflectionTestUtils.setField(consumerService, "connection", connection)

        when: "cleanup is called"
        consumerService.cleanup()

        then: "All JMS resources are closed"
        1 * consumer.close()
        1 * session.close()
        1 * connection.close()
        0 * _
    }

}
