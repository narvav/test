package com.att.idp.idgraphaccteventsms.service;

import com.att.idp.idgraphaccteventsms.helper.MessageParserHelper
import com.att.idp.idgraph.events.service.ResilientEventPublisher
import com.att.idp.idgraphaccteventsms.model.common.MessageHeader
import com.att.idp.idgraphaccteventsms.model.subscription.ChangeData
import com.att.idp.idgraphaccteventsms.model.subscription.SubscriberNotification
import com.att.idp.idgraphaccteventsms.model.subscription.SubscriberNotificationEvent
import org.springframework.test.util.ReflectionTestUtils
import com.att.idp.idgraphaccteventsms.model.productnotification.ChangeProduct;
import com.att.idp.idgraphaccteventsms.model.productnotification.ProductNotificationEvent
import com.att.idp.idgraphaccteventsms.model.productnotification.ProductNotification
import com.att.idp.idgraphaccteventsms.model.productnotification.Account
import com.att.idp.idgraphaccteventsms.model.productnotification.Product
import com.att.idp.idgraphaccteventsms.model.productnotification.AdditionalOffering
import com.att.idp.idgraphaccteventsms.model.common.ValueAddedParameters
import com.att.idp.idgraphaccteventsms.model.common.ProductAttribute
import com.att.idp.idgraphaccteventsms.model.productnotification.Subscriber
import com.att.idp.idgraphaccteventsms.model.productnotification.ContactName
import com.att.idp.idgraphaccteventsms.utils.JsonService

import java.util.ArrayList

import javax.jms.Connection
import javax.jms.ConnectionFactory
import javax.jms.MessageConsumer
import javax.jms.Queue
import javax.jms.Session
import javax.jms.TextMessage

import spock.lang.Specification
import spock.lang.Unroll

class JmsProdNotificationServiceSpec extends Specification {

    def jmsProdNotificationService
    ConnectionFactory connectionFactory
    MessageParserHelper messageParserHelper
    ResilientEventPublisher resilientEventPublisher
    Connection connection
    Session session
    Queue queue
    MessageConsumer consumer

    def setup() {
        connectionFactory = Mock(ConnectionFactory)
        messageParserHelper = Mock(MessageParserHelper)
        resilientEventPublisher = Mock(ResilientEventPublisher)
        connection = Mock(Connection)
        session = Mock(Session)
        queue = Mock(Queue)
        consumer = Mock(MessageConsumer)

        jmsProdNotificationService = new JmsProductNotificationConsumer(
                connectionFactory,
                messageParserHelper,
                resilientEventPublisher,
                "testQueue",
                true)
    }

    @Unroll
    def "should process valid text message for #scenarioName"() {
        given: "A valid TextMessage and mocked dependencies"
        TextMessage message = Mock(TextMessage)
        String payload = inputPayload
        String parsedJson = "{\"result\":\"ok\"}"

        when: "onMessage is called"
        jmsProdNotificationService.onMessage(message)

        then: "TextMessage.getText is called, payload is parsed, and invalid structure is parked as VALIDATION_FAILED"
        1 * message.getText() >> payload
        1 * messageParserHelper.parseMessage(payload) >> parsedJson
        1 * messageParserHelper.generateTraceId() >> "test-trace-id"
        1 * resilientEventPublisher.saveValidationFailure(
                "gddnRgphosNotifications",
                "Product",
                parsedJson,
                "Missing or unparseable ProductNotification / eventName")
        1 * message.acknowledge()
        0 * _

        and: "No exception is thrown and message is processed"
        // No additional assertions needed for void method

        where: "Different valid message scenarios"
        scenarioName         | inputPayload
        "simple message"     | "hello"
    }

    def "should handle exception during message processing"() {
        given: "A TextMessage and messageParserHelper throws exception"
        TextMessage message = Mock(TextMessage)
        String payload = "error"
        RuntimeException parseException = new RuntimeException("Parse failed")

        when: "onMessage is called"
        jmsProdNotificationService.onMessage(message)

        then: "TextMessage.getText is called, parseMessage throws, and error is logged"
        1 * message.getText() >> payload
        1 * messageParserHelper.parseMessage(payload) >> { throw parseException }
        0 * _
    }

    @Unroll
    def "should process valid text message for Suspended #scenarioName"() {
        given: "A valid TextMessage and mocked dependencies"
        TextMessage message = Mock(TextMessage)
        String payload = "{\"MessageHeader\":{\"TrackingMessageHeader\":{\"version\":\"v144\",\"messageId\":\"TLPAC913833923\",\"originatorId\":\"TLG\",\"timeToLive\":\"0\",\"dateTimeStamp\":\"2025-11-12T20:11:52.319Z\"},\"SecurityMessageHeader\":{\"userName\":\"\",\"userPassword\":\"\"},\"SequenceMessageHeader\":{\"sequenceNumber\":\"913833923\",\"totalInSequence\":\"1\"}},\"ProductNotification\":{\"eventName\":\"ChangeProduct\",\"billingSystemId\":\"TLG\",\"billingSystemEventGenerationDateTime\":\"2025-11-12T20:11:52.319Z\",\"Account\":{\"billingAccountNumber\":\"337332254405\",\"billingMarket\":{\"billingMarket\":\"PAC\",\"billingSubMarket\":\"LAX\"},\"accountType\":{\"accountType\":\"S\",\"accountSubType\":\"O\"}},\"Subscriber\":{\"subscriberNumber\":\"8402586727\",\"subId\":\"T_PAC_LAX_1759435216000467477944\",\"inServiceDate\":\"2025-11-12Z\",\"subscriberStatus\":\"A\",\"Device\":{\"equipmentType\":\"G\",\"technologyType\":\"LTE\",\"IMSI\":\"310170203258341\",\"IMEI\":\"357845060063337\",\"IMEIType\":\"C6\",\"SIM\":\"89011702272032583418\",\"Manufacturer\":{\"make\":\"DENSO\",\"model\":\"PG03717\"},\"smsCapabilityIndicator\":\"true\"},\"ContactName\":{\"firstName\":\"HONDA\",\"lastName\":\"DA\"},\"SubscriberAttributes\":{\"attributeName\":\"SUB_CLASS\",\"attributeValue\":\"H\"}},\"Product\":{\"PricePlan\":{\"singleUserCode\":\"CCLNTPP\",\"recurringCharge\":\"0.0\",\"PricePlanAttributes\":[{\"attributeName\":\"RTP\",\"attributeValue\":\"Y\"},{\"attributeName\":\"SOC_SEQ_NO\",\"attributeValue\":\"5124420385\"},{\"attributeName\":\"DEALER_CODE\",\"attributeValue\":\"C6SWW\"}],\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\"},\"actionCode\":\"Q\"},\"AdditionalOfferings\":[{\"action\":\"Q\",\"offeringCode\":\"NOSMSO\",\"offeringDescription\":\"TextRestricted\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\"},\"ValueAddedParameters\":{\"ProductAttributes\":[{\"attributeName\":\"RTP\",\"attributeValue\":\"Y\"},{\"attributeName\":\"SOC_SEQ_NO\",\"attributeValue\":\"5124420387\"},{\"attributeName\":\"DEALER_CODE\",\"attributeValue\":\"C6SWW\"}]}},{\"action\":\"A\",\"offeringCode\":\"PUCLMAX35\",\"offeringDescription\":\"UnldatacarMax\",\"EffectiveDates\":{\"effectiveDate\":\"2025-12-08Z\",\"expirationDate\":\"2026-01-07Z\"},\"ValueAddedParameters\":{\"ProductAttributes\":[{\"attributeName\":\"RTP\",\"attributeValue\":\"Y\"},{\"attributeName\":\"PURCH_ORDR_NO\",\"attributeValue\":\"PAC163480\"},{\"attributeName\":\"SOC_SEQ_NO\",\"attributeValue\":\"5124420389\"},{\"attributeName\":\"DEALER_CODE\",\"attributeValue\":\"C6SWW\"},{\"attributeName\":\"TS_ID\",\"attributeValue\":\"100000000197156\"},{\"attributeName\":\"AUTO_RENEW_IND\",\"attributeValue\":\"Y\"},{\"attributeName\":\"CAPM_REF_NO\",\"attributeValue\":\"8PDFHON2H010BS33001\"},{\"attributeName\":\"ONSTRET\",\"attributeValue\":\"Y\"},{\"attributeName\":\"ONSTRPRE\",\"attributeValue\":\"Y\"},{\"attributeName\":\"HBOCG\",\"attributeValue\":\"Y\"}]}},{\"action\":\"Q\",\"offeringCode\":\"PUCLMAX35\",\"offeringDescription\":\"UnldatacarMax\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\",\"expirationDate\":\"2025-12-08Z\"},\"ValueAddedParameters\":{\"ProductAttributes\":[{\"attributeName\":\"RTP\",\"attributeValue\":\"Y\"},{\"attributeName\":\"PURCH_ORDR_NO\",\"attributeValue\":\"PAC163267\"},{\"attributeName\":\"SOC_SEQ_NO\",\"attributeValue\":\"5124420388\"},{\"attributeName\":\"DEALER_CODE\",\"attributeValue\":\"C6SWW\"},{\"attributeName\":\"TS_ID\",\"attributeValue\":\"100000000196987\"},{\"attributeName\":\"AUTO_RENEW_IND\",\"attributeValue\":\"N\"},{\"attributeName\":\"CAPM_REF_NO\",\"attributeValue\":\"8P7FHON2H010BMB5001\"},{\"attributeName\":\"ONSTRET\",\"attributeValue\":\"Y\"},{\"attributeName\":\"ONSTRPRE\",\"attributeValue\":\"Y\"},{\"attributeName\":\"HBOCG\",\"attributeValue\":\"Y\"}]}},{\"action\":\"Q\",\"offeringCode\":\"SMB\",\"offeringDescription\":\"InstantMessages\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\"}},{\"action\":\"Q\",\"offeringCode\":\"STD\",\"offeringDescription\":\"AIRTIME\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\"}},{\"action\":\"Q\",\"offeringCode\":\"ACT\",\"offeringDescription\":\"ActivationFee\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\"}},{\"action\":\"Q\",\"offeringCode\":\"CON6R\",\"offeringDescription\":\"GenericAPNPolicy\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\"}},{\"action\":\"Q\",\"offeringCode\":\"ACTNOC\",\"offeringDescription\":\"BYOD/NoCommitActivations\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\"}},{\"action\":\"Q\",\"offeringCode\":\"CON6AR\",\"offeringDescription\":\"GenericAPNPolicy\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\",\"expirationDate\":\"2025-12-08Z\"}},{\"action\":\"Q\",\"offeringCode\":\"CONOAR\",\"offeringDescription\":\"AutoRenewConflict\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\",\"expirationDate\":\"2025-12-08Z\"}},{\"action\":\"A\",\"offeringCode\":\"CON6AR\",\"offeringDescription\":\"GenericAPNPolicy\",\"EffectiveDates\":{\"effectiveDate\":\"2025-12-08Z\",\"expirationDate\":\"2026-01-07Z\"}},{\"action\":\"A\",\"offeringCode\":\"DPKG\",\"offeringDescription\":\"DATACALLPACKAGE\",\"EffectiveDates\":{\"effectiveDate\":\"2025-12-08Z\",\"expirationDate\":\"2026-01-07Z\"}},{\"action\":\"Q\",\"offeringCode\":\"DPKG\",\"offeringDescription\":\"DATACALLPACKAGE\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\",\"expirationDate\":\"2025-12-08Z\"}},{\"action\":\"Q\",\"offeringCode\":\"TURBOC\",\"offeringDescription\":\"DataSession\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\",\"expirationDate\":\"2025-12-08Z\"}},{\"action\":\"A\",\"offeringCode\":\"TURBOC\",\"offeringDescription\":\"DataSession\",\"EffectiveDates\":{\"effectiveDate\":\"2025-12-08Z\",\"expirationDate\":\"2026-01-07Z\"}},{\"action\":\"Q\",\"offeringCode\":\"DUMGPR\",\"offeringDescription\":\"NOPROVISIONINGDATA\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\",\"expirationDate\":\"2025-12-08Z\"}},{\"action\":\"A\",\"offeringCode\":\"CONOAR\",\"offeringDescription\":\"AutoRenewConflict\",\"EffectiveDates\":{\"effectiveDate\":\"2025-12-08Z\",\"expirationDate\":\"2026-01-07Z\"}},{\"action\":\"A\",\"offeringCode\":\"DUMGPR\",\"offeringDescription\":\"NOPROVISIONINGDATA\",\"EffectiveDates\":{\"effectiveDate\":\"2025-12-08Z\",\"expirationDate\":\"2026-01-07Z\"}}],\"Discounts\":{\"action\":\"Q\",\"code\":\"\",\"description\":\"ConnectedCarBase\"}}}}"
        String parsedJson = "{\"MessageHeader\":{\"TrackingMessageHeader\":{\"version\":\"v144\",\"messageId\":\"TLPAC913833923\",\"originatorId\":\"TLG\",\"timeToLive\":\"0\",\"dateTimeStamp\":\"2025-11-12T20:11:52.319Z\"},\"SecurityMessageHeader\":{\"userName\":\"\",\"userPassword\":\"\"},\"SequenceMessageHeader\":{\"sequenceNumber\":\"913833923\",\"totalInSequence\":\"1\"}},\"ProductNotification\":{\"eventName\":\"ChangeProduct\",\"billingSystemId\":\"TLG\",\"billingSystemEventGenerationDateTime\":\"2025-11-12T20:11:52.319Z\",\"Account\":{\"billingAccountNumber\":\"337332254405\",\"billingMarket\":{\"billingMarket\":\"PAC\",\"billingSubMarket\":\"LAX\"},\"accountType\":{\"accountType\":\"S\",\"accountSubType\":\"O\"}},\"Subscriber\":{\"subscriberNumber\":\"8402586727\",\"subId\":\"T_PAC_LAX_1759435216000467477944\",\"inServiceDate\":\"2025-11-12Z\",\"subscriberStatus\":\"A\",\"Device\":{\"equipmentType\":\"G\",\"technologyType\":\"LTE\",\"IMSI\":\"310170203258341\",\"IMEI\":\"357845060063337\",\"IMEIType\":\"C6\",\"SIM\":\"89011702272032583418\",\"Manufacturer\":{\"make\":\"DENSO\",\"model\":\"PG03717\"},\"smsCapabilityIndicator\":\"true\"},\"ContactName\":{\"firstName\":\"HONDA\",\"lastName\":\"DA\"},\"SubscriberAttributes\":{\"attributeName\":\"SUB_CLASS\",\"attributeValue\":\"H\"}},\"Product\":{\"PricePlan\":{\"singleUserCode\":\"CCLNTPP\",\"recurringCharge\":\"0.0\",\"PricePlanAttributes\":[{\"attributeName\":\"RTP\",\"attributeValue\":\"Y\"},{\"attributeName\":\"SOC_SEQ_NO\",\"attributeValue\":\"5124420385\"},{\"attributeName\":\"DEALER_CODE\",\"attributeValue\":\"C6SWW\"}],\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\"},\"actionCode\":\"Q\"},\"AdditionalOfferings\":[{\"action\":\"Q\",\"offeringCode\":\"NOSMSO\",\"offeringDescription\":\"TextRestricted\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\"},\"ValueAddedParameters\":{\"ProductAttributes\":[{\"attributeName\":\"RTP\",\"attributeValue\":\"Y\"},{\"attributeName\":\"SOC_SEQ_NO\",\"attributeValue\":\"5124420387\"},{\"attributeName\":\"DEALER_CODE\",\"attributeValue\":\"C6SWW\"}]}},{\"action\":\"A\",\"offeringCode\":\"PUCLMAX35\",\"offeringDescription\":\"UnldatacarMax\",\"EffectiveDates\":{\"effectiveDate\":\"2025-12-08Z\",\"expirationDate\":\"2026-01-07Z\"},\"ValueAddedParameters\":{\"ProductAttributes\":[{\"attributeName\":\"RTP\",\"attributeValue\":\"Y\"},{\"attributeName\":\"PURCH_ORDR_NO\",\"attributeValue\":\"PAC163480\"},{\"attributeName\":\"SOC_SEQ_NO\",\"attributeValue\":\"5124420389\"},{\"attributeName\":\"DEALER_CODE\",\"attributeValue\":\"C6SWW\"},{\"attributeName\":\"TS_ID\",\"attributeValue\":\"100000000197156\"},{\"attributeName\":\"AUTO_RENEW_IND\",\"attributeValue\":\"Y\"},{\"attributeName\":\"CAPM_REF_NO\",\"attributeValue\":\"8PDFHON2H010BS33001\"},{\"attributeName\":\"ONSTRET\",\"attributeValue\":\"Y\"},{\"attributeName\":\"ONSTRPRE\",\"attributeValue\":\"Y\"},{\"attributeName\":\"HBOCG\",\"attributeValue\":\"Y\"}]}},{\"action\":\"Q\",\"offeringCode\":\"PUCLMAX35\",\"offeringDescription\":\"UnldatacarMax\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\",\"expirationDate\":\"2025-12-08Z\"},\"ValueAddedParameters\":{\"ProductAttributes\":[{\"attributeName\":\"RTP\",\"attributeValue\":\"Y\"},{\"attributeName\":\"PURCH_ORDR_NO\",\"attributeValue\":\"PAC163267\"},{\"attributeName\":\"SOC_SEQ_NO\",\"attributeValue\":\"5124420388\"},{\"attributeName\":\"DEALER_CODE\",\"attributeValue\":\"C6SWW\"},{\"attributeName\":\"TS_ID\",\"attributeValue\":\"100000000196987\"},{\"attributeName\":\"AUTO_RENEW_IND\",\"attributeValue\":\"N\"},{\"attributeName\":\"CAPM_REF_NO\",\"attributeValue\":\"8P7FHON2H010BMB5001\"},{\"attributeName\":\"ONSTRET\",\"attributeValue\":\"Y\"},{\"attributeName\":\"ONSTRPRE\",\"attributeValue\":\"Y\"},{\"attributeName\":\"HBOCG\",\"attributeValue\":\"Y\"}]}},{\"action\":\"Q\",\"offeringCode\":\"SMB\",\"offeringDescription\":\"InstantMessages\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\"}},{\"action\":\"Q\",\"offeringCode\":\"STD\",\"offeringDescription\":\"AIRTIME\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\"}},{\"action\":\"Q\",\"offeringCode\":\"ACT\",\"offeringDescription\":\"ActivationFee\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\"}},{\"action\":\"Q\",\"offeringCode\":\"CON6R\",\"offeringDescription\":\"GenericAPNPolicy\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\"}},{\"action\":\"Q\",\"offeringCode\":\"ACTNOC\",\"offeringDescription\":\"BYOD/NoCommitActivations\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\"}},{\"action\":\"Q\",\"offeringCode\":\"CON6AR\",\"offeringDescription\":\"GenericAPNPolicy\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\",\"expirationDate\":\"2025-12-08Z\"}},{\"action\":\"Q\",\"offeringCode\":\"CONOAR\",\"offeringDescription\":\"AutoRenewConflict\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\",\"expirationDate\":\"2025-12-08Z\"}},{\"action\":\"A\",\"offeringCode\":\"CON6AR\",\"offeringDescription\":\"GenericAPNPolicy\",\"EffectiveDates\":{\"effectiveDate\":\"2025-12-08Z\",\"expirationDate\":\"2026-01-07Z\"}},{\"action\":\"A\",\"offeringCode\":\"DPKG\",\"offeringDescription\":\"DATACALLPACKAGE\",\"EffectiveDates\":{\"effectiveDate\":\"2025-12-08Z\",\"expirationDate\":\"2026-01-07Z\"}},{\"action\":\"Q\",\"offeringCode\":\"DPKG\",\"offeringDescription\":\"DATACALLPACKAGE\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\",\"expirationDate\":\"2025-12-08Z\"}},{\"action\":\"Q\",\"offeringCode\":\"TURBOC\",\"offeringDescription\":\"DataSession\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\",\"expirationDate\":\"2025-12-08Z\"}},{\"action\":\"A\",\"offeringCode\":\"TURBOC\",\"offeringDescription\":\"DataSession\",\"EffectiveDates\":{\"effectiveDate\":\"2025-12-08Z\",\"expirationDate\":\"2026-01-07Z\"}},{\"action\":\"Q\",\"offeringCode\":\"DUMGPR\",\"offeringDescription\":\"NOPROVISIONINGDATA\",\"EffectiveDates\":{\"effectiveDate\":\"2025-11-12Z\",\"expirationDate\":\"2025-12-08Z\"}},{\"action\":\"A\",\"offeringCode\":\"CONOAR\",\"offeringDescription\":\"AutoRenewConflict\",\"EffectiveDates\":{\"effectiveDate\":\"2025-12-08Z\",\"expirationDate\":\"2026-01-07Z\"}},{\"action\":\"A\",\"offeringCode\":\"DUMGPR\",\"offeringDescription\":\"NOPROVISIONINGDATA\",\"EffectiveDates\":{\"effectiveDate\":\"2025-12-08Z\",\"expirationDate\":\"2026-01-07Z\"}}],\"Discounts\":{\"action\":\"Q\",\"code\":\"\",\"description\":\"ConnectedCarBase\"}}}}"

        MessageHeader notification = new MessageHeader()

        ProductNotificationEvent event = new ProductNotificationEvent()
        event.setMessageHeader(notification)
        ProductNotification productNotification = new ProductNotification()
        productNotification.setEventName("ChangeProduct")
        Account account = new Account()
        account.setBillingAccountNumber("337332254405")
        productNotification.setAccount(account)
        Product product = new Product()
        ValueAddedParameters valueAddedParameters = new ValueAddedParameters()
        List<ProductAttribute> productAttributes = new ArrayList<>()
        ProductAttribute attribute1 = new ProductAttribute()
        attribute1.setAttributeName("HBOCG")
        attribute1.setAttributeValue("Y")
        ProductAttribute attribute2 = new ProductAttribute()
        attribute2.setAttributeName("SOC_SEQ_NO")
        attribute2.setAttributeValue("5124420385")
        ProductAttribute attribute3 = new ProductAttribute()
        attribute3.setAttributeName("DEALER_CODE")
        attribute3.setAttributeValue("C6SWW")
        productAttributes.add(attribute1)
        productAttributes.add(attribute2)
        productAttributes.add(attribute3)
        valueAddedParameters.setProductAttributes(productAttributes)
        AdditionalOffering additionalOffering = new AdditionalOffering()
        additionalOffering.setValueAddedParameters(valueAddedParameters)
        List<AdditionalOffering> additionalOfferings = new ArrayList<>()
        additionalOfferings.add(additionalOffering)
        product.setAdditionalOfferings(additionalOfferings)
        productNotification.setProduct(product)
        event.setProductNotification(productNotification)

        when: "onMessage is called"
        JsonService.metaClass.static.convertToObject = { String json ->
            assert json == parsedJson
            return event
        }
        jmsProdNotificationService.onMessage(message)

        then: "TextMessage.getText is called and messageParserHelper.parseMessage is invoked"
        1 * message.getText() >> payload
        1 * messageParserHelper.parseMessage(payload) >> parsedJson
        1 * messageParserHelper.generateTraceId() >> "test-trace-id"
        1 * resilientEventPublisher.sendWithFallback("gddnRgphosNotifications", "Product", "337332254405", { it instanceof ChangeProduct && it.billingAccountNumber == "337332254405" }) >> true
        1 * message.acknowledge()
        0 * _

    }

    def "should initialize JMS consumer on init"() {
        given: "Mocked JMS setup"
        // connectionFactory is already set via constructor

        when: "init is called"
        jmsProdNotificationService.init()

        then: "JMS connection/session/consumer are created and started"
        1 * connectionFactory.createConnection() >> connection
        1 * connection.createSession(false, Session.CLIENT_ACKNOWLEDGE) >> session
        1 * session.createQueue("testQueue") >> queue
        1 * session.createConsumer(queue) >> consumer
        1 * consumer.setMessageListener({ it != null })
        1 * connection.start()
        0 * _
    }

    def "should cleanup JMS resources on shutdown"() {
        given: "JMS resources are set"
        ReflectionTestUtils.setField(jmsProdNotificationService, "consumer", consumer)
        ReflectionTestUtils.setField(jmsProdNotificationService, "session", session)
        ReflectionTestUtils.setField(jmsProdNotificationService, "connection", connection)

        when: "cleanup is called"
        jmsProdNotificationService.cleanup()

        then: "All JMS resources are closed"
        1 * consumer.close()
        1 * session.close()
        1 * connection.close()
        0 * _
    }

    @Unroll
    def "should activate account and log correct JSON for #scenarioName"() {
        given: "A valid AccountNotificationMessage with all required fields"
        Account account = new Account()
        account.setBillingAccountNumber("12345678")
        Subscriber subscriber = new Subscriber()
        ContactName contactName = new ContactName()
        contactName.setFirstName("firstName")
        contactName.setLastName("lastName")
        subscriber.setContactName(contactName)
        ProductNotification productNotification = new ProductNotification()
        productNotification.setEventName("ChangeProduct")
        productNotification.setAccount(account)
        productNotification.setSubscriber(subscriber)
        Product product = new Product()
        ValueAddedParameters valueAddedParameters = new ValueAddedParameters()
        List<ProductAttribute> productAttributes = List.of(
                ProductAttribute.builder()
                        .attributeName("HBOCG")
                        .attributeValue("Y")
                        .build(),
                ProductAttribute.builder()
                        .attributeName("DataLimit")
                        .attributeValue("Unlimited")
                        .build()
        );
        valueAddedParameters.setProductAttributes(productAttributes)
        List<AdditionalOffering> additionalOfferings = new ArrayList<>()
        AdditionalOffering additionalOffering = new AdditionalOffering()
        additionalOffering.setValueAddedParameters(valueAddedParameters)
        additionalOfferings.add(additionalOffering)
        product.setAdditionalOfferings(additionalOfferings)
        productNotification.setProduct(product)

        ProductNotificationEvent productNotificationEvent = new ProductNotificationEvent()
        productNotificationEvent.setProductNotification(productNotification)

        when: "isAllowedForChangedProduct  is called"
        jmsProdNotificationService.isAllowedForChangedProduct (productNotificationEvent)

        then: "isAllowedForChangedProduct is called with correct productNotificationEvent"
        // All assertions are done in the metaClass closure
        0 * _

    }

    @Unroll
    def "should change product for #scenarioName"() {
        given: "A ProductNotification with all required fields"
        Account account = new Account()
        account.setBillingAccountNumber(billingAccountNumber)
        ProductNotification productNotification = new ProductNotification()
        Subscriber subscriber = new Subscriber()
        ContactName contactName = new ContactName()
        contactName.setFirstName(firstName)
        contactName.setLastName(lastName)
        subscriber.setContactName(contactName)
        productNotification.setSubscriber(subscriber)
        productNotification.setEventName(eventName)
        productNotification.setAccount(account)

        ChangeProduct changeProduct = new ChangeProduct()
        changeProduct.setEventName(eventName)
        changeProduct.setBillingAccountNumber(billingAccountNumber)
        changeProduct.setFirstName(firstName)
        changeProduct.setLastName(lastName)
        changeProduct.setSorId("13");
        changeProduct.setServiceName("MOBILITY");
        changeProduct.setIsConnectedCar("Y");

        String expectedJson = expectedJsonValue

        when: "changeProduct is called"
        jmsProdNotificationService.changeProduct(productNotification, null, "test-trace-id")

        then: "ResilientEventPublisher sends the event via the correct binding"
        1 * resilientEventPublisher.sendWithFallback("gddnRgphosNotifications", "Product", billingAccountNumber, {
            it instanceof ChangeProduct &&
            it.eventName == eventName &&
            it.billingAccountNumber == billingAccountNumber &&
            it.firstName == firstName &&
            it.lastName == lastName &&
            it.sorId == sorId &&
            it.serviceName == serviceName &&
            it.isConnectedCar == isConnectedCar
        }) >> true
        0 * _ // No other interactions allowed

        and: "ProductNotification attributes are validated"
        changeProduct.eventName == eventName
        changeProduct.billingAccountNumber == billingAccountNumber
        changeProduct.firstName == firstName
        changeProduct.lastName == lastName
        changeProduct.sorId == sorId
        changeProduct.serviceName == serviceName
        changeProduct.isConnectedCar == isConnectedCar

        where: "Different product change scenarios"
        scenarioName         | eventName      | billingAccountNumber  | sorId | serviceName | isConnectedCar | firstName  | lastName    | expectedJsonValue
        "basic change"       | "ChangeProduct"| "12345678"            | "13"  | "MOBILITY"  |     "Y"        | "firstName"| "lastName"  | "{\"eventName\":\"ChangeProduct\",\"billingAccountNumber\":\"12345678\",\"sorId\":\"13\",\"serviceName\":\"MOBILITY\",\"isConnectedCar\":\"Y\",\"firstName\":\"firstName\",\"lastName\":\"lastName\"}"
        "data limit change"  | "ChangeProduct"| "87654321"            | "13"  | "MOBILITY"  |     "Y"        | "John"     | "Doe"       | "{\"eventName\":\"ChangeProduct\",\"billingAccountNumber\":\"87654321\",\"sorId\":\"13\",\"serviceName\":\"MOBILITY\",\"isConnectedCar\":\"Y\",\"firstName\":\"John\",\"lastName\":\"Doe\"}"
    }

}
