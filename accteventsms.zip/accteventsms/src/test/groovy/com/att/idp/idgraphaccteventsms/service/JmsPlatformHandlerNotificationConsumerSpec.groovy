package com.att.idp.idgraphaccteventsms.service

import com.att.idp.idgraphaccteventsms.helper.MessageParserHelper
import com.att.idp.idgraph.events.service.ResilientEventPublisher
import com.att.idp.idgraphaccteventsms.model.platformhandler.Change
import com.att.idp.idgraphaccteventsms.model.platformhandler.Upsert
import com.att.idp.idgraphaccteventsms.model.platformhandler.Entity
import com.att.idp.idgraphaccteventsms.model.platformhandler.Header
import com.att.idp.idgraphaccteventsms.model.platformhandler.EntityUpsert
import com.att.idp.idgraphaccteventsms.model.platformhandler.PlatformHandlerEvent
import com.att.idp.idgraphaccteventsms.model.rgnotification.RGActivationNotification
import com.att.idp.idgraphaccteventsms.model.subscription.Account
import com.att.idp.idgraphaccteventsms.model.subscription.ChangeData
import com.att.idp.idgraphaccteventsms.model.subscription.Subscriber
import com.att.idp.idgraphaccteventsms.model.subscription.SubscriberNotification
import com.att.idp.idgraphaccteventsms.model.subscription.SubscriberNotificationEvent
import com.att.idp.idgraphaccteventsms.utils.JsonService
import javax.jms.Connection
import javax.jms.ConnectionFactory
import jakarta.jms.JMSException
import jakarta.jms.Message
import javax.jms.MessageConsumer
import javax.jms.Queue
import javax.jms.Session
import javax.jms.TextMessage
import org.owasp.esapi.ESAPI
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import spock.lang.Unroll

/**
 * Unit tests for {@link JmsPlatformHandlerNotificationConsumer}.
 */
class JmsPlatformHandlerNotificationConsumerSpec extends Specification {

    def consumerService
    ConnectionFactory connectionFactory
    MessageParserHelper messageParserHelper
    ResilientEventPublisher resilientEventPublisher

    Connection connection
    Session session
    Queue queue
    MessageConsumer consumer

    void setup() {
        connectionFactory = Mock(ConnectionFactory)
        messageParserHelper = Mock(MessageParserHelper)
        resilientEventPublisher = Mock(ResilientEventPublisher)
        connection = Mock(Connection)
        session = Mock(Session)
        queue = Mock(Queue)
        consumer = Mock(MessageConsumer)

        consumerService = new JmsPlatformHandlerNotificationConsumer(
                connectionFactory,
                messageParserHelper,
                resilientEventPublisher,
                "testQueue",
                true)
    }

    @Unroll
    def "should process valid RGActivationNotification message for #scenarioName"() {
        given: "A valid TextMessage and mocked dependencies"
        String payload = inputPayload
        TextMessage message = Mock(TextMessage)
        String parsedJson = "{\"result\":\"ok\"}"

        when: "onMessage is called"
        consumerService.onMessage(message)

        then: "Message is parsed and processed"
        1 * message.getText() >> payload
        1 * messageParserHelper.parseMessage(payload) >> parsedJson
        1 * messageParserHelper.generateTraceId() >> "test-trace-id"
        1 * resilientEventPublisher.saveValidationFailure(
                "gddnRgphosNotifications",
                "Platform Handler",
                parsedJson,
                "Missing required foundationAccountNumber and/or billingAccountNumber")
        1 * message.acknowledge()
        0 * _

        where: "Different valid payload scenarios"
        scenarioName         | inputPayload
        "standard payload"   | '{"foo":"bar"}'

    }

    def "should handle empty payload gracefully"() {
        given: "A TextMessage with empty payload"
        String payload = ""
        TextMessage message = Mock(TextMessage)
        message.getText() >> payload

        when: "onMessage is called"
        consumerService.onMessage(message)

        then: "No parsing or processing occurs"
        1 * message.getText() >> payload
        0 * messageParserHelper.parseMessage(_)
        1 * message.acknowledge()
        0 * _
    }

    def "should handle non-TextMessage gracefully"() {
        given: "A non-TextMessage JMS Message"
        javax.jms.Message message = Mock(javax.jms.Message)
        message.toString() >> "nonTextPayload"

        when: "onMessage is called"
        consumerService.onMessage(message)

        then: "Message is parsed and processed"
        1 * message.toString() >> "nonTextPayload"
        1 * messageParserHelper.parseMessage("nonTextPayload") >> "{}"
        1 * messageParserHelper.generateTraceId() >> "test-trace-id"
        1 * resilientEventPublisher.saveValidationFailure(
                "gddnRgphosNotifications",
                "Platform Handler",
                "{}",
                "Missing required foundationAccountNumber and/or billingAccountNumber")
        1 * message.acknowledge()
        0 * _
    }

    def "should log error when message parsing throws exception"() {
        given: "A TextMessage and parseMessage throws exception"
        String payload = '{"foo":"bar"}'
        TextMessage message = Mock(TextMessage)
        message.getText() >> payload
        RuntimeException parseException = new RuntimeException("Parse error")
        messageParserHelper.parseMessage(payload) >> { throw parseException }

        when: "onMessage is called"
        consumerService.onMessage(message)

        then: "Exception is caught and logged"
        1 * message.getText() >> payload
        1 * messageParserHelper.parseMessage(payload) >> { throw parseException }
        0 * _
    }

    def "should persist VALIDATION_FAILED when platform handler payload misses required BAN fields"() {
        given: "A parsed payload that lacks billingAccountNumber/foundationAccountNumber"
        TextMessage message = Mock(TextMessage)
        String payload = '{"upsert":{"entity":{}}}'
        String parsedJson = payload

        Change invalidChange = new Change()
        Upsert upsert = new Upsert()
        Entity entity = new Entity()
        upsert.setEntity(entity)
        invalidChange.setUpsert(upsert)

        when: "onMessage is called"
        JsonService.metaClass.static.convertToObject = { String json ->
            assert json == parsedJson
            return invalidChange
        }
        consumerService.onMessage(message)

        then: "Validation failure is persisted and Kafka publish is skipped"
        1 * message.getText() >> payload
        1 * messageParserHelper.parseMessage(payload) >> parsedJson
        1 * messageParserHelper.generateTraceId() >> "test-trace-id"
        1 * resilientEventPublisher.saveValidationFailure(
                "gddnRgphosNotifications",
                "Platform Handler",
                parsedJson,
                "Missing required foundationAccountNumber and/or billingAccountNumber")
        1 * message.acknowledge()
        0 * resilientEventPublisher.sendWithFallback(_, _, _, _)
        0 * _
    }

    @Unroll
    def "should process valid text message for Suspended #scenarioName"() {
        given: "A valid TextMessage and mocked dependencies"
        TextMessage message = Mock(TextMessage)
        String payload = "{\"upsert\":{\"entity\":{\"foundationAccountNumber\":\"3257997\",\"billingAccountNumber\":\"12345\",\"upsert\":{\"platformHandlerLastUpdatedDate\":\"2025-11-05T13:14:32.000Z\",\"foundationAccountNumber\":\"3257997\",\"billingAccountNumber\":\"12345\",\"platformHandler\":\"Premier\"}}},\"header\":{\"sourceSystem\":\"ROME\",\"gridTxnID\":\"1a0cce45-c4df-4d43-bad0-34bd73bd0cd5\",\"transactionTS\":\"2025-11-06T05:31:28.889Z\",\"attributes\":{\"SourceBusinessLine\":\"ROME\",\"SourceDataSource\":\"ROME\",\"SourceSystem\":\"ROME\"},\"sourceBusinessLine\":\"ROME\",\"txnRecievedTS\":\"2025-11-06T05:31:28.930Z\",\"transactionID\":\"1a0cce45-c4df-4d43-bad0-34bd73bd0cd5\"}}"
        String parsedJson = "{\"upsert\":{\"entity\":{\"foundationAccountNumber\":\"3257997\",\"billingAccountNumber\":\"12345\",\"upsert\":{\"platformHandlerLastUpdatedDate\":\"2025-11-05T13:14:32.000Z\",\"foundationAccountNumber\":\"3257997\",\"billingAccountNumber\":\"12345\",\"platformHandler\":\"Premier\"}}},\"header\":{\"sourceSystem\":\"ROME\",\"gridTxnID\":\"1a0cce45-c4df-4d43-bad0-34bd73bd0cd5\",\"transactionTS\":\"2025-11-06T05:31:28.889Z\",\"attributes\":{\"SourceBusinessLine\":\"ROME\",\"SourceDataSource\":\"ROME\",\"SourceSystem\":\"ROME\"},\"sourceBusinessLine\":\"ROME\",\"txnRecievedTS\":\"2025-11-06T05:31:28.930Z\",\"transactionID\":\"1a0cce45-c4df-4d43-bad0-34bd73bd0cd5\"}}"

        Change change = new Change()
        Upsert upsert = new Upsert();
        Header header = new Header();
        header.setTransactionID("1a0cce45-c4df-4d43-bad0-34bd73bd0cd5")
        header.setTxnReceivedTS("2025-11-06T05:31:28.930Z")
        Entity entity = new Entity();
        EntityUpsert entityUpsert = new EntityUpsert();
        entityUpsert.setFoundationAccountNumber("3257997" )
        entityUpsert.setBillingAccountNumber("12345")
        entityUpsert.setPlatformHandler("Premier")
        entity.setUpsert(entityUpsert)
        upsert.setEntity(entity)
        change.setUpsert(upsert)
        change.setHeader(header)

        when: "onMessage is called"
        JsonService.metaClass.static.convertToObject = { String json ->
            assert json == parsedJson
            return change
        }
        consumerService.onMessage(message)

        then: "TextMessage.getText is called and messageParserHelper.parseMessage is invoked"
        1 * message.getText() >> payload
        1 * messageParserHelper.parseMessage(payload) >> parsedJson
        1 * messageParserHelper.generateTraceId() >> "test-trace-id"
        1 * resilientEventPublisher.sendWithFallback("gddnRgphosNotifications", "Platform Handler", "12345", { it instanceof PlatformHandlerEvent && it.billingAccountNumber == "12345" }) >> true
        1 * message.acknowledge()
        0 * _

    }

    def "should initialize JMS consumer on init"() {
        given: "Mocked JMS setup"
        // connectionFactory is already set via constructor

        when: "init is called"
        consumerService.init()

        then: "JMS connection/session/consumer are created and started"
        1 * connectionFactory.createConnection() >> connection
        1 * connection.createSession(false, Session.CLIENT_ACKNOWLEDGE) >> session
        1 * session.createQueue("testQueue") >> queue
        1 * session.createConsumer(queue) >> consumer
        1 * consumer.setMessageListener({ it != null })
        1 * connection.start()
        0 * _
    }

    def "should cleanup JMS resources on shutdown"() {
        given: "JMS resources are set"
        ReflectionTestUtils.setField(consumerService, "consumer", consumer)
        ReflectionTestUtils.setField(consumerService, "session", session)
        ReflectionTestUtils.setField(consumerService, "connection", connection)

        when: "cleanup is called"
        consumerService.cleanup()

        then: "All JMS resources are closed"
        1 * consumer.close()
        1 * session.close()
        1 * connection.close()
        0 * _
    }

    @Unroll
    def "should process RGActivationNotification for #scenarioName"() {
        given: "A RGActivationNotification with specific attributes"
        Change change = new Change()
        Upsert upsert = new Upsert();
        Header header = new Header();
        header.setTransactionID("TXN789")
        header.setTxnReceivedTS("TXN734589")
        Entity entity = new Entity();
        EntityUpsert entityUpsert = new EntityUpsert();

        entityUpsert.setFoundationAccountNumber("ACC123" )
        entityUpsert.setBillingAccountNumber("SER456")
        entityUpsert.setPlatformHandler("pf123")
        entity.setUpsert(entityUpsert)
        upsert.setEntity(entity)
        change.setUpsert(upsert)
        change.setHeader(header)

        when: "processPlatformHandlerNotification is called"
        consumerService."processPlatformHandlerNotification"(change, "test-trace-id")

        then: "Event is created with expected attributes and serialized"
        1 * resilientEventPublisher.sendWithFallback("gddnRgphosNotifications", "Platform Handler", "SER456", { it instanceof PlatformHandlerEvent && it.billingAccountNumber == "SER456" }) >> true
        0 * _
    }


}
