package com.att.idp.idgraphaccteventsms.helper;

import com.att.idp.idgraphaccteventsms.helper.MessageParserHelper
import spock.lang.Specification
import spock.lang.Unroll

class MessageParserHelperSpec extends Specification {

    MessageParserHelper messageParserHelper

    def setup() {
        messageParserHelper = new MessageParserHelper()
    }

    @Unroll
    def "should parse valid XML to JSON for #scenarioName"() {
        given: "A valid XML string"
        String xmlInput = inputXml

        when: "parseMessage is called"
        String resultJson = messageParserHelper.parseMessage(xmlInput)

        then: "Resulting JSON contains expected keys"
        resultJson != null
        resultJson.contains(expectedKey)
        resultJson.contains(expectedValue)

        where: "Different valid XML scenarios"
        scenarioName      | inputXml                                 | expectedKey | expectedValue
        "simple element"  | "<user><id>1</id><name>John</name></user>" | "id"        | "John"
        "nested element"  | "<order><item><name>Book</name></item></order>" | "name"      | "Book"
    }

    @Unroll
    def "should return null for empty or null input for #scenarioName"() {
        given: "An empty or null XML string"
        String xmlInput = inputXml

        when: "parseMessage is called"
        String resultJson = messageParserHelper.parseMessage(xmlInput)

        then: "Result is null"
        resultJson == null

        where: "Different empty/null scenarios"
        scenarioName      | inputXml
        "null input"      | null
        "empty string"    | ""
        "whitespace only" | "   "
    }

    def "should return null and log error for invalid XML"() {
        given: "An invalid XML string"
        String invalidXml = "<user><id>1<id><name>John</name></user>"

        when: "parseMessage is called"
        String resultJson = messageParserHelper.parseMessage(invalidXml)

        then: "Result is null"
        resultJson == null
    }
}
