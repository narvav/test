
package com.att.idp.component

import  com.att.idp.idgraphaccteventsms.Application

import com.att.ajsc.common.utility.SystemPropertiesLoader

import io.restassured.RestAssured
import io.restassured.http.ContentType
import io.restassured.specification.RequestSpecification
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.web.server.LocalServerPort
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification

@ContextConfiguration(classes = Application.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = Application.class)
abstract class CompTestBase extends Specification {
    @Value('${server.servlet.context-path}')
    private String contextPath

    @Value('${api.schemaVersion}')
    private String apiVersion

    @Value('${spring.application.name}')
    private String appPath

    @LocalServerPort
    private int randomServerPort

    @Value('${apiclient.rest.default.userTypes.guest.username}')
    protected String guestUsername

    @Value('${apiclient.rest.default.userTypes.guest.password}')
    protected String guestPassword

    @Value('${apiclient.rest.default.userTypes.registered.username}')
    protected String registeredUsername

    @Value('${apiclient.rest.default.userTypes.registered.password}')
    protected String registeredPassword

    private static final String host = 'localhost' //InetAddress.getLocalHost().getHostName()

    static {
        SystemPropertiesLoader.addSystemProperties()
    }


    def setup() throws Exception {
        RestAssured.baseURI = 'http://' + host + ':' + randomServerPort+ contextPath + '/' + appPath.toLowerCase() + '/' + apiVersion
    }

    /*
     * Base spec with guest user
     */
    protected RequestSpecification givenBaseSpec() {
        return RestAssured.given()
                .relaxedHTTPSValidation()
                .accept(ContentType.JSON)
                .contentType(ContentType.JSON)
                .auth().basic(guestUsername, guestPassword)
    }

    /*
     * Base spec for registered user
     */
    protected RequestSpecification givenRegisterdBaseSpec() {
        return RestAssured.given()
                .relaxedHTTPSValidation()
                .accept(ContentType.JSON)
                .contentType(ContentType.JSON)
                .auth()
                .basic(registeredUsername, registeredPassword)
    }
}