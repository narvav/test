import com.att.idp.idgraphaccteventsms.helper.MessageParserHelper
import com.att.idp.idgraph.events.service.ResilientEventPublisher
import com.att.idp.idgraphaccteventsms.model.accountnotification.AccountNotificationMessage
import com.att.idp.idgraphaccteventsms.model.accountnotification.AccountActivationEvent
import com.att.idp.idgraphaccteventsms.model.accountnotification.AccountNotification
import com.att.idp.idgraphaccteventsms.model.accountnotification.AccountCloseEvent
import com.att.idp.idgraphaccteventsms.model.accountnotification.Account
import com.att.idp.idgraphaccteventsms.model.accountnotification.Customer
import com.att.idp.idgraphaccteventsms.model.accountnotification.Name
import com.att.idp.idgraphaccteventsms.model.accountnotification.Email
import com.att.idp.idgraphaccteventsms.service.JmsAccountNotificationConsumer
import com.att.idp.idgraphaccteventsms.model.accountnotification.AccountUpdateEvent
import com.att.idp.idgraphaccteventsms.utils.JsonService
import org.springframework.test.util.ReflectionTestUtils

import javax.jms.TextMessage
import javax.jms.Connection
import javax.jms.ConnectionFactory

import javax.jms.MessageConsumer
import javax.jms.Queue
import javax.jms.Session
import spock.lang.Specification
import spock.lang.Unroll


class JmsAcctNotificationServiceSpec extends Specification {

    def jmsAcctNotificationService
    MessageParserHelper messageParserHelper
    ResilientEventPublisher resilientEventPublisher
    ConnectionFactory connectionFactory
    MessageConsumer consumer
    Session session
    Connection connection
    Queue queue


    def setup() {
        connectionFactory = Mock(ConnectionFactory)
        messageParserHelper = Mock(MessageParserHelper)
        resilientEventPublisher = Mock(ResilientEventPublisher)
        connection = Mock(Connection)
        session = Mock(Session)
        queue = Mock(Queue)
        consumer = Mock(MessageConsumer)

        jmsAcctNotificationService = new JmsAccountNotificationConsumer(
                connectionFactory,
                messageParserHelper,
                resilientEventPublisher,
                "testQueue",
                true)
    }

    @Unroll
    def "should activate account and publish event for #scenarioName"() {
        given: "A valid AccountNotificationMessage for account activation"
        AccountNotificationMessage actNotificationMsg = new AccountNotificationMessage()
        AccountNotification acctNotification = new AccountNotification()
        Account account = new Account()
        Customer customer = new Customer()
        Name name = new Name()
        name.setFirstName(firstName)
        name.setLastName(lastName)
        customer.setName(name)
        customer.setEmail(emailObj)
        account.setCustomer(customer)
        account.setBillingAccountNumber(billingAccountNumber)
        acctNotification.setAccount(account)
        acctNotification.setEventName(eventName)
        actNotificationMsg.setAccountNotification(acctNotification)

        AccountActivationEvent expectedEnt = new AccountActivationEvent()
        expectedEnt.setEventName(eventName)
        expectedEnt.setBillingAccountNumber(billingAccountNumber)
        expectedEnt.setSorId("13")
        expectedEnt.setServiceName("MOBILITY")
        expectedEnt.setFirstName(firstName)
        expectedEnt.setLastName(lastName)
        expectedEnt.setContactEmail(emailObj != null ? emailObj.getEmailAddress() : null)

        String expectedJson = expectedJsonValue

        when: "activateAccount is called"
        jmsAcctNotificationService."activateAccount"(actNotificationMsg, "test-trace-id")

        then: "ResilientEventPublisher sends the event via the correct binding"
        1 * resilientEventPublisher.sendWithFallback("gddnAccountNotifications", "Account", billingAccountNumber, {
            it instanceof AccountActivationEvent &&
                    it.eventName == eventName &&
                    it.billingAccountNumber == billingAccountNumber &&
                    it.sorId == "13" &&
                    it.serviceName == "MOBILITY" &&
                    it.firstName == firstName &&
                    it.lastName == lastName &&
                    it.contactEmail == (emailObj != null ? emailObj.getEmailAddress() : null)
        }) >> true
        0 * _ // No other interactions allowed


        and: "All attributes are validated"
        expectedEnt.eventName == eventName
        expectedEnt.billingAccountNumber == billingAccountNumber
        expectedEnt.sorId == "13"
        expectedEnt.serviceName == "MOBILITY"
        expectedEnt.firstName == firstName
        expectedEnt.lastName == lastName
        expectedEnt.contactEmail == (emailObj != null ? emailObj.getEmailAddress() : null)

        where: "Different account activation scenarios"
        scenarioName         | eventName         | billingAccountNumber | firstName | lastName | emailObj   |   expectedJsonValue

        "Standard activation" | "ActivateAccount" | "123456789" | "John" | "Doe" | Mock(Email) { getEmailAddress() >> "john.doe@example.com" } | '{"contactEmail":"john.doe@example.com","billingAccountNumber":"123456789","sorId":"13","serviceName":"MOBILITY","firstName":"John","lastName":"Doe"}'

        "Missing email" | "ActivateAccount" | "987654321" | "Jane" | "Smith" | null | '{"billingAccountNumber":"987654321","sorId":"13","serviceName":"MOBILITY","firstName":"Jane","lastName":"Smith"}'

        "Different event" | "ActivateAccount" | "555555555" | "Alice" | "Brown" | Mock(Email) { getEmailAddress() >> "alice.brown@example.com" } | '{"contactEmail":"alice.brown@example.com","billingAccountNumber":"555555555","sorId":"13","serviceName":"MOBILITY","firstName":"Alice","lastName":"Brown"}'

    }


    @Unroll
    def "should process valid text message for #scenarioName"() {
        given: "A valid TextMessage and mocked dependencies"
        TextMessage message = Mock(TextMessage)
        String payload = "{\"result\":\"ok\"}"
        String parsedJson = "{\"result\":\"ok\"}"

        when: "onMessage is called"
        jmsAcctNotificationService.onMessage(message)

        then: "TextMessage.getText is called, payload is parsed, and invalid structure is parked as VALIDATION_FAILED"
        1 * message.getText() >> payload
        1 * messageParserHelper.parseMessage(payload) >> parsedJson
        1 * messageParserHelper.generateTraceId() >> "test-trace-id"
        1 * resilientEventPublisher.saveValidationFailure(
                "gddnAccountNotifications",
                "Account",
                parsedJson,
                "Missing or unparseable AccountNotification / eventName")
        1 * message.acknowledge()
        0 * _

    }

    @Unroll
    def "should process valid text message for update account #scenarioName"() {
        given: "A valid TextMessage and mocked dependencies for update account"
        TextMessage message = Mock(TextMessage)
        String payload = "{\"MessageHeader\":{\"TrackingMessageHeader\":{\"version\":\"v144\",\"messageId\":\"TLSAN1197334412\",\"originatorId\":\"TLG\",\"timeToLive\":0,\"dateTimeStamp\":\"2025-09-11T08:00:16.894Z\"},\"SecurityMessageHeader\":{\"userName\":\"\",\"userPassword\":\"\"},\"SequenceMessageHeader\":{\"sequenceNumber\":\"1197334412\",\"totalInSequence\":1}},\"AccountNotification\":{\"eventName\":\"UpdateAccount\",\"billingSystemId\":\"TLG\",\"billingSystemEventGenerationDateTime\":\"2025-09-11T08:00:16.894Z\",\"Account\":{\"billingMarket\":{\"billingMarket\":\"SAN\",\"billingSubMarket\":\"TON\"},\"billingAccountNumber\":\"365032607323\",\"combinedBillingInfo\":{\"billingTelephoneNumber\":\"\",\"businessConsumerIndicator\":\"C\"},\"billingAccountPassword\":\"****\",\"securityLevel\":\"S\",\"passcodeEmailToken\":\"f7204cc0f2447d7a3dd66f2648600a06dbaf7a44\",\"passcdAutoGenDateTimeStamp\":\"2025-07-19T00:15:03.896Z\",\"AccountStatus\":{\"status\":\"A\",\"date\":\"2025-07-18Z\"},\"statusReason\":\"TS\",\"AccountCredit\":{\"creditClass\":\"B\"},\"AccountType\":{\"accountType\":\"I\",\"accountSubType\":\"R\",\"openChannel\":\"R\"},\"accountOpenDate\":\"2025-07-18Z\",\"glCompanyCode\":\"SB\",\"AccountBilling\":{\"billingCycle\":19,\"Balance\":{\"currentAmountDue\":8.03,\"totalAmountDue\":8.03,\"totalAmountPastDue\":0},\"combinedBillingIndicator\":\"N\"},\"BillingPreferences\":{\"doNotMailBillCode\":\"X\",\"numberOfBillsToPrint\":0,\"language\":\"E\",\"billDeliveryMethod\":\"P\"},\"Customer\":{\"name\":{\"firstName\":\"TAYLOR\",\"middleName\":\"DANIELLE\",\"lastName\":\"DEVILLIER\"},\"Address\":{\"effectiveDate\":\"2025-07-19T00:15:03.899Z\",\"linkType\":\"B\",\"addressType\":\"S\",\"incorporatedIndicator\":false,\"AddressLine1\":\"10111ANCIENTANCHOR\",\"addressPrimaryLine\":\"10111ANCIENTANCHOR\",\"Street\":{\"streetNumber\":\"10111\",\"streetName\":\"ANCIENTANCHOR\"},\"City\":\"SANANTONIO\",\"State\":\"TX\",\"Zip\":{\"zipCode\":\"****\",\"zipCodeExtension\":\"1625\",\"zipGeoCode\":\"440299116\"},\"Country\":\"US\"},\"Phone\":{\"homePhone\":\"1111110001\",\"workPhone\":\"1111110002\",\"canBeReachedPhone\":\"1111110002\"},\"Email\":{\"effectiveDate\":\"2025-07-19Z\",\"emailAddress\":\"DEVILLIER11@GMAIL.COM\",\"emailType\":\"B\",\"primaryAddressIndicator\":true},\"Identity\":{\"Identification\":{\"idType\":\"DL\",\"idNumber\":\"ln%}J\\\"T!\"},\"issuingAuthority\":\"TX\"},\"Birth\":{\"dateOfBirth\":\"****,d\"},\"socialSecurityNumberLastFourDigits\":\"****\",\"socialSecurityNumber\":\"****\"},\"DealerInfo\":{\"code\":\"029MO\"},\"Titan\":{\"titanBan\":\"339366515\",\"titanConvergeStatus\":\"ST\",\"titanConvergeStatusDate\":\"2025-09-11Z\"},\"AccountAttributes\":{\"attributeName\":\"DRVLICNS\",\"attributeValue\":\"****}J\\\"T!\"}},\"AccountChange\":{\"Account\":{\"billingSystemId\":\"TLG\",\"BillingPreferences\":{\"language\":\"E\"},\"Titan\":{\"titanConvergeStatus\":\"RT\"}}}}}"
        String parsedJson = "{\"MessageHeader\":{\"TrackingMessageHeader\":{\"version\":\"v144\",\"messageId\":\"TLSAN1197334412\",\"originatorId\":\"TLG\",\"timeToLive\":0,\"dateTimeStamp\":\"2025-09-11T08:00:16.894Z\"},\"SecurityMessageHeader\":{\"userName\":\"\",\"userPassword\":\"\"},\"SequenceMessageHeader\":{\"sequenceNumber\":\"1197334412\",\"totalInSequence\":1}},\"AccountNotification\":{\"eventName\":\"UpdateAccount\",\"billingSystemId\":\"TLG\",\"billingSystemEventGenerationDateTime\":\"2025-09-11T08:00:16.894Z\",\"Account\":{\"billingMarket\":{\"billingMarket\":\"SAN\",\"billingSubMarket\":\"TON\"},\"billingAccountNumber\":\"365032607323\",\"combinedBillingInfo\":{\"billingTelephoneNumber\":\"\",\"businessConsumerIndicator\":\"C\"},\"billingAccountPassword\":\"****\",\"securityLevel\":\"S\",\"passcodeEmailToken\":\"f7204cc0f2447d7a3dd66f2648600a06dbaf7a44\",\"passcdAutoGenDateTimeStamp\":\"2025-07-19T00:15:03.896Z\",\"AccountStatus\":{\"status\":\"A\",\"date\":\"2025-07-18Z\"},\"statusReason\":\"TS\",\"AccountCredit\":{\"creditClass\":\"B\"},\"AccountType\":{\"accountType\":\"I\",\"accountSubType\":\"R\",\"openChannel\":\"R\"},\"accountOpenDate\":\"2025-07-18Z\",\"glCompanyCode\":\"SB\",\"AccountBilling\":{\"billingCycle\":19,\"Balance\":{\"currentAmountDue\":8.03,\"totalAmountDue\":8.03,\"totalAmountPastDue\":0},\"combinedBillingIndicator\":\"N\"},\"BillingPreferences\":{\"doNotMailBillCode\":\"X\",\"numberOfBillsToPrint\":0,\"language\":\"E\",\"billDeliveryMethod\":\"P\"},\"Customer\":{\"name\":{\"firstName\":\"TAYLOR\",\"middleName\":\"DANIELLE\",\"lastName\":\"DEVILLIER\"},\"Address\":{\"effectiveDate\":\"2025-07-19T00:15:03.899Z\",\"linkType\":\"B\",\"addressType\":\"S\",\"incorporatedIndicator\":false,\"AddressLine1\":\"10111ANCIENTANCHOR\",\"addressPrimaryLine\":\"10111ANCIENTANCHOR\",\"Street\":{\"streetNumber\":\"10111\",\"streetName\":\"ANCIENTANCHOR\"},\"City\":\"SANANTONIO\",\"State\":\"TX\",\"Zip\":{\"zipCode\":\"****\",\"zipCodeExtension\":\"1625\",\"zipGeoCode\":\"440299116\"},\"Country\":\"US\"},\"Phone\":{\"homePhone\":\"1111110001\",\"workPhone\":\"1111110002\",\"canBeReachedPhone\":\"1111110002\"},\"Email\":{\"effectiveDate\":\"2025-07-19Z\",\"emailAddress\":\"DEVILLIER11@GMAIL.COM\",\"emailType\":\"B\",\"primaryAddressIndicator\":true},\"Identity\":{\"Identification\":{\"idType\":\"DL\",\"idNumber\":\"ln%}J\\\"T!\"},\"issuingAuthority\":\"TX\"},\"Birth\":{\"dateOfBirth\":\"****,d\"},\"socialSecurityNumberLastFourDigits\":\"****\",\"socialSecurityNumber\":\"****\"},\"DealerInfo\":{\"code\":\"029MO\"},\"Titan\":{\"titanBan\":\"339366515\",\"titanConvergeStatus\":\"ST\",\"titanConvergeStatusDate\":\"2025-09-11Z\"},\"AccountAttributes\":{\"attributeName\":\"DRVLICNS\",\"attributeValue\":\"****}J\\\"T!\"}},\"AccountChange\":{\"Account\":{\"billingSystemId\":\"TLG\",\"BillingPreferences\":{\"language\":\"E\"},\"Titan\":{\"titanConvergeStatus\":\"RT\"}}}}}"

        when: "onMessage is called"
        jmsAcctNotificationService.onMessage(message)

        then: "TextMessage.getText is called, messageParserHelper.parseMessage is invoked, and event is published"
        1 * message.getText() >> payload
        1 * messageParserHelper.parseMessage(payload) >> parsedJson
        1 * messageParserHelper.generateTraceId() >> "test-trace-id"
        1 * resilientEventPublisher.sendWithFallback("gddnAccountNotifications", "Account", null, { it instanceof AccountUpdateEvent && it.eventName == "UpdateAccount" && it.mobilityBan == null }) >> true
        1 * message.acknowledge()
        0 * _

    }

    @Unroll
    def "should process valid text message for close account #scenarioName"() {
        given: "A valid TextMessage and mocked dependencies for close account"
        TextMessage message = Mock(TextMessage)
        String payload = "{\"MessageHeader\":{\"TrackingMessageHeader\":{\"version\":\"v144\",\"messageId\":\"TLPAC7303378652\",\"originatorId\":\"TLG\",\"timeToLive\":0,\"dateTimeStamp\":\"2025-10-12T07:01:02.813Z\"},\"SecurityMessageHeader\":{\"userName\":\"\",\"userPassword\":\"\"},\"SequenceMessageHeader\":{\"sequenceNumber\":\"7303378652\",\"totalInSequence\":1}},\"AccountNotification\":{\"eventName\":\"CloseAccount\",\"billingSystemId\":\"TLG\",\"billingSystemEventGenerationDateTime\":\"2025-10-12T07:01:02.813Z\",\"Account\":{\"billingMarket\":{\"billingMarket\":\"PAC\",\"billingSubMarket\":\"SDG\"},\"billingAccountNumber\":\"337067001597\",\"combinedBillingInfo\":{\"billingTelephoneNumber\":\"\",\"businessConsumerIndicator\":\"C\"},\"AccountStatus\":{\"status\":\"X\",\"date\":\"2022-07-13Z\"},\"statusReason\":\"C10\",\"AccountCredit\":{\"creditClass\":\"B\"},\"AccountType\":{\"accountType\":\"I\",\"accountSubType\":\"R\",\"openChannel\":\"R\"},\"accountOpenDate\":\"2014-03-21Z\",\"glCompanyCode\":\"DL\",\"AccountBilling\":{\"billingCycle\":7,\"Balance\":{\"currentAmountDue\":0,\"totalAmountDue\":0,\"totalAmountPastDue\":0},\"combinedBillingIndicator\":\"N\"},\"BillingPreferences\":{\"doNotMailBillCode\":\"X\",\"numberOfBillsToPrint\":1,\"language\":\"E\",\"billDeliveryMethod\":\"X\"},\"Customer\":{\"name\":{\"firstName\":\"JEAN\",\"middleName\":\"T\",\"lastName\":\"RAMIREZ\"},\"Address\":{\"effectiveDate\":\"2014-02-22T18:14:28.82Z\",\"linkType\":\"B\",\"addressType\":\"S\",\"incorporatedIndicator\":true,\"AddressLine1\":\"1013TARLOCT\",\"addressPrimaryLine\":\"1013TARLOCT\",\"Street\":{\"streetNumber\":\"1013\",\"streetName\":\"TARLO\",\"streetType\":\"CT\"},\"City\":\"ELCAJON\",\"State\":\"CA\",\"Zip\":{\"zipCode\":\"****\",\"zipCodeExtension\":\"3132\",\"zipGeoCode\":\"050731030\"},\"Country\":\"US\"},\"Phone\":{\"homePhone\":\"2223334567\",\"workPhone\":\"6193125702\",\"canBeReachedPhone\":\"6264847245\"},\"Email\":{\"effectiveDate\":\"2014-03-04Z\",\"emailAddress\":\"RAMIREZJ@SANDIeGO.EDU\",\"emailType\":\"B\",\"primaryAddressIndicator\":true},\"Identity\":{\"socialSecurityNumberLastFourDigits\":\"****\",\"socialSecurityNumber\":\"****\"}},\"DealerInfo\":{\"code\":\"TDLS1\"},\"AccountAttributes\":{\"attributeName\":\"DLIFE\",\"attributeValue\":\"****\"}},\"AccountChange\":{\"Account\":{\"billingSystemId\":\"TLG\",\"BillingPreferences\":{\"language\":\"E\"},\"Customer\":{\"Phone\":{\"homePhone\":\"6194417724\"}}}}}}"
        String parsedJson = "{\"MessageHeader\":{\"TrackingMessageHeader\":{\"version\":\"v144\",\"messageId\":\"TLPAC7303378652\",\"originatorId\":\"TLG\",\"timeToLive\":0,\"dateTimeStamp\":\"2025-10-12T07:01:02.813Z\"},\"SecurityMessageHeader\":{\"userName\":\"\",\"userPassword\":\"\"},\"SequenceMessageHeader\":{\"sequenceNumber\":\"7303378652\",\"totalInSequence\":1}},\"AccountNotification\":{\"eventName\":\"CloseAccount\",\"billingSystemId\":\"TLG\",\"billingSystemEventGenerationDateTime\":\"2025-10-12T07:01:02.813Z\",\"Account\":{\"billingMarket\":{\"billingMarket\":\"PAC\",\"billingSubMarket\":\"SDG\"},\"billingAccountNumber\":\"337067001597\",\"combinedBillingInfo\":{\"billingTelephoneNumber\":\"\",\"businessConsumerIndicator\":\"C\"},\"AccountStatus\":{\"status\":\"X\",\"date\":\"2022-07-13Z\"},\"statusReason\":\"C10\",\"AccountCredit\":{\"creditClass\":\"B\"},\"AccountType\":{\"accountType\":\"I\",\"accountSubType\":\"R\",\"openChannel\":\"R\"},\"accountOpenDate\":\"2014-03-21Z\",\"glCompanyCode\":\"DL\",\"AccountBilling\":{\"billingCycle\":7,\"Balance\":{\"currentAmountDue\":0,\"totalAmountDue\":0,\"totalAmountPastDue\":0},\"combinedBillingIndicator\":\"N\"},\"BillingPreferences\":{\"doNotMailBillCode\":\"X\",\"numberOfBillsToPrint\":1,\"language\":\"E\",\"billDeliveryMethod\":\"X\"},\"Customer\":{\"name\":{\"firstName\":\"JEAN\",\"middleName\":\"T\",\"lastName\":\"RAMIREZ\"},\"Address\":{\"effectiveDate\":\"2014-02-22T18:14:28.82Z\",\"linkType\":\"B\",\"addressType\":\"S\",\"incorporatedIndicator\":true,\"AddressLine1\":\"1013TARLOCT\",\"addressPrimaryLine\":\"1013TARLOCT\",\"Street\":{\"streetNumber\":\"1013\",\"streetName\":\"TARLO\",\"streetType\":\"CT\"},\"City\":\"ELCAJON\",\"State\":\"CA\",\"Zip\":{\"zipCode\":\"****\",\"zipCodeExtension\":\"3132\",\"zipGeoCode\":\"050731030\"},\"Country\":\"US\"},\"Phone\":{\"homePhone\":\"2223334567\",\"workPhone\":\"6193125702\",\"canBeReachedPhone\":\"6264847245\"},\"Email\":{\"effectiveDate\":\"2014-03-04Z\",\"emailAddress\":\"RAMIREZJ@SANDIeGO.EDU\",\"emailType\":\"B\",\"primaryAddressIndicator\":true},\"Identity\":{\"socialSecurityNumberLastFourDigits\":\"****\",\"socialSecurityNumber\":\"****\"}},\"DealerInfo\":{\"code\":\"TDLS1\"},\"AccountAttributes\":{\"attributeName\":\"DLIFE\",\"attributeValue\":\"****\"}},\"AccountChange\":{\"Account\":{\"billingSystemId\":\"TLG\",\"BillingPreferences\":{\"language\":\"E\"},\"Customer\":{\"Phone\":{\"homePhone\":\"6194417724\"}}}}}}"

        when: "onMessage is called"
        jmsAcctNotificationService.onMessage(message)

        then: "TextMessage.getText is called, messageParserHelper.parseMessage is invoked, and event is published"
        1 * message.getText() >> payload
        1 * messageParserHelper.parseMessage(payload) >> parsedJson
        1 * messageParserHelper.generateTraceId() >> "test-trace-id"
        1 * resilientEventPublisher.sendWithFallback("gddnAccountNotifications", "Account", "337067001597", { it instanceof AccountCloseEvent && it.eventName == "CloseAccount" && it.billingAccountNumber == "337067001597" }) >> true
        1 * message.acknowledge()
        0 * _

    }

    @Unroll
    def "should process valid text message for activate account  #scenarioName"() {
        given: "A valid TextMessage and mocked dependencies for activate account"
        TextMessage message = Mock(TextMessage)
        String payload = "{\"MessageHeader\":{\"TrackingMessageHeader\":{\"version\":\"v144\",\"messageId\":\"TLPAC7303378652\",\"originatorId\":\"TLG\",\"timeToLive\":0,\"dateTimeStamp\":\"2025-10-12T07:01:02.813Z\"},\"SecurityMessageHeader\":{\"userName\":\"\",\"userPassword\":\"\"},\"SequenceMessageHeader\":{\"sequenceNumber\":\"7303378652\",\"totalInSequence\":1}},\"AccountNotification\":{\"eventName\":\"ActivateAccount\",\"billingSystemId\":\"TLG\",\"billingSystemEventGenerationDateTime\":\"2025-10-12T07:01:02.813Z\",\"Account\":{\"billingMarket\":{\"billingMarket\":\"PAC\",\"billingSubMarket\":\"SDG\"},\"billingAccountNumber\":\"337067001597\",\"combinedBillingInfo\":{\"billingTelephoneNumber\":\"\",\"businessConsumerIndicator\":\"C\"},\"AccountStatus\":{\"status\":\"X\",\"date\":\"2022-07-13Z\"},\"statusReason\":\"C10\",\"AccountCredit\":{\"creditClass\":\"B\"},\"AccountType\":{\"accountType\":\"I\",\"accountSubType\":\"R\",\"openChannel\":\"R\"},\"accountOpenDate\":\"2014-03-21Z\",\"glCompanyCode\":\"DL\",\"AccountBilling\":{\"billingCycle\":7,\"Balance\":{\"currentAmountDue\":0,\"totalAmountDue\":0,\"totalAmountPastDue\":0},\"combinedBillingIndicator\":\"N\"},\"BillingPreferences\":{\"doNotMailBillCode\":\"X\",\"numberOfBillsToPrint\":1,\"language\":\"E\",\"billDeliveryMethod\":\"X\"},\"Customer\":{\"name\":{\"firstName\":\"JEAN\",\"middleName\":\"T\",\"lastName\":\"RAMIREZ\"},\"Address\":{\"effectiveDate\":\"2014-02-22T18:14:28.82Z\",\"linkType\":\"B\",\"addressType\":\"S\",\"incorporatedIndicator\":true,\"AddressLine1\":\"1013TARLOCT\",\"addressPrimaryLine\":\"1013TARLOCT\",\"Street\":{\"streetNumber\":\"1013\",\"streetName\":\"TARLO\",\"streetType\":\"CT\"},\"City\":\"ELCAJON\",\"State\":\"CA\",\"Zip\":{\"zipCode\":\"****\",\"zipCodeExtension\":\"3132\",\"zipGeoCode\":\"050731030\"},\"Country\":\"US\"},\"Phone\":{\"homePhone\":\"2223334567\",\"workPhone\":\"6193125702\",\"canBeReachedPhone\":\"6264847245\"},\"Email\":{\"effectiveDate\":\"2014-03-04Z\",\"emailAddress\":\"RAMIREZJ@SANDIeGO.EDU\",\"emailType\":\"B\",\"primaryAddressIndicator\":true},\"Identity\":{\"socialSecurityNumberLastFourDigits\":\"****\",\"socialSecurityNumber\":\"****\"}},\"DealerInfo\":{\"code\":\"TDLS1\"},\"AccountAttributes\":{\"attributeName\":\"DLIFE\",\"attributeValue\":\"****\"}},\"AccountChange\":{\"Account\":{\"billingSystemId\":\"TLG\",\"BillingPreferences\":{\"language\":\"E\"},\"Customer\":{\"Phone\":{\"homePhone\":\"6194417724\"}}}}}}"
        String parsedJson = "{\"MessageHeader\":{\"TrackingMessageHeader\":{\"version\":\"v144\",\"messageId\":\"TLPAC7303378652\",\"originatorId\":\"TLG\",\"timeToLive\":0,\"dateTimeStamp\":\"2025-10-12T07:01:02.813Z\"},\"SecurityMessageHeader\":{\"userName\":\"\",\"userPassword\":\"\"},\"SequenceMessageHeader\":{\"sequenceNumber\":\"7303378652\",\"totalInSequence\":1}},\"AccountNotification\":{\"eventName\":\"ActivateAccount\",\"billingSystemId\":\"TLG\",\"billingSystemEventGenerationDateTime\":\"2025-10-12T07:01:02.813Z\",\"Account\":{\"billingMarket\":{\"billingMarket\":\"PAC\",\"billingSubMarket\":\"SDG\"},\"billingAccountNumber\":\"337067001597\",\"combinedBillingInfo\":{\"billingTelephoneNumber\":\"\",\"businessConsumerIndicator\":\"C\"},\"AccountStatus\":{\"status\":\"X\",\"date\":\"2022-07-13Z\"},\"statusReason\":\"C10\",\"AccountCredit\":{\"creditClass\":\"B\"},\"AccountType\":{\"accountType\":\"I\",\"accountSubType\":\"R\",\"openChannel\":\"R\"},\"accountOpenDate\":\"2014-03-21Z\",\"glCompanyCode\":\"DL\",\"AccountBilling\":{\"billingCycle\":7,\"Balance\":{\"currentAmountDue\":0,\"totalAmountDue\":0,\"totalAmountPastDue\":0},\"combinedBillingIndicator\":\"N\"},\"BillingPreferences\":{\"doNotMailBillCode\":\"X\",\"numberOfBillsToPrint\":1,\"language\":\"E\",\"billDeliveryMethod\":\"X\"},\"Customer\":{\"name\":{\"firstName\":\"JEAN\",\"middleName\":\"T\",\"lastName\":\"RAMIREZ\"},\"Address\":{\"effectiveDate\":\"2014-02-22T18:14:28.82Z\",\"linkType\":\"B\",\"addressType\":\"S\",\"incorporatedIndicator\":true,\"AddressLine1\":\"1013TARLOCT\",\"addressPrimaryLine\":\"1013TARLOCT\",\"Street\":{\"streetNumber\":\"1013\",\"streetName\":\"TARLO\",\"streetType\":\"CT\"},\"City\":\"ELCAJON\",\"State\":\"CA\",\"Zip\":{\"zipCode\":\"****\",\"zipCodeExtension\":\"3132\",\"zipGeoCode\":\"050731030\"},\"Country\":\"US\"},\"Phone\":{\"homePhone\":\"2223334567\",\"workPhone\":\"6193125702\",\"canBeReachedPhone\":\"6264847245\"},\"Email\":{\"effectiveDate\":\"2014-03-04Z\",\"emailAddress\":\"RAMIREZJ@SANDIeGO.EDU\",\"emailType\":\"B\",\"primaryAddressIndicator\":true},\"Identity\":{\"socialSecurityNumberLastFourDigits\":\"****\",\"socialSecurityNumber\":\"****\"}},\"DealerInfo\":{\"code\":\"TDLS1\"},\"AccountAttributes\":{\"attributeName\":\"DLIFE\",\"attributeValue\":\"****\"}},\"AccountChange\":{\"Account\":{\"billingSystemId\":\"TLG\",\"BillingPreferences\":{\"language\":\"E\"},\"Customer\":{\"Phone\":{\"homePhone\":\"6194417724\"}}}}}}"

        when: "onMessage is called"
        jmsAcctNotificationService.onMessage(message)

        then: "TextMessage.getText is called, messageParserHelper.parseMessage is invoked, and event is published"
        1 * message.getText() >> payload
        1 * messageParserHelper.parseMessage(payload) >> parsedJson
        1 * messageParserHelper.generateTraceId() >> "test-trace-id"
        1 * resilientEventPublisher.sendWithFallback("gddnAccountNotifications", "Account", "337067001597", { it instanceof AccountActivationEvent && it.eventName == "ActivateAccount" && it.billingAccountNumber == "337067001597" }) >> true
        1 * message.acknowledge()
        0 * _

    }

    def "should handle exception when message parsing fails"() {
        given: "A TextMessage with invalid payload"
        TextMessage message = Mock(TextMessage)
        String invalidPayload = "invalid-json"

        when: "onMessage is called"
        jmsAcctNotificationService.onMessage(message)

        then: "TextMessage.getText and messageParserHelper.parseMessage are called, exception thrown"
        1 * message.getText() >> invalidPayload
        1 * messageParserHelper.parseMessage(invalidPayload) >> { throw new RuntimeException("Parse error") }
        0 * _

        and: "No exception is thrown"
    }

    def "should initialize JMS consumer on init"() {
        given: "Mocked JMS setup"

        when: "init is called"
        jmsAcctNotificationService.init()

        then: "JMS connection/session/consumer are created and started"
        1 * connectionFactory.createConnection() >> connection
        1 * connection.createSession(false, Session.CLIENT_ACKNOWLEDGE) >> session
        1 * session.createQueue("testQueue") >> queue
        1 * session.createConsumer(queue) >> consumer
        1 * consumer.setMessageListener({ it != null })
        1 * connection.start()
        0 * _
    }

    def "should cleanup JMS resources on shutdown"() {
        given: "JMS resources are set"
        ReflectionTestUtils.setField(jmsAcctNotificationService, "consumer", consumer)
        ReflectionTestUtils.setField(jmsAcctNotificationService, "session", session)
        ReflectionTestUtils.setField(jmsAcctNotificationService, "connection", connection)

        when: "cleanup is called"
        jmsAcctNotificationService.cleanup()

        then: "All JMS resources are closed"
        1 * consumer.close()
        1 * session.close()
        1 * connection.close()
        0 * _
    }

    @Unroll
    def "should close account and publish event for #scenarioName"() {
        given: "A valid AccountNotificationMessage for account closure"
        AccountNotificationMessage closeNotificationMsg = new AccountNotificationMessage()
        AccountNotification acctNotification = new AccountNotification()
        Account account = new Account()
        account.setBillingAccountNumber(billingAccountNumber)
        acctNotification.setAccount(account)
        acctNotification.setEventName(eventName)
        closeNotificationMsg.setAccountNotification(acctNotification)

        AccountCloseEvent expectedEvent = new AccountCloseEvent()
        expectedEvent.setEventName(eventName)
        expectedEvent.setBillingAccountNumber(billingAccountNumber)
        expectedEvent.setTlgMessageId("13")

        String expectedJson = expectedJsonValue

        when: "closeAccount is called"
        jmsAcctNotificationService."closeAccount"(closeNotificationMsg, "test-trace-id")

        then: "ResilientEventPublisher sends the event via the correct binding"
        1 * resilientEventPublisher.sendWithFallback("gddnAccountNotifications", "Account", billingAccountNumber, {
            it instanceof AccountCloseEvent &&
                    it.eventName == eventName &&
                    it.billingAccountNumber == billingAccountNumber
        }) >> true
        0 * _ // No other interactions allowed

        and: "All attributes are validated"
        expectedEvent.eventName == eventName
        expectedEvent.billingAccountNumber == billingAccountNumber
        expectedEvent.tlgMessageId == "13"

        where: "Different account closure scenarios"
        scenarioName         | eventName         | billingAccountNumber | tlgMessageId | expectedJsonValue
        "Standard closure"   | "CloseAccount"    | "123456789"         | "13"         | '{"billingAccountNumber":"123456789"}'

    }

    @Unroll
    def "should update account and publish event for #scenarioName"() {
        given: "A valid AccountNotificationMessage for account update"
        AccountNotificationMessage closeNotificationMsg = new AccountNotificationMessage()
        AccountNotification acctNotification = new AccountNotification()
        Account account = new Account()
        account.setBillingAccountNumber(billingAccountNumber)
        acctNotification.setAccount(account)
        acctNotification.setEventName(eventName)
        closeNotificationMsg.setAccountNotification(acctNotification)

        AccountUpdateEvent expectedEvent = new AccountUpdateEvent()
        expectedEvent.setEventName(eventName)
        expectedEvent.setTlgMessageId("13")

        String expectedJson = expectedJsonValue

        when: "updateAccount is called"
        jmsAcctNotificationService."updateAccount"(closeNotificationMsg, "test-trace-id")

        then: "ResilientEventPublisher sends the event via the correct binding"
        1 * resilientEventPublisher.sendWithFallback("gddnAccountNotifications", "Account", null, {
            it instanceof AccountUpdateEvent &&
                    it.eventName == eventName &&
                    it.mobilityBan == null
        }) >> true
        0 * _ // No other interactions allowed

        and: "All attributes are validated"
        expectedEvent.eventName == eventName
        expectedEvent.tlgMessageId == "13"

        where: "Different account closure scenarios"
        scenarioName         | eventName         | billingAccountNumber | tlgMessageId | expectedJsonValue
        "Standard closure"   | "UpdateAccount"    | "123456789"         | "13"         | '{"billingAccountNumber":"123456789"}'

    }

}
