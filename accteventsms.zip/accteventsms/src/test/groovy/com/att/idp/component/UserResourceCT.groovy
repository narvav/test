
package com.att.idp.component


import com.att.idp.idgraphaccteventsms.model.User
import com.att.idp.idgraphaccteventsms.repository.UserRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.web.client.TestRestTemplate
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import spock.lang.Specification
import spock.lang.Unroll
import org.spockframework.spring.SpringBean

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class UserResourceCT extends Specification {


    @SpringBean
    TestRestTemplate restTemplate = Mock(TestRestTemplate)


    @Unroll
    def "should return null for get user "() {
        given: "A user exists in the database"
        String userId = "user-100"
        User user = new User('user-100')
        user.name = 'Alice Smith'

        when: "GET /v1/users/{userId} is called"
        ResponseEntity<Map> response = restTemplate.getForEntity("/v1/users/${userId}", Map)

        then: "Response is null"
        response == null
    }

    @Unroll
    def "should return null for create user "() {
        given: "A valid user payload"
        String userId = "user-201"
        Map<String, Object> userPayload = [id: userId, name: "Bob Johnson"]
        HttpHeaders headers = new HttpHeaders()
        headers.setContentType(MediaType.APPLICATION_JSON)
        HttpEntity<Map<String, Object>> request = new HttpEntity<>(userPayload, headers)

        when: "POST /v1/users is called"
        ResponseEntity<Void> response = restTemplate.postForEntity("/v1/users", request, Void)

        then: "Response is null"
        response == null
    }

    @Unroll
    def "should return null for invalid user creation"() {
        given: "An invalid user payload"
        Map<String, Object> userPayload = invalidPayload
        HttpHeaders headers = new HttpHeaders()
        headers.setContentType(MediaType.APPLICATION_JSON)
        HttpEntity<Map<String, Object>> request = new HttpEntity<>(userPayload, headers)

        when: "POST /v1/users is called"
        ResponseEntity<Map> response = restTemplate.postForEntity("/v1/users", request, Map)

        then: "Response is 400"
        response == null

        where:
        scenarioName      | invalidPayload
        "missing name"    | [id: "user-x"]
        "null body"       | null
    }
}