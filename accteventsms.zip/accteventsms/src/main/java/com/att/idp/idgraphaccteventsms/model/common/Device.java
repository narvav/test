package com.att.idp.idgraphaccteventsms.model.common;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Device implements Serializable {

    private static final long serialVersionUID = 1L;

    private String equipmentType;
    private String technologyType;
    private String IMSI;
    private String IMEI;

    @JsonAlias("imeiType")
    private String IMEIType;

    private String SIM;
    private Manufacturer manufacturer;
    private String smsCapabilityIndicator;
    private String umtsCapability;
}
