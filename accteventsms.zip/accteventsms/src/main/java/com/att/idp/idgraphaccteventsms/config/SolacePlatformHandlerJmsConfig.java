package com.att.idp.idgraphaccteventsms.config;

import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.InitialContext;

import com.solacesystems.jms.SupportedProperty;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
import javax.jms.ConnectionFactory;

/**
 * Solace JMS configuration for Spring Boot.
 */
@Configuration
@EnableJms
public class SolacePlatformHandlerJmsConfig {

    public static final Logger logger = LoggerFactory.getLogger(SolacePlatformHandlerJmsConfig.class);

    @Value("${platform.handler.context.factory}")
    private String initialContextFactory;

    @Value("${platform.handler.url}")
    private String providerUrl;

    @Value("${platform.handler.user.name}")
    private String username;

    @Value("${platform.handler.password}")
    private String password;

    @Value("${platform.handler.cfjndi.name}")
    private String cfJndiName;

    @Value("${platform.handler.vpn}")
    private String vpn;

    @Value("${platform.handler.compression.level}")
    private String compressionLevel;

    @Value("${platform.handler.optimize.direct}")
    private String optimizeDirect;


    @Bean("solacePFHandlerConnectionFactory")
    public ConnectionFactory connectionFactory() throws Exception {

        Hashtable<String, String> env = new Hashtable<>();
        env.put(InitialContext.INITIAL_CONTEXT_FACTORY, initialContextFactory);
        env.put(InitialContext.PROVIDER_URL, providerUrl);

        // Defensive null checks and logging
        if (username == null || username.isEmpty()) {
            logger.error("Solace JMS username is missing");
            throw new IllegalArgumentException("Solace JMS username must be specified");
        }
        if (password == null || password.isEmpty()) {
            logger.error("Solace JMS password is missing");
            throw new IllegalArgumentException("Solace JMS password must be specified");
        }
        if (vpn == null || vpn.isEmpty()) {
            logger.error("Solace JMS VPN is missing");
            throw new IllegalArgumentException("Solace JMS VPN must be specified");
        }
        if (cfJndiName == null || cfJndiName.isEmpty()) {
            logger.error("Solace JMS ConnectionFactory JNDI name is missing");
            throw new IllegalArgumentException("Solace JMS ConnectionFactory JNDI name must be specified");
        }

        logger.info("Connecting to Solace JMS: providerUrl={}, vpn={}, cfJndiName={}", ESAPI.encoder().encodeForHTML(providerUrl), ESAPI.encoder().encodeForHTML(vpn), ESAPI.encoder().encodeForHTML(cfJndiName));

        env.put(Context.SECURITY_PRINCIPAL, username);
        env.put(Context.SECURITY_CREDENTIALS, password);
        env.put(SupportedProperty.SOLACE_JMS_VPN, vpn);
        env.put(SupportedProperty.SOLACE_JMS_COMPRESSION_LEVEL, compressionLevel);
        env.put(SupportedProperty.SOLACE_JMS_OPTIMIZE_DIRECT, optimizeDirect);

        InitialContext context = new InitialContext(env);
        return (ConnectionFactory) context.lookup(cfJndiName);
    }
}
