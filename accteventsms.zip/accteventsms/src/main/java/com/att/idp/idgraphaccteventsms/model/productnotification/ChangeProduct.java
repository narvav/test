package com.att.idp.idgraphaccteventsms.model.productnotification;

import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
/**
 * Represents change product event details.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChangeProduct implements Serializable {
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private String eventName;
    private String contactEmail;
    private String billingAccountNumber;
    private String sorId;
    private String serviceName;
    private String isConnectedCar;
    private String firstName;
    private String lastName;
    private String eventId;
    private String eventTime;
    private String tlgMessageId;
}