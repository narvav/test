package com.att.idp.idgraphaccteventsms.model.accountnotification;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.att.idp.idgraphaccteventsms.model.common.MessageHeader;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.io.Serializable;

/**
 * Account Notification message details.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountNotificationMessage implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private MessageHeader messageHeader;
    private AccountNotification accountNotification;

}