package com.att.idp.idgraphaccteventsms.config;

import java.util.logging.Logger;

import com.att.idp.idgraphaccteventsms.resource.UserResourceImpl;
import jakarta.ws.rs.ApplicationPath;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.idp.core.config.BaseJerseyConfiguration; // Seed 2.4.0, 'idp-config' new repository in CodeCloud
import com.att.idp.shutdown.jersey.adapter.JerseyShutdownAdapter; // Seed 2.5.0, Jersey default shutdown behavior
import com.att.idp.shutdown.jersey.filter.AfterResourceResponseFilter;
import com.att.idp.shutdown.jersey.filter.BeforeResourceRequestFilter;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;


/**
 * This Class reads and sets all configuration related to Jersey
 * 
 * 
 */
@OpenAPIDefinition(info = @Info(title = "IDGraphAcctEventsMs Service",
		version = "2.9.0",
		description = "IDGraphAcctEventsMs"),servers = {@Server(url = "/msapi")})
@Component
@ApplicationPath("/idgraphaccteventsms/v1")
public class JerseyConfiguration extends BaseJerseyConfiguration {

	
	/*Please do not edit or remove the LOGGER_NAME name declaration as it is critical
	*to have this identifier for server side logging
	*/	
	public final static String LOGGER_NAME="com.att.idp.logging.server.JerseyLogging";
	private static final Logger log = Logger.getLogger(LOGGER_NAME);

    /**
	 * This is the main constructor which register the Jersey configs
	 * 
	 * @param pJerseyShutdownAdapter
	 *            - added in Seed 2.5.0, will be autowired with
	 *            JerseyShutdownAdapter started by idp-shutdown-jersey module
	 */
	@Autowired
    public JerseyConfiguration(
			@Autowired JerseyShutdownAdapter pJerseyShutdownAdapter) {
		super();
		register(UserResourceImpl.class);
		// TODO: You will add your various microservice-specific register(YourResourceImpl.class), here.
		
		// Seed 2.5.0, filters to count in progress requests:
		register(new BeforeResourceRequestFilter(pJerseyShutdownAdapter));
		register(new AfterResourceResponseFilter(pJerseyShutdownAdapter));
    }

}