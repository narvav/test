package com.att.idp.idgraphaccteventsms.utils;

import static org.apache.commons.lang3.StringUtils.isBlank;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/**
 * Utility class used to create and handle Json string. It facilitates
 * conversion from Object to Json String and from Json String to Object.
 */
public final class JsonService {

    private static final Logger LOGGER = LoggerFactory.getLogger(JsonService.class);

    private static final ObjectMapper MAPPER;

    private JsonService() {

    }

    static {
        MAPPER = new ObjectMapper();
        MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        MAPPER.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        MAPPER.setSerializationInclusion(Include.NON_NULL);
        MAPPER.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);


        MAPPER.setPropertyNamingStrategy(PropertyNamingStrategies.LOWER_CAMEL_CASE);
        MAPPER.setSerializationInclusion(Include.NON_EMPTY);
        MAPPER.configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true);
        MAPPER.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        MAPPER.enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES);
        MAPPER.enable(DeserializationFeature.READ_ENUMS_USING_TO_STRING);
        MAPPER.configure(MapperFeature.AUTO_DETECT_SETTERS, true);

    }

    /**
     * Takes an object as parameter and converts it into json string format like
     * {"dataValue":"Data Value","cloudType":"cart"}.
     *
     * @param object
     *            holds the object which need to be converted into json string
     * @return Json String
     */
    public static String getJsonFromObject(final Object object) {
        String jsonString = null;
        try {
            jsonString = MAPPER.writeValueAsString(object);
        } catch (JsonProcessingException jex) {
            LOGGER.error("JsonProcessingException occurred when converting  to Json from Object: " + jex);
        }

        return jsonString;
    }

    /**
     * Takes an object as parameter and converts it into json string format like
     * {"dataValue":"Data Value","cloudType":"cart"}.
     *
     * @param object
     *            holds the object which need to be converted in json string
     * @return Json String
     */
    public static String getJsonWithPrettyPrintFromObject(final Object object) {
        String jsonString = null;
        try {
            jsonString = MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(object);
        } catch (JsonProcessingException jex) {
            LOGGER.error("JsonProcessingException occurred when converting Json with Pretty from Object: " + jex);
        }

        return jsonString;
    }

    /**
     * Takes Json object as parameter and converts the Json string as object of
     * valueType.
     *
     * @param <T>
     *            the generic type
     * @param jsonString
     *            holds the json string which needs to be converted in object
     * @param valueType
     *            describe the type in which json string needs to converted
     * @return <T>
     */

    public static <T> T getObjectFromJson(final Object jsonString, final Class<T> valueType) {
        T object = null;
        if (jsonString != null) {
            try {
                object = MAPPER.readValue(jsonString.toString(), valueType);
            } catch (IOException jex) {
                LOGGER.error("IOException occurred when converting Json to Object: " + jex);
            }
        }
        return object;
    }

    /**
     * This method is part of the JsonService class in the com.att.idp.idgraphcontactinfoms.utils package.
     *
     * The shortenedStackTrace method is used to extract a specified number of lines from the stack trace of an exception.
     * It takes an Exception and an integer as input. The Exception is the one from which the stack trace is to be extracted, and the integer specifies the maximum number of lines to be extracted from the stack trace.
     *
     * The method first converts the stack trace of the Exception into a string using a StringWriter and a PrintWriter.
     * It then splits the string into an array of lines, and appends the specified number of lines to a StringBuilder.
     * The method then returns the string representation of the StringBuilder, which contains the extracted lines from the stack trace.
     *
     * This method is useful when you need to log or display a limited number of lines from a stack trace, for example, when you want to avoid cluttering your log files or user interface with long stack traces.
     *
     * @param e The Exception from which the stack trace is to be extracted.
     * @param maxLines The maximum number of lines to be extracted from the stack trace.
     * @return A string containing the extracted lines from the stack trace.
     */
    public static String shortenedStackTrace(Exception e, int maxLines) {
        StringWriter writer = new StringWriter();
        e.printStackTrace(new PrintWriter(writer));
        String[] lines = writer.toString().split("\n");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(lines.length, maxLines); i++) {
            sb.append(lines[i]).append("\n");
        }
        return sb.toString();
    }

    /**
     * Takes Json node as parameter and converts it into object of valueType.
     *
     * @param <T>
     *            the generic type
     * @param jsonNode
     *            holds the json node which needs to be converted in object
     * @param valueType
     *            describe the type in which json node needs to converted
     * @return <T>
     */
    public static <T> T getObjectFromJsonNode(final JsonNode jsonNode, final Class<T> valueType) {
        T object = null;
        try {
            object = MAPPER.treeToValue(jsonNode, valueType);

        } catch (JsonProcessingException jex) {
            LOGGER.error("JsonProcessingException occurred when converting Json node to Object: " + jex);
        }

        return object;
    }

    public static ObjectMapper getMapper() {
        return MAPPER.copy();
    }

    /**
     * This method is part of the JsonService class in the com.att.idp.idgraphcontactinfoms.utils package.
     *
     * The isValidJson method is used to check if a given string is a valid JSON string.
     * It takes a string as input and tries to convert it to a JsonNode using the convertToJson method.
     * If the conversion is successful, the method returns true, indicating that the input string is a valid JSON string.
     * If the conversion fails (for example, if the input string is not a valid JSON string), the method returns false.
     *
     * This method is useful when you need to validate a JSON string before processing it, for example, when you receive a JSON string from an external source and you want to ensure that it is valid before parsing it.
     *
     * @param inputJson The string to be checked for validity as a JSON string.
     * @return A boolean indicating whether the input string is a valid JSON string. Returns true if the input string is a valid JSON string, and false otherwise.
     */
    public static boolean isValidJson(String inputJson) {
        return convertToJson(inputJson) != null;
    }

    /**
     * This method is part of the JsonService class in the com.att.idp.idgraphcontactinfoms.utils package.
     *
     * The convertToJson method is used to convert a string into a JsonNode.
     * It takes a string as input and tries to convert it to a JsonNode using the readTree method of the ObjectMapper class.
     * If the conversion is successful, the method returns the resulting JsonNode.
     * If the conversion fails (for example, if the input string is not a valid JSON string), the method returns null.
     *
     * This method is useful when you need to convert a JSON string into a JsonNode, for example, when you need to parse a JSON string and work with its structure.
     *
     * @param inputJson The string to be converted to a JsonNode.
     * @return A JsonNode representing the parsed JSON, or null if the parsing fails.
     */
    public static JsonNode convertToJson(String inputJson) {
        if (isBlank(inputJson)) {
            return null;
        }

        try {
            return MAPPER.readTree(inputJson);
        } catch (JsonProcessingException e) {
            LOGGER.error("JsonProcessingException occurred when converting  to Json from String: " + e);
            return null;
        }
    }

    /**
     * This method is part of the JsonService class in the com.att.idp.idgraphcontactinfoms.utils package.
     *
     * The convertToObject method is used to convert a JSON string into an object of a specified class.
     * It takes a JSON string and a Class object as input. The JSON string is the one to be converted, and the Class object specifies the type of the object to be returned.
     *
     * The method first converts the JSON string into a JsonNode using the convertToJson method.
     * If the conversion is successful, the method then tries to convert the JsonNode into an object of the specified class using the readValue method of the ObjectMapper class.
     * If the conversion is successful, the method returns the resulting object.
     * If any conversion fails (for example, if the JSON string is not a valid JSON string, or if the JsonNode cannot be converted into an object of the specified class), the method returns null.
     *
     * This method is useful when you need to convert a JSON string into an object of a specific class, for example, when you receive a JSON string from an external source and you want to parse it into an object of a specific class for further processing.
     *
     * @param inputJson The JSON string to be converted to an object.
     * @param theClass The Class object that represents the type of the object to be returned.
     * @return An object of the specified class representing the parsed JSON, or null if any conversion fails.
     */
    public static <T> T convertToObject(String inputJson, Class<T> theClass) {
        JsonNode jsonNode = convertToJson(inputJson);
        return convertToObject(jsonNode, theClass);
    }

    /**
     * This method is part of the JsonService class in the com.att.idp.idgraphcontactinfoms.utils package.
     *
     * The convertToObject method is used to convert a JsonNode into an object of a specified class.
     * It takes a JsonNode and a Class object as input. The JsonNode is the one to be converted, and the Class object specifies the type of the object to be returned.
     *
     * The method first checks if the JsonNode is null. If it is, the method returns null.
     * If the JsonNode is not null, the method then tries to convert the JsonNode into an object of the specified class using the readValue method of the ObjectMapper class.
     * If the conversion is successful, the method returns the resulting object.
     * If the conversion fails (for example, if the JsonNode cannot be converted into an object of the specified class), the method logs an error message and returns null.
     *
     * This method is useful when you need to convert a JsonNode into an object of a specific class, for example, when you have parsed a JSON string into a JsonNode and you want to convert it into an object of a specific class for further processing.
     *
     * @param jsonNode The JsonNode to be converted to an object.
     * @param theClass The Class object that represents the type of the object to be returned.
     * @return An object of the specified class representing the parsed JsonNode, or null if the conversion fails.
     */
    public static <T> T convertToObject(JsonNode jsonNode, Class<T> theClass) {
        if (jsonNode == null) {
            return null;
        }

        try {
            return MAPPER.readValue(jsonNode.toString(), theClass);
        } catch (Exception e) {
            String errorMsg = new StringBuilder().append("JSON Mapping Exception: Could not convert the input: [").append(jsonNode.toString()).append("] to object of Class: [").append(theClass.getName()).append("].").toString();
            LOGGER.error(StringUtils.normalizeSpace(errorMsg), e);
        }

        return null;
    }

    /**
     * This method is part of the JsonService class in the com.att.idp.idgraphcontactinfoms.utils package.
     *
     * The toJsonString method is used to convert an object into a JSON string.
     * It takes an object as input and tries to convert it to a JSON string using the writeValueAsString method of the ObjectMapper class.
     * If the conversion is successful, the method returns the resulting JSON string.
     * If the conversion fails (for example, if the object cannot be serialized to a JSON string), the method logs an error message and returns the string "EMPTY_JSON".
     *
     * This method is useful when you need to convert an object into a JSON string, for example, when you need to send an object as a JSON string to an external service.
     *
     * @param obj The object to be converted to a JSON string.
     * @return A JSON string representing the serialized object, or "EMPTY_JSON" if the serialization fails.
     */
    public static String toJsonString(Object obj) {
        if (obj == null) {
            return "EMPTY_JSON";
        }

        try {
            return MAPPER.writeValueAsString(obj);
        } catch (Exception e) {
            String errorMsg = new StringBuilder().append("JSON Serialization Exception: Could not serialize the input object of Class: [").append(obj.getClass().getName()).append("]").toString();
            LOGGER.error(StringUtils.normalizeSpace(errorMsg), e);
        }

        return "EMPTY_JSON";
    }

}

