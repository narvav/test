package com.att.idp.idgraphaccteventsms.model.subscription;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.att.idp.idgraphaccteventsms.model.common.Device;
import java.io.Serializable;
import java.util.List;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;


/**
 * Subscriber details.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Subscriber implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private String inServiceDate;
    private String subscriberStatus;
    private String statusReason;
    private ContractTerm contractTerm;
    private ContactInformation contactInformation;
    private String paymentType;
    private PricePlan pricePlan;
    private List<AdditionalOffering> additionalOfferings;
    private Discounts discounts;
    private String sid;
    private String militaryStatusIndicator;
    private String subscriberNumber;
    private String subId;
    private Device device;

}

