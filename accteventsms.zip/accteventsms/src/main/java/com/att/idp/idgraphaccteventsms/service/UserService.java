package com.att.idp.idgraphaccteventsms.service;

import com.att.idp.idgraphaccteventsms.model.User;

public interface UserService {
    /**
     * Service definition which takes User's ID as input 
     *
     * @param userId - ID of the user being searched
     * 
     * @return User - Returns the details of the users being searched
     */
	public User getUser(String userId);	

	/**
     * Service definition for User Creation
     *
     * @param user- Object instance of the User to be created
     *
     * @return User - Returns the details of the users created
     */
	public User createUser(User user);

	/**
     * Service definition for User Updates
     *
     * @param user- Object instance of the User to be updated
     *
     * @return User - Returns the details of the user updated
     */
	public User updateUser(User user);	
	
	/**
     * Method definition for User Creation. Added to test the caching implementation using String
     *
     * @param user- json String 
     * 
     * @return User - Returns the details of the users created in String format
     */
	public String createUserFromString(String user);

	/**
     * Method definition which takes User's ID as input. Added to test the caching implementation using String
     *
     * @param userId - ID of the user being searched
     * 
     * @return String - Returns the details of the users being searched in String format
     */
	public String getUserString(String userId);	

}
