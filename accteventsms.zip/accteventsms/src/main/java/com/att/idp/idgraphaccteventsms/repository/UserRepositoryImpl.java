        package com.att.idp.idgraphaccteventsms.repository;

import com.att.idp.idgraphaccteventsms.model.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;


/**
 * Repository implementation using HashMap as store
 */
@Repository
public class UserRepositoryImpl implements UserRepository {

    private static final Logger log = LoggerFactory.getLogger(UserRepositoryImpl.class);

    private Map<String, User> repo = new ConcurrentHashMap<>();

    @Override
    public User getUser(String userId) {
        if (log.isInfoEnabled()) {
            log.info("getUser called for userId");
        }
        return repo.get(userId);
    }

    @Override
    public User createUser(User user) {
		if (user.getId() == null || user.getId().isEmpty()) {
            user.setId(UUID.randomUUID().toString());
        }

        repo.put(user.getId(), user);
        return user;
    }

    @Override
    public String createUserFromString(String strUser) {

        User user = new User();
        user.setId("Test123");
        user.setName("String User");
        repo.put(user.getId(), user);
        return strUser;
    }

    @Override
    public String getUserString(String userId) {

        return userId;
    }
}
