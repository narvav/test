package com.att.idp.idgraphaccteventsms.model.platformhandler;


import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;

/**
 * Represents the Header object containing transaction and source details.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Header implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private String sourceSystem;
    private String gridTxnID;
    private String transactionTS;
    private Attributes attributes;
    private String sourceBusinessLine;
    private String txnReceivedTS;
    private String transactionID;
}
