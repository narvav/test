package com.att.idp.idgraphaccteventsms.repository;

import com.att.idp.idgraphaccteventsms.model.User;

public interface UserRepository {

    /**
     * Method definition which takes User's ID as input
     *
     * @param userId - ID of the user being searched
     *
     * @return User - Returns the details of the users being searched
     */

	public User getUser(String userId);

	/**
     * Method definition for User Creation
     *
     * @param user- Object instance of the User to be created
     *
     * @return User - Returns the details of the users created
     */
	public User createUser(User user);

	/**
     * Method definition for User Creation. Added to test the caching implementation using String
     *
     * @param user- json String
     *
     * @return User - Returns the details of the users created in String format
     */
	public String createUserFromString(String user);

	/**
     * Method definition which takes User's ID as input. Added to test the caching implementation using String
     *
     * @param userId - ID of the user being searched
     * 
     * @return String - Returns the details of the users being searched in String format
     */
	public String getUserString(String userId);

}
