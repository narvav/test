package com.att.idp.idgraphaccteventsms.model.rgnotification;

import lombok.Data;
import lombok.Builder;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Represents an Rg Activation Event.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RgActivationEvent implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private String eventName;
    private String tlgMessageId;
    private String accountNumber;
    private String serialNumber;
    private String eventId;
    private String eventTime;
}