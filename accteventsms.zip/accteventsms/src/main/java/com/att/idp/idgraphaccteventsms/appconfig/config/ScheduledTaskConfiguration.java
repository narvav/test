package com.att.idp.idgraphaccteventsms.appconfig.config;

import com.azure.spring.cloud.appconfiguration.config.AppConfigurationRefresh;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import java.util.Objects;

/**
 * Configuration class for scheduling tasks.
 */
@Configuration
@EnableScheduling
public class ScheduledTaskConfiguration {

    private static final String TASK_NAME_SCHEDULED_APP_CONFIG_PRINTER = "scheduledAppConfigPrinter";
    private static final Logger logger = LoggerFactory
            .getLogger(ScheduledTaskConfiguration.class.getName() + "." + TASK_NAME_SCHEDULED_APP_CONFIG_PRINTER);

    @Autowired
    private IDGraphAzureAppConfig appConfiguration;

    @Autowired
    private AppConfigurationRefresh appConfigurationRefresh;

    // Track previous state to log only on configuration changes
    private String previousConfigState = null;


    @Scheduled(initialDelayString = "30000", fixedDelayString = "30000")
    public void doScheduledAppConfigPrinter() throws Exception {
        appConfigurationRefresh.refreshConfigurations();

        // Create a snapshot of current configuration state
        String currentConfigState = buildConfigStateString();

        // Log only if configuration has changed since last check
        if (!Objects.equals(previousConfigState, currentConfigState)) {
            logger.info("App Configuration Details: appconfig.version [{}]",
                    appConfiguration.getVersion()
            );
            previousConfigState = currentConfigState;
        }
    }

    /**
     * Builds a string representation of current configuration state for change detection.
     *
     * @return Configuration state as a concatenated string
     */
    private String buildConfigStateString() {
        return String.join("|",
                String.valueOf(appConfiguration.getVersion())
        );
    }
}