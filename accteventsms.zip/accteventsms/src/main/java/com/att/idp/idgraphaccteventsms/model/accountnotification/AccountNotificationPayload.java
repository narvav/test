package com.att.idp.idgraphaccteventsms.model.accountnotification;

import com.att.idp.idgraphaccteventsms.model.common.MessageHeader;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Represents the root AccountNotification payload.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountNotificationPayload implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private MessageHeader messageHeader;
    private AccountNotification accountNotification;
}