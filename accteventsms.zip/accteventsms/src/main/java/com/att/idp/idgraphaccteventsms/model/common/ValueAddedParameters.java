package com.att.idp.idgraphaccteventsms.model.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ValueAddedParameters implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<ProductAttribute> productAttributes;
}