package com.att.idp.idgraphaccteventsms.model.productnotification;

import com.att.idp.idgraphaccteventsms.model.common.EffectiveDates;
import com.att.idp.idgraphaccteventsms.model.common.ValueAddedParameters;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;

/**
 * Represents an additional offering for a product.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AdditionalOffering implements Serializable {
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private String action;
    private String offeringCode;
    private String offeringDescription;
    private EffectiveDates effectiveDates;
    private ValueAddedParameters valueAddedParameters;
}