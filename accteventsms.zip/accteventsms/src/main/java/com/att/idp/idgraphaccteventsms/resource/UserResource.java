package com.att.idp.idgraphaccteventsms.resource;

import com.att.idp.idgraphaccteventsms.model.User;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriInfo;

/**
 * This is the Interface definition for User mService
 * 
 * @author LEGOS - Platform Team
 * @version $Id$
 * 
 */
@Tag(name = "user")
@Path("/users")
@Produces({MediaType.APPLICATION_JSON})
public interface UserResource {
	
    /**
     * Service definition which takes User's ID as input 
     *
     * @param userId - ID of the user being searched
     * 
     * @return User - Returns the details of the users being searched
     */
	@GET
	@Path("/{userId}")
	@Produces({MediaType.APPLICATION_JSON})
	@Consumes({MediaType.APPLICATION_JSON})
	@Operation(
			description = "Get User Resource",
			summary = "For the given user id returns user resource")
	@ApiResponses(
			value = {
					@ApiResponse(responseCode = "200", description = "OK"),
					@ApiResponse(responseCode = "404", description = "Not Found")
					})
	public Response getUser(
				@Parameter(description = "Id of the user to retrieve", required = true)
				@PathParam("userId")
				String userId);
	
	/**
     * Service definition for User Creation
     *
     * @param user- Object instance of the User to be created
     * 
     * @param uriInfo - Request URI information
     * 
     * @return User - Returns the details of the users created
     */
	@POST
	@Produces({MediaType.APPLICATION_JSON})
	@Consumes({MediaType.APPLICATION_JSON})
	@Operation(
			description = "Create User",
			summary = "Create User, generates Id if not provided")
	@ApiResponses(
			value = {
					@ApiResponse(responseCode = "201", description = "Created"),
					@ApiResponse(responseCode = "409", description = "Conflict")
					})
	public Response createUser(
				@Parameter(description = "User to be created", required = true)
				User user,
				@Context UriInfo uriInfo);


	@GET
	@Path("/string/{userId}")
	@Produces({MediaType.APPLICATION_JSON})
	@Consumes({MediaType.APPLICATION_JSON})
	@Operation(
			description = "Get User Resource",
			summary = "For the given user id returns user resource")
	@ApiResponses(
			value = {
					@ApiResponse(responseCode = "200", description = "OK"),
					@ApiResponse(responseCode = "404", description = "Not Found")
					})
	public Response getUserString(
				@Parameter(description = "Id of the user to retrieve", required = true)
				@PathParam("userId")
				String userId);
}
