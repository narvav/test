package com.att.idp.idgraphaccteventsms.service;

import com.att.idp.idgraph.events.service.ResilientEventPublisher;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jms.ConnectionFactory;

import com.att.idp.idgraphaccteventsms.helper.MessageParserHelper;
import com.att.idp.idgraphaccteventsms.utils.JsonService;
import com.att.idp.idgraphaccteventsms.model.subscription.SubscriberNotificationEvent;
import com.att.idp.idgraphaccteventsms.model.subscription.ChangeData;

/**
 * JMS consumer service that subscribes to Solace queue and processes messages.
 */
@Service
public class JmsSubscriberNotificationConsumer extends AbstractJmsNotificationConsumer {

    private static final Logger log = LoggerFactory.getLogger(JmsSubscriberNotificationConsumer.class);

    private static final String BINDING_NAME = "gddnSubscriberNotifications";

    @Autowired
    public JmsSubscriberNotificationConsumer(
            @org.springframework.beans.factory.annotation.Qualifier("solaceConnectionFactory") ConnectionFactory connectionFactory,
            MessageParserHelper messageParserHelper,
            ResilientEventPublisher resilientEventPublisher,
            @Value("${solace.jms.subr.queue-name}") String queueName,
            @Value("${idgraph.gddnSubscriberNotifications.solace.autoStartup:true}") boolean autoStartup) {
        super(connectionFactory, messageParserHelper, resilientEventPublisher, BINDING_NAME, queueName, autoStartup);
    }

    @Override
    protected Logger getLogger() { return log; }

    @Override
    protected String getConsumerName() { return "Subscriber"; }

    @Override
    protected void processNotification(String jsonString, String idpTraceId) throws Exception {
        SubscriberNotificationEvent subscriberNotificationEvent = JsonService.convertToObject(jsonString, SubscriberNotificationEvent.class);
        if (subscriberNotificationEvent == null
                || subscriberNotificationEvent.getSubscriberNotification() == null
                || subscriberNotificationEvent.getSubscriberNotification().getEventName() == null) {
            log.warn("VAL_01: Subscriber notification failed deserialization or is missing required fields — saving as VALIDATION_FAILED");
            reportValidationFailure(jsonString, "Missing or unparseable SubscriberNotification / eventName");
            return;
        }
        String eventName = subscriberNotificationEvent.getSubscriberNotification().getEventName();
        if ("ChangeData".equalsIgnoreCase(eventName) || "CancelSubscriber".equalsIgnoreCase(eventName)
                || "SuspendSubscriber".equalsIgnoreCase(eventName) || "RestoreSubscriber".equalsIgnoreCase(eventName)) {
            processSubscriberNotificationEvent(subscriberNotificationEvent, idpTraceId);
        } else {
            log.warn("VAL_02: Unrecognized subscriber eventName='{}' — saving as VALIDATION_FAILED",
                    ESAPI.encoder().encodeForHTML(eventName));
            reportValidationFailure(jsonString, "Unrecognized eventName: " + eventName);
        }
    }

    /**
     * Converts a {@link SubscriberNotificationEvent} to a {@link ChangeData} object and serializes it to JSON.
     * <p>
     * This method extracts relevant fields from the event, including event name, subscriber details, and account information,
     * and populates a {@link ChangeData} instance.
     * The resulting object is then serialized to a JSON string.
     * The final JSON string is logged for further processing.
     * </p>
     *
     * @param subscriberNotificationEvent the event containing subscription notification details
     */
    private void processSubscriberNotificationEvent(SubscriberNotificationEvent subscriberNotificationEvent, String idpTraceId){

        ChangeData changeData = new ChangeData();
        changeData.setEventName(subscriberNotificationEvent.getSubscriberNotification().getEventName());

        if(subscriberNotificationEvent.getSubscriberNotification().getSubscriber() != null) {

            changeData.setSubId(subscriberNotificationEvent.getSubscriberNotification().getSubscriber().getSubId());
            changeData.setSubscriberNumber(subscriberNotificationEvent.getSubscriberNotification().getSubscriber().getSubscriberNumber());

            String eventName = subscriberNotificationEvent.getSubscriberNotification().getEventName();
            if("CancelSubscriber".equalsIgnoreCase(eventName) || "SuspendSubscriber".equalsIgnoreCase(eventName)
                    || "RestoreSubscriber".equalsIgnoreCase(eventName)) {

                String subscriberStatus = subscriberNotificationEvent.getSubscriberNotification().getSubscriber().getSubscriberStatus();

                if("C".equalsIgnoreCase(subscriberStatus)){
                    changeData.setSubscriberStatus("Terminated");
                } else if("S".equalsIgnoreCase(subscriberStatus)){
                    changeData.setSubscriberStatus("Suspended");
                } else if ("A".equalsIgnoreCase(subscriberStatus)){
                    changeData.setSubscriberStatus("Active");
                } else {
                    changeData.setSubscriberStatus(subscriberNotificationEvent.getSubscriberNotification().getSubscriber().getSubscriberStatus());
                }

            }
        }

        if(subscriberNotificationEvent.getSubscriberNotification().getAccount() != null) {

            changeData.setBillingAccountNumber(subscriberNotificationEvent.getSubscriberNotification().getAccount().getBillingAccountNumber());
        }
        changeData.setEventId(idpTraceId);
        if(subscriberNotificationEvent.getMessageHeader() != null &&
                subscriberNotificationEvent.getMessageHeader().getTrackingMessageHeader() != null) {
            changeData.setTlgMessageId(subscriberNotificationEvent.getMessageHeader().getTrackingMessageHeader().getMessageId());
            changeData.setEventTime(subscriberNotificationEvent.getMessageHeader().getTrackingMessageHeader().getDateTimeStamp());
        }

        publishEvent(changeData.getBillingAccountNumber(), changeData, changeData.getEventId(), "Subscriber");
    }
}
