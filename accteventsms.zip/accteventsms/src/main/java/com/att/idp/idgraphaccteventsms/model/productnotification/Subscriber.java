package com.att.idp.idgraphaccteventsms.model.productnotification;

import com.att.idp.idgraphaccteventsms.model.common.Device;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;

/**
 * Represents subscriber information.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Subscriber implements Serializable {
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private String subscriberNumber;
    private String subId;
    private String inServiceDate;
    private String subscriberStatus;
    private Device device;
    private ContactName contactName;
    private SubscriberAttributes subscriberAttributes;
}