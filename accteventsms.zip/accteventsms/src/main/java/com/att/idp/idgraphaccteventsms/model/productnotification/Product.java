package com.att.idp.idgraphaccteventsms.model.productnotification;

import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.util.List;

/**
 * Represents product details.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Product implements Serializable {
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private PricePlan pricePlan;
    private List<AdditionalOffering> additionalOfferings;
    private Discounts discounts;
}