package com.att.idp.idgraphaccteventsms;

import com.att.ajsc.common.utility.SystemPropertiesLoader;
import com.att.idp.core.util.ValueAnnotationValidator;
import com.att.idp.idgraph.events.annotation.EnableEventPublisher;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.cassandra.CassandraDataAutoConfiguration;
import org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableAsync;

import java.io.IOException;
import java.util.Arrays;

import com.att.idp.secrets.operations.GuideInitError;
/**
 * This is the main Class which enables the mS to run as a sprint boot application
 * @author LEGOS - Platform Team
 * @version $Id$
 */

@SpringBootApplication
@PropertySource("classpath:application.properties")
@ComponentScan(basePackages = "com.att")
@EnableAsync
@EnableCaching
@EnableAutoConfiguration(exclude = { DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class, CassandraDataAutoConfiguration.class, RedisAutoConfiguration.class})
@EnableEventPublisher
public class Application extends SpringBootServletInitializer {
    
    private SpringApplicationBuilder springApplicationBuilder = new SpringApplicationBuilder();
    
    public SpringApplicationBuilder getSpringApplicationBuilder() {
        return springApplicationBuilder;
    }
 
    public void setSpringApplicationBuilder(SpringApplicationBuilder springApplicationBuilder) {
        this.springApplicationBuilder = springApplicationBuilder;
    }
 
    /**
     * This is the main method which invokes mS as Sprint boot App 
     * @param args Command line parameters if any
     */
    public static void main(String[] args) throws GuideInitError  {
        new Application().runApp(args);
    }
 
    void runApp(String[] args)  throws GuideInitError {
        if (ValueAnnotationValidator.checkArgs(args)) {
            try {
                System.exit(ValueAnnotationValidator.validate(Arrays.asList(args), "com.att.idp", true) ? 1 : 0);
            }
            catch (ClassNotFoundException | IOException ex) {
                System.err.println("ValueAnnotationValidator failed ");
            }
        }
        SystemPropertiesLoader.addSystemProperties();
        getSpringApplicationBuilder().sources(Application.class).run(args);
    }
}