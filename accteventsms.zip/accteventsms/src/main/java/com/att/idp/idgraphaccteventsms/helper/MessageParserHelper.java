package com.att.idp.idgraphaccteventsms.helper;

import java.util.concurrent.ThreadLocalRandom;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class MessageParserHelper {

    public static final Logger logger = LoggerFactory.getLogger(MessageParserHelper.class);

    public String generateTraceId() {
        String idpTraceId = Long.toHexString(ThreadLocalRandom.current().nextLong());
        idpTraceId = idpTraceId + ":" + idpTraceId + ":0:0";
        MDC.put("idp-trace-id", idpTraceId);
        return idpTraceId;
    }

    public String parseMessage(String text) {
        logger.info("inside parseMessage::");
        try {
            if (text != null && !text.trim().isEmpty()) {
                XmlMapper xmlMapper = new XmlMapper();
                JsonNode node = xmlMapper.readTree(text.getBytes());
                ObjectMapper jsonMapper = new ObjectMapper();
                String jsonString = jsonMapper.writeValueAsString(node);
                return jsonString;
            }
        } catch (Exception ex) {
            logger.error("Error parsing message: {}", ex.getMessage(), ex);
            return null;
        }
        return null;
    }
}