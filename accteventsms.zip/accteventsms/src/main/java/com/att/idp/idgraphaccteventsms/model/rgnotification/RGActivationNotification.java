package com.att.idp.idgraphaccteventsms.model.rgnotification;

import lombok.Data;
import lombok.Builder;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.att.idp.idgraphaccteventsms.model.common.MessageHeader;
import java.io.Serializable;

/**
 * Represents the RG Activation Notification payload.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RGActivationNotification implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private MessageHeader messageHeader;
    private RGActivationNotificationBody rgActivationNotification;
}
