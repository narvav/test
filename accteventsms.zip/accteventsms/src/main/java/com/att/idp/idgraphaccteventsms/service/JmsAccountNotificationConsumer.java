package com.att.idp.idgraphaccteventsms.service;

import com.att.idp.idgraph.events.service.ResilientEventPublisher;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jms.ConnectionFactory;

import com.att.idp.idgraphaccteventsms.helper.MessageParserHelper;
import com.att.idp.idgraphaccteventsms.utils.JsonService;
import com.att.idp.idgraphaccteventsms.model.accountnotification.AccountNotificationMessage;
import com.att.idp.idgraphaccteventsms.model.accountnotification.AccountActivationEvent;
import com.att.idp.idgraphaccteventsms.model.accountnotification.AccountCloseEvent;
import com.att.idp.idgraphaccteventsms.model.accountnotification.AccountUpdateEvent;
import com.att.idp.idgraphaccteventsms.model.accountnotification.AccountChange;
import com.att.idp.idgraphaccteventsms.model.accountnotification.Account;

/**
 * JMS consumer service that subscribes to Solace queue and processes messages.
 */
@Service
public class JmsAccountNotificationConsumer extends AbstractJmsNotificationConsumer {

    private static final Logger log = LoggerFactory.getLogger(JmsAccountNotificationConsumer.class);

    private static final String BINDING_NAME = "gddnAccountNotifications";

    @Autowired
    public JmsAccountNotificationConsumer(
            @org.springframework.beans.factory.annotation.Qualifier("solaceConnectionFactory") ConnectionFactory connectionFactory,
            MessageParserHelper messageParserHelper,
            ResilientEventPublisher resilientEventPublisher,
            @Value("${solace.jms.acct.queue-name}") String queueName,
            @Value("${idgraph.gddnAccountNotifications.solace.autoStartup:true}") boolean autoStartup) {
        super(connectionFactory, messageParserHelper, resilientEventPublisher, BINDING_NAME, queueName, autoStartup);
    }

    @Override
    protected Logger getLogger() { return log; }

    @Override
    protected String getConsumerName() { return "Account"; }

    @Override
    protected void processNotification(String jsonString, String idpTraceId) throws Exception {
        log.info("Received account notification message. idpTraceId={}, payload={}", sanitizeForLog(idpTraceId), sanitizeForLog(jsonString));

        AccountNotificationMessage actNotificMsg = JsonService.convertToObject(jsonString, AccountNotificationMessage.class);

        if (actNotificMsg == null
                || actNotificMsg.getAccountNotification() == null
                || actNotificMsg.getAccountNotification().getEventName() == null) {
            log.warn("VAL_ACCT_01: Account notification failed deserialization or is missing required fields — saving as VALIDATION_FAILED");
            reportValidationFailure(jsonString, "Missing or unparseable AccountNotification / eventName");
            return;
        }

        String eventName = actNotificMsg.getAccountNotification().getEventName();
        if ("ActivateAccount".equalsIgnoreCase(eventName)) {
            activateAccount(actNotificMsg, idpTraceId);
        } else if ("CloseAccount".equalsIgnoreCase(eventName)) {
            closeAccount(actNotificMsg, idpTraceId);
        } else if ("UpdateAccount".equalsIgnoreCase(eventName)) {
            updateAccount(actNotificMsg, idpTraceId);
        } else {
            log.warn("VAL_ACCT_02: Unrecognized account eventName='{}' — saving as VALIDATION_FAILED",
                    ESAPI.encoder().encodeForHTML(eventName));
            reportValidationFailure(jsonString, "Unrecognized account eventName: " + eventName);
            return;
        }

        String processedEventName = actNotificMsg != null && actNotificMsg.getAccountNotification() != null
                ? actNotificMsg.getAccountNotification().getEventName()
                : null;
        log.info("Processed Account notification message. idpTraceId={}, eventName={}",
                sanitizeForLog(idpTraceId), sanitizeForLog(processedEventName));
    }

    private String sanitizeForLog(String value) {
        return value != null ? value.replaceAll("[\\r\\n]", " ") : null;
    }
    /**
     * Processes an account activation event from the provided {@link AccountNotificationMessage}.
     * <p>
     * Extracts relevant account and customer details, constructs an {@link AccountActivationEvent},
     * serializes it to JSON, and publishes the event to Kafka via {@link com.att.idp.idgraph.events.service.EventPublisher}.
     * </p>
     *
     * @param actNotificationMsg the account notification message containing activation details
     */
    private void activateAccount(AccountNotificationMessage actNotificationMsg, String idpTraceId){

        AccountActivationEvent accountActivationEvent = new AccountActivationEvent();
        accountActivationEvent.setEventName(actNotificationMsg.getAccountNotification().getEventName());
        accountActivationEvent.setEventId(idpTraceId);
        if(actNotificationMsg.getMessageHeader() != null &&
                actNotificationMsg.getMessageHeader().getTrackingMessageHeader() != null) {
            accountActivationEvent.setTlgMessageId(actNotificationMsg.getMessageHeader().getTrackingMessageHeader().getMessageId());
            accountActivationEvent.setEventTime(actNotificationMsg.getMessageHeader().getTrackingMessageHeader().getDateTimeStamp());
        }
        if(actNotificationMsg.getAccountNotification().getAccount() != null) {
            accountActivationEvent.setBillingAccountNumber(actNotificationMsg.getAccountNotification().getAccount().getBillingAccountNumber());
            accountActivationEvent.setSorId("13");
            accountActivationEvent.setServiceName("MOBILITY");
            if(actNotificationMsg.getAccountNotification().getAccount().getCustomer() != null &&
                    actNotificationMsg.getAccountNotification().getAccount().getCustomer().getName() != null){

                accountActivationEvent.setFirstName(actNotificationMsg.getAccountNotification().getAccount().getCustomer().getName().getFirstName());
                accountActivationEvent.setLastName(actNotificationMsg.getAccountNotification().getAccount().getCustomer().getName().getLastName());
            }

            if(actNotificationMsg.getAccountNotification().getAccount().getCustomer() != null &&
                    actNotificationMsg.getAccountNotification().getAccount().getCustomer().getEmail() != null) {

                accountActivationEvent.setContactEmail(actNotificationMsg.getAccountNotification().getAccount().getCustomer().getEmail().getEmailAddress());
            }
        }


        publishEvent(accountActivationEvent.getBillingAccountNumber(), accountActivationEvent, accountActivationEvent.getEventId(), "Account activation");
    }

    /**
     * Processes an account closure event from the provided {@link AccountNotificationMessage}.
     * <p>
     * Extracts relevant account and message header details, constructs an {@link AccountCloseEvent},
     * serializes it to JSON, and publishes the event to Kafka via {@link com.att.idp.idgraph.events.service.EventPublisher}.
     * </p>
     *
     * @param actNotificationMsg the account notification message containing closure details
     */
    private void closeAccount(AccountNotificationMessage actNotificationMsg, String idpTraceId){

        AccountCloseEvent accountCloseEvent = new AccountCloseEvent();
        accountCloseEvent.setEventName(actNotificationMsg.getAccountNotification().getEventName());

        accountCloseEvent.setEventId(idpTraceId);
        if(actNotificationMsg.getAccountNotification().getAccount() != null) {
            accountCloseEvent.setBillingAccountNumber(actNotificationMsg.getAccountNotification().getAccount().getBillingAccountNumber());

            if(actNotificationMsg.getMessageHeader() != null &&
                    actNotificationMsg.getMessageHeader().getTrackingMessageHeader() != null) {
                accountCloseEvent.setTlgMessageId(actNotificationMsg.getMessageHeader().getTrackingMessageHeader().getMessageId());
                accountCloseEvent.setEventTime(actNotificationMsg.getMessageHeader().getTrackingMessageHeader().getDateTimeStamp());
            }
        }

        publishEvent(accountCloseEvent.getBillingAccountNumber(), accountCloseEvent, accountCloseEvent.getEventId(), "Account close");
    }

    /**
     * Processes an account update event from the provided {@link AccountNotificationMessage}.
     * <p>
     * Extracts relevant account and message header details, constructs an {@link AccountUpdateEvent},
     * serializes it to JSON, and publishes the event to Kafka via {@link com.att.idp.idgraph.events.service.EventPublisher}.
     * </p>
     *
     * @param actNotificationMsg the account notification message containing update details
     */
    private void updateAccount(AccountNotificationMessage actNotificationMsg, String idpTraceId){
        log.info("Processing account update event for billingAccountNumber={}, eventId={}",
                sanitizeForLog(actNotificationMsg.getAccountNotification().getAccount() != null
                        ? actNotificationMsg.getAccountNotification().getAccount().getBillingAccountNumber()
                        : null), sanitizeForLog(idpTraceId));
        AccountUpdateEvent accountUpdateEvent = new AccountUpdateEvent();
        accountUpdateEvent.setEventName(actNotificationMsg.getAccountNotification().getEventName());

        accountUpdateEvent.setEventId(idpTraceId);
        if(actNotificationMsg.getAccountNotification().getAccount() != null) {
            accountUpdateEvent.setBillingAccountNumber(actNotificationMsg.getAccountNotification().getAccount().getBillingAccountNumber());

            if(actNotificationMsg.getMessageHeader() != null &&
                    actNotificationMsg.getMessageHeader().getTrackingMessageHeader() != null) {
                accountUpdateEvent.setTlgMessageId(actNotificationMsg.getMessageHeader().getTrackingMessageHeader().getMessageId());
                accountUpdateEvent.setEventTime(actNotificationMsg.getMessageHeader().getTrackingMessageHeader().getDateTimeStamp());
            }
            if(actNotificationMsg.getAccountNotification().getAccount().getTitan() != null &&
                    actNotificationMsg.getAccountNotification().getAccount().getFoundationAccountNumber() == null){
                accountUpdateEvent.setTitanBan(actNotificationMsg.getAccountNotification().getAccount().getTitan().getTitanBan());
                accountUpdateEvent.setServiceName("MOBILITY");
                accountUpdateEvent.setSorId("13");
                if(actNotificationMsg.getAccountNotification().getAccount().getCustomer() != null &&
                        actNotificationMsg.getAccountNotification().getAccount().getCustomer().getName() != null){

                    accountUpdateEvent.setFirstName(actNotificationMsg.getAccountNotification().getAccount().getCustomer().getName().getFirstName());
                    accountUpdateEvent.setLastName(actNotificationMsg.getAccountNotification().getAccount().getCustomer().getName().getLastName());
                }

            } else{
                accountUpdateEvent.setNewFan(actNotificationMsg.getAccountNotification().getAccount().getFoundationAccountNumber());
                if(actNotificationMsg.getAccountNotification().getAccountChange() != null &&
                        actNotificationMsg.getAccountNotification().getAccountChange().getAccount() != null){

                    accountUpdateEvent.setOldFan(actNotificationMsg.getAccountNotification().getAccountChange().getAccount().getFoundationAccountNumber());
                }
            }
        }


        log.info("Publishing account update event for billingAccountNumber={}, eventId={}",
                sanitizeForLog(accountUpdateEvent.getMobilityBan()), sanitizeForLog(accountUpdateEvent.getEventId()));
        publishEvent(accountUpdateEvent.getMobilityBan(), accountUpdateEvent, accountUpdateEvent.getEventId(), "Account update");
        log.info("Published account update event for billingAccountNumber={}, eventId={}",
                sanitizeForLog(accountUpdateEvent.getMobilityBan()), sanitizeForLog(accountUpdateEvent.getEventId()));
    }
}
