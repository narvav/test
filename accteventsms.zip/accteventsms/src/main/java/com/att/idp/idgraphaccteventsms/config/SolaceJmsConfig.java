package com.att.idp.idgraphaccteventsms.config;

import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.InitialContext;

import com.solacesystems.jms.SupportedProperty;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jms.annotation.EnableJms;
import javax.jms.ConnectionFactory;
/**
 * Solace JMS configuration for Spring Boot.
 */
@Configuration
@EnableJms
public class SolaceJmsConfig {

    public static final Logger logger = LoggerFactory.getLogger(SolaceJmsConfig.class);

    @Value("${solace.jms.initial-context-factory}")
    private String initialContextFactory;

    @Value("${solace.jms.provider-url}")
    private String providerUrl;

    @Value("${solace.jms.username}")
    private String username;

    @Value("${solace.jms.password}")
    private String password;

    @Value("${solace.jms.cf-jndi-name}")
    private String cfJndiName;

    @Value("${solace.jms.vpn}")
    private String vpn;

    @Value("${solace.jms.compression-level}")
    private String compressionLevel;

    @Value("${solace.jms.optimize-direct}")
    private String optimizeDirect;


    /**
     * Creates the default Solace JMS ConnectionFactory bean for the application.
     * This bean is marked as @Primary and should be injected using @Qualifier("solaceConnectionFactory")
     * if multiple ConnectionFactory beans exist.
     *
     * @return the default Solace JMS ConnectionFactory
     * @throws Exception if the connection factory cannot be created
     */

    @Bean("solaceConnectionFactory")
    @Primary
     public ConnectionFactory connectionFactory() throws Exception {

        Hashtable<String, String> env = new Hashtable<>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, initialContextFactory);
        env.put(Context.PROVIDER_URL, providerUrl);

        // Defensive null checks and logging
        if (username == null || username.isEmpty()) {
            logger.error("Solace JMS username is missing");
            throw new IllegalArgumentException("Solace JMS username must be specified");
        }
        if (password == null || password.isEmpty()) {
            logger.error("Solace JMS password is missing");
            throw new IllegalArgumentException("Solace JMS password must be specified");
        }
        if (vpn == null || vpn.isEmpty()) {
            logger.error("Solace JMS VPN is missing");
            throw new IllegalArgumentException("Solace JMS VPN must be specified");
        }
        if (cfJndiName == null || cfJndiName.isEmpty()) {
            logger.error("Solace JMS ConnectionFactory JNDI name is missing");
            throw new IllegalArgumentException("Solace JMS ConnectionFactory JNDI name must be specified");
        }

        env.put("solace.jms.username", username);
        env.put("solace.jms.password", password);
        env.put("solace.jms.vpn", vpn);

        if (compressionLevel != null && !compressionLevel.isEmpty()) {
            env.put("solace.jms.compressionLevel", compressionLevel);
        }
        if (optimizeDirect != null && !optimizeDirect.isEmpty()) {
            env.put("solace.jms.optimizeDirect", optimizeDirect);
        }

        logger.info("Connecting to Solace JMS: providerUrl={}, vpn={}, cfJndiName={}", ESAPI.encoder().encodeForHTML(providerUrl), ESAPI.encoder().encodeForHTML(vpn), ESAPI.encoder().encodeForHTML(cfJndiName));

        env.put(Context.SECURITY_PRINCIPAL, this.username);
        env.put(Context.SECURITY_CREDENTIALS, this.password);
        env.put(SupportedProperty.SOLACE_JMS_VPN, this.vpn);
        env.put(SupportedProperty.SOLACE_JMS_COMPRESSION_LEVEL, this.compressionLevel);
        env.put(SupportedProperty.SOLACE_JMS_OPTIMIZE_DIRECT, this.optimizeDirect);

        InitialContext context = new InitialContext(env);
        return (ConnectionFactory) context.lookup(this.cfJndiName);
    }
}
