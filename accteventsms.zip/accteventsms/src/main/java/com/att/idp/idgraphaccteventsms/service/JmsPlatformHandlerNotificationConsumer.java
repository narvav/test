package com.att.idp.idgraphaccteventsms.service;

import com.att.idp.idgraph.events.service.ResilientEventPublisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jms.ConnectionFactory;

import com.att.idp.idgraphaccteventsms.helper.MessageParserHelper;
import com.att.idp.idgraphaccteventsms.utils.JsonService;
import com.att.idp.idgraphaccteventsms.model.platformhandler.Change;
import com.att.idp.idgraphaccteventsms.model.platformhandler.PlatformHandlerEvent;

@Service
public class JmsPlatformHandlerNotificationConsumer extends AbstractJmsNotificationConsumer {

    private static final Logger log = LoggerFactory.getLogger(JmsPlatformHandlerNotificationConsumer.class);

    private static final String BINDING_NAME = "gddnRgphosNotifications";

    @Autowired
    public JmsPlatformHandlerNotificationConsumer(
            @org.springframework.beans.factory.annotation.Qualifier("solacePFHandlerConnectionFactory") ConnectionFactory connectionFactory,
            MessageParserHelper messageParserHelper,
            ResilientEventPublisher resilientEventPublisher,
            @Value("${platform.handler.queue.name}") String queueName,
            @Value("${idgraph.gddnRgphosNotifications.solace.autoStartup:true}") boolean autoStartup) {
        super(connectionFactory, messageParserHelper, resilientEventPublisher, BINDING_NAME, queueName, autoStartup);
    }

    @Override
    protected Logger getLogger() { return log; }

    @Override
    protected String getConsumerName() { return "Platform Handler"; }

    @Override
    protected void processNotification(String jsonString, String idpTraceId) throws Exception {
        Change change = JsonService.convertToObject(jsonString, Change.class);
        if (change != null && change.getUpsert() != null && change.getUpsert().getEntity() != null
                && change.getUpsert().getEntity().getFoundationAccountNumber() != null
                && change.getUpsert().getEntity().getBillingAccountNumber() != null) {
            processPlatformHandlerNotification(change, idpTraceId);
        } else {
            log.warn("VAL_PF_01: Platform handler notification missing required account fields — saving as VALIDATION_FAILED");
            reportValidationFailure(jsonString, "Missing required foundationAccountNumber and/or billingAccountNumber");
        }
    }

    private void processPlatformHandlerNotification(Change change, String idpTraceId) {

        PlatformHandlerEvent platformHandlerEvent = new PlatformHandlerEvent();

        if(change.getUpsert().getEntity().getUpsert() != null){

            platformHandlerEvent.setPhFan(change.getUpsert().getEntity().getUpsert().getFoundationAccountNumber());
            platformHandlerEvent.setBillingAccountNumber(change.getUpsert().getEntity().getUpsert().getBillingAccountNumber());
            platformHandlerEvent.setPlatformHandler(change.getUpsert().getEntity().getUpsert().getPlatformHandler());
        }
        platformHandlerEvent.setEventId(idpTraceId);
        platformHandlerEvent.setEventName("PlatformHandler");
        if(change.getHeader() != null){
            platformHandlerEvent.setEventTime(change.getHeader().getTxnReceivedTS());
        }

        publishEvent(platformHandlerEvent.getBillingAccountNumber(), platformHandlerEvent, platformHandlerEvent.getEventId(), "Platform handler");
    }
}
