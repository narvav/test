package com.att.idp.idgraphaccteventsms.model.subscription;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * Represents a simple subscriber notification event for ChangeData.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChangeData implements Serializable {

    private static final long serialVersionUID = 1L;

    private String eventName;
    private String subId;
    private String subscriberNumber;
    private String billingAccountNumber;
    private String subscriberStatus;
    private String tlgMessageId;
    private String eventId;
    private String eventTime;


}

