package com.att.idp.idgraphaccteventsms.model.subscription;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.att.idp.idgraphaccteventsms.model.common.MessageHeader;
import java.io.Serializable;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * Root object for Subscriber notification response.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubscriberNotificationEvent implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private MessageHeader messageHeader;
    private SubscriberNotification subscriberNotification;

}

