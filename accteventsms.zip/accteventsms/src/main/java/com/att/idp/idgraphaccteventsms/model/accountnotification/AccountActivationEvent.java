package com.att.idp.idgraphaccteventsms.model.accountnotification;

import lombok.Data;
import lombok.Builder;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Represents an account activation event.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountActivationEvent implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private String eventName;
    private String contactEmail;
    private String billingAccountNumber;
    private String sorId;
    private String serviceName;
    private String firstName;
    private String lastName;
    private String tlgMessageId;
    private String eventId;
    private String eventTime;
}