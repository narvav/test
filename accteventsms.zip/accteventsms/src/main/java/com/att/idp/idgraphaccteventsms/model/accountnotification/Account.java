package com.att.idp.idgraphaccteventsms.model.accountnotification;

import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.util.List;


/**
 * Account details.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Account implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private BillingMarket billingMarket;
    private String billingAccountNumber;
    private CombinedBillingInfo combinedBillingInfo;
    private String billingAccountPassword;
    private String securityLevel;
    private String passcodeEmailToken;
    private String passcdAutoGenDateTimeStamp;
    private AccountStatus accountStatus;
    private String statusReason;
    private AccountCredit accountCredit;
    private AccountType accountType;
    private String accountOpenDate;
    private String glCompanyCode;
    private AccountBilling accountBilling;
    private BillingPreferences billingPreferences;
    private Customer customer;
    private DealerInfo dealerInfo;
    private List<AccountAttribute> accountAttributes;
    private SegmentType segmentType;
    private Titan titan;
    private String primaryAccountHolder;
    private String foundationAccountNumber;
    private String enterpriseType;
}