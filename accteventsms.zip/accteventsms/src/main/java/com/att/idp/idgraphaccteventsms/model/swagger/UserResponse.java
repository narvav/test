package com.att.idp.idgraphaccteventsms.model.swagger;

import com.att.idp.idgraphaccteventsms.model.User;
import com.att.idp.core.representation.Resource;

/**
 * Swagger response class for the User model object.
 * @param <T>
 *
 * @param <T>
 */
public class UserResponse extends Resource<User> {

	public UserResponse(User content) {
		super(content);
	}

	@Override
	public User getContent() {
		return super.getContent();
	}
}