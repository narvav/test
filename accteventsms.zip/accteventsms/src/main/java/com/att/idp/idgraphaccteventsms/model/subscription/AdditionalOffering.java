package com.att.idp.idgraphaccteventsms.model.subscription;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.att.idp.idgraphaccteventsms.model.common.EffectiveDates;
import com.att.idp.idgraphaccteventsms.model.common.ValueAddedParameters;
import java.io.Serializable;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;


/**
 * Additional Offering details.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AdditionalOffering implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private String action;
    private String offeringCode;
    private String offeringDescription;
    private EffectiveDates effectiveDates;
    private ValueAddedParameters valueAddedParameters;

}
