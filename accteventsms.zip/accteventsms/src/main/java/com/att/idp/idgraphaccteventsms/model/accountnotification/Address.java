package com.att.idp.idgraphaccteventsms.model.accountnotification;

import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;


/**
 * Address details.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Address implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private String effectiveDate;
    private String linkType;
    private String addressType;
    private String incorporatedIndicator;
    private String addressLine1;
    private String addressPrimaryLine;
    private Street street;
    private String city;
    private String state;
    private Zip zip;
    private String country;
}