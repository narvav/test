package com.att.idp.idgraphaccteventsms.service;

import com.att.idp.idgraph.events.service.ResilientEventPublisher;
import com.att.idp.idgraphaccteventsms.helper.MessageParserHelper;
import com.att.idp.idgraphaccteventsms.model.common.MessageHeader;
import com.att.idp.idgraphaccteventsms.model.common.ProductAttribute;
import com.att.idp.idgraphaccteventsms.model.common.ValueAddedParameters;
import com.att.idp.idgraphaccteventsms.model.productnotification.AdditionalOffering;
import com.att.idp.idgraphaccteventsms.model.productnotification.ChangeProduct;
import com.att.idp.idgraphaccteventsms.model.productnotification.ProductNotification;
import com.att.idp.idgraphaccteventsms.model.productnotification.ProductNotificationEvent;
import com.att.idp.idgraphaccteventsms.utils.JsonService;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.jms.ConnectionFactory;
import java.util.List;

/**
 * JMS product notification service that subscribes to Solace queue and processes messages.
 */
@Service
public class JmsProductNotificationConsumer extends AbstractJmsNotificationConsumer {

    private static final Logger log = LoggerFactory.getLogger(JmsProductNotificationConsumer.class);

    private static final String BINDING_NAME = "gddnRgphosNotifications";

    @Autowired
    public JmsProductNotificationConsumer(
            @org.springframework.beans.factory.annotation.Qualifier("solaceConnectionFactory") ConnectionFactory connectionFactory,
            MessageParserHelper messageParserHelper,
            ResilientEventPublisher resilientEventPublisher,
            @Value("${solace.jms.prodhbo.queue-name}") String queueName,
            @Value("${idgraph.gddnRgphosNotifications.solace.autoStartup:true}") boolean autoStartup) {
        super(connectionFactory, messageParserHelper, resilientEventPublisher, BINDING_NAME, queueName, autoStartup);
    }

    @Override
    protected Logger getLogger() { return log; }

    @Override
    protected String getConsumerName() { return "Product"; }

    @Override
    protected void processNotification(String jsonString, String idpTraceId) throws Exception {
        ProductNotificationEvent productNotificationEvent = JsonService.convertToObject(jsonString, ProductNotificationEvent.class);

        if (productNotificationEvent == null || productNotificationEvent.getProductNotification() == null
                || productNotificationEvent.getProductNotification().getEventName() == null) {
            log.warn("VAL_PROD_01: Product notification failed deserialization or is missing required fields — saving as VALIDATION_FAILED");
            reportValidationFailure(jsonString, "Missing or unparseable ProductNotification / eventName");
            return;
        }

        String eventName = productNotificationEvent.getProductNotification().getEventName();
        if (!"ChangeProduct".equalsIgnoreCase(eventName)) {
            log.warn("VAL_PROD_02: Unrecognized product eventName='{}' — saving as VALIDATION_FAILED",
                    ESAPI.encoder().encodeForHTML(eventName));
            reportValidationFailure(jsonString, "Unrecognized product eventName: " + eventName);
            return;
        }

        boolean isChangedProdAllowed = isAllowedForChangedProduct(productNotificationEvent);
        if (isChangedProdAllowed) {
            changeProduct(productNotificationEvent.getProductNotification(), productNotificationEvent.getMessageHeader(), idpTraceId);
        } else {
            log.warn("VAL_PROD_03: Product notification did not satisfy eligibility (BAN present + HBOCG=Y) — saving as VALIDATION_FAILED");
            reportValidationFailure(jsonString, "Product notification not eligible: missing BAN and/or HBOCG!=Y");
        }
    }

    /**
     * Determines if a product change event is allowed based on the presence of a billing account number
     * and the HBOCG attribute with value "Y" in the provided {@link ProductNotificationEvent}.
     *
     * <p>
     * The method checks that the {@code productNotificationEvent} contains a non-empty billing account number
     * and at least one {@code ProductAttribute} named "HBOCG" with value "Y" in its additional offerings.
     * </p>
     *
     * @param productNotificationEvent the product notification event to validate
     * @return {@code true} if both billing account number and HBOCG attribute are present and valid; {@code false} otherwise
     */
    private boolean isAllowedForChangedProduct(ProductNotificationEvent productNotificationEvent) {

        boolean isAllowed = false;
        boolean isBillingNumberPresent = false;
        boolean isHbocgPresent = false;

        // Check for billing account number presence
        if (productNotificationEvent != null && productNotificationEvent.getProductNotification() != null) {

            if (productNotificationEvent.getProductNotification().getAccount() != null) {

                String billingAccountNumber = productNotificationEvent.getProductNotification().getAccount().getBillingAccountNumber();
                if (billingAccountNumber != null && !billingAccountNumber.trim().isEmpty()) {
                    isBillingNumberPresent = true;
                }
            }
            // Check for HBOCG attribute presence
            if (productNotificationEvent.getProductNotification().getProduct() != null) {

                List<AdditionalOffering> additionalOfferings = productNotificationEvent.getProductNotification().getProduct().getAdditionalOfferings();
                if (additionalOfferings != null && !additionalOfferings.isEmpty()) {
                    for (AdditionalOffering offering : additionalOfferings) {

                        ValueAddedParameters valueAddedParameters = offering.getValueAddedParameters();
                        List<ProductAttribute> productAttributes = valueAddedParameters != null ? valueAddedParameters.getProductAttributes() : null;
                        if (productAttributes != null && !productAttributes.isEmpty()) {
                            for (ProductAttribute attribute : productAttributes) {

                                if ("HBOCG".equalsIgnoreCase(attribute.getAttributeName())
                                        && "Y".equalsIgnoreCase(attribute.getAttributeValue())) {
                                    log.info("HBOCG attribute found with value Y");
                                    isHbocgPresent = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
        if (isBillingNumberPresent && isHbocgPresent) {

            isAllowed = true;
        }
        return isAllowed;
    }

    /**
     * Processes a product change event by constructing a {@link ChangeProduct} object
     * from the provided {@link ProductNotification}, serializing it to JSON, and logging
     * the result for downstream Kafka processing.
     *
     * <p>
     * The method extracts relevant fields from the {@code productNotification}, including
     * event name, billing account number, subscriber contact details, and sets static values
     * for SOR ID, service name, connected car status, and contact email.
     * </p>
     *
     * <p>
     * All logged values are encoded using {@link org.owasp.esapi.ESAPI#encoder()} to prevent
     * log injection vulnerabilities.
     * </p>
     *
     * @param productNotification the product notification containing event and account details
     */
    private void changeProduct(ProductNotification productNotification, MessageHeader messageHeader, String idpTraceId) {

        ChangeProduct changeProduct = new ChangeProduct();
        changeProduct.setEventName(productNotification.getEventName());
        changeProduct.setBillingAccountNumber(productNotification.getAccount().getBillingAccountNumber());
        changeProduct.setSorId("13");
        changeProduct.setServiceName("MOBILITY");
        changeProduct.setIsConnectedCar("Y");

        //TODO: check with SME for email
        changeProduct.setContactEmail("");

        if(productNotification.getSubscriber() != null &&
                productNotification.getSubscriber().getContactName() != null){
            changeProduct.setFirstName(productNotification.getSubscriber().getContactName().getFirstName());
            changeProduct.setLastName(productNotification.getSubscriber().getContactName().getLastName());
        }
        changeProduct.setEventId(idpTraceId);
        if(messageHeader != null && messageHeader.getTrackingMessageHeader() != null) {
            changeProduct.setTlgMessageId(messageHeader.getTrackingMessageHeader().getMessageId());
            changeProduct.setEventTime(messageHeader.getTrackingMessageHeader().getDateTimeStamp());
        }
        publishEvent(changeProduct.getBillingAccountNumber(), changeProduct, changeProduct.getEventId(), "Change product");
    }
}
