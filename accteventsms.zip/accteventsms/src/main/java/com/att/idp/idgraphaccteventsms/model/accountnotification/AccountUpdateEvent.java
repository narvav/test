package com.att.idp.idgraphaccteventsms.model.accountnotification;

import lombok.Data;
import lombok.Builder;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Represents an account update event.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountUpdateEvent implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private String eventName;
    private String tlgMessageId;
    private String titanBan;
    private String mobilityBan;
    private String eventId;
    private String eventTime;
    private String billingAccountNumber;
    private String firstName;
    private String lastName;
    private String serviceName;
    private String sorId;
    private String oldFan;
    private String newFan;
}