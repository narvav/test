package com.att.idp.idgraphaccteventsms.model.productnotification;

import com.att.idp.idgraphaccteventsms.model.common.EffectiveDates;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.util.List;

/**
 * Represents a price plan for a product.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PricePlan implements Serializable {
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private String singleUserCode;
    private String recurringCharge;
    private List<PricePlanAttribute> pricePlanAttributes;
    private com.att.idp.idgraphaccteventsms.model.common.EffectiveDates effectiveDates;
    private String actionCode;
}