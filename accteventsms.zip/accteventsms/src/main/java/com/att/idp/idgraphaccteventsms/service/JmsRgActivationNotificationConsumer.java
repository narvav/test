package com.att.idp.idgraphaccteventsms.service;

import com.att.idp.idgraph.events.service.ResilientEventPublisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jms.ConnectionFactory;

import com.att.idp.idgraphaccteventsms.helper.MessageParserHelper;
import com.att.idp.idgraphaccteventsms.utils.JsonService;
import com.att.idp.idgraphaccteventsms.model.rgnotification.RGActivationNotification;
import com.att.idp.idgraphaccteventsms.model.rgnotification.RgActivationEvent;

@Service
public class JmsRgActivationNotificationConsumer extends AbstractJmsNotificationConsumer {

    private static final Logger log = LoggerFactory.getLogger(JmsRgActivationNotificationConsumer.class);

    private static final String BINDING_NAME = "gddnRgphosNotifications";

    @Autowired
    public JmsRgActivationNotificationConsumer(
            @org.springframework.beans.factory.annotation.Qualifier("solaceConnectionFactory") ConnectionFactory connectionFactory,
            MessageParserHelper messageParserHelper,
            ResilientEventPublisher resilientEventPublisher,
            @Value("${solace.jms.rgactn.queue-name}") String queueName,
            @Value("${idgraph.gddnRgphosNotifications.solace.autoStartup:true}") boolean autoStartup) {
        super(connectionFactory, messageParserHelper, resilientEventPublisher, BINDING_NAME, queueName, autoStartup);
    }

    @Override
    protected Logger getLogger() { return log; }

    @Override
    protected String getConsumerName() { return "RG Activation"; }

    @Override
    protected void processNotification(String jsonString, String idpTraceId) throws Exception {
        RGActivationNotification rGActivationNotification = JsonService.convertToObject(jsonString, RGActivationNotification.class);
        if (rGActivationNotification == null
                || rGActivationNotification.getRgActivationNotification() == null
                || rGActivationNotification.getRgActivationNotification().getEventName() == null
                || rGActivationNotification.getRgActivationNotification().getAccountNumber() == null
                || rGActivationNotification.getRgActivationNotification().getAccountNumber().isBlank()) {
            log.warn("VAL_RG_01: RG activation notification missing required fields (eventName/accountNumber) — saving as VALIDATION_FAILED");
            reportValidationFailure(jsonString, "Missing or unparseable RgActivationNotification / eventName / accountNumber");
            return;
        }
        processRgActivationNotification(rGActivationNotification, idpTraceId);
    }

    /**
     * Processes the provided {@link RGActivationNotification} by mapping its attributes to a {@link RgActivationEvent},
     * serializing the event to JSON, and publishing it to the primary Kafka topic.
     *
     * @param rGActivationNotification the RG activation notification to process; may be null
     */
    private void processRgActivationNotification(RGActivationNotification rGActivationNotification, String idpTraceId) {

        RgActivationEvent rGActivationEvent = new RgActivationEvent();
        rGActivationEvent.setEventId(idpTraceId);

        if(rGActivationNotification != null){
            if(rGActivationNotification.getRgActivationNotification() != null){

                rGActivationEvent.setEventName(rGActivationNotification.getRgActivationNotification().getEventName());
                rGActivationEvent.setAccountNumber(rGActivationNotification.getRgActivationNotification().getAccountNumber());
                rGActivationEvent.setSerialNumber(rGActivationNotification.getRgActivationNotification().getSerialNumber());
            }
            if(rGActivationNotification.getMessageHeader() != null &&
                rGActivationNotification.getMessageHeader().getTrackingMessageHeader() != null){
                rGActivationEvent.setTlgMessageId(rGActivationNotification.getMessageHeader().getTrackingMessageHeader().getMessageId());
                rGActivationEvent.setEventTime(rGActivationNotification.getMessageHeader().getTrackingMessageHeader().getDateTimeStamp());
            }
        }

        publishEvent(rGActivationEvent.getAccountNumber(), rGActivationEvent, rGActivationEvent.getEventId(), "RG activation");
    }

}
