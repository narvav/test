package com.att.idp.idgraphaccteventsms.appconfig.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

@Configuration
@RefreshScope
@Getter
@Setter
public class IDGraphAzureAppConfig {

    @Value("${appconfig.version:0.0.0}")
    private String version;

    @Value("${kafka.resiliency.use-unified-entity:false}")
    private boolean useUnifiedEntity;

    @Value("${environment.region:east}")
    private String environmentRegion;

    @Value("${kafka.event.record.container.name:idg_kafka_failed_events}")
    private String kafkaEventRecordContainerName;

    @Value("${kafka.event.record.ttl.seconds:604800}")
    private int kafkaEventRecordTtlSeconds;
}
