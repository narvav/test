package com.att.idp.idgraphaccteventsms.model.subscription;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.att.idp.idgraphaccteventsms.model.common.EffectiveDates;
import com.att.idp.idgraphaccteventsms.model.common.ProductAttribute;
import java.io.Serializable;
import java.util.List;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * Price plan details.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PricePlan implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private GroupPlanDetails groupPlanDetails;
    private String singleUserCode;
    private String recurringCharge;
    private List<ProductAttribute> pricePlanAttributes;
    private String description;
    private String technologyType;
    private EffectiveDates effectiveDates;
    private String actionCode;

}

