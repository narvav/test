package com.att.idp.idgraphaccteventsms.model.productnotification;

import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;

/**
 * Represents account information.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Account implements Serializable {
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private String billingAccountNumber;
    private BillingMarket billingMarket;
    private AccountType accountType;
}