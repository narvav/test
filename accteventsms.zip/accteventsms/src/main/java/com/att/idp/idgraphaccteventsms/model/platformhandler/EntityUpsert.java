package com.att.idp.idgraphaccteventsms.model.platformhandler;


import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;

/**
 * Represents the nested Upsert object inside Entity.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class EntityUpsert implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private String platformHandlerLastUpdatedDate;
    private String foundationAccountNumber;
    private String billingAccountNumber;
    private String platformHandler;
}
