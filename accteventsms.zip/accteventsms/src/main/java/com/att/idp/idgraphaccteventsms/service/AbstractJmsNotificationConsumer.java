package com.att.idp.idgraphaccteventsms.service;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.MDC;

import javax.jms.*;
import java.util.Objects;

import com.att.idp.idgraphaccteventsms.helper.MessageParserHelper;
import com.att.idp.idgraph.events.service.ResilientEventPublisher;

/**
 * Abstract base class for JMS notification consumers that provides common
 * initialization, cleanup, and message processing logic.
 */
public abstract class AbstractJmsNotificationConsumer {

    private final ConnectionFactory connectionFactory;
    private final MessageParserHelper messageParserHelper;
    private final ResilientEventPublisher resilientEventPublisher;
    private final String bindingName;
    private final String queueName;
    private final boolean autoStartup;

    private Connection connection;
    private Session session;
    private MessageConsumer consumer;

    protected AbstractJmsNotificationConsumer(
            ConnectionFactory connectionFactory,
            MessageParserHelper messageParserHelper,
            ResilientEventPublisher resilientEventPublisher,
            String bindingName,
            String queueName,
            boolean autoStartup) {
        this.connectionFactory = connectionFactory;
        this.messageParserHelper = messageParserHelper;
        this.resilientEventPublisher = resilientEventPublisher;
        this.bindingName = bindingName;
        this.queueName = queueName;
        this.autoStartup = autoStartup;
    }

    protected abstract Logger getLogger();

    protected abstract String getConsumerName();

    protected void processMessage(String jsonString) throws Exception {
        String idpTraceId = messageParserHelper.generateTraceId();
        try {
            processNotification(jsonString, idpTraceId);
        } finally {
            MDC.remove("idp-trace-id");
        }
    }

    protected abstract void processNotification(String jsonString, String idpTraceId) throws Exception;

    @PostConstruct
    public void init() throws JMSException {
        if (!autoStartup) {
            getLogger().info("autoStartup=false for {} consumer on queue: {} — skipping JMS initialization",
                    getConsumerName(), ESAPI.encoder().encodeForHTML(queueName));
            return;
        }
        try {
            connection = connectionFactory.createConnection();
            // CLIENT_ACKNOWLEDGE: message is only ack'd via message.acknowledge() in onMessage on success.
            // On processing failure, the message remains unacked so Solace redelivers per redelivery policy.
            // This prevents message loss when publish and fallback paths encounter failures.
            session = connection.createSession(false, Session.CLIENT_ACKNOWLEDGE);
            Queue queue = session.createQueue(queueName);
            consumer = session.createConsumer(queue);
            consumer.setMessageListener(this::onMessage);
            connection.start();
            getLogger().info("Started JMS consumer for queue: {}", ESAPI.encoder().encodeForHTML(queueName));
        } catch (JMSException e) {
            getLogger().error("JMS initialization failed: {}", ESAPI.encoder().encodeForHTML(e.getMessage()));
            throw e;
        }
    }

    public void onMessage(Message message) {
        long startTime = System.currentTimeMillis();
        long endTime = 0L;
        boolean processed = false;
        try {
            String payload = message instanceof TextMessage ? ((TextMessage) message).getText() : message.toString();

            if (payload != null && !payload.isEmpty()) {
                String jsonString = messageParserHelper.parseMessage(payload);
                getLogger().info("Converted {} notification json string", getConsumerName());
                processMessage(jsonString);
            }
            // Empty/null payload also counts as successfully handled — nothing to retry.
            processed = true;
        } catch (Exception e) {
            // Do NOT acknowledge — Solace will redeliver per its redelivery policy (max retries + DMQ).
            // This ensures retries are driven by broker redelivery behavior.
            // Call session.recover() to force immediate redelivery of unacked messages.
            try {
                if (session != null) {
                    session.recover();
                }
            } catch (JMSException recoverEx) {
                getLogger().error("Failed to recover JMS session after processing error", recoverEx);
            }
            getLogger().error("Error processing JMS message: {}", ESAPI.encoder().encodeForHTML(e.getMessage()), e);
        } finally {
            if (processed) {
                try {
                    message.acknowledge();
                } catch (JMSException ackEx) {
                    // Ack failure is logged but not fatal; Solace will redeliver and consumer-side dedup will skip duplicates.
                    getLogger().error("Failed to acknowledge JMS message after successful processing: {}",
                            ESAPI.encoder().encodeForHTML(ackEx.getMessage()), ackEx);
                }
            }
            endTime = System.currentTimeMillis();
            long duration = endTime - startTime;

            getLogger().info("JMS {} Notification messages processed in {} ms [start: {}, end: {}]",
                    getConsumerName(),
                    ESAPI.encoder().encodeForHTML(String.valueOf(duration)),
                    ESAPI.encoder().encodeForHTML(String.valueOf(startTime)),
                    ESAPI.encoder().encodeForHTML(String.valueOf(endTime)));
        }
    }

    @PreDestroy
    public void cleanup() {
        try {
            if (Objects.nonNull(consumer)) {
                consumer.close();
            }
            if (Objects.nonNull(session)) {
                session.close();
            }
            if (Objects.nonNull(connection)) {
                connection.close();
            }
            getLogger().info("JMS consumer resources cleaned up.");
        } catch (JMSException e) {
            getLogger().error("Error during JMS cleanup:", ESAPI.encoder().encodeForHTML(e.getMessage()));
        }
    }

    protected ResilientEventPublisher getResilientEventPublisher() {
        return resilientEventPublisher;
    }

    protected String getBindingName() {
        return bindingName;
    }

    protected MessageParserHelper getMessageParserHelper() {
        return messageParserHelper;
    }

    protected void publishEvent(String partitionKey, Object event, String eventId, String description) {
        boolean published = getResilientEventPublisher().sendWithFallback(
                getBindingName(), getConsumerName(), partitionKey, event);
        if (published) {
            getLogger().info("{} event published to Kafka: eventId={}", description, ESAPI.encoder().encodeForHTML(eventId));
        } else {
            getLogger().warn("{} event saved to Cosmos DB fallback: eventId={}", description, ESAPI.encoder().encodeForHTML(eventId));
        }
    }

    /**
     * Persists a pre-Kafka validation failure to Cosmos DB with {@code status=VALIDATION_FAILED}.
     * These records are non-retryable and batchms will never process them.
     *
     * @param rawPayload      raw JSON string that failed validation
     * @param validationError human-readable reason (e.g., "missing billingAccountNumber")
     */
    protected void reportValidationFailure(String rawPayload, String validationError) {
        getResilientEventPublisher().saveValidationFailure(getBindingName(), getConsumerName(),
                rawPayload, validationError);
    }
}
