package com.att.idp.idgraphaccteventsms.model.subscription;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * Represents the business name and contact details for a subscriber.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BusinessName implements Serializable {

    private static final long serialVersionUID = 1L;

    private String businessName;
    private Contact contact;

}

