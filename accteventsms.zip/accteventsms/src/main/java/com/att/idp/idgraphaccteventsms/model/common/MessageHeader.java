package com.att.idp.idgraphaccteventsms.model.common;

import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;

/**
 * Message header containing tracking, security, and sequence information.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MessageHeader implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    private TrackingMessageHeader trackingMessageHeader;
    private SecurityMessageHeader securityMessageHeader;
    private SequenceMessageHeader sequenceMessageHeader;
}
