#!/bin/sh
#touch /app.jar

# Environment Variable			Command Line Argument
# SCM_URL_ENV  					$1
# SCM_COMMIT_HASH_ENV  			$2 
# SCM_BRANCH_ENV 				$3 
# JENKINS_BUILD_URL_ENV  		$4 
# JENKINS_BUILD_NUMBER_ENV		$5 
# JENKINS_BUILD_DATE_ENV    	$6
# ARTIFACT_NAME_ENV				$7 
# ARTIFACT_ID_ENV				$8

if [ "$config_env" != "" ]
then
. ./opt/ajsc/etc/config/docker/initService.sh $1 $2 $3 $4 $5 $6 $7 $8
else
. ./initService.sh $1 $2 $3 $4 $5 $6 $7 $8
fi

echo java ${JAVA_MEM_OPTS} ${JAVA_APP_OPTS} ${IDP_SSL_ARGS} -jar /opt/ajsc/bin/app.jar
exec java ${JAVA_MEM_OPTS} ${JAVA_APP_OPTS} ${IDP_SSL_ARGS} -jar /opt/ajsc/bin/app.jar
