#!/bin/sh

echo "Sidecar Enabled Check -" ${ixp_sidecar_enabled}

if [ "$USE_POD_DNS_CONFIG" = "" ]; then
    sudo /opt/ajsc/bin/fixresolv.sh
fi
    

#Define default JVM Heap Memory. (revised 1910)
# Overview in _playbook via 'java_mem_options'
# JVM Heap must be smaller vs. allocated requested K8 memory (deployment.yaml)
#   See also: _configRole _playbook
# (1) K8 deployment.yaml(spec.containers.name=JAVA_MEM_OPTS value=java_mem_options) JVM Heap override K8/playbook.
# (2) K8 deployment.yaml(spec.containers.resource.request.memory) K8 Container memory requested allocation must be greater than JVM Heap. Otherwise OOM error.
if [ "$JAVA_MEM_OPTS" = "" ]
then
    JAVA_MEM_OPTS="-Xms1024m -Xmx1024m -XX:+UseG1GC -XX:MaxGCPauseMillis=100 -XX:+UseStringDeduplication"
fi

echo "SCM_URL_ENV=$1"
echo "SCM_COMMIT_HASH_ENV=$2"
echo "SCM_BRANCH_ENV=$3"
echo "JENKINS_BUILD_URL_ENV=$4"
echo "JENKINS_BUILD_NUMBER_ENV=$5"
echo "JENKINS_BUILD_DATE_ENV=$6"
echo "ARTIFACT_NAME_ENV=$7"
echo "ARTIFACT_ID_ENV=$8"

echo "config_env -> ${config_env}"

jarPath="/opt/ajsc/etc/bin/service-virtualization-framework.jar"
if [ -f $jarPath ]; then
    echo "Service virtualization jar is found."
    loaderPathExistingValue=$(echo $JAVA_APP_OPTS | sed -e "s/.*-Dloader.path=\([a-zA-Z\/0-9_.-]\+\)/\\1/g")
    if [ "$loaderPathExistingValue" != "" ]; then
        # This will replace "-Dloader.path=origval" with "-Dloader.path=origval,pathtojar".
        JAVA_APP_OPTS=$(echo $JAVA_APP_OPTS | sed -e "s!\(.*-Dloader.path=\)\([-a-zA-Z\/0-9_.]\+\)!\\1\\2,"$jarPath"!")
    else
        JAVA_APP_OPTS=$(echo "$JAVA_APP_OPTS -Dloader.path=$jarPath")
    fi
else
    echo "Service virtualization jar not found"
fi

export otjarpath="/opt/ajsc/lib/opentelemetry/opentelemetry-javaagent.jar"
if [ "${OPENTELEMETRY_ENABLED}" = "true" ] && [ -f $otjarpath ]; then
    appkindsubstr=
    if [ "${OPENTELEMETRY_ROOTAPP}" = "true" ]; then
        appkindsubstr="-Dotel.traces.sampler=traceidratio -Dotel.traces.sampler.arg=0.1"
    else
        appkindsubstr="-Dotel.traces.sampler=parentbased_always_off"
    fi
    JAVA_APP_OPTS=$(echo "$JAVA_APP_OPTS \
    -javaagent:${otjarpath} \
    -Dotel.trace.exporter=otlp \
    -Dotel.exporter.otlp.endpoint=http://local-otel-collector-svc.com-att-idp-tools.svc.cluster.local:4317 \
    -Dotel.javaagent.debug=true \
    -Dotel.metrics.exporter=none \
    -Dotel.resource.attributes=service.name=idp-$SERVICE_NAME,mots.id=$MOTS_ID \
    $appkindsubstr")
    export OTEL_JAVAAGENT_EXTENSIONS=/opt/ajsc/lib/opentelemetry/sre-otel-javaagent-extensions.jar
else
    echo "Open Telemetry jar not found or not enabled."
fi

# This has to be true for dynatrace integration
JAVA_APP_OPTS="$JAVA_APP_OPTS -Dserver.tomcat.mbeanregistry.enabled=true"

echo "Java Options from MS Config is ${JAVA_APP_OPTS}"