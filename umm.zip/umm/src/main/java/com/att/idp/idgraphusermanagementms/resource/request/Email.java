package com.att.idp.idgraphusermanagementms.resource.request;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import static org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString;
import static org.apache.commons.lang3.builder.ToStringStyle.JSON_STYLE;

/**
 * This class is part of the com.att.idp.idgraphusermanagementms.resource.request package.
 *
 * The Email class implements the Serializable interface, allowing instances of this class to be converted into a byte stream.
 *
 * The class is used to represent an Email object, which contains a single field, emailAddress.
 * The emailAddress field is annotated with @NotNull and @Size, indicating that it is a required field and has size constraints.
 * The messages associated with these annotations provide additional information about the requirements for the emailAddress field.
 *
 * The class provides a no-argument constructor, as well as a getter and setter method for the emailAddress field.
 * It also overrides the toString method, providing a custom string representation of the object using reflection.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Email implements Serializable{

	@NotNull(message="emailAddress is required field in input request.|ResetUserPassword")
	@Size(min=1, max=255,message="emailAddress length is invalid|ResetUserPassword")
	protected String emailAddress;
	
	 /**
     * This field represents a map of unknown attributes.
     *
     * The unknownAttributes map is used to store any additional attributes that are not part of the attributeName and attributeValue fields.
     * It is initialized as a new HashMap.
     *
     * The field is annotated with @JsonAnySetter and @JsonAnyGetter, allowing it to be included in JSON serialization and deserialization.
     */
    @JsonAnySetter
    @JsonAnyGetter
    public Map<String,Object> unknownAttributes = new HashMap<>();

	@Override
	public String toString() {
		return reflectionToString(this, JSON_STYLE);
	}
}