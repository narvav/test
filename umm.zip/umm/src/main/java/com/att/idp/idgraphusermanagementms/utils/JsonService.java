package com.att.idp.idgraphusermanagementms.utils;


import static org.apache.commons.lang3.StringUtils.isBlank;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import com.fasterxml.jackson.databind.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import com.att.idp.deviceinsclaimeligibility.exception.ClientException;

//import com.att.idp.deviceinsclaimeligibility.exception.ClientException;
//import com.att.idp.deviceinsclaimeligibility.exception.ServiceException;
//import com.att.idp.deviceinsclaimeligibility.message.ErrorMessages;
import com.att.idp.core.exception.ServiceException;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;

/**
 * Utility class used to create and handle Json string. It facilitates
 * conversion from Object to Json String and from Json String to Object.
 */
public final class JsonService {

	private static final Logger LOGGER = LoggerFactory.getLogger(JsonService.class);

	private static final ObjectMapper MAPPER;

	private JsonService() {

	}

	static {
		MAPPER = new ObjectMapper();
		MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		MAPPER.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		MAPPER.setSerializationInclusion(Include.NON_NULL);
		MAPPER.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
		
		MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		MAPPER.setPropertyNamingStrategy(PropertyNamingStrategies.LOWER_CAMEL_CASE);
		MAPPER.setSerializationInclusion(Include.NON_NULL);
		MAPPER.setSerializationInclusion(Include.NON_EMPTY);
		MAPPER.configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true);
		MAPPER.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		MAPPER.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		MAPPER.enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES);
		MAPPER.enable(DeserializationFeature.READ_ENUMS_USING_TO_STRING);
		MAPPER.configure(MapperFeature.AUTO_DETECT_SETTERS, true);
		
	}

	/**
	 * Takes an object as parameter and converts it into json string format like
	 * {"dataValue":"Data Value","cloudType":"cart"}.
	 *
	 * @param object
	 *            holds the object which need to be converted into json string
	 * @return Json String
	 */
	public static String getJsonFromObject(final Object object) {
		String jsonString = null;
		try {
			jsonString = MAPPER.writeValueAsString(object);
		} catch (JsonProcessingException jex) {
			LOGGER.error("JsonProcessingException occurred when converting  to Json from Object: " + jex);
			//throw new ServiceException(ErrorMessages.JSON_SERIALIZATION_ERROR, jex.getCause());
		}

		return jsonString;
	}

	/**
	 * Takes an object as parameter and converts it into json string format like
	 * {"dataValue":"Data Value","cloudType":"cart"}.
	 *
	 * @param object
	 *            holds the object which need to be converted in json string
	 * @return Json String
	 */
	public static String getJsonWithPrettyPrintFromObject(final Object object) {
		String jsonString = null;
		try {
			jsonString = MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(object);
		} catch (JsonProcessingException jex) {
			LOGGER.error("JsonProcessingException occurred when converting Json with Pretty from Object: " + jex);
			//throw new ClientException(jex.getMessage(), shortenedStackTrace(jex, 1), 500);
		}

		return jsonString;
	}

	/**
	 * Takes Json object as parameter and converts the Json string as object of
	 * valueType.
	 *
	 * @param <T>
	 *            the generic type
	 * @param jsonString
	 *            holds the json string which needs to be converted in object
	 * @param valueType
	 *            describe the type in which json string needs to converted
	 * @return <T>
	 */

	public static <T> T getObjectFromJson(final Object jsonString, final Class<T> valueType) {
		T object = null;
		if (jsonString != null) {
			try {
				object = MAPPER.readValue(jsonString.toString(), valueType);
			} catch (IOException jex) {
				LOGGER.error("IOException occurred when converting Json to Object: " + jex);
				//throw new ServiceException(ErrorMessages.JSON_SERIALIZATION_ERROR, jex.getCause());
			}
		}
		return object;
	}

	/**
	 * This method is part of the JsonService class.
	 * It is a utility method that generates a shortened version of the stack trace for a given exception.
	 * The method takes two parameters: an Exception object and an integer representing the maximum number of lines to include in the shortened stack trace.
	 * The method uses a StringWriter and a PrintWriter to capture the stack trace of the exception.
	 * It then splits the stack trace into individual lines and appends the first 'maxLines' lines to a StringBuilder.
	 * The method returns the resulting string, which represents the shortened stack trace.
	 *
	 * @param e The exception for which the stack trace is to be shortened.
	 * @param maxLines The maximum number of lines to include in the shortened stack trace.
	 * @return String A string representing the shortened stack trace.
	 */
	public static String shortenedStackTrace(Exception e, int maxLines) {
		StringWriter writer = new StringWriter();
		e.printStackTrace(new PrintWriter(writer));
		String[] lines = writer.toString().split("\n");
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < Math.min(lines.length, maxLines); i++) {
			sb.append(lines[i]).append("\n");
		}
		return sb.toString();
	}

	/**
	 * Takes Json node as parameter and converts it into object of valueType.
	 *
	 * @param <T>
	 *            the generic type
	 * @param jsonNode
	 *            holds the json node which needs to be converted in object
	 * @param valueType
	 *            describe the type in which json node needs to converted
	 * @return <T>
	 */
	public static <T> T getObjectFromJsonNode(final JsonNode jsonNode, final Class<T> valueType) {
		T object = null;
		try {
			object = MAPPER.treeToValue(jsonNode, valueType);

		} catch (JsonProcessingException jex) {
			LOGGER.error("JsonProcessingException occurred when converting Json node to Object: " + jex);
			//throw new ServiceException(ErrorMessages.JSON_SERIALIZATION_ERROR,jex.getCause());
		}

		return object;
	}
	
	public static ObjectMapper getMapper() {
		return MAPPER.copy();
	}

	/**
	 * This method is part of the JsonService class.
	 * It is a utility method that checks if a given string is a valid JSON.
	 * The method takes a string as a parameter, which should represent a JSON.
	 * The method attempts to convert the string into a JsonNode object using the ObjectMapper.
	 * If the conversion is successful, the method returns true, indicating that the string is a valid JSON.
	 * If the conversion fails, the method returns false, indicating that the string is not a valid JSON.
	 *
	 * @param inputJson A string representing a JSON.
	 * @return boolean A boolean value indicating whether the string is a valid JSON or not.
	 */
	public static boolean isValidJson(String inputJson) {
	    return convertToJson(inputJson) != null;
	}

	/**
	 * This method is part of the JsonService class.
	 * It is a utility method that converts a string representation of a JSON to a JsonNode object.
	 * The method takes a string as a parameter, which should represent a JSON.
	 * The method attempts to parse the string into a JsonNode object using the ObjectMapper.
	 * If the parsing is successful, the method returns the JsonNode object.
	 * If the parsing fails, the method returns null.
	 *
	 * @param inputJson A string representing a JSON.
	 * @return JsonNode A JsonNode object representing the parsed JSON, or null if the parsing fails.
	 */
	public static JsonNode convertToJson(String inputJson) {
		if (isBlank(inputJson)) {
			return null;
		}

		try {
			return MAPPER.readTree(inputJson);
	    } catch (JsonProcessingException e) {
	    	LOGGER.error("JsonProcessingException occurred when converting  to Json from String: " + e);
	        return null;
	    }
	}

	/**
	 * This method is part of the JsonService class.
	 * It is a utility method that converts a string representation of a JSON to an object of a specified class.
	 * The method takes two parameters: a string representing a JSON and a Class object representing the class to which the JSON should be converted.
	 * The method first converts the string to a JsonNode object using the convertToJson method.
	 * It then converts the JsonNode object to an object of the specified class using the convertToObject method that takes a JsonNode and a Class as parameters.
	 * If the conversion is successful, the method returns the object of the specified class.
	 * If the conversion fails, the method returns null.
	 *
	 * @param <T> The type of the object to which the JSON should be converted.
	 * @param inputJson A string representing a JSON.
	 * @param theClass A Class object representing the class to which the JSON should be converted.
	 * @return T An object of the specified class representing the converted JSON, or null if the conversion fails.
	 */
	public static <T> T convertToObject(String inputJson, Class<T> theClass) {
		JsonNode jsonNode = convertToJson(inputJson);
		return convertToObject(jsonNode, theClass);
	}

	/**
	 * This method is part of the JsonService class.
	 * It is a utility method that converts a JsonNode object to an object of a specified class.
	 * The method takes two parameters: a JsonNode object and a Class object representing the class to which the JsonNode should be converted.
	 * The method attempts to convert the JsonNode object to an object of the specified class using the ObjectMapper.
	 * If the conversion is successful, the method returns the object of the specified class.
	 * If the conversion fails, the method logs an error message and returns null.
	 *
	 * @param <T> The type of the object to which the JsonNode should be converted.
	 * @param jsonNode A JsonNode object representing the JSON to be converted.
	 * @param theClass A Class object representing the class to which the JSON should be converted.
	 * @return T An object of the specified class representing the converted JSON, or null if the conversion fails.
	 */
	public static <T> T convertToObject(JsonNode jsonNode, Class<T> theClass) {
		if (jsonNode == null) {
			return null;
		}

		try {
			return MAPPER.readValue(jsonNode.toString(), theClass);
		} catch (Exception e) {
			String errorMsg = new StringBuilder().append("JSON Mapping Exception: Could not convert the input: [").append(jsonNode.toString()).append("] to object of Class: [").append(theClass.getName()).append("].").toString();
			LOGGER.error(errorMsg, e);
		}

		return null;
	}

	/**
	 * This method is part of the JsonService class.
	 * It is a utility method that converts an object to a JSON string.
	 * The method takes an object as a parameter.
	 * The method attempts to convert the object to a JSON string using the ObjectMapper.
	 * If the conversion is successful, the method returns the JSON string.
	 * If the conversion fails, the method logs an error message and returns a string "EMPTY_JSON".
	 *
	 * @param obj The object to be converted to a JSON string.
	 * @return String A string representing the JSON version of the object, or "EMPTY_JSON" if the conversion fails.
	 */
	public static String toJsonString(Object obj) {
		if (obj == null) {
			return "EMPTY_JSON";
		}

		try {
			return MAPPER.writeValueAsString(obj);
		} catch (Exception e) {
			String errorMsg = new StringBuilder().append("JSON Serialization Exception: Could not serialize the input object of Class: [").append(obj.getClass().getName()).append("]").toString();
			LOGGER.error(errorMsg, e);
		}

		return "EMPTY_JSON";
	}

}
