package com.att.idp.idgraphusermanagementms.service;

import com.att.idp.idgraphusermanagementms.resource.response.MemberIdResponse;
import jakarta.ws.rs.core.MultivaluedMap;

public interface QueryMemberIdService {

    MemberIdResponse queryMemberId(MultivaluedMap<String, String> requestHeaders, String stRequestTraceId) throws Exception;
}
