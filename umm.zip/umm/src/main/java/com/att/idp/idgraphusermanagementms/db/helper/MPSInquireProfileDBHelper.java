package com.att.idp.idgraphusermanagementms.db.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.helper.voltage.ProcessVoltageHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.StatusMsg;

/**
 * This class, MPSInquireProfileDBHelper, is responsible for querying the MPS database depending on the level passed in the input.
 * It uses Spring's JdbcTemplate for database operations.
 *
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like JdbcTemplate and ProcessVoltageHelper.
 *
 * The main method in this class is:
 * - inquireProfile: This method retrieves profile information from the MPS database based on the level passed in the input. It takes a HashMap as input and returns a HashMap as output.
 *   The input HashMap contains key-value pairs for various profile attributes like handle, domain, guid, return user fraud lock, level, and is external call.
 *   The method first checks if the jdbcTemplate is null. If it is, it returns an error status.
 *   Then it retrieves the profile attributes from the input HashMap.
 *   If the profile attributes are not found, it returns an error status.
 *   Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
 *   Finally, it returns a status indicating whether the operation was successful or not.
 */
@Component
public class MPSInquireProfileDBHelper {

	private static final String info = "$Id: master/com/att/corpops/frma/dhelpers/MPSInquireProfileDBHelper.java v1 2022-05-19 mc288e $;";
	private static String sClassName = "MPSInquireProfileDBHelper";
	public static final Logger log = LoggerFactory.getLogger(MPSInquireProfileDBHelper.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private ProcessVoltageHelper oProcessVoltageHelper;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	@Value("${filterFieldsList}")
	private String propFilterFieldsList;

	@Value("${PROP_FIELDS_TO_TRANSLATE}")
	private String propFieldsToTranslate;

//	@Value("${GENERIC_PASSWORD_ENCRYPTION_TYPE}")
	private String sGen_password_type;

	/**
	 * This method retrieves profile information from the MPS database based on the level passed in the input.
	 * It takes a HashMap as input which contains key-value pairs for various profile attributes like handle, domain, guid, return user fraud lock, level, and is external call.
	 * The method first checks if the jdbcTemplate is null. If it is, it returns an error status.
	 * Then it retrieves the profile attributes from the input HashMap.
	 * If the profile attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param hmInput A HashMap containing the details of the profile attributes to be retrieved.
	 * @return A HashMap containing the status of the operation and the retrieved profile attributes.
	 */
	public HashMap inquireProfile(HashMap hmInput) {
		String sMethodName = ".inquireProfile.";
		log.info(ProfileOrchestrationConstants.LOG_DBTOOLS000, sClassName, sMethodName, hmInput);
		log.info("CVS KEYWORDS:" + info);
		HashMap hmResult = CommonUtil.getHashMap();
		HashMap hmMember = CommonUtil.getHashMap();
		HashMap hmUserFraudLock = CommonUtil.getHashMap();
		ArrayList alMemberSvcRoles = CommonUtil.getArrayList();
		String stAppStatusCode = null;
		String stAppInfo = null;
		List<Object> objectList = CommonUtil.getArrayList();
		List alQueryResponse = null;
		String sDBMemberNum = null;

		try {
			String sInpHandle = (String) hmInput.get(CommonDefs.HANDLE);
			String sInpDomain = (String) hmInput.get(CommonDefs.DOMAIN);
			String sInpGuid = (String) hmInput.get(CommonDefs.GUID);
			String sReturnUserFraudLock = (String) hmInput.get("returnUserFraudLock");
			String sLevel = (String) hmInput.get("level");
			String sIsExternalCall = (String) hmInput.get("isExternalCall");

			ArrayList<String> alFilterFields = CommonUtil.parseToArray(propFilterFieldsList,
					CommonDefs.VALUE_SEPARATOR_CHAR);

			if ((sLevel.equals("M")) || (sLevel.equals("MSR"))) {

				String stringMemQuery = null;
				if (sGen_password_type != null && !sGen_password_type.trim().isEmpty()) {
					stringMemQuery = "SELECT m.member_num AS \"memberNum\", m.member_name AS \"memberName\","
							+ " m.slid_member_num AS \"slidMemberNum\",m.domain_id AS \"domainId\", m.parent_child_ind AS \"parentChildInd\", m.fullname AS \"fullName\", m.firstname AS \"firstName\", "
							+ "m.lastname AS \"lastName\", m.browser_language AS \"browserLanguage\", m.last_modified_by "
							+ "AS \"lastModifiedBy\", m.contact_email AS \"contactEmail\", m.autogenerated_ind AS \"autogeneratedInd\","
							+ " m.activated_ind AS \"activatedInd\", m.contact_email_status AS \"contactEmailStatus\", "
							+ "m.ssha_password AS \"ssha_password\","
							+ " m.password_dirty AS \"passwordDirty\", TO_CHAR(m.contact_email_est_date,'MMDDYYYY HH24:mi:ss') "
							+ "AS \"contactEmailEstDate\", TO_CHAR(m.create_date, 'MMDDYYYY HH24:mi:ss') AS \"createDate\", "
							+ "TO_CHAR(m.last_modified, 'MMDDYYYY HH24:mi:ss') AS \"lastModified\", TO_CHAR(m.activated_date, "
							+ "'MMDDYYYY HH24:mi:ss') AS \"activatedDate\", TO_CHAR(m.onl_qa_est_date, 'MMDDYYYY HH24:mi:ss') "
							+ "AS \"onlQaEstDate\",m.migration_ind AS \"migrationInd\", m.created_by AS \"createdBy\","
							+ "TO_CHAR(m.accessid_rtv_date, 'MMDDYYYY HH24:mi:ss') AS \"accessIdRTValidDate\",m.contact_email_valid AS \"contactEmailValid\","
							+ "TO_CHAR(m.contact_email_rtv_date, 'MMDDYYYY HH24:mi:ss') AS \"contactEmailRTValidDate\" ,m.previous_contact_email AS \"previousContactEmail\","
							+ " m.fn_linked_userid AS \"linkedFNUserId\", m.fn_linked_status AS \"linkedFNUserStatus\" ,"
							+ "memaux.enc_password_venc AS \"enc_password_venc\","
							+ "memaux.md5_password_venc AS \"md5_password_venc\", memaux.sha1_password_venc AS \"sha1_password_venc\", "
							+ "memaux.des3_password_venc AS \"des3_password_venc\", memaux.ssha_password_venc AS \"ssha_password_venc\","
							+ "memaux.security_answer_1_venc AS \"security_answer_1_venc\", memaux.security_answer_2_venc AS \"security_answer_2_venc\","
							+ " secq1.security_question as \"securityQuestion1\", secq2.security_question as \"securityQuestion2\", "
							// 2011 - Revert SSHA-256 encryption changes
							// + "memaux.password_venc AS \"gen_password_venc\", memaux.password_type AS
							// \"gen_password_type\", "
							// 2103 - Added Chnges SSHA-256 encryption changes
							+ "memaux.password_venc AS \"gen_password_venc\", memaux.password_type AS \"gen_password_type\", "
							+ "dom.domain_name AS \"domainName\" FROM member m, memberaux memaux, securityquestion secq1, securityquestion secq2, domain dom"
							+ " WHERE m.domain_id = dom.domain_id AND m.security_question_id_1 =secq1.security_question_id (+) "
							+ "AND m.security_question_id_2 =secq2.security_question_id (+) AND m.member_num = "
							+ "memaux.member_num (+)";
				} else {
					stringMemQuery = "SELECT m.member_num AS \"memberNum\", m.member_name AS \"memberName\","
							+ " m.slid_member_num AS \"slidMemberNum\",m.domain_id AS \"domainId\", m.parent_child_ind AS \"parentChildInd\", m.fullname AS \"fullName\", m.firstname AS \"firstName\", "
							+ "m.lastname AS \"lastName\", m.browser_language AS \"browserLanguage\", m.last_modified_by "
							+ "AS \"lastModifiedBy\", m.contact_email AS \"contactEmail\", m.autogenerated_ind AS \"autogeneratedInd\","
							+ " m.activated_ind AS \"activatedInd\", m.contact_email_status AS \"contactEmailStatus\", "
							+ "m.ssha_password AS \"ssha_password\","
							+ " m.password_dirty AS \"passwordDirty\", TO_CHAR(m.contact_email_est_date,'MMDDYYYY HH24:mi:ss') "
							+ "AS \"contactEmailEstDate\", TO_CHAR(m.create_date, 'MMDDYYYY HH24:mi:ss') AS \"createDate\", "
							+ "TO_CHAR(m.last_modified, 'MMDDYYYY HH24:mi:ss') AS \"lastModified\", TO_CHAR(m.activated_date, "
							+ "'MMDDYYYY HH24:mi:ss') AS \"activatedDate\", TO_CHAR(m.onl_qa_est_date, 'MMDDYYYY HH24:mi:ss') "
							+ "AS \"onlQaEstDate\",m.migration_ind AS \"migrationInd\", m.created_by AS \"createdBy\","
							+ "TO_CHAR(m.accessid_rtv_date, 'MMDDYYYY HH24:mi:ss') AS \"accessIdRTValidDate\",m.contact_email_valid AS \"contactEmailValid\","
							+ "TO_CHAR(m.contact_email_rtv_date, 'MMDDYYYY HH24:mi:ss') AS \"contactEmailRTValidDate\" ,m.previous_contact_email AS \"previousContactEmail\","
							+ " m.fn_linked_userid AS \"linkedFNUserId\", m.fn_linked_status AS \"linkedFNUserStatus\" ,"
							+ "memaux.enc_password_venc AS \"enc_password_venc\","
							+ "memaux.md5_password_venc AS \"md5_password_venc\", memaux.sha1_password_venc AS \"sha1_password_venc\", "
							+ "memaux.des3_password_venc AS \"des3_password_venc\", memaux.ssha_password_venc AS \"ssha_password_venc\","
							+ "memaux.security_answer_1_venc AS \"security_answer_1_venc\", memaux.security_answer_2_venc AS \"security_answer_2_venc\","
							+ " secq1.security_question as \"securityQuestion1\", secq2.security_question as \"securityQuestion2\", "
							+ "dom.domain_name AS \"domainName\" FROM member m, memberaux memaux, securityquestion secq1, securityquestion secq2, domain dom"
							+ " WHERE m.domain_id = dom.domain_id AND m.security_question_id_1 =secq1.security_question_id (+) "
							+ "AND m.security_question_id_2 =secq2.security_question_id (+) AND m.member_num = "
							+ "memaux.member_num (+)";
				}

				StringBuffer sMemQuery = new StringBuffer(stringMemQuery);

				if ((sInpGuid != null && !sInpGuid.isEmpty())) {
					sMemQuery.append(" AND m.member_num = ?");
					objectList.add(sInpGuid);
				} else {
					sMemQuery.append(" AND m.member_name = ? AND dom.domain_name = ?");
					objectList.add(sInpHandle);
					objectList.add(sInpDomain);
				}
				log.debug("{}{}DBTOOL_01 : Query = {}", sClassName, sMethodName, sMemQuery);

				alQueryResponse = jdbcTemplate.queryForList(new String(sMemQuery),
						objectList.toArray(new Object[objectList.size()]));

				int numRowsFound = 0;
				if (alQueryResponse != null && !alQueryResponse.isEmpty()) {
					for (int j = 0; j < alQueryResponse.size(); j++) {
						Map hmQueryResponse = (Map) alQueryResponse.get(j);
						Iterator itr = hmQueryResponse.keySet().iterator();
						while (itr.hasNext()) {
							String key = (String) itr.next();
							Object value = hmQueryResponse.get(key);
							String strValue = (value == null ? null : value.toString());
							hmMember.put(key, strValue);
						}

						sDBMemberNum = (String) hmMember.get(CommonDefs.MEMBER_NUM);
						log.info(SpiMarker.getInstance(),"{}{}DBTOOL_02 : member_num returned from member query = {}", sClassName, sMethodName,
								HtmlUtils.htmlEscape(String.valueOf(sDBMemberNum)));

						++numRowsFound;

					}
				}
				if (numRowsFound == 0) {
					stAppInfo = "Input guid or handle/domain not found";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
					log.info("{}{}DBTOOL_03 error : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}

				log.debug(SpiMarker.getInstance(),"{}{}DBTOOL_04 : Result of member query: {}", sClassName, sMethodName, hmMember);

				log.debug(SpiMarker.getInstance(),"{}{}DBTOOL_05 : Calling ProcessVoltageHelper.voltageDecryptSPIFields with input {}",
						sClassName, sMethodName, hmMember);
				hmResult = oProcessVoltageHelper.voltageDecryptSPIFields(hmMember);
				log.debug(SpiMarker.getInstance(),"{}{}DBTOOL_06 : Response from  ProcessVoltageHelper.voltageDecryptSPIFields {}", sClassName,
						sMethodName, hmResult);

				stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

				if (stAppStatusCode != null && !stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
					stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
					hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
					log.info("{}{}DBTOOL_07 : {}", sClassName, sMethodName,
							HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
					return hmResult;
				}

				HashMap hmFieldsToTranslate = CommonUtil.parseMultiDelimiterProperty(propFieldsToTranslate);
				log.info("{}{}DBTOOL_08 : PROP_FIELDS_TO_TRANSLATE : {}", sClassName, sMethodName, hmFieldsToTranslate);

				if (hmFieldsToTranslate != null && !hmFieldsToTranslate.isEmpty()) {
					String sKey = null;
					String sValue = null;
					String sNewKey = null;

					Iterator itr = hmFieldsToTranslate.keySet().iterator();
					while (itr.hasNext()) {
						sKey = (String) itr.next();
						ArrayList alFieldValue = (ArrayList) hmFieldsToTranslate.get(sKey);

						for (int i = 0; i < alFieldValue.size(); i++) {
							sNewKey = (String) alFieldValue.get(i);
						}

						if (hmMember.containsKey(sKey)) {
							sValue = (String) hmMember.remove(sKey);
							hmMember.put(sNewKey, sValue);
						}
					}
				}

				log.debug(SpiMarker.getInstance(),"{}{}DBTOOL_09 : member hash after fields translation {}.", sClassName, sMethodName,
						hmMember);

				log.info("{}{}DBTOOL_10 : filterFieldsList : {}", sClassName, sMethodName, alFilterFields);

				for (int i = 0; i < alFilterFields.size(); i++) {
					String sKey = (String) alFilterFields.get(i);

					if (!"N".equals(sIsExternalCall)) {
						hmMember.remove(sKey);
					}
				}
				log.debug(SpiMarker.getInstance(),"{}{}DBTOOL_11 : Filtered member hash {}.", sClassName, sMethodName, hmMember);

			}

			if (sLevel.equals("MSR")) {

				String stringMemSvcQuery = "SELECT ms.member_num AS \"memberNum\", ms.service_id AS \"serviceId\", "
						+ "ms.member_status AS \"memberStatusCode\", ms.create_date AS \"createDate\", ms.last_modified_by AS \"lastModifiedBy\","
						+ " ms.instance_id AS \"instanceId\", ms.sor_id AS \"sorId\", ms.sor_invariant_id AS \"sorInvariantId\", ms.nickname AS \"nickName\", "
						+ " ms.default_account AS \"defaultAccount\", ms.cpni_impacted AS \"cpniImpacted\", ms.parent_sor_id AS \"parentSorId\", "
						+ "ms.parent_sor_invariant_id as \"parentSorInvariantId\", TO_CHAR(ms.date_default_est, 'MMDDYYYY HH24:mi:ss') AS \"dateDefaultEst\", "
						+ "TO_CHAR(ms.create_date, 'MMDDYYYY HH24:mi:ss') AS \"createDate\", TO_CHAR(ms.last_modified, 'MMDDYYYY HH24:mi:ss') AS \"lastModified\", "
						+ "msr.role_id AS \"roleId\", msr.status AS \"roleStatusCode\", ser.service_name AS \"serviceName\", stat1.status_name as \"memberStatusName\","
						+ "sor.sor_name AS \"sorName\", stat2.status_name as \"roleStatusName\", srole.role_name As \"roleName\" FROM memberservice ms, status stat1, status stat2, systemofrecord sor, "
						+ "memberservicerole msr, service ser, servicerole srole WHERE msr.role_id = srole.role_id (+) AND ms.service_id = ser.service_id AND "
						+ "ms.member_status = stat1.status_code (+) AND ms.sor_id=sor.sor_id (+) AND ms.member_num = msr.member_num (+) AND ms.service_id = msr.service_id (+)"
						+ " AND ms.sor_id = msr.sor_id (+) AND ms.sor_invariant_id = msr.sor_invariant_id (+) AND msr.status = stat2.status_code (+) "
						+ "AND msr.service_id = srole.service_id (+) AND ms.member_num = ?";

				StringBuffer sMemSvcQuery = new StringBuffer(stringMemSvcQuery);

				log.info("{}{}DBTOOL_12 : Query = {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(sMemSvcQuery)));

				alQueryResponse = jdbcTemplate.queryForList(new String(sMemSvcQuery), sDBMemberNum);

				if (alQueryResponse != null && !alQueryResponse.isEmpty()) {
					for (int j = 0; j < alQueryResponse.size(); j++) {
						Map hmQueryResponse = (Map) alQueryResponse.get(j);
						Iterator itr = hmQueryResponse.keySet().iterator();
						HashMap hmMemberSvcRole = CommonUtil.getHashMap();
						while (itr.hasNext()) {
							String key = (String) itr.next();
							Object value = hmQueryResponse.get(key);
							String strValue = (value == null ? null : value.toString());
							hmMemberSvcRole.put(key, strValue);
						}
						alMemberSvcRoles.add(hmMemberSvcRole);
					}
				}

				log.debug(SpiMarker.getInstance(),"{}{}DBTOOL_13 : Result of member service query: {}", sClassName, sMethodName,
						alMemberSvcRoles);
			}

			if ((sReturnUserFraudLock != null && !sReturnUserFraudLock.isEmpty())
					&& (sReturnUserFraudLock.equals("Y"))) {

				String sUserFraudLockQuery = "SELECT member_num AS \"memberNum\", user_lock_level AS \"userLockLevel\", user_lock_reason AS \"userLockReason\" "
						+ "from userfraudlock WHERE member_num = ? ";

				log.info("{}{}DBTOOL_14 : Query = {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(sUserFraudLockQuery)));

				alQueryResponse = jdbcTemplate.queryForList(new String(sUserFraudLockQuery), sDBMemberNum);

				if (alQueryResponse != null && !alQueryResponse.isEmpty()) {
					for (int j = 0; j < alQueryResponse.size(); j++) {
						Map hmQueryResponse = (Map) alQueryResponse.get(j);
						Iterator itr = hmQueryResponse.keySet().iterator();
						while (itr.hasNext()) {
							String key = (String) itr.next();
							Object value = hmQueryResponse.get(key);
							String strValue = (value == null ? null : value.toString());
							hmUserFraudLock.put(key, strValue);
						}
					}
				}

				log.debug(SpiMarker.getInstance(),"{}{}DBTOOL_15 : Result of linked User fraud lock query: {} ", sClassName, sMethodName,
						hmUserFraudLock);
			}

			hmResult.put(MPSDefs.APP_STATUS_CODE, MPSDefs.MPS_SUCCESS);
			hmResult.put(MPSDefs.APP_STATUS_MSG, MPSDefs.MPS_SUCCESS_MSG);
			hmResult.put(MPSDefs.APP_CATEGORY_CODE, MPSDefs.CATEGORY_CODE_SUCCESS);

			hmResult.put("member", hmMember);

			if (alMemberSvcRoles != null && !alMemberSvcRoles.isEmpty()) {
				hmResult.put("memberservicerole", alMemberSvcRoles);
			}

			if (hmUserFraudLock != null && !hmUserFraudLock.isEmpty()) {
				hmResult.put(CommonDefs.USER_FRAUD_LOCK, hmUserFraudLock);
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			log.error("{}{}DBHLPE01 :  Error::{}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}DBHLPE02 : Exception = {}", sClassName, sMethodName, e);
		} finally {
			log.info(SpiMarker.getInstance(),"{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;
	}
}
