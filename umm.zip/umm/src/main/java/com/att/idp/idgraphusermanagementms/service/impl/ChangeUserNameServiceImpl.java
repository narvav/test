package com.att.idp.idgraphusermanagementms.service.impl;

import java.util.Map;

import jakarta.ws.rs.core.MultivaluedMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.ChangeUserNameHelper;
import com.att.idp.idgraphusermanagementms.resource.request.ChangeUserNameRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ChangeUserNameResponse;
import com.att.idp.idgraphusermanagementms.service.ChangeUserNameService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This class implements the ChangeUserNameService interface and provides the implementation for changing a user's name in the system.
 * It is annotated with @Service to indicate that it's a Spring Bean and @Transactional to handle the transaction management.
 *
 * It contains a method changeUserName which takes a ChangeUserNameRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return a ChangeUserNameResponse object.
 *
 * The ChangeUserNameRequest object encapsulates the details of the user name change operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class ChangeUserNameServiceImpl implements ChangeUserNameService {

	public static final Logger logger = LoggerFactory.getLogger(ChangeUserNameServiceImpl.class);

	private static String sClassName = "ChangeUserNameServiceImpl";

	@Autowired
	private ChangeUserNameHelper changeUserNameHelper;

	@Override
	public ChangeUserNameResponse changeUserName(ChangeUserNameRequest changeUserNameRequest,
			MultivaluedMap<String, String> requestHeader) {

		Map<String, Object> hmResponse = null;
		String sMethodName = ".changeUserName.";

		Map<String, Object> hmInput = CommonUtilHelper.objectToMap(changeUserNameRequest);

		String idpTraceid = (String) hmInput.get("idpTraceId");
		hmInput.put("dbusTransactionId", idpTraceid.split(":")[0]);

		logger.info("ChangeUserNameServiceImpl.changeUserName.CUNS_01 : Calling changeUserNameHelper with Input : {}", hmInput);

		hmResponse = changeUserNameHelper.changeUserName(hmInput);

		hmResponse=CommonUtilHelper.processHmResponse(hmResponse, hmInput, "ChangeUserNameHelper", ".changeUserName");
		hmResponse.put("idp-trace-id", changeUserNameRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME, "ChangeUserName");
		ChangeUserNameResponse changeUserNameResponse = CommonUtilHelper.generateChangeUserNameResponse(hmResponse);
		String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

		if (sTxnRollBack != null) {
			throw new InvalidInputDataException(hmResponse);
		}

		logger.info("{}{}CUNS_05 : Response from ChangeUserNameServiceImpl.changeUserName : {}", sClassName, sMethodName,
				changeUserNameResponse);
		return changeUserNameResponse;
	}
}
