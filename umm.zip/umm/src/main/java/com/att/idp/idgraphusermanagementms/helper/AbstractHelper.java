package com.att.idp.idgraphusermanagementms.helper;

import com.att.idp.logging.marker.SpiMarker;
import com.att.idp.idgraphusermanagementms.db.helper.FraudLockDBHelper;
import org.springframework.beans.factory.annotation.Autowired;
import com.att.mpsys.common.utils.*;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.argument.StructuredArguments;
import org.springframework.util.StringUtils;

import java.util.*;

@Slf4j
public abstract class AbstractHelper {
    private static final String sClassName = "AbstractHelper";

    @Autowired
    private FraudLockDBHelper fraudLockDBHelper;

    /**
     * This method converts a time period string into milliseconds.
     * The input string is expected to be in the format "unlockPeriod, timeLimitAttribute".
     * The method parses the string and returns the corresponding time period in milliseconds.
     *
     * @param stTimePeriod The time period string to be converted.
     * @return The time period in milliseconds.
     */
    protected long getTimePeriodInMSec(String stTimePeriod) {
        // Parse the config TIME_PERIOD in millisec
        StringTokenizer token = new StringTokenizer(stTimePeriod, CommonDefs.VALUE_SEPARATOR);
        String timeLimitAttribute = null;
        String stUnlockPeriod = null;
        long timePeriodInMSec = (long) 0.0;
        int count = 0;

        while (token.hasMoreTokens()) {
            count++;
            if (count == 1) {
                stUnlockPeriod = token.nextToken();
            }
            if (count == 2) {
                timeLimitAttribute = token.nextToken();
            }
        }

        float unlockPeriod = Float.parseFloat(stUnlockPeriod);
        log.info("unlockPeriod {}", unlockPeriod);
        if (timeLimitAttribute == null || timeLimitAttribute.trim().length() == 0) {
            timePeriodInMSec = (long) unlockPeriod;
        } else if (timeLimitAttribute.equals(MPSDefs.UNLOCK_PERIOD_SECOND)) {
            timePeriodInMSec = (long) unlockPeriod * 1000;
        } else if (timeLimitAttribute.equals(MPSDefs.UNLOCK_PERIOD_MINUTE)) {
            timePeriodInMSec = (long) unlockPeriod * 60 * 1000;
        } else if (timeLimitAttribute.equals(MPSDefs.UNLOCK_PERIOD_HOUR)) {
            timePeriodInMSec = (long) unlockPeriod * 60 * 60 * 1000;
        } else if (timeLimitAttribute.equals(MPSDefs.UNLOCK_PERIOD_DAY)) {
            timePeriodInMSec = (long) unlockPeriod * 24 * 60 * 60 * 1000;
        }
        return timePeriodInMSec;
    }

    /**
     * This method checks if a user or account is fraud locked in the MPS DB.
     * It takes a HashMap as input which contains user and account information.
     * The method follows a series of steps to perform the check operation.
     * Each step is clearly marked with a comment.
     *
     * @param hmInput The input HashMap containing the necessary data for the check operation.
     * @return A HashMap containing the result of the check operation.
     */
    // TODO: Refactor this method to improve readability and maintainability. It is moved here to reduce the duplicate code.
    protected Map<String, Object> checkFraudLock(Map<String, Object> hmInput) {
        String sMethodName = "checkFraudLock";
        String stAppInfo = null;
        Date tmsStartDate = new Date();
        HashMap hmResult = null;
        log.info(SpiMarker.getInstance(), "checkFraudLock.HLP000 : Input Hash :",
                StructuredArguments.entries(hmInput));
        try {
            if (hmInput == null || hmInput.isEmpty()) {
                stAppInfo = "Input HashMap is null or empty";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                log.info("{}{}CFL001 : {} " , sClassName , sMethodName, stAppInfo);
                return hmResult;
            }

            String sIgnoreUserFraudLock = null;
            String sIgnoreAccountFraudLock = null;

            if (hmInput.containsKey("ignoreUserFraudLock")) {
                sIgnoreUserFraudLock = (String) hmInput.remove("ignoreUserFraudLock");
            }

            if (hmInput.containsKey("ignoreAccountFraudLock")) {
                sIgnoreAccountFraudLock = (String) hmInput.remove("ignoreAccountFraudLock");
            }

            String sDBUserLockLvl = (String) hmInput.get(MPSDefs.DB_USER_LOCK_LEVEL);

            if (sIgnoreUserFraudLock == null || !sIgnoreUserFraudLock.equals(MPSDefs.YES)) {
                if (sDBUserLockLvl != null && !sDBUserLockLvl.isEmpty()) {
                    stAppInfo = "User is fraud locked in MPS DB";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_FRAUD_LOCKED_NUM, stAppInfo);
                    log.info("{}{}CFL002 : {} " , sClassName , sMethodName, stAppInfo);
                    return hmResult;
                }
            }

            boolean isAcctFraudLockedInDB = false;
            HashMap hmDBServices = (HashMap) hmInput.get(MPSDefs.SERVICES);
            if (hmDBServices != null && !hmDBServices.isEmpty()) {
                Iterator iter = hmDBServices.keySet().iterator();
                while (iter.hasNext()) {
                    String sDBSvcName = (String) iter.next();
                    if (CommonUtil.getInstanceServices(log).contains(sDBSvcName)) {
                        HashMap hmDBService = (HashMap) hmDBServices.get(sDBSvcName);
                        if (hmDBService != null && !hmDBService.isEmpty()) {
                            Iterator itr = hmDBService.keySet().iterator();
                            while (itr.hasNext()) {
                                String sKey = (String) itr.next();
                                Object obj = hmDBService.get(sKey);
                                if (obj != null && obj instanceof HashMap) {
                                    HashMap hmDBInstance = (HashMap) obj;
                                    if (hmDBInstance != null && !hmDBInstance.isEmpty()) {
                                        // Call FraudLockDBHelper to query account fraud lock
                                            HashMap<String, Object> fraudLockResult = fraudLockDBHelper.queryAccountFraudLock(hmDBInstance);
                                            if (fraudLockResult != null && fraudLockResult.containsKey(MPSDefs.FRAUD_LOCK)) {
                                                hmDBInstance.put("fraudLock", fraudLockResult.get(MPSDefs.FRAUD_LOCK));
                                            }
                                        if (hmDBInstance.get("fraudLock") != null) {
                                            ArrayList alDBAcctFraudLocks = (ArrayList) hmDBInstance.get("fraudLock");
                                            if (alDBAcctFraudLocks != null && !alDBAcctFraudLocks.isEmpty()) {
                                                for (int i = 0; i < alDBAcctFraudLocks.size(); i++) {
                                                    HashMap hmDBAcctFraudLock = (HashMap) alDBAcctFraudLocks.get(i);
                                                    if (hmDBAcctFraudLock != null && !hmDBAcctFraudLock.isEmpty()) {
                                                        String sDBAcctLocked = (String) hmDBAcctFraudLock
                                                                .get(MPSDefs.DB_ACCOUNT_LOCKED);
                                                        if (sDBAcctLocked != null
                                                                && sDBAcctLocked.equalsIgnoreCase(MPSDefs.YES)) {
                                                            isAcctFraudLockedInDB = true;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if (isAcctFraudLockedInDB) {
                                    break;
                                }
                            }
                        }
                    }
                    if (isAcctFraudLockedInDB) {
                        break;
                    }
                }
            }

            if (sIgnoreAccountFraudLock == null || !sIgnoreAccountFraudLock.equals(MPSDefs.YES)) {
                if (isAcctFraudLockedInDB) {
                    stAppInfo = "Account is fraud locked in MPS DB for the member";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ACCOUNT_IN_FRAUD_STATUS_NUM, stAppInfo);
                    log.info("{}{}CFL003 : {} " , sClassName , sMethodName, stAppInfo);
                    return hmResult;
                }
            }
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG);

        } catch (Exception e) {
            stAppInfo = "Exception thrown in checkFraudLock() method::" + e.getMessage();
            hmResult = CommonErrorMap.makeExceptionMap(e);
            log.error("{}{}CFL004 : {} " , sClassName , sMethodName, stAppInfo);
        } finally {
            log.info("{}{}CFL999 {} hmResult :: {}", sClassName , sMethodName,tmsStartDate.getTime(), hmResult);
        }
        return hmResult;
    }

    /**
     * This method checks if a member is active and has at least one active service.
     * It performs the following checks:
     * 1. Verifies if the member's state is active.
     * 2. Iterates through the member's services to check if any service is enabled.
     *
     * @param hmDbMemberServices A map containing the member's services and their details.
     *                           The key is the service type, and the value is a map with service details.
     * @param memberState The state of the member (e.g., active, inactive).
     * @return true if the member's state is active and at least one service is enabled, false otherwise.
     */
    protected boolean checkForActiveMemberAndService(Map<String, Object> hmDbMemberServices, String memberState) {
        String sMethodName = "checkForActiveMemberAndService";
        log.debug(SpiMarker.getInstance(), "checkForActiveMemberAndService : Input :",
                StructuredArguments.entries(hmDbMemberServices),memberState);

        // Check if the member state is active
        boolean isMemberStateActive = MPSDefs.INUSE_STATE.equals(memberState);
        if (!isMemberStateActive) {
            log.info("{}{}CFAMAS_01: MemberId is not active", sClassName, sMethodName);
            return false;
        }

        // Check if the member has any active services
        boolean hasActiveService = hmDbMemberServices.entrySet().stream()
                .anyMatch(entry -> MPSDefs.ENABLED.equals(((Map) entry.getValue()).get(MPSDefs.SERVICE_STATUS)));

        if (hasActiveService) {
            log.info("{}{}CFAMAS_02: Member has active service", sClassName, sMethodName);
        }

        return isMemberStateActive && hasActiveService;
    }

    /**
     * This method checks if any U-verse service is enabled for a given member.
     * It iterates through the provided map of member services and checks for specific service types
     * ("HISA", "VOIP", "IPTV") to determine if they are enabled or suspended.
     *
     * @param hmDbMemberServices A map containing the member's services and their details.
     *                           The key is the service type, and the value is a map with service details.
     * @return true if any of the specified U-verse services ("HISA", "VOIP", "IPTV") are enabled or suspended, false otherwise.
     */
    protected boolean checkUverseServiceEnabled(Map<String, Object> hmDbMemberServices) {
        String sMethodName = "checkUverseServiceEnabled";

        log.debug(SpiMarker.getInstance(), "checkUverseServiceEnabled : Input :",
                StructuredArguments.entries(hmDbMemberServices));

        // Iterate through the member services map
        for (Map.Entry<String, Object> entry : hmDbMemberServices.entrySet()) {
            String serviceType = entry.getKey();

            // Check if the service type is one of the U-verse services
            if (Arrays.asList("HISA", "VOIP", "IPTV").contains(serviceType)) {
                Map<String, Object> hmService = (Map<String, Object>) entry.getValue();
                String serviceStatus = (String) hmService.get(MPSDefs.SERVICE_STATUS);

                // Check if the service status is enabled or suspended
                if (MPSDefs.ENABLED.equals(serviceStatus) || MPSDefs.SUSPENDED.equals(serviceStatus)) {
                    log.info("{}{}CUSE_01: Uverse service is : {}", sClassName, sMethodName, serviceStatus);
                    return true; // Exit early if an active service is found
                }
            }
        }
        return false;
    }

    /**
     * This method checks the status of the PORTAL service for a given member.
     * It determines if the member has the PORTAL service and whether the service is active or suspended.
     * The method performs the following steps:
     * 1. Logs the input map for debugging purposes.
     * 2. Checks if the PORTAL service exists in the provided map.
     * 3. If the PORTAL service exists, retrieves its status and validates it.
     * 4. Logs appropriate messages based on the validation results.
     *
     * @param hmDbMemberServices A map containing the member's services and their details.
     *                           The key is the service type, and the value is a map with service details.
     * @return true if the member has the PORTAL service and its status is either "ENABLED" or "SUSPENDED",
     *         false otherwise.
     */
    protected boolean checkPortalServiceStatus(Map<String, Object> hmDbMemberServices) {
        String sMethodName = "checkPortalServiceStatus";
        log.debug(SpiMarker.getInstance(), "checkPortalServiceStatus : Input :",
                StructuredArguments.entries(hmDbMemberServices));

        // Check if the member has PORTAL service
        if (!hmDbMemberServices.containsKey(CommonDefs.PORTAL_SERVICE)) {
            log.info("{}{}CPSS_01: Member does not have PORTAL service", sClassName, sMethodName);
            return false;
        }

        HashMap<String, Object> hmPortal = (HashMap) hmDbMemberServices.get(CommonDefs.PORTAL_SERVICE);
        String portalStatus = (String) hmPortal.get(MPSDefs.SERVICE_STATUS);

        if (portalStatus == null) {
            log.info("{}{} CPSS_02 : Member's portal service status is null in DB.",
                    sClassName, sMethodName);
            return false;
        }

        if (!(portalStatus.equalsIgnoreCase(MPSDefs.ENABLED) || portalStatus.equalsIgnoreCase(MPSDefs.SUSPENDED))) {
            log.info("{}{} CPSS_03 : MemberID updates are not allowed when portal service is Terminated.",
                    sClassName, sMethodName);
            return false;
        }

        return true;
    }

    /**
     * Utility method to validate a HashMap input.
     * It checks if the input is null or empty and returns an error response if it is.
     *
     * @param input The input HashMap to validate.
     * @param errorCode The error code to return if validation fails.
     * @param sAppInfo Additional application information for logging.
     * @return A HashMap containing the error response if validation fails, null otherwise.
     */
    protected HashMap validateMapInput(HashMap input, int errorCode, String sAppInfo) {
        if (input == null || input.isEmpty()) {
            HashMap hmResponse = CommonErrorMap.makeCategoryMap(errorCode, sAppInfo);
            log.info(sAppInfo);
            return hmResponse;
        }
        return null;
    }

    /**
     * Utility method to validate a string input value.
     * It checks if the input is null or empty and returns an error response if it is.
     *
     * @param input The input value to validate.
     * @param errorCode The error code to return if validation fails.
     * @param sAppInfo Additional application information for logging.
     * @return A HashMap containing the error response if validation fails, null otherwise.
     */
    protected HashMap validateValue(String input, int errorCode, String sAppInfo) {
        if (!StringUtils.hasText(input)) {
            HashMap hmResponse = CommonErrorMap.makeCategoryMap(errorCode, sAppInfo);
            log.info(sAppInfo);
            return hmResponse;
        }
        return null;
    }

    /**
     * Utility method to validate a Yes/No input value.
     * It checks if the input is either 'Y' or 'N' (case-insensitive).
     * If the input is invalid, it returns an error response map.
     *
     * @param input The input value to validate.
     * @param errorCode The error code to return if validation fails.
     * @param sAppInfo Additional application information for logging.
     * @return A HashMap containing the error response if validation fails, null otherwise.
     */
    protected HashMap validateYNValue(String input, int errorCode, String sAppInfo) {
        input = input.toUpperCase();
        if (input != null && !(input.equals(CommonDefs.IND_Y) || input.equals(CommonDefs.IND_N))) {
            HashMap hmResponse = CommonErrorMap.makeCategoryMap(errorCode, sAppInfo);
            log.info(sAppInfo);
            return hmResponse;
        }
        return null;
    }

    /**
     * Utility method to check if the result map indicates a failure based on the application status code.
     * If the application status code is not a success, it logs the application info and returns true.
     *
     * @param result The result map containing application status code and info.
     * @return true if the operation has failed, false otherwise.
     */
    protected boolean hasFailed(HashMap result) {
        return hasFailed(result, MPSDefs.APP_STATUS_CODE);
    }

    protected boolean hasFailed(HashMap result, String statusProperty) {
        return hasFailed(result, statusProperty, null);
    }

    protected boolean hasFailed(HashMap result, String statusProperty, String logPrefix) {
        String appStatusCode = (String) result.get(statusProperty);
        logPrefix = StringUtils.hasText(logPrefix) ? logPrefix : "";
        if (!(CommonDefs.COMMON_SUCCESS.equals(appStatusCode))) {
            log.info(logPrefix + result.get(MPSDefs.APP_INFO));
            return true;
        }
        return false;
    }

    protected HashMap validateStatus(HashMap result, String statusProperty, String logPrefix) {
        String appStatusCode = (String) result.get(statusProperty);
        String appInfo = (String) result.get(MPSDefs.APP_INFO);
        logPrefix = StringUtils.hasText(logPrefix) ? logPrefix : "";
        if (!(CommonDefs.COMMON_SUCCESS.equals(appStatusCode))) {
            log.info(logPrefix + appInfo);
            HashMap hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(appStatusCode), appInfo);
            return hmResult;
        }
        return null;
    }
}
