package com.att.idp.idgraphusermanagementms.service.impl;

import java.util.Map;

import jakarta.ws.rs.core.MultivaluedMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.TxnRateLimitStatusHelper;
import com.att.idp.idgraphusermanagementms.resource.request.TransactionRateLimitRequest;
import com.att.idp.idgraphusermanagementms.resource.response.TransactionRateLimitResponse;
import com.att.idp.idgraphusermanagementms.service.TxnRateLimitStatusService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This class implements the TxnRateLimitStatusService interface and provides the implementation for checking the transaction rate limit status in the system.
 * It is annotated with @Service to indicate that it's a Spring Bean and @Transactional to handle the transaction management.
 *
 * It contains a method txnRateLimitStatus which takes a TransactionRateLimitRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return a TransactionRateLimitResponse object.
 *
 * The TransactionRateLimitRequest object encapsulates the details of the transaction rate limit status check operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class TxnRateLimitStatusServiceImpl implements TxnRateLimitStatusService {

	
	public static final Logger logger = LoggerFactory.getLogger(TxnRateLimitStatusServiceImpl.class);

	private static String sClassName = "TxnRateLimitStatusServiceImpl";

	@Autowired
	private TxnRateLimitStatusHelper txnRateLimitStatusHelperObj;

	@Override
	public TransactionRateLimitResponse txnRateLimitStatus(TransactionRateLimitRequest txnRateLimitStatusRequest,
			MultivaluedMap<String, String> requestHeader) {

		Map<String, Object> hmResponse = null;
		String sMethodName = ".txnRateLimitStatus.";

		Map<String, Object> hmInput = CommonUtilHelper.objectToMap(txnRateLimitStatusRequest);


		logger.info(SpiMarker.getInstance(),
				"TxnRateLimitStatusServiceImpl.txnRateLimitStatus.TRLS_01 : Calling TxnRateLimitStatusHelper with Input : {}",
				StructuredArguments.entries(hmInput));

		hmResponse = txnRateLimitStatusHelperObj.txnRateLimitStatus(hmInput);

		logger.info("{}{}TRLS_02 : Response from TxnRateLimitStatusHelper  : {}", sClassName, sMethodName, hmResponse);

		if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
			hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from txnRateLimitStatusHelperObj.txnRateLimitStatus");
			logger.info("{}{}TRLS_03 : Null response from txnRateLimitStatusHelperObj.txnRateLimitStatus", sClassName, sMethodName);
		} else {
			String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (stAppStatusCode == null) {
				hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from txnRateLimitStatusHelperObj.txnRateLimitStatus");
				logger.info("{}{}TRLS_04 : Null response from txnRateLimitStatusHelperObj.txnRateLimitStatus", sClassName,
						sMethodName);
			}
		}

		hmResponse.put("idp-trace-id", txnRateLimitStatusRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME, CommonDefs.TXN_RATE_LIMIT_STATUS);
		TransactionRateLimitResponse response = CommonUtilHelper.generateTxnRateLimitStatusResponse(hmResponse);

		String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

		if (sTxnRollBack != null) {
			throw new InvalidInputDataException(hmResponse);
		}
		logger.info("{}{}TRLS_05 : Response from TxnRateLimitStatusServiceImpl.txnRateLimitStatus : {}", sClassName, sMethodName,
				response);
		return response;
	}
}
