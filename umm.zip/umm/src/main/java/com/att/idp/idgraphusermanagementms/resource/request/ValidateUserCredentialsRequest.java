package com.att.idp.idgraphusermanagementms.resource.request;

import java.util.HashMap;
import java.util.Map;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class represents a request to validate a user's credentials in the system.
 * It contains fields for transactionName, callingSystemId, idpTraceId, domain, handle (userId), returnOnlineSecurityQuestions, agentId, isExternalCall, userCredentials, and a map for unknownAttributes.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 * It also overrides the toString method to return a JSON-style string representation of the object.
 *
 */
@Data
@Schema(name = "ValidateUserCredentialsRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
public class ValidateUserCredentialsRequest {

	private final String transactionName = "ValidateUserCredentials";

	protected String callingSystemId;
	
	@Schema(name = "idpTraceId")
	private String idpTraceId;
	
	private String domain;
	
	@NotNull(message = "userId is required in input request.|ValidateUserCredentials")
	@Size(min = 1, max = 127, message =  "userId length is invalid|ValidateUserCredentials")
	@JsonProperty("userId")
	@Schema(name = "userId")
	private String handle;

	@Size(min = 1, max = 1, message =  "returnOnlineSecurityQuestions length is invalid|ValidateUserCredentials")
	@Schema(name = "returnOnlineSecurityQuestions")
	private String returnOnlineSecurityQuestions;

	@Size(min = 1, max = 20, message =  "agentId length is invalid|ValidateUserCredentials")
	@Schema(name = "agentId")
	private String agentId;

	private String isExternalCall;

	@Valid
	@Schema(name = "userCredentials")
	protected UserCredentials userCredentials;

	/**
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
	 * @return Map<String,Object> The map of unknown attributes.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();

	@Override
	public String toString() {
		return "ValidateUserCredentialsRequest [transactionName=" + transactionName + ", callingSystemId="
				+ callingSystemId + ", idpTraceId=" + idpTraceId + ", domain=" + domain + ", handle=" + handle
				+ ", returnOnlineSecurityQuestions=" + returnOnlineSecurityQuestions + ", agentId=" + agentId
				+ ", isExternalCall=" + isExternalCall + ", userCredentials="
				+ userCredentials + "]";
	}	
}