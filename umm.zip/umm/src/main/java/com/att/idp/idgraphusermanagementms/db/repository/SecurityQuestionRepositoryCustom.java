package com.att.idp.idgraphusermanagementms.db.repository;

/**
 * This is a custom repository interface for security question related operations.
 * Additional methods for security question operations should be declared here.
 */
public interface SecurityQuestionRepositoryCustom {
	
	
	//public Long getSecurityQuestionId(String sSecurityQuestion) throws SQLException;
	
}
