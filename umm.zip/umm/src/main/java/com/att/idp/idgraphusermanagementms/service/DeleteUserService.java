package com.att.idp.idgraphusermanagementms.service;

import com.att.idp.idgraphusermanagementms.resource.request.DeleteUserRequest;
import com.att.idp.idgraphusermanagementms.resource.response.DeleteUserResponse;

import jakarta.ws.rs.core.MultivaluedMap;

/**
 * Service interface for deleting accessId or memberId.
 */
public interface DeleteUserService {

	/**
	 * Deletes a user based on the provided DeleteUserRequest and request headers.
	 *
	 * This method interacts with the service layer to process the deletion of a user
	 * identified by accessId or memberId. It validates the input request, logs the
	 * operation details, and returns a response indicating the success or failure
	 * of the deletion process.
	 *
	 * @param deleteUserRequest The request object containing the details of the user to be deleted.
	 * @param requestHeader The HTTP headers containing additional metadata for the request.
	 * @return A DeleteUserResponse object containing the result of the delete operation.
	 */
	DeleteUserResponse deleteUser(DeleteUserRequest deleteUserRequest, MultivaluedMap<String, String> requestHeader);
}