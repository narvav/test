package com.att.idp.idgraphusermanagementms.db.request;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * This is the DomainRequest class which implements Serializable interface.
 * It represents a request for a domain with properties like domainId, domainName, domainNameList, and domainDesc.
 * Each property has its respective getter and setter methods.
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({

})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DomainRequest implements Serializable{

	private static final long serialVersionUID = 969653024664005427L;

	private Long domainId;
	private String domainName;
	private List<String> domainNameList;
	private String domainDesc;
}