package com.att.idp.idgraphusermanagementms.integration;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.http.conn.ConnectTimeoutException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_OB;
import static com.att.idp.cd.observability.metrics.utils.Constants.URI;
import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.POST;
import static com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants.IDGRAPH_USERMANAGEMENTMS_OB;
import com.att.idp.http.client.RestApiClient;
import com.att.idp.http.client.config.RestTemplateBeanFactory;
import com.att.idp.idgraphusermanagementms.message.ClientExceptionMessage;
import com.att.idp.idgraphusermanagementms.utils.JsonService;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * For External IDP Rest Client Call
 *
 *
 */
@Component
@RefreshScope
public class MPSYSInternalRestClient implements RestApiClient {

	private static final Logger logger = LoggerFactory.getLogger(MPSYSInternalRestClient.class);

	private static String sClassName = "MPSYSInternalRestClient";

	@Value("${apiclient.rest.idgoud.url}")
	private String propOUDBaseUrl;

	@Value("${apiclient.rest.idgoua.url}")
	private String propOUABaseUrl;

	@Value("${apiclient.rest.idgcir.url}")
	private String propCIRBaseUrl;

	@Value("${apiclient.rest.idgiup.url}")
	private String propIUPBaseUrl;

	@Value("${apiclient.rest.og.url}")
	private String propOGBaseUrl;

	@Value("${apiclient.rest.idgoud.cuia.endpoint}")
	private String propCUIAEndpointPath;

	@Value("${apiclient.rest.idgoua.aa.endpoint}")
	private String propAAEndpointPath;

	@Value("${apiclient.rest.idgoua.ra.endpoint}")
	private String propRAEndpointPath;

	@Value("${apiclient.rest.idgiup.ip.endpoint}")
	private String propIPEndpointPath;

	@Value("${apiclient.rest.idgiup.iaa.endpoint}")
	private String propIAAEndpointPath;

	@Value("${apiclient.rest.idgoud.au.endpoint}")
	private String propAUEndpointPath;

	@Value("${apiclient.rest.ogs.og.endpoint}")
	private String propOGEndpointPath;

	@Value("${apiclient.rest.idgoua.cs.endpoint}")
	private String propCSEndpointPath;

	@Value("${apiclient.rest.default.userTypes.registered.username}")
	private String clientid;

	@Value("${apiclient.rest.default.userTypes.registered.password}")
	private String clientsecret;

	private RestTemplate restTemplate;

	@Autowired
	MPSYSInternalRestClient(RestTemplateBeanFactory restTemplateBeanFactory) throws Exception {
		this.restTemplate = restTemplateBeanFactory.getObject("MPSYSInternalRestClient");

	}

	/**
	 * This method is a generic method which supports multiple IDP MS to MS calls.
	 * It takes a HashMap as input which contains the necessary information for the rest client call.
	 * The method performs the rest client call and returns a HashMap containing the response.
	 * If the rest client call is successful, the response HashMap contains the response data.
	 * If the rest client call fails, the response HashMap contains the error information.
	 *
	 * @param hmRestClientInput The HashMap containing the necessary information for the rest client call.
	 * @return A HashMap containing the response from the rest client call.
	 * @throws JsonProcessingException If there is an error processing the JSON.
	 * @throws IOException If there is an I/O error.
	 */
	@TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_OB, type = REST_OB,
			description = "call IDP internal rest client",
			tags = {URI, "/msapi/idgraph/internal", METHOD, POST},
			histogram = true)
	@SuppressWarnings("unchecked")
	public Map<String, Object> callIDPRestClient(Map<String, Object> hmRestClientInput)
			throws JsonProcessingException, IOException {

		String sAppInfo = null;
		int appStatusCode = 0;
		String sMethodName = ".callRestClient.";
		logger.debug("{}{}ERC.CIDPRC.01 : Invoking MPSYSInternalRestClient.callIDPRestClient :", sClassName,sMethodName);
		String sTransactionName = (String) hmRestClientInput.get("transactionName");
		String sTransactionId = (String) hmRestClientInput.get("idpTraceId");

		Map<String, Object> jsonNode = null;
		String resourceUri = null;

		HttpHeaders reqheaders = populatingHeader(hmRestClientInput, sTransactionId);

		Map<String, Object> hmResult = new HashMap<>();

		resourceUri = getIDPContextPath(sTransactionName);
		if ("ChangeStatus".equals(sTransactionName)) {
			hmRestClientInput.remove("transactionName");
		}

		try {
			HttpEntity<?> httpEntity = null;
			ResponseEntity<JsonNode> output = null;

			String jsonObj = JsonService.getJsonFromObject(hmRestClientInput);
			httpEntity = new HttpEntity<>(jsonObj, reqheaders);
			logger.debug(SpiMarker.getInstance(), "{}{}ERC.CIDPRC.02.1 : Calling Endpoint {} with input : {} ",
					sClassName, sMethodName, sTransactionName, httpEntity);
			output = restTemplate.exchange(resourceUri, HttpMethod.POST, httpEntity, JsonNode.class);

			jsonNode = JsonService.getObjectFromJson(output.getBody(), HashMap.class);
			
			logger.info("{}{}ERC.CIDPRC.03 : Response from MPSYSInternalRestClient : {}",StringUtils.normalizeSpace( sClassName), StringUtils.normalizeSpace(sMethodName),
					jsonNode!=null ? StringUtils.normalizeSpace(jsonNode.toString()): null);

			if (HttpStatus.OK.equals(output.getStatusCode()) || HttpStatus.CREATED.equals(output.getStatusCode())) {
				Map<String, Object> hmSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
						CommonDefs.COMMON_SUCCESS_MSG);
				hmSuccess.putAll(jsonNode);
				hmResult.putAll(hmSuccess);

			} else {
				if (null != output) {
					logger.error(
							"MPSYSInternalRestClient.callRestClient response status code is not success. Status code: {}  ",
							output.getStatusCode());
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EXTERNAL_SYS_NUM,
							output.getBody().toString());
				}
			}
		} catch (Exception restClientException) {
			if (restClientException.getCause() instanceof SocketTimeoutException
					|| restClientException.getCause() instanceof ConnectTimeoutException) {
				sAppInfo = "Connection Timeout while making RestClientCall : " + sTransactionName;
				logger.info("{}{}ERC.CIDPRC.04 : Connection Timeout : {}", sClassName, sMethodName,
						restClientException.getMessage());
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_TRAN_TIME_OUT_NUM, sAppInfo);
			}

			else if (restClientException instanceof HttpClientErrorException) {
				HttpClientErrorException excp = (HttpClientErrorException) restClientException;
				if (excp.getStatusCode().equals(HttpStatus.BAD_REQUEST) || excp.getStatusCode().equals(HttpStatus.NOT_FOUND)) {

					logger.error("{}{}ERC.CIDPRC.04.5 : HttpClientErrorException while making RestClientCall {} : {}",
							sClassName, sMethodName, sTransactionName, excp.getMessage());
					ObjectMapper mapper = new ObjectMapper();
					ClientExceptionMessage msg = mapper.readValue(excp.getResponseBodyAsString(),
							ClientExceptionMessage.class);
					if (msg != null && msg.getAppStatusCode() != null) {
						sAppInfo = msg.getAppInfo() != null ? msg.getAppInfo() : excp.getMessage();
						appStatusCode = NumberUtils.toInt(msg.getAppStatusCode(), CErrorDefs.ERR_EXTERNAL_SYS_NUM);
					} else {
						// Fallback: parse error details from nested "error" object
						JsonNode errorBody = mapper.readTree(excp.getResponseBodyAsString());
						JsonNode errorNode = errorBody != null ? errorBody.get("error") : null;
						if (errorNode != null && (errorNode.has("errorId") || errorNode.has("code"))) {
							String errorCode = errorNode.has("errorId") ? errorNode.get("errorId").asText() : errorNode.get("code").asText();
							// Extract numeric code from pattern like "MS_MPSYS_BE_244"
							String numericCode = errorCode.replaceAll("\\D+", "");
							appStatusCode = NumberUtils.toInt(numericCode, CErrorDefs.ERR_EXTERNAL_SYS_NUM);
							sAppInfo = errorNode.has("message") ? errorNode.get("message").asText() : excp.getMessage();
						} else {
							appStatusCode = CErrorDefs.ERR_EXTERNAL_SYS_NUM;
							sAppInfo = excp.getMessage();
						}
						logger.info("{}{}ERC.CIDPRC.04.6 : Parsed error from nested error object - appStatusCode={}, appInfo={}",
								sClassName, sMethodName, appStatusCode, sAppInfo);
					}
					hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, sAppInfo);
				} else {
					sAppInfo = "Error from RestClientCall : " + sTransactionName;
					logger.info("{}{}ERC.CIDPRC.05 : Error from RestClientCall to IDP MS {} - HttpStatusCode : {}",
							sClassName, sMethodName, sTransactionName, excp.getRawStatusCode());
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EXTERNAL_SYS_NUM, sAppInfo);
				}
			}

			else {
				sAppInfo = "Error while making RestClientCall to IDP MS : " + restClientException.getMessage();
				logger.info("{}{}ERC.CIDPRC.06 : {} : {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(sAppInfo)), restClientException.getMessage());
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
			}
		}
		return hmResult;
	}

	/**
	 * Return context path for different IDP Ms. To support any new endpoints,
	 * please update the below check accordingly
	 * 
	 * @param sTransactionName
	 * @return resourceUri
	 */
	private String getIDPContextPath(String sTransactionName) {

		StringBuilder resourceUri = null;
		String sAppInfo = "Calling IDP MS";

		if ("CheckUserIdAvailability".equals(sTransactionName)) {
			resourceUri = new StringBuilder(propOUDBaseUrl);
			resourceUri.append(propCUIAEndpointPath);
			logger.debug("{} {}", HtmlUtils.htmlEscape(String.valueOf(sAppInfo)), "IDGraphUserManagementMs");
		} else if ("AddAssociation".equals(sTransactionName)) {
			resourceUri = new StringBuilder(propOUABaseUrl);
			resourceUri.append(propAAEndpointPath);
			logger.debug("{} {}", HtmlUtils.htmlEscape(String.valueOf(sAppInfo)), "IDGraphUserAssociationMs");
		} else if ("RemoveAssociation".equals(sTransactionName)) {
			resourceUri = new StringBuilder(propOUABaseUrl);
			resourceUri.append(propRAEndpointPath);
			logger.debug("{} {}", HtmlUtils.htmlEscape(String.valueOf(sAppInfo)), "IDGraphUserAssociationMs");
		} else if ("InquireAssociatedAccessIds".equals(sTransactionName)) {
			resourceUri = new StringBuilder(propIUPBaseUrl);
			resourceUri.append(propIAAEndpointPath);
			logger.debug("{} {}", HtmlUtils.htmlEscape(String.valueOf(sAppInfo)), "IDGraphUserProfileMs");
		} else if (CommonDefs.INQUIRE_PROFILE.equals(sTransactionName)) {
			resourceUri = new StringBuilder(propIUPBaseUrl);
			resourceUri.append(propIPEndpointPath);
			logger.debug("{} {}", HtmlUtils.htmlEscape(String.valueOf(sAppInfo)), "IDGraphUserProfileMs");
		} else if ("AddUser".equals(sTransactionName)) {
			resourceUri = new StringBuilder(propOUDBaseUrl);
			resourceUri.append(propAUEndpointPath);
			logger.debug("{} {}", HtmlUtils.htmlEscape(String.valueOf(sAppInfo)), "IDGraphUserManagementMs");

		} else if ("OrderGraph".equals(sTransactionName)) {
			resourceUri = new StringBuilder(propOGBaseUrl);
			resourceUri.append(propOGEndpointPath);
			logger.debug("{} {}", HtmlUtils.htmlEscape(String.valueOf(sAppInfo)), "OrderGraph");

		}else if ("ChangeStatus".equals(sTransactionName)) {
			resourceUri = new StringBuilder(propOUABaseUrl);
			resourceUri.append(propCSEndpointPath);
			logger.debug("{} {}", HtmlUtils.htmlEscape(String.valueOf(sAppInfo)), "IDGraphUserAssociationMs");
		} else if ("RemoveAccount".equals(sTransactionName)) {
			resourceUri = new StringBuilder(propOUABaseUrl);
			resourceUri.append(propRAEndpointPath);
			logger.debug("{} {}", HtmlUtils.htmlEscape(String.valueOf(sAppInfo)), "IDGraphUserAssociationMs");
		}
		logger.info("IDPRestClient: GetUri:{}", resourceUri);
		return resourceUri.toString();
	}

	private HttpHeaders populatingHeader(Map<String, Object> hmInput, String straceID) {

		HttpHeaders reqheaders = new HttpHeaders();
		String sTransactionName = (String) hmInput.get("transactionName");

		reqheaders.add("Authorization",
				"Basic " + Base64.getEncoder().encodeToString((clientid + ":" + clientsecret).getBytes()));
		reqheaders.setContentType(MediaType.APPLICATION_JSON);

		if ("OrderGraph".equals(sTransactionName)) {
			reqheaders.add(CommonDefs.IDP_USER_TYPE, "registered");
			reqheaders.add("X-ATT-ClientId", "MPSYS");
		} else {
			reqheaders.add("X-ATT-ClientId", (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		}

		return reqheaders;
	}

}
