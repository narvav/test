package com.att.idp.idgraphusermanagementms.resource.request;

import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class represents a Service in the system.
 * It contains fields for serviceType, serviceStatus, sor, and a map for unknownAttributes.
 * Each field has specific constraints such as not null and size limits.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 *
 */
@Schema(name = "Service")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class Services {
	
	@Schema(name = "serviceType")
	@NotNull(message = "serviceType is required field in input request.|RegisterEmailUser")
	@Size(min = 1, max = 100, message =  "serviceType length is invalid|RegisterEmailUser")
	private String serviceType;

	@Schema(name = "serviceStatus")
	@Size(min = 1, max = 30, message =  "serviceStatus length is invalid|RegisterEmailUser")
	private String serviceStatus;

	@Schema(name = "sor")
	@Size(min = 1, max = 30, message =  "sor length is invalid|RegisterEmailUser")
	private String sor;
	
	/**
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
	 * @return Map<String,Object> The map of unknown attributes.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();

}

