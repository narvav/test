package com.att.idp.idgraphusermanagementms.db.helper;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import java.util.*;

/**
 * This class is a helper for managing merged Yahoo IDs in the database.
 */
@Component
public class MergeYahooIDDBHelper {

	private static String sClassName = "MergeYahooIDDBHelper";
	public static final Logger logger = LoggerFactory.getLogger(MergeYahooIDDBHelper.class);
	private static String dateFormat = "MMDDYYYY HH24:mi:ss";
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	/**
	 * This method retrieves merged Yahoo IDs from the database.
	 * @param hmInput A HashMap containing the input parameters.
	 * @return A HashMap containing the result of the operation.
	 */
	public HashMap getMergedYahooId(HashMap hmInput) {
		String sMethodName = "getMergedYahooId";
		String stAppInfo ;
		HashMap<String, Object> hmResult = CommonUtil.getHashMap();
		List<Object> objectList = CommonUtil.getArrayList();
		List alQueryResponse;
		String getMergeYahooIdSql =
				"SELECT  m.MEMBER_NUM , m.YAHOO_ID , m.ATT_MEMBER_ID, m.STATUS, TO_CHAR(m.LAST_MODIFIED, '"
						+dateFormat+"') AS LAST_MODIFIED, m.LAST_MODIFIED_BY FROM MERGEDYAHOOID m ";

		logger.info(ProfileOrchestrationConstants.LOG_DBTOOLS000, sClassName, sMethodName, hmInput);

		if (hmInput == null) {
			hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_EMPTY_NUM, "Input hash is empty");
			logger.info("{}{}GMYI001 : Input hash is empty: {} ", sClassName, sMethodName, hmResult);
			return hmResult;
		}
		try{
			String sWhereClause = null;
			String sYahooId = (String) hmInput.get(CommonDefs.YAHOO_ID);
			String sMemberNum = (String) hmInput.get(CommonDefs.MEMBER_NUM);

			if ((sYahooId == null || sYahooId.isEmpty()) && (sMemberNum == null || sMemberNum.isEmpty())) {
				stAppInfo = "Yahoo ID and Member_num in the input is null";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.error("{}{}GMYI002 : {} ", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			if (sYahooId != null && !sYahooId.isEmpty() && sMemberNum != null && !sMemberNum.isEmpty()) {
				sWhereClause = "WHERE m.MEMBER_NUM = ? AND m.YAHOO_id=?";
				getMergeYahooIdSql = getMergeYahooIdSql + sWhereClause;
				objectList.add(sMemberNum);
				objectList.add(sYahooId);

			} else if (sMemberNum != null && !sMemberNum.isEmpty()) {
				sWhereClause = "WHERE m.MEMBER_NUM = ?";
				getMergeYahooIdSql = getMergeYahooIdSql + sWhereClause;
				objectList.add(sMemberNum);
			} else if (sYahooId != null && !sYahooId.isEmpty()) {
				sWhereClause = "WHERE m.YAHOO_ID = ?";
				getMergeYahooIdSql = getMergeYahooIdSql + sWhereClause;
				objectList.add(sYahooId);
			}

			logger.debug("{}{}GMYI003 : getMergeYahooIdSql  = {} ", sClassName, sMethodName, getMergeYahooIdSql);
			alQueryResponse = jdbcTemplate.queryForList(new String(getMergeYahooIdSql),
					objectList.toArray(new Object[objectList.size()]));
			int numRowsFound = 0;
			HashMap hmMergeYahooId = null;

			if (alQueryResponse != null && !alQueryResponse.isEmpty()) {
                hmMergeYahooId = new HashMap();
                for (Object object : alQueryResponse) {
                    Map hmQueryResponse = (Map) object;
                    for (Object o : hmQueryResponse.keySet()) {
                        String key = (String) o;
                        Object value = hmQueryResponse.get(key);
                        String strValue = (value == null ? null : value.toString());
                        hmMergeYahooId.put(key.toLowerCase(), strValue);
                    }
                    ++numRowsFound;
                }
			}

			if (numRowsFound == 0) {
				stAppInfo = "No Record Found in DB";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo);
				logger.info("{}{}GMYI004 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,CommonDefs.COMMON_SUCCESS_MSG);
			if (hmMergeYahooId != null) {
				hmResult.put(CommonDefs.MERGE_YAHOO_ID, hmMergeYahooId);
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}GMYI005 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}GMYI006 : Exception = {}", sClassName, sMethodName, e);
		} finally {
			logger.info("{}{}DBHLP999 response : {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;
	}

	/**
	 * This method updates merged Yahoo IDs in the database.
	 * @param hmInput A HashMap containing the input parameters.
	 * @return A HashMap containing the result of the operation.
	 */
	public HashMap updateMergedYahooId(HashMap hmInput){
		String sMethodName = "updateMergedYahooId";
		String stAppInfo;
		HashMap<String, Object> hmResult = null;
		List<Object> objectList = CommonUtil.getArrayList();

		logger.info(ProfileOrchestrationConstants.LOG_DBTOOLS000, sClassName, sMethodName, hmInput);

		if (hmInput == null) {
			stAppInfo = "Input hash is empty";
			hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_INVALID_DATA_NUM, stAppInfo);
			logger.info("{}{}UMYI001 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}
		try{
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sYahooId = (String) hmInput.get(CommonDefs.YAHOO_ID);
			String sMemberNum = (String) hmInput.get(CommonDefs.MEMBER_NUM);
			String sStatus = (String) hmInput.get(CommonDefs.STATUS);

			if(sCallingSystemId == null ||(sYahooId == null && sMemberNum == null) || sStatus == null){
				stAppInfo = "One of CallingSystemId or (MemberNum and YahooId) or Status is null";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.error("{}{}UMYI002 : {} ", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			StringBuilder sUpdateMergeYahooIDSql = new StringBuilder("UPDATE MERGEDYAHOOID SET ");
			String sWhereClause = null;

			if(sYahooId != null && !sYahooId.isEmpty() && sMemberNum != null && !sMemberNum.isEmpty()){
				sWhereClause = "WHERE MEMBER_NUM=? AND YAHOO_ID=?" ;
			}
			else if(sMemberNum != null && !sMemberNum.isEmpty()){
				sWhereClause = "WHERE MEMBER_NUM=?";
			}
			else if(sYahooId != null && !sYahooId.isEmpty()){
				sWhereClause = "WHERE YAHOO_ID=?";
			}
			sUpdateMergeYahooIDSql.append( "STATUS = ? ,");
			sUpdateMergeYahooIDSql.append("LAST_MODIFIED_BY = ? ");
			sUpdateMergeYahooIDSql.append(sWhereClause);

			logger.info("{}{}UMYI003 : updateFraudUserSql = {}", sClassName, sMethodName, sUpdateMergeYahooIDSql);

			objectList.add(sStatus);
			objectList.add(sCallingSystemId);
			if(sYahooId != null && !sYahooId.isEmpty() && sMemberNum != null && !sMemberNum.isEmpty()){
				Long member_num = Long.parseLong(sMemberNum);
				objectList.add(member_num);
				objectList.add(sYahooId);
			}
			else if(sMemberNum != null && !sMemberNum.isEmpty()){
				Long member_num = Long.parseLong(sMemberNum);
				objectList.add(member_num);
			}
			else if(sYahooId != null && !sYahooId.isEmpty()){
				objectList.add(sYahooId);
			}

				int rowCount = jdbcTemplate.update(new String(sUpdateMergeYahooIDSql),
					objectList.toArray(new Object[objectList.size()]));

			if (rowCount == 0) {
				stAppInfo = "No Record found for input data";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo);
				logger.info("{}{}UMYI004 : {}", sClassName, sMethodName, stAppInfo);

			} else {
				stAppInfo = "Merge Yahoo ID attributes updated successfully";
				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, stAppInfo);
				logger.info("{}{}UMYI005 : {}", sClassName, sMethodName, stAppInfo);
			}

		}catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			logger.error("{}{}UMYI006 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}UMYI007 : Exception = {}", sClassName, sMethodName, e);
		} finally {
			logger.info(SpiMarker.getInstance(),"{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;
	}

}
