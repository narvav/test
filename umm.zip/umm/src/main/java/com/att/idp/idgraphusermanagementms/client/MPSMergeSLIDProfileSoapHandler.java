package com.att.idp.idgraphusermanagementms.client;


import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import static com.att.idp.cd.observability.metrics.utils.Constants.SOAP_OB;
import static com.att.idp.cd.observability.metrics.utils.Constants.URI;
import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.POST;
import static com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants.IDGRAPH_USERMANAGEMENTMS_SOAP_OB;
import com.att.cio.commonheader.v3.ru.WSException;
import com.att.cio.commonheader.v3.ru.WSNameValueType;
import com.att.idp.core.exception.ServiceException;
import com.att.idp.idgraphusermanagementms.message.ErrorMessages;
import com.att.idp.soap.config.SOAPClientConfigurer;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.ril.mpsys.mergeslidprofileresponse.v1.MergeSLIDProfileResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.SoapFaultDetail;
import org.springframework.ws.soap.SoapFaultDetailElement;
import org.springframework.ws.soap.client.SoapFaultClientException;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;

import jakarta.annotation.PostConstruct;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
@RefreshScope
public class MPSMergeSLIDProfileSoapHandler<I>  extends WebServiceGatewaySupport {
    public static final Logger log  = LoggerFactory.getLogger(MPSMergeSLIDProfileSoapHandler.class);
    private static final String API_NAME = "MergeSLIDProfile";
    private final String sClassName = "MPSMergeSLIDProfileSoapHandler";

    @Autowired
    private HttpComponentsMessageSender httpComponentsMessageSender;

    @Autowired
    private SOAPClientConfigurer soapClientConfigurer;

    @PostConstruct
    public void init() {
        String sMethodName = ".init.";
        log.debug("{}{}MUASH_01 : Invoked for SOAP client configuration", sClassName, sMethodName);
        if (soapClientConfigurer != null) {
            log.debug("{}{}MUASH_02 : Invoked for SOAP client configuration", sClassName, sMethodName);
            soapClientConfigurer.configure(this, API_NAME);
        }
    }

    @TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_SOAP_OB, type = SOAP_OB,
            description = "merge SLID profile SOAP call",
            tags = {URI, "/MergeSLIDProfileRILMPSWeb/RILMergeSLIDProfileService", METHOD, POST},
            histogram = true)
    @Retryable(maxAttemptsExpression = "${mps.api.retry.attempts}",
            value = { SoapFaultClientException.class, Exception.class })
    public Map<String, Object> invokeAPI(I request) {
        String sMethodName = ".invokeAPI.";
        WebServiceTemplate webServiceTemplate = getWebServiceTemplate();
        Map<String, Object> resphm = null;
        try {
            webServiceTemplate.setMessageSender(httpComponentsMessageSender);
            MergeSLIDProfileResponse response = (MergeSLIDProfileResponse) webServiceTemplate.marshalSendAndReceive(request);
            return CommonErrorMap.makeCategoryMap(0, response.getAppInfo());
        } catch(Exception ex){
            if(ex instanceof SoapFaultClientException) {
                log.error("{}{}MUASH_03 : Soap Fault Exception while calling MPS API - {}",  sClassName,
                        sMethodName, ex.getMessage(), ex);
                try {
                    resphm = handleSOAPFault((SoapFaultClientException)ex);
                    return resphm;
                } catch (IOException exp) {
                    ErrorMessages error = null;
                    try {
                        log.error("{}{}MUASH_04 : ERROR from MPS API - {}", sClassName,sMethodName, exp.getMessage());
                        error = ErrorMessages.MS_MPSYS_BE_602;
                    } catch (IllegalArgumentException iaex) {
                        error = ErrorMessages.MS_MPSYS_BE_602;
                    }
                    return makeErrorMap(error);
                }
            }else {
                log.error("{}{}MUASH_05 : Exception while calling MPS API - {}", sClassName,sMethodName,
                        ex.getMessage(),ex);
                throw new ServiceException(ErrorMessages.MS_MPSYS_BE_602);
            }

        }
    }


    /**
     * Creates an error map with the given error message.
     *
     * @param error the error message to be included in the map
     * @return a HashMap containing the error code
     */
    private HashMap<String, Object> makeErrorMap(ErrorMessages error) {
        HashMap<String, Object> errorMap = new HashMap<>();
        errorMap.put("errorCode", error.toString());
        return errorMap;
    }

    /**
     * Handles SOAP fault exceptions by extracting relevant details from the SOAP fault.
     *
     * @param soapFault the SOAP fault exception to handle
     * @return a map containing error details extracted from the SOAP fault
     * @throws IOException if an I/O error occurs while handling the SOAP fault
     */
    public Map<String, Object> handleSOAPFault(SoapFaultClientException soapFault) throws IOException {
        SoapFaultDetail soapFaultDetail = soapFault.getSoapFault().getFaultDetail();
        HashMap<String, Object> resphm = CommonUtil.getHashMap();
        if (soapFaultDetail !=null && soapFaultDetail.getDetailEntries() != null
                && soapFaultDetail.getDetailEntries().hasNext()) {
            SoapFaultDetailElement detailElementChild = soapFaultDetail.getDetailEntries().next();
            WSException wsException = null;
            Object exception = getWebServiceTemplate().getUnmarshaller().unmarshal(detailElementChild.getSource());
            if(exception instanceof WSException)
                wsException = (WSException)exception;
            if(wsException!=null) {
                String sAppCategoryCode = null;
                String sAppStatusCode = wsException.getErrorCode();
                String sAppStatusMsg = wsException.getMessage();
                String sErrorType = wsException.getErrorType();
                if (sErrorType != null && sErrorType.trim().length() > 0) {
                    sErrorType = sErrorType.trim();
                    if (sErrorType.equalsIgnoreCase("Functional")) {
                        sAppCategoryCode = "3";
                    } else if (sErrorType.equalsIgnoreCase("System")) {
                        sAppCategoryCode = "2";
                    }
                }
                Optional<WSNameValueType> appInfo = wsException.getWSNameValue().stream()
                        .filter(wsName -> wsName.getName().equalsIgnoreCase(MPSDefs.APP_INFO)).findFirst();
                String appInfoValue = appInfo.map(WSNameValueType::getValue).orElse(null);
                if (sAppStatusCode != null && !sAppStatusCode.equalsIgnoreCase("0")) {
                    resphm.put("appCategoryCode", sAppCategoryCode);
                    resphm.put("appStatusCode", sAppStatusCode);
                    resphm.put("appStatusMsg", sAppStatusMsg);
                    resphm.put("appInfo", appInfoValue);
                }
            } else {
                throw new ServiceException(ErrorMessages.MS_MPSYS_BE_602);
            }
        } else {
            throw new ServiceException(ErrorMessages.MS_MPSYS_BE_602);
        }
        return resphm;
    }

}
