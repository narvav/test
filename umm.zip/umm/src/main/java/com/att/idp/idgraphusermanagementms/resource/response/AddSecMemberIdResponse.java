package com.att.idp.idgraphusermanagementms.resource.response;

import com.att.idp.core.exception.ServiceError;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * Represents the response for adding a secondary member ID in the system.
 * This class contains various fields for response details and constraints.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "AddSecMemberIdResponse")
public class AddSecMemberIdResponse {

    /**
     * The name of the transaction.
     * This field is ignored in the JSON response.
     */
    @JsonIgnore
    private String transactionName;

    /**
     * The IDP trace ID.
     */
    @JsonProperty("idp-trace-id")
    private String idpTraceId;

    /**
     * Suggested user ID 1.
     */
    private String suggestedUserId1;

    /**
     * Suggested user ID 2.
     */
    private String suggestedUserId2;

    /**
     * Suggested user ID 3.
     */
    private String suggestedUserId3;

    /**
     * The generated password.
     */
    private String generatedPassword;

    /**
     * Service errors, if any.
     */
    @JsonProperty("error")
    private ServiceError errors;

    /**
     * The application category code.
     * This field is ignored in the JSON response.
     */
    @JsonIgnore
    private String appCategoryCode;
}