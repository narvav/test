package com.att.idp.idgraphusermanagementms.request.validator;

import com.att.idp.idgraphusermanagementms.resource.request.AddSecMemberIdRequest;
import com.att.idp.idgraphusermanagementms.resource.response.AddSecMemberIdResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import jakarta.ws.rs.core.HttpHeaders;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Optional;

/**
 * Validator for AddSecMemberIdRequest.
 * This class provides methods to validate the request for adding a secondary member ID.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class AddSecMemberIdRequestValidator {

    /**
     * Logger instance for logging events.
     */
    private static final Logger logger = LoggerFactory.getLogger(AddSecMemberIdRequestValidator.class);

    /**
     * Class name for logging purposes.
     */
    private static final String CLASS_NAME = "AddSecMemberIdRequestValidator";
    private static final String DOB_FORMAT = "MMddyyyy";
    private static final DateTimeFormatter DOB_FORMATTER = DateTimeFormatter.ofPattern(DOB_FORMAT);
    private static final int MINIMUM_AGE = 13;

    @Value("${AddSec_Allowed_CallingSystemIDs}")
    private String AddSecMemeberIDAllowedCallingSystemID;

    /**
     * Validates the AddSecMemberIdRequest.
     *
     * @param requestHeader The HTTP headers of the request.
     * @param request The request object containing the details for adding a secondary member ID.
     * @return An AddSecMemberIdResponse object containing the validation result.
     */
    public AddSecMemberIdResponse addSecMemberIdReqValidator(HttpHeaders requestHeader, AddSecMemberIdRequest request) {
        String methodName = ".addSecMemberIdReqValidator.";
        String traceId = CommonUtil.getTraceId(requestHeader);
        if (traceId == null || traceId.startsWith("AutoGen_")) {
            return logAndReturnError(CErrorDefs.ERR_INVALID_DATA_NUM, "Missing or Invalid IdpTraceId", traceId, methodName);
        }
        if (request == null) {
            return logAndReturnError(CErrorDefs.ERR_INVALID_DATA_NUM, "Input Request Parameter is NULL / Empty.", traceId, methodName);
        }

        request.setTransactionName(ProfileOrchestrationConstants.ADD_SEC_MEMBERID_TRANSACTION_NAME);
        request.setIdpTraceId(traceId);

        String clientId = requestHeader.getHeaderString("X-ATT-ClientId");
        if (clientId != null) {
            request.setCallingSystemId(clientId.toUpperCase());
        } else {
            return logAndReturnError(CErrorDefs.ERR_INVALID_DATA_NUM, "Missing or invalid X-ATT-ClientId in request header", traceId, methodName);
        }

        AddSecMemberIdResponse response = validateRequestInput(request);
        if (response != null) {
            return response;
        }

        logger.info(SpiMarker.getInstance(), "{}{}ASMIDRV_02 : Input Validation Successful", CLASS_NAME, methodName);
        return null;
    }

    /**
     * Validates the input fields of the AddSecMemberIdRequest.
     *
     * @param request The request object containing the details for adding a secondary member ID.
     * @return An AddSecMemberIdResponse object containing the validation result, or null if validation is successful.
     */
    private AddSecMemberIdResponse validateRequestInput(AddSecMemberIdRequest request) {
        String methodName = ".validateRequestInput";
        Optional.ofNullable(request.getDomain()).ifPresent(x -> request.setDomain(x.trim().toLowerCase()));
        Optional.ofNullable(request.getHandle()).ifPresent(x -> request.setHandle(x.trim().toLowerCase()));
        Optional.ofNullable(request.getParentHandle()).ifPresent(x -> request.setParentHandle(x.trim().toLowerCase()));
        Optional.ofNullable(request.getParentDomain()).ifPresent(x -> request.setParentDomain(x.trim().toLowerCase()));
        Optional.ofNullable(request.getContactEmail()).ifPresent(x -> request.setContactEmail(x.trim().toLowerCase()));
        Optional.ofNullable(request.getGender()).ifPresent(x -> request.setGender(x.trim().toUpperCase()));

        if (!request.unknownAttributes.isEmpty()) {
            return logAndReturnError(CErrorDefs.ERR_INVALID_DATA_NUM, "Invalid Attributes passed in AddSecMemberIdRequest : " + request.unknownAttributes, request.getIdpTraceId(), methodName);
        }

        ArrayList allowedCallingSystemID = null;
        //AddSecMemeberIDAllowedCallingSystemID =  IDPCALM|IDPWAM
        if (AddSecMemeberIDAllowedCallingSystemID == null || AddSecMemeberIDAllowedCallingSystemID.isBlank()) {
            return logAndReturnError(CErrorDefs.ERR_INVALID_DATA_NUM, "Missing configuration for AddSec_Allowed_CallingSystemIDs", request.getIdpTraceId(), methodName);
        } else
            allowedCallingSystemID = CommonUtil.parseToArray(AddSecMemeberIDAllowedCallingSystemID, CommonDefs.VALUE_SEPARATOR_CHAR);

        String callingSystemId = request.getCallingSystemId();
        if(!allowedCallingSystemID.contains(callingSystemId)){
            return logAndReturnError(CErrorDefs.ERR_INVALID_DATA_NUM, "Invalid callingSystemID :"+callingSystemId, request.getIdpTraceId(), methodName);
        }

        if (!isValidDomain(request)) {
            return logAndReturnError(CErrorDefs.ERR_INVALID_DATA_NUM, "Input domain value has to be att.net or same as of parentDomain value", request.getIdpTraceId(), methodName);
        }

        if (!isValidProofZip(request.getProofZip())) {
            return logAndReturnError(CErrorDefs.ERR_INVALID_DATA_NUM, "Input ZIP length is not one of the allowed lengths [5,10]", request.getIdpTraceId(), methodName);
        }

        if (isCALM(request)) {
            if (request.getAgentId() == null) {
                return logAndReturnError(CErrorDefs.ERR_INVALID_DATA_NUM, "agentId is mandatory for the callingSystemId IDPCALM", request.getIdpTraceId(), methodName);
            }
            if (request.getClearPassword() != null && !request.getClearPassword().trim().isEmpty()) {
                return logAndReturnError(CErrorDefs.ERR_INVALID_DATA_NUM, "clearPassword should not present in input request for the callingSystemId IDPCALM", request.getIdpTraceId(), methodName);
            }
        } else if (request.getClearPassword() == null) {
            return logAndReturnError(CErrorDefs.ERR_INVALID_DATA_NUM, "clearPassword is required in input request", request.getIdpTraceId(), methodName);
        }

        AddSecMemberIdResponse dobValidationResponse = validateDateOfBirth(request, methodName);
        if (dobValidationResponse != null) {
            return dobValidationResponse;
        }
        return null;
    }

    /**
     * Checks if the domain in the request is valid.
     *
     * @param request The request object containing the details for adding a secondary member ID.
     * @return true if the domain is valid, false otherwise.
     */
    private boolean isValidDomain(AddSecMemberIdRequest request) {
        String parentDomain = request.getParentDomain();
        String domain = request.getDomain();
        return parentDomain != null && !parentDomain.trim().isEmpty() && (domain.equals(parentDomain) || domain.equals("att.net"));
    }

    /**
     * Checks if the proof ZIP in the request is valid.
     *
     * @param proofZip The proof ZIP to be validated.
     * @return true if the proof ZIP is valid, false otherwise.
     */
    private boolean isValidProofZip(String proofZip) {
        return proofZip == null || proofZip.trim().isEmpty() || proofZip.length() == 5 || proofZip.length() == 10;
    }

    /**
     * Checks if the calling system ID in the request is CSRIDP.
     *
     * @param request The request object containing the details for adding a secondary member ID.
     * @return true if the calling system ID is CSRIDP, false otherwise.
     */
    private boolean isCALM(AddSecMemberIdRequest request) {
        return ProfileOrchestrationConstants.CALLING_SYSTEM_ID_IDPCALM.equals(request.getCallingSystemId());
    }

    /**
     * Logs an error and returns an AddSecMemberIdResponse with the error details.
     *
     * @param errorCode The error code.
     * @param errorMessage The error message.
     * @param traceId The trace ID.
     * @param methodName The method name.
     * @return An AddSecMemberIdResponse object containing the error details.
     */
    private AddSecMemberIdResponse logAndReturnError(int errorCode, String errorMessage, String traceId, String methodName) {
        logger.info(SpiMarker.getInstance(), "{}{}ASMIDRV_01 :: {}", CLASS_NAME, methodName, errorMessage);
        Map<String, Object> hmResponse = CommonUtil.getHashMap();
        hmResponse.put(CommonDefs.COMMON_APP_INFO, errorMessage);
        hmResponse.put("idp-trace-id", traceId);
        hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(errorCode));
        return CommonUtilHelper.generateAddSecMemberIdResponse(hmResponse);
    }

    /**
     * Validates the dateOfBirth field for MMDDYYYY format and minimum age.
     *
     * @param request The request object containing the dateOfBirth.
     * @param methodName The method name for logging.
     * @return An AddSecMemberIdResponse if validation fails, or null if valid.
     */
    private AddSecMemberIdResponse validateDateOfBirth(AddSecMemberIdRequest request, String methodName) {
        String dob = request.getDateOfBirth();
        if (dob != null && !dob.isBlank()) {
            if (!dob.matches("^(0[1-9]|1[0-2])(0[1-9]|[12][0-9]|3[01])\\d{4}$")) {
                return logAndReturnError(
                        CErrorDefs.ERR_INVALID_DATA_NUM,
                        "DateOfBirth must be in MMDDYYYY format|AddSecMemberId",
                        request.getIdpTraceId(),
                        methodName
                );
            }
            try {
                LocalDate dateOfBirth = LocalDate.parse(dob, DOB_FORMATTER);
                LocalDate today = LocalDate.now();
                int age = Period.between(dateOfBirth, today).getYears();
                if (age < MINIMUM_AGE) {
                    return logAndReturnError(
                            CErrorDefs.ERR_DOB_UNDER_13_NUM,
                            "User must be at least 13 years old",
                            request.getIdpTraceId(),
                            methodName
                    );
                }
            } catch (DateTimeParseException e) {
                return logAndReturnError(
                        CErrorDefs.ERR_INVALID_DATA_NUM,
                        "Invalid DateOfBirth value|AddSecMemberId",
                        request.getIdpTraceId(),
                        methodName
                );
            }
        }
        return null;
    }
}