package com.att.idp.idgraphusermanagementms.db.model;

import java.util.Date;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.ToString;

/**
 * The Tattribute class represents a single attribute in the database.
 * It contains various properties related to the attribute such as its ID, name,
 * maximum and minimum length of its value, and the date it was created.
 *
 * Each property has its own getter and setter methods.
 *
 * This class is annotated with JPA annotations, indicating that it is a JPA entity.
 * This means that instances of this class can be automatically persisted in the database.
 */
@Entity
@Table(name = "TATTRIBUTE", schema = "MPLS_OWNER")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Tattribute {

	@Id
	@Column(name = "ATTRIBUTE_ID")
	private Long attributeId;

	@Column(name = "COMPONENTTYPE_ID")
	private Long componenttypeId;

	@Column(name = "ATTRIBUTE_NAME")
	private String attributeName;

	@Column(name = "ATTRIBUTE_VALUE_MAX_LENGTH")
	private Long attributeValueMaxLength;

	@Column(name = "ATTRIBUTE_VALUE_MIN_LENGTH")
	private Long attributeValueMinLength;

	@Column(name = "CREATE_DATE")
	private Date createDate;
}