package com.att.idp.idgraphusermanagementms.resource.request;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.util.HashMap;
import java.util.Map;

/**
 * This class represents a request to add a secondary member ID in the system.
 * It contains fields for various details such as callingSystemId, transactionName, idpTraceId, domain, userId, clearPassword, parentDomain, parentUserId, firstName, lastName, nickName, lastFourSSN, securityQuestion, securityAnswer, contactEmail, proofZip, dateOfBirth, gender, agentId, passcode, online1SecurityQuestion, online1SecurityAnswer, online2SecurityQuestion, and online2SecurityAnswer.
 * Each field has specific constraints such as not blank, size limits, and patterns.
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 */
@Data
@Schema(name = "AddSecMemberIdRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
public class AddSecMemberIdRequest {

    private String callingSystemId;

    private String transactionName;

    @Schema(name = "idpTraceId")
    private String idpTraceId;

    @Schema(name = "domain")
    @NotBlank(message = "Domain is required in input request|AddSecMemberId")
    @Size(min = 1, max = 30, message =  "Domain length is invalid|AddSecMemberId")
    private String domain;

    @Schema(name = "memberId")
    @NotBlank(message = "MemberId is required in input request|AddSecMemberId")
    @Size(min = 1, max = 127, message =  "MemberId length is invalid|AddSecMemberId")
    @JsonProperty("memberId")
    private String handle;

    @Schema(name = "clearPassword")
    @Size(min = 6, max = 24, message =  "ClearPassword length is invalid|AddSecMemberId")
    private String clearPassword;

    @Schema(name = "parentDomain")
    @Size(min = 1, max = 30, message =  "ParentDomain length is invalid|AddSecMemberId")
    private String parentDomain;

    @Schema(name = "parentMemberId")
    @NotBlank(message = "ParentMemberId is required in input request|AddSecMemberId")
    @Size(min = 1, max = 127, message =  "ParentMemberId length is invalid|AddSecMemberId")
    @JsonProperty("parentMemberId")
    private String parentHandle;

    @Schema(name = "firstName")
    @NotBlank(message = "FirstName is required in input request|AddSecMemberId")
    @Size(min = 1, max = 50, message =  "FirstName length is invalid|AddSecMemberId")
    private String firstName;

    @Schema(name = "lastName")
    @NotBlank(message = "LastName is required in input request|AddSecMemberId")
    @Size(min = 1, max = 50, message =  "LastName length is invalid|AddSecMemberId")
    private String lastName;

    @Schema(name = "nickName")
    @Size(min = 1, max = 100, message =  "NickName length is invalid|AddSecMemberId")
    private String nickName;

    @Schema(name = "lastFourSSN")
    @Size(min = 4, max = 4, message =  "LastFourSSN length is invalid|AddSecMemberId")
    @Pattern(regexp = "\\d+$", message =  "LastFourSSN must be numeric|AddSecMemberId")
    private String lastFourSSN;

    @Schema(name = "securityQuestion")
    @Size(min = 1, max = 80, message =  "SecurityQuestion length is invalid|AddSecMemberId")
    @NotBlank(message = "SecurityQuestion is required in input request|AddSecMemberId")
    private String securityQuestion;

    @Schema(name = "securityAnswer")
    @Size(min = 4, max = 80, message =  "SecurityAnswer length is invalid|AddSecMemberId")
    @NotBlank(message = "SecurityAnswer is required in input request|AddSecMemberId")
    private String securityAnswer;

    @Schema(name = "contactEmail")
    @Email(message = "ContactEmail is invalid|AddSecMemberId")
    @Size(min = 1, max = 64, message =  "ContactEmail length is invalid|AddSecMemberId")
    private String contactEmail;

    @Schema(name = "proofZip")
    @NotBlank(message = "ProofZip is required in input request|AddSecMemberId")
    @Size(min = 5, max = 10, message =  "ProofZip length is invalid|AddSecMemberId")
    @Pattern(regexp = "^[0-9-]+$", message = "ProofZip contains invalid characters.Allowed chars are [0-9] and special char '-' only|AddSecMemberId")
    private String proofZip;

    @Schema(name = "dateOfBirth")
    @NotBlank(message = "DateOfBirth is required in input request|AddSecMemberId")
    @Size(min = 1, max = 8, message =  "DateOfBirth length is invalid|AddSecMemberId")
    private String dateOfBirth;

    @Schema(name = "gender")
    @Size(min = 1, max = 1, message =  "Gender length is invalid|AddSecMemberId")
    @Pattern(regexp = "[mMfF]", message="Gender must be F/M|AddSecMemberId")
    private String gender;

    @Schema(name = "agentId")
    @Size(min = 1, max = 20, message =  "AgentId length is invalid|AddSecMemberId")
    private String agentId;

    @Schema(name = "passcode")
    @Size(min = 4, max = 4, message =  "Passcode length is invalid|AddSecMemberId")
    @Pattern(regexp = "\\d+$", message =  "Passcode must be numeric|AddSecMemberId")
    private String passcode;

    @Schema(name = "online1SecurityQuestion")
    @Size(min = 1, max = 80, message =  "Online1SecurityQuestion length is invalid|AddSecMemberId")
    private String online1SecurityQuestion;

    @Schema(name = "online1SecurityAnswer")
    @Size(min = 4, max = 80, message =  "Online1SecurityAnswer length is invalid|AddSecMemberId")
    private String online1SecurityAnswer;

    @Schema(name = "online2SecurityQuestion")
    @Size(min = 1, max = 80, message =  "Online2SecurityQuestion length is invalid|AddSecMemberId")
    private String online2SecurityQuestion;

    @Schema(name = "online1SecurityAnswer")
    @Size(min = 4, max = 80, message =  "Online1SecurityAnswer length is invalid|AddSecMemberId")
    private String online2SecurityAnswer;

    @JsonAnySetter
    @JsonAnyGetter
    public Map<String,Object> unknownAttributes = new HashMap<>();

    /**
     * Returns a string representation of the AddSecMemberIdRequest object.
     * This method overrides the default toString method to provide a custom string representation of the object.
     *
     * @return A string representation of the AddSecMemberIdRequest object, including all its fields and their values.
     */
    @Override
    public String toString() {
        return "AddSecMemberIdRequest{" +
                "callingSystemId='" + callingSystemId + '\'' +
                ", domain='" + domain + '\'' +
                ", transactionName='" + transactionName + '\'' +
                ", userId='" + handle + '\'' +
                ", clearPassword='" + clearPassword + '\'' +
                ", parentDomain='" + parentDomain + '\'' +
                ", parentHandle='" + parentHandle + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", nickName='" + nickName + '\'' +
                ", lastFourSSN='" + lastFourSSN + '\'' +
                ", securityQuestion='" + securityQuestion + '\'' +
                ", securityAnswer='" + securityAnswer + '\'' +
                ", contactEmail='" + contactEmail + '\'' +
                ", proofZip='" + proofZip + '\'' +
                ", dateOfBirth='" + dateOfBirth + '\'' +
                ", gender='" + gender + '\'' +
                ", agentId='" + agentId + '\'' +
                ", passcode='" + passcode + '\'' +
                ", online1SecurityQuestion='" + online1SecurityQuestion + '\'' +
                ", online1SecurityAnswer='" + online1SecurityAnswer + '\'' +
                ", online2SecurityQuestion='" + online2SecurityQuestion + '\'' +
                ", online2SecurityAnswer='" + online2SecurityAnswer + '\'' +
                ", unknownAttributes=" + unknownAttributes +
                '}';
    }
}