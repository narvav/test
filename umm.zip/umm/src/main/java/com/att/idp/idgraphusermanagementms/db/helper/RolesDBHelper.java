package com.att.idp.idgraphusermanagementms.db.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.att.common.validators.SystemOfRecordValidation;
import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.mpsys.common.utils.*;
import net.logstash.logback.argument.StructuredArguments;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.apache.commons.lang3.StringUtils;
import com.att.common.validators.ServiceRoleValidation;

/**
 * This class, RolesDBHelper, is responsible for managing roles in the database.
 * It uses Spring's JdbcTemplate for database operations.
 * <p>
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like JdbcTemplate and DBHelper.
 */

@Component
public class RolesDBHelper {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private DBHelper oDBHelper;

    @Autowired
    private ServiceRoleValidation oServiceRoleValidation;
    @Autowired
    private SystemOfRecordValidation oSystemOfRecordValidation;

    @Autowired
    private ErrorMetricHandler errorMetricHandler;

    private static final String CLASS_NAME = "RolesDBHelper";
    public static final Logger logger = LoggerFactory.getLogger(RolesDBHelper.class);
    private static final String sAddRoleSql =
            "INSERT INTO memberservicerole (" +
                    " MEMBER_NUM, SERVICE_ID, SOR_ID, SOR_INVARIANT_ID, ROLE_ID, STATUS, " +
                    " LAST_MODIFIED_BY) " +
                    " VALUES (?, ?, ?, ?, ?, ?, ?)";

    /**
     * This method adds a role for a member in the database.
     * It takes a HashMap as input which contains key-value pairs for various role attributes like member number, service id, SOR id, SOR invariant id, role id, status, and last modified by.
     * The method first checks if the input HashMap is null or if it contains invalid data. If it does, it returns an error status.
     * Then it retrieves the role attributes from the input HashMap.
     * If the role attributes are not found, it returns an error status.
     * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
     * Finally, it returns a status indicating whether the operation was successful or not.
     *
     * @param hmDbInput A HashMap containing the details of the role to be added.
     * @return A HashMap containing the status of the operation and the added role's information.
     */
    public HashMap addEachRole(HashMap hmDbInput) {
        String sMethodName = ".addEachRole.";
        HashMap hmResult = null;
        List<Object> objectList = new ArrayList<Object>();
        String sEventData = "";
        int iSorId = 0;
        int iServiceId = 0;

        Date dtStartDate = new Date();

        logger.info("{}{}DBTOOLS000 : addEachRole InpParam : {}", CLASS_NAME, sMethodName, StructuredArguments.entries(hmDbInput));
        try {
            String sMemberNum = (String) hmDbInput.get(MPSDefs.DB_MEMBER_NUM);
            String sServiceId = (String) hmDbInput.get(MPSDefs.DB_SERVICE_ID);
            String sServiceName = (String) hmDbInput.get(MPSDefs.DB_SERVICE_NAME);
            String sSorId = (String) hmDbInput.get(MPSDefs.DB_SOR_ID);
            String sSorName = (String) hmDbInput.get(MPSDefs.DB_SOR_NAME);
            String sSorInvariantId = (String) hmDbInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
            String sRoleId = (String) hmDbInput.get(MPSDefs.DB_ROLE_ID);
            String sStatus = (String) hmDbInput.get(MPSDefs.DB_ROLE_STATUS);
            String sCallingSystemId = (String) hmDbInput.get(CommonDefs.CALLING_SYSTEM_ID);
            String sTransactionId = (String) hmDbInput.get(CommonDefs.TRANSACTION_ID);
            String sAgentId = (String) hmDbInput.get(MPSDefs.DB_AGENT_ID);
            String sIPAddress = (String) hmDbInput.get(MPSDefs.DB_SOURCE_IP_ADDRESS);

            if ((sSorId == null || sSorId.trim().isEmpty())
                    && (sSorName != null && !sSorName.trim().isEmpty())) {
                iSorId = oDBHelper.getSorId(sSorName);
            } else if (sSorId != null && !sSorId.trim().isEmpty()) {
                iSorId = Integer.parseInt(sSorId);
            }

            if ((sServiceId == null || sServiceId.trim().isEmpty())
                    && (sServiceName != null && !sServiceName.trim().isEmpty())) {
                iServiceId = oDBHelper.getServiceId(sServiceName);
            } else if (sServiceId != null && !sServiceId.trim().isEmpty()) {
                iServiceId = Integer.parseInt(sServiceId);
            }

            sEventData = "member_num: " + sMemberNum +
                    "; service_id: " + iServiceId +
                    "; sor_id: " + iSorId +
                    "; sor_invariant_id: " + sSorInvariantId +
                    "; role_id: " + sRoleId +
                    "; status: " + sStatus +
                    "; last_modified_by: " + sCallingSystemId +
                    "; transaction_id: " + sTransactionId;

            if (sAgentId != null)
                sEventData = sEventData + "; agent_id: " + sAgentId;
            if (sIPAddress != null)
                sEventData = sEventData + "; IPAddress: " + sIPAddress;

            //get status_id corresponding to status_name
            int sStatusId = oDBHelper.getStatusCode(sStatus);

            objectList.add(sMemberNum);
            objectList.add(iServiceId);
            objectList.add(iSorId);
            objectList.add(sSorInvariantId);
            objectList.add(sRoleId);
            objectList.add(sStatusId);
            objectList.add(sCallingSystemId);

            long pTime = 0;
            Date tQueryTime = new Date();

            logger.info("{}{}RDBH.AER.01: sAddRoleSql: {}",CLASS_NAME, sMethodName, sAddRoleSql);

            int iRoleCount = jdbcTemplate.update(new String(sAddRoleSql), objectList.toArray
                    (new Object[objectList.size()]));
            pTime = (System.currentTimeMillis() - tQueryTime.getTime());

            logger.info("QUERY999 : Total time taken to execute add role = {} milliseconds", pTime);
            logger.info("DBTOOLS_03 : No of rows inserted in TMEMBERSERVICEROLE:= {}", iRoleCount);

            hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                    "Successfully Added Roles into MEMBERSERVICEROLE Table");

        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            if (null != e.getMessage() && e.getMessage().contains("ORA-00001: unique constraint")) {
                hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                        "Role association already exist in MEMBERSERVICEROLE Table");
                logger.info("DBTOOLS_E2 : resultHash ::{}", hmResult);
            } else {
                hmResult = StatusMsg.makeExceptionSQLStatus(e);
                logger.error("DBTOOLS_E2 : Error::{}", e.getMessage());
                logger.error("DBTOOLS_E2a : Exception = {}", e);
            }

        } finally {
            logger.info("{}{}DBTOOLS999 : response : {}", CLASS_NAME, sMethodName, hmResult);
        }

        return hmResult;
    }

    /**
     * This method updates the status of each role in the list of roles provided.
     * It first validates the input parameters and returns an error map if any of the required parameters are missing or invalid.
     * Then, it constructs a SQL update statement to update the status of each role in the MEMBERSERVICEROLE table.
     * It executes the update statement using JdbcTemplate and logs the number of rows updated.
     * If no rows are updated, it returns an error map with an appropriate message.
     * If the update is successful, it returns a success map with an appropriate message.
     * If an exception occurs during the process, it returns an exception map with the exception message.
     *
     * @param hmDbInput A HashMap containing the input parameters required for the update operation.
     * @return A HashMap containing the result of the update operation. If the operation is successful,
     * the map contains the success status code.
     * If the operation fails, the map contains the error status code and the error message.
     */
    public HashMap updateRoleStatus(HashMap hmDbInput) {
        String sMethodName = ".updateRoleStatus.";
        HashMap hmResult = null;
        List<Object> objectList = CommonUtil.getArrayList();
        ArrayList alUpdateRoleList = null;
        HashMap hmResponse;
        HashMap hmUpdateRole = null;
        String stAppInfo;

        Date dtStartDate = new Date();
        logger.info("{}{}DBTOOLS000 : updateRoleStatus InpParam : {}", CLASS_NAME, sMethodName, StructuredArguments.entries(hmDbInput));

        try {

            String sLastModifiedby = (String) hmDbInput.get(CommonDefs.CALLING_SYSTEM_ID);

            if (sLastModifiedby == null || sLastModifiedby.trim().isEmpty()) {
                stAppInfo = "Input callingSystemId is null or empty";
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                logger.info("{}{}URS001 : {}", CLASS_NAME, sMethodName, stAppInfo);
                return hmResponse;
            }
            alUpdateRoleList = (ArrayList) hmDbInput.get(CommonDefs.KEY_UPDATE_ROLE_STATUS);

            if (alUpdateRoleList == null || alUpdateRoleList.isEmpty()) {
                stAppInfo = "Input request to update role status is empty";
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                logger.info("{}{}URS002 : {}", CLASS_NAME, sMethodName, stAppInfo);
                return hmResponse;
            }
            int totalCount = 0;

            String sUpdateRoleStatusInfoSQL = "UPDATE MEMBERSERVICEROLE SET LAST_MODIFIED_BY=?, " +
                    "STATUS=? WHERE MEMBER_NUM=? AND ROLE_ID=? AND SERVICE_ID=? AND SOR_INVARIANT_ID=?";

            for (int i = 0; i < alUpdateRoleList.size(); i++) {
                String sUpdateRoleStatusSQL = sUpdateRoleStatusInfoSQL;
                hmUpdateRole = (HashMap) alUpdateRoleList.get(i);

                String sSorInvariantId = (String) hmUpdateRole.get(MPSDefs.DB_SOR_INVARIANT_ID);
                String sMemberNum = (String) hmUpdateRole.get(MPSDefs.DB_MEMBER_NUM);
                String sRoleStatus = (String) hmUpdateRole.get(MPSDefs.DB_ROLE_STATUS);
                String sServiceName = (String) hmUpdateRole.get(MPSDefs.DB_SERVICE_NAME);
                String sRoleName = (String) hmUpdateRole.get(MPSDefs.DB_ROLE_NAME);
                String sRoleId = (String) hmUpdateRole.get(MPSDefs.DB_ROLE_ID);
                String sServiceId = (String) hmUpdateRole.get(MPSDefs.DB_SERVICE_ID);
                String sSorId = (String) hmUpdateRole.get(MPSDefs.DB_SOR_ID);
                String sSorName = (String) hmUpdateRole.get(MPSDefs.DB_SOR_NAME);

                if (sSorInvariantId == null || sSorInvariantId.trim().isEmpty()
                        || sMemberNum == null || sMemberNum.trim().isEmpty()
                        || sRoleStatus == null || sRoleStatus.trim().isEmpty()) {
                    stAppInfo = "Input sor_invariant_id or member_num or role_status or service_name is null or empty";
                    hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                    logger.info("{}{}URS003 : {}", CLASS_NAME, sMethodName, stAppInfo);
                    return hmResponse;
                }

                if ((sRoleName == null || sRoleName.trim().isEmpty())
                        && (sRoleId == null || sRoleId.trim().isEmpty())) {
                    stAppInfo = "Input role_name OR role_id is required";
                    hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                    logger.info("{}{}URS004 : {}", CLASS_NAME, sMethodName, stAppInfo);
                    return hmResponse;
                }

                if ((sServiceName == null || sServiceName.trim().isEmpty())
                        && (sServiceId == null || sServiceId.trim().isEmpty())) {
                    stAppInfo = "Input service_name OR service_id is required";
                    hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                    logger.info("{}{}URS005 : {}", CLASS_NAME, sMethodName, stAppInfo);
                    return hmResponse;
                }

                int iSorId = 0;
                int iServiceId = 0;
                int iRoleId = 0;
                long iMemberNum = 0;

                if (sSorId != null && !sSorId.trim().isEmpty()) {
                    iSorId = Integer.parseInt(sSorId);
                } else if (sSorName != null && !sSorName.trim().isEmpty()) {
                    iSorId = oDBHelper.getSorId(sSorName);
                }

                if (iSorId > 0) {
                    sUpdateRoleStatusSQL = sUpdateRoleStatusSQL + " AND SOR_ID=?";
                }
                logger.info("{}{}RDBH.URS updateRoleStatus: SQL {}", CLASS_NAME, sMethodName,
                        sUpdateRoleStatusSQL);
                if (sServiceId != null && !sServiceId.trim().isEmpty()) {
                    iServiceId = Integer.parseInt(sServiceId);
                } else {
                    iServiceId = oDBHelper.getServiceId(sServiceName);
                }

                if (sRoleId != null && !sRoleId.trim().isEmpty()) {
                    iRoleId = Integer.parseInt(sRoleId);
                } else {
                    iRoleId = oDBHelper.getRoleId(sRoleName, iServiceId);
                }
                if (!sMemberNum.trim().isEmpty()) {
                    iMemberNum = Long.parseLong(sMemberNum);
                }
                int statusCode = oDBHelper.getStatusCode(sRoleStatus);

                long pTime = 0;
                Date tQueryTime = new Date();

                objectList.add(sLastModifiedby);
                objectList.add(statusCode);
                objectList.add(iMemberNum);
                objectList.add(iRoleId);
                objectList.add(iServiceId);
                objectList.add(sSorInvariantId);
                if (iSorId > 0)
                    objectList.add(iSorId);

                int iRoleCount = jdbcTemplate.update(new String(sUpdateRoleStatusSQL), objectList.toArray
                        (new Object[objectList.size()]));
                pTime = (System.currentTimeMillis() - tQueryTime.getTime());
                logger.info("URS007 : Total time taken to execute update role = {} milliseconds", pTime);
                logger.info("URS008 : No of rows updated in MEMBERSERVICEROLE:= {}", iRoleCount);
                hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                        "Successfully Updated Roles into MEMBERSERVICEROLE Table");

                if (iRoleCount == 0) {
                    stAppInfo = "No Records updated";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo);
                    logger.info("{}{}URS009 : {}", CLASS_NAME, sMethodName, stAppInfo);
                } else {
                    stAppInfo = "Role Status updated successfully";
                    hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, stAppInfo);
                    logger.info("{}{}URS010 : {}", CLASS_NAME, sMethodName, stAppInfo);
                }
            }

            hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                    "Successfully Added Roles into MEMBERSERVICEROLE Table");

        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            if (null != e.getMessage() && e.getMessage().contains("ORA-00001: unique constraint")) {
                hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                        "Role association already exist in MEMBERSERVICEROLE Table");
                logger.info("URS011 : resultHash ::{}", hmResult);
            } else {
                hmResult = StatusMsg.makeExceptionSQLStatus(e);
                logger.error("URS012 : Error::{}", e.getMessage());
                logger.error("URS013 : Exception = {}", e);
            }

        } finally {
            logger.info("DBTOOLS999 : {} hmResult : {}", dtStartDate.getTime(), hmResult);
        }

        return hmResult;
    }

    /**
     * This method updates the role ID for each role in the list of roles provided.
     * It first validates the input parameters and returns an error map if any of the required parameters are missing or invalid.
     * Then, it constructs a SQL update statement to update the role ID of each role in the MEMBERSERVICEROLE table.
     * It executes the update statement using JdbcTemplate and logs the number of rows updated.
     * If no rows are updated, it returns an error map with an appropriate message.
     * If the update is successful, it returns a success map with an appropriate message.
     * If an exception occurs during the process, it returns an exception map with the exception message.
     *
     * @param hmDbInput A HashMap containing the input parameters required for the update operation.
     * @return A HashMap containing the result of the update operation. If the operation is successful,
     * the map contains the success status code.
     * If the operation fails, the map contains the error status code and the error message.
     */
    public HashMap updateRoleID(HashMap hmDbInput) {
        String sMethodName = ".updateRoleID.";
        HashMap hmResult = null;
        List<Object> objectList = CommonUtil.getArrayList();
        ArrayList alUpdateRoleList = null;
        HashMap hmResponse;
        HashMap hmUpdateRole = null;
        String sEventData = "";
        String stAppInfo;

        Date dtStartDate = new Date();
        logger.info("{}{}DBTOOLS000 : updateRoleID InpParam : {}", CLASS_NAME, sMethodName, StructuredArguments.entries(hmDbInput));
        try {
            String sLastModifiedby = (String) hmDbInput.get(CommonDefs.CALLING_SYSTEM_ID);
            if (sLastModifiedby == null || sLastModifiedby.trim().isEmpty()) {
                stAppInfo = "Input callingSystemId is null or empty";
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                logger.info("{}{}URI001 : {}", CLASS_NAME, sMethodName, stAppInfo);
                return hmResponse;
            }
            alUpdateRoleList = (ArrayList) hmDbInput.get(CommonDefs.KEY_UPDATE_ROLE_ID);

            if (alUpdateRoleList == null || alUpdateRoleList.isEmpty()) {
                stAppInfo = "Input request to update role status is empty";
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                logger.info("{}{}URI002 : {}", CLASS_NAME, sMethodName, stAppInfo);
                return hmResponse;
            }
            int totalCount = 0;

            String sUpdateRoleIDInfoSQL = "UPDATE MEMBERSERVICEROLE SET LAST_MODIFIED_BY=?, ROLE_ID=? " +
                    " WHERE MEMBER_NUM=? AND SERVICE_ID=? AND SOR_INVARIANT_ID=?";

            for (int i = 0; i < alUpdateRoleList.size(); i++) {
                String sUpdateSQL = sUpdateRoleIDInfoSQL;
                hmUpdateRole = (HashMap) alUpdateRoleList.get(i);

                String sSorInvariantId = (String) hmUpdateRole.get(MPSDefs.DB_SOR_INVARIANT_ID);
                String sMemberNum = (String) hmUpdateRole.get(MPSDefs.DB_MEMBER_NUM);
                String sServiceName = (String) hmUpdateRole.get(MPSDefs.DB_SERVICE_NAME);
                String sRoleName = (String) hmUpdateRole.get(MPSDefs.DB_ROLE_NAME);
                String sRoleId = (String) hmUpdateRole.get(MPSDefs.DB_ROLE_ID);
                String sServiceId = (String) hmUpdateRole.get(MPSDefs.DB_SERVICE_ID);
                String sSorId = (String) hmUpdateRole.get(MPSDefs.DB_SOR_ID);
                String sSorName = (String) hmUpdateRole.get(MPSDefs.DB_SOR_NAME);

                if (sSorInvariantId == null || sSorInvariantId.trim().isEmpty()
                        || sMemberNum == null || sMemberNum.trim().isEmpty()) {
                    stAppInfo = "Input sor_invariant_id or member_num or service_name is null or empty";
                    hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                    logger.info("{}{}URI003 : {}", CLASS_NAME, sMethodName, stAppInfo);
                    return hmResponse;
                }

                if ((sRoleName == null || sRoleName.trim().isEmpty())
                        && (sRoleId == null || sRoleId.trim().isEmpty())) {
                    stAppInfo = "Input role_name OR role_id is required";
                    hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                    logger.info("{}{}URI004 : {}", CLASS_NAME, sMethodName, stAppInfo);
                    return hmResponse;
                }

                if ((sServiceName == null || sServiceName.trim().isEmpty())
                        && (sServiceId == null || sServiceId.trim().isEmpty())) {
                    stAppInfo = "Input service_name OR service_id is required";
                    hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                    logger.info("{}{}URI005 : {}", CLASS_NAME, sMethodName, stAppInfo);
                    return hmResponse;
                }

                int iSorId = 0;
                int iServiceId = 0;
                int iRoleId = 0;
                long iMemberNum = 0;

                if (sSorId != null && !sSorId.trim().isEmpty()) {
                    iSorId = Integer.parseInt(sSorId);
                } else if (sSorName != null && !sSorName.trim().isEmpty()) {
                    iSorId = oDBHelper.getSorId(sSorName);
                }

                if (iSorId > 0) {
                    sUpdateSQL = sUpdateSQL + " AND SOR_ID=?";
                }

                if (sServiceId != null && !sServiceId.trim().isEmpty()) {
                    iServiceId = Integer.parseInt(sServiceId);
                } else {
                    iServiceId = oDBHelper.getServiceId(sServiceName);
                }

                if (sRoleId != null && !sRoleId.trim().isEmpty()) {
                    iRoleId = Integer.parseInt(sRoleId);
                } else {
                    iRoleId = oDBHelper.getRoleId(sRoleName, iServiceId);
                }
                if (!sMemberNum.trim().isEmpty()) {
                    iMemberNum = Long.parseLong(sMemberNum);
                }

                long pTime = 0;
                Date tQueryTime = new Date();

                objectList.clear();
                objectList.add(sLastModifiedby);
                objectList.add(iRoleId);
                objectList.add(iMemberNum);
                objectList.add(iServiceId);
                objectList.add(sSorInvariantId);
                if (iSorId > 0)
                    objectList.add(iSorId);

                logger.info("{}{} URI006 : UpdateRoleIDSQL: {}", CLASS_NAME, sMethodName,sUpdateSQL);
                int iRoleCount = jdbcTemplate.update(new String(sUpdateSQL), objectList.toArray
                        (new Object[objectList.size()]));
                pTime = (System.currentTimeMillis() - tQueryTime.getTime());
                logger.info("URI007 : Total time taken to execute update role = {} milliseconds", pTime);
                logger.info("URI008 : No of rows updated in MEMBERSERVICEROLE:= {}", iRoleCount);
                hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                        "Successfully Updated Roles into MEMBERSERVICEROLE Table");

                if (iRoleCount == 0) {
                    stAppInfo = "No Records updated";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo);
                    logger.info("{}{}URI009 : {}", CLASS_NAME, sMethodName, stAppInfo);

                } else {
                    stAppInfo = "Role Status updated successfully";
                    hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, stAppInfo);
                    logger.info("{}{}URI010 : {}", CLASS_NAME, sMethodName, stAppInfo);
                }
            }

            hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                    "Successfully Added Roles into MEMBERSERVICEROLE Table");

        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            if (null != e.getMessage() && e.getMessage().contains("ORA-00001: unique constraint")) {
                hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                        "Role association already exist in MEMBERSERVICEROLE Table");
                logger.info("URI011 : resultHash ::{}", hmResult);
            } else {
                hmResult = StatusMsg.makeExceptionSQLStatus(e);
                logger.error("URI012 : Error::{}", e.getMessage());
                logger.error("URI013 : Exception = {}", e);
            }

        } finally {
            logger.info("DBTOOLS999 : {} hmResult : {}", dtStartDate.getTime(), hmResult);
        }
        return hmResult;
    }

    /**
     * This method removes a role from the MEMBERSERVICEROLE table in the database.
     * It first validates the input parameters and returns an error map if any of the required parameters are missing or invalid.
     * Then, it constructs a SQL delete statement to remove the role from the MEMBERSERVICEROLE table.
     * It executes the delete statement using JdbcTemplate and logs the number of rows deleted.
     * If no rows are deleted, it returns an error map with an appropriate message.
     * If the delete operation is successful, it returns a success map with an appropriate message.
     * If an exception occurs during the process, it returns an exception map with the exception message.
     *
     * @param hmInput A HashMap containing the input parameters required for the delete operation.
     * @return A HashMap containing the result of the delete operation. If the operation is successful, the map
     * contains the success status code.
     * If the operation fails, the map contains the error status code and the error message.
     */
    public HashMap removeEachRole(HashMap hmInput) {

        String sMethodName = ".removeEachRole.";
        List<Object> objectList = new ArrayList<Object>();
        String stAppInfo = null;
        HashMap hmResult = null;
        int serviceID;
        int sorId = 0;
        int roleId = -1;

        logger.info("{}{}DBTOOLS000  removeEachRole: InpParam : {}", CLASS_NAME, sMethodName, StructuredArguments.entries(hmInput));
        String sDeleteRoleSql = "DELETE FROM MEMBERSERVICEROLE where member_num = ? and service_id = ?";

        String sEventData = "DELETE FROM MEMBERSERVICEROLE where ";

        try {
            String stLastModifiedBy = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);
            String stMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
            String stServiceId = (String) hmInput.get(MPSDefs.DB_SERVICE_ID);
            String stServiceName = (String) hmInput.get(MPSDefs.DB_SERVICE_NAME);
            String stSorId = (String) hmInput.get(MPSDefs.DB_SOR_ID);
            String stSorName = (String) hmInput.get(MPSDefs.DB_SOR_NAME);
            String stSorInvariantId = (String) hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
            String stRoleId = (String) hmInput.get(MPSDefs.DB_ROLE_ID);
            String stRoleName = (String) hmInput.get(MPSDefs.DB_ROLE_NAME);
            String stTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);

            if (stLastModifiedBy == null || stLastModifiedBy.trim().length() == 0 || stMemberNum == null
                    || stMemberNum.trim().length() == 0 || stTransactionId == null
                    || stTransactionId.trim().length() == 0) {
                stAppInfo = "CallingSystemID or MemberNum or TransactionId cannot be null";
                logger.info("{}{}DBHLPE4 : {}", CLASS_NAME, sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, stAppInfo);
                return hmResult;
            }

            if ((stServiceId == null || stServiceId.trim().length() == 0)
                    && (stServiceName == null || stServiceName.trim().length() == 0)) {
                stAppInfo = "Both ServiceId and ServiceName cannot be null";
                logger.info("{}{}DBHLPE5 : {}", CLASS_NAME, sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, stAppInfo);
                return hmResult;
            }
            if (stMemberNum != null && stMemberNum.trim().length() > 0) {
                sEventData = sEventData + "member_num=" + stMemberNum + " ";
            }

            if (stServiceId == null || stServiceId.trim().length() == 0) {
                serviceID = oDBHelper.getServiceId(stServiceName);
                sEventData = sEventData + "and service_id=" + serviceID + " ";
            } else {
                serviceID = Integer.parseInt(stServiceId);
                sEventData = sEventData + "and service_id=" + stServiceId + " ";
            }

            if (serviceID <= 0) {
                if (stServiceName != null) {
                    stAppInfo = "Service Name:: " + stServiceName + " is not valid";
                } else {
                    stAppInfo = "ServiceID:: " + stServiceId + " is not valid";
                }

                logger.info("{}{}DBHLPE5.1 : {}", CLASS_NAME, sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                return hmResult;
            }

            if ((stSorId == null || stSorId.trim().length() == 0)
                    && (stSorName != null && stSorName.trim().length() > 0)) {
                sorId = oDBHelper.getSorId(stSorName);
            } else {
                if (stSorId != null && stSorId.trim().length() > 0 && isIntNumber(stSorId)) {
                    sorId = Integer.parseInt(stSorId);
                }
            }

            if ((stSorId != null && stSorId.trim().length() > 0)
                    || (stSorName != null && stSorName.trim().length() > 0)) {
                if (sorId <= 0) {
                    if (stSorName != null) {
                        stAppInfo = "Sor Name:: " + stSorName + " is not valid";
                    } else {
                        stAppInfo = "Sor Id:: " + stSorId + " is not valid";
                    }
                    logger.info("{}{}DBHLPE5.2 : {}", CLASS_NAME, sMethodName, stAppInfo);
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                    return hmResult;
                }
            }

            if ((stRoleId == null || stRoleId.trim().length() == 0)
                    && (stRoleName != null && stRoleName.trim().length() > 0)
                    && (stServiceName != null && stServiceName.trim().length() > 0)) {
                stRoleId = oServiceRoleValidation.getServiceRoleId(stServiceName, stRoleName);
                if (stRoleId != null && stRoleId.trim().length() > 0)
                    roleId = Integer.parseInt(stRoleId);
            } else {
                if (stRoleId != null && stRoleId.trim().length() > 0) {
                    roleId = Integer.parseInt(stRoleId);
                }
            }

            long memberNum = Long.parseLong(stMemberNum);

            if ((stRoleId != null && stRoleId.trim().length() > 0)
                    || (stRoleName != null && stRoleName.trim().length() > 0)) {
                if (roleId > 0) {
                    sDeleteRoleSql += " and role_id = ?";
                    sEventData = sEventData + "and role_id=" + roleId + " ";
                } else {
                    if (stRoleName != null) {
                        if (stServiceName != null) {
                            stAppInfo = "Role Name:: " + stRoleName + " is not valid for service name:: "
                                    + stServiceName;
                        } else {
                            stAppInfo = "Role Name:: " + stRoleName + " is not valid for service ID:: " + stServiceId;
                        }

                    } else {
                        if (stServiceName != null) {
                            stAppInfo = "Role Id:: " + stRoleId + " is not valid for service name:: " + stServiceName;
                        } else {
                            stAppInfo = "Role Id:: " + stRoleId + " is not valid for service ID:: " + stServiceId;
                        }
                    }

                    logger.info("{}{}DBHLPE5.3 : {}", CLASS_NAME, sMethodName, stAppInfo);
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                    return hmResult;
                }
            }

            if (sorId > 0) {
                sDeleteRoleSql += " and sor_id = ?";
                sEventData = sEventData + "and sor_id=" + sorId + " ";
            }

            if (stSorInvariantId != null && !stSorInvariantId.trim().isEmpty()) {
                sDeleteRoleSql += " and sor_invariant_id = ?";
                sEventData = sEventData + "and sor_invariant_id=" + stSorInvariantId + " ";
            }
            if (sEventData.trim().length() > 1024) {
                sEventData = sEventData.substring(0, 1024);
            }
            logger.info("{}{}DBHLPE6 : DB Event = {}", CLASS_NAME, sMethodName, sEventData);
            logger.info("{}{}DBHLPE7.1 : Query = {}", CLASS_NAME, sMethodName, sDeleteRoleSql);

            objectList.add(memberNum);
            objectList.add(serviceID);
            if (roleId > 0) {
                objectList.add(roleId);
            }
            if (sorId > 0) {
                objectList.add(sorId);
            }
            if (stSorInvariantId != null && !stSorInvariantId.trim().isEmpty()) {
                objectList.add(stSorInvariantId);
            }

            int rowCount = jdbcTemplate.update(new String(sDeleteRoleSql),
                    objectList.toArray(new Object[objectList.size()]));

            if (rowCount == 0) {
                stAppInfo = "No Record found";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo);
                logger.info("{}{}MPSDBSU_10.1 : {}", CLASS_NAME, sMethodName, stAppInfo);

                if (stRoleName != null && stRoleName.trim().length() != 0) {
                    hmResult.put(MPSDefs.DB_ROLE_NAME, stRoleName);
                } else {
                    hmResult.put(MPSDefs.DB_ROLE_ID, stRoleId);
                }

                if (stServiceName != null && stServiceName.trim().length() != 0) {
                    hmResult.put(MPSDefs.DB_SERVICE_NAME, stServiceName);
                } else {
                    hmResult.put(MPSDefs.DB_SERVICE_ID, stServiceId);
                }

                return hmResult;
            }

            hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, "Deleted Role Successfully");
            logger.info("{}{}DBHLPE14 : Deleted Role Successfully", CLASS_NAME, sMethodName);
        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            hmResult = StatusMsg.makeExceptionSQLStatus(e);
            String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
            logger.error("{}{}DBHLPE33 : Error::{}", CLASS_NAME, sMethodName, e.getMessage());
            logger.error("{}{}DBHLPE33.1 : Exception = {}", CLASS_NAME, sMethodName, errorCode);
        } finally {
            logger.info("DBTOOLS999 : {} hmResult : {}", sMethodName, hmResult);
        }

        return hmResult;
    }

    public HashMap deleteRole(HashMap hmInput) {

        String sMethodName = ".deleteRole";
        HashMap hmResponse = null;
        List<Object> objectList = CommonUtil.getArrayList();
        ArrayList alDeleteRoleList = null;
        String stAppInfo = null;
        HashMap hmDeleteRole = null;
        Date dtStartDate = new Date();
        logger.info("{}{}DBTOOLS000 : InpParam : {}", CLASS_NAME, sMethodName, hmInput!=null? StringUtils.normalizeSpace(hmInput.toString()): null);

        if (hmInput == null || hmInput.isEmpty()) {
            stAppInfo = ProfileOrchestrationConstants.INPUT_HASH_IS_NULL;
            hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
            logger.info("{}{} LMH_LM.100.01 : {}", CLASS_NAME, sMethodName, stAppInfo);
            return hmResponse;
        }

        try {
            String sLastModifiedby = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

            if (sLastModifiedby == null || sLastModifiedby.trim().isEmpty()) {
                stAppInfo = "Input callingSystemId is null or empty";
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                logger.info("{}{}RDH.DR.01 : {}", CLASS_NAME, sMethodName, stAppInfo);
                return hmResponse;
            }
            alDeleteRoleList = (ArrayList) hmInput.get(MPSDefs.KEY_DELETE_ROLE);

            if (alDeleteRoleList == null || alDeleteRoleList.isEmpty()) {
                stAppInfo = "Input request to delete role status is empty";
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                logger.info("{}{}RDH.DR.02 : {}", CLASS_NAME, sMethodName, stAppInfo);
                return hmResponse;
            }
            int totalCount = 0;

            String sDeleteRoleInfoSQL =
                    "DELETE FROM MEMBERSERVICEROLE WHERE MEMBER_NUM=? " +
                            "AND ROLE_ID=? AND SERVICE_ID=? AND SOR_INVARIANT_ID=?";

            for (int i = 0; i < alDeleteRoleList.size(); i++) {
                String sDeleteSQL = sDeleteRoleInfoSQL;

                hmDeleteRole = (HashMap) alDeleteRoleList.get(i);

                String sSorInvariantId = (String) hmDeleteRole.get(MPSDefs.DB_SOR_INVARIANT_ID);
                String sMemberNum = (String) hmDeleteRole.get(MPSDefs.DB_MEMBER_NUM);
                String sRoleStatus = (String) hmDeleteRole.get(MPSDefs.DB_ROLE_STATUS);
                String sServiceName = (String) hmDeleteRole.get(MPSDefs.DB_SERVICE_NAME);
                String sRoleName = (String) hmDeleteRole.get(MPSDefs.DB_ROLE_NAME);
                String sRoleId = (String) hmDeleteRole.get(MPSDefs.DB_ROLE_ID);
                String sServiceId = (String) hmDeleteRole.get(MPSDefs.DB_SERVICE_ID);
                String sSorId = (String) hmDeleteRole.get(MPSDefs.DB_SOR_ID);
                String sSorName = (String) hmDeleteRole.get(MPSDefs.DB_SOR_NAME);

                if (sSorInvariantId == null || sSorInvariantId.trim().length() == 0
                        || sMemberNum == null || sMemberNum.trim().length() == 0
                        || sRoleStatus == null || sRoleStatus.trim().length() == 0) {

                    stAppInfo = "Input sor_invariant_id or member_num or role_status or service_name is null or empty";
                    hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                    logger.info("{}{}RDH.DR.03 : {}", CLASS_NAME, sMethodName, stAppInfo);
                    return hmResponse;
                }
                if ((sRoleName == null || sRoleName.trim().length() == 0)
                        && (sRoleId == null || sRoleId.trim().length() == 0)) {

                    stAppInfo = "Input role_name OR role_id is required";
                    hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                    logger.info("{}{}RDH.DR.04 : {}", CLASS_NAME, sMethodName, stAppInfo);
                    return hmResponse;
                }

                if ((sServiceName == null || sServiceName.trim().length() == 0)
                        && (sServiceId == null || sServiceId.trim().length() == 0)) {

                    stAppInfo = "Input service_name OR service_id is required";
                    hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                    logger.info("{}{}RDH.DR.05 : {}", CLASS_NAME, sMethodName, stAppInfo);
                    return hmResponse;
                }
                int iSorId = 0;
                int iServiceId = 0;
                int iRoleId = 0;
                int iMemberNum = 0;

                if (sSorId != null && sSorId.trim().length() > 0) {
                    iSorId = Integer.parseInt(sSorId);
                } else if (sSorName != null && sSorName.trim().length() > 0) {
                    iSorId = oDBHelper.getSorId(sSorName);
                }

                if (iSorId > 0) {
                    sDeleteSQL = sDeleteSQL + " AND SOR_ID=?";
                }

                if (sServiceId != null && sServiceId.trim().length() > 0) {
                    iServiceId = Integer.parseInt(sServiceId);
                } else {
                    iServiceId = oDBHelper.getServiceId(sServiceName);
                }

                if (sRoleId != null && sRoleId.trim().length() > 0) {
                    iRoleId = Integer.parseInt(sRoleId);
                } else {
                    iRoleId = oDBHelper.getRoleId(sRoleName, iServiceId);
                }
                if (sMemberNum != null && sMemberNum.trim().length() > 0) {
                    iMemberNum = Integer.parseInt(sMemberNum);
                }
                //get status_code corresponding to status_name
                int status_code = oDBHelper.getStatusCode(sRoleStatus);

                long pTime = 0;
                Date tQueryTime = new Date();

                objectList.add(sLastModifiedby);
                objectList.add(status_code);
                objectList.add(iMemberNum);
                objectList.add(iRoleId);
                objectList.add(iServiceId);
                objectList.add(sSorInvariantId);
                if (iSorId > 0)
                    objectList.add(iSorId);
                logger.info("RDH.DR.06 : UpdateRoleIDSQL: {}", sDeleteSQL);

                //prepStmtForDeleteRole.addBatch();
                int iRoleCount = jdbcTemplate.update(new String(sDeleteSQL), objectList.toArray
                        (new Object[objectList.size()]));
                pTime = (System.currentTimeMillis() - tQueryTime.getTime());
                logger.info("RDH.DR.07 : Total time taken to execute delete role = {} milliseconds", pTime);
                logger.info("RDH.DR.08 : No of rows deleted in MEMBERSERVICEROLE:= {}", iRoleCount);
                hmResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                        "Successfully deleted Role from MEMBERSERVICEROLE Table");


                if (iRoleCount == 0) {
                    stAppInfo = "No Records deleted";
                    hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo);
                    logger.info("{}{}RDH.DR.09 : {}", CLASS_NAME, sMethodName, stAppInfo);

                } else {
                    stAppInfo = "Role Status deleted successfully";
                    hmResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, stAppInfo);
                    logger.info("{}{}RDH.DR.10 : {}", CLASS_NAME, sMethodName, stAppInfo);
                }
            }

            hmResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                    "Successfully deleted Roles from MEMBERSERVICEROLE Table");
            return hmResponse;

        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            if (null != e.getMessage()) {
                hmResponse = StatusMsg.makeExceptionSQLStatus(e);
                logger.error("RDH.DR.11 : Error::{}", e.getMessage());
            }

        } finally {
            logger.info(" RDH.DR.12 DBTOOLS999 : {} hmResponse : {}", dtStartDate.getTime(), hmResponse);
        }
        return hmResponse;
    }

    public HashMap addRoles(HashMap hmInput) {
        String sMethodName = ".addRoles";

        HashMap hmResult = null;
        String sAppStatusCode = null;
        String sAppInfo = null;
        ArrayList alRolesList = null;

        Date dtStartDate = new Date();

        logger.info("{}{}DBTOOLS000 : InpParam : {}", CLASS_NAME, sMethodName, hmInput!=null? StringUtils.normalizeSpace(hmInput.toString()): null);
        try {
            String sMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
            String sServiceId = (String) hmInput.get(MPSDefs.DB_SERVICE_ID);
            String sServiceName = (String) hmInput.get(MPSDefs.DB_SERVICE_NAME);
            String sSorId = (String) hmInput.get(MPSDefs.DB_SOR_ID);
            String sSorName = (String) hmInput.get(MPSDefs.DB_SOR_NAME);
            String sSorInvariantId = (String) hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
            String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
            String sTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);
            alRolesList = (ArrayList) hmInput.get(CommonDefs.ROLES);

            boolean bIsMissingFields = false;

            //Making sor_invariant_id as optional attribute - Request from Ganesh/Vikas Saini - 9/20/2010
            if (sMemberNum == null || sMemberNum.trim().length() <= 0 ||
                    //sSorInvariantId == null || sSorInvariantId.trim().length() <= 0 ||
                    sCallingSystemId == null || sCallingSystemId.trim().length() <= 0 ||
                    sTransactionId == null || sTransactionId.trim().length() <= 0 ||
                    alRolesList == null || alRolesList.size() == 0) {
                sAppInfo = "Input member_num, serviceId, sor_id, sor_invarinat_id, callingSystemId or roles is null or empty";
                bIsMissingFields = true;
                hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM, sAppInfo);
                logger.info("{}{}RDH.ARLS.01 : {}", CLASS_NAME, sMethodName, sAppInfo);
                return hmResult;
            }

            //Making sor_id as optional attribute - Request from Ganesh/Vikas Saini - 9/20/2010
			/*
			if ((sSorId == null || sSorId.trim().length() <=0 ) &&
					(sSorName == null || sSorName.trim().length() <=0) )
			{
				sAppInfo = "Input sor_id and sor_name both are null or empty";
				bIsMissingFields = true;
			}
			*/

            if ((sServiceId == null || sServiceId.trim().length() <= 0) &&
                    (sServiceName == null || sServiceName.trim().length() <= 0)) {
                sAppInfo = "Input service_id and service_name both are null or empty";
                bIsMissingFields = true;
            }

            if (bIsMissingFields) {
                hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM, sAppInfo);
                logger.info("RDH.ARLS.02 : No of rows inserted in TMEMBERSERVICEROLE:= {}", bIsMissingFields);
                return hmResult;
            }

            HashMap hmNewInput = new HashMap(hmInput);
            hmNewInput.remove(CommonDefs.ROLES);

            HashMap hmRoleInfo = null;

            for (int i = 0; i < alRolesList.size(); i++) {
                hmRoleInfo = (HashMap) alRolesList.get(i);

                hmNewInput.put(MPSDefs.DB_ROLE_ID, (String) hmRoleInfo.get(MPSDefs.DB_ROLE_ID));
                hmNewInput.put(MPSDefs.DB_ROLE_STATUS, (String) hmRoleInfo.get(MPSDefs.DB_ROLE_STATUS));

                logger.info("RDH.ARLS.03 : No of rows inserted in TMEMBERSERVICEROLE:= {}", bIsMissingFields);

                //call DB helper to add role one at a time
                hmResult = addEachRole(hmNewInput);

                sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

                if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
                    logger.info("RDH.ARLS.04 : No of rows inserted in TMEMBERSERVICEROLE:= {}", sAppStatusCode);


                    return hmResult;
                }
            }

        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            sAppInfo = "Exception thrown in checkAccountFraudLock() method::" + e.getMessage();
            hmResult = CommonErrorMap.makeExceptionMap(e, logger);
            logger.error("{}{}RDH.ARLS.05 : {}", CLASS_NAME, sMethodName, sAppInfo);

            return hmResult;

        } finally {
            logger.info(" RDH.ARLS.06 DBTOOLS999 : {} hmResult : {}", dtStartDate.getTime(), hmResult);
        }

        return hmResult;
    }
    public HashMap updateSorInvIdForRole(HashMap hmDbInput) {
        String sMethodName = ".updateSorInvIdForRole.";
        HashMap hmResult = null;
        List<Object> objectList = CommonUtil.getArrayList();
        ArrayList alUpdateRoleSorInvariantIdList = null;
        HashMap hmResponse;
        HashMap hmUpdateRole = null;
        String sEventData = "";
        String stAppInfo;

        if (hmDbInput == null || hmDbInput.isEmpty()) {
            stAppInfo = "input to updateSorInvIdForRole() is null";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
            logger.info("{}{}MPSDBSU_08 : Output from updateSorInvIdForRole = :  {} ", CLASS_NAME, sMethodName, stAppInfo);
            return hmResult;
        }
        Date dtStartDate = new Date();
        logger.info("{}{}DBTOOLS000 : updateSorInvIdForRole hmDbInput : {}", CLASS_NAME, sMethodName, StructuredArguments.entries(hmDbInput));
        String updateSorInvIdForRoleSQL =
                "UPDATE MEMBERSERVICEROLE SET SOR_INVARIANT_ID=?, LAST_MODIFIED_BY=? WHERE MEMBER_NUM=?" +
                        " AND SOR_ID=? AND SERVICE_ID=? AND SOR_INVARIANT_ID=?";

        try {
            String sLastModifiedby = (String) hmDbInput.get(CommonDefs.CALLING_SYSTEM_ID);

            if (sLastModifiedby == null || sLastModifiedby.trim().isEmpty()) {
                stAppInfo = "Input callingSystemId is null or empty";
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                logger.info("{}{}URI001 : {}", CLASS_NAME, sMethodName, stAppInfo);
                return hmResponse;
            }
            alUpdateRoleSorInvariantIdList = (ArrayList) hmDbInput.get(CommonDefs.KEY_UPDATE_SOR_INVARIANT_ID_FOR_ROLE);

            if (alUpdateRoleSorInvariantIdList == null || alUpdateRoleSorInvariantIdList.isEmpty()) {
                stAppInfo = "Input request to update role status is empty";
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                logger.info("{}{}URI002 : {}", CLASS_NAME, sMethodName, stAppInfo);
                return hmResponse;
            }

            for (Object o : alUpdateRoleSorInvariantIdList) {
                HashMap hmUpdateRoleSorInvariantIdList = (HashMap) o;

                int iSorId = 0;
                int iServiceId = 0;
                String stMemberNum = (String) hmUpdateRoleSorInvariantIdList.get(MPSDefs.DB_MEMBER_NUM);
                String stSorId = (String) hmUpdateRoleSorInvariantIdList.get(MPSDefs.DB_SOR_ID);
                String stSorName = (String) hmUpdateRoleSorInvariantIdList.get(MPSDefs.DB_SOR_NAME);
                String stSorInvariantId = (String) hmUpdateRoleSorInvariantIdList.get(MPSDefs.DB_SOR_INVARIANT_ID);
                String stServiceId = (String) hmUpdateRoleSorInvariantIdList.get(MPSDefs.DB_SERVICE_ID);
                String stServiceName = (String) hmUpdateRoleSorInvariantIdList.get(MPSDefs.DB_SERVICE_NAME);
                String stOldSorInvId = (String) hmUpdateRoleSorInvariantIdList.get("old_sor_invariant_id"); //1512 - Updated for DF#62768

                if (stMemberNum==null ||stMemberNum.trim().isEmpty()||stSorId==null ||stSorId.trim().isEmpty()||stSorName==null
                        ||stSorName.trim().isEmpty()||stSorInvariantId==null ||stSorInvariantId.trim().isEmpty()
                        ||stServiceId==null ||stServiceId.trim().isEmpty()||stServiceName==null ||stServiceName.trim().isEmpty()
                        ||stOldSorInvId == null || stOldSorInvId.trim().isEmpty()){
                    stAppInfo = "Member Number, Sor Id, Sor Name, Sor Invariant Id, Service Id, Service Name " +
                            "or stOldSorInvId is missing";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                    logger.info("{}{}QIPRL.DBH_03: {}", CLASS_NAME, sMethodName, stAppInfo);
                    return hmResult;
                }

                if ((stSorId == null || stSorId.trim().length() == 0) && (stSorName != null && stSorName.trim().length() > 0)) {
                    stSorId = oSystemOfRecordValidation.getSystemOfRecordIdByName(stSorName);
                    iSorId = Integer.parseInt(stSorId);

                } else if (stSorId != null && stSorId.trim().length() > 0) {
                    iSorId = Integer.parseInt(stSorId);
                }
                logger.debug("{}{}DBTOOLS05 : Got sor_id from cache= {}", CLASS_NAME, sMethodName, iSorId);

                if ((stServiceId == null || stServiceId.trim().length() == 0) &&
                        (stServiceName != null && !stServiceName.trim().isEmpty()) )
                {
                    iServiceId = oDBHelper.getServiceId(stServiceName);
                }
                else if (stServiceId != null && stServiceId.trim().length() > 0 ) {
                    iServiceId = Integer.parseInt(stServiceId);
                }

                logger.debug("{}{}DBHLP83 : updateSorInvIdForRole iServiceId={}", CLASS_NAME, sMethodName, iServiceId);

                long pTime = 0;
                Date tQueryTime = new Date();

                objectList.add(stSorInvariantId);
                objectList.add(sLastModifiedby);
                objectList.add(stMemberNum);
                objectList.add(iSorId);
                objectList.add(iServiceId);
                objectList.add(stOldSorInvId);

                logger.debug("{}{}URI006 : SQL = {}", CLASS_NAME, sMethodName, updateSorInvIdForRoleSQL);
                int rowCount = jdbcTemplate.update(new String(updateSorInvIdForRoleSQL), objectList.toArray
                        (new Object[objectList.size()]));

                pTime = (System.currentTimeMillis() - tQueryTime.getTime());

                logger.info("URI007 : updateSorInvIdForRoleSQL Total time taken to execute update role = {} milliseconds", pTime);
                logger.info("URI008 : updateSorInvIdForRoleSQL No of rows updated in MEMBERSERVICEROLE:= {}", rowCount);

                if (rowCount == 0) {
                    stAppInfo = "No Record found";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo);
                    logger.info("{}{}MPSDBSU_10 : {}", CLASS_NAME, sMethodName, stAppInfo);
                } else {
                    stAppInfo = "Successfully Updated SorInvId in the MEMBERSERVICEROLE Table ";
                    hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, stAppInfo);
                    logger.info("{}{}MPSDBSU_11 : {}", CLASS_NAME, sMethodName, stAppInfo);
                }
            }
        } catch (Exception e) {
                errorMetricHandler.recordDbErrorMetric();
                hmResult = StatusMsg.makeExceptionSQLStatus(e);
                String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
                logger.error("{}{}DMDH.DGS.07 : Error:: {}", CLASS_NAME, sMethodName, e.getMessage());
                logger.error("{}{}DMDH.DGS.08 : Exception = {}", CLASS_NAME, sMethodName, errorCode);
                return hmResult;
            } finally {
                logger.info("{}{}DBTOOLS999 : Output from updateSorInvIdForRoleSQL = :  {} ", CLASS_NAME, sMethodName, hmResult);
            }
            return hmResult;
        }
    
    /**
	 * 
	 * @param hmInput
	 * @return HashMap
	 */
	public HashMap removeRoles(HashMap hmInput) {
		String thisMethod = "removeRoles";
		String stAppStatusCode = null;
		String stAppInfo = null;
		
		logger.info("{}{}AUH_117.1 : {}{}",  CLASS_NAME, thisMethod, "DBHLP1"+"CVS KEYWORDS:" );	
				
		logger.info("{}{}AUH_117.1 : {}{}", CLASS_NAME,thisMethod,"DBHLP2","in removeRoles ");
		logger.info("{}{}AUH_117.1 : {}{}", CLASS_NAME,thisMethod,"DBHLP000"," removeRoles inputHash is ::"+hmInput);	
		
		//PreparedStatement prepStmt = null;
		HashMap hmResult = null;
		String stRoleKey = null;
		
		ArrayList alRoleID = new ArrayList ();
		ArrayList alRoleNames = new ArrayList ();
		ArrayList alRemoveRoles = new ArrayList ();
		
		if (jdbcTemplate==null){
			stAppInfo = "Connection is null";
			logger.info("{}{}AUH_117.1 : {}{}", CErrorDefs.ERR_DB_NUM, CLASS_NAME,
					thisMethod, "DBHLP4", stAppInfo);
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_DB_NUM, stAppInfo);
			return hmResult;		
		}
		
		alRoleID = (ArrayList)hmInput.get(CommonDefs.REMOVE_ROLE_IDS_KEY);
		alRoleNames = (ArrayList)hmInput.get(CommonDefs.REMOVE_ROLE_NAMES_KEY);
		
		if (alRoleID!=null && !alRoleID.isEmpty())
			stRoleKey=MPSDefs.DB_ROLE_ID;
		else if (alRoleNames!=null && !alRoleNames.isEmpty())
			stRoleKey=MPSDefs.DB_ROLE_NAME;
		
		if (stRoleKey == null || stRoleKey.trim().length() == 0){
						
			logger.info("{}{}AUH_117.1 : {}{}", 0, CLASS_NAME, thisMethod, "DBHLP5",
					"Calling removeEachRole :: " + hmInput); 
			
			hmResult=removeEachRole(hmInput);
			
			logger.info("{}{}AUH_117.1 : {}{}", 0, CLASS_NAME, thisMethod, "DBHLP6",
					"After Calling removeEachRole :: " + hmResult); 
			
			stAppStatusCode = (String) hmResult.get
								(CommonDefs.COMMON_APP_STATUS_CODE);

			if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {		
				
				String stDBServiceName = (String) hmResult.get(MPSDefs.DB_SERVICE_NAME);	
				String stDBServiceId = (String) hmResult.get(MPSDefs.DB_SERVICE_ID);
				String stDBRoleName = (String) hmResult.get(MPSDefs.DB_ROLE_NAME);
				String stDBRoleId = (String) hmResult.get(MPSDefs.DB_ROLE_ID);
				
				if ( stDBServiceName != null || stDBServiceId != null || stDBRoleName != null || stDBRoleId != null){
						
					stAppInfo = "No Roles in DB to delete.Returning Success";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);		
					
					logger.info("{}{}AUH_117.1 : {}{}", 0,
							CLASS_NAME, thisMethod, "DBHLP7",
							stAppInfo);
				}else {
					stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);		
					hmResult = CommonErrorMap.makeCategoryMap(Integer
							.parseInt(stAppStatusCode), stAppInfo);		
					logger.info("{}{}AUH_117.1 : {}{}", Integer.parseInt(stAppStatusCode),
							CLASS_NAME, thisMethod, "DBHLP7",
							"Error returned from removeEachRole ");
					return hmResult;
				}
				
			} 			
		}else {
			if (stRoleKey!=null && stRoleKey.equals(MPSDefs.DB_ROLE_ID)){
				alRemoveRoles = (ArrayList) hmInput.remove(CommonDefs.REMOVE_ROLE_IDS_KEY);
			}else{
				alRemoveRoles = (ArrayList) hmInput.remove(CommonDefs.REMOVE_ROLE_NAMES_KEY);				
			}
			if (alRemoveRoles!=null && !alRemoveRoles.isEmpty()){
				
				boolean isAppInfoChanged = false;
				
				for (int i=0; i<alRemoveRoles.size(); i++){
					String stRole = (String) alRemoveRoles.get(i);
					if (stRole!=null && stRoleKey.equals(MPSDefs.DB_ROLE_ID))
						hmInput.put(MPSDefs.DB_ROLE_ID,stRole);
					else
						hmInput.put(MPSDefs.DB_ROLE_NAME,stRole);
					
					logger.info("{}{}AUH_117.1 : {}{}", 0, CLASS_NAME, thisMethod, "DBHLP8",
							"Calling removeEachRole :: " + hmInput); 
					
					hmResult = removeEachRole(hmInput);		
					
					logger.info("{}{}AUH_117.1 : {}{}", 0, CLASS_NAME, thisMethod, "DBHLP9",
							"After Calling removeEachRole :: " + hmResult); 
					
					stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

					if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {		
						String stDBServiceName = (String) hmResult.get(MPSDefs.DB_SERVICE_NAME);	
						String stDBServiceId = (String) hmResult.get(MPSDefs.DB_SERVICE_ID);
						String stDBRoleName = (String) hmResult.get(MPSDefs.DB_ROLE_NAME);
						String stDBRoleId = (String) hmResult.get(MPSDefs.DB_ROLE_ID);
						
						if ( stDBServiceName != null || stDBServiceId != null || stDBRoleName != null || stDBRoleId != null){
							if(!isAppInfoChanged){
								stAppInfo = "Could not delete Roles ";
							}else {
								stAppInfo = stAppInfo + " , " ;
							}
							
							if(stDBRoleName != null){
								stAppInfo = stAppInfo + "RoleName:: " + stDBRoleName; 
							}else {
								stAppInfo = stAppInfo + "RoleId:: " + stDBRoleId;
							}
							
							if(stDBServiceName != null){
								stAppInfo = stAppInfo + " For ServiceName:: " + stDBServiceName;
							}else {
								stAppInfo = stAppInfo + " For ServiceId:: " + stDBServiceId;
							}
							
							isAppInfoChanged = true;
																				
						} else {
							stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);		
							hmResult = CommonErrorMap.makeCategoryMap(Integer
									.parseInt(stAppStatusCode), stAppInfo);		
							logger.info("{}{}AUH_117.1 : {}{}", Integer.parseInt(stAppStatusCode),
									CLASS_NAME, thisMethod, "DBHLP10",
									"Error returned from removeEachRole ");
							return hmResult;
						}
						
					}				
				}
				
				if(isAppInfoChanged){
					stAppInfo = stAppInfo + " as no matching Role exists for the given Service/Account Data.";
					if(stAppInfo.trim().length() > 256){
						stAppInfo = stAppInfo.substring(0,256);
					}
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
					logger.info("{}{}AUH_117.1 : {}{}", 0,
							CLASS_NAME, thisMethod, "DBHLP10",
							stAppInfo);
				}
			}
		}	
		
		stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
		
		if(stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)){
			stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);	
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
		}
		
		return hmResult;
	}

    /**
     * This method checks if the input string can be parsed into an integer.
     * It takes a string as input and tries to parse it into an integer.
     * If the parsing is successful, it returns true indicating that the string is a valid integer.
     * If the parsing fails due to a NumberFormatException, it returns false indicating that the string is not a valid integer.
     *
     * @param num The string to be checked if it can be parsed into an integer.
     * @return A boolean indicating whether the string can be parsed into an integer or not.
     */
    public boolean isIntNumber(String num) {
        try {
            Integer.parseInt(num);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }
}
