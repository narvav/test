package com.att.idp.idgraphusermanagementms.service;

import com.att.idp.idgraphusermanagementms.resource.request.LinkMemberRequest;
import com.att.idp.idgraphusermanagementms.resource.response.LinkMemberResponse;

import jakarta.ws.rs.core.MultivaluedMap;

public interface LinkMemberService {

	LinkMemberResponse linkMember(LinkMemberRequest linkMemberRequest, MultivaluedMap<String, String> requestHeader);

}
