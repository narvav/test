package com.att.idp.idgraphusermanagementms.db.model;

import jakarta.persistence.*;
import java.util.Date;

@MappedSuperclass
public class AuditablePendingAction {

     @Column(name = "PENDING_ACTION_DATE", length = 7)
    private Date pendingActionDate;

    @Column(name = "NUM_RETRIES", nullable = false, precision = 22, scale = 0)
    private Long numRetries;

    @Column(name = "CREATE_DATE", nullable = false, length = 7)
    private Date createDate;

    @Column(name = "LAST_MODIFIED", length = 7)
    private Date lastModified;

    @Column(name = "LAST_MODIFIED_BY", nullable = false)
    private String lastModifiedBy;
}

