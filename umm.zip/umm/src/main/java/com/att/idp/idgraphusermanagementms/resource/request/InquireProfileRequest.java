package com.att.idp.idgraphusermanagementms.resource.request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.att.mpsys.common.utils.CommonDefs;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class represents a request to inquire a user's profile in the system.
 * It contains fields for various details such as transactionName, callingSystemId, handle, domain, guid, level, returnUserFraudLock, returnUserSecurityInfo, returnUserFraudPassword, returnUserLockout, isExternalCall, QUERY_USER_MERGE, and idpTraceId.
 * Each field has specific constraints such as not null and size limits.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 *
 */
@Data
@Schema(name = "inquireProfileRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
public class InquireProfileRequest {

	protected final String transactionName = CommonDefs.INQUIRE_PROFILE;

	protected String callingSystemId;

	@Schema(name = "userId")
	@Size(min=1, max=127,message="userId length is invalid|InquireProfile")
	@JsonProperty("userId")
	protected String handle;

	@Schema(name = "domain")
	@Size(min=1,max=30,message="domain value cannot be empty|InquireProfile")
	protected String domain;

	@Schema(name = "guid")
	@Size(min=1,max=30,message="guid length is invalid|InquireProfile")
	protected String guid;

	@Schema(name = "level")
	@NotNull(message="level is required field in input request.|InquireProfile")
	@Size(min=1,max=256,message="level value can only be M or MSR or LM|InquireProfile")
	protected String level;

	@Schema(name = "returnUserFraudLock")
	@Size(min=1,max=1,message="returnUserFraudLock value can only be Y or N|InquireProfile")
	protected String returnUserFraudLock;

	@Schema(name = "returnUserSecurityInfo")
	@Size(min=1,max=1,message="returnUserSecurityInfo value can only be Y or N|InquireProfile")
	protected String returnUserSecurityInfo;

	@Schema(name = "returnUserFraudPassword")
	@Size(min=1,max=1,message="returnUserFraudPassword value can only be Y or N|InquireProfile")
	protected String returnUserFraudPassword;

	@Schema(name = "returnUserLockout")
	@Size(min=1,max=1,message="returnUserLockout value can only be Y or N|InquireProfile")
	protected String returnUserLockout;

	@Schema(name = "isExternalCall")
	protected String isExternalCall;

	@Schema(name = "QUERY_USER_MERGE")
	protected String QUERY_USER_MERGE;

	@Schema(name = "idpTraceId")
	private String idpTraceId;
}