package com.att.idp.idgraphusermanagementms.helper;

import com.att.idp.idgraphusermanagementms.db.helper.GetMemberServicesDBHelper;
import com.att.idp.idgraphusermanagementms.helper.resetuserpassword.LockoutHelper;
import com.att.idp.idgraphusermanagementms.helper.resetuserpassword.UserPasswordHelper;
import com.att.idp.idgraphusermanagementms.queue.message.helpers.PasswordQueueHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.idgraphusermanagementms.utils.RILCheckAndEncryptPasswordHelper;
import com.att.mpsys.common.helpers.ConvertServicesHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.RILDefs;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class UpdateUserPasswordHelper {

    public static final Logger logger = LoggerFactory.getLogger(UpdateUserPasswordHelper.class);
    private static final String AGENT_LIST = "AGENT_LIST";
    private static final String ONLINE_SECURITY_ANSWERS_UPDATED = "securityAnswerChanged";
    private static final String sClassName = "UpdateUserPasswordHelper";

    @Value("${CUP_Password_Dirty_CSI}")
    private String propPasswordDirtyCSI;
    @Value("${ChangePassword_Service_To_NotificationField}")
    private String stSrvNotificationField;

    @Value("${agentToolList}")
    private String stAgentList;

    @Value("${ChangeMemberPasswordCSIServices}")
    private String stChangeMemberPasswordCSIServices;

    @Autowired
    private GetMemberServicesDBHelper getMemberServicesDBHelperObj;

    @Autowired
    private ConvertServicesHelper oConvertServicesHelper;

    @Autowired
    private LockoutHelper oLockoutHelper;

    @Autowired
    private RILCheckAndEncryptPasswordHelper oRILCheckAndEncryptPasswordHelper;

    @Autowired
    private UserPasswordHelper oUserPasswordHelper;

    @Autowired
    private PasswordQueueHelper passwordQueueHelper;

    private boolean isTransactionRollbackOnError = false;
    //Below Value is set Null for Now since Generic password is disabled
    private String sGen_password_type = null;

    /**
     * Changes the user's password based on the provided input parameters.
     *
     * @param hmInput A map containing the input parameters for changing the user's password.
     * @return A map containing the result of the password change operation.
     */
    public Map<String, Object> changeUserPassword(Map hmInput) {
        String sMethodName = ".changeUserPassword.";
        boolean isTransactionRollbackOnError = false;
        logger.info(sClassName + sMethodName + "HLP000 : Input Hash : " + hmInput);
        boolean isParent = false;
        Map hmResult = null;
        String stAppInfo = null;
        String stAppStatusCode = null;

        ArrayList<String> alPwdDirtyCSI = null;
        String sLegacyDTVId = (String) hmInput.get(CommonDefs.LEGACY_DTV_ID);

        HashMap hmPwdHelperInput = new HashMap();

        try {
            String idpTraceid = (String) hmInput.get("idpTraceId");
            if (idpTraceid != null && idpTraceid.contains(":")) {
                hmInput.put("dbusTransactionId", idpTraceid.split(":")[0]);
            }
            //check dirtypassword
            checkDirtyPassword(hmInput, alPwdDirtyCSI);
            hmInput.put( CommonDefs.TRANSACTION_ID,hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));

            hmPwdHelperInput.putAll(hmInput);
            hmPwdHelperInput.put(CommonDefs.TRANSACTION_NAME, "ChangeMemberPassword");

            //GetMemberServices
            HashMap hmDBMemberInfo = getMemberServiceDetails(hmPwdHelperInput, hmInput);

            stAppStatusCode = (String) hmDBMemberInfo.get(CErrorDefs.COMMON_APP_STATUS_CODE);
            if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                if (stAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
                    stAppInfo = "User Not Found in DB";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
                    logger.info("{}{}UUP_101 : {}", sClassName, sMethodName, stAppInfo);
                } else {
                    hmResult = hmDBMemberInfo;
                }

                return hmResult;
            }

            //taking parent details from above member service and call getmemberservice
            String sDBParentChildInd = (String) hmDBMemberInfo.get(MPSDefs.DB_PARENT_CHILD_IND);
            String sDBParentHandle = (String) hmDBMemberInfo.get(MPSDefs.DB_PARENT_NAME);
            String sDBParentDomain = (String) hmDBMemberInfo.get(MPSDefs.DB_PARENT_DOMAIN);

            HashMap hmDBParentInfo = null;
            hmDBParentInfo = getParentServiceDetails(sDBParentChildInd, sDBParentHandle, sDBParentDomain, sMethodName);
            if (hmDBParentInfo != null) {
                stAppStatusCode = (String) hmDBParentInfo.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                    if (stAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
                        stAppInfo = "User Not Found in DB";
                        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
                        logger.info("{}{}UUP_102 : {}", sClassName, sMethodName, stAppInfo);
                    } else {
                        hmResult = hmDBParentInfo;
                    }
                    return hmResult;
                }
            }

            hmPwdHelperInput.put(MPSDefs.DB_LOCKOUT_NAME, CommonDefs.CHANGE_PASSWORD);

            String sDBSorName = (String) hmDBMemberInfo.get(MPSDefs.DB_SOR_NAME);

            if (sDBSorName != null && sDBSorName.trim().length() != 0) {
                hmPwdHelperInput.put(CommonDefs.SOR_NAME, sDBSorName);
            }

            String sDBMigrationInd = null;

            if (sDBParentChildInd.equals(MPSDefs.MPS_CHILD)) {
                logger.info("{}{}UUP_103 : Setting child migration indicator to parents migration indicator", sClassName, sMethodName);
                sDBMigrationInd = (String) hmDBParentInfo.get(MPSDefs.DB_MIGRATION_IND);
            } else {
                isParent = true;
                sDBMigrationInd = (String) hmDBMemberInfo.get(MPSDefs.DB_MIGRATION_IND);
            }

            hmPwdHelperInput.put(CommonDefs.MIGRATION_IND, sDBMigrationInd);
            hmPwdHelperInput.put(CommonDefs.PARENT_CHILD_IND, sDBParentChildInd);

            // add ban to hash
            String sDBBan = (String) hmDBMemberInfo.get(CommonDefs.BAN);
            if (sDBBan != null) {
                hmPwdHelperInput.put(CommonDefs.BAN, sDBBan);
            }

            HashMap hmDBServices = (HashMap) hmDBMemberInfo.get(CommonDefs.SERVICES);

            // Retrieve main CTN (instance_id of service MOSUB) for Access ID linked to input member ID
            retrieveMainCTN(hmDBMemberInfo, hmPwdHelperInput, sMethodName, hmDBServices);

            ArrayList alServiceTypes = getServiceTypesList(hmDBServices, sMethodName, sDBSorName);
            ArrayList alServices;


            // --DEC2011: Return error if CSI=DLOSF and SLID doesn't have DLIFE or XANBOO.

            HashMap hmResponse = buildCSIServicesLists(stChangeMemberPasswordCSIServices);
            logger.info("{}{}UUP_104 : response from buildCSIServicesLists, hmResponse : {}", sClassName, sMethodName, hmResponse);

            ArrayList alInterestedCSIs = (ArrayList) hmResponse.get("alInterestedCSIs");
            ArrayList alInterestedCallingSystemServices = (ArrayList) hmResponse
                    .get("alInterestedCallingSystemServices");

            String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
            if (alInterestedCSIs != null && alInterestedCSIs.contains(sCallingSystemId)) {
                boolean isEligibleService = isEligibleServiceCheck(alInterestedCallingSystemServices, sCallingSystemId, alServiceTypes);
                if (!isEligibleService) {
                    stAppInfo = "User does not have the required service(s).";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, stAppInfo);
                    logger.info("{}{}UUP_105 : {}", sClassName, sMethodName, stAppInfo);
                    return hmResult;

                }
            }
            ArrayList<String> alAgentList = CommonUtil.parseToArray(stAgentList, CommonDefs.VALUE_SEPARATOR_CHAR);
            logger.info("{}{}UUP_106: KEY_AGENT_TOOL_LIST : {}", sClassName, sMethodName, alAgentList);

            if (alAgentList != null && !alAgentList.isEmpty())
                hmPwdHelperInput.put(AGENT_LIST, alAgentList);

            ArrayList alLockoutInfo = (ArrayList) hmDBMemberInfo.get(MPSDefs.DB_MEMBERLOCKOUT);
            if (alLockoutInfo != null && !alLockoutInfo.isEmpty()) {
                hmResult = handleLockoutInfo(alLockoutInfo, hmDBMemberInfo, hmPwdHelperInput, alAgentList, sCallingSystemId, sClassName, sMethodName);
                if (hmResult != null) {
                    return hmResult;
                }
            }
            // end of lockout check
            HashMap hmSlidInfoForFraudLocks = null;
            hmSlidInfoForFraudLocks = getSlidInfoForFraudLocks(hmInput, hmDBMemberInfo, hmPwdHelperInput, sMethodName);
            if (hmSlidInfoForFraudLocks != null) {
                String sAppStatusCode = (String) hmSlidInfoForFraudLocks.get(CommonDefs.COMMON_APP_STATUS_CODE);
                if (sAppStatusCode!=null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
                    stAppInfo = (String) hmSlidInfoForFraudLocks.get(CommonDefs.COMMON_APP_INFO);
                    logger.info("{}{}UUP_106.1a : {}", sClassName, sMethodName, stAppInfo);
                    return hmSlidInfoForFraudLocks;
                }
            }


            String sSlidMemberNum = (String) hmDBMemberInfo.get(MPSDefs.DB_SLID_MEMBER_NUM);
            // [END] Fraud Lock check
            //[R2112]PID-400970e :to reject transactions on FN accessIDs
            //change by vd105x
            if (hmSlidInfoForFraudLocks != null && !hmSlidInfoForFraudLocks.isEmpty()) {
                String sFnLinkedStatus = (String) hmSlidInfoForFraudLocks.get(CommonDefs.DB_FN_LINKED_STATUS);
                if (sFnLinkedStatus != null && sFnLinkedStatus.equalsIgnoreCase(CommonDefs.FN_STATUS_SELF)) {
                    stAppInfo = "FirstNet linked accessId";
                    logger.info("{}{}UUP_107 : {}", sClassName, sMethodName, stAppInfo);
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, stAppInfo);
                    return hmResult;
                }
            }
            //END

            if (!isParent) {
                if (!(hmDBMemberInfo.get(MPSDefs.DB_MEMBER_STATE).equals(MPSDefs.RESERVED_STATE)
                        || hmDBMemberInfo.get(MPSDefs.DB_MEMBER_STATE).equals(MPSDefs.INUSE_STATE))) {
                    stAppInfo = "Child member has no service and member_state is not RES or customer has services"
                            + " but no services are suspended and/or enabled";
                    logger.info("{}{}UUP_108: {}", sClassName, sMethodName, stAppInfo);
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, stAppInfo);
                    return hmResult;
                }
            }

            hmResult = doOldPwdCheck(hmPwdHelperInput, hmDBMemberInfo);


            if (hmResult != null && !hmResult.isEmpty()) {
                stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
                if (!stAppStatusCode.equalsIgnoreCase(CErrorDefs.COMMON_SUCCESS)) {
                    return hmResult;
                }
            }

            String sDBMemberNum = (String) hmDBMemberInfo.get(MPSDefs.DB_MEMBER_NUM);
            if (sDBMemberNum != null) {
                hmPwdHelperInput.put(CommonDefs.MEMBER_NUM, sDBMemberNum);
            }

            populatePwdHelperInput(hmDBMemberInfo, hmDBParentInfo, hmPwdHelperInput);

            boolean isSecurityQAUpdated = false;

            ArrayList alLinkedUsers = new ArrayList();

            HashMap hmSlidInfo = (HashMap) hmDBMemberInfo.get(MPSDefs.KEY_SLID_INFO);
            if (hmSlidInfo != null && !hmSlidInfo.isEmpty()) {
                if (hmSlidInfo.containsKey(MPSDefs.KEY_LINKED_USERS)) {
                    ArrayList alDBLinkedUsers = (ArrayList) hmSlidInfo.get(MPSDefs.KEY_LINKED_USERS);
                    alLinkedUsers.addAll(alDBLinkedUsers);
                    HashMap hmThisMemberDB = CommonUtil.getHashMap();
                    hmThisMemberDB.putAll(hmSlidInfo);
                    hmThisMemberDB.remove(MPSDefs.KEY_LINKED_USERS);
                    alLinkedUsers.add(hmThisMemberDB);

                    logger.info("{}{}UUP_109 : Linked users assigned, alLinkedUsers = {}", sClassName, sMethodName, alLinkedUsers);
                }
            }

            String sCPNILinkedToSLID = "N";

            if (alLinkedUsers != null && !alLinkedUsers.isEmpty()) {//Junit fix : Added not empty condition
                sCPNILinkedToSLID = oUserPasswordHelper.getCPNILinkedToSLID(alLinkedUsers);
            } else if (sSlidMemberNum != null && sSlidMemberNum.equals(sDBMemberNum)) {
                // naked SLID scenario - account is slid but no linked users
                ArrayList alSlidInfo = new ArrayList();
                alSlidInfo.add(hmDBMemberInfo);
                sCPNILinkedToSLID = oUserPasswordHelper.getCPNILinkedToSLID(alSlidInfo);
            }

            hmPwdHelperInput.put("isCPNILinkedToSLID", sCPNILinkedToSLID);

            if (isSecurityQAUpdated) {
                hmInput.put(ONLINE_SECURITY_ANSWERS_UPDATED, CommonDefs.DEFAULT_YES);
            }

            logger.debug("{}{}UUP_110 : Calling UserPasswordHelper.processChangePassword with Input Hash : {}", sClassName, sMethodName, hmPwdHelperInput);

            hmResult = oUserPasswordHelper.processChangePassword(hmPwdHelperInput, hmDBMemberInfo, hmDBParentInfo);

            logger.debug("{}{}UUP_111 : Response from UserPasswordHelper.processChangePassword : {}", sClassName, sMethodName, hmResult);

            stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
            if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {

                stAppInfo = "Error returned from UserPasswordHelper.processChangePassword";
                logger.info("{}{}UUP_112 : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            } else {
                isTransactionRollbackOnError = true;
            }


            ArrayList <Map<String, Object>> alDbusInput = new ArrayList<>();
            if (hmResult.containsKey(CommonDefs.CONSOLIDATED_DBUS_INPUT)) {
                alDbusInput.addAll((ArrayList) hmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT));
            }

            //Prepare EDD Notification
            prepareNotification(hmInput, hmDBMemberInfo, hmPwdHelperInput, alServiceTypes, alLinkedUsers, alDbusInput);


            //R2005
            //commented since we don't need to send the CheckDarkWeb Notification
            /*if (hmDBMemberInfo != null && hmDBMemberInfo.containsKey(MPSDefs.KEY_SLID_INFO)) {
                HashMap hmSlidInfoForHaloHTMS = (HashMap) hmDBMemberInfo.get(MPSDefs.KEY_SLID_INFO);

                if (hmSlidInfoForHaloHTMS != null && !hmSlidInfoForHaloHTMS.isEmpty()) {
                    hmResponse.clear();
                    hmResponse = passwordQueueHelper.buildDbusHaloHTMSHash(hmInput, hmSlidInfoForHaloHTMS, logger);

                    stAppStatusCode = (String) hmResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                    if (!stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
                        stAppInfo = "Error returned from method buildDbusHaloHTMSHash";
                        logger.info(sClassName + sMethodName + "BDHH-2c : " + stAppInfo);
                        return hmResponse;
                    }

                    if (hmResponse.get("HaloHTMSHASH") != null)
                        alDbusInput.add(hmResponse.get("HaloHTMSHASH"));
                }
            }*/

            if (!alDbusInput.isEmpty()) {
                logger.info("{}{}UUP_113 : Calling makeAsyncCall : ", sClassName, sMethodName);

                hmResult = passwordQueueHelper.sendMessageToMQ(hmInput, hmDBMemberInfo, alDbusInput, PasswordQueueHelper.UPDATE_EVENT_TYPE);

                logger.info("{}{}UUP_114 : Response from makeAsyncCall : {}", sClassName, sMethodName, hmResult);

                stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

                if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                    stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
                    logger.info("{}{}UUP_115 : {}", sClassName, sMethodName, stAppInfo);
                    hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                    return hmResult;
                } else {
                    isTransactionRollbackOnError = true;
                }
            }

            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
        } catch (SQLException e) {
            stAppInfo = "SQL exception occured: " + e.getMessage();
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_DB_NUM, stAppInfo);
            logger.info("{}{}UUP_120 : {}", sClassName, sMethodName, stAppInfo);
        } catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e, logger);
            stAppInfo = "Exception thrown while adding User in DB : " + hmResult;
            logger.info("{}{}UUP_121 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
        } finally {

            stAppInfo = "Response from UpdateUserPasswordHelper = " + hmResult;
            logger.info("{}{}UUP_122 : {}", StringUtils.normalizeSpace(sClassName), StringUtils.normalizeSpace(sMethodName), StringUtils.normalizeSpace(stAppInfo));

            if (hmResult == null || hmResult.isEmpty()) {
                stAppInfo = "Response from UpdateUserPasswordHelper is NULL";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                logger.info("{}{}UUP_123 : {}", sClassName, sMethodName, stAppInfo);
            }

            String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);

            if (isTransactionRollbackOnError && sAppCategoryCode != null && !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
                hmResult.put("isTransactionRollback", "Y");
            }

            logger.info("{}{}HLP999 : response from UpdateUserPasswordHelper {}", sClassName, sMethodName, hmResult);
        }
        return hmResult;


    }

    private static boolean isEligibleServiceCheck(ArrayList alInterestedCallingSystemServices, String sCallingSystemId, ArrayList alServiceTypes) {
        ArrayList alServices;
        boolean isEligibleService = false;

        for (Object oCSIsServices : alInterestedCallingSystemServices) {
            if (oCSIsServices instanceof HashMap) {
                HashMap<String, Object> hmEntry = (HashMap<String, Object>) oCSIsServices;
                if (hmEntry.containsValue(sCallingSystemId)) {
                    alServices = (ArrayList) hmEntry.get(CommonDefs.SERVICES);

                    for (Object oServices : alServices) {
                        String sThisService = (String) oServices;
                        if (alServiceTypes.contains(sThisService)) {
                            isEligibleService = true;
                            break;
                        }
                    }
                }
            }
        }
        return isEligibleService;
    }

    private ArrayList getServiceTypesList(HashMap hmDBServices, String sMethodName, String sDBSorName) {
        HashMap hmSlidInfo;
        ArrayList alServices = new ArrayList();
        ArrayList alServiceLevelSORs = new ArrayList();
        ArrayList alServiceTypes = new ArrayList();

        if (hmDBServices != null && !hmDBServices.isEmpty()) {
            HashMap hmConvertServicesResponse = new HashMap();

            logger.info("{}{}CUP_04.1.1 : Calling ConvertServicesHelper.convertServices with Hash : {}", sClassName, sMethodName, hmDBServices);
            hmConvertServicesResponse = oConvertServicesHelper.convertServices(hmDBServices);
            logger.info("{}{}CUP_04.1.2 : Response from ConvertServicesHelper.convertServices: {}", sClassName, sMethodName, hmConvertServicesResponse);

            alServiceTypes = (ArrayList) hmConvertServicesResponse.get(CommonDefs.SERVICE_TYPES);
            alServices = (ArrayList) hmConvertServicesResponse.get(CommonDefs.SERVICES);
            alServiceLevelSORs = (ArrayList) hmConvertServicesResponse.get(CommonDefs.SERVICE_LEVEL_SORS);
            if (alServiceLevelSORs.isEmpty())
                alServiceLevelSORs.add(sDBSorName);

            logger.info("{}{}CUP_04.1 : hmConvertServicesResponse : {}", sClassName, sMethodName, hmConvertServicesResponse);


        } else {
            // Added member level sor if member have no services
            alServiceLevelSORs.add(sDBSorName);
        }
        return alServiceTypes;
    }

    private static void retrieveMainCTN(HashMap hmDBMemberInfo, HashMap hmPwdHelperInput, String sMethodName, HashMap hmDBServices) {
        HashMap hmSlidInfo = (HashMap) hmDBMemberInfo.get(MPSDefs.KEY_SLID_INFO);
        if (hmSlidInfo != null && !hmSlidInfo.isEmpty()) {
            HashMap<String, Object> hmSlidServices = (HashMap<String, Object>) hmSlidInfo.get(CommonDefs.SERVICES);
            if (hmSlidServices != null) {
                HashMap<String, Object> hmDBService = (HashMap<String, Object>) hmSlidServices.get(MPSDefs.MOSUB_SERVICE);
                if (hmDBService != null) {
                    hmDBService.values().stream()
                            .filter(obj -> obj instanceof HashMap)
                            .map(obj -> (HashMap) obj)
                            .filter(hmDBInstance -> hmDBInstance.get(MPSDefs.DB_INSTANCE_ID) != null)
                            .findFirst()
                            .ifPresent(hmDBInstance -> {
                                hmPwdHelperInput.put(CommonDefs.MAIN_CTN, (String) hmDBInstance.get(MPSDefs.DB_INSTANCE_ID));
                                logger.info("{}{}CUP_04.0.0 : MAIN_CTN : {}", sClassName, sMethodName, hmDBInstance.get(MPSDefs.DB_INSTANCE_ID));
                            });
                }
            }
        } else if (hmDBServices != null && hmDBServices.containsKey(CommonDefs.MOSUB_SERVICE)) {
            HashMap<String, Object> hmDBService = (HashMap<String, Object>) hmDBServices.get(MPSDefs.MOSUB_SERVICE);
            if (hmDBService != null) {
                for (Object obj : hmDBService.values()) {
                    if (obj instanceof HashMap) {
                        HashMap hmDBInstance = (HashMap) obj;
                        String instanceId = (String) hmDBInstance.get(MPSDefs.DB_INSTANCE_ID);
                        if (instanceId != null) {
                            hmPwdHelperInput.put(CommonDefs.MAIN_CTN, instanceId);
                            logger.info("{}{}CUP_04.0.1 : MAIN_CTN : {}", sClassName, sMethodName, instanceId);
                            break;
                        }
                    }
                }
            }
        }
    }

    private void checkDirtyPassword(Map hmInput, ArrayList<String> alPwdDirtyCSI) {
        String sMethodName = ".checkDirtyPassword.";

        if (propPasswordDirtyCSI != null && !propPasswordDirtyCSI.isEmpty()) {
            alPwdDirtyCSI = CommonUtil.parseToArray(propPasswordDirtyCSI, CommonDefs.VALUE_SEPARATOR_CHAR);

            logger.info("{}{}{}", sClassName, sMethodName, "CUP_03 : CUP_Password_Dirty_CSI : " + alPwdDirtyCSI);
        }

        if (alPwdDirtyCSI != null && alPwdDirtyCSI.contains(hmInput.get(hmInput.get(CommonDefs.CALLING_SYSTEM_ID)))) {
            hmInput.put(CommonDefs.PASSWORD_DIRTY, MPSDefs.YES);
        }
    }

    private HashMap getParentServiceDetails(String sDBParentChildInd, String sDBParentHandle, String sDBParentDomain, String sMethodName) {
        HashMap hmDBParentInfo = null;
        if (sDBParentChildInd != null && sDBParentChildInd.equals(MPSDefs.MPS_CHILD)) {
            HashMap hmParentGetInfoInp = new HashMap();
            hmParentGetInfoInp.put(MPSDefs.DB_MEMBER_NAME, sDBParentHandle);
            hmParentGetInfoInp.put(MPSDefs.DB_DOMAIN_NAME, sDBParentDomain);

            logger.debug("{}{}UUP_101.a : Calling MPSDB_GetMemberServices_H.getMemberServices for parent with Hash : {}", sClassName, sMethodName, hmParentGetInfoInp);

            hmDBParentInfo = getMemberServicesDBHelperObj.getMemberServices(hmParentGetInfoInp);

            logger.debug("{}{}UUP_101.b : Response Hash from MPSDB_GetMemberServices_H.getMemberServices for parent : {}", sClassName, sMethodName, hmDBParentInfo);

            if (hmDBParentInfo == null || hmDBParentInfo.isEmpty()) {
                String stAppInfo = "MPSDB_GetMemberServices_H returned null/empty response";
                HashMap hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                logger.info("{}{}UUP_101.c : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }
        }
        return hmDBParentInfo;
    }

    private HashMap handleLockoutInfo(ArrayList alLockoutInfo, HashMap hmDBMemberInfo, HashMap hmPwdHelperInput, ArrayList<String> alAgentList, String sCallingSystemId, String sClassName, String sMethodName) {
        logger.info("{}{}CUP_07 : Lockout data present: {}", sClassName, sMethodName, alLockoutInfo);
        HashMap hmLockoutQueryInput = new HashMap();
        hmLockoutQueryInput.put(CommonDefs.MEMBER_NUM, hmDBMemberInfo.get(MPSDefs.DB_MEMBER_NUM));
        hmLockoutQueryInput.put(CommonDefs.MEMBER_LOCKOUT, alLockoutInfo);

        logger.debug("{}{}CUP_07.1 : Calling LockoutHelper.queryLockout with Hash : {}", sClassName, sMethodName, hmLockoutQueryInput);
        HashMap hmResponse = oLockoutHelper.queryLockout(hmLockoutQueryInput);
        logger.debug("{}{}CUP_08 : Response from queryLockout() : {}", sClassName, sMethodName, hmResponse);

        String stAppStatusCode = (String) hmResponse.get(MPSDefs.APP_STATUS_CODE);
        if (!stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
            return hmResponse;
        }

        ArrayList alActiveLocks = (ArrayList) hmResponse.get(CommonDefs.ACTIVE_LOCKS);
        ArrayList alExpiredLocks = (ArrayList) hmResponse.get(CommonDefs.EXPIRED_LOCKS);
        ArrayList alNonExpiredNonActiveLocks = (ArrayList) hmResponse.get(CommonDefs.NONEXPIRED_NONACTIVE_LOCKS);

        if (alExpiredLocks != null)
            hmPwdHelperInput.put(CommonDefs.EXPIRED_LOCKS, alExpiredLocks);
        if (alNonExpiredNonActiveLocks != null)
            hmPwdHelperInput.put(CommonDefs.NONEXPIRED_NONACTIVE_LOCKS, alNonExpiredNonActiveLocks);
        if (alActiveLocks != null) {
            hmPwdHelperInput.put(CommonDefs.ACTIVE_LOCKS, alActiveLocks);

            Iterator iter = alActiveLocks.iterator();
            while (iter.hasNext()) {
                HashMap hmEachLock = (HashMap) iter.next();
                String sLockName = (String) hmEachLock.get(MPSDefs.DB_LOCKOUT_NAME);

                if (sLockName.equals(CommonDefs.CHANGE_PASSWORD) && !alAgentList.contains(sCallingSystemId)) {
                    String stAppInfo = "Handle currently locked out with a " + CommonDefs.CHANGE_PASSWORD + " lock.";
                    HashMap hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_MID_LOCKOUT_NUM, stAppInfo);
                    logger.info("{}{}CUP_09 : {}", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                }
            }
        }
        return null;
    }

    private HashMap getSlidInfoForFraudLocks(Map hmInput, HashMap hmDBMemberInfo, HashMap hmPwdHelperInput, String sMethodName) {
        HashMap hmSlidInfoForFraudLocks = null;

        String sDomain = (String) hmInput.get(CommonDefs.DOMAIN);
        ;
        if (sDomain != null && !sDomain.equals(CommonDefs.SLID_DUM) && hmDBMemberInfo != null
                && hmDBMemberInfo.containsKey(MPSDefs.KEY_SLID_INFO)) {
            hmSlidInfoForFraudLocks = (HashMap) hmDBMemberInfo.get(MPSDefs.KEY_SLID_INFO);
        } else if (sDomain != null && sDomain.equals(CommonDefs.SLID_DUM)) {
            hmSlidInfoForFraudLocks = hmDBMemberInfo;
        }

        String sSlidMemberNum = (String) hmDBMemberInfo.get(MPSDefs.DB_SLID_MEMBER_NUM);

        if (hmSlidInfoForFraudLocks != null && !hmSlidInfoForFraudLocks.isEmpty()
                && hmSlidInfoForFraudLocks.get(MPSDefs.DB_USER_LOCK_LEVEL) != null && sSlidMemberNum != null) {
            String sUserLockLevel = (String) hmSlidInfoForFraudLocks.get(MPSDefs.DB_USER_LOCK_LEVEL);
            String sUserLockReason = (String) hmSlidInfoForFraudLocks.get(MPSDefs.DB_USER_LOCK_REASON);
            if (sUserLockReason != null && !sUserLockReason.isEmpty()) {
                hmPwdHelperInput.put(MPSDefs.DB_USER_LOCK_REASON, sUserLockReason);
            }

            if ("1".equals(sUserLockLevel)) {
                hmPwdHelperInput.put("PROCESS_USER_FRAUD_LOCKS", "Y");
            }
            if ("2".equals(sUserLockLevel)) {
                String stAppInfo = "User Fraud lock 2 exists";
                HashMap hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_FRAUD_LOCKED_NUM, stAppInfo);
                logger.info("{}{}CUP_10 : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }
        }
        return hmSlidInfoForFraudLocks;
    }

    private void populatePwdHelperInput(HashMap hmDBMemberInfo, HashMap hmDBParentInfo, HashMap hmPwdHelperInput) {
        String sDBMemberNum = (String) hmDBMemberInfo.get(MPSDefs.DB_MEMBER_NUM);
        if (sDBMemberNum != null) {
            hmPwdHelperInput.put(CommonDefs.MEMBER_NUM, sDBMemberNum);
        }

        hmPwdHelperInput.put(CommonDefs.PARENT_HANDLE, hmDBMemberInfo.get(MPSDefs.DB_PARENT_NAME));
        hmPwdHelperInput.put(CommonDefs.PARENT_DOMAIN, hmDBMemberInfo.get(MPSDefs.DB_PARENT_DOMAIN));

        if (hmDBParentInfo != null)
            hmPwdHelperInput.put(CommonDefs.AGG_EMAIL_STATUS, hmDBParentInfo.get(MPSDefs.DB_AGG_EMAIL_STATUS));
        else
            hmPwdHelperInput.put(CommonDefs.AGG_EMAIL_STATUS, hmDBMemberInfo.get(MPSDefs.DB_AGG_EMAIL_STATUS));
        hmPwdHelperInput.put(CommonDefs.CONTACT_EMAIL, hmDBMemberInfo.get(MPSDefs.DB_CONTACT_EMAIL));

        if (hmDBMemberInfo.containsKey(MPSDefs.DB_BROWSER_LANGUAGE))
            hmPwdHelperInput.put(CommonDefs.BROWSER_LANGUAGE, hmDBMemberInfo.get(MPSDefs.DB_BROWSER_LANGUAGE));
        if (hmDBMemberInfo.containsKey(MPSDefs.DB_LC_FIRSTNAME))
            hmPwdHelperInput.put(CommonDefs.FIRST_NAME, hmDBMemberInfo.get(MPSDefs.DB_LC_FIRSTNAME));
        if (hmDBMemberInfo.containsKey(MPSDefs.DB_LC_LASTNAME))
            hmPwdHelperInput.put(CommonDefs.LAST_NAME, hmDBMemberInfo.get(MPSDefs.DB_LC_LASTNAME));
    }

    private void prepareNotification(Map hmInput, HashMap hmDBMemberInfo, HashMap hmPwdHelperInput, ArrayList alServiceTypes, ArrayList alLinkedUsers, ArrayList<Map<String, Object>> alDbusInput) {
        String sIsUpdateSilent = (String) hmInput.get(CommonDefs.IS_UPDATE_SILENT);
        sIsUpdateSilent = (sIsUpdateSilent == null) ? CommonDefs.DEFAULT_NO : sIsUpdateSilent;
        String sHandle = (String) hmInput.get(CommonDefs.HANDLE);
        String sDBMemberNum = (String) hmDBMemberInfo.get(MPSDefs.DB_MEMBER_NUM);
        if ("N".equals(sIsUpdateSilent)) {
            String sCustomerId = null;
            String sCustomerServiceType = null;
            String sSLID_Notification = null;
            String sIdType = null;
            String sDomain = (String) hmInput.get(CommonDefs.DOMAIN);
            String sMethodName = ".prepareNotification.";
            logger.info("{}{}UUP_112.a : ChangePassword_Service_To_NotificationField : {}", sClassName, sMethodName, stSrvNotificationField);

            HashMap hmServiceToNotificationfieldMapping = CommonUtil.parsePropertyToHash(stSrvNotificationField);


            if (hmServiceToNotificationfieldMapping != null && !hmServiceToNotificationfieldMapping.isEmpty()) {
                if (sDomain.equals(CommonDefs.SLID_DUM)) {
                    sCustomerId = sHandle;
                    sCustomerServiceType = (String) hmServiceToNotificationfieldMapping.get(CommonDefs.KEY_SLID);
                } else if (alServiceTypes != null && alServiceTypes.contains(MPSDefs.UVERSE_SERVICE)) {
                    sCustomerServiceType = (String) hmServiceToNotificationfieldMapping.get(MPSDefs.UVERSE_SERVICE);
                    sCustomerId = sHandle + "@" + sDomain;
                } else if (alServiceTypes != null && alServiceTypes.contains(MPSDefs.DSL_SERVICE)) {
                    sCustomerServiceType = (String) hmServiceToNotificationfieldMapping.get(MPSDefs.DSL_SERVICE);
                    sCustomerId = sHandle + "@" + sDomain;
                } else if (alServiceTypes != null && alServiceTypes.contains(MPSDefs.DIAL_SERVICE)) {
                    sCustomerServiceType = (String) hmServiceToNotificationfieldMapping.get(MPSDefs.DIAL_SERVICE);
                    sCustomerId = sHandle + "@" + sDomain;
                } else if (alServiceTypes != null && alServiceTypes.contains(MPSDefs.SWH_SERVICE)) {
                    sCustomerServiceType = (String) hmServiceToNotificationfieldMapping.get(MPSDefs.SWH_SERVICE);
                    sCustomerId = sHandle + "@" + sDomain;
                } else if (alServiceTypes != null && alServiceTypes.contains(MPSDefs.ECOMM_SERVICE)) {
                    sCustomerServiceType = (String) hmServiceToNotificationfieldMapping.get(MPSDefs.ECOMM_SERVICE);
                    sCustomerId = sHandle + "@" + sDomain;
                } else if (alServiceTypes != null && alServiceTypes.size() == 1
                        && alServiceTypes.contains(MPSDefs.PORTAL_SERVICE)) {
                    sCustomerServiceType = (String) hmServiceToNotificationfieldMapping.get(MPSDefs.PORTAL_SERVICE);
                    sCustomerId = sHandle + "@" + sDomain;
                }
            }

            if (sDomain != null && !sDomain.equals(CommonDefs.SLID_DUM) && hmDBMemberInfo != null
                    && hmDBMemberInfo.containsKey(MPSDefs.KEY_SLID_INFO)) {
                sSLID_Notification = (String) ((HashMap) hmDBMemberInfo.get(MPSDefs.KEY_SLID_INFO))
                        .get(MPSDefs.DB_MEMBER_NAME);
            } else if (sDomain != null && sDomain.equals(CommonDefs.SLID_DUM)) {
                sSLID_Notification = sHandle;
            }

            if (sDomain != null && !sDomain.equals(CommonDefs.SLID_DUM) && sSLID_Notification != null) {
                sIdType = "ID_LINKED_TO_SLID";
            } else if (sDomain != null && sDomain.equals(CommonDefs.SLID_DUM)
                    && (alLinkedUsers != null && !alLinkedUsers.isEmpty())) {//[R1908] Updated for proper idType generation

                sIdType = "SLID_WITH_LINKED_ID";
            } else if (sDomain != null && sDomain.equals(CommonDefs.SLID_DUM)
                    && (alLinkedUsers == null || alLinkedUsers.isEmpty())) {
                sIdType = "SLID";
            } else {
                sIdType = null;
            }

            HashMap hmNotificationfields = new HashMap();
            hmNotificationfields.put("customerId", sCustomerId);
            hmNotificationfields.put("customerServiceType", sCustomerServiceType);
            hmNotificationfields.put("idType", sIdType);
            hmNotificationfields.put("SLID", sSLID_Notification);

            HashMap hmInputNotification = new HashMap();
            hmInputNotification.put("Notificationfields", hmNotificationfields);
            hmInputNotification.put("ServiceToNotificationfieldMapping", hmServiceToNotificationfieldMapping);

            HashMap hmResponse = passwordQueueHelper.buildNotificationHash(hmPwdHelperInput, hmDBMemberInfo, hmInputNotification);

            String stAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);

            if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
                logger.info("{}{}UUP_112.b : {}", sClassName, sMethodName, stAppInfo);
                HashMap hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                return;
            }

            HashMap hmNotification = (HashMap) hmResponse.get("NOTIFICATIONHASH");
            if (hmNotification != null && !hmNotification.isEmpty()) {
                alDbusInput.add(hmNotification);
            }

            if (alLinkedUsers != null) {
                Iterator alLinkedUsersIterator = alLinkedUsers.iterator();
                while (alLinkedUsersIterator.hasNext()) {
                    HashMap hmEachUser = (HashMap) alLinkedUsersIterator.next();

                    String sEachUserMemNum = (String) hmEachUser.get(MPSDefs.DB_MEMBER_NUM);
                    if (sEachUserMemNum != null && !sEachUserMemNum.equals(sDBMemberNum)) {
                        hmResponse = passwordQueueHelper.buildNotificationHash(hmPwdHelperInput, hmEachUser, hmInputNotification);

                        stAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);

                        if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                            String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
                            logger.info("{}{}UUP_112.c : {}", sClassName, sMethodName, stAppInfo);
                            HashMap hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                            return;
                        }

                        if (hmResponse.get("NOTIFICATIONHASH") != null) {
                            alDbusInput.add((Map<String, Object>) hmResponse.get("NOTIFICATIONHASH"));
                        }
                    }
                }
            }
        }
    }

    private Map<String, Object> checkAppStatusCode(Map<String, Object> hmResult, String sMethodName, String ErrorMessage) {
        String stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
        if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
            String stAppInfo = "Error returned from " + ErrorMessage;
            logger.info("{}{}UUP_109.a : {}", sClassName, sMethodName, stAppInfo);
            return hmResult;
        }
        return CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
    }

    private HashMap<String, Object> buildCSIServicesLists(String sInterestedCSIServices) throws Exception {

        HashMap<String, Object> hmResponse = null;
        String sAppInfo = null;

        StringTokenizer strTok1 = new StringTokenizer(sInterestedCSIServices, "|");
        // build ArrayList using tokens
        ArrayList alInterestedCSIs = new ArrayList();
        ArrayList alInterestedCallingSystemServices = new ArrayList();

        while (strTok1.hasMoreTokens()) {
            String sTok1 = strTok1.nextToken().trim();
            StringTokenizer strTok2 = CommonUtil.getStringTokenizer(sTok1, ";");

            // --The first entry will be calling systemId...
            String sTok2 = strTok2.nextToken().trim();
            alInterestedCSIs.add(sTok2);

            HashMap<String, Object> hmEntry = CommonUtil.getHashMap();
            hmEntry.put(CommonDefs.CALLING_SYSTEMS, sTok2);
            String sTok3 = strTok2.nextToken().trim();

            if (sTok3 != null && sTok3.length() > 0) {
                StringTokenizer strTok3 = CommonUtil.getStringTokenizer(sTok3, ",");
                ArrayList alServices = CommonUtil.getArrayList();

                while (strTok3.hasMoreTokens()) {
                    while (strTok3.hasMoreTokens()) {
                        String sTok4 = strTok3.nextToken().trim();
                        alServices.add(sTok4);
                    }
                    hmEntry.put(CommonDefs.SERVICES, alServices);
                }
                alInterestedCallingSystemServices.add(hmEntry);
            }

            hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS);
            hmResponse.put("alInterestedCSIs", alInterestedCSIs);
            hmResponse.put("alInterestedCallingSystemServices", alInterestedCallingSystemServices);

        }
        return hmResponse;

    }

    private Map doOldPwdCheck(HashMap hmInput, HashMap hmDBInput) {

        String sMethodName = "doCommonChecks";
        String sAppStatusCode = "";
        Map hmResponse = new HashMap();

        logger.info("{}{}UUP_108.a : Input Hash = {}", sClassName, sMethodName, hmInput);

        try {
            String currentClearPassword = (String) hmInput.get("oldPassword");
            String mpsEncPassword = (String) hmDBInput.get(CommonDefs.DB_ENC_PASSWORD);
            String mpsSHA1Password = (String) hmDBInput.get(CommonDefs.DB_SHA1_PASSWORD);
            String mpsSSHAPassword = (String) hmDBInput.get(CommonDefs.DB_SSHA_PASSWORD);
            String mpsMD5Password = (String) hmDBInput.get(CommonDefs.DB_MD5_PASSWORD);
            //2103 - SSHA-256 encryption changes
            String mpsGenPassword = null;
            String mpsGenPasswordType = null;

            if (sGen_password_type != null && !sGen_password_type.trim().isEmpty()) {
                mpsGenPassword = (String) hmDBInput.get(CommonDefs.DB_GEN_PASSWORD);
                mpsGenPasswordType = (String) hmDBInput.get(CommonDefs.DB_GEN_PASSWORD_TYPE);
            }

            // Only process this loggeric if currentClearPassword is not null
            if (currentClearPassword != null) {
                /**
                 * Check for Crypt password first. Compare with the generated Crypt using
                 * currentClearPassword If they do not match and attemptCount < threshold, throw
                 * invalid password error Else if they do not match and attemptCount =
                 * threshold, process lockout loggeric and throw mid lockout error upon successful
                 * completion
                 */
                //2103 - SSHA-256 encryption changes
                if (mpsGenPassword != null && !mpsGenPassword.trim().isEmpty()) {

                    HashMap pwdInHs = new HashMap();
                    HashMap pwdResult;
                    pwdInHs.put(MPSDefs.WS_CLEAR_TEXT, currentClearPassword);
                    pwdResult = oRILCheckAndEncryptPasswordHelper.generateGenericPassword(pwdInHs, mpsGenPasswordType, logger);
                    String genPassFromCCP = null;
                    if (pwdResult != null && !pwdResult.isEmpty()) {
                        genPassFromCCP = (String) pwdResult.get(RILDefs.RIL_GEN_PASSWORD);
                    }
                    if (mpsGenPassword != null && !mpsGenPassword.equals(genPassFromCCP)) {

                        hmResponse = processFailedAuth(hmInput, hmDBInput, logger);
                        logger.debug("{}{}UUP_108.b : Response from processFailedAuth(): {}", sClassName, sMethodName, hmResponse);

                        sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
                        if (sAppStatusCode.equalsIgnoreCase(CErrorDefs.ERR_MID_LOCKOUT)) {
                            hmResponse = CommonErrorMap.makeCommonStatusMap(CErrorDefs.ERR_MID_LOCKOUT_NUM,
                                    "currentClearPassword does not match with the password in MPS DB (SSHA256). Handle is now locked.");
                        } else if (sAppStatusCode.equalsIgnoreCase(CErrorDefs.COMMON_SUCCESS)) {
                            hmResponse = CommonErrorMap.makeCommonStatusMap(CErrorDefs.ERR_INVALID_PASSWD_NUM,
                                    "currentClearPassword does not match the password in the MPS DB (SSHA256).");
                        }

                        return hmResponse;
                    }

                } else if (mpsSSHAPassword != null || mpsSHA1Password != null) {
                    // Adding an exception for CPR in April 2010
                    if (mpsEncPassword == null || mpsEncPassword.length() == 0) {
                        logger.info("{}{}UUP_108.c : Bypassing password validation when SHA1 or SSHA is only password type and the account has ECOMM service and service-level SOR of CPR.", sClassName, sMethodName);

                    } else {
                        /**
                         * Next, check for SHA-1 password. Compare with the generated SHA-1 using
                         * currentClearPassword If they do not match and attemptCount < threshold, throw
                         * invalid password error Else if they do not match and attemptCount =
                         * threshold, process lockout loggeric and throw mid lockout error upon successful
                         * completion
                         */
                        HashMap pwdInHs = new HashMap();
                        HashMap pwdResult = null;
                        pwdInHs.put(MPSDefs.WS_CLEAR_TEXT, currentClearPassword);
                        pwdResult = oRILCheckAndEncryptPasswordHelper.generateSHA1Password(pwdInHs, logger);

                        String sha1PassFromCCP = (String) pwdResult.get(RILDefs.RIL_SHA1_PASSWORD);
                        if (mpsSHA1Password != null && !mpsSHA1Password.equals(sha1PassFromCCP)) {

                            logger.debug("{}{}UUP_108.d : Calling processFailedAuth(): {}", sClassName, sMethodName, hmDBInput);
                            hmResponse = processFailedAuth(hmInput, hmDBInput, logger);
                            logger.debug("{}{}UUP_108.e : Response from processFailedAuth(): {}", sClassName, sMethodName, hmResponse);

                            sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
                            if (sAppStatusCode.equalsIgnoreCase(CErrorDefs.ERR_MID_LOCKOUT)) {
                                hmResponse = CommonErrorMap.makeCommonStatusMap(CErrorDefs.ERR_MID_LOCKOUT_NUM,
                                        "currentClearPassword does not match the password in the MPS DB. Handle is now locked.");
                            } else if (sAppStatusCode.equalsIgnoreCase(CErrorDefs.COMMON_SUCCESS)) {
                                hmResponse = CommonErrorMap.makeCommonStatusMap(CErrorDefs.ERR_INVALID_PASSWD_NUM,
                                        "currentClearPassword does not match the password in the MPS DB.");
                            }

                        }
                    }
                } else if (mpsMD5Password != null) {
                    HashMap pwdInHs = new HashMap();
                    HashMap pwdResult;
                    pwdInHs.put(MPSDefs.WS_CLEAR_TEXT, currentClearPassword);
                    pwdResult = oRILCheckAndEncryptPasswordHelper.generateMD5Password(pwdInHs, logger);

                    String md5PassFromCCP = (String) pwdResult.get(RILDefs.RIL_MD5_PASSWORD);
                    if (!mpsMD5Password.equals(md5PassFromCCP)) {

                        hmResponse = processFailedAuth(hmInput, hmDBInput, logger);
                        logger.debug("{}{}UUP_108.f : Response from processFailedAuth(): {}", sClassName, sMethodName, hmResponse);

                        sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
                        if (sAppStatusCode.equalsIgnoreCase(CErrorDefs.ERR_MID_LOCKOUT)) {
                            hmResponse = CommonErrorMap.makeCommonStatusMap(CErrorDefs.ERR_MID_LOCKOUT_NUM,
                                    "currentClearPassword does not match with the password in MPS DB (MD5). Handle is now locked.");
                        } else if (sAppStatusCode.equalsIgnoreCase(CErrorDefs.COMMON_SUCCESS)) {
                            hmResponse = CommonErrorMap.makeCommonStatusMap(CErrorDefs.ERR_INVALID_PASSWD_NUM,
                                    "currentClearPassword does not match the password in the MPS DB (MD5).");
                        }

                    }
                } else {
                    // Else, SHA-1, MD5, and AES256 passwords are missing from MPS DB.
                    hmResponse = processFailedAuth(hmInput, hmDBInput, logger);
                    logger.debug("{}{}UUP_108.i : Response from processFailedAuth(): {}", sClassName, sMethodName, hmResponse);

                    sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
                    if (sAppStatusCode.equalsIgnoreCase(CErrorDefs.ERR_MID_LOCKOUT)) {
                        hmResponse = CommonErrorMap.makeCommonStatusMap(CErrorDefs.ERR_MID_LOCKOUT_NUM,
                                "SHA-1 and MD5 passwords missing from MPS DB. Handle is now locked.");
                    } else if (sAppStatusCode.equalsIgnoreCase(CErrorDefs.COMMON_SUCCESS)) {
                        hmResponse = CommonErrorMap.makeCommonStatusMap(CErrorDefs.ERR_INVALID_PASSWD_NUM,
                                "SHA-1 and MD5 passwords missing from MPS DB.");
                    }

                }
            }
        } catch (Exception e) {
            hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
            logger.error("{}{}UUP_108.j : Error:: {}", sClassName, sMethodName, e.getMessage());
            logger.error("{}{}UUP_108.k : Exception = {}", sClassName, sMethodName, e);
        }
        return hmResponse;
    }

    public Map processFailedAuth(HashMap hmInput, HashMap hmDBInput, Logger logger) {
        String sMethodName = "processFailedAuth";
        Map hmResponse = new HashMap();
        String sAppInfo = "";
        String sAppStatusCode = "";
        boolean isAccountLocked = false;
        ArrayList alLocks = null;
        String stAppStatusCode = null;
        String stAppInfo = null;

        logger.info("{}{}PFA-1 : Input Hash = {}", sClassName, sMethodName, hmInput);

        try {
            String sLockoutName = (String) hmInput.get(MPSDefs.DB_LOCKOUT_NAME);
            HashMap hmLockoutUpdateInput = new HashMap();
            hmLockoutUpdateInput.put(MPSDefs.DB_MEMBER_NUM, hmDBInput.get(MPSDefs.DB_MEMBER_NUM));
            hmLockoutUpdateInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
            hmLockoutUpdateInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
            hmLockoutUpdateInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
            hmLockoutUpdateInput.put(CommonDefs.HANDLE, hmInput.get(CommonDefs.HANDLE));
            hmLockoutUpdateInput.put(CommonDefs.DOMAIN, hmInput.get(CommonDefs.DOMAIN));
            hmLockoutUpdateInput.put(CommonDefs.VALIDATION_STATUS, CommonDefs.VALIDATION_STATUS_FAILURE);

            boolean isNewLockNeeded = true;

            if (hmInput.containsKey(CommonDefs.ACTIVE_LOCKS)) {
                ArrayList alActiveLocks = (ArrayList) hmInput.get(CommonDefs.ACTIVE_LOCKS);
                Iterator iter = alActiveLocks.iterator();
                ArrayList alInterestedLocks = new ArrayList();
                while (iter.hasNext()) {
                    HashMap hmEachLock = (HashMap) iter.next();
                    String sLockName = (String) hmEachLock.get(MPSDefs.DB_LOCKOUT_NAME);
                    if (sLockName.equals(sLockoutName)) {
                        alInterestedLocks.add(hmEachLock);
                        hmLockoutUpdateInput.put(CommonDefs.ACTIVE_LOCKS, alInterestedLocks);
                        isNewLockNeeded = false;
                        break;
                    }
                }
            }
            if (hmInput.containsKey(CommonDefs.EXPIRED_LOCKS)) {
                ArrayList alExpiredLocks = (ArrayList) hmInput.get(CommonDefs.EXPIRED_LOCKS);
                Iterator iter = alExpiredLocks.iterator();
                ArrayList alInterestedLocks = new ArrayList();
                while (iter.hasNext()) {
                    HashMap hmEachLock = (HashMap) iter.next();
                    String sLockName = (String) hmEachLock.get(MPSDefs.DB_LOCKOUT_NAME);
                    if (sLockName.equals(sLockoutName)) {
                        alInterestedLocks.add(hmEachLock);
                        hmLockoutUpdateInput.put(CommonDefs.EXPIRED_LOCKS, alInterestedLocks);
                        isNewLockNeeded = false;
                        break;
                    }
                }
            }
            if (hmInput.containsKey(CommonDefs.NONEXPIRED_NONACTIVE_LOCKS)) {
                ArrayList alNonExpiredNonActiveLocks = (ArrayList) hmInput.get(CommonDefs.NONEXPIRED_NONACTIVE_LOCKS);
                Iterator iter = alNonExpiredNonActiveLocks.iterator();
                ArrayList alInterestedLocks = new ArrayList();
                while (iter.hasNext()) {
                    HashMap hmEachLock = (HashMap) iter.next();
                    String sLockName = (String) hmEachLock.get(MPSDefs.DB_LOCKOUT_NAME);
                    if (sLockName.equals(sLockoutName)) {
                        alInterestedLocks.add(hmEachLock);
                        hmLockoutUpdateInput.put(CommonDefs.NONEXPIRED_NONACTIVE_LOCKS, alInterestedLocks);
                        isNewLockNeeded = false;
                        break;
                    }
                }
            }

            if (isNewLockNeeded) {
                ArrayList alNewLock = new ArrayList();
                HashMap hmNewLock = new HashMap();
                String sSlidMemberNum = (String) hmDBInput.get(MPSDefs.DB_SLID_MEMBER_NUM);
                if (sSlidMemberNum != null && sSlidMemberNum.length() > 0)
                    hmNewLock.put(MPSDefs.DB_MEMBER_NUM, sSlidMemberNum);
                else
                    hmNewLock.put(MPSDefs.DB_MEMBER_NUM, hmDBInput.get(MPSDefs.DB_MEMBER_NUM));
                hmNewLock.put(MPSDefs.DB_LOCKOUT_NAME, hmInput.get(MPSDefs.DB_LOCKOUT_NAME));
                alNewLock.add(hmNewLock);
                hmLockoutUpdateInput.put("newLock", alNewLock);
            }

            logger.info("{}{}PFA-2a : Calling oLockoutHelper.updateLockout()", sClassName, sMethodName);

            alLocks = new ArrayList();
            hmResponse = oLockoutHelper.updateLockout(hmLockoutUpdateInput);
            logger.info("{}{}PFA-2b : Calling oLockoutHelper.updateLockout()", sClassName, sMethodName);
            sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
            if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS) && !sAppStatusCode.equals(CErrorDefs.ERR_MID_LOCKOUT))
                return hmResponse;
            if (sAppStatusCode.equals(CErrorDefs.ERR_MID_LOCKOUT))
                isAccountLocked = true;

            if (hmResponse.containsKey(sLockoutName)) {
                alLocks.addAll((ArrayList) hmResponse.get(sLockoutName));
            }

            String sFailedAuthCount = "1";
            if (hmResponse.containsKey(sLockoutName)) {
                ArrayList alUpdatedLock = (ArrayList) hmResponse.get(sLockoutName);
                HashMap hmUpdatedLock = (HashMap) alUpdatedLock.get(0);
                sFailedAuthCount = (String) hmUpdatedLock.get(MPSDefs.DB_FAILED_AUTH_COUNT);
            }
            ArrayList alDbus = new ArrayList();
            HashMap hmGACH = oUserPasswordHelper.generateHmGACH(hmInput, hmDBInput);
            hmGACH.put(CommonDefs.CREATE_INTERACTION_RESULT, CommonDefs.REASON_CODE_FAILED);
            hmGACH.put(MPSDefs.DB_FAILED_AUTH_COUNT, sFailedAuthCount);
            hmResponse = oUserPasswordHelper.buildCreateInteractionHash(hmGACH, hmDBInput);
            sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
            if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
                return hmResponse;

            if (hmResponse.get("CREATEINTERACTIONHASH") != null) {
                logger.info("{}{}PFA-3a : Calling Dbus() ", sClassName, sMethodName);
                alDbus.add(hmResponse.get("CREATEINTERACTIONHASH"));
                // call makeasync call


                logger.info("{}{}PFA-4a : Calling makeAsyncCall ", sClassName, sMethodName);

                hmResponse = passwordQueueHelper.sendMessageToMQ(hmInput, hmDBInput, alDbus, PasswordQueueHelper.UPDATE_EVENT_TYPE);

                logger.info("{}{}PFA-4b : Response from makeAsyncCall : {}", sClassName, sMethodName, hmResponse);

                stAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);

                if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                    stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
                    logger.info("{}{}GPH_09.2 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
                    hmResponse = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                    return hmResponse;
                }

            } else
                logger.info("{}{}PFA-4c : CreateInteractionEvent not required.", sClassName, sMethodName);

        } catch (Exception e) {
            hmResponse = CommonErrorMap.makeExceptionMap(e);
            logger.error("{}{}PFA-E1 : Error:: {}", sClassName, sMethodName, e.getMessage());
            logger.error("{}{}PFA-E2 : Exception = {}", sClassName, sMethodName, e);

        } finally {
            if (hmResponse == null) {
                sAppInfo = "hmResponse is null";
                logger.info("{}{}PFA-Fa{}", sClassName, sMethodName, sAppInfo);
                hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
            } else {

                if (isAccountLocked) {
                    hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_MID_LOCKOUT_NUM,
                            "Account is now locked.");
                    if (!alLocks.isEmpty())
                        hmResponse.put(CommonDefs.LOCK_LIST, alLocks);
                }
                if (hmInput.containsKey(CommonDefs.SLID))
                    hmResponse.put(CommonDefs.SLID, hmInput.get(CommonDefs.SLID));

            }
            logger.info("{}{}PFA-Fb : Response From processFailedAuth() : {}", sClassName, sMethodName, hmResponse);
        }

        return hmResponse;
    }

    private HashMap getMemberServiceDetails(HashMap hmPwdHelperInput, Map hmInput) {
        String sMethodName = ".getMemberServiceDetails.";
        HashMap hmResult = null;
        String stAppStatusCode;
        String stAppInfo;
        ArrayList alSildMaskInp = new ArrayList();
        alSildMaskInp.add("LU");
        alSildMaskInp.add("LS");
        alSildMaskInp.add("SQ");
        alSildMaskInp.add("SS"); //1907:

        HashMap hmGetInfoInp = new HashMap();
        hmGetInfoInp.put(MPSDefs.DB_MEMBER_NAME, hmInput.get(CommonDefs.HANDLE));
        hmGetInfoInp.put(MPSDefs.DB_DOMAIN_NAME, hmInput.get(CommonDefs.DOMAIN));
        hmGetInfoInp.put(MPSDefs.SECURITY_ALL_REQ, CommonDefs.DEFAULT_YES);
        hmGetInfoInp.put(MPSDefs.DB_QUERY_MEMBERLOCKOUT_FLAG, CommonDefs.DEFAULT_YES);
        hmGetInfoInp.put(MPSDefs.QUERY_SLID_INFO_FLAG, CommonDefs.DEFAULT_YES);
        hmGetInfoInp.put(MPSDefs.QUERY_LINKED_USERS_FLAG, CommonDefs.DEFAULT_YES);
        hmGetInfoInp.put(MPSDefs.QUERY_FRAUD_LOCK_FLAG, CommonDefs.DEFAULT_YES);
        hmGetInfoInp.put(CommonDefs.SLID_MASK, alSildMaskInp);

        // PID-310691e [2006][MPSYS-US3] - Adding QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG as Y for prepaid MOBILITY account support.
        //change by pm675e
        String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
        if (!CommonDefs.CALLING_SYSTEM_ERICSSON.equals(sCallingSystemId)) {
            hmGetInfoInp.put(MPSDefs.QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG, CommonDefs.DEFAULT_YES);
        }
        //END

        String sIsUpdateSilent = (String) hmInput.get(CommonDefs.IS_UPDATE_SILENT);
        if (sIsUpdateSilent == null || sIsUpdateSilent.isEmpty()
                || !CommonDefs.IND_Y.equalsIgnoreCase(sIsUpdateSilent)) {
            hmGetInfoInp.put("queryMemberFraudPassword", MPSDefs.YES);
            hmPwdHelperInput.put("checkFraudPassword", "Y");
        }

        logger.debug("{}{}CUP_02a : Calling MPSDB_GetMemberServices_H.getMemberServices with Hash : {}", sClassName, sMethodName, hmGetInfoInp);

        HashMap hmDBMemberInfo = getMemberServicesDBHelperObj.getMemberServices(hmGetInfoInp);

        logger.debug("{}{}CUP_02b : Response Hash from MPSDB_GetMemberServices_H.getMemberServices : {}", sClassName, sMethodName, hmDBMemberInfo);

        if (hmDBMemberInfo == null || hmDBMemberInfo.isEmpty()) {

            stAppInfo = "MPSDB_GetMemberServices_H returned null/empty response";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
            logger.info("{}{}CUP_3.1 : {}", sClassName, sMethodName, stAppInfo);
            return hmResult;

        } else {
            hmResult = hmDBMemberInfo;
        }

        return hmResult;
    }

}