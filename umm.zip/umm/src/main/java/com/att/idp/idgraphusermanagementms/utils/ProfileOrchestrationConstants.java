package com.att.idp.idgraphusermanagementms.utils;

/**
 * The ProfileOrchestrationConstants class is a utility class that provides constant values used in profile orchestration.
 * This class is part of the com.att.idp.idgraphusermanagementms.utils package.
 * The constants defined in this class include header keys, status messages, transaction names, and other identifiers used in the profile orchestration process.
 * The class itself cannot be instantiated and is used to organize and centralize the constants used throughout the application.
 */
public class ProfileOrchestrationConstants {

	/* gateway header keys */
	public static final String IDPCTX_INDIVIDUALID = "idpctx-individualid";
	public static final String IDPCTX_LINKEDCGACCNUMS = "idpctx-linkedcgaccnums";
	public static final String IDPCTX_LOGGED_IN_ID = "idpctx-loggedinid";
	
	public static final String IDP_CG_ID = "idp-cg-id";
	
	public static final String X_ATT_CLIENTID = "x-att-clientid";
	
	public static final String IDM_PROFILE_MS = "IDMProfileMS";
	
	public static final String PROFILEORCHESTRATION_BSSE_ENDPOINT_BASE_URI = "/msapi/profileorch/bsseaccountinfo/v1/retrieve/";
	
	public static final String STATUS_SUCCESS = "SUCCESS";
	public static final String STATUS_ERROR = "ERROR";
	
	public static final String EMPTY = "";
	
	public static final String HEADER_KEY_SESSION_ID = "idpctx-session-id";
	public static final String IDPCTX_INDIVIDUALIDS = "idpctx-individualids";

	public static final String KBA_MODE_CONTINUE = "continue";
	public static final String KBA_MODE_INITIATE = "initiate";

   //updateUser constants
	public static final java.lang.String ADD_USER_TRANSACTION_NAME = "AddUser";
	public static final java.lang.String UPDATE_USER_TRANSACTION_NAME = "UpdateUser";
	public static final java.lang.String CHECK_USERID_AVAILABILITY_TRANSACTION_NAME = "CheckUserIdAvailabilty";
	public static final java.lang.String CHANGE_USERNAME_TRANSACTION_NAME = "ChangeUserName";
	public static final java.lang.String UPDATE_USERFRAUD_TRANSACTION_NAME = "UpdateUserFraud";
	public static final java.lang.String ADD_EXTUSER_TRANSACTION_NAME = "AddExtUser";
	public static final java.lang.String UPDATE_EXTUSER_TRANSACTION_NAME = "UpdateExtUser";
	public static final java.lang.String VALIDATE_USER_CREDENTIALS_TRANSACTION_NAME = "ValidateUserCredentials";
	public static final java.lang.String UPDATE_USER_CONTACT_CBR_TRANSACTION_NAME = "UpdateUserContactCBR";
	public static final java.lang.String CHECK_ACCESSID_MERGE_ELIGIBILITY = "CheckAccessIdMergeEligibility";
	public static final java.lang.String DBUS_TRANSACTION_ID = "dbusTransactionId";
	public static final java.lang.String DBUS_TRANSACTION_NAME = "dbusTransactionName";
	public static final java.lang.String MICROSERVICE_EVENT = "MicroServiceEvent";
	
	public static final String IDPTRACEID = "idpTraceId";
	public static final String IDP_TRACE_ID = "idp-trace-id";
	public static final String MERGE_USER_ACCESSID_TRANSACTION_NAME ="MergeUserAccessId";
	public static final String ACCOUNTS ="accounts";
	public static final String SUBSCRIBERS ="subscribers";
	public static final String UPDATE_USER_MQ_AEH_SWITCH = "cfg-idgraph-updateuser-mq-aeh-switch";
	public static final String UPDATE_USER_NOTIFICATION_CLM_SWITCH = "cfg-idgraph-updateuser-notification-clm-switch";
	public static final String ADD_UPDATE_EXTUSER_TRANSACTION_NAME ="AddUpdateExtUser";
	public static final String ADD_SEC_MEMBERID_TRANSACTION_NAME ="AddSecMemberId";
	public static final String UPG_SEC_MEMBERID_TRANSACTION_NAME ="UpgSecMemberId";
	public static final String LINK_MEMBER_TRANSACTION_NAME ="LinkMember";
	public static final String MERGE_SLID_PROFILE_TRANSACTION_NAME ="MergeSLIDProfile";
	public static final String CALLING_SYSTEM_ID_IDPCALM ="IDPCALM";
	public static final String LINK_MEMBER_METHOD =".linkMember";
	public static final String DATA_MGMT ="DATAMGT";
	public static final String INPUT_HASH_IS_NULL="Input Hash is NULL";
	public static final String RESPONSE_PROCESS_LINK_MEMBER_IS_NULL_EMPTRY="Response from processLinkMember is either null or empty";
	public static final String ERROR_RESPONSE_PROCESS_LINK_MEMBER="Error Response from processLinkMember";
	public static final String RESPONSE_QUERY_SLID_INFO_IS_NULL_EMPTY="Response from querySlidInfo is NULL or EMPTY";
	public static final String ERROR_RESPONSE_QUERY_SLID_INFO="Error Response from querySlidInfo";
	public static final String RESPONSE_QUERY_MEMBER_INFO_IS_NULL_EMPTY="Response from queryMemberInfo is NULL or EMPTY";
	public static final String ERROR_RESPONSE_QUERY_MEMBER_INFO="Error Response from queryMemberInfo";
	public static final String ADDITIONAL_SLID_DATA="additionalSlidData";
	public static final String INPUT_HASH="{}{}HLP000 : Input Hash : {}";
	public static final String PROFANITY_SCANNER_TRANSACTION_NAME ="ProfanityScanner";
	public static final String SLID_EVENTS ="slidEvents";
	public static final String UVERSE_ACCOUNT_TYPE = "uverse";
	public static final String LOG_DBTOOLS000 = "{}{}DBTOOLS000 : InpParam = {}";
	public static final String LOG_DBTOOLS999 = "{}{}DBTOOLS999 : response : {}";
	public static final String APP_INFO_INPUT_HASH_EMPTY = "Input hash is empty";

	public static final String CBR_NUMBER = "cbrNumber";
	public static final String DB_CBR_NUMBER = "cbr_number";
	public static final String CBR_RT_VALID_FLAG = "cbrRTValidFlag";
	public static final String CONTACT_ADDRESS = "contactAddress";
	public static final String DB_CONTACT_ADDRESS = "contact_address";
	public static final String DB_CBR_RTV_DATE = "cbr_rtv_date";
	public static final String NICK_NAME = "nickName";
	public static final String OWNER = "Owner";
	public static final String ACCOUNT_TYPE = "accountType";
	public static final String ACCOUNT_SUB_TYPE = "accountSubType";
	public static final String SLID_MATCHES_WITH_MEMBER_ID = "bSlidMatchesMemberId";

	public static final String DELETE_USER_TRANS_NAME = "DeleteUser";
	public static final String EMAIL_SMS_MSG = "emailsmsmsg";

    // Registration Orchestration constants
    public static final String REGISTRATION_ORCHESTRATION_TRANSACTION_NAME = "RegistrationOrchestration";
    public static final String STATUS_PARTIAL_SUCCESS = "PARTIAL_SUCCESS";
    public static final String STATUS_FAILED = "FAILED";
    public static final String VALID_CLIENT_ID_IDMREG = "IDMREG";
    public static final String VALID_CLIENT_ID_IDP = "IDP";
    public static final String SERVICE_NAME_MOBILITY = "MOBILITY";
    public static final String SERVICE_NAME_TITAN = "TITAN";
    public static final String SERVICE_NAME_ECOMM = "ECOMM";
    public static final String SERVICE_NAME_INDIVIDUAL = "INDIVIDUAL";
    public static final String SOR_NAME_MO = "MO";
    public static final String SOR_NAME_LS = "LS";
    public static final String SOR_NAME_BDS = "BDS";
    public static final String SOR_NAME_CG = "CG";
    public static final String ROLE_NAME_OWNER = "OWNER";
    public static final String SERVICE_STATUS_ENABLED = "Enabled";
    public static final String SUCCESS_CODE = "MS_MPSYS_BE_0";
    public static final String SUCCESS_MSG = "SUCCESS";
    public static final String ADD_ASSOCIATION_TRANSACTION_NAME = "AddAssociation";

    // Merge path constants
    public static final String MERGE_USER_ACCESS_ID_TRANSACTION_NAME = "MergeUserAccessId";
    public static final String FROM_USER_NAME = "fromUserName";
    public static final String TO_USER_NAME = "toUserName";

    // Observability metric name constants
    public static final String IDGRAPH_USERMANAGEMENTMS_IB = "IDGRAPH_USERMANAGEMENTMS_IB";
    public static final String IDGRAPH_USERMANAGEMENTMS_OB = "IDGRAPH_USERMANAGEMENTMS_OB";
    public static final String IDGRAPH_USERMANAGEMENTMS_SOAP_OB = "IDGRAPH_USERMANAGEMENTMS_SOAP_OB";
    public static final String IDGRAPH_USERMANAGEMENTMS_DB_ERR = "IDGRAPH_USERMANAGEMENTMS_DB_ERR";

}