package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TMEMBERSERVICEATTRIBUTE", schema = "MPS_OWNER", uniqueConstraints = @UniqueConstraint(columnNames = {
		"MEMBER_NUM", "SERVICE_ID", "SOR_ID", "SOR_INVARIANT_ID", "ATTRIBUTE_ID" }))
public class Tmemberserviceattribute implements Serializable {

	private static final long serialVersionUID = -8634939803164953376L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "memberNum", column = @Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "serviceId", column = @Column(name = "SERVICE_ID", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "sorId", column = @Column(name = "SOR_ID", precision = 22, scale = 0)),
			@AttributeOverride(name = "sorInvariantId", column = @Column(name = "SOR_INVARIANT_ID")),
			@AttributeOverride(name = "instanceId", column = @Column(name = "INSTANCE_ID", length = 24)),
			@AttributeOverride(name = "attributeId", column = @Column(name = "ATTRIBUTE_ID", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "value", column = @Column(name = "VALUE", length = 1024)),
			@AttributeOverride(name = "createDate", column = @Column(name = "CREATE_DATE", nullable = false, length = 7)),
			@AttributeOverride(name = "lastModified", column = @Column(name = "LAST_MODIFIED", nullable = false, length = 7)),
			@AttributeOverride(name = "lastModifiedBy", column = @Column(name = "LAST_MODIFIED_BY", nullable = false)) })
	private TmemberserviceattributeId id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SERVICE_ID", nullable = false, insertable = false, updatable = false)
	private Tservice tservice;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MEMBER_NUM", nullable = false, insertable = false, updatable = false)
	private Tmember tmember;
}