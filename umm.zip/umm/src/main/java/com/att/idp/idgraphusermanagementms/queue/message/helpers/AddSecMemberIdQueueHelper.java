package com.att.idp.idgraphusermanagementms.queue.message.helpers;

import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.mpsys.common.helpers.FeatureManagerHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import org.apache.commons.collections.MapUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Helper class for adding secondary member IDs to the queue.
 */
@Component
public class AddSecMemberIdQueueHelper {

    public static final Logger log = LoggerFactory.getLogger(AddSecMemberIdQueueHelper.class);

    @Autowired
    FeatureManagerHelper featureManager;

    @Autowired
    PublishMqAehHelper publishMqAehHelper;

    private String sClassName = "AddSecMemberIdQueueHelper";

    private static final String ERROR_ENUM = "ErrorEnum";

    /**
     * Sends a message to the MQ.
     *
     * @param hmInput       The input HashMap containing necessary data.
     * @param alEventData   The list of event data.
     * @param slidMemberNum The SLID member number.
     * @return A map containing the result of the operation.
     */
    public HashMap sendMessageToMQ(HashMap hmInput, ArrayList<Map<String, Object>> alEventData, String slidMemberNum, String memberNum) {
        String sMethodName = ".sendMessageToMQ.";
        String stAppInfo = null;
        String stAppStatusCode = null;
        HashMap hmResult = null;

        HashMap hmDbusInput = CommonUtil.getHashMap();

        // Add SLID events to event data if present
        if(hmInput.get("slidEvents") != null){
            ArrayList alSlidEvents = (ArrayList) hmInput.get("slidEvents");
            alEventData.addAll(alSlidEvents);
        }

        // Prepare DBus input data
        if(slidMemberNum != null)
            hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, slidMemberNum);
        else
            hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, memberNum);

        hmDbusInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
        hmDbusInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
        hmDbusInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
        hmDbusInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
        hmDbusInput.put(CommonDefs.EVENTNAME, CommonDefs.MICRO_SERVICE_EVENT);
        hmDbusInput.put(CommonDefs.MS_OPERTAION, hmInput.get(CommonDefs.TRANSACTION_NAME));
        hmDbusInput.put(CommonDefs.EVENTS_DATA, alEventData);

        //mq aeh switch
        String addSecMemberIdMQAEHEnabled = featureManager.getValue("cfg-idgraph-addsecmemberid-mq-aeh-switch");
        addSecMemberIdMQAEHEnabled = (addSecMemberIdMQAEHEnabled != null && !addSecMemberIdMQAEHEnabled.isEmpty()) ? addSecMemberIdMQAEHEnabled : "MQ";
        log.info("ixp flag addSecMemberIdMQAEHEnabled MQ AEH Value: {}", ESAPI.encoder().encodeForHTML(addSecMemberIdMQAEHEnabled));

        //clm switch
        String addSecMemberIdClmEnabled = featureManager.getValue("cfg-idgraph-addsecmemberid-notification-clm-switch");
        addSecMemberIdClmEnabled = (addSecMemberIdClmEnabled != null && !addSecMemberIdClmEnabled.isEmpty()) ? addSecMemberIdClmEnabled : "MQ";
        log.info("ixp flag addsecmemberid CLM Value: {}", ESAPI.encoder().encodeForHTML(addSecMemberIdClmEnabled));

        hmResult = (HashMap<String, Object>) publishMqAehHelper.invokeMqAEH(hmDbusInput, hmInput, alEventData, sClassName,
                sMethodName, addSecMemberIdMQAEHEnabled, addSecMemberIdClmEnabled);
        // Check if the result is empty
        if (MapUtils.isEmpty(hmResult)) {
            stAppInfo = "Null Response returned from JMSQueueSender.send";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
            log.info("{}{}ASMIDQH_03 : {}", sClassName, sMethodName, stAppInfo);
            return hmResult;
        }

        stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

        // Check if the operation was successful
        if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
            stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
            log.info("{}{}ASMIDQH_04 : {} ", sClassName, sMethodName, stAppInfo != null?HtmlUtils.htmlEscape(String.valueOf(stAppInfo)):null);
            hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
            return hmResult;
        }

        // Return success result
        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
        hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
        return hmResult;
    }
}