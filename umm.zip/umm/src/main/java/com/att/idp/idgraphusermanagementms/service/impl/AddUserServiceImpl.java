package com.att.idp.idgraphusermanagementms.service.impl;

import java.util.Map;

import jakarta.ws.rs.core.MultivaluedMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.AddUserHelper;
import com.att.idp.idgraphusermanagementms.resource.request.AddUserRequest;
import com.att.idp.idgraphusermanagementms.resource.response.AddUserResponse;
import com.att.idp.idgraphusermanagementms.service.AddUserService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This class implements the AddUserService interface and provides the implementation for adding a user to the system.
 * It is annotated with @Service to indicate that it's a Spring Bean and @Transactional to handle the transaction management.
 *
 * It contains a method addUser which takes an AddUserRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return an AddUserResponse object.
 *
 * The AddUserRequest object encapsulates the details of the user addition operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class AddUserServiceImpl implements AddUserService {

	public static final Logger logger = LoggerFactory.getLogger(AddUserServiceImpl.class);

	private static String sClassName = "AddUserServiceImpl";
	@Autowired
	private AddUserHelper addUserHelper;

	@Override
	public AddUserResponse addUser(AddUserRequest addUserRequest, MultivaluedMap<String, String> requestHeader) {

		Map<String, Object> hmResponse = null;
		String sMethodName = ".addUser.";

		Map<String, Object> hmInput = CommonUtilHelper.objectToMap(addUserRequest);

		String idpTraceid = (String) hmInput.get("idpTraceId");
		hmInput.put("dbusTransactionId", idpTraceid.split(":")[0]);
		hmInput.put("handle", (String) hmInput.remove("userId"));
		
		logger.info(SpiMarker.getInstance(),
				"AddUserServiceImpl.addUser.AUS_01 : Calling addUserHelper with Input : {}",
				StructuredArguments.entries(hmInput));

		hmResponse = addUserHelper.addUser(hmInput);

		hmResponse=CommonUtilHelper.processHmResponse(hmResponse, hmInput, "addUserHelper", ".addUser");
		hmResponse.put("idp-trace-id", addUserRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME, "AddUser");
		AddUserResponse addUserResponse = CommonUtilHelper.generateAddUserResponse(hmResponse);

		String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

		if (sTxnRollBack != null) {
			throw new InvalidInputDataException(hmResponse);
		}
		logger.info("{}{}AUS_05 : Response from AddUserServiceImpl.addUser : {}", sClassName, sMethodName,
				addUserResponse);
		return addUserResponse;
	}
	
}