package com.att.idp.idgraphusermanagementms.db.helper;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import net.logstash.logback.argument.StructuredArguments;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

@Component
public class ServiceInfoDBHelper
{
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private DBHelper dBHelper;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	private static final String info = "@(#) RcsModuleId = $Id$ $HeadURL$";

	private static String sClassName = "ServiceInfoDBHelper";
	public static final Logger logger = LoggerFactory.getLogger(ServiceInfoDBHelper.class);
	/**
	 *
	 * @param hmInput
	 * @return HashMap
	 */
	public HashMap addServiceInfo (HashMap hmInput)
	{
		String sMethodName = "addServiceInfo";

		HashMap hmResult = null;
		String stAppInfo = null;
		int sor_id = -1;
		List<Object[]> objectList = new ArrayList<Object[]>();


		String stAddServiceInfoSql = "INSERT INTO serviceinfo(" +
				"SOR_ID, " +
				"SOR_INVARIANT_ID, " +
				"FISERV_AUTH_DATE, " +
				"FISERV_ENABLED_DATE, " +
				"LAST_MODIFIED_BY " +
				") VALUES(" +
				"?, ?, (SELECT sysdate FROM DUAL where 1= ?), (SELECT sysdate FROM DUAL where 1= ?), ?)";

		String stAddServiceInfoWithAccountLockSql = "INSERT INTO serviceinfo(" +
				"SOR_ID, " +
				"SOR_INVARIANT_ID, " +
				"ACCOUNT_LOCKED, " +
				"ACCOUNT_LOCKED_REASON, " +
				"FISERV_AUTH_DATE, " +
				"FISERV_ENABLED_DATE, " +
				"LAST_MODIFIED_BY " +
				") VALUES(" +
				"?, ?, ?, ?, (SELECT sysdate FROM DUAL where 1= ?), (SELECT sysdate FROM DUAL where 1= ?), ?)";


		logger.info("{}{}SCDBH.ASC.01: CVS KEYWORDS: {}", sClassName, sMethodName, info);
		logger.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmInput));


		Date dtStart = new Date();

		try {

			if (jdbcTemplate == null) {

				stAppInfo = "Error null connection, no row inserted";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM,
						stAppInfo);
				logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_DB_NUM, sClassName,
						sMethodName, "DB_ASI_H_02", stAppInfo);
				return hmResult;

			}

			String stLastModifiedBy = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);

			if (stLastModifiedBy == null
					|| stLastModifiedBy.trim().length() == 0) {
				stAppInfo = "last_modified_by is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(
						MPSDefs.ERR_EMPTY_NUM, stAppInfo);
				logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_EMPTY_NUM, sClassName,
						sMethodName, "DB_ASI_H_03", stAppInfo);
				return hmResult;
			}


			ArrayList alServiceInfo = (ArrayList) hmInput.get(MPSDefs.DB_SERVICEINFO);
			if (alServiceInfo == null || alServiceInfo.size() <= 0) {
				stAppInfo = "serviceinfo list is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(
						MPSDefs.ERR_EMPTY_NUM, stAppInfo);
				logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_EMPTY_NUM, sClassName,
						sMethodName, "DB_ASI_H_05", stAppInfo);
				return hmResult;
			}


			logger.debug("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName, "DB_ASI_H_SQL000",
					"stAddServiceInfoWithAccountLockSql: " + stAddServiceInfoWithAccountLockSql);

			//prepStmt = jdbcTemplate.(stAddServiceInfoWithAccountLockSql);

			HashMap hmServiceInfo=null;

			//Iterate through each servicecontact to insert rows
			for (int i = 0; i < alServiceInfo.size(); i++) {
				hmServiceInfo = (HashMap) alServiceInfo.get(i);


				if (hmServiceInfo != null && !hmServiceInfo.isEmpty()) {
					List<Object> objService = new ArrayList<Object>();
					String stSorInvariantId = (String) hmServiceInfo
							.get(MPSDefs.DB_SOR_INVARIANT_ID);
					String stSorName = (String) hmServiceInfo
							.get(MPSDefs.DB_SOR_NAME);
					String stSorId = (String) hmServiceInfo
							.get(MPSDefs.DB_SOR_ID);
					String stFiservAuthDate = (String) hmServiceInfo
							.get(MPSDefs.DB_FISERV_AUTH_DATE);
					String stFiservEnabledDate = (String) hmServiceInfo
							.get(MPSDefs.DB_FISERV_ENABLED_DATE);
					String stAcctLocked = (String) hmServiceInfo
							.get(MPSDefs.DB_ACCOUNT_LOCKED);
					String stAcctLockedReason = (String) hmServiceInfo
							.get(MPSDefs.DB_ACCOUNT_LOCKED_REASON);

					//validate input
					if (stSorInvariantId == null
							|| stSorInvariantId.trim().length() <= 0) {

						stAppInfo = "sor_invariant_id is null or empty in input";
						hmResult = CommonErrorMap.makeCategoryMap(
								MPSDefs.ERR_EMPTY_NUM, stAppInfo);
						logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_EMPTY_NUM,
								sClassName, sMethodName, "DB_ASI_H_06",
								stAppInfo);
						return hmResult;
					}

					if ((stSorId == null || stSorId.trim().length() <= 0)
							&& (stSorName == null || stSorName.trim().length() <= 0)) {

						stAppInfo = "sor_id and sor_name both are null or empty in input";
						hmResult = CommonErrorMap.makeCategoryMap(
								MPSDefs.ERR_EMPTY_NUM, stAppInfo);
						logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_EMPTY_NUM,
								sClassName, sMethodName, "DB_ASI_H_07",
								stAppInfo);
						return hmResult;
					}

					if (stSorId != null && stSorId.trim().length() != 0) {
						sor_id = Integer.parseInt(stSorId);
					} else {
						sor_id = dBHelper.getSorId(stSorName);
					}

					if (sor_id == -1) {
						stAppInfo = "Input sor_name/sor_id is not valid";
						hmResult = CommonErrorMap.makeCategoryMap(
								MPSDefs.ERR_EMPTY_NUM, stAppInfo);
						logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_EMPTY_NUM,
								sClassName, sMethodName, "DB_ASI_H_08",
								stAppInfo);
						return hmResult;
					}

//					if (stAcctLocked != null && stAcctLocked.trim().length() > 0) {
//						logger.debug("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName, "DB_ASI_H_SQL000",
//								"addServiceInfoSql: " + stAddServiceInfoWithAccountLockSql);
//
//						prepStmt1 = conn.prepareStatement(stAddServiceInfoWithAccountLockSql);
//					}

					int nIndex = 0;

					objService.add(null); objService.set(nIndex++, sor_id);
					logger.debug("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName,
							"DB_ASI_H_09", "sor_id::PARAM = " + sor_id);

					objService.add(null); objService.set(nIndex++, stSorInvariantId);
					logger.debug("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName,
							"DB_ASI_H_10", "sor_invariant_id::PARAM = "
									+ stSorInvariantId);

					if (stAcctLocked != null && stAcctLocked.equalsIgnoreCase("Y"))
					{
						objService.add(null); objService.set(nIndex++, stAcctLocked);
						logger.debug("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName,
								"DB_ASI_H_11", "account_locked::PARAM = "
										+ stAcctLocked);

						objService.add(null); objService.set(nIndex++, stAcctLockedReason);
						logger.debug("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName,
								"DB_ASI_H_12", "account_locked_reason::PARAM = "
										+ stAcctLockedReason);
					}else{

						objService.add(null); objService.set(nIndex++, "N");
						logger.debug("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName,
								"DB_ASI_H_11", "account_locked::PARAM = "
										+ "N");

						objService.add(null); objService.set(nIndex++, java.sql.Types.VARCHAR);
						logger.debug("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName,
								"DB_ASI_H_12", "account_locked_reason::PARAM = "
										+ stAcctLockedReason);
					}

					if (stFiservAuthDate != null) {
						int fiserv_auth_date = Integer.parseInt(stFiservAuthDate);
						objService.add(null); objService.set(nIndex++, fiserv_auth_date);
						logger.debug("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName,
								"DB_ASI_H_13", "fiserv_auth_date::PARAM = "
										+ stFiservAuthDate);
					} else {
						objService.add(null); objService.set(nIndex++, java.sql.Types.INTEGER);
						logger.debug("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName,
								"DB_ASI_H_13", "fiserv_auth_date::PARAM = "
										+ stFiservAuthDate);
					}

					if (stFiservEnabledDate != null) {
						int fiserv_enabled_date = Integer.parseInt(stFiservEnabledDate);
						objService.add(null); objService.set(nIndex++, fiserv_enabled_date);
						logger.debug("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName,
								"DB_ASI_H_14", "fiserv_enabled_date::PARAM = "
										+ stFiservEnabledDate);
					} else {
						objService.add(null); objService.set(nIndex++, java.sql.Types.INTEGER);
						logger.debug("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName,
								"DB_ASI_H_14", "fiserv_enabled_date::PARAM = "
										+ stFiservEnabledDate);
					}

					objService.add(null); objService.set(nIndex++, stLastModifiedBy);
					logger.debug("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName,
							"DB_ASI_H_04", "last_modified_by::PARAM = "
									+ stLastModifiedBy);

					//prepStmt.addBatch();
					objectList.add(objService.toArray());

				} else {
					stAppInfo = "serviceinfo hash is null or empty in input";
					hmResult = CommonErrorMap.makeCategoryMap(
							MPSDefs.ERR_EMPTY_NUM, stAppInfo);
					logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_EMPTY_NUM, sClassName,
							sMethodName, "DB_ASI_H_15", stAppInfo);
					return hmResult;
				}
			} //end of for loop

			long tTime = 0;
			Date dtStartDate = new Date();

			//int totalRowCount[] = prepStmt.executeBatch();
			int totalRowCount[] = jdbcTemplate.batchUpdate(new String(stAddServiceInfoWithAccountLockSql), objectList);

			// Calculate the total time taken to insert rows in DB
			//to return time in milliseconds for APRIL2011-sa7153
			tTime = (System.currentTimeMillis() - dtStartDate.getTime());
			logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "QUERY999",
					"Total time taken to execute query = "
							+ tTime + " milliseconds");

			if (totalRowCount.length < alServiceInfo.size()) {
				stAppInfo = "Insert Query not executed properly";
				hmResult = CommonErrorMap.makeCategoryMap(
						CommonErrorMap.ERR_DB_NUM, stAppInfo);
				logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_DB_NUM, sClassName,
						sMethodName, "DB_ASI_H_16", stAppInfo);
				return hmResult;
			}

			hmResult = CommonErrorMap.makeCategoryMap(
					CommonDefs.COMMON_SUCCESS_NUM, "No of rows inserted:= "
							+ totalRowCount.length);

			logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DB_ASI_H_17",
					"No of rows inserted:= " + totalRowCount.length);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);

			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}AUH_117.1 : {}{}", Integer.parseInt(errorCode), sClassName,
					sMethodName, "DB_ASI_H_E2", "Error: " + e.getMessage());

			logger.error("{}{}AUH_117.1 : {}{}", Integer.parseInt(errorCode), sClassName,
					sMethodName, "DB_ASI_H_E3", "::Exception = ");

			//return hmResult;

		} finally {

			if (hmResult == null || hmResult.isEmpty()) {
				hmResult = CommonErrorMap.makeCategoryMap(
						CErrorDefs.ERR_SYS_APPL_NUM,
						"Error while inserting entry in TSERVICEINFO");
				logger.error("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_SYS_APPL_NUM, sClassName,
						sMethodName, "DB_ASI_H_18",
						"Error while inserting entry in TSERVICEINFO");
			}


			logger.info("{}{}AUH_117.1 : {}{}",sClassName, sMethodName, "DBTOOLS999", dtStart
					.getTime(), hmResult);
		}

		return hmResult;
	}

	/**
	 *
	 * @param hmInput
	 * @return HashMap
	 */
	public HashMap updateServiceInfo (HashMap hmInput)
	{
		String sMethodName = "updateServiceInfo";
		HashMap hmResult = CommonUtil.getHashMap();//new HashMap();
		PreparedStatement prepStmt = null;
		String sAppInfo = null;

		String sSorInvariantId =null;
		String sSorId = null;
		String sSorName = null;
		String sCallingSystemId = null;
		String sLastModfiedBy = null;

		String updateServiceInfoSql =
				"update SERVICEINFO set last_modified_by= ? ";

		logger.info("{}{}SCDBH.USC.01: CVS KEYWORDS: {}", sClassName, sMethodName, info);
		logger.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmInput));


		Date dtStart = new Date();

		try
		{
			if (jdbcTemplate == null) {
				return hmResult = CommonErrorMap.makeCategoryMap(
						CommonErrorMap.ERR_DB_NUM, "Error null connection, no row updated");
			}

			ArrayList alServiceInfo = (ArrayList) hmInput.get("serviceinfo");
			if (alServiceInfo == null || alServiceInfo.size() <= 0)
			{
				sAppInfo = "serviceinfo list is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(
						MPSDefs.ERR_EMPTY_NUM, sAppInfo);

				logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_EMPTY_NUM, sClassName,
						sMethodName, "DBTOOLS03", sAppInfo);
				return hmResult;
			}

			//added below  declarations as part of APRIL-2011 CAST analysis changes
			// to avoid  instantiations inside loops
			String queryArg = "";
			HashMap hmServiceInfo=null;
			if(alServiceInfo !=null && !alServiceInfo.isEmpty()){

				Iterator itServiceInfo = alServiceInfo.iterator();
				while(itServiceInfo.hasNext()){

					hmServiceInfo = (HashMap) itServiceInfo.next();

					if(hmServiceInfo != null && !hmServiceInfo.isEmpty()){
						List<Object> objService = new ArrayList<Object>();

						sSorInvariantId = (String) hmServiceInfo.get(MPSDefs.DB_SOR_INVARIANT_ID);
						sSorId = (String) hmServiceInfo.get(MPSDefs.DB_SOR_ID);
						sSorName = (String) hmServiceInfo.get(MPSDefs.DB_SOR_NAME);
						sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
						sLastModfiedBy =(String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

						//validate input arguments
						if (sSorInvariantId == null || sSorInvariantId.trim().length() <= 0 ||
								sCallingSystemId == null || sCallingSystemId.trim().length() <= 0)
						{
							hmResult = CommonErrorMap.makeCategoryMap (MPSDefs.ERR_EMPTY_NUM,
									"sor_invariant_id and/or callingSystemId is null or empty in input");
							return hmResult;
						}

						if ((sSorId == null || sSorId.trim().length() <= 0) && (sSorName == null ||
								sSorName.trim().length() <= 0 ))
						{
							hmResult = CommonErrorMap.makeCategoryMap (MPSDefs.ERR_EMPTY_NUM,
									"sor_id and sor_name both are null or empty in input");
							return hmResult;
						}

						if (sSorId == null &&  sSorName != null && sSorName.trim().length() > 0 )
						{
							int iSorIs = dBHelper.getSorId(sSorName);
							sSorId = Integer.toString(iSorIs);
						}

						//String queryArg = "";
						//SimpleDateFormat sdf = 	new SimpleDateFormat("MMddyyyy");
						//commented above line and added below line as part of APRIL-2011 CAST analysis changes
						// to avoid  instantiations inside loops
						queryArg = "";


						String stFiServAuthdate = (String) hmServiceInfo.get(MPSDefs.DB_FISERV_AUTH_DATE);
						String stFiServEnableddate = (String) hmServiceInfo.get(MPSDefs.DB_FISERV_ENABLED_DATE);
						String aAcctLocked = (String) hmServiceInfo.get(MPSDefs.DB_ACCOUNT_LOCKED);
						String aAcctLockedReason = (String) hmServiceInfo.get(MPSDefs.DB_ACCOUNT_LOCKED_REASON);

						if (aAcctLocked != null && aAcctLocked.trim().length() > 0 )
							queryArg = queryArg + ", account_locked = ?";

						if (hmServiceInfo.containsKey(MPSDefs.DB_ACCOUNT_LOCKED_REASON) )
							queryArg = queryArg + ", account_locked_reason = ?";

						if (hmServiceInfo.containsKey("fiserv_enabled_date") && hmServiceInfo.containsKey("fiserv_auth_date") )
						{
							queryArg = queryArg + ", fiserv_enabled_date = (SELECT sysdate FROM dual WHERE 1 = ?), " +
									" fiserv_auth_date = (SELECT sysdate FROM dual WHERE 1 = ?) ";
						}
						else if (hmServiceInfo.containsKey("fiserv_enabled_date") )
						{
							queryArg = queryArg + ", fiserv_enabled_date = (SELECT sysdate FROM dual WHERE 1 = ?)";

						} else if (hmServiceInfo.containsKey("fiserv_auth_date") )
						{
							queryArg = queryArg + ", fiserv_auth_date = (SELECT sysdate FROM dual WHERE 1 = ?)";
						}

						/*else {
							hmResult = CommonErrorMap.makeCategoryMap (MPSDefs.ERR_EMPTY_NUM,
								"fiserv_enabled_date and fiserv_auth_date both keys are missing, no updatable field");
							return hmResult;
						}*/

						queryArg = queryArg + " WHERE sor_invariant_id = ? AND sor_id= ?";

						logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS04",
								"Query SQL = " + updateServiceInfoSql + queryArg);

						/*if(prepStmt != null){
							prepStmt.close();
						}
						prepStmt = conn.prepareStatement(updateServiceInfoSql+queryArg);*/

						int nIndex = 0;

						objService.add(null); objService.set(nIndex++, sLastModfiedBy);

						if (aAcctLocked != null && aAcctLocked.trim().length() > 0 )
							objService.add(null); objService.set(nIndex++, aAcctLocked);

						if (hmServiceInfo.containsKey(MPSDefs.DB_ACCOUNT_LOCKED_REASON) )
							objService.add(null); objService.set(nIndex++, aAcctLockedReason);

						if (hmServiceInfo.containsKey("fiserv_enabled_date") && hmServiceInfo.containsKey("fiserv_auth_date") )
						{
							objService.add(null); objService.set(nIndex++, stFiServEnableddate);
							objService.add(null); objService.set(nIndex++, stFiServAuthdate);
						}
						else if (hmServiceInfo.containsKey("fiserv_enabled_date") ) {
							objService.add(null); objService.set(nIndex++, stFiServEnableddate);
						} else if (hmServiceInfo.containsKey("fiserv_auth_date") ) {
							objService.add(null); objService.set(nIndex++, stFiServAuthdate);
						}

						objService.add(null); objService.set(nIndex++, sSorInvariantId);
						objService.add(null); objService.set(nIndex++, sSorId);

						long tTime = 0;
						Date dtStartDate = CommonUtil.getDate();

						int rowCount = jdbcTemplate.update(new String(updateServiceInfoSql+queryArg), objService.toArray());

						//Calculate the total time taken to execute the update
						//to return time in milliseconds for APRIL2011-sa7153
						tTime = (System.currentTimeMillis() - dtStartDate.getTime());
						logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "QUERY999",
								"Total time taken to execute query = " + tTime + "milliseconds");

						logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS05",
								"No of rows updated:= " + rowCount);

						if (rowCount == 0) {
							hmResult = CommonErrorMap.makeCategoryMap (MPSDefs.REC_NOT_FOUND_NUM,
									"No Record found for given sor and sor_invariant_id");
						} else {
							hmResult = CommonErrorMap.makeCategoryMap (CommonDefs.COMMON_SUCCESS_NUM,
									"No of records updated=" + rowCount);
						}

					}

				} //end of while loop

			}

		} catch (Exception e) {

			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);

			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}AUH_117.1 : {}{}", Integer.parseInt(errorCode),
					sClassName, sMethodName, "DBTOOLS_E2", "Error: " + e.getMessage());

			logger.error("{}{}AUH_117.1 : {}{}",e, Integer.parseInt(errorCode),
					sClassName, sMethodName, "DBTOOLS_E3", "::Exception = ");

			//return hmResult;

		} finally {
			//
		}

		logger.info("{}{}AUH_117.1 : {}{}",sClassName, sMethodName, "DBTOOLS999", dtStart.getTime(), hmResult);

		return hmResult;
	}
	/**
	 *
	 * @param hmInput
	 * @return HashMap
	 */
	public HashMap removeServiceInfo(HashMap hmInput)
	{
		String sMethodName = "removeServiceInfo";
		HashMap hmResult = CommonUtil.getHashMap();//new HashMap();
		PreparedStatement prepStmt = null;
		String sAppInfo = null;

		String sSorInvariantId =null;
		String sSorId = null;
		String sSorName = null;



		String removeServiceInfoSql =
				"DELETE serviceinfo WHERE sor_invariant_id = ? ";

		logger.info("{}{}SCDBH.RSC.01: CVS KEYWORDS: {}", sClassName, sMethodName, info);
		logger.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmInput));


		Date dtStart = new Date();

		try
		{
			if (jdbcTemplate == null) {
				return hmResult = CommonErrorMap.makeCategoryMap(
						CommonErrorMap.ERR_DB_NUM, "Error null connection, no row updated");
			}

			String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
			ArrayList alServiceInfo = (ArrayList) hmInput.get("serviceinfo");

			if (alServiceInfo == null || alServiceInfo.size() <= 0) {
				sAppInfo = "serviceinfo list is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(
						MPSDefs.ERR_EMPTY_NUM, sAppInfo);
				logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_EMPTY_NUM, sClassName,
						sMethodName, "DB_RSI_H_05", sAppInfo);
				return hmResult;
			}
			HashMap hmServiceInfo=null;
			if(alServiceInfo !=null && !alServiceInfo.isEmpty()){

				Iterator itServiceInfo = alServiceInfo.iterator();
				while(itServiceInfo.hasNext()){

					hmServiceInfo = (HashMap) itServiceInfo.next();

					if(hmServiceInfo != null && !hmServiceInfo.isEmpty()){
						List<Object> objService = new ArrayList<Object>();

						//validate input arguments
						sSorInvariantId = (String) hmServiceInfo.get(MPSDefs.DB_SOR_INVARIANT_ID);
						sSorId = (String) hmServiceInfo.get(MPSDefs.DB_SOR_ID);
						sSorName = (String) hmServiceInfo.get(MPSDefs.DB_SOR_NAME);

						if (sSorInvariantId == null || sSorInvariantId.trim().length() <= 0 )
						{
							hmResult = CommonErrorMap.makeCategoryMap (MPSDefs.ERR_EMPTY_NUM,
									"sor_invariant_id is null or empty in input");
							return hmResult;
						}

						if ( ((sTransactionName != null && ! sTransactionName.equalsIgnoreCase("RemoveAccount")) ||
								sTransactionName == null) &&
								(sSorId == null || sSorId.trim().length() <= 0) && (sSorName == null ||
								sSorName.trim().length() <= 0 ))
						{
							hmResult = CommonErrorMap.makeCategoryMap (MPSDefs.ERR_EMPTY_NUM,
									"sor_id and sor_name both are null or empty in input");
							return hmResult;
						}

						String queryArg = "";

						if (sSorId != null && sSorId.trim().equalsIgnoreCase("null")) {

							sSorId= null;
						}

						if (sSorName !=null && sSorName.trim().equalsIgnoreCase("null")) {
							sSorName = null;
						}



						if ((sTransactionName != null && sTransactionName.equalsIgnoreCase("RemoveAccount")) &&
								(sSorId == null || sSorId.isEmpty()) && (sSorName == null || sSorName.isEmpty()))
						{


							logger.info("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName, "DBTOOLS04",
									"Remove SQL = " + removeServiceInfoSql);
						}else if ((sTransactionName != null && sTransactionName.equalsIgnoreCase("RemoveAccount"))&&
								((sSorId != null && !sSorId.isEmpty()) || (sSorName != null && !sSorName.isEmpty())))
						{
							if (sSorId != null && !sSorId.isEmpty()) {
								queryArg = " AND sor_id = ? ";
								/*if(prepStmt != null){
									prepStmt.close();
								}
								//prepStmt = conn.prepareStatement (removeServiceInfoSql + queryArg); */
								removeServiceInfoSql = removeServiceInfoSql + queryArg;
								objService.add(sSorId);
								//prepStmt.setString(2, sSorId);

							} else if (sSorName != null && !sSorName.isEmpty()) {
								queryArg  = " AND sor_id = (SELECT sor_id FROM systemofrecord WHERE sor_name = ?) ";
								/*if(prepStmt != null){
									prepStmt.close();
								}
								prepStmt = conn.prepareStatement (removeServiceInfoSql + queryArg);*/
								removeServiceInfoSql = removeServiceInfoSql + queryArg;
								objService.add(sSorName);
								//prepStmt.setString(2, sSorName);
							}

							logger.info("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName, "DBTOOLS04.01",
									"Remove SQL = " + removeServiceInfoSql);

						}
						else if (sSorId != null && sSorId.trim().length() != 0)
						{
							sSorId = sSorId.trim();
							queryArg = " AND sor_id = ?";

							logger.info("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName, "DBTOOLS03",
									"Remove SQL = " + removeServiceInfoSql + queryArg);

							/*if(prepStmt != null){
								prepStmt.close();
							}
							prepStmt = conn.prepareStatement (removeServiceInfoSql + queryArg);*/
							removeServiceInfoSql = removeServiceInfoSql + queryArg;
							objService.add(sSorId);
							//prepStmt.setString(2, sSorId);
						}
						else if (sSorName != null && sSorName.trim().length() != 0)
						{
							sSorName = sSorName.trim();
							queryArg  = " AND sor_id = (SELECT sor_id FROM systemofrecord WHERE sor_name = ?)";

							logger.info("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName, "DBTOOLS04",
									"Remove SQL = " + removeServiceInfoSql + queryArg);

							/*if(prepStmt != null){
								prepStmt.close();
							}
							prepStmt = conn.prepareStatement (removeServiceInfoSql + queryArg); */
							removeServiceInfoSql = removeServiceInfoSql + queryArg;
							objService.add(sSorName);
							//prepStmt.setString(2, sSorName);
						}

						objService.add(0, sSorInvariantId);

						long tTime = 0;
						Date dtStartDate = CommonUtil.getDate();

						int rowCount = jdbcTemplate.update(new String(removeServiceInfoSql), objService.toArray());

						//Calculate the total time taken to execute the update
						//to return time in milliseconds for APRIL2011-sa7153
						tTime = (System.currentTimeMillis() - dtStartDate.getTime());
						logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "QUERY999",
								"Total time taken to execute query = " + tTime + "milliseconds");

						logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS05",
								"No of rows removed:= " + rowCount);

						hmResult = CommonErrorMap.makeCategoryMap (CommonDefs.COMMON_SUCCESS_NUM,
								"No of rows removed:= " + rowCount);

					}
				}
			}

		} catch (Exception e) {

			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);

			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}AUH_117.1 : {}{}", Integer.parseInt(errorCode),
					sClassName, sMethodName, "DBTOOLS_E2", "Error: " + e.getMessage());

			logger.error("{}{}AUH_117.1 : {}{}",e, Integer.parseInt(errorCode),
					sClassName, sMethodName, "DBTOOLS_E3", "::Exception = ");

			//return hmResult;

		} finally {
			//
		}
		logger.info("{}{}AUH_117.1 : {}{}",sClassName, sMethodName, "DBTOOLS999", dtStart.getTime(), hmResult);

		return hmResult;
	}


}