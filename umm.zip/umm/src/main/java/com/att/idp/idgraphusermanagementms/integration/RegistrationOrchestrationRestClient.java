package com.att.idp.idgraphusermanagementms.integration;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.conn.ConnectTimeoutException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_OB;
import static com.att.idp.cd.observability.metrics.utils.Constants.URI;
import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.POST;
import static com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants.IDGRAPH_USERMANAGEMENTMS_OB;
import com.att.idp.http.client.RestApiClient;
import com.att.idp.http.client.config.RestTemplateBeanFactory;
import com.att.idp.idgraphusermanagementms.message.ClientExceptionMessage;
import com.att.idp.idgraphusermanagementms.utils.JsonService;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
@RefreshScope
public class RegistrationOrchestrationRestClient implements RestApiClient {

    private static final Logger logger = LoggerFactory.getLogger(RegistrationOrchestrationRestClient.class);

    private static String sClassName = "RegistrationOrchestrationRestClient";

    @Value("${apiclient.rest.idgoua.url}")
    private String propOUABaseUrl;

    @Value("${apiclient.rest.idgoua.aa.endpoint}")
    private String propAAEndpointPath;

    @Value("${apiclient.rest.default.userTypes.registered.username}")
    private String clientid;

    @Value("${apiclient.rest.default.userTypes.registered.password}")
    private String clientsecret;

    private RestTemplate restTemplate;

    @Autowired
    RegistrationOrchestrationRestClient(RestTemplateBeanFactory restTemplateBeanFactory) throws Exception {
        this.restTemplate = restTemplateBeanFactory.getObject("RegistrationOrchestrationRestClient");

    }

    /**
     * This method is a generic method which supports multiple IDP MS to MS calls.
     * It takes a HashMap as input which contains the necessary information for the rest client call.
     * The method performs the rest client call and returns a HashMap containing the response.
     * If the rest client call is successful, the response HashMap contains the response data.
     * If the rest client call fails, the response HashMap contains the error information.
     *
     * @param hmRestClientInput The HashMap containing the necessary information for the rest client call.
     * @return A HashMap containing the response from the rest client call.
     * @throws JsonProcessingException If there is an error processing the JSON.
     * @throws IOException If there is an I/O error.
     */
    @TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_OB, type = REST_OB,
            description = "call registration orchestration rest client",
            tags = {URI, "/idgraphuserassociationms/v1/association/add", METHOD, POST},
            histogram = true)
    @SuppressWarnings("unchecked")
    public Map<String, Object> callIDPRestClient(Map<String, Object> hmRestClientInput)
            throws JsonProcessingException, IOException {

        String sAppInfo = null;
        int appStatusCode = 0;
        String sMethodName = ".callRestClient.";
        logger.debug("{}{}ERC.CIDPRC.01 : Invoking RegistrationOrchestrationRestClient.callIDPRestClient :", sClassName,sMethodName);

        String sTransactionName = "AddAssociation";
        String sTransactionId = (String) hmRestClientInput.get("idpTraceId");

        Map<String, Object> jsonNode = null;
        String resourceUri = null;

        HttpHeaders reqheaders = populatingHeader(hmRestClientInput, sTransactionId);

        Map<String, Object> hmResult = new HashMap<>();

        resourceUri = getIDPContextPath(sTransactionName);

        try {
            HttpEntity<?> httpEntity = null;
            ResponseEntity<JsonNode> output = null;

            String jsonObj = JsonService.getJsonFromObject(hmRestClientInput);
            httpEntity = new HttpEntity<>(jsonObj, reqheaders);
            logger.debug(SpiMarker.getInstance(),
                    "{}{}ERC.CIDPRC.02.1 : Calling Endpoint {} with sanitized request metadata [traceId={}, payloadLength={}]",
                    StringUtils.normalizeSpace(sClassName),
                    StringUtils.normalizeSpace(sMethodName),
                    StringUtils.normalizeSpace(sTransactionName),
                    sTransactionId != null
                            ? StringUtils.normalizeSpace(HtmlUtils.htmlEscape(sTransactionId).replace('\n', '_').replace('\r', '_'))
                            : null,
                    jsonObj != null ? jsonObj.length() : 0);
            output = restTemplate.exchange(resourceUri, HttpMethod.POST, httpEntity, JsonNode.class);

            jsonNode = JsonService.getObjectFromJson(output.getBody(), HashMap.class);

            logger.info("{}{}ERC.CIDPRC.03 : Response from RegistrationOrchestrationRestClient : {}",StringUtils.normalizeSpace( sClassName), StringUtils.normalizeSpace(sMethodName),
                    jsonNode!=null ? StringUtils.normalizeSpace(jsonNode.toString()): null);

            if (HttpStatus.OK.equals(output.getStatusCode()) || HttpStatus.CREATED.equals(output.getStatusCode())) {
                Map<String, Object> hmSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
                        CommonDefs.COMMON_SUCCESS_MSG);
                hmSuccess.putAll(jsonNode);
                hmResult.putAll(hmSuccess);

            } else {
                if (null != output) {
                    logger.error(
                            "RegistrationOrchestrationRestClient.callRestClient response status code is not success. Status code: {}  ",
                            output.getStatusCode());
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EXTERNAL_SYS_NUM,
                            output.getBody().toString());
                }
            }
        } catch (Exception restClientException) {
            if (restClientException.getCause() instanceof SocketTimeoutException
                    || restClientException.getCause() instanceof ConnectTimeoutException) {
                sAppInfo = "Connection Timeout while making RestClientCall : " + sTransactionName;
                logger.info("{}{}ERC.CIDPRC.04 : Connection Timeout : {}", sClassName, sMethodName,
                        restClientException.getMessage());
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_TRAN_TIME_OUT_NUM, sAppInfo);
            }

            else if (restClientException instanceof HttpClientErrorException) {
                HttpClientErrorException excp = (HttpClientErrorException) restClientException;
                if (excp.getStatusCode().equals(HttpStatus.BAD_REQUEST) || excp.getStatusCode().equals(HttpStatus.NOT_FOUND)) {

                    logger.error("{}{}ERC.CIDPRC.04.5 : HttpClientErrorException while making RestClientCall {} : {}",
                            sClassName, sMethodName, sTransactionName, excp.getMessage());
                    ObjectMapper mapper = new ObjectMapper();
                    ClientExceptionMessage msg = mapper.readValue(excp.getResponseBodyAsString(),
                            ClientExceptionMessage.class);
                    sAppInfo = msg != null ? msg.getAppInfo() : excp.getMessage();
                    appStatusCode = msg != null ? Integer.parseInt(msg.getAppStatusCode())
                            : CErrorDefs.ERR_EXTERNAL_SYS_NUM;
                    hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, sAppInfo);
                } else {
                    sAppInfo = "Error from RestClientCall : " + sTransactionName;
                    logger.info("{}{}ERC.CIDPRC.05 : Error from RestClientCall to IDP MS {} - HttpStatusCode : {}",
                            sClassName, sMethodName, sTransactionName, excp.getRawStatusCode());
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EXTERNAL_SYS_NUM, sAppInfo);
                }
            }

            else {
                sAppInfo = "Error while making RestClientCall to IDP MS : " + restClientException.getMessage();
                logger.info("{}{}ERC.CIDPRC.06 : {} : {}", sClassName, sMethodName,
                        HtmlUtils.htmlEscape(String.valueOf(sAppInfo)), restClientException.getMessage());
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
            }
        }
        return hmResult;
    }

    /**
     * Return context path for different IDP Ms. To support any new endpoints,
     * please update the below check accordingly
     *
     * @param sTransactionName
     * @return resourceUri
     */
    private String getIDPContextPath(String sTransactionName) {

        StringBuilder resourceUri = null;
        String sAppInfo = "Calling IDP MS";

        resourceUri = new StringBuilder(propOUABaseUrl);
        resourceUri.append(propAAEndpointPath);
        logger.debug("{} {}", HtmlUtils.htmlEscape(String.valueOf(sAppInfo)), "IDGraphUserAssociationMs");

        logger.info("IDPRestClient: GetUri:{}", resourceUri);
        return  resourceUri.toString();
    }

    private HttpHeaders populatingHeader(Map<String, Object> hmInput, String straceID) {

        HttpHeaders reqheaders = new HttpHeaders();
        String sTransactionName = (String) hmInput.get("transactionName");

        reqheaders.add("Authorization",
                "Basic " + Base64.getEncoder().encodeToString((clientid + ":" + clientsecret).getBytes()));
        reqheaders.setContentType(MediaType.APPLICATION_JSON);

        if ("OrderGraph".equals(sTransactionName)) {
            reqheaders.add(CommonDefs.IDP_USER_TYPE, "registered");
            reqheaders.add("X-ATT-ClientId", "MPSYS");
        } else {
            reqheaders.add("X-ATT-ClientId", (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
        }

        return reqheaders;
    }
}
