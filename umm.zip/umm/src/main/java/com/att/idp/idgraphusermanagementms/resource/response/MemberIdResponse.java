package com.att.idp.idgraphusermanagementms.resource.response;

import com.att.idp.core.exception.ServiceError;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "MemberIdResponse")
public class MemberIdResponse {

    private MemberDetails memberId;
    private List<MemberDetails> secMemberIds;
    @JsonProperty("idp-trace-id")
    private String idpTraceId;
    private ServiceError errors;

    @JsonIgnore
    private String appStatusMsg;
    @JsonIgnore
    private String appCategoryCode;
    @JsonIgnore
    private String appStatusCode;
    @JsonIgnore
    private String appInfo;
}
