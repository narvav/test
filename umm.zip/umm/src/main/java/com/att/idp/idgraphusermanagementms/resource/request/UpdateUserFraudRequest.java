package com.att.idp.idgraphusermanagementms.resource.request;

import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class represents a request to update a user's fraud lock status in the system.
 * It contains fields for callingSystemId, transactionName, handle (userId), domain, guid, agentId, userLockLevel, userLockedReasonCode, idpTraceId, isExternalCall, and a map for unknownAttributes.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 *
 */
@Schema(name = "UpdateUserFraudLockRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class UpdateUserFraudRequest {
	
	@Size(min=1, max=20,message="CallingSystemId length is invalid|UpdateUserFraud")
	private String callingSystemId;
	
	private final String transactionName = "UpdateUserFraud";
	
	@Schema(name = "userId")
	@Size(min=1, max=127,message="userId length is invalid|UpdateUserFraud")
	@JsonProperty("userId")
	private String handle;
	
	@Schema(name = "domain")
	@Size(min=1, max=30,message="Domain length is invalid|UpdateUserFraud")
	private String domain;
	
	@Schema(name = "guid")
	@Size(min=1, max=30,message="guid length is invalid|UpdateUserFraud")
	private String guid;
	
	@Schema(name = "agentId")
    @Size(min=1, max=20,message="agentId length is invalid|UpdateUserFraud") 
    private	 String agentId;
	 
	@Schema(name = "userLockLevel")
    @NotNull(message="UserLockLevel is required in input request.|UpdateUserFraud")
	@Size(min=1,max=1,message="UserLockLevel length is invalid|UpdateUserFraud") 
	private String userLockLevel;
	
	@Schema(name = "userLockedReasonCode")
    @NotNull(message="UserLockedReasonCode is required in input request.|UpdateUserFraud")
	@Size(min=1,max=50,message="UserLockedReasonCode length is invalid |UpdateUserFraud") 
	private String userLockedReasonCode;
    
    @Schema(name = "idpTraceId")
	private String idpTraceId;
	
	protected String isExternalCall;
	
	/**
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
	 * @return Map<String,Object> The map of unknown attributes.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();
	
	
}
