package com.att.idp.idgraphusermanagementms.request.validator;

import com.att.idp.idgraphusermanagementms.message.ErrorMessages;
import com.att.idp.idgraphusermanagementms.resource.request.UpdateUserContactCBRRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdateUserContactCBRResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import jakarta.ws.rs.core.HttpHeaders;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * This class, UpdateUserContactCBRRequestvalidator, is responsible for validating the UpdateUserContactCBRRequest.
 * It checks for the presence and validity of required fields in the request, and returns an UpdateUserContactCBRResponse accordingly.
 * It is annotated with @Component, @Configuration, and @PropertySource to indicate that it's a Spring Bean,
 * to allow it to access configuration properties, and to specify the location of the properties file respectively.
 *
 * The class contains several methods, including:
 * - updateUserContactCBRReqValidator: the main method that orchestrates the validation process.
 * - updateUserContactCBRInputValidator: a method that validates the input fields in the request.
 * - generateErrorMessage: a helper method that generates an error message.
 * - UpdateUserContactCBRErrorResponse: a helper method that generates an error response.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class UpdateUserContactCBRRequestvalidator {
    @Value("${PROP_UPDATE_ACCOUNT_CONTACT_CSI}")
    private String propUpdateAccountContactCsi;

    @Value("${PROP_UPDATE_ACCOUNT_CONTACT_SOR}")
    private String getPropUpdateAccountContactSOR;

    @Value("${PROP_ALLOWED_CONTACT_STATUS}")
    private String propAllowedContactStatus;

    @Value("${PROP_CONTACT_VALIDATION_STATUS}")
    private String propContactValidationStatus;

    @Value("${PROP_ALLOWED_PHONE_NUMBER_TYPE}")
    private String propAllowedPhoneNumberType;

    @Value("${PROP_UPDATE_USER_CONTACT_CSI}")
    private String propUpdateUserContactCsi;

    @Value("${PROP_CIM_AGENT_CSI}")
    private String propCimAgentCsi;

    @Value("${PROP_ALLOWED_CONTACT_TYPE}")
    private String propContcactType;

    private static final Logger logger = LoggerFactory.getLogger(UpdateUserContactCBRRequestvalidator.class);

    private final String sClassName = "UpdateUserContactCBRRequestvalidator";

    
    /**
     * This method is responsible for validating the UpdateUserContactCBRRequest.
     * It takes HttpHeaders and UpdateUserContactCBRRequest as parameters.
     * HttpHeaders contains the request headers which may include additional information required for processing the request.
     * UpdateUserContactCBRRequest encapsulates the details of the update user contact operation to be performed.
     *
     * The method performs various checks and validations on the input parameters and returns an UpdateUserContactCBRResponse object.
     * The UpdateUserContactCBRResponse object encapsulates the result of the update user contact operation.
     *
     * @param requestHeader The HttpHeaders containing the request headers.
     * @param updateUserContactCBRRequest The UpdateUserContactCBRRequest containing the details of the update user contact operation.
     * @return UpdateUserContactCBRResponse The response of the update user contact operation.
     */
    public UpdateUserContactCBRResponse updateUserContactCBRReqValidator(HttpHeaders requestHeader, UpdateUserContactCBRRequest updateUserContactCBRRequest) {
        {

            UpdateUserContactCBRResponse updateUserContactCBRResponse = null;

            String sMethodName = ".updateUserContactCBRReqValidator.";
            String stAppInfo=null;
            String stIdpTraceId = null;
            String stXAttClientId = null;

            stIdpTraceId = CommonUtil.getTraceId(requestHeader);

    		if (stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
    			stAppInfo = "Missing or Invalid IdpTraceId";
    			return UpdateUserContactCBRErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
    		}
    			
            if (updateUserContactCBRRequest == null) {
                stAppInfo = "Input Request Parameter is NULL / Empty.";
                logger.info("{}{}UUCRV_1 :: {}", sClassName, sMethodName, stAppInfo);
                return UpdateUserContactCBRErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
            }

    		updateUserContactCBRRequest.setIdpTraceId(stIdpTraceId);

            if (requestHeader.getHeaderString("X-ATT-ClientId") != null) {
                stXAttClientId = requestHeader.getHeaderString("X-ATT-ClientId");
                logger.info("{}{}UUCRV_1.4 : Setting callingSystemId: {}", sClassName, sMethodName, StringUtils.normalizeSpace(stXAttClientId));
                updateUserContactCBRRequest.setCallingSystemId(stXAttClientId);
            }
            else {
                stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
                logger.info("{}{}UUCRV_1.5 :: {}", sClassName, sMethodName, stAppInfo);
                return UpdateUserContactCBRErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
            }

            try {
                updateUserContactCBRResponse = updateUserContactCBRInputValidator(updateUserContactCBRRequest);
                if (updateUserContactCBRResponse != null) {
                    logger.info("{}{}UUCRV_2 Response from UpdateUserContactCBRInputValidator : {}", sClassName, sMethodName,
                            updateUserContactCBRResponse);
                    return updateUserContactCBRResponse;
                }

                stAppInfo = "Input Validation Successful";
                logger.info("{}{}UUCRV_3 : {}", sClassName, sMethodName, stAppInfo);

            } catch (Exception e) {
                stAppInfo = "Exception thrown in validateInput method : "
                        + e.getMessage();
                updateUserContactCBRResponse = UpdateUserContactCBRErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo, stIdpTraceId);
                logger.info("Exception thrown in validateInput method: {}", stAppInfo);
            }
            return updateUserContactCBRResponse;
        }
    }

    private UpdateUserContactCBRResponse updateUserContactCBRInputValidator(UpdateUserContactCBRRequest updateUserContactCBRRequest) {
        String stAppInfo = null;
        String sMethodName = ".updateUserContactCBRInputValidator.";
        String stIdpTraceId = updateUserContactCBRRequest.getIdpTraceId();
        UpdateUserContactCBRResponse updateUserContactCBRResponse = null;

        Optional.ofNullable(updateUserContactCBRRequest.getGuid())
                .ifPresent(x -> updateUserContactCBRRequest.setGuid(x.trim()));
        Optional.ofNullable(updateUserContactCBRRequest.getAgentId())
                .ifPresent(x -> updateUserContactCBRRequest.setAgentId(x.trim().toLowerCase()));
        Optional.ofNullable(updateUserContactCBRRequest.getDomain())
                .ifPresent(x -> updateUserContactCBRRequest.setDomain(x.trim().toLowerCase()));
        Optional.ofNullable(updateUserContactCBRRequest.getHandle())
                .ifPresent(x -> updateUserContactCBRRequest.setHandle(x.trim().toLowerCase()));
        Optional.ofNullable(updateUserContactCBRRequest.getContactType())
                .ifPresent(x -> updateUserContactCBRRequest.setContactType(x.trim().toUpperCase()));
        Optional.ofNullable(updateUserContactCBRRequest.getPhoneNumber())
                .ifPresent(x -> updateUserContactCBRRequest.setPhoneNumber(x.trim()));
        Optional.ofNullable(updateUserContactCBRRequest.getPhoneNumberExt())
                .ifPresent(x -> updateUserContactCBRRequest.setPhoneNumberExt(x.trim()));
        Optional.ofNullable(updateUserContactCBRRequest.getPhoneNumberType())
                .ifPresent(x -> updateUserContactCBRRequest.setPhoneNumberType(x.trim().toUpperCase()));
        Optional.ofNullable(updateUserContactCBRRequest.getContactStatus())
                .ifPresent(x -> updateUserContactCBRRequest.setContactStatus(x.trim().toUpperCase()));
        Optional.ofNullable(updateUserContactCBRRequest.getSubscriptionId())
                .ifPresent(x -> updateUserContactCBRRequest.setSubscriptionId(x.trim()));
        Optional.ofNullable(updateUserContactCBRRequest.getValidationStatus())
                .ifPresent(x -> updateUserContactCBRRequest.setValidationStatus(x.trim()));

        String sCallingSystemId = updateUserContactCBRRequest.getCallingSystemId();
        String stGuid = updateUserContactCBRRequest.getGuid();
        String stUserId = updateUserContactCBRRequest.getHandle();
        String stDomain = updateUserContactCBRRequest.getDomain();
        String stContactType = updateUserContactCBRRequest.getContactType();
        String sPhoneNumber = updateUserContactCBRRequest.getPhoneNumber();
        String sPhoneNumberType = updateUserContactCBRRequest.getPhoneNumberType();
        String sAgentId = updateUserContactCBRRequest.getAgentId();
        String sIsExternalCall=updateUserContactCBRRequest.getIsExternalCall();
        String sValidationStatus = updateUserContactCBRRequest.getValidationStatus();
        String sContactStatus = updateUserContactCBRRequest.getContactStatus();

        if (stContactType == null || stContactType.isEmpty()) {
            stAppInfo = "contactType cannot be empty";
            logger.info("{}{}UUCRV_2.1{}: ", sClassName, sMethodName,stAppInfo);
            return generateErrorMessage(stAppInfo, sMethodName, stIdpTraceId);
        }
        if (sContactStatus == null  || sContactStatus.isEmpty()) {
            sContactStatus = "V";
        }

        if((!CommonUtil.parseToArray(propAllowedContactStatus, CommonDefs.VALUE_SEPARATOR_CHAR).contains(sContactStatus)))
        {
            stAppInfo = "Invalid contactStatus.";
            logger.info("{}{}UUCRV_2.2 {}:  " ,sClassName ,sMethodName,stAppInfo);
            return generateErrorMessage(stAppInfo, sMethodName, stIdpTraceId);
        }

        if ((stGuid == null || stGuid.isEmpty())
                && (stUserId == null || stUserId.isEmpty() || stDomain == null || stDomain.isEmpty())) {
            stAppInfo = "Either guid OR userId/domain must be present";
            logger.info("{}{}UUCRV_2.3 {}:  " ,sClassName ,sMethodName,stAppInfo);
            return generateErrorMessage(stAppInfo, sMethodName, stIdpTraceId);
        }
        if(sIsExternalCall == null) {
            sIsExternalCall = CommonDefs.IND_Y;
        }
        if (sIsExternalCall != null
                && !(sIsExternalCall.equalsIgnoreCase(CommonDefs.IND_Y) || sIsExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
            stAppInfo = "IsExternalCall is Invalid :: Should be Y or N";
            logger.info("{}{}UUCRV_2.4 {}:  " ,sClassName ,sMethodName,stAppInfo);
            return generateErrorMessage(stAppInfo, sMethodName, stIdpTraceId);
        }
        ArrayList alPropUpdateUserContactCSIs = CommonUtil.parseToArray(propUpdateUserContactCsi, CommonDefs.VALUE_SEPARATOR_CHAR);
        if (alPropUpdateUserContactCSIs == null && alPropUpdateUserContactCSIs.isEmpty()) {
            stAppInfo = "propUpdateUserContactCsi Property value is null or empty";
            logger.info("{}{}UUCRV_2.5 {}:  ", sClassName, sMethodName, StringUtils.normalizeSpace(stAppInfo));
            return generateErrorMessage(stAppInfo, sMethodName, stIdpTraceId);
        }

        if ((sIsExternalCall != null && sIsExternalCall.equalsIgnoreCase(CommonDefs.IND_Y))
                && (!alPropUpdateUserContactCSIs.contains(sCallingSystemId))) {
            stAppInfo = "Invalid CallingSystemId in Input";
            logger.info("{}{}UUCRV_2.6 {}:  " ,sClassName ,sMethodName,stAppInfo);
            return generateErrorMessage(stAppInfo, sMethodName, stIdpTraceId);
        }
        if (sValidationStatus.equals("7")) {
            stAppInfo = "Not currently supported validationStatus";
            logger.info("{}{}UUCRV_2.7 {}:  " ,sClassName ,sMethodName,stAppInfo);
            return generateErrorMessage(stAppInfo, sMethodName, stIdpTraceId);
        }
        if (propContactValidationStatus != null && (!propContactValidationStatus.contains(sValidationStatus))) {
            stAppInfo = "Invalid validationStatus passed in input";
            logger.info("{}{}UUCRV_2.8 {}:  " ,sClassName ,sMethodName,stAppInfo);
            return generateErrorMessage(stAppInfo, sMethodName, stIdpTraceId);
        }
        if (propCimAgentCsi != null && propCimAgentCsi.equals(sCallingSystemId)) {
            if (sAgentId == null || sAgentId.isEmpty()) {
                stAppInfo = "agentId is required for this caller";
                logger.info("{}{}UUCRV_2.9 {}:  " ,sClassName ,sMethodName,stAppInfo);
                return generateErrorMessage(stAppInfo, sMethodName, stIdpTraceId);
            }
        }
        if (stContactType.equalsIgnoreCase("SMS")) {
            if (sPhoneNumber == null || sPhoneNumber.isEmpty()) {
                stAppInfo = "PhoneNumber is required, when contact type is SMS.";
                logger.info("{}{}UUCRV_2.10 {}:  ", sClassName, sMethodName, stAppInfo);
                return generateErrorMessage(stAppInfo, sMethodName, stIdpTraceId);
            }

            if (sPhoneNumber.length() != 10) {
                stAppInfo = "PhoneNumber should be of 10 digits";
                logger.info("{}{}UUCRV_2.11 {}:  ", sClassName, sMethodName, stAppInfo);
                return generateErrorMessage(stAppInfo, sMethodName, stIdpTraceId);
            }

            if (!sPhoneNumber.matches("[0-9]+")) {
                stAppInfo = "PhoneNumber should be Numeric only";
                logger.info("{}{}UUCRV_2.12 {}:  ", sClassName, sMethodName, stAppInfo);
                return generateErrorMessage(stAppInfo, sMethodName, stIdpTraceId);
            }

            if (sPhoneNumberType == null || sPhoneNumberType.isEmpty()) {
                stAppInfo = "PhoneNumberType is required, when contact type is SMS.";
                logger.info("{}{}UUCRV_2.13 {}:  ", sClassName, sMethodName, stAppInfo);
                return generateErrorMessage(stAppInfo, sMethodName, stIdpTraceId);
            } else if (!sPhoneNumberType.equals(CommonDefs.PHONE_NUMBER_TYPE_ATTMOBILE)
                    && !sPhoneNumberType.equals(CommonDefs.PHONE_NUMBER_TYPE_MOBILE)) {
                stAppInfo = "Invalid phoneNumberType.";
                logger.info("{}{}UUCRV_2.14 {}:  ", sClassName, sMethodName, stAppInfo);
                return generateErrorMessage(stAppInfo, sMethodName, stIdpTraceId);
            }
        }
        return updateUserContactCBRResponse;
    }

    private UpdateUserContactCBRResponse generateErrorMessage(String stAppInfo, String sMethodName, String stIdpTraceId) {
        ErrorMessages errMsg = ErrorMessages.valueOf("MS_MPSYS_BE_"+CErrorDefs.ERR_INVALID_DATA_NUM);
        return CommonUtilHelper.updateUserContactCBRErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, errMsg,stIdpTraceId);
    }

    private UpdateUserContactCBRResponse UpdateUserContactCBRErrorResponse(int errSysApplNum, String stAppInfo, String stIdpTraceId) {
        Map<String, Object> hmResponse = CommonUtil.getHashMap();
        hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
        hmResponse.put("idp-trace-id", stIdpTraceId);
        hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(errSysApplNum));
        return CommonUtilHelper.generateUpdateUserContactCBRResponse(hmResponse);
    }
}