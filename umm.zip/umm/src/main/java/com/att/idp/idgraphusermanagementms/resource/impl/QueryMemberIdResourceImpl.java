package com.att.idp.idgraphusermanagementms.resource.impl;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_IB;
import static com.att.idp.cd.observability.metrics.utils.Constants.URI;
import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.GET;
import static com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants.IDGRAPH_USERMANAGEMENTMS_IB;
import com.att.idp.core.exception.ServiceException;
import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.request.validator.QueryMemberIdRequestValidator;
import com.att.idp.idgraphusermanagementms.resource.QueryMemberIdResource;
import com.att.idp.idgraphusermanagementms.resource.response.MemberIdResponse;
import com.att.idp.idgraphusermanagementms.service.QueryMemberIdService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.stereotype.Controller;
import java.sql.SQLException;
import java.util.Map;

@Controller
@OpenAPIDefinition(
        info = @Info(title="User Management",
                description="IDGraphUserManagementMs provides services that are used to perform identity specific " +
                        "operations like creating new accessId, registering a currently.com memberId, updating " +
                        "profile attributes of the existing accessId, and fraud locking access Id. This information " +
                        "gets stored in IdentityGraph database and gets provisioned/replicated to multiple systems " +
                        "e.g. HALOC, Yahoo, CG, CCR, G2 etc.\n\n\n\n.", version="0.0.1"),
        servers = {
                @Server(url="https://apporigin-dev2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/"),
                @Server(url="https://apporigin-tst2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/")
        })
public class QueryMemberIdResourceImpl implements QueryMemberIdResource {
    /**
     * Logger instance for logging events.
     */
    public static final Logger logger = LoggerFactory.getLogger(QueryMemberIdResourceImpl.class);

    @Autowired
    private QueryMemberIdRequestValidator queryMemberIdRequestValidator;

    @Autowired
    private QueryMemberIdService queryMemberIdService;

    /**
     * Handles the query for a member ID.
     * <p>
     * This method validates the request headers, invokes the service to query member ID,
     * and builds the appropriate response. It also manages exceptions and logs relevant information.
     *
     * @param headers HTTP headers from the request
     * @return Response containing the member ID information or error details
     * @throws Exception if an invalid input is detected
     */

    @TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
            description = "query member id",
            tags = {URI, "/msapi/idgraphusermanagementms/v1/memberid", METHOD, GET},
            histogram = true)
    @Override
    public Response queryMemberId(HttpHeaders headers) throws Exception{

        Map<String, Object> hmResponse = CommonUtil.getHashMap();
        MemberIdResponse memberIdResponse = null;
        String stRequestTraceId = null;
        long startTm = System.currentTimeMillis();
        Response responseObj = null;

        try {
            stRequestTraceId = CommonUtil.getTraceId(headers);
            MultivaluedMap<String, String> requestHeaders = headers.getRequestHeaders();
            memberIdResponse = queryMemberIdRequestValidator.queryMemberIdRequestValidator(headers,stRequestTraceId);
            logger.info("QMID_01 : MemberId Request Header  : {}", CommonUtilHelper.sanitizeForLog(String.valueOf(requestHeaders)));
            if (memberIdResponse == null) {
                logger.info("QMID_02 : Request Header validation is successful");
                memberIdResponse = queryMemberIdService.queryMemberId(requestHeaders,stRequestTraceId);
            }
        } catch (ServiceException e) {
            logger.error("QMID_03 : ServiceException: {}", e.getMessage());
            memberIdResponse = new MemberIdResponse();
            memberIdResponse.setIdpTraceId(stRequestTraceId);
            memberIdResponse.setErrors(e.getError());
            return Response.status(e.getHttpCode()).entity(memberIdResponse).build();
        }catch (Exception e) {
            if (e instanceof InvalidInputDataException) {
                logger.error("QMID_04 : InvalidInputDataException: {}", e.getMessage());
                throw e;
            }
            else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
            }
            else {
                hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
            }
            hmResponse.put("idp-trace-id", stRequestTraceId);
            memberIdResponse = CommonUtilHelper.generateMemberIdResponse(hmResponse);
        }
        String sTimeTaken = CommonUtilHelper.getElapsedTimeInSecs(startTm) + " seconds";
        logger.info("QMID_05 : Total time taken : {} MemberId Response : {}",sTimeTaken, memberIdResponse);

        responseObj = CommonUtilHelper.buildMSResponse(memberIdResponse);

        return responseObj;
    }
}
