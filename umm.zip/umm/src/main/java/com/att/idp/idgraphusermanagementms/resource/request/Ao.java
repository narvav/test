package com.att.idp.idgraphusermanagementms.resource.request;

import lombok.Data;

import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;

/**
 * This class is part of the com.att.idp.idgraphusermanagementms.resource.request package.
 *
 * The class is used to represent an Ao object, which contains a phoneNumber field.
 * The phoneNumber field is annotated with @NotNull and @Size, indicating that it is a required field and has a size constraint.
 *
 * The class provides a no-argument constructor, as well as getter and setter methods for the phoneNumber field.
 * It also overrides the toString method, providing a custom string representation of the object using reflection.
 */
@Data
public class Ao {

	@NotNull(message="phoneNumber is required field in input request.|ResetUserPassword")
	@Size(min=1, max=10, message="phoneNumber length is invalid|ResetUserPassword")
	protected String phoneNumber;
	
	 /**
     * This field represents a map of unknown attributes.
     *
     * The unknownAttributes map is used to store any additional attributes that are not part of the attributeName and attributeValue fields.
     * It is initialized as a new HashMap.
     *
     * The field is annotated with @JsonAnySetter and @JsonAnyGetter, allowing it to be included in JSON serialization and deserialization.
     */
    @JsonAnySetter
    @JsonAnyGetter
    public Map<String,Object> unknownAttributes = new HashMap<>();
}