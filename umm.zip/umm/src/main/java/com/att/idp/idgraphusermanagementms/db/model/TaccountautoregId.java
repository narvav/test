package com.att.idp.idgraphusermanagementms.db.model;

import java.util.Date;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.*;

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TaccountautoregId implements java.io.Serializable {

	private static final long serialVersionUID = 6256314524772224648L;

	@Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)
	private Long memberNum;

	@Column(name = "SOR_ID", nullable = false, precision = 22, scale = 0)
	private Long sorId;

	@Column(name = "SOR_INVARIANT_ID", nullable = false)
	private String sorInvariantId;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", nullable = false, length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TaccountautoregId))
			return false;
		TaccountautoregId castOther = (TaccountautoregId) other;

		return ((this.getMemberNum() == castOther.getMemberNum()) || (this.getMemberNum() != null
				&& castOther.getMemberNum() != null && this.getMemberNum().equals(castOther.getMemberNum())))
				&& ((this.getSorId() == castOther.getSorId()) || (this.getSorId() != null
				&& castOther.getSorId() != null && this.getSorId().equals(castOther.getSorId())))
				&& ((this.getSorInvariantId() == castOther.getSorInvariantId())
				|| (this.getSorInvariantId() != null && castOther.getSorInvariantId() != null
				&& this.getSorInvariantId().equals(castOther.getSorInvariantId())))
				&& ((this.getCreateDate() == castOther.getCreateDate()) || (this.getCreateDate() != null
				&& castOther.getCreateDate() != null && this.getCreateDate().equals(castOther.getCreateDate())))
				&& ((this.getLastModified() == castOther.getLastModified())
				|| (this.getLastModified() != null && castOther.getLastModified() != null
				&& this.getLastModified().equals(castOther.getLastModified())))
				&& ((this.getLastModifiedBy() == castOther.getLastModifiedBy())
				|| (this.getLastModifiedBy() != null && castOther.getLastModifiedBy() != null
				&& this.getLastModifiedBy().equals(castOther.getLastModifiedBy())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getMemberNum() == null ? 0 : this.getMemberNum().hashCode());
		result = 37 * result + (getSorId() == null ? 0 : this.getSorId().hashCode());
		result = 37 * result + (getSorInvariantId() == null ? 0 : this.getSorInvariantId().hashCode());
		result = 37 * result + (getCreateDate() == null ? 0 : this.getCreateDate().hashCode());
		result = 37 * result + (getLastModified() == null ? 0 : this.getLastModified().hashCode());
		result = 37 * result + (getLastModifiedBy() == null ? 0 : this.getLastModifiedBy().hashCode());
		return result;
	}
}