package com.att.idp.idgraphusermanagementms.helper;

import com.att.mpsys.common.utils.PropertyManager;
import com.att.idp.idgraphusermanagementms.db.helper.*;
import com.att.idp.idgraphusermanagementms.utils.RILCheckAndEncryptPasswordHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.util.HtmlUtils;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * The UpdateExtUserHelper class is a helper class that provides methods to update an external user.
 * It includes methods to validate input, interact with various DB helpers to get and update user information, and handle password changes.
 * This class is annotated with @Component, meaning it is an autodetectable Spring Bean and can be automatically wired into other components using Spring's dependency injection facilities.
 * It is also annotated with @Configuration and @PropertySource, meaning it can be used to handle specific properties from a property file.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class UpdateExtUserHelper {

    private static final Logger logger = LoggerFactory.getLogger(UpdateExtUserHelper.class);
    private final String sClassName = "UpdateExtUserHelper";
    @Autowired
    private GetMemberServicesDBHelper getMemberServicesDBHelper;

    @Autowired
    private UpdateDBHelper updateDBHelper;

    @Autowired
    private RILCheckAndEncryptPasswordHelper rilCheckAndEncryptPasswordHelper;

    @Autowired
    private GetSlidInfoDBHelper getSlidInfoDBHelper;

    @Autowired
    private FraudLockDBHelper fraudLockDBHelper;

    @Autowired
    private MemberDBHelper memberDBHelper;

    @Value("${UpdateExtUser_Input_To_DB_Keys_Mapping}")
    private String updateExtUserInputToDBKeysMapping;

    @Value("${updateExtUserForSlidAndMembers}")
    private String updateExtUserForSlidAndMembers;

    @Value("${updateExtForSlidOnly}")
    private String updateExtForSlidOnly;

    /**
     * This method is responsible for updating an external user's information.
     * It first validates the input and then performs a series of operations including getting SLID information, updating member data, and handling password changes.
     * If any of these operations fail, it returns the corresponding error.
     * If all operations are successful, it returns a success message.
     *
     * @param hmInput A HashMap containing the input parameters for the method. It should include necessary information such as transaction ID, transaction name, calling system ID, and other user details to be updated.
     * @return A HashMap containing the result of the method. It includes the application status code and other information.
     */
    @Transactional
    public HashMap<String,Object> updateExtUser(HashMap<String,Object> hmInput) {
        String sMethodName = ".updateExtUser.";
        logger.info(SpiMarker.getInstance(),"{}{}HLP000 : Input Hash :  {}", sClassName, sMethodName, hmInput);

        HashMap<String,Object> hmResult = CommonUtil.getHashMap();
        String stAppInfo = null;
        String stAppStatusCode = null;

        boolean isTransactionRollbackOnError = false;

        if (hmInput == null || hmInput.isEmpty()) {
            stAppInfo = "Input Hash is NULL";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
            logger.info("{}{}UEUH_UEU_01 : {} ", sClassName, sMethodName, stAppInfo);
            return hmResult;
        }

        try {
            String sTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);
            String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
            String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
            String sExtGuid = (String) hmInput.get(CommonDefs.EXT_GUID);
            String sUserId = (String) hmInput.get(CommonDefs.USER_ID);
            String sDomain = (String) hmInput.get(CommonDefs.DOMAIN);
            String sFirstName = (String) hmInput.get(CommonDefs.FIRST_NAME);
            String sLastName = (String) hmInput.get(CommonDefs.LAST_NAME);
            String sContactEmail = (String) hmInput.get(CommonDefs.CONTACT_EMAIL);
            String stUserUnlock = (String) hmInput.get(CommonDefs.USER_UNlOCK);

            hmResult = validateInput(hmInput);

            stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                stAppInfo = (String) hmResult.get(MPSDefs.APP_INFO);
                logger.info("{}{}UEUH_UEU_02 : {}", sClassName, sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                return hmResult;
            }

            HashMap<String,Object> hmGetInfoInp = CommonUtil.getHashMap();
            HashMap<String,Object> hmDBMemberData = CommonUtil.getHashMap();

            if (sExtGuid != null && !sExtGuid.isEmpty()) {

                ArrayList alSildMaskInp = new ArrayList();
                alSildMaskInp.add("LU");

                hmGetInfoInp.put(MPSDefs.DB_MEMBER_NUM, sExtGuid);
                hmGetInfoInp.put(MPSDefs.QUERY_SLID_INFO_FLAG, CommonDefs.DEFAULT_YES);
                hmGetInfoInp.put(MPSDefs.QUERY_LINKED_USERS_FLAG, CommonDefs.DEFAULT_YES);
                hmGetInfoInp.put(MPSDefs.QUERY_FRAUD_LOCK_FLAG, CommonDefs.DEFAULT_YES);
                hmGetInfoInp.put(CommonDefs.SLID_MASK, alSildMaskInp);

                logger.debug("{}{}UEUH_UEU_03 : Calling MPSDB_GetMemberServices_H.getMemberServices with Hash :{} ", sClassName, sMethodName, hmGetInfoInp);

                hmDBMemberData = getMemberServicesDBHelper.getMemberServices(hmGetInfoInp);

                logger.debug("{}{}UEUH_UEU_04 : Response Hash from MPSDB_GetMemberServices_H.getMemberServices : {} ", sClassName, sMethodName, hmDBMemberData);

                if (hmDBMemberData == null || hmDBMemberData.isEmpty()) {
                    stAppInfo = "GetMemberServicesDBHelper.getMemberServices returned null / empty response";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                    logger.info("{}{}UEUH_UEU_05 : {} ", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                }

                stAppStatusCode = (String) hmDBMemberData.get(CErrorDefs.COMMON_APP_STATUS_CODE);

                if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                    if (stAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
                        stAppInfo = "User Not Found in DB";
                        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
                        logger.info("{}{}UEUH_UEU_06 : {}", sClassName, sMethodName, stAppInfo);
                    } else {
                        hmResult = hmDBMemberData;
                    }
                    return hmResult;
                }

                sUserId = (String) hmDBMemberData.get(MPSDefs.DB_MEMBER_NAME);
                sDomain = (String) hmDBMemberData.get(MPSDefs.DB_DOMAIN_NAME);

                if (sUserId == null || sUserId.isEmpty() || (sDomain == null || sDomain.isEmpty())) {
                    stAppInfo = "User Not Found in DB";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
                    logger.info("{}{}UEUH_UEU_07 : {}", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                }

                String fullName = "";

                if ((sFirstName != null && !sFirstName.isEmpty()) || (sLastName != null && !sLastName.isEmpty())) {

                    if (sFirstName == null || sFirstName.isEmpty())
                        sFirstName = (String) hmDBMemberData.get(MPSDefs.DB_LC_FIRSTNAME);

                    if (sLastName == null || sLastName.isEmpty())
                        sLastName = (String) hmDBMemberData.get(MPSDefs.DB_LC_LASTNAME);

                    fullName = sFirstName + " " + sLastName;

                    hmInput.put(CommonDefs.FIRST_NAME, sFirstName);
                    hmInput.put(CommonDefs.LAST_NAME, sLastName);
                    hmInput.put(CommonDefs.FULLNAME, fullName);
                }

                if (sContactEmail != null && !sContactEmail.isEmpty() && sContactEmail.length() > 64) {
                    sContactEmail = sContactEmail.substring(0, 64);
                    hmInput.put(CommonDefs.CONTACT_EMAIL, sContactEmail);
                }

                logger.debug("{}{}UEUH_UEU_08 : Calling fieldsToBeUpdated ", sClassName, sMethodName);

                hmResult = fieldsToBeUpdated(hmInput, hmDBMemberData);

                logger.debug("{}{}UEUH_UEU_09 : Response from fieldsToBeUpdated : {} ", sClassName, sMethodName, hmResult);

                stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

                if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                    logger.info("{}{}UEUH_UEU_10 : Error returned from fieldsToBeUpdated() method :{} ", sClassName, sMethodName, hmResult);
                    return hmResult;
                }

                HashMap<String,Object> hmUpdatableFields = CommonUtil.getHashMap();
                HashMap<String,Object> hmEncryptedPasswords = CommonUtil.getHashMap();

                if (hmResult != null && !hmResult.isEmpty()) {
                    if (hmResult.containsKey("hmUpdatableFields")) {
                        hmUpdatableFields = (HashMap) hmResult.get("hmUpdatableFields");
                    }
                    if (hmResult.containsKey("hmEncryptedPasswords")) {
                        hmEncryptedPasswords = (HashMap) hmResult.get("hmEncryptedPasswords");
                    }
                }
                //[2208] SID 2022000084: Update MOUP.updateExtUser in the UserUnlock=Y only case : change by mc288e
                if ((hmUpdatableFields == null || hmUpdatableFields.isEmpty()  && (stUserUnlock == null || stUserUnlock.isEmpty() || stUserUnlock.equalsIgnoreCase(CommonDefs.IND_N)) )
                        && (hmEncryptedPasswords == null || hmEncryptedPasswords.isEmpty())) {
                    stAppInfo = "Input attributes matched existing DB values";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
                    logger.info("{}{}UEUH_UEU_11 : {}", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                }

                HashMap<String,Object> hmMemberDataSlidAndMembers = CommonUtil.getHashMap();
                HashMap hmUpdateExtUserInputToDBKeysMap = null;
                if(!(updateExtUserInputToDBKeysMapping == null && updateExtUserInputToDBKeysMapping.isEmpty())) {
                    hmUpdateExtUserInputToDBKeysMap = CommonUtil.parsePropertyToHash(updateExtUserInputToDBKeysMapping);
                }
                logger.info("{}{}UEUH_UEU_12 : Property updateExtUserInputToDBKeysMapping : {} ", sClassName, sMethodName, hmUpdateExtUserInputToDBKeysMap);

                ArrayList alUpdateForSlidAndMembers = CommonUtil.parseToArray(updateExtUserForSlidAndMembers, CommonDefs.VALUE_SEPARATOR_CHAR);

                logger.info("{}{}UEUH_UEU_13 : Property updateExtUserForSlidAndMembers : {} ", sClassName, sMethodName, alUpdateForSlidAndMembers);

                if (alUpdateForSlidAndMembers != null && !alUpdateForSlidAndMembers.isEmpty()) {
                    for (Object alUpdateForSlidAndMember : alUpdateForSlidAndMembers) {
                        String fieldName = (String) alUpdateForSlidAndMember;
                        if (hmUpdatableFields.containsKey(fieldName)) {
                            String fieldValue = (String) hmUpdatableFields.get(fieldName);
                            if (fieldValue != null && !fieldValue.trim().isEmpty()) {
                                String stDBfieldName = (String) hmUpdateExtUserInputToDBKeysMap.get(fieldName);
                                hmMemberDataSlidAndMembers.put(stDBfieldName, fieldValue);
                            }
                        }
                    }
                }

                // Get hmSlidInfo for access id
                HashMap<String,Object> hmSlidInfo = (HashMap) hmDBMemberData.get(MPSDefs.KEY_SLID_INFO);

                if (hmMemberDataSlidAndMembers != null && !hmMemberDataSlidAndMembers.isEmpty()) {

                    hmMemberDataSlidAndMembers.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);

                    if (hmSlidInfo != null && !hmSlidInfo.isEmpty()) {
                        hmMemberDataSlidAndMembers.put(MPSDefs.DB_SLID_MEMBER_NUM, hmSlidInfo.get(MPSDefs.DB_SLID_MEMBER_NUM));

                        logger.debug("{}{}UEUH_UEU_14 : Calling to UpdateDBHelper.updateMemberBySlidMemberNum with HashMap = {}", sClassName, sMethodName, hmMemberDataSlidAndMembers);

                        hmResult = updateDBHelper.updateMemberBySlidMemberNum(hmMemberDataSlidAndMembers);

                        logger.debug("{}{}UEUH_UEU_15 : Response Hash from UpdateDBHelper.updateMemberBySlidMemberNum is = {}", sClassName, sMethodName, hmResult);

                        stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
                        if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                            logger.info("{}{}UEUH_UEU_16 : Error returned from UpdateDBHelper.updateMemberBySlidMemberNum :{} ", sClassName, sMethodName, hmResult);
                            return hmResult;
                        } else {
                            isTransactionRollbackOnError = true;
                        }

                    } else {
                        hmMemberDataSlidAndMembers.put(MPSDefs.DB_MEMBER_NUM, hmDBMemberData.get(MPSDefs.DB_MEMBER_NUM));

                        logger.debug("{}{}UEUH_UEU_17 : Calling to MemberDBHelper.update with HashMap = {}", sClassName, sMethodName, hmMemberDataSlidAndMembers);

                        hmResult = memberDBHelper.update(hmMemberDataSlidAndMembers);

                        logger.debug("{}{}UEUH_UEU_18 : Response Hash from MemberDBHelper.update is = {}", sClassName, sMethodName, hmResult);

                        stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

                        if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                            logger.info("{}{}UEUH_UEU_19 : Error returned from MemberDBHelper.update : {}", sClassName, sMethodName, hmResult);
                            return hmResult;
                        } else {
                            isTransactionRollbackOnError = true;
                        }
                    }
                }

                HashMap<String,Object> hmMemberDataSlidOnly = CommonUtil.getHashMap();
                ArrayList alUpdateExtForSlidOnly = CommonUtil.parseToArray(updateExtForSlidOnly, CommonDefs.VALUE_SEPARATOR_CHAR);
                logger.info("{}{}UEUH_UEU_20 : Property updateExtForSlidOnly : {} ", sClassName, sMethodName, alUpdateExtForSlidOnly);

                for (Object oAlUpdateExtForSlidOnly : alUpdateExtForSlidOnly) {
                    String fieldName = (String) oAlUpdateExtForSlidOnly;
                    if (hmUpdatableFields.containsKey(fieldName)) {
                        String fieldValue = (String) hmUpdatableFields.get(fieldName);
                        if (fieldValue != null && !fieldValue.trim().isEmpty()) {
                            String stDBfieldName = (String) hmUpdateExtUserInputToDBKeysMap.get(fieldName);
                            hmMemberDataSlidOnly.put(stDBfieldName, fieldValue);
                        }
                    }
                }

                if (hmMemberDataSlidOnly != null && !hmMemberDataSlidOnly.isEmpty()) {
                    HashMap<String,Object> hmMPSInput = CommonUtil.getHashMap();
                    ArrayList alMemberData = CommonUtil.getArrayList();

                    hmMemberDataSlidOnly.put(MPSDefs.DB_MEMBER_NUM, hmDBMemberData.get(CommonDefs.DB_MEMBER_NUM));
                    hmMemberDataSlidOnly.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);
                    hmMemberDataSlidOnly.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);
                    alMemberData.add(hmMemberDataSlidOnly);

                    hmMPSInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                    hmMPSInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
                    hmMPSInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
                    hmMPSInput.put(MPSDefs.DB_MEMBER_TABLE, alMemberData);

                    logger.debug("{}{}UEUH_UEU_21 : Calling to MemberDBHelper.processData with HashMap = {}", sClassName, sMethodName, hmMPSInput);

                    hmResult = memberDBHelper.processData(hmMPSInput);

                    logger.debug("{}{}UEUH_UEU_22 : Response Hash from MemberDBHelper.processData is = {}", sClassName, sMethodName, hmResult);

                    stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
                    if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                        logger.info("{}{}UEUH_UEU_23 : Error returned from MemberDBHelper.processData : {}", sClassName, sMethodName, hmResult);
                        return hmResult;
                    } else {
                        isTransactionRollbackOnError = true;
                    }

                    if (hmMemberDataSlidOnly.containsKey(MPSDefs.DB_MEMBER_NAME)) {
                        HashMap<String,Object> hmGrpInput = CommonUtil.getHashMap();
                        hmGrpInput.put(MPSDefs.DB_PARENT_NAME, hmMemberDataSlidOnly.get(MPSDefs.DB_MEMBER_NAME));
                        hmGrpInput.put(MPSDefs.DB_GROUP_NUM,hmSlidInfo.get(MPSDefs.DB_GROUP_NUM));
                        hmGrpInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
                        hmGrpInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                        hmGrpInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
                        hmGrpInput.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);

                        // updating groupInfo by calling MPSDB_Update_H.updateMemberGroup
                        logger.info("{}{}UEUH_UEU_24 : Calling UpdateDBHelper.updateMemberGroup with HashMap = {}",sClassName,sMethodName,hmGrpInput);
                        hmResult = updateDBHelper.updateMemberGroup(hmGrpInput);
                        logger.debug("{}{}UEUH_UEU_25 : Response from UpdateDBHelper.updateMemberGroup = {}",sClassName,sMethodName,hmResult);

                        stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
                        if (stAppStatusCode != null && !(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                            logger.info("{}{}UEUH_UEU_26 : Error returned from UpdateDBHelper.updateMemberGroup : {}",sClassName,sMethodName,hmResult);
                            return hmResult;
                        } else {
                            isTransactionRollbackOnError = true;
                        }
                    }
                }

                // Update Password
                if (hmEncryptedPasswords != null && !hmEncryptedPasswords.isEmpty()) {

                    logger.info("{}{}UEUH_UEU_27 : Calling processChangePassword with Input Hash : {}", sClassName, sMethodName, hmInput);

                    hmResult = processChangePassword(hmInput, hmDBMemberData, hmSlidInfo, hmEncryptedPasswords);

                    logger.info("{}{}UEUH_UEU_28 : Response from processChangePassword  : {}", sClassName, sMethodName, hmResult);

                    stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

                    if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                        stAppInfo = "Error returned from processChangePassword";
                        logger.info("{}{}UEUH_UEU_29 :  {}", sClassName, sMethodName, stAppInfo);
                        hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                        return hmResult;
                    } else {
                        isTransactionRollbackOnError = true;
                    }

                }
                // [2207][SPTAUTHREG-10852] FN Fraud � Enhance MOUP.updateExtUser to remove
                // userfraud lock if the userUnlock set to Y in the Request : Change by mc288e

                if (StringUtils.isNotBlank(stUserUnlock) && stUserUnlock.equalsIgnoreCase(CommonDefs.IND_Y)) {

                    HashMap<String,Object> hmSlidInfoForFraudLocks = null;
                    String sSlidMemberNum = (String) hmDBMemberData.get(MPSDefs.DB_SLID_MEMBER_NUM);
                    hmInput.put(MPSDefs.DB_SLID_MEMBER_NUM, sSlidMemberNum);

                    if (sDomain != null && !sDomain.equals(CommonDefs.SLID_DUM) && hmDBMemberData != null
                            && hmDBMemberData.containsKey(MPSDefs.KEY_SLID_INFO)) {
                        hmSlidInfoForFraudLocks = (HashMap) hmDBMemberData.get(MPSDefs.KEY_SLID_INFO);
                    } else if (sDomain != null && sDomain.equals(CommonDefs.SLID_DUM)) {
                        hmSlidInfoForFraudLocks = hmDBMemberData;
                    }

                    if (hmSlidInfoForFraudLocks != null && !hmSlidInfoForFraudLocks.isEmpty()
                            && hmSlidInfoForFraudLocks.get(MPSDefs.DB_USER_LOCK_LEVEL) != null
                            && sSlidMemberNum != null) {
                        logger.info("{}{}UEUH_UEU_30 : Calling removeUserFraudLockLevel with Input Hash : {}",
                                sClassName, sMethodName, hmInput);

                        hmResult = removeUserFraudLockLevel(hmSlidInfoForFraudLocks, hmInput);

                        logger.info("{}{}UEUH_UEU_31 : Response from removeUserFraudLockLevel  : {}", sClassName,
                                sMethodName, hmResult);

                        stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                        if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                            logger.info("{}{}UEUH_UEU_32 :  {}", sClassName, sMethodName, hmResult);
                            return hmResult;
                        } else {
                            isTransactionRollbackOnError = true;
                        }
                    }
                }
                // end
                stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

                if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                    stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
                    logger.info("{}{}UEUH_UEU_33 : {} ", sClassName, sMethodName, StringUtils.normalizeSpace(stAppInfo));
                    hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                    return hmResult;
                } else {
                    isTransactionRollbackOnError = true;
                }
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
            }
        } catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e);
            stAppInfo = "Exception thrown updateExtUser method : " + hmResult;
            logger.error("{}{}UEUH_UEU_34 :  {} ", sClassName, sMethodName, stAppInfo);
            return hmResult;
        } finally {
            stAppInfo = "Response from updateExtUser = " + hmResult;
            logger.info("{}{}UEUH_UEU_35:  {} ", sClassName, sMethodName, StringUtils.normalizeSpace(stAppInfo));

            String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);

            if (isTransactionRollbackOnError && sAppCategoryCode != null
                    && !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
                hmResult.put("isTransactionRollback", "Y");
            }
            logger.info("{}{}HLP999 : response from UpdateExtUser{} ", sClassName, sMethodName, hmResult);
        }
        return hmResult;
    }

    /**
     * This method is responsible for removing the fraud lock level of a user.
     * It first checks if the user has a fraud lock level of 2, if so, it returns an error.
     * If the user has a fraud lock level of 1, it prepares the necessary data and calls the FraudLockDBHelper's processData method to remove the fraud lock.
     * If the processData method returns an error, it is returned to the caller.
     * If the processData method is successful, the method returns a success message.
     *
     * @param hmSlidInfoForFraudLocks A HashMap containing the SLID information for fraud locks. It should include necessary information such as user lock level.
     * @param hmInput A HashMap containing the input parameters for the method. It should include necessary information such as transaction ID, transaction name, calling system ID, and other user details to be updated.
     * @return A HashMap containing the result of the method. It includes the application status code and other information.
     */
    public HashMap removeUserFraudLockLevel(HashMap<String, Object> hmSlidInfoForFraudLocks, HashMap<String, Object> hmInput) {
        String sMethodName = ".removeUserFraudLockLevel.";
        ArrayList<Object> alUserFraudLock = null;
        HashMap hmResult = null;

        String sUserLockLevel = (String) hmSlidInfoForFraudLocks.get(MPSDefs.DB_USER_LOCK_LEVEL);
        if (CommonDefs.USER_LOCK_LEVEL_TWO.equals(sUserLockLevel)) {
            String stAppInfo = "User Fraud lock 2 exists";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_FRAUD_LOCKED_NUM, stAppInfo);
            logger.info(sClassName + sMethodName + "UEUH_RUFLL_01 : " + stAppInfo);
            return hmResult;
        } else if (CommonDefs.USER_LOCK_LEVEL_ONE.equals(sUserLockLevel)) {
            HashMap<String, Object> hmUserFraudLock = CommonUtil.getHashMap();
            hmUserFraudLock.put(MPSDefs.DB_MEMBER_NUM, hmInput.get(MPSDefs.DB_SLID_MEMBER_NUM));
            hmUserFraudLock.put(MPSDefs.DB_USER_LOCK_LEVEL, null);
            hmUserFraudLock.put(MPSDefs.DB_USER_LOCK_REASON, null);
            hmUserFraudLock.put(MPSDefs.DB_FRAUD_AGENT, null);
            hmUserFraudLock.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);
            hmUserFraudLock.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
            alUserFraudLock = CommonUtil.getArrayList();
            alUserFraudLock.add(hmUserFraudLock);
        }

        if (alUserFraudLock != null && !alUserFraudLock.isEmpty()) {
            HashMap<String,Object> hmMPSInput = CommonUtil.getHashMap();
            hmMPSInput.put(MPSDefs.DB_USERFRAUDLOCK, alUserFraudLock);

            logger.info(sClassName + sMethodName + "UEUH_RUFLL_02 : Calling to FraudLockDBHelper.processData with HashMap = " + hmMPSInput);
            hmResult = fraudLockDBHelper.processData(hmMPSInput);
            logger.info(sClassName + sMethodName + "UEUH_RUFLL_03 : Response Hash from FraudLockDBHelper.processData is = " + hmResult);
        }
        if (hmResult != null) {
            String sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
            if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
                logger.info(sClassName + sMethodName  + "UEUH_RUFLL_04 : Error returned from MPSDB_FraudLock_H.processData : " + hmResult);
                return hmResult;
            }
        } else {
            String sAppInfo = "null response from FraudLockDBHelper.processData";
            logger.info(sClassName + sMethodName + "UEUH_RUFLL_05" + sAppInfo);
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
        }
        return hmResult;
    }

    /**
     * This method is responsible for validating the input parameters for the update external user operation.
     * It checks if the user ID, user unlock status, and other necessary parameters are valid and in the correct format.
     * If any of the parameters are invalid, it returns an error.
     * If all parameters are valid, it returns a success message.
     *
     * @param hmInput A HashMap containing the input parameters for the method. It should include necessary information such as user ID, user unlock status, and other user details to be updated.
     * @return A HashMap containing the result of the method. It includes the application status code and other information.
     */
    public HashMap<String,Object> validateInput(HashMap<String,Object> hmInput) {
        String sMethodName = ".validateInput.";
        HashMap hmResult = CommonUtil.getHashMap();
        String stAppInfo = null;

        try {
            String sUserId = (String) hmInput.get(CommonDefs.USER_ID);
            String sUserUnlock = (String) hmInput.get(CommonDefs.USER_UNlOCK);

            //SID#2022000015:Change by pm675e: Validating UserId
            if (StringUtils.isNotBlank(sUserId)) {
                logger.info(SpiMarker.getInstance(),"{}{}UEUH_VI_01 : calling getSlidInfo with input : {}", sClassName, sMethodName, hmInput);

                HashMap hmGetSlidResp = getSlidInfo(hmInput);

                logger.info("{}{}UEUH_VI_02 : Response from getSlidInfo : {}", sClassName, sMethodName, hmResult);

                if (hmGetSlidResp == null || hmGetSlidResp.isEmpty()) {
                    stAppInfo = "Null Response returned from getSlidInfo";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                    logger.info("{}{}UEUH_VI_03 : {}", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                }

                String stAppStatusCode = (String) hmGetSlidResp.get(MPSDefs.APP_STATUS_CODE);

                if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
                    HashMap hmSlidInfo = (HashMap) hmGetSlidResp.get(CommonDefs.KEY_SLID_INFO);
                    String stGuid = (String) hmSlidInfo.get(MPSDefs.DB_MEMBER_NUM);

                    if (!hmInput.get(CommonDefs.EXT_GUID).equals(stGuid)) {
                        stAppInfo = "Input userId already exist as an accessId in MPSYS, so cannot update to this guid";
                        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                        logger.info("{}{}UEUH_VI_04 : {}", sClassName, sMethodName, stAppInfo);
                        return hmResult;
                    }
                }
            }
            // End
            // [2207][SPTAUTHREG-10852] : Change by mc288e: Validating userUnlock
            if (StringUtils.isNotBlank(sUserUnlock) && !(sUserUnlock.equalsIgnoreCase(CommonDefs.IND_Y) || sUserUnlock.equalsIgnoreCase(CommonDefs.IND_N))) {
                stAppInfo = "userUnlock is Invalid :: Should be Y or N";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                logger.info("{}{}UEUH_VI_05 : {} ", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }
            // End

            stAppInfo = "Input Validation Successful";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
            logger.info("{}{}UEUH_VI_06 : {} ", sClassName, sMethodName, stAppInfo);

        } catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e);
            stAppInfo = "Exception thrown validateInput method : " + hmResult;
            logger.error("{}{}UEUH_VI_07 : {} ", sClassName, sMethodName, stAppInfo);
            return hmResult;
        }
        return hmResult;
    }

    private HashMap<String,Object> getSlidInfo(HashMap<String,Object> hmInput) {
        String sMethodName = ".getSlidInfo.";
        HashMap<String, Object> hmGetSlidReq = new HashMap<>();
        HashMap<String, Object> hmResult = new HashMap<>();
        hmGetSlidReq.put(CommonDefs.TRANSACTION_NAME, (String) hmInput.get(CommonDefs.TRANSACTION_NAME));
        hmGetSlidReq.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(CommonDefs.TRANSACTION_ID));
        hmGetSlidReq.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
        hmGetSlidReq.put(CommonDefs.SLID, hmInput.get(CommonDefs.USER_ID));

        logger.info("{}{}UEUH_GSI_01 :Input to GetSlidInfoDBHelper.getSlidInfo: {}", sClassName, sMethodName, hmGetSlidReq);
        hmResult = getSlidInfoDBHelper.getSlidInfo(hmGetSlidReq);
        logger.debug("{}{}UEUH_GSI_02 :Response from GetSlidInfoDBHelper.getSlidInfo: {}", sClassName, sMethodName, hmResult);

        return hmResult;
    }

    /**
     * This method is responsible for determining which fields need to be updated based on the input parameters and the current data in the database.
     * It compares the input parameters with the current data in the database and adds the fields that need to be updated to a HashMap.
     * If the password needs to be updated, it also adds the encrypted passwords to a separate HashMap.
     * If all operations are successful, it returns a success message along with the HashMaps of updatable fields and encrypted passwords.
     *
     * @param hmInput A HashMap containing the input parameters for the method. It should include necessary information such as user ID, user unlock status, and other user details to be updated.
     * @param hmDBMemberData A HashMap containing the current data in the database for the user. It should include necessary information such as user ID, user unlock status, and other user details.
     * @return A HashMap containing the result of the method. It includes the application status code and other information. It also includes the HashMaps of updatable fields and encrypted passwords if applicable.
     */
    public HashMap<String,Object> fieldsToBeUpdated(HashMap<String,Object> hmInput, HashMap<String,Object> hmDBMemberData) {
        String sMethodName = ".fieldsToBeUpdated.";

        HashMap hmResult = null;
        String stAppInfo = null;
        String stAppStatusCode = null;

        try {
            HashMap<String,Object> hmUpdatableFields = CommonUtil.getHashMap();
            HashMap<String,Object> hmEncryptedPasswords = CommonUtil.getHashMap();

            if (StringUtils.isNotBlank((String) hmInput.get(CommonDefs.FIRST_NAME))) {
                if (StringUtils.isBlank((String) hmDBMemberData.get(MPSDefs.DB_LC_FIRSTNAME))
                        || !(StringUtils.equalsIgnoreCase((String) hmInput.get(CommonDefs.FIRST_NAME),
                        (String) hmDBMemberData.get(MPSDefs.DB_LC_FIRSTNAME)))) {

                    hmUpdatableFields.put(CommonDefs.FIRST_NAME, (String) hmInput.get(CommonDefs.FIRST_NAME));

                }
            }

            if (StringUtils.isNotBlank((String) hmInput.get(CommonDefs.LAST_NAME))) {
                if (StringUtils.isBlank((String) hmDBMemberData.get(MPSDefs.DB_LC_LASTNAME))
                        || !(StringUtils.equalsIgnoreCase((String) hmInput.get(CommonDefs.LAST_NAME),
                        (String) hmDBMemberData.get(MPSDefs.DB_LC_LASTNAME)))) {

                    hmUpdatableFields.put(CommonDefs.LAST_NAME, (String) hmInput.get(CommonDefs.LAST_NAME));

                }
            }

            if (hmUpdatableFields.containsKey(CommonDefs.FIRST_NAME)
                    || hmUpdatableFields.containsKey(CommonDefs.LAST_NAME)) {
                hmUpdatableFields.put(CommonDefs.FULLNAME, (String) hmInput.get(CommonDefs.FULLNAME));
            }

            if (StringUtils.isNotBlank((String) hmInput.get(CommonDefs.LINKED_FN_USER_ID))) {
                if (StringUtils.isBlank((String) hmDBMemberData.get(CommonDefs.DB_FN_LINKED_USERID))
                        || !(StringUtils.equalsIgnoreCase((String) hmInput.get(CommonDefs.LINKED_FN_USER_ID),
                        (String) hmDBMemberData.get(CommonDefs.DB_FN_LINKED_USERID)))) {

                    hmUpdatableFields.put(CommonDefs.LINKED_FN_USER_ID,
                            (String) hmInput.get(CommonDefs.LINKED_FN_USER_ID));

                }
            }

            if (StringUtils.isNotBlank((String) hmInput.get(CommonDefs.LINKED_FN_USER_STATUS))) {
                if (StringUtils.isBlank((String) hmDBMemberData.get(CommonDefs.DB_FN_LINKED_STATUS))
                        || !(StringUtils.equalsIgnoreCase((String) hmInput.get(CommonDefs.LINKED_FN_USER_STATUS),
                        (String) hmDBMemberData.get(CommonDefs.DB_FN_LINKED_STATUS)))) {

                    hmUpdatableFields.put(CommonDefs.LINKED_FN_USER_STATUS,
                            (String) hmInput.get(CommonDefs.LINKED_FN_USER_STATUS));

                }
            }

            if (StringUtils.isNotBlank((String) hmInput.get(CommonDefs.USER_ID))) {
                if (StringUtils.isNotBlank((String) hmDBMemberData.get(MPSDefs.DB_MEMBER_NAME))
                        && StringUtils.equalsIgnoreCase((String) hmInput.get(CommonDefs.USER_ID),
                        (String) hmDBMemberData.get(MPSDefs.DB_MEMBER_NAME))
                        && StringUtils.isNotBlank((String) hmInput.get(CommonDefs.ACCESS_ID_RTV_VALID_FLAG))
                        && StringUtils.equalsIgnoreCase((String) hmInput.get(CommonDefs.ACCESS_ID_RTV_VALID_FLAG),
                        CommonDefs.IND_Y)
                        && StringUtils.isBlank((String) hmDBMemberData.get(CommonDefs.DB_ACCESS_ID_RTV_DATE))) {

                    hmUpdatableFields.put(CommonDefs.ACCESS_ID_RTV_VALID_FLAG,
                            (String) hmInput.get(CommonDefs.ACCESS_ID_RTV_VALID_FLAG));

                }

                if (StringUtils.isNotBlank((String) hmDBMemberData.get(MPSDefs.DB_MEMBER_NAME))
                        && !(StringUtils.equalsIgnoreCase((String) hmInput.get(CommonDefs.USER_ID),
                        (String) hmDBMemberData.get(MPSDefs.DB_MEMBER_NAME)))) {

                    hmUpdatableFields.put(CommonDefs.USER_ID, (String) hmInput.get(CommonDefs.USER_ID));

                    if (StringUtils.isNotBlank((String) hmInput.get(CommonDefs.ACCESS_ID_RTV_VALID_FLAG))
                            && StringUtils.equalsIgnoreCase((String) hmInput.get(CommonDefs.ACCESS_ID_RTV_VALID_FLAG),
                            CommonDefs.IND_Y)) {

                        hmUpdatableFields.put(CommonDefs.ACCESS_ID_RTV_VALID_FLAG,
                                (String) hmInput.get(CommonDefs.ACCESS_ID_RTV_VALID_FLAG));

                    } else {
                        hmUpdatableFields.put(CommonDefs.ACCESS_ID_RTV_VALID_FLAG, CommonDefs.IND_N);
                    }
                }
            }

            if (StringUtils.isNotBlank((String) hmInput.get(CommonDefs.CONTACT_EMAIL))) {
                if (StringUtils.isNotBlank((String) hmDBMemberData.get(MPSDefs.DB_CONTACT_EMAIL))
                        && StringUtils.equalsIgnoreCase((String) hmInput.get(CommonDefs.CONTACT_EMAIL),
                        (String) hmDBMemberData.get(MPSDefs.DB_CONTACT_EMAIL))
                        && StringUtils.isNotBlank((String) hmInput.get(CommonDefs.CONTACT_EMAIL_RTV_FLAG))
                        && StringUtils.equalsIgnoreCase((String) hmInput.get(CommonDefs.CONTACT_EMAIL_RTV_FLAG),
                        CommonDefs.IND_Y)
                        && StringUtils.isBlank((String) hmDBMemberData.get(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE))) {

                    hmUpdatableFields.put(CommonDefs.CONTACT_EMAIL_RTV_FLAG,
                            (String) hmInput.get(CommonDefs.CONTACT_EMAIL_RTV_FLAG));

                }

                if (StringUtils.isBlank((String) hmDBMemberData.get(MPSDefs.DB_CONTACT_EMAIL))
                        || !(StringUtils.equalsIgnoreCase((String) hmInput.get(CommonDefs.CONTACT_EMAIL),
                        (String) hmDBMemberData.get(MPSDefs.DB_CONTACT_EMAIL)))) {

                    hmUpdatableFields.put(CommonDefs.CONTACT_EMAIL, (String) hmInput.get(CommonDefs.CONTACT_EMAIL));
                    hmUpdatableFields.put(CommonDefs.PREVIOUS_CONTACT_EMAIL,
                            (String) hmDBMemberData.get(CommonDefs.DB_CONTACT_EMAIL));

                    if (StringUtils.isNotBlank((String) hmInput.get(CommonDefs.CONTACT_EMAIL_RTV_FLAG))
                            && StringUtils.equalsIgnoreCase((String) hmInput.get(CommonDefs.CONTACT_EMAIL_RTV_FLAG),
                            CommonDefs.IND_Y)) {

                        hmUpdatableFields.put(CommonDefs.CONTACT_EMAIL_RTV_FLAG,
                                (String) hmInput.get(CommonDefs.CONTACT_EMAIL_RTV_FLAG));

                    } else {
                        hmUpdatableFields.put(CommonDefs.CONTACT_EMAIL_RTV_FLAG, CommonDefs.IND_N);
                    }
                }
            }

            if (StringUtils.isNotBlank((String) hmInput.get(CommonDefs.PASSWORD_CLEAR))) {

                HashMap<String, Object> hmCheckAndEncryptInput = CommonUtil.getHashMap();

                hmCheckAndEncryptInput.put(MPSDefs.WS_TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
                hmCheckAndEncryptInput.put(MPSDefs.WS_TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
                hmCheckAndEncryptInput.put(MPSDefs.WS_CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
                hmCheckAndEncryptInput.put(MPSDefs.WS_CLEAR_TEXT, hmInput.get(CommonDefs.PASSWORD_CLEAR));
                hmCheckAndEncryptInput.put(MPSDefs.WS_USER_ID, hmDBMemberData.get(MPSDefs.DB_MEMBER_NAME));
                hmCheckAndEncryptInput.put(MPSDefs.WS_DOMAIN, hmDBMemberData.get(MPSDefs.DB_DOMAIN_NAME));
                hmCheckAndEncryptInput.put(CommonDefs.SKIP_PASSWORD_VALIDATION, CommonDefs.IND_Y);

                logger.debug("{}{}UEUH_FTBU_01 : Calling RILCheckAndEncryptPasswordHelper.checkAndEncryptPassword with inputHash : {}", sClassName,
                        sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmCheckAndEncryptInput)));

                hmResult = rilCheckAndEncryptPasswordHelper.checkAndEncryptPassword(hmCheckAndEncryptInput);

                logger.debug("{}{}UEUH_FTBU_02 : ResponseHash from RILCheckAndEncryptPasswordHelper.checkAndEncryptPassword : {}", sClassName,
                        sMethodName, hmResult);

                stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
                if (!stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
                    logger.info("{}{}UEUH_FTBU_03 : Error returned from RILCheckAndEncryptPasswordHelper.checkAndEncryptPassword : {}", sClassName,
                            sMethodName, hmResult);
                    return hmResult;
                }

                if (!hmResult.get(MPSDefs.DB_MD5_PASSWORD).equals(hmDBMemberData.get(MPSDefs.DB_MD5_PASSWORD))) {
                    hmEncryptedPasswords.putAll(hmResult);
                }
            }

            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS);
            hmResult.put("hmUpdatableFields", hmUpdatableFields);
            hmResult.put("hmEncryptedPasswords", hmEncryptedPasswords);

        } catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e);
            stAppInfo = "Exception thrown from fieldsToBeUpdated method : " + hmResult;
            logger.error("{}{}UEUH_FTBU_04 :  {} " , sClassName , sMethodName, stAppInfo);
        } finally {
            logger.info("{}{}UEUH_FTBU_05 : ResponseHash from fieldsToBeUpdated : {}", sClassName, sMethodName, hmResult);
        }
        return hmResult;
    }
    
    /**
     * This method is responsible for processing the password change for a user.
     * It first checks if the password needs to be updated by comparing the input password with the current password in the database.
     * If the password needs to be updated, it encrypts the new password and adds it to a HashMap.
     * It then updates the password for all linked users and the access id.
     * If any of these operations fail, it returns the corresponding error.
     * If all operations are successful, it returns a success message.
     *
     * @param hmInput A HashMap containing the input parameters for the method. It should include necessary information such as user ID, new password, transaction ID, transaction name, calling system ID, and other user details to be updated.
     * @param hmMemberDB A HashMap containing the current data in the database for the user. It should include necessary information such as user ID, current password, and other user details.
     * @param hmSlidInfo A HashMap containing the SLID information for the user. It should include necessary information such as user lock level.
     * @param hmEncryptedPasswords A HashMap containing the encrypted passwords. It should include necessary information such as encrypted password, MD5 password, SHA1 password, DES3 password, and other password details.
     * @return A HashMap containing the result of the method. It includes the application status code and other information.
     */
    public HashMap processChangePassword(HashMap<String,Object> hmInput, HashMap<String,Object> hmMemberDB, HashMap<String,Object> hmSlidInfo,
                                         HashMap<String,Object> hmEncryptedPasswords) {

        String sMethodName = ".processChangePassword.";

        HashMap hmResult = null;
        String stAppInfo = null;
        String stAppStatusCode = null;

        logger.info("{}{}UEUH_PCP_01 : processChangePassword with Input Hash : {}", sClassName, sMethodName, hmInput);

        try {
            String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
            String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
            String sTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);

            ArrayList alLinkedUserMemberNums = CommonUtil.getArrayList();
            ArrayList alLinkedUsers = CommonUtil.getArrayList();

            String handle = (String) hmMemberDB.get(MPSDefs.DB_MEMBER_NAME);
            String domain = (String) hmMemberDB.get(MPSDefs.DB_DOMAIN_NAME);

            String sMemberNum = (String) hmMemberDB.get(MPSDefs.DB_MEMBER_NUM);

            alLinkedUserMemberNums.add(sMemberNum);

            String sSlidMemberNum = null;

            if (hmSlidInfo != null && !hmSlidInfo.isEmpty()) {
                sSlidMemberNum = (String) hmSlidInfo.get(MPSDefs.DB_SLID_MEMBER_NUM);
                if (hmSlidInfo.containsKey(MPSDefs.KEY_LINKED_USERS)) {
                    alLinkedUsers = (ArrayList) hmSlidInfo.get(MPSDefs.KEY_LINKED_USERS);
                }
            }

            if (alLinkedUsers != null && !alLinkedUsers.isEmpty()) {
                for (int i = 0; i < alLinkedUsers.size(); i++) {
                    HashMap<String, Object> hmEachUser = (HashMap) alLinkedUsers.get(i);
                    if (hmEachUser != null && !hmEachUser.isEmpty()) {
                        String stLinkedUserMemberNum = (String) hmEachUser.get(MPSDefs.DB_MEMBER_NUM);
                        if (stLinkedUserMemberNum != null && !alLinkedUserMemberNums.contains(stLinkedUserMemberNum)) {
                            alLinkedUserMemberNums.add(stLinkedUserMemberNum);
                        }
                    }
                }
            }

            HashMap<String, Object> hmInHs = CommonUtil.getHashMap();
            hmInHs.putAll(hmInput);
            if (hmEncryptedPasswords != null && !hmEncryptedPasswords.isEmpty()) {
                // Add encrypted passwords to inputHash
                hmInHs.put(CommonDefs.DB_ENC_PASSWORD, hmEncryptedPasswords.get(MPSDefs.DB_ENC_PASSWORD));
                hmInHs.put(CommonDefs.DB_MD5_PASSWORD, hmEncryptedPasswords.get(MPSDefs.DB_MD5_PASSWORD));
                hmInHs.put(CommonDefs.DB_SHA1_PASSWORD, hmEncryptedPasswords.get(MPSDefs.DB_SHA1_PASSWORD));
                hmInHs.put(CommonDefs.DB_DES3_PASSWORD, hmEncryptedPasswords.get(MPSDefs.DB_DES3_PASSWORD));
                hmInHs.put(CommonDefs.PASSWORD_TYPE, hmEncryptedPasswords.get(CommonDefs.PASSWORD_TYPE));

                if (hmEncryptedPasswords.get(MPSDefs.DB_GEN_PASSWORD) != null) {
                    hmInHs.put(CommonDefs.DB_GEN_PASSWORD, hmEncryptedPasswords.get(MPSDefs.DB_GEN_PASSWORD));
                    hmInHs.put(CommonDefs.DB_GEN_PASSWORD_TYPE, hmEncryptedPasswords.get(MPSDefs.DB_GEN_PASSWORD_TYPE));
                }

                HashMap<String, Object> hmMemberData = CommonUtil.getHashMap();
                ArrayList alMemberData = CommonUtil.getArrayList();
                HashMap<String, Object> hmMPSInput = CommonUtil.getHashMap();

                hmMPSInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                hmMPSInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
                hmMPSInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);

                // Updating passwords for all linked users else passwords will be updated for MID
                if (alLinkedUserMemberNums != null && !alLinkedUserMemberNums.isEmpty()) {

                    for (Object alLinkedUserMemberNum : alLinkedUserMemberNums) {

                        // need to encrypted passwords for each user, as it clears the input password once updated

                        hmMemberData.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);
                        hmMemberData.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);

                        hmMemberData.put(MPSDefs.DB_ENC_PASSWORD, hmInHs.get(CommonDefs.DB_ENC_PASSWORD));
                        hmMemberData.put(MPSDefs.DB_MD5_PASSWORD, hmInHs.get(CommonDefs.DB_MD5_PASSWORD));
                        hmMemberData.put(MPSDefs.DB_SHA1_PASSWORD, hmInHs.get(CommonDefs.DB_SHA1_PASSWORD));
                        hmMemberData.put(MPSDefs.DB_DES3_PASSWORD, hmInHs.get(CommonDefs.DB_DES3_PASSWORD));
                        if (hmInHs.get(MPSDefs.DB_GEN_PASSWORD) != null) {
                            hmMemberData.put(MPSDefs.DB_GEN_PASSWORD, hmInHs.get(CommonDefs.DB_GEN_PASSWORD));
                            hmMemberData.put(MPSDefs.DB_GEN_PASSWORD_TYPE, hmInHs.get(CommonDefs.DB_GEN_PASSWORD_TYPE));
                        }
                        hmMemberData.put(MPSDefs.DB_SSHA_PASSWORD, null);

                        hmMemberData.put(MPSDefs.DB_MEMBER_NUM, alLinkedUserMemberNum);
                        //[2207] PID 400970h : updating passwordDirty for password change
                        hmMemberData.put(MPSDefs.DB_PASSWORD_DIRTY, null);
                        alMemberData.add(hmMemberData);

                        hmMPSInput.put(MPSDefs.DB_MEMBER_TABLE, alMemberData);

                        logger.debug("{}{} UEUH_PCP_02 : Calling to MemberDBHelper.processData with HashMap = {}",
                                sClassName, sMethodName, hmMPSInput);

                        hmResult = memberDBHelper.processData(hmMPSInput);

                        logger.debug("{}{} UEUH_PCP_03 : Response Hash from MemberDBHelper.processData is = {}",
                                sClassName, sMethodName, hmResult);

                        stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
                        if (!stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {

                            logger.info("{}{} UEUH_PCP_04 : Error returned  from MemberDBHelper.processData with HashMapp {} : ",
                                    sClassName, sMethodName, hmResult);

                            return hmResult;
                        }

                        // clearing the db input before updating for next linked user
                        hmMPSInput.remove(MPSDefs.DB_MEMBER_TABLE);
                        alMemberData.clear();
                    }
                }

                // updating passwords for access id
                if (sSlidMemberNum != null && !sSlidMemberNum.isEmpty()) {

                    hmMemberData.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);
                    hmMemberData.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);

                    hmMemberData.put(MPSDefs.DB_ENC_PASSWORD, hmInHs.get(CommonDefs.DB_ENC_PASSWORD));
                    hmMemberData.put(MPSDefs.DB_MD5_PASSWORD, hmInHs.get(CommonDefs.DB_MD5_PASSWORD));
                    hmMemberData.put(MPSDefs.DB_SHA1_PASSWORD, hmInHs.get(CommonDefs.DB_SHA1_PASSWORD));
                    hmMemberData.put(MPSDefs.DB_DES3_PASSWORD, hmInHs.get(CommonDefs.DB_DES3_PASSWORD));
                    if (hmInHs.get(MPSDefs.DB_GEN_PASSWORD) != null) {
                        hmMemberData.put(MPSDefs.DB_GEN_PASSWORD, hmInHs.get(CommonDefs.DB_GEN_PASSWORD));
                        hmMemberData.put(MPSDefs.DB_GEN_PASSWORD_TYPE, hmInHs.get(CommonDefs.DB_GEN_PASSWORD_TYPE));
                    }
                    hmMemberData.put(MPSDefs.DB_SSHA_PASSWORD, null);

                    hmMemberData.put(MPSDefs.DB_MEMBER_NUM, sSlidMemberNum);
                    //[2207] PID 400970h : updating passwordDirty for password change
                    hmMemberData.put(MPSDefs.DB_PASSWORD_DIRTY, null);
                    alMemberData.add(hmMemberData);

                    hmMPSInput.put(MPSDefs.DB_MEMBER_TABLE, alMemberData);

                    logger.debug("{}{} UEUH_PCP_05 : Calling to MemberDBHelper.processData with HashMap = {}", sClassName,
                            sMethodName, hmMPSInput);

                    hmResult = memberDBHelper.processData(hmMPSInput);

                    logger.debug("{}{} UEUH_PCP_06 : Response Hash from MemberDBHelper.processData is = {}", sClassName,
                            sMethodName, hmResult);

                }

                stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
                if (!stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {

                    logger.info("{}{} UEUH_PCP_07 : Error returned  from MemberDBHelper.processData with HashMapp {} : ",
                            sClassName, sMethodName, hmResult);

                    return hmResult;
                }
            }
        } catch (Exception e) {
            stAppInfo = "Exception thrown in ProcessChangePassword() method::" + e.getMessage();
            hmResult = CommonErrorMap.makeExceptionMap(e);
            logger.error("{}{} UEUH_PCP_08 : {} ", sClassName, sMethodName, stAppInfo);

        } finally {
            stAppInfo = "Response from ProcessChangePassword";
            logger.info("{}{} UEUH_PCP_09 : Response from ProcessChangePassword : {} : ", sClassName, sMethodName,
                    hmResult);
        }
        return hmResult;
    }
}