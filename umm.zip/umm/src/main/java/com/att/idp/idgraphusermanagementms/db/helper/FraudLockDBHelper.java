package com.att.idp.idgraphusermanagementms.db.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.StatusMsg;

/**
 * This class is responsible for managing fraud lock-related operations in the database.
 * It uses Spring's JdbcTemplate for database operations and has methods for querying, adding, updating, and deleting user and account fraud locks.
 * It also uses other helper classes like DBHelper, CommonUtil, and CommonErrorMap.
 *
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like JdbcTemplate and DBHelper.
 *
 * The class contains SQL queries as string constants for querying, adding, updating, and deleting user and account fraud locks.
 * These queries are used in the corresponding methods for these operations.
 *
 * The class also contains a logger for logging information and errors.
 *
 * The main methods in this class are:
 * - queryUserFraudLock: This method retrieves a user's fraud lock information from the database. It takes a HashMap as input and returns a HashMap as output.
 * - addUserFraudLock: This method adds a user's fraud lock information to the database. It takes a HashMap as input and returns a HashMap as output.
 * - updateUserFraudLock: This method updates a user's fraud lock information in the database. It takes a HashMap as input and returns a HashMap as output.
 * - deleteUserFraudLock: This method deletes a user's fraud lock information from the database. It takes a HashMap as input and returns a HashMap as output.
 * - queryAccountFraudLock: This method retrieves an account's fraud lock information from the database. It takes a HashMap as input and returns a HashMap as output.
 * - addAccountFraudLock: This method adds an account's fraud lock information to the database. It takes a HashMap as input and returns a HashMap as output.
 * - updateAccountFraudLock: This method updates an account's fraud lock information in the database. It takes a HashMap as input and returns a HashMap as output.
 * - deleteAccountFraudLock: This method deletes an account's fraud lock information from the database. It takes a HashMap as input and returns a HashMap as output.
 * - processData: This method processes a list of user and account fraud lock operations. It takes a HashMap as input and returns a HashMap as output.
 */
@Component
public class FraudLockDBHelper {

	private static String sClassName = "FraudLockDBHelper";
	public static final Logger log = LoggerFactory.getLogger(FraudLockDBHelper.class);
	public static final String APP_INFO_INPUT_HASH_NULL="Input HashMap is null";
	public static final String APP_INFO_MISSING_REQUIRED_FIELDS ="DB call failed due to missing required fields";
	public static final String APP_INFO_EMPTY ="sor_id and sor_name both are null or empty in input";
	public static final String APP_INFO_NOT_VALID ="Input sor_name/sor_id is not valid";
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private DBHelper dBHelper;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	/**
	 * This method retrieves a user's fraud lock information from the database.
	 * It takes a HashMap as an argument which contains the details of the user's fraud lock information to be retrieved.
	 * The HashMap should contain the following key:
	 * - CommonDefs.DB_MEMBER_NUM: The member number.
	 *
	 * The method first logs the start of the operation and the input parameters.
	 * It then checks if the member number is present in the input HashMap.
	 * If the member number is missing, it logs an error and returns an error status.
	 * Otherwise, it prepares the SQL query for retrieving the user's fraud lock information and executes it using the jdbcTemplate object.
	 * If the operation is successful, the method returns a HashMap containing the status of the operation and the retrieved user's fraud lock information.
	 * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
	 *
	 * @param hmDbInput A HashMap containing the details of the user's fraud lock information to be retrieved.
	 * @return A HashMap containing the status of the operation and the retrieved user's fraud lock information.
	 */
	public HashMap<String, Object> queryUserFraudLock(HashMap<String, Object> hmDbInput) {

		String sMethodName = ".queryUserFraudLock.";
		log.info(ProfileOrchestrationConstants.LOG_DBTOOLS000, sClassName, sMethodName,
				(hmDbInput != null ? StringUtils.normalizeSpace(hmDbInput.toString()) : "null"));

		String dateFormat = "MMDDYYYY HH24:mi:ss";
		String stAppInfo = null;

		List<Object> objectList = CommonUtil.getArrayList();
		HashMap<String, Object> hmUserFraudResp = null;
		HashMap<String, Object> hmUserFraud = new HashMap();
		List alQueryResponse = null;

		try {

			if (hmDbInput == null || hmDbInput.isEmpty()) {
				hmUserFraudResp = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, APP_INFO_INPUT_HASH_NULL);
				log.error("{}{}DB_H_QUFL03 : {}", sClassName, sMethodName, APP_INFO_INPUT_HASH_NULL);
				return hmUserFraudResp;
			}

			String sQueryUserFraudLockSql = "SELECT MEMBER_NUM , USER_LOCK_LEVEL, USER_LOCK_REASON, FRAUD_AGENT, TO_CHAR(CREATE_DATE, '"
					+ dateFormat + "') AS CREATE_DATE, TO_CHAR(LAST_MODIFIED, '" + dateFormat
					+ "') AS LAST_MODIFIED, LAST_MODIFIED_BY" + " FROM USERFRAUDLOCK WHERE MEMBER_NUM = ?";

			String stMemberNum = (String) hmDbInput.get(CommonDefs.DB_MEMBER_NUM);

			if (stMemberNum == null || stMemberNum.isEmpty()) {
				stAppInfo = "Member Num  is null or empty in input";
				hmUserFraudResp = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
				log.info("{}{}DB_H_QUFL04 : {}", sClassName, sMethodName, stAppInfo);
				return hmUserFraudResp;
			}

			log.info("{}{}DB_H_QUFL_SQL000 : queryUserFraudLockSql = {}", sClassName, sMethodName, sQueryUserFraudLockSql);
			objectList.add(stMemberNum);

			alQueryResponse = jdbcTemplate.queryForList(new String(sQueryUserFraudLockSql),
					objectList.toArray(new Object[objectList.size()]));

			int numRowsFound = 0;
			if (alQueryResponse != null && !alQueryResponse.isEmpty()) {
				for (int j = 0; j < alQueryResponse.size(); j++) {
					Map hmQueryResponse = (Map) alQueryResponse.get(j);
					Iterator itr = hmQueryResponse.keySet().iterator();
					while (itr.hasNext()) {
						String key = (String) itr.next();
						Object value = hmQueryResponse.get(key);
						String strValue = (value == null ? null : value.toString());
						hmUserFraud.put(key.toLowerCase(), strValue); // TODO : check for keys with MPS
					}

					++numRowsFound;
				}
			}

			hmUserFraudResp = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
					CommonDefs.COMMON_SUCCESS_MSG);
			hmUserFraudResp.putAll(hmUserFraud);

			if (numRowsFound == 0) {
				stAppInfo = "No Record Found in DB";
				hmUserFraudResp = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo);
				log.info("{}{}DB_H_QUFL05 : {}", sClassName, sMethodName, stAppInfo);
				return hmUserFraudResp;
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmUserFraudResp = StatusMsg.makeExceptionSQLStatus(e);
			//hmUserFraudResp = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DB_H_QUFL_E_02 : Error::{}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}DB_H_QUFL_E_03 : Exception = {}", sClassName, sMethodName, e);

		} finally {

			log.info(SpiMarker.getInstance(),ProfileOrchestrationConstants.LOG_DBTOOLS999, sClassName, sMethodName, hmUserFraudResp);
		}

		return hmUserFraudResp;
	}

	/**
	 * This method adds a user's fraud lock information to the database.
	 * It takes a HashMap as an argument which contains the details of the user's fraud lock information to be added.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.DB_MEMBER_NUM: The member number.
	 * - MPSDefs.DB_USER_LOCK_LEVEL: The user lock level.
	 * - MPSDefs.DB_USER_LOCK_REASON: The reason for the user lock.
	 * - MPSDefs.DB_FRAUD_AGENT: The fraud agent.
	 * - CommonDefs.CALLING_SYSTEM_ID: The identifier of the system that last modified the record.
	 *
	 * The method first logs the start of the operation and the input parameters.
	 * It then checks if the necessary information is present in the input HashMap.
	 * If any necessary information is missing, it logs an error and returns an error status.
	 * Otherwise, it prepares the SQL query for adding the user's fraud lock information and executes it using the jdbcTemplate object.
	 * If the operation is successful, the method returns a HashMap containing the status of the operation.
	 * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
	 *
	 * @param hmInput A HashMap containing the details of the user's fraud lock information to be added.
	 * @return A HashMap containing the status of the operation.
	 */
	public HashMap addUserFraudLock(HashMap hmInput) {
		String sMethodName = ".addUserFraudLock.";
		log.info(ProfileOrchestrationConstants.LOG_DBTOOLS000, sClassName, sMethodName, hmInput);

		HashMap hmResult = null;
		String stAppInfo = null;
		List<Object> objectList = CommonUtil.getArrayList();

		String sAddUserFraudLockSql = "INSERT INTO USERFRAUDLOCK(" + "MEMBER_NUM, " + "USER_LOCK_LEVEL, "
				+ "USER_LOCK_REASON, " + "FRAUD_AGENT, " + "LAST_MODIFIED_BY" + ") VALUES(" + "?, ?, ?, ?, ?)";

		try {

			if (hmInput == null || hmInput.isEmpty()) {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, APP_INFO_INPUT_HASH_NULL);
				log.info("{}{}DB_H_AUFL_01 : {}", sClassName, sMethodName, APP_INFO_INPUT_HASH_NULL);
				return hmResult;
			}

			String sMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
			String sUserLockLevel = (String) hmInput.get(MPSDefs.DB_USER_LOCK_LEVEL);
			String sUserLockReason = (String) hmInput.get(MPSDefs.DB_USER_LOCK_REASON);
			String sFraudAgent = (String) hmInput.get(MPSDefs.DB_FRAUD_AGENT);
			String sLastModifiedBy = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			
			String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
			
			if ("UpdateUserFraud".equals(sTransactionName)) {

				if (sMemberNum == null || sMemberNum.isEmpty() || sLastModifiedBy == null
						|| sLastModifiedBy.isEmpty()) {

					stAppInfo = "member_num or callingSystemId is null or empty in input";
					log.info("{}{}DB_H_AUFL_02.01 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
					return hmResult;
				}

			} else {
				// for other API's, UpdateExtUser etc..
				if (sMemberNum == null || sMemberNum.isEmpty() || sFraudAgent == null || sFraudAgent.isEmpty()
						|| sLastModifiedBy == null || sLastModifiedBy.isEmpty()) {

					stAppInfo = "member_num OR fraud_agent or callingSystemId is null or empty in input";
					log.info("{}{}DB_H_AUFL_02.02 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
					return hmResult;
				}

			}

			log.info("{}{}DB_H_AUFL_SQL000 : addUserFraudLockSql = {}", sClassName, sMethodName, sAddUserFraudLockSql);

			objectList.add(sMemberNum);

			if (sUserLockLevel != null && !sUserLockLevel.isEmpty()) {
				objectList.add(sUserLockLevel);

			} else {
				objectList.add(null);
			}
			if (sUserLockReason != null) {
				objectList.add(sUserLockReason);

			} else {
				objectList.add(null);
			}

			objectList.add(sFraudAgent);
			objectList.add(sLastModifiedBy);

			int iCount = jdbcTemplate.update(new String(sAddUserFraudLockSql),
					objectList.toArray(new Object[objectList.size()]));

			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, "No of rows inserted:= " + iCount);

			log.info("{}{}DB_H_AUFL_04 :No of rows inserted:={}", sClassName, sMethodName, iCount);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DB_H_AUFL_E1 : Error:: {}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}DB_H_AUFL_E2 : Exception = {}", sClassName, sMethodName, e);

		} finally {

			log.info(SpiMarker.getInstance(),ProfileOrchestrationConstants.LOG_DBTOOLS999, sClassName, sMethodName, hmResult);
		}

		return hmResult;
	}

	/**
	 * This method updates a user's fraud lock information in the database.
	 * It takes a HashMap as an argument which contains the details of the user's fraud lock information to be updated.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.DB_MEMBER_NUM: The member number.
	 * - MPSDefs.DB_USER_LOCK_LEVEL: The user lock level (optional).
	 * - MPSDefs.DB_USER_LOCK_REASON: The reason for the user lock (optional).
	 * - MPSDefs.DB_FRAUD_AGENT: The fraud agent (optional).
	 * - CommonDefs.CALLING_SYSTEM_ID: The identifier of the system that last modified the record.
	 *
	 * The method first logs the start of the operation and the input parameters.
	 * It then checks if the necessary information is present in the input HashMap.
	 * If any necessary information is missing, it logs an error and returns an error status.
	 * Otherwise, it prepares the SQL query for updating the user's fraud lock information and executes it using the jdbcTemplate object.
	 * If the operation is successful, the method returns a HashMap containing the status of the operation.
	 * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
	 *
	 * @param hmDbInput A HashMap containing the details of the user's fraud lock information to be updated.
	 * @return A HashMap containing the status of the operation.
	 */
	public HashMap updateUserFraudLock(HashMap hmDbInput) {

		String sMethodName = ".updateUserFraudLock.";

		HashMap hmResult = null;
		String sAppInfo = null;

		List<Object> objectList = CommonUtil.getArrayList();

		log.info(ProfileOrchestrationConstants.LOG_DBTOOLS000, sClassName, sMethodName, hmDbInput);

		StringBuilder sUpdateFraudUserSql = new StringBuilder("UPDATE USERFRAUDLOCK SET last_modified_by = ?, ");

		if (hmDbInput == null) {
			hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_INVALID_DATA_NUM, ProfileOrchestrationConstants.APP_INFO_INPUT_HASH_EMPTY);
			log.info("{}{}DB_H_UUFL_03 : {}", sClassName, sMethodName, ProfileOrchestrationConstants.APP_INFO_INPUT_HASH_EMPTY);
			return hmResult;
		}

		try {
			String sMemNumVal = (String) hmDbInput.get(MPSDefs.DB_MEMBER_NUM);
			String sCallingSystemId = (String) hmDbInput.get(CommonDefs.CALLING_SYSTEM_ID);

			if (sMemNumVal == null || sMemNumVal.isEmpty() || sCallingSystemId == null || sCallingSystemId.isEmpty()) {
				sAppInfo = "member_num OR callingSystemId is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
				log.info("{}{}DB_H_UUFL_04 : {}", sClassName, sMethodName, sAppInfo);
				return hmResult;
			}

			String sKey = null;
			int nIndex = 0;
			Set USER_FRAUD_LOCK_UPDATBLE_ATTRS = new HashSet();

			USER_FRAUD_LOCK_UPDATBLE_ATTRS.add("user_lock_level");
			USER_FRAUD_LOCK_UPDATBLE_ATTRS.add("user_lock_reason");
			USER_FRAUD_LOCK_UPDATBLE_ATTRS.add("fraud_agent");

			Iterator itr = USER_FRAUD_LOCK_UPDATBLE_ATTRS.iterator();
			while (itr.hasNext()) {
				sKey = (String) itr.next();

				if (hmDbInput.containsKey(sKey)) {
					if (nIndex > 0 && nIndex < USER_FRAUD_LOCK_UPDATBLE_ATTRS.size())
						sUpdateFraudUserSql.append(" ,");

					sUpdateFraudUserSql.append(sKey + "=?");
					nIndex++;
				}
			}

			String whereClause = "member_num =? ";
			sUpdateFraudUserSql.append(" WHERE " + whereClause);

			log.info("{}{}DB_H_UUFL_SQL000 : updateFraudUserSql = {}", sClassName, sMethodName, sUpdateFraudUserSql);

			nIndex = 0;
			objectList.add(sCallingSystemId);

			itr = USER_FRAUD_LOCK_UPDATBLE_ATTRS.iterator();
			while (itr.hasNext()) {
				sKey = (String) itr.next();

				if (hmDbInput.containsKey(sKey)) {
					nIndex++;
					objectList.add((String) hmDbInput.get(sKey));
				}
			}

			objectList.add(sMemNumVal);

			int rowCount = jdbcTemplate.update(new String(sUpdateFraudUserSql),
					objectList.toArray(new Object[objectList.size()]));

			if (rowCount == 0) {
				sAppInfo = "No Record found for input member_num";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, "Record not found in the DB");
				log.info("{}{}DB_H_UUFL_05 : {}", sClassName, sMethodName, sAppInfo);

			} else {
				sAppInfo = "USERFRAUDLOCK attributes updated successfully";
				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, sAppInfo);
				log.info("{}{}DB_H_UUFL_06 : {}", sClassName, sMethodName, sAppInfo);
			}
		}

		catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DB_H_UUFL_E2 : Error:: {}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}DB_H_UUFL_E3 : Exception = {}", sClassName, sMethodName, e);
		} finally {
			log.info(SpiMarker.getInstance(),"{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;
	}

	/**
	 * This method deletes a user's fraud lock information from the database.
	 * It takes a HashMap as an argument which contains the details of the user's fraud lock information to be deleted.
	 * The HashMap should contain the following key:
	 * - MPSDefs.DB_MEMBER_NUM: The member number.
	 *
	 * The method first logs the start of the operation and the input parameters.
	 * It then checks if the member number is present in the input HashMap.
	 * If the member number is missing, it logs an error and returns an error status.
	 * Otherwise, it prepares the SQL query for deleting the user's fraud lock information and executes it using the jdbcTemplate object.
	 * If the operation is successful, the method returns a HashMap containing the status of the operation and the number of rows deleted.
	 * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
	 *
	 * @param hmDbInput A HashMap containing the details of the user's fraud lock information to be deleted.
	 * @return A HashMap containing the status of the operation and the number of rows deleted.
	 */
	public HashMap deleteUserFraudLock(HashMap hmDbInput) {
		String sMethodName = ".deleteUserFraudLock.";

		HashMap hmResult = null;
		String sAppInfo = null;

		List<Object> objectList = CommonUtil.getArrayList();

		String sDeleteUserFraudLockSql = "DELETE from USERFRAUDLOCK where member_num = ?";

		log.info(ProfileOrchestrationConstants.LOG_DBTOOLS000, sClassName, sMethodName, hmDbInput);

		try {

			String sMemberNum = (String) hmDbInput.get(MPSDefs.DB_MEMBER_NUM);

			if (sMemberNum == null || sMemberNum.trim().length() <= 0) {
				sAppInfo = "member_num is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
				log.info("{}{}DB_H_DUFL_03 : {}", sClassName, sMethodName, sAppInfo);
				return hmResult;
			}

			log.info("{}{}DB_H_DUFL_SQL000 : deleteUserFraudLockSql = {}", sClassName, sMethodName,sDeleteUserFraudLockSql);

			objectList.add(sMemberNum.trim());

			int iCount = jdbcTemplate.update(new String(sDeleteUserFraudLockSql),
					objectList.toArray(new Object[objectList.size()]));

			log.info("{}{}DB_H_DUFL_04 : No of rows deleted are: {}", sClassName, sMethodName, iCount);

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "No of rows deleted = " + iCount);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DB_H_DUFL_E2 : Error::{}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}DB_H_DUFL_E3 : Exception = {}", sClassName, sMethodName, e);
		} finally {
			log.info(SpiMarker.getInstance(),"{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);
		}
		
		return hmResult;
	}

	/**
	 * This method retrieves an account's fraud lock information from the database.
	 * It takes a HashMap as an argument which contains the details of the account's fraud lock information to be retrieved.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.DB_SOR_INVARIANT_ID: The invariant ID of the system of record (SOR).
	 * - MPSDefs.DB_SOR_NAME: The name of the SOR (optional).
	 * - MPSDefs.DB_SOR_ID: The ID of the SOR (optional).
	 *
	 * The method first logs the start of the operation and the input parameters.
	 * It then checks if the necessary information is present in the input HashMap.
	 * If any necessary information is missing, it logs an error and returns an error status.
	 * Otherwise, it prepares the SQL query for retrieving the account's fraud lock information and executes it using the jdbcTemplate object.
	 * If the operation is successful, the method returns a HashMap containing the status of the operation and the retrieved account's fraud lock information.
	 * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
	 *
	 * @param hmInput A HashMap containing the details of the account's fraud lock information to be retrieved.
	 * @return A HashMap containing the status of the operation and the retrieved account's fraud lock information.
	 */
	public HashMap<String, Object> queryAccountFraudLock(HashMap<String, Object> hmInput) {

		String sMethodName = ".queryAccountFraudLock.";
		String dateFormat = "MMDDYYYY HH24:mi:ss";
		String stAppInfo = null;

		HashMap<String, Object> hmResult = null;
		ArrayList alAccountFraudLock = new ArrayList();
		List<Object> objectList = CommonUtil.getArrayList();
		HashMap hmAccountFraud = CommonUtil.getHashMap();
		List alQueryResponse = null;
		int sorId = -1;

		try {
			log.info(ProfileOrchestrationConstants.LOG_DBTOOLS000, sClassName, sMethodName,
					(hmInput != null ? StringUtils.normalizeSpace(hmInput.toString()) : "null"));

			if (hmInput == null || hmInput.isEmpty()) {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, APP_INFO_INPUT_HASH_NULL);
				log.info("{}{}DB_H_QAFL03 : {}", sClassName, sMethodName, APP_INFO_INPUT_HASH_NULL);
				return hmResult;
			}

			String sQueryAccountFraudLockSql = "SELECT SOR_ID, SOR_INVARIANT_ID , ACCOUNT_LOCKED, ACCOUNT_LOCK_REASON, FRAUD_AGENT, TO_CHAR(CREATE_DATE, '"
					+ dateFormat + "') AS CREATE_DATE, TO_CHAR(LAST_MODIFIED, '" + dateFormat
					+ "') AS LAST_MODIFIED, LAST_MODIFIED_BY"
					+ " FROM ACCOUNTFRAUDLOCK WHERE SOR_ID = ? AND SOR_INVARIANT_ID = ?";

			String sSorInvId = (String) hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
			String sSorName = (String) hmInput.get(MPSDefs.DB_SOR_NAME);
			String sSorId = (String) hmInput.get(MPSDefs.DB_SOR_ID);

			if ((sSorId == null || sSorId.isEmpty()) && (sSorName == null || sSorName.isEmpty())) {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
				log.info("{}{}DB_H_QAFL04 : {}", sClassName, sMethodName, APP_INFO_EMPTY);
				return hmResult;
			}

			if (sSorId != null && sSorId.trim().length() != 0) {
				sorId = Integer.parseInt(sSorId);
			} else {
				sorId = dBHelper.getSorId(sSorName);
			}

			if (sorId == -1) {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
				log.info("{}{}DB_H_QAFL05 : {}", sClassName, sMethodName, APP_INFO_NOT_VALID);
				return hmResult;
			}

			if (sSorInvId == null || sSorInvId.isEmpty()) {
				stAppInfo = "sor_invariant_id  is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
				log.info("{}{}DB_H_QAFL06 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			log.info("{}{}DB_H_QAFL_SQL000 : queryAccountFraudLockSql = {}", sClassName, sMethodName, sQueryAccountFraudLockSql);

			objectList.add(sorId);
			objectList.add(sSorInvId);

			alQueryResponse = jdbcTemplate.queryForList(new String(sQueryAccountFraudLockSql),
					objectList.toArray(new Object[objectList.size()]));

			if (alQueryResponse != null && !alQueryResponse.isEmpty()) {
				for (int j = 0; j < alQueryResponse.size(); j++) {
					Map hmQueryResponse = (Map) alQueryResponse.get(j);
					Iterator itr = hmQueryResponse.keySet().iterator();
					while (itr.hasNext()) {
						String key = (String) itr.next();
						Object value = hmQueryResponse.get(key);
						String strValue = (value == null ? null : value.toString());
						hmAccountFraud.put(key.toLowerCase(), strValue);
					}
				}
			}

			HashMap hmAccountFraudResp = CommonUtil.getHashMap();
			hmAccountFraudResp.putAll(hmAccountFraud);

			alAccountFraudLock.add(hmAccountFraudResp);

			if (alAccountFraudLock == null || alAccountFraudLock.isEmpty()) {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
						"No Record found for given account_id and identification_type");
			} else {
				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, "Success");
				hmResult.put("fraudLock", alAccountFraudLock);
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();

			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DB_H_QAFL_E_02 : Error::{}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}DB_H_QAFL_E_03 : Exception = {}", sClassName, sMethodName, e);

		} finally {
			log.info(SpiMarker.getInstance(),"{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);
		}

		return hmResult;
	}

	/**
	 * This method adds an account's fraud lock information to the database.
	 * It takes a HashMap as an argument which contains the details of the account's fraud lock information to be added.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.DB_SOR_INVARIANT_ID: The invariant ID of the system of record (SOR).
	 * - MPSDefs.DB_SOR_NAME: The name of the SOR (optional).
	 * - MPSDefs.DB_SOR_ID: The ID of the SOR (optional).
	 * - MPSDefs.DB_ACCOUNT_LOCKED: The account lock status.
	 * - MPSDefs.DB_ACCOUNT_LOCK_REASON: The reason for the account lock.
	 * - MPSDefs.DB_FRAUD_AGENT: The fraud agent.
	 * - CommonDefs.CALLING_SYSTEM_ID: The identifier of the system that last modified the record.
	 *
	 * The method first logs the start of the operation and the input parameters.
	 * It then checks if the necessary information is present in the input HashMap.
	 * If any necessary information is missing, it logs an error and returns an error status.
	 * Otherwise, it prepares the SQL query for adding the account's fraud lock information and executes it using the jdbcTemplate object.
	 * If the operation is successful, the method returns a HashMap containing the status of the operation and the number of rows added.
	 * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
	 *
	 * @param hmInput A HashMap containing the details of the account's fraud lock information to be added.
	 * @return A HashMap containing the status of the operation and the number of rows added.
	 */
	public HashMap addAccountFraudLock(HashMap hmInput) {

		String sMethodName = ".addAccountFraudLock.";

		HashMap hmResult = null;
		String stAppInfo = null;
		int sorId = -1;
		List<Object> objectList = CommonUtil.getArrayList();

		// UPSERT: Use Oracle MERGE to safely insert or update by (SOR_ID, SOR_INVARIANT_ID).
		// Prevents ORA-00001 unique constraint violation when another service (e.g., Association MS)
		// has already inserted a row for the same key within a concurrent transaction.
		String sAddAccountFraudLockSql = "MERGE INTO ACCOUNTFRAUDLOCK target " +
				"USING (SELECT ? AS SOR_ID, ? AS SOR_INVARIANT_ID FROM DUAL) source " +
				"ON (target.SOR_ID = source.SOR_ID AND target.SOR_INVARIANT_ID = source.SOR_INVARIANT_ID) " +
				"WHEN MATCHED THEN UPDATE SET " +
				"ACCOUNT_LOCKED = ?, ACCOUNT_LOCK_REASON = ?, FRAUD_AGENT = ?, LAST_MODIFIED_BY = ? " +
				"WHEN NOT MATCHED THEN INSERT " +
				"(SOR_ID, SOR_INVARIANT_ID, ACCOUNT_LOCKED, ACCOUNT_LOCK_REASON, FRAUD_AGENT, LAST_MODIFIED_BY) " +
				"VALUES (source.SOR_ID, source.SOR_INVARIANT_ID, ?, ?, ?, ?)";

		log.info(ProfileOrchestrationConstants.LOG_DBTOOLS000, sClassName, sMethodName, hmInput);

		try {

			if (hmInput == null || hmInput.isEmpty()) {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, APP_INFO_INPUT_HASH_NULL);
				log.info("{}{}DB_H_AAFL03 : {}", sClassName, sMethodName, APP_INFO_INPUT_HASH_NULL);
				return hmResult;
			}

			String sSorInvariantId = (String) hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
			String sSorId = (String) hmInput.get(MPSDefs.DB_SOR_ID);
			String sSorName = (String) hmInput.get(MPSDefs.DB_SOR_NAME);
			String sAccountLocked = (String) hmInput.get(MPSDefs.DB_ACCOUNT_LOCKED);
			String sAccountLockReason = (String) hmInput.get(MPSDefs.DB_ACCOUNT_LOCK_REASON);
			String sFraudAgent = (String) hmInput.get(MPSDefs.DB_FRAUD_AGENT);
			String sLastModifiedBy = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

			if (sSorInvariantId == null || sSorInvariantId.isEmpty() || sFraudAgent == null || sFraudAgent.isEmpty()
					|| sLastModifiedBy == null || sLastModifiedBy.isEmpty()) {
				stAppInfo = "sor_invariant_id OR fraud_agent or callingSystemId is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
				log.info("{}{}DB_H_AAFL04 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			if ((sSorId == null || sSorId.isEmpty()) && (sSorName == null || sSorName.isEmpty())) {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
				log.info("{}{}DB_H_AAFL05 : {}", sClassName, sMethodName, APP_INFO_EMPTY);
				return hmResult;
			}

			if (sSorId != null && sSorId.trim().length() != 0) {
				sorId = Integer.parseInt(sSorId);
			} else {
				sorId = dBHelper.getSorId(sSorName);
			}

			if (sorId == -1) {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
				log.info("{}{}DB_H_AAFL06 : {}", sClassName, sMethodName, APP_INFO_NOT_VALID);
				return hmResult;
			}

			log.info("{}{}DB_H_AAFL_SQL000 : addAccountFraudLockSql = {}", sClassName, sMethodName, sAddAccountFraudLockSql);

			// USING clause parameters (ON match key)
			objectList.add(sorId);
			objectList.add(sSorInvariantId);

			// WHEN MATCHED (UPDATE) parameters
			Object accountLockedValue = (sAccountLocked != null && !sAccountLocked.isEmpty()) ? sAccountLocked : null;
			Object accountLockReasonValue = sAccountLockReason;
			objectList.add(accountLockedValue);
			objectList.add(accountLockReasonValue);
			objectList.add(sFraudAgent);
			objectList.add(sLastModifiedBy);

			// WHEN NOT MATCHED (INSERT) parameters — same values as UPDATE
			objectList.add(accountLockedValue);
			objectList.add(accountLockReasonValue);
			objectList.add(sFraudAgent);
			objectList.add(sLastModifiedBy);

			int iCount = jdbcTemplate.update(new String(sAddAccountFraudLockSql),
					objectList.toArray(new Object[objectList.size()]));

			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, "No of rows upserted:= " + iCount);
			log.info("{}{}DB_H_AAFL07 : No of rows upserted:= {}", sClassName, sMethodName, iCount);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DB_H_AAFL_E2 : Error::{}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}DB_H_AAFL_E3 : Exception = {}", sClassName, sMethodName, e);

		} finally {
			log.info(SpiMarker.getInstance(),"{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);
		}

		return hmResult;
	}

	/**
	 * This method updates an account's fraud lock information in the database.
	 * It takes a HashMap as an argument which contains the details of the account's fraud lock information to be updated.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.DB_SOR_INVARIANT_ID: The invariant ID of the system of record (SOR).
	 * - MPSDefs.DB_SOR_NAME: The name of the SOR (optional).
	 * - MPSDefs.DB_SOR_ID: The ID of the SOR (optional).
	 * - MPSDefs.DB_ACCOUNT_LOCKED: The account lock status (optional).
	 * - MPSDefs.DB_ACCOUNT_LOCK_REASON: The reason for the account lock (optional).
	 * - MPSDefs.DB_FRAUD_AGENT: The fraud agent (optional).
	 * - CommonDefs.CALLING_SYSTEM_ID: The identifier of the system that last modified the record.
	 *
	 * The method first logs the start of the operation and the input parameters.
	 * It then checks if the necessary information is present in the input HashMap.
	 * If any necessary information is missing, it logs an error and returns an error status.
	 * Otherwise, it prepares the SQL query for updating the account's fraud lock information and executes it using the jdbcTemplate object.
	 * If the operation is successful, the method returns a HashMap containing the status of the operation.
	 * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
	 *
	 * @param hmInput A HashMap containing the details of the account's fraud lock information to be updated.
	 * @return A HashMap containing the status of the operation.
	 */
	public HashMap updateAccountFraudLock(HashMap hmInput) {

		String sMethodName = ".updateAccountFraudLock.";

		HashMap hmResult = null;
		String sAppInfo = null;
		int sorId = -1;

		List<Object> objectList = CommonUtil.getArrayList();

		log.info(ProfileOrchestrationConstants.LOG_DBTOOLS000, sClassName, sMethodName, hmInput);

		StringBuilder sUpdateAccountFraudLockSql = new StringBuilder(
				" UPDATE ACCOUNTFRAUDLOCK SET LAST_MODIFIED_BY = ?, ");

		try {

			if (hmInput == null) {
				hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_INVALID_DATA_NUM, ProfileOrchestrationConstants.APP_INFO_INPUT_HASH_EMPTY);
				log.info("{}{}DB_H_UAFL03 : {}", sClassName, sMethodName, ProfileOrchestrationConstants.APP_INFO_INPUT_HASH_EMPTY);
				return hmResult;
			}

			String sSorInvariantId = (String) hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
			String stSorId = (String) hmInput.get(MPSDefs.DB_SOR_ID);
			String stSorName = (String) hmInput.get(MPSDefs.DB_SOR_NAME);
			String sLastModifiedBy = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

			if (sSorInvariantId == null || sSorInvariantId.isEmpty() || sLastModifiedBy == null
					|| sLastModifiedBy.isEmpty()) {
				sAppInfo = "sor_invariant_id OR callingSystemId is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
				log.info("{}{}DB_H_UAFL04 : {}", sClassName, sMethodName, sAppInfo);
				return hmResult;
			}

			if ((stSorId == null || stSorId.isEmpty()) && (stSorName == null || stSorName.isEmpty())) {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
				log.info("{}{}DB_H_UAFL05 : {}", sClassName, sMethodName, APP_INFO_EMPTY);
				return hmResult;
			}

			if (stSorId != null && stSorId.trim().length() != 0) {
				sorId = Integer.parseInt(stSorId);
			} else {
				sorId = dBHelper.getSorId(stSorName);
			}

			if (sorId == -1) {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
				log.info("{}{}DB_H_UAFL06 : {}", sClassName, sMethodName, APP_INFO_NOT_VALID);
				return hmResult;
			}

			String sKey = null;
			int nIndex = 0;

			Set ACCOUNT_FRAUD_LOCK_UPDATBLE_ATTRS = new HashSet();

			ACCOUNT_FRAUD_LOCK_UPDATBLE_ATTRS.add("account_locked");
			ACCOUNT_FRAUD_LOCK_UPDATBLE_ATTRS.add("account_lock_reason");
			ACCOUNT_FRAUD_LOCK_UPDATBLE_ATTRS.add("fraud_agent");

			Iterator itr = ACCOUNT_FRAUD_LOCK_UPDATBLE_ATTRS.iterator();
			while (itr.hasNext()) {
				sKey = (String) itr.next();

				if (hmInput.containsKey(sKey)) {
					if (nIndex > 0 && nIndex < ACCOUNT_FRAUD_LOCK_UPDATBLE_ATTRS.size())
						sUpdateAccountFraudLockSql.append(" ,");

					sUpdateAccountFraudLockSql.append(sKey + "=?");
					nIndex++;
				}
			}

			String whereClause = "sor_id = ? AND sor_invariant_id = ? ";
			sUpdateAccountFraudLockSql.append(" WHERE " + whereClause);

			log.info("{}{}DB_H_UAFL_SQL000 : Query ={}", sClassName, sMethodName, sUpdateAccountFraudLockSql);

			nIndex = 0;
			objectList.add((String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));

			itr = ACCOUNT_FRAUD_LOCK_UPDATBLE_ATTRS.iterator();
			while (itr.hasNext()) {
				sKey = (String) itr.next();

				if (hmInput.containsKey(sKey)) {
					nIndex++;
					objectList.add((String) hmInput.get(sKey));

				}
			}

			objectList.add(sorId);
			objectList.add(sSorInvariantId);

			int rowCount = jdbcTemplate.update(new String(sUpdateAccountFraudLockSql),
					objectList.toArray(new Object[objectList.size()]));

			if (rowCount == 0) {
				sAppInfo = "No Record found for given sor and sor_invariant_id";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, "Record not found in the DB");
				log.info("{}{}DB_H_UAFL_07 : {}", sClassName, sMethodName, sAppInfo);
			} else {
				sAppInfo = "ACCOUNTFRAUDLOCK attributes updated successfully ";
				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, sAppInfo);
				log.info("{}{}DB_H_UAFL_08 : {}", sClassName, sMethodName, sAppInfo);
			}
		}

		catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DB_H_UAFL_E2 : Error::{}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}DB_H_UAFL_E3 : Exception = {}", sClassName, sMethodName, e);

		} finally {
			log.info(SpiMarker.getInstance(),"{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;

	}

	/**
	 * This method deletes an account's fraud lock information from the database.
	 * It takes a HashMap as an argument which contains the details of the account's fraud lock information to be deleted.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.DB_SOR_INVARIANT_ID: The invariant ID of the system of record (SOR).
	 * - MPSDefs.DB_SOR_NAME: The name of the SOR (optional).
	 * - MPSDefs.DB_SOR_ID: The ID of the SOR (optional).
	 *
	 * The method first logs the start of the operation and the input parameters.
	 * It then checks if the necessary information is present in the input HashMap.
	 * If any necessary information is missing, it logs an error and returns an error status.
	 * Otherwise, it prepares the SQL query for deleting the account's fraud lock information and executes it using the jdbcTemplate object.
	 * If the operation is successful, the method returns a HashMap containing the status of the operation and the number of rows deleted.
	 * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
	 *
	 * @param hmInput A HashMap containing the details of the account's fraud lock information to be deleted.
	 * @return A HashMap containing the status of the operation and the number of rows deleted.
	 */
	public HashMap deleteAccountFraudLock(HashMap hmInput) {

		String sMethodName = "deleteAccountFraudLock";
		HashMap hmResult = null;
		String sAppInfo = null;
		int sorId = -1;
		List<Object> objectList = CommonUtil.getArrayList();

		String sDeleteAccountFraudLockSql = "DELETE from ACCOUNTFRAUDLOCK where sor_id = ? AND sor_invariant_id = ?";

		log.info(ProfileOrchestrationConstants.LOG_DBTOOLS000, sClassName, sMethodName, hmInput);

		try {

			if (hmInput == null) {
				hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_INVALID_DATA_NUM, ProfileOrchestrationConstants.APP_INFO_INPUT_HASH_EMPTY);
				log.info("{}{}DB_H_DAFL03 : {}", sClassName, sMethodName, ProfileOrchestrationConstants.APP_INFO_INPUT_HASH_EMPTY);
				return hmResult;
			}

			String sSorInvariantId = (String) hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
			String stSorId = (String) hmInput.get(MPSDefs.DB_SOR_ID);
			String stSorName = (String) hmInput.get(MPSDefs.DB_SOR_NAME);

			if (sSorInvariantId == null || sSorInvariantId.isEmpty()) {
				sAppInfo = "sor_invariant_id is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
				log.info("{}{}DB_H_DAFL04 : {}", sClassName, sMethodName, sAppInfo);
				return hmResult;
			}

			if ((stSorId == null || stSorId.isEmpty()) && (stSorName == null || stSorName.isEmpty())) {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
				log.info("{}{}DB_H_DAFL05 : {}", sClassName, sMethodName, APP_INFO_EMPTY);
				return hmResult;
			}

			if (stSorId != null && stSorId.trim().length() != 0) {
				sorId = Integer.parseInt(stSorId);
			} else {
				sorId = dBHelper.getSorId(stSorName);
			}

			if (sorId == -1) {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
				log.info("{}{}DB_H_DAFL06 : {}", sClassName, sMethodName, APP_INFO_NOT_VALID);
				return hmResult;
			}

			log.info("{}{}DB_H_DAFL_SQL000 : deleteAccountFraudLockSql = {}", sClassName, sMethodName, sDeleteAccountFraudLockSql);

			objectList.add(sorId);
			objectList.add(sSorInvariantId);

			int iCount = jdbcTemplate.update(new String(sDeleteAccountFraudLockSql),
					objectList.toArray(new Object[objectList.size()]));

			log.info("{}{}DB_H_DAFL07 : No of rows deleted are : {}", sClassName, sMethodName, iCount);

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "No of rows deleted = " + iCount);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DBHLPE01 : Error:: {}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}DBHLPE02 : Exception = {}", sClassName, sMethodName, e);

		} finally {
			log.info(SpiMarker.getInstance(),"{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;

	}

	/**
	 * This method processes a list of user and account fraud lock operations.
	 * It takes a HashMap as an argument which contains the details of the operations to be processed.
	 * The HashMap should contain the following keys:
	 * - "userfraudlock": An ArrayList of HashMaps, each containing the details of a user fraud lock operation.
	 * - "accountfraudlock": An ArrayList of HashMaps, each containing the details of an account fraud lock operation.
	 *
	 * Each operation HashMap should contain the following keys:
	 * - MPSDefs.DB_OPERATION: The operation type. It can be "insert", "update", or "delete".
	 * - Other keys depending on the operation type and whether it's a user or account fraud lock operation.
	 *
	 * The method first logs the start of the operation and the input parameters.
	 * It then checks if the necessary information is present in the input HashMap.
	 * If any necessary information is missing, it logs an error and returns an error status.
	 * Otherwise, it iterates through the list of user fraud lock operations and processes each operation based on its type.
	 * It does the same for the list of account fraud lock operations.
	 * If all operations are processed successfully, the method returns a success status.
	 * If an error occurs during the processing of any operation, the method logs the error and returns an error status.
	 *
	 * @param hmInput A HashMap containing the details of the operations to be processed.
	 * @return A HashMap containing the status of the operation.
	 */
	public HashMap processData(HashMap hmInput) {

		String sMethodName = ".processData.";
		HashMap hmResult = null;
		String sAppStatusCode = null;
		String sAppInfo = null;

		log.info(ProfileOrchestrationConstants.LOG_DBTOOLS000, sClassName, sMethodName,
				(hmInput != null ? StringUtils.normalizeSpace(hmInput.toString()) : "null"));

		try {

			ArrayList alUserFraudLockOperations = (ArrayList) hmInput.get("userfraudlock");
			ArrayList alAcctFraudLockOperations = (ArrayList) hmInput.get("accountfraudlock");

			if ((alUserFraudLockOperations == null || alUserFraudLockOperations.isEmpty())
					&& (alAcctFraudLockOperations == null || alAcctFraudLockOperations.isEmpty())) {
				sAppInfo = "Both userfraudlock AND accountfraudlock lists are null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, sAppInfo);
				log.info("{}{}DBTOOLS02 : {}", sClassName, sMethodName, sAppInfo);
				return hmResult;
			}

			if (alUserFraudLockOperations != null && !alUserFraudLockOperations.isEmpty()) {
				for (int i = 0; i < alUserFraudLockOperations.size(); i++) {
					HashMap hmUserFraudLockOperation = (HashMap) alUserFraudLockOperations.get(i);

					if (hmUserFraudLockOperation != null && !hmUserFraudLockOperation.isEmpty()) {
						String sOperationType = (String) hmUserFraudLockOperation.get(MPSDefs.DB_OPERATION);

						if (sOperationType == null || sOperationType.length() <= 0) {
							sAppInfo = "operation type is null or empty in input";
							hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
							log.info("{}{}DBTOOLS03 : {}", sClassName, sMethodName, sAppInfo);
							return hmResult;
						}

						if (sOperationType.equalsIgnoreCase(MPSDefs.DB_OPERATION_INSERT)) {

							hmResult = addUserFraudLock(hmUserFraudLockOperation);
						} else if (sOperationType.equalsIgnoreCase(MPSDefs.DB_OPERATION_UPDATE)) {

							hmResult = updateUserFraudLock(hmUserFraudLockOperation);
						} else if (sOperationType.equalsIgnoreCase(MPSDefs.DB_OPERATION_DELETE)) {

							hmResult = deleteUserFraudLock(hmUserFraudLockOperation);
						} else {
							sAppInfo = sOperationType + ", operation type is invalid";
							hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, sAppInfo);
							log.info("{}{}DBTOOLS04 : {}", sClassName, sMethodName, sAppInfo);
							return hmResult;
						}

						sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
						if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
							return hmResult;
						}
					} else {
						sAppInfo = "userfraudlock operation HashMap is null or empty in input";
						hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
						log.info("{}{}DBTOOLS05 : {}", sClassName, sMethodName, sAppInfo);
						return hmResult;
					}

				} // end of for loop
			}

			// Iterate through ACCOUNTFRAUDLOCK operations list
			if (alAcctFraudLockOperations != null && !alAcctFraudLockOperations.isEmpty()) {
				for (int i = 0; i < alAcctFraudLockOperations.size(); i++) {
					HashMap hmAcctFraudLockOperation = (HashMap) alAcctFraudLockOperations.get(i);

					if (hmAcctFraudLockOperation != null && !hmAcctFraudLockOperation.isEmpty()) {
						String sOperationType = (String) hmAcctFraudLockOperation.get(MPSDefs.DB_OPERATION);

						if (sOperationType == null || sOperationType.length() <= 0) {
							sAppInfo = "operation type is null or empty in input";
							hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
							log.info("{}{}DBTOOLS06 : {}", sClassName, sMethodName, sAppInfo);
							return hmResult;
						}

						if (sOperationType.equalsIgnoreCase(MPSDefs.DB_OPERATION_INSERT)) {
							// Call local method to insert in ACCOUNTFRAUDLOCK table
							hmResult = addAccountFraudLock(hmAcctFraudLockOperation);
						} else if (sOperationType.equalsIgnoreCase(MPSDefs.DB_OPERATION_UPDATE)) {
							// Call local method to update in ACCOUNTFRAUDLOCK table
							hmResult = updateAccountFraudLock(hmAcctFraudLockOperation);
						} else if (sOperationType.equalsIgnoreCase(MPSDefs.DB_OPERATION_DELETE)) {
							// Call local method to delete from ACCOUNTFRAUDLOCK table
							hmResult = deleteAccountFraudLock(hmAcctFraudLockOperation);
						} else {
							sAppInfo = sOperationType + ", operation type is invalid";
							hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, sAppInfo);
							log.info("{}{}DBTOOLS07 : {}", sClassName, sMethodName, sAppInfo);
							return hmResult;
						}

						sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
						if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
							return hmResult;
						}
					} else {
						sAppInfo = "accountfraudlock operation HashMap is null or empty in input";
						hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO_MISSING_REQUIRED_FIELDS);
						log.info("{}{}DBTOOLS08 : {}", sClassName, sMethodName, sAppInfo);
						return hmResult;
					}

				} // end of for loop
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();

			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DBTOOLS_E1 : Error::{}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}DBTOOLS_E2 : Exception = {}", sClassName, sMethodName, e);

		} finally {

			log.info(SpiMarker.getInstance(),"{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);
		}

		return hmResult;
	}
}
