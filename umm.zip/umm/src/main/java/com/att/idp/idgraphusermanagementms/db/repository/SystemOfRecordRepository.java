package com.att.idp.idgraphusermanagementms.db.repository;

import java.sql.SQLException;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.att.idp.idgraphusermanagementms.db.model.Tsystemofrecord;

/**
 * This is the main repository interface for SystemOfRecord related operations.
 * It extends JpaRepository for standard CRUD operations and SystemOfRecordRepositoryCustom for custom operations.
 * The entity associated with this repository is Tsystemofrecord and the ID type is Long.
 */
@Repository 
public interface SystemOfRecordRepository extends JpaRepository<Tsystemofrecord, Long> , SystemOfRecordRepositoryCustom {
	
	
	/**
	 * This method is used to retrieve the System of Record ID for a given System of Record name from the database.
	 *
	 * @param sorName A string representing the System of Record name for which the ID is to be retrieved.
	 * @return A Long representing the System of Record ID associated with the given System of Record name.
	 * @throws SQLException If there is an error while executing the SQL query.
	 */
	@Query(value =  "select sor.SOR_ID from MPS_OWNER.TSYSTEMOFRECORD sor where sor.SOR_NAME=:sorName", nativeQuery=true)
	public Long getSorId(@Param(value = "sorName") String sorName) throws SQLException;
}
