package com.att.idp.idgraphusermanagementms.db.helper;

import com.att.mpsys.common.utils.*;
import lombok.Builder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.*;

/**
 * AbstractDBHelper is an abstract class that provides common database helper methods for user management services.
 * It includes methods to copy service data from a result set, process query responses, and calculate service statuses.
 * This class is intended to be extended by specific database helper implementations.
 * <p>
 * NOTE: This class has been created to encapsulate common database operations and reduce duplicate code.
 * Existing functionality or coding style has not been changed to avoid any regression.
 */
@Slf4j
public abstract class AbstractDBHelper {

    @Data
    @Builder
    public static class ProcessedQueryResponse {
        private HashMap<String, Object> memServices;
        private String dbBan;
        String memberNum;
        String dbMemberDomain;
        String slidMemberNum;
        boolean isSecurityAllYes;
    }

    protected boolean bSubEligibleServiceStatusRequired;
    protected boolean bSubEligibleSet;
    protected String sAggSubEligibleServiceStatus;

    private PropertyManagerLoader propertyManagerLoader;
    public AbstractDBHelper(PropertyManagerLoader propertyManagerLoader) {
        this.propertyManagerLoader = propertyManagerLoader;
    }

    @SuppressWarnings("unchecked")
    protected void copyServiceData(HashMap<String, Object> serviceHash, Map resultSet, HashMap<String, Object> hmMemberServiceRoles,
                         ArrayList alQueryRolesSvcList, HashMap hmMemberServiceAttributes) {
        // Add sor_invariant_id for each hash if value is not null - RK6538
        serviceHash.put(MPSDefs.DB_SOR_INVARIANT_ID, (String) resultSet.get(MPSDefs.DB_SOR_INVARIANT_ID));

        // added atlas_last_timestamp for LSR12 Feb 2010 - vs3652
        serviceHash.put(MPSDefs.DB_ATLAS_LAST_TIMESTAMP, (String) resultSet.get(MPSDefs.DB_ATLAS_LAST_TIMESTAMP));

        serviceHash.put(MPSDefs.DB_SERVICE_ID, (String) resultSet.get(MPSDefs.DB_SERVICE_ID));
        serviceHash.put(MPSDefs.DB_SERVICE_TYPE, (String) resultSet.get(MPSDefs.DB_SERVICE_TYPE));

        String serviceName = (String) resultSet.get(MPSDefs.DB_SERVICE_NAME);
        if (CommonDefs.SERVICE_VALUES.containsKey(serviceName)) {
            serviceHash.put(MPSDefs.DB_SERVICE_NAME, CommonDefs.SERVICE_VALUES.get(serviceName));
        } else {// 1610 - Updated for PID 287102 - for dynamic services , just pass the
            // serviceName as it in response
            serviceHash.put(MPSDefs.DB_SERVICE_NAME, serviceName);
        }

        serviceHash.put(MPSDefs.DB_MEMBER_STATUS_CODE, (String) resultSet.get(MPSDefs.DB_MEMBER_STATUS_CODE));
        serviceHash.put(MPSDefs.DB_GROUP_STATUS_CODE, (String) resultSet.get(MPSDefs.DB_GROUP_STATUS_CODE));
        serviceHash.put(MPSDefs.DB_GROUP_STATUS_NAME, (String) resultSet.get(MPSDefs.DB_GROUP_STATUS_NAME));
        serviceHash.put(MPSDefs.DB_MEMBER_STATUS_NAME, (String) resultSet.get(MPSDefs.DB_MEMBER_STATUS_NAME));
        serviceHash.put(MPSDefs.DB_MEMBER_TERMINATE_DATE, (String) resultSet.get(MPSDefs.DB_TERMINATE_DATE));
        serviceHash.put(MPSDefs.DB_CREATE_DATE, (String) resultSet.get(MPSDefs.DB_CREATE_DATE));
        serviceHash.put(MPSDefs.DB_LAST_MODIFIED, (String) resultSet.get(MPSDefs.DB_LAST_MODIFIED));
        serviceHash.put(MPSDefs.DB_LAST_MODIFIED_BY, (String) resultSet.get(MPSDefs.DB_LAST_MODIFIED_BY));
        serviceHash.put(MPSDefs.DB_PENDING_DISCONNECT_DATE, (String) resultSet.get(MPSDefs.DB_PENDING_DISCONNECT_DATE));
        // added for NAP by sk7243
        serviceHash.put(MPSDefs.DB_SOR_ID, (String) resultSet.get(MPSDefs.SERVICE_SOR_ID));
        serviceHash.put(MPSDefs.DB_SOR_NAME, (String) resultSet.get(MPSDefs.SERVICE_SOR_NAME));

        // added for LS R5 --rp6341
        String sSubaccountEligible = (String) resultSet.get(MPSDefs.DB_SUBACCOUNT_ELIGIBLE);
        serviceHash.put(MPSDefs.DB_SUBACCOUNT_ELIGIBLE, sSubaccountEligible);

        // added for LSR5 Oct by sm3878 on 6/12/2007
        serviceHash.put(MPSDefs.DB_EMAIL_ELIGIBLE, (String) resultSet.get(MPSDefs.DB_EMAIL_ELIGIBLE));

        if (bSubEligibleServiceStatusRequired && !bSubEligibleSet) {
            if (sSubaccountEligible.equals(MPSDefs.YES)) {
                String sServiceStatus = calculateStatus((String) resultSet.get(MPSDefs.DB_MEMBER_STATUS_NAME),
                        (String) resultSet.get(MPSDefs.DB_MEMBER_STATUS_NAME));
                if (sServiceStatus.equals(MPSDefs.ENABLED)) {
                    sAggSubEligibleServiceStatus = MPSDefs.ENABLED;
                    bSubEligibleSet = true;
                } else if (sServiceStatus.equals(MPSDefs.SUSPENDED)) {
                    sAggSubEligibleServiceStatus = MPSDefs.SUSPENDED;
                } else if (sServiceStatus.equals(MPSDefs.TERMINATED)) {
                    if ((sAggSubEligibleServiceStatus == null) || (sAggSubEligibleServiceStatus.trim().length() == 0)) {
                        sAggSubEligibleServiceStatus = MPSDefs.TERMINATED;
                    }
                }
            }
        }

        serviceHash.put(MPSDefs.DB_SERVICE_NICKNAME, (String) resultSet.get(MPSDefs.DB_SERVICE_NICKNAME));
        serviceHash.put(MPSDefs.DB_DEFAULT_ACCOUNT, (String) resultSet.get(MPSDefs.DB_DEFAULT_ACCOUNT));
        serviceHash.put(MPSDefs.DB_DATE_DEFAULT_EST, (String) resultSet.get(MPSDefs.DB_DATE_DEFAULT_EST));
        serviceHash.put(MPSDefs.DB_CPNI_IMPACTED, (String) resultSet.get(MPSDefs.DB_CPNI_IMPACTED));

        // added for June 2011 TITAN, SSO P2
        serviceHash.put(MPSDefs.DB_PARENT_SOR_ID, resultSet.get(MPSDefs.DB_PARENT_SOR_ID));
        serviceHash.put(MPSDefs.DB_PARENT_SOR_INVARIANT_ID, resultSet.get(MPSDefs.DB_PARENT_SOR_INVARIANT_ID));
        serviceHash.put(MPSDefs.DB_UVERSE_SERVICE_IND, resultSet.get(MPSDefs.DB_UVERSE_SERVICE_IND));
        serviceHash.put(MPSDefs.DB_MAJOR_SERVICE_ID, resultSet.get(MPSDefs.DB_MAJOR_SERVICE_ID));
        serviceHash.put(MPSDefs.DB_ENTITY_TYPE, resultSet.get(MPSDefs.DB_ENTITY_TYPE));

        // 1505 - Updated for Star project.
        serviceHash.put(MPSDefs.DB_UNIFICATION_PENDING, resultSet.get(MPSDefs.DB_UNIFICATION_PENDING));

        String sServiceName = (String) resultSet.get(MPSDefs.DB_SERVICE_NAME);
        String sSorInvariantId = (String) resultSet.get(MPSDefs.DB_SOR_INVARIANT_ID);

        if (sServiceName != null && sServiceName.equals("1544"))
            serviceHash.put(MPSDefs.DB_SUSPEND_REASON_CODE, resultSet.get(MPSDefs.DB_SUSPEND_REASON_CODE));

        // return roles under each service hash
        if (alQueryRolesSvcList != null && !alQueryRolesSvcList.isEmpty() && hmMemberServiceRoles != null
                && !hmMemberServiceRoles.isEmpty()) {
            String sProcessRoles = (String) alQueryRolesSvcList.get(0);

            if (sProcessRoles.equalsIgnoreCase("ALL")) {
                if (hmMemberServiceRoles.containsKey(sServiceName)) {
                    processRoles(serviceHash, hmMemberServiceRoles, sServiceName, sSorInvariantId);
                }
            } // end of ALL services
            else if (alQueryRolesSvcList.contains(sServiceName) && hmMemberServiceRoles.containsKey(sServiceName)) {
                processRoles(serviceHash, hmMemberServiceRoles, sServiceName, sSorInvariantId);
            }
        } // end of role processing

        // PID-310691e [2006][MPSYS-US3] - to return MEMBERSERVICEATTRIBUTE in response
        // for service, if present
        // changes by pm6756
        if (hmMemberServiceAttributes != null && hmMemberServiceAttributes.containsKey(serviceName)) {
            HashMap hmServiceAttribute = (HashMap) hmMemberServiceAttributes.get(serviceName);
            if (hmServiceAttribute != null) {
                String sDBSorInvId = (String) resultSet.get(MPSDefs.DB_SOR_INVARIANT_ID);

                if (sDBSorInvId != null && hmServiceAttribute.containsKey(sDBSorInvId)) {
                    ArrayList alSvcAttributes = (ArrayList) hmServiceAttribute.get(sDBSorInvId);
                    if (alSvcAttributes != null && !alSvcAttributes.isEmpty()) {
                        serviceHash.put(MPSDefs.DB_MEMBER_SERVICE_ATTRIBUTE, alSvcAttributes);
                    }
                }
            }
        } // END

    } // end copyServiceData

    private void processRoles(HashMap<String, Object> serviceHash, HashMap<String, Object> hmMemberServiceRoles,
                                     String sServiceName, String sSorInvariantId) {
        ArrayList alRoles = (ArrayList) hmMemberServiceRoles.get(sServiceName);
        if (alRoles != null && !alRoles.isEmpty()) {
            ArrayList alUpdRoleList = new ArrayList();
            for (int j = 0; j < alRoles.size(); j++) {
                HashMap hmEachRole = (HashMap) alRoles.get(j);
                if (hmEachRole != null) {
                    String sRoleSorInvariantId = (String) hmEachRole.get(MPSDefs.DB_SOR_INVARIANT_ID);
                    if (sRoleSorInvariantId != null && sRoleSorInvariantId.equals(sSorInvariantId))
                        alUpdRoleList.add(hmEachRole);
                }
            } // end of for loop
            if (alUpdRoleList != null && !alUpdRoleList.isEmpty())
                serviceHash.put(MPSDefs.DB_ROLES, alUpdRoleList);
        }
    }

    /**
     * Processes the query response and returns a ProcessedQueryResponse object.
     *
     * @param hmQueryResponse The query response map containing member details.
     * @param inputParamHs    The input parameters map containing security request details.
     * @return A ProcessedQueryResponse object containing processed member services and other details.
     * @throws Exception If an error occurs during processing.
     */
    protected ProcessedQueryResponse processQueryResponse(Map hmQueryResponse, Map inputParamHs) throws Exception {
        HashMap<String, Object> memServices = CommonUtil.getHashMap();
        String dbBan;
        String sMemberNum;
        String sDbMemberDomain;
        String sSlidMemberNum;
        boolean bIsSecurityAllYes = false;

        memServices.put(MPSDefs.SQLCODE, MPSDefs.SQL_SUCCESS);
        memServices.put(MPSDefs.SQLMSG, MPSDefs.SQL_SUCCESS_MSG);

        dbBan = (String) hmQueryResponse.get(MPSDefs.DB_BAN);
        memServices.put(MPSDefs.DB_BAN, dbBan);

        memServices.put(MPSDefs.DB_DELETE_REQUEST_DATE,
                (String) hmQueryResponse.get(MPSDefs.DB_DELETE_REQUEST_DATE));
        memServices.put(MPSDefs.DB_TOKEN, (String) hmQueryResponse.get(MPSDefs.DB_TOKEN));

        memServices.put(MPSDefs.DB_REMARKS, (String) hmQueryResponse.get(MPSDefs.DB_REMARKS));

        sMemberNum = (String) hmQueryResponse.get(MPSDefs.DB_MEMBER_NUM);
        memServices.put(MPSDefs.DB_MEMBER_NUM, (String) hmQueryResponse.get(MPSDefs.DB_MEMBER_NUM));
        memServices.put(MPSDefs.DB_MEMBER_NAME, (String) hmQueryResponse.get(MPSDefs.DB_MEMBER_NAME));

        sDbMemberDomain = (String) hmQueryResponse.get(MPSDefs.DB_DOMAIN_NAME);

        memServices.put(MPSDefs.DB_GROUP_NUM, (String) hmQueryResponse.get(MPSDefs.DB_GROUP_NUM));
        memServices.put(MPSDefs.DB_DOMAIN_NAME, (String) hmQueryResponse.get(MPSDefs.DB_DOMAIN_NAME));
        memServices.put(MPSDefs.DB_DOMAIN_ID, (String) hmQueryResponse.get(MPSDefs.DB_DOMAIN_ID));
        memServices.put(MPSDefs.DB_ENC_PASSWORD, (String) hmQueryResponse.get(MPSDefs.DB_ENC_PASSWORD));
        memServices.put(MPSDefs.DB_MD5_PASSWORD, (String) hmQueryResponse.get(MPSDefs.DB_MD5_PASSWORD));

        memServices.put(MPSDefs.DB_PARENT_CHILD_IND,
                (String) hmQueryResponse.get(MPSDefs.DB_PARENT_CHILD_IND));
        memServices.put(MPSDefs.DB_MEMBER_STATE, (String) hmQueryResponse.get(MPSDefs.DB_MEMBER_STATE));
        memServices.put(MPSDefs.DB_AGG_ACCESS_STATUS,
                (String) hmQueryResponse.get(MPSDefs.DB_AGG_ACCESS_STATUS));
        memServices.put(MPSDefs.DB_AGG_SERVICE_STATUS,
                (String) hmQueryResponse.get(MPSDefs.DB_AGG_SERVICE_STATUS));
        memServices.put(MPSDefs.DB_MAILHOST, (String) hmQueryResponse.get(MPSDefs.DB_MAILHOST));
        memServices.put(MPSDefs.DB_FULLNAME, (String) hmQueryResponse.get(MPSDefs.DB_FULLNAME));
        memServices.put(MPSDefs.DB_ACCOUNT_TYPE, (String) hmQueryResponse.get(MPSDefs.DB_ACCOUNT_TYPE));
        memServices.put(MPSDefs.DB_OPTOUT_IND, (String) hmQueryResponse.get(MPSDefs.DB_OPTOUT_IND));
        memServices.put(MPSDefs.DB_MIGRATION_IND, (String) hmQueryResponse.get(MPSDefs.DB_MIGRATION_IND));
        memServices.put(MPSDefs.DB_MIGRATION_DATE, (String) hmQueryResponse.get(MPSDefs.DB_MIGRATION_DATE));
        memServices.put(MPSDefs.DB_PARENT_NAME, (String) hmQueryResponse.get(MPSDefs.DB_PARENT_NAME));
        memServices.put(MPSDefs.DB_PARENT_DOMAIN, (String) hmQueryResponse.get(MPSDefs.DB_PARENT_DOMAIN)); // Added
        // for
        // NAP8
        memServices.put(MPSDefs.DB_PREMIUM_800_IND,
                (String) hmQueryResponse.get(MPSDefs.DB_PREMIUM_800_IND));

        memServices.put(MPSDefs.DB_BULK_BILLING_IND,
                (String) hmQueryResponse.get(MPSDefs.DB_BULK_BILLING_IND));
        memServices.put(MPSDefs.DB_ACCESS_CODE, (String) hmQueryResponse.get(MPSDefs.DB_ACCESS_CODE));
        memServices.put(MPSDefs.DB_SOR_ID, (String) hmQueryResponse.get(MPSDefs.DB_SOR_ID));
        memServices.put(MPSDefs.DB_SOR_NAME, (String) hmQueryResponse.get(MPSDefs.DB_SOR_NAME));
        memServices.put(MPSDefs.DB_ACCESS_ID, (String) hmQueryResponse.get(MPSDefs.DB_ACCESS_ID));
        memServices.put(MPSDefs.DB_ACCESS_NAME, (String) hmQueryResponse.get(MPSDefs.DB_ACCESS_NAME));
        memServices.put(MPSDefs.DB_CREATE_DATE, (String) hmQueryResponse.get("mem_create_date"));
        memServices.put(MPSDefs.DB_LAST_MODIFIED, (String) hmQueryResponse.get("mem_last_modified"));
        memServices.put(MPSDefs.DB_LAST_MODIFIED_BY,
                (String) hmQueryResponse.get(MPSDefs.DB_LAST_MODIFIED_BY));

        memServices.put(MPSDefs.DB_SHA1_PASSWORD, (String) hmQueryResponse.get(MPSDefs.DB_SHA1_PASSWORD));

        memServices.put(MPSDefs.DB_DES3_PASSWORD, (String) hmQueryResponse.get(MPSDefs.DB_DES3_PASSWORD));
        memServices.put(MPSDefs.DB_FAILED_AUTH_COUNT,
                (String) hmQueryResponse.get(MPSDefs.DB_FAILED_AUTH_COUNT));
        memServices.put(MPSDefs.DB_PASSWORD_DIRTY, (String) hmQueryResponse.get(MPSDefs.DB_PASSWORD_DIRTY));
        memServices.put(MPSDefs.DB_CONTACT_EMAIL, (String) hmQueryResponse.get(MPSDefs.DB_CONTACT_EMAIL));
        memServices.put(MPSDefs.DB_CONTACT_EMAIL_VALID,
                (String) hmQueryResponse.get(MPSDefs.DB_CONTACT_EMAIL_VALID));

        memServices.put(MPSDefs.DB_LANGUAGE, (String) hmQueryResponse.get(MPSDefs.DB_LANGUAGE));

        memServices.put(MPSDefs.DB_TOS_REJECT_DATE,
                (String) hmQueryResponse.get(MPSDefs.DB_TOS_REJECT_DATE));
        memServices.put(MPSDefs.DB_NUM_TOS_REJECTS,
                (String) hmQueryResponse.get(MPSDefs.DB_NUM_TOS_REJECTS));
        memServices.put(MPSDefs.DB_ALERT_IND, (String) hmQueryResponse.get(MPSDefs.DB_ALERT_IND));

        memServices.put(MPSDefs.DB_CREDIT_CHECKED_IND,
                (String) hmQueryResponse.get(MPSDefs.DB_CREDIT_CHECKED_IND));
        memServices.put(MPSDefs.DB_YREG_COMPLETE_IND,
                (String) hmQueryResponse.get(MPSDefs.DB_YREG_COMPLETE_IND));
        memServices.put(MPSDefs.DB_LOCKOUT_TIMESTAMP,
                (String) hmQueryResponse.get(MPSDefs.DB_LOCKOUT_TIMESTAMP));
        memServices.put(MPSDefs.DB_LC_FIRSTNAME, (String) hmQueryResponse.get(MPSDefs.DB_LC_FIRSTNAME));
        memServices.put(MPSDefs.DB_LC_LASTNAME, (String) hmQueryResponse.get(MPSDefs.DB_LC_LASTNAME));
        memServices.put(MPSDefs.DB_NICKNAME, (String) hmQueryResponse.get(MPSDefs.DB_NICKNAME));
        memServices.put(MPSDefs.DB_GENDER, (String) hmQueryResponse.get(MPSDefs.DB_GENDER));

        memServices.put(MPSDefs.DB_PROOFING_ZIP,
                CommonUtil.addHyphenInZIP((String) hmQueryResponse.get(MPSDefs.DB_PROOFING_ZIP)));

        memServices.put(MPSDefs.DB_LAST_MEMBER_STATUS_NAME,
                (String) hmQueryResponse.get(MPSDefs.DB_LAST_MEMBER_STATUS_NAME));
        memServices.put(MPSDefs.DB_LAST_MEMBER_STATUS_CODE,
                (String) hmQueryResponse.get(MPSDefs.DB_LAST_MEMBER_STATUS_CODE));

        memServices.put(MPSDefs.DB_AGG_EMAIL_STATUS,
                (String) hmQueryResponse.get(MPSDefs.DB_AGG_EMAIL_STATUS));
        memServices.put(MPSDefs.DB_CONTACT_EMAIL_EST_DATE,
                (String) hmQueryResponse.get(MPSDefs.DB_CONTACT_EMAIL_EST_DATE));

        memServices.put(MPSDefs.DB_PREVIOUS_CONTACT_EMAIL,
                (String) hmQueryResponse.get(MPSDefs.DB_PREVIOUS_CONTACT_EMAIL));

        memServices.put(MPSDefs.DB_CSR_INITIATED_LOCKOUT_TS,
                (String) hmQueryResponse.get(MPSDefs.DB_CSR_INITIATED_LOCKOUT_TS));
        memServices.put(MPSDefs.DB_BROWSER_LANGUAGE,
                (String) hmQueryResponse.get(MPSDefs.DB_BROWSER_LANGUAGE));

        memServices.put(MPSDefs.DB_DSL_NET_PASSWORD,
                (String) hmQueryResponse.get(MPSDefs.DB_DSL_NET_PASSWORD));
        memServices.put(MPSDefs.DB_DSL_NET_ENCR_TYPE,
                (String) hmQueryResponse.get(MPSDefs.DB_DSL_NET_ENCR_TYPE));
        memServices.put(MPSDefs.DB_CONTACT_EMAIL_STATUS,
                (String) hmQueryResponse.get(MPSDefs.DB_CONTACT_EMAIL_STATUS));
        memServices.put(MPSDefs.DB_SSHA_PASSWORD, (String) hmQueryResponse.get(MPSDefs.DB_SSHA_PASSWORD));

        sSlidMemberNum = (String) hmQueryResponse.get(MPSDefs.DB_SLID_MEMBER_NUM);
        memServices.put(MPSDefs.DB_SLID_MEMBER_NUM, sSlidMemberNum);

        memServices.put(MPSDefs.DB_AUTOGENERATED_IND,
                (String) hmQueryResponse.get(MPSDefs.DB_AUTOGENERATED_IND));
        memServices.put(MPSDefs.DB_ACTIVATED_IND, (String) hmQueryResponse.get(MPSDefs.DB_ACTIVATED_IND));

        memServices.put(MPSDefs.DB_BIRTHDATE_VENC, (String) hmQueryResponse.get(MPSDefs.DB_BIRTHDATE_VENC));
        memServices.put(MPSDefs.DB_PASSCODE_VENC, (String) hmQueryResponse.get(MPSDefs.DB_PASSCODE_VENC));
        memServices.put(MPSDefs.DB_SECURITY_ANSWER_VENC,
                (String) hmQueryResponse.get(MPSDefs.DB_SECURITY_ANSWER_VENC));

        memServices.put(MPSDefs.DB_LAST_VERIFIED, (String) hmQueryResponse.get(MPSDefs.DB_LAST_VERIFIED));

        memServices.put(MPSDefs.DB_CREATED_BY, (String) hmQueryResponse.get(MPSDefs.DB_CREATED_BY));

        memServices.put(MPSDefs.DB_MAIN_CTN_OPT_OUT,
                (String) hmQueryResponse.get(MPSDefs.DB_MAIN_CTN_OPT_OUT));

        memServices.put(MPSDefs.DB_ONL_QA_EST_DATE,
                (String) hmQueryResponse.get(MPSDefs.DB_ONL_QA_EST_DATE));
        memServices.put(MPSDefs.DB_ENC_PASSWORD_VENC,
                (String) hmQueryResponse.get(MPSDefs.DB_ENC_PASSWORD_VENC));
        memServices.put(MPSDefs.DB_MD5_PASSWORD_VENC,
                (String) hmQueryResponse.get(MPSDefs.DB_MD5_PASSWORD_VENC));
        memServices.put(MPSDefs.DB_SHA1_PASSWORD_VENC,
                (String) hmQueryResponse.get(MPSDefs.DB_SHA1_PASSWORD_VENC));
        memServices.put(MPSDefs.DB_DES3_PASSWORD_VENC,
                (String) hmQueryResponse.get(MPSDefs.DB_DES3_PASSWORD_VENC));
        memServices.put(MPSDefs.DB_SSHA_PASSWORD_VENC,
                (String) hmQueryResponse.get(MPSDefs.DB_SSHA_PASSWORD_VENC));
        memServices.put(MPSDefs.DB_RECENT_FRAUD_PW_DATE,
                (String) hmQueryResponse.get(MPSDefs.DB_RECENT_FRAUD_PW_DATE)); // 1808 : PID 304635
        // 2103 - SSHA-256 encryption changes
        String genericPasswordEncryptionType = PropertyManager.getProperty(CommonDefs.MOUPConfig,
                CommonDefs.GENERIC_PASSWORD_ENCRYPTION_TYPE);
        if (genericPasswordEncryptionType != null && !genericPasswordEncryptionType.isEmpty()) {
            memServices.put(MPSDefs.DB_GEN_PASSWORD_VENC,
                    (String) hmQueryResponse.get(MPSDefs.DB_GEN_PASSWORD_VENC)); // R2011:PWD encryption
            memServices.put(MPSDefs.DB_GEN_PASSWORD_TYPE,
                    (String) hmQueryResponse.get(MPSDefs.DB_GEN_PASSWORD_TYPE)); // R2011:PWD encryption
        }

//						[R2110]- :PID#400970c - Added for FN users
        if (hmQueryResponse.get(CommonDefs.DB_FN_LINKED_USERID) != null
                && !((String) hmQueryResponse.get(CommonDefs.DB_FN_LINKED_USERID)).isEmpty()) {
            memServices.put(CommonDefs.DB_FN_LINKED_USERID,
                    (String) hmQueryResponse.get(CommonDefs.DB_FN_LINKED_USERID));
        }
        if (hmQueryResponse.get(CommonDefs.DB_FN_LINKED_STATUS) != null
                && !((String) hmQueryResponse.get(CommonDefs.DB_FN_LINKED_STATUS)).isEmpty()) {
            memServices.put(CommonDefs.DB_FN_LINKED_STATUS,
                    (String) hmQueryResponse.get(CommonDefs.DB_FN_LINKED_STATUS));
        }

        // add security fields based on the input - LSR3
        if (inputParamHs.containsKey(MPSDefs.SECURITY_ALL_REQ)) {
            String sSecReqVal = (String) inputParamHs.get(MPSDefs.SECURITY_ALL_REQ);
            if (sSecReqVal != null && sSecReqVal.equalsIgnoreCase("Y")) {
                bIsSecurityAllYes = true;

                memServices.put(MPSDefs.DB_LAST_FOUR_SSN,
                        (String) hmQueryResponse.get(MPSDefs.DB_LAST_FOUR_SSN));
                memServices.put(MPSDefs.DB_SECURITY_QUESTION,
                        (String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION));
                memServices.put("security_question_id",
                        (String) hmQueryResponse.get("security_question_id"));

                memServices.put(MPSDefs.DB_SECURITY_QUESTION_TYPE,
                        (String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_TYPE));
                memServices.put(MPSDefs.DB_SECURITY_QUESTION_ACTIVE,
                        (String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_ACTIVE));
                memServices.put(MPSDefs.DB_SECURITY_QUESTION_ID_1,
                        (String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_ID_1));
                memServices.put(MPSDefs.DB_SECURITY_QUESTION_1,
                        (String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_1));
                memServices.put(MPSDefs.DB_SECURITY_ANSWER_1,
                        (String) hmQueryResponse.get(MPSDefs.DB_SECURITY_ANSWER_1));
                memServices.put(MPSDefs.DB_SECURITY_QUESTION_1_TYPE,
                        (String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_1_TYPE));
                memServices.put(MPSDefs.DB_SECURITY_QUESTION_1_ACTIVE,
                        (String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_1_ACTIVE));
                memServices.put(MPSDefs.DB_SECURITY_QUESTION_ID_2,
                        (String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_ID_2));
                memServices.put(MPSDefs.DB_SECURITY_QUESTION_2,
                        (String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_2));
                memServices.put(MPSDefs.DB_SECURITY_ANSWER_2,
                        (String) hmQueryResponse.get(MPSDefs.DB_SECURITY_ANSWER_2));
                memServices.put(MPSDefs.DB_SECURITY_QUESTION_2_TYPE,
                        (String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_2_TYPE));
                memServices.put(MPSDefs.DB_SECURITY_QUESTION_2_ACTIVE,
                        (String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_2_ACTIVE));
                memServices.put(MPSDefs.DB_SECURITY_ANSWER_1_VENC,
                        (String) hmQueryResponse.get(MPSDefs.DB_SECURITY_ANSWER_1_VENC));
                memServices.put(MPSDefs.DB_SECURITY_ANSWER_2_VENC,
                        (String) hmQueryResponse.get(MPSDefs.DB_SECURITY_ANSWER_2_VENC));
            }
        }

        return ProcessedQueryResponse.builder()
                .memServices(memServices)
                .dbBan(dbBan)
                .memberNum(sMemberNum)
                .dbMemberDomain(sDbMemberDomain)
                .slidMemberNum(sSlidMemberNum)
                .isSecurityAllYes(bIsSecurityAllYes)
                .build();
    }

    /**
     * Calculates the status based on member and group statuses.
     * This method determines the overall status by comparing the member status and group status.
     * It returns the appropriate status based on the following conditions:
     * - If both member and group statuses are "ENABLED", the status is "ENABLED".
     * - If either member or group status is "TERMINATED", the status is "TERMINATED".
     * - If either member or group status is "SUSPENDED", the status is "SUSPENDED".
     * - If either member or group status is "PENDING", the status is "PENDING".
     *
     * @param memberStatus The status of the member.
     * @param groupStatus The status of the group.
     * @return The calculated status.
     */
    protected String calculateStatus(String memberStatus, String groupStatus) {

        String status = "";
        if (groupStatus.equalsIgnoreCase(MPSDefs.ENABLED) && memberStatus.equalsIgnoreCase(MPSDefs.ENABLED)) {
            status = MPSDefs.ENABLED;
        } else {
            if (groupStatus.equalsIgnoreCase(MPSDefs.TERMINATED) || memberStatus.equalsIgnoreCase(MPSDefs.TERMINATED))
                status = MPSDefs.TERMINATED;
            else if (groupStatus.equalsIgnoreCase(MPSDefs.SUSPENDED)
                    || memberStatus.equalsIgnoreCase(MPSDefs.SUSPENDED))
                status = MPSDefs.SUSPENDED;
            else if (groupStatus.equalsIgnoreCase(MPSDefs.PENDING) || memberStatus.equalsIgnoreCase(MPSDefs.PENDING))
                status = MPSDefs.PENDING;
        }
        return status;
    }

    protected void processPORTAL(HashMap inputParamHs, HashMap<String, Object> userServiceHash, Map hmQueryResponse) {
        userServiceHash.put(MPSDefs.DB_PORTAL_PROVIDER,
                (String) hmQueryResponse.get(MPSDefs.DB_PORTAL_PROVIDER));

        // Added for April PLITE feature by vs3652
        userServiceHash.put(MPSDefs.DB_PLITE_IND,
                (String) hmQueryResponse.get(MPSDefs.DB_PLITE_IND));

        if (inputParamHs.containsKey(MPSDefs.WS_PORTAL_PROVIDER_UPDATE_DATE)) {
            String sPortalProviderLastModifiedDate = (String) inputParamHs
                    .get(MPSDefs.WS_PORTAL_PROVIDER_UPDATE_DATE);
            if (sPortalProviderLastModifiedDate != null
                    && sPortalProviderLastModifiedDate.equals(MPSDefs.YES)) {
                userServiceHash.put(MPSDefs.DB_PORTAL_PROVIDER_LAST_MODIFIED,
                        (String) hmQueryResponse.get(MPSDefs.DB_PORTAL_PROVIDER_LAST_MODIFIED));
                // Returning PORTALUSER.CREATE_DATE and LAST_MODIFIED_BY - NAP9 - June'09 -
                // RK6538
                userServiceHash.put(MPSDefs.DB_PORTAL_PROVIDER_CREATE_DATE,
                        (String) hmQueryResponse.get(MPSDefs.DB_PORTAL_PROVIDER_CREATE_DATE));
                userServiceHash.put(MPSDefs.DB_PORTAL_PROVIDER_LAST_MODIFIED_BY,
                        (String) hmQueryResponse.get(MPSDefs.DB_PORTAL_PROVIDER_LAST_MODIFIED_BY));
            } // end of if request has flag to send the above info
        }
    }

    protected void processWIFI(String sMemberNum, HashMap<String, Object> userServiceHash, JdbcTemplate jdbcTemplate, String queryWIFIUserSql) {
        List<Object> objectListWIFIUser = new ArrayList<Object>();
        objectListWIFIUser.add(sMemberNum);

        List alQueryWIFIUserResp = jdbcTemplate.queryForList(new String(queryWIFIUserSql),
                objectListWIFIUser.toArray(new Object[objectListWIFIUser.size()]));

        if (!alQueryWIFIUserResp.isEmpty()) {
            Map hmQueryWIFIUserResp = (Map) alQueryWIFIUserResp.get(0);

            if (hmQueryWIFIUserResp != null && !hmQueryWIFIUserResp.isEmpty()) {
                Iterator iter = hmQueryWIFIUserResp.keySet().iterator();
                while (iter.hasNext()) {
                    String key = (String) iter.next();
                    Object value = hmQueryWIFIUserResp.get(key);

                    String strValue = (value == null ? null : value.toString());

                    hmQueryWIFIUserResp.put(key, strValue);
                }
                userServiceHash.put(MPSDefs.DB_WIFI_SERVICE_TYPE,
                        hmQueryWIFIUserResp.get(MPSDefs.DB_WIFI_SERVICE_TYPE));
                userServiceHash.put(MPSDefs.DB_ROAMING_BLOCK_IND,
                        hmQueryWIFIUserResp.get(MPSDefs.DB_ROAMING_BLOCK_IND));
                userServiceHash.put(MPSDefs.DB_WIFI_USER_CREATE_DATE,
                        hmQueryWIFIUserResp.get(MPSDefs.DB_WIFI_USER_CREATE_DATE));
                userServiceHash.put(MPSDefs.DB_WIFI_USER_LAST_MODIFIED,
                        hmQueryWIFIUserResp.get(MPSDefs.DB_WIFI_USER_LAST_MODIFIED));
                userServiceHash.put(MPSDefs.DB_WIFI_USER_LAST_MODIFIED_BY,
                        hmQueryWIFIUserResp.get(MPSDefs.DB_WIFI_USER_LAST_MODIFIED_BY));
            }
        } else {
            log.info("DBTOOLS18 : No record found in WIFIUSER table");
        }
    }

    protected void processISDN(String sMemberNum, HashMap<String, Object> userServiceHash, JdbcTemplate jdbcTemplate, String queryISDNUserSql) {
        List<Object> objectListISDNUser = new ArrayList<Object>();
        objectListISDNUser.add(sMemberNum);

        List alQueryISDNUserResp = jdbcTemplate.queryForList(new String(queryISDNUserSql),
                objectListISDNUser.toArray(new Object[objectListISDNUser.size()]));

        if (!alQueryISDNUserResp.isEmpty()) {
            Map hmQueryISDNUserResp = (Map) alQueryISDNUserResp.get(0);

            if (hmQueryISDNUserResp != null && !hmQueryISDNUserResp.isEmpty()) {
                Iterator iter = hmQueryISDNUserResp.keySet().iterator();
                while (iter.hasNext()) {
                    String key = (String) iter.next();
                    Object value = hmQueryISDNUserResp.get(key);

                    String strValue = (value == null ? null : value.toString());

                    hmQueryISDNUserResp.put(key, strValue);
                }
                userServiceHash.put(MPSDefs.DB_IP_ADDRESS,
                        hmQueryISDNUserResp.get(MPSDefs.DB_IP_ADDRESS));
                userServiceHash.put(MPSDefs.DB_IP_NETBLOCK,
                        hmQueryISDNUserResp.get(MPSDefs.DB_IP_NETBLOCK));
                userServiceHash.put(MPSDefs.DB_IP_SUBNET,
                        hmQueryISDNUserResp.get(MPSDefs.DB_IP_SUBNET));
                userServiceHash.put(MPSDefs.DB_NETWORK_PROFILE_NAME,
                        hmQueryISDNUserResp.get(MPSDefs.DB_NETWORK_PROFILE_NAME));
                userServiceHash.put(MPSDefs.DB_NETWORK_PROFILE_ID,
                        hmQueryISDNUserResp.get(MPSDefs.DB_NETWORK_PROFILE_ID));
                userServiceHash.put(MPSDefs.ISDN_USER_CREATE_DATE,
                        hmQueryISDNUserResp.get(MPSDefs.ISDN_USER_CREATE_DATE));
                userServiceHash.put(MPSDefs.ISDN_USER_LAST_MODIFIED,
                        hmQueryISDNUserResp.get(MPSDefs.ISDN_USER_LAST_MODIFIED));
                userServiceHash.put(MPSDefs.ISDN_USER_LAST_MODIFIED_BY,
                        hmQueryISDNUserResp.get(MPSDefs.ISDN_USER_LAST_MODIFIED_BY));
            }
        } else {
            log.info("DBTOOLS17 : No record found in ISDNUSER table");
        }
    }

    protected void processDIAL(String sMemberNum, HashMap<String, Object> userServiceHash, JdbcTemplate jdbcTemplate, String queryDIALUserSql) {
        List<Object> objectListDialUser = new ArrayList<Object>();
        objectListDialUser.add(sMemberNum);

        List alQueryDialUserResp = jdbcTemplate.queryForList(new String(queryDIALUserSql),
                objectListDialUser.toArray(new Object[objectListDialUser.size()]));

        if (!alQueryDialUserResp.isEmpty()) {
            Map hmQueryDialUserResp = (Map) alQueryDialUserResp.get(0);

            if (hmQueryDialUserResp != null && !hmQueryDialUserResp.isEmpty()) {
                Iterator iter = hmQueryDialUserResp.keySet().iterator();
                while (iter.hasNext()) {
                    String key = (String) iter.next();
                    Object value = hmQueryDialUserResp.get(key);

                    String strValue = (value == null ? null : value.toString());

                    hmQueryDialUserResp.put(key, strValue);
                }
                userServiceHash.put(MPSDefs.DIAL_USER_CREATE_DATE,
                        hmQueryDialUserResp.get(MPSDefs.DIAL_USER_CREATE_DATE));
                userServiceHash.put(MPSDefs.DIAL_USER_LAST_MODIFIED,
                        hmQueryDialUserResp.get(MPSDefs.DIAL_USER_LAST_MODIFIED));
                userServiceHash.put(MPSDefs.DIAL_USER_LAST_MODIFIED_BY,
                        hmQueryDialUserResp.get(MPSDefs.DIAL_USER_LAST_MODIFIED_BY));
                userServiceHash.put(MPSDefs.DB_NETWORK_PROFILE_NAME,
                        hmQueryDialUserResp.get(MPSDefs.DB_NETWORK_PROFILE_NAME));
                userServiceHash.put(MPSDefs.DB_NETWORK_PROFILE_ID,
                        hmQueryDialUserResp.get(MPSDefs.DB_NETWORK_PROFILE_ID));
            }
        } else {
            log.info("DBTOOLS16 : No record found in DIALUSER table");
        }
    }

    protected void processDSL(String sMemberNum, HashMap<String, Object> userServiceHash, JdbcTemplate jdbcTemplate, String queryDSLUserSql) {
        List<Object> objectListDSLUser = new ArrayList<Object>();
        objectListDSLUser.add(sMemberNum);

        List alQueryDSLUserResp = jdbcTemplate.queryForList(new String(queryDSLUserSql),
                objectListDSLUser.toArray(new Object[objectListDSLUser.size()]));

        if (!alQueryDSLUserResp.isEmpty()) {
            Map hmQueryDSLUserResp = (Map) alQueryDSLUserResp.get(0);

            if (hmQueryDSLUserResp != null && !hmQueryDSLUserResp.isEmpty()) {
                Iterator iter = hmQueryDSLUserResp.keySet().iterator();
                while (iter.hasNext()) {
                    String key = (String) iter.next();
                    Object value = hmQueryDSLUserResp.get(key);

                    String strValue = (value == null ? null : value.toString());

                    hmQueryDSLUserResp.put(key, strValue);
                }
                userServiceHash.put(MPSDefs.DB_CIRCUIT_ID,
                        hmQueryDSLUserResp.get(MPSDefs.DB_CIRCUIT_ID));
                userServiceHash.put(MPSDefs.DB_VIRTUAL_PATH,
                        hmQueryDSLUserResp.get(MPSDefs.DB_VIRTUAL_PATH));
                userServiceHash.put(MPSDefs.DB_VIRTUAL_CIRCUIT,
                        hmQueryDSLUserResp.get(MPSDefs.DB_VIRTUAL_CIRCUIT));
                userServiceHash.put(MPSDefs.DB_INCOMING_BURST,
                        hmQueryDSLUserResp.get(MPSDefs.DB_INCOMING_BURST));
                userServiceHash.put(MPSDefs.DB_INCOMING_LIMIT,
                        hmQueryDSLUserResp.get(MPSDefs.DB_INCOMING_LIMIT));
                userServiceHash.put(MPSDefs.DB_OUTGOING_BURST,
                        hmQueryDSLUserResp.get(MPSDefs.DB_OUTGOING_BURST));
                userServiceHash.put(MPSDefs.DB_OUTGOING_LIMIT,
                        hmQueryDSLUserResp.get(MPSDefs.DB_OUTGOING_LIMIT));
                userServiceHash.put(MPSDefs.DB_PROTOCOL_TYPE,
                        hmQueryDSLUserResp.get(MPSDefs.DB_PROTOCOL_TYPE));
                userServiceHash.put(MPSDefs.DB_IP_ADDRESS,
                        hmQueryDSLUserResp.get(MPSDefs.DB_IP_ADDRESS));
                userServiceHash.put(MPSDefs.DB_IP_NETBLOCK,
                        hmQueryDSLUserResp.get(MPSDefs.DB_IP_NETBLOCK));
                userServiceHash.put(MPSDefs.DB_IP_SUBNET,
                        hmQueryDSLUserResp.get(MPSDefs.DB_IP_SUBNET));
                userServiceHash.put(MPSDefs.DB_WTN, hmQueryDSLUserResp.get(MPSDefs.DB_WTN));
                userServiceHash.put(MPSDefs.DSL_USER_CREATE_DATE,
                        hmQueryDSLUserResp.get(MPSDefs.DSL_USER_CREATE_DATE));
                userServiceHash.put(MPSDefs.DSL_USER_LAST_MODIFIED,
                        hmQueryDSLUserResp.get(MPSDefs.DSL_USER_LAST_MODIFIED));
                userServiceHash.put(MPSDefs.DSL_USER_LAST_MODIFIED_BY,
                        hmQueryDSLUserResp.get(MPSDefs.DSL_USER_LAST_MODIFIED_BY));
                userServiceHash.put(MPSDefs.DB_DSLAM_TYPE,
                        hmQueryDSLUserResp.get(MPSDefs.DB_DSLAM_TYPE));
                userServiceHash.put(MPSDefs.DB_TDSL_IND,
                        hmQueryDSLUserResp.get(MPSDefs.DB_TDSL_IND));
                userServiceHash.put(MPSDefs.DB_IPV6RD_ENABLED,
                        hmQueryDSLUserResp.get(MPSDefs.DB_IPV6RD_ENABLED));
                userServiceHash.put(MPSDefs.DB_IPV6RD_MANUALLY_DISABLED,
                        hmQueryDSLUserResp.get(MPSDefs.DB_IPV6RD_MANUALLY_DISABLED));
                userServiceHash.put(MPSDefs.DB_NETWORK_PROFILE_NAME,
                        hmQueryDSLUserResp.get(MPSDefs.DB_NETWORK_PROFILE_NAME));
                userServiceHash.put(MPSDefs.DB_NETWORK_PROFILE_ID,
                        hmQueryDSLUserResp.get(MPSDefs.DB_NETWORK_PROFILE_ID));
                userServiceHash.put(MPSDefs.DB_DNS_ERR_OPTOUT_IND,
                        hmQueryDSLUserResp.get(MPSDefs.DB_DNS_ERR_OPTOUT_IND));
            }
        } else {
            log.info("DBTOOLS15 : No record found in DSLUSER table");
        }
    }

    protected void processLS(Map hmQueryResponse, HashMap<String, Object> hmMemberServiceRoles, ArrayList alQueryRolesSvcList, HashMap<String, Object> hmMemberServiceAttributes, String serviceName, String instanceId, HashMap<String, Object> userServiceHash) {
        HashMap<String, Object> instanceHash = CommonUtil.getHashMap();

        copyServiceData(instanceHash, hmQueryResponse, hmMemberServiceRoles, alQueryRolesSvcList,
                hmMemberServiceAttributes);

        // Calculate instance_status by calling MbrAttributes.calculateStatus
        String instanceStatus = calculateStatus(
                (String) instanceHash.get(MPSDefs.DB_MEMBER_STATUS_NAME),
                (String) instanceHash.get(MPSDefs.DB_GROUP_STATUS_NAME));

        instanceHash.put(MPSDefs.INSTANCE_STATUS, instanceStatus);

        // rp6341- LSR7 updated to not to send site_id from memberservice table
        // Adding IPTV service provider in the response hashmap for NAP2--by nk0565
        if (serviceName.equals(MPSDefs.IPTV_SERVICE)) {
            instanceHash.put(MPSDefs.DB_PORTAL_SVC_PROVIDER,
                    (String) hmQueryResponse.get(MPSDefs.DB_PORTAL_SVC_PROVIDER));
        }
        if (serviceName.equals(MPSDefs.MOSUB_SERVICE) || serviceName.equals(MPSDefs.AAB_SERVICE)) {
            // added by vs3652 for LSR10 AAB
            ArrayList alAssoServices = CommonUtil.getArrayList();
            HashMap<String, Object> hmAssoServices = CommonUtil.getHashMap();

            String sorInvariantId = (String) hmQueryResponse.get(MPSDefs.DB_SOR_INVARIANT_ID);
            String assoSorId1 = (String) hmQueryResponse.get(MPSDefs.DB_SOR_ID1);
            String assoSorInvariantId1 = (String) hmQueryResponse.get(MPSDefs.DB_SOR_INVARIANT_ID1);
            String assoSorId2 = (String) hmQueryResponse.get(MPSDefs.DB_SOR_ID2);
            String assoSorInvariantId2 = (String) hmQueryResponse.get(MPSDefs.DB_SOR_INVARIANT_ID2);

            if (sorInvariantId != null && assoSorInvariantId1 != null
                    && sorInvariantId.equals(assoSorInvariantId1)) {
                hmAssoServices.put(MPSDefs.DB_SOR_ID1, assoSorId1);
                hmAssoServices.put(MPSDefs.DB_SOR_INVARIANT_ID1, assoSorInvariantId1);
                hmAssoServices.put(MPSDefs.DB_SOR_NAME1,
                        (String) hmQueryResponse.get(MPSDefs.DB_SOR_NAME1));

                hmAssoServices.put(MPSDefs.DB_SOR_ID2, assoSorId2);
                hmAssoServices.put(MPSDefs.DB_SOR_INVARIANT_ID2, assoSorInvariantId2);
                hmAssoServices.put(MPSDefs.DB_SOR_NAME2,
                        (String) hmQueryResponse.get(MPSDefs.DB_SOR_NAME2));

                hmAssoServices.put(MPSDefs.DB_ASSOCIATION_ASSIGNED_BY,
                        (String) hmQueryResponse.get("asso_assigned_by"));
                hmAssoServices.put(MPSDefs.DB_ASSOCIATION_CREATE_DATE,
                        (String) hmQueryResponse.get("asso_create_date"));
                hmAssoServices.put(MPSDefs.DB_ASSOCIATION_LAST_MODIFIED,
                        (String) hmQueryResponse.get("asso_last_modified"));
                hmAssoServices.put(MPSDefs.DB_ASSOCIATION_LAST_MODIFIED_BY,
                        (String) hmQueryResponse.get("asso_last_modified_by"));

                alAssoServices.add(hmAssoServices);

                if (alAssoServices.size() > 0)
                    instanceHash.put(MPSDefs.DB_ASSOCIATED_SERVICES, alAssoServices);
            }
        } // MOSUB and AAB service check

        // Always put service_status inside instance hash from June 2011
        instanceHash.put(MPSDefs.SERVICE_STATUS, (String) instanceHash.get(MPSDefs.INSTANCE_STATUS));
        instanceHash.put(MPSDefs.DB_INSTANCE_ID, instanceId);

        userServiceHash.put(instanceId, instanceHash);

        // For LS - R1, there will be only one instance_id for each LS service.
        // instance_status and service_status are same in this case.
        if (!CommonDefs.INSTANCE_SERVICES_WITH_MULTIPLE_INSTANCES.contains(serviceName))
            userServiceHash.put(MPSDefs.SERVICE_STATUS, instanceStatus);
    }
}

