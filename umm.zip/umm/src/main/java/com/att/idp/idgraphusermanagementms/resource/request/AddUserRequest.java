package com.att.idp.idgraphusermanagementms.resource.request;

import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import com.att.mpsys.common.utils.CommonDefs;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class represents a request to add a new user in the system.
 * It contains fields for various user details such as userId, passwordClear, online1SecurityQuestion, online1SecurityAnswer, online2SecurityQuestion, online2SecurityAnswer, contactEmail, firstName, lastName, browserLanguage, isAccessIdAutoGen, isTempPassword, agentId, isExternalCall, byPassCheckIdAvailability, accessIdRTValidFlag, contactEmailRTValidFlag, and idpTraceId.
 * Each field has specific constraints such as not null and size limits.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 *
 * @author pb6583_ATT
 */
@Schema(name = "addUserRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class AddUserRequest extends BaseUserRequest{
	
	private String callingSystemId;
	
	private final String transactionName = CommonDefs.ADD_USER_TRANSACTION_NAME;
	
	@Schema(name = "userId")
	@NotNull(message="userId is required in input request.|AddUser")
	@Size(min=1, max=127,message="userId length is invalid|AddUser")
	@JsonProperty("userId")
	private String handle;
	
	private final String domain = CommonDefs.SLID_DUM;
	
	@Schema(name = "passwordClear")
	@NotNull(message="passwordClear is required in input request.|AddUser")
	@Size(min=6, max=24,message="passwordClear length is invalid|AddUser")
	private String passwordClear;
	
	@Schema(name = "browserLanguage")
	@Size(min=2, max=2,message="browserLanguage length is invalid|AddUser")
	private String browserLanguage;
	
	@Schema(name = "isAccessIdAutoGen")
	@Size(min=1,max=1,message="isAccessIdAutoGen value can only be Y or N|AddUser")
	private String isAccessIdAutoGen;
	
	@Schema(name = "isTempPassword")
	@Size(min=1,max=1,message="isTempPassword value can only be Y or N|AddUser")
	private String isTempPassword;
	
	@Schema(name = "agentId")
	@Size(min=1, max=20,message="agentId length is invalid|AddUser")
	private String agentId;
	
	@Schema(name = "isExternalCall")
	protected String isExternalCall;
	
	@Schema(name = "byPassCheckIdAvailability")
	@Size(min=1,max=1,message="byPassCheckIdAvailability value can only be Y or N|AddUser")
	protected String byPassCheckIdAvailability;
	
	@Schema(name = "accessIdRTValidFlag")
	@Size(min=1,max=1,message="accessIdRTValidFlag value can only be Y or N|AddUser")
	private  String accessIdRTValidFlag;
	
	@Schema(name = "contactEmailRTValidFlag")
	@Size(min=1,max=1,message="contactEmailRTValidFlag value can only be Y or N|AddUser")
	private String contactEmailRTValidFlag;
	
	@Schema(name = "idpTraceId")
	private String idpTraceId;

	@Schema(name = "cbrNumber")
	@Size(min = 10, max = 10, message = "cbrNumber length is invalid")
	private String cbrNumber;

	@Schema(name = "cbrRTValidFlag")
	@Size(min = 1, max = 1, message = "cbrRTValidFlag length is invalid")
	@Pattern(regexp = "(?i)Y|N", message = "cbrRTValidFlag must be 'Y' or 'N'")
	private String cbrRTValidFlag;

	@Schema(name = "contactAddress")
	@Size(min = 1, max = 500, message = "contactAddress length is invalid")
	private String contactAddress;

	/**
	 * This field is part of the AddUserRequest class.
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
	 * @return Map<String,Object> The map of unknown attributes.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();

}
