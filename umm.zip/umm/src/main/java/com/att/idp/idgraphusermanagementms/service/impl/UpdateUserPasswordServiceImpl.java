package com.att.idp.idgraphusermanagementms.service.impl;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.UpdateUserPasswordHelper;
import com.att.idp.idgraphusermanagementms.helper.resetuserpassword.UserPasswordHelper;
import com.att.idp.idgraphusermanagementms.resource.request.UpdateUserPasswordRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdateUserPasswordResponse;
import com.att.idp.idgraphusermanagementms.service.UpdateUserPasswordService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.MPSDefs;
import net.logstash.logback.argument.StructuredArguments;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.ws.rs.core.MultivaluedMap;
import java.util.HashMap;
import java.util.Map;

@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class UpdateUserPasswordServiceImpl implements UpdateUserPasswordService {
    public static final Logger logger = LoggerFactory.getLogger(UpdateUserPasswordServiceImpl.class);

    private static String sClassName = "UpdateUserPasswordServiceImpl";

    @Autowired
    private UpdateUserPasswordHelper helper;
    /**
     * This method is part of the UpdateUserPasswordService interface in the com.att.idp.idgraphusermanagementms.service package.
     *
     * The updateUserPassword method is used to perform the operation of updating a user's password.
     * It takes a UpdateUserPasswordRequest object and a MultivaluedMap of String to String as input.
     * The UpdateUserPasswordRequest object represents the request body, containing the details required for updating a user's password.
     * The MultivaluedMap represents the request headers.
     *
     * The method returns a UpdateUserPasswordResponse object, which represents the response from the operation of updating a user's password.
     */ @Override
    public UpdateUserPasswordResponse updateUserPassword(UpdateUserPasswordRequest updateUserPasswordRequest, MultivaluedMap<String, String> requestHeader) {

        Map<String, Object> hmResponse = null;
        String sMethodName = ".updateUserPassword.";

        Map<String, Object> hmInput = CommonUtilHelper.objectToMap(updateUserPasswordRequest);
        hmInput.put("handle", hmInput.remove("userId"));

        logger.info(SpiMarker.getInstance(),
                "UpdateUserPasswordServiceImpl.updateUserPassword.UUPS_01 : Calling updateUserPasswordHelper with Input : {}",
                StructuredArguments.entries(hmInput));

        hmResponse = helper.changeUserPassword(hmInput);

        hmResponse=CommonUtilHelper.processHmResponse(hmResponse, hmInput, "updateUserPasswordHelper", ".updateUserPassword");
        hmResponse.put("idp-trace-id", updateUserPasswordRequest.getIdpTraceId());
        hmResponse.put(CommonDefs.TRANSACTION_NAME, "UpdateUserPassword");
        UpdateUserPasswordResponse updateUserPasswordResponse = CommonUtilHelper.generateUpdateUserPasswordResponse(hmResponse);

        String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

        if (sTxnRollBack != null) {
            throw new InvalidInputDataException(hmResponse);
        }
        logger.info("{}{}UUPS_05 : Response from UpdateUserPasswordServiceImpl.updateUserPassword : {}", sClassName, sMethodName,
                updateUserPasswordResponse);
        return updateUserPasswordResponse;

    }
}
