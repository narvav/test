package com.att.idp.idgraphusermanagementms.db.helper;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.mpsys.common.utils.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;
import java.util.*;

/**
 * This class provides helper methods to delete members and groups from the database.
 * It uses Spring's JdbcTemplate to execute SQL queries.
 */
@Component
public class DeleteMemberDBHelper {

	private static String sClassName = "DeleteMemberDBHelper";
	public static final Logger logger = LoggerFactory.getLogger(DeleteMemberDBHelper.class);
	private static final String INFO = "$Id: master/com/att/idp/idgraphusermanagementms/helper/dbhelpers/DeleteDBHelper.java v1 2024-09-15 vn3904 $;";


	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private DBHelper oDBHelper;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;
	/**
	 * Deletes a group from the database.
	 *
	 * @param inpParam A HashMap containing the group details. The group number should be provided with the key MPSDefs.DB_GROUP_NUM.
	 * @return A HashMap containing the result of the operation. If successful, the map contains a success message. If not, it contains an error message.
	 */
	public HashMap<String, Object> deleteGroup(HashMap<String, Object> inpParam) {
		String sMethodName = ".deleteGroup.";
		HashMap<String, Object> hmResult = null;
		logger.info("{}{}DBTOOLS000 : deleteGroup InpParam : {}", sClassName, sMethodName, inpParam!=null? StringUtils.normalizeSpace(inpParam.toString()): null);
		List<Object> objectList = CommonUtil.getArrayList();
		String sGroupNum = (String) inpParam.get(MPSDefs.DB_GROUP_NUM);

		if (sGroupNum == null || sGroupNum.length() <= 0) {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, "GroupNum Not passed in Input");
			logger.info("{}{}DG001 : GroupNum not passed returning error.hmResult= {}", sClassName, sMethodName,
					hmResult);
			return hmResult;
		}
		String theSql = "DELETE FROM MEMBERGROUP WHERE group_num = ?";

		try {
			objectList.add(sGroupNum);
			int rowCount = jdbcTemplate.update(new String(theSql), objectList.toArray(new Object[objectList.size()]));
			logger.debug("{}{}DM002 : rowCount::= {} ", sClassName, sMethodName, rowCount);
			if (rowCount == 0) {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.REC_NOT_FOUND_NUM, "No rows found");
			} else {
				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
						"Successfully Deleted Member from TMember Table");
			}
		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}DG002 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}DG003 : Exception = {}", sClassName, sMethodName, errorCode);
		} finally {
			logger.info("{}{}DBHLP999 response : {}", sClassName, sMethodName, hmResult);
		}

		return hmResult;

	}

	/**
	 * Deletes a member from the database.
	 *
	 * @param InpParam A HashMap containing the member details. The member number should be provided with the key MPSDefs.DB_MEMBER_NUM.
	 * @return A HashMap containing the result of the operation. If successful, the map contains a success message. If not, it contains an error message.
	 */
	public HashMap<String, Object> deleteMember(HashMap<String, Object> InpParam) {
		String sMethodName = ".deleteMember.";
		String sMemberNum=null;
		logger.info("{}{}DBTOOLS000 : deleteMember InpParam : {}", sClassName, sMethodName, InpParam!=null? StringUtils.normalizeSpace(InpParam.toString()): null);

		HashMap<String, Object> hmResult = null;
		List<Object> objectList = new ArrayList<>();
		String theSql = "DELETE FROM MEMBER WHERE member_num = ?";
		if(InpParam!=null)
		 sMemberNum = (String) InpParam.get(MPSDefs.DB_MEMBER_NUM);
		if (sMemberNum == null || sMemberNum.length() <= 0) {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, "MemberNum Not passed in Input");
			logger.info("{}{}DM001 : Member_num not passed returning error.hmResult= {}", sClassName, sMethodName,
					hmResult);
			return hmResult;
		}

		try {
			objectList.add(sMemberNum);
			int rowCount = jdbcTemplate.update(new String(theSql), objectList.toArray(new Object[objectList.size()]));

			logger.debug("{}{}DM002 : rowCount::= {} ", sClassName, sMethodName, rowCount);
			if (rowCount == 0) {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.REC_NOT_FOUND_NUM, "No rows found");
			} else {
				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
						"Successfully Deleted Member from TMember Table");
			}
			logger.debug("{}{}DM003 : removeStatus::= {} ", sClassName, sMethodName, hmResult);
		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}DM002 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}DM003 : Exception = {}", sClassName, sMethodName, errorCode);

		} finally {
			logger.info("{}{}DBHLP999 response : {}", sClassName, sMethodName, hmResult);
		}

		return hmResult;
	}
	/**
	 * Clears all {@code SLID_MEMBER_NUM} references pointing to the given member.
	 *
	 * <p>The {@code MEMBER} table has a self-referencing FK ({@code IMEM_SLIDMEMNUM_FK}):
	 * {@code MEMBER.SLID_MEMBER_NUM → MEMBER.MEMBER_NUM}. When a group is cascade-deleted,
	 * Oracle tries to delete the MEMBER rows, but other MEMBER rows (from different groups)
	 * may still reference them via {@code SLID_MEMBER_NUM}, causing {@code ORA-02292}.
	 * This method NULLs out those references before the delete.</p>
	 *
	 * @param memberNum The member_num whose inbound SLID_MEMBER_NUM references should be cleared.
	 * @return Success map with row count, or error map on failure.
	 */
	public HashMap<String, Object> clearSlidReferences(String memberNum) {
		String sMethodName = ".clearSlidReferences.";
		HashMap<String, Object> hmResult = null;
		logger.info("{}{}DBTOOLS000 : clearSlidReferences for member_num : {}", sClassName, sMethodName, memberNum);

		if (memberNum == null || memberNum.isEmpty()) {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, "member_num not passed in input");
			logger.info("{}{}CSR001 : member_num not passed, returning error. hmResult= {}", sClassName, sMethodName, hmResult);
			return hmResult;
		}

		String theSql = "UPDATE MEMBER SET SLID_MEMBER_NUM = NULL WHERE SLID_MEMBER_NUM = ?";

		try {
			int rowCount = jdbcTemplate.update(theSql, memberNum);
			logger.info("{}{}CSR002 : Cleared SLID_MEMBER_NUM references, rowCount = {}", sClassName, sMethodName, rowCount);
			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
					"Cleared SLID references, rows updated: " + rowCount);
		} catch (Exception e) {
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}CSR003 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}CSR004 : Exception = {}", sClassName, sMethodName, errorCode);
		} finally {
			logger.info("{}{}DBHLP999 response : {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;
	}

	/**
	 * @param hmInput
	 * @return HashMap
	 */
	public HashMap<String, Object> deleteGroupService(HashMap<String, Object> hmInput) {
		String sMethodName = "deleteGroupService";
		HashMap<String, Object> hmResult = null;
		String stAppInfo = null;
		List<Object> objectList = new ArrayList<>();

		logger.info("{}{}DMDH.DGS.01. : CVS KEYWORDS: {}", sClassName, sMethodName, INFO);
		logger.info("{}{}DBTOOLS000 : deleteGroupService InpParam : {}", sClassName, sMethodName, hmInput != null ? org.apache.commons.lang3.StringUtils.normalizeSpace(hmInput.toString()) : null);
		String deleteStmt = "";
		String stSorInvariantId = null;
		String sParentChildInd=null;
		String deleteSql =
				"DELETE FROM MEMBERSERVICE WHERE service_id = ? AND group_num = ?";
		String deleteInstanceSql =
				"DELETE FROM MEMBERSERVICE WHERE service_id = ? AND group_num = ? AND instance_id = ?";
		String deleteSorInvIdSql =
				"DELETE FROM MEMBERSERVICE WHERE service_id = ? AND group_num = ? AND sor_invariant_id = ?";
		String deleteInstanceSorInvIdSql =
				"DELETE FROM MEMBERSERVICE WHERE service_id = ? AND group_num = ? AND instance_id = ? AND sor_invariant_id = ?";
		String deleteParentChildIndSql =
				"DELETE FROM MEMBERSERVICE WHERE service_id = ? AND group_num = ? AND member_num in ( SELECT member_num FROM MEMBER WHERE group_num = ? AND parent_child_ind = ? )";

		String sgroupNum = null;
		String serviceName = null;
		String instanceId = null;
		try {
			if (hmInput != null) {
				sgroupNum = (String) hmInput.get(MPSDefs.DB_GROUP_NUM);
				serviceName = (String) hmInput.get(MPSDefs.DB_SERVICE_NAME);
				instanceId = (String) hmInput.get(MPSDefs.DB_INSTANCE_ID);
			}
			long groupNum = -1;
			int serviceId = 0;

			if (hmInput!=null && hmInput.containsKey(MPSDefs.DB_SOR_INVARIANT_ID)) {
				stSorInvariantId = (String) hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
				sParentChildInd = (String) hmInput.get(MPSDefs.DB_PARENT_CHILD_IND);
			}

			if (jdbcTemplate == null) {
				hmResult = CommonErrorMap.makeCategoryMap(
						CErrorDefs.ERR_SYS_APPL_NUM, "jdbcTemplate is null.");
				logger.info("{}{}DMDH.DGS.02 : response :  {} ", sClassName, sMethodName, hmResult);
				return hmResult;

			}
			if (sgroupNum != null)
				groupNum = Long.parseLong(sgroupNum);

			serviceId = oDBHelper.getServiceId(serviceName);
			logger.debug("{}{}DMDH.DGS.03 : serviceId::= {} ", sClassName, sMethodName, serviceId);

			if (serviceId == 0 || groupNum == -1) {
				stAppInfo = "CANNOT find service_id or group_Num ";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.debug("{}{}DMDH.DGS.04 : = {} ", sClassName, sMethodName, stAppInfo);
				return hmResult;

			} else {

				if (sParentChildInd != null && !sParentChildInd.trim().isEmpty()) {
					deleteStmt = deleteParentChildIndSql;
				} else {

					if ((instanceId != null && !(instanceId.trim()).isEmpty()) && (stSorInvariantId != null && !(stSorInvariantId.trim()).isEmpty())) {
						deleteSql = deleteInstanceSorInvIdSql;
					} else if (instanceId != null && !(instanceId.trim()).isEmpty()) {
						deleteSql = deleteInstanceSql;
					} else if (stSorInvariantId != null && !(stSorInvariantId.trim()).isEmpty()) {
						deleteSql = deleteSorInvIdSql;
					} else {
						deleteStmt = deleteSql;
					}
				}

				logger.debug("{}{}DMDH.DGS.05 : SQL =  {} ", sClassName, sMethodName, deleteSql);

				objectList.add(serviceId);
				objectList.add(groupNum);

				if (sParentChildInd != null && !sParentChildInd.trim().isEmpty()) {

					objectList.add(groupNum);
					objectList.add(sParentChildInd);
				} else {
					if ((instanceId != null && !instanceId.isEmpty()) && (stSorInvariantId != null && !stSorInvariantId.isEmpty())) {

						objectList.add(instanceId);
						objectList.add(stSorInvariantId);

					} else if (instanceId != null && !instanceId.isEmpty()) {

						objectList.add(instanceId);

					} else if (stSorInvariantId != null && !stSorInvariantId.isEmpty()) {
						objectList.add(stSorInvariantId);

					}
				}

				int rowCount = jdbcTemplate.update(new String(deleteStmt), objectList.toArray(new Object[objectList.size()]));

				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
						"Number of rows deleted:= " + rowCount);

				logger.debug("{}{}DMDH.DGS.06 : removeStatus::= {} ", sClassName, sMethodName, hmResult);
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}DMDH.DGS.07 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}DMDH.DGS.08 : Exception = {}", sClassName, sMethodName, errorCode);
			return hmResult;

		} finally {
			logger.info("{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;
	}

	/**
	 * @param hmDbInput
	 * @return HashMap
	 */
	//delete Mobility Device
	public HashMap<String, Object> deleteMobilityDevice(HashMap<String, Object> hmDbInput) {
		String sMethodName = ".deleteMobilityDevice";
		HashMap<String, Object> hmResult = null;
		String stAppInfo = null;
		List<Object> objectList = new ArrayList<>();
		logger.info("{}{}DMDH.DMD.01. : CVS KEYWORDS: {}", sClassName, sMethodName, INFO);
		logger.info("{}{}DBTOOLS000 : deleteMobilityDevice InpParam : {}", sClassName, sMethodName, hmDbInput != null ? StringUtils.normalizeSpace(hmDbInput.toString()) : null);

		try {

			if (jdbcTemplate == null) {
				hmResult = CommonErrorMap.makeCategoryMap(
						CErrorDefs.ERR_SYS_APPL_NUM, "jdbcTemplate is null.");
				logger.info("{}{}DMDH.DMD.02 : response :  {} ", sClassName, sMethodName, hmResult);
				return hmResult;
			}
			String sMemberNum = null;
			String sServiceId = null;
			String sSorInvariantId = null;

			if (hmDbInput != null) {
				sMemberNum = (String) hmDbInput.get(MPSDefs.DB_MEMBER_NUM);
				sServiceId = (String) hmDbInput.get(MPSDefs.DB_SERVICE_ID);
				sSorInvariantId = (String) hmDbInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
			}

			if (sMemberNum == null || sMemberNum.trim().length() <= 0 ||
					sServiceId == null || sServiceId.trim().length() <= 0 ||
					sSorInvariantId == null || sSorInvariantId.trim().length() <= 0) {
				stAppInfo = "member_num/service_id/sor_invariant_id is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM, stAppInfo);
				logger.info("{}{}DMDH.DMD.03 : {}{}", MPSDefs.ERR_EMPTY_NUM, sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			String sDeleteMobilityDeviceSql = "DELETE FROM MOBILITYDEVICE WHERE MEMBER_NUM = ?"
					+ " AND SERVICE_ID = ? AND SOR_INVARIANT_ID = ?";

			logger.debug("{}{}DDH.DMD.04 : SQL =  {} ", sClassName, sMethodName, sDeleteMobilityDeviceSql);

			objectList.add(sMemberNum);
			objectList.add(sServiceId);
			objectList.add(sSorInvariantId);

			int rowCount = jdbcTemplate.update(new String(sDeleteMobilityDeviceSql), objectList.toArray(new Object[objectList.size()]));

			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
					"Number of rows deleted:= " + rowCount);
			logger.debug("{}{}DMDH.DMD.05 : deleteMobilityDevice::= {} ", sClassName, sMethodName, hmResult);


		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}DMDH.DMD.06 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}DMDH.DMD.07 : Exception = {}", sClassName, sMethodName, errorCode);
			return hmResult;

		} finally {
			logger.info("{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;
	}
}
