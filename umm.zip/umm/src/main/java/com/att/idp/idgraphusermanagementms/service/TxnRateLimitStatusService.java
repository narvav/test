package com.att.idp.idgraphusermanagementms.service;

import jakarta.ws.rs.core.MultivaluedMap;

import com.att.idp.idgraphusermanagementms.resource.request.TransactionRateLimitRequest;
import com.att.idp.idgraphusermanagementms.resource.response.TransactionRateLimitResponse;

/**
 * This interface defines the contract for the TxnRateLimitStatusService in the system.
 * It contains a single method txnRateLimitStatus which takes a TransactionRateLimitRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return a TransactionRateLimitResponse object.
 *
 * The TransactionRateLimitRequest object encapsulates the details of the transaction rate limit status operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 * @author pb6583_ATT
 */
public interface TxnRateLimitStatusService {
	
	
	/**
	 * This method is part of the TxnRateLimitStatusService interface.
	 * It defines the contract for checking the transaction rate limit status in the system.
	 *
	 * @param txnRateLimitStatusRequest An object encapsulating the details of the transaction rate limit status operation to be performed.
	 * @param requestHeader A MultivaluedMap containing the request headers which may include additional information required for processing the request.
	 * @return A TransactionRateLimitResponse object representing the response from the system after checking the transaction rate limit status.
	 */
	TransactionRateLimitResponse txnRateLimitStatus(TransactionRateLimitRequest txnRateLimitStatusRequest, MultivaluedMap<String, String> requestHeader);

}
