package com.att.idp.idgraphusermanagementms.helper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.StringTokenizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.db.helper.IPRateLimitDBHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * The IPTxnRateLimitHelper class is a helper class that provides methods to verify and manage IP transaction rate limits.
 * It includes methods to verify the client IP address, validate input, and interact with the IPRateLimitDBHelper to query and update the IP rate limit database.
 * This class is annotated with @Component, meaning it is an autodetectable Spring Bean and can be automatically wired into other components using Spring's dependency injection facilities.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class IPTxnRateLimitHelper extends AbstractHelper {

	private static String sClassName = "IPTxnRateLimitHelper";

	public static final Logger logger = LoggerFactory.getLogger(IPTxnRateLimitHelper.class);
	
	@Value("${OPR_TIME_PERIOD}")
	private String OPR_TIME_PERIOD;
	
	@Value("${IDP_TIME_PERIOD}")
	private String IDP_TIME_PERIOD;
	
	@Value("${DATAMGT_TIME_PERIOD}")
	private String DATAMGT_TIME_PERIOD;
	
	@Value("${OPR_MAX_TRANSACTIONS}")
	private String OPR_MAX_TRANSACTIONS;
	
	@Value("${IDP_MAX_TRANSACTIONS}")
	private String IDP_MAX_TRANSACTIONS;
	
	@Value("${DATAMGT_MAX_TRANSACTIONS}")
	private String DATAMGT_MAX_TRANSACTIONS;
		
	
	@Autowired
	private IPRateLimitDBHelper oIPRateLimit_H;

	/**
	 * This method verifies the client IP address and manages IP transaction rate limits.
	 * It first validates the input and then interacts with the IPRateLimitDBHelper to query and update the IP rate limit database.
	 * If the input is null or empty, it returns an error.
	 * If the IP transaction count exceeds its maximum count, it returns an error.
	 * If the IP transaction count is less than the maximum count and the increment counter is set to 'Y', it increments the transaction count.
	 * If the time difference is greater than or equal to the IP initialization time and the increment counter is set to 'Y', it resets the transaction count.
	 *
	 * @param hmInput A HashMap containing the input parameters for the method. It should include the IP address and the increment counter.
	 * @return A HashMap containing the result of the method. It includes the application status code and other information.
	 */
	public HashMap verifyRegClientIpAddress(HashMap hmInput) {
		String sMethodName = ".verifyRegClientIpAddress.";

		logger.info("{}{}HLP000 : Input Hash : {}", sClassName, sMethodName,
				HtmlUtils.htmlEscape(String.valueOf(hmInput)));

		HashMap hmResult = null;
		String stAppInfo = null;
		String stAppStatusCode = null;
		boolean isTransactionRollback=false;

		hmResult = validateMapInput(hmInput, CErrorDefs.ERR_INVALID_DATA_NUM, "Input Hash is NULL");
		if (hmResult != null) return hmResult;

		try {
			
			logger.info("{}{}IPTR_2 :Calling  validateInput methode with input: {} ", sClassName, sMethodName, hmInput);

			hmResult = validateInput(hmInput);

			if (hasFailed(hmResult)) {
				return hmResult;
			}

			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sIncrementCounter = (String) hmInput.get(CommonDefs.INCREMENT_COUNTER);
			
			String stTimePeriod = sCallingSystemId.equals("IDP") ? IDP_TIME_PERIOD
					: sCallingSystemId.equals("OPR") ? OPR_TIME_PERIOD : DATAMGT_TIME_PERIOD;
			logger.info("{}{}IPTR_3.1: stTimePeriod {}", sClassName, sMethodName, stTimePeriod);

			String stMaxTransactions = sCallingSystemId.equals("IDP") ? IDP_MAX_TRANSACTIONS
					: sCallingSystemId.equals("OPR") ? OPR_MAX_TRANSACTIONS : DATAMGT_MAX_TRANSACTIONS;
			logger.info("{}{}IPTR_3.2: stMaxTransactions {}", sClassName, sMethodName, stMaxTransactions);

			hmResult = validateValue(stTimePeriod, CErrorDefs.ERR_CONFIG_NUM,
					sCallingSystemId+"_TIME_PERIOD property value is null or empty");
			if (hmResult != null) return hmResult;

			hmResult = validateValue(stMaxTransactions, CErrorDefs.ERR_CONFIG_NUM,
					sCallingSystemId+"_MAX_TRANSACTIONS property value is null or empty");
			if (hmResult != null) return hmResult;

			int iMaxTransactions = Integer.parseInt(stMaxTransactions);

			long timePeriodInMSec = getTimePeriodInMSec(stTimePeriod);

			HashMap hmDBInput = new HashMap();
			hmDBInput.put(MPSDefs.DB_IP_ADDRESS, hmInput.get(CommonDefs.IP_ADDRESS));
			hmDBInput.put(MPSDefs.DB_LAST_MODIFIED_BY, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		
			logger.info("{}{}IPTR_6 :Calling to oIPRateLimit_H.queryIPRateLimit with input : {}", sClassName, sMethodName, hmDBInput);
			
			hmResult = oIPRateLimit_H.queryIPRateLimit(hmDBInput);

			logger.debug("{}{}IPTR_7 :Response from  oIPRateLimit_H.queryIPRateLimit with  : {}", sClassName, sMethodName, hmResult);

			stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				
				if (stAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND)) {
					
					if (sIncrementCounter.equals(CommonDefs.IND_Y)) {
						
						logger.info("{}{}IPTR_8 :Calling to oIPRateLimit_H.addIPRateLimit with input : {}", sClassName, sMethodName, hmDBInput);
						
						hmResult = oIPRateLimit_H.addIPRateLimit(hmDBInput);
						
						logger.info("{}{}IPTR_9 :Response from oIPRateLimit_H.addIPRateLimit with input : {}", sClassName, sMethodName, hmResult);

						if (hasFailed(hmResult)) {
							return hmResult;
						} else {
							isTransactionRollback = true;
						}
					} else {
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
								CErrorDefs.COMMON_SUCCESS_MSG);
					}
				}
				return hmResult;
			} else {
				
				HashMap hmIPRateLimitInfo = new HashMap();
				hmIPRateLimitInfo = (HashMap) (hmResult.get(CommonDefs.INP_RATE_LIMIT_INFO));
				String sSBIPInitDate = (String) hmIPRateLimitInfo.get(CommonDefs.IP_INIT_DATE);
				String sDBTxnCount = (String) hmIPRateLimitInfo.get(CommonDefs.TXN_COUNT);
				String sDBSysdate = (String) hmIPRateLimitInfo.get(CommonDefs.DB_SYSDATE);

				DateFormat df = new SimpleDateFormat("MMddyyyy HH:mm:ss");
				Date dIPInitDate = df.parse(sSBIPInitDate);
				long tIPInitTime = dIPInitDate.getTime();
				logger.info("{}{}IPTR_10.01 : dIPInitDate : {} tIPInitTime : {}", sClassName, sMethodName, dIPInitDate,tIPInitTime );
				Date dDBSysdate = df.parse(sDBSysdate);
				logger.info("{}{}IPTR_10.02 : dDBSysdate : {}", sClassName, sMethodName, dDBSysdate );
				logger.info("{}{}IPTR_10.03 : timePeriodInMSec : {}", sClassName, sMethodName, timePeriodInMSec );
				long currentTime = dDBSysdate.getTime();
				long lTimeDiff = currentTime - timePeriodInMSec;

				int iTrxCount = Integer.parseInt(sDBTxnCount);
				
				logger.info("{}{}IPTR_10.1 :Time difference values : lTimeDiff {} tIPInitTime {}", sClassName, sMethodName, lTimeDiff,tIPInitTime );

				if (lTimeDiff < tIPInitTime) {

					if (iTrxCount < iMaxTransactions) {
						if (sIncrementCounter != null && sIncrementCounter.equals(CommonDefs.IND_Y)) {
							
							hmDBInput.put(CommonDefs.ACTION, CommonDefs.INCREMENT);
							
							logger.info("{}{}IPTR_11 :Calling to oIPRateLimit_H.updateIPRateLimit with input : {}", sClassName, sMethodName, hmDBInput);
							
							hmResult = oIPRateLimit_H.updateIPRateLimit(hmDBInput);
							
							logger.info("{}{}IPTR_12 :Response from oIPRateLimit_H.updateIPRateLimit with input : {}", sClassName, sMethodName, hmResult);


							if (hasFailed(hmResult)) {
								return hmResult;
							} else {
								isTransactionRollback = true;
							}
						} else {
							hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
									CErrorDefs.COMMON_SUCCESS_MSG);
							}
					} else {
						stAppInfo = "IP Txn count exceeds its maximum count";
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_IP_LIMIT_NUM, stAppInfo);
							
					}
					return hmResult;
				}

				
				if (lTimeDiff >= tIPInitTime) {
					if (sIncrementCounter != null && sIncrementCounter.equals(CommonDefs.IND_Y)) {
						hmDBInput.put(CommonDefs.ACTION, CommonDefs.RESET);
						
						logger.info("{}{}IPTR_14 :Calling to oIPRateLimit_H.updateIPRateLimit with input : {}", sClassName, sMethodName, hmDBInput);
						
						hmResult = oIPRateLimit_H.updateIPRateLimit(hmDBInput);
						
						logger.info("{}{}IPTR_15 :Response from oIPRateLimit_H.updateIPRateLimit with input : {}", sClassName, sMethodName, hmResult);

						if (hasFailed(hmResult)) {
							return hmResult;
						} else {
							isTransactionRollback = true;
						}
					} else {
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
								CErrorDefs.COMMON_SUCCESS_MSG);
					}
					return hmResult;
				}

			}

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);

		} finally {
			logger.info("{}{}HLP999 :: {}", sClassName, sMethodName, hmResult);
			 String sAppCategoryCode = (String)hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
				
				if(isTransactionRollback && sAppCategoryCode != null && !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)){
					hmResult.put("isTransactionRollback", "Y");
				}
		}
		return hmResult;

	}

	@SuppressWarnings("unused")
	private HashMap validateInput(HashMap hmInput) {
		String sMethodName = ".validateInput";
		HashMap hmResult = null;
		String sAppInfo = null;
		try {
			String sIpAddress = (String) hmInput.get(CommonDefs.IP_ADDRESS);
			String sIncrementCounter = (String) hmInput.get(CommonDefs.INCREMENT_COUNTER);			

			if (sIpAddress == null || sIpAddress.trim().isEmpty()) {
				sAppInfo = "IpAddress is null or empty ";
				logger.info("{}{}IPTR_20 : {}", sClassName, sMethodName, sAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
				return hmResult;
			}
			hmResult = validateValue(sIpAddress, CErrorDefs.ERR_INVALID_DATA_NUM,
					"IpAddress is null or empty ");
			if (hmResult != null) return hmResult;

			hmResult = validateValue(sIncrementCounter, CErrorDefs.ERR_INVALID_DATA_NUM,
					"IncrementCounter is null or empty ");
			if (hmResult != null) return hmResult;

			hmResult = validateYNValue(sIncrementCounter, CErrorDefs.ERR_INVALID_DATA_NUM,
					"IncrementCounter should be Y or N");
			if (hmResult != null) return hmResult;

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG);

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			sAppInfo = "Exception thrown from validateInput method : " + hmResult;
			logger.error("{}{}IPTR_23: {}", sClassName, sMethodName, sAppInfo);
			return hmResult;
		}

		return hmResult;
	}

}
