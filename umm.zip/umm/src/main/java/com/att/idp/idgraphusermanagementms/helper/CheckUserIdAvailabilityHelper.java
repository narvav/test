package com.att.idp.idgraphusermanagementms.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.db.repository.impl.MemberRepositoryImpl;
import com.att.idp.idgraphusermanagementms.db.helper.GetAllInfoDBHelper;
import com.att.idp.idgraphusermanagementms.utils.BadWordHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * The CheckUserIdAvailabilityHelper class is a helper class that provides
 * methods to check the availability of a user ID. It includes methods to
 * validate the input, check the availability of the user ID, and interact with
 * the MemberRepositoryImpl class to perform database operations. This class is
 * annotated with @Component, meaning it is an autodetectable Spring Bean and
 * can be automatically wired into other components using Spring's dependency
 * injection facilities. It is also annotated with @Configuration
 * and @PropertySource, indicating that it provides configuration information
 * for the Spring application context and specifies the path of the properties
 * file to be used.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class CheckUserIdAvailabilityHelper {

	private String sClassName = "CheckUserIdAvailabilityHelper";
	private static final String ERROR_ENUM = "ErrorEnum";
	public static final Logger logger = LoggerFactory.getLogger(CheckUserIdAvailabilityHelper.class);

	private final static int MAX_NO_OF_ATTEMPT = 250;
	private static final int HANDLE_LENGTH_MIN = 3;
	private static final int HANDLE_LENGTH_MAX = 18;
	private static final int HANDLE_LENGTH_MAX_FOR_SLID = 127;
	private static final int HANDLE_LENGTH_MIN_FOR_SLID = 5;

	@Autowired
	private MemberRepositoryImpl oMemberServiceRepoImpl;

	@Autowired
	private BadWordHelper oBadWordHelper;

	@Autowired
	private GetAllInfoDBHelper getAllInfo;

	@Autowired
	private BeanFactory objHandleGenAlgBeanFactory;

	@Value("${RILHRS_VALID_CSIDs}")
	private String stCheckIdAvailabilityCSI;

	@Value("${RILHRS_ValidDomains}")
	private String stDBDomainList;

	@Value("${RILHRS_MaxSuggestionsToMPS}")
	private String sMaxHandleToMPS;

	@Value("${RILHRS_MaxSuggestions}")
	private String sMaxSuggestionInConfig;

	@Value("${LEGAL_HANDLE_CHARS}")
	private String sLegalHandleChar;

	private static final String info = "$Id: master/com/att/mpsys/common/helpers/CheckUserIdAvailabilityHelper.java"
			+ " v1 2021-09-23 pm675e $;";

	/**
	 * This method checks the availability of a user ID based on the input
	 * parameters. It validates the input, checks the availability of the user ID,
	 * and interacts with the MemberRepositoryImpl class to perform database
	 * operations. It also handles exceptions and logs the necessary information for
	 * debugging purposes.
	 *
	 * @param hmCheckUserInput A Map containing the necessary information for
	 *                         checking the availability of a user ID. This includes
	 *                         details like the transaction ID, transaction name,
	 *                         calling system ID, and other relevant data.
	 * @return A Map containing the result of the operation. This includes status
	 *         codes and messages indicating the success or failure of the
	 *         operation.
	 * @throws Exception If any error occurs during the process.
	 */
	public Map<String, Object> checkUserIdAvailability(Map<String, Object> hmCheckUserInput) {

		String sMethodName = ".checkUserIdAvailability.";
		String stAppInfo = null;
		String stAppStatusCode = null;
		int inputNoOfSuggestion = 0;
		int maxHandleToMPSInConfig = 0;
		Map<String, Object> hmResult = CommonUtil.getHashMap();

		logger.info("{}{}HLP000 : Input Hash : {}", sClassName, sMethodName,
				HtmlUtils.htmlEscape(String.valueOf(hmCheckUserInput)));
		if (hmCheckUserInput == null || hmCheckUserInput.isEmpty()) {
			stAppInfo = "Input Request Parameter is NULL / Empty.";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			logger.info("{}{}CUIAH_01 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		try {

			// Calling validateInput method for hmInput validation.
			hmResult = validateInput(hmCheckUserInput);
			logger.info("{}{}CUIAH_02 :: Response from validateInput() : {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(hmResult)));
			stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			} else if (stAppStatusCode == null) {
				stAppInfo = "null response from CheckUserIdAvailabilityHelper.validateInput";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}CUIAH_02.1 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			// populating hmInput after validation
			String stTransactionId = (String) hmResult.get(CommonDefs.TRANSACTION_ID);
			String stTransactionName = (String) hmResult.get(CommonDefs.TRANSACTION_NAME);
			String stCallingSystemId = (String) hmResult.get(CommonDefs.CALLING_SYSTEM_ID);
			String stSuggest1 = (String) hmResult.get(CommonDefs.SUGGEST1);
			String stSuggest2 = (String) hmResult.get(CommonDefs.SUGGEST2);
			String stDomain = (String) hmResult.get(CommonDefs.DOMAIN);
			String stNoOfSuggestion = (String) hmResult.get(CommonDefs.NUM_SUGGESTIONS);
			String stMaxHandleToMPS = (String) hmResult.get(CommonDefs.RILHRS_MAX_SUGGESTIONS_TO_MPS);
			String stDomainLessSlid = (String) hmResult.get("domainLessSlid");
			String stSearchSLIDNamespace = (String) hmResult.get(CommonDefs.SEARCH_SLID_NAME_SPACE);

			String stIgnoreQay = (String) hmCheckUserInput.get("ignoreQay");
			String sBypassBadWordCheck = (String) hmCheckUserInput.get("bypassBadWordCheck");

			if (stNoOfSuggestion != null && !stNoOfSuggestion.isEmpty()) {
				inputNoOfSuggestion = Integer.parseInt(stNoOfSuggestion);
			}

			if (inputNoOfSuggestion == 1) {
				maxHandleToMPSInConfig = 1;
			} else {
				maxHandleToMPSInConfig = Integer.parseInt(stMaxHandleToMPS);
			}
			// 2001
			if (inputNoOfSuggestion == 1 && stSuggest1.contains("@")) {
				sBypassBadWordCheck = "Y";
			}

			HandleGenerationAlgorithm handleGenAlgo = (HandleGenerationAlgorithm) objHandleGenAlgBeanFactory
					.getBean("handleGenerationAlgorithm");
			handleGenAlgo.resetCounters();

			ArrayList alSuggestedHandle = CommonUtil.getArrayList();
			int handleCount = 0;
			int tempCounter = 0;

			for (handleCount = 0; handleCount < maxHandleToMPSInConfig;) {

				tempCounter++;

				stAppInfo = "Input to HandleGenerationAlgorithm.createHandle() method ::Suggest1:: " + stSuggest1
						+ " :: and Suggest2:: " + stSuggest2;
				logger.info("{}{}CUIAH_03 : {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
				String tempHandle = handleGenAlgo.createHandle(stSuggest1, stSuggest2, stDomain, stIgnoreQay, logger);
				stAppInfo = "Response Handle from HandleGenerationAlgorithm.createHandle() method ::" + tempHandle;

				logger.info("{}{}CUIAH_04 : {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));

				HashMap<String, Object> hmInputtoHandleCheck = CommonUtil.getHashMap();
				hmInputtoHandleCheck.put(CommonDefs.TRANSACTION_NAME, stTransactionName);
				hmInputtoHandleCheck.put(CommonDefs.TRANSACTION_ID, stTransactionId);
				hmInputtoHandleCheck.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);

				if (stIgnoreQay != null && stIgnoreQay.trim().equalsIgnoreCase(CommonDefs.IND_Y)) {
					hmInputtoHandleCheck.put("ignoreQay", stIgnoreQay);
				}

				if (sBypassBadWordCheck != null && sBypassBadWordCheck.trim().equalsIgnoreCase(CommonDefs.IND_Y)) {
					hmInputtoHandleCheck.put("bypassBadWordCheck", sBypassBadWordCheck);
				}

				hmResult = doHandleChecks(tempHandle, stDomain, stSuggest1, hmInputtoHandleCheck, logger);

				stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

				if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)
						&& (hmResult.containsKey("subCode") || (!stAppStatusCode.equals(CErrorDefs.ERR_INVALID_DATA)
								&& !stAppStatusCode.equals(CErrorDefs.ERR_BAD_PATTERN)))) {
					stAppInfo = "Error Returned from doHandleChecks() method ";
					logger.error("{}{}CUIAH_05 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}

				// 1911: Updated for reserved word error category
				if (inputNoOfSuggestion == 1 && stAppStatusCode.equals(CErrorDefs.ERR_BAD_PATTERN)) {
					stAppInfo = "suggest1 matches with reserved word";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_RESERVED_WORD_NUM, stAppInfo);
					logger.error("{}{}CUIAH_06 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}

				if (stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					if (alSuggestedHandle.size() < maxHandleToMPSInConfig) {

						alSuggestedHandle.add(tempHandle);
						handleCount++;
						if (alSuggestedHandle.size() < maxHandleToMPSInConfig) {

							continue;
						}
					}
				}

				if (tempCounter >= MAX_NO_OF_ATTEMPT) {
					stAppInfo = "Error Occured:: Exceeded the Max. Attempt to create the suggested Handle";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_SUGGEST_HANDLE_NUM, stAppInfo);
					logger.error("{}{}CUIAH_07 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}

			}

			stAppInfo = "The Value of TempCounter ::" + tempCounter + " :: And Size of ArrayList to MPS ::"
					+ alSuggestedHandle.size();
			logger.info("{}{}CUIAH_08 : {}", sClassName, sMethodName, stAppInfo);
			hmResult.clear();

			if (alSuggestedHandle.size() > 0) {
				HashMap hmSuggestedHandle = CommonUtil.getHashMap();
				hmSuggestedHandle.put(CommonDefs.TRANSACTION_ID, stTransactionId);
				hmSuggestedHandle.put(CommonDefs.TRANSACTION_NAME, stTransactionName);
				hmSuggestedHandle.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
				hmSuggestedHandle.put(CommonDefs.DOMAIN, stDomain);
				hmSuggestedHandle.put(CommonDefs.NUM_SUGGESTIONS, stNoOfSuggestion);
				hmSuggestedHandle.put(CommonDefs.SUGGEST_LIST, alSuggestedHandle);
				hmSuggestedHandle.put(CommonDefs.SEARCH_SLID_NAME_SPACE, stSearchSLIDNamespace);
				hmSuggestedHandle.put(CommonDefs.SUGGEST1, stSuggest1);

				if (stDomainLessSlid != null && stDomainLessSlid.equals(CommonDefs.IND_Y))
					hmSuggestedHandle.put("domainLessSlid", stDomainLessSlid);
				logger.info("{}{}CUIAH_09 :: input to checkMps method : hmSuggestedHandle : {}", sClassName,
						sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmSuggestedHandle)));
				hmResult = checkMps(hmSuggestedHandle, logger);
				stAppInfo = "Response from checkMps() method  " + hmResult;
				logger.debug("{}{}CUIAH_10 :: Response from checkMps method : {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
			}

		} catch (Exception e) {
			logger.info("Exception occured"+e);
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown CheckUserIdAvailability method : " + hmResult;
			logger.info("{}{}CUIAH_11 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));

		} finally {
			logger.info("{}{}HLP999 : response from CheckUserIdAvailability {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(hmResult)));
		}
		return hmResult;
	}

	/**
	 * This method validates the input parameters for checking the availability of a
	 * user ID. It checks whether the transaction name is "CheckUserIdAvailability",
	 * validates the calling system ID, and validates the suggested user ID and
	 * domain. It also handles exceptions and logs the necessary information for
	 * debugging purposes.
	 *
	 * @param hmCheckUserInput A Map containing the necessary information for
	 *                         checking the availability of a user ID. This includes
	 *                         details like the transaction ID, transaction name,
	 *                         calling system ID, and other relevant data.
	 * @return A Map containing the result of the validation. This includes status
	 *         codes and messages indicating the success or failure of the
	 *         validation.
	 * @throws Exception If any error occurs during the process.
	 */
	public Map<String, Object> validateInput(Map<String, Object> hmCheckUserInput) {
		String sMethodName = ".validateInput.";
		String sAppStatusCode = null;
		String sAppInfo = null;
		Map<String, Object> hmResult = null;

		try {

			String sTransactionName = (String) hmCheckUserInput.get(CommonDefs.TRANSACTION_NAME);
			String sIsExternalCall = (String) hmCheckUserInput.get("isExternalCall");

			if (!"CheckUserIdAvailability".equals(sTransactionName)) {
				sAppInfo = "Transaction Not Allowed :: TransactionName Should be CheckUserIdAvailability";
				logger.info(sClassName + sMethodName + "CUIDH_VI.01 : " + sAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
				return hmResult;
			}

			hmResult = validateCheckUserCallingSystemId(hmCheckUserInput);
			sAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			if (sAppStatusCode != null && !(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode))) {
				return hmResult;
			}
			hmResult = validateSuggestInputAndDomain(hmCheckUserInput);
		} catch (Exception e) {
			logger.info("Exception occured"+e);
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			String stAppInfo = "Exception thrown CheckUserIdAvailabilityHelper.validateInput method : " + hmResult;
			logger.info("{}{}CUIAH_VI.999 : {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
		}

		return hmResult;
	}

	private HashMap<String, Object> validateSuggestInputAndDomain(Map<String, Object> hmCheckUserInput) {

		String sMethodName = ".validateSuggestInputAndDomain.";
		String stAppInfo = null;
		String sAppStatusCode = null;
		String sSuggest1 = (String) hmCheckUserInput.get(CommonDefs.SUGGEST1);
		String sSuggest2 = (String) hmCheckUserInput.get(CommonDefs.SUGGEST2);
		String sNumSuggestions = (String) hmCheckUserInput.get(CommonDefs.NUM_SUGGESTIONS);
		String sSearchSLIDNamespace = (String) hmCheckUserInput.get(CommonDefs.SEARCH_SLID_NAME_SPACE);
		String sDomain = (String) hmCheckUserInput.get(CommonDefs.DOMAIN);
		HashMap<String, Object> hmResult = CommonUtil.getHashMap();
		HashMap<String, Object> getAllInfoHash = null;
		String sDomainLessSlid = null;

		if (sSuggest2 != null) {
			sSuggest2 = sSuggest2.trim().toLowerCase();
		} else {
			sSuggest2 = "";
		}

		// validate sSearchSLIDNamespace
		if (sSearchSLIDNamespace != null && !sSearchSLIDNamespace.isEmpty()) {
			sSearchSLIDNamespace = sSearchSLIDNamespace.trim().toUpperCase();
		}
		if (sSearchSLIDNamespace != null && !CommonDefs.IND_Y.equals(sSearchSLIDNamespace)
				&& !CommonDefs.IND_N.equals(sSearchSLIDNamespace)) {
			stAppInfo = "searchSLIDNamespace can have values one of Y/N";
			logger.info("{}{}CUIAH_VI.04 : {}", sClassName, sMethodName, stAppInfo);
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			return hmResult;
		}

		// validating input domain
		if (sDomain == null || (sDomain.trim()).length() == 0) {
			sDomain = CommonDefs.SLID_DUM;
		}
		if (sDomain != null && sDomain.equals(CommonDefs.SLID_DUM)) {
			sSearchSLIDNamespace = null;
		}

		sDomain = sDomain.toLowerCase();
		sSuggest1 = sSuggest1.toLowerCase();

		// commented as not required
		/*
		 * if (stDBDomainList == null || stDBDomainList.isEmpty()) { stAppInfo =
		 * "The value of RILHRS_ValidDomains is not configured in property files";
		 * logger.info("{}{}CUIAH_VI.05 : {}", sClassName, sMethodName, stAppInfo);
		 * hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM,
		 * stAppInfo); return hmResult; }
		 */
		ArrayList alDBDomainList = CommonUtil.parseToArray(stDBDomainList, CommonDefs.VALUE_SEPARATOR_CHAR);
		logger.debug("{}{}CUIAH_VI.06 : Property RILHRS_ValidDomains :  {}", sClassName, sMethodName, alDBDomainList);

		if (alDBDomainList != null && !alDBDomainList.contains(sDomain)) {

			stAppInfo = "Invalid Domain :: Input Domain does not match with domain allowed in CheckUserIdAvailability";
			logger.info("{}{}CUIAH_VI.07 : {}", sClassName, sMethodName, stAppInfo);
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			return hmResult;
		}
		hmResult.put(CommonDefs.DOMAIN, sDomain);

		// commented as not required
		// validate max suggestions
		/*
		 * if (sMaxHandleToMPS == null || sMaxHandleToMPS.isEmpty() ||
		 * sMaxSuggestionInConfig == null || sMaxSuggestionInConfig.isEmpty()) {
		 * stAppInfo =
		 * "The value of RILHRS_MaxSuggestionsToMPS or RILHRS_MaxSuggestions are not configured in property files"
		 * ; logger.info("{}{}CUIAH_VI.08 : {}", sClassName, sMethodName, stAppInfo);
		 * hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM,
		 * stAppInfo); return hmResult; }
		 */

		logger.info("{}{}CUIAH_VI.08a : Property RILHRS_MaxSuggestionsToMPS :  {}", sClassName, sMethodName,
				sMaxHandleToMPS);
		logger.info("{}{}CUIAH_VI.08b : Property RILHRS_MaxSuggestions :  {}", sClassName, sMethodName,
				sMaxSuggestionInConfig);

		int maxSuggestionsInConfig = 0;
		int inputNoOfSuggestion = 0;
		if (sMaxSuggestionInConfig != null && !sMaxSuggestionInConfig.isEmpty()) {

			maxSuggestionsInConfig = Integer.parseInt(sMaxSuggestionInConfig);
		}
		if (sNumSuggestions != null && !sNumSuggestions.isEmpty()) {

			inputNoOfSuggestion = Integer.parseInt(sNumSuggestions);
		}
		if (inputNoOfSuggestion == 0 || inputNoOfSuggestion > maxSuggestionsInConfig) {

			stAppInfo = "NoOfSuggestion passed in input :: " + inputNoOfSuggestion
					+ " can not less than 1 or greater than the MaxNoOfSuggestion configured :: "
					+ maxSuggestionsInConfig + " in property file to be returned.";
			logger.info("{}{}CUIAH_VI.09 : {}", sClassName, sMethodName, stAppInfo);
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			return hmResult;
		}

		// validate suggest handles
		if (sSuggest1 != null && sSuggest1.contains("@")) {

			int len = sSuggest1.indexOf('@');

			if (!CommonDefs.SLID_DUM.equalsIgnoreCase(sDomain)) {
				stAppInfo = "domain should be slid.dum for slid email formatted Id";
				logger.info("{}{}CUIAH_VI.10 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			if (inputNoOfSuggestion > 1) {
				stAppInfo = "numSuggestion passed in input can not be greater than 1 for slid email formatted Id";
				logger.info("{}{}CUIAH_VI.10a : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			if (sSuggest2 != null && sSuggest2.trim().length() > 0) {

				stAppInfo = "Suggest2 should not be passed in input for slid email formatted Id";
				logger.info("{}{}CUIAH_VI.10b : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			if (len == 0) {

				stAppInfo = "Suggest1 should not start with @ character for slid email formatted Id";
				logger.info("{}{}CUIAH_VI.10c : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			if (sSuggest1.length() > HANDLE_LENGTH_MAX_FOR_SLID) {

				stAppInfo = "ERROR SLID HANDLE TOO LONG::For slid email formatted Id";
				logger.info("{}{}CUIAH_VI.10d : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			String sSuggest1Handle = sSuggest1.substring(0, len);
			String sSuggest1Domain = sSuggest1.substring(len + 1);
			String sMpsSuggest1Domain = CommonDefs.IND_N;

			if (alDBDomainList != null && alDBDomainList.contains(sSuggest1Domain)) {

				stAppInfo = "AccessId is not allowed to have ATT domain from web registration";
				logger.info("{}{}CUIAH_VI.11 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ID_UNAVAILABLE_NUM, stAppInfo);
				sMpsSuggest1Domain = CommonDefs.IND_Y;
				return hmResult;
			}

			if (sMpsSuggest1Domain.equals(CommonDefs.IND_Y)) {

				HashMap inputGetAllInfo = CommonUtil.getHashMap();
				inputGetAllInfo.put(MPSDefs.DB_MEMBER_NAME, sSuggest1Handle.toLowerCase());
				inputGetAllInfo.put(MPSDefs.DB_DOMAIN_NAME, sSuggest1Domain.toLowerCase());

				getAllInfoHash = getAllInfo.getInfo(inputGetAllInfo, logger);

				if (getAllInfoHash == null || getAllInfoHash.isEmpty()) {

					stAppInfo = "Null Response returned from getAllInfo";
					// TODO:need to check MPSException
					// throw new MPSException("ERR_SYS_APPL");
				}

				sAppStatusCode = (String) getAllInfoHash.get("appStatusCode");

				if (!CErrorDefs.COMMON_SUCCESS.equals(sAppStatusCode)) {

					if (MPSDefs.REC_NOT_FOUND.equals(sAppStatusCode)) {

						stAppInfo = ".net member ID represented by handle/domain does NOT exist within MPS db";
						logger.info("{}{}CUIAH_VI.12 : {}", sClassName, sMethodName, stAppInfo);
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ID_UNAVAILABLE_NUM, stAppInfo);
						return hmResult;
					} else {
						stAppInfo = "getInfo from GetAllInfo failed for given handle and domain";
						logger.info("{}{}CUIAH_VI.12a : {}", sClassName, sMethodName, stAppInfo);
						hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(sAppStatusCode), stAppInfo);
						return hmResult;
					}

				}

				String sSlidmemberNum = (String) getAllInfoHash.get(MPSDefs.DB_SLID_MEMBER_NUM);

				if (sSlidmemberNum != null && sSlidmemberNum.trim().length() > 0) {
					stAppInfo = ".net member ID represented by handle/domain is already linked to a slid";
					logger.info("{}{}CUIAH_VI.13 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ID_UNAVAILABLE_NUM, stAppInfo);
					return hmResult;
				}
			}
		} else {

			if (CommonDefs.SLID_DUM.equalsIgnoreCase(sDomain)) {

				sDomainLessSlid = CommonDefs.IND_Y;
			}
		}
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		hmResult.put(CommonDefs.RILHRS_MAX_SUGGESTIONS_TO_MPS, sMaxHandleToMPS);
		hmResult.put(CommonDefs.TRANSACTION_ID, hmCheckUserInput.get(CommonDefs.TRANSACTION_ID));
		hmResult.put(CommonDefs.TRANSACTION_NAME, hmCheckUserInput.get(CommonDefs.TRANSACTION_NAME));
		hmResult.put(CommonDefs.CALLING_SYSTEM_ID, hmCheckUserInput.get(CommonDefs.CALLING_SYSTEM_ID));
		hmResult.put(CommonDefs.SUGGEST1, sSuggest1);
		hmResult.put(CommonDefs.DOMAIN, sDomain);
		hmResult.put(CommonDefs.NUM_SUGGESTIONS, sNumSuggestions);
		hmResult.put(CommonDefs.SUGGEST2, sSuggest2);
		if (sSearchSLIDNamespace != null && (sSearchSLIDNamespace.trim()).length() > 0) {
			hmResult.put(CommonDefs.SEARCH_SLID_NAME_SPACE, sSearchSLIDNamespace);
		}
		if (sDomainLessSlid != null && sDomainLessSlid.equals(MPSDefs.YES)) {
			hmResult.put("domainLessSlid", sDomainLessSlid);
		}
		return hmResult;
	}

	private HashMap<String, Object> validateCheckUserCallingSystemId(Map<String, Object> hmCheckUserInput) {

		String sMethodName = ".validateCheckUserCallingSystemIdAndDomain.";
		HashMap<String, Object> hmResult = CommonUtil.getHashMap();
		String sIsExternalCall = (String) hmCheckUserInput.get(CommonDefs.IS_EXTERNAL_CALL);
		String sCallingSystemId = (String) hmCheckUserInput.get(CommonDefs.CALLING_SYSTEM_ID);
		sCallingSystemId = sCallingSystemId.trim().toUpperCase();

		ArrayList<String> alValidCallingSystemId = CommonUtil.parseToArray(stCheckIdAvailabilityCSI,
				CommonDefs.VALUE_SEPARATOR_CHAR);
		logger.info("{}{}CUIAH_VI.02 : Property RILHRS_VALID_CSIDs : {}", sClassName, sMethodName,
				alValidCallingSystemId);

		if (alValidCallingSystemId != null && !alValidCallingSystemId.contains(sCallingSystemId)
				&& sIsExternalCall != null && sIsExternalCall.equals("Y")) {
			String stAppInfo = "Invalid CallingSystemId :: Input CallingSystemId is not valid for CheckUserIdAvailability "
					+ "Transaction";
			logger.info("{}{}CUIAH_VI.03 : {}", sClassName, sMethodName, stAppInfo);
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			return hmResult;
		}

		return hmResult;
	}

	/**
	 * This method performs a series of checks on a given user ID (handle) to ensure
	 * its validity. It checks for illegal characters, length constraints, reserved
	 * patterns, and whether the handle is already in use. It interacts with the
	 * BadWordHelper class to scan for inappropriate words in the handle. It also
	 * interacts with the MemberRepositoryImpl class to perform database operations.
	 *
	 * @param handle               A String representing the user ID to be checked.
	 * @param domain               A String representing the domain of the user ID.
	 * @param suggest1             A String representing the first suggested user
	 *                             ID.
	 * @param hmInputtoHandleCheck A HashMap containing the necessary information
	 *                             for checking the user ID. This includes details
	 *                             like the transaction ID, transaction name,
	 *                             calling system ID, and other relevant data.
	 * @param logger               A Logger instance used for logging information
	 *                             and errors.
	 * @return A HashMap containing the result of the operation. This includes
	 *         status codes and messages indicating the success or failure of the
	 *         operation.
	 * @throws Exception If any error occurs during the process.
	 */
	public HashMap<String, Object> doHandleChecks(String handle, String domain, String suggest1,
			HashMap<String, Object> hmInputtoHandleCheck, Logger logger) {
		String sMethodName = ".doHandleChecks.";
		String stAppInfo = null;

		String sHandle = handle.toLowerCase();
		String sDomain = domain.toLowerCase();
		int iHandleLen = sHandle.length();

		HashMap<String, Object> hmResult = new HashMap<String, Object>();

		try {

			for (int i = 0; i < iHandleLen; i++) {
				if ((sLegalHandleChar != null && !sLegalHandleChar.isEmpty())
						&& sLegalHandleChar.indexOf(sHandle.charAt(i)) == -1) {
					if (suggest1 != null && suggest1.contains("@") && sHandle.contains("@")) {
						stAppInfo = "allowing @ for slid email formatted Id ";
						logger.info("{}{}CUIAH.11 : {}", sClassName, sMethodName, stAppInfo);
					} else {
						stAppInfo = "ERROR ILLEGAL CHARACTERS IN HANDLE";
						logger.error("{}{}CUIAH.12 : {}", sClassName, sMethodName, stAppInfo);
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
						return hmResult;
					}
				}
			}

			if (sDomain != null && sDomain.equals(CommonDefs.SLID_DUM)) {
				if (iHandleLen > HANDLE_LENGTH_MAX_FOR_SLID) {
					stAppInfo = "ERROR SLID HANDLE TOO LONG::";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
					logger.error("{}{}CUIAH.13 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
				if (iHandleLen < HANDLE_LENGTH_MIN_FOR_SLID) {
					stAppInfo = "ERROR SLID HANDLE TOO SHORT::";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
					logger.error("{}{}CUIAH.14 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}

			} else {

				if (iHandleLen > HANDLE_LENGTH_MAX) {
					stAppInfo = "ERROR HANDLE TOO LONG::";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
					logger.error("{}{}CUIAH.15 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
				if (iHandleLen < HANDLE_LENGTH_MIN) {
					stAppInfo = "ERROR HANDLE TOO SHORT::";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
					logger.error("{}{}CUIAH.16 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
			}

			outer: if (sDomain.equals("prodigy.net")) {
				if (iHandleLen != 7)
					break outer;
				if (!(Character.isLetter(sHandle.charAt(0))))
					break outer;
				if (!(Character.isLetter(sHandle.charAt(1))))
					break outer;
				if (!(Character.isLetter(sHandle.charAt(2))))
					break outer;
				if (!(Character.isLetter(sHandle.charAt(3))))
					break outer;
				if (!(Character.isDigit(sHandle.charAt(4))))
					break outer;
				if (!(Character.isDigit(sHandle.charAt(5))))
					break outer;
				if (!(Character.isLetter(sHandle.charAt(6))))
					break outer;

				stAppInfo = "ERROR HANDLE IN CLASSIC PATTERN::";
				logger.error("{}{}CUIAH.16 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			if (!(Character.isLetterOrDigit(sHandle.charAt(0)))) {
				stAppInfo = "ERROR HANDLE FIRST CHARACTER NOT ALPHANUMERIC::";
				logger.error("{}{}CUIAH.17 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			if (!(Character.isLetterOrDigit(sHandle.charAt(iHandleLen - 1)))) {
				stAppInfo = "ERROR HANDLE LAST CHARACTER NOT ALPHANUMERIC::";
				logger.error("{}{}CUIAH.18 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			if (sHandle != null && !sHandle.isEmpty()) {
				boolean bLetterPresent = false;
				for (int i = 0; i < iHandleLen; i++) {
					char c = sHandle.charAt(i);
					if (Character.isLetter(c)) {
						bLetterPresent = true;
						break;
					}
				}
				if (!bLetterPresent) {
					stAppInfo = "ERROR HANDLE CAN NOT HAVE ALL DIGITS OR SPECIAL CHAR";
					logger.error("{}{}CUIAH.19 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
					return hmResult;
				}
			}

			if (sHandle != null && sHandle.startsWith("sbcis")) {
				stAppInfo = " ERROR HANDLE BEGINS WITH 'sbcis'";
				logger.error("{}{}CUIAH.20 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			String stTransactionId = (String) hmInputtoHandleCheck.get(CommonDefs.TRANSACTION_ID);
			String stTransactionName = (String) hmInputtoHandleCheck.get(CommonDefs.TRANSACTION_NAME);
			String stCallingSystemId = (String) hmInputtoHandleCheck.get(CommonDefs.CALLING_SYSTEM_ID);
			String stIgnoreQay = (String) hmInputtoHandleCheck.get("ignoreQay");

			String sBypassBadWordCheck = (String) hmInputtoHandleCheck.get("bypassBadWordCheck");
			if (sBypassBadWordCheck != null && sBypassBadWordCheck.trim().equalsIgnoreCase(CommonDefs.IND_Y)) {
				stAppInfo = "Bypassing BadWordHelper call and returning SUCCESS";
				logger.info("{}{}CUIAH.21 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
				return hmResult;
			}

			HashMap hmBadWordInput = CommonUtil.getHashMap();

			hmBadWordInput.put(CommonDefs.TRANSACTION_NAME, stTransactionName);
			hmBadWordInput.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
			hmBadWordInput.put(CommonDefs.TRANSACTION_ID, stTransactionId);
			hmBadWordInput.put(CommonDefs.ITEM, sHandle);
			hmBadWordInput.put(CommonDefs.ITEM_TYPE, CommonDefs.HANDLE);

			if (stIgnoreQay != null && stIgnoreQay.trim().equals(CommonDefs.IND_Y)) {
				hmBadWordInput.put("ignoreQay", stIgnoreQay);
			}
			logger.debug(SpiMarker.getInstance(), "{}{}CUIAH.22 :: hmInput to BadWordHelper.scanWords :: ", sClassName,
					sMethodName, StructuredArguments.entries(hmBadWordInput));

			hmResult = oBadWordHelper.scanWords(hmBadWordInput);

		} catch (Exception e) {
			logger.info("Exception occured"+e);
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown CheckUserIdAvailabilityHelper.doHandleChecks method : " + hmResult;
			logger.info("{}{}CUIAH.23 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));

		}

		return hmResult;
	}

	/**
	 * This method checks the availability of multiple user IDs with the Member
	 * Service Platform (MPS). It validates the input, checks the availability of
	 * the user IDs, and interacts with the MemberRepositoryImpl class to perform
	 * database operations. It also handles exceptions and logs the necessary
	 * information for debugging purposes.
	 *
	 * @param hmHandleToMps A HashMap containing the necessary information for
	 *                      checking the availability of user IDs. This includes
	 *                      details like the transaction ID, transaction name,
	 *                      calling system ID, and other relevant data.
	 * @param logger        A Logger instance used for logging information and
	 *                      errors.
	 * @return A HashMap containing the result of the operation. This includes
	 *         status codes and messages indicating the success or failure of the
	 *         operation.
	 * @throws Exception If any error occurs during the process.
	 */
	public HashMap<String, Object> checkMps(HashMap<String, Object> hmHandleToMps, Logger logger) {
		String sMethodName = ".checkMps.";
		String stAppInfo = null;
		HashMap<String, Object> hmResult = null;
		HashMap<String, Object> hmInput = CommonUtil.getHashMap();
		int inputNoOfSuggestion = 0;
		String stAppStatusCode = null;

		try {

			ArrayList alHandleToMps = (ArrayList) hmHandleToMps.get(CommonDefs.SUGGEST_LIST);
			String stDomain = (String) hmHandleToMps.get(CommonDefs.DOMAIN);
			String stTransactionId = (String) hmHandleToMps.get(CommonDefs.TRANSACTION_ID);
			String stSuggest1 = (String) hmHandleToMps.get(CommonDefs.SUGGEST1);
			String stNoOfSuggestion = (String) hmHandleToMps.get(CommonDefs.NUM_SUGGESTIONS);
			String stSearchSLIDNamespace = (String) hmHandleToMps.get(CommonDefs.SEARCH_SLID_NAME_SPACE);

			if (stNoOfSuggestion != null && !stNoOfSuggestion.isEmpty()) {

				inputNoOfSuggestion = Integer.parseInt(stNoOfSuggestion);
			}

			hmInput.put(MPSDefs.WS_DOMAIN, stDomain);

			if (alHandleToMps != null && !alHandleToMps.isEmpty()) {
				hmInput.put(MPSDefs.TXT_USERCOUNT, Integer.toString(alHandleToMps.size()));
			}

			if (CommonDefs.IND_Y.equals(stSearchSLIDNamespace)) {
				hmInput.put(CommonDefs.SEARCH_SLID_NAME_SPACE, stSearchSLIDNamespace);
			}

			String hashKey = null;

			for (int i = 0; i < alHandleToMps.size(); i++) {
				hashKey = "wsUserId" + "-" + (i + 1);
				String hashValue = (String) alHandleToMps.get(i);
				hmInput.put(hashKey, hashValue);
			}

			hmResult = oMemberServiceRepoImpl.checkUserList(hmInput);

			if (hmResult == null || hmResult.isEmpty()) {

				stAppInfo = "Null Response returned from checkUserList";
				logger.error("{}{}CUIAH.CMPS.01 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (stAppStatusCode == null || !stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
				stAppInfo = "Empty or Error appStatus code returned from mps.";
				logger.error("{}{}CUIAH.CMPS.02 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				return hmResult;
			}

			ArrayList alResponseHandle = CommonUtil.getArrayList();

			for (int i = 0; i < alHandleToMps.size(); i++) {
				String suggestion = (String) alHandleToMps.get(i);
				hashKey = MPSDefs.TXT_USERNAME + suggestion;

				String stFoundInMps = (String) hmResult.get(hashKey);
				if (stFoundInMps == null) {
					stAppInfo = "MPS returned missing response for: " + hashKey;
					logger.error("{}{}CUIAH.CMPS.03 : {}", sClassName, sMethodName,
							HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					break;
				}
				if (stFoundInMps.equals(MPSDefs.TXT_NOTFOUND)) {
					alResponseHandle.add(suggestion);
				}
			}

			if ((alResponseHandle == null || alResponseHandle.isEmpty())
					|| (alResponseHandle.size() < inputNoOfSuggestion)) {

				if (inputNoOfSuggestion == 1) {
					String stLinkedFnUserStatus = (String) hmResult.get(CommonDefs.LINKED_FN_USER_STATUS);
					stAppInfo = "UserId not available for use.";
					logger.error("{}{}CUIAH.CMPS.04 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ID_UNAVAILABLE_NUM, stAppInfo);
					// changes by pm675e:PID#400970d linkedFNUserStatus is returned
					// ERR_ID_UNAVAILABLE when is thrown
					if (StringUtils.isNotBlank(stLinkedFnUserStatus)) {
						hmResult.put(CommonDefs.LINKED_FN_USER_STATUS, stLinkedFnUserStatus);
					}
				} else {
					stAppInfo = "Unable to Suggest Handle::All Generated Handle found in MPS DB";
					logger.error("{}{}CUIAH.CMPS.05 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_SUGGEST_HANDLE_NUM, stAppInfo);
				}

				return hmResult;
			}

			if (alResponseHandle != null && !alResponseHandle.isEmpty()) {
				ArrayList alFinalList = CommonUtil.getArrayList();
				for (int i = 0; i < alResponseHandle.size(); i++) {
					alFinalList.add(alResponseHandle.get(i));

					if (alFinalList.size() >= inputNoOfSuggestion) {
						break;
					}
				}

				if (inputNoOfSuggestion == 1) {
					for (int k = 0; k < alFinalList.size(); k++) {
						if (stSuggest1 != null && !stSuggest1.equals(alFinalList.get(k))) {
							stAppInfo = "UserId not available for use.";
							logger.error("{}{}CUIAH.CMPS.06 : {}", sClassName, sMethodName, stAppInfo);
							hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ID_UNAVAILABLE_NUM, stAppInfo);
							return hmResult;
						}
					}
				}
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

				ArrayList alSuggestList = CommonUtil.getArrayList();
				for (int k = 0; k < alFinalList.size(); k++) {
					HashMap temp = CommonUtil.getHashMap();
					temp.put(CommonDefs.SUGGEST, alFinalList.get(k));
					alSuggestList.add(temp);

				}

				if (!alSuggestList.isEmpty()) {
					hmResult.put("suggestList", alSuggestList);
				}

				hmResult.put(CommonDefs.TRANSACTION_ID, stTransactionId);
				hmResult.put(CommonDefs.DOMAIN, stDomain);

			}

		} catch (Exception e) {
			logger.info("Exception occured {}",e);
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown CheckUserIdAvailabilityHelper.checkMPS method : " + hmResult;
			logger.info("{}{}CUIAH.CMPS.07 : {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));

		}

		return hmResult;
	}

}
