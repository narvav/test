package com.att.idp.idgraphusermanagementms.db.helper;

import java.sql.SQLException;
import java.util.*;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * DBHelper is a class that extends MPSDefs. It contains helper methods for components that access MPS databases.
 * It provides various methods to interact with the database such as getting the next unique primary key, 
 * retrieving domain ID, domain name, SOR ID, SOR name, security question ID, service ID, service name, 
 * access ID, access name, status code, status name by code, contact ID, role ID, and attribute ID from name.
 * It also provides a method to get a list of services from the database.
 * 
 * This class uses Spring's JdbcTemplate for database operations and uses SQL queries to interact with the database.
 * 
 * It uses the @Component annotation to indicate that it is a Spring component and can be autowired where needed.
 * 
 * Note: This class throws MPSException in case of any database operation failures.
 */
@Component
public class DBHelper extends MPSDefs {

	public static final Logger logger = LoggerFactory.getLogger(DBHelper.class);
	private static String sClassName = "SecurityQuestionHelper";
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	private static String wtnQuery = "SELECT mem.member_name, dom.domain_name "
			+ "FROM MEMBER mem, DOMAIN dom, DSLUSER dslUser " + "WHERE mem.domain_id = dom.domain_id AND "
			+ "mem.member_num= dslUser.member_num AND " + "mem.parent_child_ind='P' AND " + "dslUser.wtn = ?";
	

	// The getNext<name>Id methods retrieve the next unique
	// primary key.
	/**
	 * 
	 * @return long
	 * @throws SQLException
	 */
	public long getNextMemberId() throws MPSException {

		return getNextId("member_num_seq");
	} // getNextMemberId

	/**
	 * 
	 * @return long
	 * @throws SQLException
	 */
	public long getNextMemberGroupId() throws MPSException {

		return getNextId("group_num_seq");
	} // getNextGroupMemberId

	/**
	 * This method retrieves the domain ID for a given domain name from the database.
	 * It prepares a SQL query to select the domain ID from the 'domain' table where the domain name matches the input.
	 * The method executes the query using JdbcTemplate and processes the query response.
	 * If the domain name is found in the database, the corresponding domain ID is returned.
	 * If the domain name is not found, the method returns 0.
	 * In case of any exception during the process, it throws an MPSException with the error message.
	 *
	 * @param domainName The name of the domain for which the ID is to be retrieved.
	 * @return The ID of the domain if found, 0 otherwise.
	 * @throws MPSException If there is an exception during the process.
	 */
	@Cacheable("getDomainId")
	public int getDomainId(String domainName) throws MPSException {

		String sMethodName = ".getDomainId.";
		String selectStatement = "SELECT domain_id FROM domain WHERE domain_name = ?";

		int domainId = 0;
		List<Object> objectList = new ArrayList<Object>();

		try {
			objectList.add(domainName);

			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement),
					objectList.toArray(new Object[objectList.size()]));

			for (int j = 0; j < alQueryResponse.size(); j++) {
				Map hmQueryResponse = (Map)alQueryResponse.get(j);
				domainId = Integer.parseInt(hmQueryResponse.get(MPSDefs.DB_DOMAIN_ID).toString());
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			logger.info("{}{}DBH_GDI.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getDomainId::" + e.getMessage());

		} finally {

		}
		return domainId;
	} // getDomainId

	/**
	 * This method retrieves the domain name for a given domain ID from the database.
	 * It prepares a SQL query to select the domain name from the 'domain' table where the domain ID matches the input.
	 * The method executes the query using JdbcTemplate and processes the query response.
	 * If the domain ID is found in the database, the corresponding domain name is returned.
	 * If the domain ID is not found, the method returns an empty string.
	 * In case of any exception during the process, it throws an MPSException with the error message.
	 *
	 * @param domainId The ID of the domain for which the name is to be retrieved.
	 * @return The name of the domain if found, an empty string otherwise.
	 * @throws MPSException If there is an exception during the process.
	 */
	@Cacheable("getDomainName")
	public String getDomainName(String domainId) throws MPSException {

		String sMethodName = ".getDomainName.";
		String selectStatement = "SELECT domain_name FROM domain WHERE domain_id = ?";

		String domainName = "";
		List<Object> objectList = new ArrayList<Object>();

		try {
			objectList.add(domainId);

			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement),
					objectList.toArray(new Object[objectList.size()]));

			for (int j = 0; j < alQueryResponse.size(); j++) {
				Map hmQueryResponse = (Map) alQueryResponse.get(j);
				domainName = (String) hmQueryResponse.get(MPSDefs.DB_DOMAIN_NAME);
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			logger.info("{}{}DBH_GDN.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getDomainName::" + e.getMessage());

		} finally {

		}
		return domainName;
	} // getDomainName

	/**
	 * This method retrieves the System of Record (SOR) ID for a given SOR name from the database.
	 * It prepares a SQL query to select the SOR ID from the 'systemofrecord' table where the SOR name matches the input.
	 * The method executes the query using JdbcTemplate and processes the query response.
	 * If the SOR name is found in the database, the corresponding SOR ID is returned.
	 * If the SOR name is not found, the method returns 0.
	 * In case of any exception during the process, it throws an MPSException with the error message.
	 *
	 * @param sorName The name of the System of Record for which the ID is to be retrieved.
	 * @return The ID of the System of Record if found, 0 otherwise.
	 * @throws MPSException If there is an exception during the process.
	 */
	@Cacheable("getSorId")
	public int getSorId(String sorName) throws MPSException {
		String sMethodName = ".getSorId.";
		String selectStatement = "SELECT sor_id FROM systemofrecord WHERE sor_name = ?";
		int sorId = 0;
		List<Object> objectList = new ArrayList<Object>();

		try {
			objectList.add(sorName);
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement),
					objectList.toArray(new Object[objectList.size()]));

			for (int j = 0; j < alQueryResponse.size(); j++) {
				Map hmQueryResponse = (Map) alQueryResponse.get(j);
				sorId = Integer.parseInt(hmQueryResponse.get(MPSDefs.DB_SOR_ID).toString());
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			logger.info("{}{}DBH_GDI.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getSorId::" + e.getMessage());

		} finally {

		}
		return sorId;
	} // getSorId

	/**
	 * This method retrieves the System of Record (SOR) name for a given SOR ID from the database.
	 * It prepares a SQL query to select the SOR name from the 'systemofrecord' table where the SOR ID matches the input.
	 * The method executes the query using JdbcTemplate and processes the query response.
	 * If the SOR ID is found in the database, the corresponding SOR name is returned.
	 * If the SOR ID is not found, the method returns an empty string.
	 * In case of any exception during the process, it throws an MPSException with the error message.
	 *
	 * @param sorId The ID of the System of Record for which the name is to be retrieved.
	 * @return The name of the System of Record if found, an empty string otherwise.
	 * @throws MPSException If there is an exception during the process.
	 */
	@Cacheable("getSorName")
	public String getSorName(String sorId) throws MPSException {
		String sMethodName = ".getSorName.";
		String selectStatement = "SELECT sor_name FROM systemofrecord WHERE sor_id = ?";
		String sorName = "";
		List<Object> objectList = new ArrayList<Object>();

		try {
			objectList.add(sorId);
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement),
					objectList.toArray(new Object[objectList.size()]));

			for (int j = 0; j < alQueryResponse.size(); j++) {
				Map hmQueryResponse = (Map) alQueryResponse.get(j);
				sorName = (String) hmQueryResponse.get(MPSDefs.DB_SOR_NAME);
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			logger.info("{}{}DBH_GSN.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getSorName::" + e.getMessage());

		} finally {

		}
		return sorName;
	} // getSorName

	/**
	 * This method retrieves the security question ID for a given security question from the database.
	 * It prepares a SQL query to select the security question ID from the 'SecurityQuestion' table where the security question matches the input.
	 * The method executes the query using JdbcTemplate and processes the query response.
	 * If the security question is found in the database, the corresponding security question ID is returned.
	 * If the security question is not found, the method returns -1.
	 * In case of any exception during the process, it throws an MPSException with the error message.
	 *
	 * @param sSecurityQuestion The security question for which the ID is to be retrieved.
	 * @return The ID of the security question if found, -1 otherwise.
	 * @throws MPSException If there is an exception during the process.
	 */
	@Cacheable("getSecurityQuestionId")
	public int getSecurityQuestionId(String sSecurityQuestion) throws MPSException {

		String sMethodName = ".getSecurityQuestionId.";
		if (sSecurityQuestion != null && sSecurityQuestion.length() > 80) {
			sSecurityQuestion = sSecurityQuestion.substring(0, 80);
		}
		String selectStatement = "SELECT security_question_id FROM SecurityQuestion WHERE SUBSTR(TRIM(LOWER(security_question)), 1, 80) = TRIM(LOWER(?))";

		List<Object> objectList = new ArrayList<Object>();
		int iSecurityQuestionId = -1;

		try {
			objectList.add(sSecurityQuestion);
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement),
					objectList.toArray(new Object[objectList.size()]));

			for (int j = 0; j < alQueryResponse.size(); j++) {
				Map hmQueryResponse = (Map) alQueryResponse.get(j);
				iSecurityQuestionId = Integer.parseInt(hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_ID).toString());
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			logger.info("{}{}DBH_GSQI.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getSecurityQuestionId::" + e.getMessage());
		} finally {

		}
		return iSecurityQuestionId;
	} // End getSecurityQuestionId
	
	@Cacheable("getNextId")
	private long getNextId(String sequence) throws MPSException {
		
		String sMethodName = ".getNextId.";
		String selectStatement = "SELECT " + sequence + ".NEXTVAL FROM dual";
		long id = 0;

		try {
			List alQueryResponse = jdbcTemplate.queryForList(selectStatement, String.class);

			id = Long.parseLong((String) alQueryResponse.get(0));

			if (id <= 0) {
				throw new MPSException("Sequence " + sequence + " is empty.");
			}
		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			logger.info("{}{}DBH_GNI.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getNextId::" + e.getMessage());

		} finally {

		}
		// "return id" should be outside the finally block, or else any exception thrown
		// in try/catch block will not be returned to the caller.
		return id;

	} // getNextId

	/**
	 * 
	 * @param serviceName
	 * @return int
	 */
	@Cacheable("getServiceId")
	public int getServiceId(String serviceName) throws MPSException {
		String sMethodName = ".getServiceId.";
		String selectStatement = "SELECT service_id FROM service WHERE service_name = ?";
		int serviceId = 0;
		List<Object> objectList = new ArrayList<Object>();

		try {
			objectList.add(serviceName);
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement),
					objectList.toArray(new Object[objectList.size()]));

			for (int j = 0; j < alQueryResponse.size(); j++) {
				Map hmQueryResponse = (Map) alQueryResponse.get(j);
				serviceId = Integer.parseInt(hmQueryResponse.get("service_id").toString());
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			logger.info("{}{}DBH_GSI.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getServiceId::" + e.getMessage());

		} finally {

		}
		return serviceId;
	} // getServiceId

	/**
	 * 
	 * @param serviceId
	 * @return String
	 */
	@Cacheable("getServiceName")
	public String getServiceName(String serviceId) throws MPSException {
		String sMethodName = ".getServiceName.";
		String selectStatement = "SELECT service_name FROM service WHERE service_id = ?";
		List<Object> objectList = new ArrayList<Object>();
		String serviceName = "";

		try {
			objectList.add(serviceId);
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement),
					objectList.toArray(new Object[objectList.size()]));

			for (int j = 0; j < alQueryResponse.size(); j++) {
				Map hmQueryResponse = (Map) alQueryResponse.get(j);
				serviceName = (String) hmQueryResponse.get("service_name");
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			logger.info("{}{}DBH_GSN.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getServiceName::" + e.getMessage());

		} finally {

		}
		return serviceName;
	} // getServiceName

	/**
	 * 
	 * @param accessName
	 * @return int
	 * @throws SQLException
	 */
	@Cacheable("getAccessId")
	public int getAccessId(String accessName) throws MPSException {
		String sMethodName = ".getAccessId.";
		String selectStatement = "SELECT access_id FROM networkaccess WHERE access_name = ?";
		List<Object> objectList = new ArrayList<Object>();

		int accessId = 0;

		try {
			objectList.add(accessName);
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement),
					objectList.toArray(new Object[objectList.size()]));

			for (int j = 0; j < alQueryResponse.size(); j++) {
				Map hmQueryResponse = (Map) alQueryResponse.get(j);
				accessId = Integer.parseInt(hmQueryResponse.get("access_id").toString());
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			logger.info("{}{}DBH_GAI.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getAccessId::" + e.getMessage());

		} finally {

		}
		return accessId;
	} // getAccessId

	/**
	 * 
	 * @param accessId
	 * @return String
	 */
	@Cacheable("getAccessName")
	public String getAccessName(String accessId) throws MPSException {
		String sMethodName = ".getAccessName.";
		String selectStatement = "SELECT access_name FROM networkaccess WHERE access_id = ?";
		List<Object> objectList = new ArrayList<Object>();

		String accessName = "";

		try {
			objectList.add(accessId);
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement),
					objectList.toArray(new Object[objectList.size()]));

			for (int j = 0; j < alQueryResponse.size(); j++) {
				Map hmQueryResponse = (Map) alQueryResponse.get(j);
				accessName = (String) hmQueryResponse.get("access_name");
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			logger.info("{}{}DBH_GAN.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getAccessName::" + e.getMessage());

		} finally {

		}
		return accessName;
	} // getAccessName

	/**
	 * 
	 * @param statusName
	 * @return int
	 * @throws MPSException
	 */
	@Cacheable("getStatusCode")
	public int getStatusCode(String statusName) throws MPSException {
		String sMethodName = ".getStatusCode.";
		String selectStatement = "SELECT status_code FROM status WHERE status_name = ?";
		List<Object> objectList = new ArrayList<Object>();
		int statusCode = 0;

		try {
			objectList.add(statusName);
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement),
					objectList.toArray(new Object[objectList.size()]));

			for (int j = 0; j < alQueryResponse.size(); j++) {
				Map hmQueryResponse = (Map) alQueryResponse.get(j);
				statusCode = Integer.parseInt(hmQueryResponse.get("status_code").toString());
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			logger.info("{}{}DBH_GSC.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getStatusCode::" + e.getMessage());

		} finally {

		}
		return statusCode;
	} // getStatusCode

	/**
	 * 
	 * @param statusCode
	 * @return String
	 * @throws MPSException
	 */
	@Cacheable("getStatusNameByCode")
	public String getStatusNameByCode(int statusCode) throws MPSException {
		String sMethodName = ".getStatusNameByCode.";
		String selectStatement = "SELECT status_name FROM status WHERE status_code = ?";
		List<Object> objectList = new ArrayList<Object>();
		String statusName = "";

		try {
			objectList.add(statusCode);
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement),
					objectList.toArray(new Object[objectList.size()]));

			for (int j = 0; j < alQueryResponse.size(); j++) {
				Map hmQueryResponse = (Map) alQueryResponse.get(j);
				statusName = (String) (hmQueryResponse.get("status_name"));
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			logger.info("{}{}DBH_GSNBC.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getStatusNameByCode::" + e.getMessage());

		} finally {

		}
		return statusName;
	} // getStatusNameByCode	

	/**
	 * sm22y : Added method getNextContactId for Open Portal 2012 Mobile Flow
	 * 
	 * @return returns long id.
	 * @throws SQLException
	 */
	public long getNextContactId() throws MPSException {
		return getNextId("contact_seq");
	}

	private static final String QUERY_SERVICE_SQL =
			" select service_id, service_name, service_type, service_desc, email_eligible, subaccount_eligible, entity_type, major_service_id, " +
					"process_dynamically, eligibility, single_instance, unique_instance, merge_action, transfer_of_ownership, access_group, promote, inherit, cpni_addresses_available, authorized_user, use_dynamic_notification, calling_system_ids, sor_names"+
					" from SERVICE " +
					" order by service_id ASC ";

	/**
	 * This method retrieves a list of services from the database and organizes them into a HashMap.
	 * Each service is represented as a HashMap of its details, and these are grouped by service name.
	 * If the jdbcTemplate is null, an error map is returned with an appropriate error message.
	 * If no services are found in the database, an error map is returned with an appropriate error message.
	 * If an exception occurs during the process, an exception map is returned with the exception message.
	 *
	 * @return A HashMap containing the services grouped by service name. Each service is represented as a HashMap of its details.
	 * If an error occurs, a map with the error message is returned.
	 */
	@Cacheable("getServices")
	public HashMap<String, Object> getServices ()
	{
		ArrayList<HashMap<String, Object>> alServices = null;
		HashMap<String, Object> hmDbServices = new HashMap<String, Object>();
		String sServiceName = "";

		try {
			if (jdbcTemplate == null) {
				hmDbServices = CommonErrorMap.makeCategoryMap(
						CErrorDefs.ERR_SYS_APPL_NUM, "jdbcTemplate is null.");
				return hmDbServices;
			}

			List<Map<String, Object>> alQueryResponse = jdbcTemplate.queryForList(QUERY_SERVICE_SQL);
			boolean hasRecords = false;
			HashMap<String, Object> hmServiceDetails = null;

            for (Map<String, Object> stringObjectMap : alQueryResponse) {
                hasRecords = true;
                Map<String, Object> hmQueryResponse = (Map) stringObjectMap;
                hmServiceDetails = CommonUtil.getHashMap();

                for (String key : hmQueryResponse.keySet()) {
                    Object value = hmQueryResponse.get(key);
                    String strValue = (value == null ? null : value.toString());
                    hmQueryResponse.put(key, strValue);
                }

                hmServiceDetails.put(MPSDefs.DB_SERVICE_ID, hmQueryResponse.get(MPSDefs.DB_SERVICE_ID).toString());
                hmServiceDetails.put(MPSDefs.DB_SERVICE_NAME, (String) hmQueryResponse.get(MPSDefs.DB_SERVICE_NAME));
                hmServiceDetails.put(MPSDefs.DB_SERVICE_TYPE, (String) hmQueryResponse.get(MPSDefs.DB_SERVICE_TYPE));
                hmServiceDetails.put("service_desc", (String) hmQueryResponse.get("service_desc"));
                hmServiceDetails.put(MPSDefs.DB_EMAIL_ELIGIBLE, (String) hmQueryResponse.get(MPSDefs.DB_EMAIL_ELIGIBLE));
                hmServiceDetails.put("subaccount_eligible", (String) hmQueryResponse.get("subaccount_eligible"));
                hmServiceDetails.put("entity_type", (String) hmQueryResponse.get("entity_type"));
                hmServiceDetails.put("major_service_id", hmQueryResponse.get("major_service_id"));
                hmServiceDetails.put("process_dynamically", (String) hmQueryResponse.get("process_dynamically"));
                hmServiceDetails.put("eligibility", (String) hmQueryResponse.get("eligibility"));
                hmServiceDetails.put("single_instance", (String) hmQueryResponse.get("single_instance"));
                hmServiceDetails.put("unique_instance", (String) hmQueryResponse.get("unique_instance"));
                hmServiceDetails.put("merge_action", (String) hmQueryResponse.get("merge_action"));
                hmServiceDetails.put("transfer_of_ownership", (String) hmQueryResponse.get("transfer_of_ownership"));
                hmServiceDetails.put("access_group", (String) hmQueryResponse.get("access_group"));
                hmServiceDetails.put("promote", (String) hmQueryResponse.get("promote"));
                hmServiceDetails.put("inherit", (String) hmQueryResponse.get("inherit"));
                hmServiceDetails.put("cpni_addresses_available", (String) hmQueryResponse.get("cpni_addresses_available"));
                hmServiceDetails.put("authorized_user", (String) hmQueryResponse.get("authorized_user"));
                hmServiceDetails.put("use_dynamic_notification", (String) hmQueryResponse.get("use_dynamic_notification"));
                hmServiceDetails.put("calling_system_ids", (String) hmQueryResponse.get("calling_system_ids"));
                hmServiceDetails.put("sor_names", (String) hmQueryResponse.get("sor_names"));

                sServiceName = (String) hmQueryResponse.get(MPSDefs.DB_SERVICE_NAME);
                if (hmDbServices.containsKey(sServiceName)) {
                    alServices = (ArrayList) hmDbServices.get(sServiceName);
                } else {
                    alServices = CommonUtil.getArrayList();
                    hmDbServices.put(sServiceName, alServices);
                }
                alServices.add(hmServiceDetails);
            }

			if (!hasRecords) {
				hmDbServices = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, "No row found");
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmDbServices = CommonErrorMap.makeExceptionMap(e);

		}
		return hmDbServices;
	}

	/**
	 * This method retrieves the role ID for a given role name and service ID from the database.
	 * It prepares a SQL query to select the role ID from the 'servicerole' table where the role name and service ID match the inputs.
	 * The method executes the query using JdbcTemplate and processes the query response.
	 * If the role name and service ID are found in the database, the corresponding role ID is returned.
	 * If the role name and service ID are not found, the method returns 0.
	 * In case of any exception during the process, it throws an MPSException with the error message.
	 *
	 * @param sRoleName The name of the role for which the ID is to be retrieved.
	 * @param sServiceId The ID of the service for which the role ID is to be retrieved.
	 * @return The ID of the role if found, 0 otherwise.
	 * @throws MPSException If there is an exception during the process.
	 */
	@Cacheable("getRoleId")
	public int getRoleId(String sRoleName, int sServiceId) throws MPSException {
		String sMethodName = ".getRoleId.";
		String selectStatement = "SELECT role_id FROM servicerole WHERE role_name = ? and service_id = ?";
		int role_id = 0;
		List<Object> objectList = new ArrayList<Object>();
		try {
			objectList.add(sRoleName);
			objectList.add(sServiceId);
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement),
					objectList.toArray(new Object[objectList.size()]));
            for (Object o : alQueryResponse) {
                Map hmQueryResponse = (Map) o;
                role_id = Integer.parseInt(hmQueryResponse.get(MPSDefs.DB_ROLE_ID).toString());
            }
		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			logger.info("{}{}DBH_GRI.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getRoleId::" + e.getMessage());
		}
		return role_id;
	}

	/**
	 * This method retrieves the attribute ID for a given attribute name from the database.
	 * It prepares a SQL query to select the attribute ID from the attribute table where the attribute name matches the input.
	 * The method executes the query using JdbcTemplate and processes the query response.
	 * If the attribute name is found in the database, the corresponding attribute ID is returned.
	 * If the attribute name is not found, the method returns 0.
	 * In case of any exception during the process, it throws an MPSException with the error message.
	 *
	 * @param attribute_Name The name of the attribute for which the ID is to be retrieved.
	 * @return The ID of the attribute if found, 0 otherwise.
	 * @throws MPSException If there is an exception during the process.
	 */
	@Cacheable("getAttributeIdFromName")
	public int getAttributeIdFromName(String attribute_Name) throws MPSException {
		String sMethodName = ".getAttributeIdFromName.";
		String selectStatement = "SELECT attribute_id FROM attribute WHERE attribute_name = ?";
		int attribute_id = 0;
		List<Object> objectList = new ArrayList<Object>();

		try {
			objectList.add(attribute_Name);
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement),
					objectList.toArray(new Object[objectList.size()]));

			for (int j = 0; j < alQueryResponse.size(); j++) {
				Map hmQueryResponse = (Map) alQueryResponse.get(j);
				attribute_id = Integer.parseInt(hmQueryResponse.get("attribute_id").toString());
			}
		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			logger.info("{}{}DBH_GAIFN.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getAttributeIdFromName::" + e.getMessage());
		}
		return attribute_id;
	}
	
	// Added for April'10 release to get notification_id corresponding to input notification_name from NOTIFICATION table.
	/**
	 * @param stNotificationName
	 * @return
	 * @throws MPSException
	 */
	public int getNotificationId(String stNotificationName)throws MPSException
	{
		String stNotificationIdSelectSql = "SELECT notification_id FROM notification WHERE notification_name = ?";
		int iNotificationId = -1;
		List<Object> objectList = new ArrayList<Object>();

		try {
			objectList.add(stNotificationName);
			List alQueryResponse = jdbcTemplate.queryForList(new String(stNotificationIdSelectSql),
					objectList.toArray(new Object[objectList.size()]));

			for (int j = 0; j < alQueryResponse.size(); j++) {
				Map hmQueryResponse = (Map) alQueryResponse.get(j);
				iNotificationId = (int) (hmQueryResponse.get("notification_id"));
			}
			
		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			throw new MPSException("DBHelper::getNotificationId::" + e.getMessage());

		} finally {
			
		}
		return iNotificationId;
	}

}
