package com.att.idp.idgraphusermanagementms.resource.request;

import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.HashMap;
import java.util.Map;

@Data
@Schema(name = "DeleteUserRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
public class DeleteUserRequest {

	private String transactionName = ProfileOrchestrationConstants.DELETE_USER_TRANS_NAME;

	@Schema(name = "userId")
	@Size(min=1, max=127,message="userId length is invalid|DeleteUser")
	@JsonProperty("userId")
	private String handle;

	@Schema(name = "domain")
	@Size(min=1,max=30,message="domain length is invalid|DeleteUser")
    private String domain;

	@Schema(name = "guid")
	@Size(min = 1, max = 12, message =  "guid length is invalid|DeleteUser")
	@Pattern(regexp = "\\d+$", message="guid must be numeric|DeleteUser")
	private String guid;

	private String callingSystemId;

	@Schema(name = "idpTraceId")
	private String idpTraceId;

	@Schema(name = "isExternalCall")
	@Size(min = 1, max = 1, message =  "isExternalCall length is invalid|DeleteUser")
	private String isExternalCall;

	private String dbusTransactionId;


	/**
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
	 * @return Map<String,Object> The map of unknown attributes.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();

}