package com.att.idp.idgraphusermanagementms.helper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.StringTokenizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.mpsys.common.utils.PropertyManager;
import com.att.idp.idgraphusermanagementms.db.helper.CTNEligibilityDBHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * The CTNEligibilityHelper class is a helper class that provides methods to check and validate CTN (Customer Telephone Number) eligibility.
 * It includes methods to validate input, check CTN eligibility, and interact with the CTNEligibilityDBHelper class to perform database operations.
 * This class is annotated with @Component, meaning it is an autodetectable Spring Bean and can be automatically wired into other components using Spring's dependency injection facilities.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class CTNEligibilityHelper extends AbstractHelper {

	private static String sClassName = "CTNEligibilityHelper";
	public static final Logger logger = LoggerFactory.getLogger(CTNEligibilityHelper.class);

	@Autowired
	private CTNEligibilityDBHelper oCTNEligibility;
	
	@Value("${OPR_CTN_TIME_PERIOD}")
	private String OPR_CTN_TIME_PERIOD;
	
	@Value("${IDP_CTN_TIME_PERIOD}")
	private String IDP_CTN_TIME_PERIOD;
	
	@Value("${DATAMGT_CTN_TIME_PERIOD}")
	private String DATAMGT_CTN_TIME_PERIOD;
	
	@Value("${OPR_CTN_MAX_TRANSACTIONS}")
	private String OPR_CTN_MAX_TRANSACTIONS;
	
	@Value("${IDP_CTN_MAX_TRANSACTIONS}")
	private String IDP_CTN_MAX_TRANSACTIONS;
	
	@Value("${DATAMGT_CTN_MAX_TRANSACTIONS}")
	private String DATAMGT_CTN_MAX_TRANSACTIONS;

	
	/**
	 * This method checks the eligibility of a Customer Telephone Number (CTN) based on the input parameters.
	 * It validates the input, checks the CTN eligibility, and interacts with the CTNEligibilityDBHelper class to perform database operations.
	 * It also handles exceptions and logs the necessary information for debugging purposes.
	 *
	 * @param hmInput A HashMap containing the necessary information about the CTN to be checked. This includes details like CTN, increment counter, calling system ID, etc.
	 * @return A HashMap containing the result of the operation. This includes status codes and messages indicating the success or failure of the operation.
	 */
	public HashMap checkCTNEligibility(HashMap hmInput) {
		String sMethodName = ".checkCTNEligibility.";
		logger.info("{}{}HLP000 : Input Hash : {}", sClassName, sMethodName,
				HtmlUtils.htmlEscape(String.valueOf(hmInput)));

		HashMap hmResult = null;
		String stAppInfo = null;
		String stAppStatusCode = null;
		boolean isTransactionRollback = false;
		HashMap hmDBInput = null;

		hmResult = validateMapInput(hmInput, CErrorDefs.ERR_INVALID_DATA_NUM, "Input Hash is NULL");
		if (hmResult != null) return hmResult;

		try {

			logger.info("{}{}CTNE_02 :Calling  validateInput methode with input: {} ", sClassName, sMethodName,
					hmInput);

			hmResult = validateInput(hmInput);

			if (hasFailed(hmResult)) {
				return hmResult;
			}

			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sIncrementCounter = (String) hmInput.get(CommonDefs.INCREMENT_COUNTER);

			String stTimePeriod = sCallingSystemId.equals("IDP") ? IDP_CTN_TIME_PERIOD
					: sCallingSystemId.equals("OPR") ? OPR_CTN_TIME_PERIOD : DATAMGT_CTN_TIME_PERIOD;
			logger.info("{}{}CTNE_03.1: stTimePeriod {}", sClassName, sMethodName, stTimePeriod);

			String stMaxTransactions = sCallingSystemId.equals("IDP") ? IDP_CTN_MAX_TRANSACTIONS
					: sCallingSystemId.equals("OPR") ? OPR_CTN_MAX_TRANSACTIONS : DATAMGT_CTN_MAX_TRANSACTIONS;
			logger.info("{}{}CTNE_03.2: stMaxTransactions {}", sClassName, sMethodName, stMaxTransactions);

			hmResult = validateValue(stTimePeriod, CErrorDefs.ERR_CONFIG_NUM,
					sCallingSystemId + "_CTN_TIME_PERIOD property value is null or empty");
			if (hmResult != null) return hmResult;

			hmResult = validateValue(stMaxTransactions, CErrorDefs.ERR_CONFIG_NUM,
					sCallingSystemId + "_CTN_MAX_TRANSACTIONS property value is null or empty");
			if (hmResult != null) return hmResult;

			int iMaxTransactions = Integer.parseInt(stMaxTransactions);

			long timePeriodInMSec = getTimePeriodInMSec(stTimePeriod);

			logger.info("{}{}CTNE_05.2: timePeriodInMSec {}", sClassName, sMethodName, timePeriodInMSec);

			hmDBInput = new HashMap();

			hmDBInput.put(CommonDefs.CTN, hmInput.get(CommonDefs.CTN));
			hmDBInput.put(CommonDefs.LAST_MODIFIED_BY, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));

			hmResult = oCTNEligibility.getCTNEligibility(hmDBInput);

			logger.debug("{}{}CTNE_06 :Response from getCTNEligibility with  : {}", sClassName, sMethodName, hmResult);

			stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				if (stAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND)) {
					if (sIncrementCounter.equals(CommonDefs.IND_Y)) {

						logger.info("{}{}CTNE_07 :Calling to oCTNEligibility.addCTNEligibility with input : {}",
								sClassName, sMethodName, hmDBInput);

						hmResult = oCTNEligibility.addCTNEligibility(hmDBInput);

						logger.info("{}{}CTNE_08 :Response from oCTNEligibility.addCTNEligibility with input : {}",
								sClassName, sMethodName, hmResult);

						if (hasFailed(hmResult)) {
							return hmResult;
						} else {
							isTransactionRollback = true;
						}
					} else {
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
								CErrorDefs.COMMON_SUCCESS_MSG);
					}
					return hmResult;
				}

			} else {
				HashMap hmDBCTNInfo = new HashMap();
				hmDBCTNInfo = (HashMap) hmResult.get(CommonDefs.CTN_ELIGIBILITY);
				String sDBCTNInitDate = (String) hmDBCTNInfo.get(CommonDefs.CTN_INIT_DATE);
				String sDBTxnCount = (String) hmDBCTNInfo.get(CommonDefs.TXN_COUNT);
				String sDBSysdate = (String) hmDBCTNInfo.get(CommonDefs.DB_SYSDATE);
				String sCTNUsageFilter = (String) hmDBCTNInfo.get(CommonDefs.CTN_USAGE_FILTER);

				if (sCTNUsageFilter != null && sCTNUsageFilter.equalsIgnoreCase("W")) {
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS);
					return hmResult;

				} else if (sCTNUsageFilter != null && sCTNUsageFilter.equalsIgnoreCase("B")) {
					stAppInfo = "Input CTN is blacklisted";
					logger.info("{}{}CTNE_09.1 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CTN_INELIGIBLE_NUM, stAppInfo);
					return hmResult;
				}

				int iDBTxnCnt = Integer.parseInt(sDBTxnCount);
				DateFormat df = new SimpleDateFormat("MMddyyyy HH:mm:ss");
				Date ctnInitDate = df.parse(sDBCTNInitDate);
				long tCTNInitTime = ctnInitDate.getTime();
				Date dDBSysdate = df.parse(sDBSysdate);
				long currentTime = dDBSysdate.getTime();
				long lTimeDiff = currentTime - timePeriodInMSec;
				logger.info("{}{}CTNE_09.2: TimeDifference lTimeDiff:{} tCTNInitTime:{} ", sClassName, sMethodName, lTimeDiff, tCTNInitTime);

				if (lTimeDiff < tCTNInitTime) {
					if (iDBTxnCnt < iMaxTransactions) {
						if (sIncrementCounter != null && sIncrementCounter.equals(CommonDefs.IND_Y)) {
							iDBTxnCnt = iDBTxnCnt + 1;
							String sTxCount = Integer.toString(iDBTxnCnt);
							hmDBInput.put(CommonDefs.TXN_COUNT, sTxCount);
							logger.info("{}{}CTNE_10 :Calling to oCTNEligibility.updateCTNEligibility with input : {}",
									sClassName, sMethodName, hmDBInput);

							hmResult = oCTNEligibility.updateCTNEligibility(hmDBInput);

							logger.info(
									"{}{}CTNE_11 :Response from oCTNEligibility.updateCTNEligibility with input : {}",
									sClassName, sMethodName, hmResult);

							if (hasFailed(hmResult)) {
								return hmResult;
							} else {
								isTransactionRollback = true;
							}
						} else {
							hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
									CErrorDefs.COMMON_SUCCESS_MSG);
						}

					} else {
						stAppInfo = "CTN txn exceeds its maximum count";
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CTN_INELIGIBLE_NUM, stAppInfo);
					}
					return hmResult;
				}

				if (lTimeDiff >= tCTNInitTime) {
					if (sIncrementCounter != null && sIncrementCounter.equals(CommonDefs.IND_Y)) {
						iDBTxnCnt = 1;
						String sTxCount = Integer.toString(iDBTxnCnt);
						hmDBInput.put(CommonDefs.TXN_COUNT, sTxCount);
						hmDBInput.put(CommonDefs.CTN_LAST_USED_DATE_FLAG, CommonDefs.IND_Y);
						logger.info("{}{}CTNE_14 :Calling to oCTNEligibility.updateCTNEligibility with input : {}",
								sClassName, sMethodName, hmDBInput);

						hmResult = oCTNEligibility.updateCTNEligibility(hmDBInput);

						logger.info("{}{}CTNE_15 :Response from oCTNEligibility.updateCTNEligibility with input : {}",
								sClassName, sMethodName, hmResult);

						if (hasFailed(hmResult)) {
							return hmResult;
						} else {
							isTransactionRollback = true;
						}
					} else {
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
								CErrorDefs.COMMON_SUCCESS_MSG);
					}
					return hmResult;
				}
			}

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown checkCTNEligibility method : " + hmResult;
			logger.error("{}{}CTNE_17 : {}", sClassName, sMethodName, stAppInfo);
		} finally {
			logger.info("{}{}HLP999 :: {}", sClassName, sMethodName, hmResult);
			String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);

			if (isTransactionRollback && sAppCategoryCode != null
					&& !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
				hmResult.put("isTransactionRollback", "Y");
			}

		}

		return hmResult;
	}

	private HashMap validateInput(HashMap hmInput) {
		String sMethodName = ".validateInput.";
		HashMap hmResult = null;
		String sAppInfo = null;

		try {

			String sIncrementCounter = (String) hmInput.get(CommonDefs.INCREMENT_COUNTER);
			String sCTN = (String) hmInput.get(CommonDefs.CTN);

			hmResult = validateValue(sCTN, CErrorDefs.ERR_INVALID_DATA_NUM,
					"CTN is null or empty ");
			if (hmResult != null) return hmResult;

			hmResult = validateValue(sIncrementCounter, CErrorDefs.ERR_INVALID_DATA_NUM,
					"sIncrementCounter is null or empty ");
			if (hmResult != null) return hmResult;

			hmResult = validateYNValue(sIncrementCounter, CErrorDefs.ERR_INVALID_DATA_NUM,
					"IncrementCounter should be Y or N");
			if (hmResult != null) return hmResult;

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG);

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			sAppInfo = "Exception thrown from validateInput method : " + hmResult;
			logger.error("{}{}CTNE_23: {}", sClassName, sMethodName, sAppInfo);
			return hmResult;
		}
		return hmResult;
	}

}
