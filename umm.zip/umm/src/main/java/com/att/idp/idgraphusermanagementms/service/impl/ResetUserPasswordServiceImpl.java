package com.att.idp.idgraphusermanagementms.service.impl;

import java.util.HashMap;
import java.util.Map;

import jakarta.ws.rs.core.MultivaluedMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.resetuserpassword.ResetUserPasswordHelper;
import com.att.idp.idgraphusermanagementms.resource.request.ResetUserPasswordRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ResetUserPasswordResponse;
import com.att.idp.idgraphusermanagementms.service.ResetUserPasswordService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class ResetUserPasswordServiceImpl implements ResetUserPasswordService {
	public static final Logger logger = LoggerFactory.getLogger(ResetUserPasswordServiceImpl.class);

	private static String sClassName = "ResetUserPasswordServiceImpl";

	@Autowired
	private ResetUserPasswordHelper resetUserPasswordHelper;

	/**
	 * This method is part of the ResetUserPasswordService interface in the
	 * com.att.idp.idgraphusermanagementms.service package.
	 *
	 * The resetUserPassword method is used to perform the operation of resetting a
	 * user's password. It takes a ResetUserPasswordRequest object and a
	 * MultivaluedMap of String to String as input. The ResetUserPasswordRequest
	 * object represents the request body, containing the details required for
	 * resetting a user's password. The MultivaluedMap represents the request
	 * headers.
	 *
	 * The method returns a ResetUserPasswordResponse object, which represents the
	 * response from the operation of resetting a user's password.
	 */
	@Override
	public ResetUserPasswordResponse resetUserPassword(ResetUserPasswordRequest resetUserPasswordRequest,
			MultivaluedMap<String, String> requestHeader) {

		Map<String, Object> hmResponse = null;
		String sMethodName = ".resetUserPassword.";

		Map<String, Object> hmInput = CommonUtilHelper.objectToMap(resetUserPasswordRequest);

		// Updating delivery method hashMap
		HashMap hmDeliveryMethod = (HashMap) hmInput.get(CommonDefs.DELIVERY_METHODS);
		HashMap hmUpdatedDeliveryMethod = new HashMap<>();
		if (hmDeliveryMethod != null) {
			prepareDeliveryMethodHash(hmDeliveryMethod, hmUpdatedDeliveryMethod);
			hmInput.put(CommonDefs.DELIVERY_METHOD, hmUpdatedDeliveryMethod);
			hmInput.remove(CommonDefs.DELIVERY_METHODS);

		}

		String idpTraceid = (String) hmInput.get("idpTraceId");
		hmInput.put("dbusTransactionId", idpTraceid.split(":")[0]);
		hmInput.put("handle", hmInput.remove("userId"));
		hmInput.put(CommonDefs.ORIG_TRANSACTION_NAME, "ResetUserPassword");

		logger.info(SpiMarker.getInstance(),
				"ResetUserPasswordServiceImpl.resetUserPassword.UPS_01 : Calling resetUserPasswordHelper with Input : {}",
				StructuredArguments.entries(hmInput));

		hmResponse = resetUserPasswordHelper.resetUserPassword((HashMap) hmInput);

		logger.info(SpiMarker.getInstance(), "{}{}UPS_02 : Response from ResetUserPassword Helper : {}", sClassName,
				sMethodName, hmResponse);

		if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
			hmResponse = CommonUtilHelper
					.sysErrorHashMap("Null response from resetUserPasswordHelper.resetUserPassword");
			logger.info("{}{}UPS_03 : Null response from resetUserPasswordHelper.resetUserPassword", sClassName,
					sMethodName);
		} else {
			String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (stAppStatusCode == null) {
				hmResponse = CommonUtilHelper
						.sysErrorHashMap("Null response from resetUserPasswordHelper.resetUserPassword");
				logger.info("{}{}UPS_04 : Null response from resetUserPasswordHelper.resetUserPassword", sClassName,
						sMethodName);
			}
		}

		hmResponse.put(CommonDefs.TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
		hmResponse.put("idp-trace-id", resetUserPasswordRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME, "ResetUserPassword");
		ResetUserPasswordResponse resetUserPasswordResponse = CommonUtilHelper
				.generateResetUserPasswordResponse(hmResponse);

		String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

		if (sTxnRollBack != null) {
			throw new InvalidInputDataException(hmResponse);
		}
		logger.info(SpiMarker.getInstance(),
				"{}{}UPS_05 : Response from ResetUserPasswordServiceImpl.resetUserPassword : {}", sClassName,
				sMethodName, resetUserPasswordResponse);
		return resetUserPasswordResponse;

	}

	/**
	 * @param hmDeliveryMethod
	 * @param hmUpdatedDeliveryMethod
	 */
	private void prepareDeliveryMethodHash(HashMap hmDeliveryMethod, HashMap hmUpdatedDeliveryMethod) {
		String deliveryMethodType = (String) hmDeliveryMethod.get("deliveryMethodType");
		hmUpdatedDeliveryMethod.put("deliveryMethodType", deliveryMethodType);
		HashMap email = (HashMap) hmDeliveryMethod.get("email");

		if (email != null) {
			String emailAddress = (String) email.get("emailAddress");
			if (emailAddress != null) {
				hmUpdatedDeliveryMethod.put(CommonDefs.VALUE_EMAIL, emailAddress);
			}
		}

		HashMap sms = (HashMap) hmDeliveryMethod.get("sms");
		if (sms != null) {
			String smsPhoneNumber = (String) sms.get("smsPhoneNumber");
			if (smsPhoneNumber != null) {
				hmUpdatedDeliveryMethod.put(CommonDefs.VALUE_SMS, smsPhoneNumber);
			}

		}

		HashMap letter = (HashMap) hmDeliveryMethod.get("letter");
		if (letter != null) {
			HashMap hmPostal = new HashMap();

			if (letter.get("firstName") != null)
				hmPostal.put(CommonDefs.FIRST_NAME, letter.get("firstName"));
			if (letter.get("lastName") != null)
				hmPostal.put(CommonDefs.LAST_NAME, letter.get("lastName"));
			if (letter.get("street1") != null)
				hmPostal.put(CommonDefs.ADDRESS1, letter.get("street1"));
			if (letter.get("street2") != null)
				hmPostal.put(CommonDefs.ADDRESS2, letter.get("street2"));
			if (letter.get("city") != null)
				hmPostal.put(CommonDefs.CITY, letter.get("city"));
			if (letter.get("state") != null)
				hmPostal.put(CommonDefs.STATE, letter.get("state"));
			if (letter.get("zipCode") != null)
				hmPostal.put(CommonDefs.ZIPCODE, letter.get("zipCode"));
			if (letter.get("zipPlusFour") != null)
				hmPostal.put(CommonDefs.ZIPCODE4, letter.get("zipPlusFour"));
			if (letter.get("country") != null)
				hmPostal.put(CommonDefs.COUNTRY, letter.get("country"));

			hmUpdatedDeliveryMethod.put(CommonDefs.VALUE_POSTAL, hmPostal);

		}

		HashMap ao = (HashMap) hmDeliveryMethod.get("ao");
		if (ao != null) {
			String phoneNumber = (String) ao.get("phoneNumber");
			if (phoneNumber != null) {
				hmUpdatedDeliveryMethod.put(CommonDefs.VALUE_AO, phoneNumber);
			}

		}
	}
}
