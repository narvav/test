package com.att.idp.idgraphusermanagementms.db.helper;

import com.att.idp.idgraphusermanagementms.helper.voltage.ProcessVoltageHelper;
import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.mpsys.common.utils.*;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * This class is responsible for adding members to the database.
 * It uses Spring's JdbcTemplate for database operations and has methods for adding members to different tables.
 * It also uses other helper classes like DBHelper and ProcessVoltageHelper.
 * 
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like JdbcTemplate, DBHelper, and ProcessVoltageHelper.
 * 
 * The class contains SQL queries as string constants for adding members to different tables.
 * These queries are used in the corresponding methods for adding members.
 * 
 * The class also contains a logger for logging information and errors.
 * 
 * The main methods in this class are:
 * - addMemberGroup: This method adds a member group to the database.
 * - addMember: This method adds a member to the database.
 * - addMemberAux: This method adds auxiliary information for a member to the database.
 * - addPortalUser: This method adds a portal user to the database.
 */
@Component
public class AddMemberDBHelper {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private DBHelper dbHelper;

    @Autowired
    private ProcessVoltageHelper processVoltageHelper;

    @Autowired
    private ErrorMetricHandler errorMetricHandler;

    public static final Logger logger = LoggerFactory.getLogger(AddMemberDBHelper.class);
    private String sClassName = "AddMemberDBHelper";

    private static String APP_INFO_JDBC_TEMPLATE_NULL="jdbcTemplate is null.";
    private static final String ADD_MEMEBR_GROUP_SQL = "INSERT INTO membergroup("+
            "GROUP_NUM, PARENT_NAME,"+
            "DOMAIN_ID,"+
            "LAST_MODIFIED_BY," +
            "PREMIUM_800_IND, " +
            "BULK_BILLING_IND, " +
            "ACCESS_CODE " +
            ") VALUES("+
            "?, ?, ?, ?, ?, ?, ?)";
    private static final String ADD_MEMEBR_SQL=   "INSERT INTO member("+
            "MEMBER_NUM,"+
            "MEMBER_NAME,"+
            "DOMAIN_ID,"+
            "GROUP_NUM,"+
            "PARENT_CHILD_IND,"+
            "ACCESS_ID,"+
            "FULLNAME,"+
            "LAST_MODIFIED_BY,"+
            "SOR_ID,"+
            "ACCOUNT_TYPE,"+
            "CONTACT_EMAIL,"+
            "CONTACT_EMAIL_STATUS,"+
            "PASSWORD_DIRTY,"+
            "FIRSTNAME,"+
            "LASTNAME,"+
            "SLID_MEMBER_NUM,"+
            "FN_LINKED_USERID," +
            "FN_LINKED_STATUS" +
            ") VALUES("+
            "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String ADD_MEMBER_AUX_SQL = "INSERT INTO memberaux("+
            "MEMBER_NUM, "+
            "ENC_PASSWORD_VENC, "+
            "MD5_PASSWORD_VENC, " +
            "SHA1_PASSWORD_VENC, " +
            "DES3_PASSWORD_VENC, " +
            "SSHA_PASSWORD_VENC, " +
            "SECURITY_ANSWER_1_VENC, " +
            "SECURITY_ANSWER_2_VENC, " +
            "PASSWORD_VENC, " + // SSHA-256
            "PASSWORD_TYPE, " +  // SSHA-256
            "LAST_MODIFIED_BY" +") VALUES("+
            "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    private static final String ADD_PORTAL_USER_SQL = "INSERT INTO portaluser(" + "MEMBER_NUM," + "SERVICE_ID,"
			+ "PORTAL_PROVIDER," + "LAST_MODIFIED_BY," + "PLITE_IND )" + " VALUES(" + "?," + "?," + "?," + "?," + "?)";


    private static final String ADD_DSL_USER_SQL = "INSERT INTO DSLUSER ("+
            "MEMBER_NUM,"+
            "SERVICE_ID,"+
            "CIRCUIT_ID,"+
            "VIRTUAL_PATH,"+
            "VIRTUAL_CIRCUIT,"+
            "INCOMING_BURST,"+
            "INCOMING_LIMIT,"+
            "OUTGOING_BURST,"+
            "OUTGOING_LIMIT,"+
            "PROTOCOL_TYPE,"+
            "IP_ADDRESS,"+
            "IP_NETBLOCK,"+
            "IP_SUBNET,"+
            "WTN,"+
            "LAST_MODIFIED_BY,"+
            "NETWORK_PROFILE_ID,"+
            "DSLAM_TYPE,"+
            "TDSL_IND, IPV6RD_ENABLED, IPV6RD_MANUALLY_DISABLED, DNS_ERR_OPTOUT_IND) VALUES("+ //Added as per NAPII & R6
            "?,?,?,?,?,?,?,?,?,?,?,?,?,?,"+
            "?,?,?,?,?,?,?)";

    /**
     * This method is responsible for adding a member group to the database.
     * It takes a HashMap as an argument which contains the details of the member group to be added.
     * The HashMap should contain the following keys:
     * - DB_DOMAIN_NAME: The domain name of the member group.
     * - DB_PARENT_NAME: The parent name of the member group.
     * - DB_LAST_MODIFIED_BY: The identifier of the user who last modified the member group.
     * - DB_BULK_BILLING_IND: The bulk billing indicator of the member group.
     * - DB_PREMIUM_800_IND: The premium 800 indicator of the member group.
     * - DB_ACCESS_CODE: The access code of the member group.
     *
     * The method first logs the start of the operation and the input parameters.
     * It then retrieves the necessary information from the input HashMap and prepares the SQL query for insertion.
     * The method then executes the SQL query using the jdbcTemplate object.
     * If the operation is successful, the method returns a HashMap containing the status of the operation and the generated group number and domain id.
     * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
     *
     * @param hmAddMemberGroup A HashMap containing the details of the member group to be added.
     * @return A HashMap containing the status of the operation and the generated group number and domain id.
     */
    public HashMap<String, Object> addMemberGroup(HashMap<String, Object> hmAddMemberGroup) {

        String sMethodName = ".addMemberGroup.";
        HashMap resultHash =null;
        logger.info(sClassName + sMethodName +"DBTOOLS000 : "+" addMemberGroup method ");
        logger.info(sClassName + sMethodName +"AMDBH_AMG_01 : "+" addMemberGroup input Hash is ::"+ HtmlUtils.htmlEscape(String.valueOf(hmAddMemberGroup)));



        List<Object> objectList = new ArrayList<Object>();
        String domain_name 			= (String)hmAddMemberGroup.get(MPSDefs.DB_DOMAIN_NAME);
        String parent_name			= (String)hmAddMemberGroup.get(MPSDefs.DB_PARENT_NAME);
        String last_modified_by 	= (String)hmAddMemberGroup.get(MPSDefs.DB_LAST_MODIFIED_BY);

        String bulk_billing_ind		= (String)hmAddMemberGroup.get(MPSDefs.DB_BULK_BILLING_IND);
        String premium_800_ind	= (String)hmAddMemberGroup.get(MPSDefs.DB_PREMIUM_800_IND);
        String access_code 	= (String)hmAddMemberGroup.get(MPSDefs.DB_ACCESS_CODE);

        // for the case where new user is the same as parent, ie. not using existing parent.
        if (premium_800_ind == null || premium_800_ind.length() == 0 )
        {
            premium_800_ind = MPSDefs.PREMIUM_800_IND_NO;
        }

        long group_num = 0;
        int domain_id = 0;

        if (jdbcTemplate == null) {
            resultHash = CommonErrorMap.makeCategoryMap(
                    CErrorDefs.ERR_SYS_APPL_NUM, APP_INFO_JDBC_TEMPLATE_NULL);
            logger.error(sClassName + sMethodName +"AMDBH_AMG_02 : response : " + resultHash);
            return resultHash;
        }else{

            try{
                //get additional fields
                group_num 	= dbHelper.getNextMemberGroupId();
                domain_id 	= dbHelper.getDomainId(domain_name.toLowerCase());

                logger.debug(sClassName + sMethodName +"AMDBH_AMG_03 : "+"ADD_MEMEBR_GROUP_SQL: "+ADD_MEMEBR_GROUP_SQL);

                objectList.add(group_num);
                logger.info(sClassName + sMethodName +"AMDBH_AMG_04 : "+"group_num::PARAM 1 = "+group_num);

                objectList.add(parent_name.toLowerCase());
                logger.info(sClassName + sMethodName +"AMDBH_AMG_05 : "+" parent_name::PARAM 2 = "+ HtmlUtils.htmlEscape(String.valueOf(parent_name)));

                objectList.add(domain_id);
                logger.info(sClassName + sMethodName +"AMDBH_AMG_06 : "+" domain_id::PARAM 3 = "+domain_id);

                objectList.add(last_modified_by);
                logger.info(sClassName + sMethodName +"AMDBH_AMG_07 : "+" last_modified_by::PARAM 4 = "+ HtmlUtils.htmlEscape(String.valueOf(last_modified_by)));

                objectList.add(premium_800_ind);
                logger.info(sClassName + sMethodName +"AMDBH_AMG_08 : "+" premium_800_ind::PARAM 5 = "+ HtmlUtils.htmlEscape(String.valueOf(premium_800_ind)));

                objectList.add(bulk_billing_ind);
                logger.info(sClassName + sMethodName +"AMDBH_AMG_09 : "+" bulk_billing_ind::PARAM 6 = "+ HtmlUtils.htmlEscape(String.valueOf(bulk_billing_ind)));

                objectList.add(access_code);
                logger.info(sClassName + sMethodName +"AMDBH_AMG_10 : "+" access_code::PARAM 7 = "+ HtmlUtils.htmlEscape(String.valueOf(access_code)));
                logger.debug(sClassName + sMethodName +"AMDBH_AM_10.1 objectList for AddMemberGroup SQL : "+objectList);
                int rowCount = jdbcTemplate.update(new String(ADD_MEMEBR_GROUP_SQL), objectList.toArray(new Object[objectList.size()]));

                logger.info(sClassName + sMethodName +"AMDBH_AMG_11 : "+" rowCount = "+rowCount);

                //DB process succesfull
                resultHash= StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS,MPSDefs.MPS_ALL_OK,MPSDefs.SQL_SUCCESS,MPSDefs.SQL_SUCCESS_MSG,Integer.toString(rowCount));
                resultHash.put(MPSDefs.DB_GROUP_NUM,Long.toString(group_num));
                resultHash.put(MPSDefs.DB_DOMAIN_ID,Integer.toString(domain_id));

            }
            catch(Exception e){
                errorMetricHandler.recordDbErrorMetric();
                if(e.getMessage().contains("ORA-00001: unique constraint")){
                    resultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USERNAME_EXISTS_NUM, MPSDefs.ERR_USERNAME_EXISTS_MSG);
                    logger.info(sClassName + sMethodName +"AMDBH_AMG_12 : "+" resultHash ::"+resultHash);
                }else{
                    resultHash = StatusMsg.makeExceptionSQLStatus(e);
                    String errorCode = (String) resultHash.get(MPSDefs.APP_STATUS_CODE);
                    logger.error(sClassName + sMethodName +"AMDBH_AMG_13 : "+" Error::"+e.getMessage());
                    logger.error(sClassName + sMethodName +"AMDBH_AMG_14 : "+ "Exception = {}" ,e);
                }
            }finally{
                logger.info(sClassName + sMethodName +"DBTOOLS999 : resultHash : " + resultHash);
            }
        }
        return resultHash;
    }

    /** AddMember db helper.
     * @param hmAddMember inputHash
     * @return status hashmap
     */
    public HashMap<String, Object> addMember(HashMap<String, Object> hmAddMember) {
        String sMethodName = ".addMember.";
        String stAppInfo = null;
        String appStatusCode = null;

        logger.info(sClassName + sMethodName + "DBTOOLS000 : " + "CVS KEYWORDS: ");
        logger.info("AMDBH_AM_01 : "+ "InpParam = "+ HtmlUtils.htmlEscape(String.valueOf(hmAddMember)));

        HashMap status = null;
        List<Object> objectList = new ArrayList<Object>();

        //1612 Updated for voltage encryption of SPI fields in MEMBERAUX table
        status = processVoltageHelper.voltageEncryptSPIFields(hmAddMember);

        if (status == null || status.isEmpty()) {
            stAppInfo = "status HashMap from ProcessVoltageHelper is null";
            status =CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM,stAppInfo);
            logger.error(sClassName + sMethodName +"AMDBH_AM_02 : "+stAppInfo);
        }

        appStatusCode = (String) status.get(CommonDefs.COMMON_APP_STATUS_CODE);

        if (appStatusCode != null && !appStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
            stAppInfo = (String)status.get(CommonDefs.COMMON_APP_INFO);
            status = CommonErrorMap.makeCategoryMap(Integer.parseInt(appStatusCode) , stAppInfo);
            logger.info(sClassName + sMethodName +"AMDBH_AM_03 : "+ HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
            return status;
        }		//1612 End

        //get info from  InpParam HashMap
        String member_name 			= (String)hmAddMember.get(MPSDefs.DB_MEMBER_NAME);
        String domain_id_str 		= (String)hmAddMember.get(MPSDefs.DB_DOMAIN_ID);
        String group_num_str		= (String)hmAddMember.get(MPSDefs.DB_GROUP_NUM);
        String parent_child_ind		= (String)hmAddMember.get(MPSDefs.DB_PARENT_CHILD_IND);
        String access_id_str 		= (String)hmAddMember.get(MPSDefs.DB_ACCESS_ID);
        String access_name		 	= (String)hmAddMember.get(MPSDefs.DB_ACCESS_NAME);
        String sor_name				= (String)hmAddMember.get(MPSDefs.DB_SOR_NAME);
        String fullname 			= (String)hmAddMember.get(MPSDefs.DB_FULLNAME);
        String migration_ind		= (String)hmAddMember.get(MPSDefs.DB_MIGRATION_IND);
        String migration_date		= (String)hmAddMember.get(MPSDefs.DB_MIGRATION_DATE);
        String account_type 		= (String)hmAddMember.get(MPSDefs.DB_ACCOUNT_TYPE);
        String sor_id_str 			= (String)hmAddMember.get(MPSDefs.DB_SOR_ID);
        String last_modified_by 	= (String)hmAddMember.get(MPSDefs.DB_LAST_MODIFIED_BY);
        String contact_email		= (String)hmAddMember.get(MPSDefs.DB_CONTACT_EMAIL);
        String contact_email_valid	= (String)hmAddMember.get(MPSDefs.DB_CONTACT_EMAIL_VALID);
        String password_dirty		= (String)hmAddMember.get(MPSDefs.DB_PASSWORD_DIRTY);
        String slid_member_num_str 	= (String)hmAddMember.get(MPSDefs.DB_SLID_MEMBER_NUM);
        SimpleDateFormat dtFormat = new SimpleDateFormat("MMddyyyy HH:mm:ss");
        String sysDate = dtFormat.format(new Date());

        int domain_id 				= -1;
        long group_num				= -1;
        long slid_member_num		= -1;
        int sor_id 					= -1;
        int access_id				= -1;

        String firstname			= (String)hmAddMember.get(MPSDefs.DB_LC_FIRSTNAME);
        String lastname				= (String)hmAddMember.get(MPSDefs.DB_LC_LASTNAME);
        String security_question	= (String)hmAddMember.get(MPSDefs.DB_SECURITY_QUESTION);
        String security_question_1  = (String)hmAddMember.get(MPSDefs.DB_SECURITY_QUESTION_1);
        String security_question_2  = (String)hmAddMember.get(MPSDefs.DB_SECURITY_QUESTION_2);
        String security_question_id_1_str  = (String)hmAddMember.get(MPSDefs.DB_SECURITY_QUESTION_ID_1);
        String security_question_id_2_str  = (String)hmAddMember.get(MPSDefs.DB_SECURITY_QUESTION_ID_2);
        String security_question_id_str  = (String)hmAddMember.get(MPSDefs.DB_SECURITY_QUESTION_ID);
        String sExternalGuid = (String) hmAddMember.get(CommonDefs.EXT_GUID);

        long lExternalGuid = 0;
        if(sExternalGuid !=null && !sExternalGuid.trim().isEmpty()) {
            lExternalGuid = Long.parseLong(sExternalGuid);
        }
        String fn_linked_userId = (String) hmAddMember.get(CommonDefs.DB_FN_LINKED_USERID);
        String fn_linked_status = (String) hmAddMember.get(CommonDefs.DB_FN_LINKED_STATUS);
        //END
        int security_question_id 	= -1;
        int security_question_id_1 = -1;
        int security_question_id_2 = -1;

        try{
            if(migration_ind == null || migration_ind.isEmpty()){
                if(last_modified_by.equals(CommonDefs.DATAMGT)){
                    if(hmAddMember.get(MPSDefs.DB_DOMAIN_NAME).equals(CommonDefs.SLID_DUM)){
                        if (  member_name != null && member_name.indexOf( "@") > 0 ){
                            String sSlidDomain = member_name.substring(member_name.indexOf("@") + 1,member_name.length());
                            int iDomainId = 0;
                            SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
                            if ( sSlidDomain != null)
                            {
                                iDomainId = dbHelper.getDomainId(sSlidDomain);
                                if ( (iDomainId  > 0 ))
                                {
                                    migration_ind = MPSDefs.YES;
                                    migration_date = sdf.format(new Date());
                                }
                            }
                        }
                    }
                }
            }
            // [END]

            int temp_sor_id = dbHelper.getSorId(sor_name);
            sor_id_str = String.valueOf(temp_sor_id);
            logger.info(sClassName + sMethodName +"AMDBH_AM_04 : "+ "Got sor_id from DBHelper= "+ sor_id_str);

            if(access_id_str == null){
                int temp_access_id = dbHelper.getAccessId(access_name);
                access_id_str = String.valueOf(temp_access_id);
                logger.info(sClassName + sMethodName +"AMDBH_AM_05 : "+ "Got access_id from DBHelper = "+ access_id_str);
            }

            if(domain_id_str != null){
                domain_id 			= Integer.parseInt(domain_id_str);
            }
            else	{
                String domain_name 	= (String)hmAddMember.get(MPSDefs.DB_DOMAIN_NAME);
                domain_id 	= dbHelper.getDomainId(domain_name.toLowerCase());
            }

            if(group_num_str != null){
                group_num = Long.parseLong(group_num_str);
            }
            if(slid_member_num_str != null){
                slid_member_num	= Long.parseLong(slid_member_num_str);
            }

            if(sor_id_str != null){
                sor_id 				= Integer.parseInt(sor_id_str);
            }
            if(access_id_str != null){
                access_id 			= Integer.parseInt(access_id_str);
            }

            if(security_question_id_1_str != null){
                security_question_id_1 				= Integer.parseInt(security_question_id_1_str);
            }
            if(security_question_id_2_str != null){
                security_question_id_2 				= Integer.parseInt(security_question_id_2_str);
            }
            if(security_question_id_str != null){
                security_question_id 				= Integer.parseInt(security_question_id_str);
            }

            if (security_question_id < 0) {
                if(security_question != null){
                    security_question_id = dbHelper.getSecurityQuestionId(security_question);

                    logger.info(sClassName + sMethodName +"AMDBH_AM_05 : "+ "Got security_question_id from DBHelper = "+ security_question_id);

                    if(security_question_id < 0 ){
                        String sAppInfo = "Cannot find security_question_id for the given security_question="+ security_question;
                        status = StatusMsg.makeSQLStatus(MPSDefs.ERR_INVALID_DATA,MPSDefs.ERR_INVALID_DATA_MSG,
                                MPSDefs.ERR_INVALID_DATA,sAppInfo,MPSDefs.NO_ROW_UPDATED);
                        logger.info(sClassName + sMethodName +"AMDBH_AM_06 : "+ HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
                        return status;
                    }
                }
            }

            if (security_question_id_1 < 0) {
                if(security_question_1 != null){
                    security_question_id_1 = dbHelper.getSecurityQuestionId(security_question_1);

                    logger.info(sClassName + sMethodName +"AMDBH_AM_07 : "+ "Got security_question_id_1 from DBHelper = "+ security_question_id_1);

                    if(security_question_id_1 < 0 ){
                        String sAppInfo = "Cannot find security_question_id for the given security_question="+ security_question_1;
                        status = StatusMsg.makeSQLStatus(MPSDefs.ERR_INVALID_DATA,MPSDefs.ERR_INVALID_DATA_MSG,
                                MPSDefs.ERR_INVALID_DATA,sAppInfo,MPSDefs.NO_ROW_UPDATED);
                        logger.info(sClassName + sMethodName +"AMDBH_AM_08 : "+ HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
                        return status;
                    }
                }
            }
            if (security_question_id_2 < 0) {
                if(security_question_2 != null){
                    security_question_id_2 = dbHelper.getSecurityQuestionId(security_question_2);

                    logger.info(sClassName + sMethodName +"AMDBH_AM_09 : "+ "Got security_question_id_2 from DBHelper = "+ security_question_id_2);

                    if(security_question_id_2 < 0 ){
                        String sAppInfo = "Cannot find security_question_id for the given security_question="+ security_question_2;
                        status = StatusMsg.makeSQLStatus(MPSDefs.ERR_INVALID_DATA,MPSDefs.ERR_INVALID_DATA_MSG,
                                MPSDefs.ERR_INVALID_DATA,sAppInfo,MPSDefs.NO_ROW_UPDATED);
                        logger.info(sClassName + sMethodName +"AMDBH_AM_10 : "+ HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
                        return status;
                    }
                }
            }

        }catch(NumberFormatException e){
            status = StatusMsg.makeSQLStatus(MPSDefs.ERR_OUT_OF_RANGE,MPSDefs.ERR_OUT_OF_RANGE_MSG,MPSDefs.SQL_ERR,MPSDefs.SQL_ERR_MSG,MPSDefs.NO_ROW_UPDATED);
            logger.error(sClassName + sMethodName +"AMDBH_AM_11 : "+"Error: "+e.getMessage());
            return status;
        }catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            status = StatusMsg.makeExceptionSQLStatus(e);
            String errorCode = (String) status.get(MPSDefs.APP_STATUS_CODE);
            logger.error(sClassName + sMethodName +"AMDBH_AM_12 : "+ "Error: "+e.getMessage());
            return status;
        }

        long member_num = 0;

        if (jdbcTemplate == null) {
            status = CommonErrorMap.makeCategoryMap(
                    CErrorDefs.ERR_SYS_APPL_NUM, APP_INFO_JDBC_TEMPLATE_NULL);
            logger.error(sClassName + sMethodName +"AMDBH_AM_13 : response : " + status);
            return status;
        }else{

            try{

                //[R2110]changes by pm675e :PID#400970c
                if(lExternalGuid == 0) {
                    member_num 	= dbHelper.getNextMemberId();
                }else {
                    member_num =lExternalGuid;
                }
                //END
                logger.debug(sClassName + sMethodName +"AMDBH_AM_14 : "+ "ADD_MEMEBR_SQL= "+ADD_MEMEBR_SQL);

                objectList.add(member_num);
                logger.debug(sClassName + sMethodName +"AMDBH_AM_15 : "+ "member_num::PARAM 1 = "+member_num);

                objectList.add(member_name.toLowerCase());
                logger.debug(sClassName + sMethodName +"AMDBH_AM_16 : "+  "member_name::PARAM 2 = "+ HtmlUtils.htmlEscape(String.valueOf(member_name)));

                objectList.add(domain_id);
                logger.debug(sClassName + sMethodName +"AMDBH_AM_17 : " + "domain_id::PARAM 3 = "+domain_id);

                objectList.add(group_num);
                logger.debug(sClassName + sMethodName +"AMDBH_AM_18 : " + "group_num::PARAM 4 = "+group_num);

                objectList.add(parent_child_ind);
                logger.debug(sClassName + sMethodName +"AMDBH_AM_21 : " + "parent_child_ind::PARAM 7 = "+ HtmlUtils.htmlEscape(String.valueOf(parent_child_ind)));

                if(access_id_str != null){
                    objectList.add(access_id);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_22 : " + "access_id::PARAM 8 = "+access_id);
                }else{
                    objectList.add(access_id);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_23 : " + "access_id::PARAM 8 = null");
                }

                if(fullname != null){
                    objectList.add(fullname);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_26 : " + "fullname::PARAM 10 = "+ HtmlUtils.htmlEscape(String.valueOf(fullname)));
                }else{
                    objectList.add(fullname);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_27 : " + "fullname::PARAM 10 = null");
                }

                objectList.add(last_modified_by);
                logger.debug(sClassName + sMethodName +"AMDBH_AM_32 : " + "last_modified_by::PARAM 13 = "+ HtmlUtils.htmlEscape(String.valueOf(last_modified_by)));

                objectList.add(sor_id);
                logger.debug(sClassName + sMethodName +"AMDBH_AM_33 : " + "sor_id::PARAM 14 = "+sor_id);

                if(account_type != null){
                    objectList.add(account_type);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_34 : " + "account_type::PARAM 15 = "+ HtmlUtils.htmlEscape(String.valueOf(account_type)));
                }else{
                    objectList.add(account_type);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_35 : " + "account_type::PARAM 15 = null");
                }

                if(contact_email != null){
                    //1602 - Updated for SID42938 - to lower case contact_email when inserting/updating in MPS DB
                    contact_email = contact_email.toLowerCase();
                    objectList.add(contact_email);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_44 : " + "contact_email::PARAM 20 = "+ HtmlUtils.htmlEscape(String.valueOf(contact_email)));
                }else{
                    objectList.add(contact_email);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_45 : " + "contact_email::PARAM 20 = null");
                }

                if(contact_email != null && contact_email_valid != null) {
                    if (contact_email_valid.equals(MPSDefs.YES)){
                        objectList.add(MPSDefs.DB_CONTACT_STATUS_VALID);
                        logger.debug(sClassName + sMethodName + "AMDBH_AM_46 : " + "contact_email_status::PARAM 21 = " + HtmlUtils.htmlEscape(String.valueOf(MPSDefs.DB_CONTACT_STATUS_VALID)));
                    } else if (contact_email_valid.equals(MPSDefs.NO)) {
                        objectList.add(MPSDefs.DB_CONTACT_STATUS_HARD);
                        logger.debug(sClassName + sMethodName +"AMDBH_AM_47 : " + "contact_email_status::PARAM 21 = "+HtmlUtils.htmlEscape(String.valueOf(MPSDefs.DB_CONTACT_STATUS_HARD)));
                    }
                   }else {
                    objectList.add(null);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_48 : " + "contact_email_status::PARAM 21 = null");
                }

                if(password_dirty != null){
                    objectList.add(password_dirty);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_49 : " + "password_dirty::PARAM 22 = "+ HtmlUtils.htmlEscape(String.valueOf(password_dirty)));
                }else{
                    objectList.add(password_dirty);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_50 : " + "password_dirty::PARAM 22 = null");
                }

                if(firstname != null){
                    objectList.add(firstname);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_57 : " + "firstname::PARAM 26 = "+ HtmlUtils.htmlEscape(String.valueOf(firstname)));
                }else{
                    objectList.add(firstname);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_58 : " + "firstname::PARAM 26 = null");
                }

                if(lastname != null){
                    objectList.add(lastname);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_59 : " + "lastname::PARAM 27 = "+ HtmlUtils.htmlEscape(String.valueOf(lastname)));
                }else{
                    objectList.add(lastname);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_60 : " + "lastname::PARAM 27 = null");
                }

                if(parent_child_ind != null && parent_child_ind.equals("S")){
                    objectList.add(member_num);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_91 : " + "slid_member_num::PARAM 43 = "+member_num);
                } else if (parent_child_ind != null && slid_member_num_str != null) {
                    objectList.add(slid_member_num);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_92 : " + "slid_member_num::PARAM 43 = "+slid_member_num);
                } else{
                    objectList.add(null);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_93 : " + "slid_member_num::PARAM 43 = null");
                }

                //[R2110]changes by pm675e :PID#400970c
                if(fn_linked_userId != null){
                    objectList.add(fn_linked_userId);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_111 : " + "fn_linked_userId::PARAM 52 = "+ HtmlUtils.htmlEscape(String.valueOf(fn_linked_userId)));
                }else{
                    objectList.add(fn_linked_userId);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_112 : " + "fn_linked_userId::PARAM 52 = null");
                }
                if(fn_linked_status != null){
                    objectList.add(fn_linked_status);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_113 : " + "fn_linked_status::PARAM 53 = "+ HtmlUtils.htmlEscape(String.valueOf(fn_linked_status)));
                }else{
                    objectList.add(fn_linked_status);
                    logger.debug(sClassName + sMethodName +"AMDBH_AM_114 : " + "fn_linked_status::PARAM 53 = null");
                }
                //END

                //int rowCount = prepStmt.executeUpdate();
                logger.debug(sClassName + sMethodName +"AMDBH_AM_114.1 objectList for AddMember SQL : "+objectList);
                int rowCount = jdbcTemplate.update(new String(ADD_MEMEBR_SQL), objectList.toArray(new Object[objectList.size()]));
                logger.debug(sClassName + sMethodName +"AMDBH_AM_115 : member table row inserted = " + rowCount);

                //1612 Updated for voltage encryption of SPI fields in MEMBERAUX table
                //[R2110]changes by pm675e :PID#400970c for MOUP.AddExtUser(password is optional filed in AddExtUser)
                String md5_password_venc = (String) hmAddMember.get("md5_password_venc");
                if(md5_password_venc!=null && !md5_password_venc.trim().isEmpty()) {
                    hmAddMember.put(MPSDefs.DB_MEMBER_NUM, Long.toString(member_num));
                    status = addMemberAux(hmAddMember);

                    if (status == null || status.isEmpty()) {
                        stAppInfo = "status HashMap from addMemberAux() is null";
                        status =CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM,stAppInfo);
                        logger.error(sClassName + sMethodName +"AMDBH_AM_116 : "+stAppInfo);
                    }

                    appStatusCode = (String) status.get(CommonDefs.COMMON_APP_STATUS_CODE);

                    if (appStatusCode != null && !appStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
                        stAppInfo = (String) status.get(CommonDefs.COMMON_APP_INFO);
                        status = CommonErrorMap.makeCategoryMap(Integer.parseInt(appStatusCode), stAppInfo);
                        logger.info(sClassName + sMethodName +"AMDBH_AM_117 : "+ stAppInfo);
                        return status;
                    }
                }//R2110 END
                //1612 END

                //DB process succesfully
                status = StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS,MPSDefs.MPS_ALL_OK,MPSDefs.SQL_SUCCESS,MPSDefs.SQL_SUCCESS_MSG,Integer.toString(rowCount));
                status.put(MPSDefs.DB_MEMBER_NUM, Long.toString(member_num));
                status.put(MPSDefs.DB_DOMAIN_ID, Integer.toString(domain_id));

            }catch(Exception e){
                errorMetricHandler.recordDbErrorMetric();
                if(e.getMessage().contains("ORA-00001: unique constraint")){
                    status = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USERNAME_EXISTS_NUM, MPSDefs.ERR_USERNAME_EXISTS_MSG);
                    logger.info(sClassName + sMethodName +"AMDBH_AM_118 : "+" resultHash ::"+status);
                }else{
                    status = StatusMsg.makeExceptionSQLStatus(e);
                    String errorCode = (String) status.get(MPSDefs.APP_STATUS_CODE);
                    logger.error(sClassName + sMethodName +"AMDBH_AM_119 : "+" Error::"+e.getMessage());
                    logger.error(sClassName + sMethodName +"AMDBH_AM_120 : "+ "Exception = {}" ,e);
                }
            }finally{
                logger.info(sClassName + sMethodName +"DBTOOLS999 : status : " + status);
            }
        }
        return status;
    }

    /**
     * This method is responsible for adding auxiliary information for a member to the database.
     * It takes a HashMap as an argument which contains the details of the member to be added.
     * The HashMap should contain the following keys:
     * - DB_MEMBER_NUM: The member number.
     * - enc_password_venc: The encrypted password.
     * - sha1_password_venc: The SHA1 encrypted password.
     * - gen_password_venc: The generic encrypted password.
     * - gen_password_type: The type of the generic encrypted password.
     * - md5_password_venc: The MD5 encrypted password.
     * - des3_password_venc: The DES3 encrypted password.
     * - ssha_password_venc: The SSHA encrypted password.
     * - security_answer_1_venc: The first security answer.
     * - security_answer_2_venc: The second security answer.
     * - DB_LAST_MODIFIED_BY: The identifier of the user who last modified the member.
     *
     * The method first logs the start of the operation and the input parameters.
     * It then retrieves the necessary information from the input HashMap and prepares the SQL query for insertion.
     * The method then executes the SQL query using the jdbcTemplate object.
     * If the operation is successful, the method returns a HashMap containing the status of the operation.
     * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
     *
     * @param hmInput A HashMap containing the details of the member to be added.
     * @return A HashMap containing the status of the operation.
     */
    public HashMap<String,Object> addMemberAux(HashMap<String,Object> hmInput){
        String sMethodName = ".addMemberAux.";
        String sAppInfo = null;
        long member_num = 0;
        String errorCode = null;
        logger.info(sClassName + sMethodName +"DBTOOLS000 :: start. InputParams = " + HtmlUtils.htmlEscape(String.valueOf(hmInput)));
        HashMap status = null;
        List<Object> objectList = new ArrayList<Object>();

        if (hmInput == null || hmInput.isEmpty()) {
            sAppInfo = "hmInput is null or empty";
            logger.error(sClassName + sMethodName +"AMDBH_AMAux_01 : "+ sAppInfo);
            status = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
            return status;
        }

        String member_num_str = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
        String enc_password_venc = (String) hmInput.get("enc_password_venc");
        String sha1_password_venc = (String) hmInput.get("sha1_password_venc");
//		 2103 - SSHA-256 encryption changes
        String generic_password_venc = (String) hmInput.get("gen_password_venc");
        String generic_password_type = (String) hmInput.get("gen_password_type");
        String md5_password_venc = (String) hmInput.get("md5_password_venc");
        String des3_password_venc = (String) hmInput.get("des3_password_venc");
        String ssha_password_venc = (String) hmInput.get("ssha_password_venc");
        String security_answer_1_venc = (String) hmInput.get("security_answer_1_venc");
        String security_answer_2_venc = (String) hmInput.get("security_answer_2_venc");
        String last_modified_by = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);

        try {

            logger.debug(sClassName + sMethodName +"AMDBH_AMAux_02 : "+ "ADD_MEMBER_AUX_SQL= "+ADD_MEMBER_AUX_SQL);
            if(member_num_str != null){
                member_num = Long.parseLong(member_num_str);
                objectList.add(member_num);
            }

            objectList.add(enc_password_venc);
            objectList.add(md5_password_venc);
            objectList.add(sha1_password_venc);
            objectList.add(des3_password_venc);
            objectList.add(ssha_password_venc);
            objectList.add(security_answer_1_venc);
            objectList.add(security_answer_2_venc);
//		 2103 - SSHA-256 encryption changes
            objectList.add(generic_password_venc);
            objectList.add(generic_password_type);
            objectList.add(last_modified_by);
            logger.debug(sClassName + sMethodName +"AMDBH_AMAux_03 objectList for AddMemberAUX SQL : "+objectList);
            int rowCount = jdbcTemplate.update(new String(ADD_MEMBER_AUX_SQL), objectList.toArray(new Object[objectList.size()]));
            //DB process successfully
            status = StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS, MPSDefs.MPS_ALL_OK, MPSDefs.SQL_SUCCESS, MPSDefs.SQL_SUCCESS_MSG, Integer.toString(rowCount));

        }catch(Exception e){
            errorMetricHandler.recordDbErrorMetric();
            status = CommonErrorMap.makeExceptionMap(e, logger);
        }finally{
            logger.info(sClassName + sMethodName +"DBTOOLS999 : status : " + status);
        }
        return status;
    }
    
    /**
     * This method is responsible for adding a portal user to the database.
     * It takes a HashMap as an argument which contains the details of the portal user to be added.
     * The HashMap should contain the following keys:
     * - DB_MEMBER_NUM: The member number.
     * - DB_SERVICE_ID: The service ID.
     * - DB_PORTAL_PROVIDER: The portal provider.
     * - DB_LAST_MODIFIED_BY: The identifier of the user who last modified the portal user.
     * - DB_PLITE_IND: The PLITE indicator.
     *
     * The method first checks if the input HashMap is null or empty. If it is, it logs an error and returns an error status.
     * It then retrieves the necessary information from the input HashMap.
     * If the jdbcTemplate object is null, the method logs an error and returns an error status.
     * Otherwise, it prepares the SQL query for insertion and executes it using the jdbcTemplate object.
     * If the operation is successful, the method returns a HashMap containing the status of the operation.
     * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
     *
     * @param hmInput A HashMap containing the details of the portal user to be added.
     * @return A HashMap containing the status of the operation.
     */
	public HashMap<String, Object> addPortalUser(HashMap<String, Object> hmInput) {
		String sMethodName = ".addPortalUser.";

		HashMap resultHash = null;
		String sAppInfo = null;
		logger.debug(sClassName + sMethodName + "DBTOOLS000 :: start. InputParams = "
				+ HtmlUtils.htmlEscape(String.valueOf(hmInput)));

		if (hmInput == null || hmInput.isEmpty()) {
			sAppInfo = "hmInput is null or empty";
			logger.error(sClassName + sMethodName + "AMDBH_AMAux_01 : " + sAppInfo);
			resultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
			return resultHash;
		}

		HashMap hmResult = null;
		List<Object> objectList = new ArrayList<Object>();
		int service_id = 0;
		long member_num = -1;

		// get info from input HashMap
		String member_num_str = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
		String service_id_str = (String) hmInput.get(MPSDefs.DB_SERVICE_ID);
		String portal_provider = (String) hmInput.get(MPSDefs.DB_PORTAL_PROVIDER);
		String last_modified_by = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);
		String plite_ind = (String) hmInput.get(MPSDefs.DB_PLITE_IND);
		try {

			if (member_num_str != null) {
				member_num = Long.parseLong(member_num_str);

			}
			if (service_id_str != null) {
				service_id = Integer.parseInt(service_id_str);
			}

			if (jdbcTemplate == null) {
				resultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, APP_INFO_JDBC_TEMPLATE_NULL);
				logger.error(sClassName + sMethodName + "DBTOOLS_03a : response : " + resultHash);
				return resultHash;
			} else {
				objectList.add(member_num);
				objectList.add(service_id);
				objectList.add(portal_provider);
				objectList.add(last_modified_by);
				if (plite_ind != null) {
					objectList.add(plite_ind);
				} else {
					objectList.add(null);
				}
                logger.debug(sClassName + sMethodName +"DBHLP126.5 objectList for AddPortalUser SQL : "+objectList);
				int rowCount = jdbcTemplate.update(new String(ADD_PORTAL_USER_SQL),
						objectList.toArray(new Object[objectList.size()]));
				hmResult = StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS, MPSDefs.MPS_ALL_OK, MPSDefs.SQL_SUCCESS,
						MPSDefs.SQL_SUCCESS_MSG, Integer.toString(rowCount));
				return hmResult;
			}
		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			logger.error("{}{}DBHLPE01 : Error:: {}", sClassName, sMethodName, e.getMessage());

		} finally {
			logger.info("{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);
		}

		return hmResult;
	}

    /**
     * Adds a DSL user to the database.
     * <p>
     * This method inserts a DSL user record into the database using the provided input map.
     * It performs null and empty checks on the input, logs all relevant information using ESAPI encoding
     * to prevent log injection, and handles errors gracefully. The method builds a parameter list for the
     * SQL statement from the input map, executes the insert, and returns a status map indicating success or failure.
     * </p>
     *
     * @param hmInput HashMap containing DSL user details. Expected keys:
     *                <ul>
     *                  <li>MPSDefs.DB_MEMBER_NUM</li>
     *                  <li>MPSDefs.DB_SERVICE_ID</li>
     *                  <li>MPSDefs.DB_NETWORK_PROFILE_ID</li>
     *                  <li>MPSDefs.DB_CIRCUIT_ID</li>
     *                  <li>MPSDefs.DB_VIRTUAL_PATH</li>
     *                  <li>MPSDefs.DB_VIRTUAL_CIRCUIT</li>
     *                  <li>MPSDefs.DB_INCOMING_BURST</li>
     *                  <li>MPSDefs.DB_INCOMING_LIMIT</li>
     *                  <li>MPSDefs.DB_OUTGOING_BURST</li>
     *                  <li>MPSDefs.DB_OUTGOING_LIMIT</li>
     *                  <li>MPSDefs.DB_PROTOCOL_TYPE</li>
     *                  <li>MPSDefs.DB_IP_ADDRESS</li>
     *                  <li>MPSDefs.DB_IP_NETBLOCK</li>
     *                  <li>MPSDefs.DB_IP_SUBNET</li>
     *                  <li>MPSDefs.DB_WTN</li>
     *                  <li>MPSDefs.DB_LAST_MODIFIED_BY</li>
     *                  <li>MPSDefs.DB_DSLAM_TYPE</li>
     *                  <li>MPSDefs.DB_TDSL_IND</li>
     *                  <li>MPSDefs.DB_IPV6RD_ENABLED</li>
     *                  <li>MPSDefs.DB_IPV6RD_MANUALLY_DISABLED</li>
     *                  <li>MPSDefs.DB_DNS_ERR_OPTOUT_IND</li>
     *                </ul>
     * @return HashMap with operation status. On success, contains SQL status and affected row count.
     *         On failure, contains error details.
     */
    public HashMap<String, Object> addDslUser(HashMap<String, Object> hmInput) {
        final String sMethodName = ".addDslUser.";

        logger.debug("{}{}DBTOOLS000 :: start. InputParams = {}",
                "AddMemberDBHelper", sMethodName, ESAPI.encoder().encodeForHTML(String.valueOf(hmInput)));

        if (hmInput == null || hmInput.isEmpty()) {
            String sAppInfo = "hmInput is null or empty";
            logger.error("{}{}AMDBH_ADU_01 : {}", "AddMemberDBHelper", sMethodName, ESAPI.encoder().encodeForHTML(sAppInfo));
            return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
        }

        // get info from input HashMap
        String member_num_str		= (String)hmInput.get(MPSDefs.DB_MEMBER_NUM);
        String service_id_str		= (String)hmInput.get(MPSDefs.DB_SERVICE_ID);
        String circuit_id			= (String)hmInput.get(MPSDefs.DB_CIRCUIT_ID);
        String virtual_path			= (String)hmInput.get(MPSDefs.DB_VIRTUAL_PATH);
        String virtual_circuit		= (String)hmInput.get(MPSDefs.DB_VIRTUAL_CIRCUIT);
        String incoming_burst		= (String)hmInput.get(MPSDefs.DB_INCOMING_BURST);
        String incoming_limit		= (String)hmInput.get(MPSDefs.DB_INCOMING_LIMIT);
        String outgoing_burst		= (String)hmInput.get(MPSDefs.DB_OUTGOING_BURST);
        String outgoing_limit		= (String)hmInput.get(MPSDefs.DB_OUTGOING_LIMIT);
        String protocol_type		= (String)hmInput.get(MPSDefs.DB_PROTOCOL_TYPE);
        String ip_address			= (String)hmInput.get(MPSDefs.DB_IP_ADDRESS);
        String ip_netblock			= (String)hmInput.get(MPSDefs.DB_IP_NETBLOCK);
        String ip_subnet			= (String)hmInput.get(MPSDefs.DB_IP_SUBNET);
        String wtn					= (String)hmInput.get(MPSDefs.DB_WTN);
        String last_modified_by 	= (String)hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);
        String network_profile_id_str = (String) hmInput.get(MPSDefs.DB_NETWORK_PROFILE_ID);
        String dslam_type			= (String)hmInput.get(MPSDefs.DB_DSLAM_TYPE);
        String tdsl_ind				= (String)hmInput.get(MPSDefs.DB_TDSL_IND);
        String ipv6rd_enabled       = (String)hmInput.get(MPSDefs.DB_IPV6RD_ENABLED);
        String ipv6rd_manually_disabled = (String)hmInput.get(MPSDefs.DB_IPV6RD_MANUALLY_DISABLED);
        String dns_err_optout_ind = (String)hmInput.get(MPSDefs.DB_DNS_ERR_OPTOUT_IND);

        long memberNum = parseLongOrDefault(member_num_str, -1L);
        int serviceId = parseIntOrDefault(service_id_str, -1);

        List<Object> objectList = new ArrayList<>();
        objectList.add(memberNum);
        objectList.add(serviceId);

        objectList.add( circuit_id != null  ? circuit_id : null);
        objectList.add(virtual_path != null ? virtual_path : null);
        objectList.add(virtual_circuit != null ? virtual_circuit : null);
        objectList.add(incoming_burst != null ? incoming_burst : null);
        objectList.add(incoming_limit != null ? incoming_limit : null);
        objectList.add(outgoing_burst != null ? outgoing_burst : null);
        objectList.add(outgoing_limit != null ? outgoing_limit : null);
        objectList.add(protocol_type != null ? protocol_type : null);
        objectList.add(ip_address != null ? ip_address : null);
        objectList.add(ip_netblock != null ? ip_netblock : null);
        objectList.add(ip_subnet != null ? ip_subnet : null);
        objectList.add(wtn != null ? wtn : null);
        objectList.add(last_modified_by != null ? last_modified_by : null);
        objectList.add(network_profile_id_str != null ? Long.parseLong(network_profile_id_str) : null);
        objectList.add(dslam_type != null ? dslam_type : null);
        objectList.add(tdsl_ind != null ? tdsl_ind : null);
        objectList.add(ipv6rd_enabled != null ? ipv6rd_enabled : null);
        objectList.add(ipv6rd_manually_disabled != null ? ipv6rd_manually_disabled : null);
        objectList.add(dns_err_optout_ind != null ? dns_err_optout_ind : null);

        try {
            if (jdbcTemplate == null) {
                logger.error("{}{}DBTOOLS_03a : response : {}", "AddMemberDBHelper", sMethodName,
                        ESAPI.encoder().encodeForHTML(APP_INFO_JDBC_TEMPLATE_NULL));
                return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, APP_INFO_JDBC_TEMPLATE_NULL);
            }

            logger.info("{}{}DBHLP122 : ADD_DSL_USER_SQL: {}", "AddMemberDBHelper", sMethodName,
                    ESAPI.encoder().encodeForHTML(ADD_DSL_USER_SQL));
            logger.debug("{}{}DBHLP126.5 objectList for AddDslUser SQL : {}", "AddMemberDBHelper", sMethodName,
                    ESAPI.encoder().encodeForHTML(objectList.toString()));

            int rowCount = jdbcTemplate.update(ADD_DSL_USER_SQL, objectList.toArray());
            HashMap<String, Object> hmResult = StatusMsg.makeSQLStatus(
                    MPSDefs.MPS_SUCCESS, MPSDefs.MPS_ALL_OK, MPSDefs.SQL_SUCCESS,
                    MPSDefs.SQL_SUCCESS_MSG, Integer.toString(rowCount));
            logger.info("{}{}DBTOOLS999 : response : {}", "AddMemberDBHelper", sMethodName,
                    ESAPI.encoder().encodeForHTML(hmResult.toString()));
            return hmResult;
        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            logger.error("{}{}DBHLPE01 : Error:: {}", "AddMemberDBHelper", sMethodName,
                    ESAPI.encoder().encodeForHTML(e.getMessage()), e);
            HashMap<String, Object> hmResult = CommonErrorMap.makeExceptionMap(e);
            logger.info("{}{}DBTOOLS999 : response : {}", "AddMemberDBHelper", sMethodName,
                    ESAPI.encoder().encodeForHTML(hmResult.toString()));
            return hmResult;
        }
    }

    /**
     * Parses a String to a long value, returning a default if parsing fails.
     *
     * @param value        the String to parse
     * @param defaultValue the default value to return if parsing fails
     * @return the parsed long value, or defaultValue if value is null or not a valid long
     */
    private long parseLongOrDefault(String value, long defaultValue) {
        try {
            return value != null ? Long.parseLong(value) : defaultValue;
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /**
     * Parses a String to an int value, returning a default if parsing fails.
     *
     * @param value        the String to parse
     * @param defaultValue the default value to return if parsing fails
     * @return the parsed int value, or defaultValue if value is null or not a valid int
     */
    private int parseIntOrDefault(String value, int defaultValue) {
        try {
            return value != null ? Integer.parseInt(value) : defaultValue;
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }
}