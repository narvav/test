package com.att.idp.idgraphusermanagementms.service;

import jakarta.ws.rs.core.MultivaluedMap;

import com.att.idp.idgraphusermanagementms.resource.request.CheckUserIdAvailabilityRequest;
import com.att.idp.idgraphusermanagementms.resource.response.CheckUserIdAvailabilityResponse;

/**
 * This interface defines the contract for the CheckUserIdAvailabilityService in the system.
 * It contains a single method checkUserIdAvailability which takes a CheckUserIdAvailabilityRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return a CheckUserIdAvailabilityResponse object.
 *
 * The CheckUserIdAvailabilityRequest object encapsulates the details of the user ID availability check to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 * @author pb6583_ATT
 */
public interface CheckUserIdAvailabilityService {

	/**
	 * This method is part of the CheckUserIdAvailabilityService interface.
	 * It is responsible for checking the availability of a user ID in the system.
	 * The method takes a CheckUserIdAvailabilityRequest object as a parameter, which encapsulates the details of the user ID availability check to be performed.
	 * The method also takes a MultivaluedMap of request headers as a parameter, which may include additional information required for processing the request.
	 * The method returns a CheckUserIdAvailabilityResponse object representing the response from the system after checking the user ID availability.
	 *
	 * @param checkUserRequest An object encapsulating the details of the user ID availability check to be performed.
	 * @param requestHeader A MultivaluedMap containing the request headers which may include additional information required for processing the request.
	 * @return CheckUserIdAvailabilityResponse A object representing the response from the system after checking the user ID availability.
	 */
	CheckUserIdAvailabilityResponse checkUserIdAvailability(CheckUserIdAvailabilityRequest checkUserRequest,
			MultivaluedMap<String, String> requestHeader);

}
