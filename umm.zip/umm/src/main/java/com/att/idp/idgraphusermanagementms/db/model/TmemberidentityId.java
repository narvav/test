package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class TmemberidentityId implements Serializable {

	private static final long serialVersionUID = -8350478741624421939L;

	@Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)
	private Long memberNum;

	@Column(name = "IDENTITY", nullable = false)
	private String identity;

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TmemberidentityId))
			return false;
		TmemberidentityId castOther = (TmemberidentityId) other;

		return ((this.getMemberNum() == castOther.getMemberNum()) || (this.getMemberNum() != null
				&& castOther.getMemberNum() != null && this.getMemberNum().equals(castOther.getMemberNum())))
				&& ((this.getIdentity() == castOther.getIdentity()) || (this.getIdentity() != null
				&& castOther.getIdentity() != null && this.getIdentity().equals(castOther.getIdentity())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getMemberNum() == null ? 0 : this.getMemberNum().hashCode());
		result = 37 * result + (getIdentity() == null ? 0 : this.getIdentity().hashCode());
		return result;
	}
}