package com.att.idp.idgraphusermanagementms.helper;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * The TxnRateLimitStatusHelper class is a helper class that provides methods to manage transaction rate limit status.
 * It includes methods to validate input, interact with the IPTxnRateLimitHelper and CTNEligibilityHelper to verify client IP address and check CTN eligibility.
 * This class is annotated with @Component, meaning it is an autodetectable Spring Bean and can be automatically wired into other components using Spring's dependency injection facilities.
 */
@Component
public class TxnRateLimitStatusHelper {

	public static final Logger logger = LoggerFactory.getLogger(TxnRateLimitStatusHelper.class);
	private static String sClassName = "TxnRateLimitStatusHelper";

	@Autowired
	private IPTxnRateLimitHelper oIPTxnRateLimitHelper;

	@Autowired
	private CTNEligibilityHelper oCTNEligibilityHelper;

	/**
	 * This method manages the transaction rate limit status.
	 * It first validates the input and then performs a series of operations including IP transaction rate limit check and CTN eligibility check.
	 * If any of these operations fail, it returns the corresponding error.
	 * If all operations are successful, it returns a success message.
	 *
	 * @param hmInput A Map containing the input parameters for the method. It should include necessary information such as transaction ID, calling system ID, IP address, increment counter, and CTN.
	 * @return A Map containing the result of the method. It includes the application status code and other information.
	 */
	public Map<String, Object> txnRateLimitStatus(Map<String, Object> hmInput) {

		String sMethodName = ".txnRateLimitStatus.";
		logger.info("{}{}HLP000 : Input Hash : {}", sClassName, sMethodName,
				HtmlUtils.htmlEscape(String.valueOf(hmInput)));
		HashMap hmResult = null;
		HashMap hmIPTxnRateLimitHelper = new HashMap<>();
		String stAppInfo = null;
		String stAppStatusCode = null;

		if (hmInput == null || hmInput.isEmpty()) {
			stAppInfo = "Input Hash is NULL";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			logger.info("{}{}TRLSH_01 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}
		try {
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sTransactionId = (String) hmInput.get("idp-trace-id");
			String sIpAddress = (String) hmInput.get(CommonDefs.IP_ADDRESS);
			String sIncrementCounter = (String) hmInput.get(CommonDefs.INCREMENT_COUNTER);
			String sCtn = (String) hmInput.get(CommonDefs.CTN);

			hmIPTxnRateLimitHelper.put(CommonDefs.TRANSACTION_ID, sTransactionId);
			hmIPTxnRateLimitHelper.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);

			if (sIncrementCounter == null || sIncrementCounter.trim().isEmpty()) {
				hmIPTxnRateLimitHelper.put(CommonDefs.INCREMENT_COUNTER, CommonDefs.IND_N);
			} else {
				hmIPTxnRateLimitHelper.put(CommonDefs.INCREMENT_COUNTER, sIncrementCounter);
			}

			if (sIpAddress != null && !sIpAddress.trim().isEmpty()) {
				hmIPTxnRateLimitHelper.put(CommonDefs.IP_ADDRESS, sIpAddress);

				logger.info("{}{}TRLSH_02 :Calling to IPTxnRateLimitHelper.verifyRegClientIpAddress with input : {}",
						sClassName, sMethodName, hmIPTxnRateLimitHelper);

				hmResult = oIPTxnRateLimitHelper.verifyRegClientIpAddress(hmIPTxnRateLimitHelper);

				logger.info("{}{}TRLSH_03 :Response from IPTxnRateLimitHelper.verifyRegClientIpAddress : {}", sClassName,
						sMethodName, hmResult);

				stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

				if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					stAppInfo = (String) hmResult.get(MPSDefs.APP_INFO);
					logger.info("{}{}TRLSH_05 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
			}

			if (sCtn != null && !sCtn.trim().isEmpty()) {

				hmIPTxnRateLimitHelper.put(CommonDefs.CTN, sCtn);

				logger.info("{}{}TRLSH_06 :Calling to CTNEligiblityHelper.checkCTNEligibilitys with input : {}",
						sClassName, sMethodName, hmIPTxnRateLimitHelper);

				hmResult = oCTNEligibilityHelper.checkCTNEligibility(hmIPTxnRateLimitHelper);

				logger.info("{}{}TRLSH_07 :Response from CTNEligiblityHelper.checkCTNEligibilitys : {}", sClassName,
						sMethodName, hmResult);

				stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

				if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					stAppInfo = (String) hmResult.get(MPSDefs.APP_INFO);
					logger.info("{}{}TRLSY_08 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
			}

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);

		} finally {
			logger.info("{}{}HLP999 :: {}", sClassName, sMethodName, hmResult);

		}
		return hmResult;

	}
}
