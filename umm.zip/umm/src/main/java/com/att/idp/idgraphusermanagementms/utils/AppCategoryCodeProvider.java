package com.att.idp.idgraphusermanagementms.utils;

/**
 * This is the AppCategoryCodeProvider interface.
 * It is part of the com.att.idp.idgraphusermanagementms.utils package.
 * The interface defines a single method, getAppCategoryCode(), which is expected to return a String.
 * The purpose of this interface is to provide a contract for classes that need to provide an application category code.
 * Any class implementing this interface must provide an implementation for the getAppCategoryCode() method.
 */
public interface AppCategoryCodeProvider {
    String getAppCategoryCode();
}
