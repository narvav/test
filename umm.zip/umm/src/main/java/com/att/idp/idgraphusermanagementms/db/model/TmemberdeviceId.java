package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class TmemberdeviceId implements Serializable {

	private static final long serialVersionUID = 7978142864566017023L;

	@Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)
	private Long memberNum;

	@Column(name = "SOR_ID", nullable = false, precision = 22, scale = 0)
	private Long sorId;

	@Column(name = "DEVICE_ID", nullable = false)
	private String deviceId;

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TmemberdeviceId))
			return false;
		TmemberdeviceId castOther = (TmemberdeviceId) other;

		return ((this.getMemberNum() == castOther.getMemberNum()) || (this.getMemberNum() != null
				&& castOther.getMemberNum() != null && this.getMemberNum().equals(castOther.getMemberNum())))
				&& ((this.getSorId() == castOther.getSorId()) || (this.getSorId() != null
				&& castOther.getSorId() != null && this.getSorId().equals(castOther.getSorId())))
				&& ((this.getDeviceId() == castOther.getDeviceId()) || (this.getDeviceId() != null
				&& castOther.getDeviceId() != null && this.getDeviceId().equals(castOther.getDeviceId())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getMemberNum() == null ? 0 : this.getMemberNum().hashCode());
		result = 37 * result + (getSorId() == null ? 0 : this.getSorId().hashCode());
		result = 37 * result + (getDeviceId() == null ? 0 : this.getDeviceId().hashCode());
		return result;
	}
}