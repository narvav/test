package com.att.idp.idgraphusermanagementms.db.helper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.mpsys.common.utils.PropertyManager;
import com.att.idp.idgraphusermanagementms.db.model.Tmember;
import com.att.idp.idgraphusermanagementms.db.model.Tmemberfraudpassword;
import com.att.idp.idgraphusermanagementms.db.model.Tmemberlockout;
import com.att.idp.idgraphusermanagementms.db.model.Tmemberservice;
import com.att.idp.idgraphusermanagementms.db.model.Tmemberserviceattribute;
import com.att.idp.idgraphusermanagementms.db.repository.AttributeRepository;
import com.att.idp.idgraphusermanagementms.db.repository.LockoutRepository;
import com.att.idp.idgraphusermanagementms.db.repository.MemberRepository;
import com.att.idp.idgraphusermanagementms.helper.voltage.ProcessVoltageHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.StatusMsg;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This class is responsible for inquiring profile information from the database.
 * It uses Spring's JdbcTemplate for database operations.
 *
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like ProcessVoltageHelper, MemberRepository, AttributeRepository, and LockoutRepository.
 *
 * The class contains methods for inquiring profile information based on different levels passed in the input.
 *
 * The main method in this class is:
 * - inquireProfile: This method retrieves profile information from the database based on the level passed in the input. It takes a Map as input and returns a HashMap as output.
 *   The input Map contains key-value pairs for various profile attributes like calling system id, handle, domain, guid, return user fraud lock, return user security info, return user lockout, level, and is external call.
 *   The method first checks if the jdbcTemplate is null. If it is, it returns an error status.
 *   Then it retrieves the profile attributes from the input Map.
 *   If the profile attributes are not found, it returns an error status.
 *   Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
 *   Finally, it returns a status indicating whether the operation was successful or not.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class InquireProfileDBHelper {

	private static String sClassName = "InquireProfileDBHelper";

	public static final Logger logger = LoggerFactory.getLogger(InquireProfileDBHelper.class);

	@Autowired
	private ProcessVoltageHelper oProcessVoltageHelper;

	@Autowired
	private MemberRepository memberRepositoryObj;

	@Autowired
	private AttributeRepository attributeRepository;

	@Autowired
	private LockoutRepository lockoutRepository;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;
		
	@Value("${filterFieldsList}")
	private String propFilterFieldsList;

	@Value("${PROP_FIELDS_TO_TRANSLATE}")
	private String propFieldsToTranslate;
		
	@Value("${securityInfoFields}")
	private String propSecurityInfoFields;
	/**
	 * This method retrieves profile information from the database based on the level passed in the input.
	 * It takes a Map as input and returns a HashMap as output.
	 * The input Map contains key-value pairs for various profile attributes like calling system id, handle, domain, guid, return user fraud lock, return user security info, return user lockout, level, and is external call.
	 * The method first checks if the jdbcTemplate is null. If it is, it returns an error status.
	 * Then it retrieves the profile attributes from the input Map.
	 * If the profile attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param hmInput A Map containing the details of the profile's information to be retrieved.
	 * @return A HashMap containing the status of the operation and the retrieved profile's information.
	 */
	@SuppressWarnings("unchecked")
	public HashMap inquireProfile(Map<String, Object> hmInput) {
		String sMethodName = ".inquireProfile.";
		logger.info(ProfileOrchestrationConstants.LOG_DBTOOLS000, sClassName, sMethodName, hmInput);
		HashMap hmResult = CommonUtil.getHashMap();
		HashMap hmMember = CommonUtil.getHashMap();
		HashMap hmUserFraudLock = CommonUtil.getHashMap();
		HashMap hmUserSecurityInfo = CommonUtil.getHashMap();
		HashMap hmUserFraudPassword = CommonUtil.getHashMap();
		ArrayList alUserLockout = CommonUtil.getArrayList();
		ArrayList alMemberSvcRoles = CommonUtil.getArrayList();
		ArrayList alLinkedMembers = CommonUtil.getArrayList();
		ArrayList alMemberServiceAttributes = CommonUtil.getArrayList();
		String stAppStatusCode = null;
		String stAppInfo = null;
		CommonUtil.getArrayList();
		List<Tmember> alTmember = null;

		try {
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sInpHandle = (String) hmInput.get(CommonDefs.HANDLE);
			String sInpDomain = (String) hmInput.get(CommonDefs.DOMAIN);
			String sInpGuid = (String) hmInput.get(CommonDefs.GUID);
			String sReturnUserFraudLock = (String) hmInput.get("returnUserFraudLock");
			String sReturnUserSecurityInfo = (String) hmInput.get("returnUserSecurityInfo");
			String sReturnUserLockout = (String) hmInput.get("returnUserLockout");
			String sLevel = (String) hmInput.get("level");
			String sIsExternalCall = (String) hmInput.get("isExternalCall");

			ArrayList<String> alFilterFields = CommonUtil.parseToArray(propFilterFieldsList,
					CommonDefs.VALUE_SEPARATOR_CHAR);

			if ((sLevel.equals("M")) || (sLevel.equals("MSR")) || (sLevel.equals("LM"))) {

				String sGen_password_type = PropertyManager.getProperty(CommonDefs.MSConfig,
						"GENERIC_PASSWORD_ENCRYPTION_TYPE");

				if ((sInpGuid != null && !sInpGuid.isEmpty())) {
					alTmember = memberRepositoryObj.findByMemberNum(Long.valueOf(sInpGuid));
				} else {
					alTmember = memberRepositoryObj.findByMemberNameAndTdomainDomainName(sInpHandle, sInpDomain);
				}

				int numRowsFound = 0;
				if (alTmember != null && !alTmember.isEmpty()) {
					numRowsFound = inquireProfileMemberDetails(hmMember, alTmember, sGen_password_type, numRowsFound);
				}

				if (numRowsFound == 0) {
					stAppInfo = "Input guid or userId/domain not found";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
					logger.info("{}{}IPDBH002 error : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}

//				logger.debug("{}{}IPDBH003 : Result of member query: {}", sClassName, sMethodName, hmMember);

				logger.debug(SpiMarker.getInstance(), "{}{}IPDBH004 : Calling ProcessVoltageHelper.voltageDecryptSPIFields with input {}",
						sClassName, sMethodName, hmMember);
				hmResult = oProcessVoltageHelper.voltageDecryptSPIFields(hmMember);
		/*		logger.debug("{}{}IPDBH005 : Response from  ProcessVoltageHelper.voltageDecryptSPIFields {}",
						sClassName, sMethodName, hmResult); */

				stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

				if (stAppStatusCode != null && !stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
					stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
					hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
					logger.info("{}{}IPDBH006 : {}", sClassName, sMethodName,
							HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
					return hmResult;
				}

				HashMap hmFieldsToTranslate = CommonUtil.parseMultiDelimiterProperty(propFieldsToTranslate);
				logger.info("{}{}IPDBH007 : PROP_FIELDS_TO_TRANSLATE : {}", sClassName, sMethodName,
						hmFieldsToTranslate);

				if (hmFieldsToTranslate != null && !hmFieldsToTranslate.isEmpty()) {
					String sKey = null;
					String sValue = null;
					String sNewKey = null;

					Iterator itr = hmFieldsToTranslate.keySet().iterator();
					while (itr.hasNext()) {
						sKey = (String) itr.next();
						ArrayList alFieldValue = (ArrayList) hmFieldsToTranslate.get(sKey);

						for (int i = 0; i < alFieldValue.size(); i++) {
							sNewKey = (String) alFieldValue.get(i);
						}

						if (hmMember.containsKey(sKey)) {
							sValue = (String) hmMember.remove(sKey);
							hmMember.put(sNewKey, sValue);
						}
					}
				}

				logger.debug(SpiMarker.getInstance(),"InquireProfileDBHelper.inquireProfile.IPDBH008 : member hash after fields translation : {}",
						hmMember);

				logger.info("{}{}IPDBH009 : filterFieldsList : {}", sClassName, sMethodName, alFilterFields);

				if (sCallingSystemId != null && CommonDefs.CSI_ILM.equalsIgnoreCase(sCallingSystemId)
						&& sIsExternalCall.equalsIgnoreCase(CommonDefs.IND_Y)) {
					alFilterFields.remove(CommonDefs.SECURITYANSWER1);
					alFilterFields.remove(CommonDefs.SECURITYANSWER2);
				}
				for (int i = 0; i < alFilterFields.size(); i++) {
					String sKey = (String) alFilterFields.get(i);

					if (!"N".equals(sIsExternalCall)) {
						hmMember.remove(sKey);
					}
				}
				logger.debug(SpiMarker.getInstance(), "InquireProfileDBHelper.inquireProfile.IPDBH010 : Filtered member hash : {}", 
						hmMember);
				
				if ((sReturnUserSecurityInfo != null && !sReturnUserSecurityInfo.isEmpty())
						&& (sReturnUserSecurityInfo.equals("Y"))) {
					ArrayList<String> alSecurityInfoFields = CommonUtil.parseToArray(
							propSecurityInfoFields,
							CommonDefs.VALUE_SEPARATOR_CHAR);
					hmMember.forEach((k, v) -> {
						if (alSecurityInfoFields.contains(k)) {
							hmUserSecurityInfo.put(k, v);
						}
					});

					logger.debug(SpiMarker.getInstance(), "InquireProfileDBHelper.inquireProfile.IPDBH011 : hmUserSecurityInfo : {}", 
							hmUserSecurityInfo);
				}
			}

			if (sLevel.equals("MSR") || (sLevel.equals("LM"))) {

				if (alTmember != null && !alTmember.isEmpty()) {

					inquireProfileMemberServiceRole(alMemberSvcRoles, alTmember);
				}

				logger.debug("{}{}IPDBH012 : Result of member service query: {}", sClassName, sMethodName,
						alMemberSvcRoles);

				// To return MEMBERSERVICEATTRIBUTES as dynamic name/value pairs.
				inquireProfileMemberServiceAttributesDetails(alMemberSvcRoles, alMemberServiceAttributes, alTmember);
			}

			// linked member query for sLevel = LM
			inquireProfileLinkedMemberDetails(alLinkedMembers, alTmember, sLevel);

			if ((sReturnUserFraudLock != null && !sReturnUserFraudLock.isEmpty())
					&& (sReturnUserFraudLock.equals("Y"))) {

				if (alTmember != null && !alTmember.isEmpty()) {
					for (Tmember tmember : alTmember) {
						if (tmember.getTuserfraudlock() != null) {
							hmUserFraudLock.put(CommonDefs.MEMBER_NUM, tmember.getTuserfraudlock().getMemberNum());
							hmUserFraudLock.put(CommonDefs.USER_LOCK_LEVEL,
									tmember.getTuserfraudlock().getUserLockLevel());
							hmUserFraudLock.put("userLockReason", tmember.getTuserfraudlock().getUserLockReason());
						}
					}
				}

				logger.debug("{}{}IPDBH014 : Result of User fraud lock query: {} ", sClassName, sMethodName,
						hmUserFraudLock);
			}

			// Result of User lockout query
			inquireProfileUserLockOutDetails(alUserLockout, alTmember, sReturnUserLockout);

			hmResult.put(MPSDefs.APP_STATUS_CODE, MPSDefs.MPS_SUCCESS);
			hmResult.put(MPSDefs.APP_STATUS_MSG, MPSDefs.MPS_SUCCESS_MSG);
			hmResult.put(MPSDefs.APP_CATEGORY_CODE, MPSDefs.CATEGORY_CODE_SUCCESS);

			hmResult.put("member", hmMember);

			if (alMemberSvcRoles != null && !alMemberSvcRoles.isEmpty()) {
				hmResult.put("memberservicerole", alMemberSvcRoles);
			}

			if (alLinkedMembers != null && !alLinkedMembers.isEmpty()) {
				hmResult.put("linkedmember", alLinkedMembers);
			}

			if (hmUserFraudLock != null && !hmUserFraudLock.isEmpty()) {
				hmResult.put(CommonDefs.USER_FRAUD_LOCK, hmUserFraudLock);
			}

			if (hmUserSecurityInfo != null && !hmUserSecurityInfo.isEmpty()) {
				hmResult.put("userSecurityInfo", hmUserSecurityInfo);
			}

			if (hmUserFraudPassword != null && !hmUserFraudPassword.isEmpty()) {
				hmResult.put("userFraudPassword", hmUserFraudPassword);
			}

			if (alUserLockout != null && !alUserLockout.isEmpty()) {
				hmResult.put("userLockout", alUserLockout);
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			if(e instanceof NumberFormatException)
			   hmResult.put(MPSDefs.APP_INFO, "Guid length is invalid");
			
			logger.error("{}{}IPDBH021 :  Error::{}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}IPDBH022 : Exception = {}", sClassName, sMethodName, e);
		} finally {
			logger.info(SpiMarker.getInstance(), "InquireProfileDBHelper.inquireProfile.DBTOOLS999 : response : {}", 
					hmResult);
			}
		return hmResult;
	}

	private int inquireProfileMemberDetails(HashMap hmMember, List<Tmember> alTmember, String sGen_password_type,
			int numRowsFound) {
		String sMethodName = ".inquireProfileMemberDetails.";
		String sDBMemberNum;
		for (Tmember tmember : alTmember) {
			hmMember.put(CommonDefs.MEMBER_NUM, tmember.getMemberNum());
			hmMember.put(CommonDefs.MEMBER_NAME, tmember.getMemberName());
			hmMember.put(CommonDefs.DOMAIN_ID, tmember.getTdomain().getDomainId());
			hmMember.put(CommonDefs.PROOFING_PARENT_CHILD_IND, tmember.getParentChildInd());
			hmMember.put(CommonDefs.FULLNAME, tmember.getFullname());
			if (tmember.getFirstname() != null)
				hmMember.put(CommonDefs.FIRST_NAME, tmember.getFirstname());
			if (tmember.getLastname() != null)
				hmMember.put(CommonDefs.LAST_NAME, tmember.getLastname());
			if (tmember.getBrowserLanguage() != null)
				hmMember.put(CommonDefs.BROWSER_LANGUAGE, tmember.getBrowserLanguage());
			hmMember.put(CommonDefs.LAST_MODIFIED_BY, tmember.getLastModifiedBy());
			if (tmember.getContactEmail() != null)
				hmMember.put(CommonDefs.CONTACT_EMAIL, tmember.getContactEmail());
			hmMember.put(CommonDefs.AUTO_GENERATED_IND,
					tmember.getAutogeneratedInd() == null ? "N" : tmember.getAutogeneratedInd());
			hmMember.put(CommonDefs.ACTIVATED_IND,
					tmember.getActivatedInd() == null ? "Y" : tmember.getActivatedInd());
			if (tmember.getMigrationInd() != null)
				hmMember.put(CommonDefs.MIGRATION_IND, tmember.getMigrationInd());
			if (tmember.getContactEmailStatus() != null)
				hmMember.put(CommonDefs.CONTACT_EMAIL_STATUS, tmember.getContactEmailStatus());
			if (tmember.getTsecurityquestionBySecurityQuestionId1() != null)
				hmMember.put("securityQuestionId1",
						tmember.getTsecurityquestionBySecurityQuestionId1().getSecurityQuestionId());
			if (tmember.getTsecurityquestionBySecurityQuestionId2() != null)
				hmMember.put("securityQuestionId2",
						tmember.getTsecurityquestionBySecurityQuestionId2().getSecurityQuestionId());
			if (tmember.getSshaPassword() != null)
				hmMember.put(CommonDefs.DB_SSHA_PASSWORD, tmember.getSshaPassword());
			hmMember.put(CommonDefs.PASSWORD_DIRTY,
					tmember.getPasswordDirty() == null ? "N" : tmember.getPasswordDirty());
			if (tmember.getContactEmailEstDate() != null)
				hmMember.put(CommonDefs.CONTACT_EMAIL_EST_DATE,
						new SimpleDateFormat("MMddyyyy HH:mm:ss").format(tmember.getContactEmailEstDate()));
			hmMember.put(CommonDefs.CREATE_DATE,
					new SimpleDateFormat("MMddyyyy HH:mm:ss").format(tmember.getCreateDate()));
			if (tmember.getActivatedDate() != null)
				hmMember.put("activated_date",
						new SimpleDateFormat("MMddyyyy HH:mm:ss").format(tmember.getActivatedDate()));
			if (tmember.getLastModified() != null)
				hmMember.put(CommonDefs.LAST_MODIFIED,
						new SimpleDateFormat("MMddyyyy HH:mm:ss").format(tmember.getLastModified()));
			if (tmember.getOnlQaEstDate() != null)
				hmMember.put("onlQaEstDate",
						new SimpleDateFormat("MMddyyyy HH:mm:ss").format(tmember.getOnlQaEstDate()));
			if (tmember.getAccessidRtvDate() != null)
				hmMember.put("accessIdRTValidDate",
						new SimpleDateFormat("MMddyyyy HH:mm:ss").format(tmember.getAccessidRtvDate()));
			if (tmember.getContactEmailValid() != null)
				hmMember.put(CommonDefs.CONTACT_EMAIL_VALID, tmember.getContactEmailValid());
			if (tmember.getContactEmailRtvDate() != null)
				hmMember.put("contactEmailRTValidDate",
						new SimpleDateFormat("MMddyyyy HH:mm:ss").format(tmember.getContactEmailRtvDate()));
			if (tmember.getPreviousContactEmail() != null)
				hmMember.put(CommonDefs.PREVIOUS_CONTACT_EMAIL, tmember.getPreviousContactEmail());
			if (tmember.getFnLinkedUserid() != null)
				hmMember.put(CommonDefs.LINKED_FN_USER_ID, tmember.getFnLinkedUserid());
			if (tmember.getFnLinkedStatus() != null)
				hmMember.put(CommonDefs.LINKED_FN_USER_STATUS, tmember.getFnLinkedStatus());
			if (tmember.getTmemberaux() != null) {
				if (tmember.getTmemberaux().getEncPasswordVenc() != null)
					hmMember.put("enc_password_venc", tmember.getTmemberaux().getEncPasswordVenc());
				if (tmember.getTmemberaux().getMd5PasswordVenc() != null)
					hmMember.put("md5_password_venc", tmember.getTmemberaux().getMd5PasswordVenc());
				if (tmember.getTmemberaux().getSha1PasswordVenc() != null)
					hmMember.put("sha1_password_venc", tmember.getTmemberaux().getSha1PasswordVenc());
				if (tmember.getTmemberaux().getDes3PasswordVenc() != null)
					hmMember.put("des3_password_venc", tmember.getTmemberaux().getDes3PasswordVenc());
				if (tmember.getTmemberaux().getSshaPasswordVenc() != null)
					hmMember.put("ssha_password_venc", tmember.getTmemberaux().getSshaPasswordVenc());
				if (tmember.getTmemberaux().getSecurityAnswer1Venc() != null)
					hmMember.put("security_answer_1_venc", tmember.getTmemberaux().getSecurityAnswer1Venc());
				if (tmember.getTmemberaux().getSecurityAnswer2Venc() != null)
					hmMember.put("security_answer_2_venc", tmember.getTmemberaux().getSecurityAnswer2Venc());
				if (tmember.getTmemberaux().getLastModifiedPw() != null)
					hmMember.put("lastModifiedPw", new SimpleDateFormat("MMddyyyy HH:mm:ss")
							.format(tmember.getTmemberaux().getLastModifiedPw()));
				if (tmember.getTmemberaux().getLastModifiedSec() != null)
					hmMember.put("lastModifiedSec", new SimpleDateFormat("MMddyyyy HH:mm:ss")
							.format(tmember.getTmemberaux().getLastModifiedSec()));
				if (tmember.getTmemberaux().getRecentFraudPwDate() != null)
					hmMember.put("recentFraudPwDate", new SimpleDateFormat("MMddyyyy HH:mm:ss")
							.format(tmember.getTmemberaux().getRecentFraudPwDate()));
			}
			if (tmember.getTsecurityquestionBySecurityQuestionId1() != null)
				hmMember.put("securityQuestion1",
						tmember.getTsecurityquestionBySecurityQuestionId1().getSecurityQuestion());
			if (tmember.getTsecurityquestionBySecurityQuestionId2() != null)
				hmMember.put("securityQuestion2",
						tmember.getTsecurityquestionBySecurityQuestionId2().getSecurityQuestion());
			hmMember.put("domainName", tmember.getTdomain().getDomainName());			
			if (tmember.getCreatedBy() != null)
				hmMember.put(CommonDefs.CREATED_BY, tmember.getCreatedBy());

			if (sGen_password_type != null && !sGen_password_type.trim().isEmpty()) {
				hmMember.put("gen_password_venc", tmember.getTmemberaux().getPasswordVenc());
				hmMember.put("gen_password_type", tmember.getTmemberaux().getPasswordType());
			}
          
			sDBMemberNum = hmMember.get(CommonDefs.MEMBER_NUM).toString();
			logger.info("{}{}IPDBH001 : member_num returned from member query = {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(sDBMemberNum)));

			++numRowsFound;

		}
		return numRowsFound;
	}

	private void inquireProfileReturnUserFraudPassword(HashMap hmUserFraudPassword, List<Tmember> alTmember) {
		if (alTmember != null && !alTmember.isEmpty()) {
			for (Tmember tmember : alTmember) {
				Object[] arr = tmember.getTmemberfraudpasswords().toArray();
				Long maxFraudCounter = 0L;
				if (arr.length > 0) {
					for (Object obj : arr) {
						Tmemberfraudpassword tmemberfraudpassword = (Tmemberfraudpassword) obj;
						if (tmemberfraudpassword.getId().getFraudCounter() > maxFraudCounter) {
							hmUserFraudPassword.put(CommonDefs.MEMBER_NUM, tmemberfraudpassword.getId().getMemberNum());
							hmUserFraudPassword.put("fraudCounter", tmemberfraudpassword.getId().getFraudCounter());
							hmUserFraudPassword.put(CommonDefs.PASSWORD_TYPE, tmemberfraudpassword.getPasswordType());
							hmUserFraudPassword.put("password_venc", tmemberfraudpassword.getPasswordVenc());
							hmUserFraudPassword.put(CommonDefs.CREATE_DATE, new SimpleDateFormat("MMddyyyy HH:mm:ss")
									.format(tmemberfraudpassword.getCreateDate()));
							hmUserFraudPassword.put(CommonDefs.LAST_MODIFIED, new SimpleDateFormat("MMddyyyy HH:mm:ss")
									.format(tmemberfraudpassword.getLastModified()));
							hmUserFraudPassword.put(CommonDefs.LAST_MODIFIED_BY,
									tmemberfraudpassword.getLastModifiedBy());
							maxFraudCounter = tmemberfraudpassword.getId().getFraudCounter();
						}
					}
				}
			}
		}
	}

	private void inquireProfileUserLockOutDetails(ArrayList alUserLockout, List<Tmember> alTmember,
			String sReturnUserLockout) {
		String sMethodName = ".inquireProfileUserLockOutDetails.";
		if ((sReturnUserLockout != null && !sReturnUserLockout.isEmpty()) && (sReturnUserLockout.equals("Y"))) {
			if (alTmember != null && !alTmember.isEmpty()) {
				for (Tmember tmember : alTmember) {
					Object[] arr = tmember.getTmemberlockouts().toArray();
					for (Object obj : arr) {
						HashMap hmUserLockout = CommonUtil.getHashMap();
						Tmemberlockout tmemberlockout = (Tmemberlockout) obj;
						String lockoutName = lockoutRepository
								.findLockoutNameByLockoutId(tmemberlockout.getId().getLockoutId());
						hmUserLockout.put(CommonDefs.MEMBER_NUM, tmemberlockout.getId().getMemberNum());
						hmUserLockout.put("lockoutId", tmemberlockout.getId().getLockoutId());
						hmUserLockout.put("setNumber", tmemberlockout.getSetNumber());
						if (tmemberlockout.getFailedAuthCount() != null)
							hmUserLockout.put(CommonDefs.FAILED_AUTH_COUNT, tmemberlockout.getFailedAuthCount());
						if (tmemberlockout.getLockoutExpiration() != null)
							hmUserLockout.put("lockoutExpiration", new SimpleDateFormat("MMddyyyy HH:mm:ss")
									.format(tmemberlockout.getLockoutExpiration()));
						if (tmemberlockout.getLastFailedAuth() != null)
							hmUserLockout.put(CommonDefs.LAST_FAILED_AUTH, new SimpleDateFormat("MMddyyyy HH:mm:ss")
									.format(tmemberlockout.getLastFailedAuth()));
						hmUserLockout.put(CommonDefs.CREATE_DATE,
								new SimpleDateFormat("MMddyyyy HH:mm:ss").format(tmemberlockout.getCreateDate()));
						hmUserLockout.put(CommonDefs.LAST_MODIFIED,
								new SimpleDateFormat("MMddyyyy HH:mm:ss").format(tmemberlockout.getLastModified()));
						hmUserLockout.put(CommonDefs.LAST_MODIFIED_BY, tmemberlockout.getLastModifiedBy());
						hmUserLockout.put("lockoutName", lockoutName);

						alUserLockout.add(new HashMap(hmUserLockout));
					}
				}
			}

			logger.debug("{}{}IPDBH020 : Result of User lockout query: {}.", sClassName, sMethodName, alUserLockout);
		}
	}

	private void inquireProfileMemberServiceAttributesDetails(ArrayList alMemberSvcRoles,
			ArrayList alMemberServiceAttributes, List<Tmember> alTmember) {

		String sMethodName = ".inquireProfileMemberServiceAttributesDetails.";
		if (alMemberSvcRoles != null && !alMemberSvcRoles.isEmpty()) {
			if (alTmember != null && !alTmember.isEmpty()) {
				for (Tmember tmember : alTmember) {
					Object[] hmQueryResponse = tmember.getTmemberserviceattributes().toArray();
					HashMap hmMemberServiceAttributes = CommonUtil.getHashMap();
					for (Object obj : hmQueryResponse) {
						Tmemberserviceattribute tmemberserviceattribute = (Tmemberserviceattribute) obj;
						String attributeName = attributeRepository
								.findAttributeNameByAttributeId(tmemberserviceattribute.getId().getAttributeId());
						hmMemberServiceAttributes.put(CommonDefs.MEMBER_NUM,
								tmemberserviceattribute.getId().getMemberNum());
						hmMemberServiceAttributes.put(CommonDefs.SERVICE_ID,
								tmemberserviceattribute.getId().getServiceId());
						hmMemberServiceAttributes.put(CommonDefs.SOR_ID, tmemberserviceattribute.getId().getSorId());
						hmMemberServiceAttributes.put(CommonDefs.SOR_INVARIANT_ID,
								tmemberserviceattribute.getId().getSorInvariantId());
						hmMemberServiceAttributes.put(CommonDefs.ATTRIBUTE_NAME, attributeName);
						hmMemberServiceAttributes.put(CommonDefs.ATTRIBUTE_ID,
								tmemberserviceattribute.getId().getAttributeId());
						hmMemberServiceAttributes.put(CommonDefs.ATTRIBUTE_VALUE,
								tmemberserviceattribute.getId().getValue());

						alMemberServiceAttributes.add(new HashMap(hmMemberServiceAttributes));
					}
				}
			}
			logger.debug("{}{}IPDBH013 : Result of service attributes query: {}", sClassName, sMethodName,
					alMemberServiceAttributes);
		}

		if (alMemberServiceAttributes != null && !alMemberServiceAttributes.isEmpty()) {
			String sMemberNum = null;
			String sServiceId = null;
			String sSorId = null;
			String sSorInvariantId = null;

			for (Object role : alMemberSvcRoles) {
				ArrayList alAttributes = CommonUtil.getArrayList();

				if (role != null && role instanceof HashMap) {
					HashMap hmRoles = (HashMap) role;
					if (hmRoles.containsKey(CommonDefs.MEMBER_NUM)) {
						sMemberNum = hmRoles.get(CommonDefs.MEMBER_NUM).toString();
					}
					if (hmRoles.containsKey(CommonDefs.SERVICE_ID)) {
						sServiceId = hmRoles.get(CommonDefs.SERVICE_ID).toString();
					}
					if (hmRoles.containsKey(CommonDefs.SOR_ID)) {
						sSorId = hmRoles.get(CommonDefs.SOR_ID).toString();
					}
					if (hmRoles.containsKey(CommonDefs.SOR_INVARIANT_ID)) {
						sSorInvariantId = (String) hmRoles.get(CommonDefs.SOR_INVARIANT_ID);
					}

					for (Object serviceAttribute : alMemberServiceAttributes) {
						if (serviceAttribute != null && serviceAttribute instanceof HashMap) {
							HashMap hmMemberSvcAttribute = (HashMap) serviceAttribute;
							if (hmMemberSvcAttribute.containsKey(CommonDefs.MEMBER_NUM)
									&& sMemberNum.equals(hmMemberSvcAttribute.get(CommonDefs.MEMBER_NUM).toString())
									&& hmMemberSvcAttribute.containsKey(CommonDefs.SERVICE_ID)
									&& sServiceId.equals(hmMemberSvcAttribute.get(CommonDefs.SERVICE_ID).toString())
									&& hmMemberSvcAttribute.containsKey(CommonDefs.SOR_ID)
									&& sSorId.equals(hmMemberSvcAttribute.get(CommonDefs.SOR_ID).toString())
									&& hmMemberSvcAttribute.containsKey(CommonDefs.SOR_INVARIANT_ID)
									&& sSorInvariantId.equals(hmMemberSvcAttribute.get(CommonDefs.SOR_INVARIANT_ID))) {

								HashMap hmAttribute = CommonUtil.getHashMap();

								hmAttribute.put(CommonDefs.ATTRIBUTE_ID,
										hmMemberSvcAttribute.get(CommonDefs.ATTRIBUTE_ID).toString());
								hmAttribute.put(CommonDefs.ATTRIBUTE_NAME,
										(String) hmMemberSvcAttribute.get(CommonDefs.ATTRIBUTE_NAME));
								hmAttribute.put(CommonDefs.ATTRIBUTE_VALUE,
										(String) hmMemberSvcAttribute.get(CommonDefs.ATTRIBUTE_VALUE));
								alAttributes.add(hmAttribute);
							}
						}
					}
					if (alAttributes != null && !alAttributes.isEmpty()) {
						hmRoles.put(CommonDefs.ATTRIBUTES, alAttributes);
					}
				}
			}
		} 
	}

	private void inquireProfileMemberServiceRole(ArrayList alMemberSvcRoles, List<Tmember> alTmember) {
		for (Tmember hmQueryResponse : alTmember) {
			Object[] arrTmemberservice = hmQueryResponse.getTmemberservices().toArray();
			for (Object tmp : arrTmemberservice) {

				HashMap hmMemberSvcRole = CommonUtil.getHashMap();
				Tmemberservice tMemberService = (Tmemberservice) tmp;
				hmMemberSvcRole.put(CommonDefs.MEMBER_NUM, tMemberService.getId().getMemberNum());
				hmMemberSvcRole.put(CommonDefs.SERVICE_ID, tMemberService.getId().getServiceId());
				hmMemberSvcRole.put("memberStatusCode", tMemberService.getId().getMemberStatus());
				hmMemberSvcRole.put(CommonDefs.CREATE_DATE,
						new SimpleDateFormat("MMddyyyy HH:mm:ss").format(tMemberService.getId().getCreateDate()));
				hmMemberSvcRole.put(CommonDefs.LAST_MODIFIED_BY, tMemberService.getId().getLastModifiedBy());
				if (tMemberService.getInstanceId() != null)
					hmMemberSvcRole.put(CommonDefs.INSTANCE_ID, tMemberService.getInstanceId());
				hmMemberSvcRole.put(CommonDefs.SOR_ID, tMemberService.getId().getSorId());
				hmMemberSvcRole.put(CommonDefs.SOR_INVARIANT_ID, tMemberService.getSorInvariantId());
				if (tMemberService.getNickname() != null)
					hmMemberSvcRole.put(CommonDefs.IGP_NICK_NAME, tMemberService.getNickname());
				if (tMemberService.getDefaultAccount() != null)
					hmMemberSvcRole.put(CommonDefs.DEFAULT_ACCOUNT, tMemberService.getDefaultAccount());
				if (tMemberService.getCpniImpacted() != null)
					hmMemberSvcRole.put(CommonDefs.CPNI_IMPACTED, tMemberService.getCpniImpacted());
				if (tMemberService.getParentSorId() != null)
					hmMemberSvcRole.put(CommonDefs.PARENT_SOR_ID, tMemberService.getParentSorId());
				if (tMemberService.getParentSorInvariantId() != null)
					hmMemberSvcRole.put(CommonDefs.PARENT_SOR_INVARIANT_ID, tMemberService.getParentSorInvariantId());
				if (tMemberService.getDateDefaultEst() != null)
					hmMemberSvcRole.put(CommonDefs.DATE_DEFAULT_EST,
							new SimpleDateFormat("MMddyyyy HH:mm:ss").format(tMemberService.getDateDefaultEst()));
				hmMemberSvcRole.put(CommonDefs.LAST_MODIFIED,
						new SimpleDateFormat("MMddyyyy HH:mm:ss").format(tMemberService.getLastModified()));
				hmMemberSvcRole.put(CommonDefs.SERVICE_NAME, tMemberService.getTservice().getServiceName());
				if ((CommonDefs.ECOMM_SERVICE.equalsIgnoreCase(tMemberService.getTservice().getServiceName())
						|| CommonDefs.MOBILITY_SERVICE.equalsIgnoreCase(tMemberService.getTservice().getServiceName())
						|| CommonDefs.TITAN_SERVICE.equalsIgnoreCase(tMemberService.getTservice().getServiceName()))
						&& tMemberService.getParentSorInvariantId() == null) {
					hmMemberSvcRole.put("roleId", tMemberService.getTmemberservicerole().getRoleId());
					hmMemberSvcRole.put("roleStatusCode", tMemberService.getTmemberservicerole().getStatus());
					hmMemberSvcRole.put("roleStatusName",
							tMemberService.getTmemberservicerole().getTstatus().getStatusName());
					hmMemberSvcRole.put(CommonDefs.ROLE_NAME,
							tMemberService.getTmemberservicerole().getTservicerole().getRoleName());
				}
				hmMemberSvcRole.put("memberStatusName", tMemberService.getTstatusByMemberStatus().getStatusName());
				hmMemberSvcRole.put(CommonDefs.KEY_SOR_NAME, tMemberService.getTsystemofrecord().getSorName());
				alMemberSvcRoles.add(hmMemberSvcRole);
			}
		}
	}

	private void inquireProfileLinkedMemberDetails(ArrayList alLinkedMembers, List<Tmember> alTmember, String sLevel) {

		String sMethodName = ".inquireProfileLinkedMemberDetails.";
		if (sLevel.equals("LM")) {

			if (alTmember != null && !alTmember.isEmpty()) {
				for (Tmember tmember : alTmember) {
					HashMap hmLinkedMem = CommonUtil.getHashMap();
					Object[] arr = tmember.getTmembers().toArray();
					for (Object obj : arr) {
						Tmember linkedMember = (Tmember) obj;
						if (!linkedMember.getParentChildInd().equals('S')) {
							hmLinkedMem.put(CommonDefs.MEMBER_NUM, linkedMember.getMemberNum());
							hmLinkedMem.put(CommonDefs.MEMBER_NAME, linkedMember.getMemberName());
							hmLinkedMem.put(CommonDefs.DOMAIN_ID, linkedMember.getTdomain().getDomainId());
							hmLinkedMem.put(CommonDefs.SOR_ID, linkedMember.getTsystemofrecord().getSorId());
							hmLinkedMem.put(CommonDefs.ACCOUNT_TYPE, linkedMember.getAccountType());
							hmLinkedMem.put(CommonDefs.PROOFING_PARENT_CHILD_IND, linkedMember.getParentChildInd());
							hmLinkedMem.put(CommonDefs.MEMBER_STATE, linkedMember.getMemberState());
							if (linkedMember.getAggServiceStatus() != null)
								hmLinkedMem.put("aggServiceStatus", linkedMember.getAggServiceStatus());
							if (linkedMember.getMailhost() != null)
								hmLinkedMem.put(CommonDefs.MAIL_HOST, linkedMember.getMailhost());
							hmLinkedMem.put(CommonDefs.FULLNAME, linkedMember.getFullname());
							hmLinkedMem.put(CommonDefs.CREATE_DATE,
									new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0").format(linkedMember.getCreateDate()));
							hmLinkedMem.put(CommonDefs.LAST_MODIFIED,
									new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0").format(linkedMember.getLastModified()));
							hmLinkedMem.put(CommonDefs.LAST_MODIFIED_BY, linkedMember.getLastModifiedBy());
							if (linkedMember.getBan() != null)
								hmLinkedMem.put(CommonDefs.BAN, linkedMember.getBan());
							if (linkedMember.getDeleteRequestDate() != null)
								hmLinkedMem.put(CommonDefs.DELETE_REQUEST_DATE,
										new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0")
												.format(linkedMember.getDeleteRequestDate()));
							hmLinkedMem.put(CommonDefs.PASSWORD_DIRTY,
									linkedMember.getPasswordDirty() == null ? "N" : linkedMember.getPasswordDirty());
							if (linkedMember.getFirstname() != null)
								hmLinkedMem.put(CommonDefs.FIRST_NAME, linkedMember.getFirstname());
							if (linkedMember.getLastname() != null)
								hmLinkedMem.put(CommonDefs.LAST_NAME, linkedMember.getLastname());
							if (linkedMember.getNickname() != null)
								hmLinkedMem.put(CommonDefs.IGP_NICK_NAME, linkedMember.getNickname());
							if (linkedMember.getGender() != null)
								hmLinkedMem.put(CommonDefs.GENDER, linkedMember.getGender());
							hmLinkedMem.put(CommonDefs.SLID_MEMBER_NUM, linkedMember.getTmember().getMemberNum());
							if (linkedMember.getCreatedBy() != null)
								hmLinkedMem.put(CommonDefs.CREATED_BY, linkedMember.getCreatedBy());
							hmLinkedMem.put("domainName", linkedMember.getTdomain().getDomainName());
							hmLinkedMem.put(CommonDefs.PROOFING_SOR_NAME,
									linkedMember.getTsystemofrecord().getSorName());

							alLinkedMembers.add(new HashMap(hmLinkedMem));
						}
					}

				}
				logger.debug("{}{}IPDBH014 : Result of linked member query: {}", sClassName, sMethodName,
						alLinkedMembers);
			}

		}
	}
}
