package com.att.idp.idgraphusermanagementms.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.mpsys.common.utils.PropertyManager;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;


/**
 * The BadWordHelper class is part of the com.att.idp.idgraphusermanagementms.utils package.
 * This class is responsible for handling operations related to bad words in the system.
 * It includes methods for scanning words, checking bad words, and initializing bad word lists.
 * It also includes helper methods for manipulating strings and handling bad word files.
 * The class is annotated with @Component, indicating that it is an auto-detectable Spring bean.
 */

@Component
public class BadWordHelper {
	private static final Logger logger = LoggerFactory.getLogger(BadWordHelper.class);

	
	private static ArrayList dirtyWordsHiddenAL = null;

	private static ArrayList dirtyWordsMiddleAL = null;

	private static ArrayList dirtyWordsStartOrWholeAL = null;

	private static ArrayList dirtyWordsWholeAL = null;

	private static ArrayList corporateWordsHiddenAL = null;

	private static ArrayList corporateWordsMiddleAL = null;

	private static ArrayList corporateWordsStartOrWholeAL = null;

	private static ArrayList corporateWordsWholeAL = null;

	private static ArrayList commonWordsHiddenAL = null;

	private static ArrayList commonWordsMiddleAL = null;

	private static ArrayList commonWordsStartOrWholeAL = null;

	private static ArrayList commonWordsWholeAL = null;
	
	private static ArrayList comboWordsAL = null;
	
	//DEC2012 Updated for TVGAMES callingSystemId	
	private static ArrayList tvgamesWordsMiddleAL = null;
	
	private static final int HANDLE_LENGTH_MAX_FOR_SLID = 127;

	private static long lasttime = 0;
	
	private static HashMap hmfileLastLastModified = null;

	private  synchronized HashMap init(Logger logger) {
		String methodName = "init";
		HashMap hmResult = null;
		String stAppInfo = null;
		long currentTime = 0;

		try {
			currentTime = java.lang.System.currentTimeMillis();
			String stWordScanRefreshMinutes = PropertyManager.getProperty(CommonDefs.MOUPConfig, CommonDefs.RILHRS_WORD_SCAN_REFRESH_MINUTES);
			if (stWordScanRefreshMinutes == null
					|| stWordScanRefreshMinutes.trim().length() == 0) {
				stAppInfo = "Missing config parameter:: RILHRS_WordScanRefreshMinutes";
				logger.error("init01 : " +  stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(
						CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
				return hmResult;
			}
			int wordScanRefreshMinutes = Integer
					.parseInt(stWordScanRefreshMinutes);
			if ((currentTime - lasttime) < wordScanRefreshMinutes * 60 * 1000L) {
				stAppInfo = "No Need to Parse the file";
				logger.info("init02 : " + stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(
						CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
				return hmResult;
			}
			stAppInfo = "Bad Word Files Parsing Started ";
			logger
					.info("init03 : "+
							stAppInfo);
			lasttime = currentTime;

			String stBadWordFilePath = PropertyManager.getProperty(CommonDefs.MOUPConfig, CommonDefs.RILHRS_BADWORD_DIRECTORY); // TODO
			if (stBadWordFilePath == null
					|| stBadWordFilePath.trim().length() == 0) {
				stAppInfo = "Missing config parameter:: RILHRS_BadWordsDir";
				logger.error("init04 : "+ stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(
						CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
				return hmResult;
			}

			String stDirtyWordsHiddenFile = stBadWordFilePath
					+ "dirtyWords_hidden.txt";
			String stDirtyWordsMiddleFile = stBadWordFilePath
					+ "dirtyWords_middle.txt";
			String stDirtyWordsStartOrWholeFile = stBadWordFilePath
					+ "dirtyWords_startOrWhole.txt";
			String stDirtyWordsWholeFile = stBadWordFilePath
					+ "dirtyWords_whole.txt";

			String stCorporateWordsHiddenFile = stBadWordFilePath
					+ "corporateWords_hidden.txt";
			String stCorporateWordsMiddleFile = stBadWordFilePath
					+ "corporateWords_middle.txt";
			String stCorporateWordsStartOrWholeFile = stBadWordFilePath
					+ "corporateWords_startOrWhole.txt";
			String stCorporateWordsWholeFile = stBadWordFilePath
					+ "corporateWords_whole.txt";

			String stCommonWordsHiddenFile = stBadWordFilePath
					+ "commonWords_hidden.txt";
			String stCommonWordsMiddleFile = stBadWordFilePath
					+ "commonWords_middle.txt";
			String stCommonWordsStartOrWholeFile = stBadWordFilePath
					+ "commonWords_startOrWhole.txt";
			String stCommonWordsWholeFile = stBadWordFilePath
					+ "commonWords_whole.txt";

			String stComboWordsFile = stBadWordFilePath + "comboWords.txt";
			
			String stTVGamesWordsMiddleFile = stBadWordFilePath
					+ "tvgamesWords_middle.txt";

			stAppInfo = "Bad Word File Path from Config :: ";

			logger.info("init05 : "+ stAppInfo
					+ stDirtyWordsHiddenFile);
			logger.info("init06 : "+ stAppInfo
					+ stDirtyWordsMiddleFile);
			logger.info("init07 : "+ stAppInfo
					+ stDirtyWordsStartOrWholeFile);
			logger.info("init08 : "+ stAppInfo
					+ stDirtyWordsWholeFile);

			logger.info("init09 : "+ stAppInfo
					+ stCorporateWordsHiddenFile);
			logger.info("init10 : "+ stAppInfo
					+ stCorporateWordsMiddleFile);
			logger.info("init11 : "+ stAppInfo
					+ stCorporateWordsStartOrWholeFile);
			logger.info("init12 : "+ stAppInfo
					+ stCorporateWordsWholeFile);

			logger.info("init13 : "+ stAppInfo
					+ stCommonWordsHiddenFile);
			logger.info("init14 : "+ stAppInfo
					+ stCommonWordsMiddleFile);
			logger.info("init15 : "+ stAppInfo
					+ stCommonWordsStartOrWholeFile);
			logger.info("init16 : "+ stAppInfo
					+ stCommonWordsWholeFile);

			logger.info("init16.5 : "+ stAppInfo
					 + stComboWordsFile);
			
			logger.info("init16.8 : "+ stAppInfo
					+ stTVGamesWordsMiddleFile);

			if (isFirstCallOrFileModified(stDirtyWordsHiddenFile, logger))
			dirtyWordsHiddenAL = readFile(stDirtyWordsHiddenFile, logger);
			
			if (isFirstCallOrFileModified(stDirtyWordsMiddleFile, logger))
			dirtyWordsMiddleAL = readFile(stDirtyWordsMiddleFile, logger);
			
			if (isFirstCallOrFileModified(stDirtyWordsStartOrWholeFile, logger))
			dirtyWordsStartOrWholeAL = readFile(stDirtyWordsStartOrWholeFile,
					logger);
			
			if (isFirstCallOrFileModified(stDirtyWordsWholeFile, logger))
			dirtyWordsWholeAL = readFile(stDirtyWordsWholeFile, logger);

			if (isFirstCallOrFileModified(stCorporateWordsHiddenFile, logger))
			corporateWordsHiddenAL = readFile(stCorporateWordsHiddenFile, logger);
			
			if (isFirstCallOrFileModified(stCorporateWordsMiddleFile, logger))
			corporateWordsMiddleAL = readFile(stCorporateWordsMiddleFile, logger);
			
			if (isFirstCallOrFileModified(stCorporateWordsStartOrWholeFile, logger))
			corporateWordsStartOrWholeAL = readFile(
					stCorporateWordsStartOrWholeFile, logger);
			
			if (isFirstCallOrFileModified(stCorporateWordsWholeFile, logger))
			corporateWordsWholeAL = readFile(stCorporateWordsWholeFile, logger);

			if (isFirstCallOrFileModified(stCommonWordsHiddenFile, logger))
			commonWordsHiddenAL = readFile(stCommonWordsHiddenFile, logger);
			
			if (isFirstCallOrFileModified(stCommonWordsMiddleFile, logger))
			commonWordsMiddleAL = readFile(stCommonWordsMiddleFile, logger);
			
			if (isFirstCallOrFileModified(stCommonWordsStartOrWholeFile, logger))
			commonWordsStartOrWholeAL = readFile(stCommonWordsStartOrWholeFile,
					logger);
			
			if (isFirstCallOrFileModified(stCommonWordsWholeFile, logger))
			commonWordsWholeAL = readFile(stCommonWordsWholeFile, logger);
			
			if (isFirstCallOrFileModified(stComboWordsFile, logger))
			comboWordsAL = readFile(stComboWordsFile, logger);
			
			if (isFirstCallOrFileModified(stTVGamesWordsMiddleFile, logger))
				tvgamesWordsMiddleAL = readFile(stTVGamesWordsMiddleFile, logger);

			stAppInfo = "Bad Word Files Parsing Completed along with updation of HashMap with File TimeStamp::"
					+ hmfileLastLastModified;
			logger
					.info("init17 : "+
							stAppInfo);

			hmResult = CommonErrorMap.makeCategoryMap(
					CErrorDefs.COMMON_SUCCESS_NUM, " ");
			return hmResult;

		} catch (Exception ex) {
			stAppInfo = "Exception thrown from init() method ::"
					+ ex.getMessage();
			logger.error("init18 : "+ stAppInfo);
			
			// Clear and Initialize the Static ArrayList and time.
			clearAndInitialize();
			hmResult = CommonErrorMap.makeExceptionMap(ex, logger);
			return hmResult;
		} finally {
			// Calculate the total time taken to execute the init method
			long totalTime = (System.currentTimeMillis() - currentTime);
			logger
					.info("init20 : "+
							"Total time taken to execute init() method = "
									+ new Long(totalTime).toString()
									+ " milli seconds");
		}
	}

	
	private  boolean isFirstCallOrFileModified(String filename,
			Logger logger) {
		String methodName = "isFirstCallOrFileModified";
		boolean bFirstCallOrFileModified = false;
		File f = new File(filename);
		int i1 = filename.lastIndexOf("/");
		int i2 = filename.indexOf(".txt");
		String key = filename.substring(i1 + 1, i2);
		long fileLastModified = f.lastModified();
		long fileLastLastModified = 0;
		if (hmfileLastLastModified == null) {
			logger.info("IFM00 : "+
					"First Call for File Parsing and Instantiation of TimeStamp Hashmap :: "
							+ filename);
			hmfileLastLastModified = new HashMap();
			hmfileLastLastModified.put("fileLastLastModified" + key,
					fileLastModified);
			bFirstCallOrFileModified = true;
			return bFirstCallOrFileModified;
		} else if (hmfileLastLastModified.containsKey("fileLastLastModified"
				+ key)) {
			fileLastLastModified = (Long) hmfileLastLastModified
					.get("fileLastLastModified" + key);
		} else {
			logger.info("IFM01 : "+
					"First Call for File Parsing :: " + filename);
			hmfileLastLastModified.put("fileLastLastModified" + key,
					fileLastModified);
			bFirstCallOrFileModified = true;
			return bFirstCallOrFileModified;
		}
		Date dLastModified = new Date(fileLastModified);
		Date dLastLastModified = new Date(fileLastLastModified);
		logger.info("IFM02 : "+
				"File last modified at : " + dLastModified);
		logger.info("IFM03 : "+
				"File last last modified at : " + dLastLastModified);
		if (fileLastLastModified != fileLastModified) {
			logger.info("IFM04 : "+
					"File is modified so need to read again ::" + filename);
			hmfileLastLastModified.put("fileLastLastModified" + key,
					fileLastModified);
			bFirstCallOrFileModified = true;
		} else {
			logger.info("IFM02 : "+
					"File was not modified so no need to read again ::"
							+ filename);
		}
		return bFirstCallOrFileModified;
	}
	
	
	private  ArrayList readFile(String filename, Logger logger)
			throws IOException, FileNotFoundException {
        String stAppInfo;
        ArrayList alBadWords;
        boolean bSort;
        try (BufferedReader buffRead = new BufferedReader(new FileReader(filename))) {
            String stWordInFile = null;
            stAppInfo = null;
            alBadWords = new ArrayList();
            ArrayList alComboBadWords = new ArrayList();
            bSort = true;
            while ((stWordInFile = buffRead.readLine()) != null) {
                if (filename.indexOf("comboWords") != -1) {
                    alComboBadWords = CommonUtil.parseToArray(stWordInFile, ',');
                    if (alComboBadWords != null && !alComboBadWords.isEmpty()) {
                        alBadWords.add(alComboBadWords);
                    }
                    bSort = false;
                } else {
                    alBadWords.add(stWordInFile);
                }
            }

        }

        if(bSort)
		Collections.sort(alBadWords);
		
		stAppInfo = "Filename = [" + filename + "] :: No. Of Bad Words :: "
				+ alBadWords.size();
		logger.info("RF01 : "+ stAppInfo);
		return alBadWords;
	}

	/**
	 * This method is part of the BadWordHelper class.
	 * It is responsible for scanning words in the system.
	 * The method takes a HashMap as a parameter, which contains the details of the words to be scanned.
	 * The HashMap should contain the following keys:
	 * - CommonDefs.TRANSACTION_NAME: The name of the transaction.
	 * - CommonDefs.CALLING_SYSTEM_ID: The ID of the calling system.
	 * - CommonDefs.ITEM_TYPE: The type of the item (e.g., HANDLE, PASSWORD, NICKNAME).
	 * - CommonDefs.ITEM: The item to be scanned.
	 * The method returns a HashMap representing the response from the system after scanning the words.
	 * The returned HashMap contains the following keys:
	 * - CErrorDefs.COMMON_APP_STATUS_CODE: The status code of the operation.
	 * - CErrorDefs.COMMON_APP_STATUS_INFO: Additional information about the operation.
	 *
	 * @param hmInput A HashMap containing the details of the words to be scanned.
	 * @return HashMap A HashMap representing the response from the system after scanning the words.
	 */
	public  HashMap scanWords(HashMap hmInput) {
		String thisMethod = "scanWords";
		Date tmsStart = new Date();
		HashMap hmResult = new HashMap();
		String stAppInfo = null;
		String stAppStatusCode = null;
		ArrayList alBadWordFiles = new ArrayList();

		//logger.info("SW01 : " + " CVS KEYWORDS:"
		//		+ info);

		try {
			logger.info(SpiMarker.getInstance(), "SW000 : "+
					"Input HashMap = " , StructuredArguments.entries(hmInput));

			//Retrieve transactionName, callingSystemId from hmInput hash
			String stTransactionName = (String) hmInput
					.get(CommonDefs.TRANSACTION_NAME);
			String stCallingSystemId = (String) hmInput
					.get(CommonDefs.CALLING_SYSTEM_ID);
			String stItemType = (String) hmInput.get(CommonDefs.ITEM_TYPE);
			String stItem = (String) hmInput.get(CommonDefs.ITEM);	

			if (stItemType == null || stItemType.trim().length() <= 0
					|| stItem == null || stItem.trim().length() <= 0) {
				stAppInfo = "itemType and item cannot be Null / Empty";
				logger.info("SW02 : "+ stAppInfo); 
				hmResult = CommonErrorMap.makeCategoryMap(
						CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			if (!stItemType.equals(CommonDefs.HANDLE)
					&& !stItemType.equals(CommonDefs.PASSWORD)
					&& !stItemType.equals(CommonDefs.NICKNAME)) {
				stAppInfo = "Scanlist not defined for the itemType passed in Input";
				logger.info("SW03 : "+ stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(
						CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			if (stItemType.equals(CommonDefs.HANDLE)) {
				String runenv = PropertyManager.getProperty(CommonDefs.MOUPConfig, CommonDefs.RILHRS_ENV);
				String strWord = stItem.toLowerCase();
				// June'2011 Changes to byPass qay check for ForeignId's
				String stIgnoreQay = (String) hmInput.get("ignoreQay");
				if (runenv != null
						&& runenv.trim().equalsIgnoreCase("TEST")
						&& (stIgnoreQay == null || !stIgnoreQay.trim().equals(
								MPSDefs.YES))) {
					if (!strWord.startsWith("qay")) {
						stAppInfo = stItemType
								+ " Validation Failed::"
								+ "In "
								+ runenv
								+ " Environment Word starting without qay are not allowed::"
								+ strWord;
						logger.info("SW03.5 : {}", StringEscapeUtils.escapeJava(stAppInfo));
						hmResult = CommonErrorMap.makeCategoryMap(
								CErrorDefs.ERR_BAD_PATTERN_NUM, stAppInfo);
						return hmResult;
					}
				}
			}

			if (stItemType.equals(CommonDefs.PASSWORD)) {
				//bypass the password validation for configured
				// callingSystemId.
				String stBypassPasswordValidationCSIDs = PropertyManager.getProperty(CommonDefs.MOUPConfig, "BWHelperBypassPasswordValidationCSIDs");
				//break the String into tokens using "|" as the delimiter
				ArrayList alBypassPasswordValidationCSIDs = CommonUtil
						.parseToArray(stBypassPasswordValidationCSIDs,
								CommonDefs.VALUE_SEPARATOR_CHAR);
				stAppInfo = "BypassPasswordValidationCSIDs List in property file :: "
						+ alBypassPasswordValidationCSIDs;
				logger.info("SW03.3 : {}", StringEscapeUtils.escapeJava(stAppInfo));
				if (alBypassPasswordValidationCSIDs != null
						&& (stCallingSystemId != null && alBypassPasswordValidationCSIDs
								.contains(stCallingSystemId))) {
					stAppInfo = "Password validation is Bypassed for callingSystemId :: "
							+ stCallingSystemId;
					logger.info("SW3.4 : {}", StringEscapeUtils.escapeJava(stAppInfo));
					hmResult = CommonErrorMap.makeCategoryMap(
							CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
					return hmResult;
				}
			}

			if (stItemType.equals(CommonDefs.NICKNAME)) {
				//bypass the nickname validation for configured callingSystemId.
				String stBypassNicknameValidationCSIDs = PropertyManager.getProperty(CommonDefs.MOUPConfig, "BWHelperBypassNicknameValidationCSIDs");
				//break the String into tokens using "|" as the delimiter
				ArrayList alBypassNicknameValidationCSIDs = CommonUtil
						.parseToArray(stBypassNicknameValidationCSIDs,
								CommonDefs.VALUE_SEPARATOR_CHAR);
				stAppInfo = "BypassNicknameValidationCSIDs List in property file :: "
						+ alBypassNicknameValidationCSIDs;
				logger.info("SW03.7 : {}", StringEscapeUtils.escapeJava(stAppInfo));
				if (alBypassNicknameValidationCSIDs != null
						&& (stCallingSystemId != null && alBypassNicknameValidationCSIDs
								.contains(stCallingSystemId))) {
					stAppInfo = "Nickname validation is Bypassed for callingSystemId :: "
							+ stCallingSystemId;
					logger.info("SW3.8 : {}", StringEscapeUtils.escapeJava(stAppInfo));
					hmResult = CommonErrorMap.makeCategoryMap(
							CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
					return hmResult;
				}
			}
			
			// June'2011 - Changes for SSO Phase2
			boolean bDomain = false;
			String stItemHandle = null;
			String stItemDomain = null;
			int i = -1;
			if (stItemType.equals(CommonDefs.HANDLE) && stItem.contains("@")) {
				int len = stItem.indexOf('@');
				if (len == 0) {
					stAppInfo = "item should not start with @ character";

					logger.info("SW3.82 : {}", StringEscapeUtils.escapeJava(stAppInfo));
					hmResult = CommonErrorMap.makeCategoryMap(
							CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
					return hmResult;
				}
				stItemHandle = stItem.substring(0, len);
				stItemDomain = stItem.substring(len + 1);

				if (stItem.length() > HANDLE_LENGTH_MAX_FOR_SLID) {
					stAppInfo = "ERROR ITEM TOO LONG :: For slid email formatted id";
					logger.info("SW3.84: {}", StringEscapeUtils.escapeJava(stAppInfo));
					hmResult = CommonErrorMap.makeCategoryMap(
							CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
					return hmResult;
				}
				// Set the email pattern
				//String stDefaultEmailRegEx = "^[\\w\\.-]+@([A-Za-z0-9\\-]+\\.)+[A-Za-z0-9]+$";
				String stDefaultEmailRegEx = "^[\\w\\+\\.-]+@([A-Za-z0-9\\-]+\\.)+[A-Za-z0-9]+$"; //1708 - Updated for PID 295582 - DFW Cloud DVR - allowing + too in slid names
				String stEmailRegEx = PropertyManager.getProperty(CommonDefs.MOUPConfig, "BWHelperHandleEmailRegEx");
				if (stEmailRegEx == null || stEmailRegEx.trim().length() == 0) {
					stEmailRegEx = stDefaultEmailRegEx;
				} else {
					stAppInfo = "DefaultEmailRegEx matched with property file BWHelperHandleEmailRegEx :: "
							+ stDefaultEmailRegEx.equals(stEmailRegEx);
					logger.info("SW3.86 : {}", StringEscapeUtils.escapeJava(stAppInfo));
				}
				Pattern p = Pattern.compile(stEmailRegEx);
				// Match the given string with the pattern
				Matcher m = p.matcher(stItem);
				// check whether match is found
				boolean bMatchFound = m.matches();
				if (!bMatchFound) {
					stAppInfo = "Input item is not valid::Pattern not matched for slid email formatted id";
					logger.info("SW3.85 : {}", StringEscapeUtils.escapeJava(stAppInfo));
					hmResult = CommonErrorMap.makeCategoryMap(
							CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
					//Aug'2011 - Added subCode for AddMember
					hmResult.put("subCode", CErrorDefs.ERR_INVALID_CHARS);
					return hmResult;
				}

				// replace item with handle part
				stItem = stItemHandle;
				bDomain = true;
			}
			do {
				i++;
				if (i > 0) {
					stItem = stItemDomain;
					stItemType = CommonDefs.DOMAIN;
					bDomain = false;
				}
				// Get the file list from config for itemType
				hmResult = getBadWordFileList(stItemType, logger);

				stAppInfo = "After calling getBadWordFileList() :: " + hmResult;

				logger.info("SW04 : {}", StringEscapeUtils.escapeJava(stAppInfo));

				stAppStatusCode = (String) hmResult
						.get(CErrorDefs.COMMON_APP_STATUS_CODE);

				if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					stAppInfo = "Error returned getBadWordFileList() method.";
					logger.info("SW05 : {}", StringEscapeUtils.escapeJava(stAppInfo));
					return hmResult;
				}

				alBadWordFiles = (ArrayList) hmResult.get("BadWordFileList");
				if (alBadWordFiles == null || alBadWordFiles.isEmpty()) {
					stAppInfo = "BadWordFileList is Empty in property file";
					logger.error("SW06 : {}", StringEscapeUtils.escapeJava(stAppInfo));
					hmResult = CommonErrorMap.makeCategoryMap(
							CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
					return hmResult;
				}
				hmResult.clear();
				hmResult = checkBadWord(stItem, stItemType, stCallingSystemId,
						alBadWordFiles, logger);
				stAppStatusCode = (String) hmResult
						.get(CErrorDefs.COMMON_APP_STATUS_CODE);

				if (!stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
					stAppInfo = "Error returned during bad word scan for itemType::"
							+ stItemType;
					logger.info("SW06.5 : {}", StringEscapeUtils.escapeJava(stAppInfo));
					return hmResult;
				}
			} while (bDomain);
			
			//1710 - 1704 Fortify Scan Report issue fixes - commented below return statement.
			//return hmResult;
		} catch (Exception exc) {

			stAppInfo = "Expection thrown from scanWords() method:: "
					+ exc.getMessage();
			logger.error("SW07 : {}", StringEscapeUtils.escapeJava(stAppInfo));
			hmResult = CommonErrorMap.makeExceptionMap(exc, logger);
			//1710 - 1704 Fortify Scan Report issue fixes - commented below return statement.
			//return hmResult;

		} finally {
			if (hmResult == null || hmResult.isEmpty()) {
				stAppInfo = "Null Response from scanWords() method";
				logger.error("SW08 : {}", StringEscapeUtils.escapeJava(stAppInfo));
				hmResult = CommonErrorMap.makeCategoryMap(
						CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				//1710 - 1704 Fortify Scan Report issue fixes - commented below return statement. 
				//return hmResult;
			}

			logger.info("SW09 : {}", StringEscapeUtils.escapeJava(tmsStart.getTime()  + " : " +
					hmResult));
		}
		//1710 - 1704 Fortify Scan Report issue fixes - Added below return statement.
		return hmResult;

	}

	private  HashMap checkBadWord(String stItem, String stItemType,
			String stCallingSystemId, ArrayList alBadWordFiles, Logger logger) {
		String methodName = "checkBadWord";
		String stAppInfo = null;
		String stAppStatusCode = null;
		HashMap hmResponse = null;

		ArrayList currentFileHiddenPattern = new ArrayList();
		ArrayList currentFileMiddle = new ArrayList();
		ArrayList currentFileStartOrWhole = new ArrayList();
		ArrayList currentFileWhole = new ArrayList();

		try {
			// Call the init() to initialize all global variables
			hmResponse = init(logger);

			stAppStatusCode = (String) hmResponse
					.get(CErrorDefs.COMMON_APP_STATUS_CODE);

			if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				stAppInfo = " Returned error from init() method";
				logger.info("CBW01 : {}", StringEscapeUtils.escapeJava(stAppInfo));
				return hmResponse;
			}

			for (int k = 0; k < alBadWordFiles.size(); k++) {
				String stBadWordFile = (String) alBadWordFiles.get(k);
				String strWord = stItem.toLowerCase();
				if (stItemType.equals(CommonDefs.PASSWORD)) {
					stAppInfo = "item=" + strWord + ", itemType=" + stItemType
							+ ", BadWordFile=" + stBadWordFile
							+ " getting scanned";
				} else {
					stAppInfo = "item: " + strWord + ", itemType: "
							+ stItemType + ", BadWordFile: " + stBadWordFile
							+ " getting scanned";
				}
				logger.info(SpiMarker.getInstance(), "CBW02 : {}", StringEscapeUtils.escapeJava(stAppInfo));
				if (stBadWordFile.equals("dirtyWords")) {
					currentFileHiddenPattern = dirtyWordsHiddenAL;
					currentFileMiddle = dirtyWordsMiddleAL;
					currentFileStartOrWhole = dirtyWordsStartOrWholeAL;
					currentFileWhole = dirtyWordsWholeAL;
				} else if (stBadWordFile.equals("corporateWords")) {
					currentFileHiddenPattern = corporateWordsHiddenAL;
					currentFileMiddle = corporateWordsMiddleAL;
					currentFileStartOrWhole = corporateWordsStartOrWholeAL;
					currentFileWhole = corporateWordsWholeAL;
				} else if (stBadWordFile.equals("commonWords")) {
					currentFileHiddenPattern = commonWordsHiddenAL;
					currentFileMiddle = commonWordsMiddleAL;
					currentFileStartOrWhole = commonWordsStartOrWholeAL;
					currentFileWhole = commonWordsWholeAL;
				}

				// WHOLE Pattern
				String tempWord = keepLettersAndDigits(strWord);
				
				//logger.info("CBW04.1 : currentFileWhole : "+ currentFileWhole);
				//logger.info("CBW04.2 : tempWord : "+ tempWord);
				
				if (Collections.binarySearch(currentFileWhole, tempWord) >= 0) {
					stAppInfo = stItemType+" Validation Failed::"+"Failed due to binary search :: "
							+ stBadWordFile + "_whole condition";
					logger.info("CBW04 : {}", StringEscapeUtils.escapeJava(stAppInfo));
					hmResponse = CommonErrorMap.makeCategoryMap(
							CErrorDefs.ERR_BAD_PATTERN_NUM, stAppInfo);
					return hmResponse;
				}

				if (stItemType.equals(CommonDefs.HANDLE)
						&& strWord.indexOf("..") != -1) {
					stAppInfo = stItemType+" Validation Failed::"+"Failed double dot condition";
					logger.info("CBW04a : {}", StringEscapeUtils.escapeJava(stAppInfo));
					hmResponse = CommonErrorMap.makeCategoryMap(
							CErrorDefs.ERR_BAD_PATTERN_NUM, stAppInfo);
					return hmResponse;
				}

				tempWord = keepLetters(strWord);
				// HIDDEN PATTERN
				if ((!tempWord.equals("")) || (tempWord.length() > 2)) {
					int iArrLen = currentFileHiddenPattern.size();
					for (int i = 0; i < iArrLen; i++) {
						if (tempWord.indexOf((String) currentFileHiddenPattern
								.get(i)) != -1) {
							stAppInfo = stItemType+" Validation Failed::"+"Failed due to index search ::"
									+ stBadWordFile
									+ "_hidden condition for BadWord ::"
									+ (String) currentFileHiddenPattern.get(i);
							logger.info("CBW05 : {}", StringEscapeUtils.escapeJava(stAppInfo));
							hmResponse = CommonErrorMap.makeCategoryMap(
									CErrorDefs.ERR_BAD_PATTERN_NUM, stAppInfo);
							return hmResponse;
						}
					}
				}

				//MIDDLE PATTERN
				if (Collections.binarySearch(currentFileMiddle, strWord) >= 0) {
					stAppInfo = stItemType+" Validation Failed::"+"Failed due to binary search ::"
							+ stBadWordFile + "_middle condition";
					logger.info("CBW06 : {}", StringEscapeUtils.escapeJava(stAppInfo));
					hmResponse = CommonErrorMap.makeCategoryMap(
							CErrorDefs.ERR_BAD_PATTERN_NUM, stAppInfo);
					return hmResponse;
				}
				int iArrLen = currentFileMiddle.size();
				for (int i = 0; i < iArrLen; i++) {
					if (strWord.indexOf((String) currentFileMiddle.get(i)) != -1) {
						stAppInfo = stItemType+" Validation Failed::"+"Failed due to index search ::"
								+ stBadWordFile
								+ "_middle condition for BadWord::"
								+ (String) currentFileMiddle.get(i);
						logger.info("CBW07 : {}", StringEscapeUtils.escapeJava(stAppInfo));
						hmResponse = CommonErrorMap.makeCategoryMap(
								CErrorDefs.ERR_BAD_PATTERN_NUM, stAppInfo);
						return hmResponse;
					}
				}
				
				//STARTORWHOLE PATTERN
				tempWord = stripDigits(strWord);
				stAppInfo = "After stripDigits() method tempWord created";
				logger.info("CBW08 : {}", StringEscapeUtils.escapeJava(stAppInfo));
				if ((!tempWord.equals("")) && (tempWord.length() > 2)) {
					if (Collections.binarySearch(currentFileStartOrWhole,
							tempWord) >= 0) {
						stAppInfo = stItemType+" Validation Failed::"+"Failed due to binary search:: "
								+ stBadWordFile + "_startOrWhole condition";
						logger.info("CBW09 : {}", StringEscapeUtils.escapeJava(stAppInfo));
						hmResponse = CommonErrorMap.makeCategoryMap(
								CErrorDefs.ERR_BAD_PATTERN_NUM, stAppInfo);
						return hmResponse;
					}
					int iIndex = 0;
					int badWordLength = 0;
					int tempWordLength = tempWord.length();
					String strBadWordFromConfig = null;

					iArrLen = currentFileStartOrWhole.size();

					for (int i = 0; i < iArrLen; i++) {
						strBadWordFromConfig = (String) currentFileStartOrWhole
								.get(i);
						if ((iIndex = tempWord.indexOf(strBadWordFromConfig)) != -1) {
							if (strWord.startsWith(strBadWordFromConfig)) {
								stAppInfo = stItemType + " Validation Failed::"
										+ "Failed due to startsWith search :: "
										+ stBadWordFile
										+ "_startOrWhole condition";
								logger.info("CBW10 : {}", StringEscapeUtils.escapeJava(stAppInfo));
								hmResponse = CommonErrorMap.makeCategoryMap(
										CErrorDefs.ERR_BAD_PATTERN_NUM,
										stAppInfo);
								return hmResponse;
							}
							badWordLength = strBadWordFromConfig.length();
							//either 'whole' or 'endWith' like => 'www' or
							// 'awww' with badword 'www'
							if ((iIndex + badWordLength) == tempWordLength) {
								if (iIndex != 0) // 'endWith'
									if (!(Character.isLetter(tempWord
											.charAt(iIndex - 1)))) {
										stAppInfo = stItemType
												+ " Validation Failed::"
												+ "Failed due to isLetter search :: "
												+ stBadWordFile
												+ "_startOrWhole condition in (iIndex !=0) condition";
										logger.info("CBW11 : {}", StringEscapeUtils.escapeJava(stAppInfo));
										hmResponse = CommonErrorMap
												.makeCategoryMap(
														CErrorDefs.ERR_BAD_PATTERN_NUM,
														stAppInfo);
										return hmResponse;
									}

							} else if (!(Character.isLetter(tempWord
									.charAt(iIndex + badWordLength)))) {
								stAppInfo = stItemType + " Validation Failed::"
										+ "Failed due to isLetter search :: "
										+ stBadWordFile
										+ "_startOrWhole condition";
								logger.info("CBW12 : {}", StringEscapeUtils.escapeJava(stAppInfo));
								hmResponse = CommonErrorMap.makeCategoryMap(
										CErrorDefs.ERR_BAD_PATTERN_NUM,
										stAppInfo);
								return hmResponse;
							}
						}
					}
				}
				//Dec 2011 - Added for comboWord conditions
				if (stBadWordFile.equals("comboWords")) {
					tempWord = keepLetters(strWord);
					for (int j = 0; j < comboWordsAL.size(); j++) {
						ArrayList alComboWords = (ArrayList) comboWordsAL
								.get(j);
						if (alComboWords != null && !alComboWords.isEmpty()) {
							boolean isComboWordFound = false;
							for (int l = 0; l < alComboWords.size(); l++) {
								String stComboWord = (String) alComboWords
										.get(l);

								if (stComboWord != null
										&& (tempWord != null && tempWord
												.indexOf(stComboWord) != -1)) {
									isComboWordFound = true;
								} else {
									isComboWordFound = false;
									break;
								}
							}
							if (isComboWordFound) {
								stAppInfo = stItemType + " Validation Failed::"
										+ "Failed due to index search ::"
										+ stBadWordFile
										+ " condition for BadWord ::"
										+ alComboWords;
								logger.info("CBW12.5 : {}", StringEscapeUtils.escapeJava(stAppInfo));
								hmResponse = CommonErrorMap.makeCategoryMap(
										CErrorDefs.ERR_BAD_PATTERN_NUM,
										stAppInfo);
								return hmResponse;
							}
						}

					}
				}
			}
			
			//DEC2012 Updated for TVGAMES callingSystemId
			if (stCallingSystemId != null
					&& stCallingSystemId.trim().equalsIgnoreCase("TVGAMES")
					&& stItemType.equals(CommonDefs.HANDLE)
					&& tvgamesWordsMiddleAL != null) {
				String strWord = stItem.toLowerCase();
				stAppInfo = "item: " + strWord + ", itemType: " + stItemType
						+ ", BadWordFile: tvgamesWords_middle getting scanned";
				logger.info("CBW014.5 : {}", StringEscapeUtils.escapeJava(stAppInfo));
				// MIDDLE PATTERN Validation
				if (Collections.binarySearch(tvgamesWordsMiddleAL, strWord) >= 0) {
					stAppInfo = stItemType
							+ " Validation Failed::"
							+ "Failed due to binary search ::tvgamesWords_middle condition";
					logger.info("CBW15 : {}", StringEscapeUtils.escapeJava(stAppInfo));
					hmResponse = CommonErrorMap.makeCategoryMap(
							CErrorDefs.ERR_BAD_PATTERN_NUM, stAppInfo);
					return hmResponse;
				}
				int iArrLen = tvgamesWordsMiddleAL.size();
				for (int i = 0; i < iArrLen; i++) {
					if (strWord.indexOf((String) tvgamesWordsMiddleAL.get(i)) != -1) {
						stAppInfo = stItemType
								+ " Validation Failed::"
								+ "Failed due to index search ::tvgamesWords_middle condition for BadWord ::"
								+ (String) tvgamesWordsMiddleAL.get(i);
						logger.info("CBW16 : {}", StringEscapeUtils.escapeJava(stAppInfo));
						hmResponse = CommonErrorMap.makeCategoryMap(
								CErrorDefs.ERR_BAD_PATTERN_NUM, stAppInfo);
						return hmResponse;
					}
				}

			}
			hmResponse = CommonErrorMap.makeCategoryMap(
					CErrorDefs.COMMON_SUCCESS_NUM, "");
			return hmResponse;
		} catch (Exception ex) {
			stAppInfo = "Exception Thrown from checkBadWord() method "
					+ ex.getMessage();
			logger.error("CBW13 : "+ stAppInfo);
			hmResponse = CommonErrorMap.makeExceptionMap(ex, logger);
			return hmResponse;
		}
	}

	// Removes all characters except alphas
	private  String keepLetters(String givenWord) {
		//1804 : Fixing SONAR violations
		//StringBuffer strBuff = new StringBuffer();
		StringBuilder strBuff = new StringBuilder();

		for (int i = 0; i < givenWord.length(); i++) {
			char c = givenWord.charAt(i);
			if (Character.isLetter(c)) {
				strBuff.append(c);
			}
		}
		return strBuff.toString();
	}
	
	// Removes all characters except alphas and numeric
	private  String keepLettersAndDigits(String givenWord) {
		//1804 : Fixing SONAR violations
		//StringBuffer strBuff = new StringBuffer();
		StringBuilder strBuff = new StringBuilder();

		for (int i = 0; i < givenWord.length(); i++) {
			char c = givenWord.charAt(i);
			if (Character.isLetterOrDigit(c)) {
				strBuff.append(c);
			}
		}
		return strBuff.toString();
	}

	//Removes all digits except alphas
	private  String stripDigits(String givenWord) {
		//1804 : Fixing SONAR violations
		//StringBuffer strBuff = new StringBuffer();
		StringBuilder strBuff = new StringBuilder();

		for (int i = 0; i < givenWord.length(); i++) {
			char c = givenWord.charAt(i);
			if (!(Character.isDigit(c))) {
				strBuff.append(c);
			}
		}
		return strBuff.toString();
	}

	private  HashMap getBadWordFileList(String stItemType, Logger logger) {
		String thisMethod = "getBadWordFileList";
		String stAppInfo = null;
		HashMap hmResponse = new HashMap();

		try{
			//Retrieve the Bad Word files list from property for the itemType
	
			String stBadWordFiles = PropertyManager.getProperty(CommonDefs.MOUPConfig, "RILHRS_" + stItemType
					+ "Validation");
			if (stBadWordFiles == null || stBadWordFiles.trim().length() == 0) {
				stAppInfo = "Missing config parameter:: " + stItemType
						+ "Validation";
				logger.error("GBWF01 : {}", StringEscapeUtils.escapeJava(stAppInfo));
				hmResponse = CommonErrorMap.makeCategoryMap(
						CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
				return hmResponse;
			}
	
			//break the String into tokens using "|" as the delimiter
			ArrayList alBadWordFiles = CommonUtil.parseToArray(stBadWordFiles,
					CommonDefs.VALUE_SEPARATOR_CHAR);
	
			stAppInfo = "Bad Word Files List in property file :: " + alBadWordFiles;
			logger.info("GBWF02 : {}", StringEscapeUtils.escapeJava(stAppInfo));
	
			hmResponse = CommonErrorMap.makeCategoryMap(
					CErrorDefs.COMMON_SUCCESS_NUM, "Success");
			hmResponse.put("BadWordFileList", alBadWordFiles);
		}catch (Exception exc) {

			stAppInfo = "Expection thrown from scanWords() method:: "
					+ exc.getMessage();
			logger.error("GBWF02a : "+ stAppInfo);
			hmResponse = CommonErrorMap.makeExceptionMap(exc, logger);
		}
		
		return hmResponse;

	}

	private  void clearAndInitialize() {
		if (dirtyWordsHiddenAL != null) {
			dirtyWordsHiddenAL.clear();
			dirtyWordsHiddenAL = null;
		}

		if (dirtyWordsMiddleAL != null) {
			dirtyWordsMiddleAL.clear();
			dirtyWordsMiddleAL = null;
		}

		if (dirtyWordsStartOrWholeAL != null) {
			dirtyWordsStartOrWholeAL.clear();
			dirtyWordsStartOrWholeAL = null;
		}

		if (dirtyWordsWholeAL != null) {
			dirtyWordsWholeAL.clear();
			dirtyWordsWholeAL = null;
		}

		if (corporateWordsHiddenAL != null) {
			corporateWordsHiddenAL.clear();
			corporateWordsHiddenAL = null;
		}

		if (corporateWordsMiddleAL != null) {
			corporateWordsMiddleAL.clear();
			corporateWordsMiddleAL = null;
		}

		if (corporateWordsStartOrWholeAL != null) {
			corporateWordsStartOrWholeAL.clear();
			corporateWordsStartOrWholeAL = null;
		}

		if (corporateWordsWholeAL != null) {
			corporateWordsWholeAL.clear();
			corporateWordsWholeAL = null;
		}

		if (commonWordsHiddenAL != null) {
			commonWordsHiddenAL.clear();
			commonWordsHiddenAL = null;
		}

		if (commonWordsMiddleAL != null) {
			commonWordsMiddleAL.clear();
			commonWordsMiddleAL = null;
		}

		if (commonWordsStartOrWholeAL != null) {
			commonWordsStartOrWholeAL.clear();
			commonWordsStartOrWholeAL = null;
		}

		if (commonWordsWholeAL != null) {
			commonWordsWholeAL.clear();
			commonWordsWholeAL = null;
		}
		
		if (comboWordsAL != null) {
			comboWordsAL.clear();
			comboWordsAL = null;
		}
		
		if(hmfileLastLastModified != null){
			hmfileLastLastModified.clear();
			hmfileLastLastModified = null;
		}

		lasttime = 0;

	}

}