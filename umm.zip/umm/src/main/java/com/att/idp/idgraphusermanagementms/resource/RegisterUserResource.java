package com.att.idp.idgraphusermanagementms.resource;

import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.web.bind.annotation.RequestBody;

import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.resource.request.RegisterEmailUserRequest;
import com.att.idp.idgraphusermanagementms.resource.request.TransactionRateLimitRequest;
import com.att.idp.idgraphusermanagementms.resource.response.RegisterEmailUserResponse;
import com.att.idp.idgraphusermanagementms.resource.response.TransactionRateLimitResponse;

import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * This is an interface named RegisterUserResource.
 * It is annotated with @Tag(name = "register") to provide metadata for Swagger.
 * It is also annotated with @Path("/register") to set the path for the entire interface.
 * The interface is also annotated with @Produces({ MediaType.APPLICATION_JSON }) to specify that the methods in this interface produce JSON responses.
 * The interface contains two methods, txnRateLimitStatus and registerEmailUser, each annotated with @POST, @Path, @Consumes, @Produces, @ApiOperation, @ApiResponses, and @ApiImplicitParams.
 * These methods are designed to handle POST requests for transaction rate limit status verification and email user registration.
 */
@Tag(name = "register")
@Path("/register")
@Produces({ MediaType.APPLICATION_JSON })
public interface RegisterUserResource {
	
	
	/**
	 * This method is part of the RegisterUserResource interface.
	 * It is responsible for verifying the transaction rate limit status.
	 * The method is annotated with @POST to indicate that it handles HTTP POST requests.
	 * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
	 * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
	 * The method takes a TransactionRateLimitRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
	 * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
	 * The method throws an MPSException if any error occurs during the operation.
	 * The method returns a Response object which encapsulates the result of the transaction rate limit status verification operation.
	 *
	 * @param request The TransactionRateLimitRequest containing the details of the transaction rate limit status verification operation.
	 * @param httpHeader The HttpHeaders providing HTTP header information.
	 * @return Response The response of the transaction rate limit status verification operation.
	 * @throws MPSException If any error occurs during the operation.
	 */
	@POST
	@Path("/txnratelimit/verify")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "txnRateLimitStatus", description =  "This operation will limit transactions based on IP address",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = TransactionRateLimitResponse.class))),
			@ApiResponse(responseCode = "400", description =  "Bad Request"),
			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	public Response txnRateLimitStatus(@Valid @RequestBody TransactionRateLimitRequest request,
			@Context HttpHeaders httpHeader) throws MPSException;
	
	/**
	 * This method is part of the RegisterUserResource interface.
	 * It is responsible for registering a new email user.
	 * The method is annotated with @POST to indicate that it handles HTTP POST requests.
	 * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
	 * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
	 * The method takes a RegisterEmailUserRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
	 * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
	 * The method throws an MPSException if any error occurs during the operation.
	 * The method returns a Response object which encapsulates the result of the email user registration operation.
	 *
	 * @param request The RegisterEmailUserRequest containing the details of the email user registration operation.
	 * @param httpHeader The HttpHeaders providing HTTP header information.
	 * @return Response The response of the email user registration operation.
	 * @throws MPSException If any error occurs during the operation.
	 */
	@POST
	@Path("/emailuser")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "registerEmailUser", description =  "This operation creates a new OPR user",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = RegisterEmailUserResponse.class))),
			@ApiResponse(responseCode = "400", description =  "Bad Request"),
			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	public Response registerEmailUser(@Valid @RequestBody RegisterEmailUserRequest request,
			@Context HttpHeaders httpHeader) throws MPSException;

}
