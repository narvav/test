package com.att.idp.idgraphusermanagementms.service.impl;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.LinkMemberHelper;
import com.att.idp.idgraphusermanagementms.resource.request.LinkMemberRequest;
import com.att.idp.idgraphusermanagementms.resource.response.LinkMemberResponse;
import com.att.idp.idgraphusermanagementms.service.LinkMemberService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import net.logstash.logback.argument.StructuredArguments;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.ws.rs.core.MultivaluedMap;
import java.util.Map;

@Service
public class LinkMemberServiceImpl implements LinkMemberService {
	
	public static final Logger logger = LoggerFactory.getLogger(LinkMemberServiceImpl.class);

	private static String sClassName = "LinkMemberServiceImpl";
	
	@Autowired
	private LinkMemberHelper linkMemberHelper;

	@Override
	public LinkMemberResponse linkMember(LinkMemberRequest linkMemberRequest,
										 MultivaluedMap<String, String> requestHeader) {
		
		Map<String, Object> hmResponse = null;
		String sMethodName = ".linkMember.";
		
		Map<String, Object> hmInput = CommonUtilHelper.objectToMap(linkMemberRequest);
		
		String idpTraceid = (String) hmInput.get(ProfileOrchestrationConstants.IDPTRACEID);
		hmInput.put(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID, idpTraceid.split(":")[0]);
		hmInput.put(CommonDefs.HANDLE, hmInput.remove(CommonDefs.USER_ID));
		
		logger.info(SpiMarker.getInstance(),
				"LinkMemberServiceImpl.linkMember.LMS_01 : Calling LinkMemberHelper with Input : {}",
				StructuredArguments.entries(hmInput));

		hmResponse = linkMemberHelper.linkMember(hmInput);

		hmResponse=CommonUtilHelper.processHmResponse(hmResponse, hmInput, "LinkMemberHelper", ".linkMember");
		hmResponse.put(ProfileOrchestrationConstants.IDP_TRACE_ID, linkMemberRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME, ProfileOrchestrationConstants.LINK_MEMBER_TRANSACTION_NAME);
		LinkMemberResponse linkMemberResponse = CommonUtilHelper.generateLinkMemberResponse(hmResponse);

		logger.info("{}{}LMS_05 : Response from LinkMemberServiceImpl.linkMember : {}", sClassName, sMethodName,
				linkMemberResponse);
		return linkMemberResponse;
	}

}
