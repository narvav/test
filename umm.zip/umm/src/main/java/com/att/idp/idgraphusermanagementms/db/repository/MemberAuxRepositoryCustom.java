package com.att.idp.idgraphusermanagementms.db.repository;

import java.sql.SQLException;

import com.att.idp.idgraphusermanagementms.db.request.MemberRequest;

/**
 * This is the custom repository interface for the MemberAux entity.
 * It provides custom data access operations that are not provided by the standard JpaRepository.
 */
public interface MemberAuxRepositoryCustom {
	
	/**
	 * This method is used to add a new MemberAux entity to the database.
	 *
	 * @param memberRequest The request object containing the details of the MemberAux entity to be added.
	 * @return The number of rows affected in the database. If the operation is successful, this should be 1.
	 * @throws SQLException If there is an error while executing the SQL query.
	 */
	public int addMemberAux(MemberRequest memberRequest) throws SQLException;

}
