package com.att.idp.idgraphusermanagementms.service;

import jakarta.ws.rs.core.MultivaluedMap;

import com.att.idp.idgraphusermanagementms.resource.request.UnlinkMemberIdRequest;
import com.att.idp.idgraphusermanagementms.resource.response.CommonResponse;

/**
 * This interface defines the contract for the UnlinkMemberIdService in the system.
 * It contains a single method unlinkMemberId which takes an UnlinkMemberIdRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return a CommonResponse object.
 *
 * The UnlinkMemberIdRequest object encapsulates the details of the member ID unlink operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
public interface UnlinkMemberIdService {

	/**
	 * This method is part of the UnlinkMemberIdService interface.
	 * It defines the contract for unlinking a member ID in the system.
	 *
	 * @param unlinkMemberIdRequest An object encapsulating the details of the member ID unlink operation to be performed.
	 * @param requestHeader A MultivaluedMap containing the request headers which may include additional information required for processing the request.
	 * @return A CommonResponse object representing the response from the system after unlinking the member ID.
	 */
	CommonResponse unlinkMemberId(UnlinkMemberIdRequest unlinkMemberIdRequest, MultivaluedMap<String, String> requestHeader);

}
