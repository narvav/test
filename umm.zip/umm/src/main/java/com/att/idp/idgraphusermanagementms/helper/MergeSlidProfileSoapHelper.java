package com.att.idp.idgraphusermanagementms.helper;

import com.att.idp.idgraphusermanagementms.client.MPSMergeSLIDProfileSoapHandler;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.ril.mpsys.mergeslidprofilerequest.v1.MergeSLIDProfileRequest;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class MergeSlidProfileSoapHelper {

    public static final Logger logger = LoggerFactory.getLogger(MergeSlidProfileSoapHelper.class);

    private final String sClassName = "MergeSlidProfileSoapHelper";

    @Autowired
    public MPSMergeSLIDProfileSoapHandler<MergeSLIDProfileRequest> mpsMergeUserSoapHandler;

    public Map<String, Object> mergeSLIDProfileSoapCall(MergeSLIDProfileRequest mergeSLIDProfileRequest) {
        String sMethodName = ".mergeSLIDProfileSoapCall.";
        Map<String, Object> hmResult = null;
        String stAppInfo = null;
        logger.info("{}{}HLP000 : Input request: {}", sClassName, sMethodName,
                StringUtils.normalizeSpace(mergeSLIDProfileRequest.toString()));
        try {
            logger.debug("{}{}MSPH_01  Calling SoapHelper with input: {}",
                    sClassName, sMethodName, mergeSLIDProfileRequest);
            hmResult = mpsMergeUserSoapHandler.invokeAPI(mergeSLIDProfileRequest);
            logger.info("{}{}MSPH_02 Response from SoapHelper.callRILSoap() : {} ", sClassName, sMethodName, hmResult);
        } catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e, logger);
            stAppInfo = "Exception thrown mergeSLIDProfileSoapCall method : " + hmResult;
            logger.error("{}{}MSPH_03 : {}", sClassName, sMethodName, stAppInfo);
        } finally {
            if (hmResult == null || hmResult.isEmpty()) {
                stAppInfo = "Response from MergeSLIDProfileRILMPS is NULL";
                logger.debug("{}{}MSPH_04 : {}", sClassName, sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
            }
            logger.info("{}{}HLP999 : response from MergeSlidProfileSoapHelper{}", sClassName, sMethodName, hmResult);
        }
        return hmResult;
    }

    public Map<String, Object> callMergeSlidProfileSoapHelper(Map<String, Object> hmInput) {
        String sMethodName = ".callMergeSlidProfileSoapHelper.";
        String agentId="agentId";
        String stCallingSystemId = hmInput.get("callingSystemId").toString();
        String stTransactionId = hmInput.get("idpTraceId").toString().split(":")[0];

        MergeSLIDProfileRequest mergeSLIDProfileRequest = new MergeSLIDProfileRequest();
        mergeSLIDProfileRequest.setCallingSystemId(stCallingSystemId);
        mergeSLIDProfileRequest.setTransactionId(stTransactionId);
        mergeSLIDProfileRequest.setTransactionName("MergeSLIDProfile");
        mergeSLIDProfileRequest.setFromSLID(hmInput.get("fromUserName").toString());
        mergeSLIDProfileRequest.setToSLID(hmInput.get("toUserName").toString());

        if(hmInput.get(agentId)!=null && !hmInput.get(agentId).toString().isEmpty())
                mergeSLIDProfileRequest.setAgentId(hmInput.get(agentId).toString());

        logger.info("{}{}CMSPH_001 : Calling MergeSlidProfileSoapHelper : {}", sClassName, sMethodName,
                mergeSLIDProfileRequest);

        Map<String, Object> hmResponse =  mergeSLIDProfileSoapCall(mergeSLIDProfileRequest);
        logger.info("{}{}CMSPH_002 : Response from MergeSlidProfileSoapHelper.mergeSLIDProfileSoapCall(): {}", sClassName,
                sMethodName, hmResponse);
        if (hmResponse == null || hmResponse.isEmpty()) {
            String stAppInfo = "Null Response from MergeSlidProfileSoapHelper.mergeSLIDProfileSoapCall()";
            HashMap hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
            logger.info("{}{}CMSPH_003 : {}", sClassName, sMethodName, stAppInfo);
            return hmResult;
        }

        String stAppInfo;
        if(hmResponse.containsKey("appInfo") && hmResponse.get("appInfo") != null) {
             stAppInfo = hmResponse.get("appInfo").toString();
        } else {
            stAppInfo = "No appInfo found in response";
        }
        if (stAppInfo != null && !stAppInfo.isEmpty()) 
                stAppInfo = stAppInfo.replaceAll("(?i)toSLID", "toUserName").replaceAll("(?i)fromSLID", "fromUserName");
        
        hmResponse.put("appInfo", stAppInfo);

        return hmResponse;
    }
}
