package com.att.idp.idgraphusermanagementms.db.repository;

import java.sql.SQLException;
import java.util.HashMap;

/**
 * This is the custom repository interface for the MemberGroup entity.
 * It provides custom data access operations that are not provided by the standard JpaRepository.
 */
public interface MemberGroupRepositoryCustom {

	/**
	 * This method is used to add a new MemberGroup entity to the database.
	 *
	 * @param inpParamHash The HashMap containing the details of the MemberGroup entity to be added.
	 * @return A HashMap containing the result of the operation. The keys and values of this HashMap depend on the implementation of this method.
	 * @throws SQLException If there is an error while executing the SQL query.
	 */
	public HashMap addMemberGrp(HashMap inpParamHash) throws SQLException;
	
}
