package com.att.idp.idgraphusermanagementms.db.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * This is the NetworkAccessResponse class which implements Serializable interface.
 * It represents a response for a network access with properties like accessId, accessName, and accessDesc.
 * Each property has its respective getter and setter methods.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({

})
public class NetworkAccessResponse implements Serializable{

	private static final long serialVersionUID = 1905041013210369575L;

	private Long accessId;
	private String accessName;
	private String accessDesc;
}