package com.att.idp.idgraphusermanagementms.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The DateUtil class is a utility class that provides methods for date manipulation.
 * It is part of the com.att.idp.idgraphusermanagementms.utils package.
 * The class contains a Logger object for logging purposes and a DateFormat object for date formatting.
 * The DateFormat object is initialized with the "MM/dd/yyyy" pattern.
 * The class provides a method stringToSqlDate which converts a string representation of a date to a java.sql.Date object.
 * The stringToSqlDate method takes a string as a parameter, which should represent a date in the "MM/dd/yyyy" format.
 * The method attempts to parse the string into a java.util.Date object using the DateFormat object.
 * If the parsing is successful, the method converts the java.util.Date object to a java.sql.Date object and returns it.
 * If the parsing fails, the method logs an error message and returns null.
 */
public class DateUtil {

	private static Logger logger = LoggerFactory.getLogger(DateUtil.class);
	public static final String DATE_FORMAT = "MMddyyyy HH:mm:ss";
	private static final DateFormat GLOBAL_DATE_PATTERN_MMDDYYYY = new SimpleDateFormat("MM/dd/yyyy");
	
	/**
	 * This method is part of the DateUtil class.
	 * It is a utility method that converts a string representation of a date to a java.sql.Date object.
	 * The method takes a string as a parameter, which should represent a date in the "MM/dd/yyyy" format.
	 * The method attempts to parse the string into a java.util.Date object using the DateFormat object.
	 * If the parsing is successful, the method converts the java.util.Date object to a java.sql.Date object and returns it.
	 * If the parsing fails, the method logs an error message and returns null.
	 *
	 * @param dateString A string representing a date in the "MM/dd/yyyy" format.
	 * @return java.sql.Date A java.sql.Date object representing the parsed date, or null if the parsing fails.
	 */
	public static java.sql.Date stringToSqlDate(String dateString) {

		java.util.Date parsed = null;
		java.sql.Date sqlDate = null;

		try {
			parsed = GLOBAL_DATE_PATTERN_MMDDYYYY.parse(dateString);
			sqlDate = new java.sql.Date(parsed.getTime());
		} catch (ParseException ex) {
			logger.error("Error while parsing date string :" + ex.getMessage());
		}
		return sqlDate;
	}
}
