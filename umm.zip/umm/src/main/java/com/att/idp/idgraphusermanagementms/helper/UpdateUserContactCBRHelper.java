package com.att.idp.idgraphusermanagementms.helper;

import com.att.idp.cgclienthelpers.integration.CGRestClient;
import com.att.idp.cgclienthelpers.utils.CommonConstants;
import com.att.idp.idgraphusermanagementms.db.helper.ContactDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.DBHelper;
import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.resource.response.InquireProfileResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.InquireProfileUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.JsonService;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.mpsys.common.utils.*;
import com.fasterxml.jackson.databind.node.ArrayNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.io.IOException;
import java.util.*;

/**
 * This class is a helper class for updating user contact information in the CBR system.
 * It contains methods for validating input, retrieving user information, and updating the user's contact information in the database.
 * It uses various other helper classes and services such as ContactDBHelper, DBHelper, CGRestClient, and InquireProfileHelper.
 * It also uses various constants and utility methods from the CommonDefs, MPSDefs, and CommonUtil classes.
 * The main method in this class is the updateUserContactCBR method, which takes a HashMap of input parameters and returns a HashMap with the result of the operation.
 *
 */
@Component
public class UpdateUserContactCBRHelper {
    public static final Logger logger = LoggerFactory.getLogger(UpdateUserContactCBRHelper.class);
    private static final String sClassName = "UpdateUserContactCBRHelper";

    @Autowired
    private ContactDBHelper contactDBHelper;

    @Autowired
    private DBHelper oDBHelper;

    @Autowired
    private CGRestClient cgRestClient;

    @Autowired
    private InquireProfileHelper inquireProfileHelper;

    @Value("${apiclient.rest.cg.endpoint}")
    private String cgEndpoint;

    /**
     * This method is responsible for updating the user's contact information in the CBR system.
     * It first validates the input parameters and retrieves the user's current contact information from the database.
     * If the user's contact information needs to be updated, it prepares the necessary data and calls the ContactDBHelper's updateUserContact method to update the contact information.
     * If the updateUserContact method returns an error, it is returned to the caller.
     * If the updateUserContact method is successful, the method returns a success message.
     *
     * @param hmInput A HashMap containing the input parameters for the method. It should include necessary information such as user ID, new contact information, transaction ID, transaction name, calling system ID, and other user details to be updated.
     * @return A HashMap containing the result of the method. It includes the application status code and other information.
     * @throws MPSException If there is an error during the operation.
     */
    public Map<String, Object> updateUserContactCBR(Map<String, Object> hmInput) throws MPSException {
        String sMethodName = ".updateUserContactCBR.";
        Map<String, Object> hmResult = null;
        String stAppInfo = null;
        String stAppStatusCode = null;

        logger.info("{}{}HLP000 : Input Hash :  {}", sClassName, sMethodName, hmInput);

        HashMap<String, Object> hmInqProfileInp = CommonUtil.getHashMap();

        String sHandle = (String) hmInput.get(CommonDefs.HANDLE);
        String sDomain = (String) hmInput.get(CommonDefs.DOMAIN);
        String sGuid = (String) hmInput.get(CommonDefs.GUID);
        String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
        String sContactType = (String) hmInput.get(CommonDefs.CONTACT_TYPE);
        String sPhoneNumber = (String) hmInput.get(CommonDefs.PHONE_NUMBER);
        String sPhoneNumberType = (String) hmInput.get(CommonDefs.PHONE_NUMBER_TYPE);
        String sSubscriptionId = (String) hmInput.get(CommonDefs.SUBSCRIPTION_ID);
        String sPhoneNumberExt = (String) hmInput.get(CommonDefs.PHONE_NUMBER_EXT);
        String sValidationStatus = (String) hmInput.get(CommonDefs.VALIDATION_STATUS);
        String sContactStatus = (String) hmInput.get(CommonDefs.CONTACT_STATUS);

        if (sHandle != null && !sHandle.isEmpty() && sDomain != null && !sDomain.isEmpty()) {
            sGuid = "";
        } else {
            sHandle = "";
            sDomain = "";
        }
        hmInqProfileInp.put(CommonDefs.TRANSACTION_NAME, "InquireProfile");
        //hmInqProfileInp.put(CommonDefs.TRANSACTION_ID, updateUserContactCBRRequest.getIdpTraceId().split(":")[0]);
        hmInqProfileInp.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
        hmInqProfileInp.put(CommonDefs.LEVEL, "M");
        hmInqProfileInp.put("isExternalCall", CommonDefs.IND_N);

        if (sGuid == null || sGuid.isEmpty()) {
            hmInqProfileInp.put(CommonDefs.HANDLE, sHandle);
            hmInqProfileInp.put(CommonDefs.DOMAIN, sDomain);
        } else {
            hmInqProfileInp.put(CommonDefs.GUID, sGuid);
        }

        HashMap<String, Object> hmInqProfileResp = null;
        InquireProfileResponse inquireProfileResponse = null;
        hmInqProfileResp = (HashMap<String, Object>)inquireProfileHelper.inquireProfile(hmInqProfileInp);

        stAppStatusCode = (String) hmInqProfileResp.get(CommonDefs.COMMON_APP_STATUS_CODE);

        if (stAppStatusCode != null && !stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
            if (stAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND)
                    || stAppStatusCode.equals(CErrorDefs.ERR_USER_NOT_FOUND)) {
                stAppInfo = "Input guid or userId/domain not found";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
                logger.error("{}{}UUCH_01 InquireProfileHelper.inquireProfile: {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            } else {
                hmResult = hmInqProfileResp;
                logger.error("{}{}UUCH_02 InquireProfileHelper.inquireProfile: {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }
        }
        inquireProfileResponse = InquireProfileUtilHelper.generateInquireProfileResponse(hmInqProfileResp);
        if (inquireProfileResponse != null) {
            hmInqProfileResp = (HashMap<String, Object>) CommonUtilHelper.objectToMap(inquireProfileResponse);
            logger.info("{}{}UUCH_03 InquireProfileHelper.inquireProfile: {}", sClassName, sMethodName, inquireProfileResponse);
        } else {
            stAppInfo = "Null Response returned from InquireProfileHelper.inquireProfile";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
            logger.error("{}{}UUCH_04 InquireProfileHelper.inquireProfile: {}", sClassName, sMethodName, stAppInfo);
            return hmResult;
        }


        HashMap hmDBMember = (HashMap) hmInqProfileResp.get("member");

        if (hmDBMember != null && !hmDBMember.isEmpty()) {
            sGuid = (String) hmDBMember.get(CommonDefs.MEMBER_NUM);
        }
        if (sContactType !=null && sContactType.equalsIgnoreCase("SMS")) {
            if (sPhoneNumberType !=null && sPhoneNumberType.equals(CommonDefs.PHONE_NUMBER_TYPE_ATTMOBILE)) {
                if (sSubscriptionId == null || sSubscriptionId.isEmpty()) {
                    String stTopicName = null;
                    HashMap<String, Object> hmCGInput = new HashMap<String, Object>();
                    hmCGInput.put(CommonDefs.SUBSCRIBER_NUMBER, sPhoneNumber);
                    hmCGInput.put(CommonDefs.SERVICE_TYPE, "wireless");
                    hmCGInput.put(CommonConstants.CG_API_NAME, CommonConstants.CG_CUSTOMER_SEARCH_API_NAME);
                    hmCGInput.put(CommonConstants.CG_END_POINT, cgEndpoint);
                    stTopicName = ProfileOrchestrationConstants.ACCOUNTS + "," + ProfileOrchestrationConstants.SUBSCRIBERS + ",equipments";
                    hmCGInput.put("topics", stTopicName);

                    logger.debug("{}{}UUCH_4.1 : Calling CGRestClient.getCGSyncCall() with hmCGInput : {}",
                            sClassName, sMethodName, hmCGInput);

                    Map<String, Object> hmCGResponse = null;
                    try {
                        hmCGResponse = cgRestClient.getCGSyncCall(hmCGInput);
                        logger.info("{}{}UUCH_4.2 : Response from CGRestClient.getCGSyncCall() hmCGResponse : {}",
                                sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmCGResponse)));

                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }

                    if (hmCGResponse == null || hmCGResponse.isEmpty()) {
                        stAppInfo = "Null Response returned from CGRestClient.getCGSyncCall()";
                        hmCGResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                        logger.info("{}{}UUCH_05 : {} {}", sClassName, sMethodName, stAppInfo, HtmlUtils.htmlEscape(String.valueOf(hmCGResponse)));
                        return hmCGResponse;
                    }

                    if (!(CommonDefs.COMMON_SUCCESS.equals((String) hmCGResponse.get(MPSDefs.APP_STATUS_CODE)))) {
                        logger.info(
                                "{}{}UUCH_06 : Error returned from CGRestClient.callCG() hmCGResponse : {}",
                                sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmCGResponse)));
                        return hmCGResponse;
                    }
                    ArrayList alSubscribers = JsonService.convertToObject(((ArrayNode) hmCGResponse.get("subscribers")).get(0),ArrayList.class);
                    if (alSubscribers != null && !alSubscribers.isEmpty()) {
                        for (int k = 0; k < alSubscribers.size(); k++) {
                            HashMap hmSubscriberDetails = (HashMap) alSubscribers.get(k);
                            if (hmSubscriberDetails != null && !hmSubscriberDetails.isEmpty()) {
                                sSubscriptionId = ((String) hmSubscriberDetails.get(CommonDefs.SUBSCRIPTION_ID));
                            }
                        }
                    }

                }
            } else if (sPhoneNumberType !=null && sPhoneNumberType.equals(CommonDefs.PHONE_NUMBER_TYPE_MOBILE)) {
                sSubscriptionId = "";
            }
        } else {
            stAppInfo = "Not currently supported contactType";
            logger.info("{}{}UUCH_07 : {}", sClassName, sMethodName, stAppInfo);
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
            return hmResult;
        }

        HashMap<String, Object> hmContactData = CommonUtil.getHashMap();

        hmContactData.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
        hmContactData.put("subscription_id", sSubscriptionId);
        hmContactData.put(MPSDefs.DB_MEMBER_NUM, sGuid);
        hmContactData.put(MPSDefs.DB_CONTACT_TYPE, sContactType);

        boolean contactInMPS = true;

        logger.debug("{}{}UUCH_08 : Calling ContactDBHelper.getContact() with hmContactData : {}", sClassName,
                sMethodName, hmContactData);

        hmResult = contactDBHelper.getUserContact(hmContactData);

        logger.info("{}{}UUCH_09 : Response from ContactDBHelper.getUserContact() : {}", sClassName, sMethodName,
                hmResult);

        if (hmResult == null || hmResult.isEmpty()) {
            stAppInfo = "Null Response returned from ContactDBHelper.getContact()";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
            logger.info("{}{}UUCH_10 : {}", sClassName, sMethodName, stAppInfo);
            return hmResult;
        }

        stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

        if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
            if (CErrorDefs.ERR_REC_NOT_FOUND.equals(stAppStatusCode)) {
                contactInMPS = false;
            } else {
                logger.info("{}{}UUCH_11 : Error returned from ContactDBHelper.getUserContact() : {}", sClassName,
                        sMethodName, hmResult);
                return hmResult;
            }
        }

        hmContactData.put(MPSDefs.DB_PHONE_NUMBER, sPhoneNumber);
        hmContactData.put("phone_ext", sPhoneNumberExt);
        hmContactData.put(MPSDefs.DB_PHONE_NUMBER_TYPE, sPhoneNumberType);
        hmContactData.put(MPSDefs.DB_VALIDATION_STATUS, sValidationStatus);
        hmContactData.put(MPSDefs.DB_CONTACT_STATUS, sContactStatus);

        if (contactInMPS) {
            ArrayList<Object> alContactList = (ArrayList) hmResult.get("contacts");
            boolean bMismatchFound = false;
            if (alContactList != null && !alContactList.isEmpty()) {
                for (Object alContactListObject : alContactList) {
                    HashMap<String, Object> hmDBContacts = (HashMap) alContactListObject;
                    bMismatchFound = false;
                    HashMap<String, Object> hmUpdateContactData = CommonUtil.getHashMap();
                    Set<String> setInputContact = hmContactData.keySet();

                    for (Object o : setInputContact) {
                        String stInputKey = (String) o;

                        if (stInputKey != null && hmDBContacts.containsKey(stInputKey)) {
                            String stdbValue = (String) hmDBContacts.get(stInputKey);

                            String stInputValue = (String) hmContactData.get(stInputKey);
                            if (stInputValue != null && !stInputValue.equalsIgnoreCase(stdbValue)) {
                                if (!stInputValue.isEmpty()) {
                                    hmUpdateContactData.put(stInputKey, stInputValue);
                                    bMismatchFound = true;
                                }
                                if (stInputKey.equals("subscription_id")) {
                                    hmUpdateContactData.put(stInputKey, stInputValue);
                                    bMismatchFound = true;
                                }
                            }
                        }
                    }

                    if (bMismatchFound) {
                        hmUpdateContactData.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                        hmUpdateContactData.put(MPSDefs.DB_MEMBER_NUM, sGuid);
                        hmUpdateContactData.put(MPSDefs.DB_CONTACT_TYPE, sContactType);

                        if (!hmUpdateContactData.containsKey(MPSDefs.DB_PHONE_NUMBER)) {
                            hmUpdateContactData.put("updateEstablishedDate", "N");
                        }

                        if (hmUpdateContactData.containsKey(MPSDefs.DB_VALIDATION_STATUS)) {
                            hmUpdateContactData.put("validation_status_date_flag", "Y");
                        }

                        logger.debug("{}{}UUCH_12 : Calling ContactDBHelper.updateUserContact() with hmContactData : {}", sClassName, sMethodName, hmContactData);

                        hmResult = contactDBHelper.updateUserContact(hmUpdateContactData);

                        logger.debug("{}{}UUCH_13 : Response from ContactDBHelper.updateContact() : {}", sClassName, sMethodName, hmResult);

                        if (hmResult == null || hmResult.isEmpty()) {
                            stAppInfo = "Null Response returned from ContactDBHelper.updateContact()";
                            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                            logger.info("{}{}UUCH_14 : {}", sClassName, sMethodName, stAppInfo);
                            return hmResult;
                        }

                        if (!(CommonDefs.COMMON_SUCCESS.equals(hmResult.get(MPSDefs.APP_STATUS_CODE)))) {
                            logger.info("{}{}UUCH_15 : Error returned from ContactDBHelper.updateContact() : {}",
                                    sClassName, sMethodName, hmResult);
                            return hmResult;
                        }
                    } else {
                        stAppInfo = "Nothing to Update for One Record since Input Data in sync with DB Data. ";
                        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
                        return hmResult;
                    }
                }
            }
        } else {
            long lContactId = oDBHelper.getNextContactId();
            String stContactIdGen = Long.toString(lContactId);

            hmContactData.put(CommonDefs.KEY_CONTACT_ID, stContactIdGen);

            logger.debug("{}{}UUCH_16 : Calling ContactDBHelper.addContact() with hmContactData : {}", sClassName,
                    sMethodName, hmContactData);

            hmResult = contactDBHelper.addUserContact(hmContactData);

            logger.debug("{}{}UUCH_17 : Response from ContactDBHelper.addContact() : {}", sClassName, sMethodName,
                    hmResult);

            if (hmResult == null || hmResult.isEmpty()) {
                stAppInfo = "Null Response returned from ContactDBHelper.addContact()";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                logger.info("{}{}UUCH_18 : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }

            if (!(CommonDefs.COMMON_SUCCESS.equals(hmResult.get(MPSDefs.APP_STATUS_CODE)))) {
                logger.info("{}{}UUCH_19 : Error returned from ContactDBHelper.addContact() : {}", sClassName, sMethodName, hmResult);
                return hmResult;
            }
        }
        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
        logger.info("{}{}HLP999 : hmResult = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmResult)));
        return hmResult;
    }
}