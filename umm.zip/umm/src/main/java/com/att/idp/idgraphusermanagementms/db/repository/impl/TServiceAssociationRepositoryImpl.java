package com.att.idp.idgraphusermanagementms.db.repository.impl;

import java.sql.SQLException;
import java.time.LocalDate;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.att.idp.idgraphusermanagementms.db.model.Tserviceinfo;
import com.att.idp.idgraphusermanagementms.db.model.TserviceinfoId;
import com.att.idp.idgraphusermanagementms.db.repository.IDMProfileOrchestrationCustomRepository;
import com.att.idp.idgraphusermanagementms.db.repository.TServiceAssociationRepositoryCustom;

/**
 * This is the implementation class for the TServiceAssociationRepositoryCustom interface.
 * It extends IDMProfileOrchestrationCustomRepository for common CRUD operations.
 * The entity associated with this repository is Tserviceinfo and the ID type is TserviceinfoId.
 */
@Repository
public class TServiceAssociationRepositoryImpl extends IDMProfileOrchestrationCustomRepository<Tserviceinfo, TserviceinfoId> implements TServiceAssociationRepositoryCustom {

	private static final Logger logger = LoggerFactory.getLogger(TServiceAssociationRepositoryImpl.class);
	
	@Override
	protected Class<Tserviceinfo> getClassT() {
		return Tserviceinfo.class;
	}
	
	@Override
	public int saveTServiceInfo() throws SQLException {

		int rowCount = 0;
		
		
		try {
			
			String sql = "insert into MPS_OWNER.TSERVICEINFO (SOR_ID,SOR_INVARIANT_ID,"
															 + "FISERV_ENABLED_DATE,FISERV_AUTH_DATE,"
															 + "CREATE_DATE,"
															 + "LAST_MODIFIED,"
															 + "LAST_MODIFIED_BY,ACCOUNT_LOCKED,ACCOUNT_LOCKED_REASON) values (:sorId,"
															 + ":sorInvariantId,sysdate,"
															 + "sysdate,sysdate,"
															 + "sysdate,:lastModifiedBy,:accountLocked,"
															 + ":accountLockedReason)";
			
			Session hibSession = getSession();
			
			rowCount = hibSession.createNativeQuery(sql).addSynchronizedQuerySpace("")
					   .setParameter("sorId", Long.valueOf(999))
					   .setParameter("sorInvariantId", "TEST123123")
					   .setParameter("lastModifiedBy", "Test123")
					   .setParameter("accountLocked", "")
					   .setParameter("accountLockedReason", "")
					   .executeUpdate();
		} catch(Exception ex) {
			logger.error("Exception occured TServiceAssociationRepositoryImpl.saveTServiceInfo() : " + ex);
			//System.out.println("Error while inserting to DB : " + ex.getMessage());
		}
		return rowCount;
	}
}