package com.att.idp.idgraphusermanagementms.resource.request;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import static org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString;
import static org.apache.commons.lang3.builder.ToStringStyle.JSON_STYLE;

/**
 * This class is part of the com.att.idp.idgraphusermanagementms.resource.request package.
 *
 * The Sms class implements the Serializable interface, allowing instances of this class to be converted into a byte stream.
 *
 * The class is used to represent an Sms object, which contains a smsPhoneNumber field.
 * The smsPhoneNumber field is annotated with @NotNull and @Size, indicating that it is a required field and has a size constraint.
 *
 * The class provides a no-argument constructor, as well as getter and setter methods for the smsPhoneNumber field.
 * It also overrides the toString method, providing a custom string representation of the object using reflection.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Sms implements Serializable{

	@NotNull(message="smsPhoneNumber is required field in input request.|ResetUserPassword")
	@Size(min=1, max=10,message="smsPhoneNumber length is invalid|ResetUserPassword")
	protected String smsPhoneNumber;
	
	 /**
     * This field represents a map of unknown attributes.
     *
     * The unknownAttributes map is used to store any additional attributes that are not part of the attributeName and attributeValue fields.
     * It is initialized as a new HashMap.
     *
     * The field is annotated with @JsonAnySetter and @JsonAnyGetter, allowing it to be included in JSON serialization and deserialization.
     */
    @JsonAnySetter
    @JsonAnyGetter
    public Map<String,Object> unknownAttributes = new HashMap<>();

	@Override
	public String toString() {
		return reflectionToString(this, JSON_STYLE);
	}
}