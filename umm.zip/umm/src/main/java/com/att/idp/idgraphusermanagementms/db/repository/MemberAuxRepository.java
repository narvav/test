package com.att.idp.idgraphusermanagementms.db.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.idp.idgraphusermanagementms.db.model.Tmemberaux;

/**
 * This is the repository interface for the MemberAux entity.
 * It extends JpaRepository to provide standard data access operations on the MemberAux entity.
 * It also extends MemberAuxRepositoryCustom to provide custom data access operations.
 *
 * @param <Tmemberaux> The type of the entity this repository manages.
 * @param <Long> The type of the id of the entity this repository manages.
 */
@Repository 
public interface MemberAuxRepository extends JpaRepository<Tmemberaux, Long> , MemberAuxRepositoryCustom{
	
	
}
