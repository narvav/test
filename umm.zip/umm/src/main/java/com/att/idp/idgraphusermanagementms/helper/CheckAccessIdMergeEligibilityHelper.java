package com.att.idp.idgraphusermanagementms.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import jakarta.ws.rs.core.MultivaluedMap;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;
import com.att.idp.idgraphusermanagementms.db.helper.MPSInquireProfileDBHelper;
import com.att.idp.idgraphusermanagementms.utils.LogInformationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import net.logstash.logback.argument.StructuredArguments;

/**
 * The CheckAccessIdMergeEligibilityHelper class is a helper class that provides methods to check the eligibility of merging Access IDs.
 * It includes methods to validate the input, check the eligibility of the Access IDs, and interact with the MPSInquireProfileDBHelper class to perform database operations.
 * This class is annotated with @Component, meaning it is an autodetectable Spring Bean and can be automatically wired into other components using Spring's dependency injection facilities.
 * It is also annotated with @Configuration and @PropertySource, indicating that it provides configuration information for the Spring application context and specifies the path of the properties file to be used.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class CheckAccessIdMergeEligibilityHelper {
	public static final Logger logger = LoggerFactory.getLogger(CheckAccessIdMergeEligibilityHelper.class);
	private static String sClassName = "CheckAccessIdMergeEligibilityHelper";
	private static final String ERROR_ENUM = "ErrorEnum";
	private boolean isTransactionRollbackOnError = false;
	
	@Value("${checkAccessIdMergeEligibility_InEligibleServices}")
	private String sCheckAIDMergeIneligibleServices;
	
	@Value("${checkAccessIdMergeEligibility_InEligibleSingleInstanceDynamicServices}")
	private String sIneligibleDynamicServices;
	
	@Value("${PROP_ACCESSID_SERVICES_ACCOUNTS_MAX_LIMIT}")
	private String sMaxAllowedSvcsAccounts;
	
	@Autowired
	private MPSInquireProfileDBHelper inquireProfileDBHelperObj;

	/**
	 * This method checks the eligibility of merging Access IDs based on the input parameters.
	 * It validates the input, checks the eligibility of the Access IDs, and interacts with the MPSInquireProfileDBHelper class to perform database operations.
	 * It also handles exceptions and logs the necessary information for debugging purposes.
	 *
	 * @param hmInput A Map containing the necessary information for checking the eligibility of merging Access IDs. This includes details like the old Access ID, new Access ID, transaction ID, transaction name, and calling system ID.
	 * @return A Map containing the result of the operation. This includes status codes and messages indicating the success or failure of the operation.
	 */
	public Map<String, Object> checkAccessIdMergeEligibility(Map<String, Object> hmInput,
			MultivaluedMap<String, String> requestHeader) {
		String sMethodName = ".CheckAccessIdMergeEligibility.";
		Map<String, Object> hmResult = null;
		String stAppInfo = null;
		String stAppStatusCode = null;

		logger.info(SpiMarker.getInstance(),
				"CheckAccessIdMergeEligibilityHelper.checkAccessIdMergeEligibility.HLP000 : Input Hash : {}",
				StructuredArguments.entries(hmInput));

		if (MapUtils.isEmpty(hmInput)) {
			stAppInfo = "Input Hash is NULL";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			logger.info("{}{}CUNH_100 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}
		HashMap<String, Object> hmIPFromUNReq = CommonUtil.getHashMap();
		HashMap<String, Object> hmIPToUNReq = CommonUtil.getHashMap();
		HashMap<String, Object> hmIPFromUNResp = CommonUtil.getHashMap();
		HashMap<String, Object> hmIPToUNResp = CommonUtil.getHashMap();

		try {
			logger.info("CAIMEH_01 : sFromUserName : {} ", (String) hmInput.get(CommonDefs.FROM_USERNAME));
			logger.info("CAIMEH_02 : sToUserName : {} ", (String) hmInput.get(CommonDefs.TO_USERNAME));

			hmIPFromUNReq = createNewInquireProfileRequest(hmInput,
					(String) hmInput.get(CommonDefs.FROM_USERNAME));
			hmIPFromUNResp = inquireProfileDBHelperObj.inquireProfile(hmIPFromUNReq);
			stAppStatusCode = (String) hmIPFromUNResp.get(CommonDefs.COMMON_APP_STATUS_CODE);

			if (stAppStatusCode != null && !stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
				if (stAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND)
						|| stAppStatusCode.equals(CErrorDefs.ERR_USER_NOT_FOUND)) {
					stAppInfo = "User Not Found";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
					logger.error("{}{}CAIMEH_02: {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				} else {
					hmResult = hmIPFromUNResp;
					logger.error("{}{}CAIMEH_03: {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
			}
			hmResult = checkUserFraud(hmIPFromUNResp);
			stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				stAppInfo = (String) hmResult.get(MPSDefs.APP_INFO);
				logger.error("{}{}HLP006: {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			hmResult = checkInEligibleService(hmIPFromUNResp);
			stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				stAppInfo = (String) hmResult.get(MPSDefs.APP_INFO);
				logger.error("{}{}HLP007: {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			hmIPToUNReq = createNewInquireProfileRequest(hmInput,
					(String) hmInput.get(CommonDefs.TO_USERNAME));
			hmIPToUNResp = inquireProfileDBHelperObj.inquireProfile(hmIPToUNReq);
			stAppStatusCode = (String) hmIPToUNResp.get(MPSDefs.APP_STATUS_CODE);

			if (stAppStatusCode != null && !stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
				if (stAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND)
						|| stAppStatusCode.equals(CErrorDefs.ERR_USER_NOT_FOUND)) {
					stAppInfo = "User Not Found";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
					logger.error("{}{}HLP008: {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				} else {
					hmResult = hmIPToUNResp;
					logger.error("{}{}HLP009: {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
			}

			hmResult = checkUserFraud(hmIPToUNResp);
			stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				stAppInfo = (String) hmResult.get(MPSDefs.APP_INFO);
				logger.error("{}{}HLP010: {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			hmResult = checkInEligibleService(hmIPToUNResp);
			stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				stAppInfo = (String) hmResult.get(MPSDefs.APP_INFO);
				logger.error("{}{}HLP011: {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			HashMap hmIPToUNRespMember = (HashMap) hmIPToUNResp.get("member");

			if (hmIPToUNRespMember != null && !hmIPToUNRespMember.isEmpty()) {
				String sMd5Password = (String) hmIPToUNRespMember.get("md5Password");
				if (sMd5Password == null || sMd5Password.isEmpty()) {
					stAppInfo = "Error Required password format not on file";
					logger.error("{}{}HLP012: {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REQD_PWD_FORMAT_NOT_ON_FILE_NUM,
							stAppInfo);
					return hmResult;
				}
			}

			hmResult = checkDynamicService(hmIPFromUNResp, hmIPToUNResp);
			stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				stAppInfo = (String) hmResult.get(MPSDefs.APP_INFO);
				logger.error("{}{}HLP013: {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
			hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown in checkAccessIdMergeEligibility method : " + hmResult;
			logger.info("{}{}CUNH_150 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
		}

		finally {
			String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);

			if (isTransactionRollbackOnError && sAppCategoryCode != null
					&& !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
				hmResult.put("isTransactionRollback", CommonDefs.IND_Y);
			}

			logger.info("{}{}HLP999 : response from checkAccessIdMergeEligibility : {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(hmResult)));
		}
		return hmResult;
	}

	/**
	 * 
	 * @param hmInput
	 * @param userName
	 * @return
	 */
	private HashMap<String,Object> createNewInquireProfileRequest(Map<String, Object> hmInput, String userName) {
		
		HashMap<String, Object> hmInqProfileInp = CommonUtil.getHashMap();
		hmInqProfileInp.put(CommonDefs.TRANSACTION_NAME, "InquireProfile");
		hmInqProfileInp.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		hmInqProfileInp.put(CommonDefs.LEVEL, CommonDefs.INQUIREPROFILE_LEVEL_MSR);
		hmInqProfileInp.put(CommonDefs.IS_EXTERNAL_CALL, CommonDefs.IND_N);
		hmInqProfileInp.put(CommonDefs.HANDLE, userName);
		hmInqProfileInp.put(CommonDefs.DOMAIN, CommonDefs.SLID_DUM);
		hmInqProfileInp.put(CommonDefs.RETURN_USER_FRAUD_LOCK, CommonDefs.IND_Y);
		hmInqProfileInp.put(CommonDefs.RETURN_USER_SECURITY_INFO, CommonDefs.IND_Y);
		hmInqProfileInp.put("returnUserLockout", CommonDefs.IND_Y);
		hmInqProfileInp.put("QUERY_USER_MERGE", CommonDefs.IND_Y);
		return hmInqProfileInp;
	}

	/**
	 * checkUserFraud method will check user is Fraud Locked and return return
	 * success or error response.
	 *
	 * @param hmSlidResponse the hm slid response
	 * @return Hashmap
	 */
	private HashMap<String, Object> checkUserFraud(HashMap<String, Object> hmSlidResponse) {

		String sMethodName = ".checkUserFraud.";
		HashMap<String, Object> hmResult = null;
		HashMap<String, Object> hmuserFraudLock = (HashMap<String, Object>) hmSlidResponse
				.get("userfraudlock");
		if (hmuserFraudLock != null && !hmuserFraudLock.isEmpty()) {
			String sUserFraudLockLevel = (String) hmuserFraudLock.get(CommonDefs.USER_LOCK_LEVEL);
			if (sUserFraudLockLevel != null && !sUserFraudLockLevel.isEmpty()) {
				String stAppInfo = "User Fraud Locked";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_FRAUD_LOCKED_NUM, stAppInfo);
				logger.error("{}{}HLP027 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			} else {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
			}
		} else {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		}
		return hmResult;
	}

	/**
	 * checkInEligibleService method will check InEligibleService and return return
	 * success or error response.
	 *
	 * @param hmSlidResponse the hm slid response
	 * @param log            the log
	 * @return Hashmap
	 */

	private HashMap<String, Object> checkInEligibleService(HashMap<String, Object> hmSlidResponse) {
		String sMethodName = ".checkInEligibleService.";
		HashMap<String, Object> hmResult = null;
		String stAppInfo = null;
		try {
			ArrayList alMemberServiceRole = (ArrayList) hmSlidResponse.get(CommonDefs.MEMBER_SERVICE_ROLE);

			logger.info("{}{} HLP028 : checkInEligibleService : {}", sClassName, sMethodName,
					sCheckAIDMergeIneligibleServices);

			if (sCheckAIDMergeIneligibleServices == null || sCheckAIDMergeIneligibleServices.isEmpty()) {
				stAppInfo = "The value of property checkAccessIdMergeEligibility InEligibleServices is not configured in property files";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
				logger.info("{}{}HLP029 : {} ", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			if (alMemberServiceRole != null && !alMemberServiceRole.isEmpty()) {
				ArrayList alIneligibleServices = CommonUtil.parseToArray(sCheckAIDMergeIneligibleServices,
						CommonDefs.VALUE_SEPARATOR_CHAR);
				if (alIneligibleServices != null && !alIneligibleServices.isEmpty()) {
					for (int index = 0; index < alMemberServiceRole.size(); index++) {
						HashMap hmIneligibleServices = (HashMap) alMemberServiceRole.get(index);
						if (hmIneligibleServices != null && !hmIneligibleServices.isEmpty()) {
							String sIneligibleServicesName = (String) hmIneligibleServices.get(CommonDefs.SERVICE_NAME);
							if (alIneligibleServices.contains(sIneligibleServicesName)) {
								stAppInfo = "ERR_INELIGIBLE_SERVICE_" + sIneligibleServicesName;
								hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_NOT_ELIGIBLE_NUM, stAppInfo);
								logger.info("{}{}HLP030 : {} ", sClassName, sMethodName, stAppInfo);
								return hmResult;
							}
						}
					}
				}
			}
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e);
		}
		return hmResult;
	}

	/**
	 * checkDynamicService method will check DynamicService and return return
	 * success or error response.
	 *
	 * @param hmFromSlidResp the hm from slid resp
	 * @param hmToSlidResp   the hm to slid resp
	 * @param log            the log
	 * @return Hashmap
	 */

	private HashMap checkDynamicService(HashMap hmFromSlidResp, HashMap hmToSlidResp) {
		String sMethodName = ".checkDynamicService.";
		HashMap hmResult = null;
		String stAppInfo = null;
		try {
			ArrayList alFromMemberServiceRole = (ArrayList) hmFromSlidResp.get(CommonDefs.MEMBER_SERVICE_ROLE);
			ArrayList alToMemberServiceRole = (ArrayList) hmToSlidResp.get(CommonDefs.MEMBER_SERVICE_ROLE);

			logger.info("{}{} HLP032 : checkDynamicService : {}", sClassName, sMethodName, sIneligibleDynamicServices);

			if (sIneligibleDynamicServices == null || sIneligibleDynamicServices.isEmpty()) {
				stAppInfo = "The value of checkAccessIdMergeEligibility InEligibleSingleInstanceDynamicServices is not configured in property files";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
				logger.info("{}{}HLP033 : {} ", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			// [2208][SPTAUTHREG-11248]: Update MOUP.CheckAccessIdMergeEligibility to reject
			// for 25+ accounts
			logger.info(sClassName + sMethodName + "HLP033.1 : "
					+ "Property PROP_ACCESSID_SERVICES_ACCOUNTS_MAX_LIMIT : " + sMaxAllowedSvcsAccounts);
			if (sMaxAllowedSvcsAccounts == null || sMaxAllowedSvcsAccounts.isEmpty()) {
				stAppInfo = "The value of checkAccessIdMergeEligibility MaxAllowedSvcsAccounts is not configured in property files";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
				logger.info("{}{}HLP033.2 : {} ", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			int iMaxAllowedSvcsAccounts = 0;
			if (StringUtils.isNotBlank(sMaxAllowedSvcsAccounts)) {
				iMaxAllowedSvcsAccounts = Integer.parseInt(sMaxAllowedSvcsAccounts);
			}

			int iToSlidTotalSvcsAccounts = Optional.ofNullable(alToMemberServiceRole).map(ArrayList::size).orElse(0);
			int iFromSlidTotalSvcAccounts = Optional.ofNullable(alFromMemberServiceRole).map(ArrayList::size).orElse(0);

			int totalSvcsAccounts = iToSlidTotalSvcsAccounts + iFromSlidTotalSvcAccounts;
			logger.info("{}{}HLP033.3 : total services toUserName has :{} and total services fromUserName has :{} ",
					sClassName, sMethodName, iToSlidTotalSvcsAccounts, iFromSlidTotalSvcAccounts);
			if (totalSvcsAccounts > iMaxAllowedSvcsAccounts) {
				stAppInfo = "toUserName and fromUserName combined can not have more than 25 services";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_MAX_ACCOUNTS_ON_ACCESSID_NUM, stAppInfo);
				logger.info("{}{}HLP033.4 : {} ", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			// end
			ArrayList<String> alIneligibleDynamicServices = CommonUtil.parseToArray(sIneligibleDynamicServices,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			HashMap<String, ArrayList> hmFromDynamicService = new HashMap<String, ArrayList>();
			if (alFromMemberServiceRole != null && !alFromMemberServiceRole.isEmpty()) {
				for (int i = 0; i < alFromMemberServiceRole.size(); i++) {
					HashMap hmFromMemberServiceRole = (HashMap) alFromMemberServiceRole.get(i);
					if (hmFromMemberServiceRole != null && !hmFromMemberServiceRole.isEmpty()) {
						String sFromServiceName = (String) hmFromMemberServiceRole.get(CommonDefs.SERVICE_NAME);
						if (alIneligibleDynamicServices.contains(sFromServiceName)) {
							if (LogInformationConstants.VAS.equalsIgnoreCase(sFromServiceName)
									|| LogInformationConstants.CONNECTEDHOME.equalsIgnoreCase(sFromServiceName)) {
								stAppInfo = "ERR_INELIGIBLE_SERVICE_" + sFromServiceName;
								hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_NOT_ELIGIBLE_NUM, stAppInfo);
								logger.info("{}{}HLP034 : {} ", sClassName, sMethodName, stAppInfo);
								return hmResult;
							} else {
								String sFromSorINV = (String) hmFromMemberServiceRole.get(CommonDefs.SOR_INVARIANT_ID);
								if (sFromSorINV != null && !sFromSorINV.isEmpty()) {
									if (hmFromDynamicService.get(sFromServiceName) != null) {
										((ArrayList) hmFromDynamicService.get(sFromServiceName)).add(sFromSorINV);
									} else {
										ArrayList<String> alFromMembersorInvariantId = new ArrayList<String>();
										alFromMembersorInvariantId.add(sFromSorINV);
										hmFromDynamicService.put(sFromServiceName, alFromMembersorInvariantId);
									}
								}
							}
						}
				}
			}
			}

			if (hmFromDynamicService != null && !hmFromDynamicService.isEmpty() && alToMemberServiceRole != null
					&& !alToMemberServiceRole.isEmpty()) {
				for (int index = 0; index < alToMemberServiceRole.size(); index++) {
					HashMap hmToMemberServiceRole = (HashMap) alToMemberServiceRole.get(index);
					if (hmToMemberServiceRole != null && !hmToMemberServiceRole.isEmpty()) {
						String sToDynamicServiceName = (String) hmToMemberServiceRole.get(CommonDefs.SERVICE_NAME);
						if (hmFromDynamicService.containsKey(sToDynamicServiceName)) {
							if (LogInformationConstants.VAS.equalsIgnoreCase(sToDynamicServiceName)
									|| LogInformationConstants.DIRECTVNOW.equalsIgnoreCase(sToDynamicServiceName)
									|| LogInformationConstants.CONNECTEDHOME.equalsIgnoreCase(sToDynamicServiceName)) {
								stAppInfo = "ERR_INELIGIBLE_SERVICE_" + sToDynamicServiceName;
								hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_NOT_ELIGIBLE_NUM, stAppInfo);
								logger.info("{}{}HLP034 : {} ", sClassName, sMethodName, stAppInfo);
								return hmResult;
							} else if (!(hmFromDynamicService.get(sToDynamicServiceName)
									.contains(hmToMemberServiceRole.get(CommonDefs.SOR_INVARIANT_ID)))) {
								stAppInfo = "ERR_INELIGIBLE_SERVICE_" + sToDynamicServiceName;
								hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_NOT_ELIGIBLE_NUM, stAppInfo);
								logger.info("{}{}HLP036 : {} ", sClassName, sMethodName, stAppInfo);
								return hmResult;

							}
						}
					}
				}
			}
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e);
		}
		return hmResult;

	}
}