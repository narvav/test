package com.att.idp.idgraphusermanagementms.helper;

import com.att.idp.idgraph.db.oracle.helper.SubAccountsDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.GetMemberServicesDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.MemberDBHelper;
import com.att.idp.idgraphusermanagementms.queue.message.helpers.DeleteUserQueueHelper;
import com.att.idp.idgraphusermanagementms.resource.request.DeleteUserRequest;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Helper component that encapsulates the business logic required to delete a user or SLID
 * from MPS, including validation, database interaction and message‑queue notifications.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class DeleteUserHelper {

    public static final Logger logger = LoggerFactory.getLogger(DeleteUserHelper.class);
    private static final String sClassName = "DeleteUserHelper";
    private boolean isTransactionRollbackOnError = false;

    @Autowired
    private GetMemberServicesDBHelper getMemberServicesDBHelper;

    @Autowired
    private DeleteUserUtilHelper deleteUserUtility;

    @Autowired
    private DeleteUserCommonHelper deleteUserCommonHelper;

    @Autowired
    private SubAccountsDBHelper subAccountsDBHelper;

    @Autowired
    private MemberDBHelper memberDBHelper;

    @Autowired
    private DeleteUserQueueHelper deleteUserQueueHelper;

    private String sContextName = null;
    private boolean bLinkToSlid = false;

    /**
     * Orchestrates the delete user flow for a given request. The method performs
     * member lookup, validates state and services, routes to member or SLID
     * specific flows, updates member state when required and finally triggers
     * DB/queue side effects. The response map follows the common application
     * status convention defined in {@link CommonDefs} / {@link CErrorDefs}.
     *
     * @param deleteUserReq the delete‑user request containing handle/domain/guid
     *                      and calling system metadata
     * @return a result map containing application status code/message and
     * additional context describing the outcome of the delete operation
     */
    public Map<String, Object> deleteUser(DeleteUserRequest deleteUserReq) {

        String sMethodName = ".deleteUser.";
        Map<String, Object> hmResult = new HashMap<>();
        Map<String, Object> hmMemberDetails;
        String sAppInfo;
        logger.info(SpiMarker.getInstance(), "DeleteUserHelper.deleteUser.HLP000 : Input Request : {}",
                CommonUtilHelper.sanitizeForLog(String.valueOf(deleteUserReq)));

        try {

            String sHandle = deleteUserReq.getHandle();
            String sDomain = deleteUserReq.getDomain();
            String guid = deleteUserReq.getGuid();

            // call memberServices
            hmMemberDetails = getMemberServices(sHandle, sDomain, guid);
            if (!isSuccess(hmMemberDetails) || "MemberID does not exist or might already be deleted from MPS".equals(hmMemberDetails.get(CommonDefs.COMMON_APP_INFO))) {
                hmResult = hmMemberDetails;
                return hmResult;
            }

            // if guid passed
            if (sHandle == null && sDomain == null) {
                sHandle = (String) hmMemberDetails.get(MPSDefs.DB_MEMBER_NAME);
                sDomain = (String) hmMemberDetails.get(MPSDefs.DB_DOMAIN_NAME);
                deleteUserReq.setHandle(sHandle);
                deleteUserReq.setDomain(sDomain);
            } else {
                guid = (String) hmMemberDetails.get(MPSDefs.DB_MEMBER_NUM);
            }

            // to handle Terminated/Suspended memberIds
            hmResult = handleTerminatedOrSuspendedMember(deleteUserReq, hmMemberDetails);
            if (!isSuccess(hmResult)) {
                return hmResult;
            }

            // member level validations
            hmResult = validateMemberDetails(deleteUserReq, hmMemberDetails);
            if (hmResult != null) {
                return hmResult;
            }

            // slid flow - completed and returning back to caller
            if (CommonDefs.SLID_DUM.equals(sDomain)) {
                hmResult = deleteSlid(deleteUserReq, hmMemberDetails);
                if (!isSuccess(hmResult)) {
                    isTransactionRollbackOnError = true;
                }
                return hmResult;
            }

            // member flow
            hmResult = deleteInputMember(deleteUserReq, hmMemberDetails);
            if (!isSuccess(hmResult)) {
                isTransactionRollbackOnError = true;
                return hmResult;
            }

            String sDoNotInsertMember = getDoNotInsertMember(hmResult);
            Map<String, Object> hmParentToInsert = getParentToInsert(hmResult);

            // update member state as DEL
            if (shouldUpdateMemberAsDeleted(sDomain, sHandle, sDoNotInsertMember)) {
                hmResult = updateMemberAsDeleted(sHandle, sDomain, guid, deleteUserReq.getCallingSystemId(),
                        hmMemberDetails);
            }
            if (!isSuccess(hmResult)) {
                isTransactionRollbackOnError = true;
                return hmResult;
            }

            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

        } catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e, logger);
            isTransactionRollbackOnError = true;
            sAppInfo = "Exception thrown from DeleteUser method : " + hmResult;
            logger.info("{}{}DUH_EXP : {}", sClassName, sMethodName,
                    CommonUtilHelper.sanitizeForLog(sAppInfo));

        } finally {
            String sAppCategoryCode = hmResult != null
                    ? (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE)
                    : null;

            if (isTransactionRollbackOnError && sAppCategoryCode != null
                    && !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
                hmResult.put("isTransactionRollback", "Y");
            }
            logger.info("{}{}HLP999 : response from DeleteUser : {}", sClassName, sMethodName,
                    hmResult != null
                            ? CommonUtilHelper.sanitizeForLog(String.valueOf(hmResult))
                            : "null");
        }

        return hmResult;
    }

    /**
     * Executes the delete flow when the input identifies a member (non‑SLID).
     * It validates services, evaluates sub‑accounts/parent context, delegates
     * to {@link DeleteUserCommonHelper} for DB work and sends the appropriate
     * DBUS messages through {@link DeleteUserQueueHelper}.
     *
     * @param deleteUserReq   the delete request for the member
     * @param hmMemberDetails resolved member details from GetMemberServices
     * @return result map from the common delete flow, using standard status
     * semantics
     */
    private Map<String, Object> deleteInputMember(DeleteUserRequest deleteUserReq,
                                                  Map<String, Object> hmMemberDetails) {

        String sMethodName = ".deleteInputMember.";
        Map<String, Object> hmResult;
        String sAppInfo;
        String DeleteSLIDWithMember = null;
        ArrayList<Map<String, Object>> alDbusInput = CommonUtil.getArrayList();

        String sParentChildInd = (String) hmMemberDetails.get(MPSDefs.DB_PARENT_CHILD_IND);
        String sParentName = (String) hmMemberDetails.get(MPSDefs.DB_PARENT_NAME);

        String sParentDomain = (String) hmMemberDetails.get(MPSDefs.DB_PARENT_DOMAIN);
        String sSorName = (String) hmMemberDetails.get(MPSDefs.DB_SOR_NAME);
        Map<String, Object> hmServices = hmMemberDetails != null
                ? (Map<String, Object>) hmMemberDetails.get(MPSDefs.SERVICES)
                : null;

        if (isMapNotEmpty(hmServices)) {
            hmResult = deleteUserUtility.verifyServiceStatus((HashMap) hmServices);
            if (!isSuccess(hmResult)) {
                sAppInfo = "Enabled or suspended services exist.Service not terminated.";
                logger.info("{}{}DUUH.DIM.01 : {}", sClassName, sMethodName,
                        CommonUtilHelper.sanitizeForLog(sAppInfo));
                return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SERVICE_EXISTS_NUM, sAppInfo);
            }

        }

        // call subaccounts if its parent
        if (sParentChildInd.equals(MPSDefs.MPS_PARENT)) {

            Map<String, Object> hmGetSubInfoInput = CommonUtil.getHashMap();
            hmGetSubInfoInput.put(MPSDefs.WS_PARENT_ID, deleteUserReq.getHandle());
            hmGetSubInfoInput.put(MPSDefs.WS_DOMAIN, deleteUserReq.getDomain());
            hmGetSubInfoInput.put(MPSDefs.DB_GROUP_NUM, hmMemberDetails.get(MPSDefs.DB_GROUP_NUM));

            hmResult = getAndVerifySub(hmGetSubInfoInput);
            if (!isSuccess(hmResult)) {
                return hmResult;
            }
            sContextName = CommonDefs.CONTEXT_DeleteMemberList;

        }

        // if its child call getMemberServices for parent
        if (sParentChildInd.equals(MPSDefs.MPS_CHILD)) {
            if (MPSDefs.SOR_LS.equals(sSorName) && (!isMapNotEmpty(hmServices))) {

                logger.info("{}{}DUUH.DIM.10 : Calling getMemberServices for parent {}", sClassName, sMethodName,
                        sParentName);
                Map<String, Object> hmGetParentInfoResponse = getMemberServices(sParentName, sParentDomain, null);
                if (!isSuccess(hmGetParentInfoResponse)) {
                    return hmGetParentInfoResponse;
                }

                logger.debug("{}{}DUUH.DIM.11 : Parent GetInfo response : {}", sClassName, sMethodName,
                        hmGetParentInfoResponse);

                Map<String, Object> hmParentServices = (Map<String, Object>) hmGetParentInfoResponse.get(MPSDefs.SERVICES);
                logger.info("{}{}DUUH.DIM.12 : Parent Services : {}", sClassName, sMethodName, hmParentServices);

                // updating context if parent has voip service
                updateContextIfVoipTerminated(hmParentServices);
            }

        }

        // call deleteUser common method for db calls
        Map<String, Object> hmDeleteUserInput = prepareDeleteUserInput(deleteUserReq, hmMemberDetails);

        logger.info("{}{}DUH_DIM.13 : Calling DeleteUserCommonHelper.deleteUser() with input : {}", sClassName,
                sMethodName, CommonUtilHelper.sanitizeForLog(String.valueOf(hmDeleteUserInput)));

        hmResult = deleteUserCommonHelper.deleteUser(new HashMap<String, Object>(hmDeleteUserInput));

        logger.info("{}{}DUH_DIM.14 : Response Hash from DeleteUserCommonHelper.deleteUser() : {}", sClassName,
                sMethodName, CommonUtilHelper.sanitizeForLog(String.valueOf(hmResult)));

        Map<String, Object> hmDbusInp = null;
        boolean bFilterCGate = false;
        // dbus prep
        if (hmMemberDetails.get(MPSDefs.DB_SLID_MEMBER_NUM) != null) {
            hmResult = deleteUserQueueHelper.prepareDbusList(deleteUserReq, hmMemberDetails,
                    CommonDefs.DELETE_ALIAS, true);
            hmDbusInp = (Map<String, Object>) hmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT);
            if (hmDbusInp != null && !hmDbusInp.isEmpty()) {
                alDbusInput.add(hmDbusInp);
                bFilterCGate = true;
            }
        }
        if (DeleteSLIDWithMember != null) {
            hmResult = deleteUserQueueHelper.prepareDbusList(deleteUserReq, hmMemberDetails,
                    CommonDefs.CONTEXT_DeleteMemberList, true);
            hmDbusInp = (Map<String, Object>) hmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT);
            if (hmDbusInp != null && !hmDbusInp.isEmpty()) {
                alDbusInput.add(hmDbusInp);
            }
        }

        // dbus call
        Map<String, Object> hmDbusResult = deleteUserQueueHelper.sendMessageToMQ(hmMemberDetails, alDbusInput, deleteUserReq, bFilterCGate);

        logger.info("{}{}REUH_19 :Response from RegisterEmailUserQueueHelper.sendMessageToMQ: {}", sClassName,
                sMethodName, CommonUtilHelper.sanitizeForLog(String.valueOf(hmDbusResult)));

        if (!isSuccess(hmDbusResult)) {
            isTransactionRollbackOnError = true;
            return hmDbusResult;
        }
        return hmResult;

    }

    /**
     * Updates the internal context used for DBUS messaging when the parent
     * account has a VoIP service in terminated state.
     *
     * @param parentServices the parent services map retrieved from MPS
     */
    private void updateContextIfVoipTerminated(Map<String, Object> parentServices) {
        if (isMapNotEmpty(parentServices)) {
            Map<String, Object> voipService = (Map<String, Object>) parentServices.get(MPSDefs.VOIP_SERVICE);
            if (isMapNotEmpty(voipService)) {
                String serviceStatusVoip = (String) voipService.get(MPSDefs.SERVICE_STATUS);
                if (serviceStatusVoip != null && MPSDefs.TERMINATED.equals(serviceStatusVoip)) {
                    sContextName = CommonDefs.CONTEXT_ParentHasVoIP;
                }
            } else {
                logger.info("{}{}DUUH.UCIVT.01 : Parent dont have VoIP Service", sClassName,
                        "updateContextIfVoipTerminated");
            }
        }
    }

    /**
     * Executes the SLID delete flow. It validates that no services or linked
     * users remain for the SLID, performs the common delete logic, prepares the
     * DBUS payload and sends the corresponding MQ message.
     *
     * @param deleteUserReq   the delete request that targets a SLID
     * @param hmMemberDetails resolved SLID/member details
     * @return a result map representing the outcome of the SLID delete flow
     */
    private Map<String, Object> deleteSlid(DeleteUserRequest deleteUserReq, Map<String, Object> hmMemberDetails) {

        String sMethodName = ".deleteSlid.";
        Map<String, Object> hmResult;
        String sAppInfo;
        boolean bSlidDeleteInInput = true;
        ArrayList<Map<String, Object>> alDbusInput = CommonUtil.getArrayList();

        Map<String, Object> result = checkServices(hmMemberDetails, sMethodName);
        if (result != null) {
            return result;
        }
        result = checkLinkedUsers(hmMemberDetails, sMethodName);
        if (result != null) {
            return result;
        }

        Map<String, Object> hmDeleteUserInput = prepareDeleteUserInput(deleteUserReq, hmMemberDetails);

        logger.info("{}{}DUH_DS.03 : Calling DeleteUserCommonHelper.deleteUser() with input : {}", sClassName,
                sMethodName, CommonUtilHelper.sanitizeForLog(String.valueOf(hmDeleteUserInput)));

        hmResult = deleteUserCommonHelper.deleteUser(new HashMap<String, Object>(hmDeleteUserInput));

        logger.info("{}{}DUH_DS.04 : Response Hash from DeleteUserCommonHelper.deleteUser() : {}", sClassName,
                sMethodName, CommonUtilHelper.sanitizeForLog(String.valueOf(hmResult)));

        if (!isSuccess(hmResult)) {
            return hmResult;
        }

        // prepare dbus input for delete SLID
        hmResult = deleteUserQueueHelper.prepareDbusList(deleteUserReq, hmMemberDetails,
                CommonDefs.CONTEXT_DeleteMemberList, bSlidDeleteInInput);

        logger.info("{}{}DUH_DS.05 : DeleteMemberList Response from prepareDbusList() : {}", sClassName, sMethodName,
                CommonUtilHelper.sanitizeForLog(String.valueOf(hmResult)));

        if (!isMapNotEmpty(hmResult)) {
            sAppInfo = "Response from prepareDbusList is null or empty";
            logger.info("{}{}DUH_DS.06 : DeleteMemberList Response from prepareDbusList() : {}", sClassName,
                    sMethodName, hmResult);
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
            return hmResult;
        }

        if (!isSuccess(hmResult)) {
            return hmResult;
        }

        Map<String, Object> hmDbusInp = (Map<String, Object>) hmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT);
        if (hmDbusInp != null && !hmDbusInp.isEmpty()) {
            alDbusInput.add(hmDbusInp);
        }

        // dbus call
        Map<String, Object> hmDbusResult = deleteUserQueueHelper.sendMessageToMQ(hmMemberDetails, alDbusInput, deleteUserReq, false);

        logger.info("{}{}REUH_19 :Response from RegisterEmailUserQueueHelper.sendMessageToMQ: {}", sClassName,
                sMethodName, CommonUtilHelper.sanitizeForLog(String.valueOf(hmDbusResult)));

        if (!isSuccess(hmDbusResult)) {
            isTransactionRollbackOnError = true;
        }
        return hmResult;
    }

    /**
     * Performs member‑level validation checks before running the delete flow,
     * including FirstNet access ID constraints and SLID linkage flags.
     *
     * @param deleteUserReq   the original delete request
     * @param hmMemberDetails resolved member details
     * @return an error result map when validation fails, or {@code null} when
     * validation passes
     */
    private Map<String, Object> validateMemberDetails(DeleteUserRequest deleteUserReq,
                                                      Map<String, Object> hmMemberDetails) {

        String sMethodName = ".validateMemberDetails.";
        Map<String, Object> hmResult = null;
        Map<String, Object> hmSlidInfo;
        String sFnLinkedUserId;
        String sFnLinkedStatus = null;
        String sAppInfo;

        if (hmMemberDetails.get(MPSDefs.DB_SLID_MEMBER_NUM) != null)
            bLinkToSlid = true;

        // FN accessId's validation
        hmSlidInfo = (HashMap) hmMemberDetails.get(MPSDefs.KEY_SLID_INFO);

        if (hmSlidInfo != null && hmSlidInfo.containsKey(CommonDefs.DB_FN_LINKED_USERID)) {
            sFnLinkedUserId = (String) hmSlidInfo.get(CommonDefs.DB_FN_LINKED_USERID);
        }
        if (hmSlidInfo != null && hmSlidInfo.containsKey(CommonDefs.DB_FN_LINKED_STATUS)) {
            sFnLinkedStatus = (String) hmSlidInfo.get(CommonDefs.DB_FN_LINKED_STATUS);
        }

        if (null != sFnLinkedStatus && sFnLinkedStatus.equalsIgnoreCase(CommonDefs.FN_STATUS_SELF)) {

            sAppInfo = "Cannot delete FirstNet accessId";
            logger.info("{}{}DUH_VMD.01 : {} ", sClassName, sMethodName, sAppInfo);
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, sAppInfo);
            return hmResult;

        }

        return hmResult;
    }

    /**
     * Handles special‑case processing for terminated or suspended members,
     * including optional termination of suspended services.
     *
     * @param deleteUserReq   the original delete request
     * @param hmMemberDetails resolved member details
     * @return a success result map when processing is allowed, or an error map
     * when suspended services cannot be terminated
     * @throws IOException if underlying helper calls throw I/O related
     *                     exceptions
     */
    private Map<String, Object> handleTerminatedOrSuspendedMember(DeleteUserRequest deleteUserReq,
                                                                  Map<String, Object> hmMemberDetails) throws IOException {

        String sDomain = deleteUserReq.getDomain();
        // if domain is not slid.dum, myaccount.bellsouth.net, attworld.com
        if (isValidDomain(sDomain)) {
            // replacing getAllInfo call with getMemberServices()
            // getAllInfo(deleteUserReq);

            if (shouldCheckSuspendedServices(hmMemberDetails)) {
                Map<String, Object> hmResult = deleteUserUtility.checkSuspendedServicesToTerminate(deleteUserReq,
                        hmMemberDetails);

                if (!isSuccess(hmResult)) {
                    return hmResult;
                }
            }
        }

        return returnSuccessResponse();
    }

    /**
     * Determines whether the given domain should be treated as a standard
     * member domain (i.e. not one of the special SLID domains).
     *
     * @param sDomain the domain value from the request or member details
     * @return {@code true} if the domain is non‑null and not one of the
     * excluded domains; {@code false} otherwise
     */
    private boolean isValidDomain(String sDomain) {
        return sDomain != null && !(sDomain.equals("slid.dum") || sDomain.equals("myaccount.bellsouth.net")
                || sDomain.equals("attworld.com"));
    }

    /**
     * Utility method that checks the common status code in the supplied
     * response map.
     *
     * @param response the response map returned from a helper or DB layer
     * @return {@code true} when the response indicates common success; otherwise
     * {@code false}
     */
    private boolean isSuccess(Map<String, Object> response) {
        String statusCode = null;
        if (response != null) {
            statusCode = (String) response.get(CommonDefs.COMMON_APP_STATUS_CODE);
        }
        return CommonDefs.COMMON_SUCCESS.equals(statusCode);
    }

    /**
     * Creates a minimal success response map using the common success status
     * code.
     *
     * @return a map with {@link CommonDefs#COMMON_SUCCESS} as the application
     * status code
     */
    private Map<String, Object> returnSuccessResponse() {
        Map<String, Object> successHashMap = new HashMap<>();
        successHashMap.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS);
        return successHashMap;
    }

    /**
     * Evaluates whether suspended services should be checked/terminated for the
     * supplied member details.
     *
     * @param info the member details map
     * @return {@code true} when the member is in use, has the specific
     * aggregate service status and is parent/child; {@code false}
     * otherwise
     */
    private boolean shouldCheckSuspendedServices(Map<String, Object> info) {
        String sMemberState = (String) info.get(MPSDefs.DB_MEMBER_STATE);
        String sAggServiceStatus = (String) info.get(MPSDefs.DB_AGG_SERVICE_STATUS);
        String sParentChildInd = (String) info.get(MPSDefs.DB_PARENT_CHILD_IND);

        return MPSDefs.INUSE_STATE.equals(sMemberState) && "99".equals(sAggServiceStatus)
                && (MPSDefs.MPS_PARENT.equals(sParentChildInd) || MPSDefs.MPS_CHILD.equals(sParentChildInd));
    }

    /**
     * Retrieves sub‑account information for the given input and validates
     * whether the parent has any sub‑accounts that would prevent delete.
     *
     * @param hmGetSubInfoInput request map for the sub‑account lookup
     * @return success when no sub‑accounts exist; otherwise a cannot‑operate
     * error response
     */
    private Map<String, Object> getAndVerifySub(Map<String, Object> hmGetSubInfoInput) {

        String sMethodName = ".getAndVerifySub.";
        Map<String, Object> hmResult;

        // Fetching sub accounts
        hmResult = getAllSubInfo(hmGetSubInfoInput);
        if (!isSuccess(hmResult)) {
            String statusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
            if (CErrorDefs.ERR_REC_NOT_FOUND.equals(statusCode)) {
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "No Subaccounts.");
                logger.info("{}{}DUH_GAVS.00 : No Subaccounts", sClassName, sMethodName);
            }
            return hmResult;
        }

        ArrayList<Map<String, Object>> alSubs = (ArrayList<Map<String, Object>>) hmResult.get(MPSDefs.SUBACCOUNTS);
        if (alSubs == null || alSubs.isEmpty()) {
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "No Subaccounts.");
            logger.info("{}{}DUH_GAVS.01 : No Subaccounts", sClassName, sMethodName);
            return hmResult;
        } else {
            logger.info("{}{}DUH_GAVS.02 : User has Subaccounts", sClassName, sMethodName);
            return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, "User has SubAccounts");
        }

    }

    /**
     * Calls the {@link SubAccountsDBHelper} to retrieve all sub‑account
     * information associated with the provided input.
     *
     * @param hmGetSubInfoInput the sub‑account lookup input map
     * @return the raw response map from {@link SubAccountsDBHelper#getAllSubInfo(HashMap)}
     */
    private Map<String, Object> getAllSubInfo(Map<String, Object> hmGetSubInfoInput) {

        String sMethodName = ".getAllSubInfo.";
        Map<String, Object> hmSubAccountsInfo;

        logger.info("{}{}DUH_GASI.01 : Calling getAllSubInfo() : hmGetAllInfoRequest : {}", sClassName, sMethodName,
                CommonUtilHelper.sanitizeForLog(String.valueOf(hmGetSubInfoInput)));

        hmSubAccountsInfo = subAccountsDBHelper.getAllSubInfo(new HashMap<String, Object>(hmGetSubInfoInput));

        logger.info("{}{}DUH_GASI.02 : Response Hash from getAllSubInfo() : {}", sClassName, sMethodName,
                CommonUtilHelper.sanitizeForLog(String.valueOf(hmSubAccountsInfo)));

        return hmSubAccountsInfo;
    }

    /**
     * Invokes the {@link GetMemberServicesDBHelper} to retrieve member or SLID
     * information based on the provided identifiers and normalises the
     * resulting response into the common error map model.
     *
     * @param handle the member handle (user ID), may be {@code null} when GUID
     *               is supplied
     * @param domain the member domain, may be {@code null} when GUID is
     *               supplied
     * @param guid   the member GUID, optional alternative to handle/domain
     * @return a result map containing member details or an error/translated
     * status
     */
    private Map<String, Object> getMemberServices(String handle, String domain, String guid) {

        String sMethodName = ".getMemberServices.";
        Map<String, Object> hmGetInfoRequest = buildGetInfoRequest(handle, domain, guid);
        Map<String, Object> hmResult = new HashMap<>();

        logger.info("{}{}DUH_GMS.01 : Calling GetMemberServicesDBHelper.getMemberServices() : hmGetInfoRequest : {}",
                sClassName, sMethodName, CommonUtilHelper.sanitizeForLog(String.valueOf(hmGetInfoRequest)));

        hmResult = getMemberServicesDBHelper.getMemberServices(new HashMap<String, Object>(hmGetInfoRequest));

        logger.info("{}{}DUH_GMS.02 : Response Hash from GetMemberServicesDBHelper.getMemberServices() : {}",
                sClassName, sMethodName, CommonUtilHelper.sanitizeForLog(String.valueOf(hmResult)));

        String sAppStatusCode = hmResult != null
                ? (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE)
                : null;
        String sStatusMsg = hmResult != null
                ? (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_MSG)
                : null;
        if (!CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode)) {
            String sAppInfo;
            if (CErrorDefs.ERR_REC_NOT_FOUND_MSG.equals(sStatusMsg)) {
                sAppInfo = "MemberID does not exist or might already be deleted from MPS";
                logger.info("{}{}DUH_GMS : {}", sClassName, sMethodName,
                        CommonUtilHelper.sanitizeForLog(sAppInfo));
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, sAppInfo);
            } else {
                sAppInfo = "GetMemberServicesDBHelper.getMemberServices() call failed";
                logger.info("{}{}DUH_GMS : {}", sClassName, sMethodName,
                        CommonUtilHelper.sanitizeForLog(sAppInfo));
                try {
                    hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(sAppStatusCode), sAppInfo);
                } catch (NumberFormatException e) {
                    logger.error("{}{}DUH_GMS : Invalid status code format: {}", sClassName, sMethodName,
                            CommonUtilHelper.sanitizeForLog(sAppStatusCode));
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
                }
            }
        }

        return hmResult;
    }

    /**
     * Builds the GetMemberServices input map using the supplied identifiers and
     * consistently applies SLID and roles related flags.
     *
     * @param handle the member handle (user ID)
     * @param domain the member domain
     * @param guid   the member GUID
     * @return a populated request map suitable for the
     * {@link GetMemberServicesDBHelper}
     */
    private Map<String, Object> buildGetInfoRequest(String handle, String domain, String guid) {
        Map<String, Object> hmGetInfoRequest = CommonUtil.getHashMap();

        if (guid != null && !guid.isEmpty()) {
            hmGetInfoRequest.put(MPSDefs.DB_MEMBER_NUM, guid);
        } else {
            if (handle != null && !handle.isEmpty()) {
                hmGetInfoRequest.put(MPSDefs.DB_MEMBER_NAME, handle);
            }
            if (domain != null && !domain.isEmpty()) {
                hmGetInfoRequest.put(MPSDefs.DB_DOMAIN_NAME, domain);
            }
        }

        // Always set the slid info flag
        hmGetInfoRequest.put(MPSDefs.QUERY_SLID_INFO_FLAG, MPSDefs.YES);

        // Add slid masks
        List<String> alSlidMask = new ArrayList<>();
        alSlidMask.add(CommonDefs.MASK_LU);
        alSlidMask.add(CommonDefs.MASK_LS);
        alSlidMask.add(CommonDefs.MASK_SS);
        hmGetInfoRequest.put(CommonDefs.SLID_MASK, alSlidMask);

        // Add roles info flags
        List<String> alQueryRolesInfoFlag = new ArrayList<>();
        alQueryRolesInfoFlag.add(CommonDefs.ECOMM_SERVICE);
        alQueryRolesInfoFlag.add(CommonDefs.MOBILITY_SERVICE);
        hmGetInfoRequest.put(CommonDefs.QUERY_ROLES_INFO_FLAG, alQueryRolesInfoFlag);

        hmGetInfoRequest.put(MPSDefs.WS_DEVICE_INFO_REQUIRED, MPSDefs.YES);

        return hmGetInfoRequest;
    }

    /**
     * Simple utility to check whether a map is non‑null and non‑empty.
     *
     * @param map the map to evaluate
     * @return {@code true} if the map is non‑null and contains at least one
     * entry; {@code false} otherwise
     */
    private boolean isMapNotEmpty(Map<?, ?> map) {
        return map != null && !map.isEmpty();
    }

    /**
     * Simple utility to check whether a list is non‑null and non‑empty.
     *
     * @param list the list to evaluate
     * @return {@code true} if the list is non‑null and contains at least one
     * element; {@code false} otherwise
     */
    private boolean isListNotEmpty(List<?> list) {
        return list != null && !list.isEmpty();
    }

    /**
     * Validates that there are no active accounts or services associated with
     * the SLID prior to deletion.
     *
     * @param memberDetails member/SLID details from GetMemberServices
     * @param methodName    the calling method name for logging context
     * @return an error response map when associated services exist, otherwise
     * {@code null}
     */
    private Map<String, Object> checkServices(Map<String, Object> memberDetails, String methodName) {
        Map<String, Object> slidAccount = (Map<String, Object>) memberDetails.get(CommonDefs.SERVICES);
        if (isMapNotEmpty(slidAccount)) {
            String appInfo = "Accounts or Services are still associated with the specified SLID";
            logger.info("{}{}DUH_CS.01 : {}", sClassName, methodName, appInfo);
            return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SERVICE_EXISTS_NUM, appInfo);
        }
        return null;
    }

    /**
     * Checks whether any member IDs are still linked to the SLID and blocks the
     * delete operation when such links exist.
     *
     * @param memberDetails member/SLID details map
     * @param methodName    the calling method name for logging context
     * @return an error response map when linked users exist, otherwise
     * {@code null}
     */
    private Map<String, Object> checkLinkedUsers(Map<String, Object> memberDetails, String methodName) {
        Map<String, Object> slidInfo = (Map<String, Object>) memberDetails.get(MPSDefs.KEY_SLID_INFO);
        if (slidInfo != null && slidInfo.containsKey(MPSDefs.KEY_LINKED_USERS)) {
            List<Object> linkedUsers = (List<Object>) slidInfo.get(MPSDefs.KEY_LINKED_USERS);
            if (isListNotEmpty(linkedUsers)) {
                String appInfo = "MemberIds are still associated with the specified SLID";
                logger.info("{}{}DUH_CLU.01 : {}", sClassName, methodName, appInfo);
                return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, appInfo);
            }
        }
        return null;
    }

    /**
     * Prepares the input map required by {@link DeleteUserCommonHelper} based
     * on the delete request and resolved member details.
     *
     * @param req             the delete request
     * @param hmMemberDetails resolved member details from GetMemberServices
     * @return a populated input map for the common delete helper
     */
    private Map<String, Object> prepareDeleteUserInput(DeleteUserRequest req, Map<String, Object> hmMemberDetails) {
        Map<String, Object> input = CommonUtil.getHashMap();
        input.put(MPSDefs.WS_USER_ID, req.getHandle());
        input.put(MPSDefs.WS_DOMAIN, CommonDefs.SLID_DUM);
        input.put(MPSDefs.WS_CALLING_SYSTEM_ID, req.getCallingSystemId());
        input.put(MPSDefs.WS_UPDATED_BY, req.getCallingSystemId());

        // populating other fields as part of getMmemberServices- eliminated call in
        // deleteUser
        input.put(MPSDefs.DB_PARENT_CHILD_IND, hmMemberDetails.get(MPSDefs.DB_PARENT_CHILD_IND));
        input.put(MPSDefs.WS_GROUP_NUM, hmMemberDetails.get(MPSDefs.DB_GROUP_NUM));

        input.put(CommonDefs.TRANSACTION_ID, req.getIdpTraceId());
        input.put(CommonDefs.TRANSACTION_NAME, req.getTransactionName());

        return input;
    }

    /**
     * Extracts the "doNotInsertMember" flag from the supplied result map.
     *
     * @param hmResult result map returned from the common delete flow
     * @return the flag value when present, otherwise {@code "N"}
     */
    private String getDoNotInsertMember(Map<String, Object> hmResult) {
        if (hmResult.containsKey("doNotInsertMember")) {
            return (String) hmResult.get("doNotInsertMember");
        }
        return "N";
    }

    /**
     * Extracts the parent member map to insert, if present, from the supplied
     * result map.
     *
     * @param hmResult result map returned from the common delete flow
     * @return the parent member map to insert, or {@code null} when none is
     * present
     */
    private Map<String, Object> getParentToInsert(Map<String, Object> hmResult) {
        if (hmResult.containsKey("parentToInsert")) {
            return (Map<String, Object>) hmResult.get("parentToInsert");
        }
        return null;
    }

    /**
     * Determines whether the member record should be updated with a logical
     * delete row in the member table.
     *
     * @param sDomain            the member domain
     * @param sHandle            the member handle
     * @param sDoNotInsertMember flag indicating that the member row should not
     *                           be inserted
     * @return {@code true} when the member should be written as deleted;
     * {@code false} otherwise
     */
    private boolean shouldUpdateMemberAsDeleted(String sDomain, String sHandle, String sDoNotInsertMember) {
        return isValidDomain(sDomain) && sHandle != null && !sHandle.startsWith("sbciptv_")
                && "N".equals(sDoNotInsertMember);
    }

    /**
     * Persists a logical delete row for the member in the member table using
     * MemberDBHelper - processData().
     *
     * @param sHandle         the member handle
     * @param sDomain         the member domain
     * @param guid            the member GUID
     * @param lastModifiedBy  identifier of the calling system performing the
     *                        update
     * @param hmMemberDetails resolved member details whose attributes are
     *                        carried over to the delete row
     * @return the result map returned from {@link MemberDBHelper}
     */
    private Map<String, Object> updateMemberAsDeleted(String sHandle, String sDomain, String guid,
                                                      String lastModifiedBy, Map<String, Object> hmMemberDetails) {

        String sMethodName = ".updateMemberAsDeleted.";
        ArrayList<Map<String, Object>> alUpdateMember = CommonUtil.getArrayList();
        HashMap<String, Object> hmUpdateMember = CommonUtil.getHashMap();
        HashMap<String, Object> hmMemberDataInput = CommonUtil.getHashMap();

        hmUpdateMember.put(MPSDefs.DB_MEMBER_NAME, sHandle);
        hmUpdateMember.put(MPSDefs.DB_DOMAIN_ID, hmMemberDetails.get(MPSDefs.DB_DOMAIN_ID));
        hmUpdateMember.put(MPSDefs.DB_MEMBER_NUM, guid);
        hmUpdateMember.put(MPSDefs.DB_GROUP_NUM, "1");
        hmUpdateMember.put(MPSDefs.DB_SOR_ID, "20");
        hmUpdateMember.put(MPSDefs.DB_PARENT_CHILD_IND, "D");
        hmUpdateMember.put(MPSDefs.DB_ACCESS_ID, "0");
        hmUpdateMember.put(MPSDefs.DB_MEMBER_STATE, "DEL");
        // hmUpdateMember.put(MPSDefs.DB_FULLNAME, "RESERVED NAMESPACE");
        hmUpdateMember.put(MPSDefs.DB_LAST_MODIFIED_BY, lastModifiedBy);
        hmUpdateMember.put(MPSDefs.DB_OPERATION, "insertWhenMemberDelete");

        // added these attributes as part of member
        hmUpdateMember.put(MPSDefs.DB_FIRSTNAME, hmMemberDetails.get("firstname"));
        hmUpdateMember.put(MPSDefs.DB_LASTNAME, hmMemberDetails.get("lastname"));
        hmUpdateMember.put(MPSDefs.DB_FULLNAME, hmMemberDetails.get("fullname"));
        hmUpdateMember.put(MPSDefs.DB_PROOFING_ZIP, hmMemberDetails.get(MPSDefs.DB_PROOFING_ZIP));
        hmUpdateMember.put(MPSDefs.DB_MAILHOST, hmMemberDetails.get(MPSDefs.DB_MAILHOST));
        hmUpdateMember.put(MPSDefs.DB_MIGRATION_IND, hmMemberDetails.get(MPSDefs.DB_MIGRATION_IND));

        alUpdateMember.add(hmUpdateMember);
        hmMemberDataInput.put(MPSDefs.DB_MEMBER_TABLE, alUpdateMember);

        logger.info("{}{}DUUH.UMAD.02 : Calling memberDBHelper.processData() with input {}", sClassName, sMethodName,
                hmMemberDataInput);
        Map<String, Object> result = memberDBHelper.processData(hmMemberDataInput);
        logger.info("{}{}DUUH.UMAD.03 : Response from memberDBHelper.processData(){}", sClassName, sMethodName, result);

        return result;
    }

}
