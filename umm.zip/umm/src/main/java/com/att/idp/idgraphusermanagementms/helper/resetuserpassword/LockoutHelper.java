package com.att.idp.idgraphusermanagementms.helper.resetuserpassword;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TimeZone;

import com.att.idp.idgraphusermanagementms.helper.AbstractHelper;
import com.att.mpsys.common.utils.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.common.validators.LockOutValidation;


/**
 * LockoutHelper is a class that provides helper methods for managing lockouts.
 * It contains methods for querying lockouts, initializing lockout data, processing lockout rules, and updating lockouts.
 * This class is annotated with @Component, meaning it is an object managed by the Spring framework.
 * It uses Autowired to inject instances of LockOutValidation and MemberLockoutDbHelper.
 * The class also contains several constants and instance variables.
 *
 * @author as579x
 */
@Component
public class LockoutHelper extends AbstractHelper {
	 
	private static String sClassName = "LockoutHelper";
	
	@Autowired
	private LockOutValidation objLockOutValidation;
	
	@Autowired
	private MemberLockoutDbHelper oMPSDB_TMEMBERLOCKOUT_H;


	private static final String info = "$Id: master/com/att/mpsys/common/helpers/LockoutHelper.java v4 2020-01-30 kg852c $;" ;
	private static final Logger log = LoggerFactory.getLogger(LockoutHelper.class);
	
	private boolean bLockOutFlag = false;
	private ArrayList alAccountLockoutInterestedIdentificationType = new ArrayList();
	private ArrayList alMemberLockoutInterestedIdentificationType = new ArrayList();

	private PropertyManagerLoader propertyManagerLoader;
	public LockoutHelper(PropertyManagerLoader propertyManagerLoader) {
		this.propertyManagerLoader = propertyManagerLoader;
	}

	/**
	 * This method is responsible for querying lockout details.
	 * It takes a HashMap as input which contains the lockout details to be queried.
	 * The method logs the start of the process and the input parameters.
	 * It checks various conditions such as the presence of certain keys in the HashMap, the values of certain keys, etc.
	 * Based on these conditions, it decides whether to proceed with the querying or return a success message.
	 * If it decides to proceed with the querying, it prepares the input for the querying and makes the call.
	 * In case of any exception, it logs the error and returns an error HashMap.
	 * Finally, it logs the end of the process and the result, and returns the result HashMap.
	 *
	 * @param hmInput HashMap containing the lockout details to be queried.
	 * @return HashMap containing the result of the querying.
	 */
	public HashMap queryLockout(HashMap hmInput){
		
		final String sMethodName = ".queryLockout."; 
		
		log.info(sClassName + sMethodName + "CVS version : " + info);
		String sAppInfo = null;
		String sAppStatusCode = null;
		String sAppCategoryCode = null;
		String sAppStatusMsg = null;
		
		Date tmsStartDate = new Date();
		HashMap hmResponse = new HashMap();
		
		ArrayList alActiveList = new ArrayList();
		ArrayList alExpiredList = new ArrayList();
		ArrayList alNonExpiredNonActiveLocksList = new ArrayList();
		
		ArrayList alDBLockoutList  = new ArrayList();
		ArrayList alConfigLockIdValues = new ArrayList();
		
		HashMap hmConfigLockoutValues  = new HashMap();
		HashMap hmConfigLockoutIDValues = null;
		
		HashMap hmActive = null;
		HashMap hmExpired = null;
		HashMap hmNonExpiredNonActiveLock = null;
		
		String sConfigLockId = null;
		String sDBLockId= null;
		String sDBSetNumber = null;
		String sConfigLockType = null;
		String sDBFailedAuthCount = null;
		String sConfigAttemptAllowed = null;
		String sConfigLockoutName = null;
		String sLockoutExpiration = null;
		String sLastFailedAuth = null;
		String sReinitializeIntervalMin = null;
		
		String sMemberNum = null;
		String sAccountId= null;
		
		
		ArrayList alDBAccountLockout =  new ArrayList();
		ArrayList alDBMemberLockout = new ArrayList();
		
		//Log start time
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss");
		String tStartDate = dateFormat.format(tmsStartDate);
		log.info(sClassName + sMethodName + "LOHQL_02 : " + "Start time in LockoutHelper.queryLockout = " + tStartDate);
		log.info(sClassName + sMethodName + "HLP000 : " + "queryLockout::inputHash= " + HtmlUtils.htmlEscape(String.valueOf(hmInput)));
	
		try{

			hmResponse = validateMapInput(hmInput, CErrorDefs.ERR_SYS_APPL_NUM, " Input Hash is NULL / EMPTY ");
			if (hmResponse != null) return hmResponse;

			//Added for Augsut-Release
			alDBMemberLockout = (ArrayList) hmInput.get(CommonDefs.MEMBER_LOCKOUT);
			alDBAccountLockout = (ArrayList) hmInput.get("accountlockout");
			
			if((alDBAccountLockout == null || alDBAccountLockout.isEmpty())
					&& (alDBMemberLockout == null || alDBMemberLockout.isEmpty())){
				
				sAppInfo = "Lockout details missing in input";
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
				log.info(sClassName + sMethodName + "LOHQL_03.2 : " + sAppInfo);
				
				return hmResponse;
			}
			
			if(alDBMemberLockout != null && !alDBMemberLockout.isEmpty()){
				alDBLockoutList.addAll(alDBMemberLockout);
			}
			if(alDBAccountLockout != null && !alDBAccountLockout.isEmpty()){
				alDBLockoutList.addAll(alDBAccountLockout);
			}
			
			Iterator itDBLockoutList = alDBLockoutList.iterator();
			while(itDBLockoutList.hasNext()){
				
				sConfigLockId = null;
				sDBLockId= null;
				sDBSetNumber = null;
				sConfigLockType = null;
				sDBFailedAuthCount = null;
				sConfigAttemptAllowed = null;
				sConfigLockoutName = null;
				sLockoutExpiration = null;
				sLastFailedAuth = null;
				sReinitializeIntervalMin = null;
				sMemberNum = null;
				sAccountId= null;
				
				HashMap hmDBLockout = (HashMap) itDBLockoutList.next();
				if(hmDBLockout != null && !hmDBLockout.isEmpty()){
					
					sDBLockId = (String) hmDBLockout.get(MPSDefs.DB_LOCKOUT_ID);
					sDBSetNumber = (String) hmDBLockout.get(MPSDefs.DB_SET_NUMBER);
					sMemberNum = (String) hmDBLockout.get(MPSDefs.DB_MEMBER_NUM);
					sAccountId= (String) hmDBLockout.get(MPSDefs.DB_ACCOUNT_ID);
					
					log.info("{}{}LOHQK_03 : lockout_id and set_number from DB:: {} : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sDBLockId)) + " :" + HtmlUtils.htmlEscape(String.valueOf(sDBSetNumber)));
					log.info("{}{}LOHQK_04 : Lock Info:: {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmDBLockout)));
					
					
					if(hmConfigLockoutValues == null || hmConfigLockoutValues.isEmpty()){
						
						hmConfigLockoutValues = (HashMap) objLockOutValidation.getLockOuts(); 
						
					}

					hmResponse = validateMapInput(hmConfigLockoutValues, CErrorDefs.ERR_SYS_APPL_NUM, "Lockout Values are not loaded in Memory");
					if (hmResponse != null) return hmResponse;
					
					log.info(sClassName + sMethodName + "LOHQK_05 : " + "Config Lockout Details:: " + hmConfigLockoutValues);

					hmConfigLockoutIDValues = getLockoutIDValues(hmConfigLockoutValues, sDBLockId, sDBSetNumber);

					if(hmConfigLockoutIDValues != null && !hmConfigLockoutIDValues.isEmpty()){
						sConfigLockType =(String) hmConfigLockoutIDValues.get(MPSDefs.DB_LOCK_TYPE);
					}
					
					
					log.info(sClassName + sMethodName + "LOHQK_05.1 : " + "Config Lockout Details for Set Number " + sDBSetNumber+" ::" + hmConfigLockoutIDValues);
					
					sDBFailedAuthCount = (String) hmDBLockout.get(MPSDefs.DB_FAILED_AUTH_COUNT);
					sConfigAttemptAllowed =(String) hmConfigLockoutIDValues.get(MPSDefs.DB_ATTEMPTS_ALLOWED);
					
					if(sConfigLockType != null && sConfigLockType.trim().length() > 0
							&& sConfigLockType.equals("HARD")){
					
						int iFailedAuthCount = Integer.parseInt(sDBFailedAuthCount);
						int iAttemptAllowed = Integer.parseInt(sConfigAttemptAllowed);
						
						if(iFailedAuthCount >= iAttemptAllowed){
							
							sConfigLockoutName = (String) hmConfigLockoutIDValues.get(MPSDefs.DB_LOCKOUT_NAME);
							hmActive = buildLockoutMap(sDBLockId, sConfigLockoutName, sDBSetNumber,
									sDBFailedAuthCount, hmDBLockout, sMemberNum, sAccountId);

							if(hmActive != null && !hmActive.isEmpty()){
								alActiveList.add(hmActive);
							}
							
						}
					}else if (sConfigLockType != null && sConfigLockType.trim().length() > 0
							&& sConfigLockType.equals("SOFT")){
						
						sLockoutExpiration = (String)  hmDBLockout.get(MPSDefs.DB_LOCKOUT_EXPIRATION);
						DateFormat df = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
						
						if(sLockoutExpiration != null && sLockoutExpiration.trim().length() > 0
								&& (df.parse(sLockoutExpiration)).after(tmsStartDate)){
							
							sConfigLockoutName = (String) hmConfigLockoutIDValues.get(MPSDefs.DB_LOCKOUT_NAME);
							hmActive = buildLockoutMap(sDBLockId, sConfigLockoutName, sDBSetNumber,
									sDBFailedAuthCount, hmDBLockout, sMemberNum, sAccountId);

							if(hmActive != null && !hmActive.isEmpty()){
								alActiveList.add(hmActive);
							}
							
						}else{
							
							sLastFailedAuth = (String) hmDBLockout.get(MPSDefs.DB_LAST_FAILED_AUTH);
							
							if(sLastFailedAuth != null && sLastFailedAuth.trim().length() > 0){
								sReinitializeIntervalMin =(String)hmConfigLockoutIDValues.get(MPSDefs.DB_REINITIALIZE_INTERVAL_MINUTES);
								
								Date dLastFailedAuthDate = df.parse(sLastFailedAuth);
								
				
								long iReinitializeIntervalMin = Long.parseLong(sReinitializeIntervalMin);
								long lReinitializeTime=  iReinitializeIntervalMin * (60000);
								
								long lTotalReinitializeTime = dLastFailedAuthDate.getTime() + lReinitializeTime;
								
								Date dReinitializeDate = CommonUtil.getSQLDate(lTotalReinitializeTime);
								
								if(dReinitializeDate.before(tmsStartDate) || dReinitializeDate.equals(tmsStartDate)){
									
									sConfigLockoutName = (String) hmConfigLockoutIDValues.get(MPSDefs.DB_LOCKOUT_NAME);
									hmExpired = buildLockoutMap(sDBLockId, sConfigLockoutName, sDBSetNumber,
											sDBFailedAuthCount, hmDBLockout, sMemberNum, sAccountId);

									if(hmExpired != null && !hmExpired.isEmpty()){
										alExpiredList.add(hmExpired);
									}
									
								}else{
									sConfigLockoutName = (String) hmConfigLockoutIDValues.get(MPSDefs.DB_LOCKOUT_NAME);
									hmNonExpiredNonActiveLock = buildLockoutMap(sDBLockId, sConfigLockoutName, sDBSetNumber,
											sDBFailedAuthCount, hmDBLockout, sMemberNum, sAccountId);

									if(hmNonExpiredNonActiveLock != null && !hmNonExpiredNonActiveLock.isEmpty()){
										alNonExpiredNonActiveLocksList.add(hmNonExpiredNonActiveLock);
									}
								}
							}else{
								sConfigLockoutName = (String) hmConfigLockoutIDValues.get(MPSDefs.DB_LOCKOUT_NAME);
								hmNonExpiredNonActiveLock = buildLockoutMap(sDBLockId, sConfigLockoutName, sDBSetNumber,
										sDBFailedAuthCount, hmDBLockout, sMemberNum, sAccountId);

								if(hmNonExpiredNonActiveLock != null && !hmNonExpiredNonActiveLock.isEmpty()){
									alNonExpiredNonActiveLocksList.add(hmNonExpiredNonActiveLock);
								}
							}
							
						}
					}
				}
			}
			
			if((alActiveList == null || alActiveList.isEmpty()) 
				&& (alExpiredList == null || alExpiredList.isEmpty())
				&& (alNonExpiredNonActiveLocksList == null || alNonExpiredNonActiveLocksList.isEmpty())){
				
				sAppInfo = "No LockId found in DB";
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
				log.info(sClassName + sMethodName + "LOHQL_05.1 : " + sAppInfo);
				
				return hmResponse;
			}
			
			hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "");
			hmResponse.put(CommonDefs.ACTIVE_LOCKS, alActiveList);
			hmResponse.put(CommonDefs.EXPIRED_LOCKS, alExpiredList);
			hmResponse.put("nonExpiredNonActiveLocks", alNonExpiredNonActiveLocksList);
			
		}catch(Exception e){
			hmResponse = CommonErrorMap.makeExceptionMap(e);
			log.error(sClassName + sMethodName + "LOHQL_05.1 : " + " Error::" + e.getMessage());
			log.error(sClassName + sMethodName + "LOH_06.1 : " + "Exception = {}", e);
    		

    	} finally {
    		
    		log.info(sClassName + sMethodName + "HLP999 : response : " + HtmlUtils.htmlEscape(String.valueOf(hmResponse)));
    	}
		
		return hmResponse;
	}

	private HashMap getLockoutIDValues(HashMap hmConfigLockoutValues, String sDBLockId, String sDBSetNumber) {
		HashMap hmConfigLockoutIDValues;
		ArrayList alConfigLockIdValues;
		alConfigLockIdValues = (ArrayList) hmConfigLockoutValues.get(sDBLockId);
		hmConfigLockoutIDValues = CommonUtil.getHashMap();
		if(alConfigLockIdValues != null && !alConfigLockIdValues.isEmpty()){
			Iterator itConfigLockIdValues = alConfigLockIdValues.iterator();
			while(itConfigLockIdValues.hasNext()){

				HashMap hmTemp = (HashMap) itConfigLockIdValues.next();
				if(hmTemp != null && !hmTemp.isEmpty()){

					String sConfigSetNumber = (String) hmTemp.get(MPSDefs.DB_SET_NUMBER);
					if(sConfigSetNumber != null && sConfigSetNumber.trim().length() > 0
							&& sConfigSetNumber.equals(sDBSetNumber)){
						hmConfigLockoutIDValues = hmTemp;
						break;
					}
				}
			}
		}
		return hmConfigLockoutIDValues;
	}

	private  HashMap buildLockoutMap(String sDBLockId, String sConfigLockoutName, String sDBSetNumber,
									 String sDBFailedAuthCount, HashMap hmDBLockout, String sMemberNum, String sAccountId) {
		HashMap lockoutMap = CommonUtil.getHashMap();
		lockoutMap.put(MPSDefs.DB_LOCKOUT_ID, sDBLockId);
		lockoutMap.put(MPSDefs.DB_LOCKOUT_NAME, sConfigLockoutName);
		lockoutMap.put(MPSDefs.DB_SET_NUMBER, sDBSetNumber);
		lockoutMap.put(MPSDefs.DB_FAILED_AUTH_COUNT, sDBFailedAuthCount);
		lockoutMap.put(MPSDefs.DB_LAST_FAILED_AUTH,(String) hmDBLockout.get(MPSDefs.DB_LAST_FAILED_AUTH) );
		lockoutMap.put(MPSDefs.DB_LOCKOUT_EXPIRATION, (String) hmDBLockout.get(MPSDefs.DB_LOCKOUT_EXPIRATION));

		if(sMemberNum != null && sMemberNum.trim().length() > 0){
			lockoutMap.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);
		}
		if(sAccountId != null && sAccountId.trim().length() > 0){
			lockoutMap.put(MPSDefs.DB_ACCOUNT_ID , sAccountId);
		}

		return lockoutMap;
	}

	/**
	 * initialize method
	 */
	public void initialize(){
		this.bLockOutFlag=false;
		this.alAccountLockoutInterestedIdentificationType=new ArrayList();
		this.alMemberLockoutInterestedIdentificationType = new ArrayList();
	}
	

	/**
	 * This method processes the lockout rules based on the input parameters.
	 * It takes an ArrayList of lockout details, a validation status, a handle, a domain, and an identification type as input.
	 * The method logs the start of the process and the input parameters.
	 * It checks various conditions such as the presence of certain keys in the ArrayList, the values of certain keys, etc.
	 * Based on these conditions, it decides whether to proceed with the lockout operations or return a success message.
	 * If it decides to proceed with the lockout operations, it prepares the input for the operations and makes the call.
	 * In case of any exception, it logs the error and returns an error HashMap.
	 * Finally, it logs the end of the process and the result, and returns the result HashMap.
	 *
	 * @param alLockInp ArrayList containing the lockout details.
	 * @param sValidationStatus String representing the validation status.
	 * @param sHandle String representing the handle.
	 * @param sDomain String representing the domain.
	 * @param sIdentificationType String representing the identification type.
	 * @return HashMap containing the result of the lockout process.
	 */
	public HashMap processLockoutRules(ArrayList alLockInp, String sValidationStatus,String sHandle, String sDomain, String sIdentificationType){

		
		final String sMethodName = ".processLockoutRules."; 
		String sAppInfo = null;
		String sAppStatusCode = null;
		String sAppCategoryCode = null;
		String sAppStatusMsg = null;
		
		
		HashMap hmResponse = new HashMap();
		
		ArrayList alConfigLockIdValues = new ArrayList();
		ArrayList alStatus = null;
		
		HashMap hmConfigLockoutValues  = new HashMap();
		HashMap hmConfigLockoutIDValues = new HashMap();
		
		HashMap hmReturnStatus = new HashMap();
		HashMap hmStatus = null;
		
		String sConfigLockId = null;
		String sDBLockId= null;
		String sDBSetNumber = null;
		String sConfigLockType = null;
		String sDBFailedAuthCount = null;
		String sConfigAttemptAllowed = null;
		String sConfigLockoutName = null;
		String sLockoutExpiration = null;
		String sLastFailedAuth = null;
		String sReinitializeIntervalMin = null;
		String sConfigLockoutMin = null;
		String sDBLockoutName = null;
		
		String sMemberNum=null;
		String sAccountId=null;
		
		HashMap hmUpdate = null;
		HashMap hmInsert = null;
		HashMap hmDelete = null;
		
		boolean bReinitializeLock = false;
		ArrayList alLockData = new ArrayList();
		
		log.info(StringUtils.normalizeSpace(sClassName + sMethodName + "PLR_01 : " + "processLockoutRules::inputHash= " + String.valueOf(alLockInp)));
		try{
			
			if(alLockInp == null || alLockInp.isEmpty()){

				sAppInfo= "Lock Infomation is Null / Empty in input request";
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
				log.info(sClassName + sMethodName + "PLR_01.1 : " + sAppInfo);
				return hmResponse;
			}

			Date today = new Date();
			log.info(sClassName + sMethodName + "PLR_01.2 : " + today);
			TimeZone est = TimeZone.getTimeZone("CST");
			SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy HH:mm:ss");
			sdf.setTimeZone(est);
			String sCSTDate = sdf.format(today);
			SimpleDateFormat cstDateFormat = new SimpleDateFormat("MMddyyyy HH:mm:ss");
			Date currentDate = cstDateFormat.parse(sCSTDate);
			
			
			//Date currentDate = new Date();
			DateFormat df = new SimpleDateFormat("MMddyyyy HH:mm:ss");
			
			Iterator itLockInp = alLockInp.iterator();
			while(itLockInp.hasNext()){
				
				sConfigLockId = null;
				sDBLockId= null;
				sDBSetNumber = null;
				sConfigLockType = null;
				sDBFailedAuthCount = null;
				sConfigAttemptAllowed = null;
				sConfigLockoutName = null;
				sLockoutExpiration = null;
				sLastFailedAuth = null;
				sReinitializeIntervalMin = null;
				sConfigLockoutMin = null;
				bReinitializeLock = false;
				
				hmUpdate = CommonUtil.getHashMap();
				hmInsert = CommonUtil.getHashMap();
				hmDelete = CommonUtil.getHashMap();
				
				HashMap hmLockInp = (HashMap) itLockInp.next();
				if(hmLockInp != null && !hmLockInp.isEmpty()){
					
					//Added for August-2010 Release
					sMemberNum = (String) hmLockInp.get(MPSDefs.DB_MEMBER_NUM);
					sAccountId = (String) hmLockInp.get(MPSDefs.DB_ACCOUNT_ID);
					
					if(sValidationStatus != null && sValidationStatus.trim().length() > 0
							&& sValidationStatus.equals("FAILURE")){
						
						sDBLockoutName = (String) hmLockInp.get(MPSDefs.DB_LOCKOUT_NAME);
						sDBLockId = (String) hmLockInp.get(MPSDefs.DB_LOCKOUT_ID);
						
						if((sDBLockoutName== null || sDBLockoutName.trim().length() == 0)
								&& (sDBLockId == null || sDBLockId.trim().length() == 0)){
							
							sAppInfo = "If it is first time failure then either lockout_id or lockout_name is required";
							hmResponse =CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
							log.info(sClassName + sMethodName + "LOHQL_01.3 : " + sAppInfo);
							return hmResponse;
							
						}
						
						if(sDBLockId == null || sDBLockId.trim().length() == 0){
							sDBLockId =(String) objLockOutValidation.getLockOutIdByName(sDBLockoutName);
							log.info(StringUtils.normalizeSpace(sClassName + sMethodName + "LOHQL_01.03 : lockout_id " + sDBLockId));
							
							if(sDBLockId == null || sDBLockId.trim().length() == 0)
							{
								sAppInfo = "LockOutValidation.getLockOutIdByName returned null lockout_id";
								hmResponse =CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
								log.info(sClassName + sMethodName + "DB_H_UUFL_03 : " + sAppInfo);
								return hmResponse;
							}
							hmLockInp.put(MPSDefs.DB_LOCKOUT_ID, sDBLockId);
						}
						
						if(sDBLockoutName == null || sDBLockoutName.trim().length() == 0){
							sDBLockoutName =(String) objLockOutValidation.getLockOutNameById(sDBLockId);
							log.info(sClassName + sMethodName + "LOHQL_01.003 : lockout_name " + sAppInfo);
							
							if(sDBLockoutName == null || sDBLockoutName.trim().length() == 0)
							{
								sAppInfo = "LockOutValidation.getLockOutNameById returned null lockout_name";
								hmResponse =CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
								log.info(sClassName + sMethodName + "LOHQL_03.003 : " + sAppInfo);
								return hmResponse;
							}
							hmLockInp.put(MPSDefs.DB_LOCKOUT_NAME, sDBLockoutName);
						}
						
						sDBSetNumber = (String) hmLockInp.get(MPSDefs.DB_SET_NUMBER);
						sDBFailedAuthCount = (String) hmLockInp.get(MPSDefs.DB_FAILED_AUTH_COUNT);
						
						if((sDBSetNumber == null || sDBSetNumber.trim().length() == 0)
								&& (sDBFailedAuthCount == null || sDBFailedAuthCount.trim().length() == 0)){
						    sDBSetNumber="1";
						}
						
						log.info(StringUtils.normalizeSpace(sClassName + sMethodName + "PLR_04 : lockout_id and set_number from DB:: " + String.valueOf(sDBLockId) + " :" + String.valueOf(sDBSetNumber)));
						
						if(hmConfigLockoutValues == null || hmConfigLockoutValues.isEmpty()){
							
							hmConfigLockoutValues = (HashMap) objLockOutValidation.getLockOuts(); 
						}

						hmResponse = validateMapInput(hmConfigLockoutValues, CErrorDefs.ERR_SYS_APPL_NUM, "Lockout Values are not loaded in Memory");
						if (hmResponse != null) return hmResponse;

						log.info(sClassName + sMethodName + "PLR_05 : Config Lockout Details::" + hmConfigLockoutValues);

						hmConfigLockoutIDValues = getLockoutIDValues(hmConfigLockoutValues, sDBLockId, sDBSetNumber);

						if(hmConfigLockoutIDValues != null && !hmConfigLockoutIDValues.isEmpty()){
							sConfigLockType =(String) hmConfigLockoutIDValues.get(MPSDefs.DB_LOCK_TYPE);
							sConfigAttemptAllowed = (String) hmConfigLockoutIDValues.get(MPSDefs.DB_ATTEMPTS_ALLOWED);
						}
						
						log.info(StringUtils.normalizeSpace(sClassName + sMethodName + "PLR_05.1 : Config Lockout Details for Set Number " + String.valueOf(sDBSetNumber)+" ::" + hmConfigLockoutIDValues));
						
						if(sDBFailedAuthCount == null || sDBFailedAuthCount.trim().length() == 0){

							hmInsert = buildOperationMap(sIdentificationType, hmLockInp, sDBLockId, "insert", "1", "0");

							hmStatus = buildStatusMap(sHandle, sDomain, sIdentificationType,
									sMemberNum, sAccountId, (String) hmLockInp.get(MPSDefs.DB_LOCKOUT_NAME),
									"1", "1", df.format(currentDate));

							alStatus = buildStatusList(hmStatus);

						}else{
							
							sLastFailedAuth = (String) hmLockInp.get(MPSDefs.DB_LAST_FAILED_AUTH);
							
							if(sLastFailedAuth != null && sLastFailedAuth.trim().length() > 0){
								
								sReinitializeIntervalMin =(String)hmConfigLockoutIDValues.get(MPSDefs.DB_REINITIALIZE_INTERVAL_MINUTES);
								
								if(sReinitializeIntervalMin == null || sReinitializeIntervalMin.trim().length() == 0){
									sReinitializeIntervalMin="0";
								}
								
								Date dLastFailedAuthDate = df.parse(sLastFailedAuth);
								
								// 1804 : Fixing SONAR Violations
								long iReinitializeIntervalMin = Long.parseLong(sReinitializeIntervalMin);
								long lReinitializeTime=  iReinitializeIntervalMin * (60000);
								
								long lTotalReinitializeTime = dLastFailedAuthDate.getTime() + lReinitializeTime;
								
								Date dReinitializeDate = CommonUtil.getSQLDate(lTotalReinitializeTime);
								
								if((dReinitializeDate.before(currentDate))
										&& (sConfigLockType != null && sConfigLockType.trim().length() > 0
												&& sConfigLockType.equals("SOFT"))){
									
									bReinitializeLock = true;
								}
							}
							
						}
						
						if(sDBFailedAuthCount == null || sDBFailedAuthCount.trim().length() == 0){
							sDBFailedAuthCount="0";
						}
						int iFailedAuthCount = Integer.parseInt(sDBFailedAuthCount);
						int iAttemptAllowed=0;
						if(sConfigAttemptAllowed != null && sConfigAttemptAllowed.trim().length() > 0){
							iAttemptAllowed = Integer.parseInt(sConfigAttemptAllowed);
						}
						
						if(sConfigAttemptAllowed != null && sConfigAttemptAllowed.trim().length() > 0
								&&iFailedAuthCount >= iAttemptAllowed 
								&& sConfigLockType != null && sConfigLockType.trim().length() > 0
								&& sConfigLockType.equals("SOFT")){
							
							boolean bDiffSetExists = false;
							int iSetNumber = Integer.parseInt(sDBSetNumber);
							iSetNumber = iSetNumber + 1;
							
							Iterator itLockIdValues = alConfigLockIdValues.iterator();
							while(itLockIdValues.hasNext()){
								
								hmConfigLockoutIDValues = (HashMap) itLockIdValues.next();
								if(hmConfigLockoutIDValues != null && !hmConfigLockoutIDValues.isEmpty()){
									
									String sConfigSetNumber = (String) hmConfigLockoutIDValues.get(MPSDefs.DB_SET_NUMBER);
									if(sConfigSetNumber != null && sConfigSetNumber.trim().length() > 0
											&& sConfigSetNumber.equals(iSetNumber+"")){
										bDiffSetExists=true;
										break;
									}
								}
							}
							
							if(bDiffSetExists){
								
								hmUpdate = buildOperationMap(sIdentificationType, hmLockInp, sDBLockId,
										"update", iSetNumber+"", "0");

								hmStatus = buildStatusMap(sHandle, sDomain, sIdentificationType,
										sMemberNum, sAccountId, (String) hmLockInp.get(MPSDefs.DB_LOCKOUT_NAME),
										"1", iSetNumber+"", df.format(currentDate));

								alStatus = buildStatusList(hmStatus);

							}else{
								
								hmInsert = buildOperationMap(sIdentificationType, hmLockInp, sDBLockId,
										"insert", "1", "0");

								hmStatus = buildStatusMap(sHandle, sDomain, sIdentificationType,
										sMemberNum, sAccountId, (String) hmLockInp.get(MPSDefs.DB_LOCKOUT_NAME),
										"1", "1", df.format(currentDate));

								alStatus = buildStatusList(hmStatus);

								hmDelete = buildOperationMap(sIdentificationType, hmLockInp, sDBLockId,
										"delete", sDBSetNumber, "0");
							}
						}
						
					
						if(sConfigAttemptAllowed != null && sConfigAttemptAllowed.trim().length() > 0
								&& iAttemptAllowed != 0
								&& iFailedAuthCount != 0
								&& iFailedAuthCount < iAttemptAllowed 
								&& sConfigLockType != null && sConfigLockType.trim().length() > 0
								&& sConfigLockType.equals("SOFT")){
							
							
							if(bReinitializeLock){
								
								hmInsert = buildOperationMap(sIdentificationType, hmLockInp, sDBLockId,
										"insert", "1", "0");

								hmStatus = buildStatusMap(sHandle, sDomain, sIdentificationType,
										sMemberNum, sAccountId, (String) hmLockInp.get(MPSDefs.DB_LOCKOUT_NAME),
										"1", "1", df.format(currentDate));

								alStatus = buildStatusList(hmStatus);

								hmDelete = buildOperationMap(sIdentificationType, hmLockInp, sDBLockId,
										"delete", sDBSetNumber, "0");

							}else{

								hmUpdate = buildOperationMap(sIdentificationType, hmLockInp, sDBLockId,
										"update", sDBSetNumber, sDBFailedAuthCount);

								hmStatus = buildStatusMap(sHandle, sDomain, sIdentificationType,
										sMemberNum, sAccountId, (String) hmLockInp.get(MPSDefs.DB_LOCKOUT_NAME),
										(Integer.parseInt(sDBFailedAuthCount) + 1)+"", sDBSetNumber, df.format(currentDate));

								alStatus = buildStatusList(hmStatus);
								
							}
							
						}
						
						
						if(hmInsert != null && !hmInsert.isEmpty()){
							
							String sInsertFailedAuthCount = (String) hmInsert.get(MPSDefs.DB_FAILED_AUTH_COUNT);
							int iInsertFailedAuthCount = 0;
							if(sInsertFailedAuthCount != null && sInsertFailedAuthCount.trim().length() > 0){
								iInsertFailedAuthCount = Integer.parseInt(sInsertFailedAuthCount);
							}
							iInsertFailedAuthCount = iInsertFailedAuthCount + 1;
							hmInsert.put(MPSDefs.DB_FAILED_AUTH_COUNT, iInsertFailedAuthCount+"");
							hmInsert.put(MPSDefs.DB_LAST_FAILED_AUTH, df.format(currentDate));
							
							
							sConfigAttemptAllowed = (String) hmConfigLockoutIDValues.get(MPSDefs.DB_ATTEMPTS_ALLOWED);
							int iConfigAttemptAllowed = Integer.parseInt(sConfigAttemptAllowed);
							int iRemainingAttempts = iConfigAttemptAllowed - iInsertFailedAuthCount;
							hmStatus.put("authAttemptsRemaining",iRemainingAttempts+"");
							
							
						}
						
						if(hmUpdate != null && !hmUpdate.isEmpty()){
							
							String sUpdateFailedAuthCount = (String) hmUpdate.get(MPSDefs.DB_FAILED_AUTH_COUNT);
							int iUpdateFailedAuthCount = 0;
							if(sUpdateFailedAuthCount != null && sUpdateFailedAuthCount.trim().length() > 0){
								iUpdateFailedAuthCount = Integer.parseInt(sUpdateFailedAuthCount);
							}
							iUpdateFailedAuthCount = iUpdateFailedAuthCount + 1;

							hmUpdate.put(MPSDefs.DB_FAILED_AUTH_COUNT, iUpdateFailedAuthCount+"");
							sLastFailedAuth = df.format(currentDate);
							hmUpdate.put(MPSDefs.DB_LAST_FAILED_AUTH, sLastFailedAuth);
							
							sConfigAttemptAllowed = (String) hmConfigLockoutIDValues.get(MPSDefs.DB_ATTEMPTS_ALLOWED);
							int iConfigAttemptAllowed = Integer.parseInt(sConfigAttemptAllowed);
							
							int iRemainingAttempts = iConfigAttemptAllowed - iUpdateFailedAuthCount;
							hmStatus.put("authAttemptsRemaining",iRemainingAttempts+"");
							
							if(iUpdateFailedAuthCount >= iConfigAttemptAllowed ){
								
								if(sConfigLockType != null && sConfigLockType.trim().length() > 0
										&& sConfigLockType.equals("SOFT")){
									sConfigLockoutMin = (String) hmConfigLockoutIDValues.get(MPSDefs.DB_LOCKOUT_MINUTES);
									
									if(sConfigLockoutMin != null && sConfigLockoutMin.trim().length() > 0){
										// 1804 : Fixing SONAR Violations
										Long iLockoutMin = Long.parseLong(sConfigLockoutMin);
										long lLockOutTime = iLockoutMin * (60000);
										
										long currentTime = currentDate.getTime();
										long expirationTime = currentTime + lLockOutTime;
										
										Date dExpirationDate = CommonUtil.getSQLDate(expirationTime);
										
										sLockoutExpiration = df.format(dExpirationDate);
										hmUpdate.put(MPSDefs.DB_LOCKOUT_EXPIRATION, sLockoutExpiration);
										hmStatus.put(MPSDefs.DB_LOCKOUT_EXPIRATION, sLockoutExpiration);
									}else{
										
										sLockoutExpiration = df.format(currentDate);
										hmUpdate.put(MPSDefs.DB_LOCKOUT_EXPIRATION, sLockoutExpiration);
										hmStatus.put(MPSDefs.DB_LOCKOUT_EXPIRATION, sLockoutExpiration);
									}
								}
								this.bLockOutFlag =true;
									
							}
						}
						
					}
					
					if(sValidationStatus != null && sValidationStatus.trim().length() > 0
							&& sValidationStatus.equals("SUCCESS")){
						
						sDBLockId = (String) hmLockInp.get(MPSDefs.DB_LOCKOUT_ID);
						sDBSetNumber = (String) hmLockInp.get(MPSDefs.DB_SET_NUMBER);
						sDBFailedAuthCount = (String) hmLockInp.get(MPSDefs.DB_FAILED_AUTH_COUNT);
						
						if(sDBFailedAuthCount != null && sDBFailedAuthCount.trim().length() > 0){

							hmDelete = buildOperationMap(sIdentificationType, hmLockInp, sDBLockId,
									"delete", sDBSetNumber, "0");
						}
					}
					
					if(hmDelete != null && !hmDelete.isEmpty()){
						alLockData.add(hmDelete);
					}
					if(hmInsert != null && !hmInsert.isEmpty()){
						alLockData.add(hmInsert);
					}
					if(hmUpdate != null && !hmUpdate.isEmpty()){
						alLockData.add(hmUpdate);
					}
					
					if(alStatus != null && !alStatus.isEmpty()){
						
						hmReturnStatus.put((String)hmLockInp.get(MPSDefs.DB_LOCKOUT_NAME), alStatus);
					}
				}
								
			}
			
			log.info(sClassName + sMethodName + "PLR_01.2 : " + "Lock Info to Update " + alLockData);
			hmResponse= CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "");
			hmResponse.put("lockInfo", alLockData);
			hmResponse.put("status", hmReturnStatus);
					
		}catch(Exception e){
			hmResponse = CommonErrorMap.makeExceptionMap(e);
			
			log.error(sClassName + sMethodName + "LOHUL_05.1 : " + " Error::" + e.getMessage());
			log.error(sClassName + sMethodName + "LOHUL_06.1 : " + "Exception = {}", e);

    	}
		return hmResponse;
	
	}

	private HashMap buildOperationMap(String sIdentificationType, HashMap hmLockInp, String sDBLockId,
													  String operation, String setNumber, String failedAuthCount) {
		HashMap operationMap;
		operationMap = CommonUtil.getHashMap();

		operationMap.put(MPSDefs.DB_SET_NUMBER, setNumber);
		if (!operation.equals("delete")) {
			operationMap.put(MPSDefs.DB_FAILED_AUTH_COUNT, failedAuthCount);
		}
		operationMap.put("operation", operation);
		operationMap.put(MPSDefs.DB_IDENTIFICATION_TYPE, sIdentificationType);
		operationMap.put(MPSDefs.DB_ACCOUNT_ID, hmLockInp.get(MPSDefs.DB_ACCOUNT_ID));
		operationMap.put(MPSDefs.DB_MEMBER_NUM, hmLockInp.get(MPSDefs.DB_MEMBER_NUM));
		operationMap.put(MPSDefs.DB_LOCKOUT_ID, sDBLockId);
		return operationMap;
	}

	private ArrayList buildStatusList(HashMap hmStatus) {
		ArrayList alStatus = CommonUtil.getArrayList();
		alStatus.add(hmStatus);
		return alStatus;
	}

	private HashMap buildStatusMap(String sHandle, String sDomain, String sIdentificationType, String sMemberNum,
								   String sAccountId, String lockoutName, String failedAuthCount, String setNumber, String timestamp) {
		HashMap hmStatus = CommonUtil.getHashMap();

		if(sHandle != null && sHandle.trim().length() > 0){
			hmStatus.put(CommonDefs.HANDLE, sHandle);
		}
		if(sDomain != null && sDomain.trim().length() > 0){
			hmStatus.put(CommonDefs.DOMAIN, sDomain);
		}

		if(sMemberNum != null && sMemberNum.trim().length() > 0){
			hmStatus.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);
		}

		if(sAccountId != null && sAccountId.trim().length() > 0){
			hmStatus.put(MPSDefs.DB_ACCOUNT_ID, sAccountId);
		}

		hmStatus.put(MPSDefs.DB_IDENTIFICATION_TYPE, sIdentificationType);
		hmStatus.put(MPSDefs.DB_LOCKOUT_NAME, lockoutName);
		hmStatus.put(MPSDefs.DB_FAILED_AUTH_COUNT, failedAuthCount);
		hmStatus.put(MPSDefs.DB_SET_NUMBER, setNumber);
		hmStatus.put(MPSDefs.DB_LOCKOUT_TIMESTAMP, timestamp);

		return hmStatus;
	}

	/**
	 * This method is responsible for updating the lockout details.
	 * It takes a HashMap as input which contains the lockout details to be updated.
	 * The method logs the start of the process and the input parameters.
	 * It checks various conditions such as the presence of certain keys in the HashMap, the values of certain keys, etc.
	 * Based on these conditions, it decides whether to proceed with the updating or return a success message.
	 * If it decides to proceed with the updating, it prepares the input for the updating and makes the call.
	 * In case of any exception, it logs the error and returns an error HashMap.
	 * Finally, it logs the end of the process and the result, and returns the result HashMap.
	 *
	 * @param hmInput HashMap containing the lockout details to be updated.
	 * @return HashMap containing the result of the updating.
	 */
	public HashMap updateLockout (HashMap hmInput) {
		
		final String sMethodName = ".updateLockout."; 
		
		String sAppInfo = null;
		String sAppStatusCode = null;
		String sAppCategoryCode = null;
		String sAppStatusMsg = null;
		
		Date tmsStartDate = new Date();
		HashMap hmResponse = new HashMap();
		HashMap hmReturnStatus = new HashMap();
		
		ArrayList alDBActiveLockpoutList = new ArrayList();
		ArrayList alDBExpiredlockoutList = new ArrayList();
		ArrayList alDBNonExpiredNonActiveLockoutList = new ArrayList();
		ArrayList alNewLock = new ArrayList();
		
		ArrayList alDBLockoutList  = new ArrayList();
		ArrayList alConfigLockIdValues = new ArrayList();
		
		HashMap hmConfigLockoutValues  = new HashMap();
		HashMap hmConfigLockoutIDValues = new HashMap();
		
		String sValidationStatus = null;
		String sHandle = null;
		String sDomain = null;
		String sCallingSystemId = null;
		String sIdentificationType = null;
		
		ArrayList alMPSData = new ArrayList();
		ArrayList alExpiredData = new ArrayList();
		ArrayList alNonExpiredNonActiveData = new ArrayList();
		ArrayList alInitialLock = new ArrayList();
		
		boolean bDoNotUpdateMPS=true;
		
		
		
		//Log start time
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss");
		String tStartDate = dateFormat.format(tmsStartDate);
		log.info(sClassName + sMethodName + "LOHUL_01 : " + "Start time in LockoutHelper.updatelockout = " + tStartDate);
		log.info(StringUtils.normalizeSpace(sClassName + sMethodName + "HLP000 : " + "updateLockout::inputHash= " + String.valueOf(hmInput)));
		
		
		try{
			hmResponse = validateMapInput(hmInput, CErrorDefs.ERR_SYS_APPL_NUM, " Input Hash is NULL / EMPTY ");
			if (hmResponse != null) return hmResponse;

			this.initialize();
			
			sHandle = (String) hmInput.get(CommonDefs.HANDLE);
			sDomain = (String) hmInput.get(CommonDefs.DOMAIN);
			sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			
			hmResponse=RILUtil.getKeyValueAsArrayList("AccountLockoutInterestedIdentificationType","|", log);

			HashMap result = validateMapInput(hmResponse, CErrorDefs.ERR_SYS_APPL_NUM, " RILUtil.getKeyValueAsArrayList response is NULL / EMPTY ");
			if (result != null) return result;

				sAppCategoryCode = (String) hmResponse.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
				sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
				
				if(sAppCategoryCode != null && sAppCategoryCode.trim().length() > 0
						&& !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)){
					sAppInfo=(String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
					log.info(sClassName + sMethodName + "LOHUL_04.2.1 : " + HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
					return hmResponse;
			 }
			 this.alAccountLockoutInterestedIdentificationType = (ArrayList) hmResponse.get("AccountLockoutInterestedIdentificationType");
			 log.info(sClassName + sMethodName + "LOHUL_04.2.2 : " + "ACCOUNTLOCKOUT Interested IdentificationType: " + HtmlUtils.htmlEscape(String.valueOf(this.alAccountLockoutInterestedIdentificationType)));
			 hmResponse=RILUtil.getKeyValueAsArrayList("MemberLockoutInterestedIdentificationType","|", log);

			result = validateMapInput(hmResponse, CErrorDefs.ERR_SYS_APPL_NUM, " RILUtil.getKeyValueAsArrayList response is NULL / EMPTY ");
			if (result != null) return result;

				sAppCategoryCode = (String) hmResponse.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
				sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
				
				if(sAppCategoryCode != null && sAppCategoryCode.trim().length() > 0
						&& !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)){
					sAppInfo=(String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
					log.info(sClassName + sMethodName + "LOHUL_04.2.6 : " + HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
					return hmResponse;
			 }
				this.alMemberLockoutInterestedIdentificationType = (ArrayList) hmResponse.get("MemberLockoutInterestedIdentificationType");
				log.info(sClassName + sMethodName + "LOHUL_04.2.4 : " + "MEMBERLOCKOUT Interested IdentificationType: " + this.alMemberLockoutInterestedIdentificationType);
				
			
			//Added for August-2010 Relese
			sIdentificationType = (String) hmInput.get("identificationType");
			
			if(sIdentificationType != null && sIdentificationType.trim().length() > 0){
				
				if(!alMemberLockoutInterestedIdentificationType.contains(sIdentificationType)
				        && !alAccountLockoutInterestedIdentificationType.contains(sIdentificationType)){
					sAppInfo = " Identification Type should be one of:: " +alMemberLockoutInterestedIdentificationType+" and "+ alAccountLockoutInterestedIdentificationType;
	    			hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
	    			log.info(sClassName + sMethodName + "LOHUL_03.1 : " + HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
	    			return hmResponse;
				}
			}else{
				sIdentificationType="MID";
			}
			
			alDBActiveLockpoutList = (ArrayList)  hmInput.get(CommonDefs.ACTIVE_LOCKS);
			alDBExpiredlockoutList = (ArrayList)  hmInput.get(CommonDefs.EXPIRED_LOCKS);
			alDBNonExpiredNonActiveLockoutList = (ArrayList) hmInput.get("nonExpiredNonActiveLocks");
			alNewLock = (ArrayList) hmInput.get("newLock");
			
			if((alDBActiveLockpoutList == null || alDBActiveLockpoutList.isEmpty())
					&& (alDBExpiredlockoutList == null || alDBExpiredlockoutList.isEmpty())
					&& (alDBNonExpiredNonActiveLockoutList == null || alDBNonExpiredNonActiveLockoutList.isEmpty())
					&& (alNewLock == null || alNewLock.isEmpty())){
				
				sAppInfo ="Lock Information missing in Input Request";
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
				log.info(sClassName + sMethodName + "LOHUL_03 : " + sAppInfo);
				return hmResponse;
			}
			
			sValidationStatus = (String) hmInput.get(CommonDefs.VALIDATION_STATUS);
			if(sValidationStatus == null || sValidationStatus.trim().length() == 0){
				sAppInfo ="Validation Status is required";
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
				log.info(sClassName + sMethodName + "LOHUL_04 : " + sAppInfo);
				return hmResponse;
			}
			
			if(alDBActiveLockpoutList != null && !alDBActiveLockpoutList.isEmpty()){
				
				hmResponse=this.processLockoutRules(alDBActiveLockpoutList, sValidationStatus,sHandle, sDomain, sIdentificationType);

				result = validateMapInput(hmResponse, CErrorDefs.ERR_SYS_APPL_NUM, " processLockoutRules response is NULL / EMPTY ");
				if (result != null) return result;

				sAppCategoryCode = (String) hmResponse.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
				sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
				
				if(sAppCategoryCode != null && sAppCategoryCode.trim().length() > 0
						&& !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)){
					sAppInfo=(String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
					log.info("{}{}LOHUL_04.2 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
					return hmResponse;
				}
				
				
				log.debug(sClassName + sMethodName + "LOHUL_02.2 : Response from processLockoutHelper for ActiveLock " + hmResponse);
				
				alMPSData = (ArrayList) hmResponse.get("lockInfo");
				hmReturnStatus = (HashMap)hmResponse.get("status");
			}
			
			if(alDBExpiredlockoutList != null && !alDBExpiredlockoutList.isEmpty()){
				
				hmResponse=this.processLockoutRules(alDBExpiredlockoutList, sValidationStatus, sHandle, sDomain,sIdentificationType);

				result = validateMapInput(hmResponse, CErrorDefs.ERR_SYS_APPL_NUM, " processLockoutRules response is NULL / EMPTY ");
				if (result != null) return result;

				sAppCategoryCode = (String) hmResponse.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
				sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
				
				if(sAppCategoryCode != null && sAppCategoryCode.trim().length() > 0
						&& !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)){
					sAppInfo=(String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
					log.info(sClassName + sMethodName + "LOHUL_04.4 : " + HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
					return hmResponse;
				}
				
				log.debug(sClassName + sMethodName + "LOHUL_02.3 : Response from processLockoutHelper for ExpiredLock " + hmResponse);
				
				alExpiredData = (ArrayList) hmResponse.get("lockInfo");
				
				if(alMPSData == null){
					alMPSData =  new ArrayList();
				}
				
				if(alExpiredData != null && !alExpiredData.isEmpty()
						&& alMPSData != null){
					alMPSData.addAll(alExpiredData);
				}
				
				HashMap hmStatus = (HashMap) hmResponse.get("status");
				if(hmStatus != null && !hmStatus.isEmpty()){
					hmReturnStatus.putAll(hmStatus);
				}
			}
			
			if(alDBNonExpiredNonActiveLockoutList != null && !alDBNonExpiredNonActiveLockoutList.isEmpty()){
				
				log.debug(sClassName + sMethodName + "LOHUL_02.4 : Calling processLockoutHelper for NonExpiredNonActivelock");
				
				
				hmResponse=this.processLockoutRules(alDBNonExpiredNonActiveLockoutList, sValidationStatus, sHandle, sDomain,sIdentificationType);

				result = validateMapInput(hmResponse, CErrorDefs.ERR_SYS_APPL_NUM, " processLockoutRules response is NULL / EMPTY ");
				if (result != null) return result;

				sAppCategoryCode = (String) hmResponse.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
				sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
				
				if(sAppCategoryCode != null && sAppCategoryCode.trim().length() > 0
						&& !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)){
					sAppInfo=(String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
					log.info(sClassName + sMethodName + "LOHUL_04.6 : " + HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
					return hmResponse;
				}
				
				
				log.debug(sClassName + sMethodName + "LOHUL_02.5 : Response from processLockoutHelper for NonExpiredNonActivelock " + hmResponse);
				
				alNonExpiredNonActiveData = (ArrayList) hmResponse.get("lockInfo");
				
				if(alMPSData == null){
					alMPSData =  new ArrayList();
				}
				
				if(alNonExpiredNonActiveData != null && !alNonExpiredNonActiveData.isEmpty()
						&& alMPSData != null){
					alMPSData.addAll(alNonExpiredNonActiveData);
				}
				
				HashMap hmStatus = (HashMap) hmResponse.get("status");
				if(hmStatus != null && !hmStatus.isEmpty()){
					hmReturnStatus.putAll(hmStatus); 
				}
			}
			
			if(alNewLock != null && !alNewLock.isEmpty()){
				
				log.debug(sClassName + sMethodName + "LOHUL_02.6 : Calling processLockoutHelper for NewLock");
				
				
				hmResponse=this.processLockoutRules(alNewLock, sValidationStatus, sHandle, sDomain,sIdentificationType);

				result = validateMapInput(hmResponse, CErrorDefs.ERR_SYS_APPL_NUM, " processLockoutRules response is NULL / EMPTY ");
				if (result != null) return result;

				sAppCategoryCode = (String) hmResponse.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
				sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
				
				if(sAppCategoryCode != null && sAppCategoryCode.trim().length() > 0
						&& !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)){
					sAppInfo=(String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
					log.info(sClassName + sMethodName + "LOHUL_04.8 : " + HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
					return hmResponse;
				}
				
				log.debug(sClassName + sMethodName + "LOHUL_02.7 : Response from processLockoutHelper for NewLock " + hmResponse);
				
				alInitialLock = (ArrayList) hmResponse.get("lockInfo");
				
				if(alMPSData == null){
					alMPSData =  new ArrayList();
				}
				
				if(alInitialLock != null && !alInitialLock.isEmpty()
						&& alMPSData != null){
					alMPSData.addAll(alInitialLock);
				}
				
				HashMap hmStatus = (HashMap) hmResponse.get("status");
				if(hmStatus != null && !hmStatus.isEmpty()){
					hmReturnStatus.putAll(hmStatus);
				}
			}
			
			if(alMPSData != null && !alMPSData.isEmpty()){
						
				if(bDoNotUpdateMPS){
					
					HashMap hmMPSInput = CommonUtil.getHashMap();
					hmMPSInput.put(MPSDefs.DB_MEMBERLOCKOUT, alMPSData);
					hmMPSInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
					
					log.debug(sClassName + sMethodName
							+ "DM-7C : Calling to MPSDB_TMEMBERLOCKOUT_H.processData with HashMap = " + HtmlUtils.htmlEscape(String.valueOf(hmMPSInput)));
					hmResponse = oMPSDB_TMEMBERLOCKOUT_H.processData(hmMPSInput);
					log.debug(sClassName + sMethodName
							+ "DM-7D : Response Hash from MPSDB_TMEMBERLOCKOUT_H.processData is = " + hmResponse);

					sAppCategoryCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
					if (!sAppCategoryCode.equals(CErrorDefs.COMMON_SUCCESS)) {
						log.info(sClassName + sMethodName
								+ "DM-7E : Error returned from MPSDB_TMEMBERLOCKOUT_H.processData :" );
						return hmResponse;
					}

			    }
		
				if(this.bLockOutFlag){
					
					if(sIdentificationType != null && sIdentificationType.trim().length() > 0
							&& alAccountLockoutInterestedIdentificationType.contains(sIdentificationType)){
						hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ACCOUNT_LOCKOUT_NUM, "Account is locked");
						log.info(sClassName + sMethodName + "LOHUL_05.2 : Account is Locked");

					}else if (sIdentificationType != null && sIdentificationType.trim().length() > 0
							&& alMemberLockoutInterestedIdentificationType.contains(sIdentificationType)){
						hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_MID_LOCKOUT_NUM, "Member is locked");
						log.info(sClassName + sMethodName + "LOHUL_05.3 : Member is Locked");
					}
					
					if(hmReturnStatus != null && !hmReturnStatus.isEmpty()){
						hmResponse.putAll(hmReturnStatus);
					}
					if(bDoNotUpdateMPS){
					    if(sIdentificationType != null && sIdentificationType.trim().length() > 0
								&& alAccountLockoutInterestedIdentificationType.contains(sIdentificationType)){
					        hmResponse.put("accountlockout", alMPSData);

						}else if (sIdentificationType != null && sIdentificationType.trim().length() > 0
								&& alMemberLockoutInterestedIdentificationType.contains(sIdentificationType)){
						    hmResponse.put("memberlockout", alMPSData);
						}
					}
					return hmResponse;
				}
				
				
				
			}else{
				
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Nothing to Update");
				log.info(sClassName + sMethodName + "LOHUL_05 : Nothing to Update");
				return hmResponse;
			}
			
			hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "");
			if(hmReturnStatus != null && !hmReturnStatus.isEmpty()){
				hmResponse.putAll(hmReturnStatus);
			}
			if(bDoNotUpdateMPS){
			    if(sIdentificationType != null && sIdentificationType.trim().length() > 0
						&& alAccountLockoutInterestedIdentificationType.contains(sIdentificationType)){
			        hmResponse.put("accountlockout", alMPSData);

				}else if (sIdentificationType != null && sIdentificationType.trim().length() > 0
						&& alMemberLockoutInterestedIdentificationType.contains(sIdentificationType)){
				    hmResponse.put("memberlockout", alMPSData);
				}
			}
			
		}catch(Exception e){
			hmResponse = CommonErrorMap.makeExceptionMap(e);
    		
			
			log.error(sClassName + sMethodName + "LOHUL_05.1.1 : " + " Error::" + e.getMessage());
			log.error(sClassName + sMethodName + "LOHUL_06.1 : " + "Exception = {}", e);

    	} finally {
    		
    		
    		log.info(sClassName + sMethodName + "HLP999 : response : " + HtmlUtils.htmlEscape(String.valueOf(hmResponse)));
    	}
		
		return hmResponse;
	}
	

}
