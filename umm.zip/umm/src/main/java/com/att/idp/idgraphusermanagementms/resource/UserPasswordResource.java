package com.att.idp.idgraphusermanagementms.resource;

import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.resource.request.ResetUserPasswordRequest;
import com.att.idp.idgraphusermanagementms.resource.request.UpdatePrepaidUserPasswordRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ResetUserPasswordResponse;
import com.att.idp.idgraphusermanagementms.resource.request.UpdateUserPasswordRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdatePrepaidUserPasswordResponse;
import com.att.idp.idgraphusermanagementms.resource.response.UpdateUserPasswordResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.RequestBody;

import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Tag(name = "userpassword")
@Path("/userpassword")
@Produces({ MediaType.APPLICATION_JSON })
public interface UserPasswordResource {
    /**
     * This method is part of the UserPasswordResource interface.
     * Functionality for updating user password for accessId and its linked memberIds
     * The method is annotated with @POST to indicate that it handles HTTP POST requests.
     * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
     * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
     * The method takes a UpdateUserPasswordRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
     * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
     * The method throws an MPSException if any error occurs during the operation.
     * The method returns a Response object which encapsulates the result of the user access ID merge operation.
     *
     * @param updateUserPasswordRequest The UpdateUserPasswordRequest containing the details of the user access ID merge operation.
     * @param httpHeader The HttpHeaders providing HTTP header information.
     * @return Response The response of the user access ID merge operation.
     * @throws MPSException If any error occurs during the operation.
     */
    @POST
    @Path("/update")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(summary = "Update User Password", description =  "Update User Password for their accessId and its linked memberId",parameters = {
            @Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = UpdateUserPasswordResponse.class))),
            @ApiResponse(responseCode = "400", description =  "Bad Request"),
            @ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
    Response updateUserPassword(@Valid @RequestBody UpdateUserPasswordRequest updateUserPasswordRequest, @Context HttpHeaders httpHeader) throws MPSException;

    /**
     * This method is part of the UserPasswordResource interface.
     * It is responsible to reset the user password.
     * The method is annotated with @POST to indicate that it handles HTTP POST requests.
     * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
     * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
     * The method takes an ResetUserPasswordRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
     * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
     * The method throws an MPSException if any error occurs during the operation.
     * The method returns a Response object which encapsulates the result of the user addition operation.
     *
     * @param resetUserPasswordRequest The ResetUserPasswordRequest containing the details of the password reset operation.
     * @param httpHeader The HttpHeaders providing HTTP header information.
     * @return Response The response of the reset password operation.
     * @throws MPSException If any error occurs during the operation.
     */
    @POST
    @Path("/reset")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(summary = "Reset User Password", description =  "Reset User Password in the MPSYS system",parameters = {
            @Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = ResetUserPasswordResponse.class))),
            @ApiResponse(responseCode = "400", description =  "Bad Request"),
            @ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
    Response resetUserPassword(@Valid @RequestBody ResetUserPasswordRequest resetUserPasswordRequest, @Context HttpHeaders httpHeader) throws MPSException;

    /**
     * This method is part of the UserPasswordResource interface.
     * Functionality for updating user password for accessId and its linked memberIds
     * The method is annotated with @POST to indicate that it handles HTTP POST requests.
     * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
     * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
     * The method takes a UpdateUserPasswordRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
     * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
     * The method throws an MPSException if any error occurs during the operation.
     * The method returns a Response object which encapsulates the result of the user access ID merge operation.
     *
     * @param updatePrepaidUserPasswordRequest The UpdateUserPasswordRequest containing the details of the user access ID merge operation.
     * @param httpHeader The HttpHeaders providing HTTP header information.
     * @return Response The response of the user access ID merge operation.
     * @throws MPSException If any error occurs during the operation.
     */

    @POST
    @Path("/updatePrepaid")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(summary = "Update Prepaid User Password", description =  "Update Prepaid User Password for the Access Id",parameters = {
            @Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = UpdatePrepaidUserPasswordResponse.class))),
            @ApiResponse(responseCode = "400", description =  "Bad Request"),
            @ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
    Response updatePrepaidUserPassword(@Valid @RequestBody UpdatePrepaidUserPasswordRequest updatePrepaidUserPasswordRequest, @Context HttpHeaders httpHeader) throws MPSException;

}
