package com.att.idp.idgraphusermanagementms.resource.impl;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_IB;
import static com.att.idp.cd.observability.metrics.utils.Constants.URI;
import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.POST;
import static com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants.IDGRAPH_USERMANAGEMENTMS_IB;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Set;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;

import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.helper.RegistrationOrchestrationHelper;
import com.att.idp.idgraphusermanagementms.request.validator.RegistrationOrchestrationRequestValidator;
import com.att.idp.idgraphusermanagementms.resource.RegistrationOrchestrationResource;
import com.att.idp.idgraphusermanagementms.resource.request.RegistrationOrchestrationRequest;
import com.att.idp.idgraphusermanagementms.resource.response.AssociationResult;
import com.att.idp.idgraphusermanagementms.resource.response.RegistrationOrchestrationResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;

/**
 * This class is the implementation of the RegistrationOrchestrationResource interface.
 * It handles the registration orchestration endpoint, validating requests and delegating
 * to the helper for processing.
 */
@Controller
public class RegistrationOrchestrationResourceImpl implements RegistrationOrchestrationResource {

    private static final Logger logger = LoggerFactory.getLogger(RegistrationOrchestrationResourceImpl.class);
    private static final String sClassName = "RegistrationOrchestrationResourceImpl";

    @Autowired
    private RegistrationOrchestrationRequestValidator registrationOrchestrationRequestValidator;

    @Autowired
    private RegistrationOrchestrationHelper registrationOrchestrationHelper;

    /**
     * Processes the registration orchestration request.
     * 1. Validates headers and body via the request validator
     * 2. If validation passes, delegates to the helper for processing
     * 3. Maps the response to the appropriate HTTP status code
     *
     * @param request The RegistrationOrchestrationRequest.
     * @param httpHeader The HttpHeaders.
     * @return Response with appropriate HTTP status.
     * @throws MPSException If any error occurs during the operation.
     */
    @TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
            description = "registration orchestration",
            tags = {URI, "/msapi/idgraphusermanagementms/v1/orchestration/registration", METHOD, POST},
            histogram = true)
    @Override
    public Response registration(@RequestBody RegistrationOrchestrationRequest request,
                                 HttpHeaders httpHeader) throws MPSException {

        String sMethodName = ".registration.";
        long startTm = System.currentTimeMillis();

        logger.info(SpiMarker.getInstance(), "{}{}WEB_01 : RegistrationOrchestration Input : {} | Request Header : {}",
                sClassName, sMethodName,
                request != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(request)) : null,
                httpHeader.getRequestHeaders() != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(httpHeader.getRequestHeaders())) : null);

        RegistrationOrchestrationResponse response;

        try {
            // Step 1: Validate request
            response = registrationOrchestrationRequestValidator.validate(httpHeader, request);

            if (response != null) {
                // Validation failed — return error response
                logger.info("{}{}WEB_02 : Validation failed: {}", sClassName, sMethodName, response);
                return buildHttpResponse(response);
            }

            // Step 2-5: Process registration orchestration
            response = registrationOrchestrationHelper.processRegistration(request);
            logger.info("{}{}WEB_03 : RegistrationOrchestration Helper Response : {}", sClassName, sMethodName, response);

        } catch (Exception e) {
            logger.error("{}{}WEB_04 : Exception in registrationOrchestration: {}", sClassName, sMethodName, e.getMessage(), e);
            response = RegistrationOrchestrationResponse.builder()
                    .idpTraceId(request != null ? request.getIdpTraceId() : null)
                    .status(ProfileOrchestrationConstants.STATUS_FAILED)
                    .errorId("MS_MPSYS_BE_602")
                    .message("ERR_SYS_APPL: " + e.getMessage())
                    .build();
        }

        Response httpResponse = buildHttpResponse(response);
        String sTimeTaken = CommonUtilHelper.getElapsedTimeInSecs(startTm) + " seconds";
        logger.info("{}{}WEB999 : Total time taken : {} RegistrationOrchestration Response : {}", sClassName, sMethodName,
                sTimeTaken, response);

        return httpResponse;
    }

    private static final Set<String> SYSTEM_ERROR_CODES = Set.of(
            "MS_MPSYS_BE_304", "MS_MPSYS_BE_602", "MS_MPSYS_BE_605", "MS_MPSYS_BE_606");

    /**
     * Builds the HTTP Response with the appropriate status code based on the orchestration response.
     * SUCCESS → 200, PARTIAL_SUCCESS → 207, FAILED → 400 (or 500 for system errors).
     *
     * @param response The RegistrationOrchestrationResponse.
     * @return Response The JAX-RS Response with appropriate HTTP status.
     */
    private Response buildHttpResponse(RegistrationOrchestrationResponse response) {
        if (response == null) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }

        String status = response.getStatus();
        if (ProfileOrchestrationConstants.STATUS_SUCCESS.equals(status)) {
            return Response.status(Response.Status.OK).entity(response).build();
        } else if (ProfileOrchestrationConstants.STATUS_PARTIAL_SUCCESS.equals(status)) {
            return Response.status(207).entity(response).build();
        } else {
            // FAILED — check if it's a system error (5xx) or client error (4xx)
            String errorId = response.getErrorId();
            if (errorId != null && SYSTEM_ERROR_CODES.contains(errorId)) {
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(response).build();
            }

            // When errorId is null but results[] is present (aggregated FAILED),
            // inspect item-level statusCodes to determine 4xx vs 5xx
            if (errorId == null && response.getResults() != null && !response.getResults().isEmpty()) {
                if (hasOnlySystemErrors(response.getResults())) {
                    return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(response).build();
                }
            }

            return Response.status(Response.Status.BAD_REQUEST).entity(response).build();
        }
    }

    /**
     * Checks if all failed items in the results list have system-level (5xx) error codes.
     */
    private boolean hasOnlySystemErrors(List<AssociationResult> results) {
        return results.stream()
                .filter(r -> r.getStatusCode() != null
                        && !ProfileOrchestrationConstants.SUCCESS_CODE.equals(r.getStatusCode()))
                .allMatch(r -> SYSTEM_ERROR_CODES.contains(r.getStatusCode()));
    }
}
