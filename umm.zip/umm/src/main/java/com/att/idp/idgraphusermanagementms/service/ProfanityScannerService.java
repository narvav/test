package com.att.idp.idgraphusermanagementms.service;

import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.resource.request.ProfanityScannerRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ProfanityScannerResponse;

import jakarta.ws.rs.core.MultivaluedMap;
/**
 * This is the ProfanityScannerService interface. It defines a single method, profanityScanner.
 * This method is used to check for profanity words in the given scanItem.
 */

public interface ProfanityScannerService {

    /**
     * This method is used to check for profanity words in the given scanItem.
     *
     * @param profanityScannerRequest This is the request body. It should be a valid instance of ProfanityScannerRequest.
     * @param requestHeader This is the HTTP headers from the request.
     * @return A ProfanityScannerResponse object. The response contains the result of the profanity check.
     * @throws MPSException This exception is thrown if there is an error during the processing of the request.
     */
    ProfanityScannerResponse profanityScanner(ProfanityScannerRequest profanityScannerRequest, MultivaluedMap<String, String> requestHeader) throws MPSException;
}
