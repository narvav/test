package com.att.idp.idgraphusermanagementms.db.helper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import net.logstash.logback.argument.StructuredArguments;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.common.validators.DomainValidation;
import com.att.idp.idgraphusermanagementms.helper.voltage.ProcessVoltageHelper;
import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.StatusMsg;
/**
 * This class, UpdateDBHelper, is responsible for updating various entities in the database.
 * It uses Spring's JdbcTemplate for database operations.
 *
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like JdbcTemplate, DomainValidation, ProcessVoltageHelper, and DBHelper.
 *
 */
@Component
public class UpdateDBHelper {
	
	private static final String INFO = "$Id: master/com/att/idp/idgraphusermanagementms/db/helper/UpdateDBHelper.java v1 2021-09-23 vl6562 $;";
	private static String sClassName = "UpdateDBHelper";
	public static final Logger log = LoggerFactory.getLogger(UpdateDBHelper.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private DomainValidation oDomainValidation;

	@Autowired
	private ProcessVoltageHelper oProcessVoltageHelper;

	@Autowired
	private DBHelper oDBHelper;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	/**
	 * 
	 * @param hmInput
	 * @return HashMap
	 */
	public HashMap updateMemberAUX(HashMap hmInput) {

		String sMethodName = ".updateMemberAUX.";
		List<Object> objectList = CommonUtil.getArrayList();
		StringBuilder query = new StringBuilder();
		String stAppInfo = null;

		long tTime = 0;
		Date dtStartDate = new Date();

		ArrayList argsKey = CommonUtil.getArrayList();
		ArrayList argsValues = CommonUtil.getArrayList();
		ArrayList keys = CommonUtil.getArrayList();

		HashMap hmResult = null;

		log.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmInput));

		try {

			if (hmInput == null || hmInput.isEmpty()) {
				stAppInfo = "updateMemberAUX() input is null";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, stAppInfo);
				log.info("{}{}MPSDBUMA_02 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			String sMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
			String sMemberName = (String) hmInput.get(MPSDefs.DB_MEMBER_NAME);
			String sDomainName = (String) hmInput.get(MPSDefs.DB_DOMAIN_NAME);
			String sSlidMemberNum = (String) hmInput.get(MPSDefs.DB_SLID_MEMBER_NUM);

			if (sMemberNum != null && !sMemberNum.isEmpty()) {
				query = new StringBuilder(
						"MERGE into MEMBERAUX memaux using (SELECT sysdate from DUAL) mem ON (memaux.member_num = ?) WHEN matched then ");

			} else if (sMemberName != null && !sMemberName.isEmpty() && sDomainName != null && !sDomainName.isEmpty()) {
				query = new StringBuilder(
						"MERGE into MEMBERAUX memaux using (SELECT member_num from member where member_name = ? AND domain_id = ? ) mem ON (memaux.member_num = mem.member_num) WHEN matched then ");

			} else if (sSlidMemberNum != null && !sSlidMemberNum.isEmpty()) {
				query = new StringBuilder(
						"MERGE into MEMBERAUX memaux using (SELECT member_num from member where slid_member_num = ? ) mem ON (memaux.member_num = mem.member_num) WHEN matched then ");
			}

			Iterator itr = hmInput.keySet().iterator();

			while (itr.hasNext()) {
				String key = (String) itr.next();

				if (memberAuxCheckKey(key)) {
					argsKey.add(key + " = ? ");
					argsValues.add((String) hmInput.get(key));
					keys.add(key);
				}
			}

			// 1612 - Updated to return SUCCESS from this method, when there is nothing to
			// update in MEMBERAUX table
			if ((keys.size() == 0)
					|| (keys.size() == 1 && MPSDefs.DB_LAST_MODIFIED_BY.equalsIgnoreCase((String) keys.get(0)))) {
				log.info("{}{}MPSDBUMA_02.00 : Nothing to update in MemberAux", sClassName, sMethodName);
				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
				return hmResult;
			}

			String sUpdateQuery = "UPDATE SET ";
			query.append(sUpdateQuery);

			// 2103 - Added SSHA-256 encryption changes
			HashMap hmKeyConvert = CommonUtil.getHashMap();
			hmKeyConvert.put(MPSDefs.DB_GEN_PASSWORD_VENC, MPSDefs.DB_PASSWORD_VENC);
			hmKeyConvert.put(MPSDefs.DB_GEN_PASSWORD_TYPE, MPSDefs.DB_PASSWORD_TYPE);
			  
			Set<String> keyConvertSet = hmKeyConvert.keySet();
			ArrayList<String>listOfKeys = new ArrayList<String>(keyConvertSet);
			 	
			for (int i = 0; i < argsKey.size(); i++) {
				// 2103 - Added SSHA-256 encryption changes
				if (((String) argsKey.get(i)).contains(listOfKeys.get(0))) {
					query.append(hmKeyConvert.get(listOfKeys.get(0)));
					query.append("= ?");
				} else if (((String) argsKey.get(i)).contains(listOfKeys.get(1))) {
					query.append(hmKeyConvert.get(listOfKeys.get(1)));
					query.append("= ?");
				} else {
					query.append(argsKey.get(i));
				}
				if (i != (argsKey.size() - 1)) {
					query.append(" , ");
				}
			}

			query.append(" WHEN not matched THEN ");

			String sInsertQuery = "";
			if (sMemberNum != null && !sMemberNum.isEmpty()) {
				sInsertQuery = "INSERT (" + "MEMBER_NUM, " + "ENC_PASSWORD_VENC, " + "MD5_PASSWORD_VENC, "
						+ "SHA1_PASSWORD_VENC, " + "DES3_PASSWORD_VENC, " + "SSHA_PASSWORD_VENC, "
						+ "SECURITY_ANSWER_1_VENC, " + "SECURITY_ANSWER_2_VENC, "
						+ "PASSWORD_VENC, " + "PASSWORD_TYPE, " +
							 "LAST_MODIFIED_BY" + " ) VALUES ( "
						+ "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

			} else if ((sMemberName != null && !sMemberName.isEmpty() && sDomainName != null && !sDomainName.isEmpty())
					|| (sSlidMemberNum != null && !sSlidMemberNum.isEmpty())) {
				sInsertQuery = "INSERT (" + "MEMBER_NUM, " + "ENC_PASSWORD_VENC, " + "MD5_PASSWORD_VENC, "
						+ "SHA1_PASSWORD_VENC, " + "DES3_PASSWORD_VENC, " + "SSHA_PASSWORD_VENC, "
						+ "SECURITY_ANSWER_1_VENC, " + "SECURITY_ANSWER_2_VENC, "
						+ "PASSWORD_VENC, " + "PASSWORD_TYPE, " +
							 "LAST_MODIFIED_BY" + " ) VALUES ( "
						+ "mem.member_num, ?, ?, ?, ?, ?, ?, ?, ?,?,?)";
			}

			query.append(sInsertQuery);
			log.info("{}{}MPSDBUMA_02.1 : query ::  {}", sClassName, sMethodName, query);

			int cnt = 0;

			Long memberNum = null;
			Long slidMemberNum = null;

			if (sMemberNum != null && !sMemberNum.isEmpty()) {
				memberNum = Long.parseLong(sMemberNum);
				cnt = 1;
				objectList.add(memberNum);
				log.info("{}{}MPSDBUMA_02.2 : member_num::PARAM 1 = {}", sClassName, sMethodName, memberNum);

				for (int i = 0; i < argsValues.size(); i++) {
					if (memberAuxTypeSet((String) keys.get(i)).equals("String")) {
						objectList.add((String) argsValues.get(i));
						log.info("{}{}MPSDBUMA_02.3 : {} ::PARAM {} :: {}", sClassName, sMethodName,
								(String)keys.get(i), (i + 2), (String)argsValues.get(i));
					}
				}

			} else if (sMemberName != null && !sMemberName.isEmpty() && sDomainName != null && !sDomainName.isEmpty()) {
				cnt = 1;
				objectList.add(sMemberName);
				log.info("{}{}MPSDBUMA_02.2 : member_name::PARAM 1 = {}", sClassName, sMethodName, sMemberName);

				String sDomainId = oDomainValidation.getDomainId(sDomainName);
				if ((sDomainId != null && sDomainId.trim().length() > 0)) {
					cnt = 2;
					objectList.add(sDomainId);
					log.info("{}{}MPSDBUMA_02.3 : domain_id::PARAM 2 = {}", sClassName, sMethodName, sDomainId);
				}

				for (int i = 0; i < argsValues.size(); i++) {
					if (memberAuxTypeSet((String) keys.get(i)).equals("String")) {
						objectList.add((String) argsValues.get(i));
						log.info("{}{}MPSDBUMA_02.4 : {} ::PARAM {} :: {}", sClassName, sMethodName,
								(String)keys.get(i), (i + 3), (String)argsValues.get(i));
					}
				}

			} else if (sSlidMemberNum != null && !sSlidMemberNum.isEmpty()) {
				slidMemberNum = Long.parseLong(sSlidMemberNum);
				cnt = 1;
				objectList.add(slidMemberNum);
				log.info("{}{}MPSDBUMA_02.2 : slid_member_num::PARAM 1 = {}", sClassName, sMethodName, sSlidMemberNum);

				for (int i = 0; i < argsValues.size(); i++) {
					if (memberAuxTypeSet((String) keys.get(i)).equals("String")) {
						objectList.add((String) argsValues.get(i));
						log.info("{}{}MPSDBUMA_02.3 : {} ::PARAM {} :: {}", sClassName, sMethodName,
								(String)keys.get(i), (i + 2), (String)argsValues.get(i));

					}
				}
			}

			String encPasswordVenc = (String) hmInput.get(MPSDefs.DB_ENC_PASSWORD_VENC);
			String md5PasswordVenc = (String) hmInput.get(MPSDefs.DB_MD5_PASSWORD_VENC);
			String sha1PasswordVenc = (String) hmInput.get(MPSDefs.DB_SHA1_PASSWORD_VENC);
			String des3PasswordVenc = (String) hmInput.get(MPSDefs.DB_DES3_PASSWORD_VENC);
			String sshaPasswordVenc = (String) hmInput.get(MPSDefs.DB_SSHA_PASSWORD_VENC);
			String securityAnswer1Venc = (String) hmInput.get(MPSDefs.DB_SECURITY_ANSWER_1_VENC);
			String securityAnswer2Venc = (String) hmInput.get(MPSDefs.DB_SECURITY_ANSWER_2_VENC);
			// 2103 - Added SSHA-256 encryption changes
			String genericPasswordVenc = (String) hmInput.get(MPSDefs.DB_GEN_PASSWORD_VENC);
			String genericPasswordType = (String) hmInput.get(MPSDefs.DB_GEN_PASSWORD_TYPE);
			String lastModifiedBy = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);

			if (sMemberNum != null && !sMemberNum.isEmpty()) {
				cnt = cnt + argsValues.size();
				objectList.add(memberNum);
				log.info("{}{}MPSDBUMA_03.1 : member_num::PARAM {} = {}", sClassName, sMethodName, (cnt + 1), memberNum);

			} else if ((sMemberName != null && !sMemberName.isEmpty() && sDomainName != null && !sDomainName.isEmpty())
					|| (sSlidMemberNum != null && !sSlidMemberNum.isEmpty())) {
				cnt = (cnt + argsValues.size()) - 1; // decreasing count by 1 bcoz member_num is not present.
			}

			if (encPasswordVenc != null) {
				objectList.add(encPasswordVenc);
				log.info("{}{}MPSDBUMA_04 : enc_password_venc::PARAM {} = {}", sClassName, sMethodName, (cnt + 2), encPasswordVenc);
			} else {
				objectList.add(null);
				log.info("{}{}MPSDBUMA_04 : enc_password_venc::PARAM {} = null", sClassName, sMethodName, (cnt + 2));
			}

			if (md5PasswordVenc != null) {
				objectList.add(md5PasswordVenc);
				log.info("{}{}MPSDBUMA_05 : md5_password_venc::PARAM {} = {}", sClassName, sMethodName, (cnt + 3), md5PasswordVenc);
			} else {
				objectList.add(null);
				log.info("{}{}MPSDBUMA_05 : md5_password_venc::PARAM {} = null", sClassName, sMethodName, (cnt + 3));
			}

			if (sha1PasswordVenc != null) {
				objectList.add(sha1PasswordVenc);
				log.info("{}{}MPSDBUMA_06 : sha1_password_venc::PARAM {} = {}", sClassName, sMethodName, (cnt + 4), sha1PasswordVenc);
			} else {
				objectList.add(null);
				log.info("{}{}MPSDBUMA_06 : sha1_password_venc::PARAM {} = null", sClassName, sMethodName, (cnt + 4));
			}

			if (des3PasswordVenc != null) {
				objectList.add(des3PasswordVenc);
				log.info("{}{}MPSDBUMA_07 : des3_password_venc::PARAM {} = {}", sClassName, sMethodName, (cnt + 5), des3PasswordVenc);
			} else {
				objectList.add(null);
				log.info("{}{}MPSDBUMA_07 : des3_password_venc::PARAM {} = null", sClassName, sMethodName,(cnt + 5));
			}

			if (sshaPasswordVenc != null) {
				objectList.add(sshaPasswordVenc);
				log.info("{}{}MPSDBUMA_08 : ssha_password_venc::PARAM {} = {}", sClassName, sMethodName, (cnt + 6), sshaPasswordVenc);
			} else {
				objectList.add(null);
				log.info("{}{}MPSDBUMA_08 : ssha_password_venc::PARAM {} = null", sClassName, sMethodName,(cnt + 6));
			}

			if (securityAnswer1Venc != null) {
				objectList.add(securityAnswer1Venc);
				log.info("{}{}MPSDBUMA_09 : security_answer_1_venc::PARAM {} = {}", sClassName, sMethodName, (cnt + 7), securityAnswer1Venc);
			} else {
				objectList.add(null);
				log.info("{}{}MPSDBUMA_09 : security_answer_1_venc::PARAM {} = null", sClassName, sMethodName, (cnt + 7));
			}

			if (securityAnswer2Venc != null) {
				objectList.add(securityAnswer2Venc);
				log.info("{}{}MPSDBUMA_10 : security_answer_2_venc::PARAM {} = {}", sClassName, sMethodName, (cnt + 8), securityAnswer2Venc);
			} else {
				objectList.add(null);
				log.info("{}{}MPSDBUMA_10 : security_answer_2_venc::PARAM {} = null", sClassName, sMethodName, (cnt + 8));
			}
			// 2103 - Added SSHA-256 encryption changes
			if (genericPasswordVenc != null) {
				objectList.add(genericPasswordVenc);
				log.info("{}{}MPSDBUMA_10.1 : generic_password_venc::PARAM {} = {}", sClassName, sMethodName, (cnt + 9), genericPasswordVenc);
			} else {
				objectList.add(null);
				log.info("{}{}MPSDBUMA_10.1 : generic_password_venc::PARAM {} = null", sClassName, sMethodName, (cnt + 9));
			}
			if (genericPasswordType != null) {
				objectList.add(genericPasswordType);
				log.info("{}{}MPSDBUMA_10.2 : generic_password_type::PARAM {} = {}", sClassName, sMethodName, (cnt + 10), genericPasswordType);
			} else {
				objectList.add(null);
				log.info("{}{}MPSDBUMA_10.2 : generic_password_type::PARAM {} = null", sClassName, sMethodName, (cnt + 10));
			}
			 
			objectList.add(lastModifiedBy);
			log.info("{}{}MPSDBUMA_11 : last_modified_by::PARAM {} = {}", sClassName, sMethodName, (cnt + 9), lastModifiedBy);

			int rowCount = jdbcTemplate.update(new String(query), objectList.toArray(new Object[objectList.size()]));

			// Calculate the total time taken to insert rows in DB to return time in
			// milliseconds
			tTime = (System.currentTimeMillis() - dtStartDate.getTime());
			log.info("{}{}QUERY999 : Total time taken to execute query = {} milliseconds", sClassName, sMethodName, tTime);
			log.info("{}{}MPSDBUMA_12 : No of rows inserted:= {}", sClassName, sMethodName, rowCount);

			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}MPSDBUMA_13 : Error::{}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}MPSDBUMA_14 : Exception = {}", sClassName, sMethodName, e);
		} finally {
			log.info("{}{}DBTOOLS999 : response : {}{}", sClassName, sMethodName, dtStartDate.getTime(), hmResult);
		}

		return hmResult;
	}

	/**
	 * 
	 * @param hmMem
	 * @return HashMap
	 */
	public HashMap updateMemberBySlidMemberNum(HashMap hmMem) {

		String sMethodName = ".updateMemberBySlidMemberNum.";

		List<Object> objectList = CommonUtil.getArrayList();
		boolean slidMemberNum = false;
		String slidVal = null;
		String whereClause = null;
		String tblName = "MEMBER ";

		StringBuilder query = new StringBuilder(" UPDATE ");
		StringBuilder where = new StringBuilder(" WHERE ");

		int n;
		int k;

		HashMap memInfo = null;
		java.util.List argsKeys = CommonUtil.getArrayList();
		java.util.List argsVals = CommonUtil.getArrayList();
		java.util.List keys = CommonUtil.getArrayList();
		java.util.List whereKeys = CommonUtil.getArrayList();
		java.util.List whereVals = CommonUtil.getArrayList();
		java.util.List wKeys = CommonUtil.getArrayList();
		
		SimpleDateFormat sdf = null;

		log.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmMem));

		// Check if the HashMap contains the desired keys and the values are not null.
		if (hmMem == null) {
			memInfo = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, "hashmap is empty");
			log.info("{}{}MPSDB13 : hashmap is empty", sClassName, sMethodName);
			return memInfo;
		}

		try {
			log.info("{}{}MPSDB36.1 : Calling ProcessVoltageHelper.voltageEncryptSPIFields()", sClassName, sMethodName);
			memInfo = oProcessVoltageHelper.voltageEncryptSPIFields(hmMem);
			log.info("{}{}MPSDB36.2 :Response from ProcessVoltageHelper.voltageEncryptSPIFields() : {}", sClassName, sMethodName, memInfo);

			int securityQuestionId = -1;
			// Check for the security_question in the request
			if (hmMem.containsKey(MPSDefs.DB_SECURITY_QUESTION)) {

				if (hmMem.containsKey(MPSDefs.DB_SECURITY_QUESTION_ID)) {
					hmMem.remove(MPSDefs.DB_SECURITY_QUESTION);
				} else {
					// get security_question_id
					String securityQuestion = (String) hmMem.get(MPSDefs.DB_SECURITY_QUESTION);
					securityQuestionId = oDBHelper.getSecurityQuestionId(securityQuestion);
					log.info("{}{}MPSDB37.1 : security_question_id = {}", sClassName, sMethodName, securityQuestionId);

					// member_status is not pass in
					if (securityQuestionId == -1) {
						// something is missing
						String sAppInfo = "Cannot find security_question_id for the given security_question="
								+ securityQuestion;
						memInfo = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, sAppInfo);
						log.info("{}{}MPSDB37.2 : {}", sClassName, sMethodName, sAppInfo);
						return memInfo;

					}

					hmMem.remove(MPSDefs.DB_SECURITY_QUESTION);
					hmMem.put(MPSDefs.DB_SECURITY_QUESTION_ID, "" + securityQuestionId);
				}
			}

			int securityQuestionId1 = -1;
			// Check for the security_question_1 in the request
			if (hmMem.containsKey(MPSDefs.DB_SECURITY_QUESTION_1)) {
				if (hmMem.containsKey(MPSDefs.DB_SECURITY_QUESTION_ID_1)) {
					hmMem.remove(MPSDefs.DB_SECURITY_QUESTION_1);
				} else {
					// get security_question_id_1
					String securityQuestion1 = (String) hmMem.get(MPSDefs.DB_SECURITY_QUESTION_1);
					securityQuestionId1 = oDBHelper.getSecurityQuestionId(securityQuestion1);
					log.info("{}{}MPSDB37.1a : security_question_id_1 = {}", sClassName, sMethodName, securityQuestionId1);

					// member_status is not pass in
					if (securityQuestionId1 == -1) {
						// something is missing
						String sAppInfo = "Cannot find security_question_id_1 for the given security_question_1 = "
								+ securityQuestion1;
						memInfo = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, sAppInfo);
						log.info("{}{}MPSDB37.2a : {}", sClassName, sMethodName, sAppInfo);
						return memInfo;
					}
					hmMem.remove(MPSDefs.DB_SECURITY_QUESTION_1);
					hmMem.put(MPSDefs.DB_SECURITY_QUESTION_ID_1, "" + securityQuestionId1);
				}
			}
			int securityQuestionId2 = -1;
			// Check for the security_question_2 in the request
			if (hmMem.containsKey(MPSDefs.DB_SECURITY_QUESTION_2)) {
				if (hmMem.containsKey(MPSDefs.DB_SECURITY_QUESTION_ID_2)) {
					hmMem.remove(MPSDefs.DB_SECURITY_QUESTION_2);
				} else {
					// get security_question_id_2
					String securityQuestion2 = (String) hmMem.get(MPSDefs.DB_SECURITY_QUESTION_2);
					securityQuestionId2 = oDBHelper.getSecurityQuestionId(securityQuestion2);
					log.info("{}{}MPSDB37.1b : security_question_id_2 = {}", sClassName, sMethodName, securityQuestionId2);

					// member_status is not pass in
					if (securityQuestionId2 == -1) {
						// something is missing
						String sAppInfo = "Cannot find security_question_id_2 for the given security_question_2 ="
								+ securityQuestion2;
						memInfo = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, sAppInfo);
						log.info("{}{}MPSDB37.2b : {}", sClassName, sMethodName, sAppInfo);
						return memInfo;
					}
					hmMem.remove(MPSDefs.DB_SECURITY_QUESTION_2);
					hmMem.put(MPSDefs.DB_SECURITY_QUESTION_ID_2, "" + securityQuestionId2);
				}
			}

			// 1510 : EPIC PID 266956b CTN Alias for Fraud
			if (hmMem.containsKey(MPSDefs.DB_SECURITY_ANSWER_1) || hmMem.containsKey(MPSDefs.DB_SECURITY_ANSWER_2)) {
				if (hmMem.containsKey(MPSDefs.DB_ONL_QA_EST_DATE)) {
					String sOnlQAEstDate = (String) hmMem.get(MPSDefs.DB_ONL_QA_EST_DATE);
					hmMem.put(MPSDefs.DB_ONL_QA_EST_DATE, sOnlQAEstDate);
				} else {
					Date dtTodayDate = new Date();
					DateFormat dateFormat = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
					String stTodayDate = dateFormat.format(dtTodayDate);
					hmMem.put(MPSDefs.DB_ONL_QA_EST_DATE, stTodayDate);
				}
			}

			query.append(tblName);
			query.append(" SET ");
			log.info("{}{}MPSDB14 : query = {}", sClassName, sMethodName, query);

			// Iterarte through the HashMap
			Iterator it = hmMem.keySet().iterator();
			while (it.hasNext()) {
				String key = (String) it.next();

				if (key.equalsIgnoreCase("slid_member_num")) {
					slidVal = (String) hmMem.get(key);
					if ((slidVal != null) && (!slidVal.equals(""))) {
						slidMemberNum = true;
						whereKeys.add(key + " = ?");
						whereVals.add((String) hmMem.get(key));
						wKeys.add(key);

					}
				} else if (key.equalsIgnoreCase("filterMemberNumList")) {
					String filterMemberNum = "";
					for (int i = 0; i < ((ArrayList) hmMem.get(key)).size(); i++) {
						if (i == 0)
							filterMemberNum = (new StringBuilder(filterMemberNum).append(((ArrayList) hmMem.get(key)).get(i))).toString();
						else
							filterMemberNum = (new StringBuilder(filterMemberNum).append(",").append(((ArrayList) hmMem.get(key)).get(i))).toString();
					}

					filterMemberNum = (new StringBuilder("member_num not in ( ").append(filterMemberNum)).toString();
					
					whereKeys.add(filterMemberNum + ")");
				} else if (key.equalsIgnoreCase("includeMemberNumList")) {
					String includeMemberNum = "";
					for (int i = 0; i < ((ArrayList) hmMem.get(key)).size(); i++) {
						if (i == 0)
							includeMemberNum = (new StringBuilder(includeMemberNum).append(((ArrayList) hmMem.get(key)).get(i))).toString();
						else
							includeMemberNum = (new StringBuilder(includeMemberNum).append(",").append(((ArrayList) hmMem.get(key)).get(i))).toString();
					}
					includeMemberNum = (new StringBuilder("member_num in ( ").append(includeMemberNum)).toString();

					whereKeys.add(includeMemberNum + ")");
				}

				else if (memberCheckKey(key)) {
					if (key.equalsIgnoreCase(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE)) {
						sdf = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
						String sContactEmailRTVFlag = (String) hmMem.get(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE);
						if (sContactEmailRTVFlag != null && sContactEmailRTVFlag.equals(CommonDefs.IND_N)) {
							argsVals.add(null);
						} else {
							String sSysDate = sdf.format(new Date());
							argsVals.add(sSysDate);
						}
						argsKeys.add(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE + " = ?");
						keys.add(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE);
					} else {
						argsKeys.add(key + " = ?");
						argsVals.add((String) hmMem.get(key));
						keys.add(key);

					}
				}
			}
			int len = argsKeys.size();

			int i;
			for (i = 0; i < len; i++) {
				query.append(argsKeys.get(i));
				if (i != (len - 1)) {
					query.append(" , ");
				} else {

				}
			}

			int wlen = whereKeys.size();

			int p;
			for (p = 0; p < wlen; p++) {
				where.append(whereKeys.get(p));

				if (p != (wlen - 1)) {
					where.append(" AND ");
				} else {
					// where.append(" ; ");
				}
			}
			if (slidMemberNum) {
				query.append(where);
				log.info("{}{}MPSDB18 : Query = {}", sClassName, sMethodName, query);

				whereClause = "YES";
			}

			if ((whereClause == null) || (whereClause.equals(""))) {
				// The Where Clause is not set Hence Error
				memInfo = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, "Where clause not prepared");
				log.info("{}{}MPSDB20 : Where clause not prepared", sClassName, sMethodName);
				return memInfo;
			}

			i = 0;
			for (i = 0; i < argsVals.size(); i++) {
				String TestType = memberTypeSet((String) keys.get(i));

				if (memberTypeSet((String) keys.get(i)).equals("Int")) {
					if (argsVals.get(i) != null)
						objectList.add(Integer.parseInt((String) argsVals.get(i)));
					else
						objectList.add(null);
				} else if (memberTypeSet((String) keys.get(i)).equals("String")) {
					objectList.add((String) argsVals.get(i));
				} else if (memberTypeSet((String) keys.get(i)).equals("Date")) {
					String sKey = (String) keys.get(i);

					if (sKey.equals(MPSDefs.DB_LOCKOUT_TIMESTAMP) || sKey.equals(MPSDefs.DB_ONL_QA_EST_DATE)) {
						sdf = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
					} else if (sKey.equals(MPSDefs.DB_CSR_INITIATED_LOCKOUT_TS)) {
						sdf = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
					} else if (sKey.equals(MPSDefs.DB_TOS_REJECT_DATE)) {
						sdf = CommonUtil.getSimpleDateFormat("MM/dd/yyyy HH:mm:ss");
					} else if (sKey.equals(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE)) {
						sdf = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
					} else {
						sdf = CommonUtil.getSimpleDateFormat("MMddyyyy");
					}

					if (argsVals.get(i) != null) {
						java.util.Date utilDate = sdf.parse((String) argsVals.get(i));
						java.sql.Timestamp timeStamp = CommonUtil.getSQLTimeStamp(utilDate.getTime());
						objectList.add(timeStamp);
					} else {
						objectList.add(null);
					}
				}
			}

			k = i;

			// Now execute the prepared statement
			if ((whereClause != null) && (!whereClause.equals(""))) {
				i = 0;
				for (i = 0; i < whereVals.size(); i++) {
					objectList.add((String) whereVals.get(i));

				}
				n = jdbcTemplate.update(new String(query), objectList.toArray(new Object[objectList.size()]));

				log.info("{}{}MPSDB25 : The rows updated are : {}", sClassName, sMethodName, n);

				if (n == 0) {
					memInfo = CommonErrorMap.makeCategoryMap(MPSDefs.REC_NOT_FOUND_NUM, "Rec Not Found");

				} else {
					memInfo = CommonErrorMap.makeCommonStatusMap(CErrorDefs.COMMON_SUCCESS_NUM);

					// 1612
					if (slidMemberNum) {
						log.info("{}{}MPSDB49.1.1 : Calling updateMemberAUX()", sClassName, sMethodName);
						memInfo = updateMemberAUX(hmMem);
						log.info("{}{}MPSDB49.1.2 : Response from  updateMemberAUX() :{}", sClassName, sMethodName, memInfo);

						String sAppStatusCode = (String) memInfo.get(CommonDefs.COMMON_APP_STATUS_CODE);
						if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
							String sAppInfo = (String) memInfo.get(CErrorDefs.COMMON_APP_INFO);
							log.info("{}{}MPSDB49.1.4 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
							return memInfo;
						}

					}
				}
			} 
			
		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			memInfo = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}MPSDB30 : Error::{}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}MPSDB31 : Exception = {}", sClassName, sMethodName, e);
		}

		finally {
			log.info("{}{}DBTOOLS999 : Finished UpdateDBHelper = {}", sClassName, sMethodName, memInfo);
		}
		return memInfo;
	}

	/**
	 * This method checks if the given key is a valid key for the member auxiliary information.
	 * It compares the input key with a predefined set of valid keys.
	 * If the input key matches any of the valid keys, it returns true. Otherwise, it returns false.
	 *
	 * @param key The key to be checked for validity.
	 * @return A boolean indicating whether the input key is a valid member auxiliary key or not.
	 */
	public boolean memberAuxCheckKey(String key) {
		if (key.equalsIgnoreCase(MPSDefs.DB_ENC_PASSWORD_VENC) || key.equalsIgnoreCase(MPSDefs.DB_MD5_PASSWORD_VENC)
				|| key.equalsIgnoreCase(MPSDefs.DB_SECURITY_ANSWER_1_VENC)
				|| key.equalsIgnoreCase(MPSDefs.DB_SECURITY_ANSWER_2_VENC)
				|| key.equalsIgnoreCase(MPSDefs.DB_DES3_PASSWORD_VENC)
				|| key.equalsIgnoreCase(MPSDefs.DB_SHA1_PASSWORD_VENC)
				|| key.equalsIgnoreCase(MPSDefs.DB_SSHA_PASSWORD_VENC)
				|| key.equalsIgnoreCase(MPSDefs.DB_GEN_PASSWORD_VENC)  // 2103 - Added SSHA-256 encryption changes
				|| key.equalsIgnoreCase(MPSDefs.DB_GEN_PASSWORD_TYPE)
				|| key.equalsIgnoreCase(MPSDefs.DB_LAST_MODIFIED_BY)

		) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * This method determines the data type of a given key in the member auxiliary information.
	 * It compares the input key with a predefined set of keys and their corresponding data types.
	 * If the input key matches any of the predefined keys, it returns the corresponding data type as a string.
	 *
	 * @param Key The key for which the data type needs to be determined.
	 * @return A string indicating the data type of the input key. It can be "Int", "String", or "Date".
	 */
	public String memberAuxTypeSet(String Key) {
		String sReturn = "";
		if ((Key.equalsIgnoreCase(MPSDefs.DB_ENC_PASSWORD_VENC)) || (Key.equalsIgnoreCase(MPSDefs.DB_MD5_PASSWORD_VENC))
				|| Key.equalsIgnoreCase(MPSDefs.DB_SECURITY_ANSWER_1_VENC)
				|| Key.equalsIgnoreCase(MPSDefs.DB_SECURITY_ANSWER_2_VENC)
				|| Key.equalsIgnoreCase(MPSDefs.DB_DES3_PASSWORD_VENC)
				|| Key.equalsIgnoreCase(MPSDefs.DB_SHA1_PASSWORD_VENC)
				|| Key.equalsIgnoreCase(MPSDefs.DB_SSHA_PASSWORD_VENC)
				|| Key.equalsIgnoreCase(MPSDefs.DB_GEN_PASSWORD_VENC) //2103 - Added SSHA-256 encryption changes
				|| Key.equalsIgnoreCase(MPSDefs.DB_GEN_PASSWORD_TYPE)
				|| Key.equalsIgnoreCase(MPSDefs.DB_LAST_MODIFIED_BY)) {
			sReturn = "String";
		}

		return sReturn;
	}

	/**
	 * 
	 * @param key
	 * @return boolean
	 */
	public boolean memberCheckKey(String key) {
		// Modified the below IF loop by keshavi for LS R2
		// added DB_DELETE_REQUEST_DATE and DB_TOKEN in the IF loop
		if ((key.equalsIgnoreCase(MPSDefs.DB_SOR_NAME)) || (key.equalsIgnoreCase(MPSDefs.DB_SOR_ID))
				|| (key.equalsIgnoreCase(MPSDefs.DB_ACCOUNT_TYPE)) || (key.equalsIgnoreCase(MPSDefs.DB_ENC_PASSWORD))
				|| (key.equalsIgnoreCase(MPSDefs.DB_MD5_PASSWORD))
				|| (key.equalsIgnoreCase(MPSDefs.DB_PARENT_CHILD_IND)) || (key.equalsIgnoreCase(MPSDefs.DB_ACCESS_ID))
				|| (key.equalsIgnoreCase(MPSDefs.DB_ACCESS_NAME)) || (key.equalsIgnoreCase(MPSDefs.DB_MAILHOST))
				|| (key.equalsIgnoreCase(MPSDefs.DB_MIGRATION_IND)) || (key.equalsIgnoreCase(MPSDefs.DB_MIGRATION_DATE))
				|| (key.equalsIgnoreCase(MPSDefs.DB_FULLNAME)) || (key.equalsIgnoreCase(MPSDefs.DB_LAST_MODIFIED_BY))
				|| (key.equalsIgnoreCase(MPSDefs.DB_OPTOUT_IND)) || (key.equalsIgnoreCase(MPSDefs.DB_BAN))
				|| (key.equalsIgnoreCase(MPSDefs.DB_DELETE_REQUEST_DATE)) || (key.equalsIgnoreCase(MPSDefs.DB_TOKEN))
				|| (key.equalsIgnoreCase(MPSDefs.DB_REMARKS)) || (key.equalsIgnoreCase(MPSDefs.DB_MIGRATION_IND))
				|| (key.equalsIgnoreCase(MPSDefs.DB_MD5_PASSWORD)) || (key.equalsIgnoreCase(MPSDefs.DB_SHA1_PASSWORD))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SSHA_PASSWORD))
				|| (key.equalsIgnoreCase(MPSDefs.DB_CONTACT_EMAIL))
				|| (key.equalsIgnoreCase(MPSDefs.DB_CONTACT_EMAIL_VALID))
				|| (key.equalsIgnoreCase("contact_email_status")) || (key.equalsIgnoreCase(MPSDefs.DB_PASSWORD_DIRTY))
				|| (key.equalsIgnoreCase(MPSDefs.DB_CREDIT_CHECKED_IND))
				|| (key.equalsIgnoreCase(MPSDefs.DB_YREG_COMPLETE_IND))
				|| (key.equalsIgnoreCase(MPSDefs.DB_LOCKOUT_TIMESTAMP))
				|| (key.equalsIgnoreCase(MPSDefs.DB_LC_FIRSTNAME)) || (key.equalsIgnoreCase(MPSDefs.DB_LC_LASTNAME))
				|| (key.equalsIgnoreCase(MPSDefs.DB_NICKNAME)) || (key.equalsIgnoreCase(MPSDefs.DB_LAST_FOUR_SSN))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_ID))
				|| (key.equalsIgnoreCase("security_answer_enc"))
				|| (key.equalsIgnoreCase(MPSDefs.DB_GENDER)) || (key.equalsIgnoreCase(MPSDefs.DB_PROOFING_ZIP))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_1))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_ID_1))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_ANSWER_1))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_2))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_ID_2))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_ANSWER_2))
				|| (key.equalsIgnoreCase(MPSDefs.DB_PREVIOUS_CONTACT_EMAIL))
				// ts7036 for dec cpni
				|| (key.equalsIgnoreCase(MPSDefs.DB_DES3_PASSWORD))// added as per NAPII & R6
				|| (key.equalsIgnoreCase(MPSDefs.DB_FAILED_AUTH_COUNT))// added as per NAPII & R6
				|| (key.equalsIgnoreCase(MPSDefs.DB_LANGUAGE))// added as per NAP4
				|| (key.equalsIgnoreCase(MPSDefs.DB_TOS_REJECT_DATE))// added as for att.net (NAP-5) Migrations( 2008
																		// Aug)
				|| (key.equalsIgnoreCase(MPSDefs.DB_NUM_TOS_REJECTS))// added as for att.net (NAP-5) Migrations( 2008
																		// Aug)
				|| (key.equalsIgnoreCase(MPSDefs.DB_CSR_INITIATED_LOCKOUT_TS))
				|| (key.equalsIgnoreCase(MPSDefs.DB_BROWSER_LANGUAGE))
				|| (key.equalsIgnoreCase(MPSDefs.DB_ATLAS_LAST_TIMESTAMP))
				|| (key.equalsIgnoreCase(MPSDefs.DB_DSL_NET_PASSWORD))
				|| (key.equalsIgnoreCase(MPSDefs.DB_DSL_NET_ENCR_TYPE))
				|| (key.equalsIgnoreCase(MPSDefs.DB_ACTIVATED_IND)) // by dm876h for 1106
				|| (key.equalsIgnoreCase(MPSDefs.DB_PASSCODE_VENC)) // added for OCT 2011
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_ANSWER_VENC)) // added for OCT 2011
				|| (key.equalsIgnoreCase(MPSDefs.DB_BIRTHDATE_VENC)) // added for OCT 2011
				|| (key.equalsIgnoreCase(MPSDefs.DB_SLID_MEMBER_NUM)) || (key.equalsIgnoreCase("last_verified"))
				|| (key.equalsIgnoreCase(MPSDefs.DB_MAIN_CTN_OPT_OUT))
				|| (key.equalsIgnoreCase(MPSDefs.DB_ONL_QA_EST_DATE)) // added for 1510 : EPIC PID 266956b CTN Alias for Fraud
				|| (key.equalsIgnoreCase(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE))
				|| (key.equalsIgnoreCase(MPSDefs.DB_CBR_OPT_OUT))
				|| (key.equalsIgnoreCase(CommonDefs.DB_ACCESS_ID_RTV_DATE))
				|| (key.equalsIgnoreCase(ProfileOrchestrationConstants.DB_CBR_NUMBER))
				|| (key.equalsIgnoreCase(ProfileOrchestrationConstants.DB_CBR_RTV_DATE))
				|| (key.equalsIgnoreCase(ProfileOrchestrationConstants.DB_CONTACT_ADDRESS))

		) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * This method determines the data type of a given key in the member information.
	 * It compares the input key with a predefined set of keys and their corresponding data types.
	 * If the input key matches any of the predefined keys, it returns the corresponding data type as a string.
	 *
	 * @param key The key for which the data type needs to be determined.
	 * @return A string indicating the data type of the input key. It can be "Int", "String", or "Date".
	 */
	public String memberTypeSet(String key) {

		String sReturn = "";

		if ((key.equalsIgnoreCase(MPSDefs.DB_SOR_NAME)) || (key.equalsIgnoreCase(MPSDefs.DB_ACCOUNT_TYPE))
				|| (key.equalsIgnoreCase(MPSDefs.DB_ENC_PASSWORD) || (key.equalsIgnoreCase(MPSDefs.DB_MD5_PASSWORD))
						|| (key.equalsIgnoreCase(MPSDefs.DB_PARENT_CHILD_IND))
						|| (key.equalsIgnoreCase(MPSDefs.DB_ACCESS_NAME)) || key.equalsIgnoreCase(MPSDefs.DB_MAILHOST))
				|| (key.equalsIgnoreCase(MPSDefs.DB_MIGRATION_IND)) || (key.equalsIgnoreCase(MPSDefs.DB_FULLNAME))
				|| (key.equalsIgnoreCase(MPSDefs.DB_LAST_MODIFIED_BY)) || (key.equalsIgnoreCase(MPSDefs.DB_OPTOUT_IND))
				|| (key.equalsIgnoreCase(MPSDefs.DB_BAN)) || (key.equalsIgnoreCase(MPSDefs.DB_TOKEN))
				|| (key.equalsIgnoreCase(MPSDefs.DB_REMARKS)) // Added by keshavi on 12/02/05 for LSR2 Delete API
				|| (key.equalsIgnoreCase(MPSDefs.DB_MIGRATION_IND)) // Added by keshavi on 12/05/05 for LSR2
				|| (key.equalsIgnoreCase(MPSDefs.DB_MD5_PASSWORD)) // Added by keshavi on 12/05/05 for LSR2
				|| (key.equalsIgnoreCase(MPSDefs.DB_SHA1_PASSWORD)) || (key.equalsIgnoreCase(MPSDefs.DB_SSHA_PASSWORD))
				|| (key.equalsIgnoreCase(MPSDefs.DB_CONTACT_EMAIL))
				|| (key.equalsIgnoreCase(MPSDefs.DB_CONTACT_EMAIL_VALID))
				|| (key.equalsIgnoreCase("contact_email_status")) // Added for June2010
				|| (key.equalsIgnoreCase(MPSDefs.DB_PASSWORD_DIRTY))
				|| (key.equalsIgnoreCase(MPSDefs.DB_CREDIT_CHECKED_IND))// Start - Added on 05/12/06 for LSR3 - Keshavi
				|| (key.equalsIgnoreCase(MPSDefs.DB_YREG_COMPLETE_IND))
				|| (key.equalsIgnoreCase(MPSDefs.DB_LC_FIRSTNAME)) || (key.equalsIgnoreCase(MPSDefs.DB_LC_LASTNAME))
				|| (key.equalsIgnoreCase(MPSDefs.DB_NICKNAME)) || (key.equalsIgnoreCase(MPSDefs.DB_LAST_FOUR_SSN))
				|| (key.equalsIgnoreCase("security_answer_enc")) || (key.equalsIgnoreCase(MPSDefs.DB_GENDER))
				|| (key.equalsIgnoreCase(MPSDefs.DB_PROOFING_ZIP))// Start - Added on 05/12/06 for LSR3 - Keshavi
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_ANSWER_1))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_ANSWER_2))
				|| (key.equalsIgnoreCase(MPSDefs.DB_PREVIOUS_CONTACT_EMAIL))
				|| (key.equalsIgnoreCase(MPSDefs.DB_DES3_PASSWORD))// added as per NAPII & R6
				|| (key.equalsIgnoreCase(MPSDefs.DB_LANGUAGE))// added as per NAP4
				|| (key.equalsIgnoreCase(MPSDefs.DB_NUM_TOS_REJECTS))// added as for att.net (NAP-5) Migrations(2008 Aug)
				|| (key.equalsIgnoreCase(MPSDefs.DB_BROWSER_LANGUAGE))
				|| (key.equalsIgnoreCase(MPSDefs.DB_ATLAS_LAST_TIMESTAMP))
				|| (key.equalsIgnoreCase(MPSDefs.DB_DSL_NET_ENCR_TYPE))
				|| (key.equalsIgnoreCase(MPSDefs.DB_DSL_NET_PASSWORD))
				|| (key.equalsIgnoreCase(MPSDefs.DB_ACTIVATED_IND)) // by dm876h for 1106
				|| (key.equalsIgnoreCase(MPSDefs.DB_PASSCODE_VENC)) // added for OCT 2011
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_ANSWER_VENC)) // added for OCT 2011
				|| (key.equalsIgnoreCase(MPSDefs.DB_BIRTHDATE_VENC)) // added for OCT 2011
				|| (key.equalsIgnoreCase(MPSDefs.DB_MERGEABLE_IND)) // added for US253136 - 1408
				|| (key.equalsIgnoreCase(ProfileOrchestrationConstants.DB_CBR_NUMBER)) // added for US253136 - 1408
				|| (key.equalsIgnoreCase(ProfileOrchestrationConstants.DB_CONTACT_ADDRESS)) // added for US253136 - 1408
		) {

			sReturn = "String";
		}

		if ((key.equalsIgnoreCase(MPSDefs.DB_SOR_ID)) || (key.equalsIgnoreCase(MPSDefs.DB_ACCESS_ID))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_ID))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_ID_1))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_ID_2))
				|| (key.equalsIgnoreCase(MPSDefs.DB_FAILED_AUTH_COUNT)
						|| (key.equalsIgnoreCase(MPSDefs.DB_SLID_MEMBER_NUM)))

		) {

			sReturn = "Int";
		}

		if ((key.equalsIgnoreCase(MPSDefs.DB_MIGRATION_DATE)) || (key.equalsIgnoreCase(MPSDefs.DB_DELETE_REQUEST_DATE))
				|| (key.equalsIgnoreCase(MPSDefs.DB_LOCKOUT_TIMESTAMP))// Added on 05/12/06 for LSR3 - Keshavi
				|| (key.equalsIgnoreCase(MPSDefs.DB_TOS_REJECT_DATE))// added as for att.net (NAP-5) Migrations(2008 Aug)
				|| (key.equalsIgnoreCase(MPSDefs.DB_CSR_INITIATED_LOCKOUT_TS))
				|| (key.equalsIgnoreCase("last_verified")) // added for US 7440
				|| (key.equalsIgnoreCase(MPSDefs.DB_MAIN_CTN_OPT_OUT))
				|| (key.equalsIgnoreCase(MPSDefs.DB_CONTACT_EMAIL_OPT_OUT))// added for US279458: 1410
				|| (key.equalsIgnoreCase(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE))
				|| (key.equalsIgnoreCase(CommonDefs.DB_ACCESS_ID_RTV_DATE))
				|| (key.equalsIgnoreCase(MPSDefs.DB_CBR_OPT_OUT)) // added for US293355: 1410
				|| (key.equalsIgnoreCase(MPSDefs.DB_ONL_QA_EST_DATE)) // added for 1510 : EPIC PID 266956b CTN Alias for Fraud
				|| (key.equalsIgnoreCase(ProfileOrchestrationConstants.DB_CBR_RTV_DATE))
		) {
			sReturn = "Date";
		}

		return sReturn;
	}
	
	/**
	 * This method updates the member group information in the database.
	 * It takes a HashMap as input which contains key-value pairs for various member group attributes.
	 * The method first checks if the input HashMap is null or if it contains invalid data. If it does, it returns an error status.
	 * Then it retrieves the member group attributes from the input HashMap.
	 * If the member group attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param hmInput A HashMap containing the details of the member group to be updated.
	 * @return A HashMap containing the status of the operation and the updated member group's information.
	 */
	public HashMap updateMemberGroup (HashMap hmInput) {
		
		String sMethodName = ".updateMemberGroup.";
		StringBuilder sqlStmt = new StringBuilder();
		String whereClause = null;
		boolean groupNumFlag = false;
		long groupNum = 0;
		HashMap status = null;
		List<Object> objectList = CommonUtil.getArrayList();
		Date dtStartDate = new Date();

		log.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmInput));
		try {

			String groupNumStr = (String) hmInput.get(MPSDefs.DB_GROUP_NUM);
			String domain = (String) hmInput.get(MPSDefs.DB_DOMAIN_NAME);
			String lastModifiedBy = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);

			if (groupNumStr != null && groupNumStr.length() != 0) {
				whereClause = "WHERE GROUP_NUM=?";
				groupNum = Long.parseLong(groupNumStr);
				groupNumFlag = true;
			} else {
				whereClause = "WHERE GROUP_NUM = (SELECT GROUP_NUM FROM MEMBERGROUP m, DOMAIN d WHERE m.PARENT_NAME=? AND d.DOMAIN_NAME=? AND m.DOMAIN_ID=d.DOMAIN_ID)";
			}

			sqlStmt.append("UPDATE MEMBERGROUP SET ");

			String key = null;
			String value = null;
			for (Iterator e = hmInput.keySet().iterator(); e.hasNext();) {

				key = (String) e.next();
				value = (String) hmInput.get(key);

				if (key.equalsIgnoreCase(MPSDefs.DB_PARENT_NAME) && value != null) {
					sqlStmt.append(MPSDefs.DB_PARENT_NAME + "= ? ,");
				}
			}

			sqlStmt.append("LAST_MODIFIED_BY = ? ");
			sqlStmt.append(whereClause);

			int i = 0;
			for (Iterator e = hmInput.keySet().iterator(); e.hasNext();) {

				key = (String) e.next();
				value = (String) hmInput.get(key);

				if (key.equalsIgnoreCase(MPSDefs.DB_PARENT_NAME) && value != null) {
					objectList.add(value);
				}
			}

			objectList.add(lastModifiedBy);

			if (groupNumFlag) {
				objectList.add(groupNum);

			} else {
				objectList.add(objectList.add(groupNum));
				objectList.add(domain);
			}

			log.info("{}{}MPSDB4 : UpdateDBHelper.updateMemberGroup::sqlStmt ={}", sClassName, sMethodName, sqlStmt);

			int rowCount = jdbcTemplate.update(new String(sqlStmt), objectList.toArray(new Object[objectList.size()]));

			if (rowCount == 0) {
				status = StatusMsg.makeSQLStatus(MPSDefs.REC_NOT_FOUND, MPSDefs.REC_NOT_FOUND_MSG, MPSDefs.SQL_ERR,
						MPSDefs.SQL_ERR_MSG, MPSDefs.NO_ROW_UPDATED);
			} else {

				// DB process successfully
				status = StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS, MPSDefs.MPS_ALL_OK, MPSDefs.SQL_SUCCESS,
						MPSDefs.SQL_SUCCESS_MSG, Integer.toString(rowCount));
			}
		}
		catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			status = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}MPSDB7a : Error::{}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}MPSDB7a.1 : Exception = {}", sClassName, sMethodName, e);
		} finally {
			log.info("{}{}DBTOOLS999 : response : {}{}", sClassName, sMethodName, dtStartDate.getTime(), status);
		}
		
		return status;
	}

	/**
	 * This method updates the member information in the database.
	 * It takes a HashMap as input which contains key-value pairs for various member attributes.
	 * The method first checks if the input HashMap is null or if it contains invalid data. If it does, it returns an error status.
	 * Then it retrieves the member attributes from the input HashMap.
	 * If the member attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param hmDbInput A HashMap containing the details of the member to be updated.
	 * @return A HashMap containing the status of the operation and the updated member's information.
	 */
	public HashMap updateMember(HashMap hmDbInput) {
		String sMethodName = ".updateMember.";

		HashMap hmResult = null;
		List<Object> objectList = CommonUtil.getArrayList();
		String sAppStatusCode = null;
		String sAppInfo = null;

		Date dtStartDate = new Date();
		log.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmDbInput));
		String sMemNumVal = null;
		String whereClause = null;
		String columnNames = "";

		StringBuilder query = new StringBuilder(" UPDATE MEMBER ");

		java.util.List argsKeys = CommonUtil.getArrayList();
		java.util.List argsVals = CommonUtil.getArrayList();
		java.util.List Keys = CommonUtil.getArrayList();

		if (hmDbInput == null) {
			return hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_EMPTY_NUM, "Input hash is empty");
		}

		// 1612 Voltage Encrypt SPI Fields in MEMBER Table
		hmResult = oProcessVoltageHelper.voltageEncryptSPIFields(hmDbInput);

		if (hmResult == null) {
			sAppInfo = "Null response from ProcessVoltageHelper.voltageEncryptSPIFields() call.";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
			log.info("{}{}MPSDBUM_01 : {}", sClassName, sMethodName, sAppInfo);
			return hmResult;
		}

		sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

		if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
			sAppInfo = "ProcessVoltageHelper.voltageEncryptSPIFields() call failed.";
			hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(sAppStatusCode), sAppInfo);
			log.info("{}{}MPSDBUM_02 : {}", sClassName, sMethodName, sAppInfo);
			return hmResult;
		}
		// 1612 END

		query.append(" SET ");
		log.info("{}{}MPSDBUM_03 : {}", sClassName, sMethodName, query);

		try {
			// If input has DB_SECURITY_QUESTION and not DB_SECURITY_QUESTION_ID
			int security_question_id = -1;
			// Check for the security_question in the request
			if (hmDbInput.containsKey(MPSDefs.DB_SECURITY_QUESTION)) {
				if (hmDbInput.containsKey(MPSDefs.DB_SECURITY_QUESTION_ID)) {
					hmDbInput.remove(MPSDefs.DB_SECURITY_QUESTION);
				} else {
					// get security_question_id
					String security_question = (String) hmDbInput.get(MPSDefs.DB_SECURITY_QUESTION);
					security_question_id = oDBHelper.getSecurityQuestionId(security_question);

					log.info("{}{}MPSDBUM_04 : {}", sClassName, sMethodName, "security_question_id ="
							+ security_question_id);

					if (security_question_id == -1) {
						sAppInfo = "Cannot find security_question_id for the given security_question= "
								+ security_question;
						hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, sAppInfo);
						log.info("{}{}MPSDBUM_05 : {}", sClassName, sMethodName, sAppInfo);
						return hmResult;
					}
				}
			}

			int security_question_id_1 = -1;
			// Check for the security_question_1 in the request
			if (hmDbInput.containsKey(MPSDefs.DB_SECURITY_QUESTION_1)) {
				if (hmDbInput.containsKey(MPSDefs.DB_SECURITY_QUESTION_ID_1)) {
					hmDbInput.remove(MPSDefs.DB_SECURITY_QUESTION_1);
				} else {
					// get security_question_id_1
					String security_question_1 = (String) hmDbInput.get(MPSDefs.DB_SECURITY_QUESTION_1);
					security_question_id_1 = oDBHelper.getSecurityQuestionId(security_question_1);
					log.info("{}{}MPSDBUM_06 : {}", sClassName, sMethodName, "security_question_id_1 ="
							+ security_question_id_1);
					if (security_question_id_1 == -1) {
						sAppInfo = "Cannot find security_question_id_1 for the given security_question_1 = "
								+ security_question_1;
						hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, sAppInfo);
						log.info("{}{}MPSDBUM_07 : {}", sClassName, sMethodName, sAppInfo);
						return hmResult;
					}
				}
			}

			int security_question_id_2 = -1;
			// Check for the security_question_2 in the request
			if (hmDbInput.containsKey(MPSDefs.DB_SECURITY_QUESTION_2)) {
				if (hmDbInput.containsKey(MPSDefs.DB_SECURITY_QUESTION_ID_2)) {
					hmDbInput.remove(MPSDefs.DB_SECURITY_QUESTION_2);
				} else {
					// get security_question_id_2
					String security_question_2 = (String) hmDbInput.get(MPSDefs.DB_SECURITY_QUESTION_2);
					security_question_id_2 = oDBHelper.getSecurityQuestionId(security_question_2);
					log.info("{}{}MPSDBUM_08 : {}", sClassName, sMethodName, "security_question_id_2 ="
							+ security_question_id_2);

					if (security_question_id_2 == -1) {
						sAppInfo = "Cannot find security_question_id_2 for the given security_question_2 ="
								+ security_question_2;
						hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, sAppInfo);
						log.info("{}{}MPSDBUM_09 : {}", sClassName, sMethodName, sAppInfo);
						log.info(sClassName + sMethodName + "DBTOOLS_09 : " + sAppInfo);
						return hmResult;
					}
				}
			}

			// 1510 : EPIC PID 266956b CTN Alias for Fraud
			if (!hmDbInput.containsKey(MPSDefs.DB_ONL_QA_EST_DATE)) {
				if (hmDbInput.containsKey(MPSDefs.DB_SECURITY_ANSWER_1)
						|| hmDbInput.containsKey(MPSDefs.DB_SECURITY_ANSWER_2)) {
					hmDbInput.put(MPSDefs.DB_ONL_QA_EST_DATE, "");
				}
			}

			if (hmDbInput.containsKey(MPSDefs.DB_ACTIVATED_IND)) {
				String sActivatedIndFlag = (String) hmDbInput.get(MPSDefs.DB_ACTIVATED_IND);
				if (sActivatedIndFlag != null && sActivatedIndFlag.equalsIgnoreCase("Y")) {
					Date dtTodayDate = new Date();
					DateFormat dateFormat = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
					String stTodayDate = dateFormat.format(dtTodayDate);
					hmDbInput.put(MPSDefs.DB_ACTIVATED_DATE, stTodayDate);
				} else {
					hmDbInput.remove(MPSDefs.DB_ACTIVATED_DATE);
				}
			}

			if (hmDbInput.containsKey(MPSDefs.DB_CBR_OPT_OUT )) {
				String sCbrOptOut  = (String) hmDbInput.get(MPSDefs.DB_CBR_OPT_OUT);
				if (sCbrOptOut != null && sCbrOptOut.equalsIgnoreCase(MPSDefs.YES)) {
					Date dtTodayDate = new Date();
					DateFormat dateFormat = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
					String sStartDate = dateFormat.format(dtTodayDate);
					hmDbInput.put(MPSDefs.DB_CBR_OPT_OUT, sStartDate);
				}
				else {
					hmDbInput.remove(MPSDefs.DB_CBR_OPT_OUT);
				}
			}

			if (hmDbInput.containsKey(MPSDefs.DB_MAIN_CTN_OPT_OUT)) {
				String sMainCTNOptOutFlag = (String) hmDbInput.get(MPSDefs.DB_MAIN_CTN_OPT_OUT);
				if (sMainCTNOptOutFlag != null && sMainCTNOptOutFlag.equalsIgnoreCase("Y")) {
					Date dtTodayDate = new Date();
					DateFormat dateFormat = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
					String stTodayDate = dateFormat.format(dtTodayDate);
					hmDbInput.put(MPSDefs.DB_MAIN_CTN_OPT_OUT, stTodayDate);
				} else {
					hmDbInput.remove(MPSDefs.DB_MAIN_CTN_OPT_OUT);
				}
			}

			if (hmDbInput.containsKey(CommonDefs.DB_ACCESS_ID_RTV_DATE)) {
				String sAccessRTVFlag = (String) hmDbInput.get(CommonDefs.DB_ACCESS_ID_RTV_DATE);
				if (sAccessRTVFlag != null && sAccessRTVFlag.equalsIgnoreCase("N")) {
					hmDbInput.put(CommonDefs.DB_ACCESS_ID_RTV_DATE, null);
				}
			}

			if (hmDbInput.containsKey(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE)) {
				String sContactEmailRTVFlag = (String) hmDbInput.get(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE);
				if (sContactEmailRTVFlag != null && sContactEmailRTVFlag.equalsIgnoreCase("N")) {
					hmDbInput.put(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE, null);
				}
			}

			if (hmDbInput.containsKey(MPSDefs.DB_LAST_VERIFIED)) {
				String sLastVerifiedFlag = (String) hmDbInput.get(MPSDefs.DB_LAST_VERIFIED);
				if (sLastVerifiedFlag != null && sLastVerifiedFlag.equalsIgnoreCase("Y")) {
					Date dtTodayDate = new Date();
					DateFormat dateFormat = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
					String stTodayDate = dateFormat.format(dtTodayDate);
					hmDbInput.put(MPSDefs.DB_LAST_VERIFIED, stTodayDate);
				} else {
					hmDbInput.remove(MPSDefs.DB_LAST_VERIFIED);
				}
			}

			if (hmDbInput.containsKey(ProfileOrchestrationConstants.DB_CBR_RTV_DATE)) {
				String sCbrRTVFlag = (String) hmDbInput.get(ProfileOrchestrationConstants.DB_CBR_RTV_DATE);
				if (sCbrRTVFlag != null && sCbrRTVFlag.equalsIgnoreCase("Y")) {
					Date dtTodayDate = new Date();
					DateFormat dateFormat = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
					String stTodayDate = dateFormat.format(dtTodayDate);
					hmDbInput.put(ProfileOrchestrationConstants.DB_CBR_RTV_DATE, stTodayDate);
				} else {
					hmDbInput.put(ProfileOrchestrationConstants.DB_CBR_RTV_DATE, null);
				}
			}

			// added below declarations as part of APRIL-2011 CAST analysis changes
			// to avoid instantiations inside loops
			SimpleDateFormat sdf = null;
			String sKey = null;
			String key = null; // Cast Fixes - 1106 Release
			String sTransactionName = null; // 2016.07 SID44581

			Iterator it = hmDbInput.keySet().iterator();
			while (it.hasNext()) {
				key = (String) it.next();

				if (key.equalsIgnoreCase(MPSDefs.DB_MEMBER_NUM)) {
					sMemNumVal = (String) hmDbInput.get(key);
					log.info("{}{}MPSDBUM_10 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sMemNumVal)));
				} else {
					sTransactionName = (String) hmDbInput.get(CommonDefs.TRANSACTION_NAME); // 2016.07 SID44581
					if (memberCheckKey(key) || ((sTransactionName != null && sTransactionName.equals("GenericDataFix"))
							&& (key.equalsIgnoreCase(MPSDefs.DB_ACCESS_ID) || key.equalsIgnoreCase(MPSDefs.DB_SOR_ID)
							|| key.equalsIgnoreCase(MPSDefs.DB_BAN)))) // 2016.07 SID44581
					// 1711 - Updated to include nullifying of BAN via GenericDataFix API
					{
						if (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION)) {
							argsKeys.add(MPSDefs.DB_SECURITY_QUESTION_ID + " = ?");
							argsVals.add("" + security_question_id);
							// changing the key as we have to set security_question_id ie., retrieved above
							Keys.add(MPSDefs.DB_SECURITY_QUESTION_ID);
						} else if (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_1)) {
							argsKeys.add(MPSDefs.DB_SECURITY_QUESTION_ID_1 + " = ?");
							argsVals.add("" + security_question_id_1);
							Keys.add(MPSDefs.DB_SECURITY_QUESTION_ID_1);
						} else if (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_2)) {
							argsKeys.add(MPSDefs.DB_SECURITY_QUESTION_ID_2 + " = ?");
							argsVals.add("" + security_question_id_2);
							Keys.add(MPSDefs.DB_SECURITY_QUESTION_ID_2);
						} else if (key.equalsIgnoreCase(MPSDefs.DB_CONTACT_EMAIL_EST_DATE)) {
							sdf = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
							String sConEmailEstDate = (String) hmDbInput.get(key);
							if (sConEmailEstDate != null && sConEmailEstDate.trim().length() > 0) {
								argsVals.add(sConEmailEstDate);
							} else {
								String sSysDate = sdf.format(dtStartDate);
								argsVals.add(sSysDate);
							}

							argsKeys.add(MPSDefs.DB_CONTACT_EMAIL_EST_DATE + " = ?");
							Keys.add(MPSDefs.DB_CONTACT_EMAIL_EST_DATE);
						} else if (key.equalsIgnoreCase(MPSDefs.DB_ONL_QA_EST_DATE)) {
							sdf = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
							String sOnlQAEstDate = (String) hmDbInput.get(MPSDefs.DB_ONL_QA_EST_DATE);
							if (sOnlQAEstDate != null && sOnlQAEstDate.trim().length() > 0) {
								argsVals.add(sOnlQAEstDate);
							} else {
								String sSysDate = sdf.format(dtStartDate);
								argsVals.add(sSysDate);
							}

							argsKeys.add(MPSDefs.DB_ONL_QA_EST_DATE + " = ?");
							Keys.add(MPSDefs.DB_ONL_QA_EST_DATE);
						} else if (key.equalsIgnoreCase(MPSDefs.DB_MIGRATION_DATE)) { // Added for 1610 - PID 288753 IAM
							// Support Target Biller
							sdf = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
							String sMigrationDate = (String) hmDbInput.get(MPSDefs.DB_MIGRATION_DATE);
							if (sMigrationDate != null && sMigrationDate.trim().length() > 0) {
								argsVals.add(sMigrationDate);
							} else {
								String sSysDate = sdf.format(dtStartDate);
								argsVals.add(sSysDate);
							}

							argsKeys.add(MPSDefs.DB_MIGRATION_DATE + " = ?");
							Keys.add(MPSDefs.DB_MIGRATION_DATE);
						} else if (key.equalsIgnoreCase(CommonDefs.DB_ACCESS_ID_RTV_DATE)) {
							sdf = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
							String sAccessIdRTVDate = (String) hmDbInput.get(CommonDefs.DB_ACCESS_ID_RTV_DATE);
							if (sAccessIdRTVDate == null) {
								argsVals.add(sAccessIdRTVDate);
							} else {
								String sSysDate = sdf.format(dtStartDate);
								argsVals.add(sSysDate);
							}
							argsKeys.add(CommonDefs.DB_ACCESS_ID_RTV_DATE + " = ?");
							Keys.add(CommonDefs.DB_ACCESS_ID_RTV_DATE);
						}else if (key.equalsIgnoreCase(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE)) {
							sdf = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
							String sContactEmailRTVFlag = (String) hmDbInput.get(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE);
							if (sContactEmailRTVFlag == null) {
								argsVals.add(sContactEmailRTVFlag);
							} else {
								String sSysDate = sdf.format(dtStartDate);
								argsVals.add(sSysDate);
							}
							argsKeys.add(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE + " = ?");
							Keys.add(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE);
						} else {
							argsKeys.add(key + " = ?");
							argsVals.add((String) hmDbInput.get(key));
							Keys.add(key);
						}
					}
				}
			} // end of while

			int len = argsKeys.size();
			int i;

			for (i = 0; i < len; i++) {
				query.append(argsKeys.get(i));

				if (i != (len - 1)) {
					query.append(" , ");
				}
			}

			if (sMemNumVal != null && sMemNumVal.trim().length() > 0) {
				whereClause = "member_num =? ";
				query.append(" WHERE " + whereClause);
				log.info("{}{}MPSDBUM_11 : Query = {}", sClassName, sMethodName, query);
			} else {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM,
						"member_num is null or empty in input");
				return hmResult;
			}

			i = 0;

			for (i = 0; i < argsVals.size(); i++) {

				if (memberTypeSet((String) Keys.get(i)).equals("Int")) {
					if (argsVals.get(i) != null)
						objectList.add(Integer.parseInt((String) argsVals.get(i)));
					else
						objectList.add(null);
				} else if (memberTypeSet((String) Keys.get(i)).equals("String")) {
					objectList.add((String) argsVals.get(i));
				} else if (memberTypeSet((String) Keys.get(i)).equals("Date")) {
					sKey = (String) Keys.get(i);

					sdf = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");

					if (argsVals.get(i) != null) {
						java.util.Date util_date = sdf.parse((String) argsVals.get(i));

						java.sql.Timestamp timeStamp = new java.sql.Timestamp(util_date.getTime());

						objectList.add(timeStamp);
					} else {
						objectList.add(null);
					}
				}
			} // end of argsVals for loop

			objectList.add(sMemNumVal);

			// Now excute the prepared statement
			int iCount = 0;
			if ((whereClause != null) && !(whereClause.length() == 0)) {
				iCount = jdbcTemplate.update(new String(query), objectList.toArray(new Object[objectList.size()]));

				log.info("{}{}MPSDBUM_12 : The rows updated are : {}", sClassName, sMethodName, iCount);
				if (iCount == 0) {
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
							"No Record found for given member_num");
				} else {
					hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
							"No of rows updated in MEMBER table : " + iCount);
				}
			} else {
				hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_EMPTY_NUM, "where clause is not prepared");
				log.info("{}{}MPSDBUM_13 : {}", sClassName, sMethodName, "where clause is not prepared");
				return hmResult;
			}

			// 1612 Voltage Encrypt SPI Fields in MEMBER Table
			hmResult = updateMemberAUX(hmDbInput);

			if (hmResult == null || hmResult.isEmpty()) {
				sAppInfo = "Null response from MPSDB_Update_H.updateMemberAux() call.";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				log.error("{}{}MPSDBUM_14 : {}", sClassName, sMethodName, sAppInfo);
				return hmResult;
			}

			sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

			if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
				sAppInfo = "MPSDB_Update_H.updateMemberAux() call failed.";
				hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(sAppStatusCode), sAppInfo);
				log.error("{}{}MPSDBUM_15 : {}", sClassName, sMethodName, sAppInfo);
				return hmResult;
			}
		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}MPSDBUM_16 : Error:: {}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}MPSDBUM_17 : Exception = {}", sClassName, sMethodName, e);

		} finally {
			log.error("{}{}DBTOOLS999 : update MEMBER response is : {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;
	}

	/**
	 * This method updates the contact information of a member in the database.
	 * It takes a HashMap as input which contains key-value pairs for various member attributes.
	 * The method first checks if the input HashMap is null or if it contains invalid data. If it does, it returns an error status.
	 * Then it retrieves the member attributes from the input HashMap.
	 * If the member attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param InpParam A HashMap containing the details of the member to be updated.
	 * @return A HashMap containing the status of the operation and the updated member's information.
	 */
	public HashMap updateContactInfo(HashMap InpParam) {

		String sMethodName = ".updateContactInfo.";
		log.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(InpParam));
		HashMap resultHash = null;
		List<Object> objectList = CommonUtil.getArrayList();
		int rowCount = 0;

		String sContactEmail = (String) InpParam.get(MPSDefs.DB_CONTACT_EMAIL);
		String sContactEmailStatus = (String) InpParam.get(MPSDefs.DB_CONTACT_EMAIL_STATUS);
		String sSlidMemberNum = (String) InpParam.get(MPSDefs.DB_SLID_MEMBER_NUM);
		String sPreviousContactEmail = (String) InpParam.get(MPSDefs.DB_PREVIOUS_CONTACT_EMAIL);
		String sLastModifiedBy = (String) InpParam.get(CommonDefs.CALLING_SYSTEM_ID);
		String scontactEmailRTValidFlag = (String) InpParam.get("contact_email_rtv_date");
		StringBuilder sQuery = new StringBuilder("UPDATE MEMBER SET LAST_MODIFIED_BY=?");

		if (sContactEmail != null && !sContactEmail.isEmpty()){
			sQuery.append(" , CONTACT_EMAIL =?");
		}
		if (sContactEmailStatus != null && !sContactEmailStatus.isEmpty()){
			sQuery.append(" , CONTACT_EMAIL_STATUS =?");
		}
		if (sPreviousContactEmail != null && !sPreviousContactEmail.isEmpty()){
			sQuery.append(" , PREVIOUS_CONTACT_EMAIL =?");
		}

		if (scontactEmailRTValidFlag != null && scontactEmailRTValidFlag.equalsIgnoreCase("Y")) {
			sQuery.append(" , CONTACT_EMAIL_RTV_DATE = to_date(?,'MMddyyyy HH24:mi:ss')");
		} else {
			sQuery.append(" , CONTACT_EMAIL_RTV_DATE = ?");
		}


		sQuery.append(" WHERE SLID_MEMBER_NUM = ? AND (parent_child_ind || ':' || sor_id) <> 'P:6' ");

		try {
			log.info("{}{}MPSDBUCI_01 : Query = {}", sClassName, sMethodName, sQuery);

			objectList.add(sLastModifiedBy);
			log.info("{}{}MPSDBUCI_02 : last_modified_by = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sLastModifiedBy)));

			if (sContactEmail != null && !sContactEmail.isEmpty()){
				objectList.add(sContactEmail);
				log.info("{}{}MPSDBUCI_03 : contact_email = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sContactEmail)));
			}
			if (sContactEmailStatus != null && !sContactEmailStatus.isEmpty()){
				objectList.add(sContactEmailStatus);
				log.info("{}{}MPSDBUCI_04 : contact_email_status = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sContactEmailStatus)));
			}
			if (sPreviousContactEmail != null && !sPreviousContactEmail.isEmpty()){
				objectList.add(sPreviousContactEmail);
				log.info("{}{}MPSDBUCI_05 : previous_contact_email = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sPreviousContactEmail)));
			}

			if (scontactEmailRTValidFlag != null && scontactEmailRTValidFlag.equalsIgnoreCase("Y")) {
				Date dtTodayDate = new Date();
				DateFormat dateFormat = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
				String stTodayDate = dateFormat.format(dtTodayDate);
				objectList.add(stTodayDate);
				log.info("{}{}MPSDBUCI_06 : contact_email_rtv_date = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stTodayDate)));
			}else {
				objectList.add(null);
				log.info("{}{}MPSDBUCI_07 : contact_email_rtv_date = {}", sClassName, sMethodName, "null");
			}

			objectList.add(sSlidMemberNum);
			log.info("{}{}MPSDBUCI_08 : slid_member_num = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sSlidMemberNum)));

			rowCount = jdbcTemplate.update(new String(sQuery),objectList.toArray(new Object[objectList.size()]));
			log.info("{}{}MPSDBUCI_09 : Member table row updated = {}", sClassName, sMethodName, rowCount);

			resultHash = StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS, MPSDefs.MPS_ALL_OK, "0", MPSDefs.SQL_SUCCESS,
					MPSDefs.SQL_SUCCESS_MSG, Integer.toString(rowCount));

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			resultHash = StatusMsg.makeExceptionSQLStatus(e);
			log.error("{}{}MPSDBUCI_10 : Error:: {}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}MPSDBUCI_11 : Exception = {}", sClassName, sMethodName, e);

		} finally {
			log.info("{}{}DBTOOLS999 response : {}", sClassName, sMethodName, resultHash);
		}
		return resultHash;
	}

	/**
	 * Clears the SLID member number for a given member in the database.
	 * This method updates the MEMBER table to remove or reset the SLID_MEMBER_NUM field
	 * for the provided input parameters.
	 *
	 * @param InpParam a HashMap containing the details of the member whose SLID member number should be cleared
	 * @return a HashMap containing the status of the operation and any relevant information
	 */
	public HashMap clearSlidMemberNum(HashMap InpParam) {

		String sMethodName = "clearSlidMemberNum ";
		log.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(InpParam));

		HashMap resultHash = null;
		String sErrorCode;
		String sAppStatusCode = null;
		String sAppInfo = null;

		long tTime = 0;
		Date dtStartDate = new Date();

		List<Object> objectList = CommonUtil.getArrayList();

		int rowCount = 0;
		StringBuilder query = new StringBuilder("Update Member set slid_member_num=null where member_num in ( ");

		ArrayList alClearSlidMemberNumList = (ArrayList) InpParam.get("clearSlidMemberNum");

		if (alClearSlidMemberNumList == null || alClearSlidMemberNumList.isEmpty()) {
			sAppInfo = "clearSlidMemberNum is null or empty in input";
			resultHash = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM, sAppInfo);
			log.info("{}{}MPSDB.CSMN_01 : {}", sClassName, sMethodName, resultHash);
			return resultHash;
		}

		try {

			String includeMemberNum = "";

			for (int i = 0; i < alClearSlidMemberNumList.size(); i++) {
				if (i == 0)
					includeMemberNum = includeMemberNum + alClearSlidMemberNumList.get(i);
				else
					includeMemberNum = includeMemberNum + "," + alClearSlidMemberNumList.get(i);
			}

			query.append(includeMemberNum + ")");

			log.info("{}{}MPSDB.CSMN_02 : sClearSlidMemberNumSql {}", sClassName, sMethodName, query);

			rowCount = jdbcTemplate.update(new String(query));

			// Calculate the total time taken to insert rows in DB to return time in
			// milliseconds
			tTime = (System.currentTimeMillis() - dtStartDate.getTime());
			log.info("{}{}QUERY999 : Total time taken to execute query = {} milliseconds", sClassName, sMethodName,
					tTime);
			log.info("{}{}MPSDB.CSMN_05 : No of rows inserted:= {}", sClassName, sMethodName, rowCount);

			resultHash = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			resultHash = StatusMsg.makeExceptionSQLStatus(e);
			log.error("{}{}MPSDB.CSMN_06 : Error:: {}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}MPSDB.CSMN_07 : Exception = {}", sClassName, sMethodName, e);
		} finally {
			log.info("{}{}DBTOOLS999 response : {}", sClassName, sMethodName, resultHash);
		}
		return resultHash;
	}
}
