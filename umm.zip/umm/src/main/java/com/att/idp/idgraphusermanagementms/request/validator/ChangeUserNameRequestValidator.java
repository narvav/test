package com.att.idp.idgraphusermanagementms.request.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import jakarta.ws.rs.core.HttpHeaders;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.resource.request.ChangeUserNameRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ChangeUserNameResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;

/**
 * This class, ChangeUserNameRequestValidator, is responsible for validating the ChangeUserNameRequest.
 * It checks for the presence and validity of required fields in the request, and returns a ChangeUserNameResponse accordingly.
 * It is annotated with @Component, @Configuration, and @PropertySource to indicate that it's a Spring Bean,
 * to allow it to access configuration properties, and to specify the location of the properties file respectively.
 *
 * The class contains several methods, including:
 * - changeUserNameRequestValidator: the main method that orchestrates the validation process.
 * - changeUserNameErrorResponse: a helper method that generates an error response.
 * - changeUserNameRequestInputValidator: a method that validates the input fields in the request.
 * - changeUserNameIsExternalCallCheck: a method that checks the 'isExternalCall' field in the request.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class ChangeUserNameRequestValidator {
	private static final Logger logger = LoggerFactory.getLogger(ChangeUserNameRequestValidator.class);

	private String sClassName = "ChangeUserNameRequestValidator";

	@Value("${ChangeUserNameCallingSystemIds}")
	private String propCallingSystemIds;
	
	@Value("${ChangeUserNameAgentId_Required_CSIs}")
	private String propAgentIdRequiredCSI;

	
	/**
	 * This method is responsible for validating the ChangeUserNameRequest.
	 * It takes HttpHeaders and ChangeUserNameRequest as parameters.
	 * HttpHeaders contains the request headers which may include additional information required for processing the request.
	 * ChangeUserNameRequest encapsulates the details of the user name change operation to be performed.
	 *
	 * The method performs various checks and validations on the input parameters and returns a ChangeUserNameResponse object.
	 * The ChangeUserNameResponse object encapsulates the result of the user name change operation.
	 *
	 * @param requestHeader The HttpHeaders containing the request headers.
	 * @param changeUserNameRequest The ChangeUserNameRequest containing the details of the user name change operation.
	 * @return ChangeUserNameResponse The response of the user name change operation.
	 */
	public ChangeUserNameResponse changeUserNameRequestValidator(HttpHeaders requestHeader,
			ChangeUserNameRequest changeUserNameRequest) {

		ChangeUserNameResponse changeUserNameResponse = null;

		String stAppInfo = null;
		String sMethodName = ".changeUserNameRequestValidator.";
		String stIdpTraceId = null;
		String stXAttClientId = null;

        stIdpTraceId = CommonUtil.getTraceId(requestHeader);
		
		if (stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
			stAppInfo = "Missing or Invalid IdpTraceId";
			return changeUserNameErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
			
		if (changeUserNameRequest == null) {
			stAppInfo = "Input Request is NULL / Empty.";
			logger.info("{}{}CUNRV_101 :: {}", sClassName, sMethodName, stAppInfo);
			return changeUserNameErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		
		changeUserNameRequest.setIdpTraceId(stIdpTraceId);
		
		if (requestHeader.getHeaderString("X-ATT-ClientId") != null) {
			stXAttClientId = requestHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
			logger.info("{}{}CUNRV_102.2 : Setting callingSystemId: {}", sClassName, sMethodName, StringUtils.normalizeSpace(stXAttClientId));
			changeUserNameRequest.setCallingSystemId(stXAttClientId);
		}
		else {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			logger.info("{}{}CUNRV_102.3 :: {}", sClassName, sMethodName, stAppInfo);
			return changeUserNameErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		
		// checking Invalid attributes passed in Request
		Map<String, Object> allUnknownAttributes = new HashMap<>(changeUserNameRequest.unknownAttributes);

		if (!allUnknownAttributes.isEmpty()) {
			stAppInfo = "Invalid Attributes passed in ChangeUserNameRequest : " + allUnknownAttributes;
			return changeUserNameErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					changeUserNameRequest.getIdpTraceId());
		}

		try {
			changeUserNameResponse = changeUserNameRequestInputValidator(changeUserNameRequest);
			if (changeUserNameResponse != null) {
				logger.info("{}{}CUNRV_110 Response from changeUserNameRequestInputValidator : {}", sClassName,
						sMethodName, changeUserNameResponse);
				return changeUserNameResponse;
			}

			stAppInfo = "Input Validation Successful";
			logger.info("{}{}CUNRV_111 : {}", sClassName, sMethodName, stAppInfo);

		} catch (Exception e) {
			stAppInfo = "Exception thrown in ChangeUserNameRequestValidator.changeUserNameRequestValidator : "
					+ e.getMessage();
			changeUserNameResponse = changeUserNameErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo, stIdpTraceId);
			logger.info("Exception in changeUserNameRequestValidator: {}", stAppInfo);
		}

		return changeUserNameResponse;
	}

	private ChangeUserNameResponse changeUserNameRequestInputValidator(ChangeUserNameRequest changeUserNameRequest) {
		ChangeUserNameResponse changeUserNameResponse = null;
		String stAppInfo = null;
		String sMethodName = ".changeUserNameRequestInputValidator.";
		String stTransactionName = changeUserNameRequest.getTransactionName();
		String stCallingSystemId = changeUserNameRequest.getCallingSystemId();
		String stOldUserName = changeUserNameRequest.getOldUserName();
		String stNewUserName = changeUserNameRequest.getNewUserName();
		String stAgentId = changeUserNameRequest.getAgentId();
		String stIdpTraceId = changeUserNameRequest.getIdpTraceId();

		changeUserNameResponse = changeUserNameIsExternalCallCheck(changeUserNameRequest);
		if (changeUserNameResponse != null) {
			return changeUserNameResponse;
		}

		Optional.ofNullable(stCallingSystemId)
				.ifPresent(x -> changeUserNameRequest.setCallingSystemId(x.trim().toUpperCase()));

		Optional.ofNullable(stOldUserName).ifPresent(x -> changeUserNameRequest.setOldUserName(x.trim().toLowerCase()));

		Optional.ofNullable(stNewUserName).ifPresent(x -> changeUserNameRequest.setNewUserName(x.trim().toLowerCase()));

		Optional.ofNullable(stAgentId).ifPresent(x -> changeUserNameRequest.setAgentId(x.trim()));

		if (!"ChangeUserName".equals(stTransactionName)) {
			stAppInfo = "Transaction Not Allowed :: TransactionName Should be ChangeUserName";
			logger.info("{}{}CUNRV_104 : {}", sClassName, sMethodName, stAppInfo);
			return changeUserNameErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (StringUtils.isNotEmpty(changeUserNameRequest.getSuppressNotification())
				&& !(changeUserNameRequest.getSuppressNotification().equalsIgnoreCase(CommonDefs.IND_Y))
				&& !(changeUserNameRequest.getSuppressNotification().equalsIgnoreCase(CommonDefs.IND_N))) {
			stAppInfo = "suppressNotification value must be either Y or N";
			logger.info("{}{}CUNRV_105 : {}", sClassName, sMethodName, stAppInfo);
			return changeUserNameErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (StringUtils.isNotEmpty(changeUserNameRequest.getAccessIdRTValidFlag())
				&& !(changeUserNameRequest.getAccessIdRTValidFlag().equalsIgnoreCase(CommonDefs.IND_Y)
						|| changeUserNameRequest.getAccessIdRTValidFlag().equalsIgnoreCase(CommonDefs.IND_N))) {
			stAppInfo = "accessIdRTValidFlag value must be either Y or N";
			logger.info("{}{}CUNRV_106 : {}", sClassName, sMethodName, stAppInfo);
			return changeUserNameErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		ArrayList<String> alValidCallers = CommonUtil.parseToArray(propCallingSystemIds,
				CommonDefs.VALUE_SEPARATOR_CHAR);
		logger.info("CUNRV_107 : all Valid callers for ChangeUserName : {}", alValidCallers);

		stCallingSystemId = changeUserNameRequest.getCallingSystemId();
		stAgentId = changeUserNameRequest.getAgentId();

		if (alValidCallers != null && !alValidCallers.contains(stCallingSystemId)) {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			logger.info("{}{}CUNRV_108 : {}", sClassName, sMethodName, stAppInfo);
			return changeUserNameErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		ArrayList<String> alAgentIdRequiredCSI = CommonUtil.parseToArray(propAgentIdRequiredCSI,
				CommonDefs.VALUE_SEPARATOR_CHAR);
		
		if (alAgentIdRequiredCSI.contains(stCallingSystemId) && (stAgentId == null || stAgentId.length() == 0)) {
			stAppInfo = "AgentID is required in request for provided X-ATT-ClientId";
			logger.info("{}{}CUNRV_109 : {}", sClassName, sMethodName, stAppInfo);
			return changeUserNameErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		return changeUserNameResponse;
	}

	private ChangeUserNameResponse changeUserNameIsExternalCallCheck(ChangeUserNameRequest changeUserNameRequest) {
		ChangeUserNameResponse changeUserNameResponse = null;
		String stAppInfo;
		String isExternalCall = changeUserNameRequest.getIsExternalCall();

		if ((isExternalCall != null && !isExternalCall.isEmpty())) {
			if (!(isExternalCall.equalsIgnoreCase(CommonDefs.IND_Y)
					|| isExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
				stAppInfo = "isExternalCall must be one of Y or N";
				return changeUserNameErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, changeUserNameRequest.getIdpTraceId());
			} else {
				changeUserNameRequest.setIsExternalCall(isExternalCall.trim().toUpperCase());
			}
		} else {
			changeUserNameRequest.setIsExternalCall(CommonDefs.IND_Y);
		}
		return changeUserNameResponse;
	}

	private ChangeUserNameResponse changeUserNameErrorResponse(int appStatusCode, String stAppInfo, String stIdpTraceId) {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		return CommonUtilHelper.generateChangeUserNameResponse(hmResponse);
	}
}