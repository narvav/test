package com.att.idp.idgraphusermanagementms.helper.resetuserpassword;

import java.util.HashMap;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.mpsys.common.utils.PropertyManager;
import com.att.idp.idgraphusermanagementms.helper.voltage.ProofingEncryptionHelper;
import com.att.idp.idgraphusermanagementms.utils.RILCheckAndEncryptPasswordHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.RILDefs;

/**
 * LDAPValidator is a class that provides helper methods for LDAP operations.
 * It contains methods for validating and populating data for different services such as DSL, ISDN, HSIA, SWH, and WIFI.
 * This class is annotated with @Component, meaning it is an object managed by the Spring framework.
 * It uses Autowired to inject instances of RILCheckAndEncryptPasswordHelper and ProofingEncryptionHelper.
 * The class also contains several constants and instance variables.
 *
 * @author kg852c
 */
@Component
public class LDAPValidator {

	// private static final String moduleinfo = "CVS Info";
	private static final String sClassName = "LDAPValidator";

	@Autowired
	private RILCheckAndEncryptPasswordHelper npHelper;

	@Autowired
	private ProofingEncryptionHelper oProofingEncryption_H;

	/**
	 * This method is responsible for validating the input parameters and member details for LDAP operations.
	 * It takes two HashMaps and a Logger as input.
	 * The first HashMap contains the input parameters, the second HashMap contains the member details from the database, and the Logger is used for logging.
	 * The method logs the start of the process and the input parameters.
	 * It checks various conditions such as the presence of certain keys in the HashMaps, the values of certain keys, etc.
	 * Based on these conditions, it decides whether to proceed with the LDAP operations or return a success message.
	 * If it decides to proceed with the LDAP operations, it calls various methods to validate and populate data for different services such as DSL, ISDN, HSIA, SWH, and WIFI.
	 * In case of any exception, it logs the error and returns an error HashMap.
	 * Finally, it logs the end of the process and the result, and returns the result HashMap.
	 *
	 * @param hmInput HashMap containing the input parameters.
	 * @param mpsData HashMap containing the member details from the database.
	 * @param log Logger used for logging.
	 * @return HashMap containing the result of the validation process.
	 */
	public HashMap validate(HashMap hmInput, HashMap mpsData, Logger log) {
		String sMethodName = ".validate.";

		String sAppInfo = null;
		String sAppStatusCode = null;
		HashMap servicesHash = null;
		HashMap accessHash = null;
		HashMap hostingHash = null;
		HashMap wifiHash = null;
		String stAccessName = null;
		HashMap hmResult = null;
		HashMap LDAPData = CommonUtil.getHashMap();

		String transID = (String) hmInput.get(CommonDefs.TRANSACTION_ID);
		LDAPData.put(MPSDefs.MPSTRANSID, transID);

		log.info(sClassName + sMethodName + "H4 : " + "inputParamHs = " + hmInput);
		//log.info(sClassName + sMethodName + "H5 : " + "mpsData hash = " + mpsData);
		log.info(sClassName + sMethodName + "H6 : " + "Transaction ID: " + transID);

		stAccessName = (String) mpsData.get(MPSDefs.DB_ACCESS_NAME);
		servicesHash = (HashMap) mpsData.get(MPSDefs.SERVICES);

		if (servicesHash != null && !servicesHash.isEmpty()) {
			accessHash = (HashMap) servicesHash.get(stAccessName);
			hostingHash = (HashMap) servicesHash.get(MPSDefs.SWH_SERVICE);
			wifiHash = (HashMap) servicesHash.get(MPSDefs.WIFI_SERVICE);
		} else {
			sAppInfo = "validator: No service hash for the user ";
			log.info(sClassName + sMethodName + "H7 : " + sAppInfo);
			hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, sAppInfo);
			return hmResult;
		}

		sAppInfo = "Before calling populateAndValidateCommonData ... Access Hash = " + accessHash
				+ " ... and Hosting Hash = " + hostingHash + " ... and Wifi Hash = " + wifiHash;

		log.info(sClassName + sMethodName + "H8 : " + sAppInfo);

		hmResult = populateAndValidateCommonData(accessHash, hmInput, mpsData, log);

		sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

		if (null != sAppStatusCode && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
			log.info(sClassName + sMethodName + "H8b : " + "HashMap Returned from populateAndValidateCommonData() : " + hmResult);
			return hmResult;
		}

		LDAPData.putAll(hmResult);

		hmResult = validateparent(mpsData, log);

		sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

		if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
			log.info(sClassName + sMethodName + "H210b : " + "HashMap Returned from validateparent() : " + hmResult);
			return hmResult;
		}

		LDAPData.put(MPSDefs.G2_ACCESSENABLED, CommonDefs.DEFAULT_FALSE);
		LDAPData.put(MPSDefs.G2_SERVICESWHENABLED, CommonDefs.DEFAULT_FALSE);

		if (accessHash != null) {
			if (stAccessName.equalsIgnoreCase(MPSDefs.DIAL_SERVICE)) {
				log.info(sClassName + sMethodName + "H9 : " + "user has DIAL Access");

				hmResult = validateAccess(accessHash, mpsData, log);

				sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

				if (null != sAppStatusCode && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
					log.info(sClassName + sMethodName + "H252b : " + "HashMap Returned from validateAccess() : "
							+ hmResult);
					return hmResult;
				}

				LDAPData.putAll(hmResult);

			} else if (stAccessName.equalsIgnoreCase(MPSDefs.DSL_SERVICE)) {
				log.info(sClassName + sMethodName + "H10 : " + "user has DSL Access");

				hmResult = validateDSL(accessHash, mpsData, log);

				sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

				if (null != sAppStatusCode && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
					log.info(sClassName + sMethodName + "H123b : " + "HashMap Returned from validateDSL() : "
							+ hmResult);
					return hmResult;
				}

				LDAPData.putAll(hmResult);

			} else if (stAccessName.equalsIgnoreCase(MPSDefs.ISDN_SERVICE)
					|| stAccessName.equalsIgnoreCase(MPSDefs.ISDN2_SERVICE)) {
				log.info(sClassName + sMethodName + "H11 : " + "user has ISDN Access");

				hmResult = validateISDN(accessHash, mpsData, log);

				sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

				if (null != sAppStatusCode && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
					log.info(
							sClassName + sMethodName + "H836b : " + "HashMap Returned from validateISDN() : " + hmResult);
					return hmResult;
				}

				LDAPData.putAll(hmResult);

			} else if (stAccessName.equalsIgnoreCase(MPSDefs.HSIA_SERVICE)) {
				log.info(sClassName + sMethodName + "H11.1 : " + "user has HSIA Access");

				hmResult = validateHSIA(accessHash, mpsData, log);

				sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

				if (null != sAppStatusCode && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
					log.info(
							sClassName + sMethodName + "H8b : " + "HashMap Returned from validateHSIA() : " + hmResult);
					return hmResult;
				}

				LDAPData.putAll(hmResult);
			}
		}

		if (hostingHash != null) {
			log.info(sClassName + sMethodName + "H8b : " + "HashMap Returned from validateparent() : " + hmResult);
			log.info(sClassName + sMethodName + "H12 : " + "user has SWH Service");

			hmResult = validateSWH(hostingHash, mpsData, log);
			LDAPData.putAll(hmResult);
		}

		if (wifiHash != null) {
			log.info(sClassName + sMethodName + "H8b : " + "HashMap Returned from validateparent() : " + hmResult);
			log.info(sClassName + sMethodName + "H13 : " + "user has WIFI Service");

			hmResult = validateWIFI(wifiHash, mpsData, log);

			sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

			if (null != sAppStatusCode && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
				log.info(sClassName + sMethodName + "H8b : " + "HashMap Returned from validateWIFI() : " + hmResult);
				return hmResult;
			}

			LDAPData.putAll(hmResult);
		}

		// If callingSystemId = UST and MID is a
		// parent account and has HSIA or DSL service then add
		// "gforcepush = true" to JMS MapMessage content else add "gforcepush =
		// false".*/
		String stParentChildInd = (String) mpsData.get(MPSDefs.DB_PARENT_CHILD_IND);
		String stCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

		// Updated for DATAMGT caller from CRMUpdateServices, check the "forcepush" in
		// the input
		// and if it is present and value=true, set gforcepush=true - JUNE2012
		String stForcePush = (String) hmInput.get("forcepush");

		if ((stAccessName.equalsIgnoreCase(MPSDefs.DSL_SERVICE) || stAccessName.equalsIgnoreCase(MPSDefs.HSIA_SERVICE))
				&& (stParentChildInd != null && stParentChildInd.equalsIgnoreCase(MPSDefs.MPS_PARENT))
				&& ((stCallingSystemId != null && stCallingSystemId.equalsIgnoreCase(CommonDefs.CALLING_SYSTEM_ID_UST))
						|| (stForcePush != null && stForcePush.equalsIgnoreCase(CommonDefs.DEFAULT_TRUE)))) {

			LDAPData.put(MPSDefs.G2_FORCEPUSH, CommonDefs.DEFAULT_TRUE);
		} else {
			LDAPData.put(MPSDefs.G2_FORCEPUSH, CommonDefs.DEFAULT_FALSE);
		}

		// Added for Sync call to Dbus flag from SyncG2LDAP - AUG12
		LDAPData.put("SyncG2", (String) hmInput.get("SyncG2"));

		log.info(sClassName + sMethodName + "H14 : " + "Validation completed successfully. LDAP Data Hash = "
				+ LDAPData);
		return LDAPData;
	}

	/**
	 * 
	 * @param accessHashMap
	 * @param mpsData
	 * @param LDAPData
	 * @param log
	 * @return HashMap
	 */
	private HashMap populateAndValidateCommonData(HashMap accessHashMap, HashMap inpParam, HashMap mpsData, Logger log) {
		String sMethodName = ".populateAndValidateCommonData.";
		String sAppInfo = null;
		HashMap hmResult = null;
		HashMap LDAPData = CommonUtil.getHashMap();

		String member_name = null;
		if ((member_name = (String) mpsData.get(MPSDefs.DB_MEMBER_NAME)) != null)
			LDAPData.put(MPSDefs.G2_USERID, member_name);
		else {
			hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_INVALID_DATA_NUM,
					"member_name missing in the mpsData hashmap");
			return hmResult;
		}
		String domain_name = null;
		if ((domain_name = (String) mpsData.get(MPSDefs.DB_DOMAIN_NAME)) != null)
			LDAPData.put(MPSDefs.G2_DOMAIN, domain_name);
		else {
			hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_INVALID_DATA_NUM,
					"domain_name missing in the mpsData hashmap");
			return hmResult;
		}
		String parent_name = null;
		String parent_domain = null;
		if (((parent_name = (String) mpsData.get(MPSDefs.DB_PARENT_NAME)) != null)
				&& ((parent_domain = (String) mpsData.get(MPSDefs.DB_PARENT_DOMAIN)) != null))
			LDAPData.put(MPSDefs.G2_PARENTUSERID, parent_name + "@" + parent_domain);
		else {
			hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_INVALID_DATA_NUM,
					"parent handle missing in the mpsData hashmap");
			return hmResult;
		}
		String fullname = null;
		if ((fullname = (String) mpsData.get(MPSDefs.DB_FULLNAME)) != null)
			LDAPData.put(MPSDefs.G2_FULLNAME, fullname);
		else {
			hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_INVALID_DATA_NUM,
					"fullname missing in the mpsData hashmap");
			return hmResult;
		}
		// added for SID#16210 Add 5 more LS Qs for G2(1104) - ak877k

		String stParentChildInd = null;
		if ((stParentChildInd = (String) mpsData.get(MPSDefs.DB_PARENT_CHILD_IND)) != null)
			LDAPData.put(MPSDefs.DB_PARENT_CHILD_IND, stParentChildInd);

		String uidnumber = null;
		if (accessHashMap != null && (uidnumber = (String) accessHashMap.get(MPSDefs.DB_WTN)) != null)
			LDAPData.put(MPSDefs.G2_UIDNUMBER, uidnumber);
		else
			LDAPData.put(MPSDefs.G2_UIDNUMBER, "99999");

		String gidnumber = null;

		if ((gidnumber = (String) mpsData.get(MPSDefs.DB_BAN)) != null)
			LDAPData.put(MPSDefs.G2_GIDNUMBER, gidnumber);
		else
			LDAPData.put(MPSDefs.G2_GIDNUMBER, "99999");

		String enc_password = null;
		if ((enc_password = (String) mpsData.get(MPSDefs.DB_ENC_PASSWORD)) != null) {
			enc_password = "{crypt}" + enc_password;
			LDAPData.put(MPSDefs.G2_CRYPTPASSWORD, enc_password);
		} else {
			hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_INVALID_DATA_NUM,
					"enc_password missing in the mpsData hashmap");
			return hmResult;
		}
		String md5_password = null;
		if ((md5_password = (String) mpsData.get(MPSDefs.DB_MD5_PASSWORD)) != null)
			LDAPData.put(MPSDefs.G2_MD5PASSWORD, md5_password);

		String stDes3Password = (String) mpsData.get(MPSDefs.DB_DES3_PASSWORD);
		if (stDes3Password != null)
			LDAPData.put(MPSDefs.G2_DES3PASSWD, stDes3Password);

		String mailhost = null;
		if ((mailhost = (String) mpsData.get(MPSDefs.DB_MAILHOST)) != null)
			LDAPData.put(MPSDefs.G2_MAILHOST, mailhost);

		String account_type = null;
		if ((account_type = (String) mpsData.get(MPSDefs.DB_ACCOUNT_TYPE)) != null) {
			if (account_type.compareToIgnoreCase(MPSDefs.DB_BUSINESS) == 0)
				LDAPData.put(MPSDefs.G2_ACCOUNTTYPE, MPSDefs.BUSINESS);
			else {
				if (account_type.compareToIgnoreCase(MPSDefs.DB_CONSUMER) == 0)
					LDAPData.put(MPSDefs.G2_ACCOUNTTYPE, MPSDefs.CONSUMER);
				else {
					LDAPData.put(MPSDefs.G2_ACCOUNTTYPE, MPSDefs.UNKNOWN);

					sAppInfo = "account type from database is " + account_type;
					log.info(sClassName + sMethodName + "H16 : " + sAppInfo);
				}
			}
		} else
			LDAPData.put(MPSDefs.G2_ACCOUNTTYPE, MPSDefs.UNKNOWN);

		String terminate_date = null;
		if (accessHashMap != null) {
			if ((terminate_date = (String) accessHashMap.get(MPSDefs.DB_MEMBER_TERMINATE_DATE)) != null) {
				log.info(sClassName + sMethodName + "H17 : " + "terminate_date is " + terminate_date);

				String ndate = terminate_date.substring(4, 8);
				ndate = ndate + terminate_date.substring(0, 4);
				LDAPData.put(MPSDefs.G2_TERMINATEDATE, ndate);
			}
		}

		LDAPData.put(MPSDefs.G2_MAILENABLED, CommonDefs.DEFAULT_TRUE);

		String php_enabled = null;
		String php_url = null;
		String php_homedir = null;
		if ((php_enabled = (String) inpParam.get(MPSDefs.WS_PHPENABLED)) != null) {
			if (php_enabled.equalsIgnoreCase("Y")) {
				LDAPData.put(MPSDefs.G2_PHPENABLED, CommonDefs.DEFAULT_TRUE);

				if ((php_url = (String) inpParam.get(MPSDefs.WS_PHPURL)) != null)
					LDAPData.put(MPSDefs.G2_PHPURL, php_url);
				else {
					hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_INVALID_DATA_NUM,
							"wsPhpUrl missing in the inpParam hashmap");
					return hmResult;
				}
				if ((php_homedir = (String) inpParam.get(MPSDefs.WS_PHPHOMEDIR)) != null)
					LDAPData.put(MPSDefs.G2_PHPHOMEDIR, php_homedir);
				else {
					hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_INVALID_DATA_NUM,
							"wsPhpHomeDir missing in the inpParam hashmap");
					return hmResult;
				}
			} else
				LDAPData.put(MPSDefs.G2_PHPENABLED, CommonDefs.DEFAULT_FALSE);
		}

		// Send Premium 800 Ind to G2
		String premium800Ind = (String) mpsData.get(MPSDefs.DB_PREMIUM_800_IND);
		if (premium800Ind != null) {
			if (premium800Ind.equalsIgnoreCase(MPSDefs.PREMIUM_800_IND_YES))
				LDAPData.put(MPSDefs.G2_TOLLFREEENABLED, CommonDefs.DEFAULT_TRUE);
			else
				LDAPData.put(MPSDefs.G2_TOLLFREEENABLED, CommonDefs.DEFAULT_FALSE);
		} else {
			LDAPData.put(MPSDefs.G2_TOLLFREEENABLED, CommonDefs.DEFAULT_FALSE);
		}
		return LDAPData;
	}

	/**
	 * 
	 * @param mpsData
	 * @param log
	 * @return HashMap
	 */
	private HashMap validateparent(HashMap mpsData, Logger log) {
		String sMethodName = ".validateparent.";
		HashMap hmResult = null;

		String sAppInfo = null;

		int p = 1;
		try {
			while (true) {
				String f = MPSDefs.BLOCKPARENT + "-" + p;

				p++;

				String blockname;
				blockname = PropertyManager.getProperty(CommonDefs.MOUPConfig, f);

				if(null != blockname)
					blockname = blockname.trim();

				if (null == blockname || blockname.isEmpty())
					break;

				String parent_name = (String) mpsData.get(MPSDefs.DB_PARENT_NAME);

				if (parent_name == null)
					continue;

				if (parent_name.compareToIgnoreCase(blockname) == 0) {
					sAppInfo = "validator: parent name in blockparent list: " + blockname;
					log.info(sClassName + sMethodName + "H18 : " + sAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_INVALID_DATA_NUM, sAppInfo);
					return hmResult;
				}
			}

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success");
		} catch (Exception excp) {
			sAppInfo = "Exception :" + excp.getMessage();
			hmResult = CommonErrorMap.makeExceptionMap(excp);
			String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
			log.info(sClassName + sMethodName + "H18e : " + sAppInfo);
			return hmResult;
		}
		return hmResult;
	}

	/**
	 * 
	 * @param accessHashMap
	 * @param mpsData
	 * @param LDAPData
	 * @param log
	 * @return HashMap
	 */
	private HashMap validateAccess(HashMap accessHashMap, HashMap mpsData, Logger log) {
		String sMethodName = ".validateAccess.";
		String stAppInfo = null;
		HashMap hmResult = null;
		HashMap LDAPData = CommonUtil.getHashMap();

		String stAccessName = (String) mpsData.get(MPSDefs.DB_ACCESS_NAME);

		String stSorName = null;
		if ((stSorName = (String) mpsData.get(MPSDefs.DB_SOR_NAME)) != null) {
			LDAPData.put(MPSDefs.G2_ASSOCIATEDDOMAIN, stSorName);
		} else {
			stAppInfo = "sor_id missing in the mpsData hashmap";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			return hmResult;
		}
		String sst = null;

		// use service_status to check service status
		if (((sst = (String) accessHashMap.get(MPSDefs.SERVICE_STATUS)) != null)) {
			LDAPData.put(MPSDefs.G2_ACCESSENABLED, CommonDefs.DEFAULT_TRUE);
			LDAPData.put(MPSDefs.G2_CLASSOFSERVICE, stAccessName);
			// add service_status to LDAPData
			LDAPData.put(MPSDefs.G2_ACCOUNTSTATUS, sst);

		} else {
			stAppInfo = "group_status or member_status missing in the mpsData hashmap";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			return hmResult;
		}

		if (stSorName != null && stSorName.equals(MPSDefs.SOR_BLS)) {
			String stNetworkProfileNameAccessService = null;
			String stNetworkProfileNameDialService = null;
			if (stAccessName.equalsIgnoreCase(MPSDefs.DIAL_SERVICE)) {
				stNetworkProfileNameAccessService = (String) accessHashMap.get(MPSDefs.DB_NETWORK_PROFILE_NAME);
			} else if (stAccessName.equalsIgnoreCase(MPSDefs.DSL_SERVICE)
					|| stAccessName.equalsIgnoreCase(MPSDefs.ISDN_SERVICE)
					|| stAccessName.equalsIgnoreCase(MPSDefs.ISDN2_SERVICE)) {
				stNetworkProfileNameAccessService = (String) accessHashMap.get(MPSDefs.DB_NETWORK_PROFILE_NAME);
				HashMap servicesHash = (HashMap) mpsData.get(MPSDefs.SERVICES);
				HashMap dialServiceHash = (HashMap) servicesHash.get(MPSDefs.DIAL_SERVICE);
				stNetworkProfileNameDialService = (String) dialServiceHash.get(MPSDefs.DB_NETWORK_PROFILE_NAME);
			}
			if ((stAccessName.equalsIgnoreCase(MPSDefs.DIAL_SERVICE) && (stNetworkProfileNameAccessService == null))
					|| ((stAccessName.equalsIgnoreCase(MPSDefs.DSL_SERVICE)
							|| stAccessName.equalsIgnoreCase(MPSDefs.ISDN_SERVICE)
							|| stAccessName.equalsIgnoreCase(MPSDefs.ISDN2_SERVICE))
							&& (stNetworkProfileNameAccessService == null
									|| stNetworkProfileNameDialService == null))) {

				log.info(sClassName + sMethodName + "H18.0 : SOR is BLS, access_name is one of [A,1544,I,I2] "
						+ "and network_profile_name is missing in MPS db");

				stAppInfo = "SOR is BLS, access_name is one of [A,1544,I,I2] and network_profile_name is missing in MPS db";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			if (stNetworkProfileNameAccessService != null) {
				if (stAccessName.equalsIgnoreCase(MPSDefs.DIAL_SERVICE))
					LDAPData.put(MPSDefs.G2_DIALPROFILE, stNetworkProfileNameAccessService);
				else if (stNetworkProfileNameDialService != null) {
					if (stAccessName.equalsIgnoreCase(MPSDefs.DSL_SERVICE)) {
						LDAPData.put(MPSDefs.G2_DSLPROFILE, stNetworkProfileNameAccessService);
						LDAPData.put(MPSDefs.G2_DIALPROFILE, stNetworkProfileNameDialService);
					} else if (stAccessName.equalsIgnoreCase(MPSDefs.ISDN_SERVICE)) {
						LDAPData.put(MPSDefs.G2_ISDNPROFILE, stNetworkProfileNameAccessService);
						LDAPData.put(MPSDefs.G2_DIALPROFILE, stNetworkProfileNameDialService);
					} else if (stAccessName.equalsIgnoreCase(MPSDefs.ISDN2_SERVICE)) {
						LDAPData.put(MPSDefs.G2_ISDNPROFILE, stNetworkProfileNameAccessService);
						LDAPData.put(MPSDefs.G2_DIALPROFILE, stNetworkProfileNameDialService);
					}
				}
			}
			log.info(
					sClassName + sMethodName + "H18.1 : " + "Ldap Data from LdapValidator.validateAccess :" + LDAPData);
		}
		log.info(sClassName + sMethodName + "H19 : " + "End of validateAccess");
		return LDAPData;
	}

	/**
	 * 
	 * Validates and populates DSL data within LDAPData HashMap.
	 * 
	 * @throws MPSGenericException
	 * @throws Exception
	 */
	private HashMap validateDSL(HashMap accessHashMap, HashMap mpsData, Logger log) {
		String sMethodName = ".validateDSL.";
		String sAppStatusCode = null;
		HashMap hmResult = null;
		HashMap LDAPData = CommonUtil.getHashMap();

		hmResult = validateAccess(accessHashMap, mpsData, log);

		sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

		if (null != sAppStatusCode && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
			log.info(sClassName + sMethodName + "H588d : " + "HashMap Returned from validateAccess() : " + hmResult);
			return hmResult;
		}

		LDAPData.putAll(hmResult);

		hmResult = populateAndValidateDSLSpecificData(accessHashMap, mpsData, log);

		sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

		if (null != sAppStatusCode && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
			log.info(sClassName + sMethodName + "H1218d : "
					+ "HashMap Returned from populateAndValidateDSLSpecificData() : " + hmResult);
			return hmResult;
		}

		LDAPData.putAll(hmResult);

		hmResult = populateAndValidateStaticData(accessHashMap, mpsData, log);

		sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

		if (null != sAppStatusCode && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
			log.info(sClassName + sMethodName + "H638d : " + "HashMap Returned from populateAndValidateStaticData() : "
					+ hmResult);
			return hmResult;
		}

		LDAPData.putAll(hmResult);

		log.info(sClassName + sMethodName + "H20 : " + "End of validateDSL");
		return LDAPData;
	}

	/**
	 * 
	 * @param accessHashMap
	 * @param mpsData
	 * @param LDAPData
	 * @param log
	 * @return HashMap
	 */
	private HashMap validateHSIA(HashMap accessHashMap, HashMap mpsData, Logger log) {
		String sMethodName = ".validateHSIA.";
		String sAppStatusCode = null;
		HashMap hmResult = null;
		HashMap LDAPData = CommonUtil.getHashMap();

		hmResult = validateAccess(accessHashMap, mpsData, log);

		sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

		if (null != sAppStatusCode && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
			log.info(sClassName + sMethodName + "H837c : " + "HashMap Returned from validateAccess() : " + hmResult);
			return hmResult;
		}

		LDAPData.putAll(hmResult);

		String ban = (String) mpsData.get(MPSDefs.DB_BAN);
		if (ban != null && (ban = ban.trim()).length() > 0) {
			LDAPData.put(MPSDefs.G2_GIDNUMBER, ban);
		} else {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
					"ban missing in the mpsData hashmap");
			return hmResult;
		}
		log.info(sClassName + sMethodName + "H20.1 : " + "End of validateHSIA");
		return LDAPData;
	}

	/**
	 * 
	 * Validates and populates DSL specific data within LDAPData HashMap.
	 */
	private HashMap populateAndValidateDSLSpecificData(HashMap accessHashMap, HashMap mpsData,Logger log) {

		HashMap hmResult = null;
		HashMap LDAPData = CommonUtil.getHashMap();

		String stSorName = (String) mpsData.get(MPSDefs.DB_SOR_NAME);
		if (!stSorName.equalsIgnoreCase(MPSDefs.SOR_BLS)) {
			String circuit_id = null;
			if ((circuit_id = (String) accessHashMap.get(MPSDefs.DB_CIRCUIT_ID)) != null)
				LDAPData.put(MPSDefs.G2_CIRCUITID, circuit_id);
			else {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
						"circuit_id missing in the accessHashMap");
				return hmResult;
			}
			String virtual_path = null;
			if ((virtual_path = (String) accessHashMap.get(MPSDefs.DB_VIRTUAL_PATH)) != null)
				LDAPData.put(MPSDefs.G2_VIRTUALPATH, virtual_path);
			else {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
						"virtual_path missing in the accessHashMap");
				return hmResult;
			}
			String virtual_circuit = null;
			if ((virtual_circuit = (String) accessHashMap.get(MPSDefs.DB_VIRTUAL_CIRCUIT)) != null)
				LDAPData.put(MPSDefs.G2_VIRTUALCIRCUIT, virtual_circuit);
			else {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
						"virtual_circuit missing in the accessHashMap");
				return hmResult;
			}
			String unique_circuit = circuit_id + "." + virtual_path + "." + virtual_circuit;

			LDAPData.put(MPSDefs.G2_UNIQUECIRCUIT, unique_circuit);

			String protocol_type = null;
			if ((protocol_type = (String) accessHashMap.get(MPSDefs.DB_PROTOCOL_TYPE)) != null) {
				LDAPData.put(MPSDefs.G2_PROTOCOLTYPE, protocol_type);
			} else {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
						"protocol_type missing from the accessHashMap");
				return hmResult;
			}
		}
		// End of Feb NAP-II
		String incoming_burst = null;
		if ((incoming_burst = (String) accessHashMap.get(MPSDefs.DB_INCOMING_BURST)) != null)
			LDAPData.put(MPSDefs.G2_INCOMINGBURST, incoming_burst);
		else {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
					"incoming_burst missing from the accessHashMap");
			return hmResult;
		}
		String incoming_limit = null;
		if ((incoming_limit = (String) accessHashMap.get(MPSDefs.DB_INCOMING_LIMIT)) != null)
			LDAPData.put(MPSDefs.G2_INCOMINGLIMIT, incoming_limit);
		else {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
					"incoming_limit missing from the accessHashMap");
			return hmResult;
		}
		String outgoing_limit = null;
		if ((outgoing_limit = (String) accessHashMap.get(MPSDefs.DB_OUTGOING_LIMIT)) != null)
			LDAPData.put(MPSDefs.G2_OUTGOINGLIMIT, outgoing_limit);
		else {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
					"outgoing_limit missing from the accessHashMap");
			return hmResult;
		}
		String outgoing_burst = null;
		if ((outgoing_burst = (String) accessHashMap.get(MPSDefs.DB_OUTGOING_BURST)) != null)
			LDAPData.put(MPSDefs.G2_OUTGOINGBURST, outgoing_burst);
		else {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
					"outgoing_burst missing from the accessHashMap");
			return hmResult;
		}
		String stDslamType = (String) accessHashMap.get(MPSDefs.DB_DSLAM_TYPE);
		LDAPData.put(MPSDefs.DB_DSLAM_TYPE, stDslamType);

		// Send dns_err_optout_ind to G2
		String dnsErrOptOutInd = (String) accessHashMap.get(MPSDefs.DB_DNS_ERR_OPTOUT_IND);
		if (dnsErrOptOutInd != null && dnsErrOptOutInd.equalsIgnoreCase(MPSDefs.YES))
			LDAPData.put(MPSDefs.G2_DNS_OPTOUT, MPSDefs.YES);
		else
			LDAPData.put(MPSDefs.G2_DNS_OPTOUT, MPSDefs.NO);

		// Send "gdslnetworkpasswd" to G2
		String dsl_net_password = (String) mpsData.get(MPSDefs.DB_DSL_NET_PASSWORD);
		String dsl_net_pw_encr_type = (String) mpsData.get(MPSDefs.DB_DSL_NET_ENCR_TYPE);
		String sor_name = (String) mpsData.get(MPSDefs.DB_SOR_NAME);
		String parentChildInd = (String) mpsData.get(MPSDefs.DB_PARENT_CHILD_IND);

		if (parentChildInd != null && parentChildInd.equals(MPSDefs.MPS_PARENT) && (stDslamType == null
				|| (stDslamType != null && stDslamType.equalsIgnoreCase(MPSDefs.DEFAULT_DSLAM_TYPE)))) {

			if (dsl_net_password != null) {

				if (dsl_net_pw_encr_type == null) {
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
							"dsl_net_password is NOT null AND dsl_net_pw_encr_type is null");
					return hmResult;
				}
				if (dsl_net_pw_encr_type != null
						&& (dsl_net_pw_encr_type.equals("A") || dsl_net_pw_encr_type.equals("V"))) {

					// NetworkPasswordHelper npHelper = new NetworkPasswordHelper(); //TODO

					// Call ProofingEncryption_H.getDecryptedValues() to decrypt dsl_net_password
					HashMap npInputHs = new HashMap();
					npInputHs.put(MPSDefs.DB_DSL_NET_PASSWORD, dsl_net_password);
					npInputHs.put(MPSDefs.DB_DSL_NET_ENCR_TYPE, dsl_net_pw_encr_type);

					HashMap npOutputHs = oProofingEncryption_H.getDecryptedValues(npInputHs);

					String appStatusCode = (String) npOutputHs.get(CommonDefs.COMMON_APP_STATUS_CODE);

					if (appStatusCode == null || !appStatusCode.equalsIgnoreCase(CommonDefs.COMMON_SUCCESS)) {
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
								"ProofingEncryption_H.getDecryptedValues() returned error");
						return hmResult;
					}

					String clearPassword = (String) npOutputHs.get(MPSDefs.DB_DSL_NET_PASSWORD);
					String cryptedPassword = null;

					npInputHs.clear();
					npOutputHs.clear();

					npInputHs.put(MPSDefs.WS_CLEAR_TEXT, clearPassword);

					if (sor_name != null && sor_name.equals(MPSDefs.SOR_BLS)) {

						// Call Network Password Helper to apply DES3 encryption
						// to clearPassword
						npOutputHs = npHelper.generateDES3Password(npInputHs, log);

						appStatusCode = (String) npOutputHs.get(CommonDefs.COMMON_APP_STATUS_CODE);
						if (appStatusCode == null || !appStatusCode.equalsIgnoreCase(CommonDefs.COMMON_SUCCESS)) {
							hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
									"generateDES3Password() returned error");
							return hmResult;
						}

						cryptedPassword = (String) npOutputHs.get(MPSDefs.DB_DES3_PASSWORD);

					} else {

						// Call Network Password Helper to apply UNIX crypt to
						// clearPassword
						npInputHs.put(RILDefs.WS_SALT, clearPassword.substring(0,2));						
						npOutputHs = npHelper.generateCryptPassword(npInputHs, log);

						appStatusCode = (String) npOutputHs.get(CommonDefs.COMMON_APP_STATUS_CODE);
						if (appStatusCode == null || !appStatusCode.equalsIgnoreCase(CommonDefs.COMMON_SUCCESS)) {
							hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
									"generateCryptPassword() returned error");
							return hmResult;
						}

						cryptedPassword = (String) npOutputHs.get(MPSDefs.DB_ENC_PASSWORD);
						if (cryptedPassword != null)
							cryptedPassword = "{crypt}" + cryptedPassword;
					}

					LDAPData.put(MPSDefs.G2_DSL_NETWORK_PASSWORD, cryptedPassword);

				} else if (dsl_net_pw_encr_type != null
						&& (dsl_net_pw_encr_type.equals("C") || dsl_net_pw_encr_type.equals("D"))) {
					// Put gdslnetworkpasswd into LDAPData HashMap and use
					// dsl_net_password value
					if (sor_name != null && sor_name.equals(MPSDefs.SOR_BLS)) {
						LDAPData.put(MPSDefs.G2_DSL_NETWORK_PASSWORD, dsl_net_password);
					} else {
						dsl_net_password = "{crypt}" + dsl_net_password;
						LDAPData.put(MPSDefs.G2_DSL_NETWORK_PASSWORD, dsl_net_password);
					}

				} else {
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
							"invalid dsl_net_pw_encr_type value");
					return hmResult;
				}
			}
		}
		return LDAPData;
	}

	/**
	 * 
	 * Validates and populates ip_Address and ip_subnet within LDAPData HashMap.
	 * 
	 * @param log
	 * @param LDAPData
	 * @param mpsData
	 */
	private HashMap populateAndValidateStaticData(HashMap accessHashMap, HashMap mpsData, Logger log) {
		HashMap hmResult = null;
		HashMap LDAPData = CommonUtil.getHashMap();
		boolean ipFound = false;

		String ip_address = (String) accessHashMap.get(MPSDefs.DB_IP_ADDRESS);

		if ((ip_address != null) && (ip_address.length() > 0)) {
			ipFound = true;
			LDAPData.put(MPSDefs.G2_IPADDRESS, ip_address);
			LDAPData.put(MPSDefs.G2_ASSIGNSTATICIP, CommonDefs.DEFAULT_TRUE);
		} else {
			LDAPData.put(MPSDefs.G2_ASSIGNSTATICIP, CommonDefs.DEFAULT_FALSE);
		}

		String ip_subnet = (String) accessHashMap.get(MPSDefs.DB_IP_SUBNET);

		if ((ip_subnet != null) && (ip_subnet.length() > 0))
			LDAPData.put(MPSDefs.G2_IPSUBNET, ip_subnet);
		else if (ipFound) {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
					"ip_subnet missing from the accessHashMap");
			return hmResult;
		}
		return LDAPData;
	}

	/**
	 * 
	 * @param accessHashMap
	 * @param mpsData
	 * @param LDAPData
	 * @param log
	 * @return HashMap
	 */
	private HashMap validateISDN(HashMap accessHashMap, HashMap mpsData, Logger log) {
		String sMethodName = ".validateISDN.";
		String sAppStatusCode = null;
		HashMap hmResult = null;
		HashMap LDAPData = CommonUtil.getHashMap();

		hmResult = validateAccess(accessHashMap, mpsData, log);

		sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

		if (null != sAppStatusCode && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
			log.info(sClassName + sMethodName + "H233.1 : " + "HashMap Returned from validateAccess() : " + hmResult);
			return hmResult;
		}

		LDAPData.putAll(hmResult);

		hmResult = populateAndValidateStaticData(accessHashMap, mpsData, log);

		sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

		if (null != sAppStatusCode && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
			log.info(sClassName + sMethodName + "H265.1 : " + "HashMap Returned from populateAndValidateStaticData() : "
					+ hmResult);
			return hmResult;
		}

		LDAPData.putAll(hmResult);

		log.info(sClassName + sMethodName + "H21 : " + "End of validateISDN ");
		return LDAPData;
	}

	/**
	 * 
	 * @param hostingHashMap
	 * @param mpsData
	 * @param LDAPData
	 * @param log
	 * @return HashMap
	 */
	private HashMap validateSWH(HashMap hostingHashMap, HashMap mpsData, Logger log) {
		String sMethodName = ".validateSWH.";
		HashMap LDAPData = CommonUtil.getHashMap();

		if (hostingHashMap.get(MPSDefs.DB_MEMBER_STATUS_NAME).equals(MPSDefs.ENABLED))
			LDAPData.put(MPSDefs.G2_SERVICESWHENABLED, CommonDefs.DEFAULT_TRUE);
		else
			LDAPData.put(MPSDefs.G2_SERVICESWHENABLED, CommonDefs.DEFAULT_FALSE);

		String sSorName = null;
		if ((mpsData != null)) {
			sSorName = (String) mpsData.get(MPSDefs.DB_SOR_NAME);
			if ((sSorName != null) && (sSorName.trim().length() > 0)) {
				LDAPData.put(MPSDefs.G2_ASSOCIATEDDOMAIN, sSorName);
			}
			log.info(sClassName + sMethodName + "H21-0 : " + "LDAPData:" + LDAPData);
		}
		log.info(sClassName + sMethodName + "H22 : " + "End of validateSWH ");
		return LDAPData;
	}

	/**
	 * 
	 * @param wifi
	 * @param mpsData
	 * @param LDAPData
	 * @param log
	 * @return HashMap
	 */
	private HashMap validateWIFI(HashMap wifi, HashMap mpsData, Logger log) {
		String sMethodName = ".validateWIFI.";
		HashMap hmResult = null;
		HashMap LDAPData = CommonUtil.getHashMap();
		String wifiServiceType = (String) wifi.get(MPSDefs.DB_WIFI_SERVICE_TYPE);
		String roamingBlockInd = (String) wifi.get(MPSDefs.DB_ROAMING_BLOCK_IND);

		if (wifiServiceType != null)
			LDAPData.put(MPSDefs.G2_WIFISERVICE, wifiServiceType);
		else {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
					"wifi_service_type missing in the wifi HashMap");
			return hmResult;
		}
		if (roamingBlockInd != null) {
			if (roamingBlockInd.equalsIgnoreCase(MPSDefs.DB_ROAMING_BLOCK_IND_YES))
				LDAPData.put(MPSDefs.G2_WIFIBLOCKROAMING, CommonDefs.DEFAULT_TRUE);
			else
				LDAPData.put(MPSDefs.G2_WIFIBLOCKROAMING, CommonDefs.DEFAULT_FALSE);
		} else {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
					"roaming_block_ind missing in the wifi HashMap");
			return hmResult;
		}
		String memStatus = (String) wifi.get(MPSDefs.DB_MEMBER_STATUS_CODE);
		String grpStatus = (String) wifi.get(MPSDefs.DB_GROUP_STATUS_CODE);

		if ((memStatus != null) && (grpStatus != null)) {
			if (memStatus.equalsIgnoreCase(MPSDefs.DB_STATUS_ENABLED)
					&& grpStatus.equalsIgnoreCase(MPSDefs.DB_STATUS_ENABLED)) {
				LDAPData.put(MPSDefs.G2_WIFIENABLED, CommonDefs.DEFAULT_TRUE);
			} else
				LDAPData.put(MPSDefs.G2_WIFIENABLED, CommonDefs.DEFAULT_FALSE);
		}
		log.info(sClassName + sMethodName + "H23 : " + "End of validateWIFI ");
		return LDAPData;
	}
}
