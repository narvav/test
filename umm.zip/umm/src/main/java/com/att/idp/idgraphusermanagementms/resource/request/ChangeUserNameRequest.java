package com.att.idp.idgraphusermanagementms.resource.request;

import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class represents a request to change a user's name in the system.
 * It contains fields for various details such as oldUserName, newUserName, accessIdRTValidFlag, suppressNotification, agentId, idpTraceId, isExternalCall, and a map for unknownAttributes.
 * Each field has specific constraints such as not null and size limits.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 *
 * @author pb6583_ATT
 */
@Schema(name = "ChangeUserNameRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class ChangeUserNameRequest {

	private final String transactionName = "ChangeUserName";

	private String callingSystemId;

	@Schema(name = "oldUserName")
	@NotNull(message = "OldUserName is required field in input request.|ChangeUserName")
	@Size(min = 1, max = 80, message =  "OldUserName length is invalid|ChangeUserName")
	private String oldUserName;

	@Schema(name = "newUserName")
	@NotNull(message = "NewUserName is required field in input request.|ChangeUserName")
	@Size(min = 1, max = 80, message =  "NewUserName length is invalid|ChangeUserName")
	private String newUserName;

	@Schema(name = "accessIdRTValidFlag")
	@Size(min = 1, max = 1, message =  "accessIdRTValidFlag value can only be Y or N|ChangeUserName")
	private String accessIdRTValidFlag;

	@Schema(name = "suppressNotification")
	@Size(min = 1, max = 1, message =  "supressNotification value can only be Y or N|ChangeUserName")
	private String suppressNotification;

	@Schema(name = "agentId")
	private String agentId;

	@Schema(name = "idpTraceId")
	private String idpTraceId;

	@Schema(name = "isExternalCall")
	protected String isExternalCall;
	
	/**
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
	 * @return Map<String,Object> The map of unknown attributes.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();

	

}
