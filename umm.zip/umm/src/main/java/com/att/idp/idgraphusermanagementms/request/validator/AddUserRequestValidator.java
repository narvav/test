package com.att.idp.idgraphusermanagementms.request.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import jakarta.ws.rs.core.HttpHeaders;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphusermanagementms.resource.request.AddUserRequest;
import com.att.idp.idgraphusermanagementms.resource.response.AddUserResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;

/**
 * This class, AddUserRequestValidator, is responsible for validating the AddUserRequest.
 * It checks for the presence and validity of required fields in the request, and returns an AddUserResponse accordingly.
 * It is annotated with @Component, @Configuration, and @PropertySource to indicate that it's a Spring Bean, 
 * to allow it to access configuration properties, and to specify the location of the properties file respectively.
 *
 * The class contains several methods, including:
 * - addUserRequestValidator: the main method that orchestrates the validation process.
 * - addUserErrorResponse: a helper method that generates an error response.
 * - addUserRequestCSIValidator: a method that validates the Calling System ID (CSI) in the request.
 * - addUserRequestInputValidator: a method that validates the input fields in the request.
 * - addUserIsExternalCallCheck: a method that checks the 'isExternalCall' field in the request.
 * - addUserUpdateFlags: a method that checks the update flags in the request.
 * - addUserRequiredFieldCheck: a method that checks for the presence of required fields in the request.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class AddUserRequestValidator {
	private static final Logger logger = LoggerFactory.getLogger(AddUserRequestValidator.class);

	private String sClassName = "AddUserRequestValidator";

	@Value("${addUserCallingSystemIds}")
	private String propCallingSystemId;

	@Value("${addUserContactEmailRequiredCSIs}")
	private String propAddUserContactEmailCSIs;

	/**
	 * This method is responsible for validating the AddUserRequest.
	 * It takes HttpHeaders and AddUserRequest as parameters.
	 * HttpHeaders contains the request headers which may include additional information required for processing the request.
	 * AddUserRequest encapsulates the details of the user addition operation to be performed.
	 * 
	 * The method performs various checks and validations on the input parameters and returns an AddUserResponse object.
	 * The AddUserResponse object encapsulates the result of the user addition operation.
	 * 
	 * @param requestHeader The HttpHeaders containing the request headers.
	 * @param addUserRequest The AddUserRequest containing the details of the user addition operation.
	 * @return AddUserResponse The response of the user addition operation.
	 */
	public AddUserResponse addUserRequestValidator(HttpHeaders requestHeader, AddUserRequest addUserRequest) {

		AddUserResponse addUserResponse = null;

		String stAppInfo = null;
		String sMethodName = ".addUserRequestValidator.";
		String stIdpTraceId = null;
		String stXAttClientId = null;
		
		stIdpTraceId = CommonUtil.getTraceId(requestHeader);
		if (stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
			stAppInfo = "Missing or Invalid IdpTraceId";
			return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
			
		if (addUserRequest == null) {
			stAppInfo = "Input Request Parameter is NULL / Empty.";
			logger.info("{}{}AURV_102 :: {}", sClassName, sMethodName, stAppInfo);
			return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		
		addUserRequest.setIdpTraceId(stIdpTraceId);

		if (requestHeader.getHeaderString("X-ATT-ClientId") != null) {
			stXAttClientId = requestHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
			logger.info("{}{}AURV_101.2 : Setting callingSystemId: {}", sClassName, sMethodName,
					StringUtils.normalizeSpace(stXAttClientId));
			addUserRequest.setCallingSystemId(stXAttClientId);
		} else {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			logger.info("{}{}AURV_101.3 :: {}", sClassName, sMethodName, stAppInfo);
			return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		// checking Invalid attributes passed in Request
		Map<String, Object> allUnknownAttributes = new HashMap<>(addUserRequest.unknownAttributes);

		if (!allUnknownAttributes.isEmpty()) {
			stAppInfo = "Invalid Attributes passed in AddUserRequest : " + allUnknownAttributes;
			return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					addUserRequest.getIdpTraceId());
		}

		try {
			addUserResponse = addUserRequestInputValidator(addUserRequest);
			if (addUserResponse != null) {
				logger.info("{}{}AURV_103 Response from addUserRequestInputValidator : {}", sClassName, sMethodName,
						addUserResponse);
				return addUserResponse;
			} else {
				logger.debug("{}{}AURV_104 Success Response from addUserRequestInputValidator ", sClassName,
						sMethodName);
			}
			addUserResponse = addUserRequestCSIValidator(addUserRequest);
			if (addUserResponse != null) {
				logger.info("{}{}AURV_105 Response from addUserRequestCSIValidator : {}", sClassName, sMethodName,
						addUserResponse);
				return addUserResponse;
			} else {
				logger.debug("{}{}AURV_106 Success Response from addUserRequestCSIValidator ", sClassName, sMethodName);
			}
			stAppInfo = "Input Validation Successful";
			logger.info("{}{}AURV_107 : {}", sClassName, sMethodName, stAppInfo);

		} catch (Exception e) {
			stAppInfo = "Exception thrown in AddUserRequestValidator.addUserRequestValidator : " + e.getMessage();
			addUserResponse = addUserErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo, stIdpTraceId);
			logger.info("Exception in addUserRequestValidator: {}", stAppInfo);
		}

		return addUserResponse;
	}

	private AddUserResponse addUserErrorResponse(int appStatusCode, String stAppInfo, String stIdpTraceId) {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		return CommonUtilHelper.generateAddUserResponse(hmResponse);
	}

	private AddUserResponse addUserRequestCSIValidator(AddUserRequest addUserRequest) {
		String sMethodName = ".addUserRequestCSIValidator.";
		String sIsExternalCall = addUserRequest.getIsExternalCall();
		String stCallingSystemId = addUserRequest.getCallingSystemId();
		String stContactEmail = addUserRequest.getContactEmail();
		String stIdpTraceId = addUserRequest.getIdpTraceId();
		String stAppInfo = null;

		ArrayList alAddUserCallingSystemIds = null;
		ArrayList alAddUserContactEmailRequiredCSIs = null;

		// commented as dead code
//		if (propCallingSystemId == null || propCallingSystemId.isEmpty()) {
//			stAppInfo = "The value of addUserCallingSystemIds is not configured in property files";
//			logger.info("{}{}AURV_104.1 : {}", sClassName, sMethodName, stAppInfo);
//			return addUserErrorResponse(CErrorDefs.ERR_CONFIG_NUM, stAppInfo,
//					 stIdpTraceId );
//		}

		alAddUserCallingSystemIds = CommonUtil.parseToArray(propCallingSystemId, CommonDefs.VALUE_SEPARATOR_CHAR);

		logger.debug("{}{}AURV_104.2 :  Property addUserCallingSystemIds : {}", sClassName, sMethodName,
				alAddUserCallingSystemIds);

		if (alAddUserCallingSystemIds != null && !alAddUserCallingSystemIds.contains(stCallingSystemId)
				&& sIsExternalCall != null && CommonDefs.IND_Y.equals(sIsExternalCall)) {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		// commented as dead code
//		if (propAddUserContactEmailCSIs == null || propAddUserContactEmailCSIs.isEmpty()) {
//			stAppInfo = "The value of addUserContactEmailRequiredCSIs is not configured in property files";
//			return addUserErrorResponse(CErrorDefs.ERR_CONFIG_NUM, stAppInfo,
//					ErrorMessages.MS_OUD_AU_BE_11, stIdpTraceId);
//		}

		alAddUserContactEmailRequiredCSIs = CommonUtil.parseToArray(propAddUserContactEmailCSIs,
				CommonDefs.VALUE_SEPARATOR_CHAR);

		logger.debug("{}{}AURV_104.3 : Property addUserContactEmailRequiredCSIs : {}", sClassName, sMethodName,
				alAddUserContactEmailRequiredCSIs);

		if ((alAddUserContactEmailRequiredCSIs != null && alAddUserContactEmailRequiredCSIs.contains(stCallingSystemId))
				&& (stContactEmail == null || stContactEmail.isEmpty()) && sIsExternalCall != null
				&& CommonDefs.IND_Y.equals(sIsExternalCall)) {
			stAppInfo = "Contact email is mandatory for " + stCallingSystemId;
			return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		return null;
	}

	/**
	 * This method is part of the AddUserRequestValidator class.
	 * It is responsible for validating the AddUserRequest.
	 * The method takes an AddUserRequest as input.
	 * The AddUserRequest encapsulates the details of the user addition operation to be performed.
	 * The method performs various checks and validations on the input parameters and returns an AddUserResponse object.
	 * The AddUserResponse object encapsulates the result of the user addition operation.
	 * The method checks for the presence and validity of required fields in the request, and returns an AddUserResponse accordingly.
	 *
	 * @param addUserRequest The AddUserRequest containing the details of the user addition operation.
	 * @return AddUserResponse The response of the user addition operation.
	 */
	public AddUserResponse addUserRequestInputValidator(AddUserRequest addUserRequest) {
		Optional.ofNullable(addUserRequest.getCbrNumber())
				.ifPresent(x -> addUserRequest.setCbrNumber(x.trim()));
		Optional.ofNullable(addUserRequest.getCbrRTValidFlag())
				.ifPresent(x -> addUserRequest.setCbrRTValidFlag(x.trim().toUpperCase()));
		Optional.ofNullable(addUserRequest.getContactAddress())
				.ifPresent(x -> addUserRequest.setContactAddress(x.trim()));

		String stAppInfo = null;
		AddUserResponse addUserResponse = null;
		String stCallingSystemId = addUserRequest.getCallingSystemId();
		String stTransactionName = addUserRequest.getTransactionName();
		String stHandle = addUserRequest.getHandle();
		String stPasswordClear = addUserRequest.getPasswordClear();
		String stOnlineSecQues1 = addUserRequest.getOnline1SecurityQuestion();
		String stOnlineSecAns1 = addUserRequest.getOnline1SecurityAnswer();
		String stOnlineSecQues2 = addUserRequest.getOnline2SecurityQuestion();
		String stOnlineSecAns2 = addUserRequest.getOnline2SecurityAnswer();
		String stBrowerLang = addUserRequest.getBrowserLanguage();
		String stIdpTraceId = addUserRequest.getIdpTraceId();
		String firstName = addUserRequest.getFirstName();
		String lastName = addUserRequest.getLastName();
		String cbrNumber = addUserRequest.getCbrNumber();
		String cbrRTValidFlag = addUserRequest.getCbrRTValidFlag();

		addUserResponse = addUserIsExternalCallCheck(addUserRequest);
		if (addUserResponse != null) {
			return addUserResponse;
		}

//		Optional.ofNullable(stTransactionName).ifPresent(x -> addUserRequest.setTransactionName(x.trim()));

		Optional.ofNullable(stCallingSystemId)
				.ifPresent(x -> addUserRequest.setCallingSystemId(x.trim().toUpperCase()));

		Optional.ofNullable(stHandle).ifPresent(x -> addUserRequest.setHandle(x.trim().toLowerCase()));

		Optional.ofNullable(stPasswordClear).ifPresent(x -> addUserRequest.setPasswordClear(x.trim()));

		addUserResponse = addUserRequiredFieldCheck(addUserRequest);
		if (addUserResponse != null) {
			return addUserResponse;
		}

//		Optional.ofNullable(addUserRequest.getDomain())
//				.ifPresent(x -> addUserRequest.setDomain(x.trim().toLowerCase()));

		/*
		 * Optional.ofNullable(addUserRequest.getContactEmail()) .ifPresent(x ->
		 * addUserRequest.setContactEmail(x.trim().toLowerCase()));
		 */

		Optional.ofNullable(addUserRequest.getContactEmail())
				.ifPresent(x -> addUserRequest.setContactEmail(x.trim().toLowerCase()));

		Optional.ofNullable(stOnlineSecQues1).ifPresent(x -> addUserRequest.setOnline1SecurityQuestion(x.trim()));
		stOnlineSecQues1 = addUserRequest.getOnline1SecurityQuestion();

		Optional.ofNullable(stOnlineSecAns1)
				.ifPresent(x -> addUserRequest.setOnline1SecurityAnswer(x.trim().toLowerCase()));
		stOnlineSecAns1 = addUserRequest.getOnline1SecurityAnswer();

		if ((stOnlineSecQues1 == null && stOnlineSecAns1 != null)
				|| (stOnlineSecQues1 != null && stOnlineSecAns1 == null)) {
			stAppInfo = "Either of online1SecurityQuestion or online1SecurityAnswer are null or empty.";
			return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		Optional.ofNullable(stOnlineSecQues2).ifPresent(x -> addUserRequest.setOnline2SecurityQuestion(x.trim()));
		stOnlineSecQues2 = addUserRequest.getOnline2SecurityQuestion();

		Optional.ofNullable(stOnlineSecAns2)
				.ifPresent(x -> addUserRequest.setOnline2SecurityAnswer(x.trim().toLowerCase()));
		stOnlineSecAns2 = addUserRequest.getOnline2SecurityAnswer();

		if ((stOnlineSecQues2 == null && stOnlineSecAns2 != null)
				|| (stOnlineSecQues2 != null && stOnlineSecAns2 == null)) {
			stAppInfo = "Either of online2SecurityQuestion or online2SecurityAnswer are null or empty.";
			return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (stBrowerLang != null && !stBrowerLang.isEmpty()) {
			stBrowerLang = stBrowerLang.trim().toLowerCase();
			addUserRequest.setBrowserLanguage(stBrowerLang);
			if (!(stBrowerLang.equals("en") || stBrowerLang.equals("es"))) {
				stAppInfo = "browserLanguage is Invalid :: Should be one of [en, es]";
				return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
		}
		String sIsExternalCall = addUserRequest.getIsExternalCall();
		if (sIsExternalCall != null && !sIsExternalCall.isEmpty()
				&& (sIsExternalCall.equalsIgnoreCase(CommonDefs.IND_Y))) {

			if (StringUtils.isBlank(firstName) && StringUtils.isBlank(lastName)) {
				stAppInfo = "First Name and Last Name are required in input request";
				return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			} else if (StringUtils.isNotBlank(firstName) && StringUtils.isBlank(lastName)) {
				stAppInfo = "Last Name is required in input request";
				return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			} else if (StringUtils.isBlank(firstName) && StringUtils.isNotBlank(lastName)) {
				stAppInfo = "First Name is required in input request";
				return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
		} else if (sIsExternalCall.equalsIgnoreCase(CommonDefs.IND_N)) {
			Optional.ofNullable(addUserRequest.getFirstName()).ifPresent(x -> addUserRequest.setFirstName(x.trim()));
			Optional.ofNullable(addUserRequest.getLastName()).ifPresent(x -> addUserRequest.setLastName(x.trim()));
		}

		if (StringUtils.isNotEmpty(cbrRTValidFlag)) {
			if (!cbrRTValidFlag.equals("Y") && !cbrRTValidFlag.equals("N")) {
				stAppInfo = "cbrRTValidFlag must be 'Y' or 'N', if provided";
				return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
			if (StringUtils.isEmpty(cbrNumber)) {
				stAppInfo = "cbrNumber is mandatory when CBR RT Valid Flag is provided";
				return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
		}
		if (StringUtils.isNotEmpty(cbrNumber) && !cbrNumber.matches("\\d{10}")) {
			stAppInfo = "cbrNumber must be 10 digits if provided";
			return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		addUserResponse = addUserUpdateFlags(addUserRequest);
		return addUserResponse;
	}

	private AddUserResponse addUserIsExternalCallCheck(AddUserRequest addUserRequest) {
		AddUserResponse addUserResponse = null;
		String stAppInfo;
		String isExternalCall = addUserRequest.getIsExternalCall();
		String stIdpTraceId = addUserRequest.getIdpTraceId();

		if ((isExternalCall != null && !isExternalCall.isEmpty())) {
			if (!(isExternalCall.equalsIgnoreCase(CommonDefs.IND_Y)
					|| isExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
				stAppInfo = "isExternalCall must be one of Y or N";
				return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			} else {
				addUserRequest.setIsExternalCall(isExternalCall.trim().toUpperCase());
			}
		} else {
			addUserRequest.setIsExternalCall(CommonDefs.IND_Y);
		}
		return addUserResponse;
	}

	private AddUserResponse addUserUpdateFlags(AddUserRequest addUserRequest) {
		AddUserResponse addUserResponse = null;
		String sByPassCheckIdAvailability = addUserRequest.getByPassCheckIdAvailability();
		String stAccessIdRTValidFlag = addUserRequest.getAccessIdRTValidFlag();
		String stContactEmailRTValidFlag = addUserRequest.getContactEmailRTValidFlag();
		String stAppInfo = null;
		String stIdpTraceId = addUserRequest.getIdpTraceId();
		String stIsAccessIdAutoGen = addUserRequest.getIsAccessIdAutoGen();
		String stIsTempPassword = addUserRequest.getIsTempPassword();

		if (sByPassCheckIdAvailability != null && !sByPassCheckIdAvailability.isEmpty()) {
			sByPassCheckIdAvailability = sByPassCheckIdAvailability.trim().toUpperCase();
			if (!(sByPassCheckIdAvailability.equals("Y") || sByPassCheckIdAvailability.equals("N"))) {
				stAppInfo = "byPassCheckIdAvailability must be one of Y or N";
				return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
			addUserRequest.setByPassCheckIdAvailability(sByPassCheckIdAvailability);
		}

		if (stAccessIdRTValidFlag != null) {
			stAccessIdRTValidFlag = stAccessIdRTValidFlag.trim().toUpperCase();
			if (!(stAccessIdRTValidFlag.equals("Y") || stAccessIdRTValidFlag.equals("N"))) {
				stAppInfo = "accessIdRTValidFlag value can only be Y or N";
				return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
			addUserRequest.setAccessIdRTValidFlag(stAccessIdRTValidFlag);
		}
		if (stContactEmailRTValidFlag != null) {
			stContactEmailRTValidFlag = stContactEmailRTValidFlag.trim().toUpperCase();
			if (!(stContactEmailRTValidFlag.equals("Y") || stContactEmailRTValidFlag.equals("N"))) {
				stAppInfo = "contactEmailRTValidFlag value can only be Y or N";
				return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
			addUserRequest.setContactEmailRTValidFlag(stContactEmailRTValidFlag);
		}

		if (stIsAccessIdAutoGen != null && !stIsAccessIdAutoGen.isEmpty()) {
			stIsAccessIdAutoGen = stIsAccessIdAutoGen.trim().toUpperCase();
			if (!(stIsAccessIdAutoGen.equals("Y") || stIsAccessIdAutoGen.equals("N"))) {
				stAppInfo = "IsAccessIdAutoGen must be one of Y or N";
				return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
			addUserRequest.setIsAccessIdAutoGen(stIsAccessIdAutoGen);
		}

		if (stIsTempPassword != null && !stIsTempPassword.isEmpty()) {
			stIsTempPassword = stIsTempPassword.trim().toUpperCase();
			if (!(stIsTempPassword.equals("Y") || stIsTempPassword.equals("N"))) {
				stAppInfo = "IsTempPassword must be one of Y or N";
				return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
			addUserRequest.setIsTempPassword(stIsTempPassword);
		}

		return addUserResponse;
	}

	private AddUserResponse addUserRequiredFieldCheck(AddUserRequest addUserRequest) {
		String stAppInfo = null;
		AddUserResponse addUserResponse = null;
		Map<String, Object> hmResult = CommonUtil.getHashMap();
		String stCallingSystemId = addUserRequest.getCallingSystemId();
		String stTransactionName = addUserRequest.getTransactionName();
		String stHandle = addUserRequest.getHandle();
		String stPasswordClear = addUserRequest.getPasswordClear();
		String stIdpTraceId = addUserRequest.getIdpTraceId();

		if ((stTransactionName == null || stTransactionName.trim().isEmpty())
				|| (stCallingSystemId == null || stCallingSystemId.trim().isEmpty())
				|| (stHandle == null || stHandle.trim().isEmpty())
				|| (stPasswordClear == null || stPasswordClear.trim().isEmpty())) {
			stAppInfo = "Required field(s) missing";

			return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		if (!"AddUser".equals(addUserRequest.getTransactionName())) {
			stAppInfo = "Transaction Not Allowed :: TransactionName Should be AddUser";
			return addUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);

		}
		return addUserResponse;
	}

}
