package com.att.idp.idgraphusermanagementms.resource.request;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import jakarta.validation.Valid;

import static org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString;
import static org.apache.commons.lang3.builder.ToStringStyle.JSON_STYLE;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * This class is part of the com.att.idp.idgraphusermanagementms.resource.request package.
 *
 * The DeliveryMethods class implements the Serializable interface, allowing instances of this class to be converted into a byte stream.
 *
 * The class is used to represent a DeliveryMethods object, which contains several fields related to different delivery methods.
 * These fields include sms, email, letter, and ao.
 *
 * Each field is annotated with @Valid, indicating that the nested constraints on the associated object should be evaluated.
 *
 * The class provides a no-argument constructor, as well as getter and setter methods for each field.
 * It also overrides the toString method, providing a custom string representation of the object using reflection.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DeliveryMethods implements Serializable{
	@Valid
	private String deliveryMethodType;

	@Valid
	protected Sms sms;

	@Valid
	protected Email email;

	@Valid
	protected Letter letter;

	@Valid
	protected Ao ao;
	
	 /**
     * This field represents a map of unknown attributes.
     *
     * The unknownAttributes map is used to store any additional attributes that are not part of the attributeName and attributeValue fields.
     * It is initialized as a new HashMap.
     *
     * The field is annotated with @JsonAnySetter and @JsonAnyGetter, allowing it to be included in JSON serialization and deserialization.
     */
    @JsonAnySetter
    @JsonAnyGetter
    public Map<String,Object> unknownAttributes = new HashMap<>();

}