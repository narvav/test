package com.att.idp.idgraphusermanagementms.helper;

import com.att.idp.core.exception.ServiceException;

import com.att.idp.idgraph.db.oracle.helper.QueryMemberIdInfoDbHelper;
import com.att.idp.idgraph.db.oracle.model.EmailAlias;
import com.att.idp.idgraphusermanagementms.message.ErrorMessages;
import com.att.idp.idgraphusermanagementms.resource.response.MemberIdResponse;
import com.att.idp.idgraphusermanagementms.resource.response.MemberDetails;
import com.att.mpsys.common.helpers.FeatureManagerHelper;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.SSCommonDefs;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.att.idp.idgraph.db.oracle.helper.QueryMemberIdInfoDbHelper.DB_CBR;
import static com.att.idp.idgraph.db.oracle.helper.QueryMemberIdInfoDbHelper.PARENT_CHILD_IND_BOTH;


@Component
@RequiredArgsConstructor
public class QueryMemberIdHelper {

    public static final Logger logger = LoggerFactory.getLogger(QueryMemberIdHelper.class);
    private static final String QUERY_MEMBER_ID_ATTR_ENABLED_FEATURE_FLAG = "svc-idgraph-query-memberid-new-attr-enabled";

    private final QueryMemberIdInfoDbHelper queryMemberIdInfoDbHelper;
    private final FeatureManagerHelper featureManager;

    public static final String PARENT_IND = "P";
    public static final String CHILD_IND = "C";

    private static final String CLASS_NAME = "MemberIdHelper";

    /**
     * This method retrieves the MemberIdResponse based on the provided memberId, domain, guid and secMemberIds.
     *
     * @param smemberId      The member ID to be processed.
     * @param domain         The domain associated with the member ID.
     * @param guid           The GUID for the request.
     * @param sSecMemberIds  Indicates if secondary member IDs are requested.
     * @return MemberIdResponse containing member details and status.
     * @throws Exception if any error occurs during processing.
     */
    public MemberIdResponse queryMemberIdResponse(String smemberId, String domain, String guid, String sSecMemberIds, String ban) {

        MemberIdResponse response = new MemberIdResponse();

        List<Map<String, Object>> allAccounts = null;
        Map<String, List<Map<String, Object>>> groupedMemberNums = null;
        Set<String> allMemberNumsSet = null;
        Map<String, List<EmailAlias>> emailAliasMap = null;
        String stAppInfo = null;
        String sMethodName = ".getMemberIdResponse.";
        String parentChildInd = null;
        String memberNum = null;
        String groupNum = null;

        logger.info("{} {} - Start: smemberId={}, domain={}, guid={}, sSecMemberIds={}", CLASS_NAME, sMethodName, smemberId, domain, guid, sSecMemberIds);

        try {
            Map<String, Object> hmDbMemberInfo = queryMemberIdInfoDbHelper.queryMemberIdInfo(smemberId, domain, guid, ban);

            if (hmDbMemberInfo == null) {
                stAppInfo = "No Record found for the given MemberId: " + smemberId;
                logger.info("{} {}QMIDR_01 : {}", CLASS_NAME, sMethodName, stAppInfo);
                throw new ServiceException(ErrorMessages.MS_MPSYS_BE_121, stAppInfo);
            }
            parentChildInd = (String) hmDbMemberInfo.get(MPSDefs.DB_PARENT_CHILD_IND);
            memberNum = (String) hmDbMemberInfo.get(MPSDefs.DB_MEMBER_NUM);
            groupNum = (String) hmDbMemberInfo.get(MPSDefs.DB_GROUP_NUM);

            validateMemberInfo(parentChildInd, memberNum, sSecMemberIds, sMethodName);

            if (groupNum != null) {
                // Fetch all accounts for this groupNum once
                long start = System.currentTimeMillis();
                if (PARENT_IND.equalsIgnoreCase(parentChildInd) && CommonDefs.IND_N.equals(sSecMemberIds)) {
                    allAccounts = queryMemberIdInfoDbHelper.queryMemberServiceInfo(groupNum, PARENT_IND);
                } else {
                    allAccounts = queryMemberIdInfoDbHelper.queryMemberServiceInfo(groupNum, PARENT_CHILD_IND_BOTH);
                }
                long end = System.currentTimeMillis();

                logger.debug("{} {} QMIDR_04- DB record fetched: {}", CLASS_NAME, sMethodName, (end - start));
                // Group accounts by memberNum
                groupedMemberNums = getGroupedMemberNums(allAccounts);
                // Prepare email alias maps
                allMemberNumsSet = groupedMemberNums.keySet();
                emailAliasMap = getEmailAliasMap(allMemberNumsSet);
                final Map<String, List<EmailAlias>> tempEmailAliasMap = emailAliasMap != null ? emailAliasMap : Collections.emptyMap();

                if (parentChildInd != null && PARENT_IND.equalsIgnoreCase(parentChildInd) && CommonDefs.IND_Y.equals(sSecMemberIds)) {
                    logger.info("{} {}QMIDR_05 - Started processing for parent/child accounts when sSecMemberIds is Y", CLASS_NAME, sMethodName);
                    // For parent accounts
                    List<Map<String, Object>> parentMemberId = groupedMemberNums.get(memberNum);
                    if (parentMemberId != null && !parentMemberId.isEmpty()) {
                        MemberDetails memberId = buildMemberDetails(parentMemberId, parentMemberId.get(0), tempEmailAliasMap);
                        response.setMemberId(memberId);
                    }
                    // For child accounts
                    List<MemberDetails> secondaryMemberIds = new ArrayList<>();
                    for (Map.Entry<String, List<Map<String, Object>>> eachMemberNum : groupedMemberNums.entrySet()) {
                        List<Map<String, Object>> memberNumDetails = eachMemberNum.getValue();
                        if (memberNumDetails != null && !memberNumDetails.isEmpty()) {
                            if (memberNumDetails.get(0) != null &&
                                    CHILD_IND.equalsIgnoreCase((String) memberNumDetails.get(0).get(MPSDefs.DB_PARENT_CHILD_IND))) {
                                Map<String, Object> memberNumDetailsMap = memberNumDetails.get(0);
                                MemberDetails secMemberId = buildMemberDetails(memberNumDetails, memberNumDetailsMap, tempEmailAliasMap);
                                secondaryMemberIds.add(secMemberId);
                            }
                        }
                    }
                    response.setSecMemberIds(secondaryMemberIds);

                } else if (parentChildInd != null && CommonDefs.IND_N.equals(sSecMemberIds)) {
                    logger.info("{} {}QMIDR_06 - Started processing for parent/child accounts when sSecMemberIds is N", CLASS_NAME, sMethodName);
                    if (CHILD_IND.equalsIgnoreCase(parentChildInd)) {
                        // Find parent memberNum
                        String parentMemberNum = null;
                        for (Map.Entry<String, List<Map<String, Object>>> eachMemberNum : groupedMemberNums.entrySet()) {
                            List<Map<String, Object>> memberNumDetails = eachMemberNum.getValue();
                            if (memberNumDetails != null && !memberNumDetails.isEmpty()) {
                                if (memberNumDetails.get(0) != null &&
                                        PARENT_IND.equalsIgnoreCase((String) memberNumDetails.get(0).get(MPSDefs.DB_PARENT_CHILD_IND))) {
                                    parentMemberNum = eachMemberNum.getKey();
                                    break;
                                }
                            }
                        }
                        if (StringUtils.isBlank(parentMemberNum)) {
                            throw new ServiceException(ErrorMessages.MS_MPSYS_BE_100, "Cannot find the Parent MemberId for the given subAccount");
                        }

                        List<Map<String, Object>> memberIds = groupedMemberNums.get(parentMemberNum);
                        if (memberIds != null && !memberIds.isEmpty()) {
                            Map<String, Object> memberNumDetails = memberIds.get(0);
                            MemberDetails memberId = buildMemberDetails(memberIds, memberNumDetails, tempEmailAliasMap);
                            response.setMemberId(memberId);
                        }
                    }
                    List<Map<String, Object>> memberNumGroup = groupedMemberNums.get(memberNum);
                    MemberDetails memberId = buildMemberDetails(memberNumGroup, memberNumGroup.get(0), tempEmailAliasMap);
                    if(PARENT_IND.equalsIgnoreCase(parentChildInd)) {
                        response.setMemberId(memberId);
                    } else {
                        response.setSecMemberIds(List.of(memberId));
                    }
                }
            } else {
                stAppInfo = "Cannot find the GroupNum value for the given MemberId";
                logger.info("{} {}QMIDR_07 : {}", CLASS_NAME, sMethodName, stAppInfo);
                throw new ServiceException(ErrorMessages.MS_MPSYS_BE_100, stAppInfo);
            }
        } catch (ServiceException ex) {
            stAppInfo = "Exception occurred while retrieving/processing the accounts: :" + ex.getMessage();
            logger.error("{} {}QMIDR_08 : Exception = {}", CLASS_NAME, sMethodName, stAppInfo);
            throw ex;
        } catch (Exception ex) {
            stAppInfo = "Exception occurred while retrieving/processing the accounts:" + ex.getMessage();
            logger.error("{} {}QMIDR_09 : Exception = {}", CLASS_NAME, sMethodName, ex);
            throw new ServiceException(ErrorMessages.MS_MPSYS_BE_602, stAppInfo);
        }

        logger.info("{} {} QMIDR_10- End: response={}", CLASS_NAME, sMethodName, response);
        return response;
    }
    /**
     * Determines the enabled status for a list of member account records.
     * Returns ENABLED if any account is enabled.
     * Returns SUSPENDED if all accounts are either suspended or terminated and at least one has a status.
     * Returns ENABLED if no status is found or the list is empty/null.
     *
     * @param memberData List of member account records from the database.
     * @return The overall member status: ENABLED or SUSPENDED.
     */
    private String getMemberStatus(List<Map<String, Object>> memberData) {
        if (memberData == null || memberData.isEmpty()) {
            return MPSDefs.TERMINATED;
        }
        boolean anyEnabled = false;
        boolean anySuspended = false;
        boolean allTerminated = true;
        for (Map<String, Object> statusData : memberData) {
            String status = (String) statusData.get(MPSDefs.DB_MEMBER_STATUS);
            if (MPSDefs.ENABLED.equalsIgnoreCase(status)) {
                anyEnabled = true;
                break;
            }
            if (MPSDefs.SUSPENDED.equalsIgnoreCase(status)) {
                anySuspended = true;
                allTerminated = false;
            } else if (!MPSDefs.TERMINATED.equalsIgnoreCase(status)) {
                allTerminated = false;
            }
        }
        if (anyEnabled) {
            return MPSDefs.ENABLED;
        } else if (allTerminated) {
            return MPSDefs.TERMINATED;
        } else if (anySuspended) {
            return MPSDefs.SUSPENDED;
        }else {
            return MPSDefs.UNKNOWN;
        }
    }

    /**
     * Maps a database record to a MemberId object, populating all relevant fields.
     *
     * @param hmMemberInfo The database record containing member information.
     * @param tempEmailAliasMap  Map of member numbers to their email aliases.
     * @return MemberId object populated with data from the record and email aliases.
     */
    private MemberDetails mapToMemberDetails(Map<String, Object> hmMemberInfo, Map<String, List<EmailAlias>> tempEmailAliasMap) {
        MemberDetails memberId = new MemberDetails();
        memberId.setMemberNum((String) hmMemberInfo.get(MPSDefs.DB_MEMBER_NUM));
        memberId.setMemberName((String) hmMemberInfo.get(MPSDefs.DB_MEMBER_NAME));
        memberId.setDomain((String) hmMemberInfo.get(MPSDefs.DB_DOMAIN_NAME));
        memberId.setParentChildInd((String) hmMemberInfo.get(MPSDefs.DB_PARENT_CHILD_IND));
        memberId.setAccessName((String) hmMemberInfo.get(MPSDefs.DB_ACCESS_NAME));
        memberId.setMigrationInd((String) hmMemberInfo.get(MPSDefs.DB_MIGRATION_IND));
        memberId.setFirstName((String) hmMemberInfo.get(CommonDefs.DB_FIRSTNAME));
        memberId.setLastName((String) hmMemberInfo.get(CommonDefs.DB_LASTNAME));
        memberId.setNickName((String) hmMemberInfo.get(MPSDefs.DB_NICKNAME));
        memberId.setZip((String) hmMemberInfo.get(MPSDefs.DB_PROOFING_ZIP));
        memberId.setMemberId(memberId.getMemberName() + "@" + memberId.getDomain());
        memberId.setMemberStatus((String) hmMemberInfo.get(MPSDefs.DB_MEMBER_STATUS));
        memberId.setContactEmail((String) hmMemberInfo.get(MPSDefs.DB_CONTACT_EMAIL));
        memberId.setEmailAlias(tempEmailAliasMap.getOrDefault(memberId.getMemberNum(), List.of()));
        memberId.setCbr((String) hmMemberInfo.get(DB_CBR));
        return memberId;
    }

/**
 * Retrieves a map of member numbers to their associated email aliases.
 *
 * @param memberNums Set of member numbers to fetch email aliases for.
 * @return Map where the key is the member number and the value is a list of EmailAlias objects.
 */
    private Map<String, List<EmailAlias>> getEmailAliasMap(Set<String> memberNums) {
        return queryMemberIdInfoDbHelper.queryEmailAliases(memberNums);
    }
    /**
     * Groups the provided account records by their member number.
     *
     * @param accounts List of account records to group.
     * @return Map where the key is the member number and the value is a list of account records for that member.
     */
    private Map<String, List<Map<String, Object>>> getGroupedMemberNums(List<Map<String, Object>> accounts) {
        return queryMemberIdInfoDbHelper.groupAccountsByMemberNum(accounts);
    }

    /**
     * Builds a MemberDetails object for the given member.
     * Calculates the member status from the provided list of member records,
     * updates the database info map with the status, and maps all relevant fields.
     *
     * @param memberNum List of member records for the member.
     * @param hmDbMemberInfo Database info map for the member.
     * @param tempEmailAliasMap Map of member numbers to their email aliases.
     * @return MemberDetails object populated with member info, email aliases, and services.
     */
    private MemberDetails buildMemberDetails(List<Map<String, Object>> memberNum,Map<String, Object> hmDbMemberInfo, Map<String, List<EmailAlias>> tempEmailAliasMap) {
        String memberStatus = getMemberStatus(memberNum);
        hmDbMemberInfo.put(MPSDefs.DB_MEMBER_STATUS, memberStatus);

        MemberDetails memberDetails = mapToMemberDetails(hmDbMemberInfo, tempEmailAliasMap);
        boolean queryMemberIdAttrEnabled = featureManager.isEnabled(QUERY_MEMBER_ID_ATTR_ENABLED_FEATURE_FLAG);
        if(queryMemberIdAttrEnabled) {
            memberDetails.setYRegCompleteInd((String) hmDbMemberInfo.get(MPSDefs.DB_YREG_COMPLETE_IND));
            memberDetails.setCity((String) hmDbMemberInfo.get(MPSDefs.DB_CITY));
            memberDetails.setGender((String) hmDbMemberInfo.get(MPSDefs.DB_GENDER));
            memberDetails.setLanguage((String) hmDbMemberInfo.get(MPSDefs.DB_LANGUAGE));
            memberDetails.setFullName((String) hmDbMemberInfo.get(MPSDefs.DB_FULLNAME));
            memberDetails.setSor((String) hmDbMemberInfo.get(CommonDefs.SYSTEM_OF_RECORD));
            memberDetails.setState((String) hmDbMemberInfo.get(MPSDefs.DB_STATE));
            memberDetails.setStreetAddress((String) hmDbMemberInfo.get(SSCommonDefs.STREET_ADDRESS));
            memberDetails.setBizRes((String) hmDbMemberInfo.get(CommonDefs.BUS_RES_IND));
            memberDetails.setIsLegacy((String) hmDbMemberInfo.get(CommonDefs.IS_LEGACY));
            if (PARENT_IND.equalsIgnoreCase(memberDetails.getParentChildInd())) {
                memberDetails.setServices(extractServices(memberNum));
            }
        }
        return memberDetails;
    }

    /**
     * Extracts service information from member records.
     * Filters and returns only the service-related fields (service_type, service_status, portal_provider, etc.)
     *
     * @param memberRecords List of member records containing service information.
     * @return List of maps containing service details.
     */
    private List<Map<String, Object>> extractServices(List<Map<String, Object>> memberRecords) {
        if (memberRecords == null || memberRecords.isEmpty()) {
            return Collections.emptyList();
        }

        return memberRecords.stream()
                .filter(record -> record != null && !record.isEmpty())
                .map(record -> {
                    Map<String, Object> service = new java.util.HashMap<>();
                    String serviceName = (String) record.get(MPSDefs.DB_SERVICE_NAME);
                    if (StringUtils.isNotBlank(serviceName)) {
                        service.put(CommonDefs.SERVICE_NAME, serviceName);
                    }
                    String serviceStatus = (String) record.get(MPSDefs.DB_MEMBER_STATUS);
                    if (StringUtils.isNotBlank(serviceStatus)) {
                        service.put(CommonDefs.SERVICE_STATUS, serviceStatus);
                    }
                    String portalProvider = (String) record.get(MPSDefs.DB_PORTAL_PROVIDER);
                    if (StringUtils.isNotBlank(serviceName)
                            && MPSDefs.PORTAL_SERVICE.equalsIgnoreCase(serviceName)
                            && StringUtils.isNotBlank(portalProvider)) {
                        service.put(CommonDefs.PORTAL_PROVIDER, portalProvider);
                    }
                    return service;
                })
                .filter(service -> !service.isEmpty())
                .toList();
    }

    /**
     * Validates the member information for processing.
     * Throws ServiceException if memberNum or parentChildInd is blank,
     * or if a child member is incorrectly requested as a parent with secondary member IDs.
     *
     * @param parentChildInd Indicates if the member is a parent or child.
     * @param memberNum      The member number to validate.
     * @param sSecMemberIds  Secondary member IDs indicator.
     * @param sMethodName    Method name for logging.
     * @throws ServiceException if validation fails.
     */
    private void validateMemberInfo(String parentChildInd, String memberNum, String sSecMemberIds, String sMethodName) throws ServiceException {

        if (StringUtils.isBlank(memberNum) || StringUtils.isBlank(parentChildInd)) {
            String stAppInfo = "Cannot find MemberNum or ParentChildInd for the given MemberId";
            logger.info("{} {}QMIDR_02 : {}", CLASS_NAME, sMethodName, stAppInfo);
            throw new ServiceException(ErrorMessages.MS_MPSYS_BE_100, stAppInfo);
        }

        if (CHILD_IND.equalsIgnoreCase(parentChildInd) && CommonDefs.IND_Y.equals(sSecMemberIds)) {
            String stAppInfo = "Given MemberId is not a Parent MemberId";
            logger.info("{} {}QMIDR_03 : {}", CLASS_NAME, sMethodName, stAppInfo);
            throw new ServiceException(ErrorMessages.MS_MPSYS_BE_100, stAppInfo);
        }
    }
}