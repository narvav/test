package com.att.idp.idgraphusermanagementms.helper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.mpsys.common.utils.PropertyManager;
import com.att.idp.idgraphusermanagementms.db.helper.AddServiceDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.DBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.DeleteMemberDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.GetMemberServicesDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.MemberDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.MemberServiceAttributeDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.MergeYahooIDDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.RolesDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.UserMergeDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.UpdateAssociationDBHelper;
import com.att.idp.idgraphusermanagementms.helper.voltage.ProofingEncryptionHelper;
import com.att.idp.idgraphusermanagementms.queue.message.helpers.PublishMqAehHelper;
import com.att.idp.idgraphusermanagementms.queue.message.sender.JMSQueueSender;
import com.att.mpsys.common.helpers.FeatureManagerHelper;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * Helper class responsible for orchestrating the merge of two user access IDs (SLIDs).
 *
 * <p>A "merge" transfers all services and accounts from a <b>source SLID (fromSLID)</b> to a
 * <b>target SLID (toSLID)</b>, then deletes the source SLID. The operation is performed in
 * a sequential, step-by-step pipeline inside {@link #mergeUserAccessId(Map)}.</p>
 *
 * <h3>High-Level Merge Flow (21 steps)</h3>
 * <ol>
 *   <li>Initialize all instance-level state via {@link #initialize()}.</li>
 *   <li>Load the service-type reference data from {@code DBHelper.getServices()}.</li>
 *   <li>Retrieve full SLID profile for fromSLID via {@link #getSLIDInfoResponse(String)}.</li>
 *   <li>Check fraud lock on fromSLID via {@code checkFraudLock}.</li>
 *   <li>Retrieve full SLID profile for toSLID.</li>
 *   <li>Check fraud lock on toSLID.</li>
 *   <li>Enrich SLID info maps with services, wireline, and linked-user data for splitting.</li>
 *   <li>Reject if fromSLID is a FirstNet (FN) access ID.</li>
 *   <li>Reject if fromSLID has {@code MERGEABLE_IND = 'N'}.</li>
 *   <li>Split fromSLID services into type-specific lists (ECOMM, MOBILITY, TITAN, MOSUB, DTV, DYNAMIC)
 *       via {@link #fromSLIDSplitServices(Map)}.</li>
 *   <li>Split toSLID services via {@link #toSLIDSplitServices(Map)}, including a max-services-limit check.</li>
 *   <li>Unlink linked internet accounts from fromSLID and re-link them to toSLID
 *       via {@link #unlinkAndLinkInternetAccount(HashMap, HashMap, Map)}.</li>
 *   <li>Check if toSLID already has a default account and/or CPNI-impacted account
 *       via {@link #checkDefaultAccountToSlid()}.</li>
 *   <li>Process dynamic (configurable) services via {@link #processDynamicServices(ArrayList, ArrayList)}.</li>
 *   <li>Build the data structures for account insertion via {@link #prepareAccountsHashMap()}.
 *       This calls {@link #processAccounts(ArrayList, ArrayList)} per service type (ECOMM, MOBILITY, DTV, TITAN)
 *       which in turn calls {@link #processRoles(ArrayList, ArrayList)} when a matching account exists on both SLIDs.</li>
 *   <li>DB: Update member details (CBR opt-out flag, user-merge audit row)
 *       via {@link #dbMemberUpdates(HashMap, HashMap)}.</li>
 *   <li>DB: Delete the fromSLID member/group record via {@link #dbDeleteUser(HashMap)}.</li>
 *   <li>DB: Apply role status and role-ID updates via {@link #dbRoleUpdates()}.</li>
 *   <li>DB: Insert new services on toSLID via {@link #dbServicesUpdates(Map)}.</li>
 *   <li>DB: Insert new accounts, roles, service-attributes, and wireline data on toSLID
 *       via {@link #dbAccountsUpdates()}.</li>
 *   <li>Publish DBUS events (DeleteMemberList, AddMemberList, NotificationEvent) to MQ/AEH
 *       via {@link #sendMessageToMQ(HashMap, HashMap, Map)}.</li>
 * </ol>
 *
 * <h3>Scope — prototype</h3>
 * <p>This bean is {@code @Scope("prototype")} so each request gets a fresh instance. Instance fields
 * (e.g. {@code alFromSlidECOMM}, {@code stFromSlidMemberNum}) hold per-invocation state that is
 * initialized at the start of {@link #mergeUserAccessId(Map)} and must not leak across calls.</p>
 *
 * <h3>Service Type Categories</h3>
 * <ul>
 *   <li><b>ECOMM</b> — E-commerce / wireline accounts</li>
 *   <li><b>MOBILITY</b> — Wireless / mobile accounts (including MAINUVERSE sub-instances)</li>
 *   <li><b>DTV</b> — DirecTV / video accounts</li>
 *   <li><b>TITAN</b> — Fiber / LS (LightSpeed) accounts</li>
 *   <li><b>MOSUB</b> — Mobility subscription / main CTN accounts</li>
 *   <li><b>DYNAMIC</b> — Configurable services flagged with {@code process_dynamically = 'Y'} in the DB</li>
 *   <li><b>VAS / CONNECTEDHOME</b> — Blocked from merge (rejected in {@link #fromSLIDSplitServices(Map)})</li>
 * </ul>
 *
 * @see AbstractHelper
 */
@Component
@Configuration
@Scope(value = "prototype", proxyMode = ScopedProxyMode.TARGET_CLASS)
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class MergeUserAccessIdHelper extends AbstractHelper {

    public static final Logger logger = LoggerFactory.getLogger(MergeUserAccessIdHelper.class);
    private static final String sClassName = "MergeUserAccessHelper";
    // CommonDefs currently lacks dedicated constants for these service identifiers.
    private static final String VAS_SERVICE = "VAS";
    private static final String CONNECTEDHOME_SERVICE = "CONNECTEDHOME";

    // ── fromSLID per-service-type account lists ──
    // Populated by fromSLIDSplitServices(); each list holds account-level HashMaps for the source SLID.
    private HashMap<String,	Object> hmFromSlidServices = CommonUtil.getHashMap();
    private ArrayList alFromSlidECOMM;
    private ArrayList alFromSlidMOBILITY;
    private ArrayList alFromSlidTITAN;
    private ArrayList alFromSlidMOSUB ;
    private ArrayList alFromSlidDYNAMIC;
    private ArrayList alFromSLIDWireLineDetails;
    private ArrayList alFromSlidDTV;
    private ArrayList alFromSlidLinkedUsers;

    // ── toSLID per-service-type account lists ──
    // Populated by toSLIDSplitServices(); each list holds account-level HashMaps for the target SLID.
    private ArrayList alToSlidECOMM;
    private ArrayList alToSlidMOBILITY;
    private ArrayList alToSlidTITAN;
    private ArrayList alToSlidMOSUB;
    private ArrayList alToSlidDYNAMIC;
    private ArrayList alToSlidDTV;
    private ArrayList alToSlidLinkedUsers;
    private HashMap<String,	Object> hmToSlidServices;

    // ── Merge output collectors ──
    // alAddServiceList: services (MOSUB, dynamic) to be added to toSLID via dbServicesUpdates()
    private ArrayList alAddServiceList;
    // alAddToSlidAccounts: full account structures (services + roles + attributes) to insert via dbAccountsUpdates()
    private ArrayList alAddToSlidAccounts;
    // alToSlidDynAccessGroup: access-group names already present on toSLID (used to avoid duplicate dynamic service groups)
    private ArrayList alToSlidDynAccessGroup;
    // hmDynAccessGroupToBeAdded: new dynamic access-group names (key) and their SOR names (value) to add to toSLID
    private HashMap<String, String> hmDynAccessGroupToBeAdded;
    // alNotificationEventAccountList: accounts to include in the EDD NotificationEvent sent via DBUS
    private ArrayList alNotificationEventAccountList;
    // alMemberServiceRoleStatus: role-status updates to apply via dbRoleUpdates() (e.g. enable a disabled role)
    private ArrayList alMemberServiceRoleStatus;
    // alMemberServiceRoleId: role-ID updates to apply via dbRoleUpdates() (e.g. overwrite AUTHORIZEDUSER role_id with OWNER role_id)
    private ArrayList alMemberServiceRoleId;
    // alProcessDbus: all DBUS events (DeleteMemberList, AddMemberList, Unlink, Link) accumulated during the merge
    private ArrayList alProcessDbus;

    // ── Merge context identifiers ──
    private String stFromSlidMemberNum;
    private String stFromSlidGroupNum;
    private String stToSlidMemberNum;
    private String stToSlidGroupNum;
    private String stCallingSystemId;
    private String stTransactionId;
    private String stTransactionName;

    // ── Flags set by checkDefaultAccountToSlid() ──
    // toSLIDDefaultAccountExist: true when toSLID already has an account marked as the default
    private boolean toSLIDDefaultAccountExist;
    // isCPNILinkedToSLID: true when toSLID has a CPNI-impacted account (affects notification flow)
    private boolean isCPNILinkedToSLID;
    // services: reference data map of all service types loaded from the DB at the start of the merge
    private HashMap<String, Object> services;

    private final GetMemberServicesDBHelper oGetMemberServicesDBHelper;
    private final DBHelper oDBHelper;
    private final MemberDBHelper oMemberDBHelper;
    private final DeleteMemberDBHelper oDeleteMemberDBHelper;
    private final UserMergeDBHelper ouserMergeDBHelper;
    private final MergeYahooIDDBHelper omergeYahooIDDBHelper;
    private final RolesDBHelper orolesDBHelper;
    private final MemberServiceAttributeDBHelper omemberServiceAttributeDBHelper;
    private final AddServiceDBHelper oaddServiceDBHelper;
    private final UpdateAssociationDBHelper updateAssociationDBHelper;
    private final ProofingEncryptionHelper proofingEncryptionHelper;
    private final JMSQueueSender oJMSQueueSender;
    private final PublishMqAehHelper publishMqAehHelper;
    private final FeatureManagerHelper featureManager;
    private final UnlinkMemberIdHelper unlinkMemberIdHelper;
    private final LinkMemberHelper linkMemberHelper;
    private final String propPrepaidMOBILITYAccountTypeList;

    public MergeUserAccessIdHelper(
            GetMemberServicesDBHelper oGetMemberServicesDBHelper,
            DBHelper oDBHelper,
            MemberDBHelper oMemberDBHelper,
            DeleteMemberDBHelper oDeleteMemberDBHelper,
            UserMergeDBHelper ouserMergeDBHelper,
            MergeYahooIDDBHelper omergeYahooIDDBHelper,
            RolesDBHelper orolesDBHelper,
            MemberServiceAttributeDBHelper omemberServiceAttributeDBHelper,
            AddServiceDBHelper oaddServiceDBHelper,
            UpdateAssociationDBHelper updateAssociationDBHelper,
            ProofingEncryptionHelper proofingEncryptionHelper,
            JMSQueueSender oJMSQueueSender,
            PublishMqAehHelper publishMqAehHelper,
            FeatureManagerHelper featureManager,
            UnlinkMemberIdHelper unlinkMemberIdHelper,
            LinkMemberHelper linkMemberHelper,
            @Value("${PrepaidMOBILITYAccountTypeList}") String propPrepaidMOBILITYAccountTypeList) {
        this.oGetMemberServicesDBHelper = oGetMemberServicesDBHelper;
        this.oDBHelper = oDBHelper;
        this.oMemberDBHelper = oMemberDBHelper;
        this.oDeleteMemberDBHelper = oDeleteMemberDBHelper;
        this.ouserMergeDBHelper = ouserMergeDBHelper;
        this.omergeYahooIDDBHelper = omergeYahooIDDBHelper;
        this.orolesDBHelper = orolesDBHelper;
        this.omemberServiceAttributeDBHelper = omemberServiceAttributeDBHelper;
        this.oaddServiceDBHelper = oaddServiceDBHelper;
        this.updateAssociationDBHelper = updateAssociationDBHelper;
        this.proofingEncryptionHelper = proofingEncryptionHelper;
        this.oJMSQueueSender = oJMSQueueSender;
        this.publishMqAehHelper = publishMqAehHelper;
        this.featureManager = featureManager;
        this.unlinkMemberIdHelper = unlinkMemberIdHelper;
        this.linkMemberHelper = linkMemberHelper;
        this.propPrepaidMOBILITYAccountTypeList = propPrepaidMOBILITYAccountTypeList;
    }

    /**
     * Main entry point for the merge-user-access-ID operation.
     *
     * <p>Orchestrates a 21-step pipeline that transfers every service and account from
     * {@code fromSLID} (source) to {@code toSLID} (target), performs guard-rail checks
     * (fraud lock, FirstNet, mergeable indicator, max-services limit), executes the
     * required DB mutations (member, roles, services, accounts), and finally publishes
     * DBUS events to MQ/AEH for downstream consumers.</p>
     *
     * <p><b>Early-return pattern:</b> Each step checks the returned status code.
     * On any non-success code the method returns immediately with the error map,
     * skipping all subsequent steps.</p>
     *
     * @param hmInput Input map expected to contain at minimum:
     *                <ul>
     *                  <li>{@code FROM_USERNAME} — the source SLID</li>
     *                  <li>{@code TO_USERNAME} — the target SLID</li>
     *                  <li>{@code CALLING_SYSTEM_ID} — originating system</li>
     *                  <li>{@code TRANSACTION_ID} — correlation ID</li>
     *                  <li>{@code TRANSACTION_NAME} — operation name</li>
     *                </ul>
     * @return Result map with at least {@code APP_STATUS_CODE} and {@code APP_CATEGORY_CODE}.
     *         On MQ/AEH failure after DB writes, the map also contains
     *         {@code isTransactionRollback = "Y"} to signal the caller to roll back.
     */
    public Map<String, Object> mergeUserAccessId(Map<String, Object> hmInput) {
        String sMethodName = ".mergeUserAccessId.";
        Map<String, Object> hmResult = null;

        String stAppStatusCode;
        String stAppInfo;
        boolean isTransactionRollbackOnError = false;

        if (hmInput == null || hmInput.isEmpty()) {
            stAppInfo = "Input hashmap is NULL or EMPTY";
            logger.info("{}{}MUAI000 : {}", sClassName, sMethodName, stAppInfo);
            return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
        }

        logger.info("{}{}HLP000 : mergeUserAccessId start fromSLID={} toSLID={} txnId={}", sClassName, sMethodName,
                hmInput.get(CommonDefs.FROM_USERNAME), hmInput.get(CommonDefs.TO_USERNAME),
                hmInput.get(CommonDefs.TRANSACTION_ID));
        logger.debug("{}{}HLP000 : Input Hash : {}", sClassName, sMethodName,
                HtmlUtils.htmlEscape(String.valueOf(hmInput)));
        try{

            //1. Initialize the global variables
            initialize();

            //2. Retrieves the services from the DBHelper
            services = oDBHelper.getServices();
            if (services == null || services.isEmpty()) {
                throw new Exception("Services HashMap is empty");
            }
            logger.info("{}{}MUAI001 : GetServices method has retrieved {} services",
                    sClassName, sMethodName, services.size());

            stCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
            stTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);
            stTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);

            //3. START: Retrieves the SLID information for the "fromUser"
            // The getSLIDInfo method is expected to return a HashMap containing the SLID information.
            HashMap<String, Object> hmFromSlidGetInfoResponse = (HashMap<String, Object>) getSLIDInfoResponse(
                    hmInput.get(CommonDefs.FROM_USERNAME).toString());
            if (hmFromSlidGetInfoResponse == null) {
                stAppInfo = "GetMemberServicesDBHelper.getMemberServices helper returned null.";
                logger.error("{}{}MUAI002 : {}", sClassName, sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                return hmResult;
            }

            stAppStatusCode = (String) hmFromSlidGetInfoResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
            if (stAppStatusCode != null && !stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
                if (stAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
                    stAppInfo = "Input member info not found";
                    logger.info("{}{}MUAI003 : {}", sClassName, sMethodName, stAppInfo);
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
                } else {
                    hmResult.putAll(hmFromSlidGetInfoResponse);
                }
                return hmResult;
            }

            // 4. checkFraudLock against FromSLID
            hmResult = checkFraudLock(hmFromSlidGetInfoResponse);
            logger.debug("{}{}MUAI004 : checkFraudLock response for fromSLID: {}", sClassName, sMethodName, hmResult);
            stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                return hmResult;
            } else if (stAppStatusCode == null) {
                stAppInfo = "mergeUserAccessId.checkFraudLock has returned null response for FromSLID";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                logger.error("{}{}MUAI005 : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }

            // 5. Retrieves the SLID information for the "toUser".
            // The getSLIDInfo method is expected to return a HashMap containing the SLID information.
            HashMap<String, Object> hmToSlidGetInfoResponse = (HashMap<String, Object>) getSLIDInfoResponse(
                    hmInput.get(CommonDefs.TO_USERNAME).toString());

            if (hmToSlidGetInfoResponse == null) {
                stAppInfo = "GetMemberServicesDBHelper.getMemberServices helper returned null.";
                logger.error("{}{}MUAI006 : {}", sClassName, sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                return hmResult;
            }

            stAppStatusCode = (String) hmToSlidGetInfoResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
            if (stAppStatusCode != null && !stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
                if (stAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
                    stAppInfo = "Input member info not found";
                    logger.info("{}{}MUAI007 : {}", sClassName, sMethodName, stAppInfo);
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
                } else {
                    hmResult.putAll(hmToSlidGetInfoResponse);
                }
                return hmResult;
            }

            // 6. checkFraudLock against ToSLID
            hmResult = checkFraudLock(hmToSlidGetInfoResponse);
            logger.debug("{}{}MUAI008 : checkFraudLock response for toSLID: {}", sClassName, sMethodName, hmResult);
            stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                return hmResult;
            } else if (stAppStatusCode == null) {
                stAppInfo = "mergeUserAccessId.checkFraudLock has returned null response for toSLID";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                logger.error("{}{}MUAI009 : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }

            //pulling the SLIDInfo from the getSLIDInfo response
            HashMap<String, Object> hmFromSlidInfo = (HashMap<String, Object>)
                    hmFromSlidGetInfoResponse.get(CommonDefs.KEY_SLID_INFO);
            HashMap<String, Object> hmToSlidInfo = (HashMap<String, Object>)
                    hmToSlidGetInfoResponse.get(CommonDefs.KEY_SLID_INFO);

            // Enrich the SLID info maps with services, wireline details, and linked-users
            // so that the split methods (fromSLIDSplitServices / toSLIDSplitServices) can access
            // all nested data from a single enriched map. This mirrors the legacy MPS monolith
            // behaviour where the full profile was available in one flat structure.
            HashMap<String, Object> hmFromSlidInfoForSplit = new HashMap<>();
            if (hmFromSlidInfo != null && !hmFromSlidInfo.isEmpty()) {
                hmFromSlidInfoForSplit.putAll(hmFromSlidInfo);
            }
            if (hmFromSlidGetInfoResponse != null) {
                hmFromSlidInfoForSplit.put(CommonDefs.SERVICES, hmFromSlidGetInfoResponse.get(CommonDefs.SERVICES));
                hmFromSlidInfoForSplit.put(MPSDefs.DB_WIRELINEUSER, hmFromSlidGetInfoResponse.get(MPSDefs.DB_WIRELINEUSER));
                // linkedUsers is nested under KEY_SLID_INFO, already copied by putAll above;
                // do NOT overwrite from the top-level response (where it does not exist) — that was
                // causing unlinkAndLinkInternetAccount to see null and skip the unlink step.
            }

            HashMap<String, Object> hmToSlidInfoForSplit = new HashMap<>();
            if (hmToSlidInfo != null && !hmToSlidInfo.isEmpty()) {
                hmToSlidInfoForSplit.putAll(hmToSlidInfo);
            }
            if (hmToSlidGetInfoResponse != null) {
                hmToSlidInfoForSplit.put(CommonDefs.SERVICES, hmToSlidGetInfoResponse.get(CommonDefs.SERVICES));
                hmToSlidInfoForSplit.put(MPSDefs.DB_WIRELINEUSER, hmToSlidGetInfoResponse.get(MPSDefs.DB_WIRELINEUSER));
                // linkedUsers is nested under KEY_SLID_INFO, already copied by putAll above;
                // do NOT overwrite from the top-level response (where it does not exist).
            }

            // 8. Reject merge if fromSLID is a FirstNet (FN) access ID.
            //    FN_LINKED_STATUS of "pending" or "self" means the SLID is linked to FirstNet
            //    and cannot participate in a merge operation.
            if (hmFromSlidInfo != null) {
                if (!hmFromSlidInfo.isEmpty()) {
                    String sFnLinkedStatus = (String) hmFromSlidInfo.get("FN_LINKED_STATUS");
                    if (sFnLinkedStatus != null && (sFnLinkedStatus.equalsIgnoreCase("pending")
                            || sFnLinkedStatus.equalsIgnoreCase("self"))) {
                        stAppInfo = "Cannot Merge FirstNet accessId";
                        logger.info("{}{}MUAI010 : {}", sClassName, sMethodName, stAppInfo);
                        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, stAppInfo);
                        return hmResult;
                    }
                }
            }

            // 9. Reject merge if fromSLID is explicitly marked as non-mergeable.
            //    MERGEABLE_IND = 'N' is set by business rules to prevent certain SLIDs from being merged.
            if (hmFromSlidInfo != null && !hmFromSlidInfo.isEmpty()) {
                String stMergeableInd = (String) hmFromSlidInfo.get(MPSDefs.DB_MERGEABLE_IND);
                if (stMergeableInd != null && stMergeableInd.equalsIgnoreCase(MPSDefs.NO)) {
                    stAppInfo = "Can not merge as mergeable_ind on fromSlid is set to N";
                    logger.info("{}{}MUAI011 : {}", sClassName, sMethodName, stAppInfo);
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_NOT_ALLOWED_NUM, stAppInfo);
                    return hmResult;
                }
            }

            // 10. To split all the services from the fromSLID to respective ArrayLists
            hmResult =  fromSLIDSplitServices(hmFromSlidInfoForSplit);
            stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                return hmResult;
            }

            // 11. To split all the services from the toSLID to respective ArrayLists
            hmResult =  toSLIDSplitServices(hmToSlidInfoForSplit);
            stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                return hmResult;
            }

            // 12. Unlink and link Internet Account
            hmResult =  unlinkAndLinkInternetAccount(hmFromSlidGetInfoResponse,hmToSlidGetInfoResponse,hmInput);
            stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                isTransactionRollbackOnError = true;
                return hmResult;
            }

            // 13. To check if there are default accounts in toSLID
            hmResult =  checkDefaultAccountToSlid();
            stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                return hmResult;
            }

            // 14. Get the list of eligible dynamic services to be added to toSLID
            if(alFromSlidDYNAMIC != null && !alFromSlidDYNAMIC.isEmpty()){
                logger.info("{}{}MUAI012 : processDynamicServices fromCount={} toCount={}", sClassName, sMethodName,
                        alFromSlidDYNAMIC.size(), (alToSlidDYNAMIC != null ? alToSlidDYNAMIC.size() : 0));
                logger.debug("{}{}MUAI012 : alFromSlidDYNAMIC={} alToSlidDYNAMIC={}", sClassName, sMethodName,
                        alFromSlidDYNAMIC, alToSlidDYNAMIC);
                hmResult = processDynamicServices(alFromSlidDYNAMIC, alToSlidDYNAMIC);
                logger.debug("{}{}MUAI013 : processDynamicServices response={}", sClassName, sMethodName, hmResult);
                if (hmResult == null || hmResult.isEmpty()) {
                    stAppInfo = "Null Response returned from processDynamicServices()";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                    logger.error("{}{}MUAI014 : {}", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                }
                stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                if (stAppStatusCode  != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                    stAppInfo = "Error returned After calling processDynamicServices()";
                    logger.error("{}{}MUAI015 : {}", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                }

                // Collect the dynamic services that passed the merge-action and single-instance
                // checks. These will be added to toSLID alongside MOSUB services in dbServicesUpdates().
                ArrayList alDynamicServicesToAdd = (ArrayList)hmResult.get("AddDynamicServices");
                if(alDynamicServicesToAdd != null && !alDynamicServicesToAdd.isEmpty()){
                    alAddServiceList.addAll(alDynamicServicesToAdd);
                }

            }else{
                stAppInfo = "The dynamic services ArrayList for forSLID is null or empty";
                logger.info("{}{}MUAI016 : {}" , sClassName , sMethodName, stAppInfo);
            }

            // 15. prepare the accounts HashMap to be added to toSLID
            hmResult =  prepareAccountsHashMap();
            stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                return hmResult;
            }

            // 16. Database Calls - Member updates.
            hmResult =  dbMemberUpdates(hmFromSlidInfo,hmToSlidInfo);
            stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                isTransactionRollbackOnError = true;
                return hmResult;
            }

            // 17. Database Calls - Delete User.
            hmResult =  dbDeleteUser(hmFromSlidInfo);
            stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                isTransactionRollbackOnError = true;
                return hmResult;
            }

            // 18. Database Calls - Role updates.
            hmResult =  dbRoleUpdates();
            stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                isTransactionRollbackOnError = true;
                return hmResult;
            }

            // 19. Database Calls - Services addition.
            hmResult =  dbServicesUpdates(hmToSlidInfo);
            stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                isTransactionRollbackOnError = true;
                return hmResult;
            }

            // 20. Database Calls - Adding Roles and related data.
            hmResult =  dbAccountsUpdates();
            stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                isTransactionRollbackOnError = true;
                return hmResult;
            }

            // 21. Dbus Calls.
            Map hmDbusResult =  sendMessageToMQ(hmFromSlidInfo, hmToSlidInfo, hmInput);
            stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                return hmResult;
            }

            if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmDbusResult)) {
                hmResult = CommonUtilHelper.sysErrorHashMap("null response from sendMessageToMQ");
                isTransactionRollbackOnError = true;
                return hmResult;
            } else {
                stAppStatusCode = (String) hmDbusResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
                if (StringUtils.isBlank(stAppStatusCode)) {
                    isTransactionRollbackOnError = true;
                    hmResult = CommonUtilHelper.sysErrorHashMap("null response from sendMessageToMQ");
                    return hmResult;
                } else if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                    isTransactionRollbackOnError = true;
                    stAppInfo = (String) hmDbusResult.get(CommonDefs.COMMON_APP_INFO);
                    logger.error("{}{}MUAI017 : DBUS failure: {}", sClassName, sMethodName,
                            HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
                    hmResult = hmDbusResult;
                    return hmResult;
                }
            }
        }
        catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e);
            stAppInfo = "Exception thrown mergeUserAccessId method : " + hmResult;
            logger.error("{}{}MUAI018 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));

        } finally {
            // If DB writes succeeded but MQ/AEH publishing failed, flag the result so the
            // calling ServiceImpl can trigger a transaction rollback to maintain consistency.
            String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);

            if (isTransactionRollbackOnError && sAppCategoryCode != null
                    && !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
                hmResult.put("isTransactionRollback", "Y");
            }
            logger.info("{}{}HLP999 : mergeUserAccessId complete statusCode={}", sClassName, sMethodName,
                    hmResult != null ? hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE) : null);
            logger.debug("{}{}HLP999 : mergeUserAccessId response={}", sClassName, sMethodName,
                    HtmlUtils.htmlEscape(String.valueOf(hmResult)));
        }
        return hmResult;
    }

    /**
     * Retrieves the full SLID profile for a given username by querying
     * {@link GetMemberServicesDBHelper#getMemberServices(HashMap)}.
     *
     * <p>The DB query is configured with the following flags:</p>
     * <ul>
     *   <li>{@code SECURITY_ALL_REQ = Y} — fetch all security data</li>
     *   <li>{@code QUERY_SLID_INFO_FLAG = Y} — include member/group info</li>
     *   <li>{@code QUERY_LINKED_USERS_FLAG = Y} — include linked internet accounts</li>
     *   <li>{@code QUERY_FRAUD_LOCK_FLAG = Y} — include fraud-lock status</li>
     *   <li>{@code SLID_MASK = [LU, LS, SQ]} — filter linked-user types to
     *       LU (Linked User), LS (LightSpeed parent), SQ (Security Questions)</li>
     *   <li>{@code QUERY_ROLES_INFO_FLAG = [ALL]} — fetch service roles for all service types
     *       (parity with legacy SR mask)</li>
     *   <li>{@code QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG = Y} — fetch member service attributes
     *       (parity with legacy queryMemberServiceAttribute=Y)</li>
     * </ul>
     *
     * @param userName The SLID (e.g. {@code "john_doe"}) to look up.
     * @return Full profile map including services, linked users, fraud lock, SLID info,
     *         or {@code null} if the DB helper itself throws.
     */
    private Map<String, Object> getSLIDInfoResponse(String userName) {
        String sMethodName = "getSLIDInfoResponse";
        String stAppInfo = null;
        Date tmsStartDate = new Date();
        HashMap hmResult = null;
        HashMap<String, Object> hmDBMemberInfo = null;
        logger.debug("{}{}GSIR000 : Input Username is: {}", sClassName, sMethodName, userName);
        try {
            String stAppStatusCode;
            HashMap<String, Object> hmDbInput = CommonUtil.getHashMap();
            ArrayList alSildMaskInp = new ArrayList();
            alSildMaskInp.add("LU");
            alSildMaskInp.add("LS");
            alSildMaskInp.add("SQ");

            hmDbInput.put(MPSDefs.SECURITY_ALL_REQ, CommonDefs.DEFAULT_YES);
            hmDbInput.put(MPSDefs.QUERY_SLID_INFO_FLAG, CommonDefs.DEFAULT_YES);
            hmDbInput.put(MPSDefs.QUERY_LINKED_USERS_FLAG, CommonDefs.DEFAULT_YES);
            hmDbInput.put(MPSDefs.QUERY_FRAUD_LOCK_FLAG, CommonDefs.DEFAULT_YES);
            hmDbInput.put(CommonDefs.SLID_MASK, alSildMaskInp);

            // Query service roles for all service types (parity with legacy SR mask)
            ArrayList alQueryRoles = new ArrayList();
            alQueryRoles.add("ALL");
            hmDbInput.put(MPSDefs.QUERY_ROLES_INFO_FLAG, alQueryRoles);

            // Query member service attributes (parity with legacy queryMemberServiceAttribute=Y)
            hmDbInput.put(MPSDefs.QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG, MPSDefs.YES);

            if(userName != null){
                hmDbInput.put(MPSDefs.DB_MEMBER_NAME, userName);
                hmDbInput.put(MPSDefs.DB_DOMAIN_NAME, CommonDefs.SLID_DUM);
            }

            hmDBMemberInfo = oGetMemberServicesDBHelper.getMemberServices(hmDbInput);

        } catch (Exception e) {
            stAppInfo = "Exception thrown in getSLIDInfoResponse() method::" + e.getMessage();
            hmResult = CommonErrorMap.makeExceptionMap(e);
            logger.error("{}{}GSIR001 : {} " , sClassName , sMethodName, stAppInfo);
        } finally {
            logger.debug("{}{}GSIR999 : elapsed={}ms response={}", sClassName, sMethodName,
                    (new Date().getTime() - tmsStartDate.getTime()), hmDBMemberInfo);
        }
        return hmDBMemberInfo;
    }

    /**
     * Splits the source SLID’s services into per-type instance fields.
     *
     * <p>For each known service type (ECOMM, MOBILITY, DTV, TITAN, MOSUB) and for
     * dynamically-flagged services, this method extracts the individual account instances
     * from the nested services map and populates the corresponding {@code alFromSlid*}
     * lists. It also captures wireline details and linked users.</p>
     *
     * <p><b>Merge blockers:</b> If the fromSLID contains a VAS or CONNECTEDHOME service,
     * the merge is rejected immediately with {@code ERR_CANNOT_OPERATE_ON_SERVICE}.</p>
     *
     * @param hmFromSlidInfo Enriched fromSLID info map (member info + services + wireline + linked users).
     * @return Success map on completion, or error map if VAS/CONNECTEDHOME detected or an exception occurs.
     */
    private Map<String, Object> fromSLIDSplitServices(Map<String, Object> hmFromSlidInfo) {
        String sMethodName = "fromSLIDSplitServices";
        String stAppInfo = null;
        Date tmsStartDate = new Date();
        HashMap hmResult = null;
        logger.info("{}{}FSSS000 : fromSLIDSplitServices start", sClassName, sMethodName);
        logger.debug("{}{}FSSS000 : Input hash: {}", sClassName, sMethodName, hmFromSlidInfo);
        try {
            ArrayList alFromSlidDTV = new ArrayList();
            if(hmFromSlidInfo != null && !hmFromSlidInfo.isEmpty()){
                hmFromSlidServices = (HashMap<String, Object>)hmFromSlidInfo.get(CommonDefs.SERVICES);
                stFromSlidMemberNum = (String)hmFromSlidInfo.get(MPSDefs.DB_MEMBER_NUM);
                stFromSlidGroupNum = (String)hmFromSlidInfo.get(MPSDefs.DB_GROUP_NUM);
                alFromSLIDWireLineDetails = (ArrayList)hmFromSlidInfo.get(MPSDefs.DB_WIRELINEUSER);;
                if(hmFromSlidServices != null && !hmFromSlidServices.isEmpty()){
                    if (hmFromSlidServices.containsKey(VAS_SERVICE)) {
                        stAppInfo = "fromSLID has a VAS service. merge is not allowed";
                        hmResult = CommonErrorMap.makeCategoryMap(
                                CErrorDefs.ERR_CANNOT_OPERATE_ON_SERVICE_NUM, stAppInfo);
                        logger.info("{}{}FSSS_VAS : {}", sClassName, sMethodName, stAppInfo);
                        return hmResult;
                    }

                    if (hmFromSlidServices.containsKey(CONNECTEDHOME_SERVICE)) {
                        stAppInfo = "fromSLID has a CONNECTEDHOME service. merge is not allowed";
                        hmResult = CommonErrorMap.makeCategoryMap(
                                CErrorDefs.ERR_CANNOT_OPERATE_ON_SERVICE_NUM, stAppInfo);
                        logger.info("{}{}FSSS_CH : {}", sClassName, sMethodName, stAppInfo);
                        return hmResult;
                    }

                    extractDynamicServices();

                    if(hmFromSlidServices.containsKey(CommonDefs.ECOMM_SERVICE)){
                        processService(hmFromSlidServices, CommonDefs.ECOMM_SERVICE, alFromSlidECOMM);
                    }

                    if(hmFromSlidServices.containsKey(CommonDefs.MOBILITY_SERVICE)){
                        processService(hmFromSlidServices, CommonDefs.MOBILITY_SERVICE, alFromSlidMOBILITY);
                    }

                    if(hmFromSlidServices.containsKey(CommonDefs.DTV_SERVICE)){
                        processService(hmFromSlidServices, CommonDefs.DTV_SERVICE, alFromSlidDTV);
                    }

                    if(hmFromSlidServices.containsKey(CommonDefs.TITAN_SERVICE)){
                        processService(hmFromSlidServices, CommonDefs.TITAN_SERVICE, alFromSlidTITAN);
                    }

                    if(hmFromSlidServices.containsKey(CommonDefs.MOSUB_SERVICE)){
                        processService(hmFromSlidServices, CommonDefs.MOSUB_SERVICE, alFromSlidMOSUB);
                    }
                }
                //TODO test if linked users are being pulled.
                if(hmFromSlidInfo.containsKey(MPSDefs.KEY_LINKED_USERS)){
                    alFromSlidLinkedUsers = (ArrayList)hmFromSlidInfo.get(MPSDefs.KEY_LINKED_USERS);
                }
            }
            hmResult = CommonErrorMap.makeCategoryMap(
                    CommonDefs.COMMON_SUCCESS_NUM,
                    CommonDefs.COMMON_SUCCESS_MSG);
        } catch (Exception e) {
            stAppInfo = "Exception thrown in fromSLIDSplitServices() method::" + e.getMessage();
            hmResult = CommonErrorMap.makeExceptionMap(e);
            logger.error("{}{}FSSS002 : {} " , sClassName , sMethodName, stAppInfo);
        } finally {
            logger.debug("{}{}FSSS999 : elapsed={}ms response={}", sClassName, sMethodName,
                    (new Date().getTime() - tmsStartDate.getTime()), hmResult);
        }
        return hmResult;
    }

    /**
     * Extracts individual service instances from a parent service-type map and adds them
     * to the provided list.
     *
     * <p>The service-type map (e.g. the ECOMM or MOBILITY entry inside the SLID’s services)
     * uses instance keys (such as a SOR invariant ID) as map keys, with each value being a
     * HashMap of account-level data. This method iterates over those entries, stamps each
     * with its {@code DB_INSTANCE_ID} (the map key), and appends it to {@code listToPopulate}.</p>
     *
     * <p>For MOSUB services, the {@code DB_SERVICE_NAME} field is also explicitly set to maintain
     * consistency with the existing legacy code behaviour.</p>
     *
     * @param hmFromSlidServices The full services map for a SLID.
     * @param serviceName        The service-type key (e.g. {@code CommonDefs.ECOMM_SERVICE}).
     * @param listToPopulate     The target list to add extracted instances to.
     */
    private void processService(HashMap<String, Object> hmFromSlidServices, String serviceName, ArrayList listToPopulate) {
        HashMap hmTempService = (HashMap) hmFromSlidServices.get(serviceName);
        Iterator instanceIter = (Iterator) hmTempService.keySet().iterator();
        while (instanceIter != null && instanceIter.hasNext()) {

            String key = (String) instanceIter.next();
            Object value = null;
            if (key != null)
                value = hmTempService.get(key);
            if (value != null && value instanceof HashMap) {
                HashMap hmTemp = (HashMap) value;
                if (hmTemp != null && !hmTemp.isEmpty()) {
                    hmTemp.put(MPSDefs.DB_INSTANCE_ID, key);
                    if (serviceName.equals(CommonDefs.MOSUB_SERVICE)) { // to be consistent with existing code
                        hmTemp.put(MPSDefs.DB_SERVICE_NAME, serviceName);
                    }
                    listToPopulate.add(hmTemp);
                }
            }
        }
    }

    /**
     * Scans all fromSLID services and extracts those flagged as dynamically-processable.
     *
     * <p>For each service type in {@code hmFromSlidServices}, this method looks up the
     * service metadata via {@link #getServiceDataByName(String)} and checks the
     * {@code process_dynamically} flag. If set to {@code "Y"}, all instances of that
     * service are extracted (with their {@code DB_INSTANCE_ID} and a {@code ProcessDynamic = "Y"}
     * marker) and added to the {@code alFromSlidDYNAMIC} list.</p>
     *
     * <p>These dynamic services are later compared against the toSLID’s dynamic services
     * in {@link #processDynamicServices(ArrayList, ArrayList)} to determine eligibility
     * for transfer.</p>
     */
    private void extractDynamicServices() {
        Iterator itrFromSlidServiceKeys = hmFromSlidServices.entrySet().iterator();

        HashMap hmDBService;
        String sServiceType;
        Entry mapEntry;
        // iteration for Slid services and creating a separate list for Dynamic Services.
        while(itrFromSlidServiceKeys.hasNext()){
            mapEntry = (Entry) itrFromSlidServiceKeys.next();
            hmDBService = (HashMap)mapEntry.getValue();
            sServiceType=(String)mapEntry.getKey();
            HashMap<String, Object> myService = getServiceDataByName(sServiceType);
            String stProcessDynamically = myService.get("process_dynamically") != null ?
                    myService.get("process_dynamically").toString() : null;
            if(stProcessDynamically != null && stProcessDynamically.equals("Y")){
                Iterator instanceIter = (Iterator) hmDBService.keySet().iterator();
                while (instanceIter != null && instanceIter.hasNext()) {
                    String key = (String) instanceIter.next();
                    Object value = null;
                    if (key != null){
                        value = hmDBService.get(key);
                    }
                    if (value != null && value instanceof HashMap){
                        HashMap hmTemp = (HashMap)value;
                        if(hmTemp != null && !hmTemp.isEmpty()){
                            hmTemp.put(MPSDefs.DB_INSTANCE_ID, key);
                            hmTemp.put("ProcessDynamic", "Y");
                            alFromSlidDYNAMIC.add(hmTemp);
                        }
                    }
                }
            }
        }
    }

    /**
     * Splits the target SLID’s services into per-type instance fields and enforces the
     * maximum-services-per-SLID limit.
     *
     * <p>This method mirrors {@link #fromSLIDSplitServices(Map)} but operates on the toSLID.
     * In addition to splitting services into {@code alToSlid*} lists, it:</p>
     * <ol>
     *   <li>Reads {@code PROP_ACCESSID_SERVICES_ACCOUNTS_MAX_LIMIT} (typically 25) from config.</li>
     *   <li>Counts the total service instances on both fromSLID and toSLID.</li>
     *   <li>Rejects the merge if the combined count exceeds the limit.</li>
     *   <li>Extracts dynamic services from toSLID and records their access-groups in
     *       {@code alToSlidDynAccessGroup} to prevent duplicate group additions later.</li>
     * </ol>
     *
     * @param hmToSlidInfo Enriched toSLID info map (member info + services + wireline + linked users).
     * @return Success map on completion, or error map if the max-services limit is exceeded,
     *         the config property is missing, or an exception occurs.
     */
    private Map<String, Object> toSLIDSplitServices(Map<String, Object> hmToSlidInfo) {
        String sMethodName = "toSLIDSplitServices";
        String stAppInfo = null;
        Date tmsStartDate = new Date();
        HashMap hmResult = null;
        ArrayList alToSlidDTV = new ArrayList();
        logger.info("{}{}TSSS000 : toSLIDSplitServices start", sClassName, sMethodName);
        logger.debug("{}{}TSSS000 : Input hash: {}", sClassName, sMethodName, hmToSlidInfo);

        try {
            hmToSlidServices = (HashMap<String, Object>)hmToSlidInfo.get(CommonDefs.SERVICES);
            stToSlidMemberNum = (String)hmToSlidInfo.get(MPSDefs.DB_MEMBER_NUM);
            stToSlidGroupNum = (String)hmToSlidInfo.get(MPSDefs.DB_GROUP_NUM);

            String sMaxAllowedSvcsAccounts = PropertyManager.getProperty(CommonDefs.MOUPConfig,
                    "PROP_ACCESSID_SERVICES_ACCOUNTS_MAX_LIMIT");
            logger.info("{}{}TSSS001 : sMaxAllowedSvcsAccounts is: {}", sClassName, sMethodName, sMaxAllowedSvcsAccounts);
            if(sMaxAllowedSvcsAccounts != null && sMaxAllowedSvcsAccounts.trim().length() > 0) {
                int iMaxAllowedSvcsAccounts = Integer.parseInt(sMaxAllowedSvcsAccounts);
                int iToSlidTotalSvcsAccounts = !isMapNullOrEmpty(hmToSlidServices) ?
                        getToSlidTotalSvcsAccountsCount(hmToSlidServices, "toSLID") : 0;
                int iFromSlidTotalSvcsAccounts = !isMapNullOrEmpty(hmFromSlidServices) ?
                        getToSlidTotalSvcsAccountsCount(hmFromSlidServices, "fromSLID") : 0;

                if((iToSlidTotalSvcsAccounts + iFromSlidTotalSvcsAccounts) > iMaxAllowedSvcsAccounts) {
                    stAppInfo = "toSLID cannot have more than 25 services, cannot operate or merge. Current total " +
                            "service count is "+(iToSlidTotalSvcsAccounts + iFromSlidTotalSvcsAccounts);
                    hmResult = CommonErrorMap.makeCategoryMap(
                            CErrorDefs.ERR_MAX_ACCOUNTS_ON_ACCESSID_NUM, stAppInfo);
                    logger.error("{}{}TSSS002 : {}", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                }
            }
            else {
                String appInfo = "Missing config Parameter PROP_ACCESSID_SERVICES_ACCOUNTS_MAX_LIMIT";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, appInfo);
                logger.error("{}{}TSSS003 : {}", sClassName, sMethodName, appInfo);
                return hmResult;
            }


            if(hmToSlidServices != null && !hmToSlidServices.isEmpty()){
                Iterator itrToSlidServiceKeys = hmToSlidServices.entrySet().iterator();
                Entry mapEntry	= null;
                HashMap hmDBService		= null;
                String sServiceType				= null;
                while(itrToSlidServiceKeys.hasNext()){
                    mapEntry = (Entry)itrToSlidServiceKeys.next();
                    hmDBService = (HashMap)mapEntry.getValue();
                    sServiceType=(String)mapEntry.getKey();
                    HashMap<String, Object> myService = getServiceDataByName(sServiceType);
                    String stProcessDynamically = myService.get("process_dynamically") != null ?
                            myService.get("process_dynamically").toString() : null;
                    if(stProcessDynamically != null && stProcessDynamically.equals("Y")){
                        Iterator instanceIter = (Iterator) hmDBService.keySet().iterator();
                        while (instanceIter != null && instanceIter.hasNext()) {
                            String key = (String) instanceIter.next();
                            Object value = null;
                            if (key != null){
                                value = hmDBService.get(key);
                            }
                            if (value != null && value instanceof HashMap){
                                HashMap hmTemp = (HashMap)value;
                                if(hmTemp != null && !hmTemp.isEmpty()){
                                    hmTemp.put(MPSDefs.DB_INSTANCE_ID, key);
                                    String sDynamicServiceId = (String) hmTemp.get(MPSDefs.DB_SERVICE_ID);

                                    // checking for accessGroup which will be used later for sending newly added dynamic services  to tGuard
                                    HashMap hmDynamicServiceData = getServiceDataById(sDynamicServiceId);
                                    if(hmDynamicServiceData != null && !hmDynamicServiceData.isEmpty()){
                                        String sAccessGroup = (String) hmDynamicServiceData.get(MPSDefs.DB_ACCESS_GROUP);
                                        if(alToSlidDynAccessGroup != null &&
                                                !alToSlidDynAccessGroup.contains(sAccessGroup)){
                                            alToSlidDynAccessGroup.add(sAccessGroup);
                                        }
                                    }
                                    alToSlidDYNAMIC.add(hmTemp);
                                }
                            }
                        }
                    }
                }


                if(hmToSlidServices.containsKey(CommonDefs.ECOMM_SERVICE)){
                    processService(hmToSlidServices, CommonDefs.ECOMM_SERVICE, alToSlidECOMM);
                }
                if(hmToSlidServices.containsKey(CommonDefs.MOBILITY_SERVICE)){
                    processService(hmToSlidServices, CommonDefs.MOBILITY_SERVICE, alToSlidMOBILITY);
                }

                if(hmToSlidServices.containsKey(CommonDefs.DTV_SERVICE)){
                    processService(hmToSlidServices, CommonDefs.DTV_SERVICE, alToSlidDTV);
                }

                if(hmToSlidServices.containsKey(CommonDefs.TITAN_SERVICE)){
                    processService(hmToSlidServices, CommonDefs.TITAN_SERVICE, alToSlidTITAN);
                }

                if(hmToSlidServices.containsKey(CommonDefs.MOSUB_SERVICE)){
                    processService(hmToSlidServices, CommonDefs.MOSUB_SERVICE, alToSlidMOSUB);
                }

            }
            if(hmToSlidInfo.containsKey(MPSDefs.KEY_LINKED_USERS)){
                alToSlidLinkedUsers = (ArrayList)hmToSlidInfo.get(MPSDefs.KEY_LINKED_USERS);
            }

            hmResult = CommonErrorMap.makeCategoryMap(
                    CommonDefs.COMMON_SUCCESS_NUM,
                    CommonDefs.COMMON_SUCCESS_MSG);

        } catch (Exception e) {
            stAppInfo = "Exception thrown in fromSLIDSplitServices() method::" + e.getMessage();
            hmResult = CommonErrorMap.makeExceptionMap(e);
            logger.error("{}{}TSSS004 : {} " , sClassName , sMethodName, stAppInfo);
        } finally {
            logger.debug("{}{}TSSS999 : elapsed={}ms response={}", sClassName, sMethodName,
                    (new Date().getTime() - tmsStartDate.getTime()), hmResult);
        }
        return hmResult;
    }

    /**
     * Unlinks all linked internet accounts (child members) from the fromSLID and re-links them
     * to the toSLID.
     *
     * <p>This method handles the two-phase linked-user transfer:</p>
     * <ol>
     *   <li><b>Unlink phase:</b> For each linked user on fromSLID, calls
     *       {@link UnlinkMemberIdHelper#unlinkMemberId(Map)} to dissociate them from the source SLID.
     *       The DBUS events generated by each unlink (excluding NotificationEvents) are captured into
     *       {@code alProcessDbus} for later publishing.</li>
     *   <li><b>Link phase:</b> For each previously unlinked user, calls
     *       {@link LinkMemberHelper#linkMember(Map)} to associate them with the target SLID.
     *       Again, DBUS events (excluding NotificationEvent and AddServicesList) are captured.</li>
     * </ol>
     *
     * <p><b>UVERSE sor_invariant_id capture:</b> If fromSLID has no TITAN account but has a
     * linked user that is a LightSpeed (LS) parent with a UVERSE service, the UVERSE
     * {@code sor_invariant_id} is captured and added to the {@code alNotificationEventAccountList}
     * so the EDD notification includes this account.</p>
     *
     * @param hmFromSlidGetInfoResponse Full getSLIDInfo response for fromSLID.
     * @param hmToSlidGetInfoResponse   Full getSLIDInfo response for toSLID.
     * @param hmInput                   Original merge request input (provides FROM_SLID, TO_SLID, AGENT_ID).
     * @return Success map on completion, or error map if any unlink/link call fails.
     */
    private HashMap unlinkAndLinkInternetAccount(HashMap<String, Object> hmFromSlidGetInfoResponse,
                                     HashMap<String, Object> hmToSlidGetInfoResponse, Map<String, Object> hmInput) {
        String sMethodName = "unlinkAndLinkInternetAccount";
        HashMap hmResult = new HashMap();
        String stAppInfo = null;
        String stAppStatusCode;
        String stUverse_sorInvariantId = null;
        ArrayList alLinkedUsersList = new ArrayList();
        String stAgentId = (String)hmInput.get(CommonDefs.AGENT_ID);
        logger.info("{}{}ULIA000 : unlinkAndLinkInternetAccount start linkedUsers={}", sClassName, sMethodName,
                (alFromSlidLinkedUsers != null ? alFromSlidLinkedUsers.size() : 0));
        try{
            //Start of unlinkInternetAccount for fromSLID
            ArrayList alLinkedUserMemberIds = new ArrayList();
            if(alFromSlidLinkedUsers != null && !alFromSlidLinkedUsers.isEmpty()){
                for(int i=0; i<alFromSlidLinkedUsers.size(); i++){
                    HashMap hmFromLinkedUser = (HashMap)alFromSlidLinkedUsers.get(i);
                    if(hmFromLinkedUser != null && !hmFromLinkedUser .isEmpty()){
                        HashMap temp = CommonUtil.getHashMap();
                        temp.put(CommonDefs.HANDLE, hmFromLinkedUser.get(MPSDefs.DB_MEMBER_NAME));
                        temp.put(CommonDefs.DOMAIN, hmFromLinkedUser.get(MPSDefs.DB_DOMAIN_NAME));

                        alLinkedUsersList.add(temp);
                        alLinkedUserMemberIds.add(hmFromLinkedUser.get(MPSDefs.DB_MEMBER_NUM));

                        //If fromSLID has no TITAN account then check the LinkedUser,
                        //is a LS Parent with UVERSE service, store the sor_invarinatId to send to notificationEvent.

                        String stLUDbSorName = (String)hmFromLinkedUser.get(MPSDefs.DB_SOR_NAME);
                        String stLUParentChildInd = (String)hmFromLinkedUser.get(MPSDefs.DB_PARENT_CHILD_IND);

                        if((stLUDbSorName != null && stLUDbSorName.equalsIgnoreCase(MPSDefs.SOR_LS)) && (
                                stLUParentChildInd != null && stLUParentChildInd.equalsIgnoreCase(MPSDefs.MPS_PARENT))){
                            HashMap hmLUServices = (HashMap)hmFromLinkedUser.get(CommonDefs.SERVICES);
                            if (hmLUServices != null
                                    && !hmLUServices.isEmpty()
                                    && hmLUServices
                                    .containsKey(CommonDefs.UVERSE_SERVICE)) {
                                HashMap hmTempUVERSE = (HashMap) hmLUServices
                                        .get(CommonDefs.UVERSE_SERVICE);
                                Iterator instanceIter = (Iterator) hmTempUVERSE
                                        .keySet().iterator();
                                while (instanceIter != null
                                        && instanceIter.hasNext()) {
                                    String key = (String) instanceIter.next();
                                    Object value = null;
                                    if (key != null)
                                        value = hmTempUVERSE.get(key);
                                    if (value != null && value instanceof HashMap) {

                                        HashMap hmTemp = (HashMap) value;

                                        if (hmTemp != null && !hmTemp.isEmpty()) {
                                            stUverse_sorInvariantId = (String)hmTemp.get(MPSDefs.DB_SOR_INVARIANT_ID);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                //If stUverse_sorInvariantId != null, add it to the notificationList
                //Constructing NotificationEvent: EDD notification will be send for the newly added accounts
                //and for the linked LS user, if any
                if((stUverse_sorInvariantId != null && stUverse_sorInvariantId.trim().length() > 0)){

                    HashMap hmUverseData = new HashMap();
                    hmUverseData.put(MPSDefs.DB_SOR_NAME, CommonDefs.SOR_LS);
                    hmUverseData.put(CommonDefs.SOR_INVARIANT_ID, stUverse_sorInvariantId);
                    hmUverseData.put(CommonDefs.ACCOUNT_TYPE, MPSDefs.UVERSE_SERVICE);

                    alNotificationEventAccountList.add(hmUverseData);
                    logger.info("{}{}NTF_ACCT_UVERSE : Added UVERSE account to alNotificationEventAccountList, sorInvariantId={}",
                            sClassName, sMethodName, stUverse_sorInvariantId);
                }

                if(alLinkedUsersList!= null && !alLinkedUsersList.isEmpty()){
                    HashMap hmInputToUnlinkAccount = new HashMap();
                    hmInputToUnlinkAccount.put(CommonDefs.SLID, hmInput.get(CommonDefs.FROM_USERNAME));
                    hmInputToUnlinkAccount.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
                    hmInputToUnlinkAccount.put(CommonDefs.TRANSACTION_ID, stTransactionId);
                    hmInputToUnlinkAccount.put(CommonDefs.CALLMPS, MPSDefs.YES);
                    hmInputToUnlinkAccount.put(CommonDefs.CALLDBUS, MPSDefs.NO);
                    hmInputToUnlinkAccount.put(CommonDefs.TRANSACTION_NAME, "UnlinkInternetAccount");
                    hmInputToUnlinkAccount.put(CommonDefs.ORIG_TRANSACTION_NAME,hmInput.get(CommonDefs.TRANSACTION_NAME));
                    hmInputToUnlinkAccount.put(CommonDefs.RES2BUS, MPSDefs.YES);
                    hmInputToUnlinkAccount.put(CommonDefs.INTERNET_ID_LIST, alLinkedUsersList);
                    hmInputToUnlinkAccount.put(CommonDefs.FLAG_IGNORE_LIFECYCLEPUBLISHING, MPSDefs.YES);
                    hmInputToUnlinkAccount.put("autoSLIDCreation", MPSDefs.NO);
                    if(stAgentId != null && stAgentId.trim().length() > 0){
                        hmInputToUnlinkAccount.put(CommonDefs.AGENT_ID, stAgentId);
                    }

                    logger.info("{}{}ULIA001 : Unlinking {} linked user(s) from fromSLID", sClassName, sMethodName,
                            alLinkedUsersList.size());
                    logger.debug("{}{}ULIA001 : unlink inputHash={}", sClassName, sMethodName, hmInputToUnlinkAccount);

                    for (int u = 0; u < alLinkedUsersList.size(); u++) {
                        HashMap tempUnlink = (HashMap) alLinkedUsersList.get(u);
                        if (tempUnlink != null && !tempUnlink.isEmpty()) {
                            HashMap hmPerUserUnlink = CommonUtil.getHashMap();
                            hmPerUserUnlink.putAll(hmInputToUnlinkAccount);
                            hmPerUserUnlink.put("accessId", hmInputToUnlinkAccount.get(CommonDefs.SLID));
                            hmPerUserUnlink.put("memberId", tempUnlink.get(CommonDefs.HANDLE));
                            hmPerUserUnlink.put(CommonDefs.HANDLE, tempUnlink.get(CommonDefs.HANDLE));
                            hmPerUserUnlink.put(CommonDefs.DOMAIN, tempUnlink.get(CommonDefs.DOMAIN));

                            hmResult = (HashMap) unlinkMemberIdHelper.unlinkMemberId(hmPerUserUnlink);

                            logger.info("{}{}ULIA002 : Unlinked member={} status={}", sClassName, sMethodName,
                                    tempUnlink.get(CommonDefs.HANDLE),
                                    hmResult != null ? hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE) : null);
                            logger.debug("{}{}ULIA002 : unlink response={}", sClassName, sMethodName, hmResult);

                            if (hmResult == null) {
                                stAppInfo = "Null Response returned from UnlinkMemberIdHelper";
                                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                                logger.error("{}{}ULIA003 : {} ", sClassName, sMethodName, stAppInfo);
                                return hmResult;
                            }
                            stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                            if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                                stAppInfo = "Error returned from UnlinkMemberIdHelper";
                                logger.error("{}{}ULIA004 : {}", sClassName, sMethodName, stAppInfo);
                                return hmResult;
                            }

                            if (hmResult.containsKey(CommonDefs.CONSOLIDATED_DBUS_INPUT)) {
                                ArrayList alTemp = (ArrayList) hmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT);
                                for (int c = 0; c < alTemp.size(); c++) {
                                    HashMap hmTemp = (HashMap) alTemp.get(c);
                                    if (hmTemp != null && !hmTemp.isEmpty()) {
                                        String stDbusEvent = (String) hmTemp.get(CommonDefs.EVENTNAME);
                                        if (stDbusEvent != null &&
                                                !stDbusEvent.equalsIgnoreCase("NotificationEvent")) {
                                            hmTemp.put("hash_key", stFromSlidMemberNum);
                                            alProcessDbus.add(hmTemp);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Phase 2: Re-link each internet account to toSLID.
            // Each linked user that was unlinked from fromSLID is now linked to the toSLID.
            if(alLinkedUsersList!= null && !alLinkedUsersList.isEmpty()){
                for (int i=0; i<alLinkedUsersList.size(); i++){
                    HashMap tempLink = (HashMap)alLinkedUsersList.get(i);
                    if(tempLink != null && !tempLink.isEmpty()){
                        HashMap hmInputToLinkAccount = CommonUtil.getHashMap();
                        hmInputToLinkAccount.put(CommonDefs.SLID, hmInput.get(CommonDefs.TO_USERNAME));
                        hmInputToLinkAccount.put(CommonDefs.HANDLE, tempLink.get(CommonDefs.HANDLE));
                        hmInputToLinkAccount.put(CommonDefs.DOMAIN, tempLink.get(CommonDefs.DOMAIN));
                        hmInputToLinkAccount.put(CommonDefs.TRANSACTION_NAME,
                                CommonDefs.TRANS_NAME_LINK_INTERNET_ACCOUNT);
                        hmInputToLinkAccount.put(CommonDefs.ORIG_TRANSACTION_NAME,
                                hmInput.get(CommonDefs.TRANSACTION_NAME));
                        hmInputToLinkAccount.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
                        hmInputToLinkAccount.put(CommonDefs.TRANSACTION_ID, stTransactionId);
                        hmInputToLinkAccount.put(CommonDefs.CALLMPS, MPSDefs.YES);
                        hmInputToLinkAccount.put(CommonDefs.CALLDBUS, CommonDefs.IND_N);
                        hmInputToLinkAccount.put(CommonDefs.IGNORE_PROFILE_UPDATE, MPSDefs.NO);
                        hmInputToLinkAccount.put(CommonDefs.FLAG_IGNORE_LIFECYCLEPUBLISHING, MPSDefs.YES);

                        if(stAgentId != null && stAgentId.trim().length() > 0){
                            hmInputToLinkAccount.put(CommonDefs.AGENT_ID, stAgentId);
                        }

                        logger.info("{}{}ULIA005 : Linking member={} to toSLID", sClassName, sMethodName,
                                tempLink.get(CommonDefs.HANDLE));
                        logger.debug("{}{}ULIA005 : link inputHash={}", sClassName, sMethodName, hmInputToLinkAccount);

                        hmInputToLinkAccount.put(CommonDefs.ACCESS_ID, hmInput.get(CommonDefs.TO_USERNAME));
                        hmInputToLinkAccount.put(CommonDefs.MEMBERID, tempLink.get(CommonDefs.HANDLE));
                        hmInputToLinkAccount.put(ProfileOrchestrationConstants.IDPTRACEID, stTransactionId);
                        hmInputToLinkAccount.put(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID,
                                stTransactionId != null ? stTransactionId.split(":")[0] : null);
                        hmResult = (HashMap) linkMemberHelper.linkMember(hmInputToLinkAccount);
                        logger.info("{}{}ULIA006 : Linked member={} status={}", sClassName, sMethodName,
                                tempLink.get(CommonDefs.HANDLE),
                                hmResult != null ? hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE) : null);
                        logger.debug("{}{}ULIA006 : link response={}", sClassName, sMethodName, hmResult);

                        if (hmResult == null) {
                            stAppInfo = "Null Response returned from LinkInternetAccountHelper()";
                            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                            logger.error("{}{}ULIA007 {} " , sClassName , sMethodName, stAppInfo);
                            return hmResult;
                        }
                        stAppStatusCode = (String) hmResult
                                .get(CErrorDefs.COMMON_APP_STATUS_CODE);
                        if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                            stAppInfo = "Error returned After calling LinkInternetAccountHelper()";
                            logger.error("{}{}ULIA008 : {}", sClassName, sMethodName, stAppInfo);
                            return hmResult;
                        }

                        if(hmResult.containsKey(CommonDefs.CONSOLIDATED_DBUS_INPUT)){
                            ArrayList alTemp = (ArrayList) hmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT);
                            for(int c=0; c<alTemp.size(); c++){
                                HashMap hmTemp = (HashMap)alTemp.get(c);
                                if(hmTemp != null && !hmTemp.isEmpty()){
                                    String stDbusEvent = (String)hmTemp.get(CommonDefs.EVENTNAME);
                                    if(stDbusEvent != null &&
                                            !stDbusEvent.equalsIgnoreCase("NotificationEvent") &&
                                            !stDbusEvent.equalsIgnoreCase(CommonDefs.ADD_SERVICES_LIST_EVENT)){
                                        hmTemp.put("hash_key", stFromSlidMemberNum);
                                        alProcessDbus.add(hmTemp);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            hmResult = CommonErrorMap.makeCategoryMap(
                    CommonDefs.COMMON_SUCCESS_NUM,
                    CommonDefs.COMMON_SUCCESS_MSG);

        } catch (Exception e) {
            stAppInfo = "Exception :" + e.getMessage();
            hmResult = CommonErrorMap.makeExceptionMap(e);
            logger.error("{}{}ULIA001 : {}", sClassName, sMethodName, stAppInfo );
        }
        return hmResult;
    }

    /**
     * Scans all toSLID accounts (ECOMM, MOBILITY, TITAN) to determine whether the target SLID
     * already has a <b>default account</b> and/or a <b>CPNI-impacted account</b>.
     *
     * <p>These two flags drive downstream behaviour:</p>
     * <ul>
     *   <li>{@code toSLIDDefaultAccountExist} — if {@code true}, accounts transferred from fromSLID
     *       will have their {@code DEFAULT_ACCOUNT} field set to {@code "N"} to avoid creating
     *       a second default on the SLID.</li>
     *   <li>{@code isCPNILinkedToSLID} — if {@code true}, the EDD notification event includes
     *       CPNI-specific data; if {@code false}, the notification falls back to contact-email data.</li>
     * </ul>
     *
     * <p>The scan stops early (breaks) once both flags are set to {@code true}.</p>
     *
     * @return Success map (always succeeds; sets instance-level boolean flags as a side effect).
     */
    private Map<String, Object>  checkDefaultAccountToSlid() {

        String sMethodName = "checkDefaultAccountToSlid";
        String stDAsorInvariantId = null;
        String stDAServiceName = null;
        HashMap hmResult = null;

        if (alToSlidECOMM != null && !alToSlidECOMM.isEmpty()) {
            for (int i = 0; i < alToSlidECOMM.size(); i++) {
                HashMap hmToSlidECOMM = (HashMap) alToSlidECOMM.get(i);
                if (hmToSlidECOMM != null && !hmToSlidECOMM.isEmpty()) {
                    String stDefaultAccount = (String) hmToSlidECOMM.get(MPSDefs.DB_DEFAULT_ACCOUNT);
                    String stCPNIImpacted = (String) hmToSlidECOMM.get(MPSDefs.DB_CPNI_IMPACTED);
                    stDAsorInvariantId = (String)hmToSlidECOMM.get(MPSDefs.DB_SOR_INVARIANT_ID);
                    stDAServiceName = (String)hmToSlidECOMM.get(MPSDefs.DB_SERVICE_NAME);

                    if (stDefaultAccount != null && stDefaultAccount.trim().length() > 0
                            && stDefaultAccount.equalsIgnoreCase(MPSDefs.YES)){
                        toSLIDDefaultAccountExist = true;
                        logger.info("{}{}CDA000 : DefaultAccount ServiceName = {}  DefaultAccount SorInvarinatId = {}"
                                , sClassName, sMethodName, stDAServiceName, stDAsorInvariantId);
                    }

                    if (stCPNIImpacted != null && stCPNIImpacted.trim().length() > 0
                            && stCPNIImpacted.equalsIgnoreCase(MPSDefs.YES)){
                        isCPNILinkedToSLID = true;
                        logger.info("{}{}CDA001 :CPNIImpactedAccount ServiceName= {} CPNIImpactedAccount SorInvarinatId" +
                                " = {}", sClassName, sMethodName, stDAServiceName, stDAsorInvariantId);
                    }
                    if (toSLIDDefaultAccountExist && isCPNILinkedToSLID)
                        break;
                }
            }
        }

        if (alToSlidMOBILITY != null && !alToSlidMOBILITY.isEmpty()
                && (!toSLIDDefaultAccountExist || !isCPNILinkedToSLID)) {
            for (int i = 0; i < alToSlidMOBILITY.size(); i++) {
                HashMap hmToSlidMOBILITY = (HashMap) alToSlidMOBILITY.get(i);
                if (hmToSlidMOBILITY != null && !hmToSlidMOBILITY.isEmpty()) {
                    String stDefaultAccount = (String) hmToSlidMOBILITY
                            .get(MPSDefs.DB_DEFAULT_ACCOUNT);
                    String stCPNIImpacted = (String) hmToSlidMOBILITY
                            .get(MPSDefs.DB_CPNI_IMPACTED);
                    stDAsorInvariantId = (String)hmToSlidMOBILITY.get(MPSDefs.DB_SOR_INVARIANT_ID);
                    stDAServiceName = (String)hmToSlidMOBILITY.get(MPSDefs.DB_SERVICE_NAME);
                    if (stDefaultAccount != null
                            && stDefaultAccount.trim().length() > 0
                            && stDefaultAccount.equalsIgnoreCase(MPSDefs.YES)){
                        toSLIDDefaultAccountExist = true;
                        logger.info("{}{}CDA002 : DefaultAccount ServiceName = {}  DefaultAccount SorInvarinatId = {}"
                                , sClassName, sMethodName, stDAServiceName, stDAsorInvariantId);
                    }
                    if (stCPNIImpacted != null
                            && stCPNIImpacted.trim().length() > 0
                            && stCPNIImpacted.equalsIgnoreCase(MPSDefs.YES)){
                        isCPNILinkedToSLID = true;
                        logger.info("{}{}CDA003 :CPNIImpactedAccount ServiceName= {} CPNIImpactedAccount SorInvarinatId" +
                                        " = {}" , sClassName, sMethodName, stDAServiceName, stDAsorInvariantId);
                    }
                    if (toSLIDDefaultAccountExist && isCPNILinkedToSLID)
                        break;
                }
            }
        }

        if (alToSlidTITAN != null && !alToSlidTITAN.isEmpty()
                && (!toSLIDDefaultAccountExist || !isCPNILinkedToSLID)) {
            for (int i = 0; i < alToSlidTITAN.size(); i++) {
                HashMap hmToSlidTITAN = (HashMap) alToSlidTITAN.get(i);
                if (hmToSlidTITAN != null && !hmToSlidTITAN.isEmpty()) {
                    String stDefaultAccount = (String) hmToSlidTITAN
                            .get(MPSDefs.DB_DEFAULT_ACCOUNT);
                    String stCPNIImpacted = (String) hmToSlidTITAN
                            .get(MPSDefs.DB_CPNI_IMPACTED);
                    stDAsorInvariantId = (String)hmToSlidTITAN.get(MPSDefs.DB_SOR_INVARIANT_ID);
                    stDAServiceName = (String)hmToSlidTITAN.get(MPSDefs.DB_SERVICE_NAME);
                    if (stDefaultAccount != null
                            && stDefaultAccount.trim().length() > 0
                            && stDefaultAccount.equalsIgnoreCase(MPSDefs.YES)){
                        toSLIDDefaultAccountExist = true;
                        logger.info("{}{}CDA004 : DefaultAccount ServiceName = {}  DefaultAccount SorInvarinatId = {}"
                                , sClassName, sMethodName, stDAServiceName, stDAsorInvariantId);
                    }
                    if (stCPNIImpacted != null
                            && stCPNIImpacted.trim().length() > 0
                            && stCPNIImpacted.equalsIgnoreCase(MPSDefs.YES)){
                        isCPNILinkedToSLID = true;
                        logger.info("{}{}CDA005 : CPNIImpactedAccount ServiceName = {}  CPNIImpactedAccount SorInvarinatId = {}"
                                , sClassName, sMethodName, stDAServiceName, stDAsorInvariantId);
                    }
                    if (toSLIDDefaultAccountExist && isCPNILinkedToSLID)
                        break;
                }
            }
        }

        hmResult = CommonErrorMap.makeCategoryMap(
                CommonDefs.COMMON_SUCCESS_NUM,
                CommonDefs.COMMON_SUCCESS_MSG);
        return hmResult;
    }

    /**
     * Determines which dynamic services from fromSLID are eligible to be transferred to toSLID.
     *
     * <p>For each dynamic service on fromSLID, the method looks up its metadata via
     * {@link #getServiceDataById(String)} and applies the following rules:</p>
     *
     * <table border="1">
     *   <tr><th>merge_action</th><th>single_instance</th><th>Behaviour</th></tr>
     *   <tr><td>{@code null} / empty / "Keep All"</td><td>{@code "Y"}</td>
     *       <td>Match by {@code SERVICE_NAME}: if same name exists on toSLID with same
     *           {@code SOR_INVARIANT_ID} → skip (already present). If same name but
     *           <i>different</i> {@code SOR_INVARIANT_ID} → <b>reject merge</b>
     *           ({@code ERR_CANNOT_OPERATE_ON_SERVICE}).</td></tr>
     *   <tr><td>{@code null} / empty / "Keep All"</td><td>{@code "N"} (multi-instance)</td>
     *       <td>Match by all three: {@code SOR_INVARIANT_ID} + {@code SERVICE_NAME} +
     *           {@code SERVICE_ID}. If exact match → skip; else add.</td></tr>
     *   <tr><td>"Non-Transferable"</td><td>any</td>
     *       <td>Service is not moved — skip silently.</td></tr>
     * </table>
     *
     * <p>Services that pass the checks are added to the returned {@code "AddDynamicServices"} list.
     * Their access-groups (if not already on toSLID) are recorded in {@code hmDynAccessGroupToBeAdded}
     * for later DBUS notification.</p>
     *
     * @param alFromSlidDYNAMIC fromSLID dynamic service instances.
     * @param alToSlidDYNAMIC   toSLID dynamic service instances (may be null/empty).
     * @return Map containing {@code "AddDynamicServices"} list on success, or error map on conflict.
     */
    private HashMap processDynamicServices(ArrayList alFromSlidDYNAMIC, ArrayList alToSlidDYNAMIC) {
        String sMethodName = "processDynamicServices";
        HashMap hmResponse = new HashMap();
        ArrayList alAddDynamicServices = new ArrayList();

        String stAppInfo = null;
        String sAppStatusCode = null;
        logger.info("{}{}PDS001 : processDynamicServices start fromCount={} toCount={}", sClassName, sMethodName,
                (alFromSlidDYNAMIC != null ? alFromSlidDYNAMIC.size() : 0),
                (alToSlidDYNAMIC != null ? alToSlidDYNAMIC.size() : 0));
        logger.debug("{}{}PDS001 : alFromSlidDYNAMIC={} alToSlidDYNAMIC={}", sClassName, sMethodName,
                alFromSlidDYNAMIC, alToSlidDYNAMIC);
        try{
            if(alFromSlidDYNAMIC != null && !alFromSlidDYNAMIC.isEmpty()){
                for (Object fromSLIDDynamic : alFromSlidDYNAMIC) {
                    HashMap hmTempfromSlidDyn = (HashMap) fromSLIDDynamic;
                    if (hmTempfromSlidDyn != null && !hmTempfromSlidDyn.isEmpty()) {
                        boolean isMatchFound = false;
                        String stFromSlidSorInvariantId = (String) hmTempfromSlidDyn.get(MPSDefs.DB_SOR_INVARIANT_ID);
                        String stFromSlidServiceId = (String) hmTempfromSlidDyn.get(MPSDefs.DB_SERVICE_ID);
                        String stFromSlidServiceName = (String) hmTempfromSlidDyn.get(MPSDefs.DB_SERVICE_NAME);

                        HashMap hmDynamicServiceData = getServiceDataById(stFromSlidServiceId);

                        if (hmDynamicServiceData != null && !hmDynamicServiceData.isEmpty()) {
                            String sSingleInstance = (String) hmDynamicServiceData.get(MPSDefs.DB_SINGLE_INSTANCE);
                            String sMergeAction = (String) hmDynamicServiceData.get("merge_action");
                            if (sMergeAction == null || sMergeAction.isEmpty() ||
                                    "Keep All".equalsIgnoreCase(sMergeAction.trim())) {
                                if (alToSlidDYNAMIC != null && !alToSlidDYNAMIC.isEmpty()) {
                                    for (Object toSLIDDynamic : alToSlidDYNAMIC) {
                                        HashMap hmTempToSlidDyn = (HashMap) toSLIDDynamic;
                                        if (hmTempToSlidDyn != null && !hmTempToSlidDyn.isEmpty()) {
                                            String stToSlidSorInvariantId = (String)
                                                    hmTempToSlidDyn.get(MPSDefs.DB_SOR_INVARIANT_ID);
                                            String stToSlidServiceId = (String)
                                                    hmTempToSlidDyn.get(MPSDefs.DB_SERVICE_ID);
                                            String stToSlidServiceName = (String)
                                                    hmTempToSlidDyn.get(MPSDefs.DB_SERVICE_NAME);
                                            if ("Y".equalsIgnoreCase(sSingleInstance)) {
                                                // Single-instance service: only one instance per service name allowed.
                                                // Match by SERVICE_NAME only; then verify SOR_INVARIANT_ID parity.
                                                if ((stToSlidServiceName != null && !stToSlidServiceName.trim().isEmpty()) &&
                                                        stToSlidServiceName.equalsIgnoreCase(stFromSlidServiceName)) {
                                                    if (stToSlidSorInvariantId != null && stToSlidSorInvariantId.
                                                            equalsIgnoreCase(stFromSlidSorInvariantId)) {
                                                        // Same service + same SOR invariant = already present on toSLID, skip.
                                                        isMatchFound = true;
                                                        break;
                                                    } else { //Disallow Merging of SLIDs when fromSLID and toSLID has same dynamic service but different sor_invariant_id
                                                        stAppInfo = "A " + stFromSlidServiceName +
                                                                " service exists on fromSlid as well as toSlid " +
                                                                "with different sorInvariantId and cannot be merged";
                                                        logger.info("{}{}PDS002 : {}", sClassName, sMethodName, stAppInfo);
                                                        hmResponse = CommonErrorMap.makeCategoryMap
                                                                (CErrorDefs.ERR_CANNOT_OPERATE_ON_SERVICE_NUM, stAppInfo);
                                                        return hmResponse;
                                                    }
                                                }
                                            } else {
                                                // Multi-instance service: multiple instances per service name allowed.
                                                // Match requires all three identifiers to be equal.
                                                if (((stToSlidSorInvariantId != null && !stToSlidSorInvariantId.trim().isEmpty())
                                                        && stToSlidSorInvariantId.equalsIgnoreCase(stFromSlidSorInvariantId))
                                                        && ((stToSlidServiceName != null && !stToSlidServiceName.trim().isEmpty())
                                                        && stToSlidServiceName.equalsIgnoreCase(stFromSlidServiceName))
                                                        && ((stToSlidServiceId != null && !stToSlidServiceId.trim().isEmpty())
                                                        && stToSlidServiceId.equalsIgnoreCase(stFromSlidServiceId))) {
                                                    isMatchFound = true;
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            if (sMergeAction != null && !sMergeAction.isEmpty() && "Non-Transferable".
                                    equalsIgnoreCase(sMergeAction.trim())) {
                                continue;
                            }
                        }
                        if (!isMatchFound) {
                            // No matching dynamic service found on toSLID — this service will be transferred.
                            // If its access-group is not already present on toSLID (and not already queued),
                            // record it in hmDynAccessGroupToBeAdded so the DBUS AddServicesList event
                            // includes the new access-group for tGuard provisioning.
                            String sDynamicServiceId = (String) hmTempfromSlidDyn.get(MPSDefs.DB_SERVICE_ID);
                            if (hmDynamicServiceData != null && !hmDynamicServiceData.isEmpty()) {
                                String sAccessGroup = (String) hmDynamicServiceData.get(MPSDefs.DB_ACCESS_GROUP);
                                if (sAccessGroup != null && alToSlidDynAccessGroup != null &&
                                        !alToSlidDynAccessGroup.contains(sAccessGroup)
                                        && !hmDynAccessGroupToBeAdded.containsKey(sAccessGroup)) {
                                    hmDynAccessGroupToBeAdded.put(sAccessGroup, (String)
                                            hmTempfromSlidDyn.get(MPSDefs.DB_SOR_NAME));
                                }
                            }
                            alAddDynamicServices.add(hmTempfromSlidDyn);
                        }
                    }
                }
            }
            logger.debug("{}{}PDS002 : alAddDynamicServices : {}", sClassName, sMethodName, alAddDynamicServices );
            logger.debug("{}{}PDS003 : hmDynAccessGroupToBeAdded : {}", sClassName, sMethodName, hmDynAccessGroupToBeAdded );

            hmResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,CommonDefs.COMMON_SUCCESS_MSG);
            hmResponse.put("AddDynamicServices", alAddDynamicServices);

        } catch (Exception excp) {
            stAppInfo = "Exception :" + excp.getMessage();
            hmResponse = CommonErrorMap.makeExceptionMap(excp);
            logger.error("{}{}PDS004 : {}", sClassName, sMethodName, stAppInfo );
        }
        return hmResponse;
    }

    /**
     * Inserts MOSUB and dynamic services onto the target SLID in the database.
     *
     * <p>This method handles two categories of service additions:</p>
     * <ol>
     *   <li><b>MOSUB services:</b> If fromSLID has MOSUB services and toSLID does not,
     *       all fromSLID MOSUB services are added to {@code alAddServiceList}.</li>
     *   <li><b>Dynamic services:</b> Already collected in {@code alAddServiceList} by
     *       {@link #processDynamicServices(ArrayList, ArrayList)} in step 14 of the merge pipeline.</li>
     * </ol>
     *
     * <p>For each service, a new HashMap is constructed with the target SLID’s member/group numbers
     * and the service’s metadata, then passed to {@link AddServiceDBHelper#addService(HashMap)}.
     * MOSUB and dynamic services carry additional {@code SOR_INVARIANT_ID} and {@code INSTANCE_ID}
     * fields.</p>
     *
     * @param hmToSlidInfo The toSLID member info map (used for group/member context).
     * @return Success map on completion, or error map if any DB insert fails.
     */
    private Map<String, Object> dbServicesUpdates(Map<String, Object> hmToSlidInfo) {
        String sMethodName = "dbServicesUpdates";
        String stAppInfo = null;
        Date tmsStartDate = new Date();
        HashMap hmResult = null;

        logger.info("{}{}DSU000 : dbServicesUpdates start serviceCount={}", sClassName, sMethodName,
                (alAddServiceList != null ? alAddServiceList.size() : 0));

        try {
            if((alFromSlidMOSUB != null && !alFromSlidMOSUB.isEmpty()) &&
                    (alToSlidMOSUB == null || alToSlidMOSUB.isEmpty())){
                for (Object o : alFromSlidMOSUB) {
                    HashMap hmFromSlidMosub = (HashMap) o;
                    if (hmFromSlidMosub != null && !hmFromSlidMosub.isEmpty()) {
                        alAddServiceList.add(hmFromSlidMosub);
                    }
                }
            }

            if(alAddServiceList !=null && !alAddServiceList.isEmpty()){
                for (Object o : alAddServiceList) {
                    HashMap<String, Object> hmService = new HashMap<>();
                    HashMap hmTempService = (HashMap) o;
                    String stDBServiceName = (String) hmTempService.get(MPSDefs.DB_SERVICE_NAME);
                    String stProcessDynamic = (String) hmTempService.get("ProcessDynamic");
                    hmService.put(MPSDefs.DB_GROUP_NUM, stToSlidGroupNum);
                    hmService.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
                    hmService.put(MPSDefs.DB_SERVICE_NAME, stDBServiceName);
                    hmService.put(MPSDefs.DB_MEMBER_STATUS_NAME, hmTempService.get(MPSDefs.DB_MEMBER_STATUS_NAME));
                    hmService.put(MPSDefs.DB_GROUP_STATUS_NAME, MPSDefs.ENABLED);
                    hmService.put(MPSDefs.DB_SOR_NAME, hmTempService.get(MPSDefs.DB_SOR_NAME));
                    hmService.put(MPSDefs.DB_LAST_MODIFIED_BY, stCallingSystemId);

                    if ((stDBServiceName != null && (stDBServiceName.equalsIgnoreCase(MPSDefs.MOSUB_SERVICE)))
                            || (stProcessDynamic != null && stProcessDynamic.equals("Y"))) {
                        String stDbSorInvariantId = (String) hmTempService.get(MPSDefs.DB_SOR_INVARIANT_ID);
                        String stDbInstanceId = (String) hmTempService.get(MPSDefs.DB_INSTANCE_ID);
                        if (stDbSorInvariantId != null) {
                            hmService.put(MPSDefs.DB_SOR_INVARIANT_ID, stDbSorInvariantId);
                        }
                        if (stDbInstanceId != null) {
                            hmService.put(MPSDefs.DB_INSTANCE_ID, stDbInstanceId);
                        }
                    }

                    logger.debug("{}{}DSU001: Calling AddServiceDBHelper.addService with Input: {}", sClassName,
                            sMethodName,hmService);
                    hmResult = oaddServiceDBHelper.addService(hmService);
                    logger.debug("{}{}DSU002: Response from  AddServiceDBHelper.addService : {}", sClassName,
                            sMethodName,hmResult);

                    // No LDAP/G2 sync required for MergeUserAccessId
                }
            } else {
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
                hmResult.put(MPSDefs.APP_STATUS_CODE, hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE));
            }
        } catch (Exception e) {
            stAppInfo = "Exception thrown in dbServicesUpdates() method::" + e.getMessage();
            hmResult = CommonErrorMap.makeExceptionMap(e);
            logger.error("{}{}DSU004 : {} " , sClassName , sMethodName, stAppInfo);
        } finally {
            if (!isMapNullOrEmpty(hmResult) && !hmResult.containsKey(MPSDefs.APP_STATUS_CODE)) {
                hmResult.put(MPSDefs.APP_STATUS_CODE, hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE));
            }
            logger.debug("{}{}DSU999 : elapsed={}ms response={}", sClassName, sMethodName,
                    (new Date().getTime() - tmsStartDate.getTime()), hmResult);
        }
        return hmResult;
    }


    /**
     * Inserts account-level data (services, roles, service attributes, wireline users)
     * for all accounts being transferred from fromSLID to toSLID.
     *
     * <p>This method iterates over {@code alAddToSlidAccounts} (populated by
     * {@link #prepareAccountsHashMap()}) and performs four sequential DB operations
     * per account:</p>
     * <ol>
     *   <li><b>Services</b> — Calls {@link AddServiceDBHelper#addService(HashMap)} for each
     *       member-service entry (ECOMM, MOBILITY, DTV, TITAN).</li>
     *   <li><b>Roles</b> — Calls {@link RolesDBHelper#addRoles(HashMap)} for each role
     *       associated with the new service.</li>
     *   <li><b>Service Attributes</b> — Calls
     *       {@link MemberServiceAttributeDBHelper#addMemberServiceAttribute(HashMap)}
     *       for MOBILITY-specific attributes (e.g. account type, prepaid indicator).</li>
     *   <li><b>Wireline Users</b> — Calls
     *       {@link UpdateAssociationDBHelper#addWirelineUser(HashMap)} for ECOMM
     *       wireline passcode data.</li>
     * </ol>
     *
     * <p>If any individual DB call fails, the method returns the error map immediately,
     * halting further processing.</p>
     *
     * @return Success map on completion, or error map on first DB failure.
     */
    private Map<String, Object> dbAccountsUpdates() {
        String sMethodName = "dbAccountsUpdates";
        String stAppInfo = null;
        Date tmsStartDate = new Date();
        HashMap hmResult = null;
        String stAppStatusCode;

        try {
            ArrayList<HashMap<String, Object>> alAddServices = new ArrayList<HashMap<String, Object>>();
            ArrayList<HashMap<String, Object>> alAddRoles = new ArrayList<HashMap<String, Object>>();
            ArrayList<HashMap<String, Object>> alALLServiceAttributes = new ArrayList<HashMap<String, Object>>();

            for (Object obj : alAddToSlidAccounts) {
                HashMap<String, Object> hmInputAccount = (HashMap<String, Object>) obj;
                if (hmInputAccount != null && !hmInputAccount.isEmpty()) {
                    ArrayList<HashMap<String, Object>> alMemberServices = (ArrayList) hmInputAccount
                            .get(CommonDefs.KEY_MEMBER_SERVICES);
                    if (alMemberServices != null && !alMemberServices.isEmpty()) {
                        for (HashMap<String, Object> hmMemberService : alMemberServices) {
                            if (hmMemberService != null && !hmMemberService.isEmpty()) {
                                alAddServices.add(hmMemberService);
                            }
                        }
                    }
                    ArrayList<HashMap<String, Object>> alRoles = (ArrayList) hmInputAccount
                            .get(CommonDefs.KEY_SERVICE_ROLES);
                    if (alRoles != null && !alRoles.isEmpty()) {
                        for (HashMap<String, Object> hmRoles : alRoles) {
                            if (hmRoles != null && !hmRoles.isEmpty()) {
                                alAddRoles.add(hmRoles);
                            }
                        }
                    }
                    ArrayList<HashMap<String, Object>> alServiceAttributes = (ArrayList) hmInputAccount
                            .get(MPSDefs.DB_MEMBER_SERVICE_ATTRIBUTE);
                    if (alServiceAttributes != null && !alServiceAttributes.isEmpty()) {
                        alALLServiceAttributes.addAll(alServiceAttributes);
                    }

                    ArrayList<HashMap<String, Object>> alWireline = (ArrayList) hmInputAccount.get("wireline");
                    if (alWireline != null && !alWireline.isEmpty()) {
                        for (HashMap<String, Object> hmWireline : alWireline) {
                            if (hmWireline != null && !hmWireline.isEmpty()) {
                                HashMap<String, Object> hmWirelineInsert = new HashMap<>();
                                hmWirelineInsert.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
                                hmWirelineInsert.put(MPSDefs.DB_SERVICE_ID, hmWireline.get(MPSDefs.DB_SERVICE_ID));
                                hmWirelineInsert.put(MPSDefs.DB_SOR_ID, hmWireline.get(MPSDefs.DB_SOR_ID));
                                hmWirelineInsert.put(MPSDefs.DB_SOR_INVARIANT_ID, hmWireline.get(MPSDefs.DB_SOR_INVARIANT_ID));
                                hmWirelineInsert.put(MPSDefs.DB_PASSCODE, hmWireline.get(MPSDefs.DB_PASSCODE));
                                hmWirelineInsert.put(MPSDefs.DB_PASSCODE_VENC, hmWireline.get(MPSDefs.DB_PASSCODE_VENC));
                                hmWirelineInsert.put(MPSDefs.DB_LAST_MODIFIED_BY, stCallingSystemId);
                                hmWirelineInsert.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);

                                HashMap hmResultWireline = updateAssociationDBHelper.addWirelineUser(hmWirelineInsert);
                                String stAppStatusCodeWire = hmResultWireline != null ? (String) hmResultWireline.get(CommonDefs.COMMON_APP_STATUS_CODE) : null;
                                if (hmResultWireline == null || stAppStatusCodeWire == null || !CommonDefs.COMMON_SUCCESS.equals(stAppStatusCodeWire)) {
                                    logger.error("{}{}DAU_WIRELINE : Error inserting wireline user: {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmResultWireline)));

                                    if (hmResultWireline == null || hmResultWireline.get(CommonDefs.COMMON_APP_STATUS_CODE) == null) {
                                        stAppInfo = "Error inserting wireline user";
                                        hmResultWireline = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                                    }

                                    return hmResultWireline;
                                }
                            }
                        }
                    }
                }
            }

            //for each of the entries in alAddServices call the addService method
            for(HashMap<String, Object> o : alAddServices){
                HashMap<String, Object> hmService = new HashMap<>();
                HashMap hmTempService = (HashMap) o;
                hmService.put(MPSDefs.DB_GROUP_NUM, stToSlidGroupNum);
                hmService.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
                hmService.put(MPSDefs.DB_SERVICE_NAME, hmTempService.get("serviceType"));
                hmService.put(MPSDefs.DB_MEMBER_STATUS_NAME, hmTempService.get("serviceStatus"));
                hmService.put(MPSDefs.DB_GROUP_STATUS_NAME, hmTempService.get("wsGroupStatusName"));
                hmService.put(MPSDefs.DB_SOR_NAME, hmTempService.get("sorName"));
                hmService.put(MPSDefs.DB_LAST_MODIFIED_BY, stCallingSystemId);
                hmService.put(MPSDefs.DB_SOR_INVARIANT_ID, hmTempService.get("sorInvariantId"));
                hmService.put(MPSDefs.DB_INSTANCE_ID, hmTempService.get("instance_id"));
                hmService.put(MPSDefs.DB_DEFAULT_ACCOUNT, hmTempService.get("defaultAccount"));
                hmService.put(MPSDefs.DB_NICKNAME, hmTempService.get("nickname"));
                hmService.put(MPSDefs.DB_CPNI_IMPACTED, hmTempService.get("cpniImpacted"));
                hmService.put(MPSDefs.DB_OWNED_BY, hmTempService.get("ownedBy"));
                hmService.put(MPSDefs.DB_PARENT_SOR_ID, hmTempService.get("parent_sor_id"));
                hmService.put(MPSDefs.DB_PARENT_SOR_INVARIANT_ID, hmTempService.get("parent_sor_invariant_id"));
                logger.debug("{}{}DAU001 : Calling addServiceDBHelper.addService() with inputHash = {}" , sClassName , sMethodName, hmService);
                hmResult = oaddServiceDBHelper.addService(hmService);
                logger.debug("{}{}DAU002 : After Calling addServiceDBHelper.addService():: hmResult = {}" , sClassName , sMethodName, hmResult);
                stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
                if (!stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
                    String stAppInfoDau = hmResult.get(CommonDefs.COMMON_APP_INFO) != null
                            ? String.valueOf(hmResult.get(CommonDefs.COMMON_APP_INFO)) : "";
                    if (stAppInfoDau.contains("ORA-00001")) {
                        logger.info("{}{}DAU003_DUP : Account already exists on toSLID (added during link phase), continuing: sor_name={}, instance_id={}",
                                sClassName, sMethodName, hmService.get(MPSDefs.DB_SOR_NAME), hmService.get(MPSDefs.DB_INSTANCE_ID));
                        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
                        continue;
                    }
                    logger.error("{}{}DAU003 : Error from addServiceDBHelper.addService: {}", sClassName, sMethodName,
                            HtmlUtils.htmlEscape(String.valueOf(hmResult)));
                    return hmResult;
                }
            }

            //for each of the entries in alAddRoles call the addRole method
            for(HashMap<String, Object> o : alAddRoles){
                HashMap<String, Object> hmRole = new HashMap<>();
                HashMap hmTempRole = (HashMap) o;
                ArrayList alRolesList = null;
                hmRole.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
                String sRoleServiceName = (String) hmTempRole.get(MPSDefs.DB_SERVICE_TYPE);
                if (sRoleServiceName == null) {
                    sRoleServiceName = (String) hmTempRole.get(MPSDefs.DB_SERVICE_NAME);
                }
                hmRole.put(MPSDefs.DB_SERVICE_NAME, sRoleServiceName);
                hmRole.put(MPSDefs.DB_SOR_NAME, hmTempRole.get(MPSDefs.DB_SOR_NAME));
                hmRole.put(MPSDefs.DB_SOR_INVARIANT_ID, hmTempRole.get(MPSDefs.DB_SOR_INVARIANT_ID));
                hmRole.put(MPSDefs.DB_LAST_MODIFIED_BY, stCallingSystemId);
                hmRole.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
                alRolesList = (ArrayList) hmTempRole.get(CommonDefs.ROLES);
                HashMap hmRoleInfo = null;
                for (Object object : alRolesList) {
                    hmRoleInfo = (HashMap) object;
                    hmRole.put(MPSDefs.DB_ROLE_ID, (String) hmRoleInfo.get(MPSDefs.DB_ROLE_ID));
                    hmRole.put(MPSDefs.DB_ROLE_STATUS, (String) hmRoleInfo.get(MPSDefs.DB_ROLE_STATUS));
                    logger.debug("{}{}DAU004 : Calling RolesDBHelper.addEachRole() with inputHash = {}", sClassName, sMethodName, hmRole);
                    hmResult = orolesDBHelper.addEachRole(hmRole);
                    logger.debug("{}{}DAU005 : After Calling RolesDBHelper.addEachRole():: hmResult = {}", sClassName, sMethodName, hmResult);
                    stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
                    if (!stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
                        String stAppInfoDau = hmResult.get(CommonDefs.COMMON_APP_INFO) != null
                                ? String.valueOf(hmResult.get(CommonDefs.COMMON_APP_INFO)) : "";
                        if (stAppInfoDau.contains("ORA-00001")) {
                            logger.info("{}{}DAU006_DUP : Role already exists on toSLID (added during link phase), continuing",
                                    sClassName, sMethodName);
                            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
                            continue;
                        }
                        logger.error("{}{}DAU006 : Error from RolesDBHelper.addEachRole: {}", sClassName, sMethodName,
                                HtmlUtils.htmlEscape(String.valueOf(hmResult)));
                        return hmResult;
                    }
                }
            }

            //for each of the entries in alALLServiceAttributes call the addServiceAttributes method
            for(HashMap<String, Object> o : alALLServiceAttributes){
                HashMap<String, Object> hmServiceAttributes = new HashMap<>();
                HashMap hmTempServiceAttributes = (HashMap) o;
                hmServiceAttributes.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
                hmServiceAttributes.put(MPSDefs.DB_SERVICE_NAME, hmTempServiceAttributes.get(MPSDefs.DB_SERVICE_NAME));
                hmServiceAttributes.put(MPSDefs.DB_SOR_NAME, hmTempServiceAttributes.get(MPSDefs.DB_SOR_NAME));
                hmServiceAttributes.put(MPSDefs.DB_SOR_INVARIANT_ID, hmTempServiceAttributes.get(MPSDefs.DB_SOR_INVARIANT_ID));
                hmServiceAttributes.put(MPSDefs.DB_INSTANCE_ID, hmTempServiceAttributes.get(MPSDefs.DB_INSTANCE_ID));
                hmServiceAttributes.put(MPSDefs.DB_LAST_MODIFIED_BY, stCallingSystemId);
                hmServiceAttributes.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
                hmServiceAttributes.put(MPSDefs.DB_ATTRIBUTE_NAME, hmTempServiceAttributes.get(MPSDefs.DB_ATTRIBUTE_NAME));
                hmServiceAttributes.put(MPSDefs.DB_ATTRIBUTE_VALUE, hmTempServiceAttributes.get(MPSDefs.DB_ATTRIBUTE_VALUE));
                hmServiceAttributes.put("attributeName", hmTempServiceAttributes.get(MPSDefs.DB_ATTRIBUTE_NAME));
                hmServiceAttributes.put("attributeValue", hmTempServiceAttributes.get(MPSDefs.DB_ATTRIBUTE_VALUE));
                logger.debug("{}{}DAU007 : Calling MemberServiceAttributeDBHelper.addServiceAttribute() with inputHash = {}" , sClassName , sMethodName, hmServiceAttributes);
                hmResult = omemberServiceAttributeDBHelper.addServiceAttribute(hmServiceAttributes);
                logger.debug("{}{}DAU008 : After Calling MemberServiceAttributeDBHelper.addServiceAttribute():: hmResult = {}" , sClassName , sMethodName, hmResult);
                stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
                if (!stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
                    String stAppInfoDau = hmResult.get(CommonDefs.COMMON_APP_INFO) != null
                            ? String.valueOf(hmResult.get(CommonDefs.COMMON_APP_INFO)) : "";
                    if (stAppInfoDau.contains("ORA-00001")) {
                        logger.info("{}{}DAU009_DUP : Service attribute already exists on toSLID (added during link phase), continuing",
                                sClassName, sMethodName);
                        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
                        continue;
                    }
                    logger.error("{}{}DAU009 : Error from MemberServiceAttributeDBHelper.addServiceAttribute: {}",
                            sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmResult)));
                    return hmResult;
                }
            }

            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
        } catch (Exception e) {
            stAppInfo = "Exception thrown in dbAccountsUpdates() method::" + e.getMessage();
            hmResult = CommonErrorMap.makeExceptionMap(e);
            logger.error("{}{}DAU009 : {} " , sClassName , sMethodName, stAppInfo);
        } finally {
            logger.debug("{}{}DAU999 : elapsed={}ms response={}", sClassName, sMethodName,
                    (new Date().getTime() - tmsStartDate.getTime()), hmResult);
        }
        return hmResult;
    }

    /**
     * Builds the complete account-insertion data structures for every service type being transferred.
     *
     * <p>For each service type (ECOMM, MOBILITY, DTV, TITAN), this method:</p>
     * <ol>
     *   <li>Calls {@link #processAccounts(ArrayList, ArrayList)} to compare fromSLID accounts
     *       against toSLID accounts and determine which need to be <b>added</b> (unmatched)
     *       vs. which need <b>role updates</b> (matched).</li>
     *   <li>For each unmatched (new) account, constructs three nested data structures:
     *       <ul>
     *         <li><b>Member Services</b> — service-level metadata (SOR name, default-account flag,
     *             CPNI indicator, service status, instance ID, etc.)</li>
     *         <li><b>Service Roles</b> — role entries (role ID, role name, role status, etc.)</li>
     *         <li><b>Service Attributes</b> (MOBILITY only) — account-type, prepaid flags, etc.</li>
     *       </ul>
     *   </li>
     *   <li>For ECOMM, also matches wireline user records from {@code alFromSLIDWireLineDetails}
     *       by {@code SOR_INVARIANT_ID + SOR_ID + SERVICE_ID} and copies the passcode data.</li>
     *   <li>For MOBILITY, also builds a {@code alNotificationEventAccountList} entry so the
     *       EDD notification includes the newly added mobility account.</li>
     * </ol>
     *
     * <p>All constructed account maps are appended to {@code alAddToSlidAccounts}, which is later
     * consumed by {@link #dbAccountsUpdates()} for the actual DB inserts.</p>
     *
     * @return Success map on completion, or error map if any {@code processAccounts()} call fails.
     */
    private Map<String, Object> prepareAccountsHashMap() {
        String sMethodName = "prepareAccountsHashMap";
        String stAppInfo = null;
        String stAppStatusCode = null;
        Date tmsStartDate = new Date();
        HashMap hmResult = null;
        try {
             if(alFromSlidECOMM != null && !alFromSlidECOMM.isEmpty()){
                logger.info("{}{}PAM001 : processAccounts ECOMM fromCount={} toCount={}", sClassName, sMethodName,
                        alFromSlidECOMM.size(), (alToSlidECOMM != null ? alToSlidECOMM.size() : 0));
                logger.debug("{}{}PAM001 : alFromSlidECOMM={} alToSlidECOMM={}", sClassName, sMethodName,
                        alFromSlidECOMM, alToSlidECOMM);
                hmResult = processAccounts(alFromSlidECOMM, alToSlidECOMM);
                logger.debug("{}{}PAM002 : processAccounts ECOMM response={}", sClassName, sMethodName, hmResult);

                if (hmResult == null) {
                    stAppInfo = "Null Response returned from processAccounts()";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                    logger.error("{}{}PAM003 : {}" , sClassName , sMethodName, stAppInfo);
                    return hmResult;
                }
                stAppStatusCode = (String) hmResult
                        .get(CErrorDefs.COMMON_APP_STATUS_CODE);
                if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                    stAppInfo = "Error returned After calling processAccounts()";
                    logger.error("{}{}PAM004 : {}" , sClassName , sMethodName, stAppInfo);
                    return hmResult;
                }

                ArrayList alECOMMAccountsToAdd = (ArrayList)hmResult.get(CommonDefs.KEY_ADD_ACCOUNT_LIST);
                if(alECOMMAccountsToAdd != null && !alECOMMAccountsToAdd.isEmpty()){
                    for(int i=0; i<alECOMMAccountsToAdd.size(); i++){
                        HashMap hmECOMMToAdd = (HashMap)alECOMMAccountsToAdd.get(i);
                        HashMap hmECOMM = null;
                        if(hmECOMMToAdd != null && !hmECOMMToAdd.isEmpty()){
                            hmECOMM = CommonUtil.getHashMap();
                            ArrayList alECOMMMemberServices = CommonUtil.getArrayList();
                            HashMap hmECOMMMemberServices = CommonUtil.getHashMap();
                            ArrayList alECOMMServiceRoles = CommonUtil.getArrayList();
                            HashMap hmECOMMServiceRoles = CommonUtil.getHashMap();
                            HashMap hmECOMMRoles = CommonUtil.getHashMap();
                            ArrayList alECOMMRoles = CommonUtil.getArrayList();
                            ArrayList alECOMMWireline = CommonUtil.getArrayList();
                            HashMap hmECOMMWireline = CommonUtil.getHashMap();

                            hmECOMMMemberServices.put("sorName", hmECOMMToAdd.get(MPSDefs.DB_SOR_NAME));
                            hmECOMMMemberServices.put(MPSDefs.DB_NICKNAME,
                                    hmECOMMToAdd.get(MPSDefs.DB_SERVICE_NICKNAME));
                            hmECOMMMemberServices.put(CommonDefs.CPNI_IMPACTED,
                                    hmECOMMToAdd.get(MPSDefs.DB_CPNI_IMPACTED));
                            hmECOMMMemberServices.put(CommonDefs.SERVICE_TYPE,
                                    hmECOMMToAdd.get(MPSDefs.DB_SERVICE_NAME));
                            hmECOMMMemberServices.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
                            hmECOMMMemberServices.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_INSERT);
                            hmECOMMMemberServices.put(CommonDefs.SOR_INVARIANT_ID,
                                    hmECOMMToAdd.get(MPSDefs.DB_SOR_INVARIANT_ID));
                            hmECOMMMemberServices.put(MPSDefs.WS_GROUP_STATUS_NAME, MPSDefs.ENABLED);
                            hmECOMMMemberServices.put(MPSDefs.DB_GROUP_NUM, stToSlidGroupNum);
                            if(toSLIDDefaultAccountExist){
                                hmECOMMMemberServices.put(CommonDefs.DEFAULT_ACCOUNT, CommonDefs.DEFAULT_NO);
                            }else{
                                hmECOMMMemberServices.put(CommonDefs.DEFAULT_ACCOUNT,
                                        hmECOMMToAdd.get(MPSDefs.DB_DEFAULT_ACCOUNT));
                            }
                            hmECOMMMemberServices.put(CommonDefs.SERVICE_STATUS, MPSDefs.ENABLED);
                            hmECOMMMemberServices.put(CommonDefs.OWNED_BY, hmECOMMToAdd.get(MPSDefs.DB_OWNED_BY));
                            hmECOMMMemberServices.put(MPSDefs.DB_INSTANCE_ID, hmECOMMToAdd.get(MPSDefs.DB_INSTANCE_ID));
                            alECOMMMemberServices.add(hmECOMMMemberServices);

                            ArrayList alRolesToadd = (ArrayList)hmECOMMToAdd.get(MPSDefs.DB_ROLES);
                            if(alRolesToadd != null && !alRolesToadd.isEmpty()){
                                for(int j=0; j<alRolesToadd.size(); j++){
                                    HashMap hmRolesToAdd = (HashMap)alRolesToadd.get(j);
                                    if(hmRolesToAdd != null && !hmRolesToAdd.isEmpty()){
                                        hmECOMMServiceRoles.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_INSERT);
                                        hmECOMMServiceRoles.put(CommonDefs.TRANSACTION_ID, stTransactionId);
                                        hmECOMMServiceRoles.put(MPSDefs.DB_SERVICE_TYPE,
                                                hmECOMMToAdd.get(MPSDefs.DB_SERVICE_NAME));
                                        hmECOMMServiceRoles.put(MPSDefs.DB_SOR_INVARIANT_ID,
                                                hmECOMMToAdd.get(MPSDefs.DB_SOR_INVARIANT_ID));
                                        hmECOMMServiceRoles.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
                                        hmECOMMServiceRoles.put(MPSDefs.DB_SOR_NAME,
                                                hmECOMMToAdd.get(MPSDefs.DB_SOR_NAME));
                                        hmECOMMServiceRoles.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);

                                        hmECOMMRoles.put(MPSDefs.DB_SERVICE_ID, hmRolesToAdd.get(MPSDefs.DB_SERVICE_ID));
                                        hmECOMMRoles.put(MPSDefs.DB_ROLE_ID, hmRolesToAdd.get(MPSDefs.DB_ROLE_ID));
                                        hmECOMMRoles.put(MPSDefs.DB_ROLE_NAME, hmRolesToAdd.get(MPSDefs.DB_ROLE_NAME));
                                        hmECOMMRoles.put(MPSDefs.DB_SOR_INVARIANT_ID,
                                                hmRolesToAdd.get(MPSDefs.DB_SOR_INVARIANT_ID));
                                        hmECOMMRoles.put(MPSDefs.DB_ROLE_STATUS,
                                                hmRolesToAdd.get(MPSDefs.DB_ROLE_STATUS_NAME));
                                        alECOMMRoles.add(hmECOMMRoles);
                                        hmECOMMServiceRoles.put(MPSDefs.DB_ROLES, alECOMMRoles);
                                    }
                                    alECOMMServiceRoles.add(hmECOMMServiceRoles);
                                }
                            }

                            // Match wireline user records from fromSLID to this ECOMM account.
                            // Wireline data (passcode) must be migrated alongside the ECOMM service.
                            // The match is done on the triple: SOR_INVARIANT_ID + SOR_ID + SERVICE_ID.
                            if(alFromSLIDWireLineDetails != null && !alFromSLIDWireLineDetails.isEmpty()){
                                for(int c=0; c<alFromSLIDWireLineDetails.size(); c++){
                                    HashMap hmFromSLIDWireline = (HashMap)alFromSLIDWireLineDetails.get(c);
                                    if(hmFromSLIDWireline != null && !hmFromSLIDWireline.isEmpty()){
                                        String stWireLineSorInvariantId =
                                                (String)hmFromSLIDWireline.get(MPSDefs.DB_SOR_INVARIANT_ID);
                                        String stWireLineSorId = (String)hmFromSLIDWireline.get(MPSDefs.DB_SOR_ID);
                                        String stWireLineServiceId =
                                                (String)hmFromSLIDWireline.get(MPSDefs.DB_SERVICE_ID);
                                        if((stWireLineSorInvariantId != null && stWireLineSorInvariantId.equalsIgnoreCase
                                                ((String)hmECOMMToAdd.get(MPSDefs.DB_SOR_INVARIANT_ID)))
                                                && (stWireLineSorId != null && stWireLineSorId.equalsIgnoreCase
                                                ((String)hmECOMMToAdd.get(MPSDefs.DB_SOR_ID)))
                                                && (stWireLineServiceId != null && stWireLineServiceId.equalsIgnoreCase
                                                ((String)hmECOMMToAdd.get(MPSDefs.DB_SERVICE_ID)))){

                                            hmECOMMWireline.put(MPSDefs.DB_SERVICE_NAME, MPSDefs.ECOMM_SERVICE);
                                            hmECOMMWireline.put(MPSDefs.DB_SOR_NAME,
                                                    hmECOMMToAdd.get(MPSDefs.DB_SOR_NAME));
                                            hmECOMMWireline.put(MPSDefs.DB_SOR_ID,
                                                    hmECOMMToAdd.get(MPSDefs.DB_SOR_ID));
                                            hmECOMMWireline.put(MPSDefs.DB_SERVICE_ID,
                                                    hmECOMMToAdd.get(MPSDefs.DB_SERVICE_ID));
                                            hmECOMMWireline.put(MPSDefs.DB_SOR_INVARIANT_ID,
                                                    hmECOMMToAdd.get(MPSDefs.DB_SOR_INVARIANT_ID));
                                            hmECOMMWireline.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_INSERT);
                                            String stWirelinePasscode =
                                                    (String)hmFromSLIDWireline.get(MPSDefs.DB_PASSCODE);
                                            String stWirelinePasscodeVenc =
                                                    (String)hmFromSLIDWireline.get(MPSDefs.DB_PASSCODE_VENC);
                                            if(stWirelinePasscode != null && stWirelinePasscode.trim().length() > 0){
                                                hmECOMMWireline.put(MPSDefs.DB_PASSCODE, stWirelinePasscode);
                                            }
                                            if(stWirelinePasscodeVenc != null && stWirelinePasscodeVenc.trim().length() > 0){
                                                hmECOMMWireline.put(MPSDefs.DB_PASSCODE_VENC, stWirelinePasscodeVenc);
                                            }
                                            break;
                                        }
                                    }
                                }
                            }

                            if(hmECOMMWireline != null && !hmECOMMWireline.isEmpty())
                                alECOMMWireline.add(hmECOMMWireline);
                            hmECOMM.put(CommonDefs.KEY_MEMBER_SERVICES, alECOMMMemberServices);
                            hmECOMM.put(CommonDefs.KEY_SERVICE_ROLES, alECOMMServiceRoles);

                            if(alECOMMWireline != null && !alECOMMWireline.isEmpty())
                                hmECOMM.put("wireline", alECOMMWireline);
                        }
                        if(hmECOMM != null && !hmECOMM.isEmpty()){
                            alAddToSlidAccounts.add(hmECOMM);
                        }
                    }
                }
            }

            if(alFromSlidMOBILITY != null && !alFromSlidMOBILITY.isEmpty()){
                logger.info("{}{}PAM005 : processAccounts MOBILITY fromCount={} toCount={}", sClassName, sMethodName,
                        alFromSlidMOBILITY.size(), (alToSlidMOBILITY != null ? alToSlidMOBILITY.size() : 0));
                logger.debug("{}{}PAM005 : alFromSlidMOBILITY={} alToSlidMOBILITY={}", sClassName, sMethodName,
                        alFromSlidMOBILITY, alToSlidMOBILITY);
                hmResult = processAccounts(alFromSlidMOBILITY, alToSlidMOBILITY);
                logger.debug("{}{}PAM006 : processAccounts MOBILITY response={}", sClassName, sMethodName, hmResult);
                if (hmResult == null) {
                    stAppInfo = "Null Response returned from processAccounts()";
                    hmResult = CommonErrorMap.makeCategoryMap(
                            CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                    logger.error("{}{}PAM007 : {}", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                }
                stAppStatusCode = (String) hmResult
                        .get(CErrorDefs.COMMON_APP_STATUS_CODE);
                if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                    stAppInfo = "Error returned After calling processAccounts()";
                    logger.error("{}{}PAM008 : {}", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                }
                ArrayList alMOBILITYAccountsToAdd = (ArrayList)hmResult.get(CommonDefs.KEY_ADD_ACCOUNT_LIST);
                if(alMOBILITYAccountsToAdd != null && !alMOBILITYAccountsToAdd.isEmpty()){
                    for(int i=0; i<alMOBILITYAccountsToAdd.size(); i++){
                        HashMap hmMOBILITYToAdd = (HashMap)alMOBILITYAccountsToAdd.get(i);
                        HashMap hmMOBILITY = null;
                        if(hmMOBILITYToAdd != null && !hmMOBILITYToAdd.isEmpty()){
                            hmMOBILITY = CommonUtil.getHashMap();
                            ArrayList alMOBILITYMemberServices = CommonUtil.getArrayList();
                            HashMap hmMOBILITYMemberServices = CommonUtil.getHashMap();
                            ArrayList alMOBILITYServiceRoles = CommonUtil.getArrayList();
                            HashMap hmMOBILITYServiceRoles = CommonUtil.getHashMap();
                            HashMap hmMOBILITYRoles = CommonUtil.getHashMap();
                            ArrayList alMOBILITYRoles = CommonUtil.getArrayList();
                            ArrayList alMOBILITYServiceAttributes= CommonUtil.getArrayList();
                            HashMap hmMOBILITYServiceAttributes;
                            hmMOBILITYMemberServices.put("sorName", hmMOBILITYToAdd.get(MPSDefs.DB_SOR_NAME));
                            hmMOBILITYMemberServices.put(MPSDefs.DB_NICKNAME,
                                    hmMOBILITYToAdd.get(MPSDefs.DB_SERVICE_NICKNAME));
                            hmMOBILITYMemberServices.put(CommonDefs.CPNI_IMPACTED,
                                    hmMOBILITYToAdd.get(MPSDefs.DB_CPNI_IMPACTED));
                            hmMOBILITYMemberServices.put(CommonDefs.SERVICE_TYPE,
                                    hmMOBILITYToAdd.get(MPSDefs.DB_SERVICE_NAME));
                            hmMOBILITYMemberServices.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
                            hmMOBILITYMemberServices.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_INSERT);
                            hmMOBILITYMemberServices.put(CommonDefs.SOR_INVARIANT_ID,
                                    hmMOBILITYToAdd.get(MPSDefs.DB_SOR_INVARIANT_ID));
                            hmMOBILITYMemberServices.put(MPSDefs.WS_GROUP_STATUS_NAME, MPSDefs.ENABLED);
                            hmMOBILITYMemberServices.put(MPSDefs.DB_GROUP_NUM, stToSlidGroupNum);
                            if(toSLIDDefaultAccountExist){
                                hmMOBILITYMemberServices.put(CommonDefs.DEFAULT_ACCOUNT, CommonDefs.DEFAULT_NO);
                            }else{
                                hmMOBILITYMemberServices.put(CommonDefs.DEFAULT_ACCOUNT,
                                        hmMOBILITYToAdd.get(MPSDefs.DB_DEFAULT_ACCOUNT));
                            }
                            hmMOBILITYMemberServices.put(CommonDefs.SERVICE_STATUS, MPSDefs.ENABLED);
                            hmMOBILITYMemberServices.put(CommonDefs.OWNED_BY, hmMOBILITYToAdd.get(MPSDefs.DB_OWNED_BY));
                            hmMOBILITYMemberServices.put(MPSDefs.DB_INSTANCE_ID,
                                    hmMOBILITYToAdd.get(MPSDefs.DB_INSTANCE_ID));
                            hmMOBILITYMemberServices.put(MPSDefs.DB_PARENT_SOR_ID,
                                    hmMOBILITYToAdd.get(MPSDefs.DB_PARENT_SOR_ID));
                            hmMOBILITYMemberServices.put(MPSDefs.DB_PARENT_SOR_INVARIANT_ID,
                                    hmMOBILITYToAdd.get(MPSDefs.DB_PARENT_SOR_INVARIANT_ID));
                            alMOBILITYMemberServices.add(hmMOBILITYMemberServices);

                            ArrayList alRolesToadd = (ArrayList)hmMOBILITYToAdd.get(MPSDefs.DB_ROLES);
                            if(alRolesToadd != null && !alRolesToadd.isEmpty()){
                                for(int j=0; j<alRolesToadd.size(); j++){
                                    HashMap hmRolesToAdd = (HashMap)alRolesToadd.get(j);
                                    if(hmRolesToAdd != null && !hmRolesToAdd.isEmpty()){
                                        hmMOBILITYServiceRoles.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_INSERT);
                                        hmMOBILITYServiceRoles.put(CommonDefs.TRANSACTION_ID, stTransactionId);
                                        hmMOBILITYServiceRoles.put(MPSDefs.DB_SERVICE_TYPE,
                                                hmMOBILITYToAdd.get(MPSDefs.DB_SERVICE_NAME));
                                        hmMOBILITYServiceRoles.put(MPSDefs.DB_SOR_INVARIANT_ID,
                                                hmMOBILITYToAdd.get(MPSDefs.DB_SOR_INVARIANT_ID));
                                        hmMOBILITYServiceRoles.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
                                        hmMOBILITYServiceRoles.put(MPSDefs.DB_SOR_NAME,
                                                hmMOBILITYToAdd.get(MPSDefs.DB_SOR_NAME));
                                        hmMOBILITYServiceRoles.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
                                        hmMOBILITYRoles.put(MPSDefs.DB_SERVICE_ID,
                                                hmRolesToAdd.get(MPSDefs.DB_SERVICE_ID));
                                        hmMOBILITYRoles.put(MPSDefs.DB_ROLE_ID, hmRolesToAdd.get(MPSDefs.DB_ROLE_ID));
                                        hmMOBILITYRoles.put(MPSDefs.DB_ROLE_NAME, hmRolesToAdd.get(MPSDefs.DB_ROLE_NAME));
                                        hmMOBILITYRoles.put(MPSDefs.DB_SOR_INVARIANT_ID,
                                                hmRolesToAdd.get(MPSDefs.DB_SOR_INVARIANT_ID));
                                        hmMOBILITYRoles.put(MPSDefs.DB_ROLE_STATUS,
                                                hmRolesToAdd.get(MPSDefs.DB_ROLE_STATUS_NAME));
                                        alMOBILITYRoles.add(hmMOBILITYRoles);
                                        hmMOBILITYServiceRoles.put(MPSDefs.DB_ROLES, alMOBILITYRoles);
                                    }
                                    alMOBILITYServiceRoles.add(hmMOBILITYServiceRoles);
                                }
                            }

                            ArrayList alServiceAttributesToadd  =
                                    (ArrayList)hmMOBILITYToAdd.get(MPSDefs.DB_MEMBER_SERVICE_ATTRIBUTE);
                            if(alServiceAttributesToadd != null && !alServiceAttributesToadd.isEmpty()){
                                for(int j=0; j<alServiceAttributesToadd.size(); j++){
                                    HashMap hmServiceAttributesToAdd  = (HashMap)alServiceAttributesToadd.get(j);
                                    hmMOBILITYServiceAttributes=CommonUtil.getHashMap();
                                    if(hmServiceAttributesToAdd != null && !hmServiceAttributesToAdd.isEmpty()){
                                        hmMOBILITYServiceAttributes.put(CommonDefs.TRANSACTION_ID, stTransactionId);
                                        hmMOBILITYServiceAttributes.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
                                        hmMOBILITYServiceAttributes.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
                                        hmMOBILITYServiceAttributes.put(MPSDefs.DB_ATTRIBUTE_NAME,
                                                hmServiceAttributesToAdd.get(MPSDefs.DB_ATTRIBUTE_NAME));
                                        hmMOBILITYServiceAttributes.put(MPSDefs.DB_ATTRIBUTE_VALUE,
                                                hmServiceAttributesToAdd.get(MPSDefs.DB_ATTRIBUTE_VALUE));
                                        hmMOBILITYServiceAttributes.put(MPSDefs.DB_SERVICE_NAME,
                                                hmMOBILITYToAdd.get(MPSDefs.DB_SERVICE_NAME));
                                        hmMOBILITYServiceAttributes.put(MPSDefs.DB_SOR_INVARIANT_ID,
                                                hmMOBILITYToAdd.get(MPSDefs.DB_SOR_INVARIANT_ID));
                                        hmMOBILITYServiceAttributes.put(MPSDefs.DB_SOR_NAME,
                                                hmMOBILITYToAdd.get(MPSDefs.DB_SOR_NAME));
                                        hmMOBILITYServiceAttributes.put(MPSDefs.DB_INSTANCE_ID,
                                                hmMOBILITYToAdd.get(MPSDefs.DB_INSTANCE_ID));
                                    }
                                    alMOBILITYServiceAttributes.add(hmMOBILITYServiceAttributes);
                                }
                            }

                            hmMOBILITY.put(MPSDefs.DB_MEMBER_SERVICE_ATTRIBUTE, alMOBILITYServiceAttributes);
                            hmMOBILITY.put(CommonDefs.KEY_MEMBER_SERVICES, alMOBILITYMemberServices);
                            hmMOBILITY.put(CommonDefs.KEY_SERVICE_ROLES, alMOBILITYServiceRoles);

                            HashMap hmInputMOBILITYNotify = CommonUtil.getHashMap();
                            hmInputMOBILITYNotify.put(MPSDefs.DB_SOR_NAME, hmMOBILITYToAdd.get(MPSDefs.DB_SOR_NAME));
                            hmInputMOBILITYNotify.put(CommonDefs.SOR_INVARIANT_ID,
                                    hmMOBILITYToAdd.get(MPSDefs.DB_SOR_INVARIANT_ID));
                            hmInputMOBILITYNotify.put(CommonDefs.ACCOUNT_TYPE, MPSDefs.MOBILITY_SERVICE);

                            alNotificationEventAccountList.add(hmInputMOBILITYNotify);
                            logger.info("{}{}NTF_ACCT_MOBILITY : Added MOBILITY account to alNotificationEventAccountList, entry={}",
                                    sClassName, sMethodName, hmInputMOBILITYNotify);
                        }
                        if(hmMOBILITY != null && !hmMOBILITY.isEmpty()){
                            alAddToSlidAccounts.add(hmMOBILITY);
                        }
                    }
                }
            }

            if(alFromSlidDTV != null && !alFromSlidDTV.isEmpty()){
                logger.info("{}{}PAM009 : processAccounts DTV fromCount={} toCount={}", sClassName, sMethodName,
                        alFromSlidDTV.size(), (alToSlidDTV != null ? alToSlidDTV.size() : 0));
                logger.debug("{}{}PAM009 : alFromSlidDTV={} alToSlidDTV={}", sClassName, sMethodName,
                        alFromSlidDTV, alToSlidDTV);
                hmResult = processAccounts(alFromSlidDTV, alToSlidDTV);
                logger.debug("{}{}PAM010 : processAccounts DTV response={}", sClassName, sMethodName, hmResult);
                if (hmResult == null) {
                    stAppInfo = "Null Response returned from processAccounts()";
                    hmResult = CommonErrorMap.makeCategoryMap(
                            CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                    logger.error("{}{}PAM011 : {}", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                }
                stAppStatusCode = (String) hmResult
                        .get(CErrorDefs.COMMON_APP_STATUS_CODE);
                if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                    stAppInfo = "Error returned After calling processAccounts()";
                    logger.error("{}{}PAM012 : {}", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                }

                ArrayList alDTVAccountsToAdd = (ArrayList)hmResult.get(CommonDefs.KEY_ADD_ACCOUNT_LIST);
                if(alDTVAccountsToAdd != null && !alDTVAccountsToAdd.isEmpty()){
                    for(int i=0; i<alDTVAccountsToAdd.size(); i++){
                        HashMap hmDTVToAdd = (HashMap)alDTVAccountsToAdd.get(i);
                        HashMap hmDTV = null;
                        if(hmDTVToAdd != null && !hmDTVToAdd.isEmpty()){
                            hmDTV = CommonUtil.getHashMap();
                            ArrayList alDTVMemberServices = CommonUtil.getArrayList();
                            HashMap hmDTVMemberServices = CommonUtil.getHashMap();
                            ArrayList alDTVServiceRoles = CommonUtil.getArrayList();
                            HashMap hmDTVServiceRoles = CommonUtil.getHashMap();
                            ArrayList alDTVRoles = CommonUtil.getArrayList();

                            hmDTVMemberServices.put("sorName", hmDTVToAdd.get(MPSDefs.DB_SOR_NAME));
                            hmDTVMemberServices.put(MPSDefs.DB_NICKNAME, hmDTVToAdd.get(MPSDefs.DB_SERVICE_NICKNAME));
                            hmDTVMemberServices.put(CommonDefs.SERVICE_TYPE, hmDTVToAdd.get(MPSDefs.DB_SERVICE_NAME));
                            hmDTVMemberServices.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
                            hmDTVMemberServices.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_INSERT);
                            hmDTVMemberServices.put(CommonDefs.SOR_INVARIANT_ID,
                                    hmDTVToAdd.get(MPSDefs.DB_SOR_INVARIANT_ID));
                            hmDTVMemberServices.put(MPSDefs.WS_GROUP_STATUS_NAME, MPSDefs.ENABLED);
                            hmDTVMemberServices.put(MPSDefs.DB_GROUP_NUM, stToSlidGroupNum);
                            hmDTVMemberServices.put(CommonDefs.DEFAULT_ACCOUNT, CommonDefs.DEFAULT_NO);
                            hmDTVMemberServices.put(CommonDefs.SERVICE_STATUS, MPSDefs.ENABLED);
                            hmDTVMemberServices.put(CommonDefs.OWNED_BY, hmDTVToAdd.get(MPSDefs.DB_OWNED_BY));
                            hmDTVMemberServices.put(MPSDefs.DB_INSTANCE_ID, hmDTVToAdd.get(MPSDefs.DB_INSTANCE_ID));
                            hmDTVMemberServices.put(MPSDefs.DB_PARENT_SOR_ID, hmDTVToAdd.get(MPSDefs.DB_PARENT_SOR_ID));
                            hmDTVMemberServices.put(MPSDefs.DB_PARENT_SOR_INVARIANT_ID,
                                    hmDTVToAdd.get(MPSDefs.DB_PARENT_SOR_INVARIANT_ID));
                            alDTVMemberServices.add(hmDTVMemberServices);
                            hmDTV.put(CommonDefs.KEY_MEMBER_SERVICES, alDTVMemberServices);

                            ArrayList alRolesToadd = (ArrayList) hmDTVToAdd.get(MPSDefs.DB_ROLES);
                            if(alRolesToadd != null && !alRolesToadd.isEmpty()){
                                for(Object roleObj : alRolesToadd){
                                    HashMap hmRoleToAdd = (HashMap) roleObj;
                                    if(hmRoleToAdd != null && !hmRoleToAdd.isEmpty()){
                                        HashMap hmDTVRole = CommonUtil.getHashMap();
                                        hmDTVRole.put(MPSDefs.DB_SERVICE_ID, hmRoleToAdd.get(MPSDefs.DB_SERVICE_ID));
                                        hmDTVRole.put(MPSDefs.DB_ROLE_ID, hmRoleToAdd.get(MPSDefs.DB_ROLE_ID));
                                        hmDTVRole.put(MPSDefs.DB_ROLE_NAME, hmRoleToAdd.get(MPSDefs.DB_ROLE_NAME));
                                        hmDTVRole.put(MPSDefs.DB_SOR_INVARIANT_ID, hmRoleToAdd.get(MPSDefs.DB_SOR_INVARIANT_ID));
                                        hmDTVRole.put(MPSDefs.DB_ROLE_STATUS, hmRoleToAdd.get(MPSDefs.DB_ROLE_STATUS_NAME));
                                        alDTVRoles.add(hmDTVRole);
                                    }
                                }

                                hmDTVServiceRoles.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_INSERT);
                                hmDTVServiceRoles.put(CommonDefs.TRANSACTION_ID, stTransactionId);
                                hmDTVServiceRoles.put(MPSDefs.DB_SERVICE_TYPE, hmDTVToAdd.get(MPSDefs.DB_SERVICE_NAME));
                                hmDTVServiceRoles.put(MPSDefs.DB_SOR_INVARIANT_ID, hmDTVToAdd.get(MPSDefs.DB_SOR_INVARIANT_ID));
                                hmDTVServiceRoles.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
                                hmDTVServiceRoles.put(MPSDefs.DB_SOR_NAME, hmDTVToAdd.get(MPSDefs.DB_SOR_NAME));
                                hmDTVServiceRoles.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
                                hmDTVServiceRoles.put(MPSDefs.DB_ROLES, alDTVRoles);
                                alDTVServiceRoles.add(hmDTVServiceRoles);
                                hmDTV.put(CommonDefs.KEY_SERVICE_ROLES, alDTVServiceRoles);
                            }

                            ArrayList alDTVServiceAttributes = (ArrayList) hmDTVToAdd.get(MPSDefs.DB_MEMBER_SERVICE_ATTRIBUTE);
                            if(alDTVServiceAttributes != null && !alDTVServiceAttributes.isEmpty()){
                                hmDTV.put(MPSDefs.DB_MEMBER_SERVICE_ATTRIBUTE, alDTVServiceAttributes);
                            }
                        }
                        if(hmDTV != null && !hmDTV.isEmpty()){
                            alAddToSlidAccounts.add(hmDTV);
                        }
                    }
                }
            }

            if(alFromSlidTITAN != null && !alFromSlidTITAN.isEmpty()){
                logger.info("{}{}PAM013 : processAccounts TITAN fromCount={} toCount={}", sClassName, sMethodName,
                        alFromSlidTITAN.size(), (alToSlidTITAN != null ? alToSlidTITAN.size() : 0));
                logger.debug("{}{}PAM013 : alFromSlidTITAN={} alToSlidTITAN={}", sClassName, sMethodName,
                        alFromSlidTITAN, alToSlidTITAN);
                hmResult = processAccounts(alFromSlidTITAN, alToSlidTITAN);
                logger.debug("{}{}PAM014 : processAccounts TITAN response={}", sClassName, sMethodName, hmResult);
                if (hmResult == null) {
                    stAppInfo = "Null Response returned from processAccounts()";
                    hmResult = CommonErrorMap.makeCategoryMap(
                            CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                    logger.error("{}{}PAM015A : {}", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                }
                stAppStatusCode = (String) hmResult
                        .get(CErrorDefs.COMMON_APP_STATUS_CODE);
                if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                    stAppInfo = "Error returned After calling processAccounts()";
                    logger.error("{}{}PAM016A : {}", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                }
                ArrayList alTITANAccountsToAdd = (ArrayList)hmResult.get(CommonDefs.KEY_ADD_ACCOUNT_LIST);
                if(alTITANAccountsToAdd != null && !alTITANAccountsToAdd.isEmpty()){
                    for(int i=0; i<alTITANAccountsToAdd.size(); i++){
                        HashMap hmTITANToAdd = (HashMap)alTITANAccountsToAdd.get(i);
                        String stTITANSorInvId = (String)hmTITANToAdd.get(MPSDefs.DB_SOR_INVARIANT_ID);
                        HashMap hmTITAN = null;
                        if(hmTITANToAdd != null && !hmTITANToAdd.isEmpty()){
                            hmTITAN = CommonUtil.getHashMap();
                            ArrayList alTITANMemberServices = CommonUtil.getArrayList();
                            HashMap hmTITANMemberServices = CommonUtil.getHashMap();
                            ArrayList alTITANServiceRoles = CommonUtil.getArrayList();
                            HashMap hmTITANServiceRoles = CommonUtil.getHashMap();
                            HashMap hmTITANRoles = CommonUtil.getHashMap();
                            ArrayList alTITANRoles = CommonUtil.getArrayList();
                            hmTITANMemberServices.put("sorName", hmTITANToAdd.get(MPSDefs.DB_SOR_NAME));
                            hmTITANMemberServices.put(MPSDefs.DB_NICKNAME,
                                    hmTITANToAdd.get(MPSDefs.DB_SERVICE_NICKNAME));
                            hmTITANMemberServices.put(CommonDefs.CPNI_IMPACTED,
                                    hmTITANToAdd.get(MPSDefs.DB_CPNI_IMPACTED));
                            hmTITANMemberServices.put(CommonDefs.SERVICE_TYPE,
                                    hmTITANToAdd.get(MPSDefs.DB_SERVICE_NAME));
                            hmTITANMemberServices.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
                            hmTITANMemberServices.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_INSERT);
                            hmTITANMemberServices.put(CommonDefs.SOR_INVARIANT_ID,
                                    hmTITANToAdd.get(MPSDefs.DB_SOR_INVARIANT_ID));
                            hmTITANMemberServices.put(MPSDefs.WS_GROUP_STATUS_NAME, MPSDefs.ENABLED);
                            hmTITANMemberServices.put(MPSDefs.DB_GROUP_NUM, stToSlidGroupNum);
                            if(toSLIDDefaultAccountExist){
                                hmTITANMemberServices.put(CommonDefs.DEFAULT_ACCOUNT, CommonDefs.DEFAULT_NO);
                            }else{
                                hmTITANMemberServices.put(CommonDefs.DEFAULT_ACCOUNT,
                                        hmTITANToAdd.get(MPSDefs.DB_DEFAULT_ACCOUNT));
                            }
                            hmTITANMemberServices.put(CommonDefs.SERVICE_STATUS, MPSDefs.ENABLED);
                            hmTITANMemberServices.put(CommonDefs.OWNED_BY, hmTITANToAdd.get(MPSDefs.DB_OWNED_BY));
                            hmTITANMemberServices.put(MPSDefs.DB_INSTANCE_ID, hmTITANToAdd.get(MPSDefs.DB_INSTANCE_ID));
                            hmTITANMemberServices.put(MPSDefs.DB_PARENT_SOR_ID,
                                    hmTITANToAdd.get(MPSDefs.DB_PARENT_SOR_ID));
                            hmTITANMemberServices.put(MPSDefs.DB_PARENT_SOR_INVARIANT_ID,
                                    hmTITANToAdd.get(MPSDefs.DB_PARENT_SOR_INVARIANT_ID));
                            hmTITANMemberServices.put(MPSDefs.DB_UVERSE_SERVICE_IND,
                                    hmTITANToAdd.get(MPSDefs.DB_UVERSE_SERVICE_IND));
                            alTITANMemberServices.add(hmTITANMemberServices);

                            ArrayList alRolesToadd = (ArrayList)hmTITANToAdd.get(MPSDefs.DB_ROLES);
                            if(alRolesToadd != null && !alRolesToadd.isEmpty()){
                                for (Object roleToAdd : alRolesToadd) {
                                    HashMap hmRolesToAdd = (HashMap) roleToAdd;
                                    if (hmRolesToAdd != null && !hmRolesToAdd.isEmpty()) {
                                        hmTITANServiceRoles.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_INSERT);
                                        hmTITANServiceRoles.put(CommonDefs.TRANSACTION_ID, stTransactionId);
                                        hmTITANServiceRoles.put(MPSDefs.DB_SERVICE_TYPE,
                                                hmTITANToAdd.get(MPSDefs.DB_SERVICE_NAME));
                                        hmTITANServiceRoles.put(MPSDefs.DB_SOR_INVARIANT_ID,
                                                hmTITANToAdd.get(MPSDefs.DB_SOR_INVARIANT_ID));
                                        hmTITANServiceRoles.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
                                        hmTITANServiceRoles.put(MPSDefs.DB_SOR_NAME,
                                                hmTITANToAdd.get(MPSDefs.DB_SOR_NAME));
                                        hmTITANServiceRoles.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
                                        hmTITANRoles.put(MPSDefs.DB_SERVICE_ID, hmRolesToAdd.get(MPSDefs.DB_SERVICE_ID));
                                        hmTITANRoles.put(MPSDefs.DB_ROLE_ID, hmRolesToAdd.get(MPSDefs.DB_ROLE_ID));
                                        hmTITANRoles.put(MPSDefs.DB_ROLE_NAME, hmRolesToAdd.get(MPSDefs.DB_ROLE_NAME));
                                        hmTITANRoles.put(MPSDefs.DB_SOR_INVARIANT_ID,
                                                hmRolesToAdd.get(MPSDefs.DB_SOR_INVARIANT_ID));
                                        hmTITANRoles.put(MPSDefs.DB_ROLE_STATUS,
                                                hmRolesToAdd.get(MPSDefs.DB_ROLE_STATUS_NAME));
                                        alTITANRoles.add(hmTITANRoles);
                                        hmTITANServiceRoles.put(MPSDefs.DB_ROLES, alTITANRoles);
                                    }
                                    alTITANServiceRoles.add(hmTITANServiceRoles);
                                }
                            }
                            hmTITAN.put(CommonDefs.KEY_MEMBER_SERVICES, alTITANMemberServices);
                            hmTITAN.put(CommonDefs.KEY_SERVICE_ROLES, alTITANServiceRoles);
                        }
                        if(hmTITAN != null && !hmTITAN.isEmpty()){
                            alAddToSlidAccounts.add(hmTITAN);
                        }
                    }
                }
            }

            if (hmResult == null) {
                hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
            }

        } catch (Exception e) {
            stAppInfo = "Exception thrown in prepareAccountsHashMap() method::" + e.getMessage();
            hmResult = CommonErrorMap.makeExceptionMap(e);
            logger.error("{}{}PAM017 : {} " , sClassName , sMethodName, stAppInfo);
        } finally {
            logger.debug("{}{}PAM999 : elapsed={}ms response={}", sClassName, sMethodName,
                    (new Date().getTime() - tmsStartDate.getTime()), hmResult);
        }
        return hmResult;
    }

    /**
     * Compares accounts from fromSLID against toSLID to determine which accounts need to be
     * <b>added</b> (no match found) and which need <b>role updates</b> (match found).
     *
     * <p>Matching logic: an account on fromSLID matches an account on toSLID when all three
     * of the following identifiers are equal (case-insensitive):</p>
     * <ul>
     *   <li>{@code SOR_INVARIANT_ID}</li>
     *   <li>{@code SERVICE_TYPE} (service name)</li>
     *   <li>{@code SERVICE_ID}</li>
     * </ul>
     *
     * <p>When a match is found, {@link #processRoles(ArrayList, ArrayList)} is called to
     * reconcile the roles between the two accounts. When no match is found, the fromSLID
     * account is added to the returned {@code KEY_ADD_ACCOUNT_LIST} for later insertion
     * into the toSLID.</p>
     *
     * @param alFromSlidAccounts Accounts from the source SLID (must not be null/empty).
     * @param alToSlidAccounts   Accounts from the target SLID (may be null/empty, meaning all are new).
     * @return Map containing {@code KEY_ADD_ACCOUNT_LIST} with unmatched accounts, or error map.
     */
    private HashMap processAccounts(ArrayList alFromSlidAccounts, ArrayList alToSlidAccounts) {
        String sMethodName = "processAccounts";
        HashMap hmResponse;
        ArrayList alReturnAccounts = new ArrayList();
        String sAppInfo;
        String sAppStatusCode;
        logger.info("{}{}PA000 : processAccounts start fromCount={} toCount={}", sClassName, sMethodName,
                (alFromSlidAccounts != null ? alFromSlidAccounts.size() : 0),
                (alToSlidAccounts != null ? alToSlidAccounts.size() : 0));
        logger.debug("{}{}PA000 : alFromSlidAccounts={} alToSlidAccounts={}", sClassName, sMethodName,
                alFromSlidAccounts, alToSlidAccounts);
        if(alFromSlidAccounts == null ||alFromSlidAccounts.isEmpty()){
            sAppInfo = "The accounts ArrayList for forSLID is null or empty";
            logger.info("{}{}PA001 : {} ", sClassName, sMethodName, sAppInfo);
            hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
            return hmResponse;
        }

        for (Object alFromSlidAccount : alFromSlidAccounts) {
            HashMap hmTempfromSlidAcc = (HashMap) alFromSlidAccount;

              if (hmTempfromSlidAcc != null && !hmTempfromSlidAcc.isEmpty()) {
                boolean isMatchFound = false;
                String stFromSlidSorInvariantId = (String) hmTempfromSlidAcc.get(MPSDefs.DB_SOR_INVARIANT_ID);
                String stFromSlidServiceId = (String) hmTempfromSlidAcc.get(MPSDefs.DB_SERVICE_ID);
                String stFromSlidServiceType = (String) hmTempfromSlidAcc.get(MPSDefs.DB_SERVICE_TYPE);
                ArrayList alFromSlidRoles = (ArrayList) hmTempfromSlidAcc.get(MPSDefs.DB_ROLES);

                if (alToSlidAccounts != null && !alToSlidAccounts.isEmpty()) {

                    for (Object alToSlidAccount : alToSlidAccounts) {
                        HashMap hmTempToSlidAcc = (HashMap) alToSlidAccount;

                        if (hmTempToSlidAcc != null && !hmTempToSlidAcc.isEmpty()) {
                            String stToSlidSorInvariantId = (String) hmTempToSlidAcc.get(MPSDefs.DB_SOR_INVARIANT_ID);
                            String stToSlidServiceId = (String) hmTempToSlidAcc.get(MPSDefs.DB_SERVICE_ID);
                            String stToSlidServiceType = (String) hmTempToSlidAcc.get(MPSDefs.DB_SERVICE_TYPE);

                            // Three-way match: SOR_INVARIANT_ID + SERVICE_TYPE + SERVICE_ID
                            // If all three match, the same account exists on both SLIDs —
                            // we reconcile roles instead of adding a duplicate account.
                            if (((stToSlidSorInvariantId != null && !stToSlidSorInvariantId
                                    .trim().isEmpty()) && stToSlidSorInvariantId
                                    .equalsIgnoreCase(stFromSlidSorInvariantId))
                                    && ((stToSlidServiceType != null && !stToSlidServiceType
                                    .trim().isEmpty()) && stToSlidServiceType
                                    .equalsIgnoreCase(stFromSlidServiceType))
                                    && ((stToSlidServiceId != null && !stToSlidServiceId
                                    .trim().isEmpty()) && stToSlidServiceId
                                    .equalsIgnoreCase(stFromSlidServiceId))) {
                                isMatchFound = true;
                                ArrayList alToSlidRoles = (ArrayList) hmTempToSlidAcc.get(MPSDefs.DB_ROLES);
                                hmResponse = processRoles(alFromSlidRoles, alToSlidRoles);
                                sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
                                if (!sAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                                    sAppInfo = "Error returned from processRoles()";
                                    logger.error("{}{}PA002 : {}", sClassName, sMethodName, sAppInfo);
                                    return hmResponse;
                                }
                                break;
                            }
                        }
                    }
                }
                if (!isMatchFound) {
                    alReturnAccounts.add(hmTempfromSlidAcc);
                }
            }
        }
        hmResponse = CommonErrorMap.makeCategoryMap(
                CommonDefs.COMMON_SUCCESS_NUM,
                CommonDefs.COMMON_SUCCESS_MSG);
        hmResponse.put(CommonDefs.KEY_ADD_ACCOUNT_LIST, alReturnAccounts);

        return hmResponse;
    }

    /**
     * Reconciles roles between a matched fromSLID account and toSLID account.
     *
     * <p>When the same account (by SOR_INVARIANT_ID + SERVICE_TYPE + SERVICE_ID) exists on both
     * SLIDs, this method determines what role updates are needed on toSLID. It handles three
     * scenarios:</p>
     *
     * <table border="1">
     *   <tr><th>fromSLID Role</th><th>toSLID Role</th><th>Action</th></tr>
     *   <tr><td>OWNER</td><td>OWNER</td>
     *       <td>If fromSLID role is ENABLED and toSLID role is not → update toSLID role status
     *           to ENABLED (added to {@code alMemberServiceRoleStatus}).</td></tr>
     *   <tr><td>AUTHORIZEDUSER</td><td>AUTHORIZEDUSER</td>
     *       <td>Same as OWNER/OWNER — enable the toSLID role if fromSLID role is enabled.</td></tr>
     *   <tr><td>OWNER</td><td>AUTHORIZEDUSER</td>
     *       <td>Promote: enable the toSLID role if not already enabled (added to
     *           {@code alMemberServiceRoleStatus}), <b>and</b> overwrite the toSLID’s
     *           {@code role_id} with the fromSLID’s {@code role_id} (added to
     *           {@code alMemberServiceRoleId}). This effectively "upgrades" the
     *           AUTHORIZEDUSER to OWNER-level access.</td></tr>
     * </table>
     *
     * <p><b>Note:</b> The for-loops over the role ArrayLists iterate to the <i>last</i>
     * element only (overwriting on each iteration), so each account is assumed to have
     * exactly one role entry. This mirrors the legacy MPS monolith behaviour.</p>
     *
     * @param alFromSlidRoles Roles from the fromSLID account (may be null/empty → no-op).
     * @param alToSlidRoles   Roles from the toSLID account (may be null/empty → no-op).
     * @return Success map with a {@code "RoleProcessed"} boolean flag.
     */
    private HashMap processRoles(ArrayList alFromSlidRoles, ArrayList alToSlidRoles){
        String sMethodName = "processRoles";
        HashMap hmResp = null;
        String stAppInfo = null;
        boolean isRoleProcessed = false;
        if(alFromSlidRoles == null || alFromSlidRoles.isEmpty()){
            stAppInfo = "Either both the fromSlid.roles and toSLid.roles " +
                    "are null or the fromSlid.role is null, returning success";
            logger.info("{}{}PR000 : {} ", sClassName, sMethodName, stAppInfo);
            hmResp = CommonErrorMap.makeCategoryMap(
                    CommonDefs.COMMON_SUCCESS_NUM,
                    CommonDefs.COMMON_SUCCESS_MSG);
            hmResp.put("RoleProcessed", isRoleProcessed);
            return hmResp;
        }
        // At this point alFromSlidRoles is guaranteed non-null and non-empty (checked above).
        // Proceed only if toSLID also has roles for this account.
        if(alToSlidRoles != null && !alToSlidRoles.isEmpty()){
            HashMap hmfromSlidRole = null;
            HashMap hmToSlidRole = null;
            // These loops iterate to the LAST element, effectively picking the single role entry.
            // Each account is expected to have exactly one role (OWNER or AUTHORIZEDUSER).
            for (Object alFromSlidRole : alFromSlidRoles) {
                hmfromSlidRole = (HashMap) alFromSlidRole;
            }
            for (Object alToSlidRole : alToSlidRoles) {
                hmToSlidRole = (HashMap) alToSlidRole;
            }

            String sFromSlidRoleName = (String)hmfromSlidRole.get(MPSDefs.DB_ROLE_NAME);
            String sFromSlidRoleId = (String)hmfromSlidRole.get(MPSDefs.DB_ROLE_ID);
            String sToSlidRoleId = (String)hmToSlidRole.get(MPSDefs.DB_ROLE_ID);
            String sToSlidRoleName = (String)hmToSlidRole.get(MPSDefs.DB_ROLE_NAME);
            String sToSlidSorInvariantId = (String)hmToSlidRole.get(MPSDefs.DB_SOR_INVARIANT_ID);
            String sToSlidSorId = (String)hmToSlidRole.get(MPSDefs.DB_SOR_ID);
            String sToSlidServiceId = (String)hmToSlidRole.get(MPSDefs.DB_SERVICE_ID);
            String sToSlidRoleStatus = (String)hmToSlidRole.get(MPSDefs.DB_ROLE_STATUS_NAME);
            String sFromSlidRoleStatus = (String)hmfromSlidRole.get(MPSDefs.DB_ROLE_STATUS_NAME);

            logger.info("{}{}PR001 : sFromSlidRoleName = {} :: sToSlidRoleName = {} :: " +
                            "sFromSlidRoleStatus = {} :: sToSlidRoleStatus = {} ", sClassName, sMethodName,
                    sFromSlidRoleName, sToSlidRoleName, sFromSlidRoleStatus, sToSlidRoleStatus);

            HashMap hmMemberServiceRoleStatus = null;
            HashMap hmMemberServiceRoleId = null;

            //1. If both roles are "OWNER" roles
            if((sFromSlidRoleName != null && sFromSlidRoleName.equalsIgnoreCase(CommonDefs.KEY_ROLE_NAME_OWNER))
                    && (sToSlidRoleName != null && sToSlidRoleName.equalsIgnoreCase(CommonDefs.KEY_ROLE_NAME_OWNER))){
                if(sFromSlidRoleStatus != null && sFromSlidRoleStatus.equalsIgnoreCase(MPSDefs.ENABLED)
                        && !sToSlidRoleStatus.equalsIgnoreCase(sFromSlidRoleStatus)){
                    hmMemberServiceRoleStatus = new HashMap();
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_SOR_INVARIANT_ID, sToSlidSorInvariantId);
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_ROLE_ID, sToSlidRoleId);
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_SOR_ID, sToSlidSorId);
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_SERVICE_ID, sToSlidServiceId);
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_OPERATION, CommonDefs.UPDATE_KEY);
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_ROLE_STATUS, MPSDefs.ENABLED);
                    alMemberServiceRoleStatus.add(hmMemberServiceRoleStatus);
                    isRoleProcessed =true;
                }

            //2. If both roles are "AUTHORIZEDUSER" roles
            }else if((sFromSlidRoleName != null
                    && sFromSlidRoleName.equalsIgnoreCase(CommonDefs.KEY_ROLE_NAME_AUTHORIZEDUSER)) && (sToSlidRoleName
                    != null && sToSlidRoleName.equalsIgnoreCase(CommonDefs.KEY_ROLE_NAME_AUTHORIZEDUSER))){
                if(sFromSlidRoleStatus != null && sFromSlidRoleStatus.equalsIgnoreCase(MPSDefs.ENABLED)
                        && !sToSlidRoleStatus.equalsIgnoreCase(sFromSlidRoleStatus)){
                    hmMemberServiceRoleStatus = new HashMap();
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_SOR_INVARIANT_ID, sToSlidSorInvariantId);
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_ROLE_ID, sToSlidRoleId);
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_SOR_ID, sToSlidSorId);
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_SERVICE_ID, sToSlidServiceId);
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_OPERATION, CommonDefs.UPDATE_KEY);
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_ROLE_STATUS, MPSDefs.ENABLED);
                    alMemberServiceRoleStatus.add(hmMemberServiceRoleStatus);
                    isRoleProcessed =true;
                }

            // 3. If the fromSlid role is an "OWNER" role and the toSlid role is an "AUTHORIZEDUSER" role
            }else if((sFromSlidRoleName != null && sFromSlidRoleName.equalsIgnoreCase(CommonDefs.KEY_ROLE_NAME_OWNER))
                    && (sToSlidRoleName != null &&
                    sToSlidRoleName.equalsIgnoreCase(CommonDefs.KEY_ROLE_NAME_AUTHORIZEDUSER))){
                if(!sToSlidRoleStatus.equalsIgnoreCase(MPSDefs.ENABLED)){
                    hmMemberServiceRoleStatus = new HashMap();
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_SOR_INVARIANT_ID, sToSlidSorInvariantId);
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_ROLE_ID, sToSlidRoleId);
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_SOR_ID, sToSlidSorId);
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_SERVICE_ID, sToSlidServiceId);
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_OPERATION, CommonDefs.UPDATE_KEY);
                    hmMemberServiceRoleStatus.put(MPSDefs.DB_ROLE_STATUS, MPSDefs.ENABLED);
                    alMemberServiceRoleStatus.add(hmMemberServiceRoleStatus);
                }

                hmMemberServiceRoleId = new HashMap();
                hmMemberServiceRoleId.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
                hmMemberServiceRoleId.put(MPSDefs.DB_SOR_INVARIANT_ID, sToSlidSorInvariantId);
                hmMemberServiceRoleId.put(MPSDefs.DB_ROLE_ID, sFromSlidRoleId);
                hmMemberServiceRoleId.put(MPSDefs.DB_SOR_ID, sToSlidSorId);
                hmMemberServiceRoleId.put(MPSDefs.DB_SERVICE_ID, sToSlidServiceId);
                alMemberServiceRoleId.add(hmMemberServiceRoleId);
                isRoleProcessed =true;
            }
        }
        hmResp = CommonErrorMap.makeCategoryMap(
                CommonDefs.COMMON_SUCCESS_NUM,
                CommonDefs.COMMON_SUCCESS_MSG);
        hmResp.put("RoleProcessed", isRoleProcessed);
        return hmResp;
    }

    /**
     * Performs two member-level DB updates as part of the merge:
     *
     * <ol>
     *   <li><b>Clear CBR opt-out flag:</b> If the toSLID has a {@code CBR_OPT_OUT} value set,
     *       this method clears it (sets to {@code null}) via {@link MemberDBHelper#processData(HashMap)}.
     *       This ensures the merged SLID does not inherit a stale opt-out preference.</li>
     *   <li><b>Insert user-merge audit record:</b> Inserts a row into the {@code USERMERGE} table
     *       recording the source member num/name, target member num/name, and the calling system ID.
     *       This provides an audit trail for the merge operation.</li>
     * </ol>
     *
     * @param hmFromSlidInfo SLID info map for the source (fromSLID).
     * @param hmToSlidInfo   SLID info map for the target (toSLID).
     * @return Success map on completion, or error map if either DB call fails.
     */
    private HashMap<String, Object> dbMemberUpdates(HashMap hmFromSlidInfo, HashMap hmToSlidInfo) {
        String sMethodName = "dbMemberUpdates";
        HashMap hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
        String stcbroptout = (String) hmToSlidInfo.get(MPSDefs.DB_CBR_OPT_OUT);
        if(stcbroptout != null && !stcbroptout.isEmpty()){
            ArrayList<HashMap<String, Object>> alMember = CommonUtil.getArrayList();
            HashMap<String, Object> hmMPSInput = CommonUtil.getHashMap();

            HashMap hmMember = CommonUtil.getHashMap();
            hmMember.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
            // Clear the CBR opt-out flag
            hmMember.put(MPSDefs.DB_CBR_OPT_OUT, null);
            hmMember.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);
            alMember.add(hmMember);
            hmMPSInput.put(CommonDefs.TRANSACTION_NAME, stTransactionName);
            hmMPSInput.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
            hmMPSInput.put(CommonDefs.TRANSACTION_ID, stTransactionId);
            hmMPSInput.put(MPSDefs.DB_MEMBER_TABLE, alMember);

            // updating cbr_opt_flag by calling MemberDBHelper.processData
            logger.debug("{}{}DUFM001 : Calling to MemberDBHelper.processData with HashMap : {}", sClassName,
                    sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmMPSInput)));
            hmResult = oMemberDBHelper.processData(hmMPSInput);
            logger.debug("{}{}DUFM002 : Response Hash from MemberDBHelper.processData is : {} ", sClassName,
                    sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmResult)));

            if (hmResult == null || hmResult.isEmpty()) {
                String stAppInfo = "Null/empty response returned from MemberDBHelper.processData";
                logger.error("{}{}DUFM002A : {}", sClassName, sMethodName, stAppInfo);
                return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
            }

            String stAppStatusCode = (String) hmResult.getOrDefault(CErrorDefs.COMMON_APP_STATUS_CODE, null);
            if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
                String stAppInfo = "Error returned after calling MemberDBHelper.processData";
                logger.info("{}{}DUFM002B : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }
        }

        HashMap hmInputToMerge = new HashMap();
        //TODO add these to CommonDefs
        hmInputToMerge.put("DB_SOURCE_MEMBER_NUM",hmFromSlidInfo.get(MPSDefs.DB_MEMBER_NUM));
        hmInputToMerge.put("DB_SOURCE_MEMBER_NAME",hmFromSlidInfo.get(MPSDefs.DB_MEMBER_NAME));
        hmInputToMerge.put("DB_TARGET_MEMBER_NUM",hmToSlidInfo.get(MPSDefs.DB_MEMBER_NUM));
        hmInputToMerge.put("DB_TARGET_MEMBER_NAME",hmToSlidInfo.get(MPSDefs.DB_MEMBER_NAME));
        hmInputToMerge.put(MPSDefs.DB_LAST_MODIFIED_BY,stCallingSystemId);

        // inserting into usermerge table by calling UserMergeDBHelper.insertUserMergeDetails
        logger.debug("{}{}DUFM003 : Calling to UserMergeDBHelper.insertUserMergeDetails with HashMap : {}", sClassName,
                sMethodName,HtmlUtils.htmlEscape(String.valueOf(hmInputToMerge)));
        hmResult = ouserMergeDBHelper.insertUserMergeDetails(hmInputToMerge);
        logger.debug("{}{}DUFM004 : Response Hash from UserMergeDBHelper.insertUserMergeDetails is : {} ", sClassName,
                sMethodName,HtmlUtils.htmlEscape(String.valueOf(hmResult)));

        return CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
    }

    /**
     * Deletes the fromSLID’s member/group records from the database.
     *
     * <p>The deletion strategy depends on the fromSLID’s {@code PARENT_CHILD_IND}:</p>
     * <ul>
     *   <li><b>Child ("C"):</b> Calls {@link DeleteMemberDBHelper#deleteMember(HashMap)} to
     *       remove the child member record from the {@code MEMBER} table.</li>
     *   <li><b>Parent ("P") or SLID ("S"):</b> Calls {@link DeleteMemberDBHelper#deleteGroup(HashMap)}
     *       to remove the group record from the {@code MEMBERGROUP} table.</li>
     * </ul>
     *
     * <p><b>Yahoo merged ID handling (US354404):</b> For SLID-type deletions, if the member name
     * contains an {@code @} sign and the domain is {@code yahoo.com}, the method reactivates
     * the Yahoo merged ID record (sets status from {@code MARK_DELETE} back to {@code ACTIVE})
     * so the Yahoo address can authenticate again after the SLID is deleted.</p>
     *
     * <p><b>FK safety (disabled):</b> For Parent and SLID types, calls to
     * {@link DeleteMemberDBHelper#clearSlidReferences(String)} are intentionally disabled
     * for performance. Legacy deleteUser never performed this cleanup, and the current flow
     * succeeds without FK violations. Re-enable only if {@code ORA-02292} on
     * {@code MEMBER.SLID_MEMBER_NUM} surfaces in production.</p>
     *
     * @param hmFromSlidInfo SLID info map for the fromSLID.
     * @return Success map on completion, or error map if any delete/update call fails.
     */
    private HashMap<String, Object> dbDeleteUser(HashMap hmFromSlidInfo) {
        String sMethodName = "dbDeleteUser";
        HashMap hmResult;
        boolean isParent = false;
        boolean isChild = false;
        boolean isSLID = false;
        String stAppInfo;
        String stAppStatusCode;
        String group_num = hmFromSlidInfo.get(MPSDefs.DB_GROUP_NUM).toString();
        String parentChildInd = hmFromSlidInfo.get(MPSDefs.DB_PARENT_CHILD_IND).toString();
        String member_state = hmFromSlidInfo.get(MPSDefs.DB_MEMBER_STATE).toString();
        String member_num = hmFromSlidInfo.get(MPSDefs.DB_MEMBER_NUM).toString();
        String member_name = hmFromSlidInfo.get(MPSDefs.DB_MEMBER_NAME).toString();
        String domain_name = CommonDefs.SLID_DUM;
        String last_modified_by = stCallingSystemId;

        if (parentChildInd.equals(MPSDefs.MPS_PARENT))
            isParent = true;
        else if (parentChildInd.equals(MPSDefs.MPS_CHILD))
            isChild = true;
        else if (parentChildInd.equals(MPSDefs.MPS_SLID))
            isSLID = true;

        logger.info("{}{}DDU000 : dbDeleteUser start memberNum={} parentChildInd={}", sClassName, sMethodName,
                member_num, parentChildInd);

        if(isChild){
            HashMap cInHs = CommonUtil.getHashMap();
            cInHs.put(MPSDefs.DB_MEMBER_NUM, member_num);
            hmResult = oDeleteMemberDBHelper.deleteMember(cInHs);

            if (hmResult == null) {
                stAppInfo = "Null Response returned from deleteMember()";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                logger.error("{}{}DUFM005 : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }
            stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
            if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                logger.error("{}{}DUFM006 : Failed to DeleteMember {} @ {}", sClassName, sMethodName,
                        member_name, domain_name);
                return hmResult;
            }
        }

        if (isParent)  {
            // Optional FK cleanup: clear IMEM_SLIDMEMNUM_FK (self-reference) before cascade delete
            // Intentionally disabled for performance; legacy deleteUser never did this, and current flow succeeds
            // without FK violations. Re-enable only if an ORA-02292 on MEMBER.SLID_MEMBER_NUM surfaces in prod.
/*            hmResult = oDeleteMemberDBHelper.clearSlidReferences(member_num);
            if (hmResult == null || !CommonDefs.COMMON_SUCCESS.equals(hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE))) {
                logger.info("{}{}PAM014A :  Failed to clearSlidReferences for parent : {} ", sClassName, sMethodName, member_num);
                return hmResult != null ? hmResult
                        : CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "Null from clearSlidReferences");
            }*/

            HashMap gInHs = CommonUtil.getHashMap();
            gInHs.put(MPSDefs.DB_GROUP_NUM, group_num);
            hmResult = oDeleteMemberDBHelper.deleteGroup(gInHs);

            if (hmResult == null) {
                stAppInfo = "Null Response returned from deleteGroup()";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                logger.error("{}{}PAM015 : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }
            stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
            if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                logger.error("{}{}PAM016 : Failed to deleteGroup: {}", sClassName, sMethodName, group_num);
                return hmResult;
            }
        }

        if (isSLID)  {
            // Optional FK cleanup: clear IMEM_SLIDMEMNUM_FK (self-reference) before cascade delete
            // Intentionally disabled for performance; legacy deleteUser never did this, and current flow succeeds
            // without FK violations. Re-enable only if an ORA-02292 on MEMBER.SLID_MEMBER_NUM surfaces in prod.
/*            hmResult = oDeleteMemberDBHelper.clearSlidReferences(member_num);
            if (hmResult == null || !CommonDefs.COMMON_SUCCESS.equals(hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE))) {
                logger.info("{}{}PAM014B :  Failed to clearSlidReferences for SLID : {} ", sClassName, sMethodName, member_num);
                return hmResult != null ? hmResult
                        : CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "Null from clearSlidReferences");
            }*/

            HashMap slidInHs = new HashMap();
            slidInHs.put(MPSDefs.DB_GROUP_NUM, group_num);
            hmResult = oDeleteMemberDBHelper.deleteGroup(slidInHs);

            if (hmResult == null) {
                stAppInfo = "Null Response returned from deleteGroup()";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                logger.error("{}{}PAM015 : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }
            stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
            if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                logger.error("{}{}PAM016 : Failed to deleteGroup: {}", sClassName, sMethodName, group_num);
                return hmResult;
            }

            /*US354404 -  update the Yahoo merged table (mark as active) as applicable when a SLID with a yahoo.com
            domain is deleted, to ensure that yahoo.com merged ids will be able to authenticate again if their
            corresponding SLID is renamed/deleted.*/
            if(member_name != null && member_name.indexOf("@") > 0){

                HashMap hmMergedYahooId  = new HashMap();
                String sMemNameDomain = member_name.substring(member_name.indexOf("@") + 1, member_name.length());
                if (sMemNameDomain.equalsIgnoreCase(CommonDefs.DOMAIN_YAHOO)){
                    if(stTransactionName != null && !stTransactionName.isEmpty()){
                        hmMergedYahooId.put(CommonDefs.TRANSACTION_NAME,stTransactionName);
                    }
                    if(stTransactionId != null && !stTransactionId.isEmpty()){
                        hmMergedYahooId.put(CommonDefs.TRANSACTION_ID,stTransactionId);
                    }
                    if(stCallingSystemId != null && !stCallingSystemId.isEmpty()){
                        hmMergedYahooId.put(CommonDefs.CALLING_SYSTEM_ID,stCallingSystemId);
                    }
                    hmMergedYahooId.put(CommonDefs.YAHOO_ID,member_name);

                    logger.debug("{}{}DUFM003 : Calling to MergeYahooIDDBHelper.getMergedYahooId with HashMap : {}",
                            sClassName,sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmMergedYahooId)));
                    hmResult = omergeYahooIDDBHelper.getMergedYahooId(hmMergedYahooId);
                    logger.debug("{}{}DUFM004 : Response Hash from MergeYahooIDDBHelper.getMergedYahooId is : {} ",
                            sClassName,sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmResult)));

                    if (hmResult == null) {
                        stAppInfo = "MergeYahooIDDBHelper.getMergedYahooId returned null response";
                        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                        logger.error("{}{}PAM015B : {}", sClassName, sMethodName, stAppInfo);
                        return hmResult;
                    }
                    stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                    if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                        logger.error("{}{}PAM016B : MergeYahooIDDBHelper.getMergedYahooId returned error: {}",
                                sClassName, sMethodName, hmResult);
                        return hmResult;
                    }

                    else{
                        HashMap hmMergedYahooResp = (HashMap)hmMergedYahooId.get(CommonDefs.MERGE_YAHOO_ID);
                        if(hmMergedYahooResp != null && !hmMergedYahooResp.isEmpty()){
                            String sStatus = (String)hmMergedYahooResp.get(MPSDefs.DB_STATUS);
                            String sMemberNum = (String)hmMergedYahooResp.get(MPSDefs.DB_MEMBER_NUM);

                            if(sStatus != null && sStatus.equals(CommonDefs.MARK_DELETE)){
                                hmMergedYahooId.put(MPSDefs.DB_STATUS, CommonDefs.ACTIVE);
                                hmMergedYahooId.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);

                                logger.debug("{}{}DUFM003 : Calling to " +
                                                "MergeYahooIDDBHelper.updateMergedYahooId with HashMap : {}",
                                        sClassName,sMethodName,HtmlUtils.htmlEscape(String.valueOf(hmMergedYahooId)));
                                hmResult = omergeYahooIDDBHelper.updateMergedYahooId(hmMergedYahooId);
                                logger.debug("{}{}DUFM004 : Response Hash from " +
                                                "MergeYahooIDDBHelper.updateMergedYahooId is : {} ", sClassName,
                                        sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmResult)));

                                if (hmResult == null) {
                                    stAppInfo = "MergeYahooIDDBHelper.updateMergedYahooId returned null response";
                                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                                    logger.error("{}{}PAM015B : {}", sClassName, sMethodName, stAppInfo);
                                    return hmResult;
                                }
                                stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                                if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                                    logger.error("{}{}PAM016B : MergeYahooIDDBHelper.updateMergedYahooId returned error: {}",
                                            sClassName, sMethodName, hmResult);
                                    return hmResult;
                                }
                            }
                        }
                    }
                }
            }
        }
        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
        return hmResult;
    }

    /**
     * Applies accumulated role updates to the database.
     *
     * <p>During {@link #processRoles(ArrayList, ArrayList)}, two types of role changes may be
     * collected:</p>
     * <ul>
     *   <li>{@code alMemberServiceRoleStatus} — role-status updates (e.g. enabling a disabled role).
     *       These are applied via {@link RolesDBHelper#updateRoleStatus(HashMap)}.</li>
     *   <li>{@code alMemberServiceRoleId} — role-ID updates (e.g. overwriting AUTHORIZEDUSER role_id
     *       with OWNER role_id). These are applied via {@link RolesDBHelper#updateRoleID(HashMap)}.</li>
     * </ul>
     *
     * <p>If neither list has entries, the method returns success immediately (no-op).</p>
     *
     * @return Success map on completion, or error map if either DB call fails.
     */
    private HashMap<String, Object> dbRoleUpdates(){
        String sMethodName = "dbRoleUpdates";
        HashMap hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
        if ((alMemberServiceRoleStatus != null && !alMemberServiceRoleStatus.isEmpty()) ||
                (alMemberServiceRoleId != null && !alMemberServiceRoleId.isEmpty())) {
            HashMap hmInputToUpdateRole = new HashMap();
            hmInputToUpdateRole.put(CommonDefs.TRANSACTION_ID, stTransactionId);
            hmInputToUpdateRole.put(CommonDefs.TRANSACTION_NAME, stTransactionName);
            hmInputToUpdateRole.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);

            if (alMemberServiceRoleStatus != null && !alMemberServiceRoleStatus.isEmpty()) {
                hmInputToUpdateRole.put(CommonDefs.KEY_UPDATE_ROLE_STATUS, alMemberServiceRoleStatus);
                hmResult = orolesDBHelper.updateRoleStatus(hmInputToUpdateRole);
                if (isErrorResponse(hmResult)) {
                    return hmResult;
                }
            }

            if (alMemberServiceRoleId != null && !alMemberServiceRoleId.isEmpty()) {
                hmInputToUpdateRole.put(CommonDefs.KEY_UPDATE_ROLE_ID, alMemberServiceRoleId);
                hmResult = orolesDBHelper.updateRoleID(hmInputToUpdateRole);
                if (isErrorResponse(hmResult)) {
                    return hmResult;
                }
            }

            if (!isMapNullOrEmpty(hmResult)) {
                hmResult.put(MPSDefs.APP_STATUS_CODE, hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE));
            }
        } else {
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
            hmResult.put(MPSDefs.APP_STATUS_CODE, hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE));
        }

        return hmResult;
    }

    /**
     * Prepares and publishes all DBUS events (MQ and/or AEH) to notify downstream consumers
     * of the merge operation.
     *
     * <p>This method assembles up to three categories of DBUS events:</p>
     * <ol>
     *   <li><b>DeleteMemberList</b> — notifies consumers that the fromSLID has been removed.
     *       Always emitted.</li>
     *   <li><b>AddMemberList (AddServicesList)</b> — notifies consumers that new service types
     *       have been added to toSLID. Emitted only when at least one service type is being
     *       added for the first time (ECOMM, MOBILITY, DTV, TITAN, MOSUB, dynamic access groups).
     *       For MOBILITY, the service type may be set to {@code PREPAID_SERVICE} or
     *       {@code MOBILITY_SERVICE} based on prepaid checks. MOSUB includes a decrypted
     *       {@code SOR_INVARIANT_ID} via {@link ProofingEncryptionHelper}.</li>
     *   <li><b>NotificationEvent (EDD)</b> — notifies email/SMS systems of the merge.
     *       Includes account list, old/new SLID, CPNI flag, contact email, auto-generated
     *       indicators, and Main CTN instance IDs when applicable.</li>
     * </ol>
     *
     * <p>In addition, any DBUS events from earlier unlink/link operations (captured in
     * {@code alProcessDbus} during {@link #unlinkAndLinkInternetAccount}) are included.</p>
     *
     * <p><b>Event routing:</b> Non-NotificationEvent events are sent to <b>AEH only</b>.
     * NotificationEvent routing is controlled by the IXP feature flag
     * {@code cfg-idgraph-mergeuseraccessid-notification-clm-switch} (MQ, AEH, or BOTH).</p>
     *
     * @param hmFromSlidInfo SLID info map for fromSLID (source).
     * @param hmToSlidInfo   SLID info map for toSLID (target).
     * @param hmInput        Original merge request input (for AEH context).
     * @return Success map on completion, or error map if any MQ/AEH call fails.
     */
    private HashMap<String, Object> sendMessageToMQ(HashMap hmFromSlidInfo, HashMap hmToSlidInfo, Map<String, Object> hmInput) {
        String sMethodName = "prepareDBUSInput";
        String stFromSlid = hmFromSlidInfo.get(MPSDefs.DB_MEMBER_NAME) != null ?
                hmFromSlidInfo.get(MPSDefs.DB_MEMBER_NAME).toString() : null;
        String stToSlid = hmToSlidInfo.get(MPSDefs.DB_MEMBER_NAME) != null ?
                hmToSlidInfo.get(MPSDefs.DB_MEMBER_NAME).toString() : null;
        logger.info("{}{}Preparing DBUS events for merge fromSLID={} toSLID={} txnId={}",
                sClassName, sMethodName, stFromSlid, stToSlid, stTransactionId);

        //1. Preparing the deleteMember HashMap and adding it to the alProcessDbus
        HashMap<String, Object> hmInputDelteMemberList = new HashMap<String, Object>();
        hmInputDelteMemberList.put(CommonDefs.EVENTNAME, CommonDefs.CONTEXT_DeleteMemberList);
        hmInputDelteMemberList.put(CommonDefs.SUBEVENT, CommonDefs.DBUS_NOTIFICATION_SUBEVENT_SLID);
        hmInputDelteMemberList.put(CommonDefs.MIGRATION_IND, CommonDefs.IND_N);
        hmInputDelteMemberList.put(CommonDefs.HANDLE, stFromSlid);
        hmInputDelteMemberList.put(CommonDefs.DOMAIN, CommonDefs.SLID_DUM);
        hmInputDelteMemberList.put(CommonDefs.ORIG_TRANSID, stTransactionId);
        hmInputDelteMemberList.put(MPSDefs.DB_SOR_NAME, CommonDefs.SOR_NA);
        hmInputDelteMemberList.put(CommonDefs.TRANSACTION_ID, stTransactionId);
        hmInputDelteMemberList.put(CommonDefs.TRANSACTION_NAME, stTransactionName);
        hmInputDelteMemberList.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
        hmInputDelteMemberList.put(CommonDefs.ORIG_TRANSACTION_NAME, stTransactionName);
        hmInputDelteMemberList.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
        hmInputDelteMemberList.put("hash_key", stFromSlidMemberNum);

        ArrayList<HashMap<String, Object>> alMemberinfo = new ArrayList<HashMap<String,Object>>();
        HashMap<String, Object> hmMemberInfo = new HashMap<String, Object>();
        hmMemberInfo.put(CommonDefs.HANDLE, stFromSlid);
        hmMemberInfo.put(CommonDefs.DOMAIN, CommonDefs.SLID_DUM);
        hmMemberInfo.put(MPSDefs.DB_MEMBER_NUM, stFromSlidMemberNum);
        hmMemberInfo.put(MPSDefs.DB_PARENT_CHILD_IND, MPSDefs.MPS_SLID);
        alMemberinfo.add(hmMemberInfo);
        hmInputDelteMemberList.put(CommonDefs.MEMBER_INFO, alMemberinfo);
        alProcessDbus.add(hmInputDelteMemberList);

        // 2. Build AddServicesList DBUS event.
        //    This event is emitted when at least one service type is NEW to the toSLID
        //    (i.e. toSLID had none of that type before the merge). For MOBILITY, it is
        //    always emitted because prepaid/postpaid type may change. Dynamic access
        //    groups that are new to toSLID also trigger this event.
        String stToSlidMigrationInd = (String)hmToSlidInfo.get(MPSDefs.DB_MIGRATION_IND);
        boolean addSvcEcomm  = (alToSlidECOMM == null || alToSlidECOMM.isEmpty()) && (alFromSlidECOMM != null && !alFromSlidECOMM.isEmpty());
        boolean addSvcMob    = (alFromSlidMOBILITY != null && !alFromSlidMOBILITY.isEmpty());
        boolean addSvcTitan  = (alToSlidTITAN == null || alToSlidTITAN.isEmpty()) && (alFromSlidTITAN != null && !alFromSlidTITAN.isEmpty());
        boolean addSvcMosub  = (alToSlidMOSUB == null || alToSlidMOSUB.isEmpty()) && (alFromSlidMOSUB != null && !alFromSlidMOSUB.isEmpty());
        boolean addSvcDtv    = (alToSlidDTV == null || alToSlidDTV.isEmpty()) && (alFromSlidDTV != null && !alFromSlidDTV.isEmpty());
        boolean addSvcDynGrp = (hmDynAccessGroupToBeAdded != null && !hmDynAccessGroupToBeAdded.isEmpty());
        boolean addSvcGate   = addSvcEcomm || addSvcMob || addSvcTitan || addSvcMosub || addSvcDtv || addSvcDynGrp;
        logger.info("{}{}AddServicesList gate={} [ecomm={}, mob={}, titan={}, mosub={}, dtv={}, dynGrp={}]",
                sClassName, sMethodName, addSvcGate, addSvcEcomm, addSvcMob, addSvcTitan, addSvcMosub, addSvcDtv, addSvcDynGrp);
        if(addSvcGate){

            HashMap<String, Object> hmInputToAddservicesList = new HashMap<String, Object>();
            hmInputToAddservicesList.put(CommonDefs.EVENTNAME, CommonDefs.CONTEXT_AddMemberList);
            hmInputToAddservicesList.put(CommonDefs.SUBEVENT, CommonDefs.DBUS_NOTIFICATION_SUBEVENT_SLID);
            hmInputToAddservicesList.put(CommonDefs.HANDLE, stToSlid);
            hmInputToAddservicesList.put(CommonDefs.DOMAIN, CommonDefs.SLID_DUM);
            hmInputToAddservicesList.put(CommonDefs.TRANSACTION_ID, stTransactionId);
            hmInputToAddservicesList.put(CommonDefs.TRANSACTION_NAME, stTransactionName);
            hmInputToAddservicesList.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
            hmInputToAddservicesList.put(CommonDefs.ORIG_TRANSACTION_NAME, stTransactionName);
            hmInputToAddservicesList.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
            hmInputToAddservicesList.put(MPSDefs.DB_SOR_NAME, CommonDefs.SOR_NA);
            hmInputToAddservicesList.put(MPSDefs.DB_MIGRATION_IND, stToSlidMigrationInd);
            hmInputToAddservicesList.put("hash_key", stFromSlidMemberNum);

            ArrayList<HashMap<String, Object>> alMemberAddInfo = new ArrayList<HashMap<String,Object>>();
            HashMap<String, Object> hmInfo = new HashMap<String, Object>();
            hmInfo.put(CommonDefs.HANDLE, stToSlid);
            hmInfo.put(CommonDefs.DOMAIN, CommonDefs.SLID_DUM);
            hmInfo.put(MPSDefs.DB_MEMBER_NUM, stToSlidMemberNum);
            hmInfo.put(MPSDefs.DB_PARENT_CHILD_IND, MPSDefs.MPS_SLID);

            ArrayList<HashMap<String, String>> alServices = new ArrayList<HashMap<String,String>>();

            if((alToSlidECOMM == null || alToSlidECOMM.isEmpty()) &&
                    (alFromSlidECOMM != null && !alFromSlidECOMM.isEmpty())){
                String stSorNameOfEcomm = null;
                for(int i = 0; i < alFromSlidECOMM.size(); i++){
                    HashMap hmService = (HashMap) alFromSlidECOMM.get(i);
                    if(hmService != null && !hmService.isEmpty()){
                        stSorNameOfEcomm = (String) hmService.get(MPSDefs.DB_SOR_NAME);
                        break;
                    }
                }
                if(stSorNameOfEcomm != null){
                    HashMap<String, String> hmTemp1 = new HashMap<String, String>();
                    hmTemp1.put(CommonDefs.SERVICE_STATUS, MPSDefs.ENABLED);
                    hmTemp1.put(MPSDefs.DB_SOR_NAME, stSorNameOfEcomm);
                    hmTemp1.put(CommonDefs.SERVICE_TYPE, CommonDefs.ECOMM_SERVICE);
                    hmTemp1.put(CommonDefs.MEMBER_STATUS, MPSDefs.ENABLED);
                    alServices.add(hmTemp1);
                }
            }

            // MOBILITY AddServicesList logic:
            //   Case 1: toSLID has NO mobility → add with from's type (prepaid or postpaid).
            //   Case 2: toSLID is postpaid, fromSLID is prepaid → add PREPAID_SERVICE entry.
            //   Case 3: toSLID is prepaid, fromSLID is postpaid → add MOBILITY_SERVICE entry.
            //   (If both same type, no AddServicesList entry needed for mobility.)
            if(alFromSlidMOBILITY != null && !alFromSlidMOBILITY.isEmpty()) {
                boolean mobilityServiceAdded = false;
                if (alToSlidMOBILITY == null || alToSlidMOBILITY.isEmpty()) {
                    HashMap<String, String> hmTemp1 = new HashMap<String, String>();
                    hmTemp1.put(CommonDefs.SERVICE_STATUS, MPSDefs.ENABLED);
                    hmTemp1.put(MPSDefs.DB_SOR_NAME, CommonDefs.SOR_MO);
                    if (checkPrepaidMobility(alFromSlidMOBILITY))
                        hmTemp1.put(CommonDefs.SERVICE_TYPE, CommonDefs.PREPAID_SERVICE);
                    else
                        hmTemp1.put(CommonDefs.SERVICE_TYPE, CommonDefs.MOBILITY_SERVICE);
                    hmTemp1.put(CommonDefs.MEMBER_STATUS, MPSDefs.ENABLED);
                    alServices.add(hmTemp1);
                    mobilityServiceAdded = true;
                } else if (!checkPrepaidMobility(alToSlidMOBILITY)
                        && checkPrepaidMobility(alFromSlidMOBILITY)) {
                    HashMap<String, String> hmTemp1 = new HashMap<String, String>();
                    hmTemp1.put(CommonDefs.SERVICE_STATUS, MPSDefs.ENABLED);
                    hmTemp1.put(MPSDefs.DB_SOR_NAME, CommonDefs.SOR_MO);
                    hmTemp1.put(CommonDefs.SERVICE_TYPE, CommonDefs.PREPAID_SERVICE);
                    hmTemp1.put(CommonDefs.MEMBER_STATUS, MPSDefs.ENABLED);
                    alServices.add(hmTemp1);
                    mobilityServiceAdded = true;
                } else if (checkPrepaidMobility(alToSlidMOBILITY)
                        && !checkPrepaidMobility(alFromSlidMOBILITY)) {
                    HashMap<String, String> hmTemp1 = new HashMap<String, String>();
                    hmTemp1.put(CommonDefs.SERVICE_STATUS, MPSDefs.ENABLED);
                    hmTemp1.put(MPSDefs.DB_SOR_NAME, CommonDefs.SOR_MO);
                    hmTemp1.put(CommonDefs.SERVICE_TYPE, CommonDefs.MOBILITY_SERVICE);
                    hmTemp1.put(CommonDefs.MEMBER_STATUS, MPSDefs.ENABLED);
                    alServices.add(hmTemp1);
                    mobilityServiceAdded = true;
                }

                // Fallback: when mobility gate is on but no specific prepaid/postpaid transition matched,
                // still emit a mobility AddServicesList entry so downstream sees the service type.
                if (!mobilityServiceAdded) {
                    HashMap<String, Object> hmFromMob = (HashMap) alFromSlidMOBILITY.get(0);
                    if (hmFromMob != null) {
                        HashMap<String, String> hmTemp1 = new HashMap<String, String>();
                        hmTemp1.put(CommonDefs.SERVICE_STATUS, MPSDefs.ENABLED);
                        hmTemp1.put(MPSDefs.DB_SOR_NAME, CommonDefs.SOR_MO);
                        hmTemp1.put(CommonDefs.SERVICE_TYPE,
                                checkPrepaidMobility(alFromSlidMOBILITY) ? CommonDefs.PREPAID_SERVICE : CommonDefs.MOBILITY_SERVICE);
                        hmTemp1.put(CommonDefs.MEMBER_STATUS, MPSDefs.ENABLED);
                        alServices.add(hmTemp1);
                    }
                }
            }

            if(hmDynAccessGroupToBeAdded != null && !hmDynAccessGroupToBeAdded.isEmpty()){
                for (String key : hmDynAccessGroupToBeAdded.keySet()) {
                    HashMap hmTemp1 = CommonUtil.getHashMap();
                    hmTemp1.put(CommonDefs.SERVICE_STATUS, MPSDefs.ENABLED);
                    hmTemp1.put(MPSDefs.DB_SOR_NAME, hmDynAccessGroupToBeAdded.get(key));
                    hmTemp1.put(CommonDefs.SERVICE_TYPE, key);
                    hmTemp1.put(CommonDefs.MEMBER_STATUS, MPSDefs.ENABLED);
                    alServices.add(hmTemp1);

                }
            }

            if((alToSlidDTV == null || alToSlidDTV.isEmpty()) &&
                    (alFromSlidDTV != null && !alFromSlidDTV.isEmpty())){
                HashMap<String, String> hmTemp1 = new HashMap<String, String>();
                hmTemp1.put(CommonDefs.SERVICE_STATUS, MPSDefs.ENABLED);
                hmTemp1.put(MPSDefs.DB_SOR_NAME, CommonDefs.SOR_DTV);
                hmTemp1.put(CommonDefs.SERVICE_TYPE, CommonDefs.UDTV_SERVICE);
                hmTemp1.put(CommonDefs.MEMBER_STATUS, MPSDefs.ENABLED);
                alServices.add(hmTemp1);
            }

            if((alToSlidTITAN == null || alToSlidTITAN.isEmpty()) &&
                    (alFromSlidTITAN != null && !alFromSlidTITAN.isEmpty())){

                HashMap<String, String> hmTemp1 = new HashMap<String, String>();
                hmTemp1.put(CommonDefs.SERVICE_STATUS, MPSDefs.ENABLED);
                hmTemp1.put(MPSDefs.DB_SOR_NAME, CommonDefs.SOR_LS);
                hmTemp1.put(CommonDefs.SERVICE_TYPE, "LS_ACCT");
                hmTemp1.put(CommonDefs.MEMBER_STATUS, MPSDefs.ENABLED);
                alServices.add(hmTemp1);
            }

            if ((alToSlidMOSUB == null || alToSlidMOSUB.isEmpty())
                    && (alFromSlidMOSUB != null && !alFromSlidMOSUB.isEmpty())) {
                HashMap<String, String> hmTemp1 = new HashMap<String, String>();
                HashMap hmFromSlidMosub = null;
                for (int i = 0; i < alFromSlidMOSUB.size(); i++) {
                    hmFromSlidMosub = (HashMap) alFromSlidMOSUB.get(i);
                }
                if (hmFromSlidMosub != null && !hmFromSlidMosub.isEmpty()) {
                    hmTemp1.put(CommonDefs.SERVICE_STATUS,(String) hmFromSlidMosub.get(MPSDefs.SERVICE_STATUS));
                    hmTemp1.put(MPSDefs.DB_SOR_NAME,(String) hmFromSlidMosub.get(MPSDefs.DB_SOR_NAME));
                    hmTemp1.put(CommonDefs.SERVICE_TYPE,(String) hmFromSlidMosub.get(MPSDefs.DB_SERVICE_NAME));
                    hmTemp1.put(CommonDefs.MEMBER_STATUS,(String) hmFromSlidMosub.get(MPSDefs.DB_MEMBER_STATUS_NAME));
                    hmTemp1.put(CommonDefs.INSTANCE_ID,(String) hmFromSlidMosub.get(MPSDefs.DB_INSTANCE_ID));
                    String dbSorInvariantId = (String) hmFromSlidMosub.get(MPSDefs.DB_SOR_INVARIANT_ID);

                    if (dbSorInvariantId != null && dbSorInvariantId.trim().length() > 0) {
                        HashMap hmRequest = CommonUtil.getHashMap();
                        hmRequest.put(CommonDefs.SOR_INVARIANT_ID,dbSorInvariantId);

                        HashMap hmDecryptionInput = CommonUtil.getHashMap();
                        hmDecryptionInput.put(CommonDefs.SOR_INVARIANT_ID, dbSorInvariantId);

                        logger.debug("{}{}PDI001 :calling ProofingEncryptionHelper.getDecryptedValues with input :{}"
                                , sClassName, sMethodName, hmDecryptionInput);
                        HashMap hmResponse = proofingEncryptionHelper.getDecryptedValues(hmDecryptionInput);
                        logger.debug("{}{}PDI002 :Response ProofingEncryptionHelper.getDecryptedValues :{}", sClassName
                                ,	sMethodName, hmResponse);

                        String stDecryptSorInvariantId = null;
                        if (hmResponse != null && hmResponse.containsKey(CommonDefs.SOR_INVARIANT_ID)) {
                            stDecryptSorInvariantId = (String) hmResponse.get(CommonDefs.SOR_INVARIANT_ID);
                        }
                        hmTemp1.put(CommonDefs.SOR_INVARIANT_ID, stDecryptSorInvariantId);
                    }
                    alServices.add(hmTemp1);
                }
            }
            hmInfo.put(CommonDefs.SERVICES, alServices);
            alMemberAddInfo.add(hmInfo);

            logger.info("{}{}AddServicesList serviceCount={}", sClassName, sMethodName, alServices.size());
            logger.debug("{}{}AddServicesList services={}", sClassName, sMethodName, alServices);
            if(alServices != null && !alServices.isEmpty()){
                hmInputToAddservicesList.put(CommonDefs.MEMBER_INFO, alMemberAddInfo);
                alProcessDbus.add(hmInputToAddservicesList);
                logger.info("{}{}AddServicesList event added to DBUS queue", sClassName, sMethodName);
            } else {
                logger.info("{}{}AddServicesList skipped — no services to add", sClassName, sMethodName);
            }
        } else {
            logger.info("{}{}AddServicesList skipped — gate is false", sClassName, sMethodName);
        }

        // 3. Build NotificationEvent (EDD) — informs email/SMS systems about the merge.
        //    Includes: old/new SLID, account list, CPNI flag, contact email, auto-generated
        //    indicator, and Main CTN instance IDs when fromSLID/toSLID have different MOSUBs.
        String stToSlidContactEmail = (String)hmToSlidInfo.get(MPSDefs.DB_CONTACT_EMAIL);
        String stToSlidContactEmailStatus = (String)hmToSlidInfo.get(MPSDefs.DB_CONTACT_EMAIL_STATUS);
        String stFromSlidContactEmail = (String)hmFromSlidInfo.get(MPSDefs.DB_CONTACT_EMAIL);
        String stFromSlidContactEmailStatus = (String)hmFromSlidInfo.get(MPSDefs.DB_CONTACT_EMAIL_STATUS);
        HashMap<String, Object> hmNotifyEvent = new HashMap<String, Object>();
        String stFromAutoGenInd = (String)hmFromSlidInfo.get(MPSDefs.DB_AUTOGENERATED_IND);
        String stToAutoGenInd = (String)hmToSlidInfo.get(MPSDefs.DB_AUTOGENERATED_IND);

        logger.info("{}{}NotificationEvent prep: isCPNI={}, notifyAccountCount={}",
                sClassName, sMethodName, isCPNILinkedToSLID,
                (alNotificationEventAccountList != null ? alNotificationEventAccountList.size() : 0));
        logger.debug("{}{}NotificationEvent detail: toContactEmail={}, fromContactEmail={}, accounts={}",
                sClassName, sMethodName, stToSlidContactEmail, stFromSlidContactEmail, alNotificationEventAccountList);
        // Fallback: ensure mobility merges surface in NotificationEvent even when no new mobility account
        // was added (e.g., same service type on both SLIDs). Use fromSLID mobility data.
        if ((alNotificationEventAccountList == null || alNotificationEventAccountList.isEmpty())
                && addSvcMob && alFromSlidMOBILITY != null && !alFromSlidMOBILITY.isEmpty()) {
            HashMap hmFromMob = (HashMap) alFromSlidMOBILITY.get(0);
            if (hmFromMob != null) {
                HashMap<String, Object> hmInputMobilityNotify = CommonUtil.getHashMap();
                hmInputMobilityNotify.put(MPSDefs.DB_SOR_NAME, hmFromMob.get(MPSDefs.DB_SOR_NAME));
                hmInputMobilityNotify.put(CommonDefs.SOR_INVARIANT_ID, hmFromMob.get(MPSDefs.DB_SOR_INVARIANT_ID));
                hmInputMobilityNotify.put(CommonDefs.ACCOUNT_TYPE, MPSDefs.MOBILITY_SERVICE);
                alNotificationEventAccountList.add(hmInputMobilityNotify);
                logger.info("{}{}NotificationEvent fallback — added MOBILITY account from fromSLID",
                        sClassName, sMethodName);
                logger.debug("{}{}NotificationEvent fallback entry={}", sClassName, sMethodName, hmInputMobilityNotify);
            }
        }
        if(alNotificationEventAccountList != null && !alNotificationEventAccountList.isEmpty()){
            hmNotifyEvent.put(CommonDefs.EVENTNAME, CommonDefs.CONTEXT_NotificationEvent);
            hmNotifyEvent.put(CommonDefs.SUBEVENT, CommonDefs.DBUS_NOTIFICATION_SUBEVENT_SLID);
            hmNotifyEvent.put(CommonDefs.HANDLE, hmToSlidInfo.get(MPSDefs.DB_MEMBER_NAME));
            hmNotifyEvent.put(CommonDefs.DOMAIN, CommonDefs.SLID_DUM);
            hmNotifyEvent.put(CommonDefs.TRANSACTION_ID, stTransactionId);
            hmNotifyEvent.put(CommonDefs.TRANSACTION_NAME, stTransactionName);
            hmNotifyEvent.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
            hmNotifyEvent.put(MPSDefs.DB_SOR_NAME, CommonDefs.SOR_NA);
            hmNotifyEvent.put(MPSDefs.DB_PARENT_CHILD_IND, MPSDefs.MPS_SLID);
            hmNotifyEvent.put(CommonDefs.OLD_SLID, stFromSlid);
            hmNotifyEvent.put(CommonDefs.NEW_SLID, stToSlid);
            hmNotifyEvent.put(CommonDefs.DBUS_DICTIONARY_NAME,CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
            hmNotifyEvent.put("hash_key", stFromSlidMemberNum);

            //Email/SMS Footnote Content-Changes to pass auto_generated_ind value in dbus i/p.
            if(stFromAutoGenInd != null && !stFromAutoGenInd.isEmpty()){
                hmNotifyEvent.put("oldSLIDAutoGenerated",stFromAutoGenInd);
            }
            if(stToAutoGenInd != null && !stToAutoGenInd.isEmpty()){
                hmNotifyEvent.put("newSLIDAutoGenerated",stToAutoGenInd);
            }

            hmNotifyEvent.put(CommonDefs.ACCOUNT_LIST, alNotificationEventAccountList);

            if(!isCPNILinkedToSLID){
                // When no CPNI-impacted account exists, provide contact email data
                // for notification delivery. Prefer fromSLID email; fall back to toSLID.
                Map<String, String> tempMap = new HashMap<>();
                if (stFromSlidContactEmail != null && !stFromSlidContactEmail.isEmpty()
                        && stFromSlidContactEmailStatus != null && !stFromSlidContactEmailStatus.isEmpty()){
                    tempMap.put(CommonDefs.CONTACT_EMAIL, stFromSlidContactEmail);
                    tempMap.put(CommonDefs.CONTACT_EMAIL_STATUS, stFromSlidContactEmailStatus);
                }else {
                    tempMap.put(CommonDefs.CONTACT_EMAIL, stToSlidContactEmail);
                    tempMap.put(CommonDefs.CONTACT_EMAIL_STATUS, stToSlidContactEmailStatus);
                }
                Map<String, Object> contactEmailMap = new HashMap<>();
                contactEmailMap.put(CommonDefs.MEMBER_CONTACT_EMAIL, Collections.singletonList(tempMap));

                hmNotifyEvent.put("isCPNILinkedToSLID", MPSDefs.NO);
                hmNotifyEvent.put(CommonDefs.NOTIFICATION_DATA, Collections.singletonList(contactEmailMap));

            }else{
                hmNotifyEvent.put("isCPNILinkedToSLID", MPSDefs.YES);
            }

            //To inform DBus when a Main CTN is being deleted from the <fromSLID>,
            // so that appropriate notification will be sent to the customer
            String stFromSlidMosubInstanceId = null;
            String stToSlidMosubInstanceId = null;

            if (alFromSlidMOSUB != null && !alFromSlidMOSUB.isEmpty()){
                for (Object o : alFromSlidMOSUB) {
                    HashMap hmFromSlidMosub = (HashMap) o;
                    if (hmFromSlidMosub != null && !hmFromSlidMosub.isEmpty()) {
                        if (hmFromSlidMosub.get(MPSDefs.DB_INSTANCE_ID) != null) {
                            stFromSlidMosubInstanceId = (String) hmFromSlidMosub.get(MPSDefs.DB_INSTANCE_ID);
                        }
                    }
                }
            }
            if(alToSlidMOSUB != null && !alToSlidMOSUB.isEmpty()){
                for (Object o : alToSlidMOSUB) {
                    HashMap hmToSlidMosub = (HashMap) o;
                    if (hmToSlidMosub != null && !hmToSlidMosub.isEmpty()) {
                        if (hmToSlidMosub.get(MPSDefs.DB_INSTANCE_ID) != null) {
                            stToSlidMosubInstanceId = (String) hmToSlidMosub.get(MPSDefs.DB_INSTANCE_ID);
                        }
                    }
                }

            }
            if(stFromSlidMosubInstanceId != null && !stFromSlidMosubInstanceId.isEmpty()&& stToSlidMosubInstanceId != null &&
                    !stToSlidMosubInstanceId.isEmpty() && !stFromSlidMosubInstanceId.equals(stToSlidMosubInstanceId)){
                hmNotifyEvent.put("fromSlidMainCTN",stFromSlidMosubInstanceId);
                hmNotifyEvent.put("toSlidMainCTN",stToSlidMosubInstanceId);

            }else if(stFromSlidMosubInstanceId != null && !stFromSlidMosubInstanceId.isEmpty()
                    && stToSlidMosubInstanceId == null){
                hmNotifyEvent.put("fromSlidMainCTN", stFromSlidMosubInstanceId);
            }
            alProcessDbus.add(hmNotifyEvent);
            logger.info("{}{}NotificationEvent added to DBUS queue", sClassName, sMethodName);
        } else {
            logger.info("{}{}NotificationEvent skipped — no accounts in notification list",
                    sClassName, sMethodName);
        }

        //4. Splitting events: NotificationEvent (flag-based MQ/AEH) vs other events (AEH only)
        logger.info("{}{}DBUS event split: totalEvents={}", sClassName, sMethodName, alProcessDbus.size());
        if (logger.isDebugEnabled()) {
            for (int i = 0; i < alProcessDbus.size(); i++) {
                HashMap<String, Object> hmEvt = (HashMap<String, Object>) alProcessDbus.get(i);
                logger.debug("{}{}DBUS event[{}]={}", sClassName, sMethodName, i, hmEvt.get(CommonDefs.EVENTNAME));
            }
        }
        ArrayList<HashMap<String, Object>> alNonNotificationEvents = new ArrayList<>();
        ArrayList<HashMap<String, Object>> alNotificationEvents = new ArrayList<>();
        for (Object eventObj : alProcessDbus) {
            HashMap<String, Object> hmEvent = (HashMap<String, Object>) eventObj;
            String stEventName = (String) hmEvent.get(CommonDefs.EVENTNAME);
            if (CommonDefs.CONTEXT_NotificationEvent.equalsIgnoreCase(stEventName)) {
                alNotificationEvents.add(hmEvent);
            } else {
                alNonNotificationEvents.add(hmEvent);
            }
        }

        HashMap hmResult;
        String stAppInfo;
        String stAppStatusCode;

        //4a. Send non-NotificationEvent events (DeleteMemberList, AddMemberList, Unlink/Link DBUS) to AEH only
        if (!alNonNotificationEvents.isEmpty()) {
            HashMap<String, Object> hmDbusInputAeh = CommonUtil.getHashMap();
            hmDbusInputAeh.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
            hmDbusInputAeh.put(CommonDefs.TRANSACTION_ID, stTransactionId);
            hmDbusInputAeh.put(CommonDefs.TRANSACTION_NAME, stTransactionName);
            hmDbusInputAeh.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
            hmDbusInputAeh.put(CommonDefs.EVENTNAME, ProfileOrchestrationConstants.MICROSERVICE_EVENT);
            hmDbusInputAeh.put(CommonDefs.MS_OPERTAION, stTransactionName);
            if (stFromSlid != null && !stFromSlid.isEmpty()) {
                hmDbusInputAeh.put(CommonDefs.MAIN_HASH_KEY, stFromSlid);
            }
            hmDbusInputAeh.put(CommonDefs.EVENTS_DATA, alNonNotificationEvents);

            logger.info("{}{}Sending {} non-notification event(s) to AEH",
                    sClassName, sMethodName, alNonNotificationEvents.size());
            Map<String, Object> hmResultAeh = publishMqAehHelper.handleAehOnly(hmDbusInputAeh, hmInput, sClassName, sMethodName);
            logger.debug("{}{}AEH response (non-notification): {}",
                    sClassName, sMethodName, hmResultAeh != null ? HtmlUtils.htmlEscape(String.valueOf(hmResultAeh)) : null);

            if (MapUtils.isEmpty(hmResultAeh)) {
                stAppInfo = "Null Response returned from AEH for non-NotificationEvent events";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                logger.error("{}{}AEH non-notification error: {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }
            stAppStatusCode = (String) hmResultAeh.get(CommonDefs.COMMON_APP_STATUS_CODE);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                stAppInfo = (String) hmResultAeh.get(CommonDefs.COMMON_APP_INFO);
                logger.error("{}{}AEH non-notification failure: statusCode={}, info={}",
                        sClassName, sMethodName, stAppStatusCode, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
                hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                return hmResult;
            }
        }

        //4b. Send NotificationEvent based on feature flag (MQ, AEH, or BOTH)
        if (!alNotificationEvents.isEmpty()) {
            HashMap<String, Object> hmDbusInputNotify = CommonUtil.getHashMap();
            hmDbusInputNotify.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
            hmDbusInputNotify.put(CommonDefs.TRANSACTION_ID, stTransactionId);
            hmDbusInputNotify.put(CommonDefs.TRANSACTION_NAME, stTransactionName);
            hmDbusInputNotify.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
            hmDbusInputNotify.put(CommonDefs.EVENTNAME, ProfileOrchestrationConstants.MICROSERVICE_EVENT);
            hmDbusInputNotify.put(CommonDefs.MS_OPERTAION, stTransactionName);
            if (stFromSlid != null && !stFromSlid.isEmpty()) {
                hmDbusInputNotify.put(CommonDefs.MAIN_HASH_KEY, stFromSlid);
            }
            hmDbusInputNotify.put(CommonDefs.EVENTS_DATA, alNotificationEvents);

            //clm switch
            String mergeUserNotificationClmEnabled = featureManager.getValue("cfg-idgraph-mergeuseraccessid-notification-clm-switch");
            mergeUserNotificationClmEnabled = (mergeUserNotificationClmEnabled != null && !mergeUserNotificationClmEnabled.isEmpty()) ? mergeUserNotificationClmEnabled : "MQ";
            logger.info("{}{}Sending NotificationEvent via CLM mode={}", sClassName, sMethodName, mergeUserNotificationClmEnabled);

            Map<String, Object> hmResultNotify = publishMqAehHelper.invokeMqAEH(
                    hmDbusInputNotify, hmInput, (List<Map<String, Object>>) (List<?>) alNotificationEvents,
                    sClassName, sMethodName, mergeUserNotificationClmEnabled, mergeUserNotificationClmEnabled);
            logger.debug("{}{}NotificationEvent response: {}",
                    sClassName, sMethodName, hmResultNotify != null ? HtmlUtils.htmlEscape(String.valueOf(hmResultNotify)) : null);

            if (MapUtils.isEmpty(hmResultNotify)) {
                stAppInfo = "Null Response returned for NotificationEvent";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                logger.error("{}{}NotificationEvent error: {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }
            stAppStatusCode = (String) hmResultNotify.get(CommonDefs.COMMON_APP_STATUS_CODE);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                stAppInfo = (String) hmResultNotify.get(CommonDefs.COMMON_APP_INFO);
                logger.error("{}{}NotificationEvent failure: statusCode={}, info={}",
                        sClassName, sMethodName, stAppStatusCode, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
                hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                return hmResult;
            }
        }

        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
        return hmResult;
    }


    /**
     * Determines whether any mobility account on the given SLID is a <b>prepaid</b> account.
     *
     * <p>The check inspects each mobility account’s {@code MEMBER_SERVICE_ATTRIBUTE} list for two
     * attributes: {@code MOBILITY_ACCOUNT_TYPE} and {@code MOBILITY_ACCOUNT_SUBTYPE}. Their
     * concatenated value is compared against the configurable prepaid account-type list
     * ({@code propPrepaidMOBILITYAccountTypeList}). If a match is found, the method returns
     * {@code true} immediately.</p>
     *
     * <p>This flag drives the service-type value in the AddServicesList DBUS event
     * ({@code PREPAID_SERVICE} vs {@code MOBILITY_SERVICE}).</p>
     *
     * @param alSlidMOBILITY Mobility account list for the SLID (from/to).
     * @return {@code true} if at least one prepaid mobility account is found.
     */
    private boolean checkPrepaidMobility(ArrayList alSlidMOBILITY) {
        String sMethodName = "checkPrepaidMobility";
        ArrayList<String> alPrepaidAcctTypes = CommonUtil.parseToArray(propPrepaidMOBILITYAccountTypeList,
                CommonDefs.VALUE_SEPARATOR_CHAR);

        boolean isprepaidMobility = false;
        if (alSlidMOBILITY != null && !alSlidMOBILITY.isEmpty()) {
            for (Object object : alSlidMOBILITY) {
                HashMap hmMOBILITY = (HashMap) object;
                if (hmMOBILITY != null && hmMOBILITY.get(CommonDefs.MEMBER_SERVICE_ATTRIBUTE) != null) {
                    ArrayList alMemberServiceAttrMap = (ArrayList) hmMOBILITY.get(CommonDefs.MEMBER_SERVICE_ATTRIBUTE);
                    if (alMemberServiceAttrMap != null && !alMemberServiceAttrMap.isEmpty()) {
                        boolean accountTypeFound = false;
                        boolean accountSubTypeFound = false;
                        String sAccountTypeValue = "";
                        String sAccountSubTypeValue = "";
                        for (Object o : alMemberServiceAttrMap) {
                            HashMap hmMemberServiceAttribute = (HashMap) o;
                            if (hmMemberServiceAttribute != null
                                    && (hmMemberServiceAttribute.get(CommonDefs.DB_ATTRIBUTE_NAME) != null
                                    || hmMemberServiceAttribute.get(CommonDefs.DB_ATTRIBUTE_VALUE) != null)) {

                                if (!accountTypeFound || !accountSubTypeFound) {
                                    if (CommonDefs.MOBILITY_ACCOUNT_TYPE.
                                            equals(hmMemberServiceAttribute.get(CommonDefs.DB_ATTRIBUTE_NAME))) {
                                        accountTypeFound = true;
                                        sAccountTypeValue = (String)
                                                hmMemberServiceAttribute.get(CommonDefs.DB_ATTRIBUTE_VALUE);
                                    } else if (CommonDefs.MOBILITY_ACCOUNT_SUBTYPE.
                                            equals(hmMemberServiceAttribute.get(CommonDefs.DB_ATTRIBUTE_NAME))) {
                                        accountSubTypeFound = true;
                                        sAccountSubTypeValue = (String)
                                                hmMemberServiceAttribute.get(CommonDefs.DB_ATTRIBUTE_VALUE);
                                    }
                                }
                            }

                            if (accountTypeFound && accountSubTypeFound &&
                                    alPrepaidAcctTypes.contains(sAccountTypeValue + sAccountSubTypeValue)) {
                                logger.info("{}{}CPM001 : Prepaid mobility found on the current account",
                                        sClassName, sMethodName);
                                isprepaidMobility = true;
                                break;
                            }

                        }
                    }
                }
            }

        }
        return isprepaidMobility;

    }

    /**
     * Looks up service reference data by {@code SERVICE_NAME}.
     *
     * <p>Iterates through the {@code services} map (loaded from the DB at merge start) and
     * returns a <b>copy</b> of the first service entry whose {@code DB_SERVICE_NAME} matches
     * the provided name. Returns {@code null} if no match is found.</p>
     *
     * @param serviceName The service type name to look up (e.g. {@code "ECOMM"}, {@code "VAS"}).
     * @return A defensive copy of the matching service metadata map, or {@code null}.
     */
    private HashMap<String, Object> getServiceDataByName(String serviceName) {
        ArrayList<HashMap<String, Object>> dbServicesList = null;
        if (services != null) {
            for (String dbServiceName : services.keySet()) {
                dbServicesList = (ArrayList<HashMap<String, Object>>) services.get(dbServiceName);
                if (dbServicesList != null && !dbServicesList.isEmpty()) {
                    HashMap<String, Object> hmIndividualService = (HashMap<String, Object>) dbServicesList.get(0);
                    if (hmIndividualService != null) {
                        String myServiceName = (String) hmIndividualService.get(MPSDefs.DB_SERVICE_NAME);
                        if (serviceName != null && myServiceName != null && serviceName.equals(myServiceName)) {
                            HashMap<String, Object> hmDupIndividualService = CommonUtil.getHashMap();
                            hmDupIndividualService.putAll(hmIndividualService);
                            return hmDupIndividualService;
                        }
                    }
                }
            }
        }
        return null;
    }

    /**
     * Looks up service reference data by {@code SERVICE_ID}.
     *
     * <p>Similar to {@link #getServiceDataByName(String)} but matches on
     * {@code DB_SERVICE_ID} instead. Used by {@link #processDynamicServices(ArrayList, ArrayList)}
     * to retrieve metadata (merge_action, single_instance, access_group) for a dynamic service.</p>
     *
     * @param serviceId The numeric service ID to look up.
     * @return A defensive copy of the matching service metadata map, or {@code null}.
     */
    private HashMap<String, Object> getServiceDataById(String serviceId) {
        ArrayList<HashMap<String, Object>> dbServicesList = null;
        if (services != null) {
            Iterator it = services.keySet().iterator();
            while(it.hasNext()) {
                String dbServiceName = (String)it.next();
                dbServicesList = (ArrayList)services.get(dbServiceName);
                if (dbServicesList != null && dbServicesList.size() > 0) {
                    HashMap<String, Object> hmIndividualService = (HashMap<String, Object>)dbServicesList.get(0);
                    if (hmIndividualService != null) {
                        String myServiceId = (String)hmIndividualService.get(MPSDefs.DB_SERVICE_ID);
                        if (serviceId != null && myServiceId != null && serviceId.equals(myServiceId)) {
                            HashMap<String, Object> hmDupIndividualService = CommonUtil.getHashMap();
                            hmDupIndividualService.putAll(hmIndividualService);
                            return hmDupIndividualService;
                        }
                    }
                }
            }
        }
        return null;
    }

    /**
     * Counts the total number of individual service instances on a SLID.
     *
     * <p>For each service type in the provided map, this method counts each instance-level
     * entry (identified by being a {@code HashMap} value rather than a metadata string).
     * If a service type has no instance-level entries (only metadata), it is counted as 1.</p>
     *
     * <p>Used by {@link #toSLIDSplitServices(Map)} to enforce the max-services-per-SLID limit.</p>
     *
     * @param hmToSlidServices The services map for the SLID being counted.
     * @param fromOrToSLID     Label string ({@code "fromSLID"} or {@code "toSLID"}) for logging.
     * @return Total count of service instances.
     */
    private int getToSlidTotalSvcsAccountsCount(HashMap<String, Object> hmToSlidServices, String fromOrToSLID) {
        String sMethodName = "getToSlidTotalSvcsAccountsCount";
        Iterator itrToSlidServiceKeys = hmToSlidServices.entrySet().iterator();
        Entry mapEntry	= null;
        HashMap hmServiceObject = null;
        int iToSlidTotalSvcsAccounts = 0;

        while(itrToSlidServiceKeys!=null && itrToSlidServiceKeys.hasNext()){
            mapEntry = (Entry)itrToSlidServiceKeys.next();
            hmServiceObject = CommonUtil.getHashMap();
            hmServiceObject = (HashMap)mapEntry.getValue();
            boolean bInstanceFlag = false;
            Iterator instanceIter = (Iterator) hmServiceObject.keySet().iterator();
            while (instanceIter != null && instanceIter.hasNext()) {
                String key = (String) instanceIter.next();
                Object value = null;
                if (key != null){
                    value = hmServiceObject.get(key);
                }
                if (value != null && value instanceof HashMap){
                    iToSlidTotalSvcsAccounts++;
                    bInstanceFlag = true;
                }
            }
            if(!bInstanceFlag) {
                iToSlidTotalSvcsAccounts++;
            }
        }
        logger.info("{}{}TSAC000 : TotalSvcsAccounts for {} is {}", sClassName, sMethodName,
                fromOrToSLID, iToSlidTotalSvcsAccounts);
        return iToSlidTotalSvcsAccounts;
    }

    /**
     * Resets all per-invocation instance fields to their initial empty state.
     *
     * <p>Called at the very start of {@link #mergeUserAccessId(Map)} (step 1) to ensure
     * no stale data from a previous invocation leaks into the current merge. Although
     * this bean is {@code @Scope("prototype")}, this explicit reset provides defence-in-depth.</p>
     */
    private void initialize() {
        hmFromSlidServices = CommonUtil.getHashMap();
        alFromSlidECOMM = CommonUtil.getArrayList();
        alFromSlidMOBILITY = CommonUtil.getArrayList();
        alFromSlidTITAN = CommonUtil.getArrayList();
        alFromSlidMOSUB = CommonUtil.getArrayList();
        alFromSlidDYNAMIC = CommonUtil.getArrayList();
        alFromSLIDWireLineDetails = CommonUtil.getArrayList();
        alFromSlidDTV = CommonUtil.getArrayList();
        alFromSlidLinkedUsers = CommonUtil.getArrayList();

        alToSlidECOMM = CommonUtil.getArrayList();
        alToSlidMOBILITY = CommonUtil.getArrayList();
        alToSlidTITAN = CommonUtil.getArrayList();
        alToSlidMOSUB = CommonUtil.getArrayList();
        alToSlidDYNAMIC = CommonUtil.getArrayList();
        alToSlidDTV = CommonUtil.getArrayList();
        alToSlidLinkedUsers = CommonUtil.getArrayList();
        hmToSlidServices = CommonUtil.getHashMap();
        alAddServiceList = CommonUtil.getArrayList();
        alAddToSlidAccounts = CommonUtil.getArrayList();
        alToSlidDynAccessGroup = CommonUtil.getArrayList();
        hmDynAccessGroupToBeAdded = CommonUtil.getHashMap();
        alNotificationEventAccountList = CommonUtil.getArrayList();
        alProcessDbus = CommonUtil.getArrayList();
        alMemberServiceRoleStatus = CommonUtil.getArrayList();
        alMemberServiceRoleId = CommonUtil.getArrayList();

        stFromSlidMemberNum = null;
        stFromSlidGroupNum = null;
        stToSlidMemberNum = null;
        stToSlidGroupNum = null;
        stCallingSystemId = null;
        stTransactionId = null;
        stTransactionName = null;

        toSLIDDefaultAccountExist = false;
        isCPNILinkedToSLID = false;
        services = CommonUtil.getHashMap();
    }

    /**
     * Checks whether a helper response map represents an error.
     *
     * @param hmResult response map returned by DB helper methods
     * @return true when response is null/empty or appStatusCode is not success
     */
    private boolean isErrorResponse(HashMap hmResult) {
        if (isMapNullOrEmpty(hmResult)) {
            return true;
        }

        String stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
        return !CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode);
    }

    /**
     * This method checks if a HashMap is null or empty.
     *
     * @param hmInput HashMap to be checked
     * @return boolean indicating if the HashMap is null or empty
     */
    private boolean isMapNullOrEmpty (Map hmInput) {
        return hmInput == null || hmInput.isEmpty();
    }


}
