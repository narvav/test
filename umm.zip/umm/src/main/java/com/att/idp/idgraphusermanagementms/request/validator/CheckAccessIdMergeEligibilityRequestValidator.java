package com.att.idp.idgraphusermanagementms.request.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import jakarta.ws.rs.core.HttpHeaders;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.resource.request.CheckAccessIdMergeEligibilityRequest;
import com.att.idp.idgraphusermanagementms.resource.response.CheckAccessIdMergeEligibilityResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;

/**
 * This class, CheckAccessIdMergeEligibilityRequestValidator, is responsible for validating the CheckAccessIdMergeEligibilityRequest.
 * It checks for the presence and validity of required fields in the request, and returns a CheckAccessIdMergeEligibilityResponse accordingly.
 * It is annotated with @Component, @Configuration, and @PropertySource to indicate that it's a Spring Bean,
 * to allow it to access configuration properties, and to specify the location of the properties file respectively.
 *
 * The class contains several methods, including:
 * - checkAccessIdMergeEligibilityRequestValidator: the main method that orchestrates the validation process.
 * - checkAccessIdMergeEligibilityErrorResponse: a helper method that generates an error response.
 * - checkAccessIdMergeEligibilityRequestInputValidator: a method that validates the input fields in the request.
 * - checkAccessIdMergeEligibilityIsExternalCallCheck: a method that checks the 'isExternalCall' field in the request.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class CheckAccessIdMergeEligibilityRequestValidator {
	private static final Logger logger = LoggerFactory.getLogger(CheckAccessIdMergeEligibilityRequestValidator.class);

	private String sClassName = "CheckAccessIdMergeEligibilityRequestValidator";

	@Value("${checkAccessIdMergeEligibility_ValidCallingSystemIds}")
	private String propCallingSystemIds;

	@Value("${checkAccessIdMergeEligibility_AgentCallingSystemIds}")
	private String propAgentIdRequiredCSI;

	/**
	 * This method is responsible for validating the CheckAccessIdMergeEligibilityRequest.
	 * It takes HttpHeaders and CheckAccessIdMergeEligibilityRequest as parameters.
	 * HttpHeaders contains the request headers which may include additional information required for processing the request.
	 * CheckAccessIdMergeEligibilityRequest encapsulates the details of the access ID merge eligibility check operation to be performed.
	 *
	 * The method performs various checks and validations on the input parameters and returns a CheckAccessIdMergeEligibilityResponse object.
	 * The CheckAccessIdMergeEligibilityResponse object encapsulates the result of the access ID merge eligibility check operation.
	 *
	 * @param requestHeader The HttpHeaders containing the request headers.
	 * @param checkAccessIdMergeEligibilityRequest The CheckAccessIdMergeEligibilityRequest containing the details of the access ID merge eligibility check operation.
	 * @return CheckAccessIdMergeEligibilityResponse The response of the access ID merge eligibility check operation.
	 */
	public CheckAccessIdMergeEligibilityResponse checkAccessIdMergeEligibilityRequestValidator(
			HttpHeaders requestHeader, CheckAccessIdMergeEligibilityRequest checkAccessIdMergeEligibilityRequest) {

		CheckAccessIdMergeEligibilityResponse checkAccessIdMergeEligibilityResponse = null;

		String stAppInfo = null;
		String sMethodName = ".checkAccessIdMergeEligibilityRequestValidator.";
		String stIdpTraceId = null;
		String callingSystemId = null;

		stIdpTraceId = CommonUtil.getTraceId(requestHeader);

		if (stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
			stAppInfo = "Missing or Invalid IdpTraceId";
			return checkAccessIdMergeEligibilityErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (checkAccessIdMergeEligibilityRequest == null) {
			stAppInfo = "Input Request is NULL / Empty.";
			logger.info("{}{}CAIMERV_102 :: {}", sClassName, sMethodName, stAppInfo);
			return checkAccessIdMergeEligibilityErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		
		checkAccessIdMergeEligibilityRequest.setIdpTraceId(stIdpTraceId);
		
		if (requestHeader.getHeaderString("X-ATT-ClientId") != null) {
			callingSystemId = requestHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
			logger.info("{}{}CAIMERV_101 : CheckAccessIdMergeEligibility Request x-att-clientid: {}", sClassName,
					sMethodName, StringUtils.normalizeSpace(callingSystemId));
			checkAccessIdMergeEligibilityRequest.setCallingSystemId(callingSystemId);
		} else {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			logger.info("{}{}CAIMERV_101.1 :: {}", sClassName, sMethodName, stAppInfo);
			return checkAccessIdMergeEligibilityErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		// checking Invalid attributes passed in Request
		Map<String, Object> allUnknownAttributes = new HashMap<>(checkAccessIdMergeEligibilityRequest.unknownAttributes);

		if (!allUnknownAttributes.isEmpty()) {
			stAppInfo = "Invalid Attributes passed in CheckAccessIdMergeEligibilityRequest : " + allUnknownAttributes;
			return checkAccessIdMergeEligibilityErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					checkAccessIdMergeEligibilityRequest.getIdpTraceId());
		}

		try {
			checkAccessIdMergeEligibilityResponse = checkAccessIdMergeEligibilityRequestInputValidator(
					checkAccessIdMergeEligibilityRequest);
			if (checkAccessIdMergeEligibilityResponse != null) {
				logger.info("{}{}CAIMERV_103 Response from checkAccessIdMergeEligibilityRequestInputValidator : {}",
						sClassName, sMethodName, checkAccessIdMergeEligibilityResponse);
				return checkAccessIdMergeEligibilityResponse;
			} else {
				logger.debug("{}{}CAIMERV_104 Success Response from addUserRequestInputValidator ", sClassName,
						sMethodName);
			}

			stAppInfo = "Input Validation Successful";
			logger.info("{}{}CAIMERV_110 : {}", sClassName, sMethodName, stAppInfo);

		} catch (Exception e) {
			stAppInfo = "Exception thrown in CheckAccessIdMergeEligibilityRequestValidator.checkAccessIdMergeEligibilityRequestValidator : "
					+ e.getMessage();
			checkAccessIdMergeEligibilityResponse = checkAccessIdMergeEligibilityErrorResponse(
					CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo, stIdpTraceId);
			logger.info("Exception in CheckAccessIdMergeEligibilityRequestValidator: {}", stAppInfo);
		}

		return checkAccessIdMergeEligibilityResponse;
	}

	@SuppressWarnings("unchecked")
	private CheckAccessIdMergeEligibilityResponse checkAccessIdMergeEligibilityRequestInputValidator(
			CheckAccessIdMergeEligibilityRequest checkAccessIdMergeEligibilityRequest) {

		CheckAccessIdMergeEligibilityResponse checkAccessIdMergeEligibilityResponse = null;
		String stAppInfo = null;
		String sMethodName = ".checkAccessIdMergeEligibilityRequestInputValidator.";
		String stTransactionName = "CheckAccessIdMergeEligibility";
		String stCallingSystemId = checkAccessIdMergeEligibilityRequest.getCallingSystemId();
		String stFromUserName = checkAccessIdMergeEligibilityRequest.getFromUserName();
		String stToUserName = checkAccessIdMergeEligibilityRequest.getToUserName();
		String stAgentId = checkAccessIdMergeEligibilityRequest.getAgentId();
		String stIdpTraceId = checkAccessIdMergeEligibilityRequest.getIdpTraceId();

		checkAccessIdMergeEligibilityResponse = checkAccessIdMergeEligibilityIsExternalCallCheck(
				checkAccessIdMergeEligibilityRequest);
		if (checkAccessIdMergeEligibilityResponse != null) {
			return checkAccessIdMergeEligibilityResponse;
		}

		Optional.ofNullable(stCallingSystemId)
				.ifPresent(x -> checkAccessIdMergeEligibilityRequest.setCallingSystemId(x.trim().toUpperCase()));

		Optional.ofNullable(stFromUserName)
				.ifPresent(x -> checkAccessIdMergeEligibilityRequest.setFromUserName(x.trim().toLowerCase()));

		Optional.ofNullable(stToUserName)
				.ifPresent(x -> checkAccessIdMergeEligibilityRequest.setToUserName(x.trim().toLowerCase()));

		Optional.ofNullable(stAgentId).ifPresent(x -> checkAccessIdMergeEligibilityRequest.setAgentId(x.trim()));

		if (!"CheckAccessIdMergeEligibility".equals(stTransactionName)) {
			stAppInfo = "Transaction Not Allowed :: TransactionName Should be CheckAccessIdMergeEligibility";
			logger.info("{}{}CAIMERV_104 : {}", sClassName, sMethodName, stAppInfo);
			return checkAccessIdMergeEligibilityErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		ArrayList<String> alValidCallers = CommonUtil.parseToArray(propCallingSystemIds,
				CommonDefs.VALUE_SEPARATOR_CHAR);
		logger.info("CAIMERV_107 : all Valid callers for checkAccessIdMergeEligibilityRequestInputValidator : {}",
				alValidCallers);

		stCallingSystemId = checkAccessIdMergeEligibilityRequest.getCallingSystemId();
		stAgentId = checkAccessIdMergeEligibilityRequest.getAgentId();

		if (alValidCallers != null && !alValidCallers.contains(stCallingSystemId)) {
			stAppInfo = "Input callingSystemId is not valid";
			logger.info("{}{}CAIMERV_108 : {}", sClassName, sMethodName, stAppInfo);
			return checkAccessIdMergeEligibilityErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		ArrayList<String> alAgentIdRequiredCSI = CommonUtil.parseToArray(propAgentIdRequiredCSI,
				CommonDefs.VALUE_SEPARATOR_CHAR);

		if (alAgentIdRequiredCSI.contains(stCallingSystemId) && (stAgentId == null || stAgentId.length() == 0)) {
			stAppInfo = "for CSRIDP call AgentID is required field in Request";
			logger.info("{}{}CAIMERV_109 : {}", sClassName, sMethodName, stAppInfo);
			return checkAccessIdMergeEligibilityErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		return checkAccessIdMergeEligibilityResponse;
	}

	private CheckAccessIdMergeEligibilityResponse checkAccessIdMergeEligibilityIsExternalCallCheck(
			CheckAccessIdMergeEligibilityRequest checkAccessIdMergeEligibilityRequest) {

		CheckAccessIdMergeEligibilityResponse checkAccessIdMergeEligibilityResponse = null;
		String stAppInfo;
		String isExternalCall = checkAccessIdMergeEligibilityRequest.getIsExternalCall();

		if ((isExternalCall != null && !isExternalCall.isEmpty())) {
			if (!(isExternalCall.equalsIgnoreCase(CommonDefs.IND_Y)
					|| isExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
				stAppInfo = "isExternalCall must be one of Y or N";
				return checkAccessIdMergeEligibilityErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						checkAccessIdMergeEligibilityRequest.getIdpTraceId());
			} else {
				checkAccessIdMergeEligibilityRequest.setIsExternalCall(isExternalCall.trim().toUpperCase());
			}
		} else {
			checkAccessIdMergeEligibilityRequest.setIsExternalCall(CommonDefs.IND_Y);
		}
		return checkAccessIdMergeEligibilityResponse;
	}

	private CheckAccessIdMergeEligibilityResponse checkAccessIdMergeEligibilityErrorResponse(int appStatusCode,
			String stAppInfo, String stIdpTraceId) {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		return CommonUtilHelper.generateCheckAccessIdMergeEligibilityResponse(hmResponse);
	}
}