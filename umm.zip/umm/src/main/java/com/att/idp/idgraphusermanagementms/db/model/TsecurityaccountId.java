package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class TsecurityaccountId implements Serializable {

	private static final long serialVersionUID = -5427272975876772971L;

	@Column(name = "IDENTIFICATION_TYPE", nullable = false, length = 10)
	private String identificationType;

	@Column(name = "ACCOUNT_ID", nullable = false, length = 60)
	private String accountId;

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TsecurityaccountId))
			return false;
		TsecurityaccountId castOther = (TsecurityaccountId) other;

		return ((this.getIdentificationType() == castOther.getIdentificationType())
				|| (this.getIdentificationType() != null && castOther.getIdentificationType() != null
				&& this.getIdentificationType().equals(castOther.getIdentificationType())))
				&& ((this.getAccountId() == castOther.getAccountId()) || (this.getAccountId() != null
				&& castOther.getAccountId() != null && this.getAccountId().equals(castOther.getAccountId())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getIdentificationType() == null ? 0 : this.getIdentificationType().hashCode());
		result = 37 * result + (getAccountId() == null ? 0 : this.getAccountId().hashCode());
		return result;
	}

}