package com.att.idp.idgraphusermanagementms.service;

import com.att.idp.idgraphusermanagementms.resource.request.UpdateUserPasswordRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdateUserPasswordResponse;

import jakarta.ws.rs.core.MultivaluedMap;
/**
 * This method is part of the UpdateUserPasswordService interface in the com.att.idp.idgraphusermanagementms.service package.
 *
 * The updateUserPassword method is used to perform the operation of updating a user's password.
 * It takes a UpdateUserPasswordRequest object and a MultivaluedMap of String to String as input.
 * The UpdateUserPasswordRequest object represents the request body, containing the details required for updating a user's password.
 * The MultivaluedMap represents the request headers.
 *
 * The method returns a UpdateUserPasswordResponse object, which represents the response from the operation of updating a user's password.
 */
public interface UpdateUserPasswordService {
    UpdateUserPasswordResponse updateUserPassword(UpdateUserPasswordRequest updateUserPasswordRequest, MultivaluedMap<String, String> requestHeader);
}
