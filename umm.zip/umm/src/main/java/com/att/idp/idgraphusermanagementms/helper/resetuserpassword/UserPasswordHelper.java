package com.att.idp.idgraphusermanagementms.helper.resetuserpassword;

import java.net.InetAddress;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import com.att.mpsys.common.utils.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.db.helper.FraudLockDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.MemberDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.UpdateDBHelper;
import com.att.idp.idgraphusermanagementms.helper.voltage.ProofingEncryptionHelper;
import com.att.idp.idgraphusermanagementms.queue.message.sender.JMSQueueSender;
import com.att.idp.idgraphusermanagementms.utils.RILCheckAndEncryptPasswordHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.helpers.ConvertServicesHelper;

/**
 * This class is a helper class for managing user passwords.
 * It contains methods for processing password changes, resetting passwords, checking for fraud passwords, and more.
 * It also interacts with other helper classes such as LockoutHelper, UpdateDBHelper, MemberDBHelper, and others.
 * The class is annotated with @Component, indicating that it is an auto-detectable Spring bean.
 * It also uses the @PropertySource annotation to specify the location of a properties file.
 * The class contains several instance variables that are autowired, meaning that Spring will automatically handle their instantiation.
 * The class also contains a static final Logger instance for logging purposes.
 */
@Component
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class UserPasswordHelper {

	@Autowired
	private RILCheckAndEncryptPasswordHelper passwordHelper;

	@Autowired
	private LockoutHelper oLockoutHelper;

	@Autowired
	private UpdateDBHelper updateDBHelper;

	@Autowired
	private MemberDBHelper memberDBHelper;

	@Autowired
	private MemberLockoutDbHelper oMPSDB_TMEMBERLOCKOUT_H;

	@Autowired
	private FraudLockDBHelper fraudLockDBHelper;

	@Autowired
	private ConvertServicesHelper oConvertServicesHelper;

	@Autowired
	private QueryProfileProofingInfoHelper oQueryProfileProofingInfo_H;

	@Autowired
	private ProofingEncryptionHelper oProofingEncryption_H;

	
	
	@Autowired
	private JMSQueueSender oJMSQueueSender;
	
	private static final String info = "$Id: master/com/att/mpsys/common/helpers/UserPasswordHelper.java v1 2021-07-27 pm675e $;" ;
	private static final String sClassName = "UserPasswordHelper";
	private static final Logger log = LoggerFactory.getLogger(UserPasswordHelper.class);

	private PropertyManagerLoader propertyManagerLoader;
	public UserPasswordHelper(PropertyManagerLoader propertyManagerLoader) {
		this.propertyManagerLoader = propertyManagerLoader;
	}

	/**
	 * This method is used to process a password change request.
	 * It takes three HashMaps as input. The first HashMap contains input parameters for the method,
	 * the second HashMap contains information about the member from the database,
	 * and the third HashMap contains information about the parent member from the database.
	 * The method performs various operations such as checking for fraud passwords, processing lockout rules,
	 * updating the member's password in the database, and sending notifications.
	 * It handles various scenarios such as silent updates, password validation skips, and password generation.
	 * The method also interacts with other helper classes such as RILCheckAndEncryptPasswordHelper, LockoutHelper, UpdateDBHelper, and others.
	 * It returns a HashMap containing the result of the password change process.
	 *
	 * @param hmInput HashMap containing the input parameters for the method.
	 * @param hmMemberDB HashMap containing the member information from the database.
	 * @param hmParentDB HashMap containing the parent member information from the database.
	 * @return HashMap containing the result of the password change process.
	 */
	@org.springframework.transaction.annotation.Transactional
	public HashMap processChangePassword(HashMap hmInput, HashMap hmMemberDB, HashMap hmParentDB) {

		String sMethodName = ".processChangePassword.";

		HashMap hmResult = null;
		String sAppInfo = null;
		String sAppStatusCode = null;
		ArrayList alLinkedUsers = CommonUtil.getArrayList();
		ArrayList alDbus = CommonUtil.getArrayList();

		log.info(sClassName + sMethodName + "CVS000 : CVS KEYWORDS: : " + info);
		log.info(SpiMarker.getInstance(), sClassName + sMethodName + "CPH1-1 : processChangePassword() Input Hash : {}" , hmInput);

		try {
			String sIsUpdateSilent = (String) hmInput.get("isUpdateSilent");
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
			String sTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);
			// 1808: PID:304635 - To check if the input password is same as any of the fraud
			// password stored for that accessId
			String sCheckFraudPassword = (String) hmInput.get("checkFraudPassword");

			String handle = (String) hmMemberDB.get(MPSDefs.DB_MEMBER_NAME);
			String domain = (String) hmMemberDB.get(MPSDefs.DB_DOMAIN_NAME);

			HashMap hmPwdInp = CommonUtil.getHashMap();

			if (handle != null && domain != null) {
				hmPwdInp.put(MPSDefs.WS_USER_ID, handle);
				hmPwdInp.put(MPSDefs.WS_DOMAIN, domain);
			}

			hmPwdInp.put(MPSDefs.WS_CLEAR_TEXT, hmInput.get("newPassword"));
			hmPwdInp.put(MPSDefs.WS_CALLING_SYSTEM_ID, sCallingSystemId);
			hmPwdInp.put(MPSDefs.WS_TRANSACTION_NAME, sTransactionName);
			hmPwdInp.put("tempGenerated", hmInput.get("tempGenerated"));
			
			hmInput.put(CommonDefs.CLEAR_PASSWORD, hmInput.get("newPassword"));	
			//1907:Update microservice ManageOnlineUserProfile UpdateUserPasswordHelper in support of new user password creation rules.
			if(hmInput.get(CommonDefs.CONTACT_EMAIL) != null)
			hmPwdInp.put(CommonDefs.CONTACT_EMAIL, (String) hmInput.get(CommonDefs.CONTACT_EMAIL));
			
			if(hmInput.get(CommonDefs.FIRST_NAME) != null)
			hmPwdInp.put(CommonDefs.FIRST_NAME, (String) hmInput.get(CommonDefs.FIRST_NAME));
			
			if(hmInput.get(CommonDefs.LAST_NAME) != null)
			hmPwdInp.put(CommonDefs.LAST_NAME, hmInput.get(CommonDefs.LAST_NAME));
			
			if(hmInput.get(CommonDefs.MAIN_CTN) != null)
			hmPwdInp.put(CommonDefs.MAIN_CTN, (String) hmInput.get(CommonDefs.MAIN_CTN));	
																				

			if (sCallingSystemId != null && sCallingSystemId.equalsIgnoreCase(CommonDefs.SOR_CPR)
					&& sTransactionName != null
					&& sTransactionName.equalsIgnoreCase("ChangeMemberPassword")) {
				String sSkipPasswordValidation = PropertyManager.getProperty(CommonDefs.MOUPConfig,
						CommonDefs.SKIP_PASSWORD_VALIDATION);
				if (sSkipPasswordValidation != null && sSkipPasswordValidation.length() > 0)
					hmPwdInp.put(CommonDefs.SKIP_PASSWORD_VALIDATION, sSkipPasswordValidation);
			}

			// 1708 R : 293904a-DTVNOW migration to DFW : MPSYS-US2
			if (sIsUpdateSilent != null && sIsUpdateSilent.equalsIgnoreCase("Y")) {
				String sSkipPasswordValidation = PropertyManager.getProperty(CommonDefs.MOUPConfig,
						CommonDefs.SKIP_PASSWORD_VALIDATION);
				if (sSkipPasswordValidation != null && sSkipPasswordValidation.length() > 0) {
					hmPwdInp.put(CommonDefs.SKIP_PASSWORD_VALIDATION, sSkipPasswordValidation);
				}
			}
			
			if(sTransactionName.equalsIgnoreCase("ResetMemberPassword")) {
				log.info(sClassName + sMethodName + "CPH1-5F : Setting skipPasswordValidation flag to Y");
				hmPwdInp.put(CommonDefs.SKIP_PASSWORD_VALIDATION, "Y");
			}

			String sRegType = (String) hmInput.get(CommonDefs.REG_TYPE);
			if (sRegType != null && sRegType.equals(CommonDefs.LS_REG_EXISTING)) {
				log.info(SpiMarker.getInstance(), sClassName + sMethodName + "CPH1-2A : Request to generateAllPasswords = {}", StringUtils.normalizeSpace(hmPwdInp.toString()));
				hmResult = passwordHelper.generateAllPasswords(hmPwdInp, log);
				log.info(sClassName + sMethodName + "CPH1-2B : Response from generateAllPasswords = " + StringUtils.normalizeSpace(hmResult.toString()));
			} else {
				log.info(SpiMarker.getInstance(), sClassName + sMethodName + "CPH1-2A : Request to checkAndEncryptPassword = {}", StringUtils.normalizeSpace(hmPwdInp.toString()));
				hmResult = passwordHelper.checkAndEncryptPassword(hmPwdInp);
				log.info(sClassName + sMethodName + "CPH1-2B : Response from checkAndEncryptPassword = " + StringUtils.normalizeSpace(hmResult.toString()));
			}

			sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
			if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
				log.info(sClassName + sMethodName + "CPH1-3 : Error returned from RILCheckAndEncryptPasswordHelper : "
						+ StringUtils.normalizeSpace(hmResult.toString()));
				return hmResult;
			}

			HashMap hmInHs = CommonUtil.getHashMap();
			hmInHs.putAll(hmInput);

			// Add encrypted passwords to inputHash
			hmInHs.put(CommonDefs.DB_ENC_PASSWORD, hmResult.get(MPSDefs.DB_ENC_PASSWORD));
			hmInHs.put(CommonDefs.DB_MD5_PASSWORD, hmResult.get(MPSDefs.DB_MD5_PASSWORD));
			hmInHs.put(CommonDefs.DB_SHA1_PASSWORD, hmResult.get(MPSDefs.DB_SHA1_PASSWORD));
			hmInHs.put(CommonDefs.DB_DES3_PASSWORD, hmResult.get(MPSDefs.DB_DES3_PASSWORD));
			hmInHs.put(CommonDefs.PASSWORD_TYPE, hmResult.get(CommonDefs.PASSWORD_TYPE));
			// 2103 - Added SSHA-256 encryption changes
			if (hmResult.get(MPSDefs.DB_GEN_PASSWORD) != null) {

				hmInHs.put(CommonDefs.DB_GEN_PASSWORD, hmResult.get(MPSDefs.DB_GEN_PASSWORD)); 
				hmInHs.put(CommonDefs.DB_GEN_PASSWORD_TYPE, hmResult.get(MPSDefs.DB_GEN_PASSWORD_TYPE));

			}
			 
			// 1808: PID:304635 - To check if the input password is same as any of the fraud
			// password stored for that accessId
			if (sCheckFraudPassword != null && sCheckFraudPassword.equals(MPSDefs.YES)) {
				log.info(sClassName + sMethodName + "CPH1-30 : Request to processCheckFraudPassword = " + hmInHs);
				hmResult = processCheckFraudPassword(hmInHs, hmMemberDB);
				log.info(sClassName + sMethodName + "CPH1-31 : Response from processCheckFraudPassword = " + hmResult);

				sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
				if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
					log.info(sClassName + sMethodName + "CPH1-32 : Error returned from processCheckFraudPassword."
							+ hmResult);
					return hmResult;
				}
			}

			// set passwordDirty and sendNotificationEmail fields
			// set default to 'N' if null
			String passwordDirty = (String) hmInHs.get(CommonDefs.PASSWORD_DIRTY);
			String sendNotificationEmail = (String) hmInHs.get(CommonDefs.SEND_NOTIFICATION_EMAIL);

			if (passwordDirty == null || passwordDirty.trim().length() == 0) {
				hmInHs.put(CommonDefs.PASSWORD_DIRTY, "N");
			}
			if (sendNotificationEmail == null || sendNotificationEmail.trim().length() == 0) {
				hmInHs.put(CommonDefs.SEND_NOTIFICATION_EMAIL, "N");
			}

			//hmInHs.put(CommonDefs.VALIDATION_STATUS, CommonDefs.VALIDATION_STATUS_SUCCESS);

			String sMemberNum = (String) hmMemberDB.get(MPSDefs.DB_MEMBER_NUM);
			String sSlidMemberNum = (String) hmMemberDB.get(MPSDefs.DB_SLID_MEMBER_NUM);

			// Add handle and domain (from hmMemberDB) to inHS for use in doMPS()
			//hmInHs.put(CommonDefs.HANDLE, hmMemberDB.get(MPSDefs.DB_MEMBER_NAME));
			//hmInHs.put(CommonDefs.DOMAIN, hmMemberDB.get(MPSDefs.DB_DOMAIN_NAME));

			String sValidateCredentials = (String) hmInHs.get(CommonDefs.VALIDATE_CREDENTIALS);
			sValidateCredentials = (sValidateCredentials == null) ? "" : sValidateCredentials;

			HashMap hmDBServices = (HashMap) hmMemberDB.get(CommonDefs.SERVICES);

			HashMap hmMemberDataInput = CommonUtil.getHashMap();
			HashMap hmMemberData = CommonUtil.getHashMap();
			boolean isUpdateRequired = false;
			boolean isLinkedUsers = false;
			ArrayList alMemberLockout = CommonUtil.getArrayList();
			ArrayList alUserFraudLock = CommonUtil.getArrayList();

			HashMap hmSlidInfo = (HashMap) hmMemberDB.get(MPSDefs.KEY_SLID_INFO);
			if (hmSlidInfo != null && !hmSlidInfo.isEmpty()) {
				if(hmSlidInfo.containsKey(MPSDefs.KEY_LINKED_USERS)){
					isLinkedUsers = true;
					ArrayList alDBLinkedUsers = (ArrayList) hmSlidInfo.get(MPSDefs.KEY_LINKED_USERS);
					alLinkedUsers = getInterestedLinkedUsers(alDBLinkedUsers, sMemberNum);
					
					if(domain != null && !domain.equals("slid.dum")){
						HashMap hmThisMemberDB = CommonUtil.getHashMap();
						hmThisMemberDB.putAll(hmSlidInfo);
						hmThisMemberDB.remove(MPSDefs.KEY_LINKED_USERS);
						alLinkedUsers.add(hmThisMemberDB);
					}
				}
			}

			if (!isLinkedUsers) {
				hmMemberDataInput.put(MPSDefs.DB_MEMBER_NUM, hmInHs.get(CommonDefs.MEMBER_NUM));
				hmMemberDataInput.put(CommonDefs.HANDLE, hmInHs.get(CommonDefs.HANDLE));
				hmMemberDataInput.put(CommonDefs.DOMAIN, hmInHs.get(CommonDefs.DOMAIN));
			}

			hmMemberDataInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
			hmMemberDataInput.put(CommonDefs.TRANSACTION_NAME, hmInHs.get(CommonDefs.TRANSACTION_NAME));
			hmMemberDataInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInHs.get(CommonDefs.CALLING_SYSTEM_ID));

			String sValidateStatus = (String) hmInHs.get(CommonDefs.VALIDATION_STATUS);
			sValidateStatus = (sValidateStatus == null) ? CommonDefs.VALIDATION_STATUS_SUCCESS : sValidateStatus;

			String sProcessLocks = (String) hmInput.get("PROCESS_LOCKS");
			sProcessLocks = (sProcessLocks == null) ? CommonDefs.DEFAULT_YES : sProcessLocks;

			if (sProcessLocks.equals(CommonDefs.DEFAULT_YES)) {
				hmResult = processLocks(hmInHs, hmMemberDB);
				sAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

				if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
					return hmResult;

				if (hmResult.containsKey(MPSDefs.DB_MEMBERLOCKOUT)) {
					alMemberLockout = (ArrayList) hmResult.get(MPSDefs.DB_MEMBERLOCKOUT);
					isUpdateRequired = true;
				}
			}
			
			// 1510 US195227 - Processing fraud lock for DB updates
			if (hmInput.containsKey("PROCESS_USER_FRAUD_LOCKS")
					&& !sValidateCredentials.equals(CommonDefs.DEFAULT_YES)) {
				HashMap hmUserFraudLock = CommonUtil.getHashMap();
				hmUserFraudLock.put(MPSDefs.DB_MEMBER_NUM, hmMemberDB.get(MPSDefs.DB_SLID_MEMBER_NUM));
				hmUserFraudLock.put(MPSDefs.DB_USER_LOCK_LEVEL, null);
				hmUserFraudLock.put(MPSDefs.DB_USER_LOCK_REASON, null);
				hmUserFraudLock.put(MPSDefs.DB_FRAUD_AGENT, null);
				hmUserFraudLock.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);
				hmUserFraudLock.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
				alUserFraudLock = CommonUtil.getArrayList();
				alUserFraudLock.add(hmUserFraudLock);
			}

			ArrayList alMemberData = CommonUtil.getArrayList();

			if (sValidateStatus.equals(CommonDefs.VALIDATION_STATUS_SUCCESS)
					&& !sValidateCredentials.equals(CommonDefs.DEFAULT_YES)) {
				hmMemberData.put(MPSDefs.DB_MEMBER_NUM, hmMemberDB.get(CommonDefs.DB_MEMBER_NUM));

				if (!isLinkedUsers)
					hmMemberData.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);

				hmMemberData.put(MPSDefs.DB_ENC_PASSWORD, hmInHs.get(CommonDefs.DB_ENC_PASSWORD));
				hmMemberData.put(MPSDefs.DB_MD5_PASSWORD, hmInHs.get(CommonDefs.DB_MD5_PASSWORD));
				hmMemberData.put(MPSDefs.DB_SHA1_PASSWORD, hmInHs.get(CommonDefs.DB_SHA1_PASSWORD));
				hmMemberData.put(MPSDefs.DB_DES3_PASSWORD, hmInHs.get(CommonDefs.DB_DES3_PASSWORD));
				//2103 - Added SSHA-256 encryption changes
				if (hmInHs.get(MPSDefs.DB_GEN_PASSWORD) != null) {
					hmMemberData.put(MPSDefs.DB_GEN_PASSWORD, hmInHs.get(CommonDefs.DB_GEN_PASSWORD));
					hmMemberData.put(MPSDefs.DB_GEN_PASSWORD_TYPE, hmInHs.get(CommonDefs.DB_GEN_PASSWORD_TYPE));
				}
				 
				// 1408 - Updated to null out ssha_password for accessId
				hmMemberData.put(MPSDefs.DB_SSHA_PASSWORD, null);
				hmMemberData.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);
				if (hmInHs.get(CommonDefs.PASSWORD_DIRTY) != null)
					hmMemberData.put(MPSDefs.DB_PASSWORD_DIRTY, hmInHs.get(CommonDefs.PASSWORD_DIRTY));

				/**
				 * Reason : If there are no linked users then we will call the processData()
				 * method in the UpdateMemberData bean � that requires CALLG2LDAP (the design
				 * currently shows LDAP_FLAG but the code has the correct key) in the same level
				 * as the reset of the fields to be updated.
				 */

				if (hmInHs.containsKey(CommonDefs.WS_ONLINE1_SECURITY_QUESTION_ID))
					hmMemberData.put(MPSDefs.DB_SECURITY_QUESTION_ID_1,
							hmInHs.get(CommonDefs.WS_ONLINE1_SECURITY_QUESTION_ID));
				if (hmInHs.containsKey(CommonDefs.WS_ONLINE1_SECURITY_QUESTION))
					hmMemberData.put(MPSDefs.DB_SECURITY_QUESTION_1,
							hmInHs.get(CommonDefs.WS_ONLINE1_SECURITY_QUESTION));
				if (hmInHs.containsKey(CommonDefs.WS_ONLINE1_SECURITY_ANSWER))
					hmMemberData.put(MPSDefs.DB_SECURITY_ANSWER_1, hmInHs.get(CommonDefs.WS_ONLINE1_SECURITY_ANSWER));

				if (hmInHs.containsKey(CommonDefs.WS_ONLINE2_SECURITY_QUESTION_ID))
					hmMemberData.put(MPSDefs.DB_SECURITY_QUESTION_ID_2,
							hmInHs.get(CommonDefs.WS_ONLINE2_SECURITY_QUESTION_ID));
				if (hmInHs.containsKey(CommonDefs.WS_ONLINE2_SECURITY_QUESTION))
					hmMemberData.put(MPSDefs.DB_SECURITY_QUESTION_2,
							hmInHs.get(CommonDefs.WS_ONLINE2_SECURITY_QUESTION));
				if (hmInHs.containsKey(CommonDefs.WS_ONLINE2_SECURITY_ANSWER))
					hmMemberData.put(MPSDefs.DB_SECURITY_ANSWER_2, hmInHs.get(CommonDefs.WS_ONLINE2_SECURITY_ANSWER));

				alMemberData.add(hmMemberData);

				if (!isLinkedUsers) {
					/*
					 * If there is no Linked user MPSTMS_UpdateMemberDataBean.processData() will
					 * look for this.
					 */
					hmMemberDataInput.put(MPSDefs.DB_MEMBER_TABLE, alMemberData);
				} else { // -- isLinkedUsers
					hmMemberDataInput.put(MPSDefs.DO_NOT_TRANSLATE_KEYS, MPSDefs.YES);
					hmMemberData.remove(MPSDefs.DB_MEMBER_NUM);
					hmMemberData.put(MPSDefs.DB_SLID_MEMBER_NUM, hmMemberDB.get(MPSDefs.DB_SLID_MEMBER_NUM));

					log.info(sClassName + sMethodName + "DM-01 : Linked users assigned, alLinkedUsers = "
							+ alLinkedUsers);
				}
				isUpdateRequired = true;
			}

			if (!isUpdateRequired) {
				log.info(sClassName + sMethodName + "DM-4 : No MPS Update required");
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS);
				return hmResult;
			}

			/**
			 * If we have linkedUsers, we update by slid only that way the db layer only has
			 * to execute one query to update those records, otherwise they have to execute
			 * on update per linked user.
			 */
			if (isLinkedUsers) {
				log.info(sClassName + sMethodName
						+ "DM-5C : Calling to MPSDB_Update_H.updateMemberBySlidMemberNum with HashMap = "
						+ hmMemberData);
				hmResult = updateDBHelper.updateMemberBySlidMemberNum(hmMemberData);
				log.info(sClassName + sMethodName
						+ "DM-5D : Response Hash from MPSDB_Update_H.updateMemberBySlidMemberNum is = " + hmResult);

				sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
				if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
					log.info(sClassName + sMethodName
							+ "DM-5E : Error returned from MPSDB_Update_H.updateMemberBySlidMemberNum : " + hmResult);
					return hmResult;
				}
			} else {
				HashMap hmMPSInput = CommonUtil.getHashMap();
				hmMPSInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
				hmMPSInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
				hmMPSInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
				hmMPSInput.put(MPSDefs.DB_MEMBER_TABLE, alMemberData);

				log.info(sClassName + sMethodName + "DM-6C : Calling to MPSDB_TMEMBER_H.processData with HashMap = "
						+ hmMPSInput);
				hmResult = memberDBHelper.processData(hmMPSInput);
				log.info(sClassName + sMethodName + "DM-6D : Response Hash from MPSDB_TMEMBER_H.processData is = "
						+ hmResult);

				sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
				if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
					log.info(sClassName + sMethodName + "DM-6E : Error returned from MPSDB_TMEMBER_H.processData : "
							+ hmResult);
					return hmResult;
				}
			}

			if (alMemberLockout != null && !alMemberLockout.isEmpty()) {
				HashMap hmMPSInput = CommonUtil.getHashMap();
				hmMPSInput.put(MPSDefs.DB_MEMBERLOCKOUT, alMemberLockout);
				hmMPSInput.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
				
				log.info(sClassName + sMethodName
						+ "DM-7C : Calling to MPSDB_TMEMBERLOCKOUT_H.processData with HashMap = " + hmMPSInput);
				hmResult = oMPSDB_TMEMBERLOCKOUT_H.processData(hmMPSInput);
				log.info(sClassName + sMethodName
						+ "DM-7D : Response Hash from MPSDB_TMEMBERLOCKOUT_H.processData is = " + hmResult);

				sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
				if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
					log.info(sClassName + sMethodName
							+ "DM-7E : Error returned from MPSDB_TMEMBERLOCKOUT_H.processData : " + hmResult);
					return hmResult;
				}
			}

			if (alUserFraudLock != null && !alUserFraudLock.isEmpty()) {
				HashMap hmMPSInput = CommonUtil.getHashMap();
				hmMPSInput.put(MPSDefs.DB_USERFRAUDLOCK, alUserFraudLock);

				log.info(sClassName + sMethodName + "DM-8C : Calling to MPSDB_FraudLock_H.processData with HashMap = "
						+ hmMPSInput);
				hmResult = fraudLockDBHelper.processData(hmMPSInput);
				log.info(sClassName + sMethodName + "DM-8D : Response Hash from MPSDB_FraudLock_H.processData is = "
						+ hmResult);

				sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
				if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
					log.info(sClassName + sMethodName + "DM-8E : Error returned from MPSDB_FraudLock_H.processData : "
							+ hmResult);
					return hmResult;
				}
			}


			//START - Prepare Dbus Input
			if (hmInHs.containsKey("securityAnswerChanged")) {
				if (hmInHs.containsKey(CommonDefs.ONLINE1_SECURITY_ANSWER)) {
					// These two will be used for calculating the proofing version
					hmMemberDB.put(CommonDefs.ONLINE1_SECURITY_QUESTION,
							hmInHs.get(CommonDefs.ONLINE1_SECURITY_QUESTION));
					hmMemberDB.put(CommonDefs.ONLINE1_SECURITY_ANSWER,
							hmInHs.get(CommonDefs.ONLINE1_SECURITY_ANSWER));
				}
				if (hmInHs.containsKey(CommonDefs.ONLINE2_SECURITY_ANSWER)) {
					// These two will be used for calculating the proofing version
					hmMemberDB.put(CommonDefs.ONLINE2_SECURITY_QUESTION,
							hmInHs.get(CommonDefs.ONLINE2_SECURITY_QUESTION));
					hmMemberDB.put(CommonDefs.ONLINE2_SECURITY_ANSWER,
							hmInHs.get(CommonDefs.ONLINE2_SECURITY_ANSWER));
				}
			}
			hmResult = buildDBusChangePasswordHash(hmInHs, hmMemberDB, hmParentDB);
			
			sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
				sAppInfo = "Getting Dbus parameter failed.";
				log.info(sClassName + sMethodName + "DBD-1c : " + sAppInfo);
				return hmResult;
			}
			HashMap hmChangePassword = (HashMap) hmResult.get("DBUSHASH");
			if(hmChangePassword != null && !hmChangePassword.isEmpty()){
				alDbus.add(hmChangePassword);
			}
			
			if (alLinkedUsers != null && !alLinkedUsers.isEmpty()) {
				//log.info(sClassName + sMethodName + "DBD-1b : Linked users assigned, alLinkedUsers = " + alLinkedUsers);

				Iterator alLinkedUsersIterator = alLinkedUsers.iterator();

				HashMap hmLUInput = new HashMap();
				while (alLinkedUsersIterator.hasNext()) {
					HashMap hmEachUser = (HashMap) alLinkedUsersIterator.next();
					hmLUInput.clear();
					hmLUInput.put(CommonDefs.TRANSACTION_NAME, hmInHs.get(CommonDefs.TRANSACTION_NAME));
					hmLUInput.put(CommonDefs.TRANSACTION_ID, hmInHs.get(CommonDefs.TRANSACTION_ID));
					hmLUInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInHs.get(CommonDefs.CALLING_SYSTEM_ID));
					hmLUInput.put(CommonDefs.AGENT_ID, hmInHs.get(CommonDefs.AGENT_ID));
					hmLUInput.put(CommonDefs.CLEAR_PASSWORD, hmInHs.get(CommonDefs.CLEAR_PASSWORD));
					hmLUInput.put(CommonDefs.DB_ENC_PASSWORD, hmInHs.get(CommonDefs.DB_ENC_PASSWORD));
					hmLUInput.put(CommonDefs.DB_MD5_PASSWORD, hmInHs.get(CommonDefs.DB_MD5_PASSWORD));
					hmLUInput.put(CommonDefs.DB_SHA1_PASSWORD, hmInHs.get(CommonDefs.DB_SHA1_PASSWORD));
					hmLUInput.put(CommonDefs.DB_DES3_PASSWORD, hmInHs.get(CommonDefs.DB_DES3_PASSWORD));
					hmLUInput.put(CommonDefs.PASSWORD_DIRTY, hmInHs.get(CommonDefs.PASSWORD_DIRTY));
					// 2103 - Added SSHA-256 encryption changes
					if (hmInHs.get(MPSDefs.DB_GEN_PASSWORD) != null) {

						hmLUInput.put(CommonDefs.DB_GEN_PASSWORD, hmInHs.get(CommonDefs.DB_GEN_PASSWORD));
						hmLUInput.put(CommonDefs.DB_GEN_PASSWORD_TYPE, hmInHs.get(CommonDefs.DB_GEN_PASSWORD_TYPE));

					}
					 
					if (hmInHs.containsKey("securityAnswerChanged")) {
						hmLUInput.put("securityAnswerChanged", hmInHs.get("securityAnswerChanged"));
						if (hmInHs.containsKey(CommonDefs.ONLINE1_SECURITY_ANSWER)) {
							// These two will be used for calculating the proofing version
							hmEachUser.put(CommonDefs.ONLINE1_SECURITY_QUESTION,
									hmInHs.get(CommonDefs.ONLINE1_SECURITY_QUESTION));
							hmEachUser.put(CommonDefs.ONLINE1_SECURITY_ANSWER,
									hmInHs.get(CommonDefs.ONLINE1_SECURITY_ANSWER));
						}
						if (hmInHs.containsKey(CommonDefs.ONLINE2_SECURITY_ANSWER)) {
							// These two will be used for calculating the proofing version
							hmEachUser.put(CommonDefs.ONLINE2_SECURITY_QUESTION,
									hmInHs.get(CommonDefs.ONLINE2_SECURITY_QUESTION));
							hmEachUser.put(CommonDefs.ONLINE2_SECURITY_ANSWER,
									hmInHs.get(CommonDefs.ONLINE2_SECURITY_ANSWER));
						}
					}

					hmResult = buildDBusChangePasswordHash(hmLUInput, hmEachUser, null);
					sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
					if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
						sAppInfo = "Getting Dbus parameter failed.";
						log.info(sClassName + sMethodName + "DBD-1c : " + sAppInfo);
						return hmResult;
					}

					// SID 24665 allow members to all functions on myAT&T during the release
					// activity Req Rel -- START

					HashMap hmChangePasswordLinked = (HashMap) hmResult.get("DBUSHASH");
					if (hmChangePasswordLinked != null)
						alDbus.add(hmChangePasswordLinked);
				}
			} // -- 1. if(hmInHs.containsKey(MPSDefs.KEY_LINKED_USERS)) closed...

			// Now add the CreateInteraction transaction
			HashMap hmGACH = generateHmGACH(hmInHs, hmMemberDB);
			hmGACH.put(CommonDefs.CREATE_INTERACTION_RESULT, CommonDefs.REASON_CODE_SUCCESS);
			// This is the success case we need to put 0 for the failed auth count
			hmGACH.put(MPSDefs.DB_FAILED_AUTH_COUNT, "0");

			HashMap hmResponse = buildCreateInteractionHash(hmGACH, hmMemberDB);

			sAppStatusCode = (String) hmResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
				sAppInfo = "Getting Dbus parameter failed.";
				log.info(sClassName + sMethodName + "DD-2a : " + sAppInfo);
				return hmResponse;
			}

			if (hmResponse.get("CREATEINTERACTIONHASH") != null)
				alDbus.add(hmResponse.get("CREATEINTERACTIONHASH"));


			if (alLinkedUsers != null && !alLinkedUsers.isEmpty()) {
				Iterator alLinkedUsersIterator = alLinkedUsers.iterator();

				while (alLinkedUsersIterator.hasNext()) {
					HashMap hmEachUser = (HashMap) alLinkedUsersIterator.next();
					hmGACH.clear();
					hmGACH = generateHmGACH(hmInHs, hmEachUser);
					hmGACH.put(CommonDefs.CREATE_INTERACTION_RESULT, CommonDefs.REASON_CODE_SUCCESS);
					// This is the success case we need to put 0 for the failed auth count
					hmGACH.put(MPSDefs.DB_FAILED_AUTH_COUNT, "0");
					hmResponse.clear();
					hmResponse = buildCreateInteractionHash(hmGACH, hmEachUser);

					sAppStatusCode = (String) hmResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
					if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
						sAppInfo = "Getting Dbus parameter failed.";
						log.info(sClassName + sMethodName + "DD-2c : " + sAppInfo);
						return hmResponse;
					}

					if (hmResponse.get("CREATEINTERACTIONHASH") != null)
						alDbus.add(hmResponse.get("CREATEINTERACTIONHASH"));
				}
			}


			// 1510 US195227 Process Dbus event for Fraud lock user
			if (hmInHs.containsKey("PROCESS_USER_FRAUD_LOCKS")) {
				HashMap hmFraudLockEvent = CommonUtil.getHashMap();
				hmFraudLockEvent.put(CommonDefs.EVENTNAME, "AtlasIdentityManagementPublisher");
				hmFraudLockEvent.put(CommonDefs.SUBEVENT, "FraudAction");
				hmFraudLockEvent.put(CommonDefs.CALLING_SYSTEM_ID, hmInHs.get(CommonDefs.CALLING_SYSTEM_ID));
				hmFraudLockEvent.put(CommonDefs.TRANSACTION_ID, hmInHs.get(CommonDefs.TRANSACTION_ID));
				hmFraudLockEvent.put(CommonDefs.TRANSACTION_NAME, hmInHs.get(CommonDefs.TRANSACTION_NAME));
				String sOrigTransactionName = (String) hmInHs.get(CommonDefs.ORIG_TRANSACTION_NAME);
				if (sOrigTransactionName == null) {
					sOrigTransactionName = (String) hmInHs.get(CommonDefs.TRANSACTION_NAME);
				}
				hmFraudLockEvent.put(CommonDefs.ORIG_TRANSACTION_NAME, sOrigTransactionName);
				hmFraudLockEvent.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
				hmFraudLockEvent.put(CommonDefs.SLID, hmMemberDB.get(MPSDefs.DB_MEMBER_NAME));
				hmFraudLockEvent.put(CommonDefs.USER_UNLOCK_LEVEL, "0");
				if (hmInHs.get(MPSDefs.DB_USER_LOCK_REASON) != null) {
					hmFraudLockEvent.put(CommonDefs.USER_LOCK_REASON_CODE, hmInHs.get(MPSDefs.DB_USER_LOCK_REASON));
				}
				alDbus.add(hmFraudLockEvent);
			}

		
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS);
		
			if(!alDbus.isEmpty()){
				hmResult.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, alDbus);
			}			

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, log);
		} finally {
			sAppInfo = "Response from UserPasswordHelper = " + hmResult;
			log.info(SpiMarker.getInstance(), sClassName + sMethodName + "HLP999 : {}", StringUtils.normalizeSpace(sAppInfo.toString()));
		}
		return hmResult;
	}

	/**
	 * This method is used to build a HashMap containing the necessary information for a password change event.
	 * It takes three HashMaps as input. The first HashMap contains input parameters for the method,
	 * the second HashMap contains information about the member from the database,
	 * and the third HashMap contains information about the parent member from the database.
	 * The method retrieves various pieces of information from the input HashMaps, such as the handle, domain, member number, and others.
	 * It then puts these pieces of information into a new HashMap, which it returns.
	 * The returned HashMap can be used for further processing, such as generating a password or checking for fraud.
	 *
	 * @param hmInHs HashMap containing the input parameters for the method.
	 * @param hmMemberDB HashMap containing the member information from the database.
	 * @param hmParentDB HashMap containing the parent member information from the database.
	 * @return HashMap containing the necessary information for a password change event.
	 */
	public HashMap buildDBusChangePasswordHash(HashMap hmInHs, HashMap hmMemberDB, HashMap hmParentDB) {
		String sMethodName = ".buildDBusChangePasswordHash.";
		String appInfo = null;
		String appStatusCode = null;
		HashMap statusTMS = CommonUtil.getHashMap();
		HashMap dbHs = CommonUtil.getHashMap();
		String sCustomerType = null;
		String dbusSubEvent = null;
		HashMap hmGetAuthInfoResult = null;

		try {
			String sMemberNum = (String) hmMemberDB.get(MPSDefs.DB_MEMBER_NUM);
			String sSlidMemberNum = (String) hmMemberDB.get(MPSDefs.DB_SLID_MEMBER_NUM);
			String sCallingSystemId = (String) hmInHs.get(CommonDefs.CALLING_SYSTEM_ID);
			String sTransactionName = (String) hmInHs.get(CommonDefs.TRANSACTION_NAME);
			String sor_name = (String) hmMemberDB.get(MPSDefs.DB_SOR_NAME);
			String sParentChildInd = (String) hmMemberDB.get(MPSDefs.DB_PARENT_CHILD_IND);
			String sBan = (String) hmMemberDB.get(MPSDefs.DB_BAN);
			String sParentHandle = (String) hmMemberDB.get(MPSDefs.DB_PARENT_NAME);
			String sParentDomain = (String) hmMemberDB.get(MPSDefs.DB_PARENT_DOMAIN);
			
			String sEnc_password = (String) hmInHs.get(CommonDefs.DB_ENC_PASSWORD);
			String sMd5_password = (String) hmInHs.get(CommonDefs.DB_MD5_PASSWORD);
			String sSha1_password = (String) hmInHs.get(CommonDefs.DB_SHA1_PASSWORD);
			String sClearPassword = (String) hmInHs.get(CommonDefs.CLEAR_PASSWORD);
			String sSSHAPassword = (String) hmInHs.get(CommonDefs.DB_SSHA_PASSWORD);
			// 2103 - Added SSHA-256 encryption changes
			String sGeneric_password = (String) hmInHs.get(CommonDefs.DB_GEN_PASSWORD); //R2011: String
			String sGeneric_password_type = (String) hmInHs.get(CommonDefs.DB_GEN_PASSWORD_TYPE);
			 
			dbHs.put(CommonDefs.EVENTNAME, "ChangePassword");
			dbHs.put(CommonDefs.DBUS_DICTIONARY_NAME, "Dict");
			dbHs.put(CommonDefs.TRANSACTION_NAME, hmInHs.get(CommonDefs.TRANSACTION_NAME));

			if (hmInHs.get(CommonDefs.ORIG_TRANSACTION_NAME) != null) {
				dbHs.put(CommonDefs.ORIG_TRANSACTION_NAME, (String) hmInHs.get(CommonDefs.ORIG_TRANSACTION_NAME));
			}

			dbHs.put(CommonDefs.TRANSACTION_ID, hmInHs.get(CommonDefs.TRANSACTION_ID));
			dbHs.put(CommonDefs.HANDLE, hmMemberDB.get(MPSDefs.DB_MEMBER_NAME));
			dbHs.put(CommonDefs.DOMAIN, hmMemberDB.get(MPSDefs.DB_DOMAIN_NAME));

			dbHs.put(CommonDefs.MD5_PASSWORD, sMd5_password);
			dbHs.put(CommonDefs.DB_ENC_PASSWORD, sEnc_password);
			dbHs.put(CommonDefs.DB_SHA1_PASSWORD, sSha1_password);		
			
			// 2103 - Added SSHA-256 encryption changes
			  if(sGeneric_password != null)
			  { 
				log.info(sClassName + sMethodName +"CMNT1.6.1 : member hash has gen_password key, adding passwordType as Generic "); 
				dbHs.put(MPSDefs.DB_GEN_PASSWORD, sGeneric_password);
			    dbHs.put(CommonDefs.DBUS_PASSWORDTYPE, sGeneric_password_type); 
			    
			   } else if (sSha1_password != null) { 
				   
				log.info(sClassName + sMethodName + "CMNT18 : ember hash has sha1_password key, adding passwordType as SHA "); 
				dbHs.put(CommonDefs.DBUS_PASSWORDTYPE, CommonDefs.DBUS_SHA_PASSWORDTYPE); 
				
			   } else if (sClearPassword != null) { 
				   
				log.info(sClassName + sMethodName + "CMNT1.5 : member hash has clearPassword key, adding passwordType as Text "); 
				dbHs.put(CommonDefs.DBUS_PASSWORDTYPE, CommonDefs.DBUS_TEXT_PASSWORDTYPE); 
				
			} else if (sEnc_password != null) { 
				log.info(sClassName + sMethodName + "CMNT1.6 : member hash has enc_password key, adding passwordType as Crypt");
				dbHs.put(CommonDefs.DBUS_PASSWORDTYPE, CommonDefs.DBUS_CRYPT_PASSWORDTYPE); 
			} else if(sSSHAPassword != null) { 
				log.info(sClassName + sMethodName + "CMNT1.6.1 : ember hash has ssha_password key, adding passwordType as Crypt ");
				dbHs.put(CommonDefs.DBUS_PASSWORDTYPE, "SSHA"); 
			} else { 
				log.info(sClassName + sMethodName + "CMNT19 : member does not have not null sha1, clear and enc passwords. Not setting passwordType");
			}  

			if (hmInHs.get(CommonDefs.PASSWORD_DIRTY) != null)
				dbHs.put(MPSDefs.DB_PASSWORD_DIRTY, hmInHs.get(CommonDefs.PASSWORD_DIRTY));
			if (hmInHs.get(CommonDefs.SEND_NOTIFICATION_EMAIL) != null)
				dbHs.put(CommonDefs.SEND_NOTIFICATION_EMAIL, hmInHs.get(CommonDefs.SEND_NOTIFICATION_EMAIL));

			dbHs.put(CommonDefs.SOR_NAME, sor_name);

			if (hmInHs.get("newPassword") != null) 
				dbHs.put(CommonDefs.CLEAR_PASSWORD, hmInHs.get("newPassword"));

			String sMigrationInd = (String) hmMemberDB.get(MPSDefs.DB_MIGRATION_IND);
			dbHs.put(CommonDefs.MIGRATION_IND, sMigrationInd);

			dbHs.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
			dbHs.put(CommonDefs.PASSWORD_HASH_TYPE, CommonDefs.PASSWORD_HASH_TYPE_VALUE);

			if (hmInHs.get(CommonDefs.AGENT_ID) != null) {
				dbHs.put(CommonDefs.AGENT_ID, hmInHs.get(CommonDefs.AGENT_ID));

				// --1208 : SID 22373 : Change to Temp PW for Yahoo Agent PW resets
				if (hmInHs.get(CommonDefs.PASSWORD_DIRTY) != null) {
					HashMap<String, Object> hmPassword = CommonUtil.getHashMap();
					// 1408 - Updated for US238239 to use digits only in temp password generation
					hmPassword.put(MPSDefs.WS_CLEAR_TEXT, passwordHelper.generateTempPasswordDigitsOnly());
					HashMap<String, Object> hmPasswordResponse = passwordHelper.generateMD5Password(hmPassword, log);
					appStatusCode = (String) hmPasswordResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);

					if (!appStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
						return hmPasswordResponse;

					dbHs.put(CommonDefs.MD5_DIRTY_PASSWORD, hmPasswordResponse.get(CommonDefs.DB_MD5_PASSWORD));
				}
			}
			// 1510 US195223 : sending input user_lock_level to ChangePassword event
			if (hmInHs.get(CommonDefs.USER_LOCK_LEVEL) != null) {
				dbHs.put(CommonDefs.USER_LOCK_LEVEL, (String) hmInHs.get(CommonDefs.USER_LOCK_LEVEL));
			}

			dbHs.put(CommonDefs.DB_DES3_PASSWORD, hmInHs.get(CommonDefs.DB_DES3_PASSWORD));

			/*if (hmMemberDB.get(CommonDefs.SERVICES) != null) {
				dbHs.put(CommonDefs.SERVICES, hmMemberDB.get(CommonDefs.SERVICES));
			}*/

			if (sParentChildInd != null) {
				dbHs.put(CommonDefs.DB_PARENT_CHILD_IND, sParentChildInd);
			}

			dbHs.put(CommonDefs.DB_MEMBER_NUM, sMemberNum);

			if (sSlidMemberNum != null)
				dbHs.put(MPSDefs.DB_SLID_MEMBER_NUM, sSlidMemberNum);

			// call convertServicesHash() to convert services HashMap to ArrayList
			ArrayList alServiceTypes = null;
			ArrayList alServiceLevelSORs = new ArrayList();
			HashMap hmConvertServicesResponse = null;
			if (hmMemberDB.get(CommonDefs.SERVICES) != null) {
				hmConvertServicesResponse = oConvertServicesHelper
						.convertServices((HashMap) hmMemberDB.get(CommonDefs.SERVICES));
				alServiceTypes = (ArrayList) hmConvertServicesResponse.get(CommonDefs.SERVICE_TYPES);
				alServiceLevelSORs = (ArrayList) hmConvertServicesResponse.get(CommonDefs.SERVICE_LEVEL_SORS);
				dbHs.put(CommonDefs.SERVICES, hmConvertServicesResponse.get(CommonDefs.SERVICES));

				if (alServiceLevelSORs.isEmpty())
					alServiceLevelSORs.add(sor_name);

				// Added the check for BLS back into the customerType calculation.
				if (alServiceLevelSORs != null && alServiceLevelSORs.contains(MPSDefs.SOR_BLS)) {
					if (alServiceTypes.contains(MPSDefs.ISDN_SERVICE)
							|| alServiceTypes.contains(MPSDefs.ISDN2_SERVICE)) {
						sCustomerType = CommonDefs.ISDN_SERVICE;
					} else if (alServiceTypes.contains(MPSDefs.DSL_SERVICE)) {
						sCustomerType = CommonDefs.DSL_SERVICE;
					} else if (alServiceTypes.contains(MPSDefs.DIAL_SERVICE)) {
						sCustomerType = CommonDefs.DIAL_SERVICE;
					}
				}
			} else {
				// Added member level sor if member have no services
				alServiceLevelSORs.add(sor_name);
			}

			if (alServiceLevelSORs.isEmpty())
				alServiceLevelSORs.add(sor_name);

			if (sBan != null)
				dbHs.put(CommonDefs.BAN, sBan);

			dbusSubEvent = "ChangePassword";
			if (sSlidMemberNum != null) {
				/* --commenting the code to filter HALOC calls for MID ChangePassword flow. need to send only for SLID
				else if (hmInHs.containsKey("securityAnswerChanged"))
					dbHs.put(CommonDefs.FILTER_CGATE, CommonDefs.DEFAULT_NO); */
				if (sMemberNum.equals(sSlidMemberNum)) {
					dbusSubEvent = CommonDefs.DBUS_NOTIFICATION_SUBEVENT_SLID;
					dbHs.put(CommonDefs.FILTER_CGATE, CommonDefs.DEFAULT_NO);
				
				}else
					dbHs.put(CommonDefs.FILTER_CGATE, CommonDefs.DEFAULT_YES);
			}

			if (dbusSubEvent != null && dbusSubEvent.length() > 0)
				dbHs.put(CommonDefs.SUBEVENT, dbusSubEvent);

			// --Parent Handle ...
			if (sParentHandle != null && sParentHandle.length() > 0)
				dbHs.put(CommonDefs.PARENT_HANDLE, sParentHandle);

			// --Parent Domain ...
			if (sParentDomain != null && sParentDomain.length() > 0)
				dbHs.put(CommonDefs.PARENT_DOMAIN, sParentDomain);

			if (sCustomerType != null) {
				log.info(sClassName + sMethodName + "bDCPH-6-1 : Setting CustomerType and AgentId to send to dbus:");
				dbHs.put(CommonDefs.AGENT_ID, hmInHs.get(CommonDefs.AGENT_ID));
				dbHs.put(CommonDefs.CUSTOMER_TYPE, sCustomerType);
			}

			if (hmInHs.get(CommonDefs.PROOFING_VERSION) != null) //TODO - dm7141 - check how to get proofing version
				dbHs.put(CommonDefs.PROOFING_VERSION, hmInHs.get(CommonDefs.PROOFING_VERSION));

			if (hmMemberDB.get(MPSDefs.DB_BROWSER_LANGUAGE) != null)
				dbHs.put(CommonDefs.BROWSER_LANGUAGE, hmMemberDB.get(MPSDefs.DB_BROWSER_LANGUAGE));

			if (hmMemberDB.get(CommonDefs.DB_CONTACT_EMAIL) != null)
				dbHs.put(CommonDefs.CONTACT_EMAIL, hmMemberDB.get(CommonDefs.DB_CONTACT_EMAIL));

			if (hmInHs.get(CommonDefs.CLEAR_PASSWORD) != null)
				dbHs.put(CommonDefs.CLEAR_PASSWORD, hmInHs.get(CommonDefs.CLEAR_PASSWORD));

			if (hmInHs.get(CommonDefs.DELIVERY_METHOD) != null) {
				HashMap hmDeliveryMethod = (HashMap) hmInHs.get(CommonDefs.DELIVERY_METHOD);
				dbHs.put(CommonDefs.DELIVERY_METHOD_TYPE, hmDeliveryMethod.get(CommonDefs.DELIVERY_METHOD_TYPE));
				if (hmDeliveryMethod.get(CommonDefs.VALUE_EMAIL) != null) {
					dbHs.put(CommonDefs.VALUE_EMAIL, hmDeliveryMethod.get(CommonDefs.VALUE_EMAIL));
					dbHs.put("contact1", hmDeliveryMethod.get(CommonDefs.VALUE_EMAIL));
				}
				if (hmDeliveryMethod.get(CommonDefs.VALUE_SMS) != null)
					dbHs.put(CommonDefs.VALUE_SMS, hmDeliveryMethod.get(CommonDefs.VALUE_SMS));
				if (hmDeliveryMethod.get(CommonDefs.VALUE_AO) != null)
					dbHs.put(CommonDefs.VALUE_AO, hmDeliveryMethod.get(CommonDefs.VALUE_AO));
				if (hmDeliveryMethod.get(CommonDefs.VALUE_POSTAL) != null)
					dbHs.put(CommonDefs.VALUE_POSTAL, hmDeliveryMethod.get(CommonDefs.VALUE_POSTAL));
			}

			if ((sor_name != null && sor_name.equals(MPSDefs.SOR_LS))
					&& (sParentChildInd != null && sParentChildInd.equals(MPSDefs.MPS_PARENT))
					&& hmGetAuthInfoResult != null)
				dbHs.put(CommonDefs.GET_AUTH_INFO_RESULT, hmGetAuthInfoResult);

			if (hmMemberDB.get(MPSDefs.DB_LC_FIRSTNAME) != null)
				dbHs.put(CommonDefs.FIRST_NAME, hmMemberDB.get(MPSDefs.DB_LC_FIRSTNAME));
			if (hmMemberDB.get(MPSDefs.DB_LC_LASTNAME) != null)
				dbHs.put(CommonDefs.LAST_NAME, hmMemberDB.get(MPSDefs.DB_LC_LASTNAME));

			if (hmInHs.containsKey("securityAnswerChanged")) {
				dbHs.put("securityAnswerChanged", hmInHs.get("securityAnswerChanged"));

				if (!hmInHs.containsKey(CommonDefs.PROOFING_VERSION)) {
					// Setting filter_cgate flag to no for linked users since tGuard will not
					// propagate proofing version.
					//dbHs.put(CommonDefs.FILTER_CGATE, CommonDefs.DEFAULT_NO);

					if (sParentChildInd.equals(MPSDefs.MPS_PARENT) && sor_name.equals(MPSDefs.SOR_LS)) {
						hmGetAuthInfoResult = getCredentialsData(hmInHs, hmMemberDB, CommonDefs.DEFAULT_YES);
						log.info("{}{}DCP-15a : getCredentialsData() response : {}",sClassName,sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmGetAuthInfoResult)));
						appStatusCode = (String) hmGetAuthInfoResult.get(MPSDefs.APP_STATUS_CODE);
						if (!appStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
							appInfo = "getCredentialsData returned error.";
							log.info(sClassName + sMethodName + "DCP-15b : " + appInfo);
							return hmGetAuthInfoResult;
						}
					}
					
                     // Removed Proofing Version, no longer needed
					//dbHs.put(CommonDefs.PROOFING_VERSION, statusTMS.get(CommonDefs.PROOFING_VERSION));
				}
			}

			if (hmParentDB != null && sParentChildInd.equals(MPSDefs.MPS_CHILD)) {
				if (hmParentDB.get(MPSDefs.DB_LC_FIRSTNAME) != null)
					dbHs.put(CommonDefs.PARENT_FIRST_NAME, hmParentDB.get(MPSDefs.DB_LC_FIRSTNAME));
				if (hmParentDB.get(MPSDefs.DB_LC_LASTNAME) != null)
					dbHs.put(CommonDefs.PARENT_LAST_NAME, hmParentDB.get(MPSDefs.DB_LC_LASTNAME));
				if (hmParentDB.get(CommonDefs.DB_CONTACT_EMAIL) != null)
					dbHs.put(CommonDefs.PARENT_CONTACT_EMAIL, hmParentDB.get(CommonDefs.DB_CONTACT_EMAIL));
				if (hmParentDB.get(MPSDefs.DB_BROWSER_LANGUAGE) != null)
					dbHs.put(CommonDefs.PARENT_BROWSER_LANGUAGE, hmParentDB.get(MPSDefs.DB_BROWSER_LANGUAGE));

				if (hmParentDB.get(CommonDefs.SERVICES) != null) {
					if (hmConvertServicesResponse != null)
						hmConvertServicesResponse.clear();

					hmConvertServicesResponse = oConvertServicesHelper
							.convertServices((HashMap) hmParentDB.get(CommonDefs.SERVICES));
					ArrayList alParentServices = (ArrayList) hmConvertServicesResponse.get(CommonDefs.SERVICES);
					dbHs.put(CommonDefs.PARENT_SERVICES, alParentServices);
				} // end of if(alParentServices != null)
			}

			// // 1711 : EPIC PID 300110: Open Authentication Protocol - FASTPASS : updated
			// to send RemoteIPAddress for eventName=ChangePassword for yahoo call.
			InetAddress ipAddr = InetAddress.getLocalHost();
			String sSourceIPAddress = ipAddr.getHostAddress();
			dbHs.put("RemoteIPAddress", sSourceIPAddress);
			
			//PID-310691e [2006][MPSYS-US3]prepare data for ERICSSON interface
			//changes by pm675e
			if (!CommonDefs.CALLING_SYSTEM_ERICSSON.equals(sCallingSystemId) && alServiceTypes != null
					&& alServiceTypes.contains(CommonDefs.MOBILITY_SERVICE)
					&& alServiceTypes.contains(CommonDefs.MOSUB_SERVICE)) {
				HashMap hmResult = new HashMap<>();
				hmResult = preparePrepaidDataForDbus(hmInHs, hmMemberDB, dbHs);
				String stAppStatusCode = (String) hmResult
						.get(MPSDefs.APP_STATUS_CODE);
				if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					String stAppInfo = (String) hmResult.get(MPSDefs.APP_INFO);
					log.info("{}{}DCP-15G : {}", sClassName, sMethodName,
							HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
					hmResult = CommonErrorMap.makeCategoryMap(
							Integer.parseInt(stAppStatusCode), stAppInfo);
					return hmResult;
				}

			}//END

			statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS);
			statusTMS.put("DBUSHASH", dbHs);
		} catch (Exception e) {
			statusTMS = CommonErrorMap.makeExceptionMap(e, log);
		}
		return statusTMS;
	}

	/**
	 * This method is used to prepare data for mobility prepaid data for Dbus.
	 * It takes two HashMaps as input. The first HashMap contains input parameters for the method,
	 * and the second HashMap contains information about the member from the database.
	 * The method checks if the member is eligible for mobility prepaid data based on the input parameters and member information.
	 * If the member is eligible, it prepares the input for the Dbus method and makes the call.
	 * It then checks the status code returned by the Dbus method. If the status code is not 'COMMON_SUCCESS', it prepares an error HashMap and returns it.
	 * If the status code is 'COMMON_SUCCESS', it returns a success HashMap.
	 * In case of any exception, it logs the error and returns an error HashMap.
	 *
	 * @param hmInHs HashMap containing the input parameters for the method.
	 * @param hmMemberDB HashMap containing the member information from the database.
	 * @return HashMap containing the result of the mobility prepaid data preparation process.
	 */
	private HashMap preparePrepaidDataForDbus(HashMap hmInHs, HashMap hmMemberDB,
			HashMap dbHs) throws Exception {
		String sMethodName = ".preparePrepaidDataForDbus.";
		HashMap hmResult = new HashMap();
		ArrayList alPrepaidAcctTypes = new ArrayList<>();
		String sPrepaidAcctTypes = PropertyManager.getProperty(
				CommonDefs.MSConfig, CommonDefs.ERICSSON_PREPAID_MOBILITY_ACCOUNT_TYPE_LIST);
		if (sPrepaidAcctTypes != null && !sPrepaidAcctTypes.isEmpty()) {
			alPrepaidAcctTypes = CommonUtil.parseToArray(sPrepaidAcctTypes,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			log.info("{}{}DCP-15C : EricssonPrepaidMOBILITYAccountTypeList: {} ", sClassName, sMethodName,
					alPrepaidAcctTypes);

		}else {
			String stAppInfo = "Property EricssonPrepaidMOBILITYAccountTypeList value is null or empty";
			 hmResult = CommonErrorMap
					.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
			log.error("{}{}DCP-15D : {} ", sClassName, sMethodName,
					stAppInfo);
			return hmResult;
		}
		boolean isPrepaidMobilityPresent = false;
		String sPrepaidMobilityBan = null;
		HashMap hmServices = (HashMap) hmMemberDB.get(CommonDefs.SERVICES);
		if (hmServices != null) {
			HashMap<String, Object> hmMobilityServices = (HashMap) hmServices
					.get(CommonDefs.MOBILITY_SERVICE);
			for (Entry<String, Object> service : hmMobilityServices
					.entrySet()) {
				String sDBAcctType = null;
				String sDBAcctSubType = null;
				Object mobSvcDetails = service.getValue();
				if (mobSvcDetails != null && mobSvcDetails instanceof HashMap) {
					HashMap hmMobSvcDetails = (HashMap) mobSvcDetails;
					if (hmMobSvcDetails != null && !hmMobSvcDetails.isEmpty()
							&& hmMobSvcDetails.get(
									MPSDefs.DB_MEMBER_SERVICE_ATTRIBUTE) != null) {
						ArrayList alMemberServiceAttribute = (ArrayList) hmMobSvcDetails
								.get(MPSDefs.DB_MEMBER_SERVICE_ATTRIBUTE);
						log.info("{}{}DCP-15E :  Mobility Member attributes:{} ", sClassName, sMethodName,
								alMemberServiceAttribute);
						if (alMemberServiceAttribute != null
								&& !alMemberServiceAttribute.isEmpty()) {
							for (Object serviceAttribute : alMemberServiceAttribute) {
								if (serviceAttribute != null
										&& serviceAttribute instanceof HashMap) {
									HashMap hmAttributeDeatils = (HashMap) serviceAttribute;
									String sAttributeName = (String) hmAttributeDeatils
											.get(MPSDefs.DB_ATTRIBUTE_NAME);
									if (sAttributeName != null) {
										if (sAttributeName.equals(
												CommonDefs.MOBILITY_ACCOUNT_TYPE)) {
											sDBAcctType = (String) hmAttributeDeatils
													.get(MPSDefs.DB_ATTRIBUTE_VALUE);
										} else if (sAttributeName.equals(
												CommonDefs.MOBILITY_ACCOUNT_SUBTYPE)) {
											sDBAcctSubType = (String) hmAttributeDeatils
													.get(MPSDefs.DB_ATTRIBUTE_VALUE);
										}
									}
								}
							}
						}
					}

					if (sDBAcctType != null && sDBAcctSubType != null
							&& alPrepaidAcctTypes
									.contains(sDBAcctType + sDBAcctSubType)) {
						isPrepaidMobilityPresent = true;
						sPrepaidMobilityBan = (String) hmMobSvcDetails
								.get(MPSDefs.DB_SOR_INVARIANT_ID);
						break;
					}
				}
			}
			if (isPrepaidMobilityPresent) {
				Map<String, Object> hmMosubService = (HashMap) hmServices
						.get(CommonDefs.MOSUB_SERVICE);
				for (Map.Entry<String, Object> entry : hmMosubService
						.entrySet()) {
					if (entry.getValue() != null
							&& entry.getValue() instanceof HashMap) {
						HashMap hmMosubSvcDetails = (HashMap) entry.getValue();
						String sPrepaidCTN = (String) hmMosubSvcDetails
								.get(MPSDefs.DB_INSTANCE_ID);
						if (sPrepaidCTN != null && !sPrepaidCTN.isEmpty()) {
							Map hmPrepaidCTNData = new HashMap<>();
							hmPrepaidCTNData.put(CommonDefs.CTN, sPrepaidCTN);
							hmPrepaidCTNData.put(CommonDefs.BAN,
									sPrepaidMobilityBan);
							hmPrepaidCTNData.put(CommonDefs.PASSWORD,
									hmInHs.get(CommonDefs.CLEAR_PASSWORD));
							log.info("{}{}DCP-15F : PrepaidData sending to dbus:{} ", sClassName, sMethodName,
									hmPrepaidCTNData);
							dbHs.put(CommonDefs.PREPAID_DATA, hmPrepaidCTNData);
						}
					}
				}
			}
		}
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}

	/**
	 * This method is used to process the check for fraud passwords.
	 * It takes two HashMaps as input. The first HashMap contains input parameters for the method,
	 * and the second HashMap contains information about the member from the database.
	 * The method checks if the input password is the same as any of the fraud passwords stored for that accessId.
	 * If the input password matches one of the fraud passwords, it returns an error HashMap.
	 * If the input password does not match any of the fraud passwords, it returns a success HashMap.
	 * In case of any exception, it logs the error and returns an error HashMap.
	 *
	 * @param hmInput HashMap containing the input parameters for the method.
	 * @param hmDBMember HashMap containing the member information from the database.
	 * @return HashMap containing the result of the fraud password check.
	 */
	public HashMap processCheckFraudPassword(HashMap hmInput, HashMap hmDBMember) {
		String sMethodName = ".processCheckFraudPassword.";
		HashMap hmResult = null;

		log.info(sClassName + sMethodName + "PCFP01 : " + "Inside processCheckFraudPassword()");

		String sPwdDirty = (String) hmInput.get(CommonDefs.PASSWORD_DIRTY);
		String sTempGenerated = (String) hmInput.get(CommonDefs.TEMP_GENERATED);
		String sClearPwd = (String) hmInput.get(CommonDefs.CLEAR_PASSWORD);
		String sDBDomain = (String) hmDBMember.get(MPSDefs.DB_DOMAIN_NAME);
		HashMap hmSlidInfoForFraudPwd = CommonUtil.getHashMap();

		if (sDBDomain != null && sDBDomain.equals(CommonDefs.SLID_DUM)) {
			hmSlidInfoForFraudPwd.putAll(hmDBMember);
		} else if (sDBDomain != null && hmDBMember.containsKey(MPSDefs.KEY_SLID_INFO)) {
			hmSlidInfoForFraudPwd.putAll((HashMap) hmDBMember.get(MPSDefs.KEY_SLID_INFO));
		}

		String sFraudPwdsPresent = MPSDefs.NO;

		if (hmSlidInfoForFraudPwd != null && !hmSlidInfoForFraudPwd.isEmpty()) {
			if (hmSlidInfoForFraudPwd.get("recent_fraud_pw_date") != null) {
				sFraudPwdsPresent = MPSDefs.YES;
				log.info(sClassName + sMethodName + "PCFP01.01 : " + "recent_fraud_pw_date is populated in DB");
			}
		}
		boolean bCheckForFraudPwd = true;

		if ((hmSlidInfoForFraudPwd == null || hmSlidInfoForFraudPwd.isEmpty())
				|| (sPwdDirty != null && sPwdDirty.equals(MPSDefs.YES))
				|| (sTempGenerated != null && sTempGenerated.equals(MPSDefs.YES))
				|| sFraudPwdsPresent.equals(MPSDefs.NO) || (sClearPwd == null || sClearPwd.isEmpty())) {
			bCheckForFraudPwd = false;
			log.info(sClassName + sMethodName + "PCFP02 : " + "No need of password fraud check");
		}

		if (bCheckForFraudPwd) {
			ArrayList alMemberFraudPwds = (ArrayList) hmSlidInfoForFraudPwd.get("memberfraudpassword");
			String isFraudPwdMatch = MPSDefs.NO;
			String sGenPwdType = (String) hmInput.get(CommonDefs.DB_GEN_PASSWORD_TYPE);
			if (alMemberFraudPwds != null && !alMemberFraudPwds.isEmpty()) {
				Iterator iter = alMemberFraudPwds.iterator();
				while (iter.hasNext()) {
					HashMap hmFraudPwd = (HashMap) iter.next();

					String sDBPwdType = (String) hmFraudPwd.get(MPSDefs.DB_PASSWORD_TYPE);
					String sDBPwd = (String) hmFraudPwd.get(MPSDefs.DB_PASSWORD_VENC);
					String sInputPwd = null;
					
					// 2103 - Added SSHA-256 encryption changes
					if (sGenPwdType != null && sGenPwdType.equalsIgnoreCase(sDBPwdType)) {

						sInputPwd = (String) hmInput.get(CommonDefs.DB_GEN_PASSWORD);

					}
					  else if ((CommonDefs.ALGORITHM_MD5).equalsIgnoreCase(sDBPwdType)) {
						sInputPwd = (String) hmInput.get(CommonDefs.DB_MD5_PASSWORD);
					} else if (("SHA1").equalsIgnoreCase(sDBPwdType)) {
						sInputPwd = (String) hmInput.get(CommonDefs.DB_SHA1_PASSWORD);
					} else if (("DES3").equalsIgnoreCase(sDBPwdType)) {
						sInputPwd = (String) hmInput.get(CommonDefs.DB_DES3_PASSWORD);
					} else if ((CommonDefs.DBUS_SSHA_PASSWORDTYPE).equalsIgnoreCase(sDBPwdType)) {
						sInputPwd = (String) hmInput.get(CommonDefs.DB_SSHA_PASSWORD);
					} else if (("ENC").equalsIgnoreCase(sDBPwdType)) {
						sInputPwd = (String) hmInput.get(CommonDefs.DB_ENC_PASSWORD);
					} 

					if (sInputPwd != null && sInputPwd.equals(sDBPwd)) {
						isFraudPwdMatch = MPSDefs.YES;
						break;
					}
				}
			}
			if (isFraudPwdMatch.equals(MPSDefs.YES)) {
				String appInfo = "Input password matches one of the fraud passwords.";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_BAD_PATTERN_NUM, appInfo);
				log.info(sClassName + sMethodName + "PCFP03 : " + appInfo);
				return hmResult;
			}
		}
		hmResult = CommonErrorMap.makeCommonStatusMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}

	/**
	 * This method is used to filter out the linked users that are of interest.
	 * It takes an ArrayList of linked users and a member number as input.
	 * The method iterates over the ArrayList of linked users and checks if the member number of each user is different from the input member number.
	 * If the member number is different, the user is added to the ArrayList of interested linked users.
	 * The method returns the ArrayList of interested linked users.
	 *
	 * @param alLinkedUsers ArrayList containing the linked users.
	 * @param sMemberNum String representing the member number.
	 * @return ArrayList containing the interested linked users.
	 */
	public ArrayList getInterestedLinkedUsers(ArrayList alLinkedUsers, String sMemberNum) {

		String sMethodName = ".getInterestedLinkedUsers.";
		ArrayList alInterestedLinkedUsers = new ArrayList();

		if (!alLinkedUsers.isEmpty()) {
			Iterator iter = alLinkedUsers.iterator();
			while (iter.hasNext()) {

				HashMap hmEachUser = (HashMap) iter.next();
				String sThisMemberNum = (String) hmEachUser.get(MPSDefs.DB_MEMBER_NUM);

				/**
				 * In the case where we are operating on handle/domain that member_num will be
				 * in the linked_users structure so we have to skip that.
				 */
				if (!sMemberNum.equals(sThisMemberNum)) {
					alInterestedLinkedUsers.add(hmEachUser);
				}
			}
		}
		log.info(sClassName + sMethodName + "GILU-2 : " + "alInterestedLinkedUsers = " + alInterestedLinkedUsers);
		return alInterestedLinkedUsers;
	}

	/**
	 * This method is used to check if the linked users are impacted by CPNI rules.
	 * It takes an ArrayList of linked users as input.
	 * The method iterates over the ArrayList of linked users and checks if the user is impacted by CPNI rules.
	 * If the user is impacted by CPNI rules, the method sets the flag 'isCPNILinkedToSlid' to 'YES'.
	 * The method returns the flag 'isCPNILinkedToSlid'.
	 *
	 * @param alLinkedUsers ArrayList containing the linked users.
	 * @return String indicating whether the linked users are impacted by CPNI rules.
	 */
	public String getCPNILinkedToSLID(ArrayList alLinkedUsers) {

		String sMethodName = ".getCPNILinkedToSLID.";
		String sCPNILinkedToSlid = new String(CommonDefs.DEFAULT_NO);
		HashMap hmService = null;
		String sInstanceId = null;
		java.util.Map.Entry mapEntry = null;

		if (!alLinkedUsers.isEmpty()) {
			Iterator iter = alLinkedUsers.iterator();
			while (iter.hasNext() && !sCPNILinkedToSlid.equals(CommonDefs.DEFAULT_YES)) {

				HashMap hmEachUser = (HashMap) iter.next();
				HashMap hmServices = (HashMap) hmEachUser.get(MPSDefs.SERVICES);
				if (hmServices != null && !hmServices.isEmpty()) {
					Iterator servicesKeyIterator = hmServices.entrySet().iterator();
					while (servicesKeyIterator.hasNext() && !sCPNILinkedToSlid.equals(CommonDefs.DEFAULT_YES)) {
						mapEntry = (java.util.Map.Entry) servicesKeyIterator.next();
						hmService = (HashMap) mapEntry.getValue();

						Iterator iterParentService = hmService.keySet().iterator();
						while (iterParentService.hasNext()) {
							sInstanceId = (String) iterParentService.next();
							Object oInstanceIdObject = hmService.get(sInstanceId);
							if (oInstanceIdObject instanceof HashMap) {
								HashMap hmInstanceId = (HashMap) oInstanceIdObject;
								if (hmInstanceId != null) {
									if (hmInstanceId.get(MPSDefs.DB_CPNI_IMPACTED) != null) {
										String sCpniImpacted = (String) hmInstanceId.get(MPSDefs.DB_CPNI_IMPACTED);
										if (sCpniImpacted.equals(CommonDefs.DEFAULT_YES)) {
											sCPNILinkedToSlid = CommonDefs.DEFAULT_YES;
											break;
										}
									}
								}
							} // end of if object is instance of HashMap
							else {
								if (!sInstanceId.equals(MPSDefs.SERVICE_STATUS)) {
									if (hmService.get(MPSDefs.DB_CPNI_IMPACTED) != null) {
										String sCpniImpacted = (String) hmService.get(MPSDefs.DB_CPNI_IMPACTED);
										if (sCpniImpacted.equals(CommonDefs.DEFAULT_YES)) {
											sCPNILinkedToSlid = CommonDefs.DEFAULT_YES;
										}
									}
									break;
								}

							}
						} // end of while
					} // End of sevices check
				}
			}
		}
		log.info(sClassName + sMethodName + "GGCLS-1 : " + "sCPNILinkedToSlid = " + sCPNILinkedToSlid);
		return sCPNILinkedToSlid;
	}

	/**
	 * This method is used to process the lockout rules for a user.
	 * It takes two HashMaps as input. The first HashMap contains input parameters for the method,
	 * and the second HashMap contains information about the member from the database.
	 * The method checks if the user is eligible for lockout based on the input parameters and member information.
	 * If the user is eligible for lockout, it prepares the input for the LockoutHelper.processLockoutRules method and makes the call.
	 * It then checks the status code returned by the processLockoutRules method. If the status code is not 'COMMON_SUCCESS', it prepares an error HashMap and returns it.
	 * If the status code is 'COMMON_SUCCESS', it checks if there are any active locks for the user. If there are, it prepares the input for the LockoutHelper.processLockoutRules method and makes the call.
	 * It then checks the status code returned by the processLockoutRules method. If the status code is not 'COMMON_SUCCESS', it prepares an error HashMap and returns it.
	 * If the status code is 'COMMON_SUCCESS', it checks if there are any non-expired non-active locks for the user. If there are, it prepares the input for the LockoutHelper.processLockoutRules method and makes the call.
	 * It then checks the status code returned by the processLockoutRules method. If the status code is not 'COMMON_SUCCESS', it prepares an error HashMap and returns it.
	 * If the status code is 'COMMON_SUCCESS', it returns the result HashMap.
	 * In case of any exception, it logs the error and returns an error HashMap.
	 *
	 * @param hmInput HashMap containing the input parameters for the method.
	 * @param hmDBMember HashMap containing the member information from the database.
	 * @return HashMap containing the result of the lockout process.
	 */
	public HashMap processLocks(HashMap hmInput, HashMap hmDBMember) {
		HashMap hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "");
		String sAppStatusCode = "";
		String sAppInfo = "";
		String sMethodName = ".processLocks.";

		String sHandle = (String) hmInput.get(CommonDefs.HANDLE);
		String sDomain = (String) hmInput.get(CommonDefs.DOMAIN);
		String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
		String sSecondaryLockName = (String) hmInput.get("SECONDARY_LOCK_NAME");
		sSecondaryLockName = (sSecondaryLockName == null) ? "" : sSecondaryLockName;
		String sValidateStatus = (String) hmInput.get(CommonDefs.VALIDATION_STATUS);
		sValidateStatus = (sValidateStatus == null) ? CommonDefs.VALIDATION_STATUS_SUCCESS : sValidateStatus;

		ArrayList alMemberLockout = new ArrayList();
		ArrayList alActiveLocks = (ArrayList) hmInput.get(CommonDefs.ACTIVE_LOCKS);
		ArrayList alExpiredLocks = (ArrayList) hmInput.get(CommonDefs.EXPIRED_LOCKS);
		ArrayList alNonExpiredNonActiveLocks = (ArrayList) hmInput.get(CommonDefs.NONEXPIRED_NONACTIVE_LOCKS);
		String sLockoutName = (String) hmInput.get(MPSDefs.DB_LOCKOUT_NAME);
		boolean isSecondaryLockFound = false;
		ArrayList alFoundSecondaryLocks = new ArrayList();

		try {
			ArrayList alAgentList = (ArrayList) hmInput.get("AGENT_LIST");
			if (alActiveLocks != null && !alActiveLocks.isEmpty()) {
				ArrayList alInterestedLocks = new ArrayList();
				ArrayList alSecondaryInterestedLocks = new ArrayList();
				Iterator iter = alActiveLocks.iterator();
				while (iter.hasNext()) {
					HashMap hmEachLock = (HashMap) iter.next();
					String sLockName = (String) hmEachLock.get(MPSDefs.DB_LOCKOUT_NAME);
					if (alAgentList == null || !alAgentList.contains(sCallingSystemId)) {
						if (sLockName.equals(sLockoutName))
							alInterestedLocks.add(hmEachLock);
						if (sSecondaryLockName.length() > 0 && sLockName.equals(sSecondaryLockName)) {
							isSecondaryLockFound = true;
							alFoundSecondaryLocks.add(sLockName);
							alSecondaryInterestedLocks.add(hmEachLock);
						}
					} else if (alAgentList != null && alAgentList.contains(sCallingSystemId)) {
						if (sLockName.equals(CommonDefs.CHANGE_PASSWORD))
							alInterestedLocks.add(hmEachLock);
					}
				}

				if (!alInterestedLocks.isEmpty()) {
					hmResponse = oLockoutHelper.processLockoutRules(alInterestedLocks, sValidateStatus, sHandle,
							sDomain, "MID");
					sAppStatusCode = (String) hmResponse.get(MPSDefs.APP_STATUS_CODE);

					if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
						return hmResponse;

					if (hmResponse.containsKey("lockInfo")) {
						ArrayList alTheseLocks = (ArrayList) hmResponse.get("lockInfo");
						alMemberLockout.addAll(alTheseLocks);
					}
				}
				if (!alSecondaryInterestedLocks.isEmpty()) {
					hmResponse = oLockoutHelper.processLockoutRules(alSecondaryInterestedLocks,
							CommonDefs.VALIDATION_STATUS_FAILURE, sHandle, sDomain, "MID");
					sAppStatusCode = (String) hmResponse.get(MPSDefs.APP_STATUS_CODE);

					if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
						return hmResponse;

					if (hmResponse.containsKey("lockInfo")) {
						ArrayList alTheseLocks = (ArrayList) hmResponse.get("lockInfo");
						alMemberLockout.addAll(alTheseLocks);
					}
				}
			} // end activeLocks

			// We will remove all expired locks
			if (alExpiredLocks != null && !alExpiredLocks.isEmpty()
					&& (alAgentList == null || !alAgentList.contains(sCallingSystemId))) {
				hmResponse = oLockoutHelper.processLockoutRules(alExpiredLocks, sValidateStatus, sHandle, sDomain,
						"MID");
				sAppStatusCode = (String) hmResponse.get(MPSDefs.APP_STATUS_CODE);

				if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
					return hmResponse;

				if (hmResponse.containsKey("lockInfo")) {
					ArrayList alTheseLocks = (ArrayList) hmResponse.get("lockInfo");
					alMemberLockout.addAll(alTheseLocks);
				}
			}

			if (alNonExpiredNonActiveLocks != null && !alNonExpiredNonActiveLocks.isEmpty()
					&& (alAgentList == null || !alAgentList.contains(sCallingSystemId))) {
				ArrayList alInterestedLocks = new ArrayList();
				ArrayList alSecondaryInterestedLocks = new ArrayList();
				Iterator iter = alNonExpiredNonActiveLocks.iterator();
				while (iter.hasNext()) {
					HashMap hmEachLock = (HashMap) iter.next();
					String sLockName = (String) hmEachLock.get(MPSDefs.DB_LOCKOUT_NAME);
					if (sLockName.equals(sLockoutName))
						alInterestedLocks.add(hmEachLock);
					if (sSecondaryLockName.length() > 0 && sLockName.equals(sSecondaryLockName)) {
						isSecondaryLockFound = true;
						alFoundSecondaryLocks.add(sLockName);
						alSecondaryInterestedLocks.add(hmEachLock);
					}
				}
				if (!alInterestedLocks.isEmpty()) {
					hmResponse = oLockoutHelper.processLockoutRules(alInterestedLocks, sValidateStatus, sHandle,
							sDomain, "MID");
					sAppStatusCode = (String) hmResponse.get(MPSDefs.APP_STATUS_CODE);

					if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
						return hmResponse;

					if (hmResponse.containsKey("lockInfo")) {
						ArrayList alTheseLocks = (ArrayList) hmResponse.get("lockInfo");
						alMemberLockout.addAll(alTheseLocks);
					}
				}
				if (!alSecondaryInterestedLocks.isEmpty()) {
					hmResponse = oLockoutHelper.processLockoutRules(alSecondaryInterestedLocks,
							CommonDefs.VALIDATION_STATUS_FAILURE, sHandle, sDomain, "MID");
					sAppStatusCode = (String) hmResponse.get(MPSDefs.APP_STATUS_CODE);

					if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
						return hmResponse;

					if (hmResponse.containsKey("lockInfo")) {
						ArrayList alTheseLocks = (ArrayList) hmResponse.get("lockInfo");
						alMemberLockout.addAll(alTheseLocks);
					}
				} // end nonExpiredNonActiveLocks
			}

			if (sSecondaryLockName.length() > 0 && !isSecondaryLockFound
					&& (alAgentList == null || !alAgentList.contains(sCallingSystemId))) {
				ArrayList alNewLock = new ArrayList();
				HashMap hmNewLock = new HashMap();
				String sSlidMemberNum = (String) hmDBMember.get(MPSDefs.DB_SLID_MEMBER_NUM);
				if (sSlidMemberNum != null && sSlidMemberNum.length() > 0)
					hmNewLock.put(MPSDefs.DB_MEMBER_NUM, sSlidMemberNum);
				else
					hmNewLock.put(MPSDefs.DB_MEMBER_NUM, hmInput.get(CommonDefs.MEMBER_NUM));
				hmNewLock.put(MPSDefs.DB_LOCKOUT_NAME, sSecondaryLockName);
				alNewLock.add(hmNewLock);

				hmResponse = oLockoutHelper.processLockoutRules(alNewLock, CommonDefs.VALIDATION_STATUS_FAILURE,
						sHandle, sDomain, "MID");
				sAppStatusCode = (String) hmResponse.get(MPSDefs.APP_STATUS_CODE);

				if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
					return hmResponse;

				if (hmResponse.containsKey("lockInfo")) {
					ArrayList alTheseLocks = (ArrayList) hmResponse.get("lockInfo");
					alMemberLockout.addAll(alTheseLocks);
				}
			}

			if (alMemberLockout.size() > 0)
				hmResponse.put(MPSDefs.DB_MEMBERLOCKOUT, alMemberLockout);
		} catch (Exception e) {
			hmResponse = CommonErrorMap.makeExceptionMap(e);
			sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
			log.info(sClassName + sMethodName + "PL-1a : " + "Exception = " + e.getMessage());
		} finally {
			if (hmResponse == null) {
				sAppInfo = "statusTMS is null";
				log.info(sClassName + sMethodName + "PL-2 : " + sAppInfo);
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
			}
			sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
			log.info(sClassName + sMethodName + "PL-3 : " + "result of processLocks = " + hmResponse);
		}
		return hmResponse;
	}

	/**
	 * This method is used to retrieve the authentication information for a user.
	 * It takes two HashMaps and a String as input. The first HashMap contains input parameters for the method,
	 * the second HashMap contains information about the member from the database,
	 * and the String indicates whether to call the Clarify system.
	 * The method performs various operations such as checking for the presence of a BAN in the member data,
	 * generating a temporary password if necessary, and preparing the data for Dbus.
	 * It interacts with other helper classes such as passwordHelper, oQueryProfileProofingInfo_H, and others.
	 * It returns a HashMap containing the result of the authentication data retrieval process.
	 *
	 * @param inHs HashMap containing the input parameters for the method.
	 * @param mpsMemberHs HashMap containing the member information from the database.
	 * @param sCallClarify String indicating whether to call the Clarify system.
	 * @return HashMap containing the result of the authentication data retrieval process.
	 */
	public HashMap getCredentialsData(HashMap inHs, HashMap mpsMemberHs, String sCallClarify) {
		HashMap statusTMS = null;
		String sMethodName = ".getCredentialsData.";
		String appStatusCode = "";
		String appInfo = "";
		log.info(sClassName + sMethodName + "CPH7-1 : " + "Input hash to getCredentialsData():: " + inHs);

		String parentChildInd = null;
		String sor = null;

		String sBan = (String) mpsMemberHs.get(CommonDefs.BAN);

		parentChildInd = (String) mpsMemberHs.get(MPSDefs.DB_PARENT_CHILD_IND);
		sor = (String) mpsMemberHs.get(MPSDefs.DB_SOR_NAME);

		HashMap inputParams = new HashMap();
		HashMap credentialsHs = null;
		HashMap hmGetAuthInfoResult = CommonUtil.getHashMap();

		/* commenting if and else part as it is no longer needed, to fix the CALM MS issue -
		if (sBan != null && sBan.length() > 0 && sCallClarify.equals(CommonDefs.DEFAULT_YES) && parentChildInd != null
				&& parentChildInd.equals(MPSDefs.MPS_PARENT) && sor.equals(MPSDefs.SOR_LS)) {

			// if mps BAN is null, return error

			inputParams.put(CommonDefs.BAN, sBan);
			inputParams.put(CommonDefs.CALLING_SYSTEM_ID, inHs.get(CommonDefs.CALLING_SYSTEM_ID));
			inputParams.put(CommonDefs.TRANSACTION_ID, inHs.get(CommonDefs.TRANSACTION_ID));
			inputParams.put(CommonDefs.TRANSACTION_NAME, inHs.get(CommonDefs.TRANSACTION_NAME));

			// Re-added since some required data was not there in the other method. -rl1364,
			// 12/28/2007
			credentialsHs = oQueryProfileProofingInfo_H.queryCRMProofingInfo(inputParams);
			appStatusCode = (String) credentialsHs.get(MPSDefs.APP_STATUS_CODE);
			if (!appStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
				appInfo = "queryCRMProofingInfo returns error.";
				log.info(sClassName + sMethodName + "CPH7-5 : " + appInfo);
				return credentialsHs;
			} else {

				String credProofZip = (String) credentialsHs.get(CommonDefs.PROOF_ZIP);

				/*
				 * if (credProofZip != null && credProofZip.trim().length() != 0) { HashMap
				 * zipHash = CommonHelper.validateAndGetFormattedZip(credProofZip, minf);
				 * appStatusCode = (String) zipHash.get(MPSDefs.APP_STATUS_CODE); appInfo =
				 * (String) zipHash.get(MPSDefs.APP_INFO); // If zip is reformatted successfully
				 * use the new value // otherwise use the unformatted value if
				 * (appStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
				 * credentialsHs.put(CommonDefs.PROOF_ZIP, zipHash.get(CommonDefs.ZIP)); } }


				hmGetAuthInfoResult = credentialsHs;
				credentialsHs.put(CommonDefs.COMMON_APP_STATUS_CODE, CErrorDefs.COMMON_SUCCESS);
				log.info(sClassName + sMethodName + "CPH7-8 : " + "Returning credentialsHs = " + credentialsHs);

				return credentialsHs;
			}
		} else {
		*/
		credentialsHs = generateCRMHashMap(mpsMemberHs);
			if (credentialsHs != null && !credentialsHs.containsKey(CommonDefs.COMMON_APP_STATUS_CODE)) {
				credentialsHs.put(CommonDefs.COMMON_APP_STATUS_CODE, CErrorDefs.COMMON_SUCCESS);
			}
			log.info("{}{}CPH7-9 : Returning mpsMemberHs values = {} ",sClassName,sMethodName,HtmlUtils.htmlEscape(String.valueOf(credentialsHs)));
			return credentialsHs;

	}

	/**
	 * This method is used to generate a HashMap containing authentication information for a user.
	 * It takes a HashMap as input which contains information about the member from the database.
	 * The method retrieves various pieces of information from the input HashMap, such as the handle, domain, member number, and others.
	 * It then puts these pieces of information into a new HashMap, which it returns.
	 * The returned HashMap can be used for further processing, such as generating a password or checking for fraud.
	 *
	 * @param mpsMemberHs HashMap containing the member information from the database.
	 * @return HashMap containing the authentication information for the user.
	 */
	public HashMap generateCRMHashMap(HashMap mpsMemberHs) {

		final String sMethodName = ".generateCRMHashMap.";
		String sAppInfo = null;
		String sAppStatusCode = null;

		HashMap hmResponse = null;
		HashMap outputHs = new HashMap();

		try {
			outputHs.put(CommonDefs.SECURITY_QUESTION, mpsMemberHs.get(MPSDefs.DB_SECURITY_QUESTION));
			outputHs.put(CommonDefs.SECURITY_ANSWER, mpsMemberHs.get(MPSDefs.DB_SECURITY_ANSWER));
			outputHs.put(CommonDefs.SECURITY_ANSWER_VENC, mpsMemberHs.get(MPSDefs.DB_SECURITY_ANSWER_VENC));
			outputHs.put(CommonDefs.FIRST_NAME, mpsMemberHs.get(MPSDefs.DB_LC_FIRSTNAME));
			outputHs.put(CommonDefs.LAST_NAME, mpsMemberHs.get(MPSDefs.DB_LC_LASTNAME));
			outputHs.put(CommonDefs.NICKNAME, mpsMemberHs.get(MPSDefs.DB_NICKNAME));
			outputHs.put(CommonDefs.GENDER, mpsMemberHs.get(MPSDefs.DB_GENDER));

			outputHs.put(CommonDefs.DATE_OF_BIRTH, mpsMemberHs.get(MPSDefs.DB_BIRTHDATE));
			// Removing time from dateOfBirth where necessary
			String dob = (String) mpsMemberHs.get(MPSDefs.DB_BIRTHDATE);

			String sBirthDateEncryp = (String) mpsMemberHs.get(MPSDefs.DB_BIRTHDATE_ENCRYPTED);

			if (sBirthDateEncryp == null && mpsMemberHs.get(MPSDefs.DB_BIRTHDATE_VENC) == null) {

				String sConsiderClearBirthDate = PropertyManager
						.getProperty(CommonDefs.MOUPConfig, CommonDefs.PROP_CONSIDER_CLEAR_BIRTH_DATE);

				log.info(sClassName + sMethodName + "TMS42.1 : " + "ConsiderClearBirthDate Value from Config File = "
						+ sConsiderClearBirthDate);

				if (sConsiderClearBirthDate == null || !(sConsiderClearBirthDate.length() > 0)) {
					sAppInfo = "Could not find ConsiderClearBirthDate key in config file";
					log.info(sClassName + sMethodName + "TMS42.2 : " + sAppInfo);
					outputHs = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, sAppInfo);
					return outputHs;
				}

				if (sConsiderClearBirthDate != null && sConsiderClearBirthDate.equals(MPSDefs.YES) && dob != null) {
					outputHs.put(CommonDefs.DATE_OF_BIRTH, dob.substring(0, 8));
				}
			} else {
				String sSPIEncryptionType = PropertyManager
						.getProperty(CommonDefs.MOUPConfig, CommonDefs.PROP_SPI_ENCRYPTION_TYPE);
				sSPIEncryptionType = (sSPIEncryptionType == null || sSPIEncryptionType.length() == 0)
						? CommonDefs.SPI_ENCRYPTION_TYPE_AES
						: sSPIEncryptionType;
				log.info(sClassName + sMethodName + "TMS42.1a : " + "SPI_ENCRYPTION_TYPE = " + sSPIEncryptionType);

				HashMap hmDecryptInput = new HashMap();
				if (sSPIEncryptionType.equals(CommonDefs.SPI_ENCRYPTION_TYPE_VOLTAGE)) {

					hmDecryptInput.put(MPSDefs.DB_BIRTHDATE_VENC, mpsMemberHs.get(MPSDefs.DB_BIRTHDATE_VENC));

					log.info("{}{}TMS42.2.1 : getDecryptedValues input hash = {}",StringUtils.normalizeSpace(sClassName),StringUtils.normalizeSpace(sMethodName),StringUtils.normalizeSpace(hmDecryptInput != null ? hmDecryptInput.toString() : null));
					HashMap hmProofingResponse = (HashMap) oProofingEncryption_H.getDecryptedValues(hmDecryptInput);

					if (hmProofingResponse == null || hmProofingResponse.isEmpty()) {
						sAppInfo = "ProofingEncryption_H returned null/empty response";
						outputHs = CommonErrorMap.makeCommonStatusMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
						log.info(sClassName + sMethodName + "CPH10-5.1 : " + sAppInfo);
						return outputHs;
					}
					sAppStatusCode = (String) hmProofingResponse.get(MPSDefs.APP_STATUS_CODE);
					if (sAppStatusCode != null && !sAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
						sAppInfo = (String) hmProofingResponse.get(MPSDefs.APP_INFO);
						log.info("{}{}CPH10-5.2 : {}",StringUtils.normalizeSpace(sClassName),StringUtils.normalizeSpace(sMethodName),StringUtils.normalizeSpace(sAppInfo));
						return hmProofingResponse;
					}
					hmResponse = hmProofingResponse;
					log.info("{}{}TMS42.2.2 : getDecryptedValues response : {}",StringUtils.normalizeSpace(sClassName),StringUtils.normalizeSpace(sMethodName),StringUtils.normalizeSpace(hmResponse != null ? hmResponse.toString() : null));

					String sClearBirthDate = (String) hmResponse.get(MPSDefs.DB_BIRTHDATE_VENC);
					outputHs.put(CommonDefs.DATE_OF_BIRTH, sClearBirthDate);
				} else {
					if (mpsMemberHs.get(MPSDefs.DB_BIRTHDATE_ENCRYPTED) == null) {
						String sDbBirthdate = (String) mpsMemberHs.get(MPSDefs.DB_BIRTHDATE);
						int tem_index = sDbBirthdate.lastIndexOf(' ');

						if (tem_index != -1) {
							sDbBirthdate = sDbBirthdate.substring(0, tem_index);
						}
						outputHs.put(CommonDefs.DATE_OF_BIRTH, sDbBirthdate);

					} else {
						HashMap hmDecryptionInput = new HashMap();

						hmDecryptionInput.put(MPSDefs.DB_BIRTHDATE_ENCRYPTED,
								mpsMemberHs.get(MPSDefs.DB_BIRTHDATE_ENCRYPTED));
						log.info(sClassName + sMethodName + "TMS42.3.1 : " + "getDecryptedValues input hash : "
								+ hmDecryptionInput);

						HashMap hmProofingResponse = (HashMap) oProofingEncryption_H.getDecryptedValues(hmDecryptInput);

						if (hmProofingResponse == null || hmProofingResponse.isEmpty()) {
							sAppInfo = "ProofingEncryption_H returned null/empty response";
							outputHs = CommonErrorMap.makeCommonStatusMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
							log.info(sClassName + sMethodName + "CPH10-5.1 : " + sAppInfo);
							return outputHs;
						}
						sAppStatusCode = (String) hmProofingResponse.get(MPSDefs.APP_STATUS_CODE);
						if (sAppStatusCode != null && !sAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
							sAppInfo = (String) hmProofingResponse.get(MPSDefs.APP_INFO);
							log.info("{}{}CPH10-5.2 : {}",StringUtils.normalizeSpace(sClassName),StringUtils.normalizeSpace(sMethodName),StringUtils.normalizeSpace(sAppInfo));
							return hmProofingResponse;
						}
						hmResponse = hmProofingResponse;
						log.info("{}{}TMS42.3.2 : getDecryptedValues response : {}",StringUtils.normalizeSpace(sClassName),StringUtils.normalizeSpace(sMethodName),
								StringUtils.normalizeSpace(hmResponse != null ? hmResponse.toString() : null));

						String sClearBirthDate = (String) hmResponse.get(MPSDefs.DB_BIRTHDATE_ENCRYPTED);
						outputHs.put(CommonDefs.DATE_OF_BIRTH, sClearBirthDate);
					}
				}
			}

			outputHs.put(CommonDefs.LAST_FOUR_SSN, mpsMemberHs.get(MPSDefs.DB_LAST_FOUR_SSN));

			outputHs.put(CommonDefs.PROOF_ZIP, mpsMemberHs.get(MPSDefs.DB_PROOFING_ZIP));

			// Now formatting the proofZip. -rl1364, 1/8/2007
			String credProofZip = (String) mpsMemberHs.get(MPSDefs.DB_PROOFING_ZIP);

			/*
			 * if (credProofZip != null && credProofZip.trim().length() != 0) { HashMap
			 * zipHash = CommonHelper.validateAndGetFormattedZip(credProofZip, minf); String
			 * appStatusCode = (String) zipHash.get(MPSDefs.APP_STATUS_CODE); // If zip is
			 * reformatted successfully use the new value // otherwise use the unformatted
			 * value if (appStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
			 * outputHs.put(CommonDefs.PROOF_ZIP, zipHash.get(CommonDefs.ZIP)); } }
			 */

			// Adding the CPNI Fields
			outputHs.put(CommonDefs.ONLINE1_SECURITY_QUESTION, mpsMemberHs.get(MPSDefs.DB_SECURITY_QUESTION_1));
			outputHs.put(CommonDefs.ONLINE1_SECURITY_ANSWER, mpsMemberHs.get(MPSDefs.DB_SECURITY_ANSWER_1));
			outputHs.put(CommonDefs.ONLINE2_SECURITY_QUESTION, mpsMemberHs.get(MPSDefs.DB_SECURITY_QUESTION_2));
			outputHs.put(CommonDefs.ONLINE2_SECURITY_ANSWER, mpsMemberHs.get(MPSDefs.DB_SECURITY_ANSWER_2));
			// --outputHs.put(CommonDefs.PASSCODE, mpsMemberHs.get(MPSDefs.DB_PASSCODE));
			// //--1210
			outputHs.put(CommonDefs.PASSCODE_VENC, mpsMemberHs.get(MPSDefs.DB_PASSCODE_VENC));
		} catch (Exception excp) {
			sAppInfo = "Exception :" + excp.getMessage();
			outputHs = CommonErrorMap.makeExceptionMap(excp);
			String sAppCategoryCode = (String) outputHs.get(CommonDefs.COMMON_APP_STATUS_CODE);
			log.info(sClassName + sMethodName + "TMS42.3 : " + sAppInfo);
			return outputHs;
		}
		return outputHs;
	}

	
	/**
	 * This method is used to generate a HashMap containing authentication information for a user.
	 * It takes two HashMaps as input. The first HashMap contains input parameters for the method,
	 * and the second HashMap contains information about the member from the database.
	 * The method retrieves various pieces of information from the input HashMaps, such as the handle, domain, member number, and others.
	 * It then puts these pieces of information into a new HashMap, which it returns.
	 * The returned HashMap can be used for further processing, such as generating a password or checking for fraud.
	 *
	 * @param inHs HashMap containing the input parameters for the method.
	 * @param mpsMemberHs HashMap containing the member information from the database.
	 * @return HashMap containing the authentication information for the user.
	 */
	public HashMap generateHmGACH(HashMap inHs, HashMap mpsMemberHs) {

		HashMap hmGACH = new HashMap();
		hmGACH.put(CommonDefs.CALLING_SYSTEM_ID, inHs.get(CommonDefs.CALLING_SYSTEM_ID));
		hmGACH.put(CommonDefs.TRANSACTION_ID, inHs.get(CommonDefs.TRANSACTION_ID));
		hmGACH.put(CommonDefs.TRANSACTION_NAME, inHs.get(CommonDefs.TRANSACTION_NAME));
		hmGACH.put(CommonDefs.HANDLE, mpsMemberHs.get(MPSDefs.DB_MEMBER_NAME));
		hmGACH.put(CommonDefs.DOMAIN, mpsMemberHs.get(MPSDefs.DB_DOMAIN_NAME));
		hmGACH.put(CommonDefs.DB_MEMBER_NUM, mpsMemberHs.get(CommonDefs.DB_MEMBER_NUM));
		hmGACH.put(CommonDefs.SOR, mpsMemberHs.get(MPSDefs.DB_SOR_NAME));
		hmGACH.put(MPSDefs.DB_FAILED_AUTH_COUNT, mpsMemberHs.get(MPSDefs.DB_FAILED_AUTH_COUNT));
		hmGACH.put(MPSDefs.DB_LOCKOUT_TIMESTAMP, mpsMemberHs.get(MPSDefs.DB_LOCKOUT_TIMESTAMP));

		hmGACH.put(CommonDefs.DATE_OF_BIRTH, inHs.get(CommonDefs.DATE_OF_BIRTH));
		hmGACH.put(MPSDefs.DB_AGG_EMAIL_STATUS, mpsMemberHs.get(MPSDefs.DB_AGG_EMAIL_STATUS));
		hmGACH.put(CommonDefs.BAN, mpsMemberHs.get(CommonDefs.BAN));
		hmGACH.put(CommonDefs.DB_PARENT_CHILD_IND, mpsMemberHs.get(MPSDefs.DB_PARENT_CHILD_IND));
		hmGACH.put(CommonDefs.AGENT_ID, inHs.get(CommonDefs.AGENT_ID));
		hmGACH.put(CommonDefs.DB_CONTACT_EMAIL, mpsMemberHs.get(MPSDefs.DB_CONTACT_EMAIL));

		if (inHs.get(CommonDefs.IS_PRIMARY_CALLING) != null) {
			hmGACH.put(CommonDefs.IS_PRIMARY_CALLING, inHs.get(CommonDefs.IS_PRIMARY_CALLING));
		}

		return hmGACH;
	}

	/**
	 * This method is used to build a HashMap containing the necessary information for a CreateInteraction event.
	 * It takes two HashMaps as input. The first HashMap contains input parameters for the method,
	 * and the second HashMap contains information about the member from the database.
	 * The method retrieves various pieces of information from the input HashMaps, such as the handle, domain, member number, and others.
	 * It then puts these pieces of information into a new HashMap, which it returns.
	 * The returned HashMap can be used for further processing, such as generating a password or checking for fraud.
	 *
	 * @param hmInput HashMap containing the input parameters for the method.
	 * @param hmDBGetMemberServices HashMap containing the member information from the database.
	 * @return HashMap containing the necessary information for a CreateInteraction event.
	 */
	public HashMap buildCreateInteractionHash(HashMap hmInput, HashMap hmDBGetMemberServices) {
		String sMethodName = ".buildCreateInteractionHash.";
		log.info(sClassName + sMethodName + "BCIH-1 : " + "Input hashmap :: " + hmInput);

		HashMap hmReturnStatus = null;
		String sAppStatusCode = null;
		String sAppInfo = null;

		String sHandle = (String) hmInput.get(CommonDefs.HANDLE);
		String sDomain = (String) hmInput.get(CommonDefs.DOMAIN);

		String sMemberId = sHandle + "@" + sDomain;
		String isPrimaryCalling = MPSDefs.NO;
		String sUnderAgeIndicator = MPSDefs.NO;
		String isMemberIDEmailEligible = MPSDefs.NO;

		//log.info(sClassName + sMethodName + "BCIH-2a : " + "Before local variable assignments.");

		try {
			String sAlterNativeEmailAddress = (String) hmDBGetMemberServices.get(CommonDefs.DB_CONTACT_EMAIL);
			String sBan = (String) hmDBGetMemberServices.get(CommonDefs.BAN);
			if (sBan == null && hmDBGetMemberServices != null)
				sBan = (String) hmDBGetMemberServices.get(CommonDefs.BAN);

			if (sBan == null) {
				sAppInfo = "No BAN.";
				log.info(sClassName + sMethodName + "GAC302 : " + sAppInfo);
				hmReturnStatus = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, sAppInfo);
				return hmReturnStatus;
			}

			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);

			String sSor = (String) hmDBGetMemberServices.get(CommonDefs.SOR);
			if (sSor == null && hmDBGetMemberServices != null)
				sSor = (String) hmDBGetMemberServices.get(CommonDefs.SOR_NAME);
			String sParentChildInd = (String) hmDBGetMemberServices.get(CommonDefs.DB_PARENT_CHILD_IND);
			if (sParentChildInd == null && hmDBGetMemberServices != null)
				sParentChildInd = (String) hmDBGetMemberServices.get(MPSDefs.DB_PARENT_CHILD_IND);
			String sResult = (String) hmInput.get(CommonDefs.CREATE_INTERACTION_RESULT);
			if (sResult == null)
				sResult = CommonDefs.REASON_CODE_SUCCESS;

			String sAgentId = (String) hmInput.get(CommonDefs.AGENT_ID);
			String sCurrentFailedAuthCount = (String) hmDBGetMemberServices.get(MPSDefs.DB_FAILED_AUTH_COUNT);
			if (sCurrentFailedAuthCount == null && hmDBGetMemberServices != null)
				sCurrentFailedAuthCount = (String) hmDBGetMemberServices.get(MPSDefs.DB_FAILED_AUTH_COUNT);

			String sContextName = null;
			String sReasonCode1 = null;
			String sReasonCode2 = null;

			String sCreateInteractionExcpList = PropertyManager
					.getProperty(CommonDefs.MOUPConfig, CommonDefs.CREATE_INTERACTION_EXCEPTION_LIST);
			ArrayList alCreateInteractionExcpList = CommonUtil.getArrayList();

			log.info(sClassName + sMethodName + "GAC302a : sCreateInteractionExcpList = " + sCreateInteractionExcpList);

			if (sCreateInteractionExcpList != null && sCreateInteractionExcpList.trim().length() > 0)
				alCreateInteractionExcpList = CommonUtil.parseToArray(sCreateInteractionExcpList,
						CommonDefs.VALUE_SEPARATOR_CHAR);

			if (alCreateInteractionExcpList.contains(sCallingSystemId) || !sSor.equalsIgnoreCase(MPSDefs.SOR_LS)) {
				sAppInfo = sCallingSystemId
						+ " is in CreateInteractionExceptionList or User does not have LS sor. No interaction with LS CRM is required.";
				hmReturnStatus = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, sAppInfo);
				log.info(sClassName + sMethodName + "GAC303 : " + sAppInfo);
				return hmReturnStatus;
			}

			if (sResult.equalsIgnoreCase(CommonDefs.REASON_CODE_FAILED)) {
				sContextName = CommonDefs.FAILED_CREATE_INTERACTION_SUBCONTEXT;
				sReasonCode1 = CommonDefs.REASON_CODE_AUTHENTICATION;
				sReasonCode2 = CommonDefs.REASON_CODE_FAILED;
			} else {
				sReasonCode1 = CommonDefs.REASON_CODE_ACCOUNT_MANAGEMENT;
				sContextName = CommonDefs.SUCCESS_CREATE_INTERACTION_SUBCONTEXT;

				if (sTransactionName.equalsIgnoreCase(CommonDefs.TRANS_NAME_CHANGE_PWD)
						|| sTransactionName.equalsIgnoreCase(CommonDefs.TRANS_NAME_LINK_INTERNET_ACCOUNT))
					sReasonCode2 = CommonDefs.REASON_CODE_CHANGE_MEM_PWD;
				else if (sTransactionName.equalsIgnoreCase(CommonDefs.TRANS_NAME_CHANGE_SUB_PWD))
					sReasonCode2 = CommonDefs.REASON_CODE_CHANGE_SUB_PWD;
				else if (sTransactionName.equalsIgnoreCase(CommonDefs.TRANS_NAME_RESET_PWD)) {
					if (sParentChildInd.equals(MPSDefs.MPS_PARENT))
						sReasonCode2 = CommonDefs.REASON_CODE_RESET_MEM_PWD;
					else
						sReasonCode2 = CommonDefs.REASON_CODE_RESET_SUB_PWD;
				}

				if (hmInput.get(CommonDefs.IS_PRIMARY_CALLING) != null
						&& ((String) hmInput.get(CommonDefs.IS_PRIMARY_CALLING)).trim().length() > 0)
					isPrimaryCalling = (String) hmInput.get(CommonDefs.IS_PRIMARY_CALLING);
				else if (sParentChildInd != null && sParentChildInd.equals(MPSDefs.MPS_PARENT))
					isPrimaryCalling = MPSDefs.YES;
				String sBirthDay = (String) hmInput.get(CommonDefs.DATE_OF_BIRTH);

				if (sBirthDay != null && sBirthDay.length() != 0)
					if (getAgeFromBirthday(sBirthDay) < CommonDefs.MINOR_AGE)
						sUnderAgeIndicator = MPSDefs.YES;

				log.info(sClassName + sMethodName + "BCIH-3a : " + "Before sAggEmailStatus assignment.");

				String sAggEmailStatus = null;
				sAggEmailStatus = (String) hmDBGetMemberServices.get(MPSDefs.DB_AGG_EMAIL_STATUS);
				if (sAggEmailStatus == null && hmDBGetMemberServices != null)
					sAggEmailStatus = (String) hmDBGetMemberServices.get(MPSDefs.DB_AGG_EMAIL_STATUS);
				if (sAggEmailStatus != null && sAggEmailStatus.length() != 0)
					if (Integer.parseInt(sAggEmailStatus) == 0)
						isMemberIDEmailEligible = MPSDefs.YES;
				log.info(sClassName + sMethodName + "BCIH-3b : " + "After sAggEmailStatus assignment.");
			}

			String sStartTime = setCRMStartTime();

			// added below callingSystemId transalation to translate ISAAC to MPS

			String sTransLateInteractionCallingSystemId = PropertyManager
					.getProperty(CommonDefs.MOUPConfig, CommonDefs.PROP_TRANSLATE_INTERACTION_CALLING_SYSTEM_ID);
			if (sTransLateInteractionCallingSystemId == null
					|| sTransLateInteractionCallingSystemId.trim().length() <= 0) {
				sAppInfo = " TransLateInteractionCallingSystemId property is null or empty in config, so no need to "
						+ "do callingSystemId translation process";

				log.info(sClassName + sMethodName + "GAC303.1 : " + sAppInfo);
			} else {
				ArrayList alTransLateInteractionCallingSystemId = CommonUtil
						.parseToArray(sTransLateInteractionCallingSystemId, CommonDefs.VALUE_SEPARATOR_CHAR);

				if (alTransLateInteractionCallingSystemId != null
						&& alTransLateInteractionCallingSystemId.contains(sCallingSystemId)) {
					sAppInfo = "Translate callingSystemId from " + sCallingSystemId + " to MPS";
					log.info(sClassName + sMethodName + "GAC303.2 : " + sAppInfo);
					sCallingSystemId = CommonDefs.SOR_MPS;

				}
			}

			// Prepare Dbus input now
			HashMap hmDbusInput = CommonUtil.getHashMap();
			hmDbusInput.put(CommonDefs.EVENTNAME, "CreateInteraction");
			
			if(sContextName.equals(CommonDefs.SUCCESS_CREATE_INTERACTION_SUBCONTEXT)){
				hmDbusInput.put(CommonDefs.SUBEVENT, "CreateInteraction");
			} else if(sContextName.equals(CommonDefs.FAILED_CREATE_INTERACTION_SUBCONTEXT)){
				hmDbusInput.put(CommonDefs.SUBEVENT, "FailedAuth");
			}
			
			hmDbusInput.put(CommonDefs.DBUS_DICTIONARY_NAME, "Dict");
			hmDbusInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
			hmDbusInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
			hmDbusInput.put(CommonDefs.HANDLE, sHandle);
			hmDbusInput.put(CommonDefs.DOMAIN, sDomain);
			hmDbusInput.put(CommonDefs.SOR_NAME, sSor);
			hmDbusInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
			hmDbusInput.put(CommonDefs.BAN, sBan);
			hmDbusInput.put(CommonDefs.REASON_CODE_1, sReasonCode1);
			hmDbusInput.put(CommonDefs.REASON_CODE_2, sReasonCode2);
			hmDbusInput.put(CommonDefs.CREATE_INTERACTION_RESULT, sResult);
			hmDbusInput.put(CommonDefs.ATTEMPT_COUNT, sCurrentFailedAuthCount);
			if (sAgentId != null && sAgentId.trim().length() > 0)
				hmDbusInput.put(CommonDefs.AGENT_ID, sAgentId);
			if (sParentChildInd != null)
				hmDbusInput.put(CommonDefs.DB_PARENT_CHILD_IND, sParentChildInd);
			hmDbusInput.put(CommonDefs.LS_CRM_START_TIME, sStartTime);
			hmDbusInput.put(CommonDefs.MEMBERID, sMemberId);
			hmDbusInput.put(CommonDefs.IS_PRIMARY_CALLING, isPrimaryCalling);
			hmDbusInput.put(CommonDefs.UNDER_AGE_INDICATOR, sUnderAgeIndicator);
			hmDbusInput.put(CommonDefs.MEMBERID_EMAIL_ELIGIBLE, isMemberIDEmailEligible);

			if (sAlterNativeEmailAddress != null)
				hmDbusInput.put(CommonDefs.ALTERNATIVE_EMAIL_ADDRESS, sAlterNativeEmailAddress);

			hmReturnStatus = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
					CommonDefs.COMMON_SUCCESS);
			hmReturnStatus.put("CREATEINTERACTIONHASH", hmDbusInput);
		} catch (Exception e) {
			hmReturnStatus = CommonErrorMap.makeExceptionMap(e, log);
		}
		return hmReturnStatus;
	}
	

	/**
	 * This method is used to calculate the age of a user based on their date of birth.
	 * It takes a String representing the user's date of birth as input.
	 * The date of birth should be in the format "MMddyyyy".
	 * The method first parses the date of birth string into a Date object.
	 * It then calculates the difference between the current date and the date of birth in years.
	 * The method returns the age of the user in years.
	 * If the date of birth string cannot be parsed, the method returns -1.
	 *
	 * @param dateOfBirth String representing the user's date of birth in the format "MMddyyyy".
	 * @return int representing the age of the user in years, or -1 if the date of birth string cannot be parsed.
	 */
	public int getAgeFromBirthday(String dateOfBirth) {
		int ageInYears = -1;
		SimpleDateFormat dateFormatter = new SimpleDateFormat("MMddyyyy");
		Calendar age = Calendar.getInstance(Locale.getDefault());
		Date birthday;
		try {
			birthday = dateFormatter.parse(dateOfBirth);
		} catch (ParseException pe) {
			System.err.println(pe);
			return ageInYears;
		}
		age.setTime(new Date(Math.abs(birthday.getTime() - System.currentTimeMillis())));
		ageInYears = age.get(Calendar.YEAR) - 1970;
		return ageInYears;
	}

	/**
	 * This method is used to generate a string representing the current time in a specific format.
	 * The format is "yyyy-MM-ddTHH:mm:ss.SSS±HH:mm", which includes the date, time, and timezone offset.
	 * The method first gets the current date and time, and then formats it according to the specified format.
	 * The timezone offset is calculated and added to the formatted date and time string.
	 * The method returns the final formatted string.
	 *
	 * @return A string representing the current time in the format "yyyy-MM-ddTHH:mm:ss.SSS±HH:mm".
	 */
	public String setCRMStartTime() {
		String sCrmStartTime = null;
		Calendar cal = null;
		SimpleDateFormat datePart = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat timePart = new SimpleDateFormat("HH:mm:ss.SSS");
		SimpleDateFormat offsetPart = new SimpleDateFormat("HH:mm");

		Date currentTime = new Date(System.currentTimeMillis());

		cal = Calendar.getInstance();
		cal.setTime(currentTime);
		int timeZoneOffset = cal.get(Calendar.ZONE_OFFSET) + cal.get(Calendar.DST_OFFSET);

		timeZoneOffset /= 36000000;
		cal.set(2000, 1, 1, Math.abs(timeZoneOffset), 0);

		sCrmStartTime = datePart.format(currentTime) + "T" + timePart.format(currentTime);

		if (timeZoneOffset >= 0)
			sCrmStartTime += "+";
		else
			sCrmStartTime += "-";

		sCrmStartTime += offsetPart.format(cal.getTime());

		return sCrmStartTime;
	}
}