package com.att.idp.idgraphusermanagementms.resource.request;

import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class represents a request to link a member to a user in the system.
 * It contains fields for various details such as transactionName, callingSystemId, userId (accessId), memberId, domain, idpTraceId, and a map for unknownAttributes.
 * Each field has specific constraints such as not null and size limits.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 *
 */
@Data
@Schema(name = "LinkMemberRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
public class LinkMemberRequest {
	private final String transactionName= ProfileOrchestrationConstants.LINK_MEMBER_TRANSACTION_NAME;
	
	@Size(min = 1, max = 20, message =  "CallingSystemId length is invalid|LinkMember")
	private String callingSystemId;
	
	@Schema(name = "accessId")
	@NotNull(message="accessId is required field in input request.|LinkMember")
	@Size(min=1, max=127, message="accessId length is invalid|LinkMember")
	@JsonProperty("accessId")
	private String userId;
	
	@Schema(name = "memberId")
	@NotNull(message="memberId is required field in input request.|LinkMember")
	@Size(min=1, max=127, message="memberId length is invalid|LinkMember")
    protected String memberId;
	
	@Schema(name = "domain")
	@NotNull(message="domain is required field in input request.|LinkMember")
	@Size(min=5, max=30, message="domain length is invalid|LinkMember")
	private String domain;
	
	@Schema(name = "idpTraceId")
	private String idpTraceId;
	
	/**
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
	 * @return Map<String,Object> The map of unknown attributes.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();

	
}
