package com.att.idp.idgraphusermanagementms.service.impl;

import java.util.Map;

import jakarta.ws.rs.core.MultivaluedMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.UpdateUserFraudHelper;
import com.att.idp.idgraphusermanagementms.resource.request.UpdateUserFraudRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdateUserFraudResponse;
import com.att.idp.idgraphusermanagementms.service.UpdateUserFraudService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This class implements the UpdateUserFraudService interface and provides the implementation for updating a user's fraud status in the system.
 * It is annotated with @Service to indicate that it's a Spring Bean and @Transactional to handle the transaction management.
 *
 * It contains a method updateUserFraud which takes an UpdateUserFraudRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return an UpdateUserFraudResponse object.
 *
 * The UpdateUserFraudRequest object encapsulates the details of the user fraud status update operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class UpdateUserFraudServiceImpl implements UpdateUserFraudService{

	public static final Logger logger = LoggerFactory.getLogger(UpdateUserFraudServiceImpl.class);

	private static String sClassName = "UpdateUserFraudServiceImpl";
	
	@Autowired
	private UpdateUserFraudHelper updateUserFraudHelper;
	
	@Override
	public UpdateUserFraudResponse updateUserFraud(UpdateUserFraudRequest updateFraudRequest,
			MultivaluedMap<String, String> requestHeader) {
		
		Map<String, Object> hmResponse = null;
		String sMethodName = ".updateUserFraud.";

		Map<String, Object> hmInput = CommonUtilHelper.objectToMap(updateFraudRequest);

		String idpTraceid = (String) hmInput.get("idpTraceId");
		hmInput.put("dbusTransactionId", idpTraceid.split(":")[0]);
		hmInput.put("handle", (String) hmInput.remove("userId"));
		
		logger.info("UpdateUserFraudServiceImpl.updateUserFraud.UUFS_01 : Calling UpdateUserFraudHelper with Input : {}",hmInput);

		hmResponse = updateUserFraudHelper.updateUserFraud(hmInput);

		logger.info(SpiMarker.getInstance(),"{}{}UUFS_02 : Response from UpdateUserFraudHelper : {}", sClassName, sMethodName, hmResponse);

		if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
			hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from UpdateUserFraudHelper.updateUserFraud");
			logger.info("{}{}UUFS_03 : Null response from UpdateUserFraudHelper.updateUserFraud", sClassName, sMethodName);
		} else {
			String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (stAppStatusCode == null) {
				hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from UpdateUserFraudHelper.updateUserFraud");
				logger.info("{}{}UUFS_04 : Null response from UpdateUserFraudHelper.updateUserFraud", sClassName, sMethodName);
			}
		}

		hmResponse.put("idp-trace-id", updateFraudRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME, "UpdateUserFraud");
		UpdateUserFraudResponse updateUserFraudResponse = CommonUtilHelper.generateUpdateUserFraudResponse(hmResponse);

		String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

		if (sTxnRollBack != null) {
			throw new InvalidInputDataException(hmResponse);
		}
		logger.info(SpiMarker.getInstance(),"{}{}UUFS_05 : Response: {}", sClassName, sMethodName,
				updateUserFraudResponse);
		return updateUserFraudResponse;
		
	}

}
