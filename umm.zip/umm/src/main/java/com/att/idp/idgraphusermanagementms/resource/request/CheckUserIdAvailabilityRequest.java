
package com.att.idp.idgraphusermanagementms.resource.request;

import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.att.mpsys.common.utils.CommonDefs;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class represents a request to check the availability of a user ID in the system.
 * It contains fields for various details such as transactionName, callingSystemId, suggest1, numSuggestions, searchSLIDNamespace, suggest2, domain, ignoreQay, isExternalCall, idpTraceId, and a map for unknownAttributes.
 * Each field has specific constraints such as not null and size limits.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 *
 */
@Schema(name = "CheckUserIdAvailabilityRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class CheckUserIdAvailabilityRequest {

	protected  final String transactionName = "CheckUserIdAvailability";
	
    protected String callingSystemId;
    
	@Schema(name = "suggest1")
    @NotNull(message="Suggest1 is required field in input request.|CheckUserIdAvailabilty")
    @Size(min=1, max=127,message="Suggest1 length is invalid|CheckUserIdAvailabilty")
    protected String suggest1;
    
	@Schema(name = "numSuggestions")
    @NotNull(message="NumSuggestions is required field in input request.|CheckUserIdAvailabilty")
    @Size(min=1,max=1,message="NumSuggestions length is invalid.|CheckUserIdAvailabilty")
    protected String numSuggestions;
    
	protected final String searchSLIDNamespace = CommonDefs.DEFAULT_YES;
    
	@Schema(name = "suggest2")
    @Size(min=1, max=127,message="Suggest2 length is invalid|CheckUserIdAvailabilty")
    protected String suggest2;
    
	@Schema(name = "domain")
    @Size(min=1, max=30,message="Domain length is invalid|CheckUserIdAvailabilty")
    protected String domain;
    
	@Schema(name = "ignoreQay")
    @Size(min=1, max=1,message="ignoreQay value can only be Y or N|CheckUserIdAvailabilty")
    protected String ignoreQay;

	@Schema(name = "isExternalCall")
	protected String isExternalCall;
	
	@Schema(name = "idpTraceId")
	private String idpTraceId;
	
	/**
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
	 * @return Map<String,Object> The map of unknown attributes.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();
	

}
