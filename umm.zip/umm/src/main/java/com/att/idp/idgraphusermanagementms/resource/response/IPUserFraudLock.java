package com.att.idp.idgraphusermanagementms.resource.response;

import lombok.Data;

/**
 * This class represents a user's fraud lock status in the system.
 * It contains fields for memberNum, userLockLevel, and userLockReason.
 * Each field has specific constraints such as not null and size limits.
 *
 * The class uses Lombok's @Data annotation to generate getter and setter methods for all fields.
 *
 */
@Data
public class IPUserFraudLock {

	private String memberNum;
	private String userLockLevel;
	private String userLockReason;
}