package com.att.idp.idgraphusermanagementms.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import com.att.idp.idgraphusermanagementms.db.helper.FraudLockDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.MPSInquireProfileDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.UpdateAssociationDBHelper;
import com.att.idp.idgraphusermanagementms.helper.resetuserpassword.ResetUserPasswordHelper;
import com.att.idp.idgraphusermanagementms.queue.message.helpers.UpdateUserFraudQueueHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This class is a helper class for updating user fraud information in the
 * system. It contains methods for validating input, retrieving user
 * information, and updating the user's fraud information in the database. It
 * uses various other helper classes and services such as
 * MPSInquireProfileDBHelper, FraudLockDBHelper, UpdateAssociationDBHelper,
 * UpdateUserFraudQueueHelper, and ResetUserPasswordHelper. It also uses various
 * constants and utility methods from the CommonDefs, MPSDefs, and CommonUtil
 * classes. The main method in this class is the updateUserFraud method, which
 * takes a HashMap of input parameters and returns a HashMap with the result of
 * the operation.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class UpdateUserFraudHelper {

	public static final Logger logger = LoggerFactory.getLogger(UpdateUserFraudHelper.class);
	private static final String sClassName = "UpdateUserFraudHelper";
	private boolean isTransactionRollbackOnError = false;

	@Value("${accountExclusionList}")
	private String propAccountExclusionList;

	@Value("${executiveFraudExclusionList}")
	private String propExecutiveFraudExclusionList;

	@Autowired
	private MPSInquireProfileDBHelper inquireProfileDBHelperObj;

	@Autowired
	private FraudLockDBHelper fraudLockDBHelperObj;

	@Autowired
	private UpdateAssociationDBHelper updateAssociationDBHelperObj;

	@Autowired
	private UpdateUserFraudQueueHelper updateUserFraudQueueHelperObj;

	@Autowired
	private ResetUserPasswordHelper resetUserPasswordHelperObj;

	@Autowired
	private AccountLockHelper accountLockHelper;

	/**
	 * This method is responsible for updating the user's fraud information in the
	 * system. It first validates the input parameters and retrieves the user's
	 * current fraud information from the database. If the user's fraud information
	 * needs to be updated, it prepares the necessary data and calls the
	 * FraudLockDBHelper's updateUserFraudLock method to update the fraud
	 * information. If the updateUserFraudLock method returns an error, it is
	 * returned to the caller. If the updateUserFraudLock method is successful, the
	 * method returns a success message.
	 *
	 * @param hmInput A HashMap containing the input parameters for the method. It
	 *                should include necessary information such as user ID, new
	 *                fraud information, transaction ID, transaction name, calling
	 *                system ID, and other user details to be updated.
	 * @return A HashMap containing the result of the method. It includes the
	 *         application status code and other information.
	 * @throws Exception If there is an error during the operation.
	 */
	public Map<String, Object> updateUserFraud(Map<String, Object> hmInput) {

		String sMethodName = ".updateUserFraud.";
		String stAppInfo = null;
		String stAppStatusCode = null;
		String slid_member_num = null;
		Map<String, Object> hmResult = null;

		if (hmInput == null || hmInput.isEmpty()) {
			stAppInfo = "Input Hash is NULL";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			logger.info("{}{}UUFH_01 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		String sHandle = (String) hmInput.get(CommonDefs.HANDLE);
		String sDomain = (String) hmInput.get(CommonDefs.DOMAIN);
		String sGuid = (String) hmInput.get(CommonDefs.GUID);
		String sAgentId = (String) hmInput.get(CommonDefs.AGENT_ID);
		String sInpUserLockLevel = (String) hmInput.get(CommonDefs.USER_LOCK_LEVEL);
		String stAction = null;
		Map<String, Object> hmInqProfileResp = null;
		HashMap<String, String> hmDBMemberInfo = null;
		Map<String, Object> hmDbUserFraudLock = null;
		HashMap<String, Object> hmInqProfileInp = null;
		HashMap<String, Object> hmUserFraudLock = CommonUtil.getHashMap();
		HashMap<String, Object> hmResetUserInp = null;
		HashMap<String, Object> hmUpdateAssociation = CommonUtil.getHashMap();
		HashMap<String, Object> hmAccountFraudLock = CommonUtil.getHashMap();
		HashMap<String, Object> hmFraudLockInput = CommonUtil.getHashMap();
		HashMap hmFraudLockResponse = CommonUtil.getHashMap();
		ArrayList<HashMap> alMemSvcRole = CommonUtil.getArrayList();
		ArrayList alExecutiveFraudExclusionList = CommonUtil.getArrayList();
        ArrayList<Map<String, Object>> alConsDbus = new ArrayList<>();

		try {

			logger.info("{}{} HLP000 : Input Hash : {}", sClassName, sMethodName, hmInput);

			hmInqProfileInp = prepareDataForInquireProfile(hmInput);

			logger.info("{}{} UUFH_02 : Calling to InquireProfileDBHelper.inquireProfile with HashMap =  {}",
					sClassName, sMethodName, hmInqProfileInp);
			hmInqProfileResp = inquireProfileDBHelperObj.inquireProfile(hmInqProfileInp);
			logger.info(SpiMarker.getInstance(),
					"{}{} UUFH_03 : Response Hash from InquireProfileDBHelper.inquireProfile is =  {}", sClassName,
					sMethodName, StructuredArguments.entries(hmInqProfileResp));

			if (hmInqProfileResp == null || hmInqProfileResp.isEmpty()) {
				stAppInfo = "InquireProfileDBHelper returned null/empty response";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}UUFH_04 : {} ", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			stAppStatusCode = (String) hmInqProfileResp.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				if (stAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND)
						|| stAppStatusCode.equals(CErrorDefs.ERR_USER_NOT_FOUND)) {
					stAppInfo = "User Not Found for input userId or guid";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
					logger.info("{}{}UUFH_05 : {}", sClassName, sMethodName, stAppInfo);
				}

				return hmResult;
			}

			hmDBMemberInfo = (HashMap) hmInqProfileResp.get("member");
			slid_member_num = (String) hmDBMemberInfo.get(CommonDefs.SLID_MEMBER_NUM);
			hmInput.put(CommonDefs.SLID_MEMBER_NUM, slid_member_num);
			sGuid = hmDBMemberInfo.get(CommonDefs.MEMBER_NUM);
			String sMemberNum = hmDBMemberInfo.get(CommonDefs.MEMBER_NUM);
			hmInput.put((String) CommonDefs.GUID, slid_member_num);

			if (slid_member_num == null || slid_member_num.isEmpty()) {
				stAppInfo = "associated slid does not exist";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SLID_DOES_NOT_EXIST_NUM, stAppInfo);
				logger.info("{}{}UUFH_06 : {} ", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			sHandle = hmDBMemberInfo.get(CommonDefs.MEMBER_NAME);
			sDomain = hmDBMemberInfo.get("domainName");

			if (sDomain != null && !sDomain.equals("slid.dum")) {
				sAgentId = sMemberNum;

				hmInqProfileInp = prepareDataForInquireProfile(hmInput);

				hmInqProfileResp = inquireProfileDBHelperObj.inquireProfile(hmInqProfileInp);

				if (hmInqProfileResp == null || hmInqProfileResp.isEmpty()) {

					stAppInfo = "InquireProfileDBHelper returned null/empty response";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					logger.info("{}{}UUFH_07 : {} ", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
				stAppStatusCode = (String) hmInqProfileResp.get(CErrorDefs.COMMON_APP_STATUS_CODE);

				if ((stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS))) {
					if (CErrorDefs.ERR_REC_NOT_FOUND.equals(stAppStatusCode)
							|| CErrorDefs.ERR_USER_NOT_FOUND.equals(stAppStatusCode)) {

						stAppInfo = "associated slid does not exist";
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SLID_DOES_NOT_EXIST_NUM, stAppInfo);
						logger.info("{}{}UUFH_08 : {} ", sClassName, sMethodName, stAppInfo);
						return hmResult;
					}
				}

				hmDBMemberInfo = (HashMap) hmInqProfileResp.get("member");
				sGuid = hmDBMemberInfo.get(CommonDefs.MEMBER_NUM);
				hmInput.put((String) CommonDefs.GUID, sGuid);

				sHandle = hmDBMemberInfo.get(CommonDefs.MEMBER_NAME);
				sDomain = hmDBMemberInfo.get("domainName");
			}

			hmInput.put(CommonDefs.HANDLE, sHandle);
			hmInput.put(CommonDefs.DOMAIN, sDomain);
			
			if (StringUtils.isNotBlank(sInpUserLockLevel) && sInpUserLockLevel.equalsIgnoreCase("2")
					&& (sAgentId == null || sAgentId.isEmpty())) {
				sAgentId = "dummy";
				hmInput.put(CommonDefs.AGENT_ID, sAgentId);

			}

			if (hmInqProfileResp.get("memberservicerole") != null) {
				ArrayList alaccountExclusionList = CommonUtil.getArrayList();

				alMemSvcRole = (ArrayList) hmInqProfileResp.get("memberservicerole");
				if (alMemSvcRole != null && !alMemSvcRole.isEmpty()) {
					for (HashMap<String, String> hmDBService : alMemSvcRole) {

						if (propAccountExclusionList != null && !propAccountExclusionList.isEmpty()) {
							alaccountExclusionList = CommonUtil.parseToArray(propAccountExclusionList,
									CommonDefs.VALUE_SEPARATOR_CHAR);

						} else {
							stAppInfo = "Property value is null or empty";
							hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
							logger.error("{}{}UUFH_09 : {} ", sClassName, sMethodName, stAppInfo);
							return hmResult;
						}

						String sDBSvcName = hmDBService.get(CommonDefs.SERVICE_NAME);
						if (alaccountExclusionList.contains(sDBSvcName)) {

							stAppInfo = "Access ID excluded from fraud lock";
							hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
							logger.info("{}{}UUFH_10: {} ", sClassName, sMethodName, stAppInfo);
							return hmResult;
						}
					}
				}

			}

			if (propExecutiveFraudExclusionList != null && !propExecutiveFraudExclusionList.isEmpty()) {
				alExecutiveFraudExclusionList = CommonUtil.parseToArray(propExecutiveFraudExclusionList,
						CommonDefs.VALUE_SEPARATOR_CHAR);

			} else {
				stAppInfo = "Property value is null or empty";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
				logger.error("{}{}UUFH_11 : {} ", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			if (sHandle != null && alExecutiveFraudExclusionList != null
					&& alExecutiveFraudExclusionList.contains(sHandle)) {
				stAppInfo = "DARKWEB_EXEC_EXCLUSION " + sHandle + " AAID excluded from fraud lock";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
				logger.info("{}{}UUFH_12 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			String sPreviousLockLevel = null;
			boolean isUserLockRowPresent = false;
			hmDbUserFraudLock = (HashMap) hmInqProfileResp.get(CommonDefs.USER_FRAUD_LOCK);
			if (hmDbUserFraudLock != null) {
				isUserLockRowPresent = true;
				int iPrevLockLevel;

				sPreviousLockLevel = (String) hmDbUserFraudLock.get(CommonDefs.USER_LOCK_LEVEL);
				if (sPreviousLockLevel == null) {
					iPrevLockLevel = 0;
				} else {
					iPrevLockLevel = Integer.parseInt(sPreviousLockLevel);
				}

				int iUserLockLevel = Integer.parseInt(sInpUserLockLevel);
				if (iPrevLockLevel == iUserLockLevel) {
					stAppInfo = "User already locked";
					logger.info("{}{}UUFH_13 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_FRAUD_LOCKED_NUM, stAppInfo);
					return hmResult;

				}

			}

			// set action for accountlock based on userlocklevel and dblock
			if (sInpUserLockLevel.equals("2")) {
				stAction = "LOCK";
			} else if (sInpUserLockLevel.equals("1") && sPreviousLockLevel != null && sPreviousLockLevel.equals("2")) {
				stAction = "UNLOCK";
			} else if (sInpUserLockLevel.equals("0") ) {
                if (sPreviousLockLevel != null && sPreviousLockLevel.equals("2")) {
                    stAppInfo = "User Fraud lock 2 exists";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_FRAUD_LOCKED_NUM, stAppInfo);
                    return hmResult;
                } else if (sPreviousLockLevel == null) {
                    stAppInfo = "No Action taken, there is no fraud lock found in IDGRAPH";
                    hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, stAppInfo);
                    logger.info("{}{}UUFH_14 : {}", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                }
            }
			hmUserFraudLock = prepareDataforUpdateFraudDBHelper(sGuid, sAgentId, hmInput);

			if (isUserLockRowPresent) {
                if (sInpUserLockLevel.equals("0")) {
                    hmResult = fraudLockDBHelperObj.deleteUserFraudLock(hmUserFraudLock);

                    // Defensive check: ensure DB helper returned expected context before we build our final response
                    String dbAppInfo = hmResult == null ? null : (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
                    if (StringUtils.isNotBlank(dbAppInfo) && dbAppInfo.contains("No of rows deleted")) {
                        stAppInfo = "Successfully deleted user fraud lock";
                        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
                    }

                } else {
                    hmResult = fraudLockDBHelperObj.updateUserFraudLock(hmUserFraudLock);
                }
			} else {
				hmResult = fraudLockDBHelperObj.addUserFraudLock(hmUserFraudLock);
			}

			stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (stAppStatusCode != null && !(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				stAppInfo = (String) hmResult.get(CErrorDefs.COMMON_APP_INFO);
				logger.info("{}{}UUFH_15 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			} else {
				isTransactionRollbackOnError = true;
			}

			if (hmInqProfileResp.get("memberservicerole") != null) {
				alMemSvcRole = (ArrayList) hmInqProfileResp.get("memberservicerole");
				hmInput.put("dbServices", alMemSvcRole);
				if (alMemSvcRole != null && !alMemSvcRole.isEmpty() && stAction != null) {
					for (HashMap<String, String> hmDBService : alMemSvcRole) {
						String sDBSvcName = hmDBService.get("serviceName");
						hmInput.put(CommonDefs.ACTION, stAction);
						hmFraudLockInput = new HashMap();
						hmFraudLockInput.put(MPSDefs.DB_SOR_INVARIANT_ID,
								(String) hmDBService.get(CommonDefs.SOR_INVARIANT_ID));
						hmFraudLockInput.put(MPSDefs.DB_SOR_ID, (String) hmDBService.get(CommonDefs.SOR_ID));
						hmFraudLockInput.put(MPSDefs.DB_SOR_NAME, (String) hmDBService.get(CommonDefs.SOR_NAME));
						logger.info("{}{}PALH_07 : Calling fraudLockDBHelper.queryAccountFraudLock with input:{}",
								sClassName, sMethodName, hmFraudLockInput);
						hmFraudLockResponse = fraudLockDBHelperObj.queryAccountFraudLock(hmFraudLockInput);
						logger.info("{}{}PALH_08 :Response from fraudLockDBHelper.queryAccountFraudLock : {}",
								sClassName, sMethodName, hmFraudLockResponse);
						// prepare inputt for Account fraudlock and call accountfraudlock
						hmAccountFraudLock = prepareDataforAccountLock(sGuid, hmDBService, sDBSvcName, hmInput);
						hmResult = accountLockHelper.processAccountLock(hmAccountFraudLock, hmFraudLockResponse);
						stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
						if (stAppStatusCode != null && !stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
							stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
							logger.info("{}{}UUFH_16_0 : {}", sClassName, sMethodName, stAppInfo);
							return hmResult;
						} else {

							isTransactionRollbackOnError = true;
						}
						if(stAppStatusCode != null && stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS) && null!= hmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT) ) {
							alConsDbus.addAll((ArrayList<Map<String, Object>>) hmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT));
							
						}

						if (sDBSvcName.equals(CommonDefs.MOBILITY_SERVICE)) {

							hmUpdateAssociation = prepareDataforUpdateAssociationDBHelper(sGuid, hmDBService,
									sDBSvcName, hmInput);

							logger.debug(
									"{}{}UUFH_16: Calling to updateAssociationDBHelperObj.updateAssociation with input : {}",
									sClassName, sMethodName, hmUpdateAssociation);
							// reset passcode for wirelineuser/ mobility
							hmResult = updateAssociationDBHelperObj.updateAssociation(hmUpdateAssociation);
							logger.debug(
									"{}{}UUFH_17: Response Hash from updateAssociationDBHelperObj.updateAssociation is = {}",
									sClassName, sMethodName, hmResult);

							stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

							if (stAppStatusCode != null && !stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
								stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
								logger.info("{}{}UUFH_18 : {}", sClassName, sMethodName, stAppInfo);
								return hmResult;
							} else {

								isTransactionRollbackOnError = true;
							}

						}

					}
				}
			}
            if (!sInpUserLockLevel.equals("0") ) {
                hmResetUserInp = prepareDataforResetUserPassword(hmInput);

                logger.info("{}{}UUFH_19 : Calling ResetUserPasswordHelper.resetUserPassword with input : {}", sClassName,
                        sMethodName, hmResetUserInp);

                hmResult = resetUserPasswordHelperObj.resetUserPassword(hmResetUserInp);

                logger.info(SpiMarker.getInstance(),
                        "{}{}UUFH_20 : Response from ResetUserPasswordHelper.resetUserPassword : {}", sClassName,
                        sMethodName, hmResult);
                if (hmResult == null || hmResult.isEmpty()) {
                    stAppInfo = "Null Response returned from ResetUserPasswordHelper.resetUserPassword()";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                    logger.info("{}{}UUFH_21 : {}", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                }

                stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

                if (stAppStatusCode != null && !stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
                    stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
                    hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                    logger.info("{}{}UUFH_22 : {}", StringUtils.normalizeSpace(sClassName), StringUtils.normalizeSpace(sMethodName), StringUtils.normalizeSpace(stAppInfo));
                    return hmResult;
                }

                logger.info("{}{}UUFH_23 : Calling UpdateUserFraudQueueHelper with input : {}", sClassName, sMethodName,
                        hmInput);
            }
			hmResult = updateUserFraudQueueHelperObj.sendMessageToMQ(hmInput, hmDBMemberInfo, sPreviousLockLevel,
					alConsDbus);
			logger.info("{}{}UUFH_24 : Response from UpdateUserFraudQueueHelper : {}", sClassName, sMethodName,
					hmResult);

			if (hmResult == null || hmResult.isEmpty()) {
				stAppInfo = "Null Response returned from UpdateUserFraudQueueHelper.sendMessageToMQ()";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}UUFH_25 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

			if (stAppStatusCode != null && !stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
				stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
				hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
				logger.info("{}{}UUFH_26 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
		} finally {
			String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);

			if (isTransactionRollbackOnError && sAppCategoryCode != null
					&& !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
				hmResult.put("isTransactionRollback", "Y");
			}
			logger.info(SpiMarker.getInstance(), "{}{}HLP999 : response from UpdateUserFraudHelper {}", sClassName,
					sMethodName, StructuredArguments.entries(hmResult));

		}

		return hmResult;
	}

	private HashMap<String, Object> prepareDataforAccountLock(String sGuid, HashMap<String, String> hmDBService,
			String sDBSvcName, Map<String, Object> hmInput) {
		HashMap<String, Object> hmUpdateAccountFraudLock = CommonUtil.getHashMap();
		String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
		String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
		String transacionID = (String) hmInput.get("dbusTransactionId");
		String agentId = (String) hmInput.get(CommonDefs.AGENT_ID);
		String action = (String) hmInput.get(CommonDefs.ACTION);
		String sUserLockedReasonCode = (String) hmInput.get(CommonDefs.USER_LOCK_REASON_CODE);
		hmUpdateAccountFraudLock.put(CommonDefs.SOR_ID, (String) hmDBService.get(CommonDefs.SOR_ID));
		hmUpdateAccountFraudLock.put(CommonDefs.ACCOUNT_SOR, (String) hmDBService.get(CommonDefs.KEY_SOR_NAME));
		hmUpdateAccountFraudLock.put(CommonDefs.SERVICE_ID, (String) hmDBService.get(CommonDefs.SERVICE_ID));
		hmUpdateAccountFraudLock.put(CommonDefs.SOR_INVARIANT_ID,
				(String) hmDBService.get(CommonDefs.SOR_INVARIANT_ID));
		hmUpdateAccountFraudLock.put(CommonDefs.ACCOUNT_LOCKED_REASON_CODE, sUserLockedReasonCode);
		hmUpdateAccountFraudLock.put(CommonDefs.AGENT_ID, agentId);
		hmUpdateAccountFraudLock.put(CommonDefs.ACTION, action);
		hmUpdateAccountFraudLock.put(CommonDefs.TRANSACTION_ID, transacionID);
		hmUpdateAccountFraudLock.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
		hmUpdateAccountFraudLock.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
		hmUpdateAccountFraudLock.put(CommonDefs.SERVICE_NAME, sDBSvcName);
		hmUpdateAccountFraudLock.put(CommonDefs.MEMBER_NUM, sGuid);
		hmUpdateAccountFraudLock.put(MPSDefs.DB_ROLE_NAME, (String) hmDBService.get("roleName"));
		hmUpdateAccountFraudLock.put(MPSDefs.DB_ROLE_STATUS_NAME, (String) hmDBService.get("roleStatusName"));
		hmUpdateAccountFraudLock.put(MPSDefs.DB_ROLE_ID, (String) hmDBService.get("roleId"));
		hmUpdateAccountFraudLock.put(CommonDefs.CALLDBUS, "N");
		return hmUpdateAccountFraudLock;
	}

	private HashMap<String, Object> prepareDataforUpdateAssociationDBHelper(String sGuid,
			HashMap<String, String> hmDBService, String sDBSvcName, Map<String, Object> hmInput) {
		HashMap<String, Object> hmService = CommonUtil.getHashMap();
		HashMap<String, Object> hmUpdateAssociation = CommonUtil.getHashMap();
		String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
		String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
		hmService.put(CommonDefs.SERVICE_NAME, sDBSvcName);
		hmService.put(MPSDefs.DB_SERVICE_ID, (String) hmDBService.get(CommonDefs.SERVICE_ID));
		hmService.put(MPSDefs.DB_SOR_INVARIANT_ID, (String) hmDBService.get(CommonDefs.SOR_INVARIANT_ID));
		hmService.put(MPSDefs.DB_SOR_ID, (String) hmDBService.get(CommonDefs.SOR_ID));
		hmService.put(CommonDefs.RESETPASSCODE, CommonDefs.IND_Y);
		hmUpdateAssociation.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
		hmUpdateAssociation.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
		hmUpdateAssociation.put(MPSDefs.DB_MEMBER_NUM, sGuid);
		hmUpdateAssociation.put(CommonDefs.SERVICE, hmService);
		return hmUpdateAssociation;
	}

	private HashMap<String, Object> prepareDataforUpdateFraudDBHelper(String sGuid, String sAgentId,
			Map<String, Object> hmInput) {
		HashMap<String, Object> hmUserFraudLock = CommonUtil.getHashMap();
		String sInpUserLockLevel = (String) hmInput.get(CommonDefs.USER_LOCK_LEVEL);
		String sUserLockedReasonCode = (String) hmInput.get(CommonDefs.USER_LOCK_REASON_CODE);
		String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
		String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
		hmUserFraudLock.put(MPSDefs.DB_USER_LOCK_LEVEL, sInpUserLockLevel);
		hmUserFraudLock.put(MPSDefs.DB_USER_LOCK_REASON, sUserLockedReasonCode);
		hmUserFraudLock.put(MPSDefs.DB_FRAUD_AGENT, sAgentId);
		hmUserFraudLock.put(MPSDefs.DB_MEMBER_NUM, sGuid);
		hmUserFraudLock.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
		hmUserFraudLock.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
		return hmUserFraudLock;
	}

	private HashMap<String, Object> prepareDataforResetUserPassword(Map<String, Object> hmInput) {
		String sHandle = (String) hmInput.get(CommonDefs.HANDLE);
		String sDomain = (String) hmInput.get(CommonDefs.DOMAIN);
		String sAgentId = (String) hmInput.get(CommonDefs.AGENT_ID);
		String sInpUserLockLevel = (String) hmInput.get(CommonDefs.USER_LOCK_LEVEL);
        String idpTraceId = (String) hmInput.get(ProfileOrchestrationConstants.IDPTRACEID);
		HashMap<String, Object> hmResetUserInp;
		hmResetUserInp = new HashMap();
		hmResetUserInp.put(CommonDefs.ORIG_TRANSACTION_NAME, "UpdateUserFraud");
		hmResetUserInp.put(CommonDefs.TRANSACTION_NAME, "ResetUserPassword");
		hmResetUserInp.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		// hmResetUserInp.put(CommonDefs.MS_NAME, "MOUP");
		hmResetUserInp.put(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID, (String) hmInput.get("dbusTransactionId"));
		hmResetUserInp.put(CommonDefs.HANDLE, sHandle);
		hmResetUserInp.put(CommonDefs.DOMAIN, sDomain);
		hmResetUserInp.put(CommonDefs.IS_EXTERNAL_CALL, CommonDefs.IND_N);
		hmResetUserInp.put(CommonDefs.AGENT_ID, sAgentId);
		hmResetUserInp.put(CommonDefs.SUPPRESS_NOTIFICATION, CommonDefs.IND_Y);
		hmResetUserInp.put(CommonDefs.USER_LOCK_LEVEL, sInpUserLockLevel);
        hmResetUserInp.put(ProfileOrchestrationConstants.IDPTRACEID, idpTraceId);
		return hmResetUserInp;
	}

	private HashMap<String, Object> prepareDataForInquireProfile(Map<String, Object> hmInput) {
		HashMap<String, Object> hmInqProfileInp = CommonUtil.getHashMap();
		hmInqProfileInp.put(CommonDefs.TRANSACTION_NAME, "InquireProfile");
		hmInqProfileInp.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		hmInqProfileInp.put(CommonDefs.LEVEL, "MSR");
		hmInqProfileInp.put(CommonDefs.IS_EXTERNAL_CALL, "N");
		String slid_member_num = (String) hmInput.get(CommonDefs.SLID_MEMBER_NUM);

		if (hmInput.get(CommonDefs.GUID) != null) {
			hmInqProfileInp.put(CommonDefs.GUID, hmInput.get(CommonDefs.GUID));
		} else {
			hmInqProfileInp.put(CommonDefs.HANDLE, hmInput.get(CommonDefs.HANDLE));
			hmInqProfileInp.put(CommonDefs.DOMAIN, hmInput.get(CommonDefs.DOMAIN));
		}

		hmInqProfileInp.put(CommonDefs.RETURN_USER_FRAUD_LOCK, CommonDefs.IND_Y);
		return hmInqProfileInp;
	}
}

