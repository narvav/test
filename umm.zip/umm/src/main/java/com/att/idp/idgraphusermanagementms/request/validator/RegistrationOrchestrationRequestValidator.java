package com.att.idp.idgraphusermanagementms.request.validator;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.ws.rs.core.HttpHeaders;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphusermanagementms.resource.request.AssociationItem;
import com.att.idp.idgraphusermanagementms.resource.request.RegistrationOrchestrationRequest;
import com.att.idp.idgraphusermanagementms.resource.response.RegistrationOrchestrationResponse;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.mpsys.common.utils.CommonUtil;

/**
 * This class is responsible for validating the RegistrationOrchestrationRequest.
 * It checks for the presence and validity of required fields in the request,
 * and returns a RegistrationOrchestrationResponse on validation failure, or null on success.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class RegistrationOrchestrationRequestValidator {

    private static final Logger logger = LoggerFactory.getLogger(RegistrationOrchestrationRequestValidator.class);
    private static final String sClassName = "RegistrationOrchestrationRequestValidator";

    private static final List<String> VALID_SERVICE_NAMES = Arrays.asList(
            ProfileOrchestrationConstants.SERVICE_NAME_MOBILITY,
            ProfileOrchestrationConstants.SERVICE_NAME_TITAN,
            ProfileOrchestrationConstants.SERVICE_NAME_ECOMM,
            ProfileOrchestrationConstants.SERVICE_NAME_INDIVIDUAL
    );

    @Value("${RegistrationOrchestration_MaxAssociationListSize:20}")
    private int maxAssociationListSize;

    /**
     * Validates the registrationOrchestration request headers and body.
     * Returns a RegistrationOrchestrationResponse with error details if validation fails, or null if validation passes.
     *
     * @param requestHeader The HttpHeaders containing the request headers.
     * @param request The RegistrationOrchestrationRequest containing the request body.
     * @return RegistrationOrchestrationResponse on failure, null on success.
     */
    public RegistrationOrchestrationResponse validate(HttpHeaders requestHeader,
                                                      RegistrationOrchestrationRequest request) {
        String sMethodName = ".validate.";
        String stAppInfo;
        String stIdpTraceId = null;

        if (request == null) {
            stAppInfo = "Input Request is NULL / Empty.";
            logger.info("{}{}RORV_100 :: {}", sClassName, sMethodName, stAppInfo);
            return buildErrorResponse("MS_MPSYS_BE_602", "ERR_SYS_APPL: " + stAppInfo, stIdpTraceId);
        }

        // V1: Extract and validate idp-trace-id from raw header first
        String rawTraceId = requestHeader.getHeaderString("idp-trace-id");
        if (rawTraceId == null || rawTraceId.trim().isEmpty()) {
            stAppInfo = "Missing or invalid idp-trace-id in request header";
            logger.info("{}{}RORV_101 :: {}", sClassName, sMethodName, stAppInfo);
            stIdpTraceId = CommonUtil.getTraceId(requestHeader);
            return buildErrorResponse("MS_MPSYS_BE_100", "ERR_INVALID_DATA: " + stAppInfo, stIdpTraceId);
        }
        stIdpTraceId = CommonUtil.getTraceId(requestHeader);
        if (stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
            stAppInfo = "Missing or invalid idp-trace-id in request header";
            logger.info("{}{}RORV_101 :: {}", sClassName, sMethodName, stAppInfo);
            return buildErrorResponse("MS_MPSYS_BE_100", "ERR_INVALID_DATA: " + stAppInfo, stIdpTraceId);
        }
        request.setIdpTraceId(stIdpTraceId);

        // V1: Validate X-ATT-ClientId must be IDMREG
        String clientId = requestHeader.getHeaderString("X-ATT-ClientId");
        if (clientId == null || clientId.trim().isEmpty()) {
            stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
            logger.info("{}{}RORV_102 :: {}", sClassName, sMethodName, stAppInfo);
            return buildErrorResponse("MS_MPSYS_BE_100", "ERR_INVALID_DATA: " + stAppInfo, stIdpTraceId);
        }
        clientId = clientId.trim().toUpperCase();
        request.setCallingSystemId(clientId);

        if (!(ProfileOrchestrationConstants.VALID_CLIENT_ID_IDMREG.equals(clientId) ||
                ProfileOrchestrationConstants.VALID_CLIENT_ID_IDP.equals(clientId))) {
            String sanitizedClientIdForLog = clientId.replace('\r', ' ').replace('\n', ' ');
            stAppInfo = "X-ATT-ClientId must be IDMREG/IDP. Received: " + sanitizedClientIdForLog;
            logger.info("{}{}RORV_103 :: {}", sClassName, sMethodName, stAppInfo);
            return buildErrorResponse("MS_MPSYS_BE_100", "ERR_INVALID_DATA: " + stAppInfo, stIdpTraceId);
        }

        // Check for unknown attributes
        Map<String, Object> allUnknownAttributes = new HashMap<>(request.unknownAttributes);
        if (!allUnknownAttributes.isEmpty()) {
            stAppInfo = "Invalid Attributes passed in RegistrationOrchestrationRequest : " + allUnknownAttributes;
            logger.info("{}{}RORV_104 :: {}", sClassName, sMethodName, stAppInfo);
            return buildErrorResponse("MS_MPSYS_BE_100", "ERR_INVALID_DATA: " + stAppInfo, stIdpTraceId);
        }

        // V2: Validate targetAccessId
        String targetAccessId = request.getTargetAccessId();
        if (targetAccessId == null || targetAccessId.trim().isEmpty()) {
            stAppInfo = "targetAccessId is missing or empty";
            logger.info("{}{}RORV_105 :: {}", sClassName, sMethodName, stAppInfo);
            return buildErrorResponse("MS_MPSYS_BE_100", "ERR_INVALID_DATA: " + stAppInfo, stIdpTraceId);
        }
        if (targetAccessId.length() > 127) {
            stAppInfo = "targetAccessId length exceeds maximum of 127";
            logger.info("{}{}RORV_106 :: {}", sClassName, sMethodName, stAppInfo);
            return buildErrorResponse("MS_MPSYS_BE_100", "ERR_INVALID_DATA: " + stAppInfo, stIdpTraceId);
        }

        // V3: Validate associationList
        List<AssociationItem> associationList = request.getAssociationList();
        if (associationList == null || associationList.isEmpty()) {
            stAppInfo = "associationList is missing or empty";
            logger.info("{}{}RORV_107 :: {}", sClassName, sMethodName, stAppInfo);
            return buildErrorResponse("MS_MPSYS_BE_100", "ERR_INVALID_DATA: " + stAppInfo, stIdpTraceId);
        }

        // G7: Max association list size check
        if (associationList.size() > maxAssociationListSize) {
            stAppInfo = "associationList size exceeds maximum of " + maxAssociationListSize;
            logger.info("{}{}RORV_108 :: {}", sClassName, sMethodName, stAppInfo);
            return buildErrorResponse("MS_MPSYS_BE_100", "ERR_INVALID_DATA: " + stAppInfo, stIdpTraceId);
        }

        // V4, V5, V6: Validate each item in associationList
        for (int i = 0; i < associationList.size(); i++) {
            AssociationItem item = associationList.get(i);

            if (item.getServiceName() == null || item.getServiceName().trim().isEmpty()) {
                stAppInfo = "serviceName is missing in associationList item at index " + i;
                logger.info("{}{}RORV_109 :: {}", sClassName, sMethodName, stAppInfo);
                return buildErrorResponse("MS_MPSYS_BE_100", "ERR_INVALID_DATA: " + stAppInfo, stIdpTraceId);
            }

            if (!VALID_SERVICE_NAMES.contains(item.getServiceName().trim().toUpperCase())) {
                stAppInfo = "Invalid serviceName '" + StringUtils.normalizeSpace(item.getServiceName())
                        + "' in associationList item at index " + i
                        + ". Valid values: MOBILITY, TITAN, ECOMM, INDIVIDUAL";
                logger.info("{}{}RORV_110 :: {}", sClassName, sMethodName, stAppInfo);
                return buildErrorResponse("MS_MPSYS_BE_100", "ERR_INVALID_DATA: " + stAppInfo, stIdpTraceId);
            }

            if (item.getSorInvariantId() == null || item.getSorInvariantId().trim().isEmpty()) {
                stAppInfo = "sorInvariantId is missing in associationList item at index " + i;
                logger.info("{}{}RORV_111 :: {}", sClassName, sMethodName, stAppInfo);
                return buildErrorResponse("MS_MPSYS_BE_100", "ERR_INVALID_DATA: " + stAppInfo, stIdpTraceId);
            }

            if (item.getSorInvariantId().length() > 255) {
                stAppInfo = "sorInvariantId length exceeds maximum of 255 in associationList item at index " + i;
                logger.info("{}{}RORV_112 :: {}", sClassName, sMethodName, stAppInfo);
                return buildErrorResponse("MS_MPSYS_BE_100", "ERR_INVALID_DATA: " + stAppInfo, stIdpTraceId);
            }

            if (item.getSourceAccessId() != null && item.getSourceAccessId().length() > 127) {
                stAppInfo = "sourceAccessId length exceeds maximum of 127 in associationList item at index " + i;
                logger.info("{}{}RORV_113 :: {}", sClassName, sMethodName, stAppInfo);
                return buildErrorResponse("MS_MPSYS_BE_100", "ERR_INVALID_DATA: " + stAppInfo, stIdpTraceId);
            }

            // Normalize serviceName to uppercase
            item.setServiceName(item.getServiceName().trim().toUpperCase());
        }

        stAppInfo = "Input Validation Successful";
        logger.info("{}{}RORV_199 : {}", sClassName, sMethodName, stAppInfo);
        return null;
    }

    /**
     * Builds an error response for the registrationOrchestration API.
     *
     * @param errorId The error ID (e.g., MS_MPSYS_BE_100).
     * @param message The error message.
     * @param idpTraceId The trace ID.
     * @return RegistrationOrchestrationResponse The error response.
     */
    private RegistrationOrchestrationResponse buildErrorResponse(String errorId, String message, String idpTraceId) {
        return RegistrationOrchestrationResponse.builder()
                .idpTraceId(idpTraceId)
                .status(ProfileOrchestrationConstants.STATUS_FAILED)
                .errorId(errorId)
                .message(message)
                .build();
    }
}
