package com.att.idp.idgraphusermanagementms.resource.response;

import lombok.Data;

/**
 * This class represents a user's security information in the system.
 * It contains fields for recentFraudPwDate, lastModifiedSec, lastModifiedPw, securityQuestionId2, securityAnswer1, securityQuestionId1, securityQuestion2, memberNum, securityQuestion1, securityAnswer2, encPassword, md5Password, sha1Password, des3Password, and sshaPassword.
 * Each field has specific constraints such as not null and size limits.
 *
 * The class uses Lombok's @Data annotation to generate getter and setter methods for all fields.
 *
 */
@Data
public class IPUserSecurityInfo {

	private String recentFraudPwDate;
	private String lastModifiedSec;
	private String lastModifiedPw;
	private String securityQuestionId2;
	private String securityAnswer1;
	private String securityQuestionId1;
	private String securityQuestion2;
	private String memberNum;
	private String securityQuestion1;
	private String securityAnswer2;
	private String encPassword;
	private String md5Password;
	private String sha1Password;
	private String des3Password;
	private String sshaPassword;
}