package com.att.idp.idgraphusermanagementms.resource.request;

import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * This class represents a request to merge user access IDs in the system.
 * It contains fields for various details such as transactionName, callingSystemId, fromUserName, toUserName, agentId, isExternalCall, idpTraceId, and a map for unknownAttributes.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Lombok's @Getter/@Setter/@Builder to generate accessors and a builder.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 *
 */
@Schema(name = "mergeUserAccessIdRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MergeUserAccessIdRequest {

    /**
     * The name of the transaction. This field is final and cannot be changed.
     */
    @Builder.Default
    private final String transactionName = "MergeUserAccessId";

    /**
     * The ID of the system making the call.
     */
    private String callingSystemId;

    /**
     * The username of the user from which the access ID is being merged.
     * This field is required and its size must be between 1 and 127.
     */
    @NotNull(message="fromUserName is required field in input request.|MergeUserAccessId")
    @Size(min=1, max=127,message="fromUserName length is invalid|MergeUserAccessId")
    protected String fromUserName;

    /**
     * The username of the user to which the access ID is being merged.
     * This field is required and its size must be between 1 and 127.
     */
    @NotNull(message="toUserName is required field in input request.|MergeUserAccessId")
    @Size(min=1, max=127,message="toUserName length is invalid|MergeUserAccessId")
    protected String toUserName;

    /**
     * The ID of the agent performing the operation.
     * This field is optional and its size must be between 1 and 20 if provided.
     */
    @Size(min=1, max=20,message="agentId length is invalid|MergeUserAccessId")
    protected String agentId;

    /**
     * Indicates whether the call is external.
     * This field is optional and its size must be between 1 and 20 if provided.
     */
    @Size(min = 1, max = 20, message =  "isExternalCall length is invalid|MergeUserAccessId")
    private String isExternalCall;

    /**
     * The trace ID for the Identity Platform (IDP).
     */
    @Schema(name = "idpTraceId")
    private String idpTraceId;

    /**
     * A map to store any additional attributes that are not defined in the class.
     * This field is used for JSON serialization and deserialization.
     */
    @JsonAnySetter
    @JsonAnyGetter
    @Builder.Default
    public Map<String,Object> unknownAttributes = new HashMap<>();
}