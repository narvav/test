package com.att.idp.idgraphusermanagementms.db.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * This is the DomainResponse class which implements Serializable interface.
 * It represents a response for a domain with properties like domainId, domainName, and domainDesc.
 * Each property has its respective getter and setter methods.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({

})
public class DomainResponse implements Serializable{

	private static final long serialVersionUID = 969653024664005427L;

	private Long domainId;
	private String domainName;
	private String domainDesc;
}