package com.att.idp.idgraphusermanagementms.service;

import com.att.idp.idgraphusermanagementms.resource.request.UpdatePrepaidUserPasswordRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdatePrepaidUserPasswordResponse;

import jakarta.ws.rs.core.MultivaluedMap;

/**
 * Service interface for updating prepaid user passwords.
 */
public interface UpdatePrepaidUserPasswordService {

	/**
	 * Updates the password for a prepaid user.
	 *
	 * @param updatePrepaidUserPasswordRequest the request containing the details needed to update the password
	 * @return the response containing the result of the password update operation
	 */
	UpdatePrepaidUserPasswordResponse updatePrepaidUserPassword(UpdatePrepaidUserPasswordRequest updatePrepaidUserPasswordRequest, MultivaluedMap<String, String> requestHeader);
}