package com.att.idp.idgraphusermanagementms.resource.impl;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_IB;
import static com.att.idp.cd.observability.metrics.utils.Constants.URI;
import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.POST;
import static com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants.IDGRAPH_USERMANAGEMENTMS_IB;
import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.request.validator.RemoveEmailAliasRequestValidator;
import com.att.idp.idgraphusermanagementms.resource.EmailAliasResource;
import com.att.idp.idgraphusermanagementms.resource.request.RemoveEmailAliasRequest;
import com.att.idp.idgraphusermanagementms.resource.response.CommonResponse;
import com.att.idp.idgraphusermanagementms.service.RemoveEmailAliasService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.MPSDefs;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.stereotype.Controller;

import java.sql.SQLException;
import java.util.Map;

@Controller
@OpenAPIDefinition(
		info = @Info(title="User Management",
				description="IDGraphUserManagementMs provides services that are used to perform identity specific " +
						"operations like creating new accessId, registering a currently.com memberId, updating " +
						"profile attributes of the existing accessId, and fraud locking access Id. This information " +
						"gets stored in IdentityGraph database and gets provisioned/replicated to multiple systems " +
						"e.g. HALOC, Yahoo, CG, CCR, G2 etc.\n\n\n\n.", version="0.0.1"),
		servers = {
				@Server(url="https://apporigin-dev2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/"),
				@Server(url="https://apporigin-tst2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/")
		})
public class EmailAliasResourceImpl implements EmailAliasResource {
	
	private static final Logger logger = LoggerFactory.getLogger(EmailAliasResourceImpl.class);


	@Autowired
	private RemoveEmailAliasRequestValidator removeEmailAliasRequestValidator;
	@Autowired
	private RemoveEmailAliasService removeEmailAliasService;

	/**
	 * Removes an email alias for a user.
	 *
	 * @param removeEmailAliasRequest the request containing details for removing the email alias
	 * @param httpHeader the HTTP headers of the request
	 * @return a JAX-RS Response containing the result of the operation
	 * @throws MPSException if an error occurs during the process
	 */
	@TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
			description = "remove email alias",
			tags = {URI, "/msapi/idgraphusermanagementms/v1/emailalias", METHOD, POST},
			histogram = true)
	@Override
	public Response removeEmailAlias(RemoveEmailAliasRequest removeEmailAliasRequest, HttpHeaders httpHeader) throws MPSException {
		long startTm = System.currentTimeMillis();
		Map<String, Object> hmResponse = null;
		CommonResponse removeEmailAliasResponse = null;
		Response responseObj = null;
		try {
			if (removeEmailAliasRequest == null) {
				String stAppInfo = "Input request is null";
				hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("WEB_ERR : RemoveEmailAlias Input request is null");
				removeEmailAliasResponse = CommonUtilHelper.generateCommonResponse(hmResponse);
				return  CommonUtilHelper.buildMSResponse(removeEmailAliasResponse);
			}
			MultivaluedMap<String, String> requestHeader = httpHeader.getRequestHeaders();

			String stHeaders = CommonUtilHelper.objectToString(httpHeader);
			String sanitizedHeaders = CommonUtilHelper.sanitizeForLog(stHeaders);
			logger.info(SpiMarker.getInstance(),"WEB_01 : RemoveEmailAlias Input : {} | RemoveEmailAlias Request Header  : {}",
					StringUtils.normalizeSpace(removeEmailAliasRequest.toString()), sanitizedHeaders);

			removeEmailAliasResponse = removeEmailAliasRequestValidator.removeEmailAliasReqValidator(httpHeader,
					removeEmailAliasRequest);
			logger.info("WEB000 : RemoveEmailAlias Input : {}", CommonUtilHelper.sanitizeForLog(String.valueOf(removeEmailAliasRequest)));

			if (removeEmailAliasResponse == null) {
				// call the service class
				removeEmailAliasResponse = removeEmailAliasService.removeEmailAlias(removeEmailAliasRequest, requestHeader);

				logger.info("WEB_02 : RemoveEmailAlias Service Response : {}",
						removeEmailAliasResponse);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: RemoveEmailAlias{}", e.getMessage());
				throw e;
			} else if (NestedExceptionUtils.getRootCause(e) instanceof SQLException) {
				hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());

			} else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			}

            if (removeEmailAliasRequest != null) {
                hmResponse.put("idp-trace-id", removeEmailAliasRequest.getIdpTraceId());
            }
            removeEmailAliasResponse = CommonUtilHelper.generateCommonResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(removeEmailAliasResponse);
		String sTimeTaken = CommonUtilHelper.getElapsedTimeInSecs(startTm) + " seconds";

		logger.info(SpiMarker.getInstance(), "WEB999 : Total time taken : {} RemoveEmailAlias Response : {}",
				sTimeTaken, removeEmailAliasResponse);
		return responseObj;
	}
}
