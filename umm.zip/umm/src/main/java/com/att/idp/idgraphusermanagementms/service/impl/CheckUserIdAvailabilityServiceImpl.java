package com.att.idp.idgraphusermanagementms.service.impl;

import java.util.Map;

import jakarta.ws.rs.core.MultivaluedMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.idp.idgraphusermanagementms.helper.CheckUserIdAvailabilityHelper;
import com.att.idp.idgraphusermanagementms.resource.request.CheckUserIdAvailabilityRequest;
import com.att.idp.idgraphusermanagementms.resource.response.CheckUserIdAvailabilityResponse;
import com.att.idp.idgraphusermanagementms.service.CheckUserIdAvailabilityService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This class implements the CheckUserIdAvailabilityService interface and provides the implementation for checking the availability of a user ID in the system.
 * It is annotated with @Service to indicate that it's a Spring Bean.
 *
 * It contains a method checkUserIdAvailability which takes a CheckUserIdAvailabilityRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return a CheckUserIdAvailabilityResponse object.
 *
 * The CheckUserIdAvailabilityRequest object encapsulates the details of the user ID availability check operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
@Service
public class CheckUserIdAvailabilityServiceImpl implements CheckUserIdAvailabilityService{
	
	public static final Logger logger = LoggerFactory.getLogger(CheckUserIdAvailabilityServiceImpl.class);
	
	private static String sClassName = "CheckUserIdAvailabilityServiceImpl";
	
	@Autowired
	private CheckUserIdAvailabilityHelper oCheckUserIdAvailability;

	@Override
	public CheckUserIdAvailabilityResponse checkUserIdAvailability(CheckUserIdAvailabilityRequest checkUserRequest, MultivaluedMap<String, String> requestHeader) {
		
		Map<String,Object> hmCheckUserInput = null;
		Map<String,Object> hmResponse = null;
		String sMethodName = ".checkUserIdAvailabilityResponse.";

		hmCheckUserInput = CommonUtilHelper.objectToMap(checkUserRequest);
		
		logger.info("{}{}CUIAS_01 : Calling checkUserIdAvailabilityResponse with Input : {}", sClassName, sMethodName, hmCheckUserInput);

		//Calling  checkUserIdAvailability helper
		hmResponse = oCheckUserIdAvailability.checkUserIdAvailability(hmCheckUserInput);
		
		logger.info("{}{}CUIAS_02 : Response from checkUserIdAvailabilityResponse Helper : {}", sClassName, sMethodName, hmResponse);
		
		if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
			hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from checkUserIdAvailability helper");
			logger.info("{}{}CUIAS_03 : Null response from CheckUserIdAvailabilityHelper.checkUserIdAvailability", sClassName, sMethodName);
		} else {
			String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (stAppStatusCode == null) {
				hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from checkUserIdAvailability helper");
				logger.info("{}{}CUIAS_04 : Null response from CheckUserIdAvailabilityHelper.checkUserIdAvailability", sClassName, sMethodName);
			}
		}

		hmResponse.put(CommonDefs.TRANSACTION_ID, hmCheckUserInput.get(CommonDefs.TRANSACTION_ID));
		hmResponse.put("idp-trace-id", checkUserRequest.getIdpTraceId());
		CheckUserIdAvailabilityResponse checkUserResponse = CommonUtilHelper.generateCheckUserResponse(hmResponse);

		logger.info("{}{}CUIAS_05 : Response from CheckUserIdAvailabilityServiceImpl.checkUserIdAvailability : {}", sClassName, sMethodName,
				checkUserResponse);
		return checkUserResponse;
	}


}
