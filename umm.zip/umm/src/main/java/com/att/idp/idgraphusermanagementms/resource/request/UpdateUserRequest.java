package com.att.idp.idgraphusermanagementms.resource.request;

import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.Size;

import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.mpsys.common.utils.CommonDefs;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;


/**
 * This class represents a request to update a user in the system.
 * It contains fields for callingSystemId, transactionName, handle (userId), domain, online1SecurityQuestion, online1SecurityAnswer, online2SecurityQuestion, online2SecurityAnswer, contactEmail, firstName, lastName, browserLanguage, agentId, isExternalCall, accessIdRTValidFlag, contactEmailRTValidFlag, guid, activatedInd, isVerified, mainCTNOptOut, cbrOptOut, contactEmailStatus, zipCode, zipCode4, idpTraceId, and a map for unknownAttributes.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 *
 */



@Schema(name = "updateUserRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class UpdateUserRequest extends BaseUserRequest  {

	private String callingSystemId;

	private final String transactionName = ProfileOrchestrationConstants.UPDATE_USER_TRANSACTION_NAME;

	@Schema(name = "userId")
	@Size(min=1, max=127,message="userId length is invalid|UpdateUser")
	@JsonProperty("userId")
	private String handle;

	@Schema(name = "domain")
	@Size(min=1, max=30,message="domain length is invalid|UpdateUser")
	private String domain;

	@Schema(name = "browserLanguage")
	@Size(min=2, max=2,message="browserLanguage length is invalid|UpdateUser")
	private String browserLanguage;

	@Schema(name = "agentId")
	@Size(min=1, max=20,message="agentId length is invalid|UpdateUser")
	private String agentId;

	@Schema(name = "isExternalCall")
	protected String isExternalCall;

	@Schema(name = "accessIdRTValidFlag")
	@Size(min=1,max=1,message="accessIdRTValidFlag value can only be Y or N|UpdateUser")
	private  String accessIdRTValidFlag;

	@Schema(name = "contactEmailRTValidFlag")
	@Size(min=1,max=1,message="contactEmailRTValidFlag value can only be Y or N|UpdateUser")
	private String contactEmailRTValidFlag;

	@Schema(name = "guid")
	@Size(min=1,max=30,message="guid length is invalid|UpdateUser")
	private String guid;

	@Schema(name = "activatedInd")
	@Size(min=1,max=1,message="activatedInd value can only be Y or N|UpdateUser")
	private String activatedInd;

	@Schema(name = "isVerified")
	@Size(min=1,max=1,message="isVerified value can only be Y or N|UpdateUser")
	private String isVerified;

	@Schema(name = "mainCTNOptOut")
	@Size(min=1,max=1,message="mainCTNOptOut value can only be Y or N|UpdateUser")
	private String mainCTNOptOut;

	@Schema(name = "cbrOptOut")
	@Size(min=1,max=1,message="cbrOptOut value can only be Y or N|UpdateUser")
	private String cbrOptOut;

	@Schema(name = "contactEmailStatus")
	@Size(min=1,max=1,message="contactEmailStatus value can only be H ,S or V|UpdateUser")
	private String contactEmailStatus;

	@Schema(name = "zipCode")
	@Size(min=5,max=5,message="zipCode length is invalid|UpdateUser")
	private String zipCode;

	@Schema(name = "zipCode4")
	@Size(min=4,max=4,message="zipCode4 length is invalid|UpdateUser")
	private String zipCode4;

	@Schema(name = "cbrNumber")
	@Size(min=10,max=10,message="cbrNumber length is invalid|UpdateUser")
	private String cbrNumber;

	@Schema(name = "cbrRTValidFlag")
	@Size(min=1,max=1,message="cbrRTValidFlag value can only be Y or N|UpdateUser")
	private String cbrRTValidFlag;

	@Schema(name = "contactAddress")
	@Size(min=1,max=500,message="contactAddress length is invalid|UpdateUser")
	private String contactAddress;

	@Schema(name = "idpTraceId")
	private String idpTraceId;

	@Schema(name = "nickName")
	@Size(min = 0, max = 100, message =  "NickName length is invalid|UpdateUser")
	private String nickName;

	/**
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
	 * @return Map<String,Object> The map of unknown attributes.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();

}
