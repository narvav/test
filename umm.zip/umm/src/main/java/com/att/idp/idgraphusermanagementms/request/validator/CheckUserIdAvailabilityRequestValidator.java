package com.att.idp.idgraphusermanagementms.request.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import jakarta.ws.rs.core.HttpHeaders;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.resource.request.CheckUserIdAvailabilityRequest;
import com.att.idp.idgraphusermanagementms.resource.response.CheckUserIdAvailabilityResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;

/**
 * This class, CheckUserIdAvailabilityRequestValidator, is responsible for validating the CheckUserIdAvailabilityRequest.
 * It checks for the presence and validity of required fields in the request, and returns a CheckUserIdAvailabilityResponse accordingly.
 * It is annotated with @Component, @Configuration, and @PropertySource to indicate that it's a Spring Bean,
 * to allow it to access configuration properties, and to specify the location of the properties file respectively.
 *
 * The class contains several methods, including:
 * - checkUserIdAvailabilityRequestValidator: the main method that orchestrates the validation process.
 * - checkUserErrorResponse: a helper method that generates an error response.
 * - checkUserInputValidator: a method that validates the input fields in the request.
 * - checkUserRequestCSIValidator: a method that validates the 'CSI' field in the request.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class CheckUserIdAvailabilityRequestValidator {

	private static final Logger logger = LoggerFactory.getLogger(CheckUserIdAvailabilityRequestValidator.class);

	private String sClassName = "CheckUserIdAvailabilityRequestValidator";
	
	@Value("${RILHRS_VALID_CSIDs}")
	private String stCheckIdAvailabilityCSI;

	
	/**
	 * This method is responsible for validating the CheckUserIdAvailabilityRequest.
	 * It takes HttpHeaders and CheckUserIdAvailabilityRequest as parameters.
	 * HttpHeaders contains the request headers which may include additional information required for processing the request.
	 * CheckUserIdAvailabilityRequest encapsulates the details of the user ID availability check operation to be performed.
	 *
	 * The method performs various checks and validations on the input parameters and returns a CheckUserIdAvailabilityResponse object.
	 * The CheckUserIdAvailabilityResponse object encapsulates the result of the user ID availability check operation.
	 *
	 * @param requestHeader The HttpHeaders containing the request headers.
	 * @param checkUserRequest The CheckUserIdAvailabilityRequest containing the details of the user ID availability check operation.
	 * @return CheckUserIdAvailabilityResponse The response of the user ID availability check operation.
	 */
	public CheckUserIdAvailabilityResponse checkUserIdAvailabilityRequestValidator(HttpHeaders requestHeader,
			CheckUserIdAvailabilityRequest checkUserRequest) {
		
		CheckUserIdAvailabilityResponse checkUserResponse = null;
		
		String stAppInfo = null;
		String sMethodName = ".checkUserIdAvailabilityRequestValidator.";
		String stIdpTraceId = null;
		String stXAttClientId = null;
		
		stIdpTraceId = CommonUtil.getTraceId(requestHeader);
		if (stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
			stAppInfo = "Missing or Invalid IdpTraceId";
			return checkUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
			
		if (checkUserRequest == null) {
			stAppInfo = "checkUserRequest is NULL";
			logger.info("{}{}CUIARV_00 :: {}", sClassName, sMethodName, stAppInfo);
			return checkUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		
		checkUserRequest.setIdpTraceId(stIdpTraceId);
			
		if (requestHeader.getHeaderString("X-ATT-ClientId") != null) {
			stXAttClientId = requestHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
			logger.info("{}{}Setting callingSystemId: {}", sClassName, sMethodName,
					StringUtils.normalizeSpace(stXAttClientId));
			checkUserRequest.setCallingSystemId(stXAttClientId);
		} else {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			logger.info("{}{} :: {}", sClassName, sMethodName, stAppInfo);
			return checkUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		
		
		// checking Invalid attributes passed in Request
		Map<String, Object> allUnknownAttributes = new HashMap<>(checkUserRequest.unknownAttributes);
		
		if (!allUnknownAttributes.isEmpty()) {
			stAppInfo = "Invalid Attributes passed in CheckUserIdAvailabilityRequest : " + allUnknownAttributes;
			return checkUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					checkUserRequest.getIdpTraceId());
		}
		try {
			checkUserResponse = checkUserInputValidator(checkUserRequest);
			if (checkUserResponse != null) {
				logger.info("{}{}CUIARV_05 Response from checkUserIdAvailabilityRequestValidator : {}", sClassName, sMethodName,
						checkUserResponse);
				return checkUserResponse;
			} else {
				logger.info("{}{}CUIARV_06 Success Response from checkUserIdAvailabilityRequestValidator ", sClassName,
						sMethodName);
			}
			checkUserResponse = checkUserRequestCSIValidator(checkUserRequest);
			if (checkUserResponse != null) {
				logger.info("{}{}CUIARV_07 Response from checkUserRequestCSIValidator : {}", sClassName, sMethodName,
						checkUserResponse);
				return checkUserResponse;
			} else {
				logger.info("{}{}CUIARV_08 Success Response from checkUserRequestCSIValidator ", sClassName, sMethodName);
			}
			stAppInfo = "Input Validation Successful";
			logger.info("{}{}CUIARV_10 : {}", sClassName, sMethodName, stAppInfo);
		}catch (Exception e) {
			stAppInfo = "Exception thrown in checkUserIdAvailabilityRequestValidator : " + e.getMessage();
			checkUserResponse = checkUserErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo,
					 stIdpTraceId);
			logger.info("Exception in checkUserIdAvailabilityRequestValidator: {}", stAppInfo);
		}
		
		return checkUserResponse;
	}
	
	private CheckUserIdAvailabilityResponse checkUserRequestCSIValidator(CheckUserIdAvailabilityRequest checkUserRequest) throws Exception {

		String sMethodName = ".checkUserRequestCSIValidator.";
		String sIsExternalCall = checkUserRequest.getIsExternalCall();
		String stCallingSystemId = checkUserRequest.getCallingSystemId();
		String stIdpTraceId=checkUserRequest.getIdpTraceId();
		String stAppInfo = null;
		CheckUserIdAvailabilityResponse checkUserResponse = null;

		stCallingSystemId = stCallingSystemId.trim().toUpperCase();

		ArrayList<String> alValidCallingSystemId = CommonUtil.parseToArray(stCheckIdAvailabilityCSI,
				CommonDefs.VALUE_SEPARATOR_CHAR);
		logger.info("{}{}CUIARV_02 : Property RILHRS_VALID_CSIDs : {}", sClassName, sMethodName,
				alValidCallingSystemId);

		if (alValidCallingSystemId != null && !alValidCallingSystemId.contains(stCallingSystemId)
				&& sIsExternalCall != null && sIsExternalCall.equals("Y")) {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			logger.error("{}{}CUIARV_03 : {}", sClassName, sMethodName, stAppInfo);
			return checkUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					 stIdpTraceId);
		}

		return checkUserResponse;
	}

	
	/**
	 * This method is part of the CheckUserIdAvailabilityRequestValidator class.
	 * It is responsible for validating the CheckUserIdAvailabilityRequest.
	 * The method takes a CheckUserIdAvailabilityRequest as input.
	 * The CheckUserIdAvailabilityRequest encapsulates the details of the user ID availability check operation to be performed.
	 * The method performs various checks and validations on the input parameters and returns a CheckUserIdAvailabilityResponse object.
	 * The CheckUserIdAvailabilityResponse object encapsulates the result of the user ID availability check operation.
	 * The method checks for the presence and validity of required fields in the request, and returns a CheckUserIdAvailabilityResponse accordingly.
	 *
	 * @param checkUserRequest The CheckUserIdAvailabilityRequest containing the details of the user ID availability check operation.
	 * @return CheckUserIdAvailabilityResponse The response of the user ID availability check operation.
	 */
	public CheckUserIdAvailabilityResponse checkUserInputValidator(CheckUserIdAvailabilityRequest checkUserRequest) {
		
		CheckUserIdAvailabilityResponse checkUserResponse = null;
		Map<String, Object> hmResult = CommonUtil.getHashMap();
		
		String stAppInfo = null;
		String stCallingSystemId = checkUserRequest.getCallingSystemId();
		String stTransactionName = checkUserRequest.getTransactionName();
		String stSuggest1 = checkUserRequest.getSuggest1();
		String stSuggest2 = checkUserRequest.getSuggest2();
		String stNumSuggestions = checkUserRequest.getNumSuggestions();
		String stSearchSLIDNamespace = checkUserRequest.getSearchSLIDNamespace();
		String stDomain = checkUserRequest.getDomain();
//		String stBypassBadWordCheck = checkUserRequest.getBypassBadWordCheck();
		String ignoreQay = checkUserRequest.getIgnoreQay();
		String isExternalCall = checkUserRequest.getIsExternalCall();
		String stIdpTraceId=checkUserRequest.getIdpTraceId();
			
		// optional fields
		Optional.ofNullable(stSuggest2).ifPresent(x -> checkUserRequest.setSuggest2(x.trim().toLowerCase()));
//		Optional.ofNullable(stSearchSLIDNamespace).ifPresent(x -> checkUserRequest.setSearchSLIDNamespace(x.trim()));
//		Optional.ofNullable(stBypassBadWordCheck).ifPresent(x -> checkUserRequest.setBypassBadWordCheck(x.trim()));
		
		if ( (stTransactionName == null || stTransactionName.trim().isEmpty())
				|| (stCallingSystemId == null || stCallingSystemId.trim().isEmpty())
				|| (stSuggest1 == null || stSuggest1.trim().isEmpty())
				|| (stNumSuggestions == null || stNumSuggestions.trim().isEmpty())) {
			stAppInfo = "Required field(s) missing";

			return checkUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					stIdpTraceId);
		}
		if (!"CheckUserIdAvailability".equals(checkUserRequest.getTransactionName())) {
			stAppInfo = "Transaction Not Allowed :: TransactionName Should be CheckUserIdAvailability";
			return checkUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					stIdpTraceId);
		}
		if ((isExternalCall != null && !isExternalCall.isEmpty())) {
			if (!(isExternalCall.equalsIgnoreCase(CommonDefs.IND_Y)
					|| isExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
				stAppInfo = "isExternalCall must be one of Y or N";
				return checkUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						 stIdpTraceId);
			} else {
				checkUserRequest.setIsExternalCall(isExternalCall.trim().toUpperCase());
			}
		} else {
			checkUserRequest.setIsExternalCall(CommonDefs.IND_Y);
		}
		
		return checkUserResponse;
		
	}
	
	private CheckUserIdAvailabilityResponse checkUserErrorResponse(int appStatusCode, String stAppInfo,
		    String stIdpTraceId) {
			Map<String, Object> hmResponse = CommonUtil.getHashMap();
			hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
			hmResponse.put("idp-trace-id", stIdpTraceId);
			hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
			return CommonUtilHelper.generateCheckUserResponse(hmResponse);
		}

}
