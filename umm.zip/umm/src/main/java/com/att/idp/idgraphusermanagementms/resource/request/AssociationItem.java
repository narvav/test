package com.att.idp.idgraphusermanagementms.resource.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This class represents a single association item in the registrationOrchestration request.
 * Each item specifies a service/account to be merged or linked to the target accessId.
 *
 * If sourceAccessId is present, the item follows Path A (merge).
 * If sourceAccessId is absent, the item follows Path B (direct link via addAssociation).
 */
@Schema(name = "associationItem")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AssociationItem {

    /**
     * Source accessId to merge into targetAccessId.
     * Required only when merge is needed (Path A).
     */
    @Size(min = 1, max = 127, message = "sourceAccessId length is invalid|RegistrationOrchestration")
    private String sourceAccessId;

    /**
     * Service or account type. Must be one of: MOBILITY, TITAN, ECOMM, INDIVIDUAL.
     */
    @NotNull(message = "serviceName is required field in input request.|RegistrationOrchestration")
    @Size(min = 1, max = 30, message = "serviceName length is invalid|RegistrationOrchestration")
    private String serviceName;

    /**
     * Account BAN or Individual ID.
     */
    @NotNull(message = "sorInvariantId is required field in input request.|RegistrationOrchestration")
    @Size(min = 1, max = 255, message = "sorInvariantId length is invalid|RegistrationOrchestration")
    private String sorInvariantId;
}
