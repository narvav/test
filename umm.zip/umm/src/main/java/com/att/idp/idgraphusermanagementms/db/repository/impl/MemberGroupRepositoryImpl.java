package com.att.idp.idgraphusermanagementms.db.repository.impl;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashMap;

import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.db.model.Tmembergroup;
import com.att.idp.idgraphusermanagementms.db.repository.DomainRepository;
import com.att.idp.idgraphusermanagementms.db.repository.IDMProfileOrchestrationCustomRepository;
import com.att.idp.idgraphusermanagementms.db.repository.MemberGroupRepositoryCustom;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.StatusMsg;

/**
 * This is the implementation class for the MemberGroupRepositoryCustom interface.
 * It extends IDMProfileOrchestrationCustomRepository for common CRUD operations.
 * The entity associated with this repository is Tmembergroup and the ID type is Long.
 */
@Repository
public class MemberGroupRepositoryImpl extends IDMProfileOrchestrationCustomRepository<Tmembergroup, Long>
		implements MemberGroupRepositoryCustom {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MemberGroupRepositoryImpl.class);
	private static String sClassName = "MemberGroupRepositoryImpl";
	
	@Autowired
	private DomainRepository domainRepository;

	@Override
	public HashMap addMemberGrp(HashMap inpParamHash) throws SQLException {

		String sMethodName = ".addMemberGroup.";
		int rowCount = 0;
		HashMap resultHash = null;
		
		LOGGER.info(ProfileOrchestrationConstants.LOG_DBTOOLS000 ,sClassName,sMethodName,HtmlUtils.htmlEscape(String.valueOf(inpParamHash)));

		LocalDate localDate = LocalDate.now();
		java.sql.Date now = java.sql.Date.valueOf(localDate);

		String domain_name = (String) inpParamHash.get(MPSDefs.DB_DOMAIN_NAME);
		String parent_name = (String) inpParamHash.get(MPSDefs.DB_PARENT_NAME);
		String last_modified_by = (String) inpParamHash.get(MPSDefs.DB_LAST_MODIFIED_BY);

		String bulk_billing_ind = (String) inpParamHash.get(MPSDefs.DB_BULK_BILLING_IND);
		String premium_800_ind = (String) inpParamHash.get(MPSDefs.DB_PREMIUM_800_IND);
		String access_code = (String) inpParamHash.get(MPSDefs.DB_ACCESS_CODE);

		if (premium_800_ind == null || premium_800_ind.length() == 0) {
			premium_800_ind = MPSDefs.PREMIUM_800_IND_NO;
		}

		long group_num = 0;
		Long domain_id = null;
		
		try {

			domain_id = domainRepository.getDomainId(domain_name.toLowerCase());

			String sql = "INSERT INTO MPS_OWNER.TMEMBERGROUP(GROUP_NUM,PARENT_NAME, DOMAIN_ID, CREATE_DATE,LAST_MODIFIED,LAST_MODIFIED_BY, "
					+ "PREMIUM_800_IND,BULK_BILLING_IND,ACCESS_CODE ) "
					+ "values (GROUP_NUM_SEQ.NEXTVAL,:parentName,:domainId,"
					+ "sysdate,sysdate,:lastModifiedBy,:premium800Ind,:bulkBillingInd,:accessCode)";

			Session hibSession = getSession();

			rowCount = hibSession.createNativeQuery(sql).addSynchronizedQuerySpace("")
					//.setParameter("memberGrpNum", getMemberGroupNumSequence())
					.setParameter("parentName", (StringUtils.isNotBlank(parent_name) ? parent_name.toLowerCase() : ""))
					.setParameter("domainId", (domain_id != null ? domain_id : ""))
					//.setParameter("createDt", now)
					//.setParameter("lastModified", now)
					.setParameter("lastModifiedBy", (StringUtils.isNotBlank(last_modified_by) ? last_modified_by : ""))
					.setParameter("premium800Ind", premium_800_ind)
					.setParameter("bulkBillingInd", (bulk_billing_ind != null ? bulk_billing_ind : ""))
					.setParameter("accessCode", (StringUtils.isNotBlank(access_code) ? access_code : ""))
					.executeUpdate();

			resultHash = StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS, MPSDefs.MPS_ALL_OK, MPSDefs.SQL_SUCCESS,
												 MPSDefs.SQL_SUCCESS_MSG, Integer.toString(rowCount));
			resultHash.put(MPSDefs.DB_GROUP_NUM, Long.toString(group_num));
			resultHash.put(MPSDefs.DB_DOMAIN_ID, Long.toString(domain_id));
		} catch (Exception e) {
			if (e instanceof org.hibernate.exception.ConstraintViolationException) {
				resultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USERNAME_EXISTS_NUM,
						MPSDefs.ERR_USERNAME_EXISTS_MSG);
				LOGGER.info("{}{}MGR_02 : resultHash :: {}",sClassName,sMethodName, resultHash);
			} else {
				resultHash = StatusMsg.makeExceptionSQLStatus(e);
				LOGGER.error("{}{}MGR_03 : Error:: {}" ,sClassName,sMethodName, e.getMessage());
				LOGGER.error("{}{}MGR_04 : Exception = {}",sClassName,sMethodName, e);
			}
		} finally {
			LOGGER.info(sMethodName + "DBTOOLS999 : resultHash : " + resultHash);
		}
		return resultHash;
	}

	/*
	 * @Override public BigDecimal getMemberGroupNumSequence() {
	 * 
	 * final Session session = entityManager.unwrap(Session.class); Query<?> q =
	 * session.createNativeQuery("SELECT MPS_OWNER.GROUP_NUM_SEQ.NEXTVAL FROM dual"
	 * ); return (BigDecimal)q.getSingleResult(); }
	 */
}