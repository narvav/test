package com.att.idp.idgraphusermanagementms.utils;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.mpsys.common.utils.PropertyManager;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.Crypt;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.RILDefs;
import com.att.mpsys.common.utils.RILUtil;

import net.logstash.logback.argument.StructuredArguments;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
/**
 * The RILCheckAndEncryptPasswordHelper class is a utility class that provides methods for password validation and encryption.
 * This class is part of the com.att.idp.idgraphusermanagementms.utils package.
 * It provides methods to validate clear text passwords, encrypt passwords in various encryption algorithms (Crypt, MD5, SHA-1, and AES256), and decrypt AES256 passwords.
 * It also provides methods to generate temporary passwords and ACA passwords.
 * The class is annotated with @Component, indicating that it is an auto-detectable Spring bean and can be automatically wired into other components.
 */
@Component
public class RILCheckAndEncryptPasswordHelper{
	private static final Logger logger = LoggerFactory.getLogger(RILCheckAndEncryptPasswordHelper.class);
	private static String AES256Key;
	
	@Autowired
	private BadWordHelper oBadWordHelper;
	@Value("${GENERIC_PASSWORD_ENCRYPTION_TYPE}")
	String genericPasswordEncryptionType;
	
	/**
	 * checkAndEncryptPassword is the main method of the helper that first
	 * validates the clear text password, then encrypts them in four different
	 * encryption algorithms (Crypt, MD5, SHA-1, and AES256).
	 * @param inputParam input HashMap
	 * @return statusTMS return HashMap
	 */
	public HashMap checkAndEncryptPassword(HashMap inputParam) {
		logger.info(SpiMarker.getInstance(),"inputParam::" , StructuredArguments.entries(inputParam));
			
		String enc_password = null;
		String md5_password = null;
		String sha1_password = null;
		
//		 2103 - SSHA-256 encryption changes
		String generic_password = null;
		String generic_password_type = null;
		 
		String aes_password = null;
		String clear_password = null;
		String member_name = null;
		String domain_name = null;
		String salt = null;
		HashMap statusTMS = null;
		String sSkipPasswordValidation = null;
		boolean isError = true;
		String appInfo = null;
		String sDes3_password = null;

		//validate inputParam
		clear_password = (String) inputParam.get(MPSDefs.WS_CLEAR_TEXT);
		member_name = (String) inputParam.get(MPSDefs.WS_USER_ID);
		domain_name = (String) inputParam.get(MPSDefs.WS_DOMAIN);
		salt = (String) inputParam.get(RILDefs.WS_SALT);
		sSkipPasswordValidation = (String )inputParam.get(CommonDefs.SKIP_PASSWORD_VALIDATION);
		//first, check if all required arguments exist...
		if (member_name == null
			|| member_name.length() == 0
			|| domain_name == null
			|| domain_name.length() == 0
			|| clear_password == null
			|| clear_password.length() == 0) {

			if (member_name == null || member_name.length() == 0) {
				appInfo = "checkAndEncryptPasswordHelper::member name is not available"; 
				logger.error(CErrorDefs.ERR_EMPTY_NUM + 
					appInfo);
				//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
				statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, appInfo);
				return statusTMS;	
			}
			if (domain_name == null || domain_name.length() == 0) {
				appInfo = "checkAndEncryptPasswordHelper::domain name is not available";
				logger.error(CErrorDefs.ERR_EMPTY_NUM + " " +
					appInfo);
				//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
				statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, appInfo);
				return statusTMS;
			}
			if (clear_password == null || clear_password.length() == 0) {
				appInfo = "checkAndEncryptPasswordHelper::clear password is not available"; 
				logger.error(CErrorDefs.ERR_EMPTY_NUM + " " +
						appInfo);
				//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
				statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, appInfo);
				return statusTMS;
			}
		}
		
		try {
			//validate clear text password.
			HashMap validatePassHs = new HashMap();
			String appStatusCode = null;
			if(sSkipPasswordValidation == null || !sSkipPasswordValidation.equals(CommonDefs.DEFAULT_YES)){
				validatePassHs.put(MPSDefs.WS_CLEAR_TEXT,clear_password);
				validatePassHs.put(MPSDefs.WS_USER_ID,member_name);	
				validatePassHs.put(MPSDefs.WS_CALLING_SYSTEM_ID, inputParam.get(MPSDefs.WS_CALLING_SYSTEM_ID));
				validatePassHs.put(MPSDefs.WS_TRANSACTION_NAME, inputParam.get(MPSDefs.WS_TRANSACTION_NAME));
				validatePassHs.put("tempGenerated", inputParam.get("tempGenerated"));
				//1906: in support of new user password creation rules.
				validatePassHs.put(CommonDefs.FIRST_NAME, inputParam.get(CommonDefs.FIRST_NAME));
				validatePassHs.put(CommonDefs.LAST_NAME, inputParam.get(CommonDefs.LAST_NAME));
				validatePassHs.put(CommonDefs.CONTACT_EMAIL, inputParam.get(CommonDefs.CONTACT_EMAIL));
				validatePassHs.put(CommonDefs.MAIN_CTN, inputParam.get(CommonDefs.MAIN_CTN));
				statusTMS = validatePassword(validatePassHs, logger);
				appStatusCode = (String)statusTMS.get(MPSDefs.APP_STATUS_CODE);
				
				//return the error status HashMap if validation failed			
				if (!appStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					return statusTMS;				
				}
			}
	
			//derive Crypt, MD5, SHA-1 and AES256 passwords and add them to the return hashmap
			HashMap passEncryptHs = new HashMap();
			passEncryptHs.put(MPSDefs.WS_CLEAR_TEXT,clear_password);
			passEncryptHs.put(RILDefs.WS_SALT,salt);
			
			//generate Crypt password
			statusTMS = generateCryptPassword(passEncryptHs, logger);
			appStatusCode = (String)statusTMS.get(MPSDefs.APP_STATUS_CODE);
			if (appStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				if (statusTMS.containsKey(RILDefs.RIL_ENC_PASSWORD)) {
					enc_password = (String)statusTMS.get(RILDefs.RIL_ENC_PASSWORD);
				}
			} else {
				return statusTMS;
			}
			
			//generate MD5 password
			statusTMS = generateMD5Password(passEncryptHs, logger);
			appStatusCode = (String)statusTMS.get(MPSDefs.APP_STATUS_CODE);
			if (appStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				if (statusTMS.containsKey(RILDefs.RIL_MD5_PASSWORD)) {
					md5_password = (String)statusTMS.get(RILDefs.RIL_MD5_PASSWORD);
				}
			} else {
				return statusTMS;
			}
	
			//generate SHA-1 password
			statusTMS = generateSHA1Password(passEncryptHs, logger);
			appStatusCode = (String)statusTMS.get(MPSDefs.APP_STATUS_CODE);
			if (appStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				if (statusTMS.containsKey(RILDefs.RIL_SHA1_PASSWORD)) {
					sha1_password = (String)statusTMS.get(RILDefs.RIL_SHA1_PASSWORD);
				}
			} else {
				return statusTMS;
			}			
			
			 // 2103 - SSHA-256 encryption changes
			// generate Generic password
			if (genericPasswordEncryptionType != null && !genericPasswordEncryptionType.isEmpty()) {
				statusTMS = generateGenericPassword(passEncryptHs, genericPasswordEncryptionType, logger);
				appStatusCode = (String) statusTMS.get(MPSDefs.APP_STATUS_CODE);
				if (appStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					if (statusTMS.containsKey(RILDefs.RIL_GEN_PASSWORD)) {
						generic_password = (String) statusTMS.get(RILDefs.RIL_GEN_PASSWORD);
						generic_password_type = (String) statusTMS.get(RILDefs.RIL_GEN_PASSWORD_TYPE);
					}
				} else {
					return statusTMS;
				}
			}
			 
			//generate AES256 password
			statusTMS = generateAES256Password(passEncryptHs, logger);
			appStatusCode = (String)statusTMS.get(MPSDefs.APP_STATUS_CODE);
			if (appStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				if (statusTMS.containsKey(RILDefs.RIL_AES_PASSWORD)) {
					aes_password = (String)statusTMS.get(RILDefs.RIL_AES_PASSWORD);
				}
			} else {
				return statusTMS;
			}
			
			//generate DES3 password
			statusTMS = this.generateDES3Password(passEncryptHs, logger);
			appStatusCode = (String)statusTMS.get(MPSDefs.APP_STATUS_CODE);
			if (appStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				if (statusTMS.containsKey(RILDefs.RIL_DES3_PASSWORD)) {
					sDes3_password = (String)statusTMS.get(RILDefs.RIL_DES3_PASSWORD);
				}
			} else {
				return statusTMS;
			}
			//if no errors at this point, set isError to false so finally logic runs
			isError = false;

		} catch (Exception e) {
			
			statusTMS = CommonErrorMap.makeExceptionMap(e, logger);
			
			
			return statusTMS;

		} finally {
			//add the encrypted passwords to the return HashMap
			if (!isError) {
				//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
				statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG);

				statusTMS.put(RILDefs.RIL_ENC_PASSWORD, enc_password);
				statusTMS.put(RILDefs.RIL_MD5_PASSWORD, md5_password);
				statusTMS.put(RILDefs.RIL_SHA1_PASSWORD, sha1_password);
				statusTMS.put(RILDefs.RIL_AES_PASSWORD, aes_password);
				statusTMS.put(RILDefs.RIL_DES3_PASSWORD, sDes3_password);

//				 2103 - SHA-256 encryption changes
				if (generic_password != null && !generic_password.isEmpty()) {
					statusTMS.put(RILDefs.RIL_GEN_PASSWORD, generic_password);
					statusTMS.put(RILDefs.RIL_GEN_PASSWORD_TYPE, generic_password_type);
				}
				 
			}
			logger.info("STATUS:: {}", statusTMS !=null ? StringUtils.normalizeSpace(statusTMS.toString()):"null");
		}

		return statusTMS;
	}

	/**
	 * generateSalt generates a random two-character string to be appended
	 * to the beginning of the Crypt password.
	 * @return Salt String
	 * @throws Exception
	 */
	private String generateSalt() {
      StringBuilder buf;
		int strLength = RILDefs.RIL_PASSWORD_SALT_CHAR.length();
		char c = 0;
		//SID#63970 : implement SecureRandom
		SecureRandom secRandom = new SecureRandom();
		//Random randGen = new Random();
		buf = new StringBuilder();
		int randNum = 0;
		
		for (int i = 0; i < 2; i++) {
			randNum = secRandom.nextInt(strLength - 1);

			while (!(randNum >= 0 && randNum <= (strLength - 1))) {
				randNum = secRandom.nextInt(strLength - 1);
			}
			c = (char) RILDefs.RIL_PASSWORD_SALT_CHAR.charAt(randNum);

			buf.append(c);
		}

		String salt = buf.toString();

		return buf.toString();
	}

	/**
	 * The getClearTextFromAES method is part of the RILCheckAndEncryptPasswordHelper class.
	 * This method is used to decrypt an AES256 encrypted password back to clear text.
	 * The method takes a HashMap as a parameter which contains the AES256 encrypted password.
	 * The method uses the SecretKeySpec and Cipher classes from the javax.crypto package to perform the decryption.
	 * If the decryption is successful, the method returns a HashMap containing the clear text password.
	 * If the decryption fails, the method logs an error message and returns a HashMap containing the error details.
	 *
	 * @param aesPasswordParameters A HashMap containing the AES256 encrypted password.
	 * @param logger A Logger instance for logging error or status messages.
	 * @return HashMap A HashMap containing the clear text password if decryption is successful, or error details if decryption fails.
	 */
	public HashMap getClearTextFromAES(HashMap aesPasswordParameters, Logger logger) {
		String originalString = "";
		String thisMethod = "getClearTestFromAES";
		String skey;
		String aesPassword;
		String appInfo;
		HashMap resultHashMap = new HashMap();
		HashMap statusTMS;
				
		try {
			
			//check that encrypted password exists
			if (!aesPasswordParameters.containsKey(RILDefs.RIL_AES_PASSWORD)) {
				appInfo = "AES Password field is null";
				statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, appInfo);
				return statusTMS;
			}
			
			aesPassword = (String)aesPasswordParameters.get(RILDefs.RIL_AES_PASSWORD);
			
			if (AES256Key == null || AES256Key.length() == 0) {
				AES256Key = PropertyManager.getProperty(CommonDefs.MOUPSECRETConfig,CommonDefs.AES256KEY);
			}
			
			//Something's wrong if AES256Key is still null or empty			
			if (AES256Key == null || AES256Key.length() == 0) {
				appInfo = "AES256KEY is null or empty";
				statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, appInfo);
				return statusTMS;				
			}
						
			byte[] raw = hexToByteArray(AES256Key);

			//Create SecretKeySpec
			SecretKeySpec skeySpec = new SecretKeySpec(raw, RILDefs.ENCRYPT_AES);
			
			//Get AES Cipher instance in decrypt mode
			Cipher cipher = Cipher.getInstance(RILDefs.ENCRYPT_AES);
			cipher.init(Cipher.DECRYPT_MODE, skeySpec);
			
			//Retrieve original clear text password
			byte[] original =  cipher.doFinal(hexToByteArray(aesPassword));
			originalString = new String(original);
			
		} catch (Exception e) {
			statusTMS = CommonErrorMap.makeExceptionMap(e, logger);
								
			return statusTMS;			
		}
		
		//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
		statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG);
		statusTMS.put(MPSDefs.WS_CLEAR_TEXT,originalString);
		//do not log status as it contains clear text password.			
		return statusTMS;		
	}

	/**
	 * validatePassword validates the clear text password according to business rules
	 * 
	 * @param validatePasswordParameters input HashMap
	 * @param logger logger
	 * @return statusTMS return HashMap
	 */
	public HashMap validatePassword(HashMap validatePasswordParameters, Logger logger) {
		HashMap statusTMS = null;
		String clearTextPassword = (String)validatePasswordParameters.get(MPSDefs.WS_CLEAR_TEXT);
		String handle = (String)validatePasswordParameters.get(MPSDefs.WS_USER_ID);
		String sTempGenerated = (String)validatePasswordParameters.get("tempGenerated");
		String appInfo = null;
		String appStatusCode = null;
		String thisMethod = "validatePassword";
		
		logger.debug(SpiMarker.getInstance(), "RCE_VP_0 : "+ "Input to validatePassword=",  StructuredArguments.entries(validatePasswordParameters));

		try {
			//length should be between 6 and 16 characters
			String minClearLengthString = PropertyManager.getProperty(CommonDefs.MOUPConfig, CommonDefs.MIN_CLEAR_PASSWD_LENGTH_KEY);
			String maxClearLengthString = PropertyManager.getProperty(CommonDefs.MOUPConfig, CommonDefs.MAX_CLEAR_PASSWD_LENGTH_KEY);
			int minClearLength = 0;
			int maxClearLength = 0;
			if (minClearLengthString != null && minClearLengthString.trim().length() != 0) {
				minClearLength = Integer.parseInt(minClearLengthString);
			} else {
				appInfo = "Clear text password min length must be defined in ril.properties";
				//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
				statusTMS =
						CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, appInfo);
				
				return statusTMS;			
			}
			
			if (maxClearLengthString != null && maxClearLengthString.trim().length() != 0) {
				maxClearLength = Integer.parseInt(maxClearLengthString);
			} else {
				appInfo = "Clear text password max length must be defined in ril.properties";
				//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
				statusTMS =
						CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, appInfo);
				return statusTMS;						
			} 
			//1906: in support of new user password creation rules
			if (clearTextPassword.length() < minClearLength
				|| clearTextPassword.length() > maxClearLength) {
				appInfo = "Clear text password length must be between "+minClearLength+" and "+maxClearLength+ "inclusive.";
				//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
				statusTMS =
						CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_LENGTH_NUM, appInfo);
				return statusTMS;
			}
			//1906: in support of new user password creation rules - Added minf
			//if no valid chars
			if (!RILUtil.hasAllValidChars(clearTextPassword, logger)) {
				appInfo = "Clear text password must not contain invalid characters.";
				//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
				statusTMS =
						CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_CHARS_NUM, appInfo);
				return statusTMS;
			}
	
			// Do not allow the handle or any subset of the handle, beginning from the start of the handle, to be used as the password
			String tempHandle = handle; 
			if(clearTextPassword.length() <= tempHandle.length()){
				tempHandle = tempHandle.substring(0,clearTextPassword.length());
				
				//member name (handle) and password can not be same
				if (clearTextPassword.equals(tempHandle)) {
					appInfo = "Clear password should not be subset of handle.";
					//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
					statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SAME_HANDLEPASS_NUM, appInfo);
					return statusTMS;
				}
			}
			
			
			// only do the letters/numbers check if callingSystemId != COLA*
			HashMap hmPwdLettersAndNumbersExclusion =
				RILUtil.getKeyValueAsArrayList(
					CommonDefs.PWD_LETTERS_NUMBERS_EXCLUSION,
					CommonDefs.VALUE_SEPARATOR,
					logger);
	
			appStatusCode =
				(String) hmPwdLettersAndNumbersExclusion.get(
					CErrorDefs.COMMON_APP_STATUS_CODE);
	
			if (!appStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
			{
				appInfo =
					"Error code returned from RILUtil.getKeyValueAsArrayList - "
						+ appStatusCode;
				logger.info("RCE_VP_1 : "+appInfo);
				
				return (statusTMS = hmPwdLettersAndNumbersExclusion);
			}
	
			ArrayList alPwdLettersAndNumbersExclusion = 
			    (ArrayList)hmPwdLettersAndNumbersExclusion.get(CommonDefs.PWD_LETTERS_NUMBERS_EXCLUSION);
			
			String callingSystemId = (String)validatePasswordParameters.get(MPSDefs.WS_CALLING_SYSTEM_ID);
			
			// The check will take place if no calling system id is passed or if the passed
			// calling system is not in the exception list.
			// Start 2004:CR-199433: DT2IDM-966: MPSYS- remove Check for pw creation.
			// Changes made by kc2039
			/*
			 * if ((callingSystemId == null) || (callingSystemId != null &&
			 * !(alPwdLettersAndNumbersExclusion.contains(callingSystemId)))) { //password
			 * must contain both numbers and digits if not temp generated password
			 * if(sTempGenerated == null ||
			 * !sTempGenerated.trim().equalsIgnoreCase(CommonDefs.IND_Y)){ if
			 * (!RILUtil.hasLettersAndNumbers(clearTextPassword)) { appInfo =
			 * "Clear text password must contain both numbers and letters.";
			 * logger.info("RCE_VP_2 : "+ appInfo); statusTMS =
			 * RILErrorMap.makeRILStatusMap( MPSDefs.ERR_INVALID_DATA_NUM, appInfo); return
			 * statusTMS; } } }
			 */
			// End CR-199433
			
			//1906: in support of new user password creation rules.
			//statusTMS = checkPwdValidationRulesForHandle(handle, clearTextPassword);
			statusTMS = checkPwdValidationRulesForUserInfo(validatePasswordParameters, clearTextPassword);
			logger.info("Response from checkPwdValidationRulesForUserInfo(): " + statusTMS);
			appStatusCode = (String)statusTMS.get(MPSDefs.APP_STATUS_CODE);
			
			//return the error status HashMap if validation failed			
			if (!appStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				return statusTMS;				
			}
		
			HashMap hmBadWordInput = new HashMap();
			hmBadWordInput.put(CommonDefs.TRANSACTION_NAME, validatePasswordParameters.get(MPSDefs.WS_TRANSACTION_NAME));
			hmBadWordInput.put(CommonDefs.CALLING_SYSTEM_ID, validatePasswordParameters.get(MPSDefs.WS_CALLING_SYSTEM_ID));
			hmBadWordInput.put(CommonDefs.ITEM_TYPE, CommonDefs.PASSWORD);
			hmBadWordInput.put(CommonDefs.ITEM, clearTextPassword);
			logger.info(SpiMarker.getInstance(), "Input to BadWordHelper.scanWords(): " , StructuredArguments.entries(hmBadWordInput));
			
			
			statusTMS = oBadWordHelper.scanWords(hmBadWordInput);
			
			if (statusTMS == null) {
			    statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "Invalid Response from BadWordHelper.scanWords().");
				return statusTMS;
			}
			
			String sAppStatusCode = (String) statusTMS.get(CommonDefs.COMMON_APP_STATUS_CODE);
			if (!sAppStatusCode.equalsIgnoreCase(CErrorDefs.COMMON_SUCCESS)) {
				String sAppInfo = (String) statusTMS.get(CommonDefs.COMMON_APP_INFO);
				logger.info("RCE_VP_3 : "+ 
						"Error Encountered In the call to the BadWordHelper:: " + sAppInfo);
				return statusTMS;
			}
		}
		catch (Exception ex) {
			statusTMS = CommonErrorMap.makeExceptionMap(ex, logger);
			statusTMS.put(MPSDefs.APP_INFO,ex.toString());
								
			return statusTMS;			}

		// if we get here we passed validation
		//TODO:erro code map
		statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG);
		//statusTMS = RILErrorMap.makeRILStatusMap(RILDefs.RIL_SUCCESS_NUM, RILDefs.RIL_SUCCESS);	
		logger.info("checkAndEncryptPasswordHelper::validatePassword::STATUS::" + statusTMS);		
		return statusTMS;
	}
	
	
	//1906:in support of new user password creation rules.
	/**
	 * @param hInputUserInfo
	 * @param sClearTextPwd
	 * @return HashMap statusTMS
	 */
	private HashMap checkPwdValidationRulesForUserInfo(HashMap hInputUserInfo, String sClearTextPwd){
			HashMap statusTMS = null;
			String sAppInfo = null;
			String sHandleToCompare = "";
			
			StringBuilder sHandleAlphabets = new StringBuilder();
			String sInputHandle = (String) hInputUserInfo.get(MPSDefs.WS_USER_ID);
			String sFirstName = (String) hInputUserInfo.get(CommonDefs.FIRST_NAME);   
			String sLastName = (String) hInputUserInfo.get(CommonDefs.LAST_NAME); 
			String sContactEmail = (String) hInputUserInfo.get(CommonDefs.CONTACT_EMAIL);
			String sMainCTN = (String) hInputUserInfo.get(CommonDefs.MAIN_CTN);	
			String sContactEmailDomain=null;
			String sContactEmailHandle=null;
			boolean bPasswdValidationFlag = true;
			boolean bHandleValidationFlag = false;
			String sTempClearTextPwd = sClearTextPwd.toLowerCase();		
			
			for ( int i=0; i < sInputHandle.length(); i++){
	    		char c = sInputHandle.charAt(i);
	    		if(!Character.isLetter(c)){
	    			break;    			
	    		}else {
	    			sHandleAlphabets.append(c);
	    		}
	    	}
					
			if(sHandleAlphabets != null && sHandleAlphabets.length() != 0){
				sHandleToCompare = sHandleAlphabets.toString();
			}
			
			if(sHandleToCompare != null && sHandleToCompare.length() != 0){
				int indexOfHandleInPwd = sClearTextPwd.indexOf(sHandleToCompare);
				if(indexOfHandleInPwd != -1){
					if(indexOfHandleInPwd >= 2){
						bHandleValidationFlag = true;
					}
					
					String sExtraCharsInPwd = sClearTextPwd.substring(indexOfHandleInPwd + sHandleToCompare.length(),sClearTextPwd.length());
					if(!bHandleValidationFlag && sExtraCharsInPwd.length() >= 2){
						bHandleValidationFlag = true;
					}
					if(!bHandleValidationFlag){
						sAppInfo = "Alphabetic portion of handle used as password without having atleast 2 characters following or preceding.";	
						//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
						statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SAME_HANDLEPASS_NUM, sAppInfo);
						return statusTMS;
					}
				}
			}
			
			if(bPasswdValidationFlag && sInputHandle !=null && !sInputHandle.isEmpty()){
				sInputHandle = sInputHandle.toLowerCase();
				if(sTempClearTextPwd.contains(sInputHandle)){
					sAppInfo = "Requested password containing username is not allowed.";	
					bPasswdValidationFlag = false;
				}
			}
			
			//1907: SID:64163 MPSYS : Update new password rule to relax check for firstname and lastname less than 4 chars
			if(bPasswdValidationFlag && sFirstName !=null && !sFirstName.isEmpty() && sFirstName.length() > 3){
				sFirstName = sFirstName.toLowerCase();
				if(sTempClearTextPwd.contains(sFirstName)){
					sAppInfo = "Requested password containing firstName is not allowed.";	
					bPasswdValidationFlag = false;
				}
			}
			if(bPasswdValidationFlag && sLastName !=null && !sLastName.isEmpty() && sLastName.length() > 3){
				sLastName = sLastName.toLowerCase();
				if(sTempClearTextPwd.contains(sLastName)){
					sAppInfo = "Requested password containing lastName is not allowed.";	
					bPasswdValidationFlag = false;
				}
			}
			if(bPasswdValidationFlag && sContactEmail != null && !sContactEmail.isEmpty()){
				sContactEmail = sContactEmail.toLowerCase();
				if(sTempClearTextPwd.contains(sContactEmail)){
					sAppInfo = "Requested password containing contactEmail is not allowed.";	
					bPasswdValidationFlag = false;
				}
				int len = sContactEmail.indexOf('@');
				if (len > -1) {
					sContactEmailDomain = sContactEmail.substring(len + 1);
					sContactEmailHandle = sContactEmail.substring(0, len);
				}
				if(bPasswdValidationFlag && sContactEmailDomain != null && sTempClearTextPwd.contains(sContactEmailDomain)){
					sAppInfo = "Requested password containing contactEmail domain is not allowed.";	
					bPasswdValidationFlag = false;
				}
				if(bPasswdValidationFlag && sContactEmailHandle != null && sTempClearTextPwd.contains(sContactEmailHandle)){
					sAppInfo = "Requested password containing contactEmail username is not allowed.";	
					bPasswdValidationFlag = false;
				}
			}
			if(bPasswdValidationFlag && sMainCTN != null && !sMainCTN.isEmpty()){
				if(sTempClearTextPwd.contains(sMainCTN)){
					sAppInfo = "Requested password containing mainCTN is not allowed";	
					bPasswdValidationFlag = false;
				}
			}
			if(bPasswdValidationFlag)
				statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS);
			else
				statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SAME_HANDLEPASS_NUM, sAppInfo);
			return statusTMS;
		}	
	
	/*
	 * private HashMap checkPwdValidationRulesForHandle(String sInputHandle, String
	 * sClearTextPwd){ HashMap statusTMS = null; String sAppInfo = null; String
	 * sHandleToCompare = ""; StringBuilder sHandleAlphabets = new StringBuilder();
	 * 
	 * for ( int i=0; i < sInputHandle.length(); i++){ char c =
	 * sInputHandle.charAt(i); if(!Character.isLetter(c)){ break; }else {
	 * sHandleAlphabets.append(c); } }
	 * 
	 * if(sHandleAlphabets != null && sHandleAlphabets.length() != 0){
	 * sHandleToCompare = sHandleAlphabets.toString(); }
	 * 
	 * if(sHandleToCompare != null && sHandleToCompare.length() != 0){ int
	 * indexOfHandleInPwd = sClearTextPwd.indexOf(sHandleToCompare);
	 * if(indexOfHandleInPwd != -1){ if(indexOfHandleInPwd >= 2){ statusTMS =
	 * RILErrorMap.makeRILStatusMap(RILDefs.RIL_SUCCESS_NUM, RILDefs.RIL_SUCCESS);
	 * return statusTMS; }
	 * 
	 * String sExtraCharsInPwd = sClearTextPwd.substring(indexOfHandleInPwd +
	 * sHandleToCompare.length(),sClearTextPwd.length());
	 * if(sExtraCharsInPwd.length() >= 2){ statusTMS =
	 * RILErrorMap.makeRILStatusMap(RILDefs.RIL_SUCCESS_NUM, RILDefs.RIL_SUCCESS);
	 * return statusTMS; }
	 * 
	 * sAppInfo =
	 * "Alphabetic portion of handle used as password without having atleast 2 characters following or preceding."
	 * ; statusTMS
	 * =RILErrorMap.makeRILStatusMap(MPSDefs.ERR_SAME_HANDLEPASS_NUM,sAppInfo);
	 * return statusTMS;
	 * 
	 * } }
	 * 
	 * statusTMS = RILErrorMap.makeRILStatusMap(RILDefs.RIL_SUCCESS_NUM,
	 * RILDefs.RIL_SUCCESS); return statusTMS; }
	 */

	/**
	 * generateCryptPassword encrypts the clear text password using Crypt algorithm
	 * 
	 * @param passwordParameters input HashMap
	 * @param logger logger
	 * @return statusTMS return HashMap
	 */
	public HashMap generateCryptPassword(HashMap passwordParameters, Logger logger) {
		HashMap statusTMS;		
		String digest = "";
		String password = (String)passwordParameters.get(MPSDefs.WS_CLEAR_TEXT);
		String salt = (String)passwordParameters.get(RILDefs.WS_SALT);
		
		try {
			
			if (salt == null || salt.length() == 0) {
				salt = generateSalt();
			}
			
			digest = Crypt.crypt(salt,password);
			
		} catch (Exception e) {
			System.err.println(e);
			statusTMS = CommonErrorMap.makeExceptionMap(e, logger);
			statusTMS.put(MPSDefs.APP_INFO,e.toString());
									
			return statusTMS;								
		}
		
		//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
		statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG);
		statusTMS.put(RILDefs.RIL_ENC_PASSWORD, digest);
		logger.info("checkAndEncryptPasswordHelper::generateCryptPassword::STATUS::" + statusTMS);			
		return statusTMS;	
	}

	/**
	 * generateMD5Password encrypts the clear text password using MD5 algorithm
	 * For YAHOO - the encrypted md5 password is encoded in BASE64
	 * 
	 * @param passwordParameters input HashMap
	 * @param logger logger
	 * @return statusTMS return HashMap
	 */
	public HashMap generateMD5Password(HashMap passwordParameters, Logger logger) {
		HashMap statusTMS;
		String digest = "";
		byte[] digestBytes = null;
		String password = (String)passwordParameters.get(MPSDefs.WS_CLEAR_TEXT);
		
		try {
			
			MessageDigest md = MessageDigest.getInstance(RILDefs.ENCRYPT_MD5);
			md.reset();
			md.update(password.getBytes());
			digestBytes = md.digest();
			digest = CommonUtil.base64Encode(digestBytes);
			
		} catch (Exception e) {
			statusTMS = CommonErrorMap.makeExceptionMap(e, logger);
			
										
			return statusTMS;					
		}
		//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
		statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG);
		statusTMS.put(RILDefs.RIL_MD5_PASSWORD, digest);
		logger.info("checkAndEncryptPasswordHelper::generateMD5Password::STATUS::" + statusTMS);			
		return statusTMS;	
	}
	
	/**
	 * generateSHA1Password encrypts the clear text password using SHA-1 algorithm
	 * The return password is encrypted in BASE64
	 * 
	 * @param passwordParameters input HashMap
	 * @param logger logger
	 * @return statusTMS return HashMap
	 */	
	public HashMap generateSHA1Password(HashMap passwordParameters, Logger logger) {
		HashMap statusTMS;
		String digest = "";
		byte[] digestBytes = null;
		String password = (String)passwordParameters.get(MPSDefs.WS_CLEAR_TEXT);
		
		try{
		
			MessageDigest md = MessageDigest.getInstance(RILDefs.ENCRYPT_SHA1);
			md.reset();
			md.update(password.getBytes());
			digestBytes = md.digest();
			//Convert to BASE 64
			digest = CommonUtil.base64Encode(digestBytes);
		
		} catch (Exception e) {
			statusTMS = CommonErrorMap.makeExceptionMap(e, logger);
												
			return statusTMS;				
		}
		//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
		statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG);
		statusTMS.put(RILDefs.RIL_SHA1_PASSWORD, digest);
		logger.info("checkAndEncryptPasswordHelper::generateSHA1Password::STATUS::" + statusTMS);			
		return statusTMS;	
	}	
	
	/**
	 * The generateGenericPassword method is part of the RILCheckAndEncryptPasswordHelper class.
	 * This method is used to encrypt a clear text password using a generic encryption algorithm.
	 * The encryption algorithm is specified by the genericPasswordEncryptionType parameter.
	 * The method takes a HashMap as a parameter which contains the clear text password.
	 * The method uses the MessageDigest class from the java.security package to perform the encryption.
	 * If the encryption is successful, the method returns a HashMap containing the encrypted password.
	 * If the encryption fails, the method logs an error message and returns a HashMap containing the error details.
	 *
	 * @param passwordParameters A HashMap containing the clear text password.
	 * @param genericPasswordEncryptionType A String specifying the encryption algorithm to be used.
	 * @param logger A Logger instance for logging error or status messages.
	 * @return HashMap A HashMap containing the encrypted password if encryption is successful, or error details if encryption fails.
	 */
	// 2103 - SHA-256 encryption changes
	public HashMap generateGenericPassword(HashMap passwordParameters, String genericPasswordEncryptionType,
			Logger logger) {
		HashMap statusTMS;
		String digest = "";
		byte[] digestBytes = null;
		String password = (String) passwordParameters.get(MPSDefs.WS_CLEAR_TEXT);
		String algorithm = null;

		switch (genericPasswordEncryptionType) {
		case "SHA256":
			algorithm = RILDefs.ENCRYPT_SHA256;
			break;
		default:
			;
		}

		try {
			MessageDigest md = MessageDigest.getInstance(algorithm);
			md.reset();
			md.update(password.getBytes());
			digestBytes = md.digest();
			// Convert to BASE 64
			digest = CommonUtil.base64Encode(digestBytes);

		} catch (Exception e) {
			statusTMS = CommonErrorMap.makeExceptionMap(e, logger);
			return statusTMS;
		}
		//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
		statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG);
		statusTMS.put(RILDefs.RIL_GEN_PASSWORD, digest);
		statusTMS.put(RILDefs.RIL_GEN_PASSWORD_TYPE, genericPasswordEncryptionType);
		logger.debug("checkAndEncryptPasswordHelper::generateGenericPassword::STATUS::" + statusTMS);
		return statusTMS;
	}
	 

	/**
	 * generateAES256Password encrypts the clear text password using AES256 algorithm
	 * 
	 * @param passwordParameters input HashMap
	 * @param logger logger
	 * @return statusTMS return HashMap
	 */
	public HashMap generateAES256Password(HashMap passwordParameters, Logger logger) {
		HashMap statusTMS;
		String thisMethod= "generateAES256Password";
		String digest;
		String skey;
		String appInfo;
		try {
			//get clear text
			String clearText = (String)passwordParameters.get(MPSDefs.WS_CLEAR_TEXT);
			
			//Check if class field is already populated
			//If not, retrieve from properties file
			if (AES256Key == null || AES256Key.length() == 0) {
				AES256Key = PropertyManager.getProperty(CommonDefs.MOUPSECRETConfig, CommonDefs.AES256KEY);
			}
			
			//Something's wrong if AES256Key is still null or empty			
			if (AES256Key == null || AES256Key.length() == 0) {
				appInfo = "AES256KEY is null or empty";
				statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, appInfo);
				return statusTMS;				
			}
						
			byte[] raw = hexToByteArray(AES256Key);
			
			//Create SecretKeySpec
			SecretKeySpec skeySpec = new SecretKeySpec(raw, RILDefs.ENCRYPT_AES);
			
			// Instantiate the AES Cipher in encrypt mode
			Cipher cipher = Cipher.getInstance(RILDefs.ENCRYPT_AES);
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec);

			// Encrypt Clear Text using AES256 Cipher
			byte[] encrypted =  cipher.doFinal(clearText.getBytes());

			digest = asHex(encrypted);
			
		} catch (Exception e) {
			statusTMS = CommonErrorMap.makeExceptionMap(e, logger);
										
			return statusTMS;			
		}
		
		//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
		statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG);
		statusTMS.put(RILDefs.RIL_AES_PASSWORD, digest);
		logger.info("checkAndEncryptPasswordHelper::generateAES256Password::STATUS::" + statusTMS);				
		return statusTMS;	
	}
	
	/**
	 * generateTempPassword returns a six-character string, with the first 3
	 * being letters from the allowed list and the last 3 being random numbers
	 * 
	 * @return temporary password String
	 */
	/*
	 * public String generateRandomPassword(int iPasswordLength) { java.util.Random
	 * r = new java.util.Random();
	 * 
	 * char[] caValidChars = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'j', 'k',
	 * 'm', 'n', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B',
	 * 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'M', 'N', 'P', 'Q', 'R', 'S', 'T',
	 * 'U', 'V', 'W', 'X', 'Y', 'Z', '2', '3', '4', '5', '6', '7', '8', '9', '~',
	 * '@', '#', '$', '%', '&', '*', '-', '_', '+', '=' }; if (iPasswordLength < 1)
	 * { throw new IllegalArgumentException( "Invalid password length " +
	 * iPasswordLength); } StringBuilder sbRandomPassword = new StringBuilder(); for
	 * (int i = 0; i < iPasswordLength; i++) {
	 * sbRandomPassword.append(caValidChars[r.nextInt(caValidChars.length)]); }
	 * return sbRandomPassword.toString(); }
	 */   

	/**
	 * generateTempPassword returns a six-character string, with the first 3
	 * being letters from the allowed list and the last 3 being random numbers
	 * 
	 * @return temporary password String
	 */
	public  String generateTempPassword() {
		// Updating the generated password to return only lowercase in the letter section of
		// the password.  This is per a COLA requirement.  -rl1364, Dec_2007 release. 
		String PassChars1 = "uylkqrwkljhyalqrhuajwyqlhkjklqahyurqakjlkahjklqruywlkjwyuhajhqryw";
		String PassChars2 = "0536094128157992341578346501326578034128976340809563278645124897";
		String Password = "";
		int RandomAdj = 0;
		Password = randomPassword(PassChars1, RandomAdj);
		RandomAdj++;
		Password = Password + randomPassword(PassChars2, RandomAdj);
		return Password;
	}

	/**
	 * randomPassword takes a string and returns a random 3-character string from
	 * the original 
	 * 
	 * @param sPassChars Original String
	 * @param RandomAdjuster Optional seed
	 * @return partial temporary password String
	 */
	private  String randomPassword(String sPassChars, int iRandomAdjuster) {

		String Password = "";

		int Seed = (int) (System.currentTimeMillis() % 20) + 1 + iRandomAdjuster;

		String PassChars = sPassChars;
		
		//SID#63970 : implement SecureRandom
		SecureRandom secRandom = new SecureRandom();
		//Random Rand = new Random();
		secRandom.setSeed(System.currentTimeMillis() * Seed);

		byte[] PassByte = new byte[3];
		secRandom.nextBytes(PassByte);

		for (int i = 0; i < PassByte.length; i++)
			Password += PassChars.charAt(PassByte[i] & 0x3f);

		return Password;
	}


	/**
	 * asHex converts byte array to Hex String
	 * 
	 * @param buf byte array
	 * @return hexadecimal String
	 */
	public  String asHex (byte buf[]) {
		StringBuilder strbuf = new StringBuilder(buf.length * 2);
	 
	 for (int i = 0; i < buf.length; i++) {
		if (((int) buf[i] & 0xff) < 0x10)
		strbuf.append("0");
		strbuf.append(Long.toString((int) buf[i] & 0xff, 16));
	 }
	 
	 return strbuf.toString();
	}

	/**
	 * hexToByteArray converts Hex String to byte array
	 * 
	 * @param hex hexadecimal String
	 * @return byte array
	 */
	public  byte[] hexToByteArray(String hex) {
		byte[] bts = new byte[hex.length() / 2];
		for (int i = 0; i < bts.length; i++) {
			bts[i] = (byte) Integer.parseInt(hex.substring(2*i, 2*i+2), 16);
		}
		return bts;
	}

	/**
	 * The generateAllPasswords method is part of the RILCheckAndEncryptPasswordHelper class.
	 * This method is used to generate all types of encrypted passwords (Crypt, MD5, SHA-1, AES256, DES3, and Generic) for a given clear text password.
	 * The method takes a HashMap as a parameter which contains the clear text password and other related information.
	 * The method uses various utility methods to generate the encrypted passwords.
	 * If the generation of all passwords is successful, the method returns a HashMap containing all the encrypted passwords.
	 * If the generation of any password fails, the method logs an error message and returns a HashMap containing the error details.
	 *
	 * @param inHs A HashMap containing the clear text password and other related information.
	 * @param logger A Logger instance for logging error or status messages.
	 * @return HashMap A HashMap containing all the encrypted passwords if generation is successful, or error details if generation fails.
	 */
	public  HashMap generateAllPasswords(HashMap inHs, Logger logger) {
		String thisMethod = "generateAllPasswords";
		HashMap statusTMS = null;
		
		String appInfo;
		String appStatusCode;
		
		String enc_password = null;
		String md5_password = null;
		String aes_password = null;
		String sha1_password = null;
		String salt = null;
		String sDes3_password = null;
		String gen_password = null;
		String gen_password_type = null; 
		
		boolean isError = true;
		String clearText = (String)inHs.get(MPSDefs.WS_CLEAR_TEXT);
		if (clearText == null || clearText.trim().length() <= 0) {
			appInfo = "Clear Text is empty.  Cannot encrypt passwords.";
			logger.info("RCEP-1e : "+ appInfo);
			//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
			statusTMS =	CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, appInfo);
			return statusTMS;
		}
		
		salt = (String) inHs.get(RILDefs.WS_SALT);
		
		try {
			//derive Crypt, MD5, SHA-1 and AES256 passwords and add them to the return hashmap
			RILCheckAndEncryptPasswordHelper rilPwdHelper = new RILCheckAndEncryptPasswordHelper();
			HashMap passEncryptHs = new HashMap();
			//add clear text and salt to input hash for encryption
			passEncryptHs.put(MPSDefs.WS_CLEAR_TEXT,clearText);
			if (salt != null && salt.trim().length() > 0) {
				passEncryptHs.put(RILDefs.WS_SALT,salt);
			}	
			
			// generate SSHA256 password
			if (gen_password_type != null && !gen_password_type.isEmpty()) {
				statusTMS = rilPwdHelper.generateGenericPassword(passEncryptHs, gen_password_type, logger);
				appStatusCode = (String) statusTMS.get(MPSDefs.APP_STATUS_CODE);
				if (appStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					if (statusTMS.containsKey(RILDefs.RIL_GEN_PASSWORD)) {
						gen_password = (String) statusTMS.get(RILDefs.RIL_GEN_PASSWORD);
					}
				} else {
					return statusTMS;
				}
			}
			
			//generate Crypt password
			statusTMS = rilPwdHelper.generateCryptPassword(passEncryptHs, logger);
			appStatusCode = (String)statusTMS.get(MPSDefs.APP_STATUS_CODE);
			if (appStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				if (statusTMS.containsKey(RILDefs.RIL_ENC_PASSWORD)) {
					enc_password = (String)statusTMS.get(RILDefs.RIL_ENC_PASSWORD);
				}
			} else {
				return statusTMS;
			}
				
			//generate MD5 password
			statusTMS = rilPwdHelper.generateMD5Password(passEncryptHs, logger);
			appStatusCode = (String)statusTMS.get(MPSDefs.APP_STATUS_CODE);
			if (appStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				if (statusTMS.containsKey(RILDefs.RIL_MD5_PASSWORD)) {
					md5_password = (String)statusTMS.get(RILDefs.RIL_MD5_PASSWORD);
				}
			} else {
				return statusTMS;
			}
	
			//generate SHA-1 password
			statusTMS = rilPwdHelper.generateSHA1Password(passEncryptHs, logger);
			appStatusCode = (String)statusTMS.get(MPSDefs.APP_STATUS_CODE);
			if (appStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				if (statusTMS.containsKey(RILDefs.RIL_SHA1_PASSWORD)) {
					sha1_password = (String)statusTMS.get(RILDefs.RIL_SHA1_PASSWORD);
				}
			} else {
				return statusTMS;
			}			
				
			//generate AES256 password
			statusTMS = rilPwdHelper.generateAES256Password(passEncryptHs, logger);
			appStatusCode = (String)statusTMS.get(MPSDefs.APP_STATUS_CODE);
			if (appStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				if (statusTMS.containsKey(RILDefs.RIL_AES_PASSWORD)) {
					aes_password = (String)statusTMS.get(RILDefs.RIL_AES_PASSWORD);
				}
			} else {
				return statusTMS;
			}
			
			//added for NAPII -- rp6341
			//generate DES3 password
			statusTMS = rilPwdHelper.generateDES3Password(passEncryptHs, logger);
			appStatusCode = (String)statusTMS.get(MPSDefs.APP_STATUS_CODE);
			if (appStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				if (statusTMS.containsKey(RILDefs.RIL_DES3_PASSWORD)) {
					sDes3_password = (String)statusTMS.get(RILDefs.RIL_DES3_PASSWORD);
				}
			} else {
				return statusTMS;
			}
			//done rp-6341
			
			isError = false;
		} catch (Exception e) {
				
			statusTMS = CommonErrorMap.makeExceptionMap(e, logger);
			
			return statusTMS;
	
		} finally {
			//add the encrypted passwords to the return HashMap
			if (!isError) {
				//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
				statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG);
				statusTMS.put(RILDefs.RIL_ENC_PASSWORD, enc_password);
				statusTMS.put(RILDefs.RIL_MD5_PASSWORD, md5_password);
				statusTMS.put(RILDefs.RIL_SHA1_PASSWORD, sha1_password);
				statusTMS.put(RILDefs.RIL_AES_PASSWORD, aes_password);
				statusTMS.put(RILDefs.RIL_DES3_PASSWORD, sDes3_password);
				if (gen_password != null && !gen_password.isEmpty()) {
					statusTMS.put(RILDefs.RIL_GEN_PASSWORD, gen_password);
					statusTMS.put(RILDefs.RIL_GEN_PASSWORD_TYPE, gen_password_type);
				}
			}
			logger.info("checkAndEncryptPasswordHelper::STATUS::" + StringUtils.normalizeSpace(statusTMS.toString()));
		}
		return statusTMS;
	}
	
	
	/**
	 * generateTempPasswordDigitsOnly returns a 6 character	
	 * random string password with random numbers (0-9)
	 * */
	/*
	 * public String generateTempPasswordDigitsOnly(){ //to generate tempPassword in
	 * digits only String PassChars =
	 * "0536094128157992341578346501326578034128976340809563278645124897"; String
	 * Password = ""; int RandomAdj = 0;
	 * 
	 * int Seed = (int) (System.currentTimeMillis() % 20) + 1 + RandomAdj;
	 * 
	 * //SID#63970 : implement SecureRandom SecureRandom secRandom = new
	 * SecureRandom(); //Random Rand = new Random(); //
	 * secRandom.setSeed(System.currentTimeMillis() *Seed);
	 * 
	 * byte[] PassByte = new byte[6]; secRandom.nextBytes(PassByte);
	 * 
	 * for(int i=0;i<PassByte.length;i++) Password +=PassChars.charAt(PassByte[i] &
	 * 0x3f);
	 * 
	 * return Password;
	 * 
	 * }
	 */
	
	/**
	 * 
	 * @return String Password
	 */
	//R1911 - Updated for SID#2019700014 to update TEMP Pwd Generation Algorithm as per SecurityCode_H (Accenture Finding)
	public static String generateTempPasswordDigitsOnly(){
		
		String PassChars = "0123456789";
		StringBuilder buf = new StringBuilder();

		int strLength = PassChars.length();

		char c = 0;
		SecureRandom secRandom = new SecureRandom();
		int randNum = 0;
		
		int iPwdLength = 6;

		for (int i = 0; i < iPwdLength; i++) {
			randNum= secRandom.nextInt(strLength);			
			c = (char) PassChars.charAt(randNum);
			buf.append(c);
		}
		return buf.toString();		
	}
	
	/**
	 * The generateDES3Password method is part of the RILCheckAndEncryptPasswordHelper class.
	 * This method is used to generate a DES3 encrypted password from a clear text password.
	 * The method takes a HashMap as a parameter which contains the clear text password.
	 * The method uses the Cipher class from the javax.crypto package to perform the encryption.
	 * If the encryption is successful, the method returns a HashMap containing the DES3 encrypted password.
	 * If the encryption fails, the method logs an error message and returns a HashMap containing the error details.
	 *
	 * @param hmInput A HashMap containing the clear text password.
	 * @param logger A Logger instance for logging error or status messages.
	 * @return HashMap A HashMap containing the DES3 encrypted password if encryption is successful, or error details if encryption fails.
	 */
	public HashMap generateDES3Password(HashMap hmInput, Logger logger) 
	{
		
		String thisMethod = "generateDES3Password";
		Cipher oCipher;
		String sBase64EncodedEncMD5Password = null;
		HashMap hmResponse = null;
		String sAppInfo = null;
		String sAppStatusCode = null;
		String sConfigSharedKey = null;
		MessageDigest   oMessageDigest = null;
		
		try 
		{
		
			String sStringToEncrypt = (String)hmInput.get(MPSDefs.WS_CLEAR_TEXT);
			
			if (sConfigSharedKey == null || sConfigSharedKey.length() == 0)
			{
				sConfigSharedKey = PropertyManager.getProperty(CommonDefs.MOUPSECRETConfig, RILDefs.PROP_BLS_ENC_MD5_KEY);
				
				sConfigSharedKey = CommonUtil.getAESDecryption(sConfigSharedKey);
			}
			
			//Something's wrong if ConfigKeys are still null or empty			
			if (sConfigSharedKey == null || sConfigSharedKey.length() == 0) 
			{
				sAppInfo = "Key "+RILDefs.PROP_BLS_ENC_MD5_KEY+" is null or empty.";
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, sAppInfo);
				logger.error("GENDES_2 : "+ sAppInfo);
				return hmResponse;				
			}
			
			oMessageDigest = MessageDigest.getInstance( RILDefs.RIL_MD5 );
			oMessageDigest.update( ( byte ) new Date().getTime() );
			
			String sEntropy = "";
			oMessageDigest.update(sEntropy.getBytes());
			
			
			//now use the digest to generate our salt
	        byte[]  salt = oMessageDigest.digest();
	        
	        //now do some freaky calculation to calculate how long the encrypted data will be
	        int cryptLength = sStringToEncrypt.length() + 1;
	        cryptLength = ( cryptLength + 15 ) & ( ~15 );
	        
	        //build an array to store the encrypted data
	        byte[]  encryptedBytes = new byte[cryptLength];

	        //and store the length of the encrypted data as the first byte
	        encryptedBytes[0] = ( byte ) sStringToEncrypt.length();

	        //copy each byte from the string to the byte array
	        for ( int i = 0; i < sStringToEncrypt.length(); i++ )
	        {
	            encryptedBytes[i + 1] = ( byte ) sStringToEncrypt.charAt( i );
	        }
			
	        oMessageDigest.update( sConfigSharedKey.getBytes() );
	        oMessageDigest.update( salt );
	        byte[]  digest = oMessageDigest.digest();

	        int     j = 0;
	        int     count = 0;

	        //while there is more than 16 bytes left to encrypt,
	        for ( ; cryptLength > 16; cryptLength -= 16, count++ )
	        {
	            //loop through 16 bytes at a time and encrypt it (XOR it)
	            for ( int i = 0; i < 16; i++, j++ )
	            {
	                encryptedBytes[j] = ( byte ) ( ( int ) encryptedBytes[j] ^ ( int ) digest[i] );
	            }

	            //now generate a new digest based on the secret & what we just encrypted
	            oMessageDigest.update( sConfigSharedKey.getBytes() );
	            oMessageDigest.update( encryptedBytes, 16 * count, 16 );
	            
	            //md.update( encryptedBytes, 16 << count, 16 );
	            digest = oMessageDigest.digest();
	        }

	        //loop through the last bytes(up to 16) and encrypt it (XOR it)
	        for ( int i = 0; i < cryptLength; i++, j++ )
	        {
	            encryptedBytes[j] = ( byte ) ( ( int ) encryptedBytes[j]
	                                           ^ ( int ) digest[i] );
	        }

	        //instantiate a BASE64Encoder to encode the encrypted data into
	        //string format so it can easily be stored and passed around.
	        String          encodedSalt = CommonUtil.base64Encode(salt);
	        String          encodedCrypto = CommonUtil.base64Encode(encryptedBytes);
	        
	        String sEncryptedPassword = RILDefs.ENCRYPTION_FORMAT + "1" + "," + encodedSalt + "," + encodedCrypto;
	        
			// If sBase64EncodedDES3Password value is not null and not empty then create a success hash
			// and add sBase64EncodedDES3Password in the hmResponse hash with  "des3_password" key. 
			hmResponse =
				CommonErrorMap.makeCategoryMap(
						CErrorDefs.COMMON_SUCCESS_NUM,
						CErrorDefs.COMMON_SUCCESS_MSG);
		
			hmResponse.put(RILDefs.RIL_DES3_PASSWORD, sEncryptedPassword);
			logger.info("GENDES_5 : "+ "hmResponse::" + hmResponse);
		
			return hmResponse;
		} 
		catch (Exception excp) 
		{

			sAppInfo = "Exception ::" + excp.getMessage();
			hmResponse = CommonErrorMap.makeExceptionMap(excp, logger);
			logger.error("GENDES_6 : ", sAppInfo);
			return hmResponse;
		}
	}
	
	
	/**
	 * The getClearTextFromDES3 method is part of the RILCheckAndEncryptPasswordHelper class.
	 * This method is used to decrypt a DES3 encrypted password back to clear text.
	 * The method takes a HashMap as a parameter which contains the DES3 encrypted password.
	 * The method uses the SecretKeySpec and Cipher classes from the javax.crypto package to perform the decryption.
	 * If the decryption is successful, the method returns a HashMap containing the clear text password.
	 * If the decryption fails, the method logs an error message and returns a HashMap containing the error details.
	 *
	 * @param hmInput A HashMap containing the DES3 encrypted password.
	 * @param logger A Logger instance for logging error or status messages.
	 * @return HashMap A HashMap containing the clear text password if decryption is successful, or error details if decryption fails.
	 */
	public HashMap getClearTextFromDES3(HashMap hmInput, Logger logger) 
	{
		String thisMethod = "getClearTextFromDES3";
		String sClearPassword = "";
		String skey;
		String sDes3Password;
		String sAppInfo;
		HashMap resultHashMap = new HashMap();
		String sConfigSharedKey = null;
		HashMap hmResponse;
				
		try 
		{
			//check that encrypted password exists
			if (!hmInput.containsKey(RILDefs.RIL_DES3_PASSWORD)) 
			{
				sAppInfo = "DES3 Password field is null";
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, sAppInfo);
				return hmResponse;
			}
			
			sDes3Password = (String)hmInput.get(RILDefs.RIL_DES3_PASSWORD);
			
			//tokenize the encrypted string to break up the header({enc-md5}#(spi), salt & data
	        StringTokenizer stDes3Password = new StringTokenizer( sDes3Password, "," );

	        String sHeader = stDes3Password.nextToken();
	        String sEncodedSalt = stDes3Password.nextToken();
	        String sEncodedPassword = stDes3Password.nextToken();
	        
			//BLS_ENC_MD5_KEY
			if (sConfigSharedKey == null || sConfigSharedKey.length() == 0)
			{
				sConfigSharedKey = PropertyManager.getProperty(CommonDefs.MOUPSECRETConfig, RILDefs.PROP_BLS_ENC_MD5_KEY);
				
				sConfigSharedKey = CommonUtil.getAESDecryption(sConfigSharedKey);
			}
			
			//Something's wrong if ConfigKeys are still null or empty			
			if (sConfigSharedKey == null || sConfigSharedKey.length() == 0) 
			{
				sAppInfo = "Key "+RILDefs.PROP_BLS_ENC_MD5_KEY+" is null or empty.";
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, sAppInfo);
				logger.error("GENDES_2"+ sAppInfo);
				return hmResponse;				
			}
	        
	        byte[]          byteDecodedSalt = null;
	        byte[]          byteDecodedCrypto = null;
	        
	        byteDecodedSalt = CommonUtil.base64Decode(sEncodedSalt);
	        byteDecodedCrypto = CommonUtil.base64Decode(sEncodedPassword);
	        
	        //generate a digest from the secret and the salt we were given
	        MessageDigest   oMessageDigest = null;
	        oMessageDigest = MessageDigest.getInstance( RILDefs.RIL_MD5 );
	        
	        oMessageDigest.update( sConfigSharedKey.getBytes() );
	        oMessageDigest.update( byteDecodedSalt );
	        byte[] byteDigest = oMessageDigest.digest();

	        int iCryptLength = byteDecodedCrypto.length;

	        int j = 0;
	        int count = 0;
	        
	        //for each block of bytes greater than 16 bytes
	        for ( ; iCryptLength > 16; iCryptLength -= 16, count++ )
	        {
	            //store the data to generate the next digest
	        	oMessageDigest.update( sConfigSharedKey.getBytes() );
	        	oMessageDigest.update( byteDecodedCrypto, 16 * count, 16 );

	            //decrypt this block (XOR it with the current digest
	            for ( int i = 0; i < 16; i++, j++ )
	            {
	            	byteDecodedCrypto[j] = ( byte ) ( ( int ) byteDecodedCrypto[j]
	                                              ^ ( int ) byteDigest[i] );
	            }

	            //create the next digest for the next block
	            byteDigest = oMessageDigest.digest();
	        }

	        //decrypt the last block of up to 16 bytes
	        for ( int i = 0; i < iCryptLength; i++, j++ )
	        {
	        	byteDecodedCrypto[j] = ( byte ) ( ( int ) byteDecodedCrypto[j] ^ ( int ) byteDigest[i] );
	        }

	        //retrieve the length that was stored with the data
	        int len = (int)byteDecodedCrypto[0];

	        //and use the lenght to create a string from the decrypted byte array
	        //String  decryptedData = new String( decodedCrypto, 1, len );

	        sClearPassword = new String( byteDecodedCrypto, 1, len );
	    } 
		catch (Exception e) 
		{
			hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
								
			return hmResponse;			
		}
		
		//Change by pm675e:SID#2021700159 Replacing RILErrorMap with CommonErrorMap
		hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG);
		hmResponse.put(MPSDefs.WS_CLEAR_TEXT, sClearPassword);
		//do not log status as it contains clear text password.			
		return hmResponse;		
	}
	
	/**
	 * The generateACAPassword method is part of the RILCheckAndEncryptPasswordHelper class.
	 * This method is used to generate an ACA password using the SHA-1 encryption algorithm.
	 * The method takes a HashMap as a parameter which contains the salt and clear text password.
	 * The method uses the MessageDigest class from the java.security package to perform the encryption.
	 * If the encryption is successful, the method returns a HashMap containing the ACA password.
	 * If the encryption fails, the method logs an error message and returns a HashMap containing the error details.
	 *
	 * @param inputHash A HashMap containing the salt and clear text password.
	 * @param logger A Logger instance for logging error or status messages.
	 * @return HashMap A HashMap containing the ACA password if encryption is successful, or error details if encryption fails.
	 */
	public  HashMap generateACAPassword (HashMap inputHash, Logger logger) {
		final String thisMethod = "generateACAPassword"; 
		
		String sMD5Password = null;
		String sHandle = null;
		String sDomain = null;
		String sSharedSecret = null;
		String sGeneratedSalt = null;
		String sGeneratedPassword = null;
		
		String sAppStatusCode = null;
		String sAppInfo = null;
		HashMap hmResult = null;
		
		//logger.info("GACAPWD.1 : "+ "CVS Info: " + info);
		
		try {
			//1a. Input Hash NULL / EMPTY Check.
			if (inputHash == null || inputHash.isEmpty()) {
				sAppInfo = "Input HashMap is NULL / Empty.";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, sAppInfo);
				logger.error("GACAPWD.2 : "+ sAppInfo);
				return hmResult;
			}
		
			//1b. Retrieve md5Password, handle and domain from inputHash
			sMD5Password = (String) inputHash.get(CommonDefs.MD5_PASSWORD);
			sHandle = (String) inputHash.get(CommonDefs.HANDLE);
			sDomain = (String) inputHash.get(CommonDefs.DOMAIN);
		
			//2a. If any one of above not present, return ERR_EMPTY_NUM
			if (sMD5Password == null || sMD5Password.trim().length() < 1
					|| sHandle == null || sHandle.trim().length() < 1
					|| sDomain == null || sDomain.trim().length() < 1) {
				sAppInfo = "One or More of Required Fields - Handle/Domain/MD5-Password - Are Missing.";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, sAppInfo);
				logger.error("GACAPWD.3 : "+ sAppInfo);
				return hmResult;
			}
			//1906: in support of new user password creation rules.
			//2b. If input MD5-Password has length < 6 characters, return ERR_INVALID_DATA.
			String minClearLengthString = PropertyManager.getProperty(CommonDefs.MOUPConfig, CommonDefs.MIN_CLEAR_PASSWD_LENGTH_KEY);
			int minClearLength = 0;
			if (minClearLengthString != null && minClearLengthString.trim().length() != 0) {
				minClearLength = Integer.parseInt(minClearLengthString);
			}
			if (sMD5Password.trim().length() < minClearLength) {
				sAppInfo = "Invalid MD5-Password - Too Short (Less Than "+minClearLength+" Characters).";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
				logger.error("GACAPWD.4 : "+ sAppInfo);
				return hmResult;
			}
		
			sSharedSecret = PropertyManager.getProperty(CommonDefs.MOUPConfig, CommonDefs.PROP_ACA_SHARED_SECRET);
			if (sSharedSecret == null || sSharedSecret.trim().length() < 1) {
				sAppInfo = CommonDefs.PROP_ACA_SHARED_SECRET + " - is Missing in Config File.";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, sAppInfo);
				logger.error("GACAPWD.6 : "+ sAppInfo);
				return hmResult;
			}
		
			//5. Generate salt using md5Password and sSharedSecret as:
			//		salt  = md5Pwd.substring(5,md5Pwd.length() - 1) + sSharedSecret
			sGeneratedSalt = sMD5Password.substring(5, sMD5Password.length() - 1) + sSharedSecret;
		
			//6. Generate password as: password = handle@domain
			sGeneratedPassword = sHandle + "@" + sDomain;
		
			//7. Create a map hmInput, Add salt and password with keys wsSalt and wsClearText respectively.
			HashMap hmInput = new HashMap();
			hmInput.put(CommonDefs.WS_SALT, sGeneratedSalt);
			hmInput.put(CommonDefs.WS_CLEAR_TEXT, sGeneratedPassword);
		
			//8. Make a call to generateACAPwd() method.
			hmResult = generateACAPwd(hmInput, logger);
		
			if (hmResult == null || hmResult.isEmpty()) {
				sAppInfo = "Invalid Response from ACA Password Generator Method.";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
			}
			sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
			if (sAppStatusCode == null || !sAppStatusCode.equalsIgnoreCase(CErrorDefs.COMMON_SUCCESS)) {
				sAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
				logger.error("GACAPWD.7 : "+ 
						"Error Encountered In Generation of ACA Password: " + sAppInfo);
			}
			
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			sAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
			logger.error("GACAPWD.8 : "+ "Exception: " + sAppInfo);
			
		}
		logger.info("GAPAPWD.10 : "+  " HLP : "+ hmResult);
		return hmResult;
	}
	
	/**
	 * The generateACAPwd method is part of the RILCheckAndEncryptPasswordHelper class.
	 * This method is used to generate an ACA password using the SHA-1 encryption algorithm.
	 * The method takes a HashMap as a parameter which contains the salt and clear text password.
	 * The method uses the MessageDigest class from the java.security package to perform the encryption.
	 * If the encryption is successful, the method returns a HashMap containing the ACA password.
	 * If the encryption fails, the method logs an error message and returns a HashMap containing the error details.
	 *
	 * @param inputHash A HashMap containing the salt and clear text password.
	 * @param logger A Logger instance for logging error or status messages.
	 * @return HashMap A HashMap containing the ACA password if encryption is successful, or error details if encryption fails.
	 */
	public  HashMap generateACAPwd(HashMap inputHash, Logger logger) {
		final String thisMethod = "generateACAPwd";
		String sSalt = null;
		String sClearPassword = null;
		
		String sAppStatusCode = null;
		String sAppInfo = null;
		HashMap hmResult = null;
		String sGeneratedACAPassword = null;
		
		//1a. Input Hash NULL / EMPTY Check.
		if (inputHash == null || inputHash.isEmpty()) {
			sAppInfo = "Input HashMap is NULL / Empty.";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, sAppInfo);
			logger.error("GAP.1 : "+ sAppInfo);
			return hmResult;
		}
		
		//1b. Retrieve wsSalt and wsClearText from inputHash.
		sSalt = (String) inputHash.get(CommonDefs.WS_SALT);
		sClearPassword = (String) inputHash.get(CommonDefs.WS_CLEAR_TEXT);
		
		//2. If any one of above not present, return ERR_EMPTY_NUM.
		if (sSalt == null || sSalt.trim().length() < 1
				|| sClearPassword == null || sClearPassword.trim().length() < 1) {
			sAppInfo = "Either of Required Fields - Salt/ClearText-Password - is Missing.";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, sAppInfo);
			logger.error("GAP.2 : "+ sAppInfo);
			return hmResult;
		}
		
		try {
			//3. Create an instance of MessageDigest md for "SHA-1".
			MessageDigest md = MessageDigest.getInstance(CommonDefs.ENCRYPT_SHA1);
			md.reset();
			
			//4. Update the Instance of MessageDigest with Bytes of Salt.
			md.update(sSalt.getBytes());
			
			//5. Generate digestBytes from Instance of MessageDigest with ClearText.
			byte[] digestBytes = md.digest(sClearPassword.getBytes());
					
			//6. Encode digestBytes into Base64 and store as ACAPassword.
			sGeneratedACAPassword = CommonUtil.base64Encode(digestBytes);
			
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			sAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
			
			logger.error("GAP.3 : "+ "Exception: " + sAppInfo);
			
			
			return hmResult;
		}
		
		//7. Create a success ResultMap and Store ACAPassword in it.
		sAppInfo = "ACA Password Generated Successfully.";
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, sAppInfo);
		hmResult.put(CommonDefs.ACA_PASSWORD, sGeneratedACAPassword);
				
		return hmResult;
	}
	
}
