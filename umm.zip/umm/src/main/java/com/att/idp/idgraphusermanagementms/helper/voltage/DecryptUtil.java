package com.att.idp.idgraphusermanagementms.helper.voltage;



import com.voltage.securedata.enterprise.VeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.idp.core.exception.ServiceException;
import com.att.idp.idgraphusermanagementms.message.ErrorMessages;
import com.att.idp.voltage.common.VoltageEfpeFormatType;
import com.att.idp.voltage.decrypt.api.DecryptorVoltageHelper;
import com.att.idp.voltage.decrypt.api.VoltageDecryptorAutoConfiguration;

/**
 * This class, DecryptUtil, is a utility class for handling decryption operations.
 * It is annotated with @Component, indicating that it is a Spring Bean and can be autowired where needed.
 * It contains a static instance of DecryptorVoltageHelper, which is used for decryption operations.
 * The DecryptUtil class has a constructor that takes a VoltageDecryptorAutoConfiguration object as a parameter.
 * This constructor initializes the DecryptorVoltageHelper instance.
 * The class also contains a method, getDecryptedValue, which takes a value and a format name as parameters.
 * This method uses the DecryptorVoltageHelper instance to decrypt the value and returns the decrypted value.
 * If an exception occurs during decryption, it logs the error and throws a ServiceException.
 */
@Component
public class DecryptUtil {



	private static final Logger log = LoggerFactory.getLogger(DecryptUtil.class);

	private static DecryptorVoltageHelper volHelper=null;

	/**
	 * This is the constructor for the DecryptUtil class.
	 * It takes a VoltageDecryptorAutoConfiguration object as a parameter, which is autowired by Spring.
	 * The constructor initializes the static instance of DecryptorVoltageHelper, which is used for decryption operations.
	 * The DecryptorVoltageHelper instance is initialized using the getInstanceForDefaultIdentity method.
	 *
	 * @param pVDAC VoltageDecryptorAutoConfiguration object used to configure the DecryptorVoltageHelper instance.
	 */
	public DecryptUtil(@Autowired VoltageDecryptorAutoConfiguration pVDAC) throws VeException {
		volHelper = DecryptorVoltageHelper.getInstanceForDefaultIdentity();

}

	/**
	 * This method is used to decrypt a given value.
	 * It takes two parameters: the value to be decrypted and the format name.
	 * The value is a string that represents the encrypted data.
	 * The format name is a string that represents the format type of the encrypted data.
	 * The method uses the DecryptorVoltageHelper instance to decrypt the value.
	 * If the decryption is successful, it returns the decrypted value as a string.
	 * If an exception occurs during the decryption process, it logs the error and throws a ServiceException.
	 *
	 * @param value The encrypted value to be decrypted.
	 * @param formatName The format type of the encrypted value.
	 * @return The decrypted value.
	 * @throws ServiceException If an error occurs during the decryption process.
	 */
public  String getDecryptedValue(String value, String formatName) {
	try {

		return volHelper.decrypt(value, VoltageEfpeFormatType.valueOf(formatName));

		} catch(Exception e) {
			log.error("Error while getting voltage resource", e);
			throw new ServiceException(ErrorMessages.ERROR_VOLTAGE_RESOURCE);
		}

	}
}
