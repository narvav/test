package com.att.idp.idgraphusermanagementms.queue.message.helpers;

import com.att.idp.idgraphusermanagementms.queue.message.sender.JMSQueueSender;
import com.att.idp.idgraphusermanagementms.resource.request.RemoveEmailAliasRequest;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.*;
import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class RemoveEmailAliasQueueHelper {

    public static final Logger log = LoggerFactory.getLogger(RemoveEmailAliasQueueHelper.class);

    @Autowired
    private JMSQueueSender oJMSQueueSender;

    private static final String ERROR_ENUM = "ErrorEnum";
    private String sClassName = "RemoveEmailAliasQueueHelper";

    /**
     * Sends a message to the message queue to process the removal of email aliases for a user.
     * Validates the response from the queue sender and returns the result.
     * @param removeEmailAliasRequest the request object containing details for removing the email alias
     * @param alEventData the event data to be sent to the queue
     * @param stDBMemberNum the member number from the database
     * @return a map containing the result of the queue operation or error details if the request fails
     */
    public Map<String, Object> sendMessageToMQ(RemoveEmailAliasRequest removeEmailAliasRequest, List<Object> alEventData, String stDBMemberNum) {
        String sMethodName = ".sendMessageToMQ.";
        String stAppInfo;
        String stAppStatusCode = null;
        HashMap<String, Object> hmResult;
        String idpTraceid = removeEmailAliasRequest.getIdpTraceId() != null ? removeEmailAliasRequest.getIdpTraceId().split(":")[0] : null;

        HashMap<String, Object> hmDbusInput = CommonUtil.getHashMap();
        hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, stDBMemberNum);

        hmDbusInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
        hmDbusInput.put(CommonDefs.TRANSACTION_ID,
                (idpTraceid != null && idpTraceid.contains(":")) ? idpTraceid.split(":")[0] : idpTraceid);
        hmDbusInput.put(CommonDefs.TRANSACTION_NAME, removeEmailAliasRequest.getTransactionName());
        hmDbusInput.put(CommonDefs.CALLING_SYSTEM_ID, removeEmailAliasRequest.getCallingSystemId());
        hmDbusInput.put(CommonDefs.EVENTNAME, CommonDefs.MICRO_SERVICE_EVENT);
        hmDbusInput.put(CommonDefs.MS_OPERTAION, removeEmailAliasRequest.getTransactionName());
        hmDbusInput.put(CommonDefs.EVENTS_DATA, alEventData);

        log.info(SpiMarker.getInstance(),
                "RemoveEmailAliasQueueHelper.sendMessageToMQ.REAQH_01 : Calling JMSQueueSender with inputHash : {}", hmDbusInput);

        hmResult = (HashMap) oJMSQueueSender.send(hmDbusInput);

        log.info("{}{}REAQH_02 : ResponseHash from JMSQueueSender : {}", sClassName, sMethodName,
                hmResult);

        if (MapUtils.isEmpty(hmResult)) {
            stAppInfo = "Null Response returned from JMSQueueSender.send";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
            log.info("{}{}REAQH_03 : {}", sClassName, sMethodName, stAppInfo);
            return hmResult;
        }

        stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

        if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {

            stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
            log.info("{}{}REAQH_04 : {}", sClassName, sMethodName, stAppInfo);
            hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
            return hmResult;
        } else {
            hmResult.put("isTransactionRollback", true);
        }

        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
        hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
        return hmResult;

    }

    /**
     * Prepares the input data for the message queue when removing email aliases.
     * Builds the event data for UpdateMemberList and NotificationEvent if needed.
     * @param removeEmailAliasRequest the request object containing details for removing the email alias
     * @param alRemoveEmailAlias list of email alias maps to remove
     * @param memberInfoHash map containing member information and existing email aliases
     * @return a list of objects representing the event data for the queue
     */
    public static List<Object> prepareDbusInputHash(RemoveEmailAliasRequest removeEmailAliasRequest, List<Map<String, Object>> alRemoveEmailAlias, Map<String, Object> memberInfoHash) {
        List<Object> alDbusInput = new ArrayList<>();
        //create dbus input for event UpdateMemberList
        HashMap<String, Object> dbusInputHash = buildDbusInputHash(removeEmailAliasRequest, memberInfoHash);
        HashMap<String, Object> dbusMemberInfoHash = buildDbusMemberInfoHash(removeEmailAliasRequest);
        addPortalProviderInfo(dbusMemberInfoHash, memberInfoHash);
        ArrayList<String> alRemoveAliasList = buildRemoveEmailAliasesList(alRemoveEmailAlias);
        dbusMemberInfoHash.put("removeEmailAliases", alRemoveAliasList);
        ArrayList<Object> alDbusMemberInfo = new ArrayList<>();
        alDbusMemberInfo.add(dbusMemberInfoHash);
        dbusInputHash.put(CommonDefs.MEMBER_INFO, alDbusMemberInfo);
        alDbusInput.add(dbusInputHash);
        //create dbus input for event NotificationEvent
        if (shouldAddNotificationEvent(memberInfoHash)) {
            Map<String, Object> hmDbusNotificationInput = buildDbusNotificationInput(dbusInputHash,
                    memberInfoHash, alRemoveAliasList);
            alDbusInput.add(hmDbusNotificationInput);
        }
        return alDbusInput;
    }

    /**
     * Builds the input hash for the message queue event for removing email aliases.
     * @param req the request object containing details for removing the email alias
     * @param memberInfoHash map containing member information and existing email aliases
     * @return a hash map representing the input for the queue event
     */
    private static HashMap<String, Object> buildDbusInputHash(RemoveEmailAliasRequest req, Map<String, Object> memberInfoHash) {
        HashMap<String, Object> dbusInputHash = new HashMap<>();
        String idpTraceid = req.getIdpTraceId() != null ? req.getIdpTraceId().split(":")[0] : null;
        dbusInputHash.put(CommonDefs.CALLING_SYSTEM_ID, req.getCallingSystemId());
        dbusInputHash.put(CommonDefs.ORIG_TRANSACTION_NAME, req.getTransactionName());
        dbusInputHash.put(CommonDefs.TRANSACTION_NAME, req.getTransactionName());
        dbusInputHash.put(CommonDefs.TRANSACTION_ID, idpTraceid);
        dbusInputHash.put(CommonDefs.HANDLE, req.getMemberId());
        dbusInputHash.put(CommonDefs.DOMAIN, req.getDomain());
        dbusInputHash.put(CommonDefs.PARENT_HANDLE, memberInfoHash.get(MPSDefs.DB_PARENT_NAME));
        dbusInputHash.put(CommonDefs.PARENT_DOMAIN, memberInfoHash.get(MPSDefs.DB_PARENT_DOMAIN));
        dbusInputHash.put(CommonDefs.MIGRATION_IND, memberInfoHash.get(MPSDefs.DB_MIGRATION_IND));
        dbusInputHash.put(CommonDefs.EVENTNAME, "UpdateMemberList");
        dbusInputHash.put(CommonDefs.SUBEVENT, "UpdateEmailAlias");
        dbusInputHash.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
        return dbusInputHash;
    }

    /**
     * Builds the member info hash for the message queue event.
     * @param req the request object containing details for removing the email alias
     * @return a hash map representing the member info for the queue event
     */
    private static HashMap<String, Object> buildDbusMemberInfoHash(RemoveEmailAliasRequest req) {
        HashMap<String, Object> dbusMemberInfoHash = new HashMap<>();
        dbusMemberInfoHash.put(CommonDefs.HANDLE, req.getMemberId());
        dbusMemberInfoHash.put(CommonDefs.DOMAIN, req.getDomain());
        return dbusMemberInfoHash;
    }

    /**
     * Adds portal provider information to the member info hash for the queue event.
     * @param dbusMemberInfoHash the member info hash to update
     * @param memberInfoHash map containing member information and existing email aliases
     */
    private static void addPortalProviderInfo(HashMap<String, Object> dbusMemberInfoHash, Map<String, Object> memberInfoHash) {
        Map<String, Object> servicesHash = (Map<String, Object>) memberInfoHash.get(CommonDefs.SERVICES);
        if (servicesHash != null) {
            Map<String, Object> portalServiceHash = (Map<String, Object>) servicesHash.get(MPSDefs.PORTAL_SERVICE);
            if (portalServiceHash != null) {
                String portalProvider = (String) portalServiceHash.get(MPSDefs.DB_PORTAL_PROVIDER);
                if (portalProvider != null) {
                    dbusMemberInfoHash.put(CommonDefs.PORTAL_PROVIDER, portalProvider);
                }
            }
        }
    }

    /**
     * Builds a list of email aliases to be removed for the queue event.
     * @param alRemoveEmailAlias list of email alias maps to remove
     * @return a list of strings representing the email aliases to be removed
     */
    private static ArrayList<String> buildRemoveEmailAliasesList(List<Map<String, Object>> alRemoveEmailAlias) {
        ArrayList<String> alRemoveAliasList = new ArrayList<>();
        if (alRemoveEmailAlias != null) {
            for (Map<String, Object> hmTempEmailAlias : alRemoveEmailAlias) {
                if (hmTempEmailAlias != null && !hmTempEmailAlias.isEmpty()
                        && hmTempEmailAlias.containsKey("email_aliasId")
                        && hmTempEmailAlias.containsKey("email_aliasDomain")) {
                    String stEmailAlias = hmTempEmailAlias.get("email_aliasId") + "@" + hmTempEmailAlias.get("email_aliasDomain");
                    alRemoveAliasList.add(stEmailAlias);
                }
            }
        }
        return alRemoveAliasList;
    }

    /**
     * Checks if a notification event should be added to the queue event data based on member information.
     * @param memberInfoHash map containing member information and existing email aliases
     * @return true if a notification event should be added, false otherwise
     */
    private static boolean shouldAddNotificationEvent(Map<String, Object> memberInfoHash) {
        return memberInfoHash != null
                && (memberInfoHash.get(CommonDefs.SOR_NAME) != null)
                && ((String) (memberInfoHash.get(CommonDefs.SOR_NAME))).equals(MPSDefs.SOR_LS);
    }

    /**
     * Builds the input for the notification event for the message queue.
     * @param dbusInputHash the input hash for the main event
     * @param memberInfoHash map containing member information and existing email aliases
     * @param alRemoveAliasList list of email aliases to be removed
     * @return a map representing the input for the notification event
     */
    private static Map<String, Object> buildDbusNotificationInput(Map<String, Object> dbusInputHash, Map<String, Object> memberInfoHash, ArrayList<String> alRemoveAliasList) {
        String sDbusNotificationEvent = CommonDefs.PROP_EDD_NOTIFICATION_EVENT;
        String dbusNotificationDictName = CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE;
        Map<String, Object> hmDbusNotificationInput = CommonUtil.getHashMap();
        hmDbusNotificationInput.put(CommonDefs.EVENTNAME, sDbusNotificationEvent);
        hmDbusNotificationInput.put(CommonDefs.DBUS_DICTIONARY_NAME, dbusNotificationDictName);
        hmDbusNotificationInput.put(CommonDefs.HANDLE, (String) dbusInputHash.get(CommonDefs.HANDLE));
        hmDbusNotificationInput.put(CommonDefs.DOMAIN, (String) dbusInputHash.get(CommonDefs.DOMAIN));
        hmDbusNotificationInput.put(CommonDefs.TRANSACTION_NAME, (String) dbusInputHash.get(CommonDefs.TRANSACTION_NAME));
        hmDbusNotificationInput.put(CommonDefs.TRANSACTION_ID, (String) dbusInputHash.get(CommonDefs.TRANSACTION_ID));
        hmDbusNotificationInput.put(CommonDefs.CALLING_SYSTEM_ID, (String) dbusInputHash.get(CommonDefs.CALLING_SYSTEM_ID));
        hmDbusNotificationInput.put(CommonDefs.FIRST_NAME, (String) memberInfoHash.get(MPSDefs.DB_LC_FIRSTNAME));
        hmDbusNotificationInput.put(CommonDefs.SOR_NAME, (String) memberInfoHash.get(CommonDefs.SOR_NAME));
        hmDbusNotificationInput.put(CommonDefs.LAST_NAME,  memberInfoHash.get(MPSDefs.DB_LC_LASTNAME));
        hmDbusNotificationInput.put(CommonDefs.BAN, (String) memberInfoHash.get(CommonDefs.BAN));
        hmDbusNotificationInput.put(CommonDefs.MEMBER_STATUS, MPSDefs.ENABLED);
        hmDbusNotificationInput.put(MPSDefs.DB_PARENT_CHILD_IND, (String) memberInfoHash.get(MPSDefs.DB_PARENT_CHILD_IND));
        hmDbusNotificationInput.put(CommonDefs.CONTACT_EMAIL, memberInfoHash.get(MPSDefs.DB_CONTACT_EMAIL));
        hmDbusNotificationInput.put(CommonDefs.BROWSER_LANGUAGE,  memberInfoHash.get(MPSDefs.DB_BROWSER_LANGUAGE));
        hmDbusNotificationInput.put(CommonDefs.PARENT_HANDLE, dbusInputHash.get(CommonDefs.PARENT_HANDLE));
        hmDbusNotificationInput.put(CommonDefs.PARENT_DOMAIN, (String) dbusInputHash.get(CommonDefs.PARENT_DOMAIN));

        HashMap<String,Object> hmMemberServices = (HashMap) memberInfoHash.get(CommonDefs.SERVICES);
        if (hmMemberServices != null && !hmMemberServices.isEmpty()) {
            List<Map<String, Object>> alNewServices = buildNewServicesList(hmMemberServices);
            if (!alNewServices.isEmpty()) {
                hmDbusNotificationInput.put(CommonDefs.SERVICES, alNewServices);
            }
            hmDbusNotificationInput.put("removeEmailAliases", alRemoveAliasList);
        }
        return hmDbusNotificationInput;
    }

    /**
     * Builds a list of new services for the notification event based on member services information.
     * @param hmMemberServices map containing member services information
     * @return a list of maps representing the new services
     */
    private static List<Map<String, Object>> buildNewServicesList(HashMap<String, Object> hmMemberServices) {
        List<Map<String, Object>> alNewServices = new ArrayList<>();
        for (Object key : hmMemberServices.keySet()) {
            String sServiceKey = (String) key;
            Map<String, Object> hmService = (Map<String, Object>) hmMemberServices.get(sServiceKey);
            String stDbService = (String) CommonDefs.SERVICE_VALUES.get(sServiceKey);
            if (hmService == null || hmService.isEmpty()) {
                continue;
            }
            String strServiceStatus = (String) hmService.get(MPSDefs.SERVICE_STATUS);
            if (CommonDefs.INSTANCE_SERVICES.contains(stDbService)) {
                addInstanceServices(alNewServices, hmService, stDbService, strServiceStatus);
            } else {
                addSingleService(alNewServices, hmService, stDbService, strServiceStatus);
            }
        }
        return alNewServices;
    }

    /**
     * Adds instance services to the list of new services for the notification event.
     * @param alNewServices the list to add instance services to
     * @param hmService map containing service information
     * @param stDbService the service type
     * @param strServiceStatus the service status
     */
    private static void addInstanceServices(List<Map<String, Object>> alNewServices, Map<String, Object> hmService, String stDbService, String strServiceStatus) {
        for (Object insIdKey : hmService.keySet()) {
            Object objInsId = hmService.get(insIdKey);
            if (objInsId instanceof Map) {
                Map<String, Object> hmInsId = (Map<String, Object>) objInsId;
                String strEmailEligible = (String) hmInsId.get(MPSDefs.DB_EMAIL_ELIGIBLE);
                String strSorName = (String) hmInsId.get(CommonDefs.SOR_NAME);
                Map<String, Object> hmTemp = CommonUtil.getHashMap();
                hmTemp.put(CommonDefs.SERVICE_TYPE, stDbService);
                hmTemp.put(CommonDefs.SERVICE_STATUS, strServiceStatus);
                hmTemp.put(CommonDefs.EMAIL_ELIGIBLE, strEmailEligible);
                hmTemp.put(CommonDefs.SOR_NAME, strSorName);
                alNewServices.add(hmTemp);
            }
        }
    }

    /**
     * Adds a single service to the list of new services for the notification event.
     * @param alNewServices the list to add the service to
     * @param hmService map containing service information
     * @param stDbService the service type
     * @param strServiceStatus the service status
     */
    private static void addSingleService(List<Map<String, Object>> alNewServices, Map<String, Object> hmService, String stDbService, String strServiceStatus) {
        String strEmailEligible = (String) hmService.get(MPSDefs.DB_EMAIL_ELIGIBLE);
        String strSorName = (String) hmService.get(CommonDefs.SOR_NAME);
        Map<String, Object> hmTemp = CommonUtil.getHashMap();
        hmTemp.put(CommonDefs.SERVICE_TYPE, stDbService);
        hmTemp.put(CommonDefs.SERVICE_STATUS, strServiceStatus);
        hmTemp.put(CommonDefs.EMAIL_ELIGIBLE, strEmailEligible);
        hmTemp.put(CommonDefs.SOR_NAME, strSorName);
        alNewServices.add(hmTemp);
    }
}
