package com.att.idp.idgraphusermanagementms.resource.request;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * This class represents the request for the registrationOrchestration API.
 * It accepts a targetAccessId and a list of associations (BANs, Individuals)
 * to be merged or linked to the target accessId.
 */
@Schema(name = "registrationOrchestrationRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class RegistrationOrchestrationRequest {

    /**
     * The name of the transaction. This field is final and cannot be changed.
     */
    private final String transactionName = "RegistrationOrchestration";

    /**
     * The ID of the system making the call.
     */
    private String callingSystemId;

    /**
     * Target accessId to associate to.
     */
    @NotNull(message = "targetAccessId is required field in input request.|RegistrationOrchestration")
    @Size(min = 1, max = 127, message = "targetAccessId length is invalid|RegistrationOrchestration")
    private String targetAccessId;

    /**
     * List of associations to process. At least one item required.
     */
    @NotNull(message = "associationList is required field in input request.|RegistrationOrchestration")
    @Size(min = 1, message = "associationList must contain at least one item|RegistrationOrchestration")
    @Valid
    private List<AssociationItem> associationList;

    /**
     * The trace ID for the Identity Platform (IDP).
     */
    @Schema(name = "idpTraceId")
    private String idpTraceId;

    /**
     * A map to store any additional attributes that are not defined in the class.
     * This field is used for JSON serialization and deserialization.
     */
    @JsonAnySetter
    @JsonAnyGetter
    public Map<String, Object> unknownAttributes = new HashMap<>();
}
