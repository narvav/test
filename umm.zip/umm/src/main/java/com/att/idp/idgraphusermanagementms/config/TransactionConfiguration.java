package com.att.idp.idgraphusermanagementms.config;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * This is a configuration class named TransactionConfiguration.
 * It is annotated with @Configuration to indicate that it is a source of bean definitions for the application context.
 * It is also annotated with @EnableTransactionManagement to enable Spring's annotation-driven transaction management capability.
 * The class has an EntityManagerFactory field which is autowired, meaning that Spring will automatically inject an instance of EntityManagerFactory into this field.
 * EntityManagerFactory is an interface in JPA that is used to create EntityManager instances.
 * The class contains several methods, each annotated with @Bean, which define beans for JpaTransactionManager, PersistenceExceptionTranslationPostProcessor, and EntityManager.
 * These beans are instantiated and managed by the Spring container.
 */
@Configuration
@EnableTransactionManagement(proxyTargetClass=true)
public class TransactionConfiguration {
	
	@Autowired
	private EntityManagerFactory entityManagerFactory;

	
	/**
	 * This method is responsible for creating and configuring a JpaTransactionManager.
	 * JpaTransactionManager is a specific implementation of the PlatformTransactionManager interface for JPA.
	 * The method takes an EntityManagerFactory as a parameter, which is used to set the EntityManagerFactory of the JpaTransactionManager.
	 * The EntityManagerFactory is responsible for creating EntityManager instances, which are used to interact with the persistence context.
	 * The method returns the configured JpaTransactionManager.
	 *
	 * @param entityManagerFactory - an instance of EntityManagerFactory used to create EntityManager instances.
	 * @return JpaTransactionManager - a transaction manager configured for JPA.
	 */
	@Bean
	@Primary
	public JpaTransactionManager transactionManager(EntityManagerFactory entityManagerFactory) {

		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManagerFactory);
		return transactionManager;
	}
	
	/**
	 * This method is responsible for creating a PersistenceExceptionTranslationPostProcessor.
	 * PersistenceExceptionTranslationPostProcessor is a bean post-processor that automatically applies persistence exception translation to any bean marked with Spring's @Repository annotation, adding a corresponding PersistenceExceptionTranslationAdvisor to the exposed proxy.
	 * This helps in translating the native persistence exceptions into Spring's DataAccessException hierarchy.
	 * The method returns the created PersistenceExceptionTranslationPostProcessor.
	 *
	 * @return PersistenceExceptionTranslationPostProcessor - a bean post-processor that automatically applies persistence exception translation.
	 */
	@Bean
	public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
		
		return new PersistenceExceptionTranslationPostProcessor();
	}
	
	/**
	 * This method is responsible for creating an EntityManager.
	 * EntityManager is an interface in JPA that is used to interact with the persistence context.
	 * The method uses the autowired EntityManagerFactory to create an EntityManager.
	 * The EntityManagerFactory is responsible for creating EntityManager instances.
	 * The method returns the created EntityManager.
	 *
	 * @return EntityManager - an instance used to interact with the persistence context.
	 */
	@Bean
	@Qualifier("entityManager")
	public EntityManager entityManager() {
		
		return entityManagerFactory.createEntityManager();
	}
}