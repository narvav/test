package com.att.idp.idgraphusermanagementms.db.repository;

import java.sql.SQLException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.att.idp.idgraphusermanagementms.db.model.Tsecurityquestion;

/**
 * This is the main repository interface for security question related operations.
 * It extends JpaRepository for standard CRUD operations and SecurityQuestionRepositoryCustom for custom operations.
 * The entity associated with this repository is Tsecurityquestion and the ID type is Long.
 */
@Repository 
public interface SecurityQuestionRepository extends JpaRepository<Tsecurityquestion, Long> , SecurityQuestionRepositoryCustom {
	
	/**
	 * This method is used to retrieve the security question ID for a given security question from the database.
	 *
	 * @param securityQuestion A string representing the security question for which the ID is to be retrieved.
	 * @return A list of Tsecurityquestion objects that match the given security question.
	 * @throws SQLException If there is an error while executing the SQL query.
	 */
	@Query(value= "SELECT * FROM MPS_OWNER.TSECURITYQUESTION sec WHERE SUBSTR(TRIM(LOWER(sec.SECURITY_QUESTION)), 1, 80) = TRIM(LOWER(:securityQuestion))" , nativeQuery=true)
	public List<Tsecurityquestion> getSecurityQuestionId(@Param(value="securityQuestion") String securityQuestion) throws SQLException;
}
