package com.att.idp.idgraphusermanagementms.db.repository;

/**
 * This is a custom repository interface for network access related operations.
 * Additional methods for network access operations should be declared here.
 */
public interface NetWorkAccessRepositoryCustom {
	
}
