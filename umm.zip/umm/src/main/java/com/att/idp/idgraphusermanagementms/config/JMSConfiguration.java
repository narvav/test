package com.att.idp.idgraphusermanagementms.config;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;

import jakarta.jms.BytesMessage;
import jakarta.jms.Connection;
import jakarta.jms.Destination;
import jakarta.jms.JMSException;
import jakarta.jms.MessageProducer;
import jakarta.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.att.mpsys.common.utils.CommonUtil;
import com.ibm.mq.jakarta.jms.MQConnectionFactory;
import com.ibm.msg.client.jakarta.wmq.WMQConstants;
import jakarta.jms.ConnectionFactory;

/**
 * This is a method named transactionManagerRef.
 * It is annotated with @Bean to indicate that it is a bean definition.
 * The method returns a PlatformTransactionManager which is an interface that specifies behaviors for transaction management.
 * The method creates a JpaTransactionManager, sets its EntityManagerFactory with the one created by the entityManagerFactory method, and returns it.
 * The JpaTransactionManager is a specific implementation of the PlatformTransactionManager interface for JPA.
 */
@Configuration
@EnableTransactionManagement
@ComponentScan("com.att.idp.idgraphusermanagementms")
public class JMSConfiguration {

	private static Logger log = LoggerFactory.getLogger(JMSConfiguration.class);

	private static final String MQ_HOST_DL = "zlp15103.vci.att.com";

	private static final String MQ_HOST_FF = "zlp15117.vci.att.com";

	private static final String QUEUE_NAME = "MPSQL.MSDBUS.PROD1.INT.MSRIL.0";

	@Value("${mq.host}")
	private String mqHost;

	@Value("${mq.port}")
	private int mqPort;

	@Value("${mq.channel}")
	private String mqChannel;

	@Value("${mq.ff.host}")
	private String mqFFHost;

	@Value("${mq.ff.port}")
	private int mqFFPort;

	@Value("${mq.ff.channel}")
	private String mqFFChannel;

	@Value("${mq.reconnect}")
	private boolean isMqReconnect;

	@Value("${mq.reconnect.timeout.sec}")
	private int mqReconnectTimeoutSec;

	@Value("${jms.reconnect}")
	private boolean isJmsReconnect;

	@Value("${jms.session.cache.size}")
	private int jmsSessionCacheSize;

	/**
	 * Defining MQQueueConnectionFactory.
	 *
	 * @return mqQueueConnectionFactory instance of MQQueueConnectionFactory
	 */
	@Bean
	public MQConnectionFactory mqQueueConnectionFactory() {
		MQConnectionFactory mqConnectionFactory = new MQConnectionFactory();

		try  {
			/*
			 * InetAddress inetHost = InetAddress.getByName(mqHost);
			 * log.debug("Mq Channel Before : " + mqChannel);
			 * mqChannel=mqChannel.concat(".").concat(inetHost.getCanonicalHostName().
			 * substring(0, inetHost.getCanonicalHostName().indexOf("."))).trim();
			 *
			 * log.debug("Mq Channel After : " + mqChannel);
			 */

			mqConnectionFactory.setHostName(mqHost);
			mqConnectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
			mqConnectionFactory.setChannel(mqChannel.toUpperCase());
			mqConnectionFactory.setPort(mqPort);

			if (MQ_HOST_DL.equalsIgnoreCase(mqHost) || MQ_HOST_FF.equalsIgnoreCase(mqHost)) {

				// dummy request to trigger to q put
				HashMap testhmInput = getMQData();

				try(ByteArrayOutputStream bos = new ByteArrayOutputStream();
					ObjectOutput out = new ObjectOutputStream(bos);
					Connection tconnection = (Connection)mqConnectionFactory.createConnection();
					Session tsession = tconnection.createSession(false, Session.AUTO_ACKNOWLEDGE);
				) {
					out.writeObject(testhmInput);
					out.flush();
					byte[] tinputBytes = bos.toByteArray();

					Destination destination = tsession.createQueue(QUEUE_NAME);

					BytesMessage bMsg = tsession.createBytesMessage();
					bMsg.writeBytes(tinputBytes);
					bMsg.setJMSCorrelationID("test12345");
					try(MessageProducer msgProducer = tsession.createProducer(destination);) {

						log.info("before sending: ");
						msgProducer.send(bMsg);

						log.info("result of qput: SUCCESS");}

				} catch (IOException e1) {
					log.info("in mqQueueConnectionFactory exception error message,IOException" + e1.getMessage());
				} catch (JMSException e) {

					log.info("in mqQueueConnectionFactory exception error message" + e.getMessage() + "error code: "
							+ e.getErrorCode());
					log.info("in mqQueueConnectionFactory exception error cause" + e.getCause());
					log.info("existing :" + mqConnectionFactory.getHostName()
							+ mqConnectionFactory.getChannel() + mqConnectionFactory.getPort());
					mqConnectionFactory.setHostName(mqFFHost);
					mqConnectionFactory.setChannel(mqFFChannel.toUpperCase());
					mqConnectionFactory.setPort(mqFFPort);

				}
			}

			if (isMqReconnect) {
				mqConnectionFactory.setClientReconnectOptions(WMQConstants.WMQ_CLIENT_RECONNECT);
				mqConnectionFactory.setClientReconnectTimeout(mqReconnectTimeoutSec);
			}
			log.info("MQ Configuration :" + mqConnectionFactory.getHostName()
					+ mqConnectionFactory.getChannel() + mqConnectionFactory.getPort());

		}
		/*
		 * catch (UnknownHostException e) { log.error("JMC1.1",
		 * "UnknownHostException while checking for hostname :" + e.getMessage()); }
		 */
		catch (JMSException e) {

			Exception linked = e.getLinkedException();
			if (linked != null) {
				log.error("Linked Exception=" + linked.getMessage());
				log.error("Linked StackTrace=" + linked.getStackTrace());
				log.error("Linked Cause=" + linked.getCause());
				log.error("Linked=" + linked);
			}
			log.error("JMC1.2", "JMSException while creating mqQueueConnectionFactory:" + e.getMessage());

		}
		log.info("final :" + mqConnectionFactory.getHostName() + mqConnectionFactory.getChannel()
				+ mqConnectionFactory.getPort());
		return mqConnectionFactory;
	}

	/**
	 * Populating dummy values for MQ.
	 *
	 * @return testnF instance of HashMap
	 */
	private static HashMap getMQData() {

		HashMap testnF = CommonUtil.getHashMap();
		testnF.put("securityCode", "123456");
		testnF.put("securityCodeExpires", ZonedDateTime.now(ZoneOffset.UTC));

		HashMap emailAddr = CommonUtil.getHashMap();
		emailAddr.put("emailAddress", "qaytest1@att.com");

		ArrayList emailAddressList = CommonUtil.getArrayList();
		emailAddressList.add(emailAddr);
		HashMap email = CommonUtil.getHashMap();
		email.put("emailAddressList", emailAddressList);
		HashMap delMethods = CommonUtil.getHashMap();
		delMethods.put("email", email);

		HashMap testhmEventData = CommonUtil.getHashMap();
		testhmEventData.put("expirationDays", "0.041666666666666664");
		testhmEventData.put("subEvent", "EDDORC");
		testhmEventData.put("identificationType", "EMAILPIN");
		testhmEventData.put("transactionName", "GenerateSecurityCode");
		testhmEventData.put("callingSystemId", "MULESOFT");
		testhmEventData.put("transactionId", "test12345");
		testhmEventData.put("eventname", "EDDORCNotification");
		testhmEventData.put("accountID", "1000006780");
		testhmEventData.put("expirationHours", "1");
		testhmEventData.put("dbus_DictionaryName", "Dict");
		testhmEventData.put("origTransactionId", "test12345");
		testhmEventData.put("expirationDays", "0.041666666666666664");
		testhmEventData.put("notificationFields", testnF);
		testhmEventData.put("deliveryMethods", delMethods);
		ArrayList alEventData = CommonUtil.getArrayList();
		alEventData.add(testhmEventData);
		HashMap testhmInput = CommonUtil.getHashMap();
		testhmInput.put("dbus_DictionaryName", "Dict");
		testhmInput.put("mainHashKey", "1000006780");
		testhmInput.put("msOperation", "GeneratePIN");
		testhmInput.put("transactionName", "GeneratePIN");
		testhmInput.put("callingSystemId", "MULESOFT");
		testhmInput.put("eventname", "MicroServiceEvent");
		testhmInput.put("transactionId", "test12345");
		testhmInput.put("stopkeyfield", "stopfield");
		testhmInput.put("stopfield", "mstodbusStopKey1000006780");
		testhmInput.put("eventsData", alEventData);
		return testhmInput;
	}

	/**
	 * Configuring caching connection factory.
	 *
	 * @param mqConnectionFactory MQQueueConnectionFactory
	 * @return cachingConnectionFactory instance of CachingConnectionFactory
	 */
	@Bean
	@Primary
	public CachingConnectionFactory cachingConnectionFactory(MQConnectionFactory mqConnectionFactory) {
		CachingConnectionFactory cachingConnectionFactory = new CachingConnectionFactory((ConnectionFactory) mqConnectionFactory);

		if (isJmsReconnect) {
			cachingConnectionFactory.setReconnectOnException(true);
		}
		cachingConnectionFactory.setSessionCacheSize(jmsSessionCacheSize);
		return cachingConnectionFactory;
	}

	/**
	 * Creating new JmsTemplate
	 *
	 * @param cachingConnectionFactory CachingConnectionFactory
	 * @return jmsTemplate JmsTemplate
	 */
	@Bean
	public JmsTemplate jmsTemplate(CachingConnectionFactory cachingConnectionFactory) {

		JmsTemplate jmsTemplate = new JmsTemplate(cachingConnectionFactory);

		return jmsTemplate;
	}
}
