package com.att.idp.idgraphusermanagementms.db.repository;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.att.idp.idgraphusermanagementms.db.model.Tserviceinfo;
import com.att.idp.idgraphusermanagementms.db.model.TserviceinfoId;

/**
 * This is the main repository interface for TServiceAssociation related operations.
 * It extends JpaRepository for standard CRUD operations and TServiceAssociationRepositoryCustom for custom operations.
 * The entity associated with this repository is Tserviceinfo and the ID type is TserviceinfoId.
 */
@Repository 
public interface TServiceAssociationRepository extends JpaRepository<Tserviceinfo, TserviceinfoId> , TServiceAssociationRepositoryCustom {
	
	/**
	 * This method is used to retrieve the service information by System of Record ID and System of Record Invariant ID.
	 *
	 * @param sorId A BigDecimal representing the System of Record ID for which the service information is to be retrieved.
	 * @param sorInvariantId A String representing the System of Record Invariant ID for which the service information is to be retrieved.
	 * @return A Tserviceinfo object containing the service information associated with the given System of Record ID and System of Record Invariant ID.
	 */
	@Query("select tServiceInfo from Tserviceinfo tServiceInfo where tServiceInfo.id.sorId=:sorId and tServiceInfo.id.sorInvariantId=:sorInvariantId")
	public Tserviceinfo getServiceInfoBySorIdAndSorInvariantId(@Param(value = "sorId") BigDecimal sorId,
			@Param(value = "sorInvariantId") String sorInvariantId);
	
}
