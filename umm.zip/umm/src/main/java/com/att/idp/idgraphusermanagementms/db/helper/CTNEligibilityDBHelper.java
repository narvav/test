package com.att.idp.idgraphusermanagementms.db.helper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.StatusMsg;
/**
 * This class is responsible for managing CTN (Customer Telephone Number) eligibility-related operations in the database.
 * It uses Spring's JdbcTemplate for database operations and has methods for getting, adding, updating, and removing CTN eligibility.
 * It also uses other helper classes like CommonUtil and CommonErrorMap.
 *
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like JdbcTemplate.
 *
 * The class contains SQL queries as string constants for getting, adding, updating, and removing CTN eligibility.
 * These queries are used in the corresponding methods for these operations.
 *
 * The class also contains a logger for logging information and errors.
 *
 * The main methods in this class are:
 * - getCTNEligibility: This method retrieves a CTN's eligibility information from the database. It takes a HashMap as input and returns a HashMap as output.
 * - addCTNEligibility: This method adds a CTN's eligibility information to the database. It takes a HashMap as input and returns a HashMap as output.
 * - updateCTNEligibility: This method updates a CTN's eligibility information in the database. It takes a HashMap as input and returns a HashMap as output.
 * - removeCTNEligibility: This method removes a CTN's eligibility information from the database. It takes a HashMap as input and returns a HashMap as output.
 */
@Component
public class CTNEligibilityDBHelper {
	
	public static final Logger logger = LoggerFactory.getLogger(CTNEligibilityDBHelper.class);
	private static String sClassName = "CTNEligibilityDBHelper";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;
	
	private static final ArrayList alUpdateKeys = CommonUtil.getArrayList();
	static {
		alUpdateKeys.add(CommonDefs.CTN_USAGE_FILTER);
		alUpdateKeys.add(CommonDefs.TXN_COUNT); //2002: PID 308709 : Updates to handle the 2 new fields ctn_init_date and txn_count in CTNELIGIBILITY table.
	}
	
	/**
	 * This method retrieves a CTN's (Customer Telephone Number) eligibility information from the database.
	 * It takes a HashMap as an argument which contains the details of the CTN's eligibility to be retrieved.
	 * The HashMap should contain the following key:
	 * - CommonDefs.CTN: The CTN (Customer Telephone Number).
	 *
	 * The method first logs the start of the operation and the input parameters.
	 * It then checks if the CTN is present in the input HashMap.
	 * If the CTN is missing, it logs an error and returns an error status.
	 * Otherwise, it prepares the SQL query for retrieving the CTN's eligibility and executes it using the jdbcTemplate object.
	 * If the operation is successful, the method returns a HashMap containing the status of the operation and the retrieved CTN's eligibility information.
	 * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
	 *
	 * @param hmInput A HashMap containing the details of the CTN's eligibility to be retrieved.
	 * @return A HashMap containing the status of the operation and the retrieved CTN's eligibility information.
	 */
	public HashMap getCTNEligibility(HashMap hmInput){

		String sMethodName = ".getCTNEligibility.";
		String sAppInfo = null;
		String sCtn = null;
		Date dtStartDate = new Date();
		String dateFormat = "MMDDYYYY HH24:mi:ss";	 
		HashMap<String, Object> hmResult = null;
		List queryResponse = null;
		List<Object> objectList = new ArrayList<Object>();

		try {
			logger.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName,HtmlUtils.htmlEscape(String.valueOf(hmInput)));
			sCtn = (String)hmInput.get(CommonDefs.CTN);

			if(sCtn == null || sCtn.isEmpty()){
				sAppInfo = "CTN is null or empty";
				logger.info("{}{}GCTNE.DBH_03: {}", sClassName, sMethodName, sAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo );
				return hmResult;
			}

			String sQueryCTNElgbltySql = "SELECT ce.ctn, TO_CHAR(ce.ctn_last_used_date,'" + dateFormat + "') AS ctn_last_used_date, ce.ctn_usage_filter, "
					+ "TO_CHAR(ce.create_date,'" + dateFormat + "') AS create_date, TO_CHAR(ce.last_modified, '" + dateFormat + "') AS last_modified, "
					+ "TO_CHAR(ce.ctn_init_date, '" + dateFormat + "') AS ctn_init_date, ce.txn_count, ce.last_modified_by, TO_CHAR(SYSDATE, '" + dateFormat + "') AS DB_SYSDATE  " 
					+ "FROM ctneligibility ce WHERE ce.ctn = ?";

			objectList.add(sCtn);
			logger.info("{}{}GCTNE.DBH_04: CTN::PARAM 1 = {} ", sClassName, sMethodName, sCtn);
			logger.info("{}{}GCTNE.DBH_05 : sQueryCTNElgbltySql: {} ", sClassName, sMethodName, sQueryCTNElgbltySql);

			long pTime = 0;
			queryResponse = jdbcTemplate.queryForList(new String(sQueryCTNElgbltySql), objectList.toArray(new Object[objectList.size()]));
			pTime = (System.currentTimeMillis() - dtStartDate.getTime());

			logger.info("{}{}GCTNE.DBH_06 :Total time taken to execute query {} milliseconds", sClassName, sMethodName, pTime);  

			int numRowsFound = 0;
			if (queryResponse != null && !queryResponse.isEmpty()) {
				for (int j = 0; j < queryResponse.size(); j++) {
					Map hmQueryResponse = (Map) queryResponse.get(j);
					Iterator itr = hmQueryResponse.keySet().iterator();
					HashMap hmCTNElgbltyInfo = CommonUtil.getHashMap();
					while (itr.hasNext()) {
						String key = (String) itr.next();
						Object value = hmQueryResponse.get(key);
						String strValue = (value == null ? null : value.toString());
						hmCTNElgbltyInfo.put(key, strValue);
					}
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS);
					hmResult.put(CommonDefs.CTN_ELIGIBILITY, hmCTNElgbltyInfo);
					++numRowsFound;
				}
			}

			if (numRowsFound == 0) {
				sAppInfo = "Record not found.";
				hmResult = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_REC_NOT_FOUND_NUM, sAppInfo );
				logger.info("{}{}GCTNE.DBH_07 error : {}", sClassName, sMethodName, sAppInfo);
				return hmResult;
			}

		}catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}GCTNE.DBH_08 :  Error::{}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}GCTNE.DBH_09 : Exception = {}", sClassName, sMethodName, e);
		}finally {
			logger.info("{}{}DBTOOLS999 : STATUS = {}", sClassName, sMethodName, hmResult);
		}
		
		return hmResult;
	}
	
	/**
	 * This method is responsible for adding a CTN's (Customer Telephone Number) eligibility information to the database.
	 * It takes a HashMap as an argument which contains the details of the CTN's eligibility to be added.
	 * The HashMap should contain the following keys:
	 * - CommonDefs.CTN: The CTN (Customer Telephone Number).
	 * - CommonDefs.CTN_USAGE_FILTER: The usage filter of the CTN.
	 * - CommonDefs.TXN_COUNT: The transaction count.
	 *
	 * The method first logs the start of the operation and the input parameters.
	 * It then checks if the necessary information is present in the input HashMap.
	 * If any necessary information is missing, it logs an error and returns an error status.
	 * Otherwise, it prepares the SQL query for adding the CTN's eligibility and executes it using the jdbcTemplate object.
	 * If the operation is successful, the method returns a HashMap containing the status of the operation.
	 * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
	 *
	 * @param hmInput A HashMap containing the details of the CTN's eligibility to be added.
	 * @return A HashMap containing the status of the operation.
	 */
	public HashMap addCTNEligibility(HashMap hmInput){

		String sMethodName = ".addCTNEligibility.";
		String sAppInfo = null;
		String sCallingSystemId = null;
		String sCtn = null;
		String sCtnUsageFilter = null;
		String stAppInfo = null;
		Date dtStartDate = new Date();
		SimpleDateFormat sdf =	new SimpleDateFormat("MMddyyyy HH:mm:ss");
		HashMap<String, Object> hmResult = null;
		List<Object> objectList = new ArrayList<Object>();

		try {
			logger.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName,HtmlUtils.htmlEscape(String.valueOf(hmInput)));
			sCallingSystemId = (String)hmInput.get(CommonDefs.LAST_MODIFIED_BY);
			sCtn = (String)hmInput.get(CommonDefs.CTN);
			sCtnUsageFilter = (String)hmInput.get(MPSDefs.DB_CTN_USAGE_FILTER);
			//2002: PID 308709 : Updates to handle the 2 new fields ctn_init_date and txn_count in CTNELIGIBILITY table.
			String sTxnCount = (String) hmInput.get(CommonDefs.TXN_COUNT);
			if(sTxnCount == null || sTxnCount.isEmpty()) {
				sTxnCount = "1";
			}

			if(sCallingSystemId == null || sCallingSystemId.isEmpty() || sCtn == null || sCtn.isEmpty()){
				sAppInfo = "Any of CallingSystemID or CTN is null or empty";
				logger.info("{}{}ACTNE.DBH_03: {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo );
				return hmResult;
			}

			String sSysDate = sdf.format(dtStartDate);
			//2002: PID 308709 : Updates to handle the 2 new fields ctn_init_date and txn_count in CTNELIGIBILITY table
			String stCTNElgbltySql = "INSERT INTO CTNELIGIBILITY(ctn, ctn_last_used_date, ctn_usage_filter, last_modified_by, ctn_init_date, txn_count) values (?, SYSDATE, ?, ?, SYSDATE, ?)";

			objectList.add(sCtn);
			logger.info("{}{}ACTNE.DBH_04: ctn::PARAM 1 = {}", sClassName, sMethodName, sCtn);

			if(sCtnUsageFilter != null && !sCtnUsageFilter.isEmpty()){
				objectList.add(sCtnUsageFilter);
				logger.info("{}{}ACTNE.DBH_05: ctn_usage_filter::PARAM 2 = {}", sClassName, sMethodName, sCtnUsageFilter);
			}else{
				objectList.add(null);
				logger.info("{}{}ACTNE.DBH_06: ctn_usage_filter::PARAM 2 = {}", sClassName, sMethodName, sCtnUsageFilter);
			}

			objectList.add(sCallingSystemId);
			logger.info("{}{}ACTNE.DBH_07: stCTNElgbltySql: {}", sClassName, sMethodName, stCTNElgbltySql);

			//2002: PID 308709 : Updates to handle the 2 new fields ctn_init_date and txn_count in CTNELIGIBILITY table
			objectList.add(Integer.parseInt(sTxnCount));
			logger.info("{}{}ACTNE.DBH_08: TxnCount: {}", sClassName, sMethodName, Integer.parseInt(sTxnCount));

			long pTime = 0;
			int rowCount = jdbcTemplate.update(new String(stCTNElgbltySql), objectList.toArray(new Object[objectList.size()]));

			pTime = (System.currentTimeMillis() - dtStartDate.getTime());	
			logger.info("{}{}ACTNE.DBH_09 :Total time taken to execute query {} milliseconds", sClassName, sMethodName,pTime);
			logger.info("{}{}ACTNE.DBH_10 : No of rows inserted = {}", sClassName, sMethodName, rowCount);

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "No of rows inserted:= " + rowCount);
		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}ACTNE.DBH_11 :  Error::{}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}ACTNE.DBH_12 : Exception = {}", sClassName, sMethodName, e);
		}finally {
			logger.info("{}{}DBTOOLS999 : STATUS = {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;
	}
	
	
	/**
	 * This method is responsible for updating a CTN's (Customer Telephone Number) eligibility information in the database.
	 * It takes a HashMap as an argument which contains the details of the CTN's eligibility to be updated.
	 * The HashMap should contain the following keys:
	 * - CommonDefs.CTN: The CTN (Customer Telephone Number).
	 * - CommonDefs.CTN_USAGE_FILTER: The usage filter of the CTN.
	 * - CommonDefs.TXN_COUNT: The transaction count.
	 * - CommonDefs.LAST_MODIFIED_BY: The identifier of the system that last modified the record.
	 *
	 * The method first logs the start of the operation and the input parameters.
	 * It then checks if the necessary information is present in the input HashMap.
	 * If any necessary information is missing, it logs an error and returns an error status.
	 * Otherwise, it prepares the SQL query for updating the CTN's eligibility and executes it using the jdbcTemplate object.
	 * If the operation is successful, the method returns a HashMap containing the status of the operation.
	 * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
	 *
	 * @param hmInput A HashMap containing the details of the CTN's eligibility to be updated.
	 * @return A HashMap containing the status of the operation.
	 */
	public HashMap updateCTNEligibility(HashMap hmInput){

		String sMethodName = ".updateCTNEligibility.";
		String sAppInfo = null;
		String sCallingSystemId = null;
		String sCtn = null;
		String stAppInfo = null;
		Date dtStartDate = new Date();
		HashMap<String, Object> hmResult = null;
		List<Object> objectList = new ArrayList<Object>();
		try {
			logger.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName,HtmlUtils.htmlEscape(String.valueOf(hmInput)));
			sCallingSystemId = (String)hmInput.get(CommonDefs.LAST_MODIFIED_BY);
			sCtn = (String)hmInput.get(CommonDefs.CTN);

			if(sCallingSystemId == null || sCallingSystemId.isEmpty() || sCtn == null || sCtn.isEmpty()){
				sAppInfo = "Any of CallingSystemID or CTN is null or empty";
				logger.info("{}{}UCTNE.DBH_03: {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo );
				return hmResult;
			}

			StringBuilder stCTNElgbltyUpdateSql = new StringBuilder("UPDATE CTNELIGIBILITY set last_modified_by = ?");
			String sWhereClause = " WHERE ctn = ? ";

			String sCTNLastUsedDateFlag = (String) hmInput.get(CommonDefs.CTN_LAST_USED_DATE_FLAG);
			if(sCTNLastUsedDateFlag != null && !sCTNLastUsedDateFlag.isEmpty()){
				stCTNElgbltyUpdateSql.append(" , ctn_init_date = SYSDATE, ctn_last_used_date = SYSDATE ");
			}

			Iterator it = alUpdateKeys.iterator();
			while (it.hasNext()) {
				String key = (String) it.next();
				if(hmInput.containsKey(key)){
					stCTNElgbltyUpdateSql.append(" , " + key + " = '" + (String)hmInput.get(key) + "'");
				}
			}

			stCTNElgbltyUpdateSql.append(sWhereClause);

			objectList.add(sCallingSystemId);
			logger.info("{}{}UCTNE.DBH_04: last_modified_by::PARAM 1 ={}", sClassName, sMethodName, sCallingSystemId);
			objectList.add(sCtn);
			logger.info("{}{}UCTNE.DBH_05: ctn::PARAM 2 ={}", sClassName, sMethodName, sCtn);
			logger.info("{}{}UCTNE.DBH_06: stCTNElgbltySql: {}", sClassName, sMethodName, stCTNElgbltyUpdateSql);

			long pTime = 0;
			int rowCount = jdbcTemplate.update(new String(stCTNElgbltyUpdateSql), objectList.toArray(new Object[objectList.size()]));

			pTime = (System.currentTimeMillis() - dtStartDate.getTime());	
			logger.info("{}{}UCTNE.DBH_07 :Total time taken to execute query {} milliseconds ", sClassName, sMethodName,pTime );
			logger.info("{}{}UCTNE.DBH_08 : No of rows inserted = {}", sClassName, sMethodName, rowCount);

			if(rowCount == 0){
				hmResult = CommonErrorMap.makeCategoryMap (CErrorDefs.ERR_REC_NOT_FOUND_NUM,"No Record found for given ctn");
			}else{
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "No of rows updated:= " + rowCount);
			}

		}catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}UCTNE.DBH_09 :  Error::{}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}UCTNE.DBH_10 : Exception = {}", sClassName, sMethodName, e);
		}finally {
			logger.info("{}{}DBTOOLS999 : STATUS = {}", sClassName, sMethodName, hmResult);
		}

		return hmResult;
	}
	
	/**
	 * This method is responsible for removing a CTN's (Customer Telephone Number) eligibility information from the database.
	 * It takes a HashMap as an argument which contains the details of the CTN's eligibility to be removed.
	 * The HashMap should contain the following key:
	 * - CommonDefs.CTN: The CTN (Customer Telephone Number).
	 *
	 * The method first logs the start of the operation and the input parameters.
	 * It then checks if the CTN is present in the input HashMap.
	 * If the CTN is missing, it logs an error and returns an error status.
	 * Otherwise, it prepares the SQL query for removing the CTN's eligibility and executes it using the jdbcTemplate object.
	 * If the operation is successful, the method returns a HashMap containing the status of the operation.
	 * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
	 *
	 * @param hmInput A HashMap containing the details of the CTN's eligibility to be removed.
	 * @return A HashMap containing the status of the operation.
	 */
	public HashMap removeCTNEligibility(HashMap hmInput){

		String sMethodName = ".removeCTNEligibility.";
		String sAppInfo = null;
		String sCtn = null;
		Date dtStartDate = new Date();
		List<Object> objectList = new ArrayList<Object>();
		HashMap<String, Object> hmResult = null;
		try {
			logger.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName,hmInput!=null ? StringUtils.normalizeSpace(hmInput.toString()): null);
			sCtn = (String)hmInput.get(CommonDefs.CTN);
			
			if(sCtn == null || sCtn.isEmpty()){
				sAppInfo = "CTN is null or empty";
				logger.info("{}{}DCTNE.DBH_03: {}", sClassName, sMethodName, sAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo );
				return hmResult;
			}
			
			String stCTNElgbltyDelSql  = "DELETE FROM CTNELIGIBILITY WHERE ctn = ?";
			
			objectList.add(sCtn);
			logger.info("{}{}DCTNE.DBH_04: ctn::PARAM 1 ={}", sClassName, sMethodName, sCtn);
			logger.info("{}{}DCTNE.DBH_05: stCTNElgbltyDelSql: {}", sClassName, sMethodName, stCTNElgbltyDelSql);
			
			long pTime = 0;
			
			int rowCount = jdbcTemplate.update(new String(stCTNElgbltyDelSql),objectList.toArray(new Object[objectList.size()]));
			
			pTime = (System.currentTimeMillis() - dtStartDate.getTime());	
			logger.info("{}{}DCTNE.DBH_06 :Total time taken to execute query {} milliseconds ", sClassName, sMethodName,pTime);
			logger.info("{}{}DCTNE.DBH_07 : No of rows inserted = {}", sClassName, sMethodName, rowCount);
			
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "No of rows deleted:= " + rowCount);
			
		}catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}DCTNE.DBH_08 :  Error::{}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}DCTNE.DBH_09 : Exception = {}", sClassName, sMethodName, e);
		}finally {
			logger.info("{}{}DBTOOLS999 : STATUS = {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;
	}

}
