package com.att.idp.idgraphusermanagementms.request.validator;

import com.att.idp.idgraphusermanagementms.resource.request.UpdateUserPasswordRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdateUserPasswordResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import jakarta.ws.rs.core.HttpHeaders;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;

/**
 * This class, UpdateUserPasswordRequestValidator, is responsible for validating the UpdateUserPasswordRequest.
 * It checks for the presence and validity of required fields in the request, and returns a UpdateUserPasswordResponse accordingly.
 * It is annotated with @Component, @Configuration, and @PropertySource to indicate that it's a Spring Bean,
 * to allow it to access configuration properties, and to specify the location of the properties file respectively.
 *
 * The class contains several methods, including:
 * - validateUserPasswordUpdateRequest: the main method that orchestrates the validation process.
 * - validateRequest: a method that validates the input fields in the request.
 * - buildResponse: a helper method that generates a response based on the application status code, application info, and trace ID.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class UpdateUserPasswordRequestValidator {

	private static final Logger logger = LoggerFactory.getLogger(UpdateUserPasswordRequestValidator.class);
	
	private final String className = "UpdateUserPasswordRequestValidator";

	@Value("${PROP_CHANGE_USER_PASSWORD_CSI}")
	private String propCallingSystemId;

	/**
	 * This method is responsible for validating the UpdateUserPasswordRequest.
	 * It takes HttpHeaders and UpdateUserPasswordRequest as parameters.
	 * HttpHeaders contains the request headers which may include additional information required for processing the request.
	 * UpdateUserPasswordRequest encapsulates the details of the update password operation to be performed.
	 *
	 * The method performs various checks and validations on the input parameters and returns a UpdateUserPasswordResponse object.
	 * The UpdateUserPasswordResponse object encapsulates the result of the validate user update password operation.
	 *
	 * @param requestHeader The HttpHeaders containing the request headers.
	 * @param updateUserPasswordRequest The UpdateUserPasswordRequest containing the details of the validate user update password operation.
	 * @return UpdateUserPasswordResponse The response of the validate user  update password operation.
	 * @author pb6583_ATT
	 */
	public UpdateUserPasswordResponse validateUpdatePasswordRequest(HttpHeaders requestHeader, UpdateUserPasswordRequest updateUserPasswordRequest) {

		UpdateUserPasswordResponse updateUserPasswordResponse = null;

		String message = null;
		String callingMethodName = ".validateUserPasswordUpdateRequest";
		String idpTraceId = null;
		String xATTClientId = null;
		
		idpTraceId = CommonUtil.getTraceId(requestHeader);

		if (idpTraceId == null || idpTraceId.startsWith("AutoGen_")) {
			message = "Missing or Invalid IdpTraceId";
			return buildResponse(CErrorDefs.ERR_INVALID_DATA_NUM, message, idpTraceId);
		}

		if (updateUserPasswordRequest == null) {
			message = "Input Request Parameter is NULL / Empty.";
			logger.info(SpiMarker.getInstance(),"{}{}UPRV.VUPR_01 :: {}", className, callingMethodName, message);
			return buildResponse(CErrorDefs.ERR_INVALID_DATA_NUM, message, idpTraceId);
		}

		updateUserPasswordRequest.setIdpTraceId(idpTraceId);
			
		if (requestHeader.getHeaderString("X-ATT-ClientId") != null) {
			xATTClientId = requestHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
			logger.info(SpiMarker.getInstance(), "{}{}UPRV.VUPR_02 : Setting callingSystemId: {}", className, callingMethodName,
					xATTClientId);
			updateUserPasswordRequest.setCallingSystemId(xATTClientId);
		} else {
			message = "Missing or invalid X-ATT-ClientId in request header";
			logger.info(SpiMarker.getInstance(), "{}{}UPRV.VUPR_03 :: {}", className, callingMethodName, message);
			return buildResponse(CErrorDefs.ERR_INVALID_DATA_NUM, message, idpTraceId);
		}

		if( StringUtils.isEmpty(updateUserPasswordRequest.getNewPassword() )){
			message = "Required fields missing -  new password can't be empty";
			logger.info(SpiMarker.getInstance(),"{}{}UPRV.VUPR_04 :: {}", className, callingMethodName, message);
			return buildResponse(CErrorDefs.ERR_EMPTY_NUM, message, idpTraceId);
		}
		
		try {
			updateUserPasswordResponse = validateRequest(updateUserPasswordRequest);
			if (updateUserPasswordResponse != null) {
				logger.info(SpiMarker.getInstance(),"{}{}UPRV.VUPR_05 Response from UpdateUserPasswordRequestValidator : {}", className, callingMethodName,
						updateUserPasswordResponse);
				return updateUserPasswordResponse;
			} else {
				logger.debug("{}{}UPRV.VUPR_01 Success Response from UpdateUserPasswordRequestValidator ", className,
						callingMethodName);
			}
			message = "Input Validation Successful";
			logger.info(SpiMarker.getInstance(),"{}{}UPRV.VUPR_06 : {}", className, callingMethodName, message);
		} catch (Exception e) {
			message = "Exception thrown in UpdateUserPasswordRequestValidator.validateRequest : " + e.getMessage();
			logger.info(SpiMarker.getInstance(),"Exception in validateRequest: {}", message);
			return buildResponse(CErrorDefs.ERR_SYS_APPL_NUM, message, idpTraceId);
		}		
		return updateUserPasswordResponse;
	}
	
	/**
	 * This method is part of the UpdateUserPasswordRequestValidator class.
	 * It is responsible for validating the UpdateUserPasswordRequest.
	 * The method takes a UpdateUserPasswordRequest as input.
	 * The UpdateUserPasswordRequest encapsulates the details of the validate user update password operation to be performed.
	 * The method performs various checks and validations on the input parameters and returns a UpdateUserPasswordResponse object.
	 * The UpdateUserPasswordResponse object encapsulates the result of the validate user update password operation.
	 * The method checks for the presence and validity of required fields in the request, and returns a UpdateUserPasswordResponse accordingly.
	 *
	 * @param updateUserPasswordRequest The UpdateUserPasswordRequest containing the details of the validate user update password operation.
	 * @return UpdateUserPasswordResponse The response of the validate user update password operation.
	 */
	@SuppressWarnings("rawtypes")
	private UpdateUserPasswordResponse validateRequest(UpdateUserPasswordRequest updateUserPasswordRequest) {
		
		String sMethodName = ".validateUserPasswordUpdateRequest";
		
		UpdateUserPasswordResponse updateUserPasswordResponse = null;
		String sAppInfo = null;

	
		Optional.ofNullable(updateUserPasswordRequest.getCallingSystemId()).ifPresent(x -> updateUserPasswordRequest.setCallingSystemId(x.trim().toUpperCase()));
		Optional.ofNullable(updateUserPasswordRequest.getHandle()).ifPresent(x -> updateUserPasswordRequest.setHandle(x.trim().toLowerCase()));
		Optional.ofNullable(updateUserPasswordRequest.getAgentId()).ifPresent(x -> updateUserPasswordRequest.setAgentId(x.trim().toLowerCase()));
		Optional.ofNullable(updateUserPasswordRequest.getIsExternalCall()).ifPresent(x -> updateUserPasswordRequest.setIsExternalCall(x.trim().toUpperCase()));
		Optional.ofNullable(updateUserPasswordRequest.getDomain()).ifPresent(x -> updateUserPasswordRequest.setDomain(x.trim().toLowerCase()));
		Optional.ofNullable(updateUserPasswordRequest.getDeliveryContactEmailAddress()).ifPresent(x -> updateUserPasswordRequest.setDeliveryContactEmailAddress(x.trim().toLowerCase()));

		String sIdpTraceId = updateUserPasswordRequest.getIdpTraceId();
		String sIsExternalCall = Optional.ofNullable(updateUserPasswordRequest.getIsExternalCall()).orElse("Y");
		String sHandle = updateUserPasswordRequest.getHandle();
		String sDomain = updateUserPasswordRequest.getDomain();
		String sCallingSystemId = updateUserPasswordRequest.getCallingSystemId();
		String isUpdateSilent = updateUserPasswordRequest.getIsUpdateSilent();
		String deliveryContactEmailAddress = updateUserPasswordRequest.getDeliveryContactEmailAddress();

		ArrayList alUpdateUserCallingSystemIds = CommonUtil.parseToArray(propCallingSystemId, CommonDefs.VALUE_SEPARATOR_CHAR);

		if (alUpdateUserCallingSystemIds != null && !alUpdateUserCallingSystemIds.contains(sCallingSystemId)
				&& sIsExternalCall != null && CommonDefs.IND_Y.equals(sIsExternalCall)) {
			String stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			return buildResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, sIdpTraceId);
		}

		if(StringUtils.isBlank(sHandle) && !isValidEmail(deliveryContactEmailAddress)){//If userId isn't provided, deliveryContactEmailAddress should be a valid email
			sAppInfo = "delivery contact email address is invalid";
			return buildResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
		}

		//checking Invalid attributes passed in Request
		Map<String,Object> allUnknownAttributes = new HashMap<>(updateUserPasswordRequest.unknownAttributes);

		if (!allUnknownAttributes.isEmpty()) {
			sAppInfo = "Invalid Attributes passed in updateUserPasswordRequest : " + allUnknownAttributes;
			return buildResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
		}

		if (!StringUtils.isEmpty(sIsExternalCall)) {
			if (!(sIsExternalCall.equalsIgnoreCase(CommonDefs.IND_Y) || sIsExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
				sAppInfo = "IsExternalCall must be one of Y or N";
				return buildResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
			} 
		}

		if (StringUtils.isNotBlank(isUpdateSilent)) {
			if (!(isUpdateSilent.equalsIgnoreCase(CommonDefs.IND_Y) || isUpdateSilent.equalsIgnoreCase(CommonDefs.IND_N))) {
				sAppInfo = "isUpdateSilent must be one of Y or N";
				return buildResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
			}
		}

		if(StringUtils.isBlank(updateUserPasswordRequest.getHandle())){
			sAppInfo = "userId is required";
			logger.info(SpiMarker.getInstance(),"{}{}UPRV.VR_01 : {}", className, sMethodName, sAppInfo);
			return buildResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
		}

		if(!StringUtils.isBlank(updateUserPasswordRequest.getHandle()) && StringUtils.isBlank(updateUserPasswordRequest.getDomain())){
			sAppInfo = "If userId is present, domain is required";
			logger.info(SpiMarker.getInstance(),"{}{}UPRV.VR_02 : {}", className, sMethodName, sAppInfo);
			return buildResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
		}

		if (!StringUtils.isEmpty(updateUserPasswordRequest.getNewPassword())) {
			if (updateUserPasswordRequest.getNewPassword().length() < 8) {
				sAppInfo = "Password should be atleast 8 characters long";
				logger.info(SpiMarker.getInstance(),"{}{}UPRV.VR_04 : {}", className, sMethodName, sAppInfo);
				return buildResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
			}
		}
		
		return updateUserPasswordResponse;
	}
	
	private UpdateUserPasswordResponse buildResponse(int appStatusCode, String stAppInfo, String stIdpTraceId) {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		return CommonUtilHelper.generateUpdateUserPasswordResponse(hmResponse);
	}

	private boolean isValidEmail(String email) {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
				+ "A-Z]{2,7}$";
		Pattern pat = Pattern.compile(emailRegex);
		if (email == null)
			return false;
		return pat.matcher(email).matches();
	}

}
