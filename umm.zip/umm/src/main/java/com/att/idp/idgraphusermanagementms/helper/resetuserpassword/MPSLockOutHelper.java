package com.att.idp.idgraphusermanagementms.helper.resetuserpassword;

import java.util.HashMap;

/**
 * This class is named MPSLockOutHelper and it is part of the package com.att.idp.idgraphusermanagementms.helper.resetuserpassword.
 * It is used to manage lockouts in the system.
 * It contains a static HashMap named dbLockOutsHashMap which is used to store lockout details.
 * It provides two methods: loadLockOuts and getDbLockOutsHashMap.
 * The loadLockOuts method is used to load lockout details into the HashMap.
 * The getDbLockOutsHashMap method is used to retrieve the HashMap containing the lockout details.
 * Note that the getDbLockOutsHashMap method should not be accessed directly by individual APIs, but through the methods defined in LockOutValidation.
 */
public class MPSLockOutHelper {

	private static HashMap dbLockOutsHashMap = null;
	
	/**
	 * This method is used to load lockout details into the HashMap.
	 * It takes a HashMap as input which contains the lockout details to be loaded.
	 * The input HashMap replaces the current HashMap stored in the class.
	 *
	 * @param hmLockOut HashMap containing the lockout details to be loaded.
	 */
	public static void loadLockOuts(HashMap hmLockOut) {
		dbLockOutsHashMap = hmLockOut;
	}

    /**
     * @return Returns the dbLockOutsHashMap.
     * NOTE: This method must NOT be accessed by individual APIs
     * instead, access it through the methods defined in LockOutValidation.
     * Some times dbLockOutsHashMap could be null and methods in 
     * LockOutValidation has necessary logic to auto load dbLockOutsHashMap 
     */
	public static HashMap getDbLockOutsHashMap() {
        return dbLockOutsHashMap;
    }

}
