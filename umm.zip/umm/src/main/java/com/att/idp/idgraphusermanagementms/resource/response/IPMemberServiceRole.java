package com.att.idp.idgraphusermanagementms.resource.response;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * This class represents a member's service role in the system.
 * It contains fields for memberNum, serviceId, serviceName, memberStatusCode, memberStatusName, createDate, lastModified, lastModifiedBy, instanceId, sorId, sorName, sorInvariantId, nickName, defaultAccount, dateDefaultEst, cpniImpacted, parentSorId, parentSorName, parentSorInvariantId, roleId, roleName, roleStatusCode, roleStatusName, and memberServiceRoleAttributes.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Jackson's @JsonProperty annotation to handle JSON serialization and deserialization for the memberServiceRoleAttributes field.
 *
 * The class uses Lombok's @Data annotation to generate getter and setter methods for all fields.
 *
 */
@Data
public class IPMemberServiceRole {

	private String memberNum;
	private String serviceId;
	private String serviceName;
	private String memberStatusCode;
	private String memberStatusName;
	private String createDate;
	private String lastModified;
	private String lastModifiedBy;
	private String instanceId;
	private String sorId;
	private String sorName;
	private String sorInvariantId;
	private String nickName;
	private String defaultAccount;
	private String dateDefaultEst;
	private String cpniImpacted;
	private String parentSorId;
	private String parentSorName;
	private String parentSorInvariantId;
	private String roleId;
	private String roleName;
	private String roleStatusCode;
	private String roleStatusName;
	private ArrayList<IPMemberServiceRoleAttributes> memberServiceRoleAttributes;

	@JsonProperty("attributes")
	public void setMemberServiceRoleAttributes(ArrayList<IPMemberServiceRoleAttributes> memberServiceRoleAttributes) {
		this.memberServiceRoleAttributes = memberServiceRoleAttributes;
	}
}