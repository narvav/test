package com.att.idp.idgraphusermanagementms.service.impl;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.UpgSecMemberIdHelper;
import com.att.idp.idgraphusermanagementms.resource.request.UpgSecMemberIdRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpgSecMemberIdResponse;
import com.att.idp.idgraphusermanagementms.service.UpgSecMemberIdService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.ws.rs.core.HttpHeaders;
import java.util.Map;

/**
 * Service implementation for upgrading a secondary member ID.
 * This class handles the business logic for upgrading a sub-user in the MPSYS system.
 */
@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class UpgSecMemberIdServiceImpl implements UpgSecMemberIdService {

    /**
     * Logger instance for logging events.
     */
    public static final Logger logger = LoggerFactory.getLogger(UpgSecMemberIdServiceImpl.class);

    /**
     * Class name for logging purposes.
     */
    private static final String sClassName = "UpgSecMemberIdServiceImpl";

    /**
     * Helper for UpgSecMemberId operations.
     */
    @Autowired
    private UpgSecMemberIdHelper upgSecMemberIdHelper;

    /**
     * Upgrades a sub-user in the MPSYS system.
     * This method handles the logic for upgrading a secondary member ID.
     *
     * @param upgSecMemberIdRequest The request object containing the details for upgrading a secondary member ID.
     * @param requestHeader             The HTTP headers of the request.
     * @return An UpgSecMemberIdResponse object containing the status and result of the operation.
     * @throws InvalidInputDataException If an error occurs during the operation.
     */
    @Override
    public UpgSecMemberIdResponse upgSecMemberId(UpgSecMemberIdRequest upgSecMemberIdRequest, HttpHeaders requestHeader) {
        Map<String, Object> hmResponse = null;
        String sMethodName = "upgSecMemberId";

        Map<String, Object> hmInput = CommonUtilHelper.objectToMap(upgSecMemberIdRequest);
        hmInput.put("secDomain", hmInput.remove("secDomain"));
        hmInput.put("secMemberId", hmInput.remove("secMemberId"));

        logger.info(SpiMarker.getInstance(), "UpgSecMemberIdServiceImpl.upgSecMemberId ASMIDS_01 : Calling UpgSecMemberIdHelper with Input : {}", hmInput);

        hmResponse = upgSecMemberIdHelper.upgSecMemberId(hmInput);
        logger.info(SpiMarker.getInstance(), "{}{}ASMIDS_02 : Response from UpgSecMemberIdHelper Helper : {}", sClassName, sMethodName, hmResponse);

        if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
            hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from UpgSecMemberIdHelper.upgSecMemberId");
            logger.info(SpiMarker.getInstance(), "{}{}ASMIDS_03 : Null response from UpgSecMemberIdHelper.upgSecMemberId", sClassName, sMethodName);
        } else {
            String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
            if (stAppStatusCode == null) {
                hmResponse = CommonUtilHelper.sysErrorHashMap("Null appStatusCode from UpgSecMemberIdHelper.upgSecMemberId");
                logger.info(SpiMarker.getInstance(), "{}{}ASMIDS_04 : Null appStatusCode from UpgSecMemberIdHelper.upgSecMemberId", sClassName, sMethodName);
            }
        }

        hmResponse.put("idp-trace-id", upgSecMemberIdRequest.getIdpTraceId());
        hmResponse.put(CommonDefs.TRANSACTION_NAME, upgSecMemberIdRequest.getTransactionName());
        UpgSecMemberIdResponse upgSecMemberIdResponse = CommonUtilHelper.generateUpgSecMemberIdResponse(hmResponse);
        String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

        if (sTxnRollBack != null) {
            throw new InvalidInputDataException(hmResponse);
        }
        logger.info(SpiMarker.getInstance(), "{}{}ASMIDS_05 : Response from UpgSecMemberIdServiceImpl.upgSecMemberId : {}",
                sClassName, sMethodName, upgSecMemberIdResponse);
        return upgSecMemberIdResponse;
    }
}