package com.att.idp.idgraphusermanagementms.resource.response;

import java.util.List;

import com.att.idp.core.exception.ServiceError;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class represents the response from the Check User ID Availability operation in the system.
 * It contains fields for transactionName, appStatusMsg, appStatusCode, appInfo, domain, suggestList, linkedFNUserStatus, errors, idpTraceId, and appCategoryCode.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Jackson's @JsonIgnore, @JsonProperty, @JsonIgnoreProperties, and @JsonInclude annotations to handle JSON serialization and deserialization.
 * It also uses Swagger's @ApiModel annotation to provide metadata for the Swagger UI.
 *
 * The class provides getter and setter methods for all fields.
 * It also overrides the toString method to return a string representation of the object.
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "CheckUserIdAvailabilityResponse")
public class CheckUserIdAvailabilityResponse {

	@JsonIgnore
	private String transactionName;
	private String appStatusMsg;
	private String appStatusCode;
	private String appInfo;
	@JsonIgnore
	private String domain;
	private List<SuggestHandle> suggestList;
	private String linkedFNUserStatus;
	@JsonProperty("error")
	private ServiceError errors;
	@JsonProperty("idp-trace-id")
	private String idpTraceId;
	@JsonIgnore
	private String appCategoryCode;
}