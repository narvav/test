
package com.att.idp.idgraphusermanagementms.queue.message.helpers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.helpers.FeatureManagerHelper;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.queue.message.sender.JMSQueueSender;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

@Component
public class UnlinkMemberIdQueueHelper {

	public static final Logger log = LoggerFactory.getLogger(UnlinkMemberIdQueueHelper.class);

	@Autowired
	private JMSQueueSender oJMSQueueSender;

	private static final String UPDATE_ALIAS_LIST_EVENT = "UpdateAliasList";

	private String sClassName = "UnlinkMemberIdQueueHelper";

	@Autowired
	FeatureManagerHelper featureManager;

	@Autowired
	PublishMqAehHelper publishMqAehHelper;

	/**
	 * doDbus
	 * 
	 * @param hmInput        HashMap
	 * @param hmSlidDB       HashMap
	 * @param alMemberDBList ArrayList
	 * @return HashMap
	 */
	public HashMap sendMessageToMQ(Map<String, Object> hmInput, HashMap hmSlidDB, ArrayList alMemberDBList) {
		String sMethodName = ".sendMessageToMQ.";
		String stAppInfo;
		String stAppStatusCode = null;
		String sAppInfo = null;
		String sNotificationEvent = null;
		String sUpdateAliasEvent = null;
		String sCallDBUS = "Y";
		String sAccountInvariantId = null;
		String sAccountType = null;
		String sAppStatusCode = null;

		HashMap hmtGuardDAInput = CommonUtil.getHashMap();
		HashMap hmDetachAlias = null;
		HashMap hmNotificationInput = null;
		HashMap hmResponse = CommonUtil.getHashMap();
		HashMap hmMemberContactEmail = null;
		HashMap hmNotificationData = null;
		HashMap hmDefaultAccountChanged = null;
		HashMap hmMemberDB = null;

		ArrayList alDbus = CommonUtil.getArrayList();
		ArrayList alDetachAlias = CommonUtil.getArrayList();
		ArrayList alNotificationData = null;
		ArrayList alMemberContactEmail = null;

		log.debug("{}{}UMQH_01 : Input hashmap : {}", sClassName, sMethodName,
				HtmlUtils.htmlEscape(String.valueOf(hmInput)));
		log.debug("{}{}UMQH_01 : Input hmSlidDB : {}", sClassName, sMethodName,
				HtmlUtils.htmlEscape(String.valueOf(hmSlidDB)));

		ArrayList alLinkInternetAccountDbusEvents = null;
		ArrayList alRemoveAccountDbusEvents = null;

		try {


			log.info("{}{}UMQH_01 : UPDATE_ALIAS_LIST_EVENT config : {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(UPDATE_ALIAS_LIST_EVENT)));

			sUpdateAliasEvent = UPDATE_ALIAS_LIST_EVENT;

			Iterator itrMemberDBList = alMemberDBList.iterator();
			String sThisHandle = null;
			String sThisDomain = null;

			ArrayList alDetachedUsers = CommonUtil.getArrayList();
			HashMap hmDetachedUsers = null;

			while (itrMemberDBList.hasNext()) {
				hmMemberDB = CommonUtil.getHashMap();
				hmDetachedUsers = CommonUtil.getHashMap();
				hmMemberDB = (HashMap) itrMemberDBList.next();
				sThisHandle = (String) hmMemberDB.get(MPSDefs.DB_MEMBER_NAME);
				sThisDomain = (String) hmMemberDB.get(MPSDefs.DB_DOMAIN_NAME);

				hmDetachAlias = CommonUtil.getHashMap();
				hmDetachAlias.put(CommonDefs.HANDLE, sThisHandle);
				hmDetachAlias.put(CommonDefs.DOMAIN, sThisDomain);
				hmDetachedUsers.put("memberId", sThisHandle + "@" + sThisDomain);
				hmDetachedUsers.put(CommonDefs.TYPE, "MID");

				alDetachAlias.add(hmDetachAlias);
				alDetachedUsers.add(hmDetachedUsers);
			}


			if (sUpdateAliasEvent != null && !sUpdateAliasEvent.equals(CommonDefs.DBUS_EVENT_NONE)) {

				hmtGuardDAInput.put(CommonDefs.EVENTNAME, sUpdateAliasEvent);
				hmtGuardDAInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));

				if (hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME) != null) {
					hmtGuardDAInput.put(CommonDefs.ORIG_TRANSACTION_NAME,
							hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME));
				} else {
					hmtGuardDAInput.put(CommonDefs.ORIG_TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
				}
				hmtGuardDAInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
				hmtGuardDAInput.put(CommonDefs.TRANSACTION_ID, hmInput.get("dbusTransactionId"));
				hmtGuardDAInput.put(CommonDefs.ORIG_TRANSID, hmInput.get("dbusTransactionId"));
				hmtGuardDAInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
				hmtGuardDAInput.put(CommonDefs.HANDLE, hmInput.get(CommonDefs.SLID));
				hmtGuardDAInput.put(CommonDefs.DOMAIN, CommonDefs.SLID_DUM);
				hmtGuardDAInput.put(CommonDefs.PARENT_HANDLE, hmInput.get(CommonDefs.SLID));
				hmtGuardDAInput.put(CommonDefs.PARENT_DOMAIN, CommonDefs.SLID_DUM);
				hmtGuardDAInput.put(MPSDefs.DB_SLID_MEMBER_NUM, hmSlidDB.get(MPSDefs.DB_MEMBER_NUM));
				hmtGuardDAInput.put("detachAlias", alDetachAlias);
				hmtGuardDAInput.put("hash_key", hmInput.get("dbusTransactionId"));
				alDbus.add(hmtGuardDAInput);

			}

			if (hmInput.containsKey(CommonDefs.LINK_INTERNET_ACCOUNT_DBUS_EVENTS)
					&& hmInput.get(CommonDefs.LINK_INTERNET_ACCOUNT_DBUS_EVENTS) != null) {
				alLinkInternetAccountDbusEvents = (ArrayList) hmInput.get(CommonDefs.LINK_INTERNET_ACCOUNT_DBUS_EVENTS);
			}
			if (alLinkInternetAccountDbusEvents != null && !alLinkInternetAccountDbusEvents.isEmpty()) {
				HashMap hmDbusEvent = null;
				for (int i = 0; i < alLinkInternetAccountDbusEvents.size(); i++) {
					hmDbusEvent = (HashMap) alLinkInternetAccountDbusEvents.get(i);
					hmDbusEvent.put("hash_key", hmInput.get("dbusTransactionId"));
				}
				alDbus.addAll(alLinkInternetAccountDbusEvents);
			}

			if (hmInput.containsKey(CommonDefs.REMOVE_ACCOUNT_DBUS_EVENTS)
					&& hmInput.get(CommonDefs.REMOVE_ACCOUNT_DBUS_EVENTS) != null) {
				alRemoveAccountDbusEvents = (ArrayList) hmInput.get(CommonDefs.REMOVE_ACCOUNT_DBUS_EVENTS);
			}
			if (alRemoveAccountDbusEvents != null && !alRemoveAccountDbusEvents.isEmpty()) {
				HashMap hmDbusEvent = null;
				for (int i = 0; i < alRemoveAccountDbusEvents.size(); i++) {
					hmDbusEvent = (HashMap) alRemoveAccountDbusEvents.get(i);
					hmDbusEvent.put("hash_key", hmInput.get("dbusTransactionId"));
				}
				alDbus.addAll(alRemoveAccountDbusEvents);
			}
			// END: PI18 Enhance UnlinkInternetAccount API to send hash_key for HaloC Event
			// sequencing
			// Notification Event (EDD)

			sNotificationEvent = CommonDefs.CONTEXT_NotificationEvent;

			String sRes2Bus = null;
			sRes2Bus = (String) hmInput.get(CommonDefs.RES2BUS);
			sRes2Bus = (sRes2Bus == null) ? "N" : sRes2Bus;

			

			// Notification Event (EDD)

			if (sNotificationEvent != null && !sNotificationEvent.equals(CommonDefs.DBUS_EVENT_NONE)) {

				// defaultAccountChange hashmap
				// we can reduce the below code by removing the iteration for memberDB.
				// As just prepare a hashmap with required values
				// (handle,domain,parent_child_ind,accountType,ban) and put that in hmInput
				// where we have put the sDefaultAccountMemberNum.

				Iterator itrMemberDBListDAC = alMemberDBList.iterator();
				HashMap hmMemberDBDAC = null;

				while (itrMemberDBListDAC.hasNext()) {
					hmMemberDBDAC = CommonUtil.getHashMap();
					hmMemberDBDAC = (HashMap) itrMemberDBListDAC.next();

					if (hmInput.containsKey("sDefaultAccountMemberNum") && hmInput.get("sDefaultAccountMemberNum")
							.equals(hmMemberDBDAC.get(MPSDefs.DB_MEMBER_NUM))) {

						HashMap hmDACNotificationInput = CommonUtil.getHashMap();

						sAccountInvariantId = (String) hmInput.get(CommonDefs.ACCOUNT_INVARIANT_ID);
						sAccountType = (String) hmInput.get(CommonDefs.ACCOUNT_TYPE);
						if (sAccountInvariantId != null && sAccountInvariantId.length() > 0 && sAccountType != null
								&& sAccountType.length() > 0) {
							hmDefaultAccountChanged = CommonUtil.getHashMap();
							alNotificationData = CommonUtil.getArrayList();
							hmDefaultAccountChanged.put(CommonDefs.DEFAULT_ACCOUNT_CHANGED, "Y");

							alNotificationData.add(hmDefaultAccountChanged);
							hmDACNotificationInput.put(CommonDefs.NOTIFICATION_DATA, alNotificationData);

							hmDACNotificationInput.put(CommonDefs.SERVICE_TYPE, sAccountType);
							if (sAccountType.equals(CommonDefs.UVERSE_SERVICE)) {
								// hmDACNotificationInput.put(CommonDefs.SUBEVENT,CommonDefs.DBUS_NOTIFICATION_SUBEVENT_SLID);
								// // no subEvent
							} else if (sAccountType.equals(CommonDefs.ECOMM_SERVICE)
									|| sAccountType.equals(CommonDefs.MOBILITY_SERVICE)) {
								hmDACNotificationInput.put(CommonDefs.SUBEVENT,
										CommonDefs.DBUS_NOTIFICATION_SUBEVENT_SLID);
								hmDACNotificationInput.put(CommonDefs.SOR_INVARIANT_ID,
										hmInput.get(CommonDefs.ACCOUNT_INVARIANT_ID));
							}
						}

						if (!hmDACNotificationInput.isEmpty()) {
							hmDACNotificationInput.put(CommonDefs.EVENTNAME, sNotificationEvent);
							hmDACNotificationInput.put(CommonDefs.DBUS_DICTIONARY_NAME,
									CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
							hmDACNotificationInput.put(CommonDefs.TRANSACTION_NAME,
									hmInput.get(CommonDefs.TRANSACTION_NAME));
							hmDACNotificationInput.put(CommonDefs.HANDLE, hmMemberDBDAC.get(MPSDefs.DB_MEMBER_NAME));
							hmDACNotificationInput.put(CommonDefs.DOMAIN, hmMemberDBDAC.get(MPSDefs.DB_DOMAIN_NAME));
							hmDACNotificationInput.put(CommonDefs.TRANSACTION_ID,
									hmInput.get("dbusTransactionId"));
							hmDACNotificationInput.put(CommonDefs.CALLING_SYSTEM_ID,
									hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
							hmDACNotificationInput.put(MPSDefs.DB_PARENT_CHILD_IND,
									hmMemberDBDAC.get(MPSDefs.DB_PARENT_CHILD_IND));
							hmDACNotificationInput.put(CommonDefs.SOR_NAME, hmInput.get("serviceSorName"));
							hmDACNotificationInput.put(CommonDefs.RES2BUS, sRes2Bus);
							hmDACNotificationInput.put(CommonDefs.CUSTOMER_TYPE,
									hmMemberDBDAC.get(MPSDefs.DB_ACCOUNT_TYPE));
							// 1408 : removed slid.dum from slid value.
							hmDACNotificationInput.put(CommonDefs.SLID, (hmInput.get(CommonDefs.SLID)));

							if (!hmDACNotificationInput.containsKey(CommonDefs.SUBEVENT)) {
								hmDACNotificationInput.put(CommonDefs.BAN, hmMemberDBDAC.get(MPSDefs.DB_BAN));
							}

							alDbus.add(hmDACNotificationInput);
						}
					}
				} // end of while loop

				// deleteAccount hashmap
				Iterator itrMemberDBListEDD = alMemberDBList.iterator();

				HashMap hmNotificationData1 = null;
				HashMap hmMemberContactEmail1 = null;
				HashMap hmNotificationInput1 = null;

				while (itrMemberDBListEDD.hasNext()) {
					hmMemberDB = CommonUtil.getHashMap();
					hmMemberDB = (HashMap) itrMemberDBListEDD.next();
					String sServiceType1 = null;
					hmNotificationInput = CommonUtil.getHashMap();
					alNotificationData = CommonUtil.getArrayList();

					hmNotificationInput.put(CommonDefs.EVENTNAME, sNotificationEvent);
					hmNotificationInput.put(CommonDefs.DBUS_DICTIONARY_NAME,
							CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
					hmNotificationInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
					hmNotificationInput.put(CommonDefs.HANDLE, hmMemberDB.get(MPSDefs.DB_MEMBER_NAME));
					hmNotificationInput.put(CommonDefs.DOMAIN, hmMemberDB.get(MPSDefs.DB_DOMAIN_NAME));
					hmNotificationInput.put(CommonDefs.TRANSACTION_ID, hmInput.get("dbusTransactionId"));
					hmNotificationInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
					hmNotificationInput.put(MPSDefs.DB_PARENT_CHILD_IND, hmMemberDB.get(MPSDefs.DB_PARENT_CHILD_IND));
					// 1408 : removed slid.dum from slid value.
					hmNotificationInput.put(CommonDefs.SLID, (hmInput.get(CommonDefs.SLID)));
					hmNotificationInput.put(CommonDefs.RES2BUS, sRes2Bus);
					hmNotificationInput.put(CommonDefs.SOR_NAME, hmMemberDB.get(MPSDefs.DB_SOR_NAME));

					if (hmMemberDB.containsKey(CommonDefs.SERVICES) && hmMemberDB.get(CommonDefs.SERVICES) != null) {
						HashMap hmMemberServices = null;

						String sServiceType = null;

						hmMemberServices = (HashMap) hmMemberDB.get(CommonDefs.SERVICES);
						Iterator itrMemberServiceKeys = hmMemberServices.entrySet().iterator();

						// iteration for member services
						while (itrMemberServiceKeys.hasNext()) {
							Entry mapEntry = (Entry) itrMemberServiceKeys.next();

							sServiceType = (String) mapEntry.getKey();

							if (sServiceType.equals(CommonDefs.UVERSE_SERVICE)) {
								hmNotificationInput.put(CommonDefs.SERVICE_TYPE, sServiceType);
								hmNotificationInput.put(CommonDefs.BAN, hmMemberDB.get(MPSDefs.DB_BAN));
								String sParentChildIind = (hmMemberDB.get(MPSDefs.DB_PARENT_CHILD_IND) == null) ? ""
										: (String) hmMemberDB.get(MPSDefs.DB_PARENT_CHILD_IND);
								if (sParentChildIind.equalsIgnoreCase(MPSDefs.MPS_PARENT))
									sServiceType1 = CommonDefs.UVERSE_SERVICE;
							} else if (sServiceType.equals(CommonDefs.ECOMM_SERVICE)) {
								hmNotificationInput.put(CommonDefs.SERVICE_TYPE, sServiceType);
								hmNotificationInput.put(CommonDefs.SUBEVENT,
										CommonDefs.DBUS_NOTIFICATION_SUBEVENT_SLID);
							} else if (sServiceType.equals(CommonDefs.MOBILITY_SERVICE)) {
								hmNotificationInput.put(CommonDefs.SERVICE_TYPE, sServiceType);
								hmNotificationInput.put(CommonDefs.SUBEVENT,
										CommonDefs.DBUS_NOTIFICATION_SUBEVENT_SLID);
							} else if (CommonDefs.SERVICE_VALUES.get(sServiceType).equals(CommonDefs.DIAL_SERVICE)
									|| CommonDefs.SERVICE_VALUES.get(sServiceType).equals(CommonDefs.DSL_SERVICE)
									|| CommonDefs.SERVICE_VALUES.get(sServiceType).equals(CommonDefs.PORTAL_SERVICE)) {
								hmNotificationInput.put(CommonDefs.SERVICE_TYPE, CommonDefs.PORTAL_SERVICE);
								hmNotificationInput.put(CommonDefs.SUBEVENT,
										CommonDefs.DBUS_NOTIFICATION_SUBEVENT_SLID);
							}

						}

					}

					// if sorName=LS
					if (hmMemberDB.get(MPSDefs.DB_SOR_NAME).equals("LS") && hmMemberDB.get(MPSDefs.DB_BAN) != null) {
						hmNotificationInput.put(CommonDefs.KEY_ACCOUNT_ID, hmMemberDB.get(MPSDefs.DB_BAN));
						hmNotificationInput.put(CommonDefs.CUSTOMER_TYPE, hmMemberDB.get(MPSDefs.DB_ACCOUNT_TYPE));
					}

					if (!sRes2Bus.equals("Y")) {

						hmNotificationData = CommonUtil.getHashMap();
						hmMemberContactEmail = CommonUtil.getHashMap();
						alMemberContactEmail = CommonUtil.getArrayList();

						hmMemberContactEmail.put(CommonDefs.CONTACT_EMAIL, hmSlidDB.get(MPSDefs.DB_CONTACT_EMAIL));
						hmMemberContactEmail.put(CommonDefs.CONTACT_EMAIL_STATUS,
								hmSlidDB.get(MPSDefs.DB_CONTACT_EMAIL_VALID));

						if (hmMemberContactEmail.get(CommonDefs.CONTACT_EMAIL_STATUS) != null
								&& hmMemberContactEmail.get(CommonDefs.CONTACT_EMAIL_STATUS).equals("Y")) {
							hmMemberContactEmail.put(CommonDefs.CONTACT_EMAIL_STATUS, "V");
						}

						alMemberContactEmail.add(hmMemberContactEmail);
						hmNotificationData.put(CommonDefs.MEMBER_CONTACT_EMAIL, alMemberContactEmail);
						hmNotificationData.put("deleteAccount", "Y");
						alNotificationData.add(hmNotificationData);
						hmNotificationInput.put(CommonDefs.NOTIFICATION_DATA, alNotificationData);
						alDbus.add(hmNotificationInput);

					} else {

						if (sServiceType1 != null && sServiceType1.equals(CommonDefs.UVERSE_SERVICE)) { // LS primary
																										// account
							hmNotificationData = CommonUtil.getHashMap();
							hmMemberContactEmail = CommonUtil.getHashMap();
							alMemberContactEmail = CommonUtil.getArrayList();

							hmMemberContactEmail.put(CommonDefs.CONTACT_EMAIL, hmSlidDB.get(MPSDefs.DB_CONTACT_EMAIL));
							hmMemberContactEmail.put(CommonDefs.CONTACT_EMAIL_STATUS,
									hmSlidDB.get(MPSDefs.DB_CONTACT_EMAIL_VALID));

							if (hmMemberContactEmail.get(CommonDefs.CONTACT_EMAIL_STATUS) != null
									&& hmMemberContactEmail.get(CommonDefs.CONTACT_EMAIL_STATUS).equals("Y")) {
								hmMemberContactEmail.put(CommonDefs.CONTACT_EMAIL_STATUS, "V");
							}

							alMemberContactEmail.add(hmMemberContactEmail);
							hmNotificationData.put(CommonDefs.MEMBER_CONTACT_EMAIL, alMemberContactEmail);
							hmNotificationData.put("deleteAccount", "Y");
							alNotificationData.add(hmNotificationData);
							hmNotificationInput.put(CommonDefs.NOTIFICATION_DATA, alNotificationData);
							hmNotificationInput.put(CommonDefs.SERVICE_TYPE, sServiceType1);

							// removed SUBEVENT as this is UVERSE flow, so no need of SUBEVENT
							hmNotificationInput.remove(CommonDefs.SUBEVENT);

							alDbus.add(hmNotificationInput);

							// Feb, 11 :: Defect 3200 notify slid [start]
							hmNotificationInput1 = CommonUtil.getHashMap();

							hmNotificationInput1.putAll(hmNotificationInput);
							hmNotificationInput1.put(CommonDefs.SUBEVENT, CommonDefs.DBUS_NOTIFICATION_SUBEVENT_SLID);
							hmNotificationInput1.remove(CommonDefs.BAN);

							alDbus.add(hmNotificationInput1);
							// [end]

						} else {
							// hashmap for non LS .net Id
							// deleteAccount to slid contact email
							hmNotificationData = CommonUtil.getHashMap();
							hmMemberContactEmail = CommonUtil.getHashMap();
							alMemberContactEmail = CommonUtil.getArrayList();

							hmMemberContactEmail.put(CommonDefs.CONTACT_EMAIL, hmSlidDB.get(MPSDefs.DB_CONTACT_EMAIL));
							hmMemberContactEmail.put(CommonDefs.CONTACT_EMAIL_STATUS,
									hmSlidDB.get(MPSDefs.DB_CONTACT_EMAIL_VALID));

							if (hmMemberContactEmail.get(CommonDefs.CONTACT_EMAIL_STATUS) != null
									&& hmMemberContactEmail.get(CommonDefs.CONTACT_EMAIL_STATUS).equals("Y")) {
								hmMemberContactEmail.put(CommonDefs.CONTACT_EMAIL_STATUS, "V");
							}

							alMemberContactEmail.add(hmMemberContactEmail);
							hmNotificationData.put(CommonDefs.MEMBER_CONTACT_EMAIL, alMemberContactEmail);
							hmNotificationData.put("deleteAccount", "Y");
							alNotificationData.add(hmNotificationData);
							hmNotificationInput.put(CommonDefs.NOTIFICATION_DATA, alNotificationData);
							alDbus.add(hmNotificationInput);

							// deleteAccount to member contact email

							hmNotificationData1 = CommonUtil.getHashMap();
							hmMemberContactEmail1 = CommonUtil.getHashMap();
							hmNotificationInput1 = CommonUtil.getHashMap();

							ArrayList alMemberContactEmail1 = CommonUtil.getArrayList();
							ArrayList alNotificationData1 = CommonUtil.getArrayList();

							hmNotificationInput1.putAll(hmNotificationInput);

							hmMemberContactEmail1.put(CommonDefs.CONTACT_EMAIL,
									hmMemberDB.get(MPSDefs.DB_CONTACT_EMAIL));
							hmMemberContactEmail1.put(CommonDefs.CONTACT_EMAIL_STATUS,
									hmMemberDB.get(MPSDefs.DB_CONTACT_EMAIL_VALID));

							if (hmMemberContactEmail1.get(CommonDefs.CONTACT_EMAIL_STATUS) != null
									&& hmMemberContactEmail1.get(CommonDefs.CONTACT_EMAIL_STATUS).equals("Y")) {
								hmMemberContactEmail1.put(CommonDefs.CONTACT_EMAIL_STATUS, "V");
							}

							alMemberContactEmail1.add(hmMemberContactEmail1);
							hmNotificationData1.put(CommonDefs.MEMBER_CONTACT_EMAIL, alMemberContactEmail1);
							hmNotificationData1.put("deleteAccount", "Y");

							alNotificationData1.add(hmNotificationData1);
							hmNotificationInput1.put(CommonDefs.NOTIFICATION_DATA, alNotificationData1);
							hmNotificationInput1.remove(CommonDefs.SLID);

							alDbus.add(hmNotificationInput1);

						}
					}
				} // end of while loop
			}


					//mq aeh switch
			String addUserMQAEHEnabled = featureManager.getValue("cfg-idgraph-adduser-mq-aeh-switch");
			addUserMQAEHEnabled = (addUserMQAEHEnabled != null && !addUserMQAEHEnabled.isEmpty()) ? addUserMQAEHEnabled : "MQ";
			log.info("ixp flag addUserMQAEHEnabled MQ AEH Value: {}", ESAPI.encoder().encodeForHTML(addUserMQAEHEnabled));

			//clm switch
			String addUserClmEnabled = featureManager.getValue("cfg-idgraph-adduser-notification-clm-switch");
			addUserClmEnabled = (addUserClmEnabled != null && !addUserClmEnabled.isEmpty()) ? addUserClmEnabled : "MQ";
			log.info("ixp flag addUserClmEnabled CLM Value: {}", ESAPI.encoder().encodeForHTML(addUserClmEnabled));

			String sCallDbus = (String) hmInput.get(CommonDefs.CALLDBUS);
			Map hmDbusInput = prepareDbusInput(hmInput,alDbus);
			if (sCallDbus == null || sCallDbus.trim().isEmpty() || sCallDbus.equalsIgnoreCase(CommonDefs.IND_Y)) {

				hmResponse = (HashMap) publishMqAehHelper.invokeMqAEH(hmDbusInput, hmInput, alDbus, sClassName,
						sMethodName, addUserMQAEHEnabled, addUserClmEnabled);

				if (MapUtils.isEmpty(hmResponse)) {
					stAppInfo = "Null Response returned from JMSQueueSender.send";
					hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					log.info("{}{}AUQS_03 : {}", sClassName, sMethodName, stAppInfo);
					return  hmResponse;
				}

				stAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);

				if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {

					stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
					log.info("{}{}AUQS_04 :{} ", sClassName, sMethodName, CommonUtilHelper.sanitizeForLog(String.valueOf(stAppInfo)));
					hmResponse = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
					hmResponse.put("isTransactionRollback", true);
					return hmResponse;
				}
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
			}else {
				hmResponse = CommonErrorMap.makeCommonStatusMap(CErrorDefs.COMMON_SUCCESS_NUM, "");
				hmResponse.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, alDbus);

			}

		return  hmResponse;


		} catch (Exception exp) {
			hmResponse = CommonErrorMap.makeExceptionMap(exp, log);
			stAppInfo = "Exception thrown error hash map =  " + hmResponse;
			log.info("{}{}UUH_114 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(stAppInfo));

		} finally {
			if (hmResponse == null || hmResponse.isEmpty()) {
				stAppInfo = "Response from JMSQueueSender.send is NULL";
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				log.info("{}{}AUQS_05 : {}", sClassName, sMethodName, CommonUtilHelper.sanitizeForLog(stAppInfo));
			}
			log.info("{}{} HLP999 : response from UnlinkMemberIdQueueHelper: {}", sClassName, sMethodName,
					CommonUtilHelper.sanitizeForLog(String.valueOf(hmResponse)));
		}

		 return (HashMap) hmResponse;
	}
	private Map<String,Object> prepareDbusInput(Map<String, Object> hmInput,ArrayList alDbusInp) {
		HashMap<String,Object> hmDbusInput = CommonUtil.getHashMap();
		hmDbusInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
		hmDbusInput.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get("dbusTransactionId"));
		hmDbusInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
		hmDbusInput.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		hmDbusInput.put(CommonDefs.EVENTNAME, CommonDefs.MICRO_SERVICE_EVENT);
		hmDbusInput.put(CommonDefs.MS_OPERTAION, (String) hmInput.get(CommonDefs.TRANSACTION_NAME));
		hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, (String) hmInput.get("dbusTransactionId"));
		hmDbusInput.put(CommonDefs.EVENTS_DATA, alDbusInp);
	
		return hmDbusInput;
	}
}