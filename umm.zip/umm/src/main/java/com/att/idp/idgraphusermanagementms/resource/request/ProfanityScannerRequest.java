package com.att.idp.idgraphusermanagementms.resource.request;

import java.util.HashMap;
import java.util.Map;

import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@Schema(name = "ProfanityScannerRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProfanityScannerRequest {

    protected String callingSystemId;

    private final String transactionName = ProfileOrchestrationConstants.PROFANITY_SCANNER_TRANSACTION_NAME;

    @Schema(name = "scanItem")
    @NotBlank(message = "scanItem must not be null and must contain between 1 and 1000 characters.|ProfanityScanner")
    @Size(min = 1, max = 1000, message =  "scanItem length is invalid|ProfanityScanner")
    private String scanItem;

    @Schema(name = "scanItemType")
    @NotBlank(message = "scanItemType must not be null and must contain between 1 and 20 characters.|ProfanityScanner")
    @Size(min = 1, max = 20, message =  "scanItemType length is invalid|ProfanityScanner")
    private String scanItemType;

    @JsonProperty("idp-trace-id")
    @Schema(name = "idpTraceId")
    private String idpTraceId;

    @JsonAnySetter
    @JsonAnyGetter
    public Map<String,Object> unknownAttributes = new HashMap<>();
}

