package com.att.idp.idgraphusermanagementms.db.helper;

	import com.att.idp.core.exception.ServiceException;
	import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
	import com.att.idp.logging.marker.SpiMarker;
	import com.att.mpsys.common.utils.CErrorDefs;
	import com.att.mpsys.common.utils.CommonErrorMap;
	import com.att.mpsys.common.utils.MPSDefs;
	import com.att.mpsys.common.utils.StatusMsg;
	import org.slf4j.Logger;
	import org.slf4j.LoggerFactory;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.dao.DataAccessException;
	import org.springframework.jdbc.core.ArgumentPreparedStatementSetter;
	import org.springframework.jdbc.core.JdbcTemplate;
	import org.springframework.stereotype.Component;

	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.HashMap;
	import java.util.List;
	import java.util.Map;

	/**
	 * Helper class for querying member service information by group number.
	 * Provides methods to fetch member service details from the database using Spring's JdbcTemplate.
	 * Handles error scenarios and maps result sets to domain objects.
	 */
	@Component
	public class GetProfileByGroupNumDBHelper {

	    /** Class name for logging context */
	    private static final String CLASS_NAME = "GetProfileByGroupNumDBHelper";
	    /** Logger instance for this class */
	    public static final Logger logger = LoggerFactory.getLogger(GetProfileByGroupNumDBHelper.class);

	    /** JdbcTemplate for database operations, injected by Spring */
	    @Autowired
	    private JdbcTemplate jdbcTemplate;

	    @Autowired
	    private ErrorMetricHandler errorMetricHandler;

	    /** SQL query to fetch secondary member information */
	    String secMemInfoQuery = "select mem.member_num, mem.member_state, mem.agg_service_status, " +
	            "stat.status_name as last_member_status_name, memservice.service_id from member mem, " +
	            "memberservice memservice, status stat where mem.member_num = memservice.member_num(+) and  " +
	            "mem.last_member_status = stat.status_code(+) and mem.parent_child_ind = 'C' and mem.group_num in " +
	            "(select m.group_num from member m, domain d where m.domain_id = d.domain_id(+) and m.member_name = ? and " +
	            " d.domain_name= ? )";

	    /**
	     * Queries member service information for a given member name and domain name.
	     * Handles null JdbcTemplate, empty results, and database exceptions.
	     *
	     * @param memName the member name to query
	     * @param domainName the domain name to query
	     * @return a HashMap containing member service info or error status
	     * @throws ServiceException if a service-level error occurs
	     */
	    public HashMap queryMemberServiceInfo(String memName, String domainName) throws ServiceException {
	        String sMethodName = ".queryMemberServiceInfo.";
	        HashMap<String, Object> memServices =  new HashMap<>();
	        List<Map<String, Object>> queryResult = null;
	        try {

	            // Defensive check for JdbcTemplate
	            if (jdbcTemplate == null) {
	                memServices = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "jdbcTemplate is null.");
	                logger.error("response : {}", memServices);
	                return memServices;
	            }

	            Object[] params =new Object[]{memName, domainName};
	            queryResult = jdbcTemplate.query(
	                    secMemInfoQuery,
	                    new ArgumentPreparedStatementSetter(params),
	                    (rs, rowNum) -> mapResultSetToMemberInfoMap(rs)
	            );

	            // Populate result map based on query outcome
	            if(queryResult != null && !queryResult.isEmpty()) {
	                memServices.put("memberServiceInfo", queryResult);
	                memServices.put(MPSDefs.APP_STATUS_CODE, MPSDefs.MPS_SUCCESS);
	                memServices.put(MPSDefs.APP_STATUS_MSG, MPSDefs.MPS_ALL_OK);
	            }
	            else {
	                memServices = StatusMsg.makeSQLStatus(MPSDefs.REC_NOT_FOUND, MPSDefs.REC_NOT_FOUND_MSG, MPSDefs.SQL_ERR,
	                        MPSDefs.SQL_ERR_MSG, MPSDefs.NO_ROW_UPDATED);
	                logger.info("DBTOOLS34 : No row found");
	            }
	        } catch (DataAccessException e) {
	            errorMetricHandler.recordDbErrorMetric();
	            memServices = StatusMsg.makeExceptionSQLStatus(e);
	            logger.error("{}{}DBTOOLS_E4 : Exception ={}", CLASS_NAME, sMethodName, e);
	        }
	        finally{
	            logger.info(SpiMarker.getInstance(), "{}{}DBTOOLS999 : STATUS = {}", CLASS_NAME, sMethodName, memServices);
	        }
	        return memServices;
	    }

	    /**
	     * Maps the current row of the given ResultSet to a Map representing account/member information.
	     *
	     * @param rs the ResultSet positioned at the desired row
	     * @return a Map containing account/member information
	     * @throws SQLException if a database access error occurs
	     */
	    public Map<String, Object> mapResultSetToMemberInfoMap(ResultSet rs) throws SQLException {
	        Map<String, Object> memberData = new HashMap<>();
	        memberData.put(MPSDefs.DB_MEMBER_NUM, rs.getString(MPSDefs.DB_MEMBER_NUM));
	        memberData.put(MPSDefs.DB_MEMBER_STATE, rs.getString(MPSDefs.DB_MEMBER_STATE));
	        memberData.put(MPSDefs.DB_AGG_SERVICE_STATUS, rs.getString(MPSDefs.DB_AGG_SERVICE_STATUS));
	        memberData.put(MPSDefs.DB_LAST_MEMBER_STATUS_NAME, rs.getString(MPSDefs.DB_LAST_MEMBER_STATUS_NAME));
	        memberData.put(MPSDefs.DB_SERVICE_ID, rs.getString(MPSDefs.DB_SERVICE_ID));
	        return memberData;
	    }
	}