package com.att.idp.idgraphusermanagementms.resource.request;

import static org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString;
import static org.apache.commons.lang3.builder.ToStringStyle.JSON_STYLE;

import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * This class represents an Account in the system.
 * It contains fields for accountType and accountInvariantId, both of which have size constraints.
 * The accountType field has a minimum length of 1 and a maximum length of 30.
 * The accountInvariantId field has a minimum length of 1 and a maximum length of 255.
 *
 * The class uses Lombok's @Data annotation to generate getter and setter methods for both fields.
 * It also overrides the toString method to provide a JSON-style representation of the object.
 *
 */
@Data
public class Account {

	@Size(min=1, max=30,message="accountType length is invalid|InquireAssociatedAccessIds")
	protected String accountType;

	@Size(min=1, max=255,message="accountInvariantId length is invalid|InquireAssociatedAccessIds")
	protected String accountInvariantId;

	@Override
	public String toString() {
		return reflectionToString(this, JSON_STYLE);
	}
}