package com.att.idp.idgraphusermanagementms.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.db.helper.AddMemberDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.AddServiceDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.DBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.MemberDBHelper;
import com.att.idp.idgraphusermanagementms.queue.message.helpers.RegisterEmailUserQueueHelper;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * The RegisterEmailUserHelper class is a helper class that provides methods to register a user with an email.
 * It includes methods to validate date of birth, validate CTN, add a user, add a service, and add a contact.
 * This class is annotated with @Component, meaning it is an autodetectable Spring Bean and can be automatically wired into other components using Spring's dependency injection facilities.
 */
@Component
public class RegisterEmailUserHelper {

	private static final String info = "$Id: master/com/att/idp/idgraphusermanagementms/helper/RegisterEmailUserHelper.java v1 2024-03-20 pb6583 $;";
	private static String sClassName = "RegisterEmailUserHelper";
	private static final String ERROR_ENUM = "ErrorEnum";
	public static final Logger logger = LoggerFactory.getLogger(RegisterEmailUserHelper.class);

	@Value("${PORTAL_MIN_AGE}")
	private String propPortalMinAge;

	@Autowired
	private AddServiceDBHelper addServiceDbHelper;

	@Autowired
	private AddMemberDBHelper addMemeberDBHelper;

	@Autowired
	private MemberDBHelper memberDBHelper;

	@Autowired
	private DBHelper oDBHelper;

	@Autowired
	private IPTxnRateLimitHelper oIPTxnRateLimitHelper;

	@Autowired
	private CTNEligibilityHelper oCTNEligibilityHelper;

	@Autowired
	private AddUserHelper addUserhelper;

	@Autowired
	private UpdateUserContactCBRHelper updateUserContactCBRHelper;

	@Autowired
	private RegisterEmailUserQueueHelper registerEmailUserQHelper;

	/**
	 * This method is responsible for registering a user with an email.
	 * It first validates the input and then performs a series of operations including IP transaction rate limit check, age eligibility check, CTN validation, user addition, service addition, and contact addition.
	 * If any of these operations fail, it returns the corresponding error.
	 * If all operations are successful, it returns a success message.
	 *
	 * @param hmInput A Map containing the input parameters for the method. It should include necessary information for user registration such as handle, domain, password, contact email, date of birth, gender, language, and other related information.
	 * @return A Map containing the result of the method. It includes the application status code and other information.
	 */
	public Map<String, Object> registerEmailUser(Map<String, Object> hmInput) {

		String sMethodName = ".registerEmailUser.";
		boolean isTransactionRollbackOnError = false;
		Map<String, Object> hmResult = null;
		String stAppInfo = null;
		String stAppStatusCode = null;
		ArrayList<Map<String, Object>> alConsDbus = new ArrayList<>();
		logger.info(SpiMarker.getInstance(), "{}{}HLP000 : Input Hash : {}", sClassName, sMethodName,
				StructuredArguments.entries(hmInput));

		if (hmInput == null || hmInput.isEmpty()) {
			stAppInfo = "Input Hash is NULL";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			logger.info("{}{}REUH_01 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		try {

			// Calling IPTxnRateLimit
			String stRegClientIpAddress = (String) hmInput.get(CommonDefs.REG_CLIENT_IP_ADDRESS);
			if (stRegClientIpAddress != null && !stRegClientIpAddress.trim().isEmpty()) {
				HashMap<String, Object> hmRegClientInp = new HashMap<>();
				hmRegClientInp.put(CommonDefs.TRANSACTION_NAME, CommonDefs.TXN_RATE_LIMIT_STATUS);
				hmRegClientInp.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
				hmRegClientInp.put(CommonDefs.IP_ADDRESS, stRegClientIpAddress);
				hmRegClientInp.put(CommonDefs.INCREMENT_COUNTER, CommonDefs.IND_Y);
				hmRegClientInp.put(CommonDefs.IS_EXTERNAL_CALL, CommonDefs.IND_N);
				hmResult = oIPTxnRateLimitHelper.verifyRegClientIpAddress(hmRegClientInp);
				if (hmResult == null || hmResult.isEmpty()) {
					stAppInfo = "Null or empty response from IPTxnRateLimitHelper.verifyRegClientIpAddress ";
					logger.error("{}{}REUH_02 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					return hmResult;
				}
				stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

				if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					stAppInfo = (String) hmResult.get(MPSDefs.APP_INFO);
					logger.info("{}{}REUH_03 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				} else {
					isTransactionRollbackOnError = true;
				}

			}

			// Validating DOB
			String sInpDOB = (String) hmInput.get(CommonDefs.DATE_OF_BIRTH);
			hmResult = checkAgeEligibility(sInpDOB);

			stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			}

			// Validating CTN
			hmResult = validateCTN(hmInput);
			stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			} else {
				isTransactionRollbackOnError = true;
			}

			// Calling AddUser for MID
			HashMap<String, Object> hmAddUserInp = new HashMap<String, Object>();

			hmResult = addUser(hmInput, hmAddUserInp);
			if (hmResult == null || hmResult.isEmpty()) {
				stAppInfo = "Null or empty response from addUser method ";
				logger.error("{}{}REUH_04 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				return hmResult;
			}
			stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			} else {
				isTransactionRollbackOnError = true;
			}

			String stGroup_num = (String) hmResult.get(CommonDefs.GROUP_NUM);
			String stDBMemberNum = (String) hmResult.get(CommonDefs.GUID);

			// populating addmemberEvent for MQ
			alConsDbus.addAll(registerEmailUserQHelper.populateAddMemberEventData(hmInput, hmResult, true));

			// Adding Portal Service
			ArrayList alInputService = (ArrayList) hmInput.get(CommonDefs.SERVICES);
			HashMap<String, Object> hmInputService = null;
			if (alInputService != null && !alInputService.isEmpty()) {
				Iterator iter = alInputService.iterator();
				while (iter.hasNext()) {
					hmInputService = (HashMap) iter.next();
					String sServiceType = (String) hmInputService.get(CommonDefs.SERVICE_TYPE);
					hmResult = (HashMap<String, Object>) addService(hmInput, stGroup_num, stDBMemberNum,
							hmInputService);

					if (hmResult == null || hmResult.isEmpty()) {
						stAppInfo = "Null or empty response while adding portal service";
						logger.error("{}{}REUH_05 : {}", sClassName, sMethodName, stAppInfo);
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
						return hmResult;
					}
					stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

					if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
						return hmResult;
					} else {
						isTransactionRollbackOnError = true;
					}

					if (sServiceType.equals(MPSDefs.PORTAL_SERVICE)) {
						HashMap<String, Object> hmPortalUser = new HashMap<>();
						int iServiceId = oDBHelper.getServiceId(sServiceType);
						String stServiceId = String.valueOf(iServiceId);
						hmPortalUser.put(MPSDefs.DB_MEMBER_NUM, stDBMemberNum);
						hmPortalUser.put(MPSDefs.DB_SERVICE_ID, stServiceId);
						hmPortalUser.put(MPSDefs.DB_PORTAL_PROVIDER, CommonDefs.PORTAL_PROVIDER_ATT_YAHOO);
						hmPortalUser.put(MPSDefs.DB_LAST_MODIFIED_BY, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
						hmPortalUser.put(MPSDefs.DB_PLITE_IND, CommonDefs.IND_Y);
						logger.debug("{}{}REUH_06 : Calling MemberDBHelper.addPortalUser with Input: {}",
								sClassName, sMethodName, hmPortalUser);
						hmResult = addMemeberDBHelper.addPortalUser(hmPortalUser);
						logger.debug("{}{}REUH_07: Response from MemberDBHelper.addPortalUser : {}", sClassName,
								sMethodName, hmResult);
						if (hmResult == null || hmResult.isEmpty()) {
							stAppInfo = "Null or empty response from MemberDBHelper.addPortalUser";
							logger.error("{}{}REUH_08 : {}", sClassName, sMethodName, stAppInfo);
							hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
							return hmResult;
						}
						stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

						if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
							stAppInfo = (String) hmResult.get(MPSDefs.APP_INFO);
							logger.error("{}{}REUH_09 : {}", sClassName, sMethodName, stAppInfo);
							return hmResult;
						} else {
							isTransactionRollbackOnError = true;
						}

					}
				}
			}

			// Adding linked access id and updating slid_member_num of MID
			String sHandle = (String) hmInput.get(CommonDefs.HANDLE);
			String sDomain = (String) hmInput.get(CommonDefs.DOMAIN);
			String sSlidHandle = null;
			String sAccountType = (String) hmInput.get(CommonDefs.ACCOUNT_TYPE);
			String sSlidMemberNum = null;

			if (sAccountType != null && !sAccountType.isEmpty() && MPSDefs.DB_CONSUMER.equalsIgnoreCase(sAccountType)) {
				sSlidHandle = sHandle + "@" + sDomain;
				hmAddUserInp.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(ProfileOrchestrationConstants.IDPTRACEID));
				hmAddUserInp.put(CommonDefs.HANDLE, sSlidHandle);
				hmAddUserInp.put(CommonDefs.DOMAIN, CommonDefs.SLID_DUM);
				hmAddUserInp.put("byPassCheckIdAvailability", "Y");
				hmAddUserInp.entrySet().removeIf(entry->entry.getValue() == null);

				logger.info(SpiMarker.getInstance(),"{}{}REUH_10 : Calling AddUserHelper.addUser with Input: {}", sClassName, sMethodName,
						StructuredArguments.entries(hmAddUserInp));
				hmResult = (HashMap<String, Object>) addUserhelper.addUser(hmAddUserInp);
				logger.info(SpiMarker.getInstance(),"{}{}REUH_11 : Response from  AddUserHelper.addUser with Input: {}", sClassName,
						sMethodName, StructuredArguments.entries(hmResult));
				if (hmResult == null || hmResult.isEmpty()) {
					stAppInfo = "Null or empty response from AddUserHelper.addUser";
					logger.error("{}{}REUH_12 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					return hmResult;
				}
				stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

				if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					stAppInfo = (String) hmResult.get(MPSDefs.APP_INFO);
					logger.info("{}{}REUH_13 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				} else {
					isTransactionRollbackOnError = true;
				}

				sSlidMemberNum = (String) hmResult.get(CommonDefs.GUID);

				// populating addMember MQ event for linked access id
				alConsDbus.addAll(registerEmailUserQHelper.populateAddMemberEventData(hmInput, hmResult, false));

				HashMap<Object, Object> hmUpdateMember = new HashMap<>();
				HashMap<Object, Object> hmMPSInput = new HashMap<>();
				ArrayList<Object> alMember = new ArrayList<>();
				hmUpdateMember.put(MPSDefs.DB_MEMBER_NUM, stDBMemberNum);
				hmUpdateMember.put(MPSDefs.DB_SLID_MEMBER_NUM, sSlidMemberNum);
				hmUpdateMember.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);
				alMember.add(hmUpdateMember);
				hmMPSInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
				hmMPSInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
				hmMPSInput.put("member", alMember);
				logger.debug("{}{}REUH_14 : Calling MemberDBHelper.processData with Input: {}", sClassName,
						sMethodName, hmMPSInput);
				hmResult = memberDBHelper.processData(hmMPSInput);
				logger.debug("{}{}REUH_15 : Response MemberDBHelper.processData: {}", sClassName, sMethodName,
						hmResult);
				if (hmResult == null || hmResult.isEmpty()) {
					stAppInfo = "Null or empty response from oMPSDB_TMEMBER_H.processData";
					logger.error("{}{}REUH_16 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					return hmResult;
				}
				stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

				if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					stAppInfo = (String) hmResult.get(MPSDefs.APP_INFO);
					logger.info("{}{}REUH_17 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				} else {
					isTransactionRollbackOnError = true;
				}
			}

			// Adding User contact
			hmResult = addContact(hmInput, stDBMemberNum);
			if (hmResult == null || hmResult.isEmpty()) {

				stAppInfo = "UpdateUserContactCBRHelper returned null / empty response";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.error("{}{}REUH_18 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			} else {
				isTransactionRollbackOnError = true;
			}

			// populate MQ data for UpdateAlias Event
			if (sSlidMemberNum != null) {
				alConsDbus.add(
						registerEmailUserQHelper.populateUpdateAliasEventData(hmInput, sSlidHandle, sSlidMemberNum));
			}

			// dbus call
			Map hmDbusResult = registerEmailUserQHelper.sendMessageToMQ(hmInput, alConsDbus, sSlidMemberNum, stDBMemberNum);

			logger.info("{}{}REUH_19 :Response from RegisterEmailUserQueueHelper.sendMessageToMQ: {}", sClassName, sMethodName,
					hmDbusResult);

			if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmDbusResult)) {
				hmResult = CommonUtilHelper.sysErrorHashMap("null response from RegisterEmailUserQueueHelper.sendMessageToMQ");
				isTransactionRollbackOnError = true;
				return hmResult;
			} else {

				stAppStatusCode = (String) hmDbusResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
				if (StringUtils.isBlank(stAppStatusCode)) {
					isTransactionRollbackOnError = true;
					hmResult = CommonUtilHelper
							.sysErrorHashMap("null response from RegisterEmailUserQueueHelper.sendMessageToMQ");
					return hmResult;
				} else if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					isTransactionRollbackOnError = true;
					stAppInfo = (String) hmDbusResult.get(CommonDefs.COMMON_APP_INFO);
					logger.info("{}{}REUH_20 : {}", sClassName, sMethodName,
							HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
					hmResult = hmDbusResult;
					return hmResult;
				}

			}

			// Default success if no error occur
			String guid = (String) hmResult.get(MPSDefs.DB_MEMBER_NUM);
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
			hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown registerEmailUser method : " + hmResult;
			logger.error("{}{}REUH_EXCEP : {}", sClassName, sMethodName, stAppInfo);

		} finally {

			String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);

			// transaction rollback
			if (isTransactionRollbackOnError && sAppCategoryCode != null
					&& !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
				hmResult.put("isTransactionRollback", "Y");
			}
			logger.info("{}{}HLP999 : hmResult = {}", sClassName, sMethodName,
					StringUtils.normalizeSpace(hmResult.toString()));

		}

		return hmResult;

	}

	/**
	 * Validation DOB Eligibility
	 * 
	 * @param stDateOfBirthToVerify
	 * @return
	 */
	private HashMap<String, Object> checkAgeEligibility(String stDateOfBirthToVerify) {
		String sMethodName = ".checkAgeEligibility.";
		String stAppInfo = null;
		HashMap<String, Object> hmResult = CommonUtil.getHashMap();
		try {
			logger.info("{}{}REUH_CAE.01 : PORTAL_MIN_AGE : {}", sClassName, sMethodName, propPortalMinAge);
			if (propPortalMinAge != null && !propPortalMinAge.equals("0")) {
				if (stDateOfBirthToVerify != null && !stDateOfBirthToVerify.trim().isEmpty()) {
					boolean isEligible = CheckAgeEligibilityHelper.checkAgeEligibility(stDateOfBirthToVerify,
							propPortalMinAge);
					if (!isEligible) {
						stAppInfo = "Member is less than PORTAL_MIN_AGE :: " + propPortalMinAge + " years";
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_AGE_MIN_VIOLATION_NUM, stAppInfo);
						logger.info("{}{}REUH_CAE.02 : {}", sClassName, sMethodName, stAppInfo);
						return hmResult;
					}
				} else {
					stAppInfo = "inputDateOfBirth can not be null or empty for Registration.";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
					logger.info("{}{}REUH_CAE.03 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
			}
			stAppInfo = "Input DOB is eligible";
			logger.info("{}{}REUH_CAE.04 : {}", sClassName, sMethodName, stAppInfo);
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown checkAgeEligibility method : " + hmResult;
			logger.error("{}{}REUH_CAE.05 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}
		return hmResult;
	}

	private HashMap<String, Object> validateCTN(Map<String, Object> hmInput) {
		String sMethodName = ".validateCTN.";
		HashMap<String, Object> hmResult = CommonUtil.getHashMap();
		String stAppInfo = null;
		try {
			ArrayList alInputContacts = (ArrayList) hmInput.get(MPSDefs.KEY_CONTACTS);
			if (alInputContacts != null && !alInputContacts.isEmpty()) {
				Iterator<?> iter = alInputContacts.iterator();
				while (iter.hasNext()) {
					HashMap<String, Object> hmInputContact = (HashMap<String, Object>) iter.next();
					HashMap<Object, Object> hmChkCTNElgInp = null;

					String sTn = (String) hmInputContact.get(CommonDefs.TN);
					hmChkCTNElgInp = new HashMap<>();
					hmChkCTNElgInp.put(CommonDefs.TRANSACTION_NAME, CommonDefs.TXN_RATE_LIMIT_STATUS);
					hmChkCTNElgInp.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
					hmChkCTNElgInp.put(CommonDefs.INCREMENT_COUNTER, CommonDefs.IND_Y);
					hmChkCTNElgInp.put(CommonDefs.CTN, sTn);
					hmChkCTNElgInp.put(CommonDefs.IS_EXTERNAL_CALL, CommonDefs.IND_N);
					logger.info("{}{}REUH_VCTN.01 : Calling CTNEligibilityHelper.checkCTNEligibility with Input: {}",
							sClassName, sMethodName, hmChkCTNElgInp);
					hmResult = oCTNEligibilityHelper.checkCTNEligibility(hmChkCTNElgInp);

					logger.info("{}{}REUH_VCTN.02 : Response from CTNEligibilityHelper.checkCTNEligibility: {}",
							sClassName, sMethodName, hmResult);

					if (hmResult == null || hmResult.isEmpty()) {
						stAppInfo = "Null or empty response from CTNEligibilityHelper.checkCTNEligibility";
						logger.error("{}{}REUH_VCTN.03 : {}", sClassName, sMethodName, stAppInfo);
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
						return hmResult;
					}

				}

			} else {
				stAppInfo = "No CTN to Validate";
				logger.info("{}{}REUH_VCTN.04 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
			}
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown validateCTN method : " + hmResult;
			logger.error("{}{}REUH_VCTN.05 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		return hmResult;
	}

	private Map<String, Object> addUser(Map<String, Object> hmInput, HashMap<String, Object> hmAddUserInp) {
		Map<String, Object> hmResult = null;
		String sMethodName = ".addUser.";
		try {

			String stContactEmail = (String) hmInput.get(CommonDefs.CONTACT_EMAIL);
			String stOnlineSecAns1 = (String) hmInput.get(CommonDefs.ONLINE1_SECURITY_ANSWER);
			String stOnlineSecQues1 = (String) hmInput.get(CommonDefs.ONLINE1_SECURITY_QUESTION);
			String stOnlineSecAns2 = (String) hmInput.get(CommonDefs.ONLINE2_SECURITY_ANSWER);
			String stOnlineSecQues2 = (String) hmInput.get(CommonDefs.ONLINE2_SECURITY_QUESTION);
			String stLanguage = (String) hmInput.get(CommonDefs.LANGUAGE);
			String stFirstName = (String) hmInput.get(CommonDefs.FIRST_NAME);
			String stLastName = (String) hmInput.get(CommonDefs.LAST_NAME);
			String sIsExternalCall = (String) hmInput.get(CommonDefs.IS_EXTERNAL_CALL);
			String stSor = (String) hmInput.get(CommonDefs.SOR);
			String stGender = (String) hmInput.get(CommonDefs.GENDER);
			String stDateOfBirth = (String) hmInput.get(CommonDefs.DATE_OF_BIRTH);
			String stProofingZip = (String) hmInput.get(CommonDefs.PROOFING_ZIP);
			hmAddUserInp.put(CommonDefs.ORIG_TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
			hmAddUserInp.put(CommonDefs.TRANSACTION_NAME, CommonDefs.ADD_USER_TRANSACTION_NAME);
			hmAddUserInp.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(ProfileOrchestrationConstants.IDPTRACEID));
			hmAddUserInp.put(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID, (String) hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
			hmAddUserInp.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
			hmAddUserInp.put(CommonDefs.HANDLE, (String) hmInput.get(CommonDefs.HANDLE));
			hmAddUserInp.put(CommonDefs.DOMAIN, (String) hmInput.get(CommonDefs.DOMAIN));
			hmAddUserInp.put(CommonDefs.PASSWORD_CLEAR, hmInput.get(CommonDefs.PASSWORD_CLEAR));
			hmAddUserInp.put("isMIDInRequest", true);
			hmAddUserInp.put(CommonDefs.IS_EXTERNAL_CALL, CommonDefs.IND_N);
			hmAddUserInp.put(CommonDefs.CALLDBUS, CommonDefs.IND_N);
			
			if (stOnlineSecQues1 != null && !stOnlineSecQues1.trim().isEmpty()) {
				hmAddUserInp.put(CommonDefs.ONLINE1_SECURITY_QUESTION, stOnlineSecQues1.trim());
			}
			if (stOnlineSecAns1 != null && !stOnlineSecAns1.trim().isEmpty()) {
				hmAddUserInp.put(CommonDefs.ONLINE1_SECURITY_ANSWER, stOnlineSecAns1.trim());
			}

			if (stOnlineSecQues2 != null && !stOnlineSecQues2.trim().isEmpty()) {
				hmAddUserInp.put(CommonDefs.ONLINE2_SECURITY_QUESTION, stOnlineSecQues2.trim());
			}
			if (stOnlineSecAns2 != null && !stOnlineSecAns2.trim().isEmpty()) {
				hmAddUserInp.put(CommonDefs.ONLINE2_SECURITY_ANSWER, stOnlineSecAns2.trim());
			}
			if (stContactEmail != null && !stContactEmail.trim().isEmpty()) {
				hmAddUserInp.put(CommonDefs.CONTACT_EMAIL, stContactEmail.trim());
			}
			if (stFirstName != null && !stFirstName.trim().isEmpty()) {
				hmAddUserInp.put(CommonDefs.FIRST_NAME, stFirstName.trim());
			}
			if (stLastName != null && !stLastName.trim().isEmpty()) {
				hmAddUserInp.put(CommonDefs.LAST_NAME, stLastName.trim());
			}
			if (stGender != null && !stGender.trim().isEmpty()) {
				hmAddUserInp.put(CommonDefs.GENDER, stGender.trim());
			}
			if (stSor != null && !stSor.trim().isEmpty()) {
				hmAddUserInp.put(CommonDefs.SOR, stSor.trim());
			}
			if (stDateOfBirth != null && !stDateOfBirth.trim().isEmpty()) {
				hmAddUserInp.put(CommonDefs.DATE_OF_BIRTH, stDateOfBirth.trim());
			}

			if (stLanguage != null && !stLanguage.trim().isEmpty()) {
				hmAddUserInp.put(CommonDefs.LANGUAGE, stLanguage.trim());
			}

			if (stProofingZip != null && !stProofingZip.trim().isEmpty()) {
				hmAddUserInp.put(CommonDefs.PROOFING_ZIP, stProofingZip.trim());
			}

			logger.info(SpiMarker.getInstance(),"{}{}REUH_AU.01 : Calling AddUserHelper.addUser with Input: {}", sClassName, sMethodName,
					StructuredArguments.entries(hmAddUserInp));
			hmResult = (HashMap<String, Object>) addUserhelper.addUser(hmAddUserInp);

			logger.info(SpiMarker.getInstance(),"{}{}REUH_AU.02 : Response from AddUserHelper.addUser: {}", sClassName, sMethodName, StructuredArguments.entries(hmResult));
			hmAddUserInp.remove("isMIDInRequest");
			hmAddUserInp.remove(CommonDefs.PROOFING_ZIP);

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			String stAppInfo = "Exception thrown addUser method : " + hmResult;
			logger.error("{}{REUH_AU.03 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}
		return hmResult;
	}

	private Map<String, Object> addService(Map<String, Object> hmInput, String stGroup_num, String stDBMemberNum,
			HashMap<String, Object> hmInputService) {
		String stAppInfo;
		String sMethodName = ".addService.";
		HashMap<String, Object> hmService = new HashMap<>();
		HashMap<String, Object> hmResult = null;
		try {

			String sServiceType = (String) hmInputService.get(CommonDefs.SERVICE_TYPE);

			hmService.put(MPSDefs.DB_GROUP_NUM, stGroup_num);
			hmService.put(MPSDefs.DB_MEMBER_NUM, stDBMemberNum);
			hmService.put(MPSDefs.DB_SERVICE_NAME, sServiceType);
			hmService.put(MPSDefs.DB_MEMBER_STATUS_NAME, hmInputService.get(CommonDefs.SERVICE_STATUS));
			hmService.put(MPSDefs.DB_GROUP_STATUS_NAME, hmInputService.get(CommonDefs.SERVICE_STATUS));
			hmService.put(MPSDefs.DB_SOR_NAME, hmInputService.get(CommonDefs.SOR));
			hmService.put(MPSDefs.DB_LAST_MODIFIED_BY, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
			logger.debug("{}{}REUH_AS.01: Calling MPSDB_Service_H.addService with Input: {}", sClassName, sMethodName,
					hmService);
			hmResult = addServiceDbHelper.addService(hmService);
			logger.debug("{}{}REUH_AS.02: Response from  AddServiceDBHelper.addService : {}", sClassName, sMethodName,
					hmResult);
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown AddServiceDBHelper.saddService method : " + hmResult;
			logger.error("{}{}REUH_AS.03 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}
		return hmResult;
	}

	private Map<String, Object> addContact(Map<String, Object> hmInput, String stDBMemberNum) {

		String sMethodName = ".addContact.";
		ArrayList<Object> alContacts = null;
		alContacts = (ArrayList) hmInput.get(MPSDefs.KEY_CONTACTS);
		HashMap<String, Object> hmInpContact = null;
		HashMap<String, Object> hmResult = null;

		try {
			if (alContacts != null && !alContacts.isEmpty()) {
				hmInpContact = (HashMap) alContacts.get(0);

				int iValidationStatusCode;
				HashMap<String, Object> hmContactHelperInput = new HashMap<>();
				String stContactType = (String) hmInpContact.get(CommonDefs.CONTACT_TYPE);
				String stTn = (String) hmInpContact.get(CommonDefs.TN);
				String stContactStatus = (String) hmInpContact.get(CommonDefs.CONTACT_STATUS);
				String stPhoneType = (String) hmInpContact.get(CommonDefs.PHONE_TYPE);
				String stValidationStatus = (String) hmInpContact.get(CommonDefs.VALIDATION_STATUS);
				String stPhoneNumberExt = (String) hmInpContact.get(CommonDefs.TN_EXT);
				String stSubscriptionId = (String) hmInpContact.get(CommonDefs.SUBSCRIPTION_ID);
				String stContactDescription = (String) hmInpContact.get(CommonDefs.DESCRIPTION);
				hmContactHelperInput.put(CommonDefs.TRANSACTION_NAME,
						CommonDefs.UPDATE_USER_CONTACT_CBR_TRANSACTION_NAME);
				hmContactHelperInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
				hmContactHelperInput.put(CommonDefs.GUID, stDBMemberNum);
				hmContactHelperInput.put(CommonDefs.CONTACT_TYPE, stContactType);
				hmContactHelperInput.put(CommonDefs.PHONE_NUMBER, stTn);
				hmContactHelperInput.put(CommonDefs.PHONE_NUMBER_TYPE, stPhoneType);
				hmContactHelperInput.put(CommonDefs.CONTACT_STATUS, stContactStatus);
				hmContactHelperInput.put(CommonDefs.SUBSCRIPTION_ID, stSubscriptionId);
				hmContactHelperInput.put(CommonDefs.DESCRIPTION, stContactDescription);
				if (stPhoneNumberExt != null && !stPhoneNumberExt.isEmpty()) {
					hmContactHelperInput.put(CommonDefs.PHONE_NUMBER_EXT, stPhoneNumberExt);
				}
				hmContactHelperInput.put(CommonDefs.IS_EXTERNAL_CALL, CommonDefs.IND_N);
				iValidationStatusCode = oDBHelper.getStatusCode(stValidationStatus);
				String stValidationStatusCode = String.valueOf(iValidationStatusCode);
				hmContactHelperInput.put(CommonDefs.VALIDATION_STATUS, stValidationStatusCode);
				hmContactHelperInput.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(ProfileOrchestrationConstants.IDPTRACEID));
				hmContactHelperInput.put(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID, (String) hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));

				logger.info(SpiMarker.getInstance(),
						"{}{}REUH_AC.01 : Calling UpdateUserContactCBRHelper.updateUserContactCBR for UpdateUserContactCBR of CIM with hmContactCIM : {}",
						sClassName, sMethodName, StructuredArguments.entries(hmContactHelperInput));

				hmResult = (HashMap<String, Object>) updateUserContactCBRHelper.updateUserContactCBR(hmContactHelperInput);

				logger.info(SpiMarker.getInstance(),
						"{}{}REUH_AC.02 : Response from UpdateUserContactCBRHelper.updateUserContactCBR for UpdateUserContactCBR of CIM : {}",
						sClassName, sMethodName, StructuredArguments.entries(hmResult));

			} else {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG);
			}
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			String stAppInfo = "Exception thrown addContact method : " + hmResult;
			logger.error("{}{}REUH_AC.03 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}
		return hmResult;
	}

}
