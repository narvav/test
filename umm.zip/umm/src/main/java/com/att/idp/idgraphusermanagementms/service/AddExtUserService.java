package com.att.idp.idgraphusermanagementms.service;

import com.att.idp.idgraphusermanagementms.resource.request.ExtUserRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ExtUserResponse;

import jakarta.ws.rs.core.MultivaluedMap;

/**
 * This interface defines the contract for the AddExtUserService in the system.
 * It contains a single method addExtUserResponse which takes an ExtUserRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return an ExtUserResponse object.
 *
 * The ExtUserRequest object encapsulates the details of the external user to be added.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
public interface AddExtUserService {
	
	/**
	 * This method is part of the AddExtUserService interface.
	 * It defines the contract for adding an external user to the system.
	 *
	 * @param extUserRequest An object encapsulating the details of the external user to be added.
	 * @param requestHeader A MultivaluedMap containing the request headers which may include additional information required for processing the request.
	 * @return An ExtUserResponse object representing the response from the system after adding the external user.
	 */
    ExtUserResponse addExtUserResponse(ExtUserRequest extUserRequest, MultivaluedMap<String, String> requestHeader);
}
