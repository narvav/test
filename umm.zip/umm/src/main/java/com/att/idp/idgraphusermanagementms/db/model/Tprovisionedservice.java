package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.*;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TPROVISIONEDSERVICE", schema = "MPS_OWNER", uniqueConstraints = @UniqueConstraint(columnNames = { "BAN", "PRODUCT_ID", "INSTANCE_ID" }))
public class Tprovisionedservice implements java.io.Serializable {

	private static final long serialVersionUID = 6021927929082980814L;

	@Id
	@Column(name = "PROVISIONED_SERVICE_NUM", unique = true, nullable = false, precision = 22, scale = 0)
	private Long provisionedServiceNum;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "PRODUCT_ID", nullable = false)
	private Tservice tservice;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BAN")
	private Taccountinfo taccountinfo;

	@Column(name = "INSTANCE_ID", length = 24)
	private String instanceId;

	@Column(name = "SITE_ID", length = 9)
	private String siteId;

	@Column(name = "SERVICE_ELIGIBILITY", nullable = false, length = 1)
	private char serviceEligibility;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;

	@Column(name = "SOR_INVARIANT_ID")
	private String sorInvariantId;

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "tprovisionedservice")
	private Tprovisionedhsia tprovisionedhsia;
}