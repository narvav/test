package com.att.idp.idgraphusermanagementms.service;

import jakarta.ws.rs.core.HttpHeaders;

import com.att.idp.idgraphusermanagementms.resource.request.ValidateUserCredentialsRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ValidateUserCredentialsResponse;

/**
 * This interface defines the contract for the ValidateUserCredentialsService in the system.
 * It contains a single method validateUserCredentials which takes a ValidateUserCredentialsRequest object and HttpHeaders as parameters.
 * The method is expected to return a ValidateUserCredentialsResponse object.
 *
 * The ValidateUserCredentialsRequest object encapsulates the details of the user credentials validation operation to be performed.
 * The HttpHeaders contains the request headers which may include additional information required for processing the request.
 *
 */
public interface ValidateUserCredentialsService {

	/**
	 * This method is part of the ValidateUserCredentialsService interface.
	 * It defines the contract for validating a user's credentials in the system.
	 *
	 * @param validateUserCredentialsRequest An object encapsulating the details of the user credentials validation operation to be performed.
	 * @param httpHeaders HttpHeaders containing the request headers which may include additional information required for processing the request.
	 * @return A ValidateUserCredentialsResponse object representing the response from the system after validating the user's credentials.
	 */
	ValidateUserCredentialsResponse validateUserCredentials(ValidateUserCredentialsRequest validateUserCredentialsRequest, HttpHeaders httpHeaders);
}
