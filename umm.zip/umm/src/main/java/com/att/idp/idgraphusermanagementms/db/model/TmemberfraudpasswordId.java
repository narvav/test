package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class TmemberfraudpasswordId implements java.io.Serializable {

	private static final long serialVersionUID = -5189217591910771702L;

	@Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)
	private Long memberNum;

	@Column(name = "FRAUD_COUNTER", nullable = false, precision = 22, scale = 0)
	private Long fraudCounter;

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TmemberfraudpasswordId))
			return false;
		TmemberfraudpasswordId castOther = (TmemberfraudpasswordId) other;

		return ((this.getMemberNum() == castOther.getMemberNum()) || (this.getMemberNum() != null
				&& castOther.getMemberNum() != null && this.getMemberNum().equals(castOther.getMemberNum())))
				&& ((this.getFraudCounter() == castOther.getFraudCounter())
				|| (this.getFraudCounter() != null && castOther.getFraudCounter() != null
				&& this.getFraudCounter().equals(castOther.getFraudCounter())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getMemberNum() == null ? 0 : this.getMemberNum().hashCode());
		result = 37 * result + (getFraudCounter() == null ? 0 : this.getFraudCounter().hashCode());
		return result;
	}

}