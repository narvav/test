package com.att.idp.idgraphusermanagementms.service.impl;

import java.util.Map;

import jakarta.ws.rs.core.MultivaluedMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.CheckAccessIdMergeEligibilityHelper;
import com.att.idp.idgraphusermanagementms.resource.request.CheckAccessIdMergeEligibilityRequest;
import com.att.idp.idgraphusermanagementms.resource.response.CheckAccessIdMergeEligibilityResponse;
import com.att.idp.idgraphusermanagementms.service.CheckAccessIdMergeEligibilityService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This class implements the CheckAccessIdMergeEligibilityService interface and provides the implementation for checking the eligibility of merging access IDs in the system.
 * It is annotated with @Service to indicate that it's a Spring Bean and @Transactional to handle the transaction management.
 *
 * It contains a method checkAccessIdMergeEligibility which takes a CheckAccessIdMergeEligibilityRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return a CheckAccessIdMergeEligibilityResponse object.
 *
 * The CheckAccessIdMergeEligibilityRequest object encapsulates the details of the access ID merge eligibility check operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
@Service
@Transactional(readOnly = true, value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class CheckAccessIdMergeEligibilityServiceImpl implements CheckAccessIdMergeEligibilityService {

	public static final Logger logger = LoggerFactory.getLogger(CheckAccessIdMergeEligibilityServiceImpl.class);

	private static String sClassName = "CheckAccessIdMergeEligibilityServiceImpl";

	@Autowired
	private CheckAccessIdMergeEligibilityHelper checkAccessIdMergeEligibilityHelper;

	@Override
	public CheckAccessIdMergeEligibilityResponse checkAccessIdMergeEligibility(CheckAccessIdMergeEligibilityRequest checkAccessIdMergeEligibilityRequest,
 			MultivaluedMap<String, String> requestHeader) {

		Map<String, Object> hmResponse = null;
		String sMethodName = ".checkAccessIdMergeEligibility.";

		Map<String, Object> hmInput = CommonUtilHelper.objectToMap(checkAccessIdMergeEligibilityRequest);

		String idpTraceid = (String) hmInput.get("idpTraceId");
		hmInput.put("dbusTransactionId", idpTraceid.split(":")[0]);

		logger.info(SpiMarker.getInstance(),"CheckAccessIdMergeEligibilityServiceImpl.checkAccessIdMergeEligibility.CAIMES_01 : "
					+ "Calling checkAccessIdMergeEligibilityHelper with Input : {}", StructuredArguments.entries(hmInput));

		hmResponse = checkAccessIdMergeEligibilityHelper.checkAccessIdMergeEligibility(hmInput,requestHeader);

		hmResponse=CommonUtilHelper.processHmResponse(hmResponse, hmInput, "CheckAccessIdMergeEligibilityHelper", ".checkAccessIdMergeEligibility");
		hmResponse.put("idp-trace-id", checkAccessIdMergeEligibilityRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME, "CheckAccessIdMergeEligibility");
		CheckAccessIdMergeEligibilityResponse checkAccessIdMergeEligibilityResponse = CommonUtilHelper
																					  .generateCheckAccessIdMergeEligibilityResponse(hmResponse);
		
		logger.info("{}{}CAIMES_05 : Response from CheckAccessIdMergeEligibilityServiceImpl.checkAccessIdMergeEligibility : {}", sClassName, sMethodName,
					checkAccessIdMergeEligibilityResponse);
		
		return checkAccessIdMergeEligibilityResponse;
	}
}
