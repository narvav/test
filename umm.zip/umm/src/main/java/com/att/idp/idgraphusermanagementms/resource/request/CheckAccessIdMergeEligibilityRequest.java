
package com.att.idp.idgraphusermanagementms.resource.request;

import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
 
/**
 * This class represents a request to check the eligibility for merging access IDs in the system.
 * It contains fields for various details such as callingSystemId, fromUserName, toUserName, agentId, sourceIPAddress, isExternalCall, idpTraceId, and a map for unknownAttributes.
 * Each field has specific constraints such as not null and size limits.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 *
 * @author pb6583_ATT
 */
@Schema(name = "CheckAccessIdMergeEligibilityRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class CheckAccessIdMergeEligibilityRequest {

    private final String transactionName = "CheckAccessIdMergeEligibility";
	
    @Size(min=1, max=20,message="CallingSystemId length is invalid|checkAccessIdMergeEligibility")
    protected String callingSystemId;
    
    @NotNull(message="fromUserName is required field in input request.|checkAccessIdMergeEligibility")
    @Size(min=1, max=127,message="fromUserName length is invalid|checkAccessIdMergeEligibility")
    protected String fromUserName;
    
    @NotNull(message="toUserName is required field in input request.|checkAccessIdMergeEligibility")
    @Size(min=1, max=127,message="toUserName length is invalid|checkAccessIdMergeEligibility")
    protected String toUserName;
    
    @Size(min=1, max=20,message="agentId length is invalid|checkAccessIdMergeEligibility")
    protected String agentId;
    
	@Size(min = 1, max = 100, message =  "sourceIPAddress length is invalid|checkAccessIdMergeEligibility")
	private String sourceIPAddress;
	
	@Size(min = 1, max = 20, message =  "isExternalCall length is invalid|checkAccessIdMergeEligibility")
	private String isExternalCall;
	
	@Schema(name = "idpTraceId")
	private String idpTraceId;
	
	/**
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
	 * @return Map<String,Object> The map of unknown attributes.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();
	 
	
}
