package com.att.idp.idgraphusermanagementms.request.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import jakarta.ws.rs.core.HttpHeaders;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.resource.request.UpdateUserFraudRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdateUserFraudResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;

/**
 * This class, UpdateUserFraudRequestValidator, is responsible for validating the UpdateUserFraudRequest.
 * It checks for the presence and validity of required fields in the request, and returns an UpdateUserFraudResponse accordingly.
 * It is annotated with @Component, @Configuration, and @PropertySource to indicate that it's a Spring Bean,
 * to allow it to access configuration properties, and to specify the location of the properties file respectively.
 *
 * The class contains several methods, including:
 * - updateUserFraudReqValidator: the main method that orchestrates the validation process.
 * - updateUserFraudInputValidator: a method that validates the input fields in the request.
 * - updateUserFraudInputAndCSIValidator: a method that validates the 'CSI' field in the request.
 * - updateUserFraudErrorResponse: a helper method that generates an error response.
 * - updateUserFraudIsExternalCallCheck: a method that checks if the request is an external call.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class UpdateUserFraudRequestValidator {
		
	@Value("${updateUserFraudCallingSystemIds}")
	private String propValidCallers;
	
	@Value("${Prop_Agent_CallingSystemId}")
	private String propValidAgentCSI;
	
	@Value("${updateUserFraudLockLevels}")
	private String propValidLockLevels;
	
	
	private static final Logger logger = LoggerFactory.getLogger(UpdateUserFraudRequestValidator.class);

	private String sClassName = "UpdateUserFraudRequestValidator";
	
	/**
	 * This method is responsible for validating the UpdateUserFraudRequest.
	 * It takes HttpHeaders and UpdateUserFraudRequest as parameters.
	 * HttpHeaders contains the request headers which may include additional information required for processing the request.
	 * UpdateUserFraudRequest encapsulates the details of the update user fraud operation to be performed.
	 *
	 * The method performs various checks and validations on the input parameters and returns an UpdateUserFraudResponse object.
	 * The UpdateUserFraudResponse object encapsulates the result of the update user fraud operation.
	 *
	 * @param requestHeader The HttpHeaders containing the request headers.
	 * @param updateUserFraudRequest The UpdateUserFraudRequest containing the details of the update user fraud operation.
	 * @return UpdateUserFraudResponse The response of the update user fraud operation.
	 */
	public UpdateUserFraudResponse updateUserFraudReqValidator(HttpHeaders requestHeader, UpdateUserFraudRequest updateUserFraudRequest) {
		
		
		UpdateUserFraudResponse updateUserFraudResponse = null;
		
		String sMethodName = ".updateUserFraudReqValidator.";
		String stAppInfo=null;
		String stIdpTraceId = null;
		
		stIdpTraceId = CommonUtil.getTraceId(requestHeader);

		if (stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
			stAppInfo = "Missing or Invalid IdpTraceId";
			return updateUserFraudErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (updateUserFraudRequest == null) {
			stAppInfo = "Input Request is NULL / Empty.";
			logger.info("{}{}UFRV_101 :: {}", sClassName, sMethodName, stAppInfo);
			return updateUserFraudErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		
		updateUserFraudRequest.setIdpTraceId(stIdpTraceId);
			
		
		// checking Invalid attributes passed in Request
		Map<String, Object> allUnknownAttributes = new HashMap<>(updateUserFraudRequest.unknownAttributes);
		

		if (!allUnknownAttributes.isEmpty()) {
			stAppInfo = "Invalid Attributes passed in UpdateUserFraudLockRequest : " + allUnknownAttributes;
			return updateUserFraudErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					updateUserFraudRequest.getIdpTraceId());
		}
		
		
		try {
			updateUserFraudResponse =updateUserFraudInputValidator(updateUserFraudRequest,requestHeader);
			if (updateUserFraudResponse != null) {
				logger.info("{}{}UFRV_103 : Response from updateUserFraudInputValidator : {}", sClassName, sMethodName,
						updateUserFraudResponse);
				return updateUserFraudResponse;
			}
			
			updateUserFraudResponse = updateUserFraudInputAndCSIValidator(updateUserFraudRequest);
			if (updateUserFraudResponse != null) {
				logger.info("{}{}UFRV_104 : Response from updateUserFraudInputAndCSIValidator : {}", sClassName, sMethodName,
						updateUserFraudResponse);
				return updateUserFraudResponse;
			}
			
			stAppInfo = "Input Validation Successful";
			logger.info("{}{}UFRV_105 : {}", sClassName, sMethodName, stAppInfo);

		} catch (Exception e) {
			stAppInfo = "Exception thrown in UpdateUserFraudRequestValidator : "
					+ e.getMessage();
			updateUserFraudResponse=updateUserFraudErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo,
				 stIdpTraceId);
			logger.info("{}{}UFRV_106: Exception in UpdateUserFraudRequestValidator: {}", sClassName,sMethodName,stAppInfo);
		}
		
		
		
		return updateUserFraudResponse;
	}

	

	private UpdateUserFraudResponse updateUserFraudInputValidator(UpdateUserFraudRequest updateUserFraudRequest,
			HttpHeaders requestHeader) {

		UpdateUserFraudResponse updateUserFraudLockResponse = null;
		String sMethodName = ".updateUserFraudInputValidator.";
		String stAppInfo = null;

		String sHandle = updateUserFraudRequest.getHandle();
		String sDomain = updateUserFraudRequest.getDomain();
		String sGuid = updateUserFraudRequest.getGuid();
		String sAgentId = updateUserFraudRequest.getAgentId();
		String sIsExternalCall = updateUserFraudRequest.getIsExternalCall();
		String sInpUserLockLevel = updateUserFraudRequest.getUserLockLevel();
		String stXAttClientId = requestHeader.getHeaderString("X-ATT-ClientId");

		Optional.ofNullable(sGuid).ifPresent(x -> updateUserFraudRequest.setGuid(x.trim()));
		Optional.ofNullable(sHandle).ifPresent(x -> updateUserFraudRequest.setHandle(x.trim().toLowerCase()));
		Optional.ofNullable(sDomain).ifPresent(x -> updateUserFraudRequest.setDomain(x.trim().toLowerCase()));
		Optional.ofNullable(sAgentId).ifPresent(x -> updateUserFraudRequest.setAgentId(x.trim().toLowerCase()));
		Optional.ofNullable(sIsExternalCall).ifPresent(x -> updateUserFraudRequest.setIsExternalCall(x.trim()));
		Optional.ofNullable(sInpUserLockLevel).ifPresent(x -> updateUserFraudRequest.setUserLockLevel(x.trim()));
		

		String stCallingSystemId = updateUserFraudRequest.getCallingSystemId();
		
		if (stCallingSystemId == null && stXAttClientId != null) {			
			if (stXAttClientId.equalsIgnoreCase("idpgwbiz") && StringUtils.isNotBlank(requestHeader.getHeaderString("idpctx-appname"))) 
			    stCallingSystemId = requestHeader.getHeaderString("idpctx-appname").toUpperCase();
			else 
				stCallingSystemId = stXAttClientId.toUpperCase();
		}
		logger.info("{}{}: callingSystemId: {}", sClassName, sMethodName, StringUtils.normalizeSpace(stCallingSystemId));
		
		if (stCallingSystemId == null || stCallingSystemId.isEmpty()) {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			logger.info("{}{}UFRV_102.2 : {}", sClassName, sMethodName, stAppInfo);
			return updateUserFraudErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					updateUserFraudRequest.getIdpTraceId());
		}
		
		Optional.ofNullable(stCallingSystemId).ifPresent(x -> updateUserFraudRequest.setCallingSystemId(x.trim().toUpperCase()));
		
		if(sHandle!=null && sDomain == null) {
			updateUserFraudRequest.setDomain(CommonDefs.SLID_DUM);
		}

		updateUserFraudLockResponse = updateUserFraudIsExternalCallCheck(updateUserFraudRequest);

		return updateUserFraudLockResponse;
	}

	
	private UpdateUserFraudResponse updateUserFraudInputAndCSIValidator(
			UpdateUserFraudRequest updateUserFraudRequest) {
		
		String stAppInfo=null;
		String sMethodName=".updateUserFraudInputAndCSIValidator.";
		String sIsExternalCall=updateUserFraudRequest.getIsExternalCall();
		String sCallingSystemId=updateUserFraudRequest.getCallingSystemId();
		String sHandle = updateUserFraudRequest.getHandle();
		String sGuid = updateUserFraudRequest.getGuid();
		String sDomain = updateUserFraudRequest.getDomain();
		String sAgentId=updateUserFraudRequest.getAgentId();
		String sInpUserLockLevel = updateUserFraudRequest.getUserLockLevel();
		ArrayList alValidCallers = null;
		ArrayList<String> alAgentCSI =  null;
		ArrayList<String> alValidLockLevels = null;

		
		if (propValidCallers != null && !propValidCallers.isEmpty()) {
			alValidCallers = CommonUtil.parseToArray(propValidCallers, CommonDefs.VALUE_SEPARATOR_CHAR);

		} else {
			stAppInfo = "Property value is null or empty";
			logger.error("{}{}UFRV_103.1 : {} ", sClassName, sMethodName, stAppInfo);
			return updateUserFraudErrorResponse(CErrorDefs.ERR_CONFIG_NUM, stAppInfo,
					updateUserFraudRequest.getIdpTraceId());
			
		}

		logger.info("{}{}UFRV_103.2 : Property updateUserFraudCallingSystemIds : {} ", sClassName, sMethodName,
				alValidCallers);


		if (alValidCallers != null && !alValidCallers.contains(sCallingSystemId)
				&& CommonDefs.IND_Y.equals(sIsExternalCall)) {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			logger.info("{}{}UFRV_103.3 :  {} ", sClassName, sMethodName, stAppInfo);
			return updateUserFraudErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					updateUserFraudRequest.getIdpTraceId());

		}

		if ((sGuid != null && !sGuid.isEmpty())
				&& ((sHandle != null && !sHandle.isEmpty()) || (sDomain != null && !sDomain.isEmpty()))) {
			stAppInfo = "Both guid and userID should not be present";
			logger.info("{}{}UFRV_103.4 : {}", sClassName, sMethodName, stAppInfo);		
			return updateUserFraudErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					updateUserFraudRequest.getIdpTraceId());
			
		}

		if ((sGuid == null || sGuid.isEmpty())
				&& ((sHandle == null || sHandle.isEmpty()) && (sDomain == null || sDomain.isEmpty()))) {

			stAppInfo = "Either guid or userId must be present";
			logger.info("{}{}UFRV_103.5 : {}", sClassName, sMethodName, stAppInfo);
			return updateUserFraudErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					updateUserFraudRequest.getIdpTraceId());
		}
        
		
		if (propValidAgentCSI != null && !propValidAgentCSI.isEmpty()) { 
			 alAgentCSI = CommonUtil.parseToArray(propValidAgentCSI, CommonDefs.VALUE_SEPARATOR_CHAR); 

		} else { 
			stAppInfo = "Property value is null or empty";  			
			logger.error("{}{}UFRV_103.6 : {} ", sClassName, sMethodName, stAppInfo);
			return updateUserFraudErrorResponse(CErrorDefs.ERR_CONFIG_NUM, stAppInfo,
					updateUserFraudRequest.getIdpTraceId());			 
			 
		}

		if (sCallingSystemId != null && alAgentCSI != null && alAgentCSI.contains(sCallingSystemId)
				&& (sAgentId == null || sAgentId.isEmpty())) {

			stAppInfo = "AgentId is required for caller:" + sCallingSystemId;
			logger.info("{}{}UFRV_103.7 : {}", sClassName, sMethodName, StringUtils.normalizeSpace(stAppInfo));
			return updateUserFraudErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					updateUserFraudRequest.getIdpTraceId());

		}
	
		if (propValidLockLevels != null && !propValidLockLevels.isEmpty()) { 
			 alValidLockLevels = CommonUtil.parseToArray(propValidLockLevels, 
					CommonDefs.VALUE_SEPARATOR_CHAR); 

		} else { 
			stAppInfo = "Property value is null or empty";  
			logger.error("{}{}UFRV_103.8 : {} ", sClassName, sMethodName, stAppInfo); 
			return updateUserFraudErrorResponse(CErrorDefs.ERR_CONFIG_NUM, stAppInfo,
					updateUserFraudRequest.getIdpTraceId());
		}
		if (sInpUserLockLevel != null && !alValidLockLevels.contains(sInpUserLockLevel)) {
			stAppInfo = "UserLockLevel " + sInpUserLockLevel + " is not valid";
			logger.info("{}{}UFRV_103.9 : {}", sClassName, sMethodName, StringUtils.normalizeSpace(stAppInfo));
			return updateUserFraudErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					updateUserFraudRequest.getIdpTraceId());
			
		}
		return null;
	}
	
	
	private UpdateUserFraudResponse updateUserFraudErrorResponse(int appStatusCode, String stAppInfo,  String stIdpTraceId) {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		hmResponse.put(CommonDefs.TRANSACTION_NAME,"UpdateUserFraud");
		return  CommonUtilHelper.generateUpdateUserFraudResponse(hmResponse);
	}

	
	private UpdateUserFraudResponse updateUserFraudIsExternalCallCheck(UpdateUserFraudRequest updateUserFraudRequest) {
		UpdateUserFraudResponse updateUserFraudLockResponse = null;
		String stAppInfo=null;
		String isExternalCall = updateUserFraudRequest.getIsExternalCall();
		String stIdpTraceId=updateUserFraudRequest.getIdpTraceId();
		
		if ((isExternalCall != null && !isExternalCall.isEmpty())) {
			if (!(isExternalCall.equalsIgnoreCase(CommonDefs.IND_Y)
					|| isExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
				stAppInfo = "isExternalCall must be one of Y or N";
				return updateUserFraudErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			} else {
				updateUserFraudRequest.setIsExternalCall(isExternalCall.trim().toUpperCase());
			}
		} else {
			updateUserFraudRequest.setIsExternalCall(CommonDefs.IND_Y);
		}
		return updateUserFraudLockResponse;
	}
}
