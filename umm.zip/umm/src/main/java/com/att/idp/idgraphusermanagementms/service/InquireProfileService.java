package com.att.idp.idgraphusermanagementms.service;

import jakarta.ws.rs.core.MultivaluedMap;

import com.att.idp.idgraphusermanagementms.resource.request.InquireProfileRequest;
import com.att.idp.idgraphusermanagementms.resource.response.InquireProfileResponse;

/**
 * This interface defines the contract for the InquireProfileService in the system.
 * It contains a single method inquireProfile which takes an InquireProfileRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return an InquireProfileResponse object.
 *
 * The InquireProfileRequest object encapsulates the details of the profile inquiry to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
public interface InquireProfileService {

	/**
	 * This method is part of the InquireProfileService interface.
	 * It defines the contract for inquiring a profile in the system.
	 *
	 * @param inquireProfileRequest An object encapsulating the details of the profile inquiry to be performed.
	 * @param requestHeader A MultivaluedMap containing the request headers which may include additional information required for processing the request.
	 * @return An InquireProfileResponse object representing the response from the system after inquiring the profile.
	 */
	InquireProfileResponse inquireProfile(InquireProfileRequest inquireProfileRequest, MultivaluedMap<String, String> requestHeader);
}
