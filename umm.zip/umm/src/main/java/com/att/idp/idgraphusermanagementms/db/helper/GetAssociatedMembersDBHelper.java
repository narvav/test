package com.att.idp.idgraphusermanagementms.db.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.apache.commons.lang3.StringUtils;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * @author pg076f
 */
@Component
public class GetAssociatedMembersDBHelper {
	private static final String CLASS_NAME = "GetAssociatedMembersDBHelper";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private DBHelper oDBHelper;

	@Autowired
	private GetMemberServicesDBHelper oGetMemberServicesDBHelper;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	public static final Logger logger = LoggerFactory.getLogger(GetAssociatedMembersDBHelper.class);
	private static String dateFormat = "MMDDYYYY HH24:mi:ss";

	private static final String QUERY_GET_MEMBER_NUM = "SELECT" + " ms.member_num "
			+ " FROM memberservice ms, service svc " + " WHERE ms.service_id = svc.service_id (+) AND";

	private static final String QUERY_VERIFY_EXIXTING_MEMBER = "SELECT" + " ms.member_num "
			+ " FROM memberservice ms, service svc,memberservicerole msr "
			+ " WHERE ms.service_id = svc.service_id (+) AND"
			+ "  ms.member_num = msr.member_num AND ms.service_id = msr.service_id AND msr.role_id='2' AND";

	/**
	 * 
	 * @param hmInput
	 * @return HashMap
	 */
	public HashMap getAssociatedMembers(HashMap hmInput) {

		String sMethodName = ".getAssociatedMembers.";

		HashMap hmResult = null;
		String errorCode;
		String sAppStatusCode = null;

		ArrayList alMemberNums = null;
		ArrayList alServiceContacts = null;
		String sCurrentQuery = null;

		List<Object> objectList = new ArrayList<Object>();
		List alQueryResponse = null;

		logger.info("{}{}DBTOOLS000 : Inputhash : {}", CLASS_NAME, sMethodName, hmInput);

		if (jdbcTemplate == null) {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "jdbcTemplate is null.");
			logger.error("response : {}", hmResult);
			return hmResult;
		}

		String sSorInvariantId1 = (String) hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID1);
		String sSorName = (String) hmInput.get(MPSDefs.DB_SOR_NAME);
		String sSor = (String) hmInput.get(CommonDefs.SOR);
		String sSorIdStr = (String) hmInput.get(MPSDefs.DB_SOR_ID);
		String sServiceType = (String) hmInput.get(MPSDefs.DB_SERVICE_TYPE);
		String sInstanceId = (String) hmInput.get(MPSDefs.DB_INSTANCE_ID);
		String sQueryForVerifyExistingMember = (String) hmInput
				.get(CommonDefs.TRANSACTION_NAME_VERIFY_EXISTING_MEMBER_ELIGIBILITY);

		try {

			String queryArg = "";
			int sor_id = 0;

			// AUG 2014 - if sorName is null in input, update sorName with sor value
			if (sSorName == null || sSorName.isEmpty()) {
				if (sSor != null && !sSor.isEmpty()) {
					sSorName = sSor;
				}
			}

			if (sSorName != null && sSorName.trim().length() > 0) {
				int temp_sor_id = oDBHelper.getSorId(sSorName);
				sSorIdStr = String.valueOf(temp_sor_id);
				logger.debug("{}{}GAMDBH_01 : Got sor_id from DBHelper= {}", CLASS_NAME, sMethodName, sSorIdStr);
			} else if (sSorIdStr == null || sSorIdStr.isEmpty()) {
				sSorIdStr = "0";
			}

			if (sSorInvariantId1 != null && (sSorInvariantId1.trim().length()) != 0) {
				sSorInvariantId1 = sSorInvariantId1.trim();

				queryArg = " ms.sor_invariant_id=? AND ms.sor_invariant_id is not null";

				if (sSorIdStr != null && !sSorIdStr.trim().equals("0") && sServiceType != null
						&& sServiceType.trim().length() > 0) {
					queryArg += " AND ms.sor_id = ? AND svc.service_name = ? ";

				} else if (sServiceType != null && sServiceType.trim().length() > 0) {
					queryArg += " AND svc.service_name = ? ";

				} else if (sSorIdStr != null && !sSorIdStr.trim().equals("0")) {
					queryArg += " AND ms.sor_id = ? ";
				} else {
					logger.info("{}{}DANGER-05 : CONTROL MUST NOT COME HERE {}", CLASS_NAME, sMethodName, hmInput);
				}
				if (!StringUtils.isBlank(sQueryForVerifyExistingMember)
						&& sQueryForVerifyExistingMember.equals(CommonDefs.DEFAULT_YES)) {
					sCurrentQuery = QUERY_VERIFY_EXIXTING_MEMBER;
				} else {
					sCurrentQuery = QUERY_GET_MEMBER_NUM;
				}

				logger.info("{}{}GAMDBH_02 : Query SQL = {}{}", CLASS_NAME, sMethodName, sCurrentQuery, queryArg);

				objectList.add(sSorInvariantId1);

				if (sSorIdStr != null && !sSorIdStr.trim().equals("0") && sServiceType != null
						&& sServiceType.trim().length() > 0) {
					objectList.add(sSorIdStr);
					objectList.add(sServiceType);
				} else if (sServiceType != null && sServiceType.trim().length() > 0) {
					objectList.add(sServiceType);
				} else if (sSorIdStr != null && !sSorIdStr.trim().equals("0")) {
					objectList.add(sSorIdStr);
				}
			}

			else if (sInstanceId != null && (sInstanceId.trim().length()) != 0) {
				sInstanceId = sInstanceId.trim();

				queryArg = " ms.instance_id =?";

				if (sSorIdStr != null && !sSorIdStr.trim().equals("0") && sServiceType != null
						&& sServiceType.trim().length() > 0) {
					queryArg += " AND ms.sor_id = ? AND svc.service_name = ? ";

				} else if (sServiceType != null && sServiceType.trim().length() > 0) {
					queryArg += " AND svc.service_name = ? ";

				} else if (sSorIdStr != null && !sSorIdStr.trim().equals("0")) {
					queryArg += " AND ms.sor_id = ? ";
				} else {
					logger.info("{}{}DANGER-07 : CONTROL MUST NOT COME HERE {}", CLASS_NAME, sMethodName, hmInput);
				}
				logger.debug("{}{}GAMDBH_03 : Query SQL = {}{}", CLASS_NAME, sMethodName, sCurrentQuery, queryArg);

				objectList.add(sInstanceId);

				if (sSorIdStr != null && !sSorIdStr.trim().equals("0") && sServiceType != null
						&& sServiceType.trim().length() > 0) {
					objectList.add(sSorIdStr);
					objectList.add(sServiceType);
				} else if (sServiceType != null && sServiceType.trim().length() > 0) {
					objectList.add(sServiceType);
				} else if (sSorIdStr != null && !sSorIdStr.trim().equals("0")) {
					objectList.add(sSorIdStr);
				}
			}

			else {
				// if required fields not exists, return ERR_EMPTY error
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM, MPSDefs.ERR_EMPTY_MSG);
				logger.info("{}{}GAMDBH_04 : Required input field missing", CLASS_NAME, sMethodName);
				return hmResult;
			}

			alQueryResponse = jdbcTemplate.queryForList(new String(sCurrentQuery + queryArg),
					objectList.toArray(new Object[objectList.size()]));

			int rowCount = 0;
			HashMap hmDbInput = new HashMap();
			alMemberNums = new ArrayList();
			ArrayList alAssoMembers = new ArrayList();
			HashMap hmAssoMembers = null;
			HashMap hmMember = null;

			// Iterate through the result set. Populate and return HashMap.
			for (int j = 0; j < alQueryResponse.size(); j++) {
				Map hmQueryResponse = (Map) alQueryResponse.get(j);

				Iterator itr = hmQueryResponse.keySet().iterator();
				while (itr.hasNext()) {
					String key = (String) itr.next();
					Object value = hmQueryResponse.get(key);

					String strValue = (value == null ? null : value.toString());

					hmQueryResponse.put(key, strValue);
				}

				hmMember = CommonUtil.getHashMap();
				hmMember.put(MPSDefs.DB_MEMBER_NUM, (String) hmQueryResponse.get(MPSDefs.DB_MEMBER_NUM));
				alMemberNums.add(hmMember);
				++rowCount;
			}

			if (rowCount == 0) {
				if (hmResult == null || (hmResult != null && hmResult.get(MPSDefs.ASSOCIATED_MEMBERS) == null)) {
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
							CErrorDefs.ERR_REC_NOT_FOUND_MSG);
					logger.info("{}{}GAMDBH_05 : No row found", CLASS_NAME, sMethodName);
				}

				return hmResult;
			}

			if (alMemberNums != null && alMemberNums.size() > 0) {
				for (int i = 0; i < alMemberNums.size(); i++) {
					HashMap hmMemberInfo = (HashMap) alMemberNums.get(i);
					String sMemberNum = (String) hmMemberInfo.get(MPSDefs.DB_MEMBER_NUM);
					hmDbInput.put(CommonDefs.DB_MEMBER_NUM, sMemberNum);

					{

						if (hmInput.containsKey(MPSDefs.QUERY_ROLES_INFO_FLAG))
							hmDbInput.put(MPSDefs.QUERY_ROLES_INFO_FLAG, hmInput.get(MPSDefs.QUERY_ROLES_INFO_FLAG));

						if (hmInput.containsKey(MPSDefs.QUERY_ONLY_SLIDS_FLAG))
							hmDbInput.put(MPSDefs.QUERY_ONLY_SLIDS_FLAG, hmInput.get(MPSDefs.QUERY_ONLY_SLIDS_FLAG));

						if (hmInput.containsKey(MPSDefs.QUERY_SLID_INFO_FLAG))
							hmDbInput.put(MPSDefs.QUERY_SLID_INFO_FLAG, hmInput.get(MPSDefs.QUERY_SLID_INFO_FLAG));
					}

					// call getMemberServices using member_num
					hmResult = oGetMemberServicesDBHelper.getMemberServices(hmDbInput);

					HashMap hmEachMember = CommonUtil.getHashMap();

					if (hmResult != null) {
						sAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

						if (sAppStatusCode != null && sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
							hmAssoMembers = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success");
							hmEachMember.putAll(hmResult);

							hmEachMember.remove(MPSDefs.APP_STATUS_CODE);
							if (hmEachMember.containsKey(MPSDefs.APP_STATUS_MSG))
								hmEachMember.remove(MPSDefs.APP_STATUS_MSG);
							if (hmEachMember.containsKey(MPSDefs.SQLCODE))
								hmEachMember.remove(MPSDefs.SQLCODE);
							if (hmEachMember.containsKey(MPSDefs.SQLMSG))
								hmEachMember.remove(MPSDefs.SQLMSG);

							alAssoMembers.add(hmEachMember);

						} else if (sAppStatusCode != null && !sAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
							return hmResult;
						}
					}
				} // end of for loop

				if (alAssoMembers != null && alAssoMembers.size() > 0) {
					hmAssoMembers.put(MPSDefs.ASSOCIATED_MEMBERS, alAssoMembers);
					hmResult = hmAssoMembers;
				}
			} // arrayList of member_nums is not null

		} catch (Exception excp) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(excp, logger);
			String sAppInfo = (String) hmResult.get(CErrorDefs.COMMON_APP_INFO);
			if (sAppInfo == null)
				hmResult.put(CErrorDefs.COMMON_APP_INFO, excp.getMessage());
		} finally {
			logger.info(SpiMarker.getInstance(),CLASS_NAME+sMethodName+"DBTOOLS999 : STATUS={}", hmResult);
		}
		return hmResult;
	}

}
