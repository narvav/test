package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class TmemberlockoutId implements Serializable {

	private static final long serialVersionUID = 449906138574430941L;

	@Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)
	private Long memberNum;

	@Column(name = "LOCKOUT_ID", nullable = false, precision = 22, scale = 0)
	private Long lockoutId;

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TmemberlockoutId))
			return false;
		TmemberlockoutId castOther = (TmemberlockoutId) other;

		return ((this.getMemberNum() == castOther.getMemberNum()) || (this.getMemberNum() != null
				&& castOther.getMemberNum() != null && this.getMemberNum().equals(castOther.getMemberNum())))
				&& ((this.getLockoutId() == castOther.getLockoutId()) || (this.getLockoutId() != null
				&& castOther.getLockoutId() != null && this.getLockoutId().equals(castOther.getLockoutId())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getMemberNum() == null ? 0 : this.getMemberNum().hashCode());
		result = 37 * result + (getLockoutId() == null ? 0 : this.getLockoutId().hashCode());
		return result;
	}
}