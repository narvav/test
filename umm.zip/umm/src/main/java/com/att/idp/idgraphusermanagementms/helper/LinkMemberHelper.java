package com.att.idp.idgraphusermanagementms.helper;

import com.att.common.validators.DomainValidation;
import com.att.idp.cgclienthelpers.integration.CGRestClient;
import com.att.idp.cgclienthelpers.models.secureAccountProfile.AccountProfileResponse;
import com.att.idp.cgclienthelpers.utils.CommonConstants;
import com.att.idp.idgraph.association.add.AddAssociationHelper;
import com.att.idp.idgraphusermanagementms.db.helper.GetAssociatedMembersDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.GetMemberServicesDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.GetSlidInfoDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.LinkMemberDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.FraudLockDBHelper;
import com.att.idp.idgraphusermanagementms.helper.resetuserpassword.LockoutHelper;
import com.att.idp.idgraphusermanagementms.integration.MPSYSInternalRestClient;
import com.att.idp.idgraphusermanagementms.queue.message.helpers.LinkMemberQueueHelper;
import com.att.idp.idgraphusermanagementms.queue.message.sender.JMSQueueSender;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.helpers.AccountFraudLockHelper;
import com.att.mpsys.common.helpers.ConvertServicesHelper;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.MPSDefs;
import net.logstash.logback.argument.StructuredArguments;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static org.springframework.beans.factory.config.BeanDefinition.SCOPE_PROTOTYPE;


@Component
@Configuration
@Scope(SCOPE_PROTOTYPE)
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class LinkMemberHelper extends AbstractHelper {

    public static final String AL_DBUS_EVENTS = "alDbusEvents";
    private static final String sClassName = "LinkMemberHelper";
    private final Logger logger = LoggerFactory.getLogger(LinkMemberHelper.class);

    private boolean isTransactionRollbackOnError = false;

    @Value("${AUTOGEN_SLID_ACCOUNT_TYPE}")
    private String propAutoGenSlidAccountType;

    @Value("${ATLAS_AUTOGEN_SLID_ACCOUNT_TYPE}")
    private String propAtlasAutoGenSlidAccountType;

    @Value("${MYATT_AUTOGEN_SLID_ACCOUNT_TYPE}")
    private String propMyattAutoGenSlidAccountType;

    @Value("${RESIDENTIAL_ACCOUNT_SUBTYPES}")
    private String propResidentialAccountSubTypes;

    @Value("${BUSINESS_ACCOUNT_SUBTYPES}")
    private String propBusinessAccountSubTypes;

    @Value("${LSREG_INVALID_ACCOUNT_SUBTYPES}")
    private String propLSRegInvalidAccountSubTypes;

    @Value("${BYPASS_UVERSE_VALIDATION_TRANSACTION_NAMES}")
    private String propByPassUverseValidationTransactionNames;

    @Value("${PROP_ALLOW_MULTIPLE_UVERSE_LINK_TO_SLID}")
    private String propAllowMultipleUverseLinkToSlid;

    @Value("${CONTACT_EMAIL_NOT_ALLOWED_FOR_AUTOGENSLID}")
    private String propContactEmailNotAllowedForAutoGenSlid;

    @Autowired
    private AccountFraudLockHelper oAccountFraudLockHelper;
    @Autowired
    private LockoutHelper oLockoutHelper;
    @Autowired
    private GetAssociatedMembersDBHelper oGetAssociatedMembersDBHelper;
    @Autowired
    private GetMemberServicesDBHelper oGetMemberServicesDBHelper;
    @Autowired
    private GetSlidInfoDBHelper oGetSlidInfoDBHelper;
    @Autowired
    private LinkMemberDBHelper oLinkMemberDBHelper;
    @Autowired
    private UpdateMemberDataHelper oUpdateMemberDataHelper;
    @Autowired
    private AddUserHelper oAddUserHelper;
    @Autowired
    private DomainValidation oDomainValidation;
    @Autowired
    private JMSQueueSender oJMSQueueSender;
    @Autowired
    private LinkMemberQueueHelper oLinkMemberQueueHelper;
    @Autowired
    private MPSYSInternalRestClient oInternalIDPRestClient;
    @Autowired
    private CGRestClient cgRestClient;
    @Autowired
    private ConvertServicesHelper oConvertServicesHelper;
    @Autowired
    private UpdateUserHelper oUpdateUserHelper;
    @Autowired
    private FraudLockDBHelper oFraudLockDBHelper;
    @Autowired
    private AddAssociationHelper addAssociationHelper;

    @Value("${apiclient.rest.cg.secure.accoutProfile.endpoint}")
    private String cgAcctProfileEndpoint;
    @Value("${apiclient.rest.cg.secure.accoutProfile.url}")
    private String cgAcctProfileServerUrl;
    @Value("${apiclient.rest.cg.endpoint}")
    private String cgEndpoint;
    @Value("${apiclient.rest.cg.serverUrl}")
    private String cgServerUrl;

    private static final ArrayList<Object> alValidLocks = CommonUtil.getArrayList();
    static {
        alValidLocks.add("CHANGE_PASSWORD");
        alValidLocks.add("FORGOT_PASSWORD_PREQUAL");
        alValidLocks.add("PASSWORD_RESET_REQUESTS");
        alValidLocks.add("SECRET_ANSWER");
    }

    private String sCallingSystemId = null;
    private String sTransactionName = null;
    private String sTransactionId = null;
    private String sOrigTransactionName = null;
    boolean bBypassDotNetIdValidation = false;
    boolean bSlidMatchesMemberId = false;
    boolean bSlidCreated = false;
    //boolean bPasswordsMatched = false;

    private final ArrayList alMIDLocks = null;
    private ArrayList alSlidLocks = null;
    private HashMap<String, Object> hmDbMember = null;
    boolean bQueryBySorinvariantId = false;

    HashMap<String, Object> hmDBSlidInfo = null;
    HashMap<String, Object> hmMember = CommonUtil.getHashMap();
    HashMap<String, Object> hmMemberDbInfo = null;
    HashMap<String, Object> hmMemberDataInput = CommonUtil.getHashMap();

    ArrayList alRemoveSvcListEvent = null;
    ArrayList alDbusEvents = CommonUtil.getArrayList();
    boolean isMIDUversePrimary = false;

    /**
     * This method links a member by processing the provided input, member information, and SLID (Subscriber Line Identifier) information.
     * It validates the input data, processes the linking operation, and returns the result.
     *
     * @param hmInput      A map containing input data for the linking operation. Expected keys include:
     *                     - CommonDefs.CALLING_SYSTEM_ID: The ID of the calling system.
     *                     - CommonDefs.TRANSACTION_NAME: The name of the transaction.
     *                     - ProfileOrchestrationConstants.IDPTRACEID: The transaction trace ID.
     * @param hmMemberInfo A map containing member information required for the linking process.
     * @param hmSlidInfo   A map containing SLID information required for the linking process.
     * @return A map containing the result of the linking operation. The map may include:
     * - CommonDefs.COMMON_APP_STATUS_CODE: The status code of the operation.
     * - CErrorDefs.COMMON_APP_INFO: Additional information about the operation.
     * - Error details if the operation fails.
     */
    public Map<String, Object> linkMember(Map<String, Object> hmInput, Map<String, Object> hmMemberInfo, Map<String, Object> hmSlidInfo) {
        String sMethodName = ProfileOrchestrationConstants.LINK_MEMBER_METHOD;
        Map<String, Object> hmResult = null;
        String stAppStatusCode = null;
        String stAppInfo = null;

        if (hmInput.isEmpty() || hmMemberInfo.isEmpty() || (hmSlidInfo == null) || hmSlidInfo.isEmpty()) {
            stAppInfo = ProfileOrchestrationConstants.INPUT_HASH_IS_NULL;
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
            logger.info("{}{} LMH_LM.100.01 : {}", sClassName, sMethodName, stAppInfo);
            return hmResult;
        }

        if (hmInput.get(CommonDefs.CALLING_SYSTEM_ID) != null) {
            sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
        }
        if (hmInput.get(CommonDefs.TRANSACTION_NAME) != null) {
            sOrigTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
        }
        if (hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME) != null) {
            sOrigTransactionName = (String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME);
        }

        if (hmInput.get(ProfileOrchestrationConstants.IDPTRACEID) != null) {
            sTransactionId = (String) hmInput.get(ProfileOrchestrationConstants.IDPTRACEID);
        }

        try {
            logger.info("{}{} LMH_LM.100.02 :calling processLinkMember with input params : {}{}{}", sClassName, sMethodName, hmInput, hmMemberInfo, hmSlidInfo);
            hmResult = processLinkMember(hmInput, hmMemberInfo, hmSlidInfo);
            logger.info("{}{} LMH_LM.100.03 :Response from processLinkMember: {}", sClassName, sMethodName, hmResult);

            stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                stAppInfo = hmResult.get(CErrorDefs.COMMON_APP_INFO).toString();
                logger.info("{}{} LMH_LM.100.05 : {}", sClassName, sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                return hmResult;
            }
        } catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e, logger);
            stAppInfo = "Exception thrown in link member with request hmInput, hmMemberInfo, hmSlidInfo";
            logger.error("{}{} LMH_LM.100.06 :  {}", sClassName, sMethodName, stAppInfo);
        } finally {
            logger.info(SpiMarker.getInstance(), "{}{} HLP999 : response from link member with hmInput, hmMemberInfo, hmSlidInfo {}", sClassName, sMethodName, StructuredArguments.entries(hmResult));
        }
        return hmResult;
    }

    /**
     * Links a member using the provided input and member information.
     * This method processes the linking operation, validates the input data,
     * and returns the result of the operation.
     *
     * @param hmInput      A map containing input data for the linking operation.
     * @param hmMemberInfo A map containing member information required for the linking process.
     * @return A map containing the result of the linking operation, including status code and error details if any.
     */
    public Map<String, Object> linkMember(Map<String, Object> hmInput, Map<String, Object> hmMemberInfo) {
        String sMethodName = ProfileOrchestrationConstants.LINK_MEMBER_METHOD;
        String stAppStatusCode = null;
        Map<String, Object> hmResult = null;
        String stAppInfo = null;

        if (hmInput.isEmpty() || hmMemberInfo.isEmpty()) {
            stAppInfo = " hmInput/hmMemberInfo is NULL or EMPTY";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
            logger.info("{}{} LMH_LM.101.01 : {}", sClassName, sMethodName, stAppInfo);
            return hmResult;
        }
        hmDbMember = (HashMap<String, Object>) hmMemberInfo.get("member");

        if (hmDbMember == null || hmDbMember.isEmpty()) {
            stAppInfo = "hmMemberInfo is NULL or EMPTY";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
            logger.info("{}{} LMH_LM.101.01 : {}", sClassName, sMethodName, stAppInfo);
            return hmResult;
        }
        if (hmInput.get(CommonDefs.CALLING_SYSTEM_ID) != null) {
            sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
        }
        if (hmInput.get(CommonDefs.TRANSACTION_NAME) != null) {
            sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
        }
        if (hmInput.get(CommonDefs.TRANSACTION_ID) != null) {
            sTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);
        }
        if (hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME) != null) {
            sOrigTransactionName = (String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME);
        }

        logger.info(ProfileOrchestrationConstants.INPUT_HASH, sClassName, sMethodName, StructuredArguments.entries(hmMemberInfo));

        try {
            HashMap<String, Object> hmSlidInput = new HashMap<>();
            hmSlidInput.put(CommonDefs.ACCESS_ID, hmInput.get(CommonDefs.ACCESS_ID));
            hmSlidInput.put(CommonDefs.MEMBERID, hmInput.get(CommonDefs.MEMBERID));
            hmSlidInput.put(CommonDefs.DOMAIN, hmInput.get(CommonDefs.DOMAIN));

            bSlidMatchesMemberId = checkSlidMatchesMemberId(hmSlidInput);
            if (bSlidMatchesMemberId)
                hmInput.put(CommonDefs.IGNORE_PROFILE_UPDATE,CommonDefs.IND_Y);

            String sAccountType = (String) hmDbMember.get(MPSDefs.DB_ACCOUNT_TYPE);
            String sAccountSubType = (String) hmDbMember.get(MPSDefs.DB_ACCOUNT_SUBTYPE);

            HashMap<String, Object> hmParams = new HashMap<>();
            hmParams.put(ProfileOrchestrationConstants.ACCOUNT_TYPE, sAccountType);
            hmParams.put(ProfileOrchestrationConstants.ACCOUNT_SUB_TYPE, sAccountSubType);
            hmParams.put(ProfileOrchestrationConstants.SLID_MATCHES_WITH_MEMBER_ID, bSlidMatchesMemberId);
            hmParams.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
            hmParams.put(CommonDefs.ORIG_TRANSACTION_NAME, sOrigTransactionName);
            hmParams.put(CommonDefs.ORIG_TRANSID, sTransactionId);

            alDbusEvents.clear();
            hmMember.clear();
            //  query slidinfo and create slid if doesnot exists.
            hmResult = handleSlidInfoValidation(hmInput, (HashMap) hmMemberInfo, hmParams);

            if (hmResult != null) {
                stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                    stAppInfo = hmResult.get(CErrorDefs.COMMON_APP_INFO).toString();
                    logger.info("LMH_LM.101.11 : {}", CommonUtilHelper.sanitizeForLog(stAppInfo));
                    hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                    return hmResult;
                }
            }
            // AddSec member - adding AddMember event to the alDbusEvents
            if (hmResult != null && CommonDefs.IND_N.equals(hmResult.get(CommonDefs.CALLDBUS))) {
                String callDbus = (String) hmResult.get(CommonDefs.CALLDBUS);
                if (CommonDefs.IND_N.equals(callDbus)) {
                    HashMap<String, Object> dbusInput = (HashMap<String, Object>) hmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT);
                    alDbusEvents.add(dbusInput);
                }
            }
            logger.info("{}{} LMH_LM.101.08 :calling processLinkMember with input params : {}{}", sClassName, sMethodName, hmInput, hmDBSlidInfo);
            hmResult = processLinkMember(hmInput, hmMemberInfo, hmDBSlidInfo);
            logger.info("{}{} LMH_LM.101.09:Response from processLinkMember: {}", sClassName, sMethodName, hmResult);

            stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                stAppInfo = hmResult.get(CErrorDefs.COMMON_APP_INFO).toString();
                logger.info("{}{} LMH_LM.101.11 : {}", sClassName, sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                return hmResult;
            }
        } catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e, logger);
            stAppInfo = "Exception thrown linkmember() with request input and memberinfo : " + hmResult;
            logger.error("{}{} LMH_LM.101.12 :  {}", sClassName, sMethodName, HtmlUtils.htmlEscape(stAppInfo));
        } finally {
            logger.info(SpiMarker.getInstance(), "{}{} HLP999 : response from link member with hmInput and hmMemberInfo {}", sClassName, sMethodName, StructuredArguments.entries(hmResult));
        }
        return hmResult;
    }

    /**
     * Links a member using the provided input map.
     * This method processes the linking operation based on the input data,
     * performs necessary validations, and returns the result of the operation.
     *
     * @param hmInput A map containing input data for the linking operation.
     * @return A map containing the result of the linking operation, including status code and error details if any.
     */
    public Map<String, Object> linkMember(Map<String, Object> hmInput) {
        String sMethodName = ProfileOrchestrationConstants.LINK_MEMBER_METHOD;
        String stAppStatusCode = null;
        String stAppInfo = null;
        Map<String, Object> hmResult = null;
        String sAccountType = null;
        String sAccountSubType = null;
        boolean bSMBCustomer = false;

        if (hmInput.isEmpty()) {
            stAppInfo = ProfileOrchestrationConstants.INPUT_HASH_IS_NULL;
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
            logger.info("{}{} LMH_LM.102.01 : {}", sClassName, sMethodName, stAppInfo);
            return hmResult;
        }

        if (hmInput.get(CommonDefs.CALLING_SYSTEM_ID) != null) {
            sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
        }
        if (hmInput.get(CommonDefs.TRANSACTION_NAME) != null) {
            sOrigTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
        }
        if (hmInput.get(ProfileOrchestrationConstants.IDPTRACEID) != null) {
            sTransactionId = (String) hmInput.get(ProfileOrchestrationConstants.IDPTRACEID);
        }
        logger.info("{}{}HLP000 : Input Hashmap = {}", sClassName, sMethodName, hmInput);

        try {
            HashMap<String, Object> hmSlidInput = new HashMap<>();
            hmSlidInput.put(CommonDefs.ACCESS_ID, hmInput.get(CommonDefs.ACCESS_ID));
            hmSlidInput.put(CommonDefs.MEMBERID, hmInput.get(CommonDefs.MEMBERID));
            hmSlidInput.put(CommonDefs.DOMAIN, hmInput.get(CommonDefs.DOMAIN));

            bSlidMatchesMemberId = checkSlidMatchesMemberId(hmSlidInput);
            if (bSlidMatchesMemberId)
                hmInput.put(CommonDefs.IGNORE_PROFILE_UPDATE,CommonDefs.IND_Y);

            logger.info("{}{} LMH_LM.102.04 :calling queryMemberInfo with input params : {}", sClassName, sMethodName, hmInput);
            hmMemberDbInfo = queryMemberInfo(hmInput);
            logger.info("{}{} LMH_LM.102.05 :Response from queryMemberInfo: {}", sClassName, sMethodName, hmMemberDbInfo);

            if (hmMemberDbInfo == null || hmMemberDbInfo.isEmpty()) {
                stAppInfo = "Response from queryMemberInfo() is NULL or EMPTY";
                logger.info("{}{} LMH_LM.102.06 : {}", sClassName, sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                return hmResult;
            }
            stAppStatusCode = (String) hmMemberDbInfo.get(CErrorDefs.COMMON_APP_STATUS_CODE);

            if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
                if (MPSDefs.REC_NOT_FOUND.equals(stAppStatusCode)) {
                    stAppInfo = "Input MemberID Not found in DB";
                    logger.info("{}{} LMH_LM.102.07 : {}", sClassName, sMethodName, stAppInfo);
                    return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
                } else {
                    stAppInfo = "Error Response from queryMemberInfo()";
                    logger.info("{}{} LMH_LM.102.07.01 : {}, {}", sClassName, sMethodName, stAppStatusCode, stAppInfo);
                    return CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                }
            }

            HashMap hmMemberDB = (HashMap) hmMemberDbInfo.getOrDefault(
                    MPSDefs.MEM_PARENT_INFO_MEMBER_KEY,
                    hmMemberDbInfo.get(MPSDefs.MEM_PARENT_INFO_PARENT_KEY));

            String sSlidMemberNum = (String) hmMemberDB.get(MPSDefs.DB_SLID_MEMBER_NUM);
            sAccountType = (String) hmMemberDB.get(MPSDefs.DB_ACCOUNT_TYPE);
            sAccountSubType = (String) hmMemberDB.get(MPSDefs.DB_ACCOUNT_SUBTYPE);

            if ((sAccountSubType != null && sAccountSubType.equals("9")) || (sAccountType != null && sAccountType.equals("B"))) {
                bSMBCustomer = true;
            }

            String sDbSorName = (String) hmMemberDB.get(MPSDefs.DB_SOR_NAME);
            String sDbParentChildInd = (String) hmMemberDB.get(MPSDefs.DB_PARENT_CHILD_IND);
            if ((sDbSorName != null && sDbSorName.equalsIgnoreCase(MPSDefs.SOR_LS)) &&
                    (sDbParentChildInd != null && sDbParentChildInd.equalsIgnoreCase(MPSDefs.MPS_PARENT))) {
                isMIDUversePrimary = true;
            }
            if (sSlidMemberNum != null && !sSlidMemberNum.isEmpty()) {
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ID_ALREADY_LINKED_TO_SLID_NUM, "Input memberId  already linked to some other AccessID ");
                return hmResult;
            }

            HashMap<String, Object> hmParams = new HashMap<>();
            hmParams.put(ProfileOrchestrationConstants.ACCOUNT_TYPE, sAccountType);
            hmParams.put(ProfileOrchestrationConstants.ACCOUNT_SUB_TYPE, sAccountSubType);
            hmParams.put(ProfileOrchestrationConstants.SLID_MATCHES_WITH_MEMBER_ID, bSlidMatchesMemberId);
            hmParams.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
            hmParams.put(CommonDefs.ORIG_TRANSACTION_NAME, sOrigTransactionName);

            alDbusEvents.clear();
            hmMember.clear();
            hmResult = handleSlidInfoValidation(hmInput, hmMemberDbInfo, hmParams);

            if (hmResult != null) {
                stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                    stAppInfo = hmResult.get(CErrorDefs.COMMON_APP_INFO).toString();
                    logger.info("LMH_LM.101.11 : {}", CommonUtilHelper.sanitizeForLog(stAppInfo));
                    return hmResult;
                }
            }

            logger.info("{}{} LMH_LM.102.14 :calling processLinkMember with input params : {}{}{}", sClassName, sMethodName, hmInput, hmMemberDbInfo, hmDBSlidInfo);
            hmResult = processLinkMember(hmInput, hmMemberDbInfo, hmDBSlidInfo);
            logger.info("{}{} LMH_LM.102.15 :Response from processLinkMember: {}", sClassName, sMethodName, hmResult);

            stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                Object appInfoObj = hmResult.get(CErrorDefs.COMMON_APP_INFO);
                stAppInfo = appInfoObj != null ? appInfoObj.toString() : (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_MSG);
                logger.info("{}{} LMH_LM.102.17 : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }
        } catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e, logger);
            stAppInfo = "Exception thrown in linkmember() with hmInput : " + hmResult;
            logger.error("{}{} LMH_LM.102.18 :  {}", sClassName, sMethodName, HtmlUtils.htmlEscape(stAppInfo));
        } finally {
            logger.info(SpiMarker.getInstance(), "{}{}HLP999 : response from link member with hmInput {}", sClassName, sMethodName, StructuredArguments.entries(hmResult));
        }
        return hmResult;
    }

    /**
     * Processes the linking of a member with the provided input, member database info, and SLID info.
     * Handles business logic for linking, updates member attributes, and returns the result map.
     *
     * @param hmInput        Input map containing request data for linking.
     * @param hmMemberDbInfo Map containing member database information.
     * @param hmDBSlidInfo   Map containing SLID (Subscriber Line Identifier) information.
     * @return Map\<String, Object\> containing the result of the linking operation, including status codes and error details if any.
     */
    private Map<String, Object> processLinkMember(Map<String, Object> hmInput, Map<String, Object> hmMemberDbInfo, Map<String, Object> hmDBSlidInfo) {
        String sMethodName = ".processLinkMember.";
        String stAppStatusCode = null;
        String stAppInfo = null;
        Map<String, Object> hmResult = null;
        logger.info("{}{} LMH_PLM.01 : Input Hash : {}", sClassName, sMethodName,StructuredArguments.entries(hmInput));

        HashMap<String, Object> hmResponse = CommonUtil.getHashMap();
        ArrayList alUpdateMember = CommonUtil.getArrayList();
        ArrayList alAddUpdDelServices = CommonUtil.getArrayList();
        String sParentChildInd = null;
        String sSorName = null;
        String sDbSorName = null;
        String sDbMemberState = null;
        String sMemberNum = "";

        HashMap<String, Object> hmDbMemberServices = null;
        HashMap hmTempMemberUpdateAttributes = null;
        String sMemberSHA1Password = null;
        String sMemberMD5Password = null;
        String sMemberDES3Password = null;
        String sMemberEncPassword = null;

        try {
            HashMap<String, Object> hmParentDbInfo = (HashMap<String, Object>) hmMemberDbInfo.get(MPSDefs.MEM_PARENT_INFO_PARENT_KEY);
            HashMap<String, Object> hmMemDbInfo = (HashMap<String, Object>) hmMemberDbInfo.get(MPSDefs.MEM_PARENT_INFO_MEMBER_KEY);

            sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
            sTransactionId = (String) hmInput.get(ProfileOrchestrationConstants.IDPTRACEID);
            sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
            if (hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME) != null) {
                sOrigTransactionName = (String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME);
            }

            if (hmMemDbInfo != null && !hmMemDbInfo.isEmpty()) {
                sParentChildInd = (String) hmMemDbInfo.get(MPSDefs.DB_PARENT_CHILD_IND);
                sDbSorName = (String) hmMemDbInfo.get(MPSDefs.DB_SOR_NAME);
                sDbMemberState = (String) hmMemDbInfo.get(MPSDefs.DB_MEMBER_STATE);
                sMemberNum = (String) hmMemDbInfo.get(CommonDefs.DB_MEMBER_NUM);
                sMemberSHA1Password = (String) hmMemDbInfo.get(MPSDefs.DB_SHA1_PASSWORD);
                sMemberMD5Password = (String) hmMemDbInfo.get(MPSDefs.DB_MD5_PASSWORD);
                sMemberDES3Password = (String) hmMemDbInfo.get(MPSDefs.DB_DES3_PASSWORD);
                sMemberEncPassword = (String) hmMemDbInfo.get(MPSDefs.DB_ENC_PASSWORD);
                hmDbMemberServices = (HashMap) hmMemDbInfo.get(MPSDefs.SERVICES);
                this.hmDbMember = hmMemDbInfo;
            } else if (hmParentDbInfo != null && !hmParentDbInfo.isEmpty()) {
                sParentChildInd = (String) hmParentDbInfo.get(MPSDefs.DB_PARENT_CHILD_IND);
                sDbSorName = (String) hmParentDbInfo.get(MPSDefs.DB_SOR_NAME);
                sDbMemberState = (String) hmParentDbInfo.get(MPSDefs.DB_MEMBER_STATE);
                sMemberNum = (String) hmParentDbInfo.get(CommonDefs.DB_MEMBER_NUM);
                sMemberSHA1Password = (String) hmParentDbInfo.get(MPSDefs.DB_SHA1_PASSWORD);
                sMemberMD5Password = (String) hmParentDbInfo.get(MPSDefs.DB_MD5_PASSWORD);
                sMemberDES3Password = (String) hmParentDbInfo.get(MPSDefs.DB_DES3_PASSWORD);
                sMemberEncPassword = (String) hmParentDbInfo.get(MPSDefs.DB_ENC_PASSWORD);
                hmDbMemberServices = (HashMap) hmParentDbInfo.get(MPSDefs.SERVICES);
                this.hmDbMember = hmParentDbInfo;
            }
            // check if input handle is already linked to input SLIDID.
            String sSlidMemberNum = (String) hmDbMember.get(MPSDefs.DB_SLID_MEMBER_NUM);

            if (sSlidMemberNum != null && !sSlidMemberNum.isEmpty()) {
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ID_ALREADY_LINKED_TO_SLID_NUM, "Input memberId  already linked to some other SLID ");
                return hmResult;
            }
            String sCbrOptOut = null;
            HashMap<String, Object> sSlidServices = null;
            ArrayList<String> sLinkedUsers = null;
            HashMap<String, Object> hmDbSlid = (HashMap<String, Object>) hmDBSlidInfo.getOrDefault(CommonDefs.KEY_SLID_INFO, hmDBSlidInfo);

            if (hmDbSlid != null && !hmDbSlid.isEmpty()) {
                sCbrOptOut = (String) hmDbSlid.get(MPSDefs.DB_CBR_OPT_OUT);
                sSlidServices = (HashMap<String, Object>) hmDbSlid.get(CommonDefs.SERVICES);
                sLinkedUsers = (ArrayList<String>) hmDbSlid.get(MPSDefs.KEY_LINKED_USERS);
            }

            String sAutoGenSlidMemberNum = null;
            String sAutoGenSlidGroupNum = null;
            ArrayList<String> alByPassUverseValidationTransactionNames = CommonUtil.parseToArray(propByPassUverseValidationTransactionNames, CommonDefs.VALUE_SEPARATOR_CHAR);
            logger.info("{}{} LMH_PLM.03 : Property propByPassUverseValidationTransactionNames : {}", sClassName, sMethodName, alByPassUverseValidationTransactionNames);

            if ((CommonDefs.DATAMGT.equals(sCallingSystemId) && bSlidMatchesMemberId) || sOrigTransactionName != null && alByPassUverseValidationTransactionNames.contains(sOrigTransactionName)) {
                bBypassDotNetIdValidation = true;
            }
            if (hmDbMemberServices != null && !hmDbMemberServices.isEmpty() && hmDbMemberServices.containsKey(CommonDefs.PORTAL_SERVICE) && !bBypassDotNetIdValidation) {

                HashMap<String, Object> hmPortal = (HashMap) hmDbMemberServices.get(CommonDefs.PORTAL_SERVICE);
                String sPortalProvider = (String) hmPortal.get(MPSDefs.DB_PORTAL_PROVIDER);

                if (sPortalProvider != null && sPortalProvider.equalsIgnoreCase(CommonDefs.PORTAL_PROVIDER_ATT_NAP)) {
                    stAppInfo = "Member portal provider is ATT NAP so LinkMember is not allowed.";
                    logger.info("{}{} LMH_PLM.04 : {}", sClassName, sMethodName, stAppInfo);
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                    return hmResult;
                }
            }

            if (sDbMemberState != null && sDbMemberState.equalsIgnoreCase(MPSDefs.INACT_STATE) && !bBypassDotNetIdValidation) {
                stAppInfo = ".net Internet member ID is in terminated status.";
                logger.info("{}{} LMH_PLM.05 : {}", sClassName, sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, stAppInfo);
                return hmResult;
            }
            if (sDbSorName != null && sDbSorName.equalsIgnoreCase(MPSDefs.SOR_LS) && !bBypassDotNetIdValidation) {
                if (hmDbMemberServices == null) {
                    stAppInfo = "Linking member does not have any services in MPS";
                    logger.info("{}{} LMH_PLM.06 : {}", sClassName, sMethodName, stAppInfo);
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                    return hmResult;

                } else if (hmDbMemberServices.containsKey(CommonDefs.UVERSE_SERVICE)) {
                    HashMap<String, Object> hmUverse = (HashMap) hmDbMemberServices.get(CommonDefs.UVERSE_SERVICE);
                    String sDbServieStatus = (String) hmUverse.get(MPSDefs.SERVICE_STATUS);
                    if (sDbServieStatus != null && sDbServieStatus.equalsIgnoreCase(MPSDefs.TERMINATED)) {
                        stAppInfo = "Linking LS member UVERSE account should be in Enabled/Suspended status. ";
                        logger.info("{}{} LMH_PLM.07 : {}", sClassName, sMethodName, stAppInfo);
                        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                        return hmResult;
                    }
                }
            }

            if (bSlidMatchesMemberId)
                hmInput.put(CommonDefs.IGNORE_PROFILE_UPDATE, CommonDefs.IND_Y);

            String stSlidMD5Password = null;
            stSlidMD5Password = (String) hmDbSlid.get(MPSDefs.DB_MD5_PASSWORD);

            if (stSlidMD5Password == null || stSlidMD5Password.isEmpty()) {
                stAppInfo = "Required MD5 password for Slid is not present in MPSDB";
                hmResult = CommonErrorMap.makeCategoryMap(
                        CErrorDefs.ERR_REQD_PWD_FORMAT_NOT_ON_FILE_NUM, stAppInfo);
                logger.info("{}{} LMH_PLM.08 : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }

            /*  //commeting the queryLockout code due to password cutover to haloc
            verify for lockout details of slid response
            ArrayList<String> alTempSlidLocks = null;

            if (hmDbSlid != null && !hmDbSlid.isEmpty())
                alTempSlidLocks = (ArrayList<String>) hmDbSlid.get(CommonDefs.MEMBER_LOCKOUT);

            if (alTempSlidLocks != null && !alTempSlidLocks.isEmpty()) {

                HashMap<String, Object> hmSlidLockInput = CommonUtil.getHashMap();
                hmSlidLockInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
                hmSlidLockInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
                hmSlidLockInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
                hmSlidLockInput.put(CommonDefs.MEMBER_LOCKOUT, alTempSlidLocks);

                logger.info("{}{} LMH_PLM.08 :Calling to oLockoutHelper.queryLockout with input : {}", sClassName, sMethodName, hmSlidLockInput);
                hmResult = oLockoutHelper.queryLockout(hmSlidLockInput);
                logger.info("{}{} LMH_PLM.09 :Response from queryLockout: {}", sClassName, sMethodName, hmResult);

                stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                    stAppInfo = "Error from LockoutHelper().queryLockout call for Slid";
                    logger.info("{}{} LMH_PLM.11 : {}", sClassName, sMethodName, stAppInfo);
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                    return hmResult;
                }
                ArrayList<String> alActiveLocks = (ArrayList<String>) hmResult.get(CommonDefs.ACTIVE_LOCKS);

                for (Object lock : alActiveLocks) {
                    HashMap<String, Object> lockMap = (HashMap<String, Object>) lock;
                    String lockName = (String) lockMap.get(MPSDefs.DB_LOCKOUT_NAME);
                    if (alValidLocks.contains(lockName)) {
                        String appInfo = "Slid is locked with " + lockName + " Lock Name";
                        logger.info("{}{} LMH_PLM.12 : Slid  is locked with {} Lock Name", sClassName, sMethodName, lockName);
                        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_MID_LOCKOUT_NUM, appInfo);
                        return hmResult;
                    }
                }
            }*/
            //fraud lock check
            if (hmDBSlidInfo != null && !hmDBSlidInfo.isEmpty()) {
                logger.info("{}{} LMH_PLM.13 :Calling  checkFraudLock with input {}: ", sClassName, sMethodName, StructuredArguments.entries(hmDbSlid));
                hmResult = checkFraudLock(hmDbSlid);
                logger.info("{}{} LMH_PLM.14 :Response from checkFraudLock: {}", sClassName, sMethodName, hmResult);
            }
            stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                if ((stAppStatusCode).equals(CErrorDefs.ERR_USER_FRAUD_LOCKED)) {
                    stAppInfo = "User is fraud locked in MPS DB";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_FRAUD_LOCKED_NUM, stAppInfo);
                    logger.info("{}{}LMH_PLM.16.01 : {} ", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                } else  if ((stAppStatusCode).equals(CErrorDefs.ERR_ACCOUNT_IN_FRAUD_STATUS)) {
                    stAppInfo = "Account is fraud locked in MPS DB";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ACCOUNT_IN_FRAUD_STATUS_NUM, stAppInfo);
                    logger.info("{}{}LMH_PLM.16.02 : {} ", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                }else {
                    stAppInfo = "Error from checkFraudLock";
                    logger.info("{}{} LMH_PLM.16.03 : {}", sClassName, sMethodName, stAppInfo);
                    hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                    return hmResult;
                }
            }
             /* //commeting the queryLockout code due to password cutover to haloc
              //verify for lockout details of member response
            ArrayList<String> alMemberLocks = (ArrayList<String>) hmDbMember.get(MPSDefs.DB_MEMBERLOCKOUT);

            if (alMemberLocks != null && !alMemberLocks.isEmpty()) {
                HashMap<String, Object> hmMemberLockInput = CommonUtil.getHashMap();
                hmMemberLockInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
                hmMemberLockInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
                hmMemberLockInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
                hmMemberLockInput.put(MPSDefs.DB_MEMBERLOCKOUT, alMemberLocks);

                logger.info("{}{}} LMH_PLM.17 : Calling LockoutHelper.queryLockout with input : {}", sClassName, sMethodName, hmMemberLockInput);
                hmResult = oLockoutHelper.queryLockout(hmMemberLockInput);
                logger.info("{}{}} LMH_PLM.18 : Response from LockoutHelper.queryLockout : {}", sClassName, sMethodName, hmResult);

                stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                    stAppInfo = "Error from LockoutHelper().queryLockout call for Member";
                    logger.info("{}{} LMH_PLM.20 : {}", sClassName, sMethodName, stAppInfo);
                    hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                    return hmResult;
                }
                ArrayList<String> alActiveLocks = (ArrayList<String>) hmResult.get(CommonDefs.ACTIVE_LOCKS);
                if (alActiveLocks != null && !alActiveLocks.isEmpty()) {
                    for (Object lock : alActiveLocks) {
                        HashMap<String, Object> lockMap = (HashMap<String, Object>) lock;
                        String lockName = (String) lockMap.get(MPSDefs.DB_LOCKOUT_NAME);
                        if (CommonDefs.CHANGE_PASSWORD.equalsIgnoreCase(lockName)) {
                            stAppInfo = "MemberId is locked with " + lockName + " Lock Name";
                            logger.info("{}{} LMH_PLM.21 : Member Id is locked with {} Lock Name", sClassName, sMethodName, lockName);
                            hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                            return hmResult;
                        }
                    }
                }
            }*/
            hmMember.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);
            hmMember.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);
            alUpdateMember.add(hmMember);
            //1410:- US293406: RIL changes to LinkInternetAccount to clear CBR Opt Out flag.
            if (hmDbSlid != null && !hmDbSlid.isEmpty()) {
                if (sCbrOptOut != null && !sCbrOptOut.isEmpty()) {
                    HashMap<String, Object> hmSLIDUpdate = new HashMap<>();
                    hmSLIDUpdate.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);
                    hmSLIDUpdate.put(MPSDefs.DB_MEMBER_NUM, hmDbSlid.get(MPSDefs.DB_MEMBER_NUM));
                    hmSLIDUpdate.put(MPSDefs.DB_CBR_OPT_OUT, null);
                    alUpdateMember.add(hmSLIDUpdate);
                }
            }
            hmMemberDataInput.put(MPSDefs.DB_MEMBER_TABLE, alUpdateMember);
            String sLSMIDBan = (String) hmDbMember.get(MPSDefs.DB_BAN);
            hmTempMemberUpdateAttributes = new HashMap<String, Object>(hmMember);
            HashMap<String, Object> hmMIDServices = (HashMap<String, Object>) hmDbMember.get(CommonDefs.SERVICES);
            HashMap<String, Object> hmSlidServices = null;

            if (hmDbSlid != null) {
                hmSlidServices = (HashMap<String, Object>) hmDbSlid.get(CommonDefs.SERVICES);
            }
            ArrayList alLinkedUsers = null;
            if (hmDbSlid != null)
                alLinkedUsers = (ArrayList) hmDbSlid.get(MPSDefs.KEY_LINKED_USERS);

            String sMemberSor = (String) hmDbMember.get(MPSDefs.DB_SOR_NAME);

            ArrayList alAllowMultipleUverseLinkToSlid = null;
            if (sParentChildInd != null && sParentChildInd.equalsIgnoreCase(MPSDefs.MPS_PARENT) &&
                    hmMIDServices != null && !hmMIDServices.isEmpty() && hmMIDServices.containsKey(CommonDefs.UVERSE_SERVICE) &&
                    sMemberSor != null && sMemberSor.equals(MPSDefs.SOR_LS)) {
                alAllowMultipleUverseLinkToSlid = CommonUtil.parseToArray(propAllowMultipleUverseLinkToSlid, CommonDefs.VALUE_SEPARATOR_CHAR);
                logger.info("{}{} LMH_PLM.22 : Property propAllowMultipleUverseLinkToSlid : {}", sClassName, sMethodName, alAllowMultipleUverseLinkToSlid);

                if ((alAllowMultipleUverseLinkToSlid.contains(CommonDefs.DEFAULT_NO)) && alLinkedUsers != null && !alLinkedUsers.isEmpty()
                        && (sOrigTransactionName == null || !sOrigTransactionName.equals("UnlinkInternetAccount"))) {
                    HashMap hmEachLinkedUser = null;
                    HashMap hmLinkedServices = null;
                    sParentChildInd = null;

                    for (int i = 0; i < alLinkedUsers.size(); i++) {
                        hmEachLinkedUser = (HashMap) alLinkedUsers.get(i);
                        sParentChildInd = (String) hmEachLinkedUser.get(MPSDefs.DB_PARENT_CHILD_IND);
                        hmLinkedServices = (HashMap<String, Object>) hmEachLinkedUser.get(CommonDefs.SERVICES);
                        if ((sParentChildInd != null && sParentChildInd.equalsIgnoreCase(MPSDefs.MPS_PARENT) &&
                                (hmLinkedServices != null && hmLinkedServices.containsKey(CommonDefs.UVERSE_SERVICE)))) {
                            stAppInfo = "SLID already linked to different UVERSE primary id";
                            logger.info("{}{} LMH_PLM.23 : {}", sClassName, sMethodName, stAppInfo);
                            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SLID_ALREADY_LINKED_TO_DIFF_UVERSE_ID_NUM, stAppInfo);
                            return hmResult;
                        } // end of parent_child_ind is "P" and has UVERSE
                    }//end of  for
                }
                HashMap<String, Object> hmDbEachTitanInstance = null;
                HashMap<String, Object> hmDbEachService = null;
                String dbServiceKeyName = null;
                ArrayList alInstanceFormatServices = null;
                HashMap<String, Object> hmDbService = null;

                ListIterator listIte = null;
                ArrayList alKeys = CommonUtil.getArrayList();
                alKeys.add(MPSDefs.DB_ROLES);

                String sDbSorInvariantId = null;
                String sDbTitanSorName = null;
                ArrayList alInstanceServiceRole = null;
                String stInstanceServiceRole = null;
                HashMap hmUpdateMemSvcInput = null;
                HashMap hmGetAssoMembersResponse = null;
                HashMap hmDbGetAssoInput = null;
                ArrayList alAssociatedSlids = null;

                HashMap hmEachAssocSlid = null;
                HashMap<String, Object> hmAssocSlidServices = null;
                ArrayList alInstanceFormatSlidServices = null;
                ListIterator objAssocListIte = null;
                HashMap<String, Object> hmDbAssocEachService = null;
                ArrayList alAssocInstanceServiceRole = null;
                HashMap<String, Object> hmAssocInstanceServiceRole = null;
                String stAssocInstanceServiceRole = null;
                boolean bTitanHasOwnerRole = false;
                String sMainSlidMemberNum = null;

                //if ( bTitanOnFlag )
                boolean bUverseTitanAlreadyAssocToSLID = false;
                if (hmSlidServices != null && !hmSlidServices.isEmpty()) {
                    Iterator itServicesItr = hmSlidServices.keySet().iterator();
                    while (itServicesItr.hasNext()) {
                        dbServiceKeyName = (String) itServicesItr.next();
                        hmDbService = (HashMap) hmSlidServices.get(dbServiceKeyName);
                        if (dbServiceKeyName.equals(CommonDefs.TITAN_SERVICE)) {
                            alInstanceFormatServices = getServiceInfo(hmDbService, dbServiceKeyName, alKeys); // return arraylist
                            listIte = alInstanceFormatServices.listIterator();
                            while (listIte.hasNext()) {
                                hmDbEachTitanInstance = (HashMap) listIte.next();
                                sDbSorInvariantId = (String) hmDbEachTitanInstance.get(MPSDefs.DB_SOR_INVARIANT_ID);
                                sDbTitanSorName = (String) hmDbEachTitanInstance.get(CommonDefs.SOR_NAME);

                                if (sDbSorInvariantId != null && sDbSorInvariantId.equals(sLSMIDBan)) {
                                    bUverseTitanAlreadyAssocToSLID = true;
                                    bTitanHasOwnerRole = false;
                                    alInstanceServiceRole = (ArrayList) hmDbEachTitanInstance.get(MPSDefs.DB_ROLES);

                                    if (alInstanceServiceRole != null && !alInstanceServiceRole.isEmpty()) {
                                        //Iterate instance service role
                                        Iterator alInstanceServiceRoleItr = alInstanceServiceRole.iterator();
                                        while (alInstanceServiceRoleItr.hasNext()) {
                                            HashMap hmInstanceServiceRole = (HashMap) alInstanceServiceRoleItr.next();
                                            if (hmInstanceServiceRole != null && !hmInstanceServiceRole.isEmpty()) {
                                                //Retrieve role_name
                                                stInstanceServiceRole = (String) hmInstanceServiceRole.get(MPSDefs.DB_ROLE_NAME);

                                                if (stInstanceServiceRole != null && stInstanceServiceRole.equals(CommonDefs.KEY_ROLE_NAME_OWNER)) {
                                                    logger.info("{}{}LMH_PLM.24 :Slid has Default role on Titan account  {}", sClassName, sMethodName, hmInstanceServiceRole);
                                                    bTitanHasOwnerRole = true;
                                                    break;
                                                }
                                            }
                                        }// end of while

                                        if (!bTitanHasOwnerRole && !bBypassDotNetIdValidation) {
                                            logger.info("{}{}LMH_PLM.25 :SLID did not have OWNER role on TITAN account {}", sClassName, sMethodName, alInstanceServiceRole);
                                            hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "SLID did not have OWNER role on TITAN account");
                                            return hmResponse;
                                        }
                                    }// end of alInstanceServiceRole
                                    else {
                                        logger.info("{}{} LMH_PLM.26 :TITAN does not have any roles information in db {}", sClassName, sMethodName, alInstanceServiceRole);
                                        hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, "TITAN does not have any roles information in db ");
                                        return hmResponse;
                                    }

                                    hmUpdateMemSvcInput = CommonUtil.getHashMap();
                                    sMainSlidMemberNum = (String) hmDbSlid.get(MPSDefs.DB_MEMBER_NUM);
                                    hmUpdateMemSvcInput.put(MPSDefs.DB_MEMBER_NUM, hmDbSlid.get(MPSDefs.DB_MEMBER_NUM));
                                    hmUpdateMemSvcInput.put(MPSDefs.DB_SERVICE_ID, hmDbEachTitanInstance.get(CommonDefs.SERVICE_ID));
                                    hmUpdateMemSvcInput.put(MPSDefs.DB_SOR_INVARIANT_ID, hmDbEachTitanInstance.get(MPSDefs.DB_SOR_INVARIANT_ID)); //vikas added
                                    hmUpdateMemSvcInput.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);
                                    hmUpdateMemSvcInput.put(MPSDefs.DB_UVERSE_SERVICE_IND, CommonDefs.IND_Y);
                                    alAddUpdDelServices.add(hmUpdateMemSvcInput);

                                    if (hmMemberDbInfo != null) {
                                        HashMap hmMemberInfo = (HashMap) hmMemberDbInfo.get(MPSDefs.MEM_PARENT_INFO_MEMBER_KEY);
                                        HashMap hmParentInfo = (HashMap) hmMemberDbInfo.get(MPSDefs.MEM_PARENT_INFO_PARENT_KEY);
                                        if (hmMemberInfo == null) {
                                            hmGetAssoMembersResponse = hmParentInfo;
                                        }
                                    }
                                    //Skip db calls as its already present
                                    if(hmGetAssoMembersResponse == null || hmGetAssoMembersResponse.isEmpty()) {

                                        //find all other SLIDs that have AUTHORIZEDUSER access to the TITAN account.
                                        //For each SLID found, Set the UVERSE_SERVICE_IND to ‘Y’ on that TITAN account
                                        hmDbGetAssoInput = CommonUtil.getHashMap();
                                        hmDbGetAssoInput.put(CommonDefs.SERVICE_TYPE, hmDbEachTitanInstance.get(CommonDefs.SERVICE_TYPE));
                                        hmDbGetAssoInput.put(CommonDefs.SOR_ID, hmDbEachTitanInstance.get(CommonDefs.SOR_ID));
                                        hmDbGetAssoInput.put(CommonDefs.SOR_INVARIANT_ID, sDbSorInvariantId);
                                        bQueryBySorinvariantId = true;

                                        logger.info("{}{} LMH_PLM.27 :calling queryMemberInfo... hmDbGetAssoInput={}", sClassName, sMethodName, hmDbGetAssoInput);
                                        hmGetAssoMembersResponse = queryMemberInfo(hmDbGetAssoInput);
                                        logger.info("{}{} LMH_PLM.28 :resposne from queryMemberInfo... hmDbGetAssoInput={}", sClassName, sMethodName, hmGetAssoMembersResponse);

                                        // RS892X: This block will never be null as queryMemberInfo always returns a map
                                        if (hmGetAssoMembersResponse == null || hmGetAssoMembersResponse.isEmpty()) {
                                            stAppInfo = "Response from queryMemberInfo() is NULL or EMPTY";
                                            logger.info("{}{} LMH_PLM.28.1 : {}", sClassName, sMethodName, stAppInfo);
                                            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                                            return hmResult;
                                        }
                                        stAppStatusCode = (String) hmGetAssoMembersResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                                        if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
                                            if (String.valueOf(CErrorDefs.ERR_REC_NOT_FOUND_NUM).equals(stAppStatusCode)) {
                                                stAppInfo = "Input MemberID Not found in DB";
                                                logger.info("{}{} LMH_PLM.28.2 : {}", sClassName, sMethodName, stAppInfo);
                                                return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
                                            } else {
                                                stAppInfo = "Error Response from queryMemberInfo()";
                                                logger.info("{}{} LMH_PLM.29 : {}", sClassName, sMethodName, stAppInfo);
                                                return CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                                            }
                                        }
                                    }
                                    //
                                    if (hmGetAssoMembersResponse != null && !hmGetAssoMembersResponse.isEmpty()) {
                                        alAssociatedSlids = (ArrayList) hmGetAssoMembersResponse.get(MPSDefs.ASSOCIATED_MEMBERS);
                                        if (alAssociatedSlids != null && !alAssociatedSlids.isEmpty()) {
                                            List alAssocSlidServices;
                                            for (int i = 0; i < alAssociatedSlids.size(); i++) {
                                                hmEachAssocSlid = (HashMap) alAssociatedSlids.get(i);
                                                alAssocSlidServices =  (List)hmEachAssocSlid.get(CommonDefs.SERVICES);
                                                logger.info("{}{} LMH_PLM.30 :hmEachAssocSlid: {}", sClassName, sMethodName, StructuredArguments.entries(hmEachAssocSlid));

                                                String sAssocUserMemberNum = (String) hmEachAssocSlid.get(MPSDefs.DB_MEMBER_NUM);
                                                if (!sMainSlidMemberNum.equals(sAssocUserMemberNum)) {
                                                    if (alAssocSlidServices != null && !alAssocSlidServices.isEmpty() ) {//hmAssocSlidServices.containsKey(CommonDefs.TITAN_SERVICE)) {
                                                        for( Object serviceObj : alAssocSlidServices ) {
                                                            hmAssocSlidServices = (HashMap) serviceObj;

                                                            //  String serviceName = (String) hmAssocSlidServices.get(CommonDefs.SERVICE_NAME);
                                                            if(hmAssocSlidServices.containsKey(CommonDefs.TITAN_SERVICE)) {
                                                                HashMap hmAssoSlidTitanService = (HashMap) hmAssocSlidServices.get(CommonDefs.TITAN_SERVICE);
                                                                alInstanceFormatSlidServices = getServiceInfo(hmAssoSlidTitanService, CommonDefs.TITAN_SERVICE, alKeys); // return arraylist

                                                                objAssocListIte = alInstanceFormatSlidServices.listIterator();
                                                                while (objAssocListIte.hasNext()) {
                                                                    hmDbAssocEachService = (HashMap) objAssocListIte.next();
                                                                    alAssocInstanceServiceRole = (ArrayList) hmDbAssocEachService.get(MPSDefs.DB_ROLES);

                                                                    if (alAssocInstanceServiceRole != null && !alAssocInstanceServiceRole.isEmpty()) {
                                                                        //Iterate instance service role
                                                                        Iterator alAssocInstanceServiceRoleItr = alAssocInstanceServiceRole.iterator();
                                                                        while (alAssocInstanceServiceRoleItr.hasNext()) {
                                                                            hmAssocInstanceServiceRole = (HashMap) alAssocInstanceServiceRoleItr.next();
                                                                            if (hmAssocInstanceServiceRole != null && !hmAssocInstanceServiceRole.isEmpty()) {
                                                                                //Retrieve role_status
                                                                                stAssocInstanceServiceRole = (String) hmAssocInstanceServiceRole.get(MPSDefs.DB_ROLE_NAME);
                                                                                if (stAssocInstanceServiceRole != null && stAssocInstanceServiceRole.equals(CommonDefs.KEY_ROLE_NAME_AUTHORIZEDUSER)) {

                                                                                    logger.info("{}{}LMH_PLM.31 :Slid has AUTHORIZEDUSER role on Titan account {}", sClassName, sMethodName, hmAssocInstanceServiceRole);

                                                                                    hmUpdateMemSvcInput = CommonUtil.getHashMap();
                                                                                    hmUpdateMemSvcInput.put(MPSDefs.DB_MEMBER_NUM, sAssocUserMemberNum);
                                                                                    hmUpdateMemSvcInput.put(MPSDefs.DB_SERVICE_ID, hmDbAssocEachService.get(CommonDefs.SERVICE_ID));
                                                                                    hmUpdateMemSvcInput.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);
                                                                                    hmUpdateMemSvcInput.put(MPSDefs.DB_UVERSE_SERVICE_IND, CommonDefs.IND_Y);
                                                                                    hmUpdateMemSvcInput.put(MPSDefs.DB_SOR_INVARIANT_ID, hmDbAssocEachService.get(MPSDefs.DB_SOR_INVARIANT_ID));
                                                                                    hmUpdateMemSvcInput.put(MPSDefs.DB_SOR_ID, hmDbAssocEachService.get(CommonDefs.SOR_ID));

                                                                                    logger.info("{}{} LMH_PLM.32 :Updating UVERSE_SERVICE_IND for these TITAN associated slids  {}", sClassName, sMethodName, alAddUpdDelServices);

                                                                                }
                                                                            }
                                                                        }// end of while (alAssocInstanceServiceRoleItr
                                                                    }// end of alInstanceServiceRole
                                                                }// end of while (objAssocListIte
                                                            }// if TITAN service
                                                        } // loop alAssocSlidServices
                                                    } // if alAssocSlidServices not null
                                                }
                                            } //end of  for alAssociatedSlids
                                        } // end of if alAssociatedSlids not null
                                    } // end of if hmGetAssoMembersResponse not null
                                }
                            } // end of while alInstanceFormatServices.itr
                        } // if
                    }// end of slid services while
                }// end of if slid services

                //1510 - Updated to merge 1507 STAR Defect SID 41699- LinkInternet should not add TITAN account, when call is from MergeSLIDProfile, as MergeSlidProfile would be adding TITAN at their end after this LinkInternetAccount call is done
                if (sOrigTransactionName != null && sOrigTransactionName.equals(ProfileOrchestrationConstants.MERGE_SLID_PROFILE_TRANSACTION_NAME)) {
                    bUverseTitanAlreadyAssocToSLID = true;
                    logger.info("{}{} LMH_PLM.33 : For MergeSlidProfile do not add TITAN account in LinkInternet so set bUverseTitanAlreadyAssoToSLID {}",
                            sClassName, sMethodName, bUverseTitanAlreadyAssocToSLID);

                }//END - 1510

                //Check if input LS Primary BAN is not associated with other SLID's Titan account, if yes return ERR_CANNOT_OPERATE
                //Else, call AddAccountHelper to add TITAN Account with owner role to input SLID
                if (!bUverseTitanAlreadyAssocToSLID) {
                    //Ignore getAssociatedMembers call for UnlinkMemberId because old LS Primary unlink has not happened yet
                    if (sOrigTransactionName == null ||
                            (sOrigTransactionName != null && !sOrigTransactionName.equals("UnlinkInternetAccount"))) {

                        HashMap<String, Object> hmGetAssocMemInp = CommonUtil.getHashMap();
                        hmGetAssocMemInp.put(MPSDefs.DB_SOR_INVARIANT_ID1, sLSMIDBan);
                        hmGetAssocMemInp.put("queryOnlySlids", CommonDefs.IND_Y);
                        ArrayList<String> alQueryRoles = CommonUtil.getArrayList();
                        alQueryRoles.add("ALL");
                        hmGetAssocMemInp.put(MPSDefs.QUERY_ROLES_INFO_FLAG, alQueryRoles);
                        hmGetAssocMemInp.put(MPSDefs.DB_QUERY_MEMBERLOCKOUT_FLAG, CommonDefs.IND_Y);
                        hmGetAssocMemInp.put(MPSDefs.WS_SECURITY_ALL_REQ, CommonDefs.IND_Y);
                        hmGetAssocMemInp.put(MPSDefs.MAKE_MODEL_REQ, CommonDefs.IND_Y);

                        logger.info("{}{} LMH_PLM.33.1 : calling getAssociatedMembers for unlink check with input={}", sClassName, sMethodName, hmGetAssocMemInp);

                        hmGetAssoMembersResponse = oGetAssociatedMembersDBHelper.getAssociatedMembers(hmGetAssocMemInp);

                        logger.info("{}{} LMH_PLM.33.2 : response from getAssociatedMembers for unlink check={}", sClassName, sMethodName, hmGetAssoMembersResponse);

                        stAppStatusCode = (String) hmGetAssoMembersResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                        String sUnlinkCheckAppStatusMsg = (String) hmGetAssoMembersResponse.get(CErrorDefs.COMMON_APP_INFO);
                        if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
                            if (!CErrorDefs.ERR_ASSOCIATED_MEMBER_NOT_FOUND_MSG.equalsIgnoreCase(sUnlinkCheckAppStatusMsg)) {
                                logger.info("{}{} LMH_PLM.33.3 : getAssociatedMembers response is other than ASSOCIATED_MEMBER_NOT_FOUND so return error to caller", sClassName, sMethodName);
                                return hmResult = hmGetAssoMembersResponse;
                            }
                        } else {
                            alAssociatedSlids = (ArrayList) hmGetAssoMembersResponse.get(MPSDefs.ASSOCIATED_MEMBERS);
                            if (alAssociatedSlids != null && !alAssociatedSlids.isEmpty()) {
                                for (int i = 0; i < alAssociatedSlids.size(); i++) {
                                    hmEachAssocSlid = (HashMap) alAssociatedSlids.get(i);
                                    Object oAssocSlidServices = hmEachAssocSlid.get(CommonDefs.SERVICES);
                                    logger.info("{}{} LMH_PLM.33.4 : hmEachAssocSlid: {}", sClassName, sMethodName, StructuredArguments.entries(hmEachAssocSlid));
                                    // services from getAssociatedMembers is a HashMap<serviceName, serviceData>, not a List
                                    if (oAssocSlidServices instanceof HashMap) {
                                        HashMap hmUnlinkCheckSvcMap = (HashMap) oAssocSlidServices;
                                        if (hmUnlinkCheckSvcMap.containsKey(CommonDefs.TITAN_SERVICE)) {
                                            HashMap hmAssoSlidTitanService = (HashMap) hmUnlinkCheckSvcMap.get(CommonDefs.TITAN_SERVICE);
                                            ArrayList alUnlinkCheckInstanceServices = getServiceInfo(hmAssoSlidTitanService, CommonDefs.TITAN_SERVICE, alKeys);
                                            ListIterator unlinkCheckListIte = alUnlinkCheckInstanceServices.listIterator();
                                            while (unlinkCheckListIte.hasNext()) {
                                                HashMap hmDbAssocEachSvc = (HashMap) unlinkCheckListIte.next();
                                                String sDbAssocSorInvariantId = (String) hmDbAssocEachSvc.get(MPSDefs.DB_SOR_INVARIANT_ID);
                                                if (sDbAssocSorInvariantId != null && sDbAssocSorInvariantId.equals(sLSMIDBan)) {
                                                    logger.info("{}{} LMH_PLM.33.5 : Other than input SLID is associated with LS BAN of the LS Primary Member Id, returning ERR_CANNOT_OPERATE", sClassName, sMethodName);
                                                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM,
                                                            "Other than input SLID is associated with LS BAN of the LS Primary Member Id");
                                                    return hmResult;
                                                }
                                            }
                                        }
                                    }
                                } // end of for alAssociatedSlids
                            } // end of if alAssociatedSlids not null
                        }
                    } // end of UnlinkInternetAccount api check

                    HashMap hmAccount = CommonUtil.getHashMap();
                    ArrayList alAccountList = CommonUtil.getArrayList();
                    hmAccount.put(CommonDefs.SERVICE_NAME, CommonDefs.TITAN_SERVICE);
                    hmAccount.put(CommonDefs.SERVICE_STATUS, MPSDefs.ENABLED);
                    hmAccount.put(CommonDefs.SOR_INVARIANT_ID, sLSMIDBan);
                    hmAccount.put(CommonDefs.INSTANCE_ID, sLSMIDBan);
                    hmAccount.put(CommonDefs.KEY_SOR_NAME, MPSDefs.SOR_LS);

                    String sAcctNickName = Optional.ofNullable((String) hmInput.get(ProfileOrchestrationConstants.NICK_NAME))
                            .filter(nickName -> !nickName.isEmpty())
                            .orElse(ProfileOrchestrationConstants.LINK_MEMBER_TRANSACTION_NAME);
                    hmAccount.put(ProfileOrchestrationConstants.NICK_NAME, sAcctNickName);
                    hmAccount.put(CommonDefs.ROLE_NAME, CommonDefs.KEY_ROLE_NAME_OWNER);
                    hmAccount.put(CommonDefs.ROLE_STATUS, CommonDefs.ROLE_STATUS_ENABLED);
                    alAccountList.add(hmAccount);

                    HashMap hmAddAccountReq = CommonUtil.getHashMap();
                    hmAddAccountReq.put(CommonDefs.ORIG_TRANSACTION_NAME, sOrigTransactionName);
                    hmAddAccountReq.put(CommonDefs.TRANSACTION_ID, sTransactionId);
                    hmAddAccountReq.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                    hmAddAccountReq.put(CommonDefs.SLID, hmInput.get(CommonDefs.ACCESS_ID));
                    hmAddAccountReq.put(CommonDefs.GUID, hmDbSlid.get(MPSDefs.DB_MEMBER_NUM));

                    hmAddAccountReq.put(CommonDefs.TRANSACTION_NAME, CommonDefs.ADDACCOUNT_GENERIC_TRANSACTION_NAME);
                    hmAddAccountReq.put(CommonDefs.ACCOUNT_LIST, alAccountList);
                    hmAddAccountReq.put(CommonDefs.CALLDBUS, CommonDefs.IND_N);

                    logger.info("{}{} LMH_PLM.34 : callTitanAddAssociation {}", sClassName, sMethodName, hmAddAccountReq);
                    Map<String, Object> hmAddAssocResp = callTitanAddAssociation(hmAddAccountReq, hmDbSlid);

                    stAppStatusCode = (String) hmAddAssocResp.get(CErrorDefs.COMMON_APP_STATUS_CODE);

                    if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                        stAppInfo = (String) hmAddAssocResp.get(MPSDefs.APP_INFO);
                        logger.info("{}{} LMH_PLM.35 : {}", sClassName, sMethodName, stAppInfo);
                        hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                        return hmResult;
                    }
                    applyTitanAssociationResponse(hmAddAssocResp, hmMemberDataInput, alDbusEvents, hmDbSlid);
                    //prepare getSlidInfo response with TITAN account after calling AddAccountHelper,
                    //otherwise it is not setting default_account=Y
                    //RS892X: This block will never be true as its never set
                    if (bSlidCreated) {
                        hmInput.put(MPSDefs.DB_SLID_MEMBER_NUM, sAutoGenSlidMemberNum);
                        hmInput.put(MPSDefs.DB_GROUP_NUM, sAutoGenSlidGroupNum);
                    }
                }
            } // end of if (!bUverseTitanAlreadyAssocToSLID)

            if (!alAddUpdDelServices.isEmpty()) {
                hmMemberDataInput.put(MPSDefs.DB_MEMBERSERVICE_TABLE, alAddUpdDelServices);
                hmMemberDataInput.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);
                hmMemberDataInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
                hmMemberDataInput.put(CommonDefs.TRANSACTION_ID, sTransactionId.split(":")[0]);
                hmMemberDataInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                hmMemberDataInput.put(CommonDefs.HANDLE, hmDbMember.get(MPSDefs.DB_MEMBER_NAME));
                hmMemberDataInput.put(CommonDefs.DOMAIN, hmDbMember.get(MPSDefs.DB_DOMAIN_NAME));
                hmMemberDataInput.put(MPSDefs.DB_MEMBER_NUM, hmDbMember.get(MPSDefs.DB_MEMBER_NUM));
            }

            logger.info("{}{} LMH_PLM.36 :Calling  oUpdateMemberDataHelper.processData()for updating user details  {}", sClassName, sMethodName, alAddUpdDelServices);
            hmResponse = oUpdateMemberDataHelper.processData(hmMemberDataInput);
            logger.info("{}{} LMH_PLM.37 :Response from  oUpdateMemberDataHelper.processData() {}", sClassName, sMethodName, hmResponse);
            stAppStatusCode = (String) hmResponse.get(MPSDefs.APP_STATUS_CODE);

            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                stAppInfo = hmResponse.get(CErrorDefs.COMMON_APP_INFO).toString();
                logger.info("{}{} LMH_PLM.37.01 : {}", sClassName, sMethodName, stAppInfo);
                hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                return hmResponse;
            }
            HashMap hmUpdateMember = CommonUtil.getHashMap();

            hmUpdateMember.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
            hmUpdateMember.put(CommonDefs.TRANSACTION_ID, sTransactionId);
            hmUpdateMember.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);

            ArrayList alTotalLocks = CommonUtil.getArrayList();
            HashMap hmMIDLocksUpdate = CommonUtil.getHashMap();

            hmMIDLocksUpdate.put(MPSDefs.DB_MEMBER_NUM, hmDbMember.get(MPSDefs.DB_MEMBER_NUM));
            hmMIDLocksUpdate.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_DELETE);
            hmMIDLocksUpdate.put(MPSDefs.DELETE_LOCKS_BY_MEMBER_NUM_FLAG, CommonDefs.IND_Y);
            alTotalLocks.add(hmMIDLocksUpdate);

            if (alSlidLocks != null && !alSlidLocks.isEmpty())
                alTotalLocks.addAll(alSlidLocks);
            hmUpdateMember.put(MPSDefs.DB_MEMBERLOCKOUT, alTotalLocks);

            // added as part of 2011-FEB SSO
            if ((hmMIDServices != null) && (hmMIDServices.containsKey(MPSDefs.MOSUB_SERVICE))) {
                HashMap hmProcessedData = processAddUpdDelServices((HashMap) hmInput);
                logger.info("{}{} LMH_PLM.41 :Resposne from  processMosub method   {}", sClassName, sMethodName, hmProcessedData);
                stAppStatusCode = (String) hmProcessedData.get(MPSDefs.APP_STATUS_CODE);
                if (!stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
                    return hmResponse = hmProcessedData;

                hmUpdateMember.put(MPSDefs.WS_ADD_SERVICES, hmProcessedData.get(MPSDefs.WS_ADD_SERVICES));
                hmUpdateMember.put(MPSDefs.WS_REMOVE_MEMBER_SERVICES, hmProcessedData.get(MPSDefs.WS_REMOVE_MEMBER_SERVICES));
                hmUpdateMember.put(MPSDefs.WS_REMOVE_MOBILITY_DEVICES, hmProcessedData.get(MPSDefs.WS_REMOVE_MOBILITY_DEVICES));
                hmUpdateMember.put(MPSDefs.DB_MEMBERSERVICE_TABLE, hmProcessedData.get(MPSDefs.DB_MEMBERSERVICE_TABLE));
            }
            logger.info("{}{} LMH_PLM.42 :Calling  oUpdateMemberDataHelper.processData()for updating user details  {}", sClassName, sMethodName, alAddUpdDelServices);
            hmResponse = oUpdateMemberDataHelper.processData(hmUpdateMember);
            logger.info("{}{} LMH_PLM.43 :Response from  oUpdateMemberDataHelper.processData() {}", sClassName, sMethodName, hmResponse);

            stAppStatusCode = (String) hmResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                stAppInfo = "Error from UpdateMemberDataHelper.processData() call";
                logger.info("{}{} LMH_PLM.44 : {}", sClassName, sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                return hmResult;
            }

            // build Request for UpdateMemberHelper to build Request for UpdateProfileInfo
            HashMap hmUpdMemberInput = CommonUtil.getHashMap();

            String sIgnoreEDDNotification = (String) hmInput.get("ignoreEDDNotification");
            String sIgnoreProfileUpdate = (String) hmInput.get(CommonDefs.IGNORE_PROFILE_UPDATE);
            if (( sIgnoreProfileUpdate == null ) || sIgnoreProfileUpdate.equalsIgnoreCase(CommonDefs.IND_N))
            {
                HashMap<String, Object> hmDbSlidResp = (HashMap<String, Object>) hmDBSlidInfo.get(CommonDefs.KEY_SLID_INFO);
                if (sIgnoreEDDNotification != null && sIgnoreEDDNotification.trim().equals(CommonDefs.IND_Y))
                    hmUpdMemberInput.put("DoNotCallNotificationHelper", CommonDefs.IND_Y);

                hmUpdMemberInput.put(CommonDefs.TRANSACTION_NAME, CommonDefs.UPDATEMEMBER_GENERIC_TRANSACTION_NAME);
                hmUpdMemberInput.put(CommonDefs.ORIG_TRANSACTION_NAME, sTransactionName);
                hmUpdMemberInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.IDPTRACEID));

                hmUpdMemberInput.put(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
                hmUpdMemberInput.put(ProfileOrchestrationConstants.IDPTRACEID, hmInput.get(ProfileOrchestrationConstants.IDPTRACEID));
                hmUpdMemberInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                hmUpdMemberInput.put(CommonDefs.HANDLE, hmDbMember.get(MPSDefs.DB_MEMBER_NAME));
                hmUpdMemberInput.put(CommonDefs.DOMAIN, hmDbMember.get(MPSDefs.DB_DOMAIN_NAME));

                hmUpdMemberInput.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);
                hmUpdMemberInput.put(MPSDefs.DB_MEMBER_NAME, hmDbMember.get(MPSDefs.DB_MEMBER_NAME));

                hmUpdMemberInput.put(CommonDefs.FIRST_NAME, hmDbMember.get(MPSDefs.DB_LC_FIRSTNAME));
                hmUpdMemberInput.put(CommonDefs.LAST_NAME, hmDbMember.get(MPSDefs.DB_LC_LASTNAME));

                //   hmUpdMemberInput.put(CommonDefs.DOMAIN, "slid.dum");
                hmUpdMemberInput.put(CommonDefs.PARENT_HANDLE, hmDbMember.get(MPSDefs.DB_PARENT_NAME));
                hmUpdMemberInput.put(CommonDefs.PARENT_DOMAIN, hmDbMember.get(MPSDefs.DB_PARENT_DOMAIN));// use member
                hmUpdMemberInput.put(CommonDefs.GUID, hmDbMember.get(MPSDefs.DB_MEMBER_NUM));
                hmUpdMemberInput.put(CommonDefs.MIGRATION_IND, hmDbMember.get(MPSDefs.DB_MIGRATION_IND));
                hmUpdMemberInput.put(CommonDefs.DB_PARENT_CHILD_IND, hmDbMember.get(MPSDefs.DB_PARENT_CHILD_IND));
                hmUpdMemberInput.put(CommonDefs.CALLDBUS, CommonDefs.IND_N);

                if (hmTempMemberUpdateAttributes.containsKey(MPSDefs.DB_FIRSTNAME))
                    hmUpdMemberInput.put(CommonDefs.FIRST_NAME, hmTempMemberUpdateAttributes.get(MPSDefs.DB_FIRSTNAME));

                if (hmTempMemberUpdateAttributes.containsKey(MPSDefs.DB_LASTNAME))
                    hmUpdMemberInput.put(CommonDefs.LAST_NAME, hmTempMemberUpdateAttributes.get(MPSDefs.DB_LASTNAME));

                if (hmTempMemberUpdateAttributes.containsKey(MPSDefs.DB_FULLNAME))
                    hmUpdMemberInput.put(CommonDefs.FULLNAME, hmTempMemberUpdateAttributes.get(MPSDefs.DB_FULLNAME));

                if (hmTempMemberUpdateAttributes.get(MPSDefs.DB_CONTACT_EMAIL) != null)
                    hmUpdMemberInput.put(CommonDefs.CONTACT_EMAIL, hmTempMemberUpdateAttributes.get(MPSDefs.DB_CONTACT_EMAIL));

                if (hmTempMemberUpdateAttributes.get(MPSDefs.DB_CONTACT_EMAIL_EST_DATE) != null)
                    hmUpdMemberInput.put(CommonDefs.CONTACT_EMAIL_EST_DATE, hmTempMemberUpdateAttributes.get(MPSDefs.DB_CONTACT_EMAIL_EST_DATE));

                if (hmTempMemberUpdateAttributes.get(MPSDefs.DB_SECURITY_ANSWER_1) != null)
                    hmUpdMemberInput.put(CommonDefs.ONLINE1_SECURITY_ANSWER, hmTempMemberUpdateAttributes.get(MPSDefs.DB_SECURITY_ANSWER_1));

                if (hmTempMemberUpdateAttributes.get(MPSDefs.DB_SECURITY_ANSWER_2) != null)
                    hmUpdMemberInput.put(CommonDefs.ONLINE2_SECURITY_ANSWER, hmTempMemberUpdateAttributes.get(MPSDefs.DB_SECURITY_ANSWER_2));

                if (hmTempMemberUpdateAttributes.get(MPSDefs.DB_SECURITY_QUESTION_ID_1) != null)
                    hmUpdMemberInput.put(CommonDefs.ONLINE1_SECURITY_QUESTION, hmDbSlidResp.get(MPSDefs.DB_SECURITY_QUESTION_1));

                if (hmTempMemberUpdateAttributes.get(MPSDefs.DB_SECURITY_QUESTION_ID_2) != null)
                    hmUpdMemberInput.put(CommonDefs.ONLINE2_SECURITY_QUESTION, hmDbSlidResp.get(MPSDefs.DB_SECURITY_QUESTION_2));

                sParentChildInd = (String) hmDbMember.get(MPSDefs.DB_PARENT_CHILD_IND);
                sSorName = (String) hmDbMember.get(MPSDefs.DB_SOR_NAME);
                String sMemberState = (String) hmDbMember.get(MPSDefs.DB_MEMBER_STATE);

                if ((sParentChildInd.equalsIgnoreCase(MPSDefs.MPS_PARENT)) &&
                        (sSorName.equalsIgnoreCase(MPSDefs.SOR_LS)) && hmDbSlidResp != null &&
                        (hmDbSlidResp.get(MPSDefs.DB_CONTACT_EMAIL) != null) &&
                        (!sMemberState.equalsIgnoreCase(MPSDefs.INACT_STATE))) {
                    hmUpdMemberInput.put(CommonDefs.CONTACT_EMAIL, hmDbSlidResp.get(MPSDefs.DB_CONTACT_EMAIL));
                }
                hmUpdMemberInput.put("isRequestor", CommonDefs.IND_Y);
                hmUpdMemberInput.put("relatedID", hmDbMember.get(MPSDefs.DB_MEMBER_NAME) + "@" + hmDbMember.get(MPSDefs.DB_DOMAIN_NAME));
                // Updated to send service level sors and Offline S/Q in input to UpdateMember Helper
                HashMap hmServices = (HashMap) hmDbMember.get(CommonDefs.SERVICES);

                ArrayList alServiceLevelSors = null;
                if (hmServices != null && !hmServices.isEmpty()) {
                    //ConvertServicesHelper.convertServices method to get service level sors
                    hmResult = oConvertServicesHelper.convertServices(hmServices);
                    logger.info("{}{} LMH_PLM.45 : Response from ConvertServicesHelper. convertServices{}", sClassName, sMethodName, hmResult);
                    if (hmResult == null || hmResult.isEmpty()) {
                        stAppInfo = "Response from ConvertServicesHelper.convertServices() is null or empty";
                        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                        return hmResult;
                    }
                    alServiceLevelSors = (ArrayList) hmResult.get(CommonDefs.SERVICE_LEVEL_SORS);
                    if (alServiceLevelSors == null || alServiceLevelSors.isEmpty()) {
                        alServiceLevelSors = CommonUtil.getArrayList();
                        alServiceLevelSors.add(hmDbMember.get(MPSDefs.DB_SOR_NAME));
                    }
                } else {
                    alServiceLevelSors = CommonUtil.getArrayList();
                    alServiceLevelSors.add(hmDbMember.get(MPSDefs.DB_SOR_NAME));
                }
                hmUpdMemberInput.put(CommonDefs.SERVICE_LEVEL_SORS, alServiceLevelSors);

                if (hmResult != null && hmResult.get(CommonDefs.SERVICES) != null)
                    hmUpdMemberInput.put(CommonDefs.SERVICES, hmResult.get(CommonDefs.SERVICES));

                //Updated for RegisterMember for correct proofing version calculation
                if (hmInput.containsKey(CommonDefs.OFFLINE1_SECURITY_QUESTION)) {
                    hmUpdMemberInput.put(CommonDefs.SECURITY_QUESTION_ON_FILE,
                            hmInput.get(CommonDefs.OFFLINE1_SECURITY_QUESTION));

                } else {
                    sParentChildInd = (String) hmDbMember.get(MPSDefs.DB_PARENT_CHILD_IND);
                    sSorName = (String) hmDbMember.get(MPSDefs.DB_SOR_NAME);
                    sMemberState = (String) hmDbMember.get(MPSDefs.DB_MEMBER_STATE);
                    String sBan = (String) hmDbMember.get(CommonDefs.BAN);

                    if ((sParentChildInd != null && sSorName != null && sMemberState != null) &&
                            (sParentChildInd.equalsIgnoreCase(MPSDefs.MPS_PARENT)) &&
                            (sSorName.equalsIgnoreCase(MPSDefs.SOR_LS)) &&
                            (!sMemberState.equalsIgnoreCase(MPSDefs.INACT_STATE)) &&
                            (sBan != null && !sBan.trim().isEmpty())) {

                        // CG call to fetch security question
                        String sSecurityQuestion = null;
                        AccountProfileResponse hmCustResponse = null;
                        HashMap hmCGResponse = null;
                        HashMap<String, Object> hmCGInput = new HashMap();
                        hmCGInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                        hmCGInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
                        hmCGInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
                        hmCGInput.put(CommonDefs.KEY_ACCOUNT_ID, sBan); // Use BAN as account ID for CG call
                        hmCGInput.put(CommonConstants.CG_API_NAME, CommonConstants.CG_ACCOUNT_PROFILE_API_NAME);
                        hmCGInput.put(CommonDefs.KEY_ACCOUNT_TYPE, ProfileOrchestrationConstants.UVERSE_ACCOUNT_TYPE);
                        hmCGInput.put(CommonConstants.CG_SERVER_URL, cgAcctProfileServerUrl);
                        hmCGInput.put(CommonConstants.CG_END_POINT, cgAcctProfileEndpoint);

                        logger.info("{}{} LMH_PLM.46 :Calling CGRestClient.getCGSyncCall with input:{}", sClassName, sMethodName, StructuredArguments.entries(hmCGInput));

                        hmCGResponse = (HashMap) cgRestClient.getCGSyncCall(hmCGInput);

                        logger.info("{}{} LMH_PLM.47: Response CGRestClient.getCGSyncCall : {}", sClassName, sMethodName, hmCGResponse);

                        // RS892X: This block will never be null as cgRestClient.getCGSyncCall always returns a map with result/error
                        if (hmCGResponse == null || hmCGResponse.isEmpty()) {
                            stAppInfo = "cgRestClient.getCGSyncCall() returned empty response.";
                            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                            logger.info("{}{} LMH_PLM.48: CG Response : {} ", sClassName, sMethodName, stAppInfo);
                            return hmResult;
                        }
                        stAppStatusCode = (String) hmCGResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                        if (stAppStatusCode != null && !CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
                            stAppInfo = (String) hmCGResponse.get(CErrorDefs.COMMON_APP_INFO);
                            if (stAppStatusCode.equals(CErrorDefs.ERR_INVALID_DATA) && stAppInfo.contains("Data Error")) {
                                hmCGResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ACCOUNT_NOT_FOUND_NUM, stAppInfo);
                            }
                            logger.info("{}{} LMH_PLM.49:Bypassing due to error return from CGRestClient call: {} ", sClassName, sMethodName, stAppInfo);
                        } else {
                            hmCustResponse = (AccountProfileResponse) hmCGResponse.get(CommonDefs.CUSTOMER);
                            if (hmCustResponse != null) {
                                sSecurityQuestion = hmCustResponse.getAuthenticationQuestion();
                                if (sSecurityQuestion != null && !sSecurityQuestion.isEmpty())
                                    hmUpdMemberInput.put(CommonDefs.SECURITY_QUESTION_ON_FILE, sSecurityQuestion);
                            }
                        }
                    } else if (hmDbMember.get(MPSDefs.DB_SECURITY_QUESTION) != null) {
                        hmUpdMemberInput.put(CommonDefs.SECURITY_QUESTION_ON_FILE,
                                hmDbMember.get(MPSDefs.DB_SECURITY_QUESTION));
                    }
                    //DF# 273 - DEC2011 - CLARIFY updateContactEmail notification needs BAN, if available.
                    if (hmDbMember.get(CommonDefs.BAN) != null && !((String) hmDbMember.get(CommonDefs.BAN)).isEmpty()
                            && sSorName != null && sSorName.equalsIgnoreCase(MPSDefs.SOR_LS)) {
                        hmUpdMemberInput.put(CommonDefs.BAN, hmDbMember.get(CommonDefs.BAN));
                    }

                    logger.info("{}{} LMH_PLM.50:Request to UpdateUser.updateUser method : {}", sClassName, sMethodName, hmUpdMemberInput);
                    hmResult = oUpdateUserHelper.updateUser(hmUpdMemberInput);
                    logger.info("{}{} LMH_PLM.51 :Response from UpdateMemberHelper.updateUser method : {}", sClassName, sMethodName, hmResult);

                    stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
                    if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS) && !stAppStatusCode.equals("903"))
                        return hmResult;

                    ArrayList alUpdMemberEvents = (ArrayList) hmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT);

                    if (alUpdMemberEvents != null && !alUpdMemberEvents.isEmpty()) {
                        for (Iterator<HashMap> iterator = alUpdMemberEvents.iterator(); iterator.hasNext(); ) {
                            HashMap<String, Object> hmEachEvent = iterator.next();
                            if (hmEachEvent != null) {
                                String sEventName = (String) hmEachEvent.get(CommonDefs.EVENTNAME);
                                if (sEventName != null && sEventName.equalsIgnoreCase(CommonDefs.CONTEXT_NotificationEvent))
                                    iterator.remove();
                            }
                        }
                        alDbusEvents.addAll(alUpdMemberEvents);
                    }
                }
            }  // End of UpdateMemberHelper

            if (alRemoveSvcListEvent != null && !alRemoveSvcListEvent.isEmpty()) {
                for (Object objInner : alRemoveSvcListEvent) {
                    if (objInner instanceof ArrayList) {
                        alDbusEvents.addAll((ArrayList) objInner);
                    } else if (objInner instanceof HashMap) {
                        alDbusEvents.add(objInner);
                    }
                }
            }
            //dbus call
            String idpTraceid = (String) hmInput.get(ProfileOrchestrationConstants.IDPTRACEID);
            hmInput.put(CommonDefs.ORIG_TRANSACTION_NAME, sOrigTransactionName);
            hmInput.put(CommonDefs.ORIG_TRANSID, idpTraceid);

            hmInput.put(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID, idpTraceid.split(":")[0]);
            hmInput.put(ProfileOrchestrationConstants.DBUS_TRANSACTION_NAME, ProfileOrchestrationConstants.LINK_MEMBER_TRANSACTION_NAME);

            hmInput.put("hmTempMemberUpdateAttributes", hmTempMemberUpdateAttributes);
            hmInput.put(AL_DBUS_EVENTS, alDbusEvents);
            //hmInput.put("bPasswordsMatched", bPasswordsMatched);

            // Sending message to MQ
            Map hmDbusResult = oLinkMemberQueueHelper.sendMessageToMQ(hmInput, hmDbMember, (HashMap<String, Object>) hmDBSlidInfo);
            logger.info(SpiMarker.getInstance(), "LMH_PLM.52 : Response from LinkMemberQueueHelper.sendMessageToMQ : {}",
                    StructuredArguments.entries(hmDbusResult));

            if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmDbusResult)) {
                hmResult = CommonUtilHelper.sysErrorHashMap("null response from LinkMemberQueueHelper.sendMessageToMQ");
                isTransactionRollbackOnError = true;
                return hmResult;
            } else {
                stAppStatusCode = (String) hmDbusResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
                if (StringUtils.isBlank(stAppStatusCode)) {
                    isTransactionRollbackOnError = true;
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                    logger.info("{}{}LMH_PLM.52.1 : {}", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                } else if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                    isTransactionRollbackOnError = true;
                    stAppInfo = (String) hmDbusResult.get(CommonDefs.COMMON_APP_INFO);
                    logger.info("{}{} LMH_PLM.53 : {}", sClassName, sMethodName, stAppInfo);
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                    hmResult = hmDbusResult;
                    return hmResult;
                }
            }
            // Default success if no error occur
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
            // AddSec Member Id changes
            String sCallDbus = (String) hmInput.get(CommonDefs.CALLDBUS);
            if (sCallDbus != null && sCallDbus.equals(CommonDefs.IND_N)) {
                ArrayList<?> alDbusInput = (ArrayList<?>) hmDbusResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT);
                hmResult.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, alDbusInput);
            }
        } catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e, logger);
            stAppInfo = "Exception thrown processLinkMember method";
            logger.error("{}{} LMH_PLM.54 :  {}", sClassName, sMethodName, stAppInfo);
        } finally {
            String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
            if (isTransactionRollbackOnError && sAppCategoryCode != null
                    && !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
                hmResult.put("isTransactionRollback", "Y");
            }
            logger.info(SpiMarker.getInstance(), "{}{} LMH_PLM.55 HLP999 : response from processLinkMember {}", sClassName, sMethodName, StructuredArguments.entries(hmResult));
        }
        return hmResult;
    }

    /**
     * Queries member information based on the provided input map.
     * The input map should contain necessary keys to identify and retrieve member details.
     * Returns a HashMap containing member information and associated data.
     *
     * @param hmInput a map of input parameters required for querying member info
     * @return HashMap containing the queried member information and related attributes
     */
    private HashMap queryMemberInfo(Map<String, Object> hmInput) {

        String sMethodName = ".queryMemberInfo";
        HashMap<String, Object> hmResult = null;
        String sAppInfo = null;
        String sAppStatusCode = null;
        String sDomain = (String) hmInput.get(CommonDefs.DOMAIN);
        String sMemberId = (String) hmInput.get(CommonDefs.MEMBERID);
        HashMap<String, Object> hmDbParentData = null;
        try {
            logger.info(ProfileOrchestrationConstants.INPUT_HASH, sClassName, sMethodName, StructuredArguments.entries(hmInput));

            if (bQueryBySorinvariantId) {
                String sSorInvariantId = (String) hmInput.get(CommonDefs.SOR_INVARIANT_ID);

                if (sSorInvariantId != null && !sSorInvariantId.trim().isEmpty()) {
                    HashMap<String, Object> hmGetAssocMemInp = CommonUtil.getHashMap();
                    hmGetAssocMemInp.put(MPSDefs.DB_SOR_INVARIANT_ID1, sSorInvariantId);
                    hmGetAssocMemInp.put("queryOnlySlids", CommonDefs.IND_Y);

                    ArrayList<String> alQueryRoles = CommonUtil.getArrayList();

                    alQueryRoles.add("ALL");
                    hmGetAssocMemInp.put(MPSDefs.QUERY_ROLES_INFO_FLAG, alQueryRoles);
                    hmGetAssocMemInp.put(MPSDefs.DB_QUERY_MEMBERLOCKOUT_FLAG, CommonDefs.IND_Y);
                    hmGetAssocMemInp.put(MPSDefs.WS_SECURITY_ALL_REQ, CommonDefs.IND_Y);
                    hmGetAssocMemInp.put(MPSDefs.MAKE_MODEL_REQ, CommonDefs.IND_Y);

                    logger.info("{}{} LMH_QMI.01 : GetAssociatedMembersDBHelper.getAssociatedMembers with input ={}", sClassName, sMethodName, hmGetAssocMemInp);
                    hmResult = oGetAssociatedMembersDBHelper.getAssociatedMembers(hmGetAssocMemInp);
                    logger.debug(SpiMarker.getInstance(), "{}{}LMH_QMI.02 : GetAssociatedMembersDBHelper.getAssociatedMembers Response ={}", sClassName, sMethodName, hmResult);

                    if (hmResult == null || hmResult.isEmpty()) {
                        sAppInfo = "Response from  GetAssociatedMembersDBHelper is either null or empty";
                        logger.info("{}{} LMH_QMI.03 : {}", sClassName, sMethodName, sAppInfo);
                        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, HtmlUtils.htmlEscape(sAppInfo));
                        return hmResult;
                    }
                    sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                    if (!(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode))) {
                        sAppInfo = (String) hmResult.get(CErrorDefs.COMMON_APP_INFO);
                        logger.info("{}{} LMH_QMI.04 : {}", sClassName, sMethodName, sAppInfo);
                        return hmResult;
                    }
                }
            }
            // Query member info by passing input handle and domain
            if (sMemberId != null && sDomain != null) {
                HashMap<String, Object> hmDbInput = new HashMap<String, Object>();
                hmDbInput.put(CommonDefs.MEMBERID, sMemberId);
                hmDbInput.put(CommonDefs.DOMAIN, sDomain);
                hmDbInput.put(MPSDefs.DB_QUERY_MEMBERLOCKOUT_FLAG, CommonDefs.IND_Y);
                hmDbInput.put(MPSDefs.WS_SECURITY_ALL_REQ, CommonDefs.IND_Y);
                hmDbInput.put(MPSDefs.MAKE_MODEL_REQ, CommonDefs.IND_Y);

                logger.info("{}{} LMH_QMI.05 : calling  LinkMemberDBHelper getMemberParentServices with input ={}", sClassName, sMethodName, hmDbInput);
                hmResult = oLinkMemberDBHelper.getMemberParentServices(hmDbInput);
                logger.info("{}{}LMH_QMI.06 : LinkMemberDBHelper getMemberParentServices Response ={}", sClassName, sMethodName, hmResult);

                if (hmResult == null || hmResult.isEmpty()) {
                    sAppInfo = "Response from  getMemberParentServices is either null or empty";
                    logger.info("{}{} LMH_QMI.07 : {}", sClassName, sMethodName, sAppInfo);
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, sAppInfo);
                    return hmResult;
                }
                sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                if (!(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode))) {
                    sAppInfo = (String) hmResult.get(CErrorDefs.COMMON_APP_INFO);
                    logger.info("{}{} LMH_QMI.08 :  {}", sClassName, sMethodName, sAppInfo);
                    hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(sAppStatusCode), sAppInfo);
                    return hmResult;
                }
            }
            if (hmResult != null) {
                hmDbMember = (HashMap) hmResult.get(MPSDefs.MEM_PARENT_INFO_MEMBER_KEY);
                hmDbParentData = (HashMap) hmResult.get(MPSDefs.MEM_PARENT_INFO_PARENT_KEY);
                if (hmDbMember == null) {
                    hmDbMember = hmDbParentData;
                }
            }
            if (hmDbMember == null || hmDbMember.isEmpty()) {
                sAppInfo = "hmDbMember Response from  getMemberParentServices is either null or empty";
                logger.info("{}{} LMH_QMI.11 : {}", sClassName, sMethodName, sAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
                return hmResult;
            }
        } catch (Exception e) {
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
            sAppInfo = "Exception thrown from queryMemberInfo method : " + hmResult;
            logger.error("{}{} LMH_QMI.20: {}", sClassName, sMethodName, sAppInfo);
        }
        return hmResult;
    }

    /**
     * Validates SLID (Subscriber Line ID) information using the provided input maps.
     * Performs checks and validation logic on member database info and additional parameters.
     * Returns a map containing the validation result and any relevant status or error information.
     *
     * @param hmInput        input parameters for SLID validation
     * @param hmMemberDbInfo member database information map
     * @param hmParams       additional parameters for validation
     * @return Map containing validation results and status
     */
    private Map<String, Object> handleSlidInfoValidation(Map<String, Object> hmInput, HashMap hmMemberDbInfo, HashMap hmParams) {
        String sMethodName = ".handleSlidInfoValidation.";
        String stAppInfo;
        Map<String, Object> hmResult = null;

        String sAccountType = (String) hmParams.get(ProfileOrchestrationConstants.ACCOUNT_TYPE);
        String sAccountSubType = (String) hmParams.get(ProfileOrchestrationConstants.ACCOUNT_SUB_TYPE);

        bSlidMatchesMemberId = (boolean) hmParams.get(ProfileOrchestrationConstants.SLID_MATCHES_WITH_MEMBER_ID);
        sCallingSystemId = (String) hmParams.get(CommonDefs.CALLING_SYSTEM_ID);
        sOrigTransactionName = (String) hmParams.get(CommonDefs.ORIG_TRANSACTION_NAME);

        logger.info("{}{} LMH_LM.102.08 :calling querySlidInfo with input params : {}", sClassName, sMethodName, hmInput);
        hmDBSlidInfo = querySlidInfo(hmInput);
        logger.info("{}{} LMH_LM.102.09 :Response from querySlidInfo: {}", sClassName, sMethodName, hmDBSlidInfo);

        String sAppStatusMsg = (String) hmDBSlidInfo.get(CommonDefs.COMMON_APP_STATUS_MSG);
        String sAppStatusCode = (String) hmDBSlidInfo.get(CommonDefs.COMMON_APP_STATUS_CODE);

        if (!sAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {

            if (!bSlidMatchesMemberId && sAppStatusMsg.equals(MPSDefs.REC_NOT_FOUND_MSG)) {
                stAppInfo = "Input AccessId is Not found in DB";
                logger.info("{}{} LMH_LM.102.09.00 : {}", sClassName, ProfileOrchestrationConstants.LINK_MEMBER_METHOD, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
                return hmResult;

            } else if ((bSlidMatchesMemberId) && (sAccountType == null || sAccountType.equals(MPSDefs.DB_CONSUMER))
                    && (!sAppStatusMsg.equals(MPSDefs.REC_NOT_FOUND_MSG))) {

                stAppInfo = "Response returned from querySlidInfo is other than USER_NOT_FOUND and account type=R";
                logger.info("{}{} LMH_LM.102.09.01 : {}", sClassName, ProfileOrchestrationConstants.LINK_MEMBER_METHOD, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
                return hmResult;

            } else if ((bSlidMatchesMemberId) && (sAppStatusMsg.equals(MPSDefs.REC_NOT_FOUND_MSG))) {

                boolean bAutoGenSlid = checkAutoGenSlid(sAccountType, sAccountSubType);
                if (bAutoGenSlid) {
                    hmResult = CommonErrorMap.makeCommonStatusMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success");
                } else {
                    stAppInfo = "Response returned from querySlidInfo is other than USER_NOT_FOUND and account type=B";
                    logger.info("{}{} LMH_LM.102.09.02 : {}", sClassName, ProfileOrchestrationConstants.LINK_MEMBER_METHOD, stAppInfo);
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
                    return hmResult;
                }
            }
        } else {
            if ((bSlidMatchesMemberId) && (sAccountType == null || sAccountType.equals(MPSDefs.DB_CONSUMER))
                    && !(sCallingSystemId.equals("DATAMGT") &&
                    sOrigTransactionName.equals(ProfileOrchestrationConstants.LINK_MEMBER_TRANSACTION_NAME))) {

                stAppInfo = "Input AccessId is already exists in DB";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                logger.info("{}{} LMH_LM.102.09.03 : {}", sClassName, ProfileOrchestrationConstants.LINK_MEMBER_METHOD, stAppInfo);
                return hmResult;
            }
        }

      /*      //commeting the bSlidMatchesMemberId code due to password cutover to haloc
      if (!bSlidMatchesMemberId) {
            //call below method to compare MID and slid passwords
            bPasswordsMatched = comparePasswords((HashMap<String, Object>) hmInput);
            logger.info("{}{} LMH_LM.102.09.01 :MID and SLID bPasswordsMatched is: {}", sClassName, ProfileOrchestrationConstants.LINK_MEMBER_METHOD,
                    ESAPI.encoder().encodeForHTML(String.valueOf(bPasswordsMatched)));
        }*/
        if (bSlidMatchesMemberId && sAppStatusMsg.equals(MPSDefs.REC_NOT_FOUND_MSG) &&
                !(sCallingSystemId.equals("DATAMGT") && sOrigTransactionName.equals(ProfileOrchestrationConstants.LINK_MEMBER_TRANSACTION_NAME))) {

            logger.info("{}{} LMH_LM.102.10 :calling preCreateSlid with input params : {}{}", sClassName, ProfileOrchestrationConstants.LINK_MEMBER_METHOD, hmInput, hmMemberDbInfo);
            hmResult = preCreateSlid(hmInput, hmMemberDbInfo);
            logger.info("{}{} LMH_LM.102.11 :Response from preCreateSlid : {}", sClassName, ProfileOrchestrationConstants.LINK_MEMBER_METHOD, hmResult);

            if (hmResult == null || hmResult.isEmpty()) {
                stAppInfo = "Null response returned from preCreateSlid";
                logger.info("{}{} LMH_LM.102.12 : {}", sClassName, ProfileOrchestrationConstants.LINK_MEMBER_METHOD, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                return hmResult;
            }
            sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
            if (!(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode))) {
                stAppInfo = hmResult.get(CErrorDefs.COMMON_APP_INFO).toString();
                logger.info("{}{} LMH_LM.102.13 : {}", sClassName, ProfileOrchestrationConstants.LINK_MEMBER_METHOD, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                return hmResult;
            }
        } else if (bSlidMatchesMemberId && sAppStatusMsg.equals(MPSDefs.REC_NOT_FOUND_MSG) &&
                (sCallingSystemId.equals("DATAMGT"))) {
            stAppInfo = "SLID cannot be created with the calling system DATAMGT";
            logger.info("{}{} LMH_LM.102.13.1 : {}", sClassName, ProfileOrchestrationConstants.LINK_MEMBER_METHOD, stAppInfo);
            return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
        } else {
            updateMemberAttributesWithSlidValues(hmInput, hmMemberDbInfo, hmDBSlidInfo);
        }
        if (hmResult == null || hmResult.isEmpty()) {
            hmResult = hmDBSlidInfo;
        }
        return hmResult;
    }

    /**
     * Queries SLID (Subscriber Line ID) information based on the provided input map.
     * The input map should contain necessary keys to identify and retrieve SLID details.
     * Returns a HashMap containing the queried SLID information and related attributes.
     *
     * @param hmInput a map of input parameters required for querying SLID info
     * @return HashMap containing the queried SLID information and related attributes
     */
    private HashMap<String, Object> querySlidInfo(Map<String, Object> hmInput) {
        String sMethodName = ".querySlidInfo.";
        String stAppInfo = null;
        HashMap<String, Object> hmResult = null;

        HashMap<String, Object> hmSlidInput = new HashMap<>();
        hmSlidInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
        hmSlidInput.put(CommonDefs.SLID, hmInput.get(CommonDefs.ACCESS_ID));
        hmSlidInput.put(CommonDefs.MEMBERID, hmInput.get(CommonDefs.MEMBERID));
        hmSlidInput.put(CommonDefs.DOMAIN, CommonDefs.SLID_DUM);

        ArrayList alSlidMasks = CommonUtil.getArrayList();
        alSlidMasks.add(CommonDefs.MASK_SS);
        alSlidMasks.add(CommonDefs.MASK_SR);
        alSlidMasks.add(CommonDefs.MASK_SQ);
        alSlidMasks.add("SLO");
        alSlidMasks.add(CommonDefs.MASK_AS);
        if (isMIDUversePrimary) {
            alSlidMasks.add(CommonDefs.MASK_LU);
            alSlidMasks.add(CommonDefs.MASK_LS);
            hmSlidInput.put(MPSDefs.QUERY_LINKED_USERS_FLAG, "LSPrimary");
        }
        hmSlidInput.put(MPSDefs.QUERY_FRAUD_LOCK_FLAG, MPSDefs.YES);
        hmSlidInput.put(CommonDefs.SLID_MASK, alSlidMasks);
        logger.info("{}{} LMH_QSI.01 :Input to getSlidInfo =  with inputHash : {}", sClassName, sMethodName, StructuredArguments.entries(hmSlidInput));
        hmResult = oGetSlidInfoDBHelper.getSlidInfo(hmSlidInput);
        logger.info("{}{} LMH_QSI.02 :Response from getSlidInfo  : {}", sClassName, sMethodName, StringUtils.normalizeSpace(hmResult != null ? hmResult.toString() : null));

        if (hmResult == null || hmResult.isEmpty()) {
            stAppInfo = "Response from getSlidInfo() is NULL or EMPTY";
            logger.info("{}{} LMH_QSI.03 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(stAppInfo));
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
            return hmResult;
        }
        String sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
        if (!(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode))) {
            if (CErrorDefs.ERR_REC_NOT_FOUND.equals(sAppStatusCode)) {
                stAppInfo = "Input AccessId is Not found in DB";
                logger.info("{}{} LMH_QSI.04 : {}", sClassName, sMethodName, stAppInfo);
                return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo);
            } else {
                stAppInfo = "Error Response from querySlidInfo()";
                logger.info("{}{} LMH_QSI.05 : {}", sClassName, sMethodName, stAppInfo);
                return CommonErrorMap.makeCategoryMap(Integer.parseInt(sAppStatusCode), stAppInfo);
            }
        }
        return hmResult;
    }

    /**
     * Prepares and creates a SLID (Subscriber Line ID) if required, based on input and member DB info.
     * Performs necessary validation and setup before SLID creation.
     * Returns a map containing the result, status, and any relevant error information.
     *
     * @param hmInput        input parameters for SLID creation
     * @param hmMemberDbInfo member database information map
     * @return Map containing the result and status of the SLID creation process
     */
    public Map<String, Object> preCreateSlid(Map<String, Object> hmInput, Map<String, Object> hmMemberDbInfo) {

        String sMethodName = ".preCreateSlid.";
        String stAppInfo = null;
        String stAppStatusCode = null;
        String sAutoGenSlidGroupNum = null;
        String sAutoGenSlidMemberNum = null;
        HashMap<String, Object> hmResult = null;

        sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);

        logger.info("{}{} LMH_PCS.01 :calling createSLID with input params : {}", sClassName, sMethodName, hmInput);
        hmResult = createSLID(hmInput, hmMemberDbInfo);
        logger.info("{}{} LMH_PCS.02 :Response from createSLID  : {}", sClassName, sMethodName, StringUtils.normalizeSpace(hmResult != null ? hmResult.toString() : null));

        stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
        if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
            stAppInfo = hmResult.get(CErrorDefs.COMMON_APP_INFO).toString();
            logger.info("{}{} LMH_PCS.03 : {}", sClassName, sMethodName, stAppInfo);
            hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
            return hmResult;
        } else {
            sAutoGenSlidGroupNum = (String) hmResult.get(CommonDefs.GROUP_NUM);
            sAutoGenSlidMemberNum = (String) hmResult.get(CommonDefs.GUID);

            hmMember.put(MPSDefs.DB_MEMBER_NUM, hmDbMember.get(MPSDefs.DB_MEMBER_NUM));
            hmMember.put(MPSDefs.DB_SLID_MEMBER_NUM, sAutoGenSlidMemberNum);

            HashMap<String, Object> hmAddMemberEvents = (HashMap) hmResult.get("dbusInput");

            if (hmAddMemberEvents != null) {
                ArrayList alAddMemberEvents = (ArrayList) hmAddMemberEvents.get("eventsData");
                if (alAddMemberEvents != null && !alAddMemberEvents.isEmpty()) {
                    for (Object alAddMemberEvent : alAddMemberEvents) {
                        HashMap<String, Object> hmEachEvent = (HashMap<String, Object>) alAddMemberEvent;
                        String sEventName = (String) hmEachEvent.get(CommonDefs.EVENTNAME);
                        if (sEventName != null && sEventName.equalsIgnoreCase("AddUser")) {
                            hmEachEvent.put(CommonDefs.EVENTNAME, "iGateAddUserEvent");
                            break;
                        }
                    }
                }
                if (alAddMemberEvents != null)
                    alDbusEvents.addAll(alAddMemberEvents);

                hmMemberDataInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
                hmMemberDataInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
                hmMemberDataInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);

                hmInput.put(MPSDefs.DB_SLID_MEMBER_NUM, sAutoGenSlidMemberNum);
                hmInput.put(MPSDefs.DB_GROUP_NUM, sAutoGenSlidGroupNum);
                buildQuerySlidInfoResponse((HashMap) hmInput, hmDbMember, null);
            }
        }
        return hmResult;
    }

    /**
     * Creates a SLID (Subscriber Line ID) based on the provided input and member database information.
     * Performs necessary operations to generate a new SLID and returns a map containing the result,
     * status, and any relevant error information.
     *
     * @param hmInput     input parameters required for SLID creation
     * @param hmMemDbInfo member database information map
     * @return HashMap containing the result, status, and details of the SLID creation process
     */
    private HashMap<String, Object> createSLID(Map<String, Object> hmInput, Map<String, Object> hmMemDbInfo) {
        String sMethodName = ".createSLID";
        HashMap<String, Object> hmResult = null;
        String stAppInfo = null;
        String sAppStatusCode = null;

        hmMemDbInfo = (HashMap) hmMemDbInfo.getOrDefault(
                MPSDefs.MEM_PARENT_INFO_MEMBER_KEY,
                hmMemDbInfo.get(MPSDefs.MEM_PARENT_INFO_PARENT_KEY));


        logger.info("{}{} LMH_CSLID.01 : Input Hash : {}{}", sClassName, sMethodName,StructuredArguments.entries(hmInput),StructuredArguments.entries(hmMemDbInfo));
        try {

            HashMap<String, Object> hmSLIDInput = CommonUtil.getHashMap();
            hmSLIDInput.put(CommonDefs.ORIG_TRANSACTION_NAME, "LinkMember");
            hmSLIDInput.put(CommonDefs.TRANSACTION_NAME, CommonDefs.ADDMEMBER_GENERIC_TRANSACTION_NAME);

            hmSLIDInput.put(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
            hmSLIDInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.IDPTRACEID));
            hmSLIDInput.put(CommonDefs.ORIG_TRANSID, hmInput.get(ProfileOrchestrationConstants.IDPTRACEID));

            hmSLIDInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
            hmSLIDInput.put(CommonDefs.DOMAIN, CommonDefs.SLID_DUM);

            hmSLIDInput.put(CommonDefs.FIRST_NAME,  hmMemDbInfo.get(MPSDefs.DB_LC_FIRSTNAME) != null
                    ? hmMemDbInfo.get(MPSDefs.DB_LC_FIRSTNAME)
                    : hmMemDbInfo.get(MPSDefs.DB_FIRSTNAME));
            hmSLIDInput.put(CommonDefs.LAST_NAME, hmMemDbInfo.get(MPSDefs.DB_LC_LASTNAME) != null
                    ? hmMemDbInfo.get(MPSDefs.DB_LC_LASTNAME)
                    : hmMemDbInfo.get(MPSDefs.DB_LASTNAME));
            hmSLIDInput.put(CommonDefs.DB_FULLNAME, hmMemDbInfo.get(MPSDefs.DB_FULLNAME));

            hmSLIDInput.put(CommonDefs.PARENT_CHILD_IND, "S");
            hmSLIDInput.put(CommonDefs.SOR, CommonDefs.SOR_NA);
            hmSLIDInput.put(CommonDefs.HANDLE, hmInput.get(CommonDefs.ACCESS_ID));

            hmSLIDInput.put("isMIDInRequest", true);
            hmSLIDInput.put("isTempPassword", "N");
            hmSLIDInput.put(CommonDefs.CALLDBUS, CommonDefs.IND_N);

            if ((hmMemDbInfo.get(MPSDefs.DB_SHA1_PASSWORD) != null) &&
                    (!((String) hmMemDbInfo.get(MPSDefs.DB_SHA1_PASSWORD)).trim().isEmpty()))
                hmSLIDInput.put(MPSDefs.DB_SHA1_PASSWORD, hmMemDbInfo.get(MPSDefs.DB_SHA1_PASSWORD));

            if ((hmMemDbInfo.get(MPSDefs.DB_DES3_PASSWORD) != null) &&
                    (!((String) hmMemDbInfo.get(MPSDefs.DB_DES3_PASSWORD)).trim().isEmpty()))
                hmSLIDInput.put(MPSDefs.DB_DES3_PASSWORD, hmMemDbInfo.get(MPSDefs.DB_DES3_PASSWORD));

            if ((hmMemDbInfo.get(MPSDefs.DB_ENC_PASSWORD) != null) &&
                    (!((String) hmMemDbInfo.get(MPSDefs.DB_ENC_PASSWORD)).trim().isEmpty()))
                hmSLIDInput.put(MPSDefs.DB_ENC_PASSWORD, hmMemDbInfo.get(MPSDefs.DB_ENC_PASSWORD));

            if ((hmMemDbInfo.get(MPSDefs.DB_MD5_PASSWORD) != null) &&
                    (!((String) hmMemDbInfo.get(MPSDefs.DB_MD5_PASSWORD)).trim().isEmpty()))
                hmSLIDInput.put(MPSDefs.DB_MD5_PASSWORD, hmMemDbInfo.get(MPSDefs.DB_MD5_PASSWORD));

            // 2103 - SSHA-256 encryption changes
            if ((hmMemDbInfo.get(MPSDefs.DB_GEN_PASSWORD) != null)
                    && (!((String) hmMemDbInfo.get(MPSDefs.DB_GEN_PASSWORD)).trim().isEmpty())) {
                hmSLIDInput.put(MPSDefs.DB_GEN_PASSWORD, hmMemDbInfo.get(MPSDefs.DB_GEN_PASSWORD));
                hmSLIDInput.put(MPSDefs.DB_GEN_PASSWORD_TYPE, hmMemDbInfo.get(MPSDefs.DB_GEN_PASSWORD_TYPE));
            }

            if ((hmMemDbInfo.get(MPSDefs.DB_SECURITY_QUESTION_1) != null) && (!((String) hmMemDbInfo.get(MPSDefs.DB_SECURITY_QUESTION_1)).trim().isEmpty()))
                hmSLIDInput.put(CommonDefs.ONLINE1_SECURITY_QUESTION, hmMemDbInfo.get(MPSDefs.DB_SECURITY_QUESTION_1));

            if ((hmMemDbInfo.get(MPSDefs.DB_SECURITY_QUESTION_2) != null) && (!((String) hmMemDbInfo.get(MPSDefs.DB_SECURITY_QUESTION_2)).trim().isEmpty()))
                hmSLIDInput.put(CommonDefs.ONLINE2_SECURITY_QUESTION, hmMemDbInfo.get(MPSDefs.DB_SECURITY_QUESTION_2));

            if ((hmMemDbInfo.get(MPSDefs.DB_SECURITY_ANSWER_1) != null) && (!((String) hmMemDbInfo.get(MPSDefs.DB_SECURITY_ANSWER_1)).trim().isEmpty()))
                hmSLIDInput.put(CommonDefs.ONLINE1_SECURITY_ANSWER, hmMemDbInfo.get(MPSDefs.DB_SECURITY_ANSWER_1));

            if ((hmMemDbInfo.get(MPSDefs.DB_SECURITY_ANSWER_2) != null) && (!((String) hmMemDbInfo.get(MPSDefs.DB_SECURITY_ANSWER_2)).trim().isEmpty()))
                hmSLIDInput.put(CommonDefs.ONLINE2_SECURITY_ANSWER, hmMemDbInfo.get(MPSDefs.DB_SECURITY_ANSWER_2));

            if (hmMemDbInfo.get(MPSDefs.DB_ONL_QA_EST_DATE) != null && !((String) hmMemDbInfo.get(MPSDefs.DB_ONL_QA_EST_DATE)).isEmpty())
                hmSLIDInput.put(MPSDefs.DB_ONL_QA_EST_DATE, hmMemDbInfo.get(MPSDefs.DB_ONL_QA_EST_DATE));

            if ((hmMemDbInfo.get(MPSDefs.DB_BROWSER_LANGUAGE) != null) && (!((String) hmMemDbInfo.get(MPSDefs.DB_BROWSER_LANGUAGE)).trim().isEmpty()))
                hmSLIDInput.put(CommonDefs.BROWSER_LANGUAGE, hmMemDbInfo.get(MPSDefs.DB_BROWSER_LANGUAGE));

            if (hmMemDbInfo.get(MPSDefs.DB_PASSWORD_DIRTY) != null && !((String) hmMemDbInfo.get(MPSDefs.DB_PASSWORD_DIRTY)).trim().isEmpty())
                hmSLIDInput.put("passwordDirtyInd", hmMemDbInfo.get(MPSDefs.DB_PASSWORD_DIRTY));

            if ((hmMemDbInfo.get(MPSDefs.DB_GENDER) != null) && (!((String) hmMemDbInfo.get(MPSDefs.DB_GENDER)).trim().isEmpty()))
                hmSLIDInput.put(CommonDefs.GENDER, hmMemDbInfo.get(MPSDefs.DB_GENDER));

            if (hmMemDbInfo.get(MPSDefs.DB_CONTACT_EMAIL_EST_DATE) != null && !((String) hmMemDbInfo.get(MPSDefs.DB_CONTACT_EMAIL_EST_DATE)).trim().isEmpty())
                hmSLIDInput.put(MPSDefs.DB_CONTACT_EMAIL_EST_DATE, hmMemDbInfo.get(MPSDefs.DB_CONTACT_EMAIL_EST_DATE));


            //Below is for ATLAS
            if (hmInput.containsKey(CommonDefs.IS_ACCESSS_ID_AUTOGEN)) {
                String sAutogeneratedInd = (String) hmInput.get(CommonDefs.IS_ACCESSS_ID_AUTOGEN);

                if (sAutogeneratedInd != null && !sAutogeneratedInd.trim().isEmpty() && sAutogeneratedInd.equals(CommonDefs.IND_Y)) {
                    hmSLIDInput.put(CommonDefs.IS_ACCESSS_ID_AUTOGEN, CommonDefs.IND_Y);
                    hmSLIDInput.put(CommonDefs.ACTIVATED_INDEX, CommonDefs.IND_Y);
                    hmSLIDInput.put("passwordDirtyInd", CommonDefs.IND_Y);
                }
            }

            //below is for LSReg
            ArrayList alContactEmailNotAllowedForAutoGenSlid = CommonUtil.parseToArray(propContactEmailNotAllowedForAutoGenSlid, CommonDefs.VALUE_SEPARATOR_CHAR);
            logger.info("{}{} LMH_CSLID.02 : Property propContactEmailNotAllowedForAutoGenSlid : {}", sClassName, sMethodName, alContactEmailNotAllowedForAutoGenSlid);

            String sContactEmail = null;
            String sContactEmailStatus = null;

            if (hmInput.containsKey(ProfileOrchestrationConstants.ADDITIONAL_SLID_DATA)) {
                HashMap hmAdditionalSlidData = (HashMap) hmInput.get(ProfileOrchestrationConstants.ADDITIONAL_SLID_DATA);

                if (hmAdditionalSlidData != null) {
                    sContactEmail = (String) hmAdditionalSlidData.get(CommonDefs.CONTACT_EMAIL);
                    if (hmAdditionalSlidData.containsKey(CommonDefs.CONTACT_EMAIL_STATUS) && hmAdditionalSlidData.get(CommonDefs.CONTACT_EMAIL_STATUS) != null) {
                        sContactEmailStatus = (String) hmAdditionalSlidData.get(CommonDefs.CONTACT_EMAIL_STATUS);
                    }
                }
            } else if (hmMemDbInfo.get(MPSDefs.DB_CONTACT_EMAIL) != null) {
                sContactEmail = (String) hmMemDbInfo.get(MPSDefs.DB_CONTACT_EMAIL);
                if (hmMemDbInfo.containsKey(MPSDefs.DB_CONTACT_EMAIL_STATUS) && hmMemDbInfo.get(MPSDefs.DB_CONTACT_EMAIL_STATUS) != null) {
                    sContactEmailStatus = (String) hmMemDbInfo.get(MPSDefs.DB_CONTACT_EMAIL_STATUS);
                }
            }
            hmSLIDInput.put(CommonDefs.EMAIL_ADDRESS, sContactEmail);
            hmSLIDInput.put(CommonDefs.EMAIL_STATUS, sContactEmailStatus);

            //since SuggestHandle should been called when LS Primary was created, so no need to call for slid.
            hmSLIDInput.put("bypassSuggestHandleHelper", CommonDefs.IND_Y);
            hmSLIDInput.put("byPassProofingEncryption", CommonDefs.IND_Y);

            // CG call to fetch email address, email status and email establish date
            String sParentChildInd = null;
            HashMap hmCGResponse = null;
            HashMap hmAcctProfResponse = null;
            String sCGEmailAddress = null;

            sParentChildInd = (String) hmMemDbInfo.get(MPSDefs.DB_PARENT_CHILD_IND);
            String sSorName = (String) hmMemDbInfo.get(MPSDefs.DB_SOR_NAME);
            String sMemberState = (String) hmMemDbInfo.get(MPSDefs.DB_MEMBER_STATE);
            String sDbBan = (String) hmMemDbInfo.get(CommonDefs.BAN);

            if (sParentChildInd != null && sSorName != null && sMemberState != null &&
                    sParentChildInd.equalsIgnoreCase(MPSDefs.MPS_PARENT) && sSorName.equalsIgnoreCase(MPSDefs.SOR_LS) &&
                    !sMemberState.equalsIgnoreCase(MPSDefs.INACT_STATE) && sDbBan != null && !sDbBan.trim().isEmpty()) {

                HashMap<String, Object> hmCGInput = new HashMap();
                hmCGInput.put(CommonDefs.TRANSACTION_NAME, "CgRestClient");
                hmCGInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
                hmCGInput.put(CommonDefs.ACCOUNT_ID, hmMemDbInfo.get(CommonDefs.BAN));
                hmCGInput.put(CommonDefs.SERVICE_TYPE, "uverse");
                hmCGInput.put("topics", "accounts," + "subscribers");
                hmCGInput.put(CommonConstants.CG_API_NAME, CommonConstants.CG_CUSTOMER_SEARCH_API_NAME);
                hmCGInput.put(CommonConstants.CG_END_POINT, cgEndpoint);
                hmCGInput.put(CommonConstants.CG_SERVER_URL, cgServerUrl);

                logger.info("{}{} LMH_CSLID.03 : Calling CGRestClient.getCGSyncCall with input:{}", sClassName, sMethodName, hmCGInput);
                hmCGResponse = (HashMap) cgRestClient.getCGSyncCall(hmCGInput);
                logger.info("{}{} LMH_CSLID.04 :Response CGRestClient.getCGSyncCall : {}", sClassName, sMethodName, hmCGResponse);

                if (hmCGResponse == null || hmCGResponse.isEmpty()) {
                    stAppInfo = "getCGSyncCall returned null / empty response";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                    logger.info("{}{} LMH_CSLID.05: {} ", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                }
                sAppStatusCode = (String) hmCGResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                stAppInfo = (String) hmCGResponse.get(CErrorDefs.COMMON_APP_INFO);

                if (sAppStatusCode != null && !CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode)) {
                    if (sAppStatusCode.equals(CErrorDefs.ERR_INVALID_DATA) && stAppInfo.contains("Data Error")) {
                        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ACCOUNT_NOT_FOUND_NUM, stAppInfo);
                    }
                    logger.info("{}{} LMH_CSLID.06 : ban/account not found in CG: {} ", sClassName, sMethodName, stAppInfo);
                    return hmResult;
                } else {
                    hmAcctProfResponse = CommonUtil.getMap(hmCGResponse, CommonDefs.ACCOUNTS);

                    if (hmAcctProfResponse != null && !hmAcctProfResponse.isEmpty()) {
                        String sEmailStatus = (String) hmAcctProfResponse.get("emailStatus");

                        if (sEmailStatus != null && !sEmailStatus.isEmpty())
                            hmSLIDInput.put(CommonDefs.CONTACT_EMAIL_VALID, sEmailStatus);
                        String sEmailEstablishDate = (String) hmAcctProfResponse.get("emailEstablishDate");

                        if (sEmailEstablishDate != null && !sEmailEstablishDate.trim().isEmpty())
                            sEmailEstablishDate = formatDate(CommonDefs.TIME_MODIFIED, sEmailEstablishDate);
                        hmSLIDInput.put(MPSDefs.DB_CONTACT_EMAIL_EST_DATE, sEmailEstablishDate);

                        HashMap<String, Object> hmContact = CommonUtil.getMap(hmAcctProfResponse, "contact");
                        if (hmContact != null && !hmContact.isEmpty()) {
                            HashMap<String, Object> hmEmail = CommonUtil.getMap(hmContact, CommonDefs.EMAIL);
                            if (hmEmail != null && !hmEmail.isEmpty()) {
                                sCGEmailAddress = (String) hmEmail.get(CommonDefs.EMAIL_ADDRESS);
                                if (sCGEmailAddress != null && !sCGEmailAddress.isEmpty()) {
                                    sCGEmailAddress = sCGEmailAddress.trim().toLowerCase();
                                    hmSLIDInput.put(CommonDefs.CONTACT_EMAIL, sCGEmailAddress);
                                }
                            }
                        }
                    }
                }

            }
            //CG call ends
            if (sCallingSystemId != null && sCallingSystemId.equals(ProfileOrchestrationConstants.DATA_MGMT)) {
                hmSLIDInput.put(CommonDefs.TOS_FLAG, CommonDefs.IND_Y);
            }
            logger.info("{}{} LMH_CSLID.07 :Input to AddUserHelper.addUser =  with inputHash : {}", sClassName, sMethodName,StructuredArguments.entries(hmSLIDInput));
            hmResult = (HashMap<String, Object>) oAddUserHelper.addUser(hmSLIDInput);
            logger.info("{}{} LMH_CSLID.08 :Response from AddUserHelper.addUser  : {}", sClassName, sMethodName,StringUtils.normalizeSpace(hmResult != null ? hmResult.toString() : null));

            if (hmResult == null || hmResult.isEmpty()) {
                stAppInfo = "Response from AddUserHelper.addUser() is NULL or EMPTY";
                logger.info("{}{} LMH_CSLID.09 : {}", sClassName, sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                return hmResult;
            }
            sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
            if (!(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode))) {
                stAppInfo = "Error from AddUserHelper.addUser(): " + hmResult.get(CErrorDefs.COMMON_APP_INFO);
                logger.info("{}{} LMH_CSLID.10 : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }
        } catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e, logger);
            stAppInfo = "Exception thrown from Create SLID method : " + hmResult;
            logger.error("{}{} LMH_CSLID.11 {}", sClassName, sMethodName, stAppInfo);
        }
        return hmResult;
    }

    public Map<String, Object> callAddAssociation(Map<String, Object> hmAddAccountReq, String sSvcType, String sSuppressNotification) throws IOException {
        String sMethodName = ".callAddAssociation.";
        String sAppInfo = null;
        String stAppStatusCode = null;
        Map<String, Object> hmAddAssocInp = new HashMap<String, Object>();
        Map<String, Object> hmInputSvc = new HashMap<String, Object>();
        Map<String, Object> hmAcctTypeAttr = new HashMap();
        Map<String, Object> hmAcctSubTypeAttr = new HashMap();

        hmAddAssocInp.put(CommonDefs.TRANSACTION_NAME, "AddAssociation");
        hmAddAssocInp.put(CommonDefs.TRANSACTION_ID, sTransactionId);
        hmAddAssocInp.put(CommonDefs.CALLING_SYSTEM_ID, hmAddAccountReq.get(CommonDefs.CALLING_SYSTEM_ID));
        hmAddAssocInp.put(CommonDefs.GUID, hmAddAccountReq.get(CommonDefs.GUID));
        hmAddAssocInp.put("isExternalCall", "N");
        //hmAddAssocInp.put(CommonDefs.ORIG_TRANSACTION_NAME, sOrigTransactionName); // need to handle this for datamgt , throwing an error.
        // hmAddAssocInp.put("slidInfo", hmDbSlid);
        ArrayList alAssociations = new ArrayList();
        switch (sSvcType) {
            case "MOBILITY":
                hmInputSvc.put(CommonDefs.SERVICE_NAME, sSvcType);
                hmInputSvc.put(CommonDefs.SERVICE_STATUS, "Enabled");
                hmInputSvc.put(CommonDefs.KEY_SOR_NAME, "MO");

                hmInputSvc.put(CommonDefs.SOR_INVARIANT_ID, hmAddAccountReq.get(CommonDefs.SOR_INVARIANT_ID));
                hmInputSvc.put(CommonDefs.INSTANCE_ID, hmAddAccountReq.get(CommonDefs.SOR_INVARIANT_ID));
                hmInputSvc.put("nickName", ProfileOrchestrationConstants.LINK_MEMBER_TRANSACTION_NAME);

                hmInputSvc.put(CommonDefs.ROLE_NAME, "OWNER");
                hmInputSvc.put(CommonDefs.ROLE_STATUS, "Enabled");
                String sMobilityAcctType = (String) hmAddAccountReq.get("MOBILITY_ACCOUNT_TYPE");
                String sMobilityAcctSubType = (String) hmAddAccountReq.get("MOBILITY_ACCOUNT_SUBTYPE");

                ArrayList alInpAttributes = CommonUtil.getArrayList();
                if (sMobilityAcctType != null && !sMobilityAcctType.isEmpty()) {
                    hmAcctTypeAttr.put("attributeName", "MOBILITY_ACCOUNT_TYPE");
                    hmAcctTypeAttr.put("attributeValue", sMobilityAcctType);
                    alInpAttributes.add(hmAcctTypeAttr);
                }
                if (sMobilityAcctSubType != null && !sMobilityAcctSubType.isEmpty()) {
                    hmAcctSubTypeAttr.put("attributeName", "MOBILITY_ACCOUNT_SUBTYPE");
                    hmAcctSubTypeAttr.put("attributeValue", sMobilityAcctSubType);
                    alInpAttributes.add(hmAcctSubTypeAttr);
                }
                if (!alInpAttributes.isEmpty()) {
                    hmInputSvc.put("attributeList", alInpAttributes);
                }
                alAssociations.add(hmInputSvc);
                hmAddAssocInp.put("associationList", alAssociations);
                break;
            case "MOSUB":
                hmInputSvc.put(CommonDefs.SOR_INVARIANT_ID, hmAddAccountReq.get("mosubSubId"));
                hmInputSvc.put(CommonDefs.INSTANCE_ID, hmAddAccountReq.get("mosubCTN"));
                alAssociations.add(hmInputSvc);
                hmAddAssocInp.put("associationList", alAssociations);
                break;
            default:
        }

        if (sSuppressNotification != null && !sSuppressNotification.isEmpty()) {
            hmAddAssocInp.put("suppressNotification", sSuppressNotification);
        }
        logger.debug("{}{} LMH_CAA.01 : Calling MPSYSInternalRestClient.callIDPRestClient() AddAssociation endpoint : {}", sClassName, sMethodName, hmAddAssocInp);
        Map<String, Object> hmResponse = oInternalIDPRestClient.callIDPRestClient(hmAddAssocInp);
        logger.debug("{}{} LMH_CAA.02 : Response from MPSYSInternalRestClient.callIDPRestClient() AddAssociation endpoint: {}", sClassName, sMethodName, hmResponse);

        // Check if the response is empty
        if (hmResponse==null || hmResponse.isEmpty()) {
            sAppInfo = "Null Response returned from MPSYSInternalRestClient.callIDPRestClient()";
            hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
            logger.info("{}{} LMH_CAA.03 : {}", sClassName, sMethodName, sAppInfo);
            return hmResponse;
        }
        sAppInfo = (String) hmResponse.get(CErrorDefs.COMMON_APP_INFO);
        stAppStatusCode = (String) hmResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);

        if (stAppStatusCode != null && !CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
            sAppInfo = "Error from MPSYSInternalRestClient.callIDPRestClient() AddAssociation endpoint: " + sAppInfo;
            logger.info("{}{} LMH_CAA.03 : {}", sClassName, sMethodName, sAppInfo);
            return CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), sAppInfo);
        }

        hmResponse.put(CommonDefs.ORIG_TRANSACTION_NAME, sOrigTransactionName);
        hmResponse.put(CommonDefs.ORIG_TRANSID, sTransactionId);

        return hmResponse;
    }

    /**
     * Calls AddAssociationHelper to build TITAN add-association data in-process.
     *
     * @param hmAddAccountReq add-association input map
     * @param hmDbSlid SLID DB info map
     * @return response map containing status and TITAN association payload/data
     */
    private Map<String, Object> callTitanAddAssociation(Map<String, Object> hmAddAccountReq, HashMap hmDbSlid) {
        HashMap<String, Object> hmRequest = CommonUtil.getHashMap();
        hmRequest.putAll(hmAddAccountReq);
        hmRequest.put(CommonDefs.TRANSACTION_NAME, "AddAssociation");
        hmRequest.put(ProfileOrchestrationConstants.IDPTRACEID, sTransactionId);
        hmRequest.put(CommonDefs.ORIG_TRANSACTION_NAME, sOrigTransactionName);
        hmRequest.put(CommonDefs.CALLDBUS, CommonDefs.IND_N);
        hmRequest.put("isExternalCall", CommonDefs.IND_N);

        Object accountListObj = hmAddAccountReq.get(CommonDefs.ACCOUNT_LIST);
        if (accountListObj instanceof List<?> rawAccountList) {
            hmRequest.put("associationList", List.copyOf((List<Map<String, Object>>) rawAccountList));
            ArrayList<HashMap<String, Object>> alServices = CommonUtil.getArrayList();
            for (Object item : rawAccountList) {
                if (item instanceof Map<?, ?> rawMap) {
                    alServices.add(new HashMap<>((Map<String, Object>) rawMap));
                }
            }
            hmRequest.put(CommonDefs.SERVICE, alServices);
        }
        if (hmDbSlid != null && hmDbSlid.get(MPSDefs.DB_MEMBER_NUM) != null) {
            hmRequest.put(CommonDefs.GUID, hmDbSlid.get(MPSDefs.DB_MEMBER_NUM));
        }

        return addAssociationHelper.addAssociation(hmRequest);
    }

    /**
     * Applies TITAN association response data to updateMemberData input and dbus event list.
     *
     * @param hmAddAssocResp TITAN association response map
     * @param hmMemberDataInput updateMemberData input map to populate
     * @param alDbusEvents dbus event list to append consolidated events
     * @param hmDbSlid SLID DB info map used to populate WS add-service metadata
     */
    private void applyTitanAssociationResponse(Map<String, Object> hmAddAssocResp, HashMap<String, Object> hmMemberDataInput, ArrayList alDbusEvents, HashMap hmDbSlid) {
        if (hmAddAssocResp.containsKey(CommonDefs.CONSOLIDATED_DBUS_INPUT) && hmAddAssocResp.get(CommonDefs.CONSOLIDATED_DBUS_INPUT) != null) {
            alDbusEvents.addAll((ArrayList) hmAddAssocResp.get(CommonDefs.CONSOLIDATED_DBUS_INPUT));
        }

        if (hmAddAssocResp.containsKey(MPSDefs.WS_ADD_SERVICES) && hmAddAssocResp.get(MPSDefs.WS_ADD_SERVICES) != null) {
            hmMemberDataInput.put(MPSDefs.WS_ADD_SERVICES, hmAddAssocResp.get(MPSDefs.WS_ADD_SERVICES));
        }
        if (hmAddAssocResp.containsKey(MPSDefs.DB_MEMBER_SERVICE_ROLES) && hmAddAssocResp.get(MPSDefs.DB_MEMBER_SERVICE_ROLES) != null) {
            hmMemberDataInput.put(MPSDefs.DB_MEMBER_SERVICE_ROLES, hmAddAssocResp.get(MPSDefs.DB_MEMBER_SERVICE_ROLES));
            return;
        }

        HashMap hmAddAcctMPSData = (HashMap) hmAddAssocResp.get("AddAssociation");
        if (hmAddAcctMPSData == null) {
            return;
        }

        ArrayList<Map<String, Object>> alAddAccountList = (ArrayList) hmAddAcctMPSData.get(CommonDefs.ACCOUNT_LIST);
        if (alAddAccountList == null || alAddAccountList.isEmpty()) {
            return;
        }
        HashMap hmTitanAccount = (HashMap) alAddAccountList.get(0);
        ArrayList alMemberServices = (ArrayList) hmTitanAccount.get(CommonDefs.KEY_MEMBER_SERVICES);
        ArrayList alServiceRoles = (ArrayList) hmTitanAccount.get(CommonDefs.KEY_SERVICE_ROLES);

        HashMap hmAddServices = CommonUtil.getHashMap();
        if (alMemberServices != null && !alMemberServices.isEmpty()) {
            String sMembernum = null;
            for (int i = 0; i < alMemberServices.size(); i++) {
                HashMap hmEachAccount = (HashMap) alMemberServices.get(i);
                String sOperation = (String) hmEachAccount.get(MPSDefs.DB_OPERATION);
                if (sOperation != null && sOperation.equals(MPSDefs.DB_OPERATION_INSERT)) {
                    hmEachAccount.put("wsServiceName", hmEachAccount.get("serviceType"));
                    sMembernum = (String) hmEachAccount.get("member_num");
                    hmEachAccount.put("wsMemberNum", hmEachAccount.get("member_num"));
                    hmEachAccount.put("wsCallingSystemId", sCallingSystemId);
                    hmEachAccount.put("wsServiceId", hmEachAccount.get("instance_id"));
                    hmEachAccount.put("wsSorInvariantId", hmEachAccount.get("sorInvariantId"));
                    hmEachAccount.put("wsSorName", hmEachAccount.get("sorName"));
                    hmEachAccount.put("wsMemberStatusName", hmEachAccount.get("serviceStatus"));
                }
            }
            hmAddServices.put(MPSDefs.WS_SERVICES, alMemberServices);
            hmAddServices.put(MPSDefs.WS_CALLING_SYSTEM_ID, sCallingSystemId);
            hmAddServices.put(MPSDefs.WS_GROUP_NUM, hmDbSlid.get(MPSDefs.DB_GROUP_NUM));
            hmAddServices.put(MPSDefs.WS_MEMBER_NUM, sMembernum);
            hmMemberDataInput.put(MPSDefs.WS_ADD_SERVICES, hmAddServices);
        }
        if (alServiceRoles != null) {
            hmMemberDataInput.put(MPSDefs.DB_MEMBER_SERVICE_ROLES, alServiceRoles);
        }
    }

    /**
     * Checks if the SLID (Subscriber Line ID) matches the Member ID based on the provided input map.
     * Evaluates the input parameters to determine if the SLID and Member ID are considered equivalent.
     *
     * @param hmInput a map containing input parameters for the check
     * @return true if SLID matches Member ID, false otherwise
     */
    private boolean checkSlidMatchesMemberId(@NotNull Map<String, Object> hmInput) {
        String sMethodName = ".checkSlidMatchesMemberId.";

        String sSlid = (String) hmInput.get(CommonDefs.ACCESS_ID);
        String sMemberId = (String) hmInput.get(CommonDefs.MEMBERID);
        String sDomain = (String) hmInput.get(CommonDefs.DOMAIN);

        String sSlidMemberId = null;
        String sSlidDomain = null;

        if (sMemberId != null && sDomain != null) {
            String sHandle = sMemberId + "@" + sDomain;
            hmInput.put(CommonDefs.HANDLE, sHandle);
        }
        if (sSlid != null && sSlid.contains("@")) {
            sSlidMemberId = sSlid.substring(0, sSlid.indexOf("@"));
            sSlidDomain = sSlid.substring(sSlid.indexOf("@") + 1);
        }
        logger.info(
                "{}{} LMH_LM.101.02 :calling oDomainValidation.getDomainId with input params sSlidDomain : {} , sSlidMemberId : {}, sSlid : {}",
                sClassName,
                sMethodName,
                ESAPI.encoder().encodeForHTML(sSlidDomain),
                ESAPI.encoder().encodeForHTML(sSlidMemberId),
                ESAPI.encoder().encodeForHTML(sSlid));
        String sDomainId = null;
        try {
            sDomainId = oDomainValidation.getDomainId(sSlidDomain);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        logger.info("{}{} LMH_LM.101.03 :Response from oDomainValidation.getDomainId: {}", sClassName, sMethodName, sDomainId);
        return StringUtils.isNotBlank(sDomainId) && sMemberId != null && sMemberId.equals(sSlidMemberId) && sDomain != null && sDomain.equals(sSlidDomain);
    }

    /**
     * Updates member attributes with values from SLID (Subscriber Line ID) information.
     * Merges relevant SLID data into the member info map based on the provided input.
     * Returns a map containing the updated member attributes.
     *
     * @param hmInput      input parameters for the update process
     * @param hmMemberDbInfo member information map to be updated
     * @param hmDBSlidInfo SLID information map containing values to merge
     * @return Map with updated member attributes
     */
    public Map updateMemberAttributesWithSlidValues(Map<String, Object> hmInput, Map<String, Object> hmMemberDbInfo, Map<String, Object> hmDBSlidInfo) {
        String sThisMethod = ".updateMemberAttributesWithSlidValues.";

        String sParentChildInd = null;
        String sSorName = null;
        String sMemberNum = null;

        if (hmMemberDbInfo != null) {
            sParentChildInd = (String) hmMemberDbInfo.get(MPSDefs.DB_PARENT_CHILD_IND);
            sSorName = (String) hmMemberDbInfo.get(MPSDefs.DB_SOR_NAME);
            hmMemberDataInput.put(CommonDefs.HANDLE, hmMemberDbInfo.get(MPSDefs.DB_MEMBER_NAME));
            hmMemberDataInput.put(CommonDefs.DOMAIN, hmMemberDbInfo.get(MPSDefs.DB_DOMAIN_NAME));
            hmMemberDataInput.put(MPSDefs.DB_MEMBER_NUM, hmMemberDbInfo.get(MPSDefs.DB_MEMBER_NUM));
        }
        //get slid values
        HashMap<String, Object> hmDbSlid = (HashMap<String, Object>) hmDBSlidInfo.getOrDefault(CommonDefs.KEY_SLID_INFO, hmDBSlidInfo);
        // build request to update .net member attributes with input SLID values
        hmMemberDataInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
        hmMemberDataInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
        hmMemberDataInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);

        String sIgnoreProfileUpdate = (String) hmInput.get(CommonDefs.IGNORE_PROFILE_UPDATE);

        if ((sIgnoreProfileUpdate == null) || sIgnoreProfileUpdate.equalsIgnoreCase(CommonDefs.IND_N)) {
            //commeting the slid password updating to memberid code due to password cutover to haloc
            /*if (!bPasswordsMatched) {
                hmMember.put(MPSDefs.DB_SHA1_PASSWORD, hmDbSlid.get(MPSDefs.DB_SHA1_PASSWORD));
                hmMember.put(MPSDefs.DB_DES3_PASSWORD, hmDbSlid.get(MPSDefs.DB_DES3_PASSWORD));
                hmMember.put(MPSDefs.DB_ENC_PASSWORD, hmDbSlid.get(MPSDefs.DB_ENC_PASSWORD));
                hmMember.put(MPSDefs.DB_MD5_PASSWORD, hmDbSlid.get(MPSDefs.DB_MD5_PASSWORD));
                //2103 - SSHA-256 encryption changes
                if (hmDbSlid.get(MPSDefs.DB_GEN_PASSWORD) != null
                        && !((String) hmDbSlid.get(MPSDefs.DB_GEN_PASSWORD)).isEmpty()) {
                    hmMember.put(MPSDefs.DB_GEN_PASSWORD, hmDbSlid.get(MPSDefs.DB_GEN_PASSWORD));
                    hmMember.put(MPSDefs.DB_GEN_PASSWORD_TYPE, hmDbSlid.get(MPSDefs.DB_GEN_PASSWORD_TYPE));
                }
            } */
            hmMember.put(MPSDefs.DB_LC_FIRSTNAME, hmDbSlid.get(MPSDefs.DB_LC_FIRSTNAME));
            hmMember.put(MPSDefs.DB_LC_LASTNAME, hmDbSlid.get(MPSDefs.DB_LC_LASTNAME));
            hmMember.put(MPSDefs.DB_FULLNAME, hmDbSlid.get(MPSDefs.DB_FULLNAME));
            hmMember.put(MPSDefs.DB_MEMBER_NUM, hmDbSlid.get(MPSDefs.DB_MEMBER_NUM));

            if (!(sParentChildInd != null && sParentChildInd.equalsIgnoreCase(MPSDefs.MPS_PARENT) && sSorName != null && sSorName.equalsIgnoreCase(MPSDefs.SOR_LS))) {
                hmMember.put(MPSDefs.DB_CONTACT_EMAIL_STATUS, hmDbSlid.get(MPSDefs.DB_CONTACT_EMAIL_STATUS));
                hmMember.put(MPSDefs.DB_CONTACT_EMAIL_EST_DATE, hmDbSlid.get(MPSDefs.DB_CONTACT_EMAIL_EST_DATE));
                hmMember.put(MPSDefs.DB_CONTACT_EMAIL, hmDbSlid.get(MPSDefs.DB_CONTACT_EMAIL));
            }
            hmMember.put(MPSDefs.DB_SECURITY_QUESTION_ID_1, hmDbSlid.get(MPSDefs.DB_SECURITY_QUESTION_ID_1));
            hmMember.put(MPSDefs.DB_SECURITY_QUESTION_ID_2, hmDbSlid.get(MPSDefs.DB_SECURITY_QUESTION_ID_2));
            hmMember.put(MPSDefs.DB_SECURITY_ANSWER_1, hmDbSlid.get(MPSDefs.DB_SECURITY_ANSWER_1));
            hmMember.put(MPSDefs.DB_SECURITY_ANSWER_2, hmDbSlid.get(MPSDefs.DB_SECURITY_ANSWER_2));
            //1510: US196387 propagate the security Q&A established date from the SLID to the linked member id.
            if (hmDbSlid.get(MPSDefs.DB_ONL_QA_EST_DATE) != null && !((String) hmDbSlid.get(MPSDefs.DB_ONL_QA_EST_DATE)).isEmpty()) {
                hmMember.put(MPSDefs.DB_ONL_QA_EST_DATE, hmDbSlid.get(MPSDefs.DB_ONL_QA_EST_DATE));
            }
            hmMember.put(MPSDefs.DB_SLID_MEMBER_NUM, hmDbSlid.get(MPSDefs.DB_MEMBER_NUM));
            hmMember.put(MPSDefs.DB_MEMBER_NUM, hmDbSlid.get(MPSDefs.DB_MEMBER_NUM));
        } // end of else part for bSlidMatchesMemberId
        logger.info("{}{} LMH_UMAWS.01 : Property propEnterpriseAccountSubTypes : {}", sClassName, sThisMethod, hmMember);
        return hmMember;
    }

    /**
     * Compares the SHA1 password from the member database (`hmDbMember`) with the password provided in the input map.
     * Returns true if the passwords match, false otherwise.
     *
     * @param hmInput input map containing password information to compare
     * @return boolean indicating whether the passwords match
     */
    private boolean comparePasswords(HashMap<String, Object> hmInput) {
        String sMemberSHA1Password = (String) hmDbMember.get(MPSDefs.DB_SHA1_PASSWORD);
        String sMemberMD5Password = (String) hmDbMember.get(MPSDefs.DB_MD5_PASSWORD);
        String sMemberDES3Password = (String) hmDbMember.get(MPSDefs.DB_DES3_PASSWORD);
        String sMemberEncPassword = (String) hmDbMember.get(MPSDefs.DB_ENC_PASSWORD);
        String sMemberGenPassword = (String) hmDbMember.get(MPSDefs.DB_GEN_PASSWORD);
        String sSlidSHA1Password = (String) hmDBSlidInfo.get(MPSDefs.DB_SHA1_PASSWORD);
        String sSlidMD5Password = (String) hmDBSlidInfo.get(MPSDefs.DB_MD5_PASSWORD);
        String sSlidDES3Password = (String) hmDBSlidInfo.get(MPSDefs.DB_DES3_PASSWORD);
        String sSlidEncPassword = (String) hmDBSlidInfo.get(MPSDefs.DB_ENC_PASSWORD);
        String sSlidGenPassword = (String) hmDBSlidInfo.get(MPSDefs.DB_GEN_PASSWORD);
        if (!Objects.equals(sMemberGenPassword, sSlidGenPassword)) return false;
        if (!Objects.equals(sMemberSHA1Password, sSlidSHA1Password)) return false;
        if (!Objects.equals(sMemberMD5Password, sSlidMD5Password)) return false;
        if (!Objects.equals(sMemberDES3Password, sSlidDES3Password)) return false;
        return Objects.equals(sMemberEncPassword, sSlidEncPassword);
    }

    /**
     * Formats a date string based on the provided key and value.
     * The method may apply specific formatting rules depending on the key.
     *
     * @param sDateKey   the key indicating the type or format of the date
     * @param sDateValue the date value to be formatted
     * @return a formatted date string
     */
    private String formatDate(String sDateKey, String sDateValue) {
        String sThisMethod = ".formatDate.";

        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat outputFormat = new SimpleDateFormat("MMddyyyy");

        String stDate = null;
        String stAppInfo = null;
        try {
            Date date = inputFormat.parse(sDateValue);
            stDate = outputFormat.format(date);
            logger.info("{}{} LMH.FM.01 sFormattedDate : {}", sClassName, sThisMethod,  ESAPI.encoder().encodeForHTML(stDate));

        } catch (Exception e) {
            stAppInfo = "Exception thrown while date format";
            logger.error("{}{} LMH.FM.02  Exception : {}", sClassName, sThisMethod,  ESAPI.encoder().encodeForHTML(stAppInfo));
        }
        return stDate;
    }

    /**
     * Determines if a SLID (Subscriber Line ID) should be auto-generated based on account type and subtype.
     * Returns true if auto-generation conditions are met, otherwise false.
     *
     * @param sAccountType    the account type to check
     * @param sAccountSubType the account subtype to check
     * @return boolean indicating if SLID should be auto-generated
     */
    private boolean checkAutoGenSlid(String sAccountType, String sAccountSubType) {
        String sThisMethod = "checkAutoGenSlid";
        boolean bAutoGenSlid = false;
        ArrayList alAutoGenSlidAccountType = null;

        if (sOrigTransactionName != null && sOrigTransactionName.equals(CommonDefs.ATLAS_PROCESSOR)) {
            alAutoGenSlidAccountType = CommonUtil.parseToArray(propAtlasAutoGenSlidAccountType, CommonDefs.VALUE_SEPARATOR_CHAR);
            logger.info("{}{} LMH_CAGS.01 : Property propAtlasAutoGenSlidAccountType : {}", sClassName, sThisMethod, alAutoGenSlidAccountType);
        } else if ((sCallingSystemId != null) && (sCallingSystemId.equalsIgnoreCase(CommonDefs.CALLING_SYSTEM_MYWORLD) || sCallingSystemId.equalsIgnoreCase(CommonDefs.CALLING_SYSTEM_CSRMYWORLD))) {
            alAutoGenSlidAccountType = CommonUtil.parseToArray(propMyattAutoGenSlidAccountType, CommonDefs.VALUE_SEPARATOR_CHAR);
            logger.info("{}{} LMH_CAGS.02 : Property propMyattAutoGenSlidAccountType : {}", sClassName, sThisMethod, alAutoGenSlidAccountType);
        } else {
            alAutoGenSlidAccountType = CommonUtil.parseToArray(propAutoGenSlidAccountType, CommonDefs.VALUE_SEPARATOR_CHAR);
            logger.info("{}{} LMH_CAGS.03 : Property propAutoGenSlidAccountType : {}", sClassName, sThisMethod, alAutoGenSlidAccountType);
        }
        if (alAutoGenSlidAccountType.isEmpty()) {
            alAutoGenSlidAccountType.add(CommonDefs.ACTIVE);
        }
        String sTempAccountType = calculateAccountType(sAccountType, sAccountSubType);
        if (alAutoGenSlidAccountType.contains(CommonDefs.ACTIVE) || sTempAccountType == null || alAutoGenSlidAccountType.contains(sTempAccountType)) {
            bAutoGenSlid = true;
        }
        return bAutoGenSlid;
    }

    /**
     * Calculates the account type string based on the provided account type and account subtype.
     * This method may apply business logic to determine a normalized or combined account type value.
     *
     * @param accountType    the main account type
     * @param accountSubType the account subtype
     * @return a string representing the calculated account type, or null if not applicable
     */
    public String calculateAccountType(String accountType, String accountSubType) {

        String sThisMethod = "calculateAccountType";
        String derivedAccountType = null;

        ArrayList alResidentialAccountSubTypes = CommonUtil.parseToArray(propResidentialAccountSubTypes, CommonDefs.VALUE_SEPARATOR_CHAR);
        logger.info("{}{} LMH_CAT.01 : Property propResidentialAccountSubTypes : {}", sClassName, sThisMethod, alResidentialAccountSubTypes);

        ArrayList alBusinessAccountSubTypes = CommonUtil.parseToArray(propBusinessAccountSubTypes, CommonDefs.VALUE_SEPARATOR_CHAR);
        logger.info("{}{} LMH_CAT.02 : Property propBusinessAccountSubTypes : {}", sClassName, sThisMethod, alBusinessAccountSubTypes);

        ArrayList alEnterpriseAccountSubTypes = CommonUtil.parseToArray(propLSRegInvalidAccountSubTypes, CommonDefs.VALUE_SEPARATOR_CHAR);
        logger.info("{}{} LMH_CAT.03 : Property propEnterpriseAccountSubTypes : {}", sClassName, sThisMethod, alEnterpriseAccountSubTypes);

        if (accountSubType != null && !accountSubType.isEmpty()) {
            if (alBusinessAccountSubTypes.contains(accountSubType)) {
                derivedAccountType = MPSDefs.DB_BUSINESS;
            } else if (alResidentialAccountSubTypes.contains(accountSubType)) {
                derivedAccountType = MPSDefs.DB_CONSUMER;
            } else if (alEnterpriseAccountSubTypes.contains(accountSubType)) {
                derivedAccountType = "E";
            } else {
                derivedAccountType = accountType;
            }
        } else {
            derivedAccountType = accountType;
        }
        logger.info("{}{} LMH_CAT.04 :  derivedAccountType : {}", sClassName, sThisMethod, derivedAccountType);
        return derivedAccountType;
    }

    /**
     * Retrieves service information for a given service type from the provided database service hash.
     * Iterates over the specified keys and collects corresponding values from the service info map.
     *
     * @param hmDBServiceHash the hash map containing service data
     * @param sServiceType    the type of service to retrieve information for
     * @param alKeys          the list of keys to extract from the service info
     * @return an ArrayList of strings containing the requested service information
     */
    private ArrayList<String> getServiceInfo(HashMap<String, Object> hmDBServiceHash, String sServiceType, ArrayList alKeys) {

        HashMap hmServiceInfo = null;
        String stDbInstID = null;
        HashMap hmInstanceId = null;

        String stSorName = null;
        String stServiceStatusName = null;
        ArrayList alServices = CommonUtil.getArrayList();

        if (hmDBServiceHash != null && !hmDBServiceHash.isEmpty()) {
            stServiceStatusName = (String) hmDBServiceHash.get(MPSDefs.SERVICE_STATUS);
            Iterator it = hmDBServiceHash.keySet().iterator();
            while (it.hasNext()) {
                stDbInstID = (String) it.next();
                Object objInstance = hmDBServiceHash.get(stDbInstID);

                if (objInstance instanceof HashMap) {
                    hmInstanceId = (HashMap) hmDBServiceHash.get(stDbInstID);
                    stSorName = (String) hmInstanceId.get(MPSDefs.DB_SOR_NAME);

                    hmServiceInfo = CommonUtil.getHashMap();

                    hmServiceInfo.put(MPSDefs.DB_SOR_INVARIANT_ID, hmInstanceId.get(MPSDefs.DB_SOR_INVARIANT_ID));
                    hmServiceInfo.put(CommonDefs.INSTANCE_ID, stDbInstID);
                    hmServiceInfo.put(CommonDefs.MEMBER_STATUS, hmInstanceId.get(MPSDefs.DB_MEMBER_STATUS_NAME));
                    hmServiceInfo.put(CommonDefs.SOR_NAME, stSorName);
                    hmServiceInfo.put(CommonDefs.SOR_ID, hmInstanceId.get(MPSDefs.DB_SOR_ID));

                    hmServiceInfo.put(CommonDefs.SERVICE_STATUS, stServiceStatusName);
                    hmServiceInfo.put(CommonDefs.SERVICE_TYPE, sServiceType);
                    hmServiceInfo.put(CommonDefs.SERVICE_ID, hmInstanceId.get(MPSDefs.DB_SERVICE_ID));

                    hmServiceInfo.put(MPSDefs.DB_DEFAULT_ACCOUNT, hmInstanceId.get(MPSDefs.DB_DEFAULT_ACCOUNT));
                    hmServiceInfo.put(MPSDefs.DB_CPNI_IMPACTED, hmInstanceId.get(MPSDefs.DB_CPNI_IMPACTED));
                    hmServiceInfo.put(MPSDefs.DB_MOBDEV_SOR_INVARIANT_ID, hmInstanceId.get(MPSDefs.DB_MOBDEV_SOR_INVARIANT_ID));
                    hmServiceInfo.put(MPSDefs.DB_MOBDEV_MEMBER_NUM, hmInstanceId.get(MPSDefs.DB_MOBDEV_MEMBER_NUM));

                    if (alKeys != null && !alKeys.isEmpty()) {
                        Iterator ite = alKeys.iterator();
                        while (ite.hasNext()) {
                            String sKey = (String) ite.next();
                            hmServiceInfo.put(sKey, hmInstanceId.get(sKey));
                        }
                    }
                    alServices.add(hmServiceInfo);
                }
            }

            if (hmServiceInfo == null) {
                hmServiceInfo = CommonUtil.getHashMap();

                hmServiceInfo.put(CommonDefs.MEMBER_STATUS, hmDBServiceHash.get(MPSDefs.DB_MEMBER_STATUS_NAME));
                hmServiceInfo.put(CommonDefs.SOR_NAME, hmDBServiceHash.get(MPSDefs.DB_SOR_NAME));
                hmServiceInfo.put(CommonDefs.SERVICE_STATUS, hmDBServiceHash.get(MPSDefs.SERVICE_STATUS));

                if (!sServiceType.equalsIgnoreCase(MPSDefs.SWH_SERVICE))
                    sServiceType = (String) CommonDefs.SERVICE_VALUES.get(sServiceType);
                hmServiceInfo.put(CommonDefs.SERVICE_TYPE, sServiceType);
                alServices.add(hmServiceInfo);
            }
        }
        return alServices;
    }

    /**
     * Builds the response map for a SLID (Subscriber Line ID) query.
     * Combines input parameters, member database info, and optional account data to construct
     * a HashMap containing relevant SLID information for downstream processing.
     *
     * @param hmInput    input parameters for the SLID query
     * @param hmDbMember member database information map
     * @param hmAccount  optional account data map (may be null)
     * @return HashMap containing the constructed SLID query response
     */
    private HashMap buildQuerySlidInfoResponse(HashMap hmInput, HashMap hmDbMember, Map hmAccount) {
        String sThisMethod = ".buildQuerySlidInfoResponse";

        HashMap<String, Object> hmResult = CommonErrorMap.makeCommonStatusMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success");
        HashMap<String, Object> hmSlidInfo = new HashMap<>();

        hmResult.put("slidInfo", hmSlidInfo);

        hmSlidInfo.put(MPSDefs.DB_MEMBER_NUM, hmInput.get(MPSDefs.DB_SLID_MEMBER_NUM));
        hmSlidInfo.put(MPSDefs.DB_GROUP_NUM, hmInput.get(MPSDefs.DB_GROUP_NUM));
        hmSlidInfo.put(MPSDefs.DB_DOMAIN_NAME, CommonDefs.SLID_DUM);

        hmSlidInfo.put(MPSDefs.DB_MEMBER_NAME, hmInput.get(CommonDefs.ACCESS_ID));
        hmSlidInfo.put(MPSDefs.DB_PARENT_NAME, hmInput.get(CommonDefs.ACCESS_ID));
        hmSlidInfo.put(MPSDefs.DB_PARENT_DOMAIN, CommonDefs.SLID_DUM);

        hmSlidInfo.put(CommonDefs.PARENT_CHILD_IND, "S");
        hmSlidInfo.put(MPSDefs.DB_AES_PASSWORD, hmDbMember.get(MPSDefs.DB_AES_PASSWORD));
        hmSlidInfo.put(MPSDefs.DB_SHA1_PASSWORD, hmDbMember.get(MPSDefs.DB_SHA1_PASSWORD));

        hmSlidInfo.put(MPSDefs.DB_DES3_PASSWORD, hmDbMember.get(MPSDefs.DB_DES3_PASSWORD));
        hmSlidInfo.put(MPSDefs.DB_ENC_PASSWORD, hmDbMember.get(MPSDefs.DB_ENC_PASSWORD));
        hmSlidInfo.put(MPSDefs.DB_MD5_PASSWORD, hmDbMember.get(MPSDefs.DB_MD5_PASSWORD));
        //2103 - SSHA-256 encryption changes
        if (hmDbMember.get(MPSDefs.DB_GEN_PASSWORD) != null && !((String) hmDbMember.get(MPSDefs.DB_GEN_PASSWORD)).isEmpty()) {
            hmSlidInfo.put(MPSDefs.DB_GEN_PASSWORD, hmDbMember.get(MPSDefs.DB_GEN_PASSWORD));
            hmSlidInfo.put(MPSDefs.DB_GEN_PASSWORD_TYPE, hmDbMember.get(MPSDefs.DB_GEN_PASSWORD_TYPE));
        }
        hmSlidInfo.put(MPSDefs.DB_LC_FIRSTNAME, hmDbMember.get(MPSDefs.DB_LC_FIRSTNAME));
        hmSlidInfo.put(MPSDefs.DB_LC_LASTNAME, hmDbMember.get(MPSDefs.DB_LC_LASTNAME));
        hmSlidInfo.put(MPSDefs.DB_FULLNAME, hmDbMember.get(MPSDefs.DB_FULLNAME));

        hmSlidInfo.put(MPSDefs.DB_CONTACT_EMAIL_STATUS, hmDbMember.get(MPSDefs.DB_CONTACT_EMAIL_STATUS));
        hmSlidInfo.put(MPSDefs.DB_CONTACT_EMAIL, hmDbMember.get(MPSDefs.DB_CONTACT_EMAIL));

        if("AddSecMemberId".equalsIgnoreCase((String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME))){
            hmSlidInfo.put(MPSDefs.DB_SECURITY_QUESTION_1, hmDbMember.get(MPSDefs.DB_SECURITY_QUESTION_1));
            hmSlidInfo.put(MPSDefs.DB_SECURITY_QUESTION_2, hmDbMember.get(MPSDefs.DB_SECURITY_QUESTION_2));
        } else {
            hmSlidInfo.put(MPSDefs.DB_SECURITY_QUESTION_ID_1, hmDbMember.get(MPSDefs.DB_SECURITY_QUESTION_ID_1));
            hmSlidInfo.put(MPSDefs.DB_SECURITY_QUESTION_ID_2, hmDbMember.get(MPSDefs.DB_SECURITY_QUESTION_ID_2));
        }

        hmSlidInfo.put(MPSDefs.DB_SECURITY_ANSWER_1, hmDbMember.get(MPSDefs.DB_SECURITY_ANSWER_1));
        hmSlidInfo.put(MPSDefs.DB_SECURITY_ANSWER_2, hmDbMember.get(MPSDefs.DB_SECURITY_ANSWER_2));

        if (hmAccount != null && !hmAccount.isEmpty()) {
            HashMap hmTitanAccount = new HashMap();
            HashMap hmTitanInstance = new HashMap();
            ArrayList alRoles = new ArrayList();

            hmTitanAccount.put(MPSDefs.DB_SERVICE_NAME, hmAccount.get(CommonDefs.ACCOUNT_TYPE));
            hmTitanAccount.put(MPSDefs.DB_SOR_INVARIANT_ID, hmAccount.get(CommonDefs.ACCOUNT_INVARIANT_ID));
            hmTitanAccount.put(MPSDefs.DB_SOR_NAME, hmAccount.get(CommonDefs.ACCOUNT_SOR));

            hmTitanAccount.put(MPSDefs.DB_CPNI_IMPACTED, hmAccount.get(CommonDefs.CPNI_IMPACTED));
            hmTitanAccount.put(MPSDefs.DB_DEFAULT_ACCOUNT, hmAccount.get(CommonDefs.DEFAULT_ACCOUNT));
            hmTitanAccount.put(MPSDefs.DB_UVERSE_SERVICE_IND, hmAccount.get(MPSDefs.DB_UVERSE_SERVICE_IND));
            hmTitanAccount.put(MPSDefs.SERVICE_STATUS, MPSDefs.ENABLED);

            ArrayList alTempRole = (ArrayList) hmAccount.get(CommonDefs.ROLE_LIST);
            HashMap hmTempRole = (HashMap) alTempRole.get(0);

            if (hmTempRole != null) {
                HashMap hmRoles = CommonUtil.getHashMap();
                hmRoles.put(MPSDefs.DB_ROLE_NAME, hmTempRole.get(CommonDefs.ROLE_NAME));
                hmRoles.put(MPSDefs.DB_ROLE_STATUS_NAME, hmTempRole.get(CommonDefs.ROLE_STATUS));
                alRoles.add(hmRoles);
                hmTitanAccount.put(MPSDefs.DB_ROLES, alRoles);
            }
            hmTitanInstance.put(hmAccount.get(CommonDefs.ACCOUNT_INVARIANT_ID), hmTitanAccount);
            HashMap hmTitanFinalHash = CommonUtil.getHashMap();
            hmTitanFinalHash.put(CommonDefs.TITAN_SERVICE, hmTitanInstance);
            hmSlidInfo.put(MPSDefs.SERVICES, hmTitanFinalHash);
        }
        HashMap hmTempSlidInfo = new HashMap();
        hmTempSlidInfo.putAll(hmSlidInfo);
        hmDBSlidInfo = hmSlidInfo;
        //Add TITAN account under services because we added TITAN to slid
        hmResult.putAll(hmTempSlidInfo);
        logger.info("{}{} LMH_BQSIR.01 : Property propEnterpriseAccountSubTypes : {}", sClassName, sThisMethod, hmResult);
        return hmResult;
    }

    /**
     * Processes addition, update, or deletion of services based on the provided input map.
     * Applies business logic to handle service operations and returns a result map.
     *
     * @param hmInput HashMap containing input parameters for service processing
     * @return HashMap with the result of the add, update, or delete service operation
     */
    private HashMap processAddUpdDelServices(HashMap hmInput) {

        String sThisMethod = "processAddUpdDelServices";
        HashMap hmResponse = null;
        HashMap hmFinalResponse = null;
        String stAppInfo = null;

        try {
            HashMap<String, Object> hmMIDServices = (HashMap) hmDbMember.get(MPSDefs.SERVICES);
            if (hmMIDServices != null && hmMIDServices.containsKey(MPSDefs.MOSUB_SERVICE)) {

                HashMap hmRemoveMemberServices = CommonUtil.getHashMap();
                hmRemoveMemberServices.put(CommonDefs.SERVICE_TYPE, MPSDefs.MOSUB_SERVICE);

                ArrayList alDbInstanceServices = getServiceInfo((HashMap) hmMIDServices.get(MPSDefs.MOSUB_SERVICE), MPSDefs.MOSUB_SERVICE, null);

                HashMap hmDbInstanceServiceHash = (HashMap) alDbInstanceServices.get(0);

                hmRemoveMemberServices.put(CommonDefs.SERVICE_ID, hmDbInstanceServiceHash.get(CommonDefs.INSTANCE_ID));
                hmRemoveMemberServices.put(CommonDefs.SOR_INVARIANT_ID, hmDbInstanceServiceHash.get(MPSDefs.DB_SOR_INVARIANT_ID));
                //Updated to copy MOSUB only if .net MOSUB status is in Enabled state.
                String sServiceStatus = (String) hmDbInstanceServiceHash.get(CommonDefs.SERVICE_STATUS);

                ArrayList<String> alRemoveMemberServices = CommonUtil.getArrayList();
                alRemoveMemberServices.add(String.valueOf(new HashMap(hmRemoveMemberServices)));

                HashMap hmRemoveServicesFinalReq = CommonUtil.getHashMap();
                hmRemoveServicesFinalReq.put(CommonDefs.ORIG_TRANSACTION_NAME, sOrigTransactionName);
                hmRemoveServicesFinalReq.put(CommonDefs.TRANSACTION_ID, sTransactionId);
                hmRemoveServicesFinalReq.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                hmRemoveServicesFinalReq.put(CommonDefs.HANDLE, hmDbMember.get(MPSDefs.DB_MEMBER_NAME));
                hmRemoveServicesFinalReq.put(CommonDefs.DOMAIN, hmDbMember.get(MPSDefs.DB_DOMAIN_NAME));
                hmRemoveServicesFinalReq.put(MPSDefs.DB_MEMBER_NUM, hmDbMember.get(MPSDefs.DB_MEMBER_NUM));
                hmRemoveServicesFinalReq.put(CommonDefs.PARENT_CHILD_IND, hmDbMember.get(MPSDefs.DB_PARENT_CHILD_IND));
                hmRemoveServicesFinalReq.put(CommonDefs.TRANSACTION_NAME, CommonDefs.REMOVESERVICES_GENERIC_TRANSACTION_NAME);
                hmRemoveServicesFinalReq.put(CommonDefs.SERVICES, alRemoveMemberServices);
                hmRemoveServicesFinalReq.put(CommonDefs.CALLDBUS, CommonDefs.IND_N);

                logger.debug("{}{} LMH.PAUDS.01 : Calling MPSYSInternalRestClient.callIDPRestClient() RemoveAssociation endpoint : {}", sClassName, sThisMethod, hmRemoveServicesFinalReq);
                hmResponse = (HashMap) oInternalIDPRestClient.callIDPRestClient(hmRemoveServicesFinalReq);
                logger.debug("{}{} LMH_PAUDS.02 : Response from MPSYSInternalRestClient.callIDPRestClient() RemoveAssociation endpoint: {}", sClassName, sThisMethod, hmResponse);

                if (hmResponse == null || hmResponse.isEmpty()) {
                    stAppInfo = "Null Response returned from MPSYSInternalRestClient.callIDPRestClient()";
                    hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                    logger.info("{}{} LMH_PAUDS.03 : {}", sClassName, sThisMethod, HtmlUtils.htmlEscape(stAppInfo));
                    return hmResponse;
                }
                hmFinalResponse = CommonErrorMap.makeCommonStatusMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success");

                HashMap hmTempRemoveMemberServices = (HashMap) hmResponse.get(CommonDefs.REMOVESERVICES_GENERIC_TRANSACTION_NAME);
                hmTempRemoveMemberServices.remove(CommonDefs.CALLG2LDAP);
                hmFinalResponse.put(MPSDefs.WS_REMOVE_MEMBER_SERVICES, hmTempRemoveMemberServices);

                String sMobdevSorInvariantId = (String) hmDbInstanceServiceHash.get(MPSDefs.DB_MOBDEV_SOR_INVARIANT_ID);
                String sMobdevMemberNum = (String) hmDbInstanceServiceHash.get(MPSDefs.DB_MOBDEV_MEMBER_NUM);

                if ((sMobdevSorInvariantId != null) && (sMobdevMemberNum != null) &&
                        (sMobdevSorInvariantId.trim().length() > 0) && (sMobdevMemberNum.trim().length() > 0)) {

                    HashMap hmRemoveMobilityDevice = CommonUtil.getHashMap();

                    hmRemoveMobilityDevice.put(MPSDefs.DB_SOR_INVARIANT_ID, sMobdevSorInvariantId);
                    hmRemoveMobilityDevice.put(MPSDefs.DB_MEMBER_NUM, sMobdevMemberNum);
                    hmRemoveMobilityDevice.put(MPSDefs.DB_SERVICE_ID, hmDbInstanceServiceHash.get(CommonDefs.SERVICE_ID));
                    hmRemoveMobilityDevice.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);

                    ArrayList alRemoveMobilityDevice = CommonUtil.getArrayList();
                    alRemoveMobilityDevice.add(hmRemoveMobilityDevice);

                    hmFinalResponse.put(MPSDefs.WS_REMOVE_MOBILITY_DEVICES, alRemoveMobilityDevice);
                }
                alRemoveSvcListEvent = (ArrayList) hmResponse.get(CommonDefs.CONSOLIDATED_DBUS_INPUT);

                HashMap hmSlidServices = (HashMap) hmDBSlidInfo.get(MPSDefs.SERVICES);
                if ((hmDBSlidInfo != null) &&
                        ((hmSlidServices == null || hmSlidServices.isEmpty()) ||
                                (hmSlidServices != null && !hmSlidServices.containsKey(MPSDefs.MOSUB_SERVICE))) &&
                        (sServiceStatus != null && sServiceStatus.equalsIgnoreCase(MPSDefs.ENABLED))) {

                    HashMap hmAddService = CommonUtil.getHashMap();
                    hmAddService.put(MPSDefs.WS_CALLING_SYSTEM_ID, sCallingSystemId);
                    hmAddService.put(MPSDefs.WS_GROUP_NUM, hmDBSlidInfo.get(MPSDefs.DB_GROUP_NUM));
                    hmAddService.put(MPSDefs.WS_MEMBER_NUM, hmDBSlidInfo.get(MPSDefs.DB_MEMBER_NUM));

                    HashMap hmService = CommonUtil.getHashMap();
                    hmService.put(MPSDefs.WS_MEMBER_STATUS_NAME, MPSDefs.ENABLED);
                    hmService.put(MPSDefs.WS_GROUP_STATUS_NAME, MPSDefs.ENABLED);
                    hmService.put(MPSDefs.WS_SERVICE_NAME, MPSDefs.MOSUB_SERVICE);
                    hmService.put(MPSDefs.WS_SOR_INVARIANT_ID, hmDbInstanceServiceHash.get(MPSDefs.DB_SOR_INVARIANT_ID));
                    hmService.put(MPSDefs.WS_SERVICE_ID, hmDbInstanceServiceHash.get(CommonDefs.INSTANCE_ID));
                    hmService.put(MPSDefs.WS_SOR_NAME, hmDbInstanceServiceHash.get(CommonDefs.SOR_NAME));

                    ArrayList alAddServices = CommonUtil.getArrayList();
                    alAddServices.add(hmService);
                    hmAddService.put(MPSDefs.WS_SERVICES, alAddServices);
                    hmFinalResponse.put(MPSDefs.WS_ADD_SERVICES, hmAddService);
                }
            }
        } catch (Exception e) {
            hmFinalResponse = CommonErrorMap.makeExceptionMap(e, logger);
            stAppInfo = "Exception thrown processAddUpdDelServices method : " + hmFinalResponse;
            logger.error("{}{} LMH.PAUDS.05 : {}", sClassName, sThisMethod, stAppInfo);
        }
        return hmFinalResponse;
    }
}
