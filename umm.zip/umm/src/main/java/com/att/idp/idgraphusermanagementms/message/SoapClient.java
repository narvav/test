package com.att.idp.idgraphusermanagementms.message;

import jakarta.xml.soap.*;

import org.springframework.stereotype.Component;

import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.StringWriter;

@Component
public class SoapClient {

	public HashMap callSoap(HashMap params, String url) throws Exception {
		String xmlFilePath = getClass().getClassLoader().getResource("RemoveAccount.xml").getPath();
		String soapRequest = createSoapRequest(params,
				xmlFilePath);
		String soapResponse = sendSoapRequest(soapRequest, url, "testqc", "m5D%s1Y");
		return parseSoapResponse(soapResponse);
	}

	/*
	public String createSoapRequest(HashMap<String, Object> params) throws SOAPException, IOException {
		SOAPMessage soapMessage = MessageFactory.newInstance().createMessage();
		SOAPEnvelope envelope = soapMessage.getSOAPPart().getEnvelope();
		SOAPBody soapBody = envelope.getBody();

		SOAPElement removeAccountRequest = soapBody.addChildElement("removeAccountRequest", "",
				"http://mpsys.ril.att.com/removeaccountrequest/v1");

		// Add elements in the correct order
		if (params.containsKey("transactionName")) {
			SOAPElement element = removeAccountRequest.addChildElement("transactionName");
			element.addTextNode(params.get("transactionName").toString());
		}
		if (params.containsKey("transactionId")) {
			SOAPElement element = removeAccountRequest.addChildElement("transactionId");
			element.addTextNode(params.get("transactionId").toString());
		}

		for (Map.Entry<String, Object> entry : params.entrySet()) {
			if (entry.getKey().equals("accountList")) {
				SOAPElement parentElement = removeAccountRequest.addChildElement("accountList");
				ArrayList<HashMap<String, Object>> accountList = (ArrayList<HashMap<String, Object>>) entry.getValue();

				for (HashMap<String, Object> account : accountList) {
					SOAPElement accountElement = parentElement.addChildElement("account");

					for (Map.Entry<String, Object> accountEntry : account.entrySet()) {
						// Skip if the key is parentSorId
						if (accountEntry.getKey().equals("parentSorId")
								|| accountEntry.getKey().equals("parentSorInvariantId")) {
							continue;
						}
						SOAPElement childElement = accountElement.addChildElement(accountEntry.getKey());
						if (accountEntry.getValue() != null && !accountEntry.getValue().equals("parentSorId"))
							childElement.addTextNode(accountEntry.getValue().toString());
					}
				}
			} else {

				if (!entry.getKey().equals("transactionName") || !entry.getKey().equals("transactionId")) {
					SOAPElement element = removeAccountRequest.addChildElement(entry.getKey());
					if (entry.getValue() instanceof Boolean) {
						Boolean boolValue = (Boolean) entry.getValue();
						element.addTextNode(boolValue.toString());
					} else {
						if (entry.getValue() != null)
							element.addTextNode(entry.getValue().toString());
					}
				}
			}
		}

		soapMessage.saveChanges();

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		soapMessage.writeTo(outputStream);

		return outputStream.toString();
	}*/

	public String createSoapRequest(HashMap<String, Object> params, String xmlFilePath) throws Exception {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(xmlFilePath);

		// Normalize the XML structure
		doc.getDocumentElement().normalize();

		// Traverse the XML document
		updateNode(doc.getDocumentElement(), params);

		// Convert the updated Document back into a string
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		StringWriter writer = new StringWriter();
		transformer.transform(new DOMSource(doc), new StreamResult(writer));

		return writer.getBuffer().toString();
	}

	private void updateNode(Node node, HashMap<String, Object> params) {
		if (node.getNodeType() == Node.ELEMENT_NODE) {
			Element element = (Element) node;
			// If the element's tag name is in the HashMap, update its value
			if (params.containsKey(element.getTagName())) {
				if (element.getTagName().equals("accountList")) {
					ArrayList<HashMap<String, Object>> accountList = (ArrayList<HashMap<String, Object>>) params
							.get("accountList");
					for (HashMap<String, Object> account : accountList) {
						NodeList accountNodes = element.getChildNodes();
						for (int j = 0; j < accountNodes.getLength(); j++) {
							updateNode(accountNodes.item(j), account);
						}
					}
				} else {
					element.setTextContent(params.get(element.getTagName()).toString());
				}
			}
		}

		NodeList nodeList = node.getChildNodes();
		for (int i = 0; i < nodeList.getLength(); i++) {
			updateNode(nodeList.item(i), params);
		}
	}

	public String sendSoapRequest(String soapRequest, String url, String username, String password) throws Exception {
		SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
		SOAPConnection soapConnection = soapConnectionFactory.createConnection();

		InputStream is = new ByteArrayInputStream(soapRequest.getBytes());
		SOAPMessage request = MessageFactory.newInstance().createMessage(null, is);

		// Add Authorization header
		String authorization = username + ":" + password;
		String authorizationHeader = "Basic " + Base64.getEncoder().encodeToString(authorization.getBytes());
		MimeHeaders headers = request.getMimeHeaders();
		headers.addHeader("Authorization", authorizationHeader);
		request.getAttachments().forEachRemaining(System.out::print);
		SOAPMessage soapResponse = soapConnection.call(request, url);

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		soapResponse.writeTo(outputStream);

		return outputStream.toString();
	}

	public HashMap<String, Object> parseSoapResponse(String soapResponse) throws Exception {
		InputStream is = new ByteArrayInputStream(soapResponse.getBytes());
		SOAPMessage message = MessageFactory.newInstance().createMessage(null, is);

		SOAPBody soapBody = message.getSOAPBody();

		HashMap<String, Object> responseMap = new HashMap<>();

		Iterator iterator = soapBody.getChildElements();
		while (iterator.hasNext()) {
			SOAPElement element = (SOAPElement) iterator.next();
			// responseMap.put(element.getLocalName(), element.getValue());

			// Check if the appInfo value is "SUCCESS"
		//	if (element.getLocalName().equals("ns2:appInfo") && element.getValue().equals("SUCCESS")) {
				responseMap = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
						CommonDefs.COMMON_SUCCESS_MSG);
			//}
		}
		if (responseMap.isEmpty()) {

			responseMap= CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "SoapCall failed");
		}
		return responseMap;
		
	}

	/*
	 * public HashMap testData() { HashMap hmRAAccount = CommonUtil.getHashMap();
	 * hmRAAccount.put(CommonDefs.ACCOUNT_TYPE, sServiceType);
	 * hmRAAccount.put(CommonDefs.ACCOUNT_ID, sInstanceId);
	 * hmRAAccount.put(CommonDefs.ACCOUNT_INVARIANT_ID,
	 * hmInstanceId.get(MPSDefs.DB_SOR_INVARIANT_ID));
	 * hmRAAccount.put(CommonDefs.ACCOUNT_SOR,
	 * hmInstanceId.get(MPSDefs.DB_SOR_NAME));
	 * hmRAAccount.put(CommonDefs.PARENT_SOR_ID,
	 * hmInstanceId.get(MPSDefs.DB_PARENT_SOR_ID));
	 * hmRAAccount.put(CommonDefs.PARENT_SOR_INVARIANT_ID,
	 * hmInstanceId.get(MPSDefs.DB_PARENT_SOR_INVARIANT_ID));
	 * 
	 * alRAAccountList.add(hmRAAccount); }
	 */
}
