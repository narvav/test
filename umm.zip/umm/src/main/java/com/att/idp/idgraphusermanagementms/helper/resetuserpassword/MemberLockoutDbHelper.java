package com.att.idp.idgraphusermanagementms.helper.resetuserpassword;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * MemberLockoutDbHelper is a class that provides helper methods for managing member lockouts in a database.
 * It contains methods for processing data, adding, updating, and deleting lockout details.
 * This class is annotated with @Component, meaning it is an object managed by the Spring framework.
 * It uses Autowired to inject an instance of JdbcTemplate.
 * The class also contains several constants and instance variables.
 *
 * @author kg852c
 */
@Component
public class MemberLockoutDbHelper {

	private static final String info = "$Id: master/com/att/custmgmt/cuin/cupf/dhelpers/MPSDB_TMEMBERLOCKOUT_H.java v1 2020-01-30 kg852c $;";
	private static String sClassName = "MPSDB_TMEMBERLOCKOUT_H";
	private static final Logger log = LoggerFactory.getLogger(MemberLockoutDbHelper.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	/**
	 * This method processes the input data related to member lockouts.
	 * It takes a HashMap as input which contains the member lockout details.
	 * The method logs the start of the process and the input parameters.
	 * It checks various conditions such as the presence of certain keys in the HashMap, the values of certain keys, etc.
	 * Based on these conditions, it decides whether to proceed with the operations or return an error message.
	 * If it decides to proceed with the operations, it prepares the input for the operations and makes the call.
	 * In case of any exception, it logs the error and returns an error HashMap.
	 * Finally, it logs the end of the process and the result, and returns the result HashMap.
	 *
	 * @param hmInput HashMap containing the member lockout details.
	 * @return HashMap containing the result of the process.
	 */
	public HashMap processData(HashMap hmInput) {
		String sMethodName = ".processData.";
		HashMap hmResult = null;
		String sAppStatusCode = null;

		log.info("{}{}DBTOOLS01 : CVS KEYWORDS: {}", sClassName, sMethodName, info);
		log.info(sClassName + sMethodName + "DBTOOLS02 : " + "Input Hash is: " + hmInput);

		try {
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			if (sCallingSystemId == null || sCallingSystemId.trim().length() <= 0) {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM,
						"callingSystemId is null or empty in input");
				return hmResult;
			}

			ArrayList alLockoutOperations = (ArrayList) hmInput.get(MPSDefs.DB_MEMBERLOCKOUT);
			if (alLockoutOperations == null || alLockoutOperations.size() <= 0) {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM,
						"member lockout operations list is empty in input");
				return hmResult;
			}

			// Iterate through member lockout operations list
			for (int i = 0; i < alLockoutOperations.size(); i++) {
				HashMap hmLockoutOperation = (HashMap) alLockoutOperations.get(i);

				if (hmLockoutOperation != null && !hmLockoutOperation.isEmpty()) {
					String sOperationType = (String) hmLockoutOperation.get(MPSDefs.DB_OPERATION);
					hmLockoutOperation.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);

					if (sOperationType == null || sOperationType.length() <= 0) {
						hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM,
								"operation type is null or missing");
						return hmResult;
					}

					if (sOperationType.equalsIgnoreCase(MPSDefs.DB_OPERATION_INSERT)) {
						// Call local method to insert in MEMBERLOCKOUT table
						hmResult = add(hmLockoutOperation);
					} else if (sOperationType.equalsIgnoreCase(MPSDefs.DB_OPERATION_UPDATE)) {
						// Call local method to update in MEMBERLOCKOUT table
						hmResult = update(hmLockoutOperation);
					} else if (sOperationType.equalsIgnoreCase(MPSDefs.DB_OPERATION_DELETE)) {
						// Call local method to delete from MEMBERLOCKOUT table
						hmResult = delete(hmLockoutOperation);
					} else {
						hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM,
								sOperationType + ", operation type is invalid");
						return hmResult;
					}

					sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
					if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
						return hmResult;
					}
				} else {
					hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM,
							"member lockout operation hash is empty in input");
					return hmResult;
				}

			} // end of for loop
		} catch (Exception e) {

			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error(sClassName + sMethodName + "DBTOOLS_E2 : " + " Error::" + e.getMessage());
			log.error(sClassName + sMethodName + "DBTOOLS_E3 : " + "Exception = {}", e);

		} finally {
			log.info(sClassName + sMethodName + "DBTOOLS999 : response : " + hmResult);
		}

		return hmResult;
	}

	/**
	 * This method is used to add new member lockout details to the database.
	 * It takes a HashMap as input which contains the member lockout details to be added.
	 * The method logs the start of the process and the input parameters.
	 * It checks various conditions such as the presence of certain keys in the HashMap, the values of certain keys, etc.
	 * Based on these conditions, it decides whether to proceed with the addition or return an error message.
	 * If it decides to proceed with the addition, it prepares the input for the addition and makes the call.
	 * In case of any exception, it logs the error and returns an error HashMap.
	 * Finally, it logs the end of the process and the result, and returns the result HashMap.
	 *
	 * @param hmDbInput HashMap containing the member lockout details to be added.
	 * @return HashMap containing the result of the addition.
	 */
	public HashMap add(HashMap hmDbInput) {
		String sMethodName = ".add.";

		String sInsertMemberLockoutSql = "INSERT INTO MEMBERLOCKOUT ("
				+ " MEMBER_NUM, LOCKOUT_ID, SET_NUMBER, FAILED_AUTH_COUNT, LOCKOUT_EXPIRATION, "
				+ " LAST_FAILED_AUTH, LAST_MODIFIED_BY) " + " VALUES (?, ?, ?, ?, ?, ?, ?)";

		HashMap hmResult = null;
		List<Object> objectList = CommonUtil.getArrayList();
		String sAppInfo = null;

		SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy HH:mm:ss");

		log.info(sClassName + sMethodName + "DBTOOLS_01 : " + "Inputhash: " + hmDbInput);

		try {
			String sMemberNum = (String) hmDbInput.get(MPSDefs.DB_MEMBER_NUM);
			String sLockoutId = (String) hmDbInput.get(MPSDefs.DB_LOCKOUT_ID);
			String sSetNumber = (String) hmDbInput.get(MPSDefs.DB_SET_NUMBER);
			String sFailedAuthCount = (String) hmDbInput.get(MPSDefs.DB_FAILED_AUTH_COUNT);
			String sLockoutExpiration = (String) hmDbInput.get(MPSDefs.DB_LOCKOUT_EXPIRATION);
			String slastFailedAuth = (String) hmDbInput.get(MPSDefs.DB_LAST_FAILED_AUTH);
			String sCallingSystemId = (String) hmDbInput.get(CommonDefs.CALLING_SYSTEM_ID);

			if (sMemberNum == null || sMemberNum.trim().length() <= 0 || sLockoutId == null
					|| sLockoutId.trim().length() <= 0) {
				sAppInfo = "member_num and/or lockout_id is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM, sAppInfo);

				log.info(sClassName + sMethodName + "DBTOOLS_02 : " + sAppInfo);

				return hmResult;
			}

			// add lock info in MEMBERLOCKOUT table

			objectList.add(sMemberNum);

			int iLockoutId = Integer.parseInt(sLockoutId);
			objectList.add(iLockoutId);

			if (sSetNumber != null) {
				int iSetNumber = Integer.parseInt(sSetNumber);
				objectList.add(iSetNumber);
			} else {
				objectList.add(null);
			}
			if (sFailedAuthCount != null) {
				int iFailedAuthCount = Integer.parseInt(sFailedAuthCount);
				objectList.add(iFailedAuthCount);
			} else {
				objectList.add(null);
			}

			if (sLockoutExpiration != null) {
				java.util.Date util_date = sdf.parse(sLockoutExpiration);
				java.sql.Timestamp DateVal = new java.sql.Timestamp(util_date.getTime());

				objectList.add(DateVal);
			} else {
				objectList.add(null);
			}

			if (slastFailedAuth != null) {
				java.util.Date util_date = sdf.parse(slastFailedAuth);
				java.sql.Timestamp timeVal = new java.sql.Timestamp(util_date.getTime());

				objectList.add(timeVal);
			} else {
				objectList.add(null);
			}

			objectList.add(sCallingSystemId);

			log.info(
					sClassName + sMethodName + "DBTOOLS_03 : " + "sInsertMemberLockoutSql: " + sInsertMemberLockoutSql);

			long pTime = 0;
			Date tQueryTime = new Date();

			// execute the insert statement
			int iCount = jdbcTemplate.update(new String(sInsertMemberLockoutSql),
					objectList.toArray(new Object[objectList.size()]));

			// Calculate the total time taken to execute the query
			// to return time in milliseconds for APRIL2011-sa7153
			pTime = (System.currentTimeMillis() - tQueryTime.getTime());

			log.info(sClassName + sMethodName + "QUERY999 : " + "Total time taken to execute memberlockout insert = "
					+ pTime + " milliseconds");

			log.info(sClassName + sMethodName + "DBTOOLS_04 : " + "No of rows inserted in TMEMBERSLOCKOUT:= " + iCount);

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
					"No of rows inserted in TMEMBERSLOCKOUT table : " + iCount);

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error(sClassName + sMethodName + "DBTOOLS_E2 : " + " Error::" + e.getMessage());
			log.error(sClassName + sMethodName + "DBTOOLS_E3 : " + "Exception = {}", e);
		} finally {
			log.info(sClassName + sMethodName + "DBTOOLS999 : response : " + hmResult);
		}

		return hmResult;
	}

	/**
	 * This method is used to delete member lockout details from the database.
	 * It takes a HashMap as input which contains the member lockout details to be deleted.
	 * The method logs the start of the process and the input parameters.
	 * It checks various conditions such as the presence of certain keys in the HashMap, the values of certain keys, etc.
	 * Based on these conditions, it decides whether to proceed with the deletion or return an error message.
	 * If it decides to proceed with the deletion, it prepares the input for the deletion and makes the call.
	 * In case of any exception, it logs the error and returns an error HashMap.
	 * Finally, it logs the end of the process and the result, and returns the result HashMap.
	 *
	 * @param hmDbInput HashMap containing the member lockout details to be deleted.
	 * @return HashMap containing the result of the deletion.
	 */
	public HashMap delete(HashMap hmDbInput) {
		String sMethodName = ".delete.";

		HashMap hmResult = null;
		List<Object> objectList = CommonUtil.getArrayList();
		String sAppInfo = null;
		int iCount;

		log.info(sClassName + sMethodName + "DBTOOLS_01 : " + "Inputhash: " + hmDbInput);

		String sMemberNum = (String) hmDbInput.get(MPSDefs.DB_MEMBER_NUM);
		String sLockoutId = (String) hmDbInput.get(MPSDefs.DB_LOCKOUT_ID);
		String sDeleteLocksByMemberNumFlag = (String) hmDbInput.get(MPSDefs.DELETE_LOCKS_BY_MEMBER_NUM_FLAG);

		if (sMemberNum == null || sMemberNum.trim().length() <= 0) {
			sAppInfo = "member_num is null or empty in input";
			hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM, sAppInfo);
			log.info(sClassName + sMethodName + "DBTOOLS_03 : " + sAppInfo);
			return hmResult;
		}

		if ((sLockoutId == null || sLockoutId.trim().length() <= 0) && (sDeleteLocksByMemberNumFlag == null
				|| !sDeleteLocksByMemberNumFlag.equalsIgnoreCase(MPSDefs.YES))) {
			sAppInfo = "lockout_id is null or empty in input";
			hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM, sAppInfo);
			log.info(sClassName + sMethodName + "DBTOOLS_04 : " + sAppInfo);
			return hmResult;
		}

		try {
			if (sDeleteLocksByMemberNumFlag != null && sDeleteLocksByMemberNumFlag.equalsIgnoreCase(MPSDefs.YES)) {
				String sDeleteMemberLocksByMemberNumSql = "DELETE FROM MEMBERLOCKOUT where MEMBER_NUM = ?";

				objectList.add(sMemberNum.trim());
				log.info(sClassName + sMethodName + "DBTOOLS_05 : " + "sDeleteMemberLocksByMemberNumSql: "
						+ sDeleteMemberLocksByMemberNumSql);

				Date dtStartDate = new Date();

				iCount = jdbcTemplate.update(new String(sDeleteMemberLocksByMemberNumSql),
						objectList.toArray(new Object[objectList.size()]));

				long pTime = (System.currentTimeMillis() - dtStartDate.getTime());

				log.info(sClassName + sMethodName + "QUERY999 : " + "Total time taken to execute query = " + pTime
						+ " milliseconds");

				log.info(sClassName + sMethodName + "DBTOOLS07 : " + "No of rows deleted are: " + iCount);

				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
						"No of rows removed:= " + iCount);

			} else {

				String sDeleteMemberLockoutSql = "DELETE FROM MEMBERLOCKOUT where MEMBER_NUM = ?"
						+ " AND LOCKOUT_ID = ? ";

				objectList.add(sMemberNum.trim());
				int iLockoutId = Integer.parseInt(sLockoutId);
				objectList.add(iLockoutId);
				log.info(sClassName + sMethodName + "DBTOOLS_06 : " + "sDeleteMemberLockoutSql: "
						+ sDeleteMemberLockoutSql);

				Date dtStartDate = new Date();

				iCount = jdbcTemplate.update(new String(sDeleteMemberLockoutSql),
						objectList.toArray(new Object[objectList.size()]));

				long pTime = (System.currentTimeMillis() - dtStartDate.getTime());

				log.info(sClassName + sMethodName + "QUERY999 : " + "Total time taken to execute query = " + pTime
						+ " milliseconds");

				log.info(sClassName + sMethodName + "DBTOOLS07 : " + "No of rows deleted are: " + iCount);

				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
						"No of rows removed:= " + iCount);
			}

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error(sClassName + sMethodName + "DBTOOLS_E3 : " + " Error::" + e.getMessage());
			log.error(sClassName + sMethodName + "DBTOOLS_E4 : " + "Exception = {}", e);
		} finally {
			log.info(sClassName + sMethodName + "DBTOOLS999 : response : " + hmResult);
		}
		return hmResult;
	}

	/**
	 * This method is used to update member lockout details in the database.
	 * It takes a HashMap as input which contains the member lockout details to be updated.
	 * The method logs the start of the process and the input parameters.
	 * It checks various conditions such as the presence of certain keys in the HashMap, the values of certain keys, etc.
	 * Based on these conditions, it decides whether to proceed with the update or return an error message.
	 * If it decides to proceed with the update, it prepares the input for the update and makes the call.
	 * In case of any exception, it logs the error and returns an error HashMap.
	 * Finally, it logs the end of the process and the result, and returns the result HashMap.
	 *
	 * @param hmDbInput HashMap containing the member lockout details to be updated.
	 * @return HashMap containing the result of the update.
	 */
	public HashMap update(HashMap hmDbInput) {
		String sMethodName = ".update.";

		HashMap hmResult = null;
		List<Object> objectList = CommonUtil.getArrayList();

		log.info(sClassName + sMethodName + "DBTOOLS_01 : " + "Inputhash: " + hmDbInput);

		String sMemNumVal = null;
		String sLockoutIdVal = null;
		String whereClause = null;
		String columnNames = "";

		StringBuilder query = new StringBuilder(" UPDATE MEMBERLOCKOUT ");

		java.util.List argsKeys = new ArrayList();
		java.util.List argsVals = new ArrayList();
		java.util.List Keys = new ArrayList();

		if (hmDbInput == null) {
			return hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_EMPTY_NUM, "Input hash is empty");
		}

		SimpleDateFormat sdf = null;
		String sKey = null;

		query.append(" SET ");

		log.info(sClassName + sMethodName + "DBTOOLS_03 : " + "Query = " + query);

		try {
			Iterator it = hmDbInput.keySet().iterator();
			while (it.hasNext()) {
				String key = (String) it.next();

				if (key.equalsIgnoreCase(MPSDefs.DB_MEMBER_NUM)) {
					sMemNumVal = (String) hmDbInput.get(key);
					log.info(sClassName + sMethodName + "DBTOOLS_04 : " + "member_num : " + HtmlUtils.htmlEscape(String.valueOf(sMemNumVal)));
				} else if (key.equalsIgnoreCase("lockout_id")) {
					sLockoutIdVal = (String) hmDbInput.get(key);
					log.info(sClassName + sMethodName + "DBTOOLS_05 : " + "lockout_id : " + HtmlUtils.htmlEscape(String.valueOf(sLockoutIdVal)));
				} else if (key.equalsIgnoreCase(CommonDefs.CALLING_SYSTEM_ID)) {
					argsKeys.add(MPSDefs.DB_LAST_MODIFIED_BY + " = ?");
					argsVals.add((String) hmDbInput.get(key));
					Keys.add(MPSDefs.DB_LAST_MODIFIED_BY);
				} else {
					if (memberCheckKey(key)) {
						argsKeys.add(key + " = ?");
						argsVals.add((String) hmDbInput.get(key));
						Keys.add(key);
					}
				}
			}

			int len = argsKeys.size();
			int i;

			for (i = 0; i < len; i++) {
				query.append(argsKeys.get(i));

				if (i != (len - 1)) {
					query.append(" , ");
				}
			}

			if (sMemNumVal != null && sMemNumVal.trim().length() > 0 && sLockoutIdVal != null
					&& sLockoutIdVal.trim().length() > 0) {
				whereClause = "member_num =? AND lockout_id = ?";
				query.append(" WHERE " + whereClause);
				log.info(sClassName + sMethodName + "DBTOOLS_06 : " + "Query =" + query);

			} else {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM,
						"member_num and/or lockout_id is null or empty in input");
				return hmResult;
			}

			i = 0;

			for (i = 0; i < argsVals.size(); i++) {
				if (memberTypeSet((String) Keys.get(i)).equals("Int")) {
					if (argsVals.get(i) != null)
						objectList.add(Integer.parseInt((String) argsVals.get(i)));
					else
						objectList.add(null);
				} else if (memberTypeSet((String) Keys.get(i)).equals("String")) {
					objectList.add((String) argsVals.get(i));
				} else if (memberTypeSet((String) Keys.get(i)).equals("Date")) {
					sKey = (String) Keys.get(i);
					if (sKey.equals("lockout_expiration")) {
						sdf = getSimpleDateFormat("MMddyyyy HH:mm:ss");
					} else if (sKey.equals("last_failed_auth")) {
						sdf = getSimpleDateFormat("MMddyyyy HH:mm:ss");
					}

					if (argsVals.get(i) != null) {
						java.util.Date util_date = sdf.parse((String) argsVals.get(i));
						java.sql.Timestamp timeStamp = getTimeStamp(util_date.getTime());
						objectList.add(timeStamp);
					} else {
						objectList.add(null);
					}
				}
			} // end of argsVals for loop

			objectList.add(sMemNumVal);
			objectList.add(sLockoutIdVal);

			int iCount = 0;
			if ((whereClause != null) && !(whereClause.length() == 0)) {
				iCount = jdbcTemplate.update(new String(query), objectList.toArray(new Object[objectList.size()]));

				log.info(sClassName + sMethodName + "DBTOOLS_07 : " + "The number of rows updated :" + iCount);

				if (iCount == 0) {
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
							"No Record found for given member_num and lockout_id");
				} else {
					hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
							"No of rows updated in TMEMBERSLOCKOUT table : " + iCount);
				}
			} else {
				hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_EMPTY_NUM, "where clause is not prepared");
				log.info(sClassName + sMethodName + "DBTOOLS_08 : " + "where clause is not prepared");
				return hmResult;
			}
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error(sClassName + sMethodName + "DBTOOLS_E2 : " + " Error::" + e.getMessage());
			log.error(sClassName + sMethodName + "DBTOOLS_E3 : " + "Exception = {}", e);
		} finally {
			log.info(sClassName + sMethodName + "DBTOOLS999 : response : " + hmResult);
		}
		return hmResult;
	}

	/**
	 * This method checks if the provided key is one of the predefined keys.
	 * It takes a String as input which is the key to be checked.
	 * The method returns true if the key matches any of the predefined keys, false otherwise.
	 *
	 * @param Key String containing the key to be checked.
	 * @return boolean indicating whether the key matches any of the predefined keys.
	 */
	public static boolean memberCheckKey(String Key) {
		if ((Key.equalsIgnoreCase(MPSDefs.DB_SET_NUMBER)) || (Key.equalsIgnoreCase(MPSDefs.DB_FAILED_AUTH_COUNT))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_LOCKOUT_EXPIRATION))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_LAST_FAILED_AUTH))) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * This method is used to determine the data type of the provided key.
	 * It takes a String as input which is the key to be checked.
	 * The method returns a String indicating the data type of the key.
	 * The possible return values are "Int", "Date", and "String".
	 * If the key does not match any of the predefined keys, it returns an empty string.
	 *
	 * @param Key String containing the key to be checked.
	 * @return String indicating the data type of the key.
	 */
	public static String memberTypeSet(String Key) {
		String Return = "";

		if ((Key.equalsIgnoreCase(MPSDefs.DB_LAST_MODIFIED_BY))) {
			Return = "String";
		}

		if ((Key.equalsIgnoreCase(MPSDefs.DB_SET_NUMBER)) || (Key.equalsIgnoreCase("failed_auth_count"))) {

			Return = "Int";
		}

		if ((Key.equalsIgnoreCase(MPSDefs.DB_LOCKOUT_EXPIRATION))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_LAST_FAILED_AUTH))) {
			Return = "Date";
		}

		return Return;
	}

	// Cast Fixes - 1106 Release
	private static SimpleDateFormat getSimpleDateFormat(String stFormat) {
		return new SimpleDateFormat(stFormat);
	}

	// Cast Fixes - 1106 Release
	private static java.sql.Timestamp getTimeStamp(long Time) {
		return new java.sql.Timestamp(Time);
	}

}
