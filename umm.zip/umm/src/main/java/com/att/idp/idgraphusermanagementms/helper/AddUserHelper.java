package com.att.idp.idgraphusermanagementms.helper;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.att.idp.idgraphusermanagementms.db.repository.DomainRepository;
import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.db.repository.MemberGroupRepository;
import com.att.idp.idgraphusermanagementms.db.repository.MemberRepository;
import com.att.idp.idgraphusermanagementms.helper.voltage.ProofingEncryptionHelper;
import com.att.idp.idgraphusermanagementms.queue.message.helpers.AddUserQueueHelper;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.RILCheckAndEncryptPasswordHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.RILDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * The AddUserHelper class is a Spring component that provides helper methods
 * for adding users. It is configured to use a properties file for user
 * management settings. This class uses autowired dependencies on various
 * helpers and repositories to perform its operations. It contains methods for
 * adding a user, validating requests, checking user ID availability, encrypting
 * passwords, and more.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class AddUserHelper {

	public static final Logger logger = LoggerFactory.getLogger(AddUserHelper.class);
	private static String sClassName = "AddUserHelper";
	private static final String ERROR_ENUM = "ErrorEnum";
	private boolean isTransactionRollbackOnError = false;

	@Value("${byPassCheckIdAvailabilityCSI}")
	private String propByPassCheckIdAvailabilityCSI;

	@Value("${RILHRS_ValidDomains}")
	private String propDBDomainList;

	@Value("${skipPasswordValidationCSI}")
	private String propSkipPasswordValidationCSI;

	@Value("${suppressAccessIdActivationCSIs}")
	private String propSuppressAccessIdActivationCSIs;

	@Autowired
	private CheckUserIdAvailabilityHelper oCheckUserIdAvailability;

	@Autowired
	private AddUserQueueHelper addUserQueueHelper;

	@Autowired
	private RILCheckAndEncryptPasswordHelper oRILCheckAndEncryptPasswordHelper;

	@Autowired
	private ProofingEncryptionHelper oProofingEncryption;

	@Autowired
	private MemberGroupRepository memGroupRepo;

	@Autowired
	private MemberRepository memberRepository;

	@Autowired
	private DomainRepository domainRepository;
	/**
	 * This method is used to add a user to the system. It performs several
	 * operations such as validating the request, checking user ID availability,
	 * encrypting the password, and adding the user to the database. It handles
	 * various scenarios and returns appropriate responses based on the outcome of
	 * each operation.
	 *
	 * @param hmInput A Map containing the necessary information about the user to
	 *                be added. This includes details like user ID, domain, contact
	 *                email, first name, last name, etc.
	 * @return A Map containing the result of the operation. This includes status
	 *         codes and messages indicating the success or failure of the
	 *         operation.
	 */
	@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
	public Map<String, Object> addUser(Map<String, Object> hmInput) {
		String sMethodName = ".addUser.";
		Map<String, Object> hmResult = null;
		String stAppInfo = null;
		String stAppStatusCode =null;
		logger.info(SpiMarker.getInstance(), "AddUserHelper.addUser.HLP000 : Input Hash :",
				StructuredArguments.entries(hmInput));

		if (hmInput == null || hmInput.isEmpty()) {
			stAppInfo = "Input Hash is NULL";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			logger.info("{}{}AUH_100 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		try {
			// AddUserHelper validation
			if (!ProfileOrchestrationConstants.LINK_MEMBER_TRANSACTION_NAME.equals(hmInput.get("origTransactionName"))) {
				hmResult = validateRequest(hmInput);

			logger.info("{}{}AUH_102 :Response from validateRequest: {}", sClassName, sMethodName, hmResult);
			 stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			} else if (stAppStatusCode == null) {
				stAppInfo = "null response from AddUserHelper.validateRequest";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}AUH_103 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
				}
			}
			String sDateOfBirth = (String) hmInput.get(CommonDefs.DATE_OF_BIRTH);

			// CheckUserId
			hmResult = checkUserIdAvailbility(hmInput);
			logger.info("{}{}AUH_109 :Response from checkUserIdAvailbility: {}", sClassName, sMethodName, hmResult);
			stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			} else if (stAppStatusCode == null) {
				stAppInfo = "null response from AddUserHelper.checkUserIdAvailbility";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}AUH_110 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			// EncryptPwd
			if (!ProfileOrchestrationConstants.LINK_MEMBER_TRANSACTION_NAME.equals(hmInput.get("origTransactionName"))) {
				hmResult = checkAndEncryptPassword(hmInput);

			logger.info("{}{}AUH_111 :Response from checkAndEncryptPassword: {}", sClassName, sMethodName, hmResult);
			stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			} else if (stAppStatusCode == null) {
				stAppInfo = "null response from AddUserHelper.checkAndEncryptPassword";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}AUH_112 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			}
			// separating security ans variable
			String stEncPassword = (String) hmInput.get(MPSDefs.DB_ENC_PASSWORD);
			String stMd5Password = (String) hmInput.get(MPSDefs.DB_MD5_PASSWORD);
			String stDes3Password = (String) hmInput.get(MPSDefs.DB_DES3_PASSWORD);
			String stSha1Password = (String) hmInput.get(MPSDefs.DB_SHA1_PASSWORD);
			String stAesPassword = (String) hmInput.get(MPSDefs.DB_AES_PASSWORD);
			String genericPassword = (String) hmInput.get(MPSDefs.DB_GEN_PASSWORD);
			String stOnlineSecAns1 = (String) hmInput.get(CommonDefs.ONLINE1_SECURITY_ANSWER);
			String stOnlineSecAns2 = (String) hmInput.get(CommonDefs.ONLINE2_SECURITY_ANSWER);
			hmInput.entrySet().removeIf(entry->entry.getValue() == null);
			// Voltage Encryption of SPI data
			hmResult = setVoltageEncryptedFields(hmInput);
			logger.debug("{}{}AUH_113 :Response from setVoltageEncryptedFields: {}", sClassName, sMethodName, hmResult);
			stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			} else if (stAppStatusCode == null) {
				stAppInfo = "null response from AddUserHelper.setVoltageEncryptedFields";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}AUH_114 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			// overriding password and security answers with values previous to calling
			// Proofing encryption
			// Note: passwords and security answers will be encrypted in addmember
			// repository
			hmInput.put(MPSDefs.DB_ENC_PASSWORD, stEncPassword);
			hmInput.put(MPSDefs.DB_MD5_PASSWORD, stMd5Password);
			hmInput.put(MPSDefs.DB_DES3_PASSWORD, stDes3Password);
			hmInput.put(MPSDefs.DB_SHA1_PASSWORD, stSha1Password);
			hmInput.put(MPSDefs.DB_AES_PASSWORD, stAesPassword);
			hmInput.put(MPSDefs.DB_GEN_PASSWORD, genericPassword);
			hmInput.put(CommonDefs.ONLINE1_SECURITY_ANSWER, stOnlineSecAns1);
			hmInput.put(CommonDefs.ONLINE2_SECURITY_ANSWER, stOnlineSecAns2);

			// SuppressAccessID and update tos flag
			hmResult = updateTOSFlagandSuppressAccessIdActivation(hmInput);
			logger.info("{}{}AUH_116 :Response from updateTOSFlagandSuppressAccessIdActivation: {}", sClassName,
					sMethodName, hmResult);
			stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			} else if (stAppStatusCode == null) {
				stAppInfo = "null response from AddUserHelper.updateTOSFlagandSuppressAccessIdActivation";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}AUH_117 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			// Adding User in DB:

			hmResult = addUserDB(hmInput);
			logger.info("{}{}AUH_116 :Response from addUserDB: {}", sClassName, sMethodName, hmResult);
			stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			} else if (stAppStatusCode == null) {
				stAppInfo = "null response from AddUserHelper.addUserDB";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}AUH_122 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			
			// encrypted data cleanup
			hmInput.remove(CommonDefs.VOLTAGE_DATE_OF_BIRTH);
			hmInput.remove("VencDateOfBirth");

			// DbusCall
			
			// populating dateOfBirth in dbus input
			hmInput.put(CommonDefs.DATE_OF_BIRTH, sDateOfBirth);

            String sOrginTransactionName = (String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME);

            Map hmDbusResult = addUserQueueHelper.sendMessageToMQ(hmInput);
            logger.info("{}{}AUH_123 :Response from addUserQueueHelper.sendMessageToMQ: {}", sClassName, sMethodName,
					hmDbusResult);

            if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmDbusResult) && ProfileOrchestrationConstants.ADD_USER_TRANSACTION_NAME.equals(sOrginTransactionName)) {
				hmResult = CommonUtilHelper.sysErrorHashMap("null response from AddUserQueueHelper.sendMessageToMQ");
				isTransactionRollbackOnError = true;
				return hmResult;
			} else {

				stAppStatusCode = (String) hmDbusResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
				if (StringUtils.isBlank(stAppStatusCode)) {
					isTransactionRollbackOnError = true;
					hmResult = CommonUtilHelper
							.sysErrorHashMap("null response from AddUserQueueHelper.sendMessageToMQ");
					return hmResult;
				} else if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					isTransactionRollbackOnError = true;
					stAppInfo = (String) hmDbusResult.get(CommonDefs.COMMON_APP_INFO);
					logger.info("{}{}AUH_124 : {}", sClassName, sMethodName,
							HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
					hmResult = hmDbusResult;
					return hmResult;
				}

			}
			
			// Default success if no error occur
			String guid = (String) hmResult.get(MPSDefs.DB_MEMBER_NUM);
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
			hmResult.put(CommonDefs.GUID, guid);
			hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
			
			// registerEmailUser changes by pb6583
			String sCallDbus = (String) hmInput.get(CommonDefs.CALLDBUS);
			if (sCallDbus != null && sCallDbus.equals(CommonDefs.IND_N)) {
				HashMap hmDbusInput = (HashMap) hmDbusResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT);
				hmResult.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, hmDbusInput);
				hmResult.put(CommonDefs.GROUP_NUM, hmInput.get(MPSDefs.DB_GROUP_NUM));
			}
			
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown AddUser method : " + hmResult;
			logger.info("{}{}AUH_125 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));

		}

		finally {
			String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);

			if (isTransactionRollbackOnError && sAppCategoryCode != null
					&& !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
				hmResult.put("isTransactionRollback", "Y");
			}
			logger.info("{}{}HLP999 : response from AddUser : {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(hmResult)));
		}
		return hmResult;

	}

	private Map<String, Object> addUserDB(Map<String, Object> hmInput) {
		String sMethodName = ".addUserDB.";
		String stAppInfo;
		Map<String, Object> hmResult = new HashMap();
		HashMap<String, Object> hmAddMemberGroup = new HashMap();
		String stDomain = (String) hmInput.get(CommonDefs.DOMAIN);
		String stHandle = (String) hmInput.get(CommonDefs.HANDLE);
		String stCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
		String sOrginTransactionName = (String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME);
		String memberNum = null;
		Long groupNum = 0L;
		String stAppStatusCode = null;

		try {
			if(sOrginTransactionName == null || (sOrginTransactionName != null && !sOrginTransactionName.equals(ProfileOrchestrationConstants.ADD_SEC_MEMBERID_TRANSACTION_NAME))) {
				hmAddMemberGroup.put(MPSDefs.DB_DOMAIN_NAME, stDomain);
				hmAddMemberGroup.put(MPSDefs.DB_PARENT_NAME, stHandle);
				hmAddMemberGroup.put(MPSDefs.DB_LAST_MODIFIED_BY, stCallingSystemId);

				logger.debug("{}{}AUH_117.1 : Calling MemberGroupRepository.addMemberGrp with inputHash : {}", sClassName,
						sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmAddMemberGroup)));

				hmResult = memGroupRepo.addMemberGrp(hmAddMemberGroup);

				if (hmResult == null || hmResult.isEmpty()) {
					stAppInfo = "Null Response returned from MemberGroupService.addMemberGroup";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					logger.info("{}{}AUH_117.2 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}

				stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

				if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
					if (stAppStatusCode.equals(CErrorDefs.ERR_USERNAME_EXISTS)) {

						stAppInfo = "Parent name already exists in MemberGroup table";
					}

					logger.info("{}{}AUH_117.3 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
					isTransactionRollbackOnError = true;
					return hmResult;
				}

				//Tmembergroup memberGrp = null;
				String dmainId = (String) hmResult.get(MPSDefs.DB_DOMAIN_ID);
				Long initMillis = Long.valueOf(System.currentTimeMillis());
				groupNum = memGroupRepo.getMemberGrpByParentNmAndDomainId(stHandle, Long.valueOf(dmainId));
				logger.debug("Time taken for  getMemberGrpByParentNmAndDomainId : " +
						(Long.valueOf(System.currentTimeMillis()) - initMillis) / 1000.0 + "secs");
				hmInput.put(MPSDefs.DB_GROUP_NUM, groupNum.toString());
				hmInput.put(MPSDefs.DB_DOMAIN_ID, hmResult.get(MPSDefs.DB_DOMAIN_ID));
			}
			else{
				hmInput.put(MPSDefs.DB_GROUP_NUM, hmInput.get(CommonDefs.GROUP_NUM));

				String domainId = String.valueOf(domainRepository.getDomainId(stDomain));
				hmInput.put(MPSDefs.DB_DOMAIN_ID, domainId);
			}

			hmResult = addMemberTable(hmInput);

			stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			} else if (stAppStatusCode == null) {
				stAppInfo = "null response from AddUserHelper.addMemberTable";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}AUH_119 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			memberNum = (String) hmResult.get(MPSDefs.DB_MEMBER_NUM);
			hmInput.put(MPSDefs.DB_MEMBER_NUM, memberNum);

		} catch (SQLException e) {
			stAppInfo = "SQL exception occured: " + e.getMessage();
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_DB_NUM, stAppInfo);
			logger.info("{}{}AUH_120 : {}", sClassName, sMethodName, stAppInfo);
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown while adding User in DB : " + hmResult;
			logger.info("{}{}AUH_121 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
		}

		return hmResult;
	}

	private Map<String, Object> addMemberTable(Map<String, Object> hmInput) {
		String sMethodName = ".addMemberTable.";
		String stAppStatusCode = null;
		String stAppInfo = null;
		Map<String, Object> hmResult = new HashMap();
		HashMap<String, Object> hmAddMember = CommonUtil.getHashMap();

		try {
			hmAddMember = (HashMap) addUserDBInputMap(hmInput);

			logger.debug(SpiMarker.getInstance(),
					"AddUserHelper.addMemberTable.AUH_118.1 : Calling MemberService.memberService with inputHash :",
					StructuredArguments.entries(hmAddMember));

			Long initMillis = Long.valueOf(System.currentTimeMillis());
			hmResult = memberRepository.addMem(hmAddMember);
			logger.info("Time taken to insert into TMEMBER table : "+
					(Long.valueOf(System.currentTimeMillis()) - initMillis) / 1000.0 + "secs");

			logger.info("{}{}AUH_118.2 : ResponseHash from MemberRepositoryImpl.addMem : {}", sClassName, sMethodName,
					hmResult);

			if (hmResult == null || hmResult.isEmpty()) {
				stAppInfo = "Null Response returned from MPSDB_Add_H.addMember";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}AUH_118.3 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {

				stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
				if (stAppInfo == null) {
					stAppInfo = (String) hmResult.get("sqlMsg");
				}
				if (stAppStatusCode.equals(CErrorDefs.ERR_USERNAME_EXISTS)) {

					stAppInfo = "member name already exists in Member table";

				} 

				logger.info("{}{}AUH_118.4 : {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
				hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
				isTransactionRollbackOnError = true;
				return hmResult;

			}
			// adding success
			hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);

		} catch (SQLException e) {
			stAppInfo = "SQL exception occured: " + e.getMessage();
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_DB_NUM, stAppInfo);
			logger.info("{}{}AUH_118.5 : {}", sClassName, sMethodName, stAppInfo);
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown while adding User in DB : " + hmResult;
			logger.info("{}{}AUH_118.6 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
		}
		return hmResult;
	}

	private Map<String, Object> addUserDBInputMap(Map<String, Object> hmInput) {

		String stDomain = (String) hmInput.get(CommonDefs.DOMAIN);
		String stHandle = (String) hmInput.get(CommonDefs.HANDLE);
		String stCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
		String stFullName = (String) hmInput.get(CommonDefs.DB_FULLNAME);
		String stProofingZip = (String) hmInput.get(CommonDefs.PROOFING_ZIP);
		String stGroupNum = (String) hmInput.get(MPSDefs.DB_GROUP_NUM);
		String stDomainId = (String) hmInput.get(MPSDefs.DB_DOMAIN_ID);
		String stParentChildInd = (String) hmInput.get(CommonDefs.PARENT_CHILD_IND);
		String stContactEmail = (String) hmInput.get(CommonDefs.CONTACT_EMAIL);
		String stContactEmailValid = (String) hmInput.get(CommonDefs.CONTACT_EMAIL_VALID);
		String stOrigTransactionName = (String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME);
		String stBrowerLang = (String) hmInput.get(CommonDefs.BROWSER_LANGUAGE);
		String stFirstName = (String) hmInput.get(CommonDefs.FIRST_NAME);
		String stLastName = (String) hmInput.get(CommonDefs.LAST_NAME);
		String stOnlineSecAns1 = (String) hmInput.get(CommonDefs.ONLINE1_SECURITY_ANSWER);
		String stOnlineSecQues1 = (String) hmInput.get(CommonDefs.ONLINE1_SECURITY_QUESTION);
		String stOnlineSecAns2 = (String) hmInput.get(CommonDefs.ONLINE2_SECURITY_ANSWER);
		String stOnlineSecQues2 = (String) hmInput.get(CommonDefs.ONLINE2_SECURITY_QUESTION);
		String stGender = (String) hmInput.get(CommonDefs.GENDER);
		String stLanguage = (String) hmInput.get(CommonDefs.LANGUAGE);
		String stPasswordDirty = (String) hmInput.get(CommonDefs.PASSWORD_DIRTY);
		String stAutoGenInd = (String) hmInput.get(CommonDefs.AUTO_GENERATED_IND);
		String stVencDateOfBirth = (String) hmInput.get("VencDateOfBirth");
		String stActivatedInd = (String) hmInput.get(CommonDefs.ACTIVATED_INDEX);

		String stEncPassword = (String) hmInput.get(MPSDefs.DB_ENC_PASSWORD);
		String stMd5Password = (String) hmInput.get(MPSDefs.DB_MD5_PASSWORD);
		String stDes3Password = (String) hmInput.get(MPSDefs.DB_DES3_PASSWORD);
		String stSha1Password = (String) hmInput.get(MPSDefs.DB_SHA1_PASSWORD);
		String stAesPassword = (String) hmInput.get(MPSDefs.DB_AES_PASSWORD);
		String genericPassword = (String) hmInput.get(MPSDefs.DB_GEN_PASSWORD);
		String genericPasswordType = (String) hmInput.get(MPSDefs.DB_GEN_PASSWORD_TYPE);
		String cbrNumber = (String) hmInput.get(ProfileOrchestrationConstants.CBR_NUMBER);
		String cbrRTValidFlag = (String) hmInput.get(ProfileOrchestrationConstants.CBR_RT_VALID_FLAG);
		String contactAddress = (String) hmInput.get(ProfileOrchestrationConstants.CONTACT_ADDRESS);

		String stSor = CommonDefs.SOR_NA;
		String stAccountType = MPSDefs.DB_CONSUMER;
		String stMailHost = null;
		String stMigrationInd = null;
		String stMigrationDate = null;

		Boolean isMIDInRequest = Optional.ofNullable((Boolean) hmInput.get("isMIDInRequest")).orElse(false);

		SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
		if (isMIDInRequest) {
			stMailHost = getMailHost(stDomain);
			stMigrationInd = MPSDefs.YES;
			stMigrationDate = sdf.format(new Date());
			stSor = (String) hmInput.get(CommonDefs.SOR);
		}
		hmInput.put("MailHost", stMailHost);
		hmInput.put("MigrationInd", stMigrationInd);
		hmInput.put(CommonDefs.SOR, stSor);

		if (!isMIDInRequest && !CommonDefs.ADD_USER_TRANSACTION_NAME.equals(stOrigTransactionName)) {
			stAccountType = null;
		}

		HashMap<String, Object> hmAddMember = CommonUtil.getHashMap();

		hmAddMember.put(MPSDefs.DB_MEMBER_NAME, stHandle);
		hmAddMember.put(MPSDefs.DB_DOMAIN_ID, stDomainId);
		hmAddMember.put(MPSDefs.DB_DOMAIN_NAME, stDomain);
		hmAddMember.put(MPSDefs.DB_GROUP_NUM, stGroupNum);
		hmAddMember.put(MPSDefs.DB_ENC_PASSWORD, stEncPassword);
		hmAddMember.put(MPSDefs.DB_MD5_PASSWORD, stMd5Password);
		hmAddMember.put(MPSDefs.DB_DES3_PASSWORD, stDes3Password);
		hmAddMember.put(MPSDefs.DB_SHA1_PASSWORD, stSha1Password);
		hmAddMember.put(MPSDefs.DB_AES_PASSWORD, stAesPassword);

		// 2103 - SSHA-256 encryption changes
		if (genericPassword != null && !genericPassword.isEmpty()) {
			hmAddMember.put(MPSDefs.DB_GEN_PASSWORD, genericPassword);
			hmAddMember.put(MPSDefs.DB_GEN_PASSWORD_TYPE, genericPasswordType);
		}
		hmAddMember.put(MPSDefs.DB_PARENT_CHILD_IND, stParentChildInd);
		hmAddMember.put(MPSDefs.DB_FULLNAME, stFullName);
		hmAddMember.put(MPSDefs.DB_ACCESS_NAME, CommonDefs.NONE_ACCESS);
		hmAddMember.put(MPSDefs.DB_SOR_NAME, stSor);
		hmAddMember.put(MPSDefs.DB_LAST_MODIFIED_BY, stCallingSystemId);
		hmAddMember.put(MPSDefs.DB_CONTACT_EMAIL, stContactEmail);
		hmAddMember.put(MPSDefs.DB_CONTACT_EMAIL_VALID, stContactEmailValid);
		hmAddMember.put(MPSDefs.DB_BROWSER_LANGUAGE, stBrowerLang);
		hmAddMember.put(MPSDefs.DB_ACCOUNT_TYPE, stAccountType);
		hmAddMember.put(MPSDefs.DB_MEMBER_STATE, MPSDefs.RESERVED_STATE);
		hmAddMember.put(MPSDefs.DB_LC_FIRSTNAME, stFirstName);
		hmAddMember.put(MPSDefs.DB_LC_LASTNAME, stLastName);
		hmAddMember.put(MPSDefs.DB_SECURITY_QUESTION_1, stOnlineSecQues1);
		hmAddMember.put(MPSDefs.DB_SECURITY_ANSWER_1, stOnlineSecAns1);
		hmAddMember.put(MPSDefs.DB_SECURITY_QUESTION_2, stOnlineSecQues2);
		hmAddMember.put(MPSDefs.DB_SECURITY_ANSWER_2, stOnlineSecAns2);
		hmAddMember.put(CommonDefs.DB_ACCESS_ID_RTV_DATE, hmInput.get(CommonDefs.ACCESS_ID_RTV_VALID_FLAG));
		hmAddMember.put(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE, hmInput.get(CommonDefs.CONTACT_EMAIL_RTV_FLAG));
		hmAddMember.put(MPSDefs.DB_GENDER, stGender);
		hmAddMember.put(MPSDefs.DB_LANGUAGE, stLanguage);
		hmAddMember.put(MPSDefs.DB_MAILHOST, stMailHost);
		hmAddMember.put(MPSDefs.DB_MIGRATION_IND, stMigrationInd);
		hmAddMember.put(MPSDefs.DB_MIGRATION_DATE, stMigrationDate);

		if (stProofingZip != null && !stProofingZip.trim().isEmpty()) {
			hmAddMember.put(MPSDefs.DB_PROOFING_ZIP, stProofingZip.trim());
		}

		if (stPasswordDirty != null && !stPasswordDirty.isEmpty()) {
			hmAddMember.put(MPSDefs.DB_PASSWORD_DIRTY, stPasswordDirty); // 1907
		}
		if (stAutoGenInd != null && !stAutoGenInd.isEmpty()) {
			hmAddMember.put(MPSDefs.DB_AUTOGENERATED_IND, stAutoGenInd); // 1907
		}
		if (stActivatedInd != null && !stActivatedInd.isEmpty()) {
			hmAddMember.put(MPSDefs.DB_ACTIVATED_IND, stActivatedInd);// 1907
		}

		if (isMIDInRequest) {
			if (stVencDateOfBirth != null && !stVencDateOfBirth.isEmpty()) {
				hmAddMember.put(MPSDefs.DB_BIRTHDATE_VENC, stVencDateOfBirth);
			}
		}

		if (StringUtils.isNotBlank(cbrNumber)) {
			hmAddMember.put(ProfileOrchestrationConstants.DB_CBR_NUMBER, cbrNumber);
		}
		if (StringUtils.isNotBlank(cbrRTValidFlag)) {
			hmAddMember.put(ProfileOrchestrationConstants.CBR_RT_VALID_FLAG, cbrRTValidFlag);

			if (cbrRTValidFlag.equalsIgnoreCase("Y")) {
				hmAddMember.put(ProfileOrchestrationConstants.DB_CBR_RTV_DATE,
						DateTimeFormatter.ofPattern("MM/dd/yyyy").format(Instant.now().atZone(ZoneOffset.UTC)));
			}
		}
		if (StringUtils.isNotBlank(contactAddress)) {
			hmAddMember.put(ProfileOrchestrationConstants.DB_CONTACT_ADDRESS, contactAddress);
		}

		String orgTransName = (String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME);
		if(orgTransName != null && orgTransName.equals(ProfileOrchestrationConstants.ADD_SEC_MEMBERID_TRANSACTION_NAME)) {
			hmAddMember.put(MPSDefs.DB_BAN, hmInput.get(MPSDefs.DB_BAN));
			hmAddMember.put(MPSDefs.DB_ACCESS_NAME, hmInput.get(CommonDefs.ACCESS_NAME));
			hmAddMember.put(MPSDefs.DB_NICKNAME, hmInput.get(MPSDefs.DB_NICKNAME));
			hmAddMember.put(MPSDefs.DB_LAST_FOUR_SSN, hmInput.get(CommonDefs.LAST_FOUR_SSN));
			hmAddMember.put(MPSDefs.DB_SECURITY_QUESTION, hmInput.get(CommonDefs.SECURITY_QUESTION));
			hmAddMember.put(MPSDefs.DB_SECURITY_ANSWER_VENC, hmInput.get(CommonDefs.VOLTAGE_SECURITY_ANSWER));
			hmAddMember.put(MPSDefs.DB_PASSCODE_VENC, hmInput.get(CommonDefs.VOLTAGE_PASSCODE));
		}

		return hmAddMember;

	}

	private Map<String, Object> checkAndEncryptPassword(Map<String, Object> hmInput) {
		String sMethodName = ".checkAndEncryptPassword.";
		Map<String, Object> hmResult = null;

		hmResult = setPasswordValidationFlag(hmInput);

		String stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		if (stAppStatusCode == null) {
			String stAppInfo = "null response from AddUserHelper.setPasswordValidationFlag";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			logger.info("{}{}AUH_110.4 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		} else if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
			return hmResult;
		}

		HashMap<String, Object> hmCheckAndEncryptInput = new HashMap();
		hmCheckAndEncryptInput.put(MPSDefs.WS_TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
		hmCheckAndEncryptInput.put(MPSDefs.WS_TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
		hmCheckAndEncryptInput.put(MPSDefs.WS_CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		hmCheckAndEncryptInput.put(MPSDefs.WS_CLEAR_TEXT, hmInput.get(CommonDefs.PASSWORD_CLEAR));
		hmCheckAndEncryptInput.put(MPSDefs.WS_USER_ID, hmInput.get(CommonDefs.HANDLE));
		hmCheckAndEncryptInput.put(MPSDefs.WS_DOMAIN, hmInput.get(CommonDefs.DOMAIN));
		hmCheckAndEncryptInput.put(CommonDefs.TEMP_GENERATED, hmInput.get(CommonDefs.TRANSACTION_NAME));
		hmCheckAndEncryptInput.put(CommonDefs.SKIP_PASSWORD_VALIDATION,
				hmInput.get(CommonDefs.SKIP_PASSWORD_VALIDATION));

		hmCheckAndEncryptInput.put(CommonDefs.FIRST_NAME, hmInput.get(CommonDefs.FIRST_NAME));
		hmCheckAndEncryptInput.put(CommonDefs.LAST_NAME, hmInput.get(CommonDefs.LAST_NAME));
		hmCheckAndEncryptInput.put(CommonDefs.CONTACT_EMAIL, hmInput.get(CommonDefs.CONTACT_EMAIL));

		logger.debug(SpiMarker.getInstance(),
				"AddUserHelper.checkAndEncryptPassword.AUH_110.5 : Calling RILCheckAndEncryptPasswordHelper with inputHash :",
				StructuredArguments.entries(hmCheckAndEncryptInput));

		hmResult = oRILCheckAndEncryptPasswordHelper.checkAndEncryptPassword(hmCheckAndEncryptInput);

		if (hmResult == null || hmResult.isEmpty()) {
			String stAppInfo = "Null Response returned from RILCheckAndEncryptPassword Helper";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			logger.info("{}{}AUH_110.7 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

		if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
			String stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
			logger.info("{}{}AUH_110.8 : {}", sClassName, sMethodName, StringEscapeUtils.escapeJava(stAppInfo));
			hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
			return hmResult;
		}

		String stEncPassword = (String) hmResult.get(RILDefs.RIL_ENC_PASSWORD);
		String stMd5Password = (String) hmResult.get(RILDefs.RIL_MD5_PASSWORD);
		String stDes3Password = (String) hmResult.get(RILDefs.RIL_DES3_PASSWORD);
		String stSha1Password = (String) hmResult.get(RILDefs.RIL_SHA1_PASSWORD);
		// 2103 - SSHA-256 encryption changes
		String genericPassword = (String) hmResult.get(RILDefs.RIL_GEN_PASSWORD);
		String genericPasswordType = (String) hmResult.get(RILDefs.RIL_GEN_PASSWORD_TYPE);
		String stAesPassword = (String) hmResult.get(RILDefs.RIL_AES_PASSWORD);

		hmInput.put(MPSDefs.DB_ENC_PASSWORD, stEncPassword);
		hmInput.put(MPSDefs.DB_MD5_PASSWORD, stMd5Password);
		hmInput.put(MPSDefs.DB_DES3_PASSWORD, stDes3Password);
		hmInput.put(MPSDefs.DB_SHA1_PASSWORD, stSha1Password);
		hmInput.put(MPSDefs.DB_AES_PASSWORD, stAesPassword);
		// 2103 - SSHA-256 encryption changes
		if (genericPassword != null && !genericPassword.isEmpty()) {
			hmInput.put(MPSDefs.DB_GEN_PASSWORD, genericPassword);
			hmInput.put(MPSDefs.DB_GEN_PASSWORD_TYPE, genericPasswordType);
		}

		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}

	/**
	 * This method checks if the 'byPassCheckIdAvailability' flag is set in the
	 * input map. If the flag is not set, it checks if the calling system ID is in
	 * the list of system IDs that are allowed to bypass the check for user ID
	 * availability. If the calling system ID is in the list, it sets the
	 * 'byPassCheckIdAvailability' flag to 'Y'. If the calling system ID is not in
	 * the list, it sets the 'byPassCheckIdAvailability' flag to 'N'.
	 *
	 * @param hmInput A map containing the necessary information about the user and
	 *                the system making the request. This includes details like user
	 *                ID, domain, contact email, first name, last name, etc.
	 * @return A string representing the 'byPassCheckIdAvailability' flag. It can be
	 *         either 'Y' (Yes) or 'N' (No).
	 */
	public String checkByPassCheckIdAvailabilityFlag(Map<String, Object> hmInput) {
		String sMethodName = ".checkByPassCheckIdAvailabilityFlag.";
		String stCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
		String byPassCheckIdAvailability = (String) hmInput.get(CommonDefs.BY_PASS_CHECK_ID_AVAILABLE);
		if (StringUtils.isBlank(byPassCheckIdAvailability)) {
			byPassCheckIdAvailability = CommonDefs.IND_N;

			ArrayList<String> albyPassCheckIdAvailabilityCSI = CommonUtil.parseToArray(propByPassCheckIdAvailabilityCSI,
					CommonDefs.VALUE_SEPARATOR_CHAR);

			logger.info("{}{}AUH_104.1 : Property byPassCheckIdAvailabilityCSI : {}", sClassName, sMethodName,
					albyPassCheckIdAvailabilityCSI);

			if (albyPassCheckIdAvailabilityCSI != null && albyPassCheckIdAvailabilityCSI.contains(stCallingSystemId)) {
				String stAppInfo = "Calling System Id : " + stCallingSystemId
						+ " does not need to check for handle validations/availability, setting byPassCheckIdAvailability flag to Y.";
				logger.info("{}{}AUH_104.2 : {}", sClassName, sMethodName, StringEscapeUtils.escapeJava(stAppInfo));
				byPassCheckIdAvailability = CommonDefs.IND_Y;
				hmInput.put(CommonDefs.BY_PASS_CHECK_ID_AVAILABLE, byPassCheckIdAvailability);
			}
		}
		return byPassCheckIdAvailability;
	}

	/**
	 * This method checks the availability of a user ID.
	 * It first checks if the 'byPassCheckIdAvailability' flag is set in the input map.
	 * If the flag is not set, it validates the user ID by calling the 'checkUserIdAvailability' method from the 'CheckUserIdAvailabilityHelper' class.
	 * If the user ID is not available or invalid, it returns a list of suggested user IDs.
	 *
	 * @param hmInput A map containing the necessary information about the user and the system making the request. This includes details like user ID, domain, contact email, first name, last name, etc.
	 * @return A map containing the result of the operation. This includes status codes and messages indicating the success or failure of the operation, and a list of suggested user IDs if the input user ID is not available or invalid.
	 */
	public Map<String, Object> checkUserIdAvailbility(Map<String, Object> hmInput) {
		String sMethodName = ".checkUserIdAvailbility.";
		Map<String, Object> hmResult = null;
		String stAppInfo;

		String byPassCheckIdAvailability = checkByPassCheckIdAvailabilityFlag(hmInput);

		String stHandle = (String) hmInput.get(CommonDefs.HANDLE);
		String stTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);
		if (!CommonDefs.IND_Y.equals(byPassCheckIdAvailability)) {
			int numSuggestions = 3;
			if (stHandle.contains("@"))
				numSuggestions = 1;

			HashMap<String, Object> hmCheckUserInput = CommonUtil.getHashMap();

			hmCheckUserInput.put(CommonDefs.TRANSACTION_ID, stTransactionId);
			hmCheckUserInput.put(CommonDefs.TRANSACTION_NAME, "CheckUserIdAvailability");
			hmCheckUserInput.put(CommonDefs.ORIG_TRANSACTION_NAME, (String) hmInput.get(CommonDefs.TRANSACTION_NAME));
			hmCheckUserInput.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
			hmCheckUserInput.put(CommonDefs.SUGGEST1, stHandle);
			hmCheckUserInput.put(CommonDefs.DOMAIN, (String) hmInput.get(CommonDefs.DOMAIN));
			hmCheckUserInput.put(CommonDefs.NUM_SUGGESTIONS, Integer.toString(numSuggestions));
			hmCheckUserInput.put(CommonDefs.IGNORE_QAY, CommonDefs.IND_Y);

			if (hmInput.containsKey(CommonDefs.SEARCH_SLID_NAME_SPACE)) {
				String stSearchSlidNameSpace = (String) hmInput.get(CommonDefs.SEARCH_SLID_NAME_SPACE);
				hmCheckUserInput.put(CommonDefs.SEARCH_SLID_NAME_SPACE, stSearchSlidNameSpace);
			}

			hmResult = oCheckUserIdAvailability.checkUserIdAvailability(hmCheckUserInput);

			if (MapUtils.isEmpty(hmResult)) {
				stAppInfo = "Null Response returned from CheckUserIdAvailability Helper";
				logger.info("{}{}AUH_105 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				return hmResult;

			}

			String stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
				logger.info("{}{}AUH_106 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
				return hmResult;
			}

			ArrayList alSuggestHandles = (ArrayList) hmResult.get(CommonDefs.SUGGESTLIST);

			if (alSuggestHandles == null || alSuggestHandles.isEmpty()) {
				stAppInfo = "CheckUserIdAvailability helper failed to return suggestList for Success response";
				logger.info("{}{}AUH_107 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				return hmResult;
			}

			Boolean bInputHandleValid = false;
			if (alSuggestHandles.size() == numSuggestions) {

				hmResult = addSugestedHandle(stHandle, alSuggestHandles, bInputHandleValid);

				return hmResult;

			} else {
				stAppInfo = "CheckUserIdAvailabilityHelper failed to return " + numSuggestions
						+ " items in suggest list";
				logger.info("{}{}AUH_108 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				return hmResult;
			}
		}

		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}

	/**
	 * addSugestedHandle method will validate the given handle against the suggested
	 * handles from checkUserIdAvailaibility
	 * 
	 * @param stHandle
	 * @param alSuggestHandles
	 * @param bInputHandleValid
	 * @return hmResult
	 */
	private Map<String, Object> addSugestedHandle(String stHandle, ArrayList alSuggestHandles,
			Boolean bInputHandleValid) {
		String sMethodName = ".addSugestedHandle.";
		Map<String, Object> hmResult = null;
		String stAppInfo;
		HashMap<String, String> hmSuggestedHandles = CommonUtil.getHashMap();

		for (int i = 0; i < alSuggestHandles.size(); i++) {
			HashMap temp = (HashMap) alSuggestHandles.get(i);

			String stSuggestedHandle = (String) temp.get(CommonDefs.SUGGEST);

			hmSuggestedHandles.put(CommonDefs.SUGGESTED_HANDLE + (i + 1), stSuggestedHandle);

			if (stSuggestedHandle.equals(stHandle)) {
				bInputHandleValid = true;
				break;
			}
		}
		if (Boolean.FALSE.equals(bInputHandleValid)) {
			stAppInfo = "Given userId is in use or invalid. Returning suggested handles";
			logger.info("{}{}AUH_107.1 : {}", sClassName, sMethodName, stAppInfo);
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_HANDLE_NUM, stAppInfo);
			hmResult.put(CommonDefs.SUGGESTLIST, hmSuggestedHandles);
		} else {
			stAppInfo = "bInputHandleValid flag is set to true";
			logger.info("{}{}AUH_107.2 : {}", sClassName, sMethodName, stAppInfo);
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
			hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		}
		return hmResult;
	}

	/**
	 * This method is used to validate the request for adding a user. It checks the
	 * transaction name, domain name, and handle, and sets the accessIdRTValidFlag
	 * and ignoreQay flag. It also sets the DB full name based on the first name and
	 * last name provided in the request. If the full name is not provided, it sets
	 * the full name as the handle. It also sets the PARENT_CHILD_IND flag based on
	 * whether the request is for a MID or not.
	 *
	 * @param hmInput A Map containing the necessary information about the user to
	 *                be added. This includes details like user ID, domain, contact
	 *                email, first name, last name, etc.
	 * @return A Map containing the result of the operation. This includes status
	 *         codes and messages indicating the success or failure of the
	 *         operation.
	 */
	public Map<String, Object> validateRequest(Map<String, Object> hmInput) {
		String sMethodName = ".validateRequest.";
		Map<String, Object> hmResult = null;
		Boolean isMIDInRequest = Optional.ofNullable((Boolean) hmInput.get("isMIDInRequest")).orElse(false);
		// Domain check in case its not accessId unless its opr request
		String stDomain = (String) hmInput.get(CommonDefs.DOMAIN);
		if (!isMIDInRequest) {
			if (stDomain == null || stDomain.isEmpty() || !stDomain.equalsIgnoreCase(CommonDefs.SLID_DUM)) {
				String stAppInfo = "Domain is null or not valid";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}AUH_101 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
		}
		hmResult = validateRequestTransactionName(hmInput);
		String stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

		if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
			return hmResult;
		}
		logger.debug(SpiMarker.getInstance(), "{}{}AUH_101.2.a :validateContactDetails with request: {}",
				StructuredArguments.entries(hmInput));
		logger.debug("{}{}AUH_101.2.b :validateContactDetails with isMIDInRequest :{}", isMIDInRequest);
		validateContactDetails(isMIDInRequest, hmInput);

		return hmResult;
	}

	/**
	 * This method validates the transaction name, domain name, and handle for the
	 * request to add a user. It sets the accessIdRTValidFlag and ignoreQay flag
	 * based on the validation results. If the original transaction name is not
	 * provided in the input map, it defaults to "ADD_USER_TRANSACTION_NAME". If the
	 * handle does not contain '@', it sets the accessIdRTValidFlag to 'N'. If the
	 * handle is in use or invalid, it sets the ignoreQay flag to 'Y'. If the handle
	 * is valid and not in use, it sets the ignoreQay flag to 'N'.
	 *
	 * @param hmInput A Map containing the necessary information about the user to
	 *                be added. This includes details like user ID, domain, contact
	 *                email, first name, last name, etc.
	 * @return A Map containing the result of the operation. This includes status
	 *         codes and messages indicating the success or failure of the
	 *         operation.
	 */
	public Map<String, Object> validateRequestTransactionName(Map<String, Object> hmInput) {
		String sMethodName = "validateRequestTransactionName";
		String stAppInfo = null;
		String stHandle = (String) hmInput.get(CommonDefs.HANDLE);
		String stOrigTransactionName = (String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME);

		if (stOrigTransactionName == null || stOrigTransactionName.isEmpty()) {
			hmInput.put(CommonDefs.ORIG_TRANSACTION_NAME, CommonDefs.ADD_USER_TRANSACTION_NAME);
			stOrigTransactionName = (String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME);
		}
		Map<String, Object> hmResult = null;
		if (CommonDefs.ADD_USER_TRANSACTION_NAME.equals(stOrigTransactionName)) {
			if (stHandle.contains("@")) {
				int len = stHandle.indexOf('@');
				if (len > -1) {
					String stTempDomain = stHandle.substring(len + 1);
					String stTempHandle = stHandle.substring(0, len);

					if (StringUtils.isBlank(stTempHandle) || StringUtils.isBlank(stTempDomain)) {
						stAppInfo = "Input slid is not in correct email format";
						logger.info("{}{}AUH_101.1 : {}", sClassName, sMethodName, stAppInfo);
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
						return hmResult;
					}
					hmResult = validateDomainName(stTempDomain);
					String stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

					if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
						return hmResult;
					}
					hmInput.put(CommonDefs.IGNORE_QAY, CommonDefs.IND_Y);
				}

			} else if (hmInput.get(CommonDefs.ACCESS_ID_RTV_VALID_FLAG) != null
					&& hmInput.get(CommonDefs.ACCESS_ID_RTV_VALID_FLAG).equals(CommonDefs.IND_Y)) {
				hmInput.put(CommonDefs.ACCESS_ID_RTV_VALID_FLAG, CommonDefs.IND_N);
			}

		}
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}

	private Map<String, Object> validateDomainName(String stTempDomain) {
		String stAppInfo = null;
		Map<String, Object> hmResult = null;
		String sMethodName = ".validateDomainName.";
		//commented as @value field can never be empty
//		if (propDBDomainList == null || propDBDomainList.isEmpty()) {
//			stAppInfo = "The value of RILHRS_ValidDomains is not configured in property files";
//			logger.debug("{}{}AUH_VR_02 : {}", sClassName, sMethodName, stAppInfo);
//			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
//			return hmResult;
//		}
		ArrayList alDBDomainList = CommonUtil.parseToArray(propDBDomainList, CommonDefs.VALUE_SEPARATOR_CHAR);

		logger.debug("{}{}AUH_VR_03 : Property RILHRS_ValidDomains :  {}", sClassName, sMethodName, alDBDomainList);

		if (alDBDomainList != null && alDBDomainList.contains(stTempDomain)) {
			stAppInfo = "External Domain cannot be same as ATT domain";
			logger.info("{}{}AUH_VR_04 : {}", sClassName, sMethodName, stAppInfo);
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, stAppInfo);
			return hmResult;
		}
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}

	public Map<String, Object> setPasswordValidationFlag(Map<String, Object> hmInput) {
		String sMethodName = ".setPasswordValidationFlag.";
		String stSkipPasswordValidationFlag = null;
		String stAppInfo = null;
		String stIsTempPassword = (String) hmInput.get("isTempPassword");
		String stCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

		ArrayList alskipPasswordValidationCSI = null;

		Map<String, Object> hmResult = null;

		if (stIsTempPassword != null && !stIsTempPassword.isEmpty()) {
			stIsTempPassword = stIsTempPassword.trim();
			hmInput.put(CommonDefs.SKIP_PASSWORD_VALIDATION, stIsTempPassword);
			hmInput.remove("isTempPassword");
		}

		if (!hmInput.containsKey(CommonDefs.SKIP_PASSWORD_VALIDATION)) {
			stSkipPasswordValidationFlag = CommonDefs.IND_N;

			//commented as @value field can never be empty
//			if (propSkipPasswordValidationCSI == null || propSkipPasswordValidationCSI.isEmpty()) {
//				stAppInfo = "The value of skipPasswordValidationCSI is not configured in property files";
//				logger.debug("{}{}AUH_110.1 : {}", sClassName, sMethodName, stAppInfo);
//				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
//				return hmResult;
//			}

			alskipPasswordValidationCSI = CommonUtil.parseToArray(propSkipPasswordValidationCSI,
					CommonDefs.VALUE_SEPARATOR_CHAR);

			logger.debug("{}{}AUH_110.2 : Property skipPasswordValidationCSI : {}", sClassName, sMethodName,
					alskipPasswordValidationCSI);

			if (alskipPasswordValidationCSI != null && alskipPasswordValidationCSI.contains(stCallingSystemId)) {
				stAppInfo = "Calling System Id : " + stCallingSystemId
						+ " does not need to do Password validation, setting stSkipPasswordValidation flag to Y.";
				stSkipPasswordValidationFlag = CommonDefs.IND_Y;
				logger.debug("{}{}AUH_110.3 : {}", sClassName, sMethodName, StringEscapeUtils.escapeJava(stAppInfo));
			}
			hmInput.put(CommonDefs.SKIP_PASSWORD_VALIDATION, stSkipPasswordValidationFlag);
		}

		if (hmInput.get(CommonDefs.SKIP_PASSWORD_VALIDATION) != null
				&& hmInput.get(CommonDefs.SKIP_PASSWORD_VALIDATION).equals(CommonDefs.IND_Y)) {
			hmInput.put(CommonDefs.PASSWORD_DIRTY, CommonDefs.IND_Y);
		}
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}

	/**
	 * This method is used to validate the contact details for adding a user. It
	 * sets the CONTACT_EMAIL_VALID, CONTACT_EMAIL_RTV_FLAG and PARENT_CHILD_IND
	 * flags. It also sets the DB full name based on the first name and last name
	 * provided in the request. If the full name is not provided, it sets the full
	 * name as the handle. It also sets the PARENT_CHILD_IND flag based on whether
	 * the request is for a MID or not.
	 *
	 * @param isMIDInRequest A Boolean indicating whether the request is for a MID
	 *                       or not.
	 * @param hmInput        A Map containing the necessary information about the
	 *                       user to be added. This includes details like user ID,
	 *                       domain, contact email, first name, last name, etc.
	 */
	public void validateContactDetails(Boolean isMIDInRequest, Map<String, Object> hmInput) {

		String sMethodName = ".validateContactDetails.";
		String stContactEmail = (String) hmInput.get(CommonDefs.CONTACT_EMAIL);
		String stHandle = (String) hmInput.get(CommonDefs.HANDLE);
		String sOrginTransactionName = (String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME);
		if (stContactEmail != null && !stContactEmail.isEmpty()) {
			String stContactEmailValid = CommonDefs.IND_Y;
			int pos = stContactEmail.indexOf('@');

			if (pos > 0) {
				String temp = stContactEmail.substring(pos + 1);
				if (temp.indexOf('.') <= 0)
					stContactEmailValid = CommonDefs.IND_N;
			} else {
				stContactEmailValid = CommonDefs.IND_N;
			}
			if (CommonDefs.IND_Y.equals(stContactEmailValid)) {
				hmInput.put(CommonDefs.CONTACT_EMAIL_VALID, CommonDefs.IND_Y);
			} else {
				hmInput.put(CommonDefs.CONTACT_EMAIL_VALID, CommonDefs.IND_N);
			}
		} else if (hmInput.get(CommonDefs.CONTACT_EMAIL_RTV_FLAG) != null
				&& hmInput.get(CommonDefs.CONTACT_EMAIL_RTV_FLAG).equals(CommonDefs.IND_Y)) {
			hmInput.put(CommonDefs.CONTACT_EMAIL_RTV_FLAG, CommonDefs.IND_N);
		}

		String stFullName = (String) hmInput.get(CommonDefs.FULLNAME);
		String stFirstName = (String) hmInput.get(CommonDefs.FIRST_NAME);
		String stLastName = (String) hmInput.get(CommonDefs.LAST_NAME);

		if (stFullName == null || stFullName.isEmpty()) {
			if ((stFirstName != null && !stFirstName.isEmpty()) && (stLastName != null && !stLastName.isEmpty())) {
				stFullName = stFirstName + " " + stLastName;
			} else {
				stFullName = stHandle + "@slid.dum";
			}
			hmInput.put(CommonDefs.DB_FULLNAME, stFullName);
		}

		if (isMIDInRequest) {
			if(sOrginTransactionName != null && sOrginTransactionName.equals(ProfileOrchestrationConstants.ADD_SEC_MEMBERID_TRANSACTION_NAME))
				hmInput.put(CommonDefs.PARENT_CHILD_IND, MPSDefs.MPS_CHILD);
			else
				hmInput.put(CommonDefs.PARENT_CHILD_IND, MPSDefs.MPS_PARENT);
		} else {
			hmInput.put(CommonDefs.PARENT_CHILD_IND, MPSDefs.MPS_SLID);
		}

		logger.info("{}{}AUH_101.3 :validateContactDetails successfully executed", sClassName, sMethodName);
	}

	public Map<String, Object> setVoltageEncryptedFields(Map<String, Object> hmInput) {
		String sMethodName = ".setVoltageEncryptedFields.";
		String stAppInfo = null;
		String stAppStatusCode = null;

		Map hmResult = null;

		hmResult = oProofingEncryption.getEncryptedValues((HashMap) hmInput);

		stAppInfo = "AddUserHelper.setVoltageEncryptedFields.AUH_112.2 : ResponseHash from ProofingEncryption_H.getEncryptedValues";
		logger.debug(SpiMarker.getInstance(), "{} : {}", stAppInfo, StructuredArguments.entries(hmResult));

		if (hmResult == null) {
			stAppInfo = "Null Response returned from ProofingEncryption_H.getEncryptedValues";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			logger.debug("{}{}AUH_112.3 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

		if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
			stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
			hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
			logger.info("{}{}AUH_112.4 : {}", sClassName, sMethodName, StringEscapeUtils.escapeJava(String.valueOf(stAppInfo)));
			return hmResult;

		}
		String stVencDateOfBirth = (String) hmResult.get(CommonDefs.VOLTAGE_DATE_OF_BIRTH);
		hmInput.put("VencDateOfBirth", stVencDateOfBirth);
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}

	/**
	 * This method is used to update the Terms of Service (TOS) flag and suppress
	 * the activation of the Access ID. It checks if the 'isAccessIdAutoGen' flag is
	 * set in the input map. If the flag is set, it sets the 'AUTO_GENERATED_IND'
	 * flag to 'Y' and checks if the calling system ID is in the list of system IDs
	 * that are allowed to suppress the activation of the Access ID. If the calling
	 * system ID is in the list, it sets the 'ACTIVATED_INDEX' flag to 'N'. It also
	 * sets the 'TOS_FLAG' to 'Y'. If the 'agentId' is provided in the input map, it
	 * sets the 'TOS_FLAG' to 'Y'.
	 *
	 * @param hmInput A Map containing the necessary information about the user and
	 *                the system making the request. This includes details like user
	 *                ID, domain, contact email, first name, last name, etc.
	 * @return A Map containing the result of the operation. This includes status
	 *         codes and messages indicating the success or failure of the
	 *         operation.
	 */
	public Map<String, Object> updateTOSFlagandSuppressAccessIdActivation(Map<String, Object> hmInput) {
		String sMethodName = ".updateTOSFlagandSuppressAccessIdActivation.";
		String stAppInfo = null;
		Map<String, Object> hmResult = null;
		ArrayList<String> alSuppressAccessIdActivationCSIs = null;

		//commented as @value field can never be empty
//		if (propSuppressAccessIdActivationCSIs == null || propSuppressAccessIdActivationCSIs.isEmpty()) {
//			stAppInfo = "The value of suppressAccessIdActivationCSIs is not configured in property files";
//			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
//			logger.info("{}{}AUH_115.1 : {}", sClassName, sMethodName, stAppInfo);
//			return hmResult;
//		}
		alSuppressAccessIdActivationCSIs = CommonUtil.parseToArray(propSuppressAccessIdActivationCSIs,
				CommonDefs.VALUE_SEPARATOR_CHAR);
		logger.debug("{}{}AUH_115.2 : suppressAccessIdActivationCSIs : {}", sClassName, sMethodName,
				alSuppressAccessIdActivationCSIs);

		String stAgentId = (String) hmInput.get(CommonDefs.AGENT_ID);
		String stIsAccessIdAutoGen = (String) hmInput.get(CommonDefs.IS_ACCESSS_ID_AUTOGEN);
		String stCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

		if (stIsAccessIdAutoGen != null && !stIsAccessIdAutoGen.isEmpty()
				&& stIsAccessIdAutoGen.equals(CommonDefs.IND_Y)) {

			hmInput.put(CommonDefs.AUTO_GENERATED_IND, CommonDefs.IND_Y);
			if (!alSuppressAccessIdActivationCSIs.contains(stCallingSystemId)) {
				hmInput.put(CommonDefs.ACTIVATED_INDEX, CommonDefs.IND_N);
			}
			hmInput.put(CommonDefs.TOS_FLAG, CommonDefs.IND_Y);
		}
		if (stAgentId != null && !stAgentId.isEmpty()) {
			hmInput.put(CommonDefs.TOS_FLAG, CommonDefs.IND_Y);
		}

		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}

	private static String getMailHost(String domain) {
		String mailHost = null;

		if (domain != null && (domain = domain.trim()).length() != 0) {
			int ind = domain.indexOf('.');
			String subDomain = domain.substring(0, ind);
			mailHost = "mx." + subDomain + ".yahoo.com";
		}
		return mailHost;
	}
}