package com.att.idp.idgraphusermanagementms.db.repository;

import java.sql.SQLException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.att.idp.idgraphusermanagementms.db.model.Tusermerge;


/**
 * This is the main repository interface for UserMerge related operations.
 * It extends JpaRepository for standard CRUD operations.
 * The entity associated with this repository is Tusermerge and the ID type is Long.
 */
@Repository
public interface UserMergeRepository extends JpaRepository<Tusermerge, Long>{

	/**
	 * This method is used to retrieve the user merge details by source member number.
	 *
	 * @param sourceMemberNum A Long representing the source member number for which the user merge details are to be retrieved.
	 * @return A List of Tusermerge objects containing the user merge details associated with the given source member number.
	 * @throws SQLException If there is an error while executing the SQL query.
	 */
	@Query(value  = "select t from Tusermerge t where t.sourceMemberNum=:sourceMemberNum")

	public List<Tusermerge> getUserMergeDetails(@Param(value = "sourceMemberNum") Long sourceMemberNum)
			throws SQLException;
}
