package com.att.idp.idgraphusermanagementms.resource.response;

import com.att.idp.core.exception.ServiceError;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.ArrayList;

/**
 * This class represents the response from the ResetUserPassword operation in the system.
 * It contains fields for transactionName, appStatusMsg, appStatusCode, appInfo, appCategoryCode, errors, idpTraceId, slid, generatedPassword.
 * Some fields are ignored during JSON serialization/deserialization.
 *
 * The class is annotated with @Data, @JsonIgnoreProperties, @JsonInclude, and @ApiModel from various libraries such as Jackson and Swagger.
 * The @Data annotation from Lombok library generates getter and setter methods for all fields.
 * The @JsonIgnoreProperties and @JsonInclude annotations from Jackson library control the JSON serialization/deserialization behavior.
 * The @ApiModel annotation from Swagger library provides metadata for the model definition in Swagger UI.
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "ResetUserPasswordResponse")
public class ResetUserPasswordResponse {
    @JsonIgnore
    private String transactionName = "ResetUserPassword";

    private String appStatusMsg;
    private String appStatusCode;
    private String appInfo;

    @JsonIgnore
    private String appCategoryCode;

    @JsonProperty("error")
    private ServiceError errors;
    private String idpTraceId;
    private String slid;
    private String generatedPassword;

    private ArrayList<LockList> LockList;

    @JsonProperty("error")
    public void setErrors(ServiceError errors) {
        this.errors = errors;
    }

    @JsonProperty("idp-trace-id")
    public void setIdpTraceId(String idpTraceId) {
        this.idpTraceId = idpTraceId;
    }

}
