package com.att.idp.idgraphusermanagementms.service.impl;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.DeleteUserHelper;
import com.att.idp.idgraphusermanagementms.resource.request.DeleteUserRequest;
import com.att.idp.idgraphusermanagementms.resource.response.DeleteUserResponse;
import com.att.idp.idgraphusermanagementms.service.DeleteUserService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;
import jakarta.ws.rs.core.MultivaluedMap;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

/**
 * Implementation of the DeleteUserService interface.
 * <p>
 * This class provides the business logic for deleting a user based on the
 * provided DeleteUserRequest and request headers. It interacts with the
 * DeleteUserHelper to process the deletion, handles input validation, logs the
 * operation details, and constructs the appropriate response.
 * <p>
 * The class is annotated with @Service to indicate that it is a Spring service
 * component and @Transactional to manage transaction boundaries for the delete
 * operation.
 */
@Service
@AllArgsConstructor
@Transactional(readOnly = true, value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class DeleteUserServiceImpl implements DeleteUserService {

    public static final Logger logger = LoggerFactory.getLogger(DeleteUserServiceImpl.class);
    private static final String CLASS_NAME = "DeleteUserServiceImpl";

    private final DeleteUserHelper deleteUserHelper;

    /**
     * Processes the deletion of a user based on the provided request and headers.
     * <p>
     * This method converts the DeleteUserRequest object into a map, logs the input
     * details, and invokes the DeleteUserHelper to perform the deletion. It
     * validates the response, handles errors, and constructs a DeleteUserResponse
     * object. If a rollback is required, it throws an InvalidInputDataException.
     *
     * @param deleteUserRequest The request object containing the details of the
     *                          user to be deleted.
     * @param requestHeader     The HTTP headers containing additional metadata for
     *                          the request.
     * @return A DeleteUserResponse object containing the result of the delete
     * operation.
     * @throws InvalidInputDataException If the operation requires a transaction
     *                                   rollback.
     */
    @Override
    public DeleteUserResponse deleteUser(DeleteUserRequest deleteUserRequest,
                                         MultivaluedMap<String, String> requestHeader) {

        DeleteUserResponse deleteUserResponse;

        Map<String, Object> hmResponse;
        String sMethodName = ".deleteUserResponse.";

        String idpTraceid = deleteUserRequest.getIdpTraceId();
        deleteUserRequest.setDbusTransactionId(idpTraceid.split(":")[0]);

        logger.info(SpiMarker.getInstance(), "{}{}DUSI.DU.01 : Calling deleteUserHelper with Input : {}", CLASS_NAME,
                sMethodName, CommonUtilHelper.sanitizeForLog(String.valueOf(deleteUserRequest)));

        hmResponse = deleteUserHelper.deleteUser(deleteUserRequest);
        logger.info("{}{}DUSI.DU.01 : Response from  DeleteUserHelper.deleteUserHelper : {}", CLASS_NAME, sMethodName,
                hmResponse);

        if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
            hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from DeleteUserHelper.deleteUserHelper");
            logger.info("{}{}DUSI.DU.02 : Null response from DeleteUserHelper.deleteUserHelper", CLASS_NAME,
                    sMethodName);
        } else {
            String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
            if (stAppStatusCode == null) {
                hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from DeleteUserHelper.deleteUserHelper");
                logger.info("{}{}DUSI.DU.03 : Null response from DeleteUserHelper.deleteUserHelper", CLASS_NAME,
                        sMethodName);
            }
        }

        hmResponse.put(CommonDefs.TRANSACTION_ID, deleteUserRequest.getIdpTraceId());
        hmResponse.put("idp-trace-id", deleteUserRequest.getIdpTraceId());
        hmResponse.put(CommonDefs.TRANSACTION_NAME, "DeleteUser");
        deleteUserResponse = CommonUtilHelper.generateDeleteUserResponse(hmResponse);

        String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

        if (sTxnRollBack != null) {
            throw new InvalidInputDataException(hmResponse);
        }

        logger.info("{}{}DUSI.DU.04 : Response from DeleteUserServiceImpl.deleteUser : {}", CLASS_NAME, sMethodName,
                deleteUserResponse);
        return deleteUserResponse;

    }

}
