package com.att.idp.idgraphusermanagementms.db.helper;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.mpsys.common.utils.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.util.*;

/**
 * This class is responsible for managing contact-related operations in the database.
 * It uses Spring's JdbcTemplate for database operations and has methods for updating, adding, and retrieving user contacts.
 * It also uses other helper classes like DBHelper and CommonUtil.
 *
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like JdbcTemplate and DBHelper.
 *
 * The class contains SQL queries as string constants for updating, adding, and retrieving user contacts.
 * These queries are used in the corresponding methods for these operations.
 *
 * The class also contains a logger for logging information and errors.
 *
 * The main methods in this class are:
 * - updateUserContact: This method updates a user's contact information in the database. It takes a HashMap as input and returns a HashMap as output.
 * - addUserContact: This method adds a user's contact information to the database. It takes a HashMap as input and returns a HashMap as output.
 * - getUserContact: This method retrieves a user's contact information from the database. It takes a HashMap as input and returns a HashMap as output.
 */
@Component
public class ContactDBHelper {
    public static final Logger logger = LoggerFactory.getLogger(ContactDBHelper.class);
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private DBHelper oDBHelper;

    @Autowired
    private ErrorMetricHandler errorMetricHandler;

    private static final String info = "$Id: master/com/att/custmgmt/cuin/cupf/dbhelpers/MPSDB_Contact_H.java v1 2020-01-21 sp7569 $;";
    private static final String sClassName = "ContactDBHelper";

    private static final ArrayList<Object> alUpdateKeys = CommonUtil.getArrayList();
    static {
        alUpdateKeys.add("contact_desc");
        alUpdateKeys.add("phone_number");
        alUpdateKeys.add("phone_ext");
        alUpdateKeys.add("subscription_id");
        alUpdateKeys.add("email_address");
        alUpdateKeys.add("contact_status");
        alUpdateKeys.add("phone_number_type");
        alUpdateKeys.add("validation_status");
        alUpdateKeys.add("atlas_last_timestamp");
    }

    private static final ArrayList<Object> alUpperCaseKeys = CommonUtil.getArrayList();
    static {
        alUpperCaseKeys.add("contact_status");
    }
    private Date dtStartDate = new Date();
    private java.sql.Date sysDate = new java.sql.Date(dtStartDate.getTime());

    private static final ArrayList<Object> alLowerCaseKeys = CommonUtil.getArrayList();
    static {
        alLowerCaseKeys.add("phone_number");
        alLowerCaseKeys.add("email_address");
    }
    
    /**
     * This method is responsible for updating a user's contact information in the database.
     * It takes a HashMap as an argument which contains the details of the user's contact to be updated.
     * The HashMap should contain the following keys:
     * - CommonDefs.CALLING_SYSTEM_ID: The identifier of the system calling this method.
     * - member_num: The member number.
     * - contact_id: The contact ID.
     * - contact_type: The type of the contact.
     * - phone_number: The phone number.
     * - email_address: The email address.
     * - contact_status: The status of the contact.
     * - contact_desc: The description of the contact.
     * - phone_ext: The phone extension.
     * - subscription_id: The subscription ID.
     * - phone_number_type: The type of the phone number.
     * - validation_status: The validation status.
     *
     * The method first logs the start of the operation and the input parameters.
     * It then checks if the necessary information is present in the input HashMap.
     * If any necessary information is missing, it logs an error and returns an error status.
     * Otherwise, it prepares the SQL query for updating the contact and executes it using the jdbcTemplate object.
     * If the operation is successful, the method returns a HashMap containing the status of the operation.
     * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
     *
     * @param hmInput A HashMap containing the details of the user's contact to be updated.
     * @return A HashMap containing the status of the operation.
     */
    public Map<String, Object> updateUserContact(HashMap hmInput) { {
        String sMethodName = ".updateUserContact.";

        HashMap<String, Object> hmResult = null;
        String stAppInfo = null;
        List<Object> objectList = new ArrayList<Object>();

        StringBuilder updateContactSql = new StringBuilder("UPDATE contact SET ");
        String sWhereClause = "";

        logger.info("{}{}DB_UC_01 : CVS KEYWORDS: {}", sClassName, sMethodName, info);
        logger.info("{}{}DBTOOLS000 : Input Hash : {}", sClassName, sMethodName, hmInput);

        Date dtStart = new Date();

        try {
            String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
            String sUpdateEstablishedDate = (String) hmInput.get("updateEstablishedDate");
            String sValidationStatusDateFlag = (String) hmInput.get("validation_status_date_flag");
            String sMemberNum = (String) hmInput.get("member_num");
            String sContactType = (String) hmInput.get("contact_type");

            if (sCallingSystemId == null || sCallingSystemId.trim().length() == 0) {
                stAppInfo = "callingSystemId is null or empty in input";
                hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                logger.info("{}{}DB_UC_02 : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }

            sContactType = sContactType.toUpperCase().trim();

            if (sMemberNum != null && !sMemberNum.isEmpty() &&
                    sContactType != null && !sContactType.isEmpty()) {
                sWhereClause = " WHERE MEMBER_NUM = ? AND CONTACT_TYPE = ?";
            }

            String key = null;
            String value = null;

            for (Iterator iter = hmInput.keySet().iterator(); iter.hasNext();) {
                key = (String) iter.next();
                value = (String) hmInput.get(key);

                if (key != null && alUpdateKeys.contains(key) && value != null) {
                    updateContactSql.append(key.toUpperCase() + " = ? , ");
                }
            }

            if (sValidationStatusDateFlag != null) {
                if (sValidationStatusDateFlag.equals(MPSDefs.YES)) {
                    updateContactSql.append("VALIDATION_STATUS_DATE" + " = SYSDATE, ");
                } else if (sValidationStatusDateFlag.equals(MPSDefs.NO)) {
                    updateContactSql.append("VALIDATION_STATUS_DATE" + " = '', ");
                }
            }

            String stValidationStatus = (String) hmInput.get(MPSDefs.DB_VALIDATION_STATUS);
            if (hmInput.containsKey(MPSDefs.DB_VALIDATION_STATUS)
                    && (stValidationStatus == null || stValidationStatus.isEmpty())) {
                updateContactSql.append("VALIDATION_STATUS" + " = '', ");
            }

            if (sUpdateEstablishedDate == null || (!sUpdateEstablishedDate.equalsIgnoreCase("N"))) {
                updateContactSql.append("ESTABLISHED_DATE" + " = SYSDATE, ");
            }

            updateContactSql.append("LAST_MODIFIED_BY = ? ");
            updateContactSql.append(sWhereClause);

            logger.info("{}{}SQL999 : SQL Query = {}", sClassName, sMethodName, updateContactSql);

            int i = 0;
            for (Iterator iter = hmInput.keySet().iterator(); iter.hasNext();) {
                key = (String) iter.next();
                value = (String) hmInput.get(key);

                if (key != null && alUpdateKeys.contains(key) && value != null) {
                    if (alUpperCaseKeys.contains(key)) {
                        value = value.trim().toUpperCase();
                    } else if (alLowerCaseKeys.contains(key)) {
                        value = value.trim().toLowerCase();
                    }
                    objectList.add(value);
                }
            }

            objectList.add(sCallingSystemId);

            if (sMemberNum != null && !sMemberNum.isEmpty() &&
                    sContactType != null && !sContactType.isEmpty()) {
                objectList.add(Long.parseLong(sMemberNum));
                objectList.add(sContactType);
            }

            int rowCount = jdbcTemplate.update(new String(updateContactSql),
                    objectList.toArray(new Object[objectList.size()]));

            logger.info("{}{}DB_UC_03 : Number of rows updated:= {}", sClassName, sMethodName, rowCount);

            if (rowCount == 0) {
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
                        "No Record found for given contact_id");
            } else {
                hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                        "Number of records updated=" + rowCount);
            }

        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            hmResult = StatusMsg.makeExceptionSQLStatus(e);
            logger.error("{}{}DBHLPE01 : Error:: {}", sClassName, sMethodName, e.getMessage());
            logger.error("{}{}DBHLPE02 : Exception = {}", sClassName, sMethodName, e);

        } finally {
            logger.info("{}{}DBHLP999 response : {}", sClassName, sMethodName, hmResult);
        }
        return hmResult;
    }
}

    /**
     * This method is responsible for adding a user's contact information to the database.
     * It takes a HashMap as an argument which contains the details of the user's contact to be added.
     * The HashMap should contain the following keys:
     * - CommonDefs.CALLING_SYSTEM_ID: The identifier of the system calling this method.
     * - member_num: The member number.
     * - contact_id: The contact ID.
     * - contact_type: The type of the contact.
     * - phone_number: The phone number.
     * - email_address: The email address.
     * - contact_status: The status of the contact.
     * - contact_desc: The description of the contact.
     * - phone_ext: The phone extension.
     * - subscription_id: The subscription ID.
     * - phone_number_type: The type of the phone number.
     * - validation_status: The validation status.
     *
     * The method first logs the start of the operation and the input parameters.
     * It then checks if the necessary information is present in the input HashMap.
     * If any necessary information is missing, it logs an error and returns an error status.
     * Otherwise, it prepares the SQL query for adding the contact and executes it using the jdbcTemplate object.
     * If the operation is successful, the method returns a HashMap containing the status of the operation.
     * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
     *
     * @param hmContactData A HashMap containing the details of the user's contact to be added.
     * @return A HashMap containing the status of the operation.
     */
    public Map<String, Object> addUserContact(HashMap<String, Object>hmContactData) {
        String sMethodName = ".addUserContact.";

        HashMap<String, Object> hmResult = null;
        String stAppInfo = null;
        List<Object> objectList = new ArrayList<Object>();

        String addContactSql = "INSERT INTO contact(" + "CONTACT_ID, " + "MEMBER_NUM, " + "CONTACT_TYPE, "
                + "CONTACT_DESC, " + "PHONE_NUMBER, " + "PHONE_EXT, " + "SUBSCRIPTION_ID, " + "EMAIL_ADDRESS, "
                + "CONTACT_STATUS, " + "ESTABLISHED_DATE, " + "CREATED_BY, " + "LAST_MODIFIED_BY, "
                + "PHONE_NUMBER_TYPE, VALIDATION_STATUS, VALIDATION_STATUS_DATE " + ") VALUES("
                + "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        logger.info("{}{}DBTOOLS000 : Input Hash : {}{}", sClassName, sMethodName,info, hmContactData);

        Date dtStart = new Date();

        try {
            String stCallingSystemId = (String) hmContactData.get(CommonDefs.CALLING_SYSTEM_ID);
            String sMemberNum = (String) hmContactData.get("member_num");
            String sContactId = (String) hmContactData.get("contact_id");
            String sContactType = (String) hmContactData.get("contact_type");
            String sPhoneNumber = (String) hmContactData.get("phone_number");
            String sEmailAddress = (String) hmContactData.get("email_address");
            String sContactStatus = (String) hmContactData.get("contact_status");
            String sContactDesc = (String) hmContactData.get("contact_desc");
            String sPhoneExt = (String) hmContactData.get("phone_ext");
            String sSubscriptionId = (String) hmContactData.get("subscription_id");
            String sPhoneNumberType = (String) hmContactData.get("phone_number_type");
            String sValidationStatus = (String) hmContactData.get("validation_status");

            if (stCallingSystemId == null || stCallingSystemId.trim().isEmpty() || sMemberNum == null
                    || sMemberNum.trim().isEmpty() || sContactId == null || sContactId.trim().isEmpty()
                    || sContactType == null || sContactType.trim().isEmpty()) {
                stAppInfo = "callingSystemId/member_num/contact_id/contact_type is null or empty in input";
                hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                logger.info("{}{}DB_AC_03 : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }

            if (((sPhoneNumber == null || sPhoneNumber.isEmpty()) && (sEmailAddress == null || sEmailAddress.isEmpty()))
                    || ((sPhoneNumber != null && !sPhoneNumber.isEmpty())
                    && (sEmailAddress != null && !sEmailAddress.isEmpty()))) {
                stAppInfo = "phone_number and email_address cannot be both null or present at the same time";
                hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                logger.info("{}{}DB_AC_04 : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }

            sContactType = sContactType.toUpperCase().trim();

            if (sContactStatus != null && !sContactStatus.isEmpty()) {
                sContactStatus = sContactStatus.toUpperCase().trim();
            } else {
                sContactStatus = "V";
            }

            long member_num = Long.parseLong(sMemberNum);
            long contact_id = Long.parseLong(sContactId);

            logger.info("{}{}SQL000 : addContactSql : {}", sClassName, sMethodName, addContactSql);

            objectList.add(contact_id);
            objectList.add(member_num);
            objectList.add(sContactType);

            if (sContactDesc != null) {
                objectList.add(sContactDesc);
                logger.debug("{}{}DB_AC_05 : sContactDesc::PARAM 4 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sContactDesc)));
            } else {
                objectList.add(null);
                logger.debug("{}{}DB_AC_05 : sContactDesc is nNULL::PARAM 4", sClassName, sMethodName);
            }

            if (sPhoneNumber != null) {
                sPhoneNumber = sPhoneNumber.trim().toLowerCase();
                objectList.add(sPhoneNumber);
                logger.debug("{}{}DB_AC_06 : sPhoneNumber::PARAM 5 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sPhoneNumber)));
            } else {
                objectList.add(null);
                logger.debug("{}{}DB_AC_06 : sPhoneNumber is Null::PARAM 5", sClassName, sMethodName);
            }

            if (sPhoneExt != null) {
                objectList.add(sPhoneExt);
                logger.debug("{}{}DB_AC_07 : sPhoneExt::PARAM 6 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(sPhoneExt));
            } else {
                objectList.add(null);
                logger.debug("{}{}DB_AC_07 : sPhoneExt is null::PARAM 6", sClassName, sMethodName);
            }

            if (sSubscriptionId != null) {
                objectList.add(sSubscriptionId);
                logger.debug("{}{}DB_AC_08 : sSubscriptionId::PARAM 7 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(sSubscriptionId));
            } else {
                objectList.add(null);
                logger.debug("{}{}DB_AC_08 : sSubscriptionId is Null::PARAM 7", sClassName, sMethodName);
            }

            if (sEmailAddress != null) {
                sEmailAddress = sEmailAddress.trim().toLowerCase();
                objectList.add(sEmailAddress);
                logger.debug("{}{}DB_AC_09 : sEmailAddress::PARAM 8 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(sEmailAddress));
            } else {
                objectList.add(null);
                logger.debug("{}{}DB_AC_09 : sEmailAddress is Null::PARAM 8 ", sClassName, sMethodName);
            }

            objectList.add(sContactStatus);
            logger.debug("{}{}DB_AC_10 : sContactStatus::PARAM 9 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(sContactStatus));
            objectList.add(sysDate); //ESTABLISHED_DATE
            objectList.add(stCallingSystemId); //CREATED_BY
            logger.debug("{}{}DB_AC_11 : stCallingSystemId::PARAM 10 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(stCallingSystemId));
            objectList.add(stCallingSystemId); //LAST_MODIFIED_BY
            if (sPhoneNumberType != null && !sPhoneNumberType.isEmpty()) {
                objectList.add(sPhoneNumberType);
                logger.debug("{}{}DB_AC_12 : sPhoneNumberType::PARAM 12 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(sPhoneNumberType));
            } else {
                objectList.add(null);
                logger.debug("{}{}DB_AC_12 : sPhoneNumberType is null::PARAM 12", sClassName, sMethodName);
            }

            if (sValidationStatus != null && !sValidationStatus.isEmpty()) {
                sysDate = new java.sql.Date(dtStartDate.getTime());
                objectList.add(sValidationStatus);
                logger.debug("{}{}DB_AC_13 : sValidationStatus::PARAM 13 = {}", sClassName, sMethodName,
                        HtmlUtils.htmlEscape(String.valueOf(sValidationStatus)));
                objectList.add(sysDate);
                logger.debug("{}{}DB_AC_14 : sysDate::PARAM 14 = {}", sClassName, sMethodName, sysDate);
            } else {
                objectList.add(null);
                if (sValidationStatus != null) {
                    logger.debug("{}{}DB_AC_13 : sValidationStatus::PARAM 13 = {}", sClassName, sMethodName,
                            HtmlUtils.htmlEscape(sValidationStatus));
                }
                objectList.add(null);
                logger.debug("{}{}DB_AC_14 : sysDate::PARAM 14 = {}", sClassName, sMethodName, sysDate);
            }

            int rowCount = jdbcTemplate.update(addContactSql,
                    objectList.toArray(new Object[0]));

            hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                    "Number of rows inserted:= " + rowCount);

            logger.info("{}{}DB_AC_10 : Number of rows inserted:= {}", sClassName, sMethodName, rowCount);

        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            hmResult = StatusMsg.makeExceptionSQLStatus(e);
            logger.error("{}{}DBHLPE01 : Error:: {}", sClassName, sMethodName, e.getMessage());

        } finally {
            logger.info("{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);
        }
        return hmResult;
    }

    /**
     * This method is responsible for retrieving a user's contact information from the database.
     * It takes a HashMap as an argument which contains the details of the user's contact to be retrieved.
     * The HashMap should contain the following keys:
     * - contact_id: The contact ID.
     * - member_num: The member number.
     * - contact_type: The type of the contact.
     * - subscription_id: The subscription ID.
     *
     * The method first logs the start of the operation and the input parameters.
     * It then checks if the necessary information is present in the input HashMap.
     * If any necessary information is missing, it logs an error and returns an error status.
     * Otherwise, it prepares the SQL query for retrieving the contact and executes it using the jdbcTemplate object.
     * If the operation is successful, the method returns a HashMap containing the status of the operation and the retrieved contact information.
     * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
     *
     * @param hmContactData A HashMap containing the details of the user's contact to be retrieved.
     * @return A HashMap containing the status of the operation and the retrieved contact information.
     */
    public Map<String, Object> getUserContact(HashMap<String, Object> hmContactData) {
        String sMethodName = ".getUserContact.";

        HashMap<String, Object> hmResult = null;
        String stAppInfo = null;
        String dateFormat = "MMDDYYYY HH24:mi:ss";
        List<Object> objectList = new ArrayList<Object>();
        List alQueryResponse = null;

        String getContactSql = "SELECT CONTACT_ID, MEMBER_NUM, "
                + "CONTACT_TYPE, CONTACT_DESC, PHONE_NUMBER, PHONE_EXT, PHONE_NUMBER_TYPE, "
                + "SUBSCRIPTION_ID, EMAIL_ADDRESS, CONTACT_STATUS, TO_CHAR(ESTABLISHED_DATE, '" + dateFormat
                + "') AS ESTABLISHED_DATE, TO_CHAR(CREATE_DATE, '" + dateFormat
                + "') AS CREATE_DATE, CREATED_BY, TO_CHAR(LAST_MODIFIED, '" + dateFormat
                + "') AS LAST_MODIFIED, TO_CHAR(VALIDATION_STATUS_DATE, '" + dateFormat
                + "') AS VALIDATION_STATUS_DATE, VALIDATION_STATUS, LAST_MODIFIED_BY " + "FROM contact ";

        String sWhereClause = null;

        logger.info("{}{}DBTOOLS000 : Input Hash : {}{}", sClassName, sMethodName, info,hmContactData);

        try {
            String sContactId = (String) hmContactData.get("contact_id");
            String sMemberNum = (String) hmContactData.get("member_num");
            String sContactType = (String) hmContactData.get("contact_type");
            String sSubscriptionId = (String) hmContactData.get("subscription_id");

            if ((sContactId == null || sContactId.trim().isEmpty())
                    && (sMemberNum == null || sMemberNum.trim().isEmpty())
                    && (sSubscriptionId == null || sSubscriptionId.trim().isEmpty())) {
                stAppInfo = "contact_id and member_num and subscription_id all are null or empty in input";
                hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                logger.info("{}{}DB_GC_03 : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }

            if (sContactType != null && !sContactType.isEmpty()) {
                sContactType = sContactType.toUpperCase().trim();
            }

			 if (sContactType != null && !sContactType.isEmpty() && sMemberNum != null && !sMemberNum.isEmpty()) {
                sWhereClause = " WHERE MEMBER_NUM = ? AND CONTACT_TYPE = ?";
                getContactSql = getContactSql + sWhereClause;
                logger.info("{}{}SQL000 : getContactSql : {}", sClassName, sMethodName, getContactSql);
                objectList.add(sMemberNum);
                objectList.add(sContactType);
            } else if (sMemberNum != null && !sMemberNum.isEmpty()) {
                sWhereClause = " WHERE MEMBER_NUM = ?";
                getContactSql = getContactSql + sWhereClause;
                logger.info("{}{}SQL000 : getContactSql : {}", sClassName, sMethodName, getContactSql);
                objectList.add(sMemberNum);
            }

            alQueryResponse = jdbcTemplate.queryForList(new String(getContactSql),
                    objectList.toArray(new Object[objectList.size()]));

            if (alQueryResponse != null && !alQueryResponse.isEmpty()) {
                ArrayList<Object> alContactList = CommonUtil.getArrayList();
                HashMap<String, Object> hmContacts = CommonUtil.getHashMap();
                //int numRowsFound = 0;

                for (Object alQueryResponseObject : alQueryResponse) {
                    Map hmQueryResponse = (Map) alQueryResponseObject;

                    for (Object hmQueryResponseObj : hmQueryResponse.keySet()) {
                        String key = (String) hmQueryResponseObj;
                        Object value = hmQueryResponse.get(key);
                        String strValue = (value == null ? null : value.toString());
                        hmContacts.put(key.toLowerCase(), strValue);
                    }

                    String validation_status = (String) hmContacts.get("validation_status");

                    if (validation_status != null) {
                        String validation_status_name = oDBHelper.getStatusNameByCode(Integer.parseInt(validation_status));
                        hmContacts.put("validation_status_name", validation_status_name);
                    }

                    alContactList.add(hmContacts);
                    //++numRowsFound;
                }

                logger.info("{}{}DBTOOLS09.1 : Number of rows found : {}", sClassName, sMethodName, alContactList.size());
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS);
                hmResult.put("contacts", alContactList);

            } else {
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
                        CErrorDefs.ERR_REC_NOT_FOUND_MSG);
                logger.info("{}{}DBTOOLS05 : No rows found", sClassName, sMethodName);
                return hmResult;
            }

        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            hmResult = StatusMsg.makeExceptionSQLStatus(e);
            logger.error("{}{}DBHLPE01 : Error:: {}", sClassName, sMethodName, e.getMessage());
        } finally {
            logger.info("{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);
        }
        return hmResult;
    }
}
