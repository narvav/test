package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class TpendingactionId implements java.io.Serializable {

	private static final long serialVersionUID = 103178161040105061L;

	@Column(name = "APPLICATION_NAME", nullable = false, length = 30)
	private String applicationName;

	@Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)
	private Long memberNum;


	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TpendingactionId))
			return false;
		TpendingactionId castOther = (TpendingactionId) other;

		return ((this.getApplicationName() == castOther.getApplicationName())
				|| (this.getApplicationName() != null && castOther.getApplicationName() != null
				&& this.getApplicationName().equals(castOther.getApplicationName())))
				&& ((this.getMemberNum() == castOther.getMemberNum()) || (this.getMemberNum() != null
				&& castOther.getMemberNum() != null && this.getMemberNum().equals(castOther.getMemberNum())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getApplicationName() == null ? 0 : this.getApplicationName().hashCode());
		result = 37 * result + (getMemberNum() == null ? 0 : this.getMemberNum().hashCode());
		return result;
	}
}