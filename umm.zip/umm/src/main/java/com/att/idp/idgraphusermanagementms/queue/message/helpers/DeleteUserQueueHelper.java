package com.att.idp.idgraphusermanagementms.queue.message.helpers;

import com.att.idp.idgraphusermanagementms.queue.message.sender.JMSQueueSender;
import com.att.idp.idgraphusermanagementms.resource.request.DeleteUserRequest;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.helpers.FeatureManagerHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Helper component responsible for building DBUS payloads and sending
 * delete-user related events to the backend JMS queue.
 * <p>
 * This class prepares message payloads for delete member or alias operations
 * based on member details and the {@link DeleteUserRequest}, invokes
 * {@link JMSQueueSender} to send messages to MQ, and normalizes responses into
 * standard application status maps using {@link CommonErrorMap}.
 * <p>
 * It is configured as a Spring {@code @Component} and loads configuration from
 * {@code userMgmt.properties}.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class DeleteUserQueueHelper {

    public static final Logger log = LoggerFactory.getLogger(DeleteUserQueueHelper.class);
    private static final String ERROR_ENUM = "ErrorEnum";
    private static final String DELETE_MEMBER_AEH_FEATURE_KEY = "cfg-idgraph-deleteuser-mq-aeh-switch";
    private static final String DELETE_MEMBER_CLM_FEATURE_KEY = "cfg-idgraph-deleteuser-notification-clm-switch";

    @Value("${DELETE_SLID_CGATE_SUBEVENT}")
    private String propDeleteCGateSubEvent;
    private static final String  sClassName = "DeleteUserQueueHelper";

    @Autowired
    private PublishMqAehHelper publishMqAehHelper;
    @Autowired
    private FeatureManagerHelper featureManager;



    /**
     * Sends a delete-user related message to MQ via {@link JMSQueueSender}.
     * <p>
     * The method builds a DBUS input map using the provided member details,
     * event data and {@link DeleteUserRequest}, optionally adds a CGate filter
     * flag, and delegates to the JMS queue sender. The response is interpreted
     * and converted into a standardized application map:
     * <ul>
     *     <li>If the response is null or empty, a system application error map is returned.</li>
     *     <li>If the response status code is not success, an error map is returned with
     *     that status code and message.</li>
     *     <li>On success, a success category map is returned with a standard success
     *     message and {@code ErrorEnum}.</li>
     * </ul>
     *
     * @param hmMemberDetails map containing member and SLID member numbers used
     *                        to determine the main hash key
     * @param alEventData     list of event data objects to be included as
     *                        {@code EVENTS_DATA} in the DBUS input
     * @param deleteUserReq   the delete user request providing transaction ID,
     *                        calling system ID and transaction name
     * @param bFilterCGate    whether to include the {@code filtercGate} flag in
     *                        the DBUS input for CGate-specific behavior
     * @return a result map containing application status code/info and, on success,
     *         additional flags such as {@code isTransactionRollback}
     */
    public Map<String, Object> sendMessageToMQ(Map<String, Object> hmMemberDetails,
                                               ArrayList<Map<String, Object>> alEventData,
                                               DeleteUserRequest deleteUserReq,
                                               boolean bFilterCGate) {
        String sMethodName = ".sendMessageToMQ.";
        String stAppInfo;
        String stAppStatusCode = null;

        final String AEH = "AEH";
        final String MQ = "MQ";
        final String BOTH = "BOTH";

        Map<String, Object> hmResult = CommonUtil.getHashMap();
        Map<String, Object> hmDbusInput = CommonUtil.getHashMap();

        String sMemberNum = (String) hmMemberDetails.get(MPSDefs.DB_MEMBER_NUM);
        String sSlidMemberNum = (String) hmMemberDetails.get(MPSDefs.DB_SLID_MEMBER_NUM);

        if (sSlidMemberNum == null) {
            hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, sMemberNum);
        } else {
            hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, sSlidMemberNum);
        }

        hmDbusInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
        hmDbusInput.put(CommonDefs.TRANSACTION_ID, deleteUserReq.getDbusTransactionId());
        hmDbusInput.put(CommonDefs.TRANSACTION_NAME, "DeleteMemberGeneric");
        hmDbusInput.put(CommonDefs.CALLING_SYSTEM_ID, deleteUserReq.getCallingSystemId());
        hmDbusInput.put(CommonDefs.EVENTNAME, CommonDefs.MICRO_SERVICE_EVENT);
        hmDbusInput.put(CommonDefs.MS_OPERTAION, deleteUserReq.getTransactionName());
        hmDbusInput.put(CommonDefs.EVENTS_DATA, alEventData);
        if (bFilterCGate) {
            hmDbusInput.put("filtercGate", CommonDefs.IND_Y);
        }

        log.info(SpiMarker.getInstance(),
                "DeleteUserQueueHelper.sendMessageToMQ.DUQH_01 : Calling JMSQueueSender with inputHash : {}",
                hmDbusInput);

        @SuppressWarnings("unchecked")
        //Map<String, Object> response = (Map<String, Object>) oJMSQueueSender.send(hmDbusInput);

        //mq aeh switch
        String sDeleteUserMQAEHEnabled = featureManager.getValue(DELETE_MEMBER_AEH_FEATURE_KEY);
        sDeleteUserMQAEHEnabled = (sDeleteUserMQAEHEnabled != null && !sDeleteUserMQAEHEnabled.isEmpty()) ? sDeleteUserMQAEHEnabled : MQ;
        log.info("{}{} ixp flag sDeleteUserMQAEHEnabled MQ AEH Value: {}", sClassName, sMethodName, sDeleteUserMQAEHEnabled);

        //clm switch
        String sDeleteUserClmEnabled = featureManager.getValue(DELETE_MEMBER_CLM_FEATURE_KEY);
        sDeleteUserClmEnabled = (sDeleteUserClmEnabled != null && !sDeleteUserClmEnabled.isEmpty()) ? sDeleteUserClmEnabled : MQ;
        log.info("{}{} ixp flag sDeleteUserClmEnabled CLM Value: {}", sClassName,sMethodName, sDeleteUserClmEnabled);

        Map<String, Object> hmInput = CommonUtilHelper.objectToMap(deleteUserReq);

        hmResult = publishMqAehHelper.invokeMqAEH(hmDbusInput,hmInput, alEventData, sClassName, sMethodName, sDeleteUserMQAEHEnabled, sDeleteUserClmEnabled);


        log.info("{}{}DUQH_02 : ResponseHash from JMSQueueSender : {}", sClassName, sMethodName,
                HtmlUtils.htmlEscape(String.valueOf(hmResult)));

        if (MapUtils.isEmpty(hmResult)) {
            stAppInfo = "Null Response returned from JMSQueueSender.send";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
            log.info("{}{}DUQH_03 : {}", sClassName, sMethodName, stAppInfo);
            return hmResult;
        }

        stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

        if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {

            stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
            log.info("{}{}DUQH_04 : {}", sClassName, sMethodName,
                    HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
            hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
            return hmResult;
        } else {
            hmResult.put("isTransactionRollback", Boolean.TRUE);
        }

        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
        hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
        return hmResult;

    }


    /**
     * Prepares a DBUS input payload list for delete-user operations based on the
     * requested context.
     * <p>
     * Depending on the {@code context}, this method constructs DBUS input maps
     * for:
     * <ul>
     *     <li>Alias deletion ({@link CommonDefs#DELETE_ALIAS})</li>
     *     <li>Alias detach ({@link CommonDefs#KEY_DETACH_ALIAS})</li>
     *     <li>Delete member list operations ({@link CommonDefs#CONTEXT_DeleteMemberList})</li>
     * </ul>
     * The resulting map contains the consolidated DBUS input under
     * {@link CommonDefs#CONSOLIDATED_DBUS_INPUT} when applicable, or an empty
     * success map for unsupported contexts.
     *
     * @param deleteUserReq     the delete user request driving the transaction
     *                          context
     * @param memberDetails     the member details map containing SLID and group
     *                          information and nested SLID info
     * @param context           the operation context (e.g. delete alias, detach
     *                          alias, delete member list)
     * @param slidDeleteInInput flag indicating whether SLID delete information
     *                          is already present in the input
     * @return a map containing either an empty success category map or a map with
     *         {@link CommonDefs#CONSOLIDATED_DBUS_INPUT} holding the DBUS payload
     */
    @SuppressWarnings("unchecked")
    public Map<String, Object> prepareDbusList(DeleteUserRequest deleteUserReq, Map<String, Object> memberDetails,
                                               String context, boolean slidDeleteInInput) {
        Map<String, Object> result = CommonUtil.getHashMap();
        Map<String, Object> dbusInput = CommonUtil.getHashMap();

        String slidMemberNum = getString(memberDetails, MPSDefs.DB_SLID_MEMBER_NUM);
        String groupNum = getString(memberDetails, MPSDefs.DB_GROUP_NUM);
        Map<String, Object> slidInfo = getMap(memberDetails, MPSDefs.KEY_SLID_INFO);
        String handle = getString(slidInfo, MPSDefs.DB_MEMBER_NAME);
        String domain = getString(slidInfo, MPSDefs.DB_DOMAIN_NAME);

        switch (context) {
            case CommonDefs.DELETE_ALIAS:
                return handleAliasEvent(deleteUserReq, slidMemberNum, groupNum, slidInfo, handle, domain, slidDeleteInInput,
                        CommonDefs.DELETE_ALIAS, "UpdateAliasList", "deleteAlias", result, dbusInput);

            case CommonDefs.KEY_DETACH_ALIAS:
                return handleAliasEvent(deleteUserReq, slidMemberNum, groupNum, slidInfo, handle, domain, slidDeleteInInput,
                        CommonDefs.KEY_DETACH_ALIAS, "UpdateAliasList", CommonDefs.KEY_DETACH_ALIAS, result, dbusInput);

            case CommonDefs.CONTEXT_DeleteMemberList:
                return handleDeleteMemberList(deleteUserReq, slidMemberNum, groupNum, slidInfo, handle, slidDeleteInInput,
                        result, dbusInput);

            default:
                return result;
        }
    }

    private Map<String, Object> handleAliasEvent(DeleteUserRequest req, String slidMemberNum, String groupNum,
                                                 Map<String, Object> slidInfo, String handle, String domain, boolean slidDeleteInInput, String context,
                                                 String event, String subEvent, Map<String, Object> result, Map<String, Object> dbusInput) {
        if (event == null || event.equals(CommonDefs.DBUS_EVENT_NONE)) {
            return CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "");
        }

        populateCommonDbusFields(dbusInput, req, event, handle, domain, slidDeleteInInput, groupNum, slidMemberNum);

        if (hasLinkedUsers(slidInfo)) {
            List<Map<String, Object>> aliasList = new ArrayList<>();
            Map<String, Object> alias = CommonUtil.getHashMap();
            alias.put(CommonDefs.HANDLE, req.getHandle());
            alias.put(CommonDefs.DOMAIN, req.getDomain());
            aliasList.add(alias);
            dbusInput.put(subEvent, aliasList);

            result = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "");
            result.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, dbusInput);
            return result;
        }
        return CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "");
    }

    private Map<String, Object> handleDeleteMemberList(DeleteUserRequest req, String slidMemberNum, String groupNum,
                                                       Map<String, Object> slidInfo, String handle, boolean slidDeleteInInput, Map<String, Object> hmResult,
                                                       Map<String, Object> dbusInput) {
        String deleteMemberListEvent = "DeleteMemberList";
        String subEvent = propDeleteCGateSubEvent;

        if (deleteMemberListEvent == null || deleteMemberListEvent.equals(CommonDefs.DBUS_EVENT_NONE)) {
            return CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "");
        }

        populateCommonDbusFields(dbusInput, req, deleteMemberListEvent, handle, CommonDefs.SLID_DUM, slidDeleteInInput,
                groupNum, slidMemberNum);
        dbusInput.put(CommonDefs.SUBEVENT, subEvent);

        List<Map<String, Object>> memberList = new ArrayList<>();
        Map<String, Object> member = CommonUtil.getHashMap();
        member.put(MPSDefs.DB_MEMBER_NUM, getString(slidInfo, MPSDefs.DB_MEMBER_NUM));
        member.put(CommonDefs.HANDLE, handle);
        member.put(CommonDefs.DOMAIN, CommonDefs.SLID_DUM);
        member.put(MPSDefs.DB_PARENT_CHILD_IND, getString(slidInfo, MPSDefs.DB_PARENT_CHILD_IND));
        member.put(CommonDefs.SOR_NAME, getString(slidInfo, MPSDefs.DB_SOR_NAME));
        memberList.add(member);
        dbusInput.put(CommonDefs.MEMBER_INFO, memberList);

        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "");
        hmResult.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, dbusInput);
        return hmResult;
    }

    private void populateCommonDbusFields(Map<String, Object> dbusInput, DeleteUserRequest req, String event,
                                          String handle, String domain, boolean slidDeleteInInput, String groupNum, String slidMemberNum) {
        dbusInput.put(CommonDefs.EVENTNAME, event);
        dbusInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
        dbusInput.put(CommonDefs.TRANSACTION_NAME, "DeleteMemberGeneric");
        dbusInput.put(CommonDefs.ORIG_TRANSACTION_NAME, "DeleteMember");
        dbusInput.put(CommonDefs.CALLING_SYSTEM_ID, req.getCallingSystemId());
        dbusInput.put(CommonDefs.TRANSACTION_ID, req.getDbusTransactionId());
        dbusInput.put(CommonDefs.ORIG_TRANSID, req.getDbusTransactionId());
        dbusInput.put(CommonDefs.HANDLE, handle);
        dbusInput.put(CommonDefs.DOMAIN, domain);
        dbusInput.put(CommonDefs.PARENT_HANDLE, handle);
        dbusInput.put(CommonDefs.PARENT_DOMAIN, domain);

        if (!slidDeleteInInput) {
            dbusInput.put("hash_key", groupNum);
        }
        if (slidMemberNum != null) {
            dbusInput.put(MPSDefs.DB_SLID_MEMBER_NUM, slidMemberNum);
        }
    }

    private String getString(Map<String, Object> map, String key) {
        if (map != null && map.get(key) != null) {
            return map.get(key).toString();
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> getMap(Map<String, Object> map, String key) {
        Object value = map.get(key);
        if (value instanceof Map) {
            return (Map<String, Object>) value;
        }
        return CommonUtil.getHashMap();
    }

    @SuppressWarnings("unchecked")
    private boolean hasLinkedUsers(Map<String, Object> slidInfo) {
        if (slidInfo != null && slidInfo.containsKey(MPSDefs.KEY_LINKED_USERS)) {
            Object users = slidInfo.get(MPSDefs.KEY_LINKED_USERS);
            return (users instanceof List) && !((List<?>) users).isEmpty();
        }
        return false;
    }

}
