package com.att.idp.idgraphusermanagementms.resource.request;

import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;


/**
 * This class represents a Contact in the system.
 * It contains fields for contactType, phoneType, description, tn, tnExt, status, subscriptionId, validationStatus, and a map for unknownAttributes.
 * Each field has specific constraints such as not null and size limits.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 *
 */
@Schema(name = "Contact")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class Contact {
	
	@Schema(name = "contactType")
	@NotNull(message = "contactType is required field in input request.|RegisterEmailUser")
	@Size(min = 1, max = 10, message =  "contactType length is invalid|RegisterEmailUser")
	private String contactType;

	@Schema(name = "phoneType")
	@Size(min = 1, max = 10, message =  "phoneType length is invalid|RegisterEmailUser")
	private String phoneType;

	@Schema(name = "description")
	@Size(min = 1, max = 30, message =  "description length is invalid|RegisterEmailUser")
	private String description;

	@Schema(name = "tn")
	@Size(min = 1, max = 10, message =  "tn length is invalid|RegisterEmailUser")
	private String tn;

	@Schema(name = "tnExt")
	@Size(min = 1, max = 20, message =  "tnExt length is invalid|RegisterEmailUser")
	private String tnExt;

	@Schema(name = "status")
	@Size(min = 1, max = 30, message =  "status length is invalid|RegisterEmailUser")
	private String status;

	@Schema(name = "subscriptionId")
	@Size(min = 1, max = 255, message =  "subscriptionId length is invalid|RegisterEmailUser")
	private String subscriptionId;

	@Schema(name = "validationStatus")
	@Size(min = 1, max = 50, message =  "validationStatus length is invalid|RegisterEmailUser")
	private String validationStatus;
	
	/**
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
	 * @return Map<String,Object> The map of unknown attributes.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();

}
