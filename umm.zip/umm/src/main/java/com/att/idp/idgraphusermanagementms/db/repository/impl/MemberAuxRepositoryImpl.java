package com.att.idp.idgraphusermanagementms.db.repository.impl;

import java.sql.SQLException;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.att.idp.idgraphusermanagementms.db.model.Tmemberaux;
import com.att.idp.idgraphusermanagementms.db.repository.IDMProfileOrchestrationCustomRepository;
import com.att.idp.idgraphusermanagementms.db.repository.MemberAuxRepositoryCustom;
import com.att.idp.idgraphusermanagementms.db.request.MemberRequest;

/**
 * This is the implementation class for the MemberAuxRepositoryCustom interface.
 * It extends IDMProfileOrchestrationCustomRepository for common CRUD operations.
 * The entity associated with this repository is Tmemberaux and the ID type is Long.
 */
@Repository
public class MemberAuxRepositoryImpl extends IDMProfileOrchestrationCustomRepository<Tmemberaux, Long> implements MemberAuxRepositoryCustom {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MemberAuxRepositoryImpl.class);
	private static String sClassName = "MemberAuxRepositoryImpl";
	
	@Override
	protected Class<Tmemberaux> getClassT() {
		return Tmemberaux.class;
	}

	@Override
	public int addMemberAux(MemberRequest memberRequest) throws SQLException {
		String sMethodName = ".addMemberAux.";
		int rowCount = 0;

		try {


			String sql = "insert into MPS_OWNER.TMEMBERAUX (MEMBER_NUM,ENC_PASSWORD_VENC,MD5_PASSWORD_VENC,"
					+ "SHA1_PASSWORD_VENC,"
					+ "DES3_PASSWORD_VENC,SSHA_PASSWORD_VENC,"
					+ "SECURITY_ANSWER_1_VENC,SECURITY_ANSWER_2_VENC,"
					+ "LAST_MODIFIED_BY, PASSWORD_VENC, PASSWORD_TYPE) "
					+ "values (:memberNum,:encPasswordVenc,:md5PasswordVenc,"
					+ ":sha1PasswordVenc,:des3PasswordVenc,:sshaPasswordVenc,"
					+ ":securityAnswer1Venc,"
					+ ":securityAnswer2Venc,"
					+ ":lastModifiedBy,"
					+ ":passwordVenc,:passwordType)";

			Session hibSession = getSession();
			
			rowCount = hibSession.createNativeQuery(sql).addSynchronizedQuerySpace("")
								 .setParameter("memberNum", memberRequest.getMemberNum())
					.setParameter("encPasswordVenc", (StringUtils.isNotBlank(memberRequest.getMemberAux().getEncPasswordVenc())
									? memberRequest.getMemberAux().getEncPasswordVenc()
									: ""))
					.setParameter("md5PasswordVenc", StringUtils.isNotBlank(memberRequest.getMemberAux().getMd5PasswordVenc())
									? memberRequest.getMemberAux().getMd5PasswordVenc()
									: "")
								 .setParameter("sha1PasswordVenc", (StringUtils.isNotBlank(memberRequest.getMemberAux().getSha1PasswordVenc()) 
										 							? memberRequest.getMemberAux().getSha1PasswordVenc():""))
								 .setParameter("des3PasswordVenc", (StringUtils.isNotBlank(memberRequest.getMemberAux().getDes3PasswordVenc())
										 							? memberRequest.getMemberAux().getDes3PasswordVenc(): ""))
								 .setParameter("sshaPasswordVenc", (StringUtils.isNotBlank(memberRequest.getMemberAux().getSshaPasswordVenc()) 
										 							? memberRequest.getMemberAux().getSshaPasswordVenc(): ""))
								 .setParameter("securityAnswer1Venc", (StringUtils.isNotBlank(memberRequest.getMemberAux().getSecurityAnswer1Venc()) 
										 							  ? memberRequest.getMemberAux().getSecurityAnswer1Venc(): ""))
								 .setParameter("securityAnswer2Venc", (StringUtils.isNotBlank(memberRequest.getMemberAux().getSecurityAnswer2Venc()) 
										 							   ? memberRequest.getMemberAux().getSecurityAnswer2Venc(): ""))
								 //.setParameter("createDate", now)
								 //.setParameter("lastModified", now)
								 .setParameter("lastModifiedBy", (StringUtils.isNotBlank(memberRequest.getMemberAux().getLastModifiedBy())
										 ? memberRequest.getMemberAux().getLastModifiedBy():""))
								 //.setParameter("lastModifiedPw", now)
								 //.setParameter("lastModifiedSec", now)
								 //.setParameter("recentFraudPwDate", "")
								 .setParameter("passwordVenc", (StringUtils.isNotBlank(memberRequest.getMemberAux().getPasswordVenc())
										 						? memberRequest.getMemberAux().getPasswordVenc(): ""))
								 .setParameter("passwordType", (StringUtils.isNotBlank(memberRequest.getMemberAux().getPasswordType())
										 						? memberRequest.getMemberAux().getPasswordType(): ""))
								 .executeUpdate();
		} catch (Exception ex) {

			LOGGER.error("{}{}MAR_01 Error while inserting to DB : {}",sClassName,sMethodName, ex.getMessage());
		}
		return rowCount;
	}


}