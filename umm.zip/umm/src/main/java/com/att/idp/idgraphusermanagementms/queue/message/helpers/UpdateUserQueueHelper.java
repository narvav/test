package com.att.idp.idgraphusermanagementms.queue.message.helpers;

import com.att.idp.idgraph.events.service.EventPublisher;
import com.att.idp.idgraphusermanagementms.db.helper.GetMemberServicesDBHelper;
import com.att.idp.idgraphusermanagementms.helper.resetuserpassword.UserPasswordHelper;
import com.att.idp.idgraphusermanagementms.queue.message.sender.JMSQueueSender;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.helpers.ConvertServicesHelper;
import com.att.mpsys.common.helpers.FeatureManagerHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.PropertyManager;
import net.logstash.logback.argument.StructuredArguments;
import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * The UpdateUserQueueHelper class is part of the com.att.idp.idgraphusermanagementms.queue.message.helpers package.
 * It is a helper class that assists in sending messages to the message queue when a user's information is updated.
 * The class has several methods including sendMessageToMQ and buildUpdateContactEmailOrSQAEDDNotification.
 * sendMessageToMQ is responsible for sending the message to the queue and handling the response.
 * buildUpdateContactEmailOrSQAEDDNotification is responsible for building the notification for updating contact email or security questions and answers.
 * The class also has several fields including a logger, an instance of JMSQueueSender, UserPasswordHelper, GetMemberServicesDBHelper, ConvertServicesHelper, and various constants.
 */
@Component
public class UpdateUserQueueHelper {

	public static final Logger log = LoggerFactory.getLogger(UpdateUserQueueHelper.class);

	private String sClassName = "UpdateUserQueueHelper";

	private static final String ERROR_ENUM = "ErrorEnum";
	private static final String IS_TRANSACTION_ROLLBACK = "isTransactionRollback";
	private static final String USER_CONTACT_EMAIL_CHANGED	="userContactEmailChanged";
	private static final String VERIFY_CPNI_SERVICE = "verifyCPNIService";
	private static final String SLID_LEVEL_DBUS_UPDATE = "SLID_LEVEL_DBUS_UPDATE";
	private static final String MEMBER_LEVEL_DBUS_UPDATE = "MEMBER_LEVEL_DBUS_UPDATE";

	private String sGuid="";

    @Autowired
    private JMSQueueSender jmsQueueSender;

    @Autowired
    FeatureManagerHelper featureManager;

    @Autowired
    PublishMqAehHelper publishMqAehHelper;

    @Autowired
    EventPublisher eventPublisher;

	@Autowired
	private UserPasswordHelper userPasswordHelper;

	@Autowired
	private GetMemberServicesDBHelper oGetMemberServicesDBHelper;

	@Autowired
	private ConvertServicesHelper oConvertServicesHelper;

    @Value(value = "${spring.cloud.stream.bindings.externalEventsNotifications-out-0.destination}")
    private String externalEventsNotificationsTopicName;

	/**
	 * This method is part of the UpdateUserQueueHelper class.
	 * It is responsible for sending a message to the message queue when a user's information is updated.
	 * The method takes two HashMaps as input.
	 * The first HashMap contains the input data, and the second HashMap contains the DB member info.
	 * The method prepares the data for the asynchronous call, prepares the DBUS input, and sends the request to JMSQueueSender.
	 * If the response from the JMSQueueSender is empty or unsuccessful, the method returns an error.
	 * If the response is successful, the method returns a success message.
	 *
	 * @param hmInput The HashMap containing the input data.
	 * @param hmDBMemberInfo The HashMap containing the DB member info.
	 * @return A HashMap containing the response from the JMSQueueSender.
	 */
	public Map sendMessageToMQ(Map<String, Object> hmInput, Map<String, Object>  hmDBMemberInfo) {
		String sMethodName = ".sendMessageToMQ.";
		boolean callDBUS = false;
        HashMap<String, Object> hmEventData = CommonUtil.getHashMap();
        Map<String, Object> hmResult = CommonUtil.getHashMap();
        ArrayList<Map<String, Object>> alEventData = CommonUtil.getArrayList();
		ArrayList alSlidLevelDbusUpdate = null;

        log.info(SpiMarker.getInstance(), "{}{}UUQH_000 : Input Hash for UpdateUserQueueHelper : {} , {}",
                sClassName, sMethodName, StructuredArguments.entries(hmInput), StructuredArguments.entries(hmDBMemberInfo));

		sGuid = (String) hmInput.get(CommonDefs.GUID);
		String sFirstName = (String) hmInput.get(CommonDefs.FIRST_NAME);
		String sLastName = (String) hmInput.get(CommonDefs.LAST_NAME);
		String sActivatedInd = (String) hmInput.get(CommonDefs.ACTIVATED_IND);
		String sTransactionId = (String) hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID);
		String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
		String stAppInfo;
		String stAppStatusCode = null;
		String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
		String sSourceIPAddress = (String) hmInput.get(CommonDefs.SOURCE_IP_ADDRESS);

		if (sCallingSystemId != null && !sCallingSystemId.isEmpty()) {
			sCallingSystemId = sCallingSystemId.trim().toUpperCase();
			hmInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
		}

		if (sActivatedInd != null && !sActivatedInd.isEmpty()) {
			sActivatedInd = sActivatedInd.trim().toUpperCase();
			hmInput.put(CommonDefs.ACTIVATED_IND, sActivatedInd);
		}

		if ((null != sFirstName && !sFirstName.isEmpty()) || (null != sLastName && !sLastName.isEmpty())
				|| (null != sActivatedInd && !sActivatedInd.isEmpty())
				|| hmInput.containsKey(CommonDefs.CONTACT_EMAIL)
				|| hmInput.containsKey(CommonDefs.CONTACT_EMAIL_STATUS)
				|| hmInput.containsKey(CommonDefs.ONLINE1_SECURITY_QUESTION)
				|| hmInput.containsKey(CommonDefs.ONLINE1_SECURITY_ANSWER)
				|| hmInput.containsKey(CommonDefs.ONLINE2_SECURITY_QUESTION)
				|| hmInput.containsKey(CommonDefs.ONLINE2_SECURITY_ANSWER)) {
			callDBUS = true;
			if ((CommonDefs.IND_Y).equals(sActivatedInd))
				hmEventData.put("tosFlag", CommonDefs.IND_N);
		}

		if (callDBUS) {
			String stSlidLevelDbusUpdate = null;
			try {
				stSlidLevelDbusUpdate = PropertyManager.getProperty(CommonDefs.MOUPConfig,
						SLID_LEVEL_DBUS_UPDATE);
			} catch (Exception e) {
				log.error("{}{}UUQH_EX : Exception occured : {}", sClassName, sMethodName, e);
			}

			if (stSlidLevelDbusUpdate != null && !stSlidLevelDbusUpdate.isEmpty()) {
				alSlidLevelDbusUpdate = CommonUtil.parseToArray(stSlidLevelDbusUpdate,
						CommonDefs.VALUE_SEPARATOR_CHAR);
			}

			log.info("{}{}UUQH_01 : Property SLID_LEVEL_DBUS_UPDATE : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(alSlidLevelDbusUpdate)));
			HashMap hmSlidInfo = (HashMap) hmDBMemberInfo.get(MPSDefs.KEY_SLID_INFO);

			if (sGuid != null && !sGuid.isEmpty()) {
				sGuid = sGuid.trim();
				hmInput.put(CommonDefs.GUID, sGuid);
			} else {
				sGuid = (String) hmDBMemberInfo.get(MPSDefs.DB_MEMBER_NUM);
			}

			String dbMemberNum = null;
			if (hmSlidInfo != null && !hmSlidInfo.isEmpty()) {
				dbMemberNum = (String) hmSlidInfo.get(MPSDefs.DB_MEMBER_NUM);
				if (alSlidLevelDbusUpdate != null && !alSlidLevelDbusUpdate.isEmpty()) {
					for (int i = 0; i < alSlidLevelDbusUpdate.size(); i++) {
						String fieldName = (String) alSlidLevelDbusUpdate.get(i);

						if (hmInput.containsKey(fieldName)) {
							String fieldValue = (String) hmInput.get(fieldName);
							if (fieldValue != null && fieldValue.trim().length() > 0) {
								hmEventData.put(fieldName, fieldValue);
							}
						}
					}
				}

				if (hmEventData != null && !hmEventData.isEmpty()) {
					ArrayList alServicesForNotification = null;
					HashMap hmServicesForNotification = null;
					HashMap hmUserService = (HashMap) hmDBMemberInfo.get(CommonDefs.SERVICES);

					if (hmUserService != null && !hmUserService.isEmpty())
						hmServicesForNotification = oConvertServicesHelper.convertServices(hmUserService);

					if (hmServicesForNotification != null) {
						alServicesForNotification = (ArrayList) hmServicesForNotification.get(CommonDefs.SERVICES);
						hmEventData.put(CommonDefs.SERVICES, alServicesForNotification);
					}
					hmEventData.put(CommonDefs.HANDLE, hmSlidInfo.get(MPSDefs.DB_MEMBER_NAME));
					hmEventData.put(CommonDefs.PARENT_HANDLE, hmSlidInfo.get(MPSDefs.DB_PARENT_NAME));
					hmEventData.put(CommonDefs.DOMAIN, hmSlidInfo.get(MPSDefs.DB_DOMAIN_NAME));
					hmEventData.put(CommonDefs.PARENT_DOMAIN, hmSlidInfo.get(MPSDefs.DB_PARENT_DOMAIN));
					hmEventData.put(MPSDefs.DB_PARENT_CHILD_IND, hmSlidInfo.get(MPSDefs.DB_PARENT_CHILD_IND));
					hmEventData.put(MPSDefs.DB_MEMBER_NUM, hmSlidInfo.get(MPSDefs.DB_MEMBER_NUM));
					hmEventData.put(MPSDefs.DB_SLID_MEMBER_NUM, hmSlidInfo.get(MPSDefs.DB_SLID_MEMBER_NUM));
					hmEventData.put(CommonDefs.SUBEVENT, CommonDefs.DBUS_NOTIFICATION_SUBEVENT_SLID);
					hmEventData.put(CommonDefs.EVENTNAME, CommonDefs.CONTEXT_UpdateProfileInfo);
					hmEventData.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
					hmEventData.put(CommonDefs.TRANSACTION_ID, sTransactionId);
					if (sTransactionId != null && !sTransactionId.isEmpty()) {
						hmEventData.put(CommonDefs.ORIG_TRANSID, sTransactionId);
					}
					hmEventData.put(CommonDefs.TRANSACTION_NAME, CommonDefs.CONTEXT_UpdateMember);
					hmEventData.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);

					alEventData.add(hmEventData);
				}
			}

			//member level
			String stMemberLevelDbusUpdate = null;
			try {
				stMemberLevelDbusUpdate = PropertyManager.getProperty(CommonDefs.MOUPConfig, MEMBER_LEVEL_DBUS_UPDATE);
			} catch (Exception e) {
				log.error("{}{}UUQH_EX.01 : Exception occured : {}", sClassName, sMethodName, e);
			}
			ArrayList alMemberLevelDbusUpdate = null;

			if (stMemberLevelDbusUpdate != null && !stMemberLevelDbusUpdate.isEmpty()) {
				alMemberLevelDbusUpdate = CommonUtil.parseToArray(stMemberLevelDbusUpdate,
						CommonDefs.VALUE_SEPARATOR_CHAR);
			}

			log.info("{}{}UUQH_02 : Property MEMBER_LEVEL_DBUS_UPDATE : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(alMemberLevelDbusUpdate)));

			ArrayList alDBLinkedUsers = CommonUtil.getArrayList();
			ArrayList alLinkedUsers = CommonUtil.getArrayList();

			if (hmSlidInfo != null && !hmSlidInfo.isEmpty() && hmSlidInfo.containsKey(MPSDefs.KEY_LINKED_USERS)) {
				alDBLinkedUsers = (ArrayList) hmSlidInfo.get(MPSDefs.KEY_LINKED_USERS);
				alLinkedUsers = userPasswordHelper.getInterestedLinkedUsers(alDBLinkedUsers, sGuid);

			}

			log.info("{}{}UUQH_03 : alLinkedUsers : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(alLinkedUsers)));

			if (alLinkedUsers != null && !alLinkedUsers.isEmpty()) {
				for (int i = 0; i < alLinkedUsers.size(); i++) {
					HashMap hmEachUser = (HashMap) alLinkedUsers.get(i);
					HashMap hmEachUserEventData = CommonUtil.getHashMap();

					if (alMemberLevelDbusUpdate != null && !alMemberLevelDbusUpdate.isEmpty()) {
						for (int j = 0; j < alMemberLevelDbusUpdate.size(); j++) {
							String fieldName = (String) alMemberLevelDbusUpdate.get(j);
							if (hmInput.containsKey(fieldName)) {
								String fieldValue = (String) hmInput.get(fieldName);
								if (fieldValue != null && fieldValue.trim().length() > 0) {
									hmEachUserEventData.put(fieldName, fieldValue);
								}
							}
						}
					}

					if (hmEachUserEventData != null && !hmEachUserEventData.isEmpty()) {

						ArrayList alServicesForNotification = null;
						HashMap hmServicesForEachNotification = null;
						HashMap hmEachUserService = (HashMap) hmEachUser.get(CommonDefs.SERVICES);

						if (hmEachUserService != null && !hmEachUserService.isEmpty()) {
							hmServicesForEachNotification = oConvertServicesHelper.convertServices(hmEachUserService);
							if (hmServicesForEachNotification != null)
								alServicesForNotification = (ArrayList) hmServicesForEachNotification.get(CommonDefs.SERVICES);
						}

						if (alServicesForNotification != null)
							hmEachUserEventData.put(CommonDefs.SERVICES, alServicesForNotification);

						hmEachUserEventData.put(CommonDefs.PARENT_DOMAIN, hmEachUser.get(MPSDefs.DB_PARENT_DOMAIN));
						hmEachUserEventData.put(MPSDefs.DB_PARENT_CHILD_IND,
								hmEachUser.get(MPSDefs.DB_PARENT_CHILD_IND));
						hmEachUserEventData.put(CommonDefs.HANDLE, hmEachUser.get(MPSDefs.DB_MEMBER_NAME));
						hmEachUserEventData.put(CommonDefs.DOMAIN, hmEachUser.get(MPSDefs.DB_DOMAIN_NAME));
						hmEachUserEventData.put(MPSDefs.DB_MEMBER_NUM, hmEachUser.get(MPSDefs.DB_MEMBER_NUM));
						hmEachUserEventData.put(CommonDefs.MIGRATION_IND, hmEachUser.get(MPSDefs.DB_MIGRATION_IND));
						hmEachUserEventData.put(CommonDefs.PARENT_HANDLE, hmEachUser.get(MPSDefs.DB_PARENT_NAME));
						hmEachUserEventData.put(CommonDefs.SUBEVENT, CommonDefs.CONTEXT_UpdateProfileInfo);
						hmEachUserEventData.put(CommonDefs.EVENTNAME, CommonDefs.CONTEXT_UpdateProfileInfo);
						hmEachUserEventData.put(CommonDefs.DBUS_DICTIONARY_NAME,
								CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
						hmEachUserEventData.put(CommonDefs.TRANSACTION_ID, sTransactionId);
						if (sTransactionId != null && !sTransactionId.isEmpty()) {
							hmEachUserEventData.put(CommonDefs.ORIG_TRANSID, sTransactionId);
						}
						hmEachUserEventData.put(CommonDefs.TRANSACTION_NAME, CommonDefs.CONTEXT_UpdateMember);
						hmEachUserEventData.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
						alEventData.add(hmEachUserEventData);
					}
				}
			}

			if (hmInput.containsKey(CommonDefs.CONTACT_EMAIL) || hmInput.containsKey(CommonDefs.CONTACT_EMAIL_STATUS)
					|| hmInput.containsKey(CommonDefs.ONLINE1_SECURITY_QUESTION)
					|| hmInput.containsKey(CommonDefs.ONLINE1_SECURITY_ANSWER)
					|| hmInput.containsKey(CommonDefs.ONLINE2_SECURITY_QUESTION)
					|| hmInput.containsKey(CommonDefs.ONLINE2_SECURITY_ANSWER)) {
				HashMap hmEDDEventData = buildUpdateContactEmailOrSQAEDDNotification(hmInput, hmDBMemberInfo);
				if (hmEDDEventData != null && !hmEDDEventData.isEmpty()) {
					alEventData.add(hmEDDEventData);
				}
			}

		if (sTransactionName != null && !sTransactionName.isEmpty()) {
			sTransactionName = sTransactionName.trim();
		}

        Map<String, Object> hmDbusInput = CommonUtil.getHashMap();
		hmDbusInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
		hmDbusInput.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
		hmDbusInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
		hmDbusInput.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		hmDbusInput.put(CommonDefs.EVENTNAME, ProfileOrchestrationConstants.MICROSERVICE_EVENT);
		hmDbusInput.put(CommonDefs.MS_OPERTAION, sTransactionName);

		if (sGuid != null && !sGuid.isEmpty()) {
			hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, sGuid);
		} else {
			hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, dbMemberNum);
		}
		if (sSourceIPAddress != null && !sSourceIPAddress.isEmpty()) {
			sSourceIPAddress = sSourceIPAddress.trim();
			hmDbusInput.put(CommonDefs.SOURCE_IP_ADDRESS, sSourceIPAddress);
		}

		hmDbusInput.put(CommonDefs.EVENTS_DATA, alEventData);

	/* 	String sCallDbusFlag = (String) hmInput.get(CommonDefs.CALLDBUS);
		if (CommonDefs.IND_N.equals(sCallDbusFlag)) {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
			hmResult.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, alEventData);
			return hmResult;
		} */

            //mq aeh switch — prefer hmInput (header propagated), fallback to feature flag
            String updateUserMQAEHEnabled = (String) hmInput.get(ProfileOrchestrationConstants.UPDATE_USER_MQ_AEH_SWITCH);
            if (updateUserMQAEHEnabled == null || updateUserMQAEHEnabled.isEmpty()) {
                updateUserMQAEHEnabled = featureManager.getValue(ProfileOrchestrationConstants.UPDATE_USER_MQ_AEH_SWITCH);
            }
            updateUserMQAEHEnabled = (updateUserMQAEHEnabled != null && !updateUserMQAEHEnabled.isEmpty()) ? updateUserMQAEHEnabled : "MQ";
            log.info("ixp flag updateUserMQAEHEnabled MQ AEH Value: {}", updateUserMQAEHEnabled);

            //clm switch — prefer hmInput (header propagated), fallback to feature flag
            String updateUserClmEnabled = (String) hmInput.get(ProfileOrchestrationConstants.UPDATE_USER_NOTIFICATION_CLM_SWITCH);
            if (updateUserClmEnabled == null || updateUserClmEnabled.isEmpty()) {
                updateUserClmEnabled = featureManager.getValue(ProfileOrchestrationConstants.UPDATE_USER_NOTIFICATION_CLM_SWITCH);
            }
            updateUserClmEnabled = (updateUserClmEnabled != null && !updateUserClmEnabled.isEmpty()) ? updateUserClmEnabled : "MQ";
            log.info("ixp flag updateUserClmEnabled CLM Value: {}", updateUserClmEnabled);

            hmResult = publishMqAehHelper.invokeMqAEH(hmDbusInput, hmInput, alEventData, sClassName,
                    sMethodName, updateUserMQAEHEnabled, updateUserClmEnabled);

		if (MapUtils.isEmpty(hmResult)) {
                stAppInfo = "Null Response returned from UpdateUserQueueHelper.JMSQueueSender.send";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			log.info("{}{}UUQH_05 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
		if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {

			stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
			log.info("{}{}UUQH_06 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
			hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
			return hmResult;
		} else {
			hmResult.put(IS_TRANSACTION_ROLLBACK, true);
		}
	}
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}

	private HashMap buildUpdateContactEmailOrSQAEDDNotification(Map<String, Object> hmInput, Map<String, Object> hmDBMemberInfo) {
		HashMap hmNotificationInp = CommonUtil.getHashMap();
		ArrayList alNotificationData = CommonUtil.getArrayList();
		HashMap hmNotificationEmail = CommonUtil.getHashMap();
		HashMap hmMemberContactEmail = CommonUtil.getHashMap();
		ArrayList alMemberContactEmail = CommonUtil.getArrayList();

		String sTransactionId = (String) hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID);

		hmNotificationInp.put(CommonDefs.HANDLE, hmDBMemberInfo.get(MPSDefs.DB_MEMBER_NAME));
		hmNotificationInp.put(CommonDefs.DOMAIN, hmDBMemberInfo.get(MPSDefs.DB_DOMAIN_NAME));
		hmNotificationInp.put(CommonDefs.TRANSACTION_NAME, CommonDefs.CONTEXT_UpdateMember);
		hmNotificationInp.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		hmNotificationInp.put(CommonDefs.TRANSACTION_ID, sTransactionId);

		if (hmDBMemberInfo.get(MPSDefs.DB_PARENT_NAME) != null)
			hmNotificationInp.put(CommonDefs.PARENT_HANDLE, hmDBMemberInfo.get(MPSDefs.DB_PARENT_NAME));
		if (hmDBMemberInfo.get(MPSDefs.DB_PARENT_DOMAIN) != null)
			hmNotificationInp.put(CommonDefs.PARENT_DOMAIN, hmDBMemberInfo.get(MPSDefs.DB_PARENT_DOMAIN));
		if (hmDBMemberInfo.get(CommonDefs.DB_MEMBER_NUM) != null)
			hmNotificationInp.put(CommonDefs.DB_MEMBER_NUM, hmDBMemberInfo.get(CommonDefs.DB_MEMBER_NUM));
		if (hmDBMemberInfo.get(CommonDefs.SOR_NAME) != null)
			hmNotificationInp.put(CommonDefs.SOR_NAME, hmDBMemberInfo.get(CommonDefs.SOR_NAME));
		if (hmDBMemberInfo.get(CommonDefs.DB_PARENT_CHILD_IND) != null)
			hmNotificationInp.put(CommonDefs.DB_PARENT_CHILD_IND, hmDBMemberInfo.get(CommonDefs.DB_PARENT_CHILD_IND));

		if (hmInput.get(CommonDefs.BROWSER_LANGUAGE) != null)
			hmNotificationInp.put(CommonDefs.BROWSER_LANGUAGE, hmInput.get(CommonDefs.BROWSER_LANGUAGE));
		else
			hmNotificationInp.put(CommonDefs.BROWSER_LANGUAGE, hmDBMemberInfo.get(MPSDefs.DB_BROWSER_LANGUAGE));

		if (hmInput.get(CommonDefs.FIRST_NAME) != null)
			hmNotificationInp.put(CommonDefs.FIRST_NAME, hmInput.get(CommonDefs.FIRST_NAME));
		else
			hmNotificationInp.put(CommonDefs.FIRST_NAME, hmDBMemberInfo.get(MPSDefs.DB_LC_FIRSTNAME));

		if (hmInput.get(CommonDefs.LAST_NAME) != null)
			hmNotificationInp.put(CommonDefs.LAST_NAME, hmInput.get(CommonDefs.LAST_NAME));
		else
			hmNotificationInp.put(CommonDefs.LAST_NAME, hmDBMemberInfo.get(MPSDefs.DB_LC_LASTNAME));

		if (sTransactionId != null && !sTransactionId.isEmpty())
			hmNotificationInp.put(CommonDefs.ORIG_TRANSID, sTransactionId);

		hmNotificationInp.put(VERIFY_CPNI_SERVICE, CommonDefs.IND_Y);
		hmNotificationInp.put(CommonDefs.SUBEVENT, CommonDefs.DBUS_NOTIFICATION_SUBEVENT_SLID);
		hmNotificationInp.put(CommonDefs.CUSTOMER_TYPE, hmDBMemberInfo.get(MPSDefs.DB_ACCOUNT_TYPE));

		if (hmDBMemberInfo.containsKey(MPSDefs.DB_CONTACT_EMAIL))
			hmMemberContactEmail.put(CommonDefs.CONTACT_EMAIL, hmDBMemberInfo.get(MPSDefs.DB_CONTACT_EMAIL));

		String stContactValid = (String) hmDBMemberInfo.get(MPSDefs.DB_CONTACT_EMAIL_VALID);
		if (stContactValid != null) {
			hmMemberContactEmail.put(CommonDefs.CONTACT_EMAIL_STATUS, CommonDefs.EMAIL_STATUS_TRANSLATION.get(stContactValid));
		}

		if (hmMemberContactEmail != null && !hmMemberContactEmail.isEmpty())
			alMemberContactEmail.add(hmMemberContactEmail);
		if (alMemberContactEmail != null && !alMemberContactEmail.isEmpty())
			hmNotificationEmail.put(CommonDefs.MEMBER_CONTACT_EMAIL, alMemberContactEmail);

		hmNotificationEmail.put(USER_CONTACT_EMAIL_CHANGED, CommonDefs.IND_Y);

		String stAutoGenInd = (String) hmDBMemberInfo.get(MPSDefs.DB_AUTOGENERATED_IND);
		if (stAutoGenInd != null && !stAutoGenInd.isEmpty())
			hmNotificationInp.put(CommonDefs.AUTO_GENERATED_IND, stAutoGenInd);

		if (hmInput.containsKey(CommonDefs.CONTACT_EMAIL) || hmInput.containsKey(CommonDefs.CONTACT_EMAIL_STATUS))
			alNotificationData.add(hmNotificationEmail);

		if (hmInput.containsKey(CommonDefs.ONLINE1_SECURITY_ANSWER)
				|| hmInput.containsKey(CommonDefs.ONLINE2_SECURITY_ANSWER)) {
			HashMap hmSQANotification = new HashMap();
			hmSQANotification.put(CommonDefs.MEMBER_CONTACT_EMAIL, alMemberContactEmail);
			hmSQANotification.put(CommonDefs.SECURITY_ANSWER_CHANGED, CommonDefs.IND_Y);
			alNotificationData.add(hmSQANotification);
		}

		if (alNotificationData != null && !alNotificationData.isEmpty())
			hmNotificationInp.put(CommonDefs.NOTIFICATION_DATA, alNotificationData);
		else {
			if (hmInput.containsKey(CommonDefs.ONLINE1_SECURITY_QUESTION)
					|| hmInput.containsKey(CommonDefs.ONLINE2_SECURITY_QUESTION)) {
				HashMap hmNotificationFields = new HashMap();
				if (hmInput.containsKey(CommonDefs.ONLINE1_SECURITY_QUESTION)) {
					hmNotificationFields.put(CommonDefs.ONLINE1_SECURITY_QUESTION,
							hmInput.get(CommonDefs.ONLINE1_SECURITY_QUESTION));
				}

				if (hmInput.containsKey(CommonDefs.ONLINE2_SECURITY_QUESTION)) {
					hmNotificationFields.put(CommonDefs.ONLINE2_SECURITY_QUESTION,
							hmInput.get(CommonDefs.ONLINE2_SECURITY_QUESTION));
				}
				hmNotificationInp.put(CommonDefs.NOTIFICATION_FIELDS, hmNotificationFields);
			}
		}

		hmNotificationInp.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
		hmNotificationInp.put(CommonDefs.EVENTNAME, CommonDefs.CONTEXT_NotificationEvent);

		return hmNotificationInp;
	}
}