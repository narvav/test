package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "TMEMBERDEVICE", schema = "MPS_OWNER")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tmemberdevice implements Serializable {

	private static final long serialVersionUID = -1848368775724436509L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "memberNum", column = @Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "sorId", column = @Column(name = "SOR_ID", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "deviceId", column = @Column(name = "DEVICE_ID", nullable = false)) })
	private TmemberdeviceId id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CATEGORY_ID", nullable = false)
	private Tcategory tcategory;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MEMBER_NUM", nullable = false, insertable = false, updatable = false)
	private Tmember tmember;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SOR_ID", nullable = false, insertable = false, updatable = false)
	private Tsystemofrecord tsystemofrecord;

	@Column(name = "DEVICE_NAME")
	private String deviceName;

	@Column(name = "MAKE")
	private String make;

	@Column(name = "MODEL")
	private String model;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;
}