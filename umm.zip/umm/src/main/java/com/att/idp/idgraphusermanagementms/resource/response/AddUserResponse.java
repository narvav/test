package com.att.idp.idgraphusermanagementms.resource.response;

import com.att.idp.core.exception.ServiceError;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * This class represents the response from the Add User operation in the system.
 * It contains fields for transactionName, appStatusMsg, appStatusCode, guid, appInfo, appCategoryCode, errors, suggestedHandle1, suggestedHandle2, suggestedHandle3, and idpTraceId.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Jackson's @JsonIgnore, @JsonProperty, @JsonIgnoreProperties, and @JsonInclude annotations to handle JSON serialization and deserialization.
 * It also uses Swagger's @ApiModel annotation to provide metadata for the Swagger UI.
 *
 * The class provides getter and setter methods for all fields.
 * It also overrides the toString method to return a string representation of the object.
 *
 */
@EqualsAndHashCode(callSuper = true)
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "AddUserResponse")
public class AddUserResponse  extends AddUpdateUserBaseResponse{
	@JsonIgnore
	private static final String transactionName = "AddUserResponse";
	}