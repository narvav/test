package com.att.idp.idgraphusermanagementms.resource.request;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;


@Schema(name = "EmailAliases")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class EmailAliases {

	@Schema(name = "emailAliasId")
	@Size(min=1, max=127,message="emailAliasId length is invalid|RemoveEmailAlias")
	@NotBlank(message = "emailAliasId is required|RemoveEmailAlias")
	private String emailAliasId;

	@Schema(name = "emailAliasDomain")
	@NotBlank(message = "emailAliasDomain is required field in input request.|RemoveEmailAlias")
	@Size(min = 1, max = 30, message =  "emailAliasDomain length is invalid|RemoveEmailAlias")
	private  String emailAliasDomain;

	
	/**
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
     */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();

}
