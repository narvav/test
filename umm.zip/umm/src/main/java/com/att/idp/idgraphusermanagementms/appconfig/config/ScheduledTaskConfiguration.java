package com.att.idp.idgraphusermanagementms.appconfig.config;

import com.azure.spring.cloud.appconfiguration.config.AppConfigurationRefresh;
import org.apache.commons.lang.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;


/**
 * Configuration class for scheduling tasks.
 */
@Configuration
@EnableScheduling
public class ScheduledTaskConfiguration {

    private static final String TASK_NAME_SCHEDULED_APP_CONFIG_PRINTER = "scheduledAppConfigPrinter";
    private static final Logger logger = LoggerFactory
            .getLogger(ScheduledTaskConfiguration.class.getName() + "." + TASK_NAME_SCHEDULED_APP_CONFIG_PRINTER);

    @Autowired
    private IDGraphAzureAppConfig appConfiguration;

    @Autowired
    private AppConfigurationRefresh appConfigurationRefresh;

    // Track previous state to log only on configuration changes
    private volatile String lastConfigSnapshot = "";

    @Autowired
    public ScheduledTaskConfiguration(IDGraphAzureAppConfig appConfiguration,
                                      AppConfigurationRefresh appConfigurationRefresh) {
        this.appConfiguration = appConfiguration;
        this.appConfigurationRefresh = appConfigurationRefresh;
    }


    @Scheduled(initialDelayString = "30000", fixedDelayString = "30000")
    public void doScheduledAppConfigPrinter() throws Exception {
        appConfigurationRefresh.refreshConfigurations();
        String currentSnapshot = buildConfigSnapshot();
        if (!currentSnapshot.equals(lastConfigSnapshot)) {
            logger.info("App Configuration changed. Details: {}", currentSnapshot);

            lastConfigSnapshot = currentSnapshot;
        }
    }

    /**
     * Builds a string representation of the current configuration state for change detection.
     *
     * @return Configuration state as a formatted string
     */
    private String buildConfigSnapshot() {
        return String.format(
                "appconfig.version [%s], connTimeout [%s], maxSize [%s], queryTimeout [%s], validationQuery [%s], initialSize [%s], testWhileIdle [%s], testOnBorrow [%s], evictTime [%s], minSize [%s], dataSourceRefreshEnabled [%s]",
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getVersion())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getConnTimeout())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getMaxSize())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getQueryTimeout())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getValidationQuery())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getInitialSize())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.isTestWhileIdle())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.isTestOnBorrow())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getEvictTime())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getMinSize())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.isDataSourceRefreshEnabled()))
        );
    }
}
