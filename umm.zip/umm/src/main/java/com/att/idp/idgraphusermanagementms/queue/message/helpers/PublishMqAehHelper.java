package com.att.idp.idgraphusermanagementms.queue.message.helpers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.att.idp.idgraph.events.service.EventPublisher;
import com.att.idp.idgraphusermanagementms.queue.message.sender.JMSQueueSender;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.mpsys.common.utils.CommonUtil;
import org.apache.commons.text.StringEscapeUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import org.springframework.web.util.HtmlUtils;

/**
 * Helper for publishing to MQ/AEH/CLM based on configuration flags.
 */
@Component
public class PublishMqAehHelper {

    private static final Logger log = LoggerFactory.getLogger(PublishMqAehHelper.class);

    @Autowired
    private  JMSQueueSender jmsQueueSender;

    @Autowired
    private  EventPublisher eventPublisher;

    @Value(value = "${spring.cloud.stream.bindings.externalEventsNotifications-out-0.destination}")
    private String externalEventsNotificationsTopicName;

    public Map<String, Object> invokeMqAEH(
            Map<String, Object> hmDbusInput,
            Map<String, Object> hmInput,
            List<Map<String, Object>> alEventData,
            String sClassName,String sMethodName, String mQAEHEnabled, String clmEnabled) {

        Map<String, Object> hmResult = null;
        if ("MQ".equalsIgnoreCase(mQAEHEnabled) && "MQ".equalsIgnoreCase(clmEnabled)) {
            hmResult = handleMqOnly(hmDbusInput, sClassName, sMethodName);
        } else if ("AEH".equalsIgnoreCase(mQAEHEnabled) && "AEH".equalsIgnoreCase(clmEnabled)) {
            hmResult = handleAehOnly(hmDbusInput, hmInput, sClassName, sMethodName);
        } else if ("BOTH".equalsIgnoreCase(mQAEHEnabled) && "BOTH".equalsIgnoreCase(clmEnabled)) {
            hmResult = handleBothMqAeh(hmDbusInput, hmInput, sClassName, sMethodName);
        } else if ("MQ".equalsIgnoreCase(mQAEHEnabled) && "AEH".equalsIgnoreCase(clmEnabled)) {
            hmResult = handleMqAeh(hmDbusInput, hmInput, alEventData, sClassName, sMethodName);
        } else if ("MQ".equalsIgnoreCase(mQAEHEnabled) && "BOTH".equalsIgnoreCase(clmEnabled)) {
            hmResult = handleMqAndBoth(hmDbusInput, hmInput, alEventData, sClassName, sMethodName);
        } else if ("AEH".equalsIgnoreCase(mQAEHEnabled) && "MQ".equalsIgnoreCase(clmEnabled)) {
            hmResult = handleAehMq(hmDbusInput, hmInput, alEventData, sClassName, sMethodName);
        }
        return hmResult;
    }

    /**
     * Handles MQ only logic.
     */
    public Map<String, Object> handleMqOnly(
            Map<String, Object> hmDbusInput,
            String sClassName,
            String sMethodName) {
        log.info("sendMessageToMQ.ASMIDQH_01 : Calling JMSQueueSender with inputHash : {}", StringEscapeUtils.escapeJava(String.valueOf(hmDbusInput)));
        Map<String, Object> hmResult = (HashMap<String, Object>) jmsQueueSender.send(hmDbusInput);
        log.info("{}{}ASMIDQH_02 : ResponseHash from JMSQueueSender : {}",
                sClassName, sMethodName, hmResult != null ? StringEscapeUtils.escapeJava(hmResult.toString()) : null);
        return mergeResponses(hmResult, null);
    }

    /**
     * Handles AEH only logic.
     */
    public Map<String, Object> handleAehOnly(
            Map<String, Object> hmDbusInput,
            Map<String, Object> hmInput,
            String sClassName,
            String sMethodName) {
        log.info("PMQH.HAEH.01 : Inside  handleAehOnly method: {}", hmDbusInput != null ? ESAPI.encoder().encodeForHTML(hmDbusInput.toString()) : null);
        Map<String, Object> hmResultForAEH = new HashMap<String, Object>();
        String msOperation = (String)hmInput.get("msOperation");
        String appInfo = null;
        try{
            Map<String, Object> hmDbusGenericInput = new HashMap<>(hmDbusInput);
            hmDbusGenericInput.put("msName", "IDGraphUserManagementMS-");
            hmDbusGenericInput.put("eventType", "UserManagement");
            hmDbusGenericInput.put(CommonDefs.TRANSACTION_ID, hmInput.get("idpTraceId"));
            hmDbusGenericInput.put("dbServices", hmInput.get("dbServices"));
            log.info("{}{}ASMIDQH_03.0 : publishing to ExternalEvents topic : {}",
                    sClassName, sMethodName, StringEscapeUtils.escapeJava(hmDbusGenericInput.toString()));
            hmResultForAEH = publishEventToExternalEventsTopic(hmDbusGenericInput, sClassName);
            log.info("{}{}ASMIDQH_04.0 : published to ExternalEvents topic : {}",
                    sClassName, sMethodName, StringEscapeUtils.escapeJava(externalEventsNotificationsTopicName));

            return hmResultForAEH;
        } catch (Exception ex){
            log.error("Error in handleAehOnly::", ex);
            appInfo = msOperation + " sent failed";
            hmResultForAEH = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, appInfo);
            return mergeResponses(null, hmResultForAEH);
        }
    }

    /**
     * Handles BOTH logic.
     */
    public Map<String, Object> handleBothMqAeh(
            Map<String, Object> hmDbusInput,
            Map<String, Object> hmInput,
            String sClassName,
            String sMethodName) {
        log.info("{}{} PMQH.HBMA.01: Inside  handleBothMqAeh method: {}", sClassName, sMethodName, StringEscapeUtils.escapeJava(String.valueOf(hmDbusInput)));
        Map<String, Object> hmResult = null;
        Map<String, Object> hmResultForAEH = null;
        Map<String, Object> hmDbusGenericInput = new HashMap<>(hmDbusInput);
        hmDbusGenericInput.put("msName", "IDGraphUserManagementMS-");
        hmDbusGenericInput.put("eventType", "UserManagement");
        hmDbusGenericInput.put(CommonDefs.TRANSACTION_ID, hmInput.get("idpTraceId"));
        hmDbusGenericInput.put("dbServices", hmInput.get("dbServices"));
        log.info("{}{}ASMIDQH_05.0 : publishing to ExternalEvents topic : {}",
                sClassName, sMethodName, StringEscapeUtils.escapeJava(hmDbusGenericInput.toString()));
        hmResultForAEH = publishEventToExternalEventsTopic(hmDbusGenericInput, sClassName);
        log.info("{}{}ASMIDQH_06.0 : published to ExternalEvents topic : {}",
                sClassName, sMethodName, StringEscapeUtils.escapeJava(externalEventsNotificationsTopicName));

        hmDbusInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
        log.info("sendMessageToMQ.ASMIDQH_01 : Calling JMSQueueSender with inputHash : {}",
                hmDbusInput);
        hmResult = (HashMap<String, Object>) jmsQueueSender.send(hmDbusInput);
        log.info("{}{}ASMIDQH_07 : ResponseHash from JMSQueueSender : {}",
                sClassName, sMethodName, hmResult != null ? StringEscapeUtils.escapeJava(hmResult.toString()) : null);
        return mergeResponses(hmResult, hmResultForAEH);
    }

    /**
     * Handles MQ + AEH CLM logic.
     */
    public Map<String, Object> handleMqAeh(
            Map<String, Object> hmDbusInput,
            Map<String, Object> hmInput,
            List<Map<String, Object>> alEventData,
            String sClassName,
            String sMethodName) {
        log.info("{}{} PMQH.HMA.01: Inside  handleMqAeh method: {}", sClassName, sMethodName, StringEscapeUtils.escapeJava(String.valueOf(hmDbusInput)));
        Map<String, Object> hmResult = null;
        Map<String, Object> hmResultForAEH = null;
        for (Map<String, Object> eventData : alEventData) {
            String eventName = (String) eventData.get(CommonDefs.EVENTNAME);
            if (CommonDefs.CONTEXT_NotificationEvent.equalsIgnoreCase(eventName)) {
                hmDbusInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
                Map<String, Object> hmDbusGenericInput = new HashMap<>(hmDbusInput);
                hmDbusGenericInput.put("msName", "IDGraphUserManagementMS-");
                hmDbusGenericInput.put("eventType", "UserManagement");
                hmDbusGenericInput.put(CommonDefs.TRANSACTION_ID, hmInput.get("idpTraceId"));
                hmDbusGenericInput.put("dbServices", hmInput.get("dbServices"));
                hmDbusGenericInput.remove(CommonDefs.EVENTS_DATA);
                hmDbusGenericInput.put(CommonDefs.EVENTS_DATA, eventData);
                log.info("{}{}ASMIDQH_12 : publishing NotificationEvent to ExternalEvents topic : {}",
                        sClassName, sMethodName, StringEscapeUtils.escapeJava(hmDbusGenericInput.toString()));
                hmResultForAEH = publishEventToExternalEventsTopic(hmDbusGenericInput, sClassName);
                log.info("{}{}ASMIDQH_13 : published  NotificationEvent to ExternalEvents topic : {}",
                        sClassName, sMethodName, StringEscapeUtils.escapeJava(externalEventsNotificationsTopicName));

                hmDbusInput.put(CommonDefs.EVENTS_DATA, alEventData.stream()
                        .filter(event -> !CommonDefs.CONTEXT_NotificationEvent.equalsIgnoreCase((String) event.get(CommonDefs.EVENTNAME)))
                        .collect(Collectors.toList()));
            }
        }

        hmDbusInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
        log.info("sendMessageToMQ.ASMIDQH_01 : Calling JMSQueueSender with inputHash : {}",
                StringEscapeUtils.escapeJava(String.valueOf(hmDbusInput)));
        hmResult = (HashMap<String, Object>) jmsQueueSender.send(hmDbusInput);
        log.info("{}{}ASMIDQH_15 : ResponseHash from JMSQueueSender Except NotificationEvent : {}",
                sClassName, sMethodName, hmResult != null ? StringEscapeUtils.escapeJava(hmResult.toString()) : null);
        return mergeResponses(hmResult, hmResultForAEH);
    }

    /**
     * Handles MQ + BOTH CLM logic.
     */
    public Map<String, Object> handleMqAndBoth(
            Map<String, Object> hmDbusInput,
            Map<String, Object> hmInput,
            List<Map<String, Object>> alEventData,
            String sClassName,
            String sMethodName) {
        log.info("{}{} PMQH.HMAB.01: Inside  handleMqAndBoth method: {}", sClassName, sMethodName, StringEscapeUtils.escapeJava(String.valueOf(hmDbusInput)));
        Map<String, Object> hmResult = null;
        Map<String, Object> hmResultForAEH = null;
        for (Map<String, Object> eventData : alEventData) {
            String eventName = (String) eventData.get(CommonDefs.EVENTNAME);
            if (CommonDefs.CONTEXT_NotificationEvent.equalsIgnoreCase(eventName)) {
                hmDbusInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
                Map<String, Object> hmDbusGenericInput = new HashMap<>(hmDbusInput);
                hmDbusGenericInput.put("msName", "IDGraphUserManagementMS-");
                hmDbusGenericInput.put("eventType", "UserManagement");
                hmDbusGenericInput.put(CommonDefs.TRANSACTION_ID, hmInput.get("idpTraceId"));
                hmDbusGenericInput.put("dbServices", hmInput.get("dbServices"));
                hmDbusGenericInput.remove(CommonDefs.EVENTS_DATA);
                hmDbusGenericInput.put(CommonDefs.EVENTS_DATA, eventData);
                log.info("{}{}ASMIDQH_08 : publishing to ExternalEvents topic : {}",
                        sClassName, sMethodName, StringEscapeUtils.escapeJava(hmDbusGenericInput.toString()));
                hmResultForAEH = publishEventToExternalEventsTopic(hmDbusGenericInput, sClassName);
                log.info("{}{}ASMIDQH_09 : published to ExternalEvents topic : {}",
                        sClassName, sMethodName, StringEscapeUtils.escapeJava(externalEventsNotificationsTopicName));
            }
        }

        hmDbusInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
        log.info("sendMessageToMQ.ASMIDQH_01 : Calling JMSQueueSender with inputHash : {}",
                StringEscapeUtils.escapeJava(String.valueOf(hmDbusInput)));
        hmResult = (HashMap<String, Object>) jmsQueueSender.send(hmDbusInput);
        log.info("{}{}ASMIDQH_11 : ResponseHash from JMSQueueSender : {}",
                sClassName, sMethodName, hmResult != null ? StringEscapeUtils.escapeJava(hmResult.toString()) : null);
        return mergeResponses(hmResult, hmResultForAEH);
    }

    /**
     * Handles AEH + MQ CLM logic.
     */
    public Map<String, Object> handleAehMq(
            Map<String, Object> hmDbusInput,
            Map<String, Object> hmInput,
            List<Map<String, Object>> alEventData,
            String sClassName,
            String sMethodName) {
        log.info("{} PMQH.HAM.01: Inside  handleAehMq method:",
                hmDbusInput != null ? StringEscapeUtils.escapeJava(hmDbusInput.toString()) : null);
        Map<String, Object> hmResult = null;
        Map<String, Object> hmResultForAEH = null;
        List<Map<String, Object>> allEventList = new ArrayList<>();
        for (Map<String, Object> eventData : alEventData) {
            String eventName = (String) eventData.get(CommonDefs.EVENTNAME);
            if (CommonDefs.CONTEXT_NotificationEvent.equalsIgnoreCase(eventName)) {
                allEventList.add(eventData);
            }
        }
        Map<String, Object> hmDbusGenericInput = new HashMap<>(hmDbusInput);
        hmDbusGenericInput.put(CommonDefs.EVENTS_DATA, alEventData.stream()
                .filter(event -> !CommonDefs.CONTEXT_NotificationEvent.equalsIgnoreCase((String) event.get(CommonDefs.EVENTNAME)))
                .collect(Collectors.toList()));
        hmDbusGenericInput.put(CommonDefs.TRANSACTION_ID, hmInput.get("idpTraceId"));
        hmDbusGenericInput.put("dbServices", hmInput.get("dbServices"));
        hmDbusGenericInput.put("msName", "IDGraphUserManagementMS-");
        hmDbusGenericInput.put("eventType", "UserManagement");
        log.info("{}{}ASMIDQH_14 : publishing to ExternalEvents topic : {}",
                sClassName, sMethodName, StringEscapeUtils.escapeJava(hmDbusGenericInput.toString()));
        hmResultForAEH = publishEventToExternalEventsTopic(hmDbusGenericInput, sClassName);
        log.info("{}{}ASMIDQH_15 : published to ExternalEvents topic : {}",
                sClassName, sMethodName, StringEscapeUtils.escapeJava(externalEventsNotificationsTopicName));

        hmDbusInput.remove(CommonDefs.EVENTS_DATA);
        log.info("allEventList is::{} ",
                allEventList != null ? StringEscapeUtils.escapeJava(allEventList.toString()) : null);
        hmDbusInput.put(CommonDefs.EVENTS_DATA, allEventList);

        hmDbusInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
        log.info("{} sendMessageToMQ.ASMIDQH_01 : Calling JMSQueueSender with inputHash : {}",
                sClassName, StringEscapeUtils.escapeJava(String.valueOf(hmDbusInput)));
        hmResult = (HashMap<String, Object>) jmsQueueSender.send(hmDbusInput);
        log.info("{}{}ASMIDQH_13: ResponseHash from JMSQueueSender : {}",
                sClassName, sMethodName, hmResult != null ? StringEscapeUtils.escapeJava(hmResult.toString()) : null);

        return mergeResponses(hmResult, hmResultForAEH);

    }

    /**
     * Publishes an event to the external events topic.
     */
    private Map<String, Object> publishEventToExternalEventsTopic(Map<String, Object> hmAEHInput, String sClassName) {
        String binding = "externalEventsNotifications";
        Map<String, Object> hmResult = CommonUtil.getHashMap();

        try {
            log.debug("Input payload for AEH - {}", StringEscapeUtils.escapeJava(String.valueOf(hmAEHInput)));
            hmResult = validateInputForAEH(hmAEHInput, sClassName);
            if (hmResult != null) {
                return hmResult;
            }
            log.info("{}.PE.PETEE.1 Publishing event to topic: {} with TransactionId: {}", sClassName,
                    StringEscapeUtils.escapeJava(externalEventsNotificationsTopicName), StringEscapeUtils.escapeJava(String.valueOf(hmAEHInput.get(CommonDefs.TRANSACTION_ID))));
            boolean response = eventPublisher.send(binding, (String) hmAEHInput.get(CommonDefs.MAIN_HASH_KEY), hmAEHInput);
            if(response) {
                log.info("{}.PE.PETEE.2 Successfully published event to topic: {} with TransactionId: {}", sClassName,
                        StringEscapeUtils.escapeJava(externalEventsNotificationsTopicName), StringEscapeUtils.escapeJava(String.valueOf(hmAEHInput.get(CommonDefs.TRANSACTION_ID))));
                String stAppInfo = "Successfully published event to AEH for transactionId: " + hmAEHInput.get(CommonDefs.TRANSACTION_ID);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
                return hmResult;
            } else {
                log.error("{}.PE.PETEE.3 Failed to published event to topic: {} with TransactionId: {}", sClassName,
                        StringEscapeUtils.escapeJava(externalEventsNotificationsTopicName), StringEscapeUtils.escapeJava(String.valueOf(hmAEHInput.get(CommonDefs.TRANSACTION_ID))));
                String stAppInfo = "Failed to publish event to AEH";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                return hmResult;
            }
        } catch (Exception e) {
            log.error("{}.PE.PETEE.4 Exception occurred while publishing event to topic: {} with dbusTransactionId: {}",
                    sClassName,
                    StringEscapeUtils.escapeJava(externalEventsNotificationsTopicName),
                    StringEscapeUtils.escapeJava(String.valueOf(hmAEHInput.get(CommonDefs.TRANSACTION_ID))), e);
            String stAppInfo = "Error while sending event to AEH: " + e.getMessage();
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
            return hmResult;
        }
    }

    private Map<String, Object> validateInputForAEH(Map<String, Object> hmAEHInput, String sClassName) {
        Map<String, Object> hmResult = null;

        if (hmAEHInput == null || hmAEHInput.isEmpty()) {
            log.error("{}-PETEET.VIFA.1 hmDbusInput is null or empty. Cannot publish Event.", sClassName);
            String stAppInfo = "Input for AEH is NULL";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
            return hmResult;
        }

        //get the msOperation name
        String msOperation = (String)hmAEHInput.get("msOperation");
        if(msOperation==null || msOperation.isEmpty()){
            log.error("{}-PETEET.VIFA.2 msOperation is null or empty. Cannot publish Event.", sClassName);
            String appInfo = "msOperation cannot be null or empty for AEH";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, appInfo);
            return hmResult;
        }

        //get the transactionId name
        String transactionId = (String)hmAEHInput.get(CommonDefs.TRANSACTION_ID);
        if(transactionId==null || transactionId.isEmpty()){
            log.error("{}-PETEET.VIFA.3 transactionId is null or empty. Cannot publish Event.", sClassName);
            String appInfo = "TransactionId cannot be null or empty for AEH";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, appInfo);
            return hmResult;
        }
        return hmResult;
    }

    private Map<String, Object> mergeResponses(Map<String, Object> hmResult, Map<String, Object> hmResultForAEH) {
        StringBuilder stappInfo = new StringBuilder();
        if(hmResultForAEH != null || hmResult != null) {
            String stAppStatusCodeForAEH = hmResultForAEH != null ? (String) hmResultForAEH.get(CommonDefs.COMMON_APP_STATUS_CODE) : null;
            String stAppStatusCodeForMQ = hmResult != null ? (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE) : null;
            if(CommonDefs.COMMON_SUCCESS.equalsIgnoreCase(stAppStatusCodeForAEH) && CommonDefs.COMMON_SUCCESS.equalsIgnoreCase(stAppStatusCodeForMQ)) {
                return CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Successfully published event to both AEH and MQ");
            } else if(CommonDefs.COMMON_SUCCESS.equalsIgnoreCase(stAppStatusCodeForAEH) && !CommonDefs.COMMON_SUCCESS.equalsIgnoreCase(stAppStatusCodeForMQ)) {
                return CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Successfully published event to AEH");
            } else if(!CommonDefs.COMMON_SUCCESS.equalsIgnoreCase(stAppStatusCodeForAEH) && CommonDefs.COMMON_SUCCESS.equalsIgnoreCase(stAppStatusCodeForMQ)) {
                return CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Successfully published event to MQ");
            } else {
                if(hmResultForAEH != null && !CommonDefs.COMMON_SUCCESS.equalsIgnoreCase(stAppStatusCodeForAEH)) {
                    stappInfo.append(hmResultForAEH.get(CommonDefs.COMMON_APP_INFO));
                }
                if(hmResult != null && !CommonDefs.COMMON_SUCCESS.equalsIgnoreCase(stAppStatusCodeForMQ)) {
                    stappInfo.append(!stappInfo.isEmpty() ? " ": "");
                    stappInfo.append(hmResult.get(CommonDefs.COMMON_APP_INFO));
                }
                return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stappInfo.toString());
            }
        } else {
            if(hmResultForAEH == null) {
                stappInfo.append("Received NULL response from AEH.");
            }
            if(hmResult == null) {
                stappInfo.append(!stappInfo.isEmpty() ? " ": "");
                stappInfo.append("Received NULL response from MQ.");
            }
            return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stappInfo.toString());
        }
    }
}