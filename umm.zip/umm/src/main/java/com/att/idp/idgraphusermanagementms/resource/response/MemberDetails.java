package com.att.idp.idgraphusermanagementms.resource.response;

import com.att.idp.idgraph.db.oracle.model.EmailAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "MemberDetails")
public class MemberDetails {
    private String firstName;
    private String lastName;
    private String memberNum;
    private String memberName;
    private String domain;
    private String memberId;
    private String parentChildInd;
    private String memberStatus;
    private String migrationInd;
    private String accessName;
    private String cbr;
    private String zip;
    private String nickName;
    private String contactEmail;
    private String yRegCompleteInd;
    private String fullName;
    private String sor;
    private String gender;
    private String city;
    private String state;
    private String streetAddress;
    private String language;
    private String bizRes;
    private String isLegacy;
    private List<EmailAlias> emailAlias;
    private List<Map<String, Object>> services;
}
