package com.att.idp.idgraphusermanagementms.metrics;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import org.springframework.stereotype.Component;

import static com.att.idp.cd.observability.metrics.utils.Constants.DB;
import static com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants.IDGRAPH_USERMANAGEMENTMS_DB_ERR;

/**
 * Captures DB error metrics for IDGraphUserManagement operations.
 * Inject this bean into DB helper/repository classes and call
 * {@code recordDbErrorMetric()} from within {@code catch} blocks where
 * a JDBC exception occurs.
 * IDPTimedAspect intercepts the call and publishes the metric to Prometheus.
 */
@Component
public class ErrorMetricHandler {

    @TimedMetrics(
            name = IDGRAPH_USERMANAGEMENTMS_DB_ERR,
            type = DB,
            description = "DB error in IDGraphUserManagement",
            constantTags = {"database=mpsys", "container=oracle"}
    )
    public void recordDbErrorMetric() {
        // IDPTimedAspect intercepts this call and records the metric.
        // No logic needed here — call this from DB helper catch blocks.
    }
}
