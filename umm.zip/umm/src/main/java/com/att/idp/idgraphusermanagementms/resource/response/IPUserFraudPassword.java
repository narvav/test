package com.att.idp.idgraphusermanagementms.resource.response;

import lombok.Data;

/**
 * This class represents a user's fraud password status in the system.
 * It contains fields for fraudCounter, lastModifiedBy, lastModified, memberNum, and createDate.
 * Each field has specific constraints such as not null and size limits.
 *
 * The class uses Lombok's @Data annotation to generate getter and setter methods for all fields.
 *
 */
@Data
public class IPUserFraudPassword {

	private String fraudCounter;
	private String lastModifiedBy;
	private String lastModified;
	private String memberNum;
	private String createDate;
}