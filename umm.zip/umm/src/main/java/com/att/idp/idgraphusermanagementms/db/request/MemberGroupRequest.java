package com.att.idp.idgraphusermanagementms.db.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * This is the MemberGroupRequest class which implements Serializable interface.
 * It represents a request for a member group with properties like groupNum, parentName, createDate, lastModified, lastModifiedBy, premium800Ind, bulkBillingInd, accessCode, and domainRequest.
 * Each property has its respective getter and setter methods.
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({


})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MemberGroupRequest implements Serializable{

	private static final long serialVersionUID = -2440096872948005490L;

	private Long groupNum;
	private String parentName;
	private String createDate;
	private String lastModified;
	private String lastModifiedBy;
	private Character premium800Ind;
	private Character bulkBillingInd;
	private String accessCode;
	private DomainRequest domainRequest;
}