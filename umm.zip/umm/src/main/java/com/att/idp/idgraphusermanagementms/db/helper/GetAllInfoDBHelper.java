package com.att.idp.idgraphusermanagementms.db.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.mpsys.common.utils.PropertyManager;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.StatusMsg;
import org.springframework.web.util.HtmlUtils;

/**
 * This class is responsible for retrieving all information related to a user from the database.
 * It uses Spring's JdbcTemplate for database operations.
 *
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like JdbcTemplate.
 *
 * The class contains SQL queries as string constants for retrieving user information.
 * These queries are used in the corresponding methods for these operations.
 *
 * The main method in this class is:
 * - getInfo: This method retrieves all information related to a user from the database. It takes a HashMap as input and returns a HashMap as output.
 *   The input HashMap contains key-value pairs for various user attributes like member number, group number, service name, group status, member status, etc.
 *   The method first checks if the jdbcTemplate is null. If it is, it returns an error status.
 *   Then it retrieves various user attributes from the input HashMap and converts them to the appropriate data types.
 *   It also retrieves the user ID, member status, and group status from the DBHelper.
 *   If any of these values are not found, it returns an error status.
 *   Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
 *   Finally, it returns a status indicating whether the operation was successful or not.
 */
@Component
public class GetAllInfoDBHelper {

	private static final String CLASS_NAME = "GetAllInfoDBHelper";

	private  String dateFormat = "MMDDYYYY HH24:mi:ss";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	private String firstQueryMemNum =
			" SELECT  "
					+ " secq.security_question_type as security_question_type, secq.security_question_active as security_question_active, "
					+ " mem.security_question_id_1, secq1.security_question as security_question_1, mem.security_answer_1, "
					+ " secq1.security_question_type as security_question_1_type, secq1.security_question_active as security_question_1_active, "
					+ " mem.security_question_id_2, secq2.security_question as security_question_2, mem.security_answer_2, "
					+ " secq2.security_question_type as security_question_2_type, secq2.security_question_active as security_question_2_active, "
					+ " mem.previous_contact_email, TO_CHAR(mem.contact_email_est_date,'"
					+ dateFormat
					+ "') as contact_email_est_date, "
					+ " mem.last_member_status as last_member_status_code, stat.status_name as last_member_status_name, mem.credit_checked_ind, mem.yreg_complete_ind, TO_CHAR(mem.lockout_timestamp, '"
					+ dateFormat
					+ "') as lockout_timestamp, mem.firstname, mem.lastname, mem.nickname, mem.last_four_ssn, mem.security_question_id, "
					+ "  mem.gender, mem.proofing_zip, secq.security_question, "
					+ " TO_CHAR(mem.delete_request_date, '"
					+ dateFormat
					+ "') AS delete_request_date, mem.token, mem.remarks, mem.ban, mem.member_num, mem.member_name, mem.group_num, dom.domain_name, mem.domain_id, "
					+ " mem.enc_password, mem.md5_password, mem.parent_child_ind, mem.member_state, mem.agg_access_status, mem.agg_service_status, mem.mailhost, mem.fullname, mem.account_type, mem.optout_ind, mem.migration_ind, TO_CHAR(mem.migration_date, '"
					+ dateFormat
					+ "') AS migration_date, TO_CHAR(mem.create_date, '"
					+ dateFormat
					+ "') AS create_date, TO_CHAR(mem.last_modified, '"
					+ dateFormat
					+ "') AS last_modified, mem.last_modified_by AS last_modified_by, memGroup.parent_name, parentDom.domain_name as parent_domain, mem.sor_id, sor.sor_name, mem.access_id, acc.access_name, memGroup.bulk_billing_ind, memGroup.premium_800_ind, memGroup.access_code, mem.contact_email, mem.contact_email_valid, mem.password_dirty, mem.sha1_password, "
					+ " mem.des3_password, mem.failed_auth_count ,"
					+ " mem.language, mem.slid_member_num, "
					+ " TO_CHAR(mem.tos_reject_date, '" + dateFormat + "') AS tos_reject_date, mem.num_tos_rejects, "
					+ " mem.alert_ind, TO_CHAR(mem.csr_initiated_lockout_ts, '"
					+ dateFormat
					+ "') AS csr_initiated_lockout_ts, mem.browser_language, "
					+ " mem.dsl_net_password, mem.dsl_net_pw_encr_type, mem.contact_email_status, mem.ssha_password, "
					+ " mem.autogenerated_ind, mem.activated_ind, TO_CHAR(mem.activated_date, '"+ dateFormat + "') AS activated_date, mem.birthdate_venc, mem.passcode_venc, mem.security_answer_venc, "
					+ " TO_CHAR(mem.main_ctn_opt_out, '"+ dateFormat + "') AS main_ctn_opt_out, TO_CHAR(mem.onl_qa_est_date, '"
					+ dateFormat
					+ "') AS onl_qa_est_date,"
					// 2103 -  SSHA-256 encryption changes
					+ " memaux.password_venc AS gen_password_venc,"
					+ " memaux.password_type  AS gen_password_type,"
					+ " memaux.enc_password_venc, memaux.md5_password_venc, memaux.sha1_password_venc,"
					+ " memaux.des3_password_venc, memaux.ssha_password_venc, memaux.security_answer_1_venc,"
					+ " memaux.security_answer_2_venc"
					+ " FROM"
					+ " MEMBER mem,MEMBERGROUP memGroup,DOMAIN dom, DOMAIN parentDom, SecurityQuestion secq, SYSTEMOFRECORD sor,NETWORKACCESS acc, STATUS stat, "
					+ " SecurityQuestion secq1, SecurityQuestion secq2, MEMBERAUX memaux "
					+ " WHERE "
					+ " mem.sor_id = sor.sor_id AND mem.access_id = acc.access_id AND mem.domain_id = dom.domain_id AND memGroup.domain_id=parentDom.domain_id "
					+ " AND mem.security_question_id = secq.security_question_id (+) "
					+ " AND mem.last_member_status = stat.status_code (+) "
					+ " AND mem.security_question_id_1 =secq1.security_question_id (+) "
					+ " AND mem.security_question_id_2 =secq2.security_question_id (+) "
					+ " AND mem.member_num = memaux.member_num (+) "
					+ " AND mem.group_num = memGroup.group_num AND mem.member_num = ? "
					+ " AND mem.parent_child_ind in ('P','C','S') ";


	private String firstQueryBan =
			" SELECT  "
					+ " secq.security_question_type as security_question_type, secq.security_question_active as security_question_active, "
					+ " mem.security_question_id_1, secq1.security_question as security_question_1, mem.security_answer_1, "
					+ " secq1.security_question_type as security_question_1_type, secq1.security_question_active as security_question_1_active, "
					+ " mem.security_question_id_2, secq2.security_question as security_question_2, mem.security_answer_2, "
					+ " secq2.security_question_type as security_question_2_type, secq2.security_question_active as security_question_2_active, "
					+ " mem.previous_contact_email, TO_CHAR(mem.contact_email_est_date,'"
					+ dateFormat
					+ "') as contact_email_est_date, "
					+ " mem.last_member_status as last_member_status_code, stat.status_name as last_member_status_name, mem.credit_checked_ind, mem.yreg_complete_ind, TO_CHAR(mem.lockout_timestamp, '"
					+ dateFormat
					+ "') as lockout_timestamp, mem.firstname, mem.lastname, mem.nickname, mem.last_four_ssn, mem.security_question_id, "
					+ " mem.gender, mem.proofing_zip, secq.security_question, "
					+ " TO_CHAR(mem.delete_request_date, '"
					+ dateFormat
					+ "') AS delete_request_date, mem.token, mem.remarks, mem.ban, mem.member_num, mem.member_name, mem.group_num, dom.domain_name, mem.domain_id, "
					+ " mem.enc_password, mem.md5_password, mem.parent_child_ind, mem.member_state, mem.agg_access_status, mem.agg_service_status, mem.mailhost, mem.fullname, mem.account_type, mem.optout_ind, mem.migration_ind, TO_CHAR(mem.migration_date, '"
					+ dateFormat
					+ "') AS migration_date, TO_CHAR(mem.create_date, '"
					+ dateFormat
					+ "') AS create_date, TO_CHAR(mem.last_modified, '"
					+ dateFormat
					+ "') AS last_modified, mem.last_modified_by AS last_modified_by, memGroup.parent_name, parentDom.domain_name as parent_domain, mem.sor_id, sor.sor_name, mem.access_id, acc.access_name, memGroup.bulk_billing_ind, memGroup.premium_800_ind, memGroup.access_code, mem.contact_email, mem.contact_email_valid, mem.password_dirty, mem.sha1_password,  "
					+ " mem.des3_password, mem.failed_auth_count ,"
					+ " mem.language, mem.slid_member_num, "
					+ " TO_CHAR(mem.tos_reject_date, '" + dateFormat + "') AS tos_reject_date, mem.num_tos_rejects, "
					+ " mem.alert_ind, TO_CHAR(mem.csr_initiated_lockout_ts, '"
					+ dateFormat
					+ "') AS csr_initiated_lockout_ts, mem.browser_language, "
					+ " mem.dsl_net_password, mem.dsl_net_pw_encr_type, mem.contact_email_status, mem.ssha_password, "
					+ " mem.autogenerated_ind, mem.activated_ind, TO_CHAR(mem.activated_date, '"+ dateFormat + "') AS activated_date, mem.birthdate_venc, mem.passcode_venc, mem.security_answer_venc, "
					+ " TO_CHAR(mem.main_ctn_opt_out, '"+ dateFormat + "') AS main_ctn_opt_out, TO_CHAR(mem.onl_qa_est_date, '"
					+ dateFormat
					+ "') AS onl_qa_est_date,"
					// 2103 -  SSHA-256 encryption changes
					+ " memaux.password_venc AS gen_password_venc,"
					+ " memaux.password_type  AS gen_password_type,"
					+ " memaux.enc_password_venc, memaux.md5_password_venc, memaux.sha1_password_venc,"
					+ " memaux.des3_password_venc, memaux.ssha_password_venc, memaux.security_answer_1_venc,"
					+ " memaux.security_answer_2_venc"
					+ " FROM"
					+ " MEMBER mem,MEMBERGROUP memGroup,DOMAIN dom, DOMAIN parentDom, SecurityQuestion secq, SYSTEMOFRECORD sor,NETWORKACCESS acc, STATUS stat, "
					+ " SecurityQuestion secq1, SecurityQuestion secq2, MEMBERAUX memaux"
					+ " WHERE "
					+ " mem.sor_id = sor.sor_id AND mem.access_id = acc.access_id AND mem.domain_id = dom.domain_id AND memGroup.domain_id=parentDom.domain_id "
					+ " AND mem.security_question_id = secq.security_question_id (+) "
					+ " AND mem.last_member_status = stat.status_code (+) "
					+ " AND mem.security_question_id_1 =secq1.security_question_id (+) "
					+ " AND mem.security_question_id_2 =secq2.security_question_id (+) "
					+ " AND mem.member_num = memaux.member_num (+) "
					+ " AND mem.group_num = memGroup.group_num "
					+ " AND mem.parent_child_ind = 'P' "
					+ " AND mem.ban = ? ";


	/**
	 * This query retrieves ban, member_num, member_name, group_num, domain_name, domain_id, migration_date,
	 * create_date, last_modified, last_modified_by, parent_name, sor_id, sor_name, enc_password, md5_password,
	 * parent_child_ind, member_state, agg_access_status, agg_service_status, mailhost, fullname, account_type,
	 * optout_ind, access_id, access_name, bulk_billing_ind, premium_800_ind, access_code
	 *  from member, membergroup, systemofrecord, domain, networkaccess tables by member_name and domain_name.
	 */
	/**Modified all the 3 queries for LSR3
	 * @author km8212
	 * @modified on 051506
	 *   	Return all following (new non-serity) feilds
	 *			firstname, lastname, nickname, genger, credit_checked_ind, yreg_complete_ind, lockout_time_stamp, proofing_zip
	 *		If securityAllRequired key present in input
	 *			return all security fields (birthdate, last_four_SSN, security_question,security_question_id, security_answer)
	 *		Else
	 *			If (birthDateRequired key present in input Hash)
	 *				also return birthdate
	 *			If (lastFourSSNRequired key present in input Hash)
	 *				also return last_four_SSN
	 *			If (securityQuestionRequired key present in input Hash)
	 *				also return security_question,security_question_id
	 *			If (securityAnswerRequired key present in input Hash)
	 *				also return security_answer
	 ***/

	private  String firstQueryMemDomainName =
			" SELECT  "
					+ " secq.security_question_type as security_question_type, secq.security_question_active as security_question_active, "
					+ " mem.security_question_id_1, secq1.security_question as security_question_1, mem.security_answer_1, "
					+ " secq1.security_question_type as security_question_1_type, secq1.security_question_active as security_question_1_active, "
					+ " mem.security_question_id_2, secq2.security_question as security_question_2, mem.security_answer_2, "
					+ " secq2.security_question_type as security_question_2_type, secq2.security_question_active as security_question_2_active, "
					+ " mem.previous_contact_email, TO_CHAR(mem.contact_email_est_date,'"
					+ dateFormat
					+ "') as contact_email_est_date, "
					+ " mem.last_member_status as last_member_status_code, stat.status_name as last_member_status_name, mem.credit_checked_ind, mem.yreg_complete_ind, TO_CHAR(mem.lockout_timestamp, '"
					+ dateFormat
					+ "') as lockout_timestamp, mem.firstname, mem.lastname, mem.nickname, mem.last_four_ssn, mem.security_question_id, "
					+ "  mem.gender, mem.proofing_zip, secq.security_question, "
					+ " TO_CHAR(mem.delete_request_date, '"
					+ dateFormat
					+ "') AS delete_request_date, mem.token, mem.remarks, mem.ban, mem.member_num, mem.member_name, mem.group_num, dom.domain_name, mem.domain_id, "
					+ " mem.enc_password, mem.md5_password, mem.parent_child_ind, mem.member_state, mem.agg_access_status, mem.agg_service_status, mem.mailhost, mem.fullname, mem.account_type, mem.optout_ind, mem.migration_ind, TO_CHAR(mem.migration_date, '"
					+ dateFormat
					+ "') AS migration_date, TO_CHAR(mem.create_date, '"
					+ dateFormat
					+ "') AS create_date, TO_CHAR(mem.last_modified, '"
					+ dateFormat
					+ "') AS last_modified, mem.last_modified_by AS last_modified_by, memGroup.parent_name, parentDom.domain_name as parent_domain, mem.sor_id, sor.sor_name, mem.access_id, acc.access_name, memGroup.bulk_billing_ind, memGroup.premium_800_ind, memGroup.access_code, mem.contact_email, mem.contact_email_valid, mem.password_dirty, mem.sha1_password, "
					+ " mem.des3_password, mem.failed_auth_count ,"
					+ " mem.language, mem.slid_member_num, "
					+ " TO_CHAR(mem.tos_reject_date, '" + dateFormat + "') AS tos_reject_date, mem.num_tos_rejects, "
					+ " mem.alert_ind, TO_CHAR(mem.csr_initiated_lockout_ts, '"
					+ dateFormat
					+ "') AS csr_initiated_lockout_ts, mem.browser_language, "
					+ " mem.dsl_net_password, mem.dsl_net_pw_encr_type, mem.contact_email_status, mem.ssha_password, "
					+ " mem.autogenerated_ind, mem.activated_ind, TO_CHAR(mem.activated_date, '"+ dateFormat + "') AS activated_date, mem.birthdate_venc, mem.passcode_venc, mem.security_answer_venc, "
					+ " TO_CHAR(mem.main_ctn_opt_out, '"+ dateFormat + "') AS main_ctn_opt_out, TO_CHAR(mem.onl_qa_est_date, '"
					+ dateFormat
					+ "') AS onl_qa_est_date,"
					// 2103 -  SSHA-256 encryption changes
					+ " memaux.password_venc AS gen_password_venc,"
					+ " memaux.password_type  AS gen_password_type,"
					+ " memaux.enc_password_venc, memaux.md5_password_venc, memaux.sha1_password_venc, "
					+ " memaux.des3_password_venc, memaux.ssha_password_venc, memaux.security_answer_1_venc, "
					+ " memaux.security_answer_2_venc "
					+ " FROM"
					+ " MEMBER mem,MEMBERGROUP memGroup,DOMAIN dom, DOMAIN parentDom, SecurityQuestion secq, SYSTEMOFRECORD sor,NETWORKACCESS acc, STATUS stat, "
					+ " SecurityQuestion secq1, SecurityQuestion secq2, MEMBERAUX memaux "
					+ " WHERE "
					+ " mem.sor_id = sor.sor_id AND mem.access_id = acc.access_id AND mem.domain_id = dom.domain_id AND memGroup.domain_id=parentDom.domain_id "
					+ " AND mem.security_question_id = secq.security_question_id (+) "
					+ " AND mem.last_member_status = stat.status_code (+) "
					+ " AND mem.security_question_id_1 =secq1.security_question_id (+) "
					+ " AND mem.security_question_id_2 =secq2.security_question_id (+) "
					+ " AND mem.member_num = memaux.member_num (+) "
					+ "AND mem.group_num = memGroup.group_num AND mem.member_name = ? AND dom.domain_name = ? ";


	/**
	 * This query retrieves instance_id, site_id, pending_disconnect_date, member_num, service_id, member_status_code,
	 * group_status_code, group_status_name, member_status_name, terminate_date, create_date, last_modified,
	 * last_modified_by, service_name, service_type from memberservice, service, status tables by member_num.
	 */

/*		private  String queryForOtherService =
			" SELECT portal.portal_provider, portal.plite_ind, memService.instance_id, TO_CHAR(memService.pending_disconnect_date, '"
				+ dateFormat
				+ "') AS pending_disconnect_date, memService.member_num AS memService_member_num, memService.service_id AS service_id, "
				+ " memService.member_status AS member_status_code, memService.group_status AS group_status_code, "
				+ " stat1.status_name AS group_status_name, stat.status_name AS member_status_name, memService.nickname as service_nickname, "
				+ " memService.default_account, TO_CHAR(memService.date_default_est, '"
				+ dateFormat
				+ "') AS date_default_est, memService.cpni_impacted, TO_CHAR(memService.terminate_date, '"
				+ dateFormat
				+ "') AS terminate_date, TO_CHAR(memService.create_date, '"
				+ dateFormat
				+ "') AS create_date, TO_CHAR(memService.last_modified, '"
				+ dateFormat
				+ "') AS last_modified, memService.last_modified_by AS last_modified_by, serv.service_name, serv.service_type,"
				+ " memService.sor_id, sor.sor_name, memService.sor_invariant_id, memService.owned_by, memService.unification_pending, memService.parent_sor_id,"
				+ " memService.parent_sor_invariant_id, memService.uverse_service_ind,memService.suspend_reason_code, serv.major_service_id, serv.email_eligible,"
				+ " serv.entity_type, iptv.portal_svc_provider as portal_svc_provider, "
				+ " servassoc.sor_id1, "
				+ " nvl(servassoc.sor_invariant_id1, '--NULL--') as sor_invariant_id1, sor2.sor_name as sor_name1, "
				+ " servassoc.sor_id2, "
				+ " nvl(servassoc.sor_invariant_id2, '--NULL--') as sor_invariant_id2, sor3.sor_name as sor_name2, "
				+ " servassoc.assigned_by as asso_assigned_by, servassoc.last_modified_by as asso_last_modified_by, "
				+ " TO_CHAR(servassoc.create_date, '"
				+ dateFormat
				+ "') AS asso_create_date, "
				+ " TO_CHAR(servassoc.last_modified, '"
				+ dateFormat
				+ "') AS asso_last_modified "
				+ " FROM  MEMBERSERVICE memService,SERVICE serv,STATUS stat, STATUS stat1, PORTALUSER portal, SYSTEMOFRECORD sor, IPTVUSER iptv, "
				+ " serviceassociation servassoc, SYSTEMOFRECORD sor2, SYSTEMOFRECORD sor3 "
				+ " WHERE serv.service_id = memService.service_id AND memService.group_status = stat1.status_code (+) AND memService.member_status = stat.status_code (+) "
				+ " AND memService.service_id=portal.service_id (+) AND memService.member_num=portal.member_num (+) AND memService.sor_id=sor.sor_id (+) "
				+ "	AND memService.member_num = iptv.member_num(+) AND memService.service_id = iptv.service_id(+) "
				+ " AND servassoc.sor_id1(+) = memService.sor_id AND servassoc.sor_id1 = sor2.sor_id (+) AND servassoc.sor_id2 = sor3.sor_id (+) "
				+ " AND servassoc.sor_invariant_id1(+) = memService.sor_invariant_id "
				+ " AND memService.member_num = ? ";*/
	/**
	 * This query retrieves DSL service info - pending_disconnect_date, member_num, service_id, member_status_code,
	 * group_status_code, group_status_name, member_status_name, terminate_date, create_date, last_modified,
	 * last_modified_by, service_name, service_type, circuit_id, virtual_path, virtual_circuit,
	 * incoming_burst, incoming_limit, outgoing_burst, outgoing_limit, protocol_type, ip_address,
	 * ip_subnet, wtn, dsluser.create_date, dsluser.last_modified, dsluser.last_modified_by
	 * from memberservice, service, status, dsluser tables by member_num.
	 */
/*		private  String queryForDSLService =
			" SELECT portal.portal_provider, portal.plite_ind, memService.instance_id, TO_CHAR(memService.pending_disconnect_date, '"
				+ dateFormat
				+ "') AS pending_disconnect_date, memService.member_num AS memService_member_num, memService.service_id AS service_id, "
				+ " memService.member_status AS member_status_code, memService.group_status AS group_status_code, "
				+ " stat1.status_name AS group_status_name, stat.status_name AS member_status_name, memService.nickname as service_nickname, "
				+ " memService.default_account, TO_CHAR(memService.date_default_est, '"
				+ dateFormat
				+ "') AS date_default_est, memService.cpni_impacted, TO_CHAR(memService.terminate_date, '"
				+ dateFormat
				+ "') AS terminate_date, serv.service_name, serv.service_type,serv.email_eligible, TO_CHAR(memService.create_date, '"
				+ dateFormat
				+ "') AS create_date, TO_CHAR(memService.last_modified, '"
				+ dateFormat
				+ "') AS last_modified, memService.last_modified_by AS last_modified_by, memService.suspend_reason_code, "

				+ " dsl.circuit_id, dsl.virtual_path, dsl.virtual_circuit, dsl.incoming_burst, dsl.incoming_limit, "
				+ " dsl.outgoing_burst, dsl.outgoing_limit, dsl.protocol_type, dsl.ip_address, dsl.ip_subnet, dsl.wtn, dsl.ip_netblock, "
				+ " dsl.dslam_type, dsl.tdsl_ind, dsl.ipv6rd_enabled, dsl.ipv6rd_manually_disabled, dsl.dns_err_optout_ind, "
				+ " TO_CHAR(dsl.create_date, '"
				+ dateFormat
				+ "') AS dsl_user_create_date, TO_CHAR(dsl.last_modified, '"
				+ dateFormat
				+ "') AS dsl_user_last_modified, dsl.last_modified_by AS dsl_user_last_modified_by, memService.sor_id, sor.sor_name, "
				+ " dslNP.network_profile_name AS dsl_network_profile_name,dsl.network_profile_id as dsl_network_profile_id, memService.sor_invariant_id , iptv.portal_svc_provider as portal_svc_provider, "
				+ " servassoc.sor_id1, "
				+ " nvl(servassoc.sor_invariant_id1, '--NULL--') as sor_invariant_id1, sor2.sor_name as sor_name1, "
				+ " servassoc.sor_id2, "
				+ " nvl(servassoc.sor_invariant_id2, '--NULL--') as sor_invariant_id2, sor3.sor_name as sor_name2, "
				+ " servassoc.assigned_by as asso_assigned_by, servassoc.last_modified_by as asso_last_modified_by, "
				+ " TO_CHAR(servassoc.create_date, '"
				+ dateFormat
				+ "') AS asso_create_date, "
				+ " TO_CHAR(servassoc.last_modified, '"
				+ dateFormat
				+ "') AS asso_last_modified, memService.owned_by, "
				+ " memService.parent_sor_id, memService.parent_sor_invariant_id, memService.unification_pending, memService.uverse_service_ind, serv.major_service_id, serv.entity_type "
				+ " FROM  MEMBERSERVICE memService,SERVICE serv,STATUS stat,STATUS stat1,DSLUser dsl, PORTALUSER portal, SYSTEMOFRECORD sor, NETWORKPROFILE dslNP, IPTVUSER iptv,  "
				+ " serviceassociation servassoc, SYSTEMOFRECORD sor2, SYSTEMOFRECORD sor3 "
				+ " WHERE serv.service_id = memService.service_id AND memService.group_status = stat1.status_code (+) AND memService.member_status = stat.status_code (+) AND memService.member_num = dsl.member_num (+) "
				+ " AND memService.service_id=portal.service_id (+) AND memService.member_num=portal.member_num (+) AND memService.sor_id=sor.sor_id (+) "
				+ " AND dsl.network_profile_id = dslNP.network_profile_id (+) AND memService.member_num = iptv.member_num(+) AND memService.service_id = iptv.service_id(+) "
				+ " AND servassoc.sor_id1(+) = memService.sor_id AND servassoc.sor_id1 = sor2.sor_id (+) AND servassoc.sor_id2 = sor3.sor_id (+) "
				+ " AND servassoc.sor_invariant_id1(+) = memService.sor_invariant_id "
				+ " AND memService.member_num = ? ";*/

	/**
	 * This query retrieves ISDN service info - pending_disconnect_date, member_num, service_id, member_status_code,
	 * group_status_code, group_status_name, member_status_name, terminate_date, create_date, last_modified,
	 * last_modified_by, service_name, service_type,
	 * isdn.ip_address, isdn.ip_subnet, isdn.ip_netblock, isdn.create_date, isdn.last_modified, isdn.last_modified_by
	 * from memberservice, service, status, isdnuser tables by member_num.
	 */
	//LSR4 - this query modified to return PORTAL service recod if ISDN user has portal serive, by pm4659 on 101806
	//// rp6341-- LSR7 update -- removed memService.site_id from select query.
	//Not retrieving site_id from memberservice table
/*		private  String queryForISDNService =
			" SELECT portal.portal_provider, portal.plite_ind, memService.instance_id, TO_CHAR(memService.pending_disconnect_date, '"
				+ dateFormat
				+ "') AS pending_disconnect_date, memService.member_num AS memService_member_num, memService.service_id AS service_id, "
				+ " memService.member_status AS member_status_code, memService.group_status AS group_status_code, "
				+ " stat1.status_name AS group_status_name, memService.nickname as service_nickname, "
				+ " memService.default_account, TO_CHAR(memService.date_default_est, '"
				+ dateFormat
				+ "') AS date_default_est, memService.cpni_impacted, memService.suspend_reason_code,"
				+ " stat.status_name AS member_status_name, TO_CHAR(memService.terminate_date, '"
				+ dateFormat
				+ "') AS terminate_date, serv.service_name, serv.service_type, serv.email_eligible, TO_CHAR(memService.create_date, '"
				+ dateFormat
				+ "') AS create_date, TO_CHAR(memService.last_modified, '"
				+ dateFormat
				+ "') AS last_modified, memService.last_modified_by AS last_modified_by, "
				+ " isdn.ip_address, isdn.ip_subnet, isdn.ip_netblock,"
				+ " TO_CHAR(isdn.create_date, '"
				+ dateFormat
				+ "') AS isdn_user_create_date, TO_CHAR(isdn.last_modified, '"
				+ dateFormat
				+ "') AS isdn_user_last_modified, isdn.last_modified_by AS isdn_user_last_modified_by, memService.sor_id, sor.sor_name, "
				+ " isdnNP.network_profile_name AS isdn_network_profile_name,isdn.network_profile_id as isdn_network_profile_id, memService.sor_invariant_id ,iptv.portal_svc_provider as portal_svc_provider, "
				+ " servassoc.sor_id1, "
				+ " nvl(servassoc.sor_invariant_id1, '--NULL--') as sor_invariant_id1, sor2.sor_name as sor_name1, "
				+ " servassoc.sor_id2, "
				+ " nvl(servassoc.sor_invariant_id2, '--NULL--') as sor_invariant_id2, sor3.sor_name as sor_name2, "
				+ " servassoc.assigned_by as asso_assigned_by, servassoc.last_modified_by as asso_last_modified_by, "
				+ " TO_CHAR(servassoc.create_date, '"
				+ dateFormat
				+ "') AS asso_create_date, "
				+ " TO_CHAR(servassoc.last_modified, '"
				+ dateFormat
				+ "') AS asso_last_modified, memService.owned_by, "
				+ " memService.parent_sor_id, memService.parent_sor_invariant_id, memService.unification_pending, memService.uverse_service_ind, serv.major_service_id, serv.entity_type " //June 2011
				+ " FROM "
				+ " MEMBERSERVICE memService,SERVICE serv,STATUS stat,STATUS stat1,ISDNUser isdn, PORTALUSER portal, SYSTEMOFRECORD sor, NETWORKPROFILE isdnNP, IPTVUSER iptv, "
				+ " serviceassociation servassoc, SYSTEMOFRECORD sor2, SYSTEMOFRECORD sor3 "
				+ " WHERE "
				+ " serv.service_id = memService.service_id AND memService.group_status = stat1.status_code (+) AND memService.member_status = stat.status_code (+) AND memService.member_num = isdn.member_num (+) "
				+ " AND memService.service_id=portal.service_id (+) AND memService.member_num=portal.member_num (+) AND memService.sor_id=sor.sor_id (+) AND memService.member_num = ? "
				+ " AND isdn.network_profile_id = isdnNP.network_profile_id (+) AND memService.member_num = iptv.member_num(+) AND memService.service_id = iptv.service_id(+) "
				+ " AND servassoc.sor_id1(+) = memService.sor_id AND servassoc.sor_id1 = sor2.sor_id (+) AND servassoc.sor_id2 = sor3.sor_id (+) "
				+ " AND servassoc.sor_invariant_id1(+) = memService.sor_invariant_id ";*/

	//Added the new dial query for NAP2 by nk0565
	/**
	 * This query retrieves DIAL service info - pending_disconnect_date, member_num, service_id, member_status_code,
	 * group_status_code, group_status_name, member_status_name, terminate_date, create_date, last_modified,
	 * last_modified_by, service_name, service_type,
	 * dial.create_date, dial.last_modified, dial.last_modified_by,dial_network_profile_name
	 * from memberservice, service, status, dialuser tables by member_num.
	 */

	//Not retrieving site_id from memberservice table
/*		private  String queryForDIALService =
			" SELECT portal.portal_provider, portal.plite_ind, memService.instance_id, TO_CHAR(memService.pending_disconnect_date, '"
				+ dateFormat
				+ "') AS pending_disconnect_date, memService.member_num AS memService_member_num, memService.service_id AS service_id, "
				+ " memService.member_status AS member_status_code, memService.group_status AS group_status_code, "
				+ " stat1.status_name AS group_status_name, memService.nickname as service_nickname, "
				+ " memService.default_account, TO_CHAR(memService.date_default_est, '"
				+ dateFormat
				+ "') AS date_default_est, memService.cpni_impacted, "
				+ " stat.status_name AS member_status_name, TO_CHAR(memService.terminate_date, '"
				+ dateFormat
				+ "') AS terminate_date, serv.service_name, serv.service_type, serv.email_eligible, TO_CHAR(memService.create_date, '"
				+ dateFormat
				+ "') AS create_date, TO_CHAR(memService.last_modified, '"
				+ dateFormat
				+ "') AS last_modified, memService.last_modified_by AS last_modified_by, "
				+ " TO_CHAR(dial.create_date, '"
				+ dateFormat
				+ "') AS dial_user_create_date, TO_CHAR(dial.last_modified, '"
				+ dateFormat
				+ "') AS dial_user_last_modified, dial.last_modified_by AS dial_user_last_modified_by, memService.sor_id, sor.sor_name, dialNP.network_profile_name AS dial_network_profile_name , dial.network_profile_id as dial_network_profile_id "
				+ ", memService.sor_invariant_id ,memService.suspend_reason_code,"
				+ " iptv.portal_svc_provider as portal_svc_provider, "
				+ " servassoc.sor_id1, "
				+ " nvl(servassoc.sor_invariant_id1, '--NULL--') as sor_invariant_id1, sor2.sor_name as sor_name1, "
				+ " servassoc.sor_id2, "
				+ " nvl(servassoc.sor_invariant_id2, '--NULL--') as sor_invariant_id2, sor3.sor_name as sor_name2, "
				+ " servassoc.assigned_by as asso_assigned_by, servassoc.last_modified_by as asso_last_modified_by, "
				+ " TO_CHAR(servassoc.create_date, '"
				+ dateFormat
				+ "') AS asso_create_date, "
				+ " TO_CHAR(servassoc.last_modified, '"
				+ dateFormat
				+ "') AS asso_last_modified, memService.owned_by, "
				+ " memService.parent_sor_id, memService.parent_sor_invariant_id, memService.unification_pending, memService.uverse_service_ind, serv.major_service_id, serv.entity_type " //June 2011
				+ " FROM "
				+ " MEMBERSERVICE memService,SERVICE serv,STATUS stat,STATUS stat1,DIALUSER dial, PORTALUSER portal, SYSTEMOFRECORD sor, NETWORKPROFILE dialNP, IPTVUSER iptv, "
				+ " serviceassociation servassoc, SYSTEMOFRECORD sor2, SYSTEMOFRECORD sor3  "
				+ " WHERE "
				+ " serv.service_id = memService.service_id AND memService.group_status = stat1.status_code (+) AND memService.member_status = stat.status_code (+) AND memService.member_num = dial.member_num (+) "
				+ " AND memService.service_id=portal.service_id (+) AND memService.member_num=portal.member_num (+) AND memService.sor_id=sor.sor_id (+) AND memService.member_num = ? "
				+ " AND dial.network_profile_id = dialNP.network_profile_id (+) AND memService.member_num = iptv.member_num(+) AND memService.service_id = iptv.service_id(+) "
				+ " AND servassoc.sor_id1(+) = memService.sor_id AND servassoc.sor_id1 = sor2.sor_id (+) AND servassoc.sor_id2 = sor3.sor_id (+) "
				+ " AND servassoc.sor_invariant_id1(+) = memService.sor_invariant_id ";*/

	/**
	 * This query retrieves WIFI info - service_id, wifi_service_type, roaming_block_ind, create_date,
	 * last_modified, last_modified_by from wifiuser table by member_num
	 */
	/*	private  String queryForWIFIUser =
			"SELECT "
				+ "service_id, "
				+ "wifi_service_type, "
				+ "roaming_block_ind, "
				+ "TO_CHAR(create_date, '"
				+ dateFormat
				+ "') AS wifi_user_create_date, "
				+ "TO_CHAR(last_modified, '"
				+ dateFormat
				+ "') AS wifi_user_last_modified, "
				+ "last_modified_by AS wifi_user_last_modified_by "
				+ "FROM "
				+ "wifiuser "
				+ "WHERE "
				+ "member_num = ? ";

		private  String queryForISSUser =
			"SELECT service_id, service_provider, shared_id, subscription_req, subscription_conf, "
				+ "subscription_info, previous_provider, billing_ref_number, suppress_billing, "
				+ "TO_CHAR(initial_request_date, '" + dateFormat + "') AS initial_request_date, "
				+ "TO_CHAR(activation_date, '" + dateFormat + "') AS activation_date, "
				+ "TO_CHAR(create_date, '" + dateFormat + "') AS iss_user_create_date, "
				+ "TO_CHAR(last_modified, '" + dateFormat + "') AS iss_user_last_modified, "
				+ "last_modified_by AS iss_user_last_modified_by, password_venc "
				+ "FROM ISSUSER "
				+ "WHERE member_num = ? ";

		private  final ArrayList<Object> alIssAttributes = CommonUtil.getArrayList();
		{
			alIssAttributes.add(MPSDefs.DB_SERVICE_PROVIDER);
			alIssAttributes.add(MPSDefs.DB_SHARED_ID);
			alIssAttributes.add(MPSDefs.DB_SUBSCRIPTION_REQ);
			alIssAttributes.add(MPSDefs.DB_SUBSCRIPTION_CONF);
			alIssAttributes.add(MPSDefs.DB_SUBSCRIPTION_INFO);
			alIssAttributes.add(MPSDefs.DB_INITIAL_REQUEST_DATE);
			alIssAttributes.add(MPSDefs.DB_ACTIVATION_DATE);
			alIssAttributes.add(MPSDefs.DB_PREVIOUS_PROVIDER);
			alIssAttributes.add("iss_user_create_date");
			alIssAttributes.add("iss_user_last_modified");
			alIssAttributes.add("iss_user_last_modified_by");
			alIssAttributes.add(MPSDefs.DB_BILLING_REF_NUMBER);
			alIssAttributes.add(MPSDefs.DB_SUPPRESS_BILLING);
			alIssAttributes.add(MPSDefs.DB_PASSWORD_VENC);
		}

		private  String queryForTRIALUsers =
			"SELECT member_num, trial_type, TO_CHAR(create_date, '" + dateFormat + "') AS create_date, "+
			" last_modified_by, TO_CHAR(last_modified, '" + dateFormat + "') AS last_modified "+
			" from TRIALUSERS where member_num = ? ";

		private  String queryForInfoByCTN =
			"Select member_num from memberservice where instance_id = ? and instance_id is not null and service_id=23";

		private  String queryFromMemberIdentityByCTN =
			"Select member_num from memberidentity where identity = ? and identity_type='CTN'";

		private  String queryForMemberIdentity =
			"SELECT identity, identity_type " +
			" FROM MEMBERIDENTITY " +
			" WHERE member_num = ?";

		private  String queryForISSBillingInfo1 =
			"SELECT billing_id, price, charge_status "
			+ "FROM ISSBILLING "
			+ "WHERE billing_ref_number = ?";

		private  String queryForISSBillingInfo2 =
	 		"SELECT billing_id, price, billing_ref_number, charge_status "
			+ " FROM ISSBILLING "
			+ " WHERE sor = ? AND acct_type = ? AND charge_status = ?";

		private  String queryForISSBillingInfo3 =
	 		"SELECT billing_id, price, billing_ref_number, charge_status "
			+ " FROM ISSBILLING "
			+ " WHERE sor = ? AND acct_type = ?";


		private  String queryDeviceAndDeviceProfile =
			"SELECT " +
			" mdev.member_num, mdev.device_id, mdev.device_name, mdev.make, mdev.model, " +
			" sor.sor_name, mdev.category_id, c.category_name, " +
			" TO_CHAR(mdev.create_date, '" + dateFormat + "') as create_date, " +
			" TO_CHAR(mdev.last_modified, '" + dateFormat + "') as last_modified, " +
			" mdev.last_modified_by " +
			" FROM memberdevice mdev, systemofrecord sor, category c " +
			" WHERE mdev.sor_id=sor.sor_id (+) " +
			" AND mdev.category_id = c.category_id (+) " +
			" AND mdev.member_num =? ";

		private  String queryMemberLockout =
			"SELECT memloc.member_num, memloc.lockout_id, lo.lockout_name, memloc.set_number,"
			+ " memloc.failed_auth_count, TO_CHAR(memloc.lockout_expiration, '"
			+ dateFormat
			+ "') AS lockout_expiration, TO_CHAR(memloc.last_failed_auth, '"
			+ dateFormat
			+ "') AS last_failed_auth, TO_CHAR(memloc.create_date, '"
			+ dateFormat
			+ "') AS create_date, TO_CHAR(memloc.last_modified, '"
			+ dateFormat
			+ "') AS last_modified, memloc.last_modified_by "
			+ " FROM memberlockout memloc, lockout lo "
			+ " WHERE memloc.lockout_id = lo.lockout_id (+) "
			+ " AND memloc.member_num = ?";

		private  String queryDSLUserSql =
		" SELECT dsl.circuit_id, dsl.virtual_path, dsl.virtual_circuit, dsl.incoming_burst, dsl.incoming_limit,"
		+ " dsl.outgoing_burst, dsl.outgoing_limit, dsl.protocol_type, dsl.ip_address, dsl.ip_subnet, dsl.wtn, dsl.ip_netblock,"
		+ " dsl.dslam_type, dsl.tdsl_ind, dsl.ipv6rd_enabled, dsl.ipv6rd_manually_disabled, dsl.dns_err_optout_ind, "
		+ " TO_CHAR(dsl.create_date, '"
		+ dateFormat
		+ "') AS dsl_user_create_date, TO_CHAR(dsl.last_modified, '"
		+ dateFormat
		+ "') AS dsl_user_last_modified, dsl.last_modified_by AS dsl_user_last_modified_by,"
		+ " dslNP.network_profile_name AS dsl_network_profile_name, dsl.network_profile_id as dsl_network_profile_id"
		+ " FROM  DSLUser dsl, NETWORKPROFILE dslNP"
		+ " WHERE"
		+ " dsl.network_profile_id = dslNP.network_profile_id (+)"
		+ " AND dsl.member_num = ? ";*/

	/**
	 * This method retrieves all information related to a user from the database.
	 * It uses the input HashMap which contains key-value pairs for various user attributes like member number, group number, service name, group status, member status, etc.
	 * The method first checks if the jdbcTemplate is null. If it is, it returns an error status.
	 * Then it retrieves various user attributes from the input HashMap and converts them to the appropriate data types.
	 * It also retrieves the user ID, member status, and group status from the DBHelper.
	 * If any of these values are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param inputParamHs A HashMap containing the details of the user's information to be retrieved.
	 * @param logger A Logger object for logging any necessary information.
	 * @return A HashMap containing the status of the operation and the retrieved user's information.
	 */
	public HashMap getInfo(Map inputParamHs, Logger logger) {

		String thisMethod = ".getInfo.";
		Date startTime = new Date();

		// This Method will be used to get the Member Info from the Member, MemberGroup and MemberService, DSLUser and ISDNUser Tables.
		// The Member name and The Domain name should be passed to get the member Info.
		// Db Connection should be passed from the caller.

		logger.info("{}{}DBTOOLS000 : InpParam : {}", CLASS_NAME, thisMethod, HtmlUtils.htmlEscape(String.valueOf(inputParamHs)));

		long memNumVal = 0;

		boolean member_name = false;
		boolean domain_name = false;
		boolean member_num = false;
		boolean bIsBan = false;
		boolean bRolesAlreadyQueried = false;
		boolean bMemberSvcAttrQueried = false;

		String errorCode = "";
		String serviceName = "";
		String sAppStatusCode = null;
		String sAppInfo = null;
		String sTransactionName = null;

		String memberNameValue = null;
		String domainNameValue = null;
		String memberNumValue = null;
		String accessNameValue = null;
		String sBan = null;
		String sMember_num = null;
		String sSlidMemberNum = null;

		String dbBan = null;
		String dbSorName = null;
		String dbDomain = null;
		String dbAccountType = null;

		String servicesKey = MPSDefs.SERVICES;


		List<Object> objectList = new ArrayList<Object>();
		List alQueryResponse = null;

		HashMap MemServices = null;
		HashMap servicesHash = null;
		HashMap userServiceHash = null;

		HashMap hmMemberServiceRoles = null;
		HashMap hmMemberServiceAttributes = null;
		ArrayList alQueryRolesSvcList = null;
		ArrayList alSvcNotSorInvariantIds = CommonUtil.getArrayList();
		ArrayList alValidAccountsForLoyaltyInfo = null;
		// Check the connection obj first.If empty return an error.
		if (jdbcTemplate == null) {
			MemServices = CommonErrorMap.makeCategoryMap(
					CErrorDefs.ERR_SYS_APPL_NUM, "jdbcTemplate is null.");
			logger.error("response : " + MemServices);
			return MemServices;
		}

		if (logger == null) {
			// Logger object is null , Return error HashMap
			MemServices =
					StatusMsg.makeSQLStatus(
							MPSDefs.ERR_EMPTY,
							MPSDefs.ERR_EMPTY_MSG,
							MPSDefs.SQL_ERR,
							MPSDefs.SQL_ERR_MSG,
							MPSDefs.NO_ROW_UPDATED);
			logger.info("DBTOOLS5 : Logger object is null");

			return MemServices;

		}

		// Check if the HashMap contains the desired keys and the values are not null.
		if (inputParamHs == null) {
			MemServices =
					StatusMsg.makeSQLStatus(
							MPSDefs.ERR_HASHMAP_EMP,
							MPSDefs.ERR_HASHMAP_EMP_MSG,
							MPSDefs.SQL_ERR,
							MPSDefs.SQL_ERR_MSG,
							MPSDefs.NO_ROW_UPDATED);
			logger.info("DBTOOLS6 : "+
					"Empty HashMap passed");

			return MemServices;
		}

		try {

			//Retrieve member_name, domain_name, member_num values from input hash.
			memberNameValue = (String) inputParamHs.get(MPSDefs.DB_MEMBER_NAME);
			domainNameValue = (String) inputParamHs.get(MPSDefs.DB_DOMAIN_NAME);
			memberNumValue = (String) inputParamHs.get(MPSDefs.DB_MEMBER_NUM);
			sBan = (String) inputParamHs.get(MPSDefs.DB_BAN);
			String sQueryByEmailAliasHandle = (String) inputParamHs.get(MPSDefs.QUERY_BY_EMAIL_ALIAS_HANDLE_FLAG);
			String sQueryFraudLock = (String) inputParamHs.get(MPSDefs.QUERY_FRAUD_LOCK_FLAG); //1510

			/*//1502 - LoCo
			String stQueryLoyaltyDetails = (String) inputParamHs.get(MPSDefs.QUERY_LOYALTY_DETAILS_FLAG);
			if (stQueryLoyaltyDetails != null && stQueryLoyaltyDetails.equals(MPSDefs.YES)) {

				String stValidAccountsForLoyaltyInfo = minf.getvalue(CommonDefs.PROP_VALID_ACCOUNTS_FOR_LOYALTY.trim());
				logger.info("DBTOOLS15.11 : "+ "VALID_ACCOUNTS_FOR_LOYALTY" + " from config ::" + stValidAccountsForLoyaltyInfo);

				if (stValidAccountsForLoyaltyInfo == null || stValidAccountsForLoyaltyInfo.isEmpty()) {
					sAppInfo = "VALID_ACCOUNTS_FOR_LOYALTY is null or empty";
					MemServices = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, sAppInfo);
					logger.error("TMS-5.2.2.2 : "+ sAppInfo);
					return MemServices;
				} else {
					alValidAccountsForLoyaltyInfo = CommonUtil.parseToArray(stValidAccountsForLoyaltyInfo, CommonDefs.VALUE_SEPARATOR_CHAR);
					logger.info("DBTOOLS15.12 : "+ "Arraylist of VALID_ACCOUNTS_FOR_LOYALTY" + " from config ::" + alValidAccountsForLoyaltyInfo);
				}
			}*/

			if (memberNameValue == null && domainNameValue == null &&
					memberNumValue == null && sBan == null)
			{
				MemServices = StatusMsg.makeSQLStatus(
						MPSDefs.ERR_EMPTY,
						MPSDefs.ERR_EMPTY_MSG,
						MPSDefs.SQL_ERR,
						MPSDefs.SQL_ERR_MSG,
						MPSDefs.NO_ROW_UPDATED);
				logger.info("DBTOOLS7 : "+
						"Required fields missing");

				return MemServices;
			}

			if (sBan != null && sBan.trim().length() > 0){
				bIsBan = true;
			}

			if(!bIsBan){
				if ((memberNameValue != null)
						&& (memberNameValue.trim().length() > 0)) {

					member_name = true;
				}

				if ((domainNameValue != null)
						&& (domainNameValue.trim().length() > 0)) {

					domain_name = true;
				}

				if ((memberNumValue != null)
						&& (memberNumValue.trim().length() > 0)) {

					member_num = true;
				}
			}

			if(bIsBan){
				logger.debug(CLASS_NAME + thisMethod +"DBTOOLS8 : "+
						"Ban Query = " + firstQueryBan);

					/*preparedStatementForFirstQuery =
						connection.prepareStatement(firstQueryBan);
					preparedStatementForFirstQuery.setString(1, sBan);	*/
				objectList.add(sBan);
				alQueryResponse = jdbcTemplate.queryForList(new String(firstQueryBan), objectList.toArray(new Object[objectList.size()]));
			}else{
				if (member_num) {
					logger.debug(CLASS_NAME + thisMethod +"DBTOOLS9 : "+
							"Query = " + firstQueryMemNum);

					/*preparedStatementForFirstQuery =
						connection.prepareStatement(firstQueryMemNum);
					preparedStatementForFirstQuery.setString(1, memberNumValue);*/
					objectList.add(memberNumValue);
					alQueryResponse = jdbcTemplate.queryForList(new String(firstQueryMemNum), objectList.toArray(new Object[objectList.size()]));
				}

				if ((member_name && domain_name) && (!member_num))
				{
					String dynSql = "";
					if (domainNameValue != null && domainNameValue.equals(MPSDefs.SLID_DUM)) {
						dynSql = " AND mem.parent_child_ind='S' ";
					} else if (sQueryByEmailAliasHandle != null && sQueryByEmailAliasHandle.equalsIgnoreCase(MPSDefs.YES)) {
						dynSql = " AND mem.parent_child_ind in ('P','C','E') ";
					}
					else {
						dynSql = " AND mem.parent_child_ind in ('P','C') ";
					}

					logger.debug(CLASS_NAME + thisMethod +"DBTOOLS10 : "+
							"Query = " + firstQueryMemDomainName + dynSql);

					/*preparedStatementForFirstQuery =
						connection.prepareStatement(firstQueryMemDomainName + dynSql);

					preparedStatementForFirstQuery.setString(1, memberNameValue);
					preparedStatementForFirstQuery.setString(2, domainNameValue);*/
					objectList.add(memberNameValue);
					objectList.add(domainNameValue);

					alQueryResponse = jdbcTemplate.queryForList(new String(firstQueryMemDomainName + dynSql), objectList.toArray(new Object[objectList.size()]));
				}
			}


			long tTime = 0;
			Date dtStartDate = new Date();
			logger.debug(CLASS_NAME + thisMethod +"DBTOOLS11 : "+ "Query start time");

			//now execute prepared statement
			/*resultSetForFirstQuery =
				preparedStatementForFirstQuery.executeQuery();*/



			tTime = (System.currentTimeMillis() - dtStartDate.getTime());

			logger.info(CLASS_NAME + thisMethod +"QUERY999 : "+
					"Total time taken to execute query = " + tTime
					+ " milliseconds");


			//boolean hasRecords = resultSetForFirstQuery.next();
			String sSecReqVal = null;
			boolean bIsSercutyAllYes = false;

			int countFoundHandlesInDB = 0;



			// Iterate through the result set. Populate and return HashMap.
			for(int j=0; j<alQueryResponse.size(); j++) {
				Map hmQueryResponse = (Map)alQueryResponse.get(j);

				Iterator itr = hmQueryResponse.keySet().iterator();
				while(itr.hasNext()){
					String key = (String)itr.next();
					Object value = hmQueryResponse.get(key);

					String strValue = (value == null ? null : value.toString());

					hmQueryResponse.put(key, strValue);
				}

				MemServices = CommonUtil.getHashMap();//new HashMap();

				MemServices.put(MPSDefs.APP_STATUS_CODE, MPSDefs.MPS_SUCCESS);
				MemServices.put(MPSDefs.APP_STATUS_MSG, MPSDefs.MPS_ALL_OK);
				MemServices.put(MPSDefs.SQLCODE, MPSDefs.SQL_SUCCESS);
				MemServices.put(MPSDefs.SQLMSG, MPSDefs.SQL_SUCCESS_MSG);

				//change by gp371a: to support FN Users
				memNumVal =
						Long.parseLong(hmQueryResponse.get(MPSDefs.DB_MEMBER_NUM).toString());
				accessNameValue =
						(String)hmQueryResponse.get(MPSDefs.DB_ACCESS_NAME);
				String memberStateValue =
						(String)hmQueryResponse.get(MPSDefs.DB_MEMBER_STATE);

				dbBan = (String)hmQueryResponse.get(MPSDefs.DB_BAN);
				dbSorName = (String)hmQueryResponse.get(MPSDefs.DB_SOR_NAME);
				dbDomain = (String)hmQueryResponse.get(MPSDefs.DB_DOMAIN_NAME);

				MemServices.put(MPSDefs.DB_BAN,dbBan);

				MemServices.put(MPSDefs.DB_ENC_PASSWORD_VENC,
						(String)hmQueryResponse.get(MPSDefs.DB_ENC_PASSWORD_VENC));
				MemServices.put(MPSDefs.DB_MD5_PASSWORD_VENC,
						(String)hmQueryResponse.get(MPSDefs.DB_MD5_PASSWORD_VENC));
				MemServices.put(MPSDefs.DB_SHA1_PASSWORD_VENC,
						(String)hmQueryResponse.get(MPSDefs.DB_SHA1_PASSWORD_VENC));
				MemServices.put(MPSDefs.DB_DES3_PASSWORD_VENC,
						(String)hmQueryResponse.get(MPSDefs.DB_DES3_PASSWORD_VENC));
				MemServices.put(MPSDefs.DB_SSHA_PASSWORD_VENC,
						(String)hmQueryResponse.get(MPSDefs.DB_SSHA_PASSWORD_VENC));
				// 2103 -  SSHA-256 encryption changes
				String genericPasswordEncryptionType = PropertyManager.getProperty(CommonDefs.MOUPConfig,
						CommonDefs.GENERIC_PASSWORD_ENCRYPTION_TYPE);
				if (genericPasswordEncryptionType != null && !genericPasswordEncryptionType.isEmpty()) {
					MemServices.put(MPSDefs.DB_GEN_PASSWORD_VENC,
							(String) hmQueryResponse.get(MPSDefs.DB_GEN_PASSWORD_VENC)); // R2011:PWD encryption
					MemServices.put(MPSDefs.DB_GEN_PASSWORD_TYPE,
							(String) hmQueryResponse.get(MPSDefs.DB_GEN_PASSWORD_TYPE)); // R2011:PWD encryption
				}
				MemServices.put(
						MPSDefs.DB_DELETE_REQUEST_DATE,
						(String)hmQueryResponse.get(
								MPSDefs.DB_DELETE_REQUEST_DATE));
				MemServices.put(
						MPSDefs.DB_TOKEN,
						(String)hmQueryResponse.get(MPSDefs.DB_TOKEN));
				MemServices.put(
						MPSDefs.DB_REMARKS,
						(String)hmQueryResponse.get(MPSDefs.DB_REMARKS));

				//change by gp371a: to support FN Users
				sMember_num = Long.toString(memNumVal);
				MemServices.put(
						MPSDefs.DB_MEMBER_NUM,
						Long.toString(memNumVal));

				MemServices.put(
						MPSDefs.DB_MEMBER_NAME,
						(String)hmQueryResponse.get(MPSDefs.DB_MEMBER_NAME));
				MemServices.put(
						MPSDefs.DB_GROUP_NUM,
						hmQueryResponse.get(MPSDefs.DB_GROUP_NUM).toString());
				MemServices.put(
						MPSDefs.DB_DOMAIN_NAME,
						(String)hmQueryResponse.get(MPSDefs.DB_DOMAIN_NAME));
				MemServices.put(
						MPSDefs.DB_DOMAIN_ID,
						(String)hmQueryResponse.get(MPSDefs.DB_DOMAIN_ID).toString());
				MemServices.put(
						MPSDefs.DB_ENC_PASSWORD,
						(String)hmQueryResponse.get(MPSDefs.DB_ENC_PASSWORD));
				MemServices.put(
						MPSDefs.DB_MD5_PASSWORD,
						(String)hmQueryResponse.get(MPSDefs.DB_MD5_PASSWORD));
				MemServices.put(
						MPSDefs.DB_LANGUAGE,
						(String)hmQueryResponse.get(MPSDefs.DB_LANGUAGE));

				MemServices.put(
						MPSDefs.DB_TOS_REJECT_DATE,
						(String)hmQueryResponse.get(MPSDefs.DB_TOS_REJECT_DATE));
				MemServices.put(
						MPSDefs.DB_NUM_TOS_REJECTS,
						(String)hmQueryResponse.get(MPSDefs.DB_NUM_TOS_REJECTS));
				MemServices.put(
						MPSDefs.DB_ALERT_IND,
						(String)hmQueryResponse.get(MPSDefs.DB_ALERT_IND));

				MemServices.put(
						MPSDefs.DB_PARENT_CHILD_IND,
						(String)hmQueryResponse.get(
								MPSDefs.DB_PARENT_CHILD_IND));
				MemServices.put(MPSDefs.DB_MEMBER_STATE, memberStateValue);
				MemServices.put(
						MPSDefs.DB_AGG_ACCESS_STATUS,
						(String)hmQueryResponse.get(
								MPSDefs.DB_AGG_ACCESS_STATUS));
				MemServices.put(
						MPSDefs.DB_AGG_SERVICE_STATUS,
						(String)hmQueryResponse.get(
								MPSDefs.DB_AGG_SERVICE_STATUS));
				MemServices.put(
						MPSDefs.DB_MAILHOST,
						(String)hmQueryResponse.get(MPSDefs.DB_MAILHOST));
				MemServices.put(
						MPSDefs.DB_FULLNAME,
						(String)hmQueryResponse.get(MPSDefs.DB_FULLNAME));
				MemServices.put(
						MPSDefs.DB_ACCOUNT_TYPE,
						(String)hmQueryResponse.get(MPSDefs.DB_ACCOUNT_TYPE));

				dbAccountType = (String)hmQueryResponse.get(MPSDefs.DB_ACCOUNT_TYPE);

				MemServices.put(
						MPSDefs.DB_OPTOUT_IND,
						(String)hmQueryResponse.get(MPSDefs.DB_OPTOUT_IND));
				MemServices.put(
						MPSDefs.DB_MIGRATION_IND,
						(String)hmQueryResponse.get(MPSDefs.DB_MIGRATION_IND));
				MemServices.put(
						MPSDefs.DB_MIGRATION_DATE,
						(String)hmQueryResponse.get(
								MPSDefs.DB_MIGRATION_DATE));
				MemServices.put(
						MPSDefs.DB_PARENT_NAME,
						(String)hmQueryResponse.get(MPSDefs.DB_PARENT_NAME));
				MemServices.put(
						MPSDefs.DB_PARENT_DOMAIN,
						(String)hmQueryResponse.get(MPSDefs.DB_PARENT_DOMAIN));
				MemServices.put(
						MPSDefs.DB_SOR_ID,
						(String)hmQueryResponse.get(MPSDefs.DB_SOR_ID));
				MemServices.put(
						MPSDefs.DB_SOR_NAME,
						(String)hmQueryResponse.get(MPSDefs.DB_SOR_NAME));
				MemServices.put(
						MPSDefs.DB_ACCESS_ID,
						(String)hmQueryResponse.get(MPSDefs.DB_ACCESS_ID));
				MemServices.put(MPSDefs.DB_ACCESS_NAME, accessNameValue);
				MemServices.put(
						MPSDefs.DB_CREATE_DATE,
						(String)hmQueryResponse.get(MPSDefs.DB_CREATE_DATE));
				MemServices.put(
						MPSDefs.DB_LAST_MODIFIED,
						(String)hmQueryResponse.get(MPSDefs.DB_LAST_MODIFIED));
				MemServices.put(
						MPSDefs.DB_LAST_MODIFIED_BY,
						(String)hmQueryResponse.get(
								MPSDefs.DB_LAST_MODIFIED_BY));
				MemServices.put(
						MPSDefs.DB_PREMIUM_800_IND,
						(String)hmQueryResponse.get(
								MPSDefs.DB_PREMIUM_800_IND));
				MemServices.put(
						MPSDefs.DB_BULK_BILLING_IND,
						(String)hmQueryResponse.get(
								MPSDefs.DB_BULK_BILLING_IND));
				MemServices.put(
						MPSDefs.DB_ACCESS_CODE,
						(String)hmQueryResponse.get(MPSDefs.DB_ACCESS_CODE));

				MemServices.put(
						MPSDefs.DB_SHA1_PASSWORD,
						(String)hmQueryResponse.get(MPSDefs.DB_SHA1_PASSWORD));

				MemServices.put(
						MPSDefs.DB_DES3_PASSWORD,
						(String)hmQueryResponse.get(MPSDefs.DB_DES3_PASSWORD));
				MemServices.put(
						MPSDefs.DB_FAILED_AUTH_COUNT,
						(String)hmQueryResponse.get(MPSDefs.DB_FAILED_AUTH_COUNT));
				MemServices.put(
						MPSDefs.DB_PASSWORD_DIRTY,
						(String)hmQueryResponse.get(
								MPSDefs.DB_PASSWORD_DIRTY));
				MemServices.put(
						MPSDefs.DB_CONTACT_EMAIL,
						(String)hmQueryResponse.get(MPSDefs.DB_CONTACT_EMAIL));
				MemServices.put(
						MPSDefs.DB_CONTACT_EMAIL_VALID,
						(String)hmQueryResponse.get(
								MPSDefs.DB_CONTACT_EMAIL_VALID));

				MemServices.put(
						MPSDefs.DB_CREDIT_CHECKED_IND,
						(String)hmQueryResponse.get(
								MPSDefs.DB_CREDIT_CHECKED_IND));
				MemServices.put(
						MPSDefs.DB_YREG_COMPLETE_IND,
						(String)hmQueryResponse.get(
								MPSDefs.DB_YREG_COMPLETE_IND));
				MemServices.put(
						MPSDefs.DB_LOCKOUT_TIMESTAMP,
						(String)hmQueryResponse.get(
								MPSDefs.DB_LOCKOUT_TIMESTAMP));
				MemServices.put(
						MPSDefs.DB_LC_FIRSTNAME,
						(String)hmQueryResponse.get(MPSDefs.DB_LC_FIRSTNAME));
				MemServices.put(
						MPSDefs.DB_LC_LASTNAME,
						(String)hmQueryResponse.get(MPSDefs.DB_LC_LASTNAME));
				MemServices.put(
						MPSDefs.DB_NICKNAME,
						(String)hmQueryResponse.get(MPSDefs.DB_NICKNAME));
				MemServices.put(
						MPSDefs.DB_GENDER,
						(String)hmQueryResponse.get(MPSDefs.DB_GENDER));

				MemServices.put(MPSDefs.DB_PROOFING_ZIP,
						CommonUtil.addHyphenInZIP((String)hmQueryResponse.get(MPSDefs.DB_PROOFING_ZIP)));

				MemServices.put(
						MPSDefs.DB_LAST_MEMBER_STATUS_NAME,
						(String)hmQueryResponse.get(MPSDefs.DB_LAST_MEMBER_STATUS_NAME));
				MemServices.put(
						MPSDefs.DB_LAST_MEMBER_STATUS_CODE,
						(String)hmQueryResponse.get(MPSDefs.DB_LAST_MEMBER_STATUS_CODE));
				MemServices.put(
						MPSDefs.DB_CONTACT_EMAIL_EST_DATE,
						(String)hmQueryResponse.get(MPSDefs.DB_CONTACT_EMAIL_EST_DATE));
				MemServices.put(
						MPSDefs.DB_PREVIOUS_CONTACT_EMAIL,
						(String)hmQueryResponse.get(MPSDefs.DB_PREVIOUS_CONTACT_EMAIL));

				MemServices.put(MPSDefs.DB_CSR_INITIATED_LOCKOUT_TS,
						(String)hmQueryResponse.get(MPSDefs.DB_CSR_INITIATED_LOCKOUT_TS));

				MemServices.put(MPSDefs.DB_BROWSER_LANGUAGE,
						(String)hmQueryResponse.get(MPSDefs.DB_BROWSER_LANGUAGE));

				MemServices.put (MPSDefs.DB_DSL_NET_PASSWORD,
						(String)hmQueryResponse.get(MPSDefs.DB_DSL_NET_PASSWORD));

				MemServices.put (MPSDefs.DB_DSL_NET_ENCR_TYPE,
						(String)hmQueryResponse.get(MPSDefs.DB_DSL_NET_ENCR_TYPE));

				MemServices.put (MPSDefs.DB_SSHA_PASSWORD,
						(String)hmQueryResponse.get(MPSDefs.DB_SSHA_PASSWORD));

				MemServices.put (MPSDefs.DB_CONTACT_EMAIL_STATUS,
						(String)hmQueryResponse.get(MPSDefs.DB_CONTACT_EMAIL_STATUS));

				sSlidMemberNum = (String)hmQueryResponse.get(MPSDefs.DB_SLID_MEMBER_NUM);
				MemServices.put (MPSDefs.DB_SLID_MEMBER_NUM, sSlidMemberNum);

				MemServices.put (MPSDefs.DB_AUTOGENERATED_IND,
						(String)hmQueryResponse.get(MPSDefs.DB_AUTOGENERATED_IND));
				MemServices.put (MPSDefs.DB_ACTIVATED_IND,
						(String)hmQueryResponse.get(MPSDefs.DB_ACTIVATED_IND));

				MemServices.put (MPSDefs.DB_ACTIVATED_DATE,
						(String)hmQueryResponse.get(MPSDefs.DB_ACTIVATED_DATE));

				MemServices.put (MPSDefs.DB_BIRTHDATE_VENC,
						(String)hmQueryResponse.get(MPSDefs.DB_BIRTHDATE_VENC));
				MemServices.put (MPSDefs.DB_PASSCODE_VENC,
						(String)hmQueryResponse.get(MPSDefs.DB_PASSCODE_VENC));
				MemServices.put (MPSDefs.DB_SECURITY_ANSWER_VENC,
						(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_ANSWER_VENC));

				MemServices.put (MPSDefs.DB_MAIN_CTN_OPT_OUT,
						(String)hmQueryResponse.get(MPSDefs.DB_MAIN_CTN_OPT_OUT));

				MemServices.put (MPSDefs.DB_ONL_QA_EST_DATE,
						(String)hmQueryResponse.get (MPSDefs.DB_ONL_QA_EST_DATE));

				if (inputParamHs.containsKey(MPSDefs.SECURITY_ALL_REQ)) {
					sSecReqVal =
							(String) inputParamHs.get(MPSDefs.SECURITY_ALL_REQ);
					if (sSecReqVal != null
							&& sSecReqVal.equalsIgnoreCase("Y")) {
						bIsSercutyAllYes = true;

						MemServices.put(
								MPSDefs.DB_LAST_FOUR_SSN,
								(String)hmQueryResponse.get(
										MPSDefs.DB_LAST_FOUR_SSN));
						MemServices.put(
								MPSDefs.DB_SECURITY_QUESTION,
								(String)hmQueryResponse.get(
										MPSDefs.DB_SECURITY_QUESTION));
						MemServices.put(
								"security_question_id",
								(String)hmQueryResponse.get(
										"security_question_id"));



						MemServices.put(
								MPSDefs.DB_SECURITY_QUESTION_TYPE,
								(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_TYPE));
						MemServices.put(
								MPSDefs.DB_SECURITY_QUESTION_ACTIVE,
								(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_ACTIVE));
						MemServices.put(
								MPSDefs.DB_SECURITY_QUESTION_ID_1,
								(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_ID_1));
						MemServices.put(
								MPSDefs.DB_SECURITY_QUESTION_1,
								(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_1));
						MemServices.put(
								MPSDefs.DB_SECURITY_ANSWER_1,
								(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_ANSWER_1));
						MemServices.put(
								MPSDefs.DB_SECURITY_QUESTION_1_TYPE,
								(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_1_TYPE));
						MemServices.put(
								MPSDefs.DB_SECURITY_QUESTION_1_ACTIVE,
								(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_1_ACTIVE));
						MemServices.put(
								MPSDefs.DB_SECURITY_QUESTION_ID_2,
								(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_ID_2));
						MemServices.put(
								MPSDefs.DB_SECURITY_QUESTION_2,
								(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_2));
						MemServices.put(
								MPSDefs.DB_SECURITY_ANSWER_2,
								(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_ANSWER_2));
						MemServices.put(
								MPSDefs.DB_SECURITY_QUESTION_2_TYPE,
								(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_2_TYPE));
						MemServices.put(
								MPSDefs.DB_SECURITY_QUESTION_2_ACTIVE,
								(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_2_ACTIVE));

						MemServices
								.put(MPSDefs.DB_SECURITY_ANSWER_1_VENC,
										(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_ANSWER_1_VENC));
						MemServices
								.put(MPSDefs.DB_SECURITY_ANSWER_2_VENC,
										(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_ANSWER_2_VENC));

					}
				}

				if(!bIsSercutyAllYes){

					if (inputParamHs.containsKey(MPSDefs.LAST_FOUR_SSN_REQ)) {
						sSecReqVal =
								(String) inputParamHs.get(
										MPSDefs.LAST_FOUR_SSN_REQ);
						if (sSecReqVal != null
								&& sSecReqVal.equalsIgnoreCase("Y")) {
							MemServices.put(
									MPSDefs.DB_LAST_FOUR_SSN,
									(String)hmQueryResponse.get(
											MPSDefs.DB_LAST_FOUR_SSN));
						}
					}
					if (inputParamHs
							.containsKey(MPSDefs.SECURITY_QUESTION_REQ)) {
						sSecReqVal =
								(String) inputParamHs.get(
										MPSDefs.SECURITY_QUESTION_REQ);
						if (sSecReqVal != null
								&& sSecReqVal.equalsIgnoreCase("Y")) {
							MemServices.put(
									MPSDefs.DB_SECURITY_QUESTION,
									(String)hmQueryResponse.get(
											MPSDefs.DB_SECURITY_QUESTION));
							MemServices.put(
									"security_question_id",
									(String)hmQueryResponse.get(
											"security_question_id"));
							MemServices.put(
									MPSDefs.DB_SECURITY_QUESTION_ID_1,
									(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_ID_1));
							MemServices.put(
									MPSDefs.DB_SECURITY_QUESTION_1,
									(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_1));
							MemServices.put(
									MPSDefs.DB_SECURITY_QUESTION_ID_2,
									(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_ID_2));
							MemServices.put(
									MPSDefs.DB_SECURITY_QUESTION_2,
									(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_2));
						}
					}
					if (inputParamHs
							.containsKey(MPSDefs.SECURITY_ANSWER_REQ)) {
						sSecReqVal =
								(String) inputParamHs.get(
										MPSDefs.SECURITY_ANSWER_REQ);
						if (sSecReqVal != null
								&& sSecReqVal.equalsIgnoreCase("Y")) {

							MemServices.put(
									MPSDefs.DB_SECURITY_ANSWER_1,
									(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_ANSWER_1));
							MemServices.put(
									MPSDefs.DB_SECURITY_ANSWER_2,
									(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_ANSWER_2));

							MemServices
									.put(MPSDefs.DB_SECURITY_ANSWER_1_VENC,
											(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_ANSWER_1_VENC));
							MemServices
									.put(MPSDefs.DB_SECURITY_ANSWER_2_VENC,
											(String)hmQueryResponse.get(MPSDefs.DB_SECURITY_ANSWER_2_VENC));
						}
					}
				}

				/*HashMap hmStatus  =  ProcessVoltageHelper.voltageDecryptSPIFields(MemServices, minf);
				sAppStatusCode 	  =  (String) hmStatus.get( CErrorDefs.COMMON_APP_STATUS_CODE );

				if (sAppStatusCode != null	&& !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {

					logger.info("DBTOOLS11.01 : "+"ProcessVoltageHelper:voltageDecryptSPIFields::stAppInfo="+(String) hmStatus.get(CommonDefs.COMMON_APP_INFO));

					MemServices = hmStatus;
					return MemServices;
				}*/

/*				if (!memberStateValue.equalsIgnoreCase(MPSDefs.RESERVED_STATE) ||
						(dbDomain != null && dbDomain.equalsIgnoreCase("slid.dum")) )
				{
					logger.debug("DBTOOLS16 : "+
						"GOING TO FETCH RECORDS FROM MEMBER SERVICE/DSL/DIAL/ISDN Tables");

					String query = createQueryForAccessService(accessNameValue);

					logger.info("DBTOOLS17 : "+
						"accessName: " + accessNameValue + ": Query is = " + query);

					preparedStatementForSecondQuery =
						connection.prepareStatement(query);
					preparedStatementForSecondQuery.setInt(1, memNumVal);

					long totTime = 0;
					Date tQueryTime = new Date();
					logger.debug("DBTOOLS18 : "+ "Query start time");

					resultSetForSecondQuery = preparedStatementForSecondQuery.executeQuery();

					totTime = (System.currentTimeMillis() - tQueryTime.getTime());

					logger.info("QUERY999 : "+
							"Total time taken to execute query = " + totTime + " milliseconds");

					servicesHash = CommonUtil.getHashMap();//new HashMap();

					while (resultSetForSecondQuery.next()) {
						serviceName =
							resultSetForSecondQuery.getString(
								MPSDefs.DB_SERVICE_NAME);
						logger.debug("DBTOOLS19 : "+
							"Service Name now is " + serviceName);

						if (serviceName.equalsIgnoreCase(MPSDefs.DSL_SERVICE))
						{
							userServiceHash =CommonUtil.getHashMap();// new HashMap();

							userServiceHash.put(MPSDefs.DB_SOR_INVARIANT_ID,
									resultSetForSecondQuery.getString(MPSDefs.DB_SOR_INVARIANT_ID));

							//Added for LS - pending_disconnect_date
							userServiceHash.put(
								MPSDefs.DB_PENDING_DISCONNECT_DATE,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_PENDING_DISCONNECT_DATE));

							userServiceHash.put(
								MPSDefs.DB_SERVICE_ID,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_SERVICE_ID));

							userServiceHash.put(MPSDefs.DB_SERVICE_TYPE,
								resultSetForSecondQuery.getString(MPSDefs.DB_SERVICE_TYPE));

							if (CommonDefs.SERVICE_VALUES.containsKey(serviceName))
								userServiceHash.put(MPSDefs.DB_SERVICE_NAME,
										CommonDefs.SERVICE_VALUES.get(serviceName));

							userServiceHash.put(
								MPSDefs.DB_MEMBER_STATUS_CODE,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_MEMBER_STATUS_CODE));
							userServiceHash.put(
								MPSDefs.DB_GROUP_STATUS_CODE,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_GROUP_STATUS_CODE));
							userServiceHash.put(
								MPSDefs.DB_GROUP_STATUS_NAME,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_GROUP_STATUS_NAME));
							userServiceHash.put(
								MPSDefs.DB_MEMBER_STATUS_NAME,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_MEMBER_STATUS_NAME));
							userServiceHash.put(
								MPSDefs.DB_MEMBER_TERMINATE_DATE,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_TERMINATE_DATE));

							userServiceHash.put(MPSDefs.DB_CREATE_DATE,
									resultSetForSecondQuery.getString(MPSDefs.DB_CREATE_DATE));

							userServiceHash.put(MPSDefs.DB_LAST_MODIFIED,
									resultSetForSecondQuery.getString(MPSDefs.DB_LAST_MODIFIED));

							userServiceHash.put(MPSDefs.DB_LAST_MODIFIED_BY,
									resultSetForSecondQuery.getString(MPSDefs.DB_LAST_MODIFIED_BY));

							//1406 PID265652: Updated to return DSLUSER data only when access_name=DSL since DSL can coexist with HSIA now
							if (accessNameValue.equals(MPSDefs.DSL_SERVICE) )
							{
								userServiceHash.put(MPSDefs.DB_CIRCUIT_ID,
										resultSetForSecondQuery.getString(MPSDefs.DB_CIRCUIT_ID));

								userServiceHash.put(MPSDefs.DB_VIRTUAL_PATH,
										resultSetForSecondQuery.getString(MPSDefs.DB_VIRTUAL_PATH));

								userServiceHash.put(MPSDefs.DB_VIRTUAL_CIRCUIT,
										resultSetForSecondQuery.getString(MPSDefs.DB_VIRTUAL_CIRCUIT));

								userServiceHash.put(MPSDefs.DB_INCOMING_BURST,
										resultSetForSecondQuery.getString(MPSDefs.DB_INCOMING_BURST));

								userServiceHash.put(MPSDefs.DB_INCOMING_LIMIT,
										resultSetForSecondQuery.getString(MPSDefs.DB_INCOMING_LIMIT));

								userServiceHash.put(MPSDefs.DB_OUTGOING_BURST,
										resultSetForSecondQuery.getString(MPSDefs.DB_OUTGOING_BURST));

								userServiceHash.put(MPSDefs.DB_OUTGOING_LIMIT,
										resultSetForSecondQuery.getString(MPSDefs.DB_OUTGOING_LIMIT));

								userServiceHash.put(MPSDefs.DB_PROTOCOL_TYPE,
										resultSetForSecondQuery.getString(MPSDefs.DB_PROTOCOL_TYPE));

								userServiceHash.put(MPSDefs.DB_IP_ADDRESS,
										resultSetForSecondQuery.getString(MPSDefs.DB_IP_ADDRESS));

								userServiceHash.put(MPSDefs.DB_IP_NETBLOCK,
										resultSetForSecondQuery.getString(MPSDefs.DB_IP_NETBLOCK));

								userServiceHash.put(MPSDefs.DB_IP_SUBNET,
										resultSetForSecondQuery.getString(MPSDefs.DB_IP_SUBNET));

								userServiceHash.put(MPSDefs.DB_WTN,
										resultSetForSecondQuery.getString(MPSDefs.DB_WTN));

								userServiceHash.put(MPSDefs.DSL_USER_CREATE_DATE,
										resultSetForSecondQuery.getString(MPSDefs.DSL_USER_CREATE_DATE));

								userServiceHash.put(MPSDefs.DSL_USER_LAST_MODIFIED,
										resultSetForSecondQuery.getString(MPSDefs.DSL_USER_LAST_MODIFIED));

								userServiceHash.put(MPSDefs.DSL_USER_LAST_MODIFIED_BY,
										resultSetForSecondQuery.getString(MPSDefs.DSL_USER_LAST_MODIFIED_BY));

								userServiceHash.put(MPSDefs.DB_DSLAM_TYPE,
										resultSetForSecondQuery.getString(MPSDefs.DB_DSLAM_TYPE ));

								userServiceHash.put(MPSDefs.DB_TDSL_IND,
										resultSetForSecondQuery.getString(MPSDefs.DB_TDSL_IND));

								//Added for June 2011 IPV6 project
								userServiceHash.put(MPSDefs.DB_IPV6RD_ENABLED,
									  	resultSetForSecondQuery.getString(MPSDefs.DB_IPV6RD_ENABLED));

								userServiceHash.put(MPSDefs.DB_IPV6RD_MANUALLY_DISABLED,
									  	resultSetForSecondQuery.getString(MPSDefs.DB_IPV6RD_MANUALLY_DISABLED));

								userServiceHash.put(MPSDefs.DB_NETWORK_PROFILE_NAME,
										resultSetForSecondQuery.getString(MPSDefs.DSL_NETWORK_PROFILE_NAME));

								userServiceHash.put(MPSDefs.DB_NETWORK_PROFILE_ID,
										resultSetForSecondQuery.getString("dsl_"+MPSDefs.DB_NETWORK_PROFILE_ID));

								//1502 PID268891 DNS Error Assist
								userServiceHash.put(MPSDefs.DB_DNS_ERR_OPTOUT_IND,
										resultSetForSecondQuery.getString(MPSDefs.DB_DNS_ERR_OPTOUT_IND));
							}
							else if (accessNameValue.equals(MPSDefs.HSIA_SERVICE) ) {

								userServiceHash = getDSLUserInfo(
										memNumVal, connection, userServiceHash, minf);
							}

							//Calcualte service_status for DSL service
							String service_status =
								MbrAttributes.calculateStatus(
									resultSetForSecondQuery.getString(
										MPSDefs.DB_MEMBER_STATUS_NAME),
									resultSetForSecondQuery.getString(
										MPSDefs.DB_GROUP_STATUS_NAME));

							userServiceHash.put(MPSDefs.SERVICE_STATUS, service_status);

							userServiceHash.put(MPSDefs.DB_SOR_ID,
									resultSetForSecondQuery.getString(MPSDefs.DB_SOR_ID));

							userServiceHash.put (MPSDefs.DB_SOR_NAME,
									resultSetForSecondQuery.getString(MPSDefs.DB_SOR_NAME));

							userServiceHash.put(MPSDefs.DB_EMAIL_ELIGIBLE,
									resultSetForSecondQuery.getString(MPSDefs.DB_EMAIL_ELIGIBLE));

							userServiceHash.put(MPSDefs.DB_SERVICE_NICKNAME,
									resultSetForSecondQuery.getString(MPSDefs.DB_SERVICE_NICKNAME));

							userServiceHash.put(MPSDefs.DB_DEFAULT_ACCOUNT,
							  		resultSetForSecondQuery.getString(MPSDefs.DB_DEFAULT_ACCOUNT));

							userServiceHash.put(MPSDefs.DB_DATE_DEFAULT_EST,
							  		resultSetForSecondQuery.getString(MPSDefs.DB_DATE_DEFAULT_EST));

							userServiceHash.put(MPSDefs.DB_CPNI_IMPACTED,
							  		resultSetForSecondQuery.getString(MPSDefs.DB_CPNI_IMPACTED));

							userServiceHash.put(MPSDefs.DB_SUSPEND_REASON_CODE,
							  		resultSetForSecondQuery.getString(MPSDefs.DB_SUSPEND_REASON_CODE));

							userServiceHash.put (MPSDefs.DB_ENTITY_TYPE,
									resultSetForSecondQuery.getString (MPSDefs.DB_ENTITY_TYPE));

						} else if (
							(serviceName.equalsIgnoreCase(MPSDefs.ISDN_SERVICE))
								|| (serviceName.equalsIgnoreCase(MPSDefs.ISDN2_SERVICE)))
						{
							userServiceHash = CommonUtil.getHashMap();//new HashMap();

							// Add sor_invariant_id for each hash  - RK6538 - LSR10
							userServiceHash.put(MPSDefs.DB_SOR_INVARIANT_ID,
									resultSetForSecondQuery.getString(MPSDefs.DB_SOR_INVARIANT_ID));

							userServiceHash.put(
									MPSDefs.DB_SOR_ID,
									resultSetForSecondQuery.getString(
										MPSDefs.DB_SOR_ID));
							userServiceHash.put(
										MPSDefs.DB_SOR_NAME,
										resultSetForSecondQuery.getString(
											MPSDefs.DB_SOR_NAME));
							//Added for LS - pending_disconnect_date
							userServiceHash.put(
								MPSDefs.DB_PENDING_DISCONNECT_DATE,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_PENDING_DISCONNECT_DATE));

							userServiceHash.put(
								MPSDefs.DB_SERVICE_ID,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_SERVICE_ID));

							userServiceHash.put(MPSDefs.DB_SERVICE_TYPE,
								resultSetForSecondQuery.getString(MPSDefs.DB_SERVICE_TYPE));


							if (CommonDefs.SERVICE_VALUES.containsKey(serviceName))
								userServiceHash.put(MPSDefs.DB_SERVICE_NAME,
										CommonDefs.SERVICE_VALUES.get(serviceName));

							userServiceHash.put(
								MPSDefs.DB_MEMBER_STATUS_CODE,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_MEMBER_STATUS_CODE));
							userServiceHash.put(
								MPSDefs.DB_GROUP_STATUS_CODE,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_GROUP_STATUS_CODE));
							userServiceHash.put(
								MPSDefs.DB_GROUP_STATUS_NAME,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_GROUP_STATUS_NAME));
							userServiceHash.put(
								MPSDefs.DB_MEMBER_STATUS_NAME,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_MEMBER_STATUS_NAME));
							userServiceHash.put(
								MPSDefs.DB_MEMBER_TERMINATE_DATE,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_TERMINATE_DATE));

							userServiceHash.put(
								MPSDefs.DB_IP_ADDRESS,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_IP_ADDRESS));
							userServiceHash.put(
								MPSDefs.DB_IP_NETBLOCK,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_IP_NETBLOCK));
							userServiceHash.put(
								MPSDefs.DB_IP_SUBNET,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_IP_SUBNET));
							userServiceHash.put(
								MPSDefs.DB_CREATE_DATE,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_CREATE_DATE));
							userServiceHash.put(
								MPSDefs.DB_LAST_MODIFIED,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_LAST_MODIFIED));
							userServiceHash.put(
								MPSDefs.DB_LAST_MODIFIED_BY,
								resultSetForSecondQuery.getString(
									MPSDefs.DB_LAST_MODIFIED_BY));
							userServiceHash.put(
								MPSDefs.ISDN_USER_CREATE_DATE,
								resultSetForSecondQuery.getString(
									MPSDefs.ISDN_USER_CREATE_DATE));
							userServiceHash.put(
								MPSDefs.ISDN_USER_LAST_MODIFIED,
								resultSetForSecondQuery.getString(
									MPSDefs.ISDN_USER_LAST_MODIFIED));
							userServiceHash.put(
								MPSDefs.ISDN_USER_LAST_MODIFIED_BY,
								resultSetForSecondQuery.getString(
									MPSDefs.ISDN_USER_LAST_MODIFIED_BY));

							//Calcualte service_status
							String service_status =
								MbrAttributes.calculateStatus(
									resultSetForSecondQuery.getString(
										MPSDefs.DB_MEMBER_STATUS_NAME),
									resultSetForSecondQuery.getString(
										MPSDefs.DB_GROUP_STATUS_NAME));

							userServiceHash.put (MPSDefs.SERVICE_STATUS, service_status);

							userServiceHash.put(MPSDefs.DB_EMAIL_ELIGIBLE,
									resultSetForSecondQuery.getString(MPSDefs.DB_EMAIL_ELIGIBLE));
							  userServiceHash.put(MPSDefs.DB_NETWORK_PROFILE_NAME,
									resultSetForSecondQuery.getString(MPSDefs.ISDN_NETWORK_PROFILE_NAME));

							  userServiceHash.put(MPSDefs.DB_NETWORK_PROFILE_ID,
										resultSetForSecondQuery.getString("isdn_"+MPSDefs.DB_NETWORK_PROFILE_ID));

							  //added by vs3652 for COLA Apiril 2010
							  userServiceHash.put(MPSDefs.DB_SERVICE_NICKNAME,
							  		resultSetForSecondQuery.getString(MPSDefs.DB_SERVICE_NICKNAME));
							  userServiceHash.put(MPSDefs.DB_DEFAULT_ACCOUNT,
							  		resultSetForSecondQuery.getString(MPSDefs.DB_DEFAULT_ACCOUNT));
							  userServiceHash.put(MPSDefs.DB_DATE_DEFAULT_EST,
							  		resultSetForSecondQuery.getString(MPSDefs.DB_DATE_DEFAULT_EST));
							  userServiceHash.put(MPSDefs.DB_CPNI_IMPACTED,
							  		resultSetForSecondQuery.getString(MPSDefs.DB_CPNI_IMPACTED));
							  userServiceHash.put (MPSDefs.DB_ENTITY_TYPE,
									resultSetForSecondQuery.getString (MPSDefs.DB_ENTITY_TYPE));

							  //1306- Updated for COPPA Changes
								userServiceHash.put(MPSDefs.DB_SUSPEND_REASON_CODE,
								  		resultSetForSecondQuery.getString(MPSDefs.DB_SUSPEND_REASON_CODE));
						}
						else if (serviceName.equalsIgnoreCase(MPSDefs.DIAL_SERVICE))
						{
							userServiceHash =
								getDialUserInfo(
									memNumVal,
									connection,
									resultSetForSecondQuery,
									minf);

							if (userServiceHash == null)
								//  getDialUserInfo failed
								{
									logger.info("DBTOOLS20 : "+
										"Can't get Dial info for member: getDialUserInfo() failed.");

								// create error HashMap
								MemServices =
									StatusMsg.makeInfoStatusMap(
										MPSDefs.ERR_INVALID_RECORD_DB_NUM,
										"No valid DIALUSER data for member_num "
											+ String.valueOf(memNumVal)
											+ ".");

								return MemServices;
							} //  end  getWifiUserInfo failed

						}//  end else serviceName.equalsIgnoreCase(DIAL_SERVICE)
						else if (serviceName.equalsIgnoreCase (MPSDefs.WIFI_SERVICE))
						{
							userServiceHash =
								getWifiUserInfo(
									memNumVal,
									connection,
									resultSetForSecondQuery,
									minf);
							if (userServiceHash == null)
								//  getWifiUserInfo failed
								{
								// log error message
								logger.info("DBTOOLS21 : "+
									"Can't get Wifi info for member: getWifiUserInfo() failed.");

								// create error HashMap
								MemServices =
									StatusMsg.makeInfoStatusMap(
										MPSDefs.ERR_INVALID_RECORD_DB_NUM,
										"No valid WIFIUSER data for member_num "
											+ String.valueOf(memNumVal)
											+ ".");

								return MemServices;
							} //  end  getWifiUserInfo failed

							// copy data into WIFI services HashMap

						} //  end else serviceName.equalsIgnoreCase(WIFI_SERVICE)
						else if (serviceName.equalsIgnoreCase(MPSDefs.ISS_SERVICE))
						{
								userServiceHash =
									getIssUserInfo(
										memNumVal,
										connection,
										resultSetForSecondQuery,
										minf);
								if (userServiceHash == null)
									{
									// log error message
									logger.info("DBTOOLS22 : "+
										"Can't get Iss info for member: getIssUserInfo() failed.");

									// create error HashMap
									MemServices =
										StatusMsg.makeInfoStatusMap(
											MPSDefs.ERR_INVALID_RECORD_DB_NUM,
											"No valid ISSUSER data for member_num "
												+ String.valueOf(memNumVal)
												+ ".");

									return MemServices;
								} //  end  getWifiUserInfo failed

								if (inputParamHs.containsKey(MPSDefs.WS_ISS_BILLING_INFO_REQ)) {
									String sIssBillingInfoReq = (String) inputParamHs.get(MPSDefs.WS_ISS_BILLING_INFO_REQ);

									if (sIssBillingInfoReq != null && sIssBillingInfoReq.equals(MPSDefs.YES)) {
										String sBillingRefNum = (String) userServiceHash.get(MPSDefs.DB_BILLING_REF_NUMBER);

										logger.info("DBTOOLS23 : "+
												"ISS billing_ref_number is: " + sBillingRefNum);

										if (sBillingRefNum != null && sBillingRefNum.trim().length() > 0) {
											preparedStatementForBillingInfo =
												connection.prepareStatement(queryForISSBillingInfo1);

											logger.info("DBTOOLS24 : "+
												queryForISSBillingInfo1);

											preparedStatementForBillingInfo.setString(1, sBillingRefNum);

											long pTime = 0;
											Date dtQueryTime = new Date();
											logger.debug("DBTOOLS25 : "+ "Query start time");

											resultSetForIssBillingInfo =
												preparedStatementForBillingInfo.executeQuery();

											// changes done by vg558n to return time in milliseconds for
											// APRIL2011 start

											//Calculate the total time taken to execute the query
											pTime = (System.currentTimeMillis() - dtQueryTime.getTime()) / 1000;
											minf.log(Mpslog.info, 0, thisClass, thisMethod, "QUERY999",
												"Total time taken to execute query = " + new Long(pTime).toString() + " sec");

											pTime = (System.currentTimeMillis() - dtQueryTime
												.getTime());

										logger.info("QUERY999 : "+
												"Total time taken to execute query = "
														+ pTime
														+ " milliseconds");

											// changes done by vg558n to return time in milliseconds for
											// APRIL2011 end
											int rowcount = 0;

											String sPrice = null;
											String sChargeStatus = null;
											String sBillingId = null;

											while (resultSetForIssBillingInfo.next()) {
												++rowcount;

												sPrice = resultSetForIssBillingInfo.getString(MPSDefs.DB_PRICE);
												sChargeStatus = resultSetForIssBillingInfo.getString(MPSDefs.DB_CHARGE_STATUS);
												sBillingId = resultSetForIssBillingInfo.getString(MPSDefs.DB_BILLING_ID);
											} // end while (resultSetForIssBillingInfo.next())

											if (rowcount == 0) {
												logger.info("DBTOOLS26 : "+ "No row found in ISSBilling table");
											}
											else {
												userServiceHash.put(MPSDefs.DB_PRICE, sPrice);
												userServiceHash.put(MPSDefs.DB_CHARGE_STATUS, sChargeStatus);
												userServiceHash.put(MPSDefs.DB_BILLING_ID, sBillingId);
											}
										} //end of billing_id is not null
									} //end of wsIssBillingInfoReq flag is Y
								} // end input contains WS_ISS_BILLING_INFO_REQ

								if (inputParamHs.containsKey(MPSDefs.WS_BILLING_INFO_REQ))
								{
									HashMap hmBillingInput = CommonUtil.getHashMap();//new HashMap();
									HashMap hmBillingResp = null;

									HashMap hmBillingInfoReq = (HashMap) inputParamHs.get(MPSDefs.WS_BILLING_INFO_REQ);
									String sQueryAllBillingInfoFlag = null;

									if (hmBillingInfoReq != null && !hmBillingInfoReq.isEmpty()) {
										hmBillingInput.put(MPSDefs.DB_CHARGE_STATUS,
												hmBillingInfoReq.get(MPSDefs.WS_CHARGE_STATUS));

										if (hmBillingInfoReq.get(MPSDefs.WS_ACCOUNT_TYPE) != null)
											hmBillingInput.put(MPSDefs.DB_ACCOUNT_TYPE, hmBillingInfoReq.get(MPSDefs.WS_ACCOUNT_TYPE));
										else
											hmBillingInput.put(MPSDefs.DB_ACCOUNT_TYPE, dbAccountType);

										hmBillingInput.put(MPSDefs.DB_SERVICE_TYPE, MPSDefs.ISS_SERVICE);

										if (hmBillingInfoReq.get(MPSDefs.WS_SOR_NAME) != null)
											hmBillingInput.put(CommonDefs.SOR, hmBillingInfoReq.get(MPSDefs.WS_SOR_NAME));
										else
											hmBillingInput.put(CommonDefs.SOR, dbSorName);

										sQueryAllBillingInfoFlag = (String) hmBillingInfoReq.get(MPSDefs.QUERY_ALL_BILLING_INFO_FLAG);

										if (sQueryAllBillingInfoFlag != null && sQueryAllBillingInfoFlag.trim().length() > 0)
											hmBillingInput.put(MPSDefs.QUERY_ALL_BILLING_INFO_FLAG, sQueryAllBillingInfoFlag);
									}

									if (hmBillingInput != null && !hmBillingInput.isEmpty()) {

										hmBillingResp = getBillingInfo(hmBillingInput, minf, connection);

										if (hmBillingResp != null) {
											sAppStatusCode = (String) hmBillingResp.get( CErrorDefs.COMMON_APP_STATUS_CODE );

											if (sAppStatusCode != null && sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS) )
											{
												if (sQueryAllBillingInfoFlag != null && sQueryAllBillingInfoFlag.equals("Y"))
												{
													MemServices.put(MPSDefs.DB_NEW_BILLING_ID_PAID,
															hmBillingResp.get(MPSDefs.DB_NEW_BILLING_ID_PAID));
													MemServices.put(MPSDefs.DB_NEW_BILLING_REF_NUMBER_PAID,
														hmBillingResp.get(MPSDefs.DB_NEW_BILLING_REF_NUMBER_PAID));
													MemServices.put(MPSDefs.DB_NEW_BILLING_ID_FREE,
															hmBillingResp.get(MPSDefs.DB_NEW_BILLING_ID_FREE));
													MemServices.put(MPSDefs.DB_NEW_BILLING_REF_NUMBER_FREE,
														hmBillingResp.get(MPSDefs.DB_NEW_BILLING_REF_NUMBER_FREE));
												} else {
													MemServices.put(MPSDefs.DB_NEW_BILLING_ID, hmBillingResp.get(MPSDefs.DB_BILLING_ID));
													MemServices.put(MPSDefs.DB_NEW_PRICE, hmBillingResp.get(MPSDefs.DB_PRICE));
													MemServices.put(MPSDefs.DB_NEW_BILLING_REF_NUMBER,
														hmBillingResp.get(MPSDefs.DB_BILLING_REF_NUMBER));
												}
											}
										}
									}
								} // end of contains WS_BILLING_INFO_REQ hash

							} //  end else serviceName is ISS_SERVICE
						else {

							//userServiceHash = new HashMap();
							if(servicesHash != null && servicesHash.containsKey(serviceName)){
								userServiceHash = (HashMap) servicesHash.get(serviceName);
							}else{
								userServiceHash =CommonUtil.getHashMap();// new HashMap();
							}

							String instanceId = resultSetForSecondQuery.getString (MPSDefs.DB_INSTANCE_ID);

							//if (instanceId != null && (!instanceId.equals(MPSDefs.DB_NON_LS_INSTANCE_ID)))
							if (CommonUtil.getInstanceServices(logger).contains(serviceName)) //1610 - Updated for PID 287102 to treat dynamic services too as instance services
							{
								HashMap instanceHash =CommonUtil.getHashMap();// new HashMap();

								if (! bRolesAlreadyQueried && inputParamHs.containsKey(MPSDefs.QUERY_ROLES_INFO_FLAG))
								{
									alQueryRolesSvcList =  (ArrayList) inputParamHs.get(MPSDefs.QUERY_ROLES_INFO_FLAG);

									logger.deug("DBTOOLS27 : "+
											"alQueryRolesSvcList: " + alQueryRolesSvcList);

									HashMap hmDbInput = CommonUtil.getHashMap();//new HashMap();
									hmDbInput.put(MPSDefs.DB_MEMBER_NUM, sMember_num);

									HashMap hmRolesResponse = MPSDB_GetMemberRoles_H.getMemberServiceRoles( hmDbInput, connection, minf);

									if (hmRolesResponse == null)
									{
										sAppInfo =  "MPSDB_GetMemberRoles_H.getMemberServiceRoles helper returned null.";
										logger.error("DBTOOLS28 : "+ sAppInfo);
										hmRolesResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo );
										return hmRolesResponse;
									}

									sAppStatusCode = (String) hmRolesResponse.get( CErrorDefs.COMMON_APP_STATUS_CODE );

									if(sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS) )
									{
										if(sAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND) )
										{
											sAppInfo = "Member service roles not found for member_num - " + sMember_num;
											logger.info("DBTOOLS29 : "+ sAppInfo);
										} else {
											MemServices.clear();
											MemServices.putAll(hmRolesResponse);
											return  MemServices;
										}
									}

									bRolesAlreadyQueried = true;

									if (sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
										hmMemberServiceRoles = (HashMap) hmRolesResponse.get(MPSDefs.DB_MEMBER_SERVICE_ROLES);
								}

								//1806 - Updated for PID#292348 - to return MEMBERSERVICEATTRIBUTE in response for service, if present
								if(! bMemberSvcAttrQueried && inputParamHs.containsKey(MPSDefs.QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG)){

									String sQueryMemberServiceAttribute = (String) inputParamHs.get(MPSDefs.QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG);

									if(MPSDefs.YES.equals(sQueryMemberServiceAttribute)){
										HashMap hmDbInput = CommonUtil.getHashMap();
										hmDbInput.put(MPSDefs.DB_MEMBER_NUM, sMember_num);

										MPSDB_MemberServiceAttribute_H oGetMemSvcAttr = getMemberSvcAttributeHelper();
										HashMap hmMemSvcAttrResp = oGetMemSvcAttr.getServiceAttributes( hmDbInput, connection, minf);

										if (hmMemSvcAttrResp == null)
										{
											sAppInfo =  "MPSDB_MemberServiceAttribute_H.getServiceAttributes helper returned null.";
											logger.error("DBTOOLS29.1 : "+ sAppInfo);
											hmMemSvcAttrResp = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo );
											MemServices.clear();
											MemServices.putAll(hmMemSvcAttrResp);
											return  MemServices;
										}

										sAppStatusCode = (String) hmMemSvcAttrResp.get( CErrorDefs.COMMON_APP_STATUS_CODE );

										if(sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS) )
										{
											if(sAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND) )
											{
												sAppInfo = "Member service attributes not found for member_num - " + sMember_num;
												logger.info("DBTOOLS29.2 : "+ sAppInfo);
											} else {
												MemServices.clear();
												MemServices.putAll(hmMemSvcAttrResp);
												return  MemServices;
											}
										}

										if (sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
											hmMemberServiceAttributes = (HashMap) hmMemSvcAttrResp.get(MPSDefs.DB_MEMBER_SERVICE_ATTRIBUTE);
									}
									bMemberSvcAttrQueried = true;
								}//END

								//creates instanceHash
								//copyInstanceData (instanceHash, resultSetForSecondQuery);
								copyInstanceData (instanceHash, resultSetForSecondQuery, hmMemberServiceRoles, alQueryRolesSvcList);

								//Adding IPTV service provider in the response hashmap for NAP2--by nk0565
								if (serviceName.equals(MPSDefs.IPTV_SERVICE ))
								{
									instanceHash.put(MPSDefs.DB_PORTAL_SVC_PROVIDER,
											resultSetForSecondQuery.getString(MPSDefs.DB_PORTAL_SVC_PROVIDER));
								}
								if ( serviceName.equals(MPSDefs.MOSUB_SERVICE ) || serviceName.equals(MPSDefs.AAB_SERVICE))
								{

									//added by hb1387 for APRIL 2009 ASPEN
									//instanceHash.put(MPSDefs.DB_SOR_INVARIANT_ID, resultSetForSecondQuery.getString(MPSDefs.DB_SOR_INVARIANT_ID));

									//added by vs3652 for LSR10 AAB
									ArrayList alAssoServices = CommonUtil.getArrayList();//new ArrayList();
									HashMap hmAssoServices = CommonUtil.getHashMap();//new HashMap();

									String sorInvariantId = resultSetForSecondQuery.getString(MPSDefs.DB_SOR_INVARIANT_ID);
									String assoSorId1 = resultSetForSecondQuery.getString(MPSDefs.DB_SOR_ID1);
									String assoSorInvariantId1 = resultSetForSecondQuery.getString(MPSDefs.DB_SOR_INVARIANT_ID1);
									String assoSorId2 = resultSetForSecondQuery.getString(MPSDefs.DB_SOR_ID2);
									String assoSorInvariantId2 = resultSetForSecondQuery.getString(MPSDefs.DB_SOR_INVARIANT_ID2);

									if (sorInvariantId != null && assoSorInvariantId1 != null &&
											sorInvariantId.equals(assoSorInvariantId1) )
									{
										hmAssoServices.put(MPSDefs.DB_SOR_ID1, assoSorId1);
										hmAssoServices.put(MPSDefs.DB_SOR_INVARIANT_ID1, assoSorInvariantId1);
										hmAssoServices.put(MPSDefs.DB_SOR_NAME1,
												resultSetForSecondQuery.getString(MPSDefs.DB_SOR_NAME1));

										hmAssoServices.put(MPSDefs.DB_SOR_ID2, assoSorId2);
										hmAssoServices.put(MPSDefs.DB_SOR_INVARIANT_ID2, assoSorInvariantId2);
										hmAssoServices.put(MPSDefs.DB_SOR_NAME2,
												resultSetForSecondQuery.getString(MPSDefs.DB_SOR_NAME2));

										hmAssoServices.put(MPSDefs.DB_ASSOCIATION_ASSIGNED_BY,
												resultSetForSecondQuery.getString("asso_assigned_by"));
										hmAssoServices.put(MPSDefs.DB_ASSOCIATION_CREATE_DATE,
												resultSetForSecondQuery.getString("asso_create_date"));
										hmAssoServices.put(MPSDefs.DB_ASSOCIATION_LAST_MODIFIED,
												resultSetForSecondQuery.getString("asso_last_modified"));
										hmAssoServices.put(MPSDefs.DB_ASSOCIATION_LAST_MODIFIED_BY,
												resultSetForSecondQuery.getString("asso_last_modified_by"));

										alAssoServices.add(hmAssoServices);

										if (alAssoServices.size() > 0)
											instanceHash.put(MPSDefs.DB_ASSOCIATED_SERVICES, alAssoServices);
									}
									//LSR10 AAB changes ends
								}
								//1502 LoCo Updates
								if (alValidAccountsForLoyaltyInfo != null && alValidAccountsForLoyaltyInfo.contains(serviceName)) {

										ArrayList alLoyaltyProgAcctAssoct = null;
										ArrayList alLoyaltyOfferAcceptance = null;
										HashMap processLoyaltyInfo = CommonUtil.getHashMap();
										processLoyaltyInfo.put(CommonDefs.SOR_ID, resultSetForSecondQuery.getString(MPSDefs.DB_SOR_ID));
										processLoyaltyInfo.put(CommonDefs.SOR_INVARIANT_ID, resultSetForSecondQuery.getString(MPSDefs.DB_SOR_INVARIANT_ID));
										processLoyaltyInfo.put(CommonDefs.END_DATE, null);

										HashMap hmLoyaltyInfoResponse = MPSDB_LoyaltyProgAcctAssoc_H.getLoyaltyProgAcctAssoc(processLoyaltyInfo, connection, minf);

										if (hmLoyaltyInfoResponse == null) {
											sAppInfo = "HashMap hmResult  is null";
											hmLoyaltyInfoResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM,sAppInfo);
											logger.error("TMS_UMD_06.8 ; "+ sAppInfo);
											return hmLoyaltyInfoResponse;
										}
										sAppStatusCode = (String) hmLoyaltyInfoResponse.get(MPSDefs.APP_STATUS_CODE);
										if (sAppStatusCode != null && !sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
											if (sAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND))
												logger.debug("DBTOOLS15.1 : "+ "No loyaltyprogacctassociation found in MPS");
											else
												return hmLoyaltyInfoResponse;
										}

										if (sAppStatusCode != null && sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
											alLoyaltyProgAcctAssoct = (ArrayList) hmLoyaltyInfoResponse.get(CommonDefs.LOYALTY_PROG_ACCT_ASSOC);
											if (alLoyaltyProgAcctAssoct != null && !alLoyaltyProgAcctAssoct.isEmpty()) {
												instanceHash.put(CommonDefs.LOYALTY_PROG_ACCT_ASSOC, alLoyaltyProgAcctAssoct);
											}
										}

										hmLoyaltyInfoResponse = MPSDB_LoyaltyOfferAcceptance_H.getLoyaltyOfferAcceptance(processLoyaltyInfo, connection, minf);

										if (hmLoyaltyInfoResponse == null) {
											sAppInfo = "HashMap hmResult  is null";
											hmLoyaltyInfoResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM,sAppInfo);
											logger.error("TMS_UMD_06.8 : "+ sAppInfo);
											return hmLoyaltyInfoResponse;
										}
										sAppStatusCode = (String) hmLoyaltyInfoResponse.get(MPSDefs.APP_STATUS_CODE);
										if (sAppStatusCode != null && !sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
											if (sAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND))
												logger.debug("DBTOOLS15.2 : "+ "No loyaltyofferacceptance found in MPS");
											else
												return hmLoyaltyInfoResponse;
										}

										if (sAppStatusCode != null && sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
											alLoyaltyOfferAcceptance = (ArrayList) hmLoyaltyInfoResponse.get(CommonDefs.LOYALTY_OFFER_ACCEPTANCE);
											if (alLoyaltyOfferAcceptance != null && !alLoyaltyOfferAcceptance.isEmpty()) {
												instanceHash.put(CommonDefs.LOYALTY_OFFER_ACCEPTANCE,alLoyaltyOfferAcceptance);
											}
										}
								}
								//Updated for June 2011 for TITAN
								//if (serviceName.equals(MPSDefs.ECOMM_SERVICE ) ||
									//	serviceName.equals(MPSDefs.MOBILITY_SERVICE ))
								if (CommonDefs.SERVICE_NOTIFICATION_CONTACT_ELIGIBLE_ACCOUNTS.contains(serviceName))
								{
									//instanceHash.put(MPSDefs.SERVICE_STATUS,
											//(String) instanceHash.get(MPSDefs.INSTANCE_STATUS));

									HashMap hmSvcContNotInput = CommonUtil.getHashMap();//new HashMap();
									String sSorName = (String) instanceHash.get(MPSDefs.DB_SOR_NAME);

									if (instanceId != null && sSorName!= null && ! instanceId.trim().equals("1"))
									{
										hmSvcContNotInput.put(MPSDefs.DB_SOR_INVARIANT_ID, instanceId);
										hmSvcContNotInput.put(MPSDefs.DB_SOR_NAME, sSorName);
										hmSvcContNotInput.put(MPSDefs.DB_SERVICE_ID,
											instanceHash.get(MPSDefs.DB_SERVICE_ID));

										alSvcNotSorInvariantIds.add(hmSvcContNotInput);
									}

									//1510 - Updated for PID 266956b CTN Alias for Fraud - to return USERFRAULOCK and ACCOUNTFRAUDLOCK details
									if (sQueryFraudLock != null && sQueryFraudLock.equalsIgnoreCase(MPSDefs.YES)){
										HashMap hmAccountFraudLockInp = CommonUtil.getHashMap();
										hmAccountFraudLockInp.put(MPSDefs.DB_SOR_ID, resultSetForSecondQuery.getString(MPSDefs.DB_SOR_ID));
										hmAccountFraudLockInp.put(MPSDefs.DB_SOR_INVARIANT_ID, resultSetForSecondQuery.getString(MPSDefs.DB_SOR_INVARIANT_ID));

										HashMap hmAcctFraudLockResp = MPSDB_FraudLock_H.queryAccountFraudLock(hmAccountFraudLockInp, connection, minf);

										if (hmAcctFraudLockResp == null) {
											sAppInfo = "HashMap hmAcctFraudLockResp  is null";
											hmAcctFraudLockResp = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
											logger.error("DBTOOLS28.1 : "+ sAppInfo);
											return hmAcctFraudLockResp;
										}
										sAppStatusCode = (String) hmAcctFraudLockResp.get(MPSDefs.APP_STATUS_CODE);
										if (sAppStatusCode != null && !sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
											if (sAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND))
												logger.debug("DBTOOLS28.2 : "+ "No ACCOUNTFRAUDLOCK present in MPS");
											else
												return hmAcctFraudLockResp;
										}

										if (sAppStatusCode != null && sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
											ArrayList alFraudLock = (ArrayList) hmAcctFraudLockResp.get(MPSDefs.FRAUD_LOCK);
											if (alFraudLock != null && !alFraudLock.isEmpty()) {
												instanceHash.put(MPSDefs.FRAUD_LOCK, alFraudLock);
											}
										}
									} //END - 1510
								}

								//1806 - Updated for PID#292348 - to return MEMBERSERVICEATTRIBUTE in response for service, if present
								if(hmMemberServiceAttributes != null && hmMemberServiceAttributes.containsKey(serviceName)){
									HashMap hmServiceAttribute = (HashMap) hmMemberServiceAttributes.get(serviceName);
									if(hmServiceAttribute != null){
										String sDBSorInvId = (String) resultSetForSecondQuery.getString(MPSDefs.DB_SOR_INVARIANT_ID);

										if(sDBSorInvId != null && hmServiceAttribute.containsKey(sDBSorInvId)){
											ArrayList alSvcAttributes = (ArrayList) hmServiceAttribute.get(sDBSorInvId);
											if(alSvcAttributes != null && !alSvcAttributes.isEmpty()){
												instanceHash.put(MPSDefs.DB_MEMBER_SERVICE_ATTRIBUTE, alSvcAttributes);
											}
										}
									}
								}//END

								//Always put service_status inside instance hash from June 2011
								instanceHash.put(MPSDefs.SERVICE_STATUS,
										(String) instanceHash.get(MPSDefs.INSTANCE_STATUS));
								instanceHash.put(MPSDefs.DB_INSTANCE_ID, instanceId);

								userServiceHash.put(
									resultSetForSecondQuery.getString(MPSDefs.DB_INSTANCE_ID), instanceHash);

								//For LS - R1, we have only one instance_id. So, instance_status and service_status
								//values are same
								//Do not return service_status outside level for ECOMM/MOBILITY/TITAN services
								//if (! serviceName.equals(MPSDefs.ECOMM_SERVICE) && ! serviceName.equals(MPSDefs.MOBILITY_SERVICE))
								if (! CommonDefs.INSTANCE_SERVICES_WITH_MULTIPLE_INSTANCES.contains(serviceName))
								{
									userServiceHash.put (MPSDefs.SERVICE_STATUS,
											(String) instanceHash.get(MPSDefs.INSTANCE_STATUS));
								}

							} else {

								copyServiceData(
									userServiceHash,
									resultSetForSecondQuery);

								if(serviceName != null && serviceName.equals(MPSDefs.PORTAL_SERVICE)){
									logger.debug("DBTOOLS30 : "+ "Portal Service added to result hash");

									userServiceHash.put(MPSDefs.DB_PORTAL_PROVIDER,
										resultSetForSecondQuery.getString(MPSDefs.DB_PORTAL_PROVIDER));
									userServiceHash.put(MPSDefs.DB_PLITE_IND,
										resultSetForSecondQuery.getString(MPSDefs.DB_PLITE_IND));
								}
							}

						} //end of LSServices

						servicesHash.put(serviceName, userServiceHash);

					} //  	end while (resultSetForSecondQuery.next())

					//1304 SID24742: If access_name=DSL and member does not have DSL service, return ERR_INVALID_DATA
					if ((accessNameValue != null && accessNameValue.equals("1544") &&
							servicesHash != null && !servicesHash.containsKey("1544"))
							&& (sTransactionName == null ||(sTransactionName != null && !sTransactionName.equals("GenericDataFix"))))   //2016.07 SID44581
					{
						logger.info("DBTOOLS30.5 : "+
								"Member access_id=2 but there is no DSL service found");
						MemServices = CommonErrorMap.makeCategoryMap(
								CommonErrorMap.ERR_INVALID_DATA_NUM, "Member access_id=2 but there is no DSL service found");
						return MemServices;
					}

					if (servicesHash != null && ! servicesHash.isEmpty())
						MemServices.put(servicesKey, servicesHash);
				} // end if (!memberStateValue.equalsIgnoreCase(RESERVED_STATE))
*/
				//Start::Feb 2008 NAP2 Email Ailases Information
				//call to MPSDB_GetEmailAlias.getEmailAliases() by the account�s member_num to get any email alias data that exists.--Feb 2008 NAP2

/*				String sRetrieveEmailAliases = (String) inputParamHs.get(MPSDefs.RETRIEVE_EMAIL_ALIASES_FLAG);

				if (sRetrieveEmailAliases != null && sRetrieveEmailAliases.equalsIgnoreCase(MPSDefs.YES))
				{
					MPSDB_GetEmailAlias oGetEmailAlias = new MPSDB_GetEmailAlias();
					inputParamHs.put(MPSDefs.DB_MEMBER_NUM,sMember_num);
					HashMap hmStatusTMS = oGetEmailAlias.getEmailAliases(inputParamHs,connection,minf);
					String stAppStatusCode = (String)hmStatusTMS.get(MPSDefs.APP_STATUS_CODE);
					if(stAppStatusCode.equals(MPSDefs.MPS_SUCCESS)){
						ArrayList alEmailAliases =(ArrayList) hmStatusTMS.get(MPSDefs.EMAIL_ALIASES);
						MemServices.put(MPSDefs.EMAIL_ALIASES,alEmailAliases);
					}
				}*/

/*				String sTrialUsersRequired = (String) inputParamHs.get("trialUsersRequired");
				if (sTrialUsersRequired != null && sTrialUsersRequired.equalsIgnoreCase(MPSDefs.YES)) {
					preparedStatementForTrialUsers  = connection.prepareStatement(queryForTRIALUsers);
					preparedStatementForTrialUsers.setInt(1, memNumVal);

					long pTime = 0;
					Date dtQueryTime = new Date();
					logger.debug("DBTOOLS31 : "+ "Query start time");

					resultSetForTrialUsers = preparedStatementForTrialUsers.executeQuery();
					pTime = (System.currentTimeMillis() - dtQueryTime.getTime());

					logger.info("QUERY999 : "+
							"Total time taken to execute query = " + pTime
									+ " milliseconds");

					// changes done by vg558n to return time in milliseconds for
					// APRIL2011 end

					if (resultSetForTrialUsers.next()) {
						MemServices.put("trial_type", resultSetForTrialUsers.getString("trial_type"));
					}

				} //end of trialUsersRequired Y
*/
				//LSR10: Call to MPSDB_GetMediaDevices.getMediaDevices by the member_num to get media devices info from mediadevice table
/*				String sMediaDevicesRequired = (String) inputParamHs.get(MPSDefs.MEDIA_DEVICES_REQ);

				if(sMediaDevicesRequired != null && sMediaDevicesRequired.equalsIgnoreCase(MPSDefs.YES))
				{
					MPSDB_GetMediaDevices oGetMediaDevices = new MPSDB_GetMediaDevices();
					inputParamHs.put(MPSDefs.DB_MEMBER_NUM, sMember_num);
					HashMap hmStatusTMS = oGetMediaDevices.getMediaDevices(	inputParamHs, minf, connection);
					sAppStatusCode = (String) hmStatusTMS.get(MPSDefs.APP_STATUS_CODE);

					if (! sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
						if (sAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND) )
							logger.debug("DBTOOLS32 : "+ "No media devices found in MPS");
						else
							return hmStatusTMS;
					}

					if(sAppStatusCode.equals(MPSDefs.MPS_SUCCESS))
						MemServices.put(MPSDefs.DB_MEDIA_DEVICES, hmStatusTMS.get(MPSDefs.DB_MEDIA_DEVICES));
				}*/

				//MyWorld Aug 09 - Query MEMBERIDENTITY by member_num to get identity info - vs3652
/*				String sIdentityRequired = (String) inputParamHs.get(MPSDefs.WS_IDENTITY_INFO_REQ);
				if (sIdentityRequired != null && sIdentityRequired.equalsIgnoreCase(MPSDefs.YES)) {
					preparedStatementForIdentity  = connection.prepareStatement(queryForMemberIdentity);
					preparedStatementForIdentity.setInt(1, memNumVal);

					long pTime = 0;
					Date dtQueryTime = new Date();
					logger.debug("DBTOOLS33 : "+ "Query start time");

					resultSetForIdentity = preparedStatementForIdentity.executeQuery();

					pTime = (System.currentTimeMillis() - dtQueryTime.getTime());

					logger.info("QUERY999 : "+
							"Total time taken to execute query = " + pTime
									+ " milliseconds");

					ArrayList alIdentities =CommonUtil.getArrayList();
					HashMap hmIdentity =null;
					while (resultSetForIdentity.next()) {
						hmIdentity = CommonUtil.getHashMap();

						hmIdentity.put(MPSDefs.DB_IDENTITY,
								resultSetForIdentity.getString(MPSDefs.DB_IDENTITY));
						hmIdentity.put(MPSDefs.DB_IDENTITY_TYPE,
								resultSetForIdentity.getString(MPSDefs.DB_IDENTITY_TYPE));

						alIdentities.add(hmIdentity);
					}

					logger.info("DBTOOLS30 : "+
							"Identities queried :" + alIdentities);

					if (alIdentities != null && alIdentities.size() > 0)
						MemServices.put(MPSDefs.DB_IDENTITIES, alIdentities);
				} //end of wsIdentityRequired=Y

*/

/*				String sDeviceInfoReq = (String) inputParamHs.get(MPSDefs.WS_DEVICE_INFO_REQUIRED);
				if (sDeviceInfoReq != null && sDeviceInfoReq.equalsIgnoreCase(MPSDefs.YES)) {
					prepStmtForDeviceProfile  = connection.prepareStatement(queryDeviceAndDeviceProfile);
					prepStmtForDeviceProfile.setInt(1, memNumVal);

					long pTime = 0;
					Date dtQueryTime = new Date();
					logger.debug("DBTOOLS35 : "+ "Query start time");

					resultSetForDeviceProfile = prepStmtForDeviceProfile.executeQuery();
					pTime = (System.currentTimeMillis() - dtQueryTime.getTime());

					logger.info("QUERY999 : "+
							"Total time taken to execute query = " + pTime
									+ " milliseconds");

					HashMap devicesHash = null;
					HashMap hmDeviceInfo = null;
					HashMap hmTempDyAttr = null;
					ArrayList alDevices = CommonUtil.getArrayList();//new ArrayList();
					String deviceId = null;
					boolean deviceHashMapFlag = false;
					boolean deviceAlreadyRead  = false;

					while (resultSetForDeviceProfile.next())
					{
						deviceId = resultSetForDeviceProfile.getString("device_id");

						logger.debug("DBTOOLS36 : "+
							"member has device: " + deviceId);

						if (deviceId != null && deviceId.length() != 0)
						{
							if(devicesHash != null && devicesHash.containsKey(deviceId))
							{
								hmDeviceInfo = (HashMap) devicesHash.get(deviceId);
								deviceAlreadyRead = true;
							}else{
								hmDeviceInfo = CommonUtil.getHashMap();//new HashMap();
								deviceAlreadyRead = false;
							}

							if (!deviceAlreadyRead) {
								hmDeviceInfo.put(MPSDefs.DB_DEVICE_ID,
										resultSetForDeviceProfile.getString(MPSDefs.DB_DEVICE_ID));
								hmDeviceInfo.put(MPSDefs.DB_DEVICE_NAME,
										resultSetForDeviceProfile.getString(MPSDefs.DB_DEVICE_NAME));
								hmDeviceInfo.put(MPSDefs.DB_MAKE,
										resultSetForDeviceProfile.getString(MPSDefs.DB_MAKE));
								hmDeviceInfo.put(MPSDefs.DB_MODEL,
										resultSetForDeviceProfile.getString(MPSDefs.DB_MODEL));
								hmDeviceInfo.put(MPSDefs.DB_SOR_NAME,
										resultSetForDeviceProfile.getString(MPSDefs.DB_SOR_NAME));
								hmDeviceInfo.put(MPSDefs.DB_CATEGORY_ID,
										resultSetForDeviceProfile.getString(MPSDefs.DB_CATEGORY_ID));
								hmDeviceInfo.put(MPSDefs.DB_CATEGORY_NAME,
										resultSetForDeviceProfile.getString(MPSDefs.DB_CATEGORY_NAME));
								hmDeviceInfo.put(MPSDefs.DB_CREATE_DATE,
										resultSetForDeviceProfile.getString(MPSDefs.DB_CREATE_DATE));
								hmDeviceInfo.put(MPSDefs.DB_LAST_MODIFIED,
										resultSetForDeviceProfile.getString(MPSDefs.DB_LAST_MODIFIED));
								hmDeviceInfo.put(MPSDefs.DB_LAST_MODIFIED_BY,
										resultSetForDeviceProfile.getString(MPSDefs.DB_LAST_MODIFIED_BY));
							}


							if (!deviceHashMapFlag) {
								devicesHash =CommonUtil.getHashMap();// new HashMap();
								deviceHashMapFlag = true;
							}
							devicesHash.put(deviceId, hmDeviceInfo);
						} //ends deviceId null check
					} //resultSetForDeviceProfile iteration ends

					if (devicesHash != null && !devicesHash.isEmpty())
					{
						Iterator devicesIterator 	= devicesHash.entrySet().iterator();
						while (devicesIterator.hasNext()) {
							java.util.Map.Entry me = (java.util.Map.Entry) devicesIterator.next();
							alDevices.add(me.getValue());
						}

						if (alDevices != null && alDevices.size() > 0 )
							MemServices.put(CommonDefs.DEVICES, alDevices);
					}
				} //end of wsMemberDynAttrRequired=Y
*/
/*				if (alSvcNotSorInvariantIds != null && alSvcNotSorInvariantIds.size() > 0 )
				{
					logger.info("DBTOOLS37 : "+
							"List of ECOMM services: " + alSvcNotSorInvariantIds);

					HashMap hmGetAccountInput = CommonUtil.getHashMap();
					hmGetAccountInput.putAll(inputParamHs);

					hmGetAccountInput.put(MPSDefs.DB_MEMBER_NUM, sMember_num);
					hmGetAccountInput.put(CommonDefs.KEY_ECOMM_SERVICES, alSvcNotSorInvariantIds);

					//call getAllAccounts
					HashMap hmStatusTMS = MPSDB_GetAccount_H.getAllAccounts(hmGetAccountInput, connection, minf);
					sAppStatusCode = (String) hmStatusTMS.get(MPSDefs.APP_STATUS_CODE);

					if (! sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
						if (sAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND) )
							logger.info("DBTOOLS38 : "+
									"No ECOMM account found in MPS");
						else
							return hmStatusTMS;
					}

					if(sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
						if (hmStatusTMS.containsKey(MPSDefs.DB_SERVICE_CONTACTS)) {
							MemServices.put(MPSDefs.DB_SERVICE_CONTACTS, hmStatusTMS.get(MPSDefs.DB_SERVICE_CONTACTS));
						}
						if (hmStatusTMS.containsKey(MPSDefs.DB_SERVICE_NOTIFICATION)) {
							MemServices.put(MPSDefs.DB_SERVICE_NOTIFICATION, hmStatusTMS.get(MPSDefs.DB_SERVICE_NOTIFICATION));
						}
						if (hmStatusTMS.containsKey(MPSDefs.DB_WIRELINEUSER)) {
							MemServices.put(MPSDefs.DB_WIRELINEUSER, hmStatusTMS.get(MPSDefs.DB_WIRELINEUSER));
						}
						if (hmStatusTMS.containsKey(MPSDefs.DB_SERVICEINFO)) {
							MemServices.put(MPSDefs.DB_SERVICEINFO, hmStatusTMS.get(MPSDefs.DB_SERVICEINFO));
						}
					}
				}*/

				//S&B June 2010 - Query MEMBERLOCKOUT by member_num - vs3652
/*				String sQueryMemberlockout = (String) inputParamHs.get(MPSDefs.DB_QUERY_MEMBERLOCKOUT_FLAG);
				if (sQueryMemberlockout != null && sQueryMemberlockout.equalsIgnoreCase(MPSDefs.YES))
				{
					prepStmtForMemberLockout = connection.prepareStatement(queryMemberLockout);

					if (sSlidMemberNum != null && sSlidMemberNum.trim().length() > 0)
						prepStmtForMemberLockout.setString(1, sSlidMemberNum);
					else
						prepStmtForMemberLockout.setInt(1, memNumVal);

					long pTime = 0;
					Date dtQueryTime = new Date();
					logger.debug("DBTOOLS39 : "+ "Query start time");

					resultSetForMemberLockout = prepStmtForMemberLockout.executeQuery();
					pTime = (System.currentTimeMillis() - dtQueryTime.getTime());

					logger.info("QUERY999 : "+
							"Total time taken to execute query = " + pTime
									+ " milliseconds");

					ArrayList alMemberLocks = CommonUtil.getArrayList();//new ArrayList();
					HashMap hmLockInfo=null;
					while (resultSetForMemberLockout.next()) {
						hmLockInfo = CommonUtil.getHashMap();//new HashMap();
						hmLockInfo.put(MPSDefs.DB_MEMBER_NUM,
							resultSetForMemberLockout.getString(MPSDefs.DB_MEMBER_NUM));
						hmLockInfo.put(MPSDefs.DB_LOCKOUT_ID,
							resultSetForMemberLockout.getString(MPSDefs.DB_LOCKOUT_ID));
						hmLockInfo.put(MPSDefs.DB_LOCKOUT_NAME,
								resultSetForMemberLockout.getString(MPSDefs.DB_LOCKOUT_NAME));
						hmLockInfo.put(MPSDefs.DB_SET_NUMBER,
							resultSetForMemberLockout.getString(MPSDefs.DB_SET_NUMBER));
						hmLockInfo.put(MPSDefs.DB_FAILED_AUTH_COUNT,
							resultSetForMemberLockout.getString(MPSDefs.DB_FAILED_AUTH_COUNT));
						hmLockInfo.put(MPSDefs.DB_LOCKOUT_EXPIRATION,
							resultSetForMemberLockout.getString(MPSDefs.DB_LOCKOUT_EXPIRATION));
						hmLockInfo.put(MPSDefs.DB_LAST_FAILED_AUTH,
							resultSetForMemberLockout.getString(MPSDefs.DB_LAST_FAILED_AUTH));
						hmLockInfo.put(MPSDefs.DB_CREATE_DATE,
							resultSetForMemberLockout.getString(MPSDefs.DB_CREATE_DATE));
						hmLockInfo.put(MPSDefs.DB_LAST_MODIFIED,
							resultSetForMemberLockout.getString(MPSDefs.DB_LAST_MODIFIED));
						hmLockInfo.put(MPSDefs.DB_LAST_MODIFIED_BY,
							resultSetForMemberLockout.getString(MPSDefs.DB_LAST_MODIFIED_BY));

						alMemberLocks.add(hmLockInfo);
					}

					if (alMemberLocks != null && alMemberLocks.size() > 0)
						MemServices.put(MPSDefs.DB_MEMBERLOCKOUT, alMemberLocks);
					else
						logger.info("DBTOOLS40 : "+
							"No record found in MEMBERLOCKOUT table");
				} //end of queryMemberlockout=Y
	*/

				//October 2010, updated to return slid info if MID is associated to slid
/*				String sQuerySlidInfo = (String) inputParamHs.get(MPSDefs.QUERY_SLID_INFO_FLAG);

				if (sSlidMemberNum != null && sSlidMemberNum.trim().length() > 0 &&
						sQuerySlidInfo != null && sQuerySlidInfo.equalsIgnoreCase(MPSDefs.YES))
				{
					inputParamHs.put(MPSDefs.DB_SLID_MEMBER_NUM, sSlidMemberNum);
					HashMap hmStatusTMS = MPSDB_GetSlidInfo.getSlidInfo (inputParamHs, connection, minf);
					sAppStatusCode = (String) hmStatusTMS.get(MPSDefs.APP_STATUS_CODE);

					if (! sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
						if (sAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND) )
							logger.debug("DBTOOLS32 : "+ "No slid info found in MPS");
						else
							return hmStatusTMS;
					}

					if(sAppStatusCode.equals(MPSDefs.MPS_SUCCESS))
						MemServices.put(MPSDefs.KEY_SLID_INFO, hmStatusTMS.get(MPSDefs.KEY_SLID_INFO));
				}*/

				//October 2010, updated to return slid info if MID is associated to slid
/*				String sQueryMonitoredUserInfo = (String) inputParamHs.get(MPSDefs.QUERY_MONITORED_USER_INFO_FLAG);

				if (sQueryMonitoredUserInfo != null && sQueryMonitoredUserInfo.equalsIgnoreCase(MPSDefs.YES))
				{
					HashMap hmMonitorUserInput = CommonUtil.getHashMap();//new HashMap();
					hmMonitorUserInput.put(MPSDefs.DB_MEMBER_NUM, sMember_num);

					HashMap hmStatusTMS = MPSDB_MonitorUser_H.getMonitoredUsers (hmMonitorUserInput, connection, minf);
					sAppStatusCode = (String) hmStatusTMS.get(MPSDefs.APP_STATUS_CODE);

					if (! sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
						if (sAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND) )
							logger.debug("DBTOOLS32 : "+ "No monitored user info found in MPS");
						else
							return MemServices = hmStatusTMS;
					}

					if(sAppStatusCode.equals(MPSDefs.MPS_SUCCESS))
						MemServices.put(MPSDefs.DB_MONITORED_USER, hmStatusTMS.get(MPSDefs.DB_MONITORED_USER));
				}*/

				//1410, US293368 for CTN Capture
/*				String sQueryContactInfo = (String) inputParamHs.get(MPSDefs.QUERY_CONTACT_INFO_FLAG);
				if (sQueryContactInfo != null && sQueryContactInfo.equalsIgnoreCase(MPSDefs.YES))
				{
					HashMap hmContactInput = CommonUtil.getHashMap();
					hmContactInput.put(MPSDefs.DB_MEMBER_NUM, sMember_num);

					HashMap hmStatusTMS = MPSDB_Contact_H.getContact(hmContactInput, connection, minf);
					sAppStatusCode = (String) hmStatusTMS.get(MPSDefs.APP_STATUS_CODE);

					if (! sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
						if (sAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND) )
							logger.debug("DBTOOLS33.5 : "+ "No CONTACT info found in MPS");
						else
							return MemServices = hmStatusTMS;
					}

					if(sAppStatusCode.equals(MPSDefs.MPS_SUCCESS))
						MemServices.put(MPSDefs.KEY_CONTACTS, hmStatusTMS.get(MPSDefs.KEY_CONTACTS));
				}*/

				//added for LSR8, by sd8029 -- start
/*				if((dbBan != null && dbBan.trim().length()>0) && (dbSorName!=null && dbSorName.equalsIgnoreCase(MPSDefs.SOR_LS))){
					HashMap hmAccountInfo = CommonUtil.getHashMap();//new HashMap();
					hmAccountInfo.put(MPSDefs.DB_BAN,dbBan);
					HashMap hmAccountResponse = MPSDB_GetAccountInfo_H.getAccountInfo(hmAccountInfo,connection,minf);
					if(hmAccountResponse.get(MPSDefs.APP_STATUS_CODE).equals(MPSDefs.MPS_SUCCESS)){
						String dbZip = (String)hmAccountResponse.get(MPSDefs.DB_ZIP);
						MemServices.put(MPSDefs.DB_ZIP,dbZip);
//						added for LSR9,by sd8029 -- start
						//retrieving ipdslam_ind from TAccountInfo and passing in response
						MemServices.put(MPSDefs.DB_IPDSLAM_IND, hmAccountResponse.get(MPSDefs.DB_IPDSLAM_IND));
						//added for LSR9,by sd8029 -- end

						if(inputParamHs.containsKey(MPSDefs.ACCOUNT_INFO_REQ) && inputParamHs.get(MPSDefs.ACCOUNT_INFO_REQ).equals("Y")){
							MemServices.put(MPSDefs.DB_BILL_CYCLE,hmAccountResponse.get(MPSDefs.DB_BILL_CYCLE));
							MemServices.put(MPSDefs.DB_LEGAL_ENTITY,hmAccountResponse.get(MPSDefs.DB_LEGAL_ENTITY));
							MemServices.put(MPSDefs.DB_ACCOUNT_SUBTYPE,hmAccountResponse.get(MPSDefs.DB_ACCOUNT_SUBTYPE));
							MemServices.put(MPSDefs.DB_STREET,hmAccountResponse.get(MPSDefs.DB_STREET));
							MemServices.put(MPSDefs.DB_CITY,hmAccountResponse.get(MPSDefs.DB_CITY));
							MemServices.put(MPSDefs.DB_STATE,hmAccountResponse.get(MPSDefs.DB_STATE));
							MemServices.put("accountinfo_fullname", hmAccountResponse.get(MPSDefs.DB_FULLNAME));
							MemServices.put(MPSDefs.DB_RG_ACTIVATED, hmAccountResponse.get(MPSDefs.DB_RG_ACTIVATED));
							MemServices.put(MPSDefs.DB_TN_ACTIVATED, hmAccountResponse.get(MPSDefs.DB_TN_ACTIVATED));
						}

					}else{
						//1804 - Updated to ignore REC_NOT_FOUND error if BAN is not present in accountinfo
						sAppStatusCode = (String) hmAccountResponse.get(MPSDefs.APP_STATUS_CODE);
						if (sAppStatusCode.equals(MPSDefs.REC_NOT_FOUND) )
							minf.log(Mpslog.debug, 0, thisClass, thisMethod, "DBTOOLS33.05", "No ACCOUNTINFO found in MPS");
						else {
							MemServices.clear();
							MemServices.putAll(hmAccountResponse);
							return  MemServices;
						}

					}

				}	*/
				//added for LSR8, by sd8029 -- end

/*				//1510 - Updated for PID 266956b CTN Alias for Fraud - to return USERFRAULOCK and ACCOUNTFRAUDLOCK details
				if (sQueryFraudLock != null && sQueryFraudLock.equalsIgnoreCase(MPSDefs.YES))
				{
					HashMap hmUserFraudLockInp = CommonUtil.getHashMap();
					hmUserFraudLockInp.put(MPSDefs.DB_MEMBER_NUM, sMember_num);

					HashMap hmStatusTMS = MPSDB_FraudLock_H.queryUserFraudLock(hmUserFraudLockInp, connection, minf);
					sAppStatusCode = (String) hmStatusTMS.get(MPSDefs.APP_STATUS_CODE);

					if (! sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
						if (sAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND) )
							minf.log(Mpslog.debug, 0, thisClass, thisMethod, "DBTOOLS33.6", "No USERFRAUDLOCK info found in MPS");
						else
							return MemServices = hmStatusTMS;
					}

					if(sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)){
						MemServices.put(MPSDefs.DB_USER_LOCK_LEVEL, hmStatusTMS.get(MPSDefs.DB_USER_LOCK_LEVEL));
						MemServices.put(MPSDefs.DB_USER_LOCK_REASON, hmStatusTMS.get(MPSDefs.DB_USER_LOCK_REASON));
						MemServices.put(MPSDefs.DB_FRAUD_AGENT, hmStatusTMS.get(MPSDefs.DB_FRAUD_AGENT));
						MemServices.put("fraud_last_modified_by", hmStatusTMS.get(MPSDefs.DB_LAST_MODIFIED_BY));
						MemServices.put("fraud_last_modified", hmStatusTMS.get(MPSDefs.DB_LAST_MODIFIED));
						MemServices.put("fraud_create_date", hmStatusTMS.get(MPSDefs.DB_CREATE_DATE));
					}

				} // END - 1510
*/
				countFoundHandlesInDB ++;
				return MemServices;

			} // end while (hasRecords)

			if (countFoundHandlesInDB==0) {
				MemServices =
						StatusMsg.makeSQLStatus(
								MPSDefs.REC_NOT_FOUND,
								MPSDefs.REC_NOT_FOUND_MSG,
								MPSDefs.SQL_ERR,
								MPSDefs.SQL_ERR_MSG,
								MPSDefs.NO_ROW_UPDATED);

				logger.info(CLASS_NAME + thisMethod +"DBTOOLS41 : "+
						"No row found");

				return MemServices;
			}

			/*//Updated for Aug SID# 16198 - Start
			String stAutoCommit = (String)inputParamHs.get(MPSDefs.AUTOCOMMIT);
			if (stAutoCommit != null) {
				connection.setAutoCommit(Boolean.parseBoolean(stAutoCommit));
			}
			//Updated for Aug SID# 16198 - End
*/
		} // end try
		/*catch (SQLException sqlExcp) {
			String sqlMessage = sqlExcp.getMessage();

			if ((sqlMessage != null) && (sqlMessage.length() != 0)) {
				if(sqlMessage.contains("Invalid column name")){
					MemServices =StatusMsg.makeSQLStatus(MPSDefs.ERR_INVALID_DATA,MPSDefs.ERR_INVALID_DATA_MSG,Integer.toString(sqlExcp.getErrorCode()),"SQL Exception",MPSDefs.NO_ROW_UPDATED);

					minf.log(Mpslog.error,MPSDefs.ERR_INVALID_DATA_NUM,thisClass,thisMethod,"DBTOOLS_E1","Exception::" + sqlExcp.getMessage());
					minf.printStackToLog(sqlExcp,MPSDefs.ERR_INVALID_DATA_NUM,thisClass,thisMethod,"DBTOOLS_E2","Exception = ");

				}else{

					MemServices =StatusMsg.makeSQLStatus(MPSDefs.ERR_DB,MPSDefs.ERR_DB_MSG,Integer.toString(sqlExcp.getErrorCode()),"SQL Exception",MPSDefs.NO_ROW_UPDATED);

					minf.log(Mpslog.error,MPSDefs.ERR_DB_NUM,thisClass,thisMethod,"DBTOOLS_E1","Exception::" + sqlExcp.getMessage());
					minf.printStackToLog(sqlExcp,MPSDefs.ERR_DB_NUM,thisClass,thisMethod,"DBTOOLS_E2","Exception = ");
				}

			}

		} // end catch (SQLException sqlExcp)
*/		catch (Exception excp) {
			errorMetricHandler.recordDbErrorMetric();
			MemServices = StatusMsg.makeExceptionSQLStatus(excp);
			errorCode = (String) MemServices.get(MPSDefs.APP_STATUS_CODE);
			logger.error(CLASS_NAME + thisMethod +"DBTOOLS_E3 : "+
					"Exception = " + excp.getMessage());
			logger.error(CLASS_NAME + thisMethod +"DBTOOLS_E4 :={} ", excp);
		}
		finally {
			logger.info(CLASS_NAME + thisMethod +"DBTOOLS999 : "+ startTime.getTime() + " : " + MemServices);
		}

		return MemServices;

	}

	/*

	 *//**
	 *
	 * @param typeOfAccess
	 * @return String
	 *//*
	public  String createQueryForAccessService(String typeOfAccess) {
		String queryForAccessService = "";

		if (typeOfAccess.equalsIgnoreCase(MPSDefs.DSL_SERVICE)) {
			//set query for DSL service

			queryForAccessService = queryForDSLService;
		} else if (
			typeOfAccess.equalsIgnoreCase(MPSDefs.ISDN_SERVICE)
				|| (typeOfAccess.equalsIgnoreCase(MPSDefs.ISDN2_SERVICE))) {
			//set query for ISDN service
			queryForAccessService = queryForISDNService;

		}else if (typeOfAccess.equalsIgnoreCase(MPSDefs.DIAL_SERVICE)) {
			//set query for DIAL service

			queryForAccessService = queryForDIALService;
		}
		else {
			//set query for Other service
			queryForAccessService = queryForOtherService;
		}

		return queryForAccessService;
	}*/
}