package com.att.idp.idgraphusermanagementms.helper;

import com.att.idp.idgraph.association.remove.RemoveAccountHelper;
import com.att.idp.idgraphusermanagementms.db.helper.GetAssociatedMembersDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.GetSlidInfoDBHelper;
import com.att.idp.idgraphusermanagementms.queue.message.helpers.UnlinkMemberIdQueueHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.MPSDefs;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * The UnlinkMemberIdHelper class is a helper class that provides methods to unlink a member ID.
 * It includes methods to validate input, interact with the GetSlidInfoDBHelper to get SLID information.
 * This class is annotated with @Component, meaning it is an autodetectable Spring Bean and can be automatically wired into other components using Spring's dependency injection facilities.
 * It is also annotated with @Configuration and @PropertySource, meaning it can be used to handle specific properties from a property file.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class UnlinkMemberIdHelper {

	public static final Logger logger = LoggerFactory.getLogger(UnlinkMemberIdHelper.class);
	private static final String sClassName = "UnlinkMemberIdHelper";
	private boolean isTransactionRollbackOnError = false;
	
	@Autowired
	private GetSlidInfoDBHelper getSlidInfoDBHelper;
	
	@Autowired
	private GetAssociatedMembersDBHelper getAssociatedMembersDBHelper;
	

	@Autowired
	private RemoveAccountHelper removeAccountHelper;
	
	@Autowired
	private UnlinkMemberIdQueueHelper unlinkMemberIdQueueHelper;
	
	@Autowired
	private UpdateMemberDataHelper updateMemberDataHelper;

	@Autowired
	private LinkMemberHelper linkMemberHelper;
	
	@Value("${ValidAccessIdAccountTypes}")
	private String sValidAccessIdAccountTypes;
	
	@Value("${ResidentialAccountSubTypes}")
	private String sResidentialAccountSubTypes;
	
	@Value("${BusinessAccountSubTypes:null}")
	private String sBusinessAccountSubTypes;
	
	@Value("${LSREG_INVALID_ACCOUNT_SUBTYPES:null}")
	private String sEnterpriseAccountSubTypes;

	/**
	 * This method is responsible for unlinking a member ID.
	 * It first validates the input and then performs a series of operations including getting SLID information.
	 * If any of these operations fail, it returns the corresponding error.
	 * If all operations are successful, it returns a success message.
	 *
	 * @param hmInput A Map containing the input parameters for the method. It should include necessary information such as transaction ID, transaction name, calling system ID, and SLID.
	 * @return A Map containing the result of the method. It includes the application status code and other information.
	 */
	public Map<String, Object> unlinkMemberId(Map<String, Object> hmInput) {
		String sMethodName = ".unlinkMemberId.";
		Map<String, Object> hmResult = CommonUtil.getHashMap();
		String stAppInfo = null;
		String sInputHandle = null;
		String sInputDomain = null;
		ArrayList<Object> alMemberDBList = CommonUtil.getArrayList();
		ArrayList<Object> alMemberIdList = CommonUtil.getArrayList();
		logger.info("UnlinkMemberIdHelper.unlinkMemberId.HLP000 : Input Hash :", hmInput);

		if (hmInput == null || hmInput.isEmpty()) {
			stAppInfo = "Input Hash is NULL";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			logger.info("{}{}UMH_100 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}
		

		try {

			// TODO: if more validation on Request is needed then add below
			hmInput.put(CommonDefs.HANDLE, hmInput.get("memberId"));
			// prepare input hashmap for getSlidInfo
			HashMap<String, Object> hmSlidInput = CommonUtil.getHashMap();
			hmSlidInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
			hmSlidInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
			hmSlidInput.put(CommonDefs.SLID, hmInput.get("accessId"));
			

			logger.info("{}{}UMH_102 :Request to getSlidInfo =  with inputHash : {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(hmSlidInput)));

			Map hmSlidDB = getSlidInfo(hmSlidInput);

			logger.debug("{}{}UMH_103 :Response from getSlidInfo  : {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(hmSlidDB)));

			if (hmSlidDB == null || hmSlidDB.isEmpty()) {
				stAppInfo = "Response from getSlidInfo() is NULL or EMPTY";
				logger.info("{}{}UMH_104 : {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				return hmResult;
			}

			String sAppStatusCode = (String) hmSlidDB.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (!(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode))) {
				stAppInfo = "Error from getSlidInfo(): " + hmSlidDB.get(CErrorDefs.COMMON_APP_INFO);
				logger.info("{}{}UMH_105 : {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
				return hmResult = hmSlidDB;
			}
			// END getSlidInfo

			HashMap hmSlidInfo = (HashMap) hmSlidDB.get(MPSDefs.KEY_SLID_INFO);

			List alLinkedUsers = (ArrayList) hmSlidInfo.get(MPSDefs.KEY_LINKED_USERS);

			if (alLinkedUsers == null || alLinkedUsers.isEmpty()) {
				stAppInfo = "Slid does not contain any linked users.";

				logger.info("{}{}UMH_106 : {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ID_NOT_LINKED_NUM, stAppInfo);
				return hmResult;
			}

			if (hmInput.containsKey(CommonDefs.HANDLE)) {
				sInputHandle = (String) hmInput.get(CommonDefs.HANDLE);
				sInputDomain = (String) hmInput.get(CommonDefs.DOMAIN);

				for (Object linkedUser : alLinkedUsers) {
					HashMap hmThisLinkedUser = (HashMap) linkedUser;
					String sThisHandle = (String) hmThisLinkedUser.get(MPSDefs.DB_MEMBER_NAME);
					String sThisDomain = (String) hmThisLinkedUser.get(MPSDefs.DB_DOMAIN_NAME);
					String sThisMemberNum = (String) hmThisLinkedUser.get(MPSDefs.DB_MEMBER_NUM);

					// If a match is found, add the user to the lists and break the loop
					if (sInputHandle.equals(sThisHandle) && sInputDomain.equals(sThisDomain)) {
						alMemberDBList.add(hmThisLinkedUser);
						alMemberIdList.add(sThisMemberNum);
						break;
					}
				}

				if (alMemberIdList.isEmpty()) {
					stAppInfo = "Error occured for " + sInputHandle + "@" + sInputDomain
							+ " :: ID NOT associated with specified SLID";
					logger.info("{}{}UMH_107 : {}", sClassName, sMethodName,
							HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ID_NOT_LINKED_NUM, stAppInfo);
					return hmResult;
				}

			}

			logger.info("{}{}UMH_108 :Request to unlinkMemberId =  with inputHash : {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(hmInput)));

			hmResult = unlinkMemberId(hmInput, alMemberIdList, alMemberDBList, hmSlidDB);

			logger.debug("{}{}UMH_109 :Response from unlinkMemberId   : {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(hmResult)));

			if (hmResult == null || hmResult.isEmpty()) {
				String sAppInfo = "Response from unlinkMemberId() is NULL or EMPTY";
				logger.info("{}{}UMH_110 : {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				return hmResult;
			}

			sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (!(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode))) {
				String sAppInfo = (String) hmResult.get(CErrorDefs.COMMON_APP_INFO);
				logger.info("{}{}UMH_111 : {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
				return hmResult;
			}

		}  catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown unlinkMemberId method : " + hmResult;
			logger.info("{}{}UMH_112 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));

		} finally {
			String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);

			if (isTransactionRollbackOnError && sAppCategoryCode != null
					&& !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
				hmResult.put("isTransactionRollback", "Y");
			}
			logger.info("{}{}HLP999 : response from unlinkMemberId : {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(hmResult)));
		}
		return hmResult;
	}

	/**
	 * Retrieves SLID information based on the provided input.
	 *
	 * This method interacts with the database to fetch SLID information using the given input parameters.
	 * It returns a map containing the SLID information and other relevant details.
	 *
	 * @param hmInput the input map containing various parameters for fetching SLID information
	 * @return a map containing the SLID information and other relevant details
	 */
	private Map getSlidInfo(HashMap hmInput) {

		String sMethodName = ".getSlidInfo.";
		String sAppStatusCode = null;
		String sAppInfo = null;

		Map<String, Object> hmResult = CommonUtil.getHashMap();
		HashMap<String, Object> hmSlidInput = CommonUtil.getHashMap();
		ArrayList<String> alMask = CommonUtil.getArrayList();

		hmSlidInput.putAll(hmInput);
		hmSlidInput.put(CommonDefs.DOMAIN, CommonDefs.SLID_DUM);

		alMask.add("SLO");
		alMask.add(CommonDefs.MASK_SS);
		alMask.add(CommonDefs.MASK_LU); // linked users
		alMask.add(CommonDefs.MASK_LS); // linked user's services

		alMask.add(CommonDefs.MASK_SR); // slid memberServiceRole

		// 1510 : US450941 - As RIL UnlinkInternetAccount, I want to autogenerate a
		// matching Access id if the customer unlinks a Member Id,
		// so that an Access Id will be created for all eligible Member Ids.
		alMask.add("LAI"); // for AccountInfo Data for Account Sub type

		hmSlidInput.put(CommonDefs.SLID_MASK, alMask);
		try {

			logger.info("{}{}UMH_102.1 :Request to GetSlidInfoDBHelper.getSlidInfo =  with inputHash : {}", sClassName,
					sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmSlidInput)));

			hmResult = getSlidInfoDBHelper.getSlidInfo(hmSlidInput);

			logger.debug("{}{}UMH_102.2 :Response from GetSlidInfoDBHelper.getSlidInfo   : {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(hmResult)));

			if (hmResult == null || hmResult.isEmpty()) {
				sAppInfo = "Response from TMSMPS_GetMPSInfo.getSlidInfo() is NULL or EMPTY";
				logger.info("{}{}UMH_102.3: {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				return hmResult;
			}

			sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (!(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode))) {
				sAppInfo = (String) hmResult.get(CErrorDefs.COMMON_APP_INFO);
				logger.info("{}{}UMH_102.4: {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
				return hmResult;
			}

			// Retrieve linkedUsers from GetSlidinfo
			HashMap hmSlidInfo = (HashMap) hmResult.get(MPSDefs.KEY_SLID_INFO);
			ArrayList alLinkedUsers = (ArrayList) hmSlidInfo.get(MPSDefs.KEY_LINKED_USERS);

			if (alLinkedUsers == null || alLinkedUsers.isEmpty()) {
				sAppInfo = "Slid does not contain any linked users.";
				logger.info("{}{}UMH_102.5: {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ID_NOT_LINKED_NUM, sAppInfo);
				return hmResult;
			}

			if (hmInput.containsKey(CommonDefs.HANDLE)) {
				String sInputHandle = (String) hmInput.get(CommonDefs.HANDLE);
				String sInputDomain = (String) hmInput.get(CommonDefs.DOMAIN);

			}

		} catch (Exception exp) {
			hmResult = CommonErrorMap.makeExceptionMap(exp);
			sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
			String stAppInfo = "Exception thrown UnlinkMemberIdHelper.getSlidInfo method : " + hmResult;
			logger.info("{}{}UMH_102.6 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));

		}
		return hmResult;
	}

	/**
	 * Unlinks a member ID from the system.
	 *
	 * This method performs the unlinking of a member ID by processing the provided input map,
	 * member ID list, member database list, and SLID database map. It handles various operations
	 * and checks to ensure the unlinking process is completed successfully.
	 *
	 * @param hmInput A map containing the input parameters for the unlinking process.
	 * @param alMemberIdList A list of member IDs to be unlinked.
	 * @param alMemberDBList A list of member database entries corresponding to the member IDs.
	 * @param hmSlidDB A map containing SLID database information.
	 * @return A map containing the result of the unlinking process, including status codes and messages.
	 */
	private Map<String, Object> unlinkMemberId(Map<String, Object> hmInput, ArrayList alMemberIdList,
											   ArrayList alMemberDBList, Map hmSlidDB) {

		HashMap hmResult = CommonUtil.getHashMap();
		String sMethodName = ".unlinkMemberId.";
		String stAppInfo, sAppStatusCode = null;
    	String sCallDBUS= "Y";
    	String sCallMPS= "Y";
    	HashMap hmSlidInfo = CommonUtil.getHashMap();
    	HashMap hmMPSInput					= CommonUtil.getHashMap();
    	ArrayList alDBUSInput				= CommonUtil.getArrayList();
		if (hmInput == null || hmInput.isEmpty()) {
			stAppInfo = "Input hashmap is NULL or EMPTY";
			logger.info("{}{}UMH_108A.1: {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
			hmResult = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo );
			return hmResult;
		}
		
		if (hmSlidDB == null || hmSlidDB.isEmpty()) {
			stAppInfo = "hmSlidDB hashmap is NULL or EMPTY";
			logger.info("{}{}UMH_108A.2: {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
			hmResult = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo );
			return hmResult;
		}
		try {
			
			if(hmInput.containsKey(CommonDefs.CALLMPS) && hmInput.get(CommonDefs.CALLMPS) != null){
				sCallMPS = (String)hmInput.get(CommonDefs.CALLMPS);	
			}
			
			
			if(hmInput.containsKey(CommonDefs.CALLDBUS) && hmInput.get(CommonDefs.CALLDBUS) != null){
				sCallDBUS = (String)hmInput.get(CommonDefs.CALLDBUS);	
			}
			
			// Retrieve slidInfo hashmap from the hmSlidDB hashmap
			
			hmSlidInfo	=	(HashMap) hmSlidDB.get(MPSDefs.KEY_SLID_INFO);
			logger.debug("{}{}UMH_108A.3 : {}", sClassName, sMethodName, "Request to doMPS = " + hmInput);

			// calling local method doMPS
			hmResult = doMPS(hmInput, alMemberIdList, alMemberDBList, hmSlidDB);

			logger.debug("{}{}UMH_108A.4 : {}", sClassName, sMethodName, "Response from doMPS = " + StringUtils.normalizeSpace(
					hmResult != null ? hmResult.toString() : null));

			if (hmResult == null || hmResult.isEmpty()) {
				stAppInfo = "Response from unlinkInternetAccount() is NULL or EMPTY";

				logger.info("{}{}UMH_108A.5: {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				return hmResult;
			}

			sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (!(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode))) {
				stAppInfo = (String) hmResult.get(CErrorDefs.COMMON_APP_INFO);
				logger.info("{}{}UMH_108A.6 : {}", sClassName, sMethodName, StringUtils.normalizeSpace(stAppInfo));
				return hmResult;
			}
			
			if(sCallMPS != null && sCallMPS.equals("N")){
				hmMPSInput = (HashMap)hmResult.get("UnlinkInternetAccountMPSInput");
				if (hmMPSInput == null || hmMPSInput.isEmpty()) {
					stAppInfo = "UnlinkInternetAccountMPSInput is NULL or EMPTY";
					logger.error("{}{}UMH_108A.7 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo );
					return hmResult;
				}  
			}
			if(hmResult.containsKey(CommonDefs.LINK_INTERNET_ACCOUNT_DBUS_EVENTS) && hmResult.get(CommonDefs.LINK_INTERNET_ACCOUNT_DBUS_EVENTS) != null){
				hmInput.put(CommonDefs.LINK_INTERNET_ACCOUNT_DBUS_EVENTS, hmResult.get(CommonDefs.LINK_INTERNET_ACCOUNT_DBUS_EVENTS));
			}
			
			if(hmResult.containsKey(CommonDefs.REMOVE_ACCOUNT_DBUS_EVENTS) && hmResult.get(CommonDefs.REMOVE_ACCOUNT_DBUS_EVENTS) != null){
				hmInput.put(CommonDefs.REMOVE_ACCOUNT_DBUS_EVENTS, hmResult.get(CommonDefs.REMOVE_ACCOUNT_DBUS_EVENTS));
			}
			// June,11 [End]
			
			
			// populating hmInput with parent_handle and parent_domain
			hmInput.put(CommonDefs.SLID,(hmSlidInfo.get(MPSDefs.DB_MEMBER_NAME)));

			
			// calling  doDbus
			logger.info("{}{}UMH_108A.8 : {}", sClassName, sMethodName, "Calling unlinkMemberIdQueueHelper.sendMessageToMQ");

			hmResult=unlinkMemberIdQueueHelper.sendMessageToMQ(hmInput,hmSlidInfo,alMemberDBList);

			logger.info("{}{}UMH_108A.9 : {}", sClassName, sMethodName, "Response from  unlinkMemberIdQueueHelper.sendMessageToMQ : " + hmResult);

			if (hmResult == null || hmResult.isEmpty()) {
				stAppInfo = "Response from doDbus() is NULL or EMPTY";
				logger.error("{}{}UMH_108A.10 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo );
				return hmResult;
			}  
			sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (!(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode)))
			{
				stAppInfo = (String) hmResult.get(CErrorDefs.COMMON_APP_INFO);
				logger.info("{}{}UMH_108A.11 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			
			if(sCallDBUS != null && sCallDBUS.equals("N")){
				alDBUSInput = (ArrayList)hmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT);
				if (alDBUSInput == null || alDBUSInput.isEmpty()) {
					stAppInfo = "CONSOLIDATED_DBUS_INPUT is NULL or EMPTY";

					logger.error("{}{}UMH_108A.12 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo );
					return hmResult;
				}  
			}

		} catch (Exception exp) {
			hmResult     = CommonErrorMap.makeExceptionMap(exp);
			stAppInfo = "Exception thrown unlinkMemberId method : " + hmResult;
			logger.info("{}{}UMH_108A.13 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));

		}
		finally{
    		if (hmResult == null || hmResult.isEmpty()) {
                stAppInfo = "Response Map is NULL or EMPTY";
				logger.error("{}{}UMH_108A.14 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
            }
    		
    		sAppStatusCode=(String)hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
    		if (!sAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)){
    			
				stAppInfo = (String) hmResult.get(CErrorDefs.COMMON_APP_INFO);
				logger.info("{}{}UMH_108A.15 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
				
    		}
    		
    		if(sCallMPS != null && sCallMPS.equals("N")){
    			hmResult.put("UnlinkInternetAccountMPSInput",hmMPSInput);
    		}
    		
    		if(sCallDBUS != null && sCallDBUS.equals("N")){
    			hmResult.put(CommonDefs.CONSOLIDATED_DBUS_INPUT ,alDBUSInput);
    		}

    		if(!hmResult.containsKey(CommonDefs.TRANSACTION_ID)){
        		hmResult.put(CommonDefs.TRANSACTION_ID,hmInput.get(CommonDefs.TRANSACTION_ID));
        	}

		}
		return hmResult;
	}

	private HashMap doMPS(Map<String, Object> hmInput, ArrayList alMemberIdList, ArrayList alMemberDBList,
			Map hmSlidDB) {
		String sThisMethod			= ".doMPS.";
    	String sAppStatusCode 		= null;
    	String sAppInfo 			= null;
    	String sCallMPS				= "Y";
    	
    	HashMap hmMemberDataInput 	= CommonUtil.getHashMap();
    	HashMap hmResponse 			= CommonUtil.getHashMap();
    	
		try {
			
			hmMemberDataInput.put(CommonDefs.CALLING_SYSTEM_ID,hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
			hmMemberDataInput.put(CommonDefs.TRANSACTION_NAME,hmInput.get(CommonDefs.TRANSACTION_NAME));
			hmMemberDataInput.put(CommonDefs.TRANSACTION_ID,hmInput.get(CommonDefs.TRANSACTION_ID));
			
			logger.debug("{}{}UMH_108A.DMPS.01 : {}", sClassName, sThisMethod ,"Calling findAndSetDefaultAccount() with :"+hmMemberDataInput);
			
			hmResponse = findAndSetDefaultAccount(hmInput, alMemberIdList, alMemberDBList, hmSlidDB);
			
			logger.info("{}{}UMH_108A.DMPS.02 : {}", sClassName, sThisMethod, "Response from findAndSetDefaultAccount() :" + StringUtils.normalizeSpace(
					hmResponse != null ? hmResponse.toString() : null));
			
			if (hmResponse == null || hmResponse.isEmpty()) {
				sAppInfo = "Response from findAndSetDefaultAccount() is NULL or EMPTY";
				logger.info("{}{}UMH_108A.DMPS.03 : {}", sClassName, sThisMethod, sAppInfo);
				hmResponse = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo );
				return hmResponse;
			} 
			
			sAppStatusCode = (String)hmResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
		    if (!(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode)))
			{
		    	sAppInfo = (String) hmResponse.get(CErrorDefs.COMMON_APP_INFO);
		    	logger.info("{}{}UMH_108A.DMPS.04 : {}", sClassName, sThisMethod, StringUtils.normalizeSpace(sAppInfo));
				return hmResponse;
			}
		    
		    
		    // db updates
		    if(hmResponse.containsKey(MPSDefs.DB_MEMBERSERVICE_TABLE) && hmResponse.get(MPSDefs.DB_MEMBERSERVICE_TABLE)!= null){
		    	hmMemberDataInput.put(MPSDefs.DB_MEMBERSERVICE_TABLE,hmResponse.get(MPSDefs.DB_MEMBERSERVICE_TABLE));
		    }
		    if(hmResponse.containsKey(MPSDefs.DB_MEMBER_TABLE) && hmResponse.get(MPSDefs.DB_MEMBER_TABLE) != null){
		    	hmMemberDataInput.put(MPSDefs.DB_MEMBER_TABLE,hmResponse.get(MPSDefs.DB_MEMBER_TABLE));
		    }
		    if(hmResponse.containsKey(CommonDefs.REMOVE_ACCOUNT_MPS_OBJECT) && hmResponse.get(CommonDefs.REMOVE_ACCOUNT_MPS_OBJECT) != null){
		    	hmMemberDataInput.put(CommonDefs.REMOVE_ACCOUNT, hmResponse.get(CommonDefs.REMOVE_ACCOUNT_MPS_OBJECT));
		    }
		    

		    // dbus updates
		    if(hmResponse.containsKey(CommonDefs.LINK_INTERNET_ACCOUNT_DBUS_EVENTS) && hmResponse.get(CommonDefs.LINK_INTERNET_ACCOUNT_DBUS_EVENTS) != null){
				hmInput.put(CommonDefs.LINK_INTERNET_ACCOUNT_DBUS_EVENTS, hmResponse.get(CommonDefs.LINK_INTERNET_ACCOUNT_DBUS_EVENTS));
			}
			
			if(hmResponse.containsKey(CommonDefs.REMOVE_ACCOUNT_DBUS_EVENTS) && hmResponse.get(CommonDefs.REMOVE_ACCOUNT_DBUS_EVENTS) != null){
				hmInput.put(CommonDefs.REMOVE_ACCOUNT_DBUS_EVENTS, hmResponse.get(CommonDefs.REMOVE_ACCOUNT_DBUS_EVENTS));
			}
				
			//check the further logic below 
			  
			 
			//checking for CALLMPS in input
			if(hmInput.containsKey(CommonDefs.CALLMPS) && hmInput.get(CommonDefs.CALLMPS) != null){
				sCallMPS=(String)hmInput.get(CommonDefs.CALLMPS);
			}
			
			if(sCallMPS != null && sCallMPS.equalsIgnoreCase(CommonDefs.IND_Y) && 
					( hmMemberDataInput.containsKey(MPSDefs.DB_MEMBERSERVICE_TABLE) || 
					  hmMemberDataInput.containsKey(MPSDefs.DB_MEMBER_TABLE) ||
					  hmMemberDataInput.containsKey(CommonDefs.REMOVE_ACCOUNT) ))  {
				
				// call to UpdateMember bean

				logger.info("{}{}UMH_108A.DMPS.05 : {}", sClassName, sThisMethod, "Request to updateMemberDataHelper.processData(): " + hmMemberDataInput);
				hmResponse=updateMemberDataHelper.processData(hmMemberDataInput);
				logger.info("{}{}UMH_108A.DMPS.06 : {}", sClassName, sThisMethod,"Response from updateMemberDataHelper.processData():" + hmResponse);

				if (hmResponse == null || hmResponse.isEmpty()) {
					sAppInfo = "Response from updateMemberDataHelper.processData() is NULL or EMPTY";
					logger.info("{}{}UMH_108A.DMPS.07 : {}", sClassName, sThisMethod, sAppInfo);
					hmResponse = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo );
					return hmResponse;
				} 
				
			}
			else if (sCallMPS != null && sCallMPS.equals("N")){
				hmResponse= CommonErrorMap.makeCommonStatusMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS);
				hmResponse.put("UnlinkInternetAccountMPSInput",hmMemberDataInput);
			}
			
			
			
		} catch (Exception exp) {
			hmResponse     = CommonErrorMap.makeExceptionMap(exp);
			sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
			logger.debug("{}{}UMH_108A.DMPS.08 : {}",  sClassName, sThisMethod,"error hash map = "+hmResponse);
			logger.info("{}{}UMH_108A.DMPS.09 : {}", sClassName,sThisMethod,"Exception::Exception = "+exp.getMessage());
		}
		return hmResponse;
	}

	/**
	 * Finds and sets the default account for a given input.
	 *
	 * @param hmInput the input map containing various parameters
	 * @param alMemberIdList the list of member IDs to be processed
	 * @param alMemberDBList the list of member database entries
	 * @param hmSlidDBInfo the SLID database information map
	 * @return a HashMap containing the response of the operation
	 */
	private HashMap findAndSetDefaultAccount(Map<String, Object> hmInput, ArrayList alMemberIdList,
			ArrayList alMemberDBList, Map hmSlidDBInfo) {

		String sThisMethod = ".findAndSetDefaultAccount.";
		String sParentChildInd = null;
		String sSorName = null;
		String sServiceType = null;
		String sServiceStatus = null;
		String sServiceId = null;
		String sCpniImpacted = null;
		String sServiceCreateDate = null;
		String sInstanceId = null;
		String sRoleStatus = null;
		String sAppStatusCode = null;
		String sAppInfo = null;
		String sDefaultAccount = null;
		String sAccountInvariantId = null;
		String sAccountInvariantId_temp = null;
		String sAccountType = null;
		String sServiceSorName = null;
		String sServiceSorName_temp = null;
		String sDefaultAccountMemberNum = null;
		String sRes2Bus = null;
		String sSlid = null;

		HashMap hmResponse = CommonUtil.getHashMap();
		HashMap hmEachUser = CommonUtil.getHashMap();
		HashMap hmUpdatedService = CommonUtil.getHashMap();
		HashMap hmUpdatedServiceWithN = CommonUtil.getHashMap();
		HashMap hmLUServices = CommonUtil.getHashMap();
		HashMap hmThisService = CommonUtil.getHashMap();
		HashMap hmSlid = CommonUtil.getHashMap();
		HashMap hmThisRole = CommonUtil.getHashMap();
		HashMap hmMemberServices = CommonUtil.getHashMap();
		HashMap hmService = CommonUtil.getHashMap();
		Map hmMemberDB = null;
		HashMap<String, Object> hmRemoveAccountInput = CommonUtil.getHashMap();
		HashMap hmRemovedDefaultAccount = CommonUtil.getHashMap();
		HashMap hmRemoveAccountMPSObject = CommonUtil.getHashMap();

		ArrayList alLinkedUsers = CommonUtil.getArrayList();
		ArrayList alRoles = null;
		ArrayList alMemberService = CommonUtil.getArrayList();
		ArrayList alLinkInternetAccountDbusEvents = CommonUtil.getArrayList();
		ArrayList alRAAccountList = CommonUtil.getArrayList();
		ArrayList alRemovedDefaultAccount = CommonUtil.getArrayList();
		ArrayList alRemoveAccountDbusEvents = CommonUtil.getArrayList();
		ArrayList alUpdateMember = CommonUtil.getArrayList();

		Entry mapEntry = null;

		boolean isUnlinkingPrimaryDefault = false;
		boolean isRemovingTitan = false;
		boolean isCreatingSlid = false;
		boolean isUnlinkingDefault = false;

		String sMemberHandle = null;
		String sMemberDomain = null;
		String sMemberSor = null;
		String sMemberParentChildInd = null;
		HashMap hmSlidServices = null;
		HashMap hmThisSlidService = null;
		String sMemberBan = null;
		String sSorInvariantId = null;
		String autoSLIDCreation = null;
		String sMemberNum = null;
		String sOrigTransactionName = null;

		String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
		HashMap hmSlidDB = (HashMap) hmSlidDBInfo.get(MPSDefs.KEY_SLID_INFO);

		sRes2Bus = (String) hmInput.get(CommonDefs.RES2BUS);
		sRes2Bus = (sRes2Bus == null) ? "N" : sRes2Bus;

		if (hmInput.containsKey(CommonDefs.ORIG_TRANSACTION_NAME)
				&& hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME) != null) {
			sOrigTransactionName = (String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME);
		} else {
			sOrigTransactionName = "UnlinkInternetAccount";
		}
		
		String sUverseMemberNum 	= null;
		String sUverseBan			= null;
		long lServiceCreateDate = -1;
		long lUverseCreateDate = -1;
		DateFormat objDateFormat = new SimpleDateFormat("MMddyyyy HH:mm:ss");
		ArrayList alSlidLinkedUsers = CommonUtil.getArrayList();
		alSlidLinkedUsers = (ArrayList) hmSlidDB.get(MPSDefs.KEY_LINKED_USERS);
		
		logger.debug("{}{}UMH_108A.FASDA.01 : {}",sClassName, sThisMethod,"alMemberIdList : " + alMemberIdList);
		
		try {
			if (alSlidLinkedUsers != null && alSlidLinkedUsers.size() > 0) {
				checkForLinkedMembers(hmInput, alSlidLinkedUsers, alMemberIdList);
			}

			sUverseMemberNum = (String) hmInput.get("UverseMemberNum");
			sUverseBan = (String) hmInput.get("UverseBan");

			logger.info("{}{}UMH_108A.FASDA.02 : {}", sClassName, sThisMethod, "UverseMemberNum : " + sUverseMemberNum);

			// REMOVE ACCOUNT flow [start]
			isRemovingTitan = false;

			for (Object linkedUser : alMemberDBList) {

				hmMemberDB = CommonUtil.getHashMap();
				hmMemberDB = (HashMap) linkedUser;
				sMemberSor = (String) hmMemberDB.get(MPSDefs.DB_SOR_NAME);
				sMemberParentChildInd = (String) hmMemberDB.get(MPSDefs.DB_PARENT_CHILD_IND);

				if (hmSlidDB.containsKey(CommonDefs.SERVICES) && hmSlidDB.get(CommonDefs.SERVICES) != null) {
					hmSlidServices = CommonUtil.getHashMap();
					hmSlidServices = (HashMap) hmSlidDB.get(CommonDefs.SERVICES);
//							if(sTitanOn.equals(CommonDefs.DEFAULT_YES)){
					Iterator itrSlidServiceKeys = hmSlidServices.entrySet().iterator();

					// iteration for Slid services
					while (itrSlidServiceKeys.hasNext()) {

						mapEntry = (Entry) itrSlidServiceKeys.next();

						hmThisSlidService = CommonUtil.getHashMap();
						hmThisSlidService = (HashMap) mapEntry.getValue();
						sServiceType = (String) mapEntry.getKey();

						// iteration for instance services
						Iterator iterParentService = hmThisSlidService.keySet().iterator();
						while (iterParentService.hasNext()) {
							sInstanceId = (String) iterParentService.next();
							Object oInstanceIdObject = hmThisSlidService.get(sInstanceId);
							if (oInstanceIdObject instanceof HashMap) {
								HashMap hmInstanceId = (HashMap) oInstanceIdObject;

								if (hmInstanceId != null && sServiceType.equals(CommonDefs.TITAN_SERVICE)
										&& sMemberSor.equals(CommonDefs.SOR_LS) && sMemberParentChildInd.equals("P")) {
									sMemberBan = (String) hmMemberDB.get(MPSDefs.DB_BAN);
									sSorInvariantId = (String) hmInstanceId.get(MPSDefs.DB_SOR_INVARIANT_ID);
									String stSorName = (String) hmInstanceId.get(MPSDefs.DB_SOR_NAME); // June 2014 -
									// Added for
									// SID# 30866
									if (sMemberBan != null && sMemberBan.equals(sSorInvariantId)) {

										alRoles = CommonUtil.getArrayList();
										alRoles = (ArrayList) hmInstanceId.get(MPSDefs.DB_ROLES);

										if (alRoles != null && alRoles.size() > 0) {
											Iterator itrHsRole = alRoles.iterator();

											while (itrHsRole.hasNext()) {
												hmThisRole = (HashMap) itrHsRole.next();
												sRoleStatus = (String) hmThisRole.get(MPSDefs.DB_ROLE_STATUS_NAME);

												// processing when res2bus = N
												if (sRoleStatus.equals(MPSDefs.ENABLED)
														&& !sRes2Bus.equals(CommonDefs.DEFAULT_YES)) {

													boolean isTitanized = checkforTitanizedMobility(hmSlidServices, hmInstanceId);
													// iterating again for Slid services to check Titanized MOBILITY

													if (isTitanized) {
														sAppInfo = "Cannot unlink an LS Primary from a SLID when res2bus=N with a TITANized Child account associated to an Enabled TITAN account";

														logger.info("{}{}UMH_108A.FASDA.03 : {}", sClassName,
																sThisMethod, sAppInfo);
														hmResponse = CommonErrorMap.makeCategoryMap(
																CErrorDefs.ERR_TRANS_NOT_ALLOWED_NUM,
																sAppInfo);
														return hmResponse;
													}

													// checking assciated users for authorized role
													HashMap hmGAMInput = CommonUtil.getHashMap();
													hmGAMInput.putAll(hmInput);
													hmGAMInput.put(MPSDefs.DB_SOR_INVARIANT_ID1, sSorInvariantId);
													hmGAMInput.put(MPSDefs.DB_SOR_NAME, stSorName); // June 2014 -
													// Updated for SID#
													// 30866

													HashMap hmAssociatedMemberDB = CommonUtil.getHashMap();

													hmAssociatedMemberDB = (HashMap) getAssociatedMembers(hmGAMInput);

													if (hmAssociatedMemberDB == null
															|| hmAssociatedMemberDB.isEmpty()) {
														sAppInfo = "Response from getAssociatedMembers() is NULL or EMPTY";

														logger.info("{}{}UMH_108A.FASDA.04 : {}", sClassName, sThisMethod, sAppInfo);
														hmAssociatedMemberDB = CommonErrorMap
																.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
														return hmAssociatedMemberDB;
													}

													sAppStatusCode = (String) hmAssociatedMemberDB
															.get(CErrorDefs.COMMON_APP_STATUS_CODE);
													if (!(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode))) {
														sAppInfo = (String) hmAssociatedMemberDB
																.get(CErrorDefs.COMMON_APP_INFO);
														logger.info("{}{}UMH_108A.FASDA.05 : {}", sClassName, sThisMethod, sAppInfo);
														return hmAssociatedMemberDB;
													}

													boolean isAuthUserLinked = checkAssociatedMembersForAuthUser(hmAssociatedMemberDB, hmInput, sInstanceId);

													if (isAuthUserLinked) {
														sAppInfo = "Cannot unlink an LS Primary from a SLID when res2bus=N when other SLIDs have AUTHORIZEDUSER access to the TITAN account.";

														logger.info(
																"{}{}UMH_108A.FASDA.06 : {}",
																sClassName,
																sThisMethod,
																sAppInfo);
														hmResponse = CommonErrorMap
																.makeCategoryMap(
																		CErrorDefs.ERR_TRANS_NOT_ALLOWED_NUM,
																		sAppInfo);
														return hmResponse;
													}

												} // end of if() when res2bus = N

												isRemovingTitan = true;

												HashMap hmRAAccount = CommonUtil.getHashMap();
												hmRAAccount.put(CommonDefs.ACCOUNT_TYPE, sServiceType);
												hmRAAccount.put(CommonDefs.ACCOUNT_ID, sInstanceId);
												hmRAAccount.put(CommonDefs.ACCOUNT_INVARIANT_ID,
														hmInstanceId.get(MPSDefs.DB_SOR_INVARIANT_ID));
												hmRAAccount.put(CommonDefs.ACCOUNT_SOR,
														hmInstanceId.get(MPSDefs.DB_SOR_NAME));
												hmRAAccount.put(CommonDefs.PARENT_SOR_ID,
														hmInstanceId.get(MPSDefs.DB_PARENT_SOR_ID));
												hmRAAccount.put(CommonDefs.PARENT_SOR_INVARIANT_ID,
														hmInstanceId.get(MPSDefs.DB_PARENT_SOR_INVARIANT_ID));

												alRAAccountList.add(hmRAAccount);

												break;

											} // end of role loop
										}
									}
								}

							}
						} // end if instance loop

						// end of services loop
					}
//							}
				}

				logger.info("{}{}UMH_108A.FASDA.07 : {}", sClassName, sThisMethod,"isRemovingTitan : " + isRemovingTitan);
				logger.info("{}{}UMH_108A.FASDA.08 : {}", sClassName, sThisMethod,"alRAAccountList : " + alRAAccountList);

			} // end if alMemberDBList iteration

			HashMap hmRemoveAccountResponse = CommonUtil.getHashMap();

			createRemoveAccountInput(hmRemoveAccountInput, hmInput);


			if (isRemovingTitan) {
				hmRemoveAccountInput.put(CommonDefs.ACCOUNT_LIST, alRAAccountList);

				// 1510 - Merged 1507 SID#41549 - Updated for STAR Defect - if the call is
				// MergeSLIDProfile to Unlink SLID with LS Primary, only remove TITAN Account of
				// OWNER SLID.
				// This will keep TITAN and other TITANIZED Child accounts on other SLIDs intact
				if (sOrigTransactionName != null && sOrigTransactionName.equals("MergeSLIDProfile")) {
					hmRemoveAccountInput.put("processOwnerRequestOnly", MPSDefs.YES);
					hmRemoveAccountInput.put(CommonDefs.SLID, hmInput.get(CommonDefs.SLID));
					hmRemoveAccountInput.remove(CommonDefs.RES2BUS);
				} // END

				logger.debug("{}{}UMH_108A.FASDA.09 : Request to RemoveAccountHelper.removeAccount() transactionName={}, callingSystemId={}",
						sClassName, sThisMethod,
						HtmlUtils.htmlEscape(String.valueOf(hmRemoveAccountInput.get(CommonDefs.TRANSACTION_NAME))),
						HtmlUtils.htmlEscape(String.valueOf(hmRemoveAccountInput.get(CommonDefs.CALLING_SYSTEM_ID))));

				hmRemoveAccountResponse = invokeTitanAssociationHelper(hmRemoveAccountInput, hmInput);
				logger.debug("{}{}UMH_108A.FASDA.10 : {}", sClassName, sThisMethod,
						"Response from RemoveAccountHelper.removeAccount() " + StringUtils.normalizeSpace(
								hmRemoveAccountResponse != null ? hmRemoveAccountResponse.toString() : null));

				if (hmRemoveAccountResponse == null || hmRemoveAccountResponse.isEmpty()) {
					sAppInfo = "Response from RemoveAccountHelper() is NULL or EMPTY";

					logger.info("{}{}UMH_108A.FASDA.11 : {}", sClassName, sThisMethod, sAppInfo);
					hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
					return hmResponse;
				}
				sAppStatusCode = (String) hmRemoveAccountResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
				if (!(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode))) {
					sAppInfo = (String) hmRemoveAccountResponse.get(CErrorDefs.COMMON_APP_INFO);
					logger.info("{}{}UMH_108A.FASDA.12 : {}", sClassName, sThisMethod, StringUtils.normalizeSpace(sAppInfo));
					return hmRemoveAccountResponse;
				}

				if (hmRemoveAccountResponse.containsKey(CommonDefs.CONSOLIDATED_DBUS_INPUT)
						&& hmRemoveAccountResponse.get(CommonDefs.CONSOLIDATED_DBUS_INPUT) != null) {
					alRemoveAccountDbusEvents
							.addAll((ArrayList) hmRemoveAccountResponse.get(CommonDefs.CONSOLIDATED_DBUS_INPUT));

				}

				if (hmRemoveAccountResponse.containsKey(CommonDefs.CONSOLIDATED_MPS_INPUT)
						&& hmRemoveAccountResponse.get(CommonDefs.CONSOLIDATED_MPS_INPUT) != null) {
					hmRemoveAccountMPSObject
							.putAll((HashMap) hmRemoveAccountResponse.get(CommonDefs.CONSOLIDATED_MPS_INPUT));
				}

			}
			// REMOVE ACCOUNT flow [End]

			//TODO:check below code
			// Remove TITAN from in-memory SLID services after RemoveAccount.
			// In legacy, LinkInternetAccountHelper creates a new SLID internally and checks TITAN
			// against the new empty SLID (bUverseTitanAlreadyAssoToSLID=false -> AddAccount adds TITAN).
			// In the new code, LinkMemberHelper uses the passed-in old SLID data which still has TITAN,
			// causing bUverseTitanAlreadyAssocToSLID=true and skipping AddAccount.
			// Clearing TITAN here ensures LinkMemberHelper behaves like legacy.
			if (isRemovingTitan) {
				HashMap hmSlidServicesLocal = (HashMap) hmSlidDB.get(CommonDefs.SERVICES);
				if (hmSlidServicesLocal != null && hmSlidServicesLocal.containsKey(CommonDefs.TITAN_SERVICE)) {
					hmSlidServicesLocal.remove(CommonDefs.TITAN_SERVICE);
					logger.info("{}{}UMH_108A.FASDA.10.1 : {}", sClassName, sThisMethod,
							"Removed TITAN from in-memory SLID services after RemoveAccount so LinkMemberHelper will add fresh TITAN to new SLID");
				}
			}

			// LIA flow [Start]
			Iterator itrMemberDBList1 = alMemberDBList.iterator();
			HashMap hmUpdateMember = null;
			sSlid = (String) hmInput.get(CommonDefs.ACCESS_ID);

			if (hmInput.containsKey("autoSLIDCreation") && hmInput.get("autoSLIDCreation") != null) {
				autoSLIDCreation = (String) hmInput.get("autoSLIDCreation");
			}


			while (itrMemberDBList1.hasNext()) {

				hmMemberDB = CommonUtil.getHashMap();
				hmMemberDB = (HashMap) itrMemberDBList1.next();

				sMemberHandle = (String) hmMemberDB.get(MPSDefs.DB_MEMBER_NAME);
				sMemberDomain = (String) hmMemberDB.get(MPSDefs.DB_DOMAIN_NAME);
				sMemberSor = (String) hmMemberDB.get(MPSDefs.DB_SOR_NAME);
				sMemberParentChildInd = (String) hmMemberDB.get(MPSDefs.DB_PARENT_CHILD_IND);
				sMemberNum = (String) hmMemberDB.get(MPSDefs.DB_MEMBER_NUM);

				if (sSlid.equals(sMemberHandle + "@" + sMemberDomain) && !sOrigTransactionName.equals("MergeSLIDProfile") && !(sCallingSystemId.equals("DATAMGT") && sOrigTransactionName.equals("UnlinkInternetAccount"))) {
					sAppInfo = "Cannot unlink a fully-qualified .net id that matches the slid.";

					logger.info("{}{}UMH_108A.FASDA.13 : {}", sClassName, sThisMethod, sAppInfo);
					hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, sAppInfo);
					return hmResponse;
				}

				String sMemberAccountType = null;

				if (hmMemberDB.containsKey(CommonDefs.SERVICES) && hmMemberDB.get(CommonDefs.SERVICES) != null) {
					hmMemberServices = (HashMap) hmMemberDB.get(CommonDefs.SERVICES);

					isCreatingSlid = false;

					Iterator itrMemberServiceKeys = hmMemberServices.entrySet().iterator();

					// iteration for member services
					while (itrMemberServiceKeys.hasNext()) {
						mapEntry = (Entry) itrMemberServiceKeys.next();

						sServiceType = (String) mapEntry.getKey();
						hmThisService = (HashMap) mapEntry.getValue();
						sDefaultAccount = (String) hmThisService.get(MPSDefs.DB_DEFAULT_ACCOUNT);
						sServiceId = (String) hmThisService.get(MPSDefs.DB_SERVICE_ID);


						Iterator iterThisService = hmThisService.keySet().iterator();
						HashMap hmInstanceId = null;
						String sMatchingInstanceId = null;
						while (iterThisService.hasNext()) {
							sInstanceId = (String) iterThisService.next();
							Object oInstanceIdObject = hmThisService.get(sInstanceId);
							if (oInstanceIdObject instanceof HashMap) {
								hmInstanceId = CommonUtil.getHashMap();
								hmInstanceId = (HashMap) oInstanceIdObject;
								if (hmInstanceId != null) {
									sDefaultAccount = (String) hmInstanceId.get(MPSDefs.DB_DEFAULT_ACCOUNT);
									sServiceId = (String) hmInstanceId.get(MPSDefs.DB_SERVICE_ID);
									sMatchingInstanceId = sInstanceId;
								}
							}
						}

						if (sDefaultAccount != null && sDefaultAccount.equals(CommonDefs.DEFAULT_YES)) {

							hmUpdatedServiceWithN = CommonUtil.getHashMap();
							hmUpdatedServiceWithN.put(MPSDefs.DB_MEMBER_NUM, hmMemberDB.get(MPSDefs.DB_MEMBER_NUM));
							hmUpdatedServiceWithN.put(MPSDefs.DB_SERVICE_ID, sServiceId);
							hmUpdatedServiceWithN.put(MPSDefs.DB_INSTANCE_ID, sMatchingInstanceId);
							hmUpdatedServiceWithN.put(MPSDefs.DB_DEFAULT_ACCOUNT, "N");
							hmUpdatedServiceWithN.put(MPSDefs.DB_CPNI_IMPACTED, "N");
							hmUpdatedServiceWithN.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);

							alMemberService.add(hmUpdatedServiceWithN);

							isUnlinkingDefault = true;
							sDefaultAccountMemberNum = (String) hmMemberDB.get(MPSDefs.DB_MEMBER_NUM);

						}
					}// service iteration ends
					// 1510 : US450941 - As RIL UnlinkInternetAccount, I want to autogenerate a matching Access id if the customer unlinks a Member Id,
					// so that an Access Id will be created for all eligible Member Ids.
					if (sCallingSystemId != null && !sCallingSystemId.equalsIgnoreCase(CommonDefs.DATAMGT)
							&& (autoSLIDCreation == null || !autoSLIDCreation.equalsIgnoreCase("N"))) {
						String stMemberAccType = (String) hmMemberDB.get(MPSDefs.DB_ACCOUNT_TYPE);
						String stMemberAccSubType = (String) hmMemberDB.get(MPSDefs.DB_ACCOUNT_SUBTYPE);
						String stSorId = (String) hmMemberDB.get(MPSDefs.DB_SOR_ID);
						String stAggServiceStatus = (String) hmMemberDB.get(MPSDefs.DB_AGG_SERVICE_STATUS);
						logger.info("{}{}UMH_108A.FASDA.14 : {}", sClassName, sThisMethod, "stMemberAccType :" + stMemberAccType +
								" stMemberAccSubType :" + stMemberAccSubType + " stSorId :" + stSorId + " stAggServiceStatus :" + stAggServiceStatus);
						//1707:PID 292253: SMB Wireline Migrate to myAT&T Service.US7:Updates to support autogeneration of Access id for small business Uverse, DSL,Dial member id�s.
						List alValidAccessIdAccountTypes = CommonUtil.parseToArray(sValidAccessIdAccountTypes, CommonDefs.VALUE_SEPARATOR_CHAR);

						logger.info("{}{}UMH_108A.FASDA.15 : {}", sClassName, sThisMethod,
								" ArrayList alValidAccessIdAccountTypes =" + alValidAccessIdAccountTypes);

						if (stAggServiceStatus != null && stAggServiceStatus.equalsIgnoreCase("0")) {//to check enabled services
							if (stSorId != null && stSorId.equalsIgnoreCase("6")) {//to check if member is LS sor

								String sDeviredAccoutType = calculateAccountType(stMemberAccType, stMemberAccSubType);
								if (sDeviredAccoutType != null && sDeviredAccoutType.equalsIgnoreCase("R"))
									isCreatingSlid = true;
							}// 1602 : US# 567973 : SID 42710 : To Auto-generate Access IDs for memberIDs with Null Account Type
							else if (stMemberAccType == null || (alValidAccessIdAccountTypes != null && alValidAccessIdAccountTypes.contains(stMemberAccType))) {//1707:US7:Updates to support autogeneration of Access id for small business Uverse, DSL,Dial member id�s.
								isCreatingSlid = true;
							}//
						}
					}// 1510 ends

				}


				logger.info("{}{}UMH_108A.FASDA.16 : {}", sClassName, sThisMethod, "isCreatingSlid : " + isCreatingSlid);
				logger.debug("{}{}UMH_108A.FASDA.17 : {}", sClassName, sThisMethod,"alRemovedDefaultAccount : " + alRemovedDefaultAccount);

				Map hmLinkMemberInput = CommonUtil.getHashMap();
				Map hmLinkInternetAccountResponse = CommonUtil.getHashMap();
				// 1510 : US450941 - As RIL UnlinkInternetAccount, I want to autogenerate a matching Access id if the customer unlinks a Member Id,
				// so that an Access Id will be created for all eligible Member Ids.

				if (isCreatingSlid) {
					hmLinkMemberInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
					hmLinkMemberInput.put(CommonDefs.TRANSACTION_NAME, "LinkInternetAccount");
					hmLinkMemberInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.IDPTRACEID));
					hmLinkMemberInput.put(ProfileOrchestrationConstants.IDPTRACEID, hmInput.get(ProfileOrchestrationConstants.IDPTRACEID));
					hmLinkMemberInput.put(CommonDefs.ORIG_TRANSACTION_NAME, sOrigTransactionName);
					hmLinkMemberInput.put(CommonDefs.SLID, sMemberHandle + "@" + sMemberDomain);
					hmLinkMemberInput.put(CommonDefs.ACCESS_ID, sMemberHandle + "@" + sMemberDomain);
					hmLinkMemberInput.put(CommonDefs.MEMBERID, sMemberHandle);
					hmLinkMemberInput.put(CommonDefs.CALLDBUS, CommonDefs.IND_N);
					hmLinkMemberInput.put("byPassHRS", "Y");
					hmLinkMemberInput.put(CommonDefs.CALLMPS, CommonDefs.IND_Y);
					hmLinkMemberInput.put(CommonDefs.HANDLE, sMemberHandle);
					hmLinkMemberInput.put(CommonDefs.DOMAIN, sMemberDomain);
					hmLinkMemberInput.put("ignoreEDDNotification", "Y");
					hmLinkMemberInput.put("bypassSuggestHandleHelper", "Y");
					hmLinkMemberInput.put("ignoreMonitorBAN", CommonDefs.IND_Y);
					if (hmInput.containsKey(CommonDefs.AGENT_ID) && hmInput.get(CommonDefs.AGENT_ID) != null) {
						hmLinkMemberInput.put(CommonDefs.AGENT_ID, hmInput.get(CommonDefs.AGENT_ID));
					}

					// Persist slid_member_num=null to DB BEFORE calling linkMember.
					// The 1-param linkMember queries member fresh from DB and checks slid_member_num at line 413.
					// If it's still set, it returns ERR_ID_ALREADY_LINKED_TO_SLID.
					// In legacy, LinkInternetAccountHelper didn't have this check in the equivalent code path.
					// So we must nullify it in DB first to let the 1-param linkMember proceed.
					HashMap<String, Object> hmPreUpdateInput = CommonUtil.getHashMap();
					hmPreUpdateInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
					hmPreUpdateInput.put(CommonDefs.TRANSACTION_NAME, sOrigTransactionName);
					hmPreUpdateInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.IDPTRACEID));
					ArrayList alPreUpdateMember = CommonUtil.getArrayList();
					HashMap<String, Object> hmPreUpdate = CommonUtil.getHashMap();
					hmPreUpdate.put(MPSDefs.DB_MEMBER_NUM, hmMemberDB.get(MPSDefs.DB_MEMBER_NUM));
					hmPreUpdate.put(MPSDefs.DB_SLID_MEMBER_NUM, null);
					hmPreUpdate.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);
					alPreUpdateMember.add(hmPreUpdate);
					hmPreUpdateInput.put(MPSDefs.DB_MEMBER_TABLE, alPreUpdateMember);

					logger.info("{}{}UMH_108A.FASDA.17.1 : {}", sClassName, sThisMethod,
							"Pre-persisting slid_member_num=null for member_num=" + hmMemberDB.get(MPSDefs.DB_MEMBER_NUM));
					HashMap hmPreUpdateResp = updateMemberDataHelper.processData(hmPreUpdateInput);
					logger.info("{}{}UMH_108A.FASDA.17.2 : {}", sClassName, sThisMethod,
							"Pre-update response: " + StringUtils.normalizeSpace(hmPreUpdateResp != null ? hmPreUpdateResp.toString() : null));

					if (hmPreUpdateResp == null || hmPreUpdateResp.isEmpty()) {
						sAppInfo = "Response from pre-update slid_member_num=null is NULL or EMPTY";
						logger.error("{}{}UMH_108A.FASDA.17.3 : {}", sClassName, sThisMethod, sAppInfo);
						hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
						return hmResponse;
					}
					String sPreUpdateStatus = (String) hmPreUpdateResp.get(CErrorDefs.COMMON_APP_STATUS_CODE);
					if (!(CommonDefs.COMMON_SUCCESS.equals(sPreUpdateStatus))) {
						sAppInfo = "Failed to pre-update slid_member_num=null: " + hmPreUpdateResp.get(CErrorDefs.COMMON_APP_INFO);
						logger.error("{}{}UMH_108A.FASDA.17.4 : {}", sClassName, sThisMethod, StringUtils.normalizeSpace(sAppInfo));
						return hmPreUpdateResp;
					}

					// Also update in-memory so later alUpdateMember doesn't conflict
					hmMemberDB.put(MPSDefs.DB_SLID_MEMBER_NUM, null);

					logger.info("{}{}UMH_108A.FASDA.18 : {}", sClassName, sThisMethod, "Request to linkMemberHelper.linkMember() " + hmLinkMemberInput);

					// Use 1-param linkMember which handles everything internally:
					// 1. queryMemberInfo -> finds member with slid_member_num=null (just persisted)
					// 2. handleSlidInfoValidation -> querySlidInfo -> SLID qaymaXXX@att.net@slid.dum not found (REC_NOT_FOUND)
					// 3. bSlidMatchesMemberId=true + REC_NOT_FOUND -> preCreateSlid -> createSLID -> new SLID created
					// 4. processLinkMember -> uses new SLID member_num -> AddAssociation adds TITAN to new SLID
					// This matches legacy where LinkInternetAccountHelper handled everything internally.
					hmLinkInternetAccountResponse = linkMemberHelper.linkMember(hmLinkMemberInput);
					logger.info("{}{}UMH_108A.FASDA.19 : {}", sClassName, sThisMethod, "Response from linkMemberHelper.linkMember()() " + StringUtils.normalizeSpace(
							hmLinkInternetAccountResponse != null ? hmLinkInternetAccountResponse.toString() : null));

					if (hmLinkInternetAccountResponse == null || hmLinkInternetAccountResponse.isEmpty()) {
						sAppInfo = "Response from LinkInternetAccountHelper() is NULL or EMPTY";

						logger.error("{}{}UMH_108A.FASDA.20 : {}", sClassName, sThisMethod, sAppInfo);
						hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
						return hmResponse;
					}
					sAppStatusCode = (String) hmLinkInternetAccountResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
					if (!(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode))) {
						sAppInfo = (String) hmLinkInternetAccountResponse.get(CErrorDefs.COMMON_APP_INFO);
						logger.info("{}{}UMH_108A.FASDA.21 : {}", sClassName, sThisMethod, StringUtils.normalizeSpace(sAppInfo));
						return (HashMap) hmLinkInternetAccountResponse;
					}

					if (hmLinkInternetAccountResponse.containsKey(CommonDefs.CONSOLIDATED_DBUS_INPUT) && hmLinkInternetAccountResponse.get(CommonDefs.CONSOLIDATED_DBUS_INPUT) != null) {
						alLinkInternetAccountDbusEvents.addAll((ArrayList) hmLinkInternetAccountResponse.get(CommonDefs.CONSOLIDATED_DBUS_INPUT));
					}

				}// 1510 code ends
				else {
					hmUpdateMember = CommonUtil.getHashMap();

					hmUpdateMember.put(CommonDefs.HANDLE, hmMemberDB.get(MPSDefs.DB_MEMBER_NAME));
					hmUpdateMember.put(CommonDefs.DOMAIN, hmMemberDB.get(MPSDefs.DB_DOMAIN_NAME));
					hmUpdateMember.put(MPSDefs.DB_MEMBER_NUM, hmMemberDB.get(MPSDefs.DB_MEMBER_NUM));
					hmUpdateMember.put(MPSDefs.DB_SLID_MEMBER_NUM, null);
					hmUpdateMember.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);
					alUpdateMember.add(hmUpdateMember);
				}


			} // end if alMemberDBList iteration

			// LIA flow [End]

			logger.debug("{}{}UMH_108A.FASDA.22 : {}", sClassName, sThisMethod,"alUpdateMember : " + alUpdateMember);

			logger.info("{}{}UMH_108A.FASDA.23 : {}", sClassName, sThisMethod,"sUverseMemberNum : " + sUverseMemberNum);
			logger.info("{}{}UMH_108A.FASDA.24: {}", sClassName, sThisMethod, "sUverseBan : " + sUverseBan);

			logger.info("{}{}UMH_108A.FASDA.25 : {}", sClassName, sThisMethod,"alMemberService : " + alMemberService);
			logger.info("{}{}UMH_108A.FASDA.26 : {}", sClassName, sThisMethod, "isUnlinkingDefault : " + isUnlinkingDefault);

			hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS);

			if (!alRemoveAccountDbusEvents.isEmpty()) {
				hmResponse.put(CommonDefs.REMOVE_ACCOUNT_DBUS_EVENTS, alRemoveAccountDbusEvents);
			}
			if (!hmRemoveAccountMPSObject.isEmpty()) {
				hmResponse.put(CommonDefs.REMOVE_ACCOUNT_MPS_OBJECT, hmRemoveAccountMPSObject);
			}
			if (!alLinkInternetAccountDbusEvents.isEmpty()) {
				hmResponse.put(CommonDefs.LINK_INTERNET_ACCOUNT_DBUS_EVENTS, alLinkInternetAccountDbusEvents);
			}

			// too much code below this to migrate
		} catch (Exception e) {
			hmResponse     = CommonErrorMap.makeExceptionMap(e);
			sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
			logger.info("{}{}UMH_108A.FASDA.27 : {}", sClassName, sThisMethod, "error hash map = "+hmResponse);
			logger.info("{}{}UMH_108A.FASDA.28 : {}", sClassName, sThisMethod,  "Exception::Exception = "+e.getMessage());
		}
		finally{
			if(hmUpdatedService.isEmpty()){ // means we don't found a qualifying default_account
				if(hmResponse == null || hmResponse.isEmpty()){
					hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS);
				}
				logger.info("{}{}UMH_108A.FASDA.29 : {}", sClassName, sThisMethod,"No qualifying default account was found.");
			}
			else{
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS);
				alMemberService.add(hmUpdatedService);	
				hmInput.put(CommonDefs.ACCOUNT_INVARIANT_ID,sAccountInvariantId);
				hmInput.put(CommonDefs.ACCOUNT_TYPE,sAccountType);
				hmInput.put("serviceSorName",sServiceSorName);
				hmInput.put("sDefaultAccountMemberNum",sDefaultAccountMemberNum);
			}
			
			if(hmResponse != null && !hmResponse.isEmpty() && hmResponse.containsKey(CErrorDefs.COMMON_APP_STATUS_CODE))
				sAppStatusCode = (String) hmResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);

			
			if (sAppStatusCode != null && CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode))
			{
				// db updates
				if(!alMemberService.isEmpty()){
					hmResponse.put(MPSDefs.DB_MEMBERSERVICE_TABLE,alMemberService);
				}
				if(!alUpdateMember.isEmpty()){
					hmResponse.put(MPSDefs.DB_MEMBER_TABLE,alUpdateMember);
				}
				if(!hmRemoveAccountMPSObject.isEmpty()){
					hmResponse.put(CommonDefs.REMOVE_ACCOUNT_MPS_OBJECT, hmRemoveAccountMPSObject);
				}

				
				// dbus events
				if(!alRemoveAccountDbusEvents.isEmpty()){
					hmResponse.put(CommonDefs.REMOVE_ACCOUNT_DBUS_EVENTS, alRemoveAccountDbusEvents);
				}
				if(!alLinkInternetAccountDbusEvents.isEmpty()){
					hmResponse.put(CommonDefs.LINK_INTERNET_ACCOUNT_DBUS_EVENTS, alLinkInternetAccountDbusEvents);
				}
			}
		}
		
		return hmResponse;
	}

	private HashMap<String, Object> invokeTitanAssociationHelper(Map<String, Object> hmRemoveAccountInput, Map<String, Object> hmInput) {
		HashMap<String, Object> hmRequest = CommonUtil.getHashMap();
		hmRequest.putAll(hmRemoveAccountInput);
		hmRequest.put(CommonDefs.TRANSACTION_NAME, "RemoveAssociation");
		hmRequest.put(ProfileOrchestrationConstants.IDPTRACEID, hmInput.get(ProfileOrchestrationConstants.IDPTRACEID));
		hmRequest.put("userId", hmRemoveAccountInput.containsKey(CommonDefs.SLID) ? hmRemoveAccountInput.get(CommonDefs.SLID) : hmInput.get(CommonDefs.ACCESS_ID));
		hmRequest.put(CommonDefs.CALLDBUS, Boolean.FALSE);

		Object accountListObj = hmRemoveAccountInput.get(CommonDefs.ACCOUNT_LIST);
		if (accountListObj instanceof List<?> rawAccountList) {
			List<Map<String, Object>> alAssociationList = new ArrayList<>();
			for (Object item : rawAccountList) {
				if (item instanceof Map<?, ?> rawMap) {
					@SuppressWarnings("unchecked")
					Map<String, Object> hmAccount = (Map<String, Object>) rawMap;
					HashMap<String, Object> hmAssociation = CommonUtil.getHashMap();
					hmAssociation.put("serviceName", hmAccount.get(CommonDefs.ACCOUNT_TYPE));
					hmAssociation.put("sorInvariantId", StringUtils.lowerCase((String) hmAccount.get(CommonDefs.ACCOUNT_INVARIANT_ID)));
					hmAssociation.put("sorName", hmAccount.get(CommonDefs.ACCOUNT_SOR));
					hmAssociation.put(MPSDefs.DB_SOR_INVARIANT_ID1, StringUtils.lowerCase((String) hmAccount.get(CommonDefs.ACCOUNT_INVARIANT_ID)));
					hmAssociation.put(MPSDefs.DB_SOR_NAME, hmAccount.get(CommonDefs.ACCOUNT_SOR));
					hmAssociation.put(MPSDefs.DB_SERVICE_TYPE, hmAccount.get(CommonDefs.ACCOUNT_TYPE));
					alAssociationList.add(hmAssociation);
				}
			}
			hmRequest.put("associationList", alAssociationList);
		}

		return (HashMap<String, Object>) removeAccountHelper.removeAccount(hmRequest);
	}

	/**
	 * Creates the input map for removing an account.
	 *
	 * This method populates the {@code hmRemoveAccountInput} map with necessary data from the {@code hmInput} map
	 * to facilitate the removal of an account. It extracts and sets various parameters required for
	 * the account removal process.
	 *
	 * @param hmRemoveAccountInput the map to be populated with account removal data
	 * @param hmInput the input map containing various parameters for the account removal process
	 */
	private void createRemoveAccountInput(Map<String, Object> hmRemoveAccountInput, Map<String, Object> hmInput) {
		hmRemoveAccountInput.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		hmRemoveAccountInput.put(CommonDefs.TRANSACTION_NAME, "RemoveAccount");
		hmRemoveAccountInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
		hmRemoveAccountInput.put(CommonDefs.ORIG_TRANSACTION_NAME, (String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME));
		hmRemoveAccountInput.put(CommonDefs.RES2BUS, (String) hmInput.get(CommonDefs.RES2BUS));
		hmRemoveAccountInput.put("getInfoCalled", CommonDefs.DEFAULT_NO);
		hmRemoveAccountInput.put("suppressNotification", CommonDefs.DEFAULT_YES);
		hmRemoveAccountInput.put(CommonDefs.CALLMPS, Boolean.FALSE);
		hmRemoveAccountInput.put(CommonDefs.CALLDBUS, Boolean.FALSE);
		if (hmInput.containsKey(CommonDefs.AGENT_ID) && hmInput.get(CommonDefs.AGENT_ID) != null) {
			hmRemoveAccountInput.put(CommonDefs.AGENT_ID, hmInput.get(CommonDefs.AGENT_ID));
		}
	}

	/**
	 * Checks if there are any associated members with authorized user access i.e Authorized user role.
	 *
	 * This method verifies if any associated members have authorized user access to a given instance.
	 * It is used to ensure that certain operations are not performed if there are authorized users linked.
	 *
	 * @param hmAssociatedMemberDB the hashmap containing associated member database information
	 * @param hmInput the input map containing various parameters
	 * @param sInstanceId the instance ID to check for authorized user access
	 * @return true if there are associated members with authorized user access, false otherwise
	 */
	private boolean checkAssociatedMembersForAuthUser(HashMap hmAssociatedMemberDB, Map hmInput, String sInstanceId) {
		ArrayList alAssociatedMembers = CommonUtil.getArrayList();
		HashMap hmAssociatedMember = null;
		HashMap hmAsscociatedMemberService = null;
		HashMap hmThisAssociatedService = null;
		String sAssociatedServiceType = null;
		Entry mapEntry1 = null;
		ArrayList alAssociatedRoles = null;
		HashMap hmThisAssociatedRole = CommonUtil.getHashMap();
		String sAssciatedRoleStatus = null;
		boolean isAuthUserLinked = false;

		alAssociatedMembers = (ArrayList) hmAssociatedMemberDB
				.get(CommonDefs.ASSOCIATED_MEMBERS);

		if (alAssociatedMembers != null && alAssociatedMembers.size() > 0) {
			Iterator itrAssociatedMembers = alAssociatedMembers.iterator();

			while (itrAssociatedMembers.hasNext()) {
				hmAssociatedMember = CommonUtil.getHashMap();
				hmAssociatedMember = (HashMap) itrAssociatedMembers.next();

				if ((hmAssociatedMember.get(MPSDefs.DB_PARENT_CHILD_IND))
						.equals("S")
						&& !((hmAssociatedMember
								.get(MPSDefs.DB_MEMBER_NAME))
								.equals(hmInput.get(CommonDefs.SLID)))) {

					if (hmAssociatedMember.containsKey(CommonDefs.SERVICES)
							&& hmAssociatedMember
									.get(CommonDefs.SERVICES) != null) {
						hmAsscociatedMemberService = CommonUtil
								.getHashMap();
						hmAsscociatedMemberService = (HashMap) hmAssociatedMember
								.get(CommonDefs.SERVICES);
						Iterator itrAssocaitedServiceKeys = hmAsscociatedMemberService
								.entrySet().iterator();

						while (itrAssocaitedServiceKeys.hasNext()) {
							mapEntry1 = (Entry) itrAssocaitedServiceKeys
									.next();
							hmThisAssociatedService = CommonUtil
									.getHashMap();
							hmThisAssociatedService = (HashMap) mapEntry1
									.getValue();
							sAssociatedServiceType = (String) mapEntry1
									.getKey();
							HashMap hmAssociatedInstanceId = null;

							Iterator iterAssociatedService = hmThisAssociatedService
									.keySet().iterator();
							while (iterAssociatedService.hasNext()) {
								sInstanceId = (String) iterAssociatedService
										.next();

								Object oInstanceIdObject1 = hmThisAssociatedService
										.get(sInstanceId);
								if (oInstanceIdObject1 instanceof HashMap) {
									hmAssociatedInstanceId = CommonUtil
											.getHashMap();
									hmAssociatedInstanceId = (HashMap) oInstanceIdObject1;

									if (hmAssociatedInstanceId != null
											&& sAssociatedServiceType
													.equals(CommonDefs.TITAN_SERVICE)) {
										alAssociatedRoles = CommonUtil
												.getArrayList();
										alAssociatedRoles = (ArrayList) hmAssociatedInstanceId
												.get(MPSDefs.DB_ROLES);
										if (alAssociatedRoles != null
												&& alAssociatedRoles
														.size() > 0) {
											Iterator itrAssociatedRole = alAssociatedRoles
													.iterator();
											while (itrAssociatedRole
													.hasNext()) {
												hmThisAssociatedRole = (HashMap) itrAssociatedRole
														.next();
												sAssciatedRoleStatus = (String) hmThisAssociatedRole
														.get(MPSDefs.DB_ROLE_NAME);

												if (sAssciatedRoleStatus
														.equals(CommonDefs.KEY_ROLE_NAME_AUTHORIZEDUSER)) {
													isAuthUserLinked = true;
												}
											}
										}
									}

								}
							}
						}
					}

				}

			}
		}
		return isAuthUserLinked;
	}

	private boolean checkforTitanizedMobility(HashMap hmSlidServices, HashMap hmInstanceId) {
		Iterator itrSlidService = hmSlidServices.entrySet().iterator();
		HashMap hmThisSlidService_pass2 = null;
		String sServiceType_pass2 = null;
		Entry mapEntry2 = null;
		String sInstanceId_pass2 = null;
		boolean isTitanized = false;

		while (itrSlidService.hasNext()) {
			mapEntry2 = (Entry) itrSlidService.next();

			hmThisSlidService_pass2 = CommonUtil.getHashMap();
			hmThisSlidService_pass2 = (HashMap) mapEntry2.getValue();

			sServiceType_pass2 = (String) mapEntry2.getKey();

			// iteration for instance services
			Iterator iterParentService_pass2 = hmThisSlidService_pass2
					.keySet().iterator();
			while (iterParentService_pass2.hasNext()) {

				sInstanceId_pass2 = (String) iterParentService_pass2.next();
				Object oInstanceIdObject_pass2 = hmThisSlidService_pass2
						.get(sInstanceId_pass2);
				if (oInstanceIdObject_pass2 instanceof HashMap) {
					HashMap hmInstanceId_itr2 = (HashMap) oInstanceIdObject_pass2;

					// 1510 - Merged 1507 SID#41549 - Updated for STAR
					// Project Defect - check for TITANIZED Child Accounts
					// to return error
					if (hmInstanceId_itr2 != null
							&& hmInstanceId_itr2
									.get(MPSDefs.DB_PARENT_SOR_ID) != null
							&& (hmInstanceId_itr2
									.get(MPSDefs.DB_PARENT_SOR_ID))
									.equals(hmInstanceId
											.get(MPSDefs.DB_SOR_ID))
							&& hmInstanceId_itr2.get(
									MPSDefs.DB_PARENT_SOR_INVARIANT_ID) != null
							&& (hmInstanceId_itr2.get(
									MPSDefs.DB_PARENT_SOR_INVARIANT_ID))
									.equals(hmInstanceId.get(
											MPSDefs.DB_SOR_INVARIANT_ID))) {

						isTitanized = true;

					}
				}
			}
		}
		return isTitanized;
	}

	/**
	 * Checks for linked members and updates the input map with Uverse member information if found.
	 *
	 * @param hmInput the input map containing various parameters
	 * @param alSlidLinkedUsers the list of linked users associated with the SLID
	 * @param alMemberIdList the list of member IDs to be unlinked
	 * @throws ParseException if there is an error parsing the service creation date
	 */
	private void checkForLinkedMembers(Map<String, Object> hmInput, ArrayList alSlidLinkedUsers,
			ArrayList alMemberIdList) throws ParseException {
		String sThisMethod = ".checkForLinkedMembers.";
		String sServiceType = null;
		String sServiceStatus = null;
		String sInstanceId = null;

		HashMap hmThisService = CommonUtil.getHashMap();
		HashMap hmMemberServices = CommonUtil.getHashMap();
		HashMap hmMemberDB = null;

		Entry mapEntry = null;

		String sMemberBan = null;
		String sMemberNum = null;
		String sUverseMemberNum 	= null;
		String sUverseBan			= null;
		long lServiceCreateDate = -1;
		long lUverseCreateDate = -1;
		DateFormat objDateFormat = new SimpleDateFormat("MMddyyyy HH:mm:ss");
		Iterator itrHsMember = alSlidLinkedUsers.iterator();
		
		logger.debug("{}{}UMH_108A.CFLM.01 : {}",sClassName, sThisMethod,"alSlidLinkedUsers : " + alSlidLinkedUsers);
		
		while(itrHsMember.hasNext()){
			hmMemberDB=(HashMap)itrHsMember.next();
			
			if (hmMemberDB != null && !hmMemberDB.isEmpty()) {
				// checking that the linked member should not be one which is to be unlinked.
			
				sMemberNum = (String) hmMemberDB.get(MPSDefs.DB_MEMBER_NUM);
				logger.info("{}{}UMH_108A.CFLM.02 : {}", sClassName, sThisMethod,"hmMemberDB : " + hmMemberDB);
				logger.info("{}{}UMH_108A.CFLM.03 : {}", sClassName, sThisMethod,"sMemberNum : " + sMemberNum);

				if(!alMemberIdList.contains(sMemberNum)){
					if(hmMemberDB.containsKey(CommonDefs.SERVICES) && hmMemberDB.get(CommonDefs.SERVICES) != null){
			    		hmMemberServices=(HashMap)hmMemberDB.get(CommonDefs.SERVICES);
			    		
			    		Iterator itrMemberServiceKeys = hmMemberServices.entrySet().iterator();
			    		
			    		// iteration for member services
			    		while(itrMemberServiceKeys.hasNext()){
			    			mapEntry = (Entry)itrMemberServiceKeys.next();
			    			
			    			sServiceType=(String)mapEntry.getKey();
			    			hmThisService = (HashMap)mapEntry.getValue();
			    			
							sServiceStatus=(String)hmThisService.get(MPSDefs.SERVICE_STATUS);
	
							// iteration for instance services
							Iterator iterParentService = hmThisService.keySet().iterator();
							while (iterParentService.hasNext()){
								sInstanceId = (String) iterParentService.next();
								Object oInstanceIdObject = hmThisService.get(sInstanceId);
								if (oInstanceIdObject instanceof HashMap) 
								{
									HashMap hmInstanceId = (HashMap) oInstanceIdObject;
									if (hmInstanceId != null){
										sServiceStatus=(String)hmInstanceId.get(MPSDefs.SERVICE_STATUS);	
										lServiceCreateDate=objDateFormat.parse((String)hmInstanceId.get( MPSDefs.DB_CREATE_DATE)).getTime();
										sMemberBan = (String) hmMemberDB.get(MPSDefs.DB_BAN);
									}
									
								} //end of if object is instance of HashMap
							}
	
							logger.debug("{}{}UMH_108A.CFLM.04 : {}",sClassName, sThisMethod,"lServiceCreateDate : "+ lServiceCreateDate);
							logger.debug("{}{}UMH_108A.CFLM.05 : {}",sClassName, sThisMethod,"lUverseCreateDate : "+ lUverseCreateDate);
							
							if(sServiceType.equals(CommonDefs.UVERSE_SERVICE) && 
									(sServiceStatus.equals(MPSDefs.ENABLED) || sServiceStatus.equals(MPSDefs.SUSPENDED))){ 

								if(lUverseCreateDate == -1){
									lUverseCreateDate = lServiceCreateDate;
									sUverseMemberNum = sMemberNum;
									sUverseBan = sMemberBan;
								}
								else if(lServiceCreateDate <= lUverseCreateDate){
									lUverseCreateDate = lServiceCreateDate;
									sUverseMemberNum = sMemberNum;
									sUverseBan = sMemberBan;
								}
								
								hmInput.put("UverseMemberNum", sUverseMemberNum);
								hmInput.put("UverseBan", sUverseBan);
								
							}
			    		}
					}
				}
			}
		}
		
	}

	/**
	 * Retrieves associated members based on the provided input.
	 *
	 * @param hmInput the input map containing various parameters
	 * @return a HashMap containing the associated members
	 */
	private HashMap getAssociatedMembers(HashMap hmInput) {
		String sThisMethod = ".getAssociatedMembers.";
		String sAppInfo = null;
		String sAppStatusCode = null;
		
		HashMap hmGAMInput = CommonUtil.getHashMap();
		HashMap hmResponse = CommonUtil.getHashMap();
		
		hmGAMInput.putAll(hmInput);
		
		ArrayList alQueryRoles = CommonUtil.getArrayList();
		alQueryRoles.add(CommonDefs.TITAN_SERVICE);
		hmGAMInput.put("queryRolesInfoFlag", alQueryRoles);
		hmGAMInput.put("serviceInfoRequired", CommonDefs.DEFAULT_YES);
		
		try {
			// call to getAssociatedMembersDBHelper.getAssociatedMembers
			logger.info("{}{}UMH_108A.GAM.01 : {}",sClassName, sThisMethod, "Calling getAssociatedMembersDBHelper.getAssociatedMembers with input: " + hmGAMInput); //June 2014 - Updated for SID# 30866
			hmResponse = getAssociatedMembersDBHelper.getAssociatedMembers(hmGAMInput);
			logger.info("{}{}UMH_108A.GAM.02 : {}",sClassName, sThisMethod, "GAM03"+ "Response from getAssociatedMembersDBHelper.getAssociatedMembers :" + hmResponse);

			if (hmResponse == null || hmResponse.isEmpty()) {
				sAppInfo = "Response from getAssociatedMembersDBHelper.getAssociatedMembers() is NULL or EMPTY";

				logger.info("{}{}UMH_108A.GAM.03 : {}",sClassName, sThisMethod,sAppInfo);
				hmResponse = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo );
				return hmResponse;
			} 
			
			sAppStatusCode = (String) hmResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
		    if (!(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode)))
			{
		    	sAppInfo =(String) hmResponse.get(CErrorDefs.COMMON_APP_INFO);
		    	logger.info("{}{}UMH_108A.GAM.04 : {}",sClassName, sThisMethod,sAppInfo);
				return hmResponse;
			}
		} catch (Exception exp) {
			hmResponse     = CommonErrorMap.makeExceptionMap(exp);
			logger.debug("{}{}UMH_108A.GAM.05 : {}",sClassName, sThisMethod,"error hash map = "+hmResponse);
			logger.info("{}{}UMH_108A.GAM.06 : {}",sClassName,sThisMethod,"Exception::Exception = "+exp.getMessage());
		}
	    return hmResponse;
	}

	/**
	 * Calculates the account type based on the provided account type and account subtype.
	 *
	 * This method determines the derived account type by evaluating the given account type
	 * and account subtype. It returns a string representing the calculated account type.
	 *
	 * @param accountType the type of the account
	 * @param accountSubType the subtype of the account
	 * @return a string representing the calculated account type
	 */
	public String calculateAccountType(String accountType, String accountSubType) {

		String sThisMethod = "calculateAccountType";
		String derivedAccountType = null;
		List alResidentialAccountSubTypes = null;
		List alBusinessAccountSubTypes = null;
		List alEnterpriseAccountSubTypes = null;
	
		// 1707 : EPIC PID 292253: SMB Wireline Migrate to myAT&T Service : US9: updated to retreive property into arrayList
		// ResidentialAccountSubTypes=R|H|S|9
		alResidentialAccountSubTypes = CommonUtil.parseToArray(sResidentialAccountSubTypes, CommonDefs.VALUE_SEPARATOR_CHAR);
		logger.info("{}{}UMH_108A.CAT.01 : {}", sClassName ,sThisMethod,"Property ResidentialAccountSubTypes : " + alResidentialAccountSubTypes);

		alBusinessAccountSubTypes = CommonUtil.parseToArray(sBusinessAccountSubTypes, CommonDefs.VALUE_SEPARATOR_CHAR);
		logger.info("{}{}UMH_108A.CAT.02 : {}", sClassName,sThisMethod,"Property BusinessAccountSubTypes : " + alBusinessAccountSubTypes);
		
		// 1708 : SID : 55368 : Update to not autogenerate the accessId when UBAN’s account_subtype=E (Enterprise)
		alEnterpriseAccountSubTypes = CommonUtil.parseToArray(sEnterpriseAccountSubTypes, CommonDefs.VALUE_SEPARATOR_CHAR);
		logger.info("{}{}UMH_108A.CAT.03 : {}",sClassName, sThisMethod,"Property LSREG_INVALID_ACCOUNT_SUBTYPES : " + alEnterpriseAccountSubTypes);

		if (accountSubType != null && !accountSubType.isEmpty()) {
			if (alBusinessAccountSubTypes != null && alBusinessAccountSubTypes.contains(accountSubType)) {
				derivedAccountType = MPSDefs.DB_BUSINESS;
			} else if (alResidentialAccountSubTypes != null && alResidentialAccountSubTypes.contains(accountSubType)) {
				derivedAccountType = MPSDefs.DB_CONSUMER;
			}else if (alEnterpriseAccountSubTypes != null && alEnterpriseAccountSubTypes.contains(accountSubType)) {
				derivedAccountType = "E";
			} else {
				derivedAccountType = accountType;
			}
		} else {
			derivedAccountType = accountType;
		}
		logger.info("{}{}UMH_108A.CAT.04 : {}", sClassName, sThisMethod, "derivedAccountType: " + derivedAccountType);
		return derivedAccountType;
	}
}
