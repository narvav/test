package com.att.idp.idgraphusermanagementms.resource.request;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import jakarta.persistence.MappedSuperclass;
import jakarta.validation.constraints.Size;


@MappedSuperclass
@Schema(name = "baseUserRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class BaseUserRequest {

	@Schema(name = "online1SecurityQuestion")
	@Size(min=1, max=80,message="online1SecurityQuestion length is invalid")
	private String online1SecurityQuestion;
	
	@Schema(name = "online1SecurityAnswer")
	@Size(min=1, max=80,message="online1SecurityAnswer length is invalid")
	private String online1SecurityAnswer;
	
	@Schema(name = "online2SecurityQuestion")
	@Size(min=1, max=80,message="online2SecurityQuestion length is invalid")
	private String online2SecurityQuestion;
	
	@Schema(name = "online2SecurityAnswer")
	@Size(min=1, max=80,message="online2SecurityAnswer length is invalid")
	private String online2SecurityAnswer;
	
	@Schema(name = "contactEmail")
	@Size(min=1, max=60,message="contactEmail length is invalid")
	private String contactEmail;
	
	@Schema(name = "firstName")
	@Size(min=1, max=50,message="firstName length is invalid")
	private String firstName;
	
	@Schema(name = "lastName")
	@Size(min=1, max=50,message="lastName length is invalid")
	private String lastName;
	

}
