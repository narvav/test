package com.att.idp.idgraphusermanagementms.resource.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.ToString;

/**
 * The LockList class implements the Serializable interface.
 * This class is part of the com.att.idp.idgraphusermanagementms.resource.response package.
 * It represents a lock list in the system.
 * The class contains various fields such as lockName,setnumber, failedAuthCount, lastFailedAuthDateTime, lockExpirationDateTime, and authAttemptsRemaining.
 * Each field has its corresponding getter and setter methods.
 * The class is annotated with @JsonIgnoreProperties and @JsonInclude to control the JSON serialization and deserialization.
 * The @ApiModel annotation is used to add metadata for the model object in the generated documentation.
 */
@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "LockList")
public class LockList {

    private String lockName;
    private String setNumber;
    private String failedAuthCount;
    private String lastFailedAuthDateTime;
    private String lockExpirationDateTime;
    private String authAttemptsRemaining;
}
