package com.att.idp.idgraphusermanagementms.db.repository.impl;

import org.springframework.stereotype.Repository;

import com.att.idp.idgraphusermanagementms.db.model.Tsecurityquestion;
import com.att.idp.idgraphusermanagementms.db.repository.IDMProfileOrchestrationCustomRepository;
import com.att.idp.idgraphusermanagementms.db.repository.SecurityQuestionRepositoryCustom;

/**
 * This is the implementation class for the SecurityQuestionRepositoryCustom interface.
 * It extends IDMProfileOrchestrationCustomRepository for common CRUD operations.
 * The entity associated with this repository is Tsecurityquestion and the ID type is Long.
 */
@Repository
public class SecurityQuestionRepositoryImpl extends IDMProfileOrchestrationCustomRepository<Tsecurityquestion, Long> implements SecurityQuestionRepositoryCustom {
	
	@Override
	protected Class<Tsecurityquestion> getClassT() {
		return Tsecurityquestion.class;
	}

	}