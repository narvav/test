package com.att.idp.idgraphusermanagementms.healthcheck;

import com.att.idp.idgraphusermanagementms.db.helper.HealthCheckDBHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@EnableScheduling
@Component
public class DatabaseHealthIndicator extends AbstractHealthIndicator {

    private boolean isDatabaseUp = false;

    @Value("${management.endpoint.health.indicator.override:false}")
    boolean healthcheckOverrideFlag;

    public static final Logger logger = LoggerFactory.getLogger(DatabaseHealthIndicator.class);

    @Autowired
    private HealthCheckDBHelper healthCheckDBHelper;


    @Scheduled(fixedRateString = "${management.endpoint.health.db.indicator.scheduler-duration:30000}")
    public void periodicCheck() {
        this.isDatabaseUp = healthCheckDBHelper.dbHealthCheck();
    }

    @Override
    protected void doHealthCheck(Health.Builder builder) throws Exception {
        if (healthcheckOverrideFlag) {
            logger.info("Skipping healthcheck as IDP healthcheck override flag is set to true");
            builder.up();
        } else {

            if (isDatabaseUp) {
                logger.debug("Database healthcheck successful, db is up: {}", isDatabaseUp);
                builder.up();
            } else {
                logger.error("Error occurred while checking idgraph ms database health status: {}", isDatabaseUp);
                builder.down();
            }
        }
    }

}