package com.att.idp.idgraphusermanagementms.db.model;

import java.util.Date;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "TACCOUNTLOCKOUT", schema = "MPS_OWNER")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Taccountlockout implements java.io.Serializable {

	private static final long serialVersionUID = 6606760243447025738L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "identificationType", column = @Column(name = "IDENTIFICATION_TYPE", nullable = false, length = 10)),
			@AttributeOverride(name = "accountId", column = @Column(name = "ACCOUNT_ID", nullable = false, length = 60)),
			@AttributeOverride(name = "lockoutId", column = @Column(name = "LOCKOUT_ID", nullable = false, precision = 22, scale = 0)) })
	private TaccountlockoutId id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "LOCKOUT_ID", referencedColumnName = "LOCKOUT_ID", insertable = false, updatable = false),
			@JoinColumn(name = "SET_NUMBER", referencedColumnName = "SET_NUMBER", insertable = false, updatable = false) })
	private Tlockoutconfig tlockoutconfig;

	@Column(name = "FAILED_AUTH_COUNT", precision = 22, scale = 0)
	private Long failedAuthCount;

	@Column(name = "LOCKOUT_EXPIRATION", length = 7)
	private Date lockoutExpiration;

	@Column(name = "LAST_FAILED_AUTH", length = 7)
	private Date lastFailedAuth;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;
}