package com.att.idp.idgraphusermanagementms.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.util.HtmlUtils;
import com.att.idp.idgraphusermanagementms.queue.message.helpers.UpdateUserFraudQueueHelper;
import com.att.idp.idgraphusermanagementms.db.helper.FraudLockDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.RolesDBHelper;
import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This class is a helper for lock/unlock user's account and update the role
 * status to requested for Lock. The class uses the FraudLockDBHelper and
 * RolesDBHelper to validate input data, process input data, store input data,
 * prepare data for asynchronous calls, and make asynchronous calls. The class
 * is annotated with @Service, @Component, and @Transactional, meaning it is a
 * Spring Bean and can be autowired into other classes, and it supports
 * transaction management. The class also handles exceptions and logs the
 * necessary information.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class AccountLockHelper {

	@Autowired
	private UpdateUserFraudQueueHelper updateUserFraudQueueHelper;

	@Autowired
	private FraudLockDBHelper fraudLockDBHelper;

	@Autowired
	private RolesDBHelper rolesDBHelper;


	private static String sClassName = "AccountLockHelper";
	private static final String INFO = "$Id: master/com/att/idp/idgraphusermanagementms/helper/AccountLockHelper.java v1 $;";
	public static final Logger logger = LoggerFactory.getLogger(AccountLockHelper.class);
	private static final String ERROR_ENUM = "ErrorEnum";
	private boolean isTransactionRollbackOnError = false;

	/**
	 * Processes account lock and unlock operations based on the input parameters.
	 * Processes role status update operation based on the input parameters \@param
	 * hmInput A map containing input parameters for the account lock/unlock
	 * operation. \@param hmFraudLockResponse A map containing the response from the
	 * fraud lock check. \@return A map containing the result of the account
	 * lock/unlock operation.
	 */
	public Map<String, Object> processAccountLock(Map<String, Object> hmInput, HashMap hmFraudLockResponse) {

		String sMethodName = ".processAccountLck.";
		Map<String, Object> hmResult = null;
		String stAppInfo = null;
		String stAppStatusCode = null;
		ArrayList alAddUpdateAcctLocks = new ArrayList();
		ArrayList alAddUpdateRoles = new ArrayList();
		ArrayList alDBFraudLocks = new ArrayList();
		String sSecondaryAccessReset = CommonDefs.IND_N;
		ArrayList alDbusEvents = new ArrayList();

		try {

			if (hmInput == null || hmInput.isEmpty()) {
				stAppInfo = "Input HashMap is null";
				logger.info("{}{}ALH_01 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			hmInput.put(CommonDefs.SECONDARY_ACCESS_RESET, sSecondaryAccessReset);
			String sSorId = (String) hmInput.get(CommonDefs.SOR_ID);
			String sSorInvariantId = (String) hmInput.get(CommonDefs.SOR_INVARIANT_ID);
			String sReasonCode = (String) hmInput.get(CommonDefs.ACCOUNT_LOCKED_REASON_CODE);
			String sAgentId = (String) hmInput.get(CommonDefs.AGENT_ID);
			String sAction = (String) hmInput.get(CommonDefs.ACTION);
			String sTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
			String sServiceType = (String) hmInput.get(CommonDefs.SERVICE_NAME);
			String sMemberNum = (String) hmInput.get(CommonDefs.MEMBER_NUM);
			String sCallDbus = (String) hmInput.get(CommonDefs.CALLDBUS);

			if ((sTransactionName == null || sTransactionName.isEmpty())
					|| (sCallingSystemId == null || sCallingSystemId.isEmpty())
					|| (sTransactionId == null || sTransactionId.isEmpty()) || (sSorId == null || sSorId.isEmpty())
					|| (sSorInvariantId == null || sSorInvariantId.isEmpty())) {

				stAppInfo = "Required Parameter(TransactionName/TransactionId/CallingSystemId/SorId/SorInvariantId) cannot be Null / Empty";
				logger.info("{}{}ALH_02 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, stAppInfo);
				return hmResult;
			}

			if (sAction == null
					|| !(CommonDefs.LOCK.equalsIgnoreCase(sAction) || CommonDefs.UNLOCK.equalsIgnoreCase(sAction))) {
				return hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
						"Action value is not valid - Action - " + sAction);
			}

			HashMap<String, Object> hmAcctFraudLock = new HashMap<String, Object>();
			if (hmFraudLockResponse != null && !hmFraudLockResponse.isEmpty()) {
				alDBFraudLocks = (ArrayList) hmFraudLockResponse.get(MPSDefs.FRAUD_LOCK);
				if (alDBFraudLocks != null && !alDBFraudLocks.isEmpty()) {
					hmAcctFraudLock = (HashMap<String, Object>) alDBFraudLocks.get(0);
				}
			}

			if (CommonDefs.UNLOCK.equalsIgnoreCase(sAction)) {
				if (hmAcctFraudLock != null && !hmAcctFraudLock.isEmpty()) {
					String dbAccountLock = (String) hmAcctFraudLock.get(MPSDefs.DB_ACCOUNT_LOCKED);
					if (dbAccountLock.equalsIgnoreCase(CommonDefs.IND_Y)) {
						HashMap<String, Object> hmTemp = new HashMap<String, Object>();
						hmTemp.putAll(hmAcctFraudLock);
						hmTemp.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
						hmTemp.put(MPSDefs.DB_ACCOUNT_LOCKED, CommonDefs.IND_N);
						hmTemp.put(MPSDefs.DB_ACCOUNT_LOCK_REASON, null);
						hmTemp.put(MPSDefs.DB_FRAUD_AGENT, sAgentId);
						hmTemp.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);
						hmTemp.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);
						alAddUpdateAcctLocks.add(hmTemp);
					} else {
						return hmResult = CommonErrorMap.makeCommonStatusMap(CErrorDefs.COMMON_SUCCESS_NUM,
								"Account is not fraud locked, hence returning success");
					}
				}
			}

			String stRoleName = (String) hmInput.get(MPSDefs.DB_ROLE_NAME);
			String stRoleStatusName = (String) hmInput.get(MPSDefs.DB_ROLE_STATUS_NAME);

			if (CommonDefs.LOCK.equalsIgnoreCase(sAction)) {
				if (CommonDefs.KEY_ROLE_NAME_OWNER.equalsIgnoreCase(stRoleName)) {
					if (hmAcctFraudLock != null && !hmAcctFraudLock.isEmpty()) {
						HashMap<String, Object> hmTemp = new HashMap();
						hmTemp.putAll(hmAcctFraudLock);
						hmTemp.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
						hmTemp.put(MPSDefs.DB_ACCOUNT_LOCKED, CommonDefs.IND_Y);
						hmTemp.put(MPSDefs.DB_ACCOUNT_LOCK_REASON, sReasonCode);
						hmTemp.put(MPSDefs.DB_FRAUD_AGENT, sAgentId);
						hmTemp.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);
						hmTemp.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);
						alAddUpdateAcctLocks.add(hmTemp);
					} else {
						HashMap<String, Object> hmTemp = new HashMap();
						hmTemp.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
						hmTemp.put(MPSDefs.DB_ACCOUNT_LOCKED, CommonDefs.IND_Y);
						hmTemp.put(MPSDefs.DB_ACCOUNT_LOCK_REASON, sReasonCode);
						hmTemp.put(MPSDefs.DB_FRAUD_AGENT, sAgentId);
						hmTemp.put(MPSDefs.DB_SOR_INVARIANT_ID, sSorInvariantId);
						hmTemp.put(MPSDefs.DB_SOR_ID, sSorId);
						hmTemp.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);
						hmTemp.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_INSERT);
						alAddUpdateAcctLocks.add(hmTemp);
					}
				}

				if (CommonDefs.KEY_ROLE_NAME_AUTHORIZEDUSER.equalsIgnoreCase(stRoleName)
						&& CommonDefs.ROLE_STATUS_ENABLED.equalsIgnoreCase(stRoleStatusName)) {
					HashMap<String, String> hmTemp = CommonUtil.getHashMap();
					hmTemp.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);
					hmTemp.put(MPSDefs.DB_ROLE_ID, (String) hmInput.get(MPSDefs.DB_ROLE_ID));
					hmTemp.put(MPSDefs.DB_ROLE_STATUS, CommonDefs.ROLE_STATUS_REQUESTED);
					hmTemp.put(MPSDefs.DB_SERVICE_ID, (String) hmInput.get(CommonDefs.SERVICE_ID));
					hmTemp.put(MPSDefs.DB_SOR_INVARIANT_ID, (String) hmInput.get(CommonDefs.SOR_INVARIANT_ID));
					hmTemp.put(MPSDefs.DB_SOR_ID, (String) hmInput.get(CommonDefs.SOR_ID));
					hmTemp.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);
					hmTemp.put(MPSDefs.DB_OPERATION, CommonDefs.KEY_UPDATE_ROLE_STATUS);
					alAddUpdateRoles.add(hmTemp);
					sSecondaryAccessReset = CommonDefs.IND_Y;
					hmInput.put(CommonDefs.SECONDARY_ACCESS_RESET, sSecondaryAccessReset);
				}
			}

			// processing accountFraudLock table insert/update
			if (alAddUpdateAcctLocks != null && !alAddUpdateAcctLocks.isEmpty()) {
				HashMap hmInputFraud = CommonUtil.getHashMap();
				hmInputFraud.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
				hmInputFraud.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);
				hmInputFraud.put(MPSDefs.DB_ACCOUNTFRAUDLOCK, alAddUpdateAcctLocks);
				logger.info("{}{}ALH_05 : {}:{}", sClassName, sMethodName,
						"Calling FraudLockDBHelper.processData () with input = ", hmInputFraud);
				hmResult = fraudLockDBHelper.processData(hmInputFraud);

				logger.info("{}{}ALH_06 : {}:{}", sClassName, sMethodName,
						"Response from FraudLockDBHelper.processData () ", hmResult);

				if (hmResult == null || hmResult.isEmpty()) {
					stAppInfo = "FraudLock data db processing response is null or Empty";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					logger.info("{}{}ALH_06.1 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}

				stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
				if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					stAppInfo = "FraudLock data db processing was failed." + hmResult.get(CErrorDefs.COMMON_APP_INFO);
					logger.info("{}{}ALH_06.2 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
			}

			// processing MEMBERSERVICEROLE table update
			if (alAddUpdateRoles != null && !alAddUpdateRoles.isEmpty()) {
				HashMap hmUpdateRoleStatus = CommonUtil.getHashMap();
				hmUpdateRoleStatus.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
				hmUpdateRoleStatus.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);
				hmUpdateRoleStatus.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);

				hmUpdateRoleStatus.put(CommonDefs.KEY_UPDATE_ROLE_STATUS, alAddUpdateRoles);

				logger.info("{}{}ALH_07 : {}:{}", sClassName, sMethodName,
						"Calling rolesDBHelper.updateRoleStatus() with input = ", hmUpdateRoleStatus);

				hmResult = rolesDBHelper.updateRoleStatus(hmUpdateRoleStatus);

				logger.info("{}{}ALH_08 : {}:{}", sClassName, sMethodName,
						"Response from rolesDBHelper.updateRoleStatus() ", hmResult);

				if (hmResult == null || hmResult.isEmpty()) {
					stAppInfo = "fraud lock memberServiceRoles db update response is null or Empty";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					logger.info("{}{}ALH_08.1 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}

				stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
				if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					stAppInfo = "fraud lock memberServiceRoles db update was failed."
							+ hmResult.get(CErrorDefs.COMMON_APP_INFO);
					logger.info("{}{}ALH_08.2 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
			}

			if ("LOCK".equalsIgnoreCase(sAction)&& CommonDefs.KEY_ROLE_NAME_OWNER.equalsIgnoreCase(stRoleName)) {
				logger.info(sClassName + sMethodName + "ALH_9 : Calling makeAsyncCall : ");

				if (sCallDbus == null || sCallDbus.trim().isEmpty() || sCallDbus.equalsIgnoreCase(CommonDefs.IND_Y)) {
					hmResult = makeAsyncCall((HashMap) hmInput);
					logger.info(sClassName + sMethodName + "ALH_11 : Response from makeAsyncCall : " + hmResult);
					if (hmResult != null)
						return hmResult;
				}
				if (sCallDbus != null && sCallDbus.equals(CommonDefs.IND_N)) {
					alDbusEvents = getDbusInputForFraudLock(hmInput);
				}

			}

			// Default success if no error occur
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
			hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
			if (alDbusEvents != null) {
				hmResult.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, alDbusEvents);
			}

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			// hmResult.put(ERROR_ENUM, ErrorMessages.MS_OUA_UA_BE_SYS_EXP);
			isTransactionRollbackOnError = true;
			stAppInfo = "Exception thrown in processAccountLck method : " + hmResult;
			logger.error("{}{}ALH_11 : {}", sClassName, sMethodName, stAppInfo);

		} finally {
			stAppInfo = "Response from processAccountLck = " + hmResult;
			logger.info("{}{}ALH_12 : {}", sClassName, sMethodName, stAppInfo);

			String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
			if (isTransactionRollbackOnError && sAppCategoryCode != null
					&& !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
				hmResult.put("isTransactionRollback", "Y");
			}
			logger.info("{}{}HLP999 : response from AccountLockHelper {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;
	}

	/**
	 * Makes an asynchronous call to call DBUS.
	 *
	 * \@param hmInput A map containing input parameters for the asynchronous call.
	 * \@return A map containing the result of the asynchronous call.
	 */
	public Map<String, Object> makeAsyncCall(HashMap hmInput) {
		String sMethodName = ".makeAsyncCall.";
		Map<String, Object> hmResult = CommonUtil.getHashMap();
		String stAppStatusCode = null;
		String stAppInfo = null;
		ArrayList alDbusInp = getDbusInputForFraudLock(hmInput);
		Map<String, Object> hmDbusResult = updateUserFraudQueueHelper.sendMessageToMQ(hmInput, alDbusInp);
		logger.info(SpiMarker.getInstance(), "UAH_MAC_100 : Response from AccountLockHelper.makeAsyncCall : {}",
				StructuredArguments.entries(hmResult));
		if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmDbusResult)) {
			hmResult = CommonUtilHelper
					.sysErrorHashMap("null response from updateUserFraudQueueHelper.sendMessageToMQ");
			isTransactionRollbackOnError = true;
			return hmResult;
		} else {
			stAppStatusCode = (String) hmDbusResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (StringUtils.isBlank(stAppStatusCode)) {
				isTransactionRollbackOnError = true;
				hmResult = CommonUtilHelper
						.sysErrorHashMap("null response from updateUserFraudQueueHelper.sendMessageToMQ");
				return hmResult;
			} else if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				isTransactionRollbackOnError = true;
				stAppInfo = (String) hmDbusResult.get(CommonDefs.COMMON_APP_INFO);
				logger.info("{}{}ALH_MAC_01 : {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
				hmResult = hmDbusResult;
				return hmResult;
			}
		}

		return null;
	}

	/**
	 * Prepares the input for the DBus call for fraud lock.
	 *
	 * \@param hmInput A map containing input parameters for the DBus call. \@return
	 * An ArrayList containing the prepared input for the DBus call.
	 */
	public ArrayList<HashMap<String, Object>> getDbusInputForFraudLock(Map<String, Object> hmInput) {

		String sMethodName = ".getDbusInputForFraudLock.";
		ArrayList<HashMap<String, Object>> alDbusInput = CommonUtil.getArrayList();
		HashMap<String, Object> hmDbusInput = CommonUtil.getHashMap();
		// prepareNotificationEventForFraudLock
		hmDbusInput = prepareNotificationEventForFraudLock(hmInput);
		logger.info("{}{}ALH_GDI_01 : Response from prepareNotificationEventForFraudLock:: {}", sClassName, sMethodName,
				hmDbusInput);
		alDbusInput.add(hmDbusInput);
		HashMap<String, Object> hmAtlasDbusInput = prepareAtlasNotificationEventForFraudLock(hmInput);
		logger.info("{}{}ALH_GDI_02 : Response from prepareAtlasNotificationEventForFraudLock:: {}", sClassName,
				sMethodName, hmDbusInput);
		alDbusInput.add(hmAtlasDbusInput);

		return alDbusInput;
	}

	/**
	 * Prepares the notification event for fraud lock.
	 *
	 * \@param hmInput A map containing input parameters for the notification event.
	 * \@return A HashMap containing the prepared notification event.
	 */
	private HashMap<String, Object> prepareNotificationEventForFraudLock(Map<String, Object> hmInput) {
		final String sMethodName = "prepareNotificationEventForFraudLock";
		String sSecondaryAccessReset = (String) hmInput.get(CommonDefs.SECONDARY_ACCESS_RESET);
		String sMemberNum = (String) hmInput.get(CommonDefs.DB_MEMBER_NUM);
		String sSorInvariantId = (String) hmInput.get(CommonDefs.SOR_INVARIANT_ID);
		String sAction = (String) hmInput.get(CommonDefs.ACTION);
		String sAccountLockedReasonCode = (String) hmInput.get(CommonDefs.ACCOUNT_LOCKED_REASON_CODE);
		String sAgentId = (String) hmInput.get(CommonDefs.AGENT_ID);
		HashMap<String, Object> hmDbusInput = CommonUtil.getHashMap();
		hmDbusInput.put(CommonDefs.TRANSACTION_NAME, "UpdateMember");
		hmDbusInput.put("dbusTransactionId", (String) hmInput.get(CommonDefs.TRANSACTION_ID));
		hmDbusInput.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(CommonDefs.TRANSACTION_ID));
		hmDbusInput.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		hmDbusInput.put(CommonDefs.EVENTNAME, CommonDefs.PROP_EDD_NOTIFICATION_EVENT);
		hmDbusInput.put(CommonDefs.SUBEVENT, CommonDefs.DBUS_NOTIFICATION_SUBEVENT_SLID);
		hmDbusInput.put(CommonDefs.SERVICE_TYPE, (String) hmInput.get(CommonDefs.SERVICE_NAME));
		hmDbusInput.put(CommonDefs.SOR_ID, (String) hmInput.get(CommonDefs.SOR_ID));
		hmDbusInput.put(CommonDefs.ACCOUNT_SOR, (String) hmInput.get(CommonDefs.ACCOUNT_SOR));
		if (sSorInvariantId != null && !sSorInvariantId.isEmpty()) {
			hmDbusInput.put(CommonDefs.SOR_INVARIANT_ID, sSorInvariantId);
		}
		if (sMemberNum != null) {
			hmDbusInput.put("mainHashKey", sMemberNum);
		} else {
			hmDbusInput.put("mainHashKey", sSorInvariantId);
		}
		if ("LOCK".equalsIgnoreCase(sAction)) {
			hmDbusInput.put(CommonDefs.ACCOUNT_FRAUD_LOCKED, "Y");
			hmDbusInput.put(CommonDefs.ACCOUNT_LOCK_REASON, sAccountLockedReasonCode);
		} else if ("UNLOCK".equalsIgnoreCase(sAction)) {
			hmDbusInput.put(CommonDefs.ACCOUNT_FRAUD_LOCKED, "N");
		}

		logger.info("{}{}ALH_PNE_01 : prepareNotificationEventForFraudLock DbusInput: {}", sClassName, sMethodName,
				hmDbusInput);
		return hmDbusInput;
	}

	/**
	 * Prepares the atlas notification event for fraud lock.
	 *
	 * \@param hmInput A map containing input parameters for the notification event.
	 * \@return A HashMap containing the prepared atlas notification event.
	 */
	private HashMap<String, Object> prepareAtlasNotificationEventForFraudLock(Map<String, Object> hmInput) {
		HashMap<String, Object> hmAtlasNotification = CommonUtil.getHashMap();
		String sAgentId = (String) hmInput.get(CommonDefs.AGENT_ID);
		String sSorInvariantId = (String) hmInput.get(CommonDefs.SOR_INVARIANT_ID);
		String sAction = (String) hmInput.get(CommonDefs.ACTION);
		String sAccountLockedReasonCode = (String) hmInput.get(CommonDefs.ACCOUNT_LOCKED_REASON_CODE);
		hmAtlasNotification.put(CommonDefs.TRANSACTION_NAME, "UpdateMember");
		hmAtlasNotification.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(CommonDefs.TRANSACTION_ID));
		hmAtlasNotification.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		if (sAgentId != null && !sAgentId.isEmpty()) {
			hmAtlasNotification.put(CommonDefs.AGENT_ID, sAgentId);
		}
		hmAtlasNotification.put(CommonDefs.EVENTNAME, CommonDefs.EVENTNAME_ATLAS_IDENTITY_MANAGEMENT_PUBLISHER);
		hmAtlasNotification.put(CommonDefs.SUBEVENT, "FraudAction");
		hmAtlasNotification.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
		hmAtlasNotification.put(CommonDefs.SERVICE_NAME, (String) hmInput.get(CommonDefs.SERVICE_NAME));
		hmAtlasNotification.put(CommonDefs.SOR_ID, (String) hmInput.get(CommonDefs.SOR_ID));
		hmAtlasNotification.put(CommonDefs.SOR_INVARIANT_ID, sSorInvariantId);
		if ("LOCK".equalsIgnoreCase(sAction)) {
			hmAtlasNotification.put(CommonDefs.ACTION, "LOCK");
			hmAtlasNotification.put("lockedReasonCode", sAccountLockedReasonCode);
		} else if ("UNLOCK".equalsIgnoreCase(sAction)) {
			hmAtlasNotification.put(CommonDefs.ACTION, "UNLOCK");
		}
		return hmAtlasNotification;
	}

}
