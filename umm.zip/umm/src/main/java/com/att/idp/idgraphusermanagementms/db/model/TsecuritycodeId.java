package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class TsecuritycodeId implements Serializable {

	private static final long serialVersionUID = 4105678014271631068L;

	@Column(name = "IDENTIFICATION_TYPE", nullable = false, length = 10)
	private String identificationType;

	@Column(name = "ACCOUNT_ID", nullable = false, length = 60)
	private String accountId;

	@Column(name = "SECURITY_CODE", nullable = false)
	private String securityCode;
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TsecuritycodeId))
			return false;
		TsecuritycodeId castOther = (TsecuritycodeId) other;

		return ((this.getIdentificationType() == castOther.getIdentificationType())
				|| (this.getIdentificationType() != null && castOther.getIdentificationType() != null
				&& this.getIdentificationType().equals(castOther.getIdentificationType())))
				&& ((this.getAccountId() == castOther.getAccountId()) || (this.getAccountId() != null
				&& castOther.getAccountId() != null && this.getAccountId().equals(castOther.getAccountId())))
				&& ((this.getSecurityCode() == castOther.getSecurityCode())
				|| (this.getSecurityCode() != null && castOther.getSecurityCode() != null
				&& this.getSecurityCode().equals(castOther.getSecurityCode())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getIdentificationType() == null ? 0 : this.getIdentificationType().hashCode());
		result = 37 * result + (getAccountId() == null ? 0 : this.getAccountId().hashCode());
		result = 37 * result + (getSecurityCode() == null ? 0 : this.getSecurityCode().hashCode());
		return result;
	}
}