package com.att.idp.idgraphusermanagementms.db.helper;

import java.util.*;

import com.att.common.validators.ServiceValidation;
import com.att.common.validators.SystemOfRecordValidation;
import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.StatusMsg;

import net.logstash.logback.argument.StructuredArguments;

import java.util.Set;

/**
 * @author vn3904
 */
@Component
public class UpdateServiceDBHelper {

    private static String sClassName = "UpdateServiceDBHelper";
    public static final Logger logger = LoggerFactory.getLogger(UpdateServiceDBHelper.class);
    private static final String INFO = "$Id: master/com/att/idp/idgraphuserassociationms/helper/dhelpers/UpdateServiceDBHelper.java v1;";

    private static final Set<String> NON_COLUMN_KEYS = Set.of(
            CommonDefs.CALLING_SYSTEM_ID,
            CommonDefs.TRANSACTION_ID,
            CommonDefs.TRANSACTION_NAME,
            MPSDefs.DB_OPERATION
    );


    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private DBHelper oDBHelper;
    @Autowired
    private SystemOfRecordValidation oSystemOfRecordValidation;
    @Autowired
    private ServiceValidation oServiceValidation;

    @Autowired
    private ErrorMetricHandler errorMetricHandler;

    private static final String addMemberServiceSql = "INSERT INTO memberservice(" +
            "MEMBER_NUM," +
            "SERVICE_ID," +
            "GROUP_NUM," +
            "GROUP_STATUS," +
            "MEMBER_STATUS," +
            "TERMINATE_DATE," +
            "LAST_MODIFIED_BY," +
            "SITE_ID," +
            "INSTANCE_ID," +
            "SOR_ID," +
            "SOR_INVARIANT_ID," +
            "OWNED_BY," +
            "NICKNAME," +
            "DEFAULT_ACCOUNT," +
            "CPNI_IMPACTED," +
            "DATE_DEFAULT_EST," +
            "PARENT_SOR_ID," +
            "PARENT_SOR_INVARIANT_ID," +
            "UVERSE_SERVICE_IND" +
            ") VALUES(" +
            "?," +
            "?," +
            "?," +
            "?," +
            "?," +
            "to_date(?,'MMddyyyy')," +
            "?," +
            "?," +
            "?," +
            "?," +
            "?," +
            "?," +
            "?," +
            "?," +
            "?," +
            " (SELECT sysdate FROM dual WHERE 1 = ?)," +
            "?,?,?)";

    /**
     * @param hmInput
     * @return HashMap
     */

    @SuppressWarnings({"rawtypes", "unchecked"})
    public HashMap addService(HashMap hmInput) {
        String sMethodName = ".addService.";
        logger.info("{}{}DBTOOLS000 :addService InpParam : {}", sClassName, sMethodName, hmInput != null ? StringUtils.normalizeSpace(hmInput.toString()) : null);

        HashMap<String, Object> status = null;
        List<Object> objectList = new ArrayList<>();

        int serviceId = 0;
        if (hmInput == null || hmInput.isEmpty()) {
            status = CommonErrorMap.makeCategoryMap(
                    CErrorDefs.ERR_EMPTY_NUM, "input to addService() is null");
            logger.info("{}{}DBHLP001 : response :  {}", sClassName, sMethodName, status);
            return status;
        }
        String memberNumStr = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
        String groupNumStr = (String) hmInput.get(MPSDefs.DB_GROUP_NUM);
        String serviceName = (String) hmInput.get(MPSDefs.DB_SERVICE_NAME);
        String groupStatusStr = (String) hmInput.get(MPSDefs.DB_GROUP_STATUS);
        String memberStatusStr = (String) hmInput.get(MPSDefs.DB_MEMBER_STATUS);
        String terminateDate = (String) hmInput.get(MPSDefs.DB_TERMINATE_DATE);
        String lastModifiedBy = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);
        String groupStatusName = (String) hmInput.get(MPSDefs.DB_GROUP_STATUS_NAME);
        String memberStatusName = (String) hmInput.get(MPSDefs.DB_MEMBER_STATUS_NAME);
        String siteId = (String) hmInput.get(MPSDefs.DB_SITE_ID);
        String instanceId = (String) hmInput.get(MPSDefs.DB_INSTANCE_ID);
        String sorInvariantId = (String) hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
        String sorName = (String) hmInput.get(MPSDefs.DB_SOR_NAME);
        String sorIdStr = null;

        String ownedByStr = (String) hmInput.get(MPSDefs.DB_OWNED_BY);
        String nickname = (String) hmInput.get(MPSDefs.DB_NICKNAME);
        String defaultAccount = (String) hmInput.get(MPSDefs.DB_DEFAULT_ACCOUNT);
        String cpniImpacted = (String) hmInput.get(MPSDefs.DB_CPNI_IMPACTED);
        String dateDefaultEst = (String) hmInput.get(MPSDefs.DB_DATE_DEFAULT_EST);
        String parentSorIdStr = (String) hmInput.get(MPSDefs.DB_PARENT_SOR_ID);
        String parentSorName = (String) hmInput.get(MPSDefs.DB_PARENT_SOR_NAME);
        String parentSorInvariantId = (String) hmInput.get(MPSDefs.DB_PARENT_SOR_INVARIANT_ID);
        String uverseServiceInd = (String) hmInput.get(MPSDefs.DB_UVERSE_SERVICE_IND);

        long ownedBy = -1;
        long memberNum = -1;
        long groupNum = -1;
        int memberStatus = -1;
        int groupStatus = -1;
        int sorId = -1;
        int parentSorId = -1;

        try {

                    Map<String, Object> parsedValues = CommonUtilHelper.parseAndFetchDBValues(
                    jdbcTemplate, oDBHelper, sMethodName, sClassName, hmInput);

            if (parsedValues.containsKey("status")) {
                status = (HashMap) parsedValues.get("status");
                return status;
            }
            ownedBy = (long) parsedValues.get("ownedBy");
            memberNum = (long) parsedValues.get("memberNum");
            groupNum = (long) parsedValues.get("groupNum");
            memberStatus = (int) parsedValues.get("memberStatus");
            groupStatus = (int) parsedValues.get("groupStatus");
            sorId = (int) parsedValues.get("sorId");
            parentSorId = (int) parsedValues.get("parentSorId");
            serviceId = (int) parsedValues.get("serviceId");
            sorIdStr = (String) parsedValues.get("sorIdStr");
            parentSorIdStr = (String) parsedValues.get("parentSorIdStr");

            if (serviceId == 0 || memberStatus == -1 || groupStatus == -1) {
                status = StatusMsg.makeSQLStatus(MPSDefs.ERR_EMPTY, MPSDefs.ERR_EMPTY_MSG, MPSDefs.SQL_ERR, MPSDefs.SQL_ERR_MSG, MPSDefs.NO_ROW_UPDATED);
                logger.info("{}{}DBHLP84 : CANNOT find service_id, member_status or group_status", sMethodName, sClassName);
                return status;

            } else {

                logger.debug("{}{}DBHLP85 : SQL = {}", sMethodName, sClassName, addMemberServiceSql);
                // Prepare a HashMap for the parameters
                HashMap<String, Object> insertParams = new HashMap<>();
                insertParams.put("memberNum", memberNum);
                insertParams.put("serviceId", serviceId);
                insertParams.put("groupNum", groupNum);
                insertParams.put("groupStatus", groupStatus);
                insertParams.put("memberStatus", memberStatus);
                insertParams.put("terminateDate", terminateDate);
                insertParams.put("lastModifiedBy", lastModifiedBy);
                insertParams.put("siteId", siteId);
                insertParams.put("instanceId", instanceId);
                insertParams.put("sorIdStr", sorIdStr);
                insertParams.put("sorId", sorId);
                insertParams.put("sorInvariantId", sorInvariantId);
                insertParams.put("ownedByStr", ownedByStr);
                insertParams.put("ownedBy", ownedBy);
                insertParams.put("nickname", nickname);
                insertParams.put("defaultAccount", defaultAccount);
                insertParams.put("cpniImpacted", cpniImpacted);
                insertParams.put("dateDefaultEst", dateDefaultEst);
                insertParams.put("parentSorIdStr", parentSorIdStr);
                insertParams.put("parentSorId", parentSorId);
                insertParams.put("parentSorInvariantId", parentSorInvariantId);
                insertParams.put("uverseServiceInd", uverseServiceInd);

                objectList.addAll(CommonUtilHelper.prepareInsertParams(insertParams,sClassName));

                int rowCount = jdbcTemplate.update(new String(addMemberServiceSql), objectList.toArray(new Object[objectList.size()]));

                status = StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS, MPSDefs.MPS_ALL_OK, MPSDefs.SQL_SUCCESS, MPSDefs.SQL_SUCCESS_MSG, Integer.toString(rowCount));
                status.put(MPSDefs.DB_SERVICE_ID, Integer.toString(serviceId));

                logger.debug("{}{}DBHLP98 : insertStatus={}", sMethodName, sClassName, status);
            }
        } catch (NumberFormatException e) {
            status = StatusMsg.makeSQLStatus(MPSDefs.ERR_OUT_OF_RANGE, MPSDefs.ERR_OUT_OF_RANGE_MSG, MPSDefs.SQL_ERR, MPSDefs.SQL_ERR_MSG, MPSDefs.NO_ROW_UPDATED);
            logger.info("{}{}DBHLP99 : Error: {}", sMethodName, sClassName, e.getMessage());
        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();

            status = StatusMsg.makeExceptionSQLStatus(e);
            logger.error("{}{}DBHLP103 : Error: {}", sMethodName, sClassName, e.getMessage());

        } finally {
            logger.info("{}{}DBTOOLS999 : Output from addService = {}", sMethodName, sClassName, status);
        }
        return status;
    }


    /**
     * @param hmInput
     * @return
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public HashMap<String, Object> removeService(HashMap<String, Object> hmInput) {

        String sMethodName = ".removeService.";
        HashMap status = null;
        List<Object> objectList = new ArrayList<>();
        if (hmInput == null || hmInput.isEmpty()) {
            status = CommonErrorMap.makeCategoryMap(
                    CErrorDefs.ERR_INVALID_DATA_NUM, "input to removeService() is null");
            logger.info("{}{}DBHLP001 : removeService response :  {} ", sClassName, sMethodName, status);
            return status;
        }
        logger.info("{}{}QIPRL.DBH_01. : CVS KEYWORDS: {}", sClassName, sMethodName, INFO);
        logger.info("{}{}DBTOOLS000 : removeService InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmInput));
        String deleteSql =
                "DELETE  FROM MEMBERSERVICE WHERE service_id = ? AND member_num = ?";
        String deleteInstanceSql =
                "DELETE FROM MEMBERSERVICE WHERE service_id = ? AND member_num = ? AND instance_id = ?";
        String deleteSorInvIdSql =
                "DELETE FROM MEMBERSERVICE WHERE service_id = ? AND member_num = ? AND sor_invariant_id = ?";
        String deleteInstanceSorInvIdSql =
                "DELETE FROM MEMBERSERVICE WHERE service_id = ? AND member_num = ? AND instance_id = ? AND sor_invariant_id = ?";
        String deleteInstanceSorInvIdSorIdSql =
                "DELETE FROM MEMBERSERVICE WHERE service_id = ? AND member_num = ? AND instance_id = ? AND sor_invariant_id = ? AND sor_id = ?";


        String memberNumStr = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
        String stserviceName = (String) hmInput.get(MPSDefs.DB_SERVICE_NAME);
        String stSorInvariantId = (String) hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID);

        String instanceId = null;
        String sSorName = null;
        long memberNum = -1;
        int serviceId = 0;

        if (hmInput.containsKey(MPSDefs.DB_SOR_NAME)) {
            sSorName = (String) hmInput.get(MPSDefs.DB_SOR_NAME);
        }

        if (hmInput.containsKey(MPSDefs.DB_INSTANCE_ID)) {
            instanceId = (String) hmInput.get(MPSDefs.DB_INSTANCE_ID);
        }

        try {

            if (jdbcTemplate == null) {
                status = CommonErrorMap.makeCategoryMap(
                        CErrorDefs.ERR_SYS_APPL_NUM, "jdbcTemplate is null.");
                logger.info("{}{}DBHLP003 : response :  {} ", sClassName, sMethodName, status);
                return status;
            }

            if (memberNumStr != null)
                memberNum = Long.parseLong(memberNumStr);

            serviceId = oDBHelper.getServiceId(stserviceName);
            logger.debug("{}{}DBHLP004 : sor_id::= {} ", sClassName, sMethodName, serviceId);

            int iSorId = 0;
            if (sSorName != null && !sSorName.isEmpty()) {
                iSorId = oDBHelper.getSorId(sSorName);
            }

            if (serviceId == 0 || memberNum == -1) {
                //something is missing
                String stAppInfo = "CANNOT find service_id or  member_Num ";
                status = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                logger.debug("{}{}DBHLP005 : = {} ", sClassName, sMethodName, stAppInfo);
                return status;

            } else {


                if ((instanceId != null && !(instanceId.trim()).isEmpty()) && (stSorInvariantId != null && !(stSorInvariantId.trim()).isEmpty())
                        && (sSorName != null && !sSorName.isEmpty())) {
                    deleteSql = deleteInstanceSorInvIdSorIdSql;

                } else {
                    if ((instanceId != null && !(instanceId.trim()).isEmpty()) && (stSorInvariantId != null && !(stSorInvariantId.trim()).isEmpty())) {
                        deleteSql = deleteInstanceSorInvIdSql;
                    } else if (instanceId != null && !(instanceId.trim()).isEmpty()) {
                        deleteSql = deleteInstanceSql;
                    } else if (stSorInvariantId != null && !(stSorInvariantId.trim()).isEmpty()) {
                        deleteSql = deleteSorInvIdSql;
                    }
                }

                objectList.add(serviceId);
                objectList.add(memberNum);

                if ((instanceId != null && !instanceId.isEmpty()) && (stSorInvariantId != null && !stSorInvariantId.isEmpty())
                        && (sSorName != null && !sSorName.isEmpty())) {
                    objectList.add(instanceId);
                    objectList.add(stSorInvariantId);
                    objectList.add(iSorId);


                } else if ((instanceId != null && !instanceId.isEmpty()) && (stSorInvariantId != null && !stSorInvariantId.isEmpty())) {
                    objectList.add(instanceId);
                    objectList.add(stSorInvariantId);

                } else if (instanceId != null && !instanceId.isEmpty()) {
                    objectList.add(instanceId);

                } else if (stSorInvariantId != null && !stSorInvariantId.isEmpty()) {
                    objectList.add(stSorInvariantId);

                }
                logger.debug("{}{}DBHLP006 : SQL =  {} ", sClassName, sMethodName, deleteSql);


                int rowCount = jdbcTemplate.update(new String(deleteSql), objectList.toArray(new Object[objectList.size()]));

                status = StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS, MPSDefs.MPS_ALL_OK, MPSDefs.SQL_SUCCESS, MPSDefs.SQL_SUCCESS_MSG, Integer.toString(rowCount));
                status.put(MPSDefs.DB_SERVICE_ID, Integer.toString(serviceId));

                logger.debug("{}{}DBHLP007 : removeStatus::= {} ", sClassName, sMethodName, status);
            }

        } catch (NumberFormatException e) {
            status = StatusMsg.makeSQLStatus(MPSDefs.ERR_OUT_OF_RANGE, MPSDefs.ERR_OUT_OF_RANGE_MSG, MPSDefs.SQL_ERR, MPSDefs.SQL_ERR_MSG, MPSDefs.NO_ROW_UPDATED);
            logger.info("{}{}DBHLP008 : Error :  {} ", sClassName, sMethodName, e.getMessage());
        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();

            status = StatusMsg.makeExceptionSQLStatus(e);
            logger.debug("{}{}DBHLP009 : Error :  {} ", sClassName, sMethodName, status);

        } finally {
            logger.info("{}{}DBTOOLS999 : Output from removeService = :  {} ", sClassName, sMethodName, status);

        }

        return status;
    }

    /**
     * @param hmInput
     * @return
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public HashMap updateService(HashMap hmInput) {
        String sMethodName = ".updateService.";
        HashMap hmResult = null;
        String stAppInfo = null;
        List<Object> objectList = new ArrayList<>();

        logger.info("{}{}DBHLP002. : CVS KEYWORDS: {}", sClassName, sMethodName, INFO);
        logger.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmInput));

        if (hmInput == null || hmInput.isEmpty()) {
            stAppInfo = "input to updateService() is null";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, stAppInfo);
            logger.info("{}{}MPSDBSU_02 : {}", sClassName, sMethodName, stAppInfo);
            return hmResult;
        }

        try {
            String sSorName = (String) hmInput.get(MPSDefs.DB_SOR_ID);
            if (sSorName != null && !sSorName.isBlank()) {
                int iSorId = oDBHelper.getSorId(sSorName);
                hmInput.put(MPSDefs.DB_SOR_ID, String.valueOf(iSorId));
            }

            String sServiceStatus = (String) hmInput.get(MPSDefs.DB_MEMBER_STATUS);
            if (sServiceStatus != null && !sServiceStatus.isBlank()) {
                int iMemberStatus = oDBHelper.getStatusCode(sServiceStatus);
                hmInput.put(MPSDefs.DB_MEMBER_STATUS, String.valueOf(iMemberStatus));
            }

            String sServiceName = (String) hmInput.get(MPSDefs.DB_SERVICE_ID);
            if (sServiceName != null && !sServiceName.isBlank()) {
                int iServiceId = oDBHelper.getServiceId(sServiceName);
                hmInput.put(MPSDefs.DB_SERVICE_ID, String.valueOf(iServiceId));
            }

            StringBuilder oUpdateMemberServiceQuery = new StringBuilder(" UPDATE  MEMBERSERVICE  SET ");

            Iterator oItr = null;
            String sUpdateKey = null;

            oItr = hmInput.keySet().iterator();
            int j = 0;

            while (oItr.hasNext()) {
                sUpdateKey = (String) oItr.next();
                if (sUpdateKey != null && (!sUpdateKey.trim().isEmpty())
                        && !NON_COLUMN_KEYS.contains(sUpdateKey)) {
                    if (j > 0 && j < hmInput.size())
                        oUpdateMemberServiceQuery.append(",");

                    if (sUpdateKey.equalsIgnoreCase(MPSDefs.DB_PENDING_DISCONNECT_DATE))
                        oUpdateMemberServiceQuery.append(sUpdateKey).append("= to_date(?, 'mmddyyyy')");
                    else
                        oUpdateMemberServiceQuery.append(sUpdateKey).append(" = ?");

                    logger.info("{}{}MPSDBSU_03 : sUpdateKey :: {} ", sClassName, sMethodName, sUpdateKey);
                    j++;
                }
            }

            if (hmInput.containsKey(MPSDefs.DB_SOR_INVARIANT_ID)) {
                oUpdateMemberServiceQuery.append(" Where member_num = ? and  service_id=? and  sor_invariant_id=? ");
            } else {
                oUpdateMemberServiceQuery.append(" Where member_num = ? and  service_id=? and  instance_id=? ");
            }

            logger.debug("{}{}MPSDBSU_05 : updateMemberServiceSQL :: {} ", sClassName, sMethodName,
                    oUpdateMemberServiceQuery);

            oItr = hmInput.keySet().iterator();

            while (oItr.hasNext()) {
                sUpdateKey = (String) oItr.next();

                if (hmInput.containsKey(sUpdateKey) && !NON_COLUMN_KEYS.contains(sUpdateKey)) {
                    objectList.add(hmInput.get(sUpdateKey));
                }
            }

            objectList.add(hmInput.get(MPSDefs.DB_MEMBER_NUM));
            objectList.add(hmInput.get(MPSDefs.DB_SERVICE_ID));

            if (hmInput.containsKey(MPSDefs.DB_SOR_INVARIANT_ID)) {
                objectList.add(hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID));
            } else {
                objectList.add(hmInput.get(MPSDefs.DB_INSTANCE_ID));
            }

            int rowCount = jdbcTemplate.update(new String(oUpdateMemberServiceQuery),
                    objectList.toArray(new Object[objectList.size()]));

            if (rowCount == 0) {
                stAppInfo = "No Record found updateService";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_NO_SERVICE_NUM, stAppInfo);
                logger.info("{}{}MPSDBSU_06 : {}", sClassName, sMethodName, stAppInfo);
            } else {
                stAppInfo = "MEMBERSERVICE attributes updated successfully";
                hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, stAppInfo);
                logger.info("{}{}MPSDBSU_07 : {}", sClassName, sMethodName, stAppInfo);
            }
        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            hmResult = StatusMsg.makeExceptionSQLStatus(e);
            logger.debug("{}{}MPSDBSU_e : Error :  {} ", sClassName, sMethodName, hmResult);
        } finally {
            logger.info("{}{}DBTOOLS999 : Output from updateService = :  {} ", sClassName, sMethodName, hmResult);
        }
        return hmResult;
    }

    /**
     * @param hmInput
     * @return
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public HashMap<String, Object> updateMemberService(HashMap<String, Object> hmInput) {
        String sMethodName = ".updateMemberService.";
        HashMap hmResult = null;
        String stAppInfo = null;
        List<Object> objectList = new ArrayList<>();

        logger.info("{}{}DBHLP002 : CVS KEYWORDS: {}", sClassName, sMethodName, INFO);
        logger.info("{}{}DBTOOLS000 :updateMemberService InpParam : {}", sClassName, sMethodName, hmInput != null ? StringUtils.normalizeSpace(hmInput.toString()) : null);

        if (hmInput == null || hmInput.isEmpty()) {
            stAppInfo = "input to updateMemberService() is null";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, stAppInfo);
            logger.info("{}{}MPSDBSU_08 : Output from updateMemberService = :  {} ", sClassName, sMethodName, stAppInfo);
            return hmResult;
        }

        try {
            String sSorName = (String) hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
            if (sSorName != null && !sSorName.isBlank()) {
                hmInput.put(MPSDefs.DB_SOR_INVARIANT_ID, sSorName);
            }

            String sServiceStatus = (String) hmInput.get(MPSDefs.DB_MEMBER_STATUS);
            if (sServiceStatus != null && !sServiceStatus.isBlank()) {
                hmInput.put(MPSDefs.DB_MEMBER_STATUS, sServiceStatus);
            }

            String sServiceId = (String) hmInput.get(MPSDefs.DB_SERVICE_ID);
            if (sServiceId != null && !sServiceId.isBlank()) {
                int iServiceId = Integer.parseInt(sServiceId);
                hmInput.put(MPSDefs.DB_SERVICE_ID, String.valueOf(iServiceId));
            }

            StringBuilder oUpdateMemberServiceQuery = new StringBuilder(" UPDATE MEMBERSERVICE  SET ");

            Iterator oItr = null;
            String sUpdateKey = null;

            oItr = hmInput.keySet().iterator();
            int j = 0;

            while (oItr.hasNext()) {
                sUpdateKey = (String) oItr.next();
                if (sUpdateKey != null && (!sUpdateKey.trim().isEmpty())) {
                    if (j > 0 && j < hmInput.size())
                        oUpdateMemberServiceQuery.append(",");

                    if (sUpdateKey.equalsIgnoreCase(MPSDefs.DB_NICKNAME))
                        oUpdateMemberServiceQuery.append(sUpdateKey).append(" = ?");

                    else if (sUpdateKey.equalsIgnoreCase(MPSDefs.DB_DEFAULT_ACCOUNT))
                        oUpdateMemberServiceQuery.append(sUpdateKey).append(" = ?");

                    else
                        oUpdateMemberServiceQuery.append(sUpdateKey).append(" = ?");

                    j++;
                }
            }

            if (hmInput.containsKey(MPSDefs.DB_SOR_INVARIANT_ID)) {
                oUpdateMemberServiceQuery.append(" Where member_num = ? and  service_id=? and  sor_invariant_id=? ");
            } else {
                oUpdateMemberServiceQuery.append(" Where member_num = ? and  service_id=? and  instance_id=? ");
            }

            logger.debug("{}{}MPSDBSU_09 : updateMemberServiceSQL :: {} ", sClassName, sMethodName,
                    oUpdateMemberServiceQuery);

            oItr = hmInput.keySet().iterator();

            while (oItr.hasNext()) {
                sUpdateKey = (String) oItr.next();

                if (hmInput.containsKey(sUpdateKey)) {
                    objectList.add((String) hmInput.get(sUpdateKey));
                }
            }

            objectList.add((String) hmInput.get(MPSDefs.DB_MEMBER_NUM));
            objectList.add((String) hmInput.get(MPSDefs.DB_SERVICE_ID));

            if (hmInput.containsKey(MPSDefs.DB_SOR_INVARIANT_ID)) {
                objectList.add((String) hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID));
            } else {
                objectList.add((String) hmInput.get(MPSDefs.DB_INSTANCE_ID));
            }

            int rowCount = jdbcTemplate.update(new String(oUpdateMemberServiceQuery),
                    objectList.toArray(new Object[objectList.size()]));

            if (rowCount == 0) {
                stAppInfo = "No Record found";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_NO_SERVICE_NUM, stAppInfo);
                logger.info("{}{}MPSDBSU_11 : {}", sClassName, sMethodName, stAppInfo);
            } else {
                stAppInfo = "MEMBERSERVICE attributes updated successfully";
                hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, stAppInfo);
                logger.info("{}{}MPSDBSU_12 : {}", sClassName, sMethodName, stAppInfo);
            }
        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            hmResult = StatusMsg.makeExceptionSQLStatus(e);
            String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
            logger.error("{}{}DMDH.DGS.07 : Error:: {}", sClassName, sMethodName, e.getMessage());
            logger.error("{}{}DMDH.DGS.08 : Exception = {}", sClassName, sMethodName, errorCode);
            return hmResult;
        } finally {
            logger.info("{}{}DBTOOLS999 : Output from updateService = :  {} ", sClassName, sMethodName, hmResult);
        }
        return hmResult;
    }

    /**
     * @param hmInput
     * @return
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public HashMap updateMemberServiceInstanceId(HashMap hmInput) {
        String sMethodName = ".updateMemberServiceInstanceId.";
        HashMap hmResult = null;
        String stAppInfo = null;
        String updateStmt = "";

        if (hmInput == null || hmInput.isEmpty()) {
            stAppInfo = "input to updateMemberServiceInstanceId() is null";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
            logger.info("{}{}MPSDBSU_08 : Output from updateMemberServiceInstanceId = :  {} ", sClassName, sMethodName, stAppInfo);
            return hmResult;
        }

        String updateMemberServInstanceId =
                "UPDATE MEMBERSERVICE SET instance_id = ? WHERE service_id = ? AND group_num = ? AND member_num = ?";
        String updateMemberServInstanceIdWithSorInvId =
                "UPDATE MEMBERSERVICE SET instance_id = ? WHERE service_id = ? AND group_num = ? AND member_num = ? AND sor_invariant_id = ?";
        String updateServInstanceIdSorInvId =
                "UPDATE MEMBERSERVICE SET instance_id = ?, sor_invariant_id = ? WHERE service_id = ? AND group_num = ? AND member_num = ?";

        List<Object> objectList = new ArrayList<>();

        logger.info("{}{}DBHLP002 : updateMemberServiceInstanceId CVS KEYWORDS: {}", sClassName, sMethodName, INFO);
        logger.info("{}{}DBTOOLS000 :updateMemberServiceInstanceId InpParam : {}", sClassName, sMethodName, hmInput != null ? StringUtils.normalizeSpace(hmInput.toString()) : null);


        long groupNum = -1;
        long memberNum = -1;
        int serviceId = 0;
        try {
            String sGroupNum = (String) hmInput.get(MPSDefs.DB_GROUP_NUM);
            String serviceName = (String) hmInput.get(MPSDefs.DB_SERVICE_NAME);
            String sMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
            String sorInvariantId = (String) hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
            String instanceId = (String) hmInput.get(MPSDefs.DB_INSTANCE_ID);
            String sSorInvIdUpdateReqFlag = (String) hmInput.get(MPSDefs.SOR_INVARIANT_ID_UPDATE_REQ_FLAG);

            if (serviceName == null || serviceName.trim().isEmpty() || sGroupNum == null || sGroupNum.trim().isEmpty()
                    || sMemberNum == null || sMemberNum.trim().isEmpty() || instanceId == null || instanceId.trim().isEmpty()) {
                stAppInfo = "Service Name Group Number or Member Number or Instance Id is missing";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                logger.info("{}{}MPSDBSU_08 : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }

            groupNum = Long.parseLong(sGroupNum);
            memberNum = Long.parseLong(sMemberNum);
            serviceId = oDBHelper.getServiceId(serviceName);

            logger.debug("{}{}DBHLP83 : service_id={}", sMethodName, sClassName, serviceId);

            if (sorInvariantId != null && !sorInvariantId.trim().isEmpty() &&
                    sSorInvIdUpdateReqFlag != null && sSorInvIdUpdateReqFlag.trim().equals(MPSDefs.YES)) {
                updateStmt = updateServInstanceIdSorInvId;
            } else if (sorInvariantId != null && !sorInvariantId.trim().isEmpty()) {
                updateStmt = updateMemberServInstanceIdWithSorInvId;
            } else {
                updateStmt = updateMemberServInstanceId;
            }
            logger.debug("{}{}DBHLP84 : SQL = {}", sMethodName, sClassName, updateStmt);
            if (sSorInvIdUpdateReqFlag != null && sSorInvIdUpdateReqFlag.trim().equals(MPSDefs.YES)) {
                objectList.add(instanceId);
                objectList.add(sorInvariantId);
                objectList.add(serviceId);
                objectList.add(groupNum);
                objectList.add(memberNum);
            } else {
                objectList.add(instanceId);
                objectList.add(serviceId);
                objectList.add(groupNum);
                objectList.add(memberNum);
                if (sorInvariantId != null && !sorInvariantId.trim().isEmpty()) {
                    objectList.add(sorInvariantId);
                }
            }

            int rowCount = jdbcTemplate.update(new String(updateStmt),
                    objectList.toArray(new Object[objectList.size()]));

            if (rowCount == 0) {
                stAppInfo = "No Record found";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_NO_SERVICE_NUM, stAppInfo);
                logger.info("{}{}MPSDBSU_11  updateMemberServiceInstanceId: {}", sClassName, sMethodName, stAppInfo);
            } else {
                stAppInfo = "MEMBERSERVICE attributes updated successfully in the updateMemberServiceInstanceId ";
                hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, stAppInfo);
                logger.info("{}{}MPSDBSU_12 updateMemberServiceInstanceId : {}", sClassName, sMethodName, stAppInfo);
            }
        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            hmResult = StatusMsg.makeExceptionSQLStatus(e);
            String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
            logger.error("{}{}DMDH.DGS.07 : Error:: {}", sClassName, sMethodName, e.getMessage());
            logger.error("{}{}DMDH.DGS.08 : Exception = {}", sClassName, sMethodName, errorCode);
            return hmResult;
        } finally {
            logger.info("{}{}DBTOOLS999 : Output from updateMemberServiceInstanceId = :  {} ", sClassName, sMethodName, hmResult);
        }
        return hmResult;
    }

    /**
     * @param hmInput
     * @return
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public HashMap updateMemberServiceSorInvId(HashMap hmInput) {
        String sMethodName = ".updateMemberServiceSorInvId.";
        HashMap hmResult = null;
        String stAppInfo = null;
        String updateStmt = "";
        if (hmInput == null || hmInput.isEmpty()) {
            stAppInfo = "input to updateMemberServiceSorInvId() is null";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
            logger.info("{}{}PSDBSU_08 : Output from updateMemberServiceSorInvId = :  {} ", sClassName, sMethodName, stAppInfo);
            return hmResult;
        }

        String updateMemberServiceSorInvId =
                "UPDATE MEMBERSERVICE SET SOR_INVARIANT_ID = ?, LAST_MODIFIED_BY=? WHERE MEMBER_NUM=? AND SOR_ID=? AND SERVICE_ID=? ";
        String updateMemberServiceSorInvIdWithInstanceId =
                "UPDATE MEMBERSERVICE SET SOR_INVARIANT_ID = ?, LAST_MODIFIED_BY=? WHERE MEMBER_NUM=? AND SOR_ID=? AND SERVICE_ID=? AND INSTANCE_ID=? ";

        List<Object> objectList = new ArrayList<>();

        logger.info("{}{}DBHLP002 : CVS KEYWORDS: {}", sClassName, sMethodName, INFO);
        logger.info("{}{}DBTOOLS000 :updateMemberServiceSorInvId InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmInput));


        int iSorId = 0;
        int iServiceId = 0;
        try {
            String stMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
            String stSorId = (String) hmInput.get(MPSDefs.DB_SOR_ID);
            String stSorName = (String) hmInput.get(MPSDefs.DB_SOR_NAME);
            String stSorInvariantId = (String) hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
            String stInstanceId = (String) hmInput.get(MPSDefs.DB_INSTANCE_ID);
            String stLastModifiedBy = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);
            String stServiceId = (String) hmInput.get(MPSDefs.DB_SERVICE_ID);
            String stServiceName = (String) hmInput.get(MPSDefs.DB_SERVICE_NAME);

            if (stMemberNum == null || stMemberNum.trim().isEmpty() || stSorId == null || stSorId.trim().isEmpty() || stSorName == null
                    || stSorName.trim().isEmpty() || stSorInvariantId == null || stSorInvariantId.trim().isEmpty()
                    || stServiceId == null || stServiceId.trim().isEmpty() || stServiceName == null || stServiceName.trim().isEmpty()
                    || stLastModifiedBy == null || stLastModifiedBy.trim().isEmpty()) {
                stAppInfo = "Member Number, Sor Id, Sor Name, Sor Invariant Id, Service Id, Service Name " +
                        "or Last Modified By is missing";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                logger.info("{}{}QIPRL.DBH_03: {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }

            if ((stSorId == null || stSorId.trim().length() == 0) &&
                    (stSorName != null && !stSorName.trim().isEmpty())) {
                stSorId = oSystemOfRecordValidation.getSystemOfRecordIdByName(stSorName.trim());
                iSorId = Integer.parseInt(stSorId);
                logger.debug("{}{}DBTOOLS05 : Got sor_id from cache= {}", sClassName, sMethodName, iSorId);
            } else if (stSorId != null && stSorId.trim().length() > 0) {
                iSorId = Integer.parseInt(stSorId);
            }
            if ((stServiceId == null || stServiceId.trim().length() == 0) &&
                    (stServiceName != null && !stServiceName.trim().isEmpty())) {
                iServiceId = oDBHelper.getServiceId(stServiceName);
            } else if (stServiceId != null && stServiceId.trim().length() > 0) {
                iServiceId = Integer.parseInt(stServiceId);
            }

            logger.debug("{}{}DBHLP83 : service_id={}", sMethodName, sClassName, iServiceId);

            if (stInstanceId != null && !stInstanceId.trim().isEmpty()) {
                updateStmt = updateMemberServiceSorInvIdWithInstanceId;
            } else {
                updateStmt = updateMemberServiceSorInvId;
            }

            logger.debug("{}{}DBHLP84 : SQL = {}", sMethodName, sClassName, updateStmt);

            objectList.add(stSorInvariantId);
            objectList.add(stLastModifiedBy);
            objectList.add(stMemberNum);
            objectList.add(iSorId);
            objectList.add(iServiceId);
            if (stInstanceId != null && !stInstanceId.trim().isEmpty()) {
                objectList.add(stInstanceId);
            }

            int rowCount = jdbcTemplate.update(new String(updateStmt),
                    objectList.toArray(new Object[objectList.size()]));

            if (rowCount == 0) {
                stAppInfo = "No Record found";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo);
                logger.info("{}{}MPSDBSU_10 : {}", sClassName, sMethodName, stAppInfo);
            } else {
                stAppInfo = "MEMBERSERVICE attributes updated successfully in the updateMemberServiceSorInvId ";
                hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, stAppInfo);
                logger.info("{}{}MPSDBSU_11 : {}", sClassName, sMethodName, stAppInfo);
            }
        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            hmResult = StatusMsg.makeExceptionSQLStatus(e);
            String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
            logger.error("{}{}DMDH.DGS.07 : Error:: {}", sClassName, sMethodName, e.getMessage());
            logger.error("{}{}DMDH.DGS.08 : Exception = {}", sClassName, sMethodName, errorCode);
            return hmResult;
        } finally {
            logger.info("{}{}DBTOOLS999 : Output from updateMemberServiceSorInvId = :  {} ", sClassName, sMethodName, hmResult);
        }
        return hmResult;
    }


}
