package com.att.idp.idgraphusermanagementms.db.repository;

import java.sql.SQLException;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.att.idp.idgraphusermanagementms.db.model.Tdomain;

/**
 * This is an interface for the DomainRepository.
 * It extends JpaRepository to provide CRUD operations for the Tdomain entity.
 * It also extends DomainRepositoryCustom for custom queries and operations.
 *
 * @param Tdomain The type of the entity this repository manages.
 * @param Long The type of the id of the entity this repository manages.
 */
@Repository 
public interface DomainRepository extends JpaRepository<Tdomain, Long> , DomainRepositoryCustom {
	
	/*
	 * @Query(value =
	 * "select domain.domainId from Tdomain domain where domain.domainName=:domainName"
	 * ) public Long getDomainId(@Param(value = "domainName") String domainName)
	 * throws SQLException;
	 */
	
	/**
	 * This method is used to get the domain ID by its name.
	 *
	 * @param domainName The name of the domain. This is used to search for the domain in the database.
	 * @return The ID of the domain with the provided name. If no domain with the provided name is found, this method throws a SQLException.
	 * @throws SQLException If there is a problem accessing the database or if no domain with the provided name is found.
	 */
	@Query(value =  "select domain.DOMAIN_ID from MPS_OWNER.TDOMAIN domain where domain.DOMAIN_NAME=:domainName", nativeQuery=true)
	public Long getDomainId(@Param(value = "domainName") String domainName) throws SQLException;
	
	/**
	 * This method is used to get the Tdomain object by its domain name.
	 *
	 * @param domainName The name of the domain. This is used to search for the domain in the database.
	 * @return The Tdomain object with the provided domain name. If no domain with the provided name is found, this method throws a SQLException.
	 * @throws SQLException If there is a problem accessing the database or if no domain with the provided name is found.
	 */
	@Query(value =  "select domain from Tdomain domain where domain.domainName=:domainName")
	public Tdomain getTDomainByDomainName(@Param(value = "domainName") String domainName) throws SQLException;
}
