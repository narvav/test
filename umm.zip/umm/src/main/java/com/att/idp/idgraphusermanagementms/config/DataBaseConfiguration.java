package com.att.idp.idgraphusermanagementms.config;

import java.sql.SQLException;
import java.util.Properties;

import com.att.idp.idgraphusermanagementms.appconfig.config.IDGraphAzureAppConfig;
import org.apache.tomcat.jdbc.pool.XADataSource;
import org.apache.tomcat.jdbc.pool.interceptor.QueryTimeoutInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.event.EventListener;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;

/**
 * This is an interface named ApplicationDataSourceConstant.
 * It contains constants that are used as keys for various components in the application's data source configuration.
 * These constants are used throughout the application to ensure consistency when referring to these components.
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "com.att.idp.idgraphusermanagementms.db.repository")

public class DataBaseConfiguration {

    private static final Logger log = LoggerFactory.getLogger(DataBaseConfiguration.class);

    @Value("${spring.datasource.url}")
    private String url;

    @Value("${spring.datasource.driver-class-name}")
    private String driverClassName;

    @Value("${spring.datasource.username}")
    private String dbUserName;

    @Value("${spring.datasource.password}")
    private String dbPassword;

    @Value("${AES256KEY}")
    private String propAes256Key;


    @Autowired
    private IDGraphAzureAppConfig idGraphAzureAppConfig;

    @Autowired
    private ApplicationContext applicationContext;


    /**
     * Handles the refresh event triggered by the Spring Cloud RefreshScope.
     * <p>
     * This method is invoked when the application context is refreshed, typically due to
     * configuration changes. It synchronizes the update of the `RestTemplate` instance
     * with new timeout values retrieved from the `IDGraphAzureAppConfig` bean.
     * If the update fails, the method logs the error and retains the existing `RestTemplate`.
     *
     * @throws Exception if an error occurs while updating the `RestTemplate` instance.
     *                   /**
     *                   Handles the refresh event triggered by the Spring Cloud RefreshScope.
     *                   <p>
     *                   This method is invoked when the application context is refreshed, typically due to
     *                   configuration changes. It synchronizes the update of the `XADataSource` instance
     *                   with new configuration values retrieved from the `IDGraphAzureAppConfig` bean.
     *                   If the update fails, the method logs the error and retains the existing `XADataSource`.
     * @throws Exception if an error occurs while updating the `XADataSource` instance.
     */
    @EventListener(RefreshScopeRefreshedEvent.class)
    public void onConfigurationRefresh() throws Exception {
        if (idGraphAzureAppConfig.isDataSourceRefreshEnabled()) {
            synchronized (this) {
                try {

                    XADataSource xaDataSource = applicationContext.getBean(XADataSource.class);

                    if (xaDataSource == null) {
                        log.error("XADataSource bean is not available in the application context.");
                        xaDataSource = xaDataSource();
                        ConfigurableApplicationContext configurableContext = (ConfigurableApplicationContext) applicationContext;
                        configurableContext.getBeanFactory().registerSingleton("xaDataSource", xaDataSource);
                    }

                    xaDataSource.setValidationQuery(idGraphAzureAppConfig.getValidationQuery());
                    xaDataSource.setInitialSize(idGraphAzureAppConfig.getInitialSize());
                    xaDataSource.setMaxActive(idGraphAzureAppConfig.getMaxSize());
                    xaDataSource.setMinIdle(idGraphAzureAppConfig.getMinSize());
                    xaDataSource.setTestOnBorrow(idGraphAzureAppConfig.isTestOnBorrow());
                    xaDataSource.setTestWhileIdle(idGraphAzureAppConfig.isTestWhileIdle());
                    xaDataSource.setJdbcInterceptors(QueryTimeoutInterceptor.class.getName() + "(queryTimeout=" + idGraphAzureAppConfig.getQueryTimeout() + ")");
                    xaDataSource.setMinEvictableIdleTimeMillis(idGraphAzureAppConfig.getEvictTime());
                    xaDataSource.setMaxWait(idGraphAzureAppConfig.getConnTimeout());

                    log.info("XADataSource dynamically updated with new values from appconfig: appconfig.version [{}], connTimeout [{}], maxSize [{}], queryTimeout [{}], validationQuery [{}], initialSize [{}], testWhileIdle [{}], testOnBorrow [{}], evictTime [{}], minSize [{}]", idGraphAzureAppConfig.getVersion(), idGraphAzureAppConfig.getConnTimeout(), idGraphAzureAppConfig.getMaxSize(), idGraphAzureAppConfig.getQueryTimeout(), idGraphAzureAppConfig.getValidationQuery(), idGraphAzureAppConfig.getInitialSize(), idGraphAzureAppConfig.isTestWhileIdle(), idGraphAzureAppConfig.isTestOnBorrow(), idGraphAzureAppConfig.getEvictTime(), idGraphAzureAppConfig.getMinSize());
                } catch (Exception e) {
                    log.error("Failed to update XADataSource  with new appconfig values. Retaining the old XADataSource.", e);
                }
            }
        }
        else {
            log.info("DataSource refresh is disabled. Retaining the existing DataSource configuration, appconfig.isDataSourceRefreshEnabled [{}]", idGraphAzureAppConfig.isDataSourceRefreshEnabled());
        }
    }

    /**
     * This method is responsible for creating and configuring a LocalContainerEntityManagerFactoryBean.
     * LocalContainerEntityManagerFactoryBean is a FactoryBean that creates a JPA EntityManagerFactory according to JPA's standard container bootstrap contract.
     * This is the usual way to set up a shared JPA EntityManagerFactory in a Spring application context; the EntityManagerFactory can then be passed to JPA-based DAOs via dependency injection.
     *
     * @return LocalContainerEntityManagerFactoryBean - a factory bean that creates an EntityManagerFactory.
     * <p>
     * The method performs the following operations:
     * 1. Creates a new instance of LocalContainerEntityManagerFactoryBean.
     * 2. Sets the data source for the EntityManagerFactory using the dataSource() method.
     * 3. Sets the packages to scan for entity classes.
     * 4. Sets the JPA vendor adapter - in this case, HibernateJpaVendorAdapter.
     * 5. Sets the JPA properties - these include properties related to the Hibernate dialect, SQL formatting, schema, batching, and statistics.
     */
    @Bean
    @Primary
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {

        LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();

        try {
            entityManagerFactoryBean.setDataSource(xaDataSource());
        } catch (Exception e) {
            log.error("DBC1.1", "Error while creating xaDataSource:" + e.getMessage());
        }
        entityManagerFactoryBean.setPackagesToScan("com.att.idp.idgraphusermanagementms.db.model");
        final HibernateJpaVendorAdapter jpaVendorAdapter = new HibernateJpaVendorAdapter();
        entityManagerFactoryBean.setJpaVendorAdapter(jpaVendorAdapter);
        entityManagerFactoryBean.setPackagesToScan("com.att.idp.idgraphusermanagementms");
        Properties jpaProperties = new Properties();

        jpaProperties.put("hibernate.dialect", "org.hibernate.dialect.OracleDialect");
        jpaProperties.put("hibernate.hbm2ddl.auto", "none");
        jpaProperties.put("hibernate.format_sql", "true");
        jpaProperties.put("hibernate.show_sql", "false");
        jpaProperties.put("hibernate.default_schema", "BROKEN");
        jpaProperties.put("hibernate.jdbc.batch_size", 30);
        jpaProperties.put("hibernate.order_inserts", "true");
        jpaProperties.put("hibernate.order_updates", "true");
        jpaProperties.put("hibernate.general_statistics", "false");

        entityManagerFactoryBean.setJpaProperties(jpaProperties);

        return entityManagerFactoryBean;
    }

    /**
     * Defining xaDataSource details.
     *
     * @return dataSource instance of XADatasource
     */
    @Bean(name = "xaDataSource")
    XADataSource xaDataSource() throws SQLException, Exception {

        XADataSource xaDataSource = null;
        xaDataSource = new XADataSource();
        xaDataSource.setUrl(url);
        xaDataSource.setUsername(dbUserName);
        xaDataSource.setPassword(CommonUtilHelper.getAESDecryption(dbPassword, propAes256Key));
        xaDataSource.setDriverClassName(driverClassName);
        xaDataSource.setValidationQuery(idGraphAzureAppConfig.getValidationQuery());
        xaDataSource.setInitialSize(idGraphAzureAppConfig.getInitialSize());
        xaDataSource.setMaxActive(idGraphAzureAppConfig.getMaxSize());
        xaDataSource.setMinIdle(idGraphAzureAppConfig.getMinSize());
        xaDataSource.setTestOnBorrow(idGraphAzureAppConfig.isTestOnBorrow());
        xaDataSource.setTestWhileIdle(idGraphAzureAppConfig.isTestWhileIdle());
        xaDataSource.setJdbcInterceptors(QueryTimeoutInterceptor.class.getName() + "(queryTimeout=" + idGraphAzureAppConfig.getQueryTimeout() + ")");
        xaDataSource.setMinEvictableIdleTimeMillis(idGraphAzureAppConfig.getEvictTime());
        xaDataSource.setMaxWait(idGraphAzureAppConfig.getConnTimeout());

        return xaDataSource;
    }


    /**
     * This method is responsible for creating and configuring a PlatformTransactionManager.
     * PlatformTransactionManager is an interface that specifies behaviors for transaction management.
     * The method creates a JpaTransactionManager, sets its EntityManagerFactory with the one created by the entityManagerFactory method, and returns it.
     * The JpaTransactionManager is a specific implementation of the PlatformTransactionManager interface for JPA.
     *
     * @return PlatformTransactionManager - a transaction manager configured for JPA.
     */
    @Bean
    public PlatformTransactionManager transactionManagerRef() {
        final JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
        return transactionManager;
    }
}
