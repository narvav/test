package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TMEMBERSERVICE", schema = "MPS_OWNER", uniqueConstraints = @UniqueConstraint(columnNames = {
		"MEMBER_NUM", "SERVICE_ID", "SOR_ID", "SOR_INVARIANT_ID" }))
public class Tmemberservice implements Serializable {

	private static final long serialVersionUID = 2304620510194167011L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "memberNum", column = @Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "serviceId", column = @Column(name = "SERVICE_ID", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "groupNum", column = @Column(name = "GROUP_NUM", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "groupStatus", column = @Column(name = "GROUP_STATUS", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "memberStatus", column = @Column(name = "MEMBER_STATUS", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "createDate", column = @Column(name = "CREATE_DATE", nullable = false, length = 7)),
			@AttributeOverride(name = "lastModifiedBy", column = @Column(name = "LAST_MODIFIED_BY", nullable = false)),
			@AttributeOverride(name = "sorId", column = @Column(name = "SOR_ID", precision = 22, scale = 0))})
	private TmemberserviceId id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MEMBER_NUM", nullable = false, insertable = false, updatable = false)
	private Tmember tmember;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SOR_ID", insertable = false, updatable = false)
	private Tsystemofrecord tsystemofrecord;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SERVICE_ID", nullable = false, insertable = false, updatable = false)
	private Tservice tservice;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MEMBER_STATUS", nullable = false, insertable = false, updatable = false)
	private Tstatus tstatusByMemberStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "GROUP_STATUS", nullable = false, insertable = false, updatable = false)
	private Tstatus tstatusByGroupStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "GROUP_NUM", nullable = false, insertable = false, updatable = false)
	private Tmembergroup tmembergroup;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumns(value = {@JoinColumn(name = "MEMBER_NUM", insertable = false, updatable = false),
			@JoinColumn(name = "SERVICE_ID", insertable = false, updatable = false),
			@JoinColumn(name = "SOR_ID", insertable = false, updatable = false),
			@JoinColumn(name = "SOR_INVARIANT_ID", insertable = false, updatable = false)})
	private Tmemberservicerole tmemberservicerole;

	@Column(name = "TERMINATE_DATE", length = 7)
	private Date terminateDate;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "INSTANCE_ID", length = 24)
	private String instanceId;

	@Column(name = "PENDING_DISCONNECT_DATE", length = 7)
	private Date pendingDisconnectDate;

	@Column(name = "SITE_ID", length = 9)
	private String siteId;

	@Column(name = "SOR_INVARIANT_ID")
	private String sorInvariantId;

	@Column(name = "ATLAS_LAST_TIMESTAMP")
	private String atlasLastTimestamp;

	@Column(name = "OWNED_BY", precision = 22, scale = 0)
	private Long ownedBy;

	@Column(name = "NICKNAME", length = 30)
	private String nickname;

	@Column(name = "DEFAULT_ACCOUNT", length = 1)
	private Character defaultAccount;

	@Column(name = "DATE_DEFAULT_EST", length = 7)
	private Date dateDefaultEst;

	@Column(name = "CPNI_IMPACTED", length = 1)
	private Character cpniImpacted;

	@Column(name = "SUSPEND_REASON_CODE", length = 30)
	private String suspendReasonCode;

	@Column(name = "PARENT_SOR_ID", precision = 22, scale = 0)
	private Long parentSorId;

	@Column(name = "PARENT_SOR_INVARIANT_ID")
	private String parentSorInvariantId;

	@Column(name = "UVERSE_SERVICE_IND", length = 1)
	private Character uverseServiceInd;

	@Column(name = "UNIFICATION_PENDING", length = 1)
	private Character unificationPending;
}