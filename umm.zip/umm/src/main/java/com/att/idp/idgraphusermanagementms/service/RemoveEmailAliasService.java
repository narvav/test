package com.att.idp.idgraphusermanagementms.service;

import com.att.idp.idgraphusermanagementms.resource.request.RemoveEmailAliasRequest;
import com.att.idp.idgraphusermanagementms.resource.response.CommonResponse;
import jakarta.ws.rs.core.MultivaluedMap;


public interface RemoveEmailAliasService {


	CommonResponse removeEmailAlias(RemoveEmailAliasRequest removeEmailAliasIdRequest,
									 MultivaluedMap<String, String> requestHeader);

}
