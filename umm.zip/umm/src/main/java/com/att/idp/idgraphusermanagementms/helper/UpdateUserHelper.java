package com.att.idp.idgraphusermanagementms.helper;

import com.att.idp.idgraphusermanagementms.db.helper.GetMemberServicesDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.UpdateDBHelper;
import com.att.idp.idgraphusermanagementms.helper.voltage.ProofingEncryptionHelper;
import com.att.idp.idgraphusermanagementms.queue.message.helpers.UpdateUserQueueHelper;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.SharedUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.*;
import net.logstash.logback.argument.StructuredArguments;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;
import java.util.*;

/**
 * This class is a helper class for updating user information in the system.
 * It contains methods for validating input, retrieving user information, and updating the user's information in the database.
 * It uses various other helper classes and services such as UpdateUserQueueHelper, ProofingEncryptionHelper, GetMemberServicesDBHelper, and UpdateDBHelper.
 * It also uses various constants and utility methods from the CommonDefs, MPSDefs, and CommonUtil classes.
 * The main method in this class is the updateUser method, which takes a HashMap of input parameters and returns a HashMap with the result of the operation.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class UpdateUserHelper extends AbstractHelper {
	public static final Logger logger = LoggerFactory.getLogger(UpdateUserHelper.class);
	private static final String sClassName = "UpdateUserHelper";
	private static final String ERROR_ENUM = "ErrorEnum";
	private boolean isTransactionRollbackOnError = false;

	@Value("${updateForSlidAndMembers}")
	private String propUpdateForSlidAndMembers;

	@Value("${updateForSlidOnly}")
	private String propUpdateForSlidOnly;

	@Value("${updateContactInfoFields}")
	private String propUpdateContactInfoFields;

	@Value("${UpdateUser_Input_To_DB_Keys_Mapping}")
	private String propUpdateUser_Input_To_DB_Keys_Mapping;

	@Value("${updateUserMemberIdUpdatableAttributes}")
	private String propAllowedFieldsForMemberIdUpdate;

	@Autowired
	private UpdateUserQueueHelper updateUserQueueHelper;

	@Autowired
	private ProofingEncryptionHelper oProofingEncryption;

	@Autowired
	private GetMemberServicesDBHelper oGetMemberServicesDBHelper;

	@Autowired
	private UpdateDBHelper updateDBHelper;

	@Autowired
	private CommonUtilHelper commonUtilHelper;

	@Autowired
	private SharedUtilHelper sharedUtilHelper;

	/**
	 * This method is responsible for updating the user's information in the system.
	 * It first validates the input parameters and retrieves the user's current information from the database.
	 * If the user's information needs to be updated, it prepares the necessary data and calls the appropriate helper methods to update the information.
	 * These helper methods include methods for checking fraud locks, updating the database, and sending messages to the message queue.
	 * If any of these operations return an error, it is returned to the caller.
	 * If all operations are successful, the method returns a success message.
	 *
	 * @param hmInput A HashMap containing the input parameters for the method. It should include necessary information such as user ID, new user information, transaction ID, transaction name, calling system ID, and other user details to be updated.
	 * @return A HashMap containing the result of the method. It includes the application status code and other information.
	 * @throws Exception If there is an error during the operation.
	 */
	public Map<String, Object> updateUser(Map<String, Object> hmInput) {
		String sMethodName = ".updateUser.";
		Map<String, Object> hmResult = null;
		String stAppStatusCode;
		String stAppInfo;
		String stGuid = null;
		boolean isMemberIdInReq = false;
		logger.info(SpiMarker.getInstance(), "UpdateUserHelper.updateUser.HLP000 : Input Hash :",
				StructuredArguments.entries(hmInput));

		if (hmInput == null || hmInput.isEmpty()) {
			stAppInfo = "Input Hash is NULL";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			logger.info("{}{}UUH_100 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		isMemberIdInReq = CommonDefs.SLID_DUM.equals(hmInput.get(CommonDefs.DOMAIN)) ? false : true;

		try {
			// get member services from database
			HashMap<String, Object> hmDBMemberInfo;
			HashMap<String, Object> hmDbInput = CommonUtil.getHashMap();
			ArrayList alSildMaskInp = new ArrayList();
			alSildMaskInp.add("LU");
			alSildMaskInp.add("LS");
			alSildMaskInp.add("SQ");

			hmDbInput.put(MPSDefs.SECURITY_ALL_REQ, CommonDefs.DEFAULT_YES);
			hmDbInput.put(MPSDefs.QUERY_SLID_INFO_FLAG, CommonDefs.DEFAULT_YES);
			hmDbInput.put(MPSDefs.QUERY_LINKED_USERS_FLAG, CommonDefs.DEFAULT_YES);
			hmDbInput.put(MPSDefs.QUERY_FRAUD_LOCK_FLAG, CommonDefs.DEFAULT_YES);
			hmDbInput.put(CommonDefs.SLID_MASK, alSildMaskInp);

			if (hmInput.get(CommonDefs.HANDLE) != null) {
				hmDbInput.put(MPSDefs.DB_MEMBER_NAME, hmInput.get(CommonDefs.HANDLE));
				hmDbInput.put(MPSDefs.DB_DOMAIN_NAME, hmInput.get(CommonDefs.DOMAIN));
			} else if (hmInput.get(CommonDefs.GUID) != null) {
				hmDbInput.put(MPSDefs.DB_MEMBER_NUM, hmInput.get(CommonDefs.GUID));
			}
			else{
				stAppInfo = "Either GUID or UserID should be present";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			hmDBMemberInfo = oGetMemberServicesDBHelper.getMemberServices(hmDbInput);

			if (hmDBMemberInfo != null && !hmDBMemberInfo.isEmpty()) {
				logger.debug("{}{} hmDBMemberInfo: {}", sClassName, sMethodName, hmDBMemberInfo);
			}

			if (hmDBMemberInfo == null) {
				stAppInfo = "GetMemberServicesDBHelper.getMemberServices helper returned null.";
				logger.info("{}{}UUH_101 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				return hmResult;
			}

			stAppStatusCode = (String) hmDBMemberInfo.get(CErrorDefs.COMMON_APP_STATUS_CODE);

			if (stAppStatusCode != null && !stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
				if (stAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
					stAppInfo = "Input guid or handle/domain not found";
					logger.info("{}{}UUH_102 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
				} else {
					hmResult.putAll(hmDBMemberInfo);
				}
				return hmResult;
			}

			String stFirstName = (String) hmInput.get(CommonDefs.FIRST_NAME);
			String stLastName = (String) hmInput.get(CommonDefs.LAST_NAME);

			String stFullName = (String) hmInput.get(CommonDefs.FULLNAME);

			if (stFullName == null || stFullName.isEmpty()) {
				if ((stFirstName != null && !stFirstName.isEmpty()) || (stLastName != null && !stLastName.isEmpty())) {

					if (stFirstName == null || stFirstName.isEmpty())
						stFirstName = (String) hmDBMemberInfo.get(MPSDefs.DB_LC_FIRSTNAME);

					if (stLastName == null || stLastName.isEmpty())
						stLastName = (String) hmDBMemberInfo.get(MPSDefs.DB_LC_LASTNAME);

					stFullName = stFirstName + " " + stLastName;
					hmInput.put(CommonDefs.FULLNAME, stFullName);
				}
			}
			if (hmInput.get(CommonDefs.GUID) != null) {
				stGuid = hmInput.get(CommonDefs.GUID).toString();
			}
			String stDomain = (String) hmDBMemberInfo.get(MPSDefs.DB_DOMAIN_NAME);
			// A link member request can contain any domain name.
			if (hmInput.get("originTransactionName") != null && !hmInput.get("originTransactionName").equals("LinkMember")) {
				if (stGuid != null && !stGuid.isEmpty()) {
					if (stDomain != null && !stDomain.isEmpty() && !stDomain.equals("slid.dum")) {
						stAppInfo = "only domain slid.dum is supported at this time";
						logger.info("{}{}UUH_103 :{} ", sClassName, sMethodName, stAppInfo);
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
						return hmResult;
					}
				} else {
					stGuid = (String) hmDBMemberInfo.get(MPSDefs.DB_MEMBER_NUM);
				}
			} else {
				stGuid = (String) hmDBMemberInfo.get(MPSDefs.DB_MEMBER_NUM);
			}

			// performing memberID updates specific validations
			if(isMemberIdInReq) {

				HashMap<String, Object> hmDbMemberServices = null;
				hmDbMemberServices = (HashMap) hmDBMemberInfo.get(MPSDefs.SERVICES);

				if (hmDbMemberServices == null || hmDbMemberServices.isEmpty()) {
					stAppInfo = "MemberServices in DB is null. We can not operate";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, stAppInfo);
					logger.error("{}{}TAAB_PID_02.1 : hmResult : {}",sClassName, sMethodName, hmDbMemberServices);
				    return hmResult;
				}

				// check for active member and one enabled service
				String memberState = (String) hmDBMemberInfo.get(MPSDefs.DB_MEMBER_STATE);

				boolean isMemberActiveAndSrvEnabled = false;
				boolean isPortalServiceEnabled = false;
				boolean isUverseServiceEnabled = false;

				// check for active member and one enabled service
				isMemberActiveAndSrvEnabled = checkForActiveMemberAndService(hmDbMemberServices , memberState);
				logger.info("{}{}UUH_104 : member is in active state and has atleast one enabled service : {}", sClassName, sMethodName, isMemberActiveAndSrvEnabled);
				// check for portal service and its status
				isPortalServiceEnabled = checkPortalServiceStatus(hmDbMemberServices);
				logger.info("{}{}UUH_104 : member has portal service and it it's status is enabled : {}", sClassName, sMethodName, isPortalServiceEnabled);

				// Users with any of UVERSE Services can not make zipCode updates
				String zipCode = (String) hmInput.get(CommonDefs.ZIP_CODE);
				if(zipCode != null && !zipCode.isBlank()) {
					isUverseServiceEnabled = checkUverseServiceEnabled(hmDbMemberServices);
					logger.info("{}{}UUH_104 : member has any of HISA/VOIP/IPTV services in enabled status: {}", sClassName, sMethodName, isUverseServiceEnabled);
				}

				if(!isMemberActiveAndSrvEnabled || !isPortalServiceEnabled || isUverseServiceEnabled) {
					stAppInfo = "MemberId updates are not allowed because of service status check";
					logger.info("{}{}UUH_105 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, stAppInfo);
					return hmResult;
				}

			}

			// checkFraudLock
			hmResult = checkFraudLock(hmDBMemberInfo);

			logger.info("{}{}UUH_104 :Response from checkFraudLock: {}", sClassName, sMethodName, hmResult);
			stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			} else if (stAppStatusCode == null) {
				stAppInfo = "null response from UpdateUserHelper.checkFraudLock";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}UUH_105 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			//isFieldToBeUpdated
			boolean bResult = isFieldToBeUpdated(hmInput, hmDBMemberInfo);
			logger.debug("{}{}UUH_106 : Fields to be updated : {}" , sClassName , sMethodName, hmInput);
			if (!bResult) {
				stAppInfo = "Request fields and MPS data fields contain the same info. Hence no action taken";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
				hmResult.put(CommonDefs.GUID, stGuid);
				logger.info("{}{}UUH_107 : {}" , sClassName , sMethodName, stAppInfo);
				return hmResult;
			}

			// Voltage Encryption of SPI data
			hmResult = setVoltageEncryptedFields(hmInput);
			logger.debug("{}{}UUH_108 :Response from setVoltageEncryptedFields: {}", sClassName, sMethodName, hmResult);
			stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			} else if (stAppStatusCode == null) {
				stAppInfo = "null response from UpdateUserHelper.setVoltageEncryptedFields";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}UUH_109 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			if(isMemberIdInReq) {
				// Updating member in DB:
				hmResult = updateMemberIdDB(hmInput, hmDBMemberInfo);
				logger.info("{}{}UUH_110 :Response from updateUserDB: {}", sClassName, sMethodName, hmResult);
			} else {
				// Updating User in DB:
				hmResult = updateUserDB(hmInput, hmDBMemberInfo);
				logger.info("{}{}UUH_110 :Response from updateUserDB: {}", sClassName, sMethodName, hmResult);
			}

			stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			} else if (stAppStatusCode == null) {
				stAppInfo = "null response from UpdateUserHelper.updateUserDB";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}UUH_111 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			// DbusCall
			Map hmDbusResult = updateUserQueueHelper.sendMessageToMQ(hmInput, hmDBMemberInfo);
			logger.info("{}{}UUH_112 :Response from updateUserQueueHelper.sendMessageToMQ: {}", sClassName, sMethodName,
					hmDbusResult);

			if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmDbusResult)) {
				hmResult = CommonUtilHelper.sysErrorHashMap("null response from UpdateUserQueueHelper.sendMessageToMQ");
				isTransactionRollbackOnError = true;
				return hmResult;
			} else {

				stAppStatusCode = (String) hmDbusResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
				if (StringUtils.isBlank(stAppStatusCode)) {
					isTransactionRollbackOnError = true;
					hmResult = CommonUtilHelper
							.sysErrorHashMap("null response from UpdateUserQueueHelper.sendMessageToMQ");
					return hmResult;
				} else if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					isTransactionRollbackOnError = true;
					stAppInfo = (String) hmDbusResult.get(CommonDefs.COMMON_APP_INFO);
					logger.info("{}{}UUH_113 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = hmDbusResult;
					return hmResult;
				}

			}

			// Default success if no error occur
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
			hmResult.put(CommonDefs.GUID, stGuid);
			hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown UpdateUser method : " + hmResult;
			logger.info("{}{}UUH_114 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(stAppInfo));

		}

		finally {
			String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
			if (isTransactionRollbackOnError && sAppCategoryCode != null
					&& !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
				hmResult.put("isTransactionRollback", "Y");
			}
			logger.info("{}{}HLP999 : response from UpdateUser = {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;

	}

	/**
	 * This method checks if there are any fields in the input HashMap that need to be updated in the database.
	 * It compares the values in the input HashMap with the values in the database HashMap for each field.
	 * If the value of a field in the input HashMap is different from the value of the same field in the database HashMap, the method returns true.
	 * If the values of all fields in the input HashMap are the same as the values of the corresponding fields in the database HashMap, the method returns false.
	 *
	 * @param hmInput A HashMap containing the input parameters for the method. It should include necessary information such as user ID, new user information, transaction ID, transaction name, calling system ID, and other user details to be updated.
	 * @param hmDBInput A HashMap containing the current user information from the database. It should include necessary information such as user ID, current user information, transaction ID, transaction name, calling system ID, and other user details.
	 * @return A boolean indicating whether there are any fields that need to be updated. Returns true if there are fields that need to be updated, and false otherwise.
	 */
	public boolean isFieldToBeUpdated(Map<String, Object> hmInput, Map<String, Object> hmDBInput) {
		String sMethodName = ".isFieldToBeUpdated.";
		boolean bResult = false;

		if (hmInput.get(CommonDefs.ACTIVATED_IND) != null) {
			if (hmDBInput.get(MPSDefs.DB_ACTIVATED_IND) != null) {
				if (!(hmDBInput.get(MPSDefs.DB_ACTIVATED_IND).equals(hmInput.get(CommonDefs.ACTIVATED_IND))) && !hmInput.get(CommonDefs.ACTIVATED_IND).toString().isEmpty()) {
					bResult = true;
				} else {
					hmInput.remove(CommonDefs.ACTIVATED_IND);
				}
			} else {
				bResult = true;
			}
		}

		if (hmInput.get(CommonDefs.FIRST_NAME) != null) {
			if (hmDBInput.get(MPSDefs.DB_LC_FIRSTNAME) != null) {
				if (!(hmDBInput.get(MPSDefs.DB_LC_FIRSTNAME).equals(hmInput.get(CommonDefs.FIRST_NAME))) && !hmInput.get(CommonDefs.FIRST_NAME).toString().isEmpty()) {
					bResult = true;
				} else {
					hmInput.remove(CommonDefs.FIRST_NAME);
				}
			} else {
				bResult = true;
			}
		}

		if (hmInput.get(CommonDefs.LAST_NAME) != null) {
			if (hmDBInput.get(MPSDefs.DB_LC_LASTNAME) != null) {
				if (!(hmDBInput.get(MPSDefs.DB_LC_LASTNAME).equals(hmInput.get(CommonDefs.LAST_NAME))) && !hmInput.get(CommonDefs.LAST_NAME).toString().isEmpty()) {
					bResult = true;
				} else {
					hmInput.remove(CommonDefs.LAST_NAME);
				}
			} else {
				bResult = true;
			}
		}

		if (hmInput.get(CommonDefs.BROWSER_LANGUAGE) != null) {
			if (hmDBInput.get(MPSDefs.DB_BROWSER_LANGUAGE) != null) {
				if (!(hmDBInput.get(MPSDefs.DB_BROWSER_LANGUAGE).equals(hmInput.get(CommonDefs.BROWSER_LANGUAGE)))) {
					bResult = true;
				} else {
					hmInput.remove(CommonDefs.BROWSER_LANGUAGE);
				}
			} else {
				bResult = true;
			}
		}

		if (hmInput.get(CommonDefs.IS_VERIFIED) != null
				&& hmInput.get(CommonDefs.IS_VERIFIED).equals(CommonDefs.DEFAULT_YES)) {
			bResult = true;
		}

		if (hmInput.get(CommonDefs.MAIN_CTN_OPT_OUT) != null
				&& hmInput.get(CommonDefs.MAIN_CTN_OPT_OUT).equals(CommonDefs.DEFAULT_YES)) {
			bResult = true;
		}

		if (hmInput.get(CommonDefs.CBR_OPT_OUT) != null
				&& hmInput.get(CommonDefs.CBR_OPT_OUT).equals(CommonDefs.DEFAULT_YES)) {
			bResult = true;
		}

		if (hmInput.get(CommonDefs.CONTACT_EMAIL) != null ) {
			if (!(hmInput.get(CommonDefs.CONTACT_EMAIL).equals(hmDBInput.get(MPSDefs.DB_CONTACT_EMAIL)))) {
				if(hmDBInput.get(MPSDefs.DB_CONTACT_EMAIL) != null ) {
					hmInput.put(CommonDefs.PREVIOUS_CONTACT_EMAIL,hmDBInput.get(MPSDefs.DB_CONTACT_EMAIL));
				}
				bResult = true;
			} else {
				hmInput.remove(CommonDefs.CONTACT_EMAIL);
			}
		}

		if (hmInput.get(CommonDefs.CONTACT_EMAIL_STATUS) != null) {
			if( (!(hmInput.get(CommonDefs.CONTACT_EMAIL_STATUS).equals(hmDBInput.get(MPSDefs.DB_CONTACT_EMAIL_STATUS))))) {
				bResult = true;
			} else {
				hmInput.remove(CommonDefs.CONTACT_EMAIL_STATUS);
			}
		}

		if (hmInput.get(CommonDefs.ONLINE1_SECURITY_QUESTION) != null) {
			if (hmDBInput.get(MPSDefs.DB_SECURITY_QUESTION_1) != null) {
				if (!(hmDBInput.get(MPSDefs.DB_SECURITY_QUESTION_1)
						.equals(hmInput.get(CommonDefs.ONLINE1_SECURITY_QUESTION)))) {
					bResult = true;
				}
				else {
					hmInput.remove(CommonDefs.ONLINE1_SECURITY_QUESTION);
				}
			}
			else {
				bResult = true;
			}
		}
		if (hmInput.get(CommonDefs.ONLINE1_SECURITY_ANSWER) != null) {
			if (hmDBInput.get(MPSDefs.DB_SECURITY_ANSWER_1) != null) {
				if (!(hmDBInput.get(MPSDefs.DB_SECURITY_ANSWER_1)
						.equals(hmInput.get(CommonDefs.ONLINE1_SECURITY_ANSWER)))) {
					bResult = true;
				}
				else {
					hmInput.remove(CommonDefs.ONLINE1_SECURITY_ANSWER);
				}
			}
			else {
				bResult = true;
			}
		}
		if (hmInput.get(CommonDefs.ONLINE2_SECURITY_QUESTION) != null) {
			if (hmDBInput.get(MPSDefs.DB_SECURITY_QUESTION_2) != null) {
				if (!(hmDBInput.get(MPSDefs.DB_SECURITY_QUESTION_2)
						.equals(hmInput.get(CommonDefs.ONLINE2_SECURITY_QUESTION)))) {
					bResult = true;
				}
				else {
					hmInput.remove(CommonDefs.ONLINE2_SECURITY_QUESTION);
				}
			}
			else {
				bResult = true;
			}
		}
		if (hmInput.get(CommonDefs.ONLINE2_SECURITY_ANSWER) != null) {
			if (hmDBInput.get(MPSDefs.DB_SECURITY_ANSWER_2) != null) {
				if (!(hmDBInput.get(MPSDefs.DB_SECURITY_ANSWER_2)
						.equals(hmInput.get(CommonDefs.ONLINE2_SECURITY_ANSWER)))) {
					bResult = true;
				}
				else {
					hmInput.remove(CommonDefs.ONLINE2_SECURITY_ANSWER);
				}
			}
			else {
				bResult = true;
			}
		}

		if (hmInput.get("contactEmailRTValidFlag") != null && ! ((String)hmInput.get("contactEmailRTValidFlag")).isEmpty()) {
			bResult = true;
		}

		if (hmInput.get("accessIdRTValidFlag") != null  && ! ((String)hmInput.get("accessIdRTValidFlag")).isEmpty()) {
			bResult = true;
		}

		if (hmInput.get(ProfileOrchestrationConstants.CBR_NUMBER) != null) {
			if (hmDBInput.get(ProfileOrchestrationConstants.DB_CBR_NUMBER) != null) {
				if (!(hmDBInput.get(ProfileOrchestrationConstants.DB_CBR_NUMBER).equals(hmInput.get(ProfileOrchestrationConstants.CBR_NUMBER))) && !hmInput.get(ProfileOrchestrationConstants.CBR_NUMBER).toString().isEmpty()) {
					bResult = true;
				} else {
					hmInput.remove(ProfileOrchestrationConstants.CBR_NUMBER);
				}
			} else {
				bResult = true;
			}
		}

		if (hmInput.get(ProfileOrchestrationConstants.CONTACT_ADDRESS) != null) {
			if (hmDBInput.get(ProfileOrchestrationConstants.DB_CONTACT_ADDRESS) != null) {
				if (!(hmDBInput.get(ProfileOrchestrationConstants.DB_CONTACT_ADDRESS).equals(hmInput.get(ProfileOrchestrationConstants.CONTACT_ADDRESS))) && !hmInput.get(ProfileOrchestrationConstants.CONTACT_ADDRESS).toString().isEmpty()) {
					bResult = true;
				} else {
					hmInput.remove(ProfileOrchestrationConstants.CONTACT_ADDRESS);
				}
			} else {
				bResult = true;
			}
		}

		if (hmInput.get(CommonDefs.ZIP_CODE) != null) {
			if (hmDBInput.get(MPSDefs.DB_PROOFING_ZIP) != null) {
				if (!(hmDBInput.get(MPSDefs.DB_PROOFING_ZIP).equals(hmInput.get(CommonDefs.ZIP_CODE))) && !hmInput.get(CommonDefs.ZIP_CODE).toString().isEmpty()) {
					bResult = true;
				} else {
					hmInput.remove(CommonDefs.ZIP_CODE);
				}
			} else {
				bResult = true;
			}
		}

		if (hmInput.get(CommonDefs.IGP_NICK_NAME) != null) {
			if (hmDBInput.get(MPSDefs.DB_NICKNAME) != null) {
				if (!(hmDBInput.get(MPSDefs.DB_NICKNAME).equals(hmInput.get(CommonDefs.IGP_NICK_NAME))) && !hmInput.get(CommonDefs.IGP_NICK_NAME).toString().isEmpty()) {
					bResult = true;
				} else {
					hmInput.remove(CommonDefs.IGP_NICK_NAME);
				}
			} else {
				bResult = true;
			}
		}

		return bResult;
	}

	/**
	 * This method is responsible for encrypting sensitive user information using Voltage encryption.
	 * It takes a HashMap as input which contains the user information that needs to be encrypted.
	 * It calls the getEncryptedValues method of the ProofingEncryptionHelper class, passing the input HashMap to it.
	 * The getEncryptedValues method returns a HashMap with the encrypted values.
	 * If the getEncryptedValues method returns null, an error is logged and returned to the caller.
	 * If the getEncryptedValues method returns a HashMap with the encrypted values, these values are added to the input HashMap and a success message is returned.
	 *
	 * @param hmInput A HashMap containing the user information that needs to be encrypted. It should include necessary information such as date of birth, contact email, etc.
	 * @return A HashMap containing the result of the method. It includes the application status code and other information.
	 * @throws Exception If there is an error during the operation.
	 */
	public Map<String, Object> setVoltageEncryptedFields(Map<String, Object> hmInput) {
		String sMethodName = ".setVoltageEncryptedFields.";
		String stAppInfo;
		String stAppStatusCode;

		Map hmResult = oProofingEncryption.getEncryptedValues((HashMap) hmInput);

		logger.debug(SpiMarker.getInstance(),
				"UpdateUpUserHelper.setVoltageEncryptedFields.SVEF_101 : ResponseHash from ProofingEncryption_H.getEncryptedValues : {}",
				StructuredArguments.entries(hmResult));

		if (hmResult == null) {
			stAppInfo = "Null Response returned from ProofingEncryption_H.getEncryptedValues";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			logger.debug("{}{}SVEF_102 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

		if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
			stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
			hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
			logger.info("{}{}SVEF_103 : {}", sClassName, sMethodName, hmResult);
			return hmResult;

		}
		String stVencDateOfBirth = (String) hmResult.get(CommonDefs.VOLTAGE_DATE_OF_BIRTH);
		hmInput.put("VencDateOfBirth", stVencDateOfBirth);
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}

	private Map<String, Object> updateUserDB(Map<String, Object> hmInput, HashMap hmDBMemberInfo) {
		String sMethodName = ".updateUserDB.";
		String stAppInfo;
		Map<String, Object> hmResult = CommonUtil.getHashMap();
		HashMap<String, Object> hmUpdateMemberGroup = CommonUtil.getHashMap();
		String stDomain = (String) hmInput.get(CommonDefs.DOMAIN);
		String stHandle = (String) hmInput.get(CommonDefs.HANDLE);
		String stCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
		String sTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);
		String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
		String memberNum = null;
		String stAppStatusCode = null;

		hmUpdateMemberGroup.put(MPSDefs.DB_DOMAIN_NAME, stDomain);
		hmUpdateMemberGroup.put(MPSDefs.DB_PARENT_NAME, stHandle);
		hmUpdateMemberGroup.put(MPSDefs.DB_LAST_MODIFIED_BY, stCallingSystemId);

		try {
			ArrayList<String> alUpdateForSlidAndMembers = CommonUtil.parseToArray(propUpdateForSlidAndMembers,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			logger.info("{}{}UUDB_101 : Property propUpdateForSlidAndMembers : {}", sClassName, sMethodName,
					alUpdateForSlidAndMembers);

			HashMap hmUpdateUserInputToDBKeysMap = CommonUtil.parsePropertyToHash(propUpdateUser_Input_To_DB_Keys_Mapping);
			logger.info("{}{}UUDB_102 : Property UpdateUser_Input_To_DB_Keys_Mapping : {} ", sClassName , sMethodName,
					hmUpdateUserInputToDBKeysMap);

			HashMap hmMemberDataSlidAndMembers = CommonUtil.getHashMap();

			if (alUpdateForSlidAndMembers != null && !alUpdateForSlidAndMembers.isEmpty()) {
				for (int i = 0; i < alUpdateForSlidAndMembers.size(); i++) {
					String fieldName = (String) alUpdateForSlidAndMembers.get(i);

					if (hmInput.containsKey(fieldName)) {
						String fieldValue = (String) hmInput.get(fieldName);
						if (fieldValue != null && fieldValue.trim().length() > 0) {
							String stDBfieldName = (String) hmUpdateUserInputToDBKeysMap.get(fieldName);
							hmMemberDataSlidAndMembers.put(stDBfieldName, fieldValue);
						}
					}
				}
			}

			if (hmMemberDataSlidAndMembers != null && !hmMemberDataSlidAndMembers.isEmpty()) {
				hmMemberDataSlidAndMembers.put(MPSDefs.DB_SLID_MEMBER_NUM,
						hmDBMemberInfo.get(MPSDefs.DB_SLID_MEMBER_NUM));
				hmMemberDataSlidAndMembers.put(MPSDefs.DB_LAST_MODIFIED_BY, stCallingSystemId);

				logger.debug( "{}{}UUDB_103 : Calling to MPSDB_Update_H.updateMemberBySlidMemberNum with HashMap = {}", sClassName , sMethodName, hmMemberDataSlidAndMembers);

				hmResult = updateDBHelper.updateMemberBySlidMemberNum(hmMemberDataSlidAndMembers);

				logger.debug("{}{}UUDB_104 : Response Hash from MPSDB_Update_H.updateMemberBySlidMemberNum is = {}" , sClassName , sMethodName, hmResult);

				stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
				if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					isTransactionRollbackOnError = true;
					logger.info("{}{}UUDB_105 : Error returned from MPSDB_Update_H.updateMemberBySlidMemberNum :{} " , sClassName , sMethodName, hmResult);
					return hmResult;
				}
			}

			HashMap hmMemberDataSlidOnly = CommonUtil.getHashMap();
			ArrayList<String> alUpdateForSlidOnly = CommonUtil.parseToArray(propUpdateForSlidOnly,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			logger.info("{}{}UUDB_106 : Property propUpdateForSlidOnly : {}", sClassName, sMethodName,
					alUpdateForSlidOnly);

			if (alUpdateForSlidOnly != null && !alUpdateForSlidOnly.isEmpty()) {
				for (int i = 0; i < alUpdateForSlidOnly.size(); i++) {
					String fieldName = (String) alUpdateForSlidOnly.get(i);

		    			if (hmInput.containsKey(fieldName)) {
						String fieldValue = (String) hmInput.get(fieldName);
						if (fieldValue != null && fieldValue.trim().length() > 0) {
							String stDBfieldName = (String) hmUpdateUserInputToDBKeysMap.get(fieldName);
							hmMemberDataSlidOnly.put(stDBfieldName, fieldValue);
						}
					}
				}
			}

			if (hmMemberDataSlidOnly != null && !hmMemberDataSlidOnly.isEmpty()) {
				ArrayList alMemberData = CommonUtil.getArrayList();
				hmMemberDataSlidOnly.put(MPSDefs.DB_MEMBER_NUM, hmDBMemberInfo.get(CommonDefs.DB_MEMBER_NUM));
				hmMemberDataSlidOnly.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);
				hmMemberDataSlidOnly.put(MPSDefs.DB_LAST_MODIFIED_BY, stCallingSystemId);
				alMemberData.add(hmMemberDataSlidOnly);
				HashMap hmMPSInput = CommonUtil.getHashMap();
				hmMPSInput.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
				hmMPSInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
				hmMPSInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
				hmMPSInput.put(MPSDefs.DB_MEMBER_TABLE, alMemberData);

				logger.debug("{}{}UUDB_107 : Calling to MPSDB_TMEMBER_H.processData with HashMap = {}" , sClassName , sMethodName, hmMPSInput);

				hmResult = processData(hmMPSInput);

				logger.debug("{}{}UUDB_108 : Response Hash from MPSDB_TMEMBER_H.processData is = {}", sClassName , sMethodName, hmResult);

				stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
				if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					isTransactionRollbackOnError = true;
					logger.info("{}{}UUDB_109 : Error returned from MPSDB_TMEMBER_H.processData : {}", sClassName , sMethodName, hmResult);
					return hmResult;
				}
			}

			// hmInput contains fields present in updateContactInfo
			ArrayList<String> alUpdateContactInfoFields = CommonUtil.parseToArray(propUpdateContactInfoFields,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			logger.info("{}{}UUDB_110 : Property propUpdateContactInfoFields : {}", sClassName, sMethodName,
					alUpdateContactInfoFields);

			HashMap hmUpdate = CommonUtil.getHashMap();
			if (alUpdateContactInfoFields!= null && !alUpdateContactInfoFields.isEmpty()){
				for (int i = 0; i < alUpdateContactInfoFields.size(); i++) {
					String fieldName = (String) alUpdateContactInfoFields.get(i);
					if (hmInput.containsKey(fieldName)) {
						String fieldValue = (String) hmInput.get(fieldName);
						if (fieldValue != null && fieldValue.trim().length() > 0) {
							String stDBfieldName = (String) hmUpdateUserInputToDBKeysMap.get(fieldName);
							hmUpdate.put(stDBfieldName, fieldValue);
						}
					}
				}
			}

			logger.debug("{}{}UUDB_111: Fields to be updated :  hmUpdate = {}", sClassName , sMethodName, hmUpdate);

			if (hmUpdate != null && !hmUpdate.isEmpty()) {

				if(hmInput.get("contactEmailRTValidFlag") == null ) {
					hmUpdate.put("contact_email_rtv_date", "N");
				}
				hmUpdate.put(MPSDefs.DB_SLID_MEMBER_NUM, hmDBMemberInfo.get(MPSDefs.DB_SLID_MEMBER_NUM));
				hmUpdate.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);

				logger.debug("{}{}UUDB_112 : Calling to MPSDB_ContactInfo_H.updateContactInfo with HashMap = {}" , sClassName , sMethodName, hmUpdate);

				hmResult = updateDBHelper.updateContactInfo(hmUpdate);

				logger.debug("{}{}UUDB_113 : Response Hash from MPSDB_ContactInfo_H.updateContactInfo is = {} " , sClassName , sMethodName, hmResult);

				stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
				if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					isTransactionRollbackOnError = true;
					logger.info("{}{}UUDB_114 : Error returned from MPSDB_ContactInfo_H.updateContactInfo : {} " , sClassName , sMethodName, hmResult);
					return hmResult;
				}
			}

			memberNum = (String) hmResult.get(MPSDefs.DB_MEMBER_NUM);
			hmInput.put(MPSDefs.DB_MEMBER_NUM, memberNum);

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown while updating User in DB : " + hmResult;
			logger.info("{}{}UUDB_115 : {}", sClassName, sMethodName, stAppInfo);
		}

		return hmResult;
	}

	private Map<String, Object> updateMemberIdDB(Map<String, Object> hmInput, HashMap hmDBMemberInfo) {
		String sMethodName = ".updateMemberIdDB.";
		String stAppInfo;
		Map<String, Object> hmResult = CommonUtil.getHashMap();
		String stCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
		String sTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);
		String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
		String stAppStatusCode = null;

		try {
			HashMap hmUpdateUserInputToDBKeysMap = CommonUtil.parsePropertyToHash(propUpdateUser_Input_To_DB_Keys_Mapping);
			logger.info("{}{}UMDB_01 : Property UpdateUser_Input_To_DB_Keys_Mapping : {} ", sClassName , sMethodName,
					hmUpdateUserInputToDBKeysMap);

			HashMap hmMemberDataForMemberIdOnly = sharedUtilHelper.populateMemberDataForMemberIdOnly(hmInput,hmUpdateUserInputToDBKeysMap);


			if (hmMemberDataForMemberIdOnly != null && !hmMemberDataForMemberIdOnly.isEmpty()) {
				ArrayList alMemberData = CommonUtil.getArrayList();
				hmMemberDataForMemberIdOnly.put(MPSDefs.DB_MEMBER_NUM, hmDBMemberInfo.get(CommonDefs.DB_MEMBER_NUM));
				hmMemberDataForMemberIdOnly.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);
				hmMemberDataForMemberIdOnly.put(MPSDefs.DB_LAST_MODIFIED_BY, stCallingSystemId);
				alMemberData.add(hmMemberDataForMemberIdOnly);
				HashMap hmMPSInput = CommonUtil.getHashMap();
				hmMPSInput.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
				hmMPSInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
				hmMPSInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
				hmMPSInput.put(MPSDefs.DB_MEMBER_TABLE, alMemberData);

				logger.debug("{}{}UMDB_02 : Calling to MPSDB_TMEMBER_H.processData with HashMap = {}" , sClassName , sMethodName, hmMPSInput);

				hmResult = processData(hmMPSInput);

				logger.debug("{}{}UMDB_03 : Response Hash from MPSDB_TMEMBER_H.processData is = {}", sClassName , sMethodName, hmResult);

				stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
				if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					isTransactionRollbackOnError = true;
					logger.info("{}{}UMDB_04 : Error returned from MPSDB_TMEMBER_H.processData : {}", sClassName , sMethodName, hmResult);
					return hmResult;
				}
			} else if(hmMemberDataForMemberIdOnly == null || hmMemberDataForMemberIdOnly.isEmpty()) {
				stAppInfo = "Request fields and MPS data fields contain the same info. Hence no action taken";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
				logger.info("{}{}UMDB_05 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown while updating member in DB : " + hmResult;
			logger.info("{}{}UMDB_06 : {}", sClassName, sMethodName, stAppInfo);
		}

		return hmResult;
	}

	/**
	 * This method processes the input data for updating user information.
	 * It iterates through the list of member operations in the input HashMap and performs the corresponding operation for each member.
	 * Currently, only the update operation is supported.
	 * The method updates each member attribute by calling the updateMember method of the UpdateDBHelper class.
	 * If the update operation is successful, the method increments a counter for the number of rows updated.
	 * If the update operation fails, the method returns an error.
	 * At the end of the method, the number of rows updated is added to the result HashMap.
	 *
	 * @param hmInput A HashMap containing the input parameters for the method. It should include necessary information such as calling system ID, transaction name, last modified by, and a list of member operations.
	 * @return A HashMap containing the result of the method. It includes the application status code, application info (number of rows updated), and other information.
	 * @throws Exception If there is an error during the operation.
	 */
	public HashMap processData(HashMap hmInput) {
		String sMethodName = ".processData.";
		HashMap hmResult = null;
		String sAppStatusCode = null;
		logger.info("{}{}PD_101 : Input Hash is: {}", sClassName, sMethodName, hmInput);
		try {
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
			String sLastModifiedBy = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);
			ArrayList alMemberOperations = (ArrayList) hmInput.get(MPSDefs.DB_MEMBER_TABLE);

			// Iterate through member list to update each member attribute
			int rowsUpdated = 0;
			for (int i = 0; i < alMemberOperations.size(); i++) {
				HashMap hmMemberOperation = (HashMap) alMemberOperations.get(i);
				if (hmMemberOperation != null && !hmMemberOperation.isEmpty()) {
					if (sCallingSystemId != null && sCallingSystemId.length() > 0)
						hmMemberOperation.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);
					else if (sLastModifiedBy != null && sLastModifiedBy.length() > 0)
						hmMemberOperation.put(MPSDefs.DB_LAST_MODIFIED_BY, sLastModifiedBy);

					String sOperationType = (String) hmMemberOperation.get(MPSDefs.DB_OPERATION);
					// Only update operation is supported for June 2010
					if (sOperationType.equalsIgnoreCase(MPSDefs.DB_OPERATION_UPDATE)) {
						// 2016 SID44581
						if (sTransactionName != null && sTransactionName.length() > 0)
							hmMemberOperation.put(CommonDefs.TRANSACTION_NAME, sTransactionName);

						// Call local method to update one servicecontact at a time
						hmResult = updateDBHelper.updateMember(hmMemberOperation);
					}

					sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
					if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
						return hmResult;
					}
				} else {
					hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM,
							"member operation hash is empty in input");
					return hmResult;
				}

				rowsUpdated = rowsUpdated + 1;
			} // end of for loop

			hmResult.put(CommonDefs.COMMON_APP_INFO, "Number of rows updated := " + rowsUpdated);

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e);
			logger.error("{}{}PD_102 :  Error:: {}", sClassName, sMethodName, e.getMessage());

		} finally {
			logger.info("{}{}PD_104 : response: {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;
	}


}