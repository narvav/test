package com.att.idp.idgraphusermanagementms.helper.resetuserpassword;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.mpsys.common.utils.PropertyManager;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * G2LDAPHelper is a class that provides helper methods for LDAP operations.
 * It contains methods for converting MQ messages to LDAP, calling Dbus for G2 Queue, and checking if LDAP operations should be performed.
 * This class is annotated with @Component, meaning it is an object managed by the Spring framework.
 * It uses Autowired to inject an instance of LDAPValidator.
 * The class also contains several constants and instance variables.
 *
 * @author kg852c
 */
@Component
public class G2LDAPHelper {

	// private static final String moduleinfo = "CVS Info";
	private static final String CLASS_NAME = "G2LDAPHelper";
	private static final String SYNC_G2 ="SyncG2";
	@Autowired
	private LDAPValidator oLDAPValidator;

	/**
	 * This method is responsible for converting MQ messages to LDAP.
	 * It takes two HashMaps and a Logger as input.
	 * The first HashMap contains the input parameters, the second HashMap contains the member details from the database, and the Logger is used for logging.
	 * The method logs the start of the process and the input parameters.
	 * It checks various conditions such as the presence of certain keys in the HashMaps, the values of certain keys, etc.
	 * Based on these conditions, it decides whether to proceed with the LDAP operations or return a success message.
	 * If it decides to proceed with the LDAP operations, it calls the validate method of the LDAPValidator and the callDbusForG2Queue method.
	 * In case of any exception, it logs the error and returns an error HashMap.
	 * Finally, it logs the end of the process and the result, and returns the result HashMap.
	 *
	 * @param InpParam HashMap containing the input parameters.
	 * @param hmDBMember HashMap containing the member details from the database.
	 * @param log Logger used for logging.
	 * @return HashMap containing the result of the process.
	 */
	public HashMap mqToLdap(HashMap InpParam, HashMap hmDBMember, Logger log) {
		String sMethodName = ".mqToLdap.";
		HashMap hmResult = null;
		HashMap hmLDAPValidatorResp = null;
		int retCode = -1;
		String appInfo = null;
		String sAppStatusCode = null;

		log.info(CLASS_NAME + sMethodName + "TMS000 " + "Input Hash: " + InpParam);

		try {
			String stG2BlockDomains = null;
			String sG2LDAPRestrictedSor = null;
			String sNonLDAPServices = null;

			stG2BlockDomains = PropertyManager.getProperty(CommonDefs.MSConfig, MPSDefs.PROP_G2_BLOCK_DOMAINS);

			sG2LDAPRestrictedSor = PropertyManager.getProperty(CommonDefs.MSConfig,
					MPSDefs.PROP_G2_LDAP_RESTRICTED_SOR);

			sNonLDAPServices = PropertyManager.getProperty(CommonDefs.MSConfig, MPSDefs.PROP_NON_LDAP_SERVICES);

			if ((stG2BlockDomains != null && !stG2BlockDomains.isEmpty())
					&& (sG2LDAPRestrictedSor != null && !sG2LDAPRestrictedSor.isEmpty())
					&& (sNonLDAPServices != null && !sNonLDAPServices.isEmpty()))
				retCode = MPSDefs.MPS_SUCCESS_NUM;
			else
				retCode = MPSDefs.ERR_CONFIG_NUM;

			if (retCode != 0) {
				log.info(CLASS_NAME + sMethodName + "TMS_G2_1 " + "Config value is missing");
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, "Config value is missing");
				return hmResult;
			}

			if (doldap(log) == false) {
				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
				return hmResult;
			}

			String domain = (String) hmDBMember.get(MPSDefs.DB_DOMAIN_NAME);

			StringTokenizer stG2LDAPBlockDomains = new StringTokenizer(stG2BlockDomains, "|");

			ArrayList alG2LDAPBlockDomains = new ArrayList();
			while (stG2LDAPBlockDomains.hasMoreTokens())
				alG2LDAPBlockDomains.add(stG2LDAPBlockDomains.nextToken());

			if (domain != null && alG2LDAPBlockDomains.contains(domain)) {
				appInfo = "No need to PUT a message on G2 Queue as domain is one of :: " + alG2LDAPBlockDomains
						+ ". Returning SUCCESS";
				log.info(CLASS_NAME + sMethodName + "TMS_G2_4 " + appInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, appInfo);
				return hmResult;
			}

			String sorName = (String) hmDBMember.get(MPSDefs.DB_SOR_NAME);

			if (sorName != null) {

				ArrayList alG2LDAPRestrictedSor = null;

				if ((sG2LDAPRestrictedSor != null) && (sG2LDAPRestrictedSor.trim().length() > 0)) {
					StringTokenizer stG2LDAPRestrictedSorToken = new StringTokenizer(sG2LDAPRestrictedSor, "|");

					alG2LDAPRestrictedSor = new ArrayList();
					while (stG2LDAPRestrictedSorToken.hasMoreTokens())
						alG2LDAPRestrictedSor.add(stG2LDAPRestrictedSorToken.nextToken());
					log.info(CLASS_NAME + sMethodName + "TMS_G2_5 " + "G2 LDAP restricted SOR : "
							+ alG2LDAPRestrictedSor);
				}

				if (alG2LDAPRestrictedSor != null && alG2LDAPRestrictedSor.contains(sorName)) {
					log.info(CLASS_NAME + sMethodName + "TMS_G2_7 " + sorName
							+ " user should not go to LDAP....... Returning SUCCESS");

					hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
							sorName + " user should not go to LDAP....... Returning SUCCESS");
					return hmResult;
				}
			}

			String parent_child_ind = (String) hmDBMember.get(MPSDefs.DB_PARENT_CHILD_IND);

			if ((sorName != null && sorName.equals(MPSDefs.SOR_BLS))
					&& (parent_child_ind != null && parent_child_ind.equals(MPSDefs.MPS_CHILD))) {
				appInfo = "sor_name = " + sorName + " AND parent_child_ind = " + parent_child_ind
						+ ". No need to PUT a message on G2 Queue. Returning SUCCESS";
				log.info(CLASS_NAME + sMethodName + "TMS_G2_8 " + appInfo);

				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, appInfo);
				return hmResult;
			}

			String memberstate = (String) hmDBMember.get(MPSDefs.DB_MEMBER_STATE);

			if (memberstate != null) {
				if (memberstate.equals(MPSDefs.RESERVED_STATE)) {
					log.info(CLASS_NAME + sMethodName + "TMS_G2_9 "
							+ "RESERVED user should not go to LDAP....... Returning SUCCESS");
					hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
							"RESERVED user should not go to LDAP....... Returning SUCCESS");
					return hmResult;
				}
			}

			HashMap<String, Object> servicesHash = new HashMap<>();
			if (servicesHash != null) {
				servicesHash.put(MPSDefs.SERVICES, hmDBMember.get(MPSDefs.SERVICES));
				StringTokenizer strtoken = new StringTokenizer(sNonLDAPServices, ",");
				ArrayList nonLDAPServicesAL = new ArrayList();
				while (strtoken.hasMoreTokens())
					nonLDAPServicesAL.add(strtoken.nextToken());

				int cnt = 0;

				Iterator it1 = servicesHash.keySet().iterator();

				while (it1.hasNext()) {

					String keyName = (String) it1.next();

					if (!nonLDAPServicesAL.contains(keyName))
						break;
					else
						cnt++;
				}

				if (servicesHash.size() == cnt) {

					appInfo = "MPS DB services are Non LDAP services. " + "No need to call LDAP. Return Success";
					log.info(CLASS_NAME + sMethodName + "TMS_G2_11 " + appInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, appInfo);
					return hmResult;
				}
			} else {
				appInfo = "The services HashMap is null or empty. " + "No need to call LDAP. Return Success";
				log.info(CLASS_NAME + sMethodName + "TMS_G2_11.01 " + appInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, appInfo);
				return hmResult;
			}

			hmLDAPValidatorResp = oLDAPValidator.validate(InpParam, hmDBMember, log);

			sAppStatusCode = (String) hmLDAPValidatorResp.get(CErrorDefs.COMMON_APP_STATUS_CODE);

			if (null != sAppStatusCode && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
				log.info(CLASS_NAME + sMethodName + "TMS_G2_11.03 : " + "HashMap Returned from LDAPValidator.validate() : "
						+ hmLDAPValidatorResp);
				hmResult = hmLDAPValidatorResp;
				return hmResult;
			}
			
			hmResult = callDbusForG2Queue(hmLDAPValidatorResp, log);

			log.info(CLASS_NAME + sMethodName + "TMS_G2_999 " + "Response Hash from CallDbusForG2Queue: " + hmResult);

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.info(CLASS_NAME + sMethodName + "TMS_G2-1e : " + "Exception = " + e.getMessage());
		} finally {
			log.info(CLASS_NAME + sMethodName + "TMS999 : " + "Response Hash : " + hmResult);
		}
		return hmResult;
	}

	/**
	 * This method is responsible for calling Dbus for G2 Queue.
	 * It takes a HashMap and a Logger as input.
	 * The HashMap contains the input parameters for the Dbus call, and the Logger is used for logging.
	 * The method logs the start of the process and the input parameters.
	 * It checks various conditions such as the presence of certain keys in the HashMap, the values of certain keys, etc.
	 * Based on these conditions, it decides whether to proceed with the Dbus call or return a success message.
	 * If it decides to proceed with the Dbus call, it prepares the input for the Dbus call and makes the call.
	 * In case of any exception, it logs the error and returns an error HashMap.
	 * Finally, it logs the end of the process and the result, and returns the result HashMap.
	 *
	 * @param hmInputToDbus HashMap containing the input parameters for the Dbus call.
	 * @param log Logger used for logging.
	 * @return HashMap containing the result of the Dbus call.
	 */
	public HashMap callDbusForG2Queue(HashMap hmInputToDbus, Logger log) {
		String sMethodName = ".callDbusForG2Queue.";
		HashMap hmResponse = null;
		String stAppInfo = null;

		log.info(CLASS_NAME + sMethodName + "TMS400.1 : " + "InputHash to CallDbusForG2Queue" + hmInputToDbus);

		String stTransactionId = (String) hmInputToDbus.get(MPSDefs.MPSTRANSID);

		String stSyncG2 = (String) hmInputToDbus.get(SYNC_G2);

		if (!hmInputToDbus.containsKey(MPSDefs.G2_USERID) || !hmInputToDbus.containsKey(MPSDefs.G2_DOMAIN)) {
			stAppInfo = "guserid or gdomain is missing in InputToDbus hash";

			log.info(CLASS_NAME + sMethodName + "TMS400.2 : " + stAppInfo);

			hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			return hmResponse;
		}

		if ((hmInputToDbus.containsKey(MPSDefs.G2_ACCESSENABLED)) && (!hmInputToDbus.containsKey(MPSDefs.DELETING))) {
			if (hmInputToDbus.get(MPSDefs.G2_ACCESSENABLED).equals(CommonDefs.DEFAULT_TRUE)
					&& (!hmInputToDbus.containsKey(MPSDefs.G2_CLASSOFSERVICE))) {
				stAppInfo = "gclassofservice is not present in InputToDbus hash";
				log.info(CLASS_NAME + sMethodName + "TMS400.3 : " + stAppInfo);

				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResponse;

			}
		}

		// calculating the event and subevent name
		String stDbusEventName = null;
		String stDbusSubEventName = null;
		String stDBSor = (String) hmInputToDbus.get(MPSDefs.G2_ASSOCIATEDDOMAIN);
		String stDBDslamType = (String) hmInputToDbus.get(MPSDefs.DB_DSLAM_TYPE);
		String stParentChildInd = (String) hmInputToDbus.get(MPSDefs.DB_PARENT_CHILD_IND);

		if (stSyncG2 != null && stSyncG2.equalsIgnoreCase("Sync")) {

			if ((stDBSor != null && stDBSor.equals(MPSDefs.SOR_LS))
					|| (stDBDslamType != null && stDBDslamType.equals(MPSDefs.IP)))// if sor_name is LS
			{
				if (hmInputToDbus != null && hmInputToDbus.containsKey(MPSDefs.DELETING)) {
					stDbusEventName = "G2LSdeluserEvent";
				} else {
					stDbusEventName = "G2LSmoduserEvent";
				}
			} else {
				if (hmInputToDbus != null && hmInputToDbus.containsKey(MPSDefs.DELETING)) {
					stDbusEventName = "G2DSLdeluserEvent";
				} else {
					stDbusEventName = "G2DSLmoduserEvent";
				}
			}

			hmInputToDbus.put(CommonDefs.DBUS_DICTIONARY_NAME, "g2Dict");
		} else {

			if (hmInputToDbus != null && hmInputToDbus.containsKey(MPSDefs.DELETING)) {
				stDbusEventName = "DeleteMember";
			} else {
				stDbusEventName = "AddUpdateMember";
			}

			if ((stDBSor != null && stDBSor.equals(MPSDefs.SOR_LS))
					|| (stDBDslamType != null && stDBDslamType.equals(MPSDefs.IP)))// if sor_name is LS
			{
				if (stParentChildInd != null && stParentChildInd.equalsIgnoreCase(MPSDefs.MPS_PARENT)) {
					stDbusSubEventName = "LSLDAP";
				} else {
					stDbusSubEventName = "LSSUBLDAP";
				}
			} else if (stDBSor != null && stDBSor.equals(MPSDefs.SOR_BLS)) // if sor_name is BLS
			{
				stDbusSubEventName = "BLSLDAP";
			} else {
				stDbusSubEventName = "LDAP";
			}

			hmInputToDbus.put(CommonDefs.DBUS_DICTIONARY_NAME, "g2Dict");
		}

		log.info(CLASS_NAME + sMethodName + "TMS400.4 : " + "Dbus event name::" + stDbusEventName
				+ ":: and dbus subEvent name::" + stDbusSubEventName);

		if (hmInputToDbus.containsKey(MPSDefs.DB_DSLAM_TYPE)) {
			hmInputToDbus.remove(MPSDefs.DB_DSLAM_TYPE);
		}

		if (hmInputToDbus.containsKey(MPSDefs.DB_PARENT_CHILD_IND)) {
			hmInputToDbus.remove(MPSDefs.DB_PARENT_CHILD_IND);
		}

		if (hmInputToDbus.containsKey(SYNC_G2)) {
			hmInputToDbus.remove(SYNC_G2);
		}

		hmInputToDbus.put(CommonDefs.EVENTNAME, stDbusEventName);

		if (stDbusSubEventName != null && stDbusSubEventName.trim().length() > 0) {
			hmInputToDbus.put(CommonDefs.SUBEVENT, stDbusSubEventName);
		}

		hmInputToDbus.put(CommonDefs.TRANSACTION_ID, stTransactionId);
		log.info(CLASS_NAME + sMethodName + "TMS400 : " + "DBUS InputHash " + hmInputToDbus);
		
		hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS);
		hmResponse.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, hmInputToDbus);

		return hmResponse;
	}

	/**
	 * 
	 * @param log
	 * @return boolean
	 */
	private boolean doldap(Logger log) {
		String sMethodName = ".doldap.";

		try {
			String ldapmode = PropertyManager.getProperty(CommonDefs.MSConfig, MPSDefs.SKIPLDAP);

			if (ldapmode != null && ldapmode.length() > 0) {
				if ((ldapmode.startsWith("Y".toLowerCase())) || (ldapmode.startsWith("Y"))) {
					log.info(CLASS_NAME + sMethodName + "TMS19 : " + "Skipping ldap update.");
					return false;
				}
			}
		} catch (Exception e) {
			HashMap hmResponse = CommonErrorMap.makeExceptionMap(e);
			log.info(CLASS_NAME + sMethodName + "LdapHelper-E3 : " + "Exception from doldap() = " + e.getMessage());
			log.info(CLASS_NAME + sMethodName + "LdapHelper-E4 : " + "Exception Hash = " + hmResponse);
		}
		return true;
	}
}
