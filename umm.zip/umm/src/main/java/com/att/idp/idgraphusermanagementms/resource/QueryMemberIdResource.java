package com.att.idp.idgraphusermanagementms.resource;

import com.att.idp.idgraphusermanagementms.resource.response.MemberIdResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Tag(name = "memberid")
@Path("/memberid")
@Produces({ MediaType.APPLICATION_JSON })
public interface QueryMemberIdResource {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(summary = "MemberId", description =  "Retrieve the primary and secondary memberIds details",parameters = {
            @Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = MemberIdResponse.class))),

            @ApiResponse(responseCode = "400", description =  "Bad Request"),

            @ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
    Response queryMemberId(@Context HttpHeaders headers) throws Exception;
}
