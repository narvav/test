package com.att.idp.idgraphusermanagementms.service;

import jakarta.ws.rs.core.MultivaluedMap;

import com.att.idp.idgraphusermanagementms.resource.request.UpdateUserFraudRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdateUserFraudResponse;

/**
 * This interface defines the contract for the UpdateUserFraudService in the system.
 * It contains a single method updateUserFraud which takes an UpdateUserFraudRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return an UpdateUserFraudResponse object.
 *
 * The UpdateUserFraudRequest object encapsulates the details of the user fraud update operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
public interface UpdateUserFraudService {
	
	/**
	 * This method is part of the UpdateUserFraudService interface.
	 * It defines the contract for updating a user's fraud status in the system.
	 *
	 * @param updateFraudRequest An object encapsulating the details of the user fraud update operation to be performed.
	 * @param requestHeader A MultivaluedMap containing the request headers which may include additional information required for processing the request.
	 * @return An UpdateUserFraudResponse object representing the response from the system after updating the user's fraud status.
	 */
	UpdateUserFraudResponse updateUserFraud(UpdateUserFraudRequest updateFraudRequest, MultivaluedMap<String, String> requestHeader);

}
