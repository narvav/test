package com.att.idp.idgraphusermanagementms.resource.response;

import com.att.idp.core.exception.ServiceError;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "BaseResponse")
public abstract class BaseResponse {

	protected BaseResponse() {

	}
	@JsonIgnore
	private String transactionName;
	private String appStatusMsg;
	private String appStatusCode;
	private String appInfo;
	@JsonIgnore
	private String appCategoryCode;
	@JsonProperty("error")
	private ServiceError errors;
	@JsonProperty("idp-trace-id")
	private String idpTraceId;
}