package com.att.idp.idgraphusermanagementms.resource.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class represents a suggested handle in the system.
 * It contains a field for suggest which represents the suggested handle.
 *
 * The class uses Lombok's @Data annotation to generate getter and setter methods for the suggest field.
 * It also overrides the toString method to return a string representation of the object.
 *
 * The class is annotated with @JsonIgnoreProperties, @JsonInclude, and @ApiModel from various libraries such as Jackson and Swagger.
 * The @JsonIgnoreProperties and @JsonInclude annotations from Jackson library control the JSON serialization/deserialization behavior.
 * The @ApiModel annotation from Swagger library provides metadata for the model definition in Swagger UI.
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "SuggestHandle")
public class SuggestHandle {

	private String suggest;

	@Override
	public String toString() {
		return "{suggest=" + suggest + "}";
	}
}