package com.att.idp.idgraphusermanagementms.config;

import com.att.mpsys.common.helpers.BadWordHelper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;

@Configuration
public class BeanConfiguration {

    @Bean
    @Qualifier("badWordHelper")
    public BadWordHelper getBadWordHelper(){
        return new BadWordHelper();
    }

}
