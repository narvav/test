package com.att.idp.idgraphusermanagementms.request.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import jakarta.ws.rs.core.HttpHeaders;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.resource.request.UserCredentials;
import com.att.idp.idgraphusermanagementms.resource.request.ValidateUserCredentialsRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ValidateUserCredentialsResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;

/**
 * This class, ValidateUserCredentialsRequestValidator, is responsible for validating the ValidateUserCredentialsRequest.
 * It checks for the presence and validity of required fields in the request, and returns a ValidateUserCredentialsResponse accordingly.
 * It is annotated with @Component, @Configuration, and @PropertySource to indicate that it's a Spring Bean,
 * to allow it to access configuration properties, and to specify the location of the properties file respectively.
 *
 * The class contains several methods, including:
 * - validateUserCredentialsReqValidator: the main method that orchestrates the validation process.
 * - validateUserCredentialsReqtInputValidator: a method that validates the input fields in the request.
 * - getInvalidField: a method that checks for invalid fields in the UserCredentials.
 * - validateUserCredentialsResponse: a helper method that generates a response based on the application status code, application info, and trace ID.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class ValidateUserCredentialsRequestValidator {

	private static final Logger logger = LoggerFactory.getLogger(ValidateUserCredentialsRequestValidator.class);
	
	private String sClassName = "ValidateUserCredentialsRequestValidator";
	
	@Value("${ValidateUserCredentialsValidCallingSystemIds}")
	private String validateUserCredentialsValidCallingSystemIds;
	
	@Value("${ValidateCredentialsValidSlidUserCredentials}")
	private String validateCredentialsValidSlidUserCredentials;
	
	@Value("${ValidateCredentialsValidMemberUserCredentials}")
	private String validateCredentialsValidMemberUserCredentials;
	
	/**
	 * This method is responsible for validating the ValidateUserCredentialsRequest.
	 * It takes HttpHeaders and ValidateUserCredentialsRequest as parameters.
	 * HttpHeaders contains the request headers which may include additional information required for processing the request.
	 * ValidateUserCredentialsRequest encapsulates the details of the validate user credentials operation to be performed.
	 *
	 * The method performs various checks and validations on the input parameters and returns a ValidateUserCredentialsResponse object.
	 * The ValidateUserCredentialsResponse object encapsulates the result of the validate user credentials operation.
	 *
	 * @param requestHeader The HttpHeaders containing the request headers.
	 * @param validateUserCredentialsRequest The ValidateUserCredentialsRequest containing the details of the validate user credentials operation.
	 * @return ValidateUserCredentialsResponse The response of the validate user credentials operation.
	 * @author pb6583_ATT
	 */
	public ValidateUserCredentialsResponse validateUserCredentialsReqValidator(HttpHeaders requestHeader, ValidateUserCredentialsRequest validateUserCredentialsRequest) {
			
		ValidateUserCredentialsResponse validateUserCredentialsResponse = null;

		String stAppInfo = null;
		String sMethodName = ".validateUserCredentialsReqValidator";
		String stIdpTraceId = null;
		String stXAttClientId = null;
		
		stIdpTraceId = CommonUtil.getTraceId(requestHeader);

		if (stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
			stAppInfo = "Missing or Invalid IdpTraceId";
			return validateUserCredentialsResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (validateUserCredentialsRequest == null) {
			stAppInfo = "Input Request Parameter is NULL / Empty.";
			logger.info(SpiMarker.getInstance(),"{}{}VCRV_01 :: {}", sClassName, sMethodName, stAppInfo);
			return validateUserCredentialsResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		
		validateUserCredentialsRequest.setIdpTraceId(stIdpTraceId);
			
		if (requestHeader.getHeaderString("X-ATT-ClientId") != null) {
			stXAttClientId = requestHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
			logger.info(SpiMarker.getInstance(), "{}{}VCRV_1.4 : Setting callingSystemId: {}", sClassName, sMethodName,
					stXAttClientId);
			validateUserCredentialsRequest.setCallingSystemId(stXAttClientId);
		} else {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			logger.info(SpiMarker.getInstance(), "{}{}VCRV_1.5 :: {}", sClassName, sMethodName, stAppInfo);
			return validateUserCredentialsResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		
		try {
			validateUserCredentialsResponse = validateUserCredentialsReqtInputValidator(validateUserCredentialsRequest);
			if (validateUserCredentialsResponse != null) {
				logger.info(SpiMarker.getInstance(),"{}{}VCRV_02 Response from validateCredentialsRequestInputValidator : {}", sClassName, sMethodName,
						validateUserCredentialsResponse);
				return validateUserCredentialsResponse;
			} else {
				logger.debug("{}{}VCRV_03 Success Response from validateCredentialsRequestInputValidator ", sClassName,
						sMethodName);
			}
			stAppInfo = "Input Validation Successful";
			logger.info(SpiMarker.getInstance(),"{}{}VCRV_06 : {}", sClassName, sMethodName, stAppInfo);
		} catch (Exception e) {
			stAppInfo = "Exception thrown in ValidateCredentialsRequestValidator.validateCredentialsReqValidator : " + e.getMessage();
			logger.info(SpiMarker.getInstance(),"Exception in validateCredentialsReqValidator: {}", stAppInfo);
			return validateUserCredentialsResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo, stIdpTraceId);
		}		
		return validateUserCredentialsResponse;
	}
	
	/**
	 * This method is part of the ValidateUserCredentialsRequestValidator class.
	 * It is responsible for validating the ValidateUserCredentialsRequest.
	 * The method takes a ValidateUserCredentialsRequest as input.
	 * The ValidateUserCredentialsRequest encapsulates the details of the validate user credentials operation to be performed.
	 * The method performs various checks and validations on the input parameters and returns a ValidateUserCredentialsResponse object.
	 * The ValidateUserCredentialsResponse object encapsulates the result of the validate user credentials operation.
	 * The method checks for the presence and validity of required fields in the request, and returns a ValidateUserCredentialsResponse accordingly.
	 *
	 * @param validateUserCredentialsRequest The ValidateUserCredentialsRequest containing the details of the validate user credentials operation.
	 * @return ValidateUserCredentialsResponse The response of the validate user credentials operation.
	 */
	@SuppressWarnings("rawtypes")
	public ValidateUserCredentialsResponse validateUserCredentialsReqtInputValidator(ValidateUserCredentialsRequest validateUserCredentialsRequest) {
		
		String sMethodName = ".validateUserCredentialsReqtInputValidator";
		
		ValidateUserCredentialsResponse validateUserCredentialsResponse = null;
		String sAppInfo = null;
		ArrayList alValidSLIDCredentials = null;
		ArrayList alValidMemberCredentials = null;
		ArrayList alAccountValidFields = null;
	
		Optional.ofNullable(validateUserCredentialsRequest.getCallingSystemId()).ifPresent(x -> validateUserCredentialsRequest.setCallingSystemId(x.trim().toUpperCase()));
		Optional.ofNullable(validateUserCredentialsRequest.getHandle()).ifPresent(x -> validateUserCredentialsRequest.setHandle(x.trim().toLowerCase()));
		Optional.ofNullable(validateUserCredentialsRequest.getAgentId()).ifPresent(x -> validateUserCredentialsRequest.setAgentId(x.trim().toLowerCase()));
		Optional.ofNullable(validateUserCredentialsRequest.getIsExternalCall()).ifPresent(x -> validateUserCredentialsRequest.setIsExternalCall(x.trim().toUpperCase()));
		Optional.ofNullable(validateUserCredentialsRequest.getReturnOnlineSecurityQuestions()).ifPresent(x -> validateUserCredentialsRequest.setReturnOnlineSecurityQuestions(x.trim().toUpperCase()));
		Optional.ofNullable(validateUserCredentialsRequest.getDomain()).ifPresent(x -> validateUserCredentialsRequest.setDomain(x.trim().toLowerCase()));
		
		String sIdpTraceId = validateUserCredentialsRequest.getIdpTraceId();
		String sIsExternalCall = validateUserCredentialsRequest.getIsExternalCall();
		String sHandle = validateUserCredentialsRequest.getHandle();
		String sDomain = validateUserCredentialsRequest.getDomain();
		String sCallingSystemId = validateUserCredentialsRequest.getCallingSystemId();
		String sReturnOnlineSecurityQuestions = validateUserCredentialsRequest.getReturnOnlineSecurityQuestions();

		//checking Invalid attributes passed in Request
		Map<String,Object> allUnknownAttributes = new HashMap<>(validateUserCredentialsRequest.unknownAttributes);

		if(validateUserCredentialsRequest.getUserCredentials() != null) {
			allUnknownAttributes.putAll(validateUserCredentialsRequest.getUserCredentials().getUnknownAttributes());
		}
		if (!allUnknownAttributes.isEmpty()) {
			sAppInfo = "Invalid Attributes passed in validateUserCredentialsRequest : " + allUnknownAttributes;
			return validateUserCredentialsResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
		}

		if ((sIsExternalCall != null && !sIsExternalCall.isEmpty())) {
			if (!(sIsExternalCall.equalsIgnoreCase(CommonDefs.IND_Y) || sIsExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
				sAppInfo = "IsExternalCall must be one of Y or N";
				return validateUserCredentialsResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
			} 
		} else {
			sIsExternalCall = CommonDefs.IND_Y;
			validateUserCredentialsRequest.setIsExternalCall(sIsExternalCall);
		}

		if (sReturnOnlineSecurityQuestions != null) {
			if (sReturnOnlineSecurityQuestions.isEmpty() || sReturnOnlineSecurityQuestions.trim().isEmpty() || !(sReturnOnlineSecurityQuestions.equalsIgnoreCase(CommonDefs.IND_Y) || sReturnOnlineSecurityQuestions.equalsIgnoreCase(CommonDefs.IND_N))) {
				sAppInfo = "ReturnOnlineSecurityQuestions must be one of Y or N";
				return validateUserCredentialsResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
			}
		}

		if (validateUserCredentialsRequest.getUserCredentials() == null) {
			sAppInfo = "UserCredentials is  null or empty";
			logger.info(SpiMarker.getInstance(),"{}{}VCRV_2.4 : {}", sClassName, sMethodName, sAppInfo);
			return validateUserCredentialsResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
		}else if((validateUserCredentialsRequest.getUserCredentials().getBillingZip() == null ||
				validateUserCredentialsRequest.getUserCredentials().getBillingZip().isEmpty()) &&
				(validateUserCredentialsRequest.getUserCredentials().getProofZip()== null ||
						validateUserCredentialsRequest.getUserCredentials().getProofZip().isEmpty()) &&
				(validateUserCredentialsRequest.getUserCredentials().getDateOfBirth() == null ||
						validateUserCredentialsRequest.getUserCredentials().getDateOfBirth().isEmpty()) &&
				(validateUserCredentialsRequest.getUserCredentials().getLastFourSSN() == null ||
						validateUserCredentialsRequest.getUserCredentials().getLastFourSSN().isEmpty()) &&
				(validateUserCredentialsRequest.getUserCredentials().getContactEmail() == null ||
						validateUserCredentialsRequest.getUserCredentials().getContactEmail().isEmpty()) &&
				(validateUserCredentialsRequest.getUserCredentials().getLastName() == null ||
						validateUserCredentialsRequest.getUserCredentials().getLastName().isEmpty())) {
			sAppInfo = "UserCredentials is  null or empty";
			logger.info(SpiMarker.getInstance(),"{}{}VCRV_2.4.1 : {}", sClassName, sMethodName, sAppInfo);
			return validateUserCredentialsResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
		}
		
		if ((sHandle == null || sHandle.isEmpty()) || (sDomain == null || sDomain.isEmpty())) {//need to remove
			 
			sAppInfo = "UserId / Domain is null / empty";
			logger.info("{}{}VUCH_02.3.0 : {}", sClassName, sMethodName, sAppInfo);
			return validateUserCredentialsResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
		}
		
		if (validateUserCredentialsValidCallingSystemIds != null && !validateUserCredentialsValidCallingSystemIds.isEmpty()) {
			alAccountValidFields = CommonUtil.parseToArray(validateUserCredentialsValidCallingSystemIds, CommonDefs.VALUE_SEPARATOR_CHAR);
		} else {
			sAppInfo = "ValidateCredentials_ValidCallingSystemIds Property value is null or empty";
			logger.info("{}{}VUCH_02.3.1 : {}", sClassName, sMethodName, StringUtils.normalizeSpace(sAppInfo));
			return validateUserCredentialsResponse(CErrorDefs.ERR_CONFIG_NUM, sAppInfo, sIdpTraceId);
		}
		
		if (!alAccountValidFields.contains(sCallingSystemId) && CommonDefs.IND_Y.equalsIgnoreCase(sIsExternalCall)) {
			sAppInfo = "Transaction is not allowed for CallingSystemId : " + sCallingSystemId;
			logger.info("{}{}VUCH_02.3.2 : {}", sClassName, sMethodName, StringUtils.normalizeSpace(sAppInfo));
			return validateUserCredentialsResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, StringUtils.normalizeSpace(sIdpTraceId));
		}
		
		if (CommonDefs.SLID_DUM.equalsIgnoreCase(sDomain)) {

			if (validateCredentialsValidSlidUserCredentials != null && !validateCredentialsValidSlidUserCredentials.isEmpty()) {
				alValidSLIDCredentials = CommonUtil.parseToArray(validateCredentialsValidSlidUserCredentials, CommonDefs.VALUE_SEPARATOR_CHAR);
			} else {
				sAppInfo = "ValidateCredentialsValidSlidUserCredentials property value is null or empty";
				logger.info("{}{}VUCH_02.3.3 : {}", sClassName, sMethodName, sAppInfo);
				return validateUserCredentialsResponse(CErrorDefs.ERR_CONFIG_NUM, sAppInfo, sIdpTraceId);
			}

			String invalidField = getInvalidField(validateUserCredentialsRequest.getUserCredentials(), alValidSLIDCredentials);
			if (invalidField != null) {
				sAppInfo = invalidField + " is not valid userCredential for accessId";
				logger.info("{}{}VUCH_02.3.4 : {}", sClassName, sMethodName, sAppInfo);
				return validateUserCredentialsResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
			}

		} else {

			if (validateCredentialsValidMemberUserCredentials != null && !validateCredentialsValidMemberUserCredentials.isEmpty()) {
				alValidMemberCredentials = CommonUtil.parseToArray(validateCredentialsValidMemberUserCredentials, CommonDefs.VALUE_SEPARATOR_CHAR);
			} else {
				sAppInfo = "ValidateCredentialsValidMemberUserCredentials property value is null or empty";
				logger.info("{}{}VUCH_02.3.5 : {}", sClassName, sMethodName, sAppInfo);
				return validateUserCredentialsResponse(CErrorDefs.ERR_CONFIG_NUM, sAppInfo, sIdpTraceId);
			}

			String invalidField = getInvalidField(validateUserCredentialsRequest.getUserCredentials(), alValidMemberCredentials);
			if (invalidField != null) {
				sAppInfo = invalidField + " is not valid userCredential for memberId";
				logger.info("{}{}VUCH_02.3.6 : {}", sClassName, sMethodName, sAppInfo);
				return validateUserCredentialsResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
			}
		}
		return validateUserCredentialsResponse;
	}
	
	@SuppressWarnings("rawtypes")
	private String getInvalidField(UserCredentials userCredentials, ArrayList fields) {
		
		String invalidField = null;
		if(!fields.contains(CommonDefs.BILLING_ZIP)&& userCredentials.getBillingZip() != null) invalidField = CommonDefs.BILLING_ZIP;
		if(!fields.contains(CommonDefs.CONTACT_EMAIL)&& userCredentials.getContactEmail() != null) invalidField = CommonDefs.CONTACT_EMAIL;
		if(!fields.contains(CommonDefs.DATE_OF_BIRTH)&& userCredentials.getDateOfBirth() != null) invalidField = CommonDefs.DATE_OF_BIRTH;
		if(!fields.contains(CommonDefs.LAST_FOUR_SSN)&& userCredentials.getLastFourSSN() != null) invalidField = CommonDefs.LAST_FOUR_SSN;
		if(!fields.contains(CommonDefs.LAST_NAME)&& userCredentials.getLastName() != null) invalidField = CommonDefs.LAST_NAME;
		if(!fields.contains(CommonDefs.PROOF_ZIP)&& userCredentials.getProofZip() != null) invalidField = CommonDefs.PROOF_ZIP;
		return invalidField;
	}
	
	private ValidateUserCredentialsResponse validateUserCredentialsResponse(int appStatusCode, String stAppInfo, String stIdpTraceId) {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		return CommonUtilHelper.generateValidateUserCredentialsResponse(hmResponse);
	}
}