package com.att.idp.idgraphusermanagementms.resource.request;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.HashMap;
import java.util.Map;

/**
 * This class represents a request to update user password in the system.
 * It contains fields for transactionName, callingSystemId, idpTraceId, domain, handle (userId), returnOnlineSecurityQuestions, agentId, isExternalCall, userCredentials, and a map for unknownAttributes.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 * It also overrides the toString method to return a JSON-style string representation of the object.
 *
 */
@Data
@Schema(name = "UpdateUserPasswordRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdateUserPasswordRequest {

	private final String transactionName = "UpdateUserPassword";

	@Schema(name = "idpTraceId")
	private String idpTraceId;

	private String callingSystemId;
	private String domain;

	@NotNull(message = "userId is required in input request.|UpdateUserPassword")
	@Size(min = 1, max = 127, message =  "userId length is invalid|UpdateUserPassword")
	@JsonProperty("userId")
	@Schema(name = "userId")
	private String handle;

	//@NotNull(message = "oldPassword is required in input request.|UpdateUserPassword")
	@Size(min = 1, max = 24, message =  "oldPassword length is invalid|UpdateUserPassword")
	@Schema(name = "oldPassword")
	private String oldPassword;

	@NotNull(message = "newPassword is required in input request.|UpdateUserPassword")
	@Size(min = 1, max = 24, message =  "newPassword length is invalid|UpdateUserPassword")
	@Schema(name = "newPassword")
	private String newPassword;

	@Schema(name = "agentId")
	@Size(min=1, max=20,message="agentId length is invalid|UpdateUserPassword")
	private String agentId;

	@Schema(name = "isExternalCall")
	@Size(min=1,max=1,message="isExternalCall value can only be Y or N|UpdateUserPassword")
	private String isExternalCall;

	@Schema(name = "isUpdateSilent ")
	@Size(min = 1, max = 1, message =  "isUpdateSilent value can only be Y or N|UpdateUserPassword")
	private String isUpdateSilent ;

	@Valid
	@Schema(name = "deliveryContactEmailAddress")
	@Size(min = 1, max = 200, message =  "deliveryContactEmailAddress length is invalid|UpdateUserPassword")
	private String deliveryContactEmailAddress;
	/**
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
	 * @return Map<String,Object> The map of unknown attributes.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();

}