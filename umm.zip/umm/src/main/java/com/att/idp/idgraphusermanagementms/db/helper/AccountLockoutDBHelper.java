package com.att.idp.idgraphusermanagementms.db.helper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.idp.idgraphusermanagementms.utils.DateUtil;
import net.logstash.logback.argument.StructuredArguments;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This class is a helper for managing account lockouts in the database.
 * It contains methods for getting account lockout information, processing data, adding, updating, and deleting account lockouts.
 * The class uses the JdbcTemplate from Spring Framework for executing SQL queries.
 * It also uses various constants and definitions from the CommonDefs, MPSDefs, and CErrorDefs classes.
 * The class is annotated with @Component, meaning it is a Spring Bean and can be autowired into other classes.
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
@Component
public class AccountLockoutDBHelper {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	private static final String CLASS_NAME = "AccountLockoutDBHelper";
	private static String dateFormat = "MMDDYYYY HH24:mi:ss";
	private static final String LOG_INFO_QUERY999 = "{}{}QUERY999 : Total time taken to execute query = {} milliseconds";
	private static final String LOG_INFO_DBTOOLS_01 = "{}{}DBTOOLS_01 : Input Hash : {}";
	private static final String APP_INFO = "account_id,Identification_id and/or lockout_id is null or empty in input";
	private static final String INSERT_ACCOUNT_LOCKOUT_SQL = "INSERT INTO ACCOUNTLOCKOUT ("
			+ " ACCOUNT_ID, LOCKOUT_ID, SET_NUMBER, FAILED_AUTH_COUNT, LOCKOUT_EXPIRATION, "
			+ " LAST_FAILED_AUTH, LAST_MODIFIED_BY,IDENTIFICATION_TYPE) " + " VALUES (?, ?, ?, ?, ?, ?, ?,?)";

	private static final String DELETE_ACCOUNT_LOCKOUT_SQL = "DELETE FROM ACCOUNTLOCKOUT where ACCOUNT_ID = ?"
			+ " AND LOCKOUT_ID = ? AND IDENTIFICATION_TYPE = ?";

	private static String queryAccountLockout = "SELECT accloc.IDENTIFICATION_TYPE,accloc.ACCOUNT_ID, accloc.lockout_id, lo.lockout_name, accloc.set_number,"
			+ " accloc.failed_auth_count, TO_CHAR(accloc.lockout_expiration, '" + dateFormat
			+ "') AS lockout_expiration, TO_CHAR(accloc.last_failed_auth, '" + dateFormat
			+ "') AS last_failed_auth, TO_CHAR(accloc.create_date, '" + dateFormat
			+ "') AS create_date, TO_CHAR(accloc.last_modified, '" + dateFormat
			+ "') AS last_modified, accloc.last_modified_by " + " FROM accountlockout accloc, lockout lo "
			+ " WHERE accloc.lockout_id = lo.lockout_id (+) " + " AND accloc.IDENTIFICATION_TYPE = ?"
			+ " AND accloc.ACCOUNT_ID = ?";

	/**
	 * This method retrieves account lockout information from the database.
	 * It takes in a HashMap and a Logger as parameters.
	 * The HashMap contains the account ID and identification type.
	 * The method uses these details to query the ACCOUNTLOCKOUT table in the database and retrieve the account lockout information.
	 * The method returns a HashMap containing the account lockout information.
	 * If the account lockout information is successfully retrieved, the HashMap contains the account lockout information.
	 * If an exception occurs during the retrieval, the method logs the exception using the provided Logger and returns a HashMap containing error details.
	 *
	 * @param inputParamHs The HashMap containing the account ID and identification type.
	 * @param logger The Logger to be used for logging any exceptions.
	 * @return HashMap The result of the retrieval. Contains error details if the retrieval fails, or the account lockout information if the retrieval is successful.
	 */
	public HashMap getAccountLockedInfo(HashMap inputParamHs, Logger logger) {
		String sMethodName = ".getAccountLockedInfo.";

		String stAccountId = null;
		String stIdentificationType = null;
		String sAppInfo = null;
		List<Object> objectList = new ArrayList<Object>();
		List alQueryResponse = new ArrayList<Object>();

		HashMap hmResult = CommonUtil.getHashMap();

		if (inputParamHs == null || inputParamHs.isEmpty()) {
			sAppInfo = "Input Hash is NULL";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
			logger.info("{}{}DBTOOLS_01a : {}", CLASS_NAME, sMethodName, sAppInfo);
			return hmResult;
		}

		logger.info("{}{}DBTOOLS000 : InpParam : {}", CLASS_NAME, sMethodName, StructuredArguments.entries(inputParamHs));
		stAccountId = (String) inputParamHs.get(MPSDefs.DB_ACCOUNT_ID);
		stIdentificationType = (String) inputParamHs.get(MPSDefs.DB_IDENTIFICATION_TYPE);

		if (stAccountId == null || stAccountId.trim().length() <= 0 || stIdentificationType == null
				|| stIdentificationType.trim().length() <= 0) {
			sAppInfo = "account_id,Identification_id is null or empty in input";
			hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, sAppInfo);
			logger.info("{}{}DBTOOLS_02 : {}", CLASS_NAME, sMethodName, sAppInfo);
			return hmResult;
		}

		try {

			logger.info("{}{}DB3.1 : Query SQL queryAccountLockout =  {}", CLASS_NAME, sMethodName,
					queryAccountLockout);
			Collections.addAll(objectList, stIdentificationType, stAccountId);

			long pTime = 0;
			Date dtQueryTime = new Date();

			logger.info("{}{}DBTOOLS003 : Query start time", CLASS_NAME, sMethodName);

			alQueryResponse = jdbcTemplate.queryForList(new String(queryAccountLockout),
					objectList.toArray(new Object[objectList.size()]));

			pTime = (System.currentTimeMillis() - dtQueryTime.getTime());

			logger.info(LOG_INFO_QUERY999, CLASS_NAME, sMethodName, pTime);

			ArrayList alAccountLocks = CommonUtil.getArrayList();
			HashMap hmLockInfo = null;

            for (Object o : alQueryResponse) {
                Map hmQueryResponse = (Map) o;

                for (Object object : hmQueryResponse.keySet()) {
                    String key = (String) object;
                    Object value = hmQueryResponse.get(key);

                    String strValue = (value == null ? null : value.toString());

                    hmQueryResponse.put(key, strValue);
                }

                hmLockInfo = CommonUtil.getHashMap();
                hmLockInfo.put(MPSDefs.DB_ACCOUNT_ID, hmQueryResponse.get(MPSDefs.DB_ACCOUNT_ID));
                hmLockInfo.put(MPSDefs.DB_IDENTIFICATION_TYPE,
                        hmQueryResponse.get(MPSDefs.DB_IDENTIFICATION_TYPE));
                hmLockInfo.put(MPSDefs.DB_LOCKOUT_ID, hmQueryResponse.get(MPSDefs.DB_LOCKOUT_ID));
                hmLockInfo.put(MPSDefs.DB_LOCKOUT_NAME, hmQueryResponse.get(MPSDefs.DB_LOCKOUT_NAME));
                hmLockInfo.put(MPSDefs.DB_SET_NUMBER, hmQueryResponse.get(MPSDefs.DB_SET_NUMBER));
                hmLockInfo.put(MPSDefs.DB_FAILED_AUTH_COUNT,
                        hmQueryResponse.get(MPSDefs.DB_FAILED_AUTH_COUNT));
                hmLockInfo.put(MPSDefs.DB_LOCKOUT_EXPIRATION,
                        hmQueryResponse.get(MPSDefs.DB_LOCKOUT_EXPIRATION));
                hmLockInfo.put(MPSDefs.DB_LAST_FAILED_AUTH,  hmQueryResponse.get(MPSDefs.DB_LAST_FAILED_AUTH));
                hmLockInfo.put(MPSDefs.DB_CREATE_DATE,  hmQueryResponse.get(MPSDefs.DB_CREATE_DATE));
                hmLockInfo.put(MPSDefs.DB_LAST_MODIFIED,  hmQueryResponse.get(MPSDefs.DB_LAST_MODIFIED));
                hmLockInfo.put(MPSDefs.DB_LAST_MODIFIED_BY,  hmQueryResponse.get(MPSDefs.DB_LAST_MODIFIED_BY));

                alAccountLocks.add(hmLockInfo);
            }

			if (alAccountLocks.isEmpty()) {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
						"No Record found for given account_id and identification_type");
			} else {
				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
				hmResult.put("accountlockout", alAccountLocks);
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			sAppInfo = (String) hmResult.get(CErrorDefs.COMMON_APP_INFO);
			if (sAppInfo == null)
				hmResult.put(CErrorDefs.COMMON_APP_INFO, e.getMessage());

			logger.error("{}{}DBTOOLS006 : Exception = {}", CLASS_NAME, sMethodName, e.getMessage());
		} finally {
			logger.info("{}{}DBTOOLS999 : Response is : {}", CLASS_NAME, sMethodName, hmResult);
		}
		return hmResult;
	}

	/**
	 * This method processes the account lockout data.
	 * It takes in a HashMap and a Logger as parameters.
	 * The HashMap contains the account lockout data to be processed.
	 * The method retrieves the calling system ID from the HashMap.
	 * If the calling system ID is null or empty, the method returns an error.
	 * The method then retrieves the account lockout operations from the HashMap.
	 * If the account lockout operations are null or empty, the method returns an error.
	 * The method iterates over the account lockout operations and processes each operation based on its type.
	 * The operation types can be insert, update, or delete.
	 * The method calls the corresponding method (add, update, or delete) for each operation type.
	 * If an exception occurs during the processing, the method logs the exception using the provided Logger and returns a HashMap containing error details.
	 *
	 * @param hmInput The HashMap containing the account lockout data to be processed.
	 * @param logger The Logger to be used for logging any exceptions.
	 * @return HashMap The result of the processing. Contains error details if the processing fails, or a success message if the processing is successful.
	 */
	public HashMap processData(HashMap hmInput, Logger logger) {
		String sMethodName = ".processData.";
		HashMap hmResult = null;
		String sAppStatusCode = null;
		String sAppInfo = null;

		Date dtStart = new Date();

		try {
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			if (sCallingSystemId == null || sCallingSystemId.trim().length() <= 0) {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM,
						"callingSystemId is null or empty in input");
				return hmResult;
			}

			ArrayList alLockoutOperations = (ArrayList) hmInput.get("accountlockout");
			if (alLockoutOperations == null || alLockoutOperations.isEmpty()) {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM,
						"account lockout operations list is empty in input");
				return hmResult;
			}

			for (int i = 0; i < alLockoutOperations.size(); i++) {
				HashMap hmLockoutOperation = (HashMap) alLockoutOperations.get(i);

				if (hmLockoutOperation != null && !hmLockoutOperation.isEmpty()) {
					String sOperationType = (String) hmLockoutOperation.get(MPSDefs.DB_OPERATION);
					hmLockoutOperation.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);

					if (sOperationType == null || sOperationType.length() <= 0) {
						hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM,
								"operation type is null or missing");
						return hmResult;
					}

					if (sOperationType.equalsIgnoreCase(MPSDefs.DB_OPERATION_INSERT)) {
						hmResult = add(hmLockoutOperation, logger);
					} else if (sOperationType.equalsIgnoreCase(MPSDefs.DB_OPERATION_UPDATE)) {
						hmResult = update(hmLockoutOperation, logger);
					} else if (sOperationType.equalsIgnoreCase(MPSDefs.DB_OPERATION_DELETE)) {
						hmResult = delete(hmLockoutOperation, logger);
					} else {
						hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM,
								sOperationType + ", operation type is invalid");
						return hmResult;
					}

					sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
					if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
						return hmResult;
					}
				} else {
					hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM,
							"account lockout operation hash is empty in input");
					return hmResult;
				}
			}
		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			sAppInfo = (String) hmResult.get(CErrorDefs.COMMON_APP_INFO);
			if (sAppInfo == null)
				hmResult.put(CErrorDefs.COMMON_APP_INFO, e.getMessage());

			logger.error("{}{}DBTOOLS_E1 : Exception = {}", CLASS_NAME, sMethodName, e.getMessage());

		} finally {
			logger.info("{}{}DBTOOLS999 : {} : Response is : {}", CLASS_NAME, sMethodName, dtStart.getTime(), hmResult);
		}
		return hmResult;
	}

	/**
	 * This method is used to add account lockout data to the database.
	 * It takes in a HashMap and a Logger as parameters.
	 * The HashMap contains the account lockout data to be added.
	 * The method retrieves various details from the HashMap such as the account ID, lockout ID, and identification type.
	 * It then prepares an SQL query to insert the account lockout data into the ACCOUNTLOCKOUT table in the database.
	 * The method executes the SQL query using the JdbcTemplate from Spring Framework.
	 * If the insertion is successful, the method returns a HashMap containing a success message.
	 * If an exception occurs during the insertion, the method logs the exception using the provided Logger and returns a HashMap containing error details.
	 *
	 * @param hmDbInput The HashMap containing the account lockout data to be added.
	 * @param logger The Logger to be used for logging any exceptions.
	 * @return HashMap The result of the insertion. Contains error details if the insertion fails, or a success message if the insertion is successful.
	 */
	public HashMap add(HashMap hmDbInput, Logger logger) {
		String sMethodName = ".add.";

		HashMap hmResult = null;
		List<Object> objectList = new ArrayList<Object>();
		SimpleDateFormat sdf = CommonUtil.getSimpleDateFormat(DateUtil.DATE_FORMAT);
		logger.info(LOG_INFO_DBTOOLS_01, CLASS_NAME, sMethodName, hmDbInput);

		try {
			String sAccountId = (String) hmDbInput.get(MPSDefs.DB_ACCOUNT_ID);
			String sIdentificationType = (String) hmDbInput.get(MPSDefs.DB_IDENTIFICATION_TYPE);
			String sLockoutId = (String) hmDbInput.get(MPSDefs.DB_LOCKOUT_ID);
			String sLockoutExpiration = (String) hmDbInput.get(MPSDefs.DB_LOCKOUT_EXPIRATION);
			String slastFailedAuth = (String) hmDbInput.get(MPSDefs.DB_LAST_FAILED_AUTH);
			String sSetNumber = (String) hmDbInput.get(MPSDefs.DB_SET_NUMBER);
			String sFailedAuthCount = (String) hmDbInput.get(MPSDefs.DB_FAILED_AUTH_COUNT);
			String sCallingSystemId = (String) hmDbInput.get(CommonDefs.CALLING_SYSTEM_ID);

			if (sAccountId == null || sAccountId.trim().length() <= 0 || sLockoutId == null
					|| sLockoutId.trim().length() <= 0 || sIdentificationType == null
					|| sIdentificationType.trim().length() <= 0) {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO);
				logger.info("{}{}DBTOOLS_02 : {}", CLASS_NAME, sMethodName, APP_INFO);
				return hmResult;
			}

			logger.info("{}{}DBTOOLS_03 : Query SQL INSERT_ACCOUNT_LOCKOUT_SQL =  {}", CLASS_NAME, sMethodName,
					INSERT_ACCOUNT_LOCKOUT_SQL);

			objectList.add(sAccountId);

			int iLockoutId = Integer.parseInt(sLockoutId);
			objectList.add(iLockoutId);

			if (sSetNumber != null) {
				int iSetNumber = Integer.parseInt(sSetNumber);
				objectList.add(iSetNumber);
			} else {
				objectList.add(null);
			}
			if (sFailedAuthCount != null) {
				int iFailedAuthCount = Integer.parseInt(sFailedAuthCount);
				objectList.add(iFailedAuthCount);
			} else {
				objectList.add(null);
			}

			if (sLockoutExpiration != null) {
				Date util_date = sdf.parse(sLockoutExpiration);
				java.sql.Timestamp DateVal = new java.sql.Timestamp(util_date.getTime());
				objectList.add(DateVal);
			} else {
				objectList.add(null);
			}

			if (slastFailedAuth != null) {
				Date util_date = sdf.parse(slastFailedAuth);
				java.sql.Timestamp timeVal = new java.sql.Timestamp(util_date.getTime());
				objectList.add(timeVal);
			} else {
				objectList.add(null);
			}

			objectList.add(sCallingSystemId);
			objectList.add(sIdentificationType);

			long pTime = 0;
			Date tQueryTime = new Date();

			int iCount = jdbcTemplate.update(new String(INSERT_ACCOUNT_LOCKOUT_SQL),
					objectList.toArray(new Object[objectList.size()]));

			pTime = (System.currentTimeMillis() - tQueryTime.getTime());

			logger.info(LOG_INFO_QUERY999, CLASS_NAME, sMethodName,
					pTime);

			logger.info("{}{}DBTOOLS_04 : No of rows inserted in TACCOUNTLOCKOUT:= {} milliseconds", CLASS_NAME,
					sMethodName, iCount);

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);

			if((String) hmResult.get(CErrorDefs.COMMON_APP_INFO) == null) {
				hmResult.put(CErrorDefs.COMMON_APP_INFO, e.getMessage());
			}

			logger.error("{}{}DBTOOLS_E2 : Exception = {}", CLASS_NAME, sMethodName, e.getMessage());
		} finally {
			logger.info("{}{}DBTOOLS_06 : add method Response is : {}", CLASS_NAME, sMethodName, hmResult);
		}

		return hmResult;
	}

	/**
	 * This method is used to update account lockout data in the database.
	 * It takes in a HashMap and a Logger as parameters.
	 * The HashMap contains the account lockout data to be updated.
	 * The method retrieves various details from the HashMap such as the account ID, lockout ID, and identification type.
	 * It then prepares an SQL query to update the account lockout data in the ACCOUNTLOCKOUT table in the database.
	 * The method executes the SQL query using the JdbcTemplate from Spring Framework.
	 * If the update is successful, the method returns a HashMap containing a success message.
	 * If an exception occurs during the update, the method logs the exception using the provided Logger and returns a HashMap containing error details.
	 *
	 * @param hmDbInput The HashMap containing the account lockout data to be updated.
	 * @param logger The Logger to be used for logging any exceptions.
	 * @return HashMap The result of the update. Contains error details if the update fails, or a success message if the update is successful.
	 */
	public HashMap update(HashMap hmDbInput, Logger logger) {
		String sMethodName = ".update.";

		HashMap hmResult = null;
		String sAppInfo = null;
		List<Object> objectList = new ArrayList<Object>();

		logger.info(LOG_INFO_DBTOOLS_01, CLASS_NAME, sMethodName, hmDbInput);

		String sAccountIdVal = null;
		String sIdentificationType = null;
		String sLockoutIdVal = null;
		String whereClause = null;

		StringBuilder query = new StringBuilder(" UPDATE ACCOUNTLOCKOUT ");

		List argsKeys = CommonUtil.getArrayList();
		List argsVals = CommonUtil.getArrayList();
		List Keys = CommonUtil.getArrayList();

		if (hmDbInput == null) {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
					"Input hash is empty");
			return hmResult;
		}

		query.append(" SET ");
		logger.info("{}{}DBTOOLS_03 : Start of Query = {}", CLASS_NAME, sMethodName, query);

		try {
			Iterator it = hmDbInput.keySet().iterator();
			while (it.hasNext()) {
				String key = (String) it.next();

				if (key.equalsIgnoreCase(MPSDefs.DB_ACCOUNT_ID)) {
					sAccountIdVal = (String) hmDbInput.get(key);
					logger.info("{}{}DBTOOLS_04 : account_id : {}", CLASS_NAME, sMethodName, sAccountIdVal);
				} else if (key.equalsIgnoreCase(MPSDefs.DB_IDENTIFICATION_TYPE)) {
					sIdentificationType = (String) hmDbInput.get(key);
					logger.info("{}{}DBTOOLS_05 : identification_type : {}", CLASS_NAME, sMethodName,
							sIdentificationType);
				}

				else if (key.equalsIgnoreCase("lockout_id")) {
					sLockoutIdVal = (String) hmDbInput.get(key);
					logger.info("{}{}DBTOOLS_064 : lockout_id : {}", CLASS_NAME, sMethodName, sLockoutIdVal);
				} else if (key.equalsIgnoreCase(CommonDefs.CALLING_SYSTEM_ID)) {
					argsKeys.add(MPSDefs.DB_LAST_MODIFIED_BY + " = ?");
					argsVals.add((String) hmDbInput.get(key));
					Keys.add(MPSDefs.DB_LAST_MODIFIED_BY);
				} else {
					if (memberCheckKey(key)) {
						argsKeys.add(key + " = ?");
						argsVals.add((String) hmDbInput.get(key));
						Keys.add(key);
					}
				}
			}

			int len = argsKeys.size();
			int i;

			for (i = 0; i < len; i++) {
				query.append(argsKeys.get(i));

				if (i != (len - 1)) {
					query.append(" , ");
				}
			}

			if (sAccountIdVal != null && sAccountIdVal.trim().length() > 0 && sLockoutIdVal != null
					&& sLockoutIdVal.trim().length() > 0 && sIdentificationType != null
					&& sIdentificationType.trim().length() > 0) {
				whereClause = "account_id =? AND lockout_id = ? AND IDENTIFICATION_TYPE = ?";
				query.append(" WHERE " + whereClause);
				logger.info("{}{}DBTOOLS_06 : Query = {}", CLASS_NAME, sMethodName, query);

			} else {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO);
				return hmResult;
			}

			SimpleDateFormat sdf = null;
			for (i = 0; i < argsVals.size(); i++) {
				if (memberTypeSet((String) Keys.get(i)).equals("Int")) {
					Optional.ofNullable(argsVals.get(i)).ifPresentOrElse(x -> objectList.add(Integer.parseInt((String) x)), () -> objectList.add(null));
				} else if (memberTypeSet((String) Keys.get(i)).equals("String")) {
					objectList.add((String) argsVals.get(i));
				} else if (memberTypeSet((String) Keys.get(i)).equals("Date")) {

					String sKey = (String) Keys.get(i);

					if (sKey.equals("lockout_expiration")) {
						sdf = CommonUtil.getSimpleDateFormat(DateUtil.DATE_FORMAT);
					} else if (sKey.equals("last_failed_auth")) {
						sdf = CommonUtil.getSimpleDateFormat(DateUtil.DATE_FORMAT);
					}

					if (argsVals.get(i) != null) {
						Date util_date = sdf.parse((String) argsVals.get(i));
						java.sql.Timestamp timeStamp = CommonUtil.getSQLTimeStamp(util_date.getTime());
						objectList.add(timeStamp);
					} else {
						objectList.add(null);
					}
				}
			}

			Collections.addAll(objectList, sAccountIdVal, sLockoutIdVal, sIdentificationType);

			int iCount = 0;
			if ((whereClause != null) && !(whereClause.length() == 0)) {
				iCount = jdbcTemplate.update(new String(query.toString()),
						objectList.toArray(new Object[objectList.size()]));

				logger.info("{}{}DBTOOLS_07 : No of rows updated := {}", CLASS_NAME, sMethodName, iCount);

				if (iCount == 0) {
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
							"No Record found for given account_id , Identification_type and lockout_id");
				} else {
					hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
				}
			} else {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
						"where clause is not prepared");
				logger.info("{}{}DBTOOLS_08 : where clause is not prepared", CLASS_NAME, sMethodName);
				return hmResult;
			}
		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			sAppInfo = (String) hmResult.get(CErrorDefs.COMMON_APP_INFO);
			if (sAppInfo == null)
				hmResult.put(CErrorDefs.COMMON_APP_INFO, e.getMessage());

			logger.error("{}{}DBTOOLS_E3 : Exception = {}", CLASS_NAME, sMethodName, e.getMessage());
		} finally {
			logger.info("{}{}DBTOOLS_11 : update method Response is : {}", CLASS_NAME, sMethodName, hmResult);
		}
		return hmResult;
	}

	/**
	 * This method is used to delete account lockout data from the database.
	 * It takes in a HashMap and a Logger as parameters.
	 * The HashMap contains the account lockout data to be deleted.
	 * The method retrieves various details from the HashMap such as the account ID, lockout ID, and identification type.
	 * It then prepares an SQL query to delete the account lockout data from the ACCOUNTLOCKOUT table in the database.
	 * The method executes the SQL query using the JdbcTemplate from Spring Framework.
	 * If the deletion is successful, the method returns a HashMap containing a success message.
	 * If an exception occurs during the deletion, the method logs the exception using the provided Logger and returns a HashMap containing error details.
	 *
	 * @param hmDbInput The HashMap containing the account lockout data to be deleted.
	 * @param logger The Logger to be used for logging any exceptions.
	 * @return HashMap The result of the deletion. Contains error details if the deletion fails, or a success message if the deletion is successful.
	 */
	public HashMap delete(HashMap hmDbInput, Logger logger) {
		String sMethodName = ".delete.";
		HashMap hmResult = null;

		List<Object> objectList = new ArrayList<Object>();

		int iCount;

		logger.info(LOG_INFO_DBTOOLS_01, CLASS_NAME, sMethodName, hmDbInput);

		String sAccountId = (String) hmDbInput.get(MPSDefs.DB_ACCOUNT_ID);
		String sLockoutId = (String) hmDbInput.get("lockout_id");
		String sIdentificationType = (String) hmDbInput.get(MPSDefs.DB_IDENTIFICATION_TYPE);

		if (sAccountId == null || sAccountId.trim().length() <= 0 || sLockoutId == null
				|| sLockoutId.trim().length() <= 0 || sIdentificationType == null
				|| sIdentificationType.trim().length() <= 0) {
			hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, APP_INFO);
			logger.info("{}{}DBTOOLS_03 : {}", CLASS_NAME, sMethodName, APP_INFO);
			return hmResult;
		}

		try {
			objectList.add(sAccountId.trim());

			int iLockoutId = Integer.parseInt(sLockoutId);
			objectList.add(iLockoutId);
			objectList.add(sIdentificationType);

			logger.info("{}{}DBTOOLS_04 : Query SQL DELETE_ACCOUNT_LOCKOUT_SQL = {}", CLASS_NAME, sMethodName,
					DELETE_ACCOUNT_LOCKOUT_SQL);

			Date dtStartDate = new Date();

			iCount = jdbcTemplate.update(new String(DELETE_ACCOUNT_LOCKOUT_SQL),
					objectList.toArray(new Object[objectList.size()]));

			long pTime = (System.currentTimeMillis() - dtStartDate.getTime());

			logger.info(LOG_INFO_QUERY999, CLASS_NAME, sMethodName,	pTime);

			logger.info("{}{}DBTOOLS07 : No of rows inserted in TACCOUNTLOCKOUT:= {} milliseconds", CLASS_NAME,
					sMethodName, iCount);

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			if ((String) hmResult.get(CErrorDefs.COMMON_APP_INFO) == null)
				hmResult.put(CErrorDefs.COMMON_APP_INFO, e.getMessage());

			logger.error("{}{}DBTOOLS_E4 : Exception = {}", CLASS_NAME, sMethodName, e.getMessage());
		} finally {
			logger.info("{}{}DBTOOLS_12 : delete method Response is : {}", CLASS_NAME, sMethodName, hmResult);
		}
		return hmResult;
	}

	/**
	 * This method checks if the provided key is one of the predefined keys.
	 * It takes in a String as a parameter which represents the key to be checked.
	 * The method compares the provided key with the predefined keys: 'DB_SET_NUMBER', 'DB_FAILED_AUTH_COUNT', 'DB_LOCKOUT_EXPIRATION', and 'DB_LAST_FAILED_AUTH'.
	 * If the provided key matches any of the predefined keys, the method returns true.
	 * If the provided key does not match any of the predefined keys, the method returns false.
	 *
	 * @param Key The key to be checked.
	 * @return boolean Returns true if the provided key matches any of the predefined keys, otherwise returns false.
	 */
	public boolean memberCheckKey(String Key) {
		if ((Key.equalsIgnoreCase(MPSDefs.DB_SET_NUMBER)) || (Key.equalsIgnoreCase(MPSDefs.DB_FAILED_AUTH_COUNT))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_LOCKOUT_EXPIRATION))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_LAST_FAILED_AUTH))) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * This method determines the data type of the provided key.
	 * It takes in a String as a parameter which represents the key.
	 * The method checks if the provided key matches any of the predefined keys: 'DB_LAST_MODIFIED_BY', 'DB_SET_NUMBER', 'failed_auth_count', 'DB_LOCKOUT_EXPIRATION', and 'DB_LAST_FAILED_AUTH'.
	 * If the provided key matches 'DB_LAST_MODIFIED_BY', the method returns "String".
	 * If the provided key matches 'DB_SET_NUMBER' or 'failed_auth_count', the method returns "Int".
	 * If the provided key matches 'DB_LOCKOUT_EXPIRATION' or 'DB_LAST_FAILED_AUTH', the method returns "Date".
	 * If the provided key does not match any of the predefined keys, the method returns an empty string.
	 *
	 * @param Key The key for which the data type is to be determined.
	 * @return String Returns the data type of the provided key. Returns an empty string if the key does not match any of the predefined keys.
	 */
	public String memberTypeSet(String Key) {
		String Return = "";
		if ((Key.equalsIgnoreCase(MPSDefs.DB_LAST_MODIFIED_BY))) {
			Return = "String";
		}
		if ((Key.equalsIgnoreCase(MPSDefs.DB_SET_NUMBER)) || (Key.equalsIgnoreCase("failed_auth_count"))) {
			Return = "Int";
		}
		if ((Key.equalsIgnoreCase(MPSDefs.DB_LOCKOUT_EXPIRATION)) || (Key.equalsIgnoreCase(MPSDefs.DB_LAST_FAILED_AUTH))) {
			Return = "Date";
		}
		return Return;
	}

}