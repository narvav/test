package com.att.idp.idgraphusermanagementms.queue.message.helpers;

import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.mpsys.common.helpers.FeatureManagerHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * The RegisterEmailUserQueueHelper class is part of the com.att.idp.idgraphusermanagementms.queue.message.helpers package.
 * It is a helper class that assists in sending messages to the message queue when a user's email is registered.
 * The class has several methods including sendMessageToMQ, populateAddMemberEventData, and populateUpdateAliasEventData.
 * sendMessageToMQ is responsible for sending the message to the queue and handling the response.
 * populateAddMemberEventData is responsible for populating the event data for adding a member.
 * populateUpdateAliasEventData is responsible for populating the event data for updating an alias.
 * The class also has several fields including a logger, an instance of JMSQueueSender, and various constants.
 */
@Component
public class RegisterEmailUserQueueHelper {

	public static final Logger log = LoggerFactory.getLogger(RegisterEmailUserQueueHelper.class);

	private static final String ERROR_ENUM = "ErrorEnum";
	private String sClassName = "RegisterEmailUserQueueHelper";

    @Autowired
    FeatureManagerHelper featureManager;

    @Autowired
    private PublishMqAehHelper publishMqAehHelper;

	/**
	 * This method is part of the RegisterEmailUserQueueHelper class.
	 * It is responsible for sending a message to the message queue when a user's email is registered.
	 * The method takes a HashMap, an ArrayList, and two Strings as input.
	 * The HashMap contains the input data, the ArrayList contains the event data,
	 * the first String is the SLID member number, and the second String is the DB member number.
	 * The method prepares the DBUS input, sends the request to JMSQueueSender, and handles the response.
	 * If the response from the JMSQueueSender is empty or unsuccessful, the method returns an error.
	 * If the response is successful, the method returns a success message.
	 *
	 * @param hmInput The HashMap containing the input data.
	 * @param alEventData The ArrayList containing the event data.
	 * @param sSlidMemberNum The SLID member number.
	 * @param stDBMemberNum The DB member number.
	 * @return A HashMap containing the response from the JMSQueueSender.
	 */
    public Map sendMessageToMQ(Map<String, Object> hmInput, ArrayList<Map<String, Object>> alEventData, String sSlidMemberNum, String stDBMemberNum) {

		String sMethodName = ".sendMessageToMQ.";
		String stAppInfo;
		String stAppStatusCode = null;
        Map<String, Object> hmResult =null;

        final String REGISTER_EMAIL_AEH_FEATURE_KEY = "cfg-idgraph-registeremailuser-mq-aeh-switch";
        final String REGISTER_EMAIL_CLM_FEATURE_KEY = "cfg-idgraph-registeremailuser-notification-clm-switch";

        final String AEH = "AEH";
        final String MQ = "MQ";
        final String BOTH = "BOTH";


		HashMap hmDbusInput = CommonUtil.getHashMap();

		if (sSlidMemberNum == null) {
			hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, stDBMemberNum);
		} else {
			hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, sSlidMemberNum);
		}

		String sSlidMemberNumber = sSlidMemberNum;
		// 2205 Fix the hashing key for the MID to use slid_member_num
		if (alEventData != null && !alEventData.isEmpty()) {
			alEventData.forEach(eachDBUSEvent -> {
				HashMap<String, Object> hmEvent = (HashMap<String, Object>) eachDBUSEvent;
				String sEventName = (String) hmEvent.get(CommonDefs.EVENTNAME);
				if ("AddMember".equals(sEventName)) {

					hmEvent.put(MPSDefs.DB_SLID_MEMBER_NUM, sSlidMemberNumber);
					hmEvent.put("hashKey", sSlidMemberNumber);
				}
			});
		}
		hmDbusInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
		hmDbusInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
		hmDbusInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
		hmDbusInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		hmDbusInput.put(CommonDefs.EVENTNAME, CommonDefs.MICRO_SERVICE_EVENT);
		hmDbusInput.put(CommonDefs.MS_OPERTAION, hmInput.get(CommonDefs.TRANSACTION_NAME));
		hmDbusInput.put(CommonDefs.EVENTS_DATA, alEventData);

        //mq aeh switch
        String sRegisterEmailMQAEHEnabled = featureManager.getValue(REGISTER_EMAIL_AEH_FEATURE_KEY);
        sRegisterEmailMQAEHEnabled = (sRegisterEmailMQAEHEnabled != null && !sRegisterEmailMQAEHEnabled.isEmpty()) ? sRegisterEmailMQAEHEnabled : MQ;
        log.info("{}{} ixp flag sRegisterEmailMQAEHEnabled MQ AEH Value: {}", sClassName, sMethodName, sRegisterEmailMQAEHEnabled);


        //clm switch
        String sRegisterEmailClmEnabled = featureManager.getValue(REGISTER_EMAIL_CLM_FEATURE_KEY);
        sRegisterEmailClmEnabled = (sRegisterEmailClmEnabled != null && !sRegisterEmailClmEnabled.isEmpty()) ? sRegisterEmailClmEnabled : MQ;
        log.info("{}{} ixp flag sRegisterEmailClmEnabled CLM Value: {}", sClassName,sMethodName, sRegisterEmailClmEnabled);

        // add helper methods to send to MQ or AEH based on flag values
        hmResult =  publishMqAehHelper.invokeMqAEH(hmDbusInput, hmInput, alEventData, sClassName, sMethodName, sRegisterEmailMQAEHEnabled, sRegisterEmailClmEnabled);

        log.info("{}{}REUQH_18 : ResponseHash from JMSQueueSender : {}", sClassName, sMethodName,
				HtmlUtils.htmlEscape(String.valueOf(hmResult)));

		if (MapUtils.isEmpty(hmResult)) {
			stAppInfo = "Null Response returned from JMSQueueSender.send";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
            log.info("{}{}REUQH_19 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

		if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {

			stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
            log.info("{}{}REUQH_20 : ", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
			hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
			return hmResult;
		} else {
			hmResult.put("isTransactionRollback", true);
		}

		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;

	}

	/**
     * Populates the event data for an add-member event based on the consolidated DBUS
     * input contained in the Add User response.
     * <p>
     * This method retrieves the {@link CommonDefs#EVENTS_DATA} list from the
     * {@link CommonDefs#CONSOLIDATED_DBUS_INPUT} structure inside the provided
     * Add User response map. If {@code bAddServiceData} is {@code true}, it locates
     * events whose {@link CommonDefs#EVENTNAME} is {@code "AddMember"} and enriches
     * them with default portal service information under {@link CommonDefs#SERVICES}.
     * The resulting list of event data maps is then returned to the caller.
	 *
     * @param hmInput           the input data for the overall operation; currently used
     *                          only for context and not directly modified by this method.
     * @param hmAddUserResponse the map containing the Add User response, including the
     *                          consolidated DBUS input and its associated event data.
     * @param bAddServiceData   flag indicating whether portal service information should
     *                          be added to any {@code "AddMember"} events found.
     * @return an {@link ArrayList} of event data maps derived from the consolidated
     *         DBUS input, potentially enriched with portal service data for
     *         {@code "AddMember"} events; may be empty if no event data is present.
	 */
    public ArrayList<Map<String, Object>>  populateAddMemberEventData(Map<String, Object> hmInput,
			Map<String, Object> hmAddUserResponse, boolean bAddServiceData) {

        ArrayList<Map<String, Object>>  alEventsData = CommonUtil.getArrayList();

		Map<String, Object> hmDbusInp = (HashMap) hmAddUserResponse.get(CommonDefs.CONSOLIDATED_DBUS_INPUT);

		if (hmDbusInp != null && !hmDbusInp.isEmpty()) {
            Object eventsDataObj = hmDbusInp.get(CommonDefs.EVENTS_DATA);
            if (eventsDataObj instanceof ArrayList) {
                @SuppressWarnings("unchecked")
                ArrayList<Map<String, Object>> castedEventsData = (ArrayList<Map<String, Object>>) eventsDataObj;
                alEventsData = castedEventsData;
            }
		}

		if (alEventsData != null && !alEventsData.isEmpty()) {
			alEventsData.forEach(event -> {
				if (bAddServiceData) {
					HashMap<String, Object> hmEvent = (HashMap<String, Object>) event;
					String sEventName = (String) hmEvent.get(CommonDefs.EVENTNAME);
					if ("AddMember".equals(sEventName)) {
						HashMap<String, Object> hmDbusService = new HashMap<>();
						hmDbusService.put(CommonDefs.SERVICE_TYPE, CommonDefs.PORTAL_SERVICE);
						hmDbusService.put(MPSDefs.DB_PLITE_IND, CommonDefs.IND_Y);
						hmDbusService.put(MPSDefs.DB_SOR_NAME, MPSDefs.SOR_OPR);
						hmDbusService.put(CommonDefs.SERVICE_STATUS, MPSDefs.ENABLED);
						hmDbusService.put(CommonDefs.PORTAL_PROVIDER, CommonDefs.PORTAL_PROVIDER_ATT_YAHOO);
						hmDbusService.put(CommonDefs.MEMBER_STATUS, MPSDefs.ENABLED);
						ArrayList<Object> alDbusServices = new ArrayList<>();
						alDbusServices.add(hmDbusService);
						hmEvent.put(CommonDefs.SERVICES, alDbusServices);
					}
				}
			});
		}

		return alEventsData;

	}

	/**
	 * This method is part of the RegisterEmailUserQueueHelper class.
	 * It is responsible for populating the event data for updating an alias.
	 * The method takes a HashMap and two Strings as input.
	 * The HashMap contains the input data, the first String is the SLID handle, and the second String is the SLID member number.
	 * The method creates a new HashMap for the alias and adds the necessary data to it.
	 * It then adds the alias HashMap to an ArrayList and adds the ArrayList to the input HashMap.
	 * The method returns the updated input HashMap.
	 *
	 * @param hmInput The HashMap containing the input data.
	 * @param sSlidHandle The SLID handle.
	 * @param sSlidMemberNum The SLID member number.
	 * @return A HashMap containing the updated input data.
	 */
	public Map<String, Object> populateUpdateAliasEventData(Map<String, Object> hmInput, String sSlidHandle,
			String sSlidMemberNum) {

		String sHandle = (String) hmInput.get(CommonDefs.HANDLE);
		String sDomain = (String) hmInput.get(CommonDefs.DOMAIN);

		HashMap<String, Object> hmAddAlias = new HashMap<>();
		HashMap<String, Object> hmUpdateAliasInp = new HashMap<>();
		hmAddAlias.put(CommonDefs.HANDLE, hmInput.get(CommonDefs.HANDLE));
		hmAddAlias.put(CommonDefs.DOMAIN, hmInput.get(CommonDefs.DOMAIN));
		ArrayList<Object> alAddAlias = new ArrayList<>();
		alAddAlias.add(hmAddAlias);
		hmUpdateAliasInp.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		hmUpdateAliasInp.put(CommonDefs.EVENTNAME, CommonDefs.UPDATE_ALIAS_LIST_EVENT);
		hmUpdateAliasInp.put(CommonDefs.PARENT_HANDLE, sHandle);
		hmUpdateAliasInp.put(CommonDefs.PARENT_DOMAIN, sDomain);
		hmUpdateAliasInp.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
		hmUpdateAliasInp.put(MPSDefs.DB_SLID_MEMBER_NUM, sSlidMemberNum);
		hmUpdateAliasInp.put(CommonDefs.TGUARD_EVENT_ADD_ALIAS, alAddAlias);
		hmUpdateAliasInp.put(CommonDefs.HANDLE, sSlidHandle);
		hmUpdateAliasInp.put(CommonDefs.DOMAIN, CommonDefs.SLID_DUM);
		hmUpdateAliasInp.put(CommonDefs.TRANSACTION_NAME, CommonDefs.TRANS_NAME_LINK_INTERNET_ACCOUNT);
		// change by pm675e:Added transactionId for updateAliasList due to issue in
		// HaloC call
		hmUpdateAliasInp.put(CommonDefs.TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));

		return hmUpdateAliasInp;
	}

}
