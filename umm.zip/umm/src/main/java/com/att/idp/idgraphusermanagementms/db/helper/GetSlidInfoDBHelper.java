package com.att.idp.idgraphusermanagementms.db.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This class is responsible for retrieving SLID (Subscriber Line Identifier) information from the database.
 * It uses Spring's JdbcTemplate for database operations.
 *
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like JdbcTemplate and other helper classes.
 *
 * The class contains SQL queries as string constants for retrieving SLID information.
 * These queries are used in the corresponding methods for these operations.
 *
 * The main method in this class is:
 * - getSlidInfo: This method retrieves the SLID information from the database. It takes a HashMap as input and returns a HashMap as output.
 *   The input HashMap contains key-value pairs for various SLID attributes like slid, slid_member_num, slidMask etc.
 *   The method first checks if the jdbcTemplate is null. If it is, it returns an error status.
 *   Then it retrieves the SLID attributes from the input HashMap.
 *   If the SLID attributes are not found, it returns an error status.
 *   Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
 *   Finally, it returns a status indicating whether the operation was successful or not.
 */
@Component
public class GetSlidInfoDBHelper {

	private static final String INFO = "$Id: master/com/att/idp/idgraphusermanagementms/db/helper/GetSlidInfoDBHelper.java v1 2020-01-30 kg852c $;";
	private static String CLASS_NAME = "GetSlidInfoDBHelper";
	public static final Logger log = LoggerFactory.getLogger(GetSlidInfoDBHelper.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private GetInfoByMaskDBHelper oGetInfoByMaskDBHelper;

	@Autowired
	private GetMemberServicesDBHelper oGetMemberServicesDBHelper;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	/**
	 * This method retrieves the Subscriber Line Identifier (SLID) information from the database.
	 * It takes a HashMap as input and returns a HashMap as output.
	 * The input HashMap contains key-value pairs for various SLID attributes like slid, slid_member_num, slidMask etc.
	 * The method first checks if the input HashMap is null. If it is, it returns an error status.
	 * Then it retrieves the SLID attributes from the input HashMap.
	 * If the SLID attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param inputParamHs A HashMap containing the details of the SLID's information to be retrieved.
	 * @return A HashMap containing the status of the operation and the retrieved SLID's information.
	 */
	public HashMap<String, Object> getSlidInfo(HashMap<String, Object> inputParamHs) {

		String sMethodName = ".getSlidInfo.";
		String queryLinkedIdsBySlidMemberNUM = "SELECT member_num from member where slid_member_num=?";
		List<Object> objectList = CommonUtil.getArrayList();
		List alQueryResponse = null;
		HashMap<String, Object> hmResult = new HashMap<String, Object>();

		HashMap<String, Object> convertFLAG = new HashMap<String, Object>();
		convertFLAG.put("LU", "UP");
		convertFLAG.put("LS", "AS");
		convertFLAG.put("LSD", "SD");
		convertFLAG.put("LDD", "DD");
		convertFLAG.put("LRI", "RI");
		convertFLAG.put("LH", "AH");
		convertFLAG.put("LA", "AA");
		convertFLAG.put("SQ", "SQ");
		convertFLAG.put("LLO", "LO"); // to get linked user's locks
		convertFLAG.put("MI", "MI"); // to get linked user's Identity info
		convertFLAG.put("DSLU", "DSLU"); // to get linkedUser info from DSLUSER table
		convertFLAG.put("DIALU", "DIALU"); // to get linkedUser info from DIALUSER table
		convertFLAG.put("PORTALU", "PORTALU"); // to get linkedUser info from PORTALUSER table
		convertFLAG.put("ISSU", "ISSU"); // to get linkedUser info from ISSUSER table
		convertFLAG.put("WIFIU", "WIFIU"); // to get linkedUser info from WIFIUSER table
		convertFLAG.put("LAI", "AI"); // to get linkedUser info from ACCOUNTINFO table
		convertFLAG.put("ISDNU", "ISDNU"); // to get linkedUser's email alias
		convertFLAG.put("LEA", "EA"); // to get linkedUser's email alias
		convertFLAG.put("LCO", "CO"); // to get linkedUser's CONTACT info
		convertFLAG.put("LAEP", "AEP");

		String stSlid = null;
		String stSlidMemberNum = null;
		String sAppInfo = null;
		String sAppStatusCode = null;

		ArrayList<Object> alSlidMaskInInp = null;
		ArrayList<Object> alSlidQueryMask = null;
		ArrayList<Object> alLinkedQueryMask = null;
		ArrayList<Object> alLinkedIdsData = null;

		log.info("{}{}DBTOOLS01 : CVS KEYWORDS: {}", CLASS_NAME, sMethodName, INFO);

		if (inputParamHs == null) {
			log.info("{}{}DBTOOLS002 : input hash is empty", CLASS_NAME, sMethodName);
			return hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, "Input hash is empty");
		}

		log.info("{}{}DBTOOLS000 : inputParamHs = {}", CLASS_NAME, sMethodName, inputParamHs);

		// get info from HashMap
		stSlid = (String) inputParamHs.get("slid");
		stSlidMemberNum = (String) inputParamHs.get("slid_member_num");
		alSlidMaskInInp = (ArrayList) inputParamHs.get("slidMask");
		String sQueryLinkedUsers = (String) inputParamHs.get(MPSDefs.QUERY_LINKED_USERS_FLAG);
		String sQueryFraudLock = (String) inputParamHs.get(MPSDefs.QUERY_FRAUD_LOCK_FLAG);
		String sQueryMemberSvcAttr = (String) inputParamHs.get(MPSDefs.QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG);
		String sQueryMemberFraudPwd = (String) inputParamHs.get("queryMemberFraudPassword"); 
		
		if (stSlid != null && stSlid.trim().length() > 0)
			stSlid = stSlid.trim().toLowerCase();

		if ((stSlid == null || stSlid.trim().length() <= 0)
				&& (stSlidMemberNum == null || stSlidMemberNum.trim().length() <= 0)) {
			sAppInfo = "slid as well as slid_member_num can not be null or empty in input";
			hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM, sAppInfo);
			log.info("{}{}DBTOOLS_02 : {}", CLASS_NAME, sMethodName, sAppInfo);
			return hmResult;
		}

		try {

			// Retrive SLID info first
			HashMap<String, Object> hmSLIDInfoInp = new HashMap<String, Object>();
			alSlidQueryMask = new ArrayList<Object>();

			// Flag Added for Search
			if (alSlidMaskInInp != null && alSlidMaskInInp.contains("SS")) {
				alSlidQueryMask.add("AA");
				alSlidQueryMask.add("AS");
			}

			if (alSlidMaskInInp != null && alSlidMaskInInp.contains("SR")) {
				alSlidQueryMask.add("RI");
			}

			if (alSlidMaskInInp != null && alSlidMaskInInp.contains("SLO")) {
				alSlidQueryMask.add("LO");
			}

			if (alSlidMaskInInp != null && alSlidMaskInInp.contains("CI")) {
				alSlidQueryMask.add("CI");
			}

			if (alSlidMaskInInp != null && alSlidMaskInInp.contains("SQ")) {
				alSlidQueryMask.add("SQ");
			}

			if (alSlidMaskInInp != null && alSlidMaskInInp.contains("SSC")) {
				alSlidQueryMask.add("SC");
			}

			if (alSlidMaskInInp != null && alSlidMaskInInp.contains("AD"))
				alSlidQueryMask.add("AD");

			if (alSlidMaskInInp != null && alSlidMaskInInp.contains("SLAD"))
				alSlidQueryMask.add("QLAD");

			if ((sQueryFraudLock != null && sQueryFraudLock.equals(MPSDefs.YES))
					|| (alSlidMaskInInp != null && alSlidMaskInInp.contains("QFLO"))) {
				alSlidQueryMask.add("QFLO");
			}

			if ((sQueryMemberSvcAttr != null && sQueryMemberSvcAttr.equals(MPSDefs.YES))
					|| (alSlidMaskInInp != null && alSlidMaskInInp.contains("QMSA"))) {
				alSlidQueryMask.add("QMSA");
			}

			// 1808 - Updated for PID 304635 SecMod UAM-7340 Update password rules - to
			// return MEMBERFRAUDPASSWORD details
			if ((sQueryMemberFraudPwd != null && sQueryMemberFraudPwd.equals(MPSDefs.YES))
					|| (alSlidMaskInInp != null && alSlidMaskInInp.contains("QMFP"))) {
				alSlidQueryMask.add("QMFP");
			} // END

			alSlidQueryMask.add("UP");
			hmSLIDInfoInp.put("dataMask", alSlidQueryMask);

			hmSLIDInfoInp.put(MPSDefs.DB_MEMBER_NAME, stSlid);
			hmSLIDInfoInp.put(MPSDefs.DB_DOMAIN_NAME, "slid.dum");
			hmSLIDInfoInp.put(MPSDefs.DB_SLID_MEMBER_NUM, stSlidMemberNum);
			hmSLIDInfoInp.put(MPSDefs.SOURCE_CALLER, "getSlidInfo");
			hmSLIDInfoInp.put("queryDIAL", CommonDefs.DEFAULT_NO);
			hmSLIDInfoInp.put("queryDSL", CommonDefs.DEFAULT_NO);
			hmSLIDInfoInp.put("queryWIFI", CommonDefs.DEFAULT_NO);
			hmSLIDInfoInp.put("queryISDN", CommonDefs.DEFAULT_NO);
			log.info("{}{}DBTOOLS004 : Input to GetInfoByMaskDBHelper.getInfoByMask {}", CLASS_NAME, sMethodName, hmSLIDInfoInp);
			hmResult = oGetInfoByMaskDBHelper.getInfoByMask(hmSLIDInfoInp);

			if (hmResult == null || hmResult.isEmpty()) {
				sAppInfo = "Response from GetInfoByMaskDBHelper.getInfoByMask() is null / empty";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				log.info("{}{}TMS10.2 : {}", CLASS_NAME, sMethodName, sAppInfo);
				return hmResult;
			}

			sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

			if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
				log.info("{}{}DBTOOLS005 : HashMap Returned from GetInfoByMaskDBHelper.getInfoByMask() {}", CLASS_NAME, sMethodName, hmResult);
				return hmResult;
			}

			log.info(SpiMarker.getInstance(),
					"{}{}DBTOOLS006 : HashMap Returned from GetInfoByMaskDBHelper.getInfoByMask() for SLID Query ",
					CLASS_NAME, sMethodName, StructuredArguments.entries(hmResult));

			HashMap hmSLIDMember = CommonUtil.getHashMap();
			ArrayList alSLIDLocks = null;
			if (hmResult.containsKey(MPSDefs.DB_MEMBERLOCKOUT))
				alSLIDLocks = (ArrayList) hmResult.get(MPSDefs.DB_MEMBERLOCKOUT);

			hmResult.remove(CommonDefs.COMMON_APP_CATEGORY_CODE);
			hmResult.remove(CommonDefs.COMMON_APP_STATUS_CODE);
			hmResult.remove(CommonDefs.COMMON_APP_STATUS_MSG);

			if (hmResult != null && !hmResult.isEmpty()) {
				hmSLIDMember.putAll(hmResult);
			}

			HashMap<String, Object> hmMemberResponse = null;
			HashMap<String, Object> hmInpMemberInfo = (HashMap<String, Object>) inputParamHs.get(MPSDefs.MEMBER_INFO);

			if (hmInpMemberInfo != null && !hmInpMemberInfo.isEmpty()) {
				HashMap<String, Object> hmDbInput = new HashMap<String, Object>();
				hmDbInput.put(MPSDefs.DB_MEMBER_NAME, hmInpMemberInfo.get(CommonDefs.HANDLE));
				hmDbInput.put(MPSDefs.DB_DOMAIN_NAME, hmInpMemberInfo.get(CommonDefs.DOMAIN));

				hmMemberResponse = oGetMemberServicesDBHelper.getMemberServices(hmDbInput);

				if (hmMemberResponse == null) {
					sAppInfo = "GetMemberServicesDBHelper.getMemberServices helper returned null.";
					log.info("{}{}DBTOOLS28 : {}", CLASS_NAME, sMethodName, sAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
					return hmResult;
				}

				sAppStatusCode = (String) hmMemberResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);

				if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
					if (sAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
						sAppInfo = "Input member info not found";
						log.info("{}{}DBTOOLS29 : {}", CLASS_NAME, sMethodName, sAppInfo);
					} else {
						hmResult.clear();
						hmResult.putAll(hmMemberResponse);
						return hmResult;
					}
				}
			}
			// end of ChangeSlid changes

			if (alSlidMaskInInp == null || alSlidMaskInInp.isEmpty() || !alSlidMaskInInp.contains("LU")) {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.REASON_CODE_SUCCESS);

				hmResult.put(CommonDefs.KEY_SLID_INFO, hmSLIDMember);

				// below 2 lines are for ChangeSlid
				if (hmMemberResponse != null) {
					sAppStatusCode = (String) hmMemberResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
					if (sAppStatusCode != null && sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
						hmResult.put(MPSDefs.MEMBER_INFO, hmMemberResponse);
				}

				return hmResult;
			}

			if (stSlidMemberNum == null || stSlidMemberNum.trim().length() == 0) {
				stSlidMemberNum = (String) hmSLIDMember.get(MPSDefs.DB_MEMBER_NUM);
			}

			// Retrive all Member Id linked to SLID
			objectList.add(stSlidMemberNum);

			long pTime = 0;
			Date dtQueryTime = new Date();
			log.info("{}{}DBTOOLS008 : Query start time", CLASS_NAME, sMethodName);

			log.info("{}{}DB3.1 : queryAccountLockout : {}", CLASS_NAME, sMethodName, queryLinkedIdsBySlidMemberNUM);

			alQueryResponse = jdbcTemplate.queryForList(new String(queryLinkedIdsBySlidMemberNUM),
					objectList.toArray(new Object[objectList.size()]));

			// pt637d - to return time in milliseconds for APRIL2011
			pTime = (System.currentTimeMillis() - dtQueryTime.getTime());
			log.info("{}{}QUERY999 : Total time taken to execute query = {} milliseconds", CLASS_NAME, sMethodName, pTime);

			ArrayList alLinkedMembers = new ArrayList();

			for (int j = 0; j < alQueryResponse.size(); j++) {
				Map hmQueryResponse = (Map) alQueryResponse.get(j);

				Iterator itr = hmQueryResponse.keySet().iterator();
				while (itr.hasNext()) {
					String key = (String) itr.next();
					Object value = hmQueryResponse.get(key);

					String strValue = (value == null ? null : value.toString());
					hmQueryResponse.put(key, strValue);
				}

				alLinkedMembers.add((String) hmQueryResponse.get(MPSDefs.DB_MEMBER_NUM));
			}

			log.info("{}{}DBTOOLS008.1 : linkedUsers list : {}", CLASS_NAME, sMethodName, alLinkedMembers);

			if (alLinkedMembers == null || alLinkedMembers.isEmpty()) {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.REASON_CODE_SUCCESS);

				hmResult.put(CommonDefs.KEY_SLID_INFO, hmSLIDMember);
				return hmResult;
			}

			// Convert Flag names for getInfoByMask
			alLinkedQueryMask = new ArrayList();
			for (int i = 0; i < alSlidMaskInInp.size(); i++) {
				if (convertFLAG.containsKey(alSlidMaskInInp.get(i)))
					alLinkedQueryMask.add(convertFLAG.get(alSlidMaskInInp.get(i)));
			}

			alLinkedIdsData = new ArrayList();

			// remove slid's member_num from linkedMembers list
			if (alLinkedMembers != null && alLinkedMembers.contains(stSlidMemberNum))
				alLinkedMembers.remove(stSlidMemberNum);

			for (int i = 0; i < alLinkedMembers.size(); i++) {
				HashMap<String, Object> hmLinkedInfoInp = CommonUtil.getHashMap();
				hmLinkedInfoInp.put("dataMask", alLinkedQueryMask);
				hmLinkedInfoInp.put(MPSDefs.DB_MEMBER_NUM, alLinkedMembers.get(i));
				hmLinkedInfoInp.put(MPSDefs.SOURCE_CALLER, "getSlidInfo");

				if (sQueryLinkedUsers != null)
					hmLinkedInfoInp.put(MPSDefs.QUERY_LINKED_USERS_FLAG, sQueryLinkedUsers);

				log.info("{}{}DBTOOLS009 : Input to GetInfoByMaskDBHelper.getInfoByMask {}", CLASS_NAME, sMethodName,
						hmLinkedInfoInp);
				hmResult = oGetInfoByMaskDBHelper.getInfoByMask(hmLinkedInfoInp);

				if (hmResult == null || hmResult.isEmpty()) {
					sAppInfo = "Response from GetInfoByMaskDBHelper.getInfoByMask() is null / empty";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
					log.info("{}{}TMS10.2 : {}", CLASS_NAME, sMethodName, sAppInfo);
					return hmResult;
				}

				sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

				if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
					log.info("{}{}DBTOOLS010 : HashMap Returned from GetInfoByMaskDBHelper.getInfoByMask() {}", CLASS_NAME, sMethodName, hmResult);
					if (!sAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND))
						return hmResult;
				}

				log.info(SpiMarker.getInstance(), "{}{}DBTOOLS011 : HashMap Returned from GetInfoByMaskDBHelper.getInfoByMask() ", CLASS_NAME, sMethodName, StructuredArguments.entries(hmResult));

				HashMap<String, Object> hmLinkedIds = CommonUtil.getHashMap();
				hmLinkedIds.putAll(hmResult);

				if (alSLIDLocks != null && !alSLIDLocks.isEmpty())
					hmLinkedIds.put(MPSDefs.DB_MEMBERLOCKOUT, alSLIDLocks);

				hmLinkedIds.remove(CommonDefs.COMMON_APP_STATUS_CODE);
				hmLinkedIds.remove(CommonDefs.COMMON_APP_CATEGORY_CODE);
				hmLinkedIds.remove(CommonDefs.COMMON_APP_STATUS_MSG);
				hmLinkedIds.remove(CommonDefs.COMMON_APP_INFO);

				if (hmLinkedIds != null && !hmLinkedIds.isEmpty())
					alLinkedIdsData.add(hmLinkedIds);
			}

			if (alLinkedIdsData != null && !alLinkedIdsData.isEmpty())
				hmSLIDMember.put("linkedUsers", alLinkedIdsData);

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.REASON_CODE_SUCCESS);
			hmResult.put(CommonDefs.KEY_SLID_INFO, hmSLIDMember);

			// added below for ChangeSlid
			if (hmMemberResponse != null) {
				sAppStatusCode = (String) hmMemberResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
				if (sAppStatusCode != null && sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
					hmResult.put(MPSDefs.MEMBER_INFO, hmMemberResponse);
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DBTOOLS013 : Error::{}", CLASS_NAME, sMethodName, e.getMessage());
			log.error("{}{}DBTOOLS014 : Exception = {}", CLASS_NAME, sMethodName, e);
		} finally {
			log.info(SpiMarker.getInstance(), "{}{}DBTOOLS999 : Response is : {}", CLASS_NAME, sMethodName, hmResult);
		}
		return hmResult;
	}
}