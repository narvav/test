package com.att.idp.idgraphusermanagementms.db.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.mpsys.common.utils.PropertyManager;
import com.att.idp.idgraphusermanagementms.helper.voltage.VoltageEncryptionHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This class is responsible for managing member fraud password data in the database.
 * It uses Spring's JdbcTemplate for database operations.
 *
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like JdbcTemplate and VoltageEncryptionHelper.
 *
 * The class contains methods for merging, adding, deleting, and querying member fraud password data in the database.
 */
@Component
public class MemberFraudPasswordDBHelper {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private VoltageEncryptionHelper oVoltageEncryptionH;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;
	
	private static String sClassName = "MemberFraudPasswordDBHelper";
	public static final Logger log = LoggerFactory.getLogger(MemberFraudPasswordDBHelper.class);

	/**
	 * This method merges a member's fraud password data in the database.
	 * It takes a HashMap as input which contains key-value pairs for various member attributes like member number and last modified by.
	 * The method first checks if the input HashMap is null. If it is, it returns an error status.
	 * Then it retrieves the member attributes from the input HashMap.
	 * If the member attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param hmInput A HashMap containing the details of the member's fraud password information to be merged.
	 * @return A HashMap containing the status of the operation and the merged member's fraud password information.
	 */
	public HashMap mergeMemberFraudPwd(HashMap hmInput) {
		String sMethodName = ".mergeMemberFraudPwd.";
		String stAppInfo = null;
		HashMap hmResult = null;
		Date dtStartDate = new Date();
		List<Object> objectList = CommonUtil.getArrayList();

		log.info("{}{}DBTOOLS000 : hmInput = {}", sClassName, sMethodName, 
				(hmInput != null ? StringUtils.normalizeSpace(hmInput.toString()) : "null"));

		try {
			if (hmInput == null) {
				stAppInfo = "hmInput is null";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}DB_MM_03 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			String sToSlidMemberNum = (String) hmInput.get("toslid_member_num");
			String sFromSlidMemberNum = (String) hmInput.get("fromslid_member_num");

			if (sToSlidMemberNum == null || sToSlidMemberNum.isEmpty() || sFromSlidMemberNum == null
					|| sFromSlidMemberNum.isEmpty()) {
				stAppInfo = "Required Parameter ToSlidMemberNum / ToSlidMemberNum is missing";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}DB_MM_04 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			String sSql = "INSERT INTO MEMBERFRAUDPASSWORD (MEMBER_NUM, FRAUD_COUNTER, PASSWORD_TYPE, PASSWORD_VENC, LAST_MODIFIED_BY) "
					+ " SELECT ? , mfp_fromslid.FRAUD_COUNTER + NVL(( SELECT MAX(mfp_toslid.FRAUD_COUNTER) "
					+ " FROM MEMBERFRAUDPASSWORD mfp_toslid "
					+ " WHERE mfp_toslid.MEMBER_NUM = ? ), 0) fraud_counter_old, "
					+ " mfp_fromslid.PASSWORD_TYPE password_type_old, "
					+ " mfp_fromslid.PASSWORD_VENC password_venc_old, "
					+ " mfp_fromslid.LAST_MODIFIED_BY last_modified_by_old " + " FROM MEMBERFRAUDPASSWORD mfp_fromslid "
					+ " WHERE MEMBER_NUM = ? ";

			log.info("{}{}DB_MM_08 : Query SQL = {}", sClassName, sMethodName, sSql);

			objectList.add(sToSlidMemberNum);
			log.info("{}{}DB_MM_05 : sToSlidMemberNum::PARAM 1 = {}", sClassName, sMethodName, sToSlidMemberNum);

			objectList.add(sToSlidMemberNum);
			log.info("{}{}DB_MM_06 : sToSlidMemberNum::PARAM 2 = {}", sClassName, sMethodName, sToSlidMemberNum);

			objectList.add(sFromSlidMemberNum);
			log.info("{}{}DB_MM_07 : sFromSlidMemberNum::PARAM 3 = {}", sClassName, sMethodName, sFromSlidMemberNum);

			int rowCount = jdbcTemplate.update(new String(sSql), objectList.toArray(new Object[objectList.size()]));

			log.info("{}{}DB_MM_09 : No of rows inserted := {}", sClassName, sMethodName, rowCount);
			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DB_MM_24 : Error::{}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}DB_MM_25 : Exception = {}", sClassName, sMethodName, e);
		} finally {
			log.info("{}{}DBTOOLS999 : {} response : {}", sClassName, sMethodName, dtStartDate.getTime(), hmResult);
		}
		return hmResult;
	}

	/**
	 * This method adds a member's fraud password data to the database.
	 * It takes a HashMap as input which contains key-value pairs for various member attributes like member number and last modified by.
	 * The method first checks if the input HashMap is null. If it is, it returns an error status.
	 * Then it retrieves the member attributes from the input HashMap.
	 * If the member attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param hmInput A HashMap containing the details of the member's fraud password information to be added.
	 * @return A HashMap containing the status of the operation and the added member's fraud password information.
	 */
	public HashMap addMemberFraudPwd(HashMap hmInput) {
		String sMethodName = ".addMemberFraudPwd.";
		String stAppInfo = null;
		HashMap hmResult = null;
		Date dtStartDate = new Date();
		List<Object> objectList = CommonUtil.getArrayList();

		log.info("{}{}DBTOOLS000 : hmInput = {}", sClassName, sMethodName, 
				(hmInput != null ? StringUtils.normalizeSpace(hmInput.toString()) : "null"));

		try {
			if (hmInput == null) {
				stAppInfo = "hmInput is null";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}DB_MM_03 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			String stDBSlidMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
			String stCallingSytemId = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);

			if (stDBSlidMemberNum == null || stDBSlidMemberNum.isEmpty() || stCallingSytemId == null
					|| stCallingSytemId.isEmpty()) {
				stAppInfo = "Required Parameter member_num / last_modified_by is missing";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}DB_MM_04 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			//2011 - Revert SSHA-256 encryption changes		
			String sPasswordType = PropertyManager.getProperty(CommonDefs.MSConfig, CommonDefs.GENERIC_PASSWORD_ENCRYPTION_TYPE);
			String sSql = null;
			 
			if (sPasswordType !=null && !sPasswordType.trim().isEmpty()) {
				log.info("{}{}DB_MM_04.1 :GENERIC_PASSWORD_ENCRYPTION_TYPE Flag is ON {}", sClassName, sMethodName, stAppInfo);
				 sSql = "INSERT INTO MEMBERFRAUDPASSWORD (MEMBER_NUM, FRAUD_COUNTER, PASSWORD_TYPE, PASSWORD_VENC, LAST_MODIFIED_BY) SELECT m.MEMBER_NUM, "
							+ " ( SELECT NVL(MAX(FRAUD_COUNTER), 0) + 1 FROM MEMBERFRAUDPASSWORD mfp WHERE mfp.MEMBER_NUM=ma.MEMBER_NUM ) FRAUD_COUNTER, "
							+ " NVL2(password_venc, '" + sPasswordType
							+ "', NVL2 (MD5_PASSWORD_VENC, 'MD5', NVL2 (SHA1_PASSWORD_VENC, 'SHA1', NVL2 (DES3_PASSWORD_VENC, 'DES3', NVL2 (SSHA_PASSWORD_VENC, 'SSHA', 'ENC') ) ) )) PASSWORD_TYPE, "
							+ " NVL2(PASSWORD_VENC, password_venc, NVL2( MD5_PASSWORD_VENC, MD5_PASSWORD_VENC, NVL2( SHA1_PASSWORD_VENC, SHA1_PASSWORD_VENC, NVL2( DES3_PASSWORD_VENC, DES3_PASSWORD_VENC, NVL2( SSHA_PASSWORD_VENC, SSHA_PASSWORD_VENC, ENC_PASSWORD_VENC)) ) )) PASSWORD_VENC, "
							+ " ? calling_system_id FROM MEMBERAUX ma, member m WHERE m.MEMBER_NUM = ? and m.member_num = ma.member_num and nvl(m.password_dirty, 'N') = 'N'";
					 
			} else{
				 sSql = "INSERT INTO MEMBERFRAUDPASSWORD (MEMBER_NUM, FRAUD_COUNTER, PASSWORD_TYPE, PASSWORD_VENC, LAST_MODIFIED_BY) SELECT m.MEMBER_NUM, "
						+ " ( SELECT NVL(MAX(FRAUD_COUNTER), 0) + 1 FROM MEMBERFRAUDPASSWORD mfp WHERE mfp.MEMBER_NUM=ma.MEMBER_NUM ) FRAUD_COUNTER, "
						+ " NVL2 (MD5_PASSWORD_VENC, 'MD5', NVL2 (SHA1_PASSWORD_VENC, 'SHA1', NVL2 (DES3_PASSWORD_VENC, 'DES3', NVL2 (SSHA_PASSWORD_VENC, 'SSHA', 'ENC') ) ) ) PASSWORD_TYPE, "
						+ " NVL2( MD5_PASSWORD_VENC, MD5_PASSWORD_VENC, NVL2( SHA1_PASSWORD_VENC, SHA1_PASSWORD_VENC, NVL2( DES3_PASSWORD_VENC, DES3_PASSWORD_VENC, NVL2( SSHA_PASSWORD_VENC, SSHA_PASSWORD_VENC, ENC_PASSWORD_VENC)) ) ) PASSWORD_VENC, "
						+ " ? calling_system_id FROM MEMBERAUX ma, member m WHERE m.MEMBER_NUM = ? and m.member_num = ma.member_num and nvl(m.password_dirty, 'N') = 'N'";
			}			
			
			log.info("{}{}DB_MM_08a : Query SQL = {}", sClassName, sMethodName, sSql);

			objectList.add(stCallingSytemId);
			log.info("{}{}DB_MM_05 : stCallingSytemId::PARAM 1 = {}", sClassName, sMethodName, stCallingSytemId);

			objectList.add(stDBSlidMemberNum);
			log.info("{}{}DB_MM_06 : stDBSlidMemberNum::PARAM 2 = {}", sClassName, sMethodName, stDBSlidMemberNum);

			int rowCount = jdbcTemplate.update(new String(sSql), objectList.toArray(new Object[objectList.size()]));

			log.info("{}{}DB_MM_08 : No of rows inserted := {}", sClassName, sMethodName, rowCount);
			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DB_MM_24 : Error::{}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}DB_MM_25 : Exception = {}", sClassName, sMethodName, e);
		} finally {
			log.info("{}{}DBTOOLS999 : {} response : {}", sClassName, sMethodName, dtStartDate.getTime(), hmResult);
		}
		return hmResult;
	}

	/**
	 * This method deletes a member's fraud password data from the database.
	 * It takes a HashMap as input which contains key-value pairs for various member attributes like member number.
	 * The method first checks if the input HashMap is null. If it is, it returns an error status.
	 * Then it retrieves the member number from the input HashMap.
	 * If the member number is not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param hmInput A HashMap containing the details of the member's fraud password information to be deleted.
	 * @return A HashMap containing the status of the operation and the deleted member's fraud password information.
	 */
	public HashMap deleteMemberFraudPwd(HashMap hmInput) {
		String sMethodName = ".deleteMemberFraudPwd.";
		String stAppInfo = null;
		HashMap hmResult = null;
		List<Object> objectList = CommonUtil.getArrayList();
		Date dtStartDate = new Date();

		log.info("{}{}DBTOOLS000 : hmInput = {}", sClassName, sMethodName, 
				(hmInput != null ? StringUtils.normalizeSpace(hmInput.toString()) : "null"));

		try {
			if (hmInput == null) {
				stAppInfo = "InpParam is null";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}DB_DM_32 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			String stMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);

			if (stMemberNum == null || stMemberNum.isEmpty()) {
				stAppInfo = "Required Parameter member_num / last_modified_by is missing";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}DB_AM_33 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			String sSql = "DELETE FROM MEMBERFRAUDPASSWORD" + " WHERE MEMBER_NUM = ?";

			log.info("{}{}DB_AM_33a : Query SQL = {}", sClassName, sMethodName, sSql);

			objectList.add(stMemberNum);
			log.info("{}{}DB_DM_34 : stMemberNum::PARAM 1 = {}", sClassName, sMethodName, stMemberNum);

			int rowCount = jdbcTemplate.update(new String(sSql), objectList.toArray(new Object[objectList.size()]));

			log.info("{}{}DB_DM_35 : No of rows inserted := {}", sClassName, sMethodName, rowCount);
			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DB_DM_36 :  Error::{}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}DB_DM_37 : Exception = {}", sClassName, sMethodName, e);
		} finally {
			log.info("{}{}DBTOOLS999 : {} response : {}", sClassName, sMethodName, dtStartDate.getTime(), hmResult);
		}
		return hmResult;
	}

	/**
	 * This method queries a member's fraud password data from the database.
	 * It takes a HashMap as input which contains key-value pairs for various member attributes like member number.
	 * The method first checks if the input HashMap is null. If it is, it returns an error status.
	 * Then it retrieves the member number from the input HashMap.
	 * If the member number is not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * The method also handles the decryption of the password using the VoltageEncryptionHelper.
	 * Finally, it returns a HashMap containing the status of the operation and the queried member's fraud password information.
	 *
	 * @param hmInput A HashMap containing the details of the member's fraud password information to be queried.
	 * @return A HashMap containing the status of the operation and the queried member's fraud password information.
	 */
	public HashMap queryMemberFraudPwd(HashMap hmInput) {
		String sMethodName = ".queryMemberFraudPwd.";
		String stAppInfo = null;
		HashMap hmResult = null;
		List alQueryResponse = null;
		List<Object> objectList = CommonUtil.getArrayList();
		Date dtStartDate = new Date();
		String dateFormat = "MMDDYYYY HH24:mi:ss";
		
		log.info("{}{}DBTOOLS000 : Inputhash = {}", sClassName, sMethodName, 
				(hmInput != null ? StringUtils.normalizeSpace(hmInput.toString()) : "null"));

		try {
			if (hmInput == null || hmInput.isEmpty()) {
				stAppInfo = "InpParam received in queryMemberFraudPwd input is null";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}DBTOOLS_03 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			String stMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);

			if (stMemberNum == null || stMemberNum.trim().length() <= 0) {
				stAppInfo = "Required Parameter member_num is missing";
				log.info("{}{}MPSDBLRH_002 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			String sQuery = "SELECT " + "member_num, " + "fraud_counter, " + "password_type, " + "password_venc, "
					+ "TO_CHAR(create_date, '" + dateFormat + "') AS create_date, " + "TO_CHAR(last_modified, '"
					+ dateFormat + "') AS last_modified, " + "last_modified_by "
					+ "FROM memberfraudpassword WHERE member_num = ?";

			log.info("{}{}DBTOOLS_04.5 : Query SQL = {}", sClassName, sMethodName, sQuery);

			objectList.add(stMemberNum);

			alQueryResponse = jdbcTemplate.queryForList(new String(sQuery),
					objectList.toArray(new Object[objectList.size()]));

			ArrayList alMemberFraudPwd = CommonUtil.getArrayList();

			if (alQueryResponse != null && !alQueryResponse.isEmpty()) {
				for (int j = 0; j < alQueryResponse.size(); j++) {
					Map hmQueryResponse = (Map) alQueryResponse.get(j);
					Iterator itr = hmQueryResponse.keySet().iterator();
					while (itr.hasNext()) {
						String key = (String) itr.next();
						Object value = hmQueryResponse.get(key);
						String strValue = (value == null ? null : value.toString());
						hmQueryResponse.put(key, strValue);
					}

					String sPasswordVenc = null;
					String sPasswordType = null;
					String sDecryptedPassword = null;
					sPasswordVenc = (String) hmQueryResponse.get(MPSDefs.DB_PASSWORD_VENC);
					sPasswordType = (String)hmQueryResponse.get(MPSDefs.DB_PASSWORD_TYPE);
					String genericPasswordEncryptionType = PropertyManager.getProperty(CommonDefs.MSConfig, CommonDefs.GENERIC_PASSWORD_ENCRYPTION_TYPE);
					HashMap hmVoltageDecrypt = CommonUtil.getHashMap();
					
					if (genericPasswordEncryptionType != null && !genericPasswordEncryptionType.trim().isEmpty()
							&& sPasswordType != null && !sPasswordType.isEmpty()
							&& sPasswordType.equals(genericPasswordEncryptionType)) {
						hmVoltageDecrypt.put(MPSDefs.DB_GEN_PASSWORD_VENC, sPasswordVenc);
					} else {
						hmVoltageDecrypt.put(MPSDefs.DB_MD5_PASSWORD_VENC, sPasswordVenc);
					}
					hmResult = oVoltageEncryptionH.getEFPEDecryptedValues(hmVoltageDecrypt);

					if (hmResult == null || hmResult.isEmpty()) {
						stAppInfo = "Null response from VoltageEncryption_H.getEFPEDecryptedValues method";
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
						log.info("{}{}DBTOOLS_04.5a : {}", sClassName, sMethodName, stAppInfo);
						return hmResult;
					}

					String sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
					if (!CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode)) {
						hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(sAppStatusCode), stAppInfo);
						log.info("{}{}DBTOOLS_04.5b : Error from VoltageEncryption_H.getEFPEDecryptedValues call {}", sClassName, sMethodName, hmResult);
						return hmResult;
					}

					if (genericPasswordEncryptionType != null && !genericPasswordEncryptionType.trim().isEmpty()
							&& sPasswordType != null && !sPasswordType.isEmpty()
							&& sPasswordType.equals(genericPasswordEncryptionType)) {
						sDecryptedPassword = (String) hmResult.get(MPSDefs.DB_GEN_PASSWORD_VENC);
					} else {
						sDecryptedPassword = (String) hmResult.get(MPSDefs.DB_MD5_PASSWORD_VENC);
					}

					HashMap<String, Object> hmMemberFraudPwd = CommonUtil.getHashMap();

					hmMemberFraudPwd.put(MPSDefs.DB_MEMBER_NUM, (String) hmQueryResponse.get(MPSDefs.DB_MEMBER_NUM));
					hmMemberFraudPwd.put("fraud_counter", (String) hmQueryResponse.get("fraud_counter"));
					hmMemberFraudPwd.put("password_type", (String) hmQueryResponse.get("password_type"));
					hmMemberFraudPwd.put(MPSDefs.DB_PASSWORD_VENC, sDecryptedPassword);
					hmMemberFraudPwd.put(MPSDefs.DB_CREATE_DATE, (String) hmQueryResponse.get(MPSDefs.DB_CREATE_DATE));
					hmMemberFraudPwd.put(MPSDefs.DB_LAST_MODIFIED,
							(String) hmQueryResponse.get(MPSDefs.DB_LAST_MODIFIED));
					hmMemberFraudPwd.put(MPSDefs.DB_LAST_MODIFIED_BY,
							(String) hmQueryResponse.get(MPSDefs.DB_LAST_MODIFIED_BY));

					alMemberFraudPwd.add(hmMemberFraudPwd);
				}
			}

			if (alMemberFraudPwd.isEmpty()) {
				stAppInfo = "No Record Found in DB";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
						CErrorDefs.ERR_REC_NOT_FOUND_MSG);
				log.info("{}{}DBTOOLS_04.8 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
			hmResult.put("memberfraudpassword", alMemberFraudPwd);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DB_UPLR_06 : Error::{}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}DB_UPLR_07 : Exception = {}", sClassName, sMethodName, e);
		} finally {
			log.info("{}{}DBTOOLS999 : {} response : {}", sClassName, sMethodName, dtStartDate.getTime(), hmResult);
		}
		return hmResult;
	}
}
