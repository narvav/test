package com.att.idp.idgraphusermanagementms.db.model;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the TUSERMERGE database table.
 */
@Entity
@Table(name = "TUSERMERGE", schema = "MPS_OWNER")
@Getter
@Setter
@NoArgsConstructor
public class Tusermerge implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "CREATE_DATE")
	private Date createDate;

	@Column(name = "LAST_MODIFIED_BY")
	private String lastModifiedBy;

	@Column(name = "SOURCE_MEMBER_NAME")
	private String sourceMemberName;

	@Id
	@Column(name = "SOURCE_MEMBER_NUM")
	private Long sourceMemberNum;

	@Column(name = "TARGET_MEMBER_NAME")
	private String targetMemberName;

	@Column(name = "TARGET_MEMBER_NUM")
	private Long targetMemberNum;
}