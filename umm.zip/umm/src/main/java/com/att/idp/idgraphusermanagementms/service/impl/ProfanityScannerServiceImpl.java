package com.att.idp.idgraphusermanagementms.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.resource.request.ProfanityScannerRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ProfanityScannerResponse;
import com.att.idp.idgraphusermanagementms.service.ProfanityScannerService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.helpers.BadWordHelper;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

import jakarta.ws.rs.core.MultivaluedMap;
/**
 * This is the ProfanityScannerServiceImpl class. It implements the ProfanityScannerService interface.
 * The class contains a profanityScanner method which calls the scanWords method of badWordHelper class and
 * checks for profanity words in the given scanItem.
 */
@Service
@Transactional(readOnly = true, value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class ProfanityScannerServiceImpl implements ProfanityScannerService {

    public static final Logger logger = LoggerFactory.getLogger(ProfanityScannerServiceImpl.class);

    private static String sClassName = "ProfanityScannerServiceImpl";
    @Qualifier("badWordHelper")
    @Autowired
    private BadWordHelper badWordHelper;
    /**
     * This is the implementation of the profanityScanner method from the ProfanityScannerService interface.
     * It checks for profanity words in the given scanItem.
     *
     * @param profanityScannerRequest This is the request body. It should be a valid instance of ProfanityScannerRequest.
     * @param requestHeader This is the HTTP headers from the request.
     * @return A ProfanityScannerResponse object. The response contains the result of the profanity check.
     * @throws InvalidInputDataException This exception is thrown if there is an error during the processing of the request.
     */
    @Override
    public ProfanityScannerResponse profanityScanner(ProfanityScannerRequest profanityScannerRequest, MultivaluedMap<String, String> requestHeader){
        ProfanityScannerResponse profanityScannerResponse = null;
        Map<String, Object> hmResponse = null;
        String sMethodName = ".profanityScanner.";

        logger.info(SpiMarker.getInstance(),"{}{}CAS_01 : Calling BadWordHelper with Input : {}", StringUtils.normalizeSpace(String.valueOf(profanityScannerRequest)));

        Map<String, Object> hmInput = CommonUtilHelper.objectToMap(profanityScannerRequest);
        if(profanityScannerRequest.getScanItemType().equals("userid")){
            hmInput.put(CommonDefs.ITEM_TYPE,CommonDefs.HANDLE );
        }else{
            hmInput.put(CommonDefs.ITEM_TYPE, profanityScannerRequest.getScanItemType());
        }
        hmInput.put(CommonDefs.ITEM, profanityScannerRequest.getScanItem());

        if(ProfileOrchestrationConstants.EMAIL_SMS_MSG.equalsIgnoreCase(profanityScannerRequest.getScanItemType())){
            hmResponse = badWordHelper.scanEmailSMSMsg(hmInput, logger);
        }else{
            hmResponse = badWordHelper.scanWords((HashMap) hmInput,logger);
        }

        logger.info("{}{}CAS_02 : Response from badWordHelper : {}", sClassName, sMethodName, hmResponse);

        if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
            hmResponse = CommonUtilHelper.sysErrorHashMap("Null / Empty response from badWordHelper");
            logger.info("{}{}CAS_03 : Null / Empty response from badWordHelper ", sClassName, sMethodName);
        } else {
            String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
            if (stAppStatusCode == null) {
                hmResponse = CommonUtilHelper.sysErrorHashMap("AppStatusCode null from badWordHelper");
                logger.info("{}{}CAS_04 : AppStatusCode null response from badWordHelper ", sClassName, sMethodName);
            }
        }

        hmResponse.put("idp-trace-id", profanityScannerRequest.getIdpTraceId());
        profanityScannerResponse = CommonUtilHelper.generateProfanityScannerResponse(hmResponse);
        
        logger.info("{}{}CAS_05 : Response from ProfanityScannerServiceImpl.profanityScanner : {}", sClassName, sMethodName,
                profanityScannerResponse);
        return profanityScannerResponse;
    }
}