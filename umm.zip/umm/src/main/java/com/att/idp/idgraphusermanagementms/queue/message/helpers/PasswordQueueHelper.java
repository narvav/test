package com.att.idp.idgraphusermanagementms.queue.message.helpers;

import com.att.idp.idgraphusermanagementms.queue.message.sender.JMSQueueSender;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.helpers.ConvertServicesHelper;
import com.att.mpsys.common.helpers.FeatureManagerHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Component
public class PasswordQueueHelper {

	public static final Logger log = LoggerFactory.getLogger(PasswordQueueHelper.class);

    private static final String IDGRAPH_USER_MANAGEMENT_MS = "IDGraphUserManagementMS-";

    public static final String RESET_EVENT_TYPE = "ResetUserPassword";
    public static final String UPDATE_EVENT_TYPE = "UpdateUserPassword";

    @Autowired
    FeatureManagerHelper featureManager;

	@Autowired
	private ConvertServicesHelper oConvertServicesHelper;

    @Autowired
    private PublishMqAehHelper publishMqAehHelper;

    private static final String ERROR_ENUM = "ErrorEnum";
	private String sClassName = "PasswordQueueHelper";

    public Map<String, Object> sendMessageToMQ(Map<String, Object> hmInput, Map<String, Object> hmDBMemberInfo,  ArrayList<Map<String, Object>> alEventData, String sEventType) {

		String sMethodName = ".sendMessageToMQ.";
		String stAppInfo;
		String stAppStatusCode = null;
        Map<String, Object> hmResult = CommonUtil.getHashMap();

		HashMap hmDbusInput = CommonUtil.getHashMap();
		String sSlidMemberNumber = (String) hmDBMemberInfo.get(MPSDefs.DB_SLID_MEMBER_NUM);

        final String RESET_PASSWORD_AEH_FEATURE_KEY = "cfg-idgraph-resetuserpassword-mq-aeh-switch";
        final String RESET_PASSWORD_CLM_FEATURE_KEY = "cfg-idgraph-resetuserpassword-notification-clm-switch";

        final String UPDATE_PASSWORD_AEH_FEATURE_KEY = "cfg-idgraph-updateuserpassword-mq-aeh-switch";
        final String UPDATE_PASSWORD_CLM_FEATURE_KEY = "cfg-idgraph-updateuserpassword-notification-clm-switch";

        final String AEH = "AEH";
        final String MQ = "MQ";
        final String BOTH = "BOTH";

        // TODO updates for updateUserPassword
        if (null != sSlidMemberNumber) {
            hmDbusInput.put("mainHashKey", hmDBMemberInfo.get(MPSDefs.DB_SLID_MEMBER_NUM));
        } else {
            hmDbusInput.put("mainHashKey", hmDBMemberInfo.get(MPSDefs.DB_MEMBER_NUM));
        }

		// common entries for both reset and update user password
		hmDbusInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
		hmDbusInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
		hmDbusInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
		hmDbusInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		hmDbusInput.put(CommonDefs.EVENTNAME, CommonDefs.MICRO_SERVICE_EVENT);
		hmDbusInput.put(CommonDefs.MS_OPERTAION, hmInput.get(CommonDefs.TRANSACTION_NAME));
		hmDbusInput.put(CommonDefs.EVENTS_DATA, alEventData);


		String sCallDbus = (String) hmInput.get(CommonDefs.CALLDBUS);

		if (sCallDbus != null && sCallDbus.equals(CommonDefs.IND_N)) {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "SUCCESS");
			hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
			hmResult.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, hmDbusInput);
			return hmResult;
		}

//		log.info(SpiMarker.getInstance(),"PasswordQueueHelper.sendMessageToMQ.PQH_01 : Calling JMSQueueSender with inputHash : {}", hmDbusInput);
//		hmResult = (HashMap) oJMSQueueSender.send((Map) hmDbusInput);
//		log.info("{}{}PQH_02 : ResponseHash from JMSQueueSender : {}", sClassName, sMethodName,HtmlUtils.htmlEscape(String.valueOf(hmResult)));

        String sAEHFeatureKey = null;
        String sCLMFeatureKey = null;

        if(RESET_EVENT_TYPE.equalsIgnoreCase(sEventType)) {
            sAEHFeatureKey = RESET_PASSWORD_AEH_FEATURE_KEY;
            sCLMFeatureKey = RESET_PASSWORD_CLM_FEATURE_KEY;
        }else if(UPDATE_EVENT_TYPE.equalsIgnoreCase(sEventType)) {
            sAEHFeatureKey = UPDATE_PASSWORD_AEH_FEATURE_KEY;
            sCLMFeatureKey = UPDATE_PASSWORD_CLM_FEATURE_KEY;
        }else { // early exit, event type not matched
            log.error("{}{} PQH_00 : Feature keys for MQ AEH and CLM switches are not properly configured for event type: {}", sClassName, sMethodName, sEventType);
            stAppInfo = "Feature keys for MQ AEH and CLM switches are not properly configured for eventType: " + sEventType;
            hmResult = CommonErrorMap.makeCategoryMap(Integer.valueOf(CErrorDefs.ERR_INVALID_DATA), stAppInfo);
            log.info("{}{}PQH_03.01 : {}", sClassName, sMethodName, stAppInfo);
            return hmResult;
        }

        log.info("{}{} ixp AEHFeature: {} and CLMFeature: {}", sClassName, sMethodName, sAEHFeatureKey, sCLMFeatureKey);

        //mq aeh switch
        String sPWMQAEHEnabled = featureManager.getValue(sAEHFeatureKey);
        sPWMQAEHEnabled = (sPWMQAEHEnabled != null && !sPWMQAEHEnabled.isEmpty()) ? sPWMQAEHEnabled : MQ;
        log.info("{}{} ixp flag addSecMemberIdMQAEHEnabled MQ AEH Value: {}", sClassName, sMethodName, ESAPI.encoder().encodeForHTML(sPWMQAEHEnabled));


        //clm switch
        String sPWClmEnabled = featureManager.getValue(sCLMFeatureKey);
        sPWClmEnabled = (sPWClmEnabled != null && !sPWClmEnabled.isEmpty()) ? sPWClmEnabled : MQ;
        log.info("{}{} ixp flag addsecmemberid CLM Value: {}", sClassName,sMethodName, ESAPI.encoder().encodeForHTML(sPWClmEnabled));

        log.info("{}{} ixp flag password change sPWMQAEHEnabled: {} , sPasswordClmEnabled : {}, alEventData.size : {} ", sClassName,sMethodName,
                ESAPI.encoder().encodeForHTML(sPWMQAEHEnabled), ESAPI.encoder().encodeForHTML(sPWClmEnabled),
                alEventData == null ? "null" : alEventData.size());

// helper method
        hmResult = publishMqAehHelper.invokeMqAEH(hmDbusInput, hmInput, alEventData, sClassName, sMethodName, sPWMQAEHEnabled, sPWClmEnabled);

		if (MapUtils.isEmpty(hmResult)) {
			stAppInfo = "Null Response returned from JMSQueueSender.send";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			log.info("{}{}PQH_03.03 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

		if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {

			stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
			log.info("{}{}PQH_04 : ", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
			hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
			return hmResult;
		} else {
			hmResult.put("isTransactionRollback", true);
		}

		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;

	}


	/**
	 * This method is used to build a notification hash map. It takes three HashMaps
	 * as input. The first HashMap contains input parameters for the method, the
	 * second HashMap contains information about the member from the database, and
	 * the third HashMap contains additional input parameters for the notification.
	 * The method processes the input parameters and member information, and
	 * constructs a notification hash map. The notification hash map contains
	 * various details required for sending a notification, such as the event name,
	 * dictionary name, transaction details, member details, and service details.
	 * The method also handles various conditions and scenarios, such as the
	 * presence of service types, the domain of the member, and the status of the
	 * member. It returns the constructed notification hash map.
	 *
	 * @param hmInput               HashMap containing the input parameters for the
	 *                              method.
	 * @param hmDBGetMemberServices HashMap containing the member information from
	 *                              the database.
	 * @param hmInputNotification   HashMap containing additional input parameters
	 *                              for the notification.
	 * @return HashMap containing the constructed notification hash map.
	 */
	public HashMap buildNotificationHash(HashMap hmInput, HashMap hmDBGetMemberServices, HashMap hmInputNotification) {
		String sMethodName = ".buildNotificationHash.";
		String sAppInfo = null;
		String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
		String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
		HashMap hmResponse = null;

		String SERVICES = "SERVICES";
		String SERVICE_TYPES = "SERVICE_TYPES";
		String SERVICE_LEVEL_SORS = "SERVICE_LEVEL_SORS";
		String CPNI_LINKED_TO_SLID = "isCPNILinkedToSLID";

		String sDBMemberNum = (String) hmDBGetMemberServices.get(MPSDefs.DB_MEMBER_NUM);
		String sSlidMemberNum = (String) hmDBGetMemberServices.get(MPSDefs.DB_SLID_MEMBER_NUM);
		String sSorName = (String) hmDBGetMemberServices.get(MPSDefs.DB_SOR_NAME);
		String sActivatedInd = (String) hmDBGetMemberServices.get(MPSDefs.DB_ACTIVATED_IND);
		String sInputMemberNum = (String) hmInput.get(CommonDefs.MEMBER_NUM);

		log.info(SpiMarker.getInstance(), sClassName + sMethodName + "BNH-1 : input hash : {}",
				(hmInput != null ? StringUtils.normalizeSpace(hmInput.toString()) : "null"));
		log.debug(sClassName + sMethodName + "BNH-1-RM : hmDBGetMemberServices= " + hmDBGetMemberServices);

		String dbusEvent = CommonDefs.CONTEXT_EDDHPRTYPwdNotification;
		String dbusDictionary = "Dict";

		if (dbusEvent.equals(CommonDefs.DBUS_EVENT_NONE)) {
			log.info(sClassName + sMethodName + "BNH-4 : dbusEvent=NONE " + hmResponse);
			hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS);
			return hmResponse;
		}

		String sProcessSlid = (String) hmInput.get("processSlid");
		sProcessSlid = (sProcessSlid == null) ? CommonDefs.DEFAULT_YES : sProcessSlid;

		String sSubEvent = null;
		if (sSlidMemberNum != null && sDBMemberNum.equals(sSlidMemberNum))
			sSubEvent = CommonDefs.DBUS_NOTIFICATION_SUBEVENT_SLID;
		else if (sSorName.equals(CommonDefs.SOR_COLA) || sSorName.equals(CommonDefs.SOR_CPR)
				|| sSorName.equals(CommonDefs.SOR_NA))
			sSubEvent = CommonDefs.DBUS_NOTIFICATION_SUBEVENT_ECOMM;
		else if (dbusEvent.equals(CommonDefs.CONTEXT_EDDHPRTYPwdNotification)
				&& sTransactionName.equals(CommonDefs.TRANS_NAME_RESET_PWD)) {
			if (sSorName.equals(CommonDefs.SOR_LS) && hmDBGetMemberServices.get(MPSDefs.DB_BAN) != null) {
				sSubEvent = CommonDefs.DBUS_NOTIFICATION_SUBEVENT_UVERSE;
			} else {
				sSubEvent = CommonDefs.DBUS_NOTIFICATION_SUBEVENT_ISP;
			}
		}

		HashMap hmNotificationInput = new HashMap();
		hmNotificationInput.put(CommonDefs.EVENTNAME, dbusEvent);
		hmNotificationInput.put(CommonDefs.DBUS_DICTIONARY_NAME, dbusDictionary);

		hmNotificationInput.put(CommonDefs.HANDLE, hmDBGetMemberServices.get(MPSDefs.DB_MEMBER_NAME));
		hmNotificationInput.put(CommonDefs.DOMAIN, hmDBGetMemberServices.get(MPSDefs.DB_DOMAIN_NAME));

		hmNotificationInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
		hmNotificationInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
		hmNotificationInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		hmNotificationInput.put(CPNI_LINKED_TO_SLID, hmInput.get(CPNI_LINKED_TO_SLID));

		HashMap hmConvertServicesResponse = new HashMap();
		ArrayList sDBServiceTypes = new ArrayList();

		if (hmDBGetMemberServices.get(CommonDefs.SERVICES) != null) {

			hmConvertServicesResponse = oConvertServicesHelper
					.convertServices((HashMap) hmDBGetMemberServices.get(CommonDefs.SERVICES));
			hmNotificationInput.put(CommonDefs.SERVICES, hmConvertServicesResponse.get(CommonDefs.SERVICES));
			sDBServiceTypes = (ArrayList) hmConvertServicesResponse.get(CommonDefs.SERVICE_TYPES);
			log.info(sClassName + sMethodName + "BNH-1-RM1 : hmConvertServicesResponse=NONE "
					+ hmConvertServicesResponse);
		}

		log.info(sClassName + sMethodName + "NH-02 : sDBServiceTypes = " + sDBServiceTypes);

		if (sSorName.equals(CommonDefs.SOR_LS) && hmDBGetMemberServices.get(MPSDefs.DB_BAN) != null) {
			hmNotificationInput.put(CommonDefs.KEY_ACCOUNT_ID, hmDBGetMemberServices.get(MPSDefs.DB_BAN));
		}

		hmNotificationInput.put(CommonDefs.DB_MEMBER_NUM, hmDBGetMemberServices.get(MPSDefs.DB_MEMBER_NUM));
		hmNotificationInput.put(CommonDefs.PARENT_HANDLE, hmDBGetMemberServices.get(MPSDefs.DB_PARENT_NAME));
		hmNotificationInput.put(CommonDefs.PARENT_DOMAIN, hmDBGetMemberServices.get(MPSDefs.DB_DOMAIN_NAME));

		hmNotificationInput.put(CommonDefs.FIRST_NAME, hmDBGetMemberServices.get(MPSDefs.DB_LC_FIRSTNAME));
		hmNotificationInput.put(CommonDefs.LAST_NAME, hmDBGetMemberServices.get(MPSDefs.DB_LC_LASTNAME));

		hmNotificationInput.put(CommonDefs.BROWSER_LANGUAGE, hmDBGetMemberServices.get(MPSDefs.DB_BROWSER_LANGUAGE));

		if (hmDBGetMemberServices.get(CommonDefs.BAN) != null)
			hmNotificationInput.put(CommonDefs.BAN, hmDBGetMemberServices.get(CommonDefs.BAN));

		hmNotificationInput.put(CommonDefs.SOR_NAME, hmDBGetMemberServices.get(CommonDefs.SOR_NAME));
		hmNotificationInput.put(MPSDefs.DB_PARENT_CHILD_IND, hmDBGetMemberServices.get(MPSDefs.DB_PARENT_CHILD_IND));

		String sSecurityAnswerChanged = (String) hmInput.get(CommonDefs.SECURITY_ANSWER_CHANGED);
		ArrayList alNotificationData = new ArrayList();
		HashMap hmNotificationData = new HashMap();
		ArrayList alMemberContactEmails = new ArrayList();
		HashMap hmMemberContactEmail = new HashMap();
		hmMemberContactEmail.put(CommonDefs.CONTACT_EMAIL, hmDBGetMemberServices.get(MPSDefs.DB_CONTACT_EMAIL));
		hmMemberContactEmail.put(CommonDefs.CONTACT_EMAIL_STATUS,
				hmDBGetMemberServices.get(MPSDefs.DB_CONTACT_EMAIL_STATUS));
		alMemberContactEmails.add(hmMemberContactEmail);

        if (sTransactionName.equals(CommonDefs.TRANS_NAME_RESET_PWD)) {
			// [R1908] - Updated to send clearPassword and deliveryMethodValue only for
			// input member notification Data For IDP Temp Pwd issue
			if (sInputMemberNum.equals(sDBMemberNum)) {
				HashMap hmDeliveryMethodValue = new HashMap();
				hmNotificationData.put(CommonDefs.CLEAR_PASSWORD, hmInput.get(CommonDefs.CLEAR_PASSWORD));
				HashMap deliveryMethodHash = (HashMap) hmInput.get(CommonDefs.DELIVERY_METHOD);
				if (null != deliveryMethodHash && !deliveryMethodHash.isEmpty()) {
					String sDeliveryMethodType = (String) deliveryMethodHash.get(CommonDefs.DELIVERY_METHOD_TYPE);
					hmNotificationData.put(CommonDefs.DELIVERY_METHOD_TYPE, sDeliveryMethodType);
					if (sDeliveryMethodType.equals("E"))
						hmDeliveryMethodValue.put(CommonDefs.VALUE_EMAIL,
								deliveryMethodHash.get(CommonDefs.VALUE_EMAIL));
					else if (sDeliveryMethodType.equals("A"))
						hmDeliveryMethodValue.put(CommonDefs.VALUE_AO, deliveryMethodHash.get(CommonDefs.VALUE_AO));
					else if (sDeliveryMethodType.equals("S"))
						hmDeliveryMethodValue.put(CommonDefs.VALUE_SMS, deliveryMethodHash.get(CommonDefs.VALUE_SMS));
					else if (sDeliveryMethodType.equals("M"))
						hmDeliveryMethodValue.put(CommonDefs.VALUE_POSTAL,
								deliveryMethodHash.get(CommonDefs.VALUE_POSTAL));
				}
				hmNotificationData.put("deliveryMethodValue", hmDeliveryMethodValue);
			}
		}

		hmNotificationData.put(CommonDefs.MEMBER_CONTACT_EMAIL, alMemberContactEmails);
		if (sSecurityAnswerChanged != null && sSecurityAnswerChanged.equals(MPSDefs.YES)) {
			hmNotificationData.put(CommonDefs.SECURITY_ANSWER_CHANGED, MPSDefs.YES);
		}
		alNotificationData.add(hmNotificationData);
		hmNotificationInput.put(CommonDefs.NOTIFICATION_DATA, alNotificationData);

		if (sSubEvent != null) {
			hmNotificationInput.put(CommonDefs.SUBEVENT, sSubEvent);
		}

		hmNotificationInput.put(MPSDefs.DB_ACTIVATED_IND, sActivatedInd);
		ArrayList alServiceTypes = (ArrayList) hmInput.get(SERVICE_TYPES);
		if (alServiceTypes != null && (alServiceTypes.contains(CommonDefs.DLIFE_SERVICE)
				|| alServiceTypes.contains(CommonDefs.XANBOO_SERVICE)
				|| alServiceTypes.contains(CommonDefs.DLIFELIGHT_SERVICE))) {
			hmNotificationInput.put(CommonDefs.DLIFE_IND, CommonDefs.IND_Y);
		}

		HashMap hmNotificationfields = (HashMap) hmInputNotification.get("Notificationfields");

		String sCustomerId = null;
		String sCustomerServiceType = null;
		String sIdType = null;
		String sSLID_Notification = null;
		String sDBHandle = null;
		String sDBDomain = null;

		if (hmNotificationfields != null) {

			sCustomerId = (String) hmNotificationfields.get("customerId");
			sCustomerServiceType = (String) hmNotificationfields.get("customerServiceType");
			sIdType = (String) hmNotificationfields.get("idType");
			sSLID_Notification = (String) hmNotificationfields.get("SLID");
		}

		if (hmDBGetMemberServices != null) {
			sDBHandle = (String) hmDBGetMemberServices.get(MPSDefs.DB_MEMBER_NAME);
			sDBDomain = (String) hmDBGetMemberServices.get(MPSDefs.DB_DOMAIN_NAME);
		}

		if (sCustomerId != null)
			hmNotificationInput.put("customerId", sCustomerId);

		if (sCustomerServiceType != null)
			hmNotificationInput.put("customerServiceType", sCustomerServiceType);

		if (sIdType != null)
			hmNotificationInput.put("idType", sIdType);

		if (sSLID_Notification != null)
			hmNotificationInput.put("SLID", sSLID_Notification);

		if (sCustomerId != null && sCustomerId.equalsIgnoreCase(sSLID_Notification) && sDBDomain != null
				&& !sDBDomain.equals(CommonDefs.SLID_DUM)) {
			hmNotificationInput.put("fullyQualifiedId", MPSDefs.YES);
		} else if (sCustomerId != null && !sCustomerId.equalsIgnoreCase(sSLID_Notification) && sDBDomain != null
				&& !sDBDomain.equals(CommonDefs.SLID_DUM)) {
			hmNotificationInput.put("fullyQualifiedId", MPSDefs.NO);
		}

		String sHandleServiceType = null;

		HashMap hmServiceToNotificationfieldMapping = (HashMap) hmInputNotification
				.get("ServiceToNotificationfieldMapping");
		if (hmServiceToNotificationfieldMapping != null) {
			if (sDBDomain != null && sDBDomain.equals(CommonDefs.SLID_DUM)) {
				if (sInputMemberNum.equals(sDBMemberNum)) {
					sHandleServiceType = (String) hmServiceToNotificationfieldMapping.get(CommonDefs.KEY_SLID);
				} else {
					sHandleServiceType = "ACCESS_ID";
				}
			} else if (sDBServiceTypes != null && sDBServiceTypes.contains(MPSDefs.UVERSE_SERVICE)) {
				sHandleServiceType = (String) hmServiceToNotificationfieldMapping.get(MPSDefs.UVERSE_SERVICE);

			} else if (sDBServiceTypes != null && sDBServiceTypes.contains(MPSDefs.DSL_SERVICE)) {
				sHandleServiceType = (String) hmServiceToNotificationfieldMapping.get(MPSDefs.DSL_SERVICE);

			} else if (sDBServiceTypes != null && sDBServiceTypes.contains(MPSDefs.DIAL_SERVICE)) {
				sHandleServiceType = (String) hmServiceToNotificationfieldMapping.get(MPSDefs.DIAL_SERVICE);

			} else if (sDBServiceTypes != null && sDBServiceTypes.contains(MPSDefs.SWH_SERVICE)) {
				sHandleServiceType = (String) hmServiceToNotificationfieldMapping.get(MPSDefs.SWH_SERVICE);

			} else if (sDBServiceTypes != null && sDBServiceTypes.contains(MPSDefs.ECOMM_SERVICE)) {
				sHandleServiceType = (String) hmServiceToNotificationfieldMapping.get(MPSDefs.ECOMM_SERVICE);

			} else if (sDBServiceTypes != null && sDBServiceTypes.size() == 1
					&& sDBServiceTypes.contains(MPSDefs.PORTAL_SERVICE)) {
				sHandleServiceType = (String) hmServiceToNotificationfieldMapping.get(MPSDefs.PORTAL_SERVICE);

			}
		}

		if (sHandleServiceType != null)
			hmNotificationInput.put("handleServiceType", sHandleServiceType);

		String stAutoGenInd = (String) hmDBGetMemberServices.get(MPSDefs.DB_AUTOGENERATED_IND);
		if (stAutoGenInd != null && !stAutoGenInd.isEmpty()) {
			hmNotificationInput.put(CommonDefs.AUTO_GENERATED_IND, stAutoGenInd);
		}

		hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS);
		hmResponse.put("NOTIFICATIONHASH", hmNotificationInput);

		log.debug(SpiMarker.getInstance(), sClassName + sMethodName + "BNH-5 : NOTIFICATIONHASH -- hmResponse :: {}",
				hmResponse);

		return hmResponse;
	}

}
