package com.att.idp.idgraphusermanagementms.db.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.idp.idgraphusermanagementms.db.model.Tlockout;


/**
 * This is the repository interface for the Lockout entity.
 * It extends JpaRepository to provide standard data access operations on the Lockout entity.
 *
 * @param <Tlockout> The type of the entity this repository manages.
 * @param <Long> The type of the id of the entity this repository manages.
 */
public interface LockoutRepository extends JpaRepository<Tlockout, Long> {

	/**
	 * This method is used to find the name of the lockout based on its ID.
	 *
	 * @param lockoutId The ID of the lockout. This is used to search for the lockout in the database.
	 * @return The name of the lockout with the provided ID. If no lockout with the provided ID is found, this method returns null.
	 */
	@Query(value = "select lockout.LOCKOUT_NAME from MPS_OWNER.TLOCKOUT lockout where lockout.LOCKOUT_ID= :lockoutId", nativeQuery=true)
	String findLockoutNameByLockoutId(@Param(value = "lockoutId")Long lockoutId);
}
