package com.att.idp.idgraphusermanagementms.resource.response;

import lombok.Data;

/**
 * This class represents a member's service role attributes in the system.
 * It contains fields for attributeId, attributeName, and attributeValue.
 * Each field has specific constraints such as not null and size limits.
 *
 * The class uses Lombok's @Data annotation to generate getter and setter methods for all fields.
 *
 */
@Data
public class IPMemberServiceRoleAttributes {

	private String attributeId;
	private String attributeName;
	private String attributeValue;
}