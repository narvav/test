package com.att.idp.idgraphusermanagementms.utils;

/**
 * The LogInformationConstants class is a utility class that provides constant values for logging information.
 * This class is part of the com.att.idp.idgraphusermanagementms.utils package.
 * The class contains nested classes for different logging scenarios, each providing its own set of constant values.
 * The class itself cannot be instantiated and throws an exception if instantiation is attempted.
 */
public class LogInformationConstants {
	
	private LogInformationConstants() {
		throw new IllegalStateException("LogInformationConstants");
	}
	
	
	/**
	 * The AddMemberGroup is a static nested class inside the LogInformationConstants class.
	 * This class provides constant values for logging information specifically related to the addition of member groups.
	 * The class itself cannot be instantiated and throws an exception if instantiation is attempted.
	 */
	public static class AddMemberGroup {
		
		private AddMemberGroup() {
			throw new IllegalStateException("AddMemberGroup");
		}

		public static final String ADD_MEM_GRP_SUCCESS_MESSAGE  = "Successfully saved addMemberGroup data :  ";
		public static final String EMPTY_STRING					= "   ";
		public static final String RECORDS_COUNT			    = " count of rows saved : ";
		
	}
	public static final String VAS = "VAS";
	public static final String CONNECTEDHOME = "CONNECTEDHOME";
	public static final String DIRECTVNOW = "DIRECTVNOW";
}