package com.att.idp.idgraphusermanagementms.resource.impl;

import java.sql.SQLException;
import java.util.Map;

import com.att.mpsys.common.utils.CommonDefs;
import jakarta.validation.Valid;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_IB;
import static com.att.idp.cd.observability.metrics.utils.Constants.URI;
import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.POST;
import static com.att.idp.cd.observability.metrics.utils.Constants.GET;
import static com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants.IDGRAPH_USERMANAGEMENTMS_IB;

import com.att.idp.idgraphusermanagementms.request.validator.*;
import com.att.idp.idgraphusermanagementms.resource.request.*;
import com.att.idp.idgraphusermanagementms.resource.response.*;
import com.att.idp.idgraphusermanagementms.service.*;
import com.att.idp.idgraphusermanagementms.service.AddExtUserService;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.stereotype.Controller;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.request.validator.AddUserRequestValidator;
import com.att.idp.idgraphusermanagementms.request.validator.ChangeUserNameRequestValidator;
import com.att.idp.idgraphusermanagementms.request.validator.CheckAccessIdMergeEligibilityRequestValidator;
import com.att.idp.idgraphusermanagementms.request.validator.CheckUserIdAvailabilityRequestValidator;
import com.att.idp.idgraphusermanagementms.request.validator.UpdateUserFraudRequestValidator;
import com.att.idp.idgraphusermanagementms.resource.UserProfileResource;
import com.att.idp.idgraphusermanagementms.resource.response.AddUserResponse;
import com.att.idp.idgraphusermanagementms.resource.response.ChangeUserNameResponse;
import com.att.idp.idgraphusermanagementms.resource.response.CheckAccessIdMergeEligibilityResponse;
import com.att.idp.idgraphusermanagementms.resource.response.CheckUserIdAvailabilityResponse;
import com.att.idp.idgraphusermanagementms.resource.response.UpdateUserFraudResponse;
import com.att.idp.idgraphusermanagementms.service.AddUserService;
import com.att.idp.idgraphusermanagementms.service.ChangeUserNameService;
import com.att.idp.idgraphusermanagementms.service.CheckAccessIdMergeEligibilityService;
import com.att.idp.idgraphusermanagementms.service.CheckUserIdAvailabilityService;
import com.att.idp.idgraphusermanagementms.service.UpdateUserFraudService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This class is an implementation of the UserProfileResource interface.
 * It contains methods for managing user profiles, including adding, updating, checking user ID availability, changing username, checking access ID merge eligibility, updating user fraud status, adding external user, validating user credentials, updating external user, and merging user access ID.
 * It uses Spring's @Controller annotation, making it a candidate for Spring's automatic detection to discover and automatically create beans.
 * It also uses @Autowired to inject instances of various services and validators.
 * Each method in this class corresponds to a specific operation related to user profiles. These methods take in a request object and HttpHeaders as parameters.
 * These methods are responsible for validating the request, calling the appropriate service, and handling any exceptions that may occur.
 */
@Controller
@OpenAPIDefinition(
		info = @Info(title="User Management",
				description="IDGraphUserManagementMs provides services that are used to perform identity specific " +
						"operations like creating new accessId, registering a currently.com memberId, updating " +
						"profile attributes of the existing accessId, and fraud locking access Id. This information " +
						"gets stored in IdentityGraph database and gets provisioned/replicated to multiple systems " +
						"e.g. HALOC, Yahoo, CG, CCR, G2 etc.\n\n\n\n.", version="0.0.1"),
		servers = {
				@Server(url="https://apporigin-dev2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/"),
				@Server(url="https://apporigin-tst2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/")
		})
public class UserProfileResourceImpl implements UserProfileResource {

	@Autowired
	private AddUserRequestValidator addUserRequestValidator;

	@Autowired
	private AddUserService addUserService;

	@Autowired
	private UpdateUserRequestValidator updateUserRequestValidator;

	@Autowired
	private UpdateUserService updateUserService;

	@Autowired
	private CheckUserIdAvailabilityService checkUserIdAvailabilityService;

	@Autowired
	private CheckUserIdAvailabilityRequestValidator checkUserIdAvailabilityRequestValidator;

	@Autowired
	private ChangeUserNameRequestValidator changeUserNameRequestValidator;

	@Autowired
	private ChangeUserNameService changeUserNameService;

	@Autowired
	private CheckAccessIdMergeEligibilityRequestValidator checkAccessIdMergeEligibilityReqValidator;

	@Autowired
	private CheckAccessIdMergeEligibilityService checkAccessIdMergeEligibilityService;

	@Autowired
	private UpdateUserFraudService userFraudManagerService;

	@Autowired
	private UpdateUserFraudRequestValidator updateUserFraudRequestValidator;

	@Autowired
	private ValidateUserCredentialsRequestValidator validateUserCredentialsRequestValidator;

	@Autowired
	private ValidateUserCredentialsService validateUserCredentialsService;
	
	@Autowired
	private ExtUserRequestValidator extUserRequestValidator;

	@Autowired
	private AddExtUserService addExtUserService;

	@Autowired
	private UpdateExtUserService updateExtUserService;
	
	@Autowired
	private MergeUserAccessIdService mergeUserAccessIdService;
	
	@Autowired
	private MergeUserAccessIdRequestValidator mergeUserAccessIdRequestValidator;

	public static final Logger logger = LoggerFactory.getLogger(UserProfileResourceImpl.class);

	@TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
			description = "add user",
			tags = {URI, "/msapi/idgraphusermanagementms/v1/user/add", METHOD, POST},
			histogram = true)
	@Override
	public Response addUser(AddUserRequest addUserRequest,HttpHeaders httpHeaders) throws MPSException {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		AddUserResponse addUserResponse = null;
		long startTm = System.currentTimeMillis();
		Response responseObj = null;
		try {

			MultivaluedMap<String, String> requestHeader = httpHeaders.getRequestHeaders();

			logger.info(SpiMarker.getInstance(),"WEB_01 : AddUser Input : {} | AddUser Request Header  : {}",
				addUserRequest != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(addUserRequest)) : null,
					requestHeader != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(requestHeader)) : null);

			addUserResponse = addUserRequestValidator.addUserRequestValidator(httpHeaders, addUserRequest);

			logger.info(SpiMarker.getInstance(),"WEB000 : AddUser Input : {}", addUserRequest);

			if (addUserResponse == null) {
				// call the service class
				addUserResponse = addUserService.addUser(addUserRequest, requestHeader);
				logger.info("WEB_02 : AddUser Service Response : {}", addUserResponse);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: {}", e.getMessage());
				throw e;
			}
			else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
            }
			else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			}

			hmResponse.put(ProfileOrchestrationConstants.IDP_TRACE_ID, addUserRequest.getIdpTraceId());
			addUserResponse = CommonUtilHelper.generateAddUserResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(addUserResponse);
		String sTimeTaken = CommonUtilHelper.getElapsedTimeInSecs(startTm) + " seconds";

		logger.info("WEB999 : Total time taken : {} AddUser Response : {}",sTimeTaken, addUserResponse);
		return responseObj;
	}

	@TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
			description = "update user",
			tags = {URI, "/msapi/idgraphusermanagementms/v1/user/update", METHOD, POST},
			histogram = true)
	@Override
	public Response updateUser(UpdateUserRequest updateUserRequest, HttpHeaders httpHeaders) throws MPSException {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		UpdateUserResponse updateUserResponse = null;
		long startTm = System.currentTimeMillis();
		Response responseObj = null;
		try {

			MultivaluedMap<String, String> requestHeader = httpHeaders.getRequestHeaders();

			logger.info(SpiMarker.getInstance(),"WEB_01 : UpdateUser Input1 : {} | UpdateUser Request Header  : {}",
				updateUserRequest != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(updateUserRequest)) : null,
					requestHeader != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(requestHeader)) : null);

            // to support update using accessId, defaulting the domain to slid.dum
			String domain = updateUserRequest.getDomain();
			if(StringUtils.isBlank(domain)) {
				updateUserRequest.setDomain(CommonDefs.SLID_DUM);
			}
			updateUserResponse = updateUserRequestValidator.updateUserRequestValidator(httpHeaders, updateUserRequest);

			logger.info(SpiMarker.getInstance(),"WEB000 : UpdateUser Input : {}", updateUserRequest);

			if (updateUserResponse == null) {
				// call the service class
				updateUserResponse = updateUserService.updateUser(updateUserRequest, requestHeader);
				logger.info("WEB_02 : UpdateUser Service Response : {}", updateUserResponse);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: {}", e.getMessage());
				throw e;
			}
			else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
				hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
			}
			else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			}

			hmResponse.put(ProfileOrchestrationConstants.IDP_TRACE_ID, updateUserRequest.getIdpTraceId());
			updateUserResponse = CommonUtilHelper.generateUpdateUserResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(updateUserResponse);
		String sTimeTaken = CommonUtilHelper.getElapsedTimeInSecs(startTm) + " seconds";

		logger.info("WEB999 : Total time taken : {} UpdateUser Response : {}",sTimeTaken, updateUserResponse);
		return responseObj;
	}

	@TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
			description = "check user id availability",
			tags = {URI, "/msapi/idgraphusermanagementms/v1/user/checkUserIdAvailability", METHOD, POST},
			histogram = true)
	@Override
	public Response checkUserIdAvailability(CheckUserIdAvailabilityRequest checkUserRequest,HttpHeaders httpHeaders) throws MPSException{
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		CheckUserIdAvailabilityResponse checkUserResponse = null;
		long startTm = System.currentTimeMillis();

		Response responseObj = null;
		try {
			MultivaluedMap<String, String> requestHeader = httpHeaders.getRequestHeaders();

			logger.info("WEB_CUIA_01 : CheckUserIdAvailability Input : {} | CheckUserIdAvailability Request Header  : {}",
				checkUserRequest != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(checkUserRequest)) : null,
					requestHeader != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(requestHeader)) : null);

			checkUserResponse = checkUserIdAvailabilityRequestValidator.checkUserIdAvailabilityRequestValidator(httpHeaders, checkUserRequest);

			logger.info("WEB000 : CheckUserIdAvailability Input : {}", checkUserRequest);

			// when validation successful
			if(checkUserResponse == null) {
				checkUserResponse = checkUserIdAvailabilityService.checkUserIdAvailability(checkUserRequest,requestHeader);
				logger.info("WEB_CUIA_02 : CheckUserIdAvailability Service Response : {}", checkUserResponse);
			}
		}catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: {}", e.getMessage());
				throw e;
			}
			else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
            }
			else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			}

			hmResponse.put(ProfileOrchestrationConstants.IDP_TRACE_ID, checkUserRequest.getIdpTraceId());
			checkUserResponse = CommonUtilHelper.generateCheckUserResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(checkUserResponse);
		String sTimeTaken = CommonUtilHelper.getElapsedTimeInSecs(startTm) + " seconds";
		logger.info("WEB999 : Total time taken : {} CheckUserIdAvailability Response : {}",sTimeTaken, checkUserResponse);
		return responseObj;
	}

	@TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
			description = "change user name",
			tags = {URI, "/msapi/idgraphusermanagementms/v1/user/change", METHOD, POST},
			histogram = true)
	@Override
	public Response changeUserName(@Valid ChangeUserNameRequest changeUserNameRequest,HttpHeaders httpHeaders) throws MPSException {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		ChangeUserNameResponse changeUserNameResponse = null;
		long startTm = System.currentTimeMillis();

		Response responseObj = null;
		try {

			MultivaluedMap<String, String> requestHeader = httpHeaders.getRequestHeaders();

			logger.info(SpiMarker.getInstance(), "WEB_01 : ChangeUserName Input : {} | ChangeUserName Request Header  : {}",
					changeUserNameRequest != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(changeUserNameRequest)) : null,
					requestHeader != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(requestHeader)) : null);

			changeUserNameResponse = changeUserNameRequestValidator.changeUserNameRequestValidator(httpHeaders, changeUserNameRequest);

			logger.info("WEB000 : ChangeUserName Input : {}", changeUserNameRequest);

			if (changeUserNameResponse == null) {
				// call the service class
				changeUserNameResponse = changeUserNameService.changeUserName(changeUserNameRequest, requestHeader);
				logger.info("WEB_02 : ChangeUserName Service Response : {}", changeUserNameResponse);
			}
		}
		catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: {}", e.getMessage());
				throw e;
			}
			else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
            }else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			}

			hmResponse.put(ProfileOrchestrationConstants.IDP_TRACE_ID, changeUserNameRequest.getIdpTraceId());
			changeUserNameResponse = CommonUtilHelper.generateChangeUserNameResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(changeUserNameResponse);
		String sTimeTaken = CommonUtilHelper.getElapsedTimeInSecs(startTm) + " seconds";

		logger.info("WEB999 : Total time taken : {} ChangeUserName Response : {}",sTimeTaken, changeUserNameResponse);
		return responseObj;
	}

	@TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
			description = "check access id merge eligibility",
			tags = {URI, "/msapi/idgraphusermanagementms/v1/user/checkEligibility", METHOD, POST},
			histogram = true)
	@Override
	public Response checkAccessIdMergeEligibility(@Valid CheckAccessIdMergeEligibilityRequest checkAccessIdMergeEligibilityRequest,
			HttpHeaders httpHeaders) throws MPSException {

		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		CheckAccessIdMergeEligibilityResponse checkAccessIdMergeEligibilityResponse = null;
		long startTm = System.currentTimeMillis();
		Response responseObj = null;
		try {

			MultivaluedMap<String, String> requestHeader = httpHeaders.getRequestHeaders();

			logger.info(SpiMarker.getInstance(), "WEB_01 : CheckAccessIdMergeEligibility Input : {} | CheckAccessIdMergeEligibility Request Header  : {}",
					checkAccessIdMergeEligibilityRequest != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(checkAccessIdMergeEligibilityRequest)) : null,
					requestHeader != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(requestHeader)) : null);

			checkAccessIdMergeEligibilityResponse = checkAccessIdMergeEligibilityReqValidator
													.checkAccessIdMergeEligibilityRequestValidator(httpHeaders,
																								   checkAccessIdMergeEligibilityRequest);

			logger.info("WEB000 : CheckAccessIdMergeEligibility Input : {}", checkAccessIdMergeEligibilityRequest);

			if (checkAccessIdMergeEligibilityResponse == null) {
				checkAccessIdMergeEligibilityResponse = checkAccessIdMergeEligibilityService
														.checkAccessIdMergeEligibility(checkAccessIdMergeEligibilityRequest, requestHeader);
				logger.info("WEB_02 : CheckAccessIdMergeEligibility Service Response : {}", checkAccessIdMergeEligibilityResponse);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: {}", e.getMessage());
				throw e;
			}
			else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
            }else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			}
			hmResponse.put(ProfileOrchestrationConstants.IDP_TRACE_ID, checkAccessIdMergeEligibilityRequest.getIdpTraceId());
			checkAccessIdMergeEligibilityResponse = CommonUtilHelper.generateCheckAccessIdMergeEligibilityResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(checkAccessIdMergeEligibilityResponse);
		String sTimeTaken = CommonUtilHelper.getElapsedTimeInSecs(startTm) + " seconds";

		logger.info("WEB999 : Total time taken : {} CheckAccessIdMergeEligibility Response : {}", sTimeTaken,
					checkAccessIdMergeEligibilityResponse);

		return responseObj;
	}

	@TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
			description = "update user fraud",
			tags = {URI, "/msapi/idgraphusermanagementms/v1/user/updateFraud", METHOD, POST},
			histogram = true)
	@Override
	public Response updateUserFraud(@Valid UpdateUserFraudRequest updateUserFraudRequest, HttpHeaders httpHeaders)
			throws MPSException {

		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		UpdateUserFraudResponse updateUserFraudResponse = null;
		long startTm = System.currentTimeMillis();
		Response responseObj = null;
		try {

			MultivaluedMap<String, String> requestHeader = httpHeaders.getRequestHeaders();

			logger.info(SpiMarker.getInstance(), "WEB_01 : UpdateUserFraud Input : {} | UpdateUserFraud Request Header  : {}",
					updateUserFraudRequest != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(updateUserFraudRequest)) : null,
					requestHeader != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(requestHeader)) : null);

			updateUserFraudResponse = updateUserFraudRequestValidator.updateUserFraudReqValidator(httpHeaders, updateUserFraudRequest);

			logger.info("WEB000 : UpdateUserFraud Input : {}", updateUserFraudRequest);

			if (updateUserFraudResponse == null) {
				// call the service class
				updateUserFraudResponse = userFraudManagerService.updateUserFraud(updateUserFraudRequest, requestHeader);
				logger.info("WEB_02 : UserFraudManagerService Response : {}", updateUserFraudResponse);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: {}", e.getMessage());
				throw e;
			}
			else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
            }
			else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			}

			hmResponse.put(ProfileOrchestrationConstants.IDP_TRACE_ID, updateUserFraudRequest.getIdpTraceId());
			updateUserFraudResponse = CommonUtilHelper.generateUpdateUserFraudResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(updateUserFraudResponse);
		String sTimeTaken = CommonUtilHelper.getElapsedTimeInSecs(startTm) + " seconds";

		logger.info("WEB999 : Total time taken : {} UpdateUserFraud Response : {}",sTimeTaken, updateUserFraudResponse);
		return responseObj;

	}

	@TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
			description = "add external user",
			tags = {URI, "/msapi/idgraphusermanagementms/v1/user/addExt", METHOD, POST},
			histogram = true)
	@Override
	public Response addExtUser(@Valid ExtUserRequest extUserRequest, HttpHeaders httpHeaders) throws MPSException {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		ExtUserResponse extUserResponse = null;
		long startTm = System.currentTimeMillis();
		Response responseObj = null;
		if(extUserRequest != null) {
			extUserRequest.setTransactionName(ProfileOrchestrationConstants.ADD_EXTUSER_TRANSACTION_NAME);
		}
		try {

			MultivaluedMap<String, String> requestHeader = httpHeaders.getRequestHeaders();

			logger.info(SpiMarker.getInstance(),"WEB_000 : AddExtUser Input : {} | AddUser Request Header  : {}",
					(extUserRequest != null ? StringUtils.normalizeSpace(extUserRequest.toString()) : "null"), CommonUtilHelper.objectToString(requestHeader));

			extUserResponse = extUserRequestValidator.extUserReqValidator(httpHeaders, extUserRequest);

			logger.info(SpiMarker.getInstance(),"WEB_01 : AddExtUser Input : {}", extUserRequest);

			if (extUserResponse == null) {
				// call the service class
				extUserResponse = addExtUserService.addExtUserResponse(extUserRequest, requestHeader);
				logger.info("WEB_02 : AddExtUser Service Response : {}", extUserResponse);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: {}", e.getMessage());
				throw e;
			}
			else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
				hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
			}
			else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			}

			hmResponse.put(ProfileOrchestrationConstants.IDP_TRACE_ID, extUserRequest.getIdpTraceId());
			extUserResponse = CommonUtilHelper.generateExtUserResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(extUserResponse);
		String sTimeTaken = CommonUtilHelper.getElapsedTimeInSecs(startTm) + " seconds";

		extUserResponse.setTransactionName("AddExtUser");
		logger.info("WEB999 : Total time taken : {} AddExtUser Response : {}",sTimeTaken, extUserResponse);
		return responseObj;

	}

	@TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
			description = "validate user credentials",
			tags = {URI, "/msapi/idgraphusermanagementms/v1/user/credentials/validate", METHOD, POST},
			histogram = true)
	@Override
	public Response validateUserCredentials(ValidateUserCredentialsRequest validateUserCredentialsRequest, HttpHeaders httpHeaders) throws MPSException {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		ValidateUserCredentialsResponse validateUserCredentialsResponse = null;
		long startTm = System.currentTimeMillis();
		Response responseObj = null;
		try {

			logger.info(SpiMarker.getInstance(),"WEB_01 : ValidateUserCredentials Input : {} | ValidateUserCredentials Request Header  : {}",
				validateUserCredentialsRequest != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(validateUserCredentialsRequest)) : null,
					httpHeaders.getRequestHeaders() != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(httpHeaders.getRequestHeaders())) : null);

			validateUserCredentialsResponse = validateUserCredentialsRequestValidator.validateUserCredentialsReqValidator(httpHeaders, validateUserCredentialsRequest);

			logger.info(SpiMarker.getInstance(),"WEB000 : ValidateUserCredentials Input : {}", validateUserCredentialsRequest);

			if (validateUserCredentialsResponse == null) {
				// call the service class
				validateUserCredentialsResponse = validateUserCredentialsService.validateUserCredentials(validateUserCredentialsRequest, httpHeaders);
				logger.info("WEB_02 : ValidateUserCredentialsService Response : {}", validateUserCredentialsResponse);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: {}", e.getMessage());
				throw e;
			}
			else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
				hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
			}
			else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			}

			hmResponse.put(ProfileOrchestrationConstants.IDP_TRACE_ID, validateUserCredentialsRequest.getIdpTraceId());
			validateUserCredentialsResponse = CommonUtilHelper.generateValidateUserCredentialsResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(validateUserCredentialsResponse);
		String sTimeTaken =CommonUtilHelper.getElapsedTimeInSecs(startTm) + " seconds";
		logger.info("WEB999 : Total time taken : {} ValidateUserCredentials Response : {}",sTimeTaken, validateUserCredentialsResponse);
        return responseObj;
    }

	@TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
			description = "update external user",
			tags = {URI, "/msapi/idgraphusermanagementms/v1/user/updateExt", METHOD, POST},
			histogram = true)
	@Override
	public Response updateExtUser(@Valid ExtUserRequest extUserRequest, HttpHeaders httpHeaders) throws MPSException {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		ExtUserResponse extUserResponse = null;
		long startTm = System.currentTimeMillis();
		Response responseObj = null;

		if(extUserRequest != null) {
			extUserRequest.setTransactionName(ProfileOrchestrationConstants.UPDATE_EXTUSER_TRANSACTION_NAME);
		}
		try {

			MultivaluedMap<String, String> requestHeader = httpHeaders.getRequestHeaders();

			logger.info(SpiMarker.getInstance(),"WEB_01 : UpdateExtUser Input : {} | UpdateUser Request Header  : {}",
				extUserRequest != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(extUserRequest)) : null,
					requestHeader != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(requestHeader)) : null);

			extUserResponse = extUserRequestValidator.extUserReqValidator(httpHeaders, extUserRequest);

			logger.info(SpiMarker.getInstance(),"WEB000 : UpdateExtUser Input : {}", extUserRequest);

			if (extUserResponse == null) {
				// call the service class
				extUserResponse = updateExtUserService.updateExtUserResponse(extUserRequest, requestHeader);
				logger.info("WEB_02 : UpdateExtUser Service Response : {}", extUserResponse);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: {}", e.getMessage());
				throw e;
			}
			else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
				hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
			}
			else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			}

			hmResponse.put(ProfileOrchestrationConstants.IDP_TRACE_ID, extUserRequest.getIdpTraceId());
			extUserResponse = CommonUtilHelper.generateExtUserResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(extUserResponse);
		String sTimeTaken = CommonUtilHelper.getElapsedTimeInSecs(startTm) + " seconds";

		extUserResponse.setTransactionName("UpdateExtUser");
		logger.info("WEB999 : Total time taken : {} UpdateExtUser Response : {}",sTimeTaken, extUserResponse);
		return responseObj;

	}

	@TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
			description = "merge user access id",
			tags = {URI, "/msapi/idgraphusermanagementms/v1/user/merge", METHOD, POST},
			histogram = true)
	@Override
	public Response mergeUserAccessId(@Valid MergeUserAccessIdRequest mergeUserAccessIdRequest, HttpHeaders httpHeader)
			throws MPSException {

		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		MergeUserAccessIdResponse mergeUserAccessIdResponse = null;
		long startTm = System.currentTimeMillis();
		Response responseObj = null;
		try {

			MultivaluedMap<String, String> requestHeader = httpHeader.getRequestHeaders();

			logger.info(SpiMarker.getInstance(),"WEB_01 : MergeUserAccessId Input : {} | MergeUserAccessId Request Header  : {}",
				mergeUserAccessIdRequest != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(mergeUserAccessIdRequest)) : null,
					requestHeader != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(requestHeader)) : null);

			mergeUserAccessIdResponse = mergeUserAccessIdRequestValidator.mergeUserAccessIdRequestValidator(httpHeader, mergeUserAccessIdRequest);

			logger.info(SpiMarker.getInstance(),"WEB000 : MergeUserAccessId Input : {}", mergeUserAccessIdRequest);

			if (mergeUserAccessIdResponse == null) {
				// call the service class
				mergeUserAccessIdResponse = mergeUserAccessIdService.mergeUserAccessId(mergeUserAccessIdRequest, requestHeader);
				logger.info("WEB_02 : MergeUserAccessId Service Response : {}", mergeUserAccessIdResponse);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: {}", e.getMessage());
				throw e;
			}
			else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
            }
			else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			}

			hmResponse.put(ProfileOrchestrationConstants.IDP_TRACE_ID, mergeUserAccessIdRequest.getIdpTraceId());
			mergeUserAccessIdResponse = CommonUtilHelper.generateMergeUserAccessIdResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(mergeUserAccessIdResponse);
		String sTimeTaken = CommonUtilHelper.getElapsedTimeInSecs(startTm) + " seconds";

		logger.info("WEB999 : Total time taken : {} MergeUserAccessId Response : {}",sTimeTaken, mergeUserAccessIdResponse);
		return responseObj;
	
	}
}