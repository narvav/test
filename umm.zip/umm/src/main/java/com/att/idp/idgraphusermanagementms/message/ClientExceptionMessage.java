package com.att.idp.idgraphusermanagementms.message;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;


/**
 * This class represents a client exception message.
 * It is used to encapsulate the details of an exception message that is sent to the client.
 * The class is annotated with @JsonIgnoreProperties(ignoreUnknown = true), meaning that any unknown properties encountered during deserialization will be ignored.
 * The class is also annotated with @Data, a Lombok annotation that generates getters, setters, equals, hashCode, and toString methods.
 * The class contains three private fields: appStatusMsg, appStatusCode, and appInfo.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class ClientExceptionMessage {

	private String appStatusMsg;
	private String appStatusCode;
	private String appInfo;

}
