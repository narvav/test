package com.att.idp.idgraphusermanagementms.resource.response;

import com.att.idp.core.exception.ServiceError;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * Represents the response for adding a secondary member ID in the system.
 * This class contains various fields for response details and constraints.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "UpgSecMemberIdResponse")
public class UpgSecMemberIdResponse {

    /**
     * The name of the transaction.
     * This field is ignored in the JSON response.
     */
    @JsonIgnore
    private String transactionName;

    /**
     * The IDP trace ID.
     */
    @JsonProperty("idp-trace-id")
    private String idpTraceId;

    /**
     * Suggested secMemberId
     */
    private String secMemberId;

    /**
     * Suggested secDomain
     */
    private String secDomain ;

    /**
     * Service errors, if any.
     */
    @JsonProperty("error")
    private ServiceError errors;

    /**
     * The application category code.
     * This field is ignored in the JSON response.
     */
    @JsonIgnore
    private String appCategoryCode;


    private String appStatusCode;
    private String appStatusMsg;
    private String appInfo;

    @Override
    public String toString() {
        return "UpgSecMemberIdResponse [transactionName=" + transactionName + ", appStatusMsg=" + appStatusMsg
                + ", appStatusCode=" + appStatusCode + ", appInfo=" + appInfo + ", appCategoryCode=" + appCategoryCode
                + ", errors=" + CommonUtilHelper.objectToString(errors) + ", idpTraceId=" + idpTraceId + "]";
    }
}