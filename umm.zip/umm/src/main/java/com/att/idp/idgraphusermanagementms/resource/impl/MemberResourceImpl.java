package com.att.idp.idgraphusermanagementms.resource.impl;

import jakarta.ws.rs.core.HttpHeaders;
import java.sql.SQLException;
import java.util.Map;

import jakarta.validation.Valid;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_IB;
import static com.att.idp.cd.observability.metrics.utils.Constants.URI;
import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.POST;
import static com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants.IDGRAPH_USERMANAGEMENTMS_IB;
import com.att.idp.idgraphusermanagementms.service.LinkMemberService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.stereotype.Controller;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.message.ErrorMessages;
import com.att.idp.idgraphusermanagementms.request.validator.LinkMemberRequestValidator;
import com.att.idp.idgraphusermanagementms.request.validator.UnlinkMemberIdRequestValidator;
import com.att.idp.idgraphusermanagementms.resource.MemberResource;
import com.att.idp.idgraphusermanagementms.resource.request.LinkMemberRequest;
import com.att.idp.idgraphusermanagementms.resource.request.UnlinkMemberIdRequest;
import com.att.idp.idgraphusermanagementms.resource.response.CommonResponse;
import com.att.idp.idgraphusermanagementms.resource.response.LinkMemberResponse;
import com.att.idp.idgraphusermanagementms.service.UnlinkMemberIdService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This class is an implementation of the MemberResource interface.
 * It contains methods for linking and unlinking members.
 * It uses Spring's @Controller annotation, making it a candidate for Spring's automatic detection to discover and automatically create beans.
 * It also uses @Autowired to inject instances of LinkMemberRequestValidator, UnlinkMemberIdRequestValidator, and UnlinkMemberIdService.
 * 
 * The class contains two main methods: linkMember and unlinkMemberId. Both methods take in a request object and HttpHeaders as parameters.
 * These methods are responsible for validating the request, calling the appropriate service, and handling any exceptions that may occur.
 * 
 * @author pb6583
 */
@Controller
@OpenAPIDefinition(
		info = @Info(title="User Management",
				description="IDGraphUserManagementMs provides services that are used to perform identity specific " +
						"operations like creating new accessId, registering a currently.com memberId, updating " +
						"profile attributes of the existing accessId, and fraud locking access Id. This information " +
						"gets stored in IdentityGraph database and gets provisioned/replicated to multiple systems " +
						"e.g. HALOC, Yahoo, CG, CCR, G2 etc.\n\n\n\n.", version="0.0.1"),
		servers = {
				@Server(url="https://apporigin-dev2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/"),
				@Server(url="https://apporigin-tst2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/")
		})
public class MemberResourceImpl implements MemberResource{
	
	public static final Logger logger = LoggerFactory.getLogger(MemberResourceImpl.class);


	@Autowired
	LinkMemberRequestValidator linkMemberRequestValidatorObj;
	@Autowired
	private UnlinkMemberIdRequestValidator unlinkMemberIdRequestValidator;
	@Autowired
	private UnlinkMemberIdService unlinkMemberIdService;
	@Autowired
	private LinkMemberService linkMemberService;

	@TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
			description = "link member",
			tags = {URI, "/msapi/idgraphusermanagementms/v1/member/link", METHOD, POST},
			histogram = true)
	@Override
	public Response linkMember(@Valid LinkMemberRequest linkMemberRequestObj, HttpHeaders httpHeader)
			throws MPSException {
		
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		LinkMemberResponse linkMemberResponseObj = null;
		long startTm = System.currentTimeMillis();
		Response responseObj = null;
		try {

			MultivaluedMap<String, String> requestHeader = httpHeader.getRequestHeaders();
			logger.info(SpiMarker.getInstance(),"WEB_01 : LinkMember Input : {} | LinkMember Request Header  : {}",
					(linkMemberRequestObj != null ? StringUtils.normalizeSpace(linkMemberRequestObj.toString()) : "null"), CommonUtilHelper.objectToString(requestHeader));

			linkMemberResponseObj =linkMemberRequestValidatorObj.linkMemberRequestValidator(httpHeader, linkMemberRequestObj);

			logger.info("WEB000 : LinkMember Input : {}", linkMemberRequestObj);
			if (linkMemberResponseObj == null) {
				// call the service class to process the request
				linkMemberResponseObj = linkMemberService.linkMember(linkMemberRequestObj, requestHeader);
				logger.info(SpiMarker.getInstance(), "WEB_02 : LinkMember Service Response : {}", linkMemberResponseObj);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: linkMember {}", e.getMessage());
				throw e;
			} else if (NestedExceptionUtils.getRootCause(e) instanceof SQLException) {
				hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
				hmResponse.put("ErrorEnum", ErrorMessages.MS_MPSYS_BE_304);
			} else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
				hmResponse.put("ErrorEnum", ErrorMessages.MS_MPSYS_BE_602);
			}
			hmResponse.put("idp-trace-id", linkMemberRequestObj.getIdpTraceId());
			linkMemberResponseObj = CommonUtilHelper.generateLinkMemberResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(linkMemberResponseObj);
		String sTimeTaken = CommonUtilHelper.getElapsedTimeInSecs(startTm) + " seconds";

		logger.info(SpiMarker.getInstance(), "WEB999 : Total time taken : {} LinkMember Response : {}", sTimeTaken,
				linkMemberResponseObj);
		return responseObj;
	}
	
	@TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
			description = "unlink member id",
			tags = {URI, "/msapi/idgraphusermanagementms/v1/member/unlink", METHOD, POST},
			histogram = true)
	@Override
	public Response unlinkMemberId(@Valid UnlinkMemberIdRequest unlinkMemberIdRequest,
			HttpHeaders httpHeaders) throws MPSException {
	
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		CommonResponse unlinkMemberIdResponse = null;
		long startTm = System.currentTimeMillis();
		Response responseObj = null;
		try {

			MultivaluedMap<String, String> requestHeader = httpHeaders.getRequestHeaders();

			logger.info(SpiMarker.getInstance(),"WEB_01 : UnlinkMemberId Input : {} | UnlinkMemberId Request Header  : {}",
				unlinkMemberIdRequest != null ? CommonUtilHelper.sanitizeForLog(unlinkMemberIdRequest.toString()) : null,
					requestHeader != null ? CommonUtilHelper.sanitizeForLog(requestHeader.toString()) : null);

			unlinkMemberIdResponse = unlinkMemberIdRequestValidator.unlinkMemberReqValidator(httpHeaders,
					unlinkMemberIdRequest);
			logger.info("WEB000 : UnlinkMemberId Input : {}", unlinkMemberIdRequest);

			if (unlinkMemberIdResponse == null) {
				// call the service class
				unlinkMemberIdResponse = unlinkMemberIdService.unlinkMemberId(unlinkMemberIdRequest, requestHeader);
				
				logger.info(SpiMarker.getInstance(), "WEB_02 : UnlinkMemberId Service Response : {}",
						unlinkMemberIdResponse);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: unlinkMemberId{}", e.getMessage());
				throw e;
			} else if (NestedExceptionUtils.getRootCause(e) instanceof SQLException) {
				hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
				hmResponse.put("ErrorEnum", ErrorMessages.MS_MPSYS_BE_304);
			} else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
				hmResponse.put("ErrorEnum", ErrorMessages.MS_MPSYS_BE_602);
			}
			hmResponse.put("idp-trace-id", unlinkMemberIdRequest.getIdpTraceId());
			unlinkMemberIdResponse = CommonUtilHelper.generateCommonResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(unlinkMemberIdResponse);
		String sTimeTaken = CommonUtilHelper.getElapsedTimeInSecs(startTm) + " seconds";

		logger.info(SpiMarker.getInstance(), "WEB999 : Total time taken : {} UnlinkMemberId Response : {}",
				sTimeTaken, unlinkMemberIdResponse);
		return responseObj;
	}
	
	}
