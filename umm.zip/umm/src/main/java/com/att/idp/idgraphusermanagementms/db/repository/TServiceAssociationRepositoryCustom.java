package com.att.idp.idgraphusermanagementms.db.repository;

import java.sql.SQLException;

/**
 * This is a custom repository interface for TServiceAssociation related operations.
 * Additional methods for TServiceAssociation operations should be declared here.
 */
public interface TServiceAssociationRepositoryCustom {
	
	/**
	 * This method is used to save the TServiceInfo to the database.
	 *
	 * @return An integer representing the number of rows affected by the save operation.
	 * @throws SQLException If there is an error while executing the SQL query.
	 */
	public int saveTServiceInfo() throws SQLException;
}
