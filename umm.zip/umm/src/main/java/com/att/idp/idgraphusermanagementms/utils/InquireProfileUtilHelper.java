package com.att.idp.idgraphusermanagementms.utils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.PropertyAccessor;
import org.springframework.beans.PropertyAccessorFactory;

import com.att.idp.core.exception.ServiceException;
import com.att.idp.idgraphusermanagementms.message.ErrorMessages;
import com.att.idp.idgraphusermanagementms.resource.response.IPLinkedMember;
import com.att.idp.idgraphusermanagementms.resource.response.IPMemberDetail;
import com.att.idp.idgraphusermanagementms.resource.response.IPMemberServiceRole;
import com.att.idp.idgraphusermanagementms.resource.response.IPMemberServiceRoleAttributes;
import com.att.idp.idgraphusermanagementms.resource.response.IPUserFraudLock;
import com.att.idp.idgraphusermanagementms.resource.response.IPUserFraudPassword;
import com.att.idp.idgraphusermanagementms.resource.response.IPUserLockout;
import com.att.idp.idgraphusermanagementms.resource.response.IPUserSecurityInfo;
import com.att.idp.idgraphusermanagementms.resource.response.InquireProfileResponse;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * The InquireProfileUtilHelper class is a utility class that provides methods for handling responses related to profile inquiries.
 * It is part of the com.att.idp.idgraphusermanagementms.utils package.
 * The class contains methods for generating InquireProfileResponse objects based on the input HashMaps.
 * These methods handle both success and error scenarios, and populate the response objects with the appropriate data.
 * The class also contains methods for populating various response objects with data from HashMaps.
 * These methods use reflection to access the fields of the response objects and set their values based on the data in the HashMaps.
 * The class uses a Logger object for logging purposes.
 */
public class InquireProfileUtilHelper {	

	public static final Logger logger = LoggerFactory.getLogger(InquireProfileUtilHelper.class);
	private static String sClassName = "InquireProfileUtilHelper";
	
	private static InquireProfileResponse inquireProfileErrorResponse(int appStatusCode, String appInfo,
			 ErrorMessages errorMessage, String stIdpTraceId) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		InquireProfileResponse inquireProfileResponse = new InquireProfileResponse();
		inquireProfileResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		inquireProfileResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		inquireProfileResponse.setTransactionName("InquireProfile");
		inquireProfileResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		inquireProfileResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		inquireProfileResponse.setErrors(new ServiceException(errorMessage, appInfo).getError());
		inquireProfileResponse.setIdpTraceId(stIdpTraceId);

		return inquireProfileResponse;
	}

	/**
	 * This method is part of the InquireProfileUtilHelper class.
	 * It is responsible for generating an InquireProfileResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - "idp-trace-id": The trace ID for the operation.
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns an InquireProfileResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return InquireProfileResponse An InquireProfileResponse object representing the response to be sent back to the client.
	 */
	public static InquireProfileResponse generateInquireProfileResponse(Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get("idp-trace-id");
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

		int appStatusCode = Integer.parseInt(stAppStatusCode);
		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			return inquireProfileSuccessResponse(appStatusCode, stAppInfo, stIdpTraceId, hmResponse);
		} else {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf("MS_MPSYS_BE_" +appStatusCode);
			return inquireProfileErrorResponse(appStatusCode, stAppInfo, errMsg, stIdpTraceId);
		}
	}

	private static InquireProfileResponse inquireProfileSuccessResponse(int appStatusCode, String appInfo,
			 String stIdpTraceId,Map<String, Object> hmInquireProfileResponse) {

		String sMethodName=".inquireProfileSuccessResponse.";
		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		InquireProfileResponse inquireProfileResponse = new InquireProfileResponse();
		inquireProfileResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		inquireProfileResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		inquireProfileResponse.setTransactionName("InquireProfile");
		inquireProfileResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		inquireProfileResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		inquireProfileResponse.setIdpTraceId(stIdpTraceId);
		try {
			if (hmInquireProfileResponse.get("member") != null) {
				IPMemberDetail memberdetail = getMemberDetailResponse(hmInquireProfileResponse);
				inquireProfileResponse.setMemberdetail(memberdetail);
			}

			if (hmInquireProfileResponse.get("userSecurityInfo") != null) {
				IPUserSecurityInfo userSecurityInfo = getUserSecurityInfoResponse(hmInquireProfileResponse);
				inquireProfileResponse.setUserSecurityInfo(userSecurityInfo);
			}

			if (hmInquireProfileResponse.get(CommonDefs.MEMBER_SERVICE_ROLE) != null) {
				ArrayList<IPMemberServiceRole> alMemberServiceRole = getMemberServiceRoleResponse(
						hmInquireProfileResponse);
				inquireProfileResponse.setMemberServiceRole(alMemberServiceRole);
			}

			if (hmInquireProfileResponse.get(CommonDefs.USER_FRAUD_LOCK) != null) {
				IPUserFraudLock userFraudLock = getUserFraudLockResponse(hmInquireProfileResponse);
				inquireProfileResponse.setUserFraudLock(userFraudLock);
			}

			if (hmInquireProfileResponse.get("userLockout") != null) {
				ArrayList<IPUserLockout> alUserLockout = getUserLockoutResponse(hmInquireProfileResponse);
				inquireProfileResponse.setUserLockout(alUserLockout);
			}

			if (hmInquireProfileResponse.get("linkedmember") != null) {
				ArrayList<IPLinkedMember> alLinkedMember = getLinkedMemberResponse(hmInquireProfileResponse);
				inquireProfileResponse.setLinkedMember(alLinkedMember);
			}

			if (hmInquireProfileResponse.get("userFraudPassword") != null) {
				IPUserFraudPassword userFraudPassword = getUserFraudPasswordResponse(hmInquireProfileResponse);
				inquireProfileResponse.setUserFraudPassword(userFraudPassword);
			}
		} catch (Exception e) {
			String stAppInfo="Exception thrown in InquireProfileUtilHelper.inquireProfileSuccessResponse : " + e.getMessage();
			logger.error("{}{}DBHLPE01 :  Error::{}", sClassName, sMethodName,e.getMessage());
			logger.error("{}{}DBHLPE02 : Exception = {}", sClassName, sMethodName, e);			
			inquireProfileResponse=inquireProfileErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo,
					 ErrorMessages.MS_MPSYS_BE_602, stIdpTraceId);
		}
		return inquireProfileResponse;
	}

	private static IPMemberDetail getMemberDetailResponse(Map<String, Object> hmInquireProfileResponse) throws Exception {
		IPMemberDetail memberDetail = new IPMemberDetail();

		HashMap<String, Object> hmMember = (HashMap<String, Object>) hmInquireProfileResponse.get("member");

		memberDetail = (IPMemberDetail) populateFields(memberDetail, IPMemberDetail.class, hmMember);

		return memberDetail;
	}

	private static IPUserSecurityInfo getUserSecurityInfoResponse(Map<String, Object> hmInquireProfileResponse)
			throws Exception {
		IPUserSecurityInfo userSecurityInfo = new IPUserSecurityInfo();

		HashMap<String, Object> hmUserSecurityInfo = (HashMap<String, Object>) hmInquireProfileResponse
				.get("userSecurityInfo");
		userSecurityInfo = (IPUserSecurityInfo) populateFields(userSecurityInfo, IPUserSecurityInfo.class,
				hmUserSecurityInfo);
		return userSecurityInfo;
	}

	private static IPUserFraudLock getUserFraudLockResponse(Map<String, Object> hmInquireProfileResponse)
			throws Exception {
		HashMap<String, Object> hmUserfraudlock = (HashMap<String, Object>) hmInquireProfileResponse
				.get(CommonDefs.USER_FRAUD_LOCK);

		IPUserFraudLock userFraudLock = new IPUserFraudLock();
		userFraudLock = (IPUserFraudLock) populateFields(userFraudLock, IPUserFraudLock.class, hmUserfraudlock);
		return userFraudLock;
	}

	private static ArrayList<IPMemberServiceRole> getMemberServiceRoleResponse(
			Map<String, Object> hmInquireProfileResponse) throws Exception {

		IPMemberServiceRole memberServiceRole = null;
		IPMemberServiceRoleAttributes memberServiceRoleAttributes = null;
		ArrayList<IPMemberServiceRoleAttributes> alMemberServiceRoleAttributes = null;

		ArrayList<IPMemberServiceRole> memberServiceRoleAl = new ArrayList<IPMemberServiceRole>();
		ArrayList<HashMap<String, Object>> alMemberServices = (ArrayList<HashMap<String, Object>>) hmInquireProfileResponse
				.get(CommonDefs.MEMBER_SERVICE_ROLE);

		for (HashMap<String, Object> hmMemberServiceRole : alMemberServices) {
			memberServiceRole = new IPMemberServiceRole();

			memberServiceRole = (IPMemberServiceRole) populateFields(memberServiceRole, IPMemberServiceRole.class,
					hmMemberServiceRole);

			ArrayList<HashMap<String, Object>> alAttributes = (ArrayList<HashMap<String, Object>>) hmMemberServiceRole
					.get(CommonDefs.ATTRIBUTES);
			if (alAttributes != null) {
				alMemberServiceRoleAttributes = new ArrayList<IPMemberServiceRoleAttributes>();

				for (HashMap<String, Object> hmAttributes : alAttributes) {
					memberServiceRoleAttributes = new IPMemberServiceRoleAttributes();
					memberServiceRoleAttributes = (IPMemberServiceRoleAttributes) populateFields(
							memberServiceRoleAttributes, IPMemberServiceRoleAttributes.class, hmAttributes);
					alMemberServiceRoleAttributes.add(memberServiceRoleAttributes);
				}
				memberServiceRole.setMemberServiceRoleAttributes(alMemberServiceRoleAttributes);
			}
			memberServiceRoleAl.add(memberServiceRole);
		}
		return memberServiceRoleAl;
	}

	private static ArrayList<IPUserLockout> getUserLockoutResponse(Map<String, Object> hmInquireProfileResponse) throws Exception {
		ArrayList<HashMap<String, Object>> alUserLockouts = (ArrayList<HashMap<String, Object>>) hmInquireProfileResponse
				.get("userLockout");
		ArrayList<IPUserLockout> alUserLockout = new ArrayList<IPUserLockout>();
		IPUserLockout userLockout = null;

		for (HashMap<String, Object> hmUserLockout : alUserLockouts) {
			userLockout = (IPUserLockout) populateFields(userLockout, IPUserLockout.class, hmUserLockout);
			alUserLockout.add(userLockout);
		}
		return alUserLockout;
	}

	private static ArrayList<IPLinkedMember> getLinkedMemberResponse(Map<String, Object> hmInquireProfileResponse) throws Exception{
		ArrayList<HashMap<String, Object>> alLinkedMembers = (ArrayList<HashMap<String, Object>>) hmInquireProfileResponse
				.get("linkedmember");

		ArrayList<IPLinkedMember> alLinkedMember = new ArrayList<IPLinkedMember>();
		IPLinkedMember linkedMember = null;

		for (HashMap<String, Object> hmLinkedMember : alLinkedMembers) {
			linkedMember = new IPLinkedMember();
			linkedMember = (IPLinkedMember) populateFields(linkedMember, IPLinkedMember.class, hmLinkedMember);
			alLinkedMember.add(linkedMember);
		}
		return alLinkedMember;
	}

	private static IPUserFraudPassword getUserFraudPasswordResponse(Map<String, Object> hmInquireProfileResponse) throws Exception{
		IPUserFraudPassword userFraudPassword = new IPUserFraudPassword();
		HashMap<String, Object> hmUserFraudPassword = (HashMap<String, Object>) hmInquireProfileResponse
				.get("userFraudPassword");
		userFraudPassword = (IPUserFraudPassword) populateFields(userFraudPassword, IPUserFraudPassword.class,
				hmUserFraudPassword);

		return userFraudPassword;
	}

	private static Object populateFields(Object obj, Class className, HashMap hashMap) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		obj = Class.forName(className.getName()).newInstance();
		Field[] fields = obj.getClass().getDeclaredFields();
		PropertyAccessor accessor = PropertyAccessorFactory.forBeanPropertyAccess(obj);
		for(Field field: fields) {
			if(hashMap.get(field.getName()) != null) {
				if(hashMap.get(field.getName()) instanceof Long || hashMap.get(field.getName()) instanceof Character)
					accessor.setPropertyValue(field.getName(), hashMap.get(field.getName()).toString());
				else
					accessor.setPropertyValue(field.getName(), (String) hashMap.get(field.getName()));
			}
		}
		return obj;
	}
}
