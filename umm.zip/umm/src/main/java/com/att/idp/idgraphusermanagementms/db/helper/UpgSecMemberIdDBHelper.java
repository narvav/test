package com.att.idp.idgraphusermanagementms.db.helper;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.mpsys.common.utils.*;
import net.logstash.logback.argument.StructuredArguments;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

import static com.att.mpsys.common.utils.CErrorDefs.COMMON_APP_INFO;
import static com.att.mpsys.common.utils.CommonErrorMap.makeCategoryMap;

/**
 * This class provides helper methods for upgrading secondary member IDs.
 * It includes methods for checking service eligibility, preparing service inputs, validating email addresses, and more.
 */
@Component
public class UpgSecMemberIdDBHelper {
    private static String sClassName = "UpgSecMemberIdDBHelper";
    public static final Logger logger = LoggerFactory.getLogger(UpgSecMemberIdDBHelper.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private DBHelper oDBHelper;
    @Autowired
    private ErrorMetricHandler errorMetricHandler;

    private static final String ADD_UPG_SEC_MEMEBR_GROUP_SQL = "INSERT INTO MEMBERGROUP(" + "GROUP_NUM,PARENT_NAME," + "DOMAIN_ID," + "LAST_MODIFIED_BY," + "PREMIUM_800_IND " + ") VALUES(" + "?, ?, ?, ?, ?)";
    private static final String QUERY_SEC_MEMBERID_SQL = "SELECT mem.MEMBER_NUM, mem.MEMBER_NAME, mem.DOMAIN_ID, d.DOMAIN_NAME, " + "mem.PARENT_CHILD_IND, mem.GROUP_NUM, mem.BAN, mem.LAST_MODIFIED_BY, mg.PARENT_NAME " + "FROM MEMBER mem " + "JOIN MEMBERGROUP mg ON mem.GROUP_NUM = mg.GROUP_NUM " + "JOIN DOMAIN d ON mem.DOMAIN_ID = d.DOMAIN_ID " + "WHERE mem.MEMBER_NAME = ? AND d.DOMAIN_NAME = ?";

    public Map<String, Object> upgSecMemberId(Map<String, Object> hmInput) {
        String sMethodName = ".upgSecMemberId.";

        Map<String, Object> hmResult = null;
        String stAppInfo = null;
        String stAppStatusCode = null;
        Map<String, Object> hmQuerySecMemId = null;
        logger.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmInput));
        try {

            hmQuerySecMemId = querySecMemberId(hmInput);

            logger.info("{}{}USMIDH.USMI.02 : {}:{}", sClassName, sMethodName, "Response from querySecMemberId () ", hmQuerySecMemId);

            if (hmQuerySecMemId == null || hmQuerySecMemId.isEmpty()) {
                stAppInfo = "querySecMemberId response is null or Empty";
                logger.info("{}{}USMIDH.USMI.03 : {}", sClassName, sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                return hmResult;
            }

            stAppStatusCode = (String) hmQuerySecMemId.get(CErrorDefs.COMMON_APP_STATUS_CODE);

            if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                stAppInfo = (String) hmQuerySecMemId.get(CErrorDefs.COMMON_APP_INFO);
                logger.info("{}{}USMIDH.USMI.04 : {}", sClassName, sMethodName, stAppInfo);
                hmResult = makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                return hmResult;
            }
            // update the member group table
            HashMap hmQuerySecMemIdResults = (HashMap) hmQuerySecMemId.get("hmQuerySecMemIdResults");

            logger.info("{}{}USMIDH.USMI.05 : {}:{}", sClassName, sMethodName, "Calling processData () with input = ", hmQuerySecMemId);
            hmResult = processData(hmQuerySecMemIdResults);
            logger.info("{}{}USMIDH.USMI.06 : {}:{}", sClassName, sMethodName, "Response from processData () ", hmResult);

            if (hmResult == null || hmResult.isEmpty()) {
                stAppInfo = "querySecMemberId response is null or Empty";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                logger.info("{}{}USMIDH.USMI.07 : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }

            stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

            if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                stAppInfo = "querySecMemberId was failed." + hmResult.get(CErrorDefs.COMMON_APP_INFO);
                logger.info("{}{}USMIDH.USMI.08 : {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }

            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS);
            hmResult.put(COMMON_APP_INFO, CommonDefs.COMMON_SUCCESS_MSG);

        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_DB_NUM, e.getMessage());
            String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
            logger.error("{}{} USMIDH.USMI.09  Exception in upgSecMemberId :{} ", sClassName, sMethodName, errorCode);
            return hmResult;
        }
        return hmResult;
    }

    private Map<String, Object> querySecMemberId(Map<String, Object> hmInput) {
        final String sMethodName = ".querySecMemberId.";
        Map<String, Object> hmResult = CommonUtil.getHashMap();
        String stAppInfo = null;

        try {
            String secMemberId = (String) hmInput.get("secMemberId");
            String secDomain = (String) hmInput.get("secDomain");

            if (StringUtils.isBlank(secMemberId) || StringUtils.isBlank(secDomain)) {
                stAppInfo = "Secondary MemberId or Domain is empty";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, stAppInfo);
                logger.info("{}{} USMIDH.QSMI.01: {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }

            List<Object> params = Arrays.asList(secMemberId, secDomain);
            logger.info("{}{} USMIDH.QSMI_02: querySecMemIdSql: QUERY_SEC_MEMBERID_SQL {}", sClassName, sMethodName, QUERY_SEC_MEMBERID_SQL);
            long tTime = 0;
            Date dtStartDate = new Date();
            List<Map<String, Object>> queryResponse = jdbcTemplate.queryForList(QUERY_SEC_MEMBERID_SQL, params.toArray());
            tTime = (System.currentTimeMillis() - dtStartDate.getTime());
            logger.info("{}{} USMIDH.QSMI_03 :Total time taken to execute query = {} milliseconds ", sClassName, sMethodName, tTime);


            if (queryResponse.isEmpty()) {
                stAppInfo = "No row found";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo);
                logger.info("{}{}USMIDH.QSMI.04 error: {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }

            Map<String, Object> queryResult = queryResponse.get(0);
            String parentChildInd = null;
            String ban = null;
            if (queryResult.get("PARENT_CHILD_IND") != null)
                parentChildInd = (String) queryResult.get("PARENT_CHILD_IND");
            if (queryResult.get("BAN") != null)
                ban = (String) queryResult.get("BAN");

            if (!"C".equals(parentChildInd)) {
                stAppInfo = "MemberId in request is not secondary memberId";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_NOT_CHILD_NUM, stAppInfo);
                logger.info("{}{}USMIDH.QSMI.05 error: {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }

            if (StringUtils.isNotBlank(ban)) {
                stAppInfo = "Cannot upgrade a UVerse subaccount to Primary";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, stAppInfo);
                logger.info("{}{}USMIDH.QSMI.06 error: {}", sClassName, sMethodName, stAppInfo);
                return hmResult;
            }

            Map<String, Object> hmQuerySecMemIdResults = new HashMap<>();
            hmQuerySecMemIdResults.put(MPSDefs.DB_PARENT_CHILD_IND, parentChildInd);
            hmQuerySecMemIdResults.put(MPSDefs.DB_MEMBER_NUM, queryResult.get("MEMBER_NUM"));
            hmQuerySecMemIdResults.put(MPSDefs.DB_MEMBER_NAME, queryResult.get("MEMBER_NAME"));
            hmQuerySecMemIdResults.put(MPSDefs.DB_DOMAIN_ID, queryResult.get("DOMAIN_ID"));
            hmQuerySecMemIdResults.put(MPSDefs.DB_LAST_MODIFIED_BY, queryResult.get("LAST_MODIFIED_BY"));
            hmQuerySecMemIdResults.put(MPSDefs.DB_BAN, ban);

            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS);
            hmResult.put("hmQuerySecMemIdResults", hmQuerySecMemIdResults);

        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            hmResult = CommonErrorMap.makeExceptionMap(e);
            String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
            logger.error("{}{}USMIDH.QSMI.07 {}", sClassName, sMethodName, errorCode);

        }
        return hmResult;
    }

    private Map<String, Object> processData(HashMap<String, Object> querySecMemIdResults) {
        final String methodName = ".processData.";
        Map<String, Object> result = CommonUtil.getHashMap();
        try {
            long newGroupNum = oDBHelper.getNextMemberGroupId();
            logger.info("{}{}USMIDH.PD.01  Calling getNextMemberGroupId method with input: {}", sClassName, methodName, newGroupNum);

            List<Object> params = new ArrayList<>();
            params.add(newGroupNum);
            params.add(querySecMemIdResults.get(MPSDefs.DB_MEMBER_NAME));
            params.add(querySecMemIdResults.get(MPSDefs.DB_DOMAIN_ID));
            params.add(querySecMemIdResults.get(MPSDefs.DB_LAST_MODIFIED_BY));
            params.add(MPSDefs.PREMIUM_800_IND_NO);

            logger.info("{}{}USMIDH.PD.02  Calling addUpgSecMemberGroup method with input: {}", sClassName, methodName, ADD_UPG_SEC_MEMEBR_GROUP_SQL);
            long startTime = System.currentTimeMillis();
            int rowCount = jdbcTemplate.update(ADD_UPG_SEC_MEMEBR_GROUP_SQL, params.toArray());

            long elapsedTime = System.currentTimeMillis() - startTime;
            logger.info("{}{}USMIDH.PD.03  Total time taken to execute query: {}{} milliseconds", sClassName, methodName, elapsedTime,rowCount);

            updateMemberGroupNum(newGroupNum, querySecMemIdResults.get(MPSDefs.DB_MEMBER_NUM));
            updateParentChildInd(querySecMemIdResults.get(MPSDefs.DB_MEMBER_NUM));
            updateMemberServiceGroupNum(newGroupNum, querySecMemIdResults.get(MPSDefs.DB_MEMBER_NUM));

            result = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG);

        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            result = CommonErrorMap.makeExceptionMap(e);
            String errorCode = (String) result.get(MPSDefs.APP_STATUS_CODE);
            String errorMsg = (String) result.get(MPSDefs.APP_STATUS_MSG);
            logger.error("{}{}USMIDH.PD.04 {}{}", sClassName, result, errorCode, errorMsg);
        }
        return result;
    }

    private void updateMemberGroupNum(long newGroupNum, Object memberNum) {
        final String methodName = ".updateMemberGroupNum.";
        String sql = "UPDATE MEMBER SET GROUP_NUM = ? WHERE MEMBER_NUM = ?";
        List<Object> params = Arrays.asList(newGroupNum, memberNum);

        logger.info("{}{}USMIDH.UMGN.01   Calling updateMemberGroupNum method with input: {}", sClassName, methodName, sql);
        long startTime = System.currentTimeMillis();
        int rowCount=jdbcTemplate.update(sql, params.toArray());

        long elapsedTime = System.currentTimeMillis() - startTime;
        logger.info("{}{}USMIDH.UMGN.02  Total time taken to execute query: {} {}milliseconds", sClassName, methodName, elapsedTime,rowCount);
    }

    private void updateParentChildInd(Object memberNum) {
        final String methodName = ".updateParentChildInd.";
        String sUpdateParentChildIndsql = "UPDATE MEMBER SET PARENT_CHILD_IND = ? WHERE MEMBER_NUM = ?";
        List<Object> params = Arrays.asList("P", memberNum);

        logger.info("{}{}USMIDH.UPCI.01: Calling updateParentChildInd= {}", sClassName, methodName, sUpdateParentChildIndsql);

        long startTime = System.currentTimeMillis();
        int rowCount=jdbcTemplate.update(sUpdateParentChildIndsql, params.toArray());

        long elapsedTime = System.currentTimeMillis() - startTime;
        logger.info("{}{}USMIDH.UPCI.02  Total time taken to execute query: {}{} milliseconds", sClassName, methodName, elapsedTime,rowCount);
    }

    private void updateMemberServiceGroupNum(long newGroupNum, Object memberNum) {
        long elapsedTime = 0;
        final String methodName = ".updateMemberServiceGroupNum.";
        String sql = "UPDATE MEMBERSERVICE SET GROUP_NUM = ? WHERE MEMBER_NUM = ?";
        List<Object> params = Arrays.asList(newGroupNum, memberNum);

        logger.info("{}{}USMIDH.UMSG.01 :  Calling updateMemberServiceGroupNum method with input {}", sClassName, methodName, sql);
        long startTime = System.currentTimeMillis();
       int rowCount= jdbcTemplate.update(sql, params.toArray());

        elapsedTime = System.currentTimeMillis() - startTime;
        logger.info("{}{}USMIDH.UMSG.02 :  Total time taken to execute query= {}{ milliseconds", sClassName, methodName, elapsedTime,rowCount);
    }
}
