package com.att.idp.idgraphusermanagementms.resource.response;

import com.att.idp.core.exception.ServiceError;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;


@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "DeleteUserResponse")
public class DeleteUserResponse {

	@JsonIgnore
	protected final String transactionName= ProfileOrchestrationConstants.DELETE_USER_TRANS_NAME;
	
	@JsonIgnore
	private String appStatusMsg;
	@JsonIgnore
	private String appStatusCode;
	@JsonIgnore
	private String appInfo;
	@JsonIgnore
	private String appCategoryCode;
	@JsonProperty("idp-trace-id")
	private String idpTraceId;
	@JsonProperty("error")
	private ServiceError errors;
	
}