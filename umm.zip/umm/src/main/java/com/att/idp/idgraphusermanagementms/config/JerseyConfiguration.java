package com.att.idp.idgraphusermanagementms.config;

import java.util.logging.Logger;

import jakarta.ws.rs.ApplicationPath;

import com.att.idp.idgraphusermanagementms.resource.impl.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.idp.core.config.BaseJerseyConfiguration;
import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataExceptionMapper;
import com.att.idp.idgraphusermanagementms.exceptions.MPSExceptionMapper;
import com.att.idp.idgraphusermanagementms.exceptions.ValidationExceptionMapper;
import com.att.idp.shutdown.jersey.adapter.JerseyShutdownAdapter; // Seed 2.5.0, Jersey default shutdown behavior
import com.att.idp.shutdown.jersey.filter.AfterResourceResponseFilter;
import com.att.idp.shutdown.jersey.filter.BeforeResourceRequestFilter;

/**
 * This Class reads and sets all configuration related to Jersey
 * 
 * 
 */
@Component
@ApplicationPath("/idgraphusermanagementms/v1")
public class JerseyConfiguration extends BaseJerseyConfiguration {

	/*
	 * Please do not edit or remove the LOGGER_NAME name declaration as it is
	 * critical to have this identifier for server side logging
	 */
	public static final String LOGGER_NAME = "com.att.idp.logging.server.JerseyLogging";
	private static final Logger eelfLogger = Logger.getLogger(LOGGER_NAME);

	/**
	 * This is the main constructor which register the Jersey configs
	 * 
	 * @param pJerseyShutdownAdapter
	 *            - added in Seed 2.5.0, will be autowired with
	 *            JerseyShutdownAdapter started by idp-shutdown-jersey module
	 */
	@Autowired
	public JerseyConfiguration(@Autowired JerseyShutdownAdapter pJerseyShutdownAdapter) {

		eelfLogger.info(" JERSEY CONFIGURATION ");
		register(new AfterResourceResponseFilter(pJerseyShutdownAdapter));
		register(new BeforeResourceRequestFilter(pJerseyShutdownAdapter));
		register(UserProfileResourceImpl.class);
		register(InvalidInputDataExceptionMapper.class);
		register(ValidationExceptionMapper.class);
		register(UpdateUserContactCBRResourceImpl.class);
		register(RegisterUserResourceImpl.class);
		register(MemberResourceImpl.class);
		register(MPSExceptionMapper.class);
		register(AddSecMemberIdResourceImpl.class);
		register(UpgSecMemberIdResourceImpl.class);
		register(ProfanityScannerRosurceImpl.class);
		register(UserPasswordResourceImpl.class);
		register(EmailAliasResourceImpl.class);
		register(QueryMemberIdResourceImpl.class);
		register(DeleteUserResourceImpl.class);
        register(RegistrationOrchestrationResourceImpl.class);
	}
}