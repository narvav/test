package com.att.idp.idgraphusermanagementms.queue.message.helpers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.att.mpsys.common.helpers.FeatureManagerHelper;
import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.queue.message.sender.JMSQueueSender;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import org.apache.commons.lang3.StringUtils;

/**
 * The UpdateUserFraudQueueHelper class is part of the com.att.idp.idgraphusermanagementms.queue.message.helpers package.
 * It is a helper class that assists in sending messages to the message queue when a user's fraud status is updated.
 * The class has several methods including sendMessageToMQ, prepareDbusInput, and prepareDataForAsyncCall.
 * sendMessageToMQ is responsible for sending the message to the queue and handling the response.
 * prepareDbusInput is responsible for preparing the DBUS input for the message.
 * prepareDataForAsyncCall is responsible for preparing the data for the asynchronous call.
 * The class also has several fields including a logger, an instance of JMSQueueSender, and various constants.
 */
@Component
public class UpdateUserFraudQueueHelper {

	public static final Logger log = LoggerFactory.getLogger(UpdateUserFraudQueueHelper.class);

	@Autowired
	private JMSQueueSender jmsQueueSender;

    @Autowired
    FeatureManagerHelper featureManager;

    @Autowired
    PublishMqAehHelper publishMqAehHelper;

	private String sClassName = "UpdateUserFraudQueueHelper";
	
	/**
	 * This method is part of the UpdateUserFraudQueueHelper class.
	 * It is responsible for sending a message to the message queue when a user's fraud status is updated.
	 * The method takes a HashMap, another HashMap, and a String as input.
	 * The first HashMap contains the input data, the second HashMap contains the DB member info,
	 * and the String is the previous lock level.
	 * The method prepares the data for the asynchronous call, prepares the DBUS input, and sends the request to JMSQueueSender.
	 * If the response from the JMSQueueSender is empty or unsuccessful, the method returns an error.
	 * If the response is successful, the method returns a success message.
	 *
	 * @param hmInput The HashMap containing the input data.
	 * @param hmDBMemberInfo The HashMap containing the DB member info.
	 * @param sPreviousLockLevel The previous lock level.
	 * @return A HashMap containing the response from the JMSQueueSender.
	 */
	public Map<String,Object> sendMessageToMQ(Map<String, Object> hmInput, Map<String, String> hmDBMemberInfo, String sPreviousLockLevel, ArrayList<Map<String, Object>> alConsDbus) {
		
		String sMethodName = ".sendMessageToMQ.";
		String stAppInfo=null;
		String stAppStatusCode = null;
		ArrayList alDbusInp =new ArrayList();
		String userLockLevel = (String) hmInput.get(CommonDefs.USER_LOCK_LEVEL);
		Map<String,Object> hmResult = (HashMap) prepareDataForAsyncCall(hmInput, hmDBMemberInfo, sPreviousLockLevel);
		log.debug("{}{}UUFH_23 : Response from prepareDataForAsyncCall : {}", sClassName, sMethodName, hmResult);
		//adding events info related to account lock
		if(userLockLevel !=null && userLockLevel.equals("2")) {
			for(int i=0; i<alConsDbus.size();i++) {
				alDbusInp.add(alConsDbus.get(i));
			}
		}
		alDbusInp.addAll((ArrayList)(hmResult.get("dbusInput")));
		
		log.debug("{}{}UUFH_24 : makeAsyncCall : alDbusInp : {}", sClassName, sMethodName, alDbusInp);
		
		if (alDbusInp != null && !alDbusInp.isEmpty()) {

			Map<String,Object> hmDbusInput = prepareDbusInput(hmInput,hmDBMemberInfo, alDbusInp);
			String sCallDbus = (String) hmInput.get(CommonDefs.CALLDBUS);
			if (sCallDbus == null || sCallDbus.trim().isEmpty() || sCallDbus.equalsIgnoreCase(CommonDefs.IND_Y)) {

                //mq aeh switch
                String updateUserFraudMQAEHEnabled = featureManager.getValue("cfg-idgraph-updateuserfraud-mq-aeh-switch");
                updateUserFraudMQAEHEnabled = (updateUserFraudMQAEHEnabled != null && !updateUserFraudMQAEHEnabled.isEmpty()) ? updateUserFraudMQAEHEnabled : "MQ";
                log.info("ixp flag updateUserFraudMQAEHEnabled MQ AEH Value: {}", updateUserFraudMQAEHEnabled);

                //clm switch
                String updateUserFraudClmEnabled = featureManager.getValue("cfg-idgraph-updateuserfraud-notification-clm-switch");
                updateUserFraudClmEnabled = (updateUserFraudClmEnabled != null && !updateUserFraudClmEnabled.isEmpty()) ? updateUserFraudClmEnabled : "MQ";
                log.info("ixp flag updateUserFraudClmEnabled CLM Value: {}", updateUserFraudClmEnabled);

                hmResult = publishMqAehHelper.invokeMqAEH(hmDbusInput, hmInput, alDbusInp, sClassName,
                        sMethodName, updateUserFraudMQAEHEnabled, updateUserFraudClmEnabled);

				if (MapUtils.isEmpty(hmResult)) {
					stAppInfo = "Null Response returned from JMSQueueSender.send";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					log.info("{}{}UUFQS_03 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}

				stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
				if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
					log.info("{}{}UUFQS_04 : ", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
					hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
					return hmResult;
				} else {
					hmResult.put("isTransactionRollback", true);
				}
			}
			
			if (sCallDbus != null && sCallDbus.equals(CommonDefs.IND_N)) {
				hmResult.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, hmDbusInput);
			}

		}
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);		
		return hmResult;
	}


	private Map<String,Object> prepareDbusInput(Map<String, Object> hmInput,Map<String, String> hmDBMemberInfo, ArrayList alDbusInp) {
		HashMap<String,Object> hmDbusInput = CommonUtil.getHashMap();
		hmDbusInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
		hmDbusInput.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get("dbusTransactionId"));
		hmDbusInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
		hmDbusInput.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		hmDbusInput.put(CommonDefs.EVENTNAME, CommonDefs.MICRO_SERVICE_EVENT);
		hmDbusInput.put(CommonDefs.MS_OPERTAION, (String) hmInput.get(CommonDefs.TRANSACTION_NAME));
		hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, (String) hmDBMemberInfo.get(CommonDefs.MEMBER_NUM));
		hmDbusInput.put(CommonDefs.EVENTS_DATA, alDbusInp);
		
		if (hmInput.containsKey(CommonDefs.SOURCE_IP_ADDRESS)) {
			hmDbusInput.put(CommonDefs.SOURCE_IP_ADDRESS, (String) hmInput.get(CommonDefs.SOURCE_IP_ADDRESS));
		}
		return hmDbusInput;
	}

	
	/**
	 * @param hmInput
	 * @return hmEventData
	 */
	private Map<String,Object> prepareDataForAsyncCall(Map<String, Object> hmInput, Map<String, String> hmDBMemberInfo, String sPreviousLockLevel) {
		
		HashMap<String,Object> hmResult = new HashMap();
		HashMap<String,Object> hmAtlasInput = CommonUtil.getHashMap();
		ArrayList alConsDbus = CommonUtil.getArrayList();
		List alNotificationData = CommonUtil.getArrayList();
		Map<String,Object> hmNotificationData = new HashMap();
		String userLockLevel = (String) hmInput.get(CommonDefs.USER_LOCK_LEVEL);
        // Only add AtlasIdentityManagementPublisher event when lock level is NOT "0"

        if (userLockLevel != null && !userLockLevel.equals("0")) {
            hmAtlasInput.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get("dbusTransactionId"));
            hmAtlasInput.put(CommonDefs.TRANSACTION_NAME, "UpdateMember");
            hmAtlasInput.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
            hmAtlasInput.put(CommonDefs.SLID, (String) hmDBMemberInfo.get(CommonDefs.MEMBER_NAME));
            hmAtlasInput.put(CommonDefs.SERVICE_NAME, CommonDefs.KEY_SLID);
            hmAtlasInput.put(CommonDefs.USER_LOCK_REASON_CODE, (String) hmInput.get(CommonDefs.USER_LOCK_REASON_CODE));
            hmAtlasInput.put(CommonDefs.AGENT_ID, (String) hmInput.get(CommonDefs.AGENT_ID));
            hmAtlasInput.put(CommonDefs.EVENTNAME, CommonDefs.EVENTNAME_ATLAS_IDENTITY_MANAGEMENT_PUBLISHER);
            hmAtlasInput.put(CommonDefs.SUBEVENT, "FraudAction");
            hmAtlasInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
            hmAtlasInput.put(CommonDefs.USER_LOCK_LEVEL, (String) hmInput.get(CommonDefs.USER_LOCK_LEVEL));
            hmAtlasInput.put(MPSDefs.DB_SLID_MEMBER_NUM, hmInput.get(CommonDefs.SLID_MEMBER_NUM));

			alConsDbus.add(hmAtlasInput);
		}
			HashMap<String,Object> hmNotificationInput = new HashMap();
			hmNotificationInput.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get("dbusTransactionId"));
			hmNotificationInput.put(CommonDefs.TRANSACTION_NAME, "UpdateMember");
			hmNotificationInput.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
			hmNotificationInput.put(CommonDefs.CUSTOMER_TYPE, "R");
			hmNotificationInput.put(CommonDefs.EVENTNAME, CommonDefs.PROP_EDD_NOTIFICATION_EVENT);
			hmNotificationInput.put(CommonDefs.SUBEVENT, CommonDefs.DBUS_NOTIFICATION_SUBEVENT_SLID);
			hmNotificationInput.put(CommonDefs.HANDLE, (String) hmDBMemberInfo.get(CommonDefs.MEMBER_NAME));
			hmNotificationInput.put(CommonDefs.DOMAIN, (String) hmDBMemberInfo.get("domainName"));
			hmNotificationInput.put(CommonDefs.SLID, (String) hmDBMemberInfo.get(CommonDefs.MEMBER_NAME));
			hmNotificationInput.put(CommonDefs.USER_LOCK_REASON_CODE,
					(String) hmInput.get(CommonDefs.USER_LOCK_REASON_CODE));
			hmNotificationInput.put(CommonDefs.DB_MEMBER_NUM, (String) hmDBMemberInfo.get(CommonDefs.MEMBER_NUM));
			hmNotificationInput.put(CommonDefs.USER_LOCK_LEVEL, (String) hmInput.get(CommonDefs.USER_LOCK_LEVEL));
			hmNotificationInput.put(CommonDefs.DB_PARENT_CHILD_IND,
					(String) hmDBMemberInfo.get(MPSDefs.DB_PARENT_CHILD_IND));
			hmNotificationInput.put(CommonDefs.FIRST_NAME, hmDBMemberInfo.get(CommonDefs.FIRST_NAME));
			hmNotificationInput.put(CommonDefs.LAST_NAME, hmDBMemberInfo.get(CommonDefs.LAST_NAME));

			hmNotificationData.put(CommonDefs.CONTACT_EMAIL, (String) hmDBMemberInfo.get(CommonDefs.CONTACT_EMAIL));
			hmNotificationData.put(CommonDefs.CONTACT_EMAIL_STATUS,
					hmDBMemberInfo.get(CommonDefs.CONTACT_EMAIL_STATUS));

			alNotificationData.add(hmNotificationData);
			hmNotificationInput.put(CommonDefs.NOTIFICATION_DATA, alNotificationData);
			hmNotificationInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
			hmNotificationInput.put(MPSDefs.DB_SLID_MEMBER_NUM, hmInput.get(CommonDefs.SLID_MEMBER_NUM));
		
			String sFnLinkedStatus = (String) hmDBMemberInfo.get(CommonDefs.LINKED_FN_USER_STATUS);
			if (StringUtils.isNotBlank(sFnLinkedStatus)
					&& (sFnLinkedStatus.equalsIgnoreCase(CommonDefs.FN_STATUS_PENDING)
							|| sFnLinkedStatus.equalsIgnoreCase(CommonDefs.FN_STATUS_SELF))) {
				hmNotificationInput.put(CommonDefs.FN_LINKED_IND, CommonDefs.IND_Y);
			}
			alConsDbus.add(hmNotificationInput);
		
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "SUCCESS");

		if (alConsDbus != null) {
			hmResult.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, alConsDbus);
		}
		return hmResult;

	
	}
	
	public Map sendMessageToMQ(Map<String, Object> hmInput, ArrayList alDbusInput) {
		String sMethodName = ".sendMessageToMQ.";
		HashMap hmResult = CommonUtil.getHashMap();
		String sCallDbus = (String) hmInput.get(CommonDefs.CALLDBUS);
		HashMap hmDbusInput = CommonUtil.getHashMap();
		String stAppStatusCode = null;
		String stAppInfo = null;

		try {
			String dbMemNum = (String) hmInput.get(CommonDefs.DB_MEMBER_NUM);
			String sSorInvariantId = (String) hmInput.get(CommonDefs.SOR_INVARIANT_ID);
			hmDbusInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
			if(dbMemNum != null && !dbMemNum.isEmpty()) {
				hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, dbMemNum);
			} else if(sSorInvariantId != null && !sSorInvariantId.isEmpty()) {
				hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, sSorInvariantId);
			}
			hmDbusInput.put(CommonDefs.MS_OPERTAION, "UpdateUserFraud");
			hmDbusInput.put(CommonDefs.TRANSACTION_NAME, "UpdateUserFraud");
			hmDbusInput.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
			hmDbusInput.put(CommonDefs.EVENTNAME, CommonDefs.MICRO_SERVICE_EVENT);
			hmDbusInput.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(CommonDefs.TRANSACTION_ID));
			hmDbusInput.put(CommonDefs.EVENTS_DATA, alDbusInput);

			if (sCallDbus != null && sCallDbus.equals(CommonDefs.IND_N)) {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "SUCCESS");
				hmResult.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, hmDbusInput);
			} else {

				// adding notification event
				log.info("{}{}UAQH_1.0 : Calling JMSQueueSender.send with inputHash : {}", sClassName,
						sMethodName, hmDbusInput);
				hmResult = (HashMap) jmsQueueSender.send((Map) hmDbusInput);
				log.info("{}{}UAQH_1.1 : ResponseHash from JMSQueueSender.send : {}", sClassName, sMethodName,
						hmResult);

				if (hmResult == null) {
					stAppInfo = "Null Response returned from JMSQueueSender.send";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					log.info("{}{}UAQH_1.2 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
				stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
				stAppInfo =(String) hmResult.get(CommonDefs.COMMON_APP_INFO);
				if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {

					stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
					log.info("{}{}UAQH_1.3 : Error occured {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
					return hmResult;
				}else {
					hmResult.put("isTransactionRollback", true);
				}
			}

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, log);
		}
		return hmResult;

	}
}
