package com.att.idp.idgraphusermanagementms.exceptions;

import java.io.Serializable;

import com.att.idp.idgraphusermanagementms.model.ErrorMessage;

/**
 * The MPSException class extends the Exception class and implements the Serializable interface.
 * This class is used to represent exceptions that are specific to the MPS (Message Processing System).
 * It contains an ErrorMessage object that can provide detailed information about the exception.
 */
public class MPSException extends Exception implements Serializable{

	private static final long serialVersionUID = 7728046821967210029L;

	/**
	 * The ErrorMessage object associated with this MPSException.
	 * This object typically contains detailed information about the exception.
	 */
	public ErrorMessage errorMessage;
	
	/**
	 * Default constructor for the MPSException class.
	 * This constructor calls the superclass constructor with no arguments.
	 */
	public MPSException(){
		super();
	}
	
	/**
	 * Constructor for the MPSException class that takes a message string as an argument.
	 * This constructor calls the superclass constructor with the provided message string.
	 *
	 * @param message The message string associated with the exception.
	 */
	public MPSException(String message){
		super(message);
	}
	
	/**
	 * Constructor for the MPSException class that takes an ErrorMessage object as an argument.
	 * This constructor calls the superclass constructor with the application information from the ErrorMessage object.
	 * It also sets the ErrorMessage object associated with this MPSException.
	 *
	 * @param errorMessage The ErrorMessage object associated with the exception.
	 */
	public MPSException(ErrorMessage errorMessage){
		super(errorMessage.getAppInfo());
		this.errorMessage = errorMessage;
	}
	
	

}
