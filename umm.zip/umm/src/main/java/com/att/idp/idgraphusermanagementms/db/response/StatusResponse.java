package com.att.idp.idgraphusermanagementms.db.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * This is the StatusResponse class which implements Serializable interface.
 * It represents a response for a status with properties like statusCode, statusName, and statusDesc.
 * Each property has its respective getter and setter methods.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({

})
public class StatusResponse implements Serializable {

	private static final long serialVersionUID = -197545473994227273L;
	private Long statusCode;
	private String statusName;
	private String statusDesc;
}