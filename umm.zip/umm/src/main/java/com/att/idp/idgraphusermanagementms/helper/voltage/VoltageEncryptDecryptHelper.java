package com.att.idp.idgraphusermanagementms.helper.voltage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * This class is part of the com.att.idp.idgraphusermanagementms.helper.voltage package.
 * It is a helper class for encryption and decryption operations.
 * It uses the EncryptUtil and DecryptUtil classes for these operations.
 * The class has two methods: getEncryptedValue and getDecryptedValue.
 * The getEncryptedValue method takes a string and a format name as input and returns the encrypted version of the string.
 * The getDecryptedValue method takes an encrypted string and a format name as input and returns the decrypted version of the string.
 */
@Component
public class VoltageEncryptDecryptHelper {
@Autowired
private EncryptUtil encryptUtil;

@Autowired
private DecryptUtil decryptUtil;

/**
 * This method is part of the VoltageEncryptDecryptHelper class.
 * It takes a string and a format name as input and returns the encrypted version of the string.
 * The method uses the EncryptUtil instance to encrypt the string.
 * The encrypted string is then returned as the result.
 *
 * @param value The string to be encrypted.
 * @param formatName The format type of the string.
 * @return The encrypted version of the input string.
 */
	public String getEncryptedValue(String value, String formatName) {
		return encryptUtil.getEncryptedValue(value, formatName);
	}
	
	/**
	 * This method is part of the VoltageEncryptDecryptHelper class.
	 * It takes an encrypted string and a format name as input and returns the decrypted version of the string.
	 * The method uses the DecryptUtil instance to decrypt the string.
	 * The decrypted string is then returned as the result.
	 *
	 * @param value The encrypted string to be decrypted.
	 * @param formatName The format type of the string.
	 * @return The decrypted version of the input string.
	 */
	public String getDecryptedValue(String value, String formatName) {
		return decryptUtil.getDecryptedValue(value, formatName);
	}
	
}

