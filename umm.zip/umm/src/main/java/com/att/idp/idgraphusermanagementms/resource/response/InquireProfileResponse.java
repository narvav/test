package com.att.idp.idgraphusermanagementms.resource.response;

import java.util.ArrayList;

import com.att.idp.core.exception.ServiceError;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class represents the response from the Inquire Profile operation in the system.
 * It contains fields for transactionName, appStatusMsg, appStatusCode, appInfo, appCategoryCode, memberdetail, userSecurityInfo, memberServiceRole, linkedMember, userFraudLock, userFraudPassword, userLockout, errors, and idpTraceId.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Jackson's @JsonIgnore, @JsonProperty, @JsonIgnoreProperties, and @JsonInclude annotations to handle JSON serialization and deserialization.
 * It also uses Swagger's @ApiModel annotation to provide metadata for the Swagger UI.
 *
 * The class provides getter and setter methods for all fields.
 * It also overrides the toString method to return a string representation of the object.
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "InquireProfileResponse")
public class InquireProfileResponse {

	@JsonIgnore
	private String transactionName;

	private String appStatusMsg;

	private String appStatusCode;

	private String appInfo;

	@JsonIgnore
	private String appCategoryCode;

	private IPMemberDetail memberdetail;

	private IPUserSecurityInfo userSecurityInfo;

	private ArrayList<IPMemberServiceRole> memberServiceRole;

	private ArrayList<IPLinkedMember> linkedMember;

	private IPUserFraudLock userFraudLock;

	private IPUserFraudPassword userFraudPassword;

	private ArrayList<IPUserLockout> userLockout;

	private ServiceError errors;

	private String idpTraceId;

	@JsonProperty("member")
	public void setMemberdetail(IPMemberDetail memberdetail) {
		this.memberdetail = memberdetail;
	}

	@JsonProperty("error")
	public void setErrors(ServiceError errors) {
		this.errors = errors;
	}

	@JsonProperty("idp-trace-id")
	public void setIdpTraceId(String idpTraceId) {
		this.idpTraceId = idpTraceId;
	}

	@Override
	public String toString() {
		return "InquireProfileResponse [transactionName=" + transactionName + ", appStatusMsg=" + appStatusMsg
				+ ", appStatusCode=" + appStatusCode + ", appInfo=" + appInfo + ", appCategoryCode=" + appCategoryCode
				+ ", memberdetail=" + memberdetail + ", userSecurityInfo=" + userSecurityInfo + ", memberServiceRole="
				+ memberServiceRole + ", linkedMember=" + linkedMember + ", userFraudLock=" + userFraudLock
				+ ", userFraudPassword=" + userFraudPassword + ", userLockout=" + userLockout + ", errors="
				+ CommonUtilHelper.objectToString(errors) + ", idpTraceId=" + idpTraceId + "]";
	}
}