package com.att.idp.idgraphusermanagementms.model;

import java.io.Serializable;

import org.springframework.stereotype.Component;

/**
 * The ErrorMessage class is part of the com.att.idp.idgraphusermanagementms.model package.
 * It is a model class that represents an error message in the application.
 * The class has several fields: MessageId, appStatusMsg, appStatusCode, appInfo, and transactionName.
 * It also has getter and setter methods for these fields.
 * The class has two constructors: a default constructor and a constructor that initializes all the fields.
 * The getErrorResponseInfo method returns a string representation of the error message in a specific format.
 */
@Component
public class ErrorMessage implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2743055002111300115L;
	private String MessageId;  
	private String appStatusMsg; 
	private String appStatusCode; 
	private String appInfo; 
	private String transactionName;
		

	public ErrorMessage(){}
	
	/**
	 * Constructor for the ErrorMessage class.
	 * It initializes an ErrorMessage instance with the provided parameters.
	 *
	 * @param MessageId The unique identifier for the message.
	 * @param appStatusMsg The status message of the application.
	 * @param appStatusCode The status code of the application.
	 * @param appInfo Additional information about the application.
	 * @param transactionName The name of the transaction.
	 */
	public ErrorMessage(String MessageId, String appStatusMsg, String appStatusCode,String appInfo, String transactionName) {
		this.MessageId = MessageId;
		this.appStatusMsg = appStatusMsg;
		this.appInfo = appInfo;
		this.appStatusCode = appStatusCode;
		this.transactionName = transactionName;
	}

	public String getMessageId() {
		return MessageId;
	}

	public void setMessageId(String MessageId) {
		this.MessageId = MessageId;
	}

	public String getTransactionName() {
		return transactionName;
	}

	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}

	public String getAppStatusMsg() {
		return appStatusMsg;
	}

	public void setAppStatusMsg(String appStatusMsg) {
		this.appStatusMsg = appStatusMsg;
	}

	public String getAppInfo() {
		return appInfo;
	}

	public void setAppInfo(String appInfo) {
		this.appInfo = appInfo;
	}
	
	public String getErrInfo() {
		return appStatusCode;
	}

	public void setErrInfo(String appStatusCode) {
		this.appStatusCode = appStatusCode;
	}
	
	public String getErrorResponseInfo(){
		return "{"
				+ "\"appStatusCode\":\""+ appStatusCode +"\","
				+ "\"appStatusMsg\":\""+ appStatusMsg +"\","
				+ "\"appInfo\":\""+ appInfo +"\","
				+ "\"X-ATT-UniqueTransactionId\":\""+ MessageId +"\","
				+ "\"transactionName\":\""+ transactionName +"\""
				+ "}";
				
	}
	
}
