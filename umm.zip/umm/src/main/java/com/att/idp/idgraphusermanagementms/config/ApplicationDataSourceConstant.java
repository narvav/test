package com.att.idp.idgraphusermanagementms.config;

/**
 * This is an interface named ApplicationDataSourceConstant.
 * It contains constants that are used as keys for various components in the application's data source configuration.
 * These constants are used throughout the application to ensure consistency when referring to these components.
 */
public interface ApplicationDataSourceConstant {

	/** The data source **/
	String DATA_SOURCE = "dataSource";
	
	/** The entity manager factory **/
	String ENTITY_MANAGER_FACTORY = "entityManagerFactory";
	
	/** The transaction manager .**/
	String TRANSACTION_MANAGER = "transactionManager";
}