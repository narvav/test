package com.att.idp.idgraphusermanagementms.service.impl;

import java.util.Map;

import jakarta.ws.rs.core.HttpHeaders;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.ValidateUserCredentialsHelper;
import com.att.idp.idgraphusermanagementms.resource.request.ValidateUserCredentialsRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ValidateUserCredentialsResponse;
import com.att.idp.idgraphusermanagementms.service.ValidateUserCredentialsService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This class implements the ValidateUserCredentialsService interface and provides the implementation for validating user credentials in the system.
 * It is annotated with @Service to indicate that it's a Spring Bean and @Transactional to handle the transaction management.
 *
 * It contains a method validateUserCredentials which takes a ValidateUserCredentialsRequest object and HttpHeaders as parameters.
 * The method is expected to return a ValidateUserCredentialsResponse object.
 *
 * The ValidateUserCredentialsRequest object encapsulates the details of the user credentials validation operation to be performed.
 * HttpHeaders contains the request headers which may include additional information required for processing the request.
 *
 */
@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class ValidateUserCredentialsServiceImpl implements ValidateUserCredentialsService{

	public static final Logger logger = LoggerFactory.getLogger(ValidateUserCredentialsServiceImpl.class);

	private static String sClassName = "ValidateUserCredentialsServiceImpl";
	
	@Autowired
	private ValidateUserCredentialsHelper validateUserCredentialsHelper;
	
	@Override
	public ValidateUserCredentialsResponse validateUserCredentials(ValidateUserCredentialsRequest validateUserCredentialsRequest, HttpHeaders httpHeaders) {
		
		Map<String, Object> hmResponse = null;
		String sMethodName = ".validateUserCredentials.";
		
		logger.info(SpiMarker.getInstance(),"ValidateUserCredentialsServiceImpl.validateUserCredentials.VUCS_01 : Calling validateUserCredentialsHelper with Input : {}",StringUtils.normalizeSpace(validateUserCredentialsRequest.toString()));

		hmResponse = validateUserCredentialsHelper.validateUserCredentials(validateUserCredentialsRequest, httpHeaders);
		logger.info(SpiMarker.getInstance(),"{}{}VUCS_02 : Response from validateUserCredentials Helper : {}", sClassName, sMethodName, hmResponse);

		if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
			hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from validateUserCredentialsHelper.validateUserCredentials");
			logger.info(SpiMarker.getInstance(),"{}{}VUCS_03 : Null response from validateUserCredentialsHelper.validateUserCredentials", sClassName, sMethodName);
		} else {
			String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (stAppStatusCode == null) {
				hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from validateUserCredentialsHelper.validateUserCredentials");
				logger.info(SpiMarker.getInstance(),"{}{}VUCS_04 : Null response from validateUserCredentialsHelper.validateUserCredentials", sClassName, sMethodName);
			}
		}

		hmResponse.put("idp-trace-id", validateUserCredentialsRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME, validateUserCredentialsRequest.getTransactionName());
		ValidateUserCredentialsResponse validateuserCredentialsResponse = CommonUtilHelper.generateValidateUserCredentialsResponse(hmResponse);
		String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

		if (sTxnRollBack != null) {
			throw new InvalidInputDataException(hmResponse);
		}
		logger.info(SpiMarker.getInstance(),"{}{}VUCS_05 : Response from ValidateUserCredentialsServiceImpl.validateUserCredentials : {}", sClassName, sMethodName,
				validateuserCredentialsResponse);
		return validateuserCredentialsResponse;
	}
}