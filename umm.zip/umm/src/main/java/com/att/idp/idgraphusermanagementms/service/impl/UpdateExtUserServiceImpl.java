package com.att.idp.idgraphusermanagementms.service.impl;

import com.att.idp.idgraphusermanagementms.resource.request.ExtUserRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ExtUserResponse;
import com.att.idp.idgraphusermanagementms.service.UpdateExtUserService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.UpdateExtUserHelper;

import jakarta.ws.rs.core.MultivaluedMap;
import java.util.HashMap;
import java.util.Map;

/**
 * This class implements the UpdateExtUserService interface and provides the implementation for updating an external user in the system.
 * It is annotated with @Service to indicate that it's a Spring Bean and @Transactional to handle the transaction management.
 *
 * It contains a method updateExtUserResponse which takes an ExtUserRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return an ExtUserResponse object.
 *
 * The ExtUserRequest object encapsulates the details of the external user update operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class UpdateExtUserServiceImpl implements UpdateExtUserService {

    public static final Logger logger = LoggerFactory.getLogger(UpdateExtUserServiceImpl.class);

    private String sClassName = "updateExtUserServiceImpl";

    @Autowired
    private UpdateExtUserHelper updateExtUserHelper;

    @Override
    public ExtUserResponse updateExtUserResponse(ExtUserRequest extUserRequest, MultivaluedMap<String, String> requestHeader) {

        Map<String, Object> hmResponse = null;
        String sMethodName = ".updateExtUserResponse.";

        Map<String, Object> hmInput = CommonUtilHelper.objectToMap(extUserRequest);

        logger.info(SpiMarker.getInstance(), "ExtUserServiceImpl.extUserResponse.CUNS_01 : Calling updateExtUserHelper with Input : {}", hmInput);

        hmResponse = updateExtUserHelper.updateExtUser((HashMap<String, Object>) hmInput);

        hmResponse=CommonUtilHelper.processHmResponse(hmResponse, hmInput, "updateExtUserHelper", ".updateExtUser");

        hmResponse.put("idp-trace-id", extUserRequest.getIdpTraceId());
        hmResponse.put(CommonDefs.TRANSACTION_NAME, extUserRequest.getTransactionName());
        ExtUserResponse extUserResponse = CommonUtilHelper.generateExtUserResponse(hmResponse);

        String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

        if (sTxnRollBack != null) {
            throw new InvalidInputDataException(hmResponse);
        }
        logger.info("{}{}AUS_05 : Response from updateExtraUserServiceImpl.updateExtUserResponse : {}", sClassName, sMethodName,
                extUserResponse);
        return extUserResponse;
    }
}