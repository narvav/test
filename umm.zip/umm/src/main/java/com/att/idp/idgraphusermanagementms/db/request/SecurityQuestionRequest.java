package com.att.idp.idgraphusermanagementms.db.request;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * This is the SecurityQuestionRequest class which implements Serializable interface.
 * It represents a request for a security question with properties like securityQuestionId, securityQuestion, securityQuestionActive, securityQuestionType, membersForSecurityQuestionId, membersForSecurityQuestionId1, and membersForSecurityQuestionId2.
 * Each property has its respective getter and setter methods.
 */
@EqualsAndHashCode(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({
		"securityQuestionId",
		"securityQuestion",
		"securityQuestionActive",
		"securityQuestionType",
		"membersForSecurityQuestionId",
		"membersForSecurityQuestionId1",
		"membersForSecurityQuestionId2"
})
public class SecurityQuestionRequest extends SecurityQuestionBase implements Serializable {

	private static final long serialVersionUID = -6117394620222310862L;

	@JsonProperty("membersForSecurityQuestionId2")
	@JsonPropertyDescription("securityQuestion")
	private Set<MemberRequest> membersForSecurityQuestionId2 = new HashSet<>(0);

	@JsonProperty("membersForSecurityQuestionId1")
	@JsonPropertyDescription("securityQuestion")
	private Set<MemberRequest> membersForSecurityQuestionId1 = new HashSet<>(0);

	@JsonProperty("membersForSecurityQuestionId")
	@JsonPropertyDescription("securityQuestion")
	private Set<MemberRequest> membersForSecurityQuestionId = new HashSet<>(0);
}