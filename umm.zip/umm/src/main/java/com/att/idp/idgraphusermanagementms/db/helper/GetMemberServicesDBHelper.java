package com.att.idp.idgraphusermanagementms.db.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.att.mpsys.common.utils.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphusermanagementms.helper.voltage.ProcessVoltageHelper;
import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.idp.logging.marker.SpiMarker;
import org.springframework.web.util.HtmlUtils;

/**
 * This class is responsible for retrieving member services from the database.
 * It uses Spring's JdbcTemplate for database operations.
 *
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like JdbcTemplate and other helper classes.
 *
 * The class contains SQL queries as string constants for retrieving member services.
 * These queries are used in the corresponding methods for these operations.
 *
 * The main method in this class is:
 * - getMemberServices: This method retrieves the services associated with a member from the database. It takes a HashMap as input and returns a HashMap as output.
 *   The input HashMap contains key-value pairs for various member attributes like member number, ban, group number etc.
 *   The method first checks if the jdbcTemplate is null. If it is, it returns an error status.
 *   Then it retrieves the member attributes from the input HashMap.
 *   If the member attributes are not found, it returns an error status.
 *   Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
 *   Finally, it returns a status indicating whether the operation was successful or not.
 */
@Component
public class GetMemberServicesDBHelper extends AbstractDBHelper {

	private static final String CLASS_NAME = "GetMemberServicesDBHelper";
	public static final Logger logger = LoggerFactory.getLogger(GetMemberServicesDBHelper.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private GetMemberRolesDBHelper oGetMemberRolesDBHelper;

	@Autowired
	private GetSlidInfoDBHelper oGetSlidInfoDBHelper;

	@Autowired
	private FraudLockDBHelper oFraudLockDBHelper;

	@Autowired
	private MemberFraudPasswordDBHelper oMemberFraudPasswordDBHelper;

	@Autowired
	private ProcessVoltageHelper oProcessVoltageHelper;

	@Autowired
	private MemberServiceAttributeDBHelper oGetMemSvcAttr;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	@Autowired
	private PropertyManagerLoader propertyManagerLoader;

	public GetMemberServicesDBHelper(PropertyManagerLoader propertyManagerLoader) {
		super(propertyManagerLoader);
		this.propertyManagerLoader = propertyManagerLoader;
	}
	private static String dateFormat = "MMDDYYYY HH24:mi:ss";

	private static String memNumQuery =
			" SELECT "
					+ " secq.security_question_type as security_question_type, secq.security_question_active as security_question_active, "
					+ " mem.security_question_id_1, secq1.security_question as security_question_1, mem.security_answer_1, "
					+ " secq1.security_question_type as security_question_1_type, secq1.security_question_active as security_question_1_active, "
					+ " mem.security_question_id_2, secq2.security_question as security_question_2, mem.security_answer_2, "
					+ " secq2.security_question_type as security_question_2_type, secq2.security_question_active as security_question_2_active, "
					+ "  mem.previous_contact_email, TO_CHAR(mem.contact_email_est_date,'"
					+ dateFormat
					+ "') as contact_email_est_date, "

					+ " mem.language,"
					+ " TO_CHAR(mem.tos_reject_date, '" + dateFormat + "') AS tos_reject_date, mem.num_tos_rejects, "
					+ " mem.alert_ind, "
					+ " mem.agg_email_status, mem.last_member_status as last_member_status_code, stat3.status_name as last_member_status_name, mem.credit_checked_ind, mem.yreg_complete_ind, TO_CHAR(mem.lockout_timestamp, '"
					+ dateFormat
					+ "') as lockout_timestamp, mem.firstname, mem.lastname, mem.nickname, mem.last_four_ssn, mem.security_question_id, "
					+ " mem.gender, mem.proofing_zip, secq.security_question, "
					+ " mem.contact_email, mem.contact_email_valid, mem.password_dirty, mem.sha1_password, "
					+ " mem.des3_password, mem.failed_auth_count, "
					+ " TO_CHAR(mem.delete_request_date, '"
					+ dateFormat
					+ "') AS delete_request_date, mem.token, mem.remarks, mem.ban, mem.member_num, mem.member_name, mem.group_num, dom.domain_name, mem.domain_id, "
					+ " mem.enc_password, mem.md5_password, mem.parent_child_ind, mem.member_state, mem.agg_access_status, mem.agg_service_status, mem.mailhost, mem.fullname, mem.account_type,mem.optout_ind, mem.migration_ind, TO_CHAR(mem.migration_date, '"
					+ dateFormat
					+ "') AS migration_date, TO_CHAR(mem.create_date, '"
					+ dateFormat
					+ "') AS mem_create_date, TO_CHAR(mem.last_modified, '"
					+ dateFormat
					+ "') AS mem_last_modified, mem.last_modified_by AS last_modified_by, memGroup.parent_name, parentDom.domain_name as parent_domain, memGroup.premium_800_ind, memGroup.bulk_billing_ind,  memGroup.access_code, mem.sor_id, sor.sor_name, mem.access_id,  acc.access_name, serv.service_name, serv.service_type, "
					+ " serv.subaccount_eligible, serv.email_eligible, serv.entity_type, "
					+ " memService.service_id, memService.member_status AS member_status_code, "
					+ " memService.group_status AS group_status_code, stat1.status_name AS group_status_name, "
					+ " stat2.status_name AS member_status_name, "
					+ " TO_CHAR(memService.terminate_date, '"
					+ dateFormat
					+ "') AS terminate_date, "
					+ " TO_CHAR(memService.create_date, '"
					+ dateFormat
					+ "') AS create_date, TO_CHAR(memService.last_modified, '"
					+ dateFormat
					+ "') AS last_modified, memService.last_modified_by AS last_modified_by, "
					+ "memService.instance_id, "
					+ " TO_CHAR(memService.pending_disconnect_date, '"
					+ dateFormat
					+ "') AS pending_disconnect_date, portal.last_modified_by AS portal_last_modified_by, TO_CHAR(portal.create_date, '"
					+ dateFormat
					+ "') AS portal_create_date, portal.portal_provider as portal_provider, memService.sor_id as service_sor_id, sor1.sor_name as service_sor_name " //added for NAP by sk7243
					+ " ,memService.sor_invariant_id, memService.atlas_last_timestamp, memService.nickname as service_nickname, "
					+ " memService.default_account, TO_CHAR(memService.date_default_est, '"
					+ dateFormat
					+ "') AS date_default_est, memService.cpni_impacted, memService.suspend_reason_code, mem.dsl_net_password, mem.dsl_net_pw_encr_type, "
					+ " servassoc.sor_id1, "
					+ " nvl(servassoc.sor_invariant_id1, '--NULL--') as sor_invariant_id1, sor2.sor_name as sor_name1, "
					+ " servassoc.sor_id2, "
					+ " nvl(servassoc.sor_invariant_id2, '--NULL--') as sor_invariant_id2, sor3.sor_name as sor_name2, "
					+ " servassoc.assigned_by as asso_assigned_by, servassoc.last_modified_by as asso_last_modified_by, "
					+ " TO_CHAR(servassoc.create_date, '"
					+ dateFormat
					+ "') AS asso_create_date, "
					+ " TO_CHAR(servassoc.last_modified, '"
					+ dateFormat
					+ "') AS asso_last_modified, "
					+ " iptv.portal_svc_provider as portal_svc_provider, "
					+ " TO_CHAR(portal.last_modified, '"
					+ dateFormat
					+ "') AS portal_provider_last_modified, dsl.tdsl_ind, dsl.wtn, dsl.dslam_type, TO_CHAR(mem.csr_initiated_lockout_ts, '"
					+ dateFormat
					+ "') AS csr_initiated_lockout_ts, mem.browser_language, mem.contact_email_status, mem.ssha_password, "
					+ " mem.slid_member_num, mem.autogenerated_ind, mem.activated_ind, portal.plite_ind, "
					+ " memService.parent_sor_id, memService.parent_sor_invariant_id, memService.uverse_service_ind, serv.major_service_id, " //June 2011
					+ " mem.birthdate_venc, mem.passcode_venc, mem.security_answer_venc, TO_CHAR(mem.last_verified, '"
					+ dateFormat
					+ "') AS last_verified, mem.created_by, TO_CHAR(mem.main_ctn_opt_out, '"
					+ dateFormat
					+ "') AS main_ctn_opt_out, dsl.dns_err_optout_ind, memService.unification_pending, TO_CHAR(mem.onl_qa_est_date, '"
					+ dateFormat
					+ "') AS onl_qa_est_date, "
					+ " mem.fn_linked_userid, "
					+ " mem.fn_linked_status, "
					// 2103 -  SSHA-256 encryption changes
					+ " memaux.password_venc AS gen_password_venc,"
					+ " memaux.password_type  AS gen_password_type,"

					+ " memaux.enc_password_venc, memaux.md5_password_venc, memaux.sha1_password_venc, " //1612:SID 49298
					+ " memaux.des3_password_venc, memaux.ssha_password_venc, memaux.security_answer_1_venc, " //1612:SID 49298
					+  " memaux.security_answer_2_venc, TO_CHAR(memaux.recent_fraud_pw_date, '"+ dateFormat +"') AS recent_fraud_pw_date " //1612:SID 49298
					+ " FROM "
					+ " MEMBER mem,MEMBERGROUP memGroup,MEMBERSERVICE memService,DOMAIN dom, DOMAIN parentDom, SecurityQuestion secq, "
					+ " SYSTEMOFRECORD sor, NETWORKACCESS acc,SERVICE serv, STATUS stat1,STATUS stat2, STATUS stat3, PORTALUSER portal, "
					+ " SYSTEMOFRECORD sor1, SecurityQuestion secq1, SecurityQuestion secq2, IPTVUSER iptv,"
					+ " serviceassociation servassoc, SYSTEMOFRECORD sor2, SYSTEMOFRECORD sor3, "
					+ " MEMBERAUX memaux, " //1612:SID 49298
					+ " DSLUSER dsl "
					+ ""
					+ " WHERE "
					+ " mem.sor_id=sor.sor_id AND mem.access_id=acc.access_id "
					+ " AND mem.domain_id=dom.domain_id AND memGroup.domain_id=parentDom.domain_id AND mem.group_num=memGroup.group_num "
					+ " AND mem.security_question_id =secq.security_question_id (+) "
					+ " AND mem.security_question_id_1 =secq1.security_question_id (+) "
					+ " AND mem.security_question_id_2 =secq2.security_question_id (+) "
					+ " AND memService.sor_id =sor1.sor_id (+) "
					+ " AND memService.member_num = portal.member_num(+) AND memService.service_id = portal.service_id(+) AND mem.member_num=memService.member_num (+) AND memService.service_id=serv.service_id (+) "
					+ " AND memService.member_status=stat2.status_code (+) AND memService.group_status = stat1.status_code (+) AND mem.last_member_status = stat3.status_code (+) "
					+ " AND memService.member_num = iptv.member_num(+) AND memService.service_id = iptv.service_id(+) "
					+ " AND servassoc.sor_id1(+) = memService.sor_id AND servassoc.sor_id1 = sor2.sor_id (+) AND servassoc.sor_id2 = sor3.sor_id (+) "
					+ " AND servassoc.sor_invariant_id1(+) = memService.sor_invariant_id "
					+ " AND memService.member_num = dsl.member_num (+) "
					+ " AND mem.member_num = memaux.member_num (+) " //1612:SID 49298
					+ " AND mem.member_num=? ";

	private static String memDomNameQuery =
			" SELECT "
					+ " secq.security_question_type as security_question_type, secq.security_question_active as security_question_active, "
					+ " mem.security_question_id_1, secq1.security_question as security_question_1, mem.security_answer_1, "
					+ " secq1.security_question_type as security_question_1_type, secq1.security_question_active as security_question_1_active, "
					+ " mem.security_question_id_2, secq2.security_question as security_question_2, mem.security_answer_2, "
					+ " secq2.security_question_type as security_question_2_type, secq2.security_question_active as security_question_2_active, "
					+ " mem.previous_contact_email, TO_CHAR(mem.contact_email_est_date,'"
					+ dateFormat
					+ "') as contact_email_est_date, "

					+ " mem.language,"
					+ " TO_CHAR(mem.tos_reject_date, '" + dateFormat + "') AS tos_reject_date, mem.num_tos_rejects, "
					+ " mem.alert_ind, "
					+ " mem.agg_email_status, mem.last_member_status as last_member_status_code, stat3.status_name as last_member_status_name, mem.credit_checked_ind, mem.yreg_complete_ind, TO_CHAR(mem.lockout_timestamp, '"
					+ dateFormat
					+ "') as lockout_timestamp, mem.firstname, mem.lastname, mem.nickname, mem.last_four_ssn, mem.security_question_id, "
					+ " mem.gender, mem.proofing_zip, secq.security_question, "
					+ " mem.contact_email, mem.contact_email_valid, mem.password_dirty, mem.sha1_password, "
					+ " mem.des3_password,mem.failed_auth_count, "
					+ " TO_CHAR(mem.delete_request_date, '"
					+ dateFormat
					+ "') AS delete_request_date, mem.token, mem.remarks, mem.ban, mem.member_num, mem.member_name, mem.group_num, "
					+ " dom.domain_name, mem.domain_id, mem.enc_password, "
					+ " mem.md5_password, mem.parent_child_ind, mem.member_state, "
					+ " mem.agg_access_status, mem.agg_service_status, mem.mailhost, "
					+ " mem.fullname, mem.account_type,mem.optout_ind, mem.migration_ind, "
					+ " TO_CHAR(mem.migration_date, '"
					+ dateFormat
					+ "') AS migration_date, "
					+ " TO_CHAR(mem.create_date, '"
					+ dateFormat
					+ "') AS mem_create_date, "
					+ " TO_CHAR(mem.last_modified, '"
					+ dateFormat
					+ "') AS mem_last_modified, "
					+ " mem.last_modified_by AS last_modified_by, "
					+ " memGroup.parent_name, parentDom.domain_name as parent_domain, memGroup.premium_800_ind, memGroup.bulk_billing_ind,  memGroup.access_code, mem.sor_id, sor.sor_name, mem.access_id, "
					+ " acc.access_name, serv.service_name, serv.service_type, "
					+ " serv.subaccount_eligible, serv.email_eligible, serv.entity_type, "
					+ " memService.service_id, memService.member_status AS member_status_code, "
					+ " memService.group_status AS group_status_code, stat1.status_name AS group_status_name, "
					+ " stat2.status_name AS member_status_name, "
					+ " TO_CHAR(memService.terminate_date, '"
					+ dateFormat
					+ "') AS terminate_date, "
					+ " TO_CHAR(memService.create_date, '"
					+ dateFormat
					+ "') AS create_date, TO_CHAR(memService.last_modified, '"
					+ dateFormat
					+ "') AS last_modified, memService.last_modified_by AS last_modified_by, "
					+ "memService.instance_id, "
					+ " TO_CHAR(memService.pending_disconnect_date, '"
					+ dateFormat
					+ "') AS pending_disconnect_date, portal.last_modified_by AS portal_last_modified_by, TO_CHAR(portal.create_date, '"
					+ dateFormat
					+ "') AS portal_create_date, portal.portal_provider as portal_provider, memService.sor_id as service_sor_id, sor1.sor_name as service_sor_name, " //added for NAP by sk7243
					+ " iptv.portal_svc_provider as portal_svc_provider, "
					+ " memService.sor_invariant_id, memService.atlas_last_timestamp, memService.nickname as service_nickname, " //for Feb 2010 LSR12
					+ " memService.default_account, TO_CHAR(memService.date_default_est, '"
					+ dateFormat
					+ "') AS date_default_est, memService.cpni_impacted, memService.suspend_reason_code, mem.dsl_net_password, mem.dsl_net_pw_encr_type, "
					+ " servassoc.sor_id1, "
					+ " nvl(servassoc.sor_invariant_id1, '--NULL--') as sor_invariant_id1, sor2.sor_name as sor_name1,"
					+ " servassoc.sor_id2, "
					+ " nvl(servassoc.sor_invariant_id2, '--NULL--') as sor_invariant_id2, sor3.sor_name as sor_name2,"
					+ " servassoc.assigned_by as asso_assigned_by, servassoc.last_modified_by as asso_last_modified_by, "
					+ " TO_CHAR(servassoc.create_date, '"
					+ dateFormat
					+ "') AS asso_create_date, "
					+ " TO_CHAR(servassoc.last_modified, '"
					+ dateFormat
					+ "') AS asso_last_modified, "
					+ " TO_CHAR(portal.last_modified, '"
					+ dateFormat
					+ "') AS portal_provider_last_modified, dsl.tdsl_ind, dsl.wtn, dsl.dslam_type, TO_CHAR(mem.csr_initiated_lockout_ts, '"
					+ dateFormat
					+ "') AS csr_initiated_lockout_ts, mem.browser_language, mem.contact_email_status, mem.ssha_password, "
					+ " mem.slid_member_num, mem.autogenerated_ind, mem.activated_ind, portal.plite_ind, "
					+ " memService.parent_sor_id, memService.parent_sor_invariant_id, memService.uverse_service_ind, serv.major_service_id, " //June 2011
					+ " mem.birthdate_venc, mem.passcode_venc, mem.security_answer_venc, TO_CHAR(mem.last_verified, '"
					+ dateFormat
					+ "') AS last_verified, mem.created_by, TO_CHAR(mem.main_ctn_opt_out, '"
					+ dateFormat
					+ "') AS main_ctn_opt_out, dsl.dns_err_optout_ind, memService.unification_pending, TO_CHAR(mem.onl_qa_est_date, '"
					+ dateFormat
					+ "') AS onl_qa_est_date, "
					+ " mem.fn_linked_userid, "
					+ " mem.fn_linked_status, "
					// 2103 -  SSHA-256 encryption changes
					+ " memaux.password_venc AS gen_password_venc,"
					+ " memaux.password_type  AS gen_password_type,"

					+ " memaux.enc_password_venc, memaux.md5_password_venc, memaux.sha1_password_venc, " //1612:SID 49298
					+ " memaux.des3_password_venc, memaux.ssha_password_venc, memaux.security_answer_1_venc, " //1612:SID 49298
					+ " memaux.security_answer_2_venc, TO_CHAR(memaux.recent_fraud_pw_date, '"+ dateFormat +"') AS recent_fraud_pw_date " //1612:SID 49298
					+ " FROM "
					+ " MEMBER mem,MEMBERGROUP memGroup,MEMBERSERVICE memService,DOMAIN dom, DOMAIN parentDom, SecurityQuestion secq, SYSTEMOFRECORD sor,NETWORKACCESS acc,SERVICE serv,STATUS stat1,STATUS stat2,STATUS stat3, "
					+ " PORTALUSER portal, SYSTEMOFRECORD sor1, SecurityQuestion secq1, SecurityQuestion secq2, IPTVUSER iptv, "
					+ " serviceassociation servassoc, SYSTEMOFRECORD sor2, SYSTEMOFRECORD sor3, "
					+ " MEMBERAUX memaux, " //1612:SID 49298
					+ " DSLUSER dsl "
					+ " WHERE "
					+ " mem.sor_id=sor.sor_id AND mem.access_id=acc.access_id "
					+ " AND mem.domain_id=dom.domain_id AND memGroup.domain_id=parentDom.domain_id AND mem.group_num=memGroup.group_num "
					+ " AND mem.security_question_id =secq.security_question_id (+) "
					+ " AND mem.security_question_id_1 =secq1.security_question_id (+) "
					+ " AND mem.security_question_id_2 =secq2.security_question_id (+) "
					+ " AND memService.sor_id =sor1.sor_id (+) "
					+ " AND memService.member_num = portal.member_num(+) AND memService.service_id = portal.service_id(+) AND mem.member_num=memService.member_num (+) AND memService.service_id=serv.service_id (+) "
					+ " AND memService.member_status=stat2.status_code (+) AND memService.group_status = stat1.status_code (+) AND mem.last_member_status = stat3.status_code (+) "
					+ " AND memService.member_num = iptv.member_num(+) AND memService.service_id = iptv.service_id(+) "
					+ " AND servassoc.sor_id1(+) = memService.sor_id AND servassoc.sor_id1 = sor2.sor_id (+) AND servassoc.sor_id2 = sor3.sor_id (+) " //Added for LSR10 AAB
					+ " AND servassoc.sor_invariant_id1(+) = memService.sor_invariant_id "
					+ " AND memService.member_num = dsl.member_num (+) "
					+ " AND mem.member_num = memaux.member_num (+) " //1612:SID 49298
					+ " AND mem.member_name=? AND dom.domain_name=? ";
	//+ " AND mem.parent_child_ind in ('P','C') AND mem.member_name=? AND dom.domain_name=? ";

	private static String banQuery =
			" SELECT "
					+ " secq.security_question_type as security_question_type, secq.security_question_active as security_question_active, "
					+ " mem.security_question_id_1, secq1.security_question as security_question_1, mem.security_answer_1, "
					+ " secq1.security_question_type as security_question_1_type, secq1.security_question_active as security_question_1_active, "
					+ " mem.security_question_id_2, secq2.security_question as security_question_2, mem.security_answer_2, "
					+ " secq2.security_question_type as security_question_2_type, secq2.security_question_active as security_question_2_active, "
					+ " mem.previous_contact_email, TO_CHAR(mem.contact_email_est_date,'"
					+ dateFormat
					+ "') as contact_email_est_date, "

					+ " mem.language,"
					+ " TO_CHAR(mem.tos_reject_date, '" + dateFormat + "') AS tos_reject_date, mem.num_tos_rejects, "
					+ " mem.alert_ind, "
					+ " mem.agg_email_status, mem.last_member_status as last_member_status_code, stat3.status_name as last_member_status_name, mem.credit_checked_ind, mem.yreg_complete_ind, TO_CHAR(mem.lockout_timestamp, '"//LSR4 by Swaroop
					+ dateFormat
					+ "') as lockout_timestamp, mem.firstname, mem.lastname, mem.nickname, mem.last_four_ssn, mem.security_question_id, "
					+ " mem.gender, mem.proofing_zip, secq.security_question, "
					+ " mem.contact_email, mem.contact_email_valid, mem.password_dirty, mem.sha1_password, "
					+ " mem.des3_password, mem.failed_auth_count, "
					+ " TO_CHAR(mem.delete_request_date, '"
					+ dateFormat
					+ "') AS delete_request_date, mem.token, mem.remarks, mem.ban, mem.member_num, mem.member_name, mem.group_num, "
					+ " dom.domain_name, mem.domain_id, mem.enc_password, "
					+ " mem.md5_password, mem.parent_child_ind, mem.member_state, "
					+ " mem.agg_access_status, mem.agg_service_status, mem.mailhost, "
					+ " mem.fullname, mem.account_type,mem.optout_ind, mem.migration_ind, "
					+ " TO_CHAR(mem.migration_date, '"
					+ dateFormat
					+ "') AS migration_date, "
					+ " TO_CHAR(mem.create_date, '"
					+ dateFormat
					+ "') AS mem_create_date, "
					+ " TO_CHAR(mem.last_modified, '"
					+ dateFormat
					+ "') AS mem_last_modified, "
					+ " mem.last_modified_by AS last_modified_by, "
					+ " memGroup.parent_name, parentDom.domain_name as parent_domain, memGroup.premium_800_ind, memGroup.bulk_billing_ind,  memGroup.access_code, mem.sor_id, sor.sor_name, mem.access_id, "
					+ " acc.access_name, serv.service_name, serv.service_type, "
					+ " serv.subaccount_eligible, serv.email_eligible, serv.entity_type, "
					+ " memService.service_id, memService.member_status AS member_status_code, "
					+ " memService.group_status AS group_status_code, stat1.status_name AS group_status_name, "
					+ " stat2.status_name AS member_status_name, "
					+ " TO_CHAR(memService.terminate_date, '"
					+ dateFormat
					+ "') AS terminate_date, "
					+ " TO_CHAR(memService.create_date, '"
					+ dateFormat
					+ "') AS create_date, TO_CHAR(memService.last_modified, '"
					+ dateFormat
					+ "') AS last_modified, memService.last_modified_by AS last_modified_by, "
					+ "memService.instance_id, "
					+ " TO_CHAR(memService.pending_disconnect_date, '"
					+ dateFormat
					+ "') AS pending_disconnect_date, portal.last_modified_by AS portal_last_modified_by, TO_CHAR(portal.create_date, '"
					+ dateFormat
					+ "') AS portal_create_date, portal.portal_provider as portal_provider, memService.sor_id as service_sor_id, sor1.sor_name as service_sor_name, " //added for NAP by sk7243
					+ " iptv.portal_svc_provider as portal_svc_provider, "
					+ " memService.sor_invariant_id, memService.atlas_last_timestamp, memService.nickname as service_nickname, " //for Feb 2010 LSR12
					+ " memService.default_account, TO_CHAR(memService.date_default_est, '"
					+ dateFormat
					+ "') AS date_default_est, memService.cpni_impacted, memService.suspend_reason_code, mem.dsl_net_password, mem.dsl_net_pw_encr_type, "
					+ " servassoc.sor_id1, "
					+ " nvl(servassoc.sor_invariant_id1, '--NULL--') as sor_invariant_id1, sor2.sor_name as sor_name1, "
					+ " servassoc.sor_id2, "
					+ " nvl(servassoc.sor_invariant_id2, '--NULL--') as sor_invariant_id2, sor3.sor_name as sor_name2, "
					+ " servassoc.assigned_by as asso_assigned_by, servassoc.last_modified_by as asso_last_modified_by, "
					+ " TO_CHAR(servassoc.create_date, '"
					+ dateFormat
					+ "') AS asso_create_date, "
					+ " TO_CHAR(servassoc.last_modified, '"
					+ dateFormat
					+ "') AS asso_last_modified, "
					+ " TO_CHAR(portal.last_modified, '"
					+ dateFormat
					+ "') AS portal_provider_last_modified, dsl.tdsl_ind, dsl.wtn, dsl.dslam_type, TO_CHAR(mem.csr_initiated_lockout_ts, '"
					+ dateFormat
					+ "') AS csr_initiated_lockout_ts, mem.browser_language, mem.contact_email_status, mem.ssha_password, "
					+ " mem.slid_member_num, mem.autogenerated_ind, mem.activated_ind, portal.plite_ind, "
					+ " memService.parent_sor_id, memService.parent_sor_invariant_id, memService.uverse_service_ind, serv.major_service_id, " //June 2011
					+ " mem.birthdate_venc, mem.passcode_venc, mem.security_answer_venc, TO_CHAR(mem.last_verified, '"
					+ dateFormat
					+ "') AS last_verified, mem.created_by, TO_CHAR(mem.main_ctn_opt_out, '"
					+ dateFormat
					+ "') AS main_ctn_opt_out, dsl.dns_err_optout_ind, memService.unification_pending, TO_CHAR(mem.onl_qa_est_date, '"
					+ dateFormat
					+ "') AS onl_qa_est_date, "
					// 2103 -  SSHA-256 encryption changes
					+ " memaux.password_venc AS gen_password_venc,"
					+ " memaux.password_type  AS gen_password_type,"

					+ " memaux.enc_password_venc, memaux.md5_password_venc, memaux.sha1_password_venc, " //1612:SID 49298
					+ " memaux.des3_password_venc, memaux.ssha_password_venc, memaux.security_answer_1_venc, " //1612:SID 49298
					+ " memaux.security_answer_2_venc, TO_CHAR(memaux.recent_fraud_pw_date, '"+ dateFormat +"') AS recent_fraud_pw_date " //1612:SID 49298
					+ " FROM "
					+ " MEMBER mem,MEMBERGROUP memGroup,MEMBERSERVICE memService,DOMAIN dom, DOMAIN parentDom, SecurityQuestion secq, SYSTEMOFRECORD sor,NETWORKACCESS acc,SERVICE serv,STATUS stat1,STATUS stat2,STATUS stat3, "
					+ " PORTALUSER portal, SYSTEMOFRECORD sor1, SecurityQuestion secq1, SecurityQuestion secq2, IPTVUSER iptv, "
					+ " serviceassociation servassoc, SYSTEMOFRECORD sor2, SYSTEMOFRECORD sor3, "
					+ " MEMBERAUX memaux, " //1612:SID 49298
					+ " DSLUSER dsl "
					+ " WHERE "
					+ " mem.sor_id=sor.sor_id AND mem.access_id=acc.access_id "
					+ " AND mem.domain_id=dom.domain_id AND memGroup.domain_id=parentDom.domain_id AND mem.group_num=memGroup.group_num "
					+ " AND mem.security_question_id =secq.security_question_id (+) "
					+ " AND mem.security_question_id_1 =secq1.security_question_id (+) "
					+ " AND mem.security_question_id_2 =secq2.security_question_id (+) "
					+ " AND memService.sor_id =sor1.sor_id (+) "
					+ " AND memService.member_num = portal.member_num(+) AND memService.service_id = portal.service_id(+) AND mem.member_num=memService.member_num (+) AND memService.service_id=serv.service_id  (+) "
					+ " AND memService.member_status=stat2.status_code (+) AND memService.group_status = stat1.status_code (+) AND mem.last_member_status = stat3.status_code(+) "
					+ " AND memService.member_num = iptv.member_num(+) AND memService.service_id = iptv.service_id(+) "
					+ " AND servassoc.sor_id1(+) = memService.sor_id AND servassoc.sor_id1 = sor2.sor_id (+) AND servassoc.sor_id2 = sor3.sor_id (+) "
					+ " AND servassoc.sor_invariant_id1(+) = memService.sor_invariant_id "
					+ " AND memService.member_num = dsl.member_num (+) " //added for ISS Ph2
					+ " AND mem.member_num = memaux.member_num (+) " //1612:SID 49298
					+ " AND mem.parent_child_ind='P' AND mem.ban=? ";

	private static String groupNumQuery =
			" SELECT "
					+ " secq.security_question_type as security_question_type, secq.security_question_active as security_question_active, "
					+ " mem.security_question_id_1, secq1.security_question as security_question_1, mem.security_answer_1, "
					+ " secq1.security_question_type as security_question_1_type, secq1.security_question_active as security_question_1_active, "
					+ " mem.security_question_id_2, secq2.security_question as security_question_2, mem.security_answer_2, "
					+ " secq2.security_question_type as security_question_2_type, secq2.security_question_active as security_question_2_active, "
					+ " mem.previous_contact_email, TO_CHAR(mem.contact_email_est_date,'"
					+ dateFormat
					+ "') as contact_email_est_date, "

					+ " mem.language,"
					+ " TO_CHAR(mem.tos_reject_date, '" + dateFormat + "') AS tos_reject_date, mem.num_tos_rejects, "
					+ " mem.alert_ind, "
					+ " mem.agg_email_status, mem.last_member_status as last_member_status_code, stat3.status_name as last_member_status_name, mem.credit_checked_ind, mem.yreg_complete_ind, TO_CHAR(mem.lockout_timestamp, '"//LSR4 by Swaroop
					+ dateFormat
					+ "') as lockout_timestamp, mem.firstname, mem.lastname, mem.nickname, mem.last_four_ssn, mem.security_question_id, "
					+ " mem.gender, mem.proofing_zip, secq.security_question, "
					+ " mem.contact_email, mem.contact_email_valid, mem.password_dirty, mem.sha1_password, "
					+ " mem.des3_password, mem.failed_auth_count, "
					+ " TO_CHAR(mem.delete_request_date, '"
					+ dateFormat
					+ "') AS delete_request_date, mem.token, mem.remarks, mem.ban, mem.member_num, mem.member_name, mem.group_num, "
					+ " dom.domain_name, mem.domain_id, mem.enc_password, "
					+ " mem.md5_password, mem.parent_child_ind, mem.member_state, "
					+ " mem.agg_access_status, mem.agg_service_status, mem.mailhost, "
					+ " mem.fullname, mem.account_type,mem.optout_ind, mem.migration_ind, "
					+ " TO_CHAR(mem.migration_date, '"
					+ dateFormat
					+ "') AS migration_date, "
					+ " TO_CHAR(mem.create_date, '"
					+ dateFormat
					+ "') AS mem_create_date, "
					+ " TO_CHAR(mem.last_modified, '"
					+ dateFormat
					+ "') AS mem_last_modified, "
					+ " mem.last_modified_by AS last_modified_by, "
					+ " memGroup.parent_name, parentDom.domain_name as parent_domain, memGroup.premium_800_ind, memGroup.bulk_billing_ind,  memGroup.access_code, mem.sor_id, sor.sor_name, mem.access_id, "
					+ " acc.access_name, serv.service_name, serv.service_type, "
					+ " serv.subaccount_eligible, serv.email_eligible, serv.entity_type, "
					+ " memService.service_id, memService.member_status AS member_status_code, "
					+ " memService.group_status AS group_status_code, stat1.status_name AS group_status_name, "
					+ " stat2.status_name AS member_status_name, "
					+ " TO_CHAR(memService.terminate_date, '"
					+ dateFormat
					+ "') AS terminate_date, "
					+ " TO_CHAR(memService.create_date, '"
					+ dateFormat
					+ "') AS create_date, TO_CHAR(memService.last_modified, '"
					+ dateFormat
					+ "') AS last_modified, memService.last_modified_by AS last_modified_by, "
					+ "memService.instance_id, "
					+ " TO_CHAR(memService.pending_disconnect_date, '"
					+ dateFormat
					+ "') AS pending_disconnect_date, portal.last_modified_by AS portal_last_modified_by, TO_CHAR(portal.create_date, '"
					+ dateFormat
					+ "') AS portal_create_date, portal.portal_provider as portal_provider, memService.sor_id as service_sor_id, sor1.sor_name as service_sor_name, " //added for NAP by sk7243
					+ " iptv.portal_svc_provider as portal_svc_provider "
					+ ", memService.sor_invariant_id, memService.atlas_last_timestamp, memService.nickname as service_nickname, "
					+ " memService.default_account, TO_CHAR(memService.date_default_est, '"
					+ dateFormat
					+ "') AS date_default_est, memService.cpni_impacted, memService.suspend_reason_code, mem.dsl_net_password, mem.dsl_net_pw_encr_type, "
					+ " servassoc.sor_id1, "
					+ " nvl(servassoc.sor_invariant_id1, '--NULL--') as sor_invariant_id1, sor2.sor_name as sor_name1,"
					+ " servassoc.sor_id2, "
					+ " nvl(servassoc.sor_invariant_id2, '--NULL--') as sor_invariant_id2, sor3.sor_name as sor_name2,"
					+ " servassoc.assigned_by as asso_assigned_by, servassoc.last_modified_by as asso_last_modified_by, "
					+ " TO_CHAR(servassoc.create_date, '"
					+ dateFormat
					+ "') AS asso_create_date, "
					+ " TO_CHAR(servassoc.last_modified, '"
					+ dateFormat
					+ "') AS asso_last_modified, "

					+ " TO_CHAR(portal.last_modified, '"
					+ dateFormat
					+ "') AS portal_provider_last_modified, dsl.tdsl_ind, dsl.wtn, dsl.dslam_type, TO_CHAR(mem.csr_initiated_lockout_ts, '"
					+ dateFormat
					+ "') AS csr_initiated_lockout_ts, mem.browser_language, mem.contact_email_status, mem.ssha_password, "
					+ " mem.slid_member_num, mem.autogenerated_ind, mem.activated_ind, portal.plite_ind, "
					+ " memService.parent_sor_id, memService.parent_sor_invariant_id, memService.uverse_service_ind, serv.major_service_id, " //June 2011
					+ " mem.birthdate_venc, mem.passcode_venc, mem.security_answer_venc, TO_CHAR(mem.last_verified, '"
					+ dateFormat
					+ "') AS last_verified, mem.created_by, TO_CHAR(mem.main_ctn_opt_out, '"
					+ dateFormat
					+ "') AS main_ctn_opt_out, dsl.dns_err_optout_ind, memService.unification_pending, TO_CHAR(mem.onl_qa_est_date, '"
					+ dateFormat
					+ "') AS onl_qa_est_date, "
					// 2103 -  SSHA-256 encryption changes
					+ " memaux.password_venc AS gen_password_venc,"
					+ " memaux.password_type  AS gen_password_type,"

					+ " memaux.enc_password_venc, memaux.md5_password_venc, memaux.sha1_password_venc, " //1612:SID 49298
					+ " memaux.des3_password_venc, memaux.ssha_password_venc, memaux.security_answer_1_venc, " //1612:SID 49298
					+ " memaux.security_answer_2_venc, TO_CHAR(memaux.recent_fraud_pw_date, '"+ dateFormat +"') AS recent_fraud_pw_date " //1612:SID 49298
					+ " FROM "
					+ " MEMBER mem,MEMBERGROUP memGroup,MEMBERSERVICE memService,DOMAIN dom, DOMAIN parentDom, SecurityQuestion secq, SYSTEMOFRECORD sor,NETWORKACCESS acc,SERVICE serv,STATUS stat1,STATUS stat2,STATUS stat3, "
					+ " PORTALUSER portal, SYSTEMOFRECORD sor1, SecurityQuestion secq1, SecurityQuestion secq2, IPTVUSER iptv, "
					+ " serviceassociation servassoc, SYSTEMOFRECORD sor2, SYSTEMOFRECORD sor3, "
					+ " MEMBERAUX memaux, " //1612:SID 49298
					+ " DSLUSER dsl " //added by vs3652 for ISS Ph2
					+ " WHERE "
					+ " mem.sor_id=sor.sor_id AND mem.access_id=acc.access_id "
					+ " AND mem.domain_id=dom.domain_id AND memGroup.domain_id=parentDom.domain_id AND mem.group_num=memGroup.group_num "
					+ " AND mem.security_question_id =secq.security_question_id (+) "
					+ " AND mem.security_question_id_1 =secq1.security_question_id (+) "
					+ " AND mem.security_question_id_2 =secq2.security_question_id (+) "
					+ " AND memService.sor_id =sor1.sor_id (+) "
					+ " AND memService.member_num = portal.member_num(+) AND memService.service_id = portal.service_id(+) AND mem.member_num=memService.member_num (+) AND memService.service_id=serv.service_id  (+) "
					+ " AND memService.member_status=stat2.status_code (+) AND memService.group_status = stat1.status_code (+) AND mem.last_member_status = stat3.status_code(+) "
					+ " AND memService.member_num = iptv.member_num(+) AND memService.service_id = iptv.service_id(+) "
					+ " AND servassoc.sor_id1(+) = memService.sor_id AND servassoc.sor_id1 = sor2.sor_id (+) AND servassoc.sor_id2 = sor3.sor_id (+) "
					+ " AND servassoc.sor_invariant_id1(+) = memService.sor_invariant_id "
					+ " AND memService.member_num = dsl.member_num (+) " //added for ISS Ph2
					+ " AND mem.member_num = memaux.member_num (+) "	//1612:SID 49298
					+ " AND mem.parent_child_ind='P' AND mem.group_num=? ";


	private static String queryMemberLockout =
			"SELECT memloc.member_num, memloc.lockout_id, lo.lockout_name, memloc.set_number,"
					+ " memloc.failed_auth_count, TO_CHAR(memloc.lockout_expiration, '"
					+ dateFormat
					+ "') AS lockout_expiration, TO_CHAR(memloc.last_failed_auth, '"
					+ dateFormat
					+ "') AS last_failed_auth, TO_CHAR(memloc.create_date, '"
					+ dateFormat
					+ "') AS create_date, TO_CHAR(memloc.last_modified, '"
					+ dateFormat
					+ "') AS last_modified, memloc.last_modified_by "
					+ " FROM memberlockout memloc, lockout lo "
					+ " WHERE memloc.lockout_id = lo.lockout_id (+) "
					+ " AND memloc.member_num = ?";

	//Query DSLUSER table
	private static String queryDSLUserSql =
			" SELECT dsl.circuit_id, dsl.virtual_path, dsl.virtual_circuit, dsl.incoming_burst, dsl.incoming_limit,"
					+ " dsl.outgoing_burst, dsl.outgoing_limit, dsl.protocol_type, dsl.ip_address, dsl.ip_subnet, dsl.wtn, dsl.ip_netblock,"
					+ " dsl.dslam_type, dsl.tdsl_ind, dsl.ipv6rd_enabled, dsl.ipv6rd_manually_disabled, dsl.dns_err_optout_ind, "
					+ " TO_CHAR(dsl.create_date, '"
					+ dateFormat
					+ "') AS dsl_user_create_date, TO_CHAR(dsl.last_modified, '"
					+ dateFormat
					+ "') AS dsl_user_last_modified, dsl.last_modified_by AS dsl_user_last_modified_by,"
					+ " dslNP.network_profile_name AS network_profile_name, dsl.network_profile_id as network_profile_id"
					+ " FROM  DSLUser dsl, NETWORKPROFILE dslNP"
					+ " WHERE"
					+ " dsl.network_profile_id = dslNP.network_profile_id (+)"
					+ " AND dsl.member_num = ? ";

	//Query DIALUSER table
	private static String queryDIALUserSql =
			" SELECT dial.network_profile_id, dialNP.network_profile_name AS network_profile_name, "
					+ " TO_CHAR(dial.create_date, '"
					+ dateFormat
					+ "') AS dial_user_create_date, TO_CHAR(dial.last_modified, '"
					+ dateFormat
					+ "') AS dial_user_last_modified, dial.last_modified_by AS dial_user_last_modified_by "
					+ " FROM DIALUSER dial, NETWORKPROFILE dialNP "
					+ " WHERE dial.network_profile_id = dialNP.network_profile_id (+) "
					+ " AND dial.service_id = '1' AND dial.member_num = ? ";

	//Query ISDNUSER table
	private static String queryISDNUserSql =
			" SELECT isdn.ip_address, isdn.ip_subnet, isdn.ip_netblock, "
					+ " TO_CHAR(isdn.create_date, '"
					+ dateFormat
					+ "') AS isdn_user_create_date, TO_CHAR(isdn.last_modified, '"
					+ dateFormat
					+ "') AS isdn_user_last_modified, isdn.last_modified_by AS isdn_user_last_modified_by, "
					+ " isdnNP.network_profile_name AS network_profile_name, "
					+ " isdn.network_profile_id AS network_profile_id "
					+ " FROM  ISDNUSER isdn, NETWORKPROFILE isdnNP "
					+ " WHERE isdn.network_profile_id = isdnNP.network_profile_id (+) "
					+ " AND isdn.service_id in (3,4) AND isdn.member_num = ? ";

	//Query WIFIUSER table
	private static String queryWIFIUserSql =
			"SELECT wifi.wifi_service_type, wifi.roaming_block_ind, TO_CHAR(wifi.create_date, '"
					+ dateFormat
					+ "') AS wifi_user_create_date, TO_CHAR(wifi.last_modified, '"
					+ dateFormat
					+ "') AS wifi_user_last_modified, wifi.last_modified_by AS wifi_user_last_modified_by "
					+ ""
					+ "FROM wifiuser wifi "
					+ "WHERE "
					+ "wifi.service_id = '6' AND wifi.member_num = ? ";

	/**
	 * This method retrieves the services associated with a member from the database.
	 * It takes a HashMap as input and returns a HashMap as output.
	 * The input HashMap contains key-value pairs for various member attributes like member number, ban, group number etc.
	 * The method first checks if the jdbcTemplate is null. If it is, it returns an error status.
	 * Then it retrieves the member attributes from the input HashMap.
	 * If the member attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param inputParamHs A HashMap containing the details of the member's information to be retrieved.
	 * @return A HashMap containing the status of the operation and the retrieved member's services.
	 */
	public HashMap getMemberServices(HashMap inputParamHs) {
		String sMethodName = ".getMemberServices.";
		logger.info("{}{}DBTOOLS000 : InpParam : {}", CLASS_NAME, sMethodName, HtmlUtils.htmlEscape(String.valueOf(inputParamHs)));


		boolean memberHashMapFlag = false;
		boolean servicesHashMapFlag = false;
		boolean bRolesAlreadyQueried = false;
		boolean bMemberSvcAttrQueried = false; // 1806

		String serviceName = "";
		String memberNameValue = null;
		String domainNameValue = null;
		String memberNumValue = null;
		String banValue = null;
		String groupNumValue = null;
		String sQueryOnlySlidsFlag = null;
		String sQueryParentsAndSlidsFlag = null;

		sAggSubEligibleServiceStatus = null;
		bSubEligibleServiceStatusRequired = false;
		bSubEligibleSet = false;

		String sMemberNum = "";
		String dbBan = null;
		String dbSorName = null;
		long memNumVal = 0;
		String sSlidMemberNum = null;
		String sDbMemberName = null;
		String sDbMemberDomain = null;
		String servicesKey = MPSDefs.SERVICES;

		String errorCode = "";
		String sAppStatusCode = "";
		String sAppInfo = null;
		String dynSql = "";

		List<Object> objectList = new ArrayList<Object>();
		List alQueryResponse = null;

		HashMap<String, Object> memServices = null;
		HashMap<String, Object> servicesHash = null;
		HashMap<String, Object> userServiceHash = null;
		HashMap<String, Object> hmMemberServiceRoles = null;
		HashMap<String, Object> hmMemberServiceAttributes = null; // 1806
		ArrayList alQueryRolesSvcList = null;
		ArrayList alSvcNotSorInvariantIds = new ArrayList();

		if (jdbcTemplate == null) {
			memServices = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "jdbcTemplate is null.");
			logger.error("response : {}", memServices);
			return memServices;
		}

		// Check if the HashMap contains the desired keys and the values are not null.
		if (inputParamHs == null) {
			memServices = StatusMsg.makeSQLStatus(MPSDefs.ERR_HASHMAP_EMP, MPSDefs.ERR_HASHMAP_EMP_MSG, MPSDefs.SQL_ERR,
					MPSDefs.SQL_ERR_MSG, MPSDefs.NO_ROW_UPDATED);
			logger.info("{}{}DBTOOLS4 : Empty HashMap passed", CLASS_NAME, sMethodName);

			return memServices;
		}

		try {

			banValue = (String) inputParamHs.get(MPSDefs.DB_BAN);
			memberNumValue = (String) inputParamHs.get(MPSDefs.DB_MEMBER_NUM);
			memberNameValue = (String) inputParamHs.get(MPSDefs.DB_MEMBER_NAME);
			domainNameValue = (String) inputParamHs.get(MPSDefs.DB_DOMAIN_NAME);
			groupNumValue = (String) inputParamHs.get(MPSDefs.DB_GROUP_NUM);
			sQueryOnlySlidsFlag = (String) inputParamHs.get(MPSDefs.QUERY_ONLY_SLIDS_FLAG);
			sQueryParentsAndSlidsFlag = (String) inputParamHs.get(MPSDefs.QUERY_PARENTS_AND_SLIDS_FLAG);
			String sQueryFraudLock = (String) inputParamHs.get(MPSDefs.QUERY_FRAUD_LOCK_FLAG); // 1510
			String queryDIAL = (String) inputParamHs.get("queryDIAL");
			String queryDSL = (String) inputParamHs.get("queryDSL");
			String queryWIFI = (String) inputParamHs.get("queryWIFI");
			String queryISDN = (String) inputParamHs.get("queryISDN");

			// if ban exists, takes precedence. Next member_num takes precedence.
			if ((banValue != null) && ((banValue = banValue.trim()).length() > 0)) {

				logger.info("{}{}DBTOOLS5 : Ban exist in input, executing banQuery with ban = {}", CLASS_NAME, sMethodName, StringUtils.normalizeSpace(banValue));

				// Set ban value
				objectList.add(banValue);
				alQueryResponse = jdbcTemplate.queryForList(new String(banQuery),
						objectList.toArray(new Object[objectList.size()]));

			} else if (memberNumValue != null && memberNumValue.trim().length() > 0) {
				if (sQueryOnlySlidsFlag != null && sQueryOnlySlidsFlag.trim().equals(MPSDefs.YES))
					dynSql = " AND mem.parent_child_ind='S' ";
				else if (sQueryParentsAndSlidsFlag != null && sQueryParentsAndSlidsFlag.trim().equals(MPSDefs.YES))
					dynSql = " AND mem.parent_child_ind in ('P','S') ";
				else
					dynSql = " AND mem.parent_child_ind in ('P','C','S') ";

				logger.debug("{}{}DBTOOLS6 : member_num exist in input, executing memNumQuery appending with dynSql = {}", CLASS_NAME, sMethodName, dynSql);

				objectList.add(memberNumValue);
				alQueryResponse = jdbcTemplate.queryForList(new String(memNumQuery + dynSql),
						objectList.toArray(new Object[objectList.size()]));
			} else if (((memberNameValue != null) && ((memberNameValue = memberNameValue.trim()).length() > 0))
					&& ((domainNameValue != null) && ((domainNameValue = domainNameValue.trim()).length() > 0))) {
				if (domainNameValue != null && domainNameValue.equals(MPSDefs.SLID_DUM)) {
					dynSql = " AND mem.parent_child_ind='S' ";
				} else {
					dynSql = " AND mem.parent_child_ind in ('P','C') ";
				}

				logger.debug("{}{}DBTOOLS7 : member_name, domain_name exist in input, executing memDomNameQuery appending with dynSql = {}", CLASS_NAME, sMethodName, dynSql);

				objectList.add(memberNameValue);
				objectList.add(domainNameValue);
				alQueryResponse = jdbcTemplate.queryForList(new String(memDomNameQuery + dynSql),
						objectList.toArray(new Object[objectList.size()]));
			} else if ((groupNumValue != null) && ((groupNumValue = groupNumValue.trim()).length() > 0)) {

				logger.debug("{}{}DBTOOLS8 : GroupNum exist in input, executing groupNumQuery", CLASS_NAME, sMethodName);

				objectList.add(groupNumValue);
				alQueryResponse = jdbcTemplate.queryForList(new String(groupNumQuery),
						objectList.toArray(new Object[objectList.size()]));

			} else {

				memServices = StatusMsg.makeSQLStatus(MPSDefs.ERR_EMPTY, MPSDefs.ERR_EMPTY_MSG, MPSDefs.SQL_ERR,
						MPSDefs.SQL_ERR_MSG, MPSDefs.NO_ROW_UPDATED);
				logger.info("DBTOOLS9 : Required fields missing");

				return memServices;
			}

			// LS R5 for subaccount_eligible rp6341
			if (inputParamHs.containsKey(MPSDefs.AGG_SUB_ELIGIBLE_STATUS_REQUIRED)) {
				String sSubEligibleStatusRequired = (String) inputParamHs.get(MPSDefs.AGG_SUB_ELIGIBLE_STATUS_REQUIRED);
				if (sSubEligibleStatusRequired != null && sSubEligibleStatusRequired.equalsIgnoreCase(MPSDefs.YES)) {
					bSubEligibleServiceStatusRequired = true;
				}
			}

			long tTime = 0;
			Date dtStartDate = getDate();
			logger.debug("{}{}DBTOOLS10 : Query start time", CLASS_NAME, sMethodName);

			tTime = (System.currentTimeMillis() - dtStartDate.getTime());
			logger.info("{}{}QUERY999 : Total time taken to execute query = {} milliseconds", CLASS_NAME, sMethodName, tTime);

			String sSecReqVal = null;
			boolean bIsSercutyAllYes = false;
			int count = 0;

			for (int j = 0; j < alQueryResponse.size(); j++) {
				Map hmQueryResponse = (Map) alQueryResponse.get(j);

				Iterator itr = hmQueryResponse.keySet().iterator();
				while (itr.hasNext()) {
					String key = (String) itr.next();
					Object value = hmQueryResponse.get(key);

					String strValue = (value == null ? null : value.toString());

					hmQueryResponse.put(key, strValue);
				}

				// Iterate through the result set. Populate and return HashMap.
				if (!memberHashMapFlag) {
					memServices = CommonUtil.getHashMap();

					memServices.put(MPSDefs.APP_STATUS_CODE, MPSDefs.MPS_SUCCESS);
					memServices.put(MPSDefs.APP_STATUS_MSG, MPSDefs.MPS_ALL_OK);

					ProcessedQueryResponse processQueryResponse = processQueryResponse(hmQueryResponse, inputParamHs);
					memServices.putAll(processQueryResponse.getMemServices());
					bIsSercutyAllYes = processQueryResponse.isSecurityAllYes();
					sMemberNum = processQueryResponse.getMemberNum();
					sSlidMemberNum = processQueryResponse.getSlidMemberNum();
					sDbMemberDomain = processQueryResponse.getDbMemberDomain();

					if (!bIsSercutyAllYes) {

						if (inputParamHs.containsKey(MPSDefs.LAST_FOUR_SSN_REQ)) {
							sSecReqVal = (String) inputParamHs.get(MPSDefs.LAST_FOUR_SSN_REQ);
							if (sSecReqVal != null && sSecReqVal.equalsIgnoreCase("Y")) {
								memServices.put(MPSDefs.DB_LAST_FOUR_SSN,
										(String) hmQueryResponse.get(MPSDefs.DB_LAST_FOUR_SSN));
							}
						}
						if (inputParamHs.containsKey(MPSDefs.SECURITY_QUESTION_REQ)) {
							sSecReqVal = (String) inputParamHs.get(MPSDefs.SECURITY_QUESTION_REQ);
							if (sSecReqVal != null && sSecReqVal.equalsIgnoreCase("Y")) {
								memServices.put(MPSDefs.DB_SECURITY_QUESTION,
										(String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION));
								memServices.put("security_question_id",
										(String) hmQueryResponse.get("security_question_id"));
								memServices.put(MPSDefs.DB_SECURITY_QUESTION_TYPE,
										(String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_TYPE));
								memServices.put(MPSDefs.DB_SECURITY_QUESTION_ACTIVE,
										(String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_ACTIVE));
								memServices.put(MPSDefs.DB_SECURITY_QUESTION_ID_1,
										(String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_ID_1));
								memServices.put(MPSDefs.DB_SECURITY_QUESTION_1,
										(String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_1));
								memServices.put(MPSDefs.DB_SECURITY_QUESTION_1_TYPE,
										(String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_1_TYPE));
								memServices.put(MPSDefs.DB_SECURITY_QUESTION_1_ACTIVE,
										(String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_1_ACTIVE));
								memServices.put(MPSDefs.DB_SECURITY_QUESTION_ID_2,
										(String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_ID_2));
								memServices.put(MPSDefs.DB_SECURITY_QUESTION_2,
										(String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_2));
								memServices.put(MPSDefs.DB_SECURITY_QUESTION_2_TYPE,
										(String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_2_TYPE));
								memServices.put(MPSDefs.DB_SECURITY_QUESTION_2_ACTIVE,
										(String) hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_2_ACTIVE));
								// end of addition for FCC --rp6341
							}
						}
						if (inputParamHs.containsKey(MPSDefs.SECURITY_ANSWER_REQ)) {
							sSecReqVal = (String) inputParamHs.get(MPSDefs.SECURITY_ANSWER_REQ);
							if (sSecReqVal != null && sSecReqVal.equalsIgnoreCase("Y")) {

								memServices.put(MPSDefs.DB_SECURITY_ANSWER_1,
										(String) hmQueryResponse.get(MPSDefs.DB_SECURITY_ANSWER_1));
								memServices.put(MPSDefs.DB_SECURITY_ANSWER_2,
										(String) hmQueryResponse.get(MPSDefs.DB_SECURITY_ANSWER_2));
								memServices.put(MPSDefs.DB_SECURITY_ANSWER_1_VENC,
										(String) hmQueryResponse.get(MPSDefs.DB_SECURITY_ANSWER_1_VENC));
								memServices.put(MPSDefs.DB_SECURITY_ANSWER_2_VENC,
										(String) hmQueryResponse.get(MPSDefs.DB_SECURITY_ANSWER_2_VENC));
							}
						}
					}

					HashMap hmStatusTMS = oProcessVoltageHelper.voltageDecryptSPIFields(memServices);
					String stAppStatusCode = (String) hmStatusTMS.get(MPSDefs.APP_STATUS_CODE);
					if (!stAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
						return memServices = hmStatusTMS;
					}
					memberHashMapFlag = true;
				}

				serviceName = (String) hmQueryResponse.get(MPSDefs.DB_SERVICE_NAME);
				logger.debug("{}{}DBTOOLS11 : User has  {} service.", CLASS_NAME, sMethodName, serviceName);

				if (serviceName != null && serviceName.length() != 0) {

					if (servicesHash != null && servicesHash.containsKey(serviceName)) {
						userServiceHash = (HashMap) servicesHash.get(serviceName);
					} else {
						userServiceHash = CommonUtil.getHashMap();
					}

					// Added for LSR12 Feb 2010 by vs3652
					if (!bRolesAlreadyQueried && inputParamHs.containsKey(MPSDefs.QUERY_ROLES_INFO_FLAG)) {
						alQueryRolesSvcList = (ArrayList) inputParamHs.get(MPSDefs.QUERY_ROLES_INFO_FLAG);

						logger.info("{}{}DBTOOLS12 : alQueryRolesSvcList: {}", CLASS_NAME, sMethodName, StringUtils.normalizeSpace(alQueryRolesSvcList.toString()));

						HashMap hmDbInput = CommonUtil.getHashMap();
						hmDbInput.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);

						HashMap hmRolesResponse = oGetMemberRolesDBHelper.getMemberServiceRoles(hmDbInput);

						if (hmRolesResponse == null) {
							sAppInfo = "GetMemberRolesDBHelper.getMemberServiceRoles helper returned null.";
							logger.error("{}{}DBTOOLS13 : {}", CLASS_NAME, sMethodName, sAppInfo);
							hmRolesResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
							return hmRolesResponse;
						}

						sAppStatusCode = (String) hmRolesResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);

						if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
							if (sAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND)) {
								sAppInfo = "Member service roles not found for member_num - " + sMemberNum;
								logger.info("{}{}DBTOOLS14 : {}", CLASS_NAME, sMethodName, sAppInfo);
							} else {
								memServices.clear();
								memServices.putAll(hmRolesResponse);
								return memServices;
							}
						}

						bRolesAlreadyQueried = true;

						if (sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
							hmMemberServiceRoles = (HashMap) hmRolesResponse.get(MPSDefs.DB_MEMBER_SERVICE_ROLES);
					}

					// PID-310691e [2006][MPSYS-US3] - to return MEMBERSERVICEATTRIBUTE in response
					// for service, if present
					// changes by pm6756
					if (!bMemberSvcAttrQueried
							&& inputParamHs.containsKey(MPSDefs.QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG)) {

						String sQueryMemberServiceAttribute = (String) inputParamHs
								.get(MPSDefs.QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG);

						if (MPSDefs.YES.equals(sQueryMemberServiceAttribute)) {
							HashMap hmDbInput = CommonUtil.getHashMap();
							hmDbInput.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);

							HashMap hmMemSvcAttrResp = oGetMemSvcAttr.getServiceAttributesByMemberNum(hmDbInput);
							if (hmMemSvcAttrResp == null) {
								sAppInfo = "MemberServiceAttributeDBHelper.getServiceAttributes helper returned null.";
								logger.error("{}{}{} DBTOOLS13.1 : {}", CLASS_NAME, sMethodName, CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
								hmMemSvcAttrResp = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM,
										sAppInfo);
								memServices.clear();
								memServices.putAll(hmMemSvcAttrResp);
								return memServices;
							}
							sAppStatusCode = (String) hmMemSvcAttrResp.get(CErrorDefs.COMMON_APP_STATUS_CODE);
							if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
								if (sAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND)) {
									sAppInfo = "Member service attributes not found for member_num - " + sMemberNum;
									logger.info("{}{}DBTOOLS13.2 : {}", CLASS_NAME, sMethodName, sAppInfo);
								} else {
									memServices.clear();
									memServices.putAll(hmMemSvcAttrResp);
									return memServices;
								}
							}
							if (sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
								hmMemberServiceAttributes = (HashMap) hmMemSvcAttrResp
										.get(MPSDefs.DB_MEMBER_SERVICE_ATTRIBUTE);
						}
						bMemberSvcAttrQueried = true;
					} // END

					String instanceId = (String) hmQueryResponse.get(MPSDefs.DB_INSTANCE_ID);
					// LS services
					if (CommonUtil.getInstanceServices(logger).contains(serviceName)) {
						processLS(hmQueryResponse, hmMemberServiceRoles, alQueryRolesSvcList,
								hmMemberServiceAttributes, serviceName, instanceId, userServiceHash);
					} // end of if instanceId is not null and not "1"
					else {
						copyServiceData(userServiceHash, hmQueryResponse, hmMemberServiceRoles, alQueryRolesSvcList,
								hmMemberServiceAttributes);

						// calculate service_status for Non-LS services,
						// Ex: Dial, DSL, ISDN, ISDN2, SWH, WIFI, HES
						String serviceStatus = calculateStatus(
								(String) userServiceHash.get(MPSDefs.DB_MEMBER_STATUS_NAME),
								(String) userServiceHash.get(MPSDefs.DB_GROUP_STATUS_NAME));

						userServiceHash.put(MPSDefs.SERVICE_STATUS, serviceStatus);

						if (serviceName.equals(MPSDefs.PORTAL_SERVICE)) {
							processPORTAL(inputParamHs, userServiceHash, hmQueryResponse);
						} else if (queryDSL != null && queryDSL.equals(MPSDefs.YES) &&  serviceName.equals(MPSDefs.DSL_SERVICE)) {
							processDSL(sMemberNum, userServiceHash, jdbcTemplate, queryDSLUserSql);
						} else if (queryDIAL != null && queryDIAL.equals(MPSDefs.YES) && serviceName.equals(MPSDefs.DIAL_SERVICE)) {
							processDIAL(sMemberNum, userServiceHash, jdbcTemplate, queryDIALUserSql);
						} else if (queryISDN != null && queryISDN.equals(MPSDefs.YES) && (serviceName.equalsIgnoreCase(MPSDefs.ISDN_SERVICE))
								|| (serviceName.equalsIgnoreCase(MPSDefs.ISDN2_SERVICE))) {
							processISDN(sMemberNum, userServiceHash, jdbcTemplate, queryISDNUserSql);
						} else if (queryWIFI != null && queryWIFI.equals(MPSDefs.YES) && serviceName.equalsIgnoreCase(MPSDefs.WIFI_SERVICE))
							processWIFI(sMemberNum, userServiceHash, jdbcTemplate, queryWIFIUserSql);
					}

					logger.debug("{}{}DBTOOLS21 : userServiceHash has ... {}", CLASS_NAME, sMethodName, userServiceHash);

					if (!servicesHashMapFlag) {
						servicesHash = CommonUtil.getHashMap();
						servicesHashMapFlag = true;
					}

					// This code takes care of adding multiple instance_id's to same service_name
					if (servicesHash.containsKey(serviceName)) {
						HashMap tempServiceHash = (HashMap) servicesHash.get(serviceName);
						userServiceHash.putAll(tempServiceHash);
					}

					servicesHash.put(serviceName, userServiceHash);

				} // end of if service_name is != null

				// LS R5 added for subaccount_eligible -- rp6341
				if (bSubEligibleServiceStatusRequired) {
					if (sAggSubEligibleServiceStatus != null)
						memServices.put(MPSDefs.AGG_SUBELIGIBLE_SERVICE_STATUS, sAggSubEligibleServiceStatus);
				}

				// MyWorld Aug 09 - Query MEMBERIDENTITY by member_num to get identity info -
				// vs3652
				if (sMemberNum != null) {
					memNumVal = Long.parseLong(sMemberNum);
				}

				// 1902 : Query MEMBERLOCKOUT
				String sQueryMemberlockout = (String) inputParamHs.get(MPSDefs.DB_QUERY_MEMBERLOCKOUT_FLAG);
				if (sQueryMemberlockout != null && sQueryMemberlockout.equalsIgnoreCase(MPSDefs.YES)) {
					List<Object> objectListLockout = new ArrayList<Object>();

					if (sSlidMemberNum != null && sSlidMemberNum.trim().length() > 0) {
						objectListLockout.add(sSlidMemberNum);
					} else {
						objectListLockout.add(memNumVal);
					}

					List alQueryLockoutResponse = jdbcTemplate.queryForList(new String(queryMemberLockout),
							objectListLockout.toArray(new Object[objectListLockout.size()]));

					ArrayList alMemberLocks = CommonUtil.getArrayList();
					HashMap<String, Object> hmLockInfo = null;

					for (int k = 0; k < alQueryLockoutResponse.size(); k++) {
						Map hmQueryLockoutResponse = (Map) alQueryLockoutResponse.get(k);

						Iterator iter = hmQueryLockoutResponse.keySet().iterator();
						while (iter.hasNext()) {
							String key = (String) iter.next();
							Object value = hmQueryLockoutResponse.get(key);

							String strValue = (value == null ? null : value.toString());

							hmQueryLockoutResponse.put(key, strValue);
						}

						hmLockInfo = CommonUtil.getHashMap();

						hmLockInfo.put(MPSDefs.DB_MEMBER_NUM, hmQueryLockoutResponse.get(MPSDefs.DB_MEMBER_NUM));
						hmLockInfo.put(MPSDefs.DB_LOCKOUT_ID, hmQueryLockoutResponse.get(MPSDefs.DB_LOCKOUT_ID));
						hmLockInfo.put(MPSDefs.DB_LOCKOUT_NAME, hmQueryLockoutResponse.get(MPSDefs.DB_LOCKOUT_NAME));
						hmLockInfo.put(MPSDefs.DB_SET_NUMBER, hmQueryLockoutResponse.get(MPSDefs.DB_SET_NUMBER));
						hmLockInfo.put(MPSDefs.DB_FAILED_AUTH_COUNT,
								hmQueryLockoutResponse.get(MPSDefs.DB_FAILED_AUTH_COUNT));
						hmLockInfo.put(MPSDefs.DB_LOCKOUT_EXPIRATION,
								hmQueryLockoutResponse.get(MPSDefs.DB_LOCKOUT_EXPIRATION));
						hmLockInfo.put(MPSDefs.DB_LAST_FAILED_AUTH,
								hmQueryLockoutResponse.get(MPSDefs.DB_LAST_FAILED_AUTH));
						hmLockInfo.put(MPSDefs.DB_CREATE_DATE, hmQueryLockoutResponse.get(MPSDefs.DB_CREATE_DATE));
						hmLockInfo.put(MPSDefs.DB_LAST_MODIFIED, hmQueryLockoutResponse.get(MPSDefs.DB_LAST_MODIFIED));
						hmLockInfo.put(MPSDefs.DB_LAST_MODIFIED_BY,
								hmQueryLockoutResponse.get(MPSDefs.DB_LAST_MODIFIED_BY));

						alMemberLocks.add(hmLockInfo);
					}

					if (alMemberLocks != null && !alMemberLocks.isEmpty()) {
						memServices.put(MPSDefs.DB_MEMBERLOCKOUT, alMemberLocks);
					} else {
						logger.info("{}{}DBTOOLS30 : No record found in MEMBERLOCKOUT table", CLASS_NAME, sMethodName);
					}
				} // end of queryMemberlockout=Y

				// October 2010, updated to return slid info if MID is associated to slid
				String sQuerySlidInfo = (String) inputParamHs.get(MPSDefs.QUERY_SLID_INFO_FLAG);

				if (sSlidMemberNum != null && sSlidMemberNum.trim().length() > 0 && sQuerySlidInfo != null
						&& sQuerySlidInfo.equalsIgnoreCase(MPSDefs.YES)) {
					inputParamHs.put(MPSDefs.DB_SLID_MEMBER_NUM, sSlidMemberNum);
					HashMap hmStatusTMS = oGetSlidInfoDBHelper.getSlidInfo(inputParamHs);
					sAppStatusCode = (String) hmStatusTMS.get(MPSDefs.APP_STATUS_CODE);

					if (!sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
						if (sAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND))
							logger.debug("{}{}DBTOOLS32 : No slid info found in MPS", CLASS_NAME, sMethodName);
						else
							return memServices = hmStatusTMS;
					}

					if (sAppStatusCode.equals(MPSDefs.MPS_SUCCESS))
						memServices.put(MPSDefs.KEY_SLID_INFO, hmStatusTMS.get(MPSDefs.KEY_SLID_INFO));
				}

				// 1510 - Updated for PID 266956b CTN Alias for Fraud - to return USERFRAULOCK
				// and ACCOUNTFRAUDLOCK details
				if (sQueryFraudLock != null && sQueryFraudLock.equalsIgnoreCase(MPSDefs.YES) &&
				                  sSlidMemberNum != null) {
					HashMap hmUserFraudLockInp = CommonUtil.getHashMap();
					hmUserFraudLockInp.put(MPSDefs.DB_MEMBER_NUM, sSlidMemberNum);

					HashMap hmStatusTMS = oFraudLockDBHelper.queryUserFraudLock(hmUserFraudLockInp);
					sAppStatusCode = (String) hmStatusTMS.get(MPSDefs.APP_STATUS_CODE);

					if (!sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
						if (sAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND))
							logger.info("{}{}DBTOOLS33.6 : No USERFRAUDLOCK info found in MPS", CLASS_NAME, sMethodName);
						else
							return memServices = hmStatusTMS;
					}

					if (sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
						memServices.put(MPSDefs.DB_USER_LOCK_LEVEL,
								(String) hmStatusTMS.get(MPSDefs.DB_USER_LOCK_LEVEL));
						memServices.put(MPSDefs.DB_USER_LOCK_REASON,
								(String) hmStatusTMS.get(MPSDefs.DB_USER_LOCK_REASON));
						memServices.put(MPSDefs.DB_FRAUD_AGENT, (String) hmStatusTMS.get(MPSDefs.DB_FRAUD_AGENT));
						memServices.put("fraud_last_modified_by",
								(String) hmStatusTMS.get(MPSDefs.DB_LAST_MODIFIED_BY));
						memServices.put("fraud_last_modified", (String) hmStatusTMS.get(MPSDefs.DB_LAST_MODIFIED));
						memServices.put("fraud_create_date", (String) hmStatusTMS.get(MPSDefs.DB_CREATE_DATE));
					}

				} // END - 1510

				// 1808 - Updated for PID 304635 SecMod UAM-7340 Update password rules - to
				// return MEMBERFRAUDPASSWORD details
				String sQueryMemFraudPwd = (String) inputParamHs.get(MPSDefs.QUERY_MEMBER_FRAUD_PASSWORD_FLAG);
				if (sQueryMemFraudPwd != null && sQueryMemFraudPwd.equalsIgnoreCase(MPSDefs.YES)
						&& CommonDefs.SLID_DUM.equals(sDbMemberDomain)) {
					HashMap hmMemFraudPwdInp = CommonUtil.getHashMap();
					hmMemFraudPwdInp.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);

					HashMap hmStatusTMS = oMemberFraudPasswordDBHelper.queryMemberFraudPwd(hmMemFraudPwdInp);
					sAppStatusCode = (String) hmStatusTMS.get(MPSDefs.APP_STATUS_CODE);

					if (!sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
						if (sAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND))
							logger.info("{}{}DBTOOLS33.7 : No MEMBERFRAUDPASSWORD info found in MPS", CLASS_NAME, sMethodName);
						else
							return memServices = hmStatusTMS;
					}

					if (sAppStatusCode.equals(MPSDefs.MPS_SUCCESS)) {
						memServices.put(MPSDefs.DB_MEMBER_FRAUD_PASSWORD_TABLE,
								hmStatusTMS.get(MPSDefs.DB_MEMBER_FRAUD_PASSWORD_TABLE));
					}

				} // END - 1808

				// End of R6 code
				if (servicesHash != null && !servicesHash.isEmpty()) {
					memServices.put(servicesKey, servicesHash);
				} else {
					return memServices;
				}

				count++;
			}

			if (count == 0) {

				memServices = StatusMsg.makeSQLStatus(MPSDefs.REC_NOT_FOUND, MPSDefs.REC_NOT_FOUND_MSG, MPSDefs.SQL_ERR,
						MPSDefs.SQL_ERR_MSG, MPSDefs.NO_ROW_UPDATED);
				logger.info("DBTOOLS34 : No row found");

				return memServices;
			}

		} catch (Exception excp) {
			errorMetricHandler.recordDbErrorMetric();
			memServices = StatusMsg.makeExceptionSQLStatus(excp);
			errorCode = (String) memServices.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}DBTOOLS_E3 : Exception = {}", CLASS_NAME, sMethodName, excp.getMessage());
			logger.error("{}{}DBTOOLS_E4 : Exception ={}", CLASS_NAME, sMethodName, excp);

		} finally {
			logger.info(SpiMarker.getInstance(), "{}{}DBTOOLS999 : STATUS = {}", CLASS_NAME, sMethodName, memServices);
		}

		return memServices;
	}

	private Date getDate() {
		return new Date();
	}
}