package com.att.idp.idgraphusermanagementms.helper;

import com.att.idp.idgraphusermanagementms.db.helper.AddMemberDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.GetSlidInfoDBHelper;
import com.att.idp.idgraphusermanagementms.utils.RILCheckAndEncryptPasswordHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.*;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * The AddExtUserHelper class is a Spring component that provides helper methods for adding external users.
 * It is configured to use a properties file for user management settings.
 * This class uses autowired dependencies on AddMemberDBHelper, GetSlidInfoDBHelper, and RILCheckAndEncryptPasswordHelper.
 * It contains methods for adding an external user, getting SLID information, adding a member, adding a member group, generating an encrypted password, and validating an external user request.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class AddExtUserHelper {

    public static final Logger logger = LoggerFactory.getLogger(AddExtUserHelper.class);
    private static final String CLASS_NAME = "AddExtUserHelper";
    @Autowired
    private AddMemberDBHelper addMemberDBHelper;
    @Autowired
    private GetSlidInfoDBHelper getSlidInfoDBHelper;
    @Autowired
    private RILCheckAndEncryptPasswordHelper rilCheckAndEncryptPasswordHelper;

    @Value("${RILHRS_ValidDomains}")
    private String rilhrsValidDomains;

    
    /**
     * This method is used to add an external user to the system.
     * It performs several operations such as validating the user request, getting SLID information, generating an encrypted password, adding a member group, and adding a member.
     * It handles various scenarios and returns appropriate responses based on the outcome of each operation.
     * 
     * @param hmInput A HashMap containing the necessary information about the user to be added. This includes details like user ID, domain, contact email, first name, last name, etc.
     * @return A Map containing the result of the operation. This includes status codes and messages indicating the success or failure of the operation.
     */
    public Map<String, Object> addExtUser(HashMap<String, Object> hmInput){
        String sMethodName = ".addExtUser.";
        String stAppInfo = null;
        String stAppStatusCode = null;
        HashMap<String, Object> hmResult = new HashMap<>();
        logger.info(SpiMarker.getInstance(), "{}{}HLP000 : Input Hash : {}", CLASS_NAME, sMethodName, hmInput);
        boolean isTransactionRollbackOnError = false;

        if (hmInput == null || hmInput.isEmpty()) {
            stAppInfo = "Input Hash is NUL";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
            logger.info("{}{}AUH_100 : {}", CLASS_NAME, sMethodName, stAppInfo);
            return hmResult;
        }

        try {
            logger.info(SpiMarker.getInstance(), "{}{}AEUH_2 : Validating AddExtUser with input : {}", CLASS_NAME, sMethodName, hmInput);
            hmResult = (HashMap<String, Object>) extUserRequestValidation(hmInput);
            logger.info("{}{}AEUH_15 : Response from AddExtUserHelper.addExtUserRequestValidation : {}", CLASS_NAME, sMethodName, hmResult);
            stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

            if (stAppStatusCode == null || !(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode.trim()))) {
                return hmResult;
            }
            logger.info(SpiMarker.getInstance(),"{}{}AEUH_15.1 : calling AddExtUserHelper.getSlidInfo with input : {}", CLASS_NAME, sMethodName, hmInput);

            hmResult = getSlidInfo((HashMap<String, Object>) hmInput);

            logger.info(SpiMarker.getInstance(),"{}{}AEUH_18.1 : Response from AddExtUserHelper.getSlidInfo : {}", CLASS_NAME, sMethodName, hmResult);

            stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

            if (stAppStatusCode == null || !(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode.trim()))) {
                return hmResult;
            }

            // encrypt password
            String stPasswordClear = (String) hmInput.get(CommonDefs.PASSWORD_CLEAR);

            if (stPasswordClear != null && !stPasswordClear.trim().isEmpty()) {

                logger.info(SpiMarker.getInstance(),"{}{}AEUH_18.2 : calling AddExtUserHelper.generateEncryptedPassword with input : {}", CLASS_NAME, sMethodName, hmInput);
                hmResult = generateEncryptedPassword(hmInput);
                logger.info("{}{}AEUH_22.1 : Response from AddExtUserHelper.generateEncryptedPassword : {}", CLASS_NAME, sMethodName, hmResult);

                stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

                if (stAppStatusCode == null || !(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode.trim()))) {
                    return hmResult;
                }
            }

            // Add Member Group
            logger.info("{}{}AEUH_22.2 : calling AddExtUserHelper.addMemberGroup method  :", CLASS_NAME, sMethodName);
            hmResult = addMemberGroup(hmInput);
            logger.info("{}{}AEUH_22.4 : Response from AddExtUserHelper.addMemberGroup  : {}", CLASS_NAME, sMethodName, hmResult);

            if (hmResult == null || hmResult.isEmpty()) {
                stAppInfo = "Null Response returned from addMemberDBHelper.addMemberGroup";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                logger.info("{}{}AEUH_22.3 : {}",CLASS_NAME ,sMethodName, stAppInfo);
                return hmResult;
            }

            stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

            if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                return hmResult;
            } else {
                isTransactionRollbackOnError = true;
            }

            String stGroupNum = (String) hmResult.get(MPSDefs.DB_GROUP_NUM);
            String stDomainId = (String) hmResult.get(MPSDefs.DB_DOMAIN_ID);
            hmInput.put(CommonDefs.GROUP_NUM, stGroupNum);
            hmInput.put(CommonDefs.DOMAIN_ID, stDomainId);


            // AddMember
            logger.info("{}{}AEUH_23 : calling AddExtUserHelper.addMember method  : ", CLASS_NAME, sMethodName);
            hmResult = addMember(hmInput);
            logger.info("{}{}AEUH_25.1 : Response from AddExtUserHelper.addMember  : {}", CLASS_NAME, sMethodName, hmResult);

            if (hmResult == null || hmResult.isEmpty()) {
                stAppInfo = "Null Response returned from addMemberDBHelper.addMember";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                logger.info("{}{}AEUH_26 : {}",CLASS_NAME ,sMethodName, stAppInfo);
                return hmResult;
            }

            stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

            if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {

                stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);

                if (stAppStatusCode.equals(CErrorDefs.ERR_USERNAME_EXISTS)) {

                    stAppInfo = "extGuid already exists in MPSYS";
                    hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                    logger.info( "{}{}AEUH_26.1 : {}",CLASS_NAME, sMethodName ,HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
                    hmResult.put(CommonDefs.GUID, hmInput.get(CommonDefs.EXT_GUID));
                    return hmResult;

                }
                logger.info( "{}{}AEUH_27 : {}",CLASS_NAME, sMethodName ,HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
                hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);

                return hmResult;

            } else {
                isTransactionRollbackOnError = true;
            }
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

        } catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e);
            stAppInfo = "Exception thrown addExtUser method : {} " +hmResult;
            logger.error("AEUH_28 : {}", HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
        }
        finally {
            String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
            if (isTransactionRollbackOnError && sAppCategoryCode != null && !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
                hmResult.put("isTransactionRollback", "Y");
            }
            logger.info("{}{}HLP999 : response from AddExtUser:{}",CLASS_NAME,sMethodName ,HtmlUtils.htmlEscape(String.valueOf(hmResult)));
        }
        return hmResult;
    }

    private HashMap<String,Object> getSlidInfo(HashMap<String,Object> hmInput) {
        String sMethodName = ".getSlidInfo.";
        HashMap<String, Object> hmGetSlidReq = new HashMap<>();
        HashMap<String, Object> hmResult = new HashMap<>();
        hmGetSlidReq.put(CommonDefs.TRANSACTION_NAME, (String) hmInput.get(CommonDefs.TRANSACTION_NAME));
        hmGetSlidReq.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(CommonDefs.TRANSACTION_ID));
        hmGetSlidReq.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
        hmGetSlidReq.put(CommonDefs.SLID, hmInput.get(CommonDefs.USER_ID));
        // Make sure about the SLID and USER_ID
        logger.info("{}{}AEUH_16 :Input to GetSlidInfoDBHelper.getSlidInfo: {}", CLASS_NAME, sMethodName, hmGetSlidReq);
        HashMap<String,Object> hmGetSlidResp = getSlidInfoDBHelper.getSlidInfo(hmGetSlidReq);
        logger.debug("{}{}AEUH_17 :Response from GetSlidInfoDBHelper.getSlidInfo: {}", CLASS_NAME, sMethodName, hmGetSlidResp);
        String stAppStatusCode = (String) hmGetSlidResp.get(MPSDefs.APP_STATUS_CODE);

        if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
            HashMap<String,Object> hmSlidInfo = (HashMap<String,Object>) hmGetSlidResp.get(CommonDefs.KEY_SLID_INFO);
            String stGuid = (String) hmSlidInfo.get(MPSDefs.DB_MEMBER_NUM);
            String stActivatedInd = (String)hmSlidInfo.get(MPSDefs.DB_ACTIVATED_IND);
            String stAppInfo = null;
            if (hmInput.get(CommonDefs.EXT_GUID).equals(stGuid)) {
                stAppInfo = "extGuid and UserId already exists";
            } else {
                stAppInfo = "UserId already exists";
            }
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USERNAME_EXISTS_NUM, stAppInfo);
            logger.info("{}{}AEUH_18 : {}", CLASS_NAME, sMethodName, stAppInfo);

            if(!StringUtils.isEmpty(stActivatedInd)) {
                hmResult.put(CommonDefs.ACTIVATED_IND, stActivatedInd);
            }
            hmResult.put(CommonDefs.GUID, stGuid);
            return hmResult;
        } else {
            if ((CErrorDefs.ERR_REC_NOT_FOUND).equals(stAppStatusCode)) {
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
            }
        }
        return hmResult;
    }

    private HashMap<String,Object> addMember(HashMap<String,Object> hmInput) {
        HashMap<String, Object> hmResult = null;
        HashMap<String, Object> hmAddMember = CommonUtil.getHashMap();
        String sMethodName = ".addMember.";
        logger.info(SpiMarker.getInstance(), "{}{}AEUH_23.1 : Input Hash : {}", CLASS_NAME, sMethodName, hmInput);
        String stFullName = (String) hmInput.get(CommonDefs.FULLNAME);
        String stFirstName = (String) hmInput.get(CommonDefs.FIRST_NAME);
        String stLastName = (String) hmInput.get(CommonDefs.LAST_NAME);
        String stHandle = (String) hmInput.get(CommonDefs.USER_ID);
        String stDomain = (String) hmInput.get(CommonDefs.DOMAIN);
        String stGroupNum = (String) hmInput.get(CommonDefs.GROUP_NUM);
        String stDomainId = (String) hmInput.get(CommonDefs.DOMAIN_ID);
        String stCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
        String stContactEmail = (String) hmInput.get(CommonDefs.CONTACT_EMAIL);
        String stAccessIdRTValidFlag = (String) hmInput.get(CommonDefs.ACCESS_ID_RTV_VALID_FLAG);
        String stContactEmailRTValidFlag = (String) hmInput.get(CommonDefs.CONTACT_EMAIL_RTV_FLAG);

        String stEnc_password = (String) hmInput.get(MPSDefs.DB_ENC_PASSWORD);
        String stMd5_password = (String) hmInput.get(MPSDefs.DB_MD5_PASSWORD);
        String stDes3_password = (String) hmInput.get(MPSDefs.DB_DES3_PASSWORD);
        String stSha1_password = (String) hmInput.get(MPSDefs.DB_SHA1_PASSWORD);
        String stAes_password = (String) hmInput.get(MPSDefs.DB_AES_PASSWORD);
        String generic_password = (String) hmInput.get(MPSDefs.DB_GEN_PASSWORD);
        String generic_password_type = (String) hmInput.get(MPSDefs.DB_GEN_PASSWORD_TYPE);

        String stLinkedFNUserId = (String) hmInput.get(CommonDefs.LINKED_FN_USER_ID);
        String stLinkedFNUserStatus = (String) hmInput.get(CommonDefs.LINKED_FN_USER_STATUS);

        String stParentChildInd = MPSDefs.MPS_SLID;
        String stSorName = CommonDefs.SOR_NA;
        String stAccountType = MPSDefs.DB_CONSUMER;
        String stPasswordDirty = CommonDefs.IND_N;

        String stExternalGuid = (String) hmInput.get(CommonDefs.EXT_GUID);

        hmAddMember.put(MPSDefs.DB_MEMBER_NAME, stHandle);
        hmAddMember.put(MPSDefs.DB_DOMAIN_ID, stDomainId);
        hmAddMember.put(MPSDefs.DB_DOMAIN_NAME, stDomain);
        hmAddMember.put(MPSDefs.DB_GROUP_NUM, stGroupNum);
        hmAddMember.put(CommonDefs.EXT_GUID, stExternalGuid);
        hmAddMember.put(MPSDefs.DB_PARENT_CHILD_IND, stParentChildInd);
        hmAddMember.put(MPSDefs.DB_ACCESS_NAME, CommonDefs.NONE_ACCESS);
        hmAddMember.put(MPSDefs.DB_SOR_NAME, stSorName);
        hmAddMember.put(MPSDefs.DB_LAST_MODIFIED_BY, stCallingSystemId);
        hmAddMember.put(MPSDefs.DB_ACCOUNT_TYPE, stAccountType);
        hmAddMember.put(MPSDefs.DB_MEMBER_STATE, MPSDefs.RESERVED_STATE);

        if (stEnc_password != null && !stEnc_password.isEmpty()) {
            hmAddMember.put(MPSDefs.DB_ENC_PASSWORD, stEnc_password);
        }
        if (stMd5_password != null && !stMd5_password.isEmpty()) {
            hmAddMember.put(MPSDefs.DB_MD5_PASSWORD, stMd5_password);
        }
        if (stDes3_password != null && !stDes3_password.isEmpty()) {
            hmAddMember.put(MPSDefs.DB_DES3_PASSWORD, stDes3_password);
        }
        if (stSha1_password != null && !stSha1_password.isEmpty()) {
            hmAddMember.put(MPSDefs.DB_SHA1_PASSWORD, stSha1_password);
        }
        if (stAes_password != null && !stAes_password.isEmpty()) {
            hmAddMember.put(MPSDefs.DB_AES_PASSWORD, stAes_password);
        }
        if (generic_password != null && !generic_password.isEmpty()) {
            hmAddMember.put(MPSDefs.DB_GEN_PASSWORD, generic_password);
            hmAddMember.put(MPSDefs.DB_GEN_PASSWORD_TYPE, generic_password_type);
        }
        if (stContactEmail != null && !stContactEmail.trim().isEmpty()) {
            hmAddMember.put(MPSDefs.DB_CONTACT_EMAIL, stContactEmail);
            hmAddMember.put(MPSDefs.DB_CONTACT_EMAIL_VALID, CommonDefs.IND_Y);
            hmAddMember.put(MPSDefs.DB_CONTACT_EMAIL_STATUS, "V");
        }
        if (stFirstName != null && !stFirstName.trim().isEmpty()) {
            hmAddMember.put(MPSDefs.DB_LC_FIRSTNAME, stFirstName);
        }
        if (stLastName != null && !stLastName.trim().isEmpty()) {
            hmAddMember.put(MPSDefs.DB_LC_LASTNAME, stLastName);
        }
        if (stFullName != null && !stFullName.trim().isEmpty()) {
            hmAddMember.put(MPSDefs.DB_FULLNAME, stFullName);
        }
        if (stAccessIdRTValidFlag != null && !stAccessIdRTValidFlag.trim().isEmpty()) {
            hmAddMember.put(CommonDefs.DB_ACCESS_ID_RTV_DATE, stAccessIdRTValidFlag);
        }
        if (stContactEmailRTValidFlag != null && !stContactEmailRTValidFlag.trim().isEmpty()) {
            hmAddMember.put(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE, stContactEmailRTValidFlag);
        }

        if (stLinkedFNUserId != null && !stLinkedFNUserId.isEmpty()) {
            hmAddMember.put(CommonDefs.DB_FN_LINKED_USERID, stLinkedFNUserId);
        }
        if (stLinkedFNUserStatus != null && !stLinkedFNUserStatus.isEmpty()) {
            hmAddMember.put(CommonDefs.DB_FN_LINKED_STATUS, stLinkedFNUserStatus);
        }
        if (stPasswordDirty != null && !stPasswordDirty.isEmpty()) {
            hmAddMember.put(MPSDefs.DB_PASSWORD_DIRTY, stPasswordDirty);
        }

        logger.debug("{}{}AEUH_24 : Calling AddMemberDBHelper.addMember with inputHash : {}", CLASS_NAME, sMethodName,
                HtmlUtils.htmlEscape(String.valueOf(hmAddMember)));

        hmResult = addMemberDBHelper.addMember(hmAddMember);

        logger.debug("{}{}AEUH_25 : ResponseHash from AddMemberDBHelper.addMember : {}", CLASS_NAME, sMethodName, hmResult);

        return hmResult;
    }
    private HashMap<String,Object> addMemberGroup(HashMap<String,Object> hmInput) {
        HashMap<String, Object> hmResult = null;
        String sMethodName = ".addMemberGroup.";
        HashMap<String, Object> hmAddMemberGroup = CommonUtil.getHashMap();
        hmAddMemberGroup.put(MPSDefs.DB_DOMAIN_NAME, hmInput.get(CommonDefs.DOMAIN));
        hmAddMemberGroup.put(MPSDefs.DB_PARENT_NAME, hmInput.get(CommonDefs.USER_ID));
        hmAddMemberGroup.put(MPSDefs.DB_LAST_MODIFIED_BY, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));

        logger.info("{}{}AEUH_22.2 : AddMemberDBHelper.addMemberGroup with inputHash : {}", CLASS_NAME, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmAddMemberGroup)));
        hmResult = addMemberDBHelper.addMemberGroup(hmAddMemberGroup);
        logger.debug("{}{}AEUH_22.3 : ResponseHash from AddMemberDBHelper.addMemberGroup : {}", CLASS_NAME, sMethodName, hmResult);
        return hmResult;
    }
    private HashMap<String,Object> generateEncryptedPassword(HashMap<String,Object> hmInput) {
        HashMap<String, Object> hmResult;
        String sMethodName = ".generateEncryptedPassword.";
        String stAppInfo;
        String stAppStatusCode;
        HashMap<String, Object> hmCheckAndEncryptInput = new HashMap<>();
        hmCheckAndEncryptInput.put(MPSDefs.WS_TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
        hmCheckAndEncryptInput.put(MPSDefs.WS_TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
        hmCheckAndEncryptInput.put(MPSDefs.WS_CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
        hmCheckAndEncryptInput.put(MPSDefs.WS_CLEAR_TEXT, hmInput.get(CommonDefs.PASSWORD_CLEAR));
        hmCheckAndEncryptInput.put(MPSDefs.WS_USER_ID, hmInput.get(CommonDefs.USER_ID));
        hmCheckAndEncryptInput.put(MPSDefs.WS_DOMAIN, hmInput.get(CommonDefs.DOMAIN));
        hmCheckAndEncryptInput.put(CommonDefs.SKIP_PASSWORD_VALIDATION, CommonDefs.IND_Y);

        logger.debug("{}{}AEUH_19 : Calling RILCheckAndEncryptPasswordHelper with inputHash : {}", CLASS_NAME, sMethodName,
                HtmlUtils.htmlEscape(String.valueOf(hmCheckAndEncryptInput)));

        hmResult = rilCheckAndEncryptPasswordHelper.checkAndEncryptPassword(hmCheckAndEncryptInput);

        logger.debug("{}{}AEUH_20 : ResponseHash from RILCheckAndEncryptPasswordHelper : {}", CLASS_NAME, sMethodName,
                hmResult);

        if (hmResult == null || hmResult.isEmpty()) {
            stAppInfo = "Null Response returned from RILCheckAndEncryptPassword Helper";
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
            logger.info("{}{}AEUH_21 : {}", CLASS_NAME, sMethodName, stAppInfo);
            return hmResult;
        }

        stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

        if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
            stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
            logger.info("{}{}AEUH_22 : {}", CLASS_NAME, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
            hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
            return hmResult;
        }

        String stEnc_password = (String) hmResult.get(RILDefs.RIL_ENC_PASSWORD);
        String stMd5_password = (String) hmResult.get(RILDefs.RIL_MD5_PASSWORD);
        String stDes3_password = (String) hmResult.get(RILDefs.RIL_DES3_PASSWORD);
        String stSha1_password = (String) hmResult.get(RILDefs.RIL_SHA1_PASSWORD);
        String generic_password = (String) hmResult.get(RILDefs.RIL_GEN_PASSWORD);
        String generic_password_type = (String) hmResult.get(RILDefs.RIL_GEN_PASSWORD_TYPE);
        String stAes_password = (String) hmResult.get(RILDefs.RIL_AES_PASSWORD);
        hmInput.put(MPSDefs.DB_ENC_PASSWORD, stEnc_password);
        hmInput.put(MPSDefs.DB_MD5_PASSWORD, stMd5_password);
        hmInput.put(MPSDefs.DB_DES3_PASSWORD, stDes3_password);
        hmInput.put(MPSDefs.DB_SHA1_PASSWORD, stSha1_password);
        hmInput.put(MPSDefs.DB_AES_PASSWORD, stAes_password);

        if (generic_password != null && !generic_password.isEmpty()) {
            hmInput.put(MPSDefs.DB_GEN_PASSWORD, generic_password);
            hmInput.put(MPSDefs.DB_GEN_PASSWORD_TYPE, generic_password_type);
        }
        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
        return hmResult;
    }
    private Map<String, Object> extUserRequestValidation(HashMap<String, Object> hmInput) {

        String sMethodName = ".addExtUserRequestValidation.";
        Map<String, Object> hmResult = null;
        String stAppInfo = null;

        String stUserId = hmInput.get(CommonDefs.USER_ID).toString();
        String stDomain = hmInput.get(CommonDefs.DOMAIN).toString();
        String stContactEmail = null;
        if(hmInput.containsKey(CommonDefs.CONTACT_EMAIL)) {
             stContactEmail = (String) hmInput.get(CommonDefs.CONTACT_EMAIL);
        }
        String stFullName = null;
        String stFirstName = (String) hmInput.get(CommonDefs.FIRST_NAME);
        String stLastName = (String) hmInput.get(CommonDefs.LAST_NAME);

        try {
            if (stUserId.contains("@")) {
                int len = stUserId.indexOf('@');

                if (len > -1) {
                    String stTempDomain = stUserId.substring(len + 1);
                    String stTempHandle = stUserId.substring(0, len);

                    if ((stTempHandle == null || stTempHandle.isEmpty()) || (stTempDomain == null || stTempDomain.isEmpty())) {
                        stAppInfo = "Input slid is not in correct email format";
                        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                        logger.info("{}{}AEUH_12.1 : {}", CLASS_NAME, sMethodName, stAppInfo);
                        return hmResult;
                    }

                    if (rilhrsValidDomains == null || rilhrsValidDomains.isEmpty()) {
                        stAppInfo = "The value of RILHRS_ValidDomains is not configured in property files";
                        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
                        logger.info("{}{}AEUH_12.2 : {}", CLASS_NAME, sMethodName, stAppInfo);
                        return hmResult;
                    }

                    ArrayList alDBDomainList = CommonUtil.parseToArray(rilhrsValidDomains, CommonDefs.VALUE_SEPARATOR_CHAR);

                    logger.info("{}{}AEUH_13 : Property RILHRS_ValidDomains : {}", CLASS_NAME, sMethodName, alDBDomainList);

                    if (alDBDomainList != null && alDBDomainList.contains(stTempDomain)) {
                        stAppInfo = "External Domain cannot be same as ATT domain";
                        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, stAppInfo);
                        logger.info("{}{}AEUH_14 : {}", CLASS_NAME, sMethodName, stAppInfo);
                        return hmResult;
                    }
                    hmInput.put("ignoreQay", "Y");
                }
            }
            // trim contactemail to 64
            if (stContactEmail != null && !stContactEmail.isEmpty()) {

                String stContactEmailValid = CommonDefs.IND_Y;

                int pos = stContactEmail.indexOf('@');

                if (pos > 0) {
                    String temp = stContactEmail.substring(pos + 1);
                    if (temp.indexOf('.') <= 0)
                        stContactEmailValid = CommonDefs.IND_N;
                } else
                    stContactEmailValid = CommonDefs.IND_N;

                if (CommonDefs.IND_Y.equals(stContactEmailValid)) {
                    hmInput.put(CommonDefs.CONTACT_EMAIL_VALID, CommonDefs.IND_Y);
                    hmInput.put(CommonDefs.CONTACT_EMAIL_STATUS, "V");

                } else {
                    hmInput.put(CommonDefs.CONTACT_EMAIL_VALID, CommonDefs.IND_N);
                }
                // Trimming contact email to 64
                if (stContactEmail.length() > 64) {
                    stContactEmail = stContactEmail.substring(0, 64);
                    hmInput.put(CommonDefs.CONTACT_EMAIL, stContactEmail);
                }

            } else if (hmInput.get(CommonDefs.CONTACT_EMAIL_RTV_FLAG) != null
                    && CommonDefs.IND_Y.equals(hmInput.get(CommonDefs.CONTACT_EMAIL_RTV_FLAG))) {
                hmInput.put(CommonDefs.CONTACT_EMAIL_RTV_FLAG, CommonDefs.IND_N);
            }

            // FirstName and lastName trim to 50 and update hmInput
            if (stFirstName != null && !stFirstName.trim().isEmpty()) {
                stFirstName = (stFirstName.length() > 50) ? stFirstName.substring(0, 50) : stFirstName;
                hmInput.put(CommonDefs.FIRST_NAME, stFirstName);
            }

            if (stLastName != null && !stLastName.trim().isEmpty()) {
                stLastName = (stLastName.length() > 50) ? stLastName.substring(0, 50) : stLastName;
                hmInput.put(CommonDefs.LAST_NAME, stLastName);

            }
            if (stFirstName != null && !stFirstName.trim().isEmpty() && stLastName != null && !stLastName.trim().isEmpty()) {
                stFullName = stFirstName + " " + stLastName;
                hmInput.put(CommonDefs.FULLNAME, stFullName);
            }else {
                stFullName = stUserId.trim() + "@"+ stDomain;
                hmInput.put(CommonDefs.FULLNAME, stFullName);
            }

            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

        }catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e);
            stAppInfo = "Exception thrown ExtUserRequestValidation method : {} " +hmResult;
            logger.error("AEUH_14.1 : {}", HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
        }
        return hmResult;
    }
}