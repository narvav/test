package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TMEMBERLOCKOUT", schema = "MPS_OWNER")
public class Tmemberlockout implements Serializable {

	private static final long serialVersionUID = 711031964161404704L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "memberNum", column = @Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "lockoutId", column = @Column(name = "LOCKOUT_ID", nullable = false, precision = 22, scale = 0)) })
	private TmemberlockoutId id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "LOCKOUT_ID", referencedColumnName = "LOCKOUT_ID", insertable = false, updatable = false),
			@JoinColumn(name = "SET_NUMBER", referencedColumnName = "SET_NUMBER", insertable = false, updatable = false) })
	private Tlockoutconfig tlockoutconfig;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MEMBER_NUM", nullable = false, insertable = false, updatable = false)
	private Tmember tmember;

	@Column(name = "FAILED_AUTH_COUNT", precision = 22, scale = 0)
	private Long failedAuthCount;

	@Column(name = "LOCKOUT_EXPIRATION", length = 7)
	private Date lockoutExpiration;

	@Column(name = "LAST_FAILED_AUTH", length = 7)
	private Date lastFailedAuth;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;

	@Column(name = "SET_NUMBER")
	private Long setNumber;
}