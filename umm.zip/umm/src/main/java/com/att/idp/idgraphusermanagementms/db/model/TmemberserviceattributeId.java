package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class TmemberserviceattributeId implements Serializable {

	private static final long serialVersionUID = -2425472529801906764L;

	@Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)
	private Long memberNum;

	@Column(name = "SERVICE_ID", nullable = false, precision = 22, scale = 0)
	private Long serviceId;

	@Column(name = "SOR_ID", precision = 22, scale = 0)
	private Long sorId;

	@Column(name = "SOR_INVARIANT_ID")
	private String sorInvariantId;

	@Column(name = "INSTANCE_ID", length = 24)
	private String instanceId;

	@Column(name = "ATTRIBUTE_ID", nullable = false, precision = 22, scale = 0)
	private Long attributeId;

	@Column(name = "VALUE", length = 1024)
	private String value;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", nullable = false, length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TmemberserviceattributeId))
			return false;
		TmemberserviceattributeId castOther = (TmemberserviceattributeId) other;

		return ((this.getMemberNum() == castOther.getMemberNum()) || (this.getMemberNum() != null
				&& castOther.getMemberNum() != null && this.getMemberNum().equals(castOther.getMemberNum())))
				&& ((this.getServiceId() == castOther.getServiceId()) || (this.getServiceId() != null
				&& castOther.getServiceId() != null && this.getServiceId().equals(castOther.getServiceId())))
				&& ((this.getSorId() == castOther.getSorId()) || (this.getSorId() != null
				&& castOther.getSorId() != null && this.getSorId().equals(castOther.getSorId())))
				&& ((this.getSorInvariantId() == castOther.getSorInvariantId())
				|| (this.getSorInvariantId() != null && castOther.getSorInvariantId() != null
				&& this.getSorInvariantId().equals(castOther.getSorInvariantId())))
				&& ((this.getInstanceId() == castOther.getInstanceId()) || (this.getInstanceId() != null
				&& castOther.getInstanceId() != null && this.getInstanceId().equals(castOther.getInstanceId())))
				&& ((this.getAttributeId() == castOther.getAttributeId())
				|| (this.getAttributeId() != null && castOther.getAttributeId() != null
				&& this.getAttributeId().equals(castOther.getAttributeId())))
				&& ((this.getValue() == castOther.getValue()) || (this.getValue() != null
				&& castOther.getValue() != null && this.getValue().equals(castOther.getValue())))
				&& ((this.getCreateDate() == castOther.getCreateDate()) || (this.getCreateDate() != null
				&& castOther.getCreateDate() != null && this.getCreateDate().equals(castOther.getCreateDate())))
				&& ((this.getLastModified() == castOther.getLastModified())
				|| (this.getLastModified() != null && castOther.getLastModified() != null
				&& this.getLastModified().equals(castOther.getLastModified())))
				&& ((this.getLastModifiedBy() == castOther.getLastModifiedBy())
				|| (this.getLastModifiedBy() != null && castOther.getLastModifiedBy() != null
				&& this.getLastModifiedBy().equals(castOther.getLastModifiedBy())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getMemberNum() == null ? 0 : this.getMemberNum().hashCode());
		result = 37 * result + (getServiceId() == null ? 0 : this.getServiceId().hashCode());
		result = 37 * result + (getSorId() == null ? 0 : this.getSorId().hashCode());
		result = 37 * result + (getSorInvariantId() == null ? 0 : this.getSorInvariantId().hashCode());
		result = 37 * result + (getInstanceId() == null ? 0 : this.getInstanceId().hashCode());
		result = 37 * result + (getAttributeId() == null ? 0 : this.getAttributeId().hashCode());
		result = 37 * result + (getValue() == null ? 0 : this.getValue().hashCode());
		result = 37 * result + (getCreateDate() == null ? 0 : this.getCreateDate().hashCode());
		result = 37 * result + (getLastModified() == null ? 0 : this.getLastModified().hashCode());
		result = 37 * result + (getLastModifiedBy() == null ? 0 : this.getLastModifiedBy().hashCode());
		return result;
	}

}