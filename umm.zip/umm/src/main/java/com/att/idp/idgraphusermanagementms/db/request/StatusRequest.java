package com.att.idp.idgraphusermanagementms.db.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * This is the StatusRequest class which implements Serializable interface.
 * It represents a request for a status with properties like statusCode, statusName, and statusDesc.
 * Each property has its respective getter and setter methods.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({
		// Add properties here if needed
})
public class StatusRequest implements Serializable {

	private static final long serialVersionUID = -6429645534827184481L;
	private Long statusCode;
	private String statusName;
	private String statusDesc;
}