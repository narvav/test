package com.att.idp.idgraphusermanagementms.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ListIterator;

import com.att.idp.idgraphusermanagementms.db.helper.*;
import com.att.idp.idgraphusermanagementms.helper.resetuserpassword.MemberLockoutDbHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

@Component
public class UpdateMemberDataHelper extends AbstractHelper {

    @Autowired
    MemberDBHelper memberDBHelper;

    @Autowired
    AddServiceDBHelper addServiceDBHelper;

    @Autowired
    UpdateServiceDBHelper updateServiceDBHelper;

    @Autowired
    private RolesDBHelper rolesDBHelper;

    @Autowired
    private ServiceInfoDBHelper serviceInfoDBHelper;

    @Autowired
    private ServiceContactDBHelper serviceContactDBHelper;

    @Autowired
    private ServiceNotificationDBHelper serviceNotificationDBHelper;

    @Autowired
    private DeleteMemberDBHelper oDeleteMemberDBHelper;

    @Autowired
    private MemberLockoutDbHelper memberLockoutDbHelper;

    @Autowired
    private FraudLockDBHelper fraudLockDBHelper;

    @Autowired
    private MemberFraudPasswordDBHelper memberFraudPasswordDBHelper;

    @Autowired
    private UserMergeDBHelper userMergeDBHelper;

    @Autowired
    private AccountLockoutDBHelper accountLockoutDBHelper;

    @Autowired
    private UpdateDBHelper updateDBHelper;
    @Autowired
    private MemberServiceAttributeDBHelper memberServiceAttributeDBHelper;

    public static final Logger logger = LoggerFactory.getLogger(UpdateMemberDataHelper.class);
    private static String sClassName = "UpdateMemberDataHelper";

    public HashMap processData(HashMap<String, Object> hmInput) {
        String sThisMethod = ".processData.";

        ArrayList<String> alMemberLockout = CommonUtil.getArrayList();
        ArrayList<String> alUserFraudLock = CommonUtil.getArrayList(); // 1510
        ArrayList<String> alAccountFraudLock = CommonUtil.getArrayList(); // 1510
        ArrayList<String> alAccountlockout = CommonUtil.getArrayList();

        String sAppInfo;
        String stAppInfo;
        String sAppStatusCode;
        HashMap<String, Object> hmResult = null;
        HashMap<String, Object> hmMemberFraudPassword = CommonUtil.getHashMap(); // 1808
        HashMap<String, Object> hmUserMerge = null; //2004
        ArrayList<String> alMemberGroup = null;
        HashMap<String, Object> hmUpdateServiceContact = null;
        ArrayList<String> alMemberservicerole = null;
        ArrayList<String> alServicecontact = null;
        ArrayList<String> alWirelineuser = null;
        ArrayList<String> alServicenotification = null;
        ArrayList<String> alServiceinfo = null;
        ArrayList<String> alRemoveMobiltyDevcies = null;
        String sOperation = null;
        HashMap<String, Object> hmAddServices = null;
        HashMap<String, Object> hmRemoveServices = null;
        HashMap<String, Object> hmRemoveAccountRequest = CommonUtil.getHashMap();
        ArrayList alMember = null;
        ArrayList<String> alMemberService = null;
        ArrayList alUpdateMemSvcAttrs = null; //1806
        ArrayList alpendingaction = null;

        hmResult = validateMapInput(hmInput, CErrorDefs.ERR_SYS_APPL_NUM,
                "Input parameters to MPSTMS_UpdateMemberDataBean is null / empty");
        if (hmResult != null) return hmResult;

        String sTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);
        String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
        String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);

        try {
            alMember = (ArrayList<String>) hmInput.get(MPSDefs.DB_MEMBER_TABLE);
            alMemberService = (ArrayList) hmInput.get(MPSDefs.DB_MEMBERSERVICE_TABLE);
            alMemberLockout = (ArrayList) hmInput.get(MPSDefs.DB_MEMBERLOCKOUT);
            alAccountFraudLock = (ArrayList) hmInput.get(MPSDefs.DB_ACCOUNTFRAUDLOCK); // 1510
            alUserFraudLock = (ArrayList) hmInput.get(MPSDefs.DB_USERFRAUDLOCK);
            alAccountlockout = (ArrayList) hmInput.get(MPSDefs.DB_ACCOUNTLOCKOUT);
            hmMemberFraudPassword = (HashMap<String, Object>) hmInput.get(MPSDefs.DB_MEMBER_FRAUD_PASSWORD_TABLE);//1808
            hmUserMerge = (HashMap<String, Object>) hmInput.get("usermerge"); // [R2004] : Changes for PID#323487a (HBO Max)
            alUpdateMemSvcAttrs = (ArrayList) hmInput.get("updateServiceAttributes"); //1806 PID 292348 : Updates to support wireless SMB accounts
            alMemberGroup = (ArrayList) hmInput.get(MPSDefs.DB_MEMBERGROUP_TABLE);
            hmUpdateServiceContact = (HashMap<String, Object>) hmInput.get("updateServiceContact");
            alMemberservicerole = (ArrayList) hmInput.get(MPSDefs.DB_MEMBER_SERVICE_ROLES);
            alServicecontact = (ArrayList) hmInput.get(CommonDefs.SERVICE_CONTACT);
            alServicenotification = (ArrayList) hmInput.get(CommonDefs.KEY_SERVICE_NOTIFICATION);
            alServiceinfo = (ArrayList) hmInput.get(MPSDefs.DB_SERVICEINFO);
            alRemoveMobiltyDevcies = (ArrayList) hmInput.get(MPSDefs.WS_REMOVE_MOBILITY_DEVICES);
            hmAddServices = (HashMap<String, Object>) hmInput.get(MPSDefs.WS_ADD_SERVICES);
            hmRemoveAccountRequest = (HashMap) hmInput.get("removeAccount");
            alpendingaction = (ArrayList) hmInput.get(CommonDefs.PENDING_ACTION);

            if ((alMember == null || alMember.isEmpty())
                    && (alMemberLockout == null || alMemberLockout.isEmpty())
                    && (alUserFraudLock == null || alUserFraudLock.isEmpty()) // 1510
                    && (alAccountFraudLock == null || alAccountFraudLock.isEmpty()) // 1510
                    && (alAccountlockout == null || alAccountlockout.isEmpty())
                    && (alMemberService == null || alMemberService.isEmpty())
                    && (alMemberGroup == null || alMemberGroup.isEmpty())
                    && (hmUpdateServiceContact == null || hmUpdateServiceContact.isEmpty())
                    && (hmAddServices == null || hmAddServices.isEmpty())
                    //	&& (hmRemoveServices == null || hmRemoveServices.isEmpty())
                    && (alRemoveMobiltyDevcies == null || alRemoveMobiltyDevcies.isEmpty())
                    && (alMemberservicerole == null || alMemberservicerole.isEmpty())
                    && (alServicecontact == null || alServicecontact.isEmpty())
                    && (alUpdateMemSvcAttrs == null || alUpdateMemSvcAttrs.isEmpty())
                    && (alWirelineuser == null || alWirelineuser.isEmpty())
                    && (alServicenotification == null || alServicenotification.isEmpty())
                    && (alServiceinfo == null || alServiceinfo.isEmpty())
                    && (hmRemoveAccountRequest == null || hmRemoveAccountRequest.isEmpty())
                    && (alpendingaction == null || alpendingaction.isEmpty())//1406 Uverse Migration changes
                    && (hmMemberFraudPassword == null || hmMemberFraudPassword.isEmpty())
                    && (hmUserMerge == null || hmUserMerge.isEmpty())) // [R2004] : Changes for PID#323487a (HBO Max)) //1808 PID 304635


            {

                sAppInfo = "Input does not have either Member/MemberLockout/Accountlockout/MemberService/Nickname/UpdateServiceContact/Memberservicerole/Servicecontact/Serviceinfo/RemoveAccount/ISSUser data/PendingAction/linkrecommender/LoyaltyAccount/UpdateMemberServiceAttribute/UserMerge data";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
                logger.info("{}{} UMDH.PD.02 : {}", sClassName, sThisMethod, sAppInfo);
                return hmResult;
            }


            //1406 Uverse Migration changes
            HashMap hmPendingAction = null;
            if (alpendingaction != null && !alpendingaction.isEmpty()) {
                for (Object o : alpendingaction) {
                    hmPendingAction = (HashMap) o;
                    if (hmPendingAction != null && !hmPendingAction.isEmpty()) {
                        sOperation = (String) hmPendingAction.get(MPSDefs.DB_OPERATION);
                        if (sOperation == null || sOperation.isEmpty()) {
                            sAppInfo = " sOperation is null or empty ";
                            hmResult = CommonErrorMap.makeCategoryMap(
                                    MPSDefs.ERR_INVALID_DATA_NUM, sAppInfo);
                            logger.info("{}{} UMDH.PD.03 : {}", sClassName, sThisMethod, sAppInfo);

                            return hmResult;
                        }
                        if (sOperation.equalsIgnoreCase(MPSDefs.DB_OPERATION_INSERT)) {

                            logger.info("{}{}UMDH.PD.04 : {}:{}", sClassName, sThisMethod,
                                    "Calling MemberDBHelper.hmPendingAction () with input = ", hmPendingAction);
                            hmResult = memberDBHelper.addPendingAction(hmPendingAction);
                            logger.info("{}{}UMDH.PD.05 : {}:{}", sClassName, sThisMethod,
                                    "Response from MemberDBHelper.addPendingAction () ", hmResult);

                        }
                        if (sOperation.equalsIgnoreCase(MPSDefs.DB_OPERATION_UPDATE)) {
                            logger.info("{}{}UMDH.PD.04 : {}:{}", sClassName, sThisMethod,
                                    "Calling MemberDBHelper.updatePendingAction () with input = ", hmPendingAction);
                            hmResult = memberDBHelper.updatePendingAction(hmPendingAction);
                            logger.info("{}{}UMDH.PD.05 : {}:{}", sClassName, sThisMethod,
                                    "Response from MemberDBHelper.updatePendingAction () ", hmResult);

                        }
                        if (sOperation.equalsIgnoreCase(MPSDefs.DB_OPERATION_DELETE)) {

                            logger.info("{}{}UMDH.PD.04 : {}:{}", sClassName, sThisMethod,
                                    "Calling MemberDBHelper.deletePendingAction () with input = ", hmPendingAction);
                            hmResult = memberDBHelper.deletePendingAction(hmPendingAction);
                            logger.info("{}{}UMDH.PD.05 : {}:{}", sClassName, sThisMethod,
                                    "Response from MemberDBHelper.deletePendingAction () ", hmResult);

                        }
                    }
                    HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                            "MemberDBHelper.hmPendingAction() call is returning null or Empty Hash");
                    if (result != null) return result;

                    if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                            "MemberDBHelper.hmPendingAction() call failed ")) {
                        return hmResult;
                    }
                }
            }
            //1406 Uverse Migration changes - Link Recommender
            if (hmInput.containsKey("removeAccount") && hmRemoveAccountRequest != null && !hmRemoveAccountRequest.isEmpty()) {

                hmResult = removeAccount(hmRemoveAccountRequest);

                if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                        "MPS RemoveAccount call failed ")) {
                    return hmResult;
                }
            }


            if (hmInput.containsKey(MPSDefs.DB_MEMBER_TABLE)) {

                HashMap<String, Object> hmMPSInput = CommonUtil.getHashMap();
                hmMPSInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                hmMPSInput.put(MPSDefs.DB_MEMBER_TABLE, alMember);
                hmMPSInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
                hmMPSInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);


                // 1412 : US305896 : added below check is explicitly for MigrateLegacySBUsers API for converting .net to SLID and
                // updating parameters : domain_id,member_name, sor_id, parent_child_ind, account_type, remarks for member
                if (sTransactionName != null && (sTransactionName.equals("MigrateLegacySBUsers")
                        || "RevertLegacySBUsers".equals(sTransactionName))) {
                    logger.info("{}{}UMDH.PD.04 : {}:{}", sClassName, sThisMethod,
                            "Calling MemberDBHelper.processWirelineMigration () with input = ", hmMPSInput);

                    hmResult = memberDBHelper.processWirelineMigrationData(hmMPSInput);
                    logger.info("{}{}UMDH.PD.05 : {}:{}", sClassName, sThisMethod,
                            "Response from MemberDBHelper.processWirelineMigration () ", hmResult);

                    HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                            "MemberDBHelper.processWirelineMigration  call is returning null or Empty Hash");
                    if (result != null) return result;

                    if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                            "MemberDBHelper.processWirelineMigration call failed ")) {
                        return hmResult;
                    }
                } else {
                    logger.info("{}{}UMDH.PD.07 : {}:{}", sClassName, sThisMethod,
                            "Calling MemberDBHelper.processData () with input = ", hmMPSInput);
                    hmResult = memberDBHelper.processData(hmMPSInput);
                    logger.info("{}{}UMDH.PD.08 : {}:{}", sClassName, sThisMethod,
                            "Response from MemberDBHelper.processWirelineMigration () ", hmResult);

                    HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                            "MemberDBHelper.processData  call is returning null or Empty Hash");
                    if (result != null) return result;

                    if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                            "MemberDBHelper.processData call failed ")) {
                        return hmResult;
                    }
                }
            }

            if (hmInput.containsKey(MPSDefs.DB_MEMBERLOCKOUT)) {

                HashMap<String, Object> hmMPSInput = CommonUtil.getHashMap();
                hmMPSInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                hmMPSInput.put(MPSDefs.DB_MEMBERLOCKOUT, alMemberLockout);

                logger.info("{}{}UMDH.PD.11 : {}:{}", sClassName, sThisMethod,
                        "Calling MemberLockoutDbHelper.processData () with input = ", hmMPSInput);

                //Calling MMPSDB_TMEMBERLOCKOUT_H.processData  with Input params
                hmResult = memberLockoutDbHelper.processData(hmMPSInput);
                logger.info("{}{}UMDH.PD.12 : {}:{}", sClassName, sThisMethod,
                        "Response from MemberLockoutDbHelper.processData () ", hmResult);

                HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                        "MemberLockoutDbHelper.processData() call is returning null or Empty Hash");
                if (result != null) return result;

                if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                        "MemberLockoutDbHelper.processData() call failed.")) {
                    return hmResult;
                }
            }
            // 1510 : EPIC PID 266956b CTN Alias for Fraud
            if ((alUserFraudLock != null && !alUserFraudLock.isEmpty()) || (alAccountFraudLock != null && !alAccountFraudLock.isEmpty())) {

                HashMap<String, Object> hmMPSInputFraud = CommonUtil.getHashMap();
                hmMPSInputFraud.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);

                if (alUserFraudLock != null && !alUserFraudLock.isEmpty()) {
                    hmMPSInputFraud.put(MPSDefs.DB_USERFRAUDLOCK, alUserFraudLock);
                }
                if (alAccountFraudLock != null && !alAccountFraudLock.isEmpty()) {
                    hmMPSInputFraud.put(MPSDefs.DB_ACCOUNTFRAUDLOCK, alAccountFraudLock);
                }

                logger.info("{}{UMDH.PD.15 : {}:{}", sClassName, sThisMethod,
                        "Calling FraudLockDBHelper.processData () with input = ", hmMPSInputFraud);
                hmResult = fraudLockDBHelper.processData(hmMPSInputFraud);

                logger.info("{}{}UMDH.PD.16 : {}:{}", sClassName, sThisMethod,
                        "Response from FraudLockDBHelper.processData () ", hmResult);

                HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                        "FraudLockDBHelper.processData() call is returning null or Empty Hash");
                if (result != null) return result;

                if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                        "FraudLockDBHelper.processData() call failed.")) {
                    return hmResult;
                }
            }

            //1808:PID 304635: Update MergeSLIDProfile API to transfer fraud passwords if present in TMEMBERFRAUDPASSWORD table from fromSLID to toSLID

            if (hmMemberFraudPassword != null && !hmMemberFraudPassword.isEmpty()) {
                String stOperation = (String) hmMemberFraudPassword.get(MPSDefs.DB_OPERATION);

                if (stOperation != null && stOperation.equals(MPSDefs.DB_OPERATION_UPDATE)) {
                    logger.info("{}{}UMDH.PD.19 : {}:{}", sClassName, sThisMethod,
                            "Calling MemberFraudPasswordDBHelper.mergeMemberFraudPwd () with input = ", hmMemberFraudPassword);


                    hmResult = memberFraudPasswordDBHelper.mergeMemberFraudPwd(hmMemberFraudPassword);

                    logger.info("{}{}UMDH.PD.20 : {}:{}", sClassName, sThisMethod,
                            "Response from MemberFraudPasswordDBHelper.mergeMemberFraudPwd () ", hmResult);

                } else if (stOperation != null && stOperation.equals(MPSDefs.DB_OPERATION_INSERT)) {

                    logger.info("{}{}UMDH.PD.21 : {}:{}", sClassName, sThisMethod,
                            "Calling MemberFraudPasswordDBHelper.addMemberFraudPwd () with input = ", hmMemberFraudPassword);

                    hmResult = memberFraudPasswordDBHelper.addMemberFraudPwd(hmMemberFraudPassword);

                    logger.info("{}{}UMDH.PD.22 : {}:{}", sClassName, sThisMethod,
                            "Response from MemberFraudPasswordDBHelper.addMemberFraudPwd () ", hmResult);
                } else if (stOperation != null && stOperation.equals(MPSDefs.DB_OPERATION_DELETE)) {

                    logger.info("{}{}UMDH.PD.23 : {}:{}", sClassName, sThisMethod,
                            "Calling MemberFraudPasswordDBHelper.deleteMemberFraudPwd () with input = ", hmMemberFraudPassword);

                    hmResult = memberFraudPasswordDBHelper.deleteMemberFraudPwd(hmMemberFraudPassword);

                    logger.info("{}{}UMDH.PD.24 : {}:{}", sClassName, sThisMethod,
                            "Response from MemberFraudPasswordDBHelper.deleteMemberFraudPwd () ", hmResult);
                }

                HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                        "MemberFraudPasswordDBHelper is returning null or Empty Hash");
                if (result != null) return result;

                if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                        "MemberFraudPasswordDBHelper call failed.")) {
                    return hmResult;
                }
            }
            //[R2004] : Changes for PID#323487a (HBO Max)
            if (hmUserMerge != null && !hmUserMerge.isEmpty()) {
                String stOperation = (String) hmUserMerge.get(MPSDefs.DB_OPERATION);

                if (stOperation != null && stOperation.equals(MPSDefs.DB_OPERATION_INSERT)) {

                    logger.info("{}{}UMDH.PD.27 : {}:{}", sClassName, sThisMethod,
                            "Calling UserMergeDBHelper.insertUserMergeDetails () with input = ", hmUserMerge);

                    hmResult = userMergeDBHelper.insertUserMergeDetails(hmUserMerge); //addUserMerge legacy

                    logger.info("{}{}UMDH.PD.28 : {}:{}", sClassName, sThisMethod,
                            "Response from UserMergeDBHelper.insertUserMergeDetails () ", hmResult);
                }

                HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                        "UserMergeDBHelper.insertUserMergeDetails is returning null or Empty Hash");
                if (result != null) return result;

                if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                        "UserMergeDBHelper.insertUserMergeDetails call failed.")) {
                    return hmResult;
                }
            }

            if (alAccountlockout != null && !alAccountlockout.isEmpty()) {

                HashMap<String, Object> hmLockoutInp = CommonUtil.getHashMap();
                hmLockoutInp.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                hmLockoutInp.put(CommonDefs.TRANSACTION_ID, sTransactionId);
                hmLockoutInp.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
                hmLockoutInp.put(MPSDefs.DB_ACCOUNTLOCKOUT, alAccountlockout);

                logger.info("{}{}UMDH.PD.31 : {}{}", sClassName, sThisMethod,
                        "Calling AccountLockoutDBHelper.processData () with input = ", hmUserMerge);

                hmResult = accountLockoutDBHelper.processData(hmLockoutInp, logger);

                logger.info("{}{}UMDH.PD.32 : {}:{}", sClassName, sThisMethod,
                        "Response from AccountLockoutDBHelper.processData () ", hmResult);

                HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                        "AccountLockoutDBHelper.processData() call is returning null or Empty Hash");
                if (result != null) return result;

                if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                        "AccountLockoutDBHelper.processData() call failed.")) {
                    return hmResult;
                }
            }

            // Added add/update/delete services from TMEMBERSERVICE
            if (alMemberService != null && !alMemberService.isEmpty()) {
                java.util.Iterator alMemberServiceItr = alMemberService.iterator();
                while (alMemberServiceItr.hasNext()) {
                    HashMap<String, Object> hmInpMemberService = (HashMap<String, Object>) alMemberServiceItr.next();
                    if (hmInpMemberService != null && !hmInpMemberService.isEmpty()) {
                        sOperation = (String) hmInpMemberService.get(MPSDefs.DB_OPERATION);

                        hmInpMemberService.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);
                        hmInpMemberService.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                        hmInpMemberService.put(CommonDefs.TRANSACTION_ID, sTransactionId);
                        hmInpMemberService.put(CommonDefs.TRANSACTION_NAME, sTransactionName);

                        if (sOperation != null && sOperation.equals(MPSDefs.DB_OPERATION_INSERT)) {
                            logger.info("{}{}UMDH.PD.35 : {}:{}", sClassName, sThisMethod,
                                    "Calling AddServiceDBHelper.addService () with input = ", hmInpMemberService);

                            hmResult = addServiceDBHelper.addService(hmInpMemberService);
                            logger.info("{}{}UMDH.PD.36 : {}:{}", sClassName, sThisMethod,
                                    "Response from AddServiceDBHelper.addService () ", hmResult);

                        } else if (sOperation != null && sOperation.equals(MPSDefs.DB_OPERATION_UPDATE)) {
                            if (hmInpMemberService.containsKey("updateByInstanceId")
                                    && hmInpMemberService.get("updateByInstanceId").equals("Y")) {

                                logger.info("{}{}UMDH.PD.37 : {}:{}", sClassName, sThisMethod,
                                        "Calling UpdateServiceDBHelper.updateMemberServiceInstanceId () with input = ", hmInpMemberService);

                                hmResult = updateServiceDBHelper.updateMemberServiceInstanceId(hmInpMemberService);

                                logger.info("{}{}UMDH.PD.38 : {}:{}", sClassName, sThisMethod,
                                        "Response from updateMemberServiceInstanceId.updateMemberServiceInstanceId () ", hmResult);
                            }
                            // 1512 : US501601 : added to update sor_invariant_id for calls coming from Atlas
                            else if (hmInpMemberService
                                    .containsKey(CommonDefs.KEY_UPDATE_MEMBER_SERVICE_SOR_INVARIANT_ID)
                                    && hmInpMemberService.get(CommonDefs.KEY_UPDATE_MEMBER_SERVICE_SOR_INVARIANT_ID)
                                    .equals(MPSDefs.YES)) {

                                logger.info("{}{}UMDH.PD.39 : {}{}", sClassName, sThisMethod,
                                        "Calling updateServiceDBHelper.updateMemberServiceSorInvId() with input = ", hmInpMemberService);

                                hmResult = updateServiceDBHelper.updateMemberServiceSorInvId(hmInpMemberService);

                                logger.info("{}{}UMDH.PD.40 : {}{}", sClassName, sThisMethod,
                                        "Response from updateServiceDBHelper.updateMemberServiceSorInvId(),hmResult :: ", hmResult);
                            } else {

                                logger.info("{}{}UMDH.PD.41 : {}{}", sClassName, sThisMethod,
                                        "Calling UpdateServiceDBHelper.addService () with input = ",
                                        hmInpMemberService);

                                hmResult = updateServiceDBHelper.updateService(hmInpMemberService);

                                logger.info("{}{}UMDH.PD.42 : {}{}", sClassName, sThisMethod,
                                        "Response from UpdateServiceDBHelper.updateService () ", hmResult);
                            }
                        } else if (sOperation != null && sOperation.equals(MPSDefs.DB_OPERATION_DELETE)) {
                            logger.info("{}{}UMDH.PD.43 : {}:{}", sClassName, sThisMethod,
                                    "Calling UpdateServiceDBHelper.removeService () with input = ", hmInpMemberService);

                            hmResult = updateServiceDBHelper.removeService(hmInpMemberService);

                            logger.info("{}{}UMDH.PD.44 : {}:{}", sClassName, sThisMethod,
                                    "Response from UpdateServiceDBHelper.removeService () ", hmResult);
                        }

                        HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                                "UpdateServiceDBHelper.removeService() call is returning null or Empty Hash");
                        if (result != null) return result;

                        if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                                "UpdateServiceDBHelper.removeService() call failed.")) {
                            return hmResult;
                        }
                    }
                }

            }
            //Added for October2010 - [End]
            if (alMemberGroup != null && !alMemberGroup.isEmpty()) {

                java.util.Iterator alMemberGrpItr = alMemberGroup.iterator();
                while (alMemberGrpItr.hasNext()) {

                    HashMap hmInpMemberGrp = (HashMap) alMemberGrpItr.next();
                    if (hmInpMemberGrp != null && !hmInpMemberGrp.isEmpty()) {

                        hmInpMemberGrp.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                        hmInpMemberGrp.put(CommonDefs.TRANSACTION_ID, sTransactionId);
                        hmInpMemberGrp.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
                        hmInpMemberGrp.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);

                        logger.info("{}{}UMDH.PD.47 : {}:{}", sClassName, sThisMethod,
                                "Calling updateDBHelper.updateMemberGroup () with input = ", hmUserMerge);

                        hmResult = updateDBHelper.updateMemberGroup(hmInpMemberGrp);

                        logger.info("{}{}UMDH.PD.48 : {}:{}", sClassName, sThisMethod,
                                "Response from updateDBHelper.updateMemberGroup () ", hmResult);

                        HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                                "updateDBHelper.updateMemberGroup() call is returning null or Empty Hash");
                        if (result != null) return result;

                        if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                                "updateDBHelper.updateMemberGroup() call failed.")) {
                            return hmResult;
                        }
                    }
                }

            }
            if (hmUpdateServiceContact != null && !hmUpdateServiceContact.isEmpty()) {

                hmResult = serviceContactDBHelper.updateServiceContact(hmUpdateServiceContact);

                HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                        "serviceContactDBHelper.updateServiceContact() call is returning null or Empty Hash");
                if (result != null) return result;

                if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                        "serviceContactDBHelper.updateServiceContact() call failed.")) {
                    return hmResult;
                }
            }
            //Added for June2011 - [Start]
            if (alMemberservicerole != null && !alMemberservicerole.isEmpty()) {

                ArrayList alUpdateRoleStatus = CommonUtil.getArrayList();
                ArrayList alUpdateRoleId = CommonUtil.getArrayList();
                ArrayList alDeleteRole = CommonUtil.getArrayList();
                ArrayList alAddRoles = CommonUtil.getArrayList();
                ArrayList alUpdateRoleSorInvariantId = CommonUtil.getArrayList();


                HashMap hmUpdateRoleStatus = null;
                HashMap hmUpdateRoleId = null;
                HashMap hmDeleteRole = null;
                HashMap hmAddRole = null;
                HashMap hmMemberservicerole = null;
                HashMap hmUpdateRoleSorInvariantId = null;

                //String sOperation = null;

                java.util.Iterator alMemberservroleItr = alMemberservicerole.iterator();
                while (alMemberservroleItr.hasNext()) {
                    hmMemberservicerole = (HashMap) alMemberservroleItr.next();
                    if (hmMemberservicerole != null && !hmMemberservicerole.isEmpty()) {

                        sOperation = (String) hmMemberservicerole.get(MPSDefs.DB_OPERATION);
                        //Put this.sTransactionId,this.sCallingSystemId,this.sTransactionName in hmMemberservicerole
                        //hmMemberservicerole.put(CommonDefs.TRANSACTION_ID, this.sTransactionId);
                        hmMemberservicerole.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                        //hmMemberservicerole.put(CommonDefs.TRANSACTION_NAME, this.sTransactionName);

                        if (sOperation != null && sOperation.equals(CommonDefs.KEY_UPDATE_ROLE_STATUS)) {
                            //Put hmMemberservicerole in alUpdateRoleStatus
                            //alUpdateRoleStatus = CommonUtil.getArrayList();
                            alUpdateRoleStatus.add(hmMemberservicerole);
                        }

                        if (sOperation != null && sOperation.equals(CommonDefs.KEY_UPDATE_ROLE_ID)) {
                            //Put hmMemberservicerole in alUpdateRoleId
                            //alUpdateRoleId = CommonUtil.getArrayList();
                            alUpdateRoleId.add(hmMemberservicerole);
                        }

                        if (sOperation != null && sOperation.equals(MPSDefs.KEY_DELETE_ROLE)) {
                            //Put hmMemberservicerole in alUpdateMemberservicerole
                            //alDeleteRole = CommonUtil.getArrayList();
                            alDeleteRole.add(hmMemberservicerole);
                        }

                        if (sOperation != null && sOperation.equals(MPSDefs.DB_OPERATION_INSERT)) {
                            //Put hmMemberservicerole in alAddRoles
                            //alAddRoles = CommonUtil.getArrayList();
                            alAddRoles.add(hmMemberservicerole);
                        }

                        if (sOperation != null && sOperation.equals(CommonDefs.KEY_UPDATE_SOR_INVARIANT_ID_FOR_ROLE)) {
                            alUpdateRoleSorInvariantId.add(hmMemberservicerole);
                        }
                    }
                } //end of while


                if (alUpdateRoleStatus != null && !alUpdateRoleStatus.isEmpty()) {

                    hmUpdateRoleStatus = CommonUtil.getHashMap();
                    //Put TransactionName,TransactionId & CallingSystemId with DB Helper keys in hmAdd
                    hmUpdateRoleStatus.put(MPSDefs.WS_TRANSACTION_ID, sTransactionId);
                    hmUpdateRoleStatus.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                    hmUpdateRoleStatus.put(MPSDefs.WS_TRANSACTION_NAME, sTransactionName);
                    hmUpdateRoleStatus.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);

                    //Put alUpdateRoleStatus in hmUpdateRoleStatus with key updateRoleStatus
                    hmUpdateRoleStatus.put(CommonDefs.KEY_UPDATE_ROLE_STATUS, alUpdateRoleStatus);

                    //call MPSDB_UpdateRole_H.updateRoleStatus()
                    logger.info("{}{}UMDH.PD.53 : {}:{}", sClassName, sThisMethod,
                            "Calling rolesDBHelper.updateRoleStatus () with input = ", hmUpdateRoleStatus);

                    hmResult = rolesDBHelper.updateRoleStatus(hmUpdateRoleStatus);

                    logger.info("{}{}UMDH.PD.54 : {}:{}", sClassName, sThisMethod,
                            "Response from rolesDBHelper.updateRoleStatus () ", hmResult);

                    HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                            "rolesDBHelper.updateRoleStatus() call is returning null or Empty Hash");
                    if (result != null) return result;

                    if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                            "rolesDBHelper.updateRoleStatus() call failed.")) {
                        return hmResult;
                    }
                }


                if (alUpdateRoleId != null && !alUpdateRoleId.isEmpty()) {

                    hmUpdateRoleId = CommonUtil.getHashMap();
                    //Put TransactionName,TransactionId & CallingSystemId with DB Helper keys in hmAdd
                    hmUpdateRoleId.put(MPSDefs.WS_TRANSACTION_ID, sTransactionId);
                    hmUpdateRoleId.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                    hmUpdateRoleId.put(MPSDefs.WS_TRANSACTION_NAME, sTransactionName);
                    hmUpdateRoleId.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);

                    //Put alUpdateRoleId in hmUpdateRoleId with key updateRoleId
                    hmUpdateRoleId.put(CommonDefs.KEY_UPDATE_ROLE_ID, alUpdateRoleId);

                    //call MPSDB_UpdateRole_H.updateRoleID()
                    logger.info("{}{}UMDH.PD.57 : {}:{}", sClassName, sThisMethod,
                            "Calling rolesDBHelper.updateRoleID () with input = ", hmUpdateRoleId);

                    hmResult = rolesDBHelper.updateRoleID(hmUpdateRoleId);

                    logger.info("{}{}UMDH.PD.58 : {}:{}", sClassName, sThisMethod,
                            "Response from rolesDBHelper.updateRoleID () ", hmResult);

                    HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                            "rolesDBHelper.updateRoleID() call is returning null or Empty Hash");
                    if (result != null) return result;

                    if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                            "rolesDBHelper.updateRoleID() call failed.")) {
                        return hmResult;
                    }
                }


                if (alDeleteRole != null && !alDeleteRole.isEmpty()) {

                    hmDeleteRole = CommonUtil.getHashMap();
                    //Put TransactionName,TransactionId & CallingSystemId with DB Helper keys in hmAdd
                    hmDeleteRole.put(MPSDefs.WS_TRANSACTION_ID, sTransactionId);
                    hmDeleteRole.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                    hmDeleteRole.put(MPSDefs.WS_TRANSACTION_NAME, sTransactionName);
                    hmDeleteRole.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);

                    //Put alUpdateRoleId in hmDeleteRole with key deleteRole
                    hmDeleteRole.put(MPSDefs.KEY_DELETE_ROLE, alDeleteRole);

                    //call MPSDB_UpdateRole_H.deleteRole()
                    logger.info("{}{}UMDH.PD.61 : {}:{}", sClassName, sThisMethod,
                            "Calling rolesDBHelper.deleteRole () with input = ", hmDeleteRole);

                    hmResult = rolesDBHelper.deleteRole(hmDeleteRole);

                    logger.info("{}{}UMDH.PD.62 : {}:{}", sClassName, sThisMethod,
                            "Response from rolesDBHelper.deleteRole () ", hmResult);

                    HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                            "rolesDBHelper.deleteRole() call is returning null or Empty Hash");
                    if (result != null) return result;

                    if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                            "rolesDBHelper.deleteRole() call failed.")) {
                        return hmResult;
                    }
                } //end of deleteRole


                //process addRoles
                if (alAddRoles != null && !alAddRoles.isEmpty()) {
                    for (int m = 0; m < alAddRoles.size(); m++) {
                        hmAddRole = (HashMap) alAddRoles.get(m);

                        logger.info("{}{}UMDH.PD.65 : {}:{}", sClassName, sThisMethod,
                                "Calling rolesDBHelper.addRoles () with input = ", hmAddRole);

                        hmResult = rolesDBHelper.addRoles(hmAddRole);

                        logger.info("{}{}UMDH.PD.66 : {}:{}", sClassName, sThisMethod,
                                "Response from rolesDBHelper.addRoles () ", hmResult);

                        HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                                "rolesDBHelper.addRoles() call is returning null or Empty Hash");
                        if (result != null) return result;

                        if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                                "MPSDB_Roles_H.addRoles() call failed.")) {
                            return hmResult;
                        }
                    }
                }//end of addRoles


                // 1512 : US501601 : Update sor_invariant_id for member in memberServiceRole table.
                if (alUpdateRoleSorInvariantId != null && !alUpdateRoleSorInvariantId.isEmpty()) {

                    hmUpdateRoleSorInvariantId = CommonUtil.getHashMap();
                    hmUpdateRoleSorInvariantId.put(CommonDefs.TRANSACTION_ID, sTransactionId);
                    hmUpdateRoleSorInvariantId.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                    hmUpdateRoleSorInvariantId.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
                    hmUpdateRoleSorInvariantId.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);

                    //Put alUpdateRoleStatus in hmUpdateRoleStatus with key updateRoleStatus
                    hmUpdateRoleSorInvariantId.put(CommonDefs.KEY_UPDATE_SOR_INVARIANT_ID_FOR_ROLE, alUpdateRoleSorInvariantId);

                    //call MPSDB_UpdateRole_H.updateRoleStatus()
                    logger.info("{}{}UMDH.PD.69 : {}:{}", sClassName, sThisMethod,
                            "Calling UpdateServiceDBHelper.updateSorInvIdForRole () with input = ", hmUpdateRoleSorInvariantId);

                    hmResult = rolesDBHelper.updateSorInvIdForRole(hmUpdateRoleSorInvariantId);

                    logger.info("{}{}UMDH.PD.70 : {}:{}", sClassName, sThisMethod,
                            "Response from AccountLockoutDBHelper.updateSorInvIdForRole () ", hmResult);

                    HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                            "MPSDB_UpdateRole_H.updateSorInvIdForRole() call is returning null or Empty Hash");
                    if (result != null) return result;

                    if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                            "MPSDB_UpdateRole_H.updateSorInvIdForRole() call failed.")) {
                        return hmResult;
                    }
                }

            }// end of iteration over alMemberservicerole

            if (alServicecontact != null && !alServicecontact.isEmpty()) {

                ArrayList alUpdateServiceContact = CommonUtil.getArrayList();
                ArrayList alRemoveServiceContact = CommonUtil.getArrayList();
                ArrayList alAddServiceContact = CommonUtil.getArrayList();

                HashMap hmAddServiceContact = null;
                HashMap hmUpdateServiceCon = null;
                HashMap hmRemoveServiceContact = null;
                HashMap hmServiceContact = null;

                //String sOperation = null;

                java.util.Iterator alServicecontactItr = alServicecontact.iterator();
                while (alServicecontactItr.hasNext()) {
                    hmServiceContact = (HashMap) alServicecontactItr.next();
                    if (hmServiceContact != null && !hmServiceContact.isEmpty()) {

                        sOperation = (String) hmServiceContact.get(MPSDefs.DB_OPERATION);
                        //Put this.sTransactionId,this.sCallingSystemId,this.sTransactionName in hmServiceContact
                        //hmServiceContact.put(CommonDefs.TRANSACTION_ID, this.sTransactionId);
                        hmServiceContact.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                        //hmServiceContact.put(CommonDefs.TRANSACTION_NAME, this.sTransactionName);

                        if (sOperation != null && sOperation.equals(MPSDefs.DB_OPERATION_INSERT)) {
                            //Put hmServiceContact in alAddServiceContact
                            //alAddServiceContact = CommonUtil.getArrayList();
                            alAddServiceContact.add(hmServiceContact);
                        }

                        if (sOperation != null && sOperation.equals(MPSDefs.DB_OPERATION_DELETE)) {
                            //Put hmServiceContact in alRemoveServiceContact
                            //alRemoveServiceContact = CommonUtil.getArrayList();
                            alRemoveServiceContact.add(hmServiceContact);
                        }

                        if (sOperation != null && sOperation.equals(MPSDefs.DB_OPERATION_UPDATE)) {
                            //Put hmServiceContact in alUpdateServiceContact
                            //alUpdateServiceContact = CommonUtil.getArrayList();
                            alUpdateServiceContact.add(hmServiceContact);
                        }

                    }
                }

                if (alAddServiceContact != null && !alAddServiceContact.isEmpty()) {

                    hmAddServiceContact = CommonUtil.getHashMap();
                    //Put TransactionName,TransactionId & CallingSystemId with DB Helper keys in hmAdd
                    hmAddServiceContact.put(MPSDefs.WS_TRANSACTION_ID, sTransactionId);
                    hmAddServiceContact.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                    hmAddServiceContact.put(MPSDefs.WS_TRANSACTION_NAME, sTransactionName);
                    hmAddServiceContact.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);

                    //Put alAddServiceContact in hmAdd with key servicecontact
                    hmAddServiceContact.put(CommonDefs.SERVICE_CONTACT, alAddServiceContact);

                    //call MPSDB_ServiceContact_H.addServiceContact()
                    logger.info("{}{}UMDH.PD.73 : {}:{}", sClassName, sThisMethod,
                            "Calling MPSDB_ServiceContact_H.addServiceContact () with input = ", hmAddServiceContact);

                    hmResult = serviceContactDBHelper.addServiceContact(hmAddServiceContact);

                    logger.info("{}{}UMDH.PD.74 : {}:{}", sClassName, sThisMethod,
                            "Response from serviceContactDBHelper.addServiceContact () ", hmResult);

                    HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                            "MPSDB_ServiceContact_H.addServiceContact() call is returning null or Empty Hash");
                    if (result != null) return result;

                    if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                            "MPSDB_ServiceContact_H.addServiceContact() call failed.")) {
                        return hmResult;
                    }
                }


                if (alUpdateServiceContact != null && !alUpdateServiceContact.isEmpty()) {

                    hmUpdateServiceCon = CommonUtil.getHashMap();
                    //Put TransactionName,TransactionId & CallingSystemId with DB Helper keys in hmUpdate
                    hmUpdateServiceCon.put(MPSDefs.WS_TRANSACTION_ID, sTransactionId);
                    hmUpdateServiceCon.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                    hmUpdateServiceCon.put(MPSDefs.WS_TRANSACTION_NAME, sTransactionName);
                    hmUpdateServiceCon.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);

                    //Put alUpdateServiceContact  in hmAdd with key servicecontact
                    hmUpdateServiceCon.put(CommonDefs.SERVICE_CONTACT, alUpdateServiceContact);

                    //call MPSDB_ServiceContact_H.updateServiceContact()
                    logger.info("{}{}UMDH.PD.77 : {}:{}", sClassName, sThisMethod,
                            "Calling UpdateServiceDBHelper.updateServiceContact () with input = ", hmAddServiceContact);

                    hmResult = serviceContactDBHelper.updateServiceContact(hmUpdateServiceCon);

                    logger.info("{}{}UMDH.PD.78 : {}:{}", sClassName, sThisMethod,
                            "Response from serviceContactDBHelper.updateServiceContact () ", hmResult);

                    HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                            "UpdateServiceDBHelper.updateServiceContact() call is returning null or Empty Hash");
                    if (result != null) return result;

                    if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                            "UpdateServiceDBHelper.updateServiceContact() call failed.")) {
                        return hmResult;
                    }
                }


                if (alRemoveServiceContact != null && !alRemoveServiceContact.isEmpty()) {

                    hmRemoveServiceContact = CommonUtil.getHashMap();
                    //Put TransactionName,TransactionId & CallingSystemId with DB Helper keys in hmUpdate
                    hmRemoveServiceContact.put(MPSDefs.WS_TRANSACTION_ID, sTransactionId);
                    hmRemoveServiceContact.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                    hmRemoveServiceContact.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
                    hmRemoveServiceContact.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);

                    //Put alUpdateServiceContact  in hmAdd with key servicecontact
                    hmRemoveServiceContact.put(CommonDefs.SERVICE_CONTACT, alRemoveServiceContact);

                    //call MPSDB_ServiceContact_H.removeServiceContact()
                    logger.info("{}{}UMDH.PD.81 : {}:{}", sClassName, sThisMethod,
                            "Calling UpdateServiceDBHelper.removeService () with input = ", hmAddServiceContact);

                    hmResult = serviceContactDBHelper.removeServiceContact(hmRemoveServiceContact);

                    logger.info("{}{}UMDH.PD.82 : {}:{}", sClassName, sThisMethod,
                            "Response from removeServiceContact.processData () ", hmResult);

                    HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                            "MPSDB_ServiceContact_H.removeServiceContact() call is returning null or Empty Hash");
                    if (result != null) return result;

                    if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                            "MPSDB_ServiceContact_H.removeServiceContact() call failed.")) {
                        return hmResult;
                    }
                }

            } // end of iteration over alServicecontact

            if (alWirelineuser != null && !alWirelineuser.isEmpty()) {

                ArrayList alAddWirelineUser = null;
                //ArrayList alUpdateWirelineUser = CommonUtil.getArrayList();   //need to check
                //ArrayList alDeleteWirelineUser = CommonUtil.getArrayList();

                HashMap hmAddWirelineUser = null;
                HashMap hmWirelineuser = null;

                //String sOperation = null;
                String sMembernum = null;

                java.util.Iterator alWirelineuserItr = alWirelineuser.iterator();
                while (alWirelineuserItr.hasNext()) {

                    hmWirelineuser = (HashMap) alWirelineuserItr.next();
                    if (hmWirelineuser != null && !hmWirelineuser.isEmpty()) {
                        //Retrieve operation type
                        sOperation = (String) hmWirelineuser.get(MPSDefs.DB_OPERATION);
                        sMembernum = (String) hmWirelineuser.get(MPSDefs.DB_MEMBER_NUM);

                        //hmWirelineuser.put(MPSDefs.WS_TRANSACTION_ID, this.sTransactionId);
                        hmWirelineuser.put(MPSDefs.WS_CALLING_SYSTEM_ID, sCallingSystemId);
                        //hmWirelineuser.put(MPSDefs.WS_TRANSACTION_NAME, this.sTransactionName);
                        //hmWirelineuser.put(MPSDefs.DB_LAST_MODIFIED_BY, this.sCallingSystemId);

                        if (sOperation != null && sOperation.equals(MPSDefs.DB_OPERATION_INSERT)) {

                            alAddWirelineUser = CommonUtil.getArrayList();
                            alAddWirelineUser.add(hmWirelineuser);

                            hmAddWirelineUser = CommonUtil.getHashMap();
                            hmAddWirelineUser.put(MPSDefs.WS_TRANSACTION_ID, sTransactionId);
                            hmAddWirelineUser.put(MPSDefs.WS_CALLING_SYSTEM_ID, sCallingSystemId);
                            hmAddWirelineUser.put(MPSDefs.WS_TRANSACTION_NAME, sTransactionName);
                            hmAddWirelineUser.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);
                            hmAddWirelineUser.put(MPSDefs.DB_MEMBER_NUM, sMembernum);

                            hmAddWirelineUser.put(MPSDefs.DB_WIRELINEUSER, alAddWirelineUser);

                            //call MPSDB_WirelineUser_H.addWirelineUser()
                            logger.info("{}{}UMDH.PD.85 : {}:{}", sClassName, sThisMethod,
                                    "Calling UpdateServiceDBHelper.removeService () with input = ", hmAddWirelineUser);

                            // hmResult = MPSDB_WirelineUser_H.addWirelineUser(hmAddWirelineUser);

                            logger.info("{}{}UMDH.PD.86 : {}:{}", sClassName, sThisMethod,
                                    "Response from MPSDB_WirelineUser_H.addWirelineUser () ", hmResult);

                            HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                                    "MPSDB_WirelineUser_H.addWirelineUser() call is returning null or Empty Hash");
                            if (result != null) return result;

                            if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                                    "MPSDB_WirelineUser_H.addWirelineUser() call failed.")) {
                                return hmResult;
                            }
                        } else if (sOperation != null && sOperation.equals(MPSDefs.DB_OPERATION_UPDATE)) {

                            //call MPSDB_WirelineUser_H.updateWirelineUser()
                            logger.info("{}{}UMDH.PD.89 : {}:{}", sClassName, sThisMethod,
                                    "Calling UpdateServiceDBHelper.removeService () with input = ", hmWirelineuser);

                            ///MPSDB_WirelineUser_H WirelineUser_H = callMPSDB_WirelineUser_H();
                            //hmResult = WirelineUser_H.updateWirelineUser(hmWirelineuser);

                            logger.info("{}{}UMDH.PD.90 : {}:{}", sClassName, sThisMethod,
                                    "Response from WirelineUser_H.updateWirelineUser () ", hmResult);

                            HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                                    "MPSDB_WirelineUser_H.updateWirelineUser() call is returning null or Empty Hash");
                            if (result != null) return result;

                            if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                                    "MPSDB_WirelineUser_H.updateWirelineUser() call failed.")) {
                                return hmResult;
                            }
                        } else if (sOperation != null && sOperation.equals(MPSDefs.DB_OPERATION_DELETE)) {

                            //call MPSDB_WirelineUser_H.removeWirelineUser()
                            logger.info("{}{}UMDH.PD.93 : {}:{}", sClassName, sThisMethod,
                                    "Calling UpdateServiceDBHelper.removeService () with input = ", hmWirelineuser);

                            //	MPSDB_WirelineUser_H WirelineUser_H = callMPSDB_WirelineUser_H();
                            //	hmResult = WirelineUser_H.removeWirelineUser(hmWirelineuser);
                            logger.info("{}{}UMDH.PD.94 : {}:{}", sClassName, sThisMethod,
                                    "Response from WirelineUser_H.removeWirelineUser () ", hmResult);

                            HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                                    "MPSDB_WirelineUser_H.removeWirelineUser() call is returning null or Empty Hash");
                            if (result != null) return result;

                            if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                                    "MPSDB_WirelineUser_H.removeWirelineUser() call failed.")) {
                                return hmResult;
                            }
                        }
                    }
                }
            } // end of iteration over alWirelineuser

            if (alServicenotification != null && !alServicenotification.isEmpty()) {

                ArrayList alAddServiceNotification = CommonUtil.getArrayList();
                ArrayList alUpdateServiceNotification = CommonUtil.getArrayList();
                ArrayList alRemoveServiceNotification = CommonUtil.getArrayList();

                HashMap hmAddServiceNotification = null;
                HashMap hmUpdateServiceNotification = null;
                HashMap hmRemoveServiceNotification = null;

                HashMap hmServicenotification = null;

                //String sOperation = null;

                java.util.Iterator alServicenotificationItr = alServicenotification.iterator();
                while (alServicenotificationItr.hasNext()) {
                    hmServicenotification = (HashMap) alServicenotificationItr.next();
                    if (hmServicenotification != null && !hmServicenotification.isEmpty()) {

                        sOperation = (String) hmServicenotification.get(MPSDefs.DB_OPERATION);
                        //Put this.sTransactionId,this.sCallingSystemId,this.sTransactionName in hmServicenotification
                        //hmServicenotification.put(CommonDefs.TRANSACTION_ID, this.sTransactionId);
                        hmServicenotification.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                        //hmServicenotification.put(CommonDefs.TRANSACTION_NAME, this.sTransactionName);

                        if (sOperation != null && sOperation.equals(MPSDefs.DB_OPERATION_INSERT)) {
                            //Put hmServicenotification in alAddServiceNotification
                            //alAddServiceNotification = CommonUtil.getArrayList();
                            alAddServiceNotification.add(hmServicenotification);
                        }

                        if (sOperation != null && sOperation.equals(MPSDefs.DB_OPERATION_DELETE)) {
                            //Put hmServicenotification in alRemoveServiceNotification
                            //alRemoveServiceNotification = CommonUtil.getArrayList();
                            alRemoveServiceNotification.add(hmServicenotification);
                        }

                        if (sOperation != null && sOperation.equals(MPSDefs.DB_OPERATION_UPDATE)) {
                            //Put hmServicenotification in alUpdateServiceNotification
                            //alUpdateServiceNotification = CommonUtil.getArrayList();
                            alUpdateServiceNotification.add(hmServicenotification);
                        }

                    }
                }

                if (alAddServiceNotification != null && !alAddServiceNotification.isEmpty()) {

                    hmAddServiceNotification = CommonUtil.getHashMap();
                    //Put TransactionName,TransactionId & CallingSystemId with DB Helper keys in hmAdd
                    hmAddServiceNotification.put(MPSDefs.WS_TRANSACTION_ID, sTransactionId);
                    hmAddServiceNotification.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                    hmAddServiceNotification.put(MPSDefs.WS_TRANSACTION_NAME, sTransactionName);
                    hmAddServiceNotification.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);

                    //Put alAddServiceNotification in hmAdd with key serviceNotification
                    hmAddServiceNotification.put(CommonDefs.KEY_SERVICE_NOTIFICATION, alAddServiceNotification);

                    //call MPSDB_ServiceNotification_H.addServiceNotification()
                    logger.info("{}{}UMDH.PD.97 : {}:{}", sClassName, sThisMethod,
                            "Calling ServiceNotificationDBHelper.addServiceNotification () with input = ", hmAddServiceNotification);
                    hmResult = serviceNotificationDBHelper.addServiceNotification(hmAddServiceNotification);

                    logger.info("{}{}UMDH.PD.98 : {}:{}", sClassName, sThisMethod,
                            "Response from ServiceNotificationDBHelper.addServiceNotification () ", hmResult);

                    HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                            "ServiceNotificationDBHelper.addServiceNotification() call is returning null or Empty Hash");
                    if (result != null) return result;

                    if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                            "ServiceNotificationDBHelper.addServiceNotification() call failed.")) {
                        return hmResult;
                    }
                }


                if (alUpdateServiceNotification != null && !alUpdateServiceNotification.isEmpty()) {

                    hmUpdateServiceNotification = CommonUtil.getHashMap();
                    //Put TransactionName,TransactionId & CallingSystemId with DB Helper keys in hmUpdate
                    hmUpdateServiceNotification.put(MPSDefs.WS_TRANSACTION_ID, sTransactionId);
                    hmUpdateServiceNotification.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                    hmUpdateServiceNotification.put(MPSDefs.WS_TRANSACTION_NAME, sTransactionName);
                    hmUpdateServiceNotification.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);

                    //Put alUpdateServiceNotification  in hmAdd with key serviceNotification
                    hmUpdateServiceNotification.put(CommonDefs.KEY_SERVICE_NOTIFICATION, alUpdateServiceNotification);

                    //call MPSDB_ServiceNotification_H.updateServiceNotification()
                    logger.info("{}{}UMDH.PD.101 : {}:{}", sClassName, sThisMethod,
                            "Calling ServiceNotificationDBHelper.updateServiceNotification () with input = ", hmUpdateServiceNotification);
                    hmResult = serviceNotificationDBHelper.updateServiceNotification(hmUpdateServiceNotification);
                    logger.info("{}{}UMDH.PD.102 : {}:{}", sClassName, sThisMethod,
                            "Response from ServiceNotificationDBHelper.updateServiceNotification () ", hmResult);

                    HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                            "ServiceNotificationDBHelper.updateServiceNotification() call is returning null or Empty Hash");
                    if (result != null) return result;

                    if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                            "ServiceNotificationDBHelper.updateServiceNotification() call failed.")) {
                        return hmResult;
                    }
                }


                if (alRemoveServiceNotification != null && !alRemoveServiceNotification.isEmpty()) {

                    hmRemoveServiceNotification = CommonUtil.getHashMap();
                    //Put TransactionName,TransactionId & CallingSystemId with DB Helper keys in hmUpdate
                    hmRemoveServiceNotification.put(MPSDefs.WS_TRANSACTION_ID, sTransactionId);
                    hmRemoveServiceNotification.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                    hmRemoveServiceNotification.put(MPSDefs.WS_TRANSACTION_NAME, sTransactionName);
                    hmRemoveServiceNotification.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);

                    //Put alUpdateServiceContact  in hmAdd with key servicenotification
                    hmRemoveServiceNotification.put(CommonDefs.KEY_SERVICE_NOTIFICATION, alRemoveServiceNotification);

                    //call MPSDB_ServiceNotification_H.removeServiceNotification()
                    logger.info("{}{}UMDH.PD.105 : {}:{}", sClassName, sThisMethod,
                            "Calling ServiceNotificationDBHelper.removeServiceNotification () with input = ", hmRemoveServiceNotification);
                    hmResult = serviceNotificationDBHelper.removeServiceNotification(hmRemoveServiceNotification);

                    logger.info("{}{}UMDH.PD.106 : {}:{}", sClassName, sThisMethod,
                            "Response from ServiceNotificationDBHelper.removeServiceNotification () ", hmResult);

                    HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                            "ServiceNotificationDBHelper.removeServiceNotification() call is returning null or Empty Hash");
                    if (result != null) return result;

                    if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                            "ServiceNotificationDBHelper.removeServiceNotification() call failed.")) {
                        return hmResult;
                    }
                }

            } // end of iteration over alServicenotification

            if (alServiceinfo != null && !alServiceinfo.isEmpty()) {

                ArrayList alAddServiceInfo = CommonUtil.getArrayList();
                ArrayList alUpdateServiceInfo = CommonUtil.getArrayList();
                ArrayList alRemoveServiceInfo = CommonUtil.getArrayList();

                HashMap<String, Object> hmAddServiceInfo = null;
                HashMap<String, Object> hmUpdateServiceInfo = null;
                HashMap<String, Object> hmRemoveServiceInfo = null;

                HashMap<String, Object> hmServiceinfo = null;

                //String sOperation = null;

                java.util.Iterator alServiceinfoItr = alServiceinfo.iterator();
                while (alServiceinfoItr.hasNext()) {
                    hmServiceinfo = (HashMap) alServiceinfoItr.next();
                    if (hmServiceinfo != null && !hmServiceinfo.isEmpty()) {

                        sOperation = (String) hmServiceinfo.get(MPSDefs.DB_OPERATION);
                        //Put this.sTransactionId,this.sCallingSystemId,this.sTransactionName in hmMemberservicerole
                        //hmMemberservicerole.put(CommonDefs.TRANSACTION_ID, this.sTransactionId);
                        hmServiceinfo.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
                        //hmMemberservicerole.put(CommonDefs.TRANSACTION_NAME, this.sTransactionName);

                        if (sOperation != null && sOperation.equals(MPSDefs.DB_OPERATION_INSERT)) {
                            //Put hmServiceinfo in alAddServiceInfo
                            //alAddServiceInfo = CommonUtil.getArrayList();
                            alAddServiceInfo.add(hmServiceinfo);
                        }

                        if (sOperation != null && sOperation.equals(MPSDefs.DB_OPERATION_DELETE)) {
                            //Put hmServiceinfo in alRemoveServiceInfo
                            //alRemoveServiceInfo = CommonUtil.getArrayList();
                            alRemoveServiceInfo.add(hmServiceinfo);
                        }

                        if (sOperation != null && sOperation.equals(MPSDefs.DB_OPERATION_UPDATE)) {
                            //Put hmServiceinfo in alUpdateServiceInfo
                            //alUpdateServiceInfo = CommonUtil.getArrayList();
                            alUpdateServiceInfo.add(hmServiceinfo);
                        }

                    }
                }


                if (alAddServiceInfo != null && !alAddServiceInfo.isEmpty()) {

                    hmAddServiceInfo = CommonUtil.getHashMap();
                    //Put TransactionName,TransactionId & CallingSystemId with DB Helper keys in hmAdd
                    hmAddServiceInfo.put(MPSDefs.WS_TRANSACTION_ID, sTransactionId);
                    hmAddServiceInfo.put(MPSDefs.WS_CALLING_SYSTEM_ID, sCallingSystemId);
                    hmAddServiceInfo.put(MPSDefs.WS_TRANSACTION_NAME, sTransactionName);
                    hmAddServiceInfo.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);

                    //Put alAddServiceInfo in hmAdd with key serviceNotification
                    hmAddServiceInfo.put(MPSDefs.DB_SERVICEINFO, alAddServiceInfo);

                    //call MPSDB_ServiceInfo_H.addServiceInfo()
                    logger.info("{}{}UMDH.PD.109 : {}:{}", sClassName, sThisMethod,
                            "Calling ServiceInfoDBHelper.addServiceInfo () with input = ", hmAddServiceInfo);

                    hmResult = serviceInfoDBHelper.addServiceInfo(hmAddServiceInfo);

                    logger.info("{}{}UMDH.PD.110 : {}:{}", sClassName, sThisMethod,
                            "Response from ServiceInfoDBHelper.addServiceInfo () ", hmResult);

                    HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                            "ServiceInfoDBHelper.addServiceInfo() call is returning null or Empty Hash");
                    if (result != null) return result;

                    if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                            "ServiceInfoDBHelper.addServiceInfo() call failed.")) {
                        return hmResult;
                    }
                }


                if (alUpdateServiceInfo != null && !alUpdateServiceInfo.isEmpty()) {

                    hmUpdateServiceInfo = CommonUtil.getHashMap();
                    //Put TransactionName,TransactionId & CallingSystemId with DB Helper keys in hmUpdate
                    hmUpdateServiceInfo.put(MPSDefs.WS_TRANSACTION_ID, sTransactionId);
                    hmUpdateServiceInfo.put(MPSDefs.WS_CALLING_SYSTEM_ID, sCallingSystemId);
                    hmUpdateServiceInfo.put(MPSDefs.WS_TRANSACTION_NAME, sTransactionName);
                    hmUpdateServiceInfo.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);

                    //Put alUpdateServiceInfo  in hmUpdate with key serviceNotification
                    hmUpdateServiceInfo.put(MPSDefs.DB_SERVICEINFO, alUpdateServiceInfo);

                    //call MPSDB_ServiceInfo_H.updateServiceInfo()
                    logger.info("{}{}UMDH.PD.113 : {}:{}", sClassName, sThisMethod,
                            "Calling ServiceInfoDBHelper.updateServiceInfo () with input = ", hmUpdateServiceInfo);

                    hmResult = serviceInfoDBHelper.updateServiceInfo(hmUpdateServiceInfo);
                    logger.info("{}{}UMDH.PD.114 : {}:{}", sClassName, sThisMethod,
                            "Response from ServiceInfoDBHelper.processData () ", hmResult);

                    HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                            "ServiceInfoDBHelper.updateServiceInfo() call is returning null or Empty Hash");
                    if (result != null) return result;

                    if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                            "ServiceInfoDBHelper.updateServiceInfo() call failed.")) {
                        return hmResult;
                    }
                }


                if (alRemoveServiceInfo != null && !alRemoveServiceInfo.isEmpty()) {

                    hmRemoveServiceInfo = CommonUtil.getHashMap();
                    //Put TransactionName,TransactionId & CallingSystemId with DB Helper keys in hmUpdate
                    hmRemoveServiceInfo.put(MPSDefs.WS_TRANSACTION_ID, sTransactionId);
                    hmRemoveServiceInfo.put(MPSDefs.WS_CALLING_SYSTEM_ID, sCallingSystemId);
                    hmRemoveServiceInfo.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
                    hmRemoveServiceInfo.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);

                    //Put alRemoveServiceInfo  in hmRemove with key servicenotification
                    hmRemoveServiceInfo.put(MPSDefs.DB_SERVICEINFO, alRemoveServiceInfo);

                    //call MPSDB_ServiceInfo_H.removeServiceInfo()
                    logger.info("{}{}UMDH.PD.117 : {}:{}", sClassName, sThisMethod,
                            "Calling ServiceInfoDBHelper.removeServiceInfo () with input = ", hmRemoveServiceInfo);

                    hmResult = serviceInfoDBHelper.removeServiceInfo(hmRemoveServiceInfo);

                    logger.info("{}{}UMDH.PD.118 : {}:{}", sClassName, sThisMethod,
                            "Response from ServiceInfoDBHelper.removeServiceInfo () ", hmResult);

                    HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                            "ServiceInfoDBHelper.removeServiceInfo() call is returning null or Empty Hash");
                    if (result != null) return result;

                    if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                            "ServiceInfoDBHelper.removeServiceInfo() call failed.")) {
                        return hmResult;
                    }
                }
            } // end of iteration over alServiceinfo
            //need to check - processTitanizedMobilityLoyaltyInfo processDeTitanizedMobilityLoyaltyInfo
            //Added by hb1387 for FEB2011 -
            if (hmRemoveServices != null && !hmRemoveServices.isEmpty()) {
                logger.info("{}{}UMDH.PD.121 : {}:{}", sClassName, sThisMethod,
                        "Calling MemberServiceHelper.removeServices () with input = ", hmRemoveServices);
                //      hmResult=new MemberServiceHelper().removeServices(hmRemoveServices,configHelper,conn,minf); //need to check
                logger.info("{}{}UMDH.PD.121 : {}:{}", sClassName, sThisMethod,
                        "Response from MemberServiceHelper.removeServices () with input = ", hmRemoveServices);

                HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                        "MemberServiceHelper().removeServices call is returning null or Empty Hash");
                if (result != null) return result;

                if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                        "MemberServiceHelper().removeServices call failed.")) {
                    return hmResult;
                }
            } // end of RemoveServices

            if (alRemoveMobiltyDevcies != null && !alRemoveMobiltyDevcies.isEmpty()) {
                ListIterator objRemDevIte = alRemoveMobiltyDevcies.listIterator();
                while (objRemDevIte.hasNext()) {
                    HashMap hmRemMobDevice = (HashMap) objRemDevIte.next();
                    logger.info("{}{}UMDH.PD.121 : {}:{}", sClassName, sThisMethod,
                            "Calling UpdateServiceDBHelper.removeService () with input = ", hmRemMobDevice);
                    hmResult = oDeleteMemberDBHelper.deleteMobilityDevice(hmRemMobDevice);
                    logger.info("{}{}UMDH.PD.122 : {}:{}", sClassName, sThisMethod,
                            "Response from AccountLockoutDBHelper.processData () ", hmResult);

                    HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                            "MPSDB_Delete_H.deleteMobilityDevice call is returning null or Empty Hash");
                    if (result != null) return result;

                    if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                            "MPSDB_Delete_H.deleteMobilityDevice call failed.")) {
                        return hmResult;
                    }
                }// end of while
            }
            if (hmAddServices != null && !hmAddServices.isEmpty()) {
                logger.info("{}{}UMDH.PD.125 : {}:{}", sClassName, sThisMethod,
                        "Calling ServiceInfoDBHelper.removeServiceInfo () with input = ", hmAddServices);
                //	hmResult=new ServiceHelper().addServices(hmAddServices,configHelper,conn,minf);
                // hmResult=callAddAssociation(hmAddServices); //need to check
                logger.info("{}{}UMDH.PD.126 : {}:{}", sClassName, sThisMethod,
                        "Response from ServiceInfoDBHelper.removeServiceInfo () ", hmResult);

                HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                        "ServiceHelper().addServices call is returning null or Empty Hash");
                if (result != null) return result;

                if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                        "ServiceHelper().addServices call failed.")) {
                    return hmResult;
                }
            } // end of RemoveServices
            //Added by hb1387 for FEB2011 - [End]
            //Updated for June2011 - [End]
            //bCallG2 = false;
            //queryAndUpdateMergedYahooId
            //1806 : PID 292348 : Updates to support wireless SMB accounts
            if (alUpdateMemSvcAttrs != null && !alUpdateMemSvcAttrs.isEmpty()) {
                HashMap hmUpdateMemSvcAttr = null;
                Iterator alUpdateMemSvcAttrsItr = alUpdateMemSvcAttrs.iterator();
                while (alUpdateMemSvcAttrsItr.hasNext()) {
                    hmUpdateMemSvcAttr = (HashMap) alUpdateMemSvcAttrsItr.next();

                    if (hmUpdateMemSvcAttr != null && !hmUpdateMemSvcAttr.isEmpty()) {
                        logger.info("{}{}UMDH.PD.121 : {}:{}", sClassName, sThisMethod,
                                "Calling MemberServiceAttributeDBHelper.updateServiceAttribute () with input = ", hmUpdateMemSvcAttr);
                        memberServiceAttributeDBHelper.updateServiceAttribute(hmUpdateMemSvcAttr);
                        logger.info("{}{}UMDH.PD.121 : {}:{}", sClassName, sThisMethod,
                                "Calling MemberServiceAttributeDBHelper.updateServiceAttribute () with input = ", hmUpdateMemSvcAttr);

                        HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                                "MemberServiceAttributeDBHelper.updateServiceAttribute call is returning null or Empty Hash");
                        if (result != null) return result;

                        if (hasFailed(hmResult, CErrorDefs.COMMON_APP_STATUS_CODE,
                                "MemberServiceAttributeDBHelper.updateServiceAttribute call failed.")) {
                            return hmResult;
                        }
                    }
                }
            }
        } catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e);
            stAppInfo = "Exception thrown UpdateMemberHelper method : " + hmResult;
            logger.error("{}{}UEUH_UEU_34 :  {} ", sClassName, sThisMethod, stAppInfo);
            return hmResult;
        } finally {
            stAppInfo = "Response from UpdateMemberHelper = " + hmResult;
            logger.info("{}{}UEUH_UEU_35:  {} ", sClassName, sThisMethod, stAppInfo);

            logger.info("{}{}HLP999 : response from UpdateMemberHelper{} ", sClassName, sThisMethod, hmResult);
        }
        return hmResult;
    }

    private HashMap removeAccount(HashMap hmRemoveAccountRequest) {
        String thisMethod = "removeAccount";
        String stAppInfo = null;
        String stAppStatusCode = null;
        HashMap hmResult = null;

        logger.info("{}{}UMDH.RA.01 : {}", sClassName, thisMethod, "Inside removeAccount method of UpdateMemberDataBean");

        try {
            String stCallingSystemId = (String) hmRemoveAccountRequest.get(CommonDefs.CALLING_SYSTEM_ID);
            String stTransactionId = (String) hmRemoveAccountRequest.get(CommonDefs.TRANSACTION_ID);
            String stTransactionName = (String) hmRemoveAccountRequest.get(CommonDefs.TRANSACTION_NAME);

            ArrayList<String> alAccountsToBeUpdatedList = (ArrayList<String>) hmRemoveAccountRequest.get("accountsToBeUpdatedList");
            ArrayList<String> alAccountsToBeRemovedList = (ArrayList) hmRemoveAccountRequest.get("accountsToBeRemovedList");
            ArrayList<String> alRolesToBeAddedList = (ArrayList) hmRemoveAccountRequest.get("rolesToBeAddedList");
            ArrayList<String> alRolesToBeRemovedList = (ArrayList) hmRemoveAccountRequest.get("rolesToBeRemovedList");
            ArrayList<String> alAccountsToBeDeletedList = (ArrayList) hmRemoveAccountRequest.get("accountsToBeDeletedList");

            // Update accounts in DB
            if (alAccountsToBeUpdatedList != null && !alAccountsToBeUpdatedList.isEmpty()) {
                for (Object o : alAccountsToBeUpdatedList) {
                    HashMap hmAccountToBeUpdated = (HashMap) o;
                    if (hmAccountToBeUpdated != null && !hmAccountToBeUpdated.isEmpty()) {
                        HashMap<String, Object> hmUpdateService = CommonUtil.getHashMap();
                        // Retrieve account details
                        String stMemberNum = (String) hmAccountToBeUpdated.get(MPSDefs.DB_MEMBER_NUM);
                        String stServiceName = (String) hmAccountToBeUpdated.get(MPSDefs.DB_SERVICE_NAME);
                        String stInstanceId = (String) hmAccountToBeUpdated.get(MPSDefs.DB_INSTANCE_ID);
                        String stSorInvariantId = (String) hmAccountToBeUpdated.get(MPSDefs.DB_SOR_INVARIANT_ID);
                        String stDefaultAccount = (String) hmAccountToBeUpdated.get(MPSDefs.DB_DEFAULT_ACCOUNT);

                        hmUpdateService.put(MPSDefs.DB_MEMBER_NUM, stMemberNum);
                        hmUpdateService.put(MPSDefs.DB_SERVICE_NAME, stServiceName);
                        hmUpdateService.put(MPSDefs.DB_INSTANCE_ID, stInstanceId);
                        hmUpdateService.put(MPSDefs.DB_SOR_INVARIANT_ID, stSorInvariantId);
                        hmUpdateService.put(MPSDefs.DB_DEFAULT_ACCOUNT, stDefaultAccount);

                        hmResult = updateServiceDBHelper.updateService(hmUpdateService);

                        HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                                "Output Hash from MPSDB_Update_H.updateService() is NULL or EMPTY");
                        if (result != null) return result;

                        stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

                        if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                            stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG);
                            if (stAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
                                stAppStatusCode = CErrorDefs.ERR_REC_NOT_FOUND;
                            }
                            logger.info("{}{}UMDH.RA.03 : {}", sClassName, thisMethod, stAppInfo);
                            hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                            return hmResult;
                        }
                    }
                }
            } // End alAccountsToBeUpdatedList

            // Remove accounts from DB
            if (alAccountsToBeRemovedList != null && !alAccountsToBeRemovedList.isEmpty()) {
                Iterator itrAccountRemoved = alAccountsToBeRemovedList.iterator();

                while (itrAccountRemoved.hasNext()) {
                    HashMap<String, Object> hmAccountTobeRemoved = (HashMap<String, Object>) itrAccountRemoved.next();

                    if (hmAccountTobeRemoved != null && !hmAccountTobeRemoved.isEmpty()) {
                        HashMap<String, Object> hmDeleteMemberService = CommonUtil.getHashMap();

                        // Retrieve accounts details which is to be removed
                        String stMemberNum = (String) hmAccountTobeRemoved.get(MPSDefs.DB_MEMBER_NUM);
                        String stServiceName = (String) hmAccountTobeRemoved.get(MPSDefs.DB_SERVICE_NAME);
                        String stInstanceID = (String) hmAccountTobeRemoved.get(MPSDefs.DB_INSTANCE_ID);
                        String stSorInstanceId = (String) hmAccountTobeRemoved.get(MPSDefs.DB_SOR_INVARIANT_ID);
                        String stSorName = (String) hmAccountTobeRemoved.get(MPSDefs.DB_SOR_NAME);

                        hmDeleteMemberService.put(MPSDefs.DB_MEMBER_NUM, stMemberNum);
                        hmDeleteMemberService.put(MPSDefs.DB_SERVICE_NAME, stServiceName);
                        hmDeleteMemberService.put(MPSDefs.DB_INSTANCE_ID, stInstanceID);
                        hmDeleteMemberService.put(MPSDefs.DB_SOR_INVARIANT_ID, stSorInstanceId);
                        hmDeleteMemberService.put(MPSDefs.DB_SOR_NAME, stSorName);

                        hmResult = updateServiceDBHelper.removeService(hmDeleteMemberService);

                        HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                                "Output Hash from MPSDB_Delete_H.deleteMemberService() is NULL or EMPTY");
                        if (result != null) return result;

                        stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

                        if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                            stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG);
                            if (stAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
                                stAppStatusCode = CErrorDefs.ERR_REC_NOT_FOUND;
                            }
                            hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
                            logger.info("{}{}UMDH.RA.05 : {}{}", sClassName, thisMethod, "Error from MPSDB_Delete_H.deleteMemberService() :: ", stAppInfo);
                            return hmResult;
                        }
                    }
                }
            } // End alAccountsToBeRemovedList

            // Add roles in DB
            if (alRolesToBeAddedList != null && !alRolesToBeAddedList.isEmpty()) {
                for (Object o : alRolesToBeAddedList) {
                    HashMap<String, Object> hmRoleAdded = (HashMap) o;

                    if (hmRoleAdded != null && !hmRoleAdded.isEmpty()) {
                        HashMap<String, Object> hmEachRole = CommonUtil.getHashMap();

                        // Retrieve role details
                        String stRoleId = (String) hmRoleAdded.get(MPSDefs.DB_ROLE_ID);
                        String stRoleName = (String) hmRoleAdded.get(MPSDefs.DB_ROLE_NAME);
                        String stMemberNum = (String) hmRoleAdded.get(MPSDefs.DB_MEMBER_NUM);
                        String stServiceId = (String) hmRoleAdded.get(MPSDefs.DB_SERVICE_ID);
                        String stSorId = (String) hmRoleAdded.get(MPSDefs.DB_SOR_ID);
                        String stSorInvariantId = (String) hmRoleAdded.get(MPSDefs.DB_SOR_INVARIANT_ID);
                        String stRoleStatus = (String) hmRoleAdded.get(MPSDefs.DB_ROLE_STATUS_NAME);

                        hmEachRole.put(MPSDefs.DB_ROLE_ID, stRoleId);
                        hmEachRole.put(MPSDefs.DB_ROLE_NAME, stRoleName);
                        hmEachRole.put(MPSDefs.DB_MEMBER_NUM, stMemberNum);
                        hmEachRole.put(MPSDefs.DB_SERVICE_ID, stServiceId);
                        hmEachRole.put(MPSDefs.DB_SOR_ID, stSorId);
                        hmEachRole.put(MPSDefs.DB_SOR_INVARIANT_ID, stSorInvariantId);
                        hmEachRole.put(MPSDefs.DB_ROLE_STATUS, stRoleStatus);
                        hmEachRole.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
                        hmEachRole.put(CommonDefs.TRANSACTION_ID, stTransactionId);

                        hmResult = rolesDBHelper.addEachRole(hmEachRole);

                        HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                                "Output Hash from MPSDB_Roles_H.addEachRole() is NULL or EMPTY");
                        if (result != null) return result;

                        result = validateStatus(hmResult, CommonDefs.COMMON_APP_STATUS_CODE,
                                "Error from rolesDBHelper.addEachRole() :: ");
                        if (result != null) return result;
                    }
                }
            } // alRolesToBeAddedList

            // Remove roles in DB
            if (alRolesToBeRemovedList != null && !alRolesToBeRemovedList.isEmpty()) {
                for (Object o : alRolesToBeRemovedList) {
                    HashMap<String, Object> hmRoleToBeRemove = (HashMap) o;

                    if (hmRoleToBeRemove != null && !hmRoleToBeRemove.isEmpty()) {
                        HashMap<String, Object> hmEachRoleRemove = CommonUtil.getHashMap();

                        // Retrieve roles details to be removed
                        String stRoleId = (String) hmRoleToBeRemove.get(MPSDefs.DB_ROLE_ID);
                        String stRoleName = (String) hmRoleToBeRemove.get(MPSDefs.DB_ROLE_NAME);
                        String stMemberNum = (String) hmRoleToBeRemove.get(MPSDefs.DB_MEMBER_NUM);
                        String stServiceId = (String) hmRoleToBeRemove.get(MPSDefs.DB_SERVICE_ID);
                        String stSorId = (String) hmRoleToBeRemove.get(MPSDefs.DB_SOR_ID);
                        String stSorInvariantId = (String) hmRoleToBeRemove.get(MPSDefs.DB_SOR_INVARIANT_ID);
                        String stLastModifiedBy = (String) hmRoleToBeRemove.get(MPSDefs.DB_LAST_MODIFIED_BY);
                        String stServiceName = (String) hmRoleToBeRemove.get(MPSDefs.DB_SERVICE_NAME);
                        String stSorName = (String) hmRoleToBeRemove.get(MPSDefs.DB_SOR_NAME);
                        String stAgentID = (String) hmRoleToBeRemove.get(MPSDefs.DB_AGENT_ID);
                        String stSourceIpAddress = (String) hmRoleToBeRemove.get(MPSDefs.DB_SOURCE_IP_ADDRESS);

                        hmEachRoleRemove.put(MPSDefs.DB_ROLE_ID, stRoleId);
                        hmEachRoleRemove.put(MPSDefs.DB_ROLE_NAME, stRoleName);
                        hmEachRoleRemove.put(MPSDefs.DB_MEMBER_NUM, stMemberNum);
                        hmEachRoleRemove.put(MPSDefs.DB_SERVICE_ID, stServiceId);
                        hmEachRoleRemove.put(MPSDefs.DB_SOR_ID, stSorId);
                        hmEachRoleRemove.put(MPSDefs.DB_SOR_INVARIANT_ID, stSorInvariantId);
                        hmEachRoleRemove.put(MPSDefs.DB_LAST_MODIFIED_BY, stLastModifiedBy);
                        hmEachRoleRemove.put(MPSDefs.DB_SERVICE_NAME, stServiceName);
                        hmEachRoleRemove.put(MPSDefs.DB_SOR_NAME, stSorName);
                        hmEachRoleRemove.put(MPSDefs.DB_AGENT_ID, stAgentID);
                        hmEachRoleRemove.put(MPSDefs.DB_SOURCE_IP_ADDRESS, stSourceIpAddress);
                        hmEachRoleRemove.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
                        hmEachRoleRemove.put(CommonDefs.TRANSACTION_ID, stTransactionId);

                        hmResult = rolesDBHelper.removeRoles(hmEachRoleRemove);

                        HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                                "Output Hash from MPSDB_Roles_H.removeRoles() is NULL or EMPTY");
                        if (result != null) return result;

                        result = validateStatus(hmResult, CommonDefs.COMMON_APP_STATUS_CODE,
                                "Error from rolesDBHelper.removeRoles()");
                        if (result != null) return result;
                    }
                }
            } // alRolesToBeRemovedList

            // Delete the account from TSERVICEINFO, TSERVICECONTACT and TSERVICENOTIFICATION.
            if (alAccountsToBeDeletedList != null && !alAccountsToBeDeletedList.isEmpty()) {
                HashMap<String, Object> hmAccountDelete = CommonUtil.getHashMap();
                ArrayList<String> alServiceInfo = CommonUtil.getArrayList();
                ArrayList<String> alServiceContact = CommonUtil.getArrayList();
                ArrayList<String> alServiceNotification = CommonUtil.getArrayList();

                for (Object o : alAccountsToBeDeletedList) {
                    HashMap hmAccountTobeDeleted = (HashMap) o;

                    if (hmAccountTobeDeleted != null && !hmAccountTobeDeleted.isEmpty()) {
                        HashMap<String, Object> hmServiceInfo = CommonUtil.getHashMap();
                        HashMap<String, Object> hmServiceContact = CommonUtil.getHashMap();
                        HashMap<String, Object> hmServiceNotification = CommonUtil.getHashMap();

                        String stSorInvariantId = (String) hmAccountTobeDeleted.get(MPSDefs.DB_SOR_INVARIANT_ID);
                        String stSorId = (String) hmAccountTobeDeleted.get(MPSDefs.DB_SOR_ID);
                        String stSorName = (String) hmAccountTobeDeleted.get(MPSDefs.DB_SOR_NAME);

                        hmServiceInfo.put(MPSDefs.DB_SOR_INVARIANT_ID, stSorInvariantId);
                        hmServiceInfo.put(MPSDefs.DB_SOR_ID, stSorId);
                        hmServiceInfo.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
                        alServiceInfo.add(String.valueOf(hmServiceInfo));

                        hmServiceContact.put(MPSDefs.DB_SOR_INVARIANT_ID, stSorInvariantId);
                        hmServiceContact.put(MPSDefs.DB_SOR_ID, stSorId);
                        hmServiceContact.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
                        alServiceContact.add(String.valueOf(hmServiceContact));

                        hmServiceNotification.put(MPSDefs.DB_SOR_INVARIANT_ID, stSorInvariantId);
                        hmServiceNotification.put(MPSDefs.DB_SOR_NAME, stSorName);
                        hmServiceNotification.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);
                        alServiceNotification.add(String.valueOf(hmServiceNotification));

                    }

                }

                if (!alServiceInfo.isEmpty()) {
                    hmAccountDelete.put("serviceinfo", alServiceInfo);
                }

                if (!alServiceContact.isEmpty()) {
                    hmAccountDelete.put("servicecontact", alServiceContact);
                }

                if (!alServiceNotification.isEmpty()) {
                    hmAccountDelete.put("servicenotification", alServiceNotification);
                }

                hmAccountDelete.put(CommonDefs.TRANSACTION_NAME, stTransactionName);
                hmAccountDelete.put(CommonDefs.TRANSACTION_ID, stTransactionId);
                hmAccountDelete.put(CommonDefs.CALLING_SYSTEM_ID, stCallingSystemId);

                // 1. to delete from TSERVICEINFO
                hmResult = serviceInfoDBHelper.removeServiceInfo(hmAccountDelete);

                HashMap result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                        "Output Hash from MPSDB_ServiceInfo_H.removeServiceInfo() is NULL or EMPTY");
                if (result != null) return result;

                result = validateStatus(hmResult, CommonDefs.COMMON_APP_STATUS_CODE, null);
                if (result != null) return result;

                // 2. delete from TSERVICECONTACT
                hmResult = serviceContactDBHelper.removeServiceContact(hmAccountDelete);

                result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                        "Output Hash from MPSDB_ServiceContact_H.removeServiceContact() is NULL or EMPTY");
                if (result != null) return result;

                result = validateStatus(hmResult, CommonDefs.COMMON_APP_STATUS_CODE,
                        "Error from MPSDB_ServiceContact_H.removeServiceContact() :: ");
                if (result != null) return result;

                // 3. delete from TSERVICENOTIFICATION
                hmResult = serviceNotificationDBHelper.removeServiceNotification(hmAccountDelete);

                result = validateMapInput(hmResult, CErrorDefs.ERR_SYS_APPL_NUM,
                        "Output Hash from MPSDB_ServiceNotification_H.removeServiceNotification() is NULL or EMPTY");
                if (result != null) return result;

                result = validateStatus(hmResult, CommonDefs.COMMON_APP_STATUS_CODE,
                        "Error: ");
                if (result != null) return result;
            } // End alAccountsToBeDeletedList

            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG);

        } catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e);
            String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
            logger.error("{}{}UMDH.RA.17 : {}{}", sClassName, thisMethod, errorCode, thisMethod);
            logger.error("{}{}UMDH.RA.16 : {}{}", sClassName, thisMethod, "TMS_UMD_RM_E01", "Exception::Exception = " + e.getMessage());
        }
        return hmResult;
    } // END
}
