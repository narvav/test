package com.att.idp.idgraphusermanagementms.resource.response;

import lombok.Data;

/**
 * This class represents a user's lockout status in the system.
 * It contains fields for memberNum, lockoutId, lockoutName, setNumber, failedAuthCount, lockoutExpiration, lastFailedAuth, createDate, lastModified, and lastModifiedBy.
 * Each field has specific constraints such as not null and size limits.
 *
 * The class uses Lombok's @Data annotation to generate getter and setter methods for all fields.
 *
 */
@Data
public class IPUserLockout {

	private String memberNum;
	private String lockoutId;
	private String lockoutName;
	private String setNumber;
	private String failedAuthCount;
	private String lockoutExpiration;
	private String lastFailedAuth;
	private String createDate;
	private String lastModified;
	private String lastModifiedBy;
}