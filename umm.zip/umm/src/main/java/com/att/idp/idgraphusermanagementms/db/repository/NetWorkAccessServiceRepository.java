package com.att.idp.idgraphusermanagementms.db.repository;

import java.sql.SQLException;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.att.idp.idgraphusermanagementms.db.model.Tnetworkaccess;

/**
 * This is the main repository interface for network access related operations.
 * It extends JpaRepository for standard CRUD operations and NetWorkAccessRepositoryCustom for custom operations.
 * The entity associated with this repository is Tnetworkaccess and the ID type is Long.
 */
@Repository 
public interface NetWorkAccessServiceRepository extends JpaRepository<Tnetworkaccess, Long> , NetWorkAccessRepositoryCustom {
	
	/**
	 * This method is used to retrieve the access ID for a given access name from the database.
	 *
	 * @param accessName A string representing the access name for which the access ID is to be retrieved.
	 * @return An integer representing the access ID associated with the given access name.
	 * @throws SQLException If there is an error while executing the SQL query.
	 */
	@Query(value =  "select nwa.ACCESS_ID from MPS_OWNER.TNETWORKACCESS nwa where nwa.ACCESS_NAME=:accessName", nativeQuery=true)
	public int getAccessId(@Param(value = "accessName") String accessName) throws SQLException;
}