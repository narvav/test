package com.att.idp.idgraphusermanagementms.helper.resetuserpassword;

import java.net.InetAddress;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.db.helper.EmailAppPasswordDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.GetInfoByMaskDBHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * The EmailAppPasswordHelper class is a helper class that is responsible for managing email application passwords.
 * It contains methods to delete and process email application passwords.
 * This class is annotated with @Component and @PropertySource, indicating that it is an auto-detectable
 * Spring bean and a source of property values respectively.
 * It uses autowired dependencies like GetInfoByMaskDBHelper and EmailAppPasswordDBHelper to perform its operations.
 * It also uses @Value to inject property values from a properties file.
 */
@Component
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class EmailAppPasswordHelper {

	private String sClassName = "EmailAppPasswordHelper";
	private static final Logger log = LoggerFactory.getLogger(EmailAppPasswordHelper.class);
	
	@Autowired
	private GetInfoByMaskDBHelper getInfoByMaskDBHelper;
	
	@Autowired
	private EmailAppPasswordDBHelper emailAppPasswordDBHelper;
	
	@Value("${fraudDeleteSMK}")
	private String sFraudDeleteSMK;
	
	private static final String info = "$Id: master/com/att/mpsys/common/helpers/EmailAppPasswordHelper.java v4 2020-01-21 kg852c $;" ;
	
	/**
	 * This method is responsible for deleting an email application password.
	 * It takes a HashMap as input which contains the necessary information for the deletion process.
	 * The method logs the start time of the process and the input parameters.
	 * It checks if the input HashMap is null or empty and returns an error if it is.
	 * If the input contains linked users, it iterates over each user and processes the deletion for each one.
	 * If the input does not contain linked users, it directly processes the deletion.
	 * In case of any exception, it logs the error and returns an error HashMap.
	 * Finally, it logs the end time of the process and the result, and returns the result HashMap.
	 *
	 * @param hmInput HashMap containing the necessary information for the deletion process.
	 * @return HashMap containing the result of the deletion process.
	 */
	@org.springframework.transaction.annotation.Transactional
	public HashMap deleteEmailAppPwd(HashMap hmInput) {
		
		String sMethodName 		= ".deleteEmailAppPwd.";
		String stAppInfo			= null;
		String stAppStatusCode		= null;
		HashMap hmResult = null;
		
		
		Date tmsStartDate = new Date();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss");
		String tStartDate = dateFormat.format(tmsStartDate);
		log.info(sClassName + sMethodName + "CVS version : " + info);
		log.info(sClassName + sMethodName + "HLP_02 : Start time in TMS = " + tStartDate);
		log.info(sClassName + sMethodName + "HLP000 : Input Hash : " + HtmlUtils.htmlEscape(String.valueOf(hmInput)));
		
		try{
		
			if(hmInput == null || hmInput.isEmpty()){
				
				stAppInfo = "Input Request Parameter is NULL";
				log.info(sClassName + sMethodName + "HLP_03 : " + stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				return hmResult;
			}
			
			ArrayList alLinkedUsers = (ArrayList) hmInput.get(MPSDefs.KEY_LINKED_USERS);
			
			if(alLinkedUsers != null && !alLinkedUsers.isEmpty()){
				
				log.info(sClassName + sMethodName + "HLP_04 : LinkedUsers present in input, so iterating over each Member ");
				ArrayList alDbusResponse = CommonUtil.getArrayList();
				
				for (Iterator itMember = alLinkedUsers.iterator(); itMember.hasNext();) {
					HashMap hmDBMember = (HashMap) itMember.next();
					if(hmDBMember != null && !hmDBMember.isEmpty()){
						if(hmDBMember.containsKey(MPSDefs.DB_APPEMAILPASSWORD_TABLE)){
							String sDBMemberNum = (String) hmDBMember.get(MPSDefs.DB_MEMBER_NUM);
							
							HashMap hmTempInput = CommonUtil.getHashMap();
							hmTempInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
							hmTempInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
							hmTempInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
							hmTempInput.put(CommonDefs.HANDLE, hmDBMember.get(MPSDefs.DB_MEMBER_NAME));
							hmTempInput.put(CommonDefs.DOMAIN, hmDBMember.get(MPSDefs.DB_DOMAIN_NAME));
							//hmTempInput.put(CommonDefs.GUID, sDBMemberNum);
							hmTempInput.put(CommonDefs.GET_INFO_RESPONSE, hmDBMember);
							hmTempInput.put(CommonDefs.CALLDBUS, hmInput.get(CommonDefs.CALLDBUS));
							hmTempInput.put("suppressEDD", (String)hmInput.get("suppressEDD"));
							
							//1804 # PID 291481 - CR 174897 - Email Migration SMKs
							hmTempInput.put(CommonDefs.DELETE_SMK, hmInput.get(CommonDefs.DELETE_SMK));
							
							hmResult = processDeleteEmailAppPwd(hmTempInput);
							
							stAppStatusCode = (String)hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
							
							if(!CommonDefs.COMMON_SUCCESS.equalsIgnoreCase(stAppStatusCode)){
								
								stAppInfo = (String)hmResult.get(CommonDefs.COMMON_APP_INFO);
								log.info(sClassName + sMethodName + "HLP_005 : "+ HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
								hmResult  = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
								return hmResult;
							}
							
							if(hmResult.containsKey(CommonDefs.CONSOLIDATED_DBUS_INPUT)){
								alDbusResponse.addAll((ArrayList)hmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT));
							}
						}
					}
				}
				
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success");
				
				if(alDbusResponse != null && !alDbusResponse.isEmpty()){
					hmResult.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, alDbusResponse);
				}
				
			} else {
				hmResult = processDeleteEmailAppPwd(hmInput);
			}
			
		}catch(Exception e){
			
			hmResult = CommonErrorMap.makeExceptionMap(e, log);
			log.error(sClassName + sMethodName + "HLP_14 : " + " Error::" + e.getMessage());
			log.error(sClassName + sMethodName + "HLP_15 : " + "Exception = {}", e);

			
		}finally{
			
			log.info(sClassName + sMethodName + "HLP999 :  "+ HtmlUtils.htmlEscape(String.valueOf(tmsStartDate.getTime()))+ HtmlUtils.htmlEscape(String.valueOf(hmResult)));
		}
		
		return hmResult;
	}

/**
 * 
 * @param hmInput
 * @param log
 * @return HashMap
 */
	private HashMap processDeleteEmailAppPwd(HashMap hmInput) {
		
		String sMethodName 		= ".processDeleteEmailAppPwd.";
		String stAppInfo			= null;
		String stAppStatusCode		= null;
		HashMap hmResult 			= null;
		HashMap hmDBMemberInfo 		= new HashMap();
		ArrayList alDBAppEmailPassword = null;
		HashMap hmDbusInput = CommonUtil.getHashMap();

		if(hmInput.containsKey(CommonDefs.GET_INFO_RESPONSE)){
			hmDBMemberInfo = (HashMap) hmInput.remove(CommonDefs.GET_INFO_RESPONSE);
		}
		
		log.info(sClassName + sMethodName + "HLP_003 : inputHash = "+ HtmlUtils.htmlEscape(String.valueOf(hmInput)));
		
		
		try{
		
			hmResult = initializeAndValidate(hmInput);
			
			stAppStatusCode = (String)hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
			
			if(!CommonDefs.COMMON_SUCCESS.equalsIgnoreCase(stAppStatusCode)){
				
				stAppInfo = (String)hmResult.get(CErrorDefs.COMMON_APP_INFO);
				log.info(sClassName + sMethodName + "HLP_04 : "+stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
				return hmResult;
			}
			
			String sSourceIPAddress = (String)hmInput.get("sourceIPAddress");
			String sTransactionName	= (String)hmInput.get(CommonDefs.TRANSACTION_NAME);
			String sTransactionID	= (String)hmInput.get(CommonDefs.TRANSACTION_ID);
			String sCallingSystemId = (String)hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sHandle			= (String)hmInput.get(CommonDefs.HANDLE);
			String sDomain			= (String)hmInput.get(CommonDefs.DOMAIN);
			String sGuid			= (String)hmInput.get(CommonDefs.GUID);
			String sPasswordName	= (String)hmInput.get("passwordName");
			String sLanguage		= (String)hmInput.get(CommonDefs.LANGUAGE);
			String sSupressEDD		= (String)hmInput.get("suppressEDD");
			String sCallDbus		= (String)hmInput.get(CommonDefs.CALLDBUS);
			
			//Email Migration SMKs
			String sDeleteSMK		= (String)hmInput.get(CommonDefs.DELETE_SMK);
			
			if(sDeleteSMK == null || sDeleteSMK.isEmpty()){
				
				// Updated  to look for fraudDeleteSMK value
				if("ResetMemberPassword".equals(sTransactionName) 
						|| "UpdateMember".equals(sTransactionName)) {
					//String sFraudDeleteSMK = PropertyManager.getProperty(CommonDefs.MOUPConfig,"fraudDeleteSMK");
					stAppInfo = "fraudDeleteSMK in config is " + sFraudDeleteSMK;
					log.info(sClassName + sMethodName + "HLP_04.1 : "+stAppInfo);
					sDeleteSMK = sFraudDeleteSMK;
				}
				
				if(sDeleteSMK == null || sDeleteSMK.isEmpty()){
					sDeleteSMK = "N";
				}
			}
			
			String sSMK = "^OX-Y-SMK";
					
			if(hmDBMemberInfo == null || hmDBMemberInfo.isEmpty()){
				
				HashMap hmGetInfoInput  = CommonUtil.getHashMap();
				
				if(sGuid != null && !sGuid.isEmpty()){
					
					hmGetInfoInput.put(MPSDefs.DB_MEMBER_NUM, sGuid);
				}else{
					
					hmGetInfoInput.put(MPSDefs.DB_MEMBER_NAME, sHandle);
					hmGetInfoInput.put(MPSDefs.DB_DOMAIN_NAME, sDomain);
				}
				
				hmGetInfoInput.put(CommonDefs.CALLING_SYSTEM_ID, (String)hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
				hmGetInfoInput.put(CommonDefs.TRANSACTION_NAME, (String)hmInput.get(CommonDefs.TRANSACTION_NAME));
				hmGetInfoInput.put(CommonDefs.TRANSACTION_ID, (String)hmInput.get(CommonDefs.TRANSACTION_ID));
				
				ArrayList alDataMasks = CommonUtil.getArrayList();
				
				alDataMasks.add("UP");
				alDataMasks.add("AEP");
				
				hmGetInfoInput.put(CommonDefs.DATA_MASK, alDataMasks);
				
				log.debug(sClassName + sMethodName + "HLP_1 : calling MPSDB_GetInfoByMask_H.getInfoByMask with InputHash : "+ HtmlUtils.htmlEscape(String.valueOf(hmGetInfoInput)));
				
				hmResult = getInfoByMaskDBHelper.getInfoByMask(hmGetInfoInput);
				
				log.debug(sClassName + sMethodName + "HLP_2 : Response from MPSDB_GetInfoByMask_H.getInfoByMask with InputHash : "+hmResult);
				
				if(hmResult == null || hmResult.isEmpty()){
					
					stAppInfo = "Null Response returned from GetMPSInfoMPS.getInfoByMask() method. ";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					log.info(sClassName + sMethodName + "HLP_3 : "+stAppInfo);
					return hmResult;
				}
		
				stAppStatusCode = (String)hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE); 
				
				if(!CommonDefs.COMMON_SUCCESS.equalsIgnoreCase(stAppStatusCode)){
				
					stAppInfo = (String)hmResult.get(CommonDefs.COMMON_APP_INFO);
					log.info(sClassName + sMethodName + "HLP_05 : "+stAppInfo);
					hmResult  = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
					return hmResult;
				}
				
				
				
				//hmDBMemberInfo = (HashMap)hmResult.get(MPSDefs.DB_MEMBER_TABLE);
				
				hmDBMemberInfo.putAll(hmResult);
				
				alDBAppEmailPassword = (ArrayList)hmResult.get(MPSDefs.DB_APPEMAILPASSWORD_TABLE);
			} else {
				alDBAppEmailPassword = (ArrayList)hmDBMemberInfo.get(MPSDefs.DB_APPEMAILPASSWORD_TABLE);
			}
			
			if(sGuid == null || sGuid.isEmpty()){
				
				sGuid = (String)hmDBMemberInfo.get(MPSDefs.DB_MEMBER_NUM);
				
			}
			//JUnit fix : unreachable-  covered in initializeAndValidate method.
			/*if((sHandle == null || sHandle.isEmpty()) || (sDomain == null || sDomain.isEmpty())){
				
				sHandle = (String)hmDBMemberInfo.get(MPSDefs.DB_MEMBER_NAME);
				sDomain = (String)hmDBMemberInfo.get(MPSDefs.DB_DOMAIN_NAME);
			}*/
			
			//JUnit fix : already covered in initializeAndValidate method.
			/*if(CommonDefs.SLID_DUM.equalsIgnoreCase(sDomain)){
				
				stAppInfo = "accessID is not allowed in input request.";
				log.info(sClassName + sMethodName + "HLP_05.1 : "+stAppInfo);
	            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_NOT_MEMBER_ID_NUM,stAppInfo);
	            return hmResult;
			}*/
			
			String sDBContactEmail	= (String)hmDBMemberInfo.get(MPSDefs.DB_CONTACT_EMAIL);
			String sDBAcctType		= (String)hmDBMemberInfo.get(MPSDefs.DB_ACCOUNT_TYPE); 
			String sDBLanguage		= (String)hmDBMemberInfo.get(MPSDefs.DB_LANGUAGE);
			
			if(sLanguage == null || sLanguage.isEmpty()){
				
				sLanguage = sDBLanguage;
			}
			
			ArrayList alPasswordNames = CommonUtil.getArrayList(); 
			
			if(sPasswordName == null || sPasswordName.isEmpty()){
				
				if(alDBAppEmailPassword != null && !alDBAppEmailPassword.isEmpty()){
					
					Iterator itr = alDBAppEmailPassword.iterator();
					
					while (itr.hasNext()){
						
						HashMap  hmDBAppEmailPwd = (HashMap) itr.next();
						String sDBPasswordName = (String)hmDBAppEmailPwd.get(MPSDefs.DB_PASSWORD_NAME);
						
						//1804 # PID 291481 - CR 174897 - Email Migration SMKs
						if("Y".equals(sDeleteSMK) || !sSMK.equals(sDBPasswordName)){
							alPasswordNames.add(sDBPasswordName);
						}
					}
				}
			}else{
				
				if("Y".equals(sDeleteSMK) || !sSMK.equals(sPasswordName)){
					alPasswordNames.add(sPasswordName);
				}
			}
			
			ArrayList alDbusInp = CommonUtil.getArrayList();
			
			if(alPasswordNames != null && !alPasswordNames.isEmpty()){
				
				HashMap hmDeleteYahooInput = CommonUtil.getHashMap(); 
				
				hmDeleteYahooInput.put(CommonDefs.TRANSACTION_ID, sTransactionID);
				hmDeleteYahooInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
				hmDeleteYahooInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
				hmDeleteYahooInput.put(CommonDefs.HANDLE, sHandle);
				hmDeleteYahooInput.put(CommonDefs.DOMAIN, sDomain);
				hmDeleteYahooInput.put(CommonDefs.EVENTNAME, "DeleteApplicationPassword");
				hmDeleteYahooInput.put(CommonDefs.SUBEVENT, "Yahoo");
				hmDeleteYahooInput.put(CommonDefs.DBUS_DICTIONARY_NAME, "YahooDict");
				hmDeleteYahooInput.put("RemoteIPAddress", sSourceIPAddress);
				
				ArrayList alPasswordInfo = CommonUtil.getArrayList();
				
				Iterator itr = alPasswordNames.iterator();
				while (itr.hasNext()) {
					
					String sPwdName = (String) itr.next();
					HashMap hmTemp = CommonUtil.getHashMap();
					hmTemp.put(CommonDefs.PASSWORD_NAME, sPwdName);
					alPasswordInfo.add(hmTemp);
				}
				
				hmDeleteYahooInput.put("passwordNames", alPasswordInfo);
				alDbusInp.add(hmDeleteYahooInput);
				
			}
			
			// Prepare for deleting row from APPEMAILPASSWORD table if present
			
			//1804 # PID 291481 - CR 174897 - Email Migration SMKs
			ArrayList alEmailAppPwd = CommonUtil.getArrayList();
			
			if("Y".equalsIgnoreCase(sDeleteSMK)){
				
				HashMap hmDeleteEmail = CommonUtil.getHashMap();
				
				hmDeleteEmail.put(MPSDefs.DB_MEMBER_NUM, sGuid);
				
				if(sPasswordName != null && !sPasswordName.isEmpty()){
					hmDeleteEmail.put(MPSDefs.DB_PASSWORD_NAME, sPasswordName);	
				}
				
				hmDeleteEmail.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_DELETE);
				hmDeleteEmail.put(CommonDefs.TRANSACTION_ID, sTransactionID);
				hmDeleteEmail.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
				hmDeleteEmail.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
				
				//ArrayList alEmailAppPwd = CommonUtil.getArrayList(); create alEmailAppPwd above if condition to check sDeleteSMK equal to Y. 
				
				alEmailAppPwd.add(hmDeleteEmail);
				
			}else{
				
				if(alPasswordNames != null && !alPasswordNames .isEmpty()){
					
					Iterator itr = alPasswordNames.iterator();
					while (itr.hasNext()) {
						
						String sPwdName = (String) itr.next();
						HashMap hmDeleteEmail  = CommonUtil.getHashMap();
						
						hmDeleteEmail.put(MPSDefs.DB_MEMBER_NUM, sGuid);
						hmDeleteEmail.put(MPSDefs.DB_PASSWORD_NAME, sPwdName);
						hmDeleteEmail.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_DELETE);
						hmDeleteEmail.put(CommonDefs.TRANSACTION_ID, sTransactionID);
						hmDeleteEmail.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
						hmDeleteEmail.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
						alEmailAppPwd.add(hmDeleteEmail);
					}
					
				}
			}
			
			if(alEmailAppPwd != null && !alEmailAppPwd.isEmpty()){
				HashMap hmUMDInput = CommonUtil.getHashMap(); 
				
				hmUMDInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
				hmUMDInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
				hmUMDInput.put(CommonDefs.TRANSACTION_ID, sTransactionID);
				hmUMDInput.put(MPSDefs.DB_APPEMAILPASSWORD_TABLE, alEmailAppPwd);
				
				log.debug(sClassName + sMethodName + "HLP_06 : calling processAppEmailPassword() with InputHash : "+stAppInfo);
				
				hmResult=processAppEmailPassword(hmUMDInput);
				
				log.debug(sClassName + sMethodName + "HLP_06 : Response from processAppEmailPassword() with InputHash : "+stAppInfo);
				
				if(hmResult == null || hmResult.isEmpty()){
					
					stAppInfo = "NULL Response from TMSMPS_UpdateMemberData.processAppEmailPassword() method. ";
					log.info(sClassName + sMethodName + "HLP_08 : "+stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					return hmResult;
				}
				
				stAppStatusCode = (String)hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE); 
				
				if(!CommonDefs.COMMON_SUCCESS.equalsIgnoreCase(stAppStatusCode)){
				
					stAppInfo = (String)hmResult.get(CommonDefs.COMMON_APP_INFO);
					log.info(sClassName + sMethodName + "HLP_09 : "+stAppInfo);
					hmResult  = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
					return hmResult;
				}
			}			
			
			
			if(!CommonDefs.IND_Y.equalsIgnoreCase(sSupressEDD)){
				
				HashMap hmEDDEvent  = CommonUtil.getHashMap();
				
				hmEDDEvent.put(CommonDefs.TRANSACTION_ID, sTransactionID);
				hmEDDEvent.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
				hmEDDEvent.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
				hmEDDEvent.put(CommonDefs.HANDLE, sHandle);
				hmEDDEvent.put(CommonDefs.DOMAIN, sDomain);
				hmEDDEvent.put(CommonDefs.BROWSER_LANGUAGE, sLanguage);
				hmEDDEvent.put(CommonDefs.EVENTNAME, "EDDHPRTYPwdNotification");
				hmEDDEvent.put(CommonDefs.SUBEVENT, "EDDUVERSE");
				hmEDDEvent.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
				hmEDDEvent.put(CommonDefs.ACCOUNT_TYPE, sDBAcctType);
				
				HashMap hmDelMethod 				= CommonUtil.getHashMap();
				if(sDBContactEmail != null && !sDBContactEmail.isEmpty()){
					hmDelMethod.put(CommonDefs.VALUE_EMAIL, sDBContactEmail);
				} else {
					hmDelMethod.put(CommonDefs.VALUE_EMAIL, sHandle + "@" + sDomain);
				}				
				
				HashMap hmNotifData		= CommonUtil.getHashMap();
				hmNotifData.put(CommonDefs.DELIVERY_METHOD_VALUE, hmDelMethod);
				
				ArrayList alNotifData	= CommonUtil.getArrayList();
				
				alNotifData.add(hmNotifData);
				
				hmEDDEvent.put(CommonDefs.NOTIFICATION_DATA, alNotifData);
				
				alDbusInp.add(hmEDDEvent);
			}
			
			hmResult =  CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,"SUCCESS");
			hmResult.put(CommonDefs.GUID, sGuid);
			

			if(alDbusInp != null && !alDbusInp.isEmpty()){
				hmResult.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, alDbusInp);
			}

			
		}catch(Exception e){
			
			hmResult = CommonErrorMap.makeExceptionMap(e, log);
			log.error(sClassName + sMethodName + "HLP_E_01 : " + " Error::" + e.getMessage());
			log.error(sClassName + sMethodName + "HLP_E_02 : " + "Exception = {}", e);
		
			
		}finally{
			
			log.info(sClassName + sMethodName + "HLP_F_01 : hmResult "+ HtmlUtils.htmlEscape(String.valueOf(hmResult)));
		}
		
		return hmResult;
	}

	private HashMap processAppEmailPassword(HashMap hmInput) {

		String sMethodName = ".processAppEmailPassword.";
		String sAppInfo = null;
		String sAppStatusCode = null;
		Date dtStartDate = new Date();
		HashMap hmResult = null;
		String sOperation = null;

		ArrayList alEmailAppPwd = null;
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss");
		String stStartTime = null;
		stStartTime = dateFormat.format(dtStartDate);
		
		log.info(sClassName + sMethodName + "TMS_UMD_02 : hmResult "+ stStartTime);
		log.info(sClassName + sMethodName + "TMS000 : hmResult "+ HtmlUtils.htmlEscape(String.valueOf(hmInput)));

		//JUnit fix : Unreachable
		/*if (hmInput == null || hmInput.isEmpty()) {
			sAppInfo = "Input parameters to TMSMPS_UpdateMemberDataBean is null / empty";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM,sAppInfo);
			log.info(sClassName + sMethodName + "TMS_UMD_04 : "+ sAppInfo);
			return hmResult;
		}*/

		try {

			String sTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);

			alEmailAppPwd = (ArrayList) hmInput.get(MPSDefs.DB_APPEMAILPASSWORD_TABLE);
			
			//JUnit fix : Unreachable
			/*if(alEmailAppPwd == null || alEmailAppPwd.isEmpty())
			{ 
				sAppInfo="Input does not have APPEMAILPASSWORD data";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
				log.info(sClassName + sMethodName + "TMS_UMD_06 : "+ sAppInfo);
				return hmResult;
			}*/
			
			
			for (int i = 0 ; i < alEmailAppPwd.size() ; i++)
			{
			
				HashMap hmEmailAppPwd = (HashMap) alEmailAppPwd.get(i);
				if(hmEmailAppPwd != null && !hmEmailAppPwd.isEmpty())
				{
					sOperation= (String)hmEmailAppPwd.get(MPSDefs.DB_OPERATION);
					//JUnit fix : Unreachable
					/*if(sOperation == null || sOperation.isEmpty())
					{
						sAppInfo = " sOperation is null or empty ";
						hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, sAppInfo);
						log.info(sClassName + sMethodName + "TMS_UMD_06.1 : "+ sAppInfo);
						return hmResult;
					}*/
					if(sOperation.equalsIgnoreCase(MPSDefs.DB_OPERATION_DELETE))
					{
						log.debug(sClassName + sMethodName + "TMS_UMD_06.2 : Calling MPSDB_EmailAppPassword.deleteEmailAppPwd() "+ HtmlUtils.htmlEscape(String.valueOf(hmEmailAppPwd)));
					
						hmResult = emailAppPasswordDBHelper.deleteEmailAppPwd(hmEmailAppPwd);
						
						log.debug(sClassName + sMethodName + "TMS_UMD_06.3 : Response MPSDB_EmailAppPassword.deleteEmailAppPwd() "+ hmResult);

					}
					if(sOperation.equalsIgnoreCase(MPSDefs.DB_OPERATION_INSERT))
					{
						log.debug(sClassName + sMethodName + "TMS_UMD_06.2 : Calling MPSDB_EmailAppPassword.addEmailAppPwd() "+ HtmlUtils.htmlEscape(String.valueOf(hmEmailAppPwd)));
						
						hmResult = emailAppPasswordDBHelper.addEmailAppPwd(hmEmailAppPwd);
	
						log.debug(sClassName + sMethodName + "TMS_UMD_06.7 : Response MPSDB_EmailAppPassword.addEmailAppPwd() "+ hmResult);
	
					}
				}
				
				if(hmResult == null || hmResult.isEmpty())
				{
					sAppInfo = "HashMap hmResult  is null";                                      
					hmResult =  CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
					log.info(sClassName + sMethodName + "TMS_UMD_06.8 : "+ sAppInfo);
	                return hmResult;
				}
				sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
				if (sAppStatusCode != null && !sAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					sAppInfo = "Error returned After calling MPSDB_EmailAppPassword ";
					log.info(sClassName + sMethodName + "TMS_UMD_06.9 : "+ sAppInfo);
					return hmResult;
				}
		  }
			
		} catch (Exception e) {
			
			hmResult = CommonErrorMap.makeExceptionMap(e, log);
			log.error(sClassName + sMethodName + "TMS_UMD_116 : " + " Error::" + e.getMessage());
			log.error(sClassName + sMethodName + "TMS_UMD_117 : " + "Exception = {}", e);
			
		
		} 
		finally {
		
			log.info(sClassName + sMethodName + "TMS999 : "+ dtStartDate.getTime() + hmResult);
		}

		return hmResult;
		
	}

	private HashMap initializeAndValidate(HashMap hmInput) {
		
		String sMethodName = ".initializeAndValidate.";
		String stAppInfo = null;
		HashMap hmResult = null;
		
		String sHandle = (String)hmInput.get(CommonDefs.HANDLE);
		String sDomain = (String)hmInput.get(CommonDefs.DOMAIN);
		//String sGuid   = (String)hmInput.get(CommonDefs.GUID);
		String sSourceIPAddress = (String)hmInput.get(CommonDefs.SOURCE_IP_ADDRESS);
		
		Boolean bReturnError = false;
		
		try{
			if((sHandle == null || sHandle.isEmpty()) && (sDomain == null || sDomain.isEmpty())){
				
				bReturnError = true;
				stAppInfo = "Either handle/domain or guid has to be present in input request.";
				
			}else if((sHandle != null && !sHandle.isEmpty()) && (sDomain == null ||sDomain.isEmpty())){
					
				bReturnError = true;
				stAppInfo = "doamin is null in input request.";
				
			}else if((sHandle == null || sHandle.isEmpty()) && (sDomain != null && !sDomain.isEmpty())){
				
				bReturnError = true;
				stAppInfo = "handle is null in input request.";
			}
			
			if(bReturnError){
				
				log.info(sClassName + sMethodName + "HLP_1 : "+stAppInfo);
	            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,stAppInfo);
	            return hmResult;
			}
			
			
			if(CommonDefs.SLID_DUM.equalsIgnoreCase(sDomain)){
				
				stAppInfo = "accessID is not allowed in input request.";
				log.info(sClassName + sMethodName + "HLP_09 : "+stAppInfo);
	            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_NOT_MEMBER_ID_NUM,stAppInfo);
	            return hmResult;
			}
			
			
			
			if(sSourceIPAddress == null || sSourceIPAddress.isEmpty()){
				
				InetAddress ipAddr = InetAddress.getLocalHost();
				sSourceIPAddress = ipAddr.getHostAddress();
				log.info(sClassName + sMethodName + "HLP_2.0 : calculated sSourceIPAddress : "+sSourceIPAddress);
				hmInput.put(CommonDefs.SOURCE_IP_ADDRESS, sSourceIPAddress);
			}
			
			hmResult =  CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,"SUCCESS");
			
			
		}catch(Exception e){
			
			hmResult = CommonErrorMap.makeExceptionMap(e, log);
			log.error(sClassName + sMethodName + "HLP_4 : " + " Error::" + e.getMessage());
			log.error(sClassName + sMethodName + "HLP_5 : " + "Exception = {}", e);

		}
		
		return hmResult;
	}

}
