package com.att.idp.idgraphusermanagementms.service.impl;

import java.util.Map;

import jakarta.ws.rs.core.MultivaluedMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.UnlinkMemberIdHelper;
import com.att.idp.idgraphusermanagementms.resource.request.UnlinkMemberIdRequest;
import com.att.idp.idgraphusermanagementms.resource.response.CommonResponse;
import com.att.idp.idgraphusermanagementms.service.UnlinkMemberIdService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This class implements the UnlinkMemberIdService interface and provides the implementation for unlinking a member ID in the system.
 * It is annotated with @Service to indicate that it's a Spring Bean and @Transactional to handle the transaction management.
 *
 * It contains a method unlinkMemberId which takes an UnlinkMemberIdRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return a CommonResponse object.
 *
 * The UnlinkMemberIdRequest object encapsulates the details of the member ID unlink operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class UnlinkMemberIdServiceImpl implements UnlinkMemberIdService {

	
	public static final Logger logger = LoggerFactory.getLogger(UnlinkMemberIdServiceImpl.class);

	private static String sClassName = "UnlinkMemberIdServiceImpl";

	@Autowired
	private UnlinkMemberIdHelper unlinkMemberIdHelper;

	@Override
	public CommonResponse unlinkMemberId(UnlinkMemberIdRequest unlinkMemberIdRequest,
			MultivaluedMap<String, String> requestHeader) {

		Map<String, Object> hmResponse = null;
		String sMethodName = ".unlinkMemberId.";

		Map<String, Object> hmInput = CommonUtilHelper.objectToMap(unlinkMemberIdRequest);
		String idpTraceid = (String) hmInput.get("idpTraceId");
		hmInput.put("dbusTransactionId", idpTraceid.split(":")[0]);
		logger.info(SpiMarker.getInstance(),
				"UnlinkMemberIdServiceImpl.unlinkMemberId.TRLS_01 : Calling UnlinkMemberIdHelper with Input : {}",
				StructuredArguments.entries(hmInput));

		hmResponse = unlinkMemberIdHelper.unlinkMemberId(hmInput);

		logger.info("{}{}TRLS_02 : Response from UnlinkMemberIdHelper  : {}", sClassName, sMethodName, hmResponse);

		if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
			hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from UnlinkMemberIdHelper.unlinkMemberId");
			logger.info("{}{}TRLS_03 : Null response from unlinkMemberIdHelper.unlinkMemberId", sClassName, sMethodName);
		} else {
			String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (stAppStatusCode == null) {
				hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from unlinkMemberIdHelper.unlinkMemberId");
				logger.info("{}{}TRLS_04 : Null response from unlinkMemberIdHelper.unlinkMemberId", sClassName,
						sMethodName);
			}
		}

		hmResponse.put("idp-trace-id", unlinkMemberIdRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME, "UnlinkMemberId");
		CommonResponse response = CommonUtilHelper.generateCommonResponse(hmResponse);
		//CommonResponse response = null;
		String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

		if (sTxnRollBack != null) {
			throw new InvalidInputDataException(hmResponse);
		}
		logger.info("{}{}TRLS_05 : Response from UnlinkMemberIdServiceImpl.unlinkMemberId : {}", sClassName, sMethodName,
				response);
		return response;
	}


}
