package com.att.idp.idgraphusermanagementms.helper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import jakarta.ws.rs.core.HttpHeaders;

import com.att.idp.cgclienthelpers.integration.CGRestClient;
import com.att.idp.cgclienthelpers.utils.CommonConstants;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.db.helper.GetMemberServicesDBHelper;
import com.att.idp.idgraphusermanagementms.helper.resetuserpassword.LockoutHelper;
import com.att.idp.idgraphusermanagementms.helper.resetuserpassword.QueryProfileProofingInfoHelper;
import com.att.idp.idgraphusermanagementms.helper.voltage.ProofingEncryptionHelper;
import com.att.idp.idgraphusermanagementms.resource.request.ValidateUserCredentialsRequest;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * The ValidateUserCredentialsHelper class is a helper class that is responsible for validating user credentials.
 * It contains methods to validate user credentials, get member services, format Titan and Mobility CG responses, 
 * process user locks, and validate online QA establishment date.
 * This class is annotated with @Component, @Configuration, and @PropertySource, indicating that it is an auto-detectable 
 * Spring bean, a source of bean definitions, and a source of property values respectively.
 * It uses autowired dependencies like GetMemberServicesDBHelper, LockoutHelper, ProofingEncryptionHelper, CGRestClient, 
 * and QueryProfileProofingInfoHelper to perform its operations.
 * It also uses @Value to inject property values from a properties file.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class ValidateUserCredentialsHelper {

	public static final Logger logger = LoggerFactory.getLogger(ValidateUserCredentialsHelper.class);

	private static String sClassName = "ValidateUserCredentialsHelper";

	@Autowired
	private GetMemberServicesDBHelper getMemberServicesDBHelper;

	@Autowired
	private LockoutHelper lockoutHelper;

	@Autowired
	private ProofingEncryptionHelper proofingEncryptionHelper;

	@Autowired
	private CGRestClient cgRestClient;

	@Autowired
	private QueryProfileProofingInfoHelper queryProfileProofingInfoHelper;

	@Value("${MemberInterestedLocks}")
	private String memberInterestedLocks;

	@Value("${ValidateCredentialsResponseKeysMapping}")
	private String validateCredentialsResponseKeysMapping;

	@Value("${Security_QA_Aging_Days}")
	private static String security_QA_AgingDays;

	@Value("${apiclient.rest.cg.endpoint}")
	private String cgEndpoint;

	/**
	 * This method is responsible for validating user credentials.
	 * It takes a ValidateUserCredentialsRequest object and HttpHeaders as input.
	 * The ValidateUserCredentialsRequest object contains the user credentials that need to be validated.
	 * The HttpHeaders object contains the HTTP headers of the request.
	 * The method first logs the input parameters and then performs various checks and operations to validate the user credentials.
	 * These operations include checking if the user is locked, if the user has the required services, and if the user credentials match the stored credentials.
	 * If the user credentials are valid, the method processes the user locks and returns a success message.
	 * If the user credentials are not valid, the method processes the user locks and returns an error message.
	 * The method also handles various exceptions and logs appropriate error messages.
	 *
	 * @param validateUserCredentialsRequest A ValidateUserCredentialsRequest object containing the user credentials that need to be validated.
	 * @param httpHeaders A HttpHeaders object containing the HTTP headers of the request.
	 * @return A HashMap containing the result of the method. It includes the application status code and other information.
	 * @throws Exception If there is an error during the operation.
	 */
	@SuppressWarnings({"unchecked", "rawtypes"})
	public Map<String, Object> validateUserCredentials(ValidateUserCredentialsRequest validateUserCredentialsRequest, HttpHeaders httpHeaders) {

		String sMethodName = ".validateUserCredentials.";
		HashMap hmResult = null;
		String stAppInfo = null;
		String stAppStatusCode = null;
		String stAppStatusMsg = null;

		String sDBSor = null;
		String sDBParentChildInd = null;
		String sDBAccessName = null;
		String sDBBan = null;
		ArrayList<HashMap> alActiveLocks = CommonUtil.getArrayList();
		ArrayList<HashMap> alDBMemLockout = CommonUtil.getArrayList();

		HashMap hmGetInfoResp = null;
		HashMap hmGetInfoInp = null;
		Map<String,Object> hmContactDetails=null;
		ArrayList alSlidMask = new ArrayList();

		try {
			logger.info(SpiMarker.getInstance(),"{}{}HLP000 : Input Hash  : {}", sClassName, sMethodName, validateUserCredentialsRequest);
			String sTransactionName = validateUserCredentialsRequest.getTransactionName();
			String sTransactionId = validateUserCredentialsRequest.getIdpTraceId() ;
			String sHandle = validateUserCredentialsRequest.getHandle();
			String sDomain = validateUserCredentialsRequest.getDomain();
			String sCallingSystemId = validateUserCredentialsRequest.getCallingSystemId();

			hmGetInfoInp = new HashMap<String, Object>();

			hmGetInfoInp.put(CommonDefs.TRANSACTION_ID, sTransactionId);
			hmGetInfoInp.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
			hmGetInfoInp.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
			hmGetInfoInp.put(MPSDefs.DB_MEMBER_NAME, sHandle);
			hmGetInfoInp.put(MPSDefs.DB_DOMAIN_NAME, sDomain);
			hmGetInfoInp.put(MPSDefs.SECURITY_ALL_REQ, MPSDefs.YES);
			hmGetInfoInp.put(MPSDefs.DB_QUERY_MEMBERLOCKOUT_FLAG, MPSDefs.YES);
			hmGetInfoInp.put(MPSDefs.QUERY_SLID_INFO_FLAG, MPSDefs.YES);

			alSlidMask.add(CommonDefs.SLO);
			if (CommonDefs.SLID_DUM.equals(sDomain)) {
				hmGetInfoInp.put(CommonDefs.QUERY_FRAUD_LOCK, CommonDefs.IND_Y);
			}

			hmGetInfoInp.put(CommonDefs.SLID_MASK, alSlidMask);

			logger.info("{}{}VUCH_04.1 :Calling to GetMemberServicesDBHelper.getMemberServices with input : {}", sClassName, sMethodName, hmGetInfoInp);

			hmGetInfoResp = getmemberService(hmGetInfoInp);

			logger.debug("{}{}VUCH_05 :Response from GetMemberServicesDBHelper.getmemberService with  : {}", sClassName, sMethodName, hmGetInfoResp);

			stAppStatusCode = (String) hmGetInfoResp.get(CErrorDefs.COMMON_APP_STATUS_CODE);

			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				if (stAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
					stAppInfo = "User Not Found in DB";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
					logger.info("{}{}VUCH_06 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				} else {
					hmResult = hmGetInfoResp;
					return hmResult;
				}
			}

			sDBSor = (String) hmGetInfoResp.get(MPSDefs.DB_SOR_NAME);
			sDBParentChildInd = (String) hmGetInfoResp.get(MPSDefs.DB_PARENT_CHILD_IND);
			sDBAccessName = (String) hmGetInfoResp.get(MPSDefs.DB_ACCESS_NAME);
			sDBBan = (String) hmGetInfoResp.get(MPSDefs.DB_BAN);

			HashMap hmQueryLockoutResp = new HashMap();
			if (hmGetInfoResp.containsKey(CommonDefs.MEMBER_LOCKOUT)) {

				alDBMemLockout = (ArrayList) hmGetInfoResp.get(CommonDefs.MEMBER_LOCKOUT);

				if (alDBMemLockout != null && !alDBMemLockout.isEmpty()) {
					HashMap hmLHQueryInput = CommonUtil.getHashMap();

					hmLHQueryInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
					hmLHQueryInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
					hmLHQueryInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
					hmLHQueryInput.put(MPSDefs.DB_MEMBERLOCKOUT, alDBMemLockout);

					logger.info("{}{}VUCH_07 :Calling LockoutHelper.queryLockout with input : {}", sClassName, sMethodName, hmLHQueryInput);

					hmResult = lockoutHelper.queryLockout(hmLHQueryInput);

					logger.info("{}{}VUCH_08 :Response from LockoutHelper.queryLockout : {}", sClassName, sMethodName, hmResult);

					if (hmResult == null || hmResult.isEmpty()) {
						stAppInfo = "hmResult returned null / empty response";
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
						logger.info("{}{}VUCH_09 : {}", sClassName, sMethodName, stAppInfo);
						return hmResult;
					}
					stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

					if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
						stAppInfo = (String) hmResult.get(MPSDefs.APP_INFO);
						logger.info("{}{}VUCH_10 : {}", sClassName, sMethodName, stAppInfo);
						return hmResult;
					}

					alActiveLocks = (ArrayList) hmResult.get(CommonDefs.ACTIVE_LOCKS);

					if (alActiveLocks != null && !alActiveLocks.isEmpty()) {
						for (HashMap<String, String> hmLock : alActiveLocks) {
							String sDBLockName = hmLock.get(MPSDefs.DB_LOCKOUT_NAME);

							if (sDBLockName.equals(CommonDefs.FORGOT_PASSWORD_PREQUAL)) {
								stAppInfo = "Member is already locked";
								hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_MID_LOCKOUT_NUM, stAppInfo);

								HashMap hmActiveLock = CommonUtil.getHashMap();
								ArrayList alFPActiveLock = CommonUtil.getArrayList();
								alFPActiveLock.add(hmLock);
								hmActiveLock.put(sDBLockName, alFPActiveLock);

								logger.info("{}{}VUCH_11 :Calling convertIntoArrayList with input: {}", sClassName,	sMethodName, hmActiveLock);

								ArrayList alLockList = convertIntoArrayList(hmActiveLock);

								logger.info("{}{}VUCH_12 :Response convertIntoArrayList : {}", sClassName, sMethodName, alLockList);

								if (alLockList != null && !alLockList.isEmpty()) {
									hmResult.put(CommonDefs.LOCK_LIST, alLockList);
								}
								hmResult.put(CommonDefs.HANDLE, sHandle);
								hmResult.put(CommonDefs.DOMAIN, sDomain);
								return hmResult;
							}
						}
					}
					hmQueryLockoutResp.putAll(hmResult);
					hmQueryLockoutResp.remove(CommonDefs.COMMON_APP_CATEGORY_CODE);
					hmQueryLockoutResp.remove(CommonDefs.COMMON_APP_STATUS_CODE);
					hmQueryLockoutResp.remove(CommonDefs.COMMON_APP_STATUS_MSG);
				}
			}

			boolean bDSLDialOPRMember = false;
			String sDBPortalSvcSor = null;

			HashMap hmDBServices = (HashMap) hmGetInfoResp.get(CommonDefs.SERVICES);

			if (hmDBServices != null && hmDBServices.containsKey(CommonDefs.PORTAL_SERVICE)) {
				HashMap hmDBPortalSvc = (HashMap) hmDBServices.get(CommonDefs.PORTAL_SERVICE);
				sDBPortalSvcSor = (String) hmDBPortalSvc.get(CommonDefs.SOR_NAME);
			}

			if ((sDBAccessName != null
					&& (sDBAccessName.equals(MPSDefs.DIAL_SERVICE) || sDBAccessName.equals(MPSDefs.DSL_SERVICE)))
					|| (sDBPortalSvcSor != null && sDBPortalSvcSor.equals(MPSDefs.SOR_OPR))) {
				bDSLDialOPRMember = true;
			}

			if (bDSLDialOPRMember) {
				if (sDBAccessName.equals(MPSDefs.DIAL_SERVICE) && (hmDBServices == null || !hmDBServices.containsKey(MPSDefs.DIAL_SERVICE))) {
					stAppInfo = "User does not have required service as access_name " + sDBAccessName;
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_NO_SERVICE_NUM, stAppInfo);
					logger.info("{}{}VUCH_13 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}

				if (sDBAccessName.equals(MPSDefs.DSL_SERVICE) && (hmDBServices == null || !hmDBServices.containsKey(MPSDefs.DSL_SERVICE))) {
					stAppInfo = "User does not have required service as access_name " + sDBAccessName;
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_NO_SERVICE_NUM, stAppInfo);
					logger.info("{}{}VUCH_14 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
			}
			if (validateUserCredentialsRequest.getUserCredentials().getBillingZip() !=null) {
				if (!CommonDefs.SLID_DUM.equals(sDomain)) {
					if (!CommonDefs.SOR_LS.equals(sDBSor)) {
						stAppInfo = "User member level sor is not LS for input credentials element : "+ CommonDefs.BILLING_ZIP;
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
						logger.info("{}{}VUCH_15 : {}", sClassName, sMethodName, stAppInfo);
						return hmResult;
					}

					if (sDBParentChildInd.equals(CommonDefs.CHILD_INDICATOR)) {
						stAppInfo = "User credentials element contains billingZip but user is sub account";
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_NOT_PARENT_NUM, stAppInfo);
						logger.info("{}{}VUCH_16 : {}", sClassName, sMethodName, stAppInfo);
						return hmResult;
					}
				}
			}
			if (validateUserCredentialsRequest.getUserCredentials().getProofZip() != null) {
				if (!CommonDefs.SLID_DUM.equals(sDomain) && !CommonDefs.SOR_LS.equals(sDBSor) && bDSLDialOPRMember == false) {
					stAppInfo = "ProofZip is allowed for all LS & all ISP MIDs only";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
					logger.info("{}{}VUCH_17 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
			}

			if (validateUserCredentialsRequest.getUserCredentials().getContactEmail() != null) {
				if (!CommonDefs.SLID_DUM.equals(sDomain)
						&& (hmDBServices == null || (!hmDBServices.containsKey(CommonDefs.ECOMM_SERVICE)
						&& !hmDBServices.containsKey(CommonDefs.UVERSE_SERVICE)))) {
					if (!"COLA".equals(sDBSor) && !"CPR".equals(sDBSor)) {
						stAppInfo = "User does not have required service for input credential element :" + CommonDefs.CONTACT_EMAIL;
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
						logger.info("{}{}VUCH_18 : {}", sClassName, sMethodName, stAppInfo);
						return hmResult;
					}
				}
			}

			boolean isCredentialsMatched = true;
			HashMap hmCGResponse = null;
			String sBillingZip = validateUserCredentialsRequest.getUserCredentials().getBillingZip();
			String sProofZip = validateUserCredentialsRequest.getUserCredentials().getProofZip();
			String sContactEmail = validateUserCredentialsRequest.getUserCredentials().getContactEmail();
			String sLastFourSSN = validateUserCredentialsRequest.getUserCredentials().getLastFourSSN();
			String sDateOfBirth = validateUserCredentialsRequest.getUserCredentials().getDateOfBirth();
			String sLastName = validateUserCredentialsRequest.getUserCredentials().getLastName();

			if (sContactEmail != null && isCredentialsMatched) {
				sContactEmail = sContactEmail.trim().toLowerCase();
				String cgContactEmail = null;
				if (sDBParentChildInd != null && sDBParentChildInd.equalsIgnoreCase(MPSDefs.MPS_PARENT)	&& sDBSor != null &&
						sDBSor.equalsIgnoreCase(CommonDefs.SOR_LS)) {

					logger.info("{}{}VUCH_19 :Calling callCGCustomerSearch with input : {}", sClassName, sMethodName, sDBBan);
					hmContactDetails = callCGCustomerSearch(sDBBan);
					logger.info("{}{}VUCH_20 :Response callCGCustomerSearch : {}", sClassName, sMethodName, hmContactDetails);

					if (hmContactDetails == null || hmContactDetails.isEmpty()) {
						stAppInfo = "getCGSyncCall returned null / empty response";
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
						logger.info("{}{}VUCH_21.1: {} ", sClassName, sMethodName, stAppInfo);
						return hmResult;
					}
					stAppStatusCode = (String) hmContactDetails.get(CErrorDefs.COMMON_APP_STATUS_CODE);
					if (stAppStatusCode != null && !CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
						stAppInfo = (String) hmContactDetails.get(CErrorDefs.COMMON_APP_INFO);
						logger.info("{}{}VUCH_21.2: {} ", sClassName, sMethodName, stAppInfo);
						return hmContactDetails;
					}

					if (hmContactDetails != null && !hmContactDetails.isEmpty()) {
						cgContactEmail = (String) hmContactDetails.get(CommonDefs.CONTACT_EMAIL);
					}

					if (cgContactEmail == null || cgContactEmail.isEmpty() || !cgContactEmail.trim().equalsIgnoreCase(sContactEmail)) {
						isCredentialsMatched = false;
					}
				} else {
					String sDbContactEmail = (String) hmGetInfoResp.get(CommonDefs.DB_CONTACT_EMAIL);
					sDbContactEmail = (sDbContactEmail == null) ? "" : sDbContactEmail.trim().toLowerCase();

					if (!sContactEmail.trim().equalsIgnoreCase(sDbContactEmail)) {
						isCredentialsMatched = false;
					}
				}
			}

			if (sProofZip != null && isCredentialsMatched) {
				String sDbProofZip = (String) hmGetInfoResp.get(MPSDefs.DB_PROOFING_ZIP);
				String sFirstFiveDigitsDbProofZip = null;
				if (sDbProofZip != null && sDbProofZip.length() >= 5)
					sFirstFiveDigitsDbProofZip = sDbProofZip.substring(0, 5);

				if (!sProofZip.equals(sFirstFiveDigitsDbProofZip)) {
					isCredentialsMatched = false;
				}
			}

			if (sLastFourSSN != null && isCredentialsMatched) {
				String sDbLast4SSN = (String) hmGetInfoResp.get(MPSDefs.DB_LAST_FOUR_SSN);
				if (!sLastFourSSN.equals(sDbLast4SSN)) {
					isCredentialsMatched = false;
				}
			}

			if (sDateOfBirth != null && isCredentialsMatched) {
				String sDbBirthDateVenc = (String) hmGetInfoResp.get(MPSDefs.DB_BIRTHDATE_VENC);
				if (sDbBirthDateVenc != null && !sDbBirthDateVenc.isEmpty()) {
					HashMap hmDecryptionInput = CommonUtil.getHashMap();
					hmDecryptionInput.put(MPSDefs.DB_BIRTHDATE_VENC, sDbBirthDateVenc);

					logger.info("{}{}VUCH_22 :calling ProofingEncryptionHelper.getDecryptedValues with input :{}", sClassName, sMethodName, hmDecryptionInput);

					HashMap hmResponse = proofingEncryptionHelper.getDecryptedValues(hmDecryptionInput);

					logger.info("{}{}VUCH_23 :Response ProofingEncryptionHelper.getDecryptedValues :{}", sClassName,	sMethodName, hmResponse);

					String sClearBirthDate = null;
					if (hmResponse != null && hmResponse.containsKey(MPSDefs.DB_BIRTHDATE_VENC)) {
						sClearBirthDate = (String) hmResponse.get(MPSDefs.DB_BIRTHDATE_VENC);
					}
					if (!sDateOfBirth.equals(sClearBirthDate)) {
						isCredentialsMatched = false;
					}
				} else {
					isCredentialsMatched = false;
				}
			}

			if (sBillingZip != null && isCredentialsMatched) {
				String sFirstFiveDigitsCgBillingZip = null;
				String sCgBillingZip = null;

				if (hmContactDetails != null && !hmContactDetails.isEmpty()) {
					sCgBillingZip = (String) hmContactDetails.get(CommonDefs.BILLING_ZIP);
				} else if (sDBBan == null || sDBBan.trim().isEmpty()) {
					String sAppInfo = "Ban not found in DB";
					logger.info("{}{}VUCH_24 : {}", sClassName, sMethodName, sAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_BAN_NOT_FOUND_NUM, sAppInfo);
					return hmResult;
				} else {
					logger.info("{}{}VUCH_24.1 :Calling callCGCustomerSearch with input : {}", sClassName, sMethodName, sDBBan);
					hmContactDetails = callCGCustomerSearch(sDBBan);
					logger.info("{}{}VUCH_12 :Response callCGCustomerSearch : {}", sClassName, sMethodName, hmContactDetails);

					if (hmContactDetails == null || hmContactDetails.isEmpty()) {
						stAppInfo = "getCGSyncCall returned null / empty response";
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
						logger.info("{}{}VUCH_24.2: {} ", sClassName, sMethodName, stAppInfo);
						return hmResult;
					}
					stAppStatusCode = (String) hmContactDetails.get(CErrorDefs.COMMON_APP_STATUS_CODE);
					if (stAppStatusCode != null && !CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
						stAppInfo = (String) hmContactDetails.get(CErrorDefs.COMMON_APP_INFO);
						logger.info("{}{}VUCH_24.3: {} ", sClassName, sMethodName, stAppInfo);
						return hmContactDetails;
					}

					if (hmContactDetails != null && !hmContactDetails.isEmpty()) {
						sCgBillingZip = (String) hmContactDetails.get(CommonDefs.BILLING_ZIP);
					}
				}
				if (sCgBillingZip != null && sCgBillingZip.length() >= 5) {
					sFirstFiveDigitsCgBillingZip = sCgBillingZip.substring(0, 5);
				}
				if (!sBillingZip.equals(sFirstFiveDigitsCgBillingZip)) {
					isCredentialsMatched = false;
				}
			}

			if (sLastName != null && !sLastName.isEmpty() && isCredentialsMatched) {
				String sDbLastName = (String) hmGetInfoResp.get(MPSDefs.DB_LC_LASTNAME);
				String sTempLastName = sLastName;
				if (sTempLastName != null && !sTempLastName.isEmpty()) {
					sTempLastName = sTempLastName.replaceAll("[^a-zA-Z0-9]+", "");
					sTempLastName = sTempLastName.trim();
				}
				if (sDbLastName != null && !sDbLastName.isEmpty()) {
					sDbLastName = sDbLastName.replaceAll("[^a-zA-Z0-9]+", "");
					sDbLastName = sDbLastName.trim();
				}
				if (sDbLastName == null || sDbLastName.isEmpty()) {
					stAppInfo = "LastName not found on db";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CREDENTIAL_NOT_ON_FILE_NUM, stAppInfo);
					logger.info("{}{}VUCH_27 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
				if (!sTempLastName.equalsIgnoreCase(sDbLastName)) {
					isCredentialsMatched = false;
				}
			}
			HashMap hmMemberDetailForLock = new HashMap<>();
			hmMemberDetailForLock.put(CommonDefs.HANDLE, hmGetInfoResp.get(MPSDefs.DB_MEMBER_NAME));
			hmMemberDetailForLock.put(CommonDefs.DOMAIN, hmGetInfoResp.get(MPSDefs.DB_DOMAIN_NAME));
			if (hmGetInfoResp.containsKey(CommonDefs.KEY_SLID_INFO)) {
				hmMemberDetailForLock.put(MPSDefs.DB_MEMBER_NUM, hmGetInfoResp.get(MPSDefs.DB_SLID_MEMBER_NUM));
				HashMap hmDBSlidInfo = (HashMap) hmGetInfoResp.get(CommonDefs.KEY_SLID_INFO);
				if (hmDBSlidInfo != null && !hmDBSlidInfo.isEmpty()) {
					hmMemberDetailForLock.put(CommonDefs.SLID, hmDBSlidInfo.get(MPSDefs.DB_MEMBER_NAME));
				}
			} else {
				hmMemberDetailForLock.put(MPSDefs.DB_MEMBER_NUM, hmGetInfoResp.get(MPSDefs.DB_MEMBER_NUM));
			}

			hmMemberDetailForLock.put(MPSDefs.DB_PARENT_NAME, hmGetInfoResp.get(MPSDefs.DB_PARENT_NAME));
			hmMemberDetailForLock.put(MPSDefs.DB_PARENT_DOMAIN, hmGetInfoResp.get(MPSDefs.DB_PARENT_DOMAIN));

			if (hmQueryLockoutResp != null && !hmQueryLockoutResp.isEmpty()) {
				hmMemberDetailForLock.put(CommonDefs.QUERY_LOCKOUT_RESPONSE, hmQueryLockoutResp);
			}
			hmMemberDetailForLock.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
			hmMemberDetailForLock.put(CommonDefs.TRANSACTION_ID, sTransactionId);
			hmMemberDetailForLock.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);

			if (isCredentialsMatched) {
				hmResult = processUserLocks(hmMemberDetailForLock, CommonDefs.VALIDATION_STATUS_SUCCESS);

				if (hmResult == null || hmResult.isEmpty()) {
					stAppInfo = "processUserLocks returned null / empty response ";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					logger.info("{}{}VUCH_30.01 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
				stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
				stAppStatusMsg = (String) hmResult.get(MPSDefs.APP_STATUS_MSG);

				if (stAppStatusCode != null && !(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) && !(CErrorDefs.INF_NO_ACTION_TAKEN_MSG.equals(stAppStatusMsg))) {
					stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
					logger.info("{}{}VUCH_30 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
				hmResult.put(CommonDefs.HANDLE, hmMemberDetailForLock.get(CommonDefs.HANDLE));
				hmResult.put(CommonDefs.DOMAIN, hmMemberDetailForLock.get(CommonDefs.DOMAIN));
				hmResult.put(CommonDefs.SLID, hmMemberDetailForLock.get(CommonDefs.SLID));

				String sUserLockLevel = (String) hmGetInfoResp.get(MPSDefs.DB_USER_LOCK_LEVEL);
				String sUserLockedReasonCode = (String) hmGetInfoResp.get(MPSDefs.DB_USER_LOCK_REASON);

				if (sUserLockLevel != null && sUserLockLevel.trim().length() > 0
						&& (sUserLockLevel.equals(CommonDefs.USER_LOCK_LEVEL_ONE)
						|| sUserLockLevel.equals(CommonDefs.USER_LOCK_LEVEL_TWO))) {
					hmResult.put(CommonDefs.USER_LOCK_LEVEL, sUserLockLevel);
					hmResult.put(CommonDefs.USER_LOCK_REASON_CODE, sUserLockedReasonCode);
				}
				if (validateUserCredentialsRequest.getReturnOnlineSecurityQuestions() != null) {

					String sReturnOnlineSecurityQuestion = validateUserCredentialsRequest.getReturnOnlineSecurityQuestions();
					if (sReturnOnlineSecurityQuestion != null && sReturnOnlineSecurityQuestion.equalsIgnoreCase(CommonDefs.IND_Y)) {
						String sOnlSecQue1 = (String) hmGetInfoResp.get(MPSDefs.DB_SECURITY_QUESTION_1);
						String sOnlSecQue2 = (String) hmGetInfoResp.get(MPSDefs.DB_SECURITY_QUESTION_2);
						String sOnlQAEstDate = (String) hmGetInfoResp.get(MPSDefs.DB_ONL_QA_EST_DATE);
						if (sUserLockLevel != null
								&& (sUserLockLevel.equals(CommonDefs.USER_LOCK_LEVEL_ONE)
								|| sUserLockLevel.equals(CommonDefs.USER_LOCK_LEVEL_TWO))
								&& sOnlQAEstDate != null) {
							boolean bOnlineQANotAged = validateOnlineQAEstDate(sOnlQAEstDate);
							if (!bOnlineQANotAged) {
								if (sOnlSecQue1 != null && !sOnlSecQue1.isEmpty()) {
									hmResult.put(CommonDefs.ONLINE1_SECURITY_QUESTION, sOnlSecQue1);
								}
								if (sOnlSecQue2 != null && !sOnlSecQue2.isEmpty()) {
									hmResult.put(CommonDefs.ONLINE2_SECURITY_QUESTION, sOnlSecQue2);
								}
							}
						} else {
							hmResult.put(CommonDefs.ONLINE1_SECURITY_QUESTION, sOnlSecQue1);
							hmResult.put(CommonDefs.ONLINE2_SECURITY_QUESTION, sOnlSecQue2);
						}
					}
				}
			} else {

				hmResult = processUserLocks(hmMemberDetailForLock, CommonDefs.VALIDATION_STATUS_FAILURE);

				if (hmResult == null || hmResult.isEmpty()) {
					stAppInfo = "ProcessUserLocks returned null / empty response ";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					logger.info("{}{}VUCH_31.4 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
				stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
				stAppStatusMsg = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG);
				ArrayList alLockList = convertIntoArrayList(hmResult);

				if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					if (stAppStatusMsg != null && !(CErrorDefs.ERR_MID_LOCKOUT_MSG.equals(stAppStatusMsg))) {
						stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
						logger.info("{}{}VUCH_32 : {}", sClassName, sMethodName, stAppInfo);
						return hmResult;
					} else {
						hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppStatusMsg);
						if (alLockList != null && !alLockList.isEmpty()) {
							hmResult.put(CommonDefs.LOCK_LIST, alLockList);
						}
						return hmResult;
					}
				}
				stAppInfo = "User credentials are invalid";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_CREDENTIALS_NUM, stAppInfo);
				if (alLockList != null && !alLockList.isEmpty()) {
					hmResult.put(CommonDefs.LOCK_LIST, alLockList);
				}
			}
		}catch(Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
		} finally {
			logger.info("{}{}HLP999 :: {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;
	}


	/**
	 * This method retrieves member services information from the database.
	 * It takes a HashMap containing the input parameters and returns a HashMap with the response data.
	 * The method logs the input parameters, calls the GetMemberServicesDBHelper to get the member services,
	 * and handles any exceptions that may occur during the process.
	 * If the response from GetMemberServicesDBHelper is null or empty, it creates an error map with the appropriate error message.
	 *
	 * @param hmGetInfoInp A HashMap containing the input parameters for retrieving member services.
	 * @return A HashMap containing the response data from GetMemberServicesDBHelper, or an error map if an exception occurs or the response is null / empty.
	 */
	private HashMap getmemberService(HashMap hmGetInfoInp) {

		String sMethodName = ".getmemberService.";
		String stAppInfo = null;
		HashMap hmGetInfoResp = null;
		try {
			logger.info("{}{}VUCH_04.1 :Calling to GetMemberServicesDBHelper.getMemberServices with input : {}", sClassName, sMethodName, hmGetInfoInp);
			hmGetInfoResp = getMemberServicesDBHelper.getMemberServices(hmGetInfoInp);
			logger.debug("{}{}VUCH_04.2 :Response from GetMemberServicesDBHelper.getMemberServices : {}", sClassName, sMethodName, hmGetInfoResp);

			if (hmGetInfoResp == null || hmGetInfoResp.isEmpty()) {
				stAppInfo = "GetMemberServicesDBHelper.getMemberServices returned null / empty response";
				hmGetInfoResp = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}VUCH_04.3 : {}", sClassName, sMethodName, stAppInfo);
				return hmGetInfoResp;
			}
		} catch (Exception e) {
			hmGetInfoResp = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown from  GetMemberServicesDBHelper.getMemberServices method : " + hmGetInfoResp;
			logger.error("{}{}VUCH_04.4 : {}", sClassName, sMethodName, stAppInfo);
			return hmGetInfoResp;
		}
		return hmGetInfoResp;
	}

	/**
	 * This method converts a HashMap of lockout responses into an ArrayList.
	 * It takes a HashMap containing the lockout responses and returns an ArrayList with the processed lockout data.
	 * The method first parses the member interested locks and response keys mapping from the properties.
	 * Then, it iterates over the member interested locks and processes each lockout response.
	 * For each lockout response, it maps the response keys to new keys based on the response keys mapping.
	 * Finally, it adds the processed lockout data to the total locks ArrayList and returns it.
	 *
	 * @param hmUpdLockoutResp A HashMap containing the lockout responses.
	 * @return An ArrayList containing the processed lockout data.
	 * @throws Exception If there is an error during the processing.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private ArrayList convertIntoArrayList(HashMap hmUpdLockoutResp) throws Exception {

		ArrayList<HashMap> alTotalLocks = new ArrayList();
		ArrayList alMemberInterestedLocks = null;
		if (memberInterestedLocks != null && !memberInterestedLocks.isEmpty()) {
			alMemberInterestedLocks = CommonUtil.parseToArray(memberInterestedLocks, CommonDefs.VALUE_SEPARATOR_CHAR);
		}

		HashMap hmResponseKeysMapping = null;
		if (validateCredentialsResponseKeysMapping != null && !validateCredentialsResponseKeysMapping.isEmpty()) {
			hmResponseKeysMapping = CommonUtil.parsePropertyToHash(validateCredentialsResponseKeysMapping);
		}

		if (alMemberInterestedLocks != null && !alMemberInterestedLocks.isEmpty()) {
			ArrayList alLockList = new ArrayList();

			for (int i = 0; i < alMemberInterestedLocks.size(); i++) {

				String fieldName = (String) alMemberInterestedLocks.get(i);

				if (hmUpdLockoutResp != null && hmUpdLockoutResp.containsKey(fieldName)) {

					alLockList = (ArrayList) hmUpdLockoutResp.get(fieldName);
					if (alLockList != null && !alLockList.isEmpty()) {
						HashMap hmEachLock = (HashMap) alLockList.get(0);
						Iterator iter = hmResponseKeysMapping.keySet().iterator();
						HashMap hmNewEachLock = new HashMap();
						while (iter.hasNext()) {
							String sDBfieldName = (String) iter.next();
							String fieldValue = (String) hmEachLock.get(sDBfieldName);
							if (fieldValue != null && fieldValue.trim().length() > 0) {
								String stNewfieldName = (String) hmResponseKeysMapping.get(sDBfieldName);
								hmNewEachLock.put(stNewfieldName, fieldValue);
							}
						}
						alLockList.remove(hmEachLock);
						alLockList.add(hmNewEachLock);
					}
				}
			}
			alTotalLocks.addAll(alLockList);
		}
		return alTotalLocks;
	}

	/**
	 * processUserLocks will check for the active locks, expired locks and NENA
	 * locks and perform insertion ,updation, deletion according to the validation
	 * status.
	 *
	 * @param hmMemberDetailForLock
	 * @param sLockStatus
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private HashMap processUserLocks(HashMap hmMemberDetailForLock, String sLockStatus) {
		String sMethodName = ".processUserLocks.";
		HashMap<String, Object> hmResult = new HashMap<>();
		HashMap<String, Object> hmLHUpdateInput = new HashMap<>();
		String sAppInfo = null;
		logger.info("{}{}VUCH_27.1 : Logging Input Hash : {}", sClassName, sMethodName, hmMemberDetailForLock);
		String sMemberNum = (String) hmMemberDetailForLock.get(MPSDefs.DB_MEMBER_NUM);
		String sHandle = (String) hmMemberDetailForLock.get(CommonDefs.HANDLE);
		String sDomain = (String) hmMemberDetailForLock.get(CommonDefs.DOMAIN);
		String sTransactionId = (String) hmMemberDetailForLock.get(CommonDefs.TRANSACTION_ID);
		String sCallingSystemId = (String) hmMemberDetailForLock.get(CommonDefs.CALLING_SYSTEM_ID);
		String sTransactionName = (String) hmMemberDetailForLock.get(CommonDefs.TRANSACTION_NAME);

		HashMap<String, Object> hmQueryLockoutResp = (HashMap<String, Object>) hmMemberDetailForLock.get(CommonDefs.QUERY_LOCKOUT_RESPONSE);
		// if the member has locks in MPS
		if (hmQueryLockoutResp != null && !hmQueryLockoutResp.isEmpty()) {
			ArrayList<HashMap<String, Object>> alActiveFPLocks = new ArrayList<>();
			ArrayList<HashMap<String, Object>> alExpiredFPLocks = new ArrayList<>();
			ArrayList<HashMap<String, Object>> alNENAFPLocks = new ArrayList<>();

			ArrayList alActiveLocks = (ArrayList) hmQueryLockoutResp.get(CommonDefs.ACTIVE_LOCKS);
			ArrayList alExpiredLocks = (ArrayList) hmQueryLockoutResp.get(CommonDefs.EXPIRED_LOCKS);
			ArrayList alNENALocks = (ArrayList) hmQueryLockoutResp.get(CommonDefs.NONEXPIRED_NONACTIVE_LOCKS);
			logger.info("{}{}VUCH_27.2 : Logging alActiveLocks : {},alExpiredLocks : {},nonExpiredNonActiveLocks : {}",	sClassName, sMethodName,
					alActiveLocks == null?alActiveLocks:StringUtils.normalizeSpace(alActiveLocks.toString()),
					alExpiredLocks == null?alExpiredLocks:StringUtils.normalizeSpace(alExpiredLocks.toString()),
					alNENALocks == null?alNENALocks:StringUtils.normalizeSpace(alNENALocks.toString()));

			hmLHUpdateInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
			hmLHUpdateInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
			hmLHUpdateInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
			boolean isNewFPLockAdded = false;

			if (alActiveLocks != null && !alActiveLocks.isEmpty()) {
				boolean isFPLockFound = false;
				for (int i = 0; i < alActiveLocks.size(); i++) {
					HashMap<String, Object> hmEachLock = (HashMap<String, Object>) alActiveLocks.get(i);
					logger.debug("{}{}VUCH_27.3 : Logging each active lock : {}", sClassName, sMethodName, hmEachLock);
					String sLockName = null;
					if (hmEachLock != null)
						sLockName = (String) hmEachLock.get(MPSDefs.DB_LOCKOUT_NAME);
					logger.debug("{}{}VUCH_27.4 : Logging LockName : {}", sClassName, sMethodName, sLockName);
					if (sLockName != null && sLockName.equals(CommonDefs.FORGOT_PASSWORD_PREQUAL)) {
						isFPLockFound = true;
						logger.info("{}{}VUCH_27.5 : FPLock Found : ", sClassName, sMethodName);
						if (sLockStatus != null && sLockStatus.equals(CommonDefs.VALIDATION_STATUS_SUCCESS)) {
							alActiveFPLocks.add(hmEachLock);
							hmLHUpdateInput.put(CommonDefs.ACTIVE_LOCKS, alActiveFPLocks);
						}
						if (sLockStatus != null && sLockStatus.equals(CommonDefs.VALIDATION_STATUS_FAILURE)) {
							sAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
							logger.info("{}{}VUCH_27.6 : {}", sClassName, sMethodName,
									HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
							hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_MID_LOCKOUT_NUM, sAppInfo);
							return hmResult;
						}
					}
				} // end iteration through alActiveLocks.
				if (!isFPLockFound && sLockStatus.equals(CommonDefs.VALIDATION_STATUS_FAILURE)) {
					isNewFPLockAdded = true;
					HashMap<String, Object> hmFPLock = new HashMap<>();
					hmFPLock.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);
					hmFPLock.put(MPSDefs.DB_LOCKOUT_NAME, CommonDefs.FORGOT_PASSWORD_PREQUAL);
					ArrayList<HashMap<String, Object>> alNewFPLocks = new ArrayList<HashMap<String, Object>>();
					alNewFPLocks.add(hmFPLock);
					hmLHUpdateInput.put(CommonDefs.NEW_LOCKS, alNewFPLocks);
				}
			} // end If: alActiveLocks is not null and alActiveLocks.size()>0.

			if (alExpiredLocks != null && !alExpiredLocks.isEmpty()) {
				boolean isFPLockFound = false;
				for (int i = 0; i < alExpiredLocks.size(); i++) {
					HashMap<String, Object> hmEachLock = (HashMap<String, Object>) alExpiredLocks.get(i);
					logger.debug("{}{}VUCH_27.7 :Logging each expired lock :  {}", sClassName, sMethodName, hmEachLock);
					String sLockName = null;
					if (hmEachLock != null)
						sLockName = (String) hmEachLock.get(MPSDefs.DB_LOCKOUT_NAME);
					logger.debug("{}{}VUCH_27.8 :Logging LockName :  {}", sClassName, sMethodName, sLockName);
					if (sLockName != null && sLockName.equals(CommonDefs.FORGOT_PASSWORD_PREQUAL)) {
						isFPLockFound = true;
						logger.info("{}{}VUCH_27.9 :FPLock Found", sClassName, sMethodName);
						alExpiredFPLocks.add(hmEachLock);
						if (hmLHUpdateInput.containsKey(CommonDefs.NEW_LOCKS)) {
							hmLHUpdateInput.remove(CommonDefs.NEW_LOCKS);
						}
					}

				} // end iteration through alExpiredLocks.
				ArrayList<HashMap<String, Object>> alNewFPLocks = new ArrayList<>();
				if (!isFPLockFound && !isNewFPLockAdded && sLockStatus.equals(CommonDefs.VALIDATION_STATUS_FAILURE)) {
					logger.info("{}{}VUCH_28.1 :FPLock NOT Found : ", sClassName, sMethodName);
					isNewFPLockAdded = true;
					HashMap<String, Object> hmFPLock = new HashMap<>();
					hmFPLock.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);
					hmFPLock.put(MPSDefs.DB_LOCKOUT_NAME, CommonDefs.FORGOT_PASSWORD_PREQUAL);
					alNewFPLocks.add(hmFPLock);
				}
				if (alExpiredFPLocks != null && !alExpiredFPLocks.isEmpty()) {
					hmLHUpdateInput.put(CommonDefs.EXPIRED_LOCKS, alExpiredFPLocks);
				}
				if (alNewFPLocks != null && !alNewFPLocks.isEmpty()) {
					hmLHUpdateInput.put(CommonDefs.NEW_LOCKS, alNewFPLocks);
				}
			} // end If: alExpiredLocks is not null and alExpiredLocks.size()>0.

			if (alNENALocks != null && !alNENALocks.isEmpty()) {
				boolean isFPLockFound = false;
				for (int i = 0; i < alNENALocks.size(); i++) {
					HashMap<String, Object> hmEachLock = (HashMap<String, Object>) alNENALocks.get(i);
					logger.debug("{}{}VUCH_28.2 :Logging each non expired non active lock : {}", sClassName, sMethodName, hmEachLock);
					String sLockName = null;
					if (hmEachLock != null)
						sLockName = (String) hmEachLock.get(MPSDefs.DB_LOCKOUT_NAME);
					logger.debug("{}{}VUCH_28.3 :Logging LockName : {}", sClassName, sMethodName, sLockName);
					if (sLockName != null && sLockName.equals(CommonDefs.FORGOT_PASSWORD_PREQUAL)) {
						isFPLockFound = true;
						logger.debug("{}{}VUCH_28.4 :FPLock Found", sClassName, sMethodName);
						alNENAFPLocks.add(hmEachLock);
						if (hmLHUpdateInput.containsKey(CommonDefs.NEW_LOCKS)) {
							hmLHUpdateInput.remove(CommonDefs.NEW_LOCKS);
						}

					} // end if: sLockName= FORGOT_PASSWORD_PREQUAL.
				} // end iteration through alNENALocks.
				ArrayList<HashMap<String, Object>> alNewFPLocks = new ArrayList<>();
				if (!isFPLockFound && !isNewFPLockAdded && sLockStatus.equals(CommonDefs.VALIDATION_STATUS_FAILURE)) {
					logger.info("{}{}VUCH_28.5 :FPLock NOT Found", sClassName, sMethodName);
					isNewFPLockAdded = true;
					HashMap<String, Object> hmFPLock = new HashMap<>();
					hmFPLock.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);
					hmFPLock.put(MPSDefs.DB_LOCKOUT_NAME, CommonDefs.FORGOT_PASSWORD_PREQUAL);
					alNewFPLocks.add(hmFPLock);
				}
				if (alNENAFPLocks != null && !alNENAFPLocks.isEmpty()) {
					hmLHUpdateInput.put(CommonDefs.NONEXPIRED_NONACTIVE_LOCKS, alNENAFPLocks);
				}
				if (alNewFPLocks != null && !alNewFPLocks.isEmpty()) {
					hmLHUpdateInput.put(CommonDefs.NEW_LOCKS, alNewFPLocks);
				}
			} // end If: alNENALocks is not null and alNENALocks.size()>0.

			hmLHUpdateInput.put(CommonDefs.VALIDATION_STATUS, sLockStatus);
			hmLHUpdateInput.put(CommonDefs.HANDLE, sHandle);
			hmLHUpdateInput.put(CommonDefs.DOMAIN, sDomain);
			hmLHUpdateInput.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);

			if (hmLHUpdateInput != null && (hmLHUpdateInput.containsKey(CommonDefs.NEW_LOCKS)
					|| hmLHUpdateInput.containsKey(CommonDefs.EXPIRED_LOCKS)
					|| hmLHUpdateInput.containsKey(CommonDefs.NONEXPIRED_NONACTIVE_LOCKS))) {
				// calling lockout helper update
				if (sCallingSystemId != null && sCallingSystemId.equals(CommonDefs.CALLING_SYSTEM_CGATE) && sLockStatus.equals(CommonDefs.VALIDATION_STATUS_FAILURE)) {
					sAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
					logger.info("{}{}VUCH_28.6 :Calling system = CGATE and Validation Status=FAILURE, No action taken by LockoutHelper", sClassName, sMethodName);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.INF_NO_ACTION_TAKEN_NUM, CommonDefs.VALIDATION_STATUS_SUCCESS);
					return hmResult;
				} else {
					hmLHUpdateInput.put(CommonDefs.CALLMPS, Boolean.FALSE);
					logger.debug("{}{}VUCH_28.7 :Calling LockoutHelper.updateLockout with Input parameters  : {}", sClassName, sMethodName, hmLHUpdateInput);
					hmResult = (HashMap<String, Object>) lockoutHelper.updateLockout(hmLHUpdateInput);
					logger.debug("{}{}VUCH_28.8 :Response from LockoutHelper.updateLockout   : {}", sClassName, sMethodName, hmResult);
				}
			} else {
				logger.info("{}{}VUCH_28.9 :Validation SUCCESS: No action taken by LockoutHelper", sClassName, sMethodName);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.INF_NO_ACTION_TAKEN_NUM, CommonDefs.VALIDATION_STATUS_SUCCESS);
				return hmResult;
			}
		} // end if : hmQueryLockoutResp is not null.

		else if (sLockStatus.equals(CommonDefs.VALIDATION_STATUS_FAILURE)) // member does not have locks in MPS
		{
			HashMap<String, Object> hmFPLock = new HashMap<>();
			hmFPLock.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);
			hmFPLock.put(MPSDefs.DB_LOCKOUT_NAME, CommonDefs.FORGOT_PASSWORD_PREQUAL);
			ArrayList<HashMap<String, Object>> alFPLocks = new ArrayList<>();
			alFPLocks.add(hmFPLock);
			hmLHUpdateInput.put(CommonDefs.NEW_LOCKS, alFPLocks);
			hmLHUpdateInput.put(CommonDefs.VALIDATION_STATUS, sLockStatus);
			hmLHUpdateInput.put(CommonDefs.HANDLE, sHandle);
			hmLHUpdateInput.put(CommonDefs.DOMAIN, sDomain);
			hmLHUpdateInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
			hmLHUpdateInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
			hmLHUpdateInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
			// calling lockout helper update
			if (sCallingSystemId != null && sCallingSystemId.equals(CommonDefs.CALLING_SYSTEM_CGATE)) {
				logger.info("{}{}VUCH_29 :Calling system = CGATE and Validation Status=FAILURE, No action taken by LockoutHelper", sClassName, sMethodName);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.INF_NO_ACTION_TAKEN_NUM, CommonDefs.VALIDATION_STATUS_SUCCESS);
				return hmResult;
			} else {
				hmLHUpdateInput.put(CommonDefs.CALLMPS, Boolean.FALSE);
				logger.debug("{}{}VUCH_29.1 :Calling LockoutHelper.updateLockout with Input parameters  : {}", sClassName, sMethodName, hmLHUpdateInput);
				hmResult = lockoutHelper.updateLockout(hmLHUpdateInput);
				logger.debug("{}{}VUCH_29.2 :Response from LockoutHelper.updateLockout   : {}", sClassName, sMethodName, hmResult);
			}
		} // end if: the member does not have locks in MPS and sLockStatus="FAILURE"
		else {
			logger.info("{}{}AUH_130 :Validation SUCCESS: No action taken by LockoutHelper", sClassName, sMethodName);
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.INF_NO_ACTION_TAKEN_NUM, CommonDefs.VALIDATION_STATUS_SUCCESS);
			return hmResult;
		}
		return hmResult;
	}

	/**
	 * This method validates the online QA establishment date.
	 * It checks if the online QA establishment date is not aged based on the security_QA_AgingDays.
	 * If the online QA establishment date is not aged, it returns true. Otherwise, it returns false.
	 *
	 * @param sOnlineQAEstDate A string representing the online QA establishment date. It should be in the format "MMddyyyy HH:mm:ss".
	 * @return A boolean indicating whether the online QA establishment date is not aged. Returns true if the online QA establishment date is not aged, and false otherwise.
	 */
	@SuppressWarnings("rawtypes")
	public static boolean validateOnlineQAEstDate(String sOnlineQAEstDate) {

		String sMethodName = ".validateOnlineQAEstDate.";
		HashMap hmResult = CommonUtil.getHashMap();
		String stAppInfo = null;
		boolean bOnlineQADateNotAged = false;

		try {
			if (sOnlineQAEstDate != null && !sOnlineQAEstDate.isEmpty()) {
				Calendar cal = Calendar.getInstance();
				DateFormat dtFmt = new SimpleDateFormat("MMddyyyy HH:mm:ss");
				Date dtOnlineQAEstDate = dtFmt.parse(sOnlineQAEstDate);
				cal.setTime(dtOnlineQAEstDate);

				logger.info("{}{}VUCH_31 : Property SECURITY_QA_AGING_DAYS : {}", sClassName, sMethodName,	HtmlUtils.htmlEscape(String.valueOf(security_QA_AgingDays)));

				int iPropSecurityQAAgingDays = 0;

				if (security_QA_AgingDays != null && !security_QA_AgingDays.isEmpty()) {
					iPropSecurityQAAgingDays = Integer.parseInt(security_QA_AgingDays);
				}

				cal.add(Calendar.DAY_OF_MONTH, iPropSecurityQAAgingDays);

				Date systemDate = dtFmt.parse(dtFmt.format(new Date()));
				Date dtOnlineEstDate = dtFmt.parse(dtFmt.format(cal.getTime()));
				logger.info("{}{}VUCH_31.1 : dtOnlineEstDate : {} ,systemDate : {}", sClassName, sMethodName, dtOnlineEstDate, systemDate);

				if (dtOnlineEstDate.after(systemDate)) {
					bOnlineQADateNotAged = true;
				}
			}
		} catch (Exception exp) {
			logger.error("{}{}VUCH_31.2 : {}", sClassName, sMethodName, exp);
			stAppInfo = "Exception thrown validateOnlineQAEstDate method : " + hmResult;
			logger.error("{}{}VUCH_31.2.0 : {}", sClassName, sMethodName, stAppInfo);
		}
		logger.info("{}{}VUCH_31.3 : bOnlineQADateNotAged  : {}", sClassName, sMethodName, bOnlineQADateNotAged);
		return bOnlineQADateNotAged;
	}

	/**
	 * This method calls the CG Customer Search API to retrieve customer details based on the provided BAN (Billing Account Number).
	 * It takes a BAN as input and returns a HashMap containing the customer contact details.
	 * The method first checks if the BAN is null or empty and logs an error if it is.
	 * Then, it prepares the input parameters for the CG Customer Search API call and logs the input.
	 * It calls the CGRestClient to get the customer details and logs the response.
	 * If the response is null or empty, it logs an error and returns an error map.
	 * If the response contains an error status code, it logs the error and returns the response.
	 * Otherwise, it formats the CG response and returns the customer contact details.
	 *
	 * @param sDBBan The Billing Account Number (BAN) used to search for customer details.
	 * @return A HashMap containing the customer contact details, or an error map if an error occurs.
	 */
	private HashMap callCGCustomerSearch(String sDBBan) {
		String sMethodName = ".callCGCustomerSearch.";
		HashMap hmResult = null;
		String appInfo = null;
		try {
			if (sDBBan == null || sDBBan.trim().isEmpty()) {
				appInfo = "Ban not found in DB";
				logger.info("{}{}VUCH_24 : {}", sClassName, sMethodName, appInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_BAN_NOT_FOUND_NUM, appInfo);
				return hmResult;
			}
			HashMap<String, Object> hmCGInput = new HashMap<>();
			hmCGInput.put(CommonDefs.ACCOUNT_ID, sDBBan);
			hmCGInput.put("topics", "accounts," + "subscribers");
			hmCGInput.put(CommonConstants.CG_API_NAME, CommonConstants.CG_CUSTOMER_SEARCH_API_NAME);
			hmCGInput.put(CommonConstants.CG_END_POINT, cgEndpoint);
			hmCGInput.put(CommonDefs.SERVICE_TYPE, CommonDefs.UVERSE_SERVICE);

			logger.info("{}{}RQH_TA.3 : Calling CGRestClient.getCGSyncCall with input:{}", sClassName, sMethodName, hmCGInput);

			hmResult = (HashMap) cgRestClient.getCGSyncCall(hmCGInput);

			logger.info("{}{}VUCH_21 :Response CGRestClient.getCGSyncCall : {}", sClassName, sMethodName, hmResult);

			if (hmResult == null || hmResult.isEmpty()) {
				appInfo = "getCGSyncCall returned null / empty response";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, appInfo);
				logger.info("{}{}VUCH_21.1: {} ", sClassName, sMethodName, appInfo);
				return hmResult;
			}
			String stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (stAppStatusCode != null && !CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
				appInfo = (String) hmResult.get(CErrorDefs.COMMON_APP_INFO);
				logger.info("{}{}VUCH_21.2: {} ", sClassName, sMethodName, appInfo);
				return hmResult;
			} else {
				hmResult = formatUverseCGResponse(hmResult);
			}
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			appInfo = "Exception thrown from cgRestClient.getCGSyncCall method : " + hmResult;
			logger.error("{}{}VUCH_04.4 : {}", sClassName, sMethodName, appInfo);
			return hmResult;
		}
		return hmResult;
	}

	/**
	 * This method formats the Uverse CG response.
	 * It extracts the contact email and billing zip code from the given CG response map.
	 * The method first retrieves the account profile response from the CG response map.
	 * Then, it extracts the contact information, including the email address and postal code.
	 * Finally, it creates a result map containing the extracted email address and postal code,
	 * along with a success status code and reason code.
	 *
	 * @param hmCGResponse A map containing the CG response data.
	 * @return A map containing the formatted Uverse CG response, including the contact email and billing zip code.
	 */
	private HashMap<String, Object> formatUverseCGResponse(HashMap<String, Object> hmCGResponse) {
		String thisMethod = ".formatUverseCGResponse.";
		String sCGEmailAddress = null;
		String sCGPostCode = null;
		HashMap<String, Object> hmResult = null;
		HashMap hmAcctProfResponse = null;

		// Retrieve the account profile response from the CG response map
		hmAcctProfResponse = CommonUtil.getMap((HashMap) hmCGResponse, CommonDefs.ACCOUNTS);

		// Extract the contact information from the account profile response
		HashMap hmContact = CommonUtil.getMap(hmAcctProfResponse, "contact");
		if (hmContact != null && !hmContact.isEmpty()) {
			// Extract the email address from the contact information
			HashMap hmEmail = CommonUtil.getMap(hmContact, CommonDefs.EMAIL);
			if (hmEmail != null && !hmEmail.isEmpty()) {
				sCGEmailAddress = (String) hmEmail.get(CommonDefs.EMAIL_ADDRESS);
			}

			// Extract the postal code from the contact information
			HashMap hmAddressInfo = CommonUtil.getMap(hmContact, "address");
			if (hmAddressInfo != null && !hmAddressInfo.isEmpty()) {
				sCGPostCode = (String) hmAddressInfo.get("postCode");
			}
		}

		// Create the result map with the extracted email address and postal code
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.REASON_CODE_SUCCESS);
		hmResult.put(CommonDefs.CONTACT_EMAIL, sCGEmailAddress);
		hmResult.put(CommonDefs.BILLING_ZIP, sCGPostCode);

		logger.info("{}{}RQH_TA.4.1 :  {} ", sClassName, thisMethod, hmResult);

		return hmResult;
	}
}