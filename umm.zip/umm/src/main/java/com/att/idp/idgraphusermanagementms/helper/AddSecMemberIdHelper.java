package com.att.idp.idgraphusermanagementms.helper;

import com.att.idp.idgraphusermanagementms.db.helper.*;
import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.queue.message.helpers.AddSecMemberIdQueueHelper;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.idgraphusermanagementms.utils.RILCheckAndEncryptPasswordHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.*;
import net.logstash.logback.argument.StructuredArguments;
import org.apache.commons.lang.StringUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import jakarta.annotation.PostConstruct;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class AddSecMemberIdHelper extends AbstractDBHelper {

    public static final Logger logger = LoggerFactory.getLogger(AddSecMemberIdHelper.class);

    private static final String CLASS_NAME = "AddSecMemberIdHelper";

    @Autowired
    private GetMemberServicesDBHelper getMemberService;

    @Autowired
    GetProfileByGroupNumDBHelper getProfileByGroupNum;

    @Autowired
    private RILCheckAndEncryptPasswordHelper rilCheckAndEncryptPasswordHelper;

    @Autowired
    LinkMemberHelper linkMemberHelper;

    @Autowired
    private AddUserHelper addUserhelper;

    @Autowired
    private AddSecMemberIdQueueHelper addSecMemberIdQueueHelper;

    @Autowired
    private AddServiceDBHelper addServiceDBHelper;

    @Autowired
    private AddMemberDBHelper addMemberDBHelper;

    @Value("#{'${AddSec_Sub_Eligible_Services}'.split('\\|')}")
    private Set<String> alSubServices;

    @Value("#{'${AddSec_Member_LS_Service}'.split('\\|')}")
    private Set<String> alMemberLSServices;

    @Value("#{'${AddSec_Services_To_MPS}'.split('\\|')}")
    private Set<String> alServicesToMPS;

    @Value("#{'${AddSec_Services_To_Dbus}'.split('\\|')}")
    private Set<String> alServicesToDbus;

    @Value("#{'${AddSec_Notify_Services}'.split('\\|')}")
    private Set<String> alConfigNotifyServices;

    @Value("#{'${AddSec_Uverse_Services}'.split('\\|')}")
    private Set<String> alSubUversrServices;

    @Value("#{'${addSec_Agent_CallingSystemId}'.split('\\|')}")
    private Set<String> alPasswdDirtyCallSysId;

    @Value("#{'${AddSec_Interested_Services}'.split('\\|')}")
    private Set<String> subInterestedServicesList;

    @Value("${AddSec_Allowed_Total_Sub_Accounts}")
    private String AddSecAllowedTotalSubAccounts;

    @Value("${AddSec_Allowed_Total_Active_Sub_Accounts}")
    private String AddSecAllowedTotalActiveSubAccounts;

    @Value("#{'${AddSec_Autogen_Slid_Account_Type}'.split('\\|')}")
    private Set<String> alAutoGenSlidAccountType;

    @Autowired
    private PropertyManagerLoader propertyManagerLoader;

    public AddSecMemberIdHelper(PropertyManagerLoader propertyManagerLoader) {
        super(propertyManagerLoader);
        this.propertyManagerLoader = propertyManagerLoader;
    }

    private static String MPS_SERVICE_KEY = "MPS_SERVICE";
    private static String DBUS_SERVICE_KEY = "DBUS_SERVICE";

    String externalPortalInd;
    String sor;
    boolean bParentHasSubService, bEnabledEligServiceFound;
    private void initialize(){
        externalPortalInd = null;
        sor = null;
        bParentHasSubService = false;
        bEnabledEligServiceFound = false;
    }

    /**
     * Validates that all required configuration properties are present and correctly initialized.
     * <p>
     * This method is executed after dependency injection to ensure that each configuration property
     * (such as eligible services, member LS services, services to MPS/Dbus, notification services,
     * auto-generated SLID account types, interested services, and agent calling system IDs) is not missing or empty.
     * If any property is invalid, the corresponding validation method will handle error reporting.
     *
     * This method is annotated with {@code @PostConstruct} to run automatically after bean initialization.
     */
    @PostConstruct
    public void validateConfig() {
        validatePropertyValue(alSubServices, "AddSec_Sub_Eligible_Services");
        validatePropertyValue(alMemberLSServices, "AddSec_Member_LS_Service");
        validatePropertyValue(alServicesToMPS, "AddSec_Services_To_MPS");
        validatePropertyValue(alServicesToDbus, "AddSec_Services_To_Dbus");
        validatePropertyValue(alConfigNotifyServices, "AddSec_Notify_Services");
        validatePropertyValue(alAutoGenSlidAccountType, "AddSec_Autogen_Slid_Account_Type");
        validatePropertyValue(subInterestedServicesList, "AddSec_Interested_Services");
        validatePropertyValue(alPasswdDirtyCallSysId, "addSec_Agent_CallingSystemId");
    }

    /**
     * Validates that the provided configuration property is not missing or empty.
     * This method checks if the given property set is null, empty, or its first element is blank.
     * If the property is invalid, it sets the application info message and populates the configuration
     * validation result map with an error code and message.
     *
     * @param prop       The configuration property set to validate.
     * @param configName The name of the configuration property for error messaging.
     * @return Error map if invalid, otherwise null.
     */
    private HashMap validatePropertyValue(Set<String> prop, String configName) {
        String appInfo = null;
        String firstProp = (prop == null || prop.isEmpty()) ? null : prop.iterator().next();
        if (firstProp == null || StringUtils.isBlank(firstProp)) {
            appInfo = "Missing configuration for " + configName;
            return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, appInfo);
        }
        return null;
    }

    /**
     * Adds a secondary member ID (sub-account) for a parent account.
     *
     * @param hmInput Input parameters for adding a secondary member ID.
     * @return A map containing the result of the operation, including status codes and error information if applicable.
     */
    public Map<String, Object> addSecMemberId(HashMap<String, Object> hmInput) {

        boolean isTransactionRollbackOnError = false;
        String appInfo = null, appStatusCode = null;
        ArrayList<Map<String, Object>> alDbusEvents = new ArrayList<>();
        Map<String, Object> linkMemberHelperHmResult = new HashMap<>();
        Map<String, Object> hmResult = new HashMap<>();
        HashMap<String, Object> parentServices = null;
        ArrayList<Object> alMPSServices = new ArrayList<Object>();
        ArrayList<Object> alNotifyServices = new ArrayList<Object>();
        ArrayList<Object> alDbusServices = new ArrayList<Object>();
        boolean bVOIPServiceActive = false;
        boolean bDidSubInheritedServicesFromParent = false;
        String transactionName = null, callingSystemId = null;
        Map<String, Object> hmMemberServiceInfo = new HashMap<>();

        String methodName = ".addSecMemberId.";
        String memberNum = null, slidMemberNum = null, ban = null, groupNum = null;

        try {
            transactionName = getString(hmInput, CommonDefs.TRANSACTION_NAME);
            callingSystemId = getString(hmInput, CommonDefs.CALLING_SYSTEM_ID);
            String domain = getString(hmInput, CommonDefs.DOMAIN);

            Map<String, Object> accountDetails = fetchParentAndSubAccountsInfo(hmInput, methodName);

            appStatusCode = getString(accountDetails, CommonDefs.COMMON_APP_STATUS_CODE);
            if (!CErrorDefs.COMMON_SUCCESS.equals(appStatusCode))
                return accountDetails;

            HashMap<String, Object> parentInfoHash = (HashMap<String, Object>) accountDetails.get("parentInfoHash");

            if (isSubAccount(parentInfoHash)) {
                appInfo = "transaction not allowed for subAccounts";
                logger.info("{}{}ASMIDH_04 : {}", CLASS_NAME, methodName, appInfo);
                return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_NOT_PARENT_NUM, appInfo);
            }

            if (!parentInfoHash.containsKey(MPSDefs.SERVICES)) {
                appInfo = "parent does not have any services";
                logger.info("{}{}ASMIDH_05 : {}", CLASS_NAME, methodName, appInfo);
                return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_NO_SERVICE_NUM, appInfo);
            }

            sor = getString(parentInfoHash, MPSDefs.DB_SOR_NAME);
            ban = getString(parentInfoHash, CommonDefs.BAN);
            parentServices = getParentServices(parentInfoHash, methodName);

            if (parentServices != null && parentServices.get(MPSDefs.PORTAL_SERVICE) != null) {
                HashMap hmPortalService = (HashMap) parentServices.get(MPSDefs.PORTAL_SERVICE);
                String portalLiteInd = StringUtils.defaultIfEmpty((String) hmPortalService.get(MPSDefs.DB_PLITE_IND), MPSDefs.NO).trim();
                String portalSor = StringUtils.defaultIfEmpty((String) hmPortalService.get(MPSDefs.DB_SOR_NAME), "").trim();
                if (portalSor.equalsIgnoreCase(MPSDefs.SOR_OPR) && portalLiteInd.equalsIgnoreCase(MPSDefs.YES)) {
                    appInfo = "PLITE parents are not allowed to add sub-accounts";
                    logger.info("{}{}ASMIDH_06 : {}", CLASS_NAME, methodName, appInfo);
                    return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, appInfo);
                }
            }

            String parentServiceStatus = getParentServiceStatus(parentServices, subInterestedServicesList);
            if (parentServiceStatus.equalsIgnoreCase(MPSDefs.TERMINATED)) {
                appInfo = "sub interested service in parent is in terminated status";
                return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SERVICE_NOT_ACTIVE_NUM, appInfo);
            }

            HashMap<String, Object> subAccountDetails =  (HashMap<String, Object>) accountDetails.get("subAccountsInfoHash");

            if(subAccountDetails != null && !subAccountDetails.isEmpty() &&  CErrorDefs.COMMON_SUCCESS.equals(getString(subAccountDetails, CommonDefs.COMMON_APP_STATUS_CODE))){
                hmResult = doMPScheckNumberValidSubs(subAccountDetails, parentServiceStatus);
                appStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
                if (appStatusCode == null || !appStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) return hmResult;
            }

            externalPortalInd = MPSDefs.YES;

            processParentServices(parentServices, transactionName, callingSystemId, bVOIPServiceActive, bDidSubInheritedServicesFromParent, alDbusServices, alNotifyServices, alMPSServices, hmMemberServiceInfo);

            if (!bParentHasSubService) {
                return CommonErrorMap.makeCategoryMap(
                    CErrorDefs.ERR_CANNOT_OPERATE_NUM,
                    "Parent should have at least one sub eligible service in this list " + alSubServices + ". Cannot add sub"
                );
            }
            if (!bEnabledEligServiceFound) {
                return CommonErrorMap.makeCategoryMap(
                    CErrorDefs.ERR_NOT_ENABLE_NUM,
                    "parent should have at least one Enabled service in this list = " + alSubServices
                );
            }

            HashMap hmUverseResp = checkAddUverseService(hmInput, parentInfoHash);
            appStatusCode = (String) hmUverseResp.get(CErrorDefs.COMMON_APP_STATUS_CODE);
            if (!appStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) return hmUverseResp;

            if (hmUverseResp.containsKey(CommonDefs.KEY_ADD_UVERSE_SERVICE_TO_MPS)) {
                HashMap hmUverseToMPS = (HashMap) hmUverseResp.get(CommonDefs.KEY_ADD_UVERSE_SERVICE_TO_MPS);
                HashMap hmUverseToNotification = (HashMap) hmUverseResp.get(CommonDefs.KEY_ADD_UVERSE_SERVICE_TO_NOTIFICATION);
                if (hmUverseToMPS != null && !hmUverseToMPS.isEmpty()) {
                    alMPSServices.add(hmUverseToMPS);
                    hmMemberServiceInfo.put(CommonDefs.UVERSE_SERVICE, hmUverseToMPS);
                    alNotifyServices.add(hmUverseToNotification);
                }
            }

            String clearText = StringUtils.defaultIfEmpty((String) hmInput.get(CommonDefs.CLEAR_PASSWORD), rilCheckAndEncryptPasswordHelper.generateTempPassword());
            groupNum = getString(parentInfoHash, MPSDefs.DB_GROUP_NUM);
            HashMap<String, Object> hmAddUserInp = populateAddUserInpHash(hmInput, parentInfoHash, groupNum, clearText);

            logger.info(SpiMarker.getInstance(), "{}{}ASMIDH_07 : Calling AddUserHelper.addUser with Input: {}", CLASS_NAME, methodName, StructuredArguments.entries(hmAddUserInp));
            Map<String, Object> addUserhelperHmResult = addUserhelper.addUser(hmAddUserInp);
            logger.info(SpiMarker.getInstance(), "{}{}ASMIDH_08 : Response from AddUserHelper.addUser with Input: {}", CLASS_NAME, methodName, StructuredArguments.entries(addUserhelperHmResult));
            if (CommonUtilHelper.isCollectionMapNullOrEmpty(addUserhelperHmResult)) {
                isTransactionRollbackOnError = true;
                appInfo = "Null or empty response from AddUserHelper.addUser";
                logger.error("{}{}ASMIDH_09 : {}", CLASS_NAME, methodName, appInfo);
                return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, appInfo);
            }
            appStatusCode = getString(addUserhelperHmResult, MPSDefs.APP_STATUS_CODE);
            if (!CommonDefs.COMMON_SUCCESS.equals(appStatusCode)) {
                isTransactionRollbackOnError = true;
                appInfo = (String) addUserhelperHmResult.get(MPSDefs.APP_INFO);
                logger.info("{}{}ASMIDH_10 : {}", CLASS_NAME, methodName, appInfo);
                return addUserhelperHmResult;
            }
            memberNum = getString(addUserhelperHmResult, "guid");

            hmResult = addServicesToDB(alMPSServices, memberNum, groupNum, callingSystemId, parentServices);

            if (hmResult != null && !CommonDefs.COMMON_SUCCESS.equals(getString(hmResult, MPSDefs.APP_STATUS_CODE))) {
                isTransactionRollbackOnError = true;
                appInfo = (String) hmResult.get(MPSDefs.APP_INFO);
                logger.info("{}{}ASMIDH_10.1 : {}", CLASS_NAME, methodName, CommonUtilHelper.sanitizeForLog(String.valueOf(appInfo)));
                return hmResult;
            }

            prepareAddSecDbusInput(hmInput, parentInfoHash, parentServices, addUserhelperHmResult, ban, transactionName, bVOIPServiceActive, bDidSubInheritedServicesFromParent, alDbusServices, alDbusEvents);

            if (shouldAutoGenSlid(parentInfoHash)) {
                linkMemberHelperHmResult = linkMemberHelper.linkMember(
                    prepareLinkMemberInput(hmInput, domain, callingSystemId),
                    prepareHmMemberInfo(hmInput, hmAddUserInp, hmMemberServiceInfo)
                );
                if (CommonUtilHelper.isCollectionMapNullOrEmpty(linkMemberHelperHmResult)) {
                    isTransactionRollbackOnError = true;
                    appInfo = "Null response from linkMemberHelper.linkMember() call";
                    return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, appInfo);
                }
                appStatusCode = (String) linkMemberHelperHmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
                if (appStatusCode != null && !appStatusCode.equals(CommonDefs.COMMON_SUCCESS)
                    && !appStatusCode.equals(CErrorDefs.ERR_DOB_UNDER_13)
                    && !appStatusCode.equals(CErrorDefs.ERR_USER_NOT_FOUND)) {
                    isTransactionRollbackOnError = true;
                    return linkMemberHelperHmResult;
                }
                ArrayList linkMemberDbusInput = linkMemberHelperHmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT) != null
                    ? (ArrayList) linkMemberHelperHmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT)
                    : new ArrayList();
                Map<String, Object> linkMemberUpdateAliasList = linkMemberDbusInput.isEmpty() || linkMemberDbusInput.get(0) == null
                    ? CommonUtil.getHashMap()
                    : (Map<String, Object>) linkMemberDbusInput.get(0);
                slidMemberNum = (String) linkMemberUpdateAliasList.get(MPSDefs.DB_SLID_MEMBER_NUM);
            }

            if (linkMemberHelperHmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT) != null) {
                alDbusEvents.addAll((ArrayList) linkMemberHelperHmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT));
            }

            prepareNotificationInput(hmInput, parentInfoHash, parentServices, memberNum, ban, alDbusServices, alNotifyServices, alDbusEvents);

            Map hmDbusResult = addSecMemberIdQueueHelper.sendMessageToMQ(hmAddUserInp, alDbusEvents, slidMemberNum, memberNum);
            logger.info("{}{}ASMIDH_12 :Response from addUserQueueHelper.sendMessageToMQ: {}", CLASS_NAME, methodName, hmDbusResult);

            if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmDbusResult)) {
                isTransactionRollbackOnError = true;
                return CommonUtilHelper.sysErrorHashMap("null response from AddUserQueueHelper.sendMessageToMQ");
            }
            appStatusCode = (String) hmDbusResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
            if (StringUtils.isBlank(appStatusCode)) {
                isTransactionRollbackOnError = true;
                return CommonUtilHelper.sysErrorHashMap("null response from AddUserQueueHelper.sendMessageToMQ");
            }
            if (!CommonDefs.COMMON_SUCCESS.equals(appStatusCode)) {
                isTransactionRollbackOnError = true;
                appInfo = (String) hmDbusResult.get(CommonDefs.COMMON_APP_INFO);
                logger.info("{}{}ASMIDH_13 : {}", CLASS_NAME, methodName, HtmlUtils.htmlEscape(String.valueOf(appInfo)));
                return hmDbusResult;
            }
        } catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e, logger);
            appInfo = "Exception thrown addSecMemberId method : " + hmResult;
            logger.info("{}{}ASMIDH_14 : {}", CLASS_NAME, methodName, HtmlUtils.htmlEscape(String.valueOf(appInfo)));
        } finally {
            String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
            if (isTransactionRollbackOnError && sAppCategoryCode != null && !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
                hmResult.put("isTransactionRollback", "Y");
            }
            logger.info("{}{}HLP999 : response from addSecMemberId : {}", CLASS_NAME, methodName, HtmlUtils.htmlEscape(String.valueOf(hmResult)));
        }
        return hmResult;
    }

    /**
     * Creates a service array list for a given service.
     * This method processes the input service HashMap, checks if the service is in the list of LS services,
     * and prepares the necessary input for MPS and DBUS service maps.
     *
     * @param hmIndService A HashMap containing individual service details.
     * @param sServiceName The name of the service to be processed.
     * @param alLSServices An ArrayList containing the list of LS services.
     * @return A HashMap containing the prepared service inputs for MPS and DBUS.
     */
    private HashMap createServiceArrayList(HashMap hmIndService, String sServiceName, Set alLSServices) {
        HashMap hmReturnHash = new HashMap();
        HashMap hmTempService = new HashMap(hmIndService);
        String sServiceStatusName = (String) hmTempService.get(MPSDefs.SERVICE_STATUS);
        if (alLSServices.contains(sServiceName)) {
            for (Object key : hmTempService.keySet()) {
                String sInstanceId = (String) key;
                Object oInstanceIdObject = hmTempService.get(sInstanceId);
                if (oInstanceIdObject instanceof HashMap) {
                    HashMap hmInstanceId = (HashMap) oInstanceIdObject;
                    hmInstanceId.put(CommonDefs.INSTANCE_ID, sInstanceId);
                    hmInstanceId.put(MPSDefs.SERVICE_STATUS, sServiceStatusName);
                    hmTempService = hmInstanceId;
                    break;
                }
            }
        }

        String sServiceLevelSorName = (String) hmTempService.get(MPSDefs.DB_SOR_NAME);
        hmTempService.put(MPSDefs.DB_MEMBER_STATUS_NAME, MPSDefs.ENABLED);
        hmTempService.put(CommonDefs.SOR_NAME, sServiceLevelSorName != null && !sServiceLevelSorName.trim().isEmpty() ? sServiceLevelSorName : sor);
        hmTempService.put(CommonDefs.EXTERNAL_PORTAL_IND, externalPortalInd);
        hmTempService.put(MPSDefs.DB_SERVICE_NAME, sServiceName);

        //AddSec_Services_To_MPS=1544|HSIA|PORTAL|UVERSE
        if (alServicesToMPS.contains(sServiceName)) {
            hmReturnHash.put(MPS_SERVICE_KEY, preparehmServiceInput(hmTempService));
        }

        //AddSec_Services_To_Dbus=1544|HSIA|PORTAL
        if (alServicesToDbus.contains(sServiceName) && !MPSDefs.TERMINATED.equalsIgnoreCase(sServiceStatusName)) {
            hmReturnHash.put(DBUS_SERVICE_KEY, preparehmDbusInput(hmTempService));
        }

        return hmReturnHash.isEmpty() ? null : hmReturnHash;
    }

    /**
     * Checks and adds UVERSE service to the parent services if eligible.
     * Returns a result map with prepared service inputs for MPS and DBUS if applicable.
     *
     * @param hmInput Input details such as calling system ID.
     * @param getAllInfoHash All information including parent services.
     * @return Result map with service inputs for MPS and DBUS.
     */
    private HashMap checkAddUverseService(HashMap hmInput, HashMap getAllInfoHash) {
        //alSubUversrServices - AddSec_Uverse_Services=HSIA|VOIP
        if (alSubUversrServices == null || alSubUversrServices.isEmpty()) {
            return CommonErrorMap.makeCategoryMap(
                CErrorDefs.ERR_SYS_APPL_NUM,
                "Couldn't parse AddSec_Uverse_Services into ArrayList."
            );
        }

        HashMap hmParentServices = (HashMap) getAllInfoHash.get(MPSDefs.SERVICES);
        boolean eligible = false;
        if (hmParentServices != null) {
            for (Object service : alSubUversrServices) {
                if (hmParentServices.containsKey(service)) {
                    String status = (String) ((HashMap) hmParentServices.get(service)).get(MPSDefs.SERVICE_STATUS);
                    if (!CommonDefs.TERMINATED.equalsIgnoreCase(status)) {
                        eligible = true;
                        break;
                    }
                }
            }
        }

        HashMap hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.REASON_CODE_SUCCESS);

        //If there is no eligible uverse services returning success otherwise add uverse service with response.
        if (!eligible) return hmResponse;

        HashMap hmUVerse = (HashMap) hmParentServices.get(CommonDefs.UVERSE_SERVICE);
        if (hmUVerse == null || hmUVerse.isEmpty()) return hmResponse;

        String uverseStatus = (String) hmUVerse.get(MPSDefs.SERVICE_STATUS);
        if (CommonDefs.TERMINATED.equalsIgnoreCase(uverseStatus)) return hmResponse;

        String callingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
        hmUVerse.put(CommonDefs.TRANSACTION_NAME, "AddSub");
        hmUVerse.put(CommonDefs.CALLING_SYSTEM_ID, callingSystemId);

        alSubUversrServices.add(CommonDefs.UVERSE_SERVICE);
        alServicesToDbus.add(CommonDefs.UVERSE_SERVICE);

        HashMap hmUverseTempService = createServiceArrayList(hmUVerse, CommonDefs.UVERSE_SERVICE, alSubUversrServices);

        alServicesToDbus.remove(CommonDefs.UVERSE_SERVICE);

        HashMap hmMPSServiceInput = null;
        if (hmUverseTempService.containsKey(MPS_SERVICE_KEY)) {
            hmMPSServiceInput = (HashMap) hmUverseTempService.get(MPS_SERVICE_KEY);
            hmMPSServiceInput.put(MPSDefs.DB_LAST_MODIFIED_BY, callingSystemId);
        }
        HashMap hmNotificationInputService = (HashMap) hmUverseTempService.get(DBUS_SERVICE_KEY);

        hmResponse.put(CommonDefs.KEY_ADD_UVERSE_SERVICE_TO_MPS, hmMPSServiceInput);
        hmResponse.put(CommonDefs.KEY_ADD_UVERSE_SERVICE_TO_NOTIFICATION, hmNotificationInputService);

        return hmResponse;
    }

    /**
     * Prepares a list of formatted parent service details for EDD notification.
     * <p>
     * Iterates over the parent services map, formats each service's details, and adds them to the result list.
     * For services listed in {@code CommonDefs.INSTANCE_SERVICES}, it processes each instance within the service map.
     * For other services, it directly formats the service map.
     * Only non-empty formatted services are added to the result, with the service type included.
     *
     * @param hmParentServices A HashMap containing parent service names as keys and their details as values.
     * @return An ArrayList of HashMaps, each representing a formatted parent service for EDD notification.
     */
    private static ArrayList<HashMap<String, Object>> prepareParSvcForEDDNotification(HashMap<String, Object> hmParentServices) {
        ArrayList<HashMap<String, Object>> result = new ArrayList<>();

        for (Map.Entry<String, Object> entry : hmParentServices.entrySet()) {
            String key = entry.getKey();
            HashMap<String, Object> serviceMap = (HashMap<String, Object>) entry.getValue();
            HashMap<String, Object> formattedService = new HashMap<>();

            if (CommonDefs.INSTANCE_SERVICES.contains(key)) {
                for (Object value : serviceMap.values()) {
                    if (value instanceof HashMap && !((HashMap<?, ?>) value).isEmpty()) {
                        populateServiceDetails(formattedService, (HashMap<String, Object>) value);
                    }
                }
            } else {
                populateServiceDetails(formattedService, serviceMap);
            }

            if (!formattedService.isEmpty()) {
                formattedService.put(CommonDefs.SERVICE_TYPE, CommonDefs.SERVICE_VALUES.get(key));
                result.add(formattedService);
            }
        }
        return result;
    }

    /**
     * Populates the formatted parent service details.
     * This method adds service details from the provided service name HashMap to the formatted parent service HashMap,
     * only if the values are not null.
     *
     * @param hmFormatedParSvc The HashMap to store formatted parent service details.
     * @param hmServiceName The HashMap containing service details to be formatted.
     */
    private static void populateServiceDetails(Map<String, Object> hmFormatedParSvc, HashMap<String, Object> hmServiceName) {
        putIfNotNull(hmFormatedParSvc, CommonDefs.SERVICE_STATUS, (String) hmServiceName.get(MPSDefs.SERVICE_STATUS));
        putIfNotNull(hmFormatedParSvc, CommonDefs.EMAIL_ELIGIBLE, (String) hmServiceName.get(MPSDefs.DB_EMAIL_ELIGIBLE));
        putIfNotNull(hmFormatedParSvc, CommonDefs.SOR_NAME, (String) hmServiceName.get(MPSDefs.DB_SOR_NAME));
        putIfNotNull(hmFormatedParSvc, CommonDefs.MEMBER_STATUS, (String) hmServiceName.get(MPSDefs.DB_MEMBER_STATUS_NAME));
        putIfNotNull(hmFormatedParSvc, CommonDefs.PORTAL_PROVIDER, (String) hmServiceName.get(MPSDefs.DB_PORTAL_PROVIDER));
    }

    /**
     * Adds a key-value pair to the map if the value is not null.
     * This method checks if the provided value is not null, and if so, adds the key-value pair to the map.
     *
     * @param map The HashMap to which the key-value pair will be added.
     * @param key The key to be added to the map.
     * @param value The value to be added to the map if it is not null.
     */
    private static void putIfNotNull(Map<String, Object> map, String key, Object value) {
        if (value != null) {
            map.put(key, value);
        }
    }

    /**
     * Checks the validity of sub-accounts for a given group number and parent service hash.
     * This method retrieves sub-account details, validates the configuration, and checks the status of sub-accounts.
     * It returns a result map indicating success or failure based on the validation checks.
     *
     * @param parentServiceStatus A String containing parent service details.
     * @return A HashMap containing the result of the validation checks.
    * */
    private HashMap<String, Object> doMPScheckNumberValidSubs(HashMap<String, Object> subAcccountDetails, String parentServiceStatus) {
        HashMap<String, Object> hmResult = new HashMap<>();
        String methodName = "doMPScheckNumberValidSubs";
        try {
            ArrayList<HashMap<String, Object>> activeSubs = new ArrayList<>();

            hmResult = findActiveSubs((List<Map<String, Object>>) subAcccountDetails.get("memberServiceInfo"));//prepareActiveSubHashMap (activeSubs, subAcccountDetails, parentServiceStatus);
            String appStatusCode = (String)hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
            if(!appStatusCode.equals(CErrorDefs.COMMON_SUCCESS)){
                return hmResult;
            }
            activeSubs = (ArrayList<HashMap<String, Object>>) hmResult.get("activeSubs");
            int allowedTotSubAccs = parseConfigValue(AddSecAllowedTotalSubAccounts, "AddSecAllowedTotalSubAccounts");
            int allowedTotActiveSubAccs = parseConfigValue(AddSecAllowedTotalActiveSubAccounts, "AddSecAllowedTotalActiveSubAccounts");
            hmResult = findActiveSubCounts(activeSubs, parentServiceStatus);
            int totalActiveSubAccounts = (int) hmResult.get("totalActiveSubAccounts");
            int totalSuspendSubAccounts = (int) hmResult.get("totalSuspendSubAccounts");
            int totalSubAccounts = totalSuspendSubAccounts + totalActiveSubAccounts;
            if (totalSubAccounts >= allowedTotSubAccs || totalActiveSubAccounts >= allowedTotActiveSubAccs) {
                return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SUB_LIMIT_EXCEEDED_NUM, CErrorDefs.ERR_SUB_LIMIT_EXCEEDED_MSG);
            }

        } catch (Exception e) {
            logger.error("{}{}ASMIDH_06.1 : Exception doMPScheckNumberValidSubs : {}", CLASS_NAME, methodName,CommonUtilHelper.sanitizeForLog(e.getMessage()));
            return CommonErrorMap.makeExceptionMap(e);
        }
        return CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS);
    }

    /**
     * Parses a configuration value and converts it to an integer.
     * This method checks if the provided configuration value is null or blank.
     * If the value is valid, it converts the value to an integer and returns it.
     * If the value is invalid, it throws an IllegalArgumentException with an appropriate message.
     *
     * @param configValue The configuration value to be parsed.
     * @param configName The name of the configuration for error messaging.
     * @return The parsed integer value of the configuration.
     * @throws IllegalArgumentException if the configuration value is null or blank.
     */
    private int parseConfigValue(String configValue, String configName) {
        String appInfo = null;
        if (configValue == null || configValue.isBlank()) {
            appInfo = "Missing configuration for " + configName;
            throw new IllegalArgumentException(appInfo);
        }
        return Integer.parseInt(configValue);
    }

    /**
     * Determines the overall status of the parent services based on the interested sub-services.
     * <p>
     * This method checks the status of each service listed in {@code subInterestedServices} within the {@code parentServices} map.
     * <ul>
     *   <li>If any interested service is {@code ENABLED}, returns {@code MPSDefs.ENABLED}.</li>
     *   <li>If none are enabled but at least one is {@code SUSPENDED}, returns {@code MPSDefs.SUSPENDED}.</li>
     *   <li>If neither enabled nor suspended services are found, returns {@code MPSDefs.TERMINATED}.</li>
     * </ul>
     *
     * @param parentServices a map containing parent service names as keys and their details as values
     * @param subInterestedServices a set of service names to check for status
     * @return the overall status of the parent services: {@code MPSDefs.ENABLED}, {@code MPSDefs.SUSPENDED}, or {@code MPSDefs.TERMINATED}
     */
    private String getParentServiceStatus(HashMap<String, Object> parentServices, Set<String> subInterestedServices) {
        Optional<String> status = subInterestedServices.stream()
            .filter(parentServices::containsKey)
            .map(serviceName -> (String) ((HashMap<?, ?>) parentServices.get(serviceName)).get(MPSDefs.SERVICE_STATUS))
            .filter(Objects::nonNull)
            .filter(serviceStatus -> MPSDefs.ENABLED.equalsIgnoreCase(serviceStatus))
            .findFirst();

        if (status.isPresent()) {
            return MPSDefs.ENABLED;
        }

        boolean isSuspended = subInterestedServices.stream()
            .filter(parentServices::containsKey)
            .map(serviceName -> (String) ((HashMap<?, ?>) parentServices.get(serviceName)).get(MPSDefs.SERVICE_STATUS))
            .anyMatch(serviceStatus -> MPSDefs.SUSPENDED.equalsIgnoreCase(serviceStatus));

        return isSuspended ? MPSDefs.SUSPENDED : MPSDefs.TERMINATED;
    }

    /**
     * Prepares a HashMap containing service input parameters from the given service details.
     * This method extracts various service-related attributes from the input HashMap and
     * populates a new HashMap with these attributes for further processing.
     *
     * @param hmTempService A HashMap containing service details.
     * @return A HashMap containing the service input parameters.
     */
    private HashMap preparehmServiceInput(HashMap hmTempService) {
        HashMap hmServiceInput = new HashMap();
        putIfNotEmpty(hmServiceInput, MPSDefs.DB_SERVICE_NAME, hmTempService.get(MPSDefs.DB_SERVICE_NAME));
        putIfNotEmpty(hmServiceInput, MPSDefs.DB_GROUP_STATUS_NAME, hmTempService.get(MPSDefs.DB_GROUP_STATUS_NAME));
        putIfNotEmpty(hmServiceInput, MPSDefs.DB_MEMBER_STATUS_NAME, hmTempService.get(MPSDefs.DB_MEMBER_STATUS_NAME));
        putIfNotEmpty(hmServiceInput, MPSDefs.DB_GROUP_STATUS, hmTempService.get(MPSDefs.DB_GROUP_STATUS_CODE));
        putIfNotEmpty(hmServiceInput, MPSDefs.DB_MEMBER_STATUS, hmTempService.get(MPSDefs.DB_MEMBER_STATUS_CODE));
        putIfNotEmpty(hmServiceInput, MPSDefs.DB_SOR_NAME, hmTempService.get(CommonDefs.SOR_NAME));
        putIfNotEmpty(hmServiceInput, MPSDefs.DB_LAST_MODIFIED_BY, hmTempService.get(MPSDefs.DB_LAST_MODIFIED_BY));
        putIfNotEmpty(hmServiceInput, MPSDefs.DB_SITE_ID, hmTempService.get(MPSDefs.DB_SITE_ID));
        putIfNotEmpty(hmServiceInput, MPSDefs.DB_INSTANCE_ID, hmTempService.get(CommonDefs.INSTANCE_ID));
        putIfNotEmpty(hmServiceInput, MPSDefs.DB_SOR_INVARIANT_ID, hmTempService.get(MPSDefs.DB_SOR_INVARIANT_ID));
        logger.info("{}{}ASMIDH_11 : MPS Service Input: {}", CLASS_NAME, hmServiceInput);
        return hmServiceInput;
    }

    private void putIfNotEmpty(HashMap map, Object key, Object value) {
        if (value != null && !value.toString().trim().isEmpty()) {
            map.put(key, value);
        }
    }

    /**
     * Prepares a HashMap containing DBUS input parameters from the given service details.
     * This method extracts various service-related attributes from the input HashMap and
     * populates a new HashMap with these attributes for DBUS processing.
     *
     * @param hmTempService A HashMap containing service details.
     * @return A HashMap containing the DBUS input parameters.
     */
    private HashMap preparehmDbusInput(HashMap hmTempService){
        HashMap hmDbusInput = new HashMap();
        putIfNotEmpty(hmDbusInput, CommonDefs.SERVICE_TYPE, CommonDefs.SERVICE_VALUES.get(hmTempService.get(MPSDefs.DB_SERVICE_NAME)));
        putIfNotEmpty(hmDbusInput, CommonDefs.INSTANCE_ID, hmTempService.get(CommonDefs.INSTANCE_ID));
        putIfNotEmpty(hmDbusInput, CommonDefs.SERVICE_STATUS, hmTempService.get(CommonDefs.SERV_STATUS));
        putIfNotEmpty(hmDbusInput, CommonDefs.DBUS_DB_WTN, hmTempService.get(CommonDefs.DBUS_DB_WTN));
        putIfNotEmpty(hmDbusInput, CommonDefs.MEMBER_STATUS, hmTempService.get(MPSDefs.DB_MEMBER_STATUS_NAME));
        putIfNotEmpty(hmDbusInput, CommonDefs.SOR_NAME, hmTempService.get(CommonDefs.SOR_NAME));
        putIfNotEmpty(hmDbusInput, CommonDefs.PORTAL_PROVIDER, hmTempService.get(MPSDefs.PORTAL_PROVIDER));
        putIfNotEmpty(hmDbusInput, "extenalPortalInd", hmTempService.get("extenalPortalInd"));
        putIfNotEmpty(hmDbusInput, CommonDefs.INCOMING_LIMIT, hmTempService.get(MPSDefs.DB_INCOMING_LIMIT));
        putIfNotEmpty(hmDbusInput, CommonDefs.OUTGOING_LIMIT, hmTempService.get(MPSDefs.DB_OUTGOING_LIMIT));
        putIfNotEmpty(hmDbusInput, CommonDefs.EMAIL_ELIGIBLE, hmTempService.get(MPSDefs.DB_EMAIL_ELIGIBLE));
        logger.info("{}{}ASMIDH_11 : DBUS Input: {}", CLASS_NAME, hmDbusInput);
        return hmDbusInput;
    }

    /**
     * Populates a HashMap with user input data and parent information.
     * This method takes user input data, parent information, group number, and clear text password,
     * and populates a HashMap with these details for further processing.
     *
     * @param hmInput A HashMap containing user input data.
     * @param parentInfoHash A HashMap containing parent information.
     * @param groupNum The group number associated with the user.
     * @param clearText The clear text password of the user.
     * @return A HashMap containing the populated user input data and parent information.
     */
    private HashMap populateAddUserInpHash(HashMap hmInput, HashMap parentInfoHash, String groupNum, String clearText) {
        HashMap<String, Object> hmAddUserInp = new HashMap<>();
        String ban = (String) parentInfoHash.get(CommonDefs.BAN);
        String firstName = (String) hmInput.get(CommonDefs.FIRST_NAME);
        String lastName = (String) hmInput.get(CommonDefs.LAST_NAME);
        String fullName = firstName + " " + lastName;
        String securityQuestion = (String) hmInput.get(CommonDefs.SECURITY_QUESTION);
        String securityAnswer = (String) hmInput.get(CommonDefs.SECURITY_ANSWER);
        String onlineSecQues1 = (String) hmInput.get(CommonDefs.ONLINE1_SECURITY_QUESTION);
        String onlineSecAns1 = (String) hmInput.get(CommonDefs.ONLINE1_SECURITY_ANSWER);
        String onlineSecQues2 = (String) hmInput.get(CommonDefs.ONLINE2_SECURITY_QUESTION);
        String onlineSecAns2 = (String) hmInput.get(CommonDefs.ONLINE2_SECURITY_ANSWER);
        String dateOfBirth = (String) hmInput.get(CommonDefs.DATE_OF_BIRTH);
        String passcode = (String) hmInput.get(CommonDefs.PASSCODE);
        String domain = (String) hmInput.get(CommonDefs.DOMAIN);
        String accessName = (String) parentInfoHash.get(MPSDefs.DB_ACCESS_NAME);
        String stProofingZip = (String) hmInput.get(CommonDefs.PROOF_ZIP);
        String gender = (String) hmInput.get(CommonDefs.GENDER);
        String nickName = (String) hmInput.get(CommonDefs.IGP_NICK_NAME);
        String lastFourSSN = (String) hmInput.get(CommonDefs.LAST_FOUR_SSN);
        String contactEmail = (String) hmInput.get(CommonDefs.CONTACT_EMAIL);
        String language = (String) parentInfoHash.get(CommonDefs.LANGUAGE);

        String parentMigrationInd = (String) parentInfoHash.get(MPSDefs.DB_MIGRATION_IND);
        if (parentMigrationInd == null) {
            return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "Parent Migration Indicator is missing in mps db");
        }

        hmAddUserInp.put(CommonDefs.MIGRATION_IND, parentMigrationInd);
        hmAddUserInp.put("isMIDInRequest", true);
        hmAddUserInp.put(CommonDefs.DOMAIN, domain);
        hmAddUserInp.put(CommonDefs.HANDLE, hmInput.get(CommonDefs.HANDLE));
        hmAddUserInp.put(CommonDefs.SOR, parentInfoHash.get(CommonDefs.SOR_NAME));
        hmAddUserInp.put(MPSDefs.DB_FULLNAME, fullName);
        hmAddUserInp.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
        if (ban != null) {
            hmAddUserInp.put(CommonDefs.BAN, ban);
        }
        hmAddUserInp.put(CommonDefs.PARENT_CHILD_IND, MPSDefs.MPS_CHILD);
        hmAddUserInp.put(CommonDefs.ACCOUNT_TYPE, parentInfoHash.get(CommonDefs.DB_ACCOUNT_TYPE));
        hmAddUserInp.put(CommonDefs.GROUP_NUM, groupNum);
        hmAddUserInp.put(CommonDefs.MAIL_HOST, parentInfoHash.get(MPSDefs.DB_MAILHOST));
        hmAddUserInp.put(CommonDefs.ACCOUNTSTATUS, MPSDefs.ENABLED);

        HashMap hmResult = findDirtyCallingSystemId(hmAddUserInp, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
        if(hmResult.get(CommonDefs.ERROR_CODE) != null && !hmResult.get(CommonDefs.ERROR_CODE).equals(CErrorDefs.COMMON_SUCCESS_NUM)){
            return hmResult;
        }

        hmAddUserInp.put(CommonDefs.ACCESS_NAME, accessName);

        if (!CommonDefs.SOR_NAME_WN.equalsIgnoreCase(sor)) {
            putIfNotEmpty(hmAddUserInp, CommonDefs.FIRST_NAME, firstName);
            putIfNotEmpty(hmAddUserInp, CommonDefs.LAST_NAME, lastName);
            putIfNotEmpty(hmAddUserInp, CommonDefs.SECURITY_QUESTION, securityQuestion);
            putIfNotEmpty(hmAddUserInp, CommonDefs.ONLINE1_SECURITY_QUESTION, onlineSecQues1);
            putIfNotEmpty(hmAddUserInp, CommonDefs.ONLINE2_SECURITY_QUESTION, onlineSecQues2);
            putIfNotEmpty(hmAddUserInp, CommonDefs.ONLINE1_SECURITY_ANSWER, onlineSecAns1);
            putIfNotEmpty(hmAddUserInp, CommonDefs.ONLINE2_SECURITY_ANSWER, onlineSecAns2);
            putIfNotEmpty(hmAddUserInp, CommonDefs.SECURITY_ANSWER, securityAnswer);
            putIfNotEmpty(hmAddUserInp, CommonDefs.DATE_OF_BIRTH, dateOfBirth);
            putIfNotEmpty(hmAddUserInp, CommonDefs.PASSCODE, passcode);
        }

        putIfNotEmpty(hmAddUserInp, CommonDefs.PROOFING_ZIP, stProofingZip);
        putIfNotEmpty(hmAddUserInp, CommonDefs.GENDER, gender);
        putIfNotEmpty(hmAddUserInp, CommonDefs.NICKNAME, nickName);
        putIfNotEmpty(hmAddUserInp, CommonDefs.LAST_FOUR_SSN, lastFourSSN);
        putIfNotEmpty(hmAddUserInp, CommonDefs.CONTACT_EMAIL, contactEmail);
        putIfNotEmpty(hmAddUserInp, CommonDefs.LANGUAGE, language);

        hmAddUserInp.put(CommonDefs.MAIL_HOST, parentInfoHash.get(CommonDefs.MAIL_HOST));
        hmAddUserInp.put(CommonDefs.ORIG_TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
        hmAddUserInp.put(CommonDefs.TRANSACTION_NAME, CommonDefs.ADD_USER_TRANSACTION_NAME);
        hmAddUserInp.put(CommonDefs.TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.IDPTRACEID));
        hmAddUserInp.put(ProfileOrchestrationConstants.IDPTRACEID, hmInput.get(ProfileOrchestrationConstants.IDPTRACEID));
        hmAddUserInp.put(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID, hmInput.get("dbusTransactionId"));
        hmAddUserInp.put(CommonDefs.CALLDBUS, CommonDefs.IND_N);
        hmAddUserInp.put(CommonDefs.PASSWORD_CLEAR, clearText);
        hmAddUserInp.put(CommonDefs.BY_PASS_CHECK_ID_AVAILABLE,  CommonDefs.IND_N);
        return hmAddUserInp;
    }

    /**
     * Adds a key-value pair to the given map if the value is not null or empty.
     * This method checks if the provided value is not null and not empty (after trimming).
     * If the value is valid, it adds the key-value pair to the map.
     *
     * @param map The HashMap to which the key-value pair will be added.
     * @param key The key to be added to the map.
     * @param value The value to be added to the map.
     */
    private void putIfNotEmpty(HashMap<String, Object> map, String key, String value) {
        if (value != null && !value.trim().isEmpty()) {
            map.put(key, value.trim());
        }
    }

    /**
     * Validates the format of a contact email address.
     * This method checks if the provided email address contains an '@' symbol followed by a domain with a '.'.
     * If the email address is valid, it returns RILDefs.YES; otherwise, it returns RILDefs.NO.
     *
     * @param contactEmail The email address to be validated.
     * @return A String indicating whether the email address is valid (RILDefs.YES) or not (RILDefs.NO).
     */
    private String validateContactEmail(String contactEmail){
        String contactEmailValid = RILDefs.YES;
        int pos = contactEmail.indexOf('@');
        if (pos > 0) {
            String temp = contactEmail.substring(pos + 1);
            if (temp.indexOf('.') <= 0)
                contactEmailValid = RILDefs.NO;
        } else
            contactEmailValid = RILDefs.NO;
        return contactEmailValid;
    }

    /**
     * Finds and marks the calling system ID as dirty if it matches the configured list.
     * This method checks if the provided calling system ID is in the list of configured IDs
     * that require the password to be marked as dirty. If the calling system ID is found in the list,
     * it updates the input HashMap to indicate that the password is dirty.
     *
     * @param hmAddUserInp A HashMap containing user input details.
     * @param callingSystemId The calling system ID to be checked.
     * @return A HashMap containing the result of the check. Possible values include success or error codes.
     */
    private HashMap findDirtyCallingSystemId(HashMap hmAddUserInp, String callingSystemId){
        if (alPasswdDirtyCallSysId != null && alPasswdDirtyCallSysId.contains(callingSystemId)) {
            hmAddUserInp.put(CommonDefs.PASSWORD_DIRTY, MPSDefs.YES);
        }else
            hmAddUserInp.put(CommonDefs.PASSWORD_DIRTY, MPSDefs.NO);

        return CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.REASON_CODE_SUCCESS);
    }

    public HashMap findActiveSubs(List<Map<String, Object>> rows) {
        final String ENABLED = "Enabled";
        final String INUSE = "INUSE";
        final String TERMINATED = "TERMINATED";
        HashMap activeSubHash = null;
        // Group by member_num
        Map<String, List<Map<String, Object>>> grouped = rows.stream()
                .collect(Collectors.groupingBy(row -> String.valueOf(row.get("member_num"))));

        List<Map<String, Object>> activeSubs = new ArrayList<>();

        for (Map.Entry<String, List<Map<String, Object>>> entry : grouped.entrySet()) {
            List<Map<String, Object>> memberRows = entry.getValue();
            boolean allServiceIdNull = memberRows.stream().allMatch(row -> row.get("service_id") == null);

            if (allServiceIdNull) {
                memberRows.stream()
                        .filter(row -> row.get("last_member_status_name") == null ||
                                !TERMINATED.equalsIgnoreCase(String.valueOf(row.get("last_member_status_name"))))
                        .forEach(activeSubs::add);
            } else {
                memberRows.stream()
                        .filter(row -> ENABLED.equals(row.get("agg_service_status")) ||
                                INUSE.equals(row.get("member_state")))
                        .forEach(activeSubs::add);
            }
        }
        activeSubHash = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.REASON_CODE_SUCCESS);
        activeSubHash.put("activeSubs",activeSubs);
        return activeSubHash;
    }
    /**
     * Counts active and suspended sub-accounts from the provided list.
     *
     * @param activeSubs List of sub-account details.
     * @param parentServiceStatus Status of the parent service.
     * @return Map with counts of active and suspended sub-accounts.
     */
    private HashMap<String, Object> findActiveSubCounts(ArrayList<HashMap<String, Object>> activeSubs, String parentServiceStatus) {
        int totalActive = 0;
        int totalSuspended = 0;

        Map<String, List<Map<String, Object>>> grouped = activeSubs.stream()
                .collect(Collectors.groupingBy(row -> String.valueOf(row.get("member_num"))));

        for (Map.Entry<String, List<Map<String, Object>>> entry : grouped.entrySet()) {
            List<Map<String, Object>> memberRows = entry.getValue();
            boolean allServiceIdNull = memberRows.stream().allMatch(row -> row.get("service_id") == null);
            String memberState = (String) memberRows.get(0).get(MPSDefs.DB_MEMBER_STATE);
            String aggStatus = (String) memberRows.get(0).get(MPSDefs.DB_AGG_SERVICE_STATUS);
            String lastStatus = (String) memberRows.get(0).get(MPSDefs.DB_LAST_MEMBER_STATUS_NAME);

            boolean isEnabled;
            if (allServiceIdNull) {
                String status = (lastStatus == null || lastStatus.trim().isEmpty()) ? MPSDefs.ENABLED : lastStatus;
                isEnabled = MPSDefs.ENABLED.equals(calculateStatus(status, parentServiceStatus));
            } else {
                isEnabled = MPSDefs.INUSE_STATE.equals(memberState) && MPSDefs.DB_AGG_SERVICE_STATUS_ENABLE.equals(aggStatus);
            }

            if (isEnabled) {
                totalActive++;
            } else {
                totalSuspended++;
            }
        }

        HashMap<String, Object> result = new HashMap<>();
        result.put("totalActiveSubAccounts", totalActive);
        result.put("totalSuspendSubAccounts", totalSuspended);
        return result;
    }



    /**
     * Groups service IDs by member number and returns as an ArrayList of HashMaps.
     *
     * @param activeSubs List of HashMap entries representing sub-accounts.
     * @return ArrayList where each HashMap contains "member_num" and "service_ids" keys.
     */
    public ArrayList<HashMap<String, Object>> groupServiceIdsByMemberNum(ArrayList<HashMap<String, Object>> activeSubs) {
        Map<String, List<String>> grouped = activeSubs.stream()
            .collect(Collectors.groupingBy(
                sub -> String.valueOf(sub.get("member_num")),
                Collectors.mapping(
                    sub -> String.valueOf(sub.get("service_id")),
                    Collectors.toList()
                )
            ));

        ArrayList<HashMap<String, Object>> result = new ArrayList<>();
        for (Map.Entry<String, List<String>> entry : grouped.entrySet()) {
            HashMap<String, Object> map = new HashMap<>();
            map.put("member_num", entry.getKey());
            map.put("service_ids", entry.getValue());
            result.add(map);
        }
        return result;
    }

    // Returns a String value from the map for the given key, or null if not present
    private String getString(Map<String, Object> map, String key) {
        Object value = map.get(key);
        return value != null ? value.toString() : null;
    }

    // Retrieves parent info from input, typically by calling a DB helper
    private HashMap<String, Object> getParentInfo(HashMap<String, Object> hmInput) {
        HashMap<String, Object> memberInfo = new HashMap<>();
        memberInfo.put(MPSDefs.DB_MEMBER_NAME, hmInput.get(CommonDefs.PARENT_HANDLE));
        memberInfo.put(MPSDefs.DB_DOMAIN_NAME, hmInput.get(CommonDefs.PARENT_DOMAIN));
        memberInfo.put("queryDSL",MPSDefs.YES);
        return getMemberService.getMemberServices(memberInfo);
    }

    private HashMap<String, Object> getSubAccountsInfo(String memberName, String domainName) {
        HashMap<String, Object> subAcccountDetails = getProfileByGroupNum.queryMemberServiceInfo(memberName, domainName);
        String appStatusCode = (String) subAcccountDetails.get(CommonDefs.COMMON_APP_STATUS_CODE);
        if (!CErrorDefs.COMMON_SUCCESS.equals(appStatusCode) && !MPSDefs.REC_NOT_FOUND.equals(appStatusCode)) {
            String appInfo = "Error while retrieving subAccountDetails";
            logger.info("{}{}ASMIDH_17 : {}", CLASS_NAME, "getSubAccountsInfo", appInfo);
            subAcccountDetails = CommonErrorMap.makeCategoryMap(Integer.parseInt(appStatusCode), appInfo);
            return subAcccountDetails;
        }
        return subAcccountDetails;
    }
    // Checks if the parent is a sub-account
    private boolean isSubAccount(HashMap<String, Object> parentInfoHash) {
        Object ind = parentInfoHash.get(MPSDefs.DB_PARENT_CHILD_IND);
        return MPSDefs.MPS_CHILD.equals(ind) || MPSDefs.MPS_SLID.equals(ind) || "D".equals(ind) || "E".equals(ind);
    }

    // Gets parent services from the parent info hash
    private HashMap<String, Object> getParentServices(HashMap<String, Object> parentInfoHash, String methodName) {
        if (!parentInfoHash.containsKey(MPSDefs.SERVICES)) {
            logger.info("{}{} : Parent has no services", CLASS_NAME, methodName);
            return null;
        }
        return (HashMap<String, Object>) parentInfoHash.get(MPSDefs.SERVICES);
    }

    /**
     * Processes parent services to determine eligibility and prepare service inputs.
     * Iterates over parent services, checks eligibility, prepares notification details,
     * handles VOIP status, and populates MPS/DBUS service lists.
     *
     * @param parentServices Map of parent service names to their details.
     */
    private void processParentServices(HashMap<String, Object> parentServices, String transactionName, String callingSystemId, boolean bVOIPServiceActive, boolean bDidSubInheritedServicesFromParent,
                                       ArrayList<Object> alDbusServices, ArrayList<Object> alNotifyServices,  ArrayList<Object> alMPSServices, Map<String, Object> hmMemberServiceInfo ) {
        String methodName = "processParentServices";
        HashSet<String> serviceAlreadyAdded = new HashSet<>();
        for (String key : parentServices.keySet()) {
            //alSubServices - AddSec_Sub_Eligible_Services=1544|VOIP|PORTAL|HSIA
            if (!alSubServices.contains(key) || serviceAlreadyAdded.contains(key)) {
                continue;
            }
            bParentHasSubService = true;
            serviceAlreadyAdded.add(key);

            HashMap<String, Object> hmServiceName = (HashMap<String, Object>) parentServices.get(key);
            String sCheckServiceStatus = (String) hmServiceName.get(MPSDefs.SERVICE_STATUS);
            if (MPSDefs.ENABLED.equals(sCheckServiceStatus) && !bEnabledEligServiceFound) {
                bEnabledEligServiceFound = true;
            }

            //alConfigNotifyServices - AddSec_Notify_Services=VOIP
            if (alConfigNotifyServices != null && alConfigNotifyServices.contains(key)) {
                alNotifyServices.add(prepareNotifyService(hmServiceName, key, sCheckServiceStatus));
            }

            if (MPSDefs.VOIP_SERVICE.equals(key)) {
                if (!MPSDefs.TERMINATED.equals(sCheckServiceStatus)) {
                    bVOIPServiceActive = true;
                }
                continue;
            }

            hmServiceName.put(CommonDefs.TRANSACTION_NAME, transactionName);
            hmServiceName.put(CommonDefs.CALLING_SYSTEM_ID, callingSystemId);
            //alMemberLSServices - AddSec_Member_LS_Service=HSIA|IPTV|VOIP
            HashMap hmTempService = createServiceArrayList(hmServiceName, key, alMemberLSServices);
            logger.info(SpiMarker.getInstance(), "{}{}ASMIDH_07.1 : Service Input for key {} : {}", CLASS_NAME, methodName, key, StructuredArguments.entries(hmTempService));

            if (hmTempService.containsKey(MPS_SERVICE_KEY)) {
                HashMap hmMPSServiceInput = (HashMap) hmTempService.get(MPS_SERVICE_KEY);
                hmMPSServiceInput.put(MPSDefs.DB_LAST_MODIFIED_BY, callingSystemId);
                alMPSServices.add(hmMPSServiceInput);
                hmMemberServiceInfo.put(key, hmMPSServiceInput);
            }

            if (hmTempService.containsKey(DBUS_SERVICE_KEY)) {
                HashMap hmDbusServiceInput = (HashMap) hmTempService.get(DBUS_SERVICE_KEY);
                alDbusServices.add(hmDbusServiceInput);
                if (!bDidSubInheritedServicesFromParent) {
                    bDidSubInheritedServicesFromParent = true;
                }
            }
        }
    }

    /**
     * Prepares notification service details for a given service.
     *
     * @param hmServiceName Service details map.
     * @param key Service key.
     * @param serviceStatus Service status.
     * @return Notification service map.
     */
    private HashMap prepareNotifyService(HashMap<String, Object> hmServiceName, String key, String serviceStatus) {
        HashMap hmNotifyService = CommonUtil.getHashMap();
        hmNotifyService.put(CommonDefs.SERVICE_TYPE, CommonDefs.SERVICE_VALUES.get(key));
        hmNotifyService.put(CommonDefs.SERVICE_STATUS, serviceStatus);
        for (Object keyNS : hmServiceName.keySet()) {
            Object valueNS = hmServiceName.get(keyNS);
            if (valueNS instanceof HashMap) {
                HashMap hmTempNS = (HashMap) valueNS;
                hmNotifyService.put(CommonDefs.EMAIL_ELIGIBLE, hmTempNS.get(MPSDefs.DB_EMAIL_ELIGIBLE));
                hmNotifyService.put(CommonDefs.SOR_NAME, hmTempNS.get(MPSDefs.DB_SOR_NAME));
                hmNotifyService.put(CommonDefs.MEMBER_STATUS, hmTempNS.get(MPSDefs.DB_MEMBER_STATUS_NAME));
                hmNotifyService.put(CommonDefs.INSTANCE_ID, keyNS);
            }
        }
        return hmNotifyService;
    }

    /**
     * Adds services to the database for a member, performing all DB updates in parallel.
     * Executes main service, portal user, and DSL user DB operations concurrently.
     *
     * @param alMPSServices List of service input maps.
     * @param memberNum Member number.
     * @param groupNum Group number.
     * @param callingSystemId Calling system ID.
     * @param parentServices Parent services map.
     * @return Result map from service addition.
     * @throws MPSException if service addition fails.
     */
    public Map<String, Object> addServicesToDB(
            ArrayList<Object> alMPSServices,
            String memberNum,
            String groupNum,
            String callingSystemId,
            HashMap<String, Object> parentServices) throws MPSException {

        Map<String, Object> result = CommonUtil.getHashMap();
        final String methodName = ".addServicesToDB";
        final HashMap<String, Object> serviceMap = new HashMap<>();
        serviceMap.put("services", alMPSServices);
        serviceMap.put(MPSDefs.DB_MEMBER_NUM, memberNum);
        serviceMap.put(MPSDefs.DB_GROUP_NUM, groupNum);

        result = addServiceDBHelper.addServices(serviceMap);
        if (!CommonDefs.COMMON_SUCCESS.equals(result.get(MPSDefs.APP_STATUS_CODE))) {
            return result;
        }

        CompletableFuture<Map<String, Object>> portalUserFuture = CompletableFuture.completedFuture(result);
        Optional<HashMap<String, Object>> portalServiceOpt = alMPSServices.stream()
                .filter(obj -> obj instanceof HashMap)
                .map(obj -> (HashMap<String, Object>) obj)
                .filter(serviceObj -> MPSDefs.PORTAL_SERVICE.equals(serviceObj.get(MPSDefs.DB_SERVICE_NAME)))
                .findFirst();

        if (portalServiceOpt.isPresent()) {
            portalUserFuture = CompletableFuture.supplyAsync(() -> {
                HashMap<String, Object> hmPortalSvc = parentServices.get(MPSDefs.PORTAL_SERVICE) instanceof HashMap
                        ? (HashMap<String, Object>) parentServices.get(MPSDefs.PORTAL_SERVICE)
                        : null;
                HashMap<String, Object> hmPortalUser = new HashMap<>();
                hmPortalUser.put(MPSDefs.DB_MEMBER_NUM, memberNum);
                hmPortalUser.put(MPSDefs.DB_SERVICE_ID, hmPortalSvc != null ? hmPortalSvc.get(MPSDefs.DB_SERVICE_ID) : null);
                hmPortalUser.put(MPSDefs.DB_PORTAL_PROVIDER, CommonDefs.PORTAL_PROVIDER_ATT_YAHOO);
                hmPortalUser.put(MPSDefs.DB_LAST_MODIFIED_BY, callingSystemId);
                logger.debug("{}{}ASMIDH_10.02 : Calling MemberDBHelper.addPortalUser with Input: {}", CLASS_NAME, methodName, CommonUtilHelper.sanitizeForLog(String.valueOf(hmPortalUser)));
                return addMemberDBHelper.addPortalUser(hmPortalUser);
            });
        }

        CompletableFuture<Map<String, Object>> dslUserFuture = CompletableFuture.completedFuture(result);
        Optional<HashMap<String, Object>> dslServiceOpt = alMPSServices.stream()
                .filter(obj -> obj instanceof HashMap)
                .map(obj -> (HashMap<String, Object>) obj)
                .filter(serviceObj -> MPSDefs.DSL_SERVICE.equals(serviceObj.get(MPSDefs.DB_SERVICE_NAME)))
                .findFirst();

        if (dslServiceOpt.isPresent()) {
            dslUserFuture = CompletableFuture.supplyAsync(() -> {
                HashMap<String, Object> hmDslSvc = parentServices.get(MPSDefs.DSL_SERVICE) instanceof HashMap
                        ? (HashMap<String, Object>) parentServices.get(MPSDefs.DSL_SERVICE)
                        : null;
                HashMap<String, Object> hmDslUser = buildDslUserMap(hmDslSvc, memberNum, callingSystemId);
                logger.debug("{}{}ASMIDH_10.03 : Calling MemberDBHelper.addDslUser with Input: {}", CLASS_NAME, methodName, CommonUtilHelper.sanitizeForLog(String.valueOf(hmDslUser)));
                return addMemberDBHelper.addDslUser(hmDslUser);
            });
        }

        CompletableFuture<Void> allUpdates = CompletableFuture.allOf(portalUserFuture, dslUserFuture);
        try {
            allUpdates.join();
            Map<String, Object> portalResult = portalUserFuture.get();
            Map<String, Object> dslResult = dslUserFuture.get();

            if (portalServiceOpt.isPresent() && !CommonDefs.COMMON_SUCCESS.equals(portalResult.get(MPSDefs.APP_STATUS_CODE))) {
                return portalResult;
            }
            if (dslServiceOpt.isPresent() && !CommonDefs.COMMON_SUCCESS.equals(dslResult.get(MPSDefs.APP_STATUS_CODE))) {
                return dslResult;
            }
            return result;
        } catch (InterruptedException | ExecutionException e) {
            logger.error("{}{}ASMIDH_10.99 : Exception during parallel DB updates: {}", CLASS_NAME, methodName,CommonUtilHelper.sanitizeForLog(e.getMessage()));
            result.put(MPSDefs.APP_STATUS_CODE, CErrorDefs.ERR_SYS_APPL_NUM);
            result.put(MPSDefs.APP_INFO, "Exception during parallel DB updates: " + e.getMessage());
            return result;
        }
    }

    /**
     * Builds DSL user map for database insertion.
     * @param hmDslSvc DSL service map.
     * @param memberNum Member number.
     * @param callingSystemId Calling system ID.
     * @return DSL user map.
     */
    private HashMap<String, Object> buildDslUserMap(HashMap<String, Object> hmDslSvc, String memberNum, String callingSystemId) {
        HashMap<String, Object> hmDslUser = new HashMap<>();
        hmDslUser.put(MPSDefs.DB_MEMBER_NUM, memberNum);
        hmDslUser.put(MPSDefs.DB_SERVICE_ID, hmDslSvc.get(MPSDefs.DB_SERVICE_ID));
        hmDslUser.put(MPSDefs.DB_CIRCUIT_ID, hmDslSvc.get(MPSDefs.DB_CIRCUIT_ID));
        hmDslUser.put(MPSDefs.DB_VIRTUAL_PATH, hmDslSvc.get(MPSDefs.DB_VIRTUAL_PATH));
        hmDslUser.put(MPSDefs.DB_VIRTUAL_CIRCUIT, hmDslSvc.get(MPSDefs.DB_VIRTUAL_CIRCUIT));
        hmDslUser.put(MPSDefs.DB_INCOMING_BURST, hmDslSvc.get(MPSDefs.DB_INCOMING_BURST));
        hmDslUser.put(MPSDefs.DB_INCOMING_LIMIT, hmDslSvc.get(MPSDefs.DB_INCOMING_LIMIT));
        hmDslUser.put(MPSDefs.DB_OUTGOING_BURST, hmDslSvc.get(MPSDefs.DB_OUTGOING_BURST));
        hmDslUser.put(MPSDefs.DB_OUTGOING_LIMIT, hmDslSvc.get(MPSDefs.DB_OUTGOING_LIMIT));
        hmDslUser.put(MPSDefs.DB_PROTOCOL_TYPE, hmDslSvc.get(MPSDefs.DB_PROTOCOL_TYPE));
        hmDslUser.put(MPSDefs.DB_IP_ADDRESS, hmDslSvc.get(MPSDefs.DB_IP_ADDRESS));
        hmDslUser.put(MPSDefs.DB_IP_NETBLOCK, hmDslSvc.get(MPSDefs.DB_IP_NETBLOCK));
        hmDslUser.put(MPSDefs.DB_IP_SUBNET, hmDslSvc.get(MPSDefs.DB_IP_SUBNET));
        hmDslUser.put(MPSDefs.DB_WTN, hmDslSvc.get(MPSDefs.DB_WTN));
        hmDslUser.put(MPSDefs.DB_LAST_MODIFIED_BY, callingSystemId);
        hmDslUser.put(MPSDefs.DB_NETWORK_PROFILE_ID, hmDslSvc.get(MPSDefs.DB_NETWORK_PROFILE_ID));
        hmDslUser.put(MPSDefs.DB_DSLAM_TYPE, hmDslSvc.get(MPSDefs.DB_DSLAM_TYPE));
        hmDslUser.put(MPSDefs.DB_TDSL_IND, hmDslSvc.get(MPSDefs.DB_TDSL_IND));
        hmDslUser.put(MPSDefs.DB_IPV6RD_ENABLED, hmDslSvc.get(MPSDefs.DB_IPV6RD_ENABLED));
        hmDslUser.put(MPSDefs.DB_IPV6RD_MANUALLY_DISABLED, hmDslSvc.get(MPSDefs.DB_IPV6RD_MANUALLY_DISABLED));
        hmDslUser.put(MPSDefs.DB_DNS_ERR_OPTOUT_IND, hmDslSvc.get(MPSDefs.DB_DNS_ERR_OPTOUT_IND));
        return hmDslUser;
    }

    // Determines if SLID should be auto-generated
    private boolean shouldAutoGenSlid(HashMap<String, Object> parentInfoHash) {
        String sAccountType = (String) parentInfoHash.get(MPSDefs.DB_ACCOUNT_TYPE);
        //alAutoGenSlidAccountType - AddSec_Autogen_Slid_Account_Type=R|B
        if (alAutoGenSlidAccountType.contains(CommonDefs.ACTIVE)) return true;
        if (alAutoGenSlidAccountType.contains(MPSDefs.DB_CONSUMER) && (sAccountType == null || sAccountType.equalsIgnoreCase(MPSDefs.DB_CONSUMER))) return true;
        if (alAutoGenSlidAccountType.contains(MPSDefs.DB_BUSINESS) && (sAccountType == null || sAccountType.equalsIgnoreCase(MPSDefs.DB_BUSINESS))) return true;
        return !alAutoGenSlidAccountType.contains(CommonDefs.IND_N);
    }

    /**
     * Prepares the notification input map for a secondary member addition event.
     * <p>
     * This method populates the notification input map with relevant details from the input and parent info,
     * including member and parent attributes, services, and notification fields. It also handles the addition
     * of new services and notification data if the contact email is present.
     *
     * @param hmInput         The input map containing sub-account creation request details.
     * @param parentInfoHash  The map containing parent account information.
     * @param memberNum       The member number of the newly added sub-account.
     * @param ban             The billing account number associated with the account.
    */
    private void prepareNotificationInput(HashMap<String, Object> hmInput, HashMap<String, Object> parentInfoHash, HashMap<String, Object> parentServices, String memberNum, String ban,
                                          ArrayList<Object> alDbusServices, ArrayList<Object> alNotifyServices, ArrayList<Map<String, Object>> alDbusEvents) {
        HashMap hmNotificationInput = new HashMap();
        if (parentServices != null && !parentServices.isEmpty() && parentServices.containsKey(CommonDefs.UVERSE_SERVICE)) {
            hmNotificationInput.put(CommonDefs.EVENTNAME, CommonDefs.CONTEXT_NotificationEvent);
            hmNotificationInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
            hmNotificationInput.put(CommonDefs.PARENT_HANDLE, hmInput.get(CommonDefs.PARENT_HANDLE));
            hmNotificationInput.put(CommonDefs.HANDLE, hmInput.get(CommonDefs.HANDLE));
            hmNotificationInput.put(CommonDefs.DOMAIN, hmInput.get(CommonDefs.DOMAIN));
            hmNotificationInput.put(CommonDefs.PARENT_DOMAIN, hmInput.get(CommonDefs.PARENT_DOMAIN));
            hmNotificationInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
            hmNotificationInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
            hmNotificationInput.put("origTransactionId", hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
            hmNotificationInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
            hmNotificationInput.put(CommonDefs.DB_MEMBER_NUM, memberNum);
            hmNotificationInput.put(CommonDefs.CONTACT_EMAIL, hmInput.get(CommonDefs.CONTACT_EMAIL));
            hmNotificationInput.put(CommonDefs.DB_PARENT_CHILD_IND, MPSDefs.MPS_CHILD);
            hmNotificationInput.put(CommonDefs.MEMBER_STATUS, MPSDefs.ENABLED);
            hmNotificationInput.put(CommonDefs.BROWSER_LANGUAGE, null); // Sub cannot inherit the parent browser language
            hmNotificationInput.put(CommonDefs.FIRST_NAME, hmInput.get(CommonDefs.FIRST_NAME));
            hmNotificationInput.put(CommonDefs.LAST_NAME, hmInput.get(CommonDefs.LAST_NAME));
            hmNotificationInput.put(CommonDefs.PARENT_FIRST_NAME, parentInfoHash.get(MPSDefs.DB_LC_FIRSTNAME));
            hmNotificationInput.put(CommonDefs.PARENT_LAST_NAME, parentInfoHash.get(MPSDefs.DB_LC_LASTNAME));
            hmNotificationInput.put(CommonDefs.PARENT_CONTACT_EMAIL, parentInfoHash.get(MPSDefs.DB_CONTACT_EMAIL));
            hmNotificationInput.put(CommonDefs.PARENT_BROWSER_LANGUAGE, hmInput.get(MPSDefs.DB_BROWSER_LANGUAGE));
            hmNotificationInput.put(CommonDefs.PARENT_SERVICES, prepareParSvcForEDDNotification(parentServices));
            hmNotificationInput.put(CommonDefs.BAN, ban);
            hmNotificationInput.put(CommonDefs.SOR_NAME, parentInfoHash.get(MPSDefs.DB_SOR_NAME));

            if (alDbusServices != null && !alDbusServices.isEmpty()) {
                alNotifyServices.addAll(alDbusServices);
            }
            if (!alNotifyServices.isEmpty()) {
                hmNotificationInput.put(CommonDefs.NEW_SERVICES, alNotifyServices);
            }

            HashMap<String, Object> hmNotificationFields = new HashMap<>();
            hmNotificationFields.put(CommonDefs.CONTACT_EMAIL, hmInput.get(CommonDefs.CONTACT_EMAIL));
            hmNotificationFields.put(MPSDefs.DB_SECURITY_ANSWER_1, hmInput.get(CommonDefs.ONLINE1_SECURITY_ANSWER));
            hmNotificationFields.put(MPSDefs.DB_SECURITY_ANSWER_2, hmInput.get(CommonDefs.ONLINE2_SECURITY_ANSWER));
            hmNotificationFields.put(MPSDefs.DB_PASSCODE, hmInput.get(CommonDefs.PASSCODE));
            putIfPresent(hmNotificationFields, CommonDefs.LAST_FOUR_SSN, hmInput);
            putIfPresent(hmNotificationFields, CommonDefs.DATE_OF_BIRTH, hmInput);
            putIfPresent(hmNotificationFields, CommonDefs.SECURITY_ANSWER, hmInput);
            putIfPresent(hmNotificationFields, CommonDefs.PROOF_ZIP, hmInput);
            hmNotificationFields.put(CommonDefs.BROWSER_LANGUAGE, null);
            hmNotificationFields.put(CommonDefs.SECURITY_QUESTION, hmInput.get(CommonDefs.SECURITY_QUESTION));
            hmNotificationFields.put(CommonDefs.ONLINE1_SECURITY_QUESTION, hmInput.get(CommonDefs.ONLINE1_SECURITY_QUESTION));
            hmNotificationFields.put(CommonDefs.ONLINE2_SECURITY_QUESTION, hmInput.get(CommonDefs.ONLINE2_SECURITY_QUESTION));
            hmNotificationInput.put(CommonDefs.NOTIFICATION_FIELDS, hmNotificationFields);

            String contactEmail = (String) hmInput.get(CommonDefs.CONTACT_EMAIL);
            if (contactEmail != null && !contactEmail.trim().isEmpty()) {
                HashMap<String, Object> hmNotificationData = new HashMap<>();
                hmNotificationData.put(CommonDefs.CONTACT_EMAIL, contactEmail);
                hmNotificationData.put(CommonDefs.CONTACT_EMAIL_STATUS, "V");

                ArrayList<HashMap<String, Object>> alMemberContactEmail = new ArrayList<>();
                alMemberContactEmail.add(hmNotificationData);

                HashMap<String, Object> hmSubNotificationData = new HashMap<>();
                hmSubNotificationData.put(CommonDefs.MEMBER_CONTACT_EMAIL, alMemberContactEmail);

                ArrayList<HashMap<String, Object>> alNotificationData = new ArrayList<>();
                alNotificationData.add(hmSubNotificationData);

                hmNotificationInput.put(CommonDefs.NOTIFICATION_DATA, alNotificationData);
            }
        }
        if (hmNotificationInput != null && !hmNotificationInput.isEmpty()) {
            alDbusEvents.add(hmNotificationInput);
        }
    }

    /**
     * Adds a key-value pair to the map if the value from the source map is not null.
     *
     * @param map    The map to add the key-value pair to.
     * @param key    The key to add.
     * @param source The source map to retrieve the value from.
     * */
    private void putIfPresent(HashMap<String, Object> map, String key, HashMap<String, Object> source) {
        Object value = source.get(key);
        if (value != null) {
            map.put(key, value);
        }
    }

    /**
     * Prepares the DBUS input for adding a secondary member.
     * <p>
     * This method constructs the event data required for DBUS processing when a secondary member is added.
     * It determines the sub-event context, retrieves or initializes the DBUS input and events data,
     * populates the event data with relevant fields, and handles service group logic for LS, DSL, or DIAL services.
     * The method also sets member status and attaches service details if available.
     * Finally, it adds the event data to the DBUS events list if not empty.
     *
     * @param hmInput                The input map containing sub-account creation request details.
     * @param parentInfoHash         The map containing parent account information.
     * @param addUserhelperHmResult  The result map from the add user helper, containing DBUS input and events data.
     * @param ban                    The billing account number associated with the account.
     */
    private void prepareAddSecDbusInput(Map<String, Object> hmInput, Map<String, Object> parentInfoHash, Map<String, Object> parentServices,
                                         Map<String, Object> addUserhelperHmResult, String ban, String transactionName, boolean bVOIPServiceActive, boolean bDidSubInheritedServicesFromParent, ArrayList<Object> alDbusServices, ArrayList<Map<String, Object>> alDbusEvents) {
         String dbusSubEventName = bVOIPServiceActive ? CommonDefs.CONTEXT_ParentHasVoIP : CommonDefs.CONTEXT_AddingASub;

         Map<String, Object> addUserhelperDbusInput = getOrDefault(addUserhelperHmResult, "dbusInput", new HashMap());
         ArrayList addUserhelperDbusEventsData = getOrDefault(addUserhelperDbusInput, "eventsData", new ArrayList());

         HashMap<String, Object> eventData = !addUserhelperDbusEventsData.isEmpty() && addUserhelperDbusEventsData.get(0) instanceof HashMap
                 ? (HashMap<String, Object>) addUserhelperDbusEventsData.get(0)
                 : new HashMap<>();

         populateEventData(eventData, hmInput, parentInfoHash, dbusSubEventName, ban, transactionName);

         if (MPSDefs.SOR_LS.equals(sor)) {
             handleLsServiceGroup(eventData, parentInfoHash, alDbusServices);
         } else if (parentServices != null && (parentServices.containsKey(MPSDefs.DIAL_SERVICE)
                 || parentServices.containsKey(MPSDefs.DSL_SERVICE))) {
             handleDslDialServiceGroup(eventData, parentServices, alDbusServices);
         }

         if (!bDidSubInheritedServicesFromParent) {
             eventData.put(MPSDefs.DB_LAST_MEMBER_STATUS_NAME, MPSDefs.ENABLED);
         }

         if (alDbusServices != null && !alDbusServices.isEmpty()) {
             eventData.put(CommonDefs.SERVICES, alDbusServices);
         }

         if (!eventData.isEmpty()) {
             alDbusEvents.add(eventData);
         }
    }

    /**
     * Returns the value for the given key from the map, or the default value if the key is not present or is null.
     *
     * @param map          The map to retrieve the value from.
     * @param key          The key whose value is to be retrieved.
     * @param defaultValue The default value to return if the key is not present or is null.
     * @param <T>          The type of the value.
     * @return The value associated with the key, or the default value.
     */
    private <T> T getOrDefault(Map<String, Object> map, String key, T defaultValue) {
        return map.get(key) != null ? (T) map.get(key) : defaultValue;
    }

    /**
     * Populates the event data map with relevant fields for DBUS processing.
     * <p>
     * This method adds transaction, parent, migration, zip, nickname, contact email validation,
     * account status, BAN, and migration indicator fields to the event data map.
     *
     * @param eventData         The map to populate with event data.
     * @param hmInput           The input map containing sub-account creation request details.
     * @param parentInfoHash    The map containing parent account information.
     * @param dbusSubEventName  The sub-event context name.
     * @param ban               The billing account number.
     */
    private void populateEventData(Map<String, Object> eventData, Map<String, Object> hmInput,
                                    Map<String, Object> parentInfoHash, String dbusSubEventName, String ban,  String transactionName) {
         putIfNotNull(eventData, "origTransactionId", hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
         putIfNotNull(eventData, CommonDefs.TRANSACTION_NAME, transactionName);
         putIfNotNull(eventData, CommonDefs.SUBEVENT, dbusSubEventName);
         putIfNotNull(eventData, CommonDefs.PARENT_HANDLE, hmInput.get(CommonDefs.PARENT_HANDLE));
         putIfNotNull(eventData, CommonDefs.PARENT_DOMAIN, hmInput.get(CommonDefs.PARENT_DOMAIN));
         putIfNotNull(eventData, CommonDefs.DB_GEN_PASSWORD_TYPE, eventData.get("passwordType"));
         putIfNotNull(eventData, CommonDefs.MIGRATION_IND, parentInfoHash.get(MPSDefs.DB_MIGRATION_IND));
         putIfNotNull(eventData, CommonDefs.ZIP, hmInput.get(CommonDefs.PROOF_ZIP));
         putIfNotNull(eventData, CommonDefs.NICKNAME, hmInput.get(CommonDefs.IGP_NICK_NAME));

         String contactEmail = hmInput.get(CommonDefs.CONTACT_EMAIL) == null ? null : hmInput.get(CommonDefs.CONTACT_EMAIL).toString().trim();
         String contactEmailValid = contactEmail == null ? null : validateContactEmail(contactEmail);
         putIfNotNull(eventData, MPSDefs.DB_CONTACT_EMAIL_VALID, contactEmailValid);

         if (CommonDefs.CONTEXT_ParentHasVoIP.equals(dbusSubEventName)) {
             eventData.put(CommonDefs.ACCOUNTSTATUS, MPSDefs.ENABLED);
         }

         putIfNotNull(eventData, CommonDefs.BAN, ban);
         eventData.put("isSDPMigrated", CommonDefs.IND_Y);
    }

    /**
     * Handles LS service group logic for DBUS event data.
     * <p>
     * Adds LS service group details to the event data and DBUS services list.
     *
     * @param eventData        The event data map to update.
     * @param parentInfoHash   The parent account information map.
     */
    private void handleLsServiceGroup(Map<String, Object> eventData, Map<String, Object> parentInfoHash, ArrayList<Object> alDbusServices) {
        String siteZip = (String) parentInfoHash.get(CommonDefs.ZIP);
        putIfNotNull(eventData, CommonDefs.SITE_ZIP, siteZip);
        String ipdslamInd = (String) parentInfoHash.get(MPSDefs.DB_IPDSLAM_IND);
        eventData.put(CommonDefs.IPDSLAM_IND, ipdslamInd != null ? ipdslamInd : CommonDefs.IND_N);

        HashMap<String, Object> hmLSGroup = new HashMap<>();
        hmLSGroup.put(CommonDefs.SERVICE_TYPE, CommonDefs.LSO_SERVICE);
        hmLSGroup.put(CommonDefs.SERVICE_STATUS, MPSDefs.ENABLED);
        hmLSGroup.put(CommonDefs.SOR_NAME, sor);
        alDbusServices.add(hmLSGroup);
    }

    /**
     * Handles DSL/DIAL service group logic for DBUS event data.
     * <p>
     * Adds DSL/DIAL service group details to the DBUS services list.
     *
     * @param eventData      The event data map to update.
     * @param parentServices The parent services map.
     */
    private void handleDslDialServiceGroup(Map<String, Object> eventData, Map<String, Object> parentServices, ArrayList<Object> alDbusServices) {
        HashMap<String, Object> hmNonLSGroup = new HashMap<>();
        hmNonLSGroup.put(CommonDefs.SERVICE_TYPE, CommonDefs.DSLD_SERVICE);
        hmNonLSGroup.put(CommonDefs.SERVICE_STATUS, MPSDefs.ENABLED);

        String sServiceLevelSorName = getServiceLevelSorName(parentServices);
        hmNonLSGroup.put(CommonDefs.SOR_NAME, sServiceLevelSorName);
        alDbusServices.add(hmNonLSGroup);
    }

    /**
     * Retrieves the SOR name for the service level from the parent services map.
     *
     * @param parentServices The parent services map.
     * @return The SOR name for the service level, or the default SOR if not found.
     */
    private String getServiceLevelSorName(Map<String, Object> parentServices) {
        String sServiceLevelSorName = null;
        if (parentServices.containsKey(MPSDefs.DSL_SERVICE)) {
            sServiceLevelSorName = (String) ((HashMap) parentServices.get(MPSDefs.DSL_SERVICE)).get(MPSDefs.DB_SOR_NAME);
        } else if (parentServices.containsKey(MPSDefs.DIAL_SERVICE)) {
            sServiceLevelSorName = (String) ((HashMap) parentServices.get(MPSDefs.DIAL_SERVICE)).get(MPSDefs.DB_SOR_NAME);
        }
        return (sServiceLevelSorName != null && !sServiceLevelSorName.trim().isEmpty()) ? sServiceLevelSorName : sor;
    }

    /**
     * Prepares the input map required for linking a member account.
     * <p>
     * This method constructs a HashMap containing all necessary fields for the link member operation,
     * including access ID, member ID, domain, transaction names, calling system ID, and various flags.
     * The resulting map is used as input for downstream linking processes.
     *
     * @param hmInput The input map containing member details such as handle and transaction IDs.
     * @param domain  The domain to be associated with the member.
     * @return A HashMap containing the prepared input for the link member operation.
     */
    private HashMap<String, Object> prepareLinkMemberInput(HashMap<String, Object> hmInput, String domain, String callingSystemId) {
        HashMap<String, Object> hmLIAHelperInput = CommonUtil.getHashMap();
        hmLIAHelperInput.put(CommonDefs.ACCESS_ID, hmInput.get(CommonDefs.HANDLE) + "@" + domain);
        hmLIAHelperInput.put(CommonDefs.MEMBERID, hmInput.get(CommonDefs.HANDLE));
        hmLIAHelperInput.put(CommonDefs.DOMAIN,domain);
        hmLIAHelperInput.put(CommonDefs.TRANSACTION_NAME, ProfileOrchestrationConstants.LINK_MEMBER_TRANSACTION_NAME);
        hmLIAHelperInput.put(CommonDefs.CALLING_SYSTEM_ID, callingSystemId);
        hmLIAHelperInput.put(CommonDefs.CALLDBUS, CommonDefs.IND_N);
        hmLIAHelperInput.put(CommonDefs.ORIG_TRANSACTION_NAME, ProfileOrchestrationConstants.ADD_SEC_MEMBERID_TRANSACTION_NAME);
        hmLIAHelperInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.IDPTRACEID));
        hmLIAHelperInput.put(ProfileOrchestrationConstants.IDPTRACEID, hmInput.get(ProfileOrchestrationConstants.IDPTRACEID));
        hmLIAHelperInput.put(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
        hmLIAHelperInput.put(CommonDefs.IS_ACCESSS_ID_AUTOGEN, CommonDefs.IND_Y);
        hmLIAHelperInput.put("ignoreEDDNotification", CommonDefs.IND_Y);
        return hmLIAHelperInput;
    }

    /**
     * Prepares a HashMap containing member information for a sub-account.
     * <p>
     * This method populates the provided user input map (`hmAddUserInp`) with various member attributes,
     * such as parent-child indicator, service info, member name, domain, SOR, first and last name,
     * migration indicator, parent domain and name, and account type. It then wraps this map in another
     * HashMap under the key "member" and returns it.
     *
     * @param hmInput      The input map containing parent handle and domain information.
     * @param hmAddUserInp The map containing sub-account user details to be populated.
     * @return A HashMap with the key "member" mapping to the populated sub-account details.
     */
    private HashMap<String, Object> prepareHmMemberInfo(HashMap<String, Object> hmInput, HashMap<String, Object> hmAddUserInp, Map<String, Object> hmMemberServiceInfo) {
        HashMap<String, Object> hmMemberInfo = CommonUtil.getHashMap();
        hmAddUserInp.put(MPSDefs.DB_PARENT_CHILD_IND,MPSDefs.MPS_CHILD);
        hmAddUserInp.put(MPSDefs.SERVICES, hmMemberServiceInfo);
        hmAddUserInp.put(MPSDefs.DB_MEMBER_NAME, hmAddUserInp.get(CommonDefs.HANDLE));
        hmAddUserInp.put(MPSDefs.DB_DOMAIN_NAME, hmAddUserInp.get(CommonDefs.DOMAIN));
        hmAddUserInp.put(MPSDefs.DB_SOR_NAME, hmAddUserInp.get(CommonDefs.SOR));
        hmAddUserInp.put(MPSDefs.DB_LC_FIRSTNAME, hmAddUserInp.get(CommonDefs.FIRST_NAME));
        hmAddUserInp.put(MPSDefs.DB_LC_LASTNAME, hmAddUserInp.get(CommonDefs.LAST_NAME));
        hmAddUserInp.put(MPSDefs.DB_CONTACT_EMAIL, hmAddUserInp.get(CommonDefs.CONTACT_EMAIL));
        hmAddUserInp.put(MPSDefs.DB_MIGRATION_IND, hmAddUserInp.get(CommonDefs.MIGRATION_IND));
        hmAddUserInp.put(MPSDefs.DB_PARENT_DOMAIN, hmInput.get(CommonDefs.PARENT_DOMAIN));
        hmAddUserInp.put(MPSDefs.DB_PARENT_NAME, hmInput.get(CommonDefs.PARENT_HANDLE));
        hmAddUserInp.put(MPSDefs.DB_ACCOUNT_TYPE, hmAddUserInp.get(CommonDefs.ACCOUNT_TYPE));
        hmAddUserInp.put(MPSDefs.DB_SECURITY_ANSWER_1, hmAddUserInp.get(CommonDefs.ONLINE1_SECURITY_ANSWER));
        hmAddUserInp.put(MPSDefs.DB_SECURITY_ANSWER_2, hmAddUserInp.get(CommonDefs.ONLINE2_SECURITY_ANSWER));
        hmAddUserInp.put(MPSDefs.DB_SECURITY_QUESTION_1, hmAddUserInp.get(CommonDefs.ONLINE1_SECURITY_QUESTION));
        hmAddUserInp.put(MPSDefs.DB_SECURITY_QUESTION_2, hmAddUserInp.get(CommonDefs.ONLINE2_SECURITY_QUESTION));
        hmAddUserInp.put(CommonDefs.OFFLINE1_SECURITY_QUESTION, hmAddUserInp.get(CommonDefs.SECURITY_QUESTION));

        hmMemberInfo.put("member", hmAddUserInp);
        return hmMemberInfo;
    }

     /**
     * Fetches parent and sub-account info in parallel, handles errors, and logs securely.
     *
     * @param hmInput input map
     * @param methodName method name for logging
     * @return result map or error map
     */
    private Map<String, Object> fetchParentAndSubAccountsInfo(HashMap<String, Object> hmInput, String methodName) {

        try {
            CompletableFuture<HashMap<String, Object>> parentInfoFuture = CompletableFuture.supplyAsync(() -> getParentInfo(hmInput));
            CompletableFuture<HashMap<String, Object>> subAccountsInfoFuture = CompletableFuture.supplyAsync(() ->
                    getSubAccountsInfo(
                            String.valueOf(hmInput.get(CommonDefs.PARENT_HANDLE)),
                            String.valueOf(hmInput.get(CommonDefs.PARENT_DOMAIN))
                    )
            );

            CompletableFuture.allOf(parentInfoFuture, subAccountsInfoFuture).join();

            HashMap<String, Object> parentInfoHash = parentInfoFuture.get( ) != null ? parentInfoFuture.get() : new HashMap<>();
            String appStatusCode = getString(parentInfoHash, CommonDefs.COMMON_APP_STATUS_CODE);

            if (!CErrorDefs.COMMON_SUCCESS.equals(appStatusCode)) {
                String appInfo = MPSDefs.REC_NOT_FOUND.equals(appStatusCode)
                    ? "ParentMember not found within MPS db"
                    : "getMemberServices from GetMemberServicesDBHelper failed for given ParentUserId and domain";
                logger.info("{}{}ASMIDH_02/03 : {}", CLASS_NAME, methodName, ESAPI.encoder().encodeForHTML(appInfo));
                return CommonErrorMap.makeCategoryMap(
                    MPSDefs.REC_NOT_FOUND.equals(appStatusCode) ? CErrorDefs.ERR_USER_NOT_FOUND_NUM : Integer.parseInt(appStatusCode),
                    appInfo
                );
            }

            HashMap<String, Object> subAccountsInfoHash = subAccountsInfoFuture.get()  != null  ?  subAccountsInfoFuture.get() : new HashMap<>();
            appStatusCode = (String) subAccountsInfoHash.get(CommonDefs.COMMON_APP_STATUS_CODE);

            if (!CErrorDefs.COMMON_SUCCESS.equals(appStatusCode) && !MPSDefs.REC_NOT_FOUND.equals(appStatusCode)) {
                String appInfo = "Error while retrieving subAccountDetails";
                logger.info("{}{}ASMIDH_17 : {}", CLASS_NAME, methodName, ESAPI.encoder().encodeForHTML(appInfo));
                return CommonErrorMap.makeCategoryMap(Integer.parseInt(appStatusCode), appInfo);
            }

            // Return both results in a map for further processing
            Map<String, Object> result = new HashMap<>();
            result.put("parentInfoHash", parentInfoHash);
            result.put("subAccountsInfoHash", subAccountsInfoHash);
            result.put(MPSDefs.APP_STATUS_CODE, MPSDefs.MPS_SUCCESS);
            return result;

        } catch (InterruptedException | ExecutionException e) {
            String errorMsg = "Exception during parallel DB calls: " + e.getMessage();
            logger.error("{}{}ASMIDH_PARALLEL_ERROR : {}", CLASS_NAME, methodName, CommonUtilHelper.sanitizeForLog(errorMsg), e);
            return CommonUtilHelper.sysErrorHashMap(errorMsg);
        }
    }
}