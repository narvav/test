package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class TmonitorconfigId implements Serializable {

	private static final long serialVersionUID = 8460209050035479923L;

	@Column(name = "LISTENER_ID", nullable = false, precision = 22, scale = 0)
	private Long listenerId;

	@Column(name = "SERVICE_ID", nullable = false, precision = 22, scale = 0)
	private Long serviceId;

	@Column(name = "ATTRIBUTE_ID", precision = 22, scale = 0)
	private Long attributeId;

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TmonitorconfigId))
			return false;
		TmonitorconfigId castOther = (TmonitorconfigId) other;

		return ((this.getListenerId() == castOther.getListenerId()) || (this.getListenerId() != null
				&& castOther.getListenerId() != null && this.getListenerId().equals(castOther.getListenerId())))
				&& ((this.getServiceId() == castOther.getServiceId()) || (this.getServiceId() != null
				&& castOther.getServiceId() != null && this.getServiceId().equals(castOther.getServiceId())))
				&& ((this.getAttributeId() == castOther.getAttributeId())
				|| (this.getAttributeId() != null && castOther.getAttributeId() != null
				&& this.getAttributeId().equals(castOther.getAttributeId())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getListenerId() == null ? 0 : this.getListenerId().hashCode());
		result = 37 * result + (getServiceId() == null ? 0 : this.getServiceId().hashCode());
		result = 37 * result + (getAttributeId() == null ? 0 : this.getAttributeId().hashCode());
		return result;
	}
}