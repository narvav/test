package com.att.idp.idgraphusermanagementms.resource.request;

import static org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString;
import static org.apache.commons.lang3.builder.ToStringStyle.JSON_STYLE;

import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * This class represents a Service in the system.
 * It contains fields for serviceType and sorInvariantId.
 * Each field has specific constraints such as not null and size limits.
 *
 * The class uses Lombok's @Data annotation to generate getter and setter methods for all fields.
 * It also overrides the toString method to return a JSON-style string representation of the object.
 *
 */
@Data
public class Service {

	@Size(min=1, max=30,message="serviceType length is invalid|InquireAssociatedAccessIds")
	protected String serviceType;

	@Size(min=1, max=255,message="sorInvariantId length is invalid|InquireAssociatedAccessIds")
	protected String sorInvariantId;

	@Override
	public String toString() {
		return reflectionToString(this, JSON_STYLE);
	}
}