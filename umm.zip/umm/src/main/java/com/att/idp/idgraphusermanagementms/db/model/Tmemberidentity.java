package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TMEMBERIDENTITY", schema = "MPS_OWNER")
public class Tmemberidentity implements Serializable {

	private static final long serialVersionUID = 2147780168388485936L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "memberNum", column = @Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "identity", column = @Column(name = "IDENTITY", nullable = false)) })
	private TmemberidentityId id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MEMBER_NUM", nullable = false, insertable = false, updatable = false)
	private Tmember tmember;

	@Column(name = "IDENTITY_TYPE", nullable = false, length = 30)
	private String identityType;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;
}