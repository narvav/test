package com.att.idp.idgraphusermanagementms.db.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This class is responsible for managing email application password-related operations in the database.
 * It uses Spring's JdbcTemplate for database operations and has methods for querying, adding, and deleting email application passwords.
 * It also uses other helper classes like CommonUtil and CommonErrorMap.
 *
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like JdbcTemplate.
 *
 * The class contains SQL queries as string constants for querying, adding, and deleting email application passwords.
 * These queries are used in the corresponding methods for these operations.
 *
 * The class also contains a logger for logging information and errors.
 *
 * The main methods in this class are:
 * - queryEmailAppPwd: This method retrieves an email application password from the database. It takes a HashMap as input and returns a HashMap as output.
 * - addEmailAppPwd: This method adds an email application password to the database. It takes a HashMap as input and returns a HashMap as output.
 * - deleteEmailAppPwd: This method deletes an email application password from the database. It takes a HashMap as input and returns a HashMap as output.
 */
@Component
public class EmailAppPasswordDBHelper {

	private static final String CLASS_NAME = "EmailAppPasswordDBHelper";
	private static final String INFO = "$Id: master/com/att/idp/idgraphusermanagementms/db/helper/EmailAppPasswordDBHelper.java v1 2020-01-30 kg852c $;";
	public static final Logger log = LoggerFactory.getLogger(EmailAppPasswordDBHelper.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	/**
	 * This method retrieves an email application password from the database.
	 * It takes a HashMap as an argument which contains the details of the email application password to be retrieved.
	 * The HashMap should contain the following key:
	 * - MPSDefs.DB_MEMBER_NUM: The member number.
	 *
	 * The method first logs the start of the operation and the input parameters.
	 * It then checks if the member number is present in the input HashMap.
	 * If the member number is missing, it logs an error and returns an error status.
	 * Otherwise, it prepares the SQL query for retrieving the email application password and executes it using the jdbcTemplate object.
	 * If the operation is successful, the method returns a HashMap containing the status of the operation and the retrieved email application password.
	 * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
	 *
	 * @param hmInput A HashMap containing the details of the email application password to be retrieved.
	 * @return A HashMap containing the status of the operation and the retrieved email application password.
	 */
	public HashMap queryEmailAppPwd(HashMap hmInput) {

		String sMethodName = ".queryEmailAppPwd.";
		log.info("{}{}DBTOOLS01 : CVS KEYWORDS: {}", CLASS_NAME, sMethodName, INFO);
		String stAppInfo = null;
		HashMap hmResult = null;
		String dateFormat = "MMDDYYYY HH24:mi:ss";
		List<Object> objectList = CommonUtil.getArrayList();
		HashMap hmEmailAppPwd = CommonUtil.getHashMap();
		List alQueryResponse = null;
		ArrayList alEmailAppPwd = new ArrayList();

		log.info(ProfileOrchestrationConstants.LOG_DBTOOLS000, CLASS_NAME, sMethodName, hmInput);

		try {

			if (hmInput == null || hmInput.isEmpty()) {
				stAppInfo = "InpParam received in queryEmailAppPwd input is null";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}DBTOOLS_03 : {}", CLASS_NAME, sMethodName, stAppInfo);
				return hmResult;
			}

			String stMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);

			if (stMemberNum == null || stMemberNum.trim().length() <= 0) {
				stAppInfo = "Required Parameter member_num is missing";
				log.info("{}{}MPSDBLRH_002 : {}", CLASS_NAME, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			String sQuery = "SELECT " + "member_num, " + "password_name, " + "password_venc, "
					+ "TO_CHAR(create_date, '" + dateFormat + "') AS create_date, " + "TO_CHAR(last_modified, '"
					+ dateFormat + "') AS last_modified, " + "last_modified_by "
					+ "FROM APPEMAILPASSWORD WHERE member_num = ?";

			objectList.add(stMemberNum);

			log.info("{}{}DBTOOLS_04.5 : Query SQL = {}", CLASS_NAME, sMethodName, sQuery);

			// execute the prepared statement

			alQueryResponse = jdbcTemplate.queryForList(new String(sQuery),
					objectList.toArray(new Object[objectList.size()]));

			int numRowsFound = 0;
			if (alQueryResponse != null && !alQueryResponse.isEmpty()) {
				for (int j = 0; j < alQueryResponse.size(); j++) {
					Map hmQueryResponse = (Map) alQueryResponse.get(j);
					Iterator itr = hmQueryResponse.keySet().iterator();
					while (itr.hasNext()) {
						String key = (String) itr.next();
						Object value = hmQueryResponse.get(key);
						String strValue = (value == null ? null : value.toString());
						hmEmailAppPwd.put(key.toLowerCase(), strValue); // TODO : check for keys with MPS
					}

					++numRowsFound;
				}
			}

			alEmailAppPwd.add(hmEmailAppPwd);

			if (numRowsFound == 0) {
				stAppInfo = "No Record Found in DB";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo);
				log.info("{}{}DB_H_QUFL05 : {}", CLASS_NAME, sMethodName, stAppInfo);
				return hmResult;
			}

			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
			hmResult.put(MPSDefs.DB_APPEMAILPASSWORD_TABLE, alEmailAppPwd);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DB_UPLR_06.1 : Error::{}", CLASS_NAME, sMethodName, e.getMessage());
			log.error("{}{}DB_UPLR_06.2 : Exception = {}", CLASS_NAME, sMethodName, e);

		} finally {
			log.info("{}{}DBTOOLS999 : response : {}", CLASS_NAME, sMethodName, hmResult);
		}

		return hmResult;
	}

	/**
	 * This method adds an email application password to the database.
	 * It takes a HashMap as an argument which contains the details of the email application password to be added.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.DB_MEMBER_NUM: The member number.
	 * - MPSDefs.DB_PASSWORD_NAME: The name of the password.
	 * - MPSDefs.DB_PASSWORD_VENC: The encrypted password.
	 * - CommonDefs.CALLING_SYSTEM_ID: The identifier of the system that last modified the record.
	 * - "password_ox": The password in plain text (optional).
	 *
	 * The method first logs the start of the operation and the input parameters.
	 * It then checks if the necessary information is present in the input HashMap.
	 * If any necessary information is missing, it logs an error and returns an error status.
	 * Otherwise, it prepares the SQL query for adding the email application password and executes it using the jdbcTemplate object.
	 * If the operation is successful, the method returns a HashMap containing the status of the operation.
	 * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
	 *
	 * @param hmInput A HashMap containing the details of the email application password to be added.
	 * @return A HashMap containing the status of the operation.
	 */
	public HashMap addEmailAppPwd(HashMap hmInput) {
		String sMethodName = ".addEmailAppPwd.";
		log.info("{}{}DBTOOLS01 : CVS KEYWORDS: {}", CLASS_NAME, sMethodName, INFO);
		String stAppInfo = null;
		HashMap hmResult = null;
		List<Object> objectList = CommonUtil.getArrayList();

		log.info(ProfileOrchestrationConstants.LOG_DBTOOLS000, CLASS_NAME, sMethodName, hmInput);

		try {
			if (hmInput == null) {
				stAppInfo = "InpParam is null";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}DB_ADLR_02 : {}", CLASS_NAME, sMethodName, stAppInfo);
				return hmResult;
			}

			String stMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
			String sPasswordName = (String) hmInput.get(MPSDefs.DB_PASSWORD_NAME);
			String sPasswordVenc = (String) hmInput.get(MPSDefs.DB_PASSWORD_VENC);
			String stLastModifiedBy = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

			if (stMemberNum == null || stMemberNum.trim().length() <= 0 || sPasswordVenc == null
					|| sPasswordVenc.trim().length() <= 0 || stLastModifiedBy == null
					|| stLastModifiedBy.trim().length() <= 0 || sPasswordName == null
					|| sPasswordName.trim().length() <= 0) {

				stAppInfo = "Required Parameter member_num/last_modified_by/password_name/password_venc) is missing";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}DB_ADLR_03 : {}", CLASS_NAME, sMethodName, stAppInfo);
				return hmResult;
			}

			// 1806 PID 291481b Updated for PASSWORD_OX
			String sPasswordOX = (String) hmInput.get("password_ox");

			String sInsertSQL = "INSERT INTO APPEMAILPASSWORD (" + "MEMBER_NUM, " + "PASSWORD_NAME, "
					+ "PASSWORD_VENC, " + "LAST_MODIFIED_BY, " + "PASSWORD_OX) " + "values(?,?,?,?,?)";

			objectList.add(stMemberNum);
			log.info("{}{}DB_ADLR_04 : stMemberNum::PARAM 1 = {}", CLASS_NAME, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(stMemberNum)));

			objectList.add(sPasswordName);
			log.info("{}{}DB_ADLR_05 : sPasswordName::PARAM 2 = {}", CLASS_NAME, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(sPasswordName)));

			objectList.add(sPasswordVenc);
			log.info("{}{}DB_ADLR_06 : sPasswordVenc::PARAM 3 = {}", CLASS_NAME, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(sPasswordVenc)));

			objectList.add(stLastModifiedBy);
			log.info("{}{}DB_ADLR_07 : stLastModifiedBy::PARAM 4 = {}", CLASS_NAME, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(stLastModifiedBy)));

			if (sPasswordOX != null && !sPasswordOX.isEmpty()) {
				objectList.add(sPasswordOX);
				log.info("{}{}DB_ADLR_08 : sPasswordOX::PARAM 5 = {}", CLASS_NAME, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(sPasswordOX)));

			} else {
				objectList.add(null);
			}

			log.info("{}{}DB_ADLR_12.1 : Query SQL = {}", CLASS_NAME, sMethodName, sInsertSQL);

			int rowCount = jdbcTemplate.update(new String(sInsertSQL),
					objectList.toArray(new Object[objectList.size()]));

			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
					"No of rows inserted:= " + rowCount);

			log.info("{}{}DB_ADLR_13 :No of rows inserted:=  {}", CLASS_NAME, sMethodName, rowCount);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DB_ADLR_14 : Error::{}", CLASS_NAME, sMethodName, e.getMessage());
			log.error("{}{}DB_ADLR_15 : Exception = {}", CLASS_NAME, sMethodName, e);

		} finally {
			log.info("{}{}DBTOOLS999 : response : {}", CLASS_NAME, sMethodName, hmResult);
		}

		return hmResult;
	}

	/**
	 * This method deletes an email application password from the database.
	 * It takes a HashMap as an argument which contains the details of the email application password to be deleted.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.DB_MEMBER_NUM: The member number.
	 * - MPSDefs.DB_PASSWORD_NAME: The name of the password (optional).
	 *
	 * The method first logs the start of the operation and the input parameters.
	 * It then checks if the member number is present in the input HashMap.
	 * If the member number is missing, it logs an error and returns an error status.
	 * Otherwise, it prepares the SQL query for deleting the email application password and executes it using the jdbcTemplate object.
	 * If the operation is successful, the method returns a HashMap containing the status of the operation and the number of rows deleted.
	 * If an error occurs during the operation, the method logs the error and returns a HashMap containing the error details.
	 *
	 * @param hmInput A HashMap containing the details of the email application password to be deleted.
	 * @return A HashMap containing the status of the operation and the number of rows deleted.
	 */
	public HashMap deleteEmailAppPwd(HashMap hmInput) {
		String sMethodName = ".deleteEmailAppPwd.";
		log.info("{}{}DBTOOLS01 : CVS KEYWORDS: {}", CLASS_NAME, sMethodName, INFO);
		String stAppInfo = null;
		HashMap hmResult = null;
		List<Object> objectList = CommonUtil.getArrayList();

		log.info(ProfileOrchestrationConstants.LOG_DBTOOLS000, CLASS_NAME, sMethodName, hmInput);

		try {
			if (hmInput == null) {
				stAppInfo = "InpParam is null";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}DB_UPLR_01 : {}", CLASS_NAME, sMethodName, stAppInfo);
				return hmResult;
			}

			String stMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
			String sPasswordName = (String) hmInput.get(MPSDefs.DB_PASSWORD_NAME);

			if (stMemberNum == null || stMemberNum.trim().length() <= 0) {
				stAppInfo = "Required parameter member_num is null in input";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}DB_UPLR_02 : {}", CLASS_NAME, sMethodName, stAppInfo);
				return hmResult;
			}

			String sDeleteSQL = "DELETE from APPEMAILPASSWORD where member_num=? ";

			if (sPasswordName != null && !sPasswordName.isEmpty()) {
				sDeleteSQL = sDeleteSQL + " and password_name=? ";
			}

			log.info("{}{}SQL999 : SQL Query = {}", CLASS_NAME, sMethodName, sDeleteSQL);

			objectList.add(stMemberNum.trim());

			if (sPasswordName != null && !sPasswordName.isEmpty()) {
				objectList.add(sPasswordName);
			}

			int rowCount = jdbcTemplate.update(new String(sDeleteSQL),
					objectList.toArray(new Object[objectList.size()]));

			log.info("{}{}DB_UPLR_04 : No of rows deleted are: {}", CLASS_NAME, sMethodName, rowCount);

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
					"No of rows deleted = " + rowCount);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DB_UPLR_06 : Error::{}", CLASS_NAME, sMethodName, e.getMessage());
			log.error("{}{}DB_UPLR_07 : Exception = {}", CLASS_NAME, sMethodName, e);

		} finally {
			log.info("{}{}DBTOOLS999 : response : {}", CLASS_NAME, sMethodName, hmResult);
		}

		return hmResult;
	}
}
