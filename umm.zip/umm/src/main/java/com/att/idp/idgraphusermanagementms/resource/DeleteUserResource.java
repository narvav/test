package com.att.idp.idgraphusermanagementms.resource;

import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.resource.request.DeleteUserRequest;
import com.att.idp.idgraphusermanagementms.resource.response.DeleteUserResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.web.bind.annotation.RequestBody;

import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("")
@Produces({ MediaType.APPLICATION_JSON })
public interface DeleteUserResource {

	/**
	 * Deletes an accessId or memberId when all the services linked to these IDs are
	 * deleted.
	 *
	 * This method handles HTTP POST requests to delete a user. It consumes a JSON
	 * request body containing the details of the user to be deleted and produces a
	 * JSON response indicating the result of the operation. The method requires the
	 * "X-ATT-ClientId" header to identify the calling application or service.
	 *
	 * @param deleteUserRequest The request object containing the details of the
	 *                          user to be deleted.
	 * @param httpHeader        The HTTP headers containing additional request
	 *                          metadata.
	 * @return A Response object indicating the success or failure of the delete
	 *         operation.
	 * @throws MPSException If an error occurs during the operation.
	 */
	@POST
	@Path("/deleteuser")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Deletion of an accessId or memberId", description = "Delete accessId or memberId when all the services linked to these IDs are deleted", parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER) })
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Success", content = @Content(mediaType = "application/json", schema = @Schema(implementation = DeleteUserResponse.class))),
			@ApiResponse(responseCode = "400", description = "Bad Request"),
			@ApiResponse(responseCode = "500", description = "Unknown exception in application") })
	Response deleteUser(@Valid @RequestBody DeleteUserRequest deleteUserRequest, @Context HttpHeaders httpHeader)
			throws MPSException;

}