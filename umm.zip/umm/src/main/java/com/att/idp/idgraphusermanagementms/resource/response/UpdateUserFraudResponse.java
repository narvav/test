package com.att.idp.idgraphusermanagementms.resource.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * This class represents the response from the UpdateUserFraud operation in the system.
 * It contains fields for transactionName, appStatusMsg, appStatusCode, appInfo, appCategoryCode, idpTraceId, and errors.
 * Some fields are ignored during JSON serialization/deserialization.
 *
 * The class is annotated with @JsonIgnoreProperties, @JsonInclude, and @ApiModel from various libraries such as Jackson and Swagger.
 * The @JsonIgnoreProperties and @JsonInclude annotations from Jackson library control the JSON serialization/deserialization behavior.
 * The @ApiModel annotation from Swagger library provides metadata for the model definition in Swagger UI.
 *
 * The class uses Lombok's @Data annotation to generate getter and setter methods for all fields.
 *
 */
@EqualsAndHashCode(callSuper = true)
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "UpdateUserFraudLockResponse")
public class UpdateUserFraudResponse extends BaseResponse {

	@JsonIgnore
	protected static final String transactionName="UpdateUserFraud";
}