package com.att.idp.idgraphusermanagementms.exceptions;

import java.util.HashMap;

import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;

/**
 * The InvalidInputDataExceptionMapper class implements the ExceptionMapper interface for InvalidInputDataException.
 * This class is used to map the InvalidInputDataException to a Response.
 * The toResponse method is overridden to provide a custom response for the InvalidInputDataException.
 */
@Provider
public class InvalidInputDataExceptionMapper implements ExceptionMapper<InvalidInputDataException>{
		
	public static final Logger logger = LoggerFactory.getLogger(InvalidInputDataExceptionMapper.class);
	@Override
	public Response toResponse(InvalidInputDataException ex) {
		
		HashMap hmResponse = (HashMap) ex.errorHashMap;
		return CommonUtilHelper.buildMSResponse(CommonUtilHelper.generateOUDResponse(hmResponse));
		
	}
	
}
