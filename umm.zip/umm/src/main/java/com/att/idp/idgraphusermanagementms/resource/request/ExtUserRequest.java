package com.att.idp.idgraphusermanagementms.resource.request;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema;

import lombok.Data;

import jakarta.validation.constraints.*;
import jakarta.validation.constraints.Email;
import java.util.HashMap;
import java.util.Map;


/**
 * This class represents a request to add or update an external user in the system.
 * It contains fields for various user details such as callingSystemId, domain, transactionName, extGuid, userId, passwordClear, contactEmail, firstName, lastName, accessIdRTValidFlag, contactEmailRTValidFlag, linkedFNUserId, linkedFNUserStatus, agentId, isExternalCall, idpTraceId, userUnlock, and a map for unknownAttributes.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 *
 */
@Data
@Schema(name = "ExtUserRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExtUserRequest {

        private String callingSystemId;
        private final String domain = "slid.dum";
        private String transactionName;

        @Schema(name = "extGuid")
        @NotBlank(message = "extGuid is required in input request.|AddUpdateExtUser")
        @Pattern(regexp = "\\d+$", message =  "extGuid must be numeric.|AddUpdateExtUser")
        @Size(min = 1, max = 10, message =  "extGuid length is invalid|AddUpdateExtUser")
        private String extGuid;

        @Schema(name = "userId")
        @Size(max = 127, message =  "userId length is invalid|AddUpdateExtUser")
        private String userId;

        @Schema(name = "passwordClear")
        @Size(min = 6, max = 24, message =  "passwordClear length is invalid|AddUpdateExtUser")
        private String passwordClear;

        @Schema(name = "contactEmail")
        @Email(message = "ContactEmail is invalid|AddUpdateExtUser")
        @Size(max = 100, message =  "ContactEmail length is invalid|AddUpdateExtUser")
        private String contactEmail;

        @Schema(name = "firstName")
        @Size(max = 100, message =  "FirstName length is invalid|AddUpdateExtUser")
        private String firstName;

        @Schema(name = "lastName")
        @Size(max = 100, message =  "LastName length is invalid|AddUpdateExtUser")
        private String lastName;

        @Schema(name = "accessIdRTValidFlag")
        @Size(max = 1, message =  "AccessIdRTValidFlag Length must be 1|AddUpdateExtUser")
        @Pattern(regexp = "^[YyNn]?$", message =  "AccessIdRTValidFlag must be Y or N.|AddUpdateExtUser")
        private String accessIdRTValidFlag;

        @Schema(name = "contactEmailRTValidFlag")
        @Size(max = 1, message =  "ContactEmailRTValidFlag Length must be 1|AddUpdateExtUser")
        @Pattern(regexp = "^[YyNn]?$", message =  "ContactEmailRTValidFlag must be Y or N.|AddUpdateExtUser")
        private String contactEmailRTValidFlag;

        @Schema(name = "LinkedFNUserId")
        @Size(max = 127, message =  "LinkedFNUserId length is invalid|AddUpdateExtUser")
        private String linkedFNUserId;

        @Schema(name = "linkedFNUserStatus")
        @NotBlank(message = "LinkedFNUserStatus is required in input request.|AddUpdateExtUser")
        @Size(min = 1,max = 50, message =  "linkedFNUserStatus length is invalid|AddUpdateExtUser")
        private String linkedFNUserStatus;

        @Schema(name = "agentId")
        @Size(max = 10, message =  "AgentId length is invalid|AddUpdateExtUser")
        private String agentId;

        @Schema(name = "isExternalCall")
        @Size(max = 1, message =  "IsExternalCall Length must be 1|AddUpdateExtUser")
        @Pattern(regexp = "^[YyNn]?$", message =  "It must be Y or N.|AddUpdateExtUser")
        private String isExternalCall;

        @Schema(name = "idpTraceId")
        private String idpTraceId;

        @Schema(name = "UserUnlock(Only applicable in UpdateExtUser API")
        @Size(max = 1, message =  "UserUnlock Length must be 1|AddUpdateExtUser")
        @Pattern(regexp = "^[YyNn]?$", message =  "It must be Y or N.|AddUpdateExtUser")
        private String userUnlock;

        /**
    	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
    	 * The field is initialized with an empty HashMap.
    	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
    	 * The key of the Map is the attribute name and the value is the attribute value.
    	 *
    	 * @return Map<String,Object> The map of unknown attributes.
    	 */
        @JsonAnySetter
        @JsonAnyGetter
        public Map<String,Object> unknownAttributes = new HashMap<>();
}