package com.att.idp.idgraphusermanagementms.db.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.att.idp.idgraphusermanagementms.db.model.Tattribute;


/**
 * This is an interface for the AttributeRepository.
 * It extends JpaRepository to provide CRUD operations for the Tattribute entity.
 *
 * @param Tattribute The type of the entity this repository manages.
 * @param Long The type of the id of the entity this repository manages.
 */
public interface AttributeRepository extends JpaRepository<Tattribute, Long> {

	/**
	 * This method is used to find the attribute name by its ID.
	 *
	 * @param attributeId The ID of the attribute. This is used to search for the attribute in the database.
	 * @return The name of the attribute with the provided ID. If no attribute with the provided ID is found, this method returns null.
	 */
	@Query(value = "select attr.ATTRIBUTE_NAME from MPS_OWNER.TATTRIBUTE attr where attr.ATTRIBUTE_ID= :attributeId", nativeQuery=true)
	String findAttributeNameByAttributeId(@Param(value = "attributeId") Long attributeId);
}