package com.att.idp.idgraphusermanagementms.request.validator;

import jakarta.ws.rs.core.HttpHeaders;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import jakarta.validation.Valid;

import com.att.idp.idgraphusermanagementms.resource.request.LinkMemberRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphusermanagementms.resource.response.LinkMemberResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * This class, LinkMemberRequestValidator, is responsible for validating the LinkMemberRequest.
 * It checks for the presence and validity of required fields in the request, and returns a LinkMemberResponse accordingly.
 * It is annotated with @Component, @Configuration, and @PropertySource to indicate that it's a Spring Bean,
 * to allow it to access configuration properties, and to specify the location of the properties file respectively.
 *
 * The class contains several methods, including:
 * - linkMemberRequestValidator: the main method that orchestrates the validation process.
 * - linkMemberErrorResponse: a helper method that generates an error response.
 * - linkMemberInputValidator: a method that validates the input fields in the request.
 * - linkMemberCSIValidator: a method that validates the 'CSI' field in the request.
 * - linkMemberHandleValidator: a method that validates the 'Handle' field in the request.
 * - linkMemberDomainValidator: a method that validates the 'Domain' field in the request.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class LinkMemberRequestValidator {

	private static final Logger logger = LoggerFactory.getLogger(LinkMemberRequestValidator.class);

	private String sClassName = "LinkMemberRequestValidator";

	@Value("${ValidLinkMemberCSI}")
	private String propValidCallersForLinkMember;

	@Value ("${InValidLinkMemberDomain}")
	private String inValidDomainForLinkMember;

	
	/**
	 * This method is responsible for validating the LinkMemberRequest.
	 * It takes HttpHeaders and LinkMemberRequest as parameters.
	 * HttpHeaders contains the request headers which may include additional information required for processing the request.
	 * LinkMemberRequest encapsulates the details of the link member operation to be performed.
	 *
	 * The method performs various checks and validations on the input parameters and returns a LinkMemberResponse object.
	 * The LinkMemberResponse object encapsulates the result of the link member operation.
	 *
	 * @param httpHeader The HttpHeaders containing the request headers.
	 * @param linkMemberRequest The LinkMemberRequest containing the details of the link member operation.
	 * @return LinkMemberResponse The response of the link member operation.
	 */
	public LinkMemberResponse linkMemberRequestValidator(HttpHeaders httpHeader, @Valid LinkMemberRequest linkMemberRequest) {

		String sMethodName = ".linkMemberRequestValidator.";
		String stAppInfo = null;
		String stIdpTraceId = null;

		LinkMemberResponse linkMemberResponse = null;
		
		stIdpTraceId = CommonUtil.getTraceId(httpHeader);

		if (stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
			stAppInfo = "Missing or Invalid IdpTraceId";
			return linkMemberErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
			
		if (linkMemberRequest == null) {
			stAppInfo = "Input Request is NULL / Empty.";
			logger.info("{}{}LMRV_01 :: {}", sClassName, sMethodName, stAppInfo);
			return linkMemberErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		linkMemberRequest.setIdpTraceId(stIdpTraceId);

		// checking Invalid attributes passed in Request
		Map<String, Object> allUnknownAttributes = new HashMap<>(linkMemberRequest.unknownAttributes);

		if (!allUnknownAttributes.isEmpty()) {
			stAppInfo = "Invalid Attributes passed in linkMemberRequest : " + allUnknownAttributes;
			return linkMemberErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					linkMemberRequest.getIdpTraceId());
		}

		try {
			linkMemberResponse = linkMemberInputValidator(linkMemberRequest, httpHeader);
			if (linkMemberResponse != null) {
				logger.info("{}{}LMRV_04 : Response from linkMemberInputValidator : {}", sClassName, sMethodName,
						linkMemberResponse);
				return linkMemberResponse;
			}

			linkMemberResponse = linkMemberCSIValidator(linkMemberRequest);
			if (linkMemberResponse != null) {
				logger.info("{}{}LMRV_05 : Response from linkMemberCSIValidator : {}", sClassName, sMethodName,
						linkMemberResponse);
				return linkMemberResponse;
			}

			linkMemberResponse =linkMemberHandleValidator(linkMemberRequest);
			if (linkMemberResponse != null) {
				logger.info("{}{}LMRV_05 : Response from linkMemberHandleValidator : {}", sClassName, sMethodName,
						linkMemberResponse);
				return linkMemberResponse;
			}

			linkMemberResponse = linkMemberDomainValidator(linkMemberRequest);
			if (linkMemberResponse != null) {
				logger.info("{}{}LMRV_05 : Response from linkMemberDomainValidator : {}", sClassName, sMethodName,
						linkMemberResponse);
				return linkMemberResponse;
			}

			stAppInfo = "Input Validation Successful";
			logger.info("{}{}LMRV_06 : {}", sClassName, sMethodName, stAppInfo);

		} catch (Exception e) {
			stAppInfo = "Exception thrown in LinkMemberRequestValidator : " + e.getMessage();
			linkMemberResponse = linkMemberErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo, stIdpTraceId);
			logger.info("{}{}LMRV_07: Exception in LinkMemberRequestValidator: {}", sClassName, sMethodName,
					stAppInfo);
		}

		return linkMemberResponse;
	}

	private LinkMemberResponse linkMemberInputValidator(
			LinkMemberRequest linkMemberRequest, HttpHeaders httpHeader) {

		String sMethodName = "linkMemberInputValidator";
		LinkMemberResponse	linkMemberResponse=null;
		String stAppInfo = null;
		String sMemberId = linkMemberRequest.getMemberId();
		String sUserId = linkMemberRequest.getUserId();
		String sDomain = linkMemberRequest.getDomain();
		String sCallingSystemId = httpHeader.getHeaderString("X-ATT-ClientId");

		Optional.ofNullable(sMemberId).ifPresent(x -> linkMemberRequest.setMemberId(x.trim().toLowerCase()));
		Optional.ofNullable(sUserId).ifPresent(x -> linkMemberRequest.setUserId(x.trim().toLowerCase()));
		Optional.ofNullable(sDomain).ifPresent(x -> linkMemberRequest.setDomain(x.trim().toLowerCase()));


		if (sCallingSystemId == null || sCallingSystemId.isEmpty()) {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			logger.info("{}{}LMRV_IV.01 : {}", sClassName, sMethodName, stAppInfo);
			return linkMemberErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					linkMemberRequest.getIdpTraceId());
		}
		linkMemberRequest.setCallingSystemId(sCallingSystemId.trim().toUpperCase());

		return linkMemberResponse;
	}


	private LinkMemberResponse linkMemberCSIValidator(
			LinkMemberRequest linkMemberRequest) {

		LinkMemberResponse linkMemberResponse = null;

		String sMethodName = null;
		String stAppInfo = null;

		ArrayList alValidCallers = null;

		String sCallingSystemId = linkMemberRequest.getCallingSystemId();

		if (propValidCallersForLinkMember != null && !propValidCallersForLinkMember.isEmpty()) {
			alValidCallers = CommonUtil.parseToArray(propValidCallersForLinkMember,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			logger.info("{}{}LMRV_CSI.02 : linkMemberCallingSystemIds : {}", sClassName, sMethodName,
					alValidCallers);
			if (alValidCallers != null
					&& !alValidCallers.contains(sCallingSystemId)) {
				stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
				logger.info("{}{}LMRV_CSI.03 :  {} ", sClassName, sMethodName, stAppInfo);
				return linkMemberErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						linkMemberRequest.getIdpTraceId());
			}
		}
		return linkMemberResponse;
	}

	private LinkMemberResponse linkMemberDomainValidator(
			LinkMemberRequest linkMemberRequest) {

		LinkMemberResponse linkMemberResponse = null;

		String sMethodName = null;
		String stAppInfo = null;

		ArrayList alValidDomain = null;

		String domain = linkMemberRequest.getDomain();

		if (inValidDomainForLinkMember != null && !inValidDomainForLinkMember.isEmpty()) {
			alValidDomain = CommonUtil.parseToArray(inValidDomainForLinkMember,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			logger.info("{}{}LMRV_DV.02 : linkMemberCallingSystemIds : {}", sClassName, sMethodName,
					alValidDomain);
			if (alValidDomain != null
					&& alValidDomain.contains(domain)) {
				stAppInfo = "Domain attworld.com/myaccount.bellsouth.net is not valid domain for link member";
				logger.info("{}{}LMRV_DV.03 :  {} ", sClassName, sMethodName, stAppInfo);
				return linkMemberErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						linkMemberRequest.getIdpTraceId());
			}
		}
		return linkMemberResponse;
	}

	private LinkMemberResponse linkMemberHandleValidator(
			LinkMemberRequest linkMemberRequest) {

		LinkMemberResponse linkMemberResponse = null;

		String sMethodName = null;
		String stAppInfo = null;

		//String inputHandle = (String) hmInput.get(CommonDefs.HANDLE);
		String inputhandle = linkMemberRequest.getUserId();
			if (inputhandle != null
					&& inputhandle.contains("sbciptv_")) {
				stAppInfo = "Ghost Ids sbciptv_ are not allowed to link memberId to AccessId";
				logger.info("{}{}LMRV_HV.01 :  {} ", sClassName, sMethodName, stAppInfo);
				return linkMemberErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						linkMemberRequest.getIdpTraceId());
			}

		return linkMemberResponse;
	}
	private LinkMemberResponse linkMemberErrorResponse(int appStatusCode, String stAppInfo,
			String stIdpTraceId) {

		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		hmResponse.put(CommonDefs.TRANSACTION_NAME, "LinkMember");
		return CommonUtilHelper.generateLinkMemberResponse(hmResponse);
	}


}
