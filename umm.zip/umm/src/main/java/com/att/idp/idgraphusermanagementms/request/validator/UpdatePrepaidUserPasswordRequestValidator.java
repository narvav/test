package com.att.idp.idgraphusermanagementms.request.validator;

import com.att.idp.idgraphusermanagementms.resource.request.UpdatePrepaidUserPasswordRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdatePrepaidUserPasswordResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import jakarta.validation.Valid;
import jakarta.ws.rs.core.HttpHeaders;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;


/**
 * This class is part of the com.att.idp.idgraphuserprofilems.request.validator package.
 * It is a validator class for the UpdatePrepaidUserPasswordRequest.
 * The class is responsible for validating the request parameters of the UpdatePrepaidUserPasswordRequest.
 * It checks for the presence and validity of various request parameters such as the trace ID, client ID, and others.
 * It also checks for the presence of invalid attributes in the request.
 * The class provides several private methods for specific validation tasks, such as CSI validation and error response generation.
 * It also provides a method to generate an error response in case of invalid request parameters.
 * The class is annotated with @Component, @Configuration, and @PropertySource, indicating that it is a Spring component, a configuration class, and it reads properties from a specified file.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class UpdatePrepaidUserPasswordRequestValidator {

    private static final Logger logger = LoggerFactory.getLogger(UpdatePrepaidUserPasswordRequestValidator.class);

    private static final String sClassName = "UpdatePrepaidUserPasswordRequestValidator";

    @Value("${updatePrepaidUserPasswordCallingSystemIds}")
    private String propCallingSystemId;

    /**
     * This method is part of the UpdatePrepaidUserPasswordRequestValidator class.
     * It validates the UpdatePrepaidUserPasswordRequest and returns a UpdatePrepaidUserPasswordResponse.
     * The method checks the validity of various request parameters such as the trace ID, client ID, and others.
     * It also checks for the presence of invalid attributes in the request.
     * If the request is valid, it calls the querySecurityQuestionsCSIValidator method for further validation.
     * If the request is invalid, it generates an error response using the querySecurityQuestionsErrorResponse method.
     *
     * @param updatePrepaidUserPasswordRequest The UpdatePrepaidUserPasswordRequest object to be validated.
     * @param requestHeader                    The HttpHeaders object containing the request headers.
     * @return A UpdatePrepaidUserPasswordResponse object containing the validation result.
     */
    public UpdatePrepaidUserPasswordResponse updatePrepaidUserPasswordRequestValidator(@Valid UpdatePrepaidUserPasswordRequest updatePrepaidUserPasswordRequest,
                                                                                       HttpHeaders requestHeader) {

        UpdatePrepaidUserPasswordResponse updatePrepaidUserPasswordResponse = null;

        String stAppInfo = null;
        String sMethodName = ".updatePrepaidUserPasswordRequestValidator.";
        String stIdpTraceId = null;

        stIdpTraceId = CommonUtil.getTraceId(requestHeader);

        if (stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
            stAppInfo = " UpdatePrepaidUserPassword Request idp-trace-id is missing";
            logger.info("{}{}UPUPRV_00 :: {}", sClassName, sMethodName, stAppInfo);
            return updatePrepaidUserPasswordErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
        }
        if (updatePrepaidUserPasswordRequest == null) {
            stAppInfo = "Input Request is NULL / Empty.";
            logger.info("{}{}UPUPRV_00.01 :: {}", sClassName, sMethodName, stAppInfo);
            return updatePrepaidUserPasswordErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
        }
        updatePrepaidUserPasswordRequest.setIdpTraceId(stIdpTraceId);

        // checking Invalid attributes passed in Request
        Map<String, Object> allUnknownAttributes = new HashMap<>(updatePrepaidUserPasswordRequest.unknownAttributes);

        if (!allUnknownAttributes.isEmpty()) {
            stAppInfo = "Invalid Attributes passed in UpdatePrepaidUserPasswordRequest : " + allUnknownAttributes;
            return updatePrepaidUserPasswordErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
                    updatePrepaidUserPasswordRequest.getIdpTraceId());
        }


        // isExternalCall check
        String sIsExternalCall = updatePrepaidUserPasswordRequest.getIsExternalCall();
        Optional.ofNullable(sIsExternalCall).ifPresent(x -> updatePrepaidUserPasswordRequest.setIsExternalCall(x.trim()));
        if ((sIsExternalCall != null && !sIsExternalCall.isEmpty())) {
            if (!(sIsExternalCall.equalsIgnoreCase(CommonDefs.IND_Y)
                    || sIsExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
                stAppInfo = "isExternalCall must be one of Y or N";
                return updatePrepaidUserPasswordErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
            } else {
                updatePrepaidUserPasswordRequest.setIsExternalCall(sIsExternalCall.trim().toUpperCase());
            }
        } else {
            updatePrepaidUserPasswordRequest.setIsExternalCall(CommonDefs.IND_Y);
        }
        try {
            updatePrepaidUserPasswordResponse = updatePrepaidUserPasswordInputValidator(updatePrepaidUserPasswordRequest, requestHeader);

            if (updatePrepaidUserPasswordResponse != null) {
                logger.info("{}{}UPUPRV_03 Response from updatePrepaidUserPasswordInputValidator : {}", sClassName,
                        sMethodName, updatePrepaidUserPasswordResponse);
                return updatePrepaidUserPasswordResponse;
            }


            updatePrepaidUserPasswordResponse = queryUpdatePrepaidUserPasswordCSIValidator(updatePrepaidUserPasswordRequest);
            if (updatePrepaidUserPasswordResponse != null) {
                logger.info("{}{}UPUPRV_02 Response from queryUpdatePrepaidUserPasswordCSIValidator : {}", sClassName,
                        sMethodName, updatePrepaidUserPasswordResponse);
                return updatePrepaidUserPasswordResponse;
            }

            stAppInfo = "Input Validation Successful";
            logger.info("{}{}UPUPRV_04 : {}", sClassName, sMethodName, stAppInfo);


        } catch (Exception e) {
            stAppInfo = "Exception thrown in UpdatePrepaidUserPasswordRequestValidator : " + e.getMessage();
            updatePrepaidUserPasswordResponse = updatePrepaidUserPasswordErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo,
                    stIdpTraceId);
            logger.info("{}{}UPUPRV_06 Exception in UpdatePrepaidUserPasswordRequestValidator: {}", sClassName, sMethodName, stAppInfo);
        }

        return updatePrepaidUserPasswordResponse;
    }

    /**
     * Validates the calling system ID in the UpdatePrepaidUserPasswordRequest.
     *
     * This method checks if the calling system ID provided in the request is valid by comparing it against
     * a list of allowed calling system IDs. If the calling system ID is missing or invalid, an error response
     * is generated and returned.
     *
     * @param secQuestionRequest The UpdatePrepaidUserPasswordRequest object containing the request details.
     * @return A UpdatePrepaidUserPasswordResponse object containing the validation result. If the calling system ID is valid, null is returned.
     */
    private UpdatePrepaidUserPasswordResponse queryUpdatePrepaidUserPasswordCSIValidator(UpdatePrepaidUserPasswordRequest secQuestionRequest) {

        String sMethodName = ".queryUpdatePrepaidUserPasswordCSIValidator.";
        String stCallingSystemId = secQuestionRequest.getCallingSystemId();
        String stIdpTraceId = secQuestionRequest.getIdpTraceId();
        String stAppInfo = null;

        ArrayList alQueryUpdatePrepaidUserPasswordCallingSystemIds = null;

        alQueryUpdatePrepaidUserPasswordCallingSystemIds = CommonUtil.parseToArray(propCallingSystemId,
                CommonDefs.VALUE_SEPARATOR_CHAR);

        logger.debug("{}{}UPUPRV_QUPUPCSI.01 :  Property queryUpdatePrepaidUserPasswordCSIValidator : {}", sClassName, sMethodName,
                alQueryUpdatePrepaidUserPasswordCallingSystemIds);

        if (!alQueryUpdatePrepaidUserPasswordCallingSystemIds.contains(stCallingSystemId)) {
            stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
            return updatePrepaidUserPasswordErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
        }

        return null;
    }

    /**
     * Validates the input parameters of the UpdatePrepaidUserPasswordRequest.
     *
     * This method performs several validation checks on the input parameters of the UpdatePrepaidUserPasswordRequest.
     * It trims and validates the CTN, BAN, IP address, and password fields. It also checks for the presence of the
     * X-ATT-ClientId header and sets the calling system ID accordingly. If any validation fails, an error response
     * is generated and returned.
     *
     * @param updatePrepaidUserPasswordRequest The UpdatePrepaidUserPasswordRequest object containing the request details.
     * @param httpHeader The HttpHeaders object containing the request headers.
     * @return A UpdatePrepaidUserPasswordResponse object containing the validation result. If the input is valid, null is returned.
     */
    private UpdatePrepaidUserPasswordResponse updatePrepaidUserPasswordInputValidator(
            UpdatePrepaidUserPasswordRequest updatePrepaidUserPasswordRequest, HttpHeaders httpHeader) {

        String sMethodName = ".updatePrepaidUserPasswordInputValidator";
        String stAppInfo = null;
        String sCtn = updatePrepaidUserPasswordRequest.getCtn();
        String sBan = updatePrepaidUserPasswordRequest.getBan();
        String sPassword = updatePrepaidUserPasswordRequest.getPassword();
        String stIdpTraceId = updatePrepaidUserPasswordRequest.getIdpTraceId();
        String xATTClientId = null;

        Optional.ofNullable(sCtn).ifPresent(x -> updatePrepaidUserPasswordRequest.setCtn(x.trim()));
        Optional.ofNullable(sBan).ifPresent(x -> updatePrepaidUserPasswordRequest.setBan(x.trim()));
        Optional.ofNullable(sPassword).ifPresent(x -> updatePrepaidUserPasswordRequest.setPassword(x.trim()));

        if (httpHeader.getHeaderString("X-ATT-ClientId") != null) {
            xATTClientId = httpHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
            logger.info(SpiMarker.getInstance(), "{}{}UPUP.UPUPIV.01 : Setting callingSystemId: {}", sClassName, sMethodName,
                    xATTClientId);
            updatePrepaidUserPasswordRequest.setCallingSystemId(xATTClientId);
        } else {
            stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
            logger.info(SpiMarker.getInstance(), "{}{}UPUP.UPUPIV.02 :: {}", sClassName, sMethodName, stAppInfo);
            return updatePrepaidUserPasswordErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
        }

        //CTN check
        if (StringUtils.isBlank(sCtn)) {
            stAppInfo = "CTN is null or empty";
            logger.info("{}{}UPUP.UPUPIV.03 :  {} ", sClassName, sMethodName, stAppInfo);
            return updatePrepaidUserPasswordErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, updatePrepaidUserPasswordRequest.getIdpTraceId());
        }
        if (!isNumeric(sCtn)) {
            stAppInfo = "CTN has to be numeric";
            logger.info("{}{}UPUP.UPUPIV.04 : {}", sClassName, sMethodName, stAppInfo);
            return updatePrepaidUserPasswordErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
        }

        updatePrepaidUserPasswordRequest.setCtn(sCtn);

		//BAN check
        if (StringUtils.isBlank(sBan)) {
            stAppInfo = "BAN is null or empty";
            logger.info("{}{}UPUP.UPUPIV.05 :  {} ", sClassName, sMethodName, stAppInfo);
            return updatePrepaidUserPasswordErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
                    updatePrepaidUserPasswordRequest.getIdpTraceId());
        }
        updatePrepaidUserPasswordRequest.setBan(sBan.toUpperCase());

        //password check
        if (StringUtils.isBlank(updatePrepaidUserPasswordRequest.getPassword())) {
            stAppInfo = "New password can not be null or empty";
            logger.info("{}{}UPUP.UPUPIV.07 :: {}", sClassName, sMethodName, stAppInfo);
            return updatePrepaidUserPasswordErrorResponse(CErrorDefs.ERR_EMPTY_NUM, stAppInfo, stIdpTraceId);
        }
        updatePrepaidUserPasswordRequest.setPassword(sPassword);

        return null;
    }

    /**
     * Generates an error response for the UpdatePrepaidUserPasswordRequest.
     *
     * @param appStatusCode The application status code indicating the type of error.
     * @param stAppInfo     A string containing additional information about the error.
     * @param stIdpTraceId  The trace ID associated with the request.
     * @return A UpdatePrepaidUserPasswordResponse object containing the error details.
     */
    private UpdatePrepaidUserPasswordResponse updatePrepaidUserPasswordErrorResponse(int appStatusCode, String stAppInfo, String stIdpTraceId) {
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
        responseMap.put("idp-trace-id", stIdpTraceId);
        responseMap.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
        return CommonUtilHelper.generateUpdatePrepaidUserPasswordResponse(responseMap);
    }
    /**
     * Checks if the given string is numeric.
     * The string is considered numeric if it is either empty or contains exactly 10 digits.
     *
     * @param strNum the string to check
     * @return true if the string is numeric, false otherwise
     */
    public static boolean isNumeric(String strNum) {
        return strNum.matches("(^$|[0-9]{10})");
    }
}
