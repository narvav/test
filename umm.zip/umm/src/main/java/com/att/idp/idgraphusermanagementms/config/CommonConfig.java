/*package com.att.idp.idgraphusermanagementms.config;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.att.idp.audit.core.AuditManager;

@Component
public class CommonConfig {
	
	
	@Bean
	public AuditManager auditManagerConfig() {
		return new AuditManager();
	}
	
	@Bean
	public RestTemplateBeanFactory restTemplateBeanFactory() {
		return new RestTemplateBeanFactory();
	}
	
	@Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
	
	@Bean
	public RestClientConfig restClientConfig() {
		return new RestClientConfig(); 
	}

}
*/