package com.att.idp.idgraphusermanagementms.service.impl;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.AddSecMemberIdHelper;
import com.att.idp.idgraphusermanagementms.resource.request.AddSecMemberIdRequest;
import com.att.idp.idgraphusermanagementms.resource.response.AddSecMemberIdResponse;
import com.att.idp.idgraphusermanagementms.service.AddSecMemberIdService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.ws.rs.core.HttpHeaders;
import java.util.HashMap;
import java.util.Map;

/**
 * Service implementation for adding a secondary member ID.
 * This class handles the business logic for adding a sub-user in the MPSYS system.
 */
@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class AddSecMemberIdServiceImpl implements AddSecMemberIdService {

    /**
     * Logger instance for logging events.
     */
    public static final Logger logger = LoggerFactory.getLogger(AddSecMemberIdServiceImpl.class);

    /**
     * Class name for logging purposes.
     */
    private static String sClassName = "AddSecMemberIdServiceImpl";

    /**
     * Helper for AddSecMemberId operations.
     */
    @Autowired
    private AddSecMemberIdHelper addSecMemberIdHelper;

    /**
     * Adds a sub-user in the MPSYS system.
     * This method handles the logic for adding a secondary member ID.
     *
     * @param addSecMemberIdRequest The request object containing the details for adding a secondary member ID.
     * @param requestHeader The HTTP headers of the request.
     * @return An AddSecMemberIdResponse object containing the status and result of the operation.
     * @throws InvalidInputDataException If an error occurs during the operation.
     */
    @Override
    public AddSecMemberIdResponse addSubUser(AddSecMemberIdRequest addSecMemberIdRequest, HttpHeaders requestHeader) {
        Map<String, Object> hmResponse = null;
        String sMethodName = "addSubUser";
        Map<String, Object> hmInput = CommonUtilHelper.objectToMap(addSecMemberIdRequest);
        String idpTraceid = (String) hmInput.get("idpTraceId");
        hmInput.put("dbusTransactionId", idpTraceid.split(":")[0]);
        hmInput.put("handle", (String) hmInput.remove("memberId"));
        hmInput.put("parentHandle", (String) hmInput.remove("parentMemberId"));

        logger.info(SpiMarker.getInstance(),"AddSecMemberIdServiceImpl.addSubUser ASMIDS_01 : Calling addSecMemberIdHelper with Input : {}",hmInput.toString());

        hmResponse = addSecMemberIdHelper.addSecMemberId((HashMap<String, Object>) hmInput);
        logger.info(SpiMarker.getInstance(),"{}{}ASMIDS_02 : Response from AddSecMemberId Helper : {}", sClassName, sMethodName, hmResponse);

        if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
            hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from AddSecMemberIdHelper.addSubAccount");
            logger.info(SpiMarker.getInstance(),"{}{}ASMIDS_03 : Null response from AddSecMemberIdHelper.addSubAccount", sClassName, sMethodName);
        } else {
            String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
            if (stAppStatusCode == null) {
                hmResponse = CommonUtilHelper.sysErrorHashMap("Null appStatusCode from AddSecMemberIdHelper.addSubAccount");
                logger.info(SpiMarker.getInstance(),"{}{}ASMIDS_04 : Null appStatusCode from AddSecMemberIdHelper.addSubAccount", sClassName, sMethodName);
            }
        }

        hmResponse.put("idp-trace-id", addSecMemberIdRequest.getIdpTraceId());
        hmResponse.put(CommonDefs.TRANSACTION_NAME, addSecMemberIdRequest.getTransactionName());
        AddSecMemberIdResponse addSecMemberIdResponse = CommonUtilHelper.generateAddSecMemberIdResponse(hmResponse);
        String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

        if (sTxnRollBack != null) {
            throw new InvalidInputDataException(hmResponse);
        }
        logger.info(SpiMarker.getInstance(),"{}{}ASMIDS_05 : Response from AddSecMemberIdServiceImpl.addSubUser : {}", sClassName, sMethodName, addSecMemberIdResponse);
        return addSecMemberIdResponse;
    }
}