package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TROLECOLLECTION", schema = "MPS_OWNER")
public class Trolecollection implements java.io.Serializable {

	private static final long serialVersionUID = -8963422198480831188L;

	@Id
	@Column(name = "COLECTION_ID", unique = true, nullable = false, precision = 22, scale = 0)
	private Long colectionId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "COLECTION_ID", referencedColumnName = "SERVICE_ID", unique = true, nullable = false, insertable = false, updatable = false),
			@JoinColumn(name = "ROLE_ID", referencedColumnName = "ROLE_ID", nullable = false, insertable = false, updatable = false)
	})
	private Tservicerole tservicerole;

	@Column(name = "SERVICE_ID", nullable = false, precision = 22, scale = 0)
	private Long serviceId;
}