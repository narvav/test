package com.att.idp.idgraphusermanagementms.helper.voltage;
/* Copyright 2007-2009, Voltage Security, all rights reserved.
 */

/*=========================================================*/
/*                                                         */
/* Using this sample file                                  */
/*                                                         */
/*=========================================================*/
/* The try-catch block in the main function constitutes the bulk of this
 * sample file and the functionality included. The first section in
 * the block is to set up the library context. All other following
 * sections are dependent on this first one. The only other dependency
 * is that decrypting the last four digits of an SSN only requires
 * the section which does the full encryption and decryption. This
 * means that you can comment out sections that you do not want to use
 * at will.
 */

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import com.att.mpsys.common.utils.*;
import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.idp.logging.marker.SpiMarker;
import com.att.idp.voltage.common.VoltageEfpeFormatType;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This class is part of the com.att.idp.idgraphusermanagementms.helper.voltage package.
 * It is a helper class for encryption and decryption operations.
 * It uses the VoltageEncryptDecryptHelper class for these operations.
 * The class has two main methods: getEFPEEncryptedValues and getEFPEDecryptedValues.
 * The getEFPEEncryptedValues method takes a HashMap as input and returns a HashMap with encrypted values.
 * The getEFPEDecryptedValues method takes a HashMap with encrypted values as input and returns a HashMap with decrypted values.
 */
@Component
public class VoltageEncryptionHelper {

	public static final Logger logger = LoggerFactory.getLogger(VoltageEncryptionHelper.class);
	private static ArrayList alVoltageDecryptionFields = null;
	private static ArrayList alVoltageEncryptionFields = null;
	private static ArrayList alVoltagePCIEncryptionFields = null;
	private static ArrayList alVoltagePCIDecryptionFields = null;
	private static ArrayList alVoltageSSNEncryptionFields = null;
	private static ArrayList alVoltageSSNDecryptionFields = null;
	private static ArrayList alVoltageGenStrEncryptionFields = null;
	private static ArrayList alVoltageGenStrDecryptionFields = null;
	private static String sVoltageEncryptionFields = null;
	private static String sVoltageDecryptionFields = null;
	private static String sVoltagePCIEncryptionFields = null;
	private static String sVoltagePCIDecryptionFields = null;
	private static String sVoltageSSNEncryptionFields = null;
	private static String sVoltageSSNDecryptionFields = null;
	private static String sVoltageGenStrEncryptionFields = null;
	private static String sVoltageGenStrDecryptionFields = null;

	@Autowired
	private VoltageEncryptDecryptHelper voltageEncryptDecryptHelper;

	@Autowired
	private VoltageEncryptDecryptHelper voltageHelper;

	private PropertyManagerLoader propertyManagerLoader;

	/**
	 * Constructor for the VoltageEncryptionHelper class.
	 * It initializes the VoltageEncryptionHelper instance and sets up the necessary configurations.
	 * The constructor reads the encryption and decryption fields from the property manager.
	 * It also handles exceptions that might occur during the setup process.
	 */
	public VoltageEncryptionHelper(PropertyManagerLoader propertyManagerLoader) {
		this.propertyManagerLoader = propertyManagerLoader;
		FileInputStream fIn = null;
		try {
			sVoltageEncryptionFields = PropertyManager.getProperty(CommonDefs.MOUPConfig,
					CommonDefs.VOLTAGE_ENCRYPTION_FIELDS);
			sVoltageDecryptionFields = PropertyManager.getProperty(CommonDefs.MOUPConfig,
					CommonDefs.VOLTAGE_DECRYPTION_FIELDS);
			sVoltagePCIEncryptionFields = PropertyManager.getProperty(CommonDefs.MOUPConfig,
					CommonDefs.VOLTAGE_PCI_ENCRYPTION_FIELDS);
			sVoltagePCIDecryptionFields = PropertyManager.getProperty(CommonDefs.MOUPConfig,
					CommonDefs.VOLTAGE_PCI_DECRYPTION_FIELDS);

			sVoltageSSNEncryptionFields = PropertyManager.getProperty(CommonDefs.MOUPConfig,
					CommonDefs.VOLTAGE_SSN_ENCRYPTION_FIELDS);
			sVoltageSSNDecryptionFields = PropertyManager.getProperty(CommonDefs.MOUPConfig,
					CommonDefs.VOLTAGE_SSN_DECRYPTION_FIELDS);

			sVoltageGenStrEncryptionFields = PropertyManager.getProperty(CommonDefs.MOUPConfig,
					CommonDefs.VOLTAGE_GEN_STRING_ENCRYPTION_FIELDS);
			sVoltageGenStrDecryptionFields = PropertyManager.getProperty(CommonDefs.MOUPConfig,
					CommonDefs.VOLTAGE_GEN_STRING_DECRYPTION_FIELDS);

		}  catch (Exception e) {
			logger.error("GC-E2b : " + "General Exception creating the Voltage library. "+e);

		} finally {
			if (fIn != null) {
				try {
					fIn.close();
				} catch (IOException e) {
					logger.error("GC-E2c : " + "IOException closing keys.properties. "+e);
				}
			}
		}
	}


	/**
	 * This method is part of the VoltageEncryptionHelper class.
	 * It takes a HashMap as input and returns a HashMap with encrypted values.
	 * The method uses the VoltageEncryptDecryptHelper instance to encrypt the values.
	 * The encrypted values are then returned as a HashMap.
	 *
	 * @param hmInput The HashMap with values to be encrypted.
	 * @return A HashMap with encrypted values.
	 */
	public HashMap getEFPEEncryptedValues(HashMap hmInput) {
		HashMap hmResponse = new HashMap();
		HashMap hmUpdatedInput = new HashMap();
		String sMethodName = "getEFPEEncryptedValues";
		Date dtStart = new Date();
		String sEncryptedValue = null;
		String sEncryptField = null;
		String sKey = null;
		String sVoltageEncryptionField = null;

		String sAppInfo = null;

		logger.info(SpiMarker.getInstance(),"VoltageEncryptionHelper.getEFPEEncryptedValues.HLP000 : inputHash={}", hmInput);

		try {

			if (sVoltageEncryptionFields == null || sVoltageEncryptionFields.trim().length() == 0) {
				sAppInfo = "Missing or empty config parameter - VOLTAGE_ENCRYPTION_FIELDS";
				logger.error("GEV-E4 : " + sAppInfo);
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, sAppInfo);
				return hmResponse;
			}

			alVoltageEncryptionFields = CommonUtil.parseToArray(sVoltageEncryptionFields, '|');
			sAppInfo = "alVoltageEncryptionFields = " + alVoltageEncryptionFields;
			logger.info("GEV-1a : " + sAppInfo);

			if (sVoltagePCIEncryptionFields == null || sVoltagePCIEncryptionFields.trim().length() == 0) {
				// 1802 : 57618 : Remove PCI data from RegisterMember API and stop CreditRIL API
				// since DIAL registration is sunset
				alVoltagePCIEncryptionFields = new ArrayList();
			} else {
				alVoltagePCIEncryptionFields = CommonUtil.parseToArray(sVoltagePCIEncryptionFields, '|');
				sAppInfo = "sVoltagePCIEncryptionFields = " + alVoltagePCIEncryptionFields;
				logger.info("GEV-1b : " + sAppInfo);
			}

			if (sVoltageSSNEncryptionFields == null || sVoltageSSNEncryptionFields.trim().length() == 0) {
				// Unlike the other list fields, we expect this one to be blank because we do
				// not encrypt fedTaxId
				alVoltageSSNEncryptionFields = new ArrayList();
			} else
				alVoltageSSNEncryptionFields = CommonUtil.parseToArray(sVoltageSSNEncryptionFields, '|');

			sAppInfo = "sVoltageSSNEncryptionFields = " + alVoltageSSNEncryptionFields;
			logger.info("GEV-2b : " + sAppInfo);

			// 1410: to encrypt CBR
			if (sVoltageGenStrEncryptionFields == null || sVoltageGenStrEncryptionFields.trim().length() == 0) {
				alVoltageGenStrEncryptionFields = new ArrayList();
			} else {
				alVoltageGenStrEncryptionFields = CommonUtil.parseToArray(sVoltageGenStrEncryptionFields, '|');
			}

			sAppInfo = "alVoltageGenStrEncryptionFields = " + alVoltageGenStrEncryptionFields;
			logger.info("GEV-3b : ", sAppInfo);

			java.util.Map.Entry mapEntry = null;
			Iterator hmInputIterator = hmInput.entrySet().iterator();
			while (hmInputIterator.hasNext()) {
				mapEntry = (java.util.Map.Entry) hmInputIterator.next();
				sKey = (String) mapEntry.getKey();
				Object oKeyObject = mapEntry.getValue();
				if (oKeyObject instanceof String) {
					sEncryptField = (String) hmInput.get(sKey);
					if (alVoltageEncryptionFields.contains(sKey)) {

						sEncryptedValue =voltageHelper.getEncryptedValue(sEncryptField,
								VoltageEfpeFormatType.B64_GENERIC.toString());
						logger.info("Encrypted Value1 : {}", StringEscapeUtils.escapeJava(sEncryptedValue));

						hmUpdatedInput.put("voltage_" + sKey, sEncryptedValue);
					} else if (alVoltagePCIEncryptionFields.contains(sKey)) {

						sEncryptedValue = voltageHelper.getEncryptedValue(sEncryptField,
								VoltageEfpeFormatType.CC_NUM.toString());

						logger.info("Encrypted Value2 : {}", StringEscapeUtils.escapeJava(sEncryptedValue));

						hmUpdatedInput.put("voltage_" + sKey, sEncryptedValue);
					} else if (alVoltageSSNEncryptionFields.contains(sKey)) {

						sEncryptedValue = voltageHelper.getEncryptedValue(sEncryptField,
								VoltageEfpeFormatType.ALLNUM_SSN.toString());
						logger.info("Encrypted Value3 : {}", StringEscapeUtils.escapeJava(sEncryptedValue));

						hmUpdatedInput.put("voltage_" + sKey, sEncryptedValue);
					} else if (alVoltageGenStrEncryptionFields.contains(sKey)) {
						sEncryptedValue = voltageHelper.getEncryptedValue(sEncryptField,
								VoltageEfpeFormatType.ALPHA_NUM.toString());
						logger.info("GAV-E5a.1 : EncryptedValue with ALPHA_NUM format: {}", StringEscapeUtils.escapeJava(sEncryptedValue));
						hmUpdatedInput.put("voltage_" + sKey, sEncryptedValue);
					} else
						hmUpdatedInput.put(sKey, sEncryptField);
				}
			}

		} catch (Exception e) {
			sAppInfo = "Error Encrypting";
			logger.error("GAV-E5a : " + "Exception thrown: " + e.toString());
			logger.error("GEV-E5b : " + sAppInfo);
			try {
				// changed by pm675e for voltage upgrade 6.0
				logger.error("GEV-E5c : " + e.getMessage());
			} catch (Exception e1) {
				// e1.printStackTrace();//1704 Release - Commenting SONAR Violation
				logger.error("GAV-E5c.1 : " + "Exception thrown: VeException.getDetailedMessage() "+e1);
			}
			hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			return hmResponse;
		}

		hmResponse = CommonErrorMap.makeCommonStatusMap(CErrorDefs.COMMON_SUCCESS_NUM, "");
		hmResponse.putAll(hmUpdatedInput);
		hmInput.putAll(hmUpdatedInput);
		logger.info(SpiMarker.getInstance(),"VoltageEncryptionHelper.getEFPEEncryptedValues.HLP999 : " + dtStart.getTime() + " hmResponse :{}", hmResponse);
		return hmResponse;
	}

	/**
	 * This method is part of the VoltageEncryptionHelper class.
	 * It takes a HashMap with encrypted values as input and returns a HashMap with decrypted values.
	 * The method uses the VoltageEncryptDecryptHelper instance to decrypt the values.
	 * The decrypted values are then returned as a HashMap.
	 *
	 * @param hmInput The HashMap with encrypted values to be decrypted.
	 * @return A HashMap with decrypted values.
	 */
	public HashMap getEFPEDecryptedValues(HashMap hmInput) {
		HashMap hmResponse = new HashMap();
		Date dtStart = new Date();
		String sDecryptedValue = null;
		String sDecryptField = null;

		String sAppInfo = null;

		logger.info(SpiMarker.getInstance(), "HLP000 : Input Hash = {}", hmInput);

		try {

			if (sVoltageDecryptionFields == null || sVoltageDecryptionFields.trim().length() == 0) {
				sAppInfo = "Missing or empty config parameter - VOLTAGE_DECRYPTED_FIELDS";
				logger.error("GADV-E4a : " + sAppInfo);
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, sAppInfo);
				return hmResponse;
			}
			alVoltageDecryptionFields = CommonUtil.parseToArray(sVoltageDecryptionFields, '|');
			logger.debug("GADV-1a : " + "alVoltageDecryptionFields=" + alVoltageDecryptionFields);

			if (sVoltagePCIDecryptionFields == null || sVoltagePCIDecryptionFields.trim().length() == 0) {
				// Unlike the other list fields, we expect this one to be blank because we do
				// not decrypt ccNumber
				alVoltagePCIDecryptionFields = new ArrayList();
			} else
				alVoltagePCIDecryptionFields = CommonUtil.parseToArray(sVoltagePCIDecryptionFields, '|');

			logger.debug("GADV-1b : " + "alVoltagePCIDecryptionFields=" + alVoltagePCIDecryptionFields);

			if (sVoltageSSNDecryptionFields == null || sVoltageSSNDecryptionFields.trim().length() == 0) {
				sAppInfo = "Missing or empty config parameter - VOLTAGE_SSN_DECRYPTED_FIELDS";
				logger.error("GADV-E4a : " + sAppInfo);
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, sAppInfo);
				return hmResponse;
			}

			alVoltageSSNDecryptionFields = CommonUtil.parseToArray(sVoltageSSNDecryptionFields, '|');
			logger.debug("GADV-2a : " + "alVoltageSSNDecryptionFields=" + alVoltageSSNDecryptionFields);

			// 1410: to decrypt CBR
			if (sVoltageGenStrDecryptionFields == null || sVoltageGenStrDecryptionFields.trim().length() == 0) {
				alVoltageGenStrDecryptionFields = new ArrayList();
			} else {
				alVoltageGenStrDecryptionFields = CommonUtil.parseToArray(sVoltageGenStrDecryptionFields, '|');
			}

			logger.debug("GADV-2a : " + "alVoltageGenStrDecryptionFields=" + alVoltageGenStrDecryptionFields);

			java.util.Map.Entry mapEntry = null;
			Iterator hmInputIterator = hmInput.entrySet().iterator();
			while (hmInputIterator.hasNext()) {
				mapEntry = (java.util.Map.Entry) hmInputIterator.next();
				String sKey = (String) mapEntry.getKey();

				Object oKeyObject = mapEntry.getValue();
				if (oKeyObject instanceof String) {
					sDecryptField = (String) hmInput.get(sKey);

					if (alVoltageDecryptionFields.contains(sKey)) {
						sDecryptedValue = voltageHelper.getDecryptedValue(sDecryptField, VoltageEfpeFormatType.B64_GENERIC.toString());
						
//						logger.debug("Decrypted Value : " + sDecryptedValue);
						hmInput.put(sKey, sDecryptedValue);
					} else if (alVoltagePCIDecryptionFields.contains(sKey)) {
						sDecryptedValue = voltageHelper.getDecryptedValue(sDecryptField, VoltageEfpeFormatType.CC_NUM.toString());
						hmInput.put(sKey, sDecryptedValue);
					} else if (alVoltageSSNDecryptionFields.contains(sKey)) {
						sDecryptedValue = voltageHelper.getDecryptedValue(sDecryptField, VoltageEfpeFormatType.ALLNUM_SSN.toString());

						hmInput.put(sKey, sDecryptedValue);
					} else if (alVoltageGenStrDecryptionFields.contains(sKey)) {
						sDecryptedValue = voltageHelper.getDecryptedValue(sDecryptField, VoltageEfpeFormatType.ALPHA_NUM.toString());
						hmInput.put(sKey, sDecryptedValue);
					} else
						hmInput.put(sKey, sDecryptField);
				}
			}

		} catch (Exception e) {
			sAppInfo = "Error Decrypting";
			logger.error("GDV-E5a : " + "VeException thrown: " + e.toString());
			logger.error("GDV-E5b : " + sAppInfo);
			try {
				// change by pm675e for voltage upgrade 6.0
				logger.error("GDV-E5c : " + e.getMessage());
			} catch (Exception e1) {
				// e1.printStackTrace();//1704 Release - Commenting SONAR Violation
				logger.error("GDV-E5c.1 : " + "Exception thrown: VeException.getDetailedMessage() "+e1);
			}
			hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			return hmResponse;
		}

		hmResponse = CommonErrorMap.makeCommonStatusMap(CErrorDefs.COMMON_SUCCESS_NUM, "");
		hmResponse.putAll(hmInput);
		logger.info(SpiMarker.getInstance(),"VoltageEncryptionHelper.getEFPEDecryptedValues.HLP999 : " + dtStart.getTime() + " hmResponse :", StructuredArguments.entries(hmResponse));
		return hmResponse;
	}
}