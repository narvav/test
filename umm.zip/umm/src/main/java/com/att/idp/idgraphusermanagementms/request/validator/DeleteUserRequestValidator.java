package com.att.idp.idgraphusermanagementms.request.validator;

import com.att.idp.idgraphusermanagementms.resource.request.DeleteUserRequest;
import com.att.idp.idgraphusermanagementms.resource.response.DeleteUserResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import jakarta.ws.rs.core.HttpHeaders;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Validator component responsible for performing all input validation for delete user requests.
 * <p>
 * This class validates mandatory headers, normalizes and validates {@link DeleteUserRequest} fields,
 * and constructs appropriate {@link DeleteUserResponse} instances when validation fails.
 * It is configured as a Spring {@code @Component} and loads configuration from
 * {@code userMgmt.properties}.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class DeleteUserRequestValidator {

    private static final Logger logger = LoggerFactory.getLogger(DeleteUserRequestValidator.class);

    private static final String sClassName = "DeleteUserRequestValidator";

    @Value("${deleteUserCallingSystemIds}")
    private String propCallingSystemId;

    /**
     * Validates the inbound delete user request and associated HTTP headers.
     * <p>
     * The method performs the following high-level checks:
     * <ul>
     *     <li>Validates and propagates the IdP trace identifier from the headers.</li>
     *     <li>Validates the {@code X-ATT-ClientId} header and sets the calling system ID.</li>
     *     <li>Delegates to {@link #validateRequest(DeleteUserRequest)} for payload level validation.</li>
     * </ul>
     * On validation failure a {@link DeleteUserResponse} containing the appropriate
     * error code and message is returned.
     *
     * @param deleteUserRequest the delete user request payload to validate; may be {@code null}
     * @param httpHeader        the HTTP headers associated with the request, used to obtain
     *                          trace and client identifiers
     * @return a {@link DeleteUserResponse} populated with validation error details when
     *         validation fails, or {@code null} if all validations succeed and processing
     *         should continue downstream
     */
    public DeleteUserResponse deleteUserRequestValidator(DeleteUserRequest deleteUserRequest,
                                                         HttpHeaders httpHeader) {

        String callingMethodName = ".deleteUserRequestValidator";

        String message;
        String idpTraceId;
        String xATTClientId;
        DeleteUserResponse deleteUserResponse;

        idpTraceId = CommonUtil.getTraceId(httpHeader);

        if (idpTraceId == null || idpTraceId.startsWith("AutoGen_")) {
            message = "Missing or Invalid IdpTraceId";
            return buildDeleteUserResponse(CErrorDefs.ERR_INVALID_DATA_NUM, message, idpTraceId);
        }

        if (deleteUserRequest == null) {
            message = "Input Request Parameter is NULL / Empty.";
            logger.info(SpiMarker.getInstance(), "{}{}UPRV.VUPR_01 :: {}", sClassName, callingMethodName, message);
            return buildDeleteUserResponse(CErrorDefs.ERR_INVALID_DATA_NUM, message, idpTraceId);
        }

        deleteUserRequest.setIdpTraceId(idpTraceId);

        if (httpHeader.getHeaderString("X-ATT-ClientId") != null) {
            xATTClientId = httpHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
            logger.info(SpiMarker.getInstance(), "{}{}UPRV.VUPR_02 : Setting callingSystemId: {}", sClassName,
                    callingMethodName, CommonUtilHelper.sanitizeForLog(xATTClientId));
            deleteUserRequest.setCallingSystemId(xATTClientId);
        } else {
            message = "Missing or invalid X-ATT-ClientId in request header";
            logger.info(SpiMarker.getInstance(), "{}{}UPRV.VUPR_03 :: {}", sClassName, callingMethodName, message);
            return buildDeleteUserResponse(CErrorDefs.ERR_INVALID_DATA_NUM, message, idpTraceId);
        }

        try {
            deleteUserResponse = validateRequest(deleteUserRequest);
            if (deleteUserResponse != null) {
                logger.info(SpiMarker.getInstance(), "{}{}DURV.VR_01 Response from DeleteUserRequestValidator : {}",
                        sClassName, callingMethodName, deleteUserResponse);
                return deleteUserResponse;
            } else {
                logger.debug("{}{}DURV.VR_02 Success Response from DeleteUserRequestValidator ", sClassName,
                        callingMethodName);
            }
            message = "Input Validation Successful";
            logger.info(SpiMarker.getInstance(), "{}{}DURV.VR_06 : {}", sClassName, callingMethodName, message);
        } catch (Exception e) {
            message = "Exception thrown in DeleteUserRequestValidator.validateRequest : " + e.getMessage();
            logger.info(SpiMarker.getInstance(), "Exception in validateRequest: {}", message);
            return buildDeleteUserResponse(CErrorDefs.ERR_SYS_APPL_NUM, message, idpTraceId);
        }
        return deleteUserResponse;

    }

    /**
     * Performs detailed validation of the {@link DeleteUserRequest} payload.
     * <p>
     * This includes normalization of selected fields, validation of the calling system
     * identifier, unknown attribute checks, and business rules around combinations of
     * handle, domain and GUID.
     *
     * @param deleteUserRequest the request object whose fields should be validated
     * @return a {@link DeleteUserResponse} populated with validation error details when
     *         a rule is violated, or {@code null} when the request passes all checks
     */
    private DeleteUserResponse validateRequest(DeleteUserRequest deleteUserRequest) {

        DeleteUserResponse deleteUserResponse = null;
        String sAppInfo;

        Optional.ofNullable(deleteUserRequest.getCallingSystemId())
                .ifPresent(x -> deleteUserRequest.setCallingSystemId(x.trim().toUpperCase()));
        Optional.ofNullable(deleteUserRequest.getHandle())
                .ifPresent(x -> deleteUserRequest.setHandle(x.trim().toLowerCase()));
        Optional.ofNullable(deleteUserRequest.getIsExternalCall())
                .ifPresent(x -> deleteUserRequest.setIsExternalCall(x.trim().toUpperCase()));
        Optional.ofNullable(deleteUserRequest.getDomain())
                .ifPresent(x -> deleteUserRequest.setDomain(x.trim().toLowerCase()));
        Optional.ofNullable(deleteUserRequest.getGuid()).ifPresent(x -> deleteUserRequest.setGuid(x.trim()));

        String sIdpTraceId = deleteUserRequest.getIdpTraceId();
        String sIsExternalCall = Optional.ofNullable(deleteUserRequest.getIsExternalCall()).orElse("Y");
        String sHandle = deleteUserRequest.getHandle();
        String sDomain = deleteUserRequest.getDomain();
        String sCallingSystemId = deleteUserRequest.getCallingSystemId();
        String guid = deleteUserRequest.getGuid();

        ArrayList<String> alDeleteUserCallingSystemIds = CommonUtil.parseToArray(propCallingSystemId,
                CommonDefs.VALUE_SEPARATOR_CHAR);

        if (!alDeleteUserCallingSystemIds.contains(sCallingSystemId)
                && CommonDefs.IND_Y.equals(sIsExternalCall)) {
            sAppInfo = "Missing or invalid X-ATT-ClientId in request header";
            return buildDeleteUserResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
        }

        // checking Invalid attributes passed in Request
        Map<String, Object> allUnknownAttributes = new HashMap<>(deleteUserRequest.unknownAttributes);

        if (!allUnknownAttributes.isEmpty()) {
            sAppInfo = "Invalid Attributes passed in deleteUserRequest : " + allUnknownAttributes;
            return buildDeleteUserResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
        }

        if (!StringUtils.isEmpty(sIsExternalCall)) {
            if (!(sIsExternalCall.equalsIgnoreCase(CommonDefs.IND_Y)
                    || sIsExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
                sAppInfo = "IsExternalCall must be one of Y or N";
                return buildDeleteUserResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
            }
        }

        // handle, domain and guid validations
        if (!StringUtils.isEmpty(sHandle) && StringUtils.isEmpty(sDomain)) {
            sAppInfo = "UserId without domain is not allowed";
            return buildDeleteUserResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);

        }

        // consider handle passed along with domain, validated above
        if (!StringUtils.isEmpty(sHandle) && !StringUtils.isEmpty(guid)) {
            sAppInfo = "Either userId / domain or guid should present in the input";
            return buildDeleteUserResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo, sIdpTraceId);
        }

        return deleteUserResponse;
    }

    /**
     * Builds a {@link DeleteUserResponse} instance from the given status code and message.
     * <p>
     * The response is created via {@link CommonUtilHelper#generateDeleteUserResponse(Map)}
     * using a map that contains application information, trace identifier and status code.
     *
     * @param appStatusCode the application status code that represents the validation or system state
     * @param message       the descriptive message to be returned to the client
     * @param idpTraceId    the IdP trace identifier associated with the request, used for tracking
     * @return a {@link DeleteUserResponse} containing the provided details
     */
    private DeleteUserResponse buildDeleteUserResponse(int appStatusCode, String message, String idpTraceId) {

        Map<String, Object> hmResponse = CommonUtil.getHashMap();
        hmResponse.put(CommonDefs.COMMON_APP_INFO, message);
        hmResponse.put("idp-trace-id", idpTraceId);
        hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
        return CommonUtilHelper.generateDeleteUserResponse(hmResponse);
    }
}
