package com.att.idp.idgraphusermanagementms.utils;

import com.att.mpsys.common.utils.CommonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Component
public class SharedUtilHelper {

    public static final Logger logger = LoggerFactory.getLogger(SharedUtilHelper.class);
    private static final String sClassName = "SharedUtilHelper";

    @Value("#{'${updateForSlidAndMembers}'.split('\\|')}")
    private ArrayList<String> alUpdateForSlidAndMembers;

    @Value("#{'${updateForSlidOnly}'.split('\\|')}")
    private ArrayList<String> alUpdateForSlidOnly;

    @Value("#{'${updateContactInfoFields}'.split('\\|')}")
    private ArrayList<String> alUpdateContactInfoFields;

    @Value("#{'${updateUserMemberIdUpdatableAttributes}'.split('\\|')}")
    private ArrayList<String> alUpdateForMemberIdOnly;


    /**
     * Populates a HashMap with SLID and Member data based on the input map and a mapping configuration.
     * <p>
     * This method processes the input map (`hmInput`) to extract fields specified in the
     * `alUpdateForSlidAndMembers` list. For each field present in `hmInput` and not empty,
     * it adds the value to the resulting HashMap using the corresponding database field name
     * from `hmUpdateUserInputToDBKeysMap`.
     * </p>
     *
     * @param hmInput A map containing the input data for processing.
     * @param hmUpdateUserInputToDBKeysMap A HashMap mapping input field names to database field names.
     * @return HashMap A HashMap containing the populated SLID and Member data.
     */
    public HashMap populateMemberDataForSlidAndMembers(Map<String, Object> hmInput, HashMap hmUpdateUserInputToDBKeysMap) {
        String sMethodName = ".populateHmMemberDataSlidAndMembers.";

        HashMap hmMemberDataSlidAndMembers = CommonUtil.getHashMap();

        if (alUpdateForSlidAndMembers != null && !alUpdateForSlidAndMembers.isEmpty()) {
            for (int i = 0; i < alUpdateForSlidAndMembers.size(); i++) {
                String fieldName = (String) alUpdateForSlidAndMembers.get(i);

                if (hmInput.containsKey(fieldName)) {
                    String fieldValue = (String) hmInput.get(fieldName);
                    if (fieldValue != null && fieldValue.trim().length() > 0) {
                        String stDBfieldName = (String) hmUpdateUserInputToDBKeysMap.get(fieldName);
                        hmMemberDataSlidAndMembers.put(stDBfieldName, fieldValue);
                    }
                }
            }
        }
        return hmMemberDataSlidAndMembers;
    }

    /**
     * Populates a HashMap with SLID-only member data based on the input map and a mapping configuration.
     * <p>
     * This method processes the input map (`hmInput`) to extract fields specified in the
     * `alUpdateForSlidOnly` list. For each field present in `hmInput` and not empty,
     * it adds the value to the resulting HashMap using the corresponding database field name
     * from `hmUpdateUserInputToDBKeysMap`.
     *
     * @param hmInput A map containing the input data for processing.
     * @param hmUpdateUserInputToDBKeysMap A HashMap mapping input field names to database field names.
     * @return HashMap A HashMap containing the populated SLID-only member data.
     */
    public HashMap populateMemberDataForSlidOnly(Map<String, Object> hmInput, HashMap hmUpdateUserInputToDBKeysMap) {
        String sMethodName = ".populateMemberDataForSlidOnly.";

        HashMap hmMemberDataForSlidOnly = CommonUtil.getHashMap();

        if (alUpdateForSlidOnly != null && !alUpdateForSlidOnly.isEmpty()) {
            for (int i = 0; i < alUpdateForSlidOnly.size(); i++) {
                String fieldName = (String) alUpdateForSlidOnly.get(i);

                if (hmInput.containsKey(fieldName)) {
                    String fieldValue = (String) hmInput.get(fieldName);
                    if (fieldValue != null && fieldValue.trim().length() > 0) {
                        String stDBfieldName = (String) hmUpdateUserInputToDBKeysMap.get(fieldName);
                        hmMemberDataForSlidOnly.put(stDBfieldName, fieldValue);
                    }
                }
            }
        }
        return hmMemberDataForSlidOnly;
    }

    /**
     * Populates a HashMap with contact info fields based on the input map and a mapping configuration.
     * <p>
     * This method processes the input map (`hmInput`) to extract fields specified in the
     * `alUpdateContactInfoFields` list. For each field present in `hmInput` and not empty,
     * it adds the value to the resulting HashMap using the corresponding database field name
     * from `hmUpdateUserInputToDBKeysMap`.
     *
     * @param hmInput A map containing the input data for processing.
     * @param hmUpdateUserInputToDBKeysMap A HashMap mapping input field names to database field names.
     * @return HashMap A HashMap containing the populated contact info fields.
     */
    public HashMap populateMemberDataForContactInfoFields(Map<String, Object> hmInput, HashMap hmUpdateUserInputToDBKeysMap) {
        String sMethodName = ".populateMemberDataForContactInfoFields.";

        HashMap hmMemberDataForContactInfoFields = CommonUtil.getHashMap();

        if (alUpdateContactInfoFields != null && !alUpdateContactInfoFields.isEmpty()) {
            for (int i = 0; i < alUpdateContactInfoFields.size(); i++) {
                String fieldName = (String) alUpdateContactInfoFields.get(i);

                if (hmInput.containsKey(fieldName)) {
                    String fieldValue = (String) hmInput.get(fieldName);
                    if (fieldValue != null && fieldValue.trim().length() > 0) {
                        String stDBfieldName = (String) hmUpdateUserInputToDBKeysMap.get(fieldName);
                        hmMemberDataForContactInfoFields.put(stDBfieldName, fieldValue);
                    }
                }
            }
        }
        return hmMemberDataForContactInfoFields;
    }

    /**
     * Populates a HashMap with MemberId-only data based on the input map and a mapping configuration.
     * <p>
     * This method processes the input map (`hmInput`) to extract fields specified in the
     * `alUpdateForMemberIdOnly` list. For each field present in `hmInput` and not empty,
     * it adds the value to the resulting HashMap using the corresponding database field name
     * from `hmUpdateUserInputToDBKeysMap`.
     * </p>
     *
     * @param hmInput A map containing the input data for processing.
     * @param hmUpdateUserInputToDBKeysMap A HashMap mapping input field names to database field names.
     * @return HashMap A HashMap containing the populated MemberId-only data.
     */
    public HashMap populateMemberDataForMemberIdOnly(Map<String, Object> hmInput, HashMap hmUpdateUserInputToDBKeysMap) {
        String sMethodName = ".populateMemberDataForMemberIdOnly.";

        HashMap hmMemberDataMemberIdOnly = CommonUtil.getHashMap();

        if (alUpdateForMemberIdOnly != null && !alUpdateForMemberIdOnly.isEmpty()) {
            for (int i = 0; i < alUpdateForMemberIdOnly.size(); i++) {
                String fieldName = (String) alUpdateForMemberIdOnly.get(i);

                if (hmInput.containsKey(fieldName)) {
                    String fieldValue = (String) hmInput.get(fieldName);
                    if (fieldValue != null && fieldValue.trim().length() > 0) {
                        String stDBfieldName = (String) hmUpdateUserInputToDBKeysMap.get(fieldName);
                        hmMemberDataMemberIdOnly.put(stDBfieldName, fieldValue);
                    }
                }
            }
        }
        return hmMemberDataMemberIdOnly;
    }
}
