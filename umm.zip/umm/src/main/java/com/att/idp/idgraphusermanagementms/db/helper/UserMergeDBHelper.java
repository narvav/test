package com.att.idp.idgraphusermanagementms.db.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.mpsys.common.utils.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphusermanagementms.db.model.Tusermerge;
import com.att.idp.idgraphusermanagementms.db.repository.UserMergeRepository;
import org.springframework.web.util.HtmlUtils;

/**
 * 
 * @author sp7569
 *
 */
@Component
public class UserMergeDBHelper {

	private static String sClassName = "UserMergeDBHelper";
	public static final Logger logger = LoggerFactory.getLogger(UserMergeDBHelper.class);

	@Autowired
	private UserMergeRepository userMergeRepository;
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	/**
	 * This method retrieves the user merge information from the database.
	 * It takes a HashMap as input which contains key-value pairs for various user merge attributes.
	 * The method first checks if the input HashMap is null or if it contains invalid data. If it does, it returns an error status.
	 * Then it retrieves the user merge attributes from the input HashMap.
	 * If the user merge attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the userMergeRepository.
	 * Finally, it returns a HashMap containing the status of the operation and the retrieved user merge's information.
	 *
	 * @param hmInput A HashMap containing the details of the user merge to be retrieved.
	 * @return A HashMap containing the status of the operation and the retrieved user merge's information.
	 */
	public HashMap<String, Object> getUserMergeInfo(HashMap<String, Object> hmInput) {

		String thisMethod = ".getUserMergeInfo.";

		HashMap<String, Object> hmResult = CommonUtil.getHashMap();
		List<Object> objectList = CommonUtil.getArrayList();
		List<Tusermerge> alQueryResponse = null;

		String stSourceMemberNum = null;
		String sAppInfo = null;

		logger.info(ProfileOrchestrationConstants.LOG_DBTOOLS000, sClassName, thisMethod, hmInput);

		if (hmInput == null) {
			hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_EMPTY_NUM, "Input hash is empty");
			logger.info("{}{}UMDBH001 : Input hash is empty: {} ", sClassName, thisMethod, hmResult);
			return hmResult;
		}

		stSourceMemberNum = (String) hmInput.get("source_member_num");

		if (stSourceMemberNum == null || stSourceMemberNum.isEmpty()) {
			sAppInfo = "source_member_num can not be null or empty in input";
			hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_EMPTY_NUM, sAppInfo);
			logger.info("{}{}UMDBH002 : source_member_num is either null or empty in input", sClassName, thisMethod);
			return hmResult;
		}

		try {
			long pTime = 0;
			Date dtQueryTime = new Date();
			logger.debug("{}{}UMDBH003 : Query start time", sClassName, thisMethod);

			objectList.add(stSourceMemberNum);

			alQueryResponse = userMergeRepository.getUserMergeDetails(Long.valueOf(stSourceMemberNum));

			int numRowsFound = 0;
			if (alQueryResponse != null && !alQueryResponse.isEmpty()) {

				for (Tusermerge tusermerge : alQueryResponse) {

					numRowsFound++;
					hmResult.put("source_member_num", tusermerge.getSourceMemberNum().toString());
					hmResult.put("target_member_num", tusermerge.getTargetMemberNum().toString());
				}

			}

			if (numRowsFound == 0) {
				sAppInfo = "No record found";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, sAppInfo);
				logger.info("{}{}UMDBH004 error : {}", sClassName, thisMethod, sAppInfo);
				return hmResult;
			}

			pTime = (System.currentTimeMillis() - dtQueryTime.getTime());
			logger.info("{}{}UMDBH005 : Total time taken to execute query = {} milliseconds", sClassName, thisMethod,
					pTime);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			logger.error("{}{} UMDBH006 : Error:: {}", sClassName, thisMethod, e.getMessage());
			logger.error("{}{} UMDBH007 : Exception = {}", sClassName, thisMethod, e);
		} finally {
			logger.info("{}{}DBTOOLS999 : Response is : {}", sClassName, thisMethod, hmResult);
		}
		return hmResult;
	}

	/**
	 * This method is used to insert user merge details into the database.
	 *
	 * @param hmInput A HashMap containing the necessary parameters for the insert operation.
	 *                It should contain the following keys:
	 *                - DB_SOURCE_MEMBER_NUM: The source member number.
	 *                - DB_SOURCE_MEMBER_NAME: The source member name.
	 *                - DB_TARGET_MEMBER_NUM: The target member number.
	 *                - DB_TARGET_MEMBER_NAME: The target member name.
	 *                - DB_LAST_MODIFIED_BY: The identifier of the user who last modified the record.
	 *                - DB_IP_ADDRESS: The IP address of the user who is performing the operation.
	 * @return A HashMap containing the result of the operation. If the operation is successful,
	 *         the map contains a success message and the number of rows inserted.
	 *         If an error occurs, the map contains an error message.
	 */
	public HashMap insertUserMergeDetails(HashMap hmInput) {
		String sMethodName = ".insertUserMergeDetails.";
		HashMap<String, Object> hmResult = null;
		List<Object> objectList = CommonUtil.getArrayList();
		String stAppInfo = null;
		int rowCount;
		String queryInsertUserMerge = "INSERT INTO USERMERGE(source_member_num, source_member_name, " +
				"target_member_num, target_member_name, last_modified_by) values (?, ?, ?, ?, ?)";

		logger.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName,
				HtmlUtils.htmlEscape(String.valueOf(hmInput)));
		try {
			String stLastModifiedBy = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);

			String stIPAddress = (String) hmInput.get(MPSDefs.DB_IP_ADDRESS);
			if (stLastModifiedBy == null || stLastModifiedBy.trim().length() == 0) {
				stAppInfo = "last_modified_by is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM, stAppInfo);
				logger.info("{}{}IUMD001: {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			objectList.add(hmInput.get("DB_SOURCE_MEMBER_NUM"));
			objectList.add(hmInput.get("DB_SOURCE_MEMBER_NAME"));
			objectList.add(hmInput.get("DB_TARGET_MEMBER_NUM"));
			objectList.add(hmInput.get("DB_TARGET_MEMBER_NAME"));
			objectList.add(stLastModifiedBy);

			long tTime = 0;
			Date dtStartDate = new Date();
			rowCount = jdbcTemplate.update(new String(queryInsertUserMerge),
					objectList.toArray(new Object[objectList.size()]));

			tTime = (System.currentTimeMillis() - dtStartDate.getTime());
			logger.info("{}{}IUMD002 :Total time taken to execute query {} milliseconds", sClassName, sMethodName,
					tTime);

			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
					"No of rows inserted:= " + rowCount);
			logger.info("{}{}IUMD003: No of rows inserted = {}", sClassName, sMethodName, rowCount);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}IUMD004 :  Error::{}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}IUMD005 : Exception = {}", sClassName, sMethodName, e);

		} finally {
			logger.info("{}{}DBTOOLS999 : STATUS = {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;
	}


}
