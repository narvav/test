package com.att.idp.idgraphusermanagementms.helper;

import com.att.idp.idgraphusermanagementms.db.helper.UpgSecMemberIdDBHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.*;
import net.logstash.logback.argument.StructuredArguments;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.util.HashMap;
import java.util.Map;


/**
 * This class provides helper methods for upgrading secondary member IDs.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class UpgSecMemberIdHelper {

    public static final Logger logger = LoggerFactory.getLogger(UpgSecMemberIdHelper.class);

    private static String sClassName = "upgSecMemberIdHelper";

    @Autowired
    private UpgSecMemberIdDBHelper upgSecMemberIdDBHelper;


    /**
     * This method is used to upgrading a secondary member ID.
     *
     * @param hmInput A HashMap containing input details such as calling system ID.
     * @return A HashMap containing the result of the operation.
     */
    public Map<String, Object> upgSecMemberId(Map<String, Object> hmInput) {
        Map<String, Object> hmResult = CommonUtil.getHashMap();
        String sMethodName = ".upgSecMemberId.";
        String stAppInfo = null;
        String stAppStatusCode = null;
        boolean isTransactionRollbackOnError = false;
        logger.info(SpiMarker.getInstance(), "upgSecMemberIdHelper.upgSecMemberId.HLP000 : Input Hash : {}",
                StructuredArguments.entries(hmInput));


        try {
            String transactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
            String callingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
            String secDomain = (String) hmInput.get("secDomain");

            Map<String, Object> secondaryMemberInfo = new HashMap<>();
            secondaryMemberInfo.put("secMemberId", hmInput.get("secMemberId"));
            secondaryMemberInfo.put("secDomain", secDomain);
            secondaryMemberInfo.put("callingSystemId", callingSystemId);
            secondaryMemberInfo.put("transactionName", transactionName);


            logger.info("{}{} USMIH.USMID.01 : {}:{}", sClassName, sMethodName,
                    "Calling upgSecMemberIdDBHelper.upgSecMemberId () with input = ", secondaryMemberInfo);
            hmResult = upgSecMemberIdDBHelper.upgSecMemberId(secondaryMemberInfo);

            logger.info("{}{} USMIH.USMID.02 : {}:{}", sClassName, sMethodName,
                    "Response from upgSecMemberIdDBHelper.upgSecMemberId () ", hmResult);

            if (hmResult == null || hmResult.isEmpty()) {
                stAppInfo = "upgSecMemberIdDBHelperresponse is null or Empty";
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                logger.info("{}{} USMIH.USMID.03 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(stAppInfo));
                return hmResult;
            }

            stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

            if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
                stAppInfo = "upgSecMemberIdDBHelper db update was failed."
                        + hmResult.get(CErrorDefs.COMMON_APP_INFO);
                logger.info("{}{} USMIH.USMID.04 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(stAppInfo));
                isTransactionRollbackOnError = true;
                return hmResult;
            }


        } catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e);

        } finally {

            logger.debug(SpiMarker.getInstance(),
                    "USMIDH.QSMI.06:  Response from upgSecMemberIdHelper.upgSecMemberId.GPH_25 {}",
                    StructuredArguments.entries(hmResult));

            if (hmResult == null || hmResult.isEmpty()) {
                stAppInfo = "Response from upgSecMemberIdHelper is NULL";
                logger.debug("{}{} USMIDH.QSMI.07 : Response from upgSecMemberIdHelper.upgSecMemberId : {}",
                        sClassName, sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);

            }
            String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);

            if (isTransactionRollbackOnError && !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
                hmResult.put("isTransactionRollback", "Y");
            }
            logger.info(SpiMarker.getInstance(), "upgSecMemberIdHelper response.HLP999 : Input Hash : {}",
                    StructuredArguments.entries(hmResult));
        }
        return hmResult;
    }
}