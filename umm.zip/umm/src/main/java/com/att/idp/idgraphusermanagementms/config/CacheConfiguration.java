package com.att.idp.idgraphusermanagementms.config;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableCaching
public class CacheConfiguration {

  @Bean
  public CacheManager cacheManager() {
    return new ConcurrentMapCacheManager(
        "getDomainId",
        "getDomainName",
        "getSorId",
        "getSorName",
        "getSecurityQuestion",
        "getSecurityQuestionId",
        "getServiceId",
        "getNextId",
        "getServiceName",
        "getServices",
        "getStatusNameByCode",
        "getStatusCode",
        "getAccessId",
        "getAccessName",
        "getRoleId",
        "getAttributeIdFromName"
    );
  }
}
