package com.att.idp.idgraphusermanagementms.request.validator;

import com.att.idp.idgraphusermanagementms.resource.response.MemberIdResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import jakarta.ws.rs.core.HttpHeaders;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import java.util.List;
import java.util.Map;


@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class QueryMemberIdRequestValidator {

    /*** Logger instance for logging events.*/
    private static final Logger logger = LoggerFactory.getLogger(QueryMemberIdRequestValidator.class);

    @Value("#{'${queryMemberIdCallingSystemIds}'.split('\\|')}")
    private List<String> queryMemberIdCallingSystemId;

    @Value("#{'${queryMemberIdSecMemberIds}'.split('\\|')}")
    private List<String> queryMemberIdSecMemberId;
    /**
     * Class name for logging purposes.
     */
    private static final String CLASS_NAME = "QueryMemberIdRequestValidator";

    /**
     * Validates the incoming request headers for querying member ID.
     *
     * @param requestHeader The HTTP headers from the incoming request.
     * @return MemberIdResponse containing error details if validation fails, or null if successful.
     */

    public MemberIdResponse queryMemberIdRequestValidator(HttpHeaders requestHeader, String stRequestTraceId) {

        String sMethodName = ".queryMemberIdRequestValidator.";
        String stAppInfo = null;
        MemberIdResponse memberIdResponse = null;

        if (requestHeader == null) {
            stAppInfo = "Request Header is Mandatory.";
            logger.info("{} {}QMIRV_01 :: {}", CLASS_NAME, sMethodName, stAppInfo);
            return memberIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stRequestTraceId);
        }

        logger.info("{} {} : Request Header  : {}", CLASS_NAME, sMethodName, CommonUtilHelper.sanitizeForLog(String.valueOf(requestHeader.getRequestHeaders())));

        if (stRequestTraceId == null || stRequestTraceId.startsWith("AutoGen_")) {
            stAppInfo = "idp-trace-id is missing in the request header";
            return memberIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stRequestTraceId);
        }
        try {
            memberIdResponse = memberIdInputValidator(requestHeader,stRequestTraceId);
            if (memberIdResponse != null) {
                logger.info("{} {}QMIRV_02 Response from QueryMemberIdRequestValidator : {}", CLASS_NAME, sMethodName,
                        memberIdResponse);
                return memberIdResponse;
            }

            memberIdResponse = memberIdCSIValidator(requestHeader,stRequestTraceId);
            if (memberIdResponse != null) {
                logger.info("{} {}QMIRV_03 Response from QueryMemberIdRequestValidator : {}", CLASS_NAME, sMethodName,
                        memberIdResponse);
                return memberIdResponse;
            }

            stAppInfo = "Input Validation is Successful";
            logger.info("{} {}QMIRV_04 : {}", CLASS_NAME, sMethodName, stAppInfo);

        } catch (Exception e) {
            stAppInfo = "Exception thrown in QueryMemberIdRequestValidator : "
                    + e.getMessage();
            logger.error("{} {}QMIRV_05: Exception in memberIdRequestValidator: {}", CLASS_NAME,sMethodName,stAppInfo);
            memberIdResponse = memberIdErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo, stRequestTraceId);

        }
        return memberIdResponse;
    }

    /**
     * Validates the `X-ATT-ClientId` and `secMemberIds` headers against allowed values.
     *
     * @param requestHeader The HTTP headers from the incoming request.
     * @return MemberIdResponse containing error details if validation fails, or null if successful.
     */

    private MemberIdResponse memberIdCSIValidator(HttpHeaders requestHeader, String stRequestTraceId) {

        String sMethodName = ".memberIdCSIValidator.";
        String stAppInfo = null;

        String sSecMemberIds = requestHeader.getHeaderString("secMemberIds").trim().toUpperCase();
        String sCallingSystemId = requestHeader.getHeaderString("X-ATT-ClientId").trim().toUpperCase();

        logger.debug("{} {}QMIRV_06 :  CallingSystemIds : {}", CLASS_NAME, sMethodName, queryMemberIdCallingSystemId);
        if (!queryMemberIdCallingSystemId.contains(sCallingSystemId)) {
            stAppInfo = "Invalid value for X-ATT-ClientId in the request header";
            return memberIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stRequestTraceId);
        }
        logger.debug("{} {}QMIRV_07 : secMemberIds : {}", CLASS_NAME, sMethodName, queryMemberIdSecMemberId);
        if(!queryMemberIdSecMemberId.contains(sSecMemberIds)) {
            stAppInfo = "Invalid value for secMemberIds in the request header";
            return memberIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stRequestTraceId);
        }
        return null;
    }

    /**
     * Validates the input headers for member ID requests.
     *
     * Checks for the presence and exclusivity of required headers:
     * - Either `memberId`/`domain` or `guid` or `ban` must be present, but only one combination.
     * - `X-ATT-ClientId` and `secMemberIds` must be present.
     *
     * @param requestHeader The HTTP headers from the incoming request.
     * @return MemberIdResponse containing error details if validation fails, or null if successful.
     */
    private MemberIdResponse memberIdInputValidator(HttpHeaders requestHeader, String stRequestTraceId) {

        String stAppInfo=null;
        String sMethodName= ".memberIdInputValidator.";

        String sMemberId = requestHeader.getHeaderString(CommonDefs.MEMBERID) ;
        String sDomain = requestHeader.getHeaderString(CommonDefs.DOMAIN) ;
        String sGuid = requestHeader.getHeaderString(CommonDefs.GUID) ;
        String sBan = requestHeader.getHeaderString(CommonDefs.BAN) ;
        String sSecMemberIds = requestHeader.getHeaderString("secMemberIds") ;
        String sCallingSystemId = requestHeader.getHeaderString("X-ATT-ClientId");

        boolean hasMemberId = !StringUtils.isBlank(sMemberId);
        boolean hasDomain =  !StringUtils.isBlank(sDomain);
        boolean hasGuid = !StringUtils.isBlank(sGuid);
        boolean hasBan = !StringUtils.isBlank(sBan);

        boolean hasMemberIdAndDomain = hasMemberId && hasDomain;
        if (!hasMemberIdAndDomain && !hasGuid && !hasBan) {
            stAppInfo = "At least one of memberId and domain, guid, or ban must be present in request headers.";
            logger.info("{} {}QMIRV_02.1 : {}", CLASS_NAME, sMethodName, stAppInfo);
            return memberIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stRequestTraceId);
        }

        int validInputCount = 0;
        if (hasMemberId || hasDomain) validInputCount++;
        if (hasGuid) validInputCount++;
        if (hasBan) validInputCount++;

        if (validInputCount > 1) {
            stAppInfo = "Request can have only one of memberId and domain, guid, or ban.";
            logger.info("{} {}QMIRV_02.2 : {}", CLASS_NAME, sMethodName, stAppInfo);
            return memberIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stRequestTraceId);
        }

        if(hasGuid && !sGuid.matches("[0-9]+")){
            stAppInfo = "GUID must be numeric.";
            logger.info("{} {}QMIRV_02.3 : {}", CLASS_NAME, sMethodName, stAppInfo);
            return memberIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stRequestTraceId);
        }

        if (StringUtils.isBlank(sCallingSystemId)) {
            stAppInfo = " X-ATT-ClientId is mandatory in the request";
            logger.info("{} {}QMIRV_02.4 : {}", CLASS_NAME, sMethodName, stAppInfo);
            return memberIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
                    stRequestTraceId);
        }
        if (StringUtils.isBlank(sSecMemberIds)) {
            stAppInfo = "secMemberIds  must be present in the request header";
            logger.info("{} {}QMIRV_02.5 : {}", CLASS_NAME, sMethodName, stAppInfo);
            return memberIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stRequestTraceId);
        }

        return null;
    }

    /**
     * Generates an error response for the MemberId request.
     *
     * @param errorCode The error code to be included in the response.
     * @param stAppInfo A string containing application-specific information about the error.
     * @param traceId   The trace ID for tracking the request.
     * @return A MemberIdResponse object containing the error details.
     */
    private MemberIdResponse memberIdErrorResponse(int errorCode, String stAppInfo, String traceId) {
        Map<String, Object> hmResponse = CommonUtil.getHashMap();
        hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
        hmResponse.put("idp-trace-id", traceId);
        hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(errorCode));
        return CommonUtilHelper.generateMemberIdResponse(hmResponse);
    }
}
