package com.att.idp.idgraphusermanagementms.db.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.logstash.logback.argument.StructuredArguments;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.StatusMsg;

/**
 * This class is responsible for managing IP rate limits in the database.
 * It uses Spring's JdbcTemplate for database operations.
 *
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like JdbcTemplate.
 *
 * The class contains methods for querying, adding, updating, and deleting IP rate limits in the database.
 *
 */
@Component
public class IPRateLimitDBHelper {

	public static final Logger logger = LoggerFactory.getLogger(IPRateLimitDBHelper.class);
	private static final String info = "$Id: master/com/att/idp/idgraphusermanagementms/helper/dbhelpers/IPRateLimitDBHelper.java v1 2024-02-05 pb6583 $;";
	private static String sClassName = "IPRateLimitDBHelper";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	
	/**
	 * This method queries the IP rate limit from the database.
	 * It takes a HashMap as input which contains key-value pairs for various IP rate limit attributes like IP address and last modified by.
	 * The method first checks if the input HashMap is null or if the required attributes are missing. If they are, it returns an error status.
	 * Then it retrieves the IP rate limit attributes from the input HashMap.
	 * If the IP rate limit attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param hmInput A HashMap containing the details of the IP rate limit's information to be retrieved.
	 * @return A HashMap containing the status of the operation and the retrieved IP rate limit's information.
	 */
	public HashMap queryIPRateLimit(HashMap hmInput) {

		String sMethodName = ".queryIPRateLimit.";
		HashMap<String, Object> hmResult = null;
		String stAppInfo = null;
		String dateFormat = "MMDDYYYY HH24:mi:ss";
		String queryIPRateLimitSql = "SELECT IP_ADDRESS, APP_CALLINGSYSID, TXN_COUNT, TO_CHAR(IP_INIT_DATE, '"
				+ dateFormat + "') AS IP_INIT_DATE, TO_CHAR(CREATE_DATE, '" + dateFormat
				+ "') AS CREATE_DATE, TO_CHAR(LAST_MODIFIED, '" + dateFormat
				+ "') AS LAST_MODIFIED, LAST_MODIFIED_BY, TO_CHAR(SYSDATE, '" + dateFormat + "') AS DB_SYSDATE "
				+ "FROM ipratelimit " + "WHERE IP_ADDRESS = ? " + "AND APP_CALLINGSYSID = ?";

		logger.info("{}{}QIPRL.DBH_01. : queryIPRateLimit CVS KEYWORDS: {}", sClassName, sMethodName, info);
		logger.info("{}{}DBTOOLS000 : queryIPRateLimit InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmInput));
		try {
			List<Object> objectList = new ArrayList<Object>();
			List alQueryResponse = null;
			String stLastModifiedBy = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);
			String stIPAddress = (String) hmInput.get(MPSDefs.DB_IP_ADDRESS);
			if (stLastModifiedBy == null || stLastModifiedBy.trim().length() == 0 || stIPAddress == null
					|| stIPAddress.trim().length() == 0) {
				stAppInfo = "last_modified_by/ip_address is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, stAppInfo);
				logger.info("{}{}QIPRL.DBH_03: {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			objectList.add(stIPAddress);
			objectList.add(stLastModifiedBy);

			logger.info("{}{}QIPRL.DBH_04 :Calling  queryIPRateLimitSql method with input: {} ", sClassName,
					sMethodName, queryIPRateLimitSql);

			long tTime = 0;
			Date dtStartDate = new Date();
			alQueryResponse = jdbcTemplate.queryForList(new String(queryIPRateLimitSql),
					objectList.toArray(new Object[objectList.size()]));

			// Calculate the total time taken to nsert rows in DB
			// to return time in milliseconds
			tTime = (System.currentTimeMillis() - dtStartDate.getTime());
			logger.info("{}{}QIPRL.DBH_05 :Total time taken to execute query  {} ", sClassName, sMethodName,
					tTime + " milliseconds");

			int numRowsFound = 0;
			if (alQueryResponse != null && !alQueryResponse.isEmpty()) {
				for (int j = 0; j < alQueryResponse.size(); j++) {
					Map hmQueryResponse = (Map) alQueryResponse.get(j);
					Iterator itr = hmQueryResponse.keySet().iterator();
					HashMap hmIpRateLimit = CommonUtil.getHashMap();
					while (itr.hasNext()) {
						String key = (String) itr.next();
						Object value = hmQueryResponse.get(key);
						String strValue = (value == null ? null : value.toString());
						hmIpRateLimit.put(key, strValue);
					}
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS);
					hmResult.put(CommonDefs.INP_RATE_LIMIT_INFO, hmIpRateLimit);
					++numRowsFound;
				}
			}
			if (numRowsFound == 0) {
				stAppInfo = "No row found";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo);
				logger.info("{}{}IQIPRL.DBH_06 error : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}QIPRL.DBH_07 :  Error::{}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}QIPRL.DBH_08 : Exception = {}", sClassName, sMethodName, e);
		} finally {
			logger.info("{}{}DBTOOLS999 : STATUS = {}", sClassName, sMethodName, hmResult);
		}

		return hmResult;

	}

	
	/**
	 * This method adds a new IP rate limit to the database.
	 * It takes a HashMap as input which contains key-value pairs for various IP rate limit attributes like IP address and last modified by.
	 * The method first checks if the input HashMap is null or if the required attributes are missing. If they are, it returns an error status.
	 * Then it retrieves the IP rate limit attributes from the input HashMap.
	 * If the IP rate limit attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param hmInput A HashMap containing the details of the IP rate limit's information to be added.
	 * @return A HashMap containing the status of the operation and the added IP rate limit's information.
	 */
	public HashMap addIPRateLimit(HashMap hmInput) {

		String sMethodName = ".addIPRateLimit.";
		HashMap<String, Object> hmResult = null;
		List<Object> objectList = new ArrayList<Object>();
		String stAppInfo = null;

		int rowCount;
		String addIPRateLimitSql = "INSERT INTO ipratelimit(" + "IP_INIT_DATE," + "IP_ADDRESS, " + "APP_CALLINGSYSID, "
				+ "TXN_COUNT, " + "LAST_MODIFIED_BY " + ") VALUES(" + "SYSDATE,?, ?, ?, ?)";

		logger.info("{}{}QIPRL.DBH_01. : CVS KEYWORDS: {}", sClassName, sMethodName, info);
		logger.info("{}{}DBTOOLS000 : addIPRateLimitSql : {}", sClassName, sMethodName,StructuredArguments.entries(hmInput));
		try {
			String stLastModifiedBy = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);
			String stIPAddress = (String) hmInput.get(MPSDefs.DB_IP_ADDRESS);
			if (stLastModifiedBy == null || stLastModifiedBy.trim().length() == 0 || stIPAddress == null
					|| stIPAddress.trim().length() == 0) {
				stAppInfo = "last_modified_by/ip_address is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM, stAppInfo);
				logger.info("{}{}AIPRL.DBH_03: {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			objectList.add(stIPAddress);
			objectList.add(stLastModifiedBy);
			objectList.add("1");
			objectList.add(stLastModifiedBy);
			logger.info("{}{}AIPRL.DBH_04 :Calling  addIPRateLimitSql method with input: {} ", sClassName, sMethodName,
					addIPRateLimitSql);
			long tTime = 0;
			Date dtStartDate = new Date();
			rowCount = jdbcTemplate.update(new String(addIPRateLimitSql),
					objectList.toArray(new Object[objectList.size()]));

			// Calculate the total time taken to insert rows in DB
			// to return time in milliseconds
			tTime = (System.currentTimeMillis() - dtStartDate.getTime());
			logger.info("{}{}AIPRL.DBH_05 :Total time taken to execute query {} milliseconds", sClassName, sMethodName,
					tTime);

			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
					"No of rows inserted:= " + rowCount);
			logger.info("{}{}AIPRL.DBH_06 : No of rows inserted = {}", sClassName, sMethodName, rowCount);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}AIPRL.DBH_07 :  Error::{}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}AIPRL.DBH_08 : Exception = {}", sClassName, sMethodName, e);

		} finally {
			logger.info("{}{}DBTOOLS999 : STATUS = {}", sClassName, sMethodName, hmResult);
		}

		return hmResult;
	}

	
	/**
	 * This method updates the IP rate limit in the database.
	 * It takes a HashMap as input which contains key-value pairs for various IP rate limit attributes like IP address and last modified by.
	 * The method first checks if the input HashMap is null or if the required attributes are missing. If they are, it returns an error status.
	 * Then it retrieves the IP rate limit attributes from the input HashMap.
	 * If the IP rate limit attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param hmInput A HashMap containing the details of the IP rate limit's information to be updated.
	 * @return A HashMap containing the status of the operation and the updated IP rate limit's information.
	 */
	public HashMap updateIPRateLimit(HashMap hmInput) {

		String sMethodName = ".updateIPRateLimit.";
		HashMap<String, Object> hmResult = null;
		List<Object> objectList = new ArrayList<Object>();
		String stAppInfo = null;
		int rowCount;
		String incrementTxnCountSql = "UPDATE ipratelimit SET TXN_COUNT = TXN_COUNT + 1 " + "WHERE IP_ADDRESS = ? "
				+ " AND LAST_MODIFIED_BY = ? " + "AND APP_CALLINGSYSID = ?";

		String resetTxnCountSql = "UPDATE ipratelimit SET TXN_COUNT = 1, " + "IP_INIT_DATE = SYSDATE "
				+ "WHERE IP_ADDRESS = ? " + " AND LAST_MODIFIED_BY = ? " + "AND APP_CALLINGSYSID = ?";

		logger.info("{}{}UIPRL.DBH_01. : CVS KEYWORDS: {}", sClassName, sMethodName, info);
		logger.info("{}{}DBTOOLS000 : updateIPRateLimit : {}", sClassName, sMethodName,StructuredArguments.entries(hmInput));
		try {

			String stLastModifiedBy = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);
			String stIPAddress = (String) hmInput.get(MPSDefs.DB_IP_ADDRESS);
			String stAction = (String) hmInput.get(CommonDefs.ACTION);

			if (stLastModifiedBy == null || stLastModifiedBy.trim().length() == 0 || stIPAddress == null
					|| stIPAddress.trim().length() == 0 || stAction == null || stAction.trim().length() == 0) {
				stAppInfo = "last_modified_by/ip_address/action is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM, stAppInfo);
				logger.info("{}{}UIPRL.DBH_03: {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			objectList.add(stIPAddress);
			objectList.add(stLastModifiedBy);
			objectList.add(stLastModifiedBy);

			long tTime = 0;
			Date dtStartDate = new Date();

			if (stAction.equals(CommonDefs.INCREMENT)) {
				logger.info("{}{}UIPRL.DBH_04 : incrementTxnCountSql: {} ", sClassName, sMethodName,
						incrementTxnCountSql);
				rowCount = jdbcTemplate.update(new String(incrementTxnCountSql),
						objectList.toArray(new Object[objectList.size()]));
				tTime = (System.currentTimeMillis() - dtStartDate.getTime());
				logger.info("{}{}UIPRL.DBH_05 :Total time taken to execute query {} milliseconds ", sClassName,
						sMethodName, tTime);
			} else if (stAction.equals(CommonDefs.RESET)) {
				logger.info("{}{}UIPRL.DBH_06 : resetTxnCountSql:{}", sClassName, sMethodName, resetTxnCountSql);
				rowCount = jdbcTemplate.update(new String(resetTxnCountSql),
						objectList.toArray(new Object[objectList.size()]));
				tTime = (System.currentTimeMillis() - dtStartDate.getTime());
				logger.info("{}{}UIPRL.DBH_07 :Total time taken to execute query {}  milliseconds ", sClassName,
						sMethodName, tTime);
			} else {
				stAppInfo = "action is not valid";
				logger.info("{}{}UIPRL.DBH_08 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}
			logger.info("{}{}UIPRL.DBH_09 : No of rows updated = {}", sClassName, sMethodName, rowCount);

			if (rowCount == 0) {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
						"No Record found for given ip_address or app_callingsysid");
			} else {
				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
						"No of records updated=" + rowCount);
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}UIPRL.DBH_10 :  Error::{}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}UIPRL.DBH_11 : Exception = {}", sClassName, sMethodName, e);

		} finally {
			logger.info("{}{}DBTOOLS999 : STATUS={}", sClassName, sMethodName, hmResult);
		}

		return hmResult;
	}

	
	/**
	 * This method deletes an IP rate limit from the database.
	 * It takes a HashMap as input which contains key-value pairs for various IP rate limit attributes like IP address and last modified by.
	 * The method first checks if the input HashMap is null or if the required attributes are missing. If they are, it returns an error status.
	 * Then it retrieves the IP rate limit attributes from the input HashMap.
	 * If the IP rate limit attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param hmInput A HashMap containing the details of the IP rate limit's information to be deleted.
	 * @return A HashMap containing the status of the operation and the deleted IP rate limit's information.
	 */
	public HashMap deleteIPRateLimit(HashMap hmInput) {

		String sMethodName = ".deleteIPRateLimit.";
		HashMap<String, Object> hmResult = null;
		List<Object> objectList = new ArrayList<Object>();

		String stAppInfo = null;

		String deleteIPRateLimitSql = "DELETE FROM ipratelimit WHERE IP_ADDRESS = ? " + "AND APP_CALLINGSYSID = ?";

		logger.info("{}{}DIPRL.DBH_01. : CVS KEYWORDS: {}", sClassName, sMethodName, info);
		logger.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName,hmInput!=null ? StringUtils.normalizeSpace(hmInput.toString()): null);

		Date dtStart = new Date();

		try {

			String stLastModifiedBy = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);
			String stIPAddress = (String) hmInput.get("ip_address");

			if (stLastModifiedBy == null || stLastModifiedBy.trim().length() == 0 || stIPAddress == null
					|| stIPAddress.trim().length() == 0) {
				stAppInfo = "last_modified_by/ip_address is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM, stAppInfo);
				logger.info("{}{}IPRL_024: {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			logger.info("{}{}DIPRL.DBH_03 : deleteIPRateLimitSql: {} ", sClassName, sMethodName, deleteIPRateLimitSql);

			objectList.add(stIPAddress);
			objectList.add(stLastModifiedBy);

			long tTime = 0;
			Date dtStartDate = new Date();

			int rowCount = jdbcTemplate.update(new String(deleteIPRateLimitSql),
					objectList.toArray(new Object[objectList.size()]));

			// Calculate the total time taken to execute the update
			// to return time in milliseconds
			tTime = (System.currentTimeMillis() - dtStartDate.getTime());
			logger.info("{}{}DIPRL.DBH_04 : Total time taken to execute query: {} milliseconds ", sClassName,
					sMethodName, tTime);

			logger.info("{}{}DIPRL.DBH_05 : No of rows deleted: {} ", sClassName, sMethodName, rowCount);

			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
					"No of rows deleted = " + rowCount);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}DIPRL.DBH_01 :  Error::{}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}DIPRL.DBH_01 : Exception = {}", sClassName, sMethodName, e);

		} finally {
			logger.info("{}{}DBTOOLS999 : STATUS={}", sClassName, sMethodName, hmResult);
		}
		return hmResult;
	}

}