package com.att.idp.idgraphusermanagementms.service;

import jakarta.ws.rs.core.MultivaluedMap;

import com.att.idp.idgraphusermanagementms.resource.request.MergeUserAccessIdRequest;
import com.att.idp.idgraphusermanagementms.resource.response.MergeUserAccessIdResponse;

/**
 * This interface defines the contract for the MergeUserAccessIdService in the system.
 * It contains a single method mergeUserAccessId which takes a MergeUserAccessIdRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return a MergeUserAccessIdResponse object.
 *
 * The MergeUserAccessIdRequest object encapsulates the details of the user access ID merge operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
public interface MergeUserAccessIdService {

	/**
	 * This method is part of the MergeUserAccessIdService interface.
	 * It defines the contract for merging user access IDs in the system.
	 *
	 * @param mergeUserAccessIdRequest An object encapsulating the details of the user access ID merge operation to be performed.
	 * @param requestHeader A MultivaluedMap containing the request headers which may include additional information required for processing the request.
	 * @return A MergeUserAccessIdResponse object representing the response from the system after merging the user access IDs.
	 */
	MergeUserAccessIdResponse mergeUserAccessId(MergeUserAccessIdRequest mergeUserAccessIdRequest,
												MultivaluedMap<String, String> requestHeader);

}
