package com.att.idp.idgraphusermanagementms.queue.message.helpers;

import com.att.idp.idgraphusermanagementms.helper.resetuserpassword.UserPasswordHelper;
import com.att.idp.idgraphusermanagementms.helper.voltage.ProofingEncryptionHelper;
import com.att.idp.idgraphusermanagementms.queue.message.sender.JMSQueueSender;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.mpsys.common.helpers.FeatureManagerHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.att.idp.idgraphusermanagementms.helper.LinkMemberHelper.AL_DBUS_EVENTS;

@Component
public class LinkMemberQueueHelper {

    public static final Logger log = LoggerFactory.getLogger(LinkMemberQueueHelper.class);
    private static final String sClassName = "LinkMemberQueueHelper";

    @Autowired
    private JMSQueueSender oJMSQueueSender;
    @Autowired
    private ProofingEncryptionHelper oProofingEncryptionHelper;
    @Autowired
    private UserPasswordHelper oUserPasswordHelper;

    private static final String IDGRAPH_USER_MANAGEMENT_MS = "IDGraphUserManagementMS-";
    private static final String LINK_MEMBER_EVENT_TYPE = ProfileOrchestrationConstants.LINK_MEMBER_TRANSACTION_NAME;

    @Autowired
    FeatureManagerHelper featureManager;

    @Autowired
    private PublishMqAehHelper publishMqAehHelper;

    private static final String KEY_USE_SLID_NUM = "useSlidNum";
    private static final String KEY_PROCESS_SLID = "processSlid";
    boolean bSlidMatchesMemberId = false;

    public Map<String, Object> sendMessageToMQ(Map<String, Object> hmInput, HashMap<String, Object> hmDbMember, HashMap<String, Object> hmDBSlidResponse) {
        String sMethodName = ".sendMessageToMQ.";
        Map<String, Object> hmResult = null;

        String sParentChildInd = null;
        String sSorName = null;
        String sCallingSystemId = null;
        String sTransactionName = null;
        String sOrigTransactionName = null;
        String sTransactionId = null;
        String sOrigTransactionId = null;


        final String LINK_MEMBER_AEH_FEATURE_KEY = "cfg-idgraph-linkmemberid-mq-aeh-switch";
        final String LINK_MEMBER_CLM_FEATURE_KEY = "cfg-idgraph-linkmemberid-notification-clm-switch";

        final String AEH = "AEH";
        final String MQ = "MQ";
        final String BOTH = "BOTH";

        try {
            sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
            sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
            sOrigTransactionName = (String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME);
            HashMap hmTempMemberUpdateAttributes = (HashMap) hmInput.get("hmTempMemberUpdateAttributes");
            ArrayList<Map<String, Object>> alDbusEvents = (ArrayList) hmInput.get(AL_DBUS_EVENTS);
            boolean bPasswordsMatched = Boolean.TRUE.equals(hmInput.get("passwordsMatched"));
            sTransactionId = (String) hmInput.get("dbusTransactionId");
            sOrigTransactionId = (String) hmInput.get("dbusTransactionId");

            HashMap<String, Object> hmDbSlidResp = (HashMap<String, Object>) hmDBSlidResponse.getOrDefault(CommonDefs.KEY_SLID_INFO, hmDBSlidResponse);

            String sCallDbus = (String) hmInput.get(CommonDefs.CALLDBUS);
            sParentChildInd = (String) hmDbMember.get(MPSDefs.DB_PARENT_CHILD_IND);
            sSorName = (String) hmDbMember.get(MPSDefs.DB_SOR_NAME);


            log.debug("LMQH.SMTMQ_01 : Building UpdateAliasList with inputHash : {}{}",
                    CommonUtilHelper.sanitizeForLog(StringUtils.normalizeSpace(hmDbSlidResp != null ? hmDbSlidResp.toString() : null)),
                    CommonUtilHelper.sanitizeForLog(StringUtils.normalizeSpace(hmDbMember != null ? hmDbMember.toString() : null)));
            HashMap<String, Object> hmUpdateBaseEvent = getBaseEventMap(sTransactionName, sOrigTransactionName, sOrigTransactionId, sTransactionId, sCallingSystemId, CommonDefs.UPDATE_ALIAS_LIST_EVENT);
            HashMap<String, Object> hmAddAliasLists = buildUpdateAliasListEvent(hmUpdateBaseEvent, hmDbSlidResp, hmDbMember);
            alDbusEvents.add(hmAddAliasLists);

            if(!"Y".equals(hmInput.get(CommonDefs.IGNORE_EDD_NOTIFICATION))) {
                log.debug("LMQH.SMTMQ_02 : Building buildEDDNotificationEvent with inputHash : {}{}{}",
                        CommonUtilHelper.sanitizeForLog(StringUtils.normalizeSpace(hmInput.toString())),
                        CommonUtilHelper.sanitizeForLog(StringUtils.normalizeSpace(hmDbMember != null ? hmDbMember.toString() : null)),
                        CommonUtilHelper.sanitizeForLog(StringUtils.normalizeSpace(hmDbSlidResp != null ? hmDbSlidResp.toString() : null)));

                HashMap<String, Object> hmNotificationBaseEvent = getBaseEventMap(sTransactionName, sOrigTransactionName, sOrigTransactionId, sTransactionId, sCallingSystemId, CommonDefs.PROP_EDD_NOTIFICATION_EVENT);
                HashMap<String, Object> hmBuildEDDNotificationEvent = buildEDDNotificationEvent(hmNotificationBaseEvent, hmInput, hmDbMember, hmDbSlidResp, sSorName, sParentChildInd);
                alDbusEvents.add(hmBuildEDDNotificationEvent);
            }
            if (MPSDefs.MPS_PARENT.equalsIgnoreCase(sParentChildInd) && MPSDefs.SOR_LS.equalsIgnoreCase(sSorName)) {
                log.debug("LMQH.SMTMQ_03 : Building buildUpdatePaymentProfileEvent : {}{}",
                        CommonUtilHelper.sanitizeForLog(StringUtils.normalizeSpace(hmDbSlidResp != null ? hmDbSlidResp.toString() : null)),
                        CommonUtilHelper.sanitizeForLog(StringUtils.normalizeSpace(hmDbMember != null ? hmDbMember.toString() : null)));

                HashMap<String, Object> hmUpdatePaymentBaseEvent = getBaseEventMap(sTransactionName, sOrigTransactionName, sOrigTransactionId, sTransactionId, sCallingSystemId, CommonDefs.CONTEXT_UpdatePaymentProfile);
                HashMap<String, Object> hmUpdatePaymentProfile = buildUpdatePaymentProfileEvent(hmUpdatePaymentBaseEvent, hmDbSlidResp, hmDbMember);

                alDbusEvents.add(hmUpdatePaymentProfile);
            }

            String sIgnoreProfileUpdate = (String) hmInput.get(CommonDefs.IGNORE_PROFILE_UPDATE);
            String sIgnoreEDDNotification = (String) hmInput.get("ignoreEDDNotification");
            HashMap<String, Object> hmDbParentData = (HashMap) hmDbMember.get(MPSDefs.MEM_PARENT_INFO_PARENT_KEY);

            if (!bPasswordsMatched && (sIgnoreProfileUpdate == null || CommonDefs.IND_N.equalsIgnoreCase(sIgnoreProfileUpdate))) {
                log.debug("LMQH.SMTMQ_04 : Building buildChangePasswordRequest : {}{}{}",
                        CommonUtilHelper.sanitizeForLog(StringUtils.normalizeSpace(hmInput != null ? hmInput.toString() : null)),
                        CommonUtilHelper.sanitizeForLog(StringUtils.normalizeSpace(hmTempMemberUpdateAttributes != null ? hmTempMemberUpdateAttributes.toString() : null)),
                        CommonUtilHelper.sanitizeForLog(StringUtils.normalizeSpace(sIgnoreEDDNotification)));
                HashMap<String, Object> hmChangePwdInput = buildChangePasswordRequest(hmInput, hmTempMemberUpdateAttributes, sIgnoreEDDNotification);

                log.debug("LMQH.SMTMQ_05 : Building buildDBusChangePasswordHash : {}{}{}",
                        CommonUtilHelper.sanitizeForLog(StringUtils.normalizeSpace(hmChangePwdInput != null ? hmChangePwdInput.toString() : null)),
                        CommonUtilHelper.sanitizeForLog(StringUtils.normalizeSpace(hmDbMember != null ? hmDbMember.toString() : null)),
                        CommonUtilHelper.sanitizeForLog(StringUtils.normalizeSpace(hmDbParentData != null ? hmDbParentData.toString() : null)));
                hmResult = oUserPasswordHelper.buildDBusChangePasswordHash(hmChangePwdInput, hmDbMember, hmDbParentData);

                String stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
                if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
                    String stAppInfo = "Error Response returned from oUserPasswordHelper.buildDBusChangePasswordHash";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                    log.info("LMQH.SMTMQ_06 : Response from buildDBusChangePasswordHash : {}",
                            CommonUtilHelper.sanitizeForLog(StringUtils.normalizeSpace(hmResult != null ? hmResult.toString() : null)));
                    return hmResult;
                }
                HashMap<String, Object> alChgPasswordEvents = (HashMap<String, Object>) hmResult.get("DBUSHASH");
                if (alChgPasswordEvents != null && !alChgPasswordEvents.isEmpty()) {
                    alDbusEvents.add(alChgPasswordEvents);
                }
            }

            HashMap hmDbusInput = CommonUtil.getHashMap();

            if (CommonDefs.IND_N.equals(sCallDbus)) {
                hmResult = CommonErrorMap.makeCommonStatusMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success");
                hmResult.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, alDbusEvents);
                return hmResult;
            } else {

                hmDbusInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
                hmDbusInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
                hmDbusInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
                hmDbusInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
                hmDbusInput.put(CommonDefs.EVENTNAME, ProfileOrchestrationConstants.MICROSERVICE_EVENT);
                hmDbusInput.put(CommonDefs.MS_OPERTAION, sTransactionName);

                String sMemberNum = (String) hmDbMember.get(MPSDefs.DB_MEMBER_NUM);

                if (sMemberNum != null && !sMemberNum.isEmpty()) {
                    hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, sMemberNum);
                }
                hmDbusInput.put(CommonDefs.EVENTS_DATA, alDbusEvents);

                //mq aeh switch
                String sLinkMemberMQAEHEnabled = featureManager.getValue(LINK_MEMBER_AEH_FEATURE_KEY);
                sLinkMemberMQAEHEnabled = (sLinkMemberMQAEHEnabled != null && !sLinkMemberMQAEHEnabled.isEmpty()) ? sLinkMemberMQAEHEnabled : MQ;
                log.info("{}{} ixp flag sLinkMemberMQAEHEnabled MQ AEH Value: {}", sClassName, sMethodName, sLinkMemberMQAEHEnabled);

                //clm switch
                String sLinkMemberClmEnabled = featureManager.getValue(LINK_MEMBER_CLM_FEATURE_KEY);
                sLinkMemberClmEnabled = (sLinkMemberClmEnabled != null && !sLinkMemberClmEnabled.isEmpty()) ? sLinkMemberClmEnabled : MQ;
                log.info("{}{} ixp flag sLinkMemberClmEnabled CLM Value: {}", sClassName,sMethodName, sLinkMemberClmEnabled);
                hmResult = publishMqAehHelper.invokeMqAEH(hmDbusInput, hmInput, alDbusEvents, sClassName, sMethodName, sLinkMemberMQAEHEnabled, sLinkMemberClmEnabled);

                String stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
                    String stAppInfo = hmResult.get(CErrorDefs.COMMON_APP_INFO) != null ? (String) hmResult.get(CErrorDefs.COMMON_APP_INFO) : "Error Response returned from oJMSQueueSender.send";
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
                    log.info("LMQH.SMTMQ_08 : Response from oJMSQueueSender,send : {}",
                            CommonUtilHelper.sanitizeForLog(stAppInfo));
                    return hmResult;
                }
            }
            return hmResult;
        } catch (Exception exc) {
            hmResult = CommonErrorMap.makeExceptionMap(exc);
            String stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
            log.error("LMQH.SMTMQ_09 : Response from oJMSQueueSender,send : {}", CommonUtilHelper.sanitizeForLog(stAppStatusCode));
            return hmResult;
        }
    }

    @NotNull
    private Map<String, Object> prepareAEHParams(Map<String, Object> hmInput, HashMap hmDbusInput, String sEventType) {
        Map<String, Object> hmDbusGenericInput = new HashMap<>(hmDbusInput);
        hmDbusGenericInput.put("msName", IDGRAPH_USER_MANAGEMENT_MS);
        hmDbusGenericInput.put("eventType",  sEventType);
        hmDbusGenericInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
        return hmDbusGenericInput;
    }


    private ArrayList getServiceInfo(HashMap<String, Object> hmDBServiceHash, String sServiceType, ArrayList alKeys) {
        HashMap<String, Object> hmServiceInfo = null;
        String stDbInstID = null;
        HashMap<String, Object> hmInstanceId = null;

        String stSorName = null;
        String stServiceStatusName = null;
        ArrayList alServices = CommonUtil.getArrayList();

        if (hmDBServiceHash != null && !hmDBServiceHash.isEmpty()) {
            stServiceStatusName = (String) hmDBServiceHash.get(MPSDefs.SERVICE_STATUS);
            for (String s : hmDBServiceHash.keySet()) {
                stDbInstID = s;
                Object objInstance = hmDBServiceHash.get(stDbInstID);
                if (objInstance instanceof HashMap) {
                    hmInstanceId = (HashMap) hmDBServiceHash.get(stDbInstID);

                    stSorName = (String) hmInstanceId.get(MPSDefs.DB_SOR_NAME);

                    hmServiceInfo = CommonUtil.getHashMap();
                    hmServiceInfo.put(MPSDefs.DB_SOR_INVARIANT_ID, hmInstanceId
                            .get(MPSDefs.DB_SOR_INVARIANT_ID));
                    hmServiceInfo.put(CommonDefs.INSTANCE_ID, stDbInstID);
                    hmServiceInfo.put(CommonDefs.MEMBER_STATUS, hmInstanceId.get(MPSDefs.DB_MEMBER_STATUS_NAME));
                    hmServiceInfo.put(CommonDefs.SOR_NAME, stSorName);
                    hmServiceInfo.put(CommonDefs.SOR_ID, hmInstanceId.get(MPSDefs.DB_SOR_ID));
                    hmServiceInfo.put(CommonDefs.SERVICE_STATUS, stServiceStatusName);
                    hmServiceInfo.put(CommonDefs.SERVICE_TYPE, sServiceType);
                    hmServiceInfo.put(CommonDefs.SERVICE_ID, hmInstanceId.get(MPSDefs.DB_SERVICE_ID));
                    hmServiceInfo.put(MPSDefs.DB_DEFAULT_ACCOUNT, hmInstanceId.get(MPSDefs.DB_DEFAULT_ACCOUNT));
                    hmServiceInfo.put(MPSDefs.DB_CPNI_IMPACTED, hmInstanceId.get(MPSDefs.DB_CPNI_IMPACTED));

                    hmServiceInfo.put(MPSDefs.DB_MOBDEV_SOR_INVARIANT_ID, hmInstanceId.get(MPSDefs.DB_MOBDEV_SOR_INVARIANT_ID));
                    hmServiceInfo.put(MPSDefs.DB_MOBDEV_MEMBER_NUM, hmInstanceId.get(MPSDefs.DB_MOBDEV_MEMBER_NUM));

                    if (alKeys != null && !alKeys.isEmpty()) {
                        for (Object alKey : alKeys) {
                            String sKey = (String) alKey;
                            hmServiceInfo.put(sKey, hmInstanceId.get(sKey));
                        }
                    }
                    alServices.add(hmServiceInfo);
                }
            }

            if (hmServiceInfo == null) {
                hmServiceInfo = CommonUtil.getHashMap();
                hmServiceInfo.put(CommonDefs.MEMBER_STATUS, hmDBServiceHash.get(MPSDefs.DB_MEMBER_STATUS_NAME));
                hmServiceInfo.put(CommonDefs.SOR_NAME, hmDBServiceHash.get(MPSDefs.DB_SOR_NAME));
                hmServiceInfo.put(CommonDefs.SERVICE_STATUS, hmDBServiceHash.get(MPSDefs.SERVICE_STATUS));
                if (!sServiceType.equalsIgnoreCase(MPSDefs.SWH_SERVICE))
                    sServiceType = (String) CommonDefs.SERVICE_VALUES.get(sServiceType);
                hmServiceInfo.put(CommonDefs.SERVICE_TYPE, sServiceType);
                alServices.add(hmServiceInfo);
            }
        }
        return alServices;
    }

    private HashMap<String, Object> buildUpdateAliasListEvent(HashMap<String, Object> hmBaseEvent, HashMap<String, Object> hmDbSlidResp, HashMap<String, Object> hmDbMember) {

        HashMap<String, Object> hmAddAliasList = new HashMap<>(hmBaseEvent);

        hmAddAliasList.put(CommonDefs.HANDLE, hmDbSlidResp.get(MPSDefs.DB_MEMBER_NAME));
        hmAddAliasList.put(CommonDefs.DOMAIN, hmDbSlidResp.get(MPSDefs.DB_DOMAIN_NAME));

        hmAddAliasList.put(CommonDefs.PARENT_HANDLE, hmDbSlidResp.get(MPSDefs.DB_PARENT_NAME));
        hmAddAliasList.put(CommonDefs.PARENT_DOMAIN, hmDbSlidResp.get(MPSDefs.DB_PARENT_DOMAIN));
        hmAddAliasList.put(MPSDefs.DB_SLID_MEMBER_NUM, hmDbSlidResp.get(MPSDefs.DB_MEMBER_NUM));

        HashMap hmAddAlias = CommonUtil.getHashMap();
        hmAddAlias.put(CommonDefs.HANDLE, hmDbMember.get(MPSDefs.DB_MEMBER_NAME));
        hmAddAlias.put(CommonDefs.DOMAIN, hmDbMember.get(MPSDefs.DB_DOMAIN_NAME));
        ArrayList alAddAlias = CommonUtil.getArrayList();
        alAddAlias.add(hmAddAlias);
        hmAddAliasList.put(CommonDefs.TGUARD_EVENT_ADD_ALIAS, alAddAlias);
        return hmAddAliasList;
    }

    @NotNull
    private static HashMap<String, Object> getBaseEventMap(String sTransactionName, String sOrigTransactionName, String sOrigTransactionId,
                                                           String sTransactionId, String sCallingSystemId, String sEventName) {

        HashMap<String, Object> hmAddAliasList = CommonUtil.getHashMap();

        hmAddAliasList.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
        hmAddAliasList.put(CommonDefs.ORIG_TRANSACTION_NAME, sOrigTransactionName);
        hmAddAliasList.put(CommonDefs.ORIG_TRANSID, sOrigTransactionId);
        hmAddAliasList.put(CommonDefs.TRANSACTION_ID, sTransactionId);
        hmAddAliasList.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
        hmAddAliasList.put(CommonDefs.EVENTNAME, sEventName);
        hmAddAliasList.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);

        return hmAddAliasList;
    }

    private HashMap<String, Object> buildEDDNotificationEvent(HashMap<String, Object> hmNotificationBaseEvent, Map<String, Object> hmInput,
                                                              HashMap hmDbMember, HashMap<String, Object> hmDbSlidResp, String sSorName, String sParentChildInd) {
//        HashMap<String, Object> hmEventData = CommonUtil.getHashMap();

        HashMap<String, Object> hmEventData = new HashMap<>( hmNotificationBaseEvent);

//        hmEventData.put(CommonDefs.EVENTNAME, CommonDefs.PROP_EDD_NOTIFICATION_EVENT);
        hmEventData.put(CommonDefs.HANDLE, hmDbMember.get(MPSDefs.DB_MEMBER_NAME));
        hmEventData.put(CommonDefs.DOMAIN, hmDbMember.get(MPSDefs.DB_DOMAIN_NAME));
        hmEventData.put(CommonDefs.PARENT_HANDLE, hmDbMember.get(MPSDefs.DB_PARENT_NAME));
        hmEventData.put(CommonDefs.PARENT_DOMAIN, hmDbMember.get(MPSDefs.DB_PARENT_DOMAIN));
        hmEventData.put(MPSDefs.DB_SLID_MEMBER_NUM, hmDbSlidResp.get(MPSDefs.DB_MEMBER_NUM));

        hmEventData.put(CommonDefs.SUBEVENT, CommonDefs.PROP_EDD_NOTIFICATION_SUBEVENT);
        hmEventData.put(CommonDefs.FIRST_NAME, hmDbSlidResp.get(MPSDefs.DB_LC_FIRSTNAME));
        hmEventData.put(CommonDefs.LAST_NAME, hmDbSlidResp.get(MPSDefs.DB_LC_LASTNAME));
        hmEventData.put(CommonDefs.DB_MEMBER_NUM, hmDbMember.get(MPSDefs.DB_MEMBER_NUM));
        hmEventData.put(CommonDefs.BROWSER_LANGUAGE, hmDbMember.get(MPSDefs.DB_BROWSER_LANGUAGE));
        hmEventData.put(CommonDefs.CUSTOMER_TYPE, hmDbMember.get(MPSDefs.DB_ACCOUNT_TYPE));
        hmEventData.put(KEY_USE_SLID_NUM, CommonDefs.IND_Y);

        String stAutoGenInd = (String) hmDbSlidResp.get(MPSDefs.DB_AUTOGENERATED_IND);
        if (stAutoGenInd != null && !stAutoGenInd.isEmpty()) {
            hmEventData.put(CommonDefs.AUTO_GENERATED_IND, stAutoGenInd);
        }
        hmEventData.put(CommonDefs.SOR_NAME, sSorName);
        hmEventData.put(CommonDefs.DB_PARENT_CHILD_IND, sParentChildInd);
        hmEventData.put(CommonDefs.SLID, hmDbSlidResp.get(MPSDefs.DB_MEMBER_NAME));


        handleNotificationData(hmInput, hmDbMember, hmDbSlidResp,hmEventData, sSorName, sParentChildInd);
        return hmEventData;
    }

    private void handleNotificationData(Map<String, Object> hmInput, HashMap<String, Object> hmDbMember, HashMap<String, Object> hmDbSlidResp,HashMap<String, Object> hmEventData, String sSorName, String sParentChildInd) {
        ArrayList alNotificationData = CommonUtil.getArrayList();
        String sDbusBan = (String) hmDbMember.get(MPSDefs.DB_BAN);
        if (MPSDefs.MPS_PARENT.equalsIgnoreCase(sParentChildInd) &&
                MPSDefs.SOR_LS.equalsIgnoreCase(sSorName) &&
                sDbusBan != null && !sDbusBan.trim().isEmpty()) {
            hmEventData.put(CommonDefs.BAN, sDbusBan);
            hmEventData.put(CommonDefs.KEY_ACCOUNT_ID, sDbusBan);
        }

        String sIgnoreEDDNotification = (String) hmInput.get("ignoreEDDNotification");
        if (!bSlidMatchesMemberId && (!CommonDefs.IND_Y.equalsIgnoreCase(sIgnoreEDDNotification))) {
            String sAccessName = (String) hmDbMember.get(MPSDefs.DB_ACCESS_NAME);
            HashMap<String, Object> hmNotificationInput = CommonUtil.getHashMap();

            if (MPSDefs.MPS_PARENT.equalsIgnoreCase(sParentChildInd) && MPSDefs.SOR_LS.equalsIgnoreCase(sSorName) &&
                    sAccessName != null && !"A".equals(sAccessName)) {
                hmNotificationInput.put(CommonDefs.LS_PRIMARY_LINKED_TO_SLID, CommonDefs.IND_Y);
                alNotificationData.add(hmNotificationInput);
            } else {
                ArrayList<HashMap<String, Object>> alMemberContactEmails = CommonUtil.getArrayList();
                hmNotificationInput.put(CommonDefs.LS_PRIMARY_LINKED_TO_SLID, CommonDefs.IND_N);

                String contactEmail = (String) hmDbSlidResp.get(MPSDefs.DB_CONTACT_EMAIL);
                if (contactEmail != null && !contactEmail.trim().isEmpty()) {
                    HashMap<String, Object> hmMemberContactEmail = CommonUtil.getHashMap();
                    hmMemberContactEmail.put(CommonDefs.CONTACT_EMAIL, contactEmail);
                    hmMemberContactEmail.put(CommonDefs.CONTACT_EMAIL_STATUS, hmDbSlidResp.get(MPSDefs.DB_CONTACT_EMAIL_STATUS));
                    alMemberContactEmails.add(hmMemberContactEmail);
                    hmNotificationInput.put(CommonDefs.MEMBER_CONTACT_EMAIL, alMemberContactEmails);
                    alNotificationData.add(hmNotificationInput);
                }

                HashMap<String, Object> hmSlidServices = (HashMap<String, Object>) hmDbSlidResp.get(MPSDefs.SERVICES);
                if (hmSlidServices != null && !hmSlidServices.isEmpty()) {
                    handleSlidServices(hmSlidServices, hmEventData);
                }
            }

            if (!alNotificationData.isEmpty()) {
                hmEventData.put(CommonDefs.NOTIFICATION_DATA, alNotificationData);
            }

        }
    }
    private void handleSlidServices(HashMap<String, Object> hmSlidServices, HashMap<String, Object> hmEventData) {
        String sMethodName = ".handleSlidServices.";
        HashMap<String, Object> hmDefaultAccount = null;
        if(hmSlidServices != null && !hmSlidServices.isEmpty()) {
            for (Map.Entry<String, Object> entry : hmSlidServices.entrySet()) {
                String sdbServiceKeyName = entry.getKey();
                HashMap<String, Object> hmDbService = (HashMap<String, Object>) entry.getValue();

                ArrayList<HashMap<String, Object>> alInstanceFormatServices = getServiceInfo(hmDbService, sdbServiceKeyName, null); // return arraylist
                for (HashMap<String, Object> service : alInstanceFormatServices) {
                    String sDefaultAccount = (String) service.get(MPSDefs.DB_DEFAULT_ACCOUNT);
                    if (sDefaultAccount != null && sDefaultAccount.equals(CommonDefs.IND_Y)) {
                        log.info("LMQH.SMTMQ_10 : Response from oJMSQueueSender,send : {}", CommonUtilHelper.sanitizeForLog(StringUtils.normalizeSpace(sDefaultAccount)));
                        hmDefaultAccount = service;
                        break;
                    }
                }
            }
        }

        if (hmDefaultAccount != null && !hmDefaultAccount.isEmpty()) {
            hmEventData.put(CommonDefs.ACCOUNT_SOR, hmDefaultAccount.get(CommonDefs.SOR_NAME));
            hmEventData.put(CommonDefs.SERVICE_TYPE, hmDefaultAccount.get(CommonDefs.SERVICE_TYPE));
            String sSorInvariantId = (String) hmDefaultAccount.get(MPSDefs.DB_SOR_INVARIANT_ID);
            String sServiceType = (String) hmDefaultAccount.get(CommonDefs.SERVICE_TYPE);

            if (CommonDefs.MOSUB_SERVICE.equalsIgnoreCase(sServiceType) && sSorInvariantId != null) {
                HashMap<String, Object> hmDecryptInput = CommonUtil.getHashMap();
                hmDecryptInput.put(CommonDefs.SOR_INVARIANT_ID, sSorInvariantId);
                try {
                    HashMap<String, Object> hmResult = oProofingEncryptionHelper.getDecryptedValues(hmDecryptInput);
                    sSorInvariantId = (String) hmResult.get(CommonDefs.SOR_INVARIANT_ID);
                } catch (Exception exc) {
                    HashMap<String, Object> hmResult = CommonErrorMap.makeExceptionMap(exc);
                    String stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                    log.error("LMQH.SMTMQ_11 : Error:: {}", CommonUtilHelper.sanitizeForLog(StringUtils.normalizeSpace(exc.getMessage())));
                    log.error("LMQH.SMTMQ_12: Exception = {}", CommonUtilHelper.sanitizeForLog(StringUtils.normalizeSpace(stAppStatusCode)));
                    return;
                }
            }
            hmEventData.put(CommonDefs.SOR_INVARIANT_ID, sSorInvariantId);
        }
    }
    private HashMap<String, Object> buildUpdatePaymentProfileEvent(HashMap<String, Object> hmUpdatePaymentBaseEvent, HashMap<String, Object> hmDbSlidResp, HashMap<String, Object> hmDbMember) {

//        HashMap<String, Object> hmUpdatePaymentProfile = CommonUtil.getHashMap();
        HashMap<String, Object> hmUpdatePaymentProfile = new HashMap<>(hmUpdatePaymentBaseEvent);

//        hmUpdatePaymentProfile.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
//        hmUpdatePaymentProfile.put(CommonDefs.ORIG_TRANSACTION_NAME, sOrigTransactionName);
//        hmUpdatePaymentProfile.put(CommonDefs.ORIG_TRANSID, sOrigTransactionId);
//        hmUpdatePaymentProfile.put(CommonDefs.TRANSACTION_ID, sTransactionId);
//        hmUpdatePaymentProfile.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
//        hmUpdatePaymentProfile.put(CommonDefs.EVENTNAME, CommonDefs.CONTEXT_UpdatePaymentProfile);
//        hmUpdatePaymentProfile.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);

        hmUpdatePaymentProfile.put(CommonDefs.HANDLE, hmDbSlidResp.get(MPSDefs.DB_MEMBER_NAME));
        hmUpdatePaymentProfile.put(CommonDefs.DOMAIN, hmDbSlidResp.get(MPSDefs.DB_DOMAIN_NAME));
        hmUpdatePaymentProfile.put(CommonDefs.PARENT_HANDLE, hmDbSlidResp.get(MPSDefs.DB_PARENT_NAME));
        hmUpdatePaymentProfile.put(CommonDefs.PARENT_DOMAIN, hmDbSlidResp.get(MPSDefs.DB_PARENT_DOMAIN));
        hmUpdatePaymentProfile.put(CommonDefs.SLID_MEMBER_NUM, hmDbSlidResp.get(MPSDefs.DB_MEMBER_NUM));
        hmUpdatePaymentProfile.put(CommonDefs.LEGACY_MEMBER_NUM, hmDbMember.get(MPSDefs.DB_MEMBER_NUM));
        hmUpdatePaymentProfile.put(CommonDefs.SUBEVENT, "MergeProfile");

        return hmUpdatePaymentProfile;
    }

    private HashMap buildChangePasswordRequest(Map<String, Object> hmInput, HashMap<String, Object> hmTempMemberUpdateAttributes, String sIgnoreEDDNotification) {
        HashMap<String, Object> hmChangePwdInput = new HashMap<>(hmInput);
        hmChangePwdInput.put(KEY_PROCESS_SLID, CommonDefs.IND_N);
        hmChangePwdInput.remove(CommonDefs.SLID_PASSWORD);
        hmChangePwdInput.remove(CommonDefs.PASSWORD);
        hmChangePwdInput.put(MPSDefs.DB_SHA1_PASSWORD, hmTempMemberUpdateAttributes.get(MPSDefs.DB_SHA1_PASSWORD));
        hmChangePwdInput.put(MPSDefs.DB_DES3_PASSWORD, hmTempMemberUpdateAttributes.get(MPSDefs.DB_DES3_PASSWORD));
        hmChangePwdInput.put(MPSDefs.DB_ENC_PASSWORD, hmTempMemberUpdateAttributes.get(MPSDefs.DB_ENC_PASSWORD));
        hmChangePwdInput.put(MPSDefs.DB_MD5_PASSWORD, hmTempMemberUpdateAttributes.get(MPSDefs.DB_MD5_PASSWORD));

        if (hmTempMemberUpdateAttributes.get(MPSDefs.DB_GEN_PASSWORD) != null && !((String) hmTempMemberUpdateAttributes.get(MPSDefs.DB_GEN_PASSWORD)).isEmpty()) {
            hmChangePwdInput.put(MPSDefs.DB_GEN_PASSWORD, hmTempMemberUpdateAttributes.get(MPSDefs.DB_GEN_PASSWORD));
            hmChangePwdInput.put(MPSDefs.DB_GEN_PASSWORD_TYPE, hmTempMemberUpdateAttributes.get(MPSDefs.DB_GEN_PASSWORD_TYPE));
        }
        if (sIgnoreEDDNotification != null && sIgnoreEDDNotification.trim().equals(CommonDefs.IND_Y)) {
            hmChangePwdInput.put("ignoreEDDNotification", sIgnoreEDDNotification);
        }
        return hmChangePwdInput;
    }
}