package com.att.idp.idgraphusermanagementms.db.helper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;

@Component
public class HealthCheckDBHelper {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private ErrorMetricHandler errorMetricHandler;

    private static final Logger logger = LoggerFactory.getLogger(HealthCheckDBHelper.class);

    public boolean dbHealthCheck() {
        boolean isDatabaseUp = false;
        try {
            String selectStatement = "SELECT 1 FROM DUAL";
            Integer queryResponse = jdbcTemplate.queryForObject(selectStatement, Integer.class);
            if (queryResponse != null && queryResponse == 1) {
                logger.debug("Performing scheduled db health check - Database is UP");
                isDatabaseUp = true;
            }
        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            logger.error("DB Health Check failed", e);
        }
        return isDatabaseUp;
    }

}