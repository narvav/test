package com.att.idp.idgraphusermanagementms.resource;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import com.att.idp.idgraphusermanagementms.resource.response.RegistrationOrchestrationResponse;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.web.bind.annotation.RequestBody;

import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.resource.request.RegistrationOrchestrationRequest;

import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * This is an interface named RegistrationOrchestrationResource.
 * It is annotated with @Tag(name = "orchestration") to provide metadata for Swagger.
 * It is also annotated with @Path("/orchestration") to set the path for the entire interface.
 * The interface contains the registration method that consolidates mergeUserAccessId and addAssociation
 * calls into a single orchestration endpoint for the IDMREG application.
 */
@Tag(name = "orchestration")
@Path("/orchestration")
@Produces({ MediaType.APPLICATION_JSON })
public interface RegistrationOrchestrationResource {

    /**
     * This method is responsible for processing registration orchestration requests.
     * It accepts a targetAccessId and a list of associations (BANs, Individuals)
     * and internally calls mergeUserAccessId or addAssociation for each item in parallel.
     *
     * @param request The RegistrationOrchestrationRequest containing the details of the operation.
     * @param httpHeader The HttpHeaders providing HTTP header information.
     * @return Response The response of the registration orchestration operation.
     * @throws MPSException If any error occurs during the operation.
     */
    @POST
    @Path("/registration")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(summary = "Registration Orchestration",
            description = "Consolidates mergeUserAccessId and addAssociation calls into a single orchestration endpoint for manual registration",
            parameters = {
                    @Parameter(name = "X-ATT-ClientId", description = "Consumer application identifier. Must be IDMREG.", required = true, in = ParameterIn.HEADER),
                    @Parameter(name = "idp-trace-id", description = "Trace ID for the request", required = true, in = ParameterIn.HEADER)
            })
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "All associations processed successfully",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = RegistrationOrchestrationResponse.class))),
            @ApiResponse(responseCode = "207", description = "Partial success — some associations succeeded, some failed",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = RegistrationOrchestrationResponse.class))),
            @ApiResponse(responseCode = "400", description = "Validation failure or all associations failed",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = RegistrationOrchestrationResponse.class))),
            @ApiResponse(responseCode = "500", description = "Unknown exception in application")
    })
    Response registration(@RequestBody RegistrationOrchestrationRequest request,
                          @Context HttpHeaders httpHeader) throws MPSException;
}
