package com.att.idp.idgraphusermanagementms.db.request;

import java.io.Serializable;
import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * This is the MemberAuxRequest class which implements Serializable interface.
 * It represents a request for a member with properties like memberNum, encPasswordVenc, md5PasswordVenc, sha1PasswordVenc, des3PasswordVenc, sshaPasswordVenc, securityAnswer1Venc, securityAnswer2Venc, createDate, lastModifiedPw, lastModifiedSec, recentFraudPwDate, passwordVenc, passwordType, and lastModifiedBy.
 * Each property has its respective getter and setter methods.
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({ "memberNum",
		"encPasswordVenc",
		"md5PasswordVenc",
		"sha1PasswordVenc",
		"des3PasswordVenc",
		"sshaPasswordVenc",
		"securityAnswer1Venc",
		"securityAnswer2Venc",
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MemberAuxRequest implements Serializable{

	private static final long serialVersionUID = -7367019281137385647L;

	private Long memberNum;
	private String encPasswordVenc;
	private String md5PasswordVenc;
	private String sha1PasswordVenc;
	private String des3PasswordVenc;
	private String sshaPasswordVenc;
	private String securityAnswer1Venc;
	private String securityAnswer2Venc;
	private Date createDate;
	private Date lastModifiedPw;
	private Date lastModifiedSec;
	private Date recentFraudPwDate;
	private String passwordVenc;
	private String passwordType;
	private String lastModifiedBy;
}