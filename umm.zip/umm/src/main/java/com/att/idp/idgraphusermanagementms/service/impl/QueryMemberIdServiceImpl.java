package com.att.idp.idgraphusermanagementms.service.impl;

import com.att.idp.core.exception.ServiceException;
import com.att.idp.idgraphusermanagementms.helper.QueryMemberIdHelper;
import com.att.idp.idgraphusermanagementms.message.ErrorMessages;
import com.att.idp.idgraphusermanagementms.resource.response.MemberIdResponse;
import com.att.idp.idgraphusermanagementms.service.QueryMemberIdService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.*;
import jakarta.ws.rs.core.MultivaluedMap;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.HashMap;

@Service
public class QueryMemberIdServiceImpl implements QueryMemberIdService {

    private static final Logger logger = LoggerFactory.getLogger(QueryMemberIdServiceImpl.class);

    @Autowired
    private QueryMemberIdHelper queryMemberIdHelper;

    private static final String CLASS_NAME = ".QueryMemberIdServiceImpl";

    /**
     * Queries the member ID based on the provided request headers.
     *
     * @param requestHeader MultivaluedMap containing request headers
     * @return MemberIdResponse containing the result of the query
     * @throws Exception if an unexpected error occurs during processing
     */
    @Override
    public MemberIdResponse queryMemberId(MultivaluedMap<String, String> requestHeader, String stRequestTraceId) throws Exception {

        String sMethodName = ".queryMemberId";
        MemberIdResponse memberIdResponse = null;
        String stAppInfo="Calling Helper with memberId: " +requestHeader.getFirst(CommonDefs.MEMBERID) + "and domain: " + requestHeader.getFirst(CommonDefs.DOMAIN)
                + " and guid: " + requestHeader.getFirst(CommonDefs.GUID) + " and secMemberIds: " + requestHeader.getFirst("secMemberIds");
        logger.info("{}{}QMID01: {}", CLASS_NAME, sMethodName, stAppInfo);

        try {
            memberIdResponse = queryMemberIdHelper.queryMemberIdResponse(requestHeader.getFirst(CommonDefs.MEMBERID), requestHeader.getFirst(CommonDefs.DOMAIN),
                    requestHeader.getFirst(CommonDefs.GUID), requestHeader.getFirst("secMemberIds").toUpperCase(), requestHeader.getFirst(CommonDefs.BAN));
            if (memberIdResponse != null) {
                return CommonUtilHelper.memberIdSuccessResponse(memberIdResponse,stRequestTraceId);
            }else{
                stAppInfo = "No Response received";
                logger.info("{}{}QMID02: {}", CLASS_NAME, sMethodName, stAppInfo);
                throw new ServiceException(ErrorMessages.MS_MPSYS_BE_602, stAppInfo);
            }
        }catch(ServiceException e) {
            stAppInfo = "ServiceException thrown from queryMemberIdHelper with error message: "+ e.getError().getMessage();
            logger.error("{}{}QMID03: {}", CLASS_NAME, sMethodName, stAppInfo);
            throw e;
        }catch (Exception e) {
            HashMap<String, Object> hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
            hmResponse.put("idp-trace-id", stRequestTraceId);
            memberIdResponse =  CommonUtilHelper.generateMemberIdResponse(hmResponse);
        }
        return memberIdResponse;
    }
}
