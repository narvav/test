package com.att.idp.idgraphusermanagementms.service.impl;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.UpdatePrepaidUserPasswordHelper;
import com.att.idp.idgraphusermanagementms.resource.request.UpdatePrepaidUserPasswordRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdatePrepaidUserPasswordResponse;
import com.att.idp.idgraphusermanagementms.service.UpdatePrepaidUserPasswordService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;
import net.logstash.logback.argument.StructuredArguments;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.ws.rs.core.MultivaluedMap;
import java.util.Map;

/**
 * This class is part of the com.att.idp.idgraphuserprofilems.service.impl package.
 * It implements the UpdatePrepaidUserPasswordService interface.
 * The class is used to update prepaid user password about user profiles.
 * It contains a method updatePrepaidUserPassword which takes an UpdatePrepaidUserPasswordRequest object and a MultivaluedMap of request headers as parameters.
 * The method returns an UpdatePrepaidUserPasswordResponse object.
 */
@Service
@Transactional(readOnly = true, value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class UpdatePrepaidUserPasswordServiceImpl implements UpdatePrepaidUserPasswordService {
	public static final Logger logger = LoggerFactory.getLogger(UpdatePrepaidUserPasswordServiceImpl.class);

	@Autowired
	private UpdatePrepaidUserPasswordHelper updatePrepaidUserPasswordHelper;

	private static String sClassName = "UpdatePrepaidUserPasswordServiceImpl";


	/**
	 * Updates the prepaid user password.
	 *
	 * @param updatePrepaidUserPasswordRequest the request object containing user details and new password
	 * @param requestHeader the headers of the request
	 * @return UpdatePrepaidUserPasswordResponse the response object containing the status of the update operation
	 */
	@Override
	public UpdatePrepaidUserPasswordResponse updatePrepaidUserPassword(UpdatePrepaidUserPasswordRequest updatePrepaidUserPasswordRequest,
																	   MultivaluedMap<String, String> requestHeader) {

		UpdatePrepaidUserPasswordResponse updatePrepaidUserPasswordResponse = null;

		Map<String, Object> hmInput = null;
		Map<String, Object> hmResponse = null;
		String sMethodName = ".updatePrepaidUserPassword.";

		// Calling updatePrepaidUserPassword HashMap
		hmInput = CommonUtilHelper.objectToMap(updatePrepaidUserPasswordRequest);
		hmInput.put("handle", hmInput.remove("userId"));

		logger.info(SpiMarker.getInstance(),
				"UpdatePrepaidUserPasswordHelper.updatePrepaidUserPassword.UPUPSI.UPUP.02 : Response from updatePrepaidUserPassword : {}",
				StructuredArguments.entries(hmInput));

		hmResponse = updatePrepaidUserPasswordHelper.updatePrepaidUserPassword(hmInput);

		hmResponse=CommonUtilHelper.processHmResponse(hmResponse, hmInput, "UpdatePrepaidUserPasswordHelper", ".updatePrepaidUserPassword");
		hmResponse.put("idp-trace-id", updatePrepaidUserPasswordRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME, "UpdatePrepaidUserPassword");
		updatePrepaidUserPasswordResponse = CommonUtilHelper.generateUpdatePrepaidUserPasswordResponse(hmResponse);

		String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

		if (sTxnRollBack != null) {
			throw new InvalidInputDataException(hmResponse);
		}

		logger.info("{}{}UPUPSI.UPUP.05 : Response from UpdatePrepaidUserPasswordServiceImpl.updatePrepaidUserPassword : {}", sClassName, sMethodName,
				updatePrepaidUserPasswordResponse);
		return updatePrepaidUserPasswordResponse;
	}
}
