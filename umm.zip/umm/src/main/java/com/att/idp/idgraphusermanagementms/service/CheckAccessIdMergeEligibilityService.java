package com.att.idp.idgraphusermanagementms.service;

import jakarta.ws.rs.core.MultivaluedMap;

import com.att.idp.idgraphusermanagementms.resource.request.CheckAccessIdMergeEligibilityRequest;
import com.att.idp.idgraphusermanagementms.resource.response.CheckAccessIdMergeEligibilityResponse;

/**
 * This interface defines the contract for the CheckAccessIdMergeEligibilityService in the system.
 * It contains a single method checkAccessIdMergeEligibility which takes a CheckAccessIdMergeEligibilityRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return a CheckAccessIdMergeEligibilityResponse object.
 *
 * The CheckAccessIdMergeEligibilityRequest object encapsulates the details of the access ID merge eligibility check to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
public interface CheckAccessIdMergeEligibilityService {

	/**
	 * This method is part of the CheckAccessIdMergeEligibilityService interface.
	 * It defines the contract for checking the eligibility of an access ID for merging in the system.
	 *
	 * @param checkAccessIdMergeEligibilityRequest An object encapsulating the details of the access ID merge eligibility check to be performed.
	 * @param requestHeader A MultivaluedMap containing the request headers which may include additional information required for processing the request.
	 * @return A CheckAccessIdMergeEligibilityResponse object representing the response from the system after checking the access ID merge eligibility.
	 */
	CheckAccessIdMergeEligibilityResponse checkAccessIdMergeEligibility(CheckAccessIdMergeEligibilityRequest checkAccessIdMergeEligibilityRequest,
															 			MultivaluedMap<String, String> requestHeader);
}