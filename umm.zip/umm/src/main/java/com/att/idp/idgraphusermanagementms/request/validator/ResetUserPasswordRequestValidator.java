package com.att.idp.idgraphusermanagementms.request.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;

import jakarta.ws.rs.core.HttpHeaders;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphusermanagementms.resource.request.DeliveryMethods;
import com.att.idp.idgraphusermanagementms.resource.request.Letter;
import com.att.idp.idgraphusermanagementms.resource.request.ResetUserPasswordRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ResetUserPasswordResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;

/**
 * This class, ResetUserPasswordRequestValidator, is responsible for validating
 * the ResetUserPasswordRequest. It checks for the presence and validity of
 * required fields in the request, and returns an ResetUserPasswordResponse
 * accordingly. It is annotated with @Component, @Configuration,
 * and @PropertySource to indicate that it's a Spring Bean, to allow it to
 * access configuration properties, and to specify the location of the
 * properties file respectively.
 *
 * The class contains several methods, including: -
 * resetUserPasswordRequestValidator: the main method that orchestrates the
 * validation process. - resetUserPasswordErrorResponse: a helper method that
 * generates an error response. - resetUserPasswordRequestCSIValidator: a method
 * that validates the Calling System ID (CSI) in the request. -
 * resetUserPasswordRequestInputValidator: a method that validates the input
 * fields in the request. - resetUserPasswordIsExternalCallCheck: a method that
 * checks the 'isExternalCall' field in the request. -
 * resetUserPasswordRequiredFieldCheck: a method that checks for the presence of
 * required fields in the request.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class ResetUserPasswordRequestValidator {

	private static final Logger logger = LoggerFactory.getLogger(ResetUserPasswordRequestValidator.class);

	private String sClassName = "ResetUserPasswordRequestValidator";

	@Value("${PROP_RESET_USER_PASSWORD_CSI}")
	private String stValidCallers;

	@Value("${PROP_RESET_USER_PASSWORD_AGENT_CSI}")
	private String stAgentCsi;

	@Value("${RUP_RETURN_PWD_CALLER}")
	private String stReturnPwdCallers;



	/**
	 * This method is responsible for validating the ResetUserPasswordRequest. It
	 * takes HttpHeaders and a ResetUserPasswordRequest as input parameters and
	 * returns a ResetUserPasswordResponse. The method performs various checks on
	 * the input parameters and calls other private methods for further validation.
	 * If the validation is successful, the method returns a
	 * ResetUserPasswordResponse. If the validation fails, the method constructs an
	 * error response and returns it.
	 *
	 * The method also handles exceptions that can occur during the validation
	 * process.
	 *
	 * @param requestHeader            HttpHeaders that contains the request
	 *                                 headers. These headers are used for logging
	 *                                 and tracing purposes.
	 * @param resetUserPwdRequest The request object containing the parameters
	 *                                 for the ResetUserPassword operation.
	 * @return ResetUserPasswordResponse The response object containing the result
	 *         of the validation
	 */
	public ResetUserPasswordResponse resetUserPasswordRequestValidator(HttpHeaders requestHeader,
			ResetUserPasswordRequest resetUserPwdRequest) {

		ResetUserPasswordResponse resetUserPwdResponse = null;

		String stAppInfo = null;
		String sMethodName = ".resetUserPasswordRequestValidator.";
		String stIdpTraceId = null;
		String stXAttClientId = null;

		stIdpTraceId = CommonUtil.getTraceId(requestHeader);
		if (stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
			stAppInfo = "Missing or Invalid IdpTraceId";
			return resetUserPwdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (resetUserPwdRequest == null) {
			stAppInfo = "Input Request Parameter is NULL / Empty.";
			logger.info("{}{}RUPRV_102 :: {}", sClassName, sMethodName, stAppInfo);
			return resetUserPwdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		resetUserPwdRequest.setIdpTraceId(stIdpTraceId);

		if (requestHeader.getHeaderString("X-ATT-ClientId") != null) {
			stXAttClientId = requestHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
			logger.info("{}{}RUPRV_101.2 : Setting callingSystemId: {}", sClassName, sMethodName,
					StringUtils.normalizeSpace(stXAttClientId));
			resetUserPwdRequest.setCallingSystemId(stXAttClientId);
		} else {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			logger.info("{}{}RUPRV_101.3 :: {}", sClassName, sMethodName, stAppInfo);
			return resetUserPwdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		ResetUserPasswordResponse letterValidationResponse = validateLetterFields(resetUserPwdRequest, stIdpTraceId);
		if (letterValidationResponse != null) {
			return letterValidationResponse;
		}

		// checking Invalid attributes passed in Request
		Map<String, Object> allUnknownAttributes = new HashMap<>(resetUserPwdRequest.unknownAttributes);
		if(resetUserPwdRequest.getDeliveryMethods()!=null) {
			DeliveryMethods deliveryMethods = resetUserPwdRequest.getDeliveryMethods();
			allUnknownAttributes.putAll(deliveryMethods.unknownAttributes);
			
			if (deliveryMethods.getEmail() != null) {
	            allUnknownAttributes.putAll(deliveryMethods.getEmail().unknownAttributes);
	        }
	        if (deliveryMethods.getSms() != null) {
	            allUnknownAttributes.putAll(deliveryMethods.getSms().unknownAttributes);
	        }
	        if (deliveryMethods.getAo() != null) {
	            allUnknownAttributes.putAll(deliveryMethods.getAo().unknownAttributes);
	        }
	        if (deliveryMethods.getLetter() != null) {
	            allUnknownAttributes.putAll(deliveryMethods.getLetter().unknownAttributes);
	        }

		}

		if (!allUnknownAttributes.isEmpty()) {
			stAppInfo = "Invalid Attributes passed in ResetUserPasswordRequest : " + allUnknownAttributes;
			return resetUserPwdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					resetUserPwdRequest.getIdpTraceId());
		}

		try {
			resetUserPwdResponse = resetUserPwdReqInputValidator(resetUserPwdRequest);
			if (resetUserPwdResponse != null) {
				logger.info("{}{}RUPRV_103 Response from resetUserPwdReqInputValidator : {}", sClassName, sMethodName,
						resetUserPwdResponse);
				return resetUserPwdResponse;
			} else {
				logger.debug("{}{}RUPRV_104 Success Response from resetUserPwdReqInputValidator ", sClassName,
						sMethodName);
			}
			resetUserPwdResponse = resetUserPwdReqCSIValidator(resetUserPwdRequest);
			if (resetUserPwdResponse != null) {
				logger.info("{}{}RUPRV_105 Response from resetUserPwdReqCSIValidator : {}", sClassName, sMethodName,
						resetUserPwdResponse);
				return resetUserPwdResponse;
			} else {
				logger.debug("{}{}RUPRV_106 Success Response from resetUserPwdReqCSIValidator ", sClassName,
						sMethodName);
			}
			stAppInfo = "Input Validation Successful";
			logger.info("{}{}RUPRV_107 : {}", sClassName, sMethodName, stAppInfo);

		} catch (Exception e) {
			stAppInfo = "Exception thrown in ResetUserPasswordRequestValidator.resetUserPasswordRequestValidator : "
					+ e.getMessage();
			resetUserPwdResponse = resetUserPwdErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo, stIdpTraceId);
			logger.info("Exception in resetUserPasswordRequestValidator: {}", stAppInfo);
		}

		return resetUserPwdResponse;
	}

	/**
	 * This method validates the Calling System ID (CSI) in the request.
	 * It checks if the calling system ID is valid and if the agent ID is required.
	 *
	 * @param resetUserPwdRequest The request object containing the parameters for the ResetUserPassword operation.
	 * @return ResetUserPasswordResponse The response object containing the result of the validation.
	 */
	private ResetUserPasswordResponse resetUserPwdReqCSIValidator(ResetUserPasswordRequest resetUserPwdRequest) {

		String sMethodName = ".resetUserPwdReqCSIValidator.";
		String sIsExternalCall = resetUserPwdRequest.getIsExternalCall();
		String stCallingSystemId = resetUserPwdRequest.getCallingSystemId();
		String stIdpTraceId = resetUserPwdRequest.getIdpTraceId();
		String stAgentId = resetUserPwdRequest.getAgentId();
		DeliveryMethods deliveryMethod = resetUserPwdRequest.getDeliveryMethods();
		String stAppInfo = null;
		ResetUserPasswordResponse resetuserPwdResponse = null;

		ArrayList alResetUserPwdCallingSystemIds = null;

		alResetUserPwdCallingSystemIds = CommonUtil.parseToArray(stValidCallers, CommonDefs.VALUE_SEPARATOR_CHAR);

		logger.debug("{}{}RUPRV_CSI.01 :  Property PROP_RESET_USER_PASSWORD_CSI : {}", sClassName, sMethodName,
				alResetUserPwdCallingSystemIds);

		if (alResetUserPwdCallingSystemIds != null && !alResetUserPwdCallingSystemIds.contains(stCallingSystemId)
				&& sIsExternalCall != null && CommonDefs.IND_Y.equals(sIsExternalCall)) {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			return resetUserPwdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		ArrayList alAgentCsi = CommonUtil.parseToArray(stAgentCsi, CommonDefs.VALUE_SEPARATOR_CHAR);
		logger.debug("{}{}RUPRV_CSI.02 :  PROP_RESET_USER_PASSWORD_AGENT_CSI : {}", sClassName, sMethodName,
				alAgentCsi);

		if (alAgentCsi != null && !alAgentCsi.isEmpty()) {
			if (alAgentCsi.contains(stCallingSystemId)) {
				if (stAgentId == null || stAgentId.isEmpty()) {
					stAppInfo = "agentId is required for the caller";
					return resetUserPwdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
				}
			}
		}
		
		ArrayList<String> alReturnPwdCallers = CommonUtil.parseToArray(stReturnPwdCallers,
				CommonDefs.VALUE_SEPARATOR_CHAR);
		logger.debug("{}{}RUPRV_RV.01 :  RUP_RETURN_PWD_CALLER : {}", sClassName, sMethodName, alReturnPwdCallers);

		if (alReturnPwdCallers != null && !alReturnPwdCallers.isEmpty()) {
			if (!alReturnPwdCallers.contains(stCallingSystemId) && deliveryMethod == null) {
				stAppInfo = "deliveryMethods should be passed in input";
				return resetUserPwdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
		}

		return resetuserPwdResponse;
	}

	/**
	 * This method validates the input fields in the request.
	 * It checks for the presence and validity of required fields in the request.
	 *
	 * @param resetUserPwdRequest The request object containing the parameters for the ResetUserPassword operation.
	 * @return ResetUserPasswordResponse The response object containing the result of the validation.
	 */
	private ResetUserPasswordResponse resetUserPwdReqInputValidator(ResetUserPasswordRequest resetUserPwdRequest) {

		String sMethodName = ".resetUserPwdReqInputValidator.";
		String stAppInfo = null;
		ResetUserPasswordResponse resetUserPwdResponse = null;

		String stCallingSystemId = resetUserPwdRequest.getCallingSystemId();
		String stTransactionName = resetUserPwdRequest.getTransactionName();
		String stHandle = resetUserPwdRequest.getHandle();
		String stDomain = resetUserPwdRequest.getDomain();
		String stIsExternalCall = resetUserPwdRequest.getIsExternalCall();
		String stClearOnlineQA = resetUserPwdRequest.getClearOnlineQA();
		String stAgentId = resetUserPwdRequest.getAgentId();
		String stIdpTraceId = resetUserPwdRequest.getIdpTraceId();
		String stSuppressNotification = resetUserPwdRequest.getSuppressNotification();
		DeliveryMethods deliveryMethod = resetUserPwdRequest.getDeliveryMethods();

		resetUserPwdResponse = resetUserPwdExternalCallCheck(resetUserPwdRequest);
		if (resetUserPwdResponse != null) {
			return resetUserPwdResponse;
		}

		Optional.ofNullable(stCallingSystemId)
				.ifPresent(x -> resetUserPwdRequest.setCallingSystemId(x.trim().toUpperCase()));

		Optional.ofNullable(stHandle).ifPresent(x -> resetUserPwdRequest.setHandle(x.trim().toLowerCase()));
		Optional.ofNullable(stDomain).ifPresent(x -> resetUserPwdRequest.setDomain(x.trim().toLowerCase()));

		if ((stHandle == null || stHandle.isEmpty() || stDomain == null || stDomain.isEmpty())) {
			stAppInfo = "userId and domain is required in input";
			return resetUserPwdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		// Restricting ghost IDs from resetting the password
		if (stHandle != null && stHandle.trim().length() != 0) {

			if (stHandle.trim().toLowerCase().startsWith("sbciptv_")) {
				stAppInfo = "Ghost Ids are not allowed to reset the password";
				return resetUserPwdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
		}

		// Letter field validation is already handled by validateLetterFields() (CDEX-516066 / CDEX-516970)

		Optional.ofNullable(stClearOnlineQA)
				.ifPresent(x -> resetUserPwdRequest.setClearOnlineQA(x.trim().toUpperCase()));
		if (stClearOnlineQA != null && !(CommonDefs.IND_Y.equalsIgnoreCase(stClearOnlineQA)
				|| CommonDefs.IND_N.equalsIgnoreCase(stClearOnlineQA))) {
			stAppInfo = "ClearOnlineQA value should be Y or N";
			return resetUserPwdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		return resetUserPwdResponse;
	}


	/**
	 * This method checks the 'isExternalCall' field in the request.
	 * It validates if the 'isExternalCall' field is either 'Y' or 'N'.
	 *
	 * @param resetUserPwdRequest The request object containing the parameters for the ResetUserPassword operation.
	 * @return ResetUserPasswordResponse The response object containing the result of the validation.
	 */
	private ResetUserPasswordResponse resetUserPwdExternalCallCheck(ResetUserPasswordRequest resetUserPwdRequest) {
		ResetUserPasswordResponse resetuserPwdResponse = null;
		String stAppInfo;
		String isExternalCall = resetUserPwdRequest.getIsExternalCall();
		String stIdpTraceId = resetUserPwdRequest.getIdpTraceId();

		if ((isExternalCall != null && !isExternalCall.isEmpty())) {
			if (!(isExternalCall.equalsIgnoreCase(CommonDefs.IND_Y)
					|| isExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
				stAppInfo = "isExternalCall must be one of Y or N";
				return resetUserPwdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			} else {
				resetUserPwdRequest.setIsExternalCall(isExternalCall.trim().toUpperCase());
			}
		} else {
			resetUserPwdRequest.setIsExternalCall(CommonDefs.IND_Y);
		}
		return resetuserPwdResponse;
	}

	/**
	 * This method generates an error response for the ResetUserPasswordRequest.
	 * It constructs an error response with the given application status code, application info, and trace ID.
	 *
	 * @param appStatusCode The application status code indicating the type of error.
	 * @param stAppInfo The application info containing the error message.
	 * @param stIdpTraceId The trace ID for logging and tracing purposes.
	 * @return ResetUserPasswordResponse The response object containing the error details.
	 */
	private ResetUserPasswordResponse resetUserPwdErrorResponse(int appStatusCode, String stAppInfo,
			String stIdpTraceId) {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		return CommonUtilHelper.generateResetUserPasswordResponse(hmResponse);
	}

	// Pattern to detect raw or HTML-encoded script injection characters (CDEX-516066 / CDEX-516970)
	private static final Pattern DANGEROUS_CHARS_PATTERN = Pattern.compile("(?i)(<|>|&lt;|&gt;)");

	private ResetUserPasswordResponse validateLetterFields(ResetUserPasswordRequest request, String traceId) {
		DeliveryMethods deliveryMethods = request.getDeliveryMethods();
		if (deliveryMethods == null || deliveryMethods.getLetter() == null) {
			return null;
		}

		Letter letter = deliveryMethods.getLetter();
		if (containsInvalidCharacters(letter.getFirstName())
				|| containsInvalidCharacters(letter.getLastName())
				|| containsInvalidCharacters(letter.getStreet1())
				|| containsInvalidCharacters(letter.getStreet2())
				|| containsInvalidCharacters(letter.getCity())
				|| !isNumericOnly(letter.getZipCode())
				|| !isNumericOnly(letter.getZipPlusFour())) {
			return resetUserPwdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM,
					"Invalid chars are passed in the request", traceId);
		}
		return null;
	}

	private boolean containsInvalidCharacters(String value) {
		if (value == null) {
			return false;
		}
		return DANGEROUS_CHARS_PATTERN.matcher(value).find();
	}

	private boolean isNumericOnly(String value) {
		if (value == null) {
			return true;
		}
		return value.matches("^[0-9]*$");
	}
}
