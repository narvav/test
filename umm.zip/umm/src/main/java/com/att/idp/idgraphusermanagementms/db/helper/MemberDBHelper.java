package com.att.idp.idgraphusermanagementms.db.helper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.mpsys.common.utils.*;
import net.logstash.logback.argument.StructuredArguments;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.common.validators.ServiceRoleValidation;
import com.att.idp.idgraphusermanagementms.helper.voltage.ProcessVoltageHelper;
import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;

/**
 * This class is responsible for managing member data in the database.
 * It uses Spring's JdbcTemplate for database operations.
 *
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like JdbcTemplate and other helper classes.
 *
 * The class contains methods for processing and updating member data in the database.
 *
 * The main methods in this class are:
 * - processData: This method processes the member data. It takes a HashMap as input and returns a HashMap as output.
 *   The input HashMap contains key-value pairs for various member attributes like calling system id, transaction name, last modified by, and member operations.
 *   The method first checks if the jdbcTemplate is null. If it is, it returns an error status.
 *   Then it retrieves the member attributes from the input HashMap.
 *   If the member attributes are not found, it returns an error status.
 *   Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
 *   Finally, it returns a status indicating whether the operation was successful or not.
 *
 * - update: This method updates the member data in the database. It takes a HashMap as input and returns a HashMap as output.
 *   The input HashMap contains key-value pairs for various member attributes like member number, member name, domain id, sor id, parent child indicator, migration indicator, and other attributes.
 *   The method first checks if the jdbcTemplate is null. If it is, it returns an error status.
 *   Then it retrieves the member attributes from the input HashMap.
 *   If the member attributes are not found, it returns an error status.
 *   Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
 *   Finally, it returns a status indicating whether the operation was successful or not.
 */
@Component
public class MemberDBHelper {

	private static final String INFO = "$Id: master/com/att/idp/idgraphusermanagementms/db/helper/MemberDBHelper.java v3 2022-06-28 mc288e $;";
	private static final String CLASS_NAME = "MemberDBHelper";
	public static final Logger log = LoggerFactory.getLogger(MemberDBHelper.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private ProcessVoltageHelper oProcessVoltageHelper;

	@Autowired
	private DBHelper oDBHelper;

	@Autowired
	private RolesDBHelper oRolesDBHelper;

	@Autowired
	private ServiceRoleValidation oServiceRoleValidation;

	@Autowired
	private UpdateDBHelper oUpdateDBHelper;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	/**
	 * This method processes the member data.
	 * It takes a HashMap as input which contains key-value pairs for various member attributes like calling system id, transaction name, last modified by, and member operations.
	 * The method first checks if the jdbcTemplate is null. If it is, it returns an error status.
	 * Then it retrieves the member attributes from the input HashMap.
	 * If the member attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param hmInput A HashMap containing the details of the member's information to be processed.
	 * @return A HashMap containing the status of the operation and the processed member's information.
	 */
	public HashMap<String,Object> processData(HashMap hmInput) {
		String sMethodName = ".processData.";
		HashMap hmResult = null;
		String stAppInfo = null;
		String sAppStatusCode = null;

		log.info("{}{}DBTOOLS01 : CVS KEYWORDS: {}", CLASS_NAME, sMethodName, INFO);
		log.info("{}{}DBTOOLS000 : Input Hash is: {}", CLASS_NAME, sMethodName,
				(hmInput != null ? StringUtils.normalizeSpace(hmInput.toString()) : "null"));

		if (hmInput == null || hmInput.isEmpty() ) {
			stAppInfo = ProfileOrchestrationConstants.INPUT_HASH_IS_NULL;
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			log.info("{}{} LMH_LM.100.01 : {}", CLASS_NAME, sMethodName, stAppInfo);
			return hmResult;
		}

		try {
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
			String sLastModifiedBy = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);
			ArrayList alMemberOperations = (ArrayList) hmInput.get(MPSDefs.DB_MEMBER_TABLE);
			// Iterate through member list to update each member attribute
			int rowsUpdated = 0;
			for (int i = 0; i < alMemberOperations.size(); i++) {
				HashMap hmMemberOperation = (HashMap) alMemberOperations.get(i);
				if (hmMemberOperation != null && !hmMemberOperation.isEmpty()) {
					if (sCallingSystemId != null && sCallingSystemId.length() > 0)
						hmMemberOperation.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);
					else if (sLastModifiedBy != null && sLastModifiedBy.length() > 0)
						hmMemberOperation.put(MPSDefs.DB_LAST_MODIFIED_BY, sLastModifiedBy);

					String sOperationType = (String) hmMemberOperation.get(MPSDefs.DB_OPERATION);
					// Only update operation is supported for June 2010
					if (sOperationType.equalsIgnoreCase(MPSDefs.DB_OPERATION_UPDATE)) {
						// 2016 SID44581
						if (sTransactionName != null && sTransactionName.length() > 0)
							hmMemberOperation.put(CommonDefs.TRANSACTION_NAME, sTransactionName);

						// Call local method to update one servicecontact at a time
						hmResult = update(hmMemberOperation);

					}

					//1904: Update to handle Terminated/Suspended memberIds
					else if (sOperationType.contains("insertWhenMemberDelete")) {
						if (sTransactionName != null && !sTransactionName.isEmpty())
							hmMemberOperation.put(CommonDefs.TRANSACTION_NAME, sTransactionName);

						hmResult = insertWhenMemberDelete(hmMemberOperation);
					}

					sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
					if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
						return hmResult;
					}
				} else {
					hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM,
							"member operation hash is empty in input");
					return hmResult;
				}

				rowsUpdated = rowsUpdated + 1;
			} //end of for loop


			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
					"Number of rows updated := " + rowsUpdated);
			hmResult.put(CommonDefs.COMMON_APP_INFO, "Number of rows updated := " + rowsUpdated);


		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DBTOOLS_E1 : Error::{}", CLASS_NAME, sMethodName, e.getMessage());
			log.error("{}{}DBTOOLS_E2 : Exception = {}", CLASS_NAME, sMethodName, e);
		} finally {
			log.info("{}{}DBTOOLS999 : processData response : {}", CLASS_NAME, sMethodName, hmResult);
		}
		return hmResult;
	}

	/**
	 * This method updates the member data in the database.
	 * It takes a HashMap as input which contains key-value pairs for various member attributes like member number, member name, domain id, sor id, parent child indicator, migration indicator, and other attributes.
	 * The method first checks if the input HashMap is null. If it is, it returns an error status.
	 * Then it retrieves the member attributes from the input HashMap.
	 * If the member attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param hmDbInput A HashMap containing the details of the member's information to be updated.
	 * @return A HashMap containing the status of the operation and the updated member's information.
	 */
	public HashMap<String,Object> update(HashMap hmDbInput) {
		String sMethodName = ".update.";

		HashMap hmResult = null;
		List<Object> objectList = CommonUtil.getArrayList();
		String sAppStatusCode = null;
		String sAppInfo = null;

		Date dtStartDate = new Date();

		log.info("{}{}DBTOOLS_01 : Input Hash is: {}", CLASS_NAME, sMethodName, hmDbInput);

		String sMemNumVal = null;
		String whereClause = null;
		String columnNames = "";

		StringBuilder query = new StringBuilder(" UPDATE MEMBER ");

		java.util.List argsKeys = new ArrayList();
		java.util.List argsVals = new ArrayList();
		java.util.List keys = new ArrayList();

		if (hmDbInput == null) {
			return hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_EMPTY_NUM, "Input hash is empty");
		}

		// 1612 Voltage Encrypt SPI Fields in MEMBER Table
		hmResult = oProcessVoltageHelper.voltageEncryptSPIFields(hmDbInput);

		if (hmResult == null) {
			sAppInfo = "Null response from ProcessVoltageHelper.voltageEncryptSPIFields() call.";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
			log.info("{}{}DBTOOLS_02.1 : {}", CLASS_NAME, sMethodName, sAppInfo);
			return hmResult;
		}

		sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

		if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
			sAppInfo = "ProcessVoltageHelper.voltageEncryptSPIFields() call failed.";
			hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(sAppStatusCode), sAppInfo);
			log.info("{}{}DBTOOLS_02.2 : {}", CLASS_NAME, sMethodName, sAppInfo);
			return hmResult;
		}
		// 1612 END

		query.append(" SET ");
		log.info("{}{}DBTOOLS_03 : Query ={}", CLASS_NAME, sMethodName, query);

		try {
			// If input has DB_SECURITY_QUESTION and not DB_SECURITY_QUESTION_ID
			int securityQuestionId = -1;
			// Check for the security_question in the request
			if (hmDbInput.containsKey(MPSDefs.DB_SECURITY_QUESTION)) {
				if (hmDbInput.containsKey(MPSDefs.DB_SECURITY_QUESTION_ID)) {
					hmDbInput.remove(MPSDefs.DB_SECURITY_QUESTION);
				} else {
					// get security_question_id
					String securityQuestion = (String) hmDbInput.get(MPSDefs.DB_SECURITY_QUESTION);
					securityQuestionId = oDBHelper.getSecurityQuestionId(securityQuestion);

					log.info("{}{}DBTOOLS_04 : security_question_id ={}", CLASS_NAME, sMethodName, securityQuestionId);

					if (securityQuestionId == -1) {
						sAppInfo = "Cannot find security_question_id for the given security_question= "
								+ securityQuestion;
						hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, sAppInfo);
						log.info("{}{}DBTOOLS_05 : {}", CLASS_NAME, sMethodName, sAppInfo);
						return hmResult;
					}
				}
			}

			int securityQuestionId1 = -1;
			// Check for the security_question_1 in the request
			if (hmDbInput.containsKey(MPSDefs.DB_SECURITY_QUESTION_1)) {
				if (hmDbInput.containsKey(MPSDefs.DB_SECURITY_QUESTION_ID_1)) {
					hmDbInput.remove(MPSDefs.DB_SECURITY_QUESTION_1);
				} else {
					// get security_question_id_1
					String securityQuestion1 = (String) hmDbInput.get(MPSDefs.DB_SECURITY_QUESTION_1);
					securityQuestionId1 = oDBHelper.getSecurityQuestionId(securityQuestion1);

					log.info("{}{}DBTOOLS_06 : security_question_id_1 ={}", CLASS_NAME, sMethodName, securityQuestionId1);

					if (securityQuestionId1 == -1) {
						sAppInfo = "Cannot find security_question_id_1 for the given security_question_1 = "
								+ securityQuestion1;
						hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, sAppInfo);
						log.info("{}{}DBTOOLS_07 : {}", CLASS_NAME, sMethodName, sAppInfo);
						return hmResult;
					}
				}
			}

			int securityQuestionId2 = -1;
			// Check for the security_question_2 in the request
			if (hmDbInput.containsKey(MPSDefs.DB_SECURITY_QUESTION_2)) {
				if (hmDbInput.containsKey(MPSDefs.DB_SECURITY_QUESTION_ID_2)) {
					hmDbInput.remove(MPSDefs.DB_SECURITY_QUESTION_2);
				} else {
					// get security_question_id_2
					String securityQuestion2 = (String) hmDbInput.get(MPSDefs.DB_SECURITY_QUESTION_2);
					securityQuestionId2 = oDBHelper.getSecurityQuestionId(securityQuestion2);

					log.info("{}{}DBTOOLS_08 : security_question_id_2 ={}", CLASS_NAME, sMethodName, securityQuestionId2);

					if (securityQuestionId2 == -1) {
						sAppInfo = "Cannot find security_question_id_2 for the given security_question_2 ="
								+ securityQuestion2;
						hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, sAppInfo);
						log.info("{}{}DBTOOLS_09 : {}", CLASS_NAME, sMethodName, sAppInfo);
						return hmResult;
					}
				}
			}

			// 1510 : EPIC PID 266956b CTN Alias for Fraud
			if (!hmDbInput.containsKey(MPSDefs.DB_ONL_QA_EST_DATE)) {
				if (hmDbInput.containsKey(MPSDefs.DB_SECURITY_ANSWER_1)
						|| hmDbInput.containsKey(MPSDefs.DB_SECURITY_ANSWER_2)) {
					hmDbInput.put(MPSDefs.DB_ONL_QA_EST_DATE, "");
				}
			}

			if (hmDbInput.containsKey(MPSDefs.DB_ACTIVATED_IND)) {
				String sActivatedIndFlag = (String) hmDbInput.get(MPSDefs.DB_ACTIVATED_IND);
				if (sActivatedIndFlag != null && sActivatedIndFlag.equalsIgnoreCase("Y")) {
					Date dtTodayDate = new Date();
					DateFormat dateFormat = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
					String stTodayDate = dateFormat.format(dtTodayDate);

					hmDbInput.put(MPSDefs.DB_ACTIVATED_DATE, stTodayDate);
				} else {
					hmDbInput.remove(MPSDefs.DB_ACTIVATED_DATE);
				}
			}

			if (hmDbInput.containsKey(MPSDefs.DB_CBR_OPT_OUT)) {
				String sCbrOptOut = (String) hmDbInput.get(MPSDefs.DB_CBR_OPT_OUT);
				if (sCbrOptOut != null && sCbrOptOut.equalsIgnoreCase(MPSDefs.YES)) {
					Date dtTodayDate = new Date();
					DateFormat dateFormat = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
					String sStartDate = dateFormat.format(dtTodayDate);

					hmDbInput.put(MPSDefs.DB_CBR_OPT_OUT, sStartDate);
				} else {
					hmDbInput.remove(MPSDefs.DB_CBR_OPT_OUT);
				}
			}

			if (hmDbInput.containsKey(MPSDefs.DB_MAIN_CTN_OPT_OUT)) {
				String sMainCTNOptOutFlag = (String) hmDbInput.get(MPSDefs.DB_MAIN_CTN_OPT_OUT);
				if (sMainCTNOptOutFlag != null && sMainCTNOptOutFlag.equalsIgnoreCase("Y")) {
					Date dtTodayDate = new Date();
					DateFormat dateFormat = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
					String stTodayDate = dateFormat.format(dtTodayDate);

					hmDbInput.put(MPSDefs.DB_MAIN_CTN_OPT_OUT, stTodayDate);
				} else {
					hmDbInput.remove(MPSDefs.DB_MAIN_CTN_OPT_OUT);
				}
			}

			if (hmDbInput.containsKey(CommonDefs.DB_ACCESS_ID_RTV_DATE)) {
				String sAccessRTVFlag = (String) hmDbInput.get(CommonDefs.DB_ACCESS_ID_RTV_DATE);
				if (sAccessRTVFlag != null && sAccessRTVFlag.equalsIgnoreCase("N")) {

					hmDbInput.put(CommonDefs.DB_ACCESS_ID_RTV_DATE, null);
				}
			}

			if (hmDbInput.containsKey(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE)) {
				String sContactEmailRTVFlag = (String) hmDbInput.get(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE);
				if (sContactEmailRTVFlag != null && sContactEmailRTVFlag.equalsIgnoreCase("N")) {

					hmDbInput.put(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE, null);
				}
			}

			if (hmDbInput.containsKey(MPSDefs.DB_LAST_VERIFIED)) {
				String sLastVerifiedFlag = (String) hmDbInput.get(MPSDefs.DB_LAST_VERIFIED);
				if (sLastVerifiedFlag != null && sLastVerifiedFlag.equalsIgnoreCase("Y")) {
					Date dtTodayDate = new Date();
					DateFormat dateFormat = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
					String stTodayDate = dateFormat.format(dtTodayDate);

					hmDbInput.put(MPSDefs.DB_LAST_VERIFIED, stTodayDate);
				} else {
					hmDbInput.remove(MPSDefs.DB_LAST_VERIFIED);
				}
			}

			// added below declarations as part of APRIL-2011 CAST analysis changes
			// to avoid instantiations inside loops
			SimpleDateFormat sdf = null;
			String sKey = null;
			String key = null; // Cast Fixes - 1106 Release
			String sTransactionName = null; // 2016.07 SID44581

			Iterator it = hmDbInput.keySet().iterator();
			while (it.hasNext()) {
				key = (String) it.next();

				if (key.equalsIgnoreCase(MPSDefs.DB_MEMBER_NUM)) {
					sMemNumVal = (String) hmDbInput.get(key);
					log.info("{}{}DBTOOLS_10 : member_num :{}", CLASS_NAME, sMethodName,
							HtmlUtils.htmlEscape(String.valueOf(sMemNumVal)));
				} else {
					sTransactionName = (String) hmDbInput.get(CommonDefs.TRANSACTION_NAME); // 2016.07 SID44581
					if (memberCheckKey(key) || ((sTransactionName != null && sTransactionName.equals("GenericDataFix"))
							&& (key.equalsIgnoreCase(MPSDefs.DB_ACCESS_ID) || key.equalsIgnoreCase(MPSDefs.DB_SOR_ID)
							|| key.equalsIgnoreCase(MPSDefs.DB_BAN)))) // 2016.07 SID44581
					// 1711 - Updated to include nullifying of BAN via GenericDataFix API
					{
						if (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION)) {
							argsKeys.add(MPSDefs.DB_SECURITY_QUESTION_ID + " = ?");
							argsVals.add("" + securityQuestionId);
							// changing the key as we have to set security_question_id ie., retrieved above
							keys.add(MPSDefs.DB_SECURITY_QUESTION_ID);
						} else if (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_1)) {
							argsKeys.add(MPSDefs.DB_SECURITY_QUESTION_ID_1 + " = ?");
							argsVals.add("" + securityQuestionId1);
							keys.add(MPSDefs.DB_SECURITY_QUESTION_ID_1);
						} else if (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_2)) {
							argsKeys.add(MPSDefs.DB_SECURITY_QUESTION_ID_2 + " = ?");
							argsVals.add("" + securityQuestionId2);
							keys.add(MPSDefs.DB_SECURITY_QUESTION_ID_2);
						} else if (key.equalsIgnoreCase(MPSDefs.DB_CONTACT_EMAIL_EST_DATE)) {
							sdf = getSimpleDateFormat("MMddyyyy HH:mm:ss");
							String sConEmailEstDate = (String) hmDbInput.get(key);
							if (sConEmailEstDate != null && sConEmailEstDate.trim().length() > 0) {
								argsVals.add(sConEmailEstDate);
							} else {
								String sSysDate = sdf.format(dtStartDate);
								argsVals.add(sSysDate);
							}

							argsKeys.add(MPSDefs.DB_CONTACT_EMAIL_EST_DATE + " = ?");
							keys.add(MPSDefs.DB_CONTACT_EMAIL_EST_DATE);
						} else if (key.equalsIgnoreCase(MPSDefs.DB_ONL_QA_EST_DATE)) {
							sdf = getSimpleDateFormat("MMddyyyy HH:mm:ss");
							String sOnlQAEstDate = (String) hmDbInput.get(MPSDefs.DB_ONL_QA_EST_DATE);
							if (sOnlQAEstDate != null && sOnlQAEstDate.trim().length() > 0) {
								argsVals.add(sOnlQAEstDate);
							} else {
								String sSysDate = sdf.format(dtStartDate);
								argsVals.add(sSysDate);
							}

							argsKeys.add(MPSDefs.DB_ONL_QA_EST_DATE + " = ?");
							keys.add(MPSDefs.DB_ONL_QA_EST_DATE);
						} else if (key.equalsIgnoreCase(MPSDefs.DB_MIGRATION_DATE)) { // Added for 1610 - PID 288753 IAM
							// Support Target Biller
							sdf = getSimpleDateFormat("MMddyyyy HH:mm:ss");
							String sMigrationDate = (String) hmDbInput.get(MPSDefs.DB_MIGRATION_DATE);
							if (sMigrationDate != null && sMigrationDate.trim().length() > 0) {
								argsVals.add(sMigrationDate);
							} else {
								String sSysDate = sdf.format(dtStartDate);
								argsVals.add(sSysDate);
							}

							argsKeys.add(MPSDefs.DB_MIGRATION_DATE + " = ?");
							keys.add(MPSDefs.DB_MIGRATION_DATE);
						} else if (key.equalsIgnoreCase(CommonDefs.DB_ACCESS_ID_RTV_DATE)) {
							sdf = getSimpleDateFormat("MMddyyyy HH:mm:ss");
							String sAccessIdRTVDate = (String) hmDbInput.get(CommonDefs.DB_ACCESS_ID_RTV_DATE);
							if (sAccessIdRTVDate == null) {
								argsVals.add(sAccessIdRTVDate);
							} else {
								String sSysDate = sdf.format(dtStartDate);
								argsVals.add(sSysDate);
							}
							argsKeys.add(CommonDefs.DB_ACCESS_ID_RTV_DATE + " = ?");
							keys.add(CommonDefs.DB_ACCESS_ID_RTV_DATE);
						} else if (key.equalsIgnoreCase(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE)) {
							sdf = getSimpleDateFormat("MMddyyyy HH:mm:ss");
							String sContactEmailRTVFlag = (String) hmDbInput.get(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE);
							if (sContactEmailRTVFlag == null) {
								argsVals.add(sContactEmailRTVFlag);
							} else {
								String sSysDate = sdf.format(dtStartDate);
								argsVals.add(sSysDate);
							}
							argsKeys.add(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE + " = ?");
							keys.add(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE);
						} else {
							argsKeys.add(key + " = ?");
							argsVals.add((String) hmDbInput.get(key));
							keys.add(key);
						}
					}
				}
			} // end of while

			int len = argsKeys.size();
			int i;

			for (i = 0; i < len; i++) {
				query.append(argsKeys.get(i));

				if (i != (len - 1)) {
					query.append(" , ");
				}
			}

			if (sMemNumVal != null && sMemNumVal.trim().length() > 0) {
				whereClause = "member_num =? ";
				query.append(" WHERE " + whereClause);
				log.info("{}{}DBTOOLS_11 : Query ={}", CLASS_NAME, sMethodName, query);
			} else {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM,
						"member_num is null or empty in input");
				return hmResult;
			}

			i = 0;

			for (i = 0; i < argsVals.size(); i++) {

				if (memberTypeSet((String) keys.get(i)).equals("Int")) {
					if (argsVals.get(i) != null)
						objectList.add(Integer.parseInt((String) argsVals.get(i)));
					else
						objectList.add(null);
				} else if (memberTypeSet((String) keys.get(i)).equals("String")) {
					objectList.add( argsVals.get(i));
				} else if (memberTypeSet((String) keys.get(i)).equals("Date")) {
					sKey = (String) keys.get(i);

					sdf = getSimpleDateFormat("MMddyyyy HH:mm:ss");

					if (argsVals.get(i) != null) {
						java.util.Date utilDate = sdf.parse((String) argsVals.get(i));

						java.sql.Timestamp timeStamp = getTimeStamp(utilDate.getTime());

						objectList.add(timeStamp);
					} else {
						objectList.add(null);
					}
				}
			} // end of argsVals for loop

			objectList.add(sMemNumVal);

			// Now excute the prepared statement
			int iCount = 0;
			if ((whereClause != null) && whereClause.length() != 0) {
				iCount = jdbcTemplate.update(new String(query), objectList.toArray(new Object[objectList.size()]));

				log.info("{}{}DBTOOLS_12 : The rows updated are :{}", CLASS_NAME, sMethodName, iCount);

				if (iCount == 0) {
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
							"No Record found for given member_num");
				} else {
					hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
							"No of rows updated in MEMBER table : " + iCount);
				}
			} else {
				hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_EMPTY_NUM, "where clause is not prepared");

				log.info("{}{}DBTOOLS_13 : where clause is not prepared", CLASS_NAME, sMethodName);
				return hmResult;
			}

			// 1612 Voltage Encrypt SPI Fields in MEMBER Table
			hmResult = oUpdateDBHelper.updateMemberAUX(hmDbInput);

			if (hmResult == null || hmResult.isEmpty()) {
				sAppInfo = "Null response from UpdateDBHelper.updateMemberAux() call.";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				log.error("{}{}DBTOOLS_13.1 : {}", CLASS_NAME, sMethodName, sAppInfo);
				return hmResult;
			}

			sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

			if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
				sAppInfo = "UpdateDBHelper.updateMemberAux() call failed.";
				hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(sAppStatusCode), sAppInfo);
				log.error("{}{}DBTOOLS_13.2 : {}", CLASS_NAME, sMethodName, sAppInfo);
				return hmResult;
			}
		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DBTOOLS_E2 : Error::{}", CLASS_NAME, sMethodName, e.getMessage());
			log.error("{}{}DBTOOLS_E3 : Exception = {}", CLASS_NAME, sMethodName, e);
		} finally {
			log.info("{}{}DBTOOLS_999 : update MEMBER response is : {}", CLASS_NAME, sMethodName, hmResult);
		}
		return hmResult;
	}

	/**
	 * This method checks if the provided key is a valid member attribute.
	 * It takes a String as input which is the key to be checked.
	 * The method compares the input key with a predefined list of valid member attributes.
	 * If the input key matches any of the valid member attributes, it returns true.
	 * Otherwise, it returns false.
	 *
	 * @param Key A String representing the key to be checked.
	 * @return A boolean indicating whether the input key is a valid member attribute or not.
	 */
	public static boolean memberCheckKey(String Key) {
		if ((Key.equalsIgnoreCase(MPSDefs.DB_SHA1_PASSWORD)) || (Key.equalsIgnoreCase(MPSDefs.DB_DES3_PASSWORD))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_ENC_PASSWORD)) || (Key.equalsIgnoreCase(MPSDefs.DB_MD5_PASSWORD))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_SSHA_PASSWORD)) || (Key.equalsIgnoreCase(MPSDefs.DB_PASSWORD_DIRTY))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_ID))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_ID_1))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_1))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_SECURITY_ANSWER_1))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_ID_2))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_2))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_SECURITY_ANSWER_2))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_LAST_MODIFIED_BY)) || (Key.equalsIgnoreCase(MPSDefs.DB_FIRSTNAME))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_LASTNAME)) || (Key.equalsIgnoreCase(MPSDefs.DB_FULLNAME))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_CONTACT_EMAIL))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_CONTACT_EMAIL_STATUS))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_PREVIOUS_CONTACT_EMAIL))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_CONTACT_EMAIL_EST_DATE))
				|| (Key.equalsIgnoreCase("slid_member_num")) || (Key.equalsIgnoreCase(MPSDefs.DB_MEMBER_NAME))
				|| (Key.equalsIgnoreCase("autogenerated_ind")) || (Key.equalsIgnoreCase(MPSDefs.DB_PASSCODE_VENC))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_SECURITY_ANSWER_VENC))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_BIRTHDATE_VENC)) || (Key.equalsIgnoreCase(MPSDefs.DB_CBR_OPT_OUT))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_ONL_QA_EST_DATE)) // added for 1510 : EPIC PID 266956b CTN Alias for
				// Fraud
				|| (Key.equalsIgnoreCase(MPSDefs.DB_REMARKS)) // Added for 1610 - PID 288753 IAM Support Target Biller
				|| (Key.equalsIgnoreCase(MPSDefs.DB_MIGRATION_IND)) // Added for 1610 - PID 288753 IAM Support Target
				// Biller
				|| (Key.equalsIgnoreCase(MPSDefs.DB_MIGRATION_DATE)) // Added for 1610 - PID 288753 IAM Support Target
				// Biller
				|| (Key.equalsIgnoreCase(MPSDefs.DB_BROWSER_LANGUAGE))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_ACTIVATED_IND)) || (Key.equalsIgnoreCase(MPSDefs.DB_LAST_VERIFIED))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_MAIN_CTN_OPT_OUT))
				|| (Key.equalsIgnoreCase(CommonDefs.DB_ACCESS_ID_RTV_DATE))
				|| (Key.equalsIgnoreCase(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE))
				|| (Key.equalsIgnoreCase(CommonDefs.DB_FN_LINKED_USERID))
				|| (Key.equalsIgnoreCase(CommonDefs.DB_FN_LINKED_STATUS))
				|| (Key.equalsIgnoreCase(MPSDefs.DB_PASSWORD_DIRTY)) // [2207] PID 400970h : Updating passwordDirty for
			// password change
		) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * This method determines the data type of a given member attribute.
	 * It takes a String as input which is the key of the member attribute.
	 * The method compares the input key with a predefined list of member attributes and their corresponding data types.
	 * If the input key matches any of the member attributes, it returns the data type of that attribute as a String.
	 * The possible return values are "Int", "String", and "Date".
	 *
	 * @param key A String representing the key of the member attribute.
	 * @return A String indicating the data type of the input key. Possible return values are "Int", "String", and "Date".
	 */
	public static String memberTypeSet(String key) {
		String sReturn = "";

		if ((key.equalsIgnoreCase(MPSDefs.DB_SHA1_PASSWORD)) || (key.equalsIgnoreCase(MPSDefs.DB_DES3_PASSWORD))
				|| (key.equalsIgnoreCase(MPSDefs.DB_ENC_PASSWORD)) || (key.equalsIgnoreCase(MPSDefs.DB_MD5_PASSWORD))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SSHA_PASSWORD)) || (key.equalsIgnoreCase(MPSDefs.DB_PASSWORD_DIRTY))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_ANSWER_1))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_ANSWER_2))
				|| (key.equalsIgnoreCase(MPSDefs.DB_LAST_MODIFIED_BY)) || (key.equalsIgnoreCase(MPSDefs.DB_FIRSTNAME))
				|| (key.equalsIgnoreCase(MPSDefs.DB_LASTNAME)) || (key.equalsIgnoreCase(MPSDefs.DB_FULLNAME))
				|| (key.equalsIgnoreCase(MPSDefs.DB_CONTACT_EMAIL))
				|| (key.equalsIgnoreCase(MPSDefs.DB_CONTACT_EMAIL_STATUS))
				|| (key.equalsIgnoreCase(MPSDefs.DB_PREVIOUS_CONTACT_EMAIL))
				|| (key.equalsIgnoreCase(MPSDefs.DB_MEMBER_NAME)) || (key.equalsIgnoreCase("autogenerated_ind"))
				|| (key.equalsIgnoreCase(MPSDefs.DB_PASSCODE_VENC))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_ANSWER_VENC))
				|| (key.equalsIgnoreCase(MPSDefs.DB_BIRTHDATE_VENC)) || (key.equalsIgnoreCase(MPSDefs.DB_REMARKS)) // Added
				// for
				// 1610
				// -
				// PID
				// 288753
				// IAM
				// Support
				// Target
				// Biller
				|| (key.equalsIgnoreCase(MPSDefs.DB_MIGRATION_IND)) // Added for 1610 - PID 288753 IAM Support Target
				// Biller
				|| (key.equalsIgnoreCase(MPSDefs.DB_BAN)) // Added for 1711 - Updated to nullify BAN via GenericDataFix
				// API
				|| (key.equalsIgnoreCase(MPSDefs.DB_BROWSER_LANGUAGE))

				|| (key.equalsIgnoreCase(MPSDefs.DB_ACTIVATED_IND))
				|| (key.equalsIgnoreCase(CommonDefs.DB_FN_LINKED_USERID))
				|| (key.equalsIgnoreCase(CommonDefs.DB_FN_LINKED_STATUS))
				|| (key.equalsIgnoreCase(MPSDefs.DB_PASSWORD_DIRTY)) // [2207] PID 400970h : Updating passwordDirty for
			// password change

		) {
			sReturn = "String";
		}

		if ((key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_ID))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_ID_1))
				|| (key.equalsIgnoreCase(MPSDefs.DB_SECURITY_QUESTION_ID_2))
				|| (key.equalsIgnoreCase("slid_member_num")) || (key.equalsIgnoreCase(MPSDefs.DB_ACCESS_ID)) // 2016.07
				// SID44581
				|| (key.equalsIgnoreCase(MPSDefs.DB_SOR_ID)) // 2016.07 SID44581
		) {

			sReturn = "Int";
		}

		if ((key.equalsIgnoreCase(MPSDefs.DB_CONTACT_EMAIL_EST_DATE)) || (key.equalsIgnoreCase(MPSDefs.DB_CBR_OPT_OUT))
				|| (key.equalsIgnoreCase(MPSDefs.DB_ONL_QA_EST_DATE)) // added for 1510 : EPIC PID 266956b CTN Alias for
				// Fraud
				|| (key.equalsIgnoreCase(MPSDefs.DB_MIGRATION_DATE)) // Added for 1610 - PID 288753 IAM Support Target
				// Biller
				|| (key.equalsIgnoreCase(MPSDefs.DB_LAST_VERIFIED))
				|| (key.equalsIgnoreCase(MPSDefs.DB_MAIN_CTN_OPT_OUT))
				|| (key.equalsIgnoreCase(CommonDefs.DB_ACCESS_ID_RTV_DATE))
				|| (key.equalsIgnoreCase(CommonDefs.DB_CONTACT_EMAIL_RTV_DATE))

		) {
			sReturn = "Date";
		}

		return sReturn;
	}

	private static java.sql.Timestamp getTimeStamp(long time) {
		return new java.sql.Timestamp(time);
	}

	private static SimpleDateFormat getSimpleDateFormat(String stFormat) {
		return new SimpleDateFormat(stFormat);
	}


	// 1412 : US305896 : below method is added below explicitly for
	// MigrateLegacySBUsers API for converting .net to SLID and updating parameters
	// : domain_id, member_name, sor_id, parent_child_ind, account_type, remarks for
	// member
	/**
	 * This method processes the wireline migration data.
	 * It takes a HashMap as input which contains key-value pairs for various member attributes like calling system id, transaction name, last modified by, and member operations.
	 * The method first checks if the input HashMap is null. If it is, it returns an error status.
	 * Then it retrieves the member attributes from the input HashMap.
	 * If the member attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param hmInput A HashMap containing the details of the member's information to be processed.
	 * @return A HashMap containing the status of the operation and the processed member's information.
	 */
	public HashMap processWirelineMigrationData(HashMap hmInput) {
		String sMethodName = ".processWirelineMigrationData.";
		HashMap<String, Object> hmResult = null;
		List<Object> objectList = CommonUtil.getArrayList();
		List<Object> objectList2 = CommonUtil.getArrayList();
		String sAppInfo = null;

		log.info("{}{}DBTOOLS000 : Input Hash is: {}", CLASS_NAME, sMethodName,
				(hmInput != null ? StringUtils.normalizeSpace(hmInput.toString()) : "null"));

		try {
			if (hmInput == null) {
				return hmResult = CommonErrorMap.makeCategoryMap(CommonErrorMap.ERR_EMPTY_NUM, "Input hash is empty");
			}

			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

			ArrayList alMemberOperations = (ArrayList) hmInput.get(MPSDefs.DB_MEMBER_TABLE);

			HashMap hmMemberOperation = (HashMap) alMemberOperations.get(0);

			String sMemberNum = (String) hmMemberOperation.get("member_num");
			String sMemberName = (String) hmMemberOperation.get("member_name");
			String sDomainId = (String) hmMemberOperation.get("domain_id");
			String sSorId = (String) hmMemberOperation.get("sor_id");
			String sAccountType = (String) hmMemberOperation.get("account_type");
			String sRemarks = (String) hmMemberOperation.get("remarks");
			String sParentChildInd = (String) hmMemberOperation.get("parent_child_ind");
			String sGroupNum = (String) hmMemberOperation.get("group_num");
			String sMigrationInd = (String) hmMemberOperation.get("migration_ind");
			String sMigrationDate = (String) hmMemberOperation.get("setMigrationDate");
			String sSlidMemberNum = null;

			String sWhereClause = " WHERE MEMBER_NUM = ? ";

			// 1710 : SID : 55169 : Update MPS SQL queries to use bind variables where fixed
			// variables are used

			String updateSql = "UPDATE MEMBER SET MEMBER_NAME = ? , DOMAIN_ID = ? , SOR_ID = ? , PARENT_CHILD_IND = ? , MIGRATION_IND = ? ";
			// 1505: US413861: Update RIL MigrateLegacySBUsers API - migration_date
			if (sMigrationDate != null && sMigrationDate.equalsIgnoreCase(MPSDefs.YES)) {
				updateSql = updateSql + " , MIGRATION_DATE = SYSDATE";
			} else if (sMigrationDate != null && sMigrationDate.equalsIgnoreCase(MPSDefs.NO)) {
				updateSql = updateSql + " , MIGRATION_DATE = ?";
			}
			if (hmMemberOperation.get("slid_member_num") != null) {
				updateSql = updateSql + " , SLID_MEMBER_NUM = ? ";
			} else {
				updateSql = updateSql + " , SLID_MEMBER_NUM = ? ";
			}

			if (sAccountType != null && !sAccountType.isEmpty()) {
				updateSql = updateSql + " , ACCOUNT_TYPE = ? ";
			}
			if (sRemarks != null && !sRemarks.isEmpty()) {
				updateSql = updateSql + " , REMARKS = ? ";
			}

			updateSql = updateSql + " , LAST_MODIFIED_BY = ? ";
			updateSql = updateSql + sWhereClause;

			log.info("{}{}SQL999 : SQL Query = {}", CLASS_NAME, sMethodName, updateSql);

			int prepStmtCount = 1;
			objectList.add(sMemberName);
			objectList.add(sDomainId);
			objectList.add(sSorId);
			objectList.add(sParentChildInd);
			objectList.add(sMigrationInd);

			// 1507 : US423705 : updated for setting migration_date to null for
			// RevertMigrateLegacyAPI
			if (sMigrationDate != null && sMigrationDate.equalsIgnoreCase(MPSDefs.NO)) {
				objectList.add(null);
			}
			if (hmMemberOperation.get("slid_member_num") != null) {
				objectList.add(sMemberNum);
			} else {
				objectList.add(sSlidMemberNum);
			}

			if (sAccountType != null && !sAccountType.isEmpty()) {
				objectList.add(sAccountType);
			}
			if (sRemarks != null && !sRemarks.isEmpty()) {
				objectList.add(sRemarks);
			}

			objectList.add(sCallingSystemId);
			objectList.add(sMemberNum);

			long tTime = 0;
			Date dtStartDate = new Date();

			int rowCount = jdbcTemplate.update(new String(updateSql),
					objectList.toArray(new Object[objectList.size()]));

			// Calculate the total time taken to execute the update
			// to return time in milliseconds
			tTime = (System.currentTimeMillis() - dtStartDate.getTime());

			log.info("{}{}QUERY999 : Total time taken to execute query = {} milliseconds", CLASS_NAME, sMethodName, tTime);

			log.info("{}{}DB_UM_03 : No of rows updated:= {}", CLASS_NAME, sMethodName, rowCount);

			if (rowCount == 0) {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
						"No Record found for given contact_id");
			} else {
				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
						"No of records updated=" + rowCount);
			}

			String sUpdateSql = "UPDATE MEMBERGROUP SET DOMAIN_ID = ? , LAST_MODIFIED_BY = ? WHERE GROUP_NUM = ? ";

			log.info("{}{}SQL999 : SQL Query = {}", CLASS_NAME, sMethodName, sUpdateSql);

			objectList2.add(sDomainId);
			objectList2.add(sCallingSystemId);
			objectList2.add(sGroupNum);

			tTime = 0;
			dtStartDate = new Date();

			rowCount = jdbcTemplate.update(new String(sUpdateSql), objectList2.toArray(new Object[objectList2.size()]));

			log.info("{}{}DB_UM_04 : No of rows updated:= {}", CLASS_NAME, sMethodName, rowCount);

			if (rowCount == 0) {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
						"No Record found for given contact_id");
			} else {
				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
						"No of records updated=" + rowCount);
			}

			// 1507 : US422717 : MigrateLegacySBUsers update in support of complex migration
			if (hmMemberOperation.containsKey("rolesToDelete") || hmMemberOperation.containsKey("rolesToAdd")) {
				HashMap<String, Object> hmRole = CommonUtil.getHashMap();
				hmRole.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);
				hmRole.put(MPSDefs.DB_SERVICE_ID, "10");
				hmRole.put(CommonDefs.TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
				hmRole.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
				hmRole.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
				hmRole.put(MPSDefs.DB_LAST_MODIFIED_BY, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));

				if (hmMemberOperation.containsKey("rolesToDelete")) {
					ArrayList alRolesToDel = (ArrayList) hmMemberOperation.get("rolesToDelete");
					for (int i = 0; i < alRolesToDel.size(); i++) {
						HashMap hmRolesToDel = (HashMap) alRolesToDel.get(i);
						String sSorInvId = (String) hmRolesToDel.get(MPSDefs.DB_SOR_INVARIANT_ID);
						String sRoleId = (String) hmRolesToDel.get(MPSDefs.DB_ROLE_ID);

						HashMap hmRemoveRole = CommonUtil.getHashMap();
						ArrayList alRoleIds = CommonUtil.getArrayList();

						hmRole.put(MPSDefs.DB_SOR_INVARIANT_ID, sSorInvId);
						hmRole.put(MPSDefs.DB_SOR_ID, hmRolesToDel.get(MPSDefs.DB_SOR_ID));

						alRoleIds.add(sRoleId);

						hmRemoveRole.putAll(hmRole);
						hmRemoveRole.put(CommonDefs.REMOVE_ROLE_IDS_KEY, alRoleIds);

						log.info("{}{}DB_UM_04.1 : Calling RolesDBHelper.removeRoles () with input = {}", CLASS_NAME, sMethodName, hmRemoveRole);

						// Calling MPSDB_Roles_H.removeRoles with Input params
						hmResult = oRolesDBHelper.removeEachRole(hmRemoveRole);

						log.info("{}{}DB_UM_04.2 : Response from RolesDBHelper.removeRoles (), hmResult :: {}", CLASS_NAME, sMethodName, hmResult);

						if (hmResult == null || hmResult.isEmpty()) {
							sAppInfo = "RolesDBHelper.removeRoles  call is returning null or Empty Hash";
							hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
							log.info("{}{}DB_UM_04.3 : {}", CLASS_NAME, sMethodName, sAppInfo);
							return hmResult;
						}

						String sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
						if (sAppStatusCode != null && !sAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
							sAppInfo = "RolesDBHelper.removeRoles call failed "
									+ hmResult.get(CErrorDefs.COMMON_APP_INFO);
							log.info("{}{}DB_UM_04.4 : {}", CLASS_NAME, sMethodName, sAppInfo);
							return hmResult;
						}

					}
				}

				if (hmMemberOperation.containsKey("rolesToAdd")) {
					ArrayList alRolesToAdd = (ArrayList) hmMemberOperation.get("rolesToAdd");
					for (int i = 0; i < alRolesToAdd.size(); i++) {
						HashMap hmRolesToAdd = (HashMap) alRolesToAdd.get(i);
						String sSorInvId = (String) hmRolesToAdd.get(MPSDefs.DB_SOR_INVARIANT_ID);
						String sRoleName = (String) hmRolesToAdd.get(MPSDefs.DB_ROLE_NAME);

						HashMap hmAddRole = CommonUtil.getHashMap();
						ArrayList alRoles = CommonUtil.getArrayList();

						String sRoleId = oServiceRoleValidation.getServiceRoleId("ECOMM", sRoleName);

						hmRole.put(MPSDefs.DB_SOR_INVARIANT_ID, sSorInvId);
						hmRole.put(MPSDefs.DB_SOR_ID, hmRolesToAdd.get(MPSDefs.DB_SOR_ID));

						hmAddRole.putAll(hmRole);

						HashMap hmRoleToAdd = CommonUtil.getHashMap();
						hmRoleToAdd.put(MPSDefs.DB_ROLE_ID, sRoleId);
						hmRoleToAdd.put(MPSDefs.DB_ROLE_STATUS, "Enabled");

						alRoles.add(hmRoleToAdd);

						hmAddRole.put(CommonDefs.ROLES, alRoles);

						log.info("{}{}DB_UM_04.5 : Calling RolesDBHelper.addRoles () with input = {}", CLASS_NAME, sMethodName, hmAddRole);

						// Calling MPSDB_Roles_H.removeRoles with Input params
						hmResult = oRolesDBHelper.addEachRole(hmAddRole);

						log.info("{}{}DB_UM_04.6 : Response from RolesDBHelper.addRoles (), hmResult :: {}", CLASS_NAME, sMethodName, hmResult);

						if (hmResult == null || hmResult.isEmpty()) {
							sAppInfo = "RolesDBHelper.addRoles  call is returning null or Empty Hash";
							hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
							log.info("{}{}DB_UM_04.7 : {}", CLASS_NAME, sMethodName, sAppInfo);
							return hmResult;
						}

						String sAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
						if (sAppStatusCode != null && !sAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
							sAppInfo = "RolesDBHelper.addRoles call failed " + hmResult.get(CErrorDefs.COMMON_APP_INFO);
							log.info("{}{}DB_UM_04.8 : {}", CLASS_NAME, sMethodName, sAppInfo);
							return hmResult;
						}
					}
				}
			}
			// Calculate the total time taken to execute the update
			// to return time in milliseconds
			tTime = (System.currentTimeMillis() - dtStartDate.getTime());
			log.info("{}{}QUERY999 : Total time taken to execute query = {} milliseconds", CLASS_NAME, sMethodName, tTime);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DBTOOLS_E2 : Error::{}", CLASS_NAME, sMethodName, e.getMessage());
			log.error("{}{}DBTOOLS_E3 : Exception = {}", CLASS_NAME, sMethodName, e);
		} finally {
			log.info("{}{}DBTOOLS999 : response : {}", CLASS_NAME, sMethodName, hmResult);
		}
		return hmResult;
	}

	public HashMap addPendingAction(HashMap hmInput) {
		String sMethodName = ".addPendingAction.";
		java.sql.Timestamp dPendingActionDate = null;
		HashMap hmResult = null;
		String stAppInfo = null;
		String stMemberNum = null;
		String stApplicationName = null;
		String stCallingSystemId = null;
		String stPendingActionDate = null;
		DateFormat sdf = null;
		log.info("{}{}MDBH.APA.01 : CVS KEYWORDS: {}", CLASS_NAME, sMethodName, INFO);
		log.info("{}{}DBTOOLS000 :updateMemberServiceSorInvId InpParam : {}", CLASS_NAME, sMethodName, StructuredArguments.entries(hmInput));

		if (hmInput == null || hmInput.isEmpty()) {
			stAppInfo = "hmInput is null";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			log.info("{}{}MDBH.APA.03 : Output from updateMemberServiceSorInvId = :  {} ", CLASS_NAME, sMethodName, stAppInfo);
			return hmResult;
		}
		String addPendingActionSql = "INSERT INTO PENDINGACTION(APPLICATION_NAME, MEMBER_NUM,PENDING_ACTION_DATE,LAST_MODIFIED_BY)" +
				"VALUES (?, ?, ?, ?)";

		List<Object> objectList = new ArrayList<>();

		try {
			stApplicationName = (String) hmInput
					.get(MPSDefs.KEY_APPLICATION_NAME);
			stMemberNum = (String) hmInput.get(CommonDefs.DB_MEMBER_NUM);
			stPendingActionDate = (String) hmInput
					.get(MPSDefs.DB_PENDING_ACTION_DATE);
			stCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

			if (stApplicationName==null ||stApplicationName.trim().isEmpty()||stMemberNum==null ||stMemberNum.trim().isEmpty()
					||stPendingActionDate==null||stPendingActionDate.trim().isEmpty()||stCallingSystemId==null ||stCallingSystemId.trim().isEmpty())
			{
				stAppInfo = "Member Num or ApplicationName or PendingActionDate or CallingSystemId  is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}MDBH.APA.04: {}", CLASS_NAME, sMethodName, stAppInfo);
				return hmResult;
			}

			if (!stPendingActionDate.isEmpty()) {
				sdf = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
				java.util.Date utilDate = sdf.parse(stPendingActionDate);
				dPendingActionDate = getNewTimestamp(utilDate.getTime());
			}

			objectList.add(stApplicationName);
			objectList.add(stMemberNum);
			objectList.add(dPendingActionDate);
			objectList.add(stCallingSystemId);

			log.debug("{}{}MDBH.APA.05 : service_id={}", sMethodName, CLASS_NAME, dPendingActionDate);
			log.debug("{}{}MDBH.APA.06 : SQL = {}", sMethodName, CLASS_NAME, addPendingActionSql);

			long tTime = 0;
			Date dtStartDate = new Date();
			int rowCount = jdbcTemplate.update(new String(addPendingActionSql),
					objectList.toArray(new Object[objectList.size()]));
			tTime = (System.currentTimeMillis() - dtStartDate.getTime());
			log.info("{}{}MDBH.APA.07 :Total time taken to execute query {} milliseconds", CLASS_NAME, sMethodName,
					tTime);

			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
					"No of rows inserted:= " + rowCount);
			log.info("{}{}MDBH.APA.08: No of rows inserted = {}", CLASS_NAME, sMethodName, rowCount);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			log.error("{}{}MDBH.APA.09 :  Error::{}", CLASS_NAME, sMethodName, e.getMessage());
			log.error("{}{}MDBH.APA.10 : Exception = {}", CLASS_NAME, sMethodName, errorCode);

		} finally {
			log.info("{}{}DBTOOLS999 : STATUS = {}", CLASS_NAME, sMethodName, hmResult);
		}
		return hmResult;
	}
	public HashMap updatePendingAction(HashMap hmInput) {
		String sMethodName = ".updatePendingAction.";
		java.sql.Timestamp dPendingActionDate = null;
		HashMap hmResult = null;
		String stAppInfo = null;
		String updateStmt = "";
		String stMemberNum = null;
		String stApplicationName = null;
		String stCallingSystemId = null;
		String stPendingActionDate = null;
		DateFormat sdf = null;
		log.info("{}{}MDBH.UPA.01 : CVS KEYWORDS: {}", CLASS_NAME, sMethodName, INFO);
		log.info("{}{}DBTOOLS000 :updatePendingAction InpParam : {}", CLASS_NAME, sMethodName, StructuredArguments.entries(hmInput));


		if (hmInput == null || hmInput.isEmpty()) {
			stAppInfo = "hmInput is null";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			log.info("{}{}MDBH.UPA.02 : Output from updatePendingAction = :  {} ", CLASS_NAME, sMethodName, stAppInfo);
			return hmResult;
		}

		String updatePendingAction =
				"UPDATE PENDINGACTION SET PENDING_ACTION_DATE=?,LAST_MODIFIED_BY=? WHERE MEMBER_NUM=?";
		String updatePendingActionWithAppName =
				"UPDATE PENDINGACTION SET PENDING_ACTION_DATE=?,LAST_MODIFIED_BY=? WHERE MEMBER_NUM=? AND APPLICATION_NAME=?";

		List<Object> objectList = new ArrayList<>();

		try {
			stMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
			stApplicationName = (String) hmInput.get(MPSDefs.KEY_APPLICATION_NAME);
			stPendingActionDate = (String) hmInput.get(MPSDefs.DB_PENDING_ACTION_DATE);
			stCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

			if (stMemberNum==null ||stMemberNum.trim().isEmpty()||stPendingActionDate==null ||stPendingActionDate.trim().isEmpty()||stCallingSystemId==null
					||stCallingSystemId.trim().isEmpty()){
				stAppInfo = "Member_Num or PendingActionDate or CallingSystemId  is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}QIPRL.DBH_03: {}", CLASS_NAME, sMethodName, stAppInfo);
				return hmResult;
			}
			if (!stPendingActionDate.isEmpty()) {
				sdf = CommonUtil.getSimpleDateFormat("MMddyyyy HH:mm:ss");
				java.util.Date utilDate = sdf.parse(stPendingActionDate);
				dPendingActionDate = getNewTimestamp(utilDate.getTime());
			}
			if (stApplicationName != null && !stApplicationName.trim().isEmpty())
			{
				updateStmt = updatePendingActionWithAppName;
			} else {
				updateStmt = updatePendingAction;
			}
			log.debug("{}{}DBHLP84 : SQL = {}", sMethodName, CLASS_NAME, updateStmt);

			objectList.add(dPendingActionDate);
			objectList.add(stCallingSystemId);
			objectList.add(stMemberNum);
			objectList.add(stApplicationName);

			int rowCount = jdbcTemplate.update(new String(updateStmt), objectList.toArray(new Object[objectList.size()]));

			if (rowCount == 0) {
				stAppInfo = "No Record found";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_NO_SERVICE_NUM, stAppInfo);
				log.info("{}{}MDBH.UPA.03 : {}", CLASS_NAME, sMethodName, stAppInfo);
			} else {
				stAppInfo = "PENDINGACTION attributes updated successfully in the UpdatePendingAction ";
				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, stAppInfo);
				log.info("{}{}MDBH.UPA.04 : {}", CLASS_NAME, sMethodName, stAppInfo);
			}
		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			log.error("{}{}MDBH.UPA.05 : Error:: {}", CLASS_NAME, sMethodName, e.getMessage());
			log.error("{}{}MDBH.UPA.06 : Exception = {}", CLASS_NAME, sMethodName, errorCode);
			return hmResult;
		} finally {
			log.info("{}{}DBTOOLS999 : Output from UpdatePendingAction = :  {} ", CLASS_NAME, sMethodName, hmResult);
		}
		return hmResult;
	}

	public HashMap<String, Object> deletePendingAction(HashMap<String, Object> hmInput) {
		String sMethodName = ".deletePendingAction.";
		String stAppInfo = null;
		String deleteStmt = "";
		String stMemberNum = null;
		String stApplicationName = null;
		HashMap<String, Object> hmResult = null;
		List<Object> objectList = new ArrayList<>();
		log.info("{}{}MDBH.DPA.01. : CVS KEYWORDS: {}", CLASS_NAME, sMethodName, INFO);
		log.info("{}{}DBTOOLS000 : deletePendingAction InpParam : {}", CLASS_NAME, sMethodName, StructuredArguments.entries(hmInput));

		if (hmInput == null || hmInput.isEmpty()) {
			hmResult = CommonErrorMap.makeCategoryMap(
					CErrorDefs.ERR_INVALID_DATA_NUM, "input to removeService() is null");
			log.info("{}{}MDBH.DPA.02 : deletePendingAction response :  {} ", CLASS_NAME, sMethodName, hmResult);
			return hmResult;
		}
		deleteStmt =
				"DELETE FROM PENDINGACTION WHERE MEMBER_NUM = ?";
		String deleteStmtWithAppName =
				"DELETE FROM PENDINGACTION WHERE MEMBER_NUM =? AND APPLICATION_NAME=?";
		try {
			String memberNumStr = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
			if (memberNumStr == null || memberNumStr.trim().isEmpty()) {
				stAppInfo = "Member_Num  is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}MDBH.DPA.03: {}", CLASS_NAME, sMethodName, stAppInfo);
				return hmResult;
			}
			stApplicationName = (String) hmInput.get(MPSDefs.KEY_APPLICATION_NAME);
			if (stApplicationName != null && !stApplicationName.isEmpty()) {
				deleteStmt = deleteStmtWithAppName;
			}

			objectList.add(stMemberNum);
			objectList.add(stApplicationName);

			int rowCount = jdbcTemplate.update(new String(deleteStmt), objectList.toArray(new Object[objectList.size()]));

			log.info("{}{}MDBH.DPA.04 : No of rows deleted are : {}", CLASS_NAME, sMethodName, rowCount);

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "No of rows deleted = " + rowCount);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();

			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}MDBH.DPA.05 : Error:: {}", CLASS_NAME, sMethodName, e.getMessage());

		} finally {
			log.info("{}{}DBTOOLS999 : response : {}", CLASS_NAME, sMethodName, hmResult);
		}
		return hmResult;
	}
	public HashMap insertWhenMemberDelete(HashMap hmInput) {
		String sMethodName = ".insertWhenMemberDelete.";
		HashMap hmResult = null;
		String stAppInfo = null;
		String updateStmt = "";
		log.info("{}{}MDBH.IWMD.01. : CVS KEYWORDS: {}", CLASS_NAME, sMethodName, INFO);
		log.info("{}{}DBTOOLS000 : deletePendingAction InpParam : {}", CLASS_NAME, sMethodName, StructuredArguments.entries(hmInput));
		if (hmInput == null || hmInput.isEmpty()) {
			stAppInfo = "hmInput is null";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			log.info("{}{}MDBH.IWMD.02 : insertWhenMemberDelete = :  {} ", CLASS_NAME, sMethodName, stAppInfo);
			return hmResult;
		}

		String sInsertSql ="INSERT INTO MEMBER (MEMBER_NUM, MEMBER_NAME, DOMAIN_ID, GROUP_NUM, SOR_ID, PARENT_CHILD_IND,"
				+ " ACCESS_ID, MEMBER_STATE, FULLNAME, FIRSTNAME, LASTNAME, PROOFING_ZIP, MAILHOST, MIGRATION_IND, LAST_MODIFIED_BY) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		try {
			String memberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
			String memberName = (String) hmInput.get(MPSDefs.DB_MEMBER_NAME);
			String domainId = (String) hmInput.get(MPSDefs.DB_DOMAIN_ID);
			String lastModifiedBy = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);
			List<Object> objectList = new ArrayList<>();


			if (memberNum==null ||memberNum.trim().isEmpty()||memberName==null ||memberName.trim().isEmpty()||domainId==null
					||domainId.trim().isEmpty()	||lastModifiedBy == null || lastModifiedBy.trim().isEmpty()){
				stAppInfo = "One of Member Number,Member Name,Domain Id ,lastModifiedBy is missing";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}MDBH.IWMD.03: {}", CLASS_NAME, sMethodName, stAppInfo);
				return hmResult;
			}

			String sSorId = (String) hmInput.get(MPSDefs.DB_SOR_ID);
			String sGroupNum = (String) hmInput.get(MPSDefs.DB_GROUP_NUM);
			String sParentChildInd = (String) hmInput.get(MPSDefs.DB_PARENT_CHILD_IND);
			String sAccessId = (String) hmInput.get(MPSDefs.DB_ACCESS_ID);
			String sMemberState = (String) hmInput.get(MPSDefs.DB_MEMBER_STATE);
			String sFullname = (String) hmInput.get(MPSDefs.DB_FULLNAME);

			// new attributes added
			String sFirstName = (String) hmInput.get(MPSDefs.DB_FIRSTNAME);
			String sLastName = (String) hmInput.get(MPSDefs.DB_LASTNAME);
			String proofingZip = (String) hmInput.get(MPSDefs.DB_PROOFING_ZIP);
			String sMailHost = (String) hmInput.get(MPSDefs.DB_MAILHOST);
			String sMigrationInd = (String) hmInput.get(MPSDefs.DB_MIGRATION_IND);


			log.debug("{}{}MDBH.IWMD.04 : SQL = {}", sMethodName, CLASS_NAME, sInsertSql);

			objectList.add(Long.parseLong(memberNum));
			objectList.add(memberName);
			objectList.add(Integer.parseInt(domainId));
			objectList.add(Long.parseLong(sGroupNum));
			objectList.add(Integer.parseInt(sSorId));
			objectList.add(sParentChildInd);
			objectList.add(Integer.parseInt(sAccessId));
			objectList.add(sMemberState);
			objectList.add(sFullname);
			objectList.add(sFirstName);
			objectList.add(sLastName);
			objectList.add(proofingZip);
			objectList.add(sMailHost);
			objectList.add(sMigrationInd);
			objectList.add(lastModifiedBy);

			int rowCount = jdbcTemplate.update(new String(sInsertSql),
					objectList.toArray(new Object[objectList.size()]));

			if (rowCount == 0) {
				stAppInfo = "No Record Added into the member table in insertWhenMemberDelete";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo);
				log.info("{}{}MPSDBSU_10 : {}", CLASS_NAME, sMethodName, stAppInfo);
			} else {
				stAppInfo = " Member attributes added successfully in the insertWhenMemberDelete ";
				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, stAppInfo);
				log.info("{}{}MPSDBSU_11 : {}", CLASS_NAME, sMethodName, stAppInfo);
			}
		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			log.error("{}{}DMDH.DGS.07 : Error:: {}", CLASS_NAME, sMethodName, e.getMessage());
			log.error("{}{}DMDH.DGS.08 : Exception = {}", CLASS_NAME, sMethodName, errorCode);
			return hmResult;
		} finally {
			log.info("{}{}DBTOOLS999 : Output from insertWhenMemberDelete = :  {} ", CLASS_NAME, sMethodName, hmResult);
		}
		return hmResult;
	}

	private static java.sql.Timestamp getNewTimestamp(long time) {
		return new java.sql.Timestamp(time);
	}
}
