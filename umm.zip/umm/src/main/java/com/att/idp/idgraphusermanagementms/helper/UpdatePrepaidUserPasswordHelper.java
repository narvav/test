package com.att.idp.idgraphusermanagementms.helper;

import com.att.idp.idgraphusermanagementms.db.helper.GetAssociatedMembersDBHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.*;
import net.logstash.logback.argument.StructuredArguments;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This is the InquireProfileHelper class.
 * It is a helper class that provides methods to inquire about a user profile.
 * It contains methods to validate and process the input data, interact with the database, and format the response.
 * It is annotated as a Spring Component, indicating that an instance of this class will be created and managed by the Spring framework.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class UpdatePrepaidUserPasswordHelper {

	private static final String sClassName = "UpdatePrepaidUserPasswordHelper";
	public static final Logger logger = LoggerFactory.getLogger(UpdatePrepaidUserPasswordHelper.class);
	private static final String ERROR_ENUM = "ErrorEnum";
	public static final String MOBILITY_SOR_ID = "13";

	@Autowired
	private GetAssociatedMembersDBHelper oGetAssociatedMembersDBHelper;

	@Autowired
	private UpdateUserPasswordHelper updateUserPasswordHelper;

	/**
	 * This method is part of the InquireProfileHelper class.
	 * It takes a Map as an input, which contains the details required to inquire about a user profile.
	 * The method performs various validations on the input data, interacts with the database, and formats the response.
	 * It logs the input and output data, and handles any exceptions that may occur during the process.
	 * The method returns a Map which contains the response data.
	 *
	 * @param hmInput A Map containing the input data for the inquiry.
	 * @return A Map containing the response data from the inquiry.
	 */

	public Map<String, Object> updatePrepaidUserPassword(Map<String, Object> hmInput) {
		String sMethodName = ".updatePrepaidUserPassword.";
		String stAppStatusCode = null;
		Map<String, Object> hmResult = null;
		String stAppInfo = null;
		List alAssociatedMembers = new ArrayList<>();
		Map hmGetAssocMemResp = null;
		String sHandle = null;
		String sDomain = null;
		HashMap<String, String> hmOwnerHandleDomain =null;

		logger.info(SpiMarker.getInstance(), "UpdatePrepaidUserPasswordHelper.updatePrepaidUserPassword.HLP000 : Input Hash : {}",
				StructuredArguments.entries(hmInput));
		if (hmInput == null || hmInput.isEmpty()) {
			stAppInfo = "Input Hash is NULL";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			logger.info("{}{}UPUPH.UPUP.00 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		try {
			ArrayList<String> alRole = new ArrayList<>();
			HashMap<String, Object> hmGetAssociatedMembersInp = CommonUtil.getHashMap();
			hmGetAssociatedMembersInp.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
			hmGetAssociatedMembersInp.put(CommonDefs.CALLING_SYSTEM_ID,	hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
			hmGetAssociatedMembersInp.put(CommonDefs.TRANSACTION_ID, hmInput.get(ProfileOrchestrationConstants.IDPTRACEID));
			hmGetAssociatedMembersInp.put(MPSDefs.DB_SOR_INVARIANT_ID1,	hmInput.get(CommonDefs.BAN));
			hmGetAssociatedMembersInp.put(MPSDefs.DB_SERVICE_TYPE, CommonDefs.MOBILITY_SERVICE);
			hmGetAssociatedMembersInp.put(MPSDefs.DB_SOR_ID,MOBILITY_SOR_ID);
			hmGetAssociatedMembersInp.put(MPSDefs.QUERY_SLID_INFO_FLAG,	CommonDefs.IND_Y);
			// setting default values for QUERY_ROLES_INFO_FLAG
			alRole.add("ALL");
			hmGetAssociatedMembersInp.put(CommonDefs.QUERY_ROLES_INFO_FLAG, alRole);

			hmGetAssocMemResp = oGetAssociatedMembersDBHelper.getAssociatedMembers(hmGetAssociatedMembersInp);
			logger.debug(SpiMarker.getInstance(), "{}{}UPUPH.UPUP.01 : GetAssociatedMembersDBHelper.getAssociatedMembers Response ={}", sClassName, sMethodName, hmResult);

			if (hmGetAssocMemResp == null || hmGetAssocMemResp.isEmpty()) {
				stAppInfo = "Response from  GetAssociatedMembersDBHelper is either null or empty";
				logger.info("{}{} UPUPH.UPUP.02 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, HtmlUtils.htmlEscape(stAppInfo));
				return hmResult;
			}
			stAppStatusCode = (String) hmGetAssocMemResp.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				if (stAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND)|| stAppStatusCode.equals(CErrorDefs.ERR_USER_NOT_FOUND)) {
					stAppInfo = "User Not Found for input CTN and BAN";
					logger.info("{}{} UPUPH.UPUP.03 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
					return hmResult;
				}else {
					hmResult = hmGetAssocMemResp;
					return hmResult;
				}
			}
			alAssociatedMembers=(ArrayList) hmGetAssocMemResp
					.get(MPSDefs.ASSOCIATED_MEMBERS);
			hmOwnerHandleDomain = getOwnerHandleDomain(alAssociatedMembers);
			sHandle =  hmOwnerHandleDomain.get(CommonDefs.HANDLE);
			sDomain =  hmOwnerHandleDomain.get(CommonDefs.DOMAIN);

			if (sHandle == null || sHandle.isEmpty()) {
				stAppInfo = "Owner Mobility not found";
				hmResult = CommonErrorMap.makeCategoryMap(
						CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}UPUPH.UPUP.04 : {}", sClassName, sMethodName,
						stAppInfo);
				return hmResult;
			} else {
				hmInput.put(CommonDefs.HANDLE, sHandle);
				hmInput.put(CommonDefs.DOMAIN, sDomain);
			}
			hmResult = changeUserPassword((HashMap<String, Object>) hmInput);

			hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			logger.error("{}{}UPUPH.UPUP.05  Error : {}", sClassName, sMethodName,e.getMessage());

		} finally {
			logger.info(SpiMarker.getInstance(), "UpdatePrepaidUserPasswordHelper.updatePrepaidUserPassword HLP999 : response from UpdatePrepaidUserPasswordHelper :{}",
					StructuredArguments.entries(hmResult));
		}
		return hmResult;
	}
	/**
	 * This method retrieves the owner handle and domain from a list of associated members.
	 * It iterates through the list of associated members, processes each associated account,
	 * and extracts the owner handle and domain if available.
	 *
	 * @param alAssociatedMembersInp A list of associated members.
	 * @return A HashMap containing the owner handle and domain.
	 */
	private static HashMap<String, String> getOwnerHandleDomain(List alAssociatedMembersInp) {
		HashMap<String, String> hmOwnerHandleDomain = new HashMap<>();
		if (alAssociatedMembersInp != null && !alAssociatedMembersInp.isEmpty()) {
			for (Object assocMem : alAssociatedMembersInp) {
				if (assocMem instanceof HashMap<?, ?>) {
					HashMap<String, Object> hmAssocAcct = (HashMap<String, Object>) assocMem;
					processAssociatedAccount(hmAssocAcct, hmOwnerHandleDomain);
				}
			}
		}
		return hmOwnerHandleDomain;
	}
	/**
	 * Processes an associated account to retrieve the owner handle and domain.
	 * This method extracts the handle and domain from the provided associated account map,
	 * and if mobility services are present, it processes them to update the owner handle and domain.
	 *
	 * @param hmAssocAcct A HashMap containing the associated account details.
	 * @param hmOwnerHandleDomain A HashMap to store the owner handle and domain if found.
	 */
	private static void processAssociatedAccount(HashMap<String, Object> hmAssocAcct, HashMap<String, String> hmOwnerHandleDomain) {
		String sDBAssocHandle = (String) hmAssocAcct.get(MPSDefs.DB_MEMBER_NAME);
		String sDBAssocDomain = (String) hmAssocAcct.get(MPSDefs.DB_DOMAIN_NAME);
		HashMap<String, Object> hmDBAssocSvcs = (HashMap<String, Object>) hmAssocAcct.get(CommonDefs.SERVICES);
		if (hmDBAssocSvcs != null) {
			HashMap<String, Object> hmDBAssocMobSvcs = (HashMap<String, Object>) hmDBAssocSvcs.get(CommonDefs.MOBILITY_SERVICE);
			if (hmDBAssocMobSvcs != null && !hmDBAssocMobSvcs.isEmpty()) {
				processMobilityServices(hmDBAssocMobSvcs, sDBAssocHandle, sDBAssocDomain, hmOwnerHandleDomain);
			}
		}
	}

	/**
	 * Processes the mobility services associated with a user.
	 * This method iterates through the provided mobility services map, checks if each service is a mobility service,
	 * and if so, processes the roles associated with that service to update the owner handle and domain.
	 *
	 * @param hmDBAssocMobSvcs A HashMap containing the mobility services details.
	 * @param sDBAssocHandle The handle associated with the database.
	 * @param sDBAssocDomain The domain associated with the database.
	 * @param hmOwnerHandleDomain A HashMap to store the owner handle and domain if the owner role is found.
	 */
	private static void processMobilityServices(HashMap<String, Object> hmDBAssocMobSvcs, String sDBAssocHandle, String sDBAssocDomain, HashMap<String, String> hmOwnerHandleDomain) {
		for (Object mobSvcDetails : hmDBAssocMobSvcs.values()) {
			if (mobSvcDetails instanceof HashMap<?, ?>) {
				HashMap<String, Object> hmMobSvcDetails = (HashMap<String, Object>) mobSvcDetails;
				String sServiceName = (String) hmMobSvcDetails.get(MPSDefs.DB_SERVICE_NAME);
				if (CommonDefs.MOBILITY_SERVICE.equals(sServiceName)) {
					processRoles(hmMobSvcDetails, sDBAssocHandle, sDBAssocDomain, hmOwnerHandleDomain);
				}
			}
		}
	}

	/**
	 * Processes the roles associated with a mobility service and updates the owner handle and domain if the owner role is found.
	 *
	 * @param hmMobSvcDetails A HashMap containing the details of the mobility service.
	 * @param sDBAssocHandle The handle associated with the database.
	 * @param sDBAssocDomain The domain associated with the database.
	 * @param hmOwnerHandleDomain A HashMap to store the owner handle and domain if the owner role is found.
	 */
	private static void processRoles(HashMap<String, Object> hmMobSvcDetails, String sDBAssocHandle, String sDBAssocDomain, HashMap<String, String> hmOwnerHandleDomain) {
		ArrayList<HashMap<String, String>> alRoles = (ArrayList<HashMap<String, String>>) hmMobSvcDetails.get(CommonDefs.ROLES);
		for (HashMap<String, String> sRole : alRoles) {
			if (sRole != null) {
                String sRoleName = sRole.get(MPSDefs.DB_ROLE_NAME);
				if (CommonDefs.KEY_ROLE_NAME_OWNER.equalsIgnoreCase(sRoleName)) {
					hmOwnerHandleDomain.put(CommonDefs.HANDLE, sDBAssocHandle);
					hmOwnerHandleDomain.put(CommonDefs.DOMAIN, sDBAssocDomain);
				}
			}
		}
	}

	/**
	 * This method changes the user's password.
	 * It constructs a map with the necessary parameters and calls the `updateUserPasswordHelper.changeUserPassword` method.
	 * The method logs the input and output data, and handles any exceptions that may occur during the process.
	 * The method returns a map which contains the response data.
	 *
	 * @param hmInput A HashMap containing the input data for changing the user password.
	 * @return A Map containing the response data from the password change operation.
	 */
	private Map<String, Object> changeUserPassword(HashMap<String, Object> hmInput) {

		String sMethodName = ".changeUserPassword.";
		Map hmResult = null;
		String stAppInfo= null;
		String stAppStatusCode=null;
		Map<String, Object> hmChangeUserPassword = CommonUtil.getHashMap();

		hmChangeUserPassword.put(ProfileOrchestrationConstants.IDPTRACEID, hmInput.get(ProfileOrchestrationConstants.IDPTRACEID));
		hmChangeUserPassword.put(CommonDefs.TRANSACTION_NAME, CommonDefs.TRANSACTION_NAME_UPDATE_USER_PWD);
		hmChangeUserPassword.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		hmChangeUserPassword.put(CommonDefs.HANDLE, hmInput.get(CommonDefs.HANDLE));
		hmChangeUserPassword.put(CommonDefs.DOMAIN, hmInput.get(CommonDefs.DOMAIN));
		hmChangeUserPassword.put(CommonDefs.CTN, hmInput.get(CommonDefs.CTN));
		hmChangeUserPassword.put(CommonDefs.NEW_PASSWORD, hmInput.get(CommonDefs.PASSWORD));
		hmChangeUserPassword.put(CommonDefs.IS_EXTERNAL_CALL, CommonDefs.IND_N);
		hmChangeUserPassword.put(CommonDefs.IS_UPDATE_SILENT, CommonDefs.IND_Y);

		logger.info("{}{}UPUPH.CUP.01 : UpdateUserPasswordHelper.changeUserPassword with input ={}", sClassName, sMethodName, hmChangeUserPassword);
		hmResult=updateUserPasswordHelper.changeUserPassword(hmChangeUserPassword);
		logger.info("{}{}UPUH_16 : UpdateUserPasswordHelper.changeUserPassword with response ={}", sClassName, sMethodName, hmResult);

		if (hmResult == null || hmResult.isEmpty()) {
			stAppInfo = "Response from UpdateUserPasswordHelper is either null or empty";
			logger.info("{}{}UPUPH.CUP.02 : {}", sClassName, sMethodName, stAppInfo);
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			return hmResult;
		}
		stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
		if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
			stAppInfo = hmResult.get(CErrorDefs.COMMON_APP_INFO).toString();
			logger.info("{}{}UPUPH.CUP.03 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(stAppInfo).replace("\r", "").replace("\n", ""));
			return hmResult;
		}
		return hmResult;
	}

}


