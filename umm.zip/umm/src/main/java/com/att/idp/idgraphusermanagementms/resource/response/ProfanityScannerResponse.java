package com.att.idp.idgraphusermanagementms.resource.response;

import com.att.idp.core.exception.ServiceError;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "ProfanityScannerResponse")
public class ProfanityScannerResponse {

    @JsonIgnore
    private String transactionName;
    @JsonProperty("idp-trace-id")
    private String idpTraceId;
    private String appInfo;
    @JsonProperty("error")
    private ServiceError errors;
    private String appCategoryCode;

    @Override
    public String toString() {
        return "ProfanityScannerResponse{" +
                "transactionName='" + transactionName + '\'' +
                ", idpTraceId='" + idpTraceId + '\'' +
                ", appInfo='" + appInfo + '\'' +
                ", errors=" + CommonUtilHelper.objectToString(errors) +
                '}';
    }
}
