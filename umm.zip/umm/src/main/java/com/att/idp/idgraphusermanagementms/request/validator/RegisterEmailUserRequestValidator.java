package com.att.idp.idgraphusermanagementms.request.validator;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;

import jakarta.validation.Valid;
import jakarta.ws.rs.core.HttpHeaders;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphusermanagementms.resource.request.Contact;
import com.att.idp.idgraphusermanagementms.resource.request.RegisterEmailUserRequest;
import com.att.idp.idgraphusermanagementms.resource.request.Services;
import com.att.idp.idgraphusermanagementms.resource.response.RegisterEmailUserResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This class, RegisterEmailUserRequestValidator, is responsible for validating the RegisterEmailUserRequest.
 * It checks for the presence and validity of required fields in the request, and returns a RegisterEmailUserResponse accordingly.
 * It is annotated with @Component, @Configuration, and @PropertySource to indicate that it's a Spring Bean,
 * to allow it to access configuration properties, and to specify the location of the properties file respectively.
 *
 * The class contains several methods, including:
 * - registerEmailUserRequestValidator: the main method that orchestrates the validation process.
 * - registerEmailUserReqInputValidator: a method that validates the input fields in the request.
 * - registerEmailUserCSIValidator: a method that validates the 'CSI' field in the request.
 * - registerEmailUserErrorResponse: a helper method that generates an error response.
 * - validateDOBFormat: a method that validates the 'dateOfBirth' field in the request.
 * - isValidEmail: a method that validates the 'contactEmail' field in the request.
 * - validateAndGetFormattedZip: a method that validates and formats the 'proofingZip' field in the request.
 * - validateContact: a method that validates the 'contact' field in the request.
 * - validateServices: a method that validates the 'services' field in the request.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class RegisterEmailUserRequestValidator {

	private static final Logger logger = LoggerFactory.getLogger(RegisterEmailUserRequestValidator.class);

	private String sClassName = "RegisterEmailUserRequestValidator";

	@Value("${OPR_REG_CallingSystemIds}")
	private String propValidCallersForRegisterEmailUser;

	@Value("${RILHRS_ValidDomains}")
	private String propValidDomains;

	@Value("${Valid_Languages}")
	private String propValidLanguages;

	@Value("${Valid_OPR_AccountType}")
	private String propValidOPRAccountType;

	/**
	 * This method is responsible for validating the RegisterEmailUserRequest.
	 * It takes HttpHeaders and RegisterEmailUserRequest as parameters.
	 * HttpHeaders contains the request headers which may include additional information required for processing the request.
	 * RegisterEmailUserRequest encapsulates the details of the register email user operation to be performed.
	 *
	 * The method performs various checks and validations on the input parameters and returns a RegisterEmailUserResponse object.
	 * The RegisterEmailUserResponse object encapsulates the result of the register email user operation.
	 *
	 * @param requestHeader The HttpHeaders containing the request headers.
	 * @param registerEmailUserReq The RegisterEmailUserRequest containing the details of the register email user operation.
	 * @return RegisterEmailUserResponse The response of the register email user operation.
	 */
	public RegisterEmailUserResponse registerEmailUserRequestValidator(HttpHeaders requestHeader,
			@Valid RegisterEmailUserRequest registerEmailUserReq) {

		String sMethodName = ".registerEmailUserRequestValidator.";
		String stAppInfo = null;
		String stIdpTraceId = null;

		RegisterEmailUserResponse registerEmailUserResponse = null;

		stIdpTraceId = CommonUtil.getTraceId(requestHeader);

		if (stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
			stAppInfo = "Missing or Invalid IdpTraceId";
			return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
			
		if (registerEmailUserReq == null) {
			stAppInfo = "Input Request is NULL / Empty.";
			logger.info("{}{}REURV_01 :: {}", sClassName, sMethodName, stAppInfo);
			return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		registerEmailUserReq.setIdpTraceId(stIdpTraceId);

		// checking Invalid attributes passed in Request
		Map<String, Object> allUnknownAttributes = new HashMap<>(registerEmailUserReq.unknownAttributes);
		if (registerEmailUserReq.getServices() != null && !registerEmailUserReq.getServices().isEmpty()) {
			List<Services> services = registerEmailUserReq.getServices();
			for (Services service : services) {
				allUnknownAttributes.putAll(service.getUnknownAttributes());
			}
		}
		if (registerEmailUserReq.getContacts() != null && !registerEmailUserReq.getContacts().isEmpty()) {
			List<Contact> contacts = registerEmailUserReq.getContacts();
			for (Contact contact : contacts) {
				allUnknownAttributes.putAll(contact.getUnknownAttributes());
			}
		}

		if (!allUnknownAttributes.isEmpty()) {
			stAppInfo = "Invalid Attributes passed in registerEmailUserRequest : " + allUnknownAttributes;
			return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					registerEmailUserReq.getIdpTraceId());
		}

		try {
			registerEmailUserResponse = registerEmailUserReqInputValidator(registerEmailUserReq, requestHeader);
			if (registerEmailUserResponse != null) {
				logger.info("{}{}REURV_04 : Response from registerEmailUserReqInputValidator : {}", sClassName,
						sMethodName, registerEmailUserResponse);
				return registerEmailUserResponse;
			}

			stAppInfo = "Input Validation Successful";
			logger.info("{}{}REURV_05 : {}", sClassName, sMethodName, stAppInfo);

		} catch (Exception e) {
			stAppInfo = "Exception thrown in RegisterEmailUserRequestValidator : " + e.getMessage();
			registerEmailUserResponse = registerEmailUserErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo,
					stIdpTraceId);
			logger.info("{}{}REURV_06: Exception in RegisterEmailUserRequestValidator: {}", sClassName, sMethodName,
					stAppInfo);
		}

		return registerEmailUserResponse;

	}

	private RegisterEmailUserResponse registerEmailUserReqInputValidator(
			@Valid RegisterEmailUserRequest registerEmailUserReq, HttpHeaders requestHeader) {

		String sMethodName = ".registerEmailUserReqInputValidator.";
		String stAppInfo = null;
		String stIdpTraceId = null;

		RegisterEmailUserResponse registerEmailUserResponse = null;

		// mandatory fields
		Optional.ofNullable(registerEmailUserReq.getHandle())
				.ifPresent(x -> registerEmailUserReq.setHandle(x.trim().toLowerCase()));
		Optional.ofNullable(registerEmailUserReq.getDomain())
				.ifPresent(x -> registerEmailUserReq.setDomain(x.trim().toLowerCase()));
		Optional.ofNullable(registerEmailUserReq.getPasswordClear())
				.ifPresent(x -> registerEmailUserReq.setPasswordClear(x.trim()));
		Optional.ofNullable(registerEmailUserReq.getContactEmail())
				.ifPresent(x -> registerEmailUserReq.setContactEmail(x.trim().toLowerCase()));
		Optional.ofNullable(registerEmailUserReq.getFirstName())
				.ifPresent(x -> registerEmailUserReq.setFirstName(x.trim()));
		Optional.ofNullable(registerEmailUserReq.getLastName())
				.ifPresent(x -> registerEmailUserReq.setLastName(x.trim()));
		Optional.ofNullable(registerEmailUserReq.getGender())
				.ifPresent(x -> registerEmailUserReq.setGender(x.trim().toUpperCase()));

		Optional.ofNullable(registerEmailUserReq.getIsExternalCall()).ifPresentOrElse(
				x -> registerEmailUserReq.setIsExternalCall(x.toUpperCase()),
				() -> registerEmailUserReq.setIsExternalCall(CommonDefs.IND_Y));
		
		// OnlineSecurityQuestion validation
		Optional.ofNullable(registerEmailUserReq.getOnline1SecurityQuestion())
				.ifPresent(x -> registerEmailUserReq.setOnline1SecurityQuestion(x.trim()));
		Optional.ofNullable(registerEmailUserReq.getOnline2SecurityQuestion())
				.ifPresent(x -> registerEmailUserReq.setOnline2SecurityQuestion(x.trim()));
		Optional.ofNullable(registerEmailUserReq.getOnline1SecurityAnswer())
				.ifPresent(x -> registerEmailUserReq.setOnline1SecurityAnswer(x.trim().toLowerCase()));
		Optional.ofNullable(registerEmailUserReq.getOnline2SecurityAnswer())
				.ifPresent(x -> registerEmailUserReq.setOnline2SecurityAnswer(x.trim().toLowerCase()));

		String stOnlineSecQues1 = registerEmailUserReq.getOnline1SecurityQuestion();
		String stOnlineSecQues2 = registerEmailUserReq.getOnline2SecurityQuestion();
		String stOnlineSecAns1 = registerEmailUserReq.getOnline1SecurityAnswer();
		String stOnlineSecAns2 = registerEmailUserReq.getOnline2SecurityAnswer();
		if ((stOnlineSecQues1 == null && stOnlineSecAns1 != null)
				|| (stOnlineSecQues1 != null && stOnlineSecAns1 == null)) {
			stAppInfo = "Either of online1SecurityQuestion or online1SecurityAnswer are null or empty.";
			return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					registerEmailUserReq.getIdpTraceId());
		}
		
		if ((stOnlineSecQues2 == null && stOnlineSecAns2 != null)
				|| (stOnlineSecQues2 != null && stOnlineSecAns2 == null)) {
			stAppInfo = "Either of online2SecurityQuestion or online2SecurityAnswer are null or empty.";
			return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					registerEmailUserReq.getIdpTraceId());
		}
		
		String sCallingSystemId = requestHeader.getHeaderString("X-ATT-ClientId");
		if (sCallingSystemId == null || sCallingSystemId.isEmpty()) {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			logger.info("{}{}REURV.IV_01 : {}", sClassName, sMethodName, stAppInfo);
			return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					registerEmailUserReq.getIdpTraceId());
		}

		registerEmailUserReq.setCallingSystemId(sCallingSystemId.toUpperCase());

		registerEmailUserResponse = registerEmailUserCSIValidator(registerEmailUserReq);
		if (registerEmailUserResponse != null) {
			logger.info("{}{}REURV.IV_02 : Response from registerEmailUserCSIValidator : {}", sClassName, sMethodName,
					registerEmailUserResponse);
			return registerEmailUserResponse;
		}
		
		String sHandle = registerEmailUserReq.getHandle();
		if (sHandle != null && sHandle.contains("@")) {
			stAppInfo = "UserId format is not valid, invalid chars";
			logger.info("{}{}REURV.IV_03 :  {} ", sClassName, sMethodName, stAppInfo);
			return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					registerEmailUserReq.getIdpTraceId());
		}

		// valid domain check
		String sDomain = registerEmailUserReq.getDomain();
		ArrayList<String> alValidDomains = null;
		if (propValidDomains != null && !propValidDomains.isEmpty()) {
			alValidDomains = CommonUtil.parseToArray(propValidDomains, CommonDefs.VALUE_SEPARATOR_CHAR);
			logger.info("{}{}REURV.IV_03.01 : RegisterEmailUserValidDomains : {}", sClassName, sMethodName,
					alValidDomains);
			if (alValidDomains != null && !alValidDomains.contains(sDomain)) {
				stAppInfo = "Input domain is invalid";
				logger.info("{}{}REURV.IV_04 :  {} ", sClassName, sMethodName, stAppInfo);
				return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						registerEmailUserReq.getIdpTraceId());
			} else {
				if (sDomain.equals(CommonDefs.SLID_DUM)) {
					stAppInfo = "AccessId registration not allowed for RegisterEmailUser";
					logger.info("{}{}REURV.IV_05 : {}", sClassName, sMethodName, stAppInfo);
					return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
							registerEmailUserReq.getIdpTraceId());
				}
			}
		}

		String sDateOfBirth = registerEmailUserReq.getDateOfBirth();
		if (sDateOfBirth != null && !sDateOfBirth.trim().isEmpty()) {
			sDateOfBirth = sDateOfBirth.trim();
			registerEmailUserReq.setDateOfBirth(sDateOfBirth);
			boolean isValidDOBFormat = false;
			isValidDOBFormat = validateDOBFormat(sDateOfBirth);
			if (!isValidDOBFormat) {
				stAppInfo = "dateOfBirth value is not in mmddyyyy format";
				logger.info("{}{}REURV.IV_06 : {}", sClassName, sMethodName, stAppInfo);
				return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						registerEmailUserReq.getIdpTraceId());
			}
		}

		String sLanguage = registerEmailUserReq.getLanguage();
		if (sLanguage != null && !sLanguage.trim().isEmpty()) {
			sLanguage = sLanguage.trim().toLowerCase();
			registerEmailUserReq.setLanguage(sLanguage);

			ArrayList alValidLanguageList = CommonUtil.parseToArray(propValidLanguages,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			logger.info("{}{}REURV.IV_07 : Property Valid_Languages :  {}", sClassName, sMethodName,
					alValidLanguageList);

			if (alValidLanguageList != null && !alValidLanguageList.contains(sLanguage)) {
				stAppInfo = "Input Language is Invalid ";
				logger.info("{}{}REURV.IV_08 : {}", sClassName, sMethodName, stAppInfo);
				return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						registerEmailUserReq.getIdpTraceId());
			}
		}

		String sContactEmail = registerEmailUserReq.getContactEmail();
		if (sContactEmail != null && !sContactEmail.trim().isEmpty()) {

			boolean isEmailValid = true;
			isEmailValid = isValidEmail(sContactEmail);
			if (!isEmailValid) {
				stAppInfo = "Input contactEmail is invalid";
				logger.info("{}{}REURV.IV_09 : {}", sClassName, sMethodName, stAppInfo);
				return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						registerEmailUserReq.getIdpTraceId());
			}
		}

		String sGender = registerEmailUserReq.getGender();
		if (sGender != null && !sGender.trim().isEmpty()) {
			if (!(sGender.equalsIgnoreCase(CommonDefs.GENDER_M) || sGender.equalsIgnoreCase(CommonDefs.GENDER_F))) {
				stAppInfo = "Input Gender is Invalid :: Should be one of [M, F]";
				logger.info("{}{}REURV.IV_10 : {}", sClassName, sMethodName, stAppInfo);
				return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						registerEmailUserReq.getIdpTraceId());
			}
		}

		String sSor = registerEmailUserReq.getSor();
		if (sSor != null && !sSor.trim().isEmpty()) {
			if (sSor.equalsIgnoreCase(CommonDefs.PORTAL_SVC_SOR)) {
				sSor = sSor.trim().toUpperCase();
				registerEmailUserReq.setSor(sSor);
			} else {
				stAppInfo = "SOR should be " + CommonDefs.PORTAL_SVC_SOR;
				logger.info("{}{}REURV.IV_11 : {}", sClassName, sMethodName, stAppInfo);
				return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						registerEmailUserReq.getIdpTraceId());
			}

		} else {
			registerEmailUserReq.setSor(CommonDefs.PORTAL_SVC_SOR);
		}

		String sAccountType = registerEmailUserReq.getAccountType();
		if (sAccountType != null && !sAccountType.isEmpty()) {
			sAccountType = sAccountType.trim().toUpperCase();
			ArrayList alValidOPRAccountType = CommonUtil.parseToArray(propValidOPRAccountType,
					CommonDefs.VALUE_SEPARATOR_CHAR);

			logger.info("{}{}REURV.IV_12 : Property Valid_OPR_AccountType :  {}", sClassName, sMethodName,
					alValidOPRAccountType);

			if (alValidOPRAccountType != null && !alValidOPRAccountType.contains(sAccountType)) {
				stAppInfo = "Input AccountType is invalid";
				logger.info("{}{}REURV.IV_13 : {}", sClassName, sMethodName, stAppInfo);
				return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						registerEmailUserReq.getIdpTraceId());
			}
			if (sAccountType.equalsIgnoreCase(MPSDefs.DB_BUSINESS)) {
				stAppInfo = "Input Account type is B";
				logger.info("{}{}REURV.IV_14 : {}", sClassName, sMethodName, stAppInfo);
				return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						registerEmailUserReq.getIdpTraceId());
			}
		} else {
			sAccountType = MPSDefs.DB_CONSUMER;
		}
		registerEmailUserReq.setAccountType(sAccountType);

		String sProofingZip = registerEmailUserReq.getProofingZip();
		if (sProofingZip != null && !sProofingZip.trim().isEmpty()) {
			sProofingZip = sProofingZip.trim();
			registerEmailUserResponse = validateAndGetFormattedZip(registerEmailUserReq);
			if (registerEmailUserResponse != null) {
				logger.info("{}{}REURV.IV_15 : Response from validateAndGetFormattedZip : {}", sClassName, sMethodName,
						registerEmailUserResponse);
				return registerEmailUserResponse;
			}
			registerEmailUserReq.setProofingZip(sProofingZip);
		}

		registerEmailUserResponse = validateContact(registerEmailUserReq);
		if (registerEmailUserResponse != null) {
			logger.info("{}{}REURV.IV_16 : Response from validateContact : {}", sClassName, sMethodName,
					registerEmailUserResponse);
			return registerEmailUserResponse;
		}

		registerEmailUserResponse = validateServices(registerEmailUserReq);
		if (registerEmailUserResponse != null) {
			logger.info("{}{}REURV.IV_17 : Response from validateServices : {}", sClassName, sMethodName,
					registerEmailUserResponse);
			return registerEmailUserResponse;
		}

		return registerEmailUserResponse;
	}

	private RegisterEmailUserResponse registerEmailUserCSIValidator(RegisterEmailUserRequest registerEmailUserReq) {

		RegisterEmailUserResponse registerEmailUserResponse = null;

		String sMethodName = ".registerEmailUserCSIValidator.";
		String stAppInfo = null;

		ArrayList<String> alValidCallers = null;

		String sCallingSystemId = registerEmailUserReq.getCallingSystemId();
		String sIsExternalCall = registerEmailUserReq.getIsExternalCall();
		String stIdpTraceId = registerEmailUserReq.getIdpTraceId();

		if (!(sIsExternalCall.equalsIgnoreCase(CommonDefs.IND_Y)
				|| sIsExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
			stAppInfo = "isExternalCall must be one of Y or N";
			logger.info("{}{}REUCSIV_01 :  {} ", sClassName, sMethodName, stAppInfo);
			return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (propValidCallersForRegisterEmailUser != null && !propValidCallersForRegisterEmailUser.isEmpty()) {
			alValidCallers = CommonUtil.parseToArray(propValidCallersForRegisterEmailUser,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			logger.info("{}{}REUCSIV_02 : RegisterEmailUserCallingSystemIds : {}", sClassName, sMethodName,
					alValidCallers);
			if (sIsExternalCall != null && CommonDefs.IND_Y.equals(sIsExternalCall) && alValidCallers != null
					&& !alValidCallers.contains(sCallingSystemId)) {
				stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
				logger.info("{}{}REUCSIV_03 :  {} ", sClassName, sMethodName, stAppInfo);
				return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						registerEmailUserReq.getIdpTraceId());
			}
		}
		return registerEmailUserResponse;
	}

	private RegisterEmailUserResponse registerEmailUserErrorResponse(int appStatusCode, String stAppInfo,
			String stIdpTraceId) {

		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		hmResponse.put(CommonDefs.TRANSACTION_NAME, "RegisterEmailUser");
		return CommonUtilHelper.generateRegisterEmailUserResponse(hmResponse);
	}

	private boolean validateDOBFormat(String sDateofBirth) {
		String sMethodName = ".validateDOBFormat.";
		String sAppInfo = null;
		HashMap<String, Object> hmResult = null;

		SimpleDateFormat sdfrmt = new SimpleDateFormat("MMddyyyy");
		sdfrmt.setLenient(false);
		try {
			Date sParsedDOB = sdfrmt.parse(sDateofBirth);
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			sAppInfo = "Exception thrown validateDOBFormat method :Invalid DOB format passed :" + hmResult;
			logger.info("{}{}REUV.VDOB_01 : {}", sClassName, sMethodName, sAppInfo);
			return false;
		}

		return true;
	}

	private boolean isValidEmail(String email) {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." + "[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
				+ "A-Z]{2,7}$";
		Pattern pat = Pattern.compile(emailRegex);
		if (email == null)
			return false;
		return pat.matcher(email).matches();
	}

	/**
	 * This method is part of the RegisterEmailUserRequestValidator class.
	 * It is responsible for validating and formatting the 'proofingZip' field in the RegisterEmailUserRequest.
	 * The method takes a RegisterEmailUserRequest as input.
	 * The RegisterEmailUserRequest encapsulates the details of the register email user operation to be performed.
	 * The method performs various checks on the 'proofingZip' field such as checking if it's null or empty, 
	 * if it's length is not one of the allowed lengths [5,9,10], if all the characters are not integers, etc.
	 * If any of these checks fail, the method returns an error response.
	 * If the 'proofingZip' field is valid, the method formats it and sets it back to the RegisterEmailUserRequest.
	 * The method then returns a RegisterEmailUserResponse object.
	 * The RegisterEmailUserResponse object encapsulates the result of the register email user operation.
	 *
	 * @param registerEmailUserReq The RegisterEmailUserRequest containing the details of the register email user operation.
	 * @return RegisterEmailUserResponse The response of the register email user operation.
	 */
	public RegisterEmailUserResponse validateAndGetFormattedZip(RegisterEmailUserRequest registerEmailUserReq) {
		String sMethodName = ".validateAndGetFormattedZip.";

		String sZip = registerEmailUserReq.getProofingZip();
		RegisterEmailUserResponse registerEmailUserResponse = null;
		String sAppInfo = null;
		try {
			boolean bIsError = false;
			logger.info("{}{}REUV.ZV_01 : {}", sClassName, sMethodName, sAppInfo);
			if (sZip == null || sZip.trim().length() == 0) {
				sAppInfo = CommonDefs.ZIP + " is null or empty";
				bIsError = true;
			} else {
				int iZipLen = sZip.length();
				logger.info("{}{}REUV.ZV_02 :ProofingZip length::{}", sClassName, sMethodName, iZipLen);

				// If input zip length is not one of 5, 9, or 10, return ERR_INVALID_DATA.
				if (iZipLen == 5 || iZipLen == 9 || iZipLen == 10) {

					// If input zip length is 5 or 9, If all the characters are not integers, return
					// ERR_INVALID_DATA.
					if (iZipLen == 5 || iZipLen == 9) {
						for (int i = 0; i < sZip.length(); i++) {
							if (!Character.isDigit(sZip.charAt(i))) {
								sAppInfo = CommonDefs.ZIP + " should contain all digits [0-9]";
								bIsError = true;
								break;
							}
						}

					} else {// Else (input zip length = 10)
						for (int i = 0; i < sZip.length(); i++) {
//							If 5th (0-5) character is not '-', return ERR_INVALID_DATA
							if (i == 5) {
								if (sZip.charAt(i) != '-') {
									sAppInfo = "Allowed chars for " + CommonDefs.ZIP
											+ " are [0-9] and special char '-' only";
									bIsError = true;
									break;
								}
								// If first 5 characters and last 4 characters are not integers, return
								// ERR_INVALID_DATA
							} else if (!Character.isDigit(sZip.charAt(i))) {
								sAppInfo = "Allowed chars for " + CommonDefs.ZIP
										+ " are [0-9] and special char '-' only";
								bIsError = true;
								break;
							}
						}
					}
				} else {
					sAppInfo = "Input " + CommonDefs.ZIP + " length is not one of the allowed lengths [5,9,10]";
					bIsError = true;
				}
			}
			if (bIsError) {
				logger.info("{}{}REUV.ZV_03 : {}", sClassName, sMethodName, sAppInfo);
				return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo,
						registerEmailUserReq.getIdpTraceId());
			}
		} catch (Exception exp) {

			sAppInfo = "Exception thrown in RegisterEmailUserRequestValidator : " + exp.getMessage();
			registerEmailUserResponse = registerEmailUserErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo,
					registerEmailUserReq.getIdpTraceId());
			logger.info("{}{}REUV.ZV_04: Exception in RegisterEmailUserRequestValidator: {}", sClassName, sMethodName,
					sAppInfo);
			return registerEmailUserResponse;
		}
		return registerEmailUserResponse;
	}

	private RegisterEmailUserResponse validateContact(RegisterEmailUserRequest registerEmailUserReq) {
		String sMethodName = ".validateContact.";
		RegisterEmailUserResponse registerEmailUserResponse = null;
		ArrayList alContacts = (ArrayList) registerEmailUserReq.getContacts();
		Contact inpContact = new Contact();
		HashMap<String, Object> hmResult = null;
		String stAppInfo;

		if (alContacts != null && !alContacts.isEmpty()) {

			if (alContacts.size() > 1) {
				stAppInfo = "Contact can not have more than one contacts details ";
				logger.info("{}{}REUV.VC_01 : {}", sClassName, sMethodName, stAppInfo);
				return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						registerEmailUserReq.getIdpTraceId());
			}
			inpContact = (Contact) alContacts.get(0);
			
			String sContactType = inpContact.getContactType() != null ? inpContact.getContactType().trim().toUpperCase()
					: null;
			String stValidationStatus = inpContact.getValidationStatus();
			String tnContact = inpContact.getTn();
			String sPhoneType = inpContact.getPhoneType() != null ? inpContact.getPhoneType().trim().toUpperCase()
					: null;
			
			if (sContactType == null || sContactType.trim().isEmpty()) {
				stAppInfo = "Contact type can not be null or empty";
				logger.info("{}{}REUV.VC_02 : {}", sClassName, sMethodName, stAppInfo);
				return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						registerEmailUserReq.getIdpTraceId());
			} else {
				if (!sContactType.equalsIgnoreCase(CommonDefs.SMS)) {
					stAppInfo = "ContactType should be SMS";
					logger.info("{}{}REUV.VC_03 : {}", sClassName, sMethodName, stAppInfo);
					return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
							registerEmailUserReq.getIdpTraceId());
				}
				
				// validations required when contactType is SMS
				if (tnContact == null || tnContact.isEmpty()) {
					stAppInfo = "PhoneNumber is required, when contact type is SMS.";
					logger.info("{}{}REUV.VC_03.01 : {}", sClassName, sMethodName, stAppInfo);
					return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
							registerEmailUserReq.getIdpTraceId());
				}
				
				if (tnContact.length() != 10) {
					stAppInfo = "PhoneNumber should be of 10 digits";
					logger.info("{}{}REUV.VC_03.02 : {}", sClassName, sMethodName, stAppInfo);
					return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
							registerEmailUserReq.getIdpTraceId());
				}
				
				if (tnContact != null && !tnContact.matches("[0-9]+")) {
					stAppInfo = "PhoneNumber should be Numeric only";
					logger.info("{}{}REUV.VC_03.02.01 : {}", sClassName, sMethodName, stAppInfo);
					return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
							registerEmailUserReq.getIdpTraceId());
				}
				
				if (sPhoneType == null || sPhoneType.isEmpty()) {
					stAppInfo = "PhoneNumberType is required, when contact type is SMS.";
					logger.info("{}{}REUV.VC_03.03 {}:  ", sClassName, sMethodName, stAppInfo);
					return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
							registerEmailUserReq.getIdpTraceId());
				} else if (!sPhoneType.equals(CommonDefs.PHONE_NUMBER_TYPE_ATTMOBILE)
						&& !sPhoneType.equals(CommonDefs.PHONE_NUMBER_TYPE_MOBILE)) {
					stAppInfo = "Invalid phoneNumberType.";
					logger.info("{}{}REUV.VC_03.04 {}:  ", sClassName, sMethodName, stAppInfo);
					return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
							registerEmailUserReq.getIdpTraceId());
				}
				
			}
			if (stValidationStatus != null && !stValidationStatus.trim().isEmpty()) {
				if (!CommonDefs.CONTACT_VALIDATED.equals(stValidationStatus)) {
					stAppInfo = "Validation Status should be " + CommonDefs.CONTACT_VALIDATED;
					logger.info("{}{}REUV.VC_04 : {}", sClassName, sMethodName, stAppInfo);
					return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
							registerEmailUserReq.getIdpTraceId());
				}
			} else {
				inpContact.setValidationStatus(CommonDefs.CONTACT_VALIDATED);
				inpContact.setContactType(sContactType);
				inpContact.setPhoneType(sPhoneType);
				alContacts.set(0, inpContact);
			}
			registerEmailUserReq.setContacts(alContacts);
			stAppInfo = "Input Contacts Validated";
			logger.info("{}{}REUV.VC_05 : {}", sClassName, sMethodName, stAppInfo);

		} else {
			stAppInfo = "No Contacts to Validate";
			logger.info("{}{}REUV.VC_06 : {}", sClassName, sMethodName, stAppInfo);
		}

		return registerEmailUserResponse;

	}

	private RegisterEmailUserResponse validateServices(RegisterEmailUserRequest registerEmailUserReq) {
		String sMethodName = ".validateServices.";
		String stAppInfo;
		RegisterEmailUserResponse registerEmailUserResponse = null;
		ArrayList alInputService = (ArrayList) registerEmailUserReq.getServices();
		Services inpService = null;
		HashMap<String, Object> hmResult = null;
		if (alInputService != null && !alInputService.isEmpty()) {

			for (int i = 0; i < alInputService.size(); i++) {
				inpService = (Services) alInputService.get(i);
				String sServiceType = inpService.getServiceType();
				String sSor = inpService.getSor();
				String sServiceStatus = inpService.getServiceStatus();
				if (sServiceType == null || sServiceType.trim().isEmpty()) {
					stAppInfo = "Service type should not null or empty";
					logger.info("{}{}REUV.VS_01 : {}", sClassName, sMethodName, stAppInfo);
					return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
							registerEmailUserReq.getIdpTraceId());
				} else {
					if (!sServiceType.equals(CommonDefs.PORTAL_SERVICE)) {
						stAppInfo = "Service type should be PORTAL";
						logger.info("{}{}REUV.VS_02 : {}", sClassName, sMethodName, stAppInfo);
						return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
								registerEmailUserReq.getIdpTraceId());
					} else {
						if (sSor == null || sSor.trim().isEmpty()) {
							sSor = CommonDefs.PORTAL_SVC_SOR;
							inpService.setSor(sSor);
						} else {
							if (!sSor.equals(CommonDefs.PORTAL_SVC_SOR)) {
								stAppInfo = "SOR should be OPR";
								logger.info("{}{}REUV.VS_03 : {}", sClassName, sMethodName, stAppInfo);
								return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
										registerEmailUserReq.getIdpTraceId());
							}
						}
						if (sServiceStatus == null || sServiceStatus.trim().isEmpty()) {
							sServiceStatus = MPSDefs.ENABLED;
							inpService.setServiceStatus(sServiceStatus);
						} else {
							if (!sServiceStatus.equals(MPSDefs.ENABLED)) {
								stAppInfo = "ServiceStatus should be Enabled";
								logger.info("{}{}REUV.VS_04 : {}", sClassName, sMethodName, stAppInfo);
								return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
										registerEmailUserReq.getIdpTraceId());
							}
						}

					}
				}

				alInputService.set(i, inpService);
			}
			registerEmailUserReq.setServices(alInputService);
			stAppInfo = "Input Services Validated";
			logger.info("{}{}REUV.VS_05 : {}", sClassName, sMethodName, stAppInfo);
		} else {
			stAppInfo = "Services can't be null";
			logger.error("{}{}REUV.VS_06v : {}", sClassName, sMethodName, stAppInfo);
			return registerEmailUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					registerEmailUserReq.getIdpTraceId());

		}
		return registerEmailUserResponse;
	}

}
