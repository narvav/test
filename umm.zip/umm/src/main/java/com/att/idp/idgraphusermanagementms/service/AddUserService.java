package com.att.idp.idgraphusermanagementms.service;

import jakarta.ws.rs.core.MultivaluedMap;

import com.att.idp.idgraphusermanagementms.resource.request.AddUserRequest;
import com.att.idp.idgraphusermanagementms.resource.response.AddUserResponse;

/**
 * This interface defines the contract for the AddUserService in the system.
 * It contains a single method addUser which takes an AddUserRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return an AddUserResponse object.
 *
 * The AddUserRequest object encapsulates the details of the user to be added.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
public interface AddUserService {

	/**
	 * This method is part of the AddUserService interface.
	 * It defines the contract for adding a user to the system.
	 *
	 * @param addUserRequest An object encapsulating the details of the user to be added.
	 * @param requestHeader A MultivaluedMap containing the request headers which may include additional information required for processing the request.
	 * @return An AddUserResponse object representing the response from the system after adding the user.
	 */
	AddUserResponse addUser(AddUserRequest addUserRequest, MultivaluedMap<String, String> requestHeader);

}
