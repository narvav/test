package com.att.idp.idgraphusermanagementms.db.repository;

import java.sql.SQLException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.att.idp.idgraphusermanagementms.db.model.Tmember;

/**
 * This is the repository interface for the Member entity.
 * It extends JpaRepository to provide standard data access operations on the Member entity.
 * It also extends MemberRepositoryCustom to provide custom data access operations.
 *
 * @param <Tmember> The type of the entity this repository manages.
 * @param <Long> The type of the id of the entity this repository manages.
 */
@Repository 
public interface MemberRepository extends JpaRepository<Tmember, Long> , MemberRepositoryCustom{
	
	/**
	 * This method is used to retrieve a list of Tmember entities based on the provided member number.
	 *
	 * @param memberNum The member number of the Tmember entities. This is used to search for the Tmember entities in the database.
	 * @return A list of Tmember entities with the provided member number. If no such Tmember entities are found, this method returns an empty list.
	 * @throws SQLException If there is an error while executing the SQL query.
	 */
	@Query(value = "SELECT * "
							+ " FROM "
							+ " MPS_OWNER.TMEMBER mem,MPS_OWNER.TMEMBERGROUP memGroup,MPS_OWNER.TDOMAIN dom, MPS_OWNER.TDOMAIN parentDom, "
							+ " MPS_OWNER.Tsecurityquestion secq, MPS_OWNER.TSYSTEMOFRECORD sor,MPS_OWNER.TNETWORKACCESS acc, MPS_OWNER.TSTATUS stat, " 
							+ " MPS_OWNER.Tsecurityquestion secq1,MPS_OWNER.Tsecurityquestion secq2, MPS_OWNER.TMEMBERAUX memaux "  
							+ " WHERE "
							+ " mem.sor_id = sor.sor_id AND mem.access_id = acc.access_id AND mem.domain_id = dom.domain_id AND memGroup.domain_id=parentDom.domain_id "
							+ " AND mem.security_question_id = secq.security_question_id (+) "
							+ " AND mem.last_member_status = stat.status_code (+) " 
							+ " AND mem.security_question_id_1 =secq1.security_question_id (+) " 
							+ " AND mem.security_question_id_2 =secq2.security_question_id (+) " 
							+ " AND mem.member_num = memaux.member_num (+) "
							+ " AND mem.group_num = memGroup.group_num AND mem.member_num = :memberNum "
							+ " AND mem.parent_child_ind in ('P','C','S')", nativeQuery=true)
	public List<Tmember> getFirstQueryMemNum(@Param(value = "memberNum") Long memberNum) throws SQLException;
	
	/**
	 * This method is used to retrieve a list of Tmember entities based on the provided member name and domain name.
	 *
	 * @param memberName The member name of the Tmember entities. This is used to search for the Tmember entities in the database.
	 * @param domainName The domain name associated with the Tmember entities. This is used in conjunction with the member name to search for the Tmember entities in the database.
	 * @return A list of Tmember entities with the provided member name and domain name. If no such Tmember entities are found, this method returns an empty list.
	 * @throws SQLException If there is an error while executing the SQL query.
	 */
	@Query(value =  "SELECT * "
					+ "FROM MPS_OWNER.TMEMBER mem, MPS_OWNER.TMEMBERGROUP memGroup, MPS_OWNER.TDOMAIN dom, MPS_OWNER.TDOMAIN parentDom, MPS_OWNER.TSECURITYQUESTION secq , "
					+ "MPS_OWNER.TSYSTEMOFRECORD sor, " 
					+ "MPS_OWNER.TNETWORKACCESS acc, MPS_OWNER.TSTATUS stat, MPS_OWNER.TSECURITYQUESTION secq1, MPS_OWNER.TSECURITYQUESTION secq2, "
					+ "MPS_OWNER.TMEMBERAUX memaux "
					+ "WHERE mem.sor_id = sor.sor_id AND mem.access_id = acc.access_id AND mem.domain_id = dom.domain_id "
					+ "AND memGroup.domain_id=parentDom.domain_id AND mem.security_question_id = secq.security_question_id (+) "
					+ "AND mem.last_member_status = stat.status_code (+) "
					+ "AND mem.security_question_id_1 =secq1.security_question_id (+) "
					+ "AND mem.security_question_id_2 =secq2.security_question_id (+) "
					+ "AND mem.member_num = memaux.member_num (+) AND mem.group_num = memGroup.group_num "
					+ "AND mem.member_name = :memberName AND dom.domain_name = :domainName ", nativeQuery=true)
	
	public List<Tmember> getFirstQueryMemDomainName(@Param(value = "memberName") String memberName,
												 @Param(value = "domainName") String domainName) throws SQLException;
	
	/**
	 * This method is used to retrieve a Tmember entity based on the provided member name.
	 *
	 * @param memberName The member name of the Tmember entity. This is used to search for the Tmember entity in the database.
	 * @return A Tmember entity with the provided member name. If no such Tmember entity is found, this method returns null.
	 * @throws SQLException If there is an error while executing the SQL query.
	 */
	@Query(value="select mem from Tmember mem where mem.memberName=:memberName")
	public Tmember getMemberDetailsByMemberNum(@Param(value="memberName") String memberName) throws SQLException;

	
	/**
	 * This method is used to retrieve a list of Tmember entities based on the provided member name and domain name.
	 *
	 * @param memberName The member name of the Tmember entities. This is used to search for the Tmember entities in the database.
	 * @param domainName The domain name associated with the Tmember entities. This is used in conjunction with the member name to search for the Tmember entities in the database.
	 * @return A list of Tmember entities with the provided member name and domain name. If no such Tmember entities are found, this method returns an empty list.
	 * @throws SQLException If there is an error while executing the SQL query.
	 */
    List<Tmember> findByMemberNameAndTdomainDomainName(String memberName, String domainName) throws SQLException;
	
    
    /**
     * This method is used to retrieve a list of Tmember entities based on the provided member number.
     *
     * @param memberNum The member number of the Tmember entities. This is used to search for the Tmember entities in the database.
     * @return A list of Tmember entities with the provided member number. If no such Tmember entities are found, this method returns an empty list.
     * @throws SQLException If there is an error while executing the SQL query.
     */
	List<Tmember> findByMemberNum(Long memberNum) throws SQLException;
}
