package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.*;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TPENDINGACTION", schema = "MPS_OWNER")
public class Tpendingaction extends AuditablePendingAction implements java.io.Serializable {

	private static final long serialVersionUID = 8423223741256413888L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "applicationName", column = @Column(name = "APPLICATION_NAME", nullable = false, length = 30)),
			@AttributeOverride(name = "memberNum", column = @Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)) })
	private TpendingactionId id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MEMBER_NUM", nullable = false, insertable = false, updatable = false)
	private Tmember tmember;

}