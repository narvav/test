package com.att.idp.idgraphusermanagementms.queue.message.helpers;

import java.util.*;

import com.att.mpsys.common.helpers.FeatureManagerHelper;
import org.apache.commons.collections.MapUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * The AddUserQueueHelper class is part of the com.att.idp.idgraphusermanagementms.queue.message.helpers package.
 * It is a helper class that assists in sending messages to the message queue.
 * The class has several methods including sendMessageToMQ and setEventData.
 * sendMessageToMQ is responsible for sending the message to the queue and handling the response.
 * setEventData is responsible for setting the event data from the input HashMap.
 * The class also has several fields including a logger, an instance of PublishMqAehHelper , and various constants.
 */
@Component
public class AddUserQueueHelper {

	public static final Logger log = LoggerFactory.getLogger(AddUserQueueHelper.class);

    @Autowired
    FeatureManagerHelper featureManager;

    @Autowired
    PublishMqAehHelper publishMqAehHelper;
	
	private static final String ERROR_ENUM = "ErrorEnum";
	private static final String MAIL_HOST = "MailHost";
	private static final String MIGRATION_IND = "MigrationInd";
	private String sClassName = "AddUserQueueHelper";

	/**
	 * This method is part of the AddUserQueueHelper class.
	 * It is responsible for sending a message to the message queue.
	 * The method takes a HashMap as input, which contains the message to be sent.
	 * It uses the PublishMqAehHelper  instance to send the message and handles the response.
	 * The method also sets the event data from the input HashMap.
	 * If the response from the PublishMqAehHelper  is empty or unsuccessful, the method returns an error.
	 * If the response is successful, the method returns a success message.
	 *
	 * @param hmInput The HashMap containing the message to be sent.
	 * @return A HashMap containing the response from the PublishMqAehHelper .
	 */
	public Map sendMessageToMQ(Map<String, Object> hmInput) {
		String sMethodName = ".sendMessageToMQ.";
		String stAppInfo;
		String stAppStatusCode = null;
		String stPasswordDirty = (String) hmInput.get(CommonDefs.PASSWORD_DIRTY);
		String stMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
        Map<String, Object> hmResult = CommonUtil.getHashMap();
		 
		// Sets Event data from the hmInput
		HashMap hmEventData = (HashMap) setEventData(hmInput);

        List<Map<String, Object>> alEventData = new ArrayList<>();
        alEventData.add(hmEventData);

		HashMap hmDbusInput = CommonUtil.getHashMap();
		hmDbusInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
		hmDbusInput.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
		hmDbusInput.put(CommonDefs.TRANSACTION_NAME, (String) hmInput.get(CommonDefs.TRANSACTION_NAME));
		hmDbusInput.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		hmDbusInput.put(CommonDefs.EVENTNAME, ProfileOrchestrationConstants.MICROSERVICE_EVENT);
		hmDbusInput.put(CommonDefs.MS_OPERTAION, (String) hmInput.get(CommonDefs.TRANSACTION_NAME));
		hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, stMemberNum);
		if (hmInput.containsKey(CommonDefs.SOURCE_IP_ADDRESS)) {
			hmDbusInput.put(CommonDefs.SOURCE_IP_ADDRESS, (String) hmInput.get(CommonDefs.SOURCE_IP_ADDRESS));
		}
		if (!CommonDefs.ADD_USER_TRANSACTION_NAME.equals((String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME))) {
			if (CommonDefs.REGISTER_OPR_USER_TRANSACTION_NAME
					.equals((String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME))) {
				hmDbusInput.put(CommonDefs.TRANSACTION_NAME, CommonDefs.TRANS_REGISTER_MEMBER);
			}
		}

		if(hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME)!=null &&
				!hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME).equals(ProfileOrchestrationConstants.LINK_MEMBER_TRANSACTION_NAME)) {
			if (CommonDefs.SLID_DUM.equals((String) hmInput.get(CommonDefs.DOMAIN)) && (stPasswordDirty == null
					|| stPasswordDirty.isEmpty() || CommonDefs.IND_N.equalsIgnoreCase(stPasswordDirty))) {

                Map<String, Object> hmCheckDarkWebCredEventData = CommonUtil.getHashMap();
				hmCheckDarkWebCredEventData.put(CommonDefs.EVENTNAME, CommonDefs.CHECK_DARK_WEB_CRED_EVENT_NAME);
				hmCheckDarkWebCredEventData.put(CommonDefs.CLEAR_PASSWORD, (String) hmInput.get(CommonDefs.PASSWORD_CLEAR));
				hmCheckDarkWebCredEventData.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
				hmCheckDarkWebCredEventData.put(CommonDefs.SLID, (String) hmInput.get(CommonDefs.HANDLE));
				hmCheckDarkWebCredEventData.put(CommonDefs.FLOW_TYPE, CommonDefs.HALO_HTMS_FLOW_TYPE_REG);
				hmCheckDarkWebCredEventData.put(CommonDefs.CALLING_SYSTEM_ID,
						(String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
				hmCheckDarkWebCredEventData.put(CommonDefs.TRANSACTION_NAME, CommonDefs.TRANSACTION_NAME_ADD_MEMBER);
				hmCheckDarkWebCredEventData.put(CommonDefs.HASH_KEY, stMemberNum);
				if (!CommonDefs.ADD_USER_TRANSACTION_NAME.equals((String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME))) {
					if (CommonDefs.REGISTER_OPR_USER_TRANSACTION_NAME
							.equals((String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME))) {
						hmCheckDarkWebCredEventData.put(CommonDefs.TRANSACTION_NAME, CommonDefs.TRANS_REGISTER_MEMBER);
					}
				}

				alEventData.add(hmCheckDarkWebCredEventData);
			}
		}
		// End by pm675e

		hmDbusInput.put(CommonDefs.EVENTS_DATA, alEventData);

        //mq aeh switch
        String addUserMQAEHEnabled = featureManager.getValue("cfg-idgraph-adduser-mq-aeh-switch");
        addUserMQAEHEnabled = (addUserMQAEHEnabled != null && !addUserMQAEHEnabled.isEmpty()) ? addUserMQAEHEnabled : "MQ";
        log.info("ixp flag addUserMQAEHEnabled MQ AEH Value: {}", ESAPI.encoder().encodeForHTML(addUserMQAEHEnabled));

        //clm switch
        String addUserClmEnabled = featureManager.getValue("cfg-idgraph-adduser-notification-clm-switch");
        addUserClmEnabled = (addUserClmEnabled != null && !addUserClmEnabled.isEmpty()) ? addUserClmEnabled : "MQ";
        log.info("ixp flag addUserClmEnabled CLM Value: {}", ESAPI.encoder().encodeForHTML(addUserClmEnabled));

        String sCallDbus = (String) hmInput.get(CommonDefs.CALLDBUS);

		if (sCallDbus == null || sCallDbus.trim().isEmpty() || sCallDbus.equalsIgnoreCase(CommonDefs.IND_Y)) {

            hmResult = publishMqAehHelper.invokeMqAEH(hmDbusInput, hmInput, alEventData, sClassName,
                    sMethodName, addUserMQAEHEnabled, addUserClmEnabled);
			
			if (MapUtils.isEmpty(hmResult)) {
				stAppInfo = "Null Response returned from JMSQueueSender.send";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				log.info("{}{}AUQS_03 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {

				stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
				log.info("{}{}AUQS_04 : ", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
				hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
				return hmResult;
			} else {
				hmResult.put("isTransactionRollback", true);
			}
		}
		
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);		
		hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		
		// changes for RegisterEmailUser, where we are not calling DBUS, sending dbus input to helper
		if (sCallDbus != null && sCallDbus.equals(CommonDefs.IND_N)) {
			hmResult.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, hmDbusInput);	
		}
		
		return hmResult;
	}

	/**
	 * @param hmInput
	 * @return hmEventData
	 */
	private Map setEventData(Map<String, Object> hmInput) {
		HashMap hmEventData = CommonUtil.getHashMap();

		hmEventData.put(CommonDefs.CLEAR_PASSWORD, (String) hmInput.get(CommonDefs.PASSWORD_CLEAR));
		hmEventData.put(CommonDefs.FIRST_NAME, (String) hmInput.get(CommonDefs.FIRST_NAME));
		hmEventData.put(CommonDefs.LAST_NAME, (String) hmInput.get(CommonDefs.LAST_NAME));
		hmEventData.put(CommonDefs.DB_ACCOUNT_TYPE, MPSDefs.DB_CONSUMER);
		hmEventData.put(CommonDefs.PARENT_DOMAIN, (String) hmInput.get(CommonDefs.DOMAIN));
		hmEventData.put(MPSDefs.DB_PARENT_DOMAIN, (String) hmInput.get(CommonDefs.DOMAIN));
		hmEventData.put(MPSDefs.DB_CONTACT_EMAIL, (String) hmInput.get(CommonDefs.CONTACT_EMAIL));
		hmEventData.put(MPSDefs.DB_CONTACT_EMAIL_VALID, (String) hmInput.get(CommonDefs.CONTACT_EMAIL_VALID));
		// hmEventData.put(MPSDefs.DB_PARENT_CHILD_IND, "S");
		hmEventData.put(MPSDefs.DB_PARENT_CHILD_IND, (String) hmInput.get(CommonDefs.PARENT_CHILD_IND));
		// hmEventData.put(CommonDefs.PROOFING_VERSION, (String) hmInput.get(CommonDefs.PROOFING_VERSION));
		hmEventData.put(MPSDefs.DB_SOR_NAME, CommonDefs.SOR_NA);
		hmEventData.put(MPSDefs.DB_ENC_PASSWORD, (String) hmInput.get(MPSDefs.DB_ENC_PASSWORD));
		hmEventData.put(CommonDefs.MD5_PASSWORD, (String) hmInput.get(MPSDefs.DB_MD5_PASSWORD));
		hmEventData.put(MPSDefs.DB_DES3_PASSWORD, (String) hmInput.get(MPSDefs.DB_DES3_PASSWORD));
		hmEventData.put(MPSDefs.DB_SHA1_PASSWORD, (String) hmInput.get(MPSDefs.DB_SHA1_PASSWORD));
//		2103 - SSHA-256 encryption changes
		String generic_password = (String) hmInput.get(MPSDefs.DB_GEN_PASSWORD);

		if (generic_password != null && !generic_password.isEmpty()) {
			hmEventData.put(MPSDefs.DB_GEN_PASSWORD, generic_password);
			hmEventData.put(CommonDefs.PASSWORD_TYPE, (String) hmInput.get(MPSDefs.DB_GEN_PASSWORD_TYPE));
		} else {
			hmEventData.put(CommonDefs.PASSWORD_TYPE, CommonDefs.DBUS_SHA_PASSWORDTYPE);
		}
		hmEventData.put(CommonDefs.HANDLE, (String) hmInput.get(CommonDefs.HANDLE));
		hmEventData.put(CommonDefs.DOMAIN, (String) hmInput.get(CommonDefs.DOMAIN));
		hmEventData.put(MPSDefs.DB_MEMBER_NUM, (String) hmInput.get(MPSDefs.DB_MEMBER_NUM));
		hmEventData.put(MPSDefs.DB_SLID_MEMBER_NUM, (String) hmInput.get(MPSDefs.DB_MEMBER_NUM));
		hmEventData.put(CommonDefs.DB_FULLNAME, (String) hmInput.get(CommonDefs.DB_FULLNAME));
		hmEventData.put(CommonDefs.PARENT_HANDLE, (String) hmInput.get(CommonDefs.HANDLE));
		hmEventData.put(CommonDefs.SUBEVENT, CommonDefs.DBUS_NOTIFICATION_SUBEVENT_SLID);
		hmEventData.put(CommonDefs.EVENTNAME, CommonDefs.CONTEXT_AddMember);
		hmEventData.put(CommonDefs.MIGRATION_IND, "null");
		hmEventData.put(CommonDefs.HASH_KEY, (String) hmInput.get(MPSDefs.DB_MEMBER_NUM));
		hmEventData.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
		hmEventData.put(CommonDefs.TRANSACTION_ID,  (String) hmInput.get(ProfileOrchestrationConstants.DBUS_TRANSACTION_ID));
		hmEventData.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));

		String stAutoGenInd = (String) hmInput.get(CommonDefs.AUTO_GENERATED_IND);
		String stActivatedInd = (String) hmInput.get(CommonDefs.ACTIVATED_INDEX);
		String stTosFlag = (String) hmInput.get(CommonDefs.TOS_FLAG);
		String stPasswordDirty = (String) hmInput.get(CommonDefs.PASSWORD_DIRTY);

		Boolean isMIDInRequest = Optional.ofNullable((Boolean) hmInput.get("isMIDInRequest")).orElse(false);

		if (stPasswordDirty != null && !stPasswordDirty.isEmpty()) {
			hmEventData.put(MPSDefs.DB_PASSWORD_DIRTY, stPasswordDirty); // 1907
		}
		if (stAutoGenInd != null && !stAutoGenInd.isEmpty()) {
			hmEventData.put(CommonDefs.AUTO_GENERATED_IND, stAutoGenInd); // 1907
		}
		if (stActivatedInd != null && !stActivatedInd.isEmpty()) {
			hmEventData.put(CommonDefs.ACTIVATED_IND, stActivatedInd);// 1907
		}
		if (stTosFlag != null && !stTosFlag.isEmpty()) {
			hmEventData.put(CommonDefs.TOS_FLAG, stTosFlag);// 1907
		}
		if (isMIDInRequest) {
			hmEventData.remove(CommonDefs.SUBEVENT);
			hmEventData.put(CommonDefs.LANGUAGE, (String) hmInput.get(CommonDefs.LANGUAGE));
			hmEventData.put(CommonDefs.GENDER, (String) hmInput.get(CommonDefs.GENDER));
			hmEventData.put(CommonDefs.DATE_OF_BIRTH, (String) hmInput.get(CommonDefs.DATE_OF_BIRTH));
			hmEventData.put(CommonDefs.MAIL_HOST, (String) hmInput.get(MAIL_HOST));
			hmEventData.put(CommonDefs.MIGRATION_IND, (String) hmInput.get(MIGRATION_IND));
			hmEventData.put(MPSDefs.DB_SOR_NAME, (String) hmInput.get(CommonDefs.SOR));
		}
		if (!CommonDefs.ADD_USER_TRANSACTION_NAME.equals((String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME))) {
			if (CommonDefs.REGISTER_OPR_USER_TRANSACTION_NAME
					.equals((String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME))) {
				hmEventData.put(CommonDefs.TRANSACTION_NAME, CommonDefs.TRANS_REGISTER_MEMBER);
			}
		}
		String origTransactionName = (String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME);
		if (ProfileOrchestrationConstants.LINK_MEMBER_TRANSACTION_NAME.equals(origTransactionName)) {
			hmEventData.put(CommonDefs.TRANSACTION_NAME, ProfileOrchestrationConstants.LINK_MEMBER_TRANSACTION_NAME);
			hmEventData.put(CommonDefs.SUBEVENT, CommonDefs.DBUS_NOTIFICATION_SUBEVENT_SLID);
		} else {
			hmEventData.put(CommonDefs.TRANSACTION_NAME, CommonDefs.CONTEXT_AddMember);
		}
		return hmEventData;
	}

}
