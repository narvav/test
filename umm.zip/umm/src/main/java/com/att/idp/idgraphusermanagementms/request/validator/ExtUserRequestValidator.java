package com.att.idp.idgraphusermanagementms.request.validator;

import com.att.idp.idgraphusermanagementms.resource.request.ExtUserRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ExtUserResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import jakarta.ws.rs.core.HttpHeaders;
import java.util.HashMap;
import java.util.Map;

import static java.util.Optional.ofNullable;

/**
 * This class, ExtUserRequestValidator, is responsible for validating the ExtUserRequest.
 * It checks for the presence and validity of required fields in the request, and returns an ExtUserResponse accordingly.
 * It is annotated with @Component, @Configuration, and @PropertySource to indicate that it's a Spring Bean,
 * to allow it to access configuration properties, and to specify the location of the properties file respectively.
 *
 * The class contains several methods, including:
 * - extUserReqValidator: the main method that orchestrates the validation process.
 * - extUserErrorResponse: a helper method that generates an error response.
 * - extUserInputValidator: a method that validates the input fields in the request.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class ExtUserRequestValidator {
    private static final Logger logger = LoggerFactory.getLogger(ExtUserRequestValidator.class);

    private final String sClassName = "ExtUserRequestValidator";

    @Value("${ExtUserCallingSystemIds}")
    private String propExtUserCallingSystemIds;

    @Value("${ValidFNStatus}")
    private String propValidFNStatus;

    /**
     * This method is responsible for validating the ExtUserRequest.
     * It takes HttpHeaders and ExtUserRequest as parameters.
     * HttpHeaders contains the request headers which may include additional information required for processing the request.
     * ExtUserRequest encapsulates the details of the external user operation to be performed.
     *
     * The method performs various checks and validations on the input parameters and returns an ExtUserResponse object.
     * The ExtUserResponse object encapsulates the result of the external user operation.
     *
     * @param requestHeader The HttpHeaders containing the request headers.
     * @param extUserRequest The ExtUserRequest containing the details of the external user operation.
     * @return ExtUserResponse The response of the external user operation.
     */
    public ExtUserResponse extUserReqValidator(HttpHeaders requestHeader, ExtUserRequest extUserRequest) {

        ExtUserResponse extUserResponse = null;

        String sMethodName = ".ExtUserRequestValidator.";
        String stAppInfo = null;
        String stIdpTraceId = null;
        String stXAttClientId = null;
        String sTransactionName = null;

        stIdpTraceId = CommonUtil.getTraceId(requestHeader);

		if (stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
			stAppInfo = "Missing or Invalid IdpTraceId";
			return extUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId, sTransactionName);
		}

        if (extUserRequest == null) {
            stAppInfo = "Input Request is NULL / Empty.";
            logger.info("{}{}EURV_01 :: {}", sClassName, sMethodName, stAppInfo);
            return extUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId, sTransactionName);
        }

        sTransactionName = extUserRequest.getTransactionName();
		extUserRequest.setIdpTraceId(stIdpTraceId);

        if (requestHeader.getHeaderString("X-ATT-ClientId") != null) {
            stXAttClientId = requestHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
            logger.info("{}{} EURV_05 : Setting callingSystemId: {}", sClassName, sMethodName,StringUtils.normalizeSpace(stXAttClientId));
            extUserRequest.setCallingSystemId(stXAttClientId);
        }
        else {
            stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
            logger.info("{}{} EURV_05 :: {}", sClassName, sMethodName, stAppInfo);
            return extUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId, sTransactionName);
        }

        Map<String,Object> allUnknownAttributes = new HashMap<>(extUserRequest.unknownAttributes);

        if(extUserRequest.getUserUnlock() != null && !extUserRequest.getUserUnlock().isEmpty() && !sTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.UPDATE_EXTUSER_TRANSACTION_NAME)){
            allUnknownAttributes.put("userUnlock",extUserRequest.getUserUnlock());
        }
        if (!allUnknownAttributes.isEmpty()) {
            stAppInfo = "Invalid Attributes passed in extUserRequest : " + allUnknownAttributes;
            logger.info("{}{} EURV_06 : {} " ,sClassName ,sMethodName,StringUtils.normalizeSpace(stAppInfo));
            return extUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId, sTransactionName);
        }

        try {
            extUserResponse = extUserInputValidator(extUserRequest);
            if (extUserResponse != null) {
                logger.info("{}{} EURV_07 : Response from ExtUserInputValidator : {}", sClassName, sMethodName,
                        extUserResponse);
                return extUserResponse;
            }else {
                logger.info("{}{}EURV_07 Success Response from extUserInputValidator ", sClassName,
                        sMethodName);
            }

            stAppInfo = "Input Validation Successful";
            logger.info("{}{}EURV_08 : {}", sClassName, sMethodName, stAppInfo);

        } catch (Exception e) {
            stAppInfo = "Exception thrown in ExtUserRequestValidator : "
                    + e.getMessage();
            extUserResponse = extUserErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo,
                    stIdpTraceId, sTransactionName);
            logger.info("{}{}EURV_09: Exception in ExtUserRequestValidator: {}", sClassName, sMethodName, stAppInfo);
        }

        return extUserResponse;
    }

    private ExtUserResponse extUserErrorResponse(int appStatusCode, String stAppInfo, String stIdpTraceId, String sTransactionName) {
        Map<String, Object> hmResponse = CommonUtil.getHashMap();
        hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
        hmResponse.put("idp-trace-id", stIdpTraceId);
        hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
        hmResponse.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
        return CommonUtilHelper.generateExtUserResponse(hmResponse);
    }

    private ExtUserResponse extUserInputValidator(ExtUserRequest extUserRequest) {

        ExtUserResponse extUserResponse = null;
        String stAppInfo = null;
        String sMethodName = ".extUserInputValidator.";

        ofNullable(extUserRequest.getExtGuid()).ifPresent(x -> extUserRequest.setExtGuid(x.trim()));
        ofNullable(extUserRequest.getUserId()).ifPresent(x -> extUserRequest.setUserId(x.trim().toLowerCase()));
        ofNullable(extUserRequest.getContactEmail()).ifPresent(x -> extUserRequest.setContactEmail(x.trim().toLowerCase()));
        ofNullable(extUserRequest.getFirstName()).ifPresent(x -> extUserRequest.setFirstName(x.trim()));
        ofNullable(extUserRequest.getLastName()).ifPresent(x -> extUserRequest.setLastName(x.trim()));
        ofNullable(extUserRequest.getLinkedFNUserId()).ifPresent(x -> extUserRequest.setLinkedFNUserId(x.trim().toLowerCase()));
        ofNullable(extUserRequest.getAgentId()).ifPresent(x -> extUserRequest.setAgentId(x.trim().toLowerCase()));
        ofNullable(extUserRequest.getIdpTraceId()).ifPresent(x -> extUserRequest.setIdpTraceId(x.trim()));
        ofNullable(extUserRequest.getIsExternalCall()).ifPresent(x -> extUserRequest.setIsExternalCall(x.trim().toUpperCase()));
        ofNullable(extUserRequest.getPasswordClear()).ifPresent(x -> extUserRequest.setPasswordClear(x.trim()));
        ofNullable(extUserRequest.getUserUnlock()).ifPresent(x -> extUserRequest.setUserUnlock(x.trim().toUpperCase()));
        ofNullable(extUserRequest.getCallingSystemId()).ifPresent(x -> extUserRequest.setCallingSystemId(x.trim().toUpperCase()));
        ofNullable(extUserRequest.getContactEmailRTValidFlag()).ifPresent(x -> extUserRequest.setContactEmailRTValidFlag(x.trim().toUpperCase()));
        ofNullable(extUserRequest.getAccessIdRTValidFlag()).ifPresent(x -> extUserRequest.setAccessIdRTValidFlag(x.trim().toUpperCase()));
        ofNullable(extUserRequest.getLinkedFNUserStatus()).ifPresent(x -> extUserRequest.setLinkedFNUserStatus(x.trim().toLowerCase()));

        String stUserId = extUserRequest.getUserId();
        String stIdpTraceId = extUserRequest.getIdpTraceId();
        String stIsExternalCall = extUserRequest.getIsExternalCall();
        String stTransactionName = extUserRequest.getTransactionName();
        String stLinkedFNUserStatus = extUserRequest.getLinkedFNUserStatus();

        String stFirstName = extUserRequest.getFirstName();
        if (stFirstName != null && !stFirstName.isEmpty() && stFirstName.length() > 50) {
            extUserRequest.setFirstName(stFirstName.substring(0, 50));
        }
        String stLastName = extUserRequest.getLastName();
        if (stLastName != null && !stLastName.isEmpty() && stLastName.length() > 50) {
            extUserRequest.setLastName(stLastName.substring(0, 50));
        }

        if(stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.ADD_EXTUSER_TRANSACTION_NAME) && (stUserId == null || stUserId.isEmpty())){
            stAppInfo = "userId is required in input request.";
            logger.info("{}{}EURV_EUIV_02.1 : {}", sClassName, sMethodName, stAppInfo);
            return extUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId, stTransactionName);
        }

       if (!CommonUtil.parseToArray(propExtUserCallingSystemIds, CommonDefs.VALUE_SEPARATOR_CHAR).contains(extUserRequest.getCallingSystemId())) {
            stAppInfo = "Invalid CallingSystemID.";
            logger.info("{}{}EURV_EUIV_06 {}:  " ,sClassName ,sMethodName,stAppInfo);
            return extUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM,stAppInfo, stIdpTraceId, stTransactionName);
       }
       if (!(CommonUtil.parseToArray(propValidFNStatus, CommonDefs.VALUE_SEPARATOR_CHAR).contains(stLinkedFNUserStatus))) {
            stAppInfo = "Invalid LinkedFNUserStatus.";
            logger.info("{}{}EURV_EUIV_07 {}:  " ,sClassName ,sMethodName,stAppInfo);
           return extUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM,stAppInfo, stIdpTraceId, stTransactionName);
       }

        if ((stIsExternalCall != null && !stIsExternalCall.isEmpty())) {
            if (!(stIsExternalCall.equalsIgnoreCase(CommonDefs.IND_Y) || stIsExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
                stAppInfo = "isExternalCall must be one of Y or N";
                logger.info("{}{}EURV_EUIV_08 {}:  " ,sClassName ,sMethodName,stAppInfo);
                return extUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId, stTransactionName);
            }
        } else {
            extUserRequest.setIsExternalCall(CommonDefs.IND_Y);
        }
        return extUserResponse;
    }
}