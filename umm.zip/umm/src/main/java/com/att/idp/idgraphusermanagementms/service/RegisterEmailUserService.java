package com.att.idp.idgraphusermanagementms.service;

import jakarta.ws.rs.core.MultivaluedMap;

import com.att.idp.idgraphusermanagementms.resource.request.RegisterEmailUserRequest;
import com.att.idp.idgraphusermanagementms.resource.response.RegisterEmailUserResponse;

/**
 * This interface defines the contract for the RegisterEmailUserService in the system.
 * It contains a single method registerEmailUser which takes a RegisterEmailUserRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return a RegisterEmailUserResponse object.
 *
 * The RegisterEmailUserRequest object encapsulates the details of the email user registration to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
public interface RegisterEmailUserService {
	
	
	/**
	 * This method is part of the RegisterEmailUserService interface.
	 * It defines the contract for registering an email user in the system.
	 *
	 * @param registerEmailUserRequest An object encapsulating the details of the email user registration to be performed.
	 * @param requestHeader A MultivaluedMap containing the request headers which may include additional information required for processing the request.
	 * @return A RegisterEmailUserResponse object representing the response from the system after registering the email user.
	 */
	RegisterEmailUserResponse registerEmailUser(RegisterEmailUserRequest registerEmailUserRequest, MultivaluedMap<String, String> requestHeader);

}
