package com.att.idp.idgraphusermanagementms.resource.request;

import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class represents a request to unlink a member ID in the system.
 * It contains fields for transactionName, callingSystemId, accessId, memberId, domain, agentId, res2bus, isExternalCall, idpTraceId, and a map for unknownAttributes.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 *
 */
@Schema(name = "UnlinkMemberIdRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class UnlinkMemberIdRequest {
	
	private final String transactionName = "UnlinkInternetAccount";
	
	private String callingSystemId;

	@Schema(name = "accessId")
	@Size(min = 1, max = 127, message =  "accessId length is invalid|UnlinkInternetAccount")
	@NotNull(message = "accessId is required in request|UnlinkInternetAccount")
	private String accessId;
	
	@Schema(name = "memberId")
	@Size(min = 1, max = 127, message =  "memberId length is invalid|UnlinkInternetAccount")
	@NotNull(message = "memberId is required in request|UnlinkInternetAccount")
	private String memberId;
	
	@Schema(name = "domain")
	@Size(min = 1, max = 30, message =  "domain length is invalid|UnlinkInternetAccount")
	@NotNull(message = "domain is required in request|UnlinkInternetAccount")
	private String domain;
	
	@Schema(name = "agentId")
	@Size(min=1,max=20,message="agentId length is invalid|UnlinkInternetAccount")
	private String agentId;
	
	@Schema(name = "res2bus")
	@Size(min=1,max=1,message="res2bus length is invalid|UnlinkInternetAccount")
	private String res2bus;

	private String isExternalCall;

	@Schema(name = "idpTraceId")
	private String idpTraceId;
	
	/**
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
	 * @return Map<String,Object> The map of unknown attributes.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();
	
}
