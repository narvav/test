package com.att.idp.idgraphusermanagementms.helper;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Date;

import org.slf4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.att.mpsys.common.utils.PropertyManager;
import com.att.mpsys.common.utils.CommonDefs;

/**
 * The HandleGenerationAlgorithm class is responsible for generating unique user handles.
 * It uses a series of rules and algorithms to create handle suggestions based on given words.
 * The class also ensures that the generated handles are unique and do not contain any inappropriate words.
 * It is annotated with @Component, meaning it is an autodetectable Spring Bean and can be automatically wired into other components using Spring's dependency injection facilities.
 * It is also annotated with @Scope("prototype"), meaning a new instance will be created each time it is requested from the Spring application context.
 */
@Component
//@Scope(value="prototype", proxyMode=ScopedProxyMode.TARGET_CLASS)
@Scope("prototype")
public class HandleGenerationAlgorithm {
	private static final boolean APPEND_TIME_TRUE = true;
	private static final boolean APPEND_TIME_FALSE = false;
	private String LEGAL_SEPARATORS = "";
	private static final String LEGAL_CHARS = "abcdefghijklmnopqrstuvwxyz";
	private int HANDLE_LENGTH_MAX = 18;
	private static final int HANDLE_RANDOM_ALPHAS = 6;
	private static final int WORD_LENGTH_MAX = 9;
	private static final int TIME_DIGITS = 4;
	private static final int numLegalChars = LEGAL_CHARS.length();
	// UTILITY objects

	// [R2002] : Veracode fix : Use SecureRandom in place of Random.
	// private Random rng = new Random();
	private SecureRandom rng = new SecureRandom();

	private ArrayList<String> knownSuggestions = new ArrayList<String>(60);
	private Date timeStamp;
	// instance-scoped variables
	private int myCount0 = 0;
	private int myCount1 = 0;
	private int myCount2 = 0;
	private int myCount3 = 0;
	private int myCount4 = 0;
	private int myCount5 = 0;
	private int myCount6 = 0;
	private int myCount7 = 0;

	private StringBuilder myWord1 = new StringBuilder();
	private StringBuilder myWord2 = new StringBuilder();
	private StringBuilder mySuggestion = new StringBuilder();
	private StringBuilder myTemp = new StringBuilder();

	/**
	 * This method generates a unique user handle based on the given words, domain, and other parameters.
	 * It first converts the given words to lowercase and adjusts the maximum handle length based on the domain.
	 * Then, it creates a handle suggestion based on the given words.
	 * If the run environment is "TEST" and ignoreQay is not set to "yes", it prepends "qay" to the handle suggestion.
	 * If an exception occurs during the process, it logs the stack trace.
	 *
	 * @param givenWord1 The first word to be used in generating the handle.
	 * @param givenWord2 The second word to be used in generating the handle.
	 * @param domain The domain for which the handle is being generated.
	 * @param ignoreQay A flag indicating whether to ignore the "qay" prefix in the handle suggestion.
	 * @param logger The logger to be used for logging any exceptions.
	 * @return A String representing the generated handle.
	 * @throws Exception If any error occurs during the handle generation process.
	 */
	public String createHandle(String givenWord1, String givenWord2, String domain, String ignoreQay, Logger logger) {
		// Returns a handle suggestion based on the suggestionCount
		// to determine which handle generation algorithm to be used
		// and then return the lowercased result
		// This version requires two Strings
		// Reset counters if the words have changed
		// NOTE: as of 2002.02.19 resetCounters() is called by
		// HandleReservationServer.GetHandles();
		String retHandle = "";
		try {
			LEGAL_SEPARATORS = "._-";
			myWord1.delete(0, myWord1.length());
			myWord2.delete(0, myWord2.length());
			myWord1.append(givenWord1.toLowerCase());
			myWord2.append(givenWord2.toLowerCase());

			if (domain != null && domain.equals(CommonDefs.SLID_DUM)) {
				HANDLE_LENGTH_MAX = 127;
			}
			// If givenWord1 is empty string, create handle suggestion using givenWord2
			// Otherwise use both strings to create a handle suggestion

			if (givenWord2.equals("")) {
				retHandle = createWithOneWord();
			} else {
				retHandle = createWithTwoWords();
			}

			String runenv = PropertyManager.getProperty(CommonDefs.MOUPConfig, CommonDefs.RILHRS_ENV);

			if (runenv != null && runenv.trim().length() > 0) {
				if ((runenv.trim().equalsIgnoreCase("TEST"))
						&& (ignoreQay == null || !ignoreQay.trim().equals(CommonDefs.DEFAULT_YES))) {
					if (!retHandle.startsWith("qay")) {
						if (domain != null && domain.equals(CommonDefs.SLID_DUM)) {
							if (retHandle.length() < 125) {
								// 2202 remove QAY enforcement restriction on accessIds
								retHandle = retHandle;
							}
						} else if (retHandle.length() < 16) {
							retHandle = "qay" + retHandle;
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error("Exception occured in HandleGenerationAlgorithm.createHandle() : " + e);
			StackTraceElement[] stack = e.getStackTrace();
			for (StackTraceElement s : stack) {
				logger.error("EXCP : " + s.toString());
			}

		}
		return retHandle;
	}

	private String createWithOneWord() {
		// Create suggestion with one string - the global StringBuffer myWord1
		// myCount0 tracks the current case. myCount0 is reset externally by a call to
		// resetCounters();
		// Loop until the handle suggestions are unique
		do {
			switch (myCount0) {
			case 0:
				suggestRule_1(APPEND_TIME_FALSE);
				break;
			case 1:
				suggestRule_1(APPEND_TIME_TRUE);
				break;
			case 2:
				suggestRule_1(APPEND_TIME_TRUE);
				break;
			case 3:
				suggestRule_1(APPEND_TIME_TRUE);
				break;
			case 4:
				suggestRule_1(APPEND_TIME_TRUE);
				break;
			case 5:
				suggestRule_1(APPEND_TIME_TRUE);
				break;
			case 6:
				suggestRule_1(APPEND_TIME_TRUE);
				break;
			default:
				suggestRule_RNG(APPEND_TIME_TRUE);
			}
			myCount0++;
		} while (knownSuggestions.contains(mySuggestion.toString()));

		// Add the handle suggestion to the knownSuggestions list so that we can ensure
		// that
		// we always return unique handle suggestions
		knownSuggestions.add(mySuggestion.toString());
		return mySuggestion.toString();
	}

	private String createWithTwoWords() {
		// Create suggestion with both strings - the global StringBuffers myWord1 and
		// myWord2
		// myCount1 tracks the current case. myCount1 is reset externally by a call to
		// resetCounters();
		// Loop until the handle suggestions are unique
		do {
			switch (myCount1) {
			// THERE ARE 26 UNIQUE_HANDLE_RULES, but most are variants except for the
			// separator
			case 0:
				suggestRule_1(APPEND_TIME_FALSE);
				break;
			case 1:
				suggestRule_2(APPEND_TIME_FALSE);
				break;
			case 2:
			case 3:
			case 4:
			case 5:
				suggestRule_3(APPEND_TIME_FALSE);
				break;
			case 6:
			case 7:
			case 8:
			case 9:
				suggestRule_4(APPEND_TIME_FALSE);
				break;
			case 10:
			case 11:
			case 12:
			case 13:
				suggestRule_5(APPEND_TIME_FALSE);
				break;
			case 14:
			case 15:
			case 16:
			case 17:
				suggestRule_6(APPEND_TIME_FALSE);
				break;
			case 18:
			case 19:
			case 20:
			case 21:
				suggestRule_7(APPEND_TIME_FALSE);
				break;
			case 22:
			case 23:
			case 24:
			case 25:
				suggestRule_8(APPEND_TIME_FALSE);
				break;
			// SAME AS ABOVE, BUT FOR ADDING appendTime();
			case 26:
				suggestRule_1(APPEND_TIME_TRUE);
				break;
			case 27:
				suggestRule_2(APPEND_TIME_TRUE);
				break;
			case 28:
			case 29:
			case 30:
			case 31:
				suggestRule_3(APPEND_TIME_TRUE);
				break;
			case 32:
			case 33:
			case 34:
			case 35:
				suggestRule_4(APPEND_TIME_TRUE);
				break;
			case 36:
			case 37:
			case 38:
			case 39:
				suggestRule_5(APPEND_TIME_TRUE);
				break;
			case 40:
			case 41:
			case 42:
			case 43:
				suggestRule_6(APPEND_TIME_TRUE);
				break;
			case 44:
			case 45:
			case 46:
			case 47:
				suggestRule_7(APPEND_TIME_TRUE);
				break;
			case 48:
			case 49:
			case 50:
			case 51:
				suggestRule_8(APPEND_TIME_TRUE);
				break;

			default:
				suggestRule_RNG(APPEND_TIME_TRUE);
			}
			myCount1++;
		} while (knownSuggestions.contains(mySuggestion.toString()));

		// Add the handle suggestion to the knownSuggestions list so that we can ensure
		// that
		// we always return unique handle suggestions
		knownSuggestions.add(mySuggestion.toString());
		return mySuggestion.toString();
	}

	private void suggestRule_1(boolean addTime) {
		// Returns Word1
		mySuggestion.delete(0, mySuggestion.length());
		mySuggestion.append(myWord1);

		if (addTime) {
			truncateSuggestion(HANDLE_LENGTH_MAX - TIME_DIGITS);
			appendTime();
		} else {
			truncateSuggestion(HANDLE_LENGTH_MAX);
		}
	}

	// Returns Word2
	private void suggestRule_2(boolean addTime) {
		mySuggestion.delete(0, mySuggestion.length());
		mySuggestion.append(myWord2);
		if (addTime) {
			truncateSuggestion(HANDLE_LENGTH_MAX - TIME_DIGITS);
			appendTime();
		} else {
			truncateSuggestion(HANDLE_LENGTH_MAX);
		}
	}

	private void suggestRule_3(boolean addTime) {
		// Returns Word1 + LEGAL_SEPARATOR + Word2
		// myCount2 tracks the current separator to use. myCount2 is reset externally by
		// a call to resetCounters();
		createSuggestion(myWord1, myWord2, myCount2, addTime);
		myCount2++;
	}

	private void suggestRule_4(boolean addTime) {
		// Returns Word2 + LEGAL_SEPARATOR + Word1
		// myCount3 tracks the current separator to use. myCount3 is reset externally by
		// a call to resetCounters();
		createSuggestion(myWord2, myWord1, myCount3, addTime);
		myCount3++;
	}

	private void suggestRule_5(boolean addTime) {
		// Returns Word1 + LEGAL_SEPARATOR + INITWord2
		// myCount4 tracks the current separator to use. myCount4 is reset externally by
		// a call to resetCounters();
		myTemp.delete(0, myTemp.length());
		myTemp.append(myWord2.charAt(0));
		createSuggestion(myWord1, myTemp, myCount4, addTime);
		myCount4++;
	}

	private void suggestRule_6(boolean addTime) {
		// Returns INITWord1 + LEGAL_SEPARATOR + Word2
		// myCount5 tracks the current separator to use. myCount5 is reset externally by
		// a call to resetCounters();
		myTemp.delete(0, myTemp.length());
		myTemp.append(myWord1.charAt(0));
		createSuggestion(myTemp, myWord2, myCount5, addTime);
		myCount5++;
	}

	private void suggestRule_7(boolean addTime) {
		// Returns Word2 + LEGAL_SEPARATOR + INITWord1
		// myCount6 tracks the current separator to use. myCount6 is reset externally by
		// a call to resetCounters();
		myTemp.delete(0, myTemp.length());
		myTemp.append(myWord1.charAt(0));
		createSuggestion(myWord2, myTemp, myCount6, addTime);
		myCount6++;
	}

	private void suggestRule_8(boolean addTime) {
		// Returns INITWord2 + LEGAL_SEPARATOR + Word1
		// myCount7 tracks the current separator to use. myCount7 is reset externally by
		// a call to resetCounters();
		myTemp.delete(0, myTemp.length());
		myTemp.append(myWord2.charAt(0));
		createSuggestion(myTemp, myWord2, myCount7, addTime);
		myCount7++;
	}

	private void suggestRule_RNG(boolean addTime) {
		// Creates a random string with numbers
		// This is really the very last resort handle suggestion method. It creates ugly
		// handles like ayejhda9918
		mySuggestion.delete(0, mySuggestion.length());
		for (int i = 0; i < HANDLE_RANDOM_ALPHAS; i++) {
			mySuggestion.append(LEGAL_CHARS.charAt(Math.abs(rng.nextInt() % numLegalChars)));
		}
		if (addTime) {
			truncateSuggestion(HANDLE_LENGTH_MAX - TIME_DIGITS);
			appendTime();
		} else {
			truncateSuggestion(HANDLE_LENGTH_MAX);
		}
	}

	private void appendTime() {
		// Adds the time to the handle mySuggestion StringBuffer
		mySuggestion.append(getTimeAndReverseIt());
	}

	private String getTimeAndReverseIt() {
		// Returns 4-digit timestamp
		// The portion where it subracts myCount0 and myCount1 are to
		// guarantee that the timestamp is unique since
		// it is often that the timestamp for all handles suggested are the
		// same 4 digits!
		timeStamp = new Date();
		long ms = 9999 - (timeStamp.getTime() % 10000);

		if (ms < 10) {
			return ("000" + String.valueOf(ms));
		}
		if (ms < 100) {
			return ("00" + String.valueOf(ms));
		}
		if (ms < 1000) {
			return ("0" + String.valueOf(ms));
		}
		// adding random generated number
		ms = ms + (Math.abs(rng.nextInt() % numLegalChars));
		return String.valueOf(ms);
	}

	private void truncateSuggestion(int maxLength) {
		// Truncates mySuggestion to a given length
		if (mySuggestion.length() > maxLength) {
			mySuggestion.setLength(maxLength);
		}
	}

	private void createSuggestion(StringBuilder tempWord1, StringBuilder tempWord2, int tempMyCounter,
			boolean tempAddTime) {
		// Returns tempWord1 + LEGAL_SEPARATOR + tempWord2 + tempAppendTime
		// This function takes arguments, but operates on the class-scoped StringBuffer
		// mySuggestion
		mySuggestion.setLength(0);
		mySuggestion.delete(0, mySuggestion.length());
		mySuggestion.append(tempWord1);
		int separatorIndex = 0;
		int numLegalSeparators = LEGAL_SEPARATORS.length();
		separatorIndex = tempMyCounter % (1 + numLegalSeparators);

		if (separatorIndex > 0) {
			// Truncate enough room for the timestamp, half of the max handle length, and
			// minus 1 extra space for the separator
			// And then add the separator
			if (tempAddTime) {
				truncateSuggestion(WORD_LENGTH_MAX - TIME_DIGITS / 2 - 1);
			} else {
				truncateSuggestion(WORD_LENGTH_MAX - 1);
			}
			mySuggestion.append(String.valueOf(LEGAL_SEPARATORS.charAt(separatorIndex - 1)));
		} else {
			// Truncate enough room for the timestamp, half of the max handle length
			if (tempAddTime) {
				truncateSuggestion(WORD_LENGTH_MAX - TIME_DIGITS / 2);
			} else {
				truncateSuggestion(WORD_LENGTH_MAX);
			}
		}
		mySuggestion.append(tempWord2);
		if (tempAddTime) {
			truncateSuggestion(HANDLE_LENGTH_MAX - TIME_DIGITS);
			appendTime();
		} else {
			truncateSuggestion(HANDLE_LENGTH_MAX);
		}
	}

	/**
	 * this method reset all method counters that were used to track separators
	 */
	public void resetCounters() {
		// Reset all method counters that were used to track separators
		// This is called by HandleReservationServer
		myCount0 = 0;
		myCount1 = 0;
		myCount2 = 0;
		myCount3 = 0;
		myCount4 = 0;
		myCount5 = 0;
		myCount6 = 0;
		myCount7 = 0;
		// Also clear the knownSuggestions Vector so that we can start again

		knownSuggestions.clear();
	}
}