package com.att.idp.idgraphusermanagementms.db.repository;

import java.io.Serializable;

import jakarta.persistence.EntityManager;

import org.hibernate.LockOptions;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

/**
 * This is a custom repository class for IDM profile orchestration.
 * It provides custom methods for operations that are not provided by the JpaRepository.
 *
 * @param <T> The type of the entity this repository manages.
 * @param <I> The type of the id of the entity this repository manages.
 */
public class IDMProfileOrchestrationCustomRepository<T, I> {

	@Autowired
	@Qualifier("entityManagerFactory")
	protected EntityManager entityManager;

	/**
	 * This method is used to get the current Hibernate Session.
	 *
	 * @return The current Hibernate Session. If there is no current session, this method will create a new one.
	 */
	public Session getSession() {
		return entityManager.unwrap(Session.class);
	}

	protected Class<T> getClassT() {

		return null;
	}

	/**
	 * This method is used to get the entity by its ID with a write lock.
	 *
	 * @param id The ID of the entity. This is used to search for the entity in the database.
	 * @return The entity with the provided ID. If no entity with the provided ID is found, this method returns null.
	 */
	public T getByIdWithWriteLock(I id) {

		return (T) getSession().get(getClassT(), (Serializable) id, LockOptions.READ);
	}
}
