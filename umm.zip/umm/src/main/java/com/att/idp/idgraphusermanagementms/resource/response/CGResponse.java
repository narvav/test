package com.att.idp.idgraphusermanagementms.resource.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * This class represents the CGResponse in the system.
 * It contains a field for subscribers.
 *
 * The class uses Jackson's @JsonIgnoreProperties and @JsonInclude annotations to handle JSON serialization and deserialization.
 * It also uses Swagger's @ApiModel annotation to provide metadata for the Swagger UI.
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(name = "CGResponse")
public class CGResponse {
	private Subscribers subscribers;

}