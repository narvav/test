package com.att.idp.idgraphusermanagementms.resource.request;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import static org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString;
import static org.apache.commons.lang3.builder.ToStringStyle.JSON_STYLE;

/**
 * This class is part of the com.att.idp.idgraphusermanagementms.resource.request package.
 *
 * The Letter class implements the Serializable interface, allowing instances of this class to be converted into a byte stream.
 *
 * The class is used to represent a Letter object, which contains several fields related to a physical address.
 * These fields include name, street1, street2, city, state, zipCode, zipPlusFour, and country.
 *
 * Each field is annotated with @Size and/or @NotNull, indicating that they are required fields and have size constraints.
 * The messages associated with these annotations provide additional information about the requirements for each field.
 *
 * The class provides a no-argument constructor, as well as getter and setter methods for each field.
 * It also overrides the toString method, providing a custom string representation of the object using reflection.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Letter implements Serializable{

	@Schema(name = "firstName")
	@Size(min=1, max=50,message="firstName length is invalid|ResetUserPassword")
	@Pattern(regexp = "^[^<>]*$", message = "firstName contains invalid characters|ResetUserPassword")
	private String firstName;

	@Schema(name = "lastName")
	@Size(min=1, max=50,message="lastName length is invalid|ResetUserPassword")
	@Pattern(regexp = "^[^<>]*$", message = "lastName contains invalid characters|ResetUserPassword")
	private String lastName;

	@NotNull(message="street1 is required field in input request.|ResetUserPassword")
	@Size(min=1, max=100,message="street1 length is invalid|ResetUserPassword")
	@Pattern(regexp = "^[^<>]*$", message = "street1 contains invalid characters|ResetUserPassword")
	protected String street1;

	@Size(min=1, max=100,message="street2 length is invalid|ResetUserPassword")
	@Pattern(regexp = "^[^<>]*$", message = "street2 contains invalid characters|ResetUserPassword")
	protected String street2;
	
	@NotNull(message="city is required field in input request.|ResetUserPassword")
	@Size(min=1, max=100,message="city length is invalid|ResetUserPassword")
	@Pattern(regexp = "^[^<>]*$", message = "city contains invalid characters|ResetUserPassword")
	protected String city;

	@NotNull(message="state is required field in input request.|ResetUserPassword")
	@Size(min=1, max=2,message="state length is invalid|ResetUserPassword")
	protected String state;

	@NotNull(message="zipCode is required field in input request.|ResetUserPassword")
	@Size(min=1, max=5,message="zipCode length is invalid|ResetUserPassword")
	@Pattern(regexp = "^[0-9]*$", message = "zipCode must be numeric|ResetUserPassword")
	protected String zipCode;

	@Size(min=1, max=4,message="zipPlusFour length is invalid|ResetUserPassword")
	@Pattern(regexp = "^[0-9]*$", message = "zipPlusFour must be numeric|ResetUserPassword")
	protected String zipPlusFour;

	@Size(min=1, max=20,message="country length is invalid|ResetUserPassword")
	protected String country;
	
	 /**
     * This field represents a map of unknown attributes.
     *
     * The unknownAttributes map is used to store any additional attributes that are not part of the attributeName and attributeValue fields.
     * It is initialized as a new HashMap.
     *
     * The field is annotated with @JsonAnySetter and @JsonAnyGetter, allowing it to be included in JSON serialization and deserialization.
     */
    @JsonAnySetter
    @JsonAnyGetter
    public Map<String,Object> unknownAttributes = new HashMap<>();

	@Override
	public String toString() {
		return reflectionToString(this, JSON_STYLE);
	}
}