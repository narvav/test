package com.att.idp.idgraphusermanagementms.resource.response;

import com.att.idp.core.exception.ServiceError;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * This class represents the response from the ValidateUserCredentials operation in the system.
 * It contains fields for transactionName, appStatusMsg, appStatusCode, appInfo, appCategoryCode, idpTraceId, and errors.
 * Some fields are ignored during JSON serialization/deserialization.
 *
 * The class is annotated with @Data, @JsonIgnoreProperties, @JsonInclude, and @ApiModel from various libraries such as Lombok, Jackson, and Swagger.
 * The @Data annotation from Lombok library generates getter and setter methods for all fields.
 * The @JsonIgnoreProperties and @JsonInclude annotations from Jackson library control the JSON serialization/deserialization behavior.
 * The @ApiModel annotation from Swagger library provides metadata for the model definition in Swagger UI.
 *
 * It also overrides the toString method to return a string representation of the object.
 *
 */
@EqualsAndHashCode(callSuper = true)
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "ValidateUserCredentialsResponse")
public class ValidateUserCredentialsResponse extends BaseResponse {

	@JsonIgnore
	protected static final String transactionName="ValidateUserCredentials";

	}