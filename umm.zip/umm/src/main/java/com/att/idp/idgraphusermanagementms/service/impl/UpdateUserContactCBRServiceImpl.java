package com.att.idp.idgraphusermanagementms.service.impl;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.helper.UpdateUserContactCBRHelper;
import com.att.idp.idgraphusermanagementms.resource.request.UpdateUserContactCBRRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdateUserContactCBRResponse;
import com.att.idp.idgraphusermanagementms.service.UpdateUserContactCBRService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.ws.rs.core.MultivaluedMap;
import java.util.Map;

/**
 * This class implements the UpdateUserContactCBRService interface and provides the implementation for updating a user's contact in the system.
 * It is annotated with @Service to indicate that it's a Spring Bean and @Transactional to handle the transaction management.
 *
 * It contains a method updateUserContactCBR which takes an UpdateUserContactCBRRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return an UpdateUserContactCBRResponse object.
 *
 * The UpdateUserContactCBRRequest object encapsulates the details of the user contact update operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class UpdateUserContactCBRServiceImpl implements UpdateUserContactCBRService {

    public static final Logger logger = LoggerFactory.getLogger(UpdateUserContactCBRServiceImpl.class);

    private static String sClassName = "UpdateUserContactCBRServiceImpl";

    @Autowired
    private UpdateUserContactCBRHelper updateuserContactCBRHelper;

    @Override
    public UpdateUserContactCBRResponse updateUserContactCBR(UpdateUserContactCBRRequest updateUserContactCBRRequest, MultivaluedMap<String, String> requestHeader) throws MPSException {
        UpdateUserContactCBRResponse updateUserContactCBRResponse = null;
        Map<String, Object> hmResponse = null;
        String sMethodName = ".updateUserContactCBR.";
        logger.info("UpdateUserContactCBRServiceImpl.updateUserContactCBR.CAS_01 : Calling UpdateUserContactCBRHelper with Input : {}",updateUserContactCBRRequest);

        Map<String, Object> hmInput = CommonUtilHelper.objectToMap(updateUserContactCBRRequest);
        hmInput.put("handle", (String) hmInput.remove("userId"));

        hmResponse = updateuserContactCBRHelper.updateUserContactCBR(hmInput);
        {
            logger.info("{}{}CAS_02 : Response from UpdateuserContactCBRHelper.updateUserContactCBR : {}", sClassName, sMethodName, hmResponse);

            if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
                hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from UpdateUserContactCBRHelper.updateUserContactCBR");
                logger.info("{}{}CAS_03 : Null response from UpdateuserContactCBRHelper.updateUserContactCBR", sClassName, sMethodName);
            } else {
                String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
                if (stAppStatusCode == null) {
                    hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from UpdateUserContactCBRHelper.updateUserContactCBR");
                    logger.info("{}{}CAS_04 : Null response from UpdateuserContactCBRHelper.updateUserContactCBR", sClassName, sMethodName);
                }
            }
        }

        hmResponse.put(CommonDefs.TRANSACTION_ID, updateUserContactCBRRequest.getIdpTraceId());
        hmResponse.put("idp-trace-id", updateUserContactCBRRequest.getIdpTraceId());
        hmResponse.put(CommonDefs.TRANSACTION_NAME, "UpdateUserContactCBR");
        updateUserContactCBRResponse = CommonUtilHelper.generateUpdateUserContactCBRResponse(hmResponse);
        String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

        if (sTxnRollBack != null) {
            throw new InvalidInputDataException(hmResponse);
        }
        logger.info("{}{}CAS_05 : Response from UpdateUserContactCBRServiceImpl.updateUserContactCBR : {}", sClassName, sMethodName,
                updateUserContactCBRResponse);
        return updateUserContactCBRResponse;
    }
}