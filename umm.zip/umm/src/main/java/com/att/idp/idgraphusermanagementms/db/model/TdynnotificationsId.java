package com.att.idp.idgraphusermanagementms.db.model;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class TdynnotificationsId implements java.io.Serializable {

	private static final long serialVersionUID = -4467095028175076768L;

	@Column(name = "SERVICE_ID", nullable = false, precision = 22, scale = 0)
	private Long serviceId;

	@Column(name = "CTYPE", nullable = false, length = 50)
	private String ctype;

	@Column(name = "ACTION", nullable = false, length = 20)
	private String action;

	@Column(name = "N_NAME", nullable = false, length = 50)
	private String NName;

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TdynnotificationsId))
			return false;
		TdynnotificationsId castOther = (TdynnotificationsId) other;

		return ((this.getServiceId() == castOther.getServiceId()) || (this.getServiceId() != null
				&& castOther.getServiceId() != null && this.getServiceId().equals(castOther.getServiceId())))
				&& ((this.getCtype() == castOther.getCtype()) || (this.getCtype() != null
				&& castOther.getCtype() != null && this.getCtype().equals(castOther.getCtype())))
				&& ((this.getAction() == castOther.getAction()) || (this.getAction() != null
				&& castOther.getAction() != null && this.getAction().equals(castOther.getAction())))
				&& ((this.getNName() == castOther.getNName()) || (this.getNName() != null
				&& castOther.getNName() != null && this.getNName().equals(castOther.getNName())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getServiceId() == null ? 0 : this.getServiceId().hashCode());
		result = 37 * result + (getCtype() == null ? 0 : this.getCtype().hashCode());
		result = 37 * result + (getAction() == null ? 0 : this.getAction().hashCode());
		result = 37 * result + (getNName() == null ? 0 : this.getNName().hashCode());
		return result;
	}
}
