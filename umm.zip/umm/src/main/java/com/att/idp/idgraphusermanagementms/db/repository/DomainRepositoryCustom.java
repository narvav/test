package com.att.idp.idgraphusermanagementms.db.repository;

/**
 * This is a custom interface for the DomainRepository.
 * It is used to define custom queries and operations that are not provided by the JpaRepository.
 */
public interface DomainRepositoryCustom {
	
}
