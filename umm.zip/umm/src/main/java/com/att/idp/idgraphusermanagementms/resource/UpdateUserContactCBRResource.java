package com.att.idp.idgraphusermanagementms.resource;
import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.resource.request.UpdateUserContactCBRRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdateUserContactCBRResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.web.bind.annotation.RequestBody;

import jakarta.validation.Valid;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

/**
 * This is an interface named UpdateUserContactCBRResource.
 * It is annotated with @Tag(name = "contacts") to provide metadata for Swagger.
 * It is also annotated with @Path("/contacts") to set the path for the entire interface.
 * The interface is also annotated with @Produces({ MediaType.APPLICATION_JSON }) to specify that the methods in this interface produce JSON responses.
 * The interface contains a method, updateUserContactCBR, which is annotated with @POST, @Path, @Consumes, @Produces, @ApiOperation, @ApiResponses, and @ApiImplicitParams.
 * This method is designed to handle POST requests for updating user contact CBR.
 */
@Tag(name = "contacts")
@Path("/contacts")
@Produces({ MediaType.APPLICATION_JSON })
public interface UpdateUserContactCBRResource {
	
	/**
	 * This method is part of the UpdateUserContactCBRResource interface.
	 * It is responsible for updating user contact CBR.
	 * The method is annotated with @POST to indicate that it handles HTTP POST requests.
	 * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
	 * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
	 * The method takes an UpdateUserContactCBRRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
	 * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
	 * The method throws an MPSException if any error occurs during the operation.
	 * The method returns a Response object which encapsulates the result of the user contact CBR update operation.
	 *
	 * @param updateUserContactCBRRequest The UpdateUserContactCBRRequest containing the details of the user contact CBR update operation.
	 * @param httpHeader The HttpHeaders providing HTTP header information.
	 * @return Response The response of the user contact CBR update operation.
	 * @throws MPSException If any error occurs during the operation.
	 */
    @POST
    @Path("/user/update")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(summary = "Add User", description =  "Update user contact CBR",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = UpdateUserContactCBRResponse.class))),

            @ApiResponse(responseCode = "400", description =  "Bad Request"),
            @ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
    public Response updateUserContactCBR(@Valid @RequestBody UpdateUserContactCBRRequest updateUserContactCBRRequest, @Context HttpHeaders httpHeader) throws MPSException;
}
