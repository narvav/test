package com.att.idp.idgraphusermanagementms.resource.response;

import com.att.idp.core.exception.ServiceError;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class represents the response from the External User operation in the system.
 * It contains fields for transactionName, appStatusMsg, appStatusCode, idpTraceId, appInfo, guid, errors, and appCategoryCode.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Jackson's @JsonIgnore, @JsonProperty, @JsonIgnoreProperties, and @JsonInclude annotations to handle JSON serialization and deserialization.
 * It also uses Swagger's @ApiModel annotation to provide metadata for the Swagger UI.
 * It also uses Lombok's @Data annotation to generate getter and setter methods for all fields.
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "ExtUserResponse")
public class ExtUserResponse {

    @JsonIgnore
    private String transactionName;
    private String appStatusMsg;
    private String appStatusCode;
    @JsonProperty("idp-trace-id")
    private String idpTraceId;
    private String appInfo;
    private String guid;
    @JsonProperty("error")
    private ServiceError errors;
    @JsonIgnore
    private String appCategoryCode;
    private String activatedInd;
}