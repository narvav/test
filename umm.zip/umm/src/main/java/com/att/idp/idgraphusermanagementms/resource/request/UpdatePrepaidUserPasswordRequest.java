package com.att.idp.idgraphusermanagementms.resource.request;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.HashMap;
import java.util.Map;

import static com.att.mpsys.common.utils.CommonDefs.TRANSACTION_NAME_UPDATE_PREPAID_USER_PWD;

/**
 * This class represents a request to update user password in the system.
 * It contains fields for transactionName, callingSystemId, idpTraceId, domain, handle (userId), returnOnlineSecurityQuestions, agentId, isExternalCall, userCredentials, and a map for unknownAttributes.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 * It also overrides the toString method to return a JSON-style string representation of the object.
 *
 */
@Data
@Schema(name = "UpdatePrepaidUserPasswordRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdatePrepaidUserPasswordRequest {

	protected static final String transactionName = TRANSACTION_NAME_UPDATE_PREPAID_USER_PWD;

	protected String callingSystemId;

	@Schema(name = "idpTraceId")
	private String idpTraceId;

	@NotNull(message = "Password is required in input request.|UpdatePrepaidUserPassword")
	@Size(min = 1, max = 24, message =  "Password length is invalid|UpdatePrepaidUserPassword")
	@Schema(name = "password")
	protected String password;

	@NotNull(message = "CTN is required in input request.|UpdatePrepaidUserPassword")
	@Size(min = 10, max = 10, message =  "CTN length is invalid|UpdatePrepaidUserPassword")
	@Schema(name = "ctn")
	protected String ctn;

	@NotNull(message = "BAN is required in input request.|UpdatePrepaidUserPassword")
	@Size(min = 1, max = 25, message =  "BAN length is invalid|UpdatePrepaidUserPassword")
	@Schema(name = "ban")
	protected String ban;

	@Schema(name = "agentId")
	@Size(min = 1, max = 20, message =  "AgentId length is invalid|UpdatePrepaidUserPassword")
	private String agentId;

	@Schema(name = "isExternalCall")
	@Size(min = 1, max = 1, message =  "isExternalCall length is invalid|UpdatePrepaidUserPassword")
	protected String isExternalCall;


	/**
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
	 * @return Map<String,Object> The map of unknown attributes.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();

}