package com.att.idp.idgraphusermanagementms.resource.impl;

import static com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper.getElapsedTimeInSecs;
import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_IB;
import static com.att.idp.cd.observability.metrics.utils.Constants.URI;
import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.POST;
import static com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants.IDGRAPH_USERMANAGEMENTMS_IB;

import java.sql.SQLException;
import java.util.Map;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;

import com.att.idp.idgraphusermanagementms.message.ErrorMessages;
import com.att.idp.idgraphusermanagementms.resource.request.UpdatePrepaidUserPasswordRequest;
import com.att.idp.idgraphusermanagementms.resource.request.UpdateUserPasswordRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdatePrepaidUserPasswordResponse;
import com.att.idp.idgraphusermanagementms.resource.response.UpdateUserPasswordResponse;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.stereotype.Controller;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.request.validator.ResetUserPasswordRequestValidator;
import com.att.idp.idgraphusermanagementms.request.validator.UpdateUserPasswordRequestValidator;
import com.att.idp.idgraphusermanagementms.request.validator.UpdatePrepaidUserPasswordRequestValidator;
import com.att.idp.idgraphusermanagementms.resource.UserPasswordResource;
import com.att.idp.idgraphusermanagementms.resource.request.ResetUserPasswordRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ResetUserPasswordResponse;
import com.att.idp.idgraphusermanagementms.service.ResetUserPasswordService;
import com.att.idp.idgraphusermanagementms.service.UpdateUserPasswordService;
import com.att.idp.idgraphusermanagementms.service.UpdatePrepaidUserPasswordService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;

/**
 * This class is an implementation of the UserPasswordResource interface.
 * It contains methods for managing user profiles, including adding, updating, checking user ID availability, changing username, checking access ID merge eligibility, updating user fraud status, adding external user, validating user credentials, updating external user, and merging user access ID.
 * It uses Spring's @Controller annotation, making it a candidate for Spring's automatic detection to discover and automatically create beans.
 * It also uses @Autowired to inject instances of various services and validators.
 *
 * Each method in this class corresponds to a specific operation related to user profiles. These methods take in a request object and HttpHeaders as parameters.
 * These methods are responsible for validating the request, calling the appropriate service, and handling any exceptions that may occur.
 *
 *
 */
@Controller
@OpenAPIDefinition(
        info = @Info(title="User Management",
                description="IDGraphUserManagementMs provides services that are used to perform identity specific " +
                        "operations like creating new accessId, registering a currently.com memberId, updating " +
                        "profile attributes of the existing accessId, and fraud locking access Id. This information " +
                        "gets stored in IdentityGraph database and gets provisioned/replicated to multiple systems " +
                        "e.g. HALOC, Yahoo, CG, CCR, G2 etc.\n\n\n\n.", version="0.0.1"),
        servers = {
                @Server(url="https://apporigin-dev2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/"),
                @Server(url="https://apporigin-tst2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/")
        })
public class UserPasswordResourceImpl implements UserPasswordResource {

    @Autowired
    private ResetUserPasswordRequestValidator resetUserPasswordRequestValidator;

    @Autowired
    private ResetUserPasswordService resetUserPasswordService;

    @Autowired
    private UpdateUserPasswordRequestValidator updateUserPasswordRequestValidator;

    @Autowired
    private UpdateUserPasswordService updateUserPasswordService;

    @Autowired
    private UpdatePrepaidUserPasswordRequestValidator updatePrepaidUserPasswordRequestValidator;

    @Autowired
    private UpdatePrepaidUserPasswordService updatePrepaidUserPasswordService;

    public static final Logger logger = LoggerFactory.getLogger(UserPasswordResourceImpl.class);

    @TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
            description = "update user password",
            tags = {URI, "/msapi/idgraphusermanagementms/v1/userpassword/update", METHOD, POST},
            histogram = true)
    @Override
    public Response updateUserPassword(UpdateUserPasswordRequest updateUserPasswordRequest, HttpHeaders httpHeaders) throws MPSException {
        Map<String, Object> hmResponse = CommonUtil.getHashMap();
        UpdateUserPasswordResponse updateUserPasswordResponse = null;
        long startTm = System.currentTimeMillis();
        Response responseObj = null;
        try {

            MultivaluedMap<String, String> requestHeader = httpHeaders.getRequestHeaders();

            logger.info(SpiMarker.getInstance(),"WEB_01 : UpdateUserPassword Input : {} | UpdateUserPassword Request Header  : {}",
                updateUserPasswordRequest != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(updateUserPasswordRequest)) : null,
                    requestHeader != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(requestHeader)) : null);

            updateUserPasswordResponse = updateUserPasswordRequestValidator.validateUpdatePasswordRequest(httpHeaders, updateUserPasswordRequest);

            logger.info(SpiMarker.getInstance(),"WEB000 : UpdateUserPassword Input : {}", updateUserPasswordRequest);

            if (updateUserPasswordResponse == null) {
                // call the service class
                updateUserPasswordResponse = updateUserPasswordService.updateUserPassword(updateUserPasswordRequest, requestHeader);
                logger.info("WEB_02 : UserPassword Service Response : {}", updateUserPasswordResponse);
            }
        } catch (Exception e) {
            if (e instanceof InvalidInputDataException) {
                logger.error("InvalidInputDataException: {}", e.getMessage());
                throw e;
            }
            else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
            }
            else {
                hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
            }

            hmResponse.put(ProfileOrchestrationConstants.IDP_TRACE_ID, updateUserPasswordRequest.getIdpTraceId());
            updateUserPasswordResponse = CommonUtilHelper.generateUpdateUserPasswordResponse(hmResponse);
        }
        responseObj = CommonUtilHelper.buildMSResponse(updateUserPasswordResponse);
        String sTimeTaken = getElapsedTimeInSecs(startTm) + " seconds";

        logger.info("WEB999 : Total time taken : {} UpdateUserPassword Response : {}",sTimeTaken, updateUserPasswordResponse);
        return responseObj;
    }

    /**
     * This method is part of the UserPasswordResource interface.
     * It is responsible to reset the user password.
     * The method is annotated with @POST to indicate that it handles HTTP POST requests.
     * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
     * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
     * The method takes an ResetUserPasswordRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
     * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
     * The method throws an MPSException if any error occurs during the operation.
     * The method returns a Response object which encapsulates the result of the reset user password operation.
     *
     * @param resetUserPasswordRequest The ResetUserPasswordRequest containing the details of the password reset operation.
     * @param httpHeaders The HttpHeaders providing HTTP header information.
     * @return Response The response of the reset password operation.
     * @throws MPSException If any error occurs during the operation.
     */
    @TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
            description = "reset user password",
            tags = {URI, "/msapi/idgraphusermanagementms/v1/userpassword/reset", METHOD, POST},
            histogram = true)
    @Override
    public Response resetUserPassword(ResetUserPasswordRequest resetUserPasswordRequest, HttpHeaders httpHeaders) throws MPSException {
        Map<String, Object> hmResponse = CommonUtil.getHashMap();
        ResetUserPasswordResponse resetUserPasswordResponse = null;
        long startTm = System.currentTimeMillis();
        Response responseObj = null;
        try {

            MultivaluedMap<String, String> requestHeader = httpHeaders.getRequestHeaders();

            logger.info(SpiMarker.getInstance(),"WEB_01 : ResetUserPassword Input : {} | ResetUserPassword Request Header  : {}",
                resetUserPasswordRequest != null ? CommonUtilHelper.sanitizeForLog(resetUserPasswordRequest.toString()) : null,
                    requestHeader != null ? CommonUtilHelper.sanitizeForLog(requestHeader.toString()) : null);

            resetUserPasswordResponse = resetUserPasswordRequestValidator.resetUserPasswordRequestValidator(httpHeaders, resetUserPasswordRequest);

            logger.info(SpiMarker.getInstance(),"WEB000 : ResetUserPassword Input : {}", resetUserPasswordRequest);

            if (resetUserPasswordResponse == null) {
                // call the service class
                resetUserPasswordResponse = resetUserPasswordService.resetUserPassword(resetUserPasswordRequest, requestHeader);
                logger.info("WEB_02 : UserPassword Service Response : {}", resetUserPasswordResponse);
            }
        } catch (Exception e) {
            if (e instanceof InvalidInputDataException) {
                logger.error("InvalidInputDataException: {}", e.getMessage());
                throw e;
            }
            else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
            }
            else {
                hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
            }

            hmResponse.put(ProfileOrchestrationConstants.IDP_TRACE_ID, resetUserPasswordRequest.getIdpTraceId());
            resetUserPasswordResponse = CommonUtilHelper.generateResetUserPasswordResponse(hmResponse);
        }
        responseObj = CommonUtilHelper.buildMSResponse(resetUserPasswordResponse);
        String sTimeTaken = getElapsedTimeInSecs(startTm) + " seconds";

        logger.info("WEB999 : Total time taken : {} ResetUserPassword Response : {}",sTimeTaken, resetUserPasswordResponse);
        return responseObj;
    }

    /**
     * This method is part of the UserPasswordResource interface.
     * It is responsible for updating the password of a prepaid user.
     * The method is annotated with @Override to indicate that it overrides a method in the UserPasswordResource interface.
     *
     * @param updatePrepaidUserPasswordRequest The UpdatePrepaidUserPasswordRequest containing the details of the password update operation.
     * @param httpHeaders The HttpHeaders providing HTTP header information.
     * @return Response The response of the update prepaid user password operation.
     * @throws MPSException If any error occurs during the operation.
     */
    @TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
            description = "update prepaid user password",
            tags = {URI, "/msapi/idgraphusermanagementms/v1/userpassword/updatePrepaid", METHOD, POST},
            histogram = true)
    @Override
    public Response updatePrepaidUserPassword(UpdatePrepaidUserPasswordRequest updatePrepaidUserPasswordRequest, HttpHeaders httpHeaders) throws MPSException {

        Map<String, Object> hmResponse = CommonUtil.getHashMap();
        UpdatePrepaidUserPasswordResponse updatePrepaidUserPasswordResponse = null;
        long startTm = System.currentTimeMillis();
        Response responseObj = null;
        try {

            MultivaluedMap<String, String> requestHeader = httpHeaders.getRequestHeaders();
            logger.info(SpiMarker.getInstance(),"WEB_01 : UpdatePrepaidUserPassword Input : {} | ResetUserPassword Request Header  : {}",
                    (updatePrepaidUserPasswordRequest != null ? StringUtils.normalizeSpace(updatePrepaidUserPasswordRequest.toString()) : "null"), CommonUtilHelper.objectToString(requestHeader));

            updatePrepaidUserPasswordResponse = updatePrepaidUserPasswordRequestValidator.updatePrepaidUserPasswordRequestValidator(updatePrepaidUserPasswordRequest,httpHeaders);
            logger.info(SpiMarker.getInstance(),"WEB000 : UpdatePrepaidUserPassword Input : {}", updatePrepaidUserPasswordRequest);
            if (updatePrepaidUserPasswordResponse == null) {
                updatePrepaidUserPasswordResponse = updatePrepaidUserPasswordService.updatePrepaidUserPassword(updatePrepaidUserPasswordRequest,requestHeader);
                logger.info("WEB_02 : UpdatePrepaidUserPassword service Response : {}", updatePrepaidUserPasswordResponse);
            }
        } catch (Exception e) {
            if (e instanceof InvalidInputDataException) {
                logger.error("InvalidInputDataException: {}", e.getMessage());
                throw e;
            }
            else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
                hmResponse.put("ErrorEnum", ErrorMessages.MS_MPSYS_BE_304);
            }
            else {
                hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
                hmResponse.put("ErrorEnum", ErrorMessages.MS_MPSYS_BE_602);
            }

            hmResponse.put("idp-trace-id", updatePrepaidUserPasswordRequest.getIdpTraceId());

            updatePrepaidUserPasswordResponse = CommonUtilHelper.generateUpdatePrepaidUserPasswordResponse(hmResponse);
        }
        responseObj = CommonUtilHelper.buildMSResponse(updatePrepaidUserPasswordResponse);
        String sTimeTaken = getElapsedTimeInSecs(startTm) + " seconds";

        logger.info("WEB999 : Total time taken : {} UpdatePrepaidUserPassword Response : {}",sTimeTaken, updatePrepaidUserPasswordResponse);
        return responseObj;
    }

}
