package com.att.idp.idgraphusermanagementms.helper;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.mpsys.common.utils.CErrorDefs;

/**
 * The CheckAgeEligibilityHelper class is a helper class that provides a method to check the age eligibility of a user.
 * It includes a method to validate the birth date and the valid age, and calculates the current age of the user.
 * If the current age is less than the valid age, the user is not eligible. If the current age is greater than or equal to the valid age, the user is eligible.
 * This class is annotated with @Component, meaning it is an autodetectable Spring Bean and can be automatically wired into other components using Spring's dependency injection facilities.
 */
@Component
public class CheckAgeEligibilityHelper {

	private static final String info = "$Id: master/com/att/idp/idgraphusermanagementms/helper/CheckAgeEligibilityHelper.java v1 2024-04-08 pb6583 $;";
	
	private static String sClassName = "CheckAgeEligibilityHelper";
	public static final Logger logger = LoggerFactory.getLogger(CheckAgeEligibilityHelper.class);


	/**
	 * This method checks the age eligibility of a user based on the user's birth date and a valid age.
	 * It calculates the current age of the user and compares it with the valid age.
	 * If the current age is less than the valid age, the user is not eligible and the method returns false.
	 * If the current age is greater than or equal to the valid age, the user is eligible and the method returns true.
	 * This method throws an exception if any error occurs during the process.
	 *
	 * @param stBirthDate A String representing the user's birth date. The birth date should be in the format "MMddyyyy".
	 * @param stValidAge A String representing the valid age. The valid age is the minimum age a user must be to be considered eligible.
	 * @return A boolean indicating whether the user is eligible based on their age. Returns true if the user is eligible, false otherwise.
	 * @throws Exception If any error occurs during the process.
	 */
	// TODO
	public static boolean checkAgeEligibility(String stBirthDate, String stValidAge) throws Exception {

		String sMethodName = ".checkAgeEligibility.";
		String stAppInfo = null;

		logger.info("{}{}HLP01 : CVS KEYWORDS: {}", sClassName, sMethodName, info);
		logger.info("{}{}HLP000 : Input Birthdate : {}", sClassName, sMethodName, stBirthDate);
		boolean isEligible = false;

		try {

			// Get the calendar Instances
			Calendar currentCal = Calendar.getInstance();
			Calendar birthCal = Calendar.getInstance();

			SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
			Date birthDate = sdf.parse(stBirthDate);

			// Pass birthDate to the calendar instance
			birthCal.setTime(birthDate);

			// Get the validAge for Registration
			int validAge = Integer.parseInt(stValidAge);

			// Add validAge to the birthDate
			birthCal.add(Calendar.YEAR, validAge);

			// if birthDate + validAge < currentDate , the member is not
			// eligible
			if (birthCal.after(currentCal)) {

				isEligible = false;

				stAppInfo = "Current Age is less than valid Age :: " + validAge + " years.So returning false.";
				logger.info("{}{}CAE_02 : {}", sClassName, sMethodName, stAppInfo);

			}
			// if birthDate + validAge >= currentDate , the member is eligible
			else {

				isEligible = true;

				stAppInfo = "Current Age is greater than or equal to valid Age :: " + validAge
						+ " years.So returning true.";
				logger.info("{}{}CAE_03 : {}", sClassName, sMethodName, stAppInfo);
			}

		} catch (Exception e) {

			logger.error("{}{}CAE_04 : {},Exception = {}", sClassName, sMethodName, CErrorDefs.ERR_SYS_APPL_MSG,
					e.getMessage());
			throw e;
		}
		return isEligible;
	}

}
