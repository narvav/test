package com.att.idp.idgraphusermanagementms.db.helper;

import java.util.*;

import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.StatusMsg;
import org.springframework.web.util.HtmlUtils;

/**
 * This class is responsible for adding services to the database.
 * It uses Spring's JdbcTemplate for database operations and has methods for adding services.
 * It also uses other helper classes like DBHelper.
 *
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like JdbcTemplate and DBHelper.
 *
 * The class contains SQL queries as string constants for adding services.
 * These queries are used in the corresponding methods for adding services.
 *
 * The class also contains a logger for logging information and errors.
 *
 * The main method in this class is:
 * - addService: This method adds a service to the database. It takes a HashMap as input and returns a HashMap as output.
 *   The input HashMap contains key-value pairs for various service attributes like member number, group number, service name, group status, member status, etc.
 *   The method first checks if the jdbcTemplate is null. If it is, it returns an error status.
 *   Then it retrieves various service attributes from the input HashMap and converts them to the appropriate data types.
 *   It also retrieves the service ID, member status, and group status from the DBHelper.
 *   If any of these values are not found, it returns an error status.
 *   Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
 *   Finally, it returns a status indicating whether the operation was successful or not.
 */
@Component
public class AddServiceDBHelper {
	
	public static final Logger logger = LoggerFactory.getLogger(AddServiceDBHelper.class);
	private static final String INFO = "$Id: master/com/att/idp/idgraphusermanagementms/helper/dbhelpers/AddServiceDBHelper.java v1 2024-04-05 pb6583 $;";
	
    private static String sClassName = "AddServiceDBHelper";
    
	@Autowired 
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private DBHelper oDBHelper;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;
	
	private static final String ADD_MEMEBR_SERVICE_SQL = "INSERT INTO memberservice("+
			"MEMBER_NUM,"+
			"SERVICE_ID,"+
			"GROUP_NUM,"+
			"GROUP_STATUS,"+
			"MEMBER_STATUS,"+
			"TERMINATE_DATE,"+
			"LAST_MODIFIED_BY,"+
			"SITE_ID,"+
			"INSTANCE_ID,"+
			"SOR_ID," +
			"SOR_INVARIANT_ID,"+
			"OWNED_BY,"+
			"NICKNAME,"+
			"DEFAULT_ACCOUNT,"+
			"CPNI_IMPACTED,"+
			"DATE_DEFAULT_EST,"+
			"PARENT_SOR_ID,"+
			"PARENT_SOR_INVARIANT_ID,"+
			"UVERSE_SERVICE_IND"+
			") VALUES("+
			"?,"+
			"?,"+
			"?,"+
			"?,"+
			"?,"+
			"to_date(?,'MMddyyyy'),"+
			"?,"+
			"?,"+
			"?,"+
			"?,"+
			"?,"+
			"?,"+
			"?,"+
			"?,"+
			"?,"+
			" (SELECT sysdate FROM dual WHERE 1 = ?)," +
			"?,?,?)";
	/**
	 * This method is responsible for adding a service to the database.
	 * It takes a HashMap as an argument which contains the details of the service to be added.
	 * The HashMap should contain the following keys:
	 * - DB_MEMBER_NUM: The member number.
	 * - DB_GROUP_NUM: The group number.
	 * - DB_SERVICE_NAME: The service name.
	 * - DB_GROUP_STATUS: The group status.
	 * - DB_MEMBER_STATUS: The member status.
	 * - DB_TERMINATE_DATE: The termination date.
	 * - DB_LAST_MODIFIED_BY: The identifier of the user who last modified the service.
	 * - DB_GROUP_STATUS_NAME: The group status name.
	 * - DB_MEMBER_STATUS_NAME: The member status name.
	 * - DB_SITE_ID: The site ID.
	 * - DB_INSTANCE_ID: The instance ID.
	 * - DB_SOR_INVARIANT_ID: The SOR invariant ID.
	 * - DB_SOR_NAME: The SOR name.
	 * - DB_OWNED_BY: The owned by.
	 * - DB_NICKNAME: The nickname.
	 * - DB_DEFAULT_ACCOUNT: The default account.
	 * - DB_CPNI_IMPACTED: The CPNI impacted.
	 * - DB_DATE_DEFAULT_EST: The date default established.
	 * - DB_PARENT_SOR_ID: The parent SOR ID.
	 * - DB_PARENT_SOR_NAME: The parent SOR name.
	 * - DB_PARENT_SOR_INVARIANT_ID: The parent SOR invariant ID.
	 * - DB_UVERSE_SERVICE_IND: The U-verse service indicator.
	 *
	 * The method first checks if the jdbcTemplate is null. If it is, it logs an error and returns an error status.
	 * It then retrieves various service attributes from the input HashMap and converts them to the appropriate data types.
	 * It also retrieves the service ID, member status, and group status from the DBHelper.
	 * If any of these values are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param InpParam A HashMap containing the details of the service to be added.
	 * @return A HashMap containing the status of the operation.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public HashMap addService(HashMap InpParam) throws MPSException {
		String sMethodName = ".addService.";
		logger.info("{}{}DBHL000 : InpParam = {}", sClassName, sMethodName,
				StringUtils.normalizeSpace(InpParam != null ? HtmlUtils.htmlEscape(InpParam.toString()) : null));
		HashMap status = null;
		List<Object> objectList = new ArrayList<Object>();
		
		int serviceId = 0;
        if (InpParam == null) {
            String  stAppInfo="InpParam is null";
            logger.info("{}{}DBHLP01 : InpParam is null", sMethodName, sClassName);
            status = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
            return status;
        }

		String terminateDate		= (String)InpParam.get(MPSDefs.DB_TERMINATE_DATE);
		String lastModifiedBy 	= (String)InpParam.get(MPSDefs.DB_LAST_MODIFIED_BY);
		String siteId				= (String)InpParam.get(MPSDefs.DB_SITE_ID);
		String instanceId			= (String)InpParam.get(MPSDefs.DB_INSTANCE_ID);
		String sorInvariantId 	= (String)InpParam.get(MPSDefs.DB_SOR_INVARIANT_ID);
		String sorIdStr			= null;
		
		String ownedByStr			= (String)InpParam.get(MPSDefs.DB_OWNED_BY);
		String nickname				= (String)InpParam.get(MPSDefs.DB_NICKNAME);
		String defaultAccount		= (String)InpParam.get(MPSDefs.DB_DEFAULT_ACCOUNT);
		String cpniImpacted		= (String)InpParam.get(MPSDefs.DB_CPNI_IMPACTED);
		String dateDefaultEst     = (String)InpParam.get(MPSDefs.DB_DATE_DEFAULT_EST);
		String parentSorIdStr	= (String)InpParam.get(MPSDefs.DB_PARENT_SOR_ID);
		String parentSorName		= (String)InpParam.get(MPSDefs.DB_PARENT_SOR_NAME);
		String parentSorInvariantId	= (String)InpParam.get(MPSDefs.DB_PARENT_SOR_INVARIANT_ID);
		String uverseServiceInd	= (String)InpParam.get(MPSDefs.DB_UVERSE_SERVICE_IND);

		long ownedBy = -1;
		long memberNum = -1;
		long groupNum = -1;
		int memberStatus = -1;
		int groupStatus = -1;
		int sorId = -1;
		int parentSorId = -1;

		try {
					Map<String, Object> parsedValues = CommonUtilHelper.parseAndFetchDBValues(
					jdbcTemplate, oDBHelper, sMethodName, sClassName, InpParam);

			if (parsedValues.containsKey("status")) {
				status = (HashMap) parsedValues.get("status");
				return status;
			}

			ownedBy = (long) parsedValues.get("ownedBy");
			memberNum = (long) parsedValues.get("memberNum");
			groupNum = (long) parsedValues.get("groupNum");
			memberStatus = (int) parsedValues.get("memberStatus");
			groupStatus = (int) parsedValues.get("groupStatus");
			sorId = (int) parsedValues.get("sorId");
			parentSorId = (int) parsedValues.get("parentSorId");
			serviceId = (int) parsedValues.get("serviceId");
			sorIdStr = (String) parsedValues.get("sorIdStr");
			parentSorIdStr = (String) parsedValues.get("parentSorIdStr");

			if (serviceId == 0 || memberStatus == -1 || groupStatus == -1){
				String sAppInfo = "Cannot find serviceId or memberStatus/groupStatus";
				status = StatusMsg.makeSQLStatus(MPSDefs.ERR_NO_SERVICE,MPSDefs.ERR_NO_SERVICE_MSG,sAppInfo,MPSDefs.SQL_ERR,MPSDefs.SQL_ERR_MSG,MPSDefs.NO_ROW_UPDATED);
				logger.info("{}{}DBHLP84 : CANNOT find service_id, member_status or group_status", sMethodName, sClassName);
				return status;
			} else {
				logger.debug("{}{}DBHLP85 : SQL = {}", sMethodName, sClassName, ADD_MEMEBR_SERVICE_SQL);
				// Prepare a HashMap for the parameters
				HashMap<String, Object> insertParams = new HashMap<>();
				insertParams.put("memberNum", memberNum);
				insertParams.put("serviceId", serviceId);
				insertParams.put("groupNum", groupNum);
				insertParams.put("groupStatus", groupStatus);
				insertParams.put("memberStatus", memberStatus);
				insertParams.put("terminateDate", terminateDate);
				insertParams.put("lastModifiedBy", lastModifiedBy);
				insertParams.put("siteId", siteId);
				insertParams.put("instanceId", instanceId);
				insertParams.put("sorIdStr", sorIdStr);
				insertParams.put("sorId", sorId);
				insertParams.put("sorInvariantId", sorInvariantId);
				insertParams.put("ownedByStr", ownedByStr);
				insertParams.put("ownedBy", ownedBy);
				insertParams.put("nickname", nickname);
				insertParams.put("defaultAccount", defaultAccount);
				insertParams.put("cpniImpacted", cpniImpacted);
				insertParams.put("dateDefaultEst", dateDefaultEst);
				insertParams.put("parentSorIdStr", parentSorIdStr);
				insertParams.put("parentSorId", parentSorId);
				insertParams.put("parentSorInvariantId", parentSorInvariantId);
				insertParams.put("uverseServiceInd", uverseServiceInd);

				objectList.addAll(CommonUtilHelper.prepareInsertParams(insertParams,sClassName));
				int rowCount = jdbcTemplate.update(new String(ADD_MEMEBR_SERVICE_SQL), objectList.toArray(new Object[objectList.size()]));
				
				status = StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS,MPSDefs.MPS_ALL_OK,MPSDefs.SQL_SUCCESS,MPSDefs.SQL_SUCCESS_MSG,Integer.toString(rowCount));
				status.put(MPSDefs.DB_SERVICE_ID, Integer.toString(serviceId));
					
				logger.debug("{}{}DBHLP98 : insertStatus={}", sMethodName, sClassName, status);
			}
		}	
		catch(NumberFormatException e){
			status = StatusMsg.makeSQLStatus(MPSDefs.ERR_OUT_OF_RANGE,MPSDefs.ERR_OUT_OF_RANGE_MSG,MPSDefs.SQL_ERR,MPSDefs.SQL_ERR_MSG,MPSDefs.NO_ROW_UPDATED);
			logger.info("{}{}DBHLP99 : Error: {}", sMethodName, sClassName, e.getMessage()); 
		}catch(Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			status = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}DBHLP103 : Error: {}", sMethodName, sClassName, e.getMessage());
		} finally {
			logger.info("{}{}DBTOOLS999 : Output from addService = {}", sMethodName, sClassName, status);	
		}
		return status;	
	}

	/**
	 * Adds multiple services to the database using batch operation.
	 * <p>
	 * This method prepares a batch of insert statements for the provided service details.
	 * It validates input, parses required values, and executes a batch update for all services.
	 *
	 * @param inpParam A HashMap containing the details of the services to be added.
	 * @return A HashMap containing the status of the batch operation.
	 * @throws MPSException if an error occurs during database operation.
	 */
	public HashMap addServices(HashMap inpParam) throws MPSException {
	    String sMethodName = ".addServices.";
	    logger.info("{}{}DBHL000 : inpParam = {}", sClassName, sMethodName, CommonUtilHelper.sanitizeForLog(String.valueOf(inpParam != null ? inpParam : null)));
	    HashMap status = null;

	    if (inpParam == null || !(inpParam.get("services") instanceof List)) {
	        String stAppInfo = "inpParam is null or missing 'services' list";
	        logger.info("{}{}DBHLP01 : inpParam is invalid", sMethodName, sClassName);
	        status = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
	        return status;
	    }

	    List<HashMap> services = (List<HashMap>) inpParam.get("services");
		String memberNum = (String) inpParam.get(MPSDefs.DB_MEMBER_NUM);
		String groupNum = (String) inpParam.get(MPSDefs.DB_GROUP_NUM);
	    List<Object[]> batchParams = new ArrayList<>();
	    for (HashMap serviceParam : services) {
	        try {
				serviceParam.put(MPSDefs.DB_MEMBER_NUM, memberNum);
				serviceParam.put(MPSDefs.DB_GROUP_NUM, groupNum);
	            HashMap<String, Object> parsedValues = (HashMap<String, Object>) parseAndFetchDBValues(jdbcTemplate, oDBHelper, sMethodName, sClassName, serviceParam);

	            if (parsedValues.containsKey("status")) {
	                status = (HashMap) parsedValues.get("status");
	                return status;
	            }
				Object[] params = CommonUtilHelper.prepareInsertParams(parsedValues, sClassName).toArray();
				batchParams.add(params);
	        } catch (Exception e) {
	            errorMetricHandler.recordDbErrorMetric();
	            status = StatusMsg.makeExceptionSQLStatus(e);
	            logger.error("{}{}DBHLP103 : Error: {}", sMethodName, sClassName, e.getMessage());
	            return status;
	        }
	    }

	    try {
			int[] rowCounts = jdbcTemplate.batchUpdate(ADD_MEMEBR_SERVICE_SQL, batchParams);
	        int totalRows = Arrays.stream(rowCounts).sum();
	        status = StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS, MPSDefs.MPS_ALL_OK, MPSDefs.SQL_SUCCESS, MPSDefs.SQL_SUCCESS_MSG, Integer.toString(totalRows));
	        logger.info("{}{}DBTOOLS999 : Output from addServices = {}", sMethodName, sClassName, status);
	    } catch (Exception e) {
	        errorMetricHandler.recordDbErrorMetric();
	        status = StatusMsg.makeExceptionSQLStatus(e);
	        logger.error("{}{}DBHLP103 : Error: {}", sMethodName, sClassName, e.getMessage());
	    }
	    return status;
	}

	/**
	 * Parses and fetches database values from the input parameter map.
	 * Validates required fields and prepares a parameter map for database insertion.
	 *
	 * @param jdbcTemplate the JdbcTemplate for DB operations
	 * @param oDBHelper the DBHelper instance
	 * @param sMethodName the method name for logging
	 * @param sClassName the class name for logging
	 * @param inpParam the input parameter map
	 * @return a map of parsed values or error status
	 * @throws MPSException if parsing fails
	 */
	public static Map<String, Object> parseAndFetchDBValues(
	        JdbcTemplate jdbcTemplate,
	        DBHelper oDBHelper,
	        String sMethodName,
	        String sClassName,
	        HashMap inpParam) throws MPSException {

	    Map<String, Object> parsedValues = CommonUtilHelper.parseAndFetchDBValues(jdbcTemplate, oDBHelper, sMethodName, sClassName, inpParam);

	    if (parsedValues.containsKey("status")) {
	        return (HashMap) parsedValues.get("status");
	    }

	    int serviceId = (int) parsedValues.get("serviceId");
	    int memberStatus = (int) parsedValues.get("memberStatus");
	    int groupStatus = (int) parsedValues.get("groupStatus");

	    if (serviceId == 0 || memberStatus == -1 || groupStatus == -1) {
	        String sAppInfo = "Cannot find serviceId or memberStatus/groupStatus";
	        HashMap status = StatusMsg.makeSQLStatus(
	                MPSDefs.ERR_NO_SERVICE,
	                MPSDefs.ERR_NO_SERVICE_MSG,
	                sAppInfo,
	                MPSDefs.SQL_ERR,
	                MPSDefs.SQL_ERR_MSG,
	                MPSDefs.NO_ROW_UPDATED
	        );
	        logger.info("{}{}DBHLP84 : CANNOT find service_id, member_status or group_status", sMethodName, sClassName);
	        return status;
	    }

	    HashMap<String, Object> insertParams = new HashMap<>();
	    insertParams.put("memberNum", parsedValues.get("memberNum"));
	    insertParams.put("serviceId", serviceId);
	    insertParams.put("groupNum", parsedValues.get("groupNum"));
	    insertParams.put("groupStatus", groupStatus);
	    insertParams.put("memberStatus", memberStatus);
	    insertParams.put("terminateDate", inpParam.get(MPSDefs.DB_TERMINATE_DATE));
	    insertParams.put("lastModifiedBy", inpParam.get(MPSDefs.DB_LAST_MODIFIED_BY));
	    insertParams.put("siteId", inpParam.get(MPSDefs.DB_SITE_ID));
	    insertParams.put("instanceId", inpParam.get(MPSDefs.DB_INSTANCE_ID));
	    insertParams.put("sorIdStr", parsedValues.get("sorIdStr"));
	    insertParams.put("sorId", parsedValues.get("sorId"));
	    insertParams.put("sorInvariantId", inpParam.get(MPSDefs.DB_SOR_INVARIANT_ID));
	    insertParams.put("ownedByStr", inpParam.get(MPSDefs.DB_OWNED_BY));
	    insertParams.put("ownedBy", parsedValues.get("ownedBy"));
	    insertParams.put("nickname", inpParam.get(MPSDefs.DB_NICKNAME));
	    insertParams.put("defaultAccount", inpParam.get(MPSDefs.DB_DEFAULT_ACCOUNT));
	    insertParams.put("cpniImpacted", inpParam.get(MPSDefs.DB_CPNI_IMPACTED));
	    insertParams.put("dateDefaultEst", inpParam.get(MPSDefs.DB_DATE_DEFAULT_EST));
	    insertParams.put("parentSorIdStr", parsedValues.get("parentSorIdStr"));
	    insertParams.put("parentSorId", parsedValues.get("parentSorId"));
	    insertParams.put("parentSorInvariantId", inpParam.get(MPSDefs.DB_PARENT_SOR_INVARIANT_ID));
	    insertParams.put("uverseServiceInd", inpParam.get(MPSDefs.DB_UVERSE_SERVICE_IND));

	    logger.debug("{}{}DBHLP85 : SQL = {}", sMethodName, sClassName, ADD_MEMEBR_SERVICE_SQL);
	    return insertParams;
	}
}