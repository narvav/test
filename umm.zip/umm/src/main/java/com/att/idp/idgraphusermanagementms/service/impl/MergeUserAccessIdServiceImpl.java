package com.att.idp.idgraphusermanagementms.service.impl;

import java.util.Map;

import jakarta.ws.rs.core.MultivaluedMap;

import com.att.idp.idgraphusermanagementms.helper.MergeSlidProfileSoapHelper;
import com.att.mpsys.common.helpers.FeatureManagerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.resource.request.MergeUserAccessIdRequest;
import com.att.idp.idgraphusermanagementms.resource.response.MergeUserAccessIdResponse;
import com.att.idp.idgraphusermanagementms.service.MergeUserAccessIdService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.helper.MergeUserAccessIdHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This class implements the MergeUserAccessIdService interface and provides the implementation for merging user access IDs in the system.
 * It is annotated with @Service to indicate that it's a Spring Bean and @Transactional to handle the transaction management.
 *
 * It contains a method mergeUserAccessId which takes a MergeUserAccessIdRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return a MergeUserAccessIdResponse object.
 *
 * The MergeUserAccessIdRequest object encapsulates the details of the user access ID merge operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
@Service
@RequiredArgsConstructor
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class MergeUserAccessIdServiceImpl implements MergeUserAccessIdService {

	public static final Logger logger = LoggerFactory.getLogger(MergeUserAccessIdServiceImpl.class);

	private static String sClassName = "MergeUserAccessIdServiceImpl";

	private final MergeUserAccessIdHelper mergeUserAccessIdHelper;
	private final FeatureManagerHelper featureManagerHelper;
	private final MergeSlidProfileSoapHelper mergeSlidProfileSoapHelper;

	/**
	 * This method is responsible for merging user access IDs. It takes a request object and a request header as input.
	 * It processes the request, logs the necessary information, and returns a response object.
	 *
	 * @param mergeUserAccessIdRequest The request object containing the details for the merge operation.
	 * @param requestHeader The request header containing additional request metadata.
	 * @return MergeUserAccessIdResponse The response object containing the result of the merge operation.
	 * @throws InvalidInputDataException If the transaction needs to be rolled back.
	 */
	@Override
	public MergeUserAccessIdResponse mergeUserAccessId(MergeUserAccessIdRequest mergeUserAccessIdRequest,
 			MultivaluedMap<String, String> requestHeader) {
        logger.info("Inside mergeUserAccessId method:::");
		Map<String, Object> hmResponse =null;
		String sMethodName = ".mergeUserAccessId.";
		Map<String, Object> hmInput = CommonUtilHelper.objectToMap(mergeUserAccessIdRequest);
		boolean flag=true;
		String idpTraceid = (String) hmInput.get("idpTraceId");
		hmInput.put(CommonDefs.TRANSACTION_ID, idpTraceid.split(":")[0]);

        Boolean legacyFlagFromHeader = null;
        if (requestHeader != null) {
            String headerFlag = requestHeader.getFirst("legacy-api-enabled");
            if (headerFlag != null) {
                legacyFlagFromHeader = Boolean.valueOf(headerFlag);
            }
        }

        if (legacyFlagFromHeader != null) {
            flag = legacyFlagFromHeader;
            logger.info("Legacy flag supplied by caller in headers: {}", flag);
        } else {
            try {
                // Temporary fix for IDM registration IXP Async merge issue
                flag = featureManagerHelper.isEnabled("svc-idgraph-mergeuser-enable-legacyapi");
                logger.info("Legacy flag value is::: {}", flag);
            } catch (Exception e) {
                logger.error("{}{}MUS_00 : Exception while checking feature flag, defaulting to true", sClassName, sMethodName, e);
                flag = true;
            }
        }

		if (flag){
			logger.info(SpiMarker.getInstance(),
					"MergeUserAccessIdServiceImpl.mergeUserAccessId.MUS_01 : Calling MergeSlidProfileSoapHelper with Input " +
							": {}", StructuredArguments.entries(hmInput));
			hmResponse = mergeSlidProfileSoapHelper.callMergeSlidProfileSoapHelper(hmInput);
			logger.info("{}{}MUS_02 : Response from MergeSlidProfileSoapHelper Helper : {}", sClassName, sMethodName, hmResponse);
		}else{
			logger.info(SpiMarker.getInstance(),
					"MergeUserAccessIdServiceImpl.mergeUserAccessId.MUS_01 : Calling MergeUserAccessIdHelper with Input " +
							": {}", StructuredArguments.entries(hmInput));
			hmResponse=  mergeUserAccessIdHelper.mergeUserAccessId(hmInput);
			logger.info("{}{}MUS_02 : Response from MergeUserAccessId Helper : {}", sClassName, sMethodName, hmResponse);
		}



		if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
			hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from mergeUserAccessIdHelper" +
					".mergeUserAccessId");
			logger.info("{}{}MUS_03 : Null response from mergeUserAccessIdHelper.mergeUserAccessId", sClassName,
					sMethodName);
		} else {
			String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (stAppStatusCode == null) {
				hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from mergeUserAccessIdHelper" +
						".mergeUserAccessId");
				logger.info("{}{}MUS_04 : Null response from mergeUserAccessIdHelper.mergeUserAccessId", sClassName,
						sMethodName);
			}
		}

		hmResponse.put(CommonDefs.TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
		hmResponse.put("idp-trace-id", mergeUserAccessIdRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME, "MergeUserAccessId");
		MergeUserAccessIdResponse mergeUserAccessIdResponse = CommonUtilHelper.
				generateMergeUserAccessIdResponse(hmResponse);

		String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

		if (sTxnRollBack != null) {
			throw new InvalidInputDataException(hmResponse);
		}
		logger.info("{}{}MUS_05 : Response from mergeUserAccessIdServiceImpl.addUser : {}", sClassName, sMethodName,
				mergeUserAccessIdResponse);
		return mergeUserAccessIdResponse;
	}


}
