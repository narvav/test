package com.att.idp.idgraphusermanagementms.service.impl;

import java.util.Map;

import jakarta.ws.rs.core.MultivaluedMap;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.RegisterEmailUserHelper;
import com.att.idp.idgraphusermanagementms.resource.request.RegisterEmailUserRequest;
import com.att.idp.idgraphusermanagementms.resource.response.RegisterEmailUserResponse;
import com.att.idp.idgraphusermanagementms.service.RegisterEmailUserService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This class implements the RegisterEmailUserService interface and provides the implementation for registering an email user in the system.
 * It is annotated with @Service to indicate that it's a Spring Bean and @Transactional to handle the transaction management.
 *
 * It contains a method registerEmailUser which takes a RegisterEmailUserRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return a RegisterEmailUserResponse object.
 *
 * The RegisterEmailUserRequest object encapsulates the details of the email user registration operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class RegisterEmailUserServiceImpl implements RegisterEmailUserService{
	
	public static final Logger logger = LoggerFactory.getLogger(RegisterEmailUserServiceImpl.class);

	private static String sClassName = "RegisterEmailUserServiceImpl";
	
	@Autowired
	private RegisterEmailUserHelper registerEmailUserHelper;

	@Override
	public RegisterEmailUserResponse registerEmailUser(RegisterEmailUserRequest registerEmailUserRequest,
			MultivaluedMap<String, String> requestHeader) {
		
		Map<String, Object> hmResponse = null;
		String sMethodName = ".registerEmailUser.";
		
		Map<String, Object> hmInput = CommonUtilHelper.objectToMap(registerEmailUserRequest);
		
		String idpTraceid = (String) hmInput.get(ProfileOrchestrationConstants.IDPTRACEID);
		hmInput.put("dbusTransactionId", idpTraceid.split(":")[0]);
		hmInput.put("handle", (String) hmInput.remove("userId"));
		String stZip =  (String) hmInput.get("zip");
		if(!StringUtils.isEmpty(stZip)) {
			hmInput.put(CommonDefs.PROOFING_ZIP, (String) hmInput.remove("zip"));
		}
		
		logger.info(SpiMarker.getInstance(),
				"RegisterEmailUserServiceImpl.registerEmailUser.REUS_01 : Calling RegisterEmailUserHelper with Input : {}",
				StructuredArguments.entries(hmInput));

		hmResponse = registerEmailUserHelper.registerEmailUser(hmInput);

		hmResponse=CommonUtilHelper.processHmResponse(hmResponse, hmInput, "RegisterEmailUserHelper", ".registerEmailUser");
		hmResponse.put(ProfileOrchestrationConstants.IDP_TRACE_ID, registerEmailUserRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME, "RegisterEmailUser");
		RegisterEmailUserResponse registerEmailUserResponse = CommonUtilHelper.generateRegisterEmailUserResponse(hmResponse);

		String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

		if (sTxnRollBack != null) {
			throw new InvalidInputDataException(hmResponse);
		}
		logger.info("{}{}REUS_05 : Response from RegisterEmailUserServiceImpl.registerEmailUser : {}", sClassName, sMethodName,
				registerEmailUserResponse);
		return registerEmailUserResponse;
	}

}
