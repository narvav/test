package com.att.idp.idgraphusermanagementms.resource.response;

import com.att.idp.core.exception.ServiceError;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "AddUpdateUserBaseResponse")
public abstract class AddUpdateUserBaseResponse {

	protected AddUpdateUserBaseResponse() {

	}
	@JsonIgnore
	private String transactionName;
	private String appStatusMsg;
	private String appStatusCode;
	private String guid;
	private String appInfo;
	@JsonIgnore
	private String appCategoryCode;
	@JsonProperty("error")
	private ServiceError errors;
	private String suggestedHandle1;
	private String suggestedHandle2;
	private String suggestedHandle3;
	@JsonProperty("idp-trace-id")
	private String idpTraceId;
}