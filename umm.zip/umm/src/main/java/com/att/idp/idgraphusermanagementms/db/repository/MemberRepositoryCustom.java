package com.att.idp.idgraphusermanagementms.db.repository;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.HashMap;

/**
 * This is a custom repository interface for Member related operations.
 * It contains methods for adding members, checking user lists, getting member number sequences, and getting associated access IDs.
 * Each method may throw an SQLException if there is an error while executing the SQL query.
 */
public interface MemberRepositoryCustom {

	/**
	 * This method is used to add a new member to the database.
	 *
	 * @param InpParam A HashMap containing the details of the member to be added. The keys of the HashMap should correspond to the column names in the database.
	 * @return A HashMap containing the result of the operation. The keys of the HashMap should correspond to the column names in the database.
	 * @throws SQLException If there is an error while executing the SQL query.
	 */
	public HashMap addMem(HashMap InpParam) throws SQLException;

	/**
	 * This method is used to add auxiliary details for a new member to the database.
	 *
	 * @param hmInput A HashMap containing the auxiliary details of the member to be added. The keys of the HashMap should correspond to the column names in the database.
	 * @return A HashMap containing the result of the operation. The keys of the HashMap should correspond to the column names in the database.
	 * @throws SQLException If there is an error while executing the SQL query.
	 */
	public HashMap addMemberAux(HashMap hmInput) throws SQLException;

	/**
	 * This method is used to check if a user is present in the user list.
	 *
	 * @param hmInput A HashMap containing the details of the user to be checked. The keys of the HashMap should correspond to the column names in the database.
	 * @return A HashMap containing the result of the operation. The keys of the HashMap should correspond to the column names in the database.
	 */
	public HashMap<String, Object> checkUserList(HashMap<String, Object> hmInput);

	/**
	 * This method is used to retrieve the next member number sequence from the database.
	 *
	 * @return A BigDecimal representing the next member number sequence. If there is an error while retrieving the sequence, this method returns null.
	 */
	public BigDecimal getMemberNumSequence();

	/**
	 * This method is used to retrieve the associated access IDs for a given member from the database.
	 *
	 * @param hmInput A HashMap containing the details of the member for whom the access IDs are to be retrieved. The keys of the HashMap should correspond to the column names in the database.
	 * @return A HashMap containing the associated access IDs. The keys of the HashMap should correspond to the column names in the database.
	 * @throws SQLException If there is an error while executing the SQL query.
	 */
	public HashMap<String, Object> getAssociatedAccessIDs(HashMap<String, Object> hmInput) throws SQLException;

}