package com.att.idp.idgraphusermanagementms.request.validator;

import com.att.idp.idgraphusermanagementms.resource.request.UpdateUserRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdateUserResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.SharedUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import jakarta.ws.rs.core.HttpHeaders;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * This class, UpdateUserRequestValidator, is responsible for validating the UpdateUserRequest.
 * It checks for the presence and validity of required fields in the request, and returns an UpdateUserResponse accordingly.
 * It is annotated with @Component, @Configuration, and @PropertySource to indicate that it's a Spring Bean,
 * to allow it to access configuration properties, and to specify the location of the properties file respectively.
 *
 * The class contains several methods, including:
 * - updateUserRequestValidator: the main method that orchestrates the validation process.
 * - updateUserErrorResponse: a helper method that generates an error response.
 * - updateUserRequestInputValidator: a method that validates the input fields in the request.
 * - updateUserIsExternalCallCheck: a method that checks if the request is an external call.
 * - updateUserRequiredFieldCheck: a method that checks for the presence of required fields in the request.
 * - updateUserUpdateFlags: a method that validates the update flags in the request.
 * - updateUserRequestCSIValidator: a method that validates the 'CSI' field in the request.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class UpdateUserRequestValidator {
	private static final Logger logger = LoggerFactory.getLogger(UpdateUserRequestValidator.class);

	private String sClassName = "UpdateUserRequestValidator";

	@Value("${updateUserCallingSystemIds}")
	private String propCallingSystemId;

	@Value("${UpdateAgentId_Required_CSIs}")
	private String propUpdateUserAgentIdRequiredCSIs;

	@Value("${updateUserMemberIdUpdatableAttributes}")
	private String propAllowedFieldsForMemberIdUpdate;

	@Value("${UpdateUser_Input_To_DB_Keys_Mapping}")
	private String propUpdateUser_Input_To_DB_Keys_Mapping;

	@Autowired
	private CommonUtilHelper commonUtilHelper;

	@Autowired
	private SharedUtilHelper sharedUtilHelper;

	
	/**
	 * This method is responsible for validating the UpdateUserRequest.
	 * It takes HttpHeaders and UpdateUserRequest as parameters.
	 * HttpHeaders contains the request headers which may include additional information required for processing the request.
	 * UpdateUserRequest encapsulates the details of the update user operation to be performed.
	 *
	 * The method performs various checks and validations on the input parameters and returns an UpdateUserResponse object.
	 * The UpdateUserResponse object encapsulates the result of the update user operation.
	 *
	 * @param requestHeader The HttpHeaders containing the request headers.
	 * @param updateUserRequest The UpdateUserRequest containing the details of the update user operation.
	 * @return UpdateUserResponse The response of the update user operation.
	 */
	public UpdateUserResponse updateUserRequestValidator(HttpHeaders requestHeader, UpdateUserRequest updateUserRequest) {

		UpdateUserResponse updateUserResponse = null;

		String stAppInfo = null;
		String sMethodName = ".updateUserRequestValidator.";
		String stIdpTraceId = null;
		String stXAttClientId = null;
		
		stIdpTraceId = CommonUtil.getTraceId(requestHeader);

		if (stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
			stAppInfo = "Missing or Invalid IdpTraceId";
			return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (updateUserRequest == null) {
			stAppInfo = "Input Request Parameter is NULL / Empty.";
			logger.info("{}{}UURV_102 :: {}", sClassName, sMethodName, stAppInfo);
			return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					stIdpTraceId);
		}
		
		updateUserRequest.setIdpTraceId(stIdpTraceId);
			
		if (requestHeader.getHeaderString("X-ATT-ClientId") != null) {
			stXAttClientId = requestHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
			logger.info("{}{}UURV_101.2 : Setting callingSystemId: {}", sClassName, sMethodName,
					StringUtils.normalizeSpace(stXAttClientId));
			updateUserRequest.setCallingSystemId(stXAttClientId);
		} else {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			logger.info("{}{}UURV_101.3 :: {}", sClassName, sMethodName, stAppInfo);
			return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		// checking Invalid attributes passed in Request
		Map<String, Object> allUnknownAttributes = new HashMap<>(updateUserRequest.unknownAttributes);

		if (!allUnknownAttributes.isEmpty()) {
			stAppInfo = "Invalid Attributes passed in UpdateUserRequest : " + allUnknownAttributes;
			return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					updateUserRequest.getIdpTraceId());
		}
		
		try {
			updateUserResponse = updateUserRequestInputValidator(updateUserRequest);
			if (updateUserResponse != null) {
				logger.info("{}{}UURV_103 Response from updateUserRequestInputValidator : {}", sClassName, sMethodName,
						updateUserResponse);
				return updateUserResponse;
			} else {
				logger.debug("{}{}UURV_104 Success Response from updateUserRequestInputValidator ", sClassName,
						sMethodName);
			}
			updateUserResponse = updateUserRequestCSIValidator(updateUserRequest);
			if (updateUserResponse != null) {
				logger.info("{}{}UURV_105 Response from updateUserRequestCSIValidator : {}", sClassName, sMethodName,
						updateUserResponse);
				return updateUserResponse;
			} else {
				logger.debug("{}{}UURV_106 Success Response from updateUserRequestCSIValidator ", sClassName, sMethodName);
			}
			updateUserResponse = updateUserDomainLevelAttributesValidator(updateUserRequest);
			if (updateUserResponse != null) {
				logger.info("{}{}UURV_107 Response from updateUserDomainLevelAttributesValidator : {}", sClassName, sMethodName,
						updateUserResponse);
				return updateUserResponse;
			} else {
				logger.debug("{}{}UURV_108 Success Response from updateUserDomainLevelAttributesValidator ", sClassName, sMethodName);
			}

			stAppInfo = "Input Validation Successful";
			logger.info("{}{}UURV_109 : {}", sClassName, sMethodName, stAppInfo);

		} catch (Exception e) {
			stAppInfo = "Exception thrown in UpdateUserRequestValidator.updateUserRequestValidator : " + e.getMessage();
			updateUserResponse = updateUserErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo, stIdpTraceId);
			logger.error("Exception in updateUserRequestValidator: {}", stAppInfo);
		}

		return updateUserResponse;
	}

	private UpdateUserResponse updateUserErrorResponse(int appStatusCode, String stAppInfo, String stIdpTraceId) {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		return CommonUtilHelper.generateUpdateUserResponse(hmResponse);
	}

	/**
	 * This method is part of the UpdateUserRequestValidator class.
	 * It is responsible for validating the UpdateUserRequest.
	 * The method takes an UpdateUserRequest as input.
	 * The UpdateUserRequest encapsulates the details of the update user operation to be performed.
	 * The method performs various checks and validations on the input parameters and returns an UpdateUserResponse object.
	 * The UpdateUserResponse object encapsulates the result of the update user operation.
	 * The method checks for the presence and validity of required fields in the request, and returns an UpdateUserResponse accordingly.
	 *
	 * @param updateUserRequest The UpdateUserRequest containing the details of the update user operation.
	 * @return UpdateUserResponse The response of the update user operation.
	 */
	public UpdateUserResponse updateUserRequestInputValidator(UpdateUserRequest updateUserRequest) {
		String stAppInfo;
		UpdateUserResponse updateUserResponse = null;

		Optional.ofNullable(updateUserRequest.getCallingSystemId())
				.ifPresent(x -> updateUserRequest.setCallingSystemId(x.trim().toUpperCase()));
		Optional.ofNullable(updateUserRequest.getFirstName()).ifPresent(x -> updateUserRequest.setFirstName(x.trim()));
		Optional.ofNullable(updateUserRequest.getLastName()).ifPresent(x -> updateUserRequest.setLastName(x.trim()));
		Optional.ofNullable(updateUserRequest.getHandle())
				.ifPresent(x -> updateUserRequest.setHandle(x.trim().toLowerCase()));
		Optional.ofNullable(updateUserRequest.getDomain())
				.ifPresent(x -> updateUserRequest.setDomain(x.trim().toLowerCase()));
		Optional.ofNullable(updateUserRequest.getGuid())
				.ifPresent(x -> updateUserRequest.setGuid(x.trim().toLowerCase()));
		Optional.ofNullable(updateUserRequest.getActivatedInd())
				.ifPresent(x -> updateUserRequest.setActivatedInd(x.trim().toUpperCase()));
		Optional.ofNullable(updateUserRequest.getIsVerified())
				.ifPresent(x -> updateUserRequest.setIsVerified(x.trim().toUpperCase()));
		Optional.ofNullable(updateUserRequest.getMainCTNOptOut())
				.ifPresent(x -> updateUserRequest.setMainCTNOptOut(x.trim().toUpperCase()));
		Optional.ofNullable(updateUserRequest.getCbrOptOut())
				.ifPresent(x -> updateUserRequest.setCbrOptOut(x.trim().toUpperCase()));
		Optional.ofNullable(updateUserRequest.getContactEmailStatus())
				.ifPresent(x -> updateUserRequest.setContactEmailStatus(x.trim()));
		Optional.ofNullable(updateUserRequest.getZipCode())
				.ifPresent(x -> updateUserRequest.setZipCode(x.trim()));
		Optional.ofNullable(updateUserRequest.getZipCode4())
				.ifPresent(x -> updateUserRequest.setZipCode4(x.trim()));
		Optional.ofNullable(updateUserRequest.getContactEmail())
				.ifPresent(x -> updateUserRequest.setContactEmail(x.trim().toLowerCase()));
		Optional.ofNullable(updateUserRequest.getOnline1SecurityQuestion())
				.ifPresent(x -> updateUserRequest.setOnline1SecurityQuestion(x.trim()));
		Optional.ofNullable(updateUserRequest.getOnline1SecurityAnswer())
				.ifPresent(x -> updateUserRequest.setOnline1SecurityAnswer(x.trim().toLowerCase()));
		Optional.ofNullable(updateUserRequest.getOnline2SecurityQuestion())
				.ifPresent(x -> updateUserRequest.setOnline2SecurityQuestion(x.trim()));
		Optional.ofNullable(updateUserRequest.getOnline2SecurityAnswer())
				.ifPresent(x -> updateUserRequest.setOnline2SecurityAnswer(x.trim().toLowerCase()));
		Optional.ofNullable(updateUserRequest.getCbrNumber())
				.ifPresent(x -> updateUserRequest.setCbrNumber(x.trim()));
		Optional.ofNullable(updateUserRequest.getCbrRTValidFlag())
				.ifPresent(x -> updateUserRequest.setCbrRTValidFlag(x.trim().toUpperCase()));
		Optional.ofNullable(updateUserRequest.getContactAddress())
				.ifPresent(x -> updateUserRequest.setContactAddress(x.trim()));
		Optional.ofNullable(updateUserRequest.getNickName())
				.ifPresent(x -> updateUserRequest.setNickName(x.trim()));


		String stCallingSystemId = updateUserRequest.getCallingSystemId();
		String stHandle = updateUserRequest.getHandle();
		String domain = updateUserRequest.getDomain();
		String stOnlineSecQues1 = updateUserRequest.getOnline1SecurityQuestion();
		String stOnlineSecAns1 = updateUserRequest.getOnline1SecurityAnswer();
		String stOnlineSecQues2 = updateUserRequest.getOnline2SecurityQuestion();
		String stOnlineSecAns2 = updateUserRequest.getOnline2SecurityAnswer();
		String stBrowerLang = updateUserRequest.getBrowserLanguage();
		String stIdpTraceId=updateUserRequest.getIdpTraceId();
		String stGuid = updateUserRequest.getGuid();
		String stActivatedInd = updateUserRequest.getActivatedInd();
		String stIsVerified = updateUserRequest.getIsVerified();
		String stMainCTNOptOut = updateUserRequest.getMainCTNOptOut();
		String stCbrOptOut = updateUserRequest.getCbrOptOut();
		String stContactEmailStatus = updateUserRequest.getContactEmailStatus();
		String stContactEmail = updateUserRequest.getContactEmail();
		String stZipcode = updateUserRequest.getZipCode();
		String stZipcode4 = updateUserRequest.getZipCode4();
        String stCbrNumber=updateUserRequest.getCbrNumber();
		String stCbrRTValidFlag = updateUserRequest.getCbrRTValidFlag();

		updateUserResponse = updateUserIsExternalCallCheck(updateUserRequest);
		if (updateUserResponse != null) {
			return updateUserResponse;
		}

		updateUserResponse = updateUserRequiredFieldCheck(updateUserRequest);
		if (updateUserResponse != null) {
			return updateUserResponse;
		}

		if (updateUserResponse != null) {
			return updateUserResponse;
		}

		if ((stOnlineSecQues1 == null && stOnlineSecAns1 != null)
				|| (stOnlineSecQues1 != null && stOnlineSecAns1 == null)) {
			stAppInfo = "Either of online1SecurityQuestion or online1SecurityAnswer are null or empty.";
			return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if ((stOnlineSecQues2 == null && stOnlineSecAns2 != null)
				|| (stOnlineSecQues2 != null && stOnlineSecAns2 == null)) {
			stAppInfo = "Either of online2SecurityQuestion or online2SecurityAnswer are null or empty.";
			return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (stBrowerLang != null && !stBrowerLang.isEmpty()) {
			stBrowerLang = stBrowerLang.trim().toLowerCase();
			updateUserRequest.setBrowserLanguage(stBrowerLang);
			if (!(stBrowerLang.equals("en") || stBrowerLang.equals("es"))) {
				stAppInfo = "browserLanguage is Invalid :: Should be one of [en, es]";
				return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
		}

		if(stContactEmail!=null && !stContactEmail.isEmpty()) {
			if(stContactEmailStatus==null ||stContactEmailStatus.isEmpty())
				updateUserRequest.setContactEmailStatus("V");
			else if(!(stContactEmailStatus.equals("H")||(stContactEmailStatus.equals("S"))||(stContactEmailStatus.equals("V")))) {
				stAppInfo = "Invalid contactEmailStatus can be only H ,S or V";
				return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}

			Boolean bIsNotValidEmail = false;
			String domainName = "";
			int separator = stContactEmail.indexOf("@");

			if (separator <= 0)
				bIsNotValidEmail = true;
			else
				domainName = stContactEmail.substring(separator + 1);

			if (domainName.indexOf(".") <= 0)
				bIsNotValidEmail = true;
			else if (domainName.substring(domainName.indexOf(".") + 1).equals(""))
				bIsNotValidEmail = true;

			if (bIsNotValidEmail) {
				stAppInfo = "input contactEmail format is invalid.";
				return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
		}

		if (StringUtils.isNotEmpty(stCbrNumber) && stCbrNumber.length() != 10) {
			stAppInfo = "CbrNumber value must be 10 digits";
			return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		if (StringUtils.isNotEmpty(stCbrRTValidFlag) && (stCbrNumber==null || stCbrNumber.isEmpty())) {
			stAppInfo = "CBR Number is mandatory when CBR RT Valid Flag is provided";
			return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (stZipcode != null && !isValidProofZip(stZipcode)) {
			stAppInfo = "Input zipcode format is incorrect";
			return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if(stZipcode4 != null && !isValidProofZip(stZipcode4)) {
			stAppInfo = "Input zipcode4 format is incorrect";
			return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		updateUserResponse = updateUserUpdateFlags(updateUserRequest);
		return updateUserResponse;
	}

	private UpdateUserResponse updateUserIsExternalCallCheck(UpdateUserRequest updateUserRequest) {
		UpdateUserResponse updateUserResponse = null;
		String stAppInfo;
		String isExternalCall = updateUserRequest.getIsExternalCall();
		String stIdpTraceId=updateUserRequest.getIdpTraceId();
		
		if ((isExternalCall != null && !isExternalCall.isEmpty())) {
			if (!(isExternalCall.equalsIgnoreCase(CommonDefs.IND_Y)
					|| isExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
				stAppInfo = "isExternalCall must be one of Y or N";
				return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			} else {
				updateUserRequest.setIsExternalCall(isExternalCall.trim().toUpperCase());
			}
		} else {
			updateUserRequest.setIsExternalCall(CommonDefs.IND_Y);
		}
		return updateUserResponse;
	}

	private UpdateUserResponse updateUserRequiredFieldCheck(UpdateUserRequest updateUserRequest) {
		String stAppInfo = null;
		UpdateUserResponse updateUserResponse = null;
		Map<String, Object> hmResult = CommonUtil.getHashMap();
		String stCallingSystemId = updateUserRequest.getCallingSystemId();
		String stTransactionName = updateUserRequest.getTransactionName();
		String stHandle = updateUserRequest.getHandle();
		String stIdpTraceId=updateUserRequest.getIdpTraceId();
		String guid = updateUserRequest.getGuid();
		String userId = updateUserRequest.getHandle();
		String stCbrRTValidFlag = updateUserRequest.getCbrRTValidFlag();
		String stCbNumber = updateUserRequest.getCbrNumber();
		if ((stTransactionName == null || stTransactionName.trim().isEmpty())
				|| (stCallingSystemId == null || stCallingSystemId.trim().isEmpty())) {
			stAppInfo = "Required field(s) missing";

			return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (!"UpdateUser".equals(updateUserRequest.getTransactionName())) {
			stAppInfo = "Transaction Not Allowed :: TransactionName Should be UpdateUser";
			return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if ((guid == null || guid.trim().isEmpty())	&& (userId == null || userId.trim().isEmpty())) {
			stAppInfo = "Either of guid or userId is mandatory";
			return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		return updateUserResponse;
	}

	private UpdateUserResponse updateUserUpdateFlags(UpdateUserRequest updateUserRequest) {
		UpdateUserResponse updateUserResponse = null;
		String stAccessIdRTValidFlag = updateUserRequest.getAccessIdRTValidFlag();
		String stContactEmailRTValidFlag = updateUserRequest.getContactEmailRTValidFlag();
		String stAppInfo;
		String stIdpTraceId=updateUserRequest.getIdpTraceId();
		String stActivatedInd = updateUserRequest.getActivatedInd();
		String stIsVerified = updateUserRequest.getIsVerified();
		String stMainCTNOptOut = updateUserRequest.getMainCTNOptOut();
		String stCbrOptOut = updateUserRequest.getCbrOptOut();
		String stCbrRTValidFlag = updateUserRequest.getCbrRTValidFlag();

		if (stActivatedInd != null && !stActivatedInd.isEmpty()) {
			if (!(stActivatedInd.equals("Y") || stActivatedInd.equals("N"))) {
				stAppInfo = "ActivatedInd is Invalid :: Should be Y or N";
				return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
		}

		if (stIsVerified != null && !stIsVerified.isEmpty()) {
			if (!(stIsVerified.equals("Y") || stIsVerified.equals("N"))) {
				stAppInfo = "IsVerified is Invalid :: Should be Y or N";
				return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
		}

		if (stMainCTNOptOut != null && !stMainCTNOptOut.isEmpty()) {
			if (!(stMainCTNOptOut.equals("Y") || stMainCTNOptOut.equals("N"))) {
				stAppInfo = "MainCTNOptOut is Invalid :: Should be Y or N";
				return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
		}

		if (stCbrOptOut != null && !stCbrOptOut.isEmpty()) {
			if (!(stCbrOptOut.equals("Y") || stCbrOptOut.equals("N"))) {
				stAppInfo = "CbrOptOut is Invalid :: Should be Y or N";
				return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
		}

		if (stAccessIdRTValidFlag != null && !stAccessIdRTValidFlag.isEmpty()) {
			stAccessIdRTValidFlag = stAccessIdRTValidFlag.trim().toUpperCase();
			if (!(stAccessIdRTValidFlag.equals("Y") || stAccessIdRTValidFlag.equals("N"))) {
				stAppInfo = "AccessIdRTValidFlag is Invalid :: Should be Y or N";
				return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
			updateUserRequest.setAccessIdRTValidFlag(stAccessIdRTValidFlag);
		}

		if (stContactEmailRTValidFlag != null && !stContactEmailRTValidFlag.isEmpty()) {
			stContactEmailRTValidFlag = stContactEmailRTValidFlag.trim().toUpperCase();
			if (!(stContactEmailRTValidFlag.equals("Y") || stContactEmailRTValidFlag.equals("N"))) {
				stAppInfo = "ContactEmailRTValidFlag is Invalid :: Should be Y or N";
				return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
			updateUserRequest.setContactEmailRTValidFlag(stContactEmailRTValidFlag);
		}
		if (StringUtils.isNotEmpty(stCbrRTValidFlag) && !stCbrRTValidFlag.equals("Y") && !stCbrRTValidFlag.equals("N")) {
			stAppInfo = "stCbrRTValidFlag is Invalid :: Should be Y or N";
			return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		return null;
	}

	private UpdateUserResponse updateUserRequestCSIValidator(UpdateUserRequest updateUserRequest) {
		String sMethodName = ".updateUserRequestCSIValidator.";
		String sIsExternalCall = updateUserRequest.getIsExternalCall();
		String stCallingSystemId = updateUserRequest.getCallingSystemId();
		String stIdpTraceId=updateUserRequest.getIdpTraceId();
		String stAgentId = updateUserRequest.getAgentId();
		String stAppInfo;

		ArrayList alAgentIdRequiredCSI;
		ArrayList alUpdateUserCallingSystemIds;

		alUpdateUserCallingSystemIds = CommonUtil.parseToArray(propCallingSystemId, CommonDefs.VALUE_SEPARATOR_CHAR);
		alAgentIdRequiredCSI = CommonUtil.parseToArray(propUpdateUserAgentIdRequiredCSIs, CommonDefs.VALUE_SEPARATOR_CHAR);

		logger.debug("{}{}UURV_104.2 :  Property updateUserCallingSystemIds : {}", sClassName, sMethodName,
				alUpdateUserCallingSystemIds);

		if (alUpdateUserCallingSystemIds != null && !alUpdateUserCallingSystemIds.contains(stCallingSystemId)
				&& sIsExternalCall != null && CommonDefs.IND_Y.equals(sIsExternalCall)) {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (alAgentIdRequiredCSI != null && !alAgentIdRequiredCSI.isEmpty()) {
			if (alAgentIdRequiredCSI.contains(stCallingSystemId)) {
				if (stAgentId == null || stAgentId.isEmpty()) {
					stAppInfo = "agentId is required for the caller";
					logger.info("{}{}UURV_104.3: {} " , sClassName , sMethodName, stAppInfo);
					return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
				}
			}
		}
		return null;
	}

	/**
	 * Validates domain-level attributes in the update user request.
	 * <p>
	 * This method converts the incoming {@link UpdateUserRequest} to a map and prepares
	 * various attribute maps for SLID and MemberId level updates using helper utilities.
	 * It then determines the type of update (MemberId or SLID level) based on the domain value,
	 * and delegates further validation to the appropriate method.
	 * </p>
	 *
	 * @param updateUserRequest the {@link UpdateUserRequest} containing user update details
	 * @return {@link UpdateUserResponse} if validation fails, or null if validation passes
	 */
	private UpdateUserResponse updateUserDomainLevelAttributesValidator(UpdateUserRequest updateUserRequest) {
		String sMethodName = ".updateUserDomainLevelAttributesValidator.";
		String domain = updateUserRequest.getDomain();

		Map<String, Object> hmInput = CommonUtilHelper.objectToMap(updateUserRequest);
		HashMap hmUpdateUserInputToDBKeysMap = CommonUtil.parsePropertyToHash(propUpdateUser_Input_To_DB_Keys_Mapping);
		logger.info("{}{}UUDLAV_01 : Property UpdateUser_Input_To_DB_Keys_Mapping : {} ", sClassName, sMethodName,
				hmUpdateUserInputToDBKeysMap);

		HashMap hmMemberDataSlidAndMembers = sharedUtilHelper.populateMemberDataForSlidAndMembers(hmInput,hmUpdateUserInputToDBKeysMap);
		HashMap hmMemberDataSlidOnly = sharedUtilHelper.populateMemberDataForSlidOnly(hmInput,hmUpdateUserInputToDBKeysMap);
		HashMap hmMemberDataContactInfoFields = sharedUtilHelper.populateMemberDataForContactInfoFields(hmInput,hmUpdateUserInputToDBKeysMap);
		HashMap hmMemberDataMemberIdOnly = sharedUtilHelper.populateMemberDataForMemberIdOnly(hmInput,hmUpdateUserInputToDBKeysMap);

		if(domain != null && !CommonDefs.SLID_DUM.equals(domain)) {
			return memberIdLevelUpdateCheck(updateUserRequest,hmMemberDataMemberIdOnly,hmMemberDataSlidAndMembers,hmMemberDataSlidOnly,hmMemberDataContactInfoFields);
		} else if(domain != null && CommonDefs.SLID_DUM.equals(domain)) {
			return slidLevelUpdateCheck(updateUserRequest,hmMemberDataMemberIdOnly,hmMemberDataSlidAndMembers,hmMemberDataSlidOnly,hmMemberDataContactInfoFields);
		}

		return null;
	}

	/**
	 * Validates that only allowed member-level attributes are being updated in the request.
	 * Handles common attributes present in both member and other maps.
	 *
	 * @param updateUserRequest The {@link UpdateUserRequest} containing user update details.
	 * @param hmMemberDataMemberIdOnly Map of attributes allowed for member-level updates.
	 * @param hmMemberDataSlidAndMembers Map of attributes allowed for both SLID and member updates.
	 * @param hmMemberDataSlidOnly Map of attributes allowed only for SLID updates.
	 * @param hmMemberDataContactInfoFields Map of contact info attributes.
	 * @return {@link UpdateUserResponse} if validation fails, or null if validation passes.
	 */
	private UpdateUserResponse memberIdLevelUpdateCheck(
			UpdateUserRequest updateUserRequest,
			HashMap hmMemberDataMemberIdOnly,
			HashMap hmMemberDataSlidAndMembers,
			HashMap hmMemberDataSlidOnly,
			HashMap hmMemberDataContactInfoFields) {

		String stAppInfo;
		String stIdpTraceId = updateUserRequest.getIdpTraceId();

		if (hmMemberDataMemberIdOnly == null || hmMemberDataMemberIdOnly.isEmpty()) {
			stAppInfo = "Input does not contains valid attributes for member level update.";
			return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		Set<String> memberOnlyKeys = new HashSet<>(hmMemberDataMemberIdOnly.keySet());

		// Remove common keys from other maps before error check
		if (hmMemberDataSlidAndMembers != null && !hmMemberDataSlidAndMembers.isEmpty()) {
			Set<String> slidAndMemberKeys = new HashSet<>(hmMemberDataSlidAndMembers.keySet());
			slidAndMemberKeys.removeAll(memberOnlyKeys);
			if (!slidAndMemberKeys.isEmpty()) {
				stAppInfo = "User can not update SLID attributes " + slidAndMemberKeys + " for member level update.";
				return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
		}

		if (hmMemberDataSlidOnly != null && !hmMemberDataSlidOnly.isEmpty()) {
			Set<String> slidOnlyKeys = new HashSet<>(hmMemberDataSlidOnly.keySet());
			slidOnlyKeys.removeAll(memberOnlyKeys);
			if (!slidOnlyKeys.isEmpty()) {
				stAppInfo = "User can not update SLID attributes " + slidOnlyKeys + " for member level update.";
				return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
		}

		if (hmMemberDataContactInfoFields != null && !hmMemberDataContactInfoFields.isEmpty()) {
			Set<String> contactInfoKeys = new HashSet<>(hmMemberDataContactInfoFields.keySet());
			contactInfoKeys.removeAll(memberOnlyKeys);
			if (!contactInfoKeys.isEmpty()) {
				stAppInfo = "User can not update SLID attributes " + contactInfoKeys + " for member level update.";
				return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
		}

		return null;
	}


	/**
	 * Validates that only allowed SLID-level attributes are being updated in the request.
	 * Handles common attributes present in both member and SLID maps.
	 *
	 * @param updateUserRequest The {@link UpdateUserRequest} containing user update details.
	 * @param hmMemberDataMemberIdOnly Map of attributes allowed only for member-level updates.
	 * @param hmMemberDataSlidAndMembers Map of attributes allowed for both SLID and member updates.
	 * @param hmMemberDataSlidOnly Map of attributes allowed only for SLID updates.
	 * @param hmMemberDataContactInfoFields Map of contact info attributes.
	 * @return {@link UpdateUserResponse} if validation fails, or null if validation passes.
	 */
	private UpdateUserResponse slidLevelUpdateCheck(
			UpdateUserRequest updateUserRequest,
			HashMap hmMemberDataMemberIdOnly,
			HashMap hmMemberDataSlidAndMembers,
			HashMap hmMemberDataSlidOnly,
			HashMap hmMemberDataContactInfoFields) {

		String stIdpTraceId = updateUserRequest.getIdpTraceId();

		boolean isSlidAndMembersEmpty = CommonUtilHelper.isCollectionMapNullOrEmpty(hmMemberDataSlidAndMembers);
		boolean isSlidOnlyEmpty = CommonUtilHelper.isCollectionMapNullOrEmpty(hmMemberDataSlidOnly);
		boolean isContactInfoEmpty = CommonUtilHelper.isCollectionMapNullOrEmpty(hmMemberDataContactInfoFields);

		if (isSlidAndMembersEmpty && isSlidOnlyEmpty && isContactInfoEmpty) {
			String stAppInfo = "Input does not contains valid attributes for SLID level update.";
			return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		Set<String> memberOnlyKeys = hmMemberDataMemberIdOnly != null
				? new HashSet<>(hmMemberDataMemberIdOnly.keySet())
				: new HashSet<>();

		if (hmMemberDataSlidAndMembers != null) {
			memberOnlyKeys.removeAll(hmMemberDataSlidAndMembers.keySet());
		}
		if (hmMemberDataSlidOnly != null) {
			memberOnlyKeys.removeAll(hmMemberDataSlidOnly.keySet());
		}
		if (hmMemberDataContactInfoFields != null) {
			memberOnlyKeys.removeAll(hmMemberDataContactInfoFields.keySet());
		}

		if (!memberOnlyKeys.isEmpty()) {
			String stAppInfo = "User can not update member attributes " + memberOnlyKeys + " for SLID level update.";
			return updateUserErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		return null;
	}


	/**
	 * Validates that the provided proofZip contains only numeric digits.
	 * <p>
	 * The method trims the input string and checks if it is not empty.
	 * It then verifies that the trimmed string consists only of numeric characters.
	 * </p>
	 *
	 * @param proofZip the zip code string to validate
	 * @return true if the trimmed proofZip is not empty and contains only digits; false otherwise
	 */
	private boolean isValidProofZip(String proofZip) {
		if (proofZip.trim().isEmpty()) {
			return false;
		}
		return  StringUtils.isNumeric(proofZip.trim());
	}


}
