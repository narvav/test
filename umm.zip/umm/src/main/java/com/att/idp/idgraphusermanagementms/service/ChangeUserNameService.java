package com.att.idp.idgraphusermanagementms.service;

import jakarta.ws.rs.core.MultivaluedMap;

import com.att.idp.idgraphusermanagementms.resource.request.ChangeUserNameRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ChangeUserNameResponse;

/**
 * This interface defines the contract for the ChangeUserNameService in the system.
 * It contains a single method changeUserName which takes a ChangeUserNameRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return a ChangeUserNameResponse object.
 *
 * The ChangeUserNameRequest object encapsulates the details of the user for whom the username is to be changed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
public interface ChangeUserNameService {

	/**
	 * This method is part of the ChangeUserNameService interface.
	 * It is responsible for changing a user's name in the system.
	 * The method takes a ChangeUserNameRequest object as a parameter, which encapsulates the details of the user for whom the username is to be changed.
	 * The method also takes a MultivaluedMap of request headers as a parameter, which may include additional information required for processing the request.
	 * The method returns a ChangeUserNameResponse object representing the response from the system after changing the user's name.
	 *
	 * @param changeUserNameRequest An object encapsulating the details of the user for whom the username is to be changed.
	 * @param requestHeader A MultivaluedMap containing the request headers which may include additional information required for processing the request.
	 * @return ChangeUserNameResponse A object representing the response from the system after changing the user's name.
	 */
	ChangeUserNameResponse changeUserName(ChangeUserNameRequest changeUserNameRequest,
			MultivaluedMap<String, String> requestHeader);

}
