package com.att.idp.idgraphusermanagementms.db.repository;

import java.sql.SQLException;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.att.idp.idgraphusermanagementms.db.model.Tmembergroup;

/**
 * This is the repository interface for the MemberGroup entity.
 * It extends JpaRepository to provide standard data access operations on the MemberGroup entity.
 * It also extends MemberGroupRepositoryCustom to provide custom data access operations.
 *
 * @param <Tmembergroup> The type of the entity this repository manages.
 * @param <Long> The type of the id of the entity this repository manages.
 */
@Repository 
public interface MemberGroupRepository extends JpaRepository<Tmembergroup, Long> , MemberGroupRepositoryCustom {
	
	
	/**
	 * This method is used to retrieve the group number of a MemberGroup entity based on its parent name and domain ID.
	 *
	 * @param parentName The parent name of the MemberGroup entity. This is used to search for the MemberGroup in the database.
	 * @param domainId The domain ID of the MemberGroup entity. This is used in conjunction with the parent name to search for the MemberGroup in the database.
	 * @return The group number of the MemberGroup entity with the provided parent name and domain ID. If no such MemberGroup is found, this method returns null.
	 * @throws SQLException If there is an error while executing the SQL query.
	 */
	@Query(value = "select GROUP_NUM from MPS_OWNER.TMEMBERGROUP memGrp where memGrp.PARENT_NAME=:parentName and memGrp.DOMAIN_ID=:domainId", nativeQuery = true)
	public Long getMemberGrpByParentNmAndDomainId(@Param(value = "parentName") String parentName,
														  @Param(value = "domainId") Long domainId) throws SQLException;
}
