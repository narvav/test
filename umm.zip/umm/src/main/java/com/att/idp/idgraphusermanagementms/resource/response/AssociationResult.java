package com.att.idp.idgraphusermanagementms.resource.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This class represents the result of a single association item in the registrationOrchestration response.
 * Each result contains the serviceName, sorInvariantId, statusCode, and statusMsg for the processed item.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "AssociationResult")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AssociationResult {

    private String serviceName;
    private String sorInvariantId;
    private String statusCode;
    private String statusMsg;
}
