package com.att.idp.idgraphusermanagementms.resource.impl;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_IB;
import static com.att.idp.cd.observability.metrics.utils.Constants.URI;
import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.POST;
import static com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants.IDGRAPH_USERMANAGEMENTMS_IB;
import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.request.validator.ProfanityScannerRequestValidator;
import com.att.idp.idgraphusermanagementms.resource.ProfanityScannerResource;
import com.att.idp.idgraphusermanagementms.resource.request.ProfanityScannerRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ProfanityScannerResponse;
import com.att.idp.idgraphusermanagementms.service.ProfanityScannerService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.stereotype.Controller;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import java.sql.SQLException;
import java.util.Map;

import static com.att.mpsys.common.utils.CommonUtil.getElapsedTimeInSecs;
/**
 * This is the ProfanityScannerRosurceImpl class. It implements the ProfanityScannerResource interface.
 * We are calling the profanityScannerRequestValidator for validating the request and handling any exceptions that may occur.
 * The class also contains a  method profanityScanner method which checks for profanity words in the given scanItem.
 */
@Controller
@OpenAPIDefinition(
        info = @Info(title="User Management",
                description="IDGraphUserManagementMs provides services that are used to perform identity specific " +
                        "operations like creating new accessId, registering a currently.com memberId, updating " +
                        "profile attributes of the existing accessId, and fraud locking access Id. This information " +
                        "gets stored in IdentityGraph database and gets provisioned/replicated to multiple systems " +
                        "e.g. HALOC, Yahoo, CG, CCR, G2 etc.\n\n\n\n.", version="0.0.1"),
        servers = {
                @Server(url="https://apporigin-dev2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/"),
                @Server(url="https://apporigin-tst2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/")
        })
public class ProfanityScannerRosurceImpl implements ProfanityScannerResource {

    public static final Logger logger = LoggerFactory.getLogger(ProfanityScannerRosurceImpl.class);

    @Autowired
    ProfanityScannerRequestValidator profanityScannerRequestValidator;

    @Autowired
    ProfanityScannerService profanityScannerService;

    /**
     * This is the implementation of the profanityScanner method from the ProfanityScannerResource interface.
     * It checks for profanity words in the given scanItem.
     *
     * @param profanityScannerRequest This is the request body. It should be a valid instance of ProfanityScannerRequest.
     * @param httpHeader This is the HTTP headers from the request.
     * @return A Response object. The response status can be 200 for success, 400 for bad request, or 500 for an unknown exception in the application.
     * @throws MPSException This exception is thrown if there is an error during the processing of the request.
     */
    @TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
            description = "profanity scanner",
            tags = {URI, "/msapi/idgraphusermanagementms/v1/profanity/scanner", METHOD, POST},
            histogram = true)
    @Override
    public Response profanityScanner(ProfanityScannerRequest profanityScannerRequest, HttpHeaders httpHeader) throws MPSException {
        Map<String, Object> hmResponse = CommonUtil.getHashMap();
        ProfanityScannerResponse profanityScannerResponse = null;
        long startTm = System.currentTimeMillis();
        Response responseObj = null;
        try {

            MultivaluedMap<String, String> requestHeader = httpHeader.getRequestHeaders();

            logger.info(SpiMarker.getInstance(),"WEB_01 : profanityScanner Input : {} | profanityScanner Request Header  : {}",
                    (profanityScannerRequest != null ? StringUtils.normalizeSpace(profanityScannerRequest.toString())
                            : "null"), StringUtils.normalizeSpace(requestHeader != null ? requestHeader.toString() : null));

            profanityScannerResponse = profanityScannerRequestValidator.profanityScannerReqValidator(httpHeader, profanityScannerRequest);
            logger.info(SpiMarker.getInstance(),"WEB000 : profanityScanner Request  : {}", profanityScannerRequest);


            if (profanityScannerResponse == null) {
                // call the service class
                profanityScannerResponse = profanityScannerService.profanityScanner(profanityScannerRequest, requestHeader);
                logger.info("WEB_02 : profanityScanner Service Response : {}", profanityScannerResponse);
            }
        } catch (Exception e) {
            if (e instanceof InvalidInputDataException) {
                logger.error("InvalidInputDataException: {}", e.getMessage());
                throw e;
            }
            else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
            }
            else {
                hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
            }
            hmResponse.put("idp-trace-id", profanityScannerRequest.getIdpTraceId());
            profanityScannerResponse = CommonUtilHelper.generateProfanityScannerResponse(hmResponse);
        }
        responseObj = CommonUtilHelper.buildMSResponse(profanityScannerResponse);
        String sTimeTaken = getElapsedTimeInSecs(startTm) + " seconds";

        logger.info("WEB999 : Total time taken : {} ProfanityScanner Response : {}",sTimeTaken, profanityScannerResponse);
        return responseObj;
    }
}