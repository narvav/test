package com.att.idp.idgraphusermanagementms.resource.impl;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_IB;
import static com.att.idp.cd.observability.metrics.utils.Constants.URI;
import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.POST;
import static com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants.IDGRAPH_USERMANAGEMENTMS_IB;
import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.request.validator.AddSecMemberIdRequestValidator;
import com.att.idp.idgraphusermanagementms.resource.AddSecMemberIdResource;
import com.att.idp.idgraphusermanagementms.resource.request.AddSecMemberIdRequest;
import com.att.idp.idgraphusermanagementms.resource.response.AddSecMemberIdResponse;
import com.att.idp.idgraphusermanagementms.service.AddSecMemberIdService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.stereotype.Controller;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.Response;
import java.sql.SQLException;
import java.util.Map;

@Controller
@OpenAPIDefinition(
        info = @Info(title="User Management",
                description="IDGraphUserManagementMs provides services that are used to perform identity specific " +
                        "operations like creating new accessId, registering a currently.com memberId, updating " +
                        "profile attributes of the existing accessId, and fraud locking access Id. This information " +
                        "gets stored in IdentityGraph database and gets provisioned/replicated to multiple systems " +
                        "e.g. HALOC, Yahoo, CG, CCR, G2 etc.\n\n\n\n.", version="0.0.1"),
        servers = {
                @Server(url="https://apporigin-dev2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/"),
                @Server(url="https://apporigin-tst2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/")
        })
public class AddSecMemberIdResourceImpl implements AddSecMemberIdResource {

    /**
     * Logger instance for logging events.
     */
    public static final Logger logger = LoggerFactory.getLogger(AddSecMemberIdResourceImpl.class);

    /**
     * Class name for logging purposes.
     */
    private static String sClassName = "AddSecMemberIdResourceImpl";

    /**
     * Validator for AddSecMemberIdRequest.
     */
    @Autowired
    private AddSecMemberIdRequestValidator addSecMemberIdRequestValidator;

    /**
     * Service for handling AddSecMemberId operations.
     */
    @Autowired
    private AddSecMemberIdService addSecMemberIdService;

    /**
     * Adds a secondary member ID in the MPSYS system.
     * This method handles the HTTP POST request to add a secondary member ID.
     *
     * @param addSecMemberIdRequest The request object containing the details for adding a secondary member ID.
     * @param httpHeader The HTTP headers of the request.
     * @return A Response object containing the status and result of the operation.
     * @throws MPSException If an error occurs during the operation.
     */
    @TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
            description = "add secondary member id",
            tags = {URI, "/msapi/idgraphusermanagementms/v1/secmemberid/add", METHOD, POST},
            histogram = true)
    @Override
    public Response addSecMemberId(AddSecMemberIdRequest addSecMemberIdRequest, HttpHeaders httpHeader) throws MPSException {
        Map<String, Object> hmResponse = CommonUtil.getHashMap();
        AddSecMemberIdResponse addSecMemberIdResponse = null;
        long startTm = System.currentTimeMillis();
        Response responseObj = null;
        try {

            logger.info(SpiMarker.getInstance(),"WEB_01 : AddSecMemberId Input : {} | AddSecMemberId Request Header  : {}",
                addSecMemberIdRequest != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(addSecMemberIdRequest)) : null,
                    httpHeader.getRequestHeaders() != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(httpHeader.getRequestHeaders())) : null);

            addSecMemberIdResponse = addSecMemberIdRequestValidator.addSecMemberIdReqValidator(httpHeader, addSecMemberIdRequest);

            logger.info(SpiMarker.getInstance(),"WEB000 : AddSecMemberId Input : {}", addSecMemberIdRequest);

            if (addSecMemberIdResponse == null) {
                // call the service class
                addSecMemberIdResponse = addSecMemberIdService.addSubUser(addSecMemberIdRequest, httpHeader);
                logger.info("WEB_02 : AddSecMemberIdService Response : {}", addSecMemberIdResponse);
            }
        } catch (Exception e) {
            if (e instanceof InvalidInputDataException) {
                logger.error("InvalidInputDataException: {}", e.getMessage());
                throw e;
            }
            else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
            }
            else {
                hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
            }
            hmResponse.put("idp-trace-id", addSecMemberIdRequest.getIdpTraceId());
            addSecMemberIdResponse = CommonUtilHelper.generateAddSecMemberIdResponse(hmResponse);
        }
        responseObj = CommonUtilHelper.buildMSResponse(addSecMemberIdResponse);
        String sTimeTaken = CommonUtilHelper.getElapsedTimeInSecs(startTm) + " seconds";
        logger.info("WEB999 : Total time taken : {} AddSecMemberId Response : {}",sTimeTaken, addSecMemberIdResponse);
        return responseObj;
    }
}