package com.att.idp.idgraphusermanagementms.resource;

import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.resource.request.AddSecMemberIdRequest;
import com.att.idp.idgraphusermanagementms.resource.response.AddSecMemberIdResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.RequestBody;

import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

/**
 * Interface for adding a secondary member ID in the MPSYS system.
 * This interface defines the endpoint for adding a secondary member ID and provides the necessary annotations for Swagger documentation.
 */
@Tag(name = "secmemberid")
@Path("/secmemberid")
@Produces({ MediaType.APPLICATION_JSON })
public interface AddSecMemberIdResource {

    /**
     * Adds a secondary member ID in the MPSYS system.
     * This method handles the HTTP POST request to add a secondary member ID.
     *
     * @param addSecMemberIdRequest The request object containing the details for adding a secondary member ID.
     * @param httpHeader The HTTP headers of the request.
     * @return A Response object containing the status and result of the operation.
     * @throws MPSException If an error occurs during the operation.
     */
    @POST
    @Path("/add")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(summary = "Add secondary memberId", description =  "Add secondary memberId in the MPSYS system",parameters = {
            @Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description =  "Success",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = AddSecMemberIdResponse.class))),
            @ApiResponse(responseCode = "400", description =  "Bad Request"),
            @ApiResponse(responseCode = "500", description =  "Unknown exception in application")
    })
    Response addSecMemberId(@Valid @RequestBody AddSecMemberIdRequest addSecMemberIdRequest, @Context HttpHeaders httpHeader) throws MPSException;

}