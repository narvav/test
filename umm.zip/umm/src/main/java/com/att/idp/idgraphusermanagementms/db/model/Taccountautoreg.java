package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.*;

@Entity
@Table(name = "TACCOUNTAUTOREG", schema = "MPS_OWNER", uniqueConstraints = @UniqueConstraint(columnNames = { "SOR_ID", "SOR_INVARIANT_ID" }))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Taccountautoreg implements java.io.Serializable {

	private static final long serialVersionUID = -8302037290685173488L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "memberNum", column = @Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "sorId", column = @Column(name = "SOR_ID", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "sorInvariantId", column = @Column(name = "SOR_INVARIANT_ID", nullable = false)),
			@AttributeOverride(name = "createDate", column = @Column(name = "CREATE_DATE", nullable = false, length = 7)),
			@AttributeOverride(name = "lastModified", column = @Column(name = "LAST_MODIFIED", nullable = false, length = 7)),
			@AttributeOverride(name = "lastModifiedBy", column = @Column(name = "LAST_MODIFIED_BY", nullable = false)) })
	private TaccountautoregId id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MEMBER_NUM", nullable = false, insertable = false, updatable = false)
	private Tmember tmember;
}