package com.att.idp.idgraphusermanagementms.exceptions;

import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import jakarta.ws.rs.ext.ExceptionMapper;

import com.att.idp.idgraphusermanagementms.exceptions.MPSException;

/**
 * The MPSExceptionMapper class implements the ExceptionMapper interface for MPSException.
 * This class is used to map MPSException to a Response.
 * The toResponse method is overridden to provide a custom response for MPSException.
 */
public class MPSExceptionMapper implements ExceptionMapper<MPSException> {
	
	@Override
	public Response toResponse(MPSException ex) {
		return Response.status(Status.INTERNAL_SERVER_ERROR)
				.entity(ex.errorMessage.getErrorResponseInfo())
				.type(MediaType.APPLICATION_JSON)
				.build();
	}

}