package com.att.idp.idgraphusermanagementms.db.request;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

/**
 * This is the NetworkAccessRequest class which implements Serializable interface.
 * It represents a request for network access with properties like accessId, accessName, and accessDesc.
 * Each property has its respective getter and setter methods.
 */
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({

})
@Data
public class NetworkAccessRequest implements Serializable{

	private static final long serialVersionUID = 1905041013210369575L;

	private Long accessId;
	private String accessName;
	private String accessDesc;
}