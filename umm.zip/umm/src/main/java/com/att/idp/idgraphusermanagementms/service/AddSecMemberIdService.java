package com.att.idp.idgraphusermanagementms.service;

import com.att.idp.idgraphusermanagementms.resource.request.AddSecMemberIdRequest;
import com.att.idp.idgraphusermanagementms.resource.response.AddSecMemberIdResponse;

import jakarta.ws.rs.core.HttpHeaders;

/**
 * Service interface for adding a secondary member ID.
 * This interface defines the method for adding a sub-user in the MPSYS system.
 */
public interface AddSecMemberIdService {

    /**
     * Adds a sub-user in the MPSYS system.
     * This method handles the logic for adding a secondary member ID.
     *
     * @param addSubUserRequest The request object containing the details for adding a secondary member ID.
     * @param requestHeader The HTTP headers of the request.
     * @return An AddSecMemberIdResponse object containing the status and result of the operation.
     */
    AddSecMemberIdResponse addSubUser(AddSecMemberIdRequest addSubUserRequest, HttpHeaders requestHeader);
}