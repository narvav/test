package com.att.idp.idgraphusermanagementms.service.impl;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.RemoveEmailAliasHelper;
import com.att.idp.idgraphusermanagementms.resource.request.RemoveEmailAliasRequest;
import com.att.idp.idgraphusermanagementms.resource.response.CommonResponse;
import com.att.idp.idgraphusermanagementms.service.RemoveEmailAliasService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import jakarta.ws.rs.core.MultivaluedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;


@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class RemoveEmailAliasServiceImpl implements RemoveEmailAliasService {

	public static final Logger logger = LoggerFactory.getLogger(RemoveEmailAliasServiceImpl.class);

	private static final String CLASS_NAME = "RemoveEmailAliasServiceImpl";

	@Autowired
	private RemoveEmailAliasHelper removeEmailAliasHelper;

	/**
     * Removes an email alias for a user. Validates the input request and calls the helper to process the removal.
     * @param removeEmailAliasRequest the request object containing details for removing the email alias
     * @param requestHeader HTTP headers for the request
     * @return CommonResponse with the result of the operation or error details if the request is invalid
     */
	@Override
	public CommonResponse removeEmailAlias(RemoveEmailAliasRequest removeEmailAliasRequest, MultivaluedMap<String, String> requestHeader) {

		String sMethodName = ".removeEmailAlias.";
		CommonResponse removeEmailAliasResponse = null;
		if (removeEmailAliasRequest == null) {
			String stAppInfo = "Input request is null";
			HashMap<String, Object> hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			logger.info("{}{}.REAS_101 : {}", CLASS_NAME, sMethodName, stAppInfo);
			return CommonUtilHelper.generateCommonResponse(hmResult);
		}

		logger.info("{}{}.REAS_102 : Calling RemoveEmailAliasHelper with Input : {}", CLASS_NAME, sMethodName,
				CommonUtilHelper.sanitizeForLog(String.valueOf(removeEmailAliasRequest)));

		removeEmailAliasResponse = removeEmailAliasHelper.removeEmailAlias(removeEmailAliasRequest);

		logger.info("{}{}REAS_103 : Response from RemoveEmailAliasHelper : {}", CLASS_NAME, sMethodName, removeEmailAliasResponse);

		if (removeEmailAliasResponse == null) {
			String stAppInfo="Response from RemoveEmailAliasHelper is null";
			HashMap<String,Object> hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			logger.info("{}{}REAS_104 : {}", CLASS_NAME, sMethodName, stAppInfo);
			return CommonUtilHelper.generateCommonResponse(hmResult);
		}

		return removeEmailAliasResponse;
	}

	
}
