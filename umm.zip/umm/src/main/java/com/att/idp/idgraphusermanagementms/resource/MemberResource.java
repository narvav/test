package com.att.idp.idgraphusermanagementms.resource;

import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;

import com.att.idp.idgraphusermanagementms.resource.response.LinkMemberResponse;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.web.bind.annotation.RequestBody;

import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.resource.request.LinkMemberRequest;
import com.att.idp.idgraphusermanagementms.resource.request.UnlinkMemberIdRequest;
import com.att.idp.idgraphusermanagementms.resource.response.CommonResponse;

import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * This is an interface named MemberResource.
 * It is annotated with @Tag(name = "member") to provide metadata for Swagger.
 * It is also annotated with @Path("/member") to set the path for the entire interface.
 * The interface is also annotated with @Produces({ MediaType.APPLICATION_JSON }) to specify that the methods in this interface produce JSON responses.
 * The interface contains two methods, linkMember and unlinkMemberId, each annotated with @POST, @Path, @Consumes, @Produces, @ApiOperation, @ApiResponses, and @ApiImplicitParams.
 * These methods are designed to handle POST requests for linking and unlinking members.
 */
@Tag(name = "member")
@Path("/member")
@Produces({ MediaType.APPLICATION_JSON })
public interface MemberResource {
	
	/**
	 * This method is part of the MemberResource interface.
	 * It is responsible for linking a MemberID to an AccessId (SLID).
	 * The method is annotated with @POST to indicate that it handles HTTP POST requests.
	 * It is also annotated with @Path("/link") to set the path for this method.
	 * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
	 * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
	 * The method takes a LinkMemberRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
	 * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
	 * The method throws an MPSException if any error occurs during the operation.
	 * The method returns a Response object which encapsulates the result of the linking operation.
	 *
	 * @param request The LinkMemberRequest containing the details of the linking operation.
	 * @param httpHeader The HttpHeaders providing HTTP header information.
	 * @return Response The response of the linking operation.
	 * @throws MPSException If any error occurs during the operation.
	 */
	@POST
	@Path("/link")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Link MemberId", description =  "This operation will allow to link MemberID to AccessId(SLID)",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = LinkMemberResponse.class))),
			@ApiResponse(responseCode = "400", description =  "Bad Request"),
			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	public Response linkMember(@Valid @RequestBody LinkMemberRequest request,
			@Context HttpHeaders httpHeader) throws MPSException;	
	

	/**
	 * This method is part of the MemberResource interface.
	 * It is responsible for unlinking a MemberID from an AccessId (SLID).
	 * The method is annotated with @POST to indicate that it handles HTTP POST requests.
	 * It is also annotated with @Path("/unlink") to set the path for this method.
	 * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
	 * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
	 * The method takes an UnlinkMemberIdRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
	 * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
	 * The method throws an MPSException if any error occurs during the operation.
	 * The method returns a Response object which encapsulates the result of the unlinking operation.
	 *
	 * @param request The UnlinkMemberIdRequest containing the details of the unlinking operation.
	 * @param httpHeader The HttpHeaders providing HTTP header information.
	 * @return Response The response of the unlinking operation.
	 * @throws MPSException If any error occurs during the operation.
	 */
	@POST
	@Path("/unlink")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Unlink MemberId", description =  "This operation is used to de-link memberId and accessId(SLID)",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = CommonResponse.class))),
			@ApiResponse(responseCode = "400", description =  "Bad Request"),
			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	public Response unlinkMemberId(@Valid @RequestBody UnlinkMemberIdRequest request,
			@Context HttpHeaders httpHeader) throws MPSException;

}
