package com.att.idp.idgraphusermanagementms.resource.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

/**
 * This class represents a linked member in the system.
 * It contains fields for memberNum, memberName, domainId, domainName, sorId, sorName, accountType, parentChildInd, memberState, aggServiceStatus, mailHost, fullName, createDate, lastModified, lastModifiedBy, ban, deleteRequestDate, passwordDirty, firstName, lastName, nickName, gender, slidMemberNum, and createdBy.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Jackson's @JsonIgnore annotation to ignore specific fields during JSON serialization and deserialization.
 *
 * The class uses Lombok's @Data annotation to generate getter and setter methods for all fields.
 *
 */
@Data
public class IPLinkedMember {

	private String memberNum;
	private String memberName;
	private String domainId;
	private String domainName;
	private String sorId;
	private String sorName;
	private String accountType;
	private String parentChildInd;
	private String memberState;

	@JsonIgnore
	private String aggServiceStatus;

	private String mailHost;
	private String fullName;
	private String createDate;
	private String lastModified;
	private String lastModifiedBy;
	private String ban;

	@JsonIgnore
	private String deleteRequestDate;

	private String passwordDirty;
	private String firstName;
	private String lastName;
	private String nickName;
	private String gender;
	private String slidMemberNum;
	private String createdBy;
}