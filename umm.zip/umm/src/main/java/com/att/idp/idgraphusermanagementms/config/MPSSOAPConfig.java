package com.att.idp.idgraphusermanagementms.config;

import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;

import java.util.Base64;

@Configuration
public class MPSSOAPConfig {

	@Value("${MPS_SOAP_AUTHORIZATION}")
	private String mpsauth;

	@Value("${http.proxy.host:proxy.conexus.svc.local}")
	public String azProxyHost;

	@Value("${http.proxy.port:3128}")
	public String azProxyPort;

	@Value("${enable.http.proxy:false}")
	public boolean proxyEnabled;

	public static final Logger logger = LoggerFactory.getLogger(MPSSOAPConfig.class);

	private String username;
	private String password;

	@Bean
	public HttpComponentsMessageSender httpComponentsMessageSender() {

		/*Azure Cloud Flow for Soap-Sales Endpoints if Proxy is enabled*/
		HttpComponentsMessageSender httpComponentsMessageSender = null;
		String decodedAuth = new String(Base64.getDecoder().decode(mpsauth));
		String[] credentials = decodedAuth.split(":", 2);
		username = credentials[0];
		password = credentials[1];
		logger.info("..Processing SALES-HttpComponentsMessageSender () in MPSConfig.java with proxyEnabled : {}"
				, proxyEnabled);
		if(proxyEnabled) {
			logger.info("..Processing SALES-Config-HttpComponentsMessageSender() with proxy flow as  azProxyHost: " +
					"{} & azProxyPort: {}", azProxyHost, azProxyPort);

			CredentialsProvider provider = new BasicCredentialsProvider();
			provider.setCredentials(
					AuthScope.ANY,
					new UsernamePasswordCredentials(username, password)
			);

			/*Proxy Initialization*/
			CloseableHttpClient client = HttpClients
					.custom()
					.setProxy(new HttpHost(azProxyHost, Integer.parseInt(azProxyPort)))
					.addInterceptorFirst(new HttpComponentsMessageSender.RemoveSoapHeadersInterceptor())
					.setDefaultCredentialsProvider(provider)
					.build();
			httpComponentsMessageSender = new HttpComponentsMessageSender(client);
		} else {
			/*On-Prem Flow for Soap Endpoints*/
			logger.info("MPSConfig.idpHttpComponentsMessageSender() for onPremise flow");
			httpComponentsMessageSender = new HttpComponentsMessageSender();
		}

		httpComponentsMessageSender.setCredentials(usernamePasswordCredentials());
		return httpComponentsMessageSender;
	}

	@Bean
	public UsernamePasswordCredentials usernamePasswordCredentials() {
		return new UsernamePasswordCredentials(username, password);
	}

}
