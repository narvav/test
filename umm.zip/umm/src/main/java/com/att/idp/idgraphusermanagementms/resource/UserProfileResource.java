package com.att.idp.idgraphusermanagementms.resource;

import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import com.att.idp.idgraphusermanagementms.resource.request.*;
import com.att.idp.idgraphusermanagementms.resource.response.*;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.web.bind.annotation.RequestBody;

import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.resource.request.AddUserRequest;
import com.att.idp.idgraphusermanagementms.resource.request.ChangeUserNameRequest;
import com.att.idp.idgraphusermanagementms.resource.request.CheckAccessIdMergeEligibilityRequest;
import com.att.idp.idgraphusermanagementms.resource.request.CheckUserIdAvailabilityRequest;
import com.att.idp.idgraphusermanagementms.resource.request.UpdateUserFraudRequest;
import com.att.idp.idgraphusermanagementms.resource.response.AddUserResponse;
import com.att.idp.idgraphusermanagementms.resource.response.ChangeUserNameResponse;
import com.att.idp.idgraphusermanagementms.resource.response.CheckAccessIdMergeEligibilityResponse;
import com.att.idp.idgraphusermanagementms.resource.response.CheckUserIdAvailabilityResponse;
import com.att.idp.idgraphusermanagementms.resource.response.UpdateUserFraudResponse;

import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * This is an interface named UserProfileResource.
 * It is annotated with @Tag(name = "user") to provide metadata for Swagger.
 * It is also annotated with @Path("/user") to set the path for the entire interface.
 * The interface is also annotated with @Produces({ MediaType.APPLICATION_JSON }) to specify that the methods in this interface produce JSON responses.
 * The interface contains several methods, each annotated with @POST, @Path, @Consumes, @Produces, @ApiOperation, @ApiResponses, and @ApiImplicitParams.
 * These methods are designed to handle various POST requests related to user profile management such as adding a user, updating a user, checking user ID availability, changing user name, checking access ID merge eligibility, updating user fraud details, adding an external user, validating user credentials, updating an external user, and merging user access ID.
 */
@Tag(name = "user")
@Path("/user")
@Produces({ MediaType.APPLICATION_JSON })
public interface UserProfileResource {

	/**
	 * This method is part of the UserProfileResource interface.
	 * It is responsible for adding a new user.
	 * The method is annotated with @POST to indicate that it handles HTTP POST requests.
	 * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
	 * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
	 * The method takes an AddUserRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
	 * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
	 * The method throws an MPSException if any error occurs during the operation.
	 * The method returns a Response object which encapsulates the result of the user addition operation.
	 *
	 * @param addUserRequest The AddUserRequest containing the details of the user addition operation.
	 * @param httpHeader The HttpHeaders providing HTTP header information.
	 * @return Response The response of the user addition operation.
	 * @throws MPSException If any error occurs during the operation.
	 */
	@POST
	@Path("/add")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Add User", description =  "Add User in the MPSYS system",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = AddUserResponse.class))),
			@ApiResponse(responseCode = "400", description =  "Bad Request"),
			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	Response addUser(@Valid @RequestBody AddUserRequest addUserRequest,@Context HttpHeaders httpHeader) throws MPSException;

	/**
	 * This method is part of the UserProfileResource interface.
	 * It is responsible for updating an existing user.
	 * The method is annotated with @POST to indicate that it handles HTTP POST requests.
	 * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
	 * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
	 * The method takes an UpdateUserRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
	 * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
	 * The method throws an MPSException if any error occurs during the operation.
	 * The method returns a Response object which encapsulates the result of the user update operation.
	 *
	 * @param updateUserRequest The UpdateUserRequest containing the details of the user update operation.
	 * @param httpHeader The HttpHeaders providing HTTP header information.
	 * @return Response The response of the user update operation.
	 * @throws MPSException If any error occurs during the operation.
	 */
	@POST
	@Path("/update")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Update User", description =  "Update User in the MPSYS system",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = UpdateUserResponse.class))),
			@ApiResponse(responseCode = "400", description =  "Bad Request"),
			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })

	Response updateUser(@Valid @RequestBody UpdateUserRequest updateUserRequest, @Context HttpHeaders httpHeader) throws MPSException;

	
	/**
	 * This method is part of the UserProfileResource interface.
	 * It is responsible for checking the availability of a user ID.
	 * The method is annotated with @POST to indicate that it handles HTTP POST requests.
	 * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
	 * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
	 * The method takes a CheckUserIdAvailabilityRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
	 * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
	 * The method throws an MPSException if any error occurs during the operation.
	 * The method returns a Response object which encapsulates the result of the user ID availability check operation.
	 *
	 * @param request The CheckUserIdAvailabilityRequest containing the details of the user ID availability check operation.
	 * @param httpHeader The HttpHeaders providing HTTP header information.
	 * @return Response The response of the user ID availability check operation.
	 * @throws MPSException If any error occurs during the operation.
	 */
	@POST
	@Path("/checkUserIdAvailability")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Check User Id Availability", description =  "Check User Id Availability",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = CheckUserIdAvailabilityResponse.class))),
			@ApiResponse(responseCode = "400", description =  "Bad Request"),
			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	Response checkUserIdAvailability(@Valid @RequestBody CheckUserIdAvailabilityRequest request,@Context HttpHeaders httpHeader) throws MPSException;

	/**
	 * This method is part of the UserProfileResource interface.
	 * It is responsible for changing the username of an existing user.
	 * The method is annotated with @POST to indicate that it handles HTTP POST requests.
	 * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
	 * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
	 * The method takes a ChangeUserNameRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
	 * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
	 * The method throws an MPSException if any error occurs during the operation.
	 * The method returns a Response object which encapsulates the result of the username change operation.
	 *
	 * @param changeUserNameRequest The ChangeUserNameRequest containing the details of the username change operation.
	 * @param httpHeader The HttpHeaders providing HTTP header information.
	 * @return Response The response of the username change operation.
	 * @throws MPSException If any error occurs during the operation.
	 */
	@POST
	@Path("/change")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Change User Name", description =  "Change User Name in the MPSYS system",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = ChangeUserNameResponse.class))),
			@ApiResponse(responseCode = "400", description =  "Bad Request"),
			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	Response changeUserName(@Valid @RequestBody ChangeUserNameRequest changeUserNameRequest,@Context HttpHeaders httpHeader) throws MPSException;
	
	
	/**
	 * This method is part of the UserProfileResource interface.
	 * It is responsible for checking the eligibility of merging access IDs.
	 * The method is annotated with @POST to indicate that it handles HTTP POST requests.
	 * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
	 * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
	 * The method takes a CheckAccessIdMergeEligibilityRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
	 * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
	 * The method throws an MPSException if any error occurs during the operation.
	 * The method returns a Response object which encapsulates the result of the access ID merge eligibility check operation.
	 *
	 * @param request The CheckAccessIdMergeEligibilityRequest containing the details of the access ID merge eligibility check operation.
	 * @param httpHeader The HttpHeaders providing HTTP header information.
	 * @return Response The response of the access ID merge eligibility check operation.
	 * @throws MPSException If any error occurs during the operation.
	 */
	@POST
	@Path("/checkEligibility")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Check AccessId Merge Eligibility", description =  "Check AccessId Merge Eligibility in the MPSYS system",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = CheckAccessIdMergeEligibilityResponse.class))),
							@ApiResponse(responseCode = "400", description =  "Bad Request"),
							@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	public Response checkAccessIdMergeEligibility(@Valid @RequestBody CheckAccessIdMergeEligibilityRequest request,
												  @Context HttpHeaders httpHeader) throws MPSException;
	
	
	/**
	 * This method is part of the UserProfileResource interface.
	 * It is responsible for updating the fraud details of a user.
	 * The method is annotated with @POST to indicate that it handles HTTP POST requests.
	 * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
	 * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
	 * The method takes an UpdateUserFraudRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
	 * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
	 * The method throws an MPSException if any error occurs during the operation.
	 * The method returns a Response object which encapsulates the result of the user fraud update operation.
	 *
	 * @param request The UpdateUserFraudRequest containing the details of the user fraud update operation.
	 * @param httpHeader The HttpHeaders providing HTTP header information.
	 * @return Response The response of the user fraud update operation.
	 * @throws MPSException If any error occurs during the operation.
	 */
	@POST
	@Path("/updateFraud")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Update User Fraud", description =  "Update user fraud lock details in the MPSYS system",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = UpdateUserFraudResponse.class))),
							@ApiResponse(responseCode = "400", description =  "Bad Request"),
							@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	public Response updateUserFraud(@Valid @RequestBody UpdateUserFraudRequest request,
												  @Context HttpHeaders httpHeader) throws MPSException;
	/**
	 * This method is part of the UserProfileResource interface.
	 * It is responsible for adding an external user.
	 * The method is annotated with @POST to indicate that it handles HTTP POST requests.
	 * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
	 * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
	 * The method takes an ExtUserRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
	 * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
	 * The method throws an MPSException if any error occurs during the operation.
	 * The method returns a Response object which encapsulates the result of the external user addition operation.
	 *
	 * @param request The ExtUserRequest containing the details of the external user addition operation.
	 * @param httpHeader The HttpHeaders providing HTTP header information.
	 * @return Response The response of the external user addition operation.
	 * @throws MPSException If any error occurs during the operation.
	 */
	@POST
	@Path("/addExt")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Add Ext User", description =  "Add Ext User in the MPSYS system",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = ExtUserResponse.class))),
			@ApiResponse(responseCode = "400", description =  "Bad Request"),
			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	public Response addExtUser(@Valid @RequestBody ExtUserRequest request,
									   @Context HttpHeaders httpHeader) throws MPSException;

	/**
	 * This method is part of the UserProfileResource interface.
	 * It is responsible for validating user credentials.
	 * The method is annotated with @POST to indicate that it handles HTTP POST requests.
	 * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
	 * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
	 * The method takes a ValidateUserCredentialsRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
	 * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
	 * The method throws an MPSException if any error occurs during the operation.
	 * The method returns a Response object which encapsulates the result of the user credentials validation operation.
	 *
	 * @param request The ValidateUserCredentialsRequest containing the details of the user credentials validation operation.
	 * @param httpHeaders The HttpHeaders providing HTTP header information.
	 * @return Response The response of the user credentials validation operation.
	 * @throws MPSException If any error occurs during the operation.
	 */
	@POST
	@Path("/credentials/validate")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Validate User Credentials", description =  "Validate User Credentials in the MPSYS system",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = ValidateUserCredentialsResponse.class))),
			@ApiResponse(responseCode = "400", description =  "Bad Request"),
			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	public Response validateUserCredentials(@Valid @RequestBody ValidateUserCredentialsRequest request, @Context HttpHeaders httpHeaders) throws MPSException;

	
	/**
	 * This method is part of the UserProfileResource interface.
	 * It is responsible for updating an external user.
	 * The method is annotated with @POST to indicate that it handles HTTP POST requests.
	 * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
	 * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
	 * The method takes an ExtUserRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
	 * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
	 * The method throws an MPSException if any error occurs during the operation.
	 * The method returns a Response object which encapsulates the result of the external user update operation.
	 *
	 * @param request The ExtUserRequest containing the details of the external user update operation.
	 * @param httpHeader The HttpHeaders providing HTTP header information.
	 * @return Response The response of the external user update operation.
	 * @throws MPSException If any error occurs during the operation.
	 */
	@POST
	@Path("/updateExt")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Update Ext User", description =  "Update Ext User in the MPSYS system",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = ExtUserResponse.class))),
			@ApiResponse(responseCode = "400", description =  "Bad Request"),
			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	public Response updateExtUser(@Valid @RequestBody ExtUserRequest request,
									   @Context HttpHeaders httpHeader) throws MPSException;
	
	
	/**
	 * This method is part of the UserProfileResource interface.
	 * It is responsible for merging user access IDs.
	 * The method is annotated with @POST to indicate that it handles HTTP POST requests.
	 * The method is annotated with @Consumes(MediaType.APPLICATION_JSON) to specify that it consumes JSON requests.
	 * It is also annotated with @Produces(MediaType.APPLICATION_JSON) to specify that it produces JSON responses.
	 * The method takes a MergeUserAccessIdRequest object as a parameter, which is validated with @Valid and bound to the body of the HTTP request with @RequestBody.
	 * The method also takes HttpHeaders as a parameter, which provides HTTP header information.
	 * The method throws an MPSException if any error occurs during the operation.
	 * The method returns a Response object which encapsulates the result of the user access ID merge operation.
	 *
	 * @param mergeUserAccessIdRequest The MergeUserAccessIdRequest containing the details of the user access ID merge operation.
	 * @param httpHeader The HttpHeaders providing HTTP header information.
	 * @return Response The response of the user access ID merge operation.
	 * @throws MPSException If any error occurs during the operation.
	 */
	@POST
	@Path("/merge")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Merge AccessId", description =  "Merge one accessId into another in the MPSYS system",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = MergeUserAccessIdResponse.class))),
			@ApiResponse(responseCode = "400", description =  "Bad Request"),
			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	Response mergeUserAccessId(@Valid @RequestBody MergeUserAccessIdRequest mergeUserAccessIdRequest,@Context HttpHeaders httpHeader) throws MPSException;

}