package com.att.idp.idgraphusermanagementms.appconfig.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

@Configuration
@RefreshScope
@Getter
@Setter
public class IDGraphAzureAppConfig {

    @Value("${appconfig.version:0.0.0}")
    private String version;

    @Value("${appconfig.tomcat.jdbc.pool.max_size:${tomcat.jdbc.pool.max_size:100}}")
    private int maxSize;

    @Value("${appconfig.tomcat.jdbc.pool.min_size:${tomcat.jdbc.pool.min_size:5}}")
    private int minSize;

    @Value("${appconfig.tomcat.jdbc.pool.initial-size:${tomcat.jdbc.pool.initial-size:5}}")
    private int initialSize;

    @Value("${appconfig.tomcat.jdbc.pool.test-on-borrow:${tomcat.jdbc.pool.test-on-borrow:true}}")
    private boolean testOnBorrow;

    @Value("${appconfig.tomcat.jdbc.pool.test-while-idle:${tomcat.jdbc.pool.test-while-idle:true}}")
    private boolean testWhileIdle;

    @Value("${appconfig.tomcat.jdbc.pool.validation-query:${tomcat.jdbc.pool.validation-query:SELECT 1 FROM DUAL}}")
    private String validationQuery;

    @Value("${appconfig.tomcat.jdbc.pool.query-timeout:${tomcat.jdbc.pool.query-timeout:60}}")
    private int queryTimeout;

    @Value("${appconfig.tomcat.jdbc.pool.max-wait:${tomcat.jdbc.pool.max-wait:30000}}")
    private int connTimeout;

    @Value("${appconfig.tomcat.jdbc.pool.evictTime:${tomcat.jdbc.pool.evictTime:5000}}")
    private int evictTime;

    @Value("${appconfig.tomcat.datasource.refreshEnabled:${tomcat.datasource.refreshEnabled:false}}")
    private boolean dataSourceRefreshEnabled;

    @Value("${appconfig.logging.level.root:${logging.level.root:INFO}}")
    private String logLevelRoot;

    @Value("${appconfig.logging.level.com.att.idp:${logging.level.com.att.idp:DEBUG}}")
    private String logLevelIdp;

    @Value("${appconfig.logging.level.com.att.idp.logging:${logging.level.com.att.idp.logging:DEBUG}}")
    private String logLevelIdpApi;

}
