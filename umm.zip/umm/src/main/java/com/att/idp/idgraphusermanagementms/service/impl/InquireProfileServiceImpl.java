package com.att.idp.idgraphusermanagementms.service.impl;

import java.util.Map;
import java.util.Objects;

import jakarta.ws.rs.core.MultivaluedMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.InquireProfileHelper;
import com.att.idp.idgraphusermanagementms.resource.request.InquireProfileRequest;
import com.att.idp.idgraphusermanagementms.resource.response.InquireProfileResponse;
import com.att.idp.idgraphusermanagementms.service.InquireProfileService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.InquireProfileUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This class implements the InquireProfileService interface and provides the implementation for inquiring a user's profile in the system.
 * It is annotated with @Service to indicate that it's a Spring Bean and @Transactional to handle the transaction management.
 *
 * It contains a method inquireProfile which takes an InquireProfileRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return an InquireProfileResponse object.
 *
 * The InquireProfileRequest object encapsulates the details of the user profile inquiry operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
@Service
@Transactional(readOnly = true, value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class InquireProfileServiceImpl implements InquireProfileService {
	public static final Logger logger = LoggerFactory.getLogger(InquireProfileServiceImpl.class);

	@Autowired
	private InquireProfileHelper inquireProfileHelper;

	private static String sClassName = "InquireProfileServiceImpl";

	@Override
	public InquireProfileResponse inquireProfile(InquireProfileRequest inquireProfileRequest,
			MultivaluedMap<String, String> requestHeader) {

		InquireProfileResponse inquireProfileResponse = null;

		Map<String, Object> hmInput = null;
		Map<String, Object> hmResponse = null;
		String sMethodName = ".inquireProfile.";

		// Calling InquireProfile HashMap
		hmInput = CommonUtilHelper.objectToMap(inquireProfileRequest);
		
		hmInput.put("handle", hmInput.remove("userId"));
		
		if (Objects.nonNull(inquireProfileRequest.getQUERY_USER_MERGE())) {
			String flag = (String)hmInput.remove("query_USER_MERGE");
			hmInput.put("QUERY_USER_MERGE", flag);
		}

		logger.info("{}{}IPS_01 : Calling inquireProfileHelper with Input : {}", sClassName, sMethodName, hmInput);

		hmResponse = inquireProfileHelper.inquireProfile(hmInput);

		logger.info(SpiMarker.getInstance(),
				"InquireProfileHelper.inquireProfile.IPS_02 : Response from inquireProfileHelper : ",
				hmResponse);

		if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
			hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from inquireProfileHelper.inquireProfile");
			logger.info("{}{}IPS_03 : Null response from inquireProfileHelper.inquireProfile", sClassName, sMethodName);
		} else {
			String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (stAppStatusCode == null) {
				hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from inquireProfileHelper.inquireProfile");
				logger.info("{}{}IPS_04 : Null response from inquireProfileHelper.inquireProfile", sClassName,
						sMethodName);
			}
		}

		hmResponse.put(CommonDefs.TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
		hmResponse.put("idp-trace-id", inquireProfileRequest.getIdpTraceId());
		inquireProfileResponse = InquireProfileUtilHelper.generateInquireProfileResponse(hmResponse);
		
		logger.info(SpiMarker.getInstance(),
				"InquireProfileHelper.inquireProfile.IPS_05 : Response from InquireProfileServiceImpl.inquireProfile : {}",
				inquireProfileResponse);

		return inquireProfileResponse;
	}
}
