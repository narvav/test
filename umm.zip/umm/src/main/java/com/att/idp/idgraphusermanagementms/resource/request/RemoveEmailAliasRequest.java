package com.att.idp.idgraphusermanagementms.resource.request;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Schema(name = "removeEmailAliasRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class RemoveEmailAliasRequest extends BaseUserRequest{
	
	private String callingSystemId;

	private String transactionName = "RemoveEmailAlias";
	
	@Schema(name = "memberId")
	@NotNull(message="memberId is required in input request.|RemoveEmailAlias")
	@Size(min=1, max=127,message="userId length is invalid|RemoveEmailAlias")
	private String memberId;

	@Schema(name = "domain")
	@NotNull(message = "domain is required field in input request.|RemoveEmailAlias")
	@Size(min = 1, max = 30, message =  "domain length is invalid|RemoveEmailAlias")
	private  String domain;

	@Schema(name = "agentId")
	@Size(min=1, max=20,message="agentId length is invalid|RemoveEmailAlias")
	private String agentId;

	@Schema(name = "transactionType")
	@Size(min=1, max=20,message="transactionType length is invalid|RemoveEmailAlias")
	private String transactionType;

	@Schema(name = "emailAliases")
	@NotNull(message = "emailAliases is required and cannot be null|RemoveEmailAlias")
	@Size(min = 1, message = "emailAliases must contain at least 1 set of emailAliasId and emailAliasDomain|RemoveEmailAlias")
	private List<@Valid EmailAliases> emailAliases;
	
	@Schema(name = "isExternalCall")
	protected String isExternalCall;

	@Schema(name = "idpTraceId")
	private String idpTraceId;
	
	/**
	 * This field is part of the RemoveEmailAliasRequest class.
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
     */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();

}
