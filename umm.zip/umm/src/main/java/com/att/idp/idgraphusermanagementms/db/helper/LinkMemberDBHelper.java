package com.att.idp.idgraphusermanagementms.db.helper;

import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.MPSDefs;
import static com.att.mpsys.common.utils.CommonErrorMap.makeCategoryMap;
import static org.springframework.web.util.HtmlUtils.htmlEscape;

@Component
public class LinkMemberDBHelper {

    public static final Logger logger = LoggerFactory.getLogger(LinkMemberDBHelper.class);
    private static final String sClassName = "LinkMemberDBHelper";

    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private GetMemberServicesDBHelper oGetMemberServicesDBHelper;
    @Autowired
    private ErrorMetricHandler errorMetricHandler;

    public HashMap<String, Object> getMemberParentServices(HashMap hmDbInput) {

        String sMethodName = ".getMemberParentServices";
        HashMap<String, Object> hmResult = null;
        String sAppInfo = null;
        String sAppStatusCode = null;
        HashMap<String, Object> memberData = null;
        String parentChildInd = null;
        HashMap<String,Object> parentData = null;
        HashMap<String, Object> thash = null;

        if (hmDbInput == null || hmDbInput.isEmpty()) {
            sAppInfo = "hmDbInput is NULL";
            hmResult = makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
            logger.info("{}{}LMDH.GMPS.1 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(sAppInfo));
            return hmResult;
        }

        try {
            String wsUserId = (String) hmDbInput.get(CommonDefs.MEMBERID);
            String sDomain = (String) hmDbInput.get(CommonDefs.DOMAIN);
            String sMemberNum = (String) hmDbInput.get(CommonDefs.MEMBER_NUM);

            //updated to query by member_name and member_num
            HashMap<String,Object>  hmMemberData= new HashMap<>();
            boolean bMemberNameExist = false;
            boolean bDomainNameExist = false;
            boolean bMemberNumExist = false;

            if ((wsUserId != null) && (!wsUserId.trim().isEmpty())) {
                bMemberNameExist = true;
                wsUserId = wsUserId.trim().toLowerCase();
            }

            if ((sDomain != null) && (!sDomain.trim().isEmpty())) {
                bDomainNameExist = true;
                sDomain = sDomain.trim().toLowerCase();
            }

            if ((sMemberNum != null) && (!sMemberNum.trim().isEmpty()))
                bMemberNumExist = true;

            if (bMemberNumExist) {
                hmMemberData.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);
            } else if (bMemberNameExist && bDomainNameExist) {
                hmMemberData.put(MPSDefs.DB_MEMBER_NAME, wsUserId);
                hmMemberData.put(MPSDefs.DB_DOMAIN_NAME, sDomain);
            } else {
                sAppInfo = "UserId/Domain/MemberNum is missing";
                logger.info("{}{} LMDH.GMPS.2 : {}", sClassName, sMethodName,
                        sAppInfo);
                hmResult = makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
                return hmResult;
            }

            if (hmDbInput.containsKey(MPSDefs.WS_SECURITY_ALL_REQ)) {
                hmMemberData.put(MPSDefs.SECURITY_ALL_REQ, hmDbInput.get(MPSDefs.WS_SECURITY_ALL_REQ));
            } else {
                if (hmDbInput.containsKey(MPSDefs.WS_BIRTHDATE_REQ)) {
                    hmMemberData.put(MPSDefs.BIRTHDATE_REQ, hmDbInput.get(MPSDefs.WS_BIRTHDATE_REQ));
                }
                if (hmDbInput.containsKey(MPSDefs.WS_LAST_FOUR_SSN_REQ)) {
                    hmMemberData.put(MPSDefs.LAST_FOUR_SSN_REQ, hmDbInput.get(MPSDefs.WS_LAST_FOUR_SSN_REQ));
                }
                if (hmDbInput.containsKey(MPSDefs.WS_SECURITY_QUESTION_REQ)) {
                    hmMemberData.put(MPSDefs.SECURITY_QUESTION_REQ, hmDbInput.get(MPSDefs.WS_SECURITY_QUESTION_REQ));
                }
                if (hmDbInput.containsKey(MPSDefs.WS_SECURITY_ANSWER_REQ)) {
                    hmMemberData.put(MPSDefs.SECURITY_ANSWER_REQ, hmDbInput.get(MPSDefs.WS_SECURITY_ANSWER_REQ));
                }
            }

            if (hmDbInput.containsKey(MPSDefs.WS_PORTAL_PROVIDER_UPDATE_DATE)) {
                hmMemberData.put(MPSDefs.WS_PORTAL_PROVIDER_UPDATE_DATE,
                        hmDbInput.get(MPSDefs.WS_PORTAL_PROVIDER_UPDATE_DATE));
            }
            if (hmDbInput.containsKey(MPSDefs.DB_QUERY_MEMBERLOCKOUT_FLAG)) {
                hmMemberData.put(MPSDefs.DB_QUERY_MEMBERLOCKOUT_FLAG,
                        hmDbInput.get(MPSDefs.DB_QUERY_MEMBERLOCKOUT_FLAG));
            }
            if (hmDbInput.containsKey(MPSDefs.QUERY_SLID_INFO_FLAG))
                hmMemberData.put(MPSDefs.QUERY_SLID_INFO_FLAG,
                        hmDbInput.get(MPSDefs.QUERY_SLID_INFO_FLAG));

            if (hmDbInput.containsKey(MPSDefs.SLID_MASK))
                hmMemberData.put(MPSDefs.SLID_MASK,
                        hmDbInput.get(MPSDefs.SLID_MASK));
            //Added for FEB 2011 SSO Phase2 by vs3652
            if (hmDbInput.containsKey(MPSDefs.MAKE_MODEL_REQ))
                hmMemberData.put(MPSDefs.MAKE_MODEL_REQ,
                        hmDbInput.get(MPSDefs.MAKE_MODEL_REQ));
            // 1510 - Updated for PID266956b CTN Alias for Fraud - to query USERFRAUDLOCK and ACCOUNTFRAUDLOCK tables
            if (hmDbInput.containsKey(MPSDefs.QUERY_FRAUD_LOCK_FLAG)) {
                hmMemberData.put(MPSDefs.QUERY_FRAUD_LOCK_FLAG, hmDbInput.get(MPSDefs.QUERY_FRAUD_LOCK_FLAG));
            }

            //1808 - Updated for PID304635 SecMod UAM-7340 Update password rules - to query MEMBERFRAUDPASSWORD table
            if (hmDbInput.containsKey(MPSDefs.QUERY_MEMBER_FRAUD_PASSWORD_FLAG)) {
                hmMemberData.put(MPSDefs.QUERY_MEMBER_FRAUD_PASSWORD_FLAG, hmDbInput.get(MPSDefs.QUERY_MEMBER_FRAUD_PASSWORD_FLAG));
            }
            // PID-310691d [R2006]-[MPSYS-US4] - Updated to pass the QMSA flag to get MEMBERSERVICEATTRIBUTE
            if (hmDbInput.containsKey(MPSDefs.QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG)) {
                hmMemberData.put(MPSDefs.QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG, hmDbInput.get(MPSDefs.QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG));
            }


            memberData = oGetMemberServicesDBHelper.getMemberServices(hmMemberData);

            logger.info("{}{} LMDH.GMPS.3 :Response from getMemberServices  : {}", sClassName, sMethodName,
                    htmlEscape(String.valueOf(memberData)));

            if (memberData == null || memberData.isEmpty()) {
                sAppInfo = "Response from  getMemberServices is either null or empty";
                logger.info("{}{} LMDH.GMPS.4 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(sAppInfo));
                hmResult = makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
                return hmResult;
            }
            sAppStatusCode = (String) memberData.get(CommonDefs.COMMON_APP_STATUS_CODE);

            if (!(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode))) {
                sAppInfo = (String) memberData.get(CommonDefs.COMMON_APP_INFO);

                if (sAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
                    sAppInfo = "User not found";
                }
                logger.info("{}{} LMDH.GMPS.5 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(sAppInfo));
                hmResult = makeCategoryMap(Integer.parseInt(sAppStatusCode), sAppInfo);
                return hmResult;
            }

            parentChildInd = (String) memberData.get(MPSDefs.DB_PARENT_CHILD_IND);
            String parentName = (String) memberData.get(MPSDefs.DB_PARENT_NAME);
            String domainName = (String) memberData.get(MPSDefs.DB_PARENT_DOMAIN);

            hmResult = new HashMap<>();

            if (parentChildInd.equalsIgnoreCase(MPSDefs.MPS_PARENT) ||
                    parentChildInd.equalsIgnoreCase(MPSDefs.MPS_SLID) ||
                    parentChildInd.equalsIgnoreCase(MPSDefs.MPS_FOREIGN_ID)) {
                //Add 'Parent' as key and memHash as value
                memberData.remove(MPSDefs.APP_STATUS_CODE); //need to uncomment
                memberData.remove(MPSDefs.APP_STATUS_MSG); //need to uncomment
                //Add 'Parent' as key and memberData as value
                hmResult.put(MPSDefs.MEM_PARENT_INFO_PARENT_KEY, memberData);
                hmResult.put(CErrorDefs.COMMON_APP_CATEGORY_CODE, CErrorDefs.COMMON_SUCCESS);
                thash = CommonErrorMap.makeCommonStatusMap(CErrorDefs.COMMON_SUCCESS_NUM);
                hmResult.putAll(thash);
            }

            if (parentChildInd.equalsIgnoreCase(MPSDefs.MPS_CHILD)) {
               // memberData.remove(MPSDefs.APP_STATUS_CODE);
                //memberData.remove(MPSDefs.APP_STATUS_MSG);
                //Add 'Member' as key and memHash as value
                hmResult.put(MPSDefs.MEM_PARENT_INFO_MEMBER_KEY, memberData);
                HashMap<String, Object> hmParent = new HashMap<>();
                hmParent.put(MPSDefs.DB_MEMBER_NAME, parentName);
                hmParent.put(MPSDefs.DB_DOMAIN_NAME, domainName);

                if (hmDbInput.containsKey(MPSDefs.WS_SECURITY_ALL_REQ)) {
                    hmParent.put(MPSDefs.SECURITY_ALL_REQ, hmDbInput.get(MPSDefs.WS_SECURITY_ALL_REQ));
                } else {
                    if (hmDbInput.containsKey(MPSDefs.WS_BIRTHDATE_REQ)) {
                        hmParent.put(MPSDefs.BIRTHDATE_REQ, hmDbInput.get(MPSDefs.WS_BIRTHDATE_REQ));
                    }
                    if (hmDbInput.containsKey(MPSDefs.WS_LAST_FOUR_SSN_REQ)) {
                        hmParent.put(MPSDefs.LAST_FOUR_SSN_REQ, hmDbInput.get(MPSDefs.WS_LAST_FOUR_SSN_REQ));
                    }
                    if (hmDbInput.containsKey(MPSDefs.WS_SECURITY_QUESTION_REQ)) {
                        hmParent.put(MPSDefs.SECURITY_QUESTION_REQ, hmDbInput.get(MPSDefs.WS_SECURITY_QUESTION_REQ));
                    }
                    if (hmDbInput.containsKey(MPSDefs.WS_SECURITY_ANSWER_REQ)) {
                        hmParent.put(MPSDefs.SECURITY_ANSWER_REQ, hmDbInput.get(MPSDefs.WS_SECURITY_ANSWER_REQ));
                    }
                }
                if (hmDbInput.containsKey(MPSDefs.WS_PORTAL_PROVIDER_UPDATE_DATE)) {
                    hmParent.put(MPSDefs.WS_PORTAL_PROVIDER_UPDATE_DATE, hmDbInput.get(MPSDefs.WS_PORTAL_PROVIDER_UPDATE_DATE));
                }
                //Added for June 2010 S&B by vs3652
                if (hmDbInput.containsKey(MPSDefs.DB_QUERY_MEMBERLOCKOUT_FLAG))
                    hmParent.put(MPSDefs.DB_QUERY_MEMBERLOCKOUT_FLAG,
                            hmDbInput.get(MPSDefs.DB_QUERY_MEMBERLOCKOUT_FLAG));
                parentData = oGetMemberServicesDBHelper.getMemberServices(hmParent);

                if (parentData == null || parentData.isEmpty()) {
                    sAppInfo = "Response from  getMemberServices is either null or empty";
                    logger.info("{}{}LMDH.GMPS.6 : {}", sClassName, sMethodName, sAppInfo);
                    hmResult = makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
                    return hmResult;
                }
                sAppStatusCode = (String) parentData.get(CommonDefs.COMMON_APP_STATUS_CODE);

                if (!(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode))) {
                    sAppInfo = (String) parentData.get(CommonDefs.COMMON_APP_INFO);

                    if (sAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
                        sAppInfo = "User not found";
                    }
                    logger.info("{}{}LMDH.GMPS.7 : {}", sClassName, sMethodName, sAppInfo);
                    hmResult = makeCategoryMap(Integer.parseInt(sAppStatusCode), sAppInfo);
                    return hmResult;
                } else {
                    parentData.remove(MPSDefs.APP_STATUS_CODE);
                    parentData.remove(MPSDefs.APP_STATUS_MSG);
                    //Add 'Parent' as Key and ParentHash value
                    hmResult.put(MPSDefs.MEM_PARENT_INFO_PARENT_KEY, parentData);
                    hmResult.put(CErrorDefs.COMMON_APP_CATEGORY_CODE, CErrorDefs.COMMON_SUCCESS);
                    thash = CommonErrorMap.makeCommonStatusMap(CErrorDefs.COMMON_SUCCESS_NUM);
                    hmResult.putAll(thash);
                }

            }
        } catch (Exception e) {
            errorMetricHandler.recordDbErrorMetric();
            hmResult = CommonErrorMap.makeExceptionMap(e, logger);
            sAppInfo = "Exception thrown from queryMemberInfo method : " + hmResult;
            logger.error("{}{} LMDH.GMPS.8: {}", sClassName, sMethodName, HtmlUtils.htmlEscape(sAppInfo));
            return hmResult;
        }
        return hmResult;
    }
}
