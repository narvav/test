package com.att.idp.idgraphusermanagementms.helper.resetuserpassword;

import com.att.idp.idgraphusermanagementms.db.helper.GetMemberServicesDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.MemberFraudPasswordDBHelper;
import com.att.idp.idgraphusermanagementms.queue.message.helpers.PasswordQueueHelper;
import com.att.idp.idgraphusermanagementms.utils.RILCheckAndEncryptPasswordHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.helpers.ConvertServicesHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * This class is named ResetUserPasswordHelper and it is part of the package
 * com.att.idp.idgraphusermanagementms.helper.resetuserpassword. It is used to
 * manage and reset user passwords. It contains several private fields that
 * store configuration values and instances of other helper classes for managing
 * user passwords, lockouts, and sending JMS messages. It provides a public
 * method named resetUserPassword which takes a HashMap as input containing the
 * input parameters for the password reset process. This method logs the start
 * of the process and the input parameters, validates the input parameters,
 * generates a temporary password, checks for various conditions such as user
 * lockouts and fraud locks, updates the user password in the database, sends a
 * JMS message for the password reset event, and returns a HashMap containing
 * the result of the password reset process. It also provides several private
 * methods for building notification hashes, processing failed authentication
 * attempts, validating online QA establishment dates, and updating member fraud
 * passwords.
 */
@Component
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class ResetUserPasswordHelper {

	@Autowired
	private GetMemberServicesDBHelper getMemberServicesDBHelper;

	@Autowired
	private ConvertServicesHelper oConvertServicesHelper;

	@Autowired
	private LockoutHelper oLockoutHelper;

	@Autowired
	private UserPasswordHelper oUserPasswordHelper;

	@Autowired
	private RILCheckAndEncryptPasswordHelper oRILCheckAndEncryptPasswordHelper;

	@Autowired
	private MemberFraudPasswordDBHelper memberFraudPasswordDBHelper;

	@Autowired
	private EmailAppPasswordHelper emailAppPasswordHelper;

	@Autowired
	private PasswordQueueHelper passwordQueueHelper;

	@Value("${RUP_RETURN_PWD_CALLER}")
	private String stReturnPwdCallers;

	@Value("${EDDDeliveryMethods}")
	private String stDeliveryMethods;

	@Value("${PROP_RESET_USER_PASSWORD_agentToolList}")
	private String stAgentToolList;

	@Value("${ChangePassword_Service_To_NotificationField}")
	private String stSrvNotificationField;

	@Value("${Security_QA_Aging_Days}")
	private String sPropSecurityQAAgingDays;

	private static String sClassName = "ResetUserPasswordHelper";
	private static final String info = "$Id: master/com/att/mpsys/common/helpers/ResetUserPasswordHelper.java v1 2022-05-19 mc288e $;";
	private static final Logger log = LoggerFactory.getLogger(ResetUserPasswordHelper.class);

	/**
	 * This method is used to reset the user password. It takes a HashMap as input
	 * which contains various parameters required for the password reset process.
	 * The method logs the start of the process and the input parameters, validates
	 * the input parameters, generates a temporary password, checks for various
	 * conditions such as user lockouts and fraud locks, updates the user password
	 * in the database, sends a JMS message for the password reset event, and
	 * returns a HashMap containing the result of the password reset process. It
	 * also handles various error scenarios and returns appropriate error messages.
	 *
	 * @param hmInput HashMap containing the input parameters for the password reset
	 *                process.
	 * @return HashMap containing the result of the password reset process.
	 */
	@SuppressWarnings("unchecked")
	@org.springframework.transaction.annotation.Transactional
	public HashMap resetUserPassword(HashMap hmInput) {
		String sMethodName = ".resetUserPassword.";
		log.info("{}{}HLP01 : CVS KEYWORDS: {}", sClassName, sMethodName, info);
		boolean isTransactionRollbackOnError = false;
        HashMap<String, Object> hmResult = null;
		String stAppInfo = null;
		String stAppStatusCode = null;
		String sAssociatedSlid = null;
		boolean isSuppressEDD = false;
		ArrayList alActiveLocks = null;
		ArrayList alExpiredLocks = null;
		ArrayList alNonExpiredNonActiveLocks = null;
        //ArrayList alDbusInput = new ArrayList();
        ArrayList<Map<String, Object>> alDbusEvents = new ArrayList<>();

		log.info(sClassName + sMethodName + "HLP000 : Input Hash : "
				+ (hmInput != null ? StringUtils.normalizeSpace(hmInput.toString()) : "null"));

		try {
			String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
			String origTransactionName = (String) hmInput.get(CommonDefs.ORIG_TRANSACTION_NAME);
			String sTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sHandle = (String) hmInput.get(CommonDefs.HANDLE);
			String sDomain = (String) hmInput.get(CommonDefs.DOMAIN);
			String sAgentId = (String) hmInput.get(CommonDefs.AGENT_ID);
			String sSourceIPAddress = (String) hmInput.get(CommonDefs.SOURCE_IP_ADDRESS);
			String sIsExternalCall = (String) hmInput.get("isExternalCall");
			HashMap hmDeliveryMethod = (HashMap) hmInput.get(CommonDefs.DELIVERY_METHOD);
			String sSuppressNotification = (String) hmInput.get(CommonDefs.SUPPRESS_NOTIFICATION);
			String sClearOnlineQA = (String) hmInput.get(CommonDefs.CLEAR_ONLINE_QA);

			if (CommonDefs.IND_Y.equals(sSuppressNotification)) {
				isSuppressEDD = true;
			}

			String sGeneratedPassword = oRILCheckAndEncryptPasswordHelper.generateTempPasswordDigitsOnly();
			hmInput.put(CommonDefs.CLEAR_PASSWORD, sGeneratedPassword);
			hmInput.put("newPassword", sGeneratedPassword);
			hmInput.put("tempGenerated", CommonDefs.IND_Y);

			hmInput.put(CommonDefs.PASSWORD_DIRTY, CommonDefs.DEFAULT_YES);

			HashMap hmUserHelperInput = new HashMap();
			hmUserHelperInput.putAll(hmInput);
            hmUserHelperInput.put(CommonDefs.TRANSACTION_NAME,  CommonDefs.TRANS_NAME_RESET_PWD);//"ResetMemberPassword");
			hmUserHelperInput.put(CommonDefs.TRANSACTION_ID, hmInput.get("dbusTransactionId"));

			// removed legacyDTVid flow - check CDP for reference

			String sLockoutName = "";

			sLockoutName = CommonDefs.FORGOT_PASSWORD_PREQUAL;

			hmInput.put(MPSDefs.DB_LOCKOUT_NAME, sLockoutName);

			ArrayList alSildMaskInp = new ArrayList();
			alSildMaskInp.add("LU");
			alSildMaskInp.add("LS");
			alSildMaskInp.add("SQ");
			if (hmInput.get(CommonDefs.USER_LOCK_LEVEL) != null
					&& !((String) hmInput.get(CommonDefs.USER_LOCK_LEVEL)).isEmpty()) {
				alSildMaskInp.add("LAEP");
			}

			HashMap hmGetInfoInp = new HashMap();
			hmGetInfoInp.put(MPSDefs.DB_MEMBER_NAME, sHandle);
			hmGetInfoInp.put(MPSDefs.DB_DOMAIN_NAME, sDomain);
			hmGetInfoInp.put(MPSDefs.SECURITY_ALL_REQ, CommonDefs.DEFAULT_YES);
			hmGetInfoInp.put(MPSDefs.DB_QUERY_MEMBERLOCKOUT_FLAG, CommonDefs.DEFAULT_YES);
			hmGetInfoInp.put(MPSDefs.QUERY_SLID_INFO_FLAG, CommonDefs.DEFAULT_YES);
			hmGetInfoInp.put(MPSDefs.QUERY_LINKED_USERS_FLAG, CommonDefs.DEFAULT_YES);
			//we do not need below for UpdateUserFraud flow , we are using the data only in UpdateUserPassword flow to chk if the pwd passed in input is same as one of the existing pwds
			//hmGetInfoInp.put("queryMemberFraudPassword", MPSDefs.YES);
			hmGetInfoInp.put(MPSDefs.QUERY_FRAUD_LOCK_FLAG, CommonDefs.DEFAULT_YES);
			hmGetInfoInp.put(CommonDefs.SLID_MASK, alSildMaskInp);
			hmGetInfoInp.put("queryDIAL", CommonDefs.DEFAULT_NO);
			hmGetInfoInp.put("queryDSL", CommonDefs.DEFAULT_NO);
			hmGetInfoInp.put("queryWIFI", CommonDefs.DEFAULT_NO);
			hmGetInfoInp.put("queryISDN", CommonDefs.DEFAULT_NO);
			//we are not validating memberfraudpassword in UUF or RUP flow, hence commenting below line
			//hmInput.put("checkFraudPassword", "Y");

			// PID-310691e [2006][MPSYS-US3] - Adding QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG as
			// Y for prepaid MOBILITY account support.
			// change by pm675e
			if (!CommonDefs.CALLING_SYSTEM_ERICSSON.equals(sCallingSystemId)) {
				hmGetInfoInp.put(MPSDefs.QUERY_MEMBER_SERVICE_ATTRIBUTE_FLAG, CommonDefs.DEFAULT_YES);
			}
			// END

			log.debug(sClassName + sMethodName
					+ "RUP_02a : Calling MPSDB_GetMemberServices_H.getMemberServices with Hash : " + hmGetInfoInp);

			HashMap hmDBMemberInfo = getMemberServicesDBHelper.getMemberServices(hmGetInfoInp);

			log.debug(sClassName + sMethodName
					+ "RUP_02b : Response Hash from MPSDB_GetMemberServices_H.getMemberServices : " + hmDBMemberInfo);

			if (hmDBMemberInfo == null || hmDBMemberInfo.isEmpty()) {

				stAppInfo = "MPSDB_GetMemberServices_H returned null/empty response";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				log.info(sClassName + sMethodName + "RUP_3.1 : " + stAppInfo);
				return hmResult;

			}

			stAppStatusCode = (String) hmDBMemberInfo.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				if (stAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
					stAppInfo = "User Not Found in DB";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
					log.info(sClassName + sMethodName + "RUP_3.1.1 : " + stAppInfo);
				} else {
					hmResult = hmDBMemberInfo;
				}
				return hmResult;
			}

			sHandle = (String) hmDBMemberInfo.get(MPSDefs.DB_MEMBER_NAME);
			sDomain = (String) hmDBMemberInfo.get(MPSDefs.DB_DOMAIN_NAME);
			String sSlidMemberNum = (String) hmDBMemberInfo.get(MPSDefs.DB_SLID_MEMBER_NUM);
			String sMemberNum = (String) hmDBMemberInfo.get(MPSDefs.DB_MEMBER_NUM);
			String sActivatedInd = (String) hmDBMemberInfo.get(MPSDefs.DB_ACTIVATED_IND);
			String sSlid = (String) hmDBMemberInfo.get(MPSDefs.DB_MEMBER_NAME);

			String sContactEmailStatus = (String) hmDBMemberInfo.get(MPSDefs.DB_CONTACT_EMAIL_STATUS);
			sContactEmailStatus = (sContactEmailStatus == null) ? "" : sContactEmailStatus;

			String sDBParentChildInd = (String) hmDBMemberInfo.get(MPSDefs.DB_PARENT_CHILD_IND);
			String sDBParentHandle = (String) hmDBMemberInfo.get(MPSDefs.DB_PARENT_NAME);
			String sDBParentDomain = (String) hmDBMemberInfo.get(MPSDefs.DB_PARENT_DOMAIN);

			HashMap hmDBParentInfo = null;
			if (sDBParentChildInd != null && sDBParentChildInd.equals(MPSDefs.MPS_CHILD)) {
				HashMap hmParentGetInfoInp = new HashMap();
				hmParentGetInfoInp.put(MPSDefs.DB_MEMBER_NAME, sDBParentHandle);
				hmParentGetInfoInp.put(MPSDefs.DB_DOMAIN_NAME, sDBParentDomain);

				log.debug(sClassName + sMethodName
						+ "RUP_3.1.2 : Calling MPSDB_GetMemberServices_H.getMemberServices for parent with Hash : "
						+ hmParentGetInfoInp);

				hmDBParentInfo = getMemberServicesDBHelper.getMemberServices(hmParentGetInfoInp);

				log.debug(sClassName + sMethodName
						+ "RUP_3.1.3 : Response Hash from MPSDB_GetMemberServices_H.getMemberServices for parent : "
						+ hmDBParentInfo);

				if (hmDBParentInfo == null || hmDBParentInfo.isEmpty()) {

					stAppInfo = "MPSDB_GetMemberServices_H returned null/empty response";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					log.info(sClassName + sMethodName + "RUP_3.1.4 : " + stAppInfo);
					return hmResult;

				}

				stAppStatusCode = (String) hmDBParentInfo.get(CErrorDefs.COMMON_APP_STATUS_CODE);
				if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					if (stAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
						stAppInfo = "User Not Found in DB";
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
						log.info(sClassName + sMethodName + "RUP_R.1.5 : " + stAppInfo);
					} else {
						hmResult = hmDBParentInfo;
					}
					return hmResult;
				}
			}
			// [2008][MPSYS-UMP-252] - Added code for deleting the AppEmailPassword if MID
			// has linked user while fraud locking the MID
			// change by kc2039
			HashMap hmDBSlidInfo = (HashMap) hmDBMemberInfo.get(MPSDefs.KEY_SLID_INFO);
			ArrayList alKeyLinkedUser = new ArrayList();

			if (hmDBSlidInfo != null && !hmDBSlidInfo.isEmpty()) {
				alKeyLinkedUser = (ArrayList) hmDBSlidInfo.get(MPSDefs.KEY_LINKED_USERS);
			}

			if (hmInput.get(CommonDefs.USER_LOCK_LEVEL) != null
					&& !((String) hmInput.get(CommonDefs.USER_LOCK_LEVEL)).isEmpty() && alKeyLinkedUser != null
					&& !alKeyLinkedUser.isEmpty()) {

				HashMap hmEmailAppPwdHelperInp = new HashMap();
				hmEmailAppPwdHelperInp.put(MPSDefs.KEY_LINKED_USERS, alKeyLinkedUser);
				hmEmailAppPwdHelperInp.put(CommonDefs.TRANSACTION_NAME, CommonDefs.TRANS_NAME_RESET_PWD);
				hmEmailAppPwdHelperInp.put(CommonDefs.TRANSACTION_ID, sTransactionId);
				hmEmailAppPwdHelperInp.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
				hmEmailAppPwdHelperInp.put("suppressEDD", CommonDefs.IND_Y);

				log.debug(sClassName + sMethodName + "RUP_03.32a : "
						+ "Calling EmailAppPasswordHelper.deleteEmailAppPwd() :: Input Hash = "
						+ hmEmailAppPwdHelperInp);

				hmResult = emailAppPasswordHelper.deleteEmailAppPwd(hmEmailAppPwdHelperInp);

				log.debug(sClassName + sMethodName + "RUP_03.32b : "
						+ "Response from EmailAppPasswordHelper.deleteEmailAppPwd() = " + hmResult);

				if (hmResult == null || hmResult.isEmpty()) {
					stAppInfo = "hmResponse from EmailAppPasswordHelper is NULL or EMPTY";
					log.info(sClassName + sMethodName + "RUP_03.32c : " + stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					return hmResult;
				}

				stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

				if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					stAppInfo = "Error returned from deleteEmailAppPwd() Method"
							+ (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
					log.info(sClassName + sMethodName + "RUP_03.32d : "
							+ HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
					return hmResult;
				}

				if (hmResult.containsKey(CommonDefs.CONSOLIDATED_DBUS_INPUT)) {
                    alDbusEvents.addAll((ArrayList) hmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT));
				}

			}
			// End kc2039
			// Added sAssociatedSlid slid
			if (hmDBMemberInfo != null && hmDBMemberInfo.containsKey(MPSDefs.KEY_SLID_INFO)) {
				HashMap hmSlidInfo = (HashMap) hmDBMemberInfo.get(MPSDefs.KEY_SLID_INFO);

				if (hmSlidInfo != null && !hmSlidInfo.isEmpty()) {
					sAssociatedSlid = (String) hmSlidInfo.get(MPSDefs.DB_MEMBER_NAME);
					log.info(sClassName + sMethodName + "RUP_5C : " + "sAssociatedSlid assigned = " + sAssociatedSlid);
				}

			}

			// This method call is moved from UserFraudManager mS due to DB lock situation
			// happening there.
			hmResult = updateMemberFraudPassword(hmDBMemberInfo, hmInput, hmResult);

			String fullname = null;
			if (hmDBParentInfo != null) {
				fullname = (String) hmDBParentInfo.get(MPSDefs.DB_FULLNAME);
			} else if (hmDBMemberInfo != null) {
				fullname = (String) hmDBMemberInfo.get(MPSDefs.DB_FULLNAME);
			}

			String sor_name = (String) hmDBMemberInfo.get(MPSDefs.DB_SOR_NAME);
			if (sor_name != null && sor_name.trim().length() != 0) {
				hmUserHelperInput.put(CommonDefs.SOR_NAME, sor_name);
			}

			String migration_ind = null;
			boolean isParent = false;

			// check and set parent child indicator
			String parent_child_ind = (String) hmDBMemberInfo.get(MPSDefs.DB_PARENT_CHILD_IND);
			if (parent_child_ind.equals(MPSDefs.MPS_CHILD)) {
				log.info(sClassName + sMethodName + "RUP-8.0 : "
						+ "Setting child migration indicator to parents migration indicator");
				migration_ind = (String) hmDBParentInfo.get(MPSDefs.DB_MIGRATION_IND);
			} else {
				isParent = true;
				migration_ind = (String) hmDBMemberInfo.get(MPSDefs.DB_MIGRATION_IND);
			}
			hmUserHelperInput.put(CommonDefs.MIGRATION_IND, migration_ind);
			hmUserHelperInput.put(CommonDefs.PARENT_CHILD_IND, parent_child_ind);

			if (!isParent) {
				if (!(hmDBMemberInfo.get(MPSDefs.DB_MEMBER_STATE).equals(MPSDefs.RESERVED_STATE)
						|| hmDBMemberInfo.get(MPSDefs.DB_MEMBER_STATE).equals(MPSDefs.INUSE_STATE))) {
					stAppInfo = "Child member has no service and member_state is not RES or customer has services"
							+ " but no services are suspended and/or enabled";
					log.info(sClassName + sMethodName + "DCC-1 : " + stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, stAppInfo);
					return hmResult;
				}
			}

			// add ban to hash
			String ban = (String) hmDBMemberInfo.get(CommonDefs.BAN);
			if (ban != null) {
				hmUserHelperInput.put(CommonDefs.BAN, ban);
			}
			HashMap hmDBServices = (HashMap) hmDBMemberInfo.get(CommonDefs.SERVICES);

			ArrayList alServices = new ArrayList();
			ArrayList alServiceLevelSORs = new ArrayList();
			ArrayList alServiceTypes = new ArrayList();

			if (hmDBServices != null && !hmDBServices.isEmpty()) {
				HashMap hmConvertServicesResponse = new HashMap();

				log.info(sClassName + sMethodName
						+ "RUP_04.1.1 : Calling ConvertServicesHelper.convertServices with Hash : " + hmDBServices);
				hmConvertServicesResponse = oConvertServicesHelper.convertServices(hmDBServices);
				log.info(sClassName + sMethodName + "RUP_04.1.2 : Response from ConvertServicesHelper.convertServices: "
						+ hmConvertServicesResponse);

				alServiceTypes = (ArrayList) hmConvertServicesResponse.get(CommonDefs.SERVICE_TYPES);
				alServices = (ArrayList) hmConvertServicesResponse.get(CommonDefs.SERVICES);
				alServiceLevelSORs = (ArrayList) hmConvertServicesResponse.get(CommonDefs.SERVICE_LEVEL_SORS);
				if (alServiceLevelSORs.isEmpty())
					alServiceLevelSORs.add(sor_name);

			} else {
				// Added member level sor if member have no services
				alServiceLevelSORs.add(sor_name);
			}

			String sKeyName = null;
			boolean bDeliveryMethodPresent = false;
			if (hmDeliveryMethod != null) {
				String sDeliveryMethodType = (String) hmDeliveryMethod.get(CommonDefs.DELIVERY_METHOD_TYPE);

				sKeyName = CommonDefs.EDD_DELIVERY_METHODS;

				ArrayList alDeliveryMethods = null;
				if (stDeliveryMethods != null && !stDeliveryMethods.isEmpty()) {
					alDeliveryMethods = CommonUtil.parseToArray(stDeliveryMethods, CommonDefs.VALUE_SEPARATOR_CHAR);
				}

				boolean isValidDeliveryMethod = false;
				if (null != alDeliveryMethods) {
					for (int i = 0; i < alDeliveryMethods.size(); i++) {
						String sDeliveryMethod = (String) alDeliveryMethods.get(i);
						if (sDeliveryMethod.substring(0, 1).equals(sDeliveryMethodType)) {
							if (hmDeliveryMethod.containsKey(sDeliveryMethod.substring(2)) || ((sDeliveryMethodType
									.equals("M")
									&& (sor_name.equals(CommonDefs.SOR_COLA) || sor_name.equals(CommonDefs.SOR_CPR)
											|| sor_name.equals(CommonDefs.SOR_NA))))) {
								isValidDeliveryMethod = true;
								break;
							}
						}
					}
				}

				if (!isValidDeliveryMethod) {
					stAppInfo = "Invalid delivery method.";
					hmResult = CommonErrorMap.makeCommonStatusMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, stAppInfo);
					log.info(sClassName + sMethodName + "RUP_11 : " + stAppInfo);
					return hmResult;
				}

				bDeliveryMethodPresent = true;
				log.info(sClassName + sMethodName + "RUP_11.1 : " + "Delivery Method is present in input");

			} // end DeliveryMethod processing

			sKeyName = "PROP_RESET_USER_PASSWORD_agentToolList";

			ArrayList alAgentList = CommonUtil.parseToArray(stAgentToolList, CommonDefs.VALUE_SEPARATOR_CHAR);
			log.info(sClassName + sMethodName + "RUP_15.05 : alAgentList : " + alAgentList);

			if (alAgentList != null && !alAgentList.isEmpty())
				hmUserHelperInput.put("AGENT_LIST", alAgentList);

			ArrayList alLockoutInfo = (ArrayList) hmDBMemberInfo.get(MPSDefs.DB_MEMBERLOCKOUT);

			if (alLockoutInfo != null && !alLockoutInfo.isEmpty()) {
				log.info(sClassName + sMethodName + "RUP_12a : " + "Lockout data present:  " + alLockoutInfo);
				HashMap hmLockoutQueryInput = new HashMap();
				hmLockoutQueryInput.put(CommonDefs.MEMBER_NUM, hmDBMemberInfo.get(MPSDefs.DB_MEMBER_NUM));
				hmLockoutQueryInput.put(CommonDefs.MEMBER_LOCKOUT, alLockoutInfo);

				log.debug(sClassName + sMethodName + "RUP_12a.1 : Calling LockoutHelper.queryLockout with Hash : "
						+ hmLockoutQueryInput);
				hmResult = oLockoutHelper.queryLockout(hmLockoutQueryInput);
				log.debug(sClassName + sMethodName + "RUP_12a.2 : " + "Response from queryLockout() :  " + hmResult);

				stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
				if (!stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
					hmResult = hmResult;
					return hmResult;
				}

				alActiveLocks = (ArrayList) hmResult.get(CommonDefs.ACTIVE_LOCKS);
				alExpiredLocks = (ArrayList) hmResult.get(CommonDefs.EXPIRED_LOCKS);
				alNonExpiredNonActiveLocks = (ArrayList) hmResult.get(CommonDefs.NONEXPIRED_NONACTIVE_LOCKS);

				if (alExpiredLocks != null && !alExpiredLocks.isEmpty())
					hmUserHelperInput.put(CommonDefs.EXPIRED_LOCKS, alExpiredLocks);
				if (alNonExpiredNonActiveLocks != null && !alNonExpiredNonActiveLocks.isEmpty())
					hmUserHelperInput.put(CommonDefs.NONEXPIRED_NONACTIVE_LOCKS, alNonExpiredNonActiveLocks);
				if (alActiveLocks != null && !alActiveLocks.isEmpty()) {
					hmUserHelperInput.put(CommonDefs.ACTIVE_LOCKS, alActiveLocks);

					Iterator iter = alActiveLocks.iterator();
					while (iter.hasNext()) {
						HashMap hmEachLock = (HashMap) iter.next();
						String sLockName = (String) hmEachLock.get(MPSDefs.DB_LOCKOUT_NAME);

						if (sLockName != null && sLockName.equals(CommonDefs.PASSWORD_RESET_REQUESTS)
								&& !alAgentList.contains(sCallingSystemId)) { // Junit fix : Added not null condition.
							stAppInfo = "UserId currently locked out with a " + CommonDefs.PASSWORD_RESET_REQUESTS
									+ " lock.";
							hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_MID_LOCKOUT_NUM, stAppInfo);
							log.info(sClassName + sMethodName + "RUP_12c : " + stAppInfo);
							return hmResult;
						}

						if (sLockName != null && sLockName.equals(CommonDefs.FORGOT_PASSWORD_PREQUAL)
								&& sLockName.equals(sLockoutName) && !alAgentList.contains(sCallingSystemId)) { // Junit
																												// fix :
																												// Added
																												// not
																												// null
																												// condition.
							stAppInfo = "UserId currently locked out with a " + CommonDefs.FORGOT_PASSWORD_PREQUAL
									+ " lock.";
							hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_MID_LOCKOUT_NUM, stAppInfo);
							log.info(sClassName + sMethodName + "RUP_12d : " + stAppInfo);
							return hmResult;
						}

						if (sLockName != null && sLockName.equals(CommonDefs.SECRET_ANSWER)
								&& !alAgentList.contains(sCallingSystemId)) {// Junit fix: removing unreachable
																				// condition-
																				// sLockName.equals(sLockoutName)
							stAppInfo = "UserId currently locked out with a " + CommonDefs.SECRET_ANSWER + " lock.";
							hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_MID_LOCKOUT_NUM, stAppInfo);
							log.info(sClassName + sMethodName + "RUP_12e : " + stAppInfo);
							return hmResult;
						}
					} // end while
				} // end active locks processing
			} // end of lockout check

			HashMap hmSlidInfoForFraudLocks = null;

			if (sDomain != null && !sDomain.equals(CommonDefs.SLID_DUM) && hmDBMemberInfo != null
					&& hmDBMemberInfo.containsKey(MPSDefs.KEY_SLID_INFO)) {
				hmSlidInfoForFraudLocks = (HashMap) hmDBMemberInfo.get(MPSDefs.KEY_SLID_INFO);
			} else if (sDomain != null && sDomain.equals(CommonDefs.SLID_DUM)) {
				hmSlidInfoForFraudLocks = hmDBMemberInfo;
			}

			if (hmSlidInfoForFraudLocks != null && !hmSlidInfoForFraudLocks.isEmpty()
					&& hmSlidInfoForFraudLocks.get(MPSDefs.DB_USER_LOCK_LEVEL) != null && sSlidMemberNum != null) {
				String sUserLockLevel = (String) hmSlidInfoForFraudLocks.get(MPSDefs.DB_USER_LOCK_LEVEL);
//				if (sUserLockLevel != null && !sUserLockLevel.isEmpty()) {
//					hmUserHelperInput.put(MPSDefs.DB_USER_LOCK_LEVEL, sUserLockLevel);
//				}
				String sUserLockReason = (String) hmSlidInfoForFraudLocks.get(MPSDefs.DB_USER_LOCK_REASON);
				if (sUserLockReason != null && !sUserLockReason.isEmpty()) {
					hmUserHelperInput.put(MPSDefs.DB_USER_LOCK_REASON, sUserLockReason);
				}
				// gs799f added beow for lock level 2 validation
				if (StringUtils.isNotBlank(origTransactionName) && origTransactionName.equalsIgnoreCase("ResetUserPassword") && "2".equals(sUserLockLevel)) {
					stAppInfo = "User Fraud lock 2 exists";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_FRAUD_LOCKED_NUM, stAppInfo);
					log.info(sClassName + sMethodName + "RUP_13a : " + stAppInfo);
					return hmResult;
				} else if ("1".equals(sUserLockLevel) && !hmInput.containsKey("userLockLevel")) {
					// 2005: PID 306822b
					hmUserHelperInput.put("PROCESS_USER_FRAUD_LOCKS", "Y");
				}

			}
			// PID-400970e [MPSYS-US12][2112] Update the MOUP.resetUserPassword mS endpoint
			// to reject transactions on FN accessIDs
			// change by mc288e

			if (hmSlidInfoForFraudLocks != null && !hmSlidInfoForFraudLocks.isEmpty()) {
				String sFnLinkedStatus = (String) hmSlidInfoForFraudLocks.get(CommonDefs.DB_FN_LINKED_STATUS);
				if (sFnLinkedStatus != null && sFnLinkedStatus.equalsIgnoreCase(CommonDefs.FN_STATUS_SELF)) {
					stAppInfo = "FirstNet linked accessId";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, stAppInfo);
					log.info(sClassName + sMethodName + "RUP_13a_1 : " + stAppInfo);
					return hmResult;
				}
			}
			// END
			boolean bDoNotProof = false;

			String sDBMemberNum = (String) hmDBMemberInfo.get(MPSDefs.DB_MEMBER_NUM);
			if (sDBMemberNum != null) {
				hmUserHelperInput.put(CommonDefs.MEMBER_NUM, sDBMemberNum);
			}

			hmUserHelperInput.put(CommonDefs.PARENT_HANDLE, hmDBMemberInfo.get(MPSDefs.DB_PARENT_NAME));
			hmUserHelperInput.put(CommonDefs.PARENT_DOMAIN, hmDBMemberInfo.get(MPSDefs.DB_PARENT_DOMAIN));
			hmUserHelperInput.put(CommonDefs.DATE_OF_BIRTH, hmDBMemberInfo.get(MPSDefs.DB_BIRTHDATE));

			if (hmDBServices != null) {
				hmUserHelperInput.put(CommonDefs.SERVICES, hmDBServices);
			}

			if (sMemberNum != null) {
				hmUserHelperInput.put(CommonDefs.MEMBER_NUM, sMemberNum);
			}

			if (hmDBParentInfo != null)
				hmUserHelperInput.put(CommonDefs.AGG_EMAIL_STATUS, hmDBParentInfo.get(MPSDefs.DB_AGG_EMAIL_STATUS));
			else
				hmUserHelperInput.put(CommonDefs.AGG_EMAIL_STATUS, hmDBMemberInfo.get(MPSDefs.DB_AGG_EMAIL_STATUS));
			hmUserHelperInput.put(CommonDefs.CONTACT_EMAIL, hmDBMemberInfo.get(MPSDefs.DB_CONTACT_EMAIL));

			ArrayList alLinkedUsers = new ArrayList();

			HashMap hmSlidInfo = (HashMap) hmDBMemberInfo.get(MPSDefs.KEY_SLID_INFO);
			if (hmSlidInfo != null && !hmSlidInfo.isEmpty()) {
				if (hmSlidInfo.containsKey(MPSDefs.KEY_LINKED_USERS)) {
					ArrayList alDBLinkedUsers = (ArrayList) hmSlidInfo.get(MPSDefs.KEY_LINKED_USERS);
					alLinkedUsers.addAll(alDBLinkedUsers);

					HashMap hmThisMemberDB = CommonUtil.getHashMap();
					// [R1908] - Adding services as slidInfo will not have services
					if (sDomain != null && sDomain.equals(CommonDefs.SLID_DUM)) {
						hmSlidInfo.put(CommonDefs.SERVICES, hmDBServices);
					}
					hmThisMemberDB.putAll(hmSlidInfo);
					hmThisMemberDB.remove(MPSDefs.KEY_LINKED_USERS);
					alLinkedUsers.add(hmThisMemberDB);

					log.info(sClassName + sMethodName + "CPH1-3a : Linked users assigned, alLinkedUsers = "
							+ alLinkedUsers);
				}
			}

			String sCPNILinkedToSLID = "N";

			if (alLinkedUsers != null && !alLinkedUsers.isEmpty()) { // Junit fix : Added not empty condition.
				sCPNILinkedToSLID = oUserPasswordHelper.getCPNILinkedToSLID(alLinkedUsers);
			} else if (sSlidMemberNum != null && sSlidMemberNum.equals(sDBMemberNum)) {
				// naked SLID scenario - account is slid but no linked users
				ArrayList alSlidInfo = new ArrayList();
				alSlidInfo.add(hmDBMemberInfo);
				sCPNILinkedToSLID = oUserPasswordHelper.getCPNILinkedToSLID(alSlidInfo);
			}

			hmUserHelperInput.put("isCPNILinkedToSLID", sCPNILinkedToSLID);

			if (hmDBMemberInfo.containsKey(MPSDefs.DB_BROWSER_LANGUAGE))
				hmUserHelperInput.put(CommonDefs.BROWSER_LANGUAGE, hmDBMemberInfo.get(MPSDefs.DB_BROWSER_LANGUAGE));
			if (hmDBMemberInfo.containsKey(MPSDefs.DB_LC_FIRSTNAME))
				hmUserHelperInput.put(CommonDefs.FIRST_NAME, hmDBMemberInfo.get(MPSDefs.DB_LC_FIRSTNAME));
			if (hmDBMemberInfo.containsKey(MPSDefs.DB_LC_LASTNAME))
				hmUserHelperInput.put(CommonDefs.LAST_NAME, hmDBMemberInfo.get(MPSDefs.DB_LC_LASTNAME));

			hmUserHelperInput.put("SECONDARY_LOCK_NAME", CommonDefs.PASSWORD_RESET_REQUESTS);

			// [SPTLGCYENB-1226]-ResetUserPasswordHelper updates the password information in
			// MPSYS Member andMEMBERAUX table
			if (sClearOnlineQA != null && sClearOnlineQA.equalsIgnoreCase(CommonDefs.IND_Y)) {
				hmUserHelperInput.put(CommonDefs.SECURITY_ANSWER_CHANGED, CommonDefs.DEFAULT_YES);
				hmUserHelperInput.put(CommonDefs.WS_ONLINE1_SECURITY_QUESTION_ID, null);
				hmUserHelperInput.put(CommonDefs.WS_ONLINE1_SECURITY_ANSWER, null);
				hmUserHelperInput.put(CommonDefs.WS_ONLINE2_SECURITY_QUESTION_ID, null);
				hmUserHelperInput.put(CommonDefs.WS_ONLINE2_SECURITY_ANSWER, null);

				// These will be used by getProofingVersion
				hmDBMemberInfo.put(CommonDefs.ONLINE1_SECURITY_QUESTION, null);
				hmDBMemberInfo.put(CommonDefs.ONLINE1_SECURITY_ANSWER, null);
				hmDBMemberInfo.put(CommonDefs.ONLINE1_SECURITY_QUESTION, null);
				hmDBMemberInfo.put(CommonDefs.ONLINE1_SECURITY_ANSWER, null);
			}

			log.debug(SpiMarker.getInstance(),
					sClassName + sMethodName
							+ "RUP_32a : Calling UserPasswordHelper.processChangePassword with Input Hash : {}",
					(hmUserHelperInput != null ? StringUtils.normalizeSpace(hmUserHelperInput.toString()) : "null"));
			hmResult = oUserPasswordHelper.processChangePassword(hmUserHelperInput, hmDBMemberInfo, hmDBParentInfo);
			log.debug(SpiMarker.getInstance(),
					sClassName + sMethodName + "RUP_32b : Response from UserPasswordHelper.processChangePassword : {}",
					hmResult);

			stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {

				stAppInfo = "Error returned from UserPasswordHelper.processChangePassword";
				log.info(sClassName + sMethodName + "RUP_32.1.a : " + stAppInfo);
				return hmResult;
			} else {
				isTransactionRollbackOnError = true;
			}

			if (hmResult.containsKey(CommonDefs.CONSOLIDATED_DBUS_INPUT)) {
                alDbusEvents.addAll((ArrayList) hmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT));
			}

			String sRMPNotificationEvent = CommonDefs.CONTEXT_EDDHPRTYPwdNotification;

			HashMap hmNotification = new HashMap();
			HashMap hmNotificationfields = new HashMap();
			String sCustomerId = null;
			String sCustomerServiceType = null;
			String sSLID_Notification = null;
			String sIdType = null;

			log.info(sClassName + sMethodName + "RUP_18.0.1 : ChangePassword_Service_To_NotificationField : "
					+ stSrvNotificationField);

			HashMap hmServiceToNotificationfieldMapping = CommonUtil.parsePropertyToHash(stSrvNotificationField);

			if (hmServiceToNotificationfieldMapping != null && !hmServiceToNotificationfieldMapping.isEmpty()) {
				if (sDomain.equals(CommonDefs.SLID_DUM)) {
					sCustomerId = sHandle;
					sCustomerServiceType = (String) hmServiceToNotificationfieldMapping.get(CommonDefs.KEY_SLID);
				} else if (alServiceTypes != null && alServiceTypes.contains(MPSDefs.UVERSE_SERVICE)) {
					sCustomerServiceType = (String) hmServiceToNotificationfieldMapping.get(MPSDefs.UVERSE_SERVICE);
					sCustomerId = sHandle + "@" + sDomain;
				} else if (alServiceTypes != null && alServiceTypes.contains(MPSDefs.DSL_SERVICE)) {
					sCustomerServiceType = (String) hmServiceToNotificationfieldMapping.get(MPSDefs.DSL_SERVICE);
					sCustomerId = sHandle + "@" + sDomain;
				} else if (alServiceTypes != null && alServiceTypes.contains(MPSDefs.DIAL_SERVICE)) {
					sCustomerServiceType = (String) hmServiceToNotificationfieldMapping.get(MPSDefs.DIAL_SERVICE);
					sCustomerId = sHandle + "@" + sDomain;
				} else if (alServiceTypes != null && alServiceTypes.contains(MPSDefs.SWH_SERVICE)) {
					sCustomerServiceType = (String) hmServiceToNotificationfieldMapping.get(MPSDefs.SWH_SERVICE);
					sCustomerId = sHandle + "@" + sDomain;
				} else if (alServiceTypes != null && alServiceTypes.contains(MPSDefs.ECOMM_SERVICE)) {
					sCustomerServiceType = (String) hmServiceToNotificationfieldMapping.get(MPSDefs.ECOMM_SERVICE);
					sCustomerId = sHandle + "@" + sDomain;
				} else if (alServiceTypes != null && alServiceTypes.size() == 1
						&& alServiceTypes.contains(MPSDefs.PORTAL_SERVICE)) {
					sCustomerServiceType = (String) hmServiceToNotificationfieldMapping.get(MPSDefs.PORTAL_SERVICE);
					sCustomerId = sHandle + "@" + sDomain;
				}
			}

			if (sDomain != null && !sDomain.equals(CommonDefs.SLID_DUM) && hmDBMemberInfo != null
					&& hmDBMemberInfo.containsKey(MPSDefs.KEY_SLID_INFO)) {
				sSLID_Notification = (String) ((HashMap) hmDBMemberInfo.get(MPSDefs.KEY_SLID_INFO))
						.get(MPSDefs.DB_MEMBER_NAME);
			} else if (sDomain != null && sDomain.equals(CommonDefs.SLID_DUM)) {
				sSLID_Notification = sHandle;
			}

			if (sDomain != null && !sDomain.equals(CommonDefs.SLID_DUM) && sSLID_Notification != null) {
				sIdType = "ID_LINKED_TO_SLID";
			} else if (sDomain != null && sDomain.equals(CommonDefs.SLID_DUM)
					&& (alLinkedUsers != null && !alLinkedUsers.isEmpty())) {// [R1908] Updated for proper idType
																				// generation

				sIdType = "SLID_WITH_LINKED_ID";
			} else if (sDomain != null && sDomain.equals(CommonDefs.SLID_DUM)
					&& (alLinkedUsers == null || alLinkedUsers.isEmpty())) {
				sIdType = "SLID";
			} else {
				sIdType = null;
			}

			hmNotificationfields.put("customerId", sCustomerId);
			hmNotificationfields.put("customerServiceType", sCustomerServiceType);
			hmNotificationfields.put("idType", sIdType);
			hmNotificationfields.put("SLID", sSLID_Notification);
			HashMap hmInputNotification = new HashMap();
			hmInputNotification.put("Notificationfields", hmNotificationfields);
			// debug this sttattement and compare
			hmInputNotification.put("ServiceToNotificationfieldMapping", hmServiceToNotificationfieldMapping);

			hmResult = (HashMap) passwordQueueHelper.buildNotificationHash(hmUserHelperInput, hmDBMemberInfo,
					hmInputNotification);

			stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
			// Junit fix:
			/*
			 * if (stAppStatusCode != null &&
			 * !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) { stAppInfo = (String)
			 * hmResult.get(CommonDefs.COMMON_APP_INFO); log.info(sClassName + sMethodName +
			 * "GPH_09.2 : " + stAppInfo); hmResult =
			 * CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
			 * return hmResult; }
			 */

			hmNotification = (HashMap) hmResult.get("NOTIFICATIONHASH");
			if (hmNotification != null && !hmNotification.isEmpty()) {
				if (!isSuppressEDD) {
                    alDbusEvents.add(hmNotification);
				}

			}

			if (alLinkedUsers != null) {
				Iterator alLinkedUsersIterator = alLinkedUsers.iterator();
				while (alLinkedUsersIterator.hasNext()) {
					HashMap hmEachUser = (HashMap) alLinkedUsersIterator.next();

					String sEachUserMemNum = (String) hmEachUser.get(MPSDefs.DB_MEMBER_NUM);
					if (!sEachUserMemNum.equals(sDBMemberNum)) {
						hmResult = passwordQueueHelper.buildNotificationHash(hmUserHelperInput, hmEachUser,
								hmInputNotification);

						stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
						// Junit fix:
						/*
						 * if (stAppStatusCode != null &&
						 * !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) { stAppInfo = (String)
						 * hmResult.get(CommonDefs.COMMON_APP_INFO); log.info(sClassName + sMethodName +
						 * "GPH_09.2 : " + stAppInfo); hmResult =
						 * CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
						 * return hmResult; }
						 */

						if (hmResult.get("NOTIFICATIONHASH") != null) {
							if (!isSuppressEDD) {
                                alDbusEvents.add((Map<String, Object>) hmResult.get("NOTIFICATIONHASH"));
							}

						}
					}
				}
			}

            if (!alDbusEvents.isEmpty()) {
				log.info(sClassName + sMethodName + "RUP_16.1.0 : Calling makeAsyncCall : ");

                hmResult = (HashMap) passwordQueueHelper.sendMessageToMQ(hmInput, hmDBMemberInfo, alDbusEvents, PasswordQueueHelper.RESET_EVENT_TYPE);

				log.info(sClassName + sMethodName + "RUP_16.1.1 : Response from makeAsyncCall : " + hmResult);

				stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

				if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
					log.info(sClassName + sMethodName + "RUP_09.2 : " + stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
					return hmResult;
				} else {
					isTransactionRollbackOnError = true;
				}
			}

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

			ArrayList<String> alReturnPwdCallers = CommonUtil.parseToArray(stReturnPwdCallers,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			if ((hmDeliveryMethod == null || hmDeliveryMethod.isEmpty())
					&& (alReturnPwdCallers != null && !alReturnPwdCallers.isEmpty())) {
				hmResult.put("generatedPassword", sGeneratedPassword);
			}

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, log);
			log.error(sClassName + sMethodName + "RUP_9.1e : " + " Error::" + e.getMessage());
			log.error(sClassName + sMethodName + "RUP_9.2e : " + "Exception = {}", e);
		} finally {
			stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);

			if (stAppStatusCode != null && stAppStatusCode.equals(CErrorDefs.ERR_MID_LOCKOUT)) {
				HashMap hmActiveLocks = null;
				ArrayList alLockList = new ArrayList();
				if (alActiveLocks != null && !alActiveLocks.isEmpty()) {
					Iterator alActiveLocksIter = alActiveLocks.iterator();
					while (alActiveLocksIter.hasNext()) {
						hmActiveLocks = (HashMap) alActiveLocksIter.next();
						hmActiveLocks.put("authAttemptsRemaining", "0");
						alLockList.add(hmActiveLocks);
						break;
					}
				}
				if (alLockList != null && !alLockList.isEmpty()) {
					hmResult.put(CommonDefs.LOCK_LIST, alLockList);
				}
			}

			if (sAssociatedSlid != null) {
				hmResult.put(CommonDefs.SLID, sAssociatedSlid);
			}

			stAppInfo = "Response from ResetUserPasswordHelper = " + hmResult;
			log.info(SpiMarker.getInstance(), sClassName + sMethodName + "HLP999 : {}",
					StringUtils.normalizeSpace(stAppInfo));
		}
		return hmResult;
	}

	/**
	 * This method is used to process failed authentication attempts. It takes two
	 * HashMaps as input. The first HashMap contains input parameters for the
	 * method, and the second HashMap contains information about the member from the
	 * database. The method checks if the user lock level is not null and not empty,
	 * and if the password dirty flag is null, empty, or 'N'. If these conditions
	 * are met, it prepares the input for the LockoutHelper.updateLockout method and
	 * makes the call. It then checks the status code returned by the updateLockout
	 * method. If the status code is not 'COMMON_SUCCESS', it prepares an error
	 * HashMap and returns it. If the status code is 'COMMON_SUCCESS', it prepares
	 * the input for the UserPasswordHelper.buildCreateInteractionHash method and
	 * makes the call. It then checks the status code returned by the
	 * buildCreateInteractionHash method. If the status code is not
	 * 'COMMON_SUCCESS', it prepares an error HashMap and returns it. If the status
	 * code is 'COMMON_SUCCESS', it prepares the input for the makeAsyncCall method
	 * and makes the call. It then checks the status code returned by the
	 * makeAsyncCall method. If the status code is not 'COMMON_SUCCESS', it prepares
	 * an error HashMap and returns it. If the status code is 'COMMON_SUCCESS', it
	 * simply returns the result HashMap. In case of any exception, it logs the
	 * error and returns an error HashMap.
	 *
	 * @param hmInput   HashMap containing the input parameters for the method.
	 * @param hmDBInput HashMap containing the member information from the database.
	 * @return HashMap containing the result of the failed authentication process.
	 */
	public HashMap processFailedAuth(HashMap hmInput, HashMap hmDBInput) {
		String sMethodName = ".processFailedAuth.";
		HashMap hmResponse = new HashMap();
		String sAppInfo = "";
		String sAppStatusCode = "";
		boolean isAccountLocked = false;
		ArrayList alLocks = null;
		String stAppStatusCode = null;
		String stAppInfo = null;

		log.info(sClassName + sMethodName + "PFA-1 : Input Hash = {}",
				(hmInput != null ? StringUtils.normalizeSpace(hmInput.toString()) : "null"));

		try {
			String sLockoutName = (String) hmDBInput.get(MPSDefs.DB_LOCKOUT_NAME);
			HashMap hmLockoutUpdateInput = new HashMap();
			hmLockoutUpdateInput.put(MPSDefs.DB_MEMBER_NUM, hmDBInput.get(MPSDefs.DB_MEMBER_NUM));
			hmLockoutUpdateInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
			hmLockoutUpdateInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
			hmLockoutUpdateInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
			hmLockoutUpdateInput.put(CommonDefs.HANDLE, hmInput.get(CommonDefs.HANDLE));
			hmLockoutUpdateInput.put(CommonDefs.DOMAIN, hmInput.get(CommonDefs.DOMAIN));
			hmLockoutUpdateInput.put(CommonDefs.VALIDATION_STATUS, CommonDefs.VALIDATION_STATUS_FAILURE);

			boolean isNewLockNeeded = true;

			if (hmDBInput.containsKey(CommonDefs.ACTIVE_LOCKS)) {
				ArrayList alActiveLocks = (ArrayList) hmDBInput.get(CommonDefs.ACTIVE_LOCKS);
				Iterator iter = alActiveLocks.iterator();
				ArrayList alInterestedLocks = new ArrayList();
				while (iter.hasNext()) {
					HashMap hmEachLock = (HashMap) iter.next();
					String sLockName = (String) hmEachLock.get(MPSDefs.DB_LOCKOUT_NAME);
					if (sLockName.equals(sLockoutName)) {
						alInterestedLocks.add(hmEachLock);
						hmLockoutUpdateInput.put(CommonDefs.ACTIVE_LOCKS, alInterestedLocks);
						isNewLockNeeded = false;
						break;
					}
				}
			}
			if (hmDBInput.containsKey(CommonDefs.EXPIRED_LOCKS)) {
				ArrayList alExpiredLocks = (ArrayList) hmDBInput.get(CommonDefs.EXPIRED_LOCKS);
				Iterator iter = alExpiredLocks.iterator();
				ArrayList alInterestedLocks = new ArrayList();
				while (iter.hasNext()) {
					HashMap hmEachLock = (HashMap) iter.next();
					String sLockName = (String) hmEachLock.get(MPSDefs.DB_LOCKOUT_NAME);
					if (sLockName.equals(sLockoutName)) {
						alInterestedLocks.add(hmEachLock);
						hmLockoutUpdateInput.put(CommonDefs.EXPIRED_LOCKS, alInterestedLocks);
						isNewLockNeeded = false;
						break;
					}
				}
			}
			if (hmDBInput.containsKey(CommonDefs.NONEXPIRED_NONACTIVE_LOCKS)) {
				ArrayList alNonExpiredNonActiveLocks = (ArrayList) hmDBInput.get(CommonDefs.NONEXPIRED_NONACTIVE_LOCKS);
				Iterator iter = alNonExpiredNonActiveLocks.iterator();
				ArrayList alInterestedLocks = new ArrayList();
				while (iter.hasNext()) {
					HashMap hmEachLock = (HashMap) iter.next();
					String sLockName = (String) hmEachLock.get(MPSDefs.DB_LOCKOUT_NAME);
					if (sLockName.equals(sLockoutName)) {
						alInterestedLocks.add(hmEachLock);
						hmLockoutUpdateInput.put(CommonDefs.NONEXPIRED_NONACTIVE_LOCKS, alInterestedLocks);
						isNewLockNeeded = false;
						break;
					}
				}
			}

			if (isNewLockNeeded) {
				ArrayList alNewLock = new ArrayList();
				HashMap hmNewLock = new HashMap();
				String sSlidMemberNum = (String) hmDBInput.get(MPSDefs.DB_SLID_MEMBER_NUM);
				if (sSlidMemberNum != null && sSlidMemberNum.length() > 0)
					hmNewLock.put(MPSDefs.DB_MEMBER_NUM, sSlidMemberNum);
				else
					hmNewLock.put(MPSDefs.DB_MEMBER_NUM, hmDBInput.get(MPSDefs.DB_MEMBER_NUM));
				hmNewLock.put(MPSDefs.DB_LOCKOUT_NAME, hmInput.get(MPSDefs.DB_LOCKOUT_NAME));
				alNewLock.add(hmNewLock);
				hmLockoutUpdateInput.put("newLock", alNewLock);
			}

			log.info(sClassName + sMethodName + "PFA-2a : Calling oLockoutHelper.updateLockout() ");

			alLocks = new ArrayList();
			hmResponse = oLockoutHelper.updateLockout(hmLockoutUpdateInput);
			log.info(sClassName + sMethodName + "PFA-2b : Calling oLockoutHelper.updateLockout() ");
			sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
			if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS) && !sAppStatusCode.equals(CErrorDefs.ERR_MID_LOCKOUT))
				return hmResponse;
			if (sAppStatusCode.equals(CErrorDefs.ERR_MID_LOCKOUT))
				isAccountLocked = true;

			if (hmResponse.containsKey(sLockoutName)) {
				alLocks.addAll((ArrayList) hmResponse.get(sLockoutName));
			}

			String sFailedAuthCount = "1";
			if (hmResponse.containsKey(sLockoutName)) {
				ArrayList alUpdatedLock = (ArrayList) hmResponse.get(sLockoutName);
				HashMap hmUpdatedLock = (HashMap) alUpdatedLock.get(0);
				sFailedAuthCount = (String) hmUpdatedLock.get(MPSDefs.DB_FAILED_AUTH_COUNT);
			}
			ArrayList alDbus = new ArrayList();
			HashMap hmGACH = oUserPasswordHelper.generateHmGACH(hmInput, hmDBInput);
			hmGACH.put(CommonDefs.CREATE_INTERACTION_RESULT, CommonDefs.REASON_CODE_FAILED);
			hmGACH.put(MPSDefs.DB_FAILED_AUTH_COUNT, sFailedAuthCount);
			hmResponse = oUserPasswordHelper.buildCreateInteractionHash(hmGACH, hmDBInput);
			sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
			if (!sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
				return hmResponse;

			if (hmResponse.get("CREATEINTERACTIONHASH") != null) {
				log.info(sClassName + sMethodName + "PFA-3a : Calling Dbus() ");
				alDbus.add(hmResponse.get("CREATEINTERACTIONHASH"));
				// call makeasync call

				log.info(sClassName + sMethodName + "PFA-4a : Calling makeAsyncCall ");

                hmResponse = (HashMap) passwordQueueHelper.sendMessageToMQ(hmInput, hmDBInput, alDbus, PasswordQueueHelper.RESET_EVENT_TYPE);

				log.info(sClassName + sMethodName + "PFA-4b : Response from makeAsyncCall : " + hmResponse);

				stAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);

				if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
					log.info(sClassName + sMethodName + "GPH_09.2 : " + stAppInfo);
					hmResponse = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
					return hmResponse;
				}

			} else
				log.info(sClassName + sMethodName + "PFA-4c : CreateInteractionEvent not required.");

		} catch (Exception e) {
			hmResponse = CommonErrorMap.makeExceptionMap(e);
			log.error(sClassName + sMethodName + "PFA-E1 : " + " Error::" + e.getMessage());
			log.error(sClassName + sMethodName + "PFA-E2 : " + "Exception = {}", e);

		} finally {
			if (hmResponse == null) {
				sAppInfo = "hmResponse is null";
				log.info(sClassName + sMethodName + "PFA-Fa" + sAppInfo);
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
			} else {

				if (isAccountLocked) {
					hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_MID_LOCKOUT_NUM,
							"Account is now locked.");
					if (!alLocks.isEmpty())
						hmResponse.put(CommonDefs.LOCK_LIST, alLocks);
				}
				if (hmInput.containsKey(CommonDefs.SLID))
					hmResponse.put(CommonDefs.SLID, hmInput.get(CommonDefs.SLID));

			}
			log.info(sClassName + sMethodName + "PFA-Fb : Response From processFailedAuth() : " + hmResponse);
		}

		return hmResponse;
	}

	/**
	 * This method is used to validate the establishment date of online QA. It takes
	 * a String as input which represents the establishment date of online QA in the
	 * format "MMddyyyy HH:mm:ss". The method parses the input date and checks if it
	 * has aged based on the property SECURITY_QA_AGING_DAYS. If the input date has
	 * not aged, it returns true. Otherwise, it returns false.
	 *
	 * @param sOnlineQAEstDate String representing the establishment date of online
	 *                         QA.
	 * @return boolean indicating whether the online QA establishment date has aged
	 *         or not.
	 */
	public boolean validateOnlineQAEstDate(String sOnlineQAEstDate) {

		String sMethodName = ".validateOnlineQAEstDate.";
		boolean bOnlineQADateNotAged = false;

		try {
			if (sOnlineQAEstDate != null && !sOnlineQAEstDate.isEmpty()) {
				Calendar cal = Calendar.getInstance();
				DateFormat dtFmt = new SimpleDateFormat("MMddyyyy HH:mm:ss");
				Date dtOnlineQAEstDate = dtFmt.parse(sOnlineQAEstDate);
				cal.setTime(dtOnlineQAEstDate);

				// String sPropSecurityQAAgingDays =
				// PropertyManager.getProperty(CommonDefs.MOUPConfig,
				// CommonDefs.PROP_SECURITY_QA_AGING_DAYS);
				log.info(sClassName + sMethodName + "VOQAED_01 : " + "Property SECURITY_QA_AGING_DAYS : "
						+ sPropSecurityQAAgingDays);

				int iPropSecurityQAAgingDays = 0;

				if (sPropSecurityQAAgingDays != null && !sPropSecurityQAAgingDays.isEmpty()) {
					iPropSecurityQAAgingDays = Integer.parseInt(sPropSecurityQAAgingDays);
				}

				cal.add(Calendar.DAY_OF_MONTH, iPropSecurityQAAgingDays);

				Date systemDate = dtFmt.parse(dtFmt.format(new Date()));
				Date dtOnlineEstDate = dtFmt.parse(dtFmt.format(cal.getTime()));

				log.info(sClassName + sMethodName + "VOQAED_02 : " + "dtOnlineEstDate : " + dtOnlineEstDate);
				log.info(sClassName + sMethodName + "VOQAED_03 : " + "systemDate : " + systemDate);
				if (dtOnlineEstDate.after(systemDate)) {
					bOnlineQADateNotAged = true;
				}

			}
		} catch (Exception e) {
			log.error(sClassName + sMethodName + "VOQAED_04.e : " + " Error::" + e.getMessage());
			log.error(sClassName + sMethodName + "VOQAED_05.e : " + "Exception = {}", e);
		}

		log.info(sClassName + sMethodName + "VOQAED_06 : " + "bOnlineQADateNotAged : " + bOnlineQADateNotAged);
		return bOnlineQADateNotAged;
	}

	/**
	 * This method is used to update the member fraud password. It takes three
	 * HashMaps as input. The first HashMap contains information about the member
	 * from the database, the second HashMap contains input parameters for the
	 * method, and the third HashMap contains the result of the method. The method
	 * checks if the user lock level is not null and not empty, and if the password
	 * dirty flag is null, empty, or 'N'. If these conditions are met, it prepares
	 * the input for the memberFraudPasswordDBHelper.addMemberFraudPwd method and
	 * makes the call. It then checks the status code returned by the
	 * addMemberFraudPwd method. If the status code is not 'COMMON_SUCCESS', it
	 * prepares an error HashMap and returns it. If the status code is
	 * 'COMMON_SUCCESS', it simply returns the result HashMap. In case of any
	 * exception, it logs the error.
	 *
	 * @param hmDBMemberInfo HashMap containing the member information from the
	 *                       database.
	 * @param hmInput        HashMap containing the input parameters for the method.
	 * @param hmResult       HashMap containing the result of the method.
	 * @return HashMap containing the result of the update operation.
	 */
	public HashMap updateMemberFraudPassword(HashMap hmDBMemberInfo, HashMap hmInput, HashMap hmResult) {

		String sMethodName = ".updateMemberFraudPassword.";
		String stAppStatusCode = null;
		String stAppInfo = null;

		// Following code has been moved from UserFraudManager mS in order to fix the
		// the DB lock issue which was occurring due to MemberFraudPassword table update
		// running trigger to update MemberAux Table.

		try {
			String sDBPasswordDirty = (String) hmDBMemberInfo.get(CommonDefs.PASSWORD_DIRTY);
			String sGuid = (String) hmDBMemberInfo.get(CommonDefs.DB_MEMBER_NUM);
			String sUsrLockLevel = (String) hmInput.get(CommonDefs.USER_LOCK_LEVEL);
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

			if (sUsrLockLevel != null && !sUsrLockLevel.isEmpty() && (sDBPasswordDirty == null
					|| sDBPasswordDirty.isEmpty() || sDBPasswordDirty.equals(CommonDefs.IND_N))) {
				HashMap hmMemFraudPwdInput = CommonUtil.getHashMap();
				hmMemFraudPwdInput.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);
				hmMemFraudPwdInput.put(MPSDefs.DB_MEMBER_NUM, sGuid);
				log.info("{}{}UMFP_1.1 :Calling to memberFraudPasswordDBHelper.addMemberFraudPwd with input : {}",
						sClassName, sMethodName, hmMemFraudPwdInput);
				hmResult = memberFraudPasswordDBHelper.addMemberFraudPwd(hmMemFraudPwdInput);

				log.debug("{}{}UMFP_1.2 : Response Hash from memberFraudPasswordDBHelper.addMemberFraudPwd is =  {}",
						sClassName, sMethodName, hmResult);

				stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

				if (stAppStatusCode != null && !stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
					stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
					hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
					log.info("{}{}UMFP_1.3 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
			}
		} catch (Exception e) {
			log.error(sClassName + sMethodName + "UMFP_1.4 : " + " Error::" + e.getMessage());
			log.error(sClassName + sMethodName + "UMFP_1.5 : " + "Exception = {}", e);
		}

		return hmResult;
	}

}
