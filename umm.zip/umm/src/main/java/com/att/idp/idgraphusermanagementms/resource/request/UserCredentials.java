package com.att.idp.idgraphusermanagementms.resource.request;

import static org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString;
import static org.apache.commons.lang3.builder.ToStringStyle.JSON_STYLE;

import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;


/**
 * This class represents the user's credentials in the system.
 * It contains fields for billingZip, proofZip, dateOfBirth, lastFourSSN, contactEmail, lastName, and a map for unknownAttributes.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 * It also overrides the toString method to return a JSON-style string representation of the object.
 *
 */
@Data
@Schema(name = "UserCredentials")
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserCredentials {

	@Size(min = 1, max = 5, message =  "billingZip length is invalid|ValidateUserCredentials")
	@Schema(name = "billingZip")
	private String billingZip;

	@Size(min = 1, max = 5, message =  "proofZip length is invalid|ValidateUserCredentials")
	@Schema(name = "proofZip")
	private String proofZip;

	@Size(min = 1, max = 8, message =  "dateOfBirth length is invalid|ValidateUserCredentials")
	@Schema(name = "dateOfBirth")
	private String dateOfBirth;

	@Size(min = 1, max = 4, message =  "lastFourSSN length is invalid|ValidateUserCredentials")
	@Schema(name = "lastFourSSN")
	private String lastFourSSN;

	@Size(min = 1, max = 255, message =  "contactEmail length is invalid|ValidateUserCredentials")
	@Schema(name = "contactEmail")
	private String contactEmail;

	@Size(min = 1, max = 50, message =  "lastName length is invalid|ValidateUserCredentials")
	@Schema(name = "lastName")
	private String lastName;

	/**
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
	 * @return Map<String,Object> The map of unknown attributes.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();

	@Override
    public String toString() {
         return reflectionToString(this, JSON_STYLE);
    }
}