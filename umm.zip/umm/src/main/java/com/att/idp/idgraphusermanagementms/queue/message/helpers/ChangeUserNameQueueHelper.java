package com.att.idp.idgraphusermanagementms.queue.message.helpers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.att.mpsys.common.helpers.FeatureManagerHelper;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.queue.message.sender.JMSQueueSender;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * The ChangeUserNameQueueHelper class is part of the com.att.idp.idgraphusermanagementms.queue.message.helpers package.
 * It is a helper class that assists in sending messages to the message queue when a user's name is changed.
 * The class has several methods including sendMessageToMQ, prepareDbusInput, prepareEDDNotifyData, and callMSDBUS.
 * sendMessageToMQ is responsible for sending the message to the queue and handling the response.
 * prepareDbusInput is responsible for preparing the input for the DBUS.
 * prepareEDDNotifyData is responsible for preparing the data for EDD notification.
 * callMSDBUS is responsible for calling the MSDBUS.
 * The class also has several fields including a logger, an instance of JMSQueueSender, and various constants.
 */
@Component
public class ChangeUserNameQueueHelper {

	public static final Logger logger = LoggerFactory.getLogger(ChangeUserNameQueueHelper.class);
	private String sClassName = "ChangeUserNameQueueHelper";

	@Value("${SLID_CPNI_SERVICES}")
	private String propSlidCPNIServices;

    @Autowired
    PublishMqAehHelper publishMqAehHelper;

    @Autowired
    FeatureManagerHelper featureManager;

	/**
	 * This method is part of the ChangeUserNameQueueHelper class.
	 * It is responsible for sending a message to the message queue when a user's name is changed.
	 * The method takes two HashMaps as input, which contain the new user information and the old user information.
	 * It prepares the DBUS input, sends the EDD notification, and sends the request to MSDBUS.
	 * If the response from the MSDBUS is empty or unsuccessful, the method returns an error.
	 * If the response is successful, the method returns a success message.
	 *
	 * @param hmInput The HashMap containing the new user information.
	 * @param hmOldUserMemberInfo The HashMap containing the old user information.
	 * @return A HashMap containing the response from the MSDBUS.
	 * @throws Exception If there is an error during the process.
	 */
	public Map<String, Object> sendMessageToMQ(Map<String, Object> hmInput, Map<String, Object> hmOldUserMemberInfo) throws Exception {
		String sMethodName = ".sendMessageToMQ.";
		String stAppInfo;
		String stAppStatusCode = null;
		String sOldUserSlidMemberNum = null;
		String sOldUserMemberNum = null;
		String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
		Map<String, Object> hmResult = null;

		if (hmOldUserMemberInfo.containsKey(MPSDefs.DB_SLID_MEMBER_NUM))
			sOldUserSlidMemberNum = (String) hmOldUserMemberInfo.get(MPSDefs.DB_SLID_MEMBER_NUM);
		if (hmOldUserMemberInfo.containsKey(MPSDefs.DB_MEMBER_NUM))
			sOldUserMemberNum = (String) hmOldUserMemberInfo.get(MPSDefs.DB_MEMBER_NUM);
		// preparing DBUSInput to update tGuard
		// Sets Event data from the hmInput
		HashMap<String, Object> hmEventData = prepareDbusInput(hmInput, hmOldUserMemberInfo,
				CommonDefs.KEY_CGATE_CHANGE_SLID);

        ArrayList<Map<String, Object>> alEventData = CommonUtil.getArrayList();

		logger.info("{}{}CUNQH_01 : Request to Dbus for tGuard = {}", sClassName, sMethodName,
				HtmlUtils.htmlEscape(String.valueOf(hmEventData)));
		alEventData.add(hmEventData);
		boolean bSuppressNotification = false;

		if (!StringUtils.isEmpty((String) hmInput.get(CommonDefs.SUPPRESS_NOTIFICATION))
				&& ((String) hmInput.get(CommonDefs.SUPPRESS_NOTIFICATION)).equalsIgnoreCase(CommonDefs.IND_Y)) {
			bSuppressNotification = true;
		}
		// preparing DBUSInput to send EDD Notification for ChangeSLID, for all other
		// callers apart from DATAMGT
		if (!sCallingSystemId.equalsIgnoreCase(CommonDefs.DATAMGT) && !bSuppressNotification) {
			hmEventData = prepareDbusInput(hmInput, hmOldUserMemberInfo, CommonDefs.KEY_EDD_NOTIFY);
			logger.info("{}{}CUNQH_02 : Request to Dbus for EDD = {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(hmEventData)));
			alEventData.add(hmEventData);
		}
		// change by pm675e:SID#2021700157 [R2110] tgaurd timming issue
		if (sOldUserSlidMemberNum != null) {
			hmInput.put(CommonDefs.MAIN_HASH_KEY, sOldUserSlidMemberNum);
		} else {
			hmInput.put(CommonDefs.MAIN_HASH_KEY, sOldUserMemberNum);
		}
		// call to send request to MSDBUS
		hmResult = callMSDBUS(hmInput, alEventData);

		if (MapUtils.isEmpty(hmResult)) {
			stAppInfo = "Null Response returned from JMSQueueSender.send";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			logger.info("{}{}CUNQH_05 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
		if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {

			stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
			logger.info("{}{}CUNQH_06 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
			hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
			return hmResult;
		}

		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}

	private HashMap<String, Object> prepareDbusInput(Map<String, Object> hmReq, Map<String, Object> hmMemberInfo,
			String stDestination) throws Exception 
	{
		String sTransactionId = (String)hmReq.get("dbusTransactionId");
		String sTransactionName = (String) hmReq.get(CommonDefs.TRANSACTION_NAME);
		String sCallingSystemId = (String) hmReq.get(CommonDefs.CALLING_SYSTEM_ID);
		String sNewUserName = (String) hmReq.get(CommonDefs.NEW_USERNAME);
		HashMap<String, Object> hmResp = CommonUtil.getHashMap();
		HashMap<String, Object> hmOldUserSlidInfo = (HashMap) hmMemberInfo.get(MPSDefs.KEY_SLID_INFO);

		hmResp.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
		if (sTransactionName.equals("ChangeUserName"))
			hmResp.put(CommonDefs.TRANSACTION_NAME, "ChangeSLID");
		hmResp.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
		hmResp.put(CommonDefs.TRANSID, sTransactionId);
		hmResp.put(CommonDefs.ORIG_TRANSID, sTransactionId);
		hmResp.put(CommonDefs.HANDLE, sNewUserName);
		hmResp.put(CommonDefs.DOMAIN, CommonDefs.SLID_DUM);

		// for tGuard UpdateUser Request
		if (stDestination != null && stDestination.equals(CommonDefs.KEY_CGATE_CHANGE_SLID)) {
			hmResp.put(CommonDefs.EVENTNAME, "UpdateMember");
			hmResp.put(CommonDefs.SUBEVENT, CommonDefs.SUBEVENT_UPDATECGATEONLY);
			hmResp.put(CommonDefs.PARENT_HANDLE, sNewUserName);
			hmResp.put(CommonDefs.PARENT_DOMAIN, CommonDefs.SLID_DUM);
			hmResp.put(CommonDefs.DB_MEMBER_NUM, hmOldUserSlidInfo.get(MPSDefs.DB_MEMBER_NUM));
			hmResp.put(MPSDefs.DB_SLID_MEMBER_NUM, hmOldUserSlidInfo.get(MPSDefs.DB_SLID_MEMBER_NUM));
			// SPTAUTHREG-34977: Send activation flags when autogenerated accessId is activated during changeUserName
			String sAutoGenInd = (String) hmMemberInfo.get(MPSDefs.DB_AUTOGENERATED_IND);
			if (sAutoGenInd != null && sAutoGenInd.trim().equalsIgnoreCase(MPSDefs.YES)) {
				hmResp.put("tosFlag", CommonDefs.IND_N);
				hmResp.put(CommonDefs.ACTIVATED_IND, CommonDefs.IND_Y);
			}
		}
		// for EDD ChangeSLID Notification
		else if (stDestination != null && stDestination.equals(CommonDefs.KEY_EDD_NOTIFY)) {
			hmResp = prepareEDDNotifyData(hmReq, hmMemberInfo, hmResp);
		}

		return hmResp;
	}

	private HashMap<String, Object> prepareEDDNotifyData(Map<String, Object> hmReq, Map<String, Object> hmMemberInfo,
			HashMap<String, Object> hmResp) {
		String sAppInfo = null;
		String sOldUserName = (String) hmReq.get(CommonDefs.OLD_USERNAME);
		String sNewUserName = (String) hmReq.get(CommonDefs.NEW_USERNAME);
		String sFQNNewUserName = new StringBuffer(sNewUserName).append("@").append(CommonDefs.SLID_DUM).toString();
		String sFQNOldUserName = new StringBuffer(sOldUserName).append("@").append(CommonDefs.SLID_DUM).toString();

		HashMap<String, Object> hmOldUserSlidInfo = (HashMap) hmMemberInfo.get(MPSDefs.KEY_SLID_INFO);

		hmResp.put(CommonDefs.EVENTNAME, CommonDefs.PROP_EDD_NOTIFICATION_EVENT);
		hmResp.put(CommonDefs.SUBEVENT, CommonDefs.KEY_SLID);
		hmResp.put(CommonDefs.SOR_NAME, hmOldUserSlidInfo.get(MPSDefs.DB_SOR_NAME));
		hmResp.put(CommonDefs.DB_PARENT_CHILD_IND, hmOldUserSlidInfo.get(MPSDefs.DB_PARENT_CHILD_IND));
		hmResp.put(CommonDefs.FIRST_NAME, hmOldUserSlidInfo.get(MPSDefs.DB_LC_FIRSTNAME));
		hmResp.put(CommonDefs.LAST_NAME, hmOldUserSlidInfo.get(MPSDefs.DB_LC_LASTNAME));
		if (hmOldUserSlidInfo.containsKey(MPSDefs.DB_ACCOUNT_TYPE))
			hmResp.put(CommonDefs.CUSTOMER_TYPE, hmOldUserSlidInfo.get(MPSDefs.DB_ACCOUNT_TYPE));
		if (hmOldUserSlidInfo.containsKey(MPSDefs.DB_ACTIVATED_IND)
				&& hmOldUserSlidInfo.get(MPSDefs.DB_ACTIVATED_IND) != null
				&& hmOldUserSlidInfo.get(MPSDefs.DB_ACTIVATED_IND).toString().trim().length() > 0)
			hmResp.put(CommonDefs.ACTIVATED_IND, hmOldUserSlidInfo.get(MPSDefs.DB_ACTIVATED_IND));
		// SPTAUTHREG-34977: Override activation flags when autogenerated accessId is activated during changeUserName
		String sAutoGenInd = (String) hmMemberInfo.get(MPSDefs.DB_AUTOGENERATED_IND);
		if (sAutoGenInd != null && sAutoGenInd.trim().equalsIgnoreCase(MPSDefs.YES)) {
			hmResp.put("tosFlag", CommonDefs.IND_N);
			hmResp.put(CommonDefs.ACTIVATED_IND, CommonDefs.IND_Y);
		}

		// code taken from old changeSLID
		String sDefaultAccountSORInvID = null;
		String sDefaultAccountSOR = null;
		String sDefaultAccountType = null;
		String sFirstSORInvariantId = null;
		String sFirstAccountSOR = null;
		String sFirstAccountType = null;

		boolean isDefaultAccountFound = false;
		int i = 0;

		HashMap<String, Object> hmAccountsInDB = (HashMap<String, Object>) hmMemberInfo.get(MPSDefs.SERVICES);
		if (!MapUtils.isEmpty(hmAccountsInDB)) {
			// Retrieve SLID_CPNI_SERVICES=ECOMM|MOBILITY|TITAN|DLIFE from Config-File.
			ArrayList<String> alSLIDAccounts = CommonUtil.parseToArray(propSlidCPNIServices,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			if (alSLIDAccounts == null || alSLIDAccounts.isEmpty()) {
				sAppInfo = "Parsing into ArrayList for " + CommonDefs.PROP_SLID_CPNI_SERVICES + " Failed.";
				hmResp = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				return hmResp;
			}

			Iterator itSLIDAccounts = alSLIDAccounts.iterator();
			while (itSLIDAccounts.hasNext()) {
				String sCurrentAccountValue = (String) itSLIDAccounts.next();
				sCurrentAccountValue = (sCurrentAccountValue == null) ? "" : sCurrentAccountValue;
				HashMap<String, Object> hmCurrentAccountDB = (HashMap<String, Object>) hmAccountsInDB
						.get(sCurrentAccountValue);

				// If the current Account-Type is NOT found for the <oldSLID>, continue to check
				// for other Account-Types.
				if (MapUtils.isEmpty(hmCurrentAccountDB))
					continue;

				Iterator itAcctDBKeys = hmCurrentAccountDB.keySet().iterator();
				while (itAcctDBKeys.hasNext()) {
					Object key = itAcctDBKeys.next();
					Object value = null;
					if (key != null)
						value = hmCurrentAccountDB.get(key);
					if (value instanceof HashMap) {
						HashMap<String, Object> hmAccountInstance = (HashMap<String, Object>) value;
						String sDefaultAccountInd = (String) hmAccountInstance.get(MPSDefs.DB_DEFAULT_ACCOUNT);
						if (sDefaultAccountInd != null && sDefaultAccountInd.equals(MPSDefs.YES)) {
							sDefaultAccountSORInvID = (String) hmAccountInstance.get(MPSDefs.DB_SOR_INVARIANT_ID);
							sDefaultAccountSOR = (String) hmAccountInstance.get(MPSDefs.DB_SOR_NAME);
							sDefaultAccountType = sCurrentAccountValue;
							isDefaultAccountFound = true;
							break;
						}

						if (i == 0) {
							sFirstSORInvariantId = (String) hmAccountInstance.get(MPSDefs.DB_SOR_INVARIANT_ID);
							sFirstAccountSOR = (String) hmAccountInstance.get(MPSDefs.DB_SOR_NAME);
							sFirstAccountType = sCurrentAccountValue;
							i++;
						}
					}
				}
			}
		}
		// If Default-Account is still NOT found and some linkedUsers are available for
		// oldSLID:
		// Iterate over the services of LinkedUsers to check for a UVERSE
		// 'Default-Account'.
		if (!isDefaultAccountFound) {
			ArrayList<HashMap<String, Object>> alLinkedUsers = null;
			alLinkedUsers = (ArrayList) hmOldUserSlidInfo.get(MPSDefs.KEY_LINKED_USERS);
			if (alLinkedUsers != null && !alLinkedUsers.isEmpty()) {
				Iterator<HashMap<String, Object>> itLinkedUsers = alLinkedUsers.iterator();

				LULoop: while (itLinkedUsers.hasNext()) {
					HashMap<String, Object> hmCurrentLinkedUser = (HashMap<String, Object>) itLinkedUsers.next();
					if (hmCurrentLinkedUser != null && !hmCurrentLinkedUser.isEmpty()) {
						HashMap<String, Object> hmCurrentLUServices = (HashMap<String, Object>) hmCurrentLinkedUser
								.get(MPSDefs.SERVICES);

						if (hmCurrentLUServices != null && !hmCurrentLUServices.isEmpty()) {
							HashMap<String, Object> hmCurrentLUuVerseAccount = (HashMap<String, Object>) hmCurrentLUServices
									.get(MPSDefs.UVERSE_SERVICE);

							if (hmCurrentLUuVerseAccount != null && !hmCurrentLUuVerseAccount.isEmpty()) {
								Iterator itUVerseAccountKeys = hmCurrentLUuVerseAccount.keySet().iterator();

								LUUVerseLoop: while (itUVerseAccountKeys.hasNext()) {
									Object key = itUVerseAccountKeys.next();
									Object value = null;
									if (key != null)
										value = hmCurrentLUuVerseAccount.get(key);
									if (value instanceof HashMap) {
										HashMap<String, Object> hmUVerseAccountInstance = (HashMap<String, Object>) value;
										String sDefaultAccountInd = (String) hmUVerseAccountInstance
												.get(MPSDefs.DB_DEFAULT_ACCOUNT);
										if (sDefaultAccountInd != null && sDefaultAccountInd.equals(MPSDefs.YES)) {
											sDefaultAccountSORInvID = (String) hmUVerseAccountInstance
													.get(MPSDefs.DB_SOR_INVARIANT_ID);
											sDefaultAccountSOR = (String) hmUVerseAccountInstance
													.get(MPSDefs.DB_SOR_NAME);
											sDefaultAccountType = CommonDefs.UVERSE_SERVICE;
											isDefaultAccountFound = true;
											break LULoop;
										}

										if (i == 0) {
											sFirstSORInvariantId = (String) hmUVerseAccountInstance
													.get(MPSDefs.DB_SOR_INVARIANT_ID);
											sFirstAccountSOR = (String) hmUVerseAccountInstance
													.get(MPSDefs.DB_SOR_NAME);
											sFirstAccountType = CommonDefs.UVERSE_SERVICE;
											i++;
										}
									}
								}
							}
						}
					}
				}
			}
		}

		// If no Default Account is found still, get the details from 1st available
		// Account for oldSLID.
		if (!isDefaultAccountFound) {
			sDefaultAccountSORInvID = sFirstSORInvariantId;
			sDefaultAccountSOR = sFirstAccountSOR;
			sDefaultAccountType = sFirstAccountType;
		}

		if (sDefaultAccountSORInvID != null && !sDefaultAccountSORInvID.isEmpty())
			hmResp.put(CommonDefs.SOR_INVARIANT_ID, sDefaultAccountSORInvID);
		if (sDefaultAccountSOR != null && !sDefaultAccountSOR.isEmpty())
			hmResp.put(CommonDefs.ACCOUNT_SOR, sDefaultAccountSOR);
		if (sDefaultAccountType != null && !sDefaultAccountType.isEmpty())
			hmResp.put(CommonDefs.SERVICE_TYPE, sDefaultAccountType);

		String sSLIDContactEmail = (String) hmOldUserSlidInfo.get(MPSDefs.DB_CONTACT_EMAIL);
		if (sSLIDContactEmail != null && sSLIDContactEmail.trim().length() > 0) {

			HashMap<String, Object> hmMemberContactEmail = CommonUtil.getHashMap();
			hmMemberContactEmail.put(CommonDefs.CONTACT_EMAIL, sSLIDContactEmail);
			hmMemberContactEmail.put(CommonDefs.CONTACT_EMAIL_STATUS,
					hmOldUserSlidInfo.get(MPSDefs.DB_CONTACT_EMAIL_STATUS));

			ArrayList alMemberContactEmail = CommonUtil.getArrayList();
			alMemberContactEmail.add(hmMemberContactEmail);

			HashMap<String, Object> hmNotificationData = CommonUtil.getHashMap();
			hmNotificationData.put(CommonDefs.MEMBER_CONTACT_EMAIL, alMemberContactEmail);
			hmNotificationData.put(CommonDefs.OLD_SLID, sFQNOldUserName);
			hmNotificationData.put(CommonDefs.NEW_SLID, sFQNNewUserName);

			ArrayList alNotificationData = CommonUtil.getArrayList();
			alNotificationData.add(hmNotificationData);

			hmResp.put(CommonDefs.NOTIFICATION_DATA, alNotificationData);
		}
		// end
		
		if (StringUtils.isNotEmpty((String)hmOldUserSlidInfo.get(MPSDefs.DB_LC_FIRSTNAME)) && StringUtils.isNotEmpty(((String)hmOldUserSlidInfo.get(MPSDefs.DB_LC_FIRSTNAME)).trim()))	
			hmResp.put(CommonDefs.FIRST_NAME, hmOldUserSlidInfo.get(MPSDefs.DB_LC_FIRSTNAME));
				
		if (StringUtils.isNotEmpty((String)hmOldUserSlidInfo.get(MPSDefs.DB_LC_LASTNAME)) && StringUtils.isNotEmpty(((String)hmOldUserSlidInfo.get(MPSDefs.DB_LC_LASTNAME)).trim()))	
			hmResp.put(CommonDefs.LAST_NAME, hmOldUserSlidInfo.get(MPSDefs.DB_LC_LASTNAME));

		return hmResp;
	}

	/**
	 * This method is part of the ChangeUserNameQueueHelper class.
	 * It is responsible for sending a request to the MSDBUS.
	 * The method takes a HashMap and an ArrayList as input.
	 * The HashMap contains the request details and the ArrayList contains the event data.
	 * The method uses the PublishMqAehHelper  instance to send the request and handles the response.
	 * If the response from the PublishMqAehHelper  is empty or unsuccessful, the method returns an error.
	 * If the response is successful, the method returns a success message.
	 *
	 * @param hmInput The HashMap containing the request details.
	 * @param alEventData The ArrayList containing the event data.
	 * @return A HashMap containing the response from the PublishMqAehHelper .
	 */
	public Map<String, Object> callMSDBUS(Map<String, Object> hmInput, ArrayList<Map<String, Object>> alEventData){
		Map<String, Object> hmResult = null;
		String sMethodName = ".callMSDBUS.";
		HashMap<String, Object> hmDbusInput = CommonUtil.getHashMap();
		hmDbusInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
		hmDbusInput.put(CommonDefs.TRANSACTION_ID, hmInput.get("dbusTransactionId"));
		hmDbusInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
		hmDbusInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
		hmDbusInput.put(CommonDefs.EVENTNAME, CommonDefs.MICRO_SERVICE_EVENT);
		hmDbusInput.put(CommonDefs.MS_OPERTAION, hmInput.get(CommonDefs.TRANSACTION_NAME));
		hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, hmInput.get(CommonDefs.MAIN_HASH_KEY));
		if (hmInput.containsKey(CommonDefs.SOURCE_IP_ADDRESS))
			hmDbusInput.put(CommonDefs.SOURCE_IP_ADDRESS, hmInput.get(CommonDefs.SOURCE_IP_ADDRESS));

		hmDbusInput.put(CommonDefs.EVENTS_DATA, alEventData);

		logger.info("{}{}CUNQH_03 : Calling JMSQueueSender.send():: {}", sClassName, sMethodName,
				HtmlUtils.htmlEscape(String.valueOf(hmDbusInput)));

        //mq aeh switch
        String changeUserNameMQAEHEnabled = featureManager.getValue("cfg-idgraph-changeusername-mq-aeh-switch");
        changeUserNameMQAEHEnabled = (changeUserNameMQAEHEnabled != null && !changeUserNameMQAEHEnabled.isEmpty()) ? changeUserNameMQAEHEnabled : "MQ";
        logger.info("ixp flag changeUserNameMQAEHEnabled MQ AEH Value: {}", ESAPI.encoder().encodeForHTML(changeUserNameMQAEHEnabled));

        //clm switch
        String changeUserNameClmEnabled = featureManager.getValue("cfg-idgraph-changeusername-notification-clm-switch");
        changeUserNameClmEnabled = (changeUserNameClmEnabled != null && !changeUserNameClmEnabled.isEmpty()) ? changeUserNameClmEnabled : "MQ";
        logger.info("ixp flag changeUserNameClmEnabled CLM Value: {}", ESAPI.encoder().encodeForHTML(changeUserNameClmEnabled));

        hmResult = publishMqAehHelper.invokeMqAEH(hmDbusInput, hmInput, alEventData, sClassName, sMethodName, changeUserNameMQAEHEnabled, changeUserNameClmEnabled);
        return hmResult;
	}
}
