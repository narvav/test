package com.att.idp.idgraphusermanagementms.helper;

import com.att.idp.idgraph.db.oracle.helper.QueryMemberIdInfoDbHelper;
import com.att.idp.idgraphusermanagementms.db.helper.GetMemberServicesDBHelper;
import com.att.idp.idgraphusermanagementms.queue.message.helpers.RemoveEmailAliasQueueHelper;
import com.att.idp.idgraphusermanagementms.resource.request.EmailAliases;
import com.att.idp.idgraphusermanagementms.resource.request.RemoveEmailAliasRequest;
import com.att.idp.idgraphusermanagementms.resource.response.CommonResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class RemoveEmailAliasHelper {

    private static final String CLASS_NAME = "RemoveEmailAliasHelper";

    public static final Logger logger = LoggerFactory.getLogger(RemoveEmailAliasHelper.class);

    @Autowired
    private QueryMemberIdInfoDbHelper queryMemberIdInfoDbHelper;
    @Autowired
    private GetMemberServicesDBHelper getMemberServicesDBHelper;
    @Autowired
    private RemoveEmailAliasQueueHelper removeEmailAliasQueueHelper;

    /**
     * Removes an email alias for a user. Validates the request, checks member information, validates email aliases, removes them from the database, and sends a message to the queue.
     * @param removeEmailAliasRequest the request object containing details for removing the email alias
     * @return CommonResponse with the result of the operation or error details if the request is invalid
     */
    public CommonResponse removeEmailAlias(RemoveEmailAliasRequest removeEmailAliasRequest) {
        String sMethodName = ".removeEmailAlias.";
        Map<String, Object> hmResponse;

        logger.info("{}{}HLP000 :: Input:{}", CLASS_NAME, sMethodName, removeEmailAliasRequest);


        //check data
        Map<String, Object> memberInfoHash = getMPSInfo(removeEmailAliasRequest);
        String stAppStatusCode = (String) memberInfoHash.get(CommonDefs.COMMON_APP_STATUS_CODE);

        if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
            logger.info("{}{}REAH_03 :getMPSInfo returned error: {}",
                    CLASS_NAME, sMethodName, memberInfoHash);
            return CommonUtilHelper.generateCommonResponse(memberInfoHash);
        }

        // validate Email aliases

        hmResponse = validateEmailAliases(removeEmailAliasRequest, memberInfoHash);
        stAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);

        if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
            logger.info("{}{}REAH_07 :validateEmailAliases returned error: {}",
                    CLASS_NAME, sMethodName, hmResponse);
            return CommonUtilHelper.generateCommonResponse(hmResponse);
        } else if (hmResponse.get("isEmailAliasNotLinked") != null && (Boolean) hmResponse.get("isEmailAliasNotLinked")) {
            // if email alias not linked to memberId, return success
            hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
            return CommonUtilHelper.generateCommonResponse(hmResponse);
        }

        //remove email aliases from database
        List<Map<String, Object>> alRemoveEmailAlias = (List<Map<String, Object>>) hmResponse.get("emailAliases");
        hmResponse = removeEmailAliasFromDb(alRemoveEmailAlias);
        stAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);

        if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
            logger.info("{}{}REAH_08 :removeEmailAliasFromDb returned error: {}",
                    CLASS_NAME, sMethodName, hmResponse);
            return CommonUtilHelper.generateCommonResponse(hmResponse);
        }

        // call dbus to remove email aliases
        List<Object> alDbusEventData = new ArrayList<>();
        alDbusEventData = removeEmailAliasQueueHelper.prepareDbusInputHash(removeEmailAliasRequest, alRemoveEmailAlias, memberInfoHash);

        Map<String, Object> hmDbusResult = removeEmailAliasQueueHelper.sendMessageToMQ(removeEmailAliasRequest, alDbusEventData, memberInfoHash.get(MPSDefs.DB_MEMBER_NUM).toString());
        logger.info("{}{}REAH_09 :Response from removeEmailAliasQueueHelper.sendMessageToMQ: {}", CLASS_NAME, sMethodName,
                hmDbusResult);

        if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmDbusResult)) {
            hmResponse = CommonUtilHelper.sysErrorHashMap("null response from removeEmailAliasQueueHelper.sendMessageToMQ");
            return CommonUtilHelper.generateCommonResponse(hmResponse);
        } else {
            stAppStatusCode = (String) hmDbusResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
            if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
                String stAppInfo = (String) hmDbusResult.get(CommonDefs.COMMON_APP_INFO);
                logger.info("{}{}REAH_10 : {}", CLASS_NAME, sMethodName,
                        stAppInfo);
                hmResponse = hmDbusResult;
                return CommonUtilHelper.generateCommonResponse(hmResponse);
            }

        }
        hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
        return CommonUtilHelper.generateCommonResponse(hmResponse);
    }

    /**
     * Removes email aliases from the database for the given list.
     * @param alRemoveEmailAlias list of email alias maps to remove
     * @return a map containing the result of the database operation
     */
    private Map<String, Object> removeEmailAliasFromDb(List<Map<String, Object>> alRemoveEmailAlias) {
        String sMethodName = ".removeEmailAliasFromDb.";
        logger.info("{}{}VPH_11 :Removing Email Aliases from DB: {}",
                CLASS_NAME, sMethodName, alRemoveEmailAlias);

        Map<String, Object> hmResponse = queryMemberIdInfoDbHelper.removeEmailAliases(alRemoveEmailAlias);
        String stAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);

        if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
            logger.error("{}{}VPH_12 :Error removing email aliases from DB: {}",
                    CLASS_NAME, sMethodName, hmResponse);
            return hmResponse;
        }

        logger.info("{}{}VPH_13 :Successfully removed email aliases from DB", CLASS_NAME, sMethodName);
        return CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
    }

    /**
     * Validates the email aliases in the request against the member information. Checks if the aliases exist and are linked to the member.
     * @param removeEmailAliasRequest the request object containing email aliases
     * @param memberInfoHash map containing member information and existing email aliases
     * @return a map with validation results and error details if validation fails
     */
    private Map<String, Object> validateEmailAliases(RemoveEmailAliasRequest removeEmailAliasRequest, Map<String, Object> memberInfoHash) {
        String sMethodName = ".validateEmailAliases.";
        logger.info("{}{}REAH_04 :Validating Email Aliases for request: {}",
                CLASS_NAME, sMethodName, removeEmailAliasRequest);

        List<Map<String, Object>> alExistingList = (List<Map<String, Object>>) memberInfoHash.get("emailAlias");

        if (alExistingList == null || alExistingList.isEmpty()) {
            String stAppInfo = "Email alias(es) does not belong to the member";
            logger.error("{}{}REAH_05 :{} ", CLASS_NAME, sMethodName, stAppInfo);
            return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
        }
        List<EmailAliases> alFromRequest = removeEmailAliasRequest.getEmailAliases();
        List<Map<String, Object>> alRemovalList = new ArrayList<>();

        for (EmailAliases emailAlias : alFromRequest) {
            Map<String, Object> existing = alExistingList.stream()
                    .filter(e -> emailAlias.getEmailAliasId().equalsIgnoreCase((String) e.get("email_aliasId")))
                    .findFirst()
                    .orElse(null);
            if (existing != null) {

                String existingDomain = (String) existing.get("email_aliasDomain");
                if (existingDomain == null || !emailAlias.getEmailAliasDomain().equalsIgnoreCase(existingDomain)) {
                    String stAppInfo = "Email alias domain does not match for aliasId: " + emailAlias.getEmailAliasId();
                    logger.error("{}{}REAH_05.1 :{} ", CLASS_NAME, sMethodName, stAppInfo);
                    return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                }

                Map<String, Object> removalMap = new HashMap<>();
                removalMap.put("email_aliasId", emailAlias.getEmailAliasId());
                removalMap.put("email_aliasDomain", emailAlias.getEmailAliasDomain());
                removalMap.put("email_aliasMemberNum", existing.get("email_aliasMemberNum"));
                alRemovalList.add(removalMap);
            }
        }

        if (alRemovalList.isEmpty()) {
            String stAppInfo = "Email Alias not linked to memberId, mapping it into success";
            logger.error("{}{}REAH_06 :{} ", CLASS_NAME, sMethodName, stAppInfo);
            HashMap hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                    CommonDefs.COMMON_SUCCESS_MSG);
            hmResult.put("isEmailAliasNotLinked", true);
            return hmResult;
        }
        HashMap<String, Object> hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
                CommonDefs.COMMON_SUCCESS_MSG);
        hmResult.put("emailAliases", alRemovalList);
        return hmResult;

    }

    /**
     * Retrieves member information and associated email aliases from the database.
     * @param removeEmailAliasRequest the request object containing memberId and domain
     * @return a map with member information and email aliases, or error details if retrieval fails
     */
    private Map<String, Object> getMPSInfo(RemoveEmailAliasRequest removeEmailAliasRequest) {
        String sMethodName = ".getMPSInfo.";
        String stMemberId = removeEmailAliasRequest.getMemberId();
        String stDomain = removeEmailAliasRequest.getDomain();
        HashMap<String, Object> hmDbInput = new HashMap<>();
        hmDbInput.put(MPSDefs.DB_MEMBER_NAME, stMemberId);
        hmDbInput.put(MPSDefs.DB_DOMAIN_NAME, stDomain);
        HashMap<String, Object> memberInfoHash = getMemberServicesDBHelper.getMemberServices(hmDbInput);
        logger.debug("{}{}REAH_01 :Response from GetMemberServicesDBHelper.getMemberServices() is: {}",
                CLASS_NAME, sMethodName, memberInfoHash);
        if (memberInfoHash == null || memberInfoHash.isEmpty()) {
            String stAppInfo = "null hashmap returned from GetMemberServicesDBHelper.getMemberServices";
            logger.error("{}{}REAH_02 :{} ",
                    CLASS_NAME, sMethodName, stAppInfo);
            return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
        }
        String sAppStatusCode = (String) memberInfoHash.get(CErrorDefs.COMMON_APP_STATUS_CODE);
        if (sAppStatusCode != null && !sAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
            if (sAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
                String stAppInfo = "User Not Found in DB";
                return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, stAppInfo);
            }
            return memberInfoHash;
        }

        Map<String, Object> hmEmailAliases = queryMemberIdInfoDbHelper.retrieveEmailAliasDetails(memberInfoHash.get(MPSDefs.DB_MEMBER_NUM).toString());
        if (hmEmailAliases == null || hmEmailAliases.isEmpty()) {
            String sAppInfo = "Response from queryMemberIdInfoDbHelper.retrieveEmailAliasDetails() is NULL or EMPTY";
            return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
        }
        sAppStatusCode = (String) hmEmailAliases.get(CErrorDefs.COMMON_APP_STATUS_CODE);
        if (!(CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode))) {
            return hmEmailAliases;
        }
        if (hmEmailAliases.get(CommonDefs.EMAIL_ALIASES) != null) {
            memberInfoHash.put("emailAlias", hmEmailAliases.get(CommonDefs.EMAIL_ALIASES));
        }

        return memberInfoHash;
    }
}
