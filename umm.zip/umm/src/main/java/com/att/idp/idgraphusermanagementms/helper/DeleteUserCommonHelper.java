package com.att.idp.idgraphusermanagementms.helper;

import com.att.idp.idgraph.db.oracle.helper.GroupInfoDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.DeleteMemberDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.MemberDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.MergeYahooIDDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.RolesDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.UpdateDBHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;

/**
 * Helper component that orchestrates common delete-user flows across multiple
 * database helper classes.
 * <p>
 * This class coordinates the deletion of parent, child and SLID accounts,
 * associated email aliases, roles and SLID identifiers based on a consolidated
 * input map. It encapsulates the high-level business rules for determining the
 * account type (parent/child/SLID), invoking the appropriate helper
 * interactions and normalizing the result into the {@link CommonErrorMap}
 * format.
 */
@Component
public class DeleteUserCommonHelper {

    public static final Logger logger = LoggerFactory.getLogger(DeleteUserCommonHelper.class);
    private static final String CLASS_NAME = "DeleteUserCommonHelper";

    @Autowired
    private DeleteMemberDBHelper deleteUserDBHelper;

    @Autowired
    private MergeYahooIDDBHelper mergeYahooIDDBHelper;

    @Autowired
    private RolesDBHelper rolesDBHelper;

    @Autowired
    private MemberDBHelper memberDBHelper;

    @Autowired
    private UpdateDBHelper updateDBHelper;

    @Autowired
    private GroupInfoDBHelper groupInfoDBHelper;

    /**
     * Deletes a user and its related records based on the provided input map.
     * <p>
     * The method interprets the input to determine whether the request targets a
     * parent, child or SLID account (using group number, member number or
     * user-id/domain). It then:
     * <ul>
     *     <li>Validates mandatory fields such as lastUpdatedBy.</li>
     *     <li>Determines account type via {@link #determineAccountType(boolean, boolean, boolean, String)}.</li>
     *     <li>Deletes child accounts and their email aliases when applicable.</li>
     *     <li>Deletes parent/group accounts using {@link #handleParentAccount(String)}.</li>
     *     <li>Deletes SLID accounts and performs Yahoo merge-table maintenance via handleSlidAccount</li>
     *     <li>Optionally updates role IDs when {@link CommonDefs#KEY_UPDATE_ROLE_ID} is present.</li>
     *     <li>Handles SLID-with-member deletion and SLID IDs cleanup.</li>
     * </ul>
     * On success, a standard success category map is returned; otherwise the first
     * error encountered is propagated.
     *
     * @param hmInput consolidated request parameters including group/member
     *                identifiers, user id/domain, updatedBy, transaction details
     *                and various deletion flags
     * @return a result map in {@link CommonErrorMap} format representing success or
     * the specific failure that occurred
     */
    public Map<String, Object> deleteUser(HashMap hmInput) {

        String sMethodName = ".deleteUser.";
        Map<String, Object> hmResult = null;
        String sAppInfo = null;
        String sStatusCode = null;
        boolean isGroupNumExists = false;
        boolean isMemberNumExists = false;
        boolean isUserIdExists = false;
        boolean isParent = false;
        boolean isChild = false;
        boolean isSlid = false;
        boolean isError = false;

        String sGroupNum = getTrimmedValue(hmInput, MPSDefs.WS_GROUP_NUM);
        String stMemberNum = getTrimmedValue(hmInput, MPSDefs.WS_MEMBER_NUM);
        String sMemberName = getTrimmedValue(hmInput, MPSDefs.WS_USER_ID);
        String sDomainName = getTrimmedValue(hmInput, MPSDefs.WS_DOMAIN);

        String sParentChildInd = (String) hmInput.get(MPSDefs.DB_PARENT_CHILD_IND);
        String stLastModifiedBy = getTrimmedValue(hmInput, MPSDefs.WS_UPDATED_BY);
        String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
        String sTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);
        String sCallingSystemId = (String) hmInput.get(MPSDefs.WS_CALLING_SYSTEM_ID);

        if (isValidGroupNum(sGroupNum)) {
            isGroupNumExists = true;
        } else if (isValidMemberNum(stMemberNum)) {
            isMemberNumExists = true;
        } else if (isValidUserId(sMemberName, sDomainName)) {
            sMemberName = sMemberName.toLowerCase();
            sDomainName = sDomainName.toLowerCase();
            isUserIdExists = true;
        } else {
            logger.info("{}{}DUCH_DU.01 : Invalid data passed ", CLASS_NAME, sMethodName);
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
            return hmResult;
        }

        if (stLastModifiedBy == null || stLastModifiedBy.isEmpty()) {
            logger.info("{}{}DUCH_DU.02 : Required field missing : lastUpdatedBy ", CLASS_NAME, sMethodName);
            return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
        }

        try {

            // Determine account type
            boolean[] accountFlags = determineAccountType(isGroupNumExists, isMemberNumExists, isUserIdExists,
                    sParentChildInd);
            isParent = accountFlags[0];
            isChild = accountFlags[1];
            isSlid = accountFlags[2];

            if (isChild) {
                isError = !handleChildAccount(hmInput, stMemberNum);
            }

            if (isParent) {
                Map<String, Object> parentResult = handleParentAccount(sGroupNum);
                if (!isSuccess(parentResult)) {
                    return parentResult;
                }
                hmResult = parentResult;
            }

            if (isSlid) {
                Map<String, Object> slidResult = handleSlidAccount(hmInput, sGroupNum, sDomainName, sTransactionName,
                        sTransactionId, sCallingSystemId, sMemberName);
                if (!isSuccess(slidResult)) {
                    return slidResult;
                }
                hmResult = slidResult;
            }

            if (hmInput.containsKey(CommonDefs.KEY_UPDATE_ROLE_ID)) {
                hmResult = rolesDBHelper.updateRoleID(hmInput);
                if (!isSuccess(hmResult)) {
                    logger.info("{}{}DUCH_DU.15 : Error returned from rolesDBHelper.updateRoleID()", CLASS_NAME,
                            sMethodName);
                    return hmResult;
                }

            }

            hmResult = handleDeleteSLIDWithMember(hmInput, stLastModifiedBy, stMemberNum);
            if (hmResult != null && !isSuccess(hmResult)) {
                isError = true;
                return hmResult;
            }

            hmResult = handleDeleteSLIDIds(hmInput, stLastModifiedBy);
            if (hmResult != null && !isSuccess(hmResult)) {
                isError = true;
                return hmResult;
            }

        } catch (Exception e) {
            isError = true;
            hmResult = CommonErrorMap.makeExceptionMap(e);

        } finally {
            if (!isError) {
                hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.MPS_SUCCESS_NUM, "Member Deleted Successfully");
            }
        }

        return hmResult;

    }

    private Map<String, Object> callGetGroupInfo(String groupNum) {
        String methodName = ".callGetGroupInfo.";
        Map<String, Object> result = new HashMap<>();

        String safeGroupNum = CommonUtilHelper.sanitizeForLog(groupNum);
        logger.info("{}{}DUCH_CGGI.01 : Calling GroupInfoDBHelper.getGroupInfo() with group_num {}", CLASS_NAME,
                methodName, safeGroupNum);
        result = groupInfoDBHelper.getGroupInfo(groupNum);
        logger.info("{}{}DUCH_CGGI.02 : Response from GroupInfoDBHelper.getGroupInfo() {}", CLASS_NAME, methodName,
                CommonUtilHelper.sanitizeForLog(result.toString()));

        if (result == null) {
            logger.info("{}{}DUCH_CGGI.03 : {}", CLASS_NAME, methodName,
                    "GroupInfoDBHelper.getGroupInfo() is null");
            result = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, "GroupInfoDBHelper.getGroupInfo() is null");
        }

        return result;
    }

    private boolean deleteEmailAliases(List<String> emailAliases) {
        String methodName = ".deleteEmailAliases.";
        Map<String, Object> emailAliasMap = new HashMap<>();
        if (emailAliases == null || emailAliases.isEmpty()) {
            return true;
        }
        for (String aliasMemberNum : emailAliases) {
            if (aliasMemberNum != null) {
                emailAliasMap.put(MPSDefs.DB_MEMBER_NUM, aliasMemberNum);
                Map<String, Object> result = deleteUserDBHelper.deleteMember(new HashMap<>(emailAliasMap));
                String statusCode = (String) result.get(MPSDefs.APP_STATUS_CODE);
                if (!MPSDefs.MPS_SUCCESS.equals(statusCode)
                        && !MPSDefs.REC_NOT_FOUND.equalsIgnoreCase(statusCode)) {
                    logger.info("{}{}DUCH_DEA.01 : Failed to Delete email alias:: member_num : {}", CLASS_NAME,
                            methodName, CommonUtilHelper.sanitizeForLog(aliasMemberNum));
                    return false;
                }
            }
        }
        return true;
    }

    private String getTrimmedValue(Map<String, Object> input, String key) {
        Object value = input.get(key);
        return value != null ? value.toString().trim() : null;
    }

    private boolean isValidGroupNum(String groupNum) {
        return groupNum != null && !groupNum.isEmpty();
    }

    private boolean isValidMemberNum(String memberNum) {
        return memberNum != null && !memberNum.isEmpty();
    }

    private boolean isValidUserId(String memberName, String domainName) {
        return memberName != null && !memberName.isEmpty() && domainName != null && !domainName.isEmpty();
    }

    private boolean isSuccess(Map<String, Object> response) {
        String statusCode = null;
        if (response != null) {
            statusCode = (String) response.get(CommonDefs.COMMON_APP_STATUS_CODE);
        }
        return CommonDefs.COMMON_SUCCESS.equals(statusCode);
    }

    private boolean[] determineAccountType(boolean isGroupNumExists, boolean isMemberNumExists, boolean isUserIdExists,
                                           String parentChildInd) {
        boolean isParent = false;
        boolean isChild = false;
        boolean isSlid = false;

        if (isGroupNumExists) {
            isParent = true;
        } else if (isMemberNumExists) {
            isChild = true;
        } else if (isUserIdExists) {
            if (MPSDefs.MPS_PARENT.equals(parentChildInd)) {
                isParent = true;
            } else if (MPSDefs.MPS_CHILD.equals(parentChildInd)) {
                isChild = true;
            } else if (MPSDefs.MPS_SLID.equals(parentChildInd)) {
                isSlid = true;
            }
        }
        return new boolean[]{isParent, isChild, isSlid};
    }

    private boolean handleChildAccount(Map<String, Object> input, String memberNum) {
        Map<String, Object> childAccMap = new HashMap<>();
        logger.info("{}{}.DUCH_DU.06 : Child Account", CLASS_NAME, ".deleteUser.");
        @SuppressWarnings("unchecked")
        ArrayList<String> emailAliases = (ArrayList<String>) input.get(MPSDefs.EMAIL_ALIASES);
        boolean isDeleteAliasSuccess = deleteEmailAliases(emailAliases);

        if (isDeleteAliasSuccess) {
            childAccMap.put(MPSDefs.DB_MEMBER_NUM, memberNum);
            Map<String, Object> result = deleteUserDBHelper.deleteMember(new HashMap<>(childAccMap));
            if (!isSuccess(result)) {
                logger.info("{}{}.DUCH_DU.06 : Failed to Delete email alias:: member_num : {}", CLASS_NAME,
                        ".deleteUser.", CommonUtilHelper.sanitizeForLog(memberNum));
                return false;
            }
        }
        return true;
    }

    private Map<String, Object> handleParentAccount(String groupNum) {
        logger.info("{}{}.DUCH_DU.06 : Parent Account", CLASS_NAME, ".deleteUser.");
        Map<String, Object> result = callGetGroupInfo(groupNum);
        if (!isSuccess(result)) {
            logger.info("{}{}.DUCH_DU.07 : Error occured when calling getGroupInfo", CLASS_NAME, ".deleteUser.");
            return result;
        }
        Map<String, Object> deleteGroupMap = new HashMap<>();
        deleteGroupMap.put(MPSDefs.DB_GROUP_NUM, groupNum);
        return deleteUserDBHelper.deleteGroup(new HashMap<>(deleteGroupMap));
    }

    private Map<String, Object> handleSlidAccount(Map<String, Object> input, String groupNum, String domainName,
                                                  String transactionName, String transactionId, String callingSystemId,
                                                  String memberName) {
        Map<String, Object> result = null;
        boolean isError = false;
        logger.info("{}{}.DUCH_DU.10 : SLID", CLASS_NAME, ".deleteUser.");
        if (MPSDefs.YES.equals(input.get("clearSlidFromLinkedIds"))) {
            Map<String, Object> clearSlidInput = new HashMap<>();
            clearSlidInput.put("clearSlidMemberNum", input.get("clearSlidMemberNum"));
            result = updateDBHelper.clearSlidMemberNum(new HashMap<>(clearSlidInput));
            if (!isSuccess(result)) {
                isError = true;
                logger.info("{}{}.DUCH_DU.11 : Failed to Clear slidMemberNum..", CLASS_NAME, ".deleteUser.");
            }
        }

        if (!isError) {
            Map<String, Object> slidInput = new HashMap<>();
            slidInput.put(MPSDefs.DB_GROUP_NUM, groupNum);

            logger.info("{}{}.DUCH_DU.12 : Call deleteGroup", CLASS_NAME, ".deleteUser.");
            result = deleteUserDBHelper.deleteGroup(new HashMap<>(slidInput));
            if (!isSuccess(result)) {
                isError = true;
            }

            if (memberName != null && memberName.indexOf("@") > 0) {
                Map<String, Object> mergedYahooId = new HashMap<>();
                String memNameDomain = memberName.substring(memberName.indexOf("@") + 1);
                if (memNameDomain.equalsIgnoreCase(CommonDefs.DOMAIN_YAHOO)) {
                    if (transactionName != null && !transactionName.isEmpty()) {
                        mergedYahooId.put(CommonDefs.TRANSACTION_NAME, transactionName);
                    }
                    if (transactionId != null && !transactionId.isEmpty()) {
                        mergedYahooId.put(CommonDefs.TRANSACTION_ID, transactionId);
                    }
                    if (callingSystemId != null && !callingSystemId.isEmpty()) {
                        mergedYahooId.put(CommonDefs.CALLING_SYSTEM_ID, callingSystemId);
                    }
                    mergedYahooId.put(CommonDefs.YAHOO_ID, memberName);

                    logger.info(
                            "{}{}.DUCH_DU.13 : Calling MergedYahooIdDBHelper.getMergedYahooId() with input {}",
                            CLASS_NAME, ".deleteUser.", CommonUtilHelper.sanitizeForLog(mergedYahooId.toString()));
                    result = mergeYahooIDDBHelper.getMergedYahooId(new HashMap<>(mergedYahooId));
                    logger.info("{}{}.DUCH_DU.14 : Response from MergedYahooIdDBHelper.getMergedYahooId()",
                            CLASS_NAME, ".deleteUser.");

                    String statusCode = result != null
                            ? (String) result.get(MPSDefs.APP_STATUS_CODE)
                            : null;
                    if (statusCode != null && !statusCode.equals(CommonDefs.COMMON_SUCCESS)
                            && !statusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND)) {
                        isError = true;
                        return result;
                    } else {
                        @SuppressWarnings("unchecked")
                        Map<String, Object> mergedYahooResp = (Map<String, Object>) result
                                .get(CommonDefs.MERGE_YAHOO_ID);
                        if (mergedYahooResp != null && !mergedYahooResp.isEmpty()) {
                            String status = (String) mergedYahooResp.get(MPSDefs.DB_STATUS);
                            String memberNum = (String) mergedYahooResp.get(MPSDefs.DB_MEMBER_NUM);
                            if (CommonDefs.MARK_DELETE.equals(status)) {
                                mergedYahooId.put(MPSDefs.DB_STATUS, CommonDefs.ACTIVE);
                                mergedYahooId.put(MPSDefs.DB_MEMBER_NUM, memberNum);
                                logger.info(
                                        "{}{}.DUCH_DU.13 : Calling MergedYahooIdDBHelper.updateMergedYahooId() with input {}",
                                        CLASS_NAME, ".deleteUser.", CommonUtilHelper.sanitizeForLog(mergedYahooId.toString()));
                                result = mergeYahooIDDBHelper.updateMergedYahooId(new HashMap<>(mergedYahooId));
                                logger.info(
                                        "{}{}.DUCH_DU.14 : Response from MergedYahooIdDBHelper.updateMergedYahooId()",
                                        CLASS_NAME, ".deleteUser.");
                                if (!isSuccess(result)) {
                                    isError = true;
                                    return result;
                                }
                            }
                        }
                    }
                }
            }
        }
        return result;
    }

    private Map<String, Object> handleDeleteSLIDWithMember(Map<String, Object> input, String lastModifiedBy,
                                                           String memberNum) {
        String slidDelete = (String) input.get("DeleteSLIDWithMember");
        if (slidDelete != null && slidDelete.equalsIgnoreCase(MPSDefs.YES)) {
            Map<String, Object> dbInput = new HashMap<>();
            dbInput.put(MPSDefs.DB_LAST_MODIFIED_BY, lastModifiedBy);
            dbInput.put(MPSDefs.DB_MEMBER_NUM, memberNum);
            dbInput.put(MPSDefs.DB_SLID_MEMBER_NUM, input.get(MPSDefs.WS_SLID_MEMBER_NUM));

            logger.info("{}{}.DUCH_DU.16 : Calling memberDBHelper.update() with input {}", CLASS_NAME, ".deleteUser.",
                    CommonUtilHelper.sanitizeForLog(String.valueOf(dbInput)));
            Map<String, Object> result = memberDBHelper.update(new HashMap<>(dbInput));
            logger.info("{}{}.DUCH_DU.17 : Response from memberDBHelper.update(): {}", CLASS_NAME, ".deleteUser.",
                    CommonUtilHelper.sanitizeForLog(String.valueOf(result)));

            if (!isSuccess(result)) {
                Map<String, Object> errorResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_DB_NUM,
                        "MemberDBHelper update call failed");
                logger.info("{}{}.DUCH_DU.17 : MemberDBHelper update call failed", CLASS_NAME, ".deleteUser.");
                return errorResult;
            }

            dbInput = new HashMap<>();
            dbInput.put(MPSDefs.DB_LAST_MODIFIED_BY, lastModifiedBy);
            dbInput.put(MPSDefs.DB_GROUP_NUM, input.get("slid_group_num"));

            result = deleteUserDBHelper.deleteGroup(new HashMap<>(dbInput));
            if (!isSuccess(result)) {
                return result;
            }
        }
        return null;
    }

    private Map<String, Object> handleDeleteSLIDIds(Map<String, Object> input, String lastModifiedBy) {
        @SuppressWarnings("unchecked")
        ArrayList<Map<String, Object>> slidIdsDelete = (ArrayList<Map<String, Object>>) input.get("DeleteSLIDIds");
        if (slidIdsDelete != null && !slidIdsDelete.isEmpty()) {
            for (Map<String, Object> slidDelete : slidIdsDelete) {
                Map<String, Object> dbInput = CommonUtil.getHashMap();
                dbInput.put(MPSDefs.DB_LAST_MODIFIED_BY, slidDelete.get(MPSDefs.WS_UPDATED_BY));
                dbInput.put(MPSDefs.DB_MEMBER_NUM, slidDelete.get(MPSDefs.WS_MEMBER_NUM));
                dbInput.put(MPSDefs.DB_SLID_MEMBER_NUM, slidDelete.get(MPSDefs.WS_SLID_MEMBER_NUM));

                logger.info("{}{}.DUCH_DU.16 : Calling memberDBHelper.update() with input {}", CLASS_NAME,
                        ".deleteUser.", CommonUtilHelper.sanitizeForLog(String.valueOf(dbInput)));
                Map<String, Object> result = memberDBHelper.update(new HashMap<>(dbInput));
                logger.info("{}{}.DUCH_DU.17 : Response from memberDBHelper.update(): {}", CLASS_NAME,
                        ".deleteUser.", CommonUtilHelper.sanitizeForLog(String.valueOf(result)));

                if (!isSuccess(result)) {
                    Map<String, Object> errorResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_DB_NUM,
                            "MemberDBHelper update call failed");
                    logger.info("{}{}.DUCH_DU.17 : MemberDBHelper update call failed", CLASS_NAME, ".deleteUser.");
                    return errorResult;
                }

                dbInput = CommonUtil.getHashMap();
                dbInput.put(MPSDefs.DB_LAST_MODIFIED_BY, lastModifiedBy);
                dbInput.put(MPSDefs.DB_GROUP_NUM, slidDelete.get("slid_group_num"));

                result = deleteUserDBHelper.deleteGroup(new HashMap<>(dbInput));
                if (!isSuccess(result)) {
                    return result;
                }
            }
        }
        return null;
    }

}
