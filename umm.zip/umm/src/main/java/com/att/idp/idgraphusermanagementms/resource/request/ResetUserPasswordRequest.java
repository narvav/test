package com.att.idp.idgraphusermanagementms.resource.request;


import com.att.mpsys.common.utils.CommonDefs;
import com.fasterxml.jackson.annotation.*;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;


import java.util.HashMap;import jakarta.validation.Valid;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.util.Map;

import static org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString;
import static org.apache.commons.lang3.builder.ToStringStyle.JSON_STYLE;

/**
 * This class represents a request to reset user password in the system.
 * It contains fields for various user details such as  handle (userId), domain, agentId, clearOnlineQA, id, sourceIPAddress, userLockLevel, suppressNotification, deliveryMethods, isExternalCall, and a map for unknownAttributes.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 *
 */
@Schema(name = "ResetUserPasswordRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ResetUserPasswordRequest {
    private final String transactionName = "ResetUserPassword";
    private String callingSystemId;

    @Schema(name = "userId")
    @Size(min=1, max=127,message="userId length is invalid|ResetUserPassword")
    @JsonProperty("userId")
    private String handle;

    @Size(min=1,max=30,message="domain length is invalid|ResetUserPassword") 
    protected String domain;

    @Schema(name = "agentId")
    @Size(min=1, max=20,message="agentId length is invalid|ResetUserPassword")
    private String agentId;

    @Schema(name = "isExternalCall")
    @Size(min=1,max=1,message="isExternalCall value can only be Y or N|ResetUserPassword")
    @Pattern(regexp = "^[YyNn]?$", message =  "isExternalCall must be Y or N.|ResetUserPassword")
    protected String isExternalCall;

    @Schema(name = "clearOnlineQA")
    @Size(min=1,max=1,message="clearOnlineQA value can only be Y or N|ResetUserPassword")
    @Pattern(regexp = "^[YyNn]?$", message =  "clearOnlineQA must be Y or N.|ResetUserPassword")
    protected String clearOnlineQA;

    @Schema(name = "userLockLevel")
    @Size(min=1,max=1,message="userLockLevel length is invalid|ResetUserPassword")
    protected String userLockLevel;

    @Schema(name = "suppressNotification")
    @Size(min=1,max=1,message="suppressNotification value can only be Y or N|ResetUserPassword")
    @Pattern(regexp = "^[YyNn]?$", message =  "SuppressNotification must be Y or N.|ResetUserPassword")
    protected String suppressNotification;

    @Valid
    @Schema(name = "deliveryMethods")
    protected DeliveryMethods deliveryMethods;

    @Schema(name = "idpTraceId")
    private String idpTraceId;
    /**
     * This field represents a map of unknown attributes.
     *
     * The unknownAttributes map is used to store any additional attributes that are not part of the attributeName and attributeValue fields.
     * It is initialized as a new HashMap.
     *
     * The field is annotated with @JsonAnySetter and @JsonAnyGetter, allowing it to be included in JSON serialization and deserialization.
     */
    @JsonAnySetter
    @JsonAnyGetter
    public Map<String,Object> unknownAttributes = new HashMap<>();

    @Override
    public String toString() {
        return reflectionToString(this, JSON_STYLE);
    }
}
