package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TMEMBERSERVICEROLE", schema = "MPS_OWNER", uniqueConstraints = @UniqueConstraint(columnNames = {
		"MEMBER_NUM", "SERVICE_ID", "SOR_ID", "SOR_INVARIANT_ID", "ROLE_ID" }))
public class Tmemberservicerole implements Serializable {

	private static final long serialVersionUID = -7470078942282242687L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "memberNum", column = @Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "serviceId", column = @Column(name = "SERVICE_ID", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "sorId", column = @Column(name = "SOR_ID", precision = 22, scale = 0)),
			@AttributeOverride(name = "sorInvariantId", column = @Column(name = "SOR_INVARIANT_ID")) })
	private TmemberserviceroleId id;

	@Column(name = "ROLE_ID", nullable = false, precision = 22, scale = 0)
	private Long roleId;

	@Column(name = "STATUS", nullable = false, precision = 22, scale = 0)
	private Long status;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "SERVICE_ID", referencedColumnName = "SERVICE_ID", nullable = false, insertable = false, updatable = false),
			@JoinColumn(name = "ROLE_ID", referencedColumnName = "ROLE_ID", nullable = false, insertable = false, updatable = false) })
	private Tservicerole tservicerole;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SOR_ID", insertable = false, updatable = false)
	private Tsystemofrecord tsystemofrecord;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "STATUS", nullable = false, insertable = false, updatable = false)
	private Tstatus tstatus;

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "tmemberservicerole")
	private Tmemberservice tmemberservice;
}