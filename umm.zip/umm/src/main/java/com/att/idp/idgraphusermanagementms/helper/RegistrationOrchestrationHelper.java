package com.att.idp.idgraphusermanagementms.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.db.helper.GetMemberServicesDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.UpdateDBHelper;
import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.UpdateUserHelper;
import com.att.idp.idgraphusermanagementms.integration.RegistrationOrchestrationRestClient;
import com.att.idp.idgraphusermanagementms.resource.request.AssociationItem;
import com.att.idp.idgraphusermanagementms.resource.request.MergeUserAccessIdRequest;
import com.att.idp.idgraphusermanagementms.resource.request.RegistrationOrchestrationRequest;
import com.att.idp.idgraphusermanagementms.resource.response.AssociationResult;
import com.att.idp.idgraphusermanagementms.resource.response.MergeUserAccessIdResponse;
import com.att.idp.idgraphusermanagementms.resource.response.RegistrationOrchestrationResponse;
import com.att.idp.idgraphusermanagementms.service.MergeUserAccessIdService;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.mpsys.common.helpers.FeatureManagerHelper;

import jakarta.ws.rs.core.MultivaluedHashMap;
import jakarta.ws.rs.core.MultivaluedMap;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This helper class is responsible for orchestrating the registration process.
 * It processes a list of associations in parallel, calling either mergeUserAccessId (Path A)
 * or addAssociation (Path B) for each item, and aggregates the results.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class RegistrationOrchestrationHelper {

    private static final Logger logger = LoggerFactory.getLogger(RegistrationOrchestrationHelper.class);
    private static final String sClassName = "RegistrationOrchestrationHelper";

    @Autowired
    private GetMemberServicesDBHelper getMemberServicesDBHelper;

    @Autowired
    private UpdateDBHelper updateDBHelper;

    @Autowired
    private RegistrationOrchestrationRestClient registrationOrchestrationRestClient;

    @Autowired
    private MergeUserAccessIdService mergeUserAccessIdService;

    @Autowired
    private FeatureManagerHelper featureManagerHelper;
    @Autowired
    private UpdateUserHelper updateUserHelper;

    @Value("${registration.orchestration.thread.pool.size:10}")
    private int threadPoolSize;

    @Value("${registration.orchestration.overall.timeout.seconds:60}")
    private int overallTimeoutSeconds;

    /**
     * Main orchestration method. Validates targetAccessId exists in DB,
     * then processes each association item in parallel.
     *
     * @param request The registration orchestration request.
     * @return RegistrationOrchestrationResponse containing per-item results and overall status.
     */
    public RegistrationOrchestrationResponse processRegistration(RegistrationOrchestrationRequest request) {
        String sMethodName = ".processRegistration.";
        String idpTraceId = request.getIdpTraceId();

        logger.info("{}{}ROH_001 : Processing registration for targetAccessId: {}", sClassName, sMethodName,
                HtmlUtils.htmlEscape(String.valueOf(request.getTargetAccessId())));

        // Step 2: Verify targetAccessId exists in DB and retrieve member info
        Map<String, Object> targetMemberInfo = new HashMap<>();
        RegistrationOrchestrationResponse lookupError = verifyTargetAccessIdExists(request.getTargetAccessId(), idpTraceId, targetMemberInfo);
        if (lookupError != null) {
            return lookupError;
        }

        boolean legacyApiEnabled = resolveLegacyApiFlag();

        // Capture update-user channel switches once (avoids per-async lookups)
        String updateUserMqAehSwitch = resolveChannelSwitch(ProfileOrchestrationConstants.UPDATE_USER_MQ_AEH_SWITCH, "MQ");
        String updateUserClmSwitch = resolveChannelSwitch(ProfileOrchestrationConstants.UPDATE_USER_NOTIFICATION_CLM_SWITCH, "MQ");

        // Step 3: Process each association item in parallel
        String autogeneratedInd = (String) targetMemberInfo.get(MPSDefs.DB_AUTOGENERATED_IND);
        String slidMemberNum = (String) targetMemberInfo.get(MPSDefs.DB_SLID_MEMBER_NUM);
        String activatedInd = (String) targetMemberInfo.get(MPSDefs.DB_ACTIVATED_IND);

        // Step 3: Process each association item in parallel
        List<AssociationResult> results = processAssociationsInParallel(request, autogeneratedInd, slidMemberNum, activatedInd,
                legacyApiEnabled, updateUserMqAehSwitch, updateUserClmSwitch);

        // Step 5: Determine overall status
        return buildAggregatedResponse(results, idpTraceId);
    }

    /**
     * Verifies that the targetAccessId exists in the IDGraph DB.
     * On success, populates outMemberInfo with autogeneratedInd, slidMemberNum, and activatedInd from the DB response.
     *
     * @param targetAccessId The target access ID to verify.
     * @param idpTraceId The trace ID.
     * @param outMemberInfo Output map populated with member info on success.
     * @return RegistrationOrchestrationResponse with error if not found, null if found.
     */
    private RegistrationOrchestrationResponse verifyTargetAccessIdExists(String targetAccessId, String idpTraceId, Map<String, Object> outMemberInfo) {
        String sMethodName = ".verifyTargetAccessIdExists.";
        try {
            HashMap<String, Object> hmDbInput = CommonUtil.getHashMap();
            hmDbInput.put(MPSDefs.DB_MEMBER_NAME, targetAccessId.toLowerCase());
            hmDbInput.put(MPSDefs.DB_DOMAIN_NAME, CommonDefs.SLID_DUM);
            hmDbInput.put(MPSDefs.QUERY_SLID_INFO_FLAG, CommonDefs.DEFAULT_YES);

            HashMap<String, Object> hmDbResponse = getMemberServicesDBHelper.getMemberServices(hmDbInput);

            if (hmDbResponse == null) {
                logger.error("{}{}ROH_002 : DB returned null for targetAccessId lookup", sClassName, sMethodName);
                return buildErrorResponse("MS_MPSYS_BE_602", "ERR_SYS_APPL: Database returned null response", idpTraceId);
            }

            String stAppStatusCode = (String) hmDbResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
            if (stAppStatusCode != null && !stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
                if (stAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
                    logger.info("{}{}ROH_003 : targetAccessId does not exist in DB", sClassName, sMethodName);
                    return buildErrorResponse("MS_MPSYS_BE_121",
                            "ERR_USER_NOT_FOUND: Input targetAccessId does Not Exist in DB", idpTraceId);
                } else {
                    logger.error("{}{}ROH_004 : DB error during targetAccessId lookup: {}", sClassName, sMethodName, stAppStatusCode);
                    return buildErrorResponse("MS_MPSYS_BE_304", "ERR_DB: Database error during lookup", idpTraceId);
                }
            }

            // Capture member info for downstream processing (Path C activation logic)
            if (outMemberInfo != null) {
                outMemberInfo.put(MPSDefs.DB_AUTOGENERATED_IND, hmDbResponse.get(MPSDefs.DB_AUTOGENERATED_IND));
                outMemberInfo.put(MPSDefs.DB_SLID_MEMBER_NUM, hmDbResponse.get(MPSDefs.DB_SLID_MEMBER_NUM));
                outMemberInfo.put(MPSDefs.DB_ACTIVATED_IND, hmDbResponse.get(MPSDefs.DB_ACTIVATED_IND));
            }

            logger.info("{}{}ROH_005 : targetAccessId verified in DB", sClassName, sMethodName);
            return null;

        } catch (Exception e) {
            logger.error("{}{}ROH_006 : Exception during targetAccessId lookup: {}", sClassName, sMethodName, e.getMessage());
            return buildErrorResponse("MS_MPSYS_BE_602", "ERR_SYS_APPL: " + e.getMessage(), idpTraceId);
        }
    }

    /**
     * Processes all association items in parallel using CompletableFuture.
     *
     * @param request The registration orchestration request.
     * @param autogeneratedInd The autogenerated_ind value from the target member DB lookup.
     * @param slidMemberNum The slid_member_num value from the target member DB lookup.
     * @param activatedInd The activated_ind value from the target member DB lookup.
     * @return List of AssociationResult with per-item outcomes.
     */
    private List<AssociationResult> processAssociationsInParallel(RegistrationOrchestrationRequest request, String autogeneratedInd,
            String slidMemberNum, String activatedInd, boolean legacyApiEnabled,
            String updateUserMqAehSwitch, String updateUserClmSwitch) {
        logger.info("Inside processAssociationsInParallel method:::");
        String sMethodName = ".processAssociationsInParallel.";

        ExecutorService executor = Executors.newFixedThreadPool(Math.min(threadPoolSize, request.getAssociationList().size()));
        List<CompletableFuture<AssociationResult>> futures = new ArrayList<>();

        try {
            for (AssociationItem item : request.getAssociationList()) {
                CompletableFuture<AssociationResult> future = CompletableFuture.supplyAsync(() ->
                        processAssociationItem(item, request, autogeneratedInd, slidMemberNum, activatedInd, legacyApiEnabled,
                                updateUserMqAehSwitch, updateUserClmSwitch), executor);
                futures.add(future);
            }

            // Wait for all futures to complete with overall timeout
            CompletableFuture<Void> allOf = CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]));
            try {
                allOf.get(overallTimeoutSeconds, TimeUnit.SECONDS);
            } catch (Exception e) {
                logger.error("{}{}ROH_007 : Timeout or error waiting for parallel processing: {}", sClassName, sMethodName, e.getMessage());
            }

            List<AssociationResult> results = new ArrayList<>();
            for (int i = 0; i < futures.size(); i++) {
                try {
                    results.add(futures.get(i).getNow(buildTimeoutResult(request.getAssociationList().get(i))));
                } catch (Exception e) {
                    results.add(buildErrorResult(request.getAssociationList().get(i),
                            "MS_MPSYS_BE_602", "ERR_SYS_APPL: " + e.getMessage()));
                }
            }
            return results;

        } finally {
            executor.shutdown();
            try {
                if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                    executor.shutdownNow();
                }
            } catch (InterruptedException e) {
                executor.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
    }

    /**
     * Processes a single association item. Determines whether to call merge (Path A),
     * addAssociation (Path B), or activation-only update (Path C).
     *
     * Path C is triggered when sourceAccessId equals targetAccessId (case-insensitive)
     * and the target member's activated_ind is 'N'. In this case, only activated_ind
     * is updated to 'Y' without invoking merge or addAssociation.
     *
     * @param item The association item to process.
     * @param request The parent request containing targetAccessId.
     * @param autogeneratedInd The autogenerated_ind value from the target member DB lookup.
     * @param slidMemberNum The slid_member_num value from the target member DB lookup.
     * @param activatedInd The activated_ind value from the target member DB lookup.
     * @return AssociationResult with the outcome.
     */
    private AssociationResult processAssociationItem(AssociationItem item, RegistrationOrchestrationRequest request, String autogeneratedInd,
            String slidMemberNum, String activatedInd, boolean legacyApiEnabled,
            String updateUserMqAehSwitch, String updateUserClmSwitch) {
        logger.info("Inside processAssociationItem method:::");
        String sMethodName = ".processAssociationItem.";
        String serviceName = item.getServiceName();
        String sorInvariantId = item.getSorInvariantId();

        logger.info("{}{}ROH_010 : Processing item serviceName={}, sorInvariantId={}", sClassName, sMethodName,
                StringUtils.normalizeSpace(serviceName), StringUtils.normalizeSpace(sorInvariantId));

        try {
            if (StringUtils.isNotBlank(item.getSourceAccessId())) {
                // Path C: If sourceAccessId == targetAccessId and activated_ind == N,
                // skip merge and just update activated_ind to Y
                String sourceAccessId = item.getSourceAccessId().trim().toLowerCase();
                String targetAccessId = request.getTargetAccessId().trim().toLowerCase();
                if (sourceAccessId.equals(targetAccessId) && "N".equalsIgnoreCase(activatedInd)) {
                    logger.info("{}{}ROH_012 : Path C - sourceAccessId equals targetAccessId and activatedInd is N, activating member",
                            sClassName, sMethodName);
                    return processActivationPath(item, request, slidMemberNum, updateUserMqAehSwitch, updateUserClmSwitch);
                }
                logger.info("processing merge request:::");
                // Path A: Merge — sourceAccessId is present
                return processMergePath(item, request, legacyApiEnabled);
            } else {
                // Path B: Direct Link via addAssociation
                return processAddAssociationPath(item, request);
            }
        } catch (Exception e) {
            logger.error("{}{}ROH_011 : Exception processing item serviceName={}: {}", sClassName, sMethodName,
                    StringUtils.normalizeSpace(serviceName), e.getMessage());
            return buildErrorResult(item, "MS_MPSYS_BE_602", "ERR_SYS_APPL: " + e.getMessage());
        }
    }

    /**
     * Path C: Activation-only path. Updates activated_ind to 'Y' using UpdateUserHelper
     * without invoking merge or addAssociation. Triggered when sourceAccessId equals
     * targetAccessId and the member's activated_ind is 'N'.
     *
     * @param item The association item.
     * @param request The parent request containing targetAccessId.
     * @param slidMemberNum The slid_member_num from the target member DB lookup.
     * @return AssociationResult with activation outcome.
     */
    @SuppressWarnings("unchecked")
    private AssociationResult processActivationPath(AssociationItem item, RegistrationOrchestrationRequest request, String slidMemberNum,
            String updateUserMqAehSwitch, String updateUserClmSwitch) {
        String sMethodName = ".processActivationPath.";

        logger.info("{}{}ROH_040 : Activation path - updating activated_ind to Y for targetAccessId={}",
                sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(request.getTargetAccessId())));

        try {
            // Prepare input map for UpdateUserHelper.updateUser()
            HashMap<String, Object> hmUpdateInput = CommonUtil.getHashMap();
            hmUpdateInput.put(CommonDefs.ACTIVATED_IND, CommonDefs.IND_Y);
            hmUpdateInput.put(CommonDefs.TRANSACTION_NAME, "UpdateUser");
            hmUpdateInput.put(CommonDefs.CALLING_SYSTEM_ID, request.getCallingSystemId());
            String idpTraceid = request.getIdpTraceId();
            hmUpdateInput.put(ProfileOrchestrationConstants.IDPTRACEID, idpTraceid);
            if(idpTraceid != null && !idpTraceid.isEmpty()) {
                hmUpdateInput.put("dbusTransactionId", idpTraceid.split(":")[0]);
            }

            hmUpdateInput.put(CommonDefs.GUID, slidMemberNum);
            hmUpdateInput.put(CommonDefs.DOMAIN, CommonDefs.SLID_DUM);

            hmUpdateInput.put(ProfileOrchestrationConstants.UPDATE_USER_MQ_AEH_SWITCH, updateUserMqAehSwitch);
            hmUpdateInput.put(ProfileOrchestrationConstants.UPDATE_USER_NOTIFICATION_CLM_SWITCH, updateUserClmSwitch);

            Map<String, Object> hmResult = updateUserHelper.updateUser(hmUpdateInput);

            if (hmResult == null) {
                logger.error("{}{}ROH_042 : Null response from UpdateUserHelper.updateUser", sClassName, sMethodName);
                return buildErrorResult(item, "MS_MPSYS_BE_602", "ERR_SYS_APPL: Null response from UpdateUserHelper");
            }

            String stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
            if (stAppStatusCode != null && stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
                logger.info("{}{}ROH_043 : Activation path successful for targetAccessId={}",
                        sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(request.getTargetAccessId())));
                return AssociationResult.builder()
                        .serviceName(item.getServiceName())
                        .sorInvariantId(item.getSorInvariantId())
                        .statusCode(ProfileOrchestrationConstants.SUCCESS_CODE)
                        .statusMsg(ProfileOrchestrationConstants.SUCCESS_MSG)
                        .build();
            } else {
                String appInfo = (String) hmResult.getOrDefault(CErrorDefs.COMMON_APP_INFO, "");
                logger.error("{}{}ROH_044 : Activation path failed: statusCode={}, info={}",
                        sClassName, sMethodName, stAppStatusCode, appInfo);
                return buildErrorResult(item, "MS_MPSYS_BE_" + stAppStatusCode, appInfo);
            }
        } catch (Exception e) {
            logger.error("{}{}ROH_041 : Exception in activation path: {}", sClassName, sMethodName, e.getMessage());
            return buildErrorResult(item, "MS_MPSYS_BE_602", "ERR_SYS_APPL: " + e.getMessage());
        }
    }

    /**
     * Path A: Calls mergeUserAccessId via the service layer (MergeUserAccessIdServiceImpl).
     * Maps sourceAccessId → fromUserName, targetAccessId → toUserName.
     * The service layer handles feature-flag routing, transaction management, and response generation.
     *
     * @param item The association item containing sourceAccessId.
     * @param request The parent request containing targetAccessId.
     * @return AssociationResult with merge outcome.
     */
    private AssociationResult processMergePath(AssociationItem item, RegistrationOrchestrationRequest request,
            boolean legacyApiEnabled) {
        String sMethodName = ".processMergePath.";

        logger.info("{}{}ROH_020 : MergeUserAccessId path - sourceAccessId={}, targetAccessId={}", sClassName, sMethodName,
                HtmlUtils.htmlEscape(String.valueOf(item.getSourceAccessId())),
                HtmlUtils.htmlEscape(String.valueOf(request.getTargetAccessId())));

        try {
            MergeUserAccessIdRequest mergeRequest = MergeUserAccessIdRequest.builder()
                    .fromUserName(item.getSourceAccessId().trim().toLowerCase())
                    .toUserName(request.getTargetAccessId().trim().toLowerCase())
                    .callingSystemId(request.getCallingSystemId())
                    .idpTraceId(request.getIdpTraceId())
                    .build();

            MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
            headers.add("legacy-api-enabled", Boolean.toString(legacyApiEnabled));

            MergeUserAccessIdResponse mergeResponse =
                    mergeUserAccessIdService.mergeUserAccessId(mergeRequest, headers);

            return mapMergeResponse(item, mergeResponse);

        } catch (InvalidInputDataException e) {
            logger.error("{}{}ROH_021 : InvalidInputDataException in merge path (transaction rollback): {}",
                    sClassName, sMethodName, e.getMessage());
            return mapInvalidInputDataToResult(item, e);
        } catch (Exception e) {
            logger.error("{}{}ROH_022 : Exception in merge path: {}", sClassName, sMethodName, e.getMessage());
            return buildErrorResult(item, "MS_MPSYS_BE_602", "ERR_SYS_APPL: " + e.getMessage());
        }
    }

    /**
     * Maps a MergeUserAccessIdResponse to an AssociationResult.
     *
     * Success: appStatusCode == "0" → statusCode="MS_MPSYS_BE_0", statusMsg="SUCCESS"
     * Error with ServiceError: errors.errorId → statusCode, errors.message → statusMsg
     * Error without ServiceError: "MS_MPSYS_BE_" + appStatusCode → statusCode, appInfo → statusMsg
     *
     * @param item The association item.
     * @param mergeResponse The typed response from MergeUserAccessIdServiceImpl.
     * @return AssociationResult with mapped status.
     */
    private AssociationResult mapMergeResponse(AssociationItem item, MergeUserAccessIdResponse mergeResponse) {
        if (mergeResponse == null) {
            return buildErrorResult(item, "MS_MPSYS_BE_602",
                    "ERR_SYS_APPL: Null response from mergeUserAccessId service");
        }

        String stAppStatusCode = mergeResponse.getAppStatusCode();

        if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
            return AssociationResult.builder()
                    .serviceName(item.getServiceName())
                    .sorInvariantId(item.getSorInvariantId())
                    .statusCode(ProfileOrchestrationConstants.SUCCESS_CODE)
                    .statusMsg(ProfileOrchestrationConstants.SUCCESS_MSG)
                    .build();
        } else {
            String errorId;
            String errorMsg;

            if (mergeResponse.getErrors() != null) {
                errorId = mergeResponse.getErrors().getErrorId() != null
                        ? mergeResponse.getErrors().getErrorId()
                        : "MS_MPSYS_BE_" + stAppStatusCode;
                errorMsg = mergeResponse.getErrors().getMessage() != null
                        ? mergeResponse.getErrors().getMessage()
                        : "";
            } else {
                errorId = "MS_MPSYS_BE_" + stAppStatusCode;
                errorMsg = mergeResponse.getAppInfo() != null ? mergeResponse.getAppInfo() : "";
            }

            return AssociationResult.builder()
                    .serviceName(item.getServiceName())
                    .sorInvariantId(item.getSorInvariantId())
                    .statusCode(errorId)
                    .statusMsg(errorMsg)
                    .build();
        }
    }

    /**
     * Path B: Calls addAssociation via internal REST client with service-name-specific mappings.
     *
     * @param item The association item.
     * @param request The parent request.
     * @return AssociationResult with addAssociation outcome.
     */
    private AssociationResult processAddAssociationPath(AssociationItem item, RegistrationOrchestrationRequest request) {
        String sMethodName = ".processAddAssociationPath.";

        logger.info("{}{}ROH_030 : AddAssociation path - userId={}, serviceName={}", sClassName, sMethodName,
                HtmlUtils.htmlEscape(String.valueOf(request.getTargetAccessId())),
                StringUtils.normalizeSpace(item.getServiceName()));

        try {
            Map<String, Object> hmAccount = new HashMap<>();
            List<Map<String, Object>> accountList = new ArrayList<>();
            Map<String, Object> addAssocInput = new HashMap<>();

            addAssocInput.put(CommonDefs.TRANSACTION_NAME, ProfileOrchestrationConstants.ADD_ASSOCIATION_TRANSACTION_NAME);
            addAssocInput.put(CommonDefs.USER_ID, request.getTargetAccessId().trim().toLowerCase());
            addAssocInput.put(ProfileOrchestrationConstants.IDPTRACEID, request.getIdpTraceId());
            addAssocInput.put(CommonDefs.CALLING_SYSTEM_ID, request.getCallingSystemId());

            // Apply service-name-specific field mappings
            String serviceName = item.getServiceName();
            hmAccount.put(CommonDefs.SERVICE_NAME, serviceName);

            hmAccount.put(CommonDefs.INSTANCE_ID, item.getSorInvariantId());
            hmAccount.put(CommonDefs.SOR_INVARIANT_ID, item.getSorInvariantId());
            hmAccount.put(CommonDefs.KEY_SOR_NAME, mapSorName(serviceName));
            hmAccount.put(CommonDefs.SERVICE_STATUS, ProfileOrchestrationConstants.SERVICE_STATUS_ENABLED);
            addAssocInput.put(CommonDefs.SUPPRESS_NOTIFICATION, CommonDefs.MTB_IND_NO);

            // INDIVIDUAL does not get roleName/roleStatus
            if (!ProfileOrchestrationConstants.SERVICE_NAME_INDIVIDUAL.equals(serviceName)) {
                hmAccount.put(CommonDefs.ROLE_NAME, ProfileOrchestrationConstants.ROLE_NAME_OWNER);
                hmAccount.put(CommonDefs.ROLE_STATUS, ProfileOrchestrationConstants.SERVICE_STATUS_ENABLED);
            }
            accountList.add(hmAccount);
            addAssocInput.put("associationList", accountList);

            Map<String, Object> hmResponse = registrationOrchestrationRestClient.callIDPRestClient(addAssocInput);

            return mapDownstreamResponse(item, hmResponse);

        } catch (Exception e) {
            logger.error("{}{}ROH_031 : Exception in addAssociation path: {}", sClassName, sMethodName, e.getMessage());
            return buildErrorResult(item, "MS_MPSYS_BE_602", "ERR_SYS_APPL: " + e.getMessage());
        }
    }

    /**
     * Maps the serviceName to the corresponding sorName for addAssociation.
     */
    private String mapSorName(String serviceName) {
        switch (serviceName) {
            case ProfileOrchestrationConstants.SERVICE_NAME_TITAN:
                return ProfileOrchestrationConstants.SOR_NAME_LS;
            case ProfileOrchestrationConstants.SERVICE_NAME_MOBILITY:
                return ProfileOrchestrationConstants.SOR_NAME_MO;
            case ProfileOrchestrationConstants.SERVICE_NAME_ECOMM:
                return ProfileOrchestrationConstants.SOR_NAME_BDS;
            case ProfileOrchestrationConstants.SERVICE_NAME_INDIVIDUAL:
                return ProfileOrchestrationConstants.SOR_NAME_CG;
            default:
                return serviceName;
        }
    }

    /**
     * Maps a downstream API response (merge or addAssociation) to an AssociationResult.
     */
    private AssociationResult mapDownstreamResponse(AssociationItem item, Map<String, Object> hmResponse) {
        if (hmResponse == null || hmResponse.isEmpty()) {
            return buildErrorResult(item, "MS_MPSYS_BE_602", "ERR_SYS_APPL: Null response from downstream API");
        }

        String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
        if (stAppStatusCode == null) {
            return buildErrorResult(item, "MS_MPSYS_BE_602", "ERR_SYS_APPL: No status code in downstream response");
        }

        if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
            return AssociationResult.builder()
                    .serviceName(item.getServiceName())
                    .sorInvariantId(item.getSorInvariantId())
                    .statusCode(ProfileOrchestrationConstants.SUCCESS_CODE)
                    .statusMsg(ProfileOrchestrationConstants.SUCCESS_MSG)
                    .build();
        } else {
            String appInfo = (String) hmResponse.getOrDefault(CommonDefs.COMMON_APP_INFO, "");
            String errorId = "MS_MPSYS_BE_" + stAppStatusCode;
            return AssociationResult.builder()
                    .serviceName(item.getServiceName())
                    .sorInvariantId(item.getSorInvariantId())
                    .statusCode(errorId)
                    .statusMsg(appInfo)
                    .build();
        }
    }

    /**
     * Builds the aggregated response based on per-item results.
     * All succeed → SUCCESS/200, Mix → PARTIAL_SUCCESS/207, All fail → FAILED/400.
     */
    private RegistrationOrchestrationResponse buildAggregatedResponse(List<AssociationResult> results, String idpTraceId) {
        long successCount = results.stream()
                .filter(r -> ProfileOrchestrationConstants.SUCCESS_CODE.equals(r.getStatusCode()))
                .count();

        String status;
        if (successCount == results.size()) {
            status = ProfileOrchestrationConstants.STATUS_SUCCESS;
        } else if (successCount > 0) {
            status = ProfileOrchestrationConstants.STATUS_PARTIAL_SUCCESS;
        } else {
            status = ProfileOrchestrationConstants.STATUS_FAILED;
        }

        return RegistrationOrchestrationResponse.builder()
                .idpTraceId(idpTraceId)
                .status(status)
                .results(results)
                .build();
    }

    /**
     * Builds a top-level error response (no results[]).
     */
    private RegistrationOrchestrationResponse buildErrorResponse(String errorId, String message, String idpTraceId) {
        return RegistrationOrchestrationResponse.builder()
                .idpTraceId(idpTraceId)
                .status(ProfileOrchestrationConstants.STATUS_FAILED)
                .errorId(errorId)
                .message(message)
                .build();
    }

    /**
     * Resolves the legacy merge API feature flag once per registration request to avoid
     * repeated lookups inside async tasks.
     */
    private boolean resolveLegacyApiFlag() {
        try {
            return featureManagerHelper != null && featureManagerHelper.isEnabled("svc-idgraph-mergeuser-enable-legacyapi");
        } catch (Exception ex) {
            logger.error("{}{}ROH_099 : Exception while checking legacy merge feature flag, defaulting to true", sClassName,
                    ".resolveLegacyApiFlag.", ex);
            return true;
        }
    }

    /**
     * Safely resolves channel switch values, tolerating null featureManagerHelper in unit tests.
     */
    private String resolveChannelSwitch(String key, String defaultValue) {
        try {
            String value = featureManagerHelper != null ? featureManagerHelper.getValue(key) : null;
            return (value != null && !value.isEmpty()) ? value : defaultValue;
        } catch (Exception ex) {
            logger.warn("{}{}ROH_100 : Exception reading feature flag {}, defaulting to {}", sClassName, ".resolveChannelSwitch.", key, defaultValue, ex);
            return defaultValue;
        }
    }

    /**
     * Maps an InvalidInputDataException (thrown on transaction rollback) to an AssociationResult,
     * extracting the actual error code and message from the exception's errorHashMap.
     * Falls back to MS_MPSYS_BE_602 only if no status code is available.
     */
    private AssociationResult mapInvalidInputDataToResult(AssociationItem item, InvalidInputDataException e) {
        if (e.errorHashMap != null && !e.errorHashMap.isEmpty()) {
            String stAppStatusCode = (String) e.errorHashMap.get(MPSDefs.APP_STATUS_CODE);
            String stAppInfo = (String) e.errorHashMap.getOrDefault(CommonDefs.COMMON_APP_INFO, "");

            if (stAppStatusCode != null) {
                String errorId = "MS_MPSYS_BE_" + stAppStatusCode;
                return buildErrorResult(item, errorId, stAppInfo);
            }
        }
        return buildErrorResult(item, "MS_MPSYS_BE_602", "ERR_SYS_APPL: " + e.getMessage());
    }

    /**
     * Builds an error AssociationResult for a single item.
     */
    private AssociationResult buildErrorResult(AssociationItem item, String statusCode, String statusMsg) {
        return AssociationResult.builder()
                .serviceName(item.getServiceName())
                .sorInvariantId(item.getSorInvariantId())
                .statusCode(statusCode)
                .statusMsg(statusMsg)
                .build();
    }

    /**
     * Builds a timeout AssociationResult for a single item.
     */
    private AssociationResult buildTimeoutResult(AssociationItem item) {
        return AssociationResult.builder()
                .serviceName(item.getServiceName())
                .sorInvariantId(item.getSorInvariantId())
                .statusCode("MS_MPSYS_BE_606")
                .statusMsg("ERR_TRAN_TIME_OUT: Processing timed out")
                .build();
    }
}
