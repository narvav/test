package com.att.idp.idgraphusermanagementms.db.helper;

import java.sql.PreparedStatement;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.att.mpsys.common.utils.*;
import net.logstash.logback.argument.StructuredArguments;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.att.common.validators.StatusValidation;
import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;

@Component
public class ServiceContactDBHelper
{
	private static final String INFO = "$Id: master/com/att/idp/idgraphusermanagementms/helper/ServiceContactDBHelper.java v1 2024-09-20 vn3904 $";
	private static final String sClassName = "ServiceContactDBHelper";
	public static final Logger logger = LoggerFactory.getLogger(ServiceContactDBHelper.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private DBHelper oDBHelper;

	@Autowired
	private StatusValidation statusValidation;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	protected static final Set<String> SERVICE_CONTACT_UPDATBLE_ATTRS = new HashSet();
	static {
		SERVICE_CONTACT_UPDATBLE_ATTRS.add("phone_number");
		SERVICE_CONTACT_UPDATBLE_ATTRS.add("phone_number_ext");
		SERVICE_CONTACT_UPDATBLE_ATTRS.add("phone_number_type");
		SERVICE_CONTACT_UPDATBLE_ATTRS.add("email_address");
		SERVICE_CONTACT_UPDATBLE_ATTRS.add("contact_status");
		SERVICE_CONTACT_UPDATBLE_ATTRS.add("mobility_invariant_id");
		SERVICE_CONTACT_UPDATBLE_ATTRS.add("validation_status");//1510 US432315 support the scrubbing of CBR information.
	}

	protected static final Set<String> SERVICE_CONTACT_UPD_ATTRS_BY_PHONE = new HashSet();
	static {
		SERVICE_CONTACT_UPD_ATTRS_BY_PHONE.add("phone_number");
		SERVICE_CONTACT_UPD_ATTRS_BY_PHONE.add("phone_number_type");
		SERVICE_CONTACT_UPD_ATTRS_BY_PHONE.add("atlas_last_timestamp");
		SERVICE_CONTACT_UPD_ATTRS_BY_PHONE.add("contact_status"); // Oct 2013
	}
	/**
	 *
	 * @param hmInput
	 * @return HashMap
	 */
	public HashMap<String,Object> updateServiceContact (HashMap<String,Object> hmInput)
	{
		String sMethodName = "updateServiceContact";
		HashMap<String,Object> hmResult = null;
		String sAppStatusCode = null;

		logger.info("{}{}SCDBH.USC.01 : CVS KEYWORDS: {}", sClassName, sMethodName, INFO);
		logger.info("{}{}DBTOOLS000 : updateServiceContact InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmInput));

		try
		{
			if (jdbcTemplate == null) {
				return hmResult = CommonErrorMap.makeCategoryMap(
						CommonErrorMap.ERR_DB_NUM, "Error null connection, no row updated");
			}

			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sUpdateByAtlasInvId = (String) hmInput.get(MPSDefs.UPDATE_BY_ATLAS_INVARIANTID_FLAG);
			String sUpdateByPhoneNumber = (String) hmInput.get("updateByPhoneNumber");

			if (sCallingSystemId == null || sCallingSystemId.trim().length() <= 0)
			{
				hmResult = CommonErrorMap.makeCategoryMap (MPSDefs.ERR_EMPTY_NUM,
						"callingSystemId is null or empty in input");
				return hmResult;
			}

			ArrayList alServiceContacts = (ArrayList) hmInput.get("servicecontact");
			if(alServiceContacts == null || alServiceContacts.size() <= 0)
			{
				hmResult = CommonErrorMap.makeCategoryMap (MPSDefs.ERR_EMPTY_NUM,
						"servicecontact list is empty in input");
				return hmResult;
			}

			//Iterate through servicecontact list to update each servicecontact
			int rowsUpdated = 0;
			HashMap hmServiceContact=null;
			for (int i=0; i < alServiceContacts.size(); i++)
			{
				hmServiceContact = (HashMap) alServiceContacts.get(i);

				if (hmServiceContact != null && ! hmServiceContact.isEmpty())
				{
					hmServiceContact.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);

					//Call local method to update one servicecontact at a time
					if (sUpdateByAtlasInvId != null && sUpdateByAtlasInvId.equals(MPSDefs.YES)){
						hmResult = updateServiceContactByAtlasInvariantId (hmServiceContact);
					}
					else if("Y".equalsIgnoreCase(sUpdateByPhoneNumber)){//1510 - US503078 - Only this else if condition
						hmResult = updateServiceContactByPhoneNumber(hmServiceContact);
					}
					else{
						hmResult = updateEachServiceContact(hmServiceContact);
					}

					sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
					if (sAppStatusCode != null && ! sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS))
					{
						return hmResult;
					}
				} else {
					hmResult = CommonErrorMap.makeCategoryMap (MPSDefs.ERR_EMPTY_NUM,
							"servicecontact hash is empty in input");
					return hmResult;
				}

				rowsUpdated = rowsUpdated +1;
			}
			hmResult.put(CommonDefs.COMMON_APP_INFO, "Number of rows updated := " + rowsUpdated);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();

			hmResult = CommonErrorMap.makeExceptionMap(e);

			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}DMDH.DGS.07 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}DMDH.DGS.08 : Exception = {}", sClassName, sMethodName, errorCode);
			return hmResult;

		} finally {
			if ( hmResult == null || hmResult.isEmpty() )
			{
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM,
						"Error while updating  SERVICECONTACT Table");
			}

			logger.info("{}{} DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);		}

		return hmResult;
	}

	/**
	 *
	 * @param hmInput
	 * @return HashMap
	 */
	public HashMap updateEachServiceContact (HashMap hmInput)
	{

		String sMethodName = "updateEachServiceContact";
		HashMap hmResult = null;
		PreparedStatement prepStmt = null;
		String sAppInfo = null;
		StringBuilder updateEachServiceContact = new StringBuilder(
				"UPDATE SERVICECONTACT SET last_modified_by = ?, ");

			logger.info("{}{}SCDBH.UESC.01: CVS KEYWORDS: {}", sClassName, sMethodName, INFO);
			logger.info("{}{}DBTOOLS000 : updateEachServiceContact InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmInput));		logger.info("{}{}DBTOOLS000 : updateEachServiceContact InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmInput));

		try
		{
			String sSorInvariantId = (String) hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
			String sSorId = (String) hmInput.get(MPSDefs.DB_SOR_ID);
			String sSorName = (String) hmInput.get(MPSDefs.DB_SOR_NAME);
			String sContactType = (String) hmInput.get("contact_type");

			if (sSorInvariantId == null || sSorInvariantId.trim().length() <= 0 ||
					sContactType == null || sContactType.trim().length() <= 0)
			{
				hmResult = CommonErrorMap.makeCategoryMap (MPSDefs.ERR_EMPTY_NUM,
						"sor_invariant_id and/or contact_type is null or empty in input");
				return hmResult;
			}

			if ((sSorId == null || sSorId.trim().length() <= 0) && (sSorName == null ||
					sSorName.trim().length() <= 0 ))
			{
				hmResult = CommonErrorMap.makeCategoryMap (MPSDefs.ERR_EMPTY_NUM,
						"sor_id and sor_name both are null or empty in input");
				return hmResult;
			}

			String stValidationStatusFlag = (String) hmInput.get(CommonDefs.VALIDATION_STATUS_FLAG);
			String stValidationInitDateFlag = (String) hmInput.get(CommonDefs.VALIDATION_INIT_DATE_FLAG);

			if(stValidationStatusFlag != null && stValidationStatusFlag.equals(MPSDefs.NO)){
				hmInput.remove("validation_status");
				hmInput.remove(CommonDefs.VALIDATION_STATUS_FLAG);
			}
			if(stValidationInitDateFlag != null && stValidationInitDateFlag.equals(MPSDefs.NO)){
				hmInput.remove("validation_initiated_date");
				hmInput.remove(CommonDefs.VALIDATION_INIT_DATE_FLAG);
			}
			if(stValidationInitDateFlag != null && stValidationInitDateFlag.equals(MPSDefs.YES)){
				hmInput.remove("validation_initiated_date");
				hmInput.remove(CommonDefs.VALIDATION_INIT_DATE_FLAG);
			}

			String stValidationInitiatedDate = (String) hmInput.get("validation_initiated_date");
			if(stValidationInitiatedDate != null && !stValidationInitiatedDate.isEmpty()){
				hmInput.remove(stValidationInitiatedDate);
			}

			int nIndex = 0;
			String sKey = null;
			Iterator itr = SERVICE_CONTACT_UPDATBLE_ATTRS.iterator();
			while (itr.hasNext()) {
				sKey = (String) itr.next();

				if (hmInput.containsKey(sKey))
				{
					if (nIndex > 0 && nIndex < SERVICE_CONTACT_UPDATBLE_ATTRS.size())
						updateEachServiceContact.append(" ,");

					updateEachServiceContact.append(sKey + "=?");
					nIndex++;
				}
			}

			if (hmInput.containsKey(MPSDefs.DB_PHONE_NUMBER) || hmInput.containsKey(MPSDefs.DB_PHONE_NUMBER_EXT) ||
					hmInput.containsKey(MPSDefs.DB_EMAIL_ADDRESS) )
			{
				updateEachServiceContact.append(", date_established = SYSDATE ");
			}

			if(stValidationInitiatedDate != null && !stValidationInitiatedDate.isEmpty()){

				updateEachServiceContact.append(", validation_initiated_date = '' ");
			}

			if(stValidationStatusFlag != null && stValidationStatusFlag.equals(MPSDefs.NO)){
				updateEachServiceContact.append(", validation_status" + " = '' ");
			}
			if(stValidationInitDateFlag != null && stValidationInitDateFlag.equals(MPSDefs.NO)){
				updateEachServiceContact.append(", validation_initiated_date" + " = '' ");
			}

			if(stValidationInitDateFlag != null && stValidationInitDateFlag.equals(MPSDefs.YES)){
				updateEachServiceContact.append(", validation_initiated_date = SYSDATE ");
			}

			updateEachServiceContact.append("  WHERE ");

			if (sSorId != null && !sSorId.trim().isEmpty())
				updateEachServiceContact.append(" sor_invariant_id = ? AND sor_id = ? AND contact_type = ?");
			else
				updateEachServiceContact.append(
						" sor_invariant_id = ? AND sor_id = (SELECT sor_id FROM systemofrecord WHERE sor_name = ?) AND contact_type = ?");

			logger.info("{}{}SCDBH.UESC.03 : {}", sClassName, sMethodName,  updateEachServiceContact);

			String stInpValidationStatus = (String) hmInput.get(MPSDefs.DB_VALIDATION_STATUS);

			String stValidationStatusCode = null;

			if(stInpValidationStatus != null && !stInpValidationStatus.isEmpty()){

				stValidationStatusCode = statusValidation.getStatusCodeByName(stInpValidationStatus);

				if (stValidationStatusCode == null || stValidationStatusCode.isEmpty()){
					sAppInfo = "input validation_status is not valid as its not present in MPS DB";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
					logger.info("{}{}SCDBH.UESC.04 : {}{}", CErrorDefs.ERR_INVALID_DATA_NUM, sClassName, sMethodName, sAppInfo);
					return hmResult;
				}
			}

			String sInpEmailAddress = (String) hmInput.get(MPSDefs.DB_EMAIL_ADDRESS);

			nIndex = 0;
			List<Object> objService = new ArrayList<Object>();
			objService.add(null);objService.set(nIndex++, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));

			itr = SERVICE_CONTACT_UPDATBLE_ATTRS.iterator();
			while (itr.hasNext()) {
				sKey = (String) itr.next();

				if (hmInput.containsKey(sKey)) {

					if(MPSDefs.DB_VALIDATION_STATUS.equals(sKey) && stValidationStatusCode != null){
						objService.add(null);objService.set(nIndex++, Integer.parseInt(stValidationStatusCode));
					}else if (MPSDefs.DB_EMAIL_ADDRESS.equals(sKey) && (sInpEmailAddress != null && !sInpEmailAddress.isEmpty())) { //1602 - Updated for SID42938 - to lower case emailAddress when inserting/updating in MPS DB
						objService.add(null);objService.set(nIndex++, sInpEmailAddress.toLowerCase());
					}else {
						objService.add(null);objService.set(nIndex++, hmInput.get(sKey));
					}
				}
			}

			objService.add(null);objService.set(nIndex++, sSorInvariantId);

			if (sSorId != null && !sSorId.trim().isEmpty()) {
				objService.add(null);objService.set(nIndex++, sSorId );}
			else {
				objService.add(null);
				objService.set(nIndex++, sSorName);
			}

			objService.add(null);objService.set(nIndex++, sContactType);

			long tTime = 0;
			Date dtStartDate = new Date();

			int rowCount = jdbcTemplate.update(updateEachServiceContact.toString(), objService.toArray());

			tTime = (System.currentTimeMillis() - dtStartDate.getTime()) ;
			logger.info("{}{}QUERY999 : Total time taken to execute query = {} milliseconds", sClassName, sMethodName, tTime);


			if (rowCount == 0) {
				hmResult = CommonErrorMap.makeCategoryMap (CErrorDefs.ERR_REC_NOT_FOUND_NUM,
						"No Record found for given sor and sor_invariant_id");
			} else {
				hmResult = CommonErrorMap.makeCategoryMap (CommonDefs.COMMON_SUCCESS_NUM,
						"SERVICECONTACT attributes updated successfully ");
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}SCDB.UESC.07 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}SCDB.UESC.08 : Exception = {}", sClassName, sMethodName, errorCode);
			return hmResult;

		} finally {
			logger.info("{}{} DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);
		}

		return hmResult;
	}
	/**
	 *
	 * @param hmInput
     * @return HashMap
	 */
	public HashMap updateServiceContactByAtlasInvariantId (HashMap hmInput)
	{

		String sMethodName = "updateServiceContactByAtlasInvariantId";
		HashMap hmResult = null;

		StringBuilder sbUpdateServiceContact = new StringBuilder(
				"UPDATE SERVICECONTACT SET last_modified_by = ?, ");

		logger.info("{}{}SCDBH.USCBAI.01: CVS KEYWORDS: {}", sClassName, sMethodName, INFO);
		logger.info("{}{}DBTOOLS000 : updateServiceContactByAtlasInvariantId InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmInput));

			try
		{
			//validate input arguments
			String sMobilityInvarinatId = (String) hmInput.get(MPSDefs.DB_MOBILITY_INVARIANT_ID);

			if (sMobilityInvarinatId == null || sMobilityInvarinatId.trim().length() <= 0 )
			{
				hmResult = CommonErrorMap.makeCategoryMap (MPSDefs.ERR_EMPTY_NUM,
						"mobility_invarinat_id is null or empty in input");
				return hmResult;
			}

			int nIndex = 0;
			String sKey = null;
			Iterator itr = SERVICE_CONTACT_UPD_ATTRS_BY_PHONE.iterator();
			while (itr.hasNext()) {
				sKey = (String) itr.next();

				if (hmInput.containsKey(sKey))
				{
					if (nIndex > 0 && nIndex < SERVICE_CONTACT_UPD_ATTRS_BY_PHONE.size())
						sbUpdateServiceContact.append(", ");

					sbUpdateServiceContact.append(sKey + "=?");
					nIndex++;
				}
			}

			sbUpdateServiceContact.append("  WHERE mobility_invariant_id = ?");

		    logger.info("{}{}SCDBH.USCBAI.02 : {}", sClassName, sMethodName,  sbUpdateServiceContact);


			nIndex = 0;
			List<Object> objService = new ArrayList<Object>();
			objService.add(null);objService.set(nIndex++, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));

			itr = SERVICE_CONTACT_UPD_ATTRS_BY_PHONE.iterator();
			while (itr.hasNext()) {
				sKey = (String) itr.next();

				if (hmInput.containsKey(sKey)) {
				//	nIndex++;
					objService.add(null);objService.set(nIndex++, hmInput.get(sKey));
				}
			}

			objService.add(null);objService.set(nIndex++, sMobilityInvarinatId);

			long tTime = 0;
			Date dtStartDate = new Date();

			int rowCount = jdbcTemplate.update(sbUpdateServiceContact.toString(), objService.toArray());


			tTime = (System.currentTimeMillis() - dtStartDate.getTime()) ;
			logger.info("{}{}SCDBH.USCBAI.03 : Total time taken to execute query = {} milliseconds", sClassName, sMethodName, tTime);

			if (rowCount == 0) {
				hmResult = CommonErrorMap.makeCategoryMap (CErrorDefs.ERR_REC_NOT_FOUND_NUM,
						"No Record found for given phone_number");
			} else {
				hmResult = CommonErrorMap.makeCategoryMap (CommonDefs.COMMON_SUCCESS_NUM,
						"SERVICECONTACT attributes updated successfully ");
			}


		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}SCDBH.USCBAI.04 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}SCDBH.USCBAI.05 : Exception = {}", sClassName, sMethodName, errorCode);
			return hmResult;

		} finally {
			logger.info("{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;
	}

	/**
	 *
	 * @param hmInput
     * @return HashMap
	 */
	public HashMap removeServiceContact (HashMap hmInput)
	{
		String sMethodName = "removeServiceContact";

		HashMap hmResult = null;
		String sAppStatusCode = null;
		String sAppInfo = null;
		int rowCount = 0;
		PreparedStatement prepStmt = null;

		String removeServiceContactSql =
				"DELETE FROM servicecontact WHERE sor_invariant_id = ? ";

		String deleteServiceContactMobInvIdSql =
				"DELETE FROM SERVICECONTACT WHERE mobility_invariant_id = ?";


		logger.info("{}{}SCDBH.RSC.01: CVS KEYWORDS: {}", sClassName, sMethodName, INFO);

		logger.info("{}{}DBTOOLS000 : removeServiceContact InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmInput));

		Date dtStart = new Date();

		try
		{
			if (jdbcTemplate == null) {
				return hmResult = CommonErrorMap.makeCategoryMap(
						CommonErrorMap.ERR_DB_NUM, "Error null connection, no row updated");
			}

			ArrayList alServiceContacts = (ArrayList) hmInput.get("servicecontact");
			String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);

			if(alServiceContacts == null || alServiceContacts.size() <= 0)
			{
				hmResult = CommonErrorMap.makeCategoryMap (MPSDefs.ERR_EMPTY_NUM,
						"servicecontact list is null or empty in input");
				return hmResult;
			}

			logger.info("{}{}SCDBH.RSC.03 : {}{}", sClassName, sMethodName, "DBTOOLS03",
					"transactionName is = " + sTransactionName);
			HashMap hmServiceContact=null;
			//Iterate through each servicecontact to update
            for (Object alServiceContact : alServiceContacts) {
                hmServiceContact = (HashMap) alServiceContact;
                List<Object> objService = new ArrayList<Object>();

                if (hmServiceContact != null && !hmServiceContact.isEmpty()) {
                    String sSorInvariantId = (String) hmServiceContact.get(MPSDefs.DB_SOR_INVARIANT_ID);
                    String sSorId = (String) hmServiceContact.get(MPSDefs.DB_SOR_ID);
                    String sSorName = (String) hmServiceContact.get(MPSDefs.DB_SOR_NAME);
                    String sContactType = (String) hmServiceContact.get("contact_type");
                    String sMobilityInvariantId = (String) hmServiceContact.get(MPSDefs.DB_MOBILITY_INVARIANT_ID);

                    //validate input
                    if ((sSorInvariantId == null || sSorInvariantId.trim().length() <= 0)
                            && (sMobilityInvariantId == null || sMobilityInvariantId.trim().length() <= 0))  // Oct 2013
                    {
                        hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM,
                                "sor_invariant_id and mobility_invariant_id both are null or empty in input");
                        return hmResult;
                    }

                    if ((sTransactionName == null || (!sTransactionName.equalsIgnoreCase("RemoveAccount") &&
                            !sTransactionName.equalsIgnoreCase("CancelSubscriber"))) &&
                            (sContactType == null || sContactType.trim().length() <= 0)) {
                        hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM,
                                "contact_type is null or empty in input");
                        return hmResult;
                    }

                    if ((sTransactionName == null || (!sTransactionName.equalsIgnoreCase("RemoveAccount") &&
                            !sTransactionName.equalsIgnoreCase("CancelSubscriber"))) &&
                            (sSorId == null || sSorId.trim().length() <= 0) && (sSorName == null ||
                            sSorName.trim().length() <= 0)) {
                        hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM,
                                "sor_id and sor_name both are null or empty in input");
                        return hmResult;
                    }

                    String queryArg = "";

                    if (sSorId != null && sSorId.trim().equalsIgnoreCase("null")) {

                        sSorId = null;
                    }

                    if (sSorName != null && sSorName.trim().equalsIgnoreCase("null")) {
                        sSorName = null;
                    }
					int nIndex = 0;
                    if ((sTransactionName != null && sTransactionName.equalsIgnoreCase("RemoveAccount")) &&
                            (sSorId == null || sSorId.isEmpty()) && (sSorName == null || sSorName.isEmpty())) {

						logger.info("{}{}SCDBH.RSC.04 : {}", sClassName, sMethodName,  removeServiceContactSql);

                    } else if ((sTransactionName != null && sTransactionName.equalsIgnoreCase("RemoveAccount")) &&
                            ((sSorId != null && !sSorId.isEmpty()) || (sSorName != null && !sSorName.isEmpty()))) {
                        if (sSorId != null && !sSorId.isEmpty()) {
                            queryArg = " AND sor_id = ? ";
                            removeServiceContactSql = removeServiceContactSql + queryArg;
							objService.add(null); objService.set(nIndex++, sSorId);

                        } else if (!sSorName.isEmpty()) {
                            queryArg = " AND sor_id = (SELECT sor_id FROM systemofrecord WHERE sor_name = ?) ";
							removeServiceContactSql = removeServiceContactSql + queryArg;
							objService.add(null); objService.set(nIndex++, sSorName);
                        }

                        logger.info("{}{}SCDBH.RSC.06 : {}{}", sClassName, sMethodName, "DBTOOLS04.01",
                                "Remove SQL = " + removeServiceContactSql + queryArg);

                    } else if (sMobilityInvariantId != null && !sMobilityInvariantId.isEmpty()) { // Oct 2013

                        removeServiceContactSql = deleteServiceContactMobInvIdSql;

                        logger.info("{}{}SCDBH.RSC.07 : {}{}", sClassName, sMethodName, "DBTOOLS04.1",
                                "Remove SQL = " + deleteServiceContactMobInvIdSql);

                    } else if (sSorId != null && sSorId.trim().length() != 0) {
                        sSorId = sSorId.trim();
                        queryArg = " AND sor_id = ? AND contact_type = ?";

                        logger.info("{}{}SCDBH.RSC.08 : {}{}", sClassName, sMethodName, "DBTOOLS05",
                                "Remove SQL = " + removeServiceContactSql + queryArg);

						 removeServiceContactSql = removeServiceContactSql + queryArg;
						objService.add(null); objService.set(nIndex++, sSorInvariantId);
						objService.add(null); objService.set(nIndex++, sSorId);
						objService.add(null); objService.set(nIndex++, sContactType);
					} else if (sSorName != null && !sSorName.trim().isEmpty()) {
                        sSorName = sSorName.trim();
                        queryArg = " AND sor_id = (SELECT sor_id FROM systemofrecord WHERE sor_name = ?) AND contact_type = ?";

                        logger.info("{}{}SCDBH.RSC.09 : {}{}", sClassName, sMethodName, "DBTOOLS06",
                                "Remove SQL = " + removeServiceContactSql + queryArg);

					   removeServiceContactSql = removeServiceContactSql + queryArg;
					//	DELETE FROM servicecontact WHERE sor_invariant_id = ?  AND sor_id = (SELECT sor_id FROM systemofrecord WHERE sor_name = ?) AND contact_type = ?
						objService.add(null); objService.set(nIndex++, sSorInvariantId);
						objService.add(null); objService.set(nIndex++, sSorName);
						objService.add(null); objService.set(nIndex++, sContactType);
					   }
                    if (sMobilityInvariantId != null && !sMobilityInvariantId.isEmpty()) { // Oct 2013 mobility_Invariant_id is sent from Atlas
						objService.add(null); objService.set(nIndex++, sMobilityInvariantId);

                    } else {
						objService.add(null); objService.set(nIndex++, sSorInvariantId);

                        if (sTransactionName == null || !sTransactionName.equalsIgnoreCase("RemoveAccount")) {
							objService.add(null); objService.set(nIndex++, sContactType);
                        }
                    }

                    long tTime = 0;
                    Date dtStartDate = new Date();

                    rowCount += jdbcTemplate.update(removeServiceContactSql, objService.toArray());

                    if (rowCount == 0) {
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
								"No Record found for given sor and sor_invariant_id");
					} else {
						hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
								"SERVICECONTACT attributes removed successfully ");
					}
                    tTime = (System.currentTimeMillis() - dtStartDate.getTime());
					logger.info("{}{}SCDBH.RSC.10 : Total time taken to execute query = {} milliseconds", sClassName, sMethodName, tTime);


				} else {
                    hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM,
                            "servicecontact hash is null or empty in input");
                    return hmResult;
                }
            } //end of for loop

			logger.info("{}{}SCDBH.RSC.11 : {}{}", 0, sClassName, sMethodName, "DBTOOLS07",
					"No of rows removed:= " + rowCount);

			hmResult = CommonErrorMap.makeCategoryMap (CommonDefs.COMMON_SUCCESS_NUM,
					"No of rows removed:= " + rowCount );

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);

			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}SCDBH.RSC.12 : {}{}", Integer.parseInt(errorCode),
					sClassName, sMethodName, "DBTOOLS_E2", "Error: " + e.getMessage());

			logger.error("{}{}SCDBH.RSC.13 : {}{}",e, Integer.parseInt(errorCode),
					sClassName, sMethodName, "DBTOOLS_E3", "::Exception = ");

			//return hmResult;

		} finally {

			if ( hmResult == null || hmResult.isEmpty() ) {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM,
						"Error while removing entry from TSERVICECONTACT");
			}
			logger.error("{}{}SCDBH.RSC.14 : {}{}",sClassName, sMethodName, "DBTOOLS999", dtStart.getTime(), hmResult);
		}

		return hmResult;
	}

	/**
	 *
	 * @param hmInput
     * @return HashMap
	 */
	public HashMap addServiceContact (HashMap hmInput)
	{
		String sMethodName = "addServiceContact";

		HashMap hmResult = null;
		String stAppInfo = null;
		int sor_id = -1;
		PreparedStatement prepStmt = null;

		String addServiceContactSql = "INSERT INTO servicecontact("	+
				"SOR_ID, " +
				"SOR_INVARIANT_ID, " +
				"CONTACT_TYPE, " +
				"PHONE_NUMBER, " +
				"PHONE_NUMBER_EXT, " +
				"PHONE_NUMBER_TYPE, " +
				"EMAIL_ADDRESS, " +
				"CONTACT_STATUS, " +
				"DATE_ESTABLISHED, " +
				"LAST_MODIFIED_BY, " +
				"MOBILITY_INVARIANT_ID, "+
				"VALIDATION_STATUS, "+
				"VALIDATION_INITIATED_DATE"+
				") VALUES(" +
				"?, ?, ?, ?, ?, ?, ?, ?, SYSDATE, ?, ?, ?, ?)";

		logger.info("{}{}SCDBH.ASC.01: CVS KEYWORDS: {}", sClassName, sMethodName, INFO);
		logger.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmInput));

		try {

			if (jdbcTemplate == null) {

				stAppInfo = "Error null connection, no row inserted";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM,
						stAppInfo);
				logger.info("{}{}SCDBH.ASC.03 : {}", sClassName,sMethodName, stAppInfo);
				return hmResult;

			}

			int nIndex = 0;
			List<Object> objService = new ArrayList<>();

			logger.debug("{}{}SCDBH.ASC.04 : {}{}", sClassName, sMethodName,
					"DB_ASC_H_SQL000", "addServiceContactSql: "	+ addServiceContactSql);

			String stLastModifiedBy = (String) hmInput
					.get(MPSDefs.DB_LAST_MODIFIED_BY);

			if (stLastModifiedBy == null
					|| stLastModifiedBy.trim().isEmpty()) {
				stAppInfo = "last_modified_by is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(
						MPSDefs.ERR_EMPTY_NUM, stAppInfo);
				logger.info("{}{}SCDBH.ASC.05 : {}",  sClassName,sMethodName, stAppInfo);
				return hmResult;
			}

			logger.debug("{}{}SCDBH.ASC.06 : {}", sClassName, sMethodName, stLastModifiedBy);

			ArrayList alServiceContacts = (ArrayList) hmInput
					.get("servicecontact");
			if (alServiceContacts == null || alServiceContacts.isEmpty()) {
				stAppInfo = "servicecontact list is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(
						MPSDefs.ERR_EMPTY_NUM, stAppInfo);
				logger.info("{}{}SCDBH.ASC.07 : {}", sClassName,sMethodName, stAppInfo);
				return hmResult;
			}
			HashMap hmServiceContact=null;
			List<Object[]> listArr = new ArrayList<Object[]>();
			//Iterate through each servicecontact to insert rows
            for (Object alServiceContact : alServiceContacts) {
                hmServiceContact = (HashMap) alServiceContact;

                if (hmServiceContact != null && !hmServiceContact.isEmpty()) {
                    String stSorInvariantId = (String) hmServiceContact
                            .get(MPSDefs.DB_SOR_INVARIANT_ID);
                    String stSorName = (String) hmServiceContact
                            .get(MPSDefs.DB_SOR_NAME);
                    String stSorId = (String) hmServiceContact
                            .get(MPSDefs.DB_SOR_ID);
                    String stContactType = (String) hmServiceContact
                            .get(MPSDefs.DB_CONTACT_TYPE);
                    String stPhoneNumber = (String) hmServiceContact
                            .get(MPSDefs.DB_PHONE_NUMBER);
                    String stPhoneNumberExt = (String) hmServiceContact
                            .get(MPSDefs.DB_PHONE_NUMBER_EXT);
                    String stPhoneNumberType = (String) hmServiceContact
                            .get(MPSDefs.DB_PHONE_NUMBER_TYPE);
                    String stEmailAddress = (String) hmServiceContact
                            .get(MPSDefs.DB_EMAIL_ADDRESS);
                    String stContactStatus = (String) hmServiceContact
                            .get(MPSDefs.DB_CONTACT_STATUS);
                    String stMobilityInvariantId = (String) hmServiceContact.get(MPSDefs.DB_MOBILITY_INVARIANT_ID);

                    //1510 - Updated for PID271080c Capture ATT and Non ATT CBRs for Home Solutions - US#424870
                    String sValidationStatus = (String) hmServiceContact.get(MPSDefs.DB_VALIDATION_STATUS);

                    //validate input
                    if (stSorInvariantId == null
                            || stSorInvariantId.trim().length() <= 0
                            || stContactType == null
                            || stContactType.trim().length() <= 0) {

                        stAppInfo = "sor_invariant_id and/or contact_type is null or empty in input";
                        hmResult = CommonErrorMap.makeCategoryMap(
                                MPSDefs.ERR_EMPTY_NUM, stAppInfo);
                        logger.info("{}{}SCDBH.ASC.08 : {}", sClassName, sMethodName, stAppInfo);
                        return hmResult;
                    }

                    if ((stSorId == null || stSorId.trim().length() <= 0)
                            && (stSorName == null || stSorName.trim().length() <= 0)) {

                        stAppInfo = "sor_id and sor_name both are null or empty in input";
                        hmResult = CommonErrorMap.makeCategoryMap(
                                MPSDefs.ERR_EMPTY_NUM, stAppInfo);
                        logger.info("{}{}SCDBH.ASC.09 : {}",sClassName, sMethodName,stAppInfo);
                        return hmResult;
                    }

                    if (stSorId != null && !stSorId.trim().isEmpty()) {
                        sor_id = Integer.parseInt(stSorId);
                    } else {
                        sor_id = oDBHelper.getSorId(stSorName);
                    }

                    if (sor_id == -1) {
                        stAppInfo = "Input sor_name/sor_id is not valid";
                        hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                        logger.info("{}{} SCDBH.ASC.10 : {}",  sClassName, sMethodName,stAppInfo);
						return hmResult;
                    }

					objService.add(null);objService.set(nIndex++, sor_id);
                    logger.debug("{}{}SCDBH.ASC.11 : {}", sClassName, sMethodName, sor_id);

					objService.add(null);objService.set(nIndex++, stSorInvariantId);
                    logger.debug("{}{}SCDBH.ASC.12 : {}", sClassName, sMethodName,stSorInvariantId);

					objService.add(null);objService.set(nIndex++, stContactType);
                    logger.debug("{}{}SCDBH.ASC.13 : {}", sClassName, sMethodName,stContactType);


                    if (stPhoneNumber != null) {
						objService.add(null);objService.set(nIndex++, stPhoneNumber);
                        logger.debug("{}{}SCDBH.ASC.14 : {}", sClassName, sMethodName,stPhoneNumber);

                    } else {
						objService.add(null); objService.set(nIndex++, java.sql.Types.VARCHAR);
                        logger.debug("{}{}SCDBH.ASC.15 : {}", sClassName, sMethodName,stPhoneNumber);

                    }

                    if (stPhoneNumberExt != null) {
						objService.add(null);objService.set(nIndex++, stPhoneNumberExt);
                        logger.debug("{}{}SCDBH.ASC.16 : {}", sClassName, sMethodName,stPhoneNumberExt);

                    } else {
						objService.add(null);objService.set(nIndex++, java.sql.Types.VARCHAR);
                        logger.debug("{}{}SCDBH.ASC.17 : {}", sClassName, sMethodName,stPhoneNumberExt);

                    }

                    if (stPhoneNumberType != null) {
						objService.add(null);objService.set(nIndex++, stPhoneNumberType);
                        logger.debug("{}{}SCDBH.ASC.18 : {}", sClassName, sMethodName,stPhoneNumberType);

                    } else {
						objService.add(null);objService.set(nIndex++, java.sql.Types.VARCHAR);
                        logger.debug("{}{}SCDBH.ASC.19 : {}", sClassName, sMethodName,stPhoneNumberType);

                    }

                    if (stEmailAddress != null) {
                        //1602 - Updated for SID42938 - to lower case emailAddress when inserting/updating in MPS DB
                        if (!stEmailAddress.isEmpty()) {
                            stEmailAddress = stEmailAddress.toLowerCase();
                        }
						objService.add(null);objService.set(nIndex++, stEmailAddress);
                        logger.debug("{}{}SCDBH.ASC.20 : {}", sClassName, sMethodName,stEmailAddress);

                    } else {
						objService.add(null);objService.set(nIndex++, java.sql.Types.VARCHAR);
                        logger.debug("{}{}SCDBH.ASC.21 : {}", sClassName, sMethodName,stEmailAddress);

                    }

                    if (stContactStatus != null) {
						objService.add(null);objService.set(nIndex++, stContactStatus);
                        logger.debug("{}{}SCDBH.ASC.22 : {}", sClassName, sMethodName,stContactStatus);

                    } else {
						objService.add(null);objService.set(nIndex++, java.sql.Types.CHAR);
                        logger.debug("{}{}SCDBH.ASC.23 : {}", sClassName, sMethodName,stContactStatus);

                    }

					java.sql.Date sysDate = null;
					Date dtStartDate = CommonUtil.getDate();//1704 - Changed to avoid CAST VIOLATION in 1607
					sysDate = CommonUtil.getSQLDate(dtStartDate.getTime());
					objService.add(null);objService.set(nIndex++, sysDate);
					logger.debug("{}{}SCDBH.ASC.23.1 : {}", sClassName, sMethodName,  sysDate);

					if(stLastModifiedBy != null) {
						objService.add(null);
						objService.set(nIndex++, stLastModifiedBy);
						logger.debug("{}{}SCDBH.ASC.23.2 : {}", sClassName, sMethodName, stLastModifiedBy);
					}
                    if (stMobilityInvariantId != null) {
						objService.add(null);objService.set(nIndex++, stMobilityInvariantId);
						logger.debug("{}{}SCDBH.ASC.24 : {}", sClassName, sMethodName, stMobilityInvariantId);
                    } else {
						objService.add(null);objService.set(nIndex++, java.sql.Types.CHAR);
                        logger.debug("{}{}SCDBH.ASC.25 : {}", sClassName, sMethodName,stMobilityInvariantId);

                    }

                    //1510 - Updated for PID271080c Capture ATT and Non ATT CBRs for Home Solutions - US#424870
                    if (sValidationStatus != null && !sValidationStatus.isEmpty()) {
                        String sValidationStatusCode = statusValidation.getStatusCodeByName(sValidationStatus);

                        if (sValidationStatusCode == null || sValidationStatusCode.isEmpty()) {
                            stAppInfo = "input validation_status is not valid as its not present in MPS DB";
                            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                            logger.info("{}{}SCDBH.ASC.26 : {}{}", CErrorDefs.ERR_INVALID_DATA_NUM, sClassName, sMethodName, stAppInfo);
                            return hmResult;
                        }
                        //Date dtStartDate = new Date();//1704 - Commented due to CAST VIOLATION in 1607

						objService.add(null);objService.set(nIndex++, sValidationStatusCode);
                        logger.debug("{}{}SCDBH.ASC.27 : {}", sClassName, sMethodName,  sValidationStatusCode);
						objService.add(null);objService.set(nIndex++, sysDate);
                        logger.debug("{}{}SCDBH.ASC.28 : {}", sClassName, sMethodName,  sysDate);
                    } else {
						objService.add(null);objService.set(nIndex++, java.sql.Types.VARCHAR);
                        logger.debug("{}{}SCDBH.ASC.29 : {}", sClassName, sMethodName, sValidationStatus);
						objService.add(null);objService.set(nIndex++, java.sql.Types.DATE);
                        logger.debug("{}{}SCDBH.ASC.30 : {}", sClassName, sMethodName, sysDate);
                    }//END

                    listArr.add(objService.toArray());

                } else {
                    stAppInfo = "servicecontact hash is null or empty in input";
                    hmResult = CommonErrorMap.makeCategoryMap(
                            MPSDefs.ERR_EMPTY_NUM, stAppInfo);
                    logger.info("{}{}SCDBH.ASC.31 : {}", sClassName,sMethodName, stAppInfo);
                    return hmResult;
                }
            } //end of for loop

			long tTime = 0;
			Date dtStartDate = new Date();

			int[] totalRowCount = jdbcTemplate.batchUpdate(addServiceContactSql, listArr);

			tTime = (System.currentTimeMillis() - dtStartDate.getTime()) ;
			logger.info("{}{}SCDBH.ASC.32 : Total time taken to execute query = {} milliseconds", sClassName, sMethodName, tTime);


			if (totalRowCount.length < alServiceContacts.size()) {
				stAppInfo = "Insert Query not executed properly";
				hmResult = CommonErrorMap.makeCategoryMap(
						CommonErrorMap.ERR_DB_NUM, stAppInfo);
				logger.info("{}{}SCDBH.ASC.33 : {}", sClassName,sMethodName, stAppInfo);
				return hmResult;
			}

			hmResult = CommonErrorMap.makeCategoryMap(
					CommonDefs.COMMON_SUCCESS_NUM, "No of rows inserted:= "
							+ totalRowCount.length);

			logger.info("{}{}SCDBH.ASC.34 : {}", sClassName, sMethodName, totalRowCount.length);


		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}SCDBH.ASC.35 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}SCDBH.ASC.36: Exception = {}", sClassName, sMethodName, errorCode);
			return hmResult;

		} finally {
			logger.info("{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);
		}

		return hmResult;
	}

	/**
	 *
	 * @param hmInput
	 * @return HashMap
	 */
	//1510 - US503078
	public HashMap updateServiceContactByPhoneNumber(HashMap hmInput)
	{

		String sMethodName = "updateServiceContactByPhoneNumber";
		HashMap hmResult = null;
		PreparedStatement prepStmt = null;

		StringBuilder updateServiceContactByPhoneNumber = new StringBuilder(
				"UPDATE SERVICECONTACT SET last_modified_by = ?, ");

		logger.info("{}{}SCDBH.USCBPH.01: CVS KEYWORDS: {}", sClassName, sMethodName, INFO);
		logger.info("{}{}DBTOOLS000 : InpParam : {}", sClassName, sMethodName, StructuredArguments.entries(hmInput));


		try
		{
			//validate input arguments
			String sPhoneNumber = "";
			String sOldPhoneNumber = (String) hmInput.get("oldPhoneNumber");
			String sInputPhoneNumber = (String) hmInput.get(MPSDefs.DB_PHONE_NUMBER);
			String stValidationStatusFlag = (String) hmInput.get(CommonDefs.VALIDATION_STATUS_FLAG);
			String stValidationInitDateFlag = (String) hmInput.get(CommonDefs.VALIDATION_INIT_DATE_FLAG);

			sPhoneNumber = 	sOldPhoneNumber != null ? sOldPhoneNumber : sInputPhoneNumber;

			if(sPhoneNumber == null || sPhoneNumber.trim().length() <= 0 ){
				hmResult = CommonErrorMap.makeCategoryMap (MPSDefs.ERR_EMPTY_NUM,
						"PhoneNumber is null or empty in input");
				return hmResult;
			}

			List<Object> objService = new ArrayList<Object>();
			int nIndex = 0;
			String sKey = null;
			Iterator itr = SERVICE_CONTACT_UPD_ATTRS_BY_PHONE.iterator();
			while (itr.hasNext()) {
				sKey = (String) itr.next();

				if (hmInput.containsKey(sKey))
				{
					if (nIndex > 0 && nIndex < SERVICE_CONTACT_UPD_ATTRS_BY_PHONE.size())
						updateServiceContactByPhoneNumber.append(", ");

					updateServiceContactByPhoneNumber.append(sKey + "=?");
					nIndex++;
				}
			}

			if(stValidationStatusFlag != null && stValidationStatusFlag.equals(MPSDefs.NO)){
				updateServiceContactByPhoneNumber.append(", validation_status" + " = '' ");
			}
			if(stValidationInitDateFlag != null && stValidationInitDateFlag.equals(MPSDefs.NO)){
				updateServiceContactByPhoneNumber.append(", validation_initiated_date" + " = '' ");
			}

			if (hmInput.containsKey(MPSDefs.DB_PHONE_NUMBER) || hmInput.containsKey(MPSDefs.DB_PHONE_NUMBER_EXT) ||
					hmInput.containsKey(MPSDefs.DB_EMAIL_ADDRESS) ){
				updateServiceContactByPhoneNumber.append(", date_established = SYSDATE ");
			}

			updateServiceContactByPhoneNumber.append("  WHERE phone_number = ?");

			logger.info("{}{}SCDBH.USCBPH.02 : {}", sClassName, sMethodName,  updateServiceContactByPhoneNumber);

			nIndex = 0;
			objService.add(null);objService.set(nIndex++, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));

			itr = SERVICE_CONTACT_UPD_ATTRS_BY_PHONE.iterator();
			while (itr.hasNext()) {
				sKey = (String) itr.next();

				if (hmInput.containsKey(sKey)) {
					//nIndex++;
					objService.add(null);objService.set(nIndex++, hmInput.get(sKey));
				}
			}

			objService.add(null);objService.set(nIndex++, sPhoneNumber);

			long tTime = 0;
			Date dtStartDate = new Date();

			int rowCount = jdbcTemplate.update(updateServiceContactByPhoneNumber.toString(), objService.toArray());

			tTime = (System.currentTimeMillis() - dtStartDate.getTime()) ;

			logger.info("{}{}SCDBH.USCBPH.03 : Total time taken to execute query = {} milliseconds", sClassName, sMethodName, tTime);


			if (rowCount == 0) {
				hmResult = CommonErrorMap.makeCategoryMap (CErrorDefs.ERR_REC_NOT_FOUND_NUM,
						"No Record found for given phone_number");
			} else {
				hmResult = CommonErrorMap.makeCategoryMap (CommonDefs.COMMON_SUCCESS_NUM,
						"SERVICECONTACT attributes updated successfully ");
			}

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}SCDBH.USCBPH.04 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}SCDBH.USCBPH.05 : Exception = {}", sClassName, sMethodName, errorCode);
			return hmResult;

		} finally {
			logger.info("{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, hmResult);
		}

		return hmResult;
	}

}
