package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TSECURITYACCOUNT", schema = "MPS_OWNER")
public class Tsecurityaccount implements java.io.Serializable {

	private static final long serialVersionUID = 4571901002904040844L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "identificationType", column = @Column(name = "IDENTIFICATION_TYPE", nullable = false, length = 10)),
			@AttributeOverride(name = "accountId", column = @Column(name = "ACCOUNT_ID", nullable = false, length = 60)) })
	private TsecurityaccountId id;

	@Column(name = "ACCOUNT_TYPE", length = 1)
	private Character accountType;

	@Column(name = "ACCOUNT_REGION", length = 2)
	private String accountRegion;

	@Column(name = "CUMULATIVE_FAILURE_COUNT", nullable = false, precision = 22, scale = 0)
	private Long cumulativeFailureCount;

	@Column(name = "ACCOUNT_ENTRY_EXPIRES", nullable = false, length = 7)
	private Date accountEntryExpires;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;

	@Column(name = "SOR_INVARIANT_ID")
	private String sorInvariantId;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tsecurityaccount")
	private Set<Tsecuritycode> tsecuritycodes = new HashSet<>(0);
}