package com.att.idp.idgraphusermanagementms.db.repository;

/**
 * This is a custom repository interface for SystemOfRecord related operations.
 * Additional methods for SystemOfRecord operations should be declared here.
 */
public interface SystemOfRecordRepositoryCustom {
	
}
