package com.att.idp.idgraphusermanagementms.db.response;

import java.io.Serializable;
import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * This is the MemberGroupResponse class which implements Serializable interface.
 * It represents a response for a member group with properties like groupNum, parentName, createDate, lastModified, lastModifiedBy, premium800Ind, bulkBillingInd, and accessCode.
 * Each property has its respective getter and setter methods.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({


})
public class MemberGroupResponse implements Serializable{

	private static final long serialVersionUID = 7797513468715346801L;

	private Long groupNum;
	private String parentName;
	private Date createDate;
	private Date lastModified;
	private String lastModifiedBy;
	private Character premium800Ind;
	private Character bulkBillingInd;
	private String accessCode;
}