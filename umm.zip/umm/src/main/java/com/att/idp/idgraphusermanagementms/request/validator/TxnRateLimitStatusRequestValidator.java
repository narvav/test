package com.att.idp.idgraphusermanagementms.request.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import jakarta.validation.Valid;
import jakarta.ws.rs.core.HttpHeaders;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.resource.request.TransactionRateLimitRequest;
import com.att.idp.idgraphusermanagementms.resource.response.TransactionRateLimitResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;

/**
 * This class, TxnRateLimitStatusRequestValidator, is responsible for validating the TransactionRateLimitRequest.
 * It checks for the presence and validity of required fields in the request, and returns a TransactionRateLimitResponse accordingly.
 * It is annotated with @Component, @Configuration, and @PropertySource to indicate that it's a Spring Bean,
 * to allow it to access configuration properties, and to specify the location of the properties file respectively.
 *
 * The class contains several methods, including:
 * - txnRateLimitStatusRequestValidator: the main method that orchestrates the validation process.
 * - transRateLimitInputValidator: a method that validates the input fields in the request.
 * - transRateLimitCSIValidator: a method that validates the 'CSI' field in the request.
 * - transRateLimitIsExternalCallCheck: a method that checks if the request is an external call.
 * - transRateLimitErrorResponse: a helper method that generates an error response.
 * - isNumeric: a method that checks if a string is numeric.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class TxnRateLimitStatusRequestValidator {

	private static final Logger logger = LoggerFactory.getLogger(TxnRateLimitStatusRequestValidator.class);

	private String sClassName = "TxnRateLimitStatusRequestValidator";

	@Value("${ValidIPRateLimitCSI}")
	private String propValidCallersForTransLateLimit;

	/**
	 * This method is responsible for validating the TransactionRateLimitRequest.
	 * It takes HttpHeaders and TransactionRateLimitRequest as parameters.
	 * HttpHeaders contains the request headers which may include additional information required for processing the request.
	 * TransactionRateLimitRequest encapsulates the details of the transaction rate limit operation to be performed.
	 *
	 * The method performs various checks and validations on the input parameters and returns a TransactionRateLimitResponse object.
	 * The TransactionRateLimitResponse object encapsulates the result of the transaction rate limit operation.
	 *
	 * @param httpHeader The HttpHeaders containing the request headers.
	 * @param transactionRateLimitReq The TransactionRateLimitRequest containing the details of the transaction rate limit operation.
	 * @return TransactionRateLimitResponse The response of the transaction rate limit operation.
	 */
	public TransactionRateLimitResponse txnRateLimitStatusRequestValidator(HttpHeaders httpHeader,
			@Valid TransactionRateLimitRequest transactionRateLimitReq) {

		String sMethodName = ".txnRateLimitStatusRequestValidator.";
		String stAppInfo = null;
		String stIdpTraceId = null;

		TransactionRateLimitResponse transRateLimitResponse = null;

		stIdpTraceId = CommonUtil.getTraceId(httpHeader);

		if (stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
			stAppInfo = "Missing or Invalid IdpTraceId";
			return transRateLimitErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (transactionRateLimitReq == null) {
			stAppInfo = "Input Request is NULL / Empty.";
			logger.info("{}{}TRLRV_01 :: {}", sClassName, sMethodName, stAppInfo);
			return transRateLimitErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		
		transactionRateLimitReq.setIdpTraceId(stIdpTraceId);

		// checking Invalid attributes passed in Request
		Map<String, Object> allUnknownAttributes = new HashMap<>(transactionRateLimitReq.unknownAttributes);

		if (!allUnknownAttributes.isEmpty()) {
			stAppInfo = "Invalid Attributes passed in TransactionRateLimitRequest : " + allUnknownAttributes;
			return transRateLimitErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					transactionRateLimitReq.getIdpTraceId());
		}

		try {
			transRateLimitResponse = transRateLimitInputValidator(transactionRateLimitReq, httpHeader);
			if (transRateLimitResponse != null) {
				logger.info("{}{}TRLRV_04 : Response from transRateLimitInputValidator : {}", sClassName, sMethodName,
						transRateLimitResponse);
				return transRateLimitResponse;
			}

			transRateLimitResponse = transRateLimitCSIValidator(transactionRateLimitReq);
			if (transRateLimitResponse != null) {
				logger.info("{}{}TRLRV_05 : Response from transRateLimitCSIValidator : {}", sClassName, sMethodName,
						transRateLimitResponse);
				return transRateLimitResponse;
			}

			stAppInfo = "Input Validation Successful";
			logger.info("{}{}TRLRV_06 : {}", sClassName, sMethodName, stAppInfo);

		} catch (Exception e) {
			stAppInfo = "Exception thrown in TxnRateLimitStatusRequestValidator : " + e.getMessage();
			transRateLimitResponse = transRateLimitErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo, stIdpTraceId);
			logger.info("{}{}TRLRV_07: Exception in TxnRateLimitStatusRequestValidator: {}", sClassName, sMethodName,
					stAppInfo);
		}

		return transRateLimitResponse;
	}

	private TransactionRateLimitResponse transRateLimitInputValidator(
			TransactionRateLimitRequest transactionRateLimitReq, HttpHeaders httpHeader) {

		String sMethodName = "transRateLimitInputValidator";
		String stAppInfo = null;
		String sCtn = transactionRateLimitReq.getCtn();
		String sIpAddress = transactionRateLimitReq.getIpAddress();

		String sIsExternalCall = transactionRateLimitReq.getIsExternalCall();
		String sCallingSystemId = httpHeader.getHeaderString("X-ATT-ClientId");

		Optional.ofNullable(sCtn).ifPresent(x -> transactionRateLimitReq.setCtn(x.trim()));
		Optional.ofNullable(sIpAddress).ifPresent(x -> transactionRateLimitReq.setIpAddress(x.trim()));
		Optional.ofNullable(sIsExternalCall).ifPresent(x -> transactionRateLimitReq.setIsExternalCall(x.trim()));

		if (sCallingSystemId == null || sCallingSystemId.isEmpty()) {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			logger.info("{}{}TRLRV_IV.01 : {}", sClassName, sMethodName, stAppInfo);
			return transRateLimitErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					transactionRateLimitReq.getIdpTraceId());
		}
		transactionRateLimitReq.setCallingSystemId(sCallingSystemId.trim().toUpperCase());

		if ((sCtn == null || sCtn.trim().isEmpty()) && (sIpAddress == null || sIpAddress.trim().isEmpty())) {
			stAppInfo = "Both CTN and IpAddress are null or empty";
			logger.info("{}{}TRLRV_IV.02 :  {} ", sClassName, sMethodName, stAppInfo);
			return transRateLimitErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					transactionRateLimitReq.getIdpTraceId());
		}
		if (sCtn!=null && !isNumeric(sCtn))
		{
			stAppInfo = "CTN has to be numeric " ;
			logger.info("{}{}TRLRV_IV.03 : {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
			return transRateLimitErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,transactionRateLimitReq.getIdpTraceId());
		}

		return null;
	}

	/**
	 * This method is part of the TxnRateLimitStatusRequestValidator class.
	 * It is responsible for checking if a given string is numeric.
	 * The method takes a string as input.
	 * The method uses a regular expression to check if the string is numeric or not.
	 * The regular expression used is "(^$|[0-9]{10})", which checks if the string is either empty or contains exactly 10 digits.
	 * The method returns true if the string is numeric (or empty), and false otherwise.
	 *
	 * @param strNum The string to be checked.
	 * @return boolean The result of the numeric check.
	 */
	public static boolean isNumeric(String strNum) {
		return strNum.matches("(^$|[0-9]{10})");
	}
	private TransactionRateLimitResponse transRateLimitCSIValidator(
			TransactionRateLimitRequest transactionRateLimitReq) {

		TransactionRateLimitResponse transRateLimitResponse = null;

		String sMethodName = null;
		String stAppInfo = null;

		ArrayList alValidCallers = null;

		transRateLimitResponse = transRateLimitIsExternalCallCheck(transactionRateLimitReq);
		if (transRateLimitResponse != null) {
			logger.info("{}{}TRLRV_CSI.01 Response from transRateLimitCSIValidator : {}", sClassName, sMethodName,
					transRateLimitResponse);
			return transRateLimitResponse;
		}

		String sCallingSystemId = transactionRateLimitReq.getCallingSystemId();
		String sIsExternalCall = transactionRateLimitReq.getIsExternalCall();

		if (propValidCallersForTransLateLimit != null && !propValidCallersForTransLateLimit.isEmpty()) {
			alValidCallers = CommonUtil.parseToArray(propValidCallersForTransLateLimit,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			logger.info("{}{}TRLRV_CSI.02 : transRateLimitCallingSystemIds : {}", sClassName, sMethodName,
					alValidCallers);
			if (sIsExternalCall != null && CommonDefs.IND_Y.equals(sIsExternalCall) && alValidCallers != null
					&& !alValidCallers.contains(sCallingSystemId)) {
				stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
				logger.info("{}{}TRLRV_CSI.03 :  {} ", sClassName, sMethodName, stAppInfo);
				return transRateLimitErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						transactionRateLimitReq.getIdpTraceId());
			}
		}
		return transRateLimitResponse;
	}

	private TransactionRateLimitResponse transRateLimitIsExternalCallCheck(
			TransactionRateLimitRequest transactionRateLimitReq) {
		TransactionRateLimitResponse transRateLimitResponse = null;
		String stAppInfo = null;
		String isExternalCall = transactionRateLimitReq.getIsExternalCall();
		String stIdpTraceId = transactionRateLimitReq.getIdpTraceId();

		if ((isExternalCall != null && !isExternalCall.isEmpty())) {
			if (!(isExternalCall.equalsIgnoreCase(CommonDefs.IND_Y)
					|| isExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
				stAppInfo = "isExternalCall must be one of Y or N";
				return transRateLimitErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			} else {
				transactionRateLimitReq.setIsExternalCall(isExternalCall.trim().toUpperCase());
			}
		} else {
			transactionRateLimitReq.setIsExternalCall(CommonDefs.IND_Y);
		}
		return transRateLimitResponse;
	}

	private TransactionRateLimitResponse transRateLimitErrorResponse(int appStatusCode, String stAppInfo,
			String stIdpTraceId) {

		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		hmResponse.put(CommonDefs.TRANSACTION_NAME, CommonDefs.TXN_RATE_LIMIT_STATUS);
		return CommonUtilHelper.generateTxnRateLimitStatusResponse(hmResponse);
	}

}
