package com.att.idp.idgraphusermanagementms.db.helper;

import java.sql.PreparedStatement;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;


@Component
public class ServiceNotificationDBHelper {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private DBHelper dBHelper;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	private static final String info = "@(#) RcsModuleId = $Id$ $HeadURL$";

	private static final String sClassName = "ServiceNotificationDBHelper";

	private static String sRemoveServiceNotificationSql = "DELETE FROM SERVICENOTIFICATION WHERE SOR_INVARIANT_ID = ? ";

	public static final Set SERVICE_NOTIFICATION_UPDATBLE_ATTRS = new HashSet();

	public static final Logger logger = LoggerFactory.getLogger(ServiceInfoDBHelper.class);

	static {
		//SERVICE_NOTIFICATION_UPDATBLE_ATTRS.add(MPSDefs.DB_NOTIFICATION_METHOD); // Updated for June 2014 US#253897
		SERVICE_NOTIFICATION_UPDATBLE_ATTRS.add(MPSDefs.DB_NOTIFICATION_THRESHOLD);
	}
	/**
	 *
	 * @param hmInput
	 * @return HashMap
	 */
	public HashMap addServiceNotification(HashMap hmInput)
	{
		String sMethodName = "addServiceNotification";
		HashMap hmResult = null;
		PreparedStatement prepStmt = null;
		String stAppInfo = null;
		int sor_id = -1;
		int notification_id = -1;

		String stAddServiceNotificationSql = "INSERT INTO servicenotification(" +
				"SOR_ID, " +
				"SOR_INVARIANT_ID, " +
				"NOTIFICATION_ID, " +
				"NOTIFICATION_METHOD, " +
				"NOTIFICATION_THRESHOLD, " +
				"DATE_ESTABLISHED, " +
				"LAST_MODIFIED_BY " +
				") VALUES(" +
				"?, ?, ?, ?, ?, SYSDATE, ?)";

		logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DB_ASN_H_01",
				"CVS KEYWORDS: " + info);

		logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS000",
				"Input Hash is: " + hmInput);

		Date dtStart = new Date();
		List<Object[]> listArr = new ArrayList<Object[]>();
		List<Object> objService = new ArrayList<Object>();

		try {
			if (jdbcTemplate == null) {

				stAppInfo = "Error null connection, no row inserted";
				hmResult = CommonErrorMap.makeCategoryMap(
						MPSDefs.ERR_DB_NUM, stAppInfo);
				logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_DB_NUM, sClassName,
						sMethodName, "DB_ASN_H_02", stAppInfo);
				return hmResult;

			}

			logger.debug("{}{}AUH_117.1 : {}{}",sClassName, sMethodName,"DB_ASN_H_SQL000","addServiceNotificationSql: "+stAddServiceNotificationSql);

			//prepStmt = conn.prepareStatement(stAddServiceNotificationSql);

			String stLastModifiedBy = (String) hmInput
					.get(MPSDefs.DB_LAST_MODIFIED_BY);

			if (stLastModifiedBy == null
					|| stLastModifiedBy.trim().length() == 0) {
				stAppInfo = "last_modified_by is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(
						MPSDefs.ERR_EMPTY_NUM, stAppInfo);
				logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_EMPTY_NUM, sClassName,
						sMethodName, "DB_ASN_H_03", stAppInfo);
				return hmResult;
			}

			ArrayList alServiceNotification = (ArrayList) hmInput
					.get("servicenotification");
			if (alServiceNotification == null
					|| alServiceNotification.size() <= 0) {
				stAppInfo = "servicenotification list is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(
						MPSDefs.ERR_EMPTY_NUM, stAppInfo);
				logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_EMPTY_NUM, sClassName,
						sMethodName, "DB_ASN_H_05", stAppInfo);
				return hmResult;
			}

			//Iterate through each servicenotification to insert rows
			for (int i = 0; i < alServiceNotification.size(); i++) {
				HashMap hmServiceNotification = (HashMap) alServiceNotification
						.get(i);

				if (hmServiceNotification != null
						&& !hmServiceNotification.isEmpty()) {
					String stSorInvariantId = (String) hmServiceNotification
							.get(MPSDefs.DB_SOR_INVARIANT_ID);
					String stSorName = (String) hmServiceNotification
							.get(MPSDefs.DB_SOR_NAME);
					String stSorId = (String) hmServiceNotification
							.get(MPSDefs.DB_SOR_ID);
					String stNotificationId = (String) hmServiceNotification
							.get(MPSDefs.DB_NOTIFICATION_ID);
					String stNotificationName = (String) hmServiceNotification
							.get(MPSDefs.DB_NOTIFICATION_NAME);
					String stNotificationMethod = (String) hmServiceNotification
							.get(MPSDefs.DB_NOTIFICATION_METHOD);
					String stNotificationThreshold = (String) hmServiceNotification
							.get(MPSDefs.DB_NOTIFICATION_THRESHOLD);

					//validate input
					if (stSorInvariantId == null
							|| stSorInvariantId.trim().length() <= 0
							|| stNotificationMethod == null
							|| stNotificationMethod.trim().length() <= 0) {

						stAppInfo = "sor_invariant_id and/or notification_method is null or empty in input";
						hmResult = CommonErrorMap
								.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM, stAppInfo);
						logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_EMPTY_NUM, sClassName,
								sMethodName, "DB_ASN_H_06", stAppInfo);
						return hmResult;
					}

					if ((stSorId == null || stSorId.trim().length() <= 0)
							&& (stSorName == null || stSorName.trim().length() <= 0)) {

						stAppInfo = "sor_id and sor_name both are null or empty in input";
						hmResult = CommonErrorMap
								.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM, stAppInfo);
						logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_EMPTY_NUM, sClassName,
								sMethodName, "DB_ASN_H_07", stAppInfo);
						return hmResult;
					}

					if ((stNotificationId == null || stNotificationId.trim().length() <= 0)
							&& (stNotificationName == null || stNotificationName.trim().length() <= 0)) {

						stAppInfo = "notification_id and notification_name both are null or empty in input";
						hmResult = CommonErrorMap
								.makeCategoryMap(MPSDefs.ERR_EMPTY_NUM, stAppInfo);
						logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_EMPTY_NUM, sClassName,
								sMethodName, "DB_ASN_H_08", stAppInfo);
						return hmResult;
					}

					if (stSorId != null && stSorId.trim().length() != 0) {
						sor_id = Integer.parseInt(stSorId);
					} else {
						sor_id = dBHelper.getSorId(stSorName);
					}

					if(stNotificationId != null && stNotificationId.trim().length() != 0){
						notification_id = Integer.parseInt(stNotificationId);
					} else {
						notification_id = dBHelper.getNotificationId(stNotificationName);						
					}

					if (sor_id == -1 || notification_id == -1) {
						if(notification_id == -1){
							stAppInfo = "Input notification_name/notification_id is not valid";
						} else {
							stAppInfo = "Input sor_name/sor_id is not valid";
						}
						hmResult = CommonErrorMap.makeCategoryMap(
								MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
						logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_INVALID_DATA_NUM,
								sClassName, sMethodName, "DB_ASN_H_09",
								stAppInfo);
						return hmResult;
					}

					objService.add(sor_id);
					logger.debug("{}{}AUH_117.1 : {}{}", sClassName, sMethodName,
							"DB_ASN_H_10", "sor_id::PARAM 1 = " + sor_id);

					objService.add(stSorInvariantId);
					logger.debug("{}{}AUH_117.1 : {}{}", sClassName, sMethodName,
							"DB_ASN_H_11", "sor_invariant_id::PARAM 2 = "
									+ stSorInvariantId);

					objService.add(notification_id);
					logger.debug("{}{}AUH_117.1 : {}{}", sClassName, sMethodName,
							"DB_ASN_H_12", "notification_id::PARAM 3 = "
									+ notification_id);

					objService.add(stNotificationMethod);
					logger.debug("{}{}AUH_117.1 : {}{}", sClassName, sMethodName,
							"DB_ASN_H_13", "notification_method::PARAM 4 = "
									+ stNotificationMethod);

					if (stNotificationThreshold != null) {
						objService.add(stNotificationThreshold);
						logger.debug("{}{}AUH_117.1 : {}{}", sClassName, sMethodName,
								"DB_ASN_H_14",
								"notification_threshold::PARAM 5 = "
										+ stNotificationThreshold);
					} else {
						objService.add(java.sql.Types.VARCHAR);
						logger.debug("{}{}AUH_117.1 : {}{}", sClassName, sMethodName,
								"DB_ASN_H_15",
								"notification_threshold::PARAM 5 = "
										+ stNotificationThreshold);
					}

					objService.add(stLastModifiedBy);
					logger.debug("{}{}AUH_117.1 : {}{}", sClassName, sMethodName,
							"DB_ASN_H_04", "last_modified_by::PARAM 6 = "
									+ stLastModifiedBy);

					//prepStmt.addBatch();
					listArr.add(objService.toArray());
				} else {
					stAppInfo = "servicenotification hash is null or empty in input";
					hmResult = CommonErrorMap.makeCategoryMap(
							MPSDefs.ERR_EMPTY_NUM, stAppInfo);
					logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_EMPTY_NUM, sClassName,
							sMethodName, "DB_ASN_H_16", stAppInfo);
					return hmResult;
				}
			} //end of for loop

			long tTime = 0;
			Date dtStartDate = new Date();

			//int totalRowCount[] = prepStmt.executeBatch();
			int totalRowCount[] = jdbcTemplate.batchUpdate(new String(stAddServiceNotificationSql), listArr);

			// Calculate the total time taken to insert rows in DB
			//to return time in milliseconds for APRIL2011-sa7153
			tTime = (System.currentTimeMillis() - dtStartDate.getTime());
			logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "QUERY999",
					"Total time taken to execute query = "
							+ tTime + " milliseconds");

			if (totalRowCount.length < alServiceNotification.size()) {
				stAppInfo = "Insert Query not executed properly";
				hmResult = CommonErrorMap.makeCategoryMap(
						CommonErrorMap.ERR_DB_NUM, stAppInfo);
				logger.info("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_DB_NUM, sClassName,
						sMethodName, "DB_ASN_H_17", stAppInfo);
				return hmResult;
			}

			hmResult = CommonErrorMap.makeCategoryMap(
					CommonDefs.COMMON_SUCCESS_NUM, "No of rows inserted:= "
							+ totalRowCount.length);

			logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DB_ASN_H_18",
					"No of rows inserted:= " + totalRowCount.length);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);

			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}AUH_117.1 : {}{}", Integer.parseInt(errorCode), sClassName,
					sMethodName, "DB_ASN_H_E2", "Error: " + e.getMessage());

			logger.error("{}{}AUH_117.1 : {}{}",e, Integer.parseInt(errorCode), sClassName,
					sMethodName, "DB_ASN_H_E3", "::Exception = ");

			//return hmResult;

		} finally {
			if (hmResult == null || hmResult.isEmpty()) {
				hmResult = CommonErrorMap.makeCategoryMap(
						CErrorDefs.ERR_SYS_APPL_NUM,
						"Error while inserting entry in TSERVICENOTIFICATION");
				logger.error("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_SYS_APPL_NUM, sClassName,
						sMethodName, "DB_ASN_H_19", "Error while inserting entry in TSERVICENOTIFICATION");
			}

			logger.info("{}{}AUH_117.1 : {}{}",sClassName, sMethodName, "DBTOOLS999", dtStart
					.getTime(), hmResult);
		}

		return hmResult;
	}
	/**
	 *
	 * @param hmInput
	 * @return HashMap
	 */
	public HashMap updateServiceNotification (HashMap hmInput){

		String sMethodName = "updateServiceNotification";
		HashMap hmResult = null;
		String sErrorCode;
		String sAppStatusCode = null;
		String sAppInfo = null;
		boolean isEmpty = false;
		int iCount;
		ArrayList alNotificationList = null;

		logger.info("{}{}AUH_117.1 : {}{}",0, sClassName, sMethodName, "DBTOOLS01","CVS KEYWORDS:" + info);
		logger.debug("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS02","Inputhash: " + hmInput);

		Date dtStartDate = new Date();
		DateFormat dateFormat = CommonUtil.getSimpleDateFormat("yyyy-MM-dd-HH.mm.ss");//new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss");
		String sStartDate = dateFormat.format(dtStartDate);

		try {
			if (jdbcTemplate == null) {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, "null connection");
				logger.error("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_DB_NUM, sClassName, sMethodName, "DBTOOLS03", "null connection");

				return hmResult;
			}

			String sCallingSystemId = (String)hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

			if (sCallingSystemId == null || sCallingSystemId.trim().length() == 0 ) {
				sAppInfo = "callingSystemId is null or missing in input";
				hmResult = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_EMPTY_NUM, sAppInfo);
				return hmResult;

			}

			HashMap hmCommonInfo = CommonUtil.getHashMap();//new HashMap(hmInput);
			hmCommonInfo.putAll(hmInput);

			hmCommonInfo.remove(CommonDefs.KEY_SERVICE_NOTIFICATION);
			HashMap hmEachNotification = null;

			alNotificationList = (ArrayList) hmInput.get(CommonDefs.KEY_SERVICE_NOTIFICATION);

			if(alNotificationList == null || alNotificationList.size() == 0){
				String appInfo = "Notificationlist is null or missing in input";
				logger.info("{}{}AUH_117.1 : {}{}", CErrorDefs.ERR_EMPTY_NUM, sClassName, sMethodName, "DBTOOLS04", appInfo);
				hmResult = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_EMPTY_NUM, appInfo);
				return hmResult;
			}
			for (int i=0; i < alNotificationList.size(); i++) {
				hmEachNotification = (HashMap) alNotificationList.get(i);
				hmEachNotification.putAll (hmCommonInfo);
				logger.debug("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS05","updating notification: " + hmEachNotification);
				//call DB helper to update notification one at a time
				hmResult = updateEachServiceNotification(hmEachNotification);

				sAppStatusCode = (String) hmResult.get( CErrorDefs.COMMON_APP_STATUS_CODE );

				if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS) ) {
					logger.info("{}{}AUH_117.1 : {}{}", Integer.parseInt(sAppStatusCode), sClassName, sMethodName,
							"DBTOOLS06", "Error from updateEachServiceNotification : "+ hmResult);
					return hmResult;
				}

			}
		}catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}AUH_117.1 : {}{}", Integer.parseInt(errorCode),
					sClassName, sMethodName, "DBTOOLS_E1", "Error: " + e.getMessage());
			return hmResult;

		} finally {
			logger.info("{}{}AUH_117.1 : {}{}",sClassName, sMethodName, "DBTOOLS999", dtStartDate.getTime(), hmResult);
		}

		return hmResult;
	}


	private HashMap updateEachServiceNotification(HashMap hmInput)
	{
		String sMethodName = "updateEachServiceNotification";
		HashMap hmResult = null;
		String sErrorCode;
		String sAppInfo = null;
		String sAppStatusCode = null;
		PreparedStatement prepStmtForNotification = null;
		boolean isEmpty = false;
		boolean isECOMMSor = false; // Added for June 2014 US#253897
		int iCount;
		// 1804 : Fixing SONAR violations
		//StringBuffer sbUpdateServiceNotification = new StringBuffer(
		StringBuilder sbUpdateServiceNotification = new StringBuilder(
				"UPDATE SERVICENOTIFICATION SET last_modified_by = ?, date_established = SYSDATE, ");

		logger.info("{}{}AUH_117.1 : {}{}",0, sClassName, sMethodName, "DBTOOLS01","CVS KEYWORDS:" + info);
		logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS02","Inputhash: " + hmInput);

		try {

			String sCallingSystemId = (String)hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sSorId = (String)hmInput.get(MPSDefs.DB_SOR_ID);
			String sSorName = (String)hmInput.get(MPSDefs.DB_SOR_NAME);
			String sSorInvariantId = (String)hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
			String sNotificationId = (String)hmInput.get (MPSDefs.DB_NOTIFICATION_ID);
			String sNotificationMethod = (String)hmInput.get (MPSDefs.DB_NOTIFICATION_METHOD);
			String sNotificationThreshold = (String)hmInput.get (MPSDefs.DB_NOTIFICATION_THRESHOLD);

			List<Object> objService = new ArrayList<Object>();


			if (sSorInvariantId == null || sSorInvariantId.trim().length() == 0 ) {
				sAppInfo = "sor_invariant_id is null or missing in input";
				isEmpty = true;
			}


			if (sSorId == null || sSorId.trim().length() == 0) {
				if (sSorName == null || sSorName.trim().length() == 0) {
					sAppInfo = "sor_id and sor_name missing in input";
					isEmpty = true;
				}
			}

			if(hmInput.containsKey(MPSDefs.DB_NOTIFICATION_METHOD) &&
					(sNotificationMethod == null || sNotificationMethod.trim().length() == 0 )){
				sAppInfo = "notification_method is null or empty in input";
				isEmpty = true;
			}

			if(hmInput.containsKey(MPSDefs.DB_NOTIFICATION_THRESHOLD) &&
					(sNotificationThreshold == null || sNotificationThreshold.trim().length() == 0 )){
				sAppInfo = "notification_threshold is null or empty in input";
				isEmpty = true;
			}


			if (sNotificationMethod == null || sNotificationMethod.trim().length() == 0 ) {
				if (sNotificationThreshold == null || sNotificationThreshold.trim().length() == 0 ) {
					sAppInfo = "notificationmethod and notificationthreshold missing in input";
					isEmpty = true;
				}
			}

			if (sNotificationId == null || sNotificationId.trim().length() == 0 ) {
				sAppInfo = "notification_id is null or missing in input";
				isEmpty = true;
			}
			if(isEmpty){
				logger.info("{}{}AUH_117.1 : {}{}", CErrorDefs.ERR_EMPTY_NUM, sClassName, sMethodName, "DBTOOLS03", sAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_EMPTY_NUM, sAppInfo);
				return hmResult;
			}

			//June2014 - Updated for US# 253897 - adding notification_method to SERVICE_NOTIFICATION_UPDATBLE_ATTRS only for ECOMM accounts
			if((sSorId != null && (sSorId.equals("7") || sSorId.equals("16")))
					|| (sSorName != null && (sSorName.equals(MPSDefs.SOR_COLA) || sSorName.equals(MPSDefs.SOR_CPR)))){
				isECOMMSor = true;
			}

			if(isECOMMSor){
				SERVICE_NOTIFICATION_UPDATBLE_ATTRS.add(MPSDefs.DB_NOTIFICATION_METHOD);
			}
			int nIndex = 0;
			String sKey = null;
			Iterator itr = SERVICE_NOTIFICATION_UPDATBLE_ATTRS.iterator();
			while (itr.hasNext()) {
				sKey = (String) itr.next();

				if (hmInput.containsKey(sKey))
				{
					if (nIndex > 0 && nIndex < SERVICE_NOTIFICATION_UPDATBLE_ATTRS.size())
						sbUpdateServiceNotification.append(" ,");
					sbUpdateServiceNotification.append(sKey + "=?");
					nIndex++;
				}
			}

			sbUpdateServiceNotification.append("  WHERE ");

			if (sSorId != null && sSorId.trim().length() > 0 )
				sbUpdateServiceNotification.append(" sor_invariant_id = ? AND notification_id =? AND sor_id = ?");
			else
				sbUpdateServiceNotification.append(
						" sor_invariant_id = ? AND notification_id =? AND sor_id = (SELECT sor_id FROM systemofrecord WHERE sor_name = ?)");

			// OCT 2013 - updated for SMS_ notifications
			if(sNotificationMethod != null && (sNotificationMethod.contains("_") || !isECOMMSor)){ // Updated for June2014 US#253897
				sbUpdateServiceNotification.append(" AND notification_method =?");
			}// END

			logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS03",
					" Update ServiceNotification SQL :" + sbUpdateServiceNotification);

			//prepStmtForNotification = conn.prepareStatement(sbUpdateServiceNotification.toString());

			nIndex = 0;
			objService.add(null); objService.set(nIndex++, sCallingSystemId);

			itr = SERVICE_NOTIFICATION_UPDATBLE_ATTRS.iterator();
			while (itr.hasNext()) {
				sKey = (String) itr.next();
				if (hmInput.containsKey(sKey)) {
					//nIndex++;
					objService.add(null); objService.set(nIndex, (String) hmInput.get(sKey));
				}
			}
			objService.add(null); objService.set(nIndex++, sSorInvariantId.trim());
			objService.add(null); objService.set(nIndex++, sNotificationId.trim());

			if (sSorId != null && sSorId.trim().length() > 0 ) {
				objService.add(null);
				objService.set(nIndex++, sSorId.trim());
			}
			else {
				objService.add(null);
				objService.set(nIndex++, sSorName.trim());
			}

			// OCT 2013 - updated for SMS_ notifications
			if(sNotificationMethod != null && (sNotificationMethod.contains("_") || !isECOMMSor)){ // Updated for June2014 US#253897
				objService.add(null); objService.set(nIndex++, sNotificationMethod.trim());
			}// END

			Date dtStartDate = new Date();
			DateFormat dateFormat = CommonUtil.getSimpleDateFormat("yyyy-MM-dd-HH.mm.ss");//new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss");
			String sStartDate = dateFormat.format(dtStartDate);

			logger.debug("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS04", "Query start time = " + sStartDate);

			//iCount = prepStmtForNotification.executeUpdate();
			iCount = jdbcTemplate.update(new String(sbUpdateServiceNotification.toString()), objService.toArray());

			if (iCount == 0)
			{
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
						CErrorDefs.ERR_REC_NOT_FOUND_MSG);
				logger.info("{}{}AUH_117.1 : {}{}", CErrorDefs.ERR_REC_NOT_FOUND_NUM,
						sClassName, sMethodName, "DBTOOLS07", "No row found" );
				return hmResult;
			}


			// Calculate the total time taken to execute the query
			//to return time in milliseconds for APRIL2011-sa7153
			long pTime = (System.currentTimeMillis() - dtStartDate.getTime());
			logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "QUERY999",
					"Total time taken to execute query = " + pTime + " milliseconds");

			logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName,
					"DBTOOLS05", "No of rows updated are : " + iCount);


			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "SERVICENOTIFICATION attributes updated Successfully");

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			sErrorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}AUH_117.1 : {}{}", Integer.parseInt(sErrorCode), sClassName, sMethodName, "DBTOOLS_E3",
					"The exception is :" + e);
		}
		finally {
			logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS6", "Finished "
					+ sClassName + "." + sMethodName+ "= "+ hmResult);
		}
		return hmResult;
	}


	/**
	 *
	 * @param hmInput
	 * @return HashMap
	 */
	public HashMap removeServiceNotification (HashMap hmInput){

		String sMethodName = "removeServiceNotification";
		HashMap hmResult = null;
		String sErrorCode;
		String sAppStatusCode = null;
		PreparedStatement prepStmt = null;
		int iCount;
		ArrayList alNotificationList = null;

		logger.info("{}{}AUH_117.1 : {}{}",0, sClassName, sMethodName, "DBTOOLS01","CVS KEYWORDS:" + info);
		logger.debug("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS02","Inputhash: " + hmInput);

		Date dtStartDate = new Date();
		DateFormat dateFormat = CommonUtil.getSimpleDateFormat("yyyy-MM-dd-HH.mm.ss");//new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss");
		String sStartDate = dateFormat.format(dtStartDate);

		try {
			if (jdbcTemplate == null) {
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, "null connection");
				logger.error("{}{}AUH_117.1 : {}{}", MPSDefs.ERR_DB_NUM, sClassName, sMethodName, "DBTOOLS03", "null connection");

				return hmResult;
			}

			String sCallingSystemId = (String)hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

			if (sCallingSystemId == null || sCallingSystemId.trim().length() == 0 )
			{
				String appInfo = "callingSystemId is null or missing in input";
				logger.info("{}{}AUH_117.1 : {}{}", CErrorDefs.ERR_EMPTY_NUM, sClassName, sMethodName, "DBTOOLS04", appInfo);
				hmResult = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_EMPTY_NUM, appInfo);
				return hmResult;
			}


			HashMap hmCommonInfo = CommonUtil.getHashMap();//new HashMap(hmInput);
			hmCommonInfo.putAll(hmInput);

			alNotificationList = (ArrayList) hmInput.get(CommonDefs.KEY_SERVICE_NOTIFICATION);
			hmCommonInfo.remove(CommonDefs.KEY_SERVICE_NOTIFICATION);
			HashMap hmEachNotification = null;

			if(alNotificationList == null || alNotificationList.size() == 0){
				String appInfo = "Notificationlist is null or missing in input";
				logger.info("{}{}AUH_117.1 : {}{}", CErrorDefs.ERR_EMPTY_NUM, sClassName, sMethodName, "DBTOOLS05", appInfo);
				hmResult = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_EMPTY_NUM, appInfo);
				return hmResult;
			}

			for (int i=0; i < alNotificationList.size(); i++) {
				hmEachNotification = (HashMap) alNotificationList.get(i);

				hmEachNotification.putAll (hmCommonInfo);

				logger.debug("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS06","remove notification: " + hmEachNotification);

				//call DB helper to update notification one at a time
				hmResult = removeEachServiceNotification(hmEachNotification);

				sAppStatusCode = (String) hmResult.get( CErrorDefs.COMMON_APP_STATUS_CODE );

				if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS) ) {
					logger.info("{}{}AUH_117.1 : {}{}", Integer.parseInt(sAppStatusCode), sClassName, sMethodName,
							"DBTOOLS07", "Error from updateEachServiceNotification : "+ hmResult);

					return hmResult;
				}

			}
		}catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);

			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}AUH_117.1 : {}{}", Integer.parseInt(errorCode),
					sClassName, sMethodName, "DBTOOLS08", "Error: " + e.getMessage());

			return hmResult;

		} finally {
			logger.info("{}{}AUH_117.1 : {}{}",sClassName, sMethodName, "DBTOOLS999", dtStartDate.getTime(), hmResult);
		}

		return hmResult;
	}


	private HashMap removeEachServiceNotification(HashMap hmInput)
	{
		String sMethodName = "removeEachServiceNotification";
		HashMap hmResult = null;
		String sErrorCode;
		String sAppStatusCode = null;
		String sAppInfo = null;
		boolean isEmpty = false;
		int iCount;
		String prepStmtForNotification = null;
		List<Object> objService = new ArrayList<Object>();

		logger.info("{}{}AUH_117.1 : {}{}",0, sClassName, sMethodName, "DBTOOLS01","CVS KEYWORDS:" + info);
		logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS02","Inputhash: " + hmInput);

		try {
			String sCallingSystemId = (String)hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sTransactionName = (String)hmInput.get(CommonDefs.TRANSACTION_NAME);
			String sSorInvariantId = (String)hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
			String sSorId = (String)hmInput.get(MPSDefs.DB_SOR_ID);
			String sSorName = (String)hmInput.get(MPSDefs.DB_SOR_NAME);
			String sNotificationId = (String)hmInput.get (MPSDefs.DB_NOTIFICATION_ID);
			String sNotificationMethod = (String)hmInput.get (MPSDefs.DB_NOTIFICATION_METHOD); // Oct 2013

			if (sSorInvariantId == null || sSorInvariantId.trim().length() == 0 )
			{
				sAppInfo = "sor_invariant_id is null or missing in input";
				isEmpty = true;
			}

			if ( (sTransactionName != null && ! sTransactionName.equalsIgnoreCase("RemoveAccount")) ||
					sTransactionName == null)
			{
				if (sSorId == null || sSorId.trim().length() == 0) {
					if (sSorName == null || sSorName.trim().length() == 0) {
						sAppInfo = "sor_id and sor_name missing in input";
						isEmpty = true;
					}
				}

				if ((sNotificationId == null || sNotificationId.trim().length() == 0)&&
						(sNotificationMethod == null ||sNotificationMethod.trim().length() == 0) ) {
					sAppInfo = "notification_id  and notification both are null or missing in input";
					isEmpty = true;
				}
			}

			if(isEmpty){
				logger.info("{}{}AUH_117.1 : {}{}", CErrorDefs.ERR_EMPTY_NUM, sClassName, sMethodName, "DBTOOLS03", sAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap( CErrorDefs.ERR_EMPTY_NUM, sAppInfo);
				return hmResult;
			}

			if (sSorId != null && sSorId.trim().equalsIgnoreCase("null")) {

				sSorId= null;
			}

			if (sSorName !=null && sSorName.trim().equalsIgnoreCase("null")) {
				sSorName = null;
			}



			String sQueryArg = "";
			if (sTransactionName != null && sTransactionName.equalsIgnoreCase("RemoveAccount") &&
					(sSorId == null || sSorId.isEmpty()) && (sSorName == null || sSorName.isEmpty()))
			{
				//prepStmtForNotification = conn.prepareStatement(sRemoveServiceNotificationSql);
				prepStmtForNotification = sRemoveServiceNotificationSql;

				logger.debug("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName, "DBTOOLS03.1",
						"Remove SQL = " + sRemoveServiceNotificationSql);
				logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DANGER-09", "CONTROL MUST NOT COME HERE" +hmInput); // Added for June 2014 SID# 30866 (as sor_invariant_id is not unique across different service_type or instance_id)
			} else if ((sTransactionName != null && sTransactionName.equalsIgnoreCase("RemoveAccount"))&&
					((sSorId != null && !sSorId.isEmpty()) || (sSorName != null && !sSorName.isEmpty())))
			{
				if (sSorId != null && !sSorId.isEmpty()) {
					sQueryArg =" AND SOR_ID=?";
					//prepStmtForNotification = conn.prepareStatement (sRemoveServiceNotificationSql + sQueryArg);
					//prepStmtForNotification.setString(2, sSorId);
					prepStmtForNotification = sRemoveServiceNotificationSql + sQueryArg;
					objService.add(null); objService.add(null); objService.set(1, sSorId);

				} else if (sSorName != null && !sSorName.isEmpty()) {
					sQueryArg  = " AND sor_id = (SELECT sor_id FROM systemofrecord WHERE sor_name = ?) ";
					//prepStmtForNotification = conn.prepareStatement (sRemoveServiceNotificationSql + sQueryArg);
					//prepStmtForNotification.setString(2, sSorName);
					prepStmtForNotification = sRemoveServiceNotificationSql + sQueryArg;
					objService.add(null); objService.add(null); objService.set(1, sSorName);
				}

			} else if ((sSorId != null && sSorId.trim().length() > 0) &&
					(sNotificationMethod != null && sNotificationMethod.trim().length() > 0) &&
					(sNotificationId != null && sNotificationId.trim().length() > 0)) { // Oct 2013

				sQueryArg =" AND NOTIFICATION_ID =? AND SOR_ID=? AND NOTIFICATION_METHOD = ?";
				//prepStmtForNotification = conn.prepareStatement(sRemoveServiceNotificationSql + sQueryArg);
				prepStmtForNotification = sRemoveServiceNotificationSql + sQueryArg;

				logger.debug("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS03.2.0",
						"Remove SQL = " + sRemoveServiceNotificationSql);

			}
			else if ((sSorId != null && sSorId.trim().length() > 0) &&
					(sNotificationMethod != null && sNotificationMethod.trim().length() > 0)) { // Oct 2013

				sQueryArg =" AND NOTIFICATION_METHOD =? AND SOR_ID=?";
				//prepStmtForNotification = conn.prepareStatement(sRemoveServiceNotificationSql + sQueryArg);
				prepStmtForNotification = sRemoveServiceNotificationSql + sQueryArg;

				logger.debug("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS03.2",
						"Remove SQL = " + sRemoveServiceNotificationSql);

			}
			else if(sSorId != null && sSorId.trim().length() > 0){
				sQueryArg =" AND NOTIFICATION_ID =? AND SOR_ID=?";
				//prepStmtForNotification = conn.prepareStatement(sRemoveServiceNotificationSql + sQueryArg);
				prepStmtForNotification = sRemoveServiceNotificationSql + sQueryArg;

				logger.debug("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS04.1",
						"Remove SQL = " + sRemoveServiceNotificationSql);
			}else{
				if(sNotificationMethod != null && sNotificationMethod.trim().length() > 0){
					sQueryArg = " AND NOTIFICATION_ID =? AND SOR_ID = (SELECT sor_id FROM systemofrecord WHERE sor_name = ?) AND NOTIFICATION_METHOD = ?";
					//prepStmtForNotification = conn.prepareStatement(sRemoveServiceNotificationSql + sQueryArg);
					prepStmtForNotification = sRemoveServiceNotificationSql + sQueryArg;

					logger.debug("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS05.0",
							"Remove SQL = " + sRemoveServiceNotificationSql);

				}else{
					sQueryArg = " AND NOTIFICATION_ID =? AND SOR_ID = (SELECT sor_id FROM systemofrecord WHERE sor_name = ?)";
					//prepStmtForNotification = conn.prepareStatement(sRemoveServiceNotificationSql + sQueryArg);
					prepStmtForNotification = sRemoveServiceNotificationSql + sQueryArg;

					logger.debug("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS05.1",
							"Remove SQL = " + sRemoveServiceNotificationSql);
				}
			}

			logger.info("{}{}AUH_117.1 : {}{}", 0, sClassName, sMethodName, "DBTOOLS04", "sRemoveServiceNotificationSql: "+
					sRemoveServiceNotificationSql + sQueryArg);

			objService.add(null); objService.set(0, sSorInvariantId.trim());

			if ((sTransactionName != null && ! sTransactionName.equalsIgnoreCase("RemoveAccount")) ||
					sTransactionName == null)
			{
				if (sNotificationId  != null && sNotificationId.trim().length() > 0) {
					objService.add(null); objService.add(null); objService.set(1, sNotificationId.trim()); // Oct 2013
					if(sNotificationMethod != null && sNotificationMethod.trim().length() > 0 && ((sSorId != null && sSorId.trim().length() > 0) || (sSorName != null && !sSorName.isEmpty()))){
						objService.add(null); objService.add(null); objService.add(null); objService.set(3, sNotificationMethod.trim());
					}
				} else if (sNotificationMethod  != null && sNotificationMethod.trim().length() > 0){
					objService.add(null); objService.add(null); objService.set(1, sNotificationMethod.trim());
				}

				if(sSorId != null && sSorId.trim().length() > 0){
					objService.set(2, sSorId.trim());
				}else{
					objService.set(2, sSorName.trim());
				}
			}

			Date dtStartDate = new Date();
			DateFormat dateFormat = CommonUtil.getSimpleDateFormat("yyyy-MM-dd-HH.mm.ss");//new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss");
			String sStartDate = dateFormat.format(dtStartDate);

			logger.debug("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS05", "Query start time = " + sStartDate);

			//iCount = prepStmtForNotification.executeUpdate();
			iCount = jdbcTemplate.update(new String(prepStmtForNotification), objService.toArray());

			// Calculate the total time taken to execute the query
			//to return time in milliseconds for APRIL2011-sa7153
			long pTime = (System.currentTimeMillis() - dtStartDate.getTime());
			logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "QUERY999",
					"Total time taken to execute query = " + pTime + " milliseconds");

			logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName,
					"DBTOOLS06", "No of rows deleted are : " + iCount);

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "No of rows removed : " + iCount);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			sErrorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			logger.error("{}{}AUH_117.1 : {}{}", Integer.parseInt(sErrorCode), sClassName, sMethodName, "DBTOOLS_E3",
					"The exception is :" + e);
		}
		finally {
			logger.info("{}{}AUH_117.1 : {}{}", sClassName, sMethodName, "DBTOOLS11", "Finished "
					+ sClassName + "." + sMethodName+ "= "+ hmResult);


		}
		return hmResult;

	}

}
