package com.att.idp.idgraphusermanagementms.resource;

import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.resource.request.ProfanityScannerRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ProfanityScannerResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.web.bind.annotation.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
/**
 * This is the ProfanityScannerResource interface. It defines a single method, profanityScanner, which is a POST endpoint at the path "/scanner".
 * This endpoint consumes and produces JSON.
 */
@Tag(name = "profanity")
@Path("/profanity")
@Produces({ MediaType.APPLICATION_JSON })
public interface ProfanityScannerResource {

    /**
     * This is a POST endpoint at the path "/scanner". It consumes and produces JSON.
     * The purpose of this endpoint is to check for profanity words in the given scanItem.
     *
     * @param profanityScannerRequest This is the request body. It should be a valid instance of ProfanityScannerRequest.
     * @param httpHeader This is the HTTP headers from the request.
     * @return A Response object. The response status can be 200 for success, 400 for bad request, or 500 for an unknown exception in the application.
     * @throws MPSException This exception is thrown if there is an error during the processing of the request.
     */
    @POST
    @Path("/scanner")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Operation(summary = "Profanity Scanner", description =  "used to check the bad/profanity words in the given scanItem",parameters = {
            @Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = ProfanityScannerResponse.class))),
            @ApiResponse(responseCode = "400", description =  "Bad Request"),
            @ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
    public Response profanityScanner(@Valid @RequestBody ProfanityScannerRequest profanityScannerRequest, @Context HttpHeaders httpHeader) throws MPSException;
}
