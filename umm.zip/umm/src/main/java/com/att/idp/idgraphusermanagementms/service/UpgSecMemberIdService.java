package com.att.idp.idgraphusermanagementms.service;

import com.att.idp.idgraphusermanagementms.resource.request.UpgSecMemberIdRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpgSecMemberIdResponse;

import jakarta.ws.rs.core.HttpHeaders;

/**
 * Service interface for upgrading a secondary member ID.
 * This interface defines the method for upgrading a sub-user in the MPSYS system.
 */
public interface UpgSecMemberIdService {

    /**
     * Upgrades a subaccount to the primary member ID in the MPSYS system.
     * This method handles the logic for upgrading a secondary member ID.
     *
     * @param upgSecMemberIdRequest The request object containing the details for upgrading a secondary member ID.
     * @param requestHeader The HTTP headers of the request.
     * @return An UpgSecMemberIdResponse object containing the status and result of the operation.
     */
    UpgSecMemberIdResponse upgSecMemberId(UpgSecMemberIdRequest upgSecMemberIdRequest, HttpHeaders requestHeader);
}