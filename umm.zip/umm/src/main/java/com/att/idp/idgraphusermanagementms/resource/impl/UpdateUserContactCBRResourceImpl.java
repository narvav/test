package com.att.idp.idgraphusermanagementms.resource.impl;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_IB;
import static com.att.idp.cd.observability.metrics.utils.Constants.URI;
import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.POST;
import static com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants.IDGRAPH_USERMANAGEMENTMS_IB;
import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.request.validator.UpdateUserContactCBRRequestvalidator;
import com.att.idp.idgraphusermanagementms.resource.UpdateUserContactCBRResource;
import com.att.idp.idgraphusermanagementms.resource.request.UpdateUserContactCBRRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdateUserContactCBRResponse;
import com.att.idp.idgraphusermanagementms.service.UpdateUserContactCBRService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.stereotype.Controller;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import java.sql.SQLException;
import java.util.Map;

import static com.att.mpsys.common.utils.CommonUtil.getElapsedTimeInSecs;

/**
 * This class is an implementation of the UpdateUserContactCBRResource interface.
 * It contains methods for updating user contact information.
 * It uses Spring's @Controller annotation, making it a candidate for Spring's automatic detection to discover and automatically create beans.
 * It also uses @Autowired to inject instances of UpdateUserContactCBRRequestvalidator and UpdateUserContactCBRService.
 *
 * The class contains one main method: updateUserContactCBR. This method takes in an UpdateUserContactCBRRequest object and HttpHeaders as parameters.
 * This method is responsible for validating the request, calling the appropriate service, and handling any exceptions that may occur.
 *
 * The class also contains a private method getElapsedTimeInSecs which calculates the elapsed time in seconds.
 *
 */
@Controller
@OpenAPIDefinition(
        info = @Info(title="User Management",
                description="IDGraphUserManagementMs provides services that are used to perform identity specific " +
                        "operations like creating new accessId, registering a currently.com memberId, updating " +
                        "profile attributes of the existing accessId, and fraud locking access Id. This information " +
                        "gets stored in IdentityGraph database and gets provisioned/replicated to multiple systems " +
                        "e.g. HALOC, Yahoo, CG, CCR, G2 etc.\n\n\n\n.", version="0.0.1"),
        servers = {
                @Server(url="https://apporigin-dev2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/"),
                @Server(url="https://apporigin-tst2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/")
        })
public class UpdateUserContactCBRResourceImpl implements UpdateUserContactCBRResource{
    @Autowired
    private UpdateUserContactCBRRequestvalidator updateUserContactCBRRequestvalidator;

    @Autowired
    private UpdateUserContactCBRService updateUserContactCBRService;

    public static final Logger logger = LoggerFactory.getLogger(UpdateUserContactCBRResourceImpl.class);

    @TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
            description = "update user contact cbr",
            tags = {URI, "/msapi/idgraphusermanagementms/v1/contacts/user/update", METHOD, POST},
            histogram = true)
    @Override
    public Response updateUserContactCBR(UpdateUserContactCBRRequest updateUserContactCBRRequest, HttpHeaders httpHeaders) throws MPSException {
        Map<String, Object> hmResponse = CommonUtil.getHashMap();
        UpdateUserContactCBRResponse updateUserContactCBRResponse = null;
        long startTm = System.currentTimeMillis();
        Response responseObj = null;
        try {

            MultivaluedMap<String, String> requestHeader = httpHeaders.getRequestHeaders();

            logger.info(SpiMarker.getInstance(),"WEB_01 : UpdateUserContactCBR Input : {} | UpdateUserContactCBR Request Header  : {}",
                updateUserContactCBRRequest != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(updateUserContactCBRRequest)) : null,
                    requestHeader != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(requestHeader)) : null);

            logger.info(SpiMarker.getInstance(),"WEB000 : UpdateUserContactCBR Request : {}", updateUserContactCBRRequest);
            updateUserContactCBRResponse = updateUserContactCBRRequestvalidator.updateUserContactCBRReqValidator(httpHeaders, updateUserContactCBRRequest);

            logger.info(SpiMarker.getInstance(),"WEB_01.1 : UpdateUserContactCBR Response : {}", updateUserContactCBRResponse);

            if (updateUserContactCBRResponse == null) {
                // call the service class
                updateUserContactCBRResponse = updateUserContactCBRService.updateUserContactCBR(updateUserContactCBRRequest, requestHeader);
                logger.info("WEB_02 : UpdateUserContactCBR Service Response : {}", updateUserContactCBRResponse);
            }
        } catch (Exception e) {
            if (e instanceof InvalidInputDataException) {
                logger.error("InvalidInputDataException: {}", e.getMessage());
                throw e;
            }
            else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
            }
            else {
                hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
            }

            hmResponse.put("idp-trace-id", updateUserContactCBRRequest.getIdpTraceId());
            updateUserContactCBRResponse = CommonUtilHelper.generateUpdateUserContactCBRResponse(hmResponse);
        }
        responseObj = CommonUtilHelper.buildMSResponse(updateUserContactCBRResponse);
        String sTimeTaken = getElapsedTimeInSecs(startTm) + " seconds";

        logger.info("WEB999 : Total time taken : {} UpdateUserContactCBR Response : {}",sTimeTaken, updateUserContactCBRResponse);
        return responseObj;
    }
}
