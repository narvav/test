package com.att.idp.idgraphusermanagementms.resource.request;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;



/**
 * This class represents a request to register an email user in the system.
 * It contains fields for various user details such as transactionName, handle (userId), domain, passwordClear, sor, accountType, dateOfBirth, online1SecurityQuestion, online1SecurityAnswer, online2SecurityQuestion, online2SecurityAnswer, contactEmail, firstName, lastName, gender, language, regClientIpAddress, services, contacts, proofingZip, isExternalCall, idpTraceId, callingSystemId, and a map for unknownAttributes.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 *
 */

@Schema(name = "RegisterEmailUserRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class RegisterEmailUserRequest extends BaseUserRequest {

	
	private String transactionName = "RegisterEmailUser";
	
	@Schema(name = "userId")
	@NotNull(message = "userId is required field in input request.|RegisterEmailUser")
	@Size(min = 1, max = 127, message =  "userId length is invalid|RegisterEmailUser")
	@JsonProperty("userId")
	private String handle;

	@Schema(name = "domain")
	@NotNull(message = "domain is required field in input request.|RegisterEmailUser")
	@Size(min = 1, max = 30, message =  "domain length is invalid|RegisterEmailUser")
	private String domain;

	@Schema(name = "passwordClear")
	@NotNull(message = "passwordClear is required field in input request.|RegisterEmailUser")
	@Size(min = 1, max = 24, message =  "passwordClear length is invalid|RegisterEmailUser")
	private String passwordClear;

	@Schema(name = "sor")
	@Size(min = 1, max = 20, message =  "sor length is invalid|RegisterEmailUser")
	private String sor;

	@Schema(name = "accountType")
	@Size(min = 1, max = 1, message =  "accountType length is invalid|RegisterEmailUser")
	private String accountType;

	@Schema(name = "dateOfBirth")
	@NotNull(message = "dateOfBirth is required field in input request.|RegisterEmailUser")
	@Size(min = 1, max = 80, message =  "dateOfBirth length is invalid|RegisterEmailUser")
	private String dateOfBirth;

	@Schema(name = "gender")
	@Size(min = 1, max = 1, message =  "gender length is invalid|RegisterEmailUser")
	private String gender;

	@Schema(name = "language")
	@Size(min = 1, max = 2, message =  "language length is invalid|RegisterEmailUser")
	private String language;

	@Schema(name = "regClientIpAddress")
	@Size(min = 1, message =  "regClientIpAddress length is invalid|RegisterEmailUser")
	private String regClientIpAddress;

	@Schema(name = "services")
	private List<@Valid Services> services;

	@Schema(name = "contacts")
	private List<@Valid Contact> contacts;
	
	@Size(min = 1, max = 10, message =  "zip length is invalid|RegisterEmailUser")
	@JsonProperty("zip")
	private String proofingZip;

	protected String isExternalCall;

	@Schema(name = "idpTraceId")
	private String idpTraceId;

	private String callingSystemId;

	/**
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
	 * @return Map<String,Object> The map of unknown attributes.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();


}
