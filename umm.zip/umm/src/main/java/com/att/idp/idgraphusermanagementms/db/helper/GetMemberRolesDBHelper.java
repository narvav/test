package com.att.idp.idgraphusermanagementms.db.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import org.springframework.web.util.HtmlUtils;

/**
 * This class is responsible for retrieving the roles associated with a member from the database.
 * It uses Spring's JdbcTemplate for database operations.
 *
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like JdbcTemplate.
 *
 * The class contains SQL queries as string constants for retrieving member roles.
 * These queries are used in the corresponding methods for these operations.
 *
 * The main method in this class is:
 * - getMemberServiceRoles: This method retrieves the roles associated with a member from the database. It takes a HashMap as input and returns a HashMap as output.
 *   The input HashMap contains key-value pairs for various member attributes like member number.
 *   The method first checks if the jdbcTemplate is null. If it is, it returns an error status.
 *   Then it retrieves the member number from the input HashMap.
 *   If the member number is not found, it returns an error status.
 *   Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
 *   Finally, it returns a status indicating whether the operation was successful or not.
 */
@Component
public class GetMemberRolesDBHelper 
{	
	private static final String CLASS_NAME = "GetMemberRolesDBHelper";
	public static final Logger logger = LoggerFactory.getLogger(GetMemberRolesDBHelper.class);
	
	@Autowired 
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;
	
	private static String dateFormat = "MMDDYYYY HH24:mi:ss";
	
	private static final String queryMemberServiceRolesSql = 
		"SELECT msr.member_num, msr.service_id, ser.service_name, msr.role_id, srole.role_name, " 
		+ " msr.sor_id, sor.sor_name,  msr.sor_invariant_id, msr.status as role_status_code, " 
		+ " stat.status_name as role_status_name, TO_CHAR(msr.create_date, '"  
		+ dateFormat 
		+ "') AS create_date, TO_CHAR(msr.last_modified, '" 
		+ dateFormat
		+ "') AS last_modified, msr.last_modified_by AS last_modified_by " 
 		+ " FROM memberservicerole msr, service ser, servicerole srole, status stat,"  
		+ " systemofrecord sor" 
		+ " WHERE msr.service_id = ser.service_id AND srole.role_id = msr.role_id " 
		+ " AND msr.sor_id = sor.sor_id AND msr.status = stat.status_code (+) "
		+ " AND msr.service_id = srole.service_id AND msr.member_num = ?";

	/**
	 * This method retrieves the roles associated with a member from the database.
	 * It uses the input HashMap which contains key-value pairs for various member attributes like member number.
	 * The method first checks if the jdbcTemplate is null. If it is, it returns an error status.
	 * Then it retrieves the member number from the input HashMap.
	 * If the member number is not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param hmInput A HashMap containing the details of the member's information to be retrieved.
	 * @return A HashMap containing the status of the operation and the retrieved member's roles.
	 */
	//This Method returns roles associated with a member.
	public HashMap getMemberServiceRoles(HashMap hmInput) {
		String sMethodName = ".getMemberServiceRoles.";
		logger.info("{}{}DBTOOLS000 : InpParam : {}", CLASS_NAME, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmInput)));

		HashMap<String, Object> hmResult = null;
		String sMemberNum = null;
		ArrayList alServiceRoles = null;
		HashMap hmDbServiceRoles = new HashMap();
		String sServiceName = "";

		List<Object> objectList = new ArrayList<Object>();
		List alQueryResponse = null;

		if (jdbcTemplate == null) {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "jdbcTemplate is null.");
			logger.error("response : {}", hmResult);
			return hmResult;
		}

		sMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);

		if (sMemberNum == null || sMemberNum.trim().length() == 0) {
			String appInfo = "member_num is null or missing in input";
			logger.info("{}{}DBTOOLS_04 : {}", CLASS_NAME, sMethodName, appInfo);
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, appInfo);

			return hmResult;
		}

		try {

			logger.info("{}{}DBTOOLS_05 : Query SQL = {}", CLASS_NAME, sMethodName, queryMemberServiceRolesSql);

			objectList.add(sMemberNum);

			long pTime = 0;
			Date dtStartDate = new Date();

			// execute the prepared statement
			alQueryResponse = jdbcTemplate.queryForList(new String(queryMemberServiceRolesSql),
					objectList.toArray(new Object[objectList.size()]));

			// pt637d - to return time in milliseconds for APRIL2011
			pTime = (System.currentTimeMillis() - dtStartDate.getTime());

			logger.info("{}{}QUERY999 : Total time taken to execute query = {} milliseconds", CLASS_NAME, sMethodName, pTime);

			int rowCount = 0;
			HashMap<String, Object> hmRoleDetails = null;

			for (int j = 0; j < alQueryResponse.size(); j++) {
				Map hmQueryResponse = (Map) alQueryResponse.get(j);

				Iterator itr = hmQueryResponse.keySet().iterator();
				while (itr.hasNext()) {
					String key = (String) itr.next();
					Object value = hmQueryResponse.get(key);

					String strValue = (value == null ? null : value.toString());

					hmQueryResponse.put(key, strValue);
				}

				++rowCount;

				hmRoleDetails = CommonUtil.getHashMap();

				hmRoleDetails.put(MPSDefs.DB_SERVICE_ID, (String) hmQueryResponse.get(MPSDefs.DB_SERVICE_ID));

				hmRoleDetails.put(MPSDefs.DB_SERVICE_NAME, (String) hmQueryResponse.get(MPSDefs.DB_SERVICE_NAME));

				hmRoleDetails.put(MPSDefs.DB_ROLE_ID, (String) hmQueryResponse.get(MPSDefs.DB_ROLE_ID));

				hmRoleDetails.put(MPSDefs.DB_ROLE_NAME, (String) hmQueryResponse.get(MPSDefs.DB_ROLE_NAME));

				hmRoleDetails.put(MPSDefs.DB_SOR_ID, (String) hmQueryResponse.get(MPSDefs.DB_SOR_ID));

				hmRoleDetails.put(MPSDefs.DB_SOR_NAME, (String) hmQueryResponse.get(MPSDefs.DB_SOR_NAME));

				hmRoleDetails.put(MPSDefs.DB_SOR_INVARIANT_ID,
						(String) hmQueryResponse.get(MPSDefs.DB_SOR_INVARIANT_ID));

				hmRoleDetails.put("role_status_code", (String) hmQueryResponse.get("role_status_code"));

				hmRoleDetails.put(MPSDefs.DB_STATUS, (String) hmQueryResponse.get("role_status_code"));

				hmRoleDetails.put("role_status_name", (String) hmQueryResponse.get("role_status_name"));

				hmRoleDetails.put(MPSDefs.DB_CREATE_DATE, (String) hmQueryResponse.get(MPSDefs.DB_CREATE_DATE));

				hmRoleDetails.put(MPSDefs.DB_LAST_MODIFIED, (String) hmQueryResponse.get(MPSDefs.DB_LAST_MODIFIED));

				hmRoleDetails.put(MPSDefs.DB_LAST_MODIFIED_BY,
						(String) hmQueryResponse.get(MPSDefs.DB_LAST_MODIFIED_BY));

				sServiceName = (String) hmQueryResponse.get(MPSDefs.DB_SERVICE_NAME);

				if (hmDbServiceRoles.containsKey(sServiceName)) {
					alServiceRoles = (ArrayList) hmDbServiceRoles.get(sServiceName);
				} else {
					alServiceRoles = CommonUtil.getArrayList();
					hmDbServiceRoles.put(sServiceName, alServiceRoles);
				}
				
				alServiceRoles.add(hmRoleDetails);
			}

			if (rowCount == 0) {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
						CErrorDefs.ERR_REC_NOT_FOUND_MSG);
				logger.info("{}{}DBTOOLS_06 : No row found", CLASS_NAME, sMethodName);
				return hmResult;
			}

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success");

			hmResult.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);

			if (hmDbServiceRoles != null && !hmDbServiceRoles.isEmpty())
				hmResult.put(MPSDefs.DB_MEMBER_SERVICE_ROLES, hmDbServiceRoles);

		} catch (Exception excp) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(excp, logger);
			String sAppInfo = (String) hmResult.get(CErrorDefs.COMMON_APP_INFO);
			if (sAppInfo == null) {
				hmResult.put(CErrorDefs.COMMON_APP_INFO, excp.getMessage());
			}
		} finally {

			logger.info("{}{}DBTOOLS999 : STATUS={}", CLASS_NAME, sMethodName, hmResult);
		}

		return hmResult;
	} // end of getMemberServiceRoles
}
