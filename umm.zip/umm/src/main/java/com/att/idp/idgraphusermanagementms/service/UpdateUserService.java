package com.att.idp.idgraphusermanagementms.service;

import com.att.idp.idgraphusermanagementms.resource.request.UpdateUserRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdateUserResponse;

import jakarta.ws.rs.core.MultivaluedMap;

/**
 * This interface defines the contract for the UpdateUserService in the system.
 * It contains a single method updateUser which takes an UpdateUserRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return an UpdateUserResponse object.
 *
 * The UpdateUserRequest object encapsulates the details of the user update operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
public interface UpdateUserService {

	/**
	 * This method is part of the UpdateUserService interface.
	 * It defines the contract for updating a user in the system.
	 *
	 * @param updateUserRequest An object encapsulating the details of the user update operation to be performed.
	 * @param requestHeader A MultivaluedMap containing the request headers which may include additional information required for processing the request.
	 * @return An UpdateUserResponse object representing the response from the system after updating the user.
	 */
	UpdateUserResponse updateUser(UpdateUserRequest updateUserRequest, MultivaluedMap<String, String> requestHeader);

}
