package com.att.idp.idgraphusermanagementms.db.response;

import java.io.Serializable;

import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;

import com.att.idp.idgraphusermanagementms.db.request.SecurityQuestionBase;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * This is the SecurityQuestionResponse class which implements Serializable interface.
 * It represents a response for a security question with properties like securityQuestionId, securityQuestion, securityQuestionActive, and securityQuestionType.
 * Each property has its respective getter and setter methods.
 */

@EqualsAndHashCode(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({
		"securityQuestionId",
		"securityQuestion",
		"securityQuestionActive",
		"securityQuestionType",
})
public class SecurityQuestionResponse extends SecurityQuestionBase implements Serializable {

	private static final long serialVersionUID = -6117394620222310862L;

}