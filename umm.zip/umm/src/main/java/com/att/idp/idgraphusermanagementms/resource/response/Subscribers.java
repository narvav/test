package com.att.idp.idgraphusermanagementms.resource.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;

/**
 * This class represents a subscriber in the system.
 * It implements the Serializable interface, allowing it to be converted into a byte stream.
 * It contains a field for subscriptionId.
 *
 * The class is annotated with @Data, @JsonIgnoreProperties, @JsonInclude, and @ApiModel from various libraries such as Jackson and Swagger.
 * The @Data annotation from Lombok library generates getter and setter methods for all fields.
 * The @JsonIgnoreProperties and @JsonInclude annotations from Jackson library control the JSON serialization/deserialization behavior.
 * The @ApiModel annotation from Swagger library provides metadata for the model definition in Swagger UI.
 *
 * It also overrides the toString method to return a string representation of the object.
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(name = "Subscribers")
public class Subscribers implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1647488365389225977L;

	private String subscriptionId;

	@Override
	public String toString() {
		return "Subscribers{" +
				"subscriptionId='" + subscriptionId + '\'' +
				'}';
	}
}