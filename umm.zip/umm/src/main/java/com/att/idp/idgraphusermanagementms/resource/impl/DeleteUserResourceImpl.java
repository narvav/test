package com.att.idp.idgraphusermanagementms.resource.impl;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_IB;
import static com.att.idp.cd.observability.metrics.utils.Constants.URI;
import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.POST;
import static com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants.IDGRAPH_USERMANAGEMENTMS_IB;
import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.message.ErrorMessages;
import com.att.idp.idgraphusermanagementms.request.validator.DeleteUserRequestValidator;
import com.att.idp.idgraphusermanagementms.resource.DeleteUserResource;
import com.att.idp.idgraphusermanagementms.resource.request.DeleteUserRequest;
import com.att.idp.idgraphusermanagementms.resource.response.DeleteUserResponse;
import com.att.idp.idgraphusermanagementms.service.DeleteUserService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.MPSDefs;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.stereotype.Controller;

import javax.validation.Valid;
import java.sql.SQLException;
import java.util.Map;

import static com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper.getElapsedTimeInSecs;

@Controller
@AllArgsConstructor
@OpenAPIDefinition(info = @Info(title = "User Management", description = "IDGraphUserManagementMs provides services that are used to perform identity specific "
        + "operations like deleting member/accessId an accessId or memberId when all the services linked to these IDs are deleted.\n\n\n\n.", version = "0.0.1"), servers = {
        @Server(url = "https://apporigin-dev2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/"),
        @Server(url = "https://apporigin-tst2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/")})
public class DeleteUserResourceImpl implements DeleteUserResource {

    public static final Logger logger = LoggerFactory.getLogger(DeleteUserResourceImpl.class);

    private final DeleteUserRequestValidator deleteUserReqValidator;

    private final DeleteUserService deleteUserService;

    /**
     * Deletes an accessId or memberId when all the services linked to these IDs are
     * deleted.
     * <p>
     * This method handles the deletion of a user by validating the request,
     * invoking the delete service, and building the appropriate response. It logs
     * the input, service response, and execution time.
     *
     * @param deleteUserRequest The request object containing the details of the
     *                          user to be deleted.
     * @param httpHeader        The HTTP headers containing additional request
     *                          metadata.
     * @return A Response object indicating the success or failure of the delete
     * operation.
     */
    @TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
            description = "delete user",
            tags = {URI, "/msapi/idgraphusermanagementms/v1/deleteuser", METHOD, POST},
            histogram = true)
    @Override
    public Response deleteUser(@Valid DeleteUserRequest deleteUserRequest, HttpHeaders httpHeader) {

        Map<String, Object> hmResponse;
        DeleteUserResponse deleteUserResponse;
        long startTm = System.currentTimeMillis();
        Response responseObj;

        try {

            MultivaluedMap<String, String> requestHeader = httpHeader.getRequestHeaders();
            String sanitizedDeleteUserInput = "null";
            if (deleteUserRequest != null) {
                String normalized = StringUtils.normalizeSpace(deleteUserRequest.toString());
                sanitizedDeleteUserInput = normalized
                        .replace('\r', ' ')
                        .replace('\n', ' ');
            }
            logger.info(SpiMarker.getInstance(), "WEB_01 : DeleteUser Input : {} | DeleteUser Request Header  : {}",
                    sanitizedDeleteUserInput,
                    CommonUtilHelper.sanitizeForLog(CommonUtilHelper.objectToString(requestHeader)));

            deleteUserResponse = deleteUserReqValidator.deleteUserRequestValidator(deleteUserRequest, httpHeader);
            logger.info(SpiMarker.getInstance(), "WEB000 : DeleteUser Input : {}", CommonUtilHelper.sanitizeForLog(String.valueOf(deleteUserRequest)));
            if (deleteUserResponse == null) {
                deleteUserResponse = deleteUserService.deleteUser(deleteUserRequest, requestHeader);
                logger.info("WEB_02 : DeleteUser service Response : {}", deleteUserResponse);
            }
        } catch (Exception e) {
            if (e instanceof InvalidInputDataException) {
                logger.error("InvalidInputDataException: {}", e.getMessage());
                throw e;
            } else if (NestedExceptionUtils.getRootCause(e) instanceof SQLException) {
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
                hmResponse.put("ErrorEnum", ErrorMessages.MS_MPSYS_BE_304);
            } else {
                hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
                hmResponse.put("ErrorEnum", ErrorMessages.MS_MPSYS_BE_602);
            }

            String idpTraceId = deleteUserRequest != null ? deleteUserRequest.getIdpTraceId() : null;
            hmResponse.put("idp-trace-id", idpTraceId);

            deleteUserResponse = CommonUtilHelper.generateDeleteUserResponse(hmResponse);
        }
        responseObj = CommonUtilHelper.buildMSResponse(deleteUserResponse);
        String sTimeTaken = getElapsedTimeInSecs(startTm) + " seconds";

        logger.info("WEB999 : Total time taken : {} DeleteUser Response : {}", sTimeTaken, deleteUserResponse);
        return responseObj;
    }
}