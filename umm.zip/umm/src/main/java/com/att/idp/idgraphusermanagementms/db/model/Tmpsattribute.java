package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TMPSATTRIBUTE", schema = "MPS_OWNER", uniqueConstraints = @UniqueConstraint(columnNames = "ATTRIBUTE_NAME"))
public class Tmpsattribute implements java.io.Serializable {

	private static final long serialVersionUID = 1438256256309611681L;

	@Id
	@Column(name = "ATTRIBUTE_ID", unique = true, nullable = false, precision = 22, scale = 0)
	private Long attributeId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CATEGORY_ID", nullable = false)
	private Tcategory tcategory;

	@Column(name = "ATTRIBUTE_NAME", unique = true, nullable = false)
	private String attributeName;

	@Column(name = "ATTRIBUTE_VALUE_MAX_LENGTH", nullable = false, precision = 22, scale = 0)
	private Long attributeValueMaxLength;

	@Column(name = "ATTRIBUTE_VALUE_MIN_LENGTH", nullable = false, precision = 22, scale = 0)
	private Long attributeValueMinLength;
}