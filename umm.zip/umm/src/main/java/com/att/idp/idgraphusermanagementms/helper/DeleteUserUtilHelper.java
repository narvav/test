package com.att.idp.idgraphusermanagementms.helper;

import com.att.idp.idgraphusermanagementms.db.helper.UpdateServiceDBHelper;
import com.att.idp.idgraphusermanagementms.integration.MPSYSInternalRestClient;
import com.att.idp.idgraphusermanagementms.resource.request.DeleteUserRequest;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Utility helper component for delete user operations.
 * <p>
 * This helper encapsulates common business rules used during user deletion,
 * including verification of service statuses, handling of suspended services
 * that may need to be terminated, construction of change-status requests, and
 * aging checks for suspended services based on configuration.
 * <p>
 * The helper is configured as a Spring {@code @Component} and loads
 * configuration properties from {@code userMgmt.properties}.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class DeleteUserUtilHelper {

    public static final Logger logger = LoggerFactory.getLogger(DeleteUserUtilHelper.class);
    private static final String CLASS_NAME = "DeleteUserUtilHelper";

    @Value("${DELETE_MEMBER_SUSPEND_SERVICE_DAYS}")
    private String propDeleteUserSuspendSvcDays;

    @Autowired
    private CommonUtilHelper oCommonUtilHelper;

    @Autowired
    private UpdateServiceDBHelper updateServiceDBHelper;

    @Autowired
    private MPSYSInternalRestClient internalIDPRestClient;

    /**
     * Verifies the status of services for a member or access ID.
     * <p>
     * This method inspects each service in the provided map and enforces
     * the following rules:
     * <ul>
     *     <li>Terminated services are ignored.</li>
     *     <li>Suspended services must be suspended for at least the configured
     *     number of days (defined by {@code DELETE_MEMBER_SUSPEND_SERVICE_DAYS}).</li>
     *     <li>If any enabled (non-suspended) service exists, the verification fails.</li>
     * </ul>
     * On failure, an error response is returned indicating that services still
     * exist. On success, a success category map is returned.
     *
     * @param hmServices a map of services keyed by identifier, where each value
     *                   is a map containing service attributes, including status
     * @return a {@link HashMap} representing a categorized response; success when
     *         no enabled or too-recently suspended services remain, or an error
     *         category when deletion cannot proceed
     */
    public HashMap<String, Object> verifyServiceStatus(Map<String, HashMap<String, Object>> hmServices) {

        String sMethodName = ".verifyServiceStatus.";
        String sAppInfo = null;

        logger.info("{}{}DUUH.VSS.01 : Input to verifyServiceStatus : {}", CLASS_NAME, sMethodName, hmServices);

        if (hmServices != null && !hmServices.isEmpty()) {

            logger.info("{}{}DUUH.VSS.02 : Property DELETE_USER_SUSPEND_SERVICE_DAYS : {}", CLASS_NAME, sMethodName,
                    propDeleteUserSuspendSvcDays);

            for (Map.Entry<String, HashMap<String, Object>> entry : hmServices.entrySet()) {
                HashMap<String, Object> individualService = entry.getValue();
                String status = (String) individualService.get(MPSDefs.SERVICE_STATUS);

                if (isTerminated(status)) {
                    continue;
                }
                if (isSuspended(status)) {
                    String sDBLastModifiedDate = getLastModifiedDate(individualService);
                    if (!checkAging(sDBLastModifiedDate, propDeleteUserSuspendSvcDays)) {
                        sAppInfo = "Suspended services less than " + propDeleteUserSuspendSvcDays
                                + " days exist. Service not terminated.";
                        logger.info("{}{}DUUH.VSS.03 : {}", CLASS_NAME, sMethodName, sAppInfo);
                        return returnSvcExistErrResponse(sAppInfo);
                    }
                } else {
                    sAppInfo = "Enabled service exist. Service not terminated.";
                    logger.info("{}{}DUUH.VSS.04 : {}", CLASS_NAME, sMethodName, sAppInfo);
                    return returnSvcExistErrResponse(sAppInfo);
                }
            }

            sAppInfo = "No Enabled or suspended service that are less than " + propDeleteUserSuspendSvcDays + " days.";
            logger.info("{}{}DUUH.VSS.04 : {}", CLASS_NAME, sMethodName, sAppInfo);
        }

        return returnSuccessResponse("service Status is verified successfully.");

    }

    /**
     * Checks suspended services for termination eligibility and, when applicable,
     * initiates a status change to terminate.
     * <p>
     * The method evaluates all services from the {@code hmGetAllInfoResponse}
     * payload, determines whether all non-terminated services are suspended and
     * have met the configured aging threshold, and when conditions are met,
     * calls an internal REST client to change their status to terminated.
     *
     * @param deleteUserReq        the delete user request providing transaction
     *                             and user identity details
     * @param hmGetAllInfoResponse the response map containing services and
     *                             related information from upstream systems
     * @return a {@link HashMap} with success information or an error/exception
     *         category map when termination or its pre-checks fail
     * @throws IOException if the underlying REST client invocation encounters
     *                     I/O issues
     */
    public HashMap<String, Object> checkSuspendedServicesToTerminate(DeleteUserRequest deleteUserReq,
                                                                     Map<String, Object> hmGetAllInfoResponse) throws IOException {

        String sMethodName = ".checkSuspendedServicesToTerminate.";
        String sAppInfo = null;
        boolean bAllServiceNotSuspended = false;
        boolean bSuspendSvcPresent = false;

        @SuppressWarnings("unchecked")
        Map<String, HashMap<String, Object>> hmServices = (Map<String, HashMap<String, Object>>) hmGetAllInfoResponse.get(MPSDefs.SERVICES);

        logger.info("{}{}DUUH.CSST.01 : Input to checkSuspendedServicesToTerminate : {}", CLASS_NAME, sMethodName,
                hmServices);

        if (hmServices != null && !hmServices.isEmpty()) {

            logger.info("{}{}DUUH.CSST.01.01 : Property DELETE_USER_SUSPEND_SERVICE_DAYS : {}", CLASS_NAME, sMethodName,
                    propDeleteUserSuspendSvcDays);

            for (Map.Entry<String, HashMap<String, Object>> entry : hmServices.entrySet()) {
                HashMap<String, Object> individualService = entry.getValue();
                String status = (String) individualService.get(MPSDefs.SERVICE_STATUS);

                if (isTerminated(status)) {
                    continue;
                }
                if (isSuspended(status)) {
                    bSuspendSvcPresent = true;
                    String sDBLastModifiedDate = getLastModifiedDate(individualService);
                    if (!checkAging(sDBLastModifiedDate, propDeleteUserSuspendSvcDays)) {
                        sAppInfo = "Suspended services are suspended less than " + propDeleteUserSuspendSvcDays
                                + " days.";
                        logger.info("{}{}DUUH.CSST.02 : {}", CLASS_NAME, sMethodName, sAppInfo);
                        break;
                    }
                } else {
                    bAllServiceNotSuspended = true;
                    sAppInfo = "Enabled services exist on member";
                    logger.info("{}{}DUUH.CSST.03 : {}", CLASS_NAME, sMethodName, sAppInfo);
                    break;
                }
            }

            if (!bAllServiceNotSuspended && bSuspendSvcPresent) {
                Map<String, Object> hmChangeStatusRequest = buildChangeStatusRequest(deleteUserReq);
                HashMap<String, Object> hmChangeStatusResponse = changeStatusToTerminate(hmChangeStatusRequest);
                String sAppStatusCode = (String) hmChangeStatusResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
                if (!CommonDefs.COMMON_SUCCESS.equals(sAppStatusCode)) {
                    return hmChangeStatusResponse;
                }
            }

        }
        return returnSuccessResponse("SUCCESS");

    }

    /**
     * Calls the internal REST client to change service status to terminated.
     * <p>
     * The method delegates to {@link MPSYSInternalRestClient#callIDPRestClient(Map)}
     * and ensures that a non-null response is always returned by converting
     * null or empty responses into a system application error category map.
     *
     * @param hmChangeStatusRequest the request payload describing the change
     *                              status operation to be performed
     * @return a {@link HashMap} containing the response from the internal REST
     *         client or an error category map if the response was null/empty
     * @throws IOException if the REST client invocation fails with an I/O error
     */
    private HashMap<String, Object> changeStatusToTerminate(Map<String, Object> hmChangeStatusRequest) throws IOException {

        String sMethodName = ".changeStatusToTerminate.";
        String sAppInfo = null;

        logger.info("{}{} DUUH.CS.01 : Calling MPSYSInternalRestClient.callIDPRestClient() with hmChangeStatusRequest : {}",
                CLASS_NAME, sMethodName, hmChangeStatusRequest);

        @SuppressWarnings("unchecked")
        HashMap<String, Object> hmResponse = (HashMap<String, Object>) internalIDPRestClient.callIDPRestClient(hmChangeStatusRequest);

        logger.info("{}{} DUUH.CS.02 : Response from MPSYSInternalRestClient.callIDPRestClient() : {}", CLASS_NAME,
                sMethodName, hmResponse);

        if (hmResponse == null || hmResponse.isEmpty()) {
            sAppInfo = "Null Response returned from MPSYSInternalRestClient.callIDPRestClient()";
            hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
            logger.info("{}{} DUUH.CS.03 : {}", CLASS_NAME, sMethodName,
                    HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
        }
        return hmResponse;
    }

    /**
     * Builds a change-status request map for terminating all services associated
     * with the given delete user request.
     *
     * @param deleteUserReq the delete user request used to populate transaction,
     *                      handle, and domain information
     * @return a {@link Map} representing the change-status request
     */
    private Map<String, Object> buildChangeStatusRequest(DeleteUserRequest deleteUserReq) {

        HashMap<String, Object> hmChangeStatusInp = CommonUtil.getHashMap();
        //hmChangeStatusInp.put(CommonDefs.ORIG_TRANSACTION_NAME, deleteUserReq.getTransactionName());
        hmChangeStatusInp.put(CommonDefs.TRANSACTION_NAME, CommonDefs.CHANGESTATUS_TRANSACTION_NAME);
        hmChangeStatusInp.put(CommonDefs.CALLING_SYSTEM_ID, deleteUserReq.getCallingSystemId());
        //hmChangeStatusInp.put(CommonDefs.TRANSACTION_ID, deleteUserReq.getIdpTraceId());
        hmChangeStatusInp.put(CommonDefs.MEMBERID, deleteUserReq.getHandle());
        hmChangeStatusInp.put(CommonDefs.DOMAIN, deleteUserReq.getDomain());
        hmChangeStatusInp.put(CommonDefs.STATUS, CommonDefs.TERMINATED);
        hmChangeStatusInp.put(CommonDefs.TYPE, CommonDefs.TYPE_ALL);
        //hmChangeStatusInp.put(CommonDefs.IS_EXTERNAL_CALL, MPSDefs.NO);

        return hmChangeStatusInp;
    }

    /**
     * Extracts the last modified date for a service from the top-level or nested
     * service maps.
     *
     * @param service the service map which may contain {@code DB_LAST_MODIFIED}
     *                either directly or within a nested map
     * @return the last modified date as a {@link String}, or {@code null} if not
     *         found
     */
    private String getLastModifiedDate(Map<String, Object> service) {
        String sDBLastModifiedDate = (String) service.get(MPSDefs.DB_LAST_MODIFIED);
        if (sDBLastModifiedDate == null || sDBLastModifiedDate.isEmpty()) {
            for (Map.Entry<String, Object> entry : service.entrySet()) {
                Object value = entry.getValue();
                if (value instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> nested = (Map<String, Object>) value;
                    if (!nested.isEmpty()) {
                        sDBLastModifiedDate = (String) nested.get(MPSDefs.DB_LAST_MODIFIED);
                    }
                }
            }
        }
        return sDBLastModifiedDate;
    }

    /**
     * Checks whether the given status corresponds to a terminated service.
     *
     * @param status the status string to evaluate
     * @return {@code true} if the status is {@link MPSDefs#TERMINATED}, otherwise
     *         {@code false}
     */
    private boolean isTerminated(String status) {
        return MPSDefs.TERMINATED.equals(status);
    }

    /**
     * Checks whether the given status corresponds to a suspended service.
     *
     * @param status the status string to evaluate
     * @return {@code true} if the status is {@link MPSDefs#SUSPENDED}, otherwise
     *         {@code false}
     */
    private boolean isSuspended(String status) {
        return MPSDefs.SUSPENDED.equals(status);
    }

    /**
     * Creates a success response map for delete user operations.
     *
     * @param message the descriptive success message
     * @return a {@link HashMap} categorized as a success response
     */
    private HashMap<String, Object> returnSuccessResponse(String message) {
        return CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, message);
    }

    /**
     * Creates an error response map indicating that services still exist and
     * deletion cannot proceed.
     *
     * @param message the descriptive error message
     * @return a {@link HashMap} categorized as a service-exists error response
     */
    private HashMap<String, Object> returnSvcExistErrResponse(String message) {
        return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SERVICE_EXISTS_NUM, message);
    }

    /**
     * Determines whether a date field has aged beyond a configured number of days.
     * <p>
     * The method parses the input date using the pattern {@code MMddyyyy HH:mm:ss},
     * adds the provided number of days, and compares the result with the current
     * system date to determine if the field is considered aged.
     *
     * @param sAgingFieldDate the date string to evaluate
     * @param sNumOfDays      the aging threshold in days as a string
     * @return {@code true} if the field date is older than the specified number of
     *         days, {@code false} otherwise or when parsing fails
     */
    private boolean checkAging(String sAgingFieldDate, String sNumOfDays) {

        String sMethodName = ".checkAging.";
        boolean bInputFieldAged = false;

        if (isNullOrEmpty(sAgingFieldDate)) {
            logger.info("{}{} DUUH.CA.02. Input field date is null or empty.", CLASS_NAME, sMethodName);
            return false;
        }

        try {
            Calendar cal = Calendar.getInstance();
            DateFormat dtFmt = new SimpleDateFormat("MMddyyyy HH:mm:ss");
            Date dtOnlineQAEstDate = dtFmt.parse(sAgingFieldDate);
            cal.setTime(dtOnlineQAEstDate);

            logger.info("{}{}DUUH.CA.01 : Input to checkAging {} : {} days", CLASS_NAME, sMethodName, sAgingFieldDate,
                    sNumOfDays);

            int iAgingDays = 0;

            if (sNumOfDays != null && !sNumOfDays.isEmpty()) {
                iAgingDays = Integer.parseInt(sNumOfDays);
            }

            cal.add(Calendar.DAY_OF_MONTH, iAgingDays);

            Date systemDate = dtFmt.parse(dtFmt.format(new Date()));
            Date dtFieldEstDate = dtFmt.parse(dtFmt.format(cal.getTime()));

            logger.debug("{}{}DUUH.CA.02 : dtFieldEstDate {}", CLASS_NAME, sMethodName, dtFieldEstDate);
            logger.debug("{}{}DUUH.CA.03 : systemDate {}", CLASS_NAME, sMethodName, systemDate);
            if (dtFieldEstDate.before(systemDate)) {
                bInputFieldAged = true;
            }

        } catch (Exception exp) {
            logger.error("{}{}DUUH.CA.04 : Exception {}", CLASS_NAME, sMethodName, exp.getMessage());
        }

        logger.info("{}{}DUUH.CA.05 : Response from checkAging {}", CLASS_NAME, sMethodName, bInputFieldAged);
        return bInputFieldAged;
    }

    /**
     * Utility method to determine if a string is {@code null} or empty.
     *
     * @param str the string to validate
     * @return {@code true} if the string is {@code null} or has zero length,
     *         {@code false} otherwise
     */
    private boolean isNullOrEmpty(String str) {
        return str == null || str.isEmpty();
    }

}
