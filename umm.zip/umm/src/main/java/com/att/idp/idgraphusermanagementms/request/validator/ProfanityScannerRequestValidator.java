package com.att.idp.idgraphusermanagementms.request.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphusermanagementms.resource.request.ProfanityScannerRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ProfanityScannerResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;

import jakarta.ws.rs.core.HttpHeaders;
/**
 * This class is responsible for the validation of the profanityScannerRequest and headers.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class ProfanityScannerRequestValidator {

    private static final Logger logger = LoggerFactory.getLogger(ProfanityScannerRequestValidator.class);

    private String sClassName = "ProfanityScannerRequestValidator";

    @Value("${profanityScannerValidCSIDs}")
    private String profanityScannerValidCSIDs;
    /**
     * This method validates the request made to the Profanity Scanner.
     * It checks for the validity of the request headers and parameters.
     * @param requestHeader The HttpHeaders of the request
     * @param profanityScannerRequest The request object containing the parameters for the Profanity Scanner
     * @return ProfanityScannerResponse The response object containing the result of the validation
     */
    public ProfanityScannerResponse profanityScannerReqValidator(HttpHeaders requestHeader, ProfanityScannerRequest profanityScannerRequest) {

        ProfanityScannerResponse profanityScannerResponse = null;
        String stAppInfo = null;
        String sMethodName = ".profanityScannerRequestValidator.";
        String stIdpTraceId = null;
        String stXAttClientId = null;

        try {

            stIdpTraceId = CommonUtil.getTraceId(requestHeader);
            if (stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
                stAppInfo = "Missing or Invalid IdpTraceId";
                return profanityScannerErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
            }
            if (profanityScannerRequest == null) {
                stAppInfo = "Input Request Parameter is NULL / Empty.";
                logger.info("{}{}PSRV_01 :: {}", sClassName, sMethodName, stAppInfo);
                return profanityScannerErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
            }
            profanityScannerRequest.setIdpTraceId(stIdpTraceId);

            if (requestHeader.getHeaderString("X-ATT-ClientId") != null) {
                stXAttClientId = requestHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
                logger.info("{}{}PSRV_1.1 : Setting callingSystemId: {}", sClassName, sMethodName,
                        StringUtils.normalizeSpace(stXAttClientId));
                profanityScannerRequest.setCallingSystemId(stXAttClientId);
            } else {
                stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
                logger.info("{}{}PSRV_1.2 :: {}", sClassName, sMethodName, stAppInfo);
                return profanityScannerErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
            }

            profanityScannerResponse = profanityScannerRequestInputValidator(profanityScannerRequest);
            if (profanityScannerResponse != null) {
                logger.info("{}{}PSRV_2 Response from profanityScannerReqValidator : {}", sClassName, sMethodName,
                        profanityScannerResponse);
                return profanityScannerResponse;
            } else {
                logger.debug("{}{}PSRV_03 Success Response from profanityScannerReqValidator ", sClassName, sMethodName);
            }
            stAppInfo = "Input Validation Successful";
            logger.info("{}{}AARV_04 : {}", sClassName, sMethodName, stAppInfo);

        } catch (Exception e) {
            stAppInfo = "Exception thrown in ProfanityScannerRequestValidator.profanityScannerReqValidator : " + e.getMessage();
            logger.info("Exception in profanityScannerReqValidator: {}", stAppInfo);
            return profanityScannerErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo, stIdpTraceId);
        }
        return profanityScannerResponse;
    }
    /**
     * This method validates the input parameters of the Profanity Scanner request.
     * It checks for the validity of the scan item type and the calling system ID.
     * @param profanityScannerRequest The request object containing the parameters for the Profanity Scanner
     * @return ProfanityScannerResponse The response object containing the result of the validation
     */
    private ProfanityScannerResponse profanityScannerRequestInputValidator(ProfanityScannerRequest profanityScannerRequest) {

        String stAppInfo = null;
        String sMethodName = ".profanityScannerRequestInputValidator";
        ProfanityScannerResponse profanityScannerResponse = null;

        Optional.ofNullable(profanityScannerRequest.getScanItem()).ifPresent(x -> profanityScannerRequest.setScanItem(x.toLowerCase()));
        Optional.ofNullable(profanityScannerRequest.getScanItemType()).ifPresent(x -> profanityScannerRequest.setScanItemType(x.toLowerCase()));

        String scanItemType = profanityScannerRequest.getScanItemType();
        String callingSystemId = profanityScannerRequest.getCallingSystemId();

        Map<String, Object> allUnknownAttributes = new HashMap<>(profanityScannerRequest.unknownAttributes);

        if (!allUnknownAttributes.isEmpty()) {
            stAppInfo = "Invalid Attributes passed in MergeUserAccessIdRequest : " + allUnknownAttributes;
            return profanityScannerErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
                    profanityScannerRequest.getIdpTraceId());
        }

        ArrayList<String> alProfanityScannerValidCSIDs = CommonUtil.parseToArray(profanityScannerValidCSIDs, CommonDefs.VALUE_SEPARATOR_CHAR);

        if (alProfanityScannerValidCSIDs == null || alProfanityScannerValidCSIDs.isEmpty()) {
            stAppInfo = "Missing config parameter - " + profanityScannerValidCSIDs;
            logger.info("{}{}PSIRV2.1 {}:  " ,sClassName ,sMethodName,stAppInfo);
            return profanityScannerErrorResponse(CErrorDefs.ERR_CONFIG_NUM, stAppInfo, profanityScannerRequest.getIdpTraceId());
        }
        if (callingSystemId != null && (!alProfanityScannerValidCSIDs.contains(callingSystemId))) {
            stAppInfo = "callingSystemId [" + callingSystemId + "] is NOT one of the allowed IDs [" + alProfanityScannerValidCSIDs + "]";
            logger.info("{}{}PSIRV2.2 {}:  " ,sClassName ,sMethodName, StringUtils.normalizeSpace(stAppInfo));
            return profanityScannerErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, profanityScannerRequest.getIdpTraceId());
        }

        if (scanItemType != null && scanItemType.trim().length() > 0 && !CommonDefs.FIRST_NAME.equalsIgnoreCase(scanItemType) && !CommonDefs.PASSWORD.equalsIgnoreCase(scanItemType)
                && !CommonDefs.USER_ID.equalsIgnoreCase(scanItemType) && !CommonDefs.NICKNAME.equalsIgnoreCase(scanItemType)
                && !CommonDefs.LAST_NAME.equalsIgnoreCase(scanItemType)
                && !ProfileOrchestrationConstants.EMAIL_SMS_MSG.equalsIgnoreCase(scanItemType)) {
                stAppInfo = "Invalid scanItemType";
                logger.info(SpiMarker.getInstance(),"{}{}PSIRV2.3 {}:  " ,sClassName ,sMethodName,stAppInfo);
                return profanityScannerErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, profanityScannerRequest.getIdpTraceId());
        }
        return profanityScannerResponse;
    }
    /**
     * This method generates an error response for the Profanity Scanner.
     * It sets the app status code, app info, and trace ID in the response.
     * @param appStatusCode The application status code to be set in the response
     * @param stAppInfo The application info to be set in the response
     * @param stIdpTraceId The trace ID to be set in the response
     * @return ProfanityScannerResponse The response object containing the error details
     */
    private ProfanityScannerResponse profanityScannerErrorResponse(int appStatusCode, String stAppInfo, String stIdpTraceId) {

        Map<String, Object> hmResponse = CommonUtil.getHashMap();
        hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
        hmResponse.put("idp-trace-id", stIdpTraceId);
        hmResponse.put(CommonDefs.TRANSACTION_NAME, ProfileOrchestrationConstants.PROFANITY_SCANNER_TRANSACTION_NAME);
        hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
        return CommonUtilHelper.generateProfanityScannerResponse(hmResponse);
    }
}