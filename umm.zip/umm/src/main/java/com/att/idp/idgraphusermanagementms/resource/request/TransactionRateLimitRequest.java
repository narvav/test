package com.att.idp.idgraphusermanagementms.resource.request;

import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.Size;

import com.att.mpsys.common.utils.CommonDefs;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;


/**
 * This class represents a request to get the transaction rate limit status in the system.
 * It contains fields for transactionName, callingSystemId, ipAddress, ctn, isExternalCall, idpTraceId, and a map for unknownAttributes.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 *
 */
@Data
@Schema(name = "TransactionRateLimitRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionRateLimitRequest {
	private final String transactionName=CommonDefs.TXN_RATE_LIMIT_STATUS;
	
	@Size(min = 1, max = 20, message =  "CallingSystemId length is invalid|TxnRateLimitStatus")
	private String callingSystemId;
	
	@Schema(name = "ipAddress")
	@Size(min=1, max=100, message="ipAddress length is invalid|TxnRateLimitStatus")
	private String ipAddress;
	
	@Schema(name = "ctn")	
	@Size(min=10, max=10, message="CTN length is invalid|TxnRateLimitStatus")	
    protected String ctn;
	
	@Size(min = 1, max = 1, message =  "isExternalCall length is invalid|TxnRateLimitStatus")
	private String isExternalCall;	
	
	@Schema(name = "idpTraceId")
	private String idpTraceId;
	
	/**
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
	 * @return Map<String,Object> The map of unknown attributes.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();

	
}
