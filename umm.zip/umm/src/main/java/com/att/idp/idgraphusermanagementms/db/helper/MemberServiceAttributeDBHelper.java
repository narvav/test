package com.att.idp.idgraphusermanagementms.db.helper;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.att.common.validators.ServiceValidation;
import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.CommonDefs;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * This class is responsible for managing member service attributes in the database.
 * It uses Spring's JdbcTemplate for database operations.
 *
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like JdbcTemplate.
 *
 * The class contains a method for retrieving service attributes by member number.
 *
 * The main method in this class is:
 * - getServiceAttributesByMemberNum: This method retrieves service attributes by member number from the database. It takes a HashMap as input and returns a HashMap as output.
 *   The input HashMap contains key-value pairs for various service attributes like member number.
 *   The method first checks if the jdbcTemplate is null. If it is, it returns an error status.
 *   Then it retrieves the service attributes from the input HashMap.
 *   If the service attributes are not found, it returns an error status.
 *   Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
 *   Finally, it returns a status indicating whether the operation was successful or not.
 */

@Component
public class MemberServiceAttributeDBHelper {
	private static final String CLASS_NAME = "MemberServiceAttributeDBHelper";
	public static final Logger log = LoggerFactory.getLogger(MemberServiceAttributeDBHelper.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private DBHelper oDBHelper;

	@Autowired
	private ServiceValidation oServiceValidation;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	/**
	 * This method adds a service attribute to a member in the database.
	 * It takes a HashMap as input which should contain the necessary details for the operation.
	 * The HashMap contains details such as member number, service id, system of record id, instance id, system of record invariant id, attribute id, value, and last modified by.
	 * The method constructs a SQL insert query using these details and executes it using Spring's JdbcTemplate.
	 * If the operation fails, it logs the error message and returns an error map.
	 *
	 * @param hmInput A HashMap containing the input parameters for the operation. The keys should be the details for the operation and the values should be the corresponding values.
	 * @return A HashMap containing the result of the operation. If the operation is successful, the HashMap contains the number of rows inserted. If the operation fails, the HashMap contains an error message.
	 */
	public HashMap addServiceAttribute(HashMap hmInput) {

		String sInsertSQL = "INSERT INTO MEMBERSERVICEATTRIBUTE (" + "MEMBER_NUM, " + "SERVICE_ID, " + "SOR_ID, "
				+ "INSTANCE_ID, " + "SOR_INVARIANT_ID, " + "ATTRIBUTE_ID, " + "VALUE, " + "LAST_MODIFIED_BY) "
				+ "values(?,?,?,?,?,?,?,?)";

		String sThisMethod = "addServiceAttribute";
		String stAppInfo = null;
		HashMap hmResult = null;
		Date dtStartDate = new Date();
		List<Object> objectList = CommonUtil.getArrayList();

		log.info("{}{}DBTOOLS000 : addServiceAttribute InpParam : {}", CLASS_NAME, sThisMethod, hmInput!=null ?
				StringUtils.normalizeSpace(hmInput.toString()): null);

		try {

			if (jdbcTemplate == null) {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "jdbcTemplate is null.");
				log.error("response : {}", hmResult);
				return hmResult;
			}

			if (hmInput == null) {
				stAppInfo = "hmInput is null";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}MSADBH_ASA_01 : {}", CLASS_NAME, sThisMethod, stAppInfo);
				return hmResult;
			}

			String stMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
			String sServiceId = (String) hmInput.get(MPSDefs.DB_SERVICE_ID);
			String stLastModifiedBy = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sServiceName = (String) hmInput.get(MPSDefs.DB_SERVICE_NAME);
			String sSorId = (String) hmInput.get(MPSDefs.DB_SOR_ID);
			String sSorName = (String) hmInput.get(MPSDefs.DB_SOR_NAME);
			String sInstanceId = (String) hmInput.get(MPSDefs.DB_INSTANCE_ID);
			String sSorInvariantId = (String) hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
			String sAttributeId = (String) hmInput.get(MPSDefs.DB_ATTRIBUTE_ID);
			String sAttributeName = (String) hmInput.get("attributeName");
			String sAttributeValue = (String) hmInput.get("attributeValue");

			if ((sServiceId == null || sServiceId.trim().length() <= 0)
					&& (sServiceName == null || sServiceName.trim().length() <= 0)) {
				stAppInfo = "service_id or service_name is required";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}MSADBH_ASA_02 : {}{} ", CErrorDefs.ERR_INVALID_DATA_NUM, CLASS_NAME, sThisMethod,
						stAppInfo);
				return hmResult;
			}
			if (sAttributeName == null	|| sAttributeName.isEmpty()) {
				stAppInfo = "Required Parameter attribute_Name is missing";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}MSADBH_ASA_03 : {}", CLASS_NAME, sThisMethod, stAppInfo);
				return hmResult;
			}
			if (stMemberNum == null || stMemberNum.trim().length() <= 0 || stLastModifiedBy == null
					|| stLastModifiedBy.trim().length() <= 0 || sAttributeValue == null
					|| sAttributeValue.trim().length() <= 0) {
				stAppInfo = "Required Parameter member_num / last_modified_by / attribute_value is missing";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}MSADBH_ASA_04 : {}", CLASS_NAME, sThisMethod, stAppInfo);
				return hmResult;
			}

			if ((sServiceId == null || sServiceId.trim().length() <= 0) && !sServiceName.isEmpty()) {
				int serviceId = oDBHelper.getServiceId(sServiceName);
				sServiceId = String.valueOf(serviceId);
				log.info("{}{}MSADBH_ASA_05 : {}", CLASS_NAME, sThisMethod, sServiceId);
			}

			if ((sServiceName == null || sServiceName.trim().length() <= 0) && !sServiceId.isEmpty()) {
				sServiceName = oServiceValidation.getServiceNameById(sServiceId);
				log.info("{}{}MSADBH_ASA_06 : {}", CLASS_NAME, sThisMethod, sServiceName);
			}

			if ((sSorId == null || sSorId.trim().length() <= 0) && (sSorName != null && !sSorName.isEmpty())) {
				int tempSorId = oDBHelper.getSorId(sSorName);
				sSorId = String.valueOf(tempSorId);
				log.info("{}{}MSADBH_ASA_07 : {}",  CLASS_NAME, sThisMethod, sSorId);
			}

			if (sAttributeId == null || sAttributeId.trim().length() <= 0) {
				int tempsAttributeId = oDBHelper.getAttributeIdFromName(sAttributeName);
				sAttributeId = String.valueOf(tempsAttributeId);
				log.info("{}{}MSADBH_ASA_08 : {}", CLASS_NAME, sThisMethod,sAttributeId);
			}

			log.info("{}{}MSADBH_ASA_09 : Query SQL = {}", sThisMethod, sThisMethod, sInsertSQL);

			objectList.add(stMemberNum);
			log.debug("{}{}MSADBH_ASA_10 : member_num::PARAM 1 = {}", sThisMethod, sThisMethod, stMemberNum);

			objectList.add(sServiceId);
			log.debug("{}{}MSADBH_ASA_11 : service_id::PARAM 2 = {}", sThisMethod, sThisMethod, sServiceId);

			if (sSorId != null && !sSorId.isEmpty()) {
				objectList.add(sSorId);
				log.debug("{}{}MSADBH_ASA_12 : sor_id::PARAM 3 = {}", sThisMethod, sThisMethod, sSorId);
			} else {
				objectList.add(null);
				log.debug("{}{}MSADBH_ASA_13 : sor_id::PARAM 3 = {}", sThisMethod, sThisMethod, sSorId);
			}

			if (sInstanceId != null && !sInstanceId.isEmpty()) {
				objectList.add(sInstanceId);
				log.debug("{}{}MSADBH_ASA_14 : instance_id::PARAM 4 = {}", sThisMethod, sThisMethod, sInstanceId);

			} else {
				objectList.add(null);
				log.debug("{}{}MSADBH_ASA_15 : instance_id::PARAM 4 = {}", sThisMethod, sThisMethod, sInstanceId);
			}

			if (sSorInvariantId != null && !sSorInvariantId.isEmpty()) {
				objectList.add(sSorInvariantId);
				log.debug("{}{}MSADBH_ASA_16 : sor_invariant_id::PARAM 5 = {}", sThisMethod, sThisMethod, sSorInvariantId);
			} else {
				objectList.add(null);
				log.debug("{}{}MSADBH_ASA_17 : sor_invariant_id::PARAM 5 = {}", sThisMethod, sThisMethod, sSorInvariantId);
			}

			objectList.add(Integer.parseInt(sAttributeId));
			log.debug("{}{}MSADBH_ASA_18 : attribute_id::PARAM 6 = {}", sThisMethod, sThisMethod, sAttributeId);

            objectList.add(sAttributeValue);
            log.debug("{}{}MSADBH_ASA_19 : attributeValue::PARAM 7 = {}", sThisMethod, sThisMethod, sAttributeValue);

            objectList.add(stLastModifiedBy);
			log.debug("{}{}MSADBH_ASA_21 : sFromLastModifiedBy::PARAM 8 = {}", sThisMethod, sThisMethod, stLastModifiedBy);

			int rowCount = jdbcTemplate.update(new String(sInsertSQL),
					objectList.toArray(new Object[objectList.size()]));

			log.info("{}{}MSADBH_ASA_23 : {}", CLASS_NAME, sThisMethod,  rowCount);

			if (rowCount == 0) {
				log.info("{}{}MSADBH_ASA_24 : {}{}", CErrorDefs.ERR_REC_NOT_FOUND_NUM, CLASS_NAME, sThisMethod,
						"No row Inserted");
			}
			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}MSADBH_ASA_25 :  Error::{}", sThisMethod, sThisMethod, e.getMessage());

		} finally {
			log.info("{}{}DBTOOLS999 : {} response : {}", sThisMethod, sThisMethod, dtStartDate.getTime(), hmResult);
		}
		return hmResult;
	}
	public HashMap<String, Object> updateServiceAttribute(HashMap hmInput) {

		String sThisMethod = ".updateServiceAttribute.";
		HashMap<String, Object> hmResult = null;
		List<Object> objectList = new ArrayList<>();

		int serviceId = 0;
		String stAppInfo = null;
		String sWhereClause = null;
		if (hmInput == null || hmInput.isEmpty()) {
			stAppInfo = "hmInput is null";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			log.info("{}{}MSADB.USA.01 : Output from updateServiceAttribute = :  {} ", CLASS_NAME, sThisMethod, stAppInfo);
			return hmResult;
		}
		StringBuilder sbUpdateServiceContact = new StringBuilder(
				"UPDATE MEMBERSERVICEATTRIBUTE SET LAST_MODIFIED_BY=? VALUE=? WHERE ");

		log.info("{}{}DBTOOLS000 : InpParam : {}", CLASS_NAME, sThisMethod, hmInput!=null ?
				StringUtils.normalizeSpace(hmInput.toString()): null);

		int iServiceId = 0;
		try {

			if (jdbcTemplate == null) {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "jdbcTemplate is null.");
				log.error("response : {}", hmResult);
				return hmResult;
			}

			String stMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
			String sServiceId = (String) hmInput.get(MPSDefs.DB_SERVICE_ID);
			String sServiceName = (String) hmInput.get(MPSDefs.DB_SERVICE_NAME);
			String sSorId = (String) hmInput.get(MPSDefs.DB_SOR_ID);
			String sSorName = (String) hmInput.get(MPSDefs.DB_SOR_NAME);
			String sSorInvariantId = (String) hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
			String sAttributeId = (String) hmInput.get(MPSDefs.DB_ATTRIBUTE_ID);
			String sAttributeName = (String) hmInput.get(MPSDefs.DB_ATTRIBUTE_NAME);
			String sAttributeValue = (String) hmInput.get(MPSDefs.DB_ATTRIBUTE_VALUE);
			String sOldAttributeValue = (String) hmInput.get("old_attribute_value");
			String stLastModifiedBy = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sInstanceId = (String) hmInput.get(MPSDefs.DB_INSTANCE_ID);


			if (stMemberNum==null ||stMemberNum.trim().isEmpty()||sAttributeId==null ||sAttributeId.trim().isEmpty()
					||sAttributeName==null||sAttributeName.trim().isEmpty()||sOldAttributeValue==null ||sOldAttributeValue.trim().isEmpty()
					||sServiceId==null ||sServiceId.trim().isEmpty()||sServiceName==null ||sServiceName.trim().isEmpty()
					||stLastModifiedBy == null || stLastModifiedBy.trim().isEmpty()||sAttributeValue==null ||sAttributeValue.trim().isEmpty()) {

				stAppInfo = "Required Parameter member_num / attribute_id / attribute_name / old_attribute_value / service_id / service_name / last_modified_by / attribute_value is missing";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{}MSADB.USA.02: {}", CLASS_NAME, sThisMethod, stAppInfo);
				return hmResult;
			}


			if ((sServiceId == null || sServiceId.trim().length() == 0) &&
					(sServiceName != null && !sServiceName.trim().isEmpty()) )
			{
				iServiceId = oDBHelper.getServiceId(sServiceName);
				log.info("{}{} MSADB.USA.03: {}", CLASS_NAME, sThisMethod, iServiceId);
			}
			if((sServiceName == null || sServiceName.trim().length() <=0) &&
					(sServiceId != null && sServiceId.length() > 0)){
				sServiceName = oDBHelper.getServiceName(sServiceId);
				log.info("{}{}MSADB.USA.04: {}", CLASS_NAME, sThisMethod, sServiceName);
			}

			if((sAttributeId == null || sAttributeId.trim().length() <=0) &&
					(sAttributeName != null && sAttributeName.length() > 0)){
				sAttributeId = String.valueOf(oDBHelper.getAttributeIdFromName(sAttributeName));
				log.info("{}{}MSADB.USA.05: {}", CLASS_NAME, sThisMethod, sServiceName);
			}

			log.info("{}{}MSADB.USA.06 : Query SQL = {}", sThisMethod, sThisMethod, sbUpdateServiceContact);

			if (!stMemberNum.isEmpty()){
				sbUpdateServiceContact.append("MEMBER_NUM = ? ");
			}else if(!sOldAttributeValue.isEmpty()){
				sbUpdateServiceContact.append("VALUE = ? ");
			}

			sbUpdateServiceContact.append(" AND ATTRIBUTE_ID = ? ");
			sbUpdateServiceContact.append(" AND SERVICE_ID = ? ");

			if ((sSorId == null || sSorId.trim().isEmpty()) &&
					(sSorName!= null && !sSorName.trim().isEmpty()) )
			{
				sSorId = String.valueOf(oDBHelper.getSorId(sSorName));
				}
			else if (sSorId != null && !sSorId.trim().isEmpty()) {
				sSorId = String.valueOf(Integer.parseInt(sSorId));
			}
			log.debug("{}{}MSADB.USA.06 : Got sor_id from cache= {}", CLASS_NAME, sThisMethod, sSorId);
			if(sSorId != null){
				sbUpdateServiceContact.append(" AND SOR_ID = ? ");
			}
			if (sInstanceId != null && !sInstanceId.trim().isEmpty()){
				sbUpdateServiceContact.append(" AND INSTANCE_ID = ? ");
			}
			if (sSorInvariantId != null && !sSorInvariantId.trim().isEmpty()){
				sbUpdateServiceContact.append(" AND SOR_INVARIANT_ID = ? ");
			}

			objectList.add(stLastModifiedBy);
			log.debug("{}{}MSADB.USA.07 : member_num::PARAM 1 = {}", CLASS_NAME, sThisMethod, stLastModifiedBy);

			objectList.add(sAttributeValue);
			log.debug("{}{}MSADB.USA.08 : service_id::PARAM 2 = {}", CLASS_NAME, sThisMethod, sAttributeValue);

			if (!stMemberNum.isEmpty()){
				objectList.add(stMemberNum);
				log.debug("{}{}MSADB.USA.09 : stMemberNum::PARAM 3 = {}", CLASS_NAME, sThisMethod, stMemberNum);
			}else if(!sOldAttributeValue.isEmpty()){
				objectList.add(sOldAttributeValue);
				log.debug("{}{}MSADB.USA.10 : sOldAttributeValue::PARAM 3 = {}", CLASS_NAME, sThisMethod, stMemberNum);
			}

			objectList.add(sAttributeId);
			if (!sServiceId.trim().isEmpty())
			{
				objectList.add(sServiceId);
				log.debug("{}{}MSADB.USA.11 : service_id::PARAM 3 = {}", CLASS_NAME, sThisMethod, sServiceId);
			}

			if (sSorId != null && !sSorId.trim().isEmpty())
			{
				objectList.add(sSorId);
				log.debug("{}{}MSADB.USA.12 : service_id::PARAM 3 = {}", CLASS_NAME, sThisMethod, sSorId);
			}

			if (sInstanceId != null && !sInstanceId.trim().isEmpty())
			{
				objectList.add(sInstanceId);
				log.debug("{}{}MSADB.USA.13: service_id::PARAM 3 = {}", CLASS_NAME, sThisMethod, sInstanceId);
			}

			if (sSorInvariantId != null && !sSorInvariantId.trim().isEmpty())
			{
				objectList.add(sSorInvariantId);
				log.debug("{}{}MSADB.USA.14 : service_id::PARAM 3 = {}", CLASS_NAME, sThisMethod, sSorInvariantId);
			}


			int rowCount = jdbcTemplate.update(new String(sbUpdateServiceContact),
					objectList.toArray(new Object[objectList.size()]));

			log.info("{}{}MSADB.USA.15 : row count {}",  CLASS_NAME, sThisMethod, rowCount);

			if (rowCount == 0) {
				log.info("{}{}MSADB.USA.16 : {}{}", CErrorDefs.ERR_REC_NOT_FOUND_NUM, CLASS_NAME, sThisMethod,
						"No row updated");
			}
			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}MSADB.USA.17:  Error::{}", CLASS_NAME, sThisMethod, e.getMessage());

		} finally {
			log.info("{}{}DBTOOLS999 : Output from addService = {}", CLASS_NAME, sThisMethod, hmResult);
		}
		return hmResult;
	}

	/**
	 * This method retrieves service attributes by member number from the database.
	 * It takes a HashMap as input which contains key-value pairs for various service attributes like member number.
	 * The method first checks if the jdbcTemplate is null. If it is, it returns an error status.
	 * Then it retrieves the service attributes from the input HashMap.
	 * If the service attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param hmInput A HashMap containing the details of the service attributes to be retrieved.
	 * @return A HashMap containing the status of the operation and the retrieved service attributes.
	 */
	public HashMap getServiceAttributesByMemberNum(HashMap hmInput) {
		String sThisMethod = ".getServiceAttributesByMemberNum.";
		log.info(ProfileOrchestrationConstants.LOG_DBTOOLS000, CLASS_NAME, sThisMethod,hmInput);

		HashMap<String, Object> hmResult = null;
		String sMemberNum = null;

		String sServiceName = null;
		String sSorInvariantId = null;
		HashMap<String, Object> hmServices = new HashMap();
		HashMap hmServiceSorInvariantIDs = null;
		ArrayList alSorInvariantId = null;
		ArrayList alServiceAttributes = new ArrayList();
		List alQueryResponse = null;

		try {
			String dateFormat = "MMDDYYYY HH24:mi:ss";
			String queryServiceAttributesSql = "SELECT msa.member_num, msa.service_id, ser.service_name, "
					+ " msa.sor_id, sor.sor_name, msa.sor_invariant_id, msa.instance_id, "
					+ " msa.attribute_id, attr.attribute_name, msa.value as attribute_value, "
					+ " TO_CHAR(msa.create_date, '" + dateFormat
					+ "') AS create_date, TO_CHAR(msa.last_modified, '"
					+ dateFormat + "') AS last_modified, msa.last_modified_by"
					+ " FROM memberserviceattribute msa, service ser, "
					+ " systemofrecord sor, attribute attr"
					+ " WHERE msa.service_id = ser.service_id AND msa.sor_id = sor.sor_id AND msa.attribute_id = attr.attribute_id "
					+ " AND msa.member_num = ?";

			sMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);

			if (sMemberNum == null || sMemberNum.trim().isEmpty()) {
				String appInfo = "member_num is null or missing in input";
				log.info(CLASS_NAME, sThisMethod,
						CErrorDefs.ERR_INVALID_DATA_NUM + " DB_SA_92: ",
						appInfo);
				hmResult = CommonErrorMap.makeCategoryMap(
						CErrorDefs.ERR_INVALID_DATA_NUM, appInfo);
				return hmResult;
			}

			log.info(CLASS_NAME, sThisMethod, "{}{}DB_SA_93: {}", queryServiceAttributesSql);

			long pTime = 0;
			Date dtStartDate = new Date();

			alQueryResponse = jdbcTemplate.queryForList(
					new String(queryServiceAttributesSql), sMemberNum);

			// pt637d - to return time in milliseconds for APRIL2011
			pTime = (System.currentTimeMillis() - dtStartDate.getTime());

			log.info(CLASS_NAME, sThisMethod, "QUERY999",
					"Total time taken to execute query = " + pTime
							+ " milliseconds");

			int rowCount = 0;
			HashMap<String, Object> hmAttributes = null;

			if (!alQueryResponse.isEmpty()) {

                for (Object o : alQueryResponse) {
                    Map hmQuerySvcAttributeResp = (Map) o;

                    if (hmQuerySvcAttributeResp != null
                            && !hmQuerySvcAttributeResp.isEmpty()) {
                        for (Object object : hmQuerySvcAttributeResp.keySet()) {
                            ++rowCount;
                            String key = (String) object;
                            Object value = hmQuerySvcAttributeResp.get(key);

                            String strValue = (value == null
                                    ? null
                                    : value.toString());

                            hmQuerySvcAttributeResp.put(key, strValue);
                        }
                        hmAttributes = CommonUtil.getHashMap();

                        hmAttributes.put(MPSDefs.DB_SOR_ID,
                                hmQuerySvcAttributeResp
                                        .get(MPSDefs.DB_SOR_ID));
                        hmAttributes.put(MPSDefs.DB_SOR_NAME,
                                hmQuerySvcAttributeResp
                                        .get(MPSDefs.DB_SOR_NAME));
                        hmAttributes.put(MPSDefs.DB_SERVICE_ID,
                                hmQuerySvcAttributeResp
                                        .get(MPSDefs.DB_SERVICE_ID));
                        hmAttributes.put(MPSDefs.DB_SERVICE_NAME,
                                hmQuerySvcAttributeResp
                                        .get(MPSDefs.DB_SERVICE_NAME));
                        hmAttributes.put(MPSDefs.DB_INSTANCE_ID,
                                hmQuerySvcAttributeResp
                                        .get(MPSDefs.DB_INSTANCE_ID));
                        hmAttributes.put(MPSDefs.DB_SOR_INVARIANT_ID,
                                hmQuerySvcAttributeResp
                                        .get(MPSDefs.DB_SOR_INVARIANT_ID));
                        hmAttributes.put(MPSDefs.DB_ATTRIBUTE_ID,
                                hmQuerySvcAttributeResp
                                        .get(MPSDefs.DB_ATTRIBUTE_ID));
                        hmAttributes.put(MPSDefs.DB_ATTRIBUTE_NAME,
                                hmQuerySvcAttributeResp
                                        .get(MPSDefs.DB_ATTRIBUTE_NAME));
                        hmAttributes.put(MPSDefs.DB_ATTRIBUTE_VALUE,
                                hmQuerySvcAttributeResp
                                        .get(MPSDefs.DB_ATTRIBUTE_VALUE));
                        hmAttributes.put(MPSDefs.DB_CREATE_DATE,
                                hmQuerySvcAttributeResp
                                        .get(MPSDefs.DB_CREATE_DATE));
                        hmAttributes.put(MPSDefs.DB_LAST_MODIFIED,
                                hmQuerySvcAttributeResp
                                        .get(MPSDefs.DB_LAST_MODIFIED));
                        hmAttributes.put(MPSDefs.DB_LAST_MODIFIED_BY,
                                hmQuerySvcAttributeResp
                                        .get(MPSDefs.DB_LAST_MODIFIED_BY));

                        sServiceName = (String) hmQuerySvcAttributeResp
                                .get(MPSDefs.DB_SERVICE_NAME);
                        sSorInvariantId = (String) hmQuerySvcAttributeResp
                                .get(MPSDefs.DB_SOR_INVARIANT_ID);
                    }

                    if (hmServices.containsKey(sServiceName)) {
                        hmServiceSorInvariantIDs = (HashMap) hmServices
                                .get(sServiceName);
                    } else {
                        hmServiceSorInvariantIDs = CommonUtil.getHashMap();
                        hmServices.put(sServiceName, hmServiceSorInvariantIDs);
                    }

                    if (hmServiceSorInvariantIDs.containsKey(sSorInvariantId)) {
                        alSorInvariantId = (ArrayList) hmServiceSorInvariantIDs
                                .get(sSorInvariantId);
                    } else {
                        alSorInvariantId = CommonUtil.getArrayList();
                        hmServiceSorInvariantIDs.put(sSorInvariantId,
                                alSorInvariantId);
                    }

                    alSorInvariantId.add(hmAttributes);
                }
			}

			if (rowCount == 0) {
				hmResult = CommonErrorMap.makeCategoryMap(
						CErrorDefs.ERR_REC_NOT_FOUND_NUM,
						CErrorDefs.ERR_REC_NOT_FOUND_MSG);
				log.info(CLASS_NAME, sThisMethod,
						CErrorDefs.ERR_REC_NOT_FOUND_NUM + " DB_SA_94: ",
						"No row found");
				return hmResult;
			}

			hmResult = CommonErrorMap
					.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success");
			hmResult.put(MPSDefs.DB_MEMBER_SERVICE_ATTRIBUTE, hmServices);
		} catch (Exception excp) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(excp);
			String errorCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
			String sAppInfo = (String) hmResult.get(CErrorDefs.COMMON_APP_INFO);
			if (sAppInfo == null)
				hmResult.put(CErrorDefs.COMMON_APP_INFO, excp.getMessage());

			log.error("{}{}DMDH.DGS.07 : Error:: {}", CLASS_NAME, sThisMethod, excp.getMessage());
			log.error("{}{}DMDH.DGS.08 : Exception = {}", CLASS_NAME, sThisMethod, errorCode);

		} finally {
			log.info("{}{}DBTOOLS999 : response : {}", CLASS_NAME, sThisMethod,
					hmResult);
		}
		
		return hmResult;
	}
}
