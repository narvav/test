package com.att.idp.idgraphusermanagementms.db.repository.impl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;

import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.mpsys.common.utils.PropertyManager;
import com.att.idp.idgraphusermanagementms.db.model.Tmember;
import com.att.idp.idgraphusermanagementms.db.model.Tsecurityquestion;
import com.att.idp.idgraphusermanagementms.db.repository.DomainRepository;
import com.att.idp.idgraphusermanagementms.db.repository.IDMProfileOrchestrationCustomRepository;
import com.att.idp.idgraphusermanagementms.db.repository.MemberAuxRepository;
import com.att.idp.idgraphusermanagementms.db.repository.MemberRepositoryCustom;
import com.att.idp.idgraphusermanagementms.db.repository.NetWorkAccessServiceRepository;
import com.att.idp.idgraphusermanagementms.db.repository.SecurityQuestionRepository;
import com.att.idp.idgraphusermanagementms.db.repository.StatusRepository;
import com.att.idp.idgraphusermanagementms.db.repository.SystemOfRecordRepository;
import com.att.idp.idgraphusermanagementms.db.request.MemberAuxRequest;
import com.att.idp.idgraphusermanagementms.db.request.MemberRequest;
import com.att.idp.idgraphusermanagementms.helper.voltage.ProcessVoltageHelper;
import com.att.idp.idgraphusermanagementms.utils.DateUtil;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.StatusMsg;

import io.micrometer.core.instrument.util.StringUtils;
import net.logstash.logback.argument.StructuredArguments;

/**
 * This is the implementation class for the MemberRepositoryCustom interface.
 * It extends IDMProfileOrchestrationCustomRepository for common CRUD operations.
 * The entity associated with this repository is Tmember and the ID type is Long.
 */
@Component
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class MemberRepositoryImpl extends IDMProfileOrchestrationCustomRepository<Tmember, Long> implements MemberRepositoryCustom {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(MemberRepositoryImpl.class);
	
	private static String sClassName = "MemberRepositoryImpl";
	
	@Autowired
	private NetWorkAccessServiceRepository networkAccessRepo;
	
	@Autowired
	private SystemOfRecordRepository sorRepo;
	
	@Autowired
	private DomainRepository domainRepo;
	
	@Autowired
	private SecurityQuestionRepository secQuestionRepo;
	
	@Autowired
	private StatusRepository statusRepo;
	
	@Autowired
	private ProcessVoltageHelper oProcessVoltageHelper;
	
	@Autowired
	private MemberAuxRepository memberAuxRepo;
	
	@Value("${RILHRS_ValidDomains}")
	private String propDBDomainList;

	private  String queryGetTitanAccount =
			"SELECT m.member_num, m.member_name, m.contact_email, 'TITAN' search_entity, ms.sor_invariant_id entity_identifier, " +
			" sr.role_name, '1' rank " +
			" FROM member m, memberservice ms, mps_owner.memberservicerole msr, mps_owner.servicerole sr " +
			" WHERE m.member_num = ms.member_num and m.parent_child_ind = 'S' and " +
			" ms.member_num = msr.member_num and ms.service_id = msr.service_id and " +
			" msr.role_id = sr.role_id and msr.service_id = sr.service_id and " +
			" ms.sor_id = msr.sor_id and " +
			" ms.sor_invariant_id = msr.sor_invariant_id and " +
			" ms.service_id = 33 and ms.sor_id = 6 and ms.sor_invariant_id = :titanSorInvariantId ";
	
	private  String queryGetStandaloneMobility = 
			"SELECT m.member_num, m.member_name, m.contact_email, 'MOBILITY' search_entity, ms.sor_invariant_id entity_identifier, " +
			" sr.role_name, '2' rank " +
			" FROM member m, memberservice ms, mps_owner.memberservicerole msr, mps_owner.servicerole sr " +
			" WHERE m.member_num = ms.member_num and m.parent_child_ind = 'S' and " + 
			" ms.member_num = msr.member_num and ms.service_id = msr.service_id and " + 
			" ms.sor_id = msr.sor_id and " + 
			" ms.sor_invariant_id = msr.sor_invariant_id and " + 
			" ms.parent_sor_id is null and ms.parent_sor_invariant_id is null and " +
			" msr.role_id = sr.role_id and msr.service_id = sr.service_id and " + 
			" ms.service_id = 32 and ms.sor_id = 13 and ms.sor_invariant_id = :mobilitySorInvariantId ";
	
	private  String queryGetTitanizedMobility = 
			
			"SELECT m.member_num, m.member_name, m.contact_email, 'MOBILITY' search_entity, ms.sor_invariant_id entity_identifier, " +
			" sr.role_name, " +
			" '3' rank " +
			" FROM member m, memberservice ms, mps_owner.memberservicerole msr, mps_owner.servicerole sr " +
			" WHERE m.member_num = ms.member_num and m.parent_child_ind = 'S' and " +
			" ms.parent_sor_id is not null and ms.parent_sor_invariant_id is not null " +
			" AND msr.member_num(+) = ms.member_num " +
			" AND msr.service_id(+) = 33 " +
			" AND msr.sor_id(+) = ms.parent_sor_id " +
			" AND msr.sor_invariant_id(+) = ms.parent_sor_invariant_id " +
			" AND sr.role_id = msr.role_id " +
			" AND sr.service_id = msr.service_id " +
			" AND ms.service_id = 32 and ms.sor_id = 13 and ms.sor_invariant_id = :mobilitySorInvariantId ";

	
	private  String queryGetDirectvNow = 
			"SELECT m.member_num, m.member_name, m.contact_email, 'DIRECTVNOW' search_entity, ms.sor_invariant_id entity_identifier, " +
			" 'NA' role_name, " +
			" '4' rank " +
			" FROM member m, memberservice ms " +
			" WHERE m.member_num = ms.member_num and m.parent_child_ind = 'S' and " + 
			" ms.service_id = 56 and ms.sor_id = 23 and ms.sor_invariant_id = :dtvSorInvariantId ";
	

	private  String queryMemberName = 
			"SELECT m.member_num, m.member_name, m.contact_email, 'CONTACT_EMAIL_ACCESSID' search_entity, m.member_name entity_identifier, " +
			" 'NA' role_name, " +
			" '5' rank " +
			" FROM member m " +
			" WHERE m.parent_child_ind = 'S' and m.member_name = :contactEmail"; 
	
	
	private  String queryDmctn = 
			"select m.member_num, m.member_name, m.contact_email, 'DMCTN' search_entity, ms.instance_id entity_identifier, " +
			" 'NA' role_name, " +
			" '6' rank " +
			" from member m, memberservice ms " +
			" where m.member_num = ms.member_num and m.parent_child_ind = 'S' and " + 
			" ms.service_id = 23 and ms.instance_id = :dmCTN ";  

	private  String queryContactEmail = 
			"SELECT m.member_num, m.member_name, m.contact_email, 'CONTACT_EMAIL' search_entity, m.contact_email entity_identifier, " +
			" 'NA' role_name, " +
			" '7' rank " +
			" FROM member m " +
			" WHERE m.contact_email is not null and m.member_name <> m.contact_email and m.parent_child_ind = 'S' and m.contact_email = :contactEmail ";

	
	private  String queryContactEmailMID = 
			"select s.member_num, s.member_name, s.contact_email, 'CONTACT_EMAIL_MID' search_entity, m.member_name||'@'||d.domain_name entity_identifier, " +
			" 'NA' role_name, " +
			" '8' rank " +
			" from member m, member s, domain d " +
			" where s.member_num = m.slid_member_num and m.parent_child_ind in ('P', 'C') and m.domain_id = d.domain_id and m.member_name = :memberName and d.domain_name = :domainName ";

	private String queryGetWatchTV =  "SELECT m.member_num, m.member_name, m.contact_email, 'WATCHTV' search_entity, ms.sor_invariant_id entity_identifier, " + 
            " 'NA' role_name, " + 
            " '9' rank " + 
            " FROM member m, memberservice ms " + 
            " WHERE m.member_num = ms.member_num and m.parent_child_ind = 'S' and " + 
            " ms.service_id = 59 and ms.sor_id = 25 and ms.sor_invariant_id = :watchTVSorInvariantId "; 
	
	private  String queryGetEcommAccount =
			"SELECT m.member_num, m.member_name, m.contact_email, 'ECOMM' search_entity, ms.sor_invariant_id entity_identifier, " +
			" sr.role_name, '10' rank " +
			" FROM member m, memberservice ms, mps_owner.memberservicerole msr, mps_owner.servicerole sr " +
			" WHERE m.member_num = ms.member_num and m.parent_child_ind = 'S' and " +
			" ms.member_num = msr.member_num and ms.service_id = msr.service_id and " +
			" msr.role_id = sr.role_id and msr.service_id = sr.service_id and " +
			" ms.sor_id = msr.sor_id and " +
			" ms.sor_invariant_id = msr.sor_invariant_id and " +
			" ms.service_id = 10 and ms.sor_id in (7, 16) and ms.sor_invariant_id = :ecommSorInvariantId ";
	
	private  String queryGetIndividual = 
			"SELECT m.member_num, m.member_name, m.contact_email, 'INDIVIDUAL' search_entity, ms.sor_invariant_id entity_identifier, " +
			" 'NA' role_name, " + 
			" '11' rank " + 
			" FROM member m, memberservice ms " + 
			" WHERE m.member_num = ms.member_num and m.parent_child_ind = 'S' and " + 
			" ms.service_id = 61 and ms.sor_id = 27 and ms.sor_invariant_id = :individualSorInvariantId ";
	
	@Override
	protected Class<Tmember> getClassT() {
		return Tmember.class;
	}

	@Override
	public BigDecimal getMemberNumSequence() {
		final Session session = entityManager.unwrap(Session.class);
		Query<?> q = session.createNativeQuery("SELECT MPS_OWNER.MEMBER_NUM_SEQ.nextval FROM dual");
		return (BigDecimal)q.getSingleResult();
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public HashMap addMem(HashMap InpParam) throws SQLException {
		String sMethodName = ".addMember.";
		String stAppInfo = null;
		String appStatusCode = null;
		LOGGER.info(SpiMarker.getInstance(),"MemberRepositoryImpl.addMem.DBTOOLS000 : InpParam : ", StructuredArguments.entries(InpParam));

		HashMap status = null;

		status = oProcessVoltageHelper.voltageEncryptSPIFields(InpParam);

		if (status == null || status.isEmpty()) {
			stAppInfo = "status HashMap from ProcessVoltageHelper is null";
			status = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			LOGGER.error("{}{}MR_02 : {}",sClassName,sMethodName, stAppInfo);
		}

		appStatusCode = (String) status.get(CommonDefs.COMMON_APP_STATUS_CODE);

		if (appStatusCode != null && !appStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
			stAppInfo = (String) status.get(CommonDefs.COMMON_APP_INFO);
			status = CommonErrorMap.makeCategoryMap(Integer.parseInt(appStatusCode), stAppInfo);
			LOGGER.info("{}{}MR_03 : {}",sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
			return status;
		} 
		
		String member_name = (String) InpParam.get(MPSDefs.DB_MEMBER_NAME);
		String domain_id_str = (String) InpParam.get(MPSDefs.DB_DOMAIN_ID);
		String group_num_str = (String) InpParam.get(MPSDefs.DB_GROUP_NUM);
		String enc_password = (String) InpParam.get(MPSDefs.DB_ENC_PASSWORD);
		String md5_password = (String) InpParam.get(MPSDefs.DB_MD5_PASSWORD);
		String parent_child_ind = (String) InpParam.get(MPSDefs.DB_PARENT_CHILD_IND);
		String access_id_str = (String) InpParam.get(MPSDefs.DB_ACCESS_ID);
		String access_name = (String) InpParam.get(MPSDefs.DB_ACCESS_NAME);
		String sor_name = (String) InpParam.get(MPSDefs.DB_SOR_NAME);
		String mailhost = (String) InpParam.get(MPSDefs.DB_MAILHOST);
		String fullname = (String) InpParam.get(MPSDefs.DB_FULLNAME);
		String migration_ind = (String) InpParam.get(MPSDefs.DB_MIGRATION_IND);
		String migration_date = (String) InpParam.get(MPSDefs.DB_MIGRATION_DATE);
		String account_type = (String) InpParam.get(MPSDefs.DB_ACCOUNT_TYPE);
		String sor_id_str = (String) InpParam.get(MPSDefs.DB_SOR_ID);
		String last_modified_by = (String) InpParam.get(MPSDefs.DB_LAST_MODIFIED_BY);
		String ban = (String) InpParam.get(MPSDefs.DB_BAN);
		String delete_request_date = (String) InpParam.get(MPSDefs.DB_DELETE_REQUEST_DATE);
		String token = (String) InpParam.get(MPSDefs.DB_TOKEN);

		String des3_password = (String) InpParam.get(MPSDefs.DB_DES3_PASSWORD);
		String sha1_password = (String) InpParam.get(MPSDefs.DB_SHA1_PASSWORD);
		String ssha_password = (String) InpParam.get(CommonDefs.DB_SSHA_PASSWORD);
		// 2103 - SSHA-256 encryption changes
		String gen_password = (String) InpParam.get(CommonDefs.DB_GEN_PASSWORD);
		String gen_password_type = (String) InpParam.get(CommonDefs.DB_GEN_PASSWORD_TYPE);

		String contact_email = (String) InpParam.get(MPSDefs.DB_CONTACT_EMAIL);
		String contact_email_valid = (String) InpParam.get(MPSDefs.DB_CONTACT_EMAIL_VALID);
		String password_dirty = (String) InpParam.get(MPSDefs.DB_PASSWORD_DIRTY);
		String language = (String) InpParam.get(MPSDefs.DB_LANGUAGE);
		String browser_language = (String) InpParam.get(MPSDefs.DB_BROWSER_LANGUAGE);

		String autogenerated_ind = (String) InpParam.get(MPSDefs.DB_AUTOGENERATED_IND);
		String activated_ind = (String) InpParam.get(MPSDefs.DB_ACTIVATED_IND);
		String slid_member_num_str = (String) InpParam.get(MPSDefs.DB_SLID_MEMBER_NUM);
		String birthdate_venc = (String) InpParam.get(MPSDefs.DB_BIRTHDATE_VENC);
		String passcode_venc = (String) InpParam.get(MPSDefs.DB_PASSCODE_VENC);
		String security_answer_venc = (String) InpParam.get(MPSDefs.DB_SECURITY_ANSWER_VENC);
		String contact_email_rtv_date = (String) InpParam.get("contact_email_rtv_date");
		String accessid_rtv_date = (String) InpParam.get("accessid_rtv_date");

		Long domain_id = null;
		long group_num = -1;
		Long slid_member_num = -1L;
		int sor_id = -1;
		int access_id = -1;
		
		Long memberNumber = 0L;

		String credit_checked_ind = (String) InpParam.get(MPSDefs.DB_CREDIT_CHECKED_IND);
		String yreg_complete_ind = (String) InpParam.get(MPSDefs.DB_YREG_COMPLETE_IND);
		String lockout_timestamp = (String) InpParam.get(MPSDefs.DB_LOCKOUT_TIMESTAMP);
		String firstname = (String) InpParam.get(MPSDefs.DB_LC_FIRSTNAME);
		String lastname = (String) InpParam.get(MPSDefs.DB_LC_LASTNAME);
		String nickname = (String) InpParam.get(MPSDefs.DB_NICKNAME);
		String last_four_ssn = (String) InpParam.get(MPSDefs.DB_LAST_FOUR_SSN);

		String security_question = (String) InpParam.get(MPSDefs.DB_SECURITY_QUESTION);

		String security_question_1 = (String) InpParam.get(MPSDefs.DB_SECURITY_QUESTION_1);
		String security_answer_1 = (String) InpParam.get(MPSDefs.DB_SECURITY_ANSWER_1);

		String security_question_2 = (String) InpParam.get(MPSDefs.DB_SECURITY_QUESTION_2);
		String security_answer_2 = (String) InpParam.get(MPSDefs.DB_SECURITY_ANSWER_2);

		String security_question_id_1_str = (String) InpParam.get(MPSDefs.DB_SECURITY_QUESTION_ID_1);
		String security_question_id_2_str = (String) InpParam.get(MPSDefs.DB_SECURITY_QUESTION_ID_2);
		String security_question_id_str = (String) InpParam.get(MPSDefs.DB_SECURITY_QUESTION_ID);

		String gender = (String) InpParam.get(MPSDefs.DB_GENDER);
		String proofing_zip = (String) InpParam.get(MPSDefs.DB_PROOFING_ZIP);
		String dsl_net_password = (String) InpParam.get(MPSDefs.DB_DSL_NET_PASSWORD);
		String dsl_net_pw_encr_type = (String) InpParam.get(MPSDefs.DB_DSL_NET_ENCR_TYPE);
		String contact_email_est_date = (String) InpParam.get(MPSDefs.DB_CONTACT_EMAIL_EST_DATE);
		String previous_contact_email = (String) InpParam.get(MPSDefs.DB_PREVIOUS_CONTACT_EMAIL);
		String onl_qa_est_date = (String) InpParam.get(MPSDefs.DB_ONL_QA_EST_DATE);

		String security_answer_1_venc = (String) InpParam.get(MPSDefs.DB_SECURITY_ANSWER_1_VENC);
		String security_answer_2_venc = (String) InpParam.get(MPSDefs.DB_SECURITY_ANSWER_2_VENC);
		
		String sExternalGuid = (String) InpParam.get(CommonDefs.EXT_GUID);
		long lExternalGuid = 0;
		if (sExternalGuid != null && !sExternalGuid.trim().isEmpty()) {
			lExternalGuid = Long.parseLong(sExternalGuid);
		}
		String fn_linked_userId = (String) InpParam.get(CommonDefs.DB_FN_LINKED_USERID);
		String fn_linked_status = (String) InpParam.get(CommonDefs.DB_FN_LINKED_STATUS);
		String cbr_number = (String) InpParam.get(ProfileOrchestrationConstants.DB_CBR_NUMBER);
		String cbr_rt_valid_date = (String) InpParam.get(ProfileOrchestrationConstants.DB_CBR_RTV_DATE);
		String contact_address = (String) InpParam.get(ProfileOrchestrationConstants.DB_CONTACT_ADDRESS);

		Long security_question_id = (long) -1;
		Long security_question_id_1 = (long) -1;
		Long security_question_id_2 = (long) -1;
		
		java.sql.Date migrationSQLDate = null;

		try {
			if (migration_ind == null || migration_ind.isEmpty()) {
				if (CommonDefs.DATAMGT.equals(last_modified_by)) {
					if (InpParam.get(MPSDefs.DB_DOMAIN_NAME).equals(CommonDefs.SLID_DUM)) {
						if (member_name != null && member_name.indexOf("@") > 0) {
							String sSlidDomain = member_name.substring(member_name.indexOf("@") + 1,
									member_name.length());
							Long iDomainId = null;
							SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
							if (sSlidDomain != null) {
								iDomainId = domainRepo.getDomainId(sSlidDomain);
								if ((iDomainId != null)) {
									migration_ind = MPSDefs.YES;
									migration_date = sdf.format(new Date());
									java.util.Date migrationDate = sdf.parse(migration_date);
									migrationSQLDate = new java.sql.Date(migrationDate.getTime());

								}
							}
						}
					}
				}
			}
			
			Long initMillis = Long.valueOf(System.currentTimeMillis());
			Long temp_sor_id = sorRepo.getSorId(sor_name);
			LOGGER.info("Time taken for sorId repo call : " + 
					(Long.valueOf(System.currentTimeMillis()) - initMillis) / 1000.0 + "secs");
			if(temp_sor_id != null)
				sor_id_str = String.valueOf(temp_sor_id);
			LOGGER.debug( "{}{}MR_04 : Got sor_id from SystemOfRecordRepository= {}",sClassName,sMethodName, sor_id_str);

			if (access_id_str == null) {
				Long initNetWorkMillis = Long.valueOf(System.currentTimeMillis());
				int temp_access_id = networkAccessRepo.getAccessId(access_name);
				LOGGER.debug("Time taken for network repo call : " + 
						(Long.valueOf(System.currentTimeMillis()) - initNetWorkMillis) / 1000.0 + "secs");
				access_id_str = String.valueOf(temp_access_id);
				LOGGER.debug("{}{}MR_05 : Got access_id from NetWorkAccessServiceRepository = {}",sClassName,sMethodName, access_id_str);
			}

			if (domain_id_str != null) {
				domain_id = Long.valueOf(domain_id_str);
			} else {
				String domain_name = (String) InpParam.get(MPSDefs.DB_DOMAIN_NAME);
				domain_id = domainRepo.getDomainId(domain_name.toLowerCase());
			}

			if (group_num_str != null) {
				group_num = Long.parseLong(group_num_str);
			}
			if (slid_member_num_str != null) {
				slid_member_num = Long.parseLong(slid_member_num_str);
			}

			if (sor_id_str != null) {
				sor_id = Integer.parseInt(sor_id_str);
			}
			if (access_id_str != null) {
				access_id = Integer.parseInt(access_id_str);
			}

			if (security_question_id_1_str != null) {
				security_question_id_1 = Long.valueOf(security_question_id_1_str);
			}
			if (security_question_id_2_str != null) {
				security_question_id_2 = Long.valueOf(security_question_id_2_str);
			}
			if (security_question_id_str != null) {
				security_question_id = Long.valueOf(security_question_id_str);
			}

			if (security_question_id < 0) {
				if (security_question != null) {
					security_question_id = getSecurityQuestionId(security_question);

					LOGGER.debug("{}{}MR_06 : Got security_question_id from SecurityQuestionRepository = {}",
							sClassName,sMethodName, security_question_id);

					if (security_question_id < 0) {
						String sAppInfo = "Cannot find security_question_id for the given security_question="
								+ security_question;
						status = StatusMsg.makeSQLStatus(MPSDefs.ERR_INVALID_DATA, MPSDefs.ERR_INVALID_DATA_MSG,
								MPSDefs.ERR_INVALID_DATA, sAppInfo, MPSDefs.NO_ROW_UPDATED);
						LOGGER.info("{}{}MR_07 : {}",sClassName,sMethodName, HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
						return status;
					}
				}
			}

			if (security_question_id_1 < 0) {
				if (security_question_1 != null) {
					security_question_id_1 = getSecurityQuestionId1(security_question_1);

					LOGGER.debug("{}{}MR_08 : Got security_question_id_1 from SecurityQuestionRepository = {}",sClassName,sMethodName, security_question_id_1);

					if (security_question_id_1 < 0) {
						String sAppInfo = "Cannot find security_question_id for the given security_question="
								+ security_question_1;
						status = StatusMsg.makeSQLStatus(MPSDefs.ERR_INVALID_DATA, MPSDefs.ERR_INVALID_DATA_MSG,
								MPSDefs.ERR_INVALID_DATA, sAppInfo, MPSDefs.NO_ROW_UPDATED);
						LOGGER.info("{}{}MR_09 : {}",sClassName,sMethodName, HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
						return status;
					}
				}
			}
			if (security_question_id_2 < 0) {
				if (security_question_2 != null) {
					security_question_id_2 = getSecurityQuestionId2(security_question_2);

					LOGGER.debug("{}{}MR_10 : Got security_question_id_2 from SecurityQuestionRepository = {}",sClassName,
							sMethodName, security_question_id_2);

					if (security_question_id_2 < 0) {
						String sAppInfo = "Cannot find security_question_id for the given security_question="
								+ security_question_2;
						status = StatusMsg.makeSQLStatus(MPSDefs.ERR_INVALID_DATA, MPSDefs.ERR_INVALID_DATA_MSG,
								MPSDefs.ERR_INVALID_DATA, sAppInfo, MPSDefs.NO_ROW_UPDATED);
						LOGGER.info("{}{}MR_11 : {}", sClassName,sMethodName,HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
						return status;
					}
				}
			}

		} catch (NumberFormatException e) {
			status = StatusMsg.makeSQLStatus(MPSDefs.ERR_OUT_OF_RANGE, MPSDefs.ERR_OUT_OF_RANGE_MSG, MPSDefs.SQL_ERR,
					MPSDefs.SQL_ERR_MSG, MPSDefs.NO_ROW_UPDATED);

			LOGGER.error("{}{}MR_12 Error: {}",sClassName,sMethodName, e.getMessage());

			return status;
		} catch (Exception e) {
			status = StatusMsg.makeExceptionSQLStatus(e);
			LOGGER.error("{}{}MR_13 Error: {}",sClassName,sMethodName, e.getMessage());
			return status;
		}

		int rowCount = 0;
		
		
		Session hibSession = getSession();

		if (lExternalGuid == 0) {
			memberNumber = Long.valueOf(hibSession.createNativeQuery("SELECT MPS_OWNER.MEMBER_NUM_SEQ.nextval FROM dual")
					.getSingleResult().toString());
		} else {
			memberNumber = lExternalGuid;
		}
		
		try {
			String sql = "insert into MPS_OWNER.TMEMBER (MEMBER_NUM, MEMBER_NAME, DOMAIN_ID, GROUP_NUM, SOR_ID, ACCOUNT_TYPE, ENC_PASSWORD, MD5_PASSWORD, "
					+ "PARENT_CHILD_IND, ACCESS_ID, MEMBER_STATE, "
					+ "MAILHOST, FULLNAME, MIGRATION_IND, MIGRATION_DATE, CREATE_DATE, LAST_MODIFIED_BY, "
					+ "BAN, DELETE_REQUEST_DATE, TOKEN, CONTACT_EMAIL, CONTACT_EMAIL_VALID, PASSWORD_DIRTY, "
					+ "SHA1_PASSWORD, CREDIT_CHECKED_IND, YREG_COMPLETE_IND, LOCKOUT_TIMESTAMP, FIRSTNAME, LASTNAME, NICKNAME, "
					+ "GENDER, PROOFING_ZIP, LAST_FOUR_SSN, SECURITY_QUESTION_ID, "
					+ "SECURITY_QUESTION_ID_1, SECURITY_ANSWER_1, SECURITY_QUESTION_ID_2, SECURITY_ANSWER_2, "
					+ "CONTACT_EMAIL_EST_DATE, PREVIOUS_CONTACT_EMAIL, DES3_PASSWORD, LANGUAGE, "
					+ "BROWSER_LANGUAGE, "
					+ "DSL_NET_PASSWORD, DSL_NET_PW_ENCR_TYPE, "
					+ "CONTACT_EMAIL_STATUS, SSHA_PASSWORD, SLID_MEMBER_NUM, AUTOGENERATED_IND, "
					+ "ACTIVATED_IND, BIRTHDATE_VENC, PASSCODE_VENC, SECURITY_ANSWER_VENC, "
					+ "ONL_QA_EST_DATE, "
					+ "ACCESSID_RTV_DATE, CONTACT_EMAIL_RTV_DATE, FN_LINKED_USERID, FN_LINKED_STATUS, CBR_NUMBER, CONTACT_ADDRESS, CBR_RTV_DATE) "
					+ "values (:memberNumber,:memberName,:domainId,:groupNum,:sorId,"
					+ ":accountType,:encPassword,:md5Password,:parentChildInd,:accessId,:memberState,"
					+ ":mailHost,:fullName,:migrationInd,:migrationDate,"
					+ "sysdate,:lastModifiedBy,:ban,:deleteRequestDate,"
					+ ":token,:contactEmail,:contactEmailValid,:passwordDirty,:sha1Password,:creditCheckedInd,"
					+ ":yregCompleteInd,:lockOutTimeStamp,:firstName,:lastName,:nickName,:gender,:proofingZip,"
					+ ":last4ssn,:securityQuestionId,:securityQuestionId1,:securityAnswer1,"
					+ ":securityQuestionId2,:securityAnswer2,sysdate,:previousContactEmail,:des3Password,"
					+ ":language,:browserLanguage,"
					+ ":dslNetPassword,:dslNetPwEncrType,:contactEmailStatus,"
					+ ":sshaPassword,:slidMemberNum,:autogeneratedInd,:activatedInd,:birthDateVenc,"
					+ ":passwordVenc,:securityAnsVenc,"
					+ "sysdate,sysdate,"
					+ "sysdate,:fnlinkedUserId,:fnLinkedStatus,"
					+ ":cbrNumber,:contactAddress,:cbrRtvDate)";


			if (contact_email != null && contact_email_valid != null) {
				if (contact_email_valid.equals(MPSDefs.YES)) {
					
					contact_email_valid = MPSDefs.DB_CONTACT_STATUS_VALID;
					
					LOGGER.debug("{}{}MR_14: contact_email_status::PARAM 21 = {}",
							sClassName,sMethodName, MPSDefs.DB_CONTACT_STATUS_VALID);
				} else if (contact_email_valid.equals(MPSDefs.NO)) {
					contact_email_valid = MPSDefs.DB_CONTACT_STATUS_HARD;
					
					LOGGER.debug("{}{}MR_15 : contact_email_status::PARAM 21 = {}"
							,sClassName,sMethodName,MPSDefs.DB_CONTACT_STATUS_HARD);
				}
			}

			if (parent_child_ind != null && parent_child_ind.equals("S")) {
				slid_member_num = memberNumber;
				LOGGER.debug("{}{}MR_16 : slid_member_num::PARAM 43 = {}",sClassName,sMethodName, slid_member_num);
			} else if (parent_child_ind != null && slid_member_num_str != null) {
				LOGGER.debug("{}{}MR_17 : slid_member_num::PARAM 43 = {}",sClassName,sMethodName, slid_member_num);
			} else {
				slid_member_num = null;
				LOGGER.debug("{}{}MR_18 : slid_member_num::PARAM 43 = {}",sClassName,sMethodName,slid_member_num);

			}
			
			if(proofing_zip != null){				
				proofing_zip = CommonUtil.removeNonNumericChars(proofing_zip);
			}
			
			rowCount = hibSession.createNativeQuery(sql)
					.setParameter("memberNumber", memberNumber)
					.setParameter("memberName", member_name.toLowerCase()).setParameter("domainId", domain_id)
					.setParameter("groupNum", group_num)
					.setParameter("sorId", sor_id)
					.setParameter("accountType", (account_type != null ? account_type : ""))
					.setParameter("encPassword", (StringUtils.isNotEmpty(enc_password) ? enc_password : ""))
					.setParameter("md5Password", (StringUtils.isNotEmpty(md5_password) ? md5_password : ""))
					.setParameter("parentChildInd", (StringUtils.isNotBlank(parent_child_ind) ? parent_child_ind : ""))
					.setParameter("accessId", access_id).setParameter("memberState", "RES")
					.setParameter("mailHost", mailhost)
					.setParameter("fullName", (StringUtils.isNotEmpty(fullname) ? fullname : ""))
					.setParameter("migrationInd", (migration_ind != null ? migration_ind : ""))
					.setParameter("migrationDate", (migrationSQLDate != null ? migrationSQLDate : ""))
					.setParameter("lastModifiedBy", (StringUtils.isNotEmpty(last_modified_by) ? last_modified_by : ""))
					.setParameter("ban", (StringUtils.isNotEmpty(ban) ? ban : ""))
					.setParameter("deleteRequestDate", (delete_request_date != null ? DateUtil.stringToSqlDate(delete_request_date) : ""))
					.setParameter("token", (StringUtils.isNotBlank(token) ? token : ""))
					.setParameter("contactEmail", (StringUtils.isNotBlank(contact_email) ? contact_email.toLowerCase() : ""))
					.setParameter("contactEmailStatus", (contact_email_valid != null ? contact_email_valid : ""))
					.setParameter("passwordDirty", (StringUtils.isNotBlank(password_dirty) ? password_dirty : ""))
					.setParameter("sha1Password", (StringUtils.isNotBlank(sha1_password) ? sha1_password : ""))
					.setParameter("creditCheckedInd", (credit_checked_ind != null ? credit_checked_ind : ""))
					.setParameter("yregCompleteInd", (yreg_complete_ind != null ? yreg_complete_ind : ""))
					.setParameter("lockOutTimeStamp", (lockout_timestamp != null ? DateUtil.stringToSqlDate(lockout_timestamp) : ""))
					.setParameter("firstName", (StringUtils.isNotBlank(firstname) ? firstname : ""))
					.setParameter("lastName", (StringUtils.isNotBlank(lastname) ? lastname : ""))
					.setParameter("nickName", (StringUtils.isNotBlank(nickname) ? nickname : ""))
					.setParameter("gender", (gender != null ? gender : "")).setParameter("proofingZip", proofing_zip)
					.setParameter("last4ssn", (last_four_ssn != null ? last_four_ssn : ""))
					.setParameter("securityQuestionId",  security_question_id != -1 ? security_question_id : null)
					.setParameter("securityQuestionId1",  security_question_id_1 != -1 ? security_question_id_1 : null)
					.setParameter("securityAnswer1", (StringUtils.isNotBlank(security_answer_1) ? security_answer_1 : ""))
					.setParameter("securityQuestionId2", security_question_id_2 != -1 ? security_question_id_2 : null)
					.setParameter("securityAnswer2", (StringUtils.isNotBlank(security_answer_2) ? security_answer_2 : ""))
					.setParameter("previousContactEmail", (previous_contact_email != null ? previous_contact_email.toLowerCase() : ""))
					.setParameter("des3Password", (StringUtils.isNotEmpty(des3_password) ? des3_password : ""))
					.setParameter("language", (StringUtils.isNotEmpty(language) ? language : ""))
					.setParameter("browserLanguage", (StringUtils.isNotBlank(browser_language) ? browser_language : ""))
					.setParameter("dslNetPassword", (StringUtils.isNotBlank(dsl_net_password) ? dsl_net_password : ""))
					.setParameter("dslNetPwEncrType", (dsl_net_pw_encr_type != null ? dsl_net_pw_encr_type : ""))
					.setParameter("contactEmailValid", "")
					.setParameter("sshaPassword", (ssha_password != null ? ssha_password : ""))
					.setParameter("slidMemberNum", (slid_member_num != null && slid_member_num !=-1 ? slid_member_num : ""))
					.setParameter("autogeneratedInd", (autogenerated_ind != null ? autogenerated_ind : ""))
					.setParameter("activatedInd", (activated_ind != null ? activated_ind : ""))
					.setParameter("birthDateVenc", (StringUtils.isNotBlank(birthdate_venc) ? birthdate_venc : ""))
					.setParameter("passwordVenc", (StringUtils.isNotBlank(passcode_venc) ? passcode_venc : ""))
					.setParameter("securityAnsVenc", (StringUtils.isNotBlank(security_answer_venc) ? security_answer_venc : ""))
					.setParameter("fnlinkedUserId", (StringUtils.isNotBlank(fn_linked_userId) ? fn_linked_userId : ""))
					.setParameter("fnLinkedStatus", (StringUtils.isNotBlank(fn_linked_status) ? fn_linked_status : ""))
					.setParameter("cbrNumber", (StringUtils.isNotBlank(cbr_number) ? cbr_number : ""))
					.setParameter("contactAddress", (StringUtils.isNotBlank(contact_address) ? contact_address : ""))
					.setParameter("cbrRtvDate", (StringUtils.isNotBlank(cbr_rt_valid_date) ? DateUtil.stringToSqlDate(cbr_rt_valid_date) : null))
					.executeUpdate();

			LOGGER.info("{}{}MR_21 : member table row inserted = {}",sClassName,sMethodName, rowCount);

			String md5_password_venc = (String) InpParam.get("md5_password_venc");
			if (md5_password_venc != null && !md5_password_venc.trim().isEmpty()) {
				InpParam.put(MPSDefs.DB_MEMBER_NUM, memberNumber);
				Long initMillis = Long.valueOf(System.currentTimeMillis());
				status = addMemberAux(InpParam);
				LOGGER.debug("Time taken for addMemberAux repo call : " + 
						(Long.valueOf(System.currentTimeMillis()) - initMillis) / 1000.0 + "secs");

				if (status == null || status.isEmpty()) {
					stAppInfo = "status HashMap from addMemberAux() is null";
					status = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					LOGGER.error("{}{}MR_22 : {}",sClassName,sMethodName, stAppInfo);
				}

				appStatusCode = (String) status.get(CommonDefs.COMMON_APP_STATUS_CODE);

				if (appStatusCode != null && !appStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
					stAppInfo = (String) status.get(CommonDefs.COMMON_APP_INFO);
					status = CommonErrorMap.makeCategoryMap(Integer.parseInt(appStatusCode), stAppInfo);
					LOGGER.info("{}{}MR_23 : {}",sClassName,sMethodName, stAppInfo);
					return status;
				}
			}
			status = StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS, MPSDefs.MPS_ALL_OK, MPSDefs.SQL_SUCCESS,
											 MPSDefs.SQL_SUCCESS_MSG, Integer.toString(rowCount));
			
			status.put(MPSDefs.DB_MEMBER_NUM,memberNumber.toString());
			status.put(MPSDefs.DB_DOMAIN_ID, Long.valueOf(domain_id));
		} catch (Exception e) {
			if (e.getMessage().contains("ORA-00001: unique constraint")) {
				status = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USERNAME_EXISTS_NUM,
						MPSDefs.ERR_USERNAME_EXISTS_MSG);
				LOGGER.info("{}{}MR_24 :  resultHash :: {}",sClassName,sMethodName,status);
			} else {
				status = StatusMsg.makeExceptionSQLStatus(e);
				LOGGER.error("{}{}MR_25 : Error::{}",sClassName,sMethodName, e.getMessage());
				LOGGER.error("{}{}MR_26 : Exception = {}", sClassName,sMethodName,e);
			}

		} finally {
			LOGGER.info("{}{}DBTOOLS999 : status : {}",sClassName,sMethodName, status);
		}

		return status;
	}
	@Override
	public HashMap addMemberAux(HashMap hmInput) throws SQLException {
		String sMethodName = ".addMemberAux.";
		String sAppInfo = null;
		long member_num = 0;

		//LOGGER.debug("{}{}MR_21.1 InputParams = {}",sClassName,sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmInput)));

		HashMap status = null;
		int rowCount = 0;

		if (hmInput == null || hmInput.isEmpty()) {
			sAppInfo = "hmInput is null or empty";
			LOGGER.error("{}{}MA_02 : {}",sClassName,sMethodName, sAppInfo);
			status = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
			return status;
		}

		String member_num_str = hmInput.get(MPSDefs.DB_MEMBER_NUM).toString();
		String enc_password_venc = (String) hmInput.get("enc_password_venc");
		String sha1_password_venc = (String) hmInput.get("sha1_password_venc");
		String generic_password_venc = (String) hmInput.get("gen_password_venc");
		String generic_password_type = (String) hmInput.get("gen_password_type");

		String md5_password_venc = (String) hmInput.get("md5_password_venc");
		String des3_password_venc = (String) hmInput.get("des3_password_venc");
		String ssha_password_venc = (String) hmInput.get("ssha_password_venc");
		String security_answer_1_venc = (String) hmInput.get("security_answer_1_venc");
		String security_answer_2_venc = (String) hmInput.get("security_answer_2_venc");
		String last_modified_by = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);

		try {
			MemberRequest memberRequest = new MemberRequest();
			MemberAuxRequest memAuxRequest = new MemberAuxRequest();

			if(member_num_str != null){
			    memberRequest.setMemberNum(Long.valueOf(member_num_str));
			}
			memAuxRequest.setEncPasswordVenc(enc_password_venc);
			memAuxRequest.setMd5PasswordVenc(md5_password_venc);
			memAuxRequest.setSha1PasswordVenc(sha1_password_venc);
			memAuxRequest.setDes3PasswordVenc(des3_password_venc);
			memAuxRequest.setSshaPasswordVenc(ssha_password_venc);
			memAuxRequest.setSecurityAnswer1Venc(security_answer_1_venc);
			memAuxRequest.setSecurityAnswer2Venc(security_answer_2_venc);
			memAuxRequest.setLastModifiedBy(last_modified_by);
			memAuxRequest.setPasswordVenc(generic_password_venc);
			memAuxRequest.setPasswordType(generic_password_type);
			memberRequest.setMemberAux(memAuxRequest);

			Long initMillis = Long.valueOf(System.currentTimeMillis());
			rowCount = memberAuxRepo.addMemberAux(memberRequest);
			
			LOGGER.info("Time taken to insert into TMEMBERAUX table : "+
					(Long.valueOf(System.currentTimeMillis()) - initMillis) / 1000.0 + "secs");
			LOGGER.info("{}{}MA_03 : Number of records inserted to MEMBER_AUX table  : {}",sClassName,sMethodName,rowCount);

			status = StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS, MPSDefs.MPS_ALL_OK, MPSDefs.SQL_SUCCESS,
					MPSDefs.SQL_SUCCESS_MSG, Integer.toString(rowCount));

		} catch (Exception e) {
			status = CommonErrorMap.makeExceptionMap(e, LOGGER);
		} finally {
			LOGGER.info("{}{}DBTOOLS999 : status : {}",sClassName,sMethodName, status);
		}
		return status;
	}

	private Long getSecurityQuestionId2(String security_question_2) throws SQLException {
            String sMethodName=".getSecurityQuestionId2.";
			String securityQuestion2 = "";
			Long securityQuestionId2 = -1L;

			if (security_question_2 != null) {
				if (security_question_2.length() > 80) {
					securityQuestion2 = security_question_2.substring(0, 80);
				} else {
					securityQuestion2 = security_question_2;
				}
			} 

			List<Tsecurityquestion> securityQuestionList = secQuestionRepo.getSecurityQuestionId(securityQuestion2);
			if (!securityQuestionList.isEmpty() && securityQuestionList.stream().findFirst().isPresent()) {
				Tsecurityquestion securityquestion2 = securityQuestionList.stream().findFirst().get();
				securityQuestionId2 = securityquestion2.getSecurityQuestionId();
				if (securityQuestionId2 <0) {
					String sAppInfo = "Cannot find security_question_id for the given security_question=" + securityQuestion2;
					LOGGER.info("{}{}MR_09.1 : {}",sClassName,sMethodName, HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
				}
				
				LOGGER.debug("{}{}MR_09.2 : Security Question Id2 : {}",sClassName,sMethodName, securityquestion2.getSecurityQuestionId());
			}
		return securityQuestionId2;
	}

	private Long getSecurityQuestionId1(String security_question_1) throws SQLException {
		    String sMethodName=".getSecurityQuestionId1.";
			String securityQuestion1 = "";
			Long securityQuestionId1 = -1L;
			
			if (security_question_1 != null) {
				if (security_question_1.length() > 80) {
					securityQuestion1 = security_question_1.substring(0, 80);
				} else {
					securityQuestion1 = security_question_1;
				}
			} 

			List<Tsecurityquestion> securityQuestionList = secQuestionRepo.getSecurityQuestionId(securityQuestion1);
			if (!securityQuestionList.isEmpty() && securityQuestionList.stream().findFirst().isPresent()) {
				Tsecurityquestion securityquestion1 = securityQuestionList.stream().findFirst().get();
				securityQuestionId1 = securityquestion1.getSecurityQuestionId();
				if (securityQuestionId1 < 0) {
					String sAppInfo = "Cannot find security_question_id for the given security_question=" + securityQuestion1;
					LOGGER.info("{}{}MR_07.1 : {}",sClassName,sMethodName, HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
				}
				
				LOGGER.debug("{}{}MR_07.2 Security Question Id1 : {}",sClassName,sMethodName, securityquestion1.getSecurityQuestionId());
			}
		return securityQuestionId1;
	}

	private Long getSecurityQuestionId(String security_question) throws SQLException {
		String sMethodName=".getSecurityQuestionId.";
		String securityQuestion = "";
		Long securityQuestionId = -1L;
		if (security_question != null) {
			if (security_question.length() > 80) {
				securityQuestion = security_question.substring(0, 80);
			} else {
				securityQuestion = security_question;
			}
		}

		List<Tsecurityquestion> securityQuestionList = secQuestionRepo.getSecurityQuestionId(securityQuestion);
		if (!securityQuestionList.isEmpty() && securityQuestionList.stream().findFirst().isPresent()) {
			Tsecurityquestion securityquestion = securityQuestionList.stream().findFirst().get();
			LOGGER.debug("{}{}MR_07.1a : Security Question Id : {}",sClassName,sMethodName, securityquestion.getSecurityQuestionId());
			securityQuestionId = securityquestion.getSecurityQuestionId();

			if (securityQuestionId < 0) {
				String sAppInfo = "Cannot find security_question_id for the given security_question=" + securityQuestion;
				LOGGER.info("{}{}MR_07.1b : {}",sClassName,sMethodName, HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));
			}
		}
		return securityQuestionId;
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public HashMap<String, Object> checkUserList(HashMap<String, Object> hmInput) {
		
		String sMethodName = ".checkUserList.";
        java.util.Date dtStart = new java.util.Date();
        HashMap<String, Object> response = null;
        String sAppInfo = null;

        int domainCount = 0;
        HashMap<String, Object> domainHash = new HashMap<String, Object>();

        LOGGER.info("{}{}MR_CUL_01 : Input param :: {}",sClassName,sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmInput)));
        
        int usercount = Integer.parseInt((String) hmInput.get(CommonDefs.USER_COUNT));
        String domainName = (String) hmInput.get(MPSDefs.WS_DOMAIN);
        
        StringBuilder query = new StringBuilder();
		
		List<String> memberNameList = new ArrayList<>();
		List<String> domainNameList = new ArrayList<>();
		
		int i = 0;
        
        try {
        	
        	String domainSplitCheck = PropertyManager.getProperty(CommonDefs.MOUPConfig, MPSDefs.PROP_HRS_DOMAIN_SPLIT_CHECK);
	        LOGGER.debug("{}{}MR_CUL_02 checkuserlistworkerhelper::domain split check = {}",sClassName,sMethodName, domainSplitCheck);
	        if (domainSplitCheck.equals(MPSDefs.YES)) {
	            String modifiedDomain = "HRS_DOMAIN_SPLIT_"
	                    + domainName.replace('.', '_').toUpperCase();
	            String domainPair = PropertyManager.getProperty(CommonDefs.MOUPConfig, modifiedDomain);
	            if (domainPair != null && domainPair.length() != 0) {
	                StringTokenizer st = new StringTokenizer(domainPair, "|");
	                while (st.hasMoreTokens()) {
	                    domainCount++;
	                    domainHash.put("domain-" + domainCount, st.nextToken());
	                }
	            } else {
	                domainCount = 1;
	                domainHash.put("domain-1", domainName);
	            }
	            String stSlidCheckRequired = (String) hmInput.get("searchSLIDNamespace");
	            if (stSlidCheckRequired != null
	                    && stSlidCheckRequired.equalsIgnoreCase(MPSDefs.YES)) {
	                domainCount++;
	                domainHash.put("domain-" + domainCount, "slid.dum");
	            }
	        } else {
	            domainCount = 1;
	            domainHash.put("domain-1", domainName);
	        }
	        
	        query.append("select member.member_name, member.fn_linked_status from MPS_OWNER.TMEMBER member , MPS_OWNER.TDOMAIN domain where member.member_name IN(:memberName)");
	        
	        if(domainCount == 1) {
	        	query.append(" and member.domain_id = domain.domain_id AND domain.domain_name = :domainName");
	        } else {
	        	query.append(" and member.domain_id = domain.domain_id AND domain.domain_name IN (:domainName)");
	        }
	        
	        LOGGER.debug("{}{}MR_CUL_03 : checkuserlistworkerhelper::SQL ={}",sClassName,sMethodName, query);
	        
	        LOGGER.debug("{}{}MR_CUL_04 : checkuserlistworkerhelper::dom.domain_name= {}",sClassName,sMethodName, HtmlUtils.htmlEscape(String.valueOf(domainName)));
	        
	        for (i = 0; i < usercount; i++) {
                String key = MPSDefs.WS_USER_ID + "-" + (i + 1);
                String uname = (String) hmInput.get(key);
                if (uname == null)
                {
                	LOGGER.error("{}{}MR_CUL_05 : No username in hashmap for number: {}",sClassName,sMethodName, (i + 1));
                    sAppInfo = "No username in hashmap for number : " + (i + 1);
                    return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, sAppInfo);
                }
                String luname = uname.toLowerCase();
                LOGGER.debug("{}{}MR_CUL_06 username #{} = {}",sClassName,sMethodName, (i + 1), HtmlUtils.htmlEscape(String.valueOf(luname)));
                memberNameList.add(luname);
            }
	        
	        for (int j = 0; j < domainCount; j++) {
                String key = "domain-" + (j + 1);
                String domain = (String) domainHash.get(key);
                if (domain == null) 
                {
                	LOGGER.error("{}{}MR_CUL_07 No domain in hashmap for number: {}",sClassName,sMethodName, (j + 1));
                    sAppInfo = "No domain in hashmap for number: " + (j + 1);
                    return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, sAppInfo);
                }
                String ldomain = domain.toLowerCase();
                
                LOGGER.debug("{}{}MR_CUL_08 domain #{} = {}",sClassName,sMethodName, (j + 1 + i) , HtmlUtils.htmlEscape(String.valueOf(ldomain)));
                domainNameList.add(ldomain); 
            }
	        
	        response = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
                    								  CErrorDefs.COMMON_SUCCESS_MSG);
	        for (i = 0; i < usercount; i++) {
                String key = MPSDefs.WS_USER_ID + "-" + (i + 1); 
                String uname = (String) hmInput.get(key);
                String luname = uname.toLowerCase();
                String respkey = MPSDefs.TXT_USERNAME + luname;
                response.put(respkey, MPSDefs.TXT_NOTFOUND);
            }
            
            int countFoundHandlesInDB = 0;
            
            List<Object[]> alQueryResponse =  getSession().createNativeQuery(query.toString())
					 							.setParameterList("memberName", memberNameList)
					 							.setParameterList("domainName", domainNameList)
					 							.list();
            
            for(int j=0; j<alQueryResponse.size(); j++){
            	Object[] oQueryResponse = alQueryResponse.get(j);
                String dbname = (String)oQueryResponse[0]; // first column
                String key = MPSDefs.TXT_USERNAME + dbname; 
                String stFnUserID = (String)oQueryResponse[1]; // fn linked status column, as only two columns fetched from db
                if (response.containsKey(key) == false) 
                { 
                	LOGGER.error("{}{}MR_CUL_09 No notfound in hashmap for : {}",sClassName,sMethodName, key);
                    sAppInfo = "Notfound in hashmap for : " + key;
                    return CommonErrorMap.makeCategoryMap(
                            CErrorDefs.ERR_EMPTY_NUM, sAppInfo);
                }
                response.remove(key);
                response.put(key, MPSDefs.TXT_FOUND); // tell them we did find
                                                      // this one (or more)
               if(StringUtils.isNotBlank(stFnUserID))
            	   response.put(CommonDefs.LINKED_FN_USER_STATUS, stFnUserID);

                countFoundHandlesInDB++;
            }
            LOGGER.debug("{}{}MR_CUL_10 Count of member_names found in DB: {}",sClassName,sMethodName, countFoundHandlesInDB);
        } catch (Exception e) {
        	response = CommonErrorMap.makeExceptionMap(e, LOGGER);
            LOGGER.error("{}{}MR_CUL_11 :: checkUserListWorkerHelper : Error: {}",sClassName,sMethodName, response);
            
            response = CommonErrorMap.makeCategoryMap(
                    CErrorDefs.ERR_SYS_APPL_NUM, MPSDefs.ERR_SYS_APPL_MSG);
            response.put(MPSDefs.SQLCODE, MPSDefs.SQL_ERR);
            response.put(MPSDefs.SQLMSG, MPSDefs.SQL_ERR_MSG);
        } finally {
        			LOGGER.info("{}{}MR_CUL_12 : checkUserListWorkerHelper : {} : {}",sClassName,sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(dtStart.getTime())),
					 HtmlUtils.htmlEscape(String.valueOf(response)));
        }
        return response;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public HashMap<String, Object> getAssociatedAccessIDs(HashMap<String, Object> hmInput) {

		String sMethodName = ".getAssociatedAccessIDs.";

		HashMap<String, Object> response = null;

		String sAppInfo = null;

		LOGGER.info("{}{}DBTOOLS000 : Inputhash: {}",sClassName,sMethodName,hmInput);

		if (hmInput == null || hmInput.isEmpty()) {
			response = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_SYS_APPL_NUM, "Input is null or empty.");
			LOGGER.error("{}{}MR_IAA_01 : " + "Input is null or empty.");
			return response;
		}

		String sTitanSorInvariantId = (String) hmInput.get(CommonDefs.TITAN_SORINVARIANTID);
		String sMobilitySorInvariantId = (String) hmInput.get(CommonDefs.MOBILITY_SORINVARIANTID);
		String sDirectvnowSorInvariantId = (String) hmInput.get(CommonDefs.DIRECTVNOW_SORINVARIANTID);
		String sEcommSorInvariantId = (String) hmInput.get("ECOMMSorInvariantId");
		String sWatchTVSorInvariantId = (String) hmInput.get("WATCHTVSorInvariantId");
		String sIndividualSorInvariantId = (String) hmInput.get("INDIVIDUALSorInvariantId");
		String sContactEmail = (String) hmInput.get("contactEmail");
		String sDmctn = (String) hmInput.get("dmctn");

		try {
			StringBuilder query = new StringBuilder();

			boolean isVaidDomain = false;
			String tempHandle = null;
			String tempDomain = null;

			int rowCount = 0;
			ArrayList alMemberNames = new ArrayList();
			ArrayList alAssociatedUsers = new ArrayList();
			HashMap<String,Object> hmUser = null;
			
			List<Object[]> alQueryResponse =  null;

			if (StringUtils.isNotBlank(sTitanSorInvariantId)) {
				query.append(queryGetTitanAccount);
			}

			if (StringUtils.isNotBlank(sMobilitySorInvariantId)) {
				if (query.length() > 0) {
					query.append(" UNION " + queryGetStandaloneMobility + " UNION " + queryGetTitanizedMobility);
				} else {
					query.append(queryGetStandaloneMobility + " UNION " + queryGetTitanizedMobility);
				}
			}

			if (StringUtils.isNotBlank(sDirectvnowSorInvariantId)) {
				if (query.length() > 0) {
					query.append(" UNION " + queryGetDirectvNow);
				} else {
					query.append(queryGetDirectvNow);
				}
			}

			if (StringUtils.isNotBlank(sContactEmail)) {
				if (query.length() > 0) {
					query.append(" UNION " + queryMemberName);
				} else {
					query.append(queryMemberName);
				}
			}
			 
			if (StringUtils.isNotBlank(sDmctn)) {
				if (query.length() > 0) {
					query.append( " UNION " + queryDmctn);
				} else {
					query.append(queryDmctn);
				}
			}
			
			if (StringUtils.isNotBlank(sContactEmail)) {
				if (query.length() > 0) {
					query.append(" UNION " + queryContactEmail);
				} else {
					query.append(queryContactEmail);
				}
			}
			
			if (StringUtils.isNotBlank(sEcommSorInvariantId)) {
				if (query.length() > 0) {
					query.append(" UNION " + queryGetEcommAccount);
				} else {
					query.append(queryGetEcommAccount);
				}
			}

			if (StringUtils.isNotBlank(sContactEmail)) {
				int lastIndex = sContactEmail.lastIndexOf('@');

				tempHandle = sContactEmail.substring(0, lastIndex);
				tempDomain = sContactEmail.substring(lastIndex + 1, sContactEmail.length());

				ArrayList alDBDomainList = (ArrayList) CommonUtil.parseToArray(propDBDomainList,
						CommonDefs.VALUE_SEPARATOR_CHAR);

				LOGGER.info("{}{}MR_IAA_02 : Valid domains = {}" ,sClassName,sMethodName,alDBDomainList);

				if (alDBDomainList == null || alDBDomainList.isEmpty()) {
					sAppInfo = "Domain List not loaded in Cache.DomainValidation return null Hashmap";
					LOGGER.error("{}{}MR_IAA_03 : {}",sClassName,sMethodName, sAppInfo);
					return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				}

				if (alDBDomainList.contains(tempDomain.trim().toLowerCase())) {
					isVaidDomain = true;

					if (query.length() > 0) {
						query.append(" UNION " + queryContactEmailMID);
					} else {
						query.append(queryContactEmailMID);
					}
				}
			}

			if (StringUtils.isNotBlank(sWatchTVSorInvariantId)) {
				if (query.length() > 0) {
					query.append(" UNION " + queryGetWatchTV);
				} else {
					query.append(queryGetWatchTV);
				}
			}

			if (StringUtils.isNotBlank(sIndividualSorInvariantId)) {
				if (query.length() > 0) {
					query.append(" UNION " + queryGetIndividual);
				} else {
					query.append(queryGetIndividual);
				}
			}

			String sFinalQuery = "SELECT mf.member_num, mf.member_name, mf.contact_email, "
					+ "mf.search_entity, mf.entity_identifier, ms.instance_id as dmctn, mf.role_name, "
					+ "mf.rank, NVL(m1.activated_ind, 'Y') activated_ind, NVL(m1.autogenerated_ind, 'N') "
					+ "autogenerated_ind, f.user_lock_level, NVL(m1.password_dirty, 'N') "
					+ "password_dirty ,m1.fn_linked_userid, m1.fn_linked_status FROM ( " + query.toString()
					+ " ) mf, memberservice ms, member m1, userfraudlock f " + " WHERE rownum < 50 "
					+ " AND NOT EXISTS (SELECT 1 FROM memberservice msd WHERE mf.member_num = msd.member_num "
					+ "AND msd.service_id in (38,39,45)) " + " AND ms.member_num(+) = mf.member_num "
					+ " AND ms.service_id(+) = 23 " + " AND mf.member_num = m1.member_num "
					+ " AND f.member_num(+) = mf.member_num " + " ORDER BY rank, role_name desc ";

			LOGGER.debug("{}{}MR_IAA_04 : Query SQL = {}",sClassName,sMethodName, sFinalQuery);

			Query q = getSession().createNativeQuery(sFinalQuery);
			 
			Long initMillis = Long.valueOf(System.currentTimeMillis());

			if(StringUtils.isNotBlank(sTitanSorInvariantId)) {
				q.setParameter("titanSorInvariantId", sTitanSorInvariantId);
			}
			if(StringUtils.isNotBlank(sMobilitySorInvariantId)) {
				q.setParameter("mobilitySorInvariantId",sMobilitySorInvariantId);
			}
			if(StringUtils.isNotBlank(sDirectvnowSorInvariantId)) {
				q.setParameter("dtvSorInvariantId", sDirectvnowSorInvariantId);
			}
			if(StringUtils.isNotBlank(sDmctn)) {
				q.setParameter("dmCTN", sDmctn);
			}
			if(StringUtils.isNotBlank(sContactEmail)) {
				q.setParameter("contactEmail", sContactEmail);
			}
			if (sContactEmail != null && !sContactEmail.isEmpty() && isVaidDomain){
				q.setParameter("memberName", tempHandle);
				q.setParameter("domainName", tempDomain);
			}
			if(StringUtils.isNotBlank(sEcommSorInvariantId)) {
				q.setParameter("ecommSorInvariantId", sEcommSorInvariantId);
			}
			if(StringUtils.isNotBlank(sWatchTVSorInvariantId)) {
				q.setParameter("watchTVSorInvariantId", sWatchTVSorInvariantId);
			}
			if(StringUtils.isNotBlank(sIndividualSorInvariantId)) {
				q.setParameter("individualSorInvariantId", sIndividualSorInvariantId);
			}
			
			alQueryResponse = q.list();
														 
			LOGGER.info("{}{}MR_IAA_05 :Time taken to get associated accessIds : {}",sClassName,sMethodName, (Long.valueOf(System.currentTimeMillis()) - initMillis) / 1000.0 + "secs");

			for (Object[] oQueryResponse : alQueryResponse) {

				if (!alMemberNames.contains((String) oQueryResponse[1])) {
					alMemberNames.add((String) oQueryResponse[1]);
					BigDecimal memberNumber = (BigDecimal) oQueryResponse[0];
					String memberName = (String) oQueryResponse[1];
					String contactEmail = (String) oQueryResponse[2];
					String searchEntity = (String) oQueryResponse[3];
					String entityIdentifier = (String) oQueryResponse[4];
					String dmCTN = (String) oQueryResponse[5];
					String roleName = (String) oQueryResponse[6];
					String rank = String.valueOf(oQueryResponse[7]);
					String activatedInd = (String) oQueryResponse[8];
					String autogeneratedInd = (String) oQueryResponse[9];
					String userLockLevel = (String) oQueryResponse[10];
					String passwordDirty = (String) oQueryResponse[11];
					String fnLinkedUserId = (String) oQueryResponse[12];
					String fnLinkedStatus = (String) oQueryResponse[13];

					hmUser = CommonUtil.getHashMap();
					hmUser.put(MPSDefs.DB_MEMBER_NUM, memberNumber.toString());
					hmUser.put(MPSDefs.DB_MEMBER_NAME, memberName);
					hmUser.put(MPSDefs.DB_CONTACT_EMAIL, contactEmail);
					hmUser.put(CommonDefs.SEARCH_IDENTITY, searchEntity);
					hmUser.put(CommonDefs.SEARCH_IDENTIFIER, entityIdentifier);
					hmUser.put(CommonDefs.DMCTN, dmCTN);
					hmUser.put(MPSDefs.DB_ROLE_NAME, roleName);
					hmUser.put(CommonDefs.RANK, rank);
					hmUser.put(MPSDefs.DB_ACTIVATED_IND, activatedInd);
					hmUser.put(MPSDefs.DB_AUTOGENERATED_IND, autogeneratedInd);
					hmUser.put(MPSDefs.DB_USER_LOCK_LEVEL, userLockLevel);
					hmUser.put(MPSDefs.DB_PASSWORD_DIRTY, passwordDirty);
					hmUser.put(CommonDefs.DB_FN_LINKED_USERID, fnLinkedUserId);
					hmUser.put(CommonDefs.DB_FN_LINKED_STATUS, fnLinkedStatus);
					alAssociatedUsers.add(hmUser);
					++rowCount;
				}
			}
			LOGGER.debug("{}{}MR_IAA_06 : Total record found is: {}",sClassName,sMethodName, rowCount);
			if (rowCount == 0) {
				response = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM,
						"Associated user not found");
				LOGGER.info("{}{}MR_IAA_07 : No rows found",sClassName,sMethodName);
				return response;
			}
			response = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success");
			if (alAssociatedUsers != null && alAssociatedUsers.size() > 0) {
				response.put("associatedUsers", alAssociatedUsers);
			}
		} catch (Exception excp) {
			if (NestedExceptionUtils.getRootCause(excp) instanceof SQLException) {
				response = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, excp.getMessage());
			} else {
				response = CommonErrorMap.makeExceptionMap(excp);
			}
			sAppInfo = (String) response.get(CErrorDefs.COMMON_APP_INFO);
			if (sAppInfo == null) {
				response.put(CErrorDefs.COMMON_APP_INFO, excp.getMessage());
			}
		} finally {
			LOGGER.info("{}{}DBTOOLS999 :  hmResponse : {}",sClassName,sMethodName, response);
		}
		return response;
	}


}