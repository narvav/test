package com.att.idp.idgraphusermanagementms.service;

import com.att.idp.idgraphusermanagementms.resource.request.ResetUserPasswordRequest;
import com.att.idp.idgraphusermanagementms.resource.response.ResetUserPasswordResponse;

import jakarta.ws.rs.core.MultivaluedMap;

public interface ResetUserPasswordService {
    ResetUserPasswordResponse resetUserPassword(ResetUserPasswordRequest resetUserPasswordRequest, MultivaluedMap<String, String> requestHeader);
}
