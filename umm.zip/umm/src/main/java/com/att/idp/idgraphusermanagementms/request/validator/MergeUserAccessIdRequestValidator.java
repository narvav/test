package com.att.idp.idgraphusermanagementms.request.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import jakarta.ws.rs.core.HttpHeaders;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphusermanagementms.resource.request.MergeUserAccessIdRequest;
import com.att.idp.idgraphusermanagementms.resource.response.MergeUserAccessIdResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;

/**
 * This class, MergeUserAccessIdRequestValidator, is responsible for validating the MergeUserAccessIdRequest.
 * It checks for the presence and validity of required fields in the request, and returns a MergeUserAccessIdResponse accordingly.
 * It is annotated with @Component, @Configuration, and @PropertySource to indicate that it's a Spring Bean,
 * to allow it to access configuration properties, and to specify the location of the properties file respectively.
 *
 * The class contains several methods, including:
 * - mergeUserAccessIdRequestValidator: the main method that orchestrates the validation process.
 * - mergeUserAccessIdErrorResponse: a helper method that generates an error response.
 * - MergeUserAccessIdRequestInputValidator: a method that validates the input fields in the request.
 * - mergeUserAccessIdIsExternalCallCheck: a method that checks if the request is an external call.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class MergeUserAccessIdRequestValidator {
	private static final Logger logger = LoggerFactory.getLogger(MergeUserAccessIdRequestValidator.class);

	private String sClassName = "MergeUserAccessIdRequestValidator";

	@Value("${MergeUserAccessId_ValidCallingSystemIds}")
	private String propCallingSystemIds;

	@Value("${MergeUserAccessId_AgentCallingSystemIds}")
	private String propAgentIdRequiredCSI;

	/**
	 * This method is responsible for validating the MergeUserAccessIdRequest.
	 * It takes HttpHeaders and MergeUserAccessIdRequest as parameters.
	 * HttpHeaders contains the request headers which may include additional information required for processing the request.
	 * MergeUserAccessIdRequest encapsulates the details of the merge user access ID operation to be performed.
	 *
	 * The method performs various checks and validations on the input parameters and returns a MergeUserAccessIdResponse object.
	 * The MergeUserAccessIdResponse object encapsulates the result of the merge user access ID operation.
	 *
	 * @param requestHeader The HttpHeaders containing the request headers.
	 * @param mergeUserAccessIdRequest The MergeUserAccessIdRequest containing the details of the merge user access ID operation.
	 * @return MergeUserAccessIdResponse The response of the merge user access ID operation.
	 */
	public MergeUserAccessIdResponse mergeUserAccessIdRequestValidator(HttpHeaders requestHeader,
			MergeUserAccessIdRequest mergeUserAccessIdRequest) {

		MergeUserAccessIdResponse mergeUserAccessIdResponse = null;

		String stAppInfo = null;
		String sMethodName = ".MergeUserAccessIdRequestValidator.";
		String stIdpTraceId = null;
		String callingSystemId = null;
		if (mergeUserAccessIdRequest != null) {

			stIdpTraceId = CommonUtil.getTraceId(requestHeader);
			if(stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_"))
				return mergeUserAccessIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			mergeUserAccessIdRequest.setIdpTraceId(stIdpTraceId);

			if (requestHeader.getHeaderString("X-ATT-ClientId") != null) {
				callingSystemId = requestHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
				logger.info("{}{}MUARV_101 : CheckAccessIdMergeEligibility Request x-att-clientid: {}", sClassName,
						sMethodName, StringUtils.normalizeSpace(callingSystemId));
				mergeUserAccessIdRequest.setCallingSystemId(callingSystemId);
			} else {
				stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
				logger.info("{}{}MUARV_101.1 :: {}", sClassName, sMethodName, stAppInfo);
				return mergeUserAccessIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
		}

		if (mergeUserAccessIdRequest == null) {
			stAppInfo = "Input Request is NULL / Empty.";
			logger.info("{}{}MUARV_102 :: {}", sClassName, sMethodName, stAppInfo);
			return mergeUserAccessIdErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo, stIdpTraceId);
		}

		stIdpTraceId = CommonUtil.getTraceId(requestHeader);

		if (stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_"))
			return mergeUserAccessIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);

		mergeUserAccessIdRequest.setIdpTraceId(stIdpTraceId);

		if (requestHeader.getHeaderString("X-ATT-ClientId") != null) {
			callingSystemId = requestHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
			logger.info("{}{}MUARV_101 : CheckAccessIdMergeEligibility Request x-att-clientid: {}", sClassName,
					sMethodName, StringUtils.normalizeSpace(callingSystemId));
			mergeUserAccessIdRequest.setCallingSystemId(callingSystemId);
		} else {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			logger.info("{}{}MUARV_101.1 :: {}", sClassName, sMethodName, stAppInfo);
			return mergeUserAccessIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		

		// checking Invalid attributes passed in Request
		Map<String, Object> allUnknownAttributes = new HashMap<>(mergeUserAccessIdRequest.unknownAttributes);

		if (!allUnknownAttributes.isEmpty()) {
			stAppInfo = "Invalid Attributes passed in MergeUserAccessIdRequest : " + allUnknownAttributes;
			return mergeUserAccessIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					mergeUserAccessIdRequest.getIdpTraceId());
		}

		try {
			mergeUserAccessIdResponse = mergeUserAccessIdRequestInputValidator(mergeUserAccessIdRequest);
			if (mergeUserAccessIdResponse != null) {
				logger.info("{}{}MUARV_103 Response from MergeUserAccessIdRequestInputValidator : {}", sClassName,
						sMethodName, mergeUserAccessIdResponse);
				return mergeUserAccessIdResponse;
			} else {
				logger.debug("{}{}MUARV_104 Success Response from MergeUserAccessIdRequestInputValidator ",
						sClassName, sMethodName);
			}

			stAppInfo = "Input Validation Successful";
			logger.info("{}{}MUARV_105 : {}", sClassName, sMethodName, stAppInfo);

		} catch (Exception e) {
			stAppInfo = "Exception thrown in MergeUserAccessIdRequestValidator.MergeUserAccessIdRequestValidator : "
					+ e.getMessage();
			mergeUserAccessIdResponse = mergeUserAccessIdErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo,
					stIdpTraceId);
			logger.info("Exception in MergeUserAccessIdRequestValidator: {}", stAppInfo);
		}

		return mergeUserAccessIdResponse;
	}

	/**
	 * This method validates the input of the MergeUserAccessIdRequest.
	 * It checks if the request's attributes are valid, and returns a response accordingly.
	 *
	 * @param mergeUserAccessIdRequest The request to be validated.
	 * @return MergeUserAccessIdResponse The response after validation.
	 */
	@SuppressWarnings("unchecked")
	private MergeUserAccessIdResponse mergeUserAccessIdRequestInputValidator(
			MergeUserAccessIdRequest mergeUserAccessIdRequest) {

		MergeUserAccessIdResponse MergeUserAccessIdResponse = null;
		String stAppInfo = null;
		String sMethodName = ".MergeUserAccessIdRequestInputValidator.";
		String stTransactionName = "MergeUserAccessId";
		String stCallingSystemId = mergeUserAccessIdRequest.getCallingSystemId();
		String stFromUserName = mergeUserAccessIdRequest.getFromUserName();
		String stToUserName = mergeUserAccessIdRequest.getToUserName();
		String stAgentId = mergeUserAccessIdRequest.getAgentId();
		String stIdpTraceId = mergeUserAccessIdRequest.getIdpTraceId();

		MergeUserAccessIdResponse = mergeUserAccessIdIsExternalCallCheck(mergeUserAccessIdRequest);
		if (MergeUserAccessIdResponse != null) {
			return MergeUserAccessIdResponse;
		}

		Optional.ofNullable(stCallingSystemId)
				.ifPresent(x -> mergeUserAccessIdRequest.setCallingSystemId(x.trim().toUpperCase()));

		Optional.ofNullable(stFromUserName)
				.ifPresent(x -> mergeUserAccessIdRequest.setFromUserName(x.trim().toLowerCase()));

		Optional.ofNullable(stToUserName)
				.ifPresent(x -> mergeUserAccessIdRequest.setToUserName(x.trim().toLowerCase()));

		Optional.ofNullable(stAgentId).ifPresent(x -> mergeUserAccessIdRequest.setAgentId(x.trim()));

		if (stFromUserName == null || stToUserName == null) {
			stAppInfo = "Either of FromUserName or ToUserName are null or empty.";
			return mergeUserAccessIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (stFromUserName.equalsIgnoreCase(stToUserName)) {

			stAppInfo = "Both the FromUserName and ToUserName are the same";
			return mergeUserAccessIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);

		}

		ArrayList<String> alValidCallers = CommonUtil.parseToArray(propCallingSystemIds,
				CommonDefs.VALUE_SEPARATOR_CHAR);
		logger.info("MUARV_102.1 : all Valid callers for MergeUserAccessIdRequestInputValidator : {}", alValidCallers);

		stCallingSystemId = mergeUserAccessIdRequest.getCallingSystemId();
		stAgentId = mergeUserAccessIdRequest.getAgentId();

		if (!alValidCallers.contains(stCallingSystemId)) {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			logger.info("{}{}MUARV_102.2 : {}", sClassName, sMethodName, stAppInfo);
			return mergeUserAccessIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		ArrayList<String> alAgentIdRequiredCSI = CommonUtil.parseToArray(propAgentIdRequiredCSI,
				CommonDefs.VALUE_SEPARATOR_CHAR);

		if (alAgentIdRequiredCSI.contains(stCallingSystemId) && (stAgentId == null || stAgentId.isEmpty())) {
			stAppInfo = "AgentID is required field in Request for caller:" + stCallingSystemId;
			logger.info("{}{}MUARV_102.3 : {}", sClassName, sMethodName, StringUtils.normalizeSpace(stAppInfo));
			return mergeUserAccessIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		return MergeUserAccessIdResponse;
	}

	/**
	 * This method checks if the request is an external call.
	 * It checks the 'isExternalCall' attribute of the request, and returns a response accordingly.
	 *
	 * @param mergeUserAccessIdRequest The request to be checked.
	 * @return MergeUserAccessIdResponse The response after checking.
	 */
	private MergeUserAccessIdResponse mergeUserAccessIdIsExternalCallCheck(
			MergeUserAccessIdRequest mergeUserAccessIdRequest) {

		MergeUserAccessIdResponse MergeUserAccessIdResponse = null;
		String stAppInfo;
		String isExternalCall = mergeUserAccessIdRequest.getIsExternalCall();

		if ((isExternalCall != null && !isExternalCall.isEmpty())) {
			if (!(isExternalCall.equalsIgnoreCase(CommonDefs.IND_Y)
					|| isExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
				stAppInfo = "isExternalCall must be one of Y or N";
				return mergeUserAccessIdErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						mergeUserAccessIdRequest.getIdpTraceId());
			} else {
				mergeUserAccessIdRequest.setIsExternalCall(isExternalCall.trim().toUpperCase());
			}
		} else {
			mergeUserAccessIdRequest.setIsExternalCall(CommonDefs.IND_Y);
		}
		return MergeUserAccessIdResponse;
	}

	/**
	 * This method generates an error response for the MergeUserAccessId operation.
	 * It takes an error code, an error message, and a trace ID, and returns a response with these details.
	 *
	 * @param appStatusCode The error code.
	 * @param stAppInfo The error message.
	 * @param stIdpTraceId The trace ID.
	 * @return MergeUserAccessIdResponse The error response.
	 */
	private MergeUserAccessIdResponse mergeUserAccessIdErrorResponse(int appStatusCode, String stAppInfo,
			String stIdpTraceId) {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		return CommonUtilHelper.generateMergeUserAccessIdResponse(hmResponse);
	}
}