package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class TmemberserviceId implements Serializable {

	private static final long serialVersionUID = -8696118373500384191L;

	@Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)
	private Long memberNum;

	@Column(name = "SERVICE_ID", nullable = false, precision = 22, scale = 0)
	private Long serviceId;

	@Column(name = "GROUP_NUM", nullable = false, precision = 22, scale = 0)
	private Long groupNum;

	@Column(name = "GROUP_STATUS", nullable = false, precision = 22, scale = 0)
	private Long groupStatus;

	@Column(name = "MEMBER_STATUS", nullable = false, precision = 22, scale = 0)
	private Long memberStatus;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;

	@Column(name = "SOR_ID", precision = 22, scale = 0)
	private Long sorId;

	@Override
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TmemberserviceId))
			return false;
		TmemberserviceId castOther = (TmemberserviceId) other;

		return ((this.getMemberNum() == castOther.getMemberNum()) || (this.getMemberNum() != null
				&& castOther.getMemberNum() != null && this.getMemberNum().equals(castOther.getMemberNum())))
				&& ((this.getServiceId() == castOther.getServiceId()) || (this.getServiceId() != null
				&& castOther.getServiceId() != null && this.getServiceId().equals(castOther.getServiceId())))
				&& ((this.getGroupNum() == castOther.getGroupNum()) || (this.getGroupNum() != null
				&& castOther.getGroupNum() != null && this.getGroupNum().equals(castOther.getGroupNum())))
				&& ((this.getGroupStatus() == castOther.getGroupStatus())
				|| (this.getGroupStatus() != null && castOther.getGroupStatus() != null
				&& this.getGroupStatus().equals(castOther.getGroupStatus())))
				&& ((this.getMemberStatus() == castOther.getMemberStatus())
				|| (this.getMemberStatus() != null && castOther.getMemberStatus() != null
				&& this.getMemberStatus().equals(castOther.getMemberStatus())))
				&& ((this.getCreateDate() == castOther.getCreateDate()) || (this.getCreateDate() != null
				&& castOther.getCreateDate() != null && this.getCreateDate().equals(castOther.getCreateDate())))
				&& ((this.getLastModifiedBy() == castOther.getLastModifiedBy())
				|| (this.getLastModifiedBy() != null && castOther.getLastModifiedBy() != null
				&& this.getLastModifiedBy().equals(castOther.getLastModifiedBy())))
				&& ((this.getSorId() == castOther.getSorId()) || (this.getSorId() != null
				&& castOther.getSorId() != null && this.getSorId().equals(castOther.getSorId()))
		);
	}

	@Override
	public int hashCode() {
		int result = 17;

		result = 37 * result + (getMemberNum() == null ? 0 : this.getMemberNum().hashCode());
		result = 37 * result + (getServiceId() == null ? 0 : this.getServiceId().hashCode());
		result = 37 * result + (getGroupNum() == null ? 0 : this.getGroupNum().hashCode());
		result = 37 * result + (getGroupStatus() == null ? 0 : this.getGroupStatus().hashCode());
		result = 37 * result + (getMemberStatus() == null ? 0 : this.getMemberStatus().hashCode());
//		result = 37 * result + (getTerminateDate() == null ? 0 : this.getTerminateDate().hashCode());
		result = 37 * result + (getCreateDate() == null ? 0 : this.getCreateDate().hashCode());
//		result = 37 * result + (getLastModified() == null ? 0 : this.getLastModified().hashCode());
		result = 37 * result + (getLastModifiedBy() == null ? 0 : this.getLastModifiedBy().hashCode());
//		result = 37 * result + (getInstanceId() == null ? 0 : this.getInstanceId().hashCode());
//		result = 37 * result + (getPendingDisconnectDate() == null ? 0 : this.getPendingDisconnectDate().hashCode());
//		result = 37 * result + (getSiteId() == null ? 0 : this.getSiteId().hashCode());
		result = 37 * result + (getSorId() == null ? 0 : this.getSorId().hashCode());
//		result = 37 * result + (getSorInvariantId() == null ? 0 : this.getSorInvariantId().hashCode());
//		result = 37 * result + (getAtlasLastTimestamp() == null ? 0 : this.getAtlasLastTimestamp().hashCode());
//		result = 37 * result + (getOwnedBy() == null ? 0 : this.getOwnedBy().hashCode());
//		result = 37 * result + (getNickname() == null ? 0 : this.getNickname().hashCode());
//		result = 37 * result + (getDefaultAccount() == null ? 0 : this.getDefaultAccount().hashCode());
//		result = 37 * result + (getDateDefaultEst() == null ? 0 : this.getDateDefaultEst().hashCode());
//		result = 37 * result + (getCpniImpacted() == null ? 0 : this.getCpniImpacted().hashCode());
//		result = 37 * result + (getSuspendReasonCode() == null ? 0 : this.getSuspendReasonCode().hashCode());
//		result = 37 * result + (getParentSorId() == null ? 0 : this.getParentSorId().hashCode());
//		result = 37 * result + (getParentSorInvariantId() == null ? 0 : this.getParentSorInvariantId().hashCode());
//		result = 37 * result + (getUverseServiceInd() == null ? 0 : this.getUverseServiceInd().hashCode());
//		result = 37 * result + (getUnificationPending() == null ? 0 : this.getUnificationPending().hashCode());
		return result;
	}
}