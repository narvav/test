package com.att.idp.idgraphusermanagementms.request.validator;

import com.att.idp.idgraphusermanagementms.resource.request.UpgSecMemberIdRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpgSecMemberIdResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import jakarta.ws.rs.core.HttpHeaders;
import java.util.ArrayList;
import java.util.Map;
import java.util.Optional;

/**
 * Validator for UpgSecMemberIdRequest.
 * This class provides methods to validate the request for upgrading a secondary member ID.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class UpgSecMemberIdRequestValidator {

    /**
     * Logger instance for logging events.
     */
    private static final Logger logger = LoggerFactory.getLogger(UpgSecMemberIdRequestValidator.class);

    /**
     * Class name for logging purposes.
     */
    private static final String CLASS_NAME = "UpgSecMemberIdRequestValidator";

    @Value("${Upg_SecMemberIdToPrimary_Allowed_CallingSystemIDs}")
    private String upgSecMemeberIDAllowedCallingSystemID;

    /**
     * Validates the UpgSecMemberIdRequest.
     *
     * @param requestHeader The HTTP headers of the request.
     * @param request       The request object containing the details for upgrading a secondary member ID.
     * @return An UpgSecMemberIdResponse object containing the validation result.
     */
    public UpgSecMemberIdResponse upgSecMemberIdReqValidator(HttpHeaders requestHeader, UpgSecMemberIdRequest request) {
        String methodName = ".upgSecMemberIdReqValidator.";
        String traceId = CommonUtil.getTraceId(requestHeader);
        if (traceId == null || traceId.startsWith("AutoGen_")) {
            return logAndReturnError(CErrorDefs.ERR_INVALID_DATA_NUM, "Missing or Invalid IdpTraceId", traceId, methodName);
        }
        if (request == null) {
            return logAndReturnError(CErrorDefs.ERR_INVALID_DATA_NUM, "Input Request Parameter is NULL / Empty.", traceId, methodName);
        }

        request.setTransactionName(ProfileOrchestrationConstants.UPG_SEC_MEMBERID_TRANSACTION_NAME);
        request.setIdpTraceId(traceId);

        String clientId = requestHeader.getHeaderString("X-ATT-ClientId");
        if (clientId != null) {
            request.setCallingSystemId(clientId.toUpperCase());
        } else {
            return logAndReturnError(CErrorDefs.ERR_INVALID_DATA_NUM, "Missing or invalid X-ATT-ClientId in request header", traceId, methodName);
        }

        UpgSecMemberIdResponse response = validateRequestInput(request);
        if (response != null) {
            return response;
        }

        logger.info(SpiMarker.getInstance(), "{}{}USMIDRV_02 : Input Validation Successful", CLASS_NAME, methodName);
        return null;
    }

    /**
     * Validates the input fields of the UpgSecMemberIdRequest.
     *
     * @param request The request object containing the details for upgrading a secondary member ID.
     * @return An UpgSecMemberIdResponse object containing the validation result, or null if validation is successful.
     */
    private UpgSecMemberIdResponse validateRequestInput(UpgSecMemberIdRequest request) {
        String methodName = ".validateRequestInput";
        Optional.ofNullable(request.getSecMemberId()).ifPresent(x -> request.setSecMemberId(x.trim().toLowerCase()));
        Optional.ofNullable(request.getSecDomain()).ifPresent(x -> request.setSecDomain(x.trim().toLowerCase()));

        if (!request.unknownAttributes.isEmpty()) {
            return logAndReturnError(CErrorDefs.ERR_INVALID_DATA_NUM, "Invalid Attributes passed in UpgSecMemberIdRequest : " + request.unknownAttributes, request.getIdpTraceId(), methodName);
        }

        ArrayList allowedCallingSystemID = null;
        if (upgSecMemeberIDAllowedCallingSystemID == null || upgSecMemeberIDAllowedCallingSystemID.isBlank()) {
            return logAndReturnError(CErrorDefs.ERR_INVALID_DATA_NUM, "Missing configuration for UpgSec_Allowed_CallingSystemIDs", request.getIdpTraceId(), methodName);
        } else
            allowedCallingSystemID = CommonUtil.parseToArray(upgSecMemeberIDAllowedCallingSystemID, CommonDefs.VALUE_SEPARATOR_CHAR);

        String callingSystemId = request.getCallingSystemId();
        if (!allowedCallingSystemID.contains(callingSystemId)) {
            return logAndReturnError(CErrorDefs.ERR_INVALID_DATA_NUM, "Invalid callingSystemID :" + callingSystemId, request.getIdpTraceId(), methodName);
        }

      return null;
    }

    /**
     * Logs an error and returns an UpgSecMemberIdResponse with the error details.
     *
     * @param errorCode The error code.
     * @param errorMessage The error message.
     * @param traceId The trace ID.
     * @param methodName The method name.
     * @return An UpgSecMemberIdResponse object containing the error details.
     */
    private UpgSecMemberIdResponse logAndReturnError(int errorCode, String errorMessage, String traceId, String methodName) {
        logger.info(SpiMarker.getInstance(), "{}{}USMIRV :: {}", CLASS_NAME, methodName, errorMessage);
        Map<String, Object> hmResponse = CommonUtil.getHashMap();
        hmResponse.put(CommonDefs.COMMON_APP_INFO, errorMessage);
        hmResponse.put("idp-trace-id", traceId);
        hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(errorCode));
        return CommonUtilHelper.generateUpgSecMemberIdResponse(hmResponse);
    }
}