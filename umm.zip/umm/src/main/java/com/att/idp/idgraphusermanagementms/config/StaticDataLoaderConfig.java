package com.att.idp.idgraphusermanagementms.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.att.common.dbhelpers.MPSDB_GetDomains_H;
import com.att.common.dbhelpers.MPSDB_GetSecurityQuestions_H;
import com.att.common.dbhelpers.MPSDB_GetServiceRoles_H;
import com.att.common.dbhelpers.MPSDB_GetServices_H;
import com.att.common.dbhelpers.MPSDB_GetStatuses_H;
import com.att.common.dbhelpers.MPSDB_GetSystemOfRecords_H;
import com.att.common.validators.DomainValidation;
import com.att.common.validators.SecurityQuestionValidation;
import com.att.common.validators.ServiceRoleValidation;
import com.att.common.validators.ServiceValidation;
import com.att.common.validators.StatusValidation;
import com.att.common.validators.SystemOfRecordValidation;

@Configuration
@EnableTransactionManagement
public class StaticDataLoaderConfig {

	@Bean
	public StatusValidation getStatusValidation() {
		StatusValidation objStatusValidation = new StatusValidation();
		return objStatusValidation;
	}

	@Bean
	public SecurityQuestionValidation getSecurityQuestionValidation() {
		SecurityQuestionValidation objSecurityQuestionValidation = new SecurityQuestionValidation();
		return objSecurityQuestionValidation;
	}

	@Bean
	public ServiceValidation getServiceValidation() {
		ServiceValidation objServiceValidation = new ServiceValidation();
		return objServiceValidation;
	}

	@Bean
	public MPSDB_GetStatuses_H getMPSDB_GetStatuses_H() {
		MPSDB_GetStatuses_H objMPSDB_GetStatuses_H = new MPSDB_GetStatuses_H();
		return objMPSDB_GetStatuses_H;
	}

	@Bean
	public MPSDB_GetServices_H getMPSDB_GetServices_H() {
		MPSDB_GetServices_H objMPSDB_GetServices_H = new MPSDB_GetServices_H();
		return objMPSDB_GetServices_H;
	}

	@Bean
	public MPSDB_GetSecurityQuestions_H getMPSDB_GetSecurityQuestions_H() {
		MPSDB_GetSecurityQuestions_H objMPSDB_GetSecurityQuestions_H = new MPSDB_GetSecurityQuestions_H();
		return objMPSDB_GetSecurityQuestions_H;
	}

	@Bean
	public ServiceRoleValidation getServiceRoleValidation() {
		ServiceRoleValidation objServiceRoleValidation = new ServiceRoleValidation();
		return objServiceRoleValidation;
	}

	@Bean
	public MPSDB_GetServiceRoles_H getMPSDB_GetServiceRoles_H() {
		MPSDB_GetServiceRoles_H objMPSDB_GetServiceRoles_H = new MPSDB_GetServiceRoles_H();
		return objMPSDB_GetServiceRoles_H;
	}

	@Bean
	public DomainValidation getDomainValidation() {
		DomainValidation objDomainValidation = new DomainValidation();
		return objDomainValidation;
	}

	@Bean
	public MPSDB_GetDomains_H getMPSDB_GetDomains_H() {
		MPSDB_GetDomains_H objMPSDB_GetDomains_H = new MPSDB_GetDomains_H();
		return objMPSDB_GetDomains_H;
	}

	@Bean
	public SystemOfRecordValidation getSystemOfRecordValidation() {
		SystemOfRecordValidation objSystemOfRecordValidation = new SystemOfRecordValidation();
		return objSystemOfRecordValidation;
	}

	@Bean
	public MPSDB_GetSystemOfRecords_H getMPSDB_GetSystemOfRecords_H() {
		MPSDB_GetSystemOfRecords_H obMPSDB_GetSystemOfRecords_H = new MPSDB_GetSystemOfRecords_H();
		return obMPSDB_GetSystemOfRecords_H;
	}
}
