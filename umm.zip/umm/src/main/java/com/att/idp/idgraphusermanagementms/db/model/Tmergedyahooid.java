package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TMERGEDYAHOOID", schema = "MPS_OWNER", uniqueConstraints = @UniqueConstraint(columnNames = "YAHOO_ID"))
public class Tmergedyahooid implements Serializable {

	private static final long serialVersionUID = 1398685945816572860L;

	@GenericGenerator(name = "generator", strategy = "foreign", parameters = @Parameter(name = "property", value = "tmember"))
	@Id
	@GeneratedValue(generator = "generator")
	@Column(name = "MEMBER_NUM", unique = true, nullable = false, precision = 22, scale = 0)
	private Long memberNum;

	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	private Tmember tmember;

	@Column(name = "YAHOO_ID", unique = true, nullable = false, length = 200)
	private String yahooId;

	@Column(name = "ATT_MEMBER_ID", nullable = false, length = 200)
	private String attMemberId;

	@Column(name = "STATUS", nullable = false, length = 1)
	private char status;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;
}