package com.att.idp.idgraphusermanagementms.service.impl;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.helper.UpdateUserHelper;
import com.att.idp.idgraphusermanagementms.resource.request.UpdateUserRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdateUserResponse;
import com.att.idp.idgraphusermanagementms.service.UpdateUserService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;
import net.logstash.logback.argument.StructuredArguments;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.ws.rs.core.MultivaluedMap;
import java.util.Map;

/**
 * This class implements the UpdateUserService interface and provides the implementation for updating a user in the system.
 * It is annotated with @Service to indicate that it's a Spring Bean and @Transactional to handle the transaction management.
 *
 * It contains a method updateUser which takes an UpdateUserRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return an UpdateUserResponse object.
 *
 * The UpdateUserRequest object encapsulates the details of the user update operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class UpdateUserServiceImpl implements UpdateUserService {

	public static final Logger logger = LoggerFactory.getLogger(UpdateUserServiceImpl.class);

	private static String sClassName = "UpdateUserServiceImpl";
	@Autowired
	private UpdateUserHelper updateUserHelper;

	@Override
	public UpdateUserResponse updateUser(UpdateUserRequest updateUserRequest, MultivaluedMap<String, String> requestHeader) {

		Map<String, Object> hmResponse = null;
		String sMethodName = ".updateUser.";

		Map<String, Object> hmInput = CommonUtilHelper.objectToMap(updateUserRequest);

		String idpTraceid = (String) hmInput.get("idpTraceId");
		hmInput.put("dbusTransactionId", idpTraceid.split(":")[0]);
		hmInput.put("handle", (String) hmInput.remove("userId"));

		if (null != updateUserRequest.getZipCode() && null != updateUserRequest.getZipCode4())
			hmInput.put(CommonDefs.ZIP_CODE, updateUserRequest.getZipCode()+"-"+updateUserRequest.getZipCode4());
		else if (null != updateUserRequest.getZipCode())
			hmInput.put(CommonDefs.ZIP_CODE, updateUserRequest.getZipCode());

		// Allow callers to override MQ/AEH + CLM channels via headers (similar to merge path fix)
		if (requestHeader != null) {
			String mqAehOverride = requestHeader.getFirst(ProfileOrchestrationConstants.UPDATE_USER_MQ_AEH_SWITCH);
			if (mqAehOverride != null) {
				hmInput.put(ProfileOrchestrationConstants.UPDATE_USER_MQ_AEH_SWITCH, mqAehOverride);
			}

			String clmOverride = requestHeader.getFirst(ProfileOrchestrationConstants.UPDATE_USER_NOTIFICATION_CLM_SWITCH);
			if (clmOverride != null) {
				hmInput.put(ProfileOrchestrationConstants.UPDATE_USER_NOTIFICATION_CLM_SWITCH, clmOverride);
			}
		}

		logger.info(SpiMarker.getInstance(),
				"UpdateUserServiceImpl.updateUser.UUS_01 : Calling updateUserHelper with Input : {}",
				StructuredArguments.entries(hmInput));

		hmResponse = updateUserHelper.updateUser(hmInput);

		hmResponse=CommonUtilHelper.processHmResponse(hmResponse, hmInput, "updateUserHelper", ".updateUser");
		hmResponse.put("idp-trace-id", updateUserRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME, "UpdateUser");
		UpdateUserResponse updateUserResponse = CommonUtilHelper.generateUpdateUserResponse(hmResponse);

		String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

		if (sTxnRollBack != null) {
			throw new InvalidInputDataException(hmResponse);
		}
		logger.info("{}{}UUS_05 : Response from UpdateUserServiceImpl.updateUser : {}", sClassName, sMethodName,
				updateUserResponse);
		return updateUserResponse;
	}
	
}