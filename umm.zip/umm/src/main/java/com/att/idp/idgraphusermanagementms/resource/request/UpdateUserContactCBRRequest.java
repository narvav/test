package com.att.idp.idgraphusermanagementms.resource.request;
import com.fasterxml.jackson.annotation.*;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.HashMap;
import java.util.Map;

/**
 * This class represents a request to update a user's contact in the system.
 * It contains fields for callingSystemId, transactionName, agentId, guid, handle (userId), domain, contactType, phoneNumber, phoneNumberExt, phoneNumberType, subscriptionId, validationStatus, contactStatus, idpTraceId, isExternalCall, and a map for unknownAttributes.
 * Each field has specific constraints such as not null, size limits, and specific patterns.
 *
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 *
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 * It also overrides the toString method to return a JSON-style string representation of the object.
 *
 */
@Data
@Schema(name = "UpdateUserContactCBRRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdateUserContactCBRRequest {
    protected String callingSystemId;

    protected final String transactionName = "UpdateUserContactCBR";

    @Schema(name = "agentId")
    @Size(min = 1, max = 20, message =  "agentId length is invalid|UpdateUserContactCBR")
    private String agentId;

    @Schema(name = "guid")
    @Size(min = 1, max = 30, message =  "guid length is invalid|UpdateUserContactCBR")
    private String guid;

    @Schema(name = "userId")
    @Size(min = 1, max = 127, message =  "userId length is invalid|UpdateUserContactCBR")
    @JsonProperty("userId")
    private String handle;

    @Schema(name = "domain")
    @Size(min = 1, max = 30, message =  "domain length is invalid|UpdateUserContactCBR")
    private String domain;

    @Schema(name = "contactType")
    @NotNull(message = "contactType is required field in input request.|UpdateUserContactCBR")
    @Size(min = 1, max = 10, message =  "contactType length is invalid|UpdateUserContactCBR")
    private String contactType;

    @Schema(name = "phoneNumber")
    @Size(min = 10, max = 10, message =  "phoneNumber length is invalid|UpdateUserContactCBR")
    private String phoneNumber;

    @Schema(name = "phoneNumberExt")
    @Size(min = 1, max = 20, message =  "phoneNumberExt length is invalid|UpdateUserContactCBR")
    private String phoneNumberExt;

    @Schema(name = "phoneNumberType")
    @Size(min = 1, max = 10, message =  "phoneNumberType length is invalid|UpdateUserContactCBR")
    private String phoneNumberType;

    @Schema(name = "subscriptionId")
    @Size(min = 1, max = 255, message =  "subscriptionId length is invalid|UpdateUserContactCBR")
    private String subscriptionId;

    @Schema(name = "validationStatus")
    @NotNull(message = "ValidationStatus is required field in input request.|UpdateUserContactCBR")
    @Size(min = 1, max = 30, message =  "validationStatus length is invalid|UpdateUserContactCBR")
    private String validationStatus;

    @Schema(name = "contactStatus")
    @Size(min = 1, max = 1, message =  "contactStatus length is invalid|UpdateUserContactCBR")
    private String contactStatus;

    @Schema(name = "idpTraceId")
    private String idpTraceId;

    protected String isExternalCall;

    /**
	 * It is a Map that is used to store any unknown attributes that may be present in the JSON request.
	 * The field is initialized with an empty HashMap.
	 * It uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
	 * The key of the Map is the attribute name and the value is the attribute value.
	 *
	 * @return Map<String,Object> The map of unknown attributes.
	 */
    @JsonAnySetter
    @JsonAnyGetter
    public Map<String,Object> unknownAttributes = new HashMap<>();

    @Override
    public java.lang.String toString() {
        return "UpdateUserContactCBRRequest{" +
                "callingSystemId='" + callingSystemId + '\'' +
                ", transactionName='" + transactionName + '\'' +
                ", agentId='" + agentId + '\'' +
                ", guid='" + guid + '\'' +
                ", handle='" + handle + '\'' +
                ", domain='" + domain + '\'' +
                ", contactType='" + contactType + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", phoneNumberExt='" + phoneNumberExt + '\'' +
                ", phoneNumberType='" + phoneNumberType + '\'' +
                ", subscriptionId='" + subscriptionId + '\'' +
                ", validationStatus='" + validationStatus + '\'' +
                ", contactStatus='" + contactStatus + '\'' +
                ", idpTraceId='" + idpTraceId + '\'' +
                '}';
    }
}