package com.att.idp.idgraphusermanagementms.resource.request;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.util.HashMap;
import java.util.Map;

/**
 * This class represents a request to add a secondary member ID in the system.
 * It contains fields for various details such as callingSystemId, transactionName, idpTraceId, domain, userId, clearPassword, parentDomain, parentUserId, firstName, lastName, nickName, lastFourSSN, securityQuestion, securityAnswer, contactEmail, proofZip, dateOfBirth, gender, agentId, passcode, online1SecurityQuestion, online1SecurityAnswer, online2SecurityQuestion, and online2SecurityAnswer.
 * Each field has specific constraints such as not blank, size limits, and patterns.
 * The class uses Lombok's @Data annotation to automatically generate getter and setter methods for all fields.
 * It also uses Jackson's @JsonAnySetter and @JsonAnyGetter annotations to handle any unknown attributes in the JSON request.
 * The class is annotated with Swagger's @ApiModel and @ApiModelProperty annotations to provide metadata for the Swagger UI.
 */
@Data
@Schema(name = "UpgSecMemberIdRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpgSecMemberIdRequest {

    private String callingSystemId;
    private String transactionName;
    @Schema(name = "idpTraceId")
    private String idpTraceId;

    @Schema(name = "secDomain")
    @NotBlank(message = "Secondary Domain is required in input request|UpgSecMemberId")
    @Size(min = 1, max = 30, message = "Secondary Domain length is invalid|UpgSecMemberId")
    @JsonProperty("secDomain")
    private String secDomain;

    @Schema(name = "SecondaryMemberId")
    @NotBlank(message = "Secondary MemberId is required in input request|UpgSecMemberId")
    @Size(min = 1, max = 127, message = "Secondary MemberId length is invalid|UpgSecMemberId")
    @JsonProperty("secMemberId")
    private String secMemberId;

    @JsonAnySetter
    @JsonAnyGetter
    public Map<String, Object> unknownAttributes = new HashMap<>();

    /**
     * Returns a string representation of the AddSecMemberIdRequest object.
     * This method overrides the default toString method to provide a custom string representation of the object.
     *
     * @return A string representation of the AddSecMemberIdRequest object, including all its fields and their values.
     */
    @Override
    public String toString() {
        return "UpgSecMemberIdRequest{" +
                "callingSystemId='" + callingSystemId + '\'' +
                ", transactionName='" + transactionName + '\'' +
                ", secDomain='" + secDomain + '\'' +
                ", secMemberId='" + secMemberId + '\'' +
                ", unknownAttributes=" + unknownAttributes +
                '}';
    }
}