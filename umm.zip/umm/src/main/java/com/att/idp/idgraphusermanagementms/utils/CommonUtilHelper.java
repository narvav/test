package com.att.idp.idgraphusermanagementms.utils;

import com.att.idp.core.exception.ServiceException;
import com.att.idp.idgraphusermanagementms.db.helper.DBHelper;
import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.message.ErrorMessages;
import com.att.idp.idgraphusermanagementms.resource.response.*;
import com.att.mpsys.common.utils.*;
import com.att.mpsys.common.utils.RILDefs;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.PropertyAccessor;
import org.springframework.beans.PropertyAccessorFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;
import org.apache.commons.lang.StringUtils;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import java.lang.reflect.Field;
import java.security.SecureRandom;
import java.util.*;

/**
 * The CommonUtilHelper class is part of the com.att.idp.idgraphusermanagementms.utils package.
 * This class contains utility methods that are used across the application.
 * It includes methods for building responses, generating error and success responses, and converting objects to maps.
 * The class is annotated with @Component, indicating that it is an auto-detectable Spring bean.
 */
@Component
public  class CommonUtilHelper {


	public static final Logger logger = LoggerFactory.getLogger(CommonUtilHelper.class);
	private static final String MS_MPSYS_BE = "MS_MPSYS_BE_";
	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for building a response based on the type of the userDetailResponse object.
	 * The method takes an Object as a parameter, which can be an instance of various response classes.
	 * Depending on the type of the userDetailResponse object, the method redirects to specific buildResponse methods for different operations such as addUser, updateUser, checkUserIdAvailability, etc.
	 * The method returns a Response object which represents the HTTP response to be sent back to the client.
	 *
	 * @param userDetailResponse An object which can be an instance of various response classes.
	 * @return Response A Response object representing the HTTP response to be sent back to the client.
	 */
	public static Response buildMSResponse(Object userDetailResponse) {
		Response response = null;
		AddUserResponse addUser = null;
		UpdateUserResponse	updateUser=null;
		CheckUserIdAvailabilityResponse checkUser = null;
		ChangeUserNameResponse changeUserNameResponse = null;
		CheckAccessIdMergeEligibilityResponse checkAccessIdMergeEligibilityResponse = null;
		UpdateUserFraudResponse updateUserFraudLockResponse = null;
		UpdateUserContactCBRResponse updateUserContactCBRResponse = null;
		ValidateUserCredentialsResponse validateUserCredentialsResponse = null;
		ExtUserResponse extUserResponse = null;
		RegisterEmailUserResponse registerEmailUserResponse = null;
		TransactionRateLimitResponse transactionRateLimitResponse=null;
		CommonResponse commonResponse = null;
		AddSecMemberIdResponse addSecMemberIdResponse = null;
		ProfanityScannerResponse profanityScannerResponse = null;
		LinkMemberResponse linkMemberResponse = null;
		ResetUserPasswordResponse resetUserPasswordResponse = null;
		UpdateUserPasswordResponse updateUserPasswordResponse = null;
		UpgSecMemberIdResponse upgSecMemberIdResponse = null;
		UpdatePrepaidUserPasswordResponse updatePrepaidUserPasswordResponse=null;
		MergeUserAccessIdResponse mergeUserAccessIdResponse=null;
		MemberIdResponse memberIdResponse = null;
		DeleteUserResponse deleteUserResponse = null;


		if(userDetailResponse instanceof AddUserResponse) {
			addUser = (AddUserResponse) userDetailResponse;
			String sCategoryCode = addUser.getAppCategoryCode();
			response =  createResponse(addUser, response,sCategoryCode );
		}
		else if(userDetailResponse instanceof UpdateUserResponse) {
			updateUser = (UpdateUserResponse) userDetailResponse;
			String sCategoryCode = updateUser.getAppCategoryCode();
			response =  createResponse(updateUser, response,sCategoryCode );
		}
		else if(userDetailResponse instanceof CheckUserIdAvailabilityResponse) {
			checkUser = (CheckUserIdAvailabilityResponse) userDetailResponse;
			String sCategoryCode = checkUser.getAppCategoryCode();
			response =  createResponse(checkUser, response,sCategoryCode );
		}
		else if(userDetailResponse instanceof ChangeUserNameResponse) {
			changeUserNameResponse = (ChangeUserNameResponse) userDetailResponse;
			String sCategoryCode = changeUserNameResponse.getAppCategoryCode();
			response = createResponse(changeUserNameResponse, response,sCategoryCode );
		}
		else if(userDetailResponse instanceof CheckAccessIdMergeEligibilityResponse) {
			checkAccessIdMergeEligibilityResponse = (CheckAccessIdMergeEligibilityResponse) userDetailResponse;
			String sCategoryCode = checkAccessIdMergeEligibilityResponse.getAppCategoryCode();
			response = createResponse(checkAccessIdMergeEligibilityResponse, response,sCategoryCode );
		}
		else if(userDetailResponse instanceof UpdateUserFraudResponse) {
			updateUserFraudLockResponse =(UpdateUserFraudResponse) userDetailResponse;
			String sCategoryCode = updateUserFraudLockResponse.getAppCategoryCode();
			response = createResponse(updateUserFraudLockResponse, response,sCategoryCode );
		}
		else if(userDetailResponse instanceof UpdateUserContactCBRResponse) {
			updateUserContactCBRResponse = (UpdateUserContactCBRResponse) userDetailResponse;
			String sCategoryCode = updateUserContactCBRResponse.getAppCategoryCode();
			response = createResponse(updateUserContactCBRResponse, response,sCategoryCode );
		}
		else if(userDetailResponse instanceof ValidateUserCredentialsResponse) {
			validateUserCredentialsResponse =(ValidateUserCredentialsResponse) userDetailResponse;
			String sCategoryCode = validateUserCredentialsResponse.getAppCategoryCode();
			response = createResponse(validateUserCredentialsResponse, response,sCategoryCode );
		}
		else if(userDetailResponse instanceof ExtUserResponse) {
			extUserResponse =(ExtUserResponse) userDetailResponse;
			String sCategoryCode = extUserResponse.getAppCategoryCode();
			response = createResponse(extUserResponse, response,sCategoryCode );
		}else if (userDetailResponse instanceof RegisterEmailUserResponse ) {
			registerEmailUserResponse = (RegisterEmailUserResponse) userDetailResponse;
			String sCategoryCode = registerEmailUserResponse.getAppCategoryCode();
			response = createResponse(registerEmailUserResponse, response, sCategoryCode);
		}else if (userDetailResponse instanceof TransactionRateLimitResponse) {
			transactionRateLimitResponse = (TransactionRateLimitResponse) userDetailResponse;
			String sCategoryCode = transactionRateLimitResponse.getAppCategoryCode();
			response = createResponse(transactionRateLimitResponse, response, sCategoryCode);
		}else if (userDetailResponse instanceof AddSecMemberIdResponse) {
			addSecMemberIdResponse = (AddSecMemberIdResponse) userDetailResponse;
			String sCategoryCode = addSecMemberIdResponse.getAppCategoryCode();
			response = createResponse(addSecMemberIdResponse, response, sCategoryCode);
		} else if (userDetailResponse instanceof ProfanityScannerResponse) {
			profanityScannerResponse = (ProfanityScannerResponse) userDetailResponse;
			String idpTraceId = profanityScannerResponse.getIdpTraceId();
			String sErrorId = profanityScannerResponse.getErrors() != null ? profanityScannerResponse.getErrors().getErrorId() : null;
			response = profanityCreateResponse(profanityScannerResponse, response, idpTraceId,sErrorId);
		} else if(userDetailResponse instanceof LinkMemberResponse) {
			linkMemberResponse = (LinkMemberResponse) userDetailResponse;
			String sCategoryCode = linkMemberResponse.getAppCategoryCode();
			response = createResponse(linkMemberResponse, response, sCategoryCode);
		} else if(userDetailResponse instanceof ResetUserPasswordResponse) {
			resetUserPasswordResponse = (ResetUserPasswordResponse) userDetailResponse;
			String sCategoryCode = resetUserPasswordResponse.getAppCategoryCode();
			response = createResponse(resetUserPasswordResponse, response, sCategoryCode);
		} else if(userDetailResponse instanceof UpdateUserPasswordResponse) {
			updateUserPasswordResponse = (UpdateUserPasswordResponse) userDetailResponse;
			String sCategoryCode = updateUserPasswordResponse.getAppCategoryCode();
			response = createResponse(updateUserPasswordResponse, response, sCategoryCode);
		} else if(userDetailResponse instanceof UpgSecMemberIdResponse) {
			upgSecMemberIdResponse = (UpgSecMemberIdResponse) userDetailResponse;
			String sCategoryCode = upgSecMemberIdResponse.getAppCategoryCode();
			response = createResponse(upgSecMemberIdResponse, response, sCategoryCode);
		}else if(userDetailResponse instanceof UpdatePrepaidUserPasswordResponse) {
			updatePrepaidUserPasswordResponse = (UpdatePrepaidUserPasswordResponse) userDetailResponse;
			String sCategoryCode = updatePrepaidUserPasswordResponse.getAppCategoryCode();
			response = createResponse(updatePrepaidUserPasswordResponse, response, sCategoryCode);
		}else if(userDetailResponse instanceof  MergeUserAccessIdResponse) {
			mergeUserAccessIdResponse = (MergeUserAccessIdResponse) userDetailResponse;
			String sCategoryCode = mergeUserAccessIdResponse.getAppCategoryCode();
			response = createResponse(mergeUserAccessIdResponse, response, sCategoryCode);
		}else if(userDetailResponse instanceof MemberIdResponse) {
			memberIdResponse = (MemberIdResponse) userDetailResponse;
			String sCategoryCode = memberIdResponse.getAppCategoryCode();
			response = createResponse(memberIdResponse, response, sCategoryCode);
		} else if (userDetailResponse instanceof DeleteUserResponse) {
			deleteUserResponse = (DeleteUserResponse) userDetailResponse;
			String sCategoryCode = deleteUserResponse.getAppCategoryCode();
			response = createResponse(deleteUserResponse, response, sCategoryCode);
		}else {
			commonResponse = (CommonResponse) userDetailResponse;
			String sCategoryCode = commonResponse.getAppCategoryCode();
			response = createResponse(commonResponse, response, sCategoryCode);
		}
		return response;
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is an alternative to the buildMSResponse method.
	 * The method takes an Object as a parameter, which should be an instance of a class that implements the AppCategoryCodeProvider interface.
	 * The method redirects to the createResponse method, passing the responseObject, a null Response object, and the application category code obtained from the responseObject.
	 * The method returns a Response object which represents the HTTP response to be sent back to the client.
	 *
	 * @param responseObject An object which should be an instance of a class that implements the AppCategoryCodeProvider interface.
	 * @return Response A Response object representing the HTTP response to be sent back to the client.
	 */
	public static Response buildMSResponse2(Object responseObject) {
		Response response = null;
		if (responseObject instanceof AppCategoryCodeProvider) {
			AppCategoryCodeProvider provider = (AppCategoryCodeProvider) responseObject;
			String sCategoryCode = provider.getAppCategoryCode();
			response = createResponse(provider, response, sCategoryCode);
		}
		return response;
	}

	private static Response createResponse(Object OUDResponse, Response response, String sCategoryCode) {
		String commonSuccessCategoryId = "0";
		String commonErrCategoryId = "1";
		String categoryCodeSystemError = "2";
		String categoryCodeDataError = "3";
		//Added this category code for mapping USER_NO_FOUND and BAN_NOT_FOUND to 404 statuscode
		String categoryCodeNotFoundError = "4";

		if (commonErrCategoryId.equals(sCategoryCode)) {
			response = Response.status(Status.INTERNAL_SERVER_ERROR).entity(OUDResponse).build();
		} else if (categoryCodeSystemError.equals(sCategoryCode)) {
			response = Response.status(Status.INTERNAL_SERVER_ERROR).entity(OUDResponse).build();
		} else if (categoryCodeDataError.equals(sCategoryCode)) {
			response = Response.status(Status.BAD_REQUEST).entity(OUDResponse).build();
		} else if (categoryCodeNotFoundError.equals(sCategoryCode)) {
			response = Response.status(Status.NOT_FOUND).entity(OUDResponse).build();
		}else if (commonSuccessCategoryId.equals(sCategoryCode)) {
			response = Response.status(Status.OK).entity(OUDResponse).build();
		}
		return response;
	}

	/**
	 * Generates a Response for the Profanity Scanner based on the provided error ID and trace ID.
	 * This method creates a Response object based on the error ID and trace ID provided.
	 * It sets the HTTP status code and entity of the Response object according to the error ID.
	 * If the error ID indicates a server error, it sets the status to INTERNAL_SERVER_ERROR.
	 * If the error ID indicates a client error, it sets the status to BAD_REQUEST.
	 * If no error ID is provided but a trace ID is present, it sets the status to OK.
	 *
	 * @param OUDResponse The response object to be included in the HTTP response.
	 * @param response The initial Response object, which will be modified and returned.
	 * @param idpTraceId The trace ID for the operation.
	 * @param sErrorId The error ID indicating the type of error.
	 * @return Response A Response object representing the HTTP response to be sent back to the client.
	 */
	private static Response profanityCreateResponse(Object OUDResponse, Response response, String idpTraceId,String sErrorId) {

		if (sErrorId!=null && (sErrorId.equals("MS_MPSYS_BE_602") || sErrorId.equals("MS_MPSYS_BE_304") || sErrorId.equals("MS_MPSYS_BE_605"))) {
			response = Response.status(Status.INTERNAL_SERVER_ERROR).entity(OUDResponse).build();
		}
		else if (sErrorId!=null &&(sErrorId.equals("MS_MPSYS_BE_100") || sErrorId.equals("MS_MPSYS_BE_395"))) {
			response = Response.status(Status.BAD_REQUEST).entity(OUDResponse).build();
		} else if (idpTraceId !=null && !idpTraceId.isEmpty()) {
			response = Response.status(Status.OK).entity(OUDResponse).build();
		}
		return response;
	}

	private static AddUserResponse addUserErrorResponse(int appStatusCode, String appInfo,
														ErrorMessages errorMessage, Map hmSuggestHandles, String stIdpTraceId) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		AddUserResponse addUserResponse = new AddUserResponse();
		addUserResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		addUserResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		addUserResponse.setTransactionName(CommonDefs.ADD_USER_TRANSACTION_NAME);
		addUserResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		addUserResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		addUserResponse.setErrors(new ServiceException(errorMessage, appInfo).getError());
		addUserResponse.setIdpTraceId(stIdpTraceId);
		if(hmSuggestHandles!=null)
		{
			addUserResponse.setSuggestedHandle1((String)hmSuggestHandles.get(CommonDefs.SUGGESTED_HANDLE + 1));
			addUserResponse.setSuggestedHandle2((String)hmSuggestHandles.get(CommonDefs.SUGGESTED_HANDLE + 2));
			addUserResponse.setSuggestedHandle3((String)hmSuggestHandles.get(CommonDefs.SUGGESTED_HANDLE + 3));
		}
		return addUserResponse;

	}

	/**
	 * Generates an UpdateUserResponse in case of error scenarios.
	 * This method creates an UpdateUserResponse object based on the provided status code, additional information,
	 * error message, suggested handles, and trace ID. It uses the makeCategoryMap method of the CommonErrorMap class
	 * to create a HashMap containing the response details, and sets the fields of the UpdateUserResponse object using
	 * the values from the HashMap.
	 *
	 * @param appStatusCode The status code of the operation.
	 * @param appInfo Additional information about the operation.
	 * @param errorMessage An ErrorMessages object representing the error message.
	 * @param hmSuggestHandles A Map containing suggested handles.
	 * @param stIdpTraceId The trace ID for the operation.
	 * @return UpdateUserResponse An UpdateUserResponse object representing the error response to be sent back to the client.
	 */
	private static UpdateUserResponse updateUserErrorResponse(int appStatusCode, String appInfo,
															  ErrorMessages errorMessage, Map hmSuggestHandles, String stIdpTraceId) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		UpdateUserResponse updateUserResponse = new UpdateUserResponse();
		updateUserResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		updateUserResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		updateUserResponse.setTransactionName(ProfileOrchestrationConstants.UPDATE_USER_TRANSACTION_NAME);
		updateUserResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		updateUserResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		updateUserResponse.setErrors(new ServiceException(errorMessage, appInfo).getError());
		updateUserResponse.setIdpTraceId(stIdpTraceId);
		if(hmSuggestHandles!=null)
		{
			updateUserResponse.setSuggestedHandle1((String)hmSuggestHandles.get(CommonDefs.SUGGESTED_HANDLE + 1));
			updateUserResponse.setSuggestedHandle2((String)hmSuggestHandles.get(CommonDefs.SUGGESTED_HANDLE + 2));
			updateUserResponse.setSuggestedHandle3((String)hmSuggestHandles.get(CommonDefs.SUGGESTED_HANDLE + 3));
		}
		return updateUserResponse;
	}
	private static  AddUserResponse addUserSuccessResponse(int appStatusCode, String appInfo, String guid, String stIdpTraceId) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		AddUserResponse addUserResponse = new AddUserResponse();
		addUserResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		addUserResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		addUserResponse.setTransactionName(CommonDefs.ADD_USER_TRANSACTION_NAME);
		addUserResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		addUserResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		addUserResponse.setGuid(guid);
		addUserResponse.setIdpTraceId(stIdpTraceId);
		return addUserResponse;

	}

	/**
	 * Generates an UpdateUserResponse in case of success scenarios.
	 * This method creates an UpdateUserResponse object based on the provided status code, additional information,
	 * GUID, and trace ID. It uses the makeCategoryMap method of the CommonErrorMap class to create a HashMap
	 * containing the response details, and sets the fields of the UpdateUserResponse object using the values from the HashMap.
	 *
	 * @param appStatusCode The status code of the operation.
	 * @param appInfo Additional information about the operation.
	 * @param guid The GUID of the user.
	 * @param stIdpTraceId The trace ID for the operation.
	 * @return UpdateUserResponse An UpdateUserResponse object representing the successful response to be sent back to the client.
	 */
	private static  UpdateUserResponse updateUserSuccessResponse(int appStatusCode, String appInfo, String guid, String stIdpTraceId) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		UpdateUserResponse updateUserResponse = new UpdateUserResponse();
		updateUserResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		updateUserResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		updateUserResponse.setTransactionName(ProfileOrchestrationConstants.UPDATE_USER_TRANSACTION_NAME);
		updateUserResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		updateUserResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		updateUserResponse.setGuid(guid);
		updateUserResponse.setIdpTraceId(stIdpTraceId);
		return updateUserResponse;

	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating a response based on the transaction name in the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following key:
	 * - CommonDefs.TRANSACTION_NAME: The name of the transaction.
	 * Depending on the transaction name, the method redirects to specific generateResponse methods for different operations such as addUser, updateUser, checkUserIdAvailability, etc.
	 * The method returns an Object which can be an instance of various response classes.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return Object An object which can be an instance of various response classes.
	 */
	public static Object generateOUDResponse(Map<String, Object> hmResponse) {
		String stTransactionName = (String) hmResponse.get(CommonDefs.TRANSACTION_NAME);
		if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.ADD_USER_TRANSACTION_NAME)) {
			return generateAddUserResponse(hmResponse);
		} else if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.UPDATE_USER_TRANSACTION_NAME)) {
			return generateUpdateUserResponse(hmResponse);
		} else if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.CHECK_USERID_AVAILABILITY_TRANSACTION_NAME)) {
			return generateCheckUserResponse(hmResponse);
		} else if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.CHANGE_USERNAME_TRANSACTION_NAME)) {
			return generateChangeUserNameResponse(hmResponse);
		} else if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.UPDATE_USERFRAUD_TRANSACTION_NAME)) {
			return generateUpdateUserFraudResponse(hmResponse);
		} else if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.CHECK_ACCESSID_MERGE_ELIGIBILITY)) {
			return generateCheckAccessIdMergeEligibilityResponse(hmResponse);
		}else if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.VALIDATE_USER_CREDENTIALS_TRANSACTION_NAME)) {
			return generateValidateUserCredentialsResponse(hmResponse);
		}else if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.UPDATE_USER_CONTACT_CBR_TRANSACTION_NAME)) {
			return generateUpdateUserContactCBRResponse(hmResponse);
		}else if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.ADD_UPDATE_EXTUSER_TRANSACTION_NAME) || stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.ADD_EXTUSER_TRANSACTION_NAME) || stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.UPDATE_EXTUSER_TRANSACTION_NAME)) {
			return generateExtUserResponse(hmResponse);
		}else if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.MERGE_USER_ACCESSID_TRANSACTION_NAME)) {
			return generateMergeUserAccessIdResponse(hmResponse);
		}else if (stTransactionName.equalsIgnoreCase(CommonDefs.TXN_RATE_LIMIT_STATUS)) {
			return generateTxnRateLimitStatusResponse(hmResponse);
		}else if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.ADD_SEC_MEMBERID_TRANSACTION_NAME)) {
			return generateAddSecMemberIdResponse(hmResponse);
		}else if (stTransactionName.equalsIgnoreCase("RegisterEmailUser")) {
			return generateRegisterEmailUserResponse(hmResponse);
		}else if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.PROFANITY_SCANNER_TRANSACTION_NAME)) {
			return generateProfanityScannerResponse(hmResponse);
		}else if (stTransactionName.equalsIgnoreCase("LinkMember")) {
			return generateLinkMemberResponse(hmResponse);
		}else if (stTransactionName.equalsIgnoreCase("ResetUserPassword")) {
			return generateResetUserPasswordResponse(hmResponse);
		}else if (stTransactionName.equalsIgnoreCase("UpgSecMemberId")) {
			return generateUpgSecMemberIdResponse(hmResponse);
		}else if (stTransactionName.equalsIgnoreCase("UpdateUserPassword")) {
			return generateUpdateUserPasswordResponse(hmResponse);
		}else if (stTransactionName.equalsIgnoreCase("UpdatePrepaidUserPassword")) {
				return generateUpdatePrepaidUserPasswordResponse(hmResponse);
		}else if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.DELETE_USER_TRANS_NAME)) {
			return generateDeleteUserResponse(hmResponse);
		}else {
			return generateCommonResponse(hmResponse);
		}
		//return null;
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating an AddUserResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - CommonDefs.GUID: The unique identifier for the user.
	 * - "idp-trace-id": The trace ID for the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns an AddUserResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return AddUserResponse An AddUserResponse object representing the response to be sent back to the client.
	 */
	public static AddUserResponse generateAddUserResponse(Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stGuid = (String) hmResponse.get(CommonDefs.GUID);
		String stIdpTraceId=(String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);

		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		int appStatusCode = Integer.parseInt(stAppStatusCode);
		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			return addUserSuccessResponse(appStatusCode, stAppInfo, stGuid,stIdpTraceId);
		} else {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE +stAppStatusCode);

			if (hmResponse.get(CommonDefs.SUGGESTLIST) != null)
				return addUserErrorResponse(appStatusCode, stAppInfo, errMsg, (HashMap) hmResponse.get(CommonDefs.SUGGESTLIST),stIdpTraceId);
			else
				return addUserErrorResponse(appStatusCode, stAppInfo, errMsg, null,stIdpTraceId);
		}
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating an UpdateUserResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - CommonDefs.GUID: The unique identifier for the user.
	 * - "idp-trace-id": The trace ID for the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns an UpdateUserResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return UpdateUserResponse An UpdateUserResponse object representing the response to be sent back to the client.
	 */
	public static UpdateUserResponse generateUpdateUserResponse(Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stGuid = (String) hmResponse.get(CommonDefs.GUID);
		String stIdpTraceId=(String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);

		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		int appStatusCode = Integer.parseInt(stAppStatusCode);
		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			return updateUserSuccessResponse(appStatusCode, stAppInfo, stGuid,stIdpTraceId);
		} else {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE+stAppStatusCode);

			if (hmResponse.get(CommonDefs.SUGGESTLIST) != null)
				return updateUserErrorResponse(appStatusCode, stAppInfo, errMsg,
						(HashMap) hmResponse.get(CommonDefs.SUGGESTLIST),stIdpTraceId);
			else
				return updateUserErrorResponse(appStatusCode, stAppInfo, errMsg, null,stIdpTraceId);

		}
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating a CheckUserIdAvailabilityResponse in case of error scenarios.
	 * The method takes five parameters: the status code of the operation, additional information about the operation,
	 * an ErrorMessages object representing the error message, the status of the linked FN user, and the trace ID for the operation.
	 * The method uses the status code and additional information to create a HashMap using the makeCategoryMap method of the CommonErrorMap class.
	 * The HashMap contains the following keys:
	 * - CommonDefs.COMMON_APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_STATUS_MSG: The status message of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - CommonDefs.COMMON_APP_CATEGORY_CODE: The category code of the operation.
	 * The method then creates a new CheckUserIdAvailabilityResponse object and sets its fields using the values from the HashMap and the other parameters.
	 * The method returns the CheckUserIdAvailabilityResponse object.
	 *
	 * @param appStatusCode The status code of the operation.
	 * @param appInfo Additional information about the operation.
	 * @param// errorMessage An ErrorMessages object representing the error message.
	 * @param// linkedFNUserStatus The status of the linked FN user.
	 * @param stIdpTraceId The trace ID for the operation.
	 * @return CheckUserIdAvailabilityResponse A CheckUserIdAvailabilityResponse object representing the response to be sent back to the client.
	 */
	public static CheckUserIdAvailabilityResponse checkUserSuccessResponse(int appStatusCode, String appInfo, String domain,
																		   List<SuggestHandle> suggestList, String stIdpTraceId) {

		HashMap<String,Object> hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		CheckUserIdAvailabilityResponse checkUserResponse = new CheckUserIdAvailabilityResponse();
		checkUserResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		checkUserResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		checkUserResponse.setTransactionName("CheckUserIdAvailability");
		checkUserResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		checkUserResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		checkUserResponse.setDomain(domain);
		checkUserResponse.setSuggestList(suggestList);
		checkUserResponse.setIdpTraceId(stIdpTraceId);
		return checkUserResponse;

	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating a CheckUserIdAvailabilityResponse in case of error scenarios.
	 * The method takes five parameters: the status code of the operation, additional information about the operation,
	 * an ErrorMessages object representing the error message, the status of the linked FN user, and the trace ID for the operation.
	 * The method uses the status code and additional information to create a HashMap using the makeCategoryMap method of the CommonErrorMap class.
	 * The HashMap contains the following keys:
	 * - CommonDefs.COMMON_APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_STATUS_MSG: The status message of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - CommonDefs.COMMON_APP_CATEGORY_CODE: The category code of the operation.
	 * The method then creates a new CheckUserIdAvailabilityResponse object and sets its fields using the values from the HashMap and the other parameters.
	 * The method returns the CheckUserIdAvailabilityResponse object.
	 *
	 * @param appStatusCode The status code of the operation.
	 * @param appInfo Additional information about the operation.
	 * @param errorMessage An ErrorMessages object representing the error message.
	 * @param linkedFNUserStatus The status of the linked FN user.
	 * @param stIdpTraceId The trace ID for the operation.
	 * @return CheckUserIdAvailabilityResponse A CheckUserIdAvailabilityResponse object representing the response to be sent back to the client.
	 */
	public static CheckUserIdAvailabilityResponse checkUserErrorResponse(int appStatusCode, String appInfo,
																		 ErrorMessages errorMessage, String linkedFNUserStatus, String stIdpTraceId) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		CheckUserIdAvailabilityResponse checkUserResponse = new CheckUserIdAvailabilityResponse();
		checkUserResponse.setAppStatusCode((String) hmResult.get("appStatusCode"));
		checkUserResponse.setAppStatusMsg((String) hmResult.get("appStatusMsg"));
		checkUserResponse.setTransactionName("CheckUserIdAvailability");
		checkUserResponse.setAppInfo((String) hmResult.get("appInfo"));
		checkUserResponse.setAppCategoryCode((String) hmResult.get("appCategoryCode"));
		checkUserResponse.setErrors(new ServiceException(errorMessage, appInfo).getError());
		checkUserResponse.setIdpTraceId(stIdpTraceId);
		// when ERROR_ID_UNAVAILABLE, LinkedFNUserStatus will get populated
		// other scenario's will be null
		checkUserResponse.setLinkedFNUserStatus(linkedFNUserStatus);

		return checkUserResponse;

	}


	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating a CheckUserIdAvailabilityResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - CommonDefs.DOMAIN: The domain.
	 * - "idp-trace-id": The trace ID for the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns a CheckUserIdAvailabilityResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return CheckUserIdAvailabilityResponse A CheckUserIdAvailabilityResponse object representing the response to be sent back to the client.
	 */
	public static CheckUserIdAvailabilityResponse generateCheckUserResponse(Map<String, Object> hmResponse) {

		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stDomain = (String) hmResponse.get(CommonDefs.DOMAIN);
		String stIdpTraceId=(String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);

		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		int appStatusCode = Integer.parseInt(stAppStatusCode);
		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			// populating suggest list
			List<SuggestHandle> suggestList = new ArrayList();
			ArrayList alSuggestList = (ArrayList) hmResponse.get(CommonDefs.SUGGESTLIST);
			for(int k=0; k<alSuggestList.size(); k++){

				HashMap temp = (HashMap) alSuggestList.get(k);
				SuggestHandle suggestHandle = new SuggestHandle();
				suggestHandle.setSuggest(temp.get(CommonDefs.SUGGEST).toString());
				suggestList.add(suggestHandle);
			}
			return checkUserSuccessResponse(appStatusCode, stAppInfo, stDomain, suggestList,stIdpTraceId);
		} else {
			// populating LinkedFnUserStatus when appStatusMsg is ERR_INVALID_DATA and
			// stLinkedFnUserStatus is getting populated from the helper
			// changes by pm675e:PID#400970d linkedFNUserStatus is returned
			// ERR_ID_UNAVAILABLE when is thrown
			String stLinkedFnUserStatus = null;
			String appStatusMsg = (String) hmResponse.get("appStatusMsg");
			if(appStatusMsg != null && "ERR_ID_UNAVAILABLE".equals(appStatusMsg)){
				stLinkedFnUserStatus = (String) hmResponse.get(CommonDefs.LINKED_FN_USER_STATUS);
			}
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE + appStatusCode);
			return checkUserErrorResponse(appStatusCode, stAppInfo, errMsg, stLinkedFnUserStatus,stIdpTraceId);

		}

	}

	private static ChangeUserNameResponse changeUserNameSuccessResponse(int appStatusCode, String appInfo,String stIdpTraceId) {
		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		ChangeUserNameResponse changeUserNameResponse = new ChangeUserNameResponse();
		changeUserNameResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		changeUserNameResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		changeUserNameResponse.setTransactionName("ChangeUserName");
		changeUserNameResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		changeUserNameResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		changeUserNameResponse.setIdpTraceId(stIdpTraceId);
		return changeUserNameResponse;
	}

	private static ChangeUserNameResponse changeUserNameErrorResponse(int appStatusCode, String appInfo,
																	  ErrorMessages errorMessage, String stIdpTraceId) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		ChangeUserNameResponse changeUserNameResponse = new ChangeUserNameResponse();
		changeUserNameResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		changeUserNameResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		changeUserNameResponse.setTransactionName("ChangeUserName");
		changeUserNameResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		changeUserNameResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		changeUserNameResponse.setErrors(new ServiceException(errorMessage, appInfo).getError());
		changeUserNameResponse.setIdpTraceId(stIdpTraceId);

		return changeUserNameResponse;

	}

	private static CheckAccessIdMergeEligibilityResponse checkAccessIdMergeEligibilitySuccessResponse(
			int appStatusCode, String appInfo, String stIdpTraceId) {

		HashMap<String, Object> hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		CheckAccessIdMergeEligibilityResponse checkAccessIdMergeEligibilityResponse = new CheckAccessIdMergeEligibilityResponse();
		checkAccessIdMergeEligibilityResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		checkAccessIdMergeEligibilityResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		checkAccessIdMergeEligibilityResponse.setTransactionName("CheckAccessIdMergeEligibility");
		checkAccessIdMergeEligibilityResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		checkAccessIdMergeEligibilityResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		checkAccessIdMergeEligibilityResponse.setIdpTraceId(stIdpTraceId);
		return checkAccessIdMergeEligibilityResponse;
	}

	/**
	 * Generates a CheckAccessIdMergeEligibilityResponse in case of error scenarios.
	 * This method creates a CheckAccessIdMergeEligibilityResponse object based on the provided status code, additional information,
	 * error message, and trace ID. It uses the makeCategoryMap method of the CommonErrorMap class to create a HashMap
	 * containing the response details, and sets the fields of the CheckAccessIdMergeEligibilityResponse object using the values from the HashMap.
	 *
	 * @param appStatusCode The status code of the operation.
	 * @param appInfo Additional information about the operation.
	 * @param errorMessage An ErrorMessages object representing the error message.
	 * @param stIdpTraceId The trace ID for the operation.
	 * @return CheckAccessIdMergeEligibilityResponse A CheckAccessIdMergeEligibilityResponse object representing the error response to be sent back to the client.
	 */
	private static CheckAccessIdMergeEligibilityResponse checkAccessIdMergeEligibilityErrorResponse(int appStatusCode, String appInfo,
																									ErrorMessages errorMessage, String stIdpTraceId) {

		HashMap<String,Object> hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		CheckAccessIdMergeEligibilityResponse checkAccessIdMergeEligibilityResponse = new CheckAccessIdMergeEligibilityResponse();
		checkAccessIdMergeEligibilityResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		checkAccessIdMergeEligibilityResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		checkAccessIdMergeEligibilityResponse.setTransactionName("CheckAccessIdMergeEligibility");
		checkAccessIdMergeEligibilityResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		checkAccessIdMergeEligibilityResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		checkAccessIdMergeEligibilityResponse.setErrors(new ServiceException(errorMessage, appInfo).getError());
		checkAccessIdMergeEligibilityResponse.setIdpTraceId(stIdpTraceId);
		return checkAccessIdMergeEligibilityResponse;
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating a ChangeUserNameResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - "idp-trace-id": The trace ID for the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns a ChangeUserNameResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return ChangeUserNameResponse A ChangeUserNameResponse object representing the response to be sent back to the client.
	 */

	public static ChangeUserNameResponse generateChangeUserNameResponse(Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

		int appStatusCode = Integer.parseInt(stAppStatusCode);
		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			return changeUserNameSuccessResponse(appStatusCode, stAppInfo, stIdpTraceId);
		} else {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE+stAppStatusCode);
			return changeUserNameErrorResponse(appStatusCode, stAppInfo, errMsg, stIdpTraceId);
		}
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating a CheckAccessIdMergeEligibilityResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - "idp-trace-id": The trace ID for the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns a CheckAccessIdMergeEligibilityResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return CheckAccessIdMergeEligibilityResponse A CheckAccessIdMergeEligibilityResponse object representing the response to be sent back to the client.
	 */
	public static CheckAccessIdMergeEligibilityResponse generateCheckAccessIdMergeEligibilityResponse(
			Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

		int appStatusCode = Integer.parseInt(stAppStatusCode);
		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			return checkAccessIdMergeEligibilitySuccessResponse(appStatusCode, stAppInfo, stIdpTraceId);
		} else {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE + stAppStatusCode);
			return checkAccessIdMergeEligibilityErrorResponse(appStatusCode, stAppInfo, errMsg, stIdpTraceId);
		}
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating a MergeUserAccessIdResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - "idp-trace-id": The trace ID for the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns a MergeUserAccessIdResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return MergeUserAccessIdResponse A MergeUserAccessIdResponse object representing the response to be sent back to the client.
	 */
	public static MergeUserAccessIdResponse generateMergeUserAccessIdResponse(Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

		int appStatusCode = Integer.parseInt(stAppStatusCode);
		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			return mergeUserAccessIdSuccessResponse(appStatusCode, stAppInfo, stIdpTraceId);
		} else {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE +stAppStatusCode);
			return mergeUserAccessIdErrorResponse(appStatusCode, stAppInfo, errMsg, stIdpTraceId);
		}
	}

	/**
	 * Generates a MergeUserAccessIdResponse in case of success scenarios.
	 * This method creates a MergeUserAccessIdResponse object based on the provided status code, additional information,
	 * and trace ID. It uses the makeCategoryMap method of the CommonErrorMap class to create a HashMap
	 * containing the response details, and sets the fields of the MergeUserAccessIdResponse object using the values from the HashMap.
	 *
	 * @param appStatusCode The status code of the operation.
	 * @param appInfo Additional information about the operation.
	 * @param stIdpTraceId The trace ID for the operation.
	 * @return MergeUserAccessIdResponse A MergeUserAccessIdResponse object representing the successful response to be sent back to the client.
	 */
	private static MergeUserAccessIdResponse mergeUserAccessIdSuccessResponse(int appStatusCode, String appInfo,String stIdpTraceId) {
		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		MergeUserAccessIdResponse mergeUserAccessIdResponse = new MergeUserAccessIdResponse();
		mergeUserAccessIdResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		mergeUserAccessIdResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		mergeUserAccessIdResponse.setTransactionName("MergeUserAccessId");
		mergeUserAccessIdResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		mergeUserAccessIdResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		mergeUserAccessIdResponse.setIdpTraceId(stIdpTraceId);
		return mergeUserAccessIdResponse;
	}

	/**
	 * Generates a MergeUserAccessIdResponse in case of error scenarios.
	 * This method creates a MergeUserAccessIdResponse object based on the provided status code, additional information,
	 * error message, and trace ID. It uses the makeCategoryMap method of the CommonErrorMap class to create a HashMap
	 * containing the response details, and sets the fields of the MergeUserAccessIdResponse object using the values from the HashMap.
	 *
	 * @param appStatusCode The status code of the operation.
	 * @param appInfo Additional information about the operation.
	 * @param errorMessage An ErrorMessages object representing the error message.
	 * @param stIdpTraceId The trace ID for the operation.
	 * @return MergeUserAccessIdResponse A MergeUserAccessIdResponse object representing the error response to be sent back to the client.
	 */
	private static MergeUserAccessIdResponse mergeUserAccessIdErrorResponse(int appStatusCode, String appInfo,
																			ErrorMessages errorMessage, String stIdpTraceId) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		MergeUserAccessIdResponse mergeUserAccessIdResponse = new MergeUserAccessIdResponse();
		mergeUserAccessIdResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		mergeUserAccessIdResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		mergeUserAccessIdResponse.setTransactionName("MergeUserAccessId");
		mergeUserAccessIdResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		mergeUserAccessIdResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		mergeUserAccessIdResponse.setErrors(new ServiceException(errorMessage, appInfo).getError());
		mergeUserAccessIdResponse.setIdpTraceId(stIdpTraceId);

		return mergeUserAccessIdResponse;

	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is a utility method that converts an object of any type to a Map.
	 * The method uses the Jackson library's ObjectMapper to perform the conversion.
	 * The method takes a single parameter, which is the object to be converted.
	 * The method returns a Map where the keys are the field names of the object and the values are the corresponding field values.
	 * The method does not handle any exceptions that may be thrown during the conversion process.
	 *
	 * @param <T> The type of the object to be converted.
	 * @param t The object to be converted.
	 * @return Map<String, Object> A Map representation of the input object.
	 */
	public static <T> Map<String, Object> objectToMap(T t) {

		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		Map<String, Object> map = mapper.convertValue(t, new TypeReference<Map<String, Object>>() {
		});
		return map;
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is a utility method that generates a HashMap representing a system error.
	 * The method takes a single parameter, which is additional information about the operation.
	 * The method uses the makeCategoryMap method of the CommonErrorMap class to create a HashMap.
	 * The HashMap contains the following keys:
	 * - CommonDefs.COMMON_APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_STATUS_MSG: The status message of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - CommonDefs.COMMON_APP_CATEGORY_CODE: The category code of the operation.
	 * The method returns the HashMap.
	 *
	 * @param appInfo Additional information about the operation.
	 * @return Map<String, Object> A HashMap representing a system error.
	 */

	public static Map<String, Object> sysErrorHashMap(String appInfo) {
		Map<String, Object> hmResult = null;
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, appInfo);
		hmResult.put("ErrorEnum", ErrorMessages.MS_MPSYS_BE_602);
		return hmResult;
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is a utility method that checks if a given Map is null or empty.
	 * The method takes a Map as a parameter.
	 * The method returns a boolean value. It returns true if the Map is null or empty, and false otherwise.
	 *
	 * @param m The Map to be checked.
	 * @return boolean A boolean value indicating whether the Map is null or empty.
	 */
	public static boolean isCollectionMapNullOrEmpty(final Map<?, ?> m) {
		return m == null || m.isEmpty();
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is a utility method that converts an object to a JSON string representation.
	 * The method uses the Jackson library's ObjectMapper to perform the conversion.
	 * The method takes a single parameter, which is the object to be converted.
	 * If the conversion is successful, the method returns a JSON string representation of the object.
	 * If a JsonProcessingException occurs during the conversion, the method logs an error message and returns the string representation of the object.
	 *
	 * @param obj The object to be converted to a JSON string.
	 * @return String A JSON string representation of the object, or the string representation of the object if a JsonProcessingException occurs.
	 */
	public static String objectToString(Object obj) {

		if(obj == null)
			return null;
		ObjectMapper mapper = new ObjectMapper();
		try {
			return sanitizeForLog(mapper.writeValueAsString(obj));
		} catch (JsonProcessingException e) {
			logger.error("JsonProcessingException while processing object {} to string: {}", sanitizeForLog(obj.getClass().getName()), sanitizeForLog(e.getMessage()));
		}
		return sanitizeForLog(obj.toString());
	}

	/**
	 * Populates the fields of an object using the values from a HashMap.
	 * This method creates a new instance of the specified class, retrieves its fields,
	 * and sets the field values using the corresponding values from the provided HashMap.
	 * If the value in the HashMap is of type Long or Character, it converts the value to a String before setting it.
	 *
	 * @param obj The object to be populated.
	 * @param className The class of the object to be populated.
	 * @param hashMap A HashMap containing the field names and their corresponding values.
	 * @return Object The populated object.
	 * @throws InstantiationException If the class object cannot be instantiated.
	 * @throws IllegalAccessException If the class or its nullary constructor is not accessible.
	 * @throws ClassNotFoundException If the class cannot be located.
	 */
	private static Object populateFields(Object obj, Class className, HashMap hashMap) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		obj = Class.forName(className.getName()).newInstance();
		Field[] fields = obj.getClass().getDeclaredFields();
		PropertyAccessor accessor = PropertyAccessorFactory.forBeanPropertyAccess(obj);
		for(Field field: fields) {
			if(hashMap.get(field.getName()) != null) {
				if(hashMap.get(field.getName()) instanceof Long || hashMap.get(field.getName()) instanceof Character)
					accessor.setPropertyValue(field.getName(), hashMap.get(field.getName()).toString());
				else
					accessor.setPropertyValue(field.getName(), (String) hashMap.get(field.getName()));
			}
		}
		return obj;
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is a utility method that generates a random number within a specified upper limit.
	 * The method uses the SecureRandom class from the java.security package to generate the random number.
	 * The method takes a single parameter, which is the upper limit for the random number.
	 * The method returns an integer which is the generated random number.
	 *
	 * @param upperLimit The upper limit for the random number.
	 * @return int A random number within the specified upper limit.
	 */
	public static int generateRandomNum(int upperLimit)
	{
		SecureRandom rnd = new SecureRandom();
		return rnd.nextInt(upperLimit);
	}


	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating an UpdateUserFraudResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - "idp-trace-id": The trace ID for the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns an UpdateUserFraudResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return UpdateUserFraudResponse An UpdateUserFraudResponse object representing the response to be sent back to the client.
	 */
	public static UpdateUserFraudResponse generateUpdateUserFraudResponse(Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId=(String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

		int iAppStatusCode = Integer.parseInt(stAppStatusCode);
		HashMap hmResult = CommonErrorMap.makeCategoryMap(iAppStatusCode, stAppInfo);

		UpdateUserFraudResponse updateUserFraudResponse = new UpdateUserFraudResponse();
		updateUserFraudResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		updateUserFraudResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		updateUserFraudResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		updateUserFraudResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		updateUserFraudResponse.setIdpTraceId(stIdpTraceId);

		if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE+stAppStatusCode);
			updateUserFraudResponse.setErrors(new ServiceException(errMsg, stAppInfo).getError());
		}
		return updateUserFraudResponse;

	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating an UpdateUserContactCBRResponse in case of error scenarios.
	 * The method takes four parameters: the status code of the operation, additional information about the operation,
	 * an ErrorMessages object representing the error message, and the trace ID for the operation.
	 * The method uses the status code and additional information to create a HashMap using the makeCategoryMap method of the CommonErrorMap class.
	 * The HashMap contains the following keys:
	 * - CommonDefs.COMMON_APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_STATUS_MSG: The status message of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - CommonDefs.COMMON_APP_CATEGORY_CODE: The category code of the operation.
	 * The method then creates a new UpdateUserContactCBRResponse object and sets its fields using the values from the HashMap and the other parameters.
	 * The method returns the UpdateUserContactCBRResponse object.
	 *
	 * @param appStatusCode The status code of the operation.
	 * @param appInfo Additional information about the operation.
	 * @param errorMessage An ErrorMessages object representing the error message.
	 * @param stIdpTraceId The trace ID for the operation.
	 * @return UpdateUserContactCBRResponse An UpdateUserContactCBRResponse object representing the response to be sent back to the client.
	 */
	public static UpdateUserContactCBRResponse updateUserContactCBRErrorResponse(int appStatusCode, String appInfo, ErrorMessages errorMessage, String stIdpTraceId) {
		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		UpdateUserContactCBRResponse updateUserContactCBRResponse = new UpdateUserContactCBRResponse();
		updateUserContactCBRResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		updateUserContactCBRResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		updateUserContactCBRResponse.setTransactionName(CommonDefs.UPDATE_USER_CONTACT_CBR_TRANSACTION_NAME);
		updateUserContactCBRResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		updateUserContactCBRResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		updateUserContactCBRResponse.setErrors(new ServiceException(errorMessage, appInfo).getError());
		updateUserContactCBRResponse.setIdpTraceId(stIdpTraceId);

		return updateUserContactCBRResponse;
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating an UpdateUserContactCBRResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - "idp-trace-id": The trace ID for the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns an UpdateUserContactCBRResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return UpdateUserContactCBRResponse An UpdateUserContactCBRResponse object representing the response to be sent back to the client.
	 */
	public static UpdateUserContactCBRResponse generateUpdateUserContactCBRResponse(Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stGuid = (String) hmResponse.get(CommonDefs.GUID);
		String stIdpTraceId=(String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);

		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		int appStatusCode = Integer.parseInt(stAppStatusCode);
		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			return updateUserContactCBRSuccessResponse(appStatusCode, stAppInfo, stGuid,stIdpTraceId);
		} else {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE+stAppStatusCode);
			return updateUserContactCBRErrorResponse(appStatusCode, stAppInfo, errMsg, stIdpTraceId);

		}
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating a successful UpdateUserContactCBRResponse.
	 * The method takes four parameters: the status code of the operation, additional information about the operation,
	 * the unique identifier for the user, and the trace ID for the operation.
	 * The method uses the status code and additional information to create a HashMap using the makeCategoryMap method of the CommonErrorMap class.
	 * The HashMap contains the following keys:
	 * - CommonDefs.COMMON_APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_STATUS_MSG: The status message of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - CommonDefs.COMMON_APP_CATEGORY_CODE: The category code of the operation.
	 * The method then creates a new UpdateUserContactCBRResponse object and sets its fields using the values from the HashMap and the other parameters.
	 * The method returns the UpdateUserContactCBRResponse object.
	 *
	 * @param appStatusCode The status code of the operation.
	 * @param appInfo Additional information about the operation.
	 * @param stGuid The unique identifier for the user.
	 * @param stIdpTraceId The trace ID for the operation.
	 * @return UpdateUserContactCBRResponse An UpdateUserContactCBRResponse object representing the response to be sent back to the client.
	 */
	private static UpdateUserContactCBRResponse updateUserContactCBRSuccessResponse(int appStatusCode, String appInfo, String stGuid, String stIdpTraceId) {
		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		UpdateUserContactCBRResponse updateUserContactCBRResponse = new UpdateUserContactCBRResponse();
		updateUserContactCBRResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		updateUserContactCBRResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		updateUserContactCBRResponse.setTransactionName(CommonDefs.UPDATE_USER_CONTACT_CBR_TRANSACTION_NAME);
		updateUserContactCBRResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		updateUserContactCBRResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		updateUserContactCBRResponse.setIdpTraceId(stIdpTraceId);
		return updateUserContactCBRResponse;
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating an ExtUserResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - "idp-trace-id": The trace ID for the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns an ExtUserResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return ExtUserResponse An ExtUserResponse object representing the response to be sent back to the client.
	 */
	public static ExtUserResponse generateExtUserResponse(Map<String, Object> hmResponse) {

		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		String stGuid = (String) hmResponse.get(CommonDefs.GUID);
		String stTransactionName = (String) hmResponse.get(CommonDefs.TRANSACTION_NAME);
		String stActivatedInd = (String) hmResponse.get(CommonDefs.ACTIVATED_IND);
		int iAppStatusCode = Integer.parseInt(stAppStatusCode);
		HashMap<String,Object> hmResult = CommonErrorMap.makeCategoryMap(iAppStatusCode, stAppInfo);

		ExtUserResponse extUserResponse = new ExtUserResponse();
		extUserResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		extUserResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		extUserResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		extUserResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		extUserResponse.setIdpTraceId(stIdpTraceId);
		extUserResponse.setGuid(stGuid);
		if(StringUtils.isNotBlank(stActivatedInd)
				&& ProfileOrchestrationConstants.ADD_EXTUSER_TRANSACTION_NAME.equalsIgnoreCase(stTransactionName)) {
			extUserResponse.setActivatedInd(stActivatedInd);
		}

		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			return extUserSuccessResponse(iAppStatusCode, stAppInfo, stIdpTraceId, stTransactionName);
		}
		else {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE + stAppStatusCode);
			return extUserErrorResponse(iAppStatusCode, stAppInfo, errMsg, stIdpTraceId, stTransactionName, stGuid, stActivatedInd);
		}
	}

	/**
	 * Generates a successful ExtUserResponse.
	 * This method creates an ExtUserResponse object based on the provided status code, additional information,
	 * trace ID, and transaction name. It uses the makeCategoryMap method of the CommonErrorMap class to create a HashMap
	 * containing the response details, and sets the fields of the ExtUserResponse object using the values from the HashMap.
	 *
	 * @param appStatusCode The status code of the operation.
	 * @param appInfo Additional information about the operation.
	 * @param stIdpTraceId The trace ID for the operation.
	 * @param stTransactionName The name of the transaction.
	 * @return ExtUserResponse An ExtUserResponse object representing the successful response to be sent back to the client.
	 */
	private static  ExtUserResponse extUserSuccessResponse(int appStatusCode, String appInfo, String stIdpTraceId, String stTransactionName) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);
		ExtUserResponse extUserResponse = new ExtUserResponse();
		extUserResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		extUserResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		extUserResponse.setTransactionName(stTransactionName);
		extUserResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		extUserResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		extUserResponse.setIdpTraceId(stIdpTraceId);
		return extUserResponse;
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating an ExtUserResponse in case of error scenarios.
	 * The method takes six parameters: the status code of the operation, additional information about the operation,
	 * an ErrorMessages object representing the error message, the trace ID for the operation, the transaction name, and the unique identifier for the user.
	 * The method uses the status code and additional information to create a HashMap using the makeCategoryMap method of the CommonErrorMap class.
	 * The HashMap contains the following keys:
	 * - CommonDefs.COMMON_APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_STATUS_MSG: The status message of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - CommonDefs.COMMON_APP_CATEGORY_CODE: The category code of the operation.
	 * The method then creates a new ExtUserResponse object and sets its fields using the values from the HashMap and the other parameters.
	 * The method returns the ExtUserResponse object.
	 *
	 * @param appStatusCode The status code of the operation.
	 * @param appInfo Additional information about the operation.
	 * @param errorMessage An ErrorMessages object representing the error message.
	 * @param stIdpTraceId The trace ID for the operation.
	 * @param stTransactionName The transaction name.
	 * @param stGuid The unique identifier for the user.
	 * @return ExtUserResponse An ExtUserResponse object representing the response to be sent back to the client.
	 */
	public static ExtUserResponse extUserErrorResponse(int appStatusCode, String appInfo, ErrorMessages errorMessage, String stIdpTraceId, String stTransactionName, String stGuid, String activatedInd) {

		HashMap<String, Object> hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);
		ExtUserResponse addExtUserErrorResponse = new ExtUserResponse();
		addExtUserErrorResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		addExtUserErrorResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		addExtUserErrorResponse.setTransactionName(stTransactionName);
		addExtUserErrorResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		addExtUserErrorResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		addExtUserErrorResponse.setErrors(new ServiceException(errorMessage, appInfo).getError());
		addExtUserErrorResponse.setIdpTraceId(stIdpTraceId);
		addExtUserErrorResponse.setGuid(stGuid);
		addExtUserErrorResponse.setActivatedInd(activatedInd);
		return addExtUserErrorResponse;
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating a ValidateUserCredentialsResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - "idp-trace-id": The trace ID for the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns a ValidateUserCredentialsResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return ValidateUserCredentialsResponse A ValidateUserCredentialsResponse object representing the response to be sent back to the client.
	 */
	public static ValidateUserCredentialsResponse generateValidateUserCredentialsResponse(Map<String, Object> hmResponse) {

		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

		int iAppStatusCode = Integer.parseInt(stAppStatusCode);
		HashMap hmResult = CommonErrorMap.makeCategoryMap(iAppStatusCode, stAppInfo);

		ValidateUserCredentialsResponse validateUserCredentialsResponse = new ValidateUserCredentialsResponse();
		validateUserCredentialsResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		validateUserCredentialsResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		validateUserCredentialsResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		validateUserCredentialsResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		validateUserCredentialsResponse.setIdpTraceId(stIdpTraceId);

		if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE + stAppStatusCode);
			validateUserCredentialsResponse.setErrors(new ServiceException(errMsg, stAppInfo).getError());
		}
		return validateUserCredentialsResponse;
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating a RegisterEmailUserResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - "idp-trace-id": The trace ID for the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns a RegisterEmailUserResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return RegisterEmailUserResponse A RegisterEmailUserResponse object representing the response to be sent back to the client.
	 */
	public static RegisterEmailUserResponse generateRegisterEmailUserResponse(Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

		int iAppStatusCode = Integer.parseInt(stAppStatusCode);
		HashMap hmResult = CommonErrorMap.makeCategoryMap(iAppStatusCode, stAppInfo);

		RegisterEmailUserResponse registerEmailUserResponse = new RegisterEmailUserResponse();
		registerEmailUserResponse
				.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		registerEmailUserResponse
				.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		registerEmailUserResponse.setAppInfo(stAppInfo);
		registerEmailUserResponse
				.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		registerEmailUserResponse.setIdpTraceId(stIdpTraceId);

		if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {

			if (hmResponse.get(CommonDefs.SUGGESTLIST) != null) {
				Map hmSuggestHandles = (HashMap) hmResponse.get(CommonDefs.SUGGESTLIST);
				if (hmSuggestHandles != null) {
					registerEmailUserResponse
							.setSuggestedHandle1((String) hmSuggestHandles.get(CommonDefs.SUGGESTED_HANDLE + 1));
					registerEmailUserResponse
							.setSuggestedHandle2((String) hmSuggestHandles.get(CommonDefs.SUGGESTED_HANDLE + 2));
					registerEmailUserResponse
							.setSuggestedHandle3((String) hmSuggestHandles.get(CommonDefs.SUGGESTED_HANDLE + 3));
				}
			}

			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE + stAppStatusCode);
			registerEmailUserResponse.setErrors(new ServiceException(errMsg, stAppInfo).getError());
		}
		return registerEmailUserResponse;
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating a TransactionRateLimitResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - "idp-trace-id": The trace ID for the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns a TransactionRateLimitResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return TransactionRateLimitResponse A TransactionRateLimitResponse object representing the response to be sent back to the client.
	 */
	public static TransactionRateLimitResponse generateTxnRateLimitStatusResponse(Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

		int iAppStatusCode = Integer.parseInt(stAppStatusCode);
		HashMap hmResult = CommonErrorMap.makeCategoryMap(iAppStatusCode, stAppInfo);

		TransactionRateLimitResponse txnRateLimitResponse = new TransactionRateLimitResponse();
		txnRateLimitResponse
				.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		txnRateLimitResponse
				.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		txnRateLimitResponse.setAppInfo(stAppInfo);
		txnRateLimitResponse
				.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		txnRateLimitResponse.setIdpTraceId(stIdpTraceId);

		if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE + stAppStatusCode);
			txnRateLimitResponse.setErrors(new ServiceException(errMsg, stAppInfo).getError());
		}
		return txnRateLimitResponse;
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating a LinkMemberResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - "idp-trace-id": The trace ID for the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns a LinkMemberResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return LinkMemberResponse A LinkMemberResponse object representing the response to be sent back to the client.
	 */
	public static LinkMemberResponse generateLinkMemberResponse(Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

		int iAppStatusCode = Integer.parseInt(stAppStatusCode);
		HashMap hmResult = CommonErrorMap.makeCategoryMap(iAppStatusCode, stAppInfo);

		LinkMemberResponse linkMemberResponse = new LinkMemberResponse();
		linkMemberResponse
				.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		linkMemberResponse
				.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		linkMemberResponse.setAppInfo(stAppInfo);
		linkMemberResponse
				.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		linkMemberResponse.setIdpTraceId(stIdpTraceId);

		if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE + stAppStatusCode);
			return generateLinkMemberErrorResponse(iAppStatusCode, stAppInfo, errMsg, stIdpTraceId);

		}
		return linkMemberResponse;
	}

	/**
	 * Generates a LinkMemberResponse in case of error scenarios.
	 * This method creates a LinkMemberResponse object based on the provided status code, additional information,
	 * error message, and trace ID. It uses the makeCategoryMap method of the CommonErrorMap class to create a HashMap
	 * containing the response details, and sets the fields of the LinkMemberResponse object using the values from the HashMap.
	 *
	 * @param appStatusCode The status code of the operation.
	 * @param appInfo Additional information about the operation.
	 * @param errorMessage An ErrorMessages object representing the error message.
	 * @param stIdpTraceId The trace ID for the operation.
	 * @return LinkMemberResponse A LinkMemberResponse object representing the error response to be sent back to the client.
	 */
	private static LinkMemberResponse generateLinkMemberErrorResponse(int appStatusCode, String appInfo,
																	  ErrorMessages errorMessage, String stIdpTraceId) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		LinkMemberResponse linkMemberResponse = new LinkMemberResponse();
		linkMemberResponse.setTransactionName(ProfileOrchestrationConstants.LINK_MEMBER_TRANSACTION_NAME);
		linkMemberResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		linkMemberResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		linkMemberResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		linkMemberResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		linkMemberResponse.setErrors(new ServiceException(errorMessage, appInfo).getError());
		linkMemberResponse.setIdpTraceId(stIdpTraceId);
		return linkMemberResponse;

	}


	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating a CommonResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - "idp-trace-id": The trace ID for the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns a CommonResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return CommonResponse A CommonResponse object representing the response to be sent back to the client.
	 */
	//to be used when we don't want to return any extra fields except the basic ones
	public static CommonResponse generateCommonResponse(Map<String, Object> hmResponse) {

		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) Optional.ofNullable(hmResponse.get("idp-trace-id")).orElse(getTraceIdFromContextMap());

		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		int appStatusCode = Integer.parseInt(stAppStatusCode);
		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			return (CommonResponse) commonSuccessResponse(appStatusCode, stAppInfo, stIdpTraceId);
		} else {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE + stAppStatusCode);
			return (CommonResponse) commonErrorResponse(appStatusCode, stAppInfo, errMsg, stIdpTraceId);

		}
	}

	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is a utility method that generates a CommonResponse object in case of error scenarios.
	 * The method takes four parameters: the status code of the operation, additional information about the operation,
	 * an ErrorMessages object representing the error message, and the trace ID for the operation.
	 * The method uses the status code and additional information to create a HashMap using the makeCategoryMap method of the CommonErrorMap class.
	 * The HashMap contains the following keys:
	 * - CommonDefs.COMMON_APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_STATUS_MSG: The status message of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - CommonDefs.COMMON_APP_CATEGORY_CODE: The category code of the operation.
	 * The method then creates a new CommonResponse object and sets its fields using the values from the HashMap and the other parameters.
	 * The method returns the CommonResponse object.
	 *
	 * @param appStatusCode The status code of the operation.
	 * @param stAppInfo Additional information about the operation.
	 * @param errorMessage An ErrorMessages object representing the error message.
	 * @param stIdpTraceId The trace ID for the operation.
	 * @return Object A CommonResponse object representing the response to be sent back to the client.
	 */
	////to be used as common method for creating common error response fields
	private static Object commonErrorResponse(int appStatusCode, String stAppInfo,
											  ErrorMessages errorMessage, String stIdpTraceId) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, stAppInfo);

		CommonResponse commonResponse = new CommonResponse();
		commonResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		commonResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		commonResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		commonResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		commonResponse.setErrors(new ServiceException(errorMessage, stAppInfo).getError());
		commonResponse.setIdpTraceId(stIdpTraceId);

		return commonResponse;

	}

	//to be used as common method for creating common success response fields
	private static Object commonSuccessResponse(int appStatusCode, String stAppInfo, String stIdpTraceId) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, stAppInfo);

		CommonResponse commonResponse = new CommonResponse();
		commonResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		commonResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		commonResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		commonResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		commonResponse.setIdpTraceId(stIdpTraceId);
		return commonResponse;
	}

	/**
	 * Generates an AddSecMemberIdResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - "idp-trace-id": The trace ID for the operation.
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns an AddSecMemberIdResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return AddSecMemberIdResponse An AddSecMemberIdResponse object representing the response to be sent back to the client.
	 */
	public static AddSecMemberIdResponse generateAddSecMemberIdResponse(Map<String, Object> hmResponse) {

		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

		int iAppStatusCode = Integer.parseInt(stAppStatusCode);
		HashMap hmResult = CommonErrorMap.makeCategoryMap(iAppStatusCode, stAppInfo);

		AddSecMemberIdResponse addSecMemberIdResponse = new AddSecMemberIdResponse();
		addSecMemberIdResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		addSecMemberIdResponse.setIdpTraceId(stIdpTraceId);

		if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE + stAppStatusCode);
			addSecMemberIdResponse.setErrors(new ServiceException(errMsg, stAppInfo).getError());
			Map<String, Object> hmSuggestHandles = (Map<String, Object>) hmResponse.get(CommonDefs.SUGGESTLIST);
			if (hmResponse.get(CommonDefs.SUGGESTLIST) != null) {
				if (hmSuggestHandles != null) {
					addSecMemberIdResponse.setSuggestedUserId1((String) hmSuggestHandles.get(CommonDefs.SUGGESTED_HANDLE + 1));
					addSecMemberIdResponse.setSuggestedUserId2((String) hmSuggestHandles.get(CommonDefs.SUGGESTED_HANDLE + 2));
					addSecMemberIdResponse.setSuggestedUserId3((String) hmSuggestHandles.get(CommonDefs.SUGGESTED_HANDLE + 3));
				}
			}
		}
		return addSecMemberIdResponse;
	}

	public static UpgSecMemberIdResponse generateUpgSecMemberIdResponse(Map<String, Object> hmResponse) {

		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		int iAppStatusCode = Integer.parseInt(stAppStatusCode);

		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			return upgradeSecMemberIdSuccessResponse(iAppStatusCode, stAppInfo, stIdpTraceId);
		}
		else {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE+stAppStatusCode);
			return upgradeSecMemberIdErrorResponse(iAppStatusCode, stAppInfo, errMsg,stIdpTraceId);
		}
	}

	private static UpgSecMemberIdResponse upgradeSecMemberIdSuccessResponse(int appStatusCode, String appInfo, String stIdpTraceId) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		UpgSecMemberIdResponse upgradeSecMemberIdResponse = new UpgSecMemberIdResponse();
		upgradeSecMemberIdResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		upgradeSecMemberIdResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		upgradeSecMemberIdResponse.setTransactionName(ProfileOrchestrationConstants.UPG_SEC_MEMBERID_TRANSACTION_NAME);
		upgradeSecMemberIdResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		upgradeSecMemberIdResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		upgradeSecMemberIdResponse.setIdpTraceId(stIdpTraceId);
		return upgradeSecMemberIdResponse;

	}

	private static UpgSecMemberIdResponse upgradeSecMemberIdErrorResponse(int appStatusCode, String appInfo,
																		  ErrorMessages errorMessage, String stIdpTraceId) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		UpgSecMemberIdResponse upgradeSecMemberIdResponse = new UpgSecMemberIdResponse();
		upgradeSecMemberIdResponse.setTransactionName(ProfileOrchestrationConstants.UPG_SEC_MEMBERID_TRANSACTION_NAME);
		upgradeSecMemberIdResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		upgradeSecMemberIdResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		upgradeSecMemberIdResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		upgradeSecMemberIdResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		upgradeSecMemberIdResponse.setErrors(new ServiceException(errorMessage, appInfo).getError());
		upgradeSecMemberIdResponse.setIdpTraceId(stIdpTraceId);
		return upgradeSecMemberIdResponse;

	}

	/**
	 * Calculates the elapsed time in seconds from the given start time.
	 * This method computes the difference between the current system time and the provided start time,
	 * formats the elapsed time in seconds with milliseconds precision, and returns it as a string.
	 *
	 * @param startTime The start time in milliseconds.
	 * @return String The elapsed time in seconds with milliseconds precision.
	 */
	public static String getElapsedTimeInSecs(long startTime) {

		StringBuffer sElapsedTime = new StringBuffer();

		long diff = (System.currentTimeMillis() - startTime);
		long ms = diff % 1000;

		sElapsedTime.append(diff / 1000).append('.'); // secs.

		if (ms < 10)
			sElapsedTime.append("00").append(ms); // 3 digits ms 0 padded
		else if (ms < 100)
			sElapsedTime.append('0').append(ms);
		else
			sElapsedTime.append(ms);

		return sElapsedTime.toString();
	}

	/**
	 * This method generates an error response for the Profanity Scanner.
	 * It sets the app status code, app info, and trace ID in the response.
	 * @return ProfanityScannerResponse The response object containing the error details
	 */
	public static ProfanityScannerResponse generateProfanityScannerResponse(Map<String, Object> hmResponse) {

		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stCategoryCode = (String) hmResponse.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
		String stIdpTraceId=(String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);
		String stTransactionName=(String)hmResponse.get(CommonDefs.TRANSACTION_NAME);
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		int appStatusCode = Integer.parseInt(stAppStatusCode);
		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			return proanityScannerSuccessResponse( stIdpTraceId);
		} else {
			ErrorMessages errorMessage = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE+stAppStatusCode);
			return profanityScannerErrorResponse(appStatusCode, errorMessage,stAppInfo, stIdpTraceId,stTransactionName);

		}
	}
	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating a ProfanityScannerResponse in case of error scenarios.
	 * The method takes five parameters: the status code of the operation, an ErrorMessages object representing the error message,
	 * additional information about the operation, the trace ID for the operation, and the transaction name.
	 * The method uses the status code and additional information to create a HashMap using the makeCategoryMap method of the CommonErrorMap class.
	 * The HashMap contains the following keys:
	 * - CommonDefs.COMMON_APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_STATUS_MSG: The status message of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - CommonDefs.COMMON_APP_CATEGORY_CODE: The category code of the operation.
	 * The method then creates a new ProfanityScannerResponse object and sets its fields using the values from the HashMap and the other parameters.
	 * The method returns the ProfanityScannerResponse object.
	 *
	 * @param appStatusCode The status code of the operation.
	 * @param errorMessage An ErrorMessages object representing the error message.
	 * @param stAppInfo Additional information about the operation.
	 * @param stIdpTraceId The trace ID for the operation.
	 * @param stTransactionName The transaction name.
	 * @return ProfanityScannerResponse A ProfanityScannerResponse object representing the response to be sent back to the client.
	 */
	private static ProfanityScannerResponse profanityScannerErrorResponse(int appStatusCode, ErrorMessages errorMessage,String stAppInfo, String stIdpTraceId, String stTransactionName) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, stAppInfo);

		ProfanityScannerResponse profanityScannerResponse = new ProfanityScannerResponse();
		profanityScannerResponse.setTransactionName(stTransactionName);
		profanityScannerResponse.setIdpTraceId(stIdpTraceId);
		profanityScannerResponse.setErrors(new ServiceException(errorMessage,stAppInfo).getError());
		return profanityScannerResponse;
	}
	/**
	 * This method is part of the CommonUtilHelper class.
	 * It is responsible for generating a successful ProfanityScannerResponse.
	 * The method takes four parameters: the status code of the operation, additional information about the operation,
	 * the trace ID for the operation, and the transaction name.
	 * The method uses the status code and additional information to create a HashMap using the makeCategoryMap method of the CommonErrorMap class.
	 * The HashMap contains the following keys:
	 * - CommonDefs.COMMON_APP_STATUS_CODE: The status code of the operation.
	 * - CommonDefs.COMMON_APP_STATUS_MSG: The status message of the operation.
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - CommonDefs.COMMON_APP_CATEGORY_CODE: The category code of the operation.
	 * The method then creates a new ProfanityScannerResponse object and sets its fields using the values from the HashMap and the other parameters.
	 * The method returns the ProfanityScannerResponse object.
	 * @param stIdpTraceId The trace ID for the operation.
	 * @return ProfanityScannerResponse A ProfanityScannerResponse object representing the response to be sent back to the client.
	 */
	private static ProfanityScannerResponse proanityScannerSuccessResponse(String stIdpTraceId) {

		ProfanityScannerResponse profanityScannerResponse = new ProfanityScannerResponse();
		profanityScannerResponse.setIdpTraceId(stIdpTraceId);
		return profanityScannerResponse;
	}

	/**
	 * Generates an ResetUserPasswordResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - "idp-trace-id": The trace ID for the operation.
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns an ResetUserPasswordResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return resetUserPasswordResponse An ResetUserPasswordResponse object representing the response to be sent back to the client.
	 */
	public static ResetUserPasswordResponse generateResetUserPasswordResponse(Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		String stGeneratedPassword = (String) hmResponse.get("generatedPassword");
		String stSlid = (String) hmResponse.get(CommonDefs.SLID);
		ArrayList<LockList> alLockList = (ArrayList<LockList>) hmResponse.get(CommonDefs.LOCK_LIST);
		ResetUserPasswordResponse resetUserPasswordResponse = new ResetUserPasswordResponse();

		int iAppStatusCode = Integer.parseInt(stAppStatusCode);
		HashMap hmResult = CommonErrorMap.makeCategoryMap(iAppStatusCode, stAppInfo);

		resetUserPasswordResponse
				.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		resetUserPasswordResponse
				.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		resetUserPasswordResponse.setAppInfo(stAppInfo);
		resetUserPasswordResponse
				.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		resetUserPasswordResponse.setIdpTraceId(stIdpTraceId);
		resetUserPasswordResponse.setGeneratedPassword(stGeneratedPassword);
		resetUserPasswordResponse.setSlid(stSlid);
		if (alLockList != null && !alLockList.isEmpty()) {
			resetUserPasswordResponse.setLockList(alLockList);
		}

		if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE + stAppStatusCode);
			resetUserPasswordResponse.setErrors(new ServiceException(errMsg, stAppInfo).getError());
		}

		return resetUserPasswordResponse;
	}

	/**
	 * Generates an UpdateUserPasswordResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - "idp-trace-id": The trace ID for the operation.
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns an UpdateUserPasswordResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return updateUserPasswordResponse An UpdateUserPasswordResponse object representing the response to be sent back to the client.
	 */
	public static UpdateUserPasswordResponse generateUpdateUserPasswordResponse(Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		UpdateUserPasswordResponse 		updateUserPasswordResponse = new UpdateUserPasswordResponse();

		int iAppStatusCode = Integer.parseInt(stAppStatusCode);
		HashMap hmResult = CommonErrorMap.makeCategoryMap(iAppStatusCode, stAppInfo);

		updateUserPasswordResponse
				.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		updateUserPasswordResponse
				.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		updateUserPasswordResponse.setAppInfo(stAppInfo);
		updateUserPasswordResponse
				.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		updateUserPasswordResponse.setIdpTraceId(stIdpTraceId);

		if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE + stAppStatusCode);
			updateUserPasswordResponse.setErrors(new ServiceException(errMsg, stAppInfo).getError());
		}

		return updateUserPasswordResponse;
	}
	/**
	 * Generates an UpdatePrepaidUserPasswordResponse based on the input HashMap.
	 * The method takes a HashMap as a parameter, which contains the details of the response to be generated.
	 * The HashMap should contain the following keys:
	 * - CommonDefs.COMMON_APP_INFO: Additional information about the operation.
	 * - "idp-trace-id": The trace ID for the operation.
	 * - MPSDefs.APP_STATUS_CODE: The status code of the operation.
	 * Depending on the status code, the method redirects to specific response generation methods for success or error scenarios.
	 * The method returns an UpdatePrepaidUserPasswordResponse object which represents the response to be sent back to the client.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return UpdatePrepaidUserPasswordResponse An UpdatePrepaidUserPasswordResponse object representing the response to be sent back to the client.
	 */
	public static UpdatePrepaidUserPasswordResponse generateUpdatePrepaidUserPasswordResponse(Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId=(String) hmResponse.get("idp-trace-id");

		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		UpdatePrepaidUserPasswordResponse updatePrepaidUserPasswordResponse = new UpdatePrepaidUserPasswordResponse();

		int iAppStatusCode = Integer.parseInt(stAppStatusCode);
		HashMap hmResult = CommonErrorMap.makeCategoryMap(iAppStatusCode, stAppInfo);
		updatePrepaidUserPasswordResponse
				.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		updatePrepaidUserPasswordResponse
				.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		updatePrepaidUserPasswordResponse.setAppInfo(stAppInfo);
		updatePrepaidUserPasswordResponse
				.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		updatePrepaidUserPasswordResponse.setIdpTraceId(stIdpTraceId);

		if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			ErrorMessages errMsg =  ErrorMessages.valueOf(MS_MPSYS_BE + stAppStatusCode);
			updatePrepaidUserPasswordResponse.setErrors(new ServiceException(errMsg, stAppInfo).getError());
		}
		return updatePrepaidUserPasswordResponse;
	}
	
	/**
	 * This method decrypts an encrypted string using the AES encryption algorithm.
	 *
	 * It uses the SecretKeySpec class from the javax.crypto.spec package to create a key specification for the AES algorithm.
	 * The key specification is created using the provided AES key.
	 * The method then uses the Cipher class from the javax.crypto package to decrypt the encrypted string.
	 * The decryption is done in the AES mode.
	 *
	 * If the encrypted string is empty, the method returns an empty string.
	 * If there is an exception during the decryption, the method logs the error and returns an empty string.
	 *
	 * @param encrypted The encrypted string to be decrypted. It is a hexadecimal string.
	 * @param propAes256Key The AES key to be used for the decryption. It is a hexadecimal string.
	 * @return The decrypted string. If there is an exception during the decryption, it returns an empty string.
	 */
	public static String getAESDecryption(String encrypted, String propAes256Key) {

		logger.info("In AESDecryption method");

		try {
			if (encrypted.isEmpty()) {
				logger.debug("GDPWD1 No config-value to decrypt. Returning an Empty-String...");
				return encrypted;
			}

			// Something's wrong if AES256Key is still null or empty
			if (propAes256Key == null || propAes256Key.length() == 0) {
				logger.error("AES256Key is null or empty");
			}

			logger.debug("AES256Key = {}", propAes256Key);

			byte[] raw = hexToByteArray(propAes256Key);

			// Create SecretKeySpec
			SecretKeySpec secretKeySpec = new SecretKeySpec(raw, RILDefs.ENCRYPT_AES);

			if (secretKeySpec == null) {
				logger.debug("GDPWD2 No {} is available for decryption. Returning an Empty-String...",
						CommonDefs.APP_AES256KEY);
				return "";
			}

			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.DECRYPT_MODE, secretKeySpec);

			byte[] decryptedBytes = cipher.doFinal(hexToByteArray(encrypted));
			return new String(decryptedBytes);
			// }

		} catch (Exception e) {
			logger.error("GDPWDEX1 Exception : {}.", sanitizeForLog(e.getMessage()));
			return "";
		}
	}
	

	/**
	 * This method converts a hexadecimal string into a byte array.
	 *
	 * It iterates over the hexadecimal string, taking two characters at a time (representing one byte),
	 * and converts these characters into the corresponding byte value.
	 * The resulting byte values are stored in a byte array.
	 *
	 * @param hex The hexadecimal string to be converted. Each pair of characters in the string represents one byte.
	 * @return A byte array containing the byte values corresponding to the input hexadecimal string.
	 */
	public static byte[] hexToByteArray(String hex) {
		byte[] bts = new byte[hex.length() / 2];
		for (int i = 0; i < bts.length; i++) {
			bts[i] = (byte) Integer.parseInt(hex.substring(2 * i, 2 * i + 2), 16);
		}
		return bts;
	}

	

	public static Map<String, Object> processHmResponse(Map<String, Object> hmResponse, Map<String, Object> hmInput,  String sClassName, String sMethodName) {
		logger.info("CUH.PHM.01 : Response from Helper : {}", sanitizeForLog(String.valueOf(hmResponse)));

		if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
			hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from " + sClassName + sMethodName);
			logger.info("{}{}CUH.PHM.02 : Null response from ", sanitizeForLog(sClassName), sanitizeForLog(sMethodName));
		} else {
			String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (stAppStatusCode == null) {
				hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from " + sClassName + sMethodName);
				logger.info("{}{}CUH.PHM.03 : Null response from ", sanitizeForLog(sClassName), sanitizeForLog(sMethodName));
			}
		}

		hmResponse.put(CommonDefs.TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
		return hmResponse;
	}
	public static Map<String, Object> parseAndFetchDBValues(
			JdbcTemplate jdbcTemplate,
			DBHelper oDBHelper,
			String sMethodName,
			String sClassName,
			HashMap InpParam
	) throws MPSException{

		Map<String, Object> result = new HashMap<>();
		long ownedBy = -1;
		long memberNum = -1;
		long groupNum = -1;
		int memberStatus = -1;
		int groupStatus = -1;
		int sorId = -1;
		int parentSorId = -1;
		HashMap status = null;

		if (jdbcTemplate == null) {
			status = CommonErrorMap.makeCategoryMap(
					CErrorDefs.ERR_SYS_APPL_NUM, "jdbcTemplate is null.");
			logger.error("response : {}", sanitizeForLog(String.valueOf(status)));
			result.put("status", status);
			return result;
		}

		String sorName = (String) InpParam.get(MPSDefs.DB_SOR_NAME);
		String parentSorName =(String) InpParam.get(MPSDefs.DB_PARENT_SOR_NAME);
		String ownedByStr = (String) InpParam.get(MPSDefs.DB_OWNED_BY);
		String memberNumStr = (String) InpParam.get(MPSDefs.DB_MEMBER_NUM);
		String groupNumStr = (String) InpParam.get(MPSDefs.DB_GROUP_NUM);
		String memberStatusStr =(String) InpParam.get(MPSDefs.DB_MEMBER_STATUS);
		String groupStatusStr =(String) InpParam.get(MPSDefs.DB_GROUP_STATUS);
		String sorIdStr = (String) InpParam.get(MPSDefs.DB_SOR_ID);
		String parentSorIdStr = (String) InpParam.get(MPSDefs.DB_PARENT_SOR_ID);
		String serviceName =(String) InpParam.get(MPSDefs.DB_SERVICE_NAME);
		String memberStatusName = (String) InpParam.get(MPSDefs.DB_MEMBER_STATUS_NAME);
		String groupStatusName =(String) InpParam.get(MPSDefs.DB_GROUP_STATUS_NAME);

		if (sorName != null) {
			int tempSorId = oDBHelper.getSorId(sorName);
			sorIdStr = String.valueOf(tempSorId);
			logger.info("DBHLP82-1 : Got sor_id from DBHelper= {}", sanitizeForLog(sorIdStr));
		}

		if (parentSorName != null) {
			int tempParentSorId = oDBHelper.getSorId(parentSorName);
			parentSorIdStr = String.valueOf(tempParentSorId);
			logger.info("DBHLP82-1 : Got parent_sor_id from DBHelper= {}", sanitizeForLog(parentSorIdStr));
		}

		if (ownedByStr != null)
			ownedBy = Long.parseLong(ownedByStr);

		if (memberNumStr != null)
			memberNum = Long.parseLong(memberNumStr);

		if (groupNumStr != null)
			groupNum = Long.parseLong(groupNumStr);

		if (memberStatusStr != null)
			memberStatus = Integer.parseInt(memberStatusStr);

		if (groupStatusStr != null)
			groupStatus = Integer.parseInt(groupStatusStr);

		if (sorIdStr != null)
			sorId = Integer.parseInt(sorIdStr);

		if (parentSorIdStr != null)
			parentSorId = Integer.parseInt(parentSorIdStr);

		int serviceId = oDBHelper.getServiceId(serviceName);
		logger.debug("{}{}DBHLP83 : service_id={}", sMethodName, sClassName, serviceId);

		if (memberStatus == -1)
			memberStatus = oDBHelper.getStatusCode(memberStatusName);

		if (groupStatus == -1)
			groupStatus = oDBHelper.getStatusCode(groupStatusName);

		result.put("ownedBy", ownedBy);
		result.put("memberNum", memberNum);
		result.put("groupNum", groupNum);
		result.put("memberStatus", memberStatus);
		result.put("groupStatus", groupStatus);
		result.put("sorId", sorId);
		result.put("parentSorId", parentSorId);
		result.put("serviceId", serviceId);
		result.put("sorIdStr", sorIdStr);
		result.put("parentSorIdStr", parentSorIdStr);

		return result;
	}

	public static List<Object> prepareInsertParams(
			HashMap insertParams,	String sClassName) throws MPSException {

		List<Object> objectList = new ArrayList<>();
	 	long ownedBy = (long) insertParams.get("ownedBy");
		long memberNum= (long) insertParams.get("memberNum");
		long groupNum = (long) insertParams.get("groupNum");
		int  memberStatus = (int) insertParams.get("memberStatus");
		int groupStatus = (int) insertParams.get("groupStatus");
		int sorId = (int) insertParams.get("sorId");
		int parentSorId = (int) insertParams.get("parentSorId");
		int serviceId = (int) insertParams.get("serviceId");
		String sorIdStr = (String) insertParams.get("sorIdStr");
		String parentSorIdStr = (String) insertParams.get("parentSorIdStr");
		String terminateDate = (String) insertParams.get("terminateDate");
		String lastModifiedBy = (String) insertParams.get("lastModifiedBy");
		String siteId = (String) insertParams.get("siteId");
		String instanceId = (String) insertParams.get("instanceId");
		String sorInvariantId = (String) insertParams.get("sorInvariantId");
		String ownedByStr = (String) insertParams.get("ownedByStr");
		String nickname = (String) insertParams.get("nickname");
		String defaultAccount = (String) insertParams.get("defaultAccount");
		String cpniImpacted = (String) insertParams.get("cpniImpacted");
		String dateDefaultEst = (String) insertParams.get("dateDefaultEst");
		String parentSorInvariantId= (String) insertParams.get("parentSorInvariantId");
		String uverseServiceInd= (String) insertParams.get("uverseServiceInd");

		objectList.add(memberNum);
		logger.debug("{}{}DBHLP86 : member_num::PARAM 1 = {}", sClassName, ".addService.", memberNum);

		objectList.add(serviceId);
		logger.debug("{}{}DBHLP87 : service_id::PARAM 2 = {}", sClassName, ".addService.", serviceId);

		objectList.add(groupNum);
		logger.debug("{}{}MDBHLP88 : group_num::PARAM 3 = {}", sClassName, ".addService.", groupNum);

		objectList.add(groupStatus);
		logger.debug("{}{}DBHLP89 : group_status::PARAM 4 = {}", sClassName, ".addService.", groupStatus);

		objectList.add(memberStatus);
		logger.debug("{}{}DBHLP90 : member_status::PARAM 5 = {}", sClassName, ".addService.", memberStatus);

		if (terminateDate != null) {
			objectList.add(terminateDate);
			logger.debug("DBHLP91 : terminate_date::PARAM 6 = {}", sanitizeForLog(terminateDate));
		} else {
			objectList.add(terminateDate);
			logger.debug("{}{}DBHLP92 : terminate_date::PARAM 6 = null", sClassName, ".addService.");
		}
		objectList.add(lastModifiedBy);
		logger.debug("DBHLP93 : last_modified_by::PARAM 7 = {}", sanitizeForLog(lastModifiedBy));

		if (siteId != null) {
			objectList.add(siteId);
			logger.debug("DBHLP94 : site_id::PARAM 8 = {}", sanitizeForLog(siteId));
		} else {
			objectList.add(siteId);
			logger.debug("{}{}DBHLP95 : site_id::PARAM 8 = null", sClassName, ".addService.");
		}

		if (instanceId != null) {
			objectList.add(instanceId);
			logger.debug("DBHLP96 : instance_id::PARAM 9 = {}", sanitizeForLog(instanceId));
		} else {
			objectList.add(instanceId);
			logger.debug("{}{}DBHLP97 : instance_id::PARAM 9 = 1", sClassName, ".addService.");
		}

		if (sorIdStr != null) {
			objectList.add(sorId);
			logger.debug("{}{}DBHLP97-1 : sor_id::PARAM 10 = {}", sClassName, ".addService.", sorId);
		} else {
			objectList.add(sorId);
			logger.debug("{}{}DBHLP97-2 : sor_id::PARAM 10 = null", sClassName, ".addService.");
		}

		if (sorInvariantId != null) {
			objectList.add(sorInvariantId);
			logger.debug("DBHLP97-3 : sor_invariant_id::PARAM 11 = {}", sanitizeForLog(sorInvariantId));
		} else {
			objectList.add(sorInvariantId);
			logger.debug("{}{}DBHLP97-4 : sor_invariant_id::PARAM 11 = null", sClassName, ".addService.");
		}

		if (ownedByStr != null) {
			objectList.add(ownedBy);
			logger.debug("DBHLP97-5 : owned_by::PARAM 12 = {}", sanitizeForLog(ownedByStr));
		} else {
			objectList.add(null);
			logger.debug("{}{}DBHLP97-6 : owned_by::PARAM 12 = null", sClassName, ".addService.");
		}


		if (nickname != null) {
			objectList.add(nickname);
			logger.debug("DBHLP97-7 : nickname::PARAM 13 = {}", sanitizeForLog(nickname));
		} else {
			objectList.add(nickname);
			logger.debug("{}{}DBHLP97-8 : nickname::PARAM 13 = null", sClassName, ".addService.");
		}

		if (defaultAccount != null) {
			objectList.add(defaultAccount);
			logger.debug("DBHLP97-9 : default_account::PARAM 14 = {}", sanitizeForLog(defaultAccount));
		} else {
			objectList.add(defaultAccount);
			logger.debug("{}{}DBHLP97-10 : default_account::PARAM 14 = null", sClassName, ".addService.");
		}

		if (cpniImpacted != null) {
			objectList.add(cpniImpacted);
			logger.debug("DBHLP97-11 : cpni_impacted::PARAM 15 = {}", sanitizeForLog(cpniImpacted));
		} else {
			objectList.add(cpniImpacted);
			logger.debug("{}{}DBHLP97-12 : cpni_impacted::PARAM 15 = null", sClassName, ".addService.");
		}

		if (defaultAccount != null && defaultAccount.equalsIgnoreCase(MPSDefs.YES)) {
			dateDefaultEst = "1";
			objectList.add(dateDefaultEst);
			logger.debug("{}{}DBHLP97-13 : date_default_est::PARAM 16 = {}", sClassName, ".addService.", new Date());
		} else {
			objectList.add(dateDefaultEst);
			logger.debug("{}{}DBHLP97-14 : date_default_est::PARAM 16 = null", sClassName, ".addService.");
		}

		if (parentSorIdStr != null) {
			objectList.add(parentSorId);
			logger.debug("{}{}DBHLP97-15 : parent_sor_id::PARAM 17 = {}", sClassName, ".addService.", parentSorId);
		} else {
			objectList.add(null);
			logger.debug("{}{}DBHLP97-16 : parent_sor_id::PARAM 17 = null", sClassName, ".addService.");
		}

		if (parentSorInvariantId != null) {
			objectList.add(parentSorInvariantId);
			logger.debug("DBHLP97-17 : parent_sor_invariant_id::PARAM 18 = {}", sanitizeForLog(parentSorInvariantId));
		} else {
			objectList.add(parentSorInvariantId);
			logger.debug("{}{}DBHLP97-18 : parent_sor_invariant_id::PARAM 18 = null", sClassName, ".addService.");
		}

		if (uverseServiceInd != null) {
			objectList.add(uverseServiceInd);
			logger.debug("DBHLP97-19 : uverse_service_ind::PARAM 19 = {}", sanitizeForLog(uverseServiceInd));
		} else {
			objectList.add(uverseServiceInd);
			logger.debug("{}{}DBHLP97-20 : uverse_service_ind::PARAM 19 = null", sClassName, ".addService.");
		}

		return objectList;
	}

  /**
	 * Sanitizes a string for safe logging by removing control characters and HTML-encoding to prevent CRLF injection.
	 */
	public static String sanitizeForLog(String input) {
		if (input == null) {
			return null;
		}
		String stripped = input.replaceAll("[\\r\\n\\x00-\\x1F\\x7F]+", " ");
		return ESAPI.encoder().encodeForHTML(stripped);
	}

    public static String getTraceIdFromContextMap() {
        String stIdpTraceId = null;
		if (MDC.getCopyOfContextMap() != null && MDC.getCopyOfContextMap().get("idp-trace-id") != null) {
			stIdpTraceId = MDC.getCopyOfContextMap().get("idp-trace-id");
			logger.info("Context idp-trace-id: {}", sanitizeForLog(stIdpTraceId));
        }
        return stIdpTraceId;
    }
  
	public static MemberIdResponse generateMemberIdResponse(Map<String, Object> hmResponse) {

		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get(ProfileOrchestrationConstants.IDP_TRACE_ID);
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

		int iAppStatusCode = Integer.parseInt(stAppStatusCode);
		HashMap hmResult = CommonErrorMap.makeCategoryMap(iAppStatusCode, stAppInfo);

		MemberIdResponse memberIdResponse = new MemberIdResponse();
		memberIdResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		memberIdResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		memberIdResponse.setAppInfo(stAppInfo);
		memberIdResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		memberIdResponse.setIdpTraceId(stIdpTraceId);

		if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE + stAppStatusCode);
			memberIdResponse.setErrors(new ServiceException(errMsg, stAppInfo).getError());
			return memberIdResponse;
		}else{
			memberIdResponse.setMemberId((MemberDetails)hmResponse.get("memberId"));
			memberIdResponse.setSecMemberIds((List<MemberDetails>) hmResponse.get("secMemberIds"));
		}
		return memberIdResponse;
	}

	public static MemberIdResponse memberIdSuccessResponse(MemberIdResponse memberIdResponse, String traceId) {
			HashMap<String, Object> hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, "Success");
			memberIdResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
			memberIdResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
			memberIdResponse.setIdpTraceId(traceId);
			return memberIdResponse;
	}

	/**
	 * Generates a DeleteUserResponse based on the input HashMap.
	 * This method extracts relevant details from the provided HashMap, such as application info,
	 * status code, and trace ID, to construct a DeleteUserResponse object. It handles both success
	 * and error scenarios by redirecting to appropriate response generation methods.
	 *
	 * @param hmResponse A HashMap containing the details of the response to be generated.
	 * @return DeleteUserResponse An object representing the response to be sent back to the client.
	 */
	public static DeleteUserResponse generateDeleteUserResponse(Map<String, Object> hmResponse) {

		// fetch details from hmResponse
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get("idp-trace-id");
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

		// creating new hashMap hmResult
		int appStatusCode = Integer.parseInt(stAppStatusCode);
		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, stAppInfo);

		// populating deleteUserResponse
		DeleteUserResponse deleteUserResponse = new DeleteUserResponse();
		deleteUserResponse
				.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		deleteUserResponse
				.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		deleteUserResponse.setAppInfo(stAppInfo);
		deleteUserResponse
				.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		deleteUserResponse.setIdpTraceId(stIdpTraceId);
		if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {

			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf(MS_MPSYS_BE + stAppStatusCode);
			deleteUserResponse.setErrors(new ServiceException(errMsg, stAppInfo).getError());
		}
		return deleteUserResponse;

	}
}
