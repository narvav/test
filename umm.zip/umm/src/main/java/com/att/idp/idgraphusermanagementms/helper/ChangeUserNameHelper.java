package com.att.idp.idgraphusermanagementms.helper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.db.helper.DBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.GetMemberServicesDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.MemberDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.UpdateDBHelper;
import com.att.idp.idgraphusermanagementms.queue.message.helpers.ChangeUserNameQueueHelper;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * The ChangeUserNameHelper class is a helper class that provides methods to handle the process of changing a user's name.
 * It includes methods to validate the old and new user names, check the eligibility of the new user name, and update the user name in the database.
 * This class is annotated with @Component, meaning it is an autodetectable Spring Bean and can be automatically wired into other components using Spring's dependency injection facilities.
 * It is also annotated with @Configuration and @PropertySource, indicating that it provides configuration information for the Spring application context and specifies the path of the properties file to be used.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class ChangeUserNameHelper {
	public static final Logger logger = LoggerFactory.getLogger(ChangeUserNameHelper.class);
	private static String sClassName = "ChangeUserNameHelper";
	boolean isTransactionRollbackOnError = false;

	@Autowired
	private DBHelper oDBHelper;

	@Autowired
	private GetMemberServicesDBHelper oGetMemberServicesDBHelper;

	@Autowired
	private UpdateDBHelper oUpdateDBHelper;

	@Autowired
	private MemberDBHelper oMemberDBHelper;

	@Autowired
	private CheckUserIdAvailabilityHelper oCheckUserIdAvailability;

	@Autowired
	private ChangeUserNameQueueHelper changeUserNameQueueHelper;

	/**
	 * This method is used to change the username of a user.
	 * It performs various checks and validations on the old and new usernames, and updates the username in the database if all checks pass.
	 * It also sends a message to the message queue with the details of the username change.
	 * If any error occurs during the process, it logs the error and returns a map with the error details.
	 *
	 * @param hmInput A Map containing the necessary information for changing the username. This includes details like the old username, new username, transaction ID, transaction name, and calling system ID.
	 * @return A Map containing the result of the operation. This includes status codes and messages indicating the success or failure of the operation.
	 */
	public Map<String, Object> changeUserName(Map<String, Object> hmInput) {
		String sMethodName = ".ChangeUserName.";
		Map<String, Object> hmResult = null;
		String stAppInfo = null;
		String stAppStatusCode = null;

		logger.info("ChangeUserNameHelper.changeUserName.HLP000 : Input Hash : {}",
				StructuredArguments.entries(hmInput));
		Map<String, Object> hmOldUserMemberInfo = null;

		boolean bNewUserNameHaveAttDomain = false;
		boolean isForeignEmailId = false;
		String sOldUserMemberNum = null;

		if (MapUtils.isEmpty(hmInput)) {
			stAppInfo = "Input Hash is NULL";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			logger.info("{}{}CUNH_100 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
		String sOldUserName = (String) hmInput.get(CommonDefs.OLD_USERNAME);
		String sNewUserName = (String) hmInput.get(CommonDefs.NEW_USERNAME);
		String sAccessIdRTValidFlag = (String) hmInput.get(CommonDefs.ACCESS_ID_RTV_VALID_FLAG);

		try {
			logger.info(
					"CUNH_01 : sNewusername : {} and indexof @ in newUserName : {}, bNewUserNameHaveAttDomain Value : {}",
					HtmlUtils.htmlEscape(String.valueOf(sNewUserName)),
					HtmlUtils.htmlEscape(String.valueOf(sNewUserName.indexOf("@"))),
					HtmlUtils.htmlEscape(String.valueOf(bNewUserNameHaveAttDomain)));

			if (sNewUserName.indexOf("@") > 0) {
				if (oDBHelper.getDomainId(
						sNewUserName.substring(sNewUserName.indexOf("@") + 1, sNewUserName.length())) > 0) {
					bNewUserNameHaveAttDomain = true;
				} else {
					isForeignEmailId = true;
				}
			}

			logger.info("CUNH_02 : is newUserName domain is valid att domain : {}", bNewUserNameHaveAttDomain);

			// calling DBMemberInfo for oldUserName
			logger.info("{}{}CUNH_03: Calling GetMemberServicesDBHelper.getMemberServices for oldUser", sClassName, sMethodName);  
			hmOldUserMemberInfo = getMemberInfo(sOldUserName, CommonDefs.SLID_DUM);
			if (MapUtils.isEmpty(hmOldUserMemberInfo)) {
				stAppInfo = "got system error while looking for OldUserName info";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}CUNH_04 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			stAppStatusCode = (String) hmOldUserMemberInfo.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				stAppInfo = (String) hmOldUserMemberInfo.get(CommonDefs.COMMON_APP_INFO);
				if (stAppInfo == null) {
					stAppInfo = (String) hmOldUserMemberInfo.get("sqlMsg");
				}

				if (stAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
					stAppInfo = "OldUser Not Found in DB";
					stAppStatusCode = Integer.toString(CErrorDefs.ERR_USER_NOT_FOUND_NUM);
				} 

				logger.info("{}{}CUNH_05 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
				return hmResult;
			}

			hmResult = validateOldUserMemberInfo(hmOldUserMemberInfo, bNewUserNameHaveAttDomain, sCallingSystemId);
			logger.info("{}{}CUNH_09 :Response from validateOldUserMemberInfo: {}", sClassName, sMethodName, hmResult);
			stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			}

			if (hmOldUserMemberInfo.containsKey(MPSDefs.DB_MEMBER_NUM))
				sOldUserMemberNum = (String) hmOldUserMemberInfo.get(MPSDefs.DB_MEMBER_NUM);

			hmResult = validateNewUser(hmInput, bNewUserNameHaveAttDomain, sOldUserMemberNum);
			logger.info("{}{}CUNH_27 : Response from validateNewUser: {}", sClassName, sMethodName, hmResult);
			stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			}

			HashMap<String, Object> hmMember = CommonUtil.getHashMap();
			hmMember.put(MPSDefs.DB_MEMBER_NUM, sOldUserMemberNum);

			if (isForeignEmailId || bNewUserNameHaveAttDomain) {
				if ((sAccessIdRTValidFlag != null && sAccessIdRTValidFlag.equalsIgnoreCase(CommonDefs.IND_Y))) {
					hmMember.put(CommonDefs.DB_ACCESS_ID_RTV_DATE, CommonDefs.IND_Y);
				} else {
					hmMember.put(CommonDefs.DB_ACCESS_ID_RTV_DATE, null);
				}
			}

			hmResult = updateUserInDB(hmInput, hmOldUserMemberInfo, hmMember);
			logger.info("{}{}CUNH_36 : Response from updateUserInDB: {}", sClassName, sMethodName, hmResult);
			stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			}

			// DbusCall
			Map<String, Object> hmDbusResult = changeUserNameQueueHelper.sendMessageToMQ(hmInput, hmOldUserMemberInfo);
			logger.info("{}{}CUNH_37 :Response from changeUserNameQueueHelper.sendMessageToMQ: {}", sClassName,
					sMethodName, hmDbusResult);

			if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmDbusResult)) {
				hmResult = CommonUtilHelper
						.sysErrorHashMap("null response from ChangeUserNameQueueHelper.sendMessageToMQ");
				return hmResult;
			} else {
				stAppStatusCode = (String) hmDbusResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
				if (StringUtils.isBlank(stAppStatusCode)) {
					hmResult = CommonUtilHelper
							.sysErrorHashMap("null response from ChangeUserNameQueueHelper.sendMessageToMQ");
					return hmResult;
				} else if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					stAppInfo = (String) hmDbusResult.get(CommonDefs.COMMON_APP_INFO);
					logger.info("{}{}CUNH_38 : {}", sClassName, sMethodName,
							HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
					hmResult = hmDbusResult;
					return hmResult;
				}
			}

			// Default success if no error occur
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		}

		catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown in ChangeUserName method : " + hmResult;
			logger.info("{}{}CUNH_150 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
		}

		finally {
			String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);

			if (isTransactionRollbackOnError && sAppCategoryCode != null
					&& !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
				hmResult.put("isTransactionRollback", CommonDefs.IND_Y);
			}

			logger.info("{}{}HLP999 : response from ChangeUserName : {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(hmResult)));
		}

		return hmResult;
	}

	/**
	 * check the oldUserMember is valid or not by checking the info associated with
	 * it
	 * 
	 * @param hmOldUserMemberInfo
	 * @param bNewUserNameHaveAttDomain
	 * @param sCallingSystemId
	 * @return hmResult
	 */
	private Map<String, Object> validateOldUserMemberInfo(Map<String, Object> hmOldUserMemberInfo,
			boolean bNewUserNameHaveAttDomain, String sCallingSystemId) {
		String sMethodName = ".validateOldUserMemberInfo.";
		String stAppInfo = null;
		String sFnLinkedStatus = null;
		Map<String, Object> hmResult = null;

		// checking if oldUserName have any services DLIFE|XANBOO
		if (hmOldUserMemberInfo.containsKey(CommonDefs.SERVICES)) {
			HashMap<String, Object> hmServices = (HashMap<String, Object>) hmOldUserMemberInfo.get(CommonDefs.SERVICES);
			logger.info("{}{}CUNH_06: OldUserName Slid services: {}", sClassName, sMethodName, hmServices);
			if (hmServices.containsKey(CommonDefs.DLIFE_SERVICE) || hmServices.containsKey(CommonDefs.XANBOO_SERVICE)) {
				if (bNewUserNameHaveAttDomain) {
					stAppInfo = "DigitalLife accessId is not allowed to have ATT domain";
					logger.info("{}{}CUNH_07 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
					return hmResult;
				}
				if (!sCallingSystemId.equals(CommonDefs.DATAMGT)) {
					stAppInfo = "Input X-ATT-ClientId is not allowed to change DigitalLife AccessID";
					logger.info("{}{}CUNH_08 : {}", sClassName, sMethodName,
							HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, stAppInfo);
					return hmResult;
				}
			}
		}

		if (hmOldUserMemberInfo.containsKey(CommonDefs.DB_FN_LINKED_STATUS)) {
			sFnLinkedStatus = (String) hmOldUserMemberInfo.get(CommonDefs.DB_FN_LINKED_STATUS);
			if (sFnLinkedStatus != null && (sFnLinkedStatus.equalsIgnoreCase(CommonDefs.FN_STATUS_SELF))) {
				stAppInfo = "old accessId linked with FirstNet Id";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, stAppInfo);
				return hmResult;
			}
		}
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}

	/**
	 * check the newUserName is valid or not by checking the info associated with it
	 * 
	 * @param hmInput
	 * @param bNewUserNameHaveAttDomain
	 * @param sOldUserMemberNum
	 * @return hmResult
	 */
	private Map<String, Object> validateNewUser(Map<String, Object> hmInput, boolean bNewUserNameHaveAttDomain,
			String sOldUserMemberNum) {
		String sMethodName = ".validateNewUser.";
		String stAppInfo = null;
		String stAppStatusCode = null;
		String sNewUserName = (String) hmInput.get(CommonDefs.NEW_USERNAME);
		boolean bChecknewUser = true;
		Map<String, Object> hmResult = null;

		if (bNewUserNameHaveAttDomain) {
			// retrieving the newUserName details from MPS DB
			logger.info("{}{}CUNH_10: Calling GetMemberServicesDBHelper.getMemberServices for NewUser", sClassName, sMethodName);
			HashMap<String, Object> hmNewUserMemberInfo = getMemberInfo(
					sNewUserName.substring(0, sNewUserName.indexOf("@")),
					sNewUserName.substring(sNewUserName.indexOf("@") + 1, sNewUserName.length()));

			if (MapUtils.isEmpty(hmNewUserMemberInfo)) {
				stAppInfo = "got system error while looking for NewUserName info";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}CUNH_11 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			stAppStatusCode = (String) hmNewUserMemberInfo.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				stAppInfo = (String) hmNewUserMemberInfo.get(CommonDefs.COMMON_APP_INFO);
				if (stAppInfo == null) {
					stAppInfo = (String) hmNewUserMemberInfo.get("sqlMsg");
				}


				if (stAppStatusCode.equals(MPSDefs.REC_NOT_FOUND)) {
					stAppInfo = ".Net id corresponding to newUserName not exists in DB";
					stAppStatusCode = Integer.toString(CErrorDefs.ERR_CANNOT_OPERATE_NUM);
				} 

				logger.info("{}{}CUNH_12 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
				return hmResult;
			}

			hmResult = checkLinkedAccessId(hmNewUserMemberInfo, sOldUserMemberNum);
			stAppStatusCode = (String) hmResult.getOrDefault(CErrorDefs.COMMON_APP_STATUS_CODE, null);
			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			}

			bChecknewUser = (boolean) hmResult.get("bChecknewUser");
		}

		// verify whether the newUserName contains any badwords or suggest Handle
		if (bChecknewUser) {
			hmResult = checkNewUserName(hmInput);
			logger.info("{}{}CUNH_25 : Response from checkUserName() : {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(hmResult)));
			if (MapUtils.isEmpty(hmResult)) {
				stAppInfo = "Response from checkNewUserName() is null / empty";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}CUNH_26 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (!(CErrorDefs.COMMON_SUCCESS.equals(stAppStatusCode)))
				return hmResult;
		}

		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}

	/**
	 * call GetMemberServicesDBHelper.getMemberServices with handle and domain to
	 * pull memberInfo from MPSDB
	 * 
	 * @param handle
	 * @param domain
	 * @return hmResult
	 */
	private HashMap<String, Object> getMemberInfo(String handle, String domain) {
		String sMethodName = ".getMemberInfo.";
		String stAppInfo = null;
		HashMap<String, Object> hmReq = CommonUtil.getHashMap();
		HashMap<String, Object> hmResult = null;
		ArrayList<String> alSildMaskInp = CommonUtil.getArrayList();
		Arrays.asList("LU", "LS", "SQ").stream().forEachOrdered(alSildMaskInp::add);

		hmReq.put(MPSDefs.DB_MEMBER_NAME, handle);
		hmReq.put(MPSDefs.DB_DOMAIN_NAME, domain);
		hmReq.put(MPSDefs.SECURITY_ALL_REQ, CommonDefs.DEFAULT_YES);
		hmReq.put(MPSDefs.DB_QUERY_MEMBERLOCKOUT_FLAG, CommonDefs.DEFAULT_YES);
		hmReq.put(MPSDefs.QUERY_SLID_INFO_FLAG, CommonDefs.DEFAULT_YES);
		hmReq.put(MPSDefs.QUERY_LINKED_USERS_FLAG, CommonDefs.DEFAULT_YES);
		hmReq.put(MPSDefs.QUERY_FRAUD_LOCK_FLAG, CommonDefs.DEFAULT_YES);
		hmReq.put(CommonDefs.SLID_MASK, alSildMaskInp);

		logger.debug("{}{}CUNH_MIC_01 Request to get MemberServices {}", sClassName, sMethodName,
				HtmlUtils.htmlEscape(String.valueOf(hmReq)));
		hmResult = oGetMemberServicesDBHelper.getMemberServices(hmReq);
		logger.info(SpiMarker.getInstance(),
				"{}{}CUNH_MIC_02 : Received response from GetMemberServicesDBHelper.getMemberServices", sClassName, sMethodName);

		if (MapUtils.isEmpty(hmResult)) {
			stAppInfo = "GetMemberServicesDBHelper returned null / empty response";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			logger.info("{}{}CUNH_MIC_03 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		return hmResult;
	}

	/**
	 * check the userName valid or not by checking badwords and suggestHandle
	 * 
	 * @param hmValidateReq
	 * @return hmValidateRes
	 */
	private Map<String, Object> checkNewUserName(Map<String, Object> hmValidateReq) {
		String sMethodName = ".checkNewUserName.";
		String stAppStatusCode = null;
		String stAppInfo = null;
		int numSuggestions = 1;
		Map<String, Object> hmValidateRes = null;

		Map<String, Object> hmCheckNewUserNameReq = CommonUtil.getHashMap();
		hmCheckNewUserNameReq.put(CommonDefs.TRANSACTION_ID, hmValidateReq.get(CommonDefs.TRANSACTION_ID));
		hmCheckNewUserNameReq.put(CommonDefs.TRANSACTION_NAME, "CheckUserIdAvailability");
		hmCheckNewUserNameReq.put(CommonDefs.ORIG_TRANSACTION_NAME, hmValidateReq.get(CommonDefs.TRANSACTION_NAME));
		hmCheckNewUserNameReq.put(CommonDefs.CALLING_SYSTEM_ID, hmValidateReq.get(CommonDefs.CALLING_SYSTEM_ID));
		hmCheckNewUserNameReq.put(CommonDefs.SUGGEST1, hmValidateReq.get(CommonDefs.NEW_USERNAME));
		hmCheckNewUserNameReq.put(CommonDefs.DOMAIN, CommonDefs.SLID_DUM);
		hmCheckNewUserNameReq.put(CommonDefs.NUM_SUGGESTIONS, Integer.toString(numSuggestions));
		hmCheckNewUserNameReq.put(CommonDefs.IGNORE_QAY, CommonDefs.IND_Y);

		logger.debug("{}{}CUNH_17 Request to CheckUserIdAvailability : {}", sClassName, sMethodName,
				HtmlUtils.htmlEscape(String.valueOf(hmCheckNewUserNameReq)));
		hmValidateRes = oCheckUserIdAvailability.checkUserIdAvailability(hmCheckNewUserNameReq);
		logger.debug("{}{}CUNH_18 Response from CheckUserIdAvailability : {}", sClassName, sMethodName, hmValidateRes);

		if (MapUtils.isEmpty(hmValidateRes)) {
			stAppInfo = "Null Response returned from CheckUserIdAvailability Helper";
			hmValidateRes = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			logger.info("{}{}CUNH_19 : {}", sClassName, sMethodName, stAppInfo);
			return hmValidateRes;
		}
		stAppStatusCode = (String) hmValidateRes.get(MPSDefs.APP_STATUS_CODE);
		if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
			stAppInfo = (String) hmValidateRes.get(CommonDefs.COMMON_APP_INFO);
			logger.info("{}{}CUNH_20 : {}", sClassName, sMethodName, stAppInfo);
			hmValidateRes = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
			return hmValidateRes;
		}

		ArrayList alSuggestHandles = (ArrayList) hmValidateRes.get(CommonDefs.SUGGESTLIST);
		if (alSuggestHandles == null || alSuggestHandles.isEmpty()) {
			stAppInfo = "CheckUserIdAvailability helper failed to return suggestList for Success response";
			logger.info("{}{}CUNH_21 : {}", sClassName, sMethodName, stAppInfo);
			hmValidateRes = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			return hmValidateRes;
		}

		// verifying the suggested handle matched with newUserName
		if (alSuggestHandles.size() == numSuggestions) {
			String stSuggestedHandle = (String) ((HashMap) alSuggestHandles.get(0)).get(CommonDefs.SUGGEST);
			if (stSuggestedHandle.equals(hmValidateReq.get(CommonDefs.NEW_USERNAME))) {
				stAppInfo = "newUserName is valid and good to change userName";
				hmValidateRes = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
				logger.info("{}{}CUNH_22 : {}", sClassName, sMethodName, stAppInfo);
			} else {
				stAppInfo = "newUserName is in use or invalid. Returning suggested handles";
				logger.info("{}{}CUNH_23 : {}", sClassName, sMethodName, stAppInfo);
				hmValidateRes = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ID_UNAVAILABLE_NUM, stAppInfo);
				return hmValidateRes;
			}
		} else {
			stAppInfo = "CheckUserIdAvailabilityHelper failed to return " + numSuggestions + " items in suggest list";
			logger.info("{}{}CUNH_24 : {}", sClassName, sMethodName, stAppInfo);
			hmValidateRes = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			return hmValidateRes;
		}

		return hmValidateRes;
	}

	/**
	 * checking if newUserName MID is linked to any accessID or not
	 * 
	 * @param hmNewUserMemberInfo
	 * @param sOldUserMemberNum
	 * @return hmResult
	 */
	private Map<String, Object> checkLinkedAccessId(HashMap<String, Object> hmNewUserMemberInfo,
			String sOldUserMemberNum) {
		String sMethodName = ".checkLinkedAccessId.";
		String sNewUserSlidMemberNum = null;
		String stAppInfo = null;
		boolean bChecknewUser = true;
		Map<String, Object> hmResult;

		if (hmNewUserMemberInfo.containsKey(MPSDefs.DB_SLID_MEMBER_NUM))
			sNewUserSlidMemberNum = (String) hmNewUserMemberInfo.get(MPSDefs.DB_SLID_MEMBER_NUM);

		// checking if newUserName MID is linked to any accessID or not
		if (sNewUserSlidMemberNum != null && !(sNewUserSlidMemberNum.trim()).isEmpty()) {
			if (!sOldUserMemberNum.equals(sNewUserSlidMemberNum)) {
				stAppInfo = "AT&T internet ID of newUserName not linked to oldUser, instead it associated to some other user";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, stAppInfo);
				logger.info("{}{}CUNH_13 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			} else {
				logger.info("{}{}CUNH_14 : AT&T internet ID of newUserName linked to oldUser", sClassName, sMethodName);
				logger.info("{}{}CUNH_15 : as newUser already exist, skipping checkNewUser and setting flag to false", sClassName, sMethodName);
				bChecknewUser = false;
			}
		} else {
			stAppInfo = "AT&T internet ID of newUserName not linked to any accessID";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CANNOT_OPERATE_NUM, stAppInfo);
			logger.info("{}{}CUNH_16 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		hmResult.put("bChecknewUser", bChecknewUser);
		return hmResult;
	}

	/**
	 * updating in MPSDB from oldUserName to newUserName
	 * 
	 * @param hmInput
	 * @param hmOldUserMemberInfo
	 * @param hmMember
	 * @return hmResult
	 */
	private Map<String, Object> updateUserInDB(Map<String, Object> hmInput, Map<String, Object> hmOldUserMemberInfo,
			HashMap<String, Object> hmMember) {
		String sMethodName = ".updateUserInDB.";

		HashMap<String, Object> hmMPSInput = CommonUtil.getHashMap();
		HashMap<String, Object> hmGrpInput = CommonUtil.getHashMap();
		Map<String, Object> hmResult = null;
		ArrayList<HashMap<String, Object>> alMember = CommonUtil.getArrayList();

		String sAutoGenInd = null;
		String stAppStatusCode = null;
		String stAppInfo = null;
		String sNewUserName = (String) hmInput.get(CommonDefs.NEW_USERNAME);
		String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
		String sTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);
		String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

		if (hmOldUserMemberInfo.containsKey(MPSDefs.DB_AUTOGENERATED_IND))
			sAutoGenInd = (String) hmOldUserMemberInfo.get(MPSDefs.DB_AUTOGENERATED_IND);

		hmMember.put(MPSDefs.DB_MEMBER_NAME, sNewUserName);
		hmMember.put(MPSDefs.DB_OPERATION, MPSDefs.DB_OPERATION_UPDATE);

		if (sAutoGenInd != null && sAutoGenInd.trim().equalsIgnoreCase(MPSDefs.YES)) {
			hmMember.put(MPSDefs.DB_AUTOGENERATED_IND, MPSDefs.NO);
			hmMember.put(MPSDefs.DB_ACTIVATED_IND, CommonDefs.IND_Y);
		}
		alMember.add(hmMember);
		hmGrpInput.put(MPSDefs.DB_PARENT_NAME, sNewUserName);
		if (hmOldUserMemberInfo.containsKey(MPSDefs.KEY_SLID_INFO)
				&& ((HashMap) hmOldUserMemberInfo.get(MPSDefs.KEY_SLID_INFO)).containsKey(MPSDefs.DB_GROUP_NUM))
			hmGrpInput.put(MPSDefs.DB_GROUP_NUM,
					((HashMap) hmOldUserMemberInfo.get(MPSDefs.KEY_SLID_INFO)).get(MPSDefs.DB_GROUP_NUM));
		hmGrpInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
		hmGrpInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
		hmGrpInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
		hmGrpInput.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);

		hmMPSInput.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
		hmMPSInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
		hmMPSInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
		hmMPSInput.put(MPSDefs.DB_MEMBER_TABLE, alMember);

		// updating newUsername by calling MemberDBHelper.processData
		logger.debug("{}{}CUNH_28 : Calling to MemberDBHelper.processData with HashMap : {}", sClassName, sMethodName,
				HtmlUtils.htmlEscape(String.valueOf(hmMPSInput)));
		hmResult = oMemberDBHelper.processData(hmMPSInput);
		logger.debug("{}{}CUNH_29 : Response Hash from MemberDBHelper.processData is : {} ", sClassName, sMethodName,
				HtmlUtils.htmlEscape(String.valueOf(hmResult)));

		if (MapUtils.isEmpty(hmResult)) {
			stAppInfo = "Null Response returned from MemberDBHelper";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			logger.info("{}{}CUNH_30 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
		if (stAppStatusCode != null && !(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
			stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
			hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
			logger.info("{}{}CUNH_31 : Error returned from MemberDBHelper.processData : {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(hmResult)));
			return hmResult;
		} else {
			isTransactionRollbackOnError = true;
		}

		// updating groupInfo by calling UpdateDBHelper.updateMemberGroup
		logger.debug("{}{}CUNH_32 : Calling UpdateDBHelper.updateMemberGroup with HashMap : {}", sClassName,
				sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmGrpInput)));
		hmResult = oUpdateDBHelper.updateMemberGroup(hmGrpInput);
		logger.debug("{}{}CUNH_33 : Response from UpdateDBHelper.updateMemberGroup : {}", sClassName, sMethodName,
				HtmlUtils.htmlEscape(String.valueOf(hmResult)));

		if (MapUtils.isEmpty(hmResult)) {
			stAppInfo = "Null Response returned from UpdateDBHelper";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			logger.info("{}{}CUNH_34 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
		if (stAppStatusCode != null && !(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
			stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
			hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
			logger.info("{}{}CUNH_35 : Error returned from UpdateDBHelper.updateMemberGroup : {}", sClassName,
					sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmResult)));
			return hmResult;
		} else {
			isTransactionRollbackOnError = true;
		}

		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}
}
