package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import jakarta.persistence.*;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TPROVISIONEDHSIA", schema = "MPS_OWNER")
public class Tprovisionedhsia implements java.io.Serializable {

	private static final long serialVersionUID = -2546562222668319222L;

	@GenericGenerator(name = "generator", strategy = "foreign", parameters = @Parameter(name = "property", value = "tprovisionedservice"))
	@Id
	@GeneratedValue(generator = "generator")
	@Column(name = "PROVISIONED_SERVICE_NUM", unique = true, nullable = false, precision = 22, scale = 0)
	private Long provisionedServiceNum;

	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	private Tprovisionedservice tprovisionedservice;

	@Column(name = "PORTAL_PROVIDER")
	private String portalProvider;

	@Column(name = "UNVALIDATED_HANDLE", length = 20)
	private String unvalidatedHandle;

	@Column(name = "UNVALIDATED_DOMAIN", length = 30)
	private String unvalidatedDomain;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;
}