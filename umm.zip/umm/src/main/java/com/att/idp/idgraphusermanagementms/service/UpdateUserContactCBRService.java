package com.att.idp.idgraphusermanagementms.service;

import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.resource.request.UpdateUserContactCBRRequest;
import com.att.idp.idgraphusermanagementms.resource.response.UpdateUserContactCBRResponse;

import jakarta.ws.rs.core.MultivaluedMap;

/**
 * This interface defines the contract for the UpdateUserContactCBRService in the system.
 * It contains a single method updateUserContactCBR which takes an UpdateUserContactCBRRequest object and a MultivaluedMap of request headers as parameters.
 * The method is expected to return an UpdateUserContactCBRResponse object.
 *
 * The UpdateUserContactCBRRequest object encapsulates the details of the user contact update operation to be performed.
 * The MultivaluedMap contains the request headers which may include additional information required for processing the request.
 *
 */
public interface UpdateUserContactCBRService {
	
	/**
	 * This method is part of the UpdateUserContactCBRService interface.
	 * It defines the contract for updating a user's contact in the system.
	 *
	 * @param updateUserContactCBRRequest An object encapsulating the details of the user contact update operation to be performed.
	 * @param requestHeader A MultivaluedMap containing the request headers which may include additional information required for processing the request.
	 * @return An UpdateUserContactCBRResponse object representing the response from the system after updating the user's contact.
	 * @throws MPSException If there is an error during the processing of the request.
	 */
    UpdateUserContactCBRResponse updateUserContactCBR(UpdateUserContactCBRRequest updateUserContactCBRRequest, MultivaluedMap<String, String> requestHeader) throws MPSException;
}
