package com.att.idp.idgraphusermanagementms.resource.impl;

import java.sql.SQLException;
import java.util.Map;

import jakarta.validation.Valid;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_IB;
import static com.att.idp.cd.observability.metrics.utils.Constants.URI;
import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.POST;
import static com.att.idp.idgraphusermanagementms.utils.ProfileOrchestrationConstants.IDGRAPH_USERMANAGEMENTMS_IB;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.stereotype.Controller;

import com.att.idp.idgraphusermanagementms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphusermanagementms.exceptions.MPSException;
import com.att.idp.idgraphusermanagementms.message.ErrorMessages;
import com.att.idp.idgraphusermanagementms.request.validator.RegisterEmailUserRequestValidator;
import com.att.idp.idgraphusermanagementms.request.validator.TxnRateLimitStatusRequestValidator;
import com.att.idp.idgraphusermanagementms.resource.RegisterUserResource;
import com.att.idp.idgraphusermanagementms.resource.request.RegisterEmailUserRequest;
import com.att.idp.idgraphusermanagementms.resource.request.TransactionRateLimitRequest;
import com.att.idp.idgraphusermanagementms.resource.response.RegisterEmailUserResponse;
import com.att.idp.idgraphusermanagementms.resource.response.TransactionRateLimitResponse;
import com.att.idp.idgraphusermanagementms.service.RegisterEmailUserService;
import com.att.idp.idgraphusermanagementms.service.TxnRateLimitStatusService;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This class is an implementation of the RegisterUserResource interface.
 * It contains methods for transaction rate limit status and registering an email user.
 * It uses Spring's @Controller annotation, making it a candidate for Spring's automatic detection to discover and automatically create beans.
 * It also uses @Autowired to inject instances of TxnRateLimitStatusService, TxnRateLimitStatusRequestValidator, RegisterEmailUserRequestValidator, and RegisterEmailUserService.
 *
 * The class contains two main methods: txnRateLimitStatus and registerEmailUser. Both methods take in a request object and HttpHeaders as parameters.
 * These methods are responsible for validating the request, calling the appropriate service, and handling any exceptions that may occur.
 *
 * @author pb6583
 */
@Controller
@OpenAPIDefinition(
		info = @Info(title="User Management",
				description="IDGraphUserManagementMs provides services that are used to perform identity specific " +
						"operations like creating new accessId, registering a currently.com memberId, updating " +
						"profile attributes of the existing accessId, and fraud locking access Id. This information " +
						"gets stored in IdentityGraph database and gets provisioned/replicated to multiple systems " +
						"e.g. HALOC, Yahoo, CG, CCR, G2 etc.\n\n\n\n.", version="0.0.1"),
		servers = {
				@Server(url="https://apporigin-dev2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/"),
				@Server(url="https://apporigin-tst2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphusermanagementms/")
		})
public class RegisterUserResourceImpl implements RegisterUserResource{
	
	public static final Logger logger = LoggerFactory.getLogger(RegisterUserResourceImpl.class);

	
	@Autowired
	private TxnRateLimitStatusService txnRateLimitStatusServiceObj;
	
	@Autowired
	private TxnRateLimitStatusRequestValidator txnRateLimitStatusRequestValidatorObj;
	
	@Autowired
	private RegisterEmailUserRequestValidator registerEmailUserRequestValidatorObj;
	
	@Autowired
	private RegisterEmailUserService registerEmailUserServiceObj;
	
	@TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
			description = "transaction rate limit status",
			tags = {URI, "/msapi/idgraphusermanagementms/v1/register/txnratelimit/verify", METHOD, POST},
			histogram = true)
	@Override
	public Response txnRateLimitStatus(@Valid TransactionRateLimitRequest txnRateLimitRequestObj, HttpHeaders httpHeader)
			throws MPSException {
		
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		TransactionRateLimitResponse txnRateLimitResponseObj = null;
		long startTm = System.currentTimeMillis();

		Response responseObj = null;
		try {

			MultivaluedMap<String, String> requestHeader = httpHeader.getRequestHeaders();

			logger.info(SpiMarker.getInstance(), "WEB_01 : TransactionRateLimit Input : {} | TransactionRateLimit Request Header  : {}",
					txnRateLimitRequestObj != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(txnRateLimitRequestObj)) : null,
					requestHeader != null ? CommonUtilHelper.sanitizeForLog(String.valueOf(requestHeader)) : null);

			txnRateLimitResponseObj =txnRateLimitStatusRequestValidatorObj.txnRateLimitStatusRequestValidator(httpHeader,
					txnRateLimitRequestObj);

			logger.info("WEB000 : TransactionRateLimit Input : {}", txnRateLimitRequestObj);

			if (txnRateLimitResponseObj == null) {
				// call the service class
				txnRateLimitResponseObj = txnRateLimitStatusServiceObj.txnRateLimitStatus(txnRateLimitRequestObj,
						requestHeader);
				logger.info(SpiMarker.getInstance(), "WEB_02 : TransactionRateLimit Service Response : {}",
						txnRateLimitResponseObj);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: {}", e.getMessage());
				throw e;
			} else if (NestedExceptionUtils.getRootCause(e) instanceof SQLException) {
				hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
				hmResponse.put("ErrorEnum", ErrorMessages.MS_MPSYS_BE_304);
			} else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
				hmResponse.put("ErrorEnum", ErrorMessages.MS_MPSYS_BE_602);
			}

			hmResponse.put("idp-trace-id", txnRateLimitRequestObj.getIdpTraceId());
			txnRateLimitResponseObj = CommonUtilHelper.generateTxnRateLimitStatusResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(txnRateLimitResponseObj);
		String sTimeTaken = CommonUtilHelper.getElapsedTimeInSecs(startTm) + " seconds";

		logger.info(SpiMarker.getInstance(), "WEB999 : Total time taken : {} TransactionRateLimit Response : {}", sTimeTaken,
				txnRateLimitResponseObj);
		return responseObj;

	}
	
	
	@TimedMetrics(name = IDGRAPH_USERMANAGEMENTMS_IB, type = REST_IB,
			description = "register email user",
			tags = {URI, "/msapi/idgraphusermanagementms/v1/register/emailuser", METHOD, POST},
			histogram = true)
	@Override
	public Response registerEmailUser(@Valid RegisterEmailUserRequest registerEmailUserReq, HttpHeaders httpHeader)
			throws MPSException {
		
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		RegisterEmailUserResponse registerEmailUserRespObj = new RegisterEmailUserResponse();
		long startTm = System.currentTimeMillis();

		Response responseObj = null;
		try {

			MultivaluedMap<String, String> requestHeader = httpHeader.getRequestHeaders();

			logger.info(SpiMarker.getInstance(),"WEB_01 : RegisterEmailUser Input : {} | RegisterEmailUser Request Header  : {}",
					StringUtils.normalizeSpace(registerEmailUserReq != null ? registerEmailUserReq.toString() : null),
					StringUtils.normalizeSpace(requestHeader != null ? requestHeader.toString() : null));

			registerEmailUserRespObj = registerEmailUserRequestValidatorObj.registerEmailUserRequestValidator(httpHeader,
					registerEmailUserReq);

			logger.info(SpiMarker.getInstance(),"WEB000 : RegisterEmailUser Input : {}", registerEmailUserReq!=null?StringUtils.normalizeSpace(registerEmailUserReq.toString()):null);

			if (registerEmailUserRespObj == null) {
				// call the service class
				registerEmailUserRespObj = registerEmailUserServiceObj.registerEmailUser(registerEmailUserReq, requestHeader);
				
				logger.info(SpiMarker.getInstance(), "WEB_02 : RegisterEmailUser Service Response : {}",
						registerEmailUserRespObj);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: {}", e.getMessage());
				throw e;
			} else if (NestedExceptionUtils.getRootCause(e) instanceof SQLException) {
				hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
				hmResponse.put("ErrorEnum", ErrorMessages.MS_MPSYS_BE_304);
			} else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
				hmResponse.put("ErrorEnum", ErrorMessages.MS_MPSYS_BE_602);
			}

			registerEmailUserRespObj = CommonUtilHelper.generateRegisterEmailUserResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(registerEmailUserRespObj);
		String sTimeTaken = CommonUtilHelper.getElapsedTimeInSecs(startTm) + " seconds";

		logger.info(SpiMarker.getInstance(), "WEB999 : Total time taken : {} RegisterEmailUser Response : {}", sTimeTaken,
				registerEmailUserRespObj);
		return responseObj;
	}
	

}
