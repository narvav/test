package com.att.idp.idgraphusermanagementms.config;

import com.att.common.dbhelpers.MPSDB_GetAccesses_H;
import com.att.common.dbhelpers.MPSDB_GetDynNotifications_H;
import com.att.common.dbhelpers.MPSDB_GetLockOuts_H;
import com.att.common.dbhelpers.MPSDB_GetNotifications_H;
import com.att.common.validators.*;
import com.att.mpsys.common.helpers.AccountFraudLockHelper;
import com.att.mpsys.common.helpers.ConvertServicesHelper;
import com.att.mpsys.common.helpers.SoapHttpClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * This is an interface named ApplicationDataSourceConstant.
 * It contains constants that are used as keys for various components in the application's data source configuration.
 * These constants are used throughout the application to ensure consistency when referring to these components.
 */
@Configuration
public class CommonHelperBeanConfiguration {

	
	//RESETUSERPASSWORD BEANS - START
	@Bean
	public ConvertServicesHelper getConvertServicesHelper(){
		ConvertServicesHelper objConvertServicesHelper = new ConvertServicesHelper();
		return objConvertServicesHelper;
	}
	
	
	@Bean
	public SoapHttpClient getSoapHttpClient(){
		SoapHttpClient objSoapHttpClient = new SoapHttpClient();
		return objSoapHttpClient;
	}
	
	
	@Bean
	public LockOutValidation getLockOutValidation(){
		LockOutValidation objLockOutValidation = new LockOutValidation();
		return objLockOutValidation;
	}
	
	@Bean
	public MPSDB_GetLockOuts_H getMPSDB_GetLockOuts_H(){
		MPSDB_GetLockOuts_H objAccountFraudLockHelper = new MPSDB_GetLockOuts_H();
		return objAccountFraudLockHelper;
	}

	@Bean
	public AccountFraudLockHelper getAccountFraudLockHelper(){
		AccountFraudLockHelper oAccountFraudLockHelper = new AccountFraudLockHelper();
		return oAccountFraudLockHelper;
	}


	//RESETUSERPASSWORD BEANS - END

	@Bean
	public NotificationValidation getNotificationValidation(){
		NotificationValidation objNotificationValidation = new NotificationValidation();
		return objNotificationValidation;
	}

	@Bean
	public MPSDB_GetNotifications_H getMPSDB_GetNotifications_H(){
		MPSDB_GetNotifications_H objMPSDB_GetNotifications_H = new MPSDB_GetNotifications_H();
		return objMPSDB_GetNotifications_H;
	}

	@Bean
	public DynNotificationsValidation getDynNotificationsValidation(){
		DynNotificationsValidation objDynNotificationsValidation = new DynNotificationsValidation();
		return objDynNotificationsValidation;
	}

	@Bean
	public MPSDB_GetDynNotifications_H getMPSDB_GetDynNotifications_H(){
		MPSDB_GetDynNotifications_H objMPSDB_GetDynNotifications_H = new MPSDB_GetDynNotifications_H();
		return objMPSDB_GetDynNotifications_H;
	}

	@Bean
	public LoadStaticDataHelper objLoadStaticDataHelper(){
		LoadStaticDataHelper objLoadStaticDataHelper = new LoadStaticDataHelper();
		return objLoadStaticDataHelper;
	}

	@Bean
	public AccessValidation getAccessValidation(){
		AccessValidation objAccessValidation = new AccessValidation();
		return objAccessValidation;
	}

	@Bean
	public MPSDB_GetAccesses_H getMPSDB_GetAccesses_H(){
		MPSDB_GetAccesses_H objMPSDB_GetAccesses_H = new MPSDB_GetAccesses_H();
		return objMPSDB_GetAccesses_H;
	}

}