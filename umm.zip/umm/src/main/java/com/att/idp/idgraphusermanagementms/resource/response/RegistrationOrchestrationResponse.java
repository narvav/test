package com.att.idp.idgraphusermanagementms.resource.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This class represents the response from the registrationOrchestration API.
 * It contains the overall status, optional error details for top-level failures,
 * and a list of per-item association results.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "RegistrationOrchestrationResponse")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RegistrationOrchestrationResponse {

    /**
     * Echoed from request header.
     */
    @JsonProperty("idp-trace-id")
    private String idpTraceId;

    /**
     * Overall API result: SUCCESS, PARTIAL_SUCCESS, or FAILED.
     */
    private String status;

    /**
     * Top-level error ID. Present only for validation/system errors (no results[]).
     */
    private String errorId;

    /**
     * Top-level error message. Present only for validation/system errors.
     */
    private String message;

    /**
     * Per-item processing results. Present when processing reaches Step 3.
     */
    private List<AssociationResult> results;
}
