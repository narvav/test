package com.att.idp.idgraphusermanagementms.helper;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphusermanagementms.db.helper.InquireProfileDBHelper;
import com.att.idp.idgraphusermanagementms.db.helper.UserMergeDBHelper;
import com.att.idp.idgraphusermanagementms.message.ErrorMessages;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * The InquireProfileHelper class is a helper class that provides methods to inquire user profiles.
 * It includes methods to inquire profile, check user fraud and security info flag, check return fraud password and lockout, and others.
 * This class is annotated with @Component, meaning it is an autodetectable Spring Bean and can be automatically wired into other components using Spring's dependency injection facilities.
 */
@Component
public class InquireProfileHelper {

	private static String sClassName = "InquireProfileHelper";
	public static final Logger logger = LoggerFactory.getLogger(InquireProfileHelper.class);
	private static final String ERROR_ENUM = "ErrorEnum";
	private boolean isTransactionRollbackOnError = false;

	@Autowired
	private InquireProfileDBHelper inquireProfileDBHelperObj;

	@Autowired
	private UserMergeDBHelper userMergeDBHelperObj;

	/**
	 * This method is responsible for inquiring user profiles.
	 * It first checks if the input is null or empty, and if so, returns an error.
	 * Then, it performs a series of operations including user merge, checking user fraud and security info flags, checking return fraud password and lockout, and inquiring profile database.
	 * If any of these operations fail, it returns the corresponding error.
	 * If all operations are successful, it puts the success message into the result map.
	 *
	 * @param hmInput A Map containing the input parameters for the method. It should include the necessary information for inquiring user profiles.
	 * @return A Map containing the result of the method. It includes the application status code and other information.
	 */
	@org.springframework.transaction.annotation.Transactional
	public Map<String, Object> inquireProfile(Map<String, Object> hmInput) {
		String sMethodName = ".inquireProfile.";
		String stAppStatusCode = null;
		Map<String, Object> hmResult = null;
		String stAppInfo = null;
		logger.info("{}{}HLP000 : Input Hash : {}", sClassName, sMethodName,
				HtmlUtils.htmlEscape(String.valueOf(hmInput)));

		if (hmInput == null || hmInput.isEmpty()) {
			stAppInfo = "Input Hash is NULL";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			logger.info("{}{}IPH_100 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		try {
			// UserMergeDB
			hmResult = userMergeDB(hmInput);
			stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			} else if (stAppStatusCode == null) {
				stAppInfo = "null response from InquireProfileHelper.userMergeDB";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}IPH_05 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			// userFraudLock and userSecurityInfo flags
			hmResult = checkUserFraudAndSecurityInfoFlag(hmInput);
			stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			} else if (stAppStatusCode == null) {
				stAppInfo = "null response from InquireProfileHelper.checkUserFraudAndSecurityInfoFlag";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}IPH_108 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			// userFraudPassword and userLockOut flags
			hmResult = checkReturnFraudPwdAndLockOut(hmInput);
			stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			} else if (stAppStatusCode == null) {
				stAppInfo = "null response from InquireProfileHelper.checkReturnFraudPwdAndLockOut";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}IPH_110 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			// inquireProfileDB
			hmResult = inquireProfileDB(hmInput);
			stAppStatusCode = (String) hmResult.getOrDefault(MPSDefs.APP_STATUS_CODE, null);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				return hmResult;
			} else if (stAppStatusCode == null) {
				stAppInfo = "null response from InquireProfileHelper.inquireProfileDB";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}IPH_115 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown InquireProfile method : " + hmResult;
			logger.info("{}{}IPH_116 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));

		} finally {
			logger.info(SpiMarker.getInstance(),"InquireProfileHelper.inquireProfile.HLP999 : response from InquireProfileHelper :",
					StructuredArguments.entries(hmResult));
		}
		return hmResult;
	}
	
	private Map<String, Object> userMergeDB(Map<String, Object> hmInput) {
		Map<String, Object> hmResult = null;
		String sMethodName = ".userMergeDB.";
		String stAppInfo = null;
		String sHandle = (String) hmInput.get(CommonDefs.HANDLE);
		String sDomain = (String) hmInput.get(CommonDefs.DOMAIN);
		String sGuid = (String) hmInput.get(CommonDefs.GUID);

		if (sHandle != null && !sHandle.isEmpty() && sDomain != null && !sDomain.isEmpty()) {

			hmInput.put(CommonDefs.HANDLE, sHandle);
			hmInput.put(CommonDefs.DOMAIN, sDomain);

			if (hmInput.containsKey(CommonDefs.GUID)) {
				hmInput.remove(CommonDefs.GUID);
			}
		} else if (sGuid != null && !sGuid.isEmpty()) {

			if (hmInput.containsKey(CommonDefs.HANDLE)) {
				hmInput.remove(CommonDefs.HANDLE);
			}

			if (hmInput.containsKey(CommonDefs.DOMAIN)) {
				hmInput.remove(CommonDefs.DOMAIN);
			}

			// Query UserMerge if QUERY_USER_MERGE='Y'
			queryUserMergeDB(hmInput);

		} else {
			stAppInfo = "Either guid OR userId/domain must be present";
			logger.info("{}{}IPH_04 : {}", sClassName, sMethodName, stAppInfo);
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			return hmResult;
		}

		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}

	private void queryUserMergeDB(Map<String, Object> hmInput) {

		String sGuid = (String) hmInput.get(CommonDefs.GUID);
		String sMethodName = ".queryUserMergeDB.";

		if (hmInput.get("QUERY_USER_MERGE") != null && hmInput.get("QUERY_USER_MERGE").equals("Y")) {
			HashMap hmUMInput = new HashMap();
			hmUMInput.put("source_member_num", sGuid);

			logger.debug("{}{}IPH_01 : Calling UserMergeDBHelper.getUserMergeInfo with hminput : {}", sClassName,
					sMethodName, hmUMInput);

			HashMap hmUMResult = userMergeDBHelperObj.getUserMergeInfo(hmUMInput);

			logger.debug("{}{}IPH_02 : Response from UserMergeDBHelper.getUserMergeInfo  : {}", sClassName,
					sMethodName, hmUMResult);

			String sTargetMemNum = (String) hmUMResult.get("target_member_num");
			if (sTargetMemNum != null && !sTargetMemNum.isEmpty()) {
				logger.info("{}{}IPH_03 : source_member_num : {} and target_member_num {} ", sClassName, sMethodName,
						sGuid, sTargetMemNum);
				hmInput.put(CommonDefs.GUID, sTargetMemNum);
			}
		}
	}

	private Map<String, Object> inquireProfileDB(Map<String, Object> hmInput) {
		Map<String, Object> hmResult;
		String stAppInfo;
		String sMethodName = ".inquireProfileDB.";
		String stAppStatusCode;

		logger.debug("{}{}IPH_111 : Calling InquireProfileDBHelper.inquireProfile with hminput : {}", sClassName,
				sMethodName, hmInput);

		hmResult = inquireProfileDBHelperObj.inquireProfile(hmInput);

		/*logger.debug(SpiMarker.getInstance(),"InquireProfileHelper.inquireProfile.IPH_112 : Response from InquireProfileDBHelper.inquireProfile :",
				StructuredArguments.entries(hmResult));*/
		
		if (hmResult == null || hmResult.isEmpty()) {
			stAppInfo = "Null Response returned from InquireProfileDBHelper";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			logger.info("{}{}IPH_113 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}
		stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
		if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
			stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
			logger.info("{}{}IPH_114 : {}", sClassName, sMethodName, stAppInfo);
			hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);

			return hmResult;
		}
		hmResult.putAll(CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG));
		hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}

	private Map<String, Object> checkReturnFraudPwdAndLockOut(Map<String, Object> hmInput) {
		Map<String, Object> hmResult = null;
		String sMethodName = ".checkReturnFraudPwdAndLockOut.";
		String stAppInfo;
		String sreturnUserFraudPassword = (String) hmInput.get("returnUserFraudPassword");
		String sreturnUserLockout = (String) hmInput.get("returnUserLockout");
		if (sreturnUserFraudPassword != null && !sreturnUserFraudPassword.isEmpty()) {

			sreturnUserFraudPassword = sreturnUserFraudPassword.trim().toUpperCase();

			if (!(sreturnUserFraudPassword.equals("Y") || sreturnUserFraudPassword.equals("N"))) {
				stAppInfo = "returnUserFraudPassword " + sreturnUserFraudPassword + " must be one of Y or N";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}IPH_08 : {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
				return hmResult;
			}

			hmInput.put("returnUserFraudPassword", sreturnUserFraudPassword);

		}

		if (sreturnUserLockout != null && !sreturnUserLockout.isEmpty()) {

			sreturnUserLockout = sreturnUserLockout.trim().toUpperCase();

			if (!(sreturnUserLockout.equals("Y") || sreturnUserLockout.equals("N"))) {
				stAppInfo = "returnUserLockout " + sreturnUserLockout + " must be one of Y or N";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}IPH_09 : {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
				return hmResult;
			}

			hmInput.put("returnUserLockout", sreturnUserLockout);

		}
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}

	private Map<String, Object> checkUserFraudAndSecurityInfoFlag(Map<String, Object> hmInput) {
		Map<String, Object> hmResult = null;
		String sMethodName = ".checkUserFraudAndSecurityInfoFlag.";
		String sreturnUserFraudLock = (String) hmInput.get("returnUserFraudLock");
		String sreturnUserSecurityInfo = (String) hmInput.get("returnUserSecurityInfo");

		String stAppInfo = null;
		if (sreturnUserFraudLock != null && !sreturnUserFraudLock.isEmpty()) {

			sreturnUserFraudLock = sreturnUserFraudLock.trim().toUpperCase();

			if (!(sreturnUserFraudLock.equals("Y") || sreturnUserFraudLock.equals("N"))) {
				stAppInfo = "returnUserFraudLock " + sreturnUserFraudLock + " must be one of Y or N";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}IPH_06 : {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
				return hmResult;
			}

			hmInput.put("returnUserFraudLock", sreturnUserFraudLock);

		}
		if (sreturnUserSecurityInfo != null && !sreturnUserSecurityInfo.isEmpty()) {

			sreturnUserSecurityInfo = sreturnUserSecurityInfo.trim().toUpperCase();

			if (!(sreturnUserSecurityInfo.equals("Y") || sreturnUserSecurityInfo.equals("N"))) {
				stAppInfo = "returnUserSecurityInfo " + sreturnUserSecurityInfo + " must be one of Y or N";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}IPH_07 : {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
				return hmResult;
			}

			hmInput.put("returnUserSecurityInfo", sreturnUserSecurityInfo);

		}
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		hmResult.put(ERROR_ENUM, CommonDefs.COMMON_SUCCESS_MSG);
		return hmResult;
	}

	
}
