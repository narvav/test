package com.att.idp.idgraphusermanagementms.db.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * This is the SystemOfRecordRequest class which implements Serializable interface.
 * It represents a request for a system of record with properties like sorId, sorName, sorDesc, and sorType.
 * Each property has its respective getter and setter methods.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({

})
public class SystemOfRecordRequest implements Serializable{

	private static final long serialVersionUID = -4881055116810578801L;

	private Long sorId;
	private String sorName;
	private String sorDesc;
	private String sorType;
}