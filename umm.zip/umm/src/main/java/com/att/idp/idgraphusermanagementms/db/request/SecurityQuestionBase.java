package com.att.idp.idgraphusermanagementms.db.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SecurityQuestionBase implements Serializable {
    @JsonProperty("securityQuestionId")
    @JsonPropertyDescription("Security Question Id")
    @DecimalMin("1")
    @Valid
    Long securityQuestionId;

    @JsonProperty("securityQuestion")
    @JsonPropertyDescription("securityQuestion")
    String securityQuestion;

    @JsonProperty("securityQuestionActive")
    @JsonPropertyDescription("securityQuestion")
    char securityQuestionActive;

    @JsonProperty("securityQuestionType")
    @JsonPropertyDescription("securityQuestion")
    String securityQuestionType;
}
