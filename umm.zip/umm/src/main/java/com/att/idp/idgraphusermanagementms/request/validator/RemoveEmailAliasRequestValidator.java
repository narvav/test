package com.att.idp.idgraphusermanagementms.request.validator;

import com.att.idp.idgraphusermanagementms.resource.request.RemoveEmailAliasRequest;
import com.att.idp.idgraphusermanagementms.resource.response.CommonResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import jakarta.validation.Valid;
import jakarta.ws.rs.core.HttpHeaders;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class RemoveEmailAliasRequestValidator {

	private static final Logger logger = LoggerFactory.getLogger(RemoveEmailAliasRequestValidator.class);

	private String sClassName = "RemoveEmailAliasRequestValidator";

	@Value("${RemoveEmailAlias_CallingSystemIds}")
	private String propValidCallers;
	
	@Value("${RemoveEmailAlias_CSI_AgentIds}")
	private String propValidAgentIds;

	@Value("${RemoveEmailAlias_TransactionTypes}")
	private String propTransactionTypes;



	/**
     * Validates the RemoveEmailAliasRequest and its headers. Checks for null or empty request, required headers, unknown attributes, input validation, and CSI validation.
     * @param requestHeader HTTP headers of the request
     * @param removeEmailAliasRequest request object to validate
     * @return CommonResponse with error details if validation fails, or null if successful
     */
    public CommonResponse removeEmailAliasReqValidator(HttpHeaders requestHeader,
            @Valid RemoveEmailAliasRequest removeEmailAliasRequest) {

		String sMethodName = ".removeEmailAliasReqValidator.";
		String stAppInfo = null;
		String stIdpTraceId = null;
		String stXAttClientId = null;

		CommonResponse commonResponse = null;
		
		if (removeEmailAliasRequest == null) {
			stAppInfo = "Input Request is NULL / Empty.";
			logger.info("{}{}REARV_101 :: {}", sClassName, sMethodName, stAppInfo);
			return removeEmailAliasErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		
        stIdpTraceId = CommonUtil.getTraceId(requestHeader);

		removeEmailAliasRequest.setIdpTraceId(stIdpTraceId);

		if (requestHeader.getHeaderString("X-ATT-ClientId") != null) {
			stXAttClientId = requestHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
			String sanitizedXAttClientId = stXAttClientId.replaceAll("[\\r\\n]", "");
			logger.info("{}{}REARV_102 : Setting callingSystemId: {}", sClassName, sMethodName, sanitizedXAttClientId);
			removeEmailAliasRequest.setCallingSystemId(stXAttClientId);
		} else {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			logger.info("{}{}REARV_103 :: {}", sClassName, sMethodName, stAppInfo);
			return removeEmailAliasErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		try {
			// checking Invalid attributes passed in Request
			Map<String, Object> allUnknownAttributes = new HashMap<>(removeEmailAliasRequest.unknownAttributes);
			if (!allUnknownAttributes.isEmpty()) {
				stAppInfo = "Invalid Attributes passed in RemoveEmailAliasRequest : " + allUnknownAttributes;
				return removeEmailAliasErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						removeEmailAliasRequest.getIdpTraceId());
			}

			commonResponse = removeEmailAliasInputValidator(removeEmailAliasRequest);
			if (commonResponse != null) {
				logger.info("{}{}REARV_104 : Response from removeEmailAliasInputValidator : {}", sClassName, sMethodName,
						commonResponse);
				return commonResponse;
			}

			commonResponse = removeEmailAliasCSIValidator(removeEmailAliasRequest);
			if (commonResponse != null) {
				logger.info("{}{}REARV_105 : Response from removeEmailAliasCSIValidator : {}", sClassName, sMethodName,
						commonResponse);
				return commonResponse;
			}

			stAppInfo = "Input Validation Successful";
			logger.info("{}{}REARV_106 : {}", sClassName, sMethodName, stAppInfo);

		} catch (Exception e) {
			stAppInfo = "Exception thrown in removeEmailAliasRequestValidator : " + e.getMessage();
			logger.info("{}{}REARV_107: Exception in removeEmailAliasRequestValidator: {}", sClassName, sMethodName,
					stAppInfo);
			return removeEmailAliasErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo, stIdpTraceId);

		}

		return null;
	}

	/**
     * Validates the input fields of RemoveEmailAliasRequest. Checks transactionType, memberId, domain, normalizes values, and validates isExternalCall.
     * @param removeEmailAliasRequest request object to validate
     * @return CommonResponse with error details if validation fails, or null if successful
     */
    private CommonResponse removeEmailAliasInputValidator(@Valid RemoveEmailAliasRequest removeEmailAliasRequest) {
		CommonResponse commonResponse = null;
		String stAppInfo = null;

		String memberId = removeEmailAliasRequest.getMemberId();

		String domain = removeEmailAliasRequest.getDomain();

		String transactionType = removeEmailAliasRequest.getTransactionType();
		if (propTransactionTypes != null && !propTransactionTypes.isEmpty()) {
			ArrayList<?> alTransactionTypes = CommonUtil.parseToArray(propTransactionTypes,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			if (!alTransactionTypes.contains(transactionType)) {
				String appInfo = "Missing or invalid transactionType in request";

				return removeEmailAliasErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, appInfo,
						removeEmailAliasRequest.getIdpTraceId());
			}
		}

		if (StringUtils.isBlank(memberId)) {
			stAppInfo = "memberId is required";
			return removeEmailAliasErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, removeEmailAliasRequest.getIdpTraceId());
		}
		if (StringUtils.isBlank(domain)) {
			stAppInfo = "domain is required";
			return removeEmailAliasErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, removeEmailAliasRequest.getIdpTraceId());
		}

		removeEmailAliasRequest.setMemberId(memberId.trim().toLowerCase());
		removeEmailAliasRequest.setDomain(domain.trim().toLowerCase());



		commonResponse = removeEmailAliasIsExternalCallCheck(removeEmailAliasRequest);

		return commonResponse;

	}

	/**
     * Validates Calling System Id and Agent Id for RemoveEmailAliasRequest. Checks valid calling system ID, agent ID, and configuration presence.
     * @param removeEmailAliasRequest request object to validate
     * @return CommonResponse with error details if validation fails, or null if successful
     */
    private CommonResponse removeEmailAliasCSIValidator(@Valid RemoveEmailAliasRequest removeEmailAliasRequest) {
		String sCallingSystemId = removeEmailAliasRequest.getCallingSystemId();
		String isExternalCall = removeEmailAliasRequest.getIsExternalCall();
		String sAgentId = removeEmailAliasRequest.getAgentId();
		String sMethodName = "removeEmailAliasCSIValidator";
		String appInfo = null;

		logger.info("{}{}REARV_104.01 : Valid Callers : {}", sClassName, sMethodName, propValidCallers);
		if (propValidCallers != null && !propValidCallers.isEmpty()) {
			ArrayList<String> alValidCallers = CommonUtil.parseToArray(propValidCallers,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			if (CommonDefs.IND_Y.equalsIgnoreCase(isExternalCall) && alValidCallers != null
					&& !alValidCallers.contains(sCallingSystemId)) {
				appInfo = "Missing or invalid X-ATT-ClientId in request header";
				logger.info("{}{}REARV_104.02 :  {} ", sClassName, sMethodName, StringUtils.normalizeSpace(appInfo));
				return removeEmailAliasErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, appInfo,
						removeEmailAliasRequest.getIdpTraceId());
			}
		} else {
			appInfo = "RemoveEmailAlias CallingSystemIds config is not set";
			logger.info("{}{}REARV_104.03 : {} ", sClassName, sMethodName, appInfo);
			return removeEmailAliasErrorResponse(CErrorDefs.ERR_CONFIG_NUM, appInfo,
					removeEmailAliasRequest.getIdpTraceId());
		}
		
		ArrayList<String> alValidAgentIds = CommonUtil.parseToArray(propValidAgentIds,
				CommonDefs.VALUE_SEPARATOR_CHAR);
		if (sCallingSystemId != null && alValidAgentIds.contains(sCallingSystemId) && (sAgentId == null || sAgentId.isEmpty())) {

			appInfo = "AgentId is required for caller:" + sCallingSystemId;
			logger.info("{}{}REARV_104.04 : {}", CommonUtilHelper.sanitizeForLog(sClassName), CommonUtilHelper.sanitizeForLog(sMethodName), CommonUtilHelper.sanitizeForLog(appInfo));
			return removeEmailAliasErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, appInfo,
					removeEmailAliasRequest.getIdpTraceId());

		}

		return null;
	}

	/**
     * Creates a CommonResponse error object for RemoveEmailAlias operations. Populates response map with status code, app info, trace ID, and transaction name.
     * @param appStatusCode application status code
     * @param stAppInfo application info message
     * @param stIdpTraceId trace ID for request
     * @return CommonResponse error response
     */
    private CommonResponse removeEmailAliasErrorResponse(int appStatusCode, String stAppInfo,
			String stIdpTraceId) {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		hmResponse.put(CommonDefs.TRANSACTION_NAME, "RemoveEmailAlias");
		return CommonUtilHelper.generateCommonResponse(hmResponse);
	}

	/**
     * Validates and normalizes the isExternalCall field in RemoveEmailAliasRequest. Sets isExternalCall to 'Y' if missing, or validates it is 'Y' or 'N'.
     * @param removeEmailAliasRequest request object to validate
     * @return CommonResponse with error details if validation fails, or null if successful
     */
    private CommonResponse removeEmailAliasIsExternalCallCheck(RemoveEmailAliasRequest removeEmailAliasRequest) {
		CommonResponse commonResponse = null;
		String stAppInfo = null;
		String isExternalCall = removeEmailAliasRequest.getIsExternalCall();
		String stIdpTraceId = removeEmailAliasRequest.getIdpTraceId();

		if ((isExternalCall != null && !isExternalCall.isEmpty())) {
			if (!(isExternalCall.equalsIgnoreCase(CommonDefs.IND_Y)
					|| isExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
				stAppInfo = "isExternalCall must be one of Y or N";
				return removeEmailAliasErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			} else {
				removeEmailAliasRequest.setIsExternalCall(isExternalCall.trim().toUpperCase());
			}
		} else {
			removeEmailAliasRequest.setIsExternalCall(CommonDefs.IND_Y);
		}
		return commonResponse;
	}

}
