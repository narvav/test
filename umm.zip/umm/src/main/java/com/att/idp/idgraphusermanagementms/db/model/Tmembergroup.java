package com.att.idp.idgraphusermanagementms.db.model;

import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TMEMBERGROUP", schema = "MPS_OWNER", uniqueConstraints = @UniqueConstraint(columnNames = { "PARENT_NAME", "DOMAIN_ID" }))
public class Tmembergroup implements java.io.Serializable {

	private static final long serialVersionUID = -3057124733167198053L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "GROUP_NUM", unique = true, nullable = false, precision = 22, scale = 0)
	private Long groupNum;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DOMAIN_ID", nullable = false)
	private Tdomain tdomain;

	@Column(name = "PARENT_NAME", nullable = false, length = 127)
	private String parentName;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;

	@Column(name = "PREMIUM_800_IND", length = 1)
	private Character premium800Ind;

	@Column(name = "BULK_BILLING_IND", length = 1)
	private Character bulkBillingInd;

	@Column(name = "ACCESS_CODE", length = 20)
	private String accessCode;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tmembergroup")
	private Set<Tmember> tmembers = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tmembergroup")
	private Set<Tmemberservice> tmemberservices = new HashSet<>(0);
}