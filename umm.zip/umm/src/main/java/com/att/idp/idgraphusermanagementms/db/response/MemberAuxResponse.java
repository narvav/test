package com.att.idp.idgraphusermanagementms.db.response;

import java.io.Serializable;
import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * This is the MemberAuxResponse class which implements Serializable interface.
 * It represents a response for a member auxiliary with properties like encPasswordVenc, md5PasswordVenc, sha1PasswordVenc, des3PasswordVenc, sshaPasswordVenc, securityAnswer1Venc, securityAnswer2Venc, createDate, lastModifiedPw, lastModifiedSec, recentFraudPwDate, passwordVenc, and passwordType.
 * Each property has its respective getter and setter methods.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({
})
public class MemberAuxResponse implements Serializable {

	private static final long serialVersionUID = 2996627929324127646L;

	private String encPasswordVenc;
	private String md5PasswordVenc;
	private String sha1PasswordVenc;
	private String des3PasswordVenc;
	private String sshaPasswordVenc;
	private String securityAnswer1Venc;
	private String securityAnswer2Venc;
	private Date createDate;
	private Date lastModifiedPw;
	private Date lastModifiedSec;
	private Date recentFraudPwDate;
	private String passwordVenc;
	private String passwordType;
}