package com.att.idp.idgraphusermanagementms.exceptions;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.idp.idgraphusermanagementms.model.ErrorMessage;
import com.att.mpsys.common.utils.CommonDefs;

/**
 * This is the InvalidInputDataException class which extends RuntimeException and implements Serializable interface.
 * It represents an exception that is thrown when invalid input data is encountered.
 * It has properties like errorMessage and errorHashMap.
 * It has three constructors:
 * 1. A constructor that takes a message as an argument.
 * 2. A constructor that takes a message and an ErrorMessage object as arguments.
 * 3. A constructor that takes a Map object as an argument.
 */
public class InvalidInputDataException extends RuntimeException implements Serializable{

	private static final long serialVersionUID = -8606161666751198322L;
	
	public static final Logger logger = LoggerFactory.getLogger(InvalidInputDataException.class);

	/**
	 * The ErrorMessage object associated with this InvalidInputDataException.
	 * This property is used to store detailed error information when the exception is thrown.
	 */
	public ErrorMessage errorMessage;
	
	/**
	 * The errorHashMap property of the InvalidInputDataException class.
	 * This property is used to store a map of error details when the exception is thrown.
	 */
	public Map errorHashMap;
	
	/**
	 * This is a constructor for the InvalidInputDataException class.
	 * It takes a message as an argument and passes it to the superclass constructor.
	 * The message typically contains details about the invalid input data that caused the exception.
	 *
	 * @param message The detail message for the exception.
	 */
	public InvalidInputDataException(String message){
		super(message);
	}
	
	/**
	 * This is a constructor for the InvalidInputDataException class.
	 * It takes a message and an ErrorMessage object as arguments.
	 * The message is passed to the superclass constructor and the ErrorMessage object is assigned to the errorMessage property of this class.
	 * The message typically contains details about the invalid input data that caused the exception.
	 * The ErrorMessage object typically contains detailed error information when the exception is thrown.
	 *
	 * @param message The detail message for the exception.
	 * @param errorMessage The ErrorMessage object associated with this exception.
	 */
	public InvalidInputDataException(String message, ErrorMessage errorMessage){
		super(message);
		this.errorMessage = errorMessage;
//		logger.error(" InvalidInputDataException class :: " + errorMessage);
	}
	
	/**
	 * This is a constructor for the InvalidInputDataException class.
	 * It takes a Map object as an argument.
	 * The Map object typically contains a set of key-value pairs that represent error details.
	 * The message for the superclass constructor is retrieved from the Map object using the key 'COMMON_APP_STATUS_MSG'.
	 * The Map object is then assigned to the errorHashMap property of this class.
	 *
	 * @param hmResponse The Map object containing error details.
	 */
	public InvalidInputDataException(Map hmResponse){
		super((String)hmResponse.get(CommonDefs.COMMON_APP_STATUS_MSG));
		this.errorHashMap = hmResponse;
		
		//this.errorMessage = errorMessage;
	}

}
