package com.att.idp.idgraphusermanagementms.request.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import jakarta.validation.Valid;
import jakarta.ws.rs.core.HttpHeaders;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphusermanagementms.resource.request.UnlinkMemberIdRequest;
import com.att.idp.idgraphusermanagementms.resource.response.CommonResponse;
import com.att.idp.idgraphusermanagementms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;

/**
 * This class, UnlinkMemberIdRequestValidator, is responsible for validating the UnlinkMemberIdRequest.
 * It checks for the presence and validity of required fields in the request, and returns a CommonResponse accordingly.
 * It is annotated with @Component, @Configuration, and @PropertySource to indicate that it's a Spring Bean,
 * to allow it to access configuration properties, and to specify the location of the properties file respectively.
 *
 * The class contains several methods, including:
 * - unlinkMemberReqValidator: the main method that orchestrates the validation process.
 * - unlinkMemberInputValidator: a method that validates the input fields in the request.
 * - unlinkMemberCSIValidator: a method that validates the 'CSI' field in the request.
 * - unlinkMemberErrorResponse: a helper method that generates an error response.
 * - unlinkMemberIsExternalCallCheck: a method that checks if the request is an external call.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/userMgmt.properties")
public class UnlinkMemberIdRequestValidator {

	private static final Logger logger = LoggerFactory.getLogger(UnlinkMemberIdRequestValidator.class);

	private String sClassName = "UnlinkMemberIdRequestValidator";

	@Value("${unlinkMemberCallingSystemIds}")
	private String propValidCallers;
	
	@Value("${unlinkMemberCSIAgentIds}")
	private String propValidAgentIds;

	/**
	 * This method is responsible for validating the UnlinkMemberIdRequest.
	 * It takes HttpHeaders and UnlinkMemberIdRequest as parameters.
	 * HttpHeaders contains the request headers which may include additional information required for processing the request.
	 * UnlinkMemberIdRequest encapsulates the details of the unlink member id operation to be performed.
	 *
	 * The method performs various checks and validations on the input parameters and returns a CommonResponse object.
	 * The CommonResponse object encapsulates the result of the unlink member id operation.
	 *
	 * @param requestHeader The HttpHeaders containing the request headers.
	 * @param unlinkMemberIdRequest The UnlinkMemberIdRequest containing the details of the unlink member id operation.
	 * @return CommonResponse The response of the unlink member id operation.
	 */
	public CommonResponse unlinkMemberReqValidator(HttpHeaders requestHeader,
			@Valid UnlinkMemberIdRequest unlinkMemberIdRequest) {

		String sMethodName = ".unlinkMemberReqValidator.";
		String stAppInfo = null;
		String stIdpTraceId = null;
		String stXAttClientId = null;

		CommonResponse commonResponse = null;
		
		if (unlinkMemberIdRequest == null) {
			stAppInfo = "Input Request is NULL / Empty.";
			logger.info("{}{}UMIRV_101 :: {}", sClassName, sMethodName, stAppInfo);
			return unlinkMemberErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		
        stIdpTraceId = CommonUtil.getTraceId(requestHeader);
		
		if(stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
			stAppInfo = "Missing or Invalid IdpTraceId";
			return unlinkMemberErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
			

		unlinkMemberIdRequest.setIdpTraceId(stIdpTraceId);

		if (requestHeader.getHeaderString("X-ATT-ClientId") != null) {
			stXAttClientId = requestHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
			logger.info("{}{}UMIRV_103.1 : Setting callingSystemId: {}", sClassName, sMethodName, stXAttClientId);
			unlinkMemberIdRequest.setCallingSystemId(stXAttClientId);
		} else {
			stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			logger.info("{}{}UMIRV_103.2 :: {}", sClassName, sMethodName, stAppInfo);
			return unlinkMemberErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		// checking Invalid attributes passed in Request
		Map<String, Object> allUnknownAttributes = new HashMap<>(unlinkMemberIdRequest.unknownAttributes);

		if (!allUnknownAttributes.isEmpty()) {
			stAppInfo = "Invalid Attributes passed in UnlinkMemberIdRequest : " + allUnknownAttributes;
			return unlinkMemberErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					unlinkMemberIdRequest.getIdpTraceId());
		}

		try {
			commonResponse = unlinkMemberInputValidator(unlinkMemberIdRequest, requestHeader);
			if (commonResponse != null) {
				logger.info("{}{}UMIRV_104 : Response from unlinkMemberInputValidator : {}", sClassName, sMethodName,
						commonResponse);
				return commonResponse;
			}

			commonResponse = unlinkMemberCSIValidator(unlinkMemberIdRequest);
			if (commonResponse != null) {
				logger.info("{}{}UMIRV_105 : Response from unlinkMemberrCSIValidator : {}", sClassName, sMethodName,
						commonResponse);
				return commonResponse;
			}

			stAppInfo = "Input Validation Successful";
			logger.info("{}{}UMIRV_106 : {}", sClassName, sMethodName, stAppInfo);

		} catch (Exception e) {
			stAppInfo = "Exception thrown in unlinkMemberIdRequestValidator : " + e.getMessage();
			commonResponse = unlinkMemberErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo, stIdpTraceId);
			logger.info("{}{}UMIRV_107: Exception in unlinkMemberIdRequestValidator: {}", sClassName, sMethodName,
					stAppInfo);
		}

		return null;
	}

	private CommonResponse unlinkMemberInputValidator(@Valid UnlinkMemberIdRequest unlinkMemberIdRequest,
			HttpHeaders requestHeader) {
		CommonResponse commonResponse = null;
		String sMethodName = "unlinkMemberInputValidator";
		String stAppInfo = null;
		String sAccessId = unlinkMemberIdRequest.getAccessId();
		String memberId = unlinkMemberIdRequest.getMemberId();
		String sIsExternalCall = unlinkMemberIdRequest.getIsExternalCall();
		String domain = unlinkMemberIdRequest.getDomain();
		String res2Bus = unlinkMemberIdRequest.getRes2bus();
		String agentId = unlinkMemberIdRequest.getAgentId();

		Optional.ofNullable(sAccessId).ifPresent(x -> unlinkMemberIdRequest.setAccessId(x.trim().toLowerCase()));
		Optional.ofNullable(memberId).ifPresent(x -> unlinkMemberIdRequest.setMemberId(x.trim().toLowerCase()));
		Optional.ofNullable(sIsExternalCall).ifPresent(x -> unlinkMemberIdRequest.setIsExternalCall(x.trim().toUpperCase()));
		Optional.ofNullable(domain).ifPresent(x -> unlinkMemberIdRequest.setDomain(x.trim().toLowerCase()));
		Optional.ofNullable(res2Bus).ifPresent(x -> unlinkMemberIdRequest.setRes2bus(x.trim().toUpperCase()));
		Optional.ofNullable(agentId).ifPresent(x -> unlinkMemberIdRequest.setAgentId(x.trim().toLowerCase()));

		commonResponse = unlinkMemberIsExternalCallCheck(unlinkMemberIdRequest);

		return commonResponse;

	}

	private CommonResponse unlinkMemberCSIValidator(@Valid UnlinkMemberIdRequest unlinkMemberIdRequest) {
		String sCallingSystemId = unlinkMemberIdRequest.getCallingSystemId();
		String isExternalCall = unlinkMemberIdRequest.getIsExternalCall();
		String sAgentId = unlinkMemberIdRequest.getAgentId();
		String sMethodName = "unlinkMemberCSIValidator";
		String appInfo = null;

		logger.info("{}{}UMIRV.CSIV.01 : Valid Callers : {}", sClassName, sMethodName, propValidCallers);
		if (propValidCallers != null && !propValidCallers.isEmpty()) {
			ArrayList<String> alValidCallers = CommonUtil.parseToArray(propValidCallers,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			if (CommonDefs.IND_Y.equalsIgnoreCase(isExternalCall) && alValidCallers != null
					&& !alValidCallers.contains(sCallingSystemId)) {
				appInfo = "Missing or invalid X-ATT-ClientId in request header";
				logger.info("{}{}UMIRV.CSIV.02 :  {} ", sClassName, sMethodName, appInfo);
				return unlinkMemberErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, appInfo,
						unlinkMemberIdRequest.getIdpTraceId());
			}
		} else {
			appInfo = "UnlinkMemberId CallingSystemIds config is not set";
			logger.info("{}{}UMIRV.CSIV.03 : {} ", sClassName, sMethodName, appInfo);
			return unlinkMemberErrorResponse(CErrorDefs.ERR_CONFIG_NUM, appInfo,
					unlinkMemberIdRequest.getIdpTraceId());
		}
		
		ArrayList<String> alValidAgentIds = CommonUtil.parseToArray(propValidAgentIds,
				CommonDefs.VALUE_SEPARATOR_CHAR);
		if (sCallingSystemId != null && alValidAgentIds != null && alValidAgentIds.contains(sCallingSystemId)
				&& (sAgentId == null || sAgentId.isEmpty())) {

			appInfo = "AgentId is required for caller:" + sCallingSystemId;
			logger.info("{}{}UMIRV.CSIV.04 : {}", sClassName, sMethodName, StringUtils.normalizeSpace(appInfo));
			return unlinkMemberErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, appInfo,
					unlinkMemberIdRequest.getIdpTraceId());

		}

		return null;
	}

	private CommonResponse unlinkMemberErrorResponse(int appStatusCode, String stAppInfo,
			String stIdpTraceId) {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		hmResponse.put(CommonDefs.TRANSACTION_NAME, "UnlinkMemberId");
		return CommonUtilHelper.generateCommonResponse(hmResponse);
	}

	private CommonResponse unlinkMemberIsExternalCallCheck(UnlinkMemberIdRequest unlinkMemberIdRequest) {
		CommonResponse commonResponse = null;
		String stAppInfo = null;
		String isExternalCall = unlinkMemberIdRequest.getIsExternalCall();
		String stIdpTraceId = unlinkMemberIdRequest.getIdpTraceId();

		if ((isExternalCall != null && !isExternalCall.isEmpty())) {
			if (!(isExternalCall.equalsIgnoreCase(CommonDefs.IND_Y)
					|| isExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
				stAppInfo = "isExternalCall must be one of Y or N";
				return unlinkMemberErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			} else {
				unlinkMemberIdRequest.setIsExternalCall(isExternalCall.trim().toUpperCase());
			}
		} else {
			unlinkMemberIdRequest.setIsExternalCall(CommonDefs.IND_Y);
		}
		return commonResponse;
	}

}
