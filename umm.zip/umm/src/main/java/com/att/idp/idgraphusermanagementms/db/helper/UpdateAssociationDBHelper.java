package com.att.idp.idgraphusermanagementms.db.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphusermanagementms.metrics.ErrorMetricHandler;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This class, UpdateAssociationDBHelper, is responsible for updating associations in the database.
 * It uses Spring's JdbcTemplate for database operations.
 *
 * The class is annotated with @Component, meaning that Spring will automatically create an instance of this class and manage it.
 * The @Autowired annotation is used to automatically inject instances of other classes like JdbcTemplate.
 *
 * The main method in this class is:
 * - updateAssociation: This method updates an association in the database. It takes a HashMap as input and returns a HashMap as output.
 *   The input HashMap contains key-value pairs for various association attributes like member number, service id, sor id, sor invariant id, reset passcode, and calling system id.
 *   The method first checks if the jdbcTemplate is null. If it is, it returns an error status.
 *   Then it retrieves the association attributes from the input HashMap.
 *   If the association attributes are not found, it returns an error status.
 *   Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
 *   Finally, it returns a status indicating whether the operation was successful or not.
 *
 * - wirelineUserCheckKey: This method checks if a given key is either passcode venc or last modified by. It takes a string as input and returns a boolean as output.
 *   The method compares the input string with passcode venc and last modified by. If the input string matches either of them, it returns true. Otherwise, it returns false.
 */
@Component
public class UpdateAssociationDBHelper {

	private static final String info = "$Id: master/com/att/corpops/frma/dhelpers/UpdateAssociationDBHelper.java v1 2020-04-28 kc2039 $;";

	private static String sClassName = "UpdateAssociationDBHelper";

	public static final Logger log = LoggerFactory.getLogger(UpdateAssociationDBHelper.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	/**
	 * This method updates an association in the database.
	 * It takes a HashMap as input which contains key-value pairs for various association attributes like member number, service id, sor id, sor invariant id, reset passcode, and calling system id.
	 * The method first checks if the input HashMap is null or if it contains invalid data. If it does, it returns an error status.
	 * Then it retrieves the association attributes from the input HashMap.
	 * If the association attributes are not found, it returns an error status.
	 * Otherwise, it prepares a list of parameters for the SQL query and executes the query using the jdbcTemplate.
	 * Finally, it returns a status indicating whether the operation was successful or not.
	 *
	 * @param hmInput A HashMap containing the details of the association to be updated.
	 * @return A HashMap containing the status of the operation and the updated association's information.
	 */
	public HashMap updateAssociation(HashMap hmInput) {

		String sMethodName = ".UpdateAssociation.";
		List<Object> objectList = CommonUtil.getArrayList();
		StringBuilder query = new StringBuilder();
		String stAppInfo = null;
		HashMap hmResult = null;
		HashMap hmWireLineUser = null;
		boolean isEmpty = false;

		log.info("{}{}DBTOOLS01 : CVS KEYWORDS: {}", sClassName, sMethodName, info);
		log.info("{}{}DBTOOLS000 :Input Hash is: {}", sClassName, sMethodName, hmInput);

		try {

			if (hmInput == null || hmInput.isEmpty()) {
				stAppInfo = "hmInput is null";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, stAppInfo);
				log.info("{}{} DBTOOLS02 :  {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			HashMap hmService = (HashMap) hmInput.get(CommonDefs.SERVICE);

			String sSorId = (String) hmService.get(MPSDefs.DB_SOR_ID);
			String sServiceId = (String) hmService.get(MPSDefs.DB_SERVICE_ID);
			String sSorInvariantId = (String) hmService.get(MPSDefs.DB_SOR_INVARIANT_ID);
			String sResetPasscode = (String) hmService.get(CommonDefs.RESETPASSCODE);
			String sMemberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

			if (sMemberNum == null || sMemberNum.isEmpty() || sSorId == null || sServiceId == null
					|| sSorInvariantId == null || sCallingSystemId == null) {
				isEmpty = true;
			}
			if (isEmpty) {

				stAppInfo = "Required feild is Empty";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				log.info("{}{} DBTOOLS03 :  {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			hmWireLineUser = new HashMap();
			hmWireLineUser.put(MPSDefs.DB_MEMBER_NUM, sMemberNum);
			hmWireLineUser.put(MPSDefs.DB_SOR_ID, sSorId);
			hmWireLineUser.put(MPSDefs.DB_SERVICE_ID, sServiceId);
			hmWireLineUser.put(MPSDefs.DB_SOR_INVARIANT_ID, sSorInvariantId);

			if (sResetPasscode.equals("Y")) {
				hmWireLineUser.put(MPSDefs.DB_PASSCODE_VENC, null);
				hmWireLineUser.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);
			}
			query = new StringBuilder(" UPDATE WIRELINEUSER SET DATE_VERIFIED = SYSDATE, ");

			String whereClause = null;
			java.util.List<String> argsKeys = new ArrayList<>();
			java.util.List<String> argsVals = new ArrayList<>();
			java.util.List<String> keys = new ArrayList<>();

			hmWireLineUser.forEach((k, v) -> {
				if (wirelineUserCheckKey((String) k)) {
					argsKeys.add(k + " = ?");
					argsVals.add((String) v);
					keys.add((String) k);
				}
			});
			int len = argsKeys.size();
			int i;
			for (i = 0; i < len; i++) {
				query.append(argsKeys.get(i));
				if (i != (len - 1)) {
					query.append(" , ");
				}
			}
			whereClause = " MEMBER_NUM = ? AND SERVICE_ID = ? AND SOR_INVARIANT_ID = ? AND SOR_ID = ? ";
			query.append(" WHERE " + whereClause);

			for (i = 0; i < argsVals.size(); i++) {
				String sKey = keys.get(i);
				if (sKey.equals(MPSDefs.DB_PASSCODE_VENC)) {
					objectList.add("");
				} else {
					objectList.add(argsVals.get(i));
				}
			}
			objectList.add(sMemberNum);
			objectList.add(sServiceId);
			objectList.add(sSorInvariantId.trim());
			objectList.add(sSorId);

			int iCount = jdbcTemplate.update(new String(query), objectList.toArray(new Object[objectList.size()]));
			log.info("{}{}DBTOOLS04 :No of rows Updated:= {}", sClassName, sMethodName, iCount);

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
					"WIRELINEUSER attributes updated successfully with count" + iCount);
			return hmResult;
		} catch (Exception e) {
			errorMetricHandler.recordDbErrorMetric();
			hmResult = CommonErrorMap.makeExceptionMap(e);
			log.error("{}{}DBTOOLS05 :  Error::{}", sClassName, sMethodName, e.getMessage());
			log.error("{}{}DBTOOLS06 : Exception = {}", sClassName, sMethodName, e);

		} finally {
			log.info(SpiMarker.getInstance(),"{}{}DBTOOLS999: response : {}", sClassName, sMethodName, hmResult);
		}
		return hmInput;
	}

	    /**
     * Inserts a new WIRELINEUSER row.
     * Expected keys: MEMBER_NUM, SERVICE_ID, SOR_ID, SOR_INVARIANT_ID, PASSCODE, PASSCODE_VENC,
     * LAST_MODIFIED_BY (or CALLING_SYSTEM_ID as fallback).
     */
    public HashMap addWirelineUser(HashMap hmInput) {
        String sMethodName = ".addWirelineUser.";
        HashMap hmResult;
        if (hmInput == null || hmInput.isEmpty()) {
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, "hmInput is null");
            log.info("{}{} DBTOOLS_AWU_01 : {}", sClassName, sMethodName, hmResult);
            return hmResult;
        }
        if (jdbcTemplate == null) {
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "jdbcTemplate is null");
            log.error("{}{} DBTOOLS_AWU_02 : {}", sClassName, sMethodName, hmResult);
            return hmResult;
        }

        String memberNum = (String) hmInput.get(MPSDefs.DB_MEMBER_NUM);
        String serviceId = (String) hmInput.get(MPSDefs.DB_SERVICE_ID);
        String sorId = (String) hmInput.get(MPSDefs.DB_SOR_ID);
        String sorInvariantId = (String) hmInput.get(MPSDefs.DB_SOR_INVARIANT_ID);
        String passcode = (String) hmInput.get(MPSDefs.DB_PASSCODE);
        String passcodeVenc = (String) hmInput.get(MPSDefs.DB_PASSCODE_VENC);
        String lastModifiedBy = (String) hmInput.get(MPSDefs.DB_LAST_MODIFIED_BY);
        if (lastModifiedBy == null || lastModifiedBy.isEmpty()) {
            lastModifiedBy = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
        }

        if (memberNum == null || serviceId == null || sorId == null || sorInvariantId == null || lastModifiedBy == null) {
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, "Required field is missing for wireline insert");
            log.info("{}{} DBTOOLS_AWU_03 : {}", sClassName, sMethodName, hmResult);
            return hmResult;
        }

        String insertSql = "INSERT INTO WIRELINEUSER (MEMBER_NUM, SERVICE_ID, SOR_ID, SOR_INVARIANT_ID, PASSCODE, PASSCODE_VENC, LAST_MODIFIED_BY, DATE_VERIFIED) " +
                           "VALUES (?,?,?,?,?,?,?,SYSDATE)";

        try {
            int count = jdbcTemplate.update(insertSql, memberNum, serviceId, sorId, sorInvariantId, passcode, passcodeVenc, lastModifiedBy);
            log.info("{}{} DBTOOLS_AWU_04 : rows inserted = {}", sClassName, sMethodName, count);
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
        } catch (Exception e) {
            hmResult = CommonErrorMap.makeExceptionMap(e);
            log.error("{}{} DBTOOLS_AWU_05 : Error::{}", sClassName, sMethodName, e.getMessage(), e);
        }
        return hmResult;
    }
	
	/**
	 * This method checks if a given key is either 'passcode venc' or 'last modified by'.
	 * It takes a string as input and compares it with 'passcode venc' and 'last modified by'.
	 * If the input string matches either of them, it returns true. Otherwise, it returns false.
	 *
	 * @param key The string to be checked if it matches 'passcode venc' or 'last modified by'.
	 * @return A boolean indicating whether the input string matches 'passcode venc' or 'last modified by'.
	 */
	public static boolean wirelineUserCheckKey(String key) {

		if ((key.equalsIgnoreCase(MPSDefs.DB_PASSCODE_VENC)) || (key.equalsIgnoreCase(MPSDefs.DB_LAST_MODIFIED_BY))) {
			return true;
		} else
			return false;
	}
}
