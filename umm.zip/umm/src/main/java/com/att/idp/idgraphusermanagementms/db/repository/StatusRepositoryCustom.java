package com.att.idp.idgraphusermanagementms.db.repository;

/**
 * This is a custom repository interface for status related operations.
 * Additional methods for status operations should be declared here.
 */
public interface StatusRepositoryCustom {
	
}
