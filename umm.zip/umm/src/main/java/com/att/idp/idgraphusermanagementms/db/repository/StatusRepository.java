package com.att.idp.idgraphusermanagementms.db.repository;

import java.sql.SQLException;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.att.idp.idgraphusermanagementms.db.model.Tstatus;

/**
 * This is the main repository interface for status related operations.
 * It extends JpaRepository for standard CRUD operations and StatusRepositoryCustom for custom operations.
 * The entity associated with this repository is Tstatus and the ID type is Long.
 */
@Repository 
public interface StatusRepository extends JpaRepository<Tstatus, Long>, StatusRepositoryCustom {

	/**
	 * This method is used to retrieve the status code for a given status name from the database.
	 *
	 * @param statusName A string representing the status name for which the status code is to be retrieved.
	 * @return A Long representing the status code associated with the given status name.
	 * @throws SQLException If there is an error while executing the SQL query.
	 */
	@Query(value = "select status.statusCode from Tstatus status where status.statusName=:statusName")
	public Long getStatusId(@Param(value = "statusName") String statusName) throws SQLException;
}