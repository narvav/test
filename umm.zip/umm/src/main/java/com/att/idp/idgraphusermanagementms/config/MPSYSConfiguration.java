package com.att.idp.idgraphusermanagementms.config;

import jakarta.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

/**
 * This is a class named MPSYSConfiguration.
 * It is annotated with @Configuration to indicate that it is a source of bean definitions for the application context.
 * The class has an EntityManager field which is autowired, meaning that Spring will automatically inject an instance of EntityManager into this field.
 * EntityManager is an interface in JPA that is used to interact with the persistence context.
 */
@Configuration
public class MPSYSConfiguration {

	@Autowired
	private EntityManager entityManager;
}
