# AGENTS.md — IdGraphUserManagementMs

> **Purpose**: Quick-reference for AI agents and developers working in this repository.
> **Repo**: `ATT-DP1/apm0045194-idgraph-idgraphusermanagementms` | **Service**: `IdGraphUserManagementMs` | **Domain**: IDGraph Platform (APM apm0045194)
> **SDK**: `sdk-java-parent 3.0.1` | **Java 17 / Spring Boot 3.x** | **Base Path**: `/msapi/idgraphusermanagementms/v1` | **Last Updated**: 2026-08-03

---

## Build Commands

```bash
# Full build with unit tests
mvn clean install

# Build — skip tests
mvn clean install -DskipTests

# Unit tests only (default profile)
mvn clean test

# Integration tests
mvn clean verify -P integration-test

# Run locally with local profile
mvn spring-boot:run -Dspring-boot.run.profiles=local

# Docker image build (Spotify plugin)
mvn clean package -DskipTests

# Test summary
./sum_junit_tests.sh

# Code coverage report (generated under target/site/jacoco/)
mvn clean verify
```

---

## Key File Paths

| Path | Purpose |
|------|---------|
| `src/main/java/com/att/idp/idgraphusermanagementms/Application.java` | Spring Boot entry point |
| `src/main/java/.../config/` | All `@Configuration` classes (DB, JMS, SOAP, Jersey, Cache, Azure App Config) |
| `src/main/java/.../resource/impl/` | JAX-RS resource implementations (12 classes) |
| `src/main/java/.../request/validator/` | Request validators — one per endpoint (24 classes) |
| `src/main/java/.../service/impl/` | Service implementations (25 classes) |
| `src/main/java/.../helper/` | Business logic helpers (34 top-level classes + `resetuserpassword/`, `voltage/`) |
| `src/main/java/.../db/helper/` | Oracle JPA/Hibernate DB helpers (35 classes) |
| `src/main/java/.../queue/message/helpers/` | IBM MQ queue message builders (12 classes) |
| `src/main/java/.../queue/message/sender/JMSQueueSender.java` | JMS event publisher |
| `src/main/java/.../integration/` | `MPSYSInternalRestClient`, `RegistrationOrchestrationRestClient` (MS-to-MS REST calls) |
| `src/main/java/.../exceptions/` | Exception mappers (5 classes) |
| `src/main/resources/schemas/` | WSDL/XSD for MPS MergeSLIDProfile SOAP |
| `src/main/resources/errormessages.properties` | Error message catalog |
| `src/test/groovy/` | Spock BDD unit + component tests |
| `src/test/java/` | JUnit 5 unit tests |
| `src/test/ist/` | Integration/IST test configs |
| `opt/ajsc/etc/config/application.properties` | Main runtime config |
| `opt/ajsc/etc/config/userMgmt.properties` | User management specific properties |
| `opt/ajsc/etc/config/logback.xml` | Logging configuration |
| `opt/ajsc/etc/config/masking.properties` | PII field masking rules |
| `opt/ajsc/etc/config/security-filter-config.yaml` | AAF CADI security filter |
| `opt/ajsc/etc/config/rilhrs-bad-word-data/` | Profanity word list files |
| `idpsecretsloader.yaml` | Azure Key Vault secret definitions |
| `Jenkinsfile` | Jenkins CI/CD pipeline definition |
| `.github/workflows/ci.yaml` | GitHub Actions CI (reusable `v1-java-svc` workflow) |
| `opt/ajsc/etc/config/entra-authz-rules.yaml` | Entra ID OAuth2 RBAC rules |
| `pom.xml` | Maven build — parent: `sdk-java-parent 3.0.1` |

---

## Coding Conventions

### Language & Framework
- **Java 17** — use `var` where it aids readability; records not yet in use
- **Spring Boot 3.x** with `sdk-java-parent 3.0.1`
- **JAX-RS (Jersey)** — NOT Spring MVC; all REST resources implement an interface + `ResourceImpl`
- **Lombok** — use `@RequiredArgsConstructor` + `private final` for injection; **never `@Autowired` on fields**; use `@Getter`, `@Builder`; avoid `@Data`
- **Constructor injection mandatory** — if `@Qualifier` is needed, write a manual constructor

### Naming Conventions
| Layer | Suffix | Example |
|-------|--------|---------|
| JAX-RS Resource Interface | `Resource` | `UserProfileResource` |
| JAX-RS Resource Impl | `ResourceImpl` | `UserProfileResourceImpl` |
| Request Validator | `RequestValidator` | `AddUserRequestValidator` |
| Service Interface | `Service` | `AddUserService` |
| Service Implementation | `ServiceImpl` | `AddUserServiceImpl` |
| Business Helper | `Helper` | `AddUserHelper` |
| DB Helper | `DBHelper` | `AddMemberDBHelper` |
| Queue Helper | `QueueHelper` | `AddUserQueueHelper` |
| Request DTO | `Request` | `AddUserRequest` |
| Response DTO | `Response` | `AddUserResponse` |
| Constants | `Constants` | `LogInformationConstants` |

### Hard-Stops (IDGraph + OMNI rules)
- **No `@Autowired` on fields** — constructor injection only
- **No hardcoded strings** — use `*Constants.java` or `application.properties`
- **No empty catch blocks** — every `catch` must log and handle
- **No `System.out.println`** — structured logging via `log.info`, `log.error`, etc.
- **No raw exceptions to API consumers** — use `MPSException` / `InvalidInputDataException` + exception mappers
- **No PII/passwords in logs** — use ESAPI sanitization for external values; rely on `masking.properties`
- **No wildcard imports** — all imports must be explicit
- **Every endpoint MUST have a dedicated `RequestValidator`** — no business logic in Resource layer
- **`CommonErrorMap` + `CErrorDefs`** for all error response construction (via `IDGraphCommonHelper`)
- Use `idp-trace-id` as the correlation header — propagate to all downstream calls
- Register new `ResourceImpl` classes in `JerseyConfiguration`

---

## Domain-Specific Patterns

### Request Lifecycle (Every Endpoint)
```
HTTP Request
  → ResourceImpl (JAX-RS)
  → RequestValidator (validate headers + body)
  → ServiceImpl (orchestrate business logic)
  → Helper (core logic, DB interaction, external calls)
  → DBHelper (Oracle JPA/Hibernate)
  → QueueHelper → JMSQueueSender (async IBM MQ event)
  ← Response DTO
```

### Adding a New Endpoint — Checklist
1. Define method in `Resource` interface with JAX-RS + OpenAPI 3 annotations
2. Implement in corresponding `ResourceImpl`
3. Create `RequestValidator` in `request/validator/`
4. Create `Service` interface + `ServiceImpl`
5. Create `Helper` for business logic
6. If async event needed: create `QueueHelper` in `queue/message/helpers/`
7. Register `ResourceImpl` in `JerseyConfiguration`
8. Add Spock + JUnit tests
9. Update JaCoCo exclusions in `pom.xml` if needed

### IBM MQ Event Publishing
- Every state-changing operation publishes an async event via `JMSQueueSender`
- Queue routing is hash-based using `mainHashKey` across multiple queue instances
- Primary + failover MQ host; retry 3 attempts
- `PublishMqAehHelper` also coordinates with Azure Event Hub publishing

### Secret Loading Sequence
1. `IdpSecretsCacheHelper.init()` loads from Azure Key Vault **before** Spring context starts
2. `SystemPropertiesLoader.addSystemProperties()` sets environment system properties
3. Only then does Spring Boot initialize beans

### SOAP Integration (MPS MergeSLIDProfile)
- WSDL: `src/main/resources/schemas/mpsys/mergeSLIDProfile/RILMergeSLIDProfile.wsdl`
- JAXB stubs generated at build time via `jaxb-maven-plugin`
- Config: `MPSSOAPConfig` with optional Azure proxy (`enable.http.proxy`)
- Handler: `MPSMergeSLIDProfileSoapHandler`

### Voltage Encryption
- Used for password field encryption/decryption
- Helpers: `RILCheckAndEncryptPasswordHelper`, `voltage/` subpackage in `helper/`
- Keys loaded at startup into `voltageKeyCache/`
- Classes excluded from JaCoCo coverage

---

## Integration Points

| Dependency | Protocol | Config Property | Purpose |
|------------|----------|-----------------|---------|
| Oracle DB | JPA/Hibernate (XA) | `spring.datasource.url` | Primary data store |
| IBM MQ (primary) | JMS | `mq.host` / `mq.port` / `mq.channel` | Async event publishing |
| IBM MQ (failover) | JMS | `mq.ff.host` / `mq.ff.port` / `mq.ff.channel` | MQ failover |
| IDGraphUserProfileMs (IUP) | REST | `apiclient.rest.idgiup.url` | InquireProfile, InquireAssociatedAccessIds |
| IDGraphUserAssociationMs (OUA) | REST | `apiclient.rest.idgoua.url` | AddAssociation, RemoveAssociation, ChangeStatus |
| IDGraphUserManagementMs OUD | REST | `apiclient.rest.idgoud.url` | CheckUserIdAvailability, AddUser (OUD path) |
| OrderGraph | REST | `apiclient.rest.og.url` | Order-related integrations |
| CustomerGraph Orchestration MS | REST | `apiclient.rest.cg.serverUrl` | Customer profile lookups via `CGClientHelpers` |
| MPS MergeSLIDProfile | SOAP | `MPSSOAPConfig` | Merge access IDs |
| Azure Event Hub | Kafka (Spring Cloud Stream) | `spring.cloud.stream.bindings.externalEventsNotifications-*` | External event notifications via `idgrapheventshelper` |
| Kafka (Audit) | Kafka (Spring Kafka) | `spring.kafka.bootstrap-servers` | Audit watermarking + event tracking |
| Voltage Server | SDK | `idp-voltage-encrypt` / `idp-voltage-decrypt` | PII/SPI encryption/decryption |
| Azure Key Vault | Secret Loader | `idpsecretsloader.yaml` | All secrets at startup |
| Azure App Configuration | Dynamic Config | `IDGraphAzureAppConfig` | Runtime DataSource pool refresh |

### Common Request Headers (Required on All Endpoints)
| Header | Required | Description |
|--------|----------|-------------|
| `X-ATT-ClientId` | Yes | Calling system identifier |
| `idp-trace-id` | Yes | Correlation trace ID |

---

## Testing

### Test Framework
- **Spock 2.3-groovy-4.0** (primary) — BDD-style with `given/when/then` blocks in `src/test/groovy/`
- **JUnit 5** — unit tests in `src/test/java/`
- **TestContainers** (Azure, Spock) — integration tests

### Spock Hard-Stops (IDGraph rule HS-8)
- **`0 * _` mandatory** in every Spock `then:` block that verifies no unexpected interactions
- Every `then:` block must explicitly assert expected mock interactions

### Coverage
- Report: `target/site/jacoco/index.html`
- Exclusions: `Application`, all `@Configuration` classes, exception mappers, model/DTO classes, Voltage helpers, health check classes

### Test Profiles
| Profile | Command | Coverage |
|---------|---------|---------|
| `local` (default) | `mvn clean test` | Unit tests |
| `integration-test` | `mvn clean verify -P integration-test` | Integration tests |

### Test Data
- Mock configs: `src/test/resources/`
- IST configs: `src/test/ist/`
- Bad-word lists: `opt/ajsc/etc/config/rilhrs-bad-word-data/` (15 files)

---

## Deployment Notes

- **Cluster**: `Graph1EUS2-dev2` (default)
- **Namespace**: `com-att-idp-idgraph-dev2`
- **Veracode Profile**: `33944-IDGraph-IDGraphUserManagementMs`
- **Helm repo**: `apm0045194-idgraph-idgraphusermanagementms-helm`
- **Config role repo**: `apm0045194-idgraph-idgraphusermanagementms_configrole`
- **Jenkins**: https://jenkins-community-gateway.az.3pc.att.com/idp-ui/jenkins/job/com.att.idp/job/com.att.idp.IDGraphUserManagementMs/job/master
- Validate `opt/ajsc/etc/config/application.properties` and `userMgmt.properties` before promoting to each environment
- Secrets must be present in the target environment's Azure Key Vault before deployment
