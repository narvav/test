Error Code | HTTP Status Code | Message | Additional Details | Channel | System Error (Y/N) | Business Validation Error (Y/N) | Customer Input Error (Y/N)
--- | --- | --- | --- |--- |--- |--- |--- 
