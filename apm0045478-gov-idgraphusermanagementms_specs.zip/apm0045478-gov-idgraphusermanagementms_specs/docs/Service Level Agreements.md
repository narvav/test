# Performance And SLA's


## Rate Limits (Configured in MuleSoft API Gateway)

EndPoint | Sale Channel | Rate Limit | Additional Limit | Notes | Last Updated
--- | --- | --- | --- |--- |--- 

<br>
<br>
<br>

---

## API SLA (Availability)

```
%
```


## Endpoints SLA (Latency) (Use Performance dashboard links for real time information)

EndPoint | Uptime Availability % | 90th Percentile Latency ( in sec) | Notes | Last Updated
--- | --- | --- | --- |--- 

<br>
<br>
<br>

---

## API Availability / Performance dashboard links
TBD

















