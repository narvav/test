# AGENTS.md — IDGraphContactInfoMs

> Instructions for AI coding agents working in this repository.

## Repository Identity

| Field | Value |
|---|---|
| **Repository** | `apm0045194-idgraph-idgraphcontactinfoms` |
| **Domain** | IDGraph / LEGOS Platform Team |
| **Type** | Spring Boot Microservice (JAX-RS + SOAP + Kafka + JMS) |
| **Java Version** | 17 |
| **Parent SDK** | `sdk-java-parent 3.0.1` |
| **Base Path** | `/idgraphcontactinfoms/v1` |
| **MOTS ID** | 33944 |

## Governance

This service is governed by:

1. **OMNI Global Rules (Tier 1)**: `apm0011159-omni-global-rules/.windsurf/rules/`
2. **IDGraph Domain Rules (Tier 2)**: `.windsurf/rules/idgraph-*.md`

### Hard-Stops (Must Never Violate)

- **HS-1**: Use `CommonErrorMap` + `CErrorDefs` for all error responses
- **HS-2**: Reuse shared helpers (`idgraphcommonhelper`, `idgraphdbhelper`, `idgrapheventshelper`, `cgclienthelpers`, `idgraphextclienthelpers`) before adding new framework code
- **HS-3**: Sanitize logs via ESAPI — no raw external values in log statements
- **HS-4**: Key Vault secrets load before Spring context — preserve startup sequence
- **HS-5**: Preserve Kafka auth patterns — do not change PLAIN/OAUTHBEARER config
- **HS-6**: No wildcard imports — all imports must be explicit
- **HS-7**: Sync config across MS + Helm repos for every config change
- **HS-8**: `0 * _` mandatory in every Spock `then:` block
- **HS-9**: Execution plans commit to `docs/{TICKET-ID}/`, NOT team-documents
- **No `@Autowired` on fields**: Use constructor injection (`@RequiredArgsConstructor` + `final`)
- **No hardcoded secrets**: All credentials via Azure Key Vault (`idpsecretsloader.yaml`)
- **No empty catch blocks**: Every catch must log and handle
- **No `System.out.println`**: Use structured logging (`log.info`, `log.error`, etc.)
- **No removing existing code without explicit approval**: Default behavior is ADD, not REPLACE

## Project Directory Structure

```
apm0045194-idgraph-idgraphcontactinfoms/
├── src/
│   ├── main/
│   │   ├── java/com/att/idp/idgraphcontactinfoms/
│   │   │   ├── Application.java                    # Spring Boot entry point
│   │   │   ├── appconfig/config/                   # Azure App Config (IDGraphAzureAppConfig)
│   │   │   ├── cassandra/                          # Cassandra entities + repositories
│   │   │   │   ├── entity/                         # SessionId, ValidatePinAuthInfo
│   │   │   │   └── repository/                     # ValidatePinAuthInfoRepository
│   │   │   ├── cgclient/response/                  # CG API response models (28 classes)
│   │   │   ├── config/                             # Spring configuration beans
│   │   │   │   ├── JerseyConfiguration.java        # JAX-RS resource registration
│   │   │   │   ├── DataBaseConfiguration.java      # Oracle XADataSource + JPA
│   │   │   │   ├── JMSConfiguration.java           # IBM MQ connection factory
│   │   │   │   ├── LSCRMSoapConfig.java            # LSCRM SOAP client config
│   │   │   │   └── TransactionConfiguration.java   # Transaction manager
│   │   │   ├── db/                                 # Database layer
│   │   │   │   ├── helper/                         # DBHelper, SecurityCodeDBHelper, ContactDBHelper
│   │   │   │   ├── model/                          # JPA entities (80 classes)
│   │   │   │   └── repository/                     # JPA repositories + custom impls
│   │   │   ├── exceptions/                         # Custom exceptions + JAX-RS mappers
│   │   │   ├── healthcheck/                        # DatabaseHealthIndicator (Actuator)
│   │   │   ├── helpers/                            # Business logic (24 classes)
│   │   │   │   └── voltage/                        # Voltage encrypt/decrypt helpers (6 classes)
│   │   │   ├── integration/                        # Outbound REST/SOAP clients
│   │   │   │   ├── Async/                          # AsyncCall, CallDestinationAsync
│   │   │   │   ├── InquireProfileRestClient.java
│   │   │   │   ├── MuleSoftRestClient.java
│   │   │   │   ├── LscrmGetAuthInfoClient.java
│   │   │   │   └── OutboundRestClientBuilder.java
│   │   │   ├── kafka/                              # Kafka producers
│   │   │   │   ├── GenericOTPPublisher.java         # Primary/secondary failover
│   │   │   │   ├── config/                          # Producer configs
│   │   │   │   └── model/                           # GenericOTPNotification, serializers
│   │   │   ├── message/                            # ErrorMessages, LogMessages
│   │   │   ├── metrics/                            # ErrorMetricHandler
│   │   │   ├── model/                              # Domain models (12 classes)
│   │   │   ├── queue/message/sender/               # JMSQueueSender (DBUS)
│   │   │   ├── request/validator/                  # Request validators (7 classes)
│   │   │   ├── resource/                           # JAX-RS interfaces (6)
│   │   │   │   ├── impl/                           # JAX-RS implementations (4)
│   │   │   │   ├── request/                        # Request DTOs (14)
│   │   │   │   └── response/                       # Response DTOs (19)
│   │   │   ├── service/                            # Service interfaces (8) + impls
│   │   │   │   ├── async/                          # AsyncOtpEventPublisher, OracleSecurityCodeSyncPublisher
│   │   │   │   └── impl/                           # Service implementations (8)
│   │   │   └── utils/                              # Constants, CommonUtilHelper, JsonService
│   │   ├── resources/
│   │   │   ├── errormessages.properties
│   │   │   ├── logmessages.properties
│   │   │   ├── schemas/lscrm/                      # LSCRM WSDL/XSD
│   │   │   └── bindings/                           # JAXB bindings
│   │   ├── docker/                                 # Dockerfile, startService.sh
│   │   └── jenkins/                                # versioning.groovy
│   └── test/
│       ├── groovy/com/att/idp/
│       │   ├── component/                          # Component tests (7 classes)
│       │   ├── idgraphcontactinfoms/               # Unit tests (67 classes)
│       │   └── integration/                        # Integration tests (3 classes)
│       ├── resources/                              # Test properties + mock JSON
│       └── ist/                                    # IST test suites
├── opt/ajsc/etc/config/                            # Runtime configuration
│   ├── application.properties                      # Spring config
│   ├── contactInfo.properties                      # Business rules
│   ├── contactInfoCredentials.properties           # Credential refs
│   ├── security-filter-config.yaml                 # Security filters
│   └── logback/baselogback.xml                     # Logging config
├── docs/                                           # Execution plans + documentation
│   ├── CONTACTINFO_PROPERTIES_DOCUMENTATION.md
│   ├── SIM_SWAP_LOGIC_WIKI.md
│   └── SPTAUTHREG-34374/                          # Execution plan
├── Jenkinsfile                                     # CI/CD pipeline
├── pom.xml                                         # Maven build
├── idpsecretsloader.yaml                           # Key Vault secret mappings
└── CODEOWNERS
```

## Architecture Rules

### Layered Architecture (Mandatory)

```
Resource (JAX-RS interface + impl) → Validator → Service → Helper → DB/Integration
```

- **Resource Layer**: JAX-RS interfaces in `resource/`, implementations in `resource/impl/`
- **Validator Layer**: Request validators in `request/validator/` — header + body + CSI auth
- **Service Layer**: Interfaces in `service/`, implementations in `service/impl/`
- **Helper Layer**: Business logic in `helpers/` — all core logic lives here
- **Data Layer**: `db/` (Oracle), `cassandra/` (Cassandra), `CosmosDataStore` (Cosmos)
- **Integration Layer**: `integration/` — outbound REST/SOAP clients

### JAX-RS Pattern

All REST endpoints use interface + implementation split:
- Interface: OpenAPI 3 annotations (`@Tag`, `@ApiResponses`, `@Operation`)
- Implementation: Business routing, delegates to service layer
- Registration: All resources registered in `JerseyConfiguration.java`

### Error Contract

All errors must use:
```java
CommonErrorMap.makeCategoryMap(CErrorDefs.ERROR_CODE, message)
```

Never throw raw exceptions to API consumers. Use `CommonErrorMap` for all response error mapping.

### Configuration Pattern

- **Static properties**: `opt/ajsc/etc/config/contactInfo.properties`
- **Dynamic properties**: `IDGraphAzureAppConfig` with `@RefreshScope`
- **Outbound clients**: Listen on `RefreshScopeRefreshedEvent` for dynamic timeout updates
- **Feature flags**: Prefixed `svc-idgraph-` in Azure App Configuration

## Key Integration Points

| System | Protocol | Client Class | Notes |
|---|---|---|---|
| Oracle DB | JDBC (XADataSource) | `DataBaseConfiguration` | Dynamic pool refresh via App Config |
| Cosmos DB | Spring Data | `CosmosDataStore` | Hybrid Oracle/Cosmos PIN tracking |
| Cassandra | Spring Data Cassandra | `ValidatePinAuthInfoRepository` | PIN validation auth info |
| Customer Graph API | REST | `CGHelper` | SIM swap check during ValidatePIN |
| OUD InquireProfile | REST | `InquireProfileRestClient` | Profile queries |
| MuleSoft CLM | REST | `MuleSoftRestClient` | Notification delivery |
| LSCRM | SOAP | `LscrmGetAuthInfoClient` | WS-Security (Wss4jSecurityInterceptor) |
| Kafka (GenericOTP) | Kafka Producer | `GenericOTPPublisher` | Primary/secondary with `@Retryable` failover |
| IBM MQ (DBUS) | JMS | `JMSQueueSender` | Async notification delivery |

## Testing Conventions

- **Framework**: Spock (Groovy) — BDD style
- **File patterns**: `*Test.java`, `*Tests.java`, `*Spec.java`, `*Test.groovy`, `*Spec.groovy`
- **Mandatory**: `0 * _` in every Spock `then:` block (HS-8)
- **Coverage**: JaCoCo with exclusions for models, configs, DTOs
- **Build gate**: `mvn clean install` (not `-DskipTests`)

## Sensitive Areas (High Risk)

| Area | Risk | Required Safeguards |
|---|---|---|
| `GeneratePINHelper` / `GeneratePINBase` | PIN generation + notification delivery | Full regression, peer review |
| `ValidatePINHelper` + SIM swap logic | Account lockout, fraud prevention | Full regression, staged rollout |
| `GenericOTPPublisher` (Kafka) | Dual-cluster failover | Do not change JAAS/auth config |
| `DataBaseConfiguration` | XADataSource pool management | Test refresh behavior |
| `JMSConfiguration` | IBM MQ failover logic | Test reconnect behavior |
| `IDGraphAzureAppConfig` | All dynamic config values | Validate defaults match Helm |

## Common Tasks

### Adding a New Endpoint

1. Create interface in `resource/` with OpenAPI annotations
2. Create implementation in `resource/impl/`
3. Register in `JerseyConfiguration.java`
4. Create validator in `request/validator/`
5. Create service interface + impl
6. Create helper for business logic
7. Update `contactInfo.properties` if CSI auth needed
8. Sync config to Helm repo (HS-7)

### Adding a New Outbound Client

1. Create client class in `integration/`
2. Add timeout properties to `IDGraphAzureAppConfig`
3. Add `RefreshScopeRefreshedEvent` listener for dynamic refresh
4. Add `refreshEnabled` toggle property
5. Use `OutboundRestClientBuilder` for RestTemplate construction
6. Add secrets to `idpsecretsloader.yaml` if credentials needed
7. Sync config to Helm repo (HS-7)

### Modifying Business Properties

1. Update `opt/ajsc/etc/config/contactInfo.properties`
2. Update corresponding Helm config in `-helm` repo
3. Document in `docs/CONTACTINFO_PROPERTIES_DOCUMENTATION.md`
4. Test with existing CSI authorization matrices

## File Quick Reference

| Purpose | Path |
|---|---|
| Entry point | `src/main/java/.../Application.java` |
| Jersey config | `src/main/java/.../config/JerseyConfiguration.java` |
| Azure App Config | `src/main/java/.../appconfig/config/IDGraphAzureAppConfig.java` |
| REST interfaces | `src/main/java/.../resource/*.java` |
| REST implementations | `src/main/java/.../resource/impl/*.java` |
| Validators | `src/main/java/.../request/validator/*.java` |
| Services | `src/main/java/.../service/*.java` |
| Helpers | `src/main/java/.../helpers/*.java` |
| DB layer | `src/main/java/.../db/` |
| Kafka producers | `src/main/java/.../kafka/` |
| Outbound clients | `src/main/java/.../integration/` |
| Business properties | `opt/ajsc/etc/config/contactInfo.properties` |
| Secrets config | `idpsecretsloader.yaml` |
| CI/CD | `Jenkinsfile` |
| Tests | `src/test/` |

## Related Repositories

| Repository | Purpose |
|---|---|
| `apm0045194-idgraph-idgraphcontactinfoms-helm` | Helm charts + env configs (HS-7 sync target) |
| `apm0045194-idgraph-cgclienthelpers` | CG API client library |
| `apm0045194-idgraph-idgraphcommonhelper` | CommonErrorMap, CommonUtil, CErrorDefs |
| `apm0045194-idgraph-idgraphdbhelper` | Database helper utilities |
| `apm0045194-idgraph-idgrapheventshelper` | Event publishing library |
| `apm0045194-idgraph-idgraphextclienthelpers` | External client helpers |
