package com.att.idp.idgraphcontactinfoms.queue.message.sender

import jakarta.jms.BytesMessage
import jakarta.jms.Connection
import jakarta.jms.ConnectionFactory
import jakarta.jms.Destination
import jakarta.jms.JMSException
import jakarta.jms.MessageProducer
import jakarta.jms.Queue
import jakarta.jms.Session
import org.springframework.jms.core.JmsTemplate
import spock.lang.Unroll
import spock.lang.Specification
import com.att.mpsys.common.utils.CommonDefs

/**
 * Spock tests for JMSQueueSender covering happy paths and edge cases.
 * Uses data tables and explicit mock verification with 0 * _.
 */
class JMSQueueSenderTest extends Specification {

    // Concrete types for dependencies and subject under test
    JmsTemplate jmsTemplate
    ConnectionFactory connectionFactory
    Connection connection
    Session session
    Queue queue
    Destination destination
    MessageProducer messageProducer
    BytesMessage bytesMessage

    JMSQueueSender sender

    def setup() {
        jmsTemplate = Mock(JmsTemplate)
        connectionFactory = Mock(ConnectionFactory)
        connection = Mock(Connection)
        session = Mock(Session)
        queue = Mock(Queue)
        destination = Mock(Destination)
        messageProducer = Mock(MessageProducer)
        bytesMessage = Mock(BytesMessage)

        sender = new JMSQueueSender()
        // Inject JmsTemplate
        setField(sender, 'jmsTemplate', jmsTemplate)
        // Inject configuration values
        setField(sender, 'mqQueueName', 'test.queue')
        setField(sender, 'mqQueueCount', 8)
    }

    @Unroll
    def "should return error map for invalid input scenarios for #scenarioName"() {
        given: "Input map for scenario"
        Map<String, Object> input = hmInput

        when: "Send is invoked"
        Map<String, Object> result = sender.send(input)

        then: "No JMS interactions occur"
        0 * jmsTemplate.getConnectionFactory()
        0 * _

        and: "Result is a non-empty error map"
        result != null
        !result.isEmpty()

        where: "Different invalid input combinations"
        scenarioName                    | hmInput
        'null input'                    | null
        'empty input'                   | [:]
        'missing msOperation'           | [(CommonDefs.TRANSACTION_ID): 'tx1', mainHashKey: 'key']
        'missing transactionId'         | [msOperation: 'op', mainHashKey: 'key']
        'missing mainHashKey'           | [msOperation: 'op', (CommonDefs.TRANSACTION_ID): 'tx1']
    }

    def "should return error when mqQueueName property is empty"() {
        given: "Valid input but empty queue name configuration"
        setField(sender, 'mqQueueName', '')
        Map<String, Object> input = [msOperation: 'create', (CommonDefs.TRANSACTION_ID): 'tx-123', mainHashKey: 'user-1']

        when: "Send is invoked"
        Map<String, Object> result = sender.send(input)

        then: "No JMS interactions occur"
        0 * jmsTemplate.getConnectionFactory()
        0 * _

        and: "Result is error map"
        result != null
        !result.isEmpty()
    }

    def "should send message successfully with proper JMS interactions"() {
        given: "Valid input and JMS mocks set up"
        Map<String, Object> input = new HashMap<String, Object>()
        input.put('msOperation', 'create')
        input.put(CommonDefs.TRANSACTION_ID, 'tx-123')
        input.put('mainHashKey', 'user-1')

        when: "Send is invoked"
        Map<String, Object> result = sender.send(input)

        then: "JMS connection and session are created and message is sent"
        1 * jmsTemplate.getConnectionFactory() >> connectionFactory
        1 * connectionFactory.createConnection() >> connection
        1 * connection.createSession(false, Session.AUTO_ACKNOWLEDGE) >> session
        1 * session.createQueue({ String qn -> qn.startsWith('test.queue.') }) >> queue
        2 * queue.getQueueName() >> 'test.queue.1'
        1 * session.createQueue('test.queue.1') >> queue
        1 * session.createBytesMessage() >> bytesMessage
        1 * bytesMessage.writeBytes(_ as byte[])
        1 * bytesMessage.setJMSCorrelationID('tx-123')
        1 * bytesMessage.getJMSCorrelationID() >> 'tx-123'
        1 * session.createProducer(queue) >> messageProducer
        1 * messageProducer.getDestination() >> queue
        1 * messageProducer.send(bytesMessage)
        1 * session.close()
        1 * connection.close()

        and: "Result is a success map and messagePublished flag is true"
        result != null
        !result.isEmpty()
        sender.isMessagePublished()
    }

    def "should return error when serialization of input map fails"() {
        given: "Input contains non-serializable value causing serialization failure"
        Object nonSerializable = new Object()
        Map<String, Object> input = new HashMap<String, Object>()
        input.put('msOperation', 'create')
        input.put(CommonDefs.TRANSACTION_ID, 'tx-123')
        input.put('mainHashKey', 'user-1')
        input.put('bad', nonSerializable)

        when: "Send is invoked"
        Map<String, Object> result = sender.send(input)

        then: "JMS setup occurs up to bytes message creation, but send is not called due to serialization failure"
        1 * jmsTemplate.getConnectionFactory() >> connectionFactory
        1 * connectionFactory.createConnection() >> connection
        1 * connection.createSession(false, Session.AUTO_ACKNOWLEDGE) >> session
        1 * session.createQueue({ String qn -> qn.startsWith('test.queue.') }) >> queue
        2 * queue.getQueueName() >> 'test.queue.1'
        1 * session.createQueue('test.queue.1') >> queue
        //0 * session.createBytesMessage() >> bytesMessage
        1 * session.close()
        1 * connection.close()
        0 * messageProducer.send(_)

        and: "Result is an error map and messagePublished may remain true/unchanged"
        result != null
        !result.isEmpty()
    }

    def "should retry and ultimately fail when MessageProducer throws JMSException repeatedly"() {
        given: "Valid input and producer send throws JMSException three times"
        Map<String, Object> input = new HashMap<String, Object>()
        input.put('msOperation', 'create')
        input.put(CommonDefs.TRANSACTION_ID, 'tx-abc')
        input.put('mainHashKey', 'user-xyz')

        when: "Send is invoked"
        Map<String, Object> result = sender.send(input)

        then: "JMS setup and send attempts with retries, final failure captured"
        1 * jmsTemplate.getConnectionFactory() >> connectionFactory
        1 * connectionFactory.createConnection() >> connection
        1 * connection.createSession(false, Session.AUTO_ACKNOWLEDGE) >> session
        1 * session.createQueue({ String qn -> qn.startsWith('test.queue.') }) >> queue
        2 * queue.getQueueName() >> 'test.queue.2'
        1 * session.createQueue('test.queue.2') >> queue
        1 * session.createBytesMessage() >> bytesMessage
        1 * bytesMessage.writeBytes(_ as byte[])
        1 * bytesMessage.setJMSCorrelationID('tx-abc')
        1 * bytesMessage.getJMSCorrelationID() >> 'tx-abc'
        1 * session.createProducer(queue) >> messageProducer
        2 * messageProducer.getDestination() >> destination
        1 * messageProducer.send(bytesMessage) >> { throw new JMSException('Exception') }
        1 * messageProducer.send(bytesMessage) >> { throw new JMSException('Retry - first') }
        1 * messageProducer.getDestination() >> destination
        1 * messageProducer.send(bytesMessage) >> { throw new JMSException('Retry - second') }
        1 * messageProducer.getDestination() >> destination
        1 * messageProducer.send(bytesMessage) >> { throw new JMSException('Retry - third') }
        1 * session.close()
        1 * connection.close()

        and: "Result is an error map indicating JMS failure and messagePublished set to false"
        result != null
        !result.isEmpty()
        !sender.isMessagePublished()
    }

    def "should handle JMSException with linked exception and return error map"() {
        given: "Valid input and a JMSException with a linked exception is thrown early"
        Map<String, Object> input = new HashMap<String, Object>()
        input.put('msOperation', 'create')
        input.put(CommonDefs.TRANSACTION_ID, 'tx-link')
        input.put('mainHashKey', 'user-link')
        JMSException jmsException = new JMSException('boom')
        jmsException.setLinkedException(new RuntimeException('linked'))

        when: "Send is invoked"
        Map<String, Object> result = sender.send(input)

        then: "JMS exception thrown during producer creation is handled"
        1 * jmsTemplate.getConnectionFactory() >> connectionFactory
        1 * connectionFactory.createConnection() >> connection
        1 * connection.createSession(false, Session.AUTO_ACKNOWLEDGE) >> session
        1 * session.createQueue({ String qn -> qn.startsWith('test.queue.') }) >> queue
        2 * queue.getQueueName() >> 'test.queue.3'
        1 * session.createQueue('test.queue.3') >> queue
        1 * session.createBytesMessage() >> bytesMessage
        1 * bytesMessage.writeBytes(_ as byte[])
        1 * bytesMessage.setJMSCorrelationID('tx-link')
        1 * session.createProducer(queue) >> { throw jmsException }
        1 * session.close()
        1 * connection.close()

        and: "Result is an error map"
        result != null
        !result.isEmpty()
    }

    def "should handle generic Exception and return error map for #scenarioName"() {
        given: "Valid input and a RuntimeException occurs during producer creation"
        Map<String, Object> input = new HashMap<String, Object>()
        input.put('msOperation', 'create')
        input.put(CommonDefs.TRANSACTION_ID, 'tx-gen')
        input.put('mainHashKey', mainHashKey)

        when: "Send is invoked"
        Map<String, Object> result = sender.send(input)

        then: "Generic exception thrown during producer creation is handled by catch(Exception) block"
        1 * jmsTemplate.getConnectionFactory() >> connectionFactory
        1 * connectionFactory.createConnection() >> connection
        1 * connection.createSession(false, Session.AUTO_ACKNOWLEDGE) >> session
        1 * session.createQueue({ String qn -> qn.startsWith('test.queue.') }) >> queue
        2 * queue.getQueueName() >> expectedQueue
        1 * session.createQueue(expectedQueue) >> queue
        1 * session.createBytesMessage() >> bytesMessage
        1 * bytesMessage.writeBytes(_ as byte[])
        1 * bytesMessage.setJMSCorrelationID('tx-gen')
        1 * session.createProducer(queue) >> { throw new RuntimeException('producer boom') }
        1 * session.close()
        1 * connection.close()
        0 * _

        and: "Result is an error map indicating generic exception"
        result != null
        !result.isEmpty()

        where: "Different hash resulting queues"
        scenarioName        | mainHashKey | expectedQueue
        'hash bucket 0/1'   | 'user-a'    | 'test.queue.' + (Math.abs('user-a'.hashCode() % 8))
        'hash bucket other' | 'user-b'    | 'test.queue.' + (Math.abs('user-b'.hashCode() % 8))
    }

    private static void setField(Object target, String name, Object value) {
        def field = target.class.getDeclaredField(name)
        field.accessible = true
        field.set(target, value)
    }
}
