package com.att.idp.component

import com.att.ajsc.common.utility.SystemPropertiesLoader
import com.att.idp.idgraphcontactinfoms.Application
import com.att.idp.idgraph.db.oracle.helper.CacheDBHelper
import com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig
import com.att.idp.idgraphcontactinfoms.config.CassandraConfiguration
import com.att.idp.idgraphcontactinfoms.helpers.voltage.DecryptUtil
import com.att.idp.idgraphcontactinfoms.helpers.voltage.EncryptUtil
import com.att.idp.voltage.health.readiness.VoltageReadinessIndicator
import com.att.idp.voltage.decrypt.api.VoltageDecryptorAutoConfiguration
import com.att.idp.voltage.encrypt.api.VoltageEncryptorAutoConfiguration
import com.att.idp.cgclienthelpers.integration.CGApiRestClient
import com.att.idp.cgclienthelpers.integration.CGRestClient
import com.att.idp.idgraphcontactinfoms.db.repository.SecurityAccountDataRepository
import com.att.idp.idgraphcontactinfoms.db.repository.SecurityCodeRepository
import com.att.idp.idgraphcontactinfoms.helpers.ProfileHelper
import com.att.idp.idgraphcontactinfoms.integration.MuleSoftRestClient
import com.att.idp.idgraphcontactinfoms.integration.LscrmGetAuthInfoClient
import com.att.idp.idgraphcontactinfoms.integration.InquireProfileRestClient
import com.att.idp.idgraphcontactinfoms.cassandra.repository.ValidatePinAuthInfoRepository
import com.att.idp.idgraph.db.cosmos.helper.IdgOtpDBHelper
import com.azure.spring.cloud.appconfiguration.config.AppConfigurationRefresh
import com.att.mpsys.common.helpers.FeatureManagerHelper
import io.restassured.RestAssured
import io.restassured.http.ContentType
import io.restassured.specification.RequestSpecification
import org.junit.jupiter.api.Timeout
import org.mockito.Mockito
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.boot.test.web.server.LocalServerPort
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.ComponentScan
import org.springframework.context.annotation.ComponentScan.Filter
import org.springframework.context.annotation.FilterType
import org.springframework.context.annotation.Primary
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.scheduling.TaskScheduler
import org.springframework.test.context.ContextConfiguration
import org.springframework.test.context.TestPropertySource
import spock.lang.Shared
import spock.lang.Specification
import java.util.concurrent.TimeUnit

@ContextConfiguration(classes = [Application.class, TestKafkaPropertiesConfig.class, CompBaseTest.TestConfig.class])
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = [Application.class, CompBaseTest.TestConfig.class])
@ComponentScan(basePackages = "com.att.idp.idgraphcontactinfoms", excludeFilters = [@Filter(type = FilterType.ASSIGNABLE_TYPE, classes = [CassandraConfiguration.class, com.att.idp.idgraphcontactinfoms.config.CosmosNoSqlRefreshConfig.class])])
@TestPropertySource(properties = [
        'API_CLIENT_REST_DEFAULT_USERTYPES_GUEST_USER=ct-guest',
        'API_CLIENT_REST_DEFAULT_USERTYPES_GUEST_PASSWORD=ct-guest-pass',
        'API_CLIENT_REST_DEFAULT_USERTYPES_REGISTERED_USER=ct-registered',
        'API_CLIENT_REST_DEFAULT_USERTYPES_REGISTERED_PASSWORD=ct-registered-pass',
        'management.health.voltage.enabled=false',
        'management.health.cassandra.enabled=false',
        'management.readiness.health.enabled=false',
        'ixp.library-enabled=false',
        'spring.task.scheduling.enabled=false',
        'spring.main.lazy-initialization=true',
        'spring.cloud.azure.appconfiguration.enabled=false',
        'spring.cloud.azure.appconfiguration.refresh.enabled=false',
        'spring.cache.type=none',
        'azure.cosmos.nosql.enabled=false',
        'spring.autoconfigure.exclude=org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration,org.springframework.boot.autoconfigure.data.redis.RedisClientAutoConfiguration,org.springframework.boot.autoconfigure.cassandra.CassandraAutoConfiguration,org.springframework.boot.autoconfigure.data.cassandra.CassandraDataAutoConfiguration,org.springframework.boot.actuate.autoconfigure.cassandra.CassandraHealthContributorAutoConfiguration,com.azure.spring.cloud.autoconfigure.implementation.data.cosmos.CosmosDataAutoConfiguration,com.azure.spring.cloud.autoconfigure.implementation.cosmos.AzureCosmosAutoConfiguration,org.springframework.boot.autoconfigure.data.mongo.MongoAutoConfiguration,org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration',
        'spring.data.cosmos.repositories.enabled=false',
        'spring.main.allow-bean-definition-overriding=true',
        // H2 Database configuration to replace Oracle
        'spring.datasource.url=jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1;MODE=Oracle',
        'spring.datasource.driver-class-name=org.h2.Driver',
        'spring.datasource.username=sa',
        'spring.datasource.password=',
        'spring.jpa.database-platform=org.hibernate.dialect.H2Dialect',
        'spring.jpa.hibernate.ddl-auto=none',
        'AES256KEY=0123456789abcdef0123456789abcdef'
])
@Timeout(value = 30L, unit = TimeUnit.SECONDS)
abstract class CompBaseTest extends Specification {

	@Value('${server.servlet.context-path}')
	protected String contextPath

	@Value('${api.schemaVersion}')
	protected String apiVersion

	@Value('${spring.application.name}')
	protected String appPath

	@LocalServerPort
	protected int randomServerPort

	@Shared
	private boolean restAssuredBaseUriInitialized = false

	@SpringBean
	protected CGRestClient cgRestClient = Mock()

	@SpringBean
	protected CGApiRestClient cgApiRestClient = Mock()

	@SpringBean
	protected ProfileHelper profileHelper = Mock()

	@SpringBean
	protected SecurityCodeRepository securityCodeRepository = Mock()

	@SpringBean
	protected SecurityAccountDataRepository securityAccountDataRepository = Mock()

	@SpringBean
	protected MuleSoftRestClient muleSoftRestClient = Mock()

	@SpringBean
	protected FeatureManagerHelper featureManager = Mock()

	@SpringBean
	protected VoltageEncryptorAutoConfiguration voltageEncryptorAutoConfiguration = Mock()

	@SpringBean
	protected VoltageDecryptorAutoConfiguration voltageDecryptorAutoConfiguration = Mock()

	@SpringBean
	protected VoltageReadinessIndicator voltageReadinessIndicator = Mock()

	@SpringBean
	protected AppConfigurationRefresh appConfigurationRefresh = Mock()

	@SpringBean
	protected TaskScheduler taskScheduler = Mock()

	@SpringBean
	protected EncryptUtil encryptUtil = Mock()

	@SpringBean
	protected DecryptUtil decryptUtil = Mock()

	@SpringBean
	protected JdbcTemplate jdbcTemplate = Mock()

	@SpringBean
	protected ValidatePinAuthInfoRepository validatePinAuthInfoRepository = Mock()

	@SpringBean
	protected IdgOtpDBHelper idgOtpDBHelper = Mock()

	@Value('${apiclient.rest.default.userTypes.guest.username}')
	protected String guestUsername

	@Value('${apiclient.rest.default.userTypes.guest.password}')
	protected String guestPassword

	@Value('${apiclient.rest.default.userTypes.registered.username}')
	protected String registeredUsername

	@Value('${apiclient.rest.default.userTypes.registered.password}')
	protected String registeredPassword

	static {
		SystemPropertiesLoader.addSystemProperties()
	}


	def setup() throws Exception {
		if (!restAssuredBaseUriInitialized) {
			RestAssured.baseURI = 'http://localhost:' + randomServerPort +
					contextPath + '/' + appPath.toLowerCase() + '/' + apiVersion
			restAssuredBaseUriInitialized = true
		}
	}

	/*
	 * Base spec with guest user
	 */
	protected RequestSpecification givenBaseSpec() {
		return RestAssured.given()
				.relaxedHTTPSValidation()
				.accept(ContentType.JSON)
				.contentType(ContentType.JSON)
				.auth().basic(guestUsername, guestPassword)
	}

	/*
	 * Base spec for registered user
	 */
	protected RequestSpecification givenRegisterdBaseSpec() {
		return RestAssured.given()
				.relaxedHTTPSValidation()
				.accept(ContentType.JSON)
				.contentType(ContentType.JSON)
				.auth()
				.basic(registeredUsername, registeredPassword)
	}

	/**
	 * Test configuration to provide mocked beans that are initialized during Spring context startup.
	 * This prevents connection attempts and NullPointerExceptions during bean initialization.
	 */
	@TestConfiguration
	static class TestConfig {
		@Bean
		@Primary
		CacheDBHelper cacheDBHelper() {
			CacheDBHelper mock = Mockito.mock(CacheDBHelper.class)
			Mockito.when(mock.findAllAttributes()).thenReturn([])
			return mock
		}

		@Bean
		@Primary
		IDGraphAzureAppConfig idGraphAzureAppConfig() {
			IDGraphAzureAppConfig mock = Mockito.mock(IDGraphAzureAppConfig.class)
			Mockito.when(mock.isDataSourceRefreshEnabled()).thenReturn(false)
			Mockito.when(mock.getValidationQuery()).thenReturn("SELECT 1")
			Mockito.when(mock.getInitialSize()).thenReturn(1)
			Mockito.when(mock.getMaxSize()).thenReturn(5)
			Mockito.when(mock.getMinSize()).thenReturn(1)
			Mockito.when(mock.isTestOnBorrow()).thenReturn(false)
			Mockito.when(mock.isTestWhileIdle()).thenReturn(false)
			Mockito.when(mock.getQueryTimeout()).thenReturn(30)
			Mockito.when(mock.getEvictTime()).thenReturn(10000)
			Mockito.when(mock.getConnTimeout()).thenReturn(30000)
			Mockito.when(mock.isMqconnectRefreshEnabled()).thenReturn(false)
			Mockito.when(mock.isCcmulesoftRestClientRefreshEnabled()).thenReturn(false)
			Mockito.when(mock.isInquireRestClientRefreshEnabled()).thenReturn(false)
			Mockito.when(mock.isCgRestClientRefreshEnabled()).thenReturn(false)
			Mockito.when(mock.isProfileRestClientRefreshEnabled()).thenReturn(false)
			Mockito.when(mock.isLscrmSoapHttpClientRefreshEnabled()).thenReturn(false)
			return mock
		}

		@Bean
		@Primary
		LscrmGetAuthInfoClient lscrmGetAuthInfoClient() {
			return Mockito.mock(LscrmGetAuthInfoClient.class)
		}

		@Bean
		@Primary
		InquireProfileRestClient inquireProfileRestClient() {
			return Mockito.mock(InquireProfileRestClient.class)
		}

		@Bean
		@Primary
		com.azure.spring.data.cosmos.core.convert.MappingCosmosConverter mappingCosmosConverter() {
			com.azure.spring.data.cosmos.core.convert.MappingCosmosConverter mock = Mockito.mock(com.azure.spring.data.cosmos.core.convert.MappingCosmosConverter.class)
			Mockito.when(mock.getMappingContext()).thenReturn(Mockito.mock(com.azure.spring.data.cosmos.core.mapping.CosmosMappingContext.class))
			return mock
		}

		@Bean
		@Primary
		com.azure.spring.data.cosmos.core.CosmosTemplate cosmosTemplate(com.azure.spring.data.cosmos.core.convert.MappingCosmosConverter mappingCosmosConverter) {
			com.azure.spring.data.cosmos.core.CosmosTemplate mock = Mockito.mock(com.azure.spring.data.cosmos.core.CosmosTemplate.class)
			Mockito.when(mock.getConverter()).thenReturn(mappingCosmosConverter)
			return mock
		}

		@Bean
		@Primary
		com.azure.spring.data.cosmos.core.ReactiveCosmosTemplate reactiveCosmosTemplate(com.azure.spring.data.cosmos.core.convert.MappingCosmosConverter mappingCosmosConverter) {
			com.azure.spring.data.cosmos.core.ReactiveCosmosTemplate mock = Mockito.mock(com.azure.spring.data.cosmos.core.ReactiveCosmosTemplate.class)
			Mockito.when(mock.getConverter()).thenReturn(mappingCosmosConverter)
			return mock
		}

		@Bean
		Object idgOtpHistoryRepository() {
			try {
				Class<?> repoClass = Class.forName("com.att.idp.idgraph.db.cosmos.repository.IdgOtpHistoryRepository")
				return Mockito.mock(repoClass)
			} catch (ClassNotFoundException e) {
				return Mockito.mock(Object.class)
			}
		}

		@Bean
		Object nonBSSECredentialRepository() {
			try {
				Class<?> repoClass = Class.forName("com.att.idp.idgraph.db.cosmos.repository.NonBSSECredentialRepository")
				return Mockito.mock(repoClass)
			} catch (ClassNotFoundException e) {
				return Mockito.mock(Object.class)
			}
		}
	}
}