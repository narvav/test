package com.att.idp.idgraphcontactinfoms.integration

import com.att.idp.http.client.config.RestTemplateBeanFactory
import com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig
import com.att.idp.idgraphcontactinfoms.utils.JsonService
import com.fasterxml.jackson.databind.JsonNode
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.test.util.ReflectionTestUtils
import org.springframework.web.client.RestTemplate
import spock.lang.Specification

class MuleSoftRestClientTest extends Specification {

    def restTemplate = Mock(RestTemplate)
    def restTemplateBeanFactory = Mock(RestTemplateBeanFactory)
    def appConfiguration = Mock(IDGraphAzureAppConfig)
    def outboundRestClientBuilder = Mock(OutboundRestClientBuilder)
    def muleSoftRestClient

    def setup() {
        muleSoftRestClient = new MuleSoftRestClient(restTemplateBeanFactory, appConfiguration, outboundRestClientBuilder)
        ReflectionTestUtils.setField(muleSoftRestClient, 'restTemplate', restTemplate)
        ReflectionTestUtils.setField(muleSoftRestClient, 'clientid', 'testClientId')
        ReflectionTestUtils.setField(muleSoftRestClient, 'clientsecret', 'testClientSecret')
    }

    def "test postCCMuleSyncCall with successful response"() {
        given:
        def hmNotification = [key: "value"]
        def sTransactionId = "testTransactionId"
        def resourceUri = "http://test-endpoint"
        def responseBody = Mock(JsonNode)
        def responseEntity = new ResponseEntity<>(responseBody, HttpStatus.OK)

        restTemplate.exchange(resourceUri, HttpMethod.POST, _ as HttpEntity, JsonNode) >> responseEntity
        JsonService.getObjectFromJson(responseBody, JsonNode) >> responseBody
        responseBody.get("traceId") >> "testTraceId"

        when:
        def result = muleSoftRestClient.postCCMuleSyncCall(hmNotification, sTransactionId, resourceUri)

        then:
        result != null
        result["traceId"] != "testTraceId"
    }

    def "test postCCMuleSyncCall with error response"() {
        given:
        def hmNotification = [key: "value"]
        def sTransactionId = "testTransactionId"
        def resourceUri = "http://test-endpoint"
        def responseBody = Mock(JsonNode)
        def responseEntity = new ResponseEntity<>(responseBody, HttpStatus.BAD_REQUEST)

        restTemplate.exchange(resourceUri, HttpMethod.POST, _ as HttpEntity, JsonNode) >> responseEntity

        when:
        def result = muleSoftRestClient.postCCMuleSyncCall(hmNotification, sTransactionId, resourceUri)

        then:
        result != null
        result["appStatusCode"] == "610"
    }

    def "test postCCMuleSyncCall with exception"() {
        given:
        def hmNotification = [key: "value"]
        def sTransactionId = "testTransactionId"
        def resourceUri = "http://test-endpoint"

        restTemplate.exchange(resourceUri, HttpMethod.POST, _ as HttpEntity, JsonNode) >> { throw new RuntimeException("Test exception") }

        when:
        def result = muleSoftRestClient.postCCMuleSyncCall(hmNotification, sTransactionId, resourceUri)

        then:
        result != null
        result["appStatusCode"] == "610"
    }
}