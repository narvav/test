package com.att.idp.idgraphcontactinfoms.service.impl

import com.att.idp.idgraphcontactinfoms.helpers.QueryCPNIUserContactHelper
import com.att.idp.idgraphcontactinfoms.resource.request.QueryCPNIUserContactInfoRequest
import com.att.idp.idgraphcontactinfoms.resource.response.QueryCPNIUserContactInfoResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import jakarta.ws.rs.core.MultivaluedMap
import spock.lang.Specification
import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap

class QueryCPNIUserContactInfoServiceImplTest extends Specification {

	def QueryCPNIUserContactInfoServiceImpl queryCPNIUserContactInfoServiceImplObj = new QueryCPNIUserContactInfoServiceImpl()
	QueryCPNIUserContactHelper queryCPNIUserContactHelper = Mock(QueryCPNIUserContactHelper)
	QueryCPNIUserContactInfoRequest queryCPNIUserContactInfoRequest = null
	MultivaluedMap<String, String> requestHeader = null
	Map<String, String> headers = new HashMap<>()

	def setup() throws Exception {
		queryCPNIUserContactInfoServiceImplObj.queryCPNIUserContactHelper = queryCPNIUserContactHelper
		queryCPNIUserContactInfoRequest = new QueryCPNIUserContactInfoRequest()
		requestHeader = new MultivaluedHashMap<>(headers)

		queryCPNIUserContactInfoRequest.setCallingSystemId('IDP')
		queryCPNIUserContactInfoRequest.setUserId('qay_7213298')
		queryCPNIUserContactInfoRequest.setDomain('slid.dum')
		queryCPNIUserContactInfoRequest.setGuid('39587')
		queryCPNIUserContactInfoRequest.setReturnCBRCTNs('36546')
		queryCPNIUserContactInfoRequest.setIsExternalCall('Y')
		queryCPNIUserContactInfoRequest.setIdpTraceId('99dfs999:8dfs8888:77777:66666ccc')
	}

	def "query cpni user null case test"() {
		given:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoServiceImplObj.queryCPNIUserContactInfo(queryCPNIUserContactInfoRequest, requestHeader)

		and:
		def hmResponse = [(MPSDefs.APP_STATUS_CODE): null]
		queryCPNIUserContactHelper.queryCPNIUserContact(_) >> hmResponse

		when:
		response = queryCPNIUserContactInfoServiceImplObj.queryCPNIUserContactInfo(queryCPNIUserContactInfoRequest, requestHeader)

		then:
		response.appInfo == 'Null response from queryAccountContactInfoHelper.queryCPNIAccountContactInfo'
	}

	def "query cpni user success case test"() {
		given:
		def hmResponse = [
				(CommonDefs.TRANSACTION_ID): 'trma_16374856',
				(MPSDefs.APP_STATUS_CODE): '0',
				'appInfo': 'Success'
		]
		queryCPNIUserContactHelper.queryCPNIUserContact(_) >> hmResponse

		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoServiceImplObj.queryCPNIUserContactInfo(queryCPNIUserContactInfoRequest, requestHeader)

		then:
		response != null
		response.idpTraceId != null
	}

	def "query cpni user contact info returns null response from helper"() {
		given:
		queryCPNIUserContactHelper.queryCPNIUserContact(_) >> null
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoServiceImplObj.queryCPNIUserContactInfo(queryCPNIUserContactInfoRequest, requestHeader)
		then:
		response != null
		response.appInfo == 'Null response from queryUserContactInfoHelper.queryCPNIUserContactInfo'
		response.appStatusMsg == null || response.appStatusMsg == 'ERR_SYS_APPL'
	}

	def "query cpni user contact info returns empty response from helper"() {
		given:
		queryCPNIUserContactHelper.queryCPNIUserContact(_) >> [:]
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoServiceImplObj.queryCPNIUserContactInfo(queryCPNIUserContactInfoRequest, requestHeader)
		then:
		response != null
		response.appInfo == 'Null response from queryUserContactInfoHelper.queryCPNIUserContactInfo'
		response.appStatusMsg == null || response.appStatusMsg == 'ERR_SYS_APPL'
	}

	def "query cpni user contact info returns null status code in response"() {
		given:
		def hmResponse = [appInfo: 'Some info', (MPSDefs.APP_STATUS_CODE): null]
		queryCPNIUserContactHelper.queryCPNIUserContact(_) >> hmResponse
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoServiceImplObj.queryCPNIUserContactInfo(queryCPNIUserContactInfoRequest, requestHeader)
		then:
		response != null
		response.appInfo == 'Null response from queryAccountContactInfoHelper.queryCPNIAccountContactInfo'
		response.appStatusMsg == null || response.appStatusMsg == 'ERR_SYS_APPL'
	}

	def "query cpni user contact info stub response returns valid stub"() {
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoServiceImplObj.stubResponse()
		then:
		response != null
		response.appStatusCode == '0'
		response.appStatusMsg == 'SUCCESS'
		response.idpTraceId == '48f9de4f104b345a:48f9de4f104b345a:0:0'
		response.appCategoryCode == '0'
	}

	def "query cpni user contact info success with all fields"() {
		given:
		def hmResponse = [
			(CommonDefs.TRANSACTION_ID): 'trma_16374856',
			(MPSDefs.APP_STATUS_CODE): '0',
			'appInfo': 'Success',
			'appStatusMsg': 'SUCCESS',
			'idp-trace-id': 'idpTraceIdValue',
			(CommonDefs.TRANSACTION_NAME): 'QueryCPNIUserContactInfo'
		]
		queryCPNIUserContactHelper.queryCPNIUserContact(_) >> hmResponse
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoServiceImplObj.queryCPNIUserContactInfo(queryCPNIUserContactInfoRequest, requestHeader)
		then:
		response != null
		response.appStatusCode == '0'
		response.appStatusMsg == 'SUCCESS'
		response.appInfo == 'Success'
		response.transactionName == 'QueryCPNIUserContactInfo'
	}
}