package com.att.idp.idgraphcontactinfoms.request.validator

import com.att.idp.idgraphcontactinfoms.resource.request.*
import com.att.idp.idgraphcontactinfoms.resource.response.GeneratePINResponse
import com.att.mpsys.common.utils.CommonUtil
import jakarta.ws.rs.core.MultivaluedHashMap
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import jakarta.ws.rs.core.HttpHeaders

class GeneratePINRequestValidatorTest extends Specification {

	def generatePINReqValidatorObj = new GeneratePINRequestValidator()
	public GeneratePINRequest generatePINReqObj = null
	public DeliveryMethods deliveryMethodObj = null

	def requestHeader = Stub(HttpHeaders)
	public MultivaluedHashMap requestHeaders = null
	private Map<String, String> headers = new HashMap<>()
	private AttributeList attributeListO = null
	private List<AttributeList> alAttributeList = null


	def setup() {

		requestHeaders = new MultivaluedHashMap<>(headers)
		generatePINReqObj = new GeneratePINRequest()
		deliveryMethodObj = new DeliveryMethods()
		attributeListO = new AttributeList()
		alAttributeList = CommonUtil.arrayList
		Email emailObj = new Email()

//		generatePINReqObj.setTransactionName("GeneratePIN");
//		generatePINReqObj.setCallingSystemId("IDP");
		generatePINReqObj.identificationType = 'EMAILOTP'
		generatePINReqObj.accountId = '4256374859'
		generatePINReqObj.agentId = '12345'
		generatePINReqObj.browserLanguage = 'EN'
		generatePINReqObj.resBusInd = 'R'
		generatePINReqObj.returnSecurityCode = 'Y'
		generatePINReqObj.transactionId = 'trma_16374856'
		generatePINReqObj.accountType = 'Mobility'
		attributeListO.attributeName = 'employeeFlag'
		attributeListO.attributeValue = 'active'
		alAttributeList.add(attributeListO)
		generatePINReqObj.attributeList = alAttributeList

		emailObj.emailAddress = 'max@gmail.com'
		deliveryMethodObj.email = emailObj
		generatePINReqObj.deliveryMethods = deliveryMethodObj

		ReflectionTestUtils.setField(generatePINReqValidatorObj, 'propCallingSystemId',
				'IDSEMOB:IDP|DATAMGT,BANPCS:OPUS|IDP|CSRIDP,BANPCE:OPUS,BANPTONLS:MYATTSALES|IDP|UPPERFUNNEL|ANDIVA,BANPTONLE:MYATTSALES|IDP|ANDIVA,DTVNOWOTP:CSRIDP,CTNKSK:EXPKSK,BTN:IDP|DATAMGT,PINVALID:IDP|CSRIDP,NONATTCTN:IDP|CSRIDP|OPUS,ATTCTN:IDP|CSRIDP,EMAILOTP:IDP|OPUS,CRICKETOTP:IDP|CSRIDP|OPUS,EMAILPIN:IDP|CSRIDP|OPUS|ERICSSON|MYATTSALES|IDPSALES|MULESOFT|MYATTMOBILE,CTNDIH:IDP|CSRIDP|OPUS,BANAP:PENNYVA,TITANIMD:IDP|CSRIDP,CTN:IDP|CSRIDP,WBAN:IDP|CSRIDP,ECOMMSEC:IDP|CSRIDP,WBANSEC:IDP|CSRIDP,TITANSEC:IDP|CSRIDP,DTVOTP:DIRECTV,CTNAUTH:MULESOFT,CTNOPR:IDP|CSRIDP,ENCPIN:IDPSALES,PORTOUT:AVERTACK,CCPADTV:IDP,BSSEOTP:IDP|MULESOFT|IVR,BSSEONL:IDP,BSSEREGOTP:IDP')
		ReflectionTestUtils.setField(generatePINReqValidatorObj, 'propDeliveryMethods',
				'IDSEMOB:sms|email,BANPCS:sms,BANPCE:email,BANPTONLS:sms,BANPTONLE:email,DTVNOWOTP:sms|email,CTNKSK:sms,BTN:sms|email|letter|ao,PINVALID:sms|email,NONATTCTN:sms,ATTCTN:sms,EMAILOTP:email,CRICKETOTP:email,EMAILPIN:email,CTNDIH:sms,BANAP:sms|email,TITANIMD:sms|email|letter|ao,CTN:sms|email|letter|ao,WBAN:sms|email|letter|ao,ECOMMSEC:sms|email|letter|ao,WBANSEC:sms|email|letter|ao,TITANSEC:sms|email|letter|ao,DTVOTP:email,CTNAUTH:sms,CTNOPR:sms,ENCPIN:sms|email,CCPADTV:email,BSSEOTP:sms|email,BSSEONL:sms|email,BSSEREGOTP:sms|email')
		ReflectionTestUtils.setField(generatePINReqValidatorObj, 'propAgentCallingSystemId', 'OPUS|CSRIDP')
		ReflectionTestUtils.setField(generatePINReqValidatorObj, 'propAttributeName',
				'EMAILOTP:employeeFlag,EMAILPIN:DirecTVCustomerInd')
		ReflectionTestUtils.setField(generatePINReqValidatorObj, 'propAttributeValue',
				'employeeFlag:active|notactive,DirecTVCustomerInd:Y|N')


		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getRequestHeaders() >> requestHeaders
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
	}


	def "generate p i n null request test"() {
		given:
		GeneratePINRequest generatePINRequestObj = null
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINRequestObj)
		then:
		generatePINResponse.appInfo == 'Input Request is NULL / Empty.'
	}


	def "null x att client i d and c s i test"() {
		given:

		generatePINReqObj.callingSystemId = null
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> null
		generatePINResponse.appInfo == 'Either X-ATT-ClientId in request header or callingSystemId in request body must be present'
	}


	def "null x att client i d valid c s i test"() {
		given:
		generatePINReqObj.callingSystemId = 'IDP'
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> null
		generatePINResponse == null
	}


	def "valid x att client i d null c s i test"() {
		given:
		//Mockito.lenient().doReturn('IDP').when(requestHeader).getHeaderString('X-ATT-ClientId')
		generatePINReqObj.callingSystemId = null
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		generatePINResponse == null
	}


	def "null identification type test"() {
		//Mockito.doReturn(null).when(requestHeader).getHeaderString("idp-trace-id");
		given:
		generatePINReqObj.identificationType = null
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'IdentificationType can not be null / empty.'
	}


	def "null account i d test"() {
		given:
		generatePINReqObj.accountId = null
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'AccountID can not be null / empty.'
	}


	def "invalid browser lang test"() {
		given:
		generatePINReqObj.browserLanguage = 'ed'
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'BrowserLanguage is Invalid :: Should be one of [en, es]'
	}


	def "invalid return sec code test"() {
		given:
		generatePINReqObj.returnSecurityCode = 'e'
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'returnSecurityCode is Invalid :: Should be one of [Y, N]'
	}


	def "invalid res bus ind test"() {
		given:
		generatePINReqObj.resBusInd = 'e'
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'resBusInd is Invalid :: Should be one of [R, B]'
	}


	def "invalid identification type test"() {
		given:
		generatePINReqObj.identificationType = 'IEMOB'
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'Input identificationType is not valid'
	}


	def "invalid c s i test"() {
		given:
		//Mockito.doReturn('DATAMGT').when(requestHeader).getHeaderString('X-ATT-ClientId')
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'DATAMGT'
		generatePINResponse.appInfo == 'X-ATT-ClientId or callingSystemId is not valid for input identificationType'
	}


	def "null agent id for agent c s i test"() {
		given:
		//Mockito.doReturn('OPUS').when(requestHeader).getHeaderString('X-ATT-ClientId')
		generatePINReqObj.agentId = null
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'OPUS'
		generatePINResponse.appInfo == 'agentId is required'
	}


	def "null delivery method for agent c s i test"() {
		given:
		generatePINReqObj.deliveryMethods = null
		//Mockito.doReturn('OPUS').when(requestHeader).getHeaderString('X-ATT-ClientId')
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'OPUS'
		generatePINResponse.appInfo == 'deliveryMethods is required for agentId'
	}


	def "null delivery method and return sec code c s i test"() {
		given:
		generatePINReqObj.deliveryMethods = null
		generatePINReqObj.returnSecurityCode = 'N'
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'Both deliveryMethods and returnSecurityCode are not available. At least one of them is needed in the request.'
	}


	def "sms delivery method test"() {
		given:
		Sms smsO = new Sms()
		Email emailO = new Email()
		deliveryMethodObj.sms = smsO
		deliveryMethodObj.email = emailO
		generatePINReqObj.deliveryMethods = deliveryMethodObj
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'exactly one of sms or email or letter or ao deliveryMethod must be present in input'

		when:
		deliveryMethodObj.email = null
		generatePINReqObj.deliveryMethods = deliveryMethodObj
		generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader, generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'smsPhoneNumber is missing for sms deliveryMethod'
	}


	def "email delivery method test"() {
		given:
		Letter letterO = new Letter()
		deliveryMethodObj.email.emailAddress = null

		deliveryMethodObj.email = deliveryMethodObj.email
		generatePINReqObj.deliveryMethods = deliveryMethodObj

		generatePINReqObj.deliveryMethods = deliveryMethodObj
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'emailAddress is missing for email deliveryMethod'

		when:
		deliveryMethodObj.letter = letterO
		generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader, generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'exactly one of sms or email or letter deliveryMethod must be present in input'
	}


	def "letter delivery method missing mandatory field test"() {
		given:
		Letter letterO = new Letter()
		letterO.zipCode = '12345'
		letterO.street1 = 'MG'
		letterO.state = 'abc'
		letterO.city = ''
		deliveryMethodObj.letter = letterO
		deliveryMethodObj.email = null
		generatePINReqObj.deliveryMethods = deliveryMethodObj

		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'street1|city|state|zipCode are required for letter deliveryMethod'
	}

	def "letter delivery method country optional test"() {
		given:
		Letter letterO = new Letter()
		letterO.street1 = '3400 Plano Pkwy'
		letterO.city = 'Plano'
		letterO.state = 'TX'
		letterO.zipCode = '75075'
		letterO.country = 'CAN'
		deliveryMethodObj.letter = letterO
		deliveryMethodObj.email = null
		generatePINReqObj.deliveryMethods = deliveryMethodObj
		generatePINReqObj.identificationType = 'BTN'
		generatePINReqObj.attributeList = null

		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse == null
	}


	def "ao delivery method null phone number test"() {
		given:
		Ao aoObj = new Ao()
		deliveryMethodObj.ao = aoObj
		generatePINReqObj.deliveryMethods = deliveryMethodObj

		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'phoneNumber is required for ao deliveryMethod'
	}

	def "ao delivery method blank phone number test"() {
		given:
		Ao aoObj = new Ao()
		aoObj.phoneNumber = '  '
		deliveryMethodObj.ao = aoObj
		generatePINReqObj.deliveryMethods = deliveryMethodObj

		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'phoneNumber is required for ao deliveryMethod'
	}


	def "invalid delivery method test"() {
		given:
		Ao aoObj = new Ao()
		aoObj.phoneNumber = '34567786543'
		deliveryMethodObj.ao = aoObj
		deliveryMethodObj.email = null
		generatePINReqObj.deliveryMethods = deliveryMethodObj

		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'Input delivery method is not supported for input identificationType'
	}


	def "null attribute name test"() {
		given:
		attributeListO.attributeName = ''
		alAttributeList.add(attributeListO)
		generatePINReqObj.attributeList = alAttributeList

		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'Input AttributeName is null or empty'
	}


	def "null attribute value test"() {
		given:
		attributeListO.attributeValue = ''
		alAttributeList.add(attributeListO)
		generatePINReqObj.attributeList = alAttributeList

		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'Input AttributeValue is null or empty'

	}


	def "invalid identification type for attribute test"() {
		given:
		generatePINReqObj.identificationType = 'EMAILPIN'

		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'Input IdentificationType is not valid for input attributeName'
	}


	def "invalid attribute name test"() {
		given:
		attributeListO.attributeValue = 'Y'
		alAttributeList.add(attributeListO)
		generatePINReqObj.attributeList = alAttributeList

		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'Input attributeName is not valid for input attributeValue'
	}


	def "request validator success test"() {
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse == null
	}


	def "test request validator when prop c s i empty"() {
		given:
		ReflectionTestUtils.setField(generatePINReqValidatorObj, 'propCallingSystemId', '')
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'The value of generatePINCallingSystemIds is not configured in property files'
	}


	def "test request validator when prop attribute is empty"() {
		given:
		ReflectionTestUtils.setField(generatePINReqValidatorObj, 'propAttributeName',null)
		ReflectionTestUtils.setField(generatePINReqValidatorObj, 'propAttributeValue',null)
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,
				generatePINReqObj)
		then:
		generatePINResponse.appInfo == 'PropPinAttributeName | propAttributeValue value is null or empty'
	}


	def "generate p i n request c s i validator exception test"() throws Exception {
		given:
		ReflectionTestUtils.setField(generatePINReqValidatorObj, 'propCallingSystemId', null)
		when:
		GeneratePINResponse generatePINResponse = generatePINReqValidatorObj.generatePINRequestValidator(requestHeader,generatePINReqObj)
		then:
		generatePINResponse == null
	}

}
