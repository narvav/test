package com.att.idp.QAIntegration.Base

import com.att.idp.QAIntegration.Config.ContactInfoGlobalConfig
import com.att.idp.QAIntegration.Report.QG7ExtentReportListener
import com.att.idp.QAIntegration.Report.QG7TestResultCollector
import com.att.idp.QAIntegration.Utils.Utility
import groovy.json.JsonOutput
import groovy.util.logging.Slf4j
import io.restassured.RestAssured
import io.restassured.http.ContentType
import io.restassured.response.Response
import io.restassured.specification.RequestSpecification
import spock.lang.Specification

import java.util.Collections

/**
 * Unified base class for IDGraphContactInfoMs QG7 integration tests.
 *
 * Merges former BaseSpec (auth + RestAssured setup) and the static HTTP/logging
 * helpers into a single class — all specs simply extend TestBase.
 *
 * Responsibilities:
 *  - setupSpec(): resolve authorization (secrets cache → fallback) and configure RestAssured once per spec
 *  - sendRequest(): build and fire RestAssured HTTP calls with auth + headers from ContactInfoGlobalConfig
 *  - logStep() / logCustomMessage(): Slf4j + ExtentReport logging
 *  - Internal logToExtentReport(): rich HTML request/response panel written to the active test node
 */
@Slf4j
class TestBase extends Specification {

    private static final int MAX_LOG_LENGTH = 1500
    private static final ThreadLocal<String> currentTestName = new ThreadLocal<>()

    // ── Shared state populated in setupSpec() ────────────────────────────
    static String baseUrl
    static String authorization

    // ── Spec lifecycle ───────────────────────────────────────────────────

    def setupSpec() {
        RestAssured.useRelaxedHTTPSValidation()

        authorization = Utility.getAuthorizationFromSecretCache()
        if (authorization) {
            log.info("Authorization retrieved from .secretscachefolder")
        } else {
            log.warn("Authorization not found in secrets cache — ContactInfoGlobalConfig will attempt fallback")
        }

        baseUrl = ContactInfoGlobalConfig.getBaseUrl()
        boolean isBlueGreen = baseUrl != null && (baseUrl ==~ /(?i)^https?:\/\/.*-(blue|green)\/?$/)
        String runMode = isBlueGreen ? "BLUE/GREEN INGRESS (no /idgraph)" : "APPORIGIN (adds /idgraph)"
        log.info("TestBase.setupSpec() — env={}, baseUrl={}, mode={}", 
                ContactInfoGlobalConfig.getCurrentTestEnv(), baseUrl, runMode)
    }

    // ── Test name tracking (used by logStep) ─────────────────────────────

    static void setTestName(String name) {
        currentTestName.set(name)
    }

    // ── HTTP request ─────────────────────────────────────────────────────

    static Response sendRequest(
            String endpoint,
            String method,
            String requestBody = null,
            Map<String, String> extraHeaders = [:],
            Map<String, String> queryParams = [:]) {

        String resolvedBaseUrl  = ContactInfoGlobalConfig.getBaseUrl()
        String resolvedAuth     = ContactInfoGlobalConfig.getAuthorization()
        String resolvedPath     = resolveEndpointForBaseUrl(resolvedBaseUrl, endpoint)

        RestAssured.baseURI  = resolvedBaseUrl
        RestAssured.basePath = resolvedPath

        Map<String, String> headers = [
                "Content-Type" : ContactInfoGlobalConfig.CONTENT_TYPE,
                "Accept"       : ContactInfoGlobalConfig.ACCEPT,
                "Authorization": resolvedAuth
        ]
        if (extraHeaders) {
            headers.putAll(extraHeaders)
        }

        RequestSpecification request = RestAssured.given()
                .contentType(ContentType.JSON)
                .headers(headers)
                .relaxedHTTPSValidation()
                .body(requestBody != null ? requestBody : Collections.emptyMap())
                .queryParams(queryParams ?: Collections.emptyMap())

        Response response = request.request(method)

        try {
            logToExtentReport(resolvedBaseUrl + resolvedPath, headers, requestBody, response, queryParams, method)
        } catch (Exception e) {
            log.debug("ExtentReport logging skipped: {}", e.message)
        }

        // Track 5xx errors for the email report
        int sc = response.statusCode()
        if (sc >= 500 && sc < 600) {
            try {
                QG7TestResultCollector.getInstance().recordServerError(
                        currentTestName.get() ?: "Unknown",
                        resolvedBaseUrl + resolvedPath,
                        sc
                )
            } catch (Exception e) {
                log.debug("5xx tracking skipped: {}", e.message)
            }
        }

        return response
    }

    // ── Logging helpers ───────────────────────────────────────────────────

    static void logStep(String stepDescription) {
        log.info("STEP: {}", stepDescription)
        try {
            QG7ExtentReportListener.getCurrent()?.info(
                    "<b style='color:#117A65;font-family:Arial'>STEP:</b> " +
                    "<span style='font-family:Arial'>${stepDescription}</span>")
        } catch (Exception e) {
            log.debug("ExtentReport step logging skipped: {}", e.message)
        }
    }

    static void logCustomMessage(String message) {
        log.info("{}", message)
        try {
            QG7ExtentReportListener.getCurrent()?.info(message)
        } catch (Exception e) {
            log.debug("ExtentReport message logging skipped: {}", e.message)
        }
    }


    // ── Internal helpers ──────────────────────────────────────────────────

    /**
     * Resolves the endpoint path based on the BASE_URL type.
     * 
     * URL Types:
     * 1. Apporigin URLs (e.g., https://apporigin-tst3-idpgraph-e2.az.3pc.att.com:8443)
     *    → Need /idgraph in path: /msapi/idgraph/contactinfoms/v1/...
     * 
     * 2. Blue/Green Ingress URLs (e.g., https://...idgraphcontactinfoms-blue)
     *    → NO /idgraph in path: /msapi/contactinfoms/v1/...
     *    (service path is already in the BASE_URL)
     * 
     * The YAML endpoints are defined WITHOUT /idgraph (e.g., /msapi/idgraphcontactinfoms/v1/pin/generate)
     * This method adds /idgraph after /msapi for apporigin URLs.
     */
    private static String resolveEndpointForBaseUrl(String baseUrl, String endpoint) {
        if (!endpoint) {
            return endpoint
        }

        if (isBlueGreenIngressUrl(baseUrl)) {
            // Blue/Green ingress URLs: use endpoint as-is (no /idgraph needed)
            log.debug("Blue/Green Ingress URL — using endpoint as-is: {}", endpoint)
            return endpoint
        }

        // Apporigin URLs: need to add /idgraph after /msapi
        // Transform: /msapi/idgraphcontactinfoms/v1/... → /msapi/idgraph/idgraphcontactinfoms/v1/...
        if (endpoint.startsWith("/msapi/") && !endpoint.startsWith("/msapi/idgraph/")) {
            String resolved = endpoint.replaceFirst('^/msapi/', '/msapi/idgraph/')
            log.debug("Apporigin URL — endpoint resolved: {} → {}", endpoint, resolved)
            return resolved
        }

        log.debug("Using original endpoint: {}", endpoint)
        return endpoint
    }

    /**
     * Checks if the BASE_URL is a blue/green ingress URL.
     * Blue/green URLs end with -blue or -green (case-insensitive).
     * Example: https://api.graph1eus2-dev2.az.3pc.att.com/test/idgraphcontactinfoms-blue
     */
    private static boolean isBlueGreenIngressUrl(String baseUrl) {
        return baseUrl != null && (baseUrl ==~ /(?i)^https?:\/\/.*-(blue|green)\/?$/)
    }

    private static void logToExtentReport(
            String uri,
            Map<String, String> headers,
            String requestBody,
            Response response,
            Map<String, String> queryParams,
            String method) {

        String[] segments = uri.split("/")
        String apiName = segments.length >= 2 ? "/${segments[-2]}/${segments[-1]}" : uri

        StringBuilder html = new StringBuilder()
        html.append("<div style='font-family:Arial,sans-serif;max-width:900px;margin:10px auto;border:2px solid #2F80ED;border-radius:8px;padding:15px;background:#f0f8ff'>")
        html.append("<h2 style='color:#2F80ED;margin-bottom:8px'>API: ").append(apiName).append("</h2>")
        html.append("<p><b style='color:#B03A2E'>Method:</b> <span style='color:#fff;background:#B03A2E;padding:2px 8px;border-radius:4px'>").append(method).append("</span></p>")
        html.append("<p><b style='color:#104E8B'>URI:</b> <span style='color:#333'>").append(uri).append("</span></p>")

        if (queryParams) {
            html.append("<div style='background:#F9E79F;padding:10px;border-radius:6px;margin-bottom:10px'>")
                    .append("<h3 style='color:#B7950B;margin:0 0 8px 0'>Query Parameters</h3>")
            queryParams.each { k, v -> html.append("<div><b>").append(k).append("</b>: ").append(v).append("</div>") }
            html.append("</div>")
        }

        html.append("<div style='background:#D6EAF8;padding:10px;border-radius:6px;margin-bottom:10px'>")
                .append("<h3 style='color:#1B4F72;margin:0 0 8px 0'>Request Headers</h3>")
        headers.each { k, v ->
            html.append("<div><b style='color:#154360'>").append(k)
                    .append("</b>: <span style='color:#1C2833'>").append(v).append("</span></div>")
        }
        html.append("</div>")

        html.append("<div style='background:#EBF5FB;padding:10px;border-radius:6px;margin-bottom:10px'>")
                .append("<h3 style='color:#21618C;margin:0 0 8px 0'>Request Body</h3>")
                .append("<pre style='white-space:pre-wrap;word-wrap:break-word;font-size:13px;color:#0B5345'>")
                .append(truncate(prettyPrintJson(requestBody), MAX_LOG_LENGTH))
                .append("</pre></div>")

        html.append("<p><b style='color:#117A65'>Response Status:</b> <span style='color:#0E6251'>")
                .append(response.statusCode).append("</span></p>")
        html.append("<div style='background:#D1F2EB;padding:10px;border-radius:6px;margin-top:10px'>")
                .append("<h3 style='color:#138D75;margin:0 0 8px 0'>Response Body</h3>")
                .append("<pre style='white-space:pre-wrap;word-wrap:break-word;font-size:13px;color:#0B5345'>")
                .append(truncate(prettyPrintJson(response.body?.asPrettyString()), MAX_LOG_LENGTH))
                .append("</pre></div></div>")

        QG7ExtentReportListener.getCurrent()?.info(html.toString())
    }

    private static String prettyPrintJson(String json) {
        if (!json?.trim()) return ""
        try { return JsonOutput.prettyPrint(json) } catch (Exception e) { return json }
    }

    private static String truncate(String input, int maxLength) {
        if (!input) return ""
        input.length() <= maxLength ? input : input.substring(0, maxLength) + "\n... (truncated)"
    }
}
