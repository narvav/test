package com.att.idp.QAIntegration.Config

import com.att.idp.QAIntegration.Utils.Utility
import groovy.util.logging.Slf4j
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.yaml.snakeyaml.Yaml

import java.util.regex.Pattern

/**
 * Central configuration for IDGraphContactInfoMs QG7 integration tests.
 *
 * ALL configuration (environment URLs, email settings, env-hint patterns, defaults)
 * is loaded from {@code src/test/resources/CONFIG/contactinfo-global-config.yaml}.
 * No values are hardcoded here — edit the YAML to change any setting.
 *
 * Environment resolution priority (first match wins):
 *   1. BASE_URL                  — inferred via envHints regex from YAML
 *   2. INTEGRATION_TEST_ENV      — inferred or used as-is
 *   3. INTEGRATION_TEST_CLUSTER  — inferred via envHints regex from YAML
 *   4. defaultEnv from YAML      — fallback (default: TEST3)
 */
@Slf4j
class ContactInfoGlobalConfig {

    private static final String CONFIG_RESOURCE = "/CONFIG/contactinfo-global-config.yaml"

    private static final Map<String, Object> GLOBAL_CONFIG = loadGlobalConfig()

    static final String DEFAULT_ENV   = GLOBAL_CONFIG.defaultEnv   as String ?: "TEST3"
    static final String CONTENT_TYPE  = GLOBAL_CONFIG.contentType  as String ?: "application/json"
    static final String ACCEPT        = GLOBAL_CONFIG.accept        as String ?: "application/json"

    static final Map<String, String> ENVIRONMENTS = (GLOBAL_CONFIG.environments as Map<String, String>) ?: [:]

    private static final Map<String, Pattern> ENV_HINT_PATTERNS = buildHintPatterns(GLOBAL_CONFIG.envHints as Map)

    private static final Map<String, String> EMAIL_CONFIG = (GLOBAL_CONFIG.email as Map<String, String>) ?: [:]

    private static final Map<String, List<String>> TEST_CASE_FILTER = (GLOBAL_CONFIG.testCases as Map<String, List<String>>) ?: [:]

    /**
     * All API endpoint paths loaded from CONFIG/contactinfo-global-config.yaml.
     * Usage: ContactInfoGlobalConfig.Endpoints.GENERATE_PIN
     * To change a path — edit the YAML, no code change needed.
     */
    static class Endpoints {
        private static final Map<String, String> EP = (GLOBAL_CONFIG.endpoints as Map<String, String>) ?: [:]

        // PIN endpoints
        static final String GENERATE_PIN = EP.get("generatePin") ?: "/msapi/idgraphcontactinfoms/v1/pin/generate"
        static final String VALIDATE_PIN = EP.get("validatePin") ?: "/msapi/idgraphcontactinfoms/v1/pin/validate"
        static final String DELETE_PIN   = EP.get("deletePin")   ?: "/msapi/idgraphcontactinfoms/v1/pin/delete"
        static final String INQUIRE_PIN  = EP.get("inquirePin")  ?: "/msapi/idgraphcontactinfoms/v1/pin/inquire"
        // CPNI Contact Info endpoints
        static final String CPNI_CONTACT_INFO_ACCOUNT = EP.get("cpniContactInfoAccount") ?: "/msapi/idgraphcontactinfoms/v1/cpniContactInfo/account"
        static final String CPNI_CONTACT_INFO_USER    = EP.get("cpniContactInfoUser")    ?: "/msapi/idgraphcontactinfoms/v1/cpniContactInfo/user"
        static final String CPNI_CONTACT_INFO         = EP.get("cpniContactInfo")        ?: "/msapi/idgraphcontactinfoms/v1/cpniContactInfo"
        // Actuator
        static final String HEARTBEAT    = EP.get("heartbeat")   ?: "/msapi/actuator/heartbeat"
    }

    private static String  CACHED_ENV       = null
    private static Map     CACHED_TEST_DATA = null
    private static boolean LOGGED_PARAMS    = false

    // ── Config YAML loader ────────────────────────────────────────────

    private static Map<String, Object> loadGlobalConfig() {
        Logger initLog = LoggerFactory.getLogger(ContactInfoGlobalConfig.class)
        InputStream is = null
        try {
            is = ContactInfoGlobalConfig.class.getResourceAsStream(CONFIG_RESOURCE)
            if (is != null) {
                Map loaded = new Yaml().load(is) as Map ?: [:]
                initLog.info("ContactInfoGlobalConfig loaded from classpath:{}", CONFIG_RESOURCE)
                return loaded
            }
            File fallback = new File("src/test/resources${CONFIG_RESOURCE}")
            if (fallback.exists()) {
                Map loaded = new Yaml().load(fallback.text) as Map ?: [:]
                initLog.info("ContactInfoGlobalConfig loaded from file: {}", fallback.absolutePath)
                return loaded
            }
            initLog.warn("contactinfo-global-config.yaml not found — using empty defaults")
            return [:]
        } catch (Exception e) {
            initLog.error("Failed to load contactinfo-global-config.yaml: {}", e.message, e)
            return [:]
        } finally {
            try { is?.close() } catch (Exception ignored) { /* safe close */ }
        }
    }

    private static Map<String, Pattern> buildHintPatterns(Map raw) {
        if (!raw) return [:]
        Map<String, Pattern> patterns = [:]
        raw.each { k, v -> patterns[k as String] = Pattern.compile(v as String) }
        return patterns
    }

    // ── Public API ────────────────────────────────────────────────────

    static Map<String, String> getEmailConfig() { EMAIL_CONFIG }

    static synchronized String getCurrentTestEnv() {
        if (CACHED_ENV != null) return CACHED_ENV
        CACHED_ENV = determineEnv()
        return CACHED_ENV
    }

    static String getBaseUrl() {
        String explicit = System.getProperty("BASE_URL")?.trim()
        if (explicit?.toLowerCase(Locale.US)?.startsWith("http")) return explicit
        String envKey = normalizeEnvName(explicit ?: getCurrentTestEnv()) ?: DEFAULT_ENV
        return ENVIRONMENTS[envKey] ?: ENVIRONMENTS[DEFAULT_ENV]
    }

    static String getAuthorization() {
        String token = System.getProperty("AUTHORIZATION")?.trim()
        if (token) {
            log.info("Authorization sourced from -DAUTHORIZATION system property")
        } else {
            token = Utility.getAuthorizationFromSecretCache()?.trim()
        }
        if (!token) return null
        if (token.toLowerCase(Locale.US).startsWith("basic ") ||
            token.toLowerCase(Locale.US).startsWith("bearer ")) {
            return token
        }
        return "Basic ${token}"
    }

    static String getDataFileDirectory() {
        "src/test/resources/QATestData/${getCurrentTestEnv()}/"
    }

    static synchronized Map getTestData() {
        if (CACHED_TEST_DATA == null) {
            String dir    = getDataFileDirectory()
            File yamlFile = new File(dir + "IDGraphContactInfoMs_TestData.yaml")
            if (yamlFile.exists()) {
                CACHED_TEST_DATA = new Yaml().load(yamlFile.text) as Map ?: [:]
                log.info("Test data loaded from: {}", yamlFile.absolutePath)
            } else {
                log.warn("Test data YAML not found at: {}. Using empty defaults.", yamlFile.absolutePath)
                CACHED_TEST_DATA = [:]
            }
        }
        return new LinkedHashMap(CACHED_TEST_DATA)
    }

    /**
     * Check if a test case is enabled for the current environment.
     * If the environment is not in the testCases filter, ALL tests run by default.
     * If the environment is in the filter, only listed tests run.
     *
     * @param testCaseName The test case name (e.g., "HeartbeatITSpec" or feature name)
     * @return true if the test should run, false if it should be skipped
     */
    static boolean isTestCaseEnabled(String testCaseName) {
        String env = getCurrentTestEnv()
        List<String> enabledTests = TEST_CASE_FILTER.get(env)
        
        if (enabledTests == null || enabledTests.isEmpty()) {
            log.info("No test case filter configured for env {} — test '{}' will run (all tests enabled)", env, testCaseName)
            return true
        }
        
        boolean enabled = enabledTests.contains(testCaseName)
        if (!enabled) {
            log.info("Test case '{}' is NOT in the filter list for env {} — test will be skipped", testCaseName, env)
        }
        return enabled
    }

    // ── Private helpers ───────────────────────────────────────────────

    private static String determineEnv() {
        if (!LOGGED_PARAMS) {
            log.info("=" * 70)
            log.info("QG7 INTEGRATION TEST — PARAMETERS")
            log.info("  BASE_URL                 = {}", System.getProperty("BASE_URL") ?: "NOT SET")
            log.info("  INTEGRATION_TEST_ENV     = {}", System.getProperty("INTEGRATION_TEST_ENV") ?: "NOT SET")
            log.info("  INTEGRATION_TEST_CLUSTER = {}", System.getProperty("INTEGRATION_TEST_CLUSTER") ?: "NOT SET")
            log.info("  defaultEnv (YAML)        = {}", DEFAULT_ENV)
            log.info("=" * 70)
            LOGGED_PARAMS = true
        }

        String baseUrl = System.getProperty("BASE_URL")?.trim()
        if (baseUrl) {
            String inferred = normalizeEnvName(baseUrl)
            if (inferred) {
                log.info("Env inferred from BASE_URL '{}': {}", baseUrl, inferred)
                return inferred
            }
        }

        String integTestEnv = System.getProperty("INTEGRATION_TEST_ENV")?.trim()
        if (integTestEnv) {
            String inferred = normalizeEnvName(integTestEnv)
            if (inferred) {
                log.info("Env inferred from INTEGRATION_TEST_ENV '{}': {}", integTestEnv, inferred)
                return inferred
            }
            log.info("Env from INTEGRATION_TEST_ENV (raw): {}", integTestEnv)
            return integTestEnv.toUpperCase(Locale.US)
        }

        String cluster = System.getProperty("INTEGRATION_TEST_CLUSTER")?.trim()
        if (cluster) {
            String inferred = normalizeEnvName(cluster)
            if (inferred) {
                log.info("Env inferred from INTEGRATION_TEST_CLUSTER '{}': {}", cluster, inferred)
                return inferred
            }
        }

        log.info("Falling back to defaultEnv from YAML: {}", DEFAULT_ENV)
        return DEFAULT_ENV
    }

    private static String normalizeEnvName(String candidate) {
        if (!candidate) return null
        String trimmed = candidate.trim()
        String upper   = trimmed.toUpperCase(Locale.US)
        if (ENVIRONMENTS.containsKey(upper)) return upper
        String byUrl = ENVIRONMENTS.find { k, v -> v.equalsIgnoreCase(trimmed) }?.key
        if (byUrl) return byUrl
        return ENV_HINT_PATTERNS.find { k, p -> p.matcher(trimmed).find() }?.key
    }
}
