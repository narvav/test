package com.att.idp.idgraphcontactinfoms.db.helper

import com.att.idp.idgraphcontactinfoms.db.helper.ValidatePinInfoBean
import spock.lang.Specification
import spock.lang.Unroll

class ValidatePinInfoBeanTest extends Specification {

    @Unroll
    def "should correctly set and get all fields for #scenarioName"() {
        given: "A ValidatePinInfoBean with all fields set"
        String status = inputStatus
        String failureReason = inputFailureReason
        Date createDate = inputCreateDate
        String channel = inputChannel
        String sessionId = inputSessionId
        String accountType = inputAccountType
        String authenticationMethod = inputAuthenticationMethod
        String accountNumber = inputAccountNumber
        String emailAddress = inputEmailAddress
        String phoneNumber = inputPhoneNumber

        ValidatePinInfoBean bean = new ValidatePinInfoBean()
        bean.setStatus(status)
        bean.setFailureReason(failureReason)
        bean.setCreateDate(createDate)
        bean.setChannel(channel)
        bean.setSessionId(sessionId)
        bean.setAccountType(accountType)
        bean.setAuthenticationMethod(authenticationMethod)
        bean.setAccountNumber(accountNumber)
        bean.setEmailAddress(emailAddress)
        bean.setPhoneNumber(phoneNumber)

        when: "All getters are called"
        String resultStatus = bean.getStatus()
        String resultFailureReason = bean.getFailureReason()
        Date resultCreateDate = bean.getCreateDate()
        String resultChannel = bean.getChannel()
        String resultSessionId = bean.getSessionId()
        String resultAccountType = bean.getAccountType()
        String resultAuthenticationMethod = bean.getAuthenticationMethod()
        String resultAccountNumber = bean.getAccountNumber()
        String resultEmailAddress = bean.getEmailAddress()
        String resultPhoneNumber = bean.getPhoneNumber()
        String resultToString = bean.toString()

        then: "All fields are returned as set and toString contains all values"
        0 * _ // No mock interactions

        and: "All attributes match expected values"
        resultStatus == status
        resultFailureReason == failureReason
        resultCreateDate == createDate
        resultChannel == channel
        resultSessionId == sessionId
        resultAccountType == accountType
        resultAuthenticationMethod == authenticationMethod
        resultAccountNumber == accountNumber
        resultEmailAddress == emailAddress
        resultPhoneNumber == phoneNumber
        resultToString.contains(status)
        resultToString.contains(failureReason)
        resultToString.contains(channel)
        resultToString.contains(sessionId)
        resultToString.contains(accountType)
        resultToString.contains(authenticationMethod)
        resultToString.contains(accountNumber)
        resultToString.contains(emailAddress)
        resultToString.contains(phoneNumber)

        where: "Different bean scenarios"
        scenarioName         | inputStatus | inputFailureReason | inputCreateDate      | inputChannel | inputSessionId | inputAccountType | inputAuthenticationMethod | inputAccountNumber | inputEmailAddress     | inputPhoneNumber
        "all fields set"     | "SUCCESS"   | "NONE"            | new Date(1700000000) | "WEB"        | "SID123"       | "PREPAID"        | "PIN"                    | "ACC123"           | "user@test.com"       | "1234567890"
        "empty fields"       | ""          | ""                | null                 | ""           | ""             | ""               | ""                       | ""                 | ""                    | ""
        "partial fields set" | "FAIL"      | "INVALID"         | new Date(1800000000) | "APP"        | "SID456"       | ""               | "OTP"                    | ""                 | "other@test.com"      | ""
    }
}
