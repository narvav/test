package com.att.idp.idgraphcontactinfoms.helpers

import com.att.idp.idgraph.db.cosmos.entity.IdgOtpContainer
import com.att.idp.idgraph.db.cosmos.entity.SecurityCode
import com.att.idp.idgraph.db.cosmos.helper.IdgOtpDBHelper
import com.att.idp.idgraph.db.cosmos.helper.OtpHistoryDBHelper
import java.util.concurrent.Executor
import com.att.idp.idgraphcontactinfoms.kafka.GenericOTPPublisher
import com.att.idp.idgraphcontactinfoms.kafka.model.GenericOTPNotification
import com.att.idp.idgraphcontactinfoms.service.async.OracleSecurityCodeSyncPublisher
import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.att.idp.idgraphcontactinfoms.db.helper.SecurityCodeDBHelper
import com.att.idp.idgraphcontactinfoms.helpers.voltage.ProofingEncryptionHelper
import com.att.idp.idgraphcontactinfoms.helpers.voltage.VoltageEncryptionHelper
import com.att.idp.idgraphcontactinfoms.integration.MuleSoftRestClient
import com.att.idp.idgraphcontactinfoms.queue.message.sender.JMSQueueSender
import com.att.mpsys.common.utils.*
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import com.att.idp.idgraphcontactinfoms.service.async.AsyncOtpEventPublisher
import java.time.Instant
import java.time.LocalDateTime;
import spock.lang.Unroll


class GeneratePINBaseTest extends Specification {

    def GeneratePINBase generatePINBaseO

    SecurityCodeDBHelper securityCodeDBHelper = Mock(SecurityCodeDBHelper)

    ProofingEncryptionHelper proofingEncryptionHelper = Mock(ProofingEncryptionHelper)

    VoltageEncryptionHelper voltageEncryptionHelper = Mock(VoltageEncryptionHelper)

    JMSQueueSender oJMSQueueSender = Mock(JMSQueueSender)

    FeatureManagerHelper featureManager = Mock(FeatureManagerHelper)

    MuleSoftRestClient muleSoftRestClient = Mock(MuleSoftRestClient)

    IdgOtpDBHelper idgOtpDBHelper = Mock(IdgOtpDBHelper)

    ValidatePINHelper validatePINHelper = Mock(ValidatePINHelper)

    OracleSecurityCodeSyncPublisher oracleSecurityCodeSyncPublisher = Mock(OracleSecurityCodeSyncPublisher)
    AsyncOtpEventPublisher otpEventPublisher = Mock(AsyncOtpEventPublisher)
    OtpHistoryDBHelper otpHistoryDBHelper = Mock(OtpHistoryDBHelper)
    Executor otpHistoryExecutor = { Runnable r -> r.run() } as Executor

    private HashMap<String, Object> hmInput = null
    private HashMap<String, Object> hmdeliveryMethods = null
    private HashMap<String, Object> hmSms = null
    private HashMap<String, Object> hmEmail = null
    private HashMap<String, Object> hmLetter = null
    private HashMap<String, Object> hmAo = null
    private Map<String, Object> hmResult = null
    private HashMap<String, Object> resultHashSuccess = null
    private HashMap<String, Object> resultHash = null
    private HashMap<String, Object> errorResultHash = null

    private ArrayList alDbusInput = null
    private ArrayList alAttributes = null

    private String stAppInfo = null


    def setup() {
        generatePINBaseO = new GeneratePINBase(otpHistoryDBHelper, otpHistoryExecutor)
        generatePINBaseO.securityCodeDBHelper = securityCodeDBHelper
        generatePINBaseO.proofingEncryptionHelper = proofingEncryptionHelper
        generatePINBaseO.voltageEncryptionHelper = voltageEncryptionHelper
        generatePINBaseO.oJMSQueueSender = oJMSQueueSender
        generatePINBaseO.featureManager = featureManager
        generatePINBaseO.muleSoftRestClient = muleSoftRestClient
        generatePINBaseO.idgOtpDBHelper = idgOtpDBHelper
        generatePINBaseO.validatePINHelper = validatePINHelper
        oracleSecurityCodeSyncPublisher = Mock(OracleSecurityCodeSyncPublisher)
        ReflectionTestUtils.setField(generatePINBaseO, 'otpEventPublisher', otpEventPublisher)

        resultHashSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
                CErrorDefs.COMMON_SUCCESS_MSG)

        hmInput = CommonUtil.hashMap
        hmdeliveryMethods = CommonUtil.hashMap
        hmSms = CommonUtil.hashMap
        hmEmail = CommonUtil.hashMap
        hmLetter = CommonUtil.hashMap
        hmAo = CommonUtil.hashMap
        alDbusInput = CommonUtil.arrayList
        alAttributes = CommonUtil.arrayList

        hmInput[CommonDefs.TRANSACTION_ID] = 'trma_5467253'
        hmInput[CommonDefs.TRANSACTION_NAME] = 'GeneratePIN'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.ACCOUNT_ID] = '5214001254'
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'IDSEMOB'
        hmInput[CommonDefs.AGENT_ID] = '1234'
        hmInput[CommonDefs.BROWSER_LANGUAGE] = 'EN'
        hmInput[CommonDefs.RETURN_SECURITY_CODE] = 'Y'
        hmInput[CommonDefs.SECURITY_PIN_EXPIRATION_HOURS] = '24'
        hmInput[CommonDefs.SOURCE] = 'ONL'
        hmInput[CommonDefs.DELIVERY_METHOD] = 's'
        hmInput[CommonDefs.ENCRYPTED_SECURITY_CODE] = '!@#$'
        hmInput[CommonDefs.DELIVERY_DETAIL] = '1122331133'
        hmInput[CommonDefs.SECURITY_CODE] = '111111'
        hmInput[CommonDefs.SECURITY_PIN_EXPIRATION_DATE] = '11112018'
        hmInput[CommonDefs.DELIVERY_METHODS] = hmdeliveryMethods

        hmSms['smsPhoneNumber'] = '1112223333'
        hmSms['deviceType'] = 'ANDROID'

        hmEmail['emailAddress'] = 'asc@att.com'

        hmLetter['name'] = 'KIANA N BELTRAN'
        hmLetter['street1'] = '530 E SKYLANE ST'
        hmLetter['city'] = 'WHITE PLAINS'
        hmLetter['state'] = 'NY'
        hmLetter['zipCode'] = '6666'
        hmLetter['street2'] = 'Apt 204'
        hmLetter['street3'] = 'STE 101-K'
        hmLetter['zipPlusFour'] = '4567'
        hmLetter['country'] = 'US'

        hmAo['phoneNumber'] = '9637260432'

        ReflectionTestUtils.setField(generatePINBaseO, 'propPINLength',
                'IDSEMOB:6|BANPCS:6|BANPCE:6|BANPTONLS:6|BANPTONLE:6|DTVNOWOTP:6|CTNKSK:6|BTN:8|PINVALID:6|NONATTCTN:6|ATTCTN:6|EMAILOTP:6|CRICKETOTP:6|EMAILPIN:6|CTNDIH:4|BANAP:6|TITANIMD:8|CTN:8|WBAN:8|ECOMMSEC:8|WBANSEC:8|TITANSEC:8|DTVOTP:6|CTNAUTH:6|CTNOPR:4|ENCPIN:6|PORTOUT:6|CCPADTV:6|BSSEOTP:6|BSSEONL:6|BSSEREGOTP:6')
        ReflectionTestUtils.setField(generatePINBaseO, 'propPINExpirationMinutes',
                'IDSEMOB:1440|BANPCS:120|BANPCE:120|BANPTONLS:120|BANPTONLE:120|DTVNOWOTP:60|CTNKSK:120|BTN:43200|PINVALID:120|NONATTCTN:60|ATTCTN:60|EMAILOTP:60|CRICKETOTP:60|EMAILPIN:60|CTNDIH:60|BANAP:1440|TITANIMD:43200|CTN:43200|WBAN:43200|ECOMMSEC:43200|WBANSEC:43200|TITANSEC:43200|DTVOTP:60|CTNAUTH:60|CTNOPR:1440|ENCPIN:43200|PORTOUT:5760|CCPADTV:60|BSSEOTP:60|BSSEONL:60|BSSEREGOTP:60|AUTHUSER:120|NTRETAILER:60|ESIMOTP:60|GENERICOTP:60|PORTOUTABS:20160|PORTOUTBSS:4320|BANPC:1440|REGIMPROVE:60|APPTSCHED:1440|BANCRU:1440|BANPT:1440|BANPTONL:1440|CALLFWD:60|PORTOUTPP:5760|SMBYIELD:60')
        ReflectionTestUtils.setField(generatePINBaseO, 'propStubCCMULECall', 'N')
        ReflectionTestUtils.setField(generatePINBaseO, 'sPropPinDeliveryMethods',
                'IDSEMOB:sms|email,BANPCS:sms,BANPCE:email,BANPTONLS:sms,BANPTONLE:email,DTVNOWOTP:sms|email,CTNKSK:sms,BTN:sms|email|letter|ao,PINVALID:sms|email,NONATTCTN:sms,ATTCTN:sms,EMAILOTP:email,CRICKETOTP:email,EMAILPIN:email,CTNDIH:sms,BANAP:sms|email,TITANIMD:sms|email|letter|ao,CTN:sms|email|letter|ao,WBAN:sms|email|letter|ao,ECOMMSEC:sms|email|letter|ao,WBANSEC:sms|email|letter|ao,TITANSEC:sms|email|letter|ao,DTVOTP:email,CTNAUTH:sms,CTNOPR:sms,ENCPIN:sms|email,CCPADTV:email,BSSEOTP:sms|email,BSSEONL:sms|email,BSSEREGOTP:sms|email')
        ReflectionTestUtils.setField(generatePINBaseO, 'sPropPinMaxPins',
                'IDSEMOB:10|BANPCS:10|BANPCE:10|BANPTONLS:10|BANPTONLE:10|DTVNOWOTP:5|CTNKSK:10|BTN:10|PINVALID:10|NONATTCTN:10|ATTCTN:10|EMAILOTP:10|CRICKETOTP:10|EMAILPIN:10|CTNDIH:5|BANAP:10|TITANIMD:10|CTN:10|WBAN:10|ECOMMSEC:10|WBANSEC:10|TITANSEC:10|DTVOTP:10|CTNAUTH:10|CTNOPR:5|ENCPIN:10|PORTOUT:5|CCPADTV:10|BSSEOTP:10|BSSEONL:10|BSSEREGOTP:10')
        ReflectionTestUtils.setField(generatePINBaseO, 'propPinExcludeTimeOverwiteIDType',
                'PORTOUTBSS|ECOMMSEC|WBANSEC|TITANSEC|PORTOUT|PORTOUTABS')
        ReflectionTestUtils.setField(generatePINBaseO, 'propSubCategory',
                'BSSEOTP:TEMP_PIN|BSSEONL:TEMP_PIN|BSSEREGOTP:TEMP_PIN|ESIMOTP:TEMP_PIN|GENERICOTP:TEMP_PIN|PORTOUTABS:TEMP_PIN|PORTOUTBSS:BSSE_TEMP_PIN|CALLFWD:TEMP_PIN|REGIMPROVE:TEMP_PIN|BANPC:TEMP_PIN|BANPTONL:TEMP_PIN|NTRETAILER:TEMP_PIN')
        ReflectionTestUtils.setField(generatePINBaseO, 'propHighPriorityIdentificationTypes',
                'PROP_CLM_HIGH_PRIORITY_IDENTIFICATIONTYPES:ESIMOTP|GENERICOTP|NTRETAILER|BANPC|BANPTONL|REGIMPROVE|PORTOUTPP|SMBYIELD|PORTOUTBSS|BSSEGEN|BSSEOTP|BSSEONL|BSSEREGOTP')
        ReflectionTestUtils.setField(generatePINBaseO, 'propIdentificationTypeToServiceTypeMapping',
                'PROP_IDENTIFICATIONTYPES_CLM_SERVICETYPE_MAPPING=ECOMMSEC:wireline|WBANSEC:wireless|TITANSEC:uverse|ESIMOTP:wireless')

    }


    def "process input data error test"() {
        given:
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'ENCPIN'
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.processInputData()
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SYSTEM ERROR'
    }


    def "validate security code data error case1"() {
        given:
        HashMap<String, Object> hmGetDBResult = CommonUtil.hashMap
        hmGetDBResult[CommonDefs.COMMON_APP_STATUS_CODE] = '118'
        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> 'ORACLEMASTER'
        securityCodeDBHelper.getSecurityCodeDataQuery(_) >> hmGetDBResult
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.validateSecurityCodeData()
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_USERNAME_EXISTS'
    }


    def "validate security code data error case2"() {
        given:
        HashMap<String, Object> hmGetDBResult = CommonUtil.hashMap
        hmGetDBResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
        hmGetDBResult[MPSDefs.SECURITY_CODE_COUNT] = '10'
        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> 'ORACLEMASTER'
        securityCodeDBHelper.getSecurityCodeDataQuery(_) >> hmGetDBResult
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.validateSecurityCodeData()
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Security Codes cannot be more than 10'
    }

    def "validate security code data error case3"() {
        given:
        HashMap<String, Object> hmGetDBResult = CommonUtil.hashMap
        hmGetDBResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
        hmGetDBResult[MPSDefs.SECURITY_CODE_COUNT] = '10'
        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> "COSMOSMASTER"
        idgOtpDBHelper.getSecurityCodeDataQuery(_) >> hmGetDBResult
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.validateSecurityCodeData()
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Security Codes cannot be more than 10'
    }

    def "validate security code data error case4"() {
        given:
        HashMap<String, Object> hmGetDBResult = CommonUtil.hashMap
        hmGetDBResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
        hmGetDBResult[MPSDefs.SECURITY_CODE_COUNT] = '10'
        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> "ONLYCOSMOS"
        idgOtpDBHelper.getSecurityCodeDataQuery(_) >> hmGetDBResult
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.validateSecurityCodeData()
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Security Codes cannot be more than 10'
    }

    def "validate security code data error case5"() {
        given:
        HashMap<String, Object> hmGetDBResult = CommonUtil.hashMap
        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> "ORACLEMASTER"
        hmGetDBResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
        hmGetDBResult.remove(MPSDefs.SECURITY_CODE_COUNT)
        hmGetDBResult[CommonDefs.COMMON_APP_STATUS_CODE] = null
        securityCodeDBHelper.getSecurityCodeDataQuery(_) >> hmGetDBResult
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.validateSecurityCodeData()
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Input Validation Successful'
    }

    def "validate security code data error case6"() {
        given:
        HashMap<String, Object> hmGetDBResult = CommonUtil.hashMap
        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> "ORACLEMASTER"
        hmGetDBResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
        hmGetDBResult[MPSDefs.SECURITY_CODE_COUNT] = '10'
        hmGetDBResult[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.ERR_REC_NOT_FOUND
        securityCodeDBHelper.getSecurityCodeDataQuery(_) >> hmGetDBResult
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.validateSecurityCodeData()
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Security Codes cannot be more than 10'
    }


    def "validate security code data error success"() {
        given:
        HashMap<String, Object> hmGetDBResult = CommonUtil.hashMap
        hmGetDBResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
        hmGetDBResult[MPSDefs.SECURITY_CODE_COUNT] = '9'
        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> 'ORACLEMASTER'
        securityCodeDBHelper.getSecurityCodeDataQuery(_) >> hmGetDBResult
        featureManager.isEnabled(_) >> true
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.validateSecurityCodeData()
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Input Validation Successful'
    }


    def "generate pin delivery method error"() throws Exception {
        given:
        HashMap<String, Object> hmEncResult = CommonUtil.hashMap
        hmEncResult['voltage_CBR'] = '11$%^4#@8%5d43$ec'
        hmEncResult[MPSDefs.APP_STATUS_CODE] = '0'
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'ENCPIN'
        hmdeliveryMethods['letter'] = hmLetter
        hmLetter['foreignAddrInd'] = 'YES'
        generatePINBaseO.initialize(hmInput)

        voltageEncryptionHelper.getEFPEEncryptedValues(_) >> hmEncResult
        when:
        hmResult = generatePINBaseO.processInputData()

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'ForeignAddInd can have Values one of Y/N'
    }


    def "generate pin delivery method sms success"() throws Exception {
        given:
        featureManager.isEnabled(_ as String) >> false
        hmdeliveryMethods['sms'] = hmSms
        generatePINBaseO.initialize(hmInput)

        when:
        hmResult = generatePINBaseO.processInputData()
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Input Data processed Successfully'
    }


    def "generate pin delivery method email success"() throws Exception {
        given:
        featureManager.isEnabled(_ as String) >> false
        hmdeliveryMethods['email'] = hmEmail
        hmdeliveryMethods['ao'] = hmAo
        generatePINBaseO.initialize(hmInput)

        when:
        hmResult = generatePINBaseO.processInputData()
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Input Data processed Successfully'
    }


    def "generate pin delivery method letter success"() throws Exception {
        given:
        featureManager.isEnabled(_ as String) >> false
        hmdeliveryMethods['letter'] = hmLetter
        generatePINBaseO.initialize(hmInput)

        when:
        hmResult = generatePINBaseO.processInputData()
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Input Data processed Successfully'
    }


    def "process input data exception"() {
        given:
        generatePINBaseO.initialize(null)

        when:
        hmResult = generatePINBaseO.processInputData()
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "generate pin security account error"() throws Exception {
        given:
        stAppInfo = 'System ERROR returned from DB helper'
        resultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo)

        securityCodeDBHelper.getSecurityAccountData(_) >> resultHash
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.storeMPSData()

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'System ERROR returned from DB helper'
    }


    def "generate pin record not found error"() throws Exception {
        given:
        stAppInfo = 'Record not found'
        resultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo)
        stAppInfo = 'System ERROR returned from DB helper'
        errorResultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo)

        securityCodeDBHelper.getSecurityAccountData(_) >> resultHash
        securityCodeDBHelper.setSecurityAccountData(_) >> errorResultHash
        generatePINBaseO.initialize(hmInput)
        featureManager.getValue(_ as String) >> "ORACLEMASTER"
        when:
        hmResult = generatePINBaseO.storeMPSData()

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'System ERROR returned from DB helper'
    }

    def "generate pin record not found error 2"() throws Exception {
        given:
        stAppInfo = 'Record not found'
        resultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo)
        stAppInfo = 'System ERROR returned from DB helper'
        errorResultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo)
        idgOtpDBHelper.getSecurityAccountData(_) >> resultHash
        securityCodeDBHelper.setSecurityAccountData(_) >> errorResultHash
        hmInput["security_code_expiration_time"] = 10
        generatePINBaseO.initialize(hmInput)
        featureManager.getValue(_ as String) >> "ONLYCOSMOS"
        when:
        hmResult = generatePINBaseO.storeMPSData()

        then:
        hmResult["appStatusMsg"] == 'ERR_SYS_APPL'
    }

    def "generate pin update record error"() throws Exception {
        given:
        String stAppInfo = 'System ERROR returned from DB helper'
        errorResultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo)

        // doReturn(errorResultHash).when(securityCodeDBHelper).updateSecurityAccount(Mockito.any(HashMap.class),
        //        Mockito.anyBoolean())
        securityCodeDBHelper.getSecurityAccountData(_) >> resultHashSuccess
        securityCodeDBHelper.updateSecurityAccount(_, _) >> errorResultHash

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.storeMPSData()

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'System ERROR returned from DB helper'
    }


    def "generate pin set security code error"() throws Exception {
        given:
        String stAppInfo = 'System ERROR returned from DB helper'
        errorResultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo)

        securityCodeDBHelper.getSecurityAccountData(_) >> resultHashSuccess
        securityCodeDBHelper.updateSecurityAccount(_, _) >> errorResultHash
        //securityCodeDBHelper.getSecurityCodeDataQuery(_)>> errorResultHash
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.storeMPSData()

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'System ERROR returned from DB helper'
    }


    def "generate pin security account d b error"() throws Exception {
        given:
        stAppInfo = 'DB ERROR returned from DB helper'
        resultHash = CommonErrorMap.makeCategoryMap(Integer.parseInt(CErrorDefs.ERR_DB), stAppInfo)

        securityCodeDBHelper.getSecurityAccountData(_) >> resultHash
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.storeMPSData()

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'DB ERROR returned from DB helper'
    }


    def "generate pin record not found d b error"() throws Exception {
        given:
        stAppInfo = 'Record not found'
        resultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo)
        stAppInfo = 'DB ERROR returned from DB helper'
        errorResultHash = CommonErrorMap.makeCategoryMap(Integer.parseInt(CErrorDefs.ERR_DB), stAppInfo)

        securityCodeDBHelper.getSecurityAccountData(_) >> resultHash
        securityCodeDBHelper.setSecurityAccountData(_) >> errorResultHash
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.storeMPSData()

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'DB ERROR returned from DB helper'
    }


    def "generate pin update record d b error"() throws Exception {
        given:
        String stAppInfo = 'DB ERROR returned from DB helper'
        errorResultHash = CommonErrorMap.makeCategoryMap(Integer.parseInt(CErrorDefs.ERR_DB), stAppInfo)

        securityCodeDBHelper.getSecurityAccountData(_) >> resultHashSuccess
        //securityCodeDBHelper.getSecurityAccountData(_)>>resultHash
        securityCodeDBHelper.updateSecurityAccount(_, _) >> errorResultHash
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.storeMPSData()

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'DB ERROR returned from DB helper'
    }


    def "generate pin set security code d b error"() throws Exception {
        given:
        String stAppInfo = 'DB ERROR returned from DB helper'
        errorResultHash = CommonErrorMap.makeCategoryMap(Integer.parseInt(CErrorDefs.ERR_DB), stAppInfo)

        // securityCodeDBHelper.getSecurityAccountData(_)>>resultHashSuccess
        securityCodeDBHelper.updateSecurityAccount(_, _) >> resultHashSuccess
        securityCodeDBHelper.getSecurityAccountData(_) >> errorResultHash
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.storeMPSData()

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'DB ERROR returned from DB helper'
    }


    def "generate pin store m p s data success"() throws Exception {
        given:
        securityCodeDBHelper.getSecurityAccountData(_) >> resultHashSuccess
        securityCodeDBHelper.updateSecurityAccount(_, _) >> resultHashSuccess
        securityCodeDBHelper.getSecurityCodeDataQuery(_) >> resultHashSuccess
        securityCodeDBHelper.setSecurityCode(_) >> resultHashSuccess

        // Mocking the return value of idgOtpDBHelper.findByIdentificationTypeAndAccountId
        IdgOtpContainer mockContainer = new IdgOtpContainer()
        mockContainer.setIdentificationType("IDENTIFICATION_TYPE")
        mockContainer.setAccountId("ACCOUNT_ID")
        mockContainer.setSecurityCodes(new ArrayList<>())
        idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.of(mockContainer)

        idgOtpDBHelper.createOrUpdateEntity(_) >> mockContainer
        hmInput["security_code_expiration_time"] = "10"

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.storeMPSData()

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "generate pin store m p s data success2"() throws Exception {
        given:
        securityCodeDBHelper.getSecurityAccountData(_) >> resultHashSuccess
        securityCodeDBHelper.updateSecurityAccount(_, _) >> resultHashSuccess
        securityCodeDBHelper.getSecurityCodeDataQuery(_) >> resultHashSuccess

        hmResult = CommonUtil.hashMap
        hmResult.put(CommonDefs.COMMON_APP_STATUS_CODE, '1')

        securityCodeDBHelper.setSecurityCode(_) >> hmResult

        // Mocking the return value of idgOtpDBHelper.findByIdentificationTypeAndAccountId
        IdgOtpContainer mockContainer = new IdgOtpContainer()
        mockContainer.setIdentificationType("IDENTIFICATION_TYPE")
        mockContainer.setAccountId("ACCOUNT_ID")
        mockContainer.setSecurityCodes(new ArrayList<>())
        idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.of(mockContainer)

        idgOtpDBHelper.createOrUpdateEntity(_) >> mockContainer
        hmInput["security_code_expiration_time"] = "10"

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.storeMPSData()

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_UNKNOWN'
    }


    def "generate pin store m p s data exception"() throws Exception {
        given:
        featureManager.isEnabled(_ as String) >> true
        generatePINBaseO.initialize(null)
        when:
        hmResult = generatePINBaseO.storeMPSData()

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "generate pin prepare data for mulesoft success"() throws Exception {
        given:
        hmdeliveryMethods['email'] = hmEmail
        hmdeliveryMethods['sms'] = hmSms
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'BSSEOTP'

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.prepareDataForCCMuleSyncCall()

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "generate pin prepare data for mulesoft success1"() throws Exception {
        given:
        hmdeliveryMethods['email'] = hmEmail
        hmdeliveryMethods['sms'] = hmSms
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'ESIMOTP'

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.prepareDataForCCMuleSyncCall()

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "generate pin prepare data for mulesoft null delivery method"() throws Exception {
        given:
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'BSSEOTP'
        hmInput[CommonDefs.DELIVERY_METHODS] = null

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.prepareDataForCCMuleSyncCall()

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Please provide a delivery method'
    }


    def "generate pin prepare data for mulesoft empty delivery method"() throws Exception {
        given:
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'BSSEOTP'

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.prepareDataForCCMuleSyncCall()

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Delivery method is empty'
    }


    def "generate pin prepare data for mulesoft exception"() throws Exception {
        given:
        generatePINBaseO.initialize(null)
        when:
        hmResult = generatePINBaseO.prepareDataForCCMuleSyncCall()

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "generate pin make c c mule sync call success"() throws Exception {
        given:
        ReflectionTestUtils.setField(generatePINBaseO, 'propStubCCMULECall', 'Y')

        muleSoftRestClient.postCCMuleSyncCall(_, _, _) >> resultHashSuccess
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.makeCCMuleSyncCall(alDbusInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "generate pin make c c mule sync call null response"() throws Exception {
        given:
        muleSoftRestClient.postCCMuleSyncCall(_, _, _) >> null

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.makeCCMuleSyncCall(alDbusInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Null Response returned by muleSoftRestClient.postCCMuleSyncCall'
    }


    def "generate pin make c c mule sync call error"() throws Exception {
        given:
        stAppInfo = 'Error returned by muleSoftRestClient'
        errorResultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo)

        muleSoftRestClient.postCCMuleSyncCall(_, _, _) >> errorResultHash
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.makeCCMuleSyncCall(alDbusInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Error returned by muleSoftRestClient'
    }


    def "generate pin make c c mule sync call property error"() throws Exception {
        given:
        ReflectionTestUtils.setField(generatePINBaseO, 'propStubCCMULECall', null)

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.makeCCMuleSyncCall(alDbusInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'PROP_CALL_CCMULE_STUB Config is null or empty'
    }


    def "generate pin make c c mule sync call exception"() throws Exception {
        given:
        generatePINBaseO.initialize(null)

        when:
        hmResult = generatePINBaseO.makeCCMuleSyncCall(alDbusInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "generate pin prepare data for ao success"() throws Exception {
        given:
        alAttributes.add('employeeFlag')
        hmdeliveryMethods[CommonDefs.AO] = hmAo
        hmInput[CommonDefs.ATTRIBUTE_LIST] = alAttributes
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'ENCPIN'
        hmInput[CommonDefs.RES_BUS_IND] = 'R'

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.prepareDataForAsyncCall()
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "generate pin prepare data for sms success"() throws Exception {
        given:
        hmdeliveryMethods['sms'] = hmSms

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.prepareDataForAsyncCall()
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "generate pin prepare data for email success"() throws Exception {
        given:
        hmdeliveryMethods['email'] = hmEmail

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.prepareDataForAsyncCall()
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "generate pin prepare data for letter success"() throws Exception {
        given:
        hmdeliveryMethods['letter'] = hmLetter

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.prepareDataForAsyncCall()
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "generate pin prepare data exception case"() throws Exception {
        given:
        hmInput[CommonDefs.BROWSER_LANGUAGE] = 21

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.prepareDataForAsyncCall()
        then:
        //hmResult[CommonDefs.COMMON_APP_INFO] == 'SYSTEM ERROR'
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "generate pin make async call success"() throws Exception {
        given:
        hmInput[CommonDefs.CALLDBUS] = 'N'

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.makeAsyncCall(alDbusInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "generate pin make async call exception"() throws Exception {
        given:
        hmInput[CommonDefs.ACCOUNT_ID] = 1565512

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.makeAsyncCall(alDbusInput)
        then:
        //hmResult[CommonDefs.COMMON_APP_INFO] == 'SYSTEM ERROR'
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "generate pin make async call null response"() throws Exception {
        given:
        hmdeliveryMethods['sms'] = hmSms
        oJMSQueueSender.send(_) >> null
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.makeAsyncCall(alDbusInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Null Response returned from JMSQueueSender.send'
    }


    def "generate pin make async call error"() throws Exception {
        given:
        hmdeliveryMethods['sms'] = hmSms
        stAppInfo = 'Some ERROR returned from JMSQSender'
        errorResultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo)

        oJMSQueueSender.send(_) >> errorResultHash
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.makeAsyncCall(alDbusInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Some ERROR returned from JMSQSender'
    }


    def "generate pin make async call execption"() throws Exception {
        given:
        hmInput[CommonDefs.ACCOUNT_ID] = 1565512

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.makeAsyncCall(alDbusInput)
        then:
        //hmResult[CommonDefs.COMMON_APP_INFO] == 'SYSTEM ERROR'
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "generate pin make async call no delivery method success"() throws Exception {
        given:
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.makeAsyncCall(alDbusInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "generate pin async call success"() throws Exception {
        given:
        hmdeliveryMethods['sms'] = hmSms

        oJMSQueueSender.send(_) >> resultHashSuccess
        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.makeAsyncCall(alDbusInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    @Unroll
    def "should store Cosmos DB security code and publish event for #scenarioName"() {
        given: "Mocks and input for Cosmos DB security code storage and event publishing"
        GeneratePINBase generatePINBaseSpy = Spy(new GeneratePINBase(otpHistoryDBHelper, otpHistoryExecutor))
        ReflectionTestUtils.setField(generatePINBaseSpy, 'securityCodeDBHelper', securityCodeDBHelper)
        ReflectionTestUtils.setField(generatePINBaseSpy, 'proofingEncryptionHelper', proofingEncryptionHelper)
        ReflectionTestUtils.setField(generatePINBaseSpy, 'voltageEncryptionHelper', voltageEncryptionHelper)
        ReflectionTestUtils.setField(generatePINBaseSpy, 'oJMSQueueSender', oJMSQueueSender)
        ReflectionTestUtils.setField(generatePINBaseSpy, 'featureManager', featureManager)
        ReflectionTestUtils.setField(generatePINBaseSpy, 'muleSoftRestClient', muleSoftRestClient)
        ReflectionTestUtils.setField(generatePINBaseSpy, 'idgOtpDBHelper', idgOtpDBHelper)
        ReflectionTestUtils.setField(generatePINBaseSpy, 'otpEventPublisher', otpEventPublisher)
                // Set all ReflectionTestUtils fields as in setup()
        ReflectionTestUtils.setField(generatePINBaseSpy, 'propPINLength', ReflectionTestUtils.getField(generatePINBaseO, 'propPINLength'))
        ReflectionTestUtils.setField(generatePINBaseSpy, 'propPINExpirationMinutes', ReflectionTestUtils.getField(generatePINBaseO, 'propPINExpirationMinutes'))
        ReflectionTestUtils.setField(generatePINBaseSpy, 'propStubCCMULECall', ReflectionTestUtils.getField(generatePINBaseO, 'propStubCCMULECall'))
        ReflectionTestUtils.setField(generatePINBaseSpy, 'sPropPinDeliveryMethods', ReflectionTestUtils.getField(generatePINBaseO, 'sPropPinDeliveryMethods'))
        ReflectionTestUtils.setField(generatePINBaseSpy, 'sPropPinMaxPins', ReflectionTestUtils.getField(generatePINBaseO, 'sPropPinMaxPins'))
        ReflectionTestUtils.setField(generatePINBaseSpy, 'propPinExcludeTimeOverwiteIDType', ReflectionTestUtils.getField(generatePINBaseO, 'propPinExcludeTimeOverwiteIDType'))
        ReflectionTestUtils.setField(generatePINBaseSpy, 'propSubCategory', ReflectionTestUtils.getField(generatePINBaseO, 'propSubCategory'))
        ReflectionTestUtils.setField(generatePINBaseSpy, 'propHighPriorityIdentificationTypes', ReflectionTestUtils.getField(generatePINBaseO, 'propHighPriorityIdentificationTypes'))
        ReflectionTestUtils.setField(generatePINBaseSpy, 'propIdentificationTypeToServiceTypeMapping', ReflectionTestUtils.getField(generatePINBaseO, 'propIdentificationTypeToServiceTypeMapping'))

        String sInpIdentificationType = identificationType
        String sInpAccountId = accountId
        String sInpCallingSystemId = callingSystemId
        String sSecurityCodeExpirationTime = expirationTime
        String sSource = source
        String sDeliveryMethod = deliveryMethod
        String sSHA256EncryptedSecurityCode = sha256Code
        String sDeliveryDetail = deliveryDetail
        HashMap<String, Object> hmInputLocal = CommonUtil.hashMap
        hmInputLocal[CommonDefs.IDENTIFICATION_TYPE] = sInpIdentificationType
        hmInputLocal[CommonDefs.ACCOUNT_ID] = sInpAccountId
        hmInputLocal[CommonDefs.CALLING_SYSTEM_ID] = sInpCallingSystemId
        hmInputLocal["security_code_expiration_time"] = sSecurityCodeExpirationTime
        hmInputLocal[CommonDefs.SOURCE] = sSource
        hmInputLocal[CommonDefs.DELIVERY_METHOD] = sDeliveryMethod
        hmInputLocal["encryptedSHA256SecurityCode"] = sSHA256EncryptedSecurityCode
        hmInputLocal[CommonDefs.DELIVERY_DETAIL] = sDeliveryDetail
        generatePINBaseSpy.hmInput = hmInputLocal

        IdgOtpContainer queryContainer = new IdgOtpContainer()
        queryContainer.setIdentificationType(sInpIdentificationType)
        queryContainer.setAccountId(sInpAccountId)

        Optional<IdgOtpContainer> existingContainerOpt = existingList.isEmpty() ? Optional.empty() : Optional.of(existingList.get(0))
        IdgOtpContainer idgOtpContainer = existingContainerOpt.isEmpty() ? new IdgOtpContainer() : existingContainerOpt.get()
        idgOtpContainer.setIdentificationType(sInpIdentificationType)
        idgOtpContainer.setAccountId(sInpAccountId)
        idgOtpContainer.setCumulativeFailureCount(0)
        idgOtpContainer.setUpdatedBy(sInpCallingSystemId)
        idgOtpContainer.setAccountEntryExpires(expiryDate)
        idgOtpContainer.setSecurityCodes(new ArrayList<>())

        SecurityCode securityCode = new SecurityCode()
        securityCode.setSecurityCode(sSHA256EncryptedSecurityCode)
        securityCode.setVerificationFailureCount(0)
        securityCode.setSecurityCodeExpires(expiryDate)
        securityCode.setSecurityCodeStatus("ACTIVE")
        securityCode.setSource(sSource)
        securityCode.setDeliveryMethod(sDeliveryMethod)
        securityCode.setDeliveryDetail(sDeliveryDetail)
        securityCode.setCreatedDate(createdDate)
        securityCode.setUpdatedDate(createdDate)
        securityCode.setUpdatedBy(sInpCallingSystemId)
        idgOtpContainer.getSecurityCodes().add(securityCode)

        IdgOtpContainer savedContainer = new IdgOtpContainer()
        savedContainer.setId(savedId)
        savedContainer.setSecurityCodes(idgOtpContainer.getSecurityCodes())

        // Mock for OTP data source
        1 * featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> "COSMOSMASTER"
        // Mock for Cosmos DB find
        1 * idgOtpDBHelper.findByIdentificationTypeAndAccountId({ IdgOtpContainer qc ->
            qc.getIdentificationType() == sInpIdentificationType && qc.getAccountId() == sInpAccountId
        }) >> existingContainerOpt
        // Mock for Cosmos DB create/update
        1 * idgOtpDBHelper.createOrUpdateEntity({ IdgOtpContainer c ->
            c.getIdentificationType() == sInpIdentificationType && c.getAccountId() == sInpAccountId
        }) >> savedContainer
        // Mock for publish feature flag
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> publishEnabled
        // Mock for Cosmos DB getSecurityAccountData
        1 * securityCodeDBHelper.getSecurityAccountData({ Map m ->
            m != null &&
                m.get('account_id') == sInpAccountId &&
                m.get('identification_type') == sInpIdentificationType
        }) >> CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "SUCCESS")
        // Mock for Oracle updateSecurityAccount
        1 * securityCodeDBHelper.updateSecurityAccount({ Map m ->
            m != null &&
                m.get('account_id') == sInpAccountId &&
                m.get('identification_type') == sInpIdentificationType &&
                m.get('last_modified_by') == sInpCallingSystemId &&
                m.get('security_code_expiration_time') == sSecurityCodeExpirationTime
        }, true) >> CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "SUCCESS")
        // Mock for Oracle setSecurityCode (should be called once in Cosmos path as well)
        1 * securityCodeDBHelper.setSecurityCode({ Map m ->
            m != null &&
                m.get('account_id') == sInpAccountId &&
                m.get('identification_type') == sInpIdentificationType &&
                m.get('last_modified_by') == sInpCallingSystemId &&
                m.get('security_code_expiration_time') == sSecurityCodeExpirationTime &&
                m.get('delivery_method') == sDeliveryMethod &&
                m.get('delivery_detail') == sDeliveryDetail &&
                m.get('source') == sSource
        }) >> CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "SUCCESS")
        // event publishing is delegated to AsyncOtpEventPublisher

        when: "storeMPSData is called for Cosmos DB path"
        Map<String, Object> result = generatePINBaseSpy.storeMPSData()

        then: "Result is success and event published if enabled"
        result != null
        result[CommonDefs.COMMON_APP_INFO] == "SUCCESS"
        if (publishEnabled) {
            1 * otpEventPublisher.publishGeneratePinEvent(sInpAccountId, _, _)
        }

		where:
		scenarioName         | identificationType | accountId  | callingSystemId | expirationTime | source | deliveryMethod | sha256Code      | deliveryDetail | existingList                  | expiryDate                   | createdDate                           | savedId   | publishEnabled
		"insert no publish"  | "IDSEMOB"          | "acct-1"   | "CALLING_SYS"   | "10"           | "ONL"  | "S"           | "SHA256_CODE"  | "1112223333"  | []                            | "2026-01-01T00:00:00Z"      | LocalDateTime.of(2026, 1, 1, 0, 0)   | "id-1"   | false
		"update publish"     | "IDSEMOB"          | "acct-1"   | "CALLING_SYS"   | "10"           | "ONL"  | "S"           | "SHA256_CODE"  | "1112223333"  | [new IdgOtpContainer(identificationType: "IDSEMOB", accountId: "acct-1")] | "2026-01-01T00:00:00Z"      | LocalDateTime.of(2026, 1, 1, 0, 0)   | "id-2"   | true
    }

    // ============================================================
    // Tests for Cosmos DB error handling in ORACLEMASTER mode
    // (commit 2db8962c - GPB_111)
    // ============================================================

    def "ORACLEMASTER: Cosmos DB write exception is caught and processing continues in storeMPSData"() {
        given: "ORACLEMASTER mode with Cosmos DB throwing exception during write"
        securityCodeDBHelper.getSecurityAccountData(_) >> resultHashSuccess
        securityCodeDBHelper.updateSecurityAccount(_, _) >> resultHashSuccess
        securityCodeDBHelper.getSecurityCodeDataQuery(_) >> resultHashSuccess
        securityCodeDBHelper.setSecurityCode(_) >> resultHashSuccess

        // Cosmos DB findByIdentificationTypeAndAccountId throws exception
        idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> { throw new RuntimeException("Cosmos connection timeout") }

        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> "ORACLEMASTER"
        hmInput["security_code_expiration_time"] = "10"
        generatePINBaseO.initialize(hmInput)

        when:
        hmResult = generatePINBaseO.storeMPSData()

        then: "Exception is caught, processing continues to success"
        hmResult != null
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        notThrown(RuntimeException)
    }

    def "ORACLEMASTER: Cosmos DB createOrUpdateEntity exception is caught and processing continues in storeMPSData"() {
        given: "ORACLEMASTER mode with Cosmos DB throwing exception during createOrUpdateEntity"
        securityCodeDBHelper.getSecurityAccountData(_) >> resultHashSuccess
        securityCodeDBHelper.updateSecurityAccount(_, _) >> resultHashSuccess
        securityCodeDBHelper.getSecurityCodeDataQuery(_) >> resultHashSuccess
        securityCodeDBHelper.setSecurityCode(_) >> resultHashSuccess

        List<IdgOtpContainer> mockContainers = new ArrayList<>()
        IdgOtpContainer mockContainer = new IdgOtpContainer()
        mockContainer.setIdentificationType("IDSEMOB")
        mockContainer.setAccountId("5214001254")
        mockContainer.setSecurityCodes(new ArrayList<>())
        mockContainers.add(mockContainer)

        idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> mockContainers
        // createOrUpdateEntity throws exception
        idgOtpDBHelper.createOrUpdateEntity(_) >> { throw new RuntimeException("Cosmos write failed") }

        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> "ORACLEMASTER"
        hmInput["security_code_expiration_time"] = "10"
        generatePINBaseO.initialize(hmInput)

        when:
        hmResult = generatePINBaseO.storeMPSData()

        then: "Exception is caught, processing continues to success"
        hmResult != null
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        notThrown(RuntimeException)
    }

    def "COSMOSMASTER: Cosmos DB write exception is re-thrown in storeMPSData"() {
        given: "COSMOSMASTER mode with Cosmos DB throwing exception during write"
        // In COSMOSMASTER, Oracle calls are skipped, Cosmos is primary
        idgOtpDBHelper.getSecurityAccountData(_) >> resultHashSuccess
        idgOtpDBHelper.updateSecurityAccount(_, _) >> resultHashSuccess
        idgOtpDBHelper.getSecurityCodeDataQuery(_) >> resultHashSuccess

        // Cosmos DB findByIdentificationTypeAndAccountId throws exception
        idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> { throw new RuntimeException("Cosmos connection timeout") }

        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> "COSMOSMASTER"
        hmInput["security_code_expiration_time"] = "10"
        generatePINBaseO.initialize(hmInput)

        when:
        hmResult = generatePINBaseO.storeMPSData()

        then: "Exception propagates to outer catch, returning system error"
        hmResult != null
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    @Unroll
    def "should call gotpPublisher.sendToPrimary and return success for #scenarioName"() {
        given: "A GeneratePINBase Spy with a mocked GenericOTPPublisher and stubbed genericOTPmessageObject"
        GenericOTPPublisher gotpPublisher = Mock(GenericOTPPublisher)
        GeneratePINBase generatePINBase = Spy(new GeneratePINBase(otpHistoryDBHelper, otpHistoryExecutor))
        ReflectionTestUtils.setField(generatePINBase, "gotpPublisher", gotpPublisher)
        GenericOTPNotification notification = new GenericOTPNotification()
        notification.setNotificationID("IDGRAPHContactInfoMs-123")
        notification.setNotificationType("OTP")
        generatePINBase.genericOTPmessageObject(_ as Map) >> notification
        Map<String, Object> input = new LinkedHashMap<>()
        input.put("idpTraceId", "123")

        when: "makeGenericOTPAEHCall is called"
        HashMap<String, Object> result = generatePINBase.makeGenericOTPAEHCall(input)

        then: "gotpPublisher.sendToPrimary is called once with a JSON string containing the notificationID and result is validated"
        1 * gotpPublisher.sendToPrimary({ String json -> json != null && json.contains('"notificationID":"IDGRAPHContactInfoMs-123"') })
        result != null
        result["appStatusCode"] == CErrorDefs.COMMON_SUCCESS_NUM.toString()
        result["appInfo"] == "SUCCESS"

        where:
        scenarioName | _
        "valid input" | _
    }

    @Unroll
    def "should build GenericOTPNotification correctly for #scenarioName"() {
        given: "A GeneratePINBase instance and input map for genericOTPmessageObject"
        GeneratePINBase generatePINBase = new GeneratePINBase(otpHistoryDBHelper, otpHistoryExecutor)
        Map<String, Object> input = new LinkedHashMap<>()
        input.put("idpTraceId", idpTraceId)
        input.put("accountId", accountId)
        input.put("identificationType", identificationType)
        input.put("browserLanguage", browserLanguage)
        input.put("callingSystemId", callingSystemId)
        input.put("security_pin_expiration_date", expirationDate)
        Map<String, Object> smsMap = new LinkedHashMap<>()
        smsMap.put("smsPhoneNumber", smsPhoneNumber)
        Map<String, Object> emailMap = new LinkedHashMap<>()
        emailMap.put("emailaddress", emailAddress)
        Map<String, Object> deliveryMethods = new LinkedHashMap<>()
        if (smsPhoneNumber != null) deliveryMethods.put("SMS", smsMap)
        if (emailAddress != null) deliveryMethods.put("EMAIL", emailMap)
        input.put("deliveryMethods", deliveryMethods)

        when: "genericOTPmessageObject is called"
        GenericOTPNotification notification = generatePINBase.genericOTPmessageObject(input)

        then: "Notification fields are set as expected"
        notification != null
        notification.getNotificationID() == expectedNotificationId
        notification.getNotificationType() == "OTP"
        notification.getNotificationCategory() == "GeneratePIN"
        notification.getNotificationsubCategory() == identificationType
        notification.getNotificationDetails() != null
        notification.getNotificationDetails().getAccountId() == accountId
        notification.getNotificationDetails().getAccountType() == expectedAccountType
        notification.getNotificationDetails().getLangPreference() == expectedLang
        notification.getNotificationDetails().getClientId() == callingSystemId
        0 * _

        where:
        scenarioName         | idpTraceId | accountId   | identificationType | browserLanguage | callingSystemId | expirationDate      | smsPhoneNumber | emailAddress      | expectedNotificationId         | expectedAccountType | expectedLang
        "wireless sms"      | "123"      | "A1"        | "IDSEMOB"         | "en"           | "SYS1"         | "2025-09-13"       | "5551112222"  | null             | "IDGRAPHContactInfoMs-123"    | "WIRELESS"        | "EN"
        "bsse event email"  | "456"      | "B2"        | "PORTOUTBSS"      | "es"           | "SYS2"         | "2025-09-14"       | null           | "test@att.com"   | "IDGRAPHContactInfoMs-456"    | "BSSEWIRELESS"    | "ES"
    }

    @Unroll
    def "should return ERR_ACCOUNT_LOCKOUT when account is locked for #scenarioName"() {
        given: "A locked account with unlockAccountTime in the future and proper mocks"
        String identificationType = "BSSEGENE"
        String accountId = "5214001254"
        String unlockAccountTime = java.time.Instant.now().plusSeconds(3600).toString() // 1 hour in future
        IdgOtpContainer lockedContainer = new IdgOtpContainer()
        lockedContainer.setIdentificationType(identificationType)
        lockedContainer.setAccountId(accountId)
        lockedContainer.setUnlockAccountTime(unlockAccountTime)


        // Set up input and mocks
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = identificationType
        hmInput[CommonDefs.ACCOUNT_ID] = accountId
        generatePINBaseO.initialize(hmInput)
        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> "ONLYCOSMOS"
        validatePINHelper.parseOtpUnlockAccountMinutes() >> ["BSSEGENE": "60"]
         idgOtpDBHelper.findByIdentificationTypeAndAccountId(_ as IdgOtpContainer) >>Optional.of(lockedContainer)

        when: "generateOTPWithLockoutCheck is called"
        Map<String, Object> result = generatePINBaseO.generateOTPWithLockoutCheck()

        then: "Result is ERR_ACCOUNT_LOCKOUT and no OTP is generated"
        result != null
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.ERR_ACCOUNT_LOCKOUT
        result[CommonDefs.COMMON_APP_INFO] == "Auth method is locked for OTP generation"

    }

    @Unroll
    def "should call processInputData when account is not locked for #scenarioName"() {
        given: "An account with unlockAccountTime in the past or not set, and proper mocks"
        String identificationType = "IDSEMOB"
        String accountId = "5214001254"
        String unlockAccountTime = java.time.Instant.now().minusSeconds(3600).toString() // 1 hour in past
        IdgOtpContainer unlockedContainer = new IdgOtpContainer()
        unlockedContainer.setIdentificationType(identificationType)
        unlockedContainer.setAccountId(accountId)
        unlockedContainer.setUnlockAccountTime(unlockAccountTime)


        // Set up input and mocks
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = identificationType
        hmInput[CommonDefs.ACCOUNT_ID] = accountId
        generatePINBaseO.initialize(hmInput)
        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> "COSMOSMASTER"
         validatePINHelper.parseOtpUnlockAccountMinutes() >> [(identificationType): "60"]
        idgOtpDBHelper.findByIdentificationTypeAndAccountId(_ as IdgOtpContainer) >>Optional.of(unlockedContainer)

        generatePINBaseO.processInputData() >> resultHashSuccess


        when: "generateOTPWithLockoutCheck is called"
        Map<String, Object> result = generatePINBaseO.generateOTPWithLockoutCheck()

        then: "Result is from processInputData and not lockout error"
        result != null
        result[CommonDefs.COMMON_APP_INFO] == "Input Data processed Successfully"

        where:
        scenarioName      | otpDataSource
        "ONLYCOSMOS"      | "ONLYCOSMOS"
        "COSMOSMASTER"    | "COSMOSMASTER"
    }

    // ============================================================
    // High-impact tests for getOtpDataSource (covers ~15 lines)
    // ============================================================

    def "getOtpDataSource returns COSMOSMASTER when feature flag is null"() {
        given:
        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> null

        when:
        String result = generatePINBaseO.getOtpDataSource()

        then:
        result == "COSMOSMASTER"
    }

    @Unroll
    def "getOtpDataSource returns valid value for #dataSource"() {
        given:
        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> dataSource

        when:
        String result = generatePINBaseO.getOtpDataSource()

        then:
        result == dataSource

        where:
        dataSource << ["ORACLEMASTER", "ONLYORACLE", "ONLYCOSMOS", "COSMOSMASTER"]
    }

    def "getOtpDataSource throws IllegalArgumentException for invalid value"() {
        given:
        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> "INVALID_SOURCE"

        when:
        generatePINBaseO.getOtpDataSource()

        then:
        thrown(IllegalArgumentException)
    }

    // ============================================================
    // High-impact tests for createSecurityCode (covers ~25 lines)
    // ============================================================

    @Unroll
    def "createSecurityCode generates code of correct length for #scenarioName"() {
        when:
        String code = generatePINBaseO.createSecurityCode(codeLength)

        then:
        code != null
        code.length() == Integer.parseInt(codeLength)
        code.matches("[0-9]+")
        0 * _

        where:
        scenarioName  | codeLength
        "6 digits"    | "6"
        "8 digits"    | "8"
        "4 digits"    | "4"
    }

    // ============================================================
    // High-impact tests for getDeliveryMethodAndDetails (covers ~120 lines)
    // ============================================================

    def "getDeliveryMethodAndDetails returns SMS delivery method and details"() {
        given:
        HashMap hmDM = CommonUtil.getHashMap()
        HashMap hmSmsInner = CommonUtil.getHashMap()
        hmSmsInner['smsPhoneNumber'] = '5551234567'
        hmDM[CommonDefs.SMS] = hmSmsInner
        generatePINBaseO.initialize(hmInput)

        when:
        HashMap result = generatePINBaseO.getDeliveryMethodAndDetails(hmDM)

        then:
        result != null
        result[CommonDefs.DELIVERY_METHOD] == "S"
        result[CommonDefs.DELIVERY_DETAIL] != null
    }

    def "getDeliveryMethodAndDetails returns EMAIL delivery method and details"() {
        given:
        HashMap hmDM = CommonUtil.getHashMap()
        HashMap hmEmailInner = CommonUtil.getHashMap()
        hmEmailInner['emailAddress'] = 'test@att.com'
        hmDM[CommonDefs.EMAIL] = hmEmailInner
        generatePINBaseO.initialize(hmInput)

        when:
        HashMap result = generatePINBaseO.getDeliveryMethodAndDetails(hmDM)

        then:
        result != null
        result[CommonDefs.DELIVERY_METHOD] == "E"
        result[CommonDefs.DELIVERY_DETAIL] == 'test@att.com'
    }

    def "getDeliveryMethodAndDetails returns LETTER delivery method with full address"() {
        given:
        HashMap hmDM = CommonUtil.getHashMap()
        HashMap hmLetterInner = CommonUtil.getHashMap()
        hmLetterInner['name'] = 'John Doe'
        hmLetterInner['street1'] = '123 Main St'
        hmLetterInner['street2'] = 'Apt 4'
        hmLetterInner['street3'] = 'Suite B'
        hmLetterInner['postOffice'] = 'PO Box 100'
        hmLetterInner['city'] = 'Dallas'
        hmLetterInner['state'] = 'TX'
        hmLetterInner['zipCode'] = '75001'
        hmLetterInner['zipPlusFour'] = '1234'
        hmLetterInner['country'] = 'US'
        hmLetterInner['foreignAddrInd'] = 'N'
        hmDM[CommonDefs.LETTER] = hmLetterInner
        generatePINBaseO.initialize(hmInput)

        when:
        HashMap result = generatePINBaseO.getDeliveryMethodAndDetails(hmDM)

        then:
        result != null
        result[CommonDefs.DELIVERY_METHOD] == "M"
        result[CommonDefs.DELIVERY_DETAIL] != null
    }

    def "getDeliveryMethodAndDetails returns LETTER with invalid foreignAddrInd returns error"() {
        given:
        HashMap hmDM = CommonUtil.getHashMap()
        HashMap hmLetterInner = CommonUtil.getHashMap()
        hmLetterInner['name'] = 'John Doe'
        hmLetterInner['street1'] = '123 Main St'
        hmLetterInner['foreignAddrInd'] = 'INVALID'
        hmDM[CommonDefs.LETTER] = hmLetterInner
        generatePINBaseO.initialize(hmInput)

        when:
        HashMap result = generatePINBaseO.getDeliveryMethodAndDetails(hmDM)

        then:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }

    def "getDeliveryMethodAndDetails returns AO delivery method"() {
        given:
        HashMap hmDM = CommonUtil.getHashMap()
        HashMap hmAoInner = CommonUtil.getHashMap()
        hmAoInner['phoneNumber'] = '9876543210'
        hmDM[CommonDefs.AO] = hmAoInner
        generatePINBaseO.initialize(hmInput)

        when:
        HashMap result = generatePINBaseO.getDeliveryMethodAndDetails(hmDM)

        then:
        result != null
        result[CommonDefs.DELIVERY_METHOD] == "A"
        result[CommonDefs.DELIVERY_DETAIL] == '9876543210'
    }

    def "getDeliveryMethodAndDetails returns success with null delivery methods map"() {
        when:
        HashMap result = generatePINBaseO.getDeliveryMethodAndDetails(null)

        then:
        result != null
        result[CommonDefs.DELIVERY_METHOD] == null
        result[CommonDefs.DELIVERY_DETAIL] == null
    }

    def "getDeliveryMethodAndDetails returns success with empty delivery methods map"() {
        when:
        HashMap result = generatePINBaseO.getDeliveryMethodAndDetails(new HashMap())

        then:
        result != null
        result[CommonDefs.DELIVERY_METHOD] == null
    }

    // ============================================================
    // High-impact tests for prepareDataForCCMuleSyncCall (covers ~170 lines)
    // ============================================================

    def "prepareDataForCCMuleSyncCall returns error when delivery methods is null"() {
        given:
        hmInput[CommonDefs.DELIVERY_METHODS] = null
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        generatePINBaseO.initialize(hmInput)

        when:
        Map<String, Object> result = generatePINBaseO.prepareDataForCCMuleSyncCall()

        then:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
        result[CommonDefs.COMMON_APP_INFO] == 'Please provide a delivery method'
    }

    def "prepareDataForCCMuleSyncCall returns error when delivery methods is empty"() {
        given:
        hmInput[CommonDefs.DELIVERY_METHODS] = new HashMap()
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        generatePINBaseO.initialize(hmInput)

        when:
        Map<String, Object> result = generatePINBaseO.prepareDataForCCMuleSyncCall()

        then:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
        result[CommonDefs.COMMON_APP_INFO] == 'Delivery method is empty'
    }

    def "prepareDataForCCMuleSyncCall success with SMS delivery and OTP EDD to CLM enabled"() {
        given:
        HashMap hmSmsDelivery = CommonUtil.getHashMap()
        hmSmsDelivery['smsPhoneNumber'] = '5551112222'
        HashMap hmDM = CommonUtil.getHashMap()
        hmDM['SMS'] = hmSmsDelivery
        hmInput[CommonDefs.DELIVERY_METHODS] = hmDM
        hmInput[CommonDefs.RES_BUS_IND] = 'R'
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> true
        ReflectionTestUtils.setField(generatePINBaseO, 'propSubCategoryClm',
                'BSSEOTP:TEMP_PIN_CLM|BSSEONL:TEMP_PIN_CLM')
        generatePINBaseO.initialize(hmInput)

        when:
        Map<String, Object> result = generatePINBaseO.prepareDataForCCMuleSyncCall()

        then:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        result[CommonDefs.COMMUNICATION_NOTIFICATION] != null
    }

    def "prepareDataForCCMuleSyncCall success with EMAIL delivery and attributes"() {
        given:
        HashMap hmEmailDelivery = CommonUtil.getHashMap()
        hmEmailDelivery['emailAddress'] = 'test@att.com'
        HashMap hmDM = CommonUtil.getHashMap()
        hmDM['EMAIL'] = hmEmailDelivery
        hmInput[CommonDefs.DELIVERY_METHODS] = hmDM
        hmInput[CommonDefs.BROWSER_LANGUAGE] = null
        ArrayList<Map<String, String>> attrs = new ArrayList<>()
        attrs.add(['attributeName': 'key1', 'attributeValue': 'val1'])
        hmInput[CommonDefs.ATTRIBUTE_LIST] = attrs
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        generatePINBaseO.initialize(hmInput)

        when:
        Map<String, Object> result = generatePINBaseO.prepareDataForCCMuleSyncCall()

        then:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        result[CommonDefs.COMMUNICATION_NOTIFICATION] != null
    }

    // ============================================================
    // High-impact tests for makeCCMuleSyncCall (covers ~90 lines)
    // ============================================================

    def "makeCCMuleSyncCall returns config error when propStubCCMULECall is null"() {
        given:
        ReflectionTestUtils.setField(generatePINBaseO, 'propStubCCMULECall', null)
        generatePINBaseO.initialize(hmInput)
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false

        when:
        HashMap<String, Object> result = generatePINBaseO.makeCCMuleSyncCall(new ArrayList())

        then:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_CONFIG'
    }

    def "makeCCMuleSyncCall returns config error when propStubCCMULECall is empty"() {
        given:
        ReflectionTestUtils.setField(generatePINBaseO, 'propStubCCMULECall', '  ')
        generatePINBaseO.initialize(hmInput)
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false

        when:
        HashMap<String, Object> result = generatePINBaseO.makeCCMuleSyncCall(new ArrayList())

        then:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_CONFIG'
    }

    def "makeCCMuleSyncCall stub call returns success with returnSecurityCode"() {
        given:
        ReflectionTestUtils.setField(generatePINBaseO, 'propStubCCMULECall', 'Y')
        hmInput[CommonDefs.RETURN_SECURITY_CODE] = 'Y'
        hmInput[CommonDefs.SECURITY_CODE] = '123456'
        generatePINBaseO.initialize(hmInput)
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false

        when:
        HashMap<String, Object> result = generatePINBaseO.makeCCMuleSyncCall(new ArrayList())

        then:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        result[CommonDefs.SECURITY_CODE] == '123456'
        result[CommonDefs.SECURITY_PIN_EXPIRATION_DATE] != null
    }

    def "makeCCMuleSyncCall real call returns null response"() {
        given:
        ReflectionTestUtils.setField(generatePINBaseO, 'propStubCCMULECall', 'N')
        ReflectionTestUtils.setField(generatePINBaseO, 'ccmulesoftServerUrl', 'http://localhost')
        ReflectionTestUtils.setField(generatePINBaseO, 'ccmulesoftEndpoint', '/api/clm')
        ReflectionTestUtils.setField(generatePINBaseO, 'clmHighPriorityServerUrl', 'http://localhost')
        ReflectionTestUtils.setField(generatePINBaseO, 'clmHighPriorityEndpoint', '/api/clm-hp')
        generatePINBaseO.initialize(hmInput)
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        muleSoftRestClient.postCCMuleSyncCall(_, _, _) >> null

        when:
        HashMap<String, Object> result = generatePINBaseO.makeCCMuleSyncCall(new ArrayList())

        then:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "makeCCMuleSyncCall real call returns error response"() {
        given:
        ReflectionTestUtils.setField(generatePINBaseO, 'propStubCCMULECall', 'N')
        ReflectionTestUtils.setField(generatePINBaseO, 'ccmulesoftServerUrl', 'http://localhost')
        ReflectionTestUtils.setField(generatePINBaseO, 'ccmulesoftEndpoint', '/api/clm')
        ReflectionTestUtils.setField(generatePINBaseO, 'clmHighPriorityServerUrl', 'http://localhost')
        ReflectionTestUtils.setField(generatePINBaseO, 'clmHighPriorityEndpoint', '/api/clm-hp')
        generatePINBaseO.initialize(hmInput)
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        HashMap errorResp = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, 'CLM Error')
        muleSoftRestClient.postCCMuleSyncCall(_, _, _) >> errorResp

        when:
        HashMap<String, Object> result = generatePINBaseO.makeCCMuleSyncCall(new ArrayList())

        then:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == 'CLM Error'
    }

    def "makeCCMuleSyncCall real call success with high priority routing and OTP EDD CLM enabled"() {
        given:
        ReflectionTestUtils.setField(generatePINBaseO, 'propStubCCMULECall', 'N')
        ReflectionTestUtils.setField(generatePINBaseO, 'ccmulesoftServerUrl', 'http://localhost')
        ReflectionTestUtils.setField(generatePINBaseO, 'ccmulesoftEndpoint', '/api/clm')
        ReflectionTestUtils.setField(generatePINBaseO, 'clmHighPriorityServerUrl', 'http://hp-localhost')
        ReflectionTestUtils.setField(generatePINBaseO, 'clmHighPriorityEndpoint', '/api/clm-hp')
        ReflectionTestUtils.setField(generatePINBaseO, 'propHighPriorityIdentificationTypesClm',
                'IDSEMOB|BSSEOTP')
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'IDSEMOB'
        hmInput[CommonDefs.RETURN_SECURITY_CODE] = 'N'
        generatePINBaseO.initialize(hmInput)
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> true
        HashMap successResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        muleSoftRestClient.postCCMuleSyncCall(_, _, { String url -> url.contains("hp-localhost") }) >> successResp

        when:
        HashMap<String, Object> result = generatePINBaseO.makeCCMuleSyncCall(new ArrayList())

        then:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        result[CommonDefs.SECURITY_CODE] == null
        result[CommonDefs.SECURITY_PIN_EXPIRATION_DATE] != null
    }

    // ============================================================
    // High-impact tests for prepareDataForAsyncCall (covers ~115 lines)
    // ============================================================

    def "prepareDataForAsyncCall success with SMS delivery method"() {
        given:
        HashMap hmSmsDelivery = CommonUtil.getHashMap()
        hmSmsDelivery['smsPhoneNumber'] = '5551112222'
        HashMap hmDM = CommonUtil.getHashMap()
        hmDM['SMS'] = hmSmsDelivery
        hmInput[CommonDefs.DELIVERY_METHODS] = hmDM
        hmInput['security_code_expiration_time'] = '60'
        hmInput[CommonDefs.TOKEN] = 'test-token'
        hmInput['dbusTransactionId'] = 'dbus-123'
        hmInput[CommonDefs.RES_BUS_IND] = 'R'
        generatePINBaseO.initialize(hmInput)

        when:
        Map<String, Object> result = generatePINBaseO.prepareDataForAsyncCall()

        then:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        result[CommonDefs.CONSOLIDATED_DBUS_INPUT] != null
    }

    def "prepareDataForAsyncCall success with EMAIL delivery method"() {
        given:
        HashMap hmEmailDelivery = CommonUtil.getHashMap()
        hmEmailDelivery['emailAddress'] = 'test@att.com'
        HashMap hmDM = CommonUtil.getHashMap()
        hmDM['EMAIL'] = hmEmailDelivery
        hmInput[CommonDefs.DELIVERY_METHODS] = hmDM
        hmInput['security_code_expiration_time'] = '120'
        hmInput['dbusTransactionId'] = 'dbus-456'
        generatePINBaseO.initialize(hmInput)

        when:
        Map<String, Object> result = generatePINBaseO.prepareDataForAsyncCall()

        then:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "prepareDataForAsyncCall success with LETTER delivery method"() {
        given:
        HashMap hmLetterDelivery = CommonUtil.getHashMap()
        hmLetterDelivery['name'] = 'John Doe'
        hmLetterDelivery['street1'] = '123 Main St'
        hmLetterDelivery['notifyViaLetter'] = 'Y'
        HashMap hmDM = CommonUtil.getHashMap()
        hmDM['LETTER'] = hmLetterDelivery
        hmInput[CommonDefs.DELIVERY_METHODS] = hmDM
        hmInput['security_code_expiration_time'] = '60'
        hmInput['dbusTransactionId'] = 'dbus-789'
        generatePINBaseO.initialize(hmInput)

        when:
        Map<String, Object> result = generatePINBaseO.prepareDataForAsyncCall()

        then:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "prepareDataForAsyncCall success with AO delivery method"() {
        given:
        HashMap hmAoDelivery = CommonUtil.getHashMap()
        hmAoDelivery['phoneNumber'] = '9876543210'
        HashMap hmDM = CommonUtil.getHashMap()
        hmDM['AO'] = hmAoDelivery
        hmInput[CommonDefs.DELIVERY_METHODS] = hmDM
        hmInput['security_code_expiration_time'] = '60'
        hmInput['dbusTransactionId'] = 'dbus-101'
        hmInput[CommonDefs.ACCOUNT_ID] = '12345'
        generatePINBaseO.initialize(hmInput)

        when:
        Map<String, Object> result = generatePINBaseO.prepareDataForAsyncCall()

        then:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "prepareDataForAsyncCall with ENCPIN identification type sets encrypted key"() {
        given:
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'ENCPIN'
        hmInput[CommonDefs.TOKEN] = 'encrypted-token-value'
        hmInput['security_code_expiration_time'] = '60'
        hmInput['dbusTransactionId'] = 'dbus-enc'
        hmInput[CommonDefs.ATTRIBUTE_LIST] = [['name': 'attr1', 'value': 'val1']]
        generatePINBaseO.initialize(hmInput)

        when:
        Map<String, Object> result = generatePINBaseO.prepareDataForAsyncCall()

        then:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "prepareDataForAsyncCall with no delivery methods"() {
        given:
        hmInput[CommonDefs.DELIVERY_METHODS] = null
        hmInput['security_code_expiration_time'] = '60'
        hmInput['dbusTransactionId'] = 'dbus-no-dm'
        generatePINBaseO.initialize(hmInput)

        when:
        Map<String, Object> result = generatePINBaseO.prepareDataForAsyncCall()

        then:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "prepareDataForAsyncCall with numeric account ID sets ban field"() {
        given:
        hmInput[CommonDefs.ACCOUNT_ID] = '999888777'
        hmInput['security_code_expiration_time'] = null
        hmInput['dbusTransactionId'] = 'dbus-ban'
        generatePINBaseO.initialize(hmInput)

        when:
        Map<String, Object> result = generatePINBaseO.prepareDataForAsyncCall()

        then:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    // ============================================================
    // High-impact tests for makeAsyncCall (covers ~75 lines)
    // ============================================================

    def "makeAsyncCall with callDbus N returns success with consolidated input"() {
        given:
        hmInput[CommonDefs.CALLDBUS] = 'N'
        hmInput['dbusTransactionId'] = 'dbus-n'
        hmInput[CommonDefs.RETURN_SECURITY_CODE] = 'Y'
        hmInput[CommonDefs.SECURITY_CODE] = '654321'
        generatePINBaseO.initialize(hmInput)

        when:
        HashMap result = generatePINBaseO.makeAsyncCall(new ArrayList())

        then:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        result[CommonDefs.SECURITY_CODE] == '654321'
    }

    def "makeAsyncCall JMSQueueSender returns error status"() {
        given:
        hmInput[CommonDefs.CALLDBUS] = null
        hmInput['dbusTransactionId'] = 'dbus-err'
        hmdeliveryMethods['sms'] = hmSms
        hmInput[CommonDefs.DELIVERY_METHODS] = hmdeliveryMethods
        HashMap errorResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, 'JMS Error')
        oJMSQueueSender.send(_) >> errorResult
        generatePINBaseO.initialize(hmInput)

        when:
        HashMap result = generatePINBaseO.makeAsyncCall(new ArrayList())

        then:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "makeAsyncCall JMSQueueSender returns null"() {
        given:
        hmInput[CommonDefs.CALLDBUS] = null
        hmInput['dbusTransactionId'] = 'dbus-null'
        hmdeliveryMethods['sms'] = hmSms
        hmInput[CommonDefs.DELIVERY_METHODS] = hmdeliveryMethods
        oJMSQueueSender.send(_) >> null
        generatePINBaseO.initialize(hmInput)

        when:
        HashMap result = generatePINBaseO.makeAsyncCall(new ArrayList())

        then:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    // ============================================================
    // High-impact tests for makeGenericOTPAEHCall exception paths (covers ~25 lines)
    // ============================================================

    def "makeGenericOTPAEHCall handles PrimaryProducerException"() {
        given:
        GenericOTPPublisher gotpPub = Mock(GenericOTPPublisher)
        GeneratePINBase gpbSpy = Spy(new GeneratePINBase(otpHistoryDBHelper, otpHistoryExecutor))
        ReflectionTestUtils.setField(gpbSpy, "gotpPublisher", gotpPub)
        GenericOTPNotification notification = new GenericOTPNotification()
        notification.setNotificationID("test-id")
        gpbSpy.genericOTPmessageObject(_ as Map) >> notification
        gotpPub.sendToPrimary(_) >> { throw new com.att.idp.idgraphcontactinfoms.exceptions.PrimaryProducerException("primary fail") }

        when:
        HashMap<String, Object> result = gpbSpy.makeGenericOTPAEHCall(new LinkedHashMap())

        then:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "makeGenericOTPAEHCall handles generic Exception"() {
        given:
        GenericOTPPublisher gotpPub = Mock(GenericOTPPublisher)
        GeneratePINBase gpbSpy = Spy(new GeneratePINBase(otpHistoryDBHelper, otpHistoryExecutor))
        ReflectionTestUtils.setField(gpbSpy, "gotpPublisher", gotpPub)
        GenericOTPNotification notification = new GenericOTPNotification()
        notification.setNotificationID("test-id")
        gpbSpy.genericOTPmessageObject(_ as Map) >> notification
        gotpPub.sendToPrimary(_) >> { throw new RuntimeException("unexpected error") }

        when:
        HashMap<String, Object> result = gpbSpy.makeGenericOTPAEHCall(new LinkedHashMap())

        then:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    // ============================================================
    // High-impact tests for genericOTPmessageObject PORTOUTBSS path (covers ~40 lines)
    // ============================================================

    def "genericOTPmessageObject sets BSSEWIRELESS and isBsseEvent Y for PORTOUTBSS"() {
        given:
        GeneratePINBase gpb = new GeneratePINBase(otpHistoryDBHelper, otpHistoryExecutor)
        Map<String, Object> input = new LinkedHashMap<>()
        input.put("idpTraceId", "trace-bsse")
        input.put("accountId", "ACCT-BSS")
        input.put("identificationType", "PORTOUTBSS")
        input.put("browserLanguage", null)
        input.put("callingSystemId", "MULESOFT")
        input.put("security_pin_expiration_date", "2025-12-01")
        input.put("channel", "IVR")
        Map<String, Object> deliveryMethods = new LinkedHashMap<>()
        Map<String, Object> smsMap = new LinkedHashMap<>()
        smsMap.put("smsPhoneNumber", "5559998888")
        deliveryMethods.put("SMS", smsMap)
        input.put("deliveryMethods", deliveryMethods)

        when:
        GenericOTPNotification notification = gpb.genericOTPmessageObject(input)

        then:
        notification != null
        notification.getNotificationDetails().getAccountType() == "BSSEWIRELESS"
        notification.getNotificationDetails().getLangPreference() == "EN"
        notification.getNotificationDetails().getChannel() == "IVR"
        notification.getNotificationDetails().getAttributeList().any { it.getAttributeName() == "isBsseEvent" && it.getAttributeValue() == "Y" }
    }

    def "genericOTPmessageObject with email only delivery for non-PORTOUTBSS"() {
        given:
        GeneratePINBase gpb = new GeneratePINBase(otpHistoryDBHelper, otpHistoryExecutor)
        Map<String, Object> input = new LinkedHashMap<>()
        input.put("idpTraceId", "trace-email")
        input.put("accountId", "ACCT-EMAIL")
        input.put("identificationType", "IDSEMOB")
        input.put("browserLanguage", "es")
        input.put("callingSystemId", "IDP")
        input.put("security_pin_expiration_date", "2025-12-01")
        Map<String, Object> deliveryMethods = new LinkedHashMap<>()
        Map<String, Object> emailMap = new LinkedHashMap<>()
        emailMap.put("emailaddress", "test@email.com")
        deliveryMethods.put(CommonDefs.EMAIL, emailMap)
        input.put("deliveryMethods", deliveryMethods)

        when:
        GenericOTPNotification notification = gpb.genericOTPmessageObject(input)

        then:
        notification != null
        notification.getNotificationDetails().getAccountType() == "WIRELESS"
        notification.getNotificationDetails().getLangPreference() == "ES"
        notification.getNotificationDetails().getAttributeList().any { it.getAttributeName() == "isBsseEvent" && it.getAttributeValue() == "N" }
        notification.getNotificationDetails().getAttributeList().any { it.getAttributeName() == "emailAddress" && it.getAttributeValue() == "test@email.com" }
    }

    // ============================================================
    // High-impact tests for getUnlockTime (covers ~15 lines)
    // ============================================================

    def "getUnlockTime returns Instant when unlockAccountTime is present"() {
        given:
        String futureTime = java.time.Instant.now().plusSeconds(3600).toString()
        IdgOtpContainer container = new IdgOtpContainer()
        container.setIdentificationType("IDSEMOB")
        container.setAccountId("acct-1")
        container.setUnlockAccountTime(futureTime)
        idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.of(container)

        when:
        Instant result = generatePINBaseO.getUnlockTime(new IdgOtpContainer())

        then:
        result != null
    }

    def "getUnlockTime returns null when container not found"() {
        given:
        idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()

        when:
        Instant result = generatePINBaseO.getUnlockTime(new IdgOtpContainer())

        then:
        result == null
    }

    def "getUnlockTime returns null when unlockAccountTime is null"() {
        given:
        IdgOtpContainer container = new IdgOtpContainer()
        container.setUnlockAccountTime(null)
        idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.of(container)

        when:
        Instant result = generatePINBaseO.getUnlockTime(new IdgOtpContainer())

        then:
        result == null
    }

    def "getUnlockTime throws exception when DB call fails"() {
        given:
        idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> { throw new RuntimeException("DB failure") }

        when:
        generatePINBaseO.getUnlockTime(new IdgOtpContainer())

        then:
        thrown(RuntimeException)
    }

    def "should handle exception when unlockAccountTime is invalid format"() {
        given: "A container with invalid unlockAccountTime format"
        String identificationType = "IDSEMOB"
        String accountId = "5214001254"
        String unlockAccountTime = "not-a-timestamp"
        IdgOtpContainer badContainer = new IdgOtpContainer()
        badContainer.setIdentificationType(identificationType)
        badContainer.setAccountId(accountId)
        badContainer.setUnlockAccountTime(unlockAccountTime)
        List<IdgOtpContainer> containers = new ArrayList<>()
        containers.add(badContainer)

        hmInput[CommonDefs.IDENTIFICATION_TYPE] = identificationType
        hmInput[CommonDefs.ACCOUNT_ID] = accountId
        generatePINBaseO.initialize(hmInput)
        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> "ONLYCOSMOS"
        validatePINHelper.parseOtpUnlockAccountMinutes() >> [(identificationType): "60"]
        idgOtpDBHelper.findByIdentificationTypeAndAccountId(_ as IdgOtpContainer) >> Optional.of(badContainer)

      /*   generatePINBaseO.processInputData() >> resultHashSuccess

        when: "generateOTPWithLockoutCheck is called"*/
/*
         generatePINBaseO.processInputData() >> resultHash
*/

        when:
        Map<String, Object> result = generatePINBaseO.generateOTPWithLockoutCheck()

        then:
        result != null


    }


    def "service type uses accountType when present in request"() throws Exception {
        given:
        hmdeliveryMethods['email'] = hmEmail
        hmdeliveryMethods['sms'] = hmSms
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'WBANSEC'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'BSSEWIRELESS'
        featureManager.isEnabled('svc-idgraph-phase1-otp-edd-to-clm-enabled') >> false

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.prepareDataForCCMuleSyncCall()
        ArrayList communication = (ArrayList) hmResult[CommonDefs.COMMUNICATION_NOTIFICATION]
        HashMap communicationMap = (HashMap) communication.get(0)
        ArrayList customers = (ArrayList) communicationMap[CommonDefs.CUSTOMERS]
        HashMap customerInfo = (HashMap) customers.get(0)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        customerInfo[CommonDefs.SERVICE_TYPE] == 'bssewireless'
    }

    def "service type uses config mapping when accountType not present"() throws Exception {
        given:
        hmdeliveryMethods['email'] = hmEmail
        hmdeliveryMethods['sms'] = hmSms
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'WBANSEC'
        featureManager.isEnabled('svc-idgraph-phase1-otp-edd-to-clm-enabled') >> false

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.prepareDataForCCMuleSyncCall()
        ArrayList communication = (ArrayList) hmResult[CommonDefs.COMMUNICATION_NOTIFICATION]
        HashMap communicationMap = (HashMap) communication.get(0)
        ArrayList customers = (ArrayList) communicationMap[CommonDefs.CUSTOMERS]
        HashMap customerInfo = (HashMap) customers.get(0)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        customerInfo[CommonDefs.SERVICE_TYPE] == 'wireless'
    }


    def "service type uses config mapping when accountType is null"() throws Exception {
        given:
        hmdeliveryMethods['email'] = hmEmail
        hmdeliveryMethods['sms'] = hmSms
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'WBANSEC'
        hmInput[CommonDefs.ACCOUNT_TYPE] = null
        featureManager.isEnabled('svc-idgraph-phase1-otp-edd-to-clm-enabled') >> false

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.prepareDataForCCMuleSyncCall()
        ArrayList communication = (ArrayList) hmResult[CommonDefs.COMMUNICATION_NOTIFICATION]
        HashMap communicationMap = (HashMap) communication.get(0)
        ArrayList customers = (ArrayList) communicationMap[CommonDefs.CUSTOMERS]
        HashMap customerInfo = (HashMap) customers.get(0)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        customerInfo[CommonDefs.SERVICE_TYPE] == 'wireless'
    }


    def "service type not set when accountType empty and no config mapping"() throws Exception {
        given:
        hmdeliveryMethods['email'] = hmEmail
        hmdeliveryMethods['sms'] = hmSms
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'IDSEMOB'
        hmInput[CommonDefs.ACCOUNT_TYPE] = ''
        featureManager.isEnabled('svc-idgraph-phase1-otp-edd-to-clm-enabled') >> false

        generatePINBaseO.initialize(hmInput)
        when:
        hmResult = generatePINBaseO.prepareDataForCCMuleSyncCall()
        ArrayList communication = (ArrayList) hmResult[CommonDefs.COMMUNICATION_NOTIFICATION]
        HashMap communicationMap = (HashMap) communication.get(0)
        ArrayList customers = (ArrayList) communicationMap[CommonDefs.CUSTOMERS]
        HashMap customerInfo = (HashMap) customers.get(0)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        customerInfo[CommonDefs.SERVICE_TYPE] == null
    }

    // ============================================================
    // Tests for AO and LETTER support in prepareDataForCCMuleSyncCall
    // ============================================================

    def "prepareDataForCCMuleSyncCall success with AO delivery method sets aoTN and mode AO"() {
        given:
        HashMap hmAoDelivery = CommonUtil.getHashMap()
        hmAoDelivery['phoneNumber'] = '9637260432'
        HashMap hmDM = CommonUtil.getHashMap()
        hmDM[CommonDefs.AO] = hmAoDelivery
        hmInput[CommonDefs.DELIVERY_METHODS] = hmDM
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'BSSEOTP'
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        generatePINBaseO.initialize(hmInput)

        when:
        Map<String, Object> result = generatePINBaseO.prepareDataForCCMuleSyncCall()

        then:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        ArrayList communication = (ArrayList) result[CommonDefs.COMMUNICATION_NOTIFICATION]
        HashMap communicationMap = (HashMap) communication.get(0)
        ArrayList customers = (ArrayList) communicationMap[CommonDefs.CUSTOMERS]
        HashMap customerInfo = (HashMap) customers.get(0)
        ArrayList aoTn = (ArrayList) customerInfo['aoTn']
        aoTn != null
        aoTn.size() == 1
        aoTn.get(0) == '9637260432'
        customerInfo[CommonDefs.Mode] == 'ao'
    }

    def "prepareDataForCCMuleSyncCall success with LETTER delivery method builds addresses and sets mode POSTAL"() {
        given:
        HashMap hmLetterDelivery = CommonUtil.getHashMap()
        hmLetterDelivery['name'] = 'John Doe'
        hmLetterDelivery['street1'] = '3400 Plano Pkwy'
        hmLetterDelivery['street2'] = 'Building 2'
        hmLetterDelivery['city'] = 'Plano'
        hmLetterDelivery['state'] = 'TX'
        hmLetterDelivery['zipCode'] = '75075'
        hmLetterDelivery['country'] = 'USA'
        HashMap hmDM = CommonUtil.getHashMap()
        hmDM[CommonDefs.LETTER] = hmLetterDelivery
        hmInput[CommonDefs.DELIVERY_METHODS] = hmDM
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'BSSEOTP'
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        generatePINBaseO.initialize(hmInput)

        when:
        Map<String, Object> result = generatePINBaseO.prepareDataForCCMuleSyncCall()

        then:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        ArrayList communication = (ArrayList) result[CommonDefs.COMMUNICATION_NOTIFICATION]
        HashMap communicationMap = (HashMap) communication.get(0)
        ArrayList customers = (ArrayList) communicationMap[CommonDefs.CUSTOMERS]
        HashMap customerInfo = (HashMap) customers.get(0)
        ArrayList addresses = (ArrayList) customerInfo['addresses']
        addresses != null
        addresses.size() == 1
        HashMap address = (HashMap) addresses.get(0)
        address['addressClasification'] == 'SERVICE'
        address['name'] == 'John Doe'
        address['address1'] == '3400 Plano Pkwy'
        address['address2'] == 'Building 2'
        address['city'] == 'Plano'
        address['state'] == 'TX'
        address['country'] == 'USA'
        address['zip'] == '75075'
        customerInfo[CommonDefs.Mode] == 'POSTAL'
    }

    def "prepareDataForCCMuleSyncCall LETTER success omits address2 when street2 is null"() {
        given:
        HashMap hmLetterDelivery = CommonUtil.getHashMap()
        hmLetterDelivery['name'] = 'John Doe'
        hmLetterDelivery['street1'] = '3400 Plano Pkwy'
        hmLetterDelivery['city'] = 'Plano'
        hmLetterDelivery['state'] = 'TX'
        hmLetterDelivery['zipCode'] = '75075'
        hmLetterDelivery['country'] = 'USA'
        HashMap hmDM = CommonUtil.getHashMap()
        hmDM[CommonDefs.LETTER] = hmLetterDelivery
        hmInput[CommonDefs.DELIVERY_METHODS] = hmDM
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'BSSEOTP'
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        generatePINBaseO.initialize(hmInput)

        when:
        Map<String, Object> result = generatePINBaseO.prepareDataForCCMuleSyncCall()

        then:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        ArrayList communication = (ArrayList) result[CommonDefs.COMMUNICATION_NOTIFICATION]
        HashMap communicationMap = (HashMap) communication.get(0)
        ArrayList customers = (ArrayList) communicationMap[CommonDefs.CUSTOMERS]
        HashMap customerInfo = (HashMap) customers.get(0)
        ArrayList addresses = (ArrayList) customerInfo['addresses']
        HashMap address = (HashMap) addresses.get(0)
        address['name'] == 'John Doe'
        !address.containsKey('address2')
    }

    def "prepareDataForCCMuleSyncCall LETTER success omits name when name is blank"() {
        given:
        HashMap hmLetterDelivery = CommonUtil.getHashMap()
        hmLetterDelivery['name'] = ''
        hmLetterDelivery['street1'] = '3400 Plano Pkwy'
        hmLetterDelivery['city'] = 'Plano'
        hmLetterDelivery['state'] = 'TX'
        hmLetterDelivery['zipCode'] = '75075'
        hmLetterDelivery['country'] = 'USA'
        HashMap hmDM = CommonUtil.getHashMap()
        hmDM[CommonDefs.LETTER] = hmLetterDelivery
        hmInput[CommonDefs.DELIVERY_METHODS] = hmDM
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'BSSEOTP'
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        generatePINBaseO.initialize(hmInput)

        when:
        Map<String, Object> result = generatePINBaseO.prepareDataForCCMuleSyncCall()

        then:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        ArrayList communication = (ArrayList) result[CommonDefs.COMMUNICATION_NOTIFICATION]
        HashMap communicationMap = (HashMap) communication.get(0)
        ArrayList customers = (ArrayList) communicationMap[CommonDefs.CUSTOMERS]
        HashMap customerInfo = (HashMap) customers.get(0)
        ArrayList addresses = (ArrayList) customerInfo['addresses']
        HashMap address = (HashMap) addresses.get(0)
        !address.containsKey('name')
    }


}
