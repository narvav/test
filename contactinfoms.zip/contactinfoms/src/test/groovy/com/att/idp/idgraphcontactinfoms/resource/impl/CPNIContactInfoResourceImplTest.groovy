package com.att.idp.idgraphcontactinfoms.resource.impl

import com.att.idp.core.exception.ServiceException
import com.att.idp.idgraphcontactinfoms.exceptions.InvalidInputDataException
import com.att.idp.idgraphcontactinfoms.message.ErrorMessages
import com.att.idp.idgraphcontactinfoms.request.validator.CPNIContactInfoRequestValidator
import com.att.idp.idgraphcontactinfoms.request.validator.QueryCPNIAcccountContactInfoRequestValidator
import com.att.idp.idgraphcontactinfoms.request.validator.QueryCPNIUserContactInfoRequestValidator
import com.att.idp.idgraphcontactinfoms.resource.request.QueryCPNIAccountContactInfoRequest
import com.att.idp.idgraphcontactinfoms.resource.request.QueryCPNIUserContactInfoRequest
import com.att.idp.idgraphcontactinfoms.resource.response.CPNIContactInfoResponse
import com.att.idp.idgraphcontactinfoms.resource.response.QueryCPNIAccountContactInfoResponse
import com.att.idp.idgraphcontactinfoms.resource.response.QueryCPNIUserContactInfoResponse
import com.att.idp.idgraphcontactinfoms.service.CPNIContactInfoService
import com.att.idp.idgraphcontactinfoms.service.QueryCPNIAccountContactInfoService
import com.att.idp.idgraphcontactinfoms.service.QueryCPNIUserContactInfoService
import com.att.mpsys.common.helpers.FeatureManagerHelper
import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap
import jakarta.ws.rs.core.MultivaluedMap
import jakarta.ws.rs.core.Response
import spock.lang.Specification

class CPNIContactInfoResourceImplTest extends Specification {
	
	def CPNIContactInfoResourceImplObj = new CPNIContactInfoResourceImpl()

	def queryCPNIAccountContactInfoServiceObj = Mock(QueryCPNIAccountContactInfoService)

	def queryCPNIAcccountInfoRequestValidatorObj = Mock(QueryCPNIAcccountContactInfoRequestValidator)

	def queryCPNIUserContactInfoServiceObj = Mock(QueryCPNIUserContactInfoService)

	def queryCPNIUserContactInfoRequestValidatorObj = Mock(QueryCPNIUserContactInfoRequestValidator)

	def httpHeadersMock = Stub(HttpHeaders)

    def FeatureManagerHelper featureManager = Mock();

	def queryCPNIAccountContactInfoRequest = new QueryCPNIAccountContactInfoRequest()

	def queryCPNIUserContactInfoRequest = new QueryCPNIUserContactInfoRequest()
	def cpniContactInfoService = Mock(CPNIContactInfoService)
	def cpniContactInfoRequestValidator = Mock(CPNIContactInfoRequestValidator)
	def httpHeaders = Mock(HttpHeaders)

	QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse = null
	QueryCPNIUserContactInfoResponse queryCPNIUserContactInfoResponse = null

	def setup() throws Exception {
		CPNIContactInfoResourceImplObj.queryCPNIAccountContactInfoService = queryCPNIAccountContactInfoServiceObj
		CPNIContactInfoResourceImplObj.queryCPNIAcccountInfoRequestValidator = queryCPNIAcccountInfoRequestValidatorObj
		CPNIContactInfoResourceImplObj.queryCPNIUserContactInfoService = queryCPNIUserContactInfoServiceObj
		CPNIContactInfoResourceImplObj.queryCPNIUserContactInfoRequestValidator = queryCPNIUserContactInfoRequestValidatorObj
		CPNIContactInfoResourceImplObj.cpniContactInfoService = cpniContactInfoService
		CPNIContactInfoResourceImplObj.cpniContactInfoRequestValidator = cpniContactInfoRequestValidator
        CPNIContactInfoResourceImplObj.featureManager = featureManager
	}

	def "test query c p n i account contact info success"() throws Exception {
		given:
		queryCPNIAccountContactInfoResponse = new QueryCPNIAccountContactInfoResponse()
		queryCPNIAccountContactInfoResponse.appCategoryCode = '0'
		queryCPNIAcccountInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(_ as HttpHeaders,
				_ as QueryCPNIAccountContactInfoRequest) >> null
		queryCPNIAccountContactInfoServiceObj.queryCPNIAccountContactInfo(_ as QueryCPNIAccountContactInfoRequest,
				_) >> queryCPNIAccountContactInfoResponse
		when:
		Response response = CPNIContactInfoResourceImplObj.queryCPNIAccountContactInfo(queryCPNIAccountContactInfoRequest, httpHeadersMock)
		then:
		response.status == 200
	}


	def "test query c p n i account contact info error from req validator"() throws Exception {
		given:
		queryCPNIAccountContactInfoResponse = new QueryCPNIAccountContactInfoResponse()
		queryCPNIAccountContactInfoResponse.appCategoryCode = '2'
		queryCPNIAcccountInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(_ as HttpHeaders,
				_ as QueryCPNIAccountContactInfoRequest) >> queryCPNIAccountContactInfoResponse
		when:
		Response response = CPNIContactInfoResourceImplObj.queryCPNIAccountContactInfo(queryCPNIAccountContactInfoRequest, httpHeadersMock)
		then:
		response.status == 500
	}


	def "test query c p n i account contact info error from generate p i n service"() throws Exception {
		given:
		queryCPNIAccountContactInfoResponse = new QueryCPNIAccountContactInfoResponse()
		queryCPNIAccountContactInfoResponse.appCategoryCode = '3'
		queryCPNIAccountContactInfoServiceObj.queryCPNIAccountContactInfo(_, _) >> queryCPNIAccountContactInfoResponse
		when:
		Response response = CPNIContactInfoResourceImplObj.queryCPNIAccountContactInfo(queryCPNIAccountContactInfoRequest, httpHeadersMock)
		then:
		response.status == 400
	}


	def "test query c p n i account contact info invalid input data exception"() throws Exception {
		given:
		InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
		queryCPNIAccountContactInfoServiceObj.queryCPNIAccountContactInfo(_, _) >> { throw ex }

		when:
		Response response = CPNIContactInfoResourceImplObj.queryCPNIAccountContactInfo(queryCPNIAccountContactInfoRequest, httpHeadersMock)

		then:
		thrown InvalidInputDataException
	}


	def "test query c p n i account contact info exception"() throws Exception {
		given:
		NullPointerException ex = new NullPointerException('NullPointerException thrown')
		queryCPNIAccountContactInfoServiceObj.queryCPNIAccountContactInfo(_, _) >> { throw ex }
		when:
		Response response = CPNIContactInfoResourceImplObj.queryCPNIAccountContactInfo(queryCPNIAccountContactInfoRequest, httpHeadersMock)
		then:
		response.status == 500
	}


	def "test query c p n i user contact info success"() throws Exception {
		given:
		queryCPNIUserContactInfoResponse = new QueryCPNIUserContactInfoResponse()
		queryCPNIUserContactInfoResponse.appCategoryCode = '0'
		queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(_ as HttpHeaders, _) >> null
		queryCPNIUserContactInfoServiceObj.queryCPNIUserContactInfo(_ as QueryCPNIUserContactInfoRequest,
				_) >> queryCPNIUserContactInfoResponse
		when:
		Response response = CPNIContactInfoResourceImplObj.queryCPNIUserContactInfo(queryCPNIUserContactInfoRequest, httpHeadersMock)
		then:
		response.status == 200
	}


	def "test query c p n i user contact info invalid input data exception"() throws Exception {
		given:
		InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
		queryCPNIUserContactInfoServiceObj.queryCPNIUserContactInfo(_, _) >> { throw ex }

		when:
		Response response = CPNIContactInfoResourceImplObj.queryCPNIUserContactInfo(queryCPNIUserContactInfoRequest, httpHeadersMock)

		then:
		thrown InvalidInputDataException
	}


	def "test query c p n i user contact info exception"() throws Exception {
		given:
		NullPointerException ex = new NullPointerException('NullPointerException thrown')
		queryCPNIUserContactInfoServiceObj.queryCPNIUserContactInfo(_, _) >> { throw ex }
		when:
		expect:
		Response response = CPNIContactInfoResourceImplObj.queryCPNIUserContactInfo(queryCPNIUserContactInfoRequest, httpHeadersMock)
	}

	// Test: cpniContactInfo - validator returns error response
	def "test cpniContactInfo returns error from validator"() {
		given:
		def errorResponse = new CPNIContactInfoResponse(appCategoryCode: '2')
		cpniContactInfoRequestValidator.cpniContactInfoRequestValidator(_) >> errorResponse
		httpHeaders.getRequestHeaders() >> [:]

		when:
		def response = CPNIContactInfoResourceImplObj.cpniContactInfo(httpHeaders)

		then:
		response.status == 500
	}

// Test: cpniContactInfo - service returns valid response
	def "test cpniContactInfo returns success from service"() {
		given:
		cpniContactInfoRequestValidator.cpniContactInfoRequestValidator(_) >> null
        def serviceResponse = new CPNIContactInfoResponse(appCategoryCode: '0')
		cpniContactInfoService.cpniContactInfo(_) >> serviceResponse
		httpHeaders.getRequestHeaders() >> new MultivaluedHashMap<>()

		when:
		def response = CPNIContactInfoResourceImplObj.cpniContactInfo(httpHeaders)

		then:
		response.status == 200
	}

    def "test cpniContactInfo returns success from service along with individualId"() {
        given:
        cpniContactInfoRequestValidator.cpniContactInfoRequestValidator(_) >> null
        featureManager.isEnabled("svc-idgraph-cpnicontactinfo-enable-individualid-in-response") >> true

        def serviceResponse = new CPNIContactInfoResponse(appCategoryCode: '0')
        cpniContactInfoService.cpniContactInfo(_) >> serviceResponse
        httpHeaders.getRequestHeaders() >> new MultivaluedHashMap<>()

        when:
        def response = CPNIContactInfoResourceImplObj.cpniContactInfo(httpHeaders)

        then:
        response.status == 200
    }

// Test: cpniContactInfo - service throws ServiceException
	def "test cpniContactInfo handles ServiceException"() {
		given:
		cpniContactInfoRequestValidator.cpniContactInfoRequestValidator(_ as HttpHeaders) >> null
		httpHeaders.getRequestHeaders() >> new MultivaluedHashMap<>()
		httpHeaders.getHeaderString("idp-trace-id") >> "trace"
		ServiceException ex = new ServiceException(ErrorMessages.MS_MPSYS_BE_363,"data not found")
		cpniContactInfoService.cpniContactInfo(_ as MultivaluedMap<String, String>) >> { throw ex }

		when:
		def response = CPNIContactInfoResourceImplObj.cpniContactInfo(httpHeaders)

		then:
		response.status == 404
		def entity = response.entity as CPNIContactInfoResponse
		entity.idpTraceId == "trace"
	}

// Test: cpniContactInfo - service throws generic Exception
	def "test cpniContactInfo handles generic Exception"() {
		given:
		cpniContactInfoRequestValidator.cpniContactInfoRequestValidator(_) >> null
		cpniContactInfoService.cpniContactInfo(_) >> { throw new RuntimeException("fail") }
		httpHeaders.getRequestHeaders() >> new MultivaluedHashMap<>()
		httpHeaders.getHeaderString("idp-trace-id") >> "trace"

		when:
		def response = CPNIContactInfoResourceImplObj.cpniContactInfo(httpHeaders)

		then:
		response.status == 500
		def entity = response.entity
		entity != null
	}

// Test: queryCPNIAccountContactInfo - SQLException as root cause
	def "test queryCPNIAccountContactInfo handles SQLException root cause"() {
		given:
		def ex = new Exception(new java.sql.SQLException("db error"))
		queryCPNIAcccountInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(_, _) >> null
		queryCPNIAccountContactInfoServiceObj.queryCPNIAccountContactInfo(_, _) >> { throw ex }
		httpHeaders.getRequestHeaders() >> new MultivaluedHashMap<>()

		when:
		def response = CPNIContactInfoResourceImplObj.queryCPNIAccountContactInfo(queryCPNIAccountContactInfoRequest, httpHeaders)

		then:
		response.status == 500
	}

// Test: queryCPNIUserContactInfo - SQLException as root cause
	def "test queryCPNIUserContactInfo handles SQLException root cause"() {
		given:
		def ex = new Exception(new java.sql.SQLException("db error"))
		queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(_, _) >> null
		queryCPNIUserContactInfoServiceObj.queryCPNIUserContactInfo(_, _) >> { throw ex }
		httpHeaders.getRequestHeaders() >> new MultivaluedHashMap<>()

		when:
		def response = CPNIContactInfoResourceImplObj.queryCPNIUserContactInfo(queryCPNIUserContactInfoRequest, httpHeaders)

		then:
		response.status == 500
	}



}
