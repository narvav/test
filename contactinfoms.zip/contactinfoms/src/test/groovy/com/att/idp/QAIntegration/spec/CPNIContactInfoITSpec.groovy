package com.att.idp.QAIntegration.spec

import com.att.idp.QAIntegration.Base.TestBase
import com.att.idp.QAIntegration.Config.ContactInfoGlobalConfig
import com.att.idp.QAIntegration.Helpers.ContactInfoMsApiHelpers
import groovy.util.logging.Slf4j
import io.restassured.response.Response
import spock.lang.IgnoreIf
import spock.lang.Shared
import spock.lang.Tag
import spock.lang.Unroll

/**
 * QG7 Integration Test — CPNI Contact Info API
 *
 * Tests for:
 * - POST /cpniContactInfo/account — Query CPNI Account Contact Info
 * - POST /cpniContactInfo/user    — Query CPNI User Contact Info
 *
 * YAML-driven: reads test data from QATestData/{ENV}/IDGraphContactInfoMs_TestData.yaml
 *
 * OMNI Compliance:
 * - Spec suffix: *ITSpec.groovy (testing-foundation.md E1)
 * - then: 0 * _ mandatory (HS-8)
 * - No mocks — real HTTP calls to deployed service
 */
@Slf4j
@Tag("Regression")
@Tag("CPNI")
@Tag("IDGraphContactInfoMs")
@IgnoreIf({ !ContactInfoGlobalConfig.isTestCaseEnabled("CPNIContactInfoITSpec") })
class CPNIContactInfoITSpec extends TestBase {

    @Shared
    Map testData = ContactInfoGlobalConfig.getTestData()

    @Shared
    List<Map> cpniAccountPositive = (testData?.get("cpniAccountPositive") as List<Map>) ?: []

    @Shared
    List<Map> cpniAccountNegative = (testData?.get("cpniAccountNegative") as List<Map>) ?: []

    @Shared
    List<Map> cpniUserPositive = (testData?.get("cpniUserPositive") as List<Map>) ?: []

    @Shared
    List<Map> cpniUserNegative = (testData?.get("cpniUserNegative") as List<Map>) ?: []

    // ═══════════════════════════════════════════════════════════════════════════
    // CPNI Account Contact Info — Positive Tests
    // ═══════════════════════════════════════════════════════════════════════════

    @Unroll("CPNI Account Positive — #tc.testCaseName")
    def "CPNI Account Contact Info — Positive Tests"() {
        setup:
        TestBase.setTestName(tc.testCaseName as String)
        TestBase.logStep("POST ${ContactInfoGlobalConfig.Endpoints.CPNI_CONTACT_INFO_ACCOUNT}")

        when: "POST CPNI Account Contact Info is called"
        Response response = ContactInfoMsApiHelpers.cpniContactInfoAccount(tc as Map)

        then: "No mock interactions"
        0 * _

        and: "Response status matches expected"
        int expectedStatus = (tc.expectedStatus ?: 200) as int
        assert response.statusCode() == expectedStatus :
                "Expected ${expectedStatus} but got ${response.statusCode()}. Body: ${response.body().asString().take(500)}"

        where:
        tc << cpniAccountPositive
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CPNI Account Contact Info — Negative Tests
    // ═══════════════════════════════════════════════════════════════════════════

    @Unroll("CPNI Account Negative — #tc.testCaseName")
    def "CPNI Account Contact Info — Negative Tests"() {
        setup:
        setTestName(tc.testCaseName as String)
        logStep("POST ${ContactInfoGlobalConfig.Endpoints.CPNI_CONTACT_INFO_ACCOUNT} (expecting 400)")

        when: "POST CPNI Account Contact Info is called with invalid data"
        Response response = ContactInfoMsApiHelpers.cpniContactInfoAccount(tc as Map)

        then: "No mock interactions"
        0 * _

        and: "Response status matches expected (400 for negative cases)"
        int expectedStatus = (tc.expectedStatus ?: 400) as int
        assert response.statusCode() == expectedStatus :
                "Expected ${expectedStatus} but got ${response.statusCode()}. Body: ${response.body().asString().take(500)}"

        where:
        tc << cpniAccountNegative
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CPNI User Contact Info — Positive Tests
    // ═══════════════════════════════════════════════════════════════════════════

    @Unroll("CPNI User Positive — #tc.testCaseName")
    def "CPNI User Contact Info — Positive Tests"() {
        setup:
        setTestName(tc.testCaseName as String)
        logStep("POST ${ContactInfoGlobalConfig.Endpoints.CPNI_CONTACT_INFO_USER}")

        when: "POST CPNI User Contact Info is called"
        Response response = ContactInfoMsApiHelpers.cpniContactInfoUser(tc as Map)

        then: "No mock interactions"
        0 * _

        and: "Response status matches expected"
        int expectedStatus = (tc.expectedStatus ?: 200) as int
        assert response.statusCode() == expectedStatus :
                "Expected ${expectedStatus} but got ${response.statusCode()}. Body: ${response.body().asString().take(500)}"

        where:
        tc << cpniUserPositive
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CPNI User Contact Info — Negative Tests
    // ═══════════════════════════════════════════════════════════════════════════

    @Unroll("CPNI User Negative — #tc.testCaseName")
    def "CPNI User Contact Info — Negative Tests"() {
        setup:
        setTestName(tc.testCaseName as String)
        logStep("POST ${ContactInfoGlobalConfig.Endpoints.CPNI_CONTACT_INFO_USER} (expecting 400)")

        when: "POST CPNI User Contact Info is called with invalid data"
        Response response = ContactInfoMsApiHelpers.cpniContactInfoUser(tc as Map)

        then: "No mock interactions"
        0 * _

        and: "Response status matches expected (400 for negative cases)"
        int expectedStatus = (tc.expectedStatus ?: 400) as int
        assert response.statusCode() == expectedStatus :
                "Expected ${expectedStatus} but got ${response.statusCode()}. Body: ${response.body().asString().take(500)}"

        where:
        tc << cpniUserNegative
    }
}
