package com.att.idp.idgraphcontactinfoms.helpers

import com.att.idp.idgraph.db.cosmos.helper.IdgOtpDBHelper
import com.att.idp.idgraph.db.cosmos.helper.OtpHistoryDBHelper
import java.util.concurrent.Executor
import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import org.mockito.Mock
import org.springframework.beans.factory.BeanFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import spock.lang.Ignore


class GeneratePINHelperTest extends Specification {

    def GeneratePINHelper generatePINHelperObj = new GeneratePINHelper()
    GeneratePINBase generatePINBaseObj
    BeanFactory objGeneratePINBaseFactory = Mock(BeanFactory)
    DeletePINHelper objDeletePINHelper_Mock = Mock(DeletePINHelper)
    FeatureManagerHelper featureManager = Mock(FeatureManagerHelper)

    HashMap hmInput = new HashMap()
    HashMap<String, Object> getInfoResp = new HashMap<String, Object>()
    HashMap<String, Object> getInfoResp1 = new HashMap<String, Object>()
    HashMap<String, Object> resultHashSuccess = null
    HashMap<String, Object> hmInpDeliveryMethods = new HashMap<String, Object>()
    HashMap<String, Object> hmEmailDetails = new HashMap<String, Object>()
    // HashMap hmInpDeliveryMethods = (HashMap) hmInput.get(CommonDefs.DELIVERY_METHODS);
    String transId = 'test123'
    Map hmResponse = null
    ArrayList alDbusInp = new ArrayList()
    HashMap hmUser = new HashMap()


    def setup() {
        resultHashSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
                CErrorDefs.COMMON_SUCCESS_MSG)
        
        def otpHistoryDBHelper = Mock(OtpHistoryDBHelper)
        def otpHistoryExecutor = { Runnable r -> r.run() } as Executor
        generatePINBaseObj = Spy(new GeneratePINBase(otpHistoryDBHelper, otpHistoryExecutor))
        generatePINBaseObj.featureManager = featureManager
        
        generatePINHelperObj.objGeneratePINBaseFactory = objGeneratePINBaseFactory
        generatePINHelperObj.deletePinHelper = objDeletePINHelper_Mock
        generatePINHelperObj.featureManager = featureManager
        objGeneratePINBaseFactory.getBean("generatePINBase") >> generatePINBaseObj
        hmInput[CommonDefs.TRANSACTION_ID] = transId
        hmInput[CommonDefs.TRANSACTION_NAME] = 'GeneratePIN'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.ACCOUNT_ID] = '000968523'
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'IDSEMOB'
        hmInput[CommonDefs.BROWSER_LANGUAGE] = 'en'
        hmInput[CommonDefs.RETURN_SECURITY_CODE] = 'Y'
        hmInput[CommonDefs.AGENT_ID] = 'abc123'
        hmInput[CommonDefs.RES_BUS_IND] = 'R'
        hmEmailDetails[CommonDefs.EMAIL_ADDRESS] = 'abc@gmail.com'
        hmInpDeliveryMethods.put(CommonDefs.EMAIL, hmEmailDetails)


        alDbusInp.add(null)

        ReflectionTestUtils.setField(generatePINHelperObj, "propDeletePreviousPinCSI", "PORTOUT:AVERTACK")
        ReflectionTestUtils.setField(generatePINHelperObj, "sCCMuleIdentificationTypes", "BSSEOTP|BSSEONL|BSSEREGOTP")

        when:
        getInfoResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        getInfoResp[CommonDefs.CONSOLIDATED_DBUS_INPUT] = alDbusInp
        getInfoResp[CommonDefs.SECURITY_CODE] = 'SECURITY_CODE'
        getInfoResp[CommonDefs.SECURITY_PIN_EXPIRATION_DATE] = 'SECURITY_PIN_EXPIRATION_DATE'

        getInfoResp1 = CommonErrorMap.makeCategoryMap(3, CErrorDefs.CATEGORY_CODE_DATA_ERROR)
    }


    def "test input data"() {
        given:
        generatePINBaseObj.generateOTPWithLockoutCheck() >> getInfoResp1
        generatePINBaseObj.validateSecurityCodeData()>>resultHashSuccess
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == '3'
    }


    def "test generate pin process input data"() {
        given:
        generatePINBaseObj.generateOTPWithLockoutCheck() >> getInfoResp1
        generatePINBaseObj.validateSecurityCodeData()>>resultHashSuccess
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == '3'
    }


    def "test generate pin store mps data"() {
        given:
        generatePINBaseObj.storeMPSData() >> getInfoResp1
        generatePINBaseObj.validateSecurityCodeData()>>resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck()>>resultHashSuccess

        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == '3'
        hmResponse['isTransactionRollback'] == 'Y'
    }


    def "test generate pin store mps data success"() {
        given:
        generatePINBaseObj.storeMPSData() >> getInfoResp
        generatePINBaseObj.validateSecurityCodeData()>>resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck()>>resultHashSuccess
        generatePINBaseObj.prepareDataForAsyncCall() >> getInfoResp
        generatePINBaseObj.makeAsyncCall(_) >> getInfoResp
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }


    def "test generate pin prepare data for async call"() {
        given:
        generatePINBaseObj.prepareDataForAsyncCall() >> getInfoResp1
        generatePINBaseObj.storeMPSData() >> getInfoResp
        generatePINBaseObj.validateSecurityCodeData()>>resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck()>>resultHashSuccess
        //generatePINBaseObj.prepareDataForAsyncCall()>>resultHashSuccess
        generatePINBaseObj.makeAsyncCall(_)>>resultHashSuccess
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == '3'
    }


    def "test generate pin make async call"() {
        given:
        generatePINBaseObj.prepareDataForAsyncCall() >> getInfoResp
        generatePINBaseObj.makeAsyncCall(alDbusInp) >> getInfoResp1
        generatePINBaseObj.storeMPSData() >> getInfoResp
        generatePINBaseObj.validateSecurityCodeData()>>resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck()>>resultHashSuccess
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == '3'
        hmResponse['isTransactionRollback'] == 'Y'
    }


    def "test generate pin make async call success"() {
        given:
        generatePINBaseObj.prepareDataForAsyncCall() >> getInfoResp
        generatePINBaseObj.makeAsyncCall(alDbusInp) >> getInfoResp
        generatePINBaseObj.storeMPSData() >> getInfoResp
        generatePINBaseObj.validateSecurityCodeData()>>resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck()>>resultHashSuccess
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }


    def "test generate pin make async call null"() {
        given:
        generatePINBaseObj.prepareDataForAsyncCall() >> getInfoResp
        generatePINBaseObj.makeAsyncCall(alDbusInp) >> null
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.ERR_SYS_APPL
    }


    def "test generate pin make c c mule sync call"() {
        given:
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'BSSEOTP'
        hmInput[CommonDefs.DELIVERY_METHODS] = hmInpDeliveryMethods
        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        HashMap prepareSync = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'OK')
        prepareSync[CommonDefs.COMMUNICATION_NOTIFICATION] = [[channel: 'EMAIL']]
        HashMap syncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        syncResp[CommonDefs.SECURITY_CODE] = '123456'
        syncResp[CommonDefs.SECURITY_PIN_EXPIRATION_DATE] = '20260107T120000'
        generatePINBaseObj.prepareDataForCCMuleSyncCall() >> prepareSync
        generatePINBaseObj.makeCCMuleSyncCall(_) >> syncResp
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }


    def "test delete security pin for portout"() {
        given:
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'AVERTACK'
        hmInput[CommonDefs.ACCOUNT_ID] = '000968523'
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'PORTOUT'
        hmInput[CommonDefs.SOURCE_IP_ADDRESS] = '10.12.13.223'

        HashMap hmDeletePinInp = [
                (CommonDefs.TRANSACTION_NAME): 'DeletePIN',
                (CommonDefs.TRANSACTION_ID): hmInput[CommonDefs.TRANSACTION_ID],
                (CommonDefs.ACCOUNT_ID): hmInput[CommonDefs.ACCOUNT_ID],
                (CommonDefs.IDENTIFICATION_TYPE): hmInput[CommonDefs.IDENTIFICATION_TYPE],
                (CommonDefs.CALLING_SYSTEM_ID): hmInput[CommonDefs.CALLING_SYSTEM_ID],
                (CommonDefs.DELETE_All): CommonDefs.IND_Y,
                (CommonDefs.AGENT_ID): hmInput[CommonDefs.AGENT_ID],
                (CommonDefs.SOURCE_IP_ADDRESS): hmInput[CommonDefs.SOURCE_IP_ADDRESS]
        ]

        hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj
        objDeletePINHelper_Mock.deletePin(hmDeletePinInp) >> hmResponse
        generatePINBaseObj.storeMPSData() >> getInfoResp
        generatePINBaseObj.validateSecurityCodeData()>>resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck()>>resultHashSuccess
        generatePINBaseObj.prepareDataForAsyncCall() >> resultHashSuccess
        generatePINBaseObj.makeAsyncCall(_) >> resultHashSuccess

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }


    def "test generate pin prepare data for c c mule sync call error case"() {
        given:
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'BSSEOTP'
        hmInput[CommonDefs.DELIVERY_METHODS] = hmInpDeliveryMethods
        generatePINBaseObj.prepareDataForCCMuleSyncCall() >> null
        generatePINBaseObj.storeMPSData() >> getInfoResp
        generatePINBaseObj.validateSecurityCodeData()>>resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck()>>resultHashSuccess
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_INFO] == 'Null Response returned from prepareDataForCCMuleSyncCall'
    }


    def "test generate pin make c c mule sync call error case null"() {
        given:
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'BSSEOTP'
        hmInput[CommonDefs.DELIVERY_METHODS] = hmInpDeliveryMethods
        generatePINBaseObj.prepareDataForCCMuleSyncCall() >> getInfoResp
        generatePINBaseObj.storeMPSData() >> getInfoResp
        generatePINBaseObj.validateSecurityCodeData()>>resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck()>>resultHashSuccess
        generatePINBaseObj.makeCCMuleSyncCall(null) >> null
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_INFO] == 'Null Response returned by makeCCMuleSyncCall'
    }


    def "test generate pin delete pin helper error"() {
        given:
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'AVERTACK'
        hmInput[CommonDefs.ACCOUNT_ID] = '000968523'
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'PORTOUT'
        hmInput[CommonDefs.SOURCE_IP_ADDRESS] = '10.12.13.223'

        hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, 'Error')
        objDeletePINHelper_Mock.deletePin(_) >> hmResponse
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse != null
    }


    def "test generate pin validate security code data"() {
        given:
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj
        generatePINBaseObj.validateSecurityCodeData() >> getInfoResp1

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == '3'
    }


    def "test generate pin s c c mule identification types"() {
        given:
        generatePINHelperObj.sCCMuleIdentificationTypes = null
        generatePINBaseObj.prepareDataForCCMuleSyncCall() >> getInfoResp
        generatePINBaseObj.storeMPSData() >> getInfoResp
        generatePINBaseObj.validateSecurityCodeData()>>resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck()>>resultHashSuccess

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        _* objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.ERR_CONFIG
    }

    def "test generate pin store mps data rollback flag"() {
        given:
        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        HashMap<String,Object> storeError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, 'StoreFail')
        generatePINBaseObj.storeMPSData() >> storeError
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.ERR_SYS_APPL
    }

    def "test generate pin async call rollback flag"() {
        given:
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'NOTINCC'
        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        generatePINBaseObj.prepareDataForAsyncCall() >> getInfoResp
        // simulate async error
        generatePINBaseObj.makeAsyncCall(_) >> getInfoResp1
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == '3'
        hmResponse['isTransactionRollback'] == 'Y'
    }

    def "test generate pin AEH generic OTP path success"() {
        given:
        ReflectionTestUtils.setField(generatePINHelperObj, 'sAEHGENERICOTPIdentificationTypes', 'GENOTP|GEN2')
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'GENOTP'
        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        HashMap asyncPrep = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        asyncPrep[CommonDefs.CONSOLIDATED_DBUS_INPUT] = [[:]]
        generatePINBaseObj.prepareDataForAsyncCall() >> asyncPrep
        generatePINBaseObj.makeAsyncCall(_) >> resultHashSuccess
        generatePINBaseObj.makeGenericOTPAEHCall(hmInput) >> resultHashSuccess
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    def "test generate pin return security code flag N"() {
        given:
        hmInput[CommonDefs.RETURN_SECURITY_CODE] = 'N'
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'GENOTP'
        ReflectionTestUtils.setField(generatePINHelperObj, 'sAEHGENERICOTPIdentificationTypes', 'GENOTP')
        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        HashMap asyncPrep = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        asyncPrep[CommonDefs.CONSOLIDATED_DBUS_INPUT] = [[:]]
        generatePINBaseObj.prepareDataForAsyncCall() >> asyncPrep
        generatePINBaseObj.makeAsyncCall(_) >> resultHashSuccess
        generatePINBaseObj.makeGenericOTPAEHCall(hmInput) >> resultHashSuccess
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    def "test generate pin c c mule sync call error status"() {
        given:
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'BSSEOTP'
        hmInput[CommonDefs.DELIVERY_METHODS] = hmInpDeliveryMethods
        HashMap prepareSync = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'OK')
        prepareSync[CommonDefs.COMMUNICATION_NOTIFICATION] = [[channel:'EMAIL']]
        HashMap syncError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, 'SyncFail')
        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        generatePINBaseObj.prepareDataForCCMuleSyncCall() >> prepareSync
        generatePINBaseObj.makeCCMuleSyncCall(_) >> syncError
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == Integer.toString(CErrorDefs.ERR_INVALID_DATA_NUM)
    }

    def "test generate pin c c mule skip delivery methods still success"() {
        given:
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'BSSEOTP'
        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }


    def "test CSIGATEWAY sets SECURITY_CODE_EXPIRES to first 8 chars"() {
        given:
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'CSIGATEWAY'
        // returning success throughout async path
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj
        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        HashMap<String, Object> asyncPrep = new HashMap<>()
        asyncPrep[CommonDefs.COMMON_APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        asyncPrep[CommonDefs.CONSOLIDATED_DBUS_INPUT] = alDbusInp
        generatePINBaseObj.prepareDataForAsyncCall() >> asyncPrep
        HashMap<String, Object> asyncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        asyncResp[CommonDefs.SECURITY_CODE] = '123456'
        asyncResp[CommonDefs.SECURITY_PIN_EXPIRATION_DATE] = '20260107T120000'
        generatePINBaseObj.makeAsyncCall(alDbusInp) >> asyncResp

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        hmResponse[CommonDefs.SECURITY_CODE_EXPIRES] == '20260107'
    }

    // ============================================================
    // OTP EDD to CLM feature flag tests
    // ============================================================

    def "test generate pin with OTP EDD to CLM enabled uses CLM identification types"() {
        given:
        generatePINHelperObj.featureManager = featureManager
        ReflectionTestUtils.setField(generatePINHelperObj, 'sCCMuleIdentificationTypesClm', 'BSSEOTP|CLMTYPE')
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'BSSEOTP'
        hmInput[CommonDefs.DELIVERY_METHODS] = hmInpDeliveryMethods
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> true
        featureManager.isEnabled("svc-idgraph-contactinfoms-csigateway-return-securitycode") >> false

        HashMap prepareSync = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'OK')
        prepareSync[CommonDefs.COMMUNICATION_NOTIFICATION] = [['channel': 'EMAIL']]
        HashMap syncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        syncResp[CommonDefs.SECURITY_CODE] = '999888'
        syncResp[CommonDefs.SECURITY_PIN_EXPIRATION_DATE] = '20260401T120000'

        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        generatePINBaseObj.prepareDataForCCMuleSyncCall() >> prepareSync
        generatePINBaseObj.makeCCMuleSyncCall(_) >> syncResp
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    // ============================================================
    // CSIGATEWAY security code return and expiry tests
    // ============================================================

    def "test CSIGATEWAY with returnSecurityCode enabled returns security code"() {
        given:
        generatePINHelperObj.featureManager = featureManager
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'CSIGATEWAY'
        hmInput[CommonDefs.RETURN_SECURITY_CODE] = 'N'
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        featureManager.isEnabled("svc-idgraph-contactinfoms-csigateway-return-securitycode") >> true

        HashMap asyncPrep = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        asyncPrep[CommonDefs.CONSOLIDATED_DBUS_INPUT] = alDbusInp
        HashMap asyncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        asyncResp[CommonDefs.SECURITY_CODE] = '123456'
        asyncResp[CommonDefs.SECURITY_PIN_EXPIRATION_DATE] = '20260107T120000'

        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        generatePINBaseObj.prepareDataForAsyncCall() >> asyncPrep
        generatePINBaseObj.makeAsyncCall(_) >> asyncResp
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        hmResponse[CommonDefs.SECURITY_CODE] == '123456'
        hmResponse[CommonDefs.SECURITY_CODE_EXPIRES] == '20260107'
    }

    def "test CSIGATEWAY with short expiry date does not truncate"() {
        given:
        generatePINHelperObj.featureManager = featureManager
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'CSIGATEWAY'
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        featureManager.isEnabled("svc-idgraph-contactinfoms-csigateway-return-securitycode") >> false

        HashMap asyncPrep = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        asyncPrep[CommonDefs.CONSOLIDATED_DBUS_INPUT] = alDbusInp
        HashMap asyncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        asyncResp[CommonDefs.SECURITY_CODE] = '123456'
        asyncResp[CommonDefs.SECURITY_PIN_EXPIRATION_DATE] = 'SHORT'

        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        generatePINBaseObj.prepareDataForAsyncCall() >> asyncPrep
        generatePINBaseObj.makeAsyncCall(_) >> asyncResp
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        !hmResponse.containsKey(CommonDefs.SECURITY_CODE_EXPIRES)
    }

    def "test CSIGATEWAY with null expiry date"() {
        given:
        generatePINHelperObj.featureManager = featureManager
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'CSIGATEWAY'
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        featureManager.isEnabled("svc-idgraph-contactinfoms-csigateway-return-securitycode") >> false

        HashMap asyncPrep = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        asyncPrep[CommonDefs.CONSOLIDATED_DBUS_INPUT] = alDbusInp
        HashMap asyncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        asyncResp[CommonDefs.SECURITY_CODE] = '123456'
        asyncResp[CommonDefs.SECURITY_PIN_EXPIRATION_DATE] = null

        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        generatePINBaseObj.prepareDataForAsyncCall() >> asyncPrep
        generatePINBaseObj.makeAsyncCall(_) >> asyncResp
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    def "test non-CSIGATEWAY caller always gets security code expires"() {
        given:
        generatePINHelperObj.featureManager = featureManager
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.RETURN_SECURITY_CODE] = 'Y'
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        featureManager.isEnabled("svc-idgraph-contactinfoms-csigateway-return-securitycode") >> false

        HashMap asyncPrep = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        asyncPrep[CommonDefs.CONSOLIDATED_DBUS_INPUT] = alDbusInp
        HashMap asyncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        asyncResp[CommonDefs.SECURITY_CODE] = '654321'
        asyncResp[CommonDefs.SECURITY_PIN_EXPIRATION_DATE] = '20260401T235959'

        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        generatePINBaseObj.prepareDataForAsyncCall() >> asyncPrep
        generatePINBaseObj.makeAsyncCall(_) >> asyncResp
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        hmResponse[CommonDefs.SECURITY_CODE] == '654321'
        hmResponse[CommonDefs.SECURITY_CODE_EXPIRES] == '20260401T235959'
    }

    // ============================================================
    // CCMule sync call with null appStatusCode
    // ============================================================

    def "test CCMule sync call returns response with null status code"() {
        given:
        generatePINHelperObj.featureManager = featureManager
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'BSSEOTP'
        hmInput[CommonDefs.DELIVERY_METHODS] = hmInpDeliveryMethods
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false

        HashMap prepareSync = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'OK')
        prepareSync[CommonDefs.COMMUNICATION_NOTIFICATION] = [['channel': 'EMAIL']]
        HashMap syncResp = new HashMap()

        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        generatePINBaseObj.prepareDataForCCMuleSyncCall() >> prepareSync
        generatePINBaseObj.makeCCMuleSyncCall(_) >> syncResp
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_INFO] == 'Null Response returned by makeCCMuleSyncCall'
    }

    def "test CCMule sync call prepare data returns non-success"() {
        given:
        generatePINHelperObj.featureManager = featureManager
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'BSSEOTP'
        hmInput[CommonDefs.DELIVERY_METHODS] = hmInpDeliveryMethods
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false

        HashMap prepareError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, 'PrepFail')

        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        generatePINBaseObj.prepareDataForCCMuleSyncCall() >> prepareError
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_INFO] == 'PrepFail'
    }

    def "test CCMule sync call success sets rollback and returns security code"() {
        given:
        generatePINHelperObj.featureManager = featureManager
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'BSSEOTP'
        hmInput[CommonDefs.DELIVERY_METHODS] = hmInpDeliveryMethods
        hmInput[CommonDefs.RETURN_SECURITY_CODE] = 'Y'
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        featureManager.isEnabled("svc-idgraph-contactinfoms-csigateway-return-securitycode") >> false

        HashMap prepareSync = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'OK')
        prepareSync[CommonDefs.COMMUNICATION_NOTIFICATION] = [['channel': 'EMAIL']]
        HashMap syncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        syncResp[CommonDefs.SECURITY_CODE] = '112233'
        syncResp[CommonDefs.SECURITY_PIN_EXPIRATION_DATE] = '20260401T120000'

        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        generatePINBaseObj.prepareDataForCCMuleSyncCall() >> prepareSync
        generatePINBaseObj.makeCCMuleSyncCall(_) >> syncResp
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        hmResponse[CommonDefs.SECURITY_CODE] == '112233'
    }

    // ============================================================
    // AEH generic OTP null response
    // ============================================================

    def "test AEH generic OTP call returns null"() {
        given:
        generatePINHelperObj.featureManager = featureManager
        ReflectionTestUtils.setField(generatePINHelperObj, 'sAEHGENERICOTPIdentificationTypes', 'GENOTP')
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'GENOTP'
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false

        HashMap asyncPrep = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        asyncPrep[CommonDefs.CONSOLIDATED_DBUS_INPUT] = [[:]]

        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        generatePINBaseObj.prepareDataForAsyncCall() >> asyncPrep
        generatePINBaseObj.makeAsyncCall(_) >> resultHashSuccess
        generatePINBaseObj.makeGenericOTPAEHCall(_) >> null
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_INFO] == 'Null Response returned by makeGenericOTPAEHCall'
    }

    // ============================================================
    // Delete previous PIN success paths
    // ============================================================

    def "test delete previous pin success continues to generate"() {
        given:
        generatePINHelperObj.featureManager = featureManager
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'AVERTACK'
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'PORTOUT'
        hmInput[CommonDefs.SOURCE_IP_ADDRESS] = '10.12.13.223'
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        featureManager.isEnabled("svc-idgraph-contactinfoms-csigateway-return-securitycode") >> false

        HashMap deleteResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        HashMap asyncPrep = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        asyncPrep[CommonDefs.CONSOLIDATED_DBUS_INPUT] = alDbusInp
        HashMap asyncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        asyncResp[CommonDefs.SECURITY_CODE] = '777888'
        asyncResp[CommonDefs.SECURITY_PIN_EXPIRATION_DATE] = '20260401T120000'

        objDeletePINHelper_Mock.deletePin(_) >> deleteResp
        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        generatePINBaseObj.prepareDataForAsyncCall() >> asyncPrep
        generatePINBaseObj.makeAsyncCall(_) >> asyncResp
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    def "test delete previous pin without sourceIPAddress"() {
        given:
        generatePINHelperObj.featureManager = featureManager
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'AVERTACK'
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'PORTOUT'
        hmInput.remove(CommonDefs.SOURCE_IP_ADDRESS)
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        featureManager.isEnabled("svc-idgraph-contactinfoms-csigateway-return-securitycode") >> false

        HashMap deleteResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        HashMap asyncPrep = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        asyncPrep[CommonDefs.CONSOLIDATED_DBUS_INPUT] = alDbusInp
        HashMap asyncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        asyncResp[CommonDefs.SECURITY_CODE] = '777888'
        asyncResp[CommonDefs.SECURITY_PIN_EXPIRATION_DATE] = '20260401T120000'

        objDeletePINHelper_Mock.deletePin(_) >> deleteResp
        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        generatePINBaseObj.prepareDataForAsyncCall() >> asyncPrep
        generatePINBaseObj.makeAsyncCall(_) >> asyncResp
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    def "test delete previous pin with empty sourceIPAddress"() {
        given:
        generatePINHelperObj.featureManager = featureManager
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'AVERTACK'
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'PORTOUT'
        hmInput[CommonDefs.SOURCE_IP_ADDRESS] = ''
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        featureManager.isEnabled("svc-idgraph-contactinfoms-csigateway-return-securitycode") >> false

        HashMap deleteResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        HashMap asyncPrep = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        asyncPrep[CommonDefs.CONSOLIDATED_DBUS_INPUT] = alDbusInp
        HashMap asyncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        asyncResp[CommonDefs.SECURITY_CODE] = '777888'
        asyncResp[CommonDefs.SECURITY_PIN_EXPIRATION_DATE] = '20260401T120000'

        objDeletePINHelper_Mock.deletePin(_) >> deleteResp
        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        generatePINBaseObj.prepareDataForAsyncCall() >> asyncPrep
        generatePINBaseObj.makeAsyncCall(_) >> asyncResp
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    // ============================================================
    // CCMule skip delivery with returnSecurityCode
    // ============================================================

    def "test CCMule identification type but null delivery methods with returnSecurityCode Y"() {
        given:
        generatePINHelperObj.featureManager = featureManager
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'BSSEOTP'
        hmInput[CommonDefs.RETURN_SECURITY_CODE] = 'Y'
        hmInput.remove(CommonDefs.DELIVERY_METHODS)
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        featureManager.isEnabled("svc-idgraph-contactinfoms-csigateway-return-securitycode") >> false

        HashMap storeResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        storeResp[CommonDefs.SECURITY_CODE] = '445566'
        storeResp[CommonDefs.SECURITY_PIN_EXPIRATION_DATE] = '20260401T120000'

        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> storeResp
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    // ============================================================
    // sCCMuleIdentificationTypes empty string
    // ============================================================

    def "test generate pin sCCMuleIdentificationTypes empty returns config error"() {
        given:
        generatePINHelperObj.featureManager = featureManager
        ReflectionTestUtils.setField(generatePINHelperObj, 'sCCMuleIdentificationTypes', '')
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false

        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_INFO] == 'PROP_CCMULE_IDENTIFICATION_TYPES is null or empty'
    }

    // ============================================================
    // sAEHGENERICOTPIdentificationTypes null path
    // ============================================================

    def "test generate pin with null AEH identification types skips AEH call"() {
        given:
        generatePINHelperObj.featureManager = featureManager
        ReflectionTestUtils.setField(generatePINHelperObj, 'sAEHGENERICOTPIdentificationTypes', null)
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        featureManager.isEnabled("svc-idgraph-contactinfoms-csigateway-return-securitycode") >> false

        HashMap asyncPrep = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        asyncPrep[CommonDefs.CONSOLIDATED_DBUS_INPUT] = alDbusInp
        HashMap asyncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        asyncResp[CommonDefs.SECURITY_CODE] = '111222'
        asyncResp[CommonDefs.SECURITY_PIN_EXPIRATION_DATE] = '20260401T120000'

        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        generatePINBaseObj.prepareDataForAsyncCall() >> asyncPrep
        generatePINBaseObj.makeAsyncCall(_) >> asyncResp
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        0 * generatePINBaseObj.makeGenericOTPAEHCall(_)
    }

    def "test generate pin with null callingSystemId"() {
        given:
        generatePINHelperObj.featureManager = featureManager
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = null
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
        featureManager.isEnabled("svc-idgraph-contactinfoms-csigateway-return-securitycode") >> false

        HashMap asyncPrep = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        asyncPrep[CommonDefs.CONSOLIDATED_DBUS_INPUT] = alDbusInp
        HashMap asyncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        asyncResp[CommonDefs.SECURITY_CODE] = '111222'
        asyncResp[CommonDefs.SECURITY_PIN_EXPIRATION_DATE] = '20260401T120000'

        generatePINBaseObj.validateSecurityCodeData() >> resultHashSuccess
        generatePINBaseObj.generateOTPWithLockoutCheck() >> resultHashSuccess
        generatePINBaseObj.storeMPSData() >> resultHashSuccess
        generatePINBaseObj.prepareDataForAsyncCall() >> asyncPrep
        generatePINBaseObj.makeAsyncCall(_) >> asyncResp
        objGeneratePINBaseFactory.getBean('generatePINBase') >> generatePINBaseObj

        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)

        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

   /* def "test generate pin accountLockout"() {
        HashMap hmResult =  CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ACCOUNT_LOCKOUT_NUM, "Auth method is locked for OTP generation");
        hmInput[CommonDefs.TRANSACTION_ID] = transId
        hmInput[CommonDefs.TRANSACTION_NAME] = 'GeneratePIN'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'CCMULE'
        hmInput[CommonDefs.ACCOUNT_ID] = '000968523'
        hmInput[CommonDefs.IDENTIFICATION_TYPE] = 'BSSEGENE'
        hmInput[CommonDefs.BROWSER_LANGUAGE] = 'en'
        hmInput[CommonDefs.RETURN_SECURITY_CODE] = 'Y'
        hmInput[CommonDefs.AGENT_ID] = 'abc123'

        given:
        featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled")>>false
        generatePINBaseObj.validateSecurityCodeData()>>resultHashSuccess

        generatePINBaseObj.generateOTPWithLockoutCheck() >> hmResult
        when:
        hmResponse = generatePINHelperObj.generatePin(hmInput)
        then:
        hmResponse[CommonDefs.COMMON_APP_STATUS_MSG] == CErrorDefs.ERR_ACCOUNT_LOCKOUT_MSG
    }
*/
}
