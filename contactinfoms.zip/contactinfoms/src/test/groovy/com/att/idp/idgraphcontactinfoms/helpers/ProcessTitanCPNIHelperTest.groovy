import com.att.idp.idgraphcontactinfoms.helpers.CGHelper
import com.att.idp.idgraphcontactinfoms.helpers.CPNIDataConsolidationHelper
import com.att.idp.idgraphcontactinfoms.helpers.ProcessTitanCPNIHelper
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import spock.lang.Unroll
import com.att.mpsys.common.utils.CErrorDefs

class ProcessTitanCPNIHelperTest extends Specification {

    ProcessTitanCPNIHelper helper
    CPNIDataConsolidationHelper cpniDataConsolidationHelper
    CGHelper cgHelper

    HashMap<String, Object> baseInput

    void setup() {
        helper = new ProcessTitanCPNIHelper()
        cpniDataConsolidationHelper = Mock(CPNIDataConsolidationHelper)
        cgHelper = Mock(CGHelper)
        ReflectionTestUtils.setField(helper, "cpniDataConsolidationHelper", cpniDataConsolidationHelper)
        ReflectionTestUtils.setField(helper, "cgHelper", cgHelper)
        ReflectionTestUtils.setField(helper, "cgV2Endpoint", "http://cg-endpoint")

        baseInput = CommonUtil.getHashMap()
        baseInput.put(CommonDefs.TRANSACTION_NAME, "QueryCPNIAccountContactInfo")
        baseInput.put(CommonDefs.TRANSACTION_ID, "tx123")
        baseInput.put(CommonDefs.CALLING_SYSTEM_ID, "CSRIDP")
        baseInput.put(CommonDefs.ACCOUNT_ID, "A123")
    }

    def "should return error map when input empty"() {
        given: "Empty input map"
        HashMap<String, Object> emptyInput = CommonUtil.getHashMap()

        when: "Method invoked"
        HashMap<String, Object> result = helper.getTitanCPNIContacts(emptyInput)

        then: "Error info returned"
        result.get(CommonDefs.COMMON_APP_INFO) == "Input Hash is null or empty"
        0 * _
    }

    def "should handle null input and return exception map"() {
        when:
        HashMap<String, Object> result = helper.getTitanCPNIContacts(null)

        then:
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CErrorDefs.ERR_INVALID_DATA_MSG
        0 * _
    }

    def "should return error map when CG response empty"() {
        given: "Valid input and CG returns empty map"
        HashMap<String, Object> cgResp = CommonUtil.getHashMap()

        when:
        HashMap<String, Object> result = helper.getTitanCPNIContacts(baseInput)

        then:
        1 * cgHelper.makeCGSyncCall({ HashMap<String,Object> hm -> hm.get(CommonDefs.ACCOUNT_ID) == "A123" }, "http://cg-endpoint") >> cgResp
        0 * cpniDataConsolidationHelper._
        result.get(CommonDefs.COMMON_APP_INFO) == "Null/empty response from CG"
        0 * _
    }

    def "should return error when CG response missing accounts key"() {
        given:
        HashMap<String, Object> cgResp = CommonUtil.getHashMap()
        cgResp.put("somethingElse", new HashMap<>())
        when:
        HashMap<String, Object> result = helper.getTitanCPNIContacts(baseInput)

        then:
        1 * cgHelper.makeCGSyncCall(_, _) >> cgResp
        result.get(CommonDefs.COMMON_APP_INFO) == "No Account data found in CG response."
        0 * _
    }

    def "should return error when accounts map empty"() {
        given:
        HashMap<String, Object> accounts = CommonUtil.getHashMap()
        HashMap<String, Object> cgResp = CommonUtil.getHashMap()
        cgResp.put("accounts", accounts)

        when:
        HashMap<String, Object> result = helper.getTitanCPNIContacts(baseInput)

        then:
        1 * cgHelper.makeCGSyncCall(_, _) >> cgResp
        result.get(CommonDefs.COMMON_APP_INFO) == "No Account data found in CG response."
        0 * _
    }

    def "should return error when consolidation helper returns null"() {
        given:
        HashMap<String, Object> contact = CommonUtil.getHashMap()
        contact.put("email", [emailAddress: "user@test.com", emailEstablishDate: "2023-10-01"]) // minimal for flow
        contact.put("address", [contactType: "D", postCode: "75001-1234", street1: "123 Main", city: "Dallas", state: "TX", country: "USA", lastUpdate: "2023-10-01"])
        HashMap<String, Object> accounts = CommonUtil.getHashMap()
        accounts.put("contact", contact)
        accounts.put("createdOn", "2023-10-01")
        HashMap<String, Object> cgResp = CommonUtil.getHashMap()
        cgResp.put("accounts", accounts)

        when:
        HashMap<String, Object> result = helper.getTitanCPNIContacts(baseInput)

        then:
        1 * cgHelper.makeCGSyncCall(_, _) >> cgResp
        1 * cpniDataConsolidationHelper.generateCPNIConsolidation({ HashMap<String,Object> consInput ->
            consInput.get(CommonDefs.TRANSACTION_NAME) == "QueryCPNIAccountContactInfo"
        }) >> null
        result.get(CommonDefs.COMMON_APP_INFO) == "Null response from CPNIDataConsolidationHelper"
        0 * _
    }

    def "should return consolidation response on success with CBR list and skip aging flag"() {
        given:
        baseInput.put("skipAgingRuleFlag", CommonDefs.IND_Y)
        baseInput.put(CommonDefs.ACCOUNT_INVARIANT_ID, "AINV1")
        HashMap<String, Object> primary = [ (CommonDefs.PHONE_NUMBER): "1111111111", (CommonDefs.DEVICE_IN_HAND_VALIDATION_STS): "8", (CommonDefs.PHONE_MODIFIED_DATE): "2023-10-01T10:15:30", (CommonDefs.PHONE_TYPE): "Cell Phone", (CommonDefs.IS_ATT_NUMBER): Boolean.FALSE ] as HashMap<String,Object>
        HashMap<String, Object> secondary = [ (CommonDefs.PHONE_NUMBER): "2222222222", (CommonDefs.DEVICE_IN_HAND_VALIDATION_STS): "8", (CommonDefs.PHONE_MODIFIED_DATE): "2023-10-02T10:15:30", (CommonDefs.PHONE_TYPE): "Cell Phone", (CommonDefs.IS_ATT_NUMBER): Boolean.TRUE ] as HashMap<String,Object>
        HashMap<String, Object> contact = CommonUtil.getHashMap()
        contact.put(CommonDefs.CBR_INFO, primary)
        contact.put(CommonDefs.ALT_CBR_INFO, secondary)
        contact.put("email", [emailAddress: "user@test.com", emailEstablishDate: "2023-10-01"])
        contact.put("address", [contactType: "F", postCode: "75001-1234", street1: "123 Main", city: "Dallas", state: "TX", country: "USA", lastUpdate: "2023-10-01"])
        HashMap<String, Object> accounts = CommonUtil.getHashMap()
        accounts.put("contact", contact)
        accounts.put("createdOn", "2023-10-01")
        accounts.put("state", "ACTIVE")
        HashMap<String, Object> cgResp = CommonUtil.getHashMap()
        cgResp.put("accounts", accounts)
        HashMap<String, Object> consolidationResponse = [ (CommonDefs.COMMON_APP_STATUS_CODE): CommonDefs.COMMON_SUCCESS, (CommonDefs.COMMON_APP_INFO): CommonDefs.COMMON_SUCCESS_MSG ] as HashMap<String,Object>

        when:
        HashMap<String, Object> result = helper.getTitanCPNIContacts(baseInput)

        then:
        1 * cgHelper.makeCGSyncCall({ HashMap<String,Object> hm -> hm.get(CommonDefs.ACCOUNT_ID) == "AINV1" }, _) >> cgResp
        1 * cpniDataConsolidationHelper.generateCPNIConsolidation({ HashMap<String,Object> consInput ->
            consInput.get("CBRCTNList") instanceof List && ((List)consInput.get("CBRCTNList")).size() == 2 &&
            ((List)consInput.get("CBRCTNList")).every{ Map m -> m.get(CommonDefs.CPNI_ELIGIBLE_EMAIL_FLAG) == CommonDefs.IND_Y }
        }) >> consolidationResponse
        result == consolidationResponse
        0 * _
    }

    def "should handle exception thrown by consolidation helper and return exception map"() {
        given:
        HashMap<String, Object> contact = CommonUtil.getHashMap()
        contact.put("email", [emailAddress: "user@test.com", emailEstablishDate: "2023-10-01"])
        contact.put("address", [contactType: "D", postCode: "75001", street1: "123 Main", city: "Dallas", state: "TX", country: "USA", lastUpdate: "2023-10-01"])
        HashMap<String, Object> accounts = CommonUtil.getHashMap()
        accounts.put("contact", contact)
        accounts.put("createdOn", "2023-10-01")
        HashMap<String, Object> cgResp = CommonUtil.getHashMap()
        cgResp.put("accounts", accounts)

        when:
        HashMap<String, Object> result = helper.getTitanCPNIContacts(baseInput)

        then:
        1 * cgHelper.makeCGSyncCall(_, _) >> cgResp
        1 * cpniDataConsolidationHelper.generateCPNIConsolidation(_) >> { throw new RuntimeException("boom") }
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CErrorDefs.ERR_SYS_APPL_MSG
        0 * _
    }

    def "should return error when CBR ineligible (validation status not 8 and skip flag N)"() {
        given:
        HashMap<String, Object> primary = [ (CommonDefs.PHONE_NUMBER): "1111111111", (CommonDefs.DEVICE_IN_HAND_VALIDATION_STS): "7", (CommonDefs.PHONE_MODIFIED_DATE): "2023-10-01T10:15:30", (CommonDefs.PHONE_TYPE): "Cell Phone", (CommonDefs.IS_ATT_NUMBER): Boolean.FALSE ] as HashMap<String,Object>
        HashMap<String, Object> contact = CommonUtil.getHashMap()
        contact.put(CommonDefs.CBR_INFO, primary)
        contact.put("email", [emailAddress: "user@test.com", emailEstablishDate: "2023-10-01"])
        HashMap<String, Object> accounts = CommonUtil.getHashMap()
        accounts.put("contact", contact)
        accounts.put("createdOn", "2023-10-01")
        HashMap<String, Object> cgResp = CommonUtil.getHashMap()
        cgResp.put("accounts", accounts)
        HashMap<String, Object> consolidationResponse = [ (CommonDefs.COMMON_APP_STATUS_CODE): CommonDefs.COMMON_SUCCESS, (CommonDefs.COMMON_APP_INFO): CommonDefs.COMMON_SUCCESS_MSG ] as HashMap<String,Object>

        when:
        HashMap<String, Object> result = helper.getTitanCPNIContacts(baseInput)

        then:
        1 * cgHelper.makeCGSyncCall(_, _) >> cgResp
        1 * cpniDataConsolidationHelper.generateCPNIConsolidation({ HashMap<String,Object> consInput -> !consInput.containsKey("CBRCTNList") }) >> consolidationResponse
        result == consolidationResponse
        0 * _
    }

    def "should exclude CBR phone when mapped type is not MOBILE even with valid status 8"() {
        given: "CBR phone with Home phone type and valid status 8"
        HashMap<String, Object> primary = [ (CommonDefs.PHONE_NUMBER): "1111111111", (CommonDefs.DEVICE_IN_HAND_VALIDATION_STS): "8", (CommonDefs.PHONE_MODIFIED_DATE): "2023-10-01T10:15:30", (CommonDefs.PHONE_TYPE): "Home", (CommonDefs.IS_ATT_NUMBER): Boolean.FALSE ] as HashMap<String,Object>
        HashMap<String, Object> contact = CommonUtil.getHashMap()
        contact.put(CommonDefs.CBR_INFO, primary)
        contact.put("email", [emailAddress: "user@test.com", emailEstablishDate: "2023-10-01"])
        HashMap<String, Object> accounts = CommonUtil.getHashMap()
        accounts.put("contact", contact)
        accounts.put("createdOn", "2023-10-01")
        accounts.put("phoneNumberValidationStatus", "8")
        HashMap<String, Object> cgResp = CommonUtil.getHashMap()
        cgResp.put("accounts", accounts)
        HashMap<String, Object> consolidationResponse = [ (CommonDefs.COMMON_APP_STATUS_CODE): CommonDefs.COMMON_SUCCESS, (CommonDefs.COMMON_APP_INFO): CommonDefs.COMMON_SUCCESS_MSG ] as HashMap<String,Object>

        when: "getTitanCPNIContacts is called"
        HashMap<String, Object> result = helper.getTitanCPNIContacts(baseInput)

        then: "CBRCTNList should not be present since Home phone type is not MOBILE"
        1 * cgHelper.makeCGSyncCall(_, _) >> cgResp
        1 * cpniDataConsolidationHelper.generateCPNIConsolidation({ HashMap<String,Object> consInput -> !consInput.containsKey("CBRCTNList") }) >> consolidationResponse
        0 * _

        and: "result is the consolidation response"
        result == consolidationResponse
    }

    def "should use accountId when accountInvariantId absent in callCGforUverse"() {
        given:
        HashMap<String, Object> input = CommonUtil.getHashMap()
        input.put(CommonDefs.ACCOUNT_ID, "ACC456")

        when:
        helper.callCGforUverse(input)

        then:
        1 * cgHelper.makeCGSyncCall({ HashMap<String,Object> hm -> hm.get(CommonDefs.ACCOUNT_ID) == "ACC456" }, "http://cg-endpoint") >> CommonUtil.getHashMap()
        0 * _
    }

    def "should handle exception in callCGforUverse and return error map"() {
        given:
        HashMap<String, Object> input = CommonUtil.getHashMap()
        input.put(CommonDefs.ACCOUNT_ID, "ACC456")

        when:
        HashMap<String, Object> result = helper.callCGforUverse(input)

        then:
        1 * cgHelper.makeCGSyncCall(_, _) >> { throw new RuntimeException("cg fail") }
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CErrorDefs.ERR_SYS_APPL_MSG
        0 * _
    }

    @Unroll
    def "should format date correctly for #scenarioName"() {
        given:
        java.lang.reflect.Method m = ProcessTitanCPNIHelper.class.getDeclaredMethod("formatDate", String.class, String.class)
        m.setAccessible(true)

        when:
        String result = (String) m.invoke(null, key, value)

        then:
        result == expected

        where:
        scenarioName                         | key                               | value                        | expected
        "customer active"                   | CommonDefs.CUSTOMER_ACTIVE_DATE    | "2023-10-01"                | "10012023 00:00:00"
        "time modified"                    | CommonDefs.TIME_MODIFIED           | "2023-10-01"                | "10012023 00:00:00"
        "email addr last update"           | "EmailAddrLastUpdateTs"           | "2023-10-01"                | "10012023 00:00:00"
        "establish date"                   | "establishDate"                   | "2023-10-01"                | "10012023 00:00:00"
        "sim swap"                         | "simSwapDateTime"                 | "2023-10-01T12:00:00Z"      | "10012023 07:00:00"
        "phone modified"                   | CommonDefs.PHONE_MODIFIED_DATE     | "2023-10-01T12:00:00"       | "10012023 12:00:00"
        "unknown key"                      | "unknownKey"                      | "2023-10-01"                | null
    }

    def "should return null formatted date on parse exception"() {
        given:
        java.lang.reflect.Method m = ProcessTitanCPNIHelper.class.getDeclaredMethod("formatDate", String.class, String.class)
        m.setAccessible(true)

        when:
        String result = (String) m.invoke(null, CommonDefs.CUSTOMER_ACTIVE_DATE, "bad-date")

        then:
        result == null
    }
}


