package com.att.idp.QAIntegration.Helpers

import com.att.idp.QAIntegration.Base.TestBase
import com.att.idp.QAIntegration.Config.ContactInfoGlobalConfig
import com.att.idp.QAIntegration.Utils.ApplicationConstants
import groovy.json.JsonOutput
import groovy.util.logging.Slf4j
import io.restassured.response.Response

/**
 * YAML-driven API helper for IDGraphContactInfoMs QG7 integration tests.
 *
 * Design principles:
 *   - ZERO hardcoded test data — every value comes from YAML test data maps
 *   - Optional headers, query params, path params — all sourced from YAML
 *   - Reusable header constants from {@link ApplicationConstants.Header}
 *   - All requests route through {@link TestBase#sendRequest} for uniform logging
 *
 * Usage in specs:
 *   Map data = ContactInfoGlobalConfig.getTestData().get("generatePIN")
 *   Response r = ContactInfoMsApiHelpers.generatePIN(data)
 */
@Slf4j
class ContactInfoMsApiHelpers {

    // ═══════════════════════════════════════════════════════════════════════════
    // OTP FLOW CLIENTS CONFIGURATION
    // ═══════════════════════════════════════════════════════════════════════════

    static final Map<String, Map> CLIENTS_CONFIG_OTP_FLOW = [
            "BANPCS"    : [clientID: ["OPUS", "IDP", "CSRIDP", "SARAPLUS", "CCMULE", "ERICSSON", "IVRSAG"], expiration: 120, methods: ["sms"], length: 6],
            "BANPCE"    : [clientID: ["OPUS", "SARAPLUS", "CCMULE", "ERICSSON"], expiration: 120, methods: ["email"], length: 6],
            "BANPTONLS" : [clientID: ["MYATTSALES", "IDP", "UPPERFUNNEL", "ANDIVA", "IDPWEBSALES", "IDPCHECKOUT"], expiration: 120, methods: ["sms"], length: 6],
            "BANPTONLE" : [clientID: ["MYATTSALES", "IDP", "ANDIVA", "IDPCHECKOUT"], expiration: 120, methods: ["email"], length: 6],
            "PINVALID"  : [clientID: ["IDP", "CSRIDP", "OPUS"], expiration: 120, methods: ["sms", "email"], length: 6],
            "NONATTCTN" : [clientID: ["IDP", "CSRIDP", "OPUS"], expiration: 60, methods: ["sms"], length: 6],
            "ATTCTN"    : [clientID: ["IDP", "CSRIDP"], expiration: 60, methods: ["sms"], length: 6],
            "EMAILOTP"  : [clientID: ["IDP", "OPUS"], expiration: 60, methods: ["email"], length: 6],
            "CRICKETOTP": [clientID: ["IDP", "CSRIDP", "OPUS"], expiration: 60, methods: ["email"], length: 6],
            "EMAILPIN"  : [clientID: ["IDP", "CSRIDP", "OPUS", "ERICSSON", "MYATTSALES", "IDPSALES", "MULESOFT", "CCMULE", "MYATTMOBILE", "CIAM", "UPPERFUNNEL"], expiration: 60, methods: ["email"], length: 6],
            "CTNDIH"    : [clientID: ["IDP", "CSRIDP", "OPUS"], expiration: 60, methods: ["sms"], length: 4],
            "BANAP"     : [clientID: ["PENNYVA", "TLG"], expiration: 1440, methods: ["sms", "email"], length: 6],
            "CTN"       : [clientID: ["IDP", "CSRIDP", "MOBILEREG"], expiration: 43200, methods: ["sms", "email"], length: 8],
            "ECOMMSEC"  : [clientID: ["IDP", "CSRIDP"], expiration: 43200, methods: ["sms", "email"], length: 8],
            "TITANSEC"  : [clientID: ["IDP", "CSRIDP"], expiration: 43200, methods: ["sms", "email"], length: 8],
            "CTNAUTH"   : [clientID: ["MULESOFT", "CCMULE"], expiration: 60, methods: ["sms"], length: 6],
            "CTNOPR"    : [clientID: ["IDP", "CSRIDP", "CSIGATEWAY"], expiration: 1440, methods: ["sms"], length: 4],
            "ENCPIN"    : [clientID: ["IDPSALES"], expiration: 43200, methods: ["sms", "email"], length: 6],
            "BSSEOTP"   : [clientID: ["IDP", "MULESOFT", "CCMULE", "IVR", "CHAT", "IVRSAG"], expiration: 60, methods: ["sms", "email"], length: 6],
            "BSSEONL"   : [clientID: ["IDP", "IDPWAM", "IDPCAC"], expiration: 60, methods: ["sms", "email"], length: 6],
            "BSSEREGOTP": [clientID: ["IDP"], expiration: 60, methods: ["sms", "email"], length: 6],
            "AUTHUSER"  : [clientID: ["IDP"], expiration: 120, methods: ["sms"], length: 6],
            "NTRETAILER": [clientID: ["WALMART", "SAMSUNG", "GOOGLESTORE", "BESTBUY", "APPLE", "TARGET", "COSTCO", "SAMSCLUB", "IDPCOMENBSER", "OMNIADAPTER", "CSIGATEWAY"], expiration: 60, methods: ["sms", "email"], length: 6],
            "ESIMOTP"   : [clientID: ["IDP", "MYATTSALES", "UPPERFUNNEL", "IDPWEBSALES"], expiration: 60, methods: ["sms"], length: 6],
            "GENERICOTP": [clientID: ["IDP", "IDPWEBSUPPORT", "IDPDTAP", "IDPWEBSALES", "UPPERFUNNEL", "IDPCHECKOUT", "OPUS", "ERICSSON", "IDPCOMENBSER"], expiration: 60, methods: ["sms", "email"], length: 6],
            "PORTOUTABS": [clientID: ["OPUS", "PREMIER", "TELEGENCE", "IDPWAM", "IDP"], expiration: 4320, methods: ["email"], length: 6],
            "PORTOUTBSS": [clientID: ["IDPWAM", "BSSEOC", "IVRSAG", "IDP"], expiration: 4320, methods: ["sms"], length: 6],
            "PORTOUT"   : [clientID: ["AVERTACK", "IDP"], expiration: 4320, methods: ["sms", "email"], length: 6],
            "BANPC"     : [clientID: ["IVRSAG", "CLARIFY", "EDS", "EVA", "IDPCOMENBSER", "IDPCHECKOUT", "OPUS"], expiration: 1440, methods: ["sms", "email"], length: 6],
            "REGIMPROVE": [clientID: ["OPUS", "LSCRM", "ATLAS-UI", "SHM", "CCMULE"], expiration: 60, methods: ["sms", "email"], length: 6],
            "APPTSCHED" : [clientID: ["QRAS", "IDPDTAP"], expiration: 1440, methods: ["sms", "email"], length: 6],
            "BANCRU"    : [clientID: ["CLARIFY", "OPUS", "ASF"], expiration: 1440, methods: ["sms", "email"], length: 6],
            "BANPT"     : [clientID: ["CSIGATEWAY", "IDP", "OPUS"], expiration: 1440, methods: ["sms", "email"], length: 6],
            "BANPTONL"  : [clientID: ["IDP"], expiration: 1440, methods: ["sms", "email"], length: 6],
            "PORTOUTPP" : [clientID: ["ERICSSON", "IVRSAG"], expiration: 5760, methods: ["sms", "email"], length: 6],
            "SMBYIELD"  : [clientID: ["IDPCHECKOUT", "IDPCNCUI"], expiration: 60, methods: ["email"], length: 6],
            "BSSEGENS"  : [clientID: ["IDPWAM", "CCMULE", "MULESOFT"], expiration: 60, methods: ["sms"], length: 6],
            "BSSEGENE"  : [clientID: ["IDPWAM", "CCMULE", "MULESOFT"], expiration: 60, methods: ["email"], length: 6],
            "BTN"       : [clientID: ["IDP"], expiration: 1440, methods: ["sms", "email"], length: 8],
            "WBAN"      : [clientID: ["IDP", "CSRIDP"], expiration: 1440, methods: ["sms", "email"], length: 8],
            "WBANSEC"   : [clientID: ["IDP", "CSRIDP"], expiration: 43200, methods: ["sms", "email"], length: 8],
            "TITANIMD"  : [clientID: ["IDP", "CSRIDP"], expiration: 43200, methods: ["sms", "email"], length: 8]
    ]

    // ═══════════════════════════════════════════════════════════════════════════
    // YAML-LOADED DEFAULTS (no hardcoded data — everything from YAML)
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Returns a fresh copy of the 'defaults' section from the YAML test data file.
     * Every spec or helper that needs base data should call this instead of using
     * a hardcoded map.
     */
    static Map<String, String> getDefaults() {
        Map yamlDefaults = ContactInfoGlobalConfig.getTestData()?.get("defaults") as Map
        if (yamlDefaults) {
            return new LinkedHashMap<>(yamlDefaults)
        }
        log.warn("No 'defaults' section found in YAML — returning minimal fallback")
        return [
                callingSystemId: "IDP",
                clientId       : "IDP",
                deleteAll      : "Y"
        ]
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // UTILITY METHODS
    // ═══════════════════════════════════════════════════════════════════════════

    static List<String> getClientID(String key) {
        return CLIENTS_CONFIG_OTP_FLOW[key]?.clientID ?: []
    }

    static List<String> getDeliveryMethods(String key) {
        return CLIENTS_CONFIG_OTP_FLOW[key]?.methods ?: []
    }

    static int getPinLength(String key) {
        return CLIENTS_CONFIG_OTP_FLOW[key]?.length ?: 0
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // PIN API METHODS
    // ═══════════════════════════════════════════════════════════════════════════

    static Response generatePIN(Map data) {
        Map body = [:]
        addIfPresent(body, "accountId", data)
        addIfPresent(body, "identificationType", data)
        addIfPresent(body, "callingSystemId", data)
        addIfPresent(body, "agentId", data)
        addIfPresent(body, "returnSecurityCode", data)
        addIfPresent(body, "browserLanguage", data)
        addIfPresent(body, "resBusInd", data)
        body.deliveryMethods = buildDeliveryMethods(data)
        return TestBase.sendRequest(
                ContactInfoGlobalConfig.Endpoints.GENERATE_PIN, "POST",
                JsonOutput.toJson(body),
                buildExtraHeaders(data),
                buildQueryParams(data)
        )
    }

    static Response validatePIN(Map data, String securityCode) {
        Map body = [:]
        addIfPresent(body, "accountId", data)
        addIfPresent(body, "identificationType", data)
        addIfPresent(body, "callingSystemId", data)
        body.securityCode = securityCode
        body.DeletePINOnSuccess = data?.DeletePINOnSuccess ?: "NONE"
        return TestBase.sendRequest(
                ContactInfoGlobalConfig.Endpoints.VALIDATE_PIN, "POST",
                JsonOutput.toJson(body),
                buildExtraHeaders(data),
                buildQueryParams(data)
        )
    }

    static Response deletePIN(Map data) {
        Map body = [:]
        addIfPresent(body, "accountId", data)
        addIfPresent(body, "identificationType", data)
        addIfPresent(body, "callingSystemId", data)
        addIfPresent(body, "deleteAll", data)
        addIfPresent(body, "reasonCode", data)
        return TestBase.sendRequest(
                ContactInfoGlobalConfig.Endpoints.DELETE_PIN, "POST",
                JsonOutput.toJson(body),
                buildExtraHeaders(data),
                buildQueryParams(data)
        )
    }

    static Response inquirePIN(Map data) {
        Map body = [:]
        addIfPresent(body, "accountId", data)
        addIfPresent(body, "identificationType", data)
        addIfPresent(body, "callingSystemId", data)
        return TestBase.sendRequest(
                ContactInfoGlobalConfig.Endpoints.INQUIRE_PIN, "POST",
                JsonOutput.toJson(body),
                buildExtraHeaders(data),
                buildQueryParams(data)
        )
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CPNI CONTACT INFO API METHODS
    // ═══════════════════════════════════════════════════════════════════════════

    static Response cpniContactInfoAccount(Map data) {
        Map body = [:]
        addIfPresent(body, "callingSystemId", data)
        addIfPresent(body, "accountId", data)
        addIfPresent(body, "accountInvariantId", data)
        addIfPresent(body, "accountType", data)
        addIfPresent(body, "returnCBRCTNs", data)
        addIfPresent(body, "skipAgingRuleFlag", data)
        addIfPresent(body, "isExternalCall", data)
        addIfPresent(body, "idpTraceId", data)
        return TestBase.sendRequest(
                ContactInfoGlobalConfig.Endpoints.CPNI_CONTACT_INFO_ACCOUNT, "POST",
                JsonOutput.toJson(body),
                buildExtraHeaders(data),
                buildQueryParams(data)
        )
    }

    static Response cpniContactInfoUser(Map data) {
        Map body = [:]
        addIfPresent(body, "callingSystemId", data)
        addIfPresent(body, "userId", data)
        addIfPresent(body, "domain", data)
        addIfPresent(body, "guid", data)
        addIfPresent(body, "returnCBRCTNs", data)
        addIfPresent(body, "isExternalCall", data)
        addIfPresent(body, "idpTraceId", data)
        return TestBase.sendRequest(
                ContactInfoGlobalConfig.Endpoints.CPNI_CONTACT_INFO_USER, "POST",
                JsonOutput.toJson(body),
                buildExtraHeaders(data),
                buildQueryParams(data)
        )
    }

    static Response cpniContactInfo() {
        return TestBase.sendRequest(
                ContactInfoGlobalConfig.Endpoints.CPNI_CONTACT_INFO, "GET",
                null,
                [:],
                [:]
        )
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // HEARTBEAT
    // ═══════════════════════════════════════════════════════════════════════════

    static Response heartbeat() {
        return TestBase.sendRequest(ContactInfoGlobalConfig.Endpoints.HEARTBEAT, "GET")
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // PRIVATE HELPERS
    // ═══════════════════════════════════════════════════════════════════════════

    private static void addIfPresent(Map body, String key, Map data) {
        if (data?.containsKey(key) && data[key] != null) {
            body[key] = data[key]
        }
    }

    private static Map<String, String> buildExtraHeaders(Map data) {
        Map<String, String> headers = [:]
        if (data?.clientId) {
            headers[ApplicationConstants.Header.ATT_CLIENT_ID] = data.clientId as String
        }
        if (data?.accountId) {
            headers[ApplicationConstants.Header.IDP_CG_ACCOUNT_ID] = data.accountId as String
        }
        if (data?.subscriberId) {
            headers[ApplicationConstants.Header.IDP_CG_SUBSCRIBER_ID] = data.subscriberId as String
        }
        Map yamlHeaders = data?.extraHeaders as Map
        if (yamlHeaders) {
            yamlHeaders.each { k, v -> headers[k as String] = v as String }
        }
        return headers
    }

    private static Map<String, String> buildQueryParams(Map data) {
        Map yamlParams = data?.queryParams as Map
        if (!yamlParams) return [:]
        Map<String, String> params = [:]
        yamlParams.each { k, v -> params[k as String] = v as String }
        return params
    }

    private static Map buildDeliveryMethods(Map data) {
        String method = (data?.deliveryMethod as String)?.toLowerCase(Locale.US)
        if (!method && data?.deliveryMethods) {
            return data.deliveryMethods as Map
        }

        // Fallback to YAML defaults if phone/email not in test case data
        Map defaults = getDefaults()
        String phone = data?.smsPhoneNumber ?: defaults?.smsPhoneNumber ?: "3305031423"
        String email = data?.emailAddress ?: defaults?.emailAddress ?: "generatePIN_Automation@yopmail.com"

        switch (method) {
            case "sms":
                return [sms: [smsPhoneNumber: phone]]
            case "letter":
                Map letter = [:]
                if (data?.letterName) letter.name = data.letterName
                if (data?.letterStreet1) letter.street1 = data.letterStreet1
                if (data?.letterCity) letter.city = data.letterCity
                if (data?.letterState) letter.state = data.letterState
                if (data?.letterZip) letter.zipCode = data.letterZip
                if (data?.letterCountry) letter.country = data.letterCountry
                return [letter: letter]
            case "email":
            default:
                return [email: [emailAddress: email]]
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // REUSABLE HELPER — Delete All PINs for a given account + identificationType
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Pre-cleanup: deletes all PINs for the given accountId + identificationType.
     * Uses deleteAll=Y so the service does not complain about missing PIN.
     * Safe to call even if no PIN exists — 200 or 400 are both acceptable.
     */
    static Response deleteAllPins(Map data) {
        Map deleteData = new LinkedHashMap<>(data)
        deleteData.put("deleteAll", "Y")
        log.info("Pre-cleanup deleteAll for accountId={}, type={}", deleteData.accountId, deleteData.identificationType)
        return deletePIN(deleteData)
    }
}
