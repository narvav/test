package com.att.idp.component

import com.att.idp.idgraph.db.cosmos.entity.IdgOtpContainer
import com.att.idp.idgraph.db.cosmos.helper.IdgOtpDBHelper
import com.att.idp.idgraphcontactinfoms.db.model.Tsecurityaccount
import com.att.idp.idgraphcontactinfoms.db.model.Tsecuritycode
import com.att.idp.idgraphcontactinfoms.db.model.TsecuritycodeId
import com.att.idp.idgraphcontactinfoms.db.repository.SecurityAccountDataRepository
import com.att.idp.idgraphcontactinfoms.db.repository.SecurityCodeRepository
import com.att.idp.idgraphcontactinfoms.integration.MuleSoftRestClient
import com.att.idp.idgraphcontactinfoms.resource.request.GeneratePINRequest;
import com.att.idp.idgraphcontactinfoms.utils.JsonService
import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.att.mpsys.common.utils.CommonUtil
import org.hamcrest.CoreMatchers
import org.spockframework.spring.SpringBean

import java.text.DateFormat
import java.text.SimpleDateFormat;
import java.time.LocalDate;



class GeneratePinCompTest extends CompBaseTest {

    String uri = "/pin/generate";

    @SpringBean
    SecurityCodeRepository securityCodeRepository = Mock();

    @SpringBean
    SecurityAccountDataRepository securityAccountDataRepository = Mock();

    @SpringBean
    MuleSoftRestClient muleSoftRestClient = Mock();
	
    @SpringBean
    FeatureManagerHelper featureManager = Mock();

    @SpringBean
    IdgOtpDBHelper idgOtpDBHelper = Mock();

    HashMap<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>()
        headers.put("Content-Type", "application/json")
        headers.put("idp-trace-id", "ed44414d155475a6:ed44414d155475a6:0:0")
        headers.put("X-ATT-ClientId", "ERICSSON")
        return headers
    }



    def "generate pin success sms"() {
        given:
		featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ONLYORACLE";
        securityCodeRepository.getSecurityCodeDataQuery(_ as String, _ as String) >> populateSecurityCodeList();
        securityCodeRepository.deleteByIdIdentificationTypeAndIdAccountId(_ as String, _ as String) >> 0;
        securityAccountDataRepository.getSecurityAccountData(_ as String, _ as String) >> getSecurityList();
        securityAccountDataRepository.getCumulativeFailureCount(_ as String, _ as String) >> 0;
        securityAccountDataRepository.updateSecurityAccount(_ as HashMap, _ as Boolean, _ as Long) >> 1;
        securityCodeRepository.setSecurityCode(_ as HashMap) >> 1;
        muleSoftRestClient.postCCMuleSyncCall(_ as HashMap, null, _ as String) >> getMockResult();
        String expectedDate = calculateExpectedDate(60, "GMT");

        expect:
        givenBaseSpec()
                .body(mockRequest())
                .when().headers(getHeaders())
                .post(uri)
                .then()
                .statusCode(200).assertThat()
                .body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
                .body("appStatusCode", CoreMatchers.equalTo("0"))
                .body("securityCode", CoreMatchers.notNullValue())
                .body("securityCodeExpires", CoreMatchers.containsString(expectedDate))
				.body("idp-trace-id", CoreMatchers.equalTo("ed44414d155475a6:ed44414d155475a6:0:0"))

    }
    def "generate pin  for accountlockout when identificationType BSSEGENE"() {
        HashMap headers = getHeaders()
        headers.put("X-ATT-ClientId", "CCMULE")
        String expectedDate = calculateExpectedDate(60, "GMT");
        HashMap<String, Object> hmGetDBResult = ["security_code_count" : '2', "appStatusCode" : '0']

        given:
        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> "COSMOSMASTER"
        idgOtpDBHelper.getSecurityCodeDataQuery(_) >> hmGetDBResult
        String unlockAccountTime = java.time.Instant.now().plusSeconds(3600).toString() // 1 hour in future
        IdgOtpContainer unlockedContainer = new IdgOtpContainer()
        unlockedContainer.setIdentificationType("BSSEGENE")
        unlockedContainer.setAccountId("2543916110")
        unlockedContainer.setUnlockAccountTime(unlockAccountTime)

        idgOtpDBHelper.findByIdentificationTypeAndAccountId(_)>> Optional.of(unlockedContainer)

        expect:
        givenBaseSpec()
                .body(mockRequestBSSEGENE())
                .when().headers(headers)
                .post(uri)
                .then()
                .statusCode(400).assertThat()
                .body("appStatusMsg", CoreMatchers.equalTo("ERR_ACCOUNT_LOCKOUT"))
                .body("appStatusCode", CoreMatchers.equalTo("268"))
                .body("idp-trace-id", CoreMatchers.equalTo("ed44414d155475a6:ed44414d155475a6:0:0"))
    }

    def "generate pin identification type Invalid input data"() {
        given:
        GeneratePINRequest request = mockRequest();
        request.identificationType = "";
        expect:
        givenBaseSpec()
                .body(request)
                .when().headers(getHeaders())
                .post(uri)
                .then()
                .statusCode(400).assertThat()
                .body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
                .body("appStatusCode", CoreMatchers.equalTo("100"))
                .body("appInfo", CoreMatchers.notNullValue())
                .body("error.errorId", CoreMatchers.equalTo("MS_MPSYS_BE_100"))
                .body("idp-trace-id", CoreMatchers.equalTo("ed44414d155475a6:ed44414d155475a6:0:0"))

    }


    /*def "CC Mule Null Response Output"() {
        given:
        securityCodeRepository.getSecurityCodeDataQuery(_ as String, _ as String) >> populateSecurityCodeList();
        securityCodeRepository.deleteByIdIdentificationTypeAndIdAccountId(_ as String, _ as String) >> 0;
        securityAccountDataRepository.getSecurityAccountData(_ as String, _ as String) >> getSecurityList();
        securityAccountDataRepository.getCumulativeFailureCount(_ as String, _ as String) >> 0;
        securityAccountDataRepository.updateSecurityAccount(_ as HashMap, _ as Boolean, _ as Long) >> 1;
        securityCodeRepository.setSecurityCode(_ as HashMap) >> 0;
        muleSoftRestClient.postCCMuleSyncCall(_ as HashMap, _ as String, _ as String) >> null;

        expect:
        givenBaseSpec()
                .body(mockRequest())
                .when().headers(getHeaders())
                .post(uri)
                .then()
                .statusCode(500).assertThat()
                .body("appStatusMsg", CoreMatchers.equalTo("ERR_SYS_APPL"))
                .body("appStatusCode", CoreMatchers.equalTo("602"))
                .body("appInfo", CoreMatchers.notNullValue())
                .body("error.errorId", CoreMatchers.equalTo("MS_MPSYS_BE_602"))
                .body("idp-trace-id", CoreMatchers.equalTo("ed44414d155475a6:ed44414d155475a6:0:0"))

    }*/
     private GeneratePINRequest mockRequestBSSEGENE() {

        String requestStr = "{\"accountId\":\"2543916110\"," +
                "\"identificationType\":\"BSSEGENE\"," +
                "\"agentId\":\"ad4567\"," +
                "\"returnSecurityCode\":\"Y\"," +
                "\"browserLanguage\":\"en\"," +
                "\"deliveryMethods\":{" +
                "\"email\":{\"emailaddress\":\"ss254y@att.com\"" +
                "}}}"
        return JsonService.convertToObject(requestStr, GeneratePINRequest.class);
    }

    private GeneratePINRequest mockRequest() {

        String requestStr = "{\"accountId\":\"2543916110\"," +
                "\"identificationType\":\"GENERICOTP\"," +
                "\"agentId\":\"ad4567\"," +
                "\"returnSecurityCode\":\"Y\"," +
                "\"browserLanguage\":\"en\"," +
                "\"deliveryMethods\":{" +
                "\"email\":{\"emailaddress\":\"ss254y@att.com\"" +
                "}}}"
        return JsonService.convertToObject(requestStr, GeneratePINRequest.class);
    }

    private List<Tsecuritycode> populateSecurityCodeList() {
        List<Tsecuritycode> securityCodeList = new ArrayList<>();
        Tsecuritycode securityCode = new Tsecuritycode();
        TsecuritycodeId secCode2 = new TsecuritycodeId()
        //secCode2.securityCode = '14213'
        secCode2.accountId = '2543916110'
        securityCode.id = secCode2
        securityCode.securityCodeStatus = 'ACTIVE'
        securityCode.securityCodeExpires = java.sql.Date.valueOf(LocalDate.now());
        securityCode.createDate = java.sql.Date.valueOf(LocalDate.now());
        securityCode.lastModified = java.sql.Date.valueOf(LocalDate.now());
        securityCode.sorInvariantId = null
        securityCode.passcodeVenc = '1234567'
        securityCode.verificationFailureCount = 10
        securityCode.deliveryDetail = '2146759270'
        securityCodeList.add(securityCode);
        return securityCodeList;
    }

    List<Tsecurityaccount> getSecurityList() {
        List<Tsecurityaccount> securityList = new ArrayList<>();
        Tsecurityaccount securityAccount = new Tsecurityaccount();
        securityAccount.accountEntryExpires = java.sql.Date.valueOf(LocalDate.now());
        securityAccount.lastModified = java.sql.Date.valueOf(LocalDate.now());
        securityAccount.createDate = java.sql.Date.valueOf(LocalDate.now());
        securityAccount.lastModifiedBy = "ERICSSON";
        securityAccount.cumulativeFailureCount = 0;
        securityList.add(securityAccount);
        return securityList;
    }

    private HashMap getMockResult() {
        HashMap<String, Object> mockResult = new HashMap<>()
        mockResult.put("appCategoryCode", "0");
        mockResult.put("appStatusMsg ", "SUCCESS");
        mockResult.put("traceId", "676d86c553c8c866:676d86c553c8c866:0:1");
        mockResult.put("appStatusCode", "0");
        mockResult.put("COMMON_APP_STATUS_CODE", "0")
        mockResult.put("APP_STATUS_CODE", "0");
        mockResult.put("COMMON_APP_INFO", "SUCCESS");
        return mockResult;
    }
    private String calculateExpectedDate(int expirationMinutes, String timeZone) {
        DateFormat df = new SimpleDateFormat("MMddyyyy HH:mm");
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeZone(TimeZone.getTimeZone(timeZone));
        calendar.add(Calendar.MINUTE, expirationMinutes);
        Date expiryDate = calendar.getTime();
        TimeZone tz = calendar.getTimeZone();
        return df.format(expiryDate) + " " + tz.getDisplayName(true, tz.SHORT);
    }

}
