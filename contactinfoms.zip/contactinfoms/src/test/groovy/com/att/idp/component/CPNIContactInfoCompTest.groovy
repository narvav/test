package com.att.idp.component

import com.att.idp.core.exception.ServiceError
import com.att.idp.core.exception.ServiceException
import com.att.idp.dpl.profile.bsse.customerv4.CustomerV4Response
import com.att.idp.idgraphcontactinfoms.message.ErrorMessages
import com.att.idp.idgraphcontactinfoms.model.Individual
import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.fasterxml.jackson.databind.JsonNode
import org.hamcrest.CoreMatchers
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.DeserializationFeature;
import io.swagger.client.model.CGIndividualInfo

import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter;


class CPNIContactInfoCompTest extends CompBaseTest {

    def getHeaders() {
        Map<String, String> headers = new HashMap<>()
        headers.put("Content-Type", "application/json")
        headers.put("idp-trace-id", "ed44414d155475a6:ed44414d155475a6:0:0")
        headers.put("X-ATT-ClientId", "IDP")
        return headers
    }

    def "get CPNI contact info success with individualId"() {
        given:
        String individualId = "123456789"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("individualId", individualId)
        profileHelper.profileMsSearchByIndividualId(_ as String,_ as Map)>> getMockIndividualProfileData()

        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //added this logic to exclude idp-trace-id from api response while deserializing to Individual object
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode individualNode = rootNode.get("individual");
        Individual individual = objectMapper.treeToValue(individualNode, Individual.class);

        then:
        response.statusCode() == 200
        response.then()
                .body("individual", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
                .body("errors", CoreMatchers.nullValue())
        individual.getContactMediums().size() == 2
        individual.getContactMediums().get(0).getMediumType() == "email"
        individual.getContactMediums().get(1).getMediumType() == "cbr"
        individual.getAccounts().size() == 2
        individual.getAccounts().get(0).id == "551308050779"
        individual.getAccounts().get(1).id == "558244086338"
    }

    def "get CPNI contact info success with individualId with exploitable Y"() {
        given:
        String individualId = "123456789"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("individualId", individualId)
        headers.put("exploitable", "Y")
        profileHelper.profileMsSearchByIndividualId(_ as String,_ as Map)>> getMockIndividualProfileData()

        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //added this logic to exclude idp-trace-id from api response while deserializing to Individual object
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode individualNode = rootNode.get("individual");
        Individual individual = objectMapper.treeToValue(individualNode, Individual.class);

        then:
        response.statusCode() == 200
        response.then()
                .body("individual", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
                .body("errors", CoreMatchers.nullValue())
        individual.getContactMediums().size() == 0
        individual.getAccounts().size() == 2
        individual.getAccounts().get(0).id == "551308050779"
        individual.getAccounts().get(1).id == "558244086338"
        individual.getAccounts().get(0).getContacts().get(0).getContactMediums().size() == 0
        individual.getAccounts().get(1).getContacts().get(0).getContactMediums().size() == 0
        individual.getAccounts().get(0).getSubscribers().size() == 1
        individual.getAccounts().get(0).getSubscribers().get(0).getSubscriberId() == "6197798996"

    }

    def "get CPNI contact info success with accountId"() {
        given:
        String accountId = "551796831595"
        String accountType = "wireless"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("accountId", accountId)
        headers.put("accountType", accountType)
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> getMockCGCustomerV4Data("mock-customer-v4-data.json")
        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //added this logic to exclude idp-trace-id from api response while deserializing to Individual object
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode individualNode = rootNode.get("individual");
        Individual individual = objectMapper.treeToValue(individualNode, Individual.class);
        then:
        response.statusCode() == 200
        response.then()
                .body("individual", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
                .body("errors", CoreMatchers.nullValue())
        individual.getContactMediums().size() == 2
        individual.getContactMediums().get(0).getMediumType() == "email"
        individual.getContactMediums().get(1).getMediumType() == "cbr"
        individual.getAccounts().size() == 1
        individual.getAccounts().get(0).id == "551796831595"
    }

    def "get CPNI contact info success with accountId with individualId in response"() {
        given:
        String accountId = "551796831595"
        String accountType = "wireless"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("accountId", accountId)
        headers.put("accountType", accountType)
        featureManager.isEnabled("svc-idgraph-cpnicontactinfo-enable-individualid-in-response") >> true;
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);

        cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> getMockCGCustomerV4Data("mock-customer-v4-data.json")
        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //added this logic to exclude idp-trace-id from api response while deserializing to Individual object
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode individualNode = rootNode.get("individual");
        Individual individual = objectMapper.treeToValue(individualNode, Individual.class);
        then:
        response.statusCode() == 200
        response.then()
                .body("individual", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
                .body("errors", CoreMatchers.nullValue())
        individual.getId() == "6a9f7b99-214e-44af-8f7c-2336b834fc70"
        individual.getContactMediums().size() == 2
        individual.getContactMediums().get(0).getMediumType() == "email"
        individual.getContactMediums().get(1).getMediumType() == "cbr"
        individual.getAccounts().size() == 1
        individual.getAccounts().get(0).id == "551796831595"
    }

    def "get CPNI contact info success with legacy wireless accountId"() {
        given:
        String accountId = "177333434256"
        String accountType = "wireless"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("accountId", accountId)
        headers.put("accountType", accountType)
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> getMockCGCustomerV4Data("mock-customer-v4-legacy-wireless-data.json")
        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //added this logic to exclude idp-trace-id from api response while deserializing to Individual object
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode individualNode = rootNode.get("individual");
        Individual individual = objectMapper.treeToValue(individualNode, Individual.class);
        then:
        response.statusCode() == 200
        response.then()
                .body("individual", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
                .body("errors", CoreMatchers.nullValue())
        individual.getContactMediums().size() == 3
        individual.getContactMediums().get(0).getMediumType() == "email"
        individual.getContactMediums().get(1).getMediumType() == "cbr"
        individual.getContactMediums().get(2).getMediumType() == "cbr"
        individual.getAccounts().size() == 1
        individual.getAccounts().get(0).id == "177333434256"
        individual.getAccounts().get(0).getSubscribers().size() == 1
    }


    def "get CPNI contact info success with legacy uverse accountId"() {
        given:
        String accountId = "303112330"
        String accountType = "uverse"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("accountId", accountId)
        headers.put("accountType", accountType)
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> getMockCGCustomerV4Data("mock-customer-v4-legacy-uverse-data.json")
        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //added this logic to exclude idp-trace-id from api response while deserializing to Individual object
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode individualNode = rootNode.get("individual");
        Individual individual = objectMapper.treeToValue(individualNode, Individual.class);
        then:
        response.statusCode() == 200
        response.then()
                .body("individual", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
                .body("errors", CoreMatchers.nullValue())
        individual.getContactMediums().size() == 3
        individual.getContactMediums().get(0).getMediumType() == "email"
        individual.getContactMediums().get(1).getMediumType() == "cbr"
        individual.getContactMediums().get(2).getMediumType() == "cbr"
        individual.getAccounts().size() == 1
        individual.getAccounts().get(0).id == "303112330"
    }


    def "get CPNI contact info success with accountId with exploitable Y"() {
        given:
        String accountId = "551796831595"
        String accountType = "wireless"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("accountId", accountId)
        headers.put("accountType", accountType)
        headers.put("exploitable", "Y")
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> getMockCGCustomerV4Data("mock-customer-v4-data.json")
        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //added this logic to exclude idp-trace-id from api response while deserializing to Individual object
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode individualNode = rootNode.get("individual");
        Individual individual = objectMapper.treeToValue(individualNode, Individual.class);
        then:
        response.statusCode() == 200
        response.then()
                .body("individual", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
                .body("errors", CoreMatchers.nullValue())
        individual.getContactMediums().size() == 0
        individual.getAccounts().size() == 1
        individual.getAccounts().get(0).id == "551796831595"
        individual.getAccounts().get(0).getContacts().get(0).getContactMediums().size() == 0
        individual.getAccounts().get(0).getSubscribers().size() == 1
        individual.getAccounts().get(0).getSubscribers().get(0).getSubscriberId() == "2298956544"

    }

    def "get CPNI contact info success with accountId with accountType B"() {
        given:
        String accountId = "551796831595"
        String accountType = "wireless"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("accountId", accountId)
        headers.put("accountType", accountType)
        headers.put("exploitable", "Y")
        headers.put("returnBizCTNs", "Y")
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> getMockCGCustomerV4Data("mock-customer-v4-data-accountType_B.json")
        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //added this logic to exclude idp-trace-id from api response while deserializing to Individual object
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode individualNode = rootNode.get("individual");
        Individual individual = objectMapper.treeToValue(individualNode, Individual.class);
        then:
        response.statusCode() == 200
        response.then()
                .body("individual", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
                .body("errors", CoreMatchers.nullValue())
        individual.getContactMediums().size() == 0
        individual.getAccounts().size() == 1
        individual.getAccounts().get(0).id == "551796831595"
        individual.getAccounts().get(0).getContacts().get(0).getContactMediums().size() == 0
        individual.getAccounts().get(0).getSubscribers().size() == 2
        individual.getAccounts().get(0).getSubscribers().get(0).getSubscriberId() == "2298956545"
        individual.getAccounts().get(0).getSubscribers().get(1).getSubscriberId() == "2298956544"

    }

    def "get CPNI contact info success with accountId with exploitable Y and cpniEligible as false"() {
        given:
        String accountId = "551796831595"
        String accountType = "wireless"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("accountId", accountId)
        headers.put("accountType", accountType)
        headers.put("exploitable", "Y")
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> getMockCGCustomerV4DataWithCpniEligibleAsFalseForWireless("mock-customer-v4-data.json")
        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //added this logic to exclude idp-trace-id from api response while deserializing to Individual object
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode individualNode = rootNode.get("individual");
        Individual individual = objectMapper.treeToValue(individualNode, Individual.class);
        then:
        response.statusCode() == 200
        response.then()
                .body("individual", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
                .body("errors", CoreMatchers.nullValue())
        individual.getContactMediums().size() == 0
        individual.getAccounts().size() == 1
        individual.getAccounts().get(0).id == "551796831595"
        individual.getAccounts().get(0).getContacts().get(0).getContactMediums().size() == 0
        individual.getAccounts().get(0).getSubscribers().size() == 0
    }

    def "get CPNI contact info success with accountId with exploitable Y for fiber account"() {
        given:
        String accountId = "551796831595"
        String accountType = "fiber"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("accountId", accountId)
        headers.put("accountType", accountType)
        headers.put("exploitable", "Y")
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> getMockCGCustomerV4Data("mock-customer-v4-data_fiber_account.json")
        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //added this logic to exclude idp-trace-id from api response while deserializing to Individual object
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode individualNode = rootNode.get("individual");
        Individual individual = objectMapper.treeToValue(individualNode, Individual.class);
        then:
        response.statusCode() == 200
        response.then()
                .body("individual", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
                .body("errors", CoreMatchers.nullValue())
        individual.getContactMediums().size() == 2
        individual.getContactMediums().get(0).getMediumType() == "email"
        individual.getContactMediums().get(1).getMediumType() == "cbr"
        individual.getAccounts().size() == 1
        individual.getAccounts().get(0).id == "551796831595"
        individual.getAccounts().get(0).getContacts().get(0).getContactMediums().size() == 1
        individual.getAccounts().get(0).getContacts().get(0).getContactMediums().get(0).getMediumType() == "postalAddress"
        individual.getAccounts().get(0).getSubscribers().size() == 0
    }

    def "get CPNI contact info success with accountId with exploitable Y for fiber account with cpniEligible false"() {
        given:
        String accountId = "551796831595"
        String accountType = "fiber"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("accountId", accountId)
        headers.put("accountType", accountType)
        headers.put("exploitable", "Y")
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> getMockCGCustomerV4DataWithCpniEligibleAsFalse("mock-customer-v4-data_fiber_account.json")
        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //added this logic to exclude idp-trace-id from api response while deserializing to Individual object
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode individualNode = rootNode.get("individual");
        Individual individual = objectMapper.treeToValue(individualNode, Individual.class);
        then:
        response.statusCode() == 200
        response.then()
                .body("individual", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
                .body("errors", CoreMatchers.nullValue())
        individual.getContactMediums().size() == 0
        individual.getAccounts().size() == 1
        individual.getAccounts().get(0).id == "551796831595"
        individual.getAccounts().get(0).getContacts().get(0).getContactMediums().size() == 1
        individual.getAccounts().get(0).getSubscribers().size() == 0
    }

    def "get CPNI contact error from profilems"() {
        given:
        String individualId = "123456789"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("individualId", individualId)
        ServiceException ex = new ServiceException(ErrorMessages.MS_MPSYS_BE_363,"data not found")
        profileHelper.profileMsSearchByIndividualId(_ as String,_ as Map)>> {throw ex}

        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //added this logic to exclude idp-trace-id from api response while deserializing to Individual object
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode error = rootNode.get("error");
        ServiceError serviceError = objectMapper.treeToValue(error, ServiceError.class);

        then:
        response.statusCode() == 404
        response.then()
                .body("error", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
        serviceError.errorId == "MS_MPSYS_BE_363"

    }

    def "get CPNI contact error from customer graph"() {
        given:
        String accountId = "6354937252"
        String accountType = "wireless"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("accountId", accountId)
        headers.put("accountType", accountType)
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        ServiceException ex = new ServiceException(ErrorMessages.MS_MPSYS_BE_363,"data not found")
        cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> {throw ex}

        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //added this logic to exclude idp-trace-id from api response while deserializing to Individual object
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode error = rootNode.get("error");
        ServiceError serviceError = objectMapper.treeToValue(error, ServiceError.class);

        then:
        response.statusCode() == 404
        response.then()
                .body("error", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
        serviceError.errorId == "MS_MPSYS_BE_363"

    }

    def "get CPNI contact system error from profilems"() {
        given:
        String individualId = "123456789"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("individualId", individualId)
        ServiceException ex = new ServiceException(ErrorMessages.MS_MPSYS_BE_610,"Error from ProfileMs API :IndividualContactInfo")
        profileHelper.profileMsSearchByIndividualId(_ as String,_ as Map)>> {throw ex}

        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //added this logic to exclude idp-trace-id from api response while deserializing to Individual object
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode error = rootNode.get("error");
        ServiceError serviceError = objectMapper.treeToValue(error, ServiceError.class);
        then:
        response.statusCode() == 500
        response.then()
                .body("error", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
        serviceError.errorId == "MS_MPSYS_BE_610"

    }

    def "get CPNI contact system error from customer graph"() {
        given:
        String accountId = "6354937252 "
        String accountType = "wireless"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("accountId", accountId)
        headers.put("accountType", accountType)
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        ServiceException ex = new ServiceException(ErrorMessages.MS_MPSYS_BE_610,"Error from CG API : UnifiedV4Customer")
        cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> {throw ex}

        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //added this logic to exclude idp-trace-id from api response while deserializing to Individual object
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode error = rootNode.get("error");
        ServiceError serviceError = objectMapper.treeToValue(error, ServiceError.class);
        then:
        response.statusCode() == 500
        response.then()
                .body("error", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
        serviceError.errorId == "MS_MPSYS_BE_610"

    }

    def "get CPNI contact info invalid client id"() {
        given:
        String individualId = "invalid"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("individualId", individualId)


        when:
        def response = givenBaseSpec().headers(headers + ["X-ATT-ClientId": "INVALID"]).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        //added this logic to exclude idp-trace-id from api response while deserializing to Individual object
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode error = rootNode.get("error");
        ServiceError serviceError = objectMapper.treeToValue(error, ServiceError.class);
        then:
        response.statusCode() == 400
        response.then()
                .body("error", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
        serviceError.errorId == "MS_MPSYS_BE_100"
    }

    def "cpniContactInfo with companion subscriber should return cpniEligible=false for that CTN"() {
        given: "account ID with a companion duoIdentifier subscriber"
        String accountId = "177333434256"
        String accountType = "wireless"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("accountId", accountId)
        headers.put("accountType", accountType)
        headers.put("exploitable", "Y")
        HashMap<String, Object> cgInput = new HashMap<>()
        cgInput.put("accountID", accountId)
        cgInput.put("accountType", accountType)
        cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> getMockCGCustomerV4Data("mock-customer-v4-legacy-wireless-data.json")

        when: "the API is called"
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString())
        JsonNode individualNode = rootNode.get("individual")
        Individual individual = objectMapper.treeToValue(individualNode, Individual.class)

        then: "response is successful"
        response.statusCode() == 200
        response.then()
                .body("individual", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
                .body("errors", CoreMatchers.nullValue())

        and: "account has one companion subscriber"
        individual.getAccounts().size() == 1
        individual.getAccounts().get(0).id == "177333434256"
        individual.getAccounts().get(0).getSubscribers().size() == 0

        and: "companion subscriber (9453289083) is excluded from CPNI eligibility"
        individual.getAccounts().get(0).getSubscribers().find { it.subscriberId == "9453289083" } == null
    }

    def "get CPNI contact info success with subscriberNumber"() {
        given:
        String subscriberNumber = "1234567890"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("subscriberNumber", subscriberNumber)
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("phoneNumber", subscriberNumber);
        cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> getMockCGCustomerV4Data("mock-customer-v4-data.json")
        
        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode individualNode = rootNode.get("individual");
        Individual individual = objectMapper.treeToValue(individualNode, Individual.class);
        
        then:
        response.statusCode() == 200
        response.then()
                .body("individual", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
                .body("errors", CoreMatchers.nullValue())
        individual.getContactMediums().size() == 2
        individual.getContactMediums().get(0).getMediumType() == "email"
        individual.getContactMediums().get(1).getMediumType() == "cbr"
        individual.getAccounts().size() == 1
        individual.getAccounts().get(0).id == "551796831595"
    }

    def "get CPNI contact info success with subscriberNumber with exploitable Y"() {
        given:
        String subscriberNumber = "1234567890"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("subscriberNumber", subscriberNumber)
        headers.put("exploitable", "Y")
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("phoneNumber", subscriberNumber);
        cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> getMockCGCustomerV4Data("mock-customer-v4-data.json")
        
        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode individualNode = rootNode.get("individual");
        Individual individual = objectMapper.treeToValue(individualNode, Individual.class);
        
        then:
        response.statusCode() == 200
        response.then()
                .body("individual", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
                .body("errors", CoreMatchers.nullValue())
        individual.getContactMediums().size() == 0
        individual.getAccounts().size() == 1
        individual.getAccounts().get(0).id == "551796831595"
        individual.getAccounts().get(0).getContacts().get(0).getContactMediums().size() == 0
        individual.getAccounts().get(0).getSubscribers().size() == 1
        individual.getAccounts().get(0).getSubscribers().get(0).getSubscriberId() == "2298956544"
    }

    def "get CPNI contact info success with subscriberNumber with individualId in response"() {
        given:
        String subscriberNumber = "1234567890"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("subscriberNumber", subscriberNumber)
        featureManager.isEnabled("svc-idgraph-cpnicontactinfo-enable-individualid-in-response") >> true;
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("phoneNumber", subscriberNumber);
        cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> getMockCGCustomerV4Data("mock-customer-v4-data.json")
        
        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode individualNode = rootNode.get("individual");
        Individual individual = objectMapper.treeToValue(individualNode, Individual.class);
        
        then:
        response.statusCode() == 200
        response.then()
                .body("individual", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
                .body("errors", CoreMatchers.nullValue())
        individual.getId() == "6a9f7b99-214e-44af-8f7c-2336b834fc70"
        individual.getContactMediums().size() == 2
        individual.getContactMediums().get(0).getMediumType() == "email"
        individual.getContactMediums().get(1).getMediumType() == "cbr"
        individual.getAccounts().size() == 1
        individual.getAccounts().get(0).id == "551796831595"
    }

    def "get CPNI contact error from customer graph with subscriberNumber"() {
        given:
        String subscriberNumber = "1234567890"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("subscriberNumber", subscriberNumber)
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("phoneNumber", subscriberNumber);
        ServiceException ex = new ServiceException(ErrorMessages.MS_MPSYS_BE_363,"data not found")
        cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> {throw ex}

        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode error = rootNode.get("error");
        ServiceError serviceError = objectMapper.treeToValue(error, ServiceError.class);

        then:
        response.statusCode() == 404
        response.then()
                .body("error", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
        serviceError.errorId == "MS_MPSYS_BE_363"
    }

    def "get CPNI contact system error from customer graph with subscriberNumber"() {
        given:
        String subscriberNumber = "1234567890"
        String uri = "/cpniContactInfo/"
        Map<String, String> headers = getHeaders()
        headers.put("subscriberNumber", subscriberNumber)
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("phoneNumber", subscriberNumber);
        ServiceException ex = new ServiceException(ErrorMessages.MS_MPSYS_BE_610,"Error from CG API : UnifiedV4Customer")
        cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> {throw ex}

        when:
        def response = givenBaseSpec().headers(headers).get(uri)
        ObjectMapper objectMapper = new ObjectMapper()
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        JsonNode rootNode = objectMapper.readTree(response.getBody().asString());
        JsonNode error = rootNode.get("error");
        ServiceError serviceError = objectMapper.treeToValue(error, ServiceError.class);
        
        then:
        response.statusCode() == 500
        response.then()
                .body("error", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
        serviceError.errorId == "MS_MPSYS_BE_610"
    }

    private static CGIndividualInfo getMockIndividualProfileData() {
        ObjectMapper mapper = new ObjectMapper()
        try {
            // Use getResourceAsStream to avoid NullPointerException
            InputStream inputStream = CPNIContactInfoCompTest.class.getClassLoader().getResourceAsStream("mock-profile-individual-data.json")
            if (inputStream == null) {
                throw new RuntimeException("Resource file 'mock-profile-individual-data.json' not found")
            }
            return mapper.readValue(inputStream, CGIndividualInfo)
        } catch (Exception e) {
            throw new RuntimeException("Failed to load mock profile data", e)
        }
    }

    private static CustomerV4Response getMockCGCustomerV4Data(String inputJson) {
        ObjectMapper mapper = new ObjectMapper()
        try {
            // Use getResourceAsStream to avoid NullPointerException
            InputStream inputStream = CPNIContactInfoCompTest.class.getClassLoader().getResourceAsStream(inputJson)
            if (inputStream == null) {
                throw new RuntimeException("Resource file {} not found" , inputJson)
            }
            return mapper.readValue(inputStream, CustomerV4Response)
        } catch (Exception e) {
            throw new RuntimeException("Failed to load mock profile data", e)
        }
    }

    private static CustomerV4Response getMockCGCustomerV4DataWithCpniEligibleAsFalse(String inputJson) {
        ObjectMapper mapper = new ObjectMapper()
        try {
            // Use getResourceAsStream to avoid NullPointerException
            InputStream inputStream = CPNIContactInfoCompTest.class.getClassLoader().getResourceAsStream(inputJson)
            if (inputStream == null) {
                throw new RuntimeException("Resource file {} not found",inputJson)
            }
            CustomerV4Response customerV4Response = mapper.readValue(inputStream, CustomerV4Response)
            String now = ZonedDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));

            customerV4Response.getIndividual().getContactMedium().get(0).getCharacteristic().setEstablishmentDate(now)
            customerV4Response.getIndividual().getContactMedium().get(1).getCharacteristic().setEstablishmentDate(now)
           // customerV4Response.getIndividual().getAccounts().get(0).setCreatedOn(now);
            customerV4Response.getIndividual().getAccounts().get(0).getContact().get(0)
                    .getContactMedium().get(0).getCharacteristic().setEstablishmentDate(now)
            return customerV4Response;
        } catch (Exception e) {
            throw new RuntimeException("Failed to load mock profile data", e)
        }
    }

    private static CustomerV4Response getMockCGCustomerV4DataWithCpniEligibleAsFalseForWireless(String inputJson) {
        ObjectMapper mapper = new ObjectMapper()
        try {
            // Use getResourceAsStream to avoid NullPointerException
            InputStream inputStream = CPNIContactInfoCompTest.class.getClassLoader().getResourceAsStream(inputJson)
            if (inputStream == null) {
                throw new RuntimeException("Resource file {} not found",inputJson)
            }
            CustomerV4Response customerV4Response = mapper.readValue(inputStream, CustomerV4Response)
            String now = ZonedDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));

            customerV4Response.getIndividual().getContactMedium().get(0).getCharacteristic().setEstablishmentDate(now)
            customerV4Response.getIndividual().getContactMedium().get(1).getCharacteristic().setEstablishmentDate(now)
            customerV4Response.getIndividual().getAccounts().get(0).getContact().get(0)
                    .getContactMedium().get(0).getCharacteristic().setEstablishmentDate(now)

            customerV4Response.getIndividual().getAccounts().get(0).getSubscribers().get(0).getStatus().setStatus("suspended")
            customerV4Response.getIndividual().getAccounts().get(0).getSubscribers().get(1).getStatus().setStatus("suspended")

            return customerV4Response;
        } catch (Exception e) {
            throw new RuntimeException("Failed to load mock profile data", e)
        }
    }
}