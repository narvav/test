package com.att.idp.component

import org.springframework.boot.autoconfigure.kafka.KafkaProperties
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.context.annotation.Configuration

/**
* Provides KafkaProperties bean for component tests.
* The IDP KafkaAutoConfiguration (from idp-spring-boot-autoconfigure) is loaded
* via @ComponentScan(basePackages = "com.att") and requires KafkaProperties.
* Spring Boot's KafkaAutoConfiguration (which normally provides KafkaProperties)
* is excluded in tests, so this config fills the gap without enabling the full
* Kafka auto-configuration.
*/
@Configuration
@EnableConfigurationProperties(KafkaProperties.class)
class TestKafkaPropertiesConfig {
}
