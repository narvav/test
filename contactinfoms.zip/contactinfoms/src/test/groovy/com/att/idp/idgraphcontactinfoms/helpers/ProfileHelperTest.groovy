package com.att.idp.idgraphcontactinfoms.helpers

import com.att.idp.cgclienthelpers.integration.ProfileRestClient
import com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig
import com.att.idp.idgraphcontactinfoms.integration.OutboundRestClientBuilder
import com.att.idp.http.client.config.RestTemplateBeanFactory
import io.swagger.client.model.CGIndividualInfo
import jakarta.ws.rs.core.MultivaluedMap
import org.springframework.test.util.ReflectionTestUtils
import org.springframework.web.client.RestTemplate
import spock.lang.Specification
import spock.lang.Unroll

class ProfileHelperTest extends Specification {

    ProfileRestClient profileRestClient
    RestTemplateBeanFactory restTemplateBeanFactory
    IDGraphAzureAppConfig appConfiguration
    OutboundRestClientBuilder outboundRestClientBuilder
    RestTemplate restTemplate
    ProfileHelper profileHelper

    def setup() {
        profileRestClient = Mock(ProfileRestClient)
        restTemplateBeanFactory = Mock(RestTemplateBeanFactory)
        appConfiguration = Mock(IDGraphAzureAppConfig)
        outboundRestClientBuilder = Mock(OutboundRestClientBuilder)
        restTemplate = Mock(RestTemplate)
        profileHelper = new ProfileHelper(restTemplateBeanFactory, appConfiguration, outboundRestClientBuilder)
        ReflectionTestUtils.setField(profileHelper, 'profileRestClient', profileRestClient)
        ReflectionTestUtils.setField(profileHelper, 'restTemplate', restTemplate)
        ReflectionTestUtils.setField(profileHelper, 'appConfiguration', appConfiguration)
        ReflectionTestUtils.setField(profileHelper, 'restTemplateFactory', restTemplateBeanFactory)
        ReflectionTestUtils.setField(profileHelper, 'outboundRestClientBuilder', outboundRestClientBuilder)
    }

    def "should initialize restTemplate in init()"() {
        given:
        RestTemplate initializedRestTemplate = Mock(RestTemplate)
        appConfiguration.getProfileConnectTimeout() >> 1000
        appConfiguration.getProfileReadTimeout() >> 2000
        restTemplateBeanFactory.getObject() >> restTemplate
        outboundRestClientBuilder.buildRestTemplate(restTemplate, 1000, 2000, false, null) >> initializedRestTemplate
        ReflectionTestUtils.setField(profileHelper, 'restTemplate', restTemplate)

        when:
        profileHelper.init()

        then:
        ReflectionTestUtils.getField(profileHelper, 'restTemplate') == initializedRestTemplate
    }

    @Unroll
    def "should handle configuration refresh event and update restTemplate for #scenarioName"() {
        given:
        appConfiguration.isProfileRestClientRefreshEnabled() >> refreshEnabled
        appConfiguration.getProfileConnectTimeout() >> connectTimeout
        appConfiguration.getProfileReadTimeout() >> readTimeout
        restTemplateBeanFactory.getObject() >> restTemplate
        outboundRestClientBuilder.buildRestTemplate(restTemplate, connectTimeout, readTimeout, false, null) >> updatedRestTemplate
        ReflectionTestUtils.setField(profileHelper, 'restTemplate', restTemplate)

        when:
        profileHelper.onConfigurationRefresh()

        then:
        ReflectionTestUtils.getField(profileHelper, 'restTemplate') == (refreshEnabled ? updatedRestTemplate : restTemplate)

        where:
        scenarioName         | refreshEnabled | connectTimeout | readTimeout | updatedRestTemplate
        "refresh enabled"   | true           | 1000          | 2000        | Mock(RestTemplate)
        "refresh disabled"  | false          | 1000          | 2000        | Mock(RestTemplate)
    }

    def "should retain old restTemplate if exception occurs during refresh"() {
        given:
        appConfiguration.isProfileRestClientRefreshEnabled() >> true
        appConfiguration.getProfileConnectTimeout() >> 1000
        appConfiguration.getProfileReadTimeout() >> 2000
        restTemplateBeanFactory.getObject() >> restTemplate
        outboundRestClientBuilder.buildRestTemplate(restTemplate, 1000, 2000, false, null) >> { throw new RuntimeException("fail") }
        ReflectionTestUtils.setField(profileHelper, 'restTemplate', restTemplate)

        when:
        profileHelper.onConfigurationRefresh()

        then:
        ReflectionTestUtils.getField(profileHelper, 'restTemplate') == restTemplate
    }

    def "should initialize restTemplate if null in onConfigurationRefresh"() {
        given:
        appConfiguration.isProfileRestClientRefreshEnabled() >> true
        appConfiguration.getProfileConnectTimeout() >> 1000
        appConfiguration.getProfileReadTimeout() >> 2000
        restTemplateBeanFactory.getObject() >> restTemplate
        outboundRestClientBuilder.buildRestTemplate(restTemplate, 1000, 2000, false, null) >> restTemplate
        ReflectionTestUtils.setField(profileHelper, 'restTemplate', null)

        when:
        profileHelper.onConfigurationRefresh()

        then:
        noExceptionThrown()
    }

    def "should build restTemplate in initializeRestTemplate"() {
        given:
        RestTemplate inputRestTemplate = Mock(RestTemplate)
        RestTemplate builtRestTemplate = Mock(RestTemplate)
        appConfiguration.getProfileConnectTimeout() >> 1000
        appConfiguration.getProfileReadTimeout() >> 2000
        outboundRestClientBuilder.buildRestTemplate(inputRestTemplate, 1000, 2000, false, null) >> builtRestTemplate
        ReflectionTestUtils.setField(profileHelper, 'restTemplateFactory', restTemplateBeanFactory)
        ReflectionTestUtils.setField(profileHelper, 'appConfiguration', appConfiguration)
        ReflectionTestUtils.setField(profileHelper, 'outboundRestClientBuilder', outboundRestClientBuilder)

        when:
        RestTemplate result = ReflectionTestUtils.invokeMethod(profileHelper, 'initializeRestTemplate', inputRestTemplate)

        then:
        result == builtRestTemplate
    }

    def "should handle exception in initializeRestTemplate and return input restTemplate"() {
        given:
        RestTemplate inputRestTemplate = Mock(RestTemplate)
        appConfiguration.getProfileConnectTimeout() >> 1000
        appConfiguration.getProfileReadTimeout() >> 2000
        outboundRestClientBuilder.buildRestTemplate(inputRestTemplate, 1000, 2000, false, null) >> { throw new RuntimeException("fail") }
        ReflectionTestUtils.setField(profileHelper, 'restTemplateFactory', restTemplateBeanFactory)
        ReflectionTestUtils.setField(profileHelper, 'appConfiguration', appConfiguration)
        ReflectionTestUtils.setField(profileHelper, 'outboundRestClientBuilder', outboundRestClientBuilder)

        when:
        RestTemplate result = ReflectionTestUtils.invokeMethod(profileHelper, 'initializeRestTemplate', inputRestTemplate)

        then:
        result == inputRestTemplate
    }

    def "should call profileRestClient.profileMsSearchByIndividualId and return result"() {
        given:
        String individualId = "id123"
        MultivaluedMap<String, String> requestHeaders = Mock(MultivaluedMap)
        CGIndividualInfo expectedInfo = Mock(CGIndividualInfo)
        ReflectionTestUtils.setField(profileHelper, 'restTemplate', restTemplate)
        profileRestClient.profileMsSearchByIndividualId(individualId, requestHeaders, restTemplate) >> expectedInfo

        when:
        CGIndividualInfo result = profileHelper.profileMsSearchByIndividualId(individualId, requestHeaders)

        then:
        1 * profileRestClient.profileMsSearchByIndividualId(individualId, requestHeaders, restTemplate) >> expectedInfo
        0 * _
        result == expectedInfo
    }
}

