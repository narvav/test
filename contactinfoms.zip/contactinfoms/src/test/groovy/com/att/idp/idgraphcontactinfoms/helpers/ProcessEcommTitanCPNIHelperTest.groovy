package com.att.idp.idgraphcontactinfoms.helpers

import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs
import spock.lang.Specification


class ProcessEcommTitanCPNIHelperTest extends Specification {
	
	def ProcessEcommTitanCPNIHelper objProcessEcommTitanCPNIHelper = new ProcessEcommTitanCPNIHelper()

    CPNIDataConsolidationHelper oCPNIConsolidationHelper = Mock(CPNIDataConsolidationHelper)

    QueryProfileProofingInfoHelper oQueryProfileProofingInfoH = Mock(QueryProfileProofingInfoHelper)

    InquireAccountContactInfoHelper oInquireAccountContactInfoHelper = Mock(InquireAccountContactInfoHelper)

    String stTransactionId = null
    HashMap resultHashSuccess = null
    HashMap resultHashError = null
    HashMap hmResult = null
    HashMap hmRes = CommonUtil.hashMap
    HashMap hmBDSResponse =null
    HashMap hmInput = CommonUtil.hashMap
    String stAppStatusMsg = null
    String stAppInfo = null
    ArrayList alAccountDetailResponse = CommonUtil.arrayList
    HashMap hmAnchorAccount = CommonUtil.hashMap
    HashMap hmAnchorAccounts = CommonUtil.hashMap
    HashMap hmAddressInfo = CommonUtil.hashMap
    HashMap hmAddrOfRecord = CommonUtil.hashMap
    HashMap hmCPNIConsHelperInput = CommonUtil.hashMap
    HashMap hmEmailAddresses = CommonUtil.hashMap
    ArrayList alResponse = CommonUtil.arrayList
    ArrayList alEmailAddresses = CommonUtil.arrayList


    def setup(){

        objProcessEcommTitanCPNIHelper.oCPNIConsolidationHelper = oCPNIConsolidationHelper
        objProcessEcommTitanCPNIHelper.oQueryProfileProofingInfoH = oQueryProfileProofingInfoH
        objProcessEcommTitanCPNIHelper.oInquireAccountContactInfoHelper = oInquireAccountContactInfoHelper

		stTransactionId = 'trma_123'

        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIAccountContactInfo'
        hmInput[CommonDefs.TRANSACTION_ID] = stTransactionId
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'CSRIDP'
        hmInput[CommonDefs.ACCOUNT_TYPE] = CommonDefs.MOBILITY_SERVICE
        hmInput[CommonDefs.ACCOUNT_INVARIANT_ID] = '23475940534'
        hmInput[CommonDefs.ACCOUNT_ID] = '32'
        hmInput['ignoreEmailStatusValidation'] = CommonDefs.IND_Y
        hmInput[CommonDefs.ACTIVATED_IND] = CommonDefs.IND_Y
        hmAddressInfo['AddressOfRecord'] = hmAddrOfRecord

        hmAnchorAccount[CommonDefs.CUSTOMER_ACTIVE_DATE] = '2018-10-23'
        hmAnchorAccount['EmailAddress'] = 'sp7569@att.com'
        hmAnchorAccount['EmailUndeliverableInd'] = CommonDefs.IND_Y
        hmAnchorAccount['EmailAddrLastUpdateTs'] = '2018-10-23'
        hmAnchorAccount[CommonDefs.KEY_ACCOUNT_STATUS] = 'V'
        hmAnchorAccount[CommonDefs.CUSTOMER_ACTIVE_DATE] = '2018-10-23'
        hmAnchorAccount[CommonDefs.KEY_DSL_DRY_LOOP_IND] = CommonDefs.IND_Y
        hmAnchorAccount[CommonDefs.SERVICE_NBR] = '2345'
        hmAnchorAccount[CommonDefs.KEY_ACCOUNT_ID] = '2345'
        hmAnchorAccount[CommonDefs.PROBATIONARY_BILLING_ADDRESS] = '2345'
        hmAnchorAccount['AddressInfo'] = hmAddressInfo

        hmAnchorAccounts['AnchorAccount'] = hmAnchorAccount
        alAccountDetailResponse.add(hmAnchorAccounts)

        hmEmailAddresses[CommonDefs.EMAIL_ADDRESS] = 'sp7569@att.com'
        hmEmailAddresses[CommonDefs.EMAIL_STATUS] = 'V'
        hmEmailAddresses[CommonDefs.KEY_EMAIL_ESTABLISHED_DATE] = '10232018 00:00:00'
        hmEmailAddresses[CommonDefs.KEY_ACCOUNT_ESTABLISHED_DATE] = '2018-10-23'
        alEmailAddresses.add(hmEmailAddresses)
        alResponse.add(hmRes)
        hmCPNIConsHelperInput['UverseEmailEstablishedDate'] = '10232018 00:00:00'
        hmCPNIConsHelperInput[CommonDefs.CUSTOMER_ACTIVE_DATE] = '10232018 00:00:00'
        hmCPNIConsHelperInput[CommonDefs.KEY_ACCOUNT_ID] = '2345'
        hmCPNIConsHelperInput[CommonDefs.CONTACT_EMAIL] = 'sp7569@att.com'
        hmCPNIConsHelperInput[CommonDefs.KEY_IGNORE_POSTAL_ADDRESS_VALIDATION] = CommonDefs.IND_Y
        hmCPNIConsHelperInput[CommonDefs.SERVICE_NBR] = '2345'
        hmCPNIConsHelperInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIAccountContactInfo'
        hmCPNIConsHelperInput[CommonDefs.TRANSACTION_ID] = stTransactionId
        hmCPNIConsHelperInput[CommonDefs.CALLING_SYSTEM_ID] = 'CSRIDP'
        hmCPNIConsHelperInput['UverseMemberEmailAddress'] = 'sp7569@att.com'
        hmCPNIConsHelperInput[CommonDefs.KEY_ACCOUNT_STATUS] = 'V'
        hmCPNIConsHelperInput[CommonDefs.KEY_EMAIL_ADDRESSES] = alEmailAddresses
        hmCPNIConsHelperInput[CommonDefs.POSTAL_ADDRESS] = alResponse
        hmCPNIConsHelperInput[CommonDefs.KEY_PROBATIONARY_ADDRESS_IND] = CommonDefs.IND_Y
        hmCPNIConsHelperInput['UverseEmailStatus'] = 'V'
        hmCPNIConsHelperInput[CommonDefs.KEY_DSL_DRY_LOOP_IND] = CommonDefs.IND_Y
        hmCPNIConsHelperInput[CommonDefs.ACTIVATED_IND] = CommonDefs.IND_Y
        hmCPNIConsHelperInput['NewCPNIEilibilityRule'] = CommonDefs.IND_Y

        hmBDSResponse= CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG)
        resultHashError= CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, CErrorDefs.ERR_INVALID_DATA)
    }


    def "test process ecomm titan c p n i empty input"() {
        when:
        hmResult = objProcessEcommTitanCPNIHelper.processEcommTitanCPNI(null, hmBDSResponse)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Input Hash is null or empty'
    }


    def "test process ecomm titan c p n i hm b d s response error"() {
        given:
        hmBDSResponse[CommonDefs.COMMON_APP_INFO] = CErrorDefs.ERR_INVALID_DATA
        hmBDSResponse[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.CATEGORY_CODE_SYSTEM_ERROR
        hmBDSResponse[CommonDefs.COMMON_APP_CATEGORY_CODE] = CErrorDefs.CATEGORY_CODE_SYSTEM_ERROR
        when:
        hmResult = objProcessEcommTitanCPNIHelper.processEcommTitanCPNI(hmInput, hmBDSResponse)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == CErrorDefs.ERR_INVALID_DATA
    }


    def "test process ecomm titan c p n i hm b d s response account not found"() {
        given:
        hmBDSResponse[CommonDefs.COMMON_APP_INFO] = CErrorDefs.ERR_INVALID_DATA
        hmBDSResponse[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.CATEGORY_CODE_SYSTEM_ERROR
        when:
        hmResult = objProcessEcommTitanCPNIHelper.processEcommTitanCPNI(hmInput, hmBDSResponse)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == CErrorDefs.ERR_ACCOUNT_NOT_FOUND_MSG
    }


    def "test process ecomm titan c p n i account detail response empty"() {
        when:
        hmResult = objProcessEcommTitanCPNIHelper.processEcommTitanCPNI(hmInput, hmBDSResponse)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'AccountDetailResponse is null or empty in BDS response'
    }


    def "test process ecomm titan c p n i c p n i consolidation helper returns null"() {
        given:
        hmAnchorAccount['EmailAddrLastUpdateTs'] = '2018-10-23'
        hmAnchorAccount['EmailUndeliverableInd'] = '0'
        oCPNIConsolidationHelper.generateCPNIConsolidation(_)>>null
        hmBDSResponse['AccountDetailResponse'] = alAccountDetailResponse
        when:
        hmResult = objProcessEcommTitanCPNIHelper.processEcommTitanCPNI(hmInput, hmBDSResponse)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'null Hash returned from CPNIConsolidationHelper.generateCPNIConsolidation() '
    }


    def "test process ecomm titan c p n i c p n i consolidation helper returns excp"() {
        when:
        hmResult = objProcessEcommTitanCPNIHelper.processEcommTitanCPNI(hmInput, null)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "test call c p n i cons helper c p n i consolidation helper returns err"() {
        given:
        hmInput[CommonDefs.ACCOUNT_TYPE] = CommonDefs.TITAN_SERVICE
        hmCPNIConsHelperInput.remove(CommonDefs.KEY_ACCOUNT_ID)
        oCPNIConsolidationHelper.generateCPNIConsolidation(_)>>resultHashError
        hmBDSResponse['AccountDetailResponse'] = alAccountDetailResponse
        when:
        hmResult = objProcessEcommTitanCPNIHelper.callCPNIConsHelper(hmInput, hmBDSResponse)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == CErrorDefs.ERR_INVALID_DATA
    }


    def "test call c p n i cons helper anchor account null"() {
        given:
        hmAnchorAccounts['AnchorAccount'] = null
        hmBDSResponse['AccountDetailResponse'] = alAccountDetailResponse
        when:
        hmResult = objProcessEcommTitanCPNIHelper.callCPNIConsHelper(hmInput, hmBDSResponse)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'AnchorAccount is null or empty in BDS response'
    }


    def "test call c p n i cons helper hm b d s response null"() {
        when:
        hmResult = objProcessEcommTitanCPNIHelper.callCPNIConsHelper(hmInput, null)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "test c p n i cons helper process c b r c t ns a c c o u n t t y p e titan"() {
        given:
        HashMap hmCBRInfo = CommonUtil.hashMap
        HashMap hmGetAuthInfoResp = CommonUtil.hashMap
        hmCBRInfo[CommonDefs.DEVICE_IN_HAND_VALIDATION_STS] = '8'
        hmCBRInfo[CommonDefs.PHONE] = '0'
        hmCBRInfo[CommonDefs.PHONE_MODIFIED_DATE] = '0'
        hmCBRInfo[CommonDefs.PHONE_TYPE] = "Mobile"
        hmCBRInfo[CommonDefs.IS_ATT_NUMBER] = '0'
        hmCBRInfo[CommonDefs.SUBSCRIBER_ID] = '1'

        hmGetAuthInfoResp[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
        hmGetAuthInfoResp[CommonDefs.CBR_INFO] = hmCBRInfo
        hmGetAuthInfoResp[CommonDefs.ALT_CBR_INFO] = hmCBRInfo

        hmInput['returnCBRCTNs'] = CommonDefs.IND_Y

        hmInput[CommonDefs.ACCOUNT_TYPE] = CommonDefs.TITAN_SERVICE
        oCPNIConsolidationHelper.generateCPNIConsolidation(_)>>resultHashError
        oQueryProfileProofingInfoH.queryCRMProofingInfo(_)>>hmGetAuthInfoResp
        hmBDSResponse['AccountDetailResponse'] = alAccountDetailResponse
        when:
        hmResult = objProcessEcommTitanCPNIHelper.callCPNIConsHelper(hmInput, hmBDSResponse)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == CErrorDefs.ERR_INVALID_DATA
    }
    def "test cpni cons helper process cbrctns account type titan2"() {
        given:
        HashMap hmCBRInfo = CommonUtil.hashMap
        HashMap hmGetAuthInfoResp = CommonUtil.hashMap
        hmCBRInfo[CommonDefs.DEVICE_IN_HAND_VALIDATION_STS] = '8'
        hmCBRInfo[CommonDefs.PHONE] = '0'
        hmCBRInfo[CommonDefs.PHONE_MODIFIED_DATE] = '0'
        hmCBRInfo[CommonDefs.PHONE_TYPE] = "Cell Phone"
        hmCBRInfo[CommonDefs.IS_ATT_NUMBER] = '0'
        hmCBRInfo[CommonDefs.SUBSCRIBER_ID] = '1'

        hmGetAuthInfoResp[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
        hmGetAuthInfoResp[CommonDefs.CBR_INFO] = hmCBRInfo
        hmGetAuthInfoResp[CommonDefs.ALT_CBR_INFO] = hmCBRInfo

        hmInput['returnCBRCTNs'] = CommonDefs.IND_Y

        hmInput[CommonDefs.ACCOUNT_TYPE] = CommonDefs.TITAN_SERVICE
        oCPNIConsolidationHelper.generateCPNIConsolidation(_)>>resultHashError
        oQueryProfileProofingInfoH.queryCRMProofingInfo(_)>>hmGetAuthInfoResp
        hmBDSResponse['AccountDetailResponse'] = alAccountDetailResponse
        when:
        hmResult = objProcessEcommTitanCPNIHelper.callCPNIConsHelper(hmInput, hmBDSResponse)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == CErrorDefs.ERR_INVALID_DATA
    }
    def "test cpni cons helper process cbrctns account type titan3"() {
        given:
        HashMap hmCBRInfo = CommonUtil.hashMap
        HashMap hmGetAuthInfoResp = CommonUtil.hashMap
        hmCBRInfo[CommonDefs.DEVICE_IN_HAND_VALIDATION_STS] = '8'
        hmCBRInfo[CommonDefs.PHONE] = '0'
        hmCBRInfo[CommonDefs.PHONE_MODIFIED_DATE] = '0'
        hmCBRInfo[CommonDefs.PHONE_TYPE] = "Cell Phone"
        hmCBRInfo[CommonDefs.IS_ATT_NUMBER] = '0'
        hmCBRInfo[CommonDefs.SUBSCRIBER_ID] = null

        hmGetAuthInfoResp[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
        hmGetAuthInfoResp[CommonDefs.CBR_INFO] = hmCBRInfo
        hmGetAuthInfoResp[CommonDefs.ALT_CBR_INFO] = hmCBRInfo

        hmInput['returnCBRCTNs'] = CommonDefs.IND_Y

        hmInput[CommonDefs.ACCOUNT_TYPE] = CommonDefs.TITAN_SERVICE
        oCPNIConsolidationHelper.generateCPNIConsolidation(_)>>resultHashError
        oQueryProfileProofingInfoH.queryCRMProofingInfo(_)>>hmGetAuthInfoResp
        hmBDSResponse['AccountDetailResponse'] = alAccountDetailResponse
        when:
        hmResult = objProcessEcommTitanCPNIHelper.callCPNIConsHelper(hmInput, hmBDSResponse)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == CErrorDefs.ERR_INVALID_DATA
    }


    def "test c p n i cons helper process c b r c t ns a c c o u n t t y p e e c o m m s e r v i c e"() {
        given:
        ArrayList alDBPhoneList = CommonUtil.arrayList
        HashMap hmInquireAcctContactResp = CommonUtil.hashMap
        HashMap hmAccountContacts = CommonUtil.hashMap
        hmAccountContacts[CommonDefs.DEVICE_IN_HAND_VALIDATION_STS] = '8'
        hmAccountContacts[CommonDefs.PHONE] = '0'
        hmAccountContacts[CommonDefs.PHONE_MODIFIED_DATE] = '0'
        hmAccountContacts[CommonDefs.PHONE_TYPE] = CommonDefs.PHONE_NUMBER_TYPE_MOBILE
        hmAccountContacts[CommonDefs.IS_ATT_NUMBER] = '0'
        hmAccountContacts[CommonDefs.SUBSCRIBER_ID] = '1'
        hmAccountContacts[CommonDefs.CONTACT_TYPE] = 'SPHONE'
        hmAccountContacts['dateEstablished'] = '09282014 06:15:47'
        hmAccountContacts[CommonDefs.CONTACT_STATUS] = 'V'
        hmAccountContacts[CommonDefs.VALIDATION_STATUS] = '8'
        hmAccountContacts[CommonDefs.KEY_SOR_NAME] = 'LS'
        hmAccountContacts['phoneList'] = alDBPhoneList
        alDBPhoneList.add(hmAccountContacts)

        hmInquireAcctContactResp[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
        hmInquireAcctContactResp[CommonDefs.CBR_INFO] = hmAccountContacts
        hmInquireAcctContactResp[CommonDefs.ALT_CBR_INFO] = hmAccountContacts
		hmInquireAcctContactResp['accountContacts'] = hmAccountContacts

		hmInput['returnCBRCTNs'] = CommonDefs.IND_Y

		hmInput[CommonDefs.ACCOUNT_TYPE] = CommonDefs.ECOMM_SERVICE
		oCPNIConsolidationHelper.generateCPNIConsolidation(_)>>resultHashError
		oInquireAccountContactInfoHelper.inquireAccountContactInfo(_)>>hmInquireAcctContactResp
		hmBDSResponse['AccountDetailResponse'] = alAccountDetailResponse
        when:
        hmResult = objProcessEcommTitanCPNIHelper.callCPNIConsHelper(hmInput, hmBDSResponse)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == CErrorDefs.ERR_INVALID_DATA
    }

    def "should set ignoreBDSError to IND_Y when sReturnCBRCTNs is IND_Y"() {
        given:
        HashMap<String, Object> hmInput = new HashMap<>()
        hmInput.put(CommonDefs.ACCOUNT_TYPE, CommonDefs.TITAN_SERVICE)
        hmInput.put("returnCBRCTNs", CommonDefs.IND_Y)
        HashMap<String, Object> hmBDSResponse = new HashMap<>()
        hmBDSResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)

        when:
        HashMap<String, Object> result = objProcessEcommTitanCPNIHelper.processEcommTitanCPNI(hmInput, hmBDSResponse)

        then:
        hmInput.get("ignoreBDSError") == CommonDefs.IND_Y
    }

    def "should process ACCOUNT_CONTACT_LIST and update response"() {
        given:
        //HashMap<String, Object> hmInput = new HashMap<>()
        hmInput.put(CommonDefs.ACCOUNT_TYPE, CommonDefs.TITAN_SERVICE)
        //HashMap<String, Object> hmBDSResponse = new HashMap<>()
        hmBDSResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        ArrayList<HashMap<String, Object>> alContactList = new ArrayList<>()
        HashMap<String, Object> contact = new HashMap<>()
        contact.put("contactName", "John Doe")
        alContactList.add(contact)
        HashMap<String, Object> hmCPNIConResponse = new HashMap<>()
        hmCPNIConResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        hmCPNIConResponse.put(CommonDefs.ACCOUNT_CONTACT_LIST, alContactList)
        hmBDSResponse['AccountDetailResponse'] = alAccountDetailResponse
        when:
        oCPNIConsolidationHelper.generateCPNIConsolidation(_) >> hmCPNIConResponse
        HashMap<String, Object> result = objProcessEcommTitanCPNIHelper.processEcommTitanCPNI(hmInput, hmBDSResponse)

        then:
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get(CommonDefs.COMMON_APP_INFO) == CommonDefs.COMMON_SUCCESS_MSG
        result.containsKey(CommonDefs.ACCOUNT_CONTACT_LIST)
        result.get(CommonDefs.ACCOUNT_CONTACT_LIST) == alContactList
    }

    def "should correctly format simSwapDateTime"() {
        given:
        String sDateKey = "simSwapDateTime"
        String sDateValue = "2023-10-01T12:00:00Z"
        String expectedFormattedDate = "10012023 07:00:00"

        when:
        String result = objProcessEcommTitanCPNIHelper.formatDate(sDateKey, sDateValue)

        then:
        result == expectedFormattedDate
    }

    def "should correctly format EmailAddrLastUpdateTs"() {
        given:
        String sDateKey = "EmailAddrLastUpdateTs"
        String sDateValue = "2023-10-01T12:00:00Z"
        String expectedFormattedDate = "10012023 00:00:00"

        when:
        String result = objProcessEcommTitanCPNIHelper.formatDate(sDateKey, sDateValue)

        then:
        result == expectedFormattedDate
    }
    def "should correctly format establishDate"() {
        given:
        String sDateKey = "establishDate"
        String sDateValue = "2023-10-01T12:00:00Z"
        String expectedFormattedDate = "10012023 00:00:00"

        when:
        String result = objProcessEcommTitanCPNIHelper.formatDate(sDateKey, sDateValue)

        then:
        result == expectedFormattedDate
    }
    def "should correctly format timeModified"() {
        given:
        String sDateKey = CommonDefs.TIME_MODIFIED
        String sDateValue = "2023-10-01T12:00:00Z"
        String expectedFormattedDate = "10012023 00:00:00"

        when:
        String result = objProcessEcommTitanCPNIHelper.formatDate(sDateKey, sDateValue)

        then:
        result == expectedFormattedDate
    }

    def "should process CBRCTNs for #scenarioName"() {
        given: "Input HashMap and account type"
        HashMap<String, Object> hmInput = new HashMap<>()
        hmInput.put(CommonDefs.TRANSACTION_ID, "txn123")
        hmInput.put(CommonDefs.TRANSACTION_NAME, "QueryCPNIAccountContactInfo")
        hmInput.put(CommonDefs.CALLING_SYSTEM_ID, "CSRIDP")
        hmInput.put(CommonDefs.ACCOUNT_TYPE, accountType)
        hmInput.put("skipAgingRuleFlag", skipAgingRuleFlag)
        hmInput.put("returnCBRCTNs", returnCBRCTNs)
        String sAcctSorInvId = "BAN123"

        HashMap<String, Object> hmCBRInfo = new HashMap<>()
        hmCBRInfo.put(CommonDefs.DEVICE_IN_HAND_VALIDATION_STS, deviceValidationStatus)
        hmCBRInfo.put(CommonDefs.PHONE, phone)
        hmCBRInfo.put(CommonDefs.PHONE_MODIFIED_DATE, phoneModifiedDate)
        hmCBRInfo.put(CommonDefs.PHONE_TYPE, phoneType)
        hmCBRInfo.put(CommonDefs.IS_ATT_NUMBER, isAttNumber)
        hmCBRInfo.put(CommonDefs.SUBSCRIBER_ID, subscriberId)

        HashMap<String, Object> hmGetAuthInfoResp = new HashMap<>()
        hmGetAuthInfoResp.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        hmGetAuthInfoResp.put(CommonDefs.CBR_INFO, hmCBRInfo)
        hmGetAuthInfoResp.put(CommonDefs.ALT_CBR_INFO, hmCBRInfo)

        1 * oQueryProfileProofingInfoH.queryCRMProofingInfo({ HashMap<String, String> param ->
            param.get(CommonDefs.TRANSACTION_ID) == "txn123" &&
                    param.get(CommonDefs.TRANSACTION_NAME) == "QueryCPNIAccountContactInfo" &&
                    param.get(CommonDefs.CALLING_SYSTEM_ID) == "CSRIDP" &&
                    param.get(CommonDefs.BAN) == sAcctSorInvId
        }) >> hmGetAuthInfoResp
        0 * _

        when: "processCBRCTNs is called"
        HashMap<String, Object> result = objProcessEcommTitanCPNIHelper.processCBRCTNs(hmInput, sAcctSorInvId)

        then: "Result contains expected CBRCTN list"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get(CommonDefs.COMMON_APP_INFO) == CommonDefs.COMMON_SUCCESS_MSG
        ArrayList<HashMap<String, Object>> cbrctnList = (ArrayList<HashMap<String, Object>>) result.get("CBRCTN")
        if (expectedCBRCTN) {
            cbrctnList != null
            cbrctnList.size() == 2
            cbrctnList[0].get(MPSDefs.DB_CONTACT_TYPE) == CommonDefs.CONTACT_TYPE_PRIMARY_PHONE
            cbrctnList[0].get(MPSDefs.DB_CONTACT_STATUS) == "V"
            cbrctnList[0].get(CommonDefs.KEY_PHONE) == phone
            cbrctnList[1].get(MPSDefs.DB_CONTACT_TYPE) == CommonDefs.CONTACT_TYPE_SECONDARY_PHONE
            cbrctnList[1].get(MPSDefs.DB_CONTACT_STATUS) == "V"
            cbrctnList[1].get(CommonDefs.KEY_PHONE) == phone
        } else {
            cbrctnList == null || cbrctnList.isEmpty()
        }

        where: "Different account types and validation scenarios"
        scenarioName                | accountType           | skipAgingRuleFlag | returnCBRCTNs | deviceValidationStatus | phone | phoneModifiedDate | phoneType   | isAttNumber | subscriberId | expectedCBRCTN
        "Titan valid CBR"           | CommonDefs.TITAN_SERVICE | CommonDefs.IND_N | CommonDefs.IND_Y | "8"                  | "5551234" | "2023-10-01"   | "Mobile"    | "0"         | "1"          | true
        "Titan skip aging rule"     | CommonDefs.TITAN_SERVICE | CommonDefs.IND_Y | CommonDefs.IND_Y | "7"                  | "5551234" | "2023-10-01"   | "Mobile"    | "0"         | "1"          | true
        "Titan invalid validation"  | CommonDefs.TITAN_SERVICE | CommonDefs.IND_N | CommonDefs.IND_Y | "7"                  | "5551234" | "2023-10-01"   | "Mobile"    | "0"         | "1"          | false
    }

    def "should process CBRCTNs for ECOMM_SERVICE for #scenarioName"() {
        given: "Input HashMap and account type"
        HashMap<String, Object> hmInput = new HashMap<>()
        hmInput.put(CommonDefs.TRANSACTION_ID, "txn123")
        hmInput.put(CommonDefs.TRANSACTION_NAME, "InquireAccountContactInfo")
        hmInput.put(CommonDefs.CALLING_SYSTEM_ID, "CSRIDP")
        hmInput.put(CommonDefs.ACCOUNT_TYPE, CommonDefs.ECOMM_SERVICE)
        hmInput.put("skipAgingRuleFlag", skipAgingRuleFlag)
        hmInput.put("returnCBRCTNs", CommonDefs.IND_Y)
        String sAcctSorInvId = "INV123"

        ArrayList<HashMap<String, Object>> phoneList = new ArrayList<>()
        HashMap<String, Object> phoneContact = new HashMap<>()
        phoneContact.put(CommonDefs.CONTACT_TYPE, contactType)
        phoneContact.put(CommonDefs.CONTACT_STATUS, contactStatus)
        phoneContact.put(CommonDefs.VALIDATION_STATUS, validationStatus)
        phoneContact.put(CommonDefs.PHONE_NUMBER, phoneNumber)
        phoneContact.put("dateEstablished", "09282014 06:15:47")
        phoneContact.put(CommonDefs.PHONE_NUMBER_TYPE, phoneNumberType)
        phoneList.add(phoneContact)

        HashMap<String, Object> accountContacts = new HashMap<>()
        accountContacts.put("phoneList", phoneList)

        HashMap<String, Object> inquireResp = new HashMap<>()
        inquireResp.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        inquireResp.put("accountContacts", accountContacts)

        1 * oInquireAccountContactInfoHelper.inquireAccountContactInfo({ HashMap<String, Object> param ->
            param.get(CommonDefs.TRANSACTION_ID) == "txn123" &&
                    param.get(CommonDefs.TRANSACTION_NAME) == "InquireAccountContactInfo" &&
                    param.get(CommonDefs.CALLING_SYSTEM_ID) == "CSRIDP" &&
                    param.get(CommonDefs.ACCOUNT_INVARIANT_ID) == sAcctSorInvId &&
                    param.get(CommonDefs.ACCOUNT_TYPE) == CommonDefs.ECOMM_SERVICE
        }) >> inquireResp
        0 * _

        when: "processCBRCTNs is called"
        HashMap<String, Object> result = objProcessEcommTitanCPNIHelper.processCBRCTNs(hmInput, sAcctSorInvId)

        then: "Result contains expected CBRCTN list"
        result != null
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get(CommonDefs.COMMON_APP_INFO) == CommonDefs.COMMON_SUCCESS_MSG
        ArrayList<HashMap<String, Object>> cbrctnList = (ArrayList<HashMap<String, Object>>) result.get("CBRCTN")
        if (expectedCBRCTN) {
            cbrctnList != null
            cbrctnList.size() == 1
            cbrctnList[0].get(MPSDefs.DB_CONTACT_TYPE) == contactType
            cbrctnList[0].get(MPSDefs.DB_CONTACT_STATUS) == contactStatus
            cbrctnList[0].get(CommonDefs.KEY_PHONE) == phoneNumber
            cbrctnList[0].get(CommonDefs.KEY_PHONE_EST_DATE) == "09282014 06:15:47"
            cbrctnList[0].get(CommonDefs.PHONE_NUMBER_TYPE) == phoneNumberType
        } else {
            cbrctnList == null || cbrctnList.isEmpty()
        }

        where: "Different phone validation scenarios"
        scenarioName         | contactType                      | contactStatus | validationStatus | phoneNumber | phoneNumberType | expectedCBRCTN | skipAgingRuleFlag
        "Valid phone"        | CommonDefs.CONTACT_TYPE_PRIMARY_PHONE | "V"         | "8"             | "5554321"   | CommonDefs.PHONE_NUMBER_TYPE_MOBILE | true | CommonDefs.IND_N
        "Invalid status"     | CommonDefs.CONTACT_TYPE_PRIMARY_PHONE | "N"         | "8"             | "5554321"   | CommonDefs.PHONE_NUMBER_TYPE_MOBILE | false | CommonDefs.IND_N
        "Invalid validation" | CommonDefs.CONTACT_TYPE_PRIMARY_PHONE | "V"         | "7"             | "5554321"   | CommonDefs.PHONE_NUMBER_TYPE_MOBILE | false | CommonDefs.IND_N
    }

}
