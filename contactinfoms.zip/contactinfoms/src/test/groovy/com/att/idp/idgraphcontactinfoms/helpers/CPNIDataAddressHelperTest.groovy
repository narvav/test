package com.att.idp.idgraphcontactinfoms.helpers

import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import java.text.SimpleDateFormat

class CPNIDataAddressHelperTest extends Specification {

	def CPNIDataAddressHelper CPNIDataAddressHelperObj = new CPNIDataAddressHelper()

    String stTransactionId = null
    Logger logger = null
    HashMap hmResult = null
    HashMap hmRes = null
    HashMap hmInput = null
    String stAppStatusMsg = null
    String stAppInfo = null
    String date = null
    String sCSTDate = null
    ArrayList alValidCPNIAddress = new ArrayList()
    private static final long MILLIS_PER_DAY = 24 * 60 * 60 * 1000


    def setup() {

        logger = LoggerFactory.getLogger('QueryCPNIUserContactHelper')

        System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')

        hmInput = CommonUtil.hashMap

        hmInput[CommonDefs.CONTACT_INFO] = alValidCPNIAddress
        hmInput[CommonDefs.ACTIVATED_IND] = 'Y'
        hmInput['NewCPNIEilibilityRule'] = 'Y'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.POSTAL_ADDRESS] = alValidCPNIAddress

        hmRes = new HashMap()
        hmRes[MPSDefs.DB_CONTACT_TYPE] = 'PEMAIL'
        hmRes['CPNIEligibleEmail'] = 'N'

        Date today = new Date()
        SimpleDateFormat sdf = new SimpleDateFormat('MMddyyyy HH:mm:ss')

        TimeZone cst = TimeZone.getTimeZone('CST')
        sdf.timeZone = cst
        sCSTDate = sdf.format(new Date(today.time - 20 * MILLIS_PER_DAY))

        ReflectionTestUtils.setField(CPNIDataAddressHelperObj, 'sBypassCallingSystemIds', '1')
        ReflectionTestUtils.setField(CPNIDataAddressHelperObj, 'sSimSwapAgingDays', '3')

    }


    def "c p n i data address null input"() {
        when:
        hmResult = CPNIDataAddressHelperObj.validateCPNIAddress(null)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == ' Input Hash is NULL / EMPTY '
    }

    def "c p n i data address empty input"() {
        when:
        hmResult = CPNIDataAddressHelperObj.validateCPNIAddress(CommonUtil.hashMap)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == ' Input Hash is NULL / EMPTY '
    }


    def "c p n i data address success"() {
        when:
        hmResult = CPNIDataAddressHelperObj.validateCPNIAddress(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "c p n i postal address empty "() {
        hmInput[CommonDefs.POSTAL_ADDRESS] = ''
        when:
        hmResult = CPNIDataAddressHelperObj.validateCPNIAddress(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "c p n i postal address null "() {
        hmInput[CommonDefs.POSTAL_ADDRESS] = null
        when:
        hmResult = CPNIDataAddressHelperObj.validateCPNIAddress(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }


    def "c p n i data address s contact type email"() {
        given:
        hmInput[CommonDefs.ACTIVATED_IND] = 'N'
        alValidCPNIAddress.add(hmRes)
        when:
        hmResult = CPNIDataAddressHelperObj.validateCPNIAddress(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "c p n i data address s contact type email flag null"() {
        given:
        hmInput[CommonDefs.ACTIVATED_IND] = 'N'
        hmInput[CommonDefs.POSTAL_ADDRESS] = null
        hmInput[CommonDefs.CPNI_ELIGIBLE_EMAIL_FLAG] = null
        alValidCPNIAddress.add(hmRes)
        when:
        hmResult = CPNIDataAddressHelperObj.validateCPNIAddress(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "c p n i data address s contact type null"() {
        given:
        hmRes[MPSDefs.DB_CONTACT_TYPE] = null
        alValidCPNIAddress.add(hmRes)
        when:
        hmResult = CPNIDataAddressHelperObj.validateCPNIAddress(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }


    def "c p n i data address s contact type phone"() {
        given:
        hmRes['phone_est_date'] = sCSTDate
        hmRes['Phone'] = 'SPHONE'
        hmRes['account_create_date'] = null
        hmRes[CommonDefs.SIM_SWAP_DATE] = sCSTDate
        hmRes[MPSDefs.DB_CONTACT_TYPE] = 'SPHONE'
        alValidCPNIAddress.add(hmRes)
        when:
        hmResult = CPNIDataAddressHelperObj.validateCPNIAddress(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }


    def "c p n i data address s contact type phone new c p n i eilibility rule"() {
        given:
        hmRes['phone_est_date'] = sCSTDate
        hmRes['Phone'] = 'SPHONE'
        hmRes['account_create_date'] = null
        hmRes[CommonDefs.SIM_SWAP_DATE] = sCSTDate
        hmRes['NewCPNIEilibilityRule'] = 'N'
        hmRes[MPSDefs.DB_CONTACT_TYPE] = 'SPHONE'
        alValidCPNIAddress.add(hmRes)
        when:
        hmResult = CPNIDataAddressHelperObj.validateCPNIAddress(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }


    def "c p n i data address s contact type phone c p n i eligible email"() {
        given:
        hmRes['CPNIEligibleEmail'] = 'Y'
        hmRes['phone_est_date'] = sCSTDate
        hmRes['Phone'] = 'SPHONE'
        hmRes['account_create_date'] = null
        hmRes[CommonDefs.SIM_SWAP_DATE] = sCSTDate
        hmRes['NewCPNIEilibilityRule'] = 'N'
        hmRes[MPSDefs.DB_CONTACT_TYPE] = 'PPHONE'
        alValidCPNIAddress.add(hmRes)
        when:
        hmResult = CPNIDataAddressHelperObj.validateCPNIAddress(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }


    def "c p n i data address s contact type phone c p n i eligible email email"() {
        given:
        hmRes['CPNIEligibleEmail'] = 'Y'
        hmRes['phone_est_date'] = sCSTDate
        hmRes['Phone'] = 'SPHONE'
        hmRes['account_create_date'] = null
        hmRes[CommonDefs.SIM_SWAP_DATE] = sCSTDate
        hmRes['NewCPNIEilibilityRule'] = 'N'
        hmRes[MPSDefs.DB_CONTACT_TYPE] = 'PEMAIL'
        alValidCPNIAddress.add(hmRes)
        when:
        hmResult = CPNIDataAddressHelperObj.validateCPNIAddress(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }


    def "c p n i data address s contact type phone b c p n i not eligible1"() {
        given:
        hmRes['CPNIEligibleEmail'] = 'N'
        hmRes['phone_est_date'] = null
        hmRes['Phone'] = 'SPHONE'
        hmRes['account_create_date'] = null
        hmRes[CommonDefs.SIM_SWAP_DATE] = sCSTDate
        hmRes['NewCPNIEilibilityRule'] = 'N'
        hmRes[MPSDefs.DB_CONTACT_TYPE] = 'SPHONE'
        alValidCPNIAddress.add(hmRes)
        when:
        hmResult = CPNIDataAddressHelperObj.validateCPNIAddress(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }


    def "c p n i data address s contact type phone b c p n i not eligible"() {
        given:
        hmInput[CommonDefs.CONTACT_INFO] = null
        hmRes['phone_est_date'] = sCSTDate
        hmRes['Phone'] = 'SPHONE'
        hmRes['account_create_date'] = sCSTDate
        hmRes[CommonDefs.SIM_SWAP_DATE] = sCSTDate
        hmRes['NewCPNIEilibilityRule'] = 'N'
        hmRes[MPSDefs.DB_CONTACT_TYPE] = 'SPHONE'
        alValidCPNIAddress.add(hmRes)
        when:
        hmResult = CPNIDataAddressHelperObj.validateCPNIAddress(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'

    }


    def "c p n i data address exception"() {
        given:
        ArrayList alPostAddress = new ArrayList()
        alValidCPNIAddress.add(alPostAddress)
        when:
        hmResult = CPNIDataAddressHelperObj.validateCPNIAddress(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "c p n i data address s sim swap aging days"() {
        given:
        ReflectionTestUtils.setField(CPNIDataAddressHelperObj, 'sSimSwapAgingDays', null)
        hmInput[CommonDefs.CONTACT_INFO] = null
        hmRes['phone_est_date'] = sCSTDate
        hmRes['Phone'] = 'SPHONE'
		hmRes['account_create_date'] = sCSTDate
		hmRes[CommonDefs.SIM_SWAP_DATE] = sCSTDate
		hmRes['NewCPNIEilibilityRule'] = 'N'

		hmRes[MPSDefs.DB_CONTACT_TYPE] = 'SPHONE'
		alValidCPNIAddress.add(hmRes)
        when:
        hmResult = CPNIDataAddressHelperObj.validateCPNIAddress(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_CONFIG'
    }

}
