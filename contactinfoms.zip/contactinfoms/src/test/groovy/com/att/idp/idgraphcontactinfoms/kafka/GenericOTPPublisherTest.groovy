package com.att.idp.idgraphcontactinfoms.kafka

import com.att.idp.idgraphcontactinfoms.exceptions.PrimaryProducerException
import com.att.idp.idgraphcontactinfoms.exceptions.SecondaryProducerException
import org.apache.kafka.clients.producer.RecordMetadata
import org.apache.kafka.common.TopicPartition
import org.apache.kafka.common.errors.AuthenticationException
import org.slf4j.MDC
import org.springframework.kafka.core.KafkaTemplate
import org.springframework.kafka.support.SendResult
import org.springframework.util.concurrent.ListenableFuture
import org.springframework.util.concurrent.ListenableFutureCallback
import spock.lang.Specification

import static org.mockito.Mockito.doAnswer
import static org.mockito.Mockito.mock

class GenericOTPPublisherTest extends Specification {

    def mockKafkaTemplatePrimary = Mock(KafkaTemplate)
    def mockKafkaTemplateSecondary = Mock(KafkaTemplate)
    def mockFuture = Stub(ListenableFuture)
    def mockSendResult = Stub(SendResult)
    def recordMetadata = new RecordMetadata(new TopicPartition('topic', 0), 1L, 0, 0L, 0, 0)
    def producer = new GenericOTPPublisher()

    def setup() {
        producer.kafkaTemplatePrimary = mockKafkaTemplatePrimary
        producer.kafkaTemplateSecondary = mockKafkaTemplateSecondary
        producer.gotpTopicname = 'primaryTopic'
        producer.gotpSecondaryTopicname = 'secondaryTopic'
        MDC.putCloseable('idp-trace-id', '123')
        mockSendResult.getRecordMetadata() >> recordMetadata
    }

    


    def "test sendToPrimary authentication failure"() {
        given:
        def message = 'message'
        mockKafkaTemplatePrimary.send(_, _) >> { throw new AuthenticationException('auth error') }

        when:
        producer.sendToPrimary(message)

        then:
        thrown(PrimaryProducerException)
    }

    

    

    def "test sendToSecondary authentication failure"() {
        given:
        def message = 'message'
        def contextMap = MDC.getCopyOfContextMap()
        mockKafkaTemplateSecondary.send(_, _) >> { throw new AuthenticationException('auth error') }

        when:
        producer.sendToSecondary(message, contextMap)

        then:
        thrown(PrimaryProducerException)
    }



    def "test recoverSendToSecondary"() {
        given:
        def message = 'message'
        def exception = new SecondaryProducerException('error', 'error', 500)

        when:
        producer.recoverSendToSecondary(exception, message)

        then:
        thrown(SecondaryProducerException)
    }
}