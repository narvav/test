package com.att.idp.idgraphcontactinfoms.db.repository.impl

import com.att.idp.idgraphcontactinfoms.db.repository.SystemOfRecordRepository
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs
import com.att.idp.idgraphcontactinfoms.utils.ProfileOrchestrationConstants
import org.hibernate.Session
import org.hibernate.query.NativeQuery
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Specification

import jakarta.persistence.EntityManager
import java.sql.SQLException
import java.time.LocalDate
import com.att.idp.idgraphcontactinfoms.exceptions.MPSException

class SecurityCodeRepositoryImplTest extends Specification {

	def securityCodeRepositoryImplObj = new SecurityCodeRepositoryImpl()

	def systemOfRecordRepo = Mock(SystemOfRecordRepository)

	def query = Mock(NativeQuery)

	def sessionMock = Mock(Session)

	def entityManager = Mock(EntityManager)

	private LocalDate localDate
	private java.sql.Date now

	private HashMap<String, Object> inpParamHash = null
	public static final Logger logger = LoggerFactory.getLogger(SecurityCodeRepositoryImpl.class)

	def setup() {
		securityCodeRepositoryImplObj.systemOfRecordRepo = systemOfRecordRepo
		securityCodeRepositoryImplObj.entityManager = entityManager
		entityManager.unwrap(Session) >> sessionMock
		sessionMock.createNativeQuery(_) >> query
		//query.setParameter(_, _) >> query
		//query.addSynchronizedQuerySpace(_) >> query

		inpParamHash = CommonUtil.hashMap
		inpParamHash[MPSDefs.DB_ACCOUNT_ID] = '1111111111'
		inpParamHash[MPSDefs.DB_SOR_INVARIANT_ID] = '123456'
		inpParamHash[MPSDefs.DB_ACCOUNT_TYPE] = 'R'
		inpParamHash[MPSDefs.DB_ACCOUNT_REGION] = 'abc'
		inpParamHash[MPSDefs.DB_IDENTIFICATION_TYPE] = 'IDSEMOB'
		inpParamHash[MPSDefs.DB_LAST_MODIFIED_BY] = 'DATAMGT'
		inpParamHash['security_code_expiration_time'] = '24'
		inpParamHash[MPSDefs.DB_SECURITY_CODE] = '1234' // Added valid security code
	}

	/*def "set security account data exception test1"() throws SQLException {
		given:
		NullPointerException ex = new NullPointerException('ORA-00001: unique constraint')

		entityManager.unwrap(Session) >> sessionMock
		sessionMock.createNativeQuery(_) >> { throw ex }

		when:
		int rowcount = securityCodeRepositoryImplObj.setSecurityCode(inpParamHash)
		then:
		thrown NullPointerException
	}

	def "set security account data exception else test2"() throws SQLException {
		given:
		NullPointerException ex = new NullPointerException('NullPointerException')

		entityManager.unwrap(Session) >> sessionMock
		sessionMock.createNativeQuery(_) >> { throw ex }

		when:
		int rowcount = securityCodeRepositoryImplObj.setSecurityCode(inpParamHash)
		then:
		thrown NullPointerException
	}
*/
	def "set security account data success test"() {
		given:
		entityManager.unwrap(Session) >> sessionMock
		sessionMock.createNativeQuery(_) >> query
		query.setParameter(_, _) >> query
		query.addSynchronizedQuerySpace(_) >> query
		query.executeUpdate() >> 1


		when:
		int rowcount = securityCodeRepositoryImplObj.setSecurityCode(inpParamHash)

		then:
		rowcount == 1
	}

	def "set security account data success with all optional parameters and sor lookup"() {
		given:
		// clone base map so other tests unaffected
		HashMap fullParams = new HashMap(inpParamHash)
		fullParams[MPSDefs.DB_SOR_NAME] = 'SOR_A'
		fullParams[MPSDefs.DB_SOR_INVARIANT_ID] = 'INV123'
		fullParams[MPSDefs.DB_SLID_MEMBER_NUM] = '98765'
		fullParams[MPSDefs.DB_DELIVERY_METHOD] = 'EMAIL'
		fullParams[MPSDefs.DB_DELIVERY_DETAIL] = 'user@example.com'
		fullParams[CommonDefs.SOURCE] = 'WEB'
		fullParams[MPSDefs.DB_PASSCODE_VENC] = 'PV1'
		fullParams['security_code_expiration_time'] = '12'
		fullParams[ProfileOrchestrationConstants.EXPIRY_TIME_UNIT] = 'HOURS'

		systemOfRecordRepo.getSorId('SOR_A') >> 42L
		query.setParameter(_, _) >> query
		query.executeUpdate() >> 1

		when:
		int rowcount = securityCodeRepositoryImplObj.setSecurityCode(fullParams)

		then:
		rowcount == 1
	}

	def "set security account data success without sor lookup (empty sor name)"() {
		given:
		HashMap noSorParams = new HashMap(inpParamHash)
		noSorParams[MPSDefs.DB_SOR_NAME] = ''
		query.setParameter(_, _) >> query
		query.executeUpdate() >> 1

		when:
		int rowcount = securityCodeRepositoryImplObj.setSecurityCode(noSorParams)

		then:
		rowcount == 1
		0 * systemOfRecordRepo.getSorId(_)
	}

	def "set security account data unique constraint exception path"() {
		given:
		query.executeUpdate() >> { throw new RuntimeException('ORA-00001: unique constraint (MPS_OWNER.UK_TSECURITYCODE)') }
		query.setParameter(_, _) >> query

		when:
		int rowcount = securityCodeRepositoryImplObj.setSecurityCode(inpParamHash)

		then:
		rowcount == 0
		RuntimeException ex = thrown()
		ex.message.contains("unique constraint")
	}

	def "set security account data generic exception path"() {
		given:
		query.executeUpdate() >> { throw new RuntimeException('Some other DB error') }
		query.setParameter(_, _) >> query

		when:
		int rowcount = securityCodeRepositoryImplObj.setSecurityCode(inpParamHash)

		then:
		rowcount == 0
		RuntimeException ex = thrown()
		ex.message.contains("error")
	}

	def "getSorId success"() {
		given:
		systemOfRecordRepo.getSorId('SORSUCCESS') >> 999L

		when:
		Long sorId = securityCodeRepositoryImplObj.getSorId('SORSUCCESS')

		then:
		sorId == 999L
	}

	def "getSorId exception path rethrows MPSException"() {
		given:
		systemOfRecordRepo.getSorId('SORFAIL') >> { throw new RuntimeException('lookup failed') }

		when:
		securityCodeRepositoryImplObj.getSorId('SORFAIL')

		then:
		thrown MPSException
	}
}