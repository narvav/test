package com.att.idp.QAIntegration.Report

import com.att.idp.QAIntegration.Config.ContactInfoGlobalConfig
import groovy.json.JsonSlurper

import jakarta.activation.DataHandler
import jakarta.activation.FileDataSource
import jakarta.mail.Authenticator
import jakarta.mail.Message
import jakarta.mail.PasswordAuthentication
import jakarta.mail.Session
import jakarta.mail.Transport
import jakarta.mail.internet.InternetAddress
import jakarta.mail.internet.MimeBodyPart
import jakarta.mail.internet.MimeMessage
import jakarta.mail.internet.MimeMultipart
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.text.SimpleDateFormat

/**
 * QG7 Integration Test Email Sender for IDGraphContactInfoMs.
 *
 * Invoked by maven-exec-plugin after the integration-test phase completes.
 * Reads {@code target/qg7-test-results-summary.json} (written by QG7ExtentReportListener),
 * builds the HTML email body via QG7EmailReportBuilder, and sends it via SMTP.
 *
 * The HTML Extent report ({@code target/SparkReport/ContactInfoMs-QG7-Report.html})
 * is attached to the email for full drill-down detail.
 *
 * ONLY called when the integration-test Maven profile is active (exec-maven-plugin
 * in that profile invokes this main method). Unit/component test runs are unaffected.
 */
class QG7EmailSender {

    private static final String JSON_SUMMARY_PATH   = "target/qg7-test-results-summary.json"
    private static final String EXTENT_REPORT_PATH  = "target/SparkReport/ContactInfoMs-QG7-Report.html"
    private static final String CUSTOM_REPORT_PATH  = "target/CustomReport/Email.html"
    private static final String EMAIL_REPORT_PATH   = "target/ContactInfoMs-QG7-EmailReport.html"

    static void main(String[] args) {
        File jsonFile    = new File(JSON_SUMMARY_PATH)
        File extentFile  = new File(EXTENT_REPORT_PATH)
        File customFile  = new File(CUSTOM_REPORT_PATH)

        if (!jsonFile.exists() && !extentFile.exists()) {
            println "WARNING: No QG7 test results found. Skipping email."
            return
        }

        // Check sendEmailMode from config
        Map<String, String> emailConfig = ContactInfoGlobalConfig.getEmailConfig()
        String sendEmailMode = emailConfig.get("sendEmailMode")?.toLowerCase() ?: "onfailure"
        
        // Build collector to check test results
        QG7TestResultCollector collector = buildCollectorFromJson(jsonFile)
        int failedCount = collector.failedTests.get()
        
        // Determine if email should be sent based on mode
        boolean shouldSendEmail = false
        switch (sendEmailMode) {
            case "always":
                shouldSendEmail = true
                println "Email mode: ALWAYS — email will be sent"
                break
            case "never":
                shouldSendEmail = false
                println "Email mode: NEVER — email will NOT be sent"
                break
            case "onfailure":
            default:
                shouldSendEmail = (failedCount > 0)
                if (shouldSendEmail) {
                    println "Email mode: ON_FAILURE — ${failedCount} test(s) failed, email will be sent"
                } else {
                    println "Email mode: ON_FAILURE — all tests passed, email will NOT be sent"
                }
                break
        }
        
        if (!shouldSendEmail) {
            println "Skipping email send based on sendEmailMode='${sendEmailMode}' and test results (failed=${failedCount})"
            return
        }

        // Prefer the pre-generated custom HTML report; fall back to building from JSON
        String htmlBody
        if (customFile.exists()) {
            htmlBody = customFile.text
            println "QG7 custom report loaded → ${customFile.absolutePath}"
        } else {
            htmlBody = QG7EmailReportBuilder.build(collector)
            println "QG7 email report built from JSON summary"
        }

        Files.write(new File(EMAIL_REPORT_PATH).toPath(), htmlBody.getBytes(StandardCharsets.UTF_8))
        println "QG7 email report written → ${new File(EMAIL_REPORT_PATH).absolutePath}"

        sendEmail(htmlBody, extentFile)
    }

    private static QG7TestResultCollector buildCollectorFromJson(File jsonFile) {
        QG7TestResultCollector c = new QG7TestResultCollector()
        c.reset()
        if (!jsonFile.exists()) {
            println "WARNING: JSON summary not found at ${jsonFile.absolutePath}; sending empty report."
            return c
        }
        try {
            Map data = new JsonSlurper().parse(jsonFile) as Map
            Map overall = data.overall as Map ?: [:]
            c.totalTests.set((overall.total   ?: 0) as int)
            c.passedTests.set((overall.passed  ?: 0) as int)
            c.failedTests.set((overall.failed  ?: 0) as int)
            c.skippedTests.set((overall.skipped ?: 0) as int)

            ((data.specs ?: [:]) as Map).each { Object key, Object val ->
                String spec = key.toString()
                Map counts  = val as Map
                c.specTotal.put(spec, new java.util.concurrent.atomic.AtomicInteger((counts.total   ?: 0) as int))
                c.specPassed.put(spec, new java.util.concurrent.atomic.AtomicInteger((counts.passed  ?: 0) as int))
                c.specFailed.put(spec, new java.util.concurrent.atomic.AtomicInteger((counts.failed  ?: 0) as int))
                c.specSkipped.put(spec, new java.util.concurrent.atomic.AtomicInteger((counts.skipped ?: 0) as int))
            }

            ((data.failedTests ?: []) as List).each { Object item ->
                Map ft = item as Map
                c.failedFlows.add([spec: ft.spec?.toString() ?: "Unknown", feature: ft.feature?.toString() ?: "Unknown", error: ft.error?.toString() ?: ""])
            }
            c.startTimeMs = System.currentTimeMillis() - 60_000L
        } catch (Exception e) {
            println "WARNING: Failed to parse JSON summary: ${e.message}"
        }
        return c
    }

    private static void sendEmail(String htmlBody, File extentReportFile) {
        Map<String, String> emailConfig = ContactInfoGlobalConfig.getEmailConfig()
        String toEmail   = emailConfig.get("toEmail") ?: ""
        String ccEmail   = emailConfig.get("ccEmail") ?: ""
        String fromEmail = emailConfig.get("fromEmail") ?: ""
        String username  = emailConfig.get("username") ?: ""
        String password  = emailConfig.get("password") ?: ""

        if (!toEmail) {
            println "WARNING: No toEmail configured — skipping email send."
            return
        }

        Properties props = new Properties()
        props.put("mail.smtp.auth", "true")
        props.put("mail.smtp.starttls.enable", "true")
        props.put("mail.smtp.host", "smtp.it.att.com")
        props.put("mail.smtp.port", "587")

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password)
            }
        })

        try {
            MimeMessage message = new MimeMessage(session)
            message.setFrom(new InternetAddress(fromEmail))
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail))
            if (ccEmail) {
                message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(ccEmail))
            }

            String env    = System.getProperty("INTEGRATION_TEST_ENV") ?: ContactInfoGlobalConfig.getCurrentTestEnv()
            String strDate = new SimpleDateFormat("dd-MMM-yyyy").format(new Date())
            message.setSubject("IDGraphContactInfoMs QG7 Integration Test Report — ${env} — ${strDate}")

            MimeMultipart mixedPart = new MimeMultipart("mixed")

            MimeBodyPart htmlPart = new MimeBodyPart()
            htmlPart.setContent(htmlBody, "text/html; charset=UTF-8")
            mixedPart.addBodyPart(htmlPart)

            if (extentReportFile?.exists()) {
                MimeBodyPart attachPart = new MimeBodyPart()
                attachPart.setDataHandler(new DataHandler(new FileDataSource(extentReportFile)))
                attachPart.setFileName("ContactInfoMs-QG7-Report.html")
                mixedPart.addBodyPart(attachPart)
                println "Extent report attached: ${extentReportFile.absolutePath}"
            }

            message.setContent(mixedPart)
            Transport.send(message)
            println "QG7 email report sent successfully to: ${toEmail}"
        } catch (Exception e) {
            println "WARNING: Failed to send QG7 email: ${e.message}"
            e.printStackTrace(System.out)
        }
    }
}
