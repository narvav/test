package com.att.idp.idgraphcontactinfoms.db.helper

import com.att.idp.idgraphcontactinfoms.exceptions.MPSException
import com.att.mpsys.common.utils.MPSDefs
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.junit.jupiter.MockitoExtension
import org.springframework.jdbc.core.JdbcTemplate
import spock.lang.Ignore
import spock.lang.Specification

import static org.junit.jupiter.api.Assertions.assertEquals

class DBHelperTest extends Specification {

    def testObj = new DBHelper()

    def jdbcTemplate = Mock(JdbcTemplate)

    private List<Object> objectList = new ArrayList<Object>()
    private List alQueryResponse = new ArrayList<Object>()
    private String selectStatement = null

    def setup() {
        testObj.jdbcTemplate = jdbcTemplate
    }

    def "get domain id success"() throws MPSException {
        given:
        selectStatement = 'SELECT domain_id FROM domain WHERE domain_name = ?'
        String domain_name = 'slid.dum'
        objectList.add(domain_name)

        HashMap<String, Object> domainList = new HashMap<String, Object>()
        domainList[MPSDefs.DB_DOMAIN_ID] = '15'
        alQueryResponse.add(domainList)

        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse

        when:
        int domainID = testObj.getDomainId(domain_name)
        then:
        domainID == 15
    }


    def "get domain id exception"() {
        given:
        selectStatement = 'SELECT domain_id FROM domain WHERE domain_name = ?'
        String domain_name = 'slid.dum'
        objectList.add(domain_name)

        HashMap<String, Object> domainList = new HashMap<String, Object>()
        domainList[MPSDefs.DB_DOMAIN_ID] = null
        alQueryResponse.add(domainList)

        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse

        expect:
        try {
			int domainID = testObj.getDomainId(domain_name)
        } catch (MPSException e) {
            String message = e.message
            message.contains("DBHelper::getDomainId::Cannot invoke")
			//assertEquals('DBHelper::getDomainId::Cannot invoke', e.message)
        }
    }


    def "get sor id success"() throws MPSException {
        given:
        selectStatement = 'SELECT sor_id FROM systemofrecord WHERE sor_name = ?'
        String sor_name = 'NA'
        objectList.add(sor_name)

        HashMap<String, Object> sorList = new HashMap<String, Object>()
        sorList[MPSDefs.DB_SOR_ID] = '17'
        alQueryResponse.add(sorList)

        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse

        when:
        int sorID = testObj.getSorId(sor_name)
        then:
        sorID == 17
    }


    def "get sor id s exception"() {
        given:
        selectStatement = 'SELECT sor_id FROM systemofrecord WHERE sor_name = ?'
        String sor_name = 'NA'
        objectList.add(sor_name)

        HashMap<String, Object> sorList = new HashMap<String, Object>()
        sorList[MPSDefs.DB_SOR_ID] = null
        alQueryResponse.add(sorList)

        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse

        expect:
        try {
			int sorId = testObj.getSorId(sor_name)
        } catch (MPSException e) {
            String message = e.message
            message.contains("DBHelper::getSorId::Cannot invoke")
			//assertEquals('DBHelper::getSorId::Cannot invoke', e.message)
        }
    }


    def "get security question id success"() throws MPSException {
        given:
        selectStatement = 'SELECT security_question_id FROM SecurityQuestion WHERE SUBSTR(TRIM(LOWER(security_question)), 1, 80) = TRIM(LOWER(?))'
        String sSecurityQuestion = 'What is the title of your favorite book?'
        objectList.add(sSecurityQuestion)

        HashMap<String, Object> questionList = new HashMap<String, Object>()
        questionList[MPSDefs.DB_SECURITY_QUESTION_ID] = '27'
        alQueryResponse.add(questionList)

        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse
        when:
        int questionId = testObj.getSecurityQuestionId(sSecurityQuestion)
        then:
        questionId == 27
    }


    def "get security question id more length success"() throws MPSException {
        given:
        String sSecurityQuestion = 'What is the title of your favorite book? wdns fwebjfbwejfb cdvchEDBEFJWENFC NWWJEEJWDFNCDkfnkwj'

        objectList.add(sSecurityQuestion)

        HashMap<String, Object> questionList = new HashMap<String, Object>()
        questionList[MPSDefs.DB_SECURITY_QUESTION_ID] = '-1'
        alQueryResponse.add(questionList)

        jdbcTemplate.queryForList(_, _) >> alQueryResponse

        when:
        int questionId = testObj.getSecurityQuestionId(sSecurityQuestion)
        then:
        questionId == -1
    }


    def "get security question id exception"() {
        given:
        selectStatement = 'SELECT security_question_id FROM SecurityQuestion WHERE SUBSTR(TRIM(LOWER(security_question)), 1, 80) = TRIM(LOWER(?))'
        String sSecurityQuestion = 'What is the title of your favorite book?'
        objectList.add(sSecurityQuestion)

        HashMap<String, Object> questionList = new HashMap<String, Object>()
        questionList[MPSDefs.DB_SECURITY_QUESTION_ID] = null
        alQueryResponse.add(questionList)

        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse
        expect:
        try {
			int questionId = testObj.getSecurityQuestionId(sSecurityQuestion)
        } catch (MPSException e) {
            String message = e.message
            message.contains("DBHelper::getSecurityQuestionId::Cannot invoke")
			//assertEquals('DBHelper::getSecurityQuestionId::Cannot invoke', e.message)
        }
    }


    def "get next id success"() throws MPSException {
        given:
        selectStatement = 'SELECT group_num_seq.NEXTVAL FROM dual'
        alQueryResponse.add('12345')

        jdbcTemplate.queryForList(_, _) >> alQueryResponse
        when:
        long groupId = testObj.getNextMemberGroupId()
        then:
        groupId == 12345L
    }


    def "get access id success"() throws MPSException {
        given:
        String accessName = 'group_num_seq'
        selectStatement = 'SELECT access_id FROM networkaccess WHERE access_name = ?'
        objectList.add(accessName)
        HashMap<String, Object> accessIdList = new HashMap<String, Object>()
        accessIdList['access_id'] = '5'
        alQueryResponse.add(accessIdList)

        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse
        when:
        long accessId = testObj.getAccessId(accessName)
        then:
        accessId == 5L
    }


    def "get access id exception"() {
        given:
        String accessName = 'group_num_seq'
        selectStatement = 'SELECT access_id FROM networkaccess WHERE access_name = ?'

        objectList.add(accessName)

        HashMap<String, Object> accessIdList = new HashMap<String, Object>()
        accessIdList['access_id'] = null
        alQueryResponse.add(accessIdList)

        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse
        expect:
        try {
			long accessID = testObj.getAccessId(accessName)
        } catch (MPSException e) {
            String message = e.message
            message.contains("DBHelper::getAccessId::Cannot invoke")

            //assertEquals('DBHelper::getAccessId::Cannot invoke', e.message)
        }
    }


    def "get next id error"() {
        given:
        selectStatement = 'SELECT group_num_seq.NEXTVAL FROM dual'
        alQueryResponse.add('-1')

        jdbcTemplate.queryForList(selectStatement, _ as String) >> alQueryResponse
        expect:
        try {
			long groupId = testObj.nextMemberGroupId
        } catch (MPSException e) {
			e.getMessage() == 'DBHelper::getNextId::Sequence group_num_seq is empty.'
        }
    }


    def "get next id exception"() {
        given:
        selectStatement = 'SELECT member_num_seq.NEXTVAL FROM dual'

        jdbcTemplate.queryForList(selectStatement, _ as String) >> null
        expect:
        try {
			long memberId = testObj.nextMemberId
        } catch (MPSException e) {
            String message = e.message
            message.contains("DBHelper::getNextId::Cannot invoke")
			//assertEquals('DBHelper::getNextId::Cannot invoke', e.message)
        }
    }


    def "get service name exception"() {
        given:
        selectStatement = 'SELECT service_name FROM service WHERE service_id = ?'
        objectList.add('1')

        HashMap<String, Object> serviceList = new HashMap<String, Object>()
        serviceList['service_name'] = 123232
        alQueryResponse.add(serviceList)

        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse
        expect:
        try {
			String serviceName = testObj.getServiceName('1')
        } catch (MPSException e) {
			assertEquals(
                    'DBHelper::getServiceName::class java.lang.Integer cannot be cast to class java.lang.String (java.lang.Integer and java.lang.String are in module java.base of loader \'bootstrap\')',
                    e.message)
        }
    }


    def "get service name success"() throws MPSException {
        given:
        selectStatement = 'SELECT service_name FROM service WHERE service_id = ?'
        HashMap<String, Object> serviceList = new HashMap<String, Object>()
        serviceList['service_name'] = 'DSL'
        alQueryResponse.add(serviceList)

        objectList.add('1')

        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse
        when:
        String serviceName = testObj.getServiceName('1')
        then:
        serviceName == 'DSL'
    }


    def "get service id exception"() {
        given:
        selectStatement = 'SELECT service_id FROM service WHERE service_name = ?'
        HashMap<String, Object> serviceList = new HashMap<String, Object>()
        serviceList['service_id'] = null
        alQueryResponse.add(serviceList)

        objectList.add('DSL')
        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse
        expect:
        try {
			int serviceId = testObj.getServiceId('DSL')
        } catch (MPSException e) {
            String message = e.message
            message.contains("DBHelper::getServiceId::Cannot invoke")
			//assertEquals('DBHelper::getServiceId::Cannot invoke', e.message)
        }
    }


    def "get service id success"() throws MPSException {
        given:
        selectStatement = 'SELECT service_id FROM service WHERE service_name = ?'
        HashMap<String, Object> serviceList = new HashMap<String, Object>()
        serviceList['service_id'] = '1'
        alQueryResponse.add(serviceList)

        objectList.add('DSL')

        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse
        when:
        int serviceId = testObj.getServiceId('DSL')
        then:
        serviceId == 1
    }


    def "get sor name exception"() {
        given:
        selectStatement = 'SELECT sor_name FROM systemofrecord WHERE sor_id = ?'
        HashMap<String, Object> sorList = new HashMap<String, Object>()
        sorList['sor_name'] = 1122
        alQueryResponse.add(sorList)
        objectList.add('17')

        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse
        expect:
        try {
			String sorName = testObj.getSorName('17')
        } catch (MPSException e) {
			assertEquals(
                    'DBHelper::getSorName::class java.lang.Integer cannot be cast to class java.lang.String (java.lang.Integer and java.lang.String are in module java.base of loader \'bootstrap\')',
                    e.message)
        }
    }


    def "get sor name success"() throws MPSException {
        given:
        selectStatement = 'SELECT sor_name FROM systemofrecord WHERE sor_id = ?'
        HashMap<String, Object> sorList = new HashMap<String, Object>()
        sorList['sor_name'] = 'MO'
        alQueryResponse.add(sorList)

        objectList.add('17')
        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse
        when:
        String sorName = testObj.getSorName('17')
        then:
        sorName == 'MO'
    }


    def "get access name exception"() {
        given:
        selectStatement = 'SELECT access_name FROM networkaccess WHERE access_id = ?'
        HashMap<String, Object> nameList = new HashMap<String, Object>()
        nameList['access_name'] = 12323
        alQueryResponse.add(nameList)
        objectList.add('5')

        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse
        expect:
        try {
			String sorName = testObj.getAccessName('5')
        } catch (MPSException e) {
			assertEquals(
                    'DBHelper::getAccessName::class java.lang.Integer cannot be cast to class java.lang.String (java.lang.Integer and java.lang.String are in module java.base of loader \'bootstrap\')',
                    e.message)
        }
    }


    def "get access name success"() throws MPSException {
        given:
        selectStatement = 'SELECT access_name FROM networkaccess WHERE access_id = ?'
        HashMap<String, Object> nameList = new HashMap<String, Object>()
        nameList['access_name'] = 'LS'
        alQueryResponse.add(nameList)

        objectList.add('5')
        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse
        when:
        String sorName = testObj.getAccessName('5')
        then:
        sorName == 'LS'
    }


    def "get status code exception"() {
        given:
        selectStatement = 'SELECT status_code FROM status WHERE status_name = ?'
        HashMap<String, Object> statusList = new HashMap<String, Object>()
        statusList['status_code'] = null
        alQueryResponse.add(statusList)

        objectList.add('5')

        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse
        expect:
        try {
			int statusCode = testObj.getStatusCode('5')
        } catch (MPSException e) {
            String message = e.message
            message.contains("DBHelper::getStatusCode::Cannot invoke")
			//assertEquals('DBHelper::getStatusCode::Cannot invoke', e.message)
        }
    }


    def "get status code success"() throws MPSException {
        given:
        selectStatement = 'SELECT status_code FROM status WHERE status_name = ?'
        HashMap<String, Object> statusList = new HashMap<String, Object>()
        statusList['status_code'] = 0
        alQueryResponse.add(statusList)

        objectList.add('5')
        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse
        when:
        int statusCode = testObj.getStatusCode('5')
        then:
        statusCode == 0
    }


    def "get domain name exception"() {
        given:
        selectStatement = 'SELECT domain_name FROM domain WHERE domain_id = ?'
        HashMap<String, Object> domaineList = new HashMap<String, Object>()
        domaineList[MPSDefs.DB_DOMAIN_NAME] = 213214
        alQueryResponse.add(domaineList)

        objectList.add('15')

        jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse
        expect:
        try {
			String domainName = testObj.getDomainName('15')
        } catch (MPSException e) {
			assertEquals(
                    'DBHelper::getDomainName::class java.lang.Integer cannot be cast to class java.lang.String (java.lang.Integer and java.lang.String are in module java.base of loader \'bootstrap\')',
                    e.message)
        }
    }


    def "get domain name success"() throws MPSException {
        given:
        selectStatement = 'SELECT domain_name FROM domain WHERE domain_id = ?'
        HashMap<String, Object> domainList = new HashMap<String, Object>()
		domainList[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
		alQueryResponse.add(domainList)

		objectList.add('15')
		jdbcTemplate.queryForList(new String(selectStatement),
				objectList.toArray(new Object[objectList.size()])) >> alQueryResponse
        when:
        String domainName = testObj.getDomainName('15')
        then:
        domainName == 'slid.dum'
    }

    def "get attribute id from name success"() throws MPSException {
        given:
        selectStatement = 'SELECT attribute_id FROM attribute WHERE attribute_name = ?'
        String attributeName = 'SO'
		HashMap<String, Object> attributeList = new HashMap<String, Object>()
		attributeList[MPSDefs.DB_ATTRIBUTE_ID] = 2
		alQueryResponse.add(attributeList)

		objectList.add(attributeName)

		jdbcTemplate.queryForList(_, _) >> alQueryResponse
        when:
        String attributeId = testObj.getStatusNameByCode(2)
        then:
        attributeId == null
    }

}