package com.att.idp.idgraphcontactinfoms.helpers

import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.CommonUtil
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class ProcessTitanCBRHelperTest extends Specification {

    def ProcessTitanCBRHelper processTitanCBRHelperObj = new ProcessTitanCBRHelper()

    QueryProfileProofingInfoHelper oQueryProfileProofingInfo_H = Mock(QueryProfileProofingInfoHelper)

    HashMap resultHashSuccess = null
    HashMap resultHashError = null
    HashMap hmResult = null
    HashMap hmInput = null
    String stAppStatusMsg = null
    String stAppInfo = null
    ArrayList alAcctSorInvId = new ArrayList()

    def setup() {
        processTitanCBRHelperObj.oQueryProfileProofingInfoH = oQueryProfileProofingInfo_H
        hmResult = CommonUtil.hashMap
        hmResult[CommonDefs.DEVICE_IN_HAND_VALIDATION_STS] = '8'
        hmResult[CommonDefs.PHONE_MODIFIED_DATE] = '2018-12-02T15:51:13-06:00'
        hmResult[CommonDefs.PHONE_TYPE] = 'phone'
        hmResult['isATTNumber'] = '04563774'

        hmInput = CommonUtil.hashMap
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'

        resultHashSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG)
        resultHashSuccess['cbrInfo'] = hmResult
        resultHashSuccess['altCbrInfo'] = hmResult
        resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, 'Error returned from Helper')

    }

    def "process titan c b r helper e r r b a n n o t f o u n d"() {
        given:
        hmInput['accountInvariantIdList'] = alAcctSorInvId

        when:
        hmResult = processTitanCBRHelperObj.processTitanCBRInfo(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_BAN_NOT_FOUND'
    }

    def "process titan c b r helper exception"() {
        given:
        alAcctSorInvId.add(hmInput)
        hmInput['accountInvariantIdList'] = alAcctSorInvId

        when:
        hmResult = processTitanCBRHelperObj.processTitanCBRInfo(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "process titan c b r helper response null"() {
        given:
        alAcctSorInvId.add('00830046589')
        hmInput['accountInvariantIdList'] = alAcctSorInvId
        oQueryProfileProofingInfo_H.queryCRMProofingInfo(_) >> null

        when:
        hmResult = processTitanCBRHelperObj.processTitanCBRInfo(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_BAN_NOT_FOUND'
    }

    def "process titan c b r helper response error"() {
        given:
        alAcctSorInvId.add('00830046589')
        hmInput['accountInvariantIdList'] = alAcctSorInvId
        oQueryProfileProofingInfo_H.queryCRMProofingInfo(_) >> resultHashError

        when:
        hmResult = processTitanCBRHelperObj.processTitanCBRInfo(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_BAN_NOT_FOUND'
    }

    def "process titan c b r helper response success"() {
        given:
        alAcctSorInvId.add('00830046589')
        hmInput['accountInvariantIdList'] = alAcctSorInvId
        oQueryProfileProofingInfo_H.queryCRMProofingInfo(_) >> resultHashSuccess

        when:
        hmResult = processTitanCBRHelperObj.processTitanCBRInfo(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "process titan c b r helper response success with a t t number"() {
        given:
        alAcctSorInvId.add('00830046589')
        hmResult['isATTNumber'] = '0'
        hmResult[CommonDefs.SUBSCRIBER_ID] = 'subscriberId'
        hmInput['accountInvariantIdList'] = alAcctSorInvId
        oQueryProfileProofingInfo_H.queryCRMProofingInfo(_) >> resultHashSuccess

        when:
        hmResult = processTitanCBRHelperObj.processTitanCBRInfo(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "process titan c b r helper response success with m o b i l e"() {
        given:
        alAcctSorInvId.add('00830046589')
        hmResult['isATTNumber'] = '0'
        hmResult[CommonDefs.PHONE_TYPE] = 'Cell Phone'
        hmInput['accountInvariantIdList'] = alAcctSorInvId
        oQueryProfileProofingInfo_H.queryCRMProofingInfo(_) >> resultHashSuccess

        when:
        hmResult = processTitanCBRHelperObj.processTitanCBRInfo(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "process titan c b r helper response success with a t t m o b i l e"() {
        given:
        alAcctSorInvId.add('00830046589')
        hmResult['isATTNumber'] = '1'
        hmResult[CommonDefs.PHONE_TYPE] = 'Cell Phone'
        hmInput['accountInvariantIdList'] = alAcctSorInvId
        oQueryProfileProofingInfo_H.queryCRMProofingInfo(_) >> resultHashSuccess

        when:
        hmResult = processTitanCBRHelperObj.processTitanCBRInfo(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "process titan c b r helper response success with null date established"() {
        given:
        alAcctSorInvId.add('00830046589')
        hmResult['isATTNumber'] = '1'
        hmResult[CommonDefs.PHONE_TYPE] = 'Cell Phone'
        hmResult[CommonDefs.PHONE_MODIFIED_DATE] = '12132019 17:08:49'
        hmInput['accountInvariantIdList'] = alAcctSorInvId
        oQueryProfileProofingInfo_H.queryCRMProofingInfo(_) >> resultHashSuccess

        when:
        hmResult = processTitanCBRHelperObj.processTitanCBRInfo(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }
}