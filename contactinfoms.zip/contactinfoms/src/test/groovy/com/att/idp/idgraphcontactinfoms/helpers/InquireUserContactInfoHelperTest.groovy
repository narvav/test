package com.att.idp.idgraphcontactinfoms.helpers

import com.att.idp.idgraphcontactinfoms.db.helper.InquireUserContactInfoDBHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.CommonUtil
import spock.lang.Specification

class InquireUserContactInfoHelperTest extends Specification {

	def InquireUserContactInfoHelperObj = new InquireUserContactInfoHelper()

	InquireUserContactInfoDBHelper inquireUserContactInfoDBHelper = Mock(InquireUserContactInfoDBHelper)

	HashMap resultHashSuccess = null
	HashMap resultHashError = null
	HashMap hmResult = null
	HashMap hmInput = null
	String stAppStatusMsg = null
	String stAppInfo = null


	def setup() {
		System.setProperty('CommonConfigurationFilePath', './opt/att/ajsc/config/CommonConfigurationTest.xml')
		InquireUserContactInfoHelperObj.inquireUserContactInfoDBHelper=inquireUserContactInfoDBHelper

		hmInput = CommonUtil.hashMap

		hmInput[CommonDefs.TRANSACTION_NAME] = 'InquireUserContactInfo'
		hmInput[CommonDefs.GUID] = '564748493'
		hmInput[CommonDefs.TRANSACTION_ID] = '564748493'
		hmInput['isExternalCall'] = 'Y'
		hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'

		resultHashSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
				CErrorDefs.COMMON_SUCCESS_MSG)
		resultHashSuccess[CommonDefs.CONTACT_EMAIL] = 'dummy@att.com'
		resultHashSuccess[CommonDefs.CONTACT_EMAIL_VALID] = 'Y'
		resultHashSuccess[CommonDefs.CONTACT_EMAIL_EST_DATE] = '08032018 05:08:24'
		resultHashSuccess[CommonDefs.PREVIOUS_CONTACT_EMAIL] = 'abc@att.com'
		resultHashSuccess[CommonDefs.CONTACT_EMAIL_STATUS] = 'V'

		stAppInfo = 'Error returned from Helper'
		resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo)

	}


	def "test inquire user contact email invalid c s i error"() {
		given:
		hmInput[CommonDefs.CALLING_SYSTEM_ID] = null
		when:
		hmResult = InquireUserContactInfoHelperObj.inquireUserContactInfo(hmInput)
		then:
		hmResult[CommonDefs.COMMON_APP_INFO] == 'Result Hash is NULL '
	}


	def "test inquire user contact email invalid transaction id"() {
		given:
		hmInput[CommonDefs.TRANSACTION_ID] = null
		when:
		hmResult = InquireUserContactInfoHelperObj.inquireUserContactInfo(hmInput)
		then:
		hmResult[CommonDefs.COMMON_APP_INFO] == 'transactionId must be present'
	}


	def "test inquire user contact email invalid transaction name"() {
		given:
		hmInput[CommonDefs.TRANSACTION_NAME] = null
		when:
		hmResult = InquireUserContactInfoHelperObj.inquireUserContactInfo(hmInput)
		then:
		hmResult[CommonDefs.COMMON_APP_INFO] == 'transactionName should be InquireUserContactInfo'
	}


	def "test inquire user contact email invalid guid"() {
		given:
		hmInput[CommonDefs.GUID] = null
		when:
		hmResult = InquireUserContactInfoHelperObj.inquireUserContactInfo(hmInput)
		then:
		hmResult[CommonDefs.COMMON_APP_INFO] == 'guid must be present'
	}


	def "test inquire user contact email empty input"() {
		when:
		hmResult = InquireUserContactInfoHelperObj.inquireUserContactInfo(null)
		then:
		hmResult[CommonDefs.COMMON_APP_INFO] == 'Input Hash is NULL or EMPTY'
	}


	def "test inquire user contact email success"() {
		given:
		inquireUserContactInfoDBHelper.inquireUserContactInfo('564748493') >> resultHashSuccess
		when:
		hmResult = InquireUserContactInfoHelperObj.inquireUserContactInfo(hmInput)
		then:
		hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
	}


	def "test inquire user contact email for null output"() {
		given:
		inquireUserContactInfoDBHelper.inquireUserContactInfo('564748493') >> null
		when:
		hmResult = InquireUserContactInfoHelperObj.inquireUserContactInfo(hmInput)
		then:
		hmResult[CommonDefs.COMMON_APP_INFO] == 'Result Hash is NULL '
	}

}
