package com.att.idp.idgraphcontactinfoms.service.impl

import com.att.idp.idgraphcontactinfoms.exceptions.InvalidInputDataException
import com.att.idp.idgraphcontactinfoms.helpers.QueryCPNIAcccountContactHelper
import com.att.idp.idgraphcontactinfoms.resource.request.QueryCPNIAccountContactInfoRequest
import com.att.idp.idgraphcontactinfoms.resource.response.QueryCPNIAccountContactInfoResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import spock.lang.Specification
import jakarta.ws.rs.core.MultivaluedHashMap
import jakarta.ws.rs.core.MultivaluedMap
import static org.junit.jupiter.api.Assertions.assertThrows

class QueryCPNIAccountContactInfoServiceImplTest extends Specification {

	def QueryCPNIAccountContactInfoServiceImpl queryCPNIAccountContactInfoServiceImplObj = new QueryCPNIAccountContactInfoServiceImpl()
	QueryCPNIAcccountContactHelper queryAccountContactInfoHelper = Mock(QueryCPNIAcccountContactHelper)
	QueryCPNIAccountContactInfoRequest queryCPNIAccountContactInfoRequest = null
	MultivaluedMap<String, String> requestHeader = null
	Map<String, String> headers = new HashMap<>()

	def setup() throws Exception {
		queryCPNIAccountContactInfoServiceImplObj.queryAccountContactInfoHelper = queryAccountContactInfoHelper
		queryCPNIAccountContactInfoRequest = new QueryCPNIAccountContactInfoRequest()
		requestHeader = new MultivaluedHashMap<>(headers)

		queryCPNIAccountContactInfoRequest.callingSystemId = 'IDP'
		queryCPNIAccountContactInfoRequest.accountId = '64573738'
		queryCPNIAccountContactInfoRequest.accountInvariantId = '714189229'
		queryCPNIAccountContactInfoRequest.accountType = 'nor'
		queryCPNIAccountContactInfoRequest.returnCBRCTNs = '36546'
		queryCPNIAccountContactInfoRequest.isExternalCall = 'Y'
		queryCPNIAccountContactInfoRequest.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
	}

	def "query c p n i account null case test"() {
		// when QueryCPNI helper response not set
		when:
		QueryCPNIAccountContactInfoResponse response = queryCPNIAccountContactInfoServiceImplObj.queryCPNIAccountContactInfo(queryCPNIAccountContactInfoRequest, requestHeader)
		then:
		response.appInfo == 'Null response from queryAccountContactInfoHelper.queryCPNIAccountContactInfo'

		// when QueryCPNI helper response has been set, app status code is null
		HashMap hmResponse = new HashMap()
		when:
		hmResponse[MPSDefs.APP_STATUS_CODE] = null
		1 * queryAccountContactInfoHelper.queryCPNIAccountContact(_) >> hmResponse
		response = queryCPNIAccountContactInfoServiceImplObj.queryCPNIAccountContactInfo(queryCPNIAccountContactInfoRequest, requestHeader)
		then:
		response.appInfo == 'Null response from queryAccountContactInfoHelper.queryCPNIAccountContactInfo'
	}

	def "query c p n i account success case test"() {
		given:
		HashMap hmResponse = new HashMap()
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_16374856'
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		hmResponse['appInfo'] = 'Success'
		1 * queryAccountContactInfoHelper.queryCPNIAccountContact(_) >> hmResponse
		when:
		QueryCPNIAccountContactInfoResponse response = queryCPNIAccountContactInfoServiceImplObj.queryCPNIAccountContactInfo(queryCPNIAccountContactInfoRequest, requestHeader)
		then:
		response != null
		response.idpTraceId != null
	}

/*	def "query c p n i account when trans rollback set test"() {
		given:
		HashMap hmResponse = new HashMap()
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_16374856'
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		hmResponse['isTransactionRollback'] = 'true'
		1 * queryAccountContactInfoHelper.queryCPNIAccountContact(_) >> hmResponse

		expect:
		InvalidInputDataException excep = assertThrows(InvalidInputDataException.class, () -> {
			queryCPNIAccountContactInfoServiceImplObj.queryCPNIAccountContactInfo(queryCPNIAccountContactInfoRequest, requestHeader)
		})
	}*/
}