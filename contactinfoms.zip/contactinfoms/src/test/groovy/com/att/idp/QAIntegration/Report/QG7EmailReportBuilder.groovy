package com.att.idp.QAIntegration.Report

import java.text.SimpleDateFormat
import java.util.concurrent.atomic.AtomicInteger

/**
 * Builds a rich, modern HTML report for IDGraphContactInfoMs QG7 integration tests.
 *
 * Theme: Blue gradient header, glass-morphism cards, donut chart for pass rate,
 *        modern color palette optimised for both email clients and browser viewing.
 *
 * Sections:
 *   1. Blue gradient header with status pill
 *   2. Run info cards (Environment, GitHub Actions, Duration)
 *   3. KPI summary row with DONUT CHART for pass rate
 *   4. Test Flow Breakdown table with inline progress bars per spec
 *   5. Server-error panel (or clean-bill panel)
 *   6. Celebration / action-required banner
 *   7. Branded footer
 */
class QG7EmailReportBuilder {

    // ── Colour palette — BLUE THEME ─────────────────────────────────────
    private static final String BLUE_1      = "#1e40af"  // Deep blue
    private static final String BLUE_2      = "#3b82f6"  // Bright blue
    private static final String BLUE_GRAD   = "linear-gradient(135deg, ${BLUE_1} 0%, ${BLUE_2} 100%)"
    private static final String SKY_1       = "#56CCF2"
    private static final String SKY_2       = "#2F80ED"
    private static final String SKY_GRAD    = "linear-gradient(135deg, ${SKY_1} 0%, ${SKY_2} 100%)"
    private static final String DARK_TEXT   = "#1e293b"
    private static final String MUTED_TEXT  = "#64748b"
    private static final String GREEN       = "#10b981"
    private static final String GREEN_BG    = "#ecfdf5"
    private static final String RED         = "#ef4444"
    private static final String RED_BG      = "#fef2f2"
    private static final String AMBER       = "#f59e0b"
    private static final String AMBER_BG    = "#fffbeb"
    private static final String BLUE        = "#3b82f6"
    private static final String BLUE_BG     = "#eff6ff"
    private static final String CARD_BDR    = "#e2e8f0"
    private static final String BODY_BG     = "#f0f4f8"

    static String build(QG7TestResultCollector c) {
        c.endTimeMs = c.endTimeMs > 0 ? c.endTimeMs : System.currentTimeMillis()
        String runDate = new SimpleDateFormat("MMM dd, yyyy  hh:mm a z").format(new Date(c.startTimeMs))
        String endDate = new SimpleDateFormat("hh:mm a z").format(new Date(c.endTimeMs))

        int total   = c.totalTests.get()
        int passed  = c.passedTests.get()
        int failed  = c.failedTests.get()
        int skipped = c.skippedTests.get()
        double passRateVal = c.getPassRate()
        String passRate = String.format("%.1f", passRateVal)
        int passRateInt = passRateVal as int

        boolean hasFails  = !c.failedFlows.isEmpty()
        boolean has5xx    = !c.serverErrors.isEmpty()
        boolean allPassed = (failed == 0 && total > 0)

        String statusText  = allPassed ? "ALL PASSED" : "${failed} FAILED"
        String statusColor = allPassed ? GREEN : RED

        String ghRunUrl  = c.getGitHubRunUrl()
        String ghRunLink = ghRunUrl
                ? "<a href='${esc(ghRunUrl)}' style='color:${SKY_2};font-weight:700;text-decoration:none'>View Run #${esc(c.getGitHubRunNumber())} &rarr;</a>"
                : "<span style='color:${MUTED_TEXT}'>Local Run</span>"

        StringBuilder sb = new StringBuilder()

        // ── HTML OPEN + HEADER ─────────────────────────────────────────
        sb.append("""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:24px;background:${BODY_BG};font-family:'Segoe UI',system-ui,-apple-system,Arial,sans-serif;color:${DARK_TEXT}">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:1200px;margin:0 auto;background:#fff;border-radius:24px;overflow:hidden;box-shadow:0 12px 48px rgba(30,64,175,.15)">

  <!-- ═══ HEADER — BLUE THEME ═══ -->
  <tr><td bgcolor="#1e40af" style="background:${BLUE_GRAD};padding:40px 36px;text-align:center">
    <div style="font-size:13px;font-weight:600;color:rgba(255,255,255,.85);text-transform:uppercase;letter-spacing:2px;margin-bottom:10px">IDGraphContactInfoMs</div>
    <div style="font-size:28px;font-weight:900;color:#fff;letter-spacing:-.5px">QG7 Integration Test Report</div>
    <div style="margin-top:18px">
      <span style="display:inline-block;background:${statusColor};color:#fff;font-weight:800;padding:10px 32px;border-radius:24px;font-size:14px;letter-spacing:.8px;box-shadow:0 4px 16px rgba(0,0,0,.2)">${statusText}</span>
    </div>
    <div style="margin-top:16px;font-size:13px;color:rgba(255,255,255,.8)">${runDate}</div>
  </td></tr>

  <!-- ═══ RUN INFO CARDS ═══ -->
  <tr><td style="padding:24px 24px 8px">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>
      ${infoCard("Environment", esc(c.getEnvironment()), "Suite", "QG7 Integration", "Service", "ContactInfoMs", SKY_2)}
      ${githubCard(c, ghRunLink)}
      ${durationCard(c.getDuration(), runDate, endDate)}
    </tr></table>
  </td></tr>

  <!-- ═══ KPI CARDS ═══ -->
  <tr><td style="padding:16px 24px 8px">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>
      ${kpiCard(String.valueOf(total),   "Total",   BLUE,  BLUE_BG)}
      ${kpiCard(String.valueOf(passed),  "Passed",  GREEN, GREEN_BG)}
      ${kpiCard(String.valueOf(failed),  "Failed",  RED,   RED_BG)}
      ${kpiCard(String.valueOf(skipped), "Skipped", AMBER, AMBER_BG)}
    </tr></table>
  </td></tr>

  <!-- ═══ PASS RATE BAR ═══ -->
  <tr><td style="padding:8px 28px 16px">
    <table role="presentation" width="100%" style="background:#f8fafc;border:1px solid ${CARD_BDR};border-radius:16px"><tr>
      <td style="padding:24px 32px">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>
          <td style="vertical-align:middle;width:120px">
            <div style="font-size:38px;font-weight:900;color:${allPassed ? GREEN : (passRateInt >= 80 ? GREEN : (passRateInt >= 50 ? AMBER : RED))};line-height:1">${passRate}%</div>
            <div style="font-size:10px;font-weight:700;color:${MUTED_TEXT};text-transform:uppercase;letter-spacing:1px;margin-top:5px">Pass Rate</div>
          </td>
          <td style="vertical-align:middle;padding-left:24px">
            <!-- Stacked progress bar -->
            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
              <tr><td style="background:#e2e8f0;border-radius:8px;height:14px;overflow:hidden;font-size:0;line-height:0">
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse"><tr>
                  <td width="${passRateInt}%" style="background:${allPassed ? GREEN : (passRateInt >= 80 ? GREEN : (passRateInt >= 50 ? AMBER : RED))};height:14px;border-radius:${failed > 0 ? '8px 0 0 8px' : '8px'};font-size:0;line-height:0">&nbsp;</td>
                  ${failed > 0 ? "<td width=\"${total > 0 ? ((failed * 100 / total) as int) : 0}%\" style=\"background:${RED};height:14px;${skipped == 0 ? 'border-radius:0 8px 8px 0;' : ''}font-size:0;line-height:0\">&nbsp;</td>" : ""}
                  ${skipped > 0 ? "<td width=\"${total > 0 ? ((skipped * 100 / total) as int) : 0}%\" style=\"background:${AMBER};height:14px;border-radius:0 8px 8px 0;font-size:0;line-height:0\">&nbsp;</td>" : ""}
                </tr></table>
              </td></tr>
            </table>
            <!-- Legend row -->
            <table role="presentation" cellpadding="0" cellspacing="0" style="margin-top:10px"><tr>
              <td style="padding-right:18px"><span style="display:inline-block;width:10px;height:10px;background:${allPassed ? GREEN : (passRateInt >= 80 ? GREEN : (passRateInt >= 50 ? AMBER : RED))};border-radius:3px;vertical-align:middle;margin-right:5px"></span><span style="font-size:12px;font-weight:700;color:${DARK_TEXT}">${passed}</span><span style="font-size:11px;color:${MUTED_TEXT}"> Passed (${total > 0 ? String.format("%.1f", passed * 100.0 / total) : "0"}%)</span></td>
              <td style="padding-right:18px"><span style="display:inline-block;width:10px;height:10px;background:${RED};border-radius:3px;vertical-align:middle;margin-right:5px"></span><span style="font-size:12px;font-weight:700;color:${DARK_TEXT}">${failed}</span><span style="font-size:11px;color:${MUTED_TEXT}"> Failed (${total > 0 ? String.format("%.1f", failed * 100.0 / total) : "0"}%)</span></td>
              ${skipped > 0 ? "<td><span style=\"display:inline-block;width:10px;height:10px;background:${AMBER};border-radius:3px;vertical-align:middle;margin-right:5px\"></span><span style=\"font-size:12px;font-weight:700;color:${DARK_TEXT}\">${skipped}</span><span style=\"font-size:11px;color:${MUTED_TEXT}\"> Skipped (${String.format('%.1f', skipped * 100.0 / total)}%)</span></td>" : ""}
            </tr></table>
          </td>
        </tr></table>
      </td>
    </tr></table>
  </td></tr>
""")

        // ── TEST FLOW BREAKDOWN ──────────────────────────────────────────
        List<String> specNames = c.specTotal.keySet().toList().sort()
        if (specNames) {
            sb.append("""
  <tr><td style="padding:8px 28px">
    <table role="presentation" width="100%" style="border:1px solid ${CARD_BDR};border-radius:16px;overflow:hidden">
      <tr><td bgcolor="#1e40af" style="background:${BLUE_GRAD};padding:18px 28px">
        <div style="font-size:16px;font-weight:800;color:#fff">Test Flow Breakdown</div>
        <div style="font-size:11px;color:rgba(255,255,255,.75);margin-top:4px">${specNames.size()} spec(s) executed</div>
      </td></tr>
      <tr><td style="padding:0"><table width="100%" style="border-collapse:collapse;font-size:13px">
        <thead><tr style="background:#f8fafc">
          <th style="text-align:left;padding:12px 20px;color:${MUTED_TEXT};font-weight:700;font-size:11px;text-transform:uppercase;letter-spacing:.5px;border-bottom:2px solid #e2e8f0">Spec</th>
          <th style="text-align:center;padding:12px;color:${MUTED_TEXT};font-weight:700;font-size:11px;text-transform:uppercase;border-bottom:2px solid #e2e8f0">Total</th>
          <th style="text-align:center;padding:12px;color:${MUTED_TEXT};font-weight:700;font-size:11px;text-transform:uppercase;border-bottom:2px solid #e2e8f0">Pass</th>
          <th style="text-align:center;padding:12px;color:${MUTED_TEXT};font-weight:700;font-size:11px;text-transform:uppercase;border-bottom:2px solid #e2e8f0">Fail</th>
          <th style="text-align:left;padding:12px 20px;color:${MUTED_TEXT};font-weight:700;font-size:11px;text-transform:uppercase;border-bottom:2px solid #e2e8f0">Progress</th>
          <th style="text-align:center;padding:12px 16px;color:${MUTED_TEXT};font-weight:700;font-size:11px;text-transform:uppercase;border-bottom:2px solid #e2e8f0">Status</th>
        </tr></thead><tbody>
""")
            int si = 0
            specNames.each { String spec ->
                si++
                int sTotal  = c.specTotal.getOrDefault(spec,   new AtomicInteger(0)).get()
                int sPassed = c.specPassed.getOrDefault(spec,  new AtomicInteger(0)).get()
                int sFailed = c.specFailed.getOrDefault(spec,  new AtomicInteger(0)).get()
                int pct     = sTotal > 0 ? ((sPassed * 100) / sTotal) as int : 0
                String rowBg   = (si % 2 == 0) ? '#f8fafc' : '#ffffff'
                String barColor = sFailed > 0 ? RED : GREEN
                String stPill   = sFailed > 0
                        ? "<span style='background:${RED_BG};color:${RED};padding:4px 14px;border-radius:12px;font-weight:700;font-size:11px;border:1px solid #fecaca'>FAIL</span>"
                        : "<span style='background:${GREEN_BG};color:${GREEN};padding:4px 14px;border-radius:12px;font-weight:700;font-size:11px;border:1px solid #a7f3d0'>PASS</span>"
                sb.append("""          <tr style="background:${rowBg}">
            <td style="padding:12px 20px;font-weight:600;color:${DARK_TEXT}">${esc(spec)}</td>
            <td style="padding:12px;text-align:center;font-weight:700;color:${DARK_TEXT}">${sTotal}</td>
            <td style="padding:12px;text-align:center;font-weight:700;color:${GREEN}">${sPassed}</td>
            <td style="padding:12px;text-align:center;font-weight:700;color:${sFailed > 0 ? RED : '#cbd5e1'}">${sFailed > 0 ? sFailed : '-'}</td>
            <td style="padding:12px 20px"><div style="background:#e2e8f0;border-radius:6px;height:8px;overflow:hidden;min-width:100px"><div style="width:${pct}%;height:100%;border-radius:6px;background:${barColor}"></div></div><div style="font-size:10px;color:${MUTED_TEXT};margin-top:3px">${pct}%</div></td>
            <td style="padding:12px 16px;text-align:center">${stPill}</td>
          </tr>
""")
            }
            sb.append("        </tbody></table></td></tr></table></td></tr>")
        }

        // ── 5XX-ERROR PANEL ──────────────────────────────────────────────
        sb.append("""
  <tr><td style="padding:8px 28px">
    <table role="presentation" width="100%" style="border:1px solid ${CARD_BDR};border-radius:16px;overflow:hidden">
      <tr><td bgcolor="${has5xx ? '#ef4444' : '#1e40af'}" style="background:${has5xx ? RED : BLUE_GRAD};padding:16px 28px">
        <div style="font-size:15px;font-weight:800;color:#fff">5XX Server Errors</div>
        <div style="font-size:11px;color:rgba(255,255,255,.75);margin-top:3px">HTTP 500 / 502 / 503 endpoint failures</div>
      </td></tr>
""")
        if (has5xx) {
            sb.append("<tr><td style='padding:0'><table width='100%' style='border-collapse:collapse;font-size:13px'><thead><tr style='background:${RED_BG}'><th style='text-align:left;padding:11px 16px;color:#991b1b;font-weight:700;border-bottom:2px solid #fecaca;font-size:11px;text-transform:uppercase'>#</th><th style='text-align:left;padding:11px 16px;color:#991b1b;font-weight:700;border-bottom:2px solid #fecaca;font-size:11px;text-transform:uppercase'>Endpoint</th><th style='text-align:center;padding:11px 16px;color:#991b1b;font-weight:700;border-bottom:2px solid #fecaca;font-size:11px;text-transform:uppercase'>Hits</th></tr></thead><tbody>")
            int ei = 0
            c.getServerErrorsByEndpoint().each { Map<String, Object> entry ->
                ei++
                String ebg = (ei % 2 == 0) ? RED_BG : "#fff"
                sb.append("<tr style='background:${ebg}'><td style='padding:10px 16px;font-weight:700;color:${RED}'>${ei}</td><td style='padding:10px 16px;font-family:monospace;font-size:12px;color:${DARK_TEXT}'>${esc(entry.endpoint as String)}</td><td style='padding:10px 16px;text-align:center'><span style='background:${RED};color:#fff;padding:4px 16px;border-radius:12px;font-weight:700;font-size:12px'>${entry.count}</span></td></tr>")
            }
            sb.append("</tbody></table></td></tr>")
        } else {
            sb.append("<tr><td style='padding:32px;text-align:center;background:#f8fafc'><div style='font-size:32px;margin-bottom:8px'>&#9989;</div><div style='font-size:15px;font-weight:700;color:${GREEN}'>No 5XX Errors Detected</div><div style='font-size:11px;color:${MUTED_TEXT};margin-top:4px'>All endpoints returned healthy responses</div></td></tr>")
        }
        sb.append("    </table></td></tr>")

        // ── CELEBRATION / ACTION REQUIRED ─────────────────────────────────
        if (allPassed) {
            sb.append("""
  <tr><td style="padding:8px 24px"><table role="presentation" width="100%" style="border:2px solid #a7f3d0;border-radius:20px;background:${GREEN_BG}">
    <tr><td style="padding:32px;text-align:center">
      <div style="font-size:42px;margin-bottom:10px">&#127881;</div>
      <div style="font-size:20px;font-weight:900;color:${GREEN}">All ${total} Test Cases Passed!</div>
      <div style="font-size:12px;color:${MUTED_TEXT};margin-top:8px">No action required &mdash; service is healthy</div>
    </td></tr>
  </table></td></tr>""")
        }
        if (hasFails) {
            sb.append("""
  <tr><td style="padding:8px 24px"><table role="presentation" width="100%" style="background:${RED_BG};border:2px solid #fca5a5;border-radius:20px">
    <tr><td style="padding:24px 28px">
      <div style="font-size:15px;font-weight:800;color:${RED};margin-bottom:8px">&#9888;&#65039; Action Required</div>
      <div style="font-size:13px;color:#991b1b;line-height:1.8"><strong>${failed} test case(s)</strong> failed. Open the attached Spark HTML report for request/response details and stack traces.</div>
    </td></tr>
  </table></td></tr>""")
        }

        // ── FOOTER — BLUE THEME ─────────────────────────────────────────────
        sb.append("""
  <tr><td bgcolor="#1e40af" style="padding:28px 36px;background:${BLUE_GRAD};text-align:center">
    <div style="font-size:15px;font-weight:700;color:#fff;margin-bottom:8px">IDGraphContactInfoMs &mdash; QG7 Integration Tests</div>
    <div style="font-size:12px;color:rgba(255,255,255,.85);line-height:1.8">
      Env: ${esc(c.getEnvironment())} &bull; Duration: ${c.getDuration()} &bull; Pass Rate: ${passRate}%<br/>
      Generated: ${runDate}
    </div>
  </td></tr>
</table></body></html>""")

        return sb.toString()
    }

    // ── Card Helpers ──────────────────────────────────────────────────────

    private static String kpiCard(String value, String label, String accent, String bg) {
        "<td style='padding:0 6px'><table role='presentation' width='100%' style='border:1.5px solid ${accent}22;border-radius:16px;background:${bg}'><tr><td style='padding:20px 12px;text-align:center'><div style='font-size:32px;font-weight:900;color:${accent};line-height:1'>${value}</div><div style='font-size:10px;font-weight:700;color:${MUTED_TEXT};text-transform:uppercase;letter-spacing:.8px;margin-top:8px'>${label}</div></td></tr></table></td>"
    }

    private static String infoCard(String title, String mainVal, String k1, String v1, String k2, String v2, String accent) {
        "<td style='width:33%;padding:0 8px 0 0;vertical-align:top'><table role='presentation' width='100%' style='background:#fff;border:1px solid ${CARD_BDR};border-radius:16px;border-top:4px solid ${accent};box-shadow:0 2px 12px rgba(59,130,246,.08)'><tr><td style='padding:20px'><div style='font-size:10px;font-weight:800;color:${accent};text-transform:uppercase;letter-spacing:1.5px;margin-bottom:10px'>${title}</div><div style='font-size:24px;font-weight:900;color:${DARK_TEXT};margin-bottom:10px'>${mainVal}</div><div style='font-size:12px;color:#475569'><b>${k1}:</b> ${v1}</div><div style='font-size:12px;color:#475569;margin-top:4px'><b>${k2}:</b> ${v2}</div></td></tr></table></td>"
    }

    private static String githubCard(QG7TestResultCollector c, String ghRunLink) {
        "<td style='width:33%;padding:0 4px;vertical-align:top'><table role='presentation' width='100%' style='background:#fff;border:1px solid ${CARD_BDR};border-radius:16px;border-top:4px solid #24292e;box-shadow:0 2px 12px rgba(0,0,0,.06)'><tr><td style='padding:20px'><div style='font-size:10px;font-weight:800;color:#24292e;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:10px'>GitHub Actions</div><div style='font-size:12px;color:#475569;margin-bottom:5px'><b>Workflow:</b> ${esc(c.getGitHubWorkflow())}</div><div style='font-size:12px;color:#475569;margin-bottom:5px'><b>Run #:</b> ${esc(c.getGitHubRunNumber())}</div><div style='font-size:12px;color:#475569;margin-bottom:5px'><b>Actor:</b> @${esc(c.getGitHubActor())}</div><div style='margin-top:8px'>${ghRunLink}</div></td></tr></table></td>"
    }

    private static String durationCard(String duration, String start, String end) {
        "<td style='width:33%;padding:0 0 0 8px;vertical-align:top'><table role='presentation' width='100%' style='background:#fff;border:1px solid ${CARD_BDR};border-radius:16px;border-top:4px solid ${SKY_1};box-shadow:0 2px 12px rgba(86,204,242,.10)'><tr><td style='padding:20px'><div style='font-size:10px;font-weight:800;color:${SKY_2};text-transform:uppercase;letter-spacing:1.5px;margin-bottom:10px'>Run Duration</div><div style='font-size:32px;font-weight:900;color:${DARK_TEXT};margin-bottom:10px'>${duration}</div><div style='font-size:12px;color:#475569'><b>Start:</b> ${start}</div><div style='font-size:12px;color:#475569;margin-top:4px'><b>End:</b> ${end}</div></td></tr></table></td>"
    }

    private static String esc(String s) {
        if (!s) return ""
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
    }
}
