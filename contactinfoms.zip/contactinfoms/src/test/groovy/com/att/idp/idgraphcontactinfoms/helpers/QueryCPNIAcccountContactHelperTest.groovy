package com.att.idp.idgraphcontactinfoms.helpers

import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.CommonUtil
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import spock.lang.Unroll


class QueryCPNIAccountContactHelperTest extends Specification {

    def QueryCPNIAcccountContactHelper queryCPNIAccountContactHelperObj = new QueryCPNIAcccountContactHelper()
    ProcessEcommTitanCPNIHelper objProcessEcommTitanCPNIHelper = Mock(ProcessEcommTitanCPNIHelper)
    ProcessMobilityCPNIHelper objprocessMobilityCPNIHelper = Mock(ProcessMobilityCPNIHelper)
    ExternalDestinationHelper objExternalDestinationHelper = Mock(ExternalDestinationHelper)
    FeatureManagerHelper featureManager = Mock(FeatureManagerHelper)
    ProcessTitanCPNIHelper objProcessTitanCPNIHelper = Mock(ProcessTitanCPNIHelper)

    String stTransactionId = null
    HashMap resultHashSuccess = null
    HashMap resultHashError = null
    HashMap hmResult = null
    HashMap hmRes = null
    HashMap hmInput = null
    String stAppStatusMsg = null
    String stAppInfo = null

    def setup() {
        queryCPNIAccountContactHelperObj.objProcessEcommTitanCPNIHelper = objProcessEcommTitanCPNIHelper
        queryCPNIAccountContactHelperObj.objprocessMobilityCPNIHelper = objprocessMobilityCPNIHelper
        queryCPNIAccountContactHelperObj.objExternalDestinationHelper = objExternalDestinationHelper
        queryCPNIAccountContactHelperObj.objProcessTitanCPNIHelper = objProcessTitanCPNIHelper
        queryCPNIAccountContactHelperObj.featureManager = featureManager
        System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')
        stTransactionId = 'as00_123'

        hmInput = CommonUtil.hashMap

        resultHashSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG)
        stAppInfo = 'Error returned from Helper'
        resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo)
        ReflectionTestUtils.setField(queryCPNIAccountContactHelperObj, 'stValidCallers', 'DATAMGT|IDP|CSRIDP|ILM|MULESOFT|OPUS|CUSTOMERGRAPH|AVERTACK')
    }

    def "query c p n i account contactaccount invariant id error"() {
        given:
        featureManager.isEnabled(_ as String)>>false
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIAccountContactInfo'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'

        when:
        hmResult = queryCPNIAccountContactHelperObj.queryCPNIAccountContact(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Either accountInvariantId or accountId must be present in input'
    }

    def "query c p n i account contact c t n error case"() {
        given:
        featureManager.isEnabled(_ as String)>>false
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIAccountContactInfo'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        hmInput[CommonDefs.ACCOUNT_INVARIANT_ID] = null
        hmInput[CommonDefs.ACCOUNT_ID] = '45476839'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'

        when:
        hmResult = queryCPNIAccountContactHelperObj.queryCPNIAccountContact(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'CTN should be of 10 digits'
    }

    def "query c p n i account contact error case"() {
        given:
        featureManager.isEnabled(_ as String)>>false
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIAccountContactInfo'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        hmInput[CommonDefs.ACCOUNT_INVARIANT_ID] = '98765'
        hmInput[CommonDefs.ACCOUNT_ID] = '4547683934'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['filterSIMSwapCTNs'] = 'Y'


        when:
        hmResult = queryCPNIAccountContactHelperObj.queryCPNIAccountContact(hmInput)

        then:
        _ * objExternalDestinationHelper.callMultipleDestinations(_ as HashMap) >> hmInput
        _ * objprocessMobilityCPNIHelper.processMobilityCPNI(_ as HashMap, _ as HashMap) >> resultHashError
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Response from QueryCPNIAcccountContactHelper is NULL'
    }

    def "query c p n i account contact e r r s y s a p p l error case"() {
        given:
        featureManager.isEnabled(_ as String)>>false
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIAccountContactInfo'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        hmInput[CommonDefs.ACCOUNT_INVARIANT_ID] = null
        hmInput[CommonDefs.ACCOUNT_ID] = '4547683934'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['filterSIMSwapCTNs'] = 'N'
        objprocessMobilityCPNIHelper.processMobilityCPNI(_, _) >> resultHashSuccess
        objExternalDestinationHelper.callMultipleDestinations(_)>> resultHashSuccess

        when:
        hmResult = queryCPNIAccountContactHelperObj.queryCPNIAccountContact(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "query c p n i account contact invalid b t n error case"() {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIAccountContactInfo'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'ECOMM'
        hmInput[CommonDefs.ACCOUNT_INVARIANT_ID] = null
        hmInput[CommonDefs.ACCOUNT_ID] = '454768393423'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'

        when:
        hmResult = queryCPNIAccountContactHelperObj.queryCPNIAccountContact(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'BTN should be 13 digits'
    }

    def "query c p n i account contact e c o m m error case"() {
        given:
        featureManager.isEnabled(_ as String)>>false
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIAccountContactInfo'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'ECOMM'
        hmInput[CommonDefs.ACCOUNT_INVARIANT_ID] = null
        hmInput[CommonDefs.ACCOUNT_ID] = '4547683934123'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        objExternalDestinationHelper.callMultipleDestinations(_)>> resultHashSuccess
        when:
        hmResult = queryCPNIAccountContactHelperObj.queryCPNIAccountContact(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Response from QueryCPNIAcccountContactHelper is NULL'
    }

    def "query c p n i account contact success case"() {
        given:
        featureManager.isEnabled(_ as String)>>false
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIAccountContactInfo'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'ECOMM'
        hmInput[CommonDefs.ACCOUNT_INVARIANT_ID] = null
        hmInput[CommonDefs.ACCOUNT_ID] = '4547683934243'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'

        objProcessEcommTitanCPNIHelper.processEcommTitanCPNI(_ , _ ) >> resultHashSuccess
        objExternalDestinationHelper.callMultipleDestinations(_)>> resultHashSuccess
        when:
        hmResult = queryCPNIAccountContactHelperObj.queryCPNIAccountContact(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    @Unroll
    def "should process Titan service with CG call for #scenarioName"() {
        given: "Titan account type and feature flag enabled"

        HashMap<String, Object> hmInput = new HashMap<>()
        hmInput.put(CommonDefs.TRANSACTION_NAME, "QueryCPNIAccountContactInfo")
        hmInput.put(CommonDefs.ACCOUNT_TYPE, CommonDefs.TITAN_SERVICE)
        hmInput.put(CommonDefs.ACCOUNT_INVARIANT_ID, "TITAN123")
        hmInput.put(CommonDefs.ACCOUNT_ID, "9876543210123")
        hmInput.put(CommonDefs.CALLING_SYSTEM_ID, "IDP")
        HashMap<String, Object> titanResult = new HashMap<>()
        titanResult.put(CommonDefs.COMMON_APP_INFO, "SUCCESS")

        when: "queryCPNIAccountContact is called"
        HashMap<String, Object> result = null
        featureManager.isEnabled("svc-idgraph-contactinfo-cpni-uverse-callcg") >> true
        objProcessTitanCPNIHelper.getTitanCPNIContacts(hmInput) >> titanResult
        result = queryCPNIAccountContactHelperObj.queryCPNIAccountContact(hmInput)

        then: "Titan helper is called and result is returned"
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-cpni-uverse-callcg") >> true

        and: "Result contains expected Titan response"
        result != null
        result.get(CommonDefs.COMMON_APP_INFO) == "SUCCESS"

        where: "Different Titan scenarios"
        scenarioName | _
        "Titan CG call enabled" | _
    }


}