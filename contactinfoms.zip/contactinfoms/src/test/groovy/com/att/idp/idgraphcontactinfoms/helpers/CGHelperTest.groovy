// groovy
package com.att.idp.idgraphcontactinfoms.helpers

import com.att.idp.cgclienthelpers.integration.CGRestClient
import com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig
import com.att.idp.idgraphcontactinfoms.integration.OutboundRestClientBuilder
import com.att.idp.http.client.config.RestTemplateBeanFactory
import org.jboss.logging.MDC
import org.springframework.test.util.ReflectionTestUtils
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent
import org.springframework.web.client.RestTemplate
import spock.lang.Specification

class CGHelperTest extends Specification {

    def cgRestClient = Mock(CGRestClient)
    def restTemplateBeanFactory = Mock(RestTemplateBeanFactory)
    def appConfiguration = Mock(IDGraphAzureAppConfig)
    def outboundRestClientBuilder = Mock(OutboundRestClientBuilder)
    def restTemplate = Mock(RestTemplate)
    def cgHelper

    def setup() {
        cgHelper = new CGHelper(restTemplateBeanFactory, appConfiguration, outboundRestClientBuilder)
        ReflectionTestUtils.setField(cgHelper, 'cgRestClient', cgRestClient)
        ReflectionTestUtils.setField(cgHelper, 'restTemplate', restTemplate)
        MDC.clear()
    }

    def "test onConfiguration Refresh event"() {
        given:
        RefreshScopeRefreshedEvent event = Mock(RefreshScopeRefreshedEvent)
        appConfiguration.isCgRestClientRefreshEnabled() >> false

        when:
        cgHelper.onConfigurationRefresh()

        then:
        noExceptionThrown()
    }

    def "test makeCGSyncCall with valid input"() {
        given:
        Map<String, Object> input = [key: "value"]
        Map<String, Object> expectedResponse = [response: "success"]
        cgRestClient.getCGSyncCall(_) >> expectedResponse

        when:
        Map<String, Object> result = cgHelper.makeCGSyncCall(input, "http://test-endpoint")

        then:
        result == expectedResponse
        input.containsKey(CGHelper.REFRESHED_REST_TEMPLATE_BEAN)
        input.containsKey("cgEndPoint")
    }

    def "test makeCGSyncCall with null input"() {
        given:
        Map<String, Object> input = null

        when:
        Map<String, Object> result = cgHelper.makeCGSyncCall(input, "http://test-endpoint")

        then:
        result.isEmpty()
    }

    def "test onConfigurationRefresh with successful update"() {
        given:
        appConfiguration.isCgRestClientRefreshEnabled() >> false
        appConfiguration.getInquireprofilerestclientConnectTimeout() >> 5000
        appConfiguration.getInquireprofilerestclientReadTimeout() >> 10000
        outboundRestClientBuilder.buildRestTemplate(_, 5000, 10000, false, null) >> restTemplate

        when:
        cgHelper.onConfigurationRefresh()

        then:
        noExceptionThrown()
    }

    def "test onConfigurationRefresh with exception during update"() {
        given:
        appConfiguration.isCgRestClientRefreshEnabled() >> false
        appConfiguration.getInquireprofilerestclientConnectTimeout() >> 5000
        appConfiguration.getInquireprofilerestclientReadTimeout() >> 10000
        outboundRestClientBuilder.buildRestTemplate(_, 5000, 10000, false, null) >> { throw new RuntimeException("Update failed") }

        when:
        cgHelper.onConfigurationRefresh()

        then:
        noExceptionThrown()
    }

    def "should make CG sync call and return expected response for #scenarioName"() {
        given:
        HashMap<String, Object> hmCGInput = new HashMap<>()
        hmCGInput.put("key", inputValue)
        HashMap<String, Object> expectedResponse = new HashMap<>()
        expectedResponse.put("response", expectedResult)

        when:
        HashMap<String, Object> result = cgHelper.makeCGSyncCall(hmCGInput, endpoint)

        then:
        1 * cgRestClient.getCGSyncCall({ HashMap<String, Object> map ->
            map.get("key") == inputValue &&
                    map.get(CGHelper.REFRESHED_REST_TEMPLATE_BEAN) == restTemplate &&
                    map.get("cgEndPoint") == endpoint
        }) >> expectedResponse
        0 * _
        result.get("response") == expectedResult
        hmCGInput.get(CGHelper.REFRESHED_REST_TEMPLATE_BEAN) == restTemplate
        hmCGInput.get("cgEndPoint") == endpoint

        where:
        scenarioName      | inputValue | endpoint           | expectedResult
        "basic input"     | "value1"   | "http://endpoint1" | "success"
        "alternate input" | "value2"   | "http://endpoint2" | "ok"
    }

    def "should return empty map when makeCGSyncCall is called with null input"() {
        given:
        HashMap<String, Object> hmCGInput = null

        when:
        HashMap<String, Object> result = cgHelper.makeCGSyncCall(hmCGInput, "http://endpoint")

        then:
        0 * cgRestClient.getCGSyncCall(_)
        0 * _
        result.isEmpty()
    }

    def "should handle configuration refresh event and update restTemplate successfully for #scenarioName"() {
        given:
        Integer connectTimeout = 0
        Integer readTimeout = 0
        appConfiguration.getCgConnectTimeout() >> connectTimeout
        appConfiguration.getCgReadTimeout() >> readTimeout
        appConfiguration.isCgRestClientRefreshEnabled() >> true

        when:
        cgHelper.onConfigurationRefresh()

        then:
        1 * appConfiguration.isCgRestClientRefreshEnabled() >> true
        3 * appConfiguration.getCgConnectTimeout() >> connectTimeout
        3 * appConfiguration.getCgReadTimeout() >> readTimeout
        1 * outboundRestClientBuilder.buildRestTemplate(restTemplate, connectTimeout, readTimeout, false, null) >> restTemplate
        0 * _
        notThrown(Exception)

        where:
        scenarioName | _
        "default"    | _
    }

    def "should handle exception during configuration refresh and retain old restTemplate for #scenarioName"() {
        given:
        Integer connectTimeout = 10
        Integer readTimeout = 10
        appConfiguration.isCgRestClientRefreshEnabled() >> false
        appConfiguration.getCgConnectTimeout() >> connectTimeout
        appConfiguration.getCgReadTimeout() >> readTimeout
        outboundRestClientBuilder.buildRestTemplate(restTemplate, connectTimeout, readTimeout, false, null) >> { throw new RuntimeException("Update failed") }

        when:
        cgHelper.onConfigurationRefresh()

        then:
        1 * appConfiguration.isCgRestClientRefreshEnabled() >> false
        0 * appConfiguration.getCgConnectTimeout() >> connectTimeout
        0 * appConfiguration.getCgReadTimeout() >> readTimeout
        0 * outboundRestClientBuilder.buildRestTemplate(restTemplate, connectTimeout, readTimeout, false, null) >> { throw new RuntimeException("Update failed") }
        0 * _
        notThrown(Exception)

        where:
        scenarioName | _
        "exception"  | _
    }

    // ============================================================
    // Additional coverage: onConfigurationRefresh exception with enabled=true
    // Covers lines 96-98 (catch block inside synchronized)
    // ============================================================

    def "onConfigurationRefresh catches exception when enabled and buildRestTemplate fails"() {
        given:
        appConfiguration.isCgRestClientRefreshEnabled() >> true
        appConfiguration.getCgConnectTimeout() >> 5000
        appConfiguration.getCgReadTimeout() >> 10000
        outboundRestClientBuilder.buildRestTemplate(_, _, _, _, _) >> { throw new RuntimeException("Connection pool error") }

        when:
        cgHelper.onConfigurationRefresh()

        then:
        noExceptionThrown()
    }

    // ============================================================
    // Additional coverage: onConfigurationRefresh with null restTemplate
    // Covers lines 89-90 (restTemplate == null branch)
    // ============================================================

    def "onConfigurationRefresh recreates restTemplate from factory when null"() {
        given:
        ReflectionTestUtils.setField(cgHelper, 'restTemplate', null)
        appConfiguration.isCgRestClientRefreshEnabled() >> true
        appConfiguration.getCgConnectTimeout() >> 3000
        appConfiguration.getCgReadTimeout() >> 6000
        restTemplateBeanFactory.getObject('cgrestclient') >> restTemplate
        outboundRestClientBuilder.buildRestTemplate(restTemplate, 3000, 6000, false, null) >> restTemplate

        when:
        cgHelper.onConfigurationRefresh()

        then:
        noExceptionThrown()
    }

    // ============================================================
    // Additional coverage: initializeRestTemplate with null restTemplate
    // Covers line 108-109 (null check in initializeRestTemplate)
    // ============================================================

    def "init with null restTemplate creates from factory"() {
        given:
        ReflectionTestUtils.setField(cgHelper, 'restTemplate', null)
        restTemplateBeanFactory.getObject('cgrestclient') >> restTemplate
        appConfiguration.getCgConnectTimeout() >> 2000
        appConfiguration.getCgReadTimeout() >> 4000
        outboundRestClientBuilder.buildRestTemplate(restTemplate, 2000, 4000, false, null) >> restTemplate

        when:
        cgHelper.init()

        then:
        noExceptionThrown()
    }

    def "init handles exception from buildRestTemplate gracefully"() {
        given:
        appConfiguration.getCgConnectTimeout() >> 2000
        appConfiguration.getCgReadTimeout() >> 4000
        outboundRestClientBuilder.buildRestTemplate(_, _, _, _, _) >> { throw new RuntimeException("Build failed") }

        when:
        cgHelper.init()

        then:
        noExceptionThrown()
    }

}