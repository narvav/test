package com.att.idp.idgraphcontactinfoms.helpers

import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.CommonUtil
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ArrayNode
import spock.lang.Specification
import spock.lang.Unroll

class ProcessMobilityCPNIHelperTest extends Specification {

    def ProcessMobilityCPNIHelper objProcessMobilityCPNIHelper = new ProcessMobilityCPNIHelper()

	CPNIDataConsolidationHelper oCPNIConsolidationHelper = Mock(CPNIDataConsolidationHelper)

    HashMap hmResult = null
    HashMap hmInput = CommonUtil.hashMap
    String stTransactionId = null
    String stAppStatusMsg = null
    String stAppInfo = null
    HashMap hmIAPResponse = null
    HashMap hmAcctProfResponse = CommonUtil.hashMap
    HashMap hmAccountCreationDate = CommonUtil.hashMap
    HashMap hmAccountStatus = CommonUtil.hashMap
    HashMap hmCustomer = CommonUtil.hashMap
    HashMap hmCSISubscriber = CommonUtil.hashMap
    HashMap hmSub = CommonUtil.hashMap
    HashMap hmAccountType = new HashMap()
    HashMap hmEmail = CommonUtil.hashMap
    HashMap hmAddress = CommonUtil.hashMap
    ArrayList alCSISubscriber = CommonUtil.arrayList
    HashMap hmNameInfo = CommonUtil.hashMap
    HashMap hmBusinessNameInfo = CommonUtil.hashMap
    HashMap hmUnit = CommonUtil.hashMap
    HashMap hmStreet = CommonUtil.hashMap
    HashMap hmZipInfo = CommonUtil.hashMap
    HashMap hmSubscriberStatus = CommonUtil.hashMap
    HashMap hmSvcActivationDate = CommonUtil.hashMap
    HashMap hmDeviceInformation = CommonUtil.hashMap
    ArrayList alDevices = CommonUtil.arrayList
    HashMap hmDevice = CommonUtil.hashMap
    HashMap hmCPNIConResponse = CommonUtil.hashMap
    HashMap hmCTNList = CommonUtil.hashMap
    ArrayList alpostalAddress = CommonUtil.arrayList
    ArrayList alemailAddresses = CommonUtil.arrayList
    ArrayList alCTNList = CommonUtil.arrayList
    HashMap hmPostalAddr = CommonUtil.hashMap
    HashMap resultHashError = null
    TimeZone originalTimeZone = TimeZone.getDefault()

    def setup() {

        objProcessMobilityCPNIHelper.oCPNIConsolidationHelper = oCPNIConsolidationHelper
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIAccountContactInfo'
        hmInput[CommonDefs.TRANSACTION_ID] = 'trma_123'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'CSRIDP'
        hmInput['checkSMS'] = CommonDefs.IND_Y

        hmNameInfo['namePrefix'] = 'Mr'
        hmNameInfo['firstName'] = 'Sai'
        hmNameInfo['middleName'] = 'S'
        hmNameInfo['lastName'] = 'Raj'
        hmNameInfo['nameSuffix'] = 'S'
        hmBusinessNameInfo['businessName'] = 'Sai Enterprises'

        hmStreet['streetNumber'] = 'L-23'
        hmStreet['streetDirection'] = 'Sea Side'
        hmStreet['streetName'] = 'Marketyard Lane'
        hmStreet['streetType'] = 'XYZ'
        hmStreet['streetTrailingDirection'] = 'Left'

        hmZipInfo['zipCode'] = '456792'
        hmZipInfo['zipCodeExtension'] = '6'
        hmUnit['unitDesignator'] = 'B'
        hmUnit['unitNumber'] = '205'
        hmAddress['addressType'] = 'F'
        hmAddress['AddressLine1'] = 'Res-1'
        hmAddress['AddressLine2'] = 'Lane 2'
        hmAddress['PostOfficeBox'] = 'Lane 2'
        hmAddress[CommonDefs.KEY_CITY] = 'PUNE'
        hmAddress[CommonDefs.KEY_STATE] = 'Maharashtra'
        hmAddress['Unit'] = hmUnit
        hmAddress['Street'] = hmStreet
        hmAddress['Zip'] = hmZipInfo
        hmAddress[CommonDefs.KEY_COUNTRY] = 'INDIA'
        hmAddress['lastUpdate'] = '10232018 00:00:00'

        hmDevice['smsCapabilityIndicator'] = CommonDefs.DEFAULT_TRUE
        hmDevice[CommonDefs.IMEI] = 'XGJ234384729505'
        alDevices.add(hmDevice)
        hmEmail[CommonDefs.EMAIL_ADDRESS] = 'ax1794@att.com'
        hmEmail['effectiveDate'] = '2018-10-23'
        hmEmail[CommonDefs.EMAIL_STATUS] = 'V'
        hmEmail[CommonDefs.KEY_EMAIL_ESTABLISHED_DATE] = null
        hmEmail[CommonDefs.KEY_ACCOUNT_ESTABLISHED_DATE] = '10232018 00:00:00'
        hmCustomer['address'] = hmAddress
        hmCustomer[CommonDefs.EMAIL] = hmEmail
        hmCustomer['name'] = hmNameInfo
        hmCustomer['businessName'] = hmBusinessNameInfo
        hmSvcActivationDate['effectiveDate'] = '2018-10-23'
        hmDeviceInformation['device'] = alDevices

        hmSubscriberStatus[CommonDefs.SUBSCRIBER_STATUS] = 'A'
        hmAccountCreationDate['effectiveDate'] = '2018-10-23'
        hmAccountStatus[CommonDefs.STATUS] = 'A'
        hmSub[CommonDefs.SUBSCRIBER_NUMBER] = '12345'
        hmSub[CommonDefs.KEY_SUBSCRIPTION_ID] = '2'
        hmSub['SubscriberStatus'] = hmSubscriberStatus
        hmSub['ServiceActivationDate'] = hmSvcActivationDate
        hmSub['deviceInformation'] = hmDeviceInformation
        hmSub[CommonDefs.SIM_SWAP_DATE] = '2018-10-23'
        hmCSISubscriber['subscribers'] = hmSub
        hmAccountType['accountType'] = 'R'
        alCSISubscriber.add(hmCSISubscriber)

        hmAcctProfResponse[CommonDefs.KEY_ACCOUNT_STATUS] = hmAccountStatus
        hmAcctProfResponse['AccountCreationDate'] = hmAccountCreationDate
        hmAcctProfResponse['Customer'] = hmCustomer
        hmAcctProfResponse['subscribers'] = alCSISubscriber
        hmAcctProfResponse['primaryAccountHolder'] = 'Sai'
        hmAcctProfResponse['createdOn'] = '2023-05-11'
        hmAcctProfResponse['contact'] = hmCustomer
        hmAcctProfResponse[CommonDefs.KEY_ACCOUNT_TYPE] = hmAccountType

        hmPostalAddr[CommonDefs.KEY_ZIPCODE] = '456792'
        hmPostalAddr[CommonDefs.KEY_STATE] = 'Maharashtra'
        hmPostalAddr['ZipPlusFour'] = '6'
        hmPostalAddr[CommonDefs.KEY_ADDRESS2] = 'Res-1'
        hmPostalAddr[CommonDefs.KEY_ADDRESS3] = 'Lane 2'
        hmPostalAddr[CommonDefs.KEY_COUNTRY] = 'INDIA'
        hmPostalAddr[CommonDefs.KEY_CITY] = 'PUNE'
        hmPostalAddr[CommonDefs.KEY_ACCOUNT_ESTABLISHED_DATE] = '10232018 00:00:00'
        hmPostalAddr[CommonDefs.KEY_BILLNAME] = 'Mr Sai S Raj S'
        hmPostalAddr[CommonDefs.KEY_ADDRESS_ESTABLISHED_DATE] = null
        hmPostalAddr[CommonDefs.KEY_FOREIGN_ADDR_IND] = CommonDefs.IND_Y

        hmCTNList[CommonDefs.IMEI] = 'XGJ234384729505'
        hmCTNList[CommonDefs.KEY_SUBSCRIPTION_ID] = '2'
        hmCTNList[CommonDefs.CTN] = '12345'
        hmCTNList[CommonDefs.ACTIVATION_DATE] = '2018-10-23'
        hmCTNList[CommonDefs.SIM_SWAP_DATE] = '10232018 00:00:00'
        hmCTNList[CommonDefs.STATUS] = 'A'
        alpostalAddress.add(hmPostalAddr)
        alemailAddresses.add(hmEmail)
        alCTNList.add(hmCTNList)

        hmIAPResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG)
        hmIAPResponse['accounts'] = hmAcctProfResponse
        hmCPNIConResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG)
        hmCPNIConResponse[CommonDefs.ACCOUNT_CONTACT_LIST] = alCTNList
        resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, CErrorDefs.ERR_INVALID_DATA)
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"))
    }


    def "test process mobility c p n i helper empty input"() {
        when:
        hmResult = objProcessMobilityCPNIHelper.processMobilityCPNI(null, hmResult)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Input Hash is null or empty'
    }


    def "test process mobility c p n i helper emptyhm i a p response"() {
        when:
        hmResult = objProcessMobilityCPNIHelper.processMobilityCPNI(hmInput, null)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Null IAPResponse'
    }


    def "test process mobility c p n i helper hm i a p response error"() {
        given:
        hmIAPResponse[CommonDefs.COMMON_APP_INFO] = CErrorDefs.ERR_INVALID_DATA
        hmIAPResponse[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.CATEGORY_CODE_SYSTEM_ERROR
        hmIAPResponse[CommonDefs.COMMON_APP_CATEGORY_CODE] = CErrorDefs.CATEGORY_CODE_SYSTEM_ERROR
        when:
        hmResult = objProcessMobilityCPNIHelper.processMobilityCPNI(hmInput, hmIAPResponse)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == CErrorDefs.ERR_INVALID_DATA
    }


    def "test process mobility c p n i helper hm i a p response account not found"() {
        given:
        hmIAPResponse[CommonDefs.COMMON_APP_INFO] = CErrorDefs.ERR_INVALID_DATA
        hmIAPResponse[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.CATEGORY_CODE_SYSTEM_ERROR
        when:
        hmResult = objProcessMobilityCPNIHelper.processMobilityCPNI(hmInput, hmIAPResponse)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == CErrorDefs.ERR_ACCOUNT_NOT_FOUND_MSG
    }


    def "test generate c p n i consolidation empty response"() {
        given:
        hmInput['checkSMS'] = CommonDefs.IND_N
        hmCustomer.remove('name')
        hmAddress['addressType'] = 'P'
        oCPNIConsolidationHelper.generateCPNIConsolidation(_)>>null
        when:
        hmResult = objProcessMobilityCPNIHelper.processMobilityCPNI(hmInput, hmIAPResponse)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'null Hash returned from CPNIConsolidationHelper.generateCPNIConsolidation() '
    }


    def "test generate c p n i consolidation success"() {
        given:
        hmAcctProfResponse['primaryAccountHolder'] = '12345'
        hmEmail.remove('effectiveDate')
        oCPNIConsolidationHelper.generateCPNIConsolidation(_)>>hmCPNIConResponse
        when:
        hmResult = objProcessMobilityCPNIHelper.processMobilityCPNI(hmInput, hmIAPResponse)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == CErrorDefs.COMMON_SUCCESS_MSG
    }


    def "test generate c p n i consolidation returns error"() {
        given:
        hmAddress['address'] = 'S'
        hmEmail.remove('effectiveDate')
        hmPostalAddr[CommonDefs.KEY_ADDRESS2] = 'L-23 Sea Side Marketyard Lane XYZ Left  B 205'
		hmPostalAddr[CommonDefs.KEY_FOREIGN_ADDR_IND] = CommonDefs.IND_N
		oCPNIConsolidationHelper.generateCPNIConsolidation(_)>>resultHashError
        when:
        hmResult = objProcessMobilityCPNIHelper.processMobilityCPNI(hmInput, hmIAPResponse)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == CErrorDefs.ERR_INVALID_DATA
    }
	
//	@Test
	void test_CSISubscriber_ReturnsError() {
		hmIAPResponse['subscribers'] = hmSub
		hmAddress['address'] = 'S'
		oCPNIConsolidationHelper.generateCPNIConsolidation(_)>>resultHashError
		hmResult = objProcessMobilityCPNIHelper.processMobilityCPNI(hmInput, hmIAPResponse)
		assertEquals(CErrorDefs.ERR_INVALID_DATA, hmResult[CommonDefs.COMMON_APP_INFO])
	}

    def "formatDate should handle exception"() {
        given:
        String sDateKey = "simSwapDate"
        String sDateValue = "2025-02-13 00:00:00"
        when:
        String result = objProcessMobilityCPNIHelper.formatDate(sDateKey, sDateValue)

        then:
        result == "02132025 00:00:00"

    }

    @Unroll
    def "test ctn list filtering based on duoIdentifier [#scenario]"() {
        given:
        HashMap hmSubscriberEntry = new HashMap()
        hmSubscriberEntry['subscriberId'] = '12345'
        hmSubscriberEntry['status'] = 'A'
        hmSubscriberEntry['subscriptionId'] = '2'
        hmSubscriberEntry['effectiveDate'] = '2018-10-23'
        if (duoIdentifier != null) hmSubscriberEntry['duoIdentifier'] = duoIdentifier
        ArrayList alSubscribers = new ArrayList()
        alSubscribers.add(hmSubscriberEntry)
        ArrayNode subscribersNode = new ObjectMapper().valueToTree(alSubscribers)
        hmIAPResponse['subscribers'] = subscribersNode
        hmInput['checkSMS'] = CommonDefs.IND_N

        when:
        hmResult = objProcessMobilityCPNIHelper.processMobilityCPNI(hmInput, hmIAPResponse)

        then:
        1 * oCPNIConsolidationHelper.generateCPNIConsolidation({ HashMap consolidationInput ->
            String consolidationInputAsString = String.valueOf(consolidationInput)
            expectedSubscriberPresent ? consolidationInputAsString.contains('12345') : !consolidationInputAsString.contains('12345')
        }) >> hmCPNIConResponse
        0 * _

        and:
        hmResult[CommonDefs.COMMON_APP_INFO] == CErrorDefs.COMMON_SUCCESS_MSG

        where:
        scenario                            | duoIdentifier | expectedSubscriberPresent
        'duoIdentifier is null'             | null          | true
        'duoIdentifier is companion'        | 'Companion'   | false
        'duoIdentifier is non-companion'    | 'anchor'      | true
    }

    def cleanup() {
        TimeZone.setDefault(originalTimeZone)
    }
}
