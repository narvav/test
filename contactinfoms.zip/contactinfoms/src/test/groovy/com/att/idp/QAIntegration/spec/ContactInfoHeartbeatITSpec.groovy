package com.att.idp.QAIntegration.spec

import com.att.idp.QAIntegration.Base.TestBase
import com.att.idp.QAIntegration.Config.ContactInfoGlobalConfig
import groovy.util.logging.Slf4j
import io.restassured.response.Response
import spock.lang.IgnoreIf
import spock.lang.Tag

/**
 * QG7 Smoke Test — IDGraphContactInfoMs Heartbeat
 *
 * Verifies the deployed service is alive and reports status=UP.
 * Uses TestBase.sendRequest (IDGraphE2E pattern) — no extends BaseSpec.
 *
 * OMNI Compliance:
 * - Spec suffix: *ITSpec.groovy (testing-foundation.md E1)
 * - then: 0 * _ mandatory (HS-8)
 * - No mocks — real HTTP call to deployed service
 */
@Slf4j
@Tag("Smoke")
@Tag("IDGraphContactInfoMs")
@IgnoreIf({ !ContactInfoGlobalConfig.isTestCaseEnabled("ContactInfoHeartbeatITSpec") })
class ContactInfoHeartbeatITSpec extends TestBase {

    def "Heartbeat returns 200 and status UP"() {
        setup:
        TestBase.setTestName("Heartbeat — Service UP Check")
        TestBase.logStep("GET ${ContactInfoGlobalConfig.Endpoints.HEARTBEAT} on env=${ContactInfoGlobalConfig.getCurrentTestEnv()}")

        when: "GET heartbeat is called against the deployed service"
        Response response = TestBase.sendRequest(ContactInfoGlobalConfig.Endpoints.HEARTBEAT, "GET", null)

        then: "No mock interactions — real HTTP call"
        0 * _

        and: "Service is alive and reports UP"
        assert response.statusCode() == 200 :
                "Expected HTTP 200 but got: ${response.statusCode()}. Body: ${response.body().asString().take(300)}"
        assert response.body().jsonPath().getString("status") == "UP" :
                "Expected status=UP but got: ${response.body().jsonPath().getString("status")}"
    }
}
