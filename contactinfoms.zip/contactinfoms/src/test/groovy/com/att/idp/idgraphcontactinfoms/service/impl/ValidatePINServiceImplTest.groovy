package com.att.idp.idgraphcontactinfoms.service.impl

import com.att.idp.idgraphcontactinfoms.exceptions.InvalidInputDataException
import com.att.idp.idgraphcontactinfoms.helpers.ValidatePINHelper
import com.att.idp.idgraphcontactinfoms.resource.request.ValidatePINRequest
import com.att.idp.idgraphcontactinfoms.resource.response.ValidatePINResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import jakarta.ws.rs.core.MultivaluedMap
import spock.lang.Specification
import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap
import static org.junit.jupiter.api.Assertions.assertThrows

class ValidatePINServiceImplTest extends Specification {

    def ValidatePINServiceImpl validatePINServiceImplObj = new ValidatePINServiceImpl()
    ValidatePINHelper validatePINHelperObj = Mock(ValidatePINHelper)
    ValidatePINRequest validatePinRequest
    MultivaluedMap<String, String> requestHeader
    Map<String, String> headers = new HashMap<>()

    def setup() {
        validatePINServiceImplObj.validatePINHelper = validatePINHelperObj
        validatePinRequest = new ValidatePINRequest(
                callingSystemId: 'IDP',
                accountId: '64573738',
                securityCode: '099743',
                identificationType: 'CTNDIH',
                deletePINOnSuccess: 'ALL',
                agentId: 'ad4637',
                idpTraceId: '99dfs999:8dfs8888:77777:66666ccc'
        )
        requestHeader = new MultivaluedHashMap<>(headers)
    }

    def "test validate pin null case"() {
        when:
        ValidatePINResponse response = validatePINServiceImplObj.validatePIN(validatePinRequest, requestHeader)
        then:
        response.appInfo == 'Null response from validatePINHelper.validatePIN'

        when:
        def hmResponse = [(MPSDefs.APP_STATUS_CODE): null]
        validatePINHelperObj.validatePIN(_) >> hmResponse
        response = validatePINServiceImplObj.validatePIN(validatePinRequest, requestHeader)
        then:
        response.appInfo == 'Null response from validatePINHelper.validatePIN'
    }

    def "test validate pin success case"() {
        given:
        def hmResponse = [
                (CommonDefs.TRANSACTION_ID): 'trma_16374856',
                (MPSDefs.APP_STATUS_CODE): '0',
                'appInfo': 'Success'
        ]
        validatePINHelperObj.validatePIN(_) >> hmResponse
        when:
        ValidatePINResponse response = validatePINServiceImplObj.validatePIN(validatePinRequest, requestHeader)
        then:
        response != null
        response.idpTraceId != null
        response.transactionName == 'ValidatePIN'
    }

    def "test validate pin when trans rollback set"() {
        given:
        def hmResponse = [
                (CommonDefs.TRANSACTION_ID): 'trma_16374856',
                (MPSDefs.APP_STATUS_CODE): '0',
                'isTransactionRollback': 'true'
        ]
        validatePINHelperObj.validatePIN(_) >> hmResponse
        expect:
        InvalidInputDataException excep = assertThrows(InvalidInputDataException.class) {
            validatePINServiceImplObj.validatePIN(validatePinRequest, requestHeader)
        }
    }
}