package com.att.idp.QAIntegration.Utils

import com.att.idp.secrets.utils.SecretsCacheReader
import groovy.json.JsonSlurper
import groovy.util.logging.Slf4j
import io.restassured.RestAssured
import io.restassured.response.Response

import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

@Slf4j
class Utility {
	static String clusterName = ApplicationConstants.clusterName
	private static String secretValue = null
	static final Object configFileLock = new Object()
	private static Map configFileCache = null
	private static Set<String> loggedTestCases = Collections.synchronizedSet(new HashSet<String>())

	static String getBasicAuthHeader(String username, String password) {
		String credentials = "${username}:${password}"
		String encoded = Base64.encoder.encodeToString(credentials.bytes)
		return "Basic ${encoded}"
	}

	static String getCurrentDateTime() { // Added return type
		def now = ZonedDateTime.now(ZoneId.of("America/Chicago"))
		def formatter = DateTimeFormatter.ofPattern("MM_dd_yyyy_HH_mm_ss")
		return now.format(formatter)
	}


	static synchronized String getAuthorizationFromSecretCache() {
		if (secretValue != null) {
			return secretValue
		}
		SecretsCacheReader secret = new SecretsCacheReader()
		if (ApplicationConstants.env?.contains("prodgraph1eus2")) {
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.PROD_GRAPH_EAST_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
		} else if(ApplicationConstants.env?.contains("prodgraph1wus2")) {
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.PROD_GRAPH_WEST_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
		} else if (ApplicationConstants.env?.contains("prodgraph1scus")) {
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.PROD_GRAPH_SC_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
		} else if (ApplicationConstants.env?.contains("prodgraph1cnryeus2")) {
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.PROD_GRAPH_CANARY_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
		} else if (ApplicationConstants.env?.contains("sales1eus2-prod") || ApplicationConstants.env?.contains("prodsales1eus2")) {
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.PROD_SALES_EAST_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
		} else if (ApplicationConstants.env?.contains("sales1wus2-prod") || ApplicationConstants.env?.contains("prodsales1wus2")) {
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.PROD_SALES_WEST_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
		} else if (ApplicationConstants.env?.contains("prodsales1scus")) {
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.PROD_SALES_SC_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
		} else if (ApplicationConstants.env?.contains("prodsales1cnryeus2")) {
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.PROD_SALES_CANARY_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
		} else if (ApplicationConstants.env?.contains("graph1eus2-stage") || ApplicationConstants.env?.contains("stagegraph1eus2") || ApplicationConstants.env?.contains("sales1eus2-stage") || ApplicationConstants.env?.contains("stagesales1eus2")) {
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.STAGE_EAST_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
		} else if (ApplicationConstants.env?.contains("graph1wus2-stage") || ApplicationConstants.env?.contains("stagegraph1wus2") || ApplicationConstants.env?.contains("sales1wus2-stage") || ApplicationConstants.env?.contains("stagesales1wus2")) {
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.STAGE_WEST_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
		} else if (ApplicationConstants.env?.contains("graph1eus2-perf2")) {
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.PERF_GRAPH_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			if (!secretValue?.trim()) {
				secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.PERF_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			}
		} else if (ApplicationConstants.env?.contains("sales1eus2-perf2")) {
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.PERF_SALES_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			if (!secretValue?.trim()) {
				secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.PERF_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			}
		} else if (ApplicationConstants.env?.contains("graph1eus2-dev")) {
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.DEV_GRAPH_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			if (!secretValue?.trim()) {
				secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.DEV_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			}
		} else if (ApplicationConstants.env?.contains("sales1eus2-dev")) {
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.DEV_SALES_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			if (!secretValue?.trim()) {
				secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.DEV_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			}
		} else if (ApplicationConstants.env?.contains("graph1eus2-test")) {
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.TEST_GRAPH_EAST_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			if (!secretValue?.trim()) {
				secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.TEST_2_5_6_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			}
			if (!secretValue?.trim()) {
				secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.TEST_3_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			}
		} else if (ApplicationConstants.env?.contains("graph1wus2-test")) {
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.TEST_GRAPH_WEST_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			if (!secretValue?.trim()) {
				secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.TEST_2_5_6_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			}
			if (!secretValue?.trim()) {
				secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.TEST_3_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			}
		} else if (ApplicationConstants.env?.contains("sales1eus2-test")) {
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.TEST_SALES_EAST_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			if (!secretValue?.trim()) {
				secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.TEST_2_5_6_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			}
			if (!secretValue?.trim()) {
				secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.TEST_3_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			}
		} else if (ApplicationConstants.env?.contains("sales1wus2-test")) {
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.TEST_SALES_WEST_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			if (!secretValue?.trim()) {
				secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.TEST_2_5_6_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			}
			if (!secretValue?.trim()) {
				secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.TEST_3_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
			}
		} else {
			// Fallback test vault if no pattern matches
			secretValue = secret.readSecretFile(ApplicationConstants.AzureKeyVault.TEST_3_KEY_VAULT_NAME, ApplicationConstants.AzureKeyVault.QG7_AUTH_SECRET_NAME)
		}
		return secretValue
	}

	static Map getValueFromConfigFile(String env) {
		synchronized(configFileLock) {
			if (configFileCache != null) {
				return configFileCache
			}
			def configFile = new File(ApplicationConstants.CONFIG_FILE_PATH)
			if (!configFile.exists()) {
				log.error("Config file not found at path: {}", ApplicationConstants.CONFIG_FILE_PATH)
				throw new IllegalArgumentException("Config file not found at path: " + ApplicationConstants.CONFIG_FILE_PATH)
			}
			def config
			try {
				config = new JsonSlurper().parse(configFile)
			} catch (Exception e) {
				log.error("Failed to parse config file at path: {}. Error: {}", ApplicationConstants.CONFIG_FILE_PATH, e.message)
				throw new IllegalArgumentException("Failed to parse config file at path: " + ApplicationConstants.CONFIG_FILE_PATH + ". Error: " + e.message)
			}
			def envConfig = config[env]
			if (!envConfig) {
				log.error("Environment '{}' not found in config file. Available keys: {}", env, config.keySet())
				throw new IllegalArgumentException("Environment '" + env + "' not found in config file. Available keys: " + config.keySet())
			}
			def secretsMap = AzureKeyVaultUtil.getSecretValue()
			def authKey = (ApplicationConstants.env?.toLowerCase()?.contains('stage') || ApplicationConstants.env?.toLowerCase()?.contains('prod') ||
					   env?.toLowerCase()?.contains('stage') || env?.toLowerCase()?.contains('prod')) ? 'stage' : 'test'
			def authorization = secretsMap.get(
				authKey == 'stage' ? ApplicationConstants.AzureKeyVault.STAGE_AUTH_SECRET_NAME
								   : ApplicationConstants.AzureKeyVault.TEST_AUTH_SECRET_NAME
			)
			log.info("Authorization retrieved from Key Vault and cached in memory.")
			def baseUrl = envConfig['baseUrl']
			def expectedJsonPath = envConfig['expectedJsonPath']
			def nonProdAuthorization = secretsMap.get(ApplicationConstants.AzureKeyVault.TEST_AUTH_SECRET_NAME)
			def prodAuthorization = secretsMap.get(ApplicationConstants.AzureKeyVault.STAGE_AUTH_SECRET_NAME)
			configFileCache = [authorization: authorization, baseUrl: baseUrl, expectedJsonPath: expectedJsonPath, nonProdAuthorization: nonProdAuthorization, prodAuthorization: prodAuthorization]
			return configFileCache
		}
	}


}
