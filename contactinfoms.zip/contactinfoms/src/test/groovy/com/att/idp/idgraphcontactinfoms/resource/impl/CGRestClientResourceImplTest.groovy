package com.att.idp.idgraphcontactinfoms.resource.impl

import com.att.idp.idgraphcontactinfoms.service.CGRestClientService
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonErrorMap
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.Response

class CGRestClientResourceImplTest extends Specification {
	
	def cGRestClientResourceImplObj = new CGRestClientResourceImpl()

	def cgRestClientService = Mock(CGRestClientService)

	def httpHeaders = Stub(HttpHeaders)

	def setup() throws Exception {
		cGRestClientResourceImplObj.cgRestClientService = cgRestClientService
	}

	def "test cg rest client success"() throws Exception {
		given:
		HashMap hmSuccessResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
		cgRestClientService.cgRestClient(_ as HashMap) >> hmSuccessResponse
		when:
		Response response = cGRestClientResourceImplObj.cgRestClient(httpHeaders)
		then:
		response.status == 200
	}

    def "should process cgRestClient for #scenarioName"() {
        given: "HttpHeaders and expected service response"
        httpHeaders.getHeaderString("accountId") >> accountId
        httpHeaders.getHeaderString("subscriberNumber") >> subscriberNumber
        httpHeaders.getHeaderString("serviceType") >> serviceType
        httpHeaders.getHeaderString("topics") >> topics
        httpHeaders.getHeaderString("idp-trace-id") >> idpTraceId

        HashMap<String, Object> expectedRequest = new HashMap<>()
        if (accountId != null && !accountId.isEmpty()) {
            expectedRequest.put("accountId", accountId)
        } else if (subscriberNumber != null && !subscriberNumber.isEmpty()) {
            expectedRequest.put("subscriberNumber", subscriberNumber)
        }
        expectedRequest.put("serviceType", serviceType)
        expectedRequest.put("topics", topics)

        HashMap<String, Object> serviceResponse = CommonErrorMap.makeCategoryMap(responseCode, responseMsg)
        serviceResponse.put("idp-trace-id", idpTraceId)

        1 * cgRestClientService.cgRestClient({ HashMap<String, Object> param ->
            param.get("accountId") == expectedRequest.get("accountId") &&
                    param.get("subscriberNumber") == expectedRequest.get("subscriberNumber") &&
                    param.get("serviceType") == serviceType &&
                    param.get("topics") == topics
        }) >> serviceResponse
        0 * _

        when: "cgRestClient is called"
        Response response = cGRestClientResourceImplObj.cgRestClient(httpHeaders)

        then: "Response contains expected status and entity"
        response != null
        response.status == expectedStatus
        Object entityObj = response.getEntity()
        entityObj != null
        entityObj.appStatusCode == String.valueOf(responseCode)
        entityObj.appInfo == responseMsg
        entityObj.idpTraceId == idpTraceId

        where: "Different header and response scenarios"
        scenarioName         | accountId   | subscriberNumber | serviceType | topics      | idpTraceId   | responseCode | responseMsg | expectedStatus
        "AccountId present"  | "A123"      | ""               | "WIRELESS"  | "topic1"    | "trace-001"  | 0            | "SUCCESS"   | 200
        "Subscriber present" | ""          | "S456"           | "WIRELINE"  | "topic2"    | "trace-002"  | 0            | "SUCCESS"   | 200
        "Error response"     | "A789"      | ""               | "ENABLER"   | "topic3"    | "trace-003"  | 100          | "ERROR"     | 400

    }

}
