package com.att.idp.idgraphcontactinfoms.db.repository.impl

import com.att.idp.idgraphcontactinfoms.db.helper.SecurityCodeDBHelper
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs
import org.hibernate.Session
import org.hibernate.query.NativeQuery
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Specification

import jakarta.persistence.EntityManager
import java.time.LocalDate

class SecurityAccountDataRepositoryImplTest extends Specification {

    def testObj = new SecurityAccountDataRepositoryImpl()

    def query = Mock(NativeQuery)

    def sessionMock = Mock(Session)

    def entityManager = Mock(EntityManager)

    private HashMap<String, Object> inpParamHash = null

    private boolean isSaveSecurityCode
    private Long cumulativeFailureCount
    private LocalDate localDate
    private java.sql.Date now

    public static final Logger logger = LoggerFactory.getLogger(SecurityCodeDBHelper.class)


    def setup() {
        testObj.entityManager = entityManager
        entityManager.unwrap(_) >> sessionMock
        sessionMock.unwrap(_) >> query
		inpParamHash = CommonUtil.hashMap
        isSaveSecurityCode = true
        cumulativeFailureCount = 0L

        inpParamHash[MPSDefs.DB_ACCOUNT_ID] = '1111111111'
        inpParamHash[MPSDefs.DB_SOR_INVARIANT_ID] = '123456'
        inpParamHash[MPSDefs.DB_ACCOUNT_TYPE] = 'R'
        inpParamHash[MPSDefs.DB_ACCOUNT_REGION] = 'abc'
        inpParamHash[MPSDefs.DB_IDENTIFICATION_TYPE] = 'IDSEMOB'
        inpParamHash[MPSDefs.DB_LAST_MODIFIED_BY] = 'DATAMGT'
        inpParamHash['security_code_expiration_time'] = '24'
    }


    def "set security account data success test"() throws Exception {
        given:
        localDate = LocalDate.now()
        now = java.sql.Date.valueOf(localDate)

        entityManager.unwrap(_) >> sessionMock
        sessionMock.createNativeQuery(_) >> query
        query.addSynchronizedQuerySpace('') >> query

//        query.setParameter('identificationType', inpParamHash[MPSDefs.DB_IDENTIFICATION_TYPE]) >> query
//        query.setParameter('accountId', inpParamHash[MPSDefs.DB_ACCOUNT_ID]) >> query
//        query.setParameter('accountType', inpParamHash[MPSDefs.DB_ACCOUNT_TYPE]) >> query
//        query.setParameter('accountRegion', inpParamHash[MPSDefs.DB_ACCOUNT_REGION]) >> query
//        query.setParameter('cumulativeFailureCount', 0) >> query
//        query.setParameter('accountEntryExpires', (double) 1) >> query
//        query.setParameter('createDate', _) >> query
//        query.setParameter('lastModified', _) >> query
//        query.setParameter('lastModifiedBy', inpParamHash[MPSDefs.DB_LAST_MODIFIED_BY]) >> query
//        query.setParameter('sorInvariantId', inpParamHash[MPSDefs.DB_SOR_INVARIANT_ID]) >> query
        query.setParameter(_,_) >> query

        query.executeUpdate() >> new Integer(10)

        when:
        int rowcount = testObj.setSecurityAccountData(inpParamHash)
        then:
        rowcount == 10
    }


    //@Ignore
    def "set security account data exception test1"() throws Exception {
        given:
        NullPointerException ex = new NullPointerException('ORA-00001: unique constraint')

        entityManager.unwrap(_) >> sessionMock
        sessionMock.createNativeQuery(_) >> { throw ex }

        when:
        int rowcount = testObj.setSecurityAccountData(inpParamHash)
        then:
        thrown NullPointerException
    }


    //@Ignore
    def "set security account data exception test2"() throws Exception {
        given:
        NullPointerException ex = new NullPointerException('NullPointerException')

        entityManager.unwrap(_) >> sessionMock
        sessionMock.createNativeQuery(_) >> { throw ex }

        when:
        int rowcount = testObj.setSecurityAccountData(inpParamHash)
        then:
        thrown NullPointerException
    }


    def "update security account success test1"() throws Exception {
        given:
        inpParamHash[MPSDefs.DB_SOR_INVARIANT_ID] = null
        localDate = LocalDate.now()
        now = java.sql.Date.valueOf(localDate)

        entityManager.unwrap(_) >> sessionMock
        sessionMock.createNativeQuery(_) >> query
        query.addSynchronizedQuerySpace('') >> query

//        query.setParameter('accountEntryExpires', (double) 1) >> query
//        query.setParameter('last_modified_by', inpParamHash[MPSDefs.DB_LAST_MODIFIED_BY]) >> query
//        query.setParameter('identification_type', inpParamHash[MPSDefs.DB_IDENTIFICATION_TYPE]) >> query
//        query.setParameter('account_id', inpParamHash[MPSDefs.DB_ACCOUNT_ID]) >> query

        query.setParameter(_,_) >> query

        query.executeUpdate() >> new Integer(10)

        when:
        int rowcount = testObj.updateSecurityAccount(inpParamHash, isSaveSecurityCode, cumulativeFailureCount)
        then:
        rowcount == 10
    }


    def "update security account success test2"() throws Exception {
        given:
        localDate = LocalDate.now()
        now = java.sql.Date.valueOf(localDate)

        entityManager.unwrap(_) >> sessionMock
        sessionMock.createNativeQuery(_) >> query
        query.addSynchronizedQuerySpace('') >> query

//        query.setParameter('accountEntryExpires', (double) 1) >> query
//        query.setParameter('last_modified_by', inpParamHash[MPSDefs.DB_LAST_MODIFIED_BY]) >> query
//        query.setParameter('sor_invariant_id', inpParamHash[MPSDefs.DB_SOR_INVARIANT_ID]) >> query
//        query.setParameter('identification_type', inpParamHash[MPSDefs.DB_IDENTIFICATION_TYPE]) >> query
//        query.setParameter('account_id', inpParamHash[MPSDefs.DB_ACCOUNT_ID]) >> query

        query.setParameter(_,_) >> query

        query.executeUpdate() >> new Integer(10)

        when:
        int rowcount = testObj.updateSecurityAccount(inpParamHash, isSaveSecurityCode, cumulativeFailureCount)
        then:
        rowcount == 10
    }


    def "update security account success test3"() throws Exception {
        given:
        isSaveSecurityCode = false
        localDate = LocalDate.now()
        now = java.sql.Date.valueOf(localDate)

        entityManager.unwrap(_) >> sessionMock
        sessionMock.createNativeQuery(_) >> query
        query.addSynchronizedQuerySpace('') >> query

//        query.setParameter('cumulativeFailureCount', cumulativeFailureCount + 1L) >> query
//        query.setParameter('last_modified_by', inpParamHash[MPSDefs.DB_LAST_MODIFIED_BY]) >> query
//		query.setParameter('identification_type', inpParamHash[MPSDefs.DB_IDENTIFICATION_TYPE]) >> query
//		query.setParameter('account_id', inpParamHash[MPSDefs.DB_ACCOUNT_ID]) >> query

        query.setParameter(_,_) >> query

		query.executeUpdate() >> new Integer(10)

        when:
        int rowcount = testObj.updateSecurityAccount(inpParamHash, isSaveSecurityCode, cumulativeFailureCount)
        then:
        rowcount == 10
    }


    //@Ignore
    def "update security account exception test1"() throws Exception {
        given:
        NullPointerException ex = new NullPointerException()

        entityManager.unwrap(_) >> sessionMock
		sessionMock.createNativeQuery(_) >> { throw ex }

        when:
        int rowcount = testObj.updateSecurityAccount(inpParamHash, isSaveSecurityCode, cumulativeFailureCount)
        then:
        thrown NullPointerException
    }

}
