package com.att.idp.idgraphcontactinfoms.integration

import com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig
import org.apache.hc.client5.http.impl.routing.DefaultProxyRoutePlanner
import org.springframework.http.client.BufferingClientHttpRequestFactory
import org.springframework.web.client.RestTemplate
import spock.lang.Specification

class OutboundRestClientBuilderTest extends Specification {

    def appConfig = Stub(IDGraphAzureAppConfig) {
        getHttpPoolMaxTotal() >> 200
        getHttpPoolDefaultMaxPerRoute() >> 50
        getHttpPoolConnectionRequestTimeout() >> 5000
    }

    def outboundRestClientBuilder = new OutboundRestClientBuilder(appConfig)

    def "test buildRestTemplate without proxy"() {
        given:
        def restTemplate = Mock(RestTemplate)

        when:
        def result = outboundRestClientBuilder.buildRestTemplate(restTemplate, 5000, 10000, false, null)

        then:
        result == restTemplate
        1 * restTemplate.setRequestFactory({ it instanceof BufferingClientHttpRequestFactory })
        0 * _
    }

    def "test buildRestTemplate with proxy"() {
        given:
        def restTemplate = Mock(RestTemplate)
        def routePlanner = Mock(DefaultProxyRoutePlanner)

        when:
        def result = outboundRestClientBuilder.buildRestTemplate(restTemplate, 5000, 10000, true, routePlanner)

        then:
        result == restTemplate
        1 * restTemplate.setRequestFactory({ it instanceof BufferingClientHttpRequestFactory })
        0 * _
    }

    def "test buildRestTemplate closes previous client on config refresh"() {
        given:
        def restTemplate = Mock(RestTemplate)

        when:
        outboundRestClientBuilder.buildRestTemplate(restTemplate, 5000, 10000, false, null)
        def result = outboundRestClientBuilder.buildRestTemplate(restTemplate, 3000, 8000, false, null)

        then:
        result == restTemplate
        2 * restTemplate.setRequestFactory({ it instanceof BufferingClientHttpRequestFactory })
        0 * _
    }
}