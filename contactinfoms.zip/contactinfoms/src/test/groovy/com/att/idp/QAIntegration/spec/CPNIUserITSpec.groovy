package com.att.idp.QAIntegration.spec

import com.att.idp.QAIntegration.Base.TestBase
import com.att.idp.QAIntegration.Config.ContactInfoGlobalConfig
import com.att.idp.QAIntegration.Helpers.ContactInfoMsApiHelpers
import groovy.util.logging.Slf4j
import io.restassured.response.Response
import spock.lang.IgnoreIf
import spock.lang.Shared
import spock.lang.Tag
import spock.lang.Unroll

/**
 * QG7 Integration Test — CPNI Contact Info User API
 *
 * Tests for POST /cpniContactInfo/user endpoint with YAML-driven test data.
 * Tests with userId and guid lookups.
 *
 * OMNI Compliance:
 * - Spec suffix: *ITSpec.groovy (testing-foundation.md E1)
 * - then: 0 * _ mandatory (HS-8)
 * - No mocks — real HTTP calls to deployed service
 */
@Slf4j
@Tag("Regression")
@Tag("CPNI")
@Tag("IDGraphContactInfoMs")
@IgnoreIf({ !ContactInfoGlobalConfig.isTestCaseEnabled("CPNIUserITSpec") })
class CPNIUserITSpec extends TestBase {

    @Shared
    Map testData = ContactInfoGlobalConfig.getTestData()

    @Shared
    List<Map> cpniUserWithUserId = (testData?.get("cpniUserWithUserId") as List<Map>) ?: []

    @Shared
    List<Map> cpniUserWithGuid = (testData?.get("cpniUserWithGuid") as List<Map>) ?: []

    @Shared
    List<Map> cpniUserNegative = (testData?.get("cpniUserNegative") as List<Map>) ?: []

    // ═══════════════════════════════════════════════════════════════════════════
    // CPNI User — Tests with UserId (from YAML)
    // ═══════════════════════════════════════════════════════════════════════════

    @Unroll("CPNI User — #tc.testCaseName")
    def "CPNI User Contact Info — With UserId"() {
        setup:
        setTestName(tc.testCaseName as String)
        logStep("POST ${ContactInfoGlobalConfig.Endpoints.CPNI_CONTACT_INFO_USER}")

        when: "POST CPNI User Contact Info is called"
        Response response = ContactInfoMsApiHelpers.cpniContactInfoUser(tc as Map)

        then: "No mock interactions"
        0 * _

        and: "Response status matches expected"
        int expectedStatus = (tc.expectedStatus ?: 200) as int
        assert response.statusCode() == expectedStatus :
                "Expected ${expectedStatus} but got ${response.statusCode()}"

        where:
        tc << cpniUserWithUserId
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CPNI User — Tests with GUID (from YAML)
    // ═══════════════════════════════════════════════════════════════════════════

    @Unroll("CPNI User — #tc.testCaseName")
    def "CPNI User Contact Info — With GUID"() {
        setup:
        setTestName(tc.testCaseName as String)
        logStep("POST ${ContactInfoGlobalConfig.Endpoints.CPNI_CONTACT_INFO_USER}")

        when: "POST CPNI User Contact Info is called"
        Response response = ContactInfoMsApiHelpers.cpniContactInfoUser(tc as Map)

        then: "No mock interactions"
        0 * _

        and: "Response status matches expected"
        int expectedStatus = (tc.expectedStatus ?: 200) as int
        assert response.statusCode() == expectedStatus :
                "Expected ${expectedStatus} but got ${response.statusCode()}"

        where:
        tc << cpniUserWithGuid
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CPNI User — Negative Tests (from YAML)
    // ═══════════════════════════════════════════════════════════════════════════

    @Unroll("CPNI User Negative — #tc.testCaseName")
    def "CPNI User Contact Info — Negative Tests"() {
        setup:
        setTestName(tc.testCaseName as String)
        logStep("POST ${ContactInfoGlobalConfig.Endpoints.CPNI_CONTACT_INFO_USER} (expecting 400)")

        when: "POST CPNI User Contact Info is called with invalid data"
        Response response = ContactInfoMsApiHelpers.cpniContactInfoUser(tc as Map)

        then: "No mock interactions"
        0 * _

        and: "Response status matches expected"
        int expectedStatus = (tc.expectedStatus ?: 400) as int
        assert response.statusCode() == expectedStatus :
                "Expected ${expectedStatus} but got ${response.statusCode()}"

        where:
        tc << cpniUserNegative
    }
}
