package com.att.idp.integration

import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpHandler
import com.sun.net.httpserver.HttpServer
import groovy.json.JsonSlurper
import spock.lang.Specification
import spock.lang.Stepwise
import spock.lang.Unroll

import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse
import java.time.Duration

/**
 * Integration tests that validate the Generic Mocking API endpoints deployed via deploy-mock-api.sh.
 * Starts an embedded mock HTTP server that mirrors the behavior of local-mock-server.py,
 * serving static JSON responses from apim-mocking-testing/mocks/.
 */
@Stepwise
class MockingApiIntegrationTest extends Specification {

    static final String MOCKS_DIR = "apim-mocking-testing/mocks"
    static HttpServer mockServer
    static String mockBaseUrl

    HttpClient httpClient
    JsonSlurper jsonSlurper

    def setupSpec() {
        mockServer = HttpServer.create(new InetSocketAddress(0), 0)
        int port = mockServer.address.port
        mockBaseUrl = "http://localhost:${port}"

        mockServer.createContext("/", new HttpHandler() {
            @Override
            void handle(HttpExchange exchange) throws IOException {
                String path = exchange.requestURI.path
                String responseBody

                if (path.contains("inquire-profile")) {
                    responseBody = new File("${MOCKS_DIR}/inquire-profile/success-response.json").text
                } else if (path.contains("lscrm")) {
                    responseBody = new File("${MOCKS_DIR}/lscrm/success-response.json").text
                } else if (path.contains("mulesoft")) {
                    responseBody = new File("${MOCKS_DIR}/mulesoft/success-response.json").text
                } else {
                    responseBody = '{"error": "Mock not found"}'
                }

                byte[] bytes = responseBody.getBytes("UTF-8")
                exchange.responseHeaders.set("Content-Type", "application/json")
                exchange.sendResponseHeaders(200, bytes.length)
                exchange.responseBody.write(bytes)
                exchange.responseBody.close()
            }
        })
        mockServer.start()
    }

    def cleanupSpec() {
        if (mockServer != null) {
            mockServer.stop(0)
        }
    }

    def setup() {
        httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(10))
                .build()
        jsonSlurper = new JsonSlurper()
    }

    // ──────────────────────────────────────────────
    // Inquire Profile — GET /mock/inquire-profile/*
    // ──────────────────────────────────────────────

    def "should return success response from InquireProfile mock endpoint"() {
        given: "expected response loaded from mock file"
        Map<String, Object> expectedResponse = (Map<String, Object>) jsonSlurper.parse(
                new File("${MOCKS_DIR}/inquire-profile/success-response.json"))
        String url = mockBaseUrl + "/inquire-profile/1234567890"

        when: "GET request is sent to the InquireProfile mock endpoint"
        HttpResponse<String> response = httpClient.send(
                HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .header("Content-Type", "application/json")
                        .header("X-ATT-ClientId", "test-client")
                        .header("idp-trace-id", "trace-ip-001")
                        .GET()
                        .build(),
                HttpResponse.BodyHandlers.ofString())

        then: "no unexpected interactions"
        0 * _

        and: "response status is 200 and body matches expected mock"
        response.statusCode() == 200
        Map<String, Object> body = (Map<String, Object>) jsonSlurper.parseText(response.body())
        body.profile != null
        body.profile.status == expectedResponse.profile.status
        body.profile.customerType == expectedResponse.profile.customerType
        body.profile.firstName == expectedResponse.profile.firstName
        body.profile.lastName == expectedResponse.profile.lastName
        body.profile.contactEmail == expectedResponse.profile.contactEmail
    }

    def "should return valid JSON structure from InquireProfile mock"() {
        given: "request URL"
        String url = mockBaseUrl + "/inquire-profile/9876543210"

        when: "GET request is sent with a different account number"
        HttpResponse<String> response = httpClient.send(
                HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .header("Content-Type", "application/json")
                        .header("X-ATT-ClientId", "test-client")
                        .header("idp-trace-id", "trace-ip-002")
                        .GET()
                        .build(),
                HttpResponse.BodyHandlers.ofString())

        then: "no unexpected interactions"
        0 * _

        and: "response is valid JSON with HTTP 200"
        response.statusCode() == 200
        Map<String, Object> body = (Map<String, Object>) jsonSlurper.parseText(response.body())
        body != null
    }

    // ──────────────────────────────────────────────
    // LSCRM — POST /mock/lscrm/*
    // ──────────────────────────────────────────────

    def "should return success response from LSCRM mock endpoint"() {
        given: "request and expected response loaded from mock files"
        String requestBody = new File("${MOCKS_DIR}/lscrm/success-request.json").text
        Map<String, Object> expectedResponse = (Map<String, Object>) jsonSlurper.parse(
                new File("${MOCKS_DIR}/lscrm/success-response.json"))
        String url = mockBaseUrl + "/lscrm/authorize"

        when: "POST request is sent to the LSCRM mock endpoint"
        HttpResponse<String> response = httpClient.send(
                HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .header("Content-Type", "application/json")
                        .header("X-ATT-ClientId", "test-client")
                        .header("idp-trace-id", "trace-lscrm-001")
                        .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                        .build(),
                HttpResponse.BodyHandlers.ofString())

        then: "no unexpected interactions"
        0 * _

        and: "response status is 200 and body matches expected mock"
        response.statusCode() == 200
        Map<String, Object> body = (Map<String, Object>) jsonSlurper.parseText(response.body())
        body.authInfo != null
        body.authInfo.accountNumber == expectedResponse.authInfo.accountNumber
        body.authInfo.authStatus == expectedResponse.authInfo.authStatus
        body.authInfo.authMethod == expectedResponse.authInfo.authMethod
        body.authInfo.token == expectedResponse.authInfo.token
    }

    def "should accept POST with empty body to LSCRM mock endpoint"() {
        given: "request URL"
        String url = mockBaseUrl + "/lscrm/authorize"

        when: "POST request is sent with empty body"
        HttpResponse<String> response = httpClient.send(
                HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .header("Content-Type", "application/json")
                        .header("X-ATT-ClientId", "test-client")
                        .header("idp-trace-id", "trace-lscrm-002")
                        .POST(HttpRequest.BodyPublishers.ofString("{}"))
                        .build(),
                HttpResponse.BodyHandlers.ofString())

        then: "no unexpected interactions"
        0 * _

        and: "response is still 200 — mock returns static response regardless of input"
        response.statusCode() == 200
        Map<String, Object> body = (Map<String, Object>) jsonSlurper.parseText(response.body())
        body.authInfo != null
    }

    // ──────────────────────────────────────────────
    // MuleSoft — POST /mock/mulesoft/*
    // ──────────────────────────────────────────────

    def "should return success response from MuleSoft mock endpoint"() {
        given: "request and expected response loaded from mock files"
        String requestBody = new File("${MOCKS_DIR}/mulesoft/success-request.json").text
        Map<String, Object> expectedResponse = (Map<String, Object>) jsonSlurper.parse(
                new File("${MOCKS_DIR}/mulesoft/success-response.json"))
        String url = mockBaseUrl + "/mulesoft/notify"

        when: "POST request is sent to the MuleSoft mock endpoint"
        HttpResponse<String> response = httpClient.send(
                HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .header("Content-Type", "application/json")
                        .header("X-ATT-ClientId", "test-client")
                        .header("idp-trace-id", "trace-ms-001")
                        .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                        .build(),
                HttpResponse.BodyHandlers.ofString())

        then: "no unexpected interactions"
        0 * _

        and: "response status is 200 and body matches expected mock"
        response.statusCode() == 200
        Map<String, Object> body = (Map<String, Object>) jsonSlurper.parseText(response.body())
        body.notificationId == expectedResponse.notificationId
        body.status == expectedResponse.status
        body.timestamp == expectedResponse.timestamp
    }

    def "should accept POST with empty body to MuleSoft mock endpoint"() {
        given: "request URL"
        String url = mockBaseUrl + "/mulesoft/notify"

        when: "POST request is sent with empty body"
        HttpResponse<String> response = httpClient.send(
                HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .header("Content-Type", "application/json")
                        .header("X-ATT-ClientId", "test-client")
                        .header("idp-trace-id", "trace-ms-002")
                        .POST(HttpRequest.BodyPublishers.ofString("{}"))
                        .build(),
                HttpResponse.BodyHandlers.ofString())

        then: "no unexpected interactions"
        0 * _

        and: "response is still 200"
        response.statusCode() == 200
        Map<String, Object> body = (Map<String, Object>) jsonSlurper.parseText(response.body())
        body.status == "DELIVERED"
    }

    // ──────────────────────────────────────────────
    // Cross-cutting: unknown endpoint
    // ──────────────────────────────────────────────

    def "should return error response for unknown mock endpoint"() {
        given: "request URL"
        String url = mockBaseUrl + "/unknown/endpoint"

        when: "GET request is sent to an unknown mock path"
        HttpResponse<String> response = httpClient.send(
                HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .header("Content-Type", "application/json")
                        .header("X-ATT-ClientId", "test-client")
                        .header("idp-trace-id", "trace-unknown-001")
                        .GET()
                        .build(),
                HttpResponse.BodyHandlers.ofString())

        then: "no unexpected interactions"
        0 * _

        and: "response indicates mock not found"
        response.statusCode() == 200
        Map<String, Object> body = (Map<String, Object>) jsonSlurper.parseText(response.body())
        body.error == "Mock not found"
    }

    // ──────────────────────────────────────────────
    // Parameterized: all endpoints respond with 200
    // ──────────────────────────────────────────────

    @Unroll
    def "should return HTTP 200 from #scenarioName mock endpoint"() {
        given: "request URL"
        String url = mockBaseUrl + path

        when: "request is sent to the mock endpoint"
        HttpRequest.Builder requestBuilder = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .header("X-ATT-ClientId", "test-client")
                .header("idp-trace-id", "trace-param-" + scenarioName)

        HttpRequest httpRequest = httpMethod == "GET"
                ? requestBuilder.GET().build()
                : requestBuilder.POST(HttpRequest.BodyPublishers.ofString("{}")).build()

        HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString())

        then: "no unexpected interactions"
        0 * _

        and: "response status is 200"
        response.statusCode() == 200

        where:
        scenarioName      | path                              | httpMethod
        "inquire-profile" | "/inquire-profile/1234567890"     | "GET"
        "lscrm"           | "/lscrm/authorize"                | "POST"
        "mulesoft"        | "/mulesoft/notify"                 | "POST"
    }
}

