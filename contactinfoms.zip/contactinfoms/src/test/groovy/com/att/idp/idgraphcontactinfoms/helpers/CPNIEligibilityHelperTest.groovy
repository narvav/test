package com.att.idp.idgraphcontactinfoms.helpers

import com.att.idp.core.exception.ServiceException
import com.att.idp.idgraphcontactinfoms.model.Characteristic
import spock.lang.Specification
import spock.lang.Unroll

import org.slf4j.Logger;
import org.slf4j.LoggerFactory

import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate;

class CPNIEligibilityHelperTest extends Specification {
    def CPNIEligibilityHelper cpniEligibilityHelper
    Logger logger = null

    def setup() {
        cpniEligibilityHelper = new CPNIEligibilityHelper()
        logger = LoggerFactory.getLogger('CPNIEligibilityHelper')
    }

    def "test updateCPNIEligibility with valid dates for BSSE products"() {
        given:
        Characteristic characteristic = new Characteristic()
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSX");
        OffsetDateTime now = OffsetDateTime.now();
        String establishmentDate = now.minusDays(30).format(formatter);
        String creationDate = now.format(formatter);

        when:
        Characteristic result = cpniEligibilityHelper.updateCPNIEligibility(characteristic, establishmentDate, creationDate, "CG")

        then:
        result != null
        result.isAged == true
        result.cpniEligible == true
    }

    def "test updateCPNIEligibility with creationDate as null for BSSE products"() {
        given:
        Characteristic characteristic = new Characteristic()
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSX");
        OffsetDateTime now = OffsetDateTime.now();
        String establishmentDate = now.minusDays(30).format(formatter);
        String creationDate = null;

        when:
        Characteristic result = cpniEligibilityHelper.updateCPNIEligibility(characteristic, establishmentDate, creationDate, "CG")

        then:
        result != null
        result.isAged == true
        result.cpniEligible == false
    }

    def "test updateCPNIEligibility with targetSor as null for BSSE products"() {
        given:
        Characteristic characteristic = new Characteristic()
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSX");
        OffsetDateTime now = OffsetDateTime.now();
        String establishmentDate = now.minusDays(30).format(formatter);
        String creationDate = null;

        when:
        Characteristic result = cpniEligibilityHelper.updateCPNIEligibility(characteristic, establishmentDate, creationDate, null)

        then:
        thrown(ServiceException)
    }

    @Unroll
    def "should update CPNI eligibility for Uverse CBR for #scenarioName"() {
        given:
        String dateTimeFormat = "yyyy-MM-dd HH:mm:ss"
        Characteristic characteristic = new Characteristic()
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateTimeFormat)
        OffsetDateTime now = OffsetDateTime.now()
        String establishmentDate = now.minusDays(daysAgo).format(formatter)

        when:
        Characteristic result = cpniEligibilityHelper.updateCPNIEligibilityForUverseCBR(characteristic, establishmentDate, isVerified, dateTimeFormat)

        then:
        result != null
        result.isAged == expectedIsAged
        result.cpniEligible == expectedCpniEligible

        where:
        scenarioName              | daysAgo | expectedIsAged | expectedCpniEligible | isVerified
        "valid (aged) date"      | 30      | true           | true     | true
        "invalid (not aged) date"| 10      | false          | false    | true
        "isVerified is null"    | 10      | false          | false    | null
    }

    def "should update CPNI eligibility for Uverse CBR for establishmentDate as null"() {
        given:
        String dateTimeFormat = "yyyy-MM-dd HH:mm:ss"
        Characteristic characteristic = new Characteristic()
        boolean isVerified = true
        String establishmentDate = null

        when:
        Characteristic result = cpniEligibilityHelper.updateCPNIEligibilityForUverseCBR(characteristic, establishmentDate, isVerified, dateTimeFormat)

        then:
        result != null
        result.isAged == false
        result.cpniEligible == false

    }

    def "test updateCPNIEligibility with future establishment date for BSSE products"() {
        given:
        Characteristic characteristic = new Characteristic()
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSX");
        OffsetDateTime now = OffsetDateTime.now();
        String establishmentDate = now.plusDays(10).format(formatter);
        String creationDate = now.format(formatter);

        when:
        Characteristic result = cpniEligibilityHelper.updateCPNIEligibility(characteristic, establishmentDate, creationDate,"CG")

        then:
        result != null
        result.isAged == false
        result.cpniEligible == false
    }

    @Unroll
    def "should updateSubscriberCPNIEligibility for #scenarioName"() {
        given:
        Characteristic characteristic = new Characteristic()

        when:
        Characteristic result = cpniEligibilityHelper.updateSubscriberCPNIEligibility(characteristic, status, smsCapable, simSwapDate, accountCreatedOn)

        then:
        result != null
        result.cpniEligible == expectedCpniEligible

        where:
        scenarioName                                      | status     | smsCapable | simSwapDate                                 | accountCreatedOn                            | expectedCpniEligible
        "active and SMS capable, no sim swap date"      | "active"  | true       | null                                        | null                                        | true
        "inactive status, no sim swap"                  | "inactive"| true       | null                                        | null                                        | false
        "active but not SMS capable"                    | "active"  | false      | null                                        | null                                        | false
        "active, SMS capable, sim swap aged and valid"  | "active"  | true       |  "2026-01-20T10:00:00.234Z"    | null                                        | true
        "active, SMS capable, sim swap not aged, same"  | "active"  | true       | "2026-02-01T10:00:00.234Z"                |  "2026-02-01T10:00:00.234Z"               | true
    }

    def "test updateCPNIEligibility with establishment date as null for BSSE products"() {
        given:
        Characteristic characteristic = new Characteristic()
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSX");
        OffsetDateTime now = OffsetDateTime.now();
        String establishmentDate = null;
        String creationDate = now.format(formatter);

        when:
        Characteristic result = cpniEligibilityHelper.updateCPNIEligibility(characteristic, establishmentDate, creationDate, "CG")

        then:
        result != null
        result.cpniEligible == false
    }

    @Unroll
    def "should validate simSwapDateValidation for #scenarioName"() {
        given:
        // Set up the helper and its aging days property
        cpniEligibilityHelper.sSimSwapAgingDays = simSwapAgingDays
        // Use a date format matching the method's default
        String dateTimeFormat = "yyyy-MM-dd HH:mm:ss"
        // Prepare test dates using LocalDateTime for correct formatting
        String simSwapDateStr = simSwapDate ? java.time.LocalDateTime.of(java.time.LocalDate.parse(simSwapDate), java.time.LocalTime.MIDNIGHT).format(java.time.format.DateTimeFormatter.ofPattern(dateTimeFormat)) : null
        String accountCreatedOnStr = accountCreatedOn ? java.time.LocalDateTime.of(java.time.LocalDate.parse(accountCreatedOn), java.time.LocalTime.MIDNIGHT).format(java.time.format.DateTimeFormatter.ofPattern(dateTimeFormat)) : null

        when:
        boolean result = cpniEligibilityHelper.simSwapDateValidation(simSwapDateStr, accountCreatedOnStr, dateTimeFormat)

        then:
        result == expected

        where:
        scenarioName                                 | simSwapDate      | accountCreatedOn | simSwapAgingDays | expected
        "SIM swap date is aged"                      | LocalDate.now().minusDays(3).toString() | null             | "2"             | true
        "SIM swap date not aged, accountCreatedOn same as simSwapDate" | LocalDate.now().toString() | LocalDate.now().toString() | "2" | true
        "SIM swap date not aged, accountCreatedOn different" | LocalDate.now().toString() | LocalDate.now().minusDays(1).toString() | "2" | false
        "SIM swap date blank"                        | null             | LocalDate.now().toString() | "2" | false
        "SIM swap date not aged, accountCreatedOn blank" | LocalDate.now().toString() | null | "2" | false
        "SIM swap aging days blank (default 2)"      | LocalDate.now().minusDays(3).toString() | null | null | true
    }

    @Unroll
    def "should updateSubscriberCPNIEligibilityForLegacy for #scenarioName"() {
        given:
        Characteristic characteristic = new Characteristic()
        cpniEligibilityHelper.sSimSwapAgingDays = simSwapAgingDays
        String dateTimeFormat = "yyyy-MM-dd HH:mm:ss"
        String simSwapDateStr = simSwapDate ? java.time.LocalDateTime.of(java.time.LocalDate.parse(simSwapDate), java.time.LocalTime.MIDNIGHT).format(java.time.format.DateTimeFormatter.ofPattern(dateTimeFormat)) : null
        String accountCreatedOnStr = accountCreatedOn ? java.time.LocalDateTime.of(java.time.LocalDate.parse(accountCreatedOn), java.time.LocalTime.MIDNIGHT).format(java.time.format.DateTimeFormatter.ofPattern(dateTimeFormat)) : null

        when:
        Characteristic result = cpniEligibilityHelper.updateSubscriberCPNIEligibilityForLegacy(characteristic, status, smsCapable, simSwapDateStr, accountCreatedOnStr)

        then:
        result != null
        result.cpniEligible == expectedCpniEligible

        where:
        scenarioName | status     | smsCapable | simSwapDate      | accountCreatedOn | simSwapAgingDays | expectedCpniEligible
        "all valid, aged" | "active"  | true       | LocalDate.now().minusDays(3).toString() | null             | "2"             | true
        "all valid, not aged, same date" | "active"  | true       | LocalDate.now().toString() | LocalDate.now().toString() | "2" | true
        "all valid, not aged, different date" | "active"  | true       | LocalDate.now().toString() | LocalDate.now().minusDays(1).toString() | "2" | false
        "inactive status" | "inactive"| true       | LocalDate.now().minusDays(3).toString() | null | "2" | false
        "not SMS capable" | "active"  | false      | LocalDate.now().minusDays(3).toString() | null | "2" | false
        "simSwapDate blank" | "active"  | true       | null | LocalDate.now().toString() | "2" | false
        "simSwapAgingDays blank (default 2)" | "active"  | true       | LocalDate.now().minusDays(3).toString() | null | null | true
    }
}
