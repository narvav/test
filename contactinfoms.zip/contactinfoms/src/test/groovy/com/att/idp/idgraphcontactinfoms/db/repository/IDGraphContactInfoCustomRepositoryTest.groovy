package com.att.idp.idgraphcontactinfoms.db.repository

import com.att.idp.idgraphcontactinfoms.db.model.Tsecuritycode
import org.hibernate.Session
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import jakarta.persistence.EntityManager

class IDGraphContactInfoCustomRepositoryTest extends Specification {
	
	def customRepoMock = new IDGraphContactInfoCustomRepository<Tsecuritycode, Long>()

	def entityManagerMock = Mock(EntityManager)

	def session = Mock(Session)


	def setup() throws Exception {
		customRepoMock.entityManager = entityManagerMock
		ReflectionTestUtils.setField(customRepoMock, 'entityManager', entityManagerMock)
		entityManagerMock.unwrap(_) >> session
	}


	def "test get session"() {
		expect:
		customRepoMock.session != null
	}


	def "test get by id with write lock"(){
		expect:
		customRepoMock.getByIdWithWriteLock(1L) == null
	}

}
