package com.att.idp.idgraphcontactinfoms.helpers

import com.att.idp.idgraphcontactinfoms.db.helper.ContactDBHelper
import com.att.mpsys.common.utils.*
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification


class InquireUserContactCBRHelperTest extends Specification {
	
	def InquireUserContactCBRHelper inquireUserContactCBRHelperObj = new InquireUserContactCBRHelper()

    ContactDBHelper contactDBHelper = Mock(ContactDBHelper)

    String stTransactionId = null
    HashMap resultHashSuccess = null
    HashMap resultHashRecNotFound = null
    HashMap resultHashError = null
    HashMap hmInput = null
    HashMap hmResult = null
    String stAppStatusMsg = null
    String stAppInfo = null
    HashMap hmLinkedMember = null
    HashMap hmDBContact = null
    ArrayList alLinkedMemberList = null
    ArrayList alContactList = null


    def setup() {
        inquireUserContactCBRHelperObj.contactDBHelper = contactDBHelper
        System.setProperty('CommonConfigurationFilePath', './opt/att/ajsc/config/CommonConfigurationTest.xml')

        hmLinkedMember = CommonUtil.hashMap
        hmLinkedMember[CommonDefs.MEMBER_NAME] = 'Kanav Gupta'
        hmLinkedMember[CommonDefs.MEMBER_NUM] = '984214981'
        hmLinkedMember['domainName'] = 'att.net'

        alLinkedMemberList = CommonUtil.arrayList
        alLinkedMemberList.add(hmLinkedMember)

        hmInput = CommonUtil.hashMap
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.TRANSACTION_ID] = 'kan_123'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.IS_EXTERNAL_CALL] = 'Y'
        hmInput[CommonDefs.GUID] = '123456789'
        hmInput['linkedMemberList'] = alLinkedMemberList

        hmDBContact = CommonUtil.hashMap
        hmDBContact[MPSDefs.DB_CONTACT_TYPE] = 'SMS'
        hmDBContact['established_date'] = '09282014 06:15:47'
        hmDBContact[MPSDefs.DB_CONTACT_STATUS] = 'V'
        hmDBContact[MPSDefs.DB_VALIDATION_STATUS] = '8'
        hmDBContact[MPSDefs.DB_MEMBER_NUM] = '984214981'

        alContactList = CommonUtil.arrayList
        alContactList.add(hmDBContact)
		
		resultHashSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG)
        resultHashSuccess['contacts'] = alContactList

        stAppInfo = 'Error returned from Helper'
        resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo)
        resultHashRecNotFound = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo)
        ReflectionTestUtils.setField(inquireUserContactCBRHelperObj, 'sPropInquireUserContactInfoCSI', 'DATAMGT|IDP|CSRIDP|ILM|MULESOFT|OPUS|CUSTOMERGRAPH')

    }


    def "inquire contact c b r null input error case"() {
        when:
        hmResult = inquireUserContactCBRHelperObj.inquireUserContactCBR(null)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Input Hash is NULL'
    }


    def "inquire contact c b r invalid c s i error case"() {
        given:
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'DRIDP'
        when:
        hmResult = inquireUserContactCBRHelperObj.inquireUserContactCBR(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Invalid CallingSystemId'
    }


    def "inquire contact c b r invalid c s null"() {
        given:
        ReflectionTestUtils.setField(inquireUserContactCBRHelperObj, 'sPropInquireUserContactInfoCSI',null)
        when:
        hmResult = inquireUserContactCBRHelperObj.inquireUserContactCBR(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Property value is null or empty'
    }


    def "inquire contact c b r null response get user contact error case"() {
        given:
        contactDBHelper.getUserContact(_)>>null
        when:
        hmResult = inquireUserContactCBRHelperObj.inquireUserContactCBR(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Null Response returned from ContactDBHelper.getUserContact()'
    }


    def "inquire contact c b r get user contact error case"() {
        given:
        contactDBHelper.getUserContact(_)>>resultHashError
        when:
        hmResult = inquireUserContactCBRHelperObj.inquireUserContactCBR(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Error returned from Helper'
    }


    def "inquire contact c b r rec not found get user contact s u c c e s s case"() {
        given:
        hmInput['linkedMemberList'] = null
        contactDBHelper.getUserContact(_)>>resultHashRecNotFound
        when:
        hmResult = inquireUserContactCBRHelperObj.inquireUserContactCBR(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "inquire contact c b r get user contact s u c c e s s case"() {
        given:
        hmInput[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        contactDBHelper.getUserContact(_)>>resultHashSuccess
        when:
        hmResult = inquireUserContactCBRHelperObj.inquireUserContactCBR(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "inquire contact c b r get user contact exception case"() {
        given:
        hmInput[CommonDefs.GUID] = 123456789
        when:
        hmResult = inquireUserContactCBRHelperObj.inquireUserContactCBR(hmInput)
        then:
        //hmResult[CommonDefs.COMMON_APP_INFO] == 'SYSTEM ERROR'
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

}
