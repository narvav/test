package com.att.idp.integration

import spock.lang.Specification
import static org.hamcrest.CoreMatchers.anyOf
import static org.hamcrest.CoreMatchers.is

class CPNIContactInfoIT extends IntegrationTestBase {

	private Map<String, String> getHeaders() {
		Map<String, String> headers = new HashMap<>()
		headers.put("Content-Type", "application/json")
		headers.put("idp-trace-id", "ed44414d155475a6:ed44414d155475a6:0:0")
		headers.put("X-ATT-ClientId", "IDP")
		return headers
	}

	def "query CPNI account success"() {
		given:
		String uri = "/cpniContactInfo/account"
		String req = """{
            "accountInvariantId": "000911033779",
            "accountId": "000911033779",
            "accountType": "ECOMM",
            "returnCBRCTNs": "N",
            "isExternalCall": "N"
        }"""

		when:
		def response = givenBaseSpec().headers(getHeaders()).body(req).post(uri)

		then:
		response.statusCode() in [200, 400]
	}

	def "query CPNI user success"() {
		given:
		String uri = "/cpniContactInfo/user"
		String req = """{
            "guid": "1020425284",
            "returnCBRCTNs": "Y",
            "isExternalCall": "N"
        }"""

		when:
		def response = givenBaseSpec().headers(getHeaders()).body(req).post(uri)

		then:
		response.statusCode() in [200, 400]
	}
}