package com.att.idp.idgraphcontactinfoms.helpers

import com.att.idp.idgraph.db.cosmos.helper.IdgOtpDBHelper
import com.att.idp.idgraphcontactinfoms.db.helper.SecurityCodeDBHelper
import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.jboss.logging.MDC
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class InquirePINHelperTest extends Specification {
	
	def InquirePINHelper inquirePINHelperObj = new InquirePINHelper()
    SecurityCodeDBHelper securityCodeDBHelperObj = Mock(SecurityCodeDBHelper)
    IdgOtpDBHelper idgOtpDBHelper = Mock(IdgOtpDBHelper)
    FeatureManagerHelper featureManager = Mock(FeatureManagerHelper)
    HashMap hmInput = null
    HashMap hmResponse = null
    String stAppInfo = null
    String stAppStatusMsg = null
    Logger logger = null
    HashMap hmDBInput = null
    HashMap<String, Object> hmSecurityCodeResp = null
    ArrayList alSecurityCodeData = new ArrayList<>()


    def setup() throws Exception {
        inquirePINHelperObj.securityCodeDBHelperObj = securityCodeDBHelperObj
        inquirePINHelperObj.idgOtpDBHelper = idgOtpDBHelper
        inquirePINHelperObj.featureManager = featureManager
		logger = LoggerFactory.getLogger('DeletePIN')
        MDC.put('transid', 'test123')
        System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')

        hmSecurityCodeResp = new HashMap()
        hmInput = new HashMap()
        hmInput['transactionName'] = 'InquirePIN'
        hmInput['callingSystemId'] = 'DATAMGT'
        hmInput['accountId'] = '000981453456'
        hmInput['identificationType'] = 'IDSEMOB'
        hmInput['transactionId'] = 'test1234'

        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> 'ORACLEMASTER'

        MDC.put('transid', 'test123')
        System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')

       //ReflectionTestUtils.setField(inquirePINHelperObj, 'propValidPINCSI', 'IDSEMOB:IDP|DATAMGT,BANPCS:OPUS|IDP|CSRIDP,BANPCE:OPUS,BANPTONLS:MYATTSALES|IDP|UPPERFUNNEL|ANDIVA,BANPTONLE:MYATTSALES|IDP|ANDIVA,DTVNOWOTP:CSRIDP,CTNKSK:EXPKSK,BTN:IDP|DATAMGT,PINVALID:IDP|CSRIDP,NONATTCTN:IDP|CSRIDP|OPUS,ATTCTN:IDP|CSRIDP,EMAILOTP:IDP|OPUS,CRICKETOTP:IDP|CSRIDP|OPUS,EMAILPIN:IDP|CSRIDP|OPUS|ERICSSON|MYATTSALES|IDPSALES|MULESOFT|MYATTMOBILE,CTNDIH:IDP|CSRIDP|OPUS,BANAP:PENNYVA,TITANIMD:IDP|CSRIDP,CTN:IDP|CSRIDP,WBAN:IDP|CSRIDP,ECOMMSEC:IDP|CSRIDP,WBANSEC:IDP|CSRIDP,TITANSEC:IDP|CSRIDP,DTVOTP:DIRECTV,CTNAUTH:MULESOFT,CTNOPR:IDP|CSRIDP,ENCPIN:IDPSALES,PORTOUT:AVERTACK,CCPADTV:IDP,BSSEOTP:IDP|MULESOFT|IVR,BSSEONL:IDP,BSSEREGOTP:IDP')
        ReflectionTestUtils.setField(inquirePINHelperObj, 'propPinMaxPins',
                'IDSEMOB:10|BANPCS:10|BANPCE:10|BANPTONLS:10|BANPTONLE:10|DTVNOWOTP:5|CTNKSK:10|BTN:10|PINVALID:10|NONATTCTN:10|ATTCTN:10|EMAILOTP:10|CRICKETOTP:10|EMAILPIN:10|CTNDIH:5|BANAP:10|TITANIMD:10|CTN:10|WBAN:10|ECOMMSEC:10|WBANSEC:10|TITANSEC:10|DTVOTP:10|CTNAUTH:10|CTNOPR:5|ENCPIN:10|PORTOUT:5|CCPADTV:10|BSSEOTP:10|BSSEONL:10|BSSEREGOTP:10|AUTHUSER:10|NTRETAILER:10|ESIMOTP:10|GENERICOTP:10|PORTOUTABS:5|PORTOUTBSS:5|BANPC:10|\\\n' +
                        'REGIMPROVE:10|APPTSCHED:5|BANCRU:10|BANPT:10|BANPTONL:10|CALLFWD:5|PORTOUTPP:5|SMBYIELD:5')

    }


    def cleanup() throws Exception {
		MDC.remove('transid')
    }


    def "test inquirePIN when required param is null"() {

        given:
        hmInput['accountId'] = null

        when:
        hmResponse = inquirePINHelperObj.inquirePIN(hmInput)

        then:
        hmResponse != null
        hmResponse['appInfo'] == 'Either of the parameters TransactionName|CallingSystemId|AccountId|IdentificationType is null'
    }


    def "test inquire p i n security code failure"() throws Exception {

		// when security code response is recode not found
        given:
        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.ERR_REC_NOT_FOUND
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap)>>hmSecurityCodeResp
        when:
        hmResponse = inquirePINHelperObj.inquirePIN(hmInput)
        then:
        hmResponse != null
        hmResponse['appInfo'] == 'No record found in DB.'

        // when security code call fails
        when:
        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = 'Error'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap)>>hmSecurityCodeResp
        hmResponse = inquirePINHelperObj.inquirePIN(hmInput)
        then:
        hmResponse != null

    }

    def "test inquire p i n security code"() throws Exception {

		given:
        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '5'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023 12:12:12'
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE_EXPIRES] = '23012023 12:12:12'
        hmDBSecurityCode['security_code_status'] = 'ACTIVE'
        hmDBSecurityCode[MPSDefs.DB_LAST_MODIFIED_BY] = 'CSIGATEWAY'

        alSecurityCodeData.add(hmDBSecurityCode)

        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeResp[MPSDefs.SECURITY_CODE_INFO] = alSecurityCodeData
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap)>>hmSecurityCodeResp
        when:
        hmResponse = inquirePINHelperObj.inquirePIN(hmInput)
        then:
        hmResponse != null
        hmResponse['securityPins'] != null
	}

    def "test inquire p i n security code exception"() throws Exception {

        // when security code response is recode not found
        given:
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap)>> { throw NullPointerException}
        when:
        hmResponse = inquirePINHelperObj.inquirePIN(hmInput)
        then:
        hmResponse['appStatusCode'] == '602'

    }
    def "test inquirePIN when PROP_PIN_MAX_PINS is not set for IdentificationType"() {
        given:
        // Remove the identification type from the property so sMaxPins will be null
        ReflectionTestUtils.setField(inquirePINHelperObj, 'propPinMaxPins', 'IDSEMOB:0')
        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeResp[MPSDefs.SECURITY_CODE_INFO] = []
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeResp

        when:
        def response = inquirePINHelperObj.inquirePIN(hmInput)

        then:
        response != null
        response[CommonDefs.COMMON_APP_INFO] == "PROP_PIN_MAX_PINS is not set for IdentificationType : IDSEMOB"
        response[CommonDefs.COMMON_APP_STATUS_CODE] == '100'
    }
}
