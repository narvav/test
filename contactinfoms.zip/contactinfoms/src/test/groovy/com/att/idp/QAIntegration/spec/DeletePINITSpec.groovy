package com.att.idp.QAIntegration.spec

import com.att.idp.QAIntegration.Base.TestBase
import com.att.idp.QAIntegration.Config.ContactInfoGlobalConfig
import com.att.idp.QAIntegration.Helpers.ContactInfoMsApiHelpers
import groovy.util.logging.Slf4j
import io.restassured.response.Response
import spock.lang.IgnoreIf
import spock.lang.Shared
import spock.lang.Tag
import spock.lang.Unroll

/**
 * QG7 Integration Test — IDGraphContactInfoMs Delete PIN
 *
 * Tests for POST /pin/delete endpoint with both positive and negative test cases.
 * YAML-driven: reads test data from QATestData/{ENV}/IDGraphContactInfoMs_TestData.yaml
 *
 * OMNI Compliance:
 * - Spec suffix: *ITSpec.groovy (testing-foundation.md E1)
 * - then: 0 * _ mandatory (HS-8)
 * - No mocks — real HTTP call to deployed service
 */
@Slf4j
@Tag("Regression")
@Tag("PIN")
@Tag("IDGraphContactInfoMs")
@IgnoreIf({ !ContactInfoGlobalConfig.isTestCaseEnabled("DeletePINITSpec") })
class DeletePINITSpec extends TestBase {

    @Shared
    Map testData = ContactInfoGlobalConfig.getTestData()

    @Shared
    List<Map> deletePinPositive = (testData?.get("deletePinPositive") as List<Map>) ?: []

    @Shared
    List<Map> deletePinNegative = (testData?.get("deletePinNegative") as List<Map>) ?: []

    // ═══════════════════════════════════════════════════════════════════════════
    // Delete PIN — Positive Tests
    // ═══════════════════════════════════════════════════════════════════════════

    @Unroll("Delete PIN Positive — #tc.testCaseName")
    def "Delete PIN — Positive Tests"() {
        setup:
        setTestName(tc.testCaseName as String)
        logStep("POST ${ContactInfoGlobalConfig.Endpoints.DELETE_PIN}")

        when: "POST Delete PIN is called"
        Response response = ContactInfoMsApiHelpers.deletePIN(tc as Map)

        then: "No mock interactions"
        0 * _

        and: "Response status matches expected (200 for positive cases)"
        int expectedStatus = (tc.expectedStatus ?: 200) as int
        assert response.statusCode() == expectedStatus :
                "Expected ${expectedStatus} but got ${response.statusCode()}. Body: ${response.body().asString().take(500)}"

        where:
        tc << deletePinPositive
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Delete PIN — Negative Tests
    // ═══════════════════════════════════════════════════════════════════════════

    @Unroll("Delete PIN Negative — #tc.testCaseName")
    def "Delete PIN — Negative Tests"() {
        setup:
        setTestName(tc.testCaseName as String)
        logStep("POST ${ContactInfoGlobalConfig.Endpoints.DELETE_PIN} (expecting 400)")

        when: "POST Delete PIN is called with invalid data"
        Response response = ContactInfoMsApiHelpers.deletePIN(tc as Map)

        then: "No mock interactions"
        0 * _

        and: "Response status matches expected (400 for negative cases)"
        int expectedStatus = (tc.expectedStatus ?: 400) as int
        assert response.statusCode() == expectedStatus :
                "Expected ${expectedStatus} but got ${response.statusCode()}. Body: ${response.body().asString().take(500)}"

        where:
        tc << deletePinNegative
    }
}
