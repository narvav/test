package com.att.idp.idgraphcontactinfoms.request.validator

import com.att.idp.idgraphcontactinfoms.resource.request.DeletePINRequest
import com.att.idp.idgraphcontactinfoms.resource.response.DeletePinResponse
import com.att.mpsys.common.utils.CommonUtil
import jakarta.ws.rs.core.MultivaluedHashMap
import org.slf4j.MDC
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders

class DeletePINRequestValidatorTest extends Specification {
	
	def deletePINRequestValidatorObj = new DeletePINRequestValidator()
	public DeletePINRequest deletePINRequestObj = null

	def requestHeader = Stub(HttpHeaders)
	MultivaluedHashMap requestHeaders =null


	def setup() throws Exception {
		deletePINRequestObj = new DeletePINRequest()
		MultivaluedHashMap requestHeaders = new MultivaluedHashMap<>(headers)

		deletePINRequestObj.callingSystemId = 'IDP'
		//deletePINRequestObj.setTransactionName("DeletePIN");
		deletePINRequestObj.accountId = '476389532'
		deletePINRequestObj.identificationType = 'IDSEMOB'
		deletePINRequestObj.securityCode = 'Y'
		deletePINRequestObj.reasonCode = 'B'
		deletePINRequestObj.deleteAll = 'N'
		//deletePINRequestObj.setSourceIPAddress("10.55.17.56");
		//deletePINRequestObj.setTransactionId("trma_16374856");
		deletePINRequestObj.agentId = '1234'

		ReflectionTestUtils.setField(deletePINRequestValidatorObj, 'propValidPINIDENTypeAndCSI', 'IDSEMOB:IDP|DATAMGT,BANPCS:OPUS|IDP|CSRIDP,BANPCE:OPUS,BANPTONLS:MYATTSALES|IDP|UPPERFUNNEL|ANDIVA,BANPTONLE:MYATTSALES|IDP|ANDIVA,DTVNOWOTP:CSRIDP,CTNKSK:EXPKSK,BTN:IDP|DATAMGT,PINVALID:IDP|CSRIDP,NONATTCTN:IDP|CSRIDP|OPUS,ATTCTN:IDP|CSRIDP,EMAILOTP:IDP|OPUS,CRICKETOTP:IDP|CSRIDP|OPUS,EMAILPIN:IDP|CSRIDP|OPUS|ERICSSON|MYATTSALES|IDPSALES|MULESOFT|MYATTMOBILE,CTNDIH:IDP|CSRIDP|OPUS,BANAP:PENNYVA,TITANIMD:IDP|CSRIDP,CTN:IDP|CSRIDP,WBAN:IDP|CSRIDP,ECOMMSEC:IDP|CSRIDP,WBANSEC:IDP|CSRIDP,TITANSEC:IDP|CSRIDP,DTVOTP:DIRECTV,CTNAUTH:MULESOFT,CTNOPR:IDP|CSRIDP,ENCPIN:IDPSALES,PORTOUT:AVERTACK,CCPADTV:IDP,BSSEOTP:IDP|MULESOFT,BSSEOLN:IDP')
		ReflectionTestUtils.setField(deletePINRequestValidatorObj, 'propPINAgentCSI', 'OPUS|CSRIDP')
		requestHeader.getHeaderString('X-ATT-UniqueTransactionId') >> '99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		requestHeader.getRequestHeaders() >> requestHeaders
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		//requestHeader.add("X-ATT-UniqueTransactionId", "99dfs999:8dfs8888:77777:66666ccc");
	
	}

	private Map<String, String> headers = new HashMap<>()


	def "delete p i n request validator success test"(){
		given:
		deletePINRequestObj.agentId = null
		when:
		DeletePinResponse deletePINResponse = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader,deletePINRequestObj)
		then:
		deletePINResponse == null
	}

    def "delete p i n request validator success test2"(){
        given:
        requestHeader.getRequestHeaders().put('idp-trace-id', List.of('99dfs999:8dfs8888:77777:66666ccc'))
        deletePINRequestObj.agentId = null
        when:
        DeletePinResponse deletePINResponse = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader,deletePINRequestObj)
        then:
        deletePINResponse == null
    }

    def "deletePINRequestValidatorInputValidator test"() throws Exception {
        given:
        deletePINRequestObj.agentId = null
        deletePINRequestObj.unknownAttributes = CommonUtil.hashMap
        deletePINRequestObj.unknownAttributes.put("test","test")
        when:
        DeletePinResponse deletePINResponse = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader,deletePINRequestObj)
        then:
        deletePINResponse.appInfo == 'Invalid Attributes passed in deletePINRequest : {test=test}'
    }


	def "delete p i n null request test"(){
		given:
		deletePINRequestObj = null
		when:
		DeletePinResponse deletePINResponse = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader,deletePINRequestObj)
		then:
		deletePINResponse.appInfo == 'Input Request Parameter is NULL / Empty.'
	}


	def "delete p i n valid delete all test"() throws Exception {
		given:
		deletePINRequestObj.deleteAll = 'ekjgn'
		when:
		DeletePinResponse deletePINResponse = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader,
				deletePINRequestObj)
		then:
		deletePINResponse.appInfo == 'DeleteAll should be either Y or N'
	}


	def "delete p i n request c s i validator prop pin csi test"() throws Exception {
		given:
		deletePINRequestObj.identificationType = 'email'
		when:
		DeletePinResponse deletePINResponse = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader,
				deletePINRequestObj)
		then:
		deletePINResponse.appInfo == 'Input IdentificationType is not valid for CallingSystemId :IDP'
	}


	def "delete p i n request c s i validator valid caller test"() throws Exception {
		given:
		deletePINRequestObj.identificationType = 'IDSEMOB'
		deletePINRequestObj.callingSystemId = null
		//requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDM'
		when:
		DeletePinResponse deletePINResponse = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader,
				deletePINRequestObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDM'
		deletePINResponse.appInfo == ' Input X-ATT-ClientId or CallingSystemID  is not valid for IdentificationType :IDSEMOB'
	}


	def "delete p i n request c s i validator invalid calling sys id test"() throws Exception {
		given:
		deletePINRequestObj.identificationType = 'IDSEMOB'
		deletePINRequestObj.callingSystemId = 'IDM'
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		when:
		DeletePinResponse deletePINResponse = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader,
				deletePINRequestObj)
		then:
		deletePINResponse.appInfo == ' Input X-ATT-ClientId or CallingSystemID  is not valid for IdentificationType :IDSEMOB'
	}

    def "delete p i n request c s i validator propincsi not configured test"() throws Exception {
        given:
        deletePINRequestObj.identificationType = 'IDSEMOB'
        deletePINRequestObj.callingSystemId = 'IDM'
        requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
        ReflectionTestUtils.setField(deletePINRequestValidatorObj, 'propValidPINIDENTypeAndCSI', '')
        when:
        DeletePinResponse deletePINResponse = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader,
                deletePINRequestObj)
        then:
        deletePINResponse.appInfo == 'PROP_PIN_CSI  property is not configured in the properties file'
    }

	def "delete p i n request validator success for valid c s i test"(){
		given:
		deletePINRequestObj.identificationType = 'IDSEMOB'
		deletePINRequestObj.callingSystemId = 'IDP'
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDM'
		when:
		DeletePinResponse deletePINResponse = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader,deletePINRequestObj)
		then:
		deletePINResponse == null
	}


	def "delete p i n request validator success for valid c s i null client i d test"(){
		given:
		deletePINRequestObj.identificationType = 'IDSEMOB'
		deletePINRequestObj.callingSystemId = 'IDP'
		requestHeader.getHeaderString('X-ATT-ClientId') >> null
		when:
		DeletePinResponse deletePINResponse = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader,deletePINRequestObj)
		then:
		deletePINResponse == null
	}

	def "delete p i n valid c s i test"() throws Exception {
		given:
		deletePINRequestObj.callingSystemId = null
		//requestHeader.getHeaderString('X-ATT-ClientId') >> 'MYWORLD'
		when:
		DeletePinResponse deletePINResponse = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader,
				deletePINRequestObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'MYWORLD'
		deletePINResponse.appInfo == ' Input X-ATT-ClientId or CallingSystemID  is not valid for IdentificationType :IDSEMOB'
	}


	def "delete p i n request c s i validator null test"() throws Exception {
		given:
		ReflectionTestUtils.setField(deletePINRequestValidatorObj, 'propValidPINIDENTypeAndCSI', null)
		when:
		DeletePinResponse deletePINResponse = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader,
				deletePINRequestObj)
		then:
		deletePINResponse.appInfo == 'PROP_PIN_CSI  property is not configured in the properties file'
	}
	
//	@Test
//	public void deletePINRequestValidatorNullTransactionNameTest() throws Exception {
//		deletePINRequestObj.setTransactionName(null);
//		DeletePinResponse deletePINResponse = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader,deletePINRequestObj);
//		assertEquals("TransactionName can not be null / empty.", deletePINResponse.getAppInfo());
//	}


	def "delete p i n request validator null calling system i d test"() throws Exception {
		given:
		//requestHeader.getHeaderString('X-ATT-ClientId') >> null
		deletePINRequestObj.callingSystemId = null
		when:
		DeletePinResponse deletePINResponse = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader,deletePINRequestObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> null
		deletePINResponse.appInfo == 'Either X-ATT-ClientId in request header or callingSystemId in request body must be present'
	}


	def "delete p i n request validator null identification type test"() throws Exception {
		given:
		deletePINRequestObj.identificationType = null
		when:
		DeletePinResponse deletePINResponse = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader,deletePINRequestObj)
		then:
		deletePINResponse.appInfo == 'IdentificationType can not be null / empty.'
	}


	def "delete p i n request validator null account id test"() throws Exception {
		given:
		deletePINRequestObj.accountId = null
		when:
		DeletePinResponse deletePINResponse = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader,deletePINRequestObj)
		then:
		deletePINResponse.appInfo == 'AccountID can not be null / empty.'
	}


	def "delete p i n request validator null delete all test"() throws Exception {
		given:
		deletePINRequestObj.deleteAll = null
		when:
		DeletePinResponse deletePINResponse = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader,deletePINRequestObj)
		then:
		deletePINResponse.appInfo == 'DeleteAll can not be null / empty.'
	}

	// ============================================================
	// Coverage: missing idp-trace-id returns error (lines 82-84)
	// ============================================================

	def "deletePINRequestValidator returns error when idp-trace-id is missing"() {
		given:
		MDC.remove('idp-trace-id')
		def headerNoTrace = Stub(HttpHeaders)
		headerNoTrace.getHeaderString('idp-trace-id') >> null
		headerNoTrace.getHeaderString('X-ATT-UniqueTransactionId') >> null
		headerNoTrace.getHeaderString('X-ATT-ClientId') >> 'IDP'
		headerNoTrace.getRequestHeaders() >> new MultivaluedHashMap<>()

		when:
		DeletePinResponse resp = deletePINRequestValidatorObj.deletePINRequestValidator(headerNoTrace, deletePINRequestObj)

		then:
		resp.appInfo == 'DeletePIN Request idp-trace-id is missing'
	}

	// ============================================================
	// Coverage: AgentId required for OPUS/CSRIDP callingSystemId (lines 196-198)
	// ============================================================

	def "deletePINRequestValidator returns error when AgentId missing for OPUS callingSystemId"() {
		given:
		deletePINRequestObj.callingSystemId = 'OPUS'
		deletePINRequestObj.identificationType = 'NONATTCTN'
		deletePINRequestObj.agentId = null

		when:
		DeletePinResponse resp = deletePINRequestValidatorObj.deletePINRequestValidator(requestHeader, deletePINRequestObj)

		then:
		resp.appInfo == 'AgentId is required'
	}

	// ============================================================
	// Coverage: idp-trace-id starts with AutoGen_ (lines 82-84)
	// ============================================================

	def "deletePINRequestValidator returns error when idp-trace-id starts with AutoGen_"() {
		given:
		MDC.remove('idp-trace-id')
		def headerAutoGen = Stub(HttpHeaders)
		headerAutoGen.getHeaderString('idp-trace-id') >> null
		headerAutoGen.getHeaderString('X-ATT-UniqueTransactionId') >> null
		headerAutoGen.getHeaderString('X-ATT-ClientId') >> 'IDP'
		MultivaluedHashMap autoGenHeaders = new MultivaluedHashMap<>()
		headerAutoGen.getRequestHeaders() >> autoGenHeaders

		when:
		DeletePinResponse resp = deletePINRequestValidatorObj.deletePINRequestValidator(headerAutoGen, deletePINRequestObj)

		then:
		resp.appInfo == 'DeletePIN Request idp-trace-id is missing'
	}

}
