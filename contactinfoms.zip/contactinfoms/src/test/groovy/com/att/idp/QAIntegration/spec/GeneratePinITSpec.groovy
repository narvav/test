package com.att.idp.QAIntegration.spec

import com.att.idp.QAIntegration.Base.TestBase
import com.att.idp.QAIntegration.Config.ContactInfoGlobalConfig
import com.att.idp.QAIntegration.Helpers.ContactInfoMsApiHelpers
import groovy.util.logging.Slf4j
import io.restassured.response.Response
import spock.lang.IgnoreIf
import spock.lang.Shared
import spock.lang.Tag
import spock.lang.Unroll

/**
 * QG7 Integration Test — IDGraphContactInfoMs Generate PIN
 *
 * Tests for POST /pin/generate endpoint with both positive and negative test cases.
 * YAML-driven: reads test data from QATestData/{ENV}/IDGraphContactInfoMs_TestData.yaml
 *
 * OMNI Compliance:
 * - Spec suffix: *ITSpec.groovy (testing-foundation.md E1)
 * - then: 0 * _ mandatory (HS-8)
 * - No mocks — real HTTP call to deployed service
 */
@Slf4j
@Tag("Regression")
@Tag("PIN")
@Tag("IDGraphContactInfoMs")
@IgnoreIf({ !ContactInfoGlobalConfig.isTestCaseEnabled("GeneratePinITSpec") })
class GeneratePinITSpec extends TestBase {

    @Shared
    Map testData = ContactInfoGlobalConfig.getTestData()

    @Shared
    List<Map> generatePinPositive = (testData?.get("generatePinPositive") as List<Map>) ?: []

    @Shared
    List<Map> generatePinNegative = (testData?.get("generatePinNegative") as List<Map>) ?: []

    // ═══════════════════════════════════════════════════════════════════════════
    // Generate PIN — Positive Tests
    // ═══════════════════════════════════════════════════════════════════════════

    @Unroll("Generate PIN Positive — #tc.testCaseName")
    def "Generate PIN — Positive Tests"() {
        setup:
        setTestName(tc.testCaseName as String)
        Map data = new LinkedHashMap<>(tc as Map)

        and: "Pre-cleanup: deleteAll existing PINs for this account"
        logStep("Pre-cleanup: deleteAll for accountId=${data.accountId} | type=${data.identificationType}")
        ContactInfoMsApiHelpers.deleteAllPins(data)

        when: "POST Generate PIN is called"
        logStep("POST ${ContactInfoGlobalConfig.Endpoints.GENERATE_PIN}")
        Response response = ContactInfoMsApiHelpers.generatePIN(data)

        then: "No mock interactions"
        0 * _

        and: "Response status matches expected (200 for positive cases)"
        int expectedStatus = (tc.expectedStatus ?: 200) as int
        assert response.statusCode() == expectedStatus :
                "Expected ${expectedStatus} but got ${response.statusCode()}. Body: ${response.body().asString().take(500)}"

        cleanup: "Delete PIN after test"
        if (response?.statusCode() == 200) {
            ContactInfoMsApiHelpers.deleteAllPins(data)
        }

        where:
        tc << generatePinPositive
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Generate PIN — Negative Tests
    // ═══════════════════════════════════════════════════════════════════════════

    @Unroll("Generate PIN Negative — #tc.testCaseName")
    def "Generate PIN — Negative Tests"() {
        setup:
        setTestName(tc.testCaseName as String)
        logStep("POST ${ContactInfoGlobalConfig.Endpoints.GENERATE_PIN} (expecting 400)")

        when: "POST Generate PIN is called with invalid data"
        Response response = ContactInfoMsApiHelpers.generatePIN(tc as Map)

        then: "No mock interactions"
        0 * _

        and: "Response status matches expected (400 for negative cases)"
        int expectedStatus = (tc.expectedStatus ?: 400) as int
        assert response.statusCode() == expectedStatus :
                "Expected ${expectedStatus} but got ${response.statusCode()}. Body: ${response.body().asString().take(500)}"

        where:
        tc << generatePinNegative
    }
}
