package com.att.idp.idgraphcontactinfoms.helpers

import com.att.idp.idgraphcontactinfoms.db.helper.SecurityCodeDBHelper
import com.att.idp.idgraphcontactinfoms.helpers.voltage.ProofingEncryptionHelper
import com.att.idp.idgraphcontactinfoms.helpers.voltage.VoltageEncryptionHelper
import com.att.idp.idgraphcontactinfoms.integration.MuleSoftRestClient
import com.att.idp.idgraphcontactinfoms.queue.message.sender.JMSQueueSender
import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.att.mpsys.common.utils.*
import com.sbc.cc.clarify.api.mps.message.GetAuthInfoRequest
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class LSCRMHelperTest extends Specification {

   def "buildGetAuthInfoRequest handles missing input keys gracefully"() {
        given:
        def helper = new LSCRMHelper()
        ReflectionTestUtils.setField(helper, "lscrmLoginName", "MPS_USER")
        ReflectionTestUtils.setField(helper, "lscrmApplicationId", "MPS")
        def input = [:]

        when:
        GetAuthInfoRequest result = helper.buildGetAuthInfoRequest(input)

        then:
        result != null
        result.ban == null
        result.requestHeader != null
        with(result.requestHeader) {
            sbcuid == "MPS_USER"
            applicationID == "MPS"
            clarifyUser != null
            with(clarifyUser) {
                loginName == "MPS_USER"
                password == "MPS_USER"
                channel == null
            }
        }
    }

    def "buildGetAuthInfoRequest handles input map with null values"() {
        given:
        def helper = new LSCRMHelper()
        ReflectionTestUtils.setField(helper, "lscrmLoginName", "MPS_USER")
        ReflectionTestUtils.setField(helper, "lscrmApplicationId", "MPS")
        def input = [
                "CALLING_SYSTEM_ID": null,
                "BAN": null
        ]

        when:
        GetAuthInfoRequest result = helper.buildGetAuthInfoRequest(input)

        then:
        result != null
        result.ban == null
        result.requestHeader != null
        with(result.requestHeader) {
            sbcuid == "MPS_USER"
            applicationID == "MPS"
            clarifyUser != null
            with(clarifyUser) {
                loginName == "MPS_USER"
                password == "MPS_USER"
                channel == null
            }
        }
    }
}
