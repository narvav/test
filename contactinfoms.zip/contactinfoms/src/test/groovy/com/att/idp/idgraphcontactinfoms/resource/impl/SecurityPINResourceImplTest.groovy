package com.att.idp.idgraphcontactinfoms.resource.impl

import com.att.idp.idgraphcontactinfoms.exceptions.InvalidInputDataException
import com.att.idp.idgraphcontactinfoms.request.validator.DeletePINRequestValidator
import com.att.idp.idgraphcontactinfoms.request.validator.GeneratePINRequestValidator
import com.att.idp.idgraphcontactinfoms.request.validator.InquirePINRequestValidator
import com.att.idp.idgraphcontactinfoms.request.validator.ValidatePINRequestValidator
import com.att.idp.idgraphcontactinfoms.resource.request.DeletePINRequest
import com.att.idp.idgraphcontactinfoms.resource.request.GeneratePINRequest
import com.att.idp.idgraphcontactinfoms.resource.request.InquirePINRequest
import com.att.idp.idgraphcontactinfoms.resource.request.ValidatePINRequest
import com.att.idp.idgraphcontactinfoms.resource.response.DeletePinResponse
import com.att.idp.idgraphcontactinfoms.resource.response.GeneratePINResponse
import com.att.idp.idgraphcontactinfoms.resource.response.InquirePINResponse
import com.att.idp.idgraphcontactinfoms.resource.response.ValidatePINResponse
import com.att.idp.idgraphcontactinfoms.service.DeletePINService
import com.att.idp.idgraphcontactinfoms.service.GeneratePINService
import com.att.idp.idgraphcontactinfoms.service.InquirePINService
import com.att.idp.idgraphcontactinfoms.service.ValidatePINService
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.Response

class SecurityPINResourceImplTest extends Specification {

	def securityPINResourceImplObj = new SecurityPINResourceImpl()

	def generatePINServiceObj = Mock(GeneratePINService)

	def generatePINRequestValidatorObj = Mock(GeneratePINRequestValidator)

	def deletePinServiceObj = Mock(DeletePINService)

	def deletePINRequestValidatorObj = Mock(DeletePINRequestValidator)

	def validatePINRequestValidatorObj = Mock(ValidatePINRequestValidator)

	def validatePINServiceObj = Mock(ValidatePINService)

	def inquirePINRequestValidatorObj = Mock(InquirePINRequestValidator)

	def inquirePINServiceObj = Mock(InquirePINService)

	def httpHeadersMock = Stub(HttpHeaders)

	def generatePINRequestMock = new GeneratePINRequest()

	def deletePINRequestMock = new DeletePINRequest()

	def validatePINRequestMock = new ValidatePINRequest()

	def inquirePINRequestMock = new InquirePINRequest()

	private GeneratePINResponse generatePinResponse = null
	private DeletePinResponse deletePinResponse = null
	private ValidatePINResponse validatePinResponse = null
	private InquirePINResponse inquirePinResponse = null

	def setup() throws Exception {
		securityPINResourceImplObj.generatePINService = generatePINServiceObj
		securityPINResourceImplObj.generatePINRequestValidator = generatePINRequestValidatorObj
		securityPINResourceImplObj.deletePinService = deletePinServiceObj
		securityPINResourceImplObj.deletePINRequestValidator = deletePINRequestValidatorObj
		securityPINResourceImplObj.validatePINService = validatePINServiceObj
		securityPINResourceImplObj.validatePINRequestValidator = validatePINRequestValidatorObj
		securityPINResourceImplObj.inquirePinService = inquirePINServiceObj
		securityPINResourceImplObj.inquirePINRequestValidator = inquirePINRequestValidatorObj
	}

	def "test generate p i n success"() throws Exception {
		given:
		generatePinResponse = new GeneratePINResponse()
		generatePinResponse.appCategoryCode = '0'
		generatePINRequestValidatorObj.generatePINRequestValidator(_ as HttpHeaders, _ as GeneratePINRequest) >> null
		generatePINServiceObj.generatePIN(_ as GeneratePINRequest,
				_) >> generatePinResponse
		when:
		Response response = securityPINResourceImplObj.generatePIN(generatePINRequestMock, httpHeadersMock)
		then:
		response.status == 200
	}


	def "test generate p i n error from req validator"() throws Exception {
		given:
		generatePinResponse = new GeneratePINResponse()
		generatePinResponse.appCategoryCode = '2'
		generatePINRequestValidatorObj.generatePINRequestValidator(_ as HttpHeaders,
				_ as GeneratePINRequest) >> generatePinResponse
		when:
		Response response = securityPINResourceImplObj.generatePIN(generatePINRequestMock, httpHeadersMock)
		then:
		response.status == 500
	}


	def "test generate p i n error from generate p i n service"() throws Exception {
		given:
		generatePinResponse = new GeneratePINResponse()
		generatePinResponse.appCategoryCode = '3'
		generatePINServiceObj.generatePIN(_ as GeneratePINRequest,
				_) >> generatePinResponse
		when:
		Response response = securityPINResourceImplObj.generatePIN(generatePINRequestMock, httpHeadersMock)
		then:
		response.status == 400
	}


	def "test generate p i n invalid input data exception"() throws Exception {
		given:
		InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
		generatePINServiceObj.generatePIN(_ as GeneratePINRequest,
				_) >> { throw ex }

		when:
		Response response = securityPINResourceImplObj.generatePIN(generatePINRequestMock, httpHeadersMock)

		then:
		thrown InvalidInputDataException
	}


	def "test generate p i n exception"() throws Exception {
		given:
		NullPointerException ex = new NullPointerException('NullPointerException thrown')
		generatePINServiceObj.generatePIN(_ as GeneratePINRequest,
				_) >> { throw ex }
		when:
		Response response = securityPINResourceImplObj.generatePIN(generatePINRequestMock, httpHeadersMock)
		then:
		response.status == 500
	}


	def "test delete p i n success"() throws Exception {
		given:
		deletePinResponse = new DeletePinResponse()
		deletePinResponse.appCategoryCode = '0'
		deletePINRequestValidatorObj.deletePINRequestValidator(_ as HttpHeaders, _ as DeletePINRequest) >> null
		deletePinServiceObj.deletePin(_ as DeletePINRequest,
				_) >> deletePinResponse
		when:
		Response response = securityPINResourceImplObj.deletePin(deletePINRequestMock, httpHeadersMock)
		then:
		response.status == 200
	}


	def "test delete p i n error from validator"() throws Exception {
		given:
		deletePinResponse = new DeletePinResponse()
		deletePinResponse.appCategoryCode = '2'
		deletePINRequestValidatorObj.deletePINRequestValidator(_ as HttpHeaders,
				_ as DeletePINRequest) >> deletePinResponse
		when:
		Response response = securityPINResourceImplObj.deletePin(deletePINRequestMock, httpHeadersMock)
		then:
		response.status == 500
	}


	def "test delete p i n error from service"() throws Exception {
		given:
		deletePinResponse = new DeletePinResponse()
		deletePinResponse.appCategoryCode = '3'
		deletePinServiceObj.deletePin(_ as DeletePINRequest,
				_) >> deletePinResponse
		when:
		Response response = securityPINResourceImplObj.deletePin(deletePINRequestMock, httpHeadersMock)
		then:
		response.status == 400
	}


	def "test delete p i n invalid input data exception"() throws Exception {
		given:
		InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
		deletePinServiceObj.deletePin(_ as DeletePINRequest,
				_) >> { throw ex }

		when:
		Response response = securityPINResourceImplObj.deletePin(deletePINRequestMock, httpHeadersMock)

		then:
		thrown InvalidInputDataException
	}


	def "test delete p i n exception"() throws Exception {
		given:
		deletePINRequestMock.getTransactionName() >> 'DeletePIN'
		NullPointerException ex = new NullPointerException('NullPointerException thrown')
		deletePinServiceObj.deletePin(_ as DeletePINRequest,
				_) >> { throw ex }
		when:
		Response response = securityPINResourceImplObj.deletePin(deletePINRequestMock, httpHeadersMock)
		then:
		response.status == 500
	}


	def "test validate p i n success"() throws Exception {
		given:
		validatePinResponse = new ValidatePINResponse()
		validatePinResponse.appCategoryCode = '0'
		validatePINRequestValidatorObj.validatePINRequestValidator(_ as HttpHeaders,
				_ as ValidatePINRequest) >> null
		validatePINServiceObj.validatePIN(_ as ValidatePINRequest,
				_) >> validatePinResponse
		when:
		Response response = securityPINResourceImplObj.validatePIN(validatePINRequestMock, httpHeadersMock)
		then:
		response.status == 200
	}


	def "test validate p i n error from validator"() throws Exception {
		given:
		validatePinResponse = new ValidatePINResponse()
		validatePinResponse.appCategoryCode = '2'
		validatePINRequestValidatorObj.validatePINRequestValidator(_ as HttpHeaders,
				_ as ValidatePINRequest) >> validatePinResponse
		when:
		Response response = securityPINResourceImplObj.validatePIN(validatePINRequestMock, httpHeadersMock)
		then:
		response.status == 500
	}


	def "test validate p i n error from service"() throws Exception {
		given:
		validatePinResponse = new ValidatePINResponse()
		validatePinResponse.appCategoryCode = '3'
		validatePINServiceObj.validatePIN(_ as ValidatePINRequest,
				_) >> validatePinResponse
		when:
		Response response = securityPINResourceImplObj.validatePIN(validatePINRequestMock, httpHeadersMock)
		then:
		response.status == 400
	}


	def "test validate p i n invalid input data exception"() throws Exception {
		given:
		InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
		validatePINServiceObj.validatePIN(_ as ValidatePINRequest,
				_) >> { throw ex }

		when:
		Response response = securityPINResourceImplObj.validatePIN(validatePINRequestMock, httpHeadersMock)

		then:
		thrown InvalidInputDataException
	}


	def "test validate p i n exception"() throws Exception {
		given:
		validatePINRequestMock.getTransactionName() >> 'ValidatePIN'
		NullPointerException ex = new NullPointerException('NullPointerException thrown')
		validatePINServiceObj.validatePIN(_ as ValidatePINRequest,
				_) >> { throw ex }
		when:
		Response response = securityPINResourceImplObj.validatePIN(validatePINRequestMock, httpHeadersMock)
		then:
		response.status == 500
	}

	def "test inquire p i n success"() throws Exception {
		given:
		inquirePinResponse = new InquirePINResponse()
		inquirePinResponse.appCategoryCode = '0'
		inquirePINRequestValidatorObj.inquirePINRequestValidator(_ as HttpHeaders,
				_ as InquirePINRequest) >> null
		inquirePINServiceObj.inquirePIN(_ as InquirePINRequest,
				_) >> inquirePinResponse
		when:
		Response response = securityPINResourceImplObj.inquirePin(inquirePINRequestMock, httpHeadersMock)
		then:
		response.status == 200
	}


	def "test inquire p i n error from validator"() throws Exception {
		given:
		inquirePinResponse = new InquirePINResponse()
		inquirePinResponse.appCategoryCode = '2'
		inquirePINRequestValidatorObj.inquirePINRequestValidator(_ as HttpHeaders,
				_ as InquirePINRequest) >> inquirePinResponse
		when:
		Response response = securityPINResourceImplObj.inquirePin(inquirePINRequestMock, httpHeadersMock)
		then:
		response.status == 500
	}


	def "test inquire p i n error from service"() throws Exception {
		given:
		inquirePinResponse = new InquirePINResponse()
		inquirePinResponse.appCategoryCode = '3'
		inquirePINServiceObj.inquirePIN(_ as InquirePINRequest,
				_) >> inquirePinResponse
		when:
		Response response = securityPINResourceImplObj.inquirePin(inquirePINRequestMock, httpHeadersMock)
		then:
		response.status == 400
	}


	def "test inquire p i n invalid input data exception"() throws Exception {
		given:
		InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
		inquirePINServiceObj.inquirePIN(_ as InquirePINRequest,
				_) >> { throw ex }

		when:
		Response response = securityPINResourceImplObj.inquirePin(inquirePINRequestMock, httpHeadersMock)

		then:
		thrown InvalidInputDataException
	}


	def "test inquire p i n exception"() throws Exception {
		given:
		inquirePINRequestMock.getTransactionName() >> 'InquirePIN'
		NullPointerException ex = new NullPointerException('NullPointerException thrown')
		inquirePINServiceObj.inquirePIN(_ as InquirePINRequest,
				_) >> { throw ex }
		when:
		Response response = securityPINResourceImplObj.inquirePin(inquirePINRequestMock, httpHeadersMock)
		then:
		response.status == 500
	}
	
}
