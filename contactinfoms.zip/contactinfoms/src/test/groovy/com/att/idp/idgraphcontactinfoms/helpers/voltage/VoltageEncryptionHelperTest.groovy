package com.att.idp.idgraphcontactinfoms.helpers.voltage


import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class VoltageEncryptionHelperTest extends Specification {

	def voltageEncryption_H = new VoltageEncryptionHelper()

	def voltageHelper = Mock(VoltageEncryptDecryptHelper)

	static HashMap<String, Object> hmInput = null

	public static final Logger logger = LoggerFactory.getLogger(VoltageEncryptionHelper.class)

	/*@Test
	public void setup() {
		System.setProperty("CommonConfigurationFilePath", "./opt/ajsc/etc/config/CommonConfigurationTest.xml");
		VoltageEncryption_H voltageEncryption_HObj = new VoltageEncryption_H();
	}*/


	def setupSpec() {
		System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')
	}


	def setup()
	{
		voltageEncryption_H.voltageHelper = voltageHelper
		hmInput = new HashMap<String, Object>()

		ReflectionTestUtils.setField(voltageEncryption_H, 'propVoltageEncryptionFields', 'passcode|wsPasscode|securityAnswer|wsSecurityAnswer|security_answer|dateOfBirth|birthdate_venc|security_answer_venc|passcode_venc|dsl_net_password|issuser_password|wirelineuser_passcode|securitycode_passcode|md5_password_venc|enc_password_venc|sha1_password_venc|des3_password_venc|ssha_password_venc|security_answer_1_venc|security_answer_2_venc|generatedPassword|dialEnrollPassword|yahoo_app_pwd|gen_password_venc')
		ReflectionTestUtils.setField(voltageEncryption_H, 'propVoltageDecryptionFields', 'birthdate_venc|security_answer_venc|passcode_venc|password_venc|dsl_net_password|md5_password_venc|enc_password_venc|sha1_password_venc|des3_password_venc|ssha_password_venc|security_answer_1_venc|security_answer_2_venc|gen_password_venc')
		ReflectionTestUtils.setField(voltageEncryption_H, 'propVoltagePCIEncryptionFields', 'ccNumber')
		ReflectionTestUtils.setField(voltageEncryption_H, 'propVoltagePCIDecryptionFields', '')
		ReflectionTestUtils.setField(voltageEncryption_H, 'propVoltageSSNEncryptionFields', '')
		ReflectionTestUtils.setField(voltageEncryption_H, 'propVoltageSSNDecryptionFields', 'fedTaxId')
		ReflectionTestUtils.setField(voltageEncryption_H, 'propVoltageGenStrEncryptionFields', '')
		ReflectionTestUtils.setField(voltageEncryption_H, 'propVoltageGenStrDecryptionFields', '')
	}


	def "testget efpe encrypted values voltage encryption fields success"()
	{
		given:
		hmInput['passcode'] = '67365'
		when:
		HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEEncryptedValues(hmInput)
		then:
		hmResult['appStatusMsg'] == 'SUCCESS'
	}


	def "testget efpe encrypted values voltage pci encryption fields success"()
	{
		given:
		hmInput['ccNumber'] = '567987'
		when:
		HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEEncryptedValues(hmInput)
		then:
		hmResult['appStatusMsg'] == 'SUCCESS'

	}


	def "testget efpe encrypted values voltage gen str encryption fields success"()
	{
		given:
		hmInput['CBR'] = 'r6279'
		when:
		HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEEncryptedValues(hmInput)
		then:
		hmResult['appStatusMsg'] == 'SUCCESS'

	}

	def "testget efpe encrypted values success"()
	{
		given:
		hmInput['fedTaxId'] = 'trma6fg9'
		when:
		HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEEncryptedValues(hmInput)
		then:
		hmResult['appStatusMsg'] == 'SUCCESS'

	}


	def "testget efpe encrypted values exception"()
	{
		given:
		hmInput['passcode'] = '67365'
		voltageHelper.getEncryptedValue(_ as String, _ as String) >> { throw new NullPointerException() }
		when:
		HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEEncryptedValues(hmInput)
		then:
		hmResult['appInfo'] == 'SYSTEM ERROR'
	}


	def "testget efpe decrypted values voltage decryption fields success"()
	{
		given:
		hmInput['birthdate_venc'] = '$%6667565654R'
		when:
		HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEDecryptedValues(hmInput)
		then:
		hmResult['appStatusMsg'] == 'SUCCESS'
	}


	def "testget efpe decrypted values voltage ssn decryption fields success"()
	{
		given:
		hmInput['fedTaxId'] = 'trma6f99'
		when:
		HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEDecryptedValues(hmInput)
		then:
		hmResult['appStatusMsg'] == 'SUCCESS'
	}


	def "testget efpe decrypted values voltage gen str decryption fields success"()
	{
		given:
		hmInput['CBR'] = '6fg&^$#%9'
		when:
		HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEDecryptedValues(hmInput)
		then:
		hmResult['appStatusMsg'] == 'SUCCESS'
	}


	def "testget efpe decrypted values success"()
	{
		given:
		hmInput['passcode'] = '673^&96&65'
		when:
		HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEDecryptedValues(hmInput)
		then:
		hmResult['appStatusMsg'] == 'SUCCESS'
	}


	def "testget efpe decrypted values exception"()
	{
		given:
		hmInput['birthdate_venc'] = '6%#873GVD%^65'
		voltageHelper.getDecryptedValue(_ as String, _ as String) >> { throw new NullPointerException() }
		when:
		HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEDecryptedValues(hmInput)
		then:
		hmResult['appInfo'] == 'SYSTEM ERROR'
	}


	def "testget efpe decrypted values when prop fields not present1"()
	{
		given:
		ReflectionTestUtils.setField(voltageEncryption_H, 'propVoltageDecryptionFields', '')
		hmInput['birthdate_venc'] = '6%#873GVD%^65'
		//when(voltageHelper.getDecryptedValue(Mockito.anyString(),Mockito.anyString())).thenThrow(NullPointerException.class);
		when:
		HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEDecryptedValues(hmInput)
		then:
		hmResult != null
		hmResult['appInfo'] == 'Missing or empty config parameter - VOLTAGE_DECRYPTED_FIELDS'

	}


	def "testget efpe decrypted values when prop fields not present2"()
	{
		given:
		ReflectionTestUtils.setField(voltageEncryption_H, 'propVoltageSSNDecryptionFields', '')
		hmInput['birthdate_venc'] = '6%#873GVD%^65'
		when:
		HashMap<String, Object> hmResult = voltageEncryption_H.getEFPEDecryptedValues(hmInput)
		then:
		hmResult != null
		hmResult['appInfo'] == 'Missing or empty config parameter - VOLTAGE_SSN_DECRYPTED_FIELDS'
	}
}
