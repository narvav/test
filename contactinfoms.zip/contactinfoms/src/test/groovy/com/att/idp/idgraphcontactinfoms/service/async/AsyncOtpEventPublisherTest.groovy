package com.att.idp.idgraphcontactinfoms.service.async

import com.att.idp.idgraphcontactinfoms.model.EventData
import spock.lang.Specification

class AsyncOtpEventPublisherTest extends Specification {

    AsyncOtpEventPublisher publisher
    OracleSecurityCodeSyncPublisher syncPublisher = Mock(OracleSecurityCodeSyncPublisher)

    def setup() {
        publisher = new AsyncOtpEventPublisher()
        publisher.oracleSecurityCodeSyncPublisher = syncPublisher
    }

    def "publishDeletePinEvent calls syncPublisher with DELETE event type"() {
        given:
        EventData eventData = new EventData()
        eventData.setAccountId("acc123")

        when:
        publisher.publishDeletePinEvent("acc123", eventData)

        then:
        1 * syncPublisher.publish("acc123", OracleSecurityCodeSyncPublisher.EVENT_TYPE_DELETE, eventData, "DeletePIN")
        0 * _
    }

    def "publishDeletePinEvent catches exception without propagating"() {
        given:
        EventData eventData = new EventData()
        syncPublisher.publish(_, _, _, _) >> { throw new RuntimeException("Kafka unavailable") }

        when:
        publisher.publishDeletePinEvent("acc123", eventData)

        then:
        notThrown(RuntimeException)
    }

    def "publishValidatePinEvent calls syncPublisher with UPDATE event type"() {
        given:
        EventData eventData = new EventData()
        eventData.setAccountId("acc456")

        when:
        publisher.publishValidatePinEvent("acc456", eventData)

        then:
        1 * syncPublisher.publish("acc456", OracleSecurityCodeSyncPublisher.EVENT_TYPE_UPDATE, eventData, "ValidatePIN")
        0 * _
    }

    def "publishValidatePinEvent catches exception without propagating"() {
        given:
        EventData eventData = new EventData()
        syncPublisher.publish(_, _, _, _) >> { throw new RuntimeException("Connection timeout") }

        when:
        publisher.publishValidatePinEvent("acc456", eventData)

        then:
        notThrown(RuntimeException)
    }

    def "publishGeneratePinEvent calls syncPublisher with provided event type"() {
        given:
        EventData eventData = new EventData()
        eventData.setAccountId("acc789")

        when:
        publisher.publishGeneratePinEvent("acc789", eventType, eventData)

        then:
        1 * syncPublisher.publish("acc789", eventType, eventData, "generatePin")
        0 * _

        where:
        eventType << [OracleSecurityCodeSyncPublisher.EVENT_TYPE_INSERT, OracleSecurityCodeSyncPublisher.EVENT_TYPE_UPDATE]
    }

    def "publishGeneratePinEvent catches exception without propagating"() {
        given:
        EventData eventData = new EventData()
        syncPublisher.publish(_, _, _, _) >> { throw new RuntimeException("Broker down") }

        when:
        publisher.publishGeneratePinEvent("acc789", "INSERT", eventData)

        then:
        notThrown(RuntimeException)
    }
}
