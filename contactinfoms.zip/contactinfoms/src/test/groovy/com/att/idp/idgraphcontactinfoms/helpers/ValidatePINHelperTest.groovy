package com.att.idp.idgraphcontactinfoms.helpers

import com.att.idp.cgclienthelpers.integration.CGRestClient
import com.att.idp.idgraph.db.cosmos.helper.IdgOtpDBHelper
import com.att.idp.idgraph.db.cosmos.helper.OtpHistoryDBHelper
import java.util.concurrent.Executor
import com.att.idp.idgraphcontactinfoms.db.helper.ValidatePinInfoBean
import com.att.idp.idgraphcontactinfoms.db.helper.CosmosDataStore
import com.att.idp.idgraphcontactinfoms.db.helper.SecurityCodeDBHelper
import com.att.idp.idgraphcontactinfoms.helpers.voltage.ProofingEncryptionHelper
import com.att.idp.idgraphcontactinfoms.metrics.ErrorMetricHandler
import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.MPSDefs
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper
import com.att.mpsys.common.utils.RILDefs
import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ArrayNode
import org.jboss.logging.MDC
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import spock.lang.Unroll
import com.att.idp.idgraphcontactinfoms.utils.ProfileOrchestrationConstants
import com.att.idp.cgclienthelpers.integration.CGApiRestClient
import com.att.idp.cgclienthelpers.utils.CGUtilHelper
import com.att.idp.dpl.profile.bsse.customerv4.CustomerV4Response
import com.att.idp.dpl.profile.bsse.customerv4.Individual
import com.att.idp.dpl.profile.bsse.customerv4.Account
import com.att.idp.dpl.profile.bsse.customerv4.Subscriber
import com.att.idp.core.exception.ServiceException
import com.att.idp.idgraphcontactinfoms.message.ErrorMessages

import java.security.MessageDigest
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class ValidatePINHelperTest extends Specification {

    def ValidatePINHelper validatePINHelperObj
    ProofingEncryptionHelper proofingEncryptionHelper = Mock(ProofingEncryptionHelper)
    SecurityCodeDBHelper securityCodeDBHelperObj = Mock(SecurityCodeDBHelper)
    DeletePINHelper objDeletePINHelper = Mock(DeletePINHelper)
    CGRestClient cgRestClient = Mock(CGRestClient)
    CGHelper cgHelper = Spy(CGHelper)
    FeatureManagerHelper featureManager = Mock(FeatureManagerHelper)
    IdgOtpDBHelper idgOtpDBHelper = Mock(IdgOtpDBHelper)
    HashMap hmInput = null
    HashMap hmResponse = null
    String stAppInfo = null
    String stAppStatusMsg = null
    Logger logger = null
    HashMap hmDBInput = null
    HashMap<String, Object> hmSecurityCodeResp = null
    ArrayList alSecurityCodeData = new ArrayList<>()

    CosmosDataStore cosmosDataStore = Mock(CosmosDataStore)
    CGApiRestClient cgApiRestClient = Mock(CGApiRestClient)
    CGUtilHelper cgUtilHelper = Mock(CGUtilHelper)
    def errMetricHandler = Mock(ErrorMetricHandler)
    OtpHistoryDBHelper otpHistoryDBHelper = Mock(OtpHistoryDBHelper)
    Executor otpHistoryExecutor = { Runnable r -> r.run() } as Executor

    def setup() throws Exception {
        validatePINHelperObj = new ValidatePINHelper(otpHistoryDBHelper, otpHistoryExecutor)
        validatePINHelperObj.proofingEncryptionHelper = proofingEncryptionHelper
        validatePINHelperObj.securityCodeDBHelperObj = securityCodeDBHelperObj
        validatePINHelperObj.objDeletePINHelper = objDeletePINHelper
        validatePINHelperObj.errorMetricHandler = errMetricHandler
        ReflectionTestUtils.setField(cgHelper, "cgRestClient", cgRestClient)
        validatePINHelperObj.cgHelper = cgHelper
        validatePINHelperObj.featureManager = featureManager
        validatePINHelperObj.idgOtpDBHelper = idgOtpDBHelper
        validatePINHelperObj.cgApiRestClient = cgApiRestClient
        validatePINHelperObj.cgUtilHelper = cgUtilHelper

        // Mocking the CosmosDataStore methods
        cosmosDataStore.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeResp


        logger = LoggerFactory.getLogger('DeletePIN')
        logger = LoggerFactory.getLogger('DeletePIN')
        MDC.put('transid', 'test123')
        System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')

        hmSecurityCodeResp = new HashMap()
        hmInput = new HashMap()
        hmInput['transactionName'] = 'ValidatePIN'
        hmInput['callingSystemId'] = 'DATAMGT'
        hmInput['accountId'] = '000981453456'
        hmInput['identificationType'] = 'IDSEMOB'
        hmInput['securityCode'] = '1990122'
        hmInput['deletePINOnSuccess'] = 'Yes'
        hmInput['agentId'] = '1234'
        hmInput['sourceIPAddress'] = '10.12.13.223'
        hmInput['transactionId'] = 'test1234'

        MDC.put('transid', 'test123')
        System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')

        ReflectionTestUtils.setField(validatePINHelperObj, 'propValidPINCSI', 'IDSEMOB:IDP|DATAMGT,BANPCS:OPUS|IDP|CSRIDP,BANPCE:OPUS,BANPTONLS:MYATTSALES|IDP|UPPERFUNNEL|ANDIVA,BANPTONLE:MYATTSALES|IDP|ANDIVA,DTVNOWOTP:CSRIDP,CTNKSK:EXPKSK,BTN:IDP|DATAMGT,PINVALID:IDP|CSRIDP,NONATTCTN:IDP|CSRIDP|OPUS,ATTCTN:IDP|CSRIDP,EMAILOTP:IDP|OPUS,CRICKETOTP:IDP|CSRIDP|OPUS,EMAILPIN:IDP|CSRIDP|OPUS|ERICSSON|MYATTSALES|IDPSALES|MULESOFT|MYATTMOBILE,CTNDIH:IDP|CSRIDP|OPUS,BANAP:PENNYVA,TITANIMD:IDP|CSRIDP,CTN:IDP|CSRIDP,WBAN:IDP|CSRIDP,ECOMMSEC:IDP|CSRIDP,WBANSEC:IDP|CSRIDP,TITANSEC:IDP|CSRIDP,DTVOTP:DIRECTV,CTNAUTH:MULESOFT,CTNOPR:IDP|CSRIDP,ENCPIN:IDPSALES,PORTOUT:AVERTACK,CCPADTV:IDP,BSSEOTP:IDP|MULESOFT|IVR,BSSEONL:IDP,BSSEREGOTP:IDP')
        ReflectionTestUtils.setField(validatePINHelperObj, 'propValidAgentCSI', 'OPUS|CSRIDP')
        ReflectionTestUtils.setField(validatePINHelperObj, 'propUnlockPeriodMins', 'IDSEMOB:1440|BANPCS:120|BANPCE:120|BANPTONLS:120|BANPTONLE:120|DTVNOWOTP:60|CTNKSK:120|BTN:43200|PINVALID:120|NONATTCTN:60|ATTCTN:60|EMAILOTP:60|CRICKETOTP:60|EMAILPIN:60|CTNDIH:60|BANAP:1440|TITANIMD:43200|CTN:43200|WBAN:43200|ECOMMSEC:43200|WBANSEC:43200|TITANSEC:43200|DTVOTP:60|CTNAUTH:60|CTNOPR:1440|ENCPIN:43200|PORTOUT:5760|CCPADTV:60|BSSEOTP:60|BSSEONL:60|BSSEREGOTP:60|AUTHUSER:120|NTRETAILER:60|ESIMOTP:60|GENERICOTP:60|PORTOUTABS:20160|PORTOUTBSS:4320|BANPC:1440|REGIMPROVE:60|APPTSCHED:1440|BANCRU:1440|BANPT:1440|BANPTONL:1440|CALLFWD:60|PORTOUTPP:5760|SMBYIELD:60')
        ReflectionTestUtils.setField(validatePINHelperObj, 'propPINMaxFailureCnt', 'IDSEMOB:5|BANPCS:5|BANPCE:5|BANPTONLS:5|BANPTONLE:5|DTVNOWOTP:5|CTNKSK:5|BTN:5|PINVALID:5|NONATTCTN:5|ATTCTN:5|EMAILOTP:5|CRICKETOTP:5|EMAILPIN:5|CTNDIH:5|BANAP:5|TITANIMD:5|CTN:5|WBAN:5|ECOMMSEC:5|WBANSEC:5|TITANSEC:5|DTVOTP:5|CTNAUTH:5|CTNOPR:5|ENCPIN:5|PORTOUT:50|CCPADTV:5|BSSEOTP:5|BSSEONL:5|BSSEREGOTP:5')
        ReflectionTestUtils.setField(validatePINHelperObj, 'propPinMaxPins', 'IDSEMOB:10|BANPCS:10|BANPCE:10|BANPTONLS:10|BANPTONLE:10|DTVNOWOTP:5|CTNKSK:10|BTN:10|PINVALID:10|NONATTCTN:10|ATTCTN:10|EMAILOTP:10|CRICKETOTP:10|EMAILPIN:10|CTNDIH:5|BANAP:10|TITANIMD:10|CTN:10|WBAN:10|ECOMMSEC:10|WBANSEC:10|TITANSEC:10|DTVOTP:10|CTNAUTH:10|CTNOPR:5|ENCPIN:10|PORTOUT:5|CCPADTV:10|BSSEOTP:10|BSSEONL:10|BSSEREGOTP:10')
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', 'IDSEMOB|BANPCS|BANPCE|BANPTONLS|BANPTONLE|ATTCTN|CTNDIH|BANAP')
        ReflectionTestUtils.setField(validatePINHelperObj, 'propCTNActiveDays', '1')
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMActiveDays', '2')
        ReflectionTestUtils.setField(validatePINHelperObj, 'propReuseIdentificationTypes', 'PUK')
        ReflectionTestUtils.setField(validatePINHelperObj, 'cosmosDataStore', cosmosDataStore)
        ReflectionTestUtils.setField(validatePINHelperObj, 'propCosmosUpdateCSI', 'OPUS|CCMULE')
        ReflectionTestUtils.setField(validatePINHelperObj, 'propOtpUnlockAccountMinutes', 'BSSEGENS:360|BSSEGENE:360')

        CommonUtilHelper.metaClass.'static'.generateGenericPassword = { HashMap passwordParameters, String genericPasswordEncryptionType ->
            [(RILDefs.RIL_GEN_PASSWORD): 'SHA256_ENC']
        }

    }


    def cleanup() throws Exception {
        MDC.remove('transid')
        GroovySystem.metaClassRegistry.removeMetaClass(CommonUtilHelper)
    }

    @Unroll
    def "should return invalid data when mandatory field is null for #scenarioName"() {
        given: "Input map with one mandatory field set to null"
        Map<String, Object> hmInput = new HashMap<>()
        hmInput.put(CommonDefs.TRANSACTION_NAME, transactionName)
        hmInput.put(CommonDefs.CALLING_SYSTEM_ID, callingSystemId)
        hmInput.put(CommonDefs.ACCOUNT_ID, accountId)
        hmInput.put(CommonDefs.IDENTIFICATION_TYPE, identificationType)
        hmInput.put(CommonDefs.SECURITY_CODE, securityCode)
        hmInput.put(CommonDefs.DELETE_PIN_ON_SUCCESS, deletePinOnSuccess)

        when: "validatePIN is invoked"
        HashMap<String, Object> result = validatePINHelperObj.validatePIN(hmInput)

        then: "No external dependencies are called"
        0 * securityCodeDBHelperObj._
        0 * objDeletePINHelper._
        0 * idgOtpDBHelper._
        0 * cosmosDataStore._
        0 * proofingEncryptionHelper._
        0 * featureManager._
        0 * errMetricHandler._
        0 * cgHelper._
        0 * _

        and: "Result indicates invalid data error with expected info message"
        result != null
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) == CErrorDefs.CATEGORY_CODE_DATA_ERROR
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CErrorDefs.ERR_INVALID_DATA_MSG
        result.get(CommonDefs.COMMON_APP_INFO) == stAppInfoExpected

        where: "Each mandatory field is null in turn"
        scenarioName                | transactionName | callingSystemId | accountId | identificationType | securityCode | deletePinOnSuccess | stAppInfoExpected
        "null transaction name"     | null            | "SYS1"          | "acct1"   | "IDTYPE"           | "1234"       | "Y"                | "Either of the parameters TransactionName|CallingSystemId|AccountId|IdentificationType|SecurityCode|DeletePINOnSuccess is null"
        "null calling system id"    | "TXN"           | null            | "acct1"   | "IDTYPE"           | "1234"       | "Y"                | "Either of the parameters TransactionName|CallingSystemId|AccountId|IdentificationType|SecurityCode|DeletePINOnSuccess is null"
        "null account id"           | "TXN"           | "SYS1"          | null      | "IDTYPE"           | "1234"       | "Y"                | "Either of the parameters TransactionName|CallingSystemId|AccountId|IdentificationType|SecurityCode|DeletePINOnSuccess is null"
        "null identification type"  | "TXN"           | "SYS1"          | "acct1"   | null               | "1234"       | "Y"                | "Either of the parameters TransactionName|CallingSystemId|AccountId|IdentificationType|SecurityCode|DeletePINOnSuccess is null"
        "null security code"        | "TXN"           | "SYS1"          | "acct1"   | "IDTYPE"           | null         | "Y"                | "Either of the parameters TransactionName|CallingSystemId|AccountId|IdentificationType|SecurityCode|DeletePINOnSuccess is null"
        "null delete PIN on success"| "TXN"           | "SYS1"          | "acct1"   | "IDTYPE"           | "1234"       | null               | "Either of the parameters TransactionName|CallingSystemId|AccountId|IdentificationType|SecurityCode|DeletePINOnSuccess is null"
    }


    def "test validate p i n security code failure"() throws Exception {

        // when security code response is recode not found
        given:
        featureManager.isEnabled(_ as String)>>false
        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> 'ORACLEMASTER'
        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.ERR_REC_NOT_FOUND
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap)>>hmSecurityCodeResp
        when:
        hmResponse = validatePINHelperObj.validatePIN(hmInput)
        then:
        hmResponse != null
        hmResponse['appInfo'] == 'No record found in DB.'
        hmResponse[CommonDefs.REMAINING_CODES] != null

        // when security code call fails
        when:
        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = 'Error'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap)>>hmSecurityCodeResp
        hmResponse = validatePINHelperObj.validatePIN(hmInput)
        then:
        hmResponse != null

    }


    def "test validate p i n security code"() throws Exception {

        // TODO once cg calls done, need to rework

        // populating SecurityCodeData arrayList, when delivery method is S
        given:
        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '5'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        alSecurityCodeData.add(hmDBSecurityCode)

        proofingEncryptionHelper.generateSHA1Value(_ as String)>>'1990122'

        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeResp[MPSDefs.SECURITY_CODE_INFO] = alSecurityCodeData
        cgRestClient.getCGSyncCall(_ as HashMap)>>null

        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap)>>hmSecurityCodeResp
        when:
        hmResponse = validatePINHelperObj.validatePIN(hmInput)
        then:
        hmResponse != null
        //assertEquals("Response from RestServiceHelper.call() is null or empty", hmResponse.get("appInfo"));
    }

    def "should return ERR_SIM_NOT_YET_ELIGIBLE when CG simSwapDate is recent and differs from account createdOn"() {
        given:
        featureManager.getValue(_ as String) >> "ORACLEMASTER"

        String today = LocalDate.now(ZoneId.of("GMT")).toString()
        HashMap<String, Object> hmSyncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        ObjectMapper map = new ObjectMapper()
        JsonNode subscriberNode = map.readTree('{"simSwapDate":"' + today + 'T00:00:00Z"}')
        ArrayNode subscribersArray = map.valueToTree([subscriberNode])
        hmSyncResp['subscribers'] = subscribersArray
        hmSyncResp['accounts'] = ['createdOn': '2020-01-01 00:00:00']

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        ArrayList alSecurityCodeDataLocal = new ArrayList<>()
        alSecurityCodeDataLocal.add(hmDBSecurityCode)
        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = alSecurityCodeDataLocal
        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        cgHelper.makeCGSyncCall(_, _) >> hmSyncResp

        // update failure count paths invoked when response is not success
        securityCodeDBHelperObj.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >>
                CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        securityCodeDBHelperObj.updateSecurityAccount(_ as HashMap, false) >>
                CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        idgOtpDBHelper.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >>
                CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        idgOtpDBHelper.updateSecurityAccount(_ as HashMap) >>
                CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        when:
        def resp = validatePINHelperObj.validatePIN(new HashMap(hmInput))

        then:
        resp != null
        resp[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.ERR_SIM_NOT_YET_ELIGIBLE
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == CErrorDefs.ERR_SIM_NOT_YET_ELIGIBLE_MSG
    }

    def "should return ERR_EXTERNAL_SYS when CG account createdOn is null and SIM swap date is recent (V2 flow)"() {
        given: "CG sync response with a recent simSwapDate but no account createdOn"
        featureManager.getValue(_ as String) >> "ORACLEMASTER"

        String today = LocalDate.now(ZoneId.of("GMT")).toString()
        HashMap<String, Object> hmSyncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        ObjectMapper map = new ObjectMapper()
        JsonNode subscriberNode = map.readTree('{"simSwapDate":"' + today + 'T00:00:00Z"}')
        ArrayNode subscribersArray = map.valueToTree([subscriberNode])
        hmSyncResp['subscribers'] = subscribersArray
        // No 'accounts' entry => accountCreatedOn resolves to null

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        ArrayList alSecurityCodeDataLocal = new ArrayList<>()
        alSecurityCodeDataLocal.add(hmDBSecurityCode)
        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = alSecurityCodeDataLocal
        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        cgHelper.makeCGSyncCall(_, _) >> hmSyncResp

        when: "validatePIN is invoked"
        def resp = validatePINHelperObj.validatePIN(new HashMap(hmInput))

        then: "response is ERR_EXTERNAL_SYS with a createdOn-null appInfo message"
        resp != null
        resp[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.ERR_EXTERNAL_SYS
        resp[CommonDefs.COMMON_APP_INFO] == 'createdOn value is null for CTN :: 9899545'
    }

    def "test validate p i n security code for cosmosdb update"() throws Exception {

        // TODO once cg calls done, need to rework

        // populating SecurityCodeData arrayList, when delivery method is S
        given:
        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '5'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        hmInput['callingSystemId'] = 'CCMULE'
        hmInput['accountType'] = 'WIRELESS'

        alSecurityCodeData.add(hmDBSecurityCode)

        proofingEncryptionHelper.generateSHA1Value(_ as String)>>'1990122'

        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeResp[MPSDefs.SECURITY_CODE_INFO] = alSecurityCodeData
        cgRestClient.getCGSyncCall(_ as HashMap)>>null

        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap)>>hmSecurityCodeResp
        when:
        hmResponse = validatePINHelperObj.validatePIN(hmInput)
        then:
        hmResponse != null
        //assertEquals("Response from RestServiceHelper.call() is null or empty", hmResponse.get("appInfo"));
    }

    def "test checkAging with valid inputs"() {
        given:
        String sAgingFieldDate = agingFieldDate
        String sNumOfDays = numOfDays
        String sDateFormat = dateFormat

        when:
        boolean result = validatePINHelperObj.checkAging(sAgingFieldDate, sNumOfDays, sDateFormat)

        then:
        result == expectedResult

        where:
        agingFieldDate | numOfDays | dateFormat   || expectedResult
        "2023-01-01"   | "30"      | "yyyy-MM-dd" || true
        "2023-01-01"   | "365"     | "yyyy-MM-dd" || true
        "2023-01-01"   | "0"       | "yyyy-MM-dd" || true
    }

    def "test checkAging with null date"() {
        given:
        String sAgingFieldDate = null
        String sNumOfDays = "30"
        String sDateFormat = "yyyy-MM-dd"

        when:
        boolean result = validatePINHelperObj.checkAging(sAgingFieldDate, sNumOfDays, sDateFormat)

        then:
        result == false
    }

    def "test checkAging with empty date"() {
        given:
        String sAgingFieldDate = ""
        String sNumOfDays = "30"
        String sDateFormat = "yyyy-MM-dd"

        when:
        boolean result = validatePINHelperObj.checkAging(sAgingFieldDate, sNumOfDays, sDateFormat)

        then:
        result == false
    }

    def "test checkAging with exception"() {
        given:
        String sAgingFieldDate = "invalid-date"
        String sNumOfDays = "30"
        String sDateFormat = "yyyy-MM-dd"

        when:
        boolean result = validatePINHelperObj.checkAging(sAgingFieldDate, sNumOfDays, sDateFormat)

        then:
        result == false
    }


    def "test validate p i n security code error timeout"() throws Exception {

        given:
        HashMap resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_TRAN_TIME_OUT_NUM, 'Error Returned')

        // populating SecurityCodeData arrayList, when delivery method is S
        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '5'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        alSecurityCodeData.add(hmDBSecurityCode)

        proofingEncryptionHelper.generateSHA1Value(_ as String)>>'1990122'

        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeResp[MPSDefs.SECURITY_CODE_INFO] = alSecurityCodeData
        cgRestClient.getCGSyncCall(_ as HashMap)>>resultHashError

        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap)>>hmSecurityCodeResp
        when:
        hmResponse = validatePINHelperObj.validatePIN(hmInput)
        then:
        hmResponse != null
        //assertEquals("Response from RestServiceHelper.call() is null or empty", hmResponse.get("appInfo"));
    }


    def "test validate p i n security code error e r r e x t e r n a l s y s"() throws Exception {

        given:
        HashMap resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EXTERNAL_SYS_NUM, 'Error Returned')

        // populating SecurityCodeData arrayList, when delivery method is S
        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '5'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        alSecurityCodeData.add(hmDBSecurityCode)
        proofingEncryptionHelper.generateSHA1Value(_ as String)>>'1990122'
        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeResp[MPSDefs.SECURITY_CODE_INFO] = alSecurityCodeData
        cgRestClient.getCGSyncCall(_ as HashMap)>>resultHashError

        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap)>>hmSecurityCodeResp
        when:
        hmResponse = validatePINHelperObj.validatePIN(hmInput)
        then:
        hmResponse != null
        //assertEquals("Response from RestServiceHelper.call() is null or empty", hmResponse.get("appInfo"));
    }


    def "test validate p i n security code subcriber not found"() throws Exception {

        given:
        HashMap resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SIM_DATE_MISSING_NUM, 'Error Returned')

        // populating SecurityCodeData arrayList, when delivery method is S
        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '5'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        alSecurityCodeData.add(hmDBSecurityCode)

        proofingEncryptionHelper.generateSHA1Value(_ as String)>>'1990122'
        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeResp[MPSDefs.SECURITY_CODE_INFO] = alSecurityCodeData
        cgRestClient.getCGSyncCall(_ as HashMap)>>resultHashError
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap)>>hmSecurityCodeResp
        when:
        hmResponse = validatePINHelperObj.validatePIN(hmInput)
        then:
        hmResponse != null
        //assertEquals("Response from RestServiceHelper.call() is null or empty", hmResponse.get("appInfo"));
    }

    def "test validate p i n security code with c g response"() throws Exception {
        given:
        HashMap hmSyncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        ArrayList alSubcriber = new ArrayList<>()

        ObjectMapper map = new ObjectMapper()
        JsonNode node = map.readTree(CGResponse())
        alSubcriber.add(node)
        ArrayNode array = map.valueToTree(alSubcriber)
        hmSyncResp['subscribers'] = array

        //HashMap resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SIM_DATE_MISSING_NUM, "Error Returned");

        // populating SecurityCodeData arrayList, when delivery method is S
        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '5'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        alSecurityCodeData.add(hmDBSecurityCode)

        proofingEncryptionHelper.generateSHA1Value(_ as String)>>'1990122'

        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeResp[MPSDefs.SECURITY_CODE_INFO] = alSecurityCodeData
        cgRestClient.getCGSyncCall(_ as HashMap)>>hmSyncResp
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap)>>hmSecurityCodeResp


        when:
        hmResponse = validatePINHelperObj.validatePIN(hmInput)
        then:
        hmResponse != null


        //assertEquals("Response from RestServiceHelper.call() is null or empty", hmResponse.get("appInfo"));
    }


    def "test validate p i n security code with c g response success"() throws Exception {

        given:
        HashMap hmResultSuccess = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        //HashMap resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SIM_DATE_MISSING_NUM, "Error Returned");

        // populating SecurityCodeData arrayList, when delivery method is S
        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = 'abc@att.com'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        alSecurityCodeData.add(hmDBSecurityCode)

        proofingEncryptionHelper.generateSHA1Value(_ as String)>>'1990122'
        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeResp[MPSDefs.SECURITY_CODE_INFO] = alSecurityCodeData


        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap)>>hmSecurityCodeResp
        objDeletePINHelper.deletePin(_ as HashMap)>>hmResultSuccess
        hmInput['deletePINOnSuccess'] = 'ALL'
        when:
        hmResponse = validatePINHelperObj.validatePIN(hmInput)
        then:
        hmResponse != null


        //assertEquals("Response from RestServiceHelper.call() is null or empty", hmResponse.get("appInfo"));
    }

    def "test validate p i n security code error incorrect code"() throws Exception {

        given:
        HashMap hmResultSuccess = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        //HashMap resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SIM_DATE_MISSING_NUM, "Error Returned");

        // populating SecurityCodeData arrayList, when delivery method is S
        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '22222'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = 'abc@att.com'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        alSecurityCodeData.add(hmDBSecurityCode)

        proofingEncryptionHelper.generateSHA1Value(_ as String)>>'1990122'
        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeResp[MPSDefs.SECURITY_CODE_INFO] = alSecurityCodeData

        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap)>>hmSecurityCodeResp
        objDeletePINHelper.deletePin(_ as HashMap)>>hmResultSuccess
        securityCodeDBHelperObj.updateSecurityCode(_ as HashMap,MPSDefs.INCREMENT_FAILURE_COUNT)>>hmResultSuccess
        securityCodeDBHelperObj.updateSecurityAccount(_ as HashMap,false)>>hmResultSuccess
        hmInput['deletePINOnSuccess'] = 'ALL'
        when:
        hmResponse = validatePINHelperObj.validatePIN(hmInput)
        then:
        hmResponse != null


        //assertEquals("Response from RestServiceHelper.call() is null or empty", hmResponse.get("appInfo"));
    }


    def "test validate p i n security code with max failed count"() throws Exception {
        given:
        HashMap hmSyncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        HashMap hmResultSuccess = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        ArrayList alSubcriber = new ArrayList<>()

        ObjectMapper map = new ObjectMapper()
        JsonNode node = map.readTree(CGResponse())
        alSubcriber.add(node)
        ArrayNode array = map.valueToTree(alSubcriber)
        hmSyncResp['subscribers'] = array

        //HashMap resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SIM_DATE_MISSING_NUM, "Error Returned");

        // populating SecurityCodeData arrayList, when delivery method is S
        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 7
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        alSecurityCodeData.add(hmDBSecurityCode)

        proofingEncryptionHelper.generateSHA1Value(_ as String)>>'1990122'

        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeResp[MPSDefs.SECURITY_CODE_INFO] = alSecurityCodeData
        cgRestClient.getCGSyncCall(_ as HashMap)>>hmSyncResp

        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap)>>hmSecurityCodeResp
        securityCodeDBHelperObj.updateSecurityCode(_ as HashMap,MPSDefs.INCREMENT_FAILURE_COUNT)>>hmResultSuccess
        securityCodeDBHelperObj.updateSecurityAccount(_ as HashMap,false)>>hmResultSuccess

        when:
        hmResponse = validatePINHelperObj.validatePIN(hmInput)
        then:
        hmResponse != null


        //assertEquals("Response from RestServiceHelper.call() is null or empty", hmResponse.get("appInfo"));
    }

    def "test validatePIN with cosmos update with error"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')
        Map<String, Object> hmInput = [
                transactionName: 'ValidatePIN',
                callingSystemId: 'DATAMGT',
                accountId: '000981453456',
                identificationType: 'IDSEMOB',
                securityCode: '1990122',
                deletePINOnSuccess: 'Yes',
                agentId: '1234',
                sourceIPAddress: '10.12.13.223',
                transactionId: 'test1234',
                idpSessionId: 'session1234'
        ]
        Map<String, Object> hmSecurityCodeResp = [
                (CommonDefs.COMMON_APP_STATUS_CODE): '0',
                (MPSDefs.SECURITY_CODE_INFO): [[
                                                       (MPSDefs.DB_SECURITY_CODE): '1990122',
                                                       (MPSDefs.DB_VERIFICATION_FAILURE_COUNT): 1,
                                                       (MPSDefs.EXCEEDED_UNLOCKED_TIME): '0',
                                                       (MPSDefs.DB_DELIVERY_METHOD): 'S',
                                                       (MPSDefs.DB_DELIVERY_DETAIL): '9899545',
                                                       (MPSDefs.DB_CREATE_DATE): '23012023'
                                               ]]
        ]
        HashMap hmResultSuccess = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        featureManager.getValue(_ as String) >> "ONLYORACLE"
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_) >> hmSecurityCodeResp
        proofingEncryptionHelper.generateSHA1Value(_) >> '1990122'
        objDeletePINHelper.deletePin(_ as HashMap) >> hmResultSuccess

        when:
        def result = validatePINHelperObj.validatePIN(hmInput)

        then:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    def "test validatePIN with cosmos update"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')
        HashMap hmSyncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        HashMap hmResultSuccess = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        ArrayList alSubcriber = new ArrayList<>()
        ObjectMapper map = new ObjectMapper()
        JsonNode node = map.readTree(CGResponse())
        alSubcriber.add(node)
        ArrayNode array = map.valueToTree(alSubcriber)
        hmSyncResp['subscribers'] = array

        Map<String, Object> hmInput = [
                transactionName: 'ValidatePIN',
                callingSystemId: 'CCMULE',
                accountId: '000981453456',
                accountType: 'MOBILITY',
                identificationType: 'IDSEMOB',
                securityCode: '1990122',
                deletePINOnSuccess: 'Yes',
                agentId: '1234',
                sourceIPAddress: '10.12.13.223',
                transactionId: 'test1234',
                idpSessionId: 'session1234'
        ]



        Map<String, Object> hmSecurityCodeResp = [
                (CommonDefs.COMMON_APP_STATUS_CODE): '0',
                (MPSDefs.SECURITY_CODE_INFO): [[
                                                       (MPSDefs.DB_SECURITY_CODE): '1990122',
                                                       (MPSDefs.DB_VERIFICATION_FAILURE_COUNT): 1,
                                                       (MPSDefs.EXCEEDED_UNLOCKED_TIME): '0',
                                                       (MPSDefs.DB_DELIVERY_METHOD): 'S',
                                                       (MPSDefs.DB_DELIVERY_DETAIL): '9899545',
                                                       (MPSDefs.DB_CREATE_DATE): '23012023'
                                               ]]
        ]
        featureManager.getValue(_ as String) >> "ONLYORACLE"
        cgHelper.makeCGSyncCall(_, _) >> hmSyncResp
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_) >> hmSecurityCodeResp
        idgOtpDBHelper.getSecurityCodeDataQuery(_) >> hmSecurityCodeResp
        securityCodeDBHelperObj.updateSecurityCode(_ as HashMap, _)>>hmResultSuccess
        idgOtpDBHelper.updateSecurityCode(_ as HashMap, _)>>hmResultSuccess
        securityCodeDBHelperObj.updateSecurityAccount(_ as HashMap,false)>>hmResultSuccess
        idgOtpDBHelper.updateSecurityAccount(_ as HashMap)>>hmResultSuccess
        proofingEncryptionHelper.generateSHA1Value(_) >> '1990122'

        when:
        def result = validatePINHelperObj.validatePIN(hmInput)

        then:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_CODE] == '602'
    }

    def "test getOtpDataSource with ORACLEMASTER"() {
        given:
        featureManager.getValue(_ as String)>>'ORACLEMASTER'
        when:
        String result = validatePINHelperObj.getOtpDataSource()
        then:
        result == 'ORACLEMASTER'
    }
    def "test getOtpDataSource with ONLYORACLE"() {
        given:
        featureManager.getValue(_ as String)>>'ONLYORACLE'
        when:
        String result = validatePINHelperObj.getOtpDataSource()
        then:
        result == 'ONLYORACLE'
    }

    def "test getOtpDataSource with ONLYCOSMOS"() {
        given:
        featureManager.getValue(_ as String)>>'ONLYCOSMOS'
        when:
        String result = validatePINHelperObj.getOtpDataSource()
        then:
        result == 'ONLYCOSMOS'
    }
    def "test getOtpDataSource with COSMOSMASTER"() {
        given:
        featureManager.getValue(_ as String)>>'COSMOSMASTER'
        when:
        String result = validatePINHelperObj.getOtpDataSource()
        then:
        result == 'COSMOSMASTER'
    }

    def "test getOtpDataSource with DUMMY"() {
        given:
        featureManager.getValue(_ as String)>>'DUMMY'
        when:
        validatePINHelperObj.getOtpDataSource()
        then:
        thrown(IllegalArgumentException)
    }

    def "test getOtpDataSource with null"() {
        given:
        featureManager.getValue(_ as String)>>null
        when:
        String result  = validatePINHelperObj.getOtpDataSource()
        then:
        result == 'COSMOSMASTER'
    }

    String CGResponse() {

        return '{\n' +
                '    "individuals": [\n' +
                '        {\n' +
                '            "id": "f73623f0-2a26-4717-9913-4750f5203f73",\n' +
                '            "givenName": "KRISTAL",\n' +
                '            "familyName": "PADDEN",\n' +
                '            "contactMedium": [\n' +
                '                {\n' +
                '                    "mediumType": "email",\n' +
                '                    "preferred": true,\n' +
                '                    "characteristic": {\n' +
                '                        "contactType": "other",\n' +
                '                        "emailAddress": "KRISTALECC@GMAIL.COM"\n' +
                '                    }\n' +
                '                },\n' +
                '                {\n' +
                '                    "mediumType": "postalAddress",\n' +
                '                    "preferred": true,\n' +
                '                    "characteristic": {\n' +
                '                        "contactType": "B",\n' +
                '                        "city": "DAYTONA BEACH",\n' +
                '                        "country": "USA",\n' +
                '                        "postCode": "32117-5591",\n' +
                '                        "stateOrProvince": "FL",\n' +
                '                        "street1": "1381 N CLYDE MORRIS BLVD APT 1030",\n' +
                '                        "place": {\n' +
                '                            "id": "336496948"\n' +
                '                        },\n' +
                '                        "addressSubType": "H",\n' +
                '                        "county": "127"\n' +
                '                    }\n' +
                '                }\n' +
                '            ],\n' +
                '            "accounts": [\n' +
                '                {\n' +
                '                    "id": "523350291056",\n' +
                '                    "state": "O",\n' +
                '                    "createdOn": "2021-08-20 00:00:00",\n' +
                '                    "accountType": "I",\n' +
                '                    "accountSubType": "R",\n' +
                '                    "contact": [\n' +
                '                        {\n' +
                '                            "contactMedium": [\n' +
                '                                {\n' +
                '                                    "mediumType": "email",\n' +
                '                                    "preferred": true,\n' +
                '                                    "characteristic": {\n' +
                '                                        "contactType": "other",\n' +
                '                                        "emailAddress": "KRISTALECC@GMAIL.COM"\n' +
                '                                    }\n' +
                '                                },\n' +
                '                                {\n' +
                '                                    "mediumType": "postalAddress",\n' +
                '                                    "preferred": true,\n' +
                '                                    "characteristic": {\n' +
                '                                        "contactType": "B",\n' +
                '                                        "city": "DAYTONA BEACH",\n' +
                '                                        "country": "USA",\n' +
                '                                        "postCode": "32117-5591",\n' +
                '                                        "stateOrProvince": "FL",\n' +
                '                                        "street1": "1381 N CLYDE MORRIS BLVD APT 1030",\n' +
                '                                        "place": {\n' +
                '                                            "id": "336496948"\n' +
                '                                        },\n' +
                '                                        "addressSubType": "H",\n' +
                '                                        "county": "127"\n' +
                '                                    }\n' +
                '                                }\n' +
                '                            ]\n' +
                '                        }\n' +
                '                    ],\n' +
                '                    "billStructure": {\n' +
                '                        "presentationMedia": [\n' +
                '                            {\n' +
                '                                "name": "paperless"\n' +
                '                            }\n' +
                '                        ],\n' +
                '                        "cycleSpecification": {\n' +
                '                            "id": "22",\n' +
                '                            "name": "BillingCycleSpecification",\n' +
                '                            "frequency": "month"\n' +
                '                        }\n' +
                '                    },\n' +
                '                    "ratingType": "postpaid",\n' +
                '                    "fraudLocked": false,\n' +
                '                    "billingMarket": "FLP",\n' +
                '                    "fanDetails": {},\n' +
                '                    "pastDue": 331.93,\n' +
                '                    "bmgIndicator": "NS",\n' +
                '                    "taxExemptStatus": "N",\n' +
                '                    "companyCode": "BL",\n' +
                '                    "isEmployee": "N",\n' +
                '                    "bundleDiscExists": "N",\n' +
                '                    "subscribersCount": 3,\n' +
                '                    "productTypes": [\n' +
                '                        "WIRELESS"\n' +
                '                    ],\n' +
                '                    "amountDue": 331.93,\n' +
                '                    "languagePreference": "EN",\n' +
                '                    "convergedCustomerOption": "0",\n' +
                '                    "firstnetIndicator": false,\n' +
                '                    "billingAccountTypeDisplay": "Individual",\n' +
                '                    "serviceDiscount": 0,\n' +
                '                    "convergedCustomerOptionDisplay": "none",\n' +
                '                    "securityLevelCode": "S",\n' +
                '                    "profileType": "BILLINGACCOUNT",\n' +
                '                    "emailStatusUpdateDate": "2022-10-13 00:00:00",\n' +
                '                    "hboMaxEntitlementIndicator": false,\n' +
                '                    "givenName": "KRISTAL",\n' +
                '                    "familyName": "PADDEN",\n' +
                '                    "serviceType": "WIRELESS",\n' +
                '                    "emailStatus": "VD",\n' +
                '                    "creditClass": "B",\n' +
                '                    "subMarket": "025",\n' +
                '                    "systemOfRecord": "TELEGANCE-DB",\n' +
                '                    "autoPayIndicator": "false",\n' +
                '                    "primaryAccountHolder": "3863169761",\n' +
                '                    "billDueDate": "2023-11-15 00:00:00",\n' +
                '                    "statusReasonCode": "CA",\n' +
                '                    "customerInTreatment": true,\n' +
                '                    "statusReasonDescription": "CTN Activation",\n' +
                '                    "statusReasonActivity": "CTN ACTIVATION"\n' +
                '                }\n' +
                '            ],\n' +
                '            "products": [\n' +
                '                {\n' +
                '                    "productId": "18591032096",\n' +
                '                    "startDate": "2021-08-20 19:06:27",\n' +
                '                    "productOfferingCharacteristic": [\n' +
                '                        {\n' +
                '                            "name": "itemSdesc",\n' +
                '                            "value": "iP12ProA2341"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "capCode",\n' +
                '                            "value": "0"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "manfCd",\n' +
                '                            "value": "APPLE"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "equipmentType",\n' +
                '                            "value": "I"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "frequency",\n' +
                '                            "value": "0"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "itemOwnership",\n' +
                '                            "value": "S"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "locationId",\n' +
                '                            "value": "RMSC"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "esnSeqNo",\n' +
                '                            "value": "130561495"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "model",\n' +
                '                            "value": "iP12ProA2341"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "manfName",\n' +
                '                            "value": "APPLE"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "tradeInInd",\n' +
                '                            "value": "false"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "currPossession",\n' +
                '                            "value": "I"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "lastSwActvDate",\n' +
                '                            "value": "2021-08-20 00:00:00"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "pool",\n' +
                '                            "value": "P"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "swStateInd",\n' +
                '                            "value": "Y"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "baudRate",\n' +
                '                            "value": "0"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "equipmentMode",\n' +
                '                            "value": "N"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "esnLevel",\n' +
                '                            "value": "2"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "itemLDesc",\n' +
                '                            "value": "APPLE iPhone 12 Pro A2341"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "currPossessionDt",\n' +
                '                            "value": "20210820000000"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "unitEsn",\n' +
                '                            "value": "353781189974353"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "newEsnFlag",\n' +
                '                            "value": "N"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "capSeqNo",\n' +
                '                            "value": "0"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "desc",\n' +
                '                            "value": "IMEI#353781189974353"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "smsCapability",\n' +
                '                            "value": "Y"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "equipmentAttrDesc",\n' +
                '                            "value": "S7-5G mmWave/Sub6 / DSDS"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "osVersion",\n' +
                '                            "value": "14.7.1(18G82)"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "osType",\n' +
                '                            "value": "IOS"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "equipmentCategory",\n' +
                '                            "value": "Phone"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "lteType",\n' +
                '                            "value": "3"\n' +
                '                        }\n' +
                '                    ],\n' +
                '                    "productRelationship": [\n' +
                '                        {\n' +
                '                            "product": {\n' +
                '                                "id": "3863169761"\n' +
                '                            },\n' +
                '                            "type": "SubscriptionRelation"\n' +
                '                        }\n' +
                '                    ],\n' +
                '                    "productOffering": {\n' +
                '                        "type": "Equipment"\n' +
                '                    }\n' +
                '                },\n' +
                '                {\n' +
                '                    "productId": "16573031207",\n' +
                '                    "startDate": "2021-08-20 19:03:46",\n' +
                '                    "productOfferingCharacteristic": [\n' +
                '                        {\n' +
                '                            "name": "itemSdesc",\n' +
                '                            "value": "UNKNOWN"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "capCode",\n' +
                '                            "value": "0"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "manfCd",\n' +
                '                            "value": "TEC"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "imsi",\n' +
                '                            "value": "310280002912182"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "uiccInd",\n' +
                '                            "value": "X"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "equipmentType",\n' +
                '                            "value": "S"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "frequency",\n' +
                '                            "value": "0"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "itemOwnership",\n' +
                '                            "value": "S"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "locationId",\n' +
                '                            "value": "RMSC"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "puk2",\n' +
                '                            "value": "04815120"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "esnSeqNo",\n' +
                '                            "value": "130561494"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "model",\n' +
                '                            "value": "UNKNOWN"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "puk1",\n' +
                '                            "value": "82109406"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "manfName",\n' +
                '                            "value": "TEC"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "tradeInInd",\n' +
                '                            "value": "false"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "currPossession",\n' +
                '                            "value": "I"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "lastSwActvDate",\n' +
                '                            "value": "2021-08-20 00:00:00"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "pool",\n' +
                '                            "value": "P"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "swStateInd",\n' +
                '                            "value": "Y"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "baudRate",\n' +
                '                            "value": "0"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "equipmentMode",\n' +
                '                            "value": "N"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "esnLevel",\n' +
                '                            "value": "1"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "privateId",\n' +
                '                            "value": "310280002912182@private.att.net"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "itemLDesc",\n' +
                '                            "value": "Unknown Type Of Equipment"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "currPossessionDt",\n' +
                '                            "value": "20210820000000"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "unitEsn",\n' +
                '                            "value": "89012804320029121828"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "newEsnFlag",\n' +
                '                            "value": "N"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "capSeqNo",\n' +
                '                            "value": "0"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "publicId",\n' +
                '                            "value": "3863169761@one.att.net"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "desc",\n' +
                '                            "value": "SIM#89012804320029121828"\n' +
                '                        },\n' +
                '                        {\n' +
                '                            "name": "imsiPublicId",\n' +
                '                            "value": "310280002912182@one.att.net"\n' +
                '                        }\n' +
                '                    ],\n' +
                '                    "productRelationship": [\n' +
                '                        {\n' +
                '                            "product": {\n' +
                '                                "id": "3863169761"\n' +
                '                            },\n' +
                '                            "type": "SubscriptionRelation"\n' +
                '                        }\n' +
                '                    ],\n' +
                '                    "productOffering": {\n' +
                '                        "type": "Equipment"\n' +
                '                    }\n' +
                '                }\n' +
                '            ],\n' +
                '            "contracts": [],\n' +
                '            "installments": [],\n' +
                '            "subscribers": [\n' +
                '                {\n' +
                '                    "subscriberId": "3863169761",\n' +
                '                    "effectiveDate": "2021-08-20 00:00:00",\n' +
                '                    "status": "A",\n' +
                '                    "profile": {\n' +
                '                        "firstName": "KRISTAL",\n' +
                '                        "lastName": "PADDEN",\n' +
                '                        "emailAddress": "KRISTALECC@GMAIL.COM",\n' +
                '                        "phoneNumber": "3863169761",\n' +
                '                        "phoneNumberAttIndicator": false,\n' +
                '                        "secondaryPhoneNumberAttIndicator": false\n' +
                '                    },\n' +
                '                    "addresses": [\n' +
                '                        {\n' +
                '                            "addressLine1": "1381 N CLYDE MORRIS BLVD APT 1030",\n' +
                '                            "city": "DAYTONA BEACH",\n' +
                '                            "state": "FL",\n' +
                '                            "zip": "32117",\n' +
                '                            "addressType": "U",\n' +
                '                            "addressCategory": "PPU",\n' +
                '                            "addressSubType": "H"\n' +
                '                        }\n' +
                '                    ],\n' +
                '                    "subscriptionId": "T_FLP_025_1629500626000124273497",\n' +
                '                    "subscriberStatusReasonCode": "CA",\n' +
                '                    "statusReasonActivity": "CTN ACTIVATION",\n' +
                '                    "statusReasonCodeDescription": "CTN Activation",\n' +
                '                    "subStatusDate": "2021-08-20 00:00:00",\n' +
                '                    "blueNetworkIndicator": "N",\n' +
                '                    "nciIndicator": "N",\n' +
                '                    "techType": "GL",\n' +
                '                    "migrated": "N",\n' +
                '                    "primarySubscriber": "Y",\n' +
                '                    "groupId": "G9270128",\n' +
                '                    "firstnetIndicator": "false"\n' +
                '                }\n' +
                '            ]\n' +
                '        }\n' +
                '    ]\n' +
                '}'
    }

    @Unroll
    def "should compare account and SIM effective dates for #scenarioName"() {
        given: "Two date strings and a date format"
        String accountCreatedOn = acctDate
        String sSIMEffectiveDate = simDate
        String sDateFormat = "yyyy-MM-dd"

        when: "compareAcctAndSIMEffectDate is called"
        boolean result = validatePINHelperObj.compareAcctAndSIMEffectDate(accountCreatedOn, sSIMEffectiveDate, sDateFormat)

        then: "Result matches expected outcome"
        0 * _ // No external interactions

        and: "Result is true if dates are not equal, false if equal or any is null"
        result == expectedNotSame

        where: "Different date comparison scenarios"
        scenarioName           | acctDate      | simDate      | expectedNotSame
        "dates are equal"      | "2024-06-01"  | "2024-06-01" | false
        "dates are different"  | "2024-06-01"  | "2024-06-02" | true
        "account date null"    | null          | "2024-06-01" | false
        "SIM date null"        | "2024-06-01"  | null         | false
        "both dates null"      | null          | null         | false
        "invalid date format"  | "2024/06/01"  | "2024-06-01" | false
    }

    @Unroll
    def "should update CosmosDB for #scenarioName"() {
        given: "Cosmos input and result maps with concrete types"
        Map<String, Object> hmCosmosInput = [
                "sessionId": "sess123",
                (CommonDefs.ACCOUNT_ID): "acct456",
                (CommonDefs.ACCOUNT_TYPE): accountType,
                (CommonDefs.CALLING_SYSTEM_ID): "CHAN789",
                (CommonDefs.DELIVERY_METHOD): deliveryMethod,
                (CommonDefs.DELIVERY_METHOD_VALUE): deliveryDetail
        ].findAll { it.value != null }
        Map<String, Object> hmResult = [
                (CommonDefs.COMMON_APP_CATEGORY_CODE): appCategoryCode,
                (CommonDefs.COMMON_APP_STATUS_MSG): appStatusMsg,
                (CommonDefs.COMMON_APP_INFO): appInfo
        ]

        ValidatePinInfoBean expectedBean = new ValidatePinInfoBean()
        expectedBean.setSessionId("sess123")
        expectedBean.setAccountNumber("acct456")
        expectedBean.setAccountType(accountType)
        expectedBean.setChannel("CHAN789")
        expectedBean.setStatus(expectedStatus)
        expectedBean.setFailureReason(expectedFailureReason)
        if (deliveryMethod == "E") {
            expectedBean.setAuthenticationMethod("OTPEMAIL")
            expectedBean.setEmailAddress(deliveryDetail)
        } else if (deliveryMethod == "S") {
            expectedBean.setAuthenticationMethod("OTPSMS")
            expectedBean.setPhoneNumber(deliveryDetail)
        } else if (expectedStatus == "FAILURE") {
            expectedBean.setAuthenticationMethod("OTP")
        }

        when: "updateIDMCosmosDB is called"
        Map<String, Object> result = validatePINHelperObj.updateIDMCosmosDB(hmCosmosInput, hmResult)

        then: "CosmosDataStore is called with correct bean"
        1 * cosmosDataStore.PersistValidatePinInfoToDatabase({ ValidatePinInfoBean bean ->
            bean.sessionId == expectedBean.sessionId &&
                    bean.accountNumber == expectedBean.accountNumber &&
                    bean.accountType == expectedBean.accountType &&
                    bean.channel == expectedBean.channel &&
                    bean.status == expectedBean.status &&
                    bean.failureReason == expectedBean.failureReason &&
                    bean.authenticationMethod == expectedBean.authenticationMethod &&
                    bean.emailAddress == expectedBean.emailAddress &&
                    bean.phoneNumber == expectedBean.phoneNumber
        })
        0 * _

        and: "Result contains expected success code and message"
        result != null
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) == "0"
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG

        where: "Different result scenarios"
        scenarioName         | appCategoryCode           | appStatusMsg         | appInfo         | accountType | deliveryMethod | deliveryDetail | expectedStatus | expectedFailureReason
        "Success"            | CommonDefs.COMMON_SUCCESS | "SuccessMsg"         | "Info"          | "WIRELESS"  | "E"            | "user@email"   | "SUCCESS"      | null
        "System Failure"     | "2"                       | "SystemError"        | "SysInfo"       | "UVERSE"    | null           | null           | "FAILURE"      | "SYSTEM:SystemError:SysInfo"
        "Data Failure"       | "3"                       | "DataError"          | "DataInfo"      | "WIRELESS"  | "S"            | "1234567890"   | "FAILURE"      | "DATA:DataError:DataInfo"
    }

    def "test validatePIN incorrect code ONLYCOSMOS data source"() {
        given:
        featureManager.getValue(_ as String) >> 'ONLYCOSMOS'
        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put('transactionName', 'ValidatePIN')
        hmInputLocal.put('identificationType', 'IDSEMOB')
        hmInputLocal.put('securityCode', '1990122')

        HashMap<String, Object> hmDbSecurityCode = new HashMap<>()
        hmDbSecurityCode.put(MPSDefs.DB_SECURITY_CODE, 'differentEncrypted')
        hmDbSecurityCode.put(MPSDefs.DB_VERIFICATION_FAILURE_COUNT, Integer.valueOf(1))
        hmDbSecurityCode.put(MPSDefs.EXCEEDED_UNLOCKED_TIME, '0')
        hmDbSecurityCode.put(MPSDefs.DB_DELIVERY_METHOD, 'E')
        hmDbSecurityCode.put(MPSDefs.DB_DELIVERY_DETAIL, 'user@test.com')
        hmDbSecurityCode.put(MPSDefs.DB_CREATE_DATE, '2024-01-01')

        ArrayList<HashMap<String, Object>> alCodes = new ArrayList<>()
        alCodes.add(hmDbSecurityCode)

        HashMap<String, Object> hmSecurityCodeOnlyCosmos = new HashMap<>()
        hmSecurityCodeOnlyCosmos.put(CommonDefs.COMMON_APP_STATUS_CODE, CErrorDefs.COMMON_SUCCESS)
        hmSecurityCodeOnlyCosmos.put(MPSDefs.SECURITY_CODE_INFO, alCodes)

        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        idgOtpDBHelper.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeOnlyCosmos

        when:
        HashMap<String, Object> result = validatePINHelperObj.validatePIN(hmInputLocal)

        then:
        result != null
        // Runtime shows a system error with errorMetricHandler invocation when hmSecurityCodeResp becomes null
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) == CErrorDefs.CATEGORY_CODE_SYSTEM_ERROR

        1 * idgOtpDBHelper.getSecurityCodeDataQuery(_ as HashMap)
        1 * errMetricHandler.recordDBErrorMetric(_ as String)

        // No Cosmos update calls are made in this erroneous path
        0 * idgOtpDBHelper.updateSecurityCode(_ as HashMap, _)
        0 * idgOtpDBHelper.updateSecurityAccount(_ as HashMap)

        // And no Oracle DB or deletePIN interactions
        0 * securityCodeDBHelperObj._
        0 * objDeletePINHelper._
        0 * cosmosDataStore._
    }

    @Unroll
    def "should delete PIN and return success when validation succeeds for #scenarioName"() {
        given: "A valid input map and mocked dependencies for successful PIN deletion"
        Map<String, Object> hmInput = new HashMap<>()
        hmInput.put("idpTraceId", "trace-123")
        hmInput.put(CommonDefs.TRANSACTION_NAME, "ValidatePIN")
        hmInput.put(CommonDefs.CALLING_SYSTEM_ID, "CALLING_SYS")
        hmInput.put(CommonDefs.ACCOUNT_ID, "account1")
        hmInput.put(CommonDefs.IDENTIFICATION_TYPE, identificationType)
        hmInput.put(CommonDefs.SECURITY_CODE, "123456")
        hmInput.put(CommonDefs.DELETE_PIN_ON_SUCCESS, deleteOnSuccess)
        hmInput.put(CommonDefs.ACCOUNT_TYPE, "BSSEWIRELESS")

        // Force Oracle/DB flow so securityCodeDBHelperObj + objDeletePINHelper are used
        featureManager.getValue(_ as String) >> "ORACLEMASTER"

        ArrayList<String> alReusePinIdentificationType = new ArrayList<>()
        alReusePinIdentificationType.add(reuseIdentificationType)
        ReflectionTestUtils.setField(validatePINHelperObj, "propReuseIdentificationTypes",
                reuseIdentificationType)

        ReflectionTestUtils.setField(validatePINHelperObj, "propUnlockPeriodMins",
                String.format("%s:30", identificationType.toUpperCase()))
        ReflectionTestUtils.setField(validatePINHelperObj, "propPINMaxFailureCnt",
                String.format("%s:3", identificationType.toUpperCase()))
        ReflectionTestUtils.setField(validatePINHelperObj, "propPinMaxPins",
                String.format("%s:5", identificationType.toUpperCase()))
        ReflectionTestUtils.setField(validatePINHelperObj, "propSIMCheckIdentificationType",
                "")

        HashMap<String, Object> hmSecurityCodeResp = new HashMap<>()
        hmSecurityCodeResp.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        ArrayList<HashMap<String, Object>> alSecurityCodeData = new ArrayList<>()
        HashMap<String, Object> hmDBSecurityCode = new HashMap<>()
        hmDBSecurityCode.put(MPSDefs.DB_SECURITY_CODE, "ENCRYPTED_CODE")
        hmDBSecurityCode.put(MPSDefs.DB_VERIFICATION_FAILURE_COUNT, Integer.valueOf(0))
        hmDBSecurityCode.put(MPSDefs.EXCEEDED_UNLOCKED_TIME, "0")
        hmDBSecurityCode.put(MPSDefs.DB_CREATE_DATE, "2024-01-01T00:00:00")
        hmDBSecurityCode.put(MPSDefs.DB_DELIVERY_METHOD, "E")
        hmDBSecurityCode.put(MPSDefs.DB_DELIVERY_DETAIL, "someDetail")
        alSecurityCodeData.add(hmDBSecurityCode)
        hmSecurityCodeResp.put(MPSDefs.SECURITY_CODE_INFO, alSecurityCodeData)

        HashMap<String, Object> hmDeleteSuccessResp = new HashMap<>()
        hmDeleteSuccessResp.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        boolean reuseIdType = identificationType.equalsIgnoreCase(reuseIdentificationType)
        int expectedDeleteInvocations = (reuseIdType && !deleteOnSuccess.equals("ALL")) ? 0 : 1
        int expectedDeleteAllInvocations = deleteOnSuccess.equals("ALL") ? 1 : 0

        when: "validatePIN is invoked"
        HashMap<String, Object> hmResult = validatePINHelperObj.validatePIN(hmInput)

        then: "Dependencies are invoked with expected parameters"
        1 * proofingEncryptionHelper.generateSHA1Value("123456") >> "ENCRYPTED_CODE"
        1 * securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeResp
        expectedDeleteInvocations * objDeletePINHelper.deletePin({ Map<String, Object> hmDelete ->
            hmDelete.get(CommonDefs.TRANSACTION_ID) == "trace-123" &&
                    hmDelete.get(CommonDefs.TRANSACTION_NAME) == "DeletePIN" &&
                    hmDelete.get(CommonDefs.CALLING_SYSTEM_ID) == "CALLING_SYS" &&
                    hmDelete.get(CommonDefs.ACCOUNT_ID) == "account1" &&
                    hmDelete.get(CommonDefs.IDENTIFICATION_TYPE) == identificationType.toUpperCase() &&
                    hmDelete.get(CommonDefs.SECURITY_CODE) == "123456" &&
                    hmDelete.get(CommonDefs.DELETE_All) == CommonDefs.IND_N &&
                    hmDelete.get(CommonDefs.AGENT_ID) == null &&
                    hmDelete.get(CommonDefs.REASON_CODE) == expectedReasonCode &&
                    hmDelete.get(CommonDefs.IS_EXTERNAL_CALL) == CommonDefs.IND_N &&
                    !hmDelete.containsKey("SKIP_HISTORY")
        }) >> hmDeleteSuccessResp
        expectedDeleteAllInvocations * objDeletePINHelper.deletePin({ Map<String, Object> hmDeleteAll ->
            hmDeleteAll.get(CommonDefs.TRANSACTION_ID) == "trace-123" &&
                    hmDeleteAll.get(CommonDefs.TRANSACTION_NAME) == "DeletePIN" &&
                    hmDeleteAll.get(CommonDefs.CALLING_SYSTEM_ID) == "CALLING_SYS" &&
                    hmDeleteAll.get(CommonDefs.ACCOUNT_ID) == "account1" &&
                    hmDeleteAll.get(CommonDefs.IDENTIFICATION_TYPE) == identificationType.toUpperCase() &&
                    hmDeleteAll.get(CommonDefs.SECURITY_CODE) == "123456" &&
                    hmDeleteAll.get(CommonDefs.DELETE_All) == CommonDefs.IND_Y &&
                    hmDeleteAll.get(CommonDefs.AGENT_ID) == null &&
                    hmDeleteAll.get(CommonDefs.REASON_CODE) == expectedReasonCode &&
                    hmDeleteAll.get(CommonDefs.IS_EXTERNAL_CALL) == CommonDefs.IND_N &&
                    !hmDeleteAll.containsKey("SKIP_HISTORY")
        }) >> hmDeleteSuccessResp
        1 * featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> 'ORACLEMASTER'
        0 * idgOtpDBHelper.updateSecurityCode(_ as HashMap, _)
        0 * idgOtpDBHelper.updateSecurityAccount(_ as HashMap, _)
        0 * securityCodeDBHelperObj.updateSecurityCode(_ as HashMap, _)
        0 * securityCodeDBHelperObj.updateSecurityAccount(_ as HashMap, _)
        0 * cgHelper.makeCGSyncCall(_ as HashMap, _)

        and: "No OTP history from ValidatePINHelper on success path; delete history handled by DeletePINHelper"
        _ * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()
        0 * otpHistoryDBHelper.saveOtpHistory(_)

        and: "Result is success and no remaining codes are added for success path"
        hmResult != null
        hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        hmResult.get(CommonDefs.COMMON_APP_INFO) == CommonDefs.COMMON_SUCCESS_MSG

        where: "Different combinations of identification type and delete-on-success flag"
        scenarioName                      | identificationType | deleteOnSuccess | reuseIdentificationType | expectedReasonCode
        "reuse identification type"       | "puk"              | "Y"             | "PUK"                   | ProfileOrchestrationConstants.STATUS_CODE_ACTIVE
        "non-reuse identification type"   | "otp"              | "Y"             | "PUK"                   | ProfileOrchestrationConstants.STATUS_CODE_REGISTERED
        "delete all on success for reuse" | "puk"              | "ALL"           | "PUK"                   | ProfileOrchestrationConstants.STATUS_CODE_ACTIVE
    }

    // Added tests to cover COSMOS error branches inside existing spec
    def "should return error when Cosmos updateSecurityCode fails"() {
        given:
        featureManager.getValue(_ as String) >> "COSMOSMASTER"

        Map<String, Object> updateSecurityCodeSuccessResp = new HashMap<>()
        updateSecurityCodeSuccessResp.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)

        Map<String, Object> updateAccountFailResp = new HashMap<>()
        updateAccountFailResp.put(CommonDefs.COMMON_APP_STATUS_CODE, CErrorDefs.ERR_INVALID_RECORD_DB)

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.CALLING_SYSTEM_ID, "CHAN")
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, "IDSEMOB")
        hmInputLocal.put(CommonDefs.SECURITY_CODE, "123456")
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, "Y")

        Map<String, Object> hmSecurityCodeRespLocal = new HashMap<>()
        hmSecurityCodeRespLocal.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        List<Map<String, Object>> alSecurityCodeDataLocal = new ArrayList<>()
        Map<String, Object> hmDBSecurityCode = new HashMap<>()
        hmDBSecurityCode.put(MPSDefs.DB_SECURITY_CODE, "ENCRYPTED_DIFFERENT")
        hmDBSecurityCode.put(MPSDefs.DB_VERIFICATION_FAILURE_COUNT, Integer.valueOf(1))
        hmDBSecurityCode.put(MPSDefs.EXCEEDED_UNLOCKED_TIME, "0")
        hmDBSecurityCode.put(MPSDefs.DB_DELIVERY_METHOD, "E")
        hmDBSecurityCode.put(MPSDefs.DB_DELIVERY_DETAIL, "user@att.com")
        hmDBSecurityCode.put(MPSDefs.DB_CREATE_DATE, "2024-01-01")
        alSecurityCodeDataLocal.add(hmDBSecurityCode)
        hmSecurityCodeRespLocal.put(MPSDefs.SECURITY_CODE_INFO, alSecurityCodeDataLocal)

        when:
        Map<String, Object> result = validatePINHelperObj.validatePIN(hmInputLocal)

        then:
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == "122"

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "COSMOSMASTER"
        1 * proofingEncryptionHelper.generateSHA1Value("123456") >> "ENCRYPTED_MATCH"
        1 * idgOtpDBHelper.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal

        // IDG update is invoked once with the expected map and operation
        1 * idgOtpDBHelper.updateSecurityCode(
                { Map<String, Object> hmUpdateInp ->
                    hmUpdateInp.get(MPSDefs.DB_REASON_CODE) == "FAILED" &&
                            hmUpdateInp.get(MPSDefs.DB_ACCOUNT_ID) == "000981453456" &&
                            hmUpdateInp.get(MPSDefs.DB_IDENTIFICATION_TYPE) == "IDSEMOB" &&
                            hmUpdateInp.get(MPSDefs.DB_LAST_MODIFIED_BY) == "CHAN" &&
                            hmUpdateInp.get(MPSDefs.MAX_FAILURE_COUNT) == "5"
                },
                MPSDefs.INCREMENT_FAILURE_COUNT
        ) >> updateSecurityCodeSuccessResp

        // Cosmos updateSecurityCode succeeds
        1 * securityCodeDBHelperObj.updateSecurityCode(
                { Map<String, Object> hmUpdateInp ->
                    hmUpdateInp.get(MPSDefs.DB_IDENTIFICATION_TYPE) == "IDSEMOB" &&
                            hmUpdateInp.get(MPSDefs.DB_ACCOUNT_ID) == "000981453456" &&
                            hmUpdateInp.get(MPSDefs.DB_LAST_MODIFIED_BY) == "CHAN" &&
                            hmUpdateInp.get(MPSDefs.MAX_FAILURE_COUNT) == "5" &&
                            hmUpdateInp.get(MPSDefs.DB_REASON_CODE) == "FAILED"
                },
                MPSDefs.INCREMENT_FAILURE_COUNT
        ) >> updateSecurityCodeSuccessResp

        // Cosmos account update fails, driving system error 999
        1 * securityCodeDBHelperObj.updateSecurityAccount({ Map<String, Object> m ->
            m.get("reason_code") == "FAILED" &&
                    m.get("account_id") == hmInputLocal.get(CommonDefs.ACCOUNT_ID) &&
                    m.get("identification_type") == "IDSEMOB" &&
                    m.get("last_modified_by") == "CHAN" &&
                    m.get("max_failure_count") == "5"
        }, false) >> updateAccountFailResp

        0 * errMetricHandler.recordDBErrorMetric(_ as String)
        0 * objDeletePINHelper._
        0 * cgHelper._
        0 * cosmosDataStore._
        0 * _
    }
    // ============================================================
    // Tests for Cosmos DB error handling in ORACLEMASTER mode
    // (commit 2db8962c - VPH_21a/c, VPH_24a/c, VPH_27a/c)
    // ============================================================

    def "ORACLEMASTER: Cosmos updateSecurityCode error response is logged and processing continues (incrementFailure)"() {
        given: "ORACLEMASTER mode with incorrect code triggering incrementFailure path"
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, 'IDSEMOB')
        hmInputLocal.put(CommonDefs.SECURITY_CODE, '123456')
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, 'Y')

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = 'DIFFERENT_CODE'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = 'user@att.com'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        HashMap hmSuccessResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        HashMap hmCosmosErrorResp = new HashMap()
        hmCosmosErrorResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.ERR_INVALID_RECORD_DB

        featureManager.getValue(_ as String) >> 'ORACLEMASTER'
        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '123456'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        securityCodeDBHelperObj.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >> hmSuccessResp
        securityCodeDBHelperObj.updateSecurityAccount(_ as HashMap, false) >> hmSuccessResp
        // Cosmos updateSecurityCode returns error
        idgOtpDBHelper.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >> hmCosmosErrorResp
        // Cosmos updateSecurityAccount succeeds
        idgOtpDBHelper.updateSecurityAccount(_ as HashMap) >> hmSuccessResp

        when:
        def result = validatePINHelperObj.validatePIN(hmInputLocal)

        then: "Processing continues despite Cosmos error - returns incorrect code error"
        result != null
        result[CommonDefs.COMMON_APP_STATUS_CODE] != null
        // Should NOT return the Cosmos error - should continue and return incorrect code result
        result[CommonDefs.REMAINING_CODES] != null
    }

    def "ORACLEMASTER: Cosmos updateSecurityCode exception is caught and processing continues (incrementFailure)"() {
        given: "ORACLEMASTER mode with Cosmos throwing exception on updateSecurityCode"
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, 'IDSEMOB')
        hmInputLocal.put(CommonDefs.SECURITY_CODE, '123456')
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, 'Y')

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = 'DIFFERENT_CODE'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = 'user@att.com'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        HashMap hmSuccessResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        featureManager.getValue(_ as String) >> 'ORACLEMASTER'
        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '123456'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        securityCodeDBHelperObj.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >> hmSuccessResp
        securityCodeDBHelperObj.updateSecurityAccount(_ as HashMap, false) >> hmSuccessResp
        // Cosmos updateSecurityCode throws exception
        idgOtpDBHelper.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >> { throw new RuntimeException("Cosmos connection timeout") }
        // Cosmos updateSecurityAccount should still be called
        idgOtpDBHelper.updateSecurityAccount(_ as HashMap) >> hmSuccessResp

        when:
        def result = validatePINHelperObj.validatePIN(hmInputLocal)

        then: "Exception is caught, processing continues - returns incorrect code result"
        result != null
        result[CommonDefs.REMAINING_CODES] != null
        notThrown(RuntimeException)
    }

    def "COSMOSMASTER: Cosmos updateSecurityCode exception is re-thrown (incrementFailure)"() {
        given: "COSMOSMASTER mode with Cosmos throwing exception on updateSecurityCode"
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, 'IDSEMOB')
        hmInputLocal.put(CommonDefs.SECURITY_CODE, '123456')
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, 'Y')

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = 'DIFFERENT_CODE'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = 'user@att.com'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        HashMap hmSuccessResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        featureManager.getValue(_ as String) >> 'COSMOSMASTER'
        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '123456'
        idgOtpDBHelper.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        // Cosmos updateSecurityCode throws exception in COSMOSMASTER - should propagate
        idgOtpDBHelper.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >> { throw new RuntimeException("Cosmos connection timeout") }

        when:
        def result = validatePINHelperObj.validatePIN(hmInputLocal)

        then: "Exception propagates to outer catch, returning system error"
        result != null
        result[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "ORACLEMASTER: Cosmos updateSecurityAccount error response is logged and processing continues"() {
        given: "ORACLEMASTER mode with Cosmos updateSecurityAccount returning error"
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, 'IDSEMOB')
        hmInputLocal.put(CommonDefs.SECURITY_CODE, '123456')
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, 'Y')

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = 'DIFFERENT_CODE'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = 'user@att.com'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        HashMap hmSuccessResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        HashMap hmCosmosErrorResp = new HashMap()
        hmCosmosErrorResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.ERR_INVALID_RECORD_DB

        featureManager.getValue(_ as String) >> 'ORACLEMASTER'
        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '123456'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        securityCodeDBHelperObj.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >> hmSuccessResp
        securityCodeDBHelperObj.updateSecurityAccount(_ as HashMap, false) >> hmSuccessResp
        // Cosmos updateSecurityCode succeeds
        idgOtpDBHelper.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >> hmSuccessResp
        // Cosmos updateSecurityAccount returns error
        idgOtpDBHelper.updateSecurityAccount(_ as HashMap) >> hmCosmosErrorResp

        when:
        def result = validatePINHelperObj.validatePIN(hmInputLocal)

        then: "Processing continues despite Cosmos updateSecurityAccount error"
        result != null
        result[CommonDefs.REMAINING_CODES] != null
    }

    def "ORACLEMASTER: Cosmos updateSecurityAccount exception is caught and processing continues"() {
        given: "ORACLEMASTER mode with Cosmos throwing exception on updateSecurityAccount"
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, 'IDSEMOB')
        hmInputLocal.put(CommonDefs.SECURITY_CODE, '123456')
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, 'Y')

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = 'DIFFERENT_CODE'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = 'user@att.com'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        HashMap hmSuccessResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        featureManager.getValue(_ as String) >> 'ORACLEMASTER'
        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '123456'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        securityCodeDBHelperObj.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >> hmSuccessResp
        securityCodeDBHelperObj.updateSecurityAccount(_ as HashMap, false) >> hmSuccessResp
        idgOtpDBHelper.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >> hmSuccessResp
        // Cosmos updateSecurityAccount throws exception
        idgOtpDBHelper.updateSecurityAccount(_ as HashMap) >> { throw new RuntimeException("Cosmos timeout") }

        when:
        def result = validatePINHelperObj.validatePIN(hmInputLocal)

        then: "Exception is caught, processing continues"
        result != null
        result[CommonDefs.REMAINING_CODES] != null
        notThrown(RuntimeException)
    }

    def "COSMOSMASTER: Cosmos updateSecurityAccount exception is re-thrown"() {
        given: "COSMOSMASTER mode with Cosmos throwing exception on updateSecurityAccount"
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, 'IDSEMOB')
        hmInputLocal.put(CommonDefs.SECURITY_CODE, '123456')
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, 'Y')

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = 'DIFFERENT_CODE'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = 'user@att.com'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        HashMap hmSuccessResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        featureManager.getValue(_ as String) >> 'COSMOSMASTER'
        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '123456'
        idgOtpDBHelper.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        idgOtpDBHelper.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >> hmSuccessResp
        securityCodeDBHelperObj.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >> hmSuccessResp
        securityCodeDBHelperObj.updateSecurityAccount(_ as HashMap, false) >> hmSuccessResp
        // Cosmos updateSecurityAccount throws exception in COSMOSMASTER - should propagate
        idgOtpDBHelper.updateSecurityAccount(_ as HashMap) >> { throw new RuntimeException("Cosmos timeout") }

        when:
        def result = validatePINHelperObj.validatePIN(hmInputLocal)

        then: "Exception propagates to outer catch, returning system error"
        result != null
        result[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "ORACLEMASTER: Cosmos updateSecurityCode (unlock) error response is logged and processing continues"() {
        given: "ORACLEMASTER mode with unlock path - Cosmos updateSecurityCode returns error"
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, 'IDSEMOB')
        hmInputLocal.put(CommonDefs.SECURITY_CODE, '123456')
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, 'Y')

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '123456'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '5'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = 'user@att.com'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        HashMap hmSuccessResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        HashMap hmCosmosErrorResp = new HashMap()
        hmCosmosErrorResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.ERR_INVALID_RECORD_DB
        HashMap hmDeleteSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        featureManager.getValue(_ as String) >> 'ORACLEMASTER'
        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '123456'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        // Oracle unlock succeeds
        securityCodeDBHelperObj.updateSecurityCode(_ as HashMap, MPSDefs.UNLOCK_SECURITY_CODES) >> hmSuccessResp
        // Cosmos unlock returns error
        idgOtpDBHelper.updateSecurityCode(_ as HashMap, MPSDefs.UNLOCK_SECURITY_CODES) >> hmCosmosErrorResp
        objDeletePINHelper.deletePin(_ as HashMap) >> hmDeleteSuccess

        when:
        def result = validatePINHelperObj.validatePIN(hmInputLocal)

        then: "Processing continues despite Cosmos unlock error"
        result != null
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    def "ORACLEMASTER: Cosmos updateSecurityCode (unlock) exception is caught and processing continues"() {
        given: "ORACLEMASTER mode with unlock path - Cosmos throws exception"
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, 'IDSEMOB')
        hmInputLocal.put(CommonDefs.SECURITY_CODE, '123456')
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, 'Y')

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '123456'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '5'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = 'user@att.com'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        HashMap hmSuccessResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        HashMap hmDeleteSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        featureManager.getValue(_ as String) >> 'ORACLEMASTER'
        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '123456'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        securityCodeDBHelperObj.updateSecurityCode(_ as HashMap, MPSDefs.UNLOCK_SECURITY_CODES) >> hmSuccessResp
        // Cosmos unlock throws exception
        idgOtpDBHelper.updateSecurityCode(_ as HashMap, MPSDefs.UNLOCK_SECURITY_CODES) >> { throw new RuntimeException("Cosmos timeout") }
        objDeletePINHelper.deletePin(_ as HashMap) >> hmDeleteSuccess

        when:
        def result = validatePINHelperObj.validatePIN(hmInputLocal)

        then: "Exception is caught, processing continues to success"
        result != null
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        notThrown(RuntimeException)
    }

    def "should return error when Cosmos updateSecurityAccount fails"() {
        given:
        featureManager.getValue(_ as String) >> "COSMOSMASTER"

        Map<String, Object> updateSecurityCodeSuccessResp = new HashMap<>()
        updateSecurityCodeSuccessResp.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)

        Map<String, Object> updateAccountFailResp = new HashMap<>()
        updateAccountFailResp.put(CommonDefs.COMMON_APP_STATUS_CODE, CErrorDefs.ERR_INVALID_RECORD_DB)

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.CALLING_SYSTEM_ID, "CHAN")
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, "IDSEMOB")
        hmInputLocal.put(CommonDefs.SECURITY_CODE, "123456")
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, "Y")

        Map<String, Object> hmSecurityCodeRespLocal = new HashMap<>()
        hmSecurityCodeRespLocal.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        List<Map<String, Object>> alSecurityCodeDataLocal = new ArrayList<>()
        Map<String, Object> hmDBSecurityCode = new HashMap<>()
        hmDBSecurityCode.put(MPSDefs.DB_SECURITY_CODE, "ENCRYPTED_DIFFERENT")
        hmDBSecurityCode.put(MPSDefs.DB_VERIFICATION_FAILURE_COUNT, Integer.valueOf(1))
        hmDBSecurityCode.put(MPSDefs.EXCEEDED_UNLOCKED_TIME, "0")
        hmDBSecurityCode.put(MPSDefs.DB_DELIVERY_METHOD, "E")
        hmDBSecurityCode.put(MPSDefs.DB_DELIVERY_DETAIL, "user@att.com")
        hmDBSecurityCode.put(MPSDefs.DB_CREATE_DATE, "2024-01-01")
        alSecurityCodeDataLocal.add(hmDBSecurityCode)
        hmSecurityCodeRespLocal.put(MPSDefs.SECURITY_CODE_INFO, alSecurityCodeDataLocal)

        when:
        Map<String, Object> result = validatePINHelperObj.validatePIN(hmInputLocal)

        then:
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == "122"

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "COSMOSMASTER"
        1 * proofingEncryptionHelper.generateSHA1Value("123456") >> "ENCRYPTED_MATCH"
        1 * idgOtpDBHelper.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal

        // IDG update is invoked once with the expected map and operation
        1 * idgOtpDBHelper.updateSecurityCode(
                { Map<String, Object> hmUpdateInp ->
                    hmUpdateInp.get(MPSDefs.DB_REASON_CODE) == "FAILED" &&
                            hmUpdateInp.get(MPSDefs.DB_ACCOUNT_ID) == "000981453456" &&
                            hmUpdateInp.get(MPSDefs.DB_IDENTIFICATION_TYPE) == "IDSEMOB" &&
                            hmUpdateInp.get(MPSDefs.DB_LAST_MODIFIED_BY) == "CHAN" &&
                            hmUpdateInp.get(MPSDefs.MAX_FAILURE_COUNT) == "5"
                },
                MPSDefs.INCREMENT_FAILURE_COUNT
        ) >> updateSecurityCodeSuccessResp

        // Cosmos updateSecurityCode succeeds
        1 * securityCodeDBHelperObj.updateSecurityCode(
                { Map<String, Object> hmUpdateInp ->
                    hmUpdateInp.get(MPSDefs.DB_IDENTIFICATION_TYPE) == "IDSEMOB" &&
                            hmUpdateInp.get(MPSDefs.DB_ACCOUNT_ID) == "000981453456" &&
                            hmUpdateInp.get(MPSDefs.DB_LAST_MODIFIED_BY) == "CHAN" &&
                            hmUpdateInp.get(MPSDefs.MAX_FAILURE_COUNT) == "5" &&
                            hmUpdateInp.get(MPSDefs.DB_REASON_CODE) == "FAILED"
                },
                MPSDefs.INCREMENT_FAILURE_COUNT
        ) >> updateSecurityCodeSuccessResp

        // Cosmos updateSecurityAccount fails
        1 * securityCodeDBHelperObj.updateSecurityAccount(
                { Map<String, Object> oracleAccUpd ->
                    oracleAccUpd.get("reason_code") == "FAILED" &&
                            oracleAccUpd.get("account_id") == hmInputLocal.get(CommonDefs.ACCOUNT_ID) &&
                            oracleAccUpd.get("identification_type") == "IDSEMOB" &&
                            oracleAccUpd.get("last_modified_by") == "CHAN" &&
                            oracleAccUpd.get("max_failure_count") == "5"
                },
                false
        ) >> updateAccountFailResp
        0 * errMetricHandler.recordDBErrorMetric(_ as String)
        0 * objDeletePINHelper._
        0 * cgHelper._
        0 * cosmosDataStore._
        0 * _
    }

    @Unroll
    def "should return ERR_ACCOUNT_LOCKOUT for account lockout"() {
        given: "A security code DB response with all codes FAILED and failure count 6"
        HashMap hmInput = new HashMap()
        hmInput['accountId'] = '09230927'
        hmInput['identificationType'] = 'BSSEGENE'
        hmInput['securityCode'] = 'testcode'
        hmInput['agentId'] = 'rb830a'
        hmInput['deletePINOnSuccess'] = 'NONE'
        hmInput['transactionName'] = 'ValidatePIN'
        hmInput['callingSystemId'] = 'CCMULE'


        ArrayList<HashMap> alSecurityCodeData = new ArrayList<>()
        HashMap hmDBSecurityCode1 = new HashMap()
        hmDBSecurityCode1[MPSDefs.DB_SECURITY_CODE] = 'FcGVbhana5KDmiiFLmtwj/g7R1h1XJ4ACQMKDK1bZB8='
        hmDBSecurityCode1[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 6
        hmDBSecurityCode1[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '-43.041666666666664'
        hmDBSecurityCode1[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode1[MPSDefs.DB_DELIVERY_DETAIL] = 'rb830a@att.com'
        hmDBSecurityCode1[MPSDefs.DB_CREATE_DATE] = '02112026 00:39:54'
        hmDBSecurityCode1["security_code_status"] = 'FAILED'
        alSecurityCodeData.add(hmDBSecurityCode1)

        HashMap hmDBSecurityCode2 = new HashMap()
        hmDBSecurityCode2[MPSDefs.DB_SECURITY_CODE] = 'PLjfPu+fPCqIm+344rsAo10EZGR1s4QSsyJFckis0uM='
        hmDBSecurityCode2[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 6
        hmDBSecurityCode2[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '-47.041666666666664'
        hmDBSecurityCode2[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode2[MPSDefs.DB_DELIVERY_DETAIL] = 'rb830a@att.com'
        hmDBSecurityCode2[MPSDefs.DB_CREATE_DATE] = '02112026 00:43:09'
        hmDBSecurityCode2["security_code_status"] = 'FAILED'
        alSecurityCodeData.add(hmDBSecurityCode2)

        HashMap hmDBSecurityCode3 = new HashMap()
        hmDBSecurityCode3[MPSDefs.DB_SECURITY_CODE] = 'NDSyQbb+EAQKoohM1k2xaSh5eaqJ5KJ6bE/6eAeNau0='
        hmDBSecurityCode3[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 6
        hmDBSecurityCode3[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '-52.041666666666664'
        hmDBSecurityCode3[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode3[MPSDefs.DB_DELIVERY_DETAIL] = 'rb830a@att.com'
        hmDBSecurityCode3[MPSDefs.DB_CREATE_DATE] = '02112026 00:48:32'
        hmDBSecurityCode3["security_code_status"] = 'FAILED'
        alSecurityCodeData.add(hmDBSecurityCode3)

        HashMap hmSecurityCodeResp = new HashMap()
        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeResp[MPSDefs.SECURITY_CODE_INFO] = alSecurityCodeData
        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_MSG] = CommonDefs.COMMON_SUCCESS_MSG
        hmSecurityCodeResp[MPSDefs.SECURITY_CODE_COUNT] = 3


        HashMap hmResultSuccess = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)



        when: "validatePIN is called with input that triggers account lockout"
        HashMap hmResponse = validatePINHelperObj.validatePIN(hmInput)

        then: "Response contains ERR_ACCOUNT_LOCKOUT and all relevant attributes"
        featureManager.getValue(_ as String) >> 'ONLYCOSMOS'
        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        idgOtpDBHelper.getSecurityCodeDataQuery(_)>> hmSecurityCodeResp
        idgOtpDBHelper.updateUnlockAccountTime() >> true
        idgOtpDBHelper.updateSecurityCode(_ as HashMap, _)>>hmResultSuccess
        idgOtpDBHelper.updateSecurityAccount(_ as HashMap)>>hmResultSuccess
        and: "Validate all response attributes"
        hmResponse != null
        hmResponse.get(CommonDefs.COMMON_APP_STATUS_MSG) == CErrorDefs.ERR_ACCOUNT_LOCKOUT_MSG
        hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_ACCOUNT_LOCKOUT
    }

    @Unroll
    def "should return ERR_ACCOUNT_LOCKOUT for account lockout when its COSMOSMASTER"() {
        given: "A security code DB response with all codes FAILED and failure count 6"
        HashMap hmInput = new HashMap()
        hmInput['accountId'] = '09230927'
        hmInput['identificationType'] = 'BSSEGENE'
        hmInput['securityCode'] = 'testcode'
        hmInput['agentId'] = 'rb830a'
        hmInput['deletePINOnSuccess'] = 'NONE'
        hmInput['transactionName'] = 'ValidatePIN'
        hmInput['callingSystemId'] = 'CCMULE'


        ArrayList<HashMap> alSecurityCodeData = new ArrayList<>()
        HashMap hmDBSecurityCode1 = new HashMap()
        hmDBSecurityCode1[MPSDefs.DB_SECURITY_CODE] = 'FcGVbhana5KDmiiFLmtwj/g7R1h1XJ4ACQMKDK1bZB8='
        hmDBSecurityCode1[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 6
        hmDBSecurityCode1[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '-43.041666666666664'
        hmDBSecurityCode1[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode1[MPSDefs.DB_DELIVERY_DETAIL] = 'rb830a@att.com'
        hmDBSecurityCode1[MPSDefs.DB_CREATE_DATE] = '02112026 00:39:54'
        hmDBSecurityCode1["security_code_status"] = 'FAILED'
        alSecurityCodeData.add(hmDBSecurityCode1)

        HashMap hmDBSecurityCode2 = new HashMap()
        hmDBSecurityCode2[MPSDefs.DB_SECURITY_CODE] = 'PLjfPu+fPCqIm+344rsAo10EZGR1s4QSsyJFckis0uM='
        hmDBSecurityCode2[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 6
        hmDBSecurityCode2[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '-47.041666666666664'
        hmDBSecurityCode2[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode2[MPSDefs.DB_DELIVERY_DETAIL] = 'rb830a@att.com'
        hmDBSecurityCode2[MPSDefs.DB_CREATE_DATE] = '02112026 00:43:09'
        hmDBSecurityCode2["security_code_status"] = 'FAILED'
        alSecurityCodeData.add(hmDBSecurityCode2)

        HashMap hmDBSecurityCode3 = new HashMap()
        hmDBSecurityCode3[MPSDefs.DB_SECURITY_CODE] = 'NDSyQbb+EAQKoohM1k2xaSh5eaqJ5KJ6bE/6eAeNau0='
        hmDBSecurityCode3[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 6
        hmDBSecurityCode3[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '-52.041666666666664'
        hmDBSecurityCode3[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode3[MPSDefs.DB_DELIVERY_DETAIL] = 'rb830a@att.com'
        hmDBSecurityCode3[MPSDefs.DB_CREATE_DATE] = '02112026 00:48:32'
        hmDBSecurityCode3["security_code_status"] = 'FAILED'
        alSecurityCodeData.add(hmDBSecurityCode3)

        HashMap hmSecurityCodeResp = new HashMap()
        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeResp[MPSDefs.SECURITY_CODE_INFO] = alSecurityCodeData
        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_MSG] = CommonDefs.COMMON_SUCCESS_MSG
        hmSecurityCodeResp[MPSDefs.SECURITY_CODE_COUNT] = 3

        HashMap hmResultSuccess = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)

        when: "validatePIN is called with input that triggers account lockout"
        HashMap hmResponse = validatePINHelperObj.validatePIN(hmInput)

        then: "Response contains ERR_ACCOUNT_LOCKOUT and all relevant attributes"
        featureManager.getValue(_ as String) >> 'COSMOSMASTER'
        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        idgOtpDBHelper.getSecurityCodeDataQuery(_)>> hmSecurityCodeResp
        idgOtpDBHelper.updateUnlockAccountTime() >> true
        idgOtpDBHelper.updateSecurityCode(_ as HashMap, _)>>hmResultSuccess
        idgOtpDBHelper.updateSecurityAccount(_ as HashMap)>>hmResultSuccess
        securityCodeDBHelperObj.updateSecurityCode(_,_)>>hmSecurityCodeResp
        securityCodeDBHelperObj.updateSecurityAccount(_,_)>>hmResultSuccess
        and: "Validate all response attributes"
        hmResponse != null
        hmResponse.get(CommonDefs.COMMON_APP_STATUS_MSG) == CErrorDefs.ERR_ACCOUNT_LOCKOUT_MSG
        hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_ACCOUNT_LOCKOUT
    }


    @Unroll
    def "should handle exception when updateUnlockAccountTime throws for #scenarioName"() {
        given: "A request and mocked dependencies for exception scenario"
        Map<String, Object> hmInput = new HashMap<>()
        hmInput.put('accountId', sAccountId)
        hmInput.put('identificationType', sIdentificationType)
        hmInput.put('securityCode', 'testcode')
        hmInput.put('agentId', 'rb830a')
        hmInput.put('deletePINOnSuccess', 'NONE')
        hmInput.put('transactionName', 'ValidatePIN')
        hmInput.put('callingSystemId', sCallingSystemId)

        List<Map<String, Object>> alSecurityCodeData = new ArrayList<>()
        Map<String, Object> hmDBSecurityCode1 = new HashMap<>()
        hmDBSecurityCode1.put(MPSDefs.DB_SECURITY_CODE, 'FcGVbhana5KDmiiFLmtwj/g7R1h1XJ4ACQMKDK1bZB8=')
        hmDBSecurityCode1.put(MPSDefs.DB_VERIFICATION_FAILURE_COUNT, 6)
        hmDBSecurityCode1.put(MPSDefs.EXCEEDED_UNLOCKED_TIME, '-43.041666666666664')
        hmDBSecurityCode1.put(MPSDefs.DB_DELIVERY_METHOD, 'E')
        hmDBSecurityCode1.put(MPSDefs.DB_DELIVERY_DETAIL, 'rb830a@att.com')
        hmDBSecurityCode1.put(MPSDefs.DB_CREATE_DATE, '02112026 00:39:54')
        hmDBSecurityCode1.put('security_code_status', 'FAILED')
        alSecurityCodeData.add(hmDBSecurityCode1)

        Map<String, Object> hmDBSecurityCode2 = new HashMap<>()
        hmDBSecurityCode2.put(MPSDefs.DB_SECURITY_CODE, 'PLjfPu+fPCqIm+344rsAo10EZGR1s4QSsyJFckis0uM=')
        hmDBSecurityCode2.put(MPSDefs.DB_VERIFICATION_FAILURE_COUNT, 6)
        hmDBSecurityCode2.put(MPSDefs.EXCEEDED_UNLOCKED_TIME, '-47.041666666666664')
        hmDBSecurityCode2.put(MPSDefs.DB_DELIVERY_METHOD, 'E')
        hmDBSecurityCode2.put(MPSDefs.DB_DELIVERY_DETAIL, 'rb830a@att.com')
        hmDBSecurityCode2.put(MPSDefs.DB_CREATE_DATE, '02112026 00:43:09')
        hmDBSecurityCode2.put('security_code_status', 'FAILED')
        alSecurityCodeData.add(hmDBSecurityCode2)

        Map<String, Object> hmDBSecurityCode3 = new HashMap<>()
        hmDBSecurityCode3.put(MPSDefs.DB_SECURITY_CODE, 'NDSyQbb+EAQKoohM1k2xaSh5eaqJ5KJ6bE/6eAeNau0=')
        hmDBSecurityCode3.put(MPSDefs.DB_VERIFICATION_FAILURE_COUNT, 6)
        hmDBSecurityCode3.put(MPSDefs.EXCEEDED_UNLOCKED_TIME, '-52.041666666666664')
        hmDBSecurityCode3.put(MPSDefs.DB_DELIVERY_METHOD, 'E')
        hmDBSecurityCode3.put(MPSDefs.DB_DELIVERY_DETAIL, 'rb830a@att.com')
        hmDBSecurityCode3.put(MPSDefs.DB_CREATE_DATE, '02112026 00:48:32')
        hmDBSecurityCode3.put('security_code_status', 'FAILED')
        alSecurityCodeData.add(hmDBSecurityCode3)

        Map<String, Object> hmSecurityCodeResp = new HashMap<>()
        hmSecurityCodeResp.put(CommonDefs.COMMON_APP_STATUS_CODE, CErrorDefs.COMMON_SUCCESS)
        hmSecurityCodeResp.put(MPSDefs.SECURITY_CODE_INFO, alSecurityCodeData)
        hmSecurityCodeResp.put(CommonDefs.COMMON_APP_STATUS_MSG, CommonDefs.COMMON_SUCCESS_MSG)
        hmSecurityCodeResp.put(MPSDefs.SECURITY_CODE_COUNT, 3)

        featureManager.getValue(_) >> 'COSMOSMASTER'
        proofingEncryptionHelper.generateSHA1Value(_) >> '1990122'
        idgOtpDBHelper.getSecurityCodeDataQuery(_) >> hmSecurityCodeResp
        idgOtpDBHelper.updateUnlockAccountTime(_,_,_,_) >> { throw new Exception("DB update failed") }

        when: "Method under test calls updateUnlockAccountTime and exception is thrown"
        HashMap hmResponse= validatePINHelperObj.validatePIN(hmInput)

        then: "Exception is thrown and no other interactions occur"
        hmResponse != null
        hmResponse.get(CommonDefs.COMMON_APP_STATUS_MSG) == CErrorDefs.ERR_SYS_APPL_MSG
        hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_SYS_APPL

        where:
        scenarioName            | sIdentificationType | sAccountId   | unlockMinutesVal | sCallingSystemId
        "Standard exception"    | "BSSEGENE"        | "09230927"   | 60.0            | "CCMULE"
        "Edge case exception"   | "EMAILOTP"         | "12345678"   | 0.0             | "SYSTEMX"
    }

    // ============================================================
    // High-impact tests for parseOtpUnlockAccountMinutes (covers ~20 lines)
    // ============================================================

    def "parseOtpUnlockAccountMinutes returns correct map for valid property"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propOtpUnlockAccountMinutes', 'BSSEGENS:360|BSSEGENE:360|EMAILOTP:120')

        when:
        HashMap<String, String> result = validatePINHelperObj.parseOtpUnlockAccountMinutes()

        then:
        result.size() == 3
        result['BSSEGENS'] == '360'
        result['BSSEGENE'] == '360'
        result['EMAILOTP'] == '120'
        0 * _
    }

    def "parseOtpUnlockAccountMinutes returns empty map for null property"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propOtpUnlockAccountMinutes', null)

        when:
        HashMap<String, String> result = validatePINHelperObj.parseOtpUnlockAccountMinutes()

        then:
        result.isEmpty()
        0 * _
    }

    def "parseOtpUnlockAccountMinutes returns empty map for empty string"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propOtpUnlockAccountMinutes', '   ')

        when:
        HashMap<String, String> result = validatePINHelperObj.parseOtpUnlockAccountMinutes()

        then:
        result.isEmpty()
        0 * _
    }

    def "parseOtpUnlockAccountMinutes skips malformed pairs"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propOtpUnlockAccountMinutes', 'BSSEGENS:360|BADENTRY|:120|GOOD:60')

        when:
        HashMap<String, String> result = validatePINHelperObj.parseOtpUnlockAccountMinutes()

        then:
        result.size() == 2
        result['BSSEGENS'] == '360'
        result['GOOD'] == '60'
        0 * _
    }

    def "parseOtpUnlockAccountMinutes skips entries with empty key or value"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propOtpUnlockAccountMinutes', ':360|BSSEGENE:')

        when:
        HashMap<String, String> result = validatePINHelperObj.parseOtpUnlockAccountMinutes()

        then:
        result.isEmpty()
        0 * _
    }

    // ============================================================
    // High-impact tests for updateUnlockTime (covers ~40 lines)
    // ============================================================

    def "updateUnlockTime returns true when unlock is successful"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propOtpUnlockAccountMinutes', 'BSSEGENE:360')
        idgOtpDBHelper.updateUnlockAccountTime('BSSEGENE', 'acct123', 360, 'CCMULE') >> true

        when:
        boolean result = validatePINHelperObj.updateUnlockTime('BSSEGENE', 'acct123', null, 'CCMULE')

        then:
        result == true
    }

    def "updateUnlockTime returns false when existing unlock time is in the future"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propOtpUnlockAccountMinutes', 'BSSEGENE:360')
        String futureTime = Instant.now().plusSeconds(7200).toString()

        when:
        boolean result = validatePINHelperObj.updateUnlockTime('BSSEGENE', 'acct123', futureTime, 'CCMULE')

        then:
        result == false
        0 * idgOtpDBHelper.updateUnlockAccountTime(_, _, _, _)
    }

    def "updateUnlockTime updates when existing unlock time is in the past"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propOtpUnlockAccountMinutes', 'BSSEGENE:360')
        String pastTime = Instant.now().minusSeconds(7200).toString()
        idgOtpDBHelper.updateUnlockAccountTime('BSSEGENE', 'acct123', 360, 'CCMULE') >> true

        when:
        boolean result = validatePINHelperObj.updateUnlockTime('BSSEGENE', 'acct123', pastTime, 'CCMULE')

        then:
        result == true
    }

    def "updateUnlockTime throws ServiceException when identificationType not configured"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propOtpUnlockAccountMinutes', 'BSSEGENE:360')

        when:
        validatePINHelperObj.updateUnlockTime('UNKNOWN_TYPE', 'acct123', null, 'CCMULE')

        then:
        thrown(com.att.idp.core.exception.ServiceException)
        0 * idgOtpDBHelper.updateUnlockAccountTime(_, _, _, _)
    }

    def "updateUnlockTime returns false when DB update fails"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propOtpUnlockAccountMinutes', 'BSSEGENE:360')
        idgOtpDBHelper.updateUnlockAccountTime('BSSEGENE', 'acct123', 360, 'CCMULE') >> false

        when:
        boolean result = validatePINHelperObj.updateUnlockTime('BSSEGENE', 'acct123', null, 'CCMULE')

        then:
        result == false
    }

    def "updateUnlockTime throws when unlock minutes is not a valid number"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propOtpUnlockAccountMinutes', 'BSSEGENE:INVALID')

        when:
        validatePINHelperObj.updateUnlockTime('BSSEGENE', 'acct123', null, 'CCMULE')

        then:
        thrown(NumberFormatException)
    }

    // ============================================================
    // High-impact tests for updateIDMCosmosDB exception path (covers ~15 lines)
    // ============================================================

    def "updateIDMCosmosDB returns error when CosmosDataStore throws exception"() {
        given:
        Map<String, Object> hmCosmosInput = [
                "sessionId": "sess-exc",
                (CommonDefs.ACCOUNT_ID): "acct-exc",
                (CommonDefs.ACCOUNT_TYPE): "WIRELESS",
                (CommonDefs.CALLING_SYSTEM_ID): "OPUS",
                (CommonDefs.DELIVERY_METHOD): "S",
                (CommonDefs.DELIVERY_METHOD_VALUE): "5551234567"
        ]
        Map<String, Object> hmResult = [
                (CommonDefs.COMMON_APP_CATEGORY_CODE): CommonDefs.COMMON_SUCCESS,
                (CommonDefs.COMMON_APP_STATUS_MSG): "SuccessMsg",
                (CommonDefs.COMMON_APP_INFO): "Info"
        ]
        cosmosDataStore.PersistValidatePinInfoToDatabase(_ as ValidatePinInfoBean) >> { throw new RuntimeException("Cosmos write failure") }

        when:
        HashMap response = validatePINHelperObj.updateIDMCosmosDB(hmCosmosInput, hmResult)

        then:
        response != null
        response.get(CommonDefs.COMMON_APP_STATUS_MSG) == CErrorDefs.ERR_SYS_APPL_MSG
    }

    // ============================================================
    // High-impact tests for validatePIN COSMOSMASTER success with delete (covers ~60 lines)
    // ============================================================

    def "validatePIN COSMOSMASTER success path with delete and CSIGATEWAY caller returns securityCodeCreatedOn"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.CALLING_SYSTEM_ID, 'CSIGATEWAY')
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, 'IDSEMOB')
        hmInputLocal.put(CommonDefs.SECURITY_CODE, '123456')
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, 'Yes')

        // Compute the real SHA256+Base64 hash (metaClass mock doesn't intercept Java-to-Java calls)
        MessageDigest md = MessageDigest.getInstance('SHA-256')
        md.reset()
        md.update('123456'.getBytes())
        String sha256Hash = jakarta.xml.bind.DatatypeConverter.printBase64Binary(md.digest())

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = sha256Hash
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 0
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = 'user@att.com'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '20240615120000'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        HashMap hmSuccessRespLocal = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        HashMap hmDeleteSuccess = new HashMap()
        hmDeleteSuccess[CommonDefs.COMMON_APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS

        when:
        def result = validatePINHelperObj.validatePIN(hmInputLocal)

        then:
        1 * featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> 'COSMOSMASTER'
        _ * proofingEncryptionHelper.generateSHA1Value(_)
        1 * idgOtpDBHelper.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        _ * idgOtpDBHelper.updateSecurityCode(_, _) >> hmSuccessRespLocal
        _ * idgOtpDBHelper.updateSecurityAccount(_) >> hmSuccessRespLocal
        _ * securityCodeDBHelperObj.updateSecurityCode(_, _) >> hmSuccessRespLocal
        _ * securityCodeDBHelperObj.updateSecurityAccount(_, _) >> hmSuccessRespLocal
        _ * objDeletePINHelper.deletePin(_ as HashMap) >> hmDeleteSuccess
        _ * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()

        and:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        result[CommonDefs.SECURITY_CODE_CREATED_ON] == '20240615'
    }

    def "validatePIN COSMOSMASTER success path with EDS caller returns securityCodeCreatedOn"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.CALLING_SYSTEM_ID, 'EDS')
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, 'IDSEMOB')
        hmInputLocal.put(CommonDefs.SECURITY_CODE, '123456')
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, 'Yes')

        // Compute the real SHA256+Base64 hash (metaClass mock doesn't intercept Java-to-Java calls)
        MessageDigest mdEds = MessageDigest.getInstance('SHA-256')
        mdEds.reset()
        mdEds.update('123456'.getBytes())
        String sha256HashEds = jakarta.xml.bind.DatatypeConverter.printBase64Binary(mdEds.digest())

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = sha256HashEds
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 0
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '5551234567'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '20240615120000'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        HashMap hmSuccessRespLocal = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        HashMap hmDeleteSuccess = new HashMap()
        hmDeleteSuccess[CommonDefs.COMMON_APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS

        when:
        def result = validatePINHelperObj.validatePIN(hmInputLocal)

        then:
        1 * featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> 'COSMOSMASTER'
        _ * proofingEncryptionHelper.generateSHA1Value(_)
        1 * idgOtpDBHelper.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        _ * idgOtpDBHelper.updateSecurityCode(_, _) >> hmSuccessRespLocal
        _ * idgOtpDBHelper.updateSecurityAccount(_) >> hmSuccessRespLocal
        _ * securityCodeDBHelperObj.updateSecurityCode(_, _) >> hmSuccessRespLocal
        _ * securityCodeDBHelperObj.updateSecurityAccount(_, _) >> hmSuccessRespLocal
        _ * objDeletePINHelper.deletePin(_ as HashMap) >> hmDeleteSuccess
        _ * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()

        and:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        result[CommonDefs.SECURITY_CODE_CREATED_ON] == '20240615'
    }

    // ============================================================
    // High-impact test for validatePIN with accountType MOBILITY → WIRELESS cosmos mapping (covers ~20 lines)
    // ============================================================

    def "validatePIN COSMOSMASTER with MOBILITY accountType maps to WIRELESS in cosmos update"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')
        ReflectionTestUtils.setField(validatePINHelperObj, 'propCosmosUpdateCSI', 'OPUS|CCMULE')

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.CALLING_SYSTEM_ID, 'OPUS')
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, 'IDSEMOB')
        hmInputLocal.put(CommonDefs.SECURITY_CODE, '123456')
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, 'Yes')
        hmInputLocal.put(CommonDefs.ACCOUNT_TYPE, 'MOBILITY')
        hmInputLocal.put('idpSessionId', 'session-cosmos')

        // Compute the real SHA256+Base64 hash (metaClass mock doesn't intercept Java-to-Java calls)
        MessageDigest mdMob = MessageDigest.getInstance('SHA-256')
        mdMob.reset()
        mdMob.update('123456'.getBytes())
        String sha256HashMob = jakarta.xml.bind.DatatypeConverter.printBase64Binary(mdMob.digest())

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = sha256HashMob
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 0
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '5559876543'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '20240615120000'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        HashMap hmDeleteSuccess = new HashMap()
        hmDeleteSuccess[CommonDefs.COMMON_APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        HashMap hmSuccessResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        when:
        def result = validatePINHelperObj.validatePIN(hmInputLocal)

        then:
        1 * featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> 'COSMOSMASTER'
        _ * proofingEncryptionHelper.generateSHA1Value(_)
        1 * idgOtpDBHelper.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        _ * securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        _ * idgOtpDBHelper.updateSecurityCode(_, _) >> hmSuccessResp
        _ * idgOtpDBHelper.updateSecurityAccount(_) >> hmSuccessResp
        _ * securityCodeDBHelperObj.updateSecurityCode(_, _) >> hmSuccessResp
        _ * securityCodeDBHelperObj.updateSecurityAccount(_, _) >> hmSuccessResp
        _ * objDeletePINHelper.deletePin(_ as HashMap) >> hmDeleteSuccess
        _ * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()

        and:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS

        // Verify cosmos update is called with WIRELESS (mapped from MOBILITY)
        1 * cosmosDataStore.PersistValidatePinInfoToDatabase({ ValidatePinInfoBean bean ->
            bean.accountType == 'WIRELESS' &&
                    bean.sessionId == 'session-cosmos' &&
                    bean.status == 'SUCCESS' &&
                    bean.authenticationMethod == 'OTPSMS' &&
                    bean.phoneNumber == '5559876543'
        })
    }

    def "validatePIN COSMOSMASTER with TITAN accountType maps to UVERSE in cosmos update"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')
        ReflectionTestUtils.setField(validatePINHelperObj, 'propCosmosUpdateCSI', 'OPUS|CCMULE')

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.CALLING_SYSTEM_ID, 'CCMULE')
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, 'IDSEMOB')
        hmInputLocal.put(CommonDefs.SECURITY_CODE, '123456')
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, 'Yes')
        hmInputLocal.put(CommonDefs.ACCOUNT_TYPE, 'TITAN')
        hmInputLocal.put('idpSessionId', 'session-titan')

        // Compute the real SHA256+Base64 hash (metaClass mock doesn't intercept Java-to-Java calls)
        MessageDigest mdTitan = MessageDigest.getInstance('SHA-256')
        mdTitan.reset()
        mdTitan.update('123456'.getBytes())
        String sha256HashTitan = jakarta.xml.bind.DatatypeConverter.printBase64Binary(mdTitan.digest())

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = sha256HashTitan
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 0
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = 'test@att.com'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '20240615120000'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        HashMap hmDeleteSuccess = new HashMap()
        hmDeleteSuccess[CommonDefs.COMMON_APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        HashMap hmSuccessResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        when:
        def result = validatePINHelperObj.validatePIN(hmInputLocal)

        then:
        1 * featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> 'COSMOSMASTER'
        _ * proofingEncryptionHelper.generateSHA1Value(_)
        1 * idgOtpDBHelper.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        _ * securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        _ * idgOtpDBHelper.updateSecurityCode(_, _) >> hmSuccessResp
        _ * idgOtpDBHelper.updateSecurityAccount(_) >> hmSuccessResp
        _ * securityCodeDBHelperObj.updateSecurityCode(_, _) >> hmSuccessResp
        _ * securityCodeDBHelperObj.updateSecurityAccount(_, _) >> hmSuccessResp
        _ * objDeletePINHelper.deletePin(_ as HashMap) >> hmDeleteSuccess
        _ * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()

        and:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS

        1 * cosmosDataStore.PersistValidatePinInfoToDatabase({ ValidatePinInfoBean bean ->
            bean.accountType == 'UVERSE' &&
                    bean.sessionId == 'session-titan' &&
                    bean.status == 'SUCCESS' &&
                    bean.authenticationMethod == 'OTPEMAIL' &&
                    bean.emailAddress == 'test@att.com'
        })
    }

    // ============================================================
    // High-impact test for validatePIN finally block - null result path (covers ~15 lines)
    // ============================================================

    def "validatePIN returns ERR_SYS_APPL when hmResult is null in finally block"() {
        given:
        featureManager.getValue(_ as String) >> { throw new NullPointerException("simulated NPE") }

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)

        when:
        def result = validatePINHelperObj.validatePIN(hmInputLocal)

        then:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_MSG] == CErrorDefs.ERR_SYS_APPL_MSG
    }

    // ============================================================
    // High-impact test for validatePIN transaction rollback flag (covers ~10 lines)
    // ============================================================

    def "validatePIN sets isTransactionRollback Y for non-success non-lockout non-incorrect-code errors"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, 'IDSEMOB')
        hmInputLocal.put(CommonDefs.SECURITY_CODE, '123456')
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, 'Yes')
        hmInputLocal.put('isTransactionRollbackOnError', 'true')

        featureManager.getValue(_ as String) >> 'ORACLEMASTER'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> { throw new RuntimeException("DB connection failed") }

        when:
        def result = validatePINHelperObj.validatePIN(hmInputLocal)

        then:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_MSG] == CErrorDefs.ERR_SYS_APPL_MSG
    }

    @Unroll
    def "should throw ERR_ACCOUNT_LOCKOUT and not update unlockAccountTime if already exists with future date"() {
        given: "A security code DB response with all codes FAILED and failure count 6"
        HashMap hmInput = new HashMap()
        hmInput['accountId'] = '09230927'
        hmInput['identificationType'] = 'BSSEGENE'
        hmInput['securityCode'] = 'testcode'
        hmInput['agentId'] = 'rb830a'
        hmInput['deletePINOnSuccess'] = 'NONE'
        hmInput['transactionName'] = 'ValidatePIN'
        hmInput['callingSystemId'] = 'CCMULE'

        ArrayList<HashMap> alSecurityCodeData = new ArrayList<>()

        HashMap hmDBSecurityCode3 = new HashMap()
        hmDBSecurityCode3[MPSDefs.DB_SECURITY_CODE] = 'NDSyQbb+EAQKoohM1k2xaSh5eaqJ5KJ6bE/6eAeNau0='
        hmDBSecurityCode3[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 6
        hmDBSecurityCode3[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '-52.041666666666664'
        hmDBSecurityCode3[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode3[MPSDefs.DB_DELIVERY_DETAIL] = 'rb830a@att.com'
        hmDBSecurityCode3[MPSDefs.DB_CREATE_DATE] = '02112026 00:48:32'
        hmDBSecurityCode3["security_code_status"] = 'FAILED'
        alSecurityCodeData.add(hmDBSecurityCode3)

        HashMap hmSecurityCodeResp = new HashMap()
        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeResp[MPSDefs.SECURITY_CODE_INFO] = alSecurityCodeData
        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_MSG] = CommonDefs.COMMON_SUCCESS_MSG
        hmSecurityCodeResp[MPSDefs.SECURITY_CODE_COUNT] = 3
        hmSecurityCodeResp["unlockAccountTime"] = Instant.now().plusSeconds(3600) // Future unlock time

        HashMap hmResultSuccess = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)

        when: "validatePIN is called with input that triggers account lockout"
        HashMap hmResponse = validatePINHelperObj.validatePIN(hmInput)

        then: "Response contains ERR_ACCOUNT_LOCKOUT and all relevant attributes"
        featureManager.getValue(_ as String) >> 'COSMOSMASTER'
        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        idgOtpDBHelper.getSecurityCodeDataQuery(_)>> hmSecurityCodeResp
        idgOtpDBHelper.updateUnlockAccountTime() >> true
        idgOtpDBHelper.updateSecurityCode(_ as HashMap, _)>>hmResultSuccess
        idgOtpDBHelper.updateSecurityAccount(_ as HashMap)>>hmResultSuccess
        securityCodeDBHelperObj.updateSecurityCode(_,_)>>hmSecurityCodeResp
        securityCodeDBHelperObj.updateSecurityAccount(_,_)>>hmResultSuccess
        and: "Validate all response attributes"
        hmResponse != null
        hmResponse.get(CommonDefs.COMMON_APP_STATUS_MSG) == CErrorDefs.ERR_ACCOUNT_LOCKOUT_MSG
        hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_ACCOUNT_LOCKOUT
    }

    // ============================================================
    // ONLYCOSMOS data source query path
    // ============================================================

    def "validatePIN ONLYCOSMOS uses idgOtpDBHelper for getSecurityCodeDataQuery"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, 'IDSEMOB')
        hmInputLocal.put(CommonDefs.SECURITY_CODE, '123456')
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, 'Yes')

        MessageDigest md = MessageDigest.getInstance('SHA-256')
        md.reset()
        md.update('123456'.getBytes())
        String sha256Hash = jakarta.xml.bind.DatatypeConverter.printBase64Binary(md.digest())

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = sha256Hash
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 0
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = 'user@att.com'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '20240615120000'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        HashMap hmDeleteSuccess = new HashMap()
        hmDeleteSuccess[CommonDefs.COMMON_APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS

        when:
        def result = validatePINHelperObj.validatePIN(hmInputLocal)

        then:
        1 * featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> 'ONLYCOSMOS'
        _ * proofingEncryptionHelper.generateSHA1Value(_)
        1 * idgOtpDBHelper.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        0 * securityCodeDBHelperObj.getSecurityCodeDataQuery(_)
        _ * idgOtpDBHelper.updateSecurityCode(_, _) >> CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        _ * idgOtpDBHelper.updateSecurityAccount(_) >> CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        _ * objDeletePINHelper.deletePin(_ as HashMap) >> hmDeleteSuccess
        _ * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()

        and:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    // ============================================================
    // CG sync call returns ERR_INVALID_DATA
    // ============================================================

    def "validatePIN returns error when CG call returns ERR_INVALID_DATA"() {
        given:
        featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> 'ORACLEMASTER'
        HashMap resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, 'Error Returned')

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '5'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        alSecurityCodeData.add(hmDBSecurityCode)

        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        hmSecurityCodeResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeResp[MPSDefs.SECURITY_CODE_INFO] = alSecurityCodeData
        cgRestClient.getCGSyncCall(_ as HashMap) >> resultHashError
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeResp

        when:
        hmResponse = validatePINHelperObj.validatePIN(hmInput)

        then:
        hmResponse != null
        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.ERR_INVALID_DATA
    }

    // ============================================================
    // CG success with null simSwapDate → ERR_SIM_DATE_MISSING
    // ============================================================

    def "validatePIN returns ERR_SIM_DATE_MISSING when simSwapDate is null from CG response"() {
        given:
        featureManager.getValue(_ as String) >> 'ORACLEMASTER'

        HashMap<String, Object> hmSyncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        ObjectMapper map = new ObjectMapper()
        JsonNode subscriberNode = map.readTree('{}')
        ArrayNode subscribersArray = map.valueToTree([subscriberNode])
        hmSyncResp['subscribers'] = subscribersArray
        hmSyncResp['accounts'] = ['createdOn': '2020-01-01 00:00:00']

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        ArrayList alLocal = new ArrayList<>()
        alLocal.add(hmDBSecurityCode)
        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = alLocal
        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        cgHelper.makeCGSyncCall(_, _) >> hmSyncResp

        securityCodeDBHelperObj.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >>
                CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        securityCodeDBHelperObj.updateSecurityAccount(_ as HashMap, false) >>
                CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        idgOtpDBHelper.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >>
                CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        idgOtpDBHelper.updateSecurityAccount(_ as HashMap) >>
                CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        when:
        def resp = validatePINHelperObj.validatePIN(new HashMap(hmInput))

        then:
        resp != null
        resp[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.ERR_SIM_DATE_MISSING
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == CErrorDefs.ERR_SIM_DATE_MISSING_MSG
    }

    // ============================================================
    // BSSEWIRELESS accountType uses cgEndpointV3
    // ============================================================

    def "validatePIN uses cgEndpointV3 for BSSEWIRELESS accountType"() {
        given:
        featureManager.getValue(_ as String) >> 'ORACLEMASTER'
        ReflectionTestUtils.setField(validatePINHelperObj, 'cgEndpointV3', 'http://cg-v3-endpoint')

        HashMap<String, Object> hmSyncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        ObjectMapper map = new ObjectMapper()
        String today = LocalDate.now(ZoneId.of("GMT")).toString()
        JsonNode subscriberNode = map.readTree('{"simSwapDate":"2020-01-01T00:00:00Z"}')
        ArrayNode subscribersArray = map.valueToTree([subscriberNode])
        hmSyncResp['subscribers'] = subscribersArray
        hmSyncResp['accounts'] = ['createdOn': '2020-01-01 00:00:00']

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        ArrayList alLocal = new ArrayList<>()
        alLocal.add(hmDBSecurityCode)
        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = alLocal

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.ACCOUNT_TYPE, 'BSSEWIRELESS')

        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        securityCodeDBHelperObj.updateSecurityCode(_ as HashMap, _) >> CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        securityCodeDBHelperObj.updateSecurityAccount(_ as HashMap, false) >> CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        idgOtpDBHelper.updateSecurityCode(_ as HashMap, _) >> CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        idgOtpDBHelper.updateSecurityAccount(_ as HashMap) >> CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        objDeletePINHelper.deletePin(_ as HashMap) >> CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        when:
        def resp = validatePINHelperObj.validatePIN(hmInputLocal)

        then:
        1 * cgHelper.makeCGSyncCall(_, 'http://cg-v3-endpoint') >> hmSyncResp
        resp != null
    }

    // ============================================================
    // EVA caller returns securityCodeCreatedOn
    // ============================================================

    def "validatePIN success path with EVA caller returns securityCodeCreatedOn"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.CALLING_SYSTEM_ID, 'EVA')
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, 'IDSEMOB')
        hmInputLocal.put(CommonDefs.SECURITY_CODE, '123456')
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, 'Yes')

        MessageDigest mdEva = MessageDigest.getInstance('SHA-256')
        mdEva.reset()
        mdEva.update('123456'.getBytes())
        String sha256HashEva = jakarta.xml.bind.DatatypeConverter.printBase64Binary(mdEva.digest())

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = sha256HashEva
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 0
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = 'user@att.com'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '20240615120000'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        HashMap hmDeleteSuccess = new HashMap()
        hmDeleteSuccess[CommonDefs.COMMON_APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        HashMap hmSuccessResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        when:
        def result = validatePINHelperObj.validatePIN(hmInputLocal)

        then:
        1 * featureManager.getValue('cfg-idgraph-contactinfo-otpdatasource') >> 'COSMOSMASTER'
        _ * proofingEncryptionHelper.generateSHA1Value(_)
        1 * idgOtpDBHelper.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        _ * idgOtpDBHelper.updateSecurityCode(_, _) >> hmSuccessResp
        _ * idgOtpDBHelper.updateSecurityAccount(_) >> hmSuccessResp
        _ * securityCodeDBHelperObj.updateSecurityCode(_, _) >> hmSuccessResp
        _ * securityCodeDBHelperObj.updateSecurityAccount(_, _) >> hmSuccessResp
        _ * objDeletePINHelper.deletePin(_ as HashMap) >> hmDeleteSuccess
        _ * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()

        and:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        result[CommonDefs.SECURITY_CODE_CREATED_ON] == '20240615'
    }

    // ============================================================
    // Oracle incrementFailure updateSecurityCode returns error
    // ============================================================

    def "validatePIN returns error when Oracle updateSecurityCode incrementFailure fails"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, 'IDSEMOB')
        hmInputLocal.put(CommonDefs.SECURITY_CODE, '123456')
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, 'Y')

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = 'DIFFERENT_CODE'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = 'user@att.com'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        HashMap hmFailResp = new HashMap()
        hmFailResp[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.ERR_INVALID_RECORD_DB

        featureManager.getValue(_ as String) >> 'ORACLEMASTER'
        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '123456'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        securityCodeDBHelperObj.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >> hmFailResp

        when:
        def result = validatePINHelperObj.validatePIN(hmInputLocal)

        then:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.ERR_INVALID_RECORD_DB
    }

    // ============================================================
    // updateIDMCosmosDB with FAILURE status and no delivery method → OTP
    // ============================================================

    def "updateIDMCosmosDB sets authenticationMethod OTP when status is FAILURE and no delivery method"() {
        given:
        Map<String, Object> hmCosmosInput = [
                "sessionId": "sess-fail",
                (CommonDefs.ACCOUNT_ID): "acct-fail",
                (CommonDefs.ACCOUNT_TYPE): "WIRELESS",
                (CommonDefs.CALLING_SYSTEM_ID): "OPUS"
        ]
        Map<String, Object> hmResult = [
                (CommonDefs.COMMON_APP_CATEGORY_CODE): "3",
                (CommonDefs.COMMON_APP_STATUS_MSG): "ERR_DATA",
                (CommonDefs.COMMON_APP_INFO): "Some data error"
        ]
        cosmosDataStore.PersistValidatePinInfoToDatabase(_ as ValidatePinInfoBean) >> {}

        when:
        HashMap response = validatePINHelperObj.updateIDMCosmosDB(hmCosmosInput, hmResult)

        then:
        response != null
        response.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        1 * cosmosDataStore.PersistValidatePinInfoToDatabase({ ValidatePinInfoBean bean ->
            bean.status == 'FAILURE' &&
                    bean.authenticationMethod == 'OTP' &&
                    bean.failureReason.startsWith('DATA:')
        })
    }

    def "updateIDMCosmosDB sets FAILURE with category 2 system error"() {
        given:
        Map<String, Object> hmCosmosInput = [
                "sessionId": "sess-sys",
                (CommonDefs.ACCOUNT_ID): "acct-sys",
                (CommonDefs.ACCOUNT_TYPE): "WIRELESS",
                (CommonDefs.CALLING_SYSTEM_ID): "OPUS"
        ]
        Map<String, Object> hmResult = [
                (CommonDefs.COMMON_APP_CATEGORY_CODE): "2",
                (CommonDefs.COMMON_APP_STATUS_MSG): "ERR_SYS",
                (CommonDefs.COMMON_APP_INFO): "System error info"
        ]
        cosmosDataStore.PersistValidatePinInfoToDatabase(_ as ValidatePinInfoBean) >> {}

        when:
        HashMap response = validatePINHelperObj.updateIDMCosmosDB(hmCosmosInput, hmResult)

        then:
        response != null
        response.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        1 * cosmosDataStore.PersistValidatePinInfoToDatabase({ ValidatePinInfoBean bean ->
            bean.status == 'FAILURE' &&
                    bean.authenticationMethod == 'OTP' &&
                    bean.failureReason.startsWith('SYSTEM:')
        })
    }

    // ============================================================
    // checkAging with null numOfDays
    // ============================================================

    def "checkAging with null numOfDays defaults iAgingDays to 0"() {
        given:
        String sAgingFieldDate = '2020-01-01'
        String sNumOfDays = null
        String sDateFormat = 'yyyy-MM-dd'

        when:
        boolean result = validatePINHelperObj.checkAging(sAgingFieldDate, sNumOfDays, sDateFormat)

        then:
        result == true
    }

    def "checkAging with empty numOfDays defaults iAgingDays to 0"() {
        given:
        String sAgingFieldDate = '2020-01-01'
        String sNumOfDays = ''
        String sDateFormat = 'yyyy-MM-dd'

        when:
        boolean result = validatePINHelperObj.checkAging(sAgingFieldDate, sNumOfDays, sDateFormat)

        then:
        result == true
    }

    def "checkAging with future date returns false"() {
        given:
        String sAgingFieldDate = LocalDate.now(ZoneId.of("GMT")).plusDays(30).toString()
        String sNumOfDays = '60'
        String sDateFormat = 'yyyy-MM-dd'

        when:
        boolean result = validatePINHelperObj.checkAging(sAgingFieldDate, sNumOfDays, sDateFormat)

        then:
        result == false
    }

    // ============================================================
    // compareAcctAndSIMEffectDate edge cases
    // ============================================================

    def "compareAcctAndSIMEffectDate returns false when dates are the same"() {
        when:
        boolean result = validatePINHelperObj.compareAcctAndSIMEffectDate('2024-01-01', '2024-01-01', 'yyyy-MM-dd')

        then:
        result == false
    }

    def "compareAcctAndSIMEffectDate returns true when dates differ"() {
        when:
        boolean result = validatePINHelperObj.compareAcctAndSIMEffectDate('2024-01-01', '2024-06-15', 'yyyy-MM-dd')

        then:
        result == true
    }

    def "compareAcctAndSIMEffectDate returns false when accountCreatedOn is null"() {
        when:
        boolean result = validatePINHelperObj.compareAcctAndSIMEffectDate(null, '2024-06-15', 'yyyy-MM-dd')

        then:
        result == false
    }

    def "compareAcctAndSIMEffectDate returns false when simEffectiveDate is null"() {
        when:
        boolean result = validatePINHelperObj.compareAcctAndSIMEffectDate('2024-01-01', null, 'yyyy-MM-dd')

        then:
        result == false
    }

    def "compareAcctAndSIMEffectDate returns false on parse exception"() {
        when:
        boolean result = validatePINHelperObj.compareAcctAndSIMEffectDate('bad-date', '2024-01-01', 'yyyy-MM-dd')

        then:
        result == false
    }

    // ============================================================
    // SPTAUTHREG-34675: CG V4 SIM swap check unit tests
    // ============================================================

    def "validatePIN V4 SIM check - non-CG targetSOR - dates provided - returns success"() {
        given:
        featureManager.getValue(_ as String) >> 'ORACLEMASTER'
        featureManager.isEnabled('svc-idgraph-validatepin-cg-v4-enabled') >> true

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 0
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        CustomerV4Response mockResponse = Mock(CustomerV4Response)
        Individual mockIndividual = Mock(Individual)
        Account mockAccount = Mock(Account)
        mockAccount.getCreatedOn() >> '2020-01-01 00:00:00'
        mockAccount.getTargetSOR() >> 'NONE'
        mockAccount.getSubscribers() >> []
        mockIndividual.getAccounts() >> [mockAccount]
        mockResponse.getIndividual() >> mockIndividual

        Map<String, Map<String, Object>> simSwapMap = ['9899545': ['simSwapDateValue': '2020-01-01 00:00:00']]

        HashMap hmSuccessResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        HashMap hmDeleteSuccess = new HashMap()
        hmDeleteSuccess[CommonDefs.COMMON_APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS

        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        cgApiRestClient.getCustomerDetailsByAccountId(_ as HashMap) >> mockResponse
        cgUtilHelper.extractSubscriberDetailsFromV4Response(_) >> simSwapMap
        objDeletePINHelper.deletePin(_ as HashMap) >> hmDeleteSuccess
        securityCodeDBHelperObj.updateSecurityCode(_, _) >> hmSuccessResp
        idgOtpDBHelper.updateSecurityCode(_, _) >> hmSuccessResp
        idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()

        when:
        def resp = validatePINHelperObj.validatePIN(new HashMap(hmInput))

        then:
        resp != null
        resp[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        0 * cgHelper._
    }

    def "validatePIN V4 SIM check - CG targetSOR - same dates - returns success"() {
        given:
        featureManager.getValue(_ as String) >> 'ORACLEMASTER'
        featureManager.isEnabled('svc-idgraph-validatepin-cg-v4-enabled') >> true

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 0
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        CustomerV4Response mockResponse = Mock(CustomerV4Response)
        Individual mockIndividual = Mock(Individual)
        Account mockAccount = Mock(Account)
        mockAccount.getCreatedOn() >> '2020-01-01T00:00:00.000+0000'
        mockAccount.getTargetSOR() >> 'CG'
        mockAccount.getSubscribers() >> []
        mockIndividual.getAccounts() >> [mockAccount]
        mockResponse.getIndividual() >> mockIndividual

        Map<String, Map<String, Object>> simSwapMap = ['9899545': ['simSwapDateValue': '2020-01-01T00:00:00.000+0000']]

        HashMap hmSuccessResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        HashMap hmDeleteSuccess = new HashMap()
        hmDeleteSuccess[CommonDefs.COMMON_APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS

        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        cgApiRestClient.getCustomerDetailsByAccountId(_ as HashMap) >> mockResponse
        cgUtilHelper.extractSubscriberDetailsFromV4Response(_) >> simSwapMap
        objDeletePINHelper.deletePin(_ as HashMap) >> hmDeleteSuccess
        securityCodeDBHelperObj.updateSecurityCode(_, _) >> hmSuccessResp
        idgOtpDBHelper.updateSecurityCode(_, _) >> hmSuccessResp
        idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()

        when:
        def resp = validatePINHelperObj.validatePIN(new HashMap(hmInput))

        then:
        resp != null
        resp[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        0 * cgHelper._
    }

    def "validatePIN V4 SIM check - CG targetSOR - SIM date differs from account date - returns ERR_SIM_NOT_YET_ELIGIBLE"() {
        given:
        featureManager.getValue(_ as String) >> 'ORACLEMASTER'
        featureManager.isEnabled('svc-idgraph-validatepin-cg-v4-enabled') >> true

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 0
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        CustomerV4Response mockResponse = Mock(CustomerV4Response)
        Individual mockIndividual = Mock(Individual)
        Account mockAccount = Mock(Account)
        // SIM swap date is yesterday (1 day ago), account created 28 days ago
        // SIM date (yesterday) + 2 aging days = tomorrow, which is AFTER current date
        // So checkAging returns false, then compareAcctAndSIMEffectDate is called
        // Since dates differ, ERR_SIM_NOT_YET_ELIGIBLE is returned
        String recentSimDate = LocalDate.now(ZoneId.of("GMT")).minusDays(1).toString() + 'T00:00:00.000+0000'
        String accountCreatedDate = LocalDate.now(ZoneId.of("GMT")).minusDays(28).toString() + 'T00:00:00.000+0000'
        mockAccount.getCreatedOn() >> accountCreatedDate
        mockAccount.getTargetSOR() >> 'CG'
        mockAccount.getSubscribers() >> []
        mockIndividual.getAccounts() >> [mockAccount]
        mockResponse.getIndividual() >> mockIndividual

        Map<String, Map<String, Object>> simSwapMap = ['9899545': ['simSwapDateValue': recentSimDate]]

        HashMap hmSuccessResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        cgApiRestClient.getCustomerDetailsByAccountId(_ as HashMap) >> mockResponse
        cgUtilHelper.extractSubscriberDetailsFromV4Response(_) >> simSwapMap
        securityCodeDBHelperObj.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >> hmSuccessResp
        securityCodeDBHelperObj.updateSecurityAccount(_ as HashMap, false) >> hmSuccessResp
        idgOtpDBHelper.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >> hmSuccessResp
        idgOtpDBHelper.updateSecurityAccount(_ as HashMap) >> hmSuccessResp
        idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()

        when:
        def resp = validatePINHelperObj.validatePIN(new HashMap(hmInput))

        then:
        resp != null
        resp[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.ERR_SIM_NOT_YET_ELIGIBLE
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == CErrorDefs.ERR_SIM_NOT_YET_ELIGIBLE_MSG
        0 * cgHelper._
    }

    def "validatePIN V4 SIM check - simSwapDateValue null in CG response - returns ERR_SIM_DATE_MISSING"() {
        given:
        featureManager.getValue(_ as String) >> 'ORACLEMASTER'
        featureManager.isEnabled('svc-idgraph-validatepin-cg-v4-enabled') >> true

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 0
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        CustomerV4Response mockResponse = Mock(CustomerV4Response)
        Individual mockIndividual = Mock(Individual)
        Account mockAccount = Mock(Account)
        mockAccount.getCreatedOn() >> '2020-01-01T00:00:00.000+0000'
        mockAccount.getTargetSOR() >> 'CG'
        mockAccount.getSubscribers() >> []
        mockIndividual.getAccounts() >> [mockAccount]
        mockResponse.getIndividual() >> mockIndividual

        Map<String, Map<String, Object>> simSwapMap = [:]

        HashMap hmSuccessResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        cgApiRestClient.getCustomerDetailsByAccountId(_ as HashMap) >> mockResponse
        cgUtilHelper.extractSubscriberDetailsFromV4Response(_) >> simSwapMap
        securityCodeDBHelperObj.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >> hmSuccessResp
        securityCodeDBHelperObj.updateSecurityAccount(_ as HashMap, false) >> hmSuccessResp
        idgOtpDBHelper.updateSecurityCode(_ as HashMap, MPSDefs.INCREMENT_FAILURE_COUNT) >> hmSuccessResp
        idgOtpDBHelper.updateSecurityAccount(_ as HashMap) >> hmSuccessResp
        idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()

        when:
        def resp = validatePINHelperObj.validatePIN(new HashMap(hmInput))

        then:
        resp != null
        resp[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.ERR_SIM_DATE_MISSING
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == CErrorDefs.ERR_SIM_DATE_MISSING_MSG
    }

    def "validatePIN V4 SIM check - null individual in CG V4 response - ServiceException caught - returns error"() {
        given:
        featureManager.getValue(_ as String) >> 'ORACLEMASTER'
        featureManager.isEnabled('svc-idgraph-validatepin-cg-v4-enabled') >> true

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 0
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        CustomerV4Response mockResponse = Mock(CustomerV4Response)
        mockResponse.getIndividual() >> null

        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        cgApiRestClient.getCustomerDetailsByAccountId(_ as HashMap) >> mockResponse

        when:
        def resp = validatePINHelperObj.validatePIN(new HashMap(hmInput))

        then:
        resp != null
        resp[CommonDefs.COMMON_APP_STATUS_CODE] != CommonDefs.COMMON_SUCCESS
    }

    def "validatePIN V4 SIM check - DUO companion subscriber - ServiceException caught - returns error"() {
        given:
        featureManager.getValue(_ as String) >> 'ORACLEMASTER'
        featureManager.isEnabled('svc-idgraph-validatepin-cg-v4-enabled') >> true

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 0
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        Subscriber mockSubscriber = Mock(Subscriber)
        mockSubscriber.getDuoIdentifier() >> 'companion'
        Account mockAccount = Mock(Account)
        mockAccount.getSubscribers() >> [mockSubscriber]
        Individual mockIndividual = Mock(Individual)
        mockIndividual.getAccounts() >> [mockAccount]
        CustomerV4Response mockResponse = Mock(CustomerV4Response)
        mockResponse.getIndividual() >> mockIndividual

        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        cgApiRestClient.getCustomerDetailsByAccountId(_ as HashMap) >> mockResponse

        when:
        def resp = validatePINHelperObj.validatePIN(new HashMap(hmInput))

        then:
        resp != null
        resp[CommonDefs.COMMON_APP_STATUS_CODE] != CommonDefs.COMMON_SUCCESS
    }

    def "validatePIN V4 SIM check - ServiceException thrown by cgApiRestClient - propagated and caught - returns error"() {
        given:
        featureManager.getValue(_ as String) >> 'ORACLEMASTER'
        featureManager.isEnabled('svc-idgraph-validatepin-cg-v4-enabled') >> true

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 0
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        cgApiRestClient.getCustomerDetailsByAccountId(_ as HashMap) >> { throw new ServiceException(ErrorMessages.MS_MPSYS_BE_100, 'CG V4 unavailable') }

        when:
        def resp = validatePINHelperObj.validatePIN(new HashMap(hmInput))

        then:
        resp != null
        resp[CommonDefs.COMMON_APP_STATUS_CODE] != CommonDefs.COMMON_SUCCESS
    }

    def "validatePIN V4 SIM check - RuntimeException thrown by cgApiRestClient - wrapped as ServiceException - returns error"() {
        given:
        featureManager.getValue(_ as String) >> 'ORACLEMASTER'
        featureManager.isEnabled('svc-idgraph-validatepin-cg-v4-enabled') >> true

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 0
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        cgApiRestClient.getCustomerDetailsByAccountId(_ as HashMap) >> { throw new RuntimeException('connection timeout') }

        when:
        def resp = validatePINHelperObj.validatePIN(new HashMap(hmInput))

        then:
        resp != null
        resp[CommonDefs.COMMON_APP_STATUS_CODE] != CommonDefs.COMMON_SUCCESS
    }

    def "validatePIN V4 SIM check - account createdOn is null and SIM date recent - throws ServiceException mapped to ERR_EXTERNAL_SYS"() {
        given:
        featureManager.getValue(_ as String) >> 'ORACLEMASTER'
        featureManager.isEnabled('svc-idgraph-validatepin-cg-v4-enabled') >> true

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 0
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        CustomerV4Response mockResponse = Mock(CustomerV4Response)
        Individual mockIndividual = Mock(Individual)
        Account mockAccount = Mock(Account)
        // Recent SIM swap date (yesterday) so checkAging returns false and the createdOn guard is reached
        String recentSimDate = LocalDate.now(ZoneId.of("GMT")).minusDays(1).toString() + 'T00:00:00.000+0000'
        mockAccount.getCreatedOn() >> null
        mockAccount.getTargetSOR() >> 'CG'
        mockAccount.getSubscribers() >> []
        mockIndividual.getAccounts() >> [mockAccount]
        mockResponse.getIndividual() >> mockIndividual

        Map<String, Map<String, Object>> simSwapMap = ['9899545': ['simSwapDateValue': recentSimDate]]

        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        cgApiRestClient.getCustomerDetailsByAccountId(_ as HashMap) >> mockResponse
        cgUtilHelper.extractSubscriberDetailsFromV4Response(_) >> simSwapMap

        when:
        def resp = validatePINHelperObj.validatePIN(new HashMap(hmInput))

        then: "ServiceException is caught and mapped to ERR_EXTERNAL_SYS; the V2 CG path is never used"
        resp != null
        resp[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.ERR_EXTERNAL_SYS
        0 * cgHelper._
    }

    // ============================================================
    // deletePin error on success path returns error
    // ============================================================

    def "validatePIN returns error when deletePin fails on success path"() {
        given:
        ReflectionTestUtils.setField(validatePINHelperObj, 'propSIMCheckIdentificationType', '')

        Map<String, Object> hmInputLocal = new HashMap<>(hmInput)
        hmInputLocal.put(CommonDefs.IDENTIFICATION_TYPE, 'IDSEMOB')
        hmInputLocal.put(CommonDefs.SECURITY_CODE, '123456')
        hmInputLocal.put(CommonDefs.DELETE_PIN_ON_SUCCESS, 'Yes')

        MessageDigest mdDel = MessageDigest.getInstance('SHA-256')
        mdDel.reset()
        mdDel.update('123456'.getBytes())
        String sha256HashDel = jakarta.xml.bind.DatatypeConverter.printBase64Binary(mdDel.digest())

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = sha256HashDel
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 0
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'E'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = 'user@att.com'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '20240615120000'

        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = [hmDBSecurityCode]

        HashMap hmDeleteFail = new HashMap()
        hmDeleteFail[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.ERR_INVALID_RECORD_DB

        featureManager.getValue(_ as String) >> 'COSMOSMASTER'
        proofingEncryptionHelper.generateSHA1Value(_ as String) >> 'whatever'
        idgOtpDBHelper.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        objDeletePINHelper.deletePin(_ as HashMap) >> hmDeleteFail

        when:
        def result = validatePINHelperObj.validatePIN(hmInputLocal)

        then:
        result != null
        result[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.ERR_INVALID_RECORD_DB
    }

    // ============================================================
    // SIM check aged path where simSwapDate is old → success
    // ============================================================

    def "validatePIN returns success when SIM effective date is aged and account createdOn same"() {
        given:
        featureManager.getValue(_ as String) >> 'ORACLEMASTER'

        String oldDate = '2020-01-01'
        HashMap<String, Object> hmSyncResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        ObjectMapper map = new ObjectMapper()
        JsonNode subscriberNode = map.readTree('{"simSwapDate":"' + oldDate + 'T00:00:00Z"}')
        ArrayNode subscribersArray = map.valueToTree([subscriberNode])
        hmSyncResp['subscribers'] = subscribersArray
        hmSyncResp['accounts'] = ['createdOn': oldDate + ' 00:00:00']

        HashMap hmDBSecurityCode = new HashMap()
        hmDBSecurityCode[MPSDefs.DB_SECURITY_CODE] = '1990122'
        hmDBSecurityCode[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = 1
        hmDBSecurityCode[MPSDefs.EXCEEDED_UNLOCKED_TIME] = '0'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_METHOD] = 'S'
        hmDBSecurityCode[MPSDefs.DB_DELIVERY_DETAIL] = '9899545'
        hmDBSecurityCode[MPSDefs.DB_CREATE_DATE] = '23012023'

        ArrayList alLocal = new ArrayList<>()
        alLocal.add(hmDBSecurityCode)
        HashMap hmSecurityCodeRespLocal = new HashMap()
        hmSecurityCodeRespLocal[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.COMMON_SUCCESS
        hmSecurityCodeRespLocal[MPSDefs.SECURITY_CODE_INFO] = alLocal
        proofingEncryptionHelper.generateSHA1Value(_ as String) >> '1990122'
        securityCodeDBHelperObj.getSecurityCodeDataQuery(_ as HashMap) >> hmSecurityCodeRespLocal
        cgHelper.makeCGSyncCall(_, _) >> hmSyncResp
        objDeletePINHelper.deletePin(_ as HashMap) >> CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        securityCodeDBHelperObj.updateSecurityCode(_, _) >> CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        idgOtpDBHelper.updateSecurityCode(_, _) >> CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        when:
        def resp = validatePINHelperObj.validatePIN(new HashMap(hmInput))

        then:
        resp != null
        resp[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    // ============================================================
    // normalizeDateToLegacy tests (private method - invoke via reflection)
    // ============================================================

    @Unroll
    def "normalizeDateToLegacy converts #scenarioName to yyyy-MM-dd format"() {
        when:
        String result = ReflectionTestUtils.invokeMethod(validatePINHelperObj, 'normalizeDateToLegacy', inputDate)

        then:
        0 * _

        and:
        result == expectedDate

        where:
        scenarioName                        | inputDate                          || expectedDate
        "ISO 8601 with Z timezone"          | "2024-01-15T10:30:00.123Z"         || "2024-01-15"
        "ISO 8601 with offset timezone"     | "2024-01-15T10:30:00+05:30"        || "2024-01-15"
        "ISO 8601 without milliseconds"     | "2024-01-15T10:30:00Z"             || "2024-01-15"
        "legacy timestamp format"           | "2024-01-15 10:30:00"              || "2024-01-15"
        "legacy timestamp with date only"   | "2024-01-15 00:00:00"              || "2024-01-15"
        "date-only format"                  | "2024-01-15"                       || "2024-01-15"
    }



    def "normalizeDateToLegacy returns empty string for empty input"() {
        when:
        String result = ReflectionTestUtils.invokeMethod(validatePINHelperObj, 'normalizeDateToLegacy', "")

        then:
        0 * _

        and:
        result == ""
    }

    def "normalizeDateToLegacy returns original for whitespace-only input"() {
        when:
        String result = ReflectionTestUtils.invokeMethod(validatePINHelperObj, 'normalizeDateToLegacy', "   ")

        then:
        0 * _

        and:
        result == "   "
    }

    def "normalizeDateToLegacy handles unexpected format gracefully"() {
        given:
        String unexpectedFormat = "15-01-2024"

        when:
        String result = ReflectionTestUtils.invokeMethod(validatePINHelperObj, 'normalizeDateToLegacy', unexpectedFormat)

        then:
        0 * _

        and:
        result == unexpectedFormat
    }

    def "normalizeDateToLegacy handles short unexpected format"() {
        given:
        String shortFormat = "2024"

        when:
        String result = ReflectionTestUtils.invokeMethod(validatePINHelperObj, 'normalizeDateToLegacy', shortFormat)

        then:
        0 * _

        and:
        result == shortFormat
    }
}
