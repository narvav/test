package com.att.idp.idgraphcontactinfoms.helpers.voltage

import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class ProofingEncryptionHelperTest extends Specification {
	
	
	def proofingEncryption_H = new ProofingEncryptionHelper()

	def voltageHelper = Mock(VoltageEncryptionHelper)

	public static final Logger logger = LoggerFactory.getLogger('ProofingEncryption_H')
	HashMap<String, Object> hmEncInput = null
	HashMap<String, Object> hmDecInput = null
	HashMap<String, Object> hmEachInnerValue = null
	HashMap<String, Object> hmServices = null
	HashMap<String, Object> hmEachServices = null


	def setup()
	{
		proofingEncryption_H.voltageHelper = voltageHelper
		hmEncInput = new HashMap<String, Object>()
		hmEncInput['userID'] = 'qay_ribgt'
		hmEncInput['passcode'] = '67365'
		hmEncInput['voltage_dsl_net_password'] = 'A5EC5&$47D'
		hmEncInput['online1SecurityAnswer'] = 'developer'
		hmEncInput['sorInvariantId'] = '1673687503'
		hmEncInput['twoWayEncryptField'] = 'qay_ribgt'

		hmDecInput = new HashMap<String, Object>()
		hmDecInput[MPSDefs.DB_DSL_NET_ENCR_TYPE] = 'A'
		hmDecInput[MPSDefs.DB_DSL_NET_PASSWORD] = '6d76f53543e7e4f21533e72f6a8bef36'
		hmDecInput['sorInvariantId'] = '6d76f53543e7e4f21533e72f6a8bef36'
		hmServices = new HashMap()
		hmEachServices = new HashMap<String, Object>()
		hmEachInnerValue = new HashMap()
		hmEachInnerValue['sor_invariant_id'] = '6d76f53543e7e4f21533e72f6a8bef36'
		hmEachServices['instanceID'] = hmEachInnerValue
		hmEachServices['aes_password'] = '6d76f53543e7e4f21533e72f6a8bef36'
		hmServices['MOSUB'] = hmEachServices
		hmServices['ISS'] = hmEachServices
		hmDecInput[MPSDefs.SERVICES] = hmServices

		ReflectionTestUtils.setField(proofingEncryption_H, 'propSpiEncyptionType', 'V')
		ReflectionTestUtils.setField(proofingEncryption_H, 'propVoltageEncryptFields', 'birthdate_venc|security_answer_venc|passcode_venc|password_venc|dsl_net_password|md5_password_venc|enc_password_venc|sha1_password_venc|des3_password_venc|ssha_password_venc|security_answer_1_venc|security_answer_2_venc|gen_password_venc')
		ReflectionTestUtils.setField(proofingEncryption_H, 'propRemoveFieldsWhenSPIEncryptionTypeA', 'birthdate_venc|passcode_venc|security_answer_venc|wirelineuser_passcode_venc|issuser_password_venc')
		ReflectionTestUtils.setField(proofingEncryption_H, 'propOneWayEncrypt', 'online1SecurityAnswer|online2SecurityAnswer|wsOnline1SecurityAnswer|wsOnline2SecurityAnswer')
		ReflectionTestUtils.setField(proofingEncryption_H, 'propTwoWayEncrypt', 'sorInvariantId')
		ReflectionTestUtils.setField(proofingEncryption_H, 'propTwoWayServicesEncrypt', 'MOSUB|ISS')
		ReflectionTestUtils.setField(proofingEncryption_H, 'propPopulateVoltageFields', 'birthdate:birthdate_venc|wsPasscode:passcode_venc|passcode:passcode_venc|securityAnswer:security_answer_venc|security_answer:security_answer_venc|birthdate_encrypted:birthdate_venc|dateOfBirth:birthdate_venc|wirelineuser_passcode:wirelineuser_passcode_venc|issuser_password:issuser_password_venc|securitycode_passcode:securitycode_passcode_venc')
		ReflectionTestUtils.setField(proofingEncryption_H, 'aes256key', '16cd6d4581316cd7dfed29e087b10b145ddac92a62ed47ca2b4b60ea1b1f74fe')
		ReflectionTestUtils.setField(proofingEncryption_H, 'propMosubAttrDecryption', 'sor_invariant_id|sorInvariantId|wsSorInvariantId')
		ReflectionTestUtils.setField(proofingEncryption_H, 'propIssAttrDecryption', 'aes_password')

		System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')
	}


	def "testget encrypted values null input"()
	{
		given:
		hmEncInput = null
		when:
		HashMap<String, Object> hmResult = proofingEncryption_H.getEncryptedValues(hmEncInput)
		then:
		hmResult == null
	}


	def "testget encrypted values null response from voltage helper"()
	{
		given:
		voltageHelper.getEFPEEncryptedValues(hmEncInput) >> null
		when:
		HashMap<String, Object> hmResult = proofingEncryption_H.getEncryptedValues(hmEncInput)
		then:
		hmResult['appInfo'] == 'VoltageEncryption_H.getEFPEDecryptedValues return null / empty'
	}


	def "testget encrypted values error from voltage helper"()
	{
		given:
		HashMap<String, Object> voltageResult = new HashMap<String, Object>()
		voltageResult[CommonDefs.COMMON_APP_STATUS_CODE] = '118'
		voltageHelper.getEFPEEncryptedValues(hmEncInput) >> voltageResult
		when:
		HashMap<String, Object> hmResult = proofingEncryption_H.getEncryptedValues(hmEncInput)
		then:
		hmResult['appStatusCode'] == '118'
	}


	def "testget encrypted values success"()
	{
		given:
		HashMap<String, Object> voltageResult = new HashMap<String, Object>()
		voltageResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
		voltageHelper.getEFPEEncryptedValues(hmEncInput) >> voltageResult
		when:
		HashMap<String, Object> hmResult = proofingEncryption_H.getEncryptedValues(hmEncInput)
		then:
		hmResult['appStatusMsg'] == 'SUCCESS'
	}


	def "testget encrypted values exception fromgenerate sha1 value"()
	{
		given:
		HashMap<String, Object> voltageResult = new HashMap<String, Object>()
		voltageResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
		hmEncInput['online1SecurityAnswer'] = null
		voltageHelper.getEFPEEncryptedValues(hmEncInput) >> voltageResult
		when:
		HashMap<String, Object> hmResult = proofingEncryption_H.getEncryptedValues(hmEncInput)
		then:
		hmResult['appInfo'] == 'generateSHA1Value failed for field=online1SecurityAnswer'
	}


	def "testget encrypted values exception fromgenerate aes256 value"()
	{
		given:
		HashMap<String, Object> voltageResult = new HashMap<String, Object>()
		voltageResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
		hmEncInput['sorInvariantId'] = null
		voltageHelper.getEFPEEncryptedValues(hmEncInput) >> voltageResult
		when:
		HashMap<String, Object> hmResult = proofingEncryption_H.getEncryptedValues(hmEncInput)
		then:
		hmResult['appInfo'] == 'generateAES256Value failed for field=sorInvariantId'
	}


	def "testget encrypted values exception"()
	{
		given:
		voltageHelper.getEFPEEncryptedValues(hmEncInput) >> { throw new NullPointerException() }
		when:
		HashMap<String, Object> hmResult = proofingEncryption_H.getEncryptedValues(hmEncInput)
		then:
		hmResult['appInfo'] == 'SYSTEM ERROR'
	}


	def "testget decrypted values null input"()
	{
		given:
		hmDecInput = null
		when:
		HashMap<String, Object> hmResult = proofingEncryption_H.getDecryptedValues(hmDecInput)
		then:
		hmResult['appInfo'] == ' hmInput is NULL '
	}


	def "testget decrypted values null response from voltage helper"()
	{
//		Mockito.when(voltageHelper.getEFPEEncryptedValues(Mockito.any(HashMap.class)))
//        .thenReturn(null); 
		when:
		HashMap<String, Object> hmResult = proofingEncryption_H.getDecryptedValues(hmDecInput)
		then:
		hmResult['appInfo'] == 'VoltageEncryption_H.getEFPEDecryptedValues return null / empty'
	}


	def "testget decrypted values exception fromget clear text from aes case1"()
	{
		given:
		hmDecInput[MPSDefs.DB_DSL_NET_PASSWORD] = '4f21533e72f6a8bef36'
		when:
		HashMap<String, Object> hmResult = proofingEncryption_H.getDecryptedValues(hmDecInput)
		then:
		hmResult['appInfo'] == 'generatedClearText failed for field=dsl_net_password'
	}


	def "testget decrypted values exception fromget clear text from aes case2"()
	{
		given:
		hmDecInput['sorInvariantId'] = '4f21533e72f6a8bef36'

		HashMap<String, Object> voltageResult = new HashMap<String, Object>()
		voltageResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
		voltageHelper.getEFPEDecryptedValues(_ as HashMap) >> voltageResult
		when:
		HashMap<String, Object> hmResult = proofingEncryption_H.getDecryptedValues(hmDecInput)
		then:
		hmResult['appInfo'] == 'generatedClearText failed for field=sorInvariantId'
	}


	def "testget decrypted values error from voltage helper"()
	{
		given:
		hmDecInput[MPSDefs.DB_DSL_NET_ENCR_TYPE] = 'C'
		HashMap<String, Object> voltageResult = new HashMap<String, Object>()
		voltageResult[CommonDefs.COMMON_APP_STATUS_CODE] = '118'
		voltageHelper.getEFPEDecryptedValues(hmDecInput) >> voltageResult
		when:
		HashMap<String, Object> hmResult = proofingEncryption_H.getDecryptedValues(hmDecInput)
		then:
		hmResult['appStatusCode'] == '118'
	}


	def "testget decrypted values success case1"()
	{
		given:
		HashMap<String, Object> voltageResult = new HashMap<String, Object>()
		voltageResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
		voltageHelper.getEFPEDecryptedValues(_ as HashMap) >> voltageResult
		when:
		HashMap<String, Object> hmResult = proofingEncryption_H.getDecryptedValues(hmDecInput)
		then:
		hmResult['appStatusMsg'] == 'SUCCESS'
	}


	def "testget decrypted values exception fromget clear text from a e s case3"()
	{
		given:
		hmEachInnerValue['sor_invariant_id'] = '56790789'
		HashMap<String, Object> voltageResult = new HashMap<String, Object>()
		voltageResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
		voltageHelper.getEFPEDecryptedValues(_ as HashMap) >> voltageResult
		when:
		HashMap<String, Object> hmResult = proofingEncryption_H.getDecryptedValues(hmDecInput)
		then:
		hmResult['appInfo'] == 'generatedClearText failed for field=sor_invariant_id'
	}


	def "testget decrypted values exception fromget clear text from a e s case4"()
	{
		given:
		hmServices['ISS'] = hmEachServices
		hmEachServices.replace('aes_password', '6d76f53543e7e4f21533e72f6a8bef36', '%67#4343*75')
		HashMap<String, Object> voltageResult = new HashMap<String, Object>()
		voltageResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
		voltageHelper.getEFPEDecryptedValues(_ as HashMap) >> voltageResult
		when:
		HashMap<String, Object> hmResult = proofingEncryption_H.getDecryptedValues(hmDecInput)
		then:
		hmResult['appInfo'] == 'generatedClearText failed for field=aes_password'
	}


	def "testreplace all"()
	{
		given:
		hmDecInput = null
		when:
		String strResult = proofingEncryption_H.replaceAll(null, ' ', ' ')
		then:
		strResult == null

		when:
		strResult = proofingEncryption_H.replaceAll('online1SecurityAnswer', null, ' ')
		then:
		strResult == 'online1SecurityAnswer'

		when:
		strResult = proofingEncryption_H.replaceAll('online1SecurityAnswer', 'Answer', null)
		then:
		strResult == 'online1Security'

		when:
		strResult = proofingEncryption_H.replaceAll('online1SecurityAnswer', 'Answer', 'Question')
		then:
		strResult == 'online1SecurityQuestion'
	}


	def "testget decrypted values success case2"()
	{
		// when propSpiEncyptionType is 'AV'
		given:
		ReflectionTestUtils.setField(proofingEncryption_H, 'propSpiEncyptionType', 'AV')

		HashMap<String, Object> voltageResult = new HashMap<String, Object>()
		voltageResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
		when:
		HashMap<String, Object> hmResult = proofingEncryption_H.getDecryptedValues(hmDecInput)
		then:
		hmResult['appStatusMsg'] == 'SUCCESS'
	}
	
}
