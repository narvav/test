package com.att.idp.component

import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ArrayNode
import com.fasterxml.jackson.databind.node.ObjectNode
import org.hamcrest.CoreMatchers

class CGRestClientCompTest extends CompBaseTest {

    private static final String ACCOUNT_CG_RESPONSE = '{"contact":{"address":{"contactType":"D","postCode":"75001-1234","street1":"123 Main","city":"Dallas","state":"TX","country":"USA","lastUpdate":"2023-10-01"},"email":{"emailAddress":"user@test.com","emailEstablishDate":"2023-10-01"}},"createdOn":"2023-10-01"}'
    private static HashMap<String, Object> accounts;
    private static ArrayNode subscribers;

    static {
        HashMap<String, Object> contact = CommonUtil.getHashMap()
        contact.put("email", [emailAddress: "user@test.com", emailEstablishDate: "2023-10-01"]) // minimal for flow
        contact.put("address", [contactType: "D", postCode: "75001-1234", street1: "123 Main", city: "Dallas", state: "TX", country: "USA", lastUpdate: "2023-10-01"])
        accounts = CommonUtil.getHashMap()
        accounts.put("contact", contact)
        accounts.put("createdOn", "2023-10-01")

        ObjectMapper objectMapper = new ObjectMapper()
        subscribers = objectMapper.createArrayNode()
        ObjectNode subscriberNode = objectMapper.createObjectNode()
        subscriberNode.put("subscriberId", "3863169761")
        subscriberNode.put("effectiveDate", "2021-08-20 00:00:00")
        subscriberNode.put("status", "A")
        subscribers.add(subscriberNode)
    }

    private Map<String, String> getHeaders(String accountId, String subscriberNumber, String serviceType, String topics) {
        Map<String, String> headers = new HashMap<>()
        headers.put("Content-Type", "application/json")
        headers.put("idp-trace-id", "ed44414d155475a6:ed44414d155475a6:0:0")
        headers.put("X-ATT-ClientId", "IDP")
        if (accountId != null) headers.put("accountId", accountId)
        if (subscriberNumber != null) headers.put("subscriberNumber", subscriberNumber)
        headers.put("serviceType", serviceType)
        headers.put("topics", topics)
        return headers
    }

    def "cgRestClient success for accountId"() {
        given:
        String accountId = "177071112120"
        String serviceType = "wireless"
        String topics = "accounts,subscribers,equipments"
        String uri = "/cgRestClient/cgSyncCall"
        Map<String, String> headers = getHeaders(accountId, null, serviceType, topics)
        Map<String, Object> cgResponseMap = new HashMap<>()
        cgResponseMap.put(MPSDefs.APP_STATUS_CODE, "0")
        cgResponseMap.put("status", "SUCCESS")
        cgResponseMap.put("message", "ok")
        cgResponseMap.put("accounts", accounts)
        cgRestClient.getCGSyncCall(_ as HashMap<String, Object>) >> cgResponseMap

        when:
        def response = givenBaseSpec().headers(headers).get(uri)

        then:
        response.statusCode() == 200
        response.then()
                .body("idp-trace-id", CoreMatchers.notNullValue())
                .body("appStatusMsg", CoreMatchers.is("SUCCESS"))
                .body("accounts", CoreMatchers.equalTo(accounts))
    }

    def "cgRestClient success for subscriberNumber"() {
        given:
        String subscriberNumber = "177071112120"
        String serviceType = "wireless"
        String topics = "accounts,subscribers,equipments"
        String uri = "/cgRestClient/cgSyncCall"
        Map<String, String> headers = getHeaders(null, subscriberNumber, serviceType, topics)
        Map<String, Object> cgResponseMap = new HashMap<>()
        cgResponseMap.put(MPSDefs.APP_STATUS_CODE, "0")
        cgResponseMap.put("status", "SUCCESS")
        cgResponseMap.put("message", "ok")
        cgResponseMap.put("subscribers", subscribers)
        cgRestClient.getCGSyncCall(_ as HashMap<String, Object>) >> cgResponseMap

        when:
        def response = givenBaseSpec().headers(headers).get(uri)

        then:
        response.statusCode() == 200
        response.then()
                .body("idp-trace-id", CoreMatchers.notNullValue())
                .body("appStatusMsg", CoreMatchers.is("SUCCESS"))
    }

    def "cgRestClient system error when CG returns empty"() {
        given:
        String accountId = "177071112120"
        String serviceType = "wireless"
        String topics = "accounts,subscribers,equipments"
        String uri = "/cgRestClient/cgSyncCall"
        Map<String, String> headers = getHeaders(accountId, null, serviceType, topics)
        Map<String, Object> emptyResponse = new HashMap<>()
        cgRestClient.getCGSyncCall(_ as HashMap<String, Object>) >> emptyResponse

        when:
        def response = givenBaseSpec().headers(headers).get(uri)

        then:
        response.statusCode() == 500
        response.then()
                .body("error", CoreMatchers.notNullValue())
                .body("idp-trace-id", CoreMatchers.notNullValue())
    }
}
