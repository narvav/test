package com.att.idp.idgraphcontactinfoms.request.validator


import com.att.idp.idgraphcontactinfoms.resource.request.InquirePINRequest
import com.att.idp.idgraphcontactinfoms.resource.response.InquirePINResponse
import com.att.mpsys.common.utils.CommonUtil
import org.slf4j.MDC
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import jakarta.ws.rs.core.MultivaluedHashMap
import jakarta.ws.rs.core.HttpHeaders


class InquirePINRequestValidatorTest extends Specification {

	def inquirePINReqValidatorObj = new InquirePINRequestValidator()
	def inquirePINReqObj = null

	def requestHeader = Stub(HttpHeaders)
	public MultivaluedHashMap requestHeaders = null
	private Map<String, String> headers = new HashMap<>()

	def setup() {

		requestHeaders = new MultivaluedHashMap<>(headers)
		inquirePINReqObj = new InquirePINRequest()

		inquirePINReqObj.identificationType = 'EMAILOTP'
		inquirePINReqObj.accountId = '4256374859'
		
		ReflectionTestUtils.setField(inquirePINReqValidatorObj, 'propValidPINIDENTypeAndCSI',
				'IDSEMOB:IDP|DATAMGT,BANPCS:OPUS|IDP|CSRIDP,BANPCE:OPUS,BANPTONLS:MYATTSALES|IDP|UPPERFUNNEL|ANDIVA,BANPTONLE:MYATTSALES|IDP|ANDIVA,DTVNOWOTP:CSRIDP,CTNKSK:EXPKSK,BTN:IDP|DATAMGT,PINVALID:IDP|CSRIDP,NONATTCTN:IDP|CSRIDP|OPUS,ATTCTN:IDP|CSRIDP,EMAILOTP:IDP|OPUS,CRICKETOTP:IDP|CSRIDP|OPUS,EMAILPIN:IDP|CSRIDP|OPUS|ERICSSON|MYATTSALES|IDPSALES|MULESOFT|MYATTMOBILE,CTNDIH:IDP|CSRIDP|OPUS,BANAP:PENNYVA,TITANIMD:IDP|CSRIDP,CTN:IDP|CSRIDP,WBAN:IDP|CSRIDP,ECOMMSEC:IDP|CSRIDP,WBANSEC:IDP|CSRIDP,TITANSEC:IDP|CSRIDP,DTVOTP:DIRECTV,CTNAUTH:MULESOFT,CTNOPR:IDP|CSRIDP,ENCPIN:IDPSALES,PORTOUT:AVERTACK,CCPADTV:IDP,BSSEOTP:IDP|MULESOFT|IVR,BSSEONL:IDP,BSSEREGOTP:IDP')
		

		requestHeader.getRequestHeaders() >> requestHeaders
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
	}


	def "inquire p i n null request test"() {
		given:
		InquirePINRequest inquirePINRequestObj = null
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		when:
		InquirePINResponse inquirePINResponse = inquirePINReqValidatorObj.inquirePINRequestValidator(requestHeader,
				inquirePINRequestObj)
		then:
		inquirePINResponse.appInfo == 'Input Request Parameter is NULL / Empty.'
	}


	def "null x att client i d and c s i test"() {
		given:

		inquirePINReqObj.callingSystemId = null
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		when:
		InquirePINResponse inquirePINResponse = inquirePINReqValidatorObj.inquirePINRequestValidator(requestHeader,
				inquirePINReqObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> null
		inquirePINResponse.appInfo == 'Either X-ATT-ClientId in request header or callingSystemId in request body must be present'
	}

	def "null x att client i d valid c s i test"() {
		given:
		inquirePINReqObj.callingSystemId = 'IDP'
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		when:
		InquirePINResponse inquirePINResponse = inquirePINReqValidatorObj.inquirePINRequestValidator(requestHeader,
				inquirePINReqObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> null
		inquirePINResponse == null
	}


	def "valid x att client i d null c s i test"() {
		given:
		//Mockito.lenient().doReturn('IDP').when(requestHeader).getHeaderString('X-ATT-ClientId')
		inquirePINReqObj.callingSystemId = null
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		when:
		InquirePINResponse inquirePINResponse = inquirePINReqValidatorObj.inquirePINRequestValidator(requestHeader,
				inquirePINReqObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		inquirePINResponse == null
	}


	def "null identification type test"() {
		//Mockito.doReturn(null).when(requestHeader).getHeaderString("idp-trace-id");
		given:
		inquirePINReqObj.identificationType = null
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		when:
		InquirePINResponse inquirePINResponse = inquirePINReqValidatorObj.inquirePINRequestValidator(requestHeader,
				inquirePINReqObj)
		then:
		inquirePINResponse.appInfo == 'IdentificationType can not be null / empty.'
	}


	def "null account i d test"() {
		given:
		inquirePINReqObj.accountId = null
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		when:
		InquirePINResponse inquirePINResponse = inquirePINReqValidatorObj.inquirePINRequestValidator(requestHeader,
				inquirePINReqObj)
		then:
		inquirePINResponse.appInfo == 'AccountID can not be null / empty.'
	}


	def "invalid identification type test"() {
		given:
		inquirePINReqObj.identificationType = 'IEMOB'
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		when:
		InquirePINResponse inquirePINResponse = inquirePINReqValidatorObj.inquirePINRequestValidator(requestHeader,
				inquirePINReqObj)
		then:
		inquirePINResponse.appInfo == 'Input IdentificationType is not valid for CallingSystemId :IDP'
	}


	def "invalid c s i test"() {
		given:
		//Mockito.doReturn('DATAMGT').when(requestHeader).getHeaderString('X-ATT-ClientId')
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		when:
		InquirePINResponse inquirePINResponse = inquirePINReqValidatorObj.inquirePINRequestValidator(requestHeader,
				inquirePINReqObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'DATAMGT'
		inquirePINResponse.appInfo == ' Input X-ATT-ClientId or CallingSystemID  is not valid for IdentificationType :EMAILOTP'
	}


	def "request validator success test"() {
		given:
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		when:
		InquirePINResponse inquirePINResponse = inquirePINReqValidatorObj.inquirePINRequestValidator(requestHeader,
				inquirePINReqObj)
		then:
		inquirePINResponse == null
	}


	def "test request validator when prop c s i empty"() {
		given:
		ReflectionTestUtils.setField(inquirePINReqValidatorObj, 'propValidPINIDENTypeAndCSI', '')
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		when:
		InquirePINResponse inquirePINResponse = inquirePINReqValidatorObj.inquirePINRequestValidator(requestHeader,
				inquirePINReqObj)
		then:
		inquirePINResponse.appInfo == 'PROP_PIN_CSI  property is not configured in the properties file'
	}


	def "inquire p i n request c s i validator exception test"() throws Exception {
		given:
		ReflectionTestUtils.setField(inquirePINReqValidatorObj, 'propValidPINIDENTypeAndCSI', null)
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		when:
		InquirePINResponse inquirePINResponse = inquirePINReqValidatorObj.inquirePINRequestValidator(requestHeader,inquirePINReqObj)
		then:
		inquirePINResponse.appInfo == 'PROP_PIN_CSI  property is not configured in the properties file'
	}

	// ============================================================
	// Coverage: missing idp-trace-id returns error (lines 47-48)
	// ============================================================

	def "inquirePINRequestValidator returns error when idp-trace-id is missing"() {
		given:
		MDC.remove('idp-trace-id')
		def headerNoTrace = Stub(HttpHeaders)
		headerNoTrace.getHeaderString('idp-trace-id') >> null
		headerNoTrace.getHeaderString('X-ATT-UniqueTransactionId') >> null
		headerNoTrace.getHeaderString('X-ATT-ClientId') >> 'IDP'
		headerNoTrace.getRequestHeaders() >> new MultivaluedHashMap<>()

		when:
		InquirePINResponse resp = inquirePINReqValidatorObj.inquirePINRequestValidator(headerNoTrace, inquirePINReqObj)

		then:
		resp.appInfo == 'InquirePIN Request idp-trace-id is missing'
	}

	// ============================================================
	// Coverage: unknown attributes returns error (lines 73-75)
	// ============================================================

	def "inquirePINRequestValidator returns error when unknown attributes present"() {
		given:
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		inquirePINReqObj.unknownAttributes = CommonUtil.hashMap
		inquirePINReqObj.unknownAttributes.put('bogusField', 'bogusValue')

		when:
		InquirePINResponse resp = inquirePINReqValidatorObj.inquirePINRequestValidator(requestHeader, inquirePINReqObj)

		then:
		resp.appInfo == 'Invalid Attributes passed in InquirePINRequest : {bogusField=bogusValue}'
	}

}
