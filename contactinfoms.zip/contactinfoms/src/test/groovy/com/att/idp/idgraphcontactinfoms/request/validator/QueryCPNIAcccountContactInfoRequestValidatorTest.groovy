package com.att.idp.idgraphcontactinfoms.request.validator

import com.att.idp.idgraphcontactinfoms.resource.request.QueryCPNIAccountContactInfoRequest
import com.att.idp.idgraphcontactinfoms.resource.response.QueryCPNIAccountContactInfoResponse
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.junit.jupiter.MockitoExtension
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap

class QueryCPNIAcccountContactInfoRequestValidatorTest extends Specification {
	
	def queryCPNIAcccountContactInfoRequestValidatorObj = new QueryCPNIAcccountContactInfoRequestValidator()
	def queryCPNIAcccountContactInfoRequestObj

	def requestHeader = Stub(HttpHeaders)
	public MultivaluedHashMap requestHeaders = null
	private Map<String, String> headers = new HashMap<>()


	def setup() {

		requestHeaders = new MultivaluedHashMap<>(headers)
		queryCPNIAcccountContactInfoRequestObj = new QueryCPNIAccountContactInfoRequest()
		queryCPNIAcccountContactInfoRequestObj.callingSystemId = 'IDP'
		queryCPNIAcccountContactInfoRequestObj.accountInvariantId = '3958924'
		queryCPNIAcccountContactInfoRequestObj.accountId = '54567096'
		queryCPNIAcccountContactInfoRequestObj.accountType = 'TITAN'
		queryCPNIAcccountContactInfoRequestObj.returnCBRCTNs = 'Y'
		queryCPNIAcccountContactInfoRequestObj.accountId = '4256374859'
		queryCPNIAcccountContactInfoRequestObj.isExternalCall = 'Y'

		ReflectionTestUtils.setField(queryCPNIAcccountContactInfoRequestValidatorObj, 'propValidCallers', 'DATAMGT|IDP|CSRIDP|ILM|MULESOFT|OPUS|CUSTOMERGRAPH|AVERTACK')

		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getRequestHeaders() >> requestHeaders

	}


	def "query cpni acccount contact info success request test"() {
		when:
		QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
		then:
		queryCPNIAccountContactInfoResponse == null
	}


	def "query cpni acccount contact info null request test"() {
		when:
		QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, null)
		then:
		queryCPNIAccountContactInfoResponse.appInfo == 'Input Request is NULL / Empty.'
	}


	def "query cpni acccount contact info calling system i d test"() {
		given:
		//Mockito.doReturn(null).when(requestHeader).getHeaderString('X-ATT-ClientId')
		queryCPNIAcccountContactInfoRequestObj.callingSystemId = null
		when:
		QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> null
		queryCPNIAccountContactInfoResponse.appInfo == 'Either X-ATT-ClientId in request header or callingSystemId in request body must be present'
	}


	def "query cpni acccount contact info success null c s i valid client i d test"() {
		given:
		//Mockito.doReturn(null).when(requestHeader).getHeaderString('X-ATT-ClientId')
		queryCPNIAcccountContactInfoRequestObj.callingSystemId = 'IDP'
		when:
		QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> null
		queryCPNIAccountContactInfoResponse == null
	}


	def "query cpni acccount contact info success valid c s i null client i d test"() {
		given:
		//Mockito.doReturn('IDP').when(requestHeader).getHeaderString('X-ATT-ClientId')
		queryCPNIAcccountContactInfoRequestObj.callingSystemId = null
		when:
		QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		queryCPNIAccountContactInfoResponse == null
	}


	def "query cpni acccount contact info success valid c s i in valid client i d test"() {
		given:
		//Mockito.doReturn('IDL').when(requestHeader).getHeaderString('X-ATT-ClientId')
		queryCPNIAcccountContactInfoRequestObj.callingSystemId = 'IDP'
		when:
		QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		queryCPNIAccountContactInfoResponse == null
	}


	def "query cpni acccount contact info account type null test"() {
		given:
		queryCPNIAcccountContactInfoRequestObj.accountType = null
		when:
		QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
		then:
		queryCPNIAccountContactInfoResponse.appInfo == 'accountType must be present'
	}


	def "query cpni acccount contact info account id null test"() {
		given:
		queryCPNIAcccountContactInfoRequestObj.accountInvariantId = null
		queryCPNIAcccountContactInfoRequestObj.accountId = null
		when:
		QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
		then:
		queryCPNIAccountContactInfoResponse.appInfo == 'Either accountInvariantId or accountId must be present in input'
	}


	def "query cpni acccount contact info return c b r c t ns test"() {
		given:
		queryCPNIAcccountContactInfoRequestObj.returnCBRCTNs = 'aha'
		when:
		QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
		then:
		queryCPNIAccountContactInfoResponse.appInfo == 'returnCBRCTNs should be either Y or N'
	}


	def "query cpni acccount contact info is external call test"() {
		given:
		queryCPNIAcccountContactInfoRequestObj.isExternalCall = '9876534567'
		when:
		QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
		then:
		queryCPNIAccountContactInfoResponse.appInfo == 'isExternalCall must be one of Y or N'
	}


	def "query cpni acccount contact info account type test"() {
		given:
		queryCPNIAcccountContactInfoRequestObj.accountType = '82576478'
		when:
		QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
		then:
		queryCPNIAccountContactInfoResponse.appInfo == 'accountType is invalid'
	}


	def "query cpni acccount contact info account type and account invariant id test"() {
		given:
		queryCPNIAcccountContactInfoRequestObj.accountType = 'TITAN'
		queryCPNIAcccountContactInfoRequestObj.accountInvariantId = null
		when:
		QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
		then:
		queryCPNIAccountContactInfoResponse.appInfo == 'accountInvariantId is required for accountType TITAN'
	}


	def "query cpni acccount contact info calling system i ds test"() {
		given:
		//Mockito.doReturn('ooooo').when(requestHeader).getHeaderString('X-ATT-ClientId')
		queryCPNIAcccountContactInfoRequestObj.callingSystemId = null
		when:
		QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'ooooo'
		queryCPNIAccountContactInfoResponse.appInfo == 'Invalid X-ATT-ClientId in request header or callingSystemId in request body'
	}


	def "query cpni acccount contact info client id test"() {
		given:
		//Mockito.doReturn(null).when(requestHeader).getHeaderString('X-ATT-ClientId')
		queryCPNIAcccountContactInfoRequestObj.callingSystemId = 'yyyyy'
		when:
		QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> null
		queryCPNIAccountContactInfoResponse.appInfo == 'Invalid X-ATT-ClientId in request header or callingSystemId in request body'
	}


	def "query cpni acccount contact info exception test"() throws Exception {
		given:
		ReflectionTestUtils.setField(queryCPNIAcccountContactInfoRequestValidatorObj, 'propValidCallers', null)
		expect:
		queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
	}


	def "query cpni acccount contact info unknown attributes test"() {
        given:
        queryCPNIAcccountContactInfoRequestObj.unknownAttributes = ["foo": "bar"]
        when:
        QueryCPNIAccountContactInfoResponse response = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        response.appInfo.contains('Invalid Attributes passed in QueryCPNIAccountContactInfoRequest')
    }

    def "query cpni acccount contact info skip aging rule flag invalid test"() {
        given:
        queryCPNIAcccountContactInfoRequestObj.skipAgingRuleFlag = 'Z'
        when:
        QueryCPNIAccountContactInfoResponse response = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        response.appInfo == 'sSkipAgingRuleFlag must be one of Y or N'
    }

    def "query cpni acccount contact info is external call null sets default Y test"() {
        given:
        queryCPNIAcccountContactInfoRequestObj.isExternalCall = null
        when:
        queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        queryCPNIAcccountContactInfoRequestObj.isExternalCall == 'Y'
    }

    def "query cpni acccount contact info account invariant id present sets account id null test"() {
        given:
        queryCPNIAcccountContactInfoRequestObj.accountInvariantId = 'INV123'
        queryCPNIAcccountContactInfoRequestObj.accountId = 'ACC456'
        when:
        queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        queryCPNIAcccountContactInfoRequestObj.accountId == null
    }

    def "query cpni acccount contact info exception in parse valid callers test"() {
        given:
        ReflectionTestUtils.setField(queryCPNIAcccountContactInfoRequestValidatorObj, 'propValidCallers', 'A|B|C')
        queryCPNIAcccountContactInfoRequestObj.accountType = 'TITAN'
        queryCPNIAcccountContactInfoRequestObj.accountInvariantId = 'INV123'
        // Set unknownAttributes to empty map to avoid NPE
        queryCPNIAcccountContactInfoRequestObj.unknownAttributes = [:]
        when:
        QueryCPNIAccountContactInfoResponse response = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        response != null // Should not throw NPE
    }

    def "query cpni acccount contact info trace id empty string test"() {
        given:
        requestHeader.getHeaderString('idp-trace-id') >> ''
        when:
        QueryCPNIAccountContactInfoResponse response = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        response == null // Should proceed, not error, as empty string is not null or AutoGen_
    }

    def "query cpni acccount contact info trace id whitespace test"() {
        given:
        requestHeader.getHeaderString('idp-trace-id') >> '   '
        when:
        QueryCPNIAccountContactInfoResponse response = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        response == null // Should proceed, not error, as whitespace is not null or AutoGen_
    }

    def "query cpni acccount contact info calling system id empty string test"() {
        given:
        queryCPNIAcccountContactInfoRequestObj.callingSystemId = ''
        requestHeader.getHeaderString('X-ATT-ClientId') >> ''
        when:
        QueryCPNIAccountContactInfoResponse response = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        response.appInfo == 'Either X-ATT-ClientId in request header or callingSystemId in request body must be present'
    }

    def "query cpni acccount contact info calling system id whitespace test"() {
        given:
        queryCPNIAcccountContactInfoRequestObj.callingSystemId = '   '
        requestHeader.getHeaderString('X-ATT-ClientId') >> '   '
        when:
        QueryCPNIAccountContactInfoResponse response = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        response.appInfo == 'Either X-ATT-ClientId in request header or callingSystemId in request body must be present'
    }

    def "query cpni acccount contact info account type empty string test"() {
        given:
        queryCPNIAcccountContactInfoRequestObj.accountType = ''
        when:
        QueryCPNIAccountContactInfoResponse response = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        response.appInfo == 'accountType must be present'
    }

    def "query cpni acccount contact info account type whitespace test"() {
        given:
        queryCPNIAcccountContactInfoRequestObj.accountType = '   '
        when:
        QueryCPNIAccountContactInfoResponse response = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        response.appInfo == 'accountType must be present'
    }

    def "query cpni acccount contact info account id empty string test"() {
        given:
        queryCPNIAcccountContactInfoRequestObj.accountInvariantId = null
        queryCPNIAcccountContactInfoRequestObj.accountId = ''
        when:
        QueryCPNIAccountContactInfoResponse response = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        response.appInfo == 'Either accountInvariantId or accountId must be present in input'
    }

    def "query cpni acccount contact info account id whitespace test"() {
        given:
        queryCPNIAcccountContactInfoRequestObj.accountInvariantId = null
        queryCPNIAcccountContactInfoRequestObj.accountId = '   '
        when:
        QueryCPNIAccountContactInfoResponse response = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        response.appInfo == 'Either accountInvariantId or accountId must be present in input'
    }

    def "query cpni acccount contact info account invariant id empty string test"() {
        given:
        queryCPNIAcccountContactInfoRequestObj.accountType = 'TITAN'
        queryCPNIAcccountContactInfoRequestObj.accountInvariantId = ''
        when:
        QueryCPNIAccountContactInfoResponse response = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        response.appInfo == 'accountInvariantId is required for accountType TITAN'
    }

    def "query cpni acccount contact info account invariant id whitespace test"() {
        given:
        queryCPNIAcccountContactInfoRequestObj.accountType = 'TITAN'
        queryCPNIAcccountContactInfoRequestObj.accountInvariantId = '   '
        when:
        QueryCPNIAccountContactInfoResponse response = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        response.appInfo == 'accountInvariantId is required for accountType TITAN'
    }

    def "query cpni acccount contact info skip aging rule flag empty string test"() {
        given:
        queryCPNIAcccountContactInfoRequestObj.skipAgingRuleFlag = ''
        when:
        QueryCPNIAccountContactInfoResponse response = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        response.appStatusMsg == "ERR_INVALID_DATA"
    }

    def "query cpni acccount contact info skip aging rule flag whitespace test"() {
        given:
        queryCPNIAcccountContactInfoRequestObj.skipAgingRuleFlag = '   '
        when:
        QueryCPNIAccountContactInfoResponse response = queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        response.appInfo == 'sSkipAgingRuleFlag must be one of Y or N'
    }

    def "query cpni acccount contact info is external call empty string test"() {
        given:
        queryCPNIAcccountContactInfoRequestObj.isExternalCall = ''
        when:
        queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        queryCPNIAcccountContactInfoRequestObj.isExternalCall == 'Y'
    }

    def "query cpni acccount contact info is external call whitespace test"() {
        given:
        queryCPNIAcccountContactInfoRequestObj.isExternalCall = '   '
        when:
        queryCPNIAcccountContactInfoRequestValidatorObj.queryCPNIAccountContactRequestValidator(requestHeader, queryCPNIAcccountContactInfoRequestObj)
        then:
        queryCPNIAcccountContactInfoRequestObj.isExternalCall == 'Y'
    }
}
