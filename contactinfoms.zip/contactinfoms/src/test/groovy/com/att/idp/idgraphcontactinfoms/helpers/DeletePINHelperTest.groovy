package com.att.idp.idgraphcontactinfoms.helpers

import com.att.idp.idgraph.db.cosmos.entity.IdgOtpContainer
import com.att.idp.idgraph.db.cosmos.entity.Operation
import com.att.idp.idgraph.db.cosmos.entity.SecurityCode
import com.att.idp.idgraph.db.cosmos.helper.IdgOtpDBHelper
import com.att.idp.idgraph.db.cosmos.helper.OtpHistoryDBHelper
import java.util.concurrent.Executor
import com.att.idp.idgraphcontactinfoms.db.helper.SecurityCodeDBHelper
import com.att.idp.idgraphcontactinfoms.helpers.voltage.ProofingEncryptionHelper
import com.att.mpsys.common.helpers.FeatureManagerHelper

import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.MPSDefs
import java.security.MessageDigest
import org.jboss.logging.MDC
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Specification
import com.att.idp.idgraphcontactinfoms.service.async.AsyncOtpEventPublisher

class DeletePINHelperTest extends Specification {

    def DeletePINHelper deletePINHelper
    SecurityCodeDBHelper securityCodeDBHelper = Mock(SecurityCodeDBHelper)
    ProofingEncryptionHelper proofingEncryptionHelper = Mock(ProofingEncryptionHelper)
    FeatureManagerHelper featureManager = Mock(FeatureManagerHelper)
    IdgOtpDBHelper idgOtpDBHelper = Mock(IdgOtpDBHelper)
    AsyncOtpEventPublisher otpEventPublisher = Mock(AsyncOtpEventPublisher)
    OtpHistoryDBHelper otpHistoryDBHelper = Mock(OtpHistoryDBHelper)
    Executor otpHistoryExecutor = { Runnable r -> r.run() } as Executor

    Logger logger = null
    HashMap hmInput = null
    HashMap hmDBInput = null

    def setup() throws Exception {
        deletePINHelper = new DeletePINHelper(otpHistoryDBHelper, otpHistoryExecutor)
        deletePINHelper.securityCodeDBHelper = securityCodeDBHelper
        deletePINHelper.proofingEncryptionHelper = proofingEncryptionHelper
        deletePINHelper.featureManager = featureManager
        deletePINHelper.idgOtpDBHelper = idgOtpDBHelper
        deletePINHelper.otpEventPublisher = otpEventPublisher

        logger = LoggerFactory.getLogger('DeletePIN')
        MDC.put('transid', 'test123')
        System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')

        hmInput = new HashMap()
        hmInput['transactionName'] = 'DeletePIN'
        hmInput['callingSystemId'] = 'DATAMGT'
        hmInput['accountId'] = '000981453456'
        hmInput['identificationType'] = 'IDSEMOB'
        hmInput['securityCode'] = '1990122'
        hmInput['reasonCode'] = 'PW RESET'
        hmInput['deleteAll'] = 'N'
        hmInput['agentId'] = '1234'
        hmInput['sourceIPAddress'] = '10.12.13.223'
        hmInput['transactionId'] = 'test1234'
        hmInput['idpTraceId']='121313'

        hmDBInput = new HashMap()
        hmDBInput[MPSDefs.DB_IDENTIFICATION_TYPE] = 'IDSEMOB'
        hmDBInput[MPSDefs.DB_ACCOUNT_ID] = '000981453456'
        hmDBInput[MPSDefs.DB_SECURITY_CODE] = '@#!*47BDcW%'
        hmDBInput[MPSDefs.DB_REASON_CODE] = 'PW RESET'
    }

    def cleanup() throws Exception {
        MDC.remove('transid')
    }

    def "test delete pin exception case"() {
        given:
        hmInput['accountId'] = 453456

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        //resp[CommonDefs.COMMON_APP_INFO] == 'SYSTEM ERROR'
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "test delete pin empty security code"() {
        given:
        hmInput['securityCode'] = ''

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SecurityCode is missing'
    }

    def "test delete pin empty reason code"() {
        given:
        hmInput['reasonCode'] = ''

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'ReasonCode is missing'
    }

    def "test delete pin invalid reason code"() {
        given:
        hmInput['reasonCode'] = 'TEST1234'
        hmInput['isExternalCall'] = 'Y'
        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'reasonCode should be one of REGISTERED or PW RESET'
    }

    def "test delete pin for success with delete all is y"() {
        given:
        hmInput['deleteAll'] = 'Y'
        HashMap hmDBInput = new HashMap()
        hmDBInput[MPSDefs.DB_IDENTIFICATION_TYPE] = 'IDSEMOB'
        hmDBInput[MPSDefs.DB_ACCOUNT_ID] = '000981453456'
        HashMap hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ORACLEMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmResponse
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmResponse
        featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata")>>true
        1 * otpEventPublisher.publishDeletePinEvent(_, _) >> _

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "delete all history stores marker message"() {
        given:
        hmInput['deleteAll'] = 'Y'
        HashMap hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ORACLEMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmResponse
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> false
        1 * otpHistoryDBHelper.saveOtpHistory({ history ->
            history.accountId == '000981453456' &&
                    history.identificationType == 'IDSEMOB' &&
                    history.historyMetadata.operation == Operation.DELETE &&
                    history.historyMetadata.message == 'Delete All was used to clear all OTPs' &&
                    history.securityCodes == null
        })

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "test delete pin for error with delete all is y"() {
        given:
        hmInput['deleteAll'] = 'Y'
        HashMap hmDBInput = new HashMap()
        hmDBInput[MPSDefs.DB_IDENTIFICATION_TYPE] = 'IDSEMOB'
        hmDBInput[MPSDefs.DB_ACCOUNT_ID] = '000981453456'
        HashMap hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INCORRECT_CODE_NUM, 'No Record Found in SECURITYCODE table for this account.')
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmResponse

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'No Record Found in SECURITYCODE table for this account.'
    }

    def "test delete pin for success with delete all is n"() {
        given:
        hmInput['deleteAll'] = 'N'
        HashMap hmDBInput = new HashMap()
        hmDBInput[MPSDefs.DB_IDENTIFICATION_TYPE] = 'IDSEMOB'
        hmDBInput[MPSDefs.DB_ACCOUNT_ID] = '000981453456'
        HashMap hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ORACLEMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmResponse
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmResponse
        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "single delete saves UPDATE then DELETE history records"() {
        given:
        hmInput['deleteAll'] = 'N'
        HashMap hmOracleResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        SecurityCode removedCode = SecurityCode.builder()
                .securityCode('sha256-code')
                .securityCodeStatus('REGISTERED')
                .deliveryMethod('SMS')
                .build()
        SecurityCode remainingCode = SecurityCode.builder()
                .securityCode('other-code')
                .securityCodeStatus('ACTIVE')
                .deliveryMethod('E')
                .build()
        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        hmCosmosResponse.put('removedSecurityCodes', [removedCode])

        IdgOtpContainer containerAfterRemoval = new IdgOtpContainer()
        containerAfterRemoval.setSecurityCodes([remainingCode])

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ORACLEMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleResponse
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> false
        1 * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.of(containerAfterRemoval)
        1 * otpHistoryDBHelper.saveOtpHistory({ history ->
            history.accountId == '000981453456' &&
                    history.identificationType == 'IDSEMOB' &&
                    history.historyMetadata.operation == Operation.UPDATE &&
                    history.historyMetadata.message == null &&
                    history.securityCodes?.size() == 2 &&
                    history.securityCodes.any { it.securityCode == 'other-code' && it.securityCodeStatus == 'ACTIVE' } &&
                    history.securityCodes.any { it.securityCode == 'sha256-code' && it.securityCodeStatus == 'REGISTERED' }
        })
        1 * otpHistoryDBHelper.saveOtpHistory({ history ->
            history.accountId == '000981453456' &&
                    history.identificationType == 'IDSEMOB' &&
                    history.historyMetadata.operation == Operation.DELETE &&
                    history.historyMetadata.message == null &&
                    history.securityCodes?.size() == 1 &&
                    history.securityCodes[0].securityCode == 'sha256-code'
        })

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    // ============================================================
    // Tests for Cosmos DB error handling in ORACLEMASTER mode
    // (commit 2db8962c - DPH_2.3_COSMOS)
    // ============================================================

    def "ORACLEMASTER: Cosmos deleteSecurityPIN error response is logged and processing continues"() {
        given: "ORACLEMASTER mode with Cosmos deleteSecurityPIN returning error"
        hmInput['deleteAll'] = 'Y'
        HashMap hmOracleSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        HashMap hmCosmosError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INCORRECT_CODE_NUM, 'Cosmos delete failed')

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ORACLEMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleSuccess
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosError

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then: "Processing continues despite Cosmos error - returns success"
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "ORACLEMASTER: Cosmos deleteSecurityPIN exception is caught and processing continues"() {
        given: "ORACLEMASTER mode with Cosmos throwing exception on deleteSecurityPIN"
        hmInput['deleteAll'] = 'Y'
        HashMap hmOracleSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ORACLEMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleSuccess
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> { throw new RuntimeException("Cosmos connection timeout") }

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then: "Exception is caught, processing continues to success"
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
        notThrown(RuntimeException)
    }

    def "COSMOSMASTER: Cosmos deleteSecurityPIN exception is re-thrown"() {
        given: "COSMOSMASTER mode with Cosmos throwing exception on deleteSecurityPIN"
        hmInput['deleteAll'] = 'Y'
        HashMap hmOracleSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "COSMOSMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleSuccess
        // In COSMOSMASTER, Oracle is skipped, Cosmos throws
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> { throw new RuntimeException("Cosmos connection timeout") }

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then: "Exception propagates to outer catch, returning system error"
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "ORACLEMASTER: Cosmos deleteSecurityPIN error response for single delete is logged and processing continues"() {
        given: "ORACLEMASTER mode with single delete - Cosmos returns error"
        hmInput['deleteAll'] = 'N'
        HashMap hmOracleSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        HashMap hmCosmosError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INCORRECT_CODE_NUM, 'Cosmos delete failed')

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ORACLEMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleSuccess
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosError

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then: "Processing continues despite Cosmos error - returns success"
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "non-ORACLEMASTER: Cosmos deleteSecurityPIN error response returns error to caller"() {
        given: "Non-ORACLEMASTER mode (default) with Cosmos deleteSecurityPIN returning error"
        hmInput['deleteAll'] = 'Y'
        HashMap hmOracleSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        HashMap hmCosmosError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INCORRECT_CODE_NUM, 'Cosmos delete failed')

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "COSMOSMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleSuccess
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosError

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then: "Error is returned to caller"
        resp[CommonDefs.COMMON_APP_INFO] == 'Cosmos delete failed'
    }

    // ============================================================
    // ONLYCOSMOS data source tests
    // ============================================================

    def "ONLYCOSMOS: skips Oracle and only calls Cosmos for delete all"() {
        given:
        hmInput['deleteAll'] = 'Y'
        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ONLYCOSMOS"
        0 * securityCodeDBHelper.deleteSecurityPIN(_, _)
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> false

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "ONLYCOSMOS: skips Oracle and only calls Cosmos for single delete"() {
        given:
        hmInput['deleteAll'] = 'N'
        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ONLYCOSMOS"
        0 * securityCodeDBHelper.deleteSecurityPIN(_, _)
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> false

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    // ============================================================
    // ONLYORACLE data source tests
    // ============================================================

    def "ONLYORACLE: skips Cosmos and only calls Oracle for delete all"() {
        given:
        hmInput['deleteAll'] = 'Y'
        HashMap hmOracleResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ONLYORACLE"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleResponse
        0 * idgOtpDBHelper.deleteSecurityPIN(_, _)

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "ONLYORACLE: skips Cosmos and only calls Oracle for single delete"() {
        given:
        hmInput['deleteAll'] = 'N'
        HashMap hmOracleResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ONLYORACLE"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleResponse
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        0 * idgOtpDBHelper.deleteSecurityPIN(_, _)

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    // ============================================================
    // Event publishing tests for single delete
    // ============================================================

    def "single delete publishes ValidatePIN event when publish enabled and removedSecurityCodes present"() {
        given:
        hmInput['deleteAll'] = 'N'

        SecurityCode removedCode = SecurityCode.builder()
                .securityCode('sha256_encrypted')
                .verificationFailureCount(2)
                .securityCodeExpires('2026-03-30T15:00:00Z')
                .securityCodeStatus('REGISTERED')
                .source('ONL')
                .deliveryMethod('S')
                .deliveryDetail('1234567890')
                .build()

        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        hmCosmosResponse.put('removedSecurityCodes', [removedCode])

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ONLYCOSMOS"
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> true
        1 * otpEventPublisher.publishValidatePinEvent('000981453456', _)

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "single delete does not publish event when removedSecurityCodes is empty"() {
        given:
        hmInput['deleteAll'] = 'N'
        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        hmCosmosResponse.put('removedSecurityCodes', [])

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ONLYCOSMOS"
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> true
        0 * otpEventPublisher.publishValidatePinEvent(_, _)

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "single delete does not publish when removedSecurityCodes is null"() {
        given:
        hmInput['deleteAll'] = 'N'
        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ONLYCOSMOS"
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> true
        0 * otpEventPublisher.publishValidatePinEvent(_, _)

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "single delete does not publish when feature flag disabled"() {
        given:
        hmInput['deleteAll'] = 'N'
        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        SecurityCode removedCode = SecurityCode.builder()
                .securityCode('sha256_encrypted')
                .securityCodeStatus('REGISTERED')
                .build()
        hmCosmosResponse.put('removedSecurityCodes', [removedCode])

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ONLYCOSMOS"
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> false
        0 * otpEventPublisher.publishValidatePinEvent(_, _)

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    // ============================================================
    // Event publishing with Date type parsing
    // ============================================================

    def "single delete builds event data from SecurityCode entity with valid fields"() {
        given:
        hmInput['deleteAll'] = 'N'

        SecurityCode removedCode = SecurityCode.builder()
                .securityCode('sha256_encrypted')
                .verificationFailureCount(0)
                .securityCodeExpires('2026-12-31T23:59:59Z')
                .securityCodeStatus('ACTIVE')
                .source('IVR')
                .deliveryMethod('E')
                .deliveryDetail('test@att.com')
                .build()
        removedCode.setCreatedDate(java.time.LocalDateTime.now())

        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        hmCosmosResponse.put('removedSecurityCodes', [removedCode])

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ONLYCOSMOS"
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> true
        1 * otpEventPublisher.publishValidatePinEvent('000981453456', _)

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "single delete builds event data from SecurityCode entity with invalid expiry string"() {
        given:
        hmInput['deleteAll'] = 'N'

        SecurityCode removedCode = SecurityCode.builder()
                .securityCode('sha256_encrypted')
                .verificationFailureCount(0)
                .securityCodeExpires('INVALID_DATE')
                .securityCodeStatus('ACTIVE')
                .source('ONL')
                .deliveryMethod('S')
                .deliveryDetail('5551234567')
                .build()

        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        hmCosmosResponse.put('removedSecurityCodes', [removedCode])

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ONLYCOSMOS"
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> true
        1 * otpEventPublisher.publishValidatePinEvent('000981453456', _)

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "single delete builds event data from SecurityCode entity with null expiry and null create date"() {
        given:
        hmInput['deleteAll'] = 'N'

        SecurityCode removedCode = SecurityCode.builder()
                .securityCode('sha256_encrypted')
                .verificationFailureCount(0)
                .securityCodeExpires(null)
                .securityCodeStatus('ACTIVE')
                .source('ONL')
                .deliveryMethod('S')
                .deliveryDetail('5551234567')
                .build()

        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        hmCosmosResponse.put('removedSecurityCodes', [removedCode])

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ONLYCOSMOS"
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> true
        1 * otpEventPublisher.publishValidatePinEvent('000981453456', _)

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    // ============================================================
    // ONLYORACLE history behavior tests
    // ============================================================

    def "ONLYORACLE skips all history saves"() {
        given:
        hmInput['deleteAll'] = 'N'
        HashMap hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ONLYORACLE"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmResponse
        0 * otpHistoryDBHelper.saveOtpHistory(_)
        0 * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_)

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    // ============================================================
    // getOtpDataSource tests
    // ============================================================

    def "getOtpDataSource returns COSMOSMASTER when feature flag is null"() {
        given:
        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> null

        when:
        String result = deletePINHelper.getOtpDataSource()

        then:
        result == 'COSMOSMASTER'
    }

    def "getOtpDataSource returns valid data source values"() {
        given:
        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> dataSource

        when:
        String result = deletePINHelper.getOtpDataSource()

        then:
        result == dataSource

        where:
        dataSource << ['ORACLEMASTER', 'ONLYORACLE', 'ONLYCOSMOS', 'COSMOSMASTER']
    }

    def "getOtpDataSource throws IllegalArgumentException for invalid data source"() {
        given:
        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "INVALID_SOURCE"

        when:
        deletePINHelper.getOtpDataSource()

        then:
        thrown(IllegalArgumentException)
    }

    // ============================================================
    // validateInput - IS_EXTERNAL_CALL defaulting
    // ============================================================

    def "validateInput defaults IS_EXTERNAL_CALL to Y when not present"() {
        given:
        hmInput.remove('isExternalCall')
        hmInput['deleteAll'] = 'N'
        hmInput['securityCode'] = '123456'
        hmInput['reasonCode'] = 'REGISTERED'

        when:
        Map<String, Object> resp = deletePINHelper.validateInput(hmInput)

        then:
        hmInput[CommonDefs.IS_EXTERNAL_CALL] == 'Y'
        resp[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    def "validateInput with null security code for deleteAll=N returns error"() {
        given:
        hmInput['deleteAll'] = 'N'
        hmInput['securityCode'] = null

        when:
        Map<String, Object> resp = deletePINHelper.validateInput(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SecurityCode is missing'
    }

    def "validateInput with null reason code for deleteAll=N returns error"() {
        given:
        hmInput['deleteAll'] = 'N'
        hmInput['securityCode'] = '123456'
        hmInput['reasonCode'] = null

        when:
        Map<String, Object> resp = deletePINHelper.validateInput(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'ReasonCode is missing'
    }

    def "validateInput succeeds for deleteAll=Y without securityCode or reasonCode"() {
        given:
        hmInput['deleteAll'] = 'Y'
        hmInput.remove('securityCode')
        hmInput.remove('reasonCode')

        when:
        Map<String, Object> resp = deletePINHelper.validateInput(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    // ============================================================
    // History pair async with container read failure
    // ============================================================

    def "saveDeleteHistoryPairAsync gracefully handles container read failure"() {
        given:
        hmInput['deleteAll'] = 'N'
        HashMap hmOracleResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        SecurityCode removedCode = SecurityCode.builder()
                .securityCode('sha256-code')
                .securityCodeStatus('REGISTERED')
                .build()
        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        hmCosmosResponse.put('removedSecurityCodes', [removedCode])

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ORACLEMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleResponse
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> false
        1 * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> { throw new RuntimeException("DB read failed") }
        1 * otpHistoryDBHelper.saveOtpHistory({ history ->
            history.historyMetadata.operation == Operation.UPDATE &&
                    history.securityCodes?.size() == 1 &&
                    history.securityCodes[0].securityCode == 'sha256-code'
        })
        1 * otpHistoryDBHelper.saveOtpHistory({ history ->
            history.historyMetadata.operation == Operation.DELETE
        })

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "saveDeleteHistoryPairAsync handles empty container"() {
        given:
        hmInput['deleteAll'] = 'N'
        HashMap hmOracleResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        SecurityCode removedCode = SecurityCode.builder()
                .securityCode('sha256-code')
                .securityCodeStatus('REGISTERED')
                .build()
        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        hmCosmosResponse.put('removedSecurityCodes', [removedCode])

        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ORACLEMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleResponse
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> false
        1 * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()
        1 * otpHistoryDBHelper.saveOtpHistory({ history ->
            history.historyMetadata.operation == Operation.UPDATE &&
                    history.securityCodes?.size() == 1
        })
        1 * otpHistoryDBHelper.saveOtpHistory({ history ->
            history.historyMetadata.operation == Operation.DELETE
        })

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    // ============================================================
    // publishotpdata enabled with non-deleteAll triggers buildValidateEventData
    // Covers lines 221-239, 301-307, 310-334, 337-383
    // ============================================================

    def "deletePin publishes validate event when publishotpdata enabled and removedSecurityCodes present with String expiry"() {
        given:
        hmInput['deleteAll'] = 'N'
        HashMap hmOracleResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        SecurityCode removedCode = SecurityCode.builder()
                .securityCode('sha256_encrypted_code')
                .verificationFailureCount(2)
                .securityCodeExpires('2026-12-31T23:59:59Z')
                .securityCodeStatus('ACTIVE')
                .source('COSMOS')
                .deliveryMethod('E')
                .deliveryDetail('user@att.com')
                .build()

        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        hmCosmosResponse.put('removedSecurityCodes', [removedCode])

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ORACLEMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleResponse
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> true
        1 * otpEventPublisher.publishValidatePinEvent('000981453456', { eventData ->
            eventData.accountId == '000981453456' &&
            eventData.identificationType == 'IDSEMOB' &&
            eventData.securityAccountEvent != null &&
            eventData.securityCodeEvent != null &&
            eventData.securityCodeEvent.securityCode == 'sha256_encrypted_code' &&
            eventData.securityCodeEvent.verificationFailureCount == '2' &&
            eventData.securityCodeEvent.securityCodeStatus == 'ACTIVE' &&
            eventData.securityCodeEvent.deliveryMethod == 'E' &&
            eventData.securityAccountEvent.cumulativeFailureCount == '2'
        })
        _ * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()
        _ * otpHistoryDBHelper.saveOtpHistory(_)

        and:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "deletePin publishes validate event with null createDate on SecurityCode entity"() {
        given:
        hmInput['deleteAll'] = 'N'
        HashMap hmOracleResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        SecurityCode removedCode = SecurityCode.builder()
                .securityCode('sha256_encrypted_code')
                .verificationFailureCount(0)
                .securityCodeExpires('2026-12-31T23:59:59Z')
                .securityCodeStatus('REGISTERED')
                .deliveryMethod('S')
                .deliveryDetail('5551234567')
                .build()

        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        hmCosmosResponse.put('removedSecurityCodes', [removedCode])

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ORACLEMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleResponse
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> true
        1 * otpEventPublisher.publishValidatePinEvent('000981453456', { eventData ->
            eventData.securityAccountEvent.cumulativeFailureCount == '0' &&
            eventData.securityCodeEvent.verificationFailureCount == '0' &&
            eventData.securityCodeEvent.createdDate != null
        })
        _ * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()
        _ * otpHistoryDBHelper.saveOtpHistory(_)

        and:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "deletePin publishes validate event with invalid expiry date string on SecurityCode entity"() {
        given:
        hmInput['deleteAll'] = 'N'
        HashMap hmOracleResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        SecurityCode removedCode = SecurityCode.builder()
                .securityCode('sha256_encrypted_code')
                .verificationFailureCount(0)
                .securityCodeExpires('INVALID-DATE-FORMAT')
                .securityCodeStatus('ACTIVE')
                .deliveryMethod('E')
                .deliveryDetail('test@att.com')
                .build()

        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        hmCosmosResponse.put('removedSecurityCodes', [removedCode])

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ORACLEMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleResponse
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> true
        1 * otpEventPublisher.publishValidatePinEvent('000981453456', { eventData ->
            eventData.securityCodeEvent.createdDate != null
        })
        _ * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()
        _ * otpHistoryDBHelper.saveOtpHistory(_)

        and:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "deletePin publishotpdata enabled but empty removedSecurityCodes skips event publish"() {
        given:
        hmInput['deleteAll'] = 'N'
        HashMap hmOracleResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        hmCosmosResponse.put('removedSecurityCodes', [])

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ORACLEMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleResponse
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> true
        0 * otpEventPublisher.publishValidatePinEvent(_, _)
        _ * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()
        _ * otpHistoryDBHelper.saveOtpHistory(_)

        and:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "deletePin publishotpdata enabled but null removedSecurityCodes skips event publish"() {
        given:
        hmInput['deleteAll'] = 'N'
        HashMap hmOracleResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ORACLEMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleResponse
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> true
        0 * otpEventPublisher.publishValidatePinEvent(_, _)
        _ * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()
        _ * otpHistoryDBHelper.saveOtpHistory(_)

        and:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    // ============================================================
    // saveOtpHistoryAsync exception path (lines 460-461)
    // ============================================================

    def "saveOtpHistoryAsync logs error when saveOtpHistory throws exception on deleteAll"() {
        given:
        hmInput['deleteAll'] = 'Y'
        HashMap hmOracleResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ORACLEMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleResponse
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> false
        1 * otpHistoryDBHelper.saveOtpHistory(_) >> { throw new RuntimeException("History save failed") }

        and:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    // ============================================================
    // saveDeleteHistoryPairAsync exception path (lines 514-515)
    // ============================================================

    def "saveDeleteHistoryPairAsync logs error when saveOtpHistory throws exception"() {
        given:
        hmInput['deleteAll'] = 'N'
        HashMap hmOracleResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        SecurityCode removedCode = SecurityCode.builder()
                .securityCode('sha256-code')
                .securityCodeStatus('REGISTERED')
                .build()
        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        hmCosmosResponse.put('removedSecurityCodes', [removedCode])

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ORACLEMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleResponse
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> false
        1 * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()
        1 * otpHistoryDBHelper.saveOtpHistory(_) >> { throw new RuntimeException("History save failed") }

        and:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "deletePin publishotpdata enabled with removedSecurityCodes publishes event in ORACLEMASTER"() {
        given:
        hmInput['deleteAll'] = 'N'
        HashMap hmOracleResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        SecurityCode removedCode = SecurityCode.builder()
                .securityCode('sha256_code')
                .securityCodeStatus('REGISTERED')
                .deliveryMethod('S')
                .deliveryDetail('5551234567')
                .build()

        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        hmCosmosResponse.put('removedSecurityCodes', [removedCode])

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ORACLEMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleResponse
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> true
        1 * otpEventPublisher.publishValidatePinEvent('000981453456', _)
        _ * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()
        _ * otpHistoryDBHelper.saveOtpHistory(_)

        and:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "deletePin with LocalDateTime createDate on SecurityCode entity"() {
        given:
        hmInput['deleteAll'] = 'N'
        HashMap hmOracleResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')

        SecurityCode removedCode = SecurityCode.builder()
                .securityCode('sha256_encrypted_code')
                .verificationFailureCount(0)
                .securityCodeExpires(null)
                .securityCodeStatus('ACTIVE')
                .deliveryMethod('S')
                .deliveryDetail('5551234567')
                .build()
        removedCode.setCreatedDate(java.time.LocalDateTime.of(2026, 1, 15, 10, 0, 0))

        HashMap hmCosmosResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
        hmCosmosResponse.put('removedSecurityCodes', [removedCode])

        when:
        HashMap<String, Object> resp = deletePINHelper.deletePin(hmInput)

        then:
        1 * featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ORACLEMASTER"
        1 * securityCodeDBHelper.deleteSecurityPIN(_, _) >> hmOracleResponse
        1 * proofingEncryptionHelper.generateSHA1Value(_) >> 'encrypted_secCode'
        1 * idgOtpDBHelper.deleteSecurityPIN(_, _) >> hmCosmosResponse
        1 * featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata") >> true
        1 * otpEventPublisher.publishValidatePinEvent('000981453456', { eventData ->
            eventData.securityCodeEvent.createdDate != null &&
            eventData.securityAccountEvent.accountEntryExpires == null
        })
        _ * idgOtpDBHelper.findByIdentificationTypeAndAccountId(_) >> Optional.empty()
        _ * otpHistoryDBHelper.saveOtpHistory(_)

        and:
        resp[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }
}