package com.att.idp.idgraphcontactinfoms.service.impl

import com.att.idp.idgraphcontactinfoms.exceptions.InvalidInputDataException
import com.att.idp.idgraphcontactinfoms.helpers.DeletePINHelper
import com.att.idp.idgraphcontactinfoms.resource.request.DeletePINRequest
import com.att.idp.idgraphcontactinfoms.resource.response.DeletePinResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import jakarta.ws.rs.core.MultivaluedMap
import spock.lang.Specification
import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap
import static org.junit.jupiter.api.Assertions.assertThrows

class DeletePINServiceImplTest extends Specification {

	def DeletePINServiceImpl deletePINServiceImplObj = new DeletePINServiceImpl()
	DeletePINHelper deletePinHelperObj = Mock(DeletePINHelper)

	DeletePINRequest deletePINRequest = null
	MultivaluedMap<String, String> requestHeader = null
	Map<String, String> headers = new HashMap<>()

	def setup() throws Exception {
		deletePINServiceImplObj.deletePinHelper = deletePinHelperObj
		deletePINRequest = new DeletePINRequest()
		requestHeader = new MultivaluedHashMap<>(headers)

		deletePINRequest.callingSystemId = 'IDP'
		deletePINRequest.accountId = '64573738'
		deletePINRequest.securityCode = '099743'
		deletePINRequest.deleteAll = 'Y'
		deletePINRequest.identificationType = 'EMAILOTP'
		deletePINRequest.reasonCode = 'registered'
		deletePINRequest.agentId = 'ad4637'
		deletePINRequest.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
	}

	def "test delet pin null case"() {
		// when delete pin helper response not set
		when:
		DeletePinResponse response = deletePINServiceImplObj.deletePin(deletePINRequest, requestHeader)
		then:
		response.appInfo == 'Null response from deletePinHelper.deletePin'

		// when delete pin helper response has been set, app status code is null
		HashMap hmResponse = new HashMap()
		when:
		hmResponse[MPSDefs.APP_STATUS_CODE] = null
		deletePinHelperObj.deletePin(_) >> hmResponse
		response = deletePINServiceImplObj.deletePin(deletePINRequest, requestHeader)
		then:
		response.appInfo == 'Null response from deletePinHelper.deletePin'
	}

	def "test delet pin success case"() {
		given:
		HashMap hmResponse = new HashMap()
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_16374856'
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		hmResponse['appInfo'] = 'Success'
		deletePinHelperObj.deletePin(_) >> hmResponse
		when:
		DeletePinResponse response = deletePINServiceImplObj.deletePin(deletePINRequest, requestHeader)
		then:
		response != null
		response.idpTraceId != null
		response.transactionName == 'DeletePIN'
	}

	def "test delet pin when trans rollback set"() {
		given:
		HashMap hmResponse = new HashMap()
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_16374856'
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		hmResponse['isTransactionRollback'] = 'true'
		deletePinHelperObj.deletePin(_) >> hmResponse

		expect:
		InvalidInputDataException excep = assertThrows(InvalidInputDataException.class, () -> {
			deletePINServiceImplObj.deletePin(deletePINRequest, requestHeader)
		})
	}
}