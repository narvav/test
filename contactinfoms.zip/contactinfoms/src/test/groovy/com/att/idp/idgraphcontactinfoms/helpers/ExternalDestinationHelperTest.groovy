package com.att.idp.idgraphcontactinfoms.helpers

import com.att.idp.idgraphcontactinfoms.integration.Async.AsyncCall
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.CommonUtil
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class ExternalDestinationHelperTest extends Specification {

    ExternalDestinationHelper externalDestinationHelperObj
    AsyncCall asyncCall

    String stTransactionId = null
    Logger logger = null
    HashMap resultHashSuccess = null
    HashMap resultHashError = null
    HashMap hmResult = null
    HashMap hmInput = null
    String stAppStatusMsg = null
    String stAppInfo = null
    HashMap ctnHash = null

    def setup() {
        asyncCall = Mock(AsyncCall)
        externalDestinationHelperObj = new ExternalDestinationHelper()
        ReflectionTestUtils.setField(externalDestinationHelperObj, "asyncCall", asyncCall)
        ReflectionTestUtils.setField(externalDestinationHelperObj, "sPropCallCPNIStub", "Y")
        logger = LoggerFactory.getLogger('QueryCPNIAccountContactInfo')
        System.setProperty('CommonConfigurationFilePath', './opt/att/ajsc/config/CommonConfigurationTest.xml')
        stTransactionId = 'kan_123'

        hmInput = CommonUtil.hashMap
        ctnHash = CommonUtil.hashMap

        hmInput[CommonDefs.TRANSACTION_ID] = stTransactionId
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIAccountContact'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'ECOMM'
        hmInput[CommonDefs.ACCOUNT_INVARIANT_ID] = '56474849312'
        hmInput[CommonDefs.ACCOUNT_ID] = '45476839'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'MYWORLD'

        ctnHash['transactionName'] = 'QueryCPNIUserContactInfo'
        ctnHash['ctn'] = '0009057929'
        ctnHash['callingSystemId'] = 'IDP'
        ctnHash['transactionId'] = stTransactionId
        ctnHash['eventname'] = 'QueryCSIInquireSubscriberProfile'
        ctnHash['mask'] = 'SD:DI'

        hmInput['mosubCTN'] = ctnHash
        resultHashSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG)
        stAppInfo = 'Error returned from Helper'
        resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo)
    }

    def "external destination helper e c o m m n response"() {
        given:
        asyncCall.processRequest(_) >> resultHashSuccess

        when:
        hmResult = externalDestinationHelperObj.callMultipleDestinations(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "external destination helper e c o m m n with no invarient id response"() {
        given:
        hmInput[CommonDefs.ACCOUNT_INVARIANT_ID] = null
        asyncCall.processRequest(_) >> resultHashSuccess

        when:
        hmResult = externalDestinationHelperObj.callMultipleDestinations(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "external destination helper t i t a n response"() {
        given:
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'TITAN'
        asyncCall.processRequest(_) >> resultHashSuccess

        when:
        hmResult = externalDestinationHelperObj.callMultipleDestinations(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "external destination helper t i t a n with no invarient i d response"() {
        given:
        hmInput[CommonDefs.ACCOUNT_INVARIANT_ID] = null
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'TITAN'
        asyncCall.processRequest(_) >> resultHashSuccess

        when:
        hmResult = externalDestinationHelperObj.callCSI(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "external destination helper m o b i l i t y response"() {
        given:
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        asyncCall.processRequest(_) >> resultHashSuccess

        when:
        hmResult = externalDestinationHelperObj.callMultipleDestinations(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "external destination helper exception case"() {
        given:
        hmInput[CommonDefs.ACCOUNT_INVARIANT_ID] = 12345

        when:
        hmResult = externalDestinationHelperObj.callMultipleDestinations(hmInput)

        then:
        //hmResult[CommonDefs.COMMON_APP_INFO] == 'SYSTEM ERROR'
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "should return stubbed CSI response for #scenarioName"() {
        given: "Input map for CSI scenario"
        HashMap<String, Object> hmInput = CommonUtil.getHashMap()
        hmInput.put(CommonDefs.TRANSACTION_ID, "txn123")
        hmInput.put(CommonDefs.TRANSACTION_NAME, "QueryCPNIAccountContact")
        hmInput.put(CommonDefs.ACCOUNT_TYPE, accountType)
        hmInput.put(CommonDefs.ACCOUNT_ID, accountId)
        hmInput.put(CommonDefs.CALLING_SYSTEM_ID, "MYWORLD")

        when: "callCSI is invoked"
        HashMap<String, Object> result = externalDestinationHelperObj.callCSI(hmInput)

        then: "Result contains expected stubbed values"
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE).toString() == CErrorDefs.COMMON_SUCCESS_NUM.toString()
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG
        result.get(CommonDefs.KEY_CSI_ACCOUNT) != null
        0 * _

        where:
        scenarioName      | accountType | accountId
        "MOBILITY CSI"    | "MOBILITY"  | "1234567890"
        "MOBILITY stub"   | "MOBILITY"  | "0987654321"
    }

    def "should return stubbed BDS response for #scenarioName"() {
        given: "Input map for BDS scenario"
        HashMap<String, Object> hmInput = CommonUtil.getHashMap()
        hmInput.put(CommonDefs.TRANSACTION_ID, "txn456")
        hmInput.put(CommonDefs.TRANSACTION_NAME, "QueryCPNIAccountContact")
        hmInput.put(CommonDefs.ACCOUNT_TYPE, accountType)
        hmInput.put(CommonDefs.ACCOUNT_INVARIANT_ID, accountInvariantId)
        hmInput.put(CommonDefs.ACCOUNT_ID, accountId)
        hmInput.put(CommonDefs.CALLING_SYSTEM_ID, "MYWORLD")

        when: "callMultipleDestinations is invoked"
        HashMap<String, Object> result = externalDestinationHelperObj.callMultipleDestinations(hmInput)

        then: "Result contains expected stubbed BDS values"
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE).toString() == CErrorDefs.COMMON_SUCCESS_NUM.toString()
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG
        result.get(CommonDefs.BDS_SOR) != null
        0 * _

        where:
        scenarioName      | accountType | accountInvariantId | accountId
        "ECOMM BDS"       | "ECOMM"     | "56474849312"      | "45476839"
        "TITAN BDS"       | "TITAN"     | "56474849312"      | "45476839"
    }

    def "should call asyncCall when stub property is not Y for #scenarioName"() {
        given: "Input map and stub property set to N"
        ReflectionTestUtils.setField(externalDestinationHelperObj, "sPropCallCPNIStub", "N")
        HashMap<String, Object> hmInput = CommonUtil.getHashMap()
        hmInput.put(CommonDefs.TRANSACTION_ID, "txn789")
        hmInput.put(CommonDefs.TRANSACTION_NAME, "QueryCPNIAccountContact")
        hmInput.put(CommonDefs.ACCOUNT_TYPE, accountType)
        hmInput.put(CommonDefs.ACCOUNT_ID, accountId)
        hmInput.put(CommonDefs.CALLING_SYSTEM_ID, "MYWORLD")
        HashMap<String, Object> asyncResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)

        when: "callMultipleDestinations is invoked"
        HashMap<String, Object> result = externalDestinationHelperObj.callMultipleDestinations(hmInput)

        then: "asyncCall.processRequest is called and result returned"
        1 * asyncCall.processRequest({ HashMap<String, Object> m -> m != null }) >> asyncResult
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE).toString() == CErrorDefs.COMMON_SUCCESS_NUM.toString()
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG
        0 * _

        where:
        scenarioName      | accountType | accountId
        "MOBILITY async"  | "MOBILITY"  | "1234567890"
        "ECOMM async"     | "ECOMM"     | "45476839"
    }

    def "should handle exception and return error map"() {
        given: "Input map that causes exception"
        HashMap<String, Object> hmInput = null

        when: "callMultipleDestinations is invoked"
        HashMap<String, Object> result = externalDestinationHelperObj.callMultipleDestinations(hmInput)

        then: "Result contains system error"
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == "ERR_SYS_APPL"
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) == "2"
        0 * _
    }

    // ============================================================
    // Coverage: callCSI with null input triggers prepareCSIResponse(null) (line 62)
    // ============================================================

    def "callCSI with null input returns stubbed CSI response"() {
        when:
        HashMap<String, Object> result = externalDestinationHelperObj.callCSI(null)

        then:
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG
        0 * _
    }

    // ============================================================
    // Coverage: callCSI with BAN starting with '00' returns ERR_ACCOUNT_NOT_FOUND (lines 67-69)
    // ============================================================

    def "callCSI returns account not found when BAN starts with 00"() {
        given:
        HashMap<String, Object> input = CommonUtil.getHashMap()
        input.put(CommonDefs.BILLING_ACCOUNT_NUMBER, '001234567890')

        when:
        HashMap<String, Object> result = externalDestinationHelperObj.callCSI(input)

        then:
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CErrorDefs.ERR_ACCOUNT_NOT_FOUND_MSG
        0 * _
    }

    // ============================================================
    // Coverage: callCSI with SUBSCRIBER_NUMBER in input (line 147)
    // ============================================================

    def "callCSI populates subscriber number from input SUBSCRIBER_NUMBER"() {
        given:
        HashMap<String, Object> input = CommonUtil.getHashMap()
        input.put(CommonDefs.SUBSCRIBER_NUMBER, '5551234567')

        when:
        HashMap<String, Object> result = externalDestinationHelperObj.callCSI(input)

        then:
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG
        result.get(CommonDefs.KEY_CSI_ACCOUNT) != null
        0 * _
    }

    // ============================================================
    // Coverage: callCSI with BAN starting with '10' triggers second subscriber block (lines 169-183)
    // ============================================================

    def "callCSI adds second subscriber when BAN starts with 10"() {
        given:
        HashMap<String, Object> input = CommonUtil.getHashMap()
        input.put(CommonDefs.BILLING_ACCOUNT_NUMBER, '1098765432')

        when:
        HashMap<String, Object> result = externalDestinationHelperObj.callCSI(input)

        then:
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG
        0 * _
    }

    // ============================================================
    // Coverage: callCSI non-stub path (lines 408-409)
    // ============================================================

    def "callCSI with stub disabled logs and returns success"() {
        given:
        ReflectionTestUtils.setField(externalDestinationHelperObj, "sPropCallCPNIStub", "N")
        HashMap<String, Object> input = CommonUtil.getHashMap()
        input.put(CommonDefs.TRANSACTION_ID, 'txn_nonstub')
        input.put(CommonDefs.TRANSACTION_NAME, 'QueryCPNIAccountContact')
        input.put(CommonDefs.ACCOUNT_TYPE, 'MOBILITY')
        input.put(CommonDefs.ACCOUNT_ID, '5551234567')
        input.put(CommonDefs.CALLING_SYSTEM_ID, 'IDP')

        when:
        HashMap<String, Object> result = externalDestinationHelperObj.callCSI(input)

        then:
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == CommonDefs.COMMON_SUCCESS_MSG
        0 * _
    }

    // ============================================================
    // Coverage: callCSI exception path (lines 412-413)
    // ============================================================

    def "callCSI catches exception when stub enabled and input causes error"() {
        given:
        // Put a non-String value for BILLING_ACCOUNT_NUMBER to trigger ClassCastException in prepareCSIResponse
        HashMap<String, Object> input = CommonUtil.getHashMap()
        input.put(CommonDefs.BILLING_ACCOUNT_NUMBER, Integer.valueOf(12345))

        when:
        HashMap<String, Object> result = externalDestinationHelperObj.callCSI(input)

        then:
        result.get(CommonDefs.COMMON_APP_STATUS_MSG) == 'ERR_SYS_APPL'
        0 * _
    }
}