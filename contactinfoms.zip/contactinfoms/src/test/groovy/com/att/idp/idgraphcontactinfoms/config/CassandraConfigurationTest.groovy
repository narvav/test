package com.att.idp.idgraphcontactinfoms.config

import com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig
import com.att.mpsys.common.utils.CErrorDefs
import com.datastax.oss.driver.api.core.CqlSession
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class CassandraConfigurationTest extends Specification {

    def "should rebuild cqlSession and close previous session on refresh success"() {
        given:
        IDGraphAzureAppConfig appConfig = Mock(IDGraphAzureAppConfig)
        CqlSession oldSession = Mock(CqlSession)
        CqlSession newSession = Mock(CqlSession)
        RefreshScopeRefreshedEvent refreshEvent = Mock(RefreshScopeRefreshedEvent)

        CassandraConfiguration config = new CassandraConfiguration(appConfig) {
            @Override
            protected CqlSession buildCqlSession() {
                return newSession
            }
        }
        ReflectionTestUtils.setField(config, "cqlSession", oldSession)

        when:
        config.onConfigurationRefresh(refreshEvent)

        then:
        ReflectionTestUtils.getField(config, "cqlSession") == newSession
        1 * refreshEvent.getName() >> "refresh"
        1 * oldSession.close()
        1 * appConfig.getVersion() >> "v1"
        1 * appConfig.getCassandraConnectTimeoutMs() >> 1000
        1 * appConfig.getCassandraInitQueryTimeoutMs() >> 2000
        1 * appConfig.getCassandraRequestTimeoutMs() >> 3000
        1 * appConfig.getMaxConnectionPoolSize() >> 4
        0 * _
    }

    def "should log error and retain existing session when rebuild throws exception"() {
        given:
        IDGraphAzureAppConfig appConfig = Mock(IDGraphAzureAppConfig)
        CqlSession existingSession = Mock(CqlSession)
        RefreshScopeRefreshedEvent refreshEvent = Mock(RefreshScopeRefreshedEvent)

        CassandraConfiguration config = new CassandraConfiguration(appConfig) {
            @Override
            protected CqlSession buildCqlSession() {
                throw new RuntimeException("boom")
            }
        }
        ReflectionTestUtils.setField(config, "cqlSession", existingSession)

        when:
        config.onConfigurationRefresh(refreshEvent)

        then:
        ReflectionTestUtils.getField(config, "cqlSession") == existingSession
        1 * refreshEvent.getName() >> "refresh"
        0 * existingSession.close()
        0 * _
    }

    def "should handle null existing session gracefully on refresh success"() {
        given:
        IDGraphAzureAppConfig appConfig = Mock(IDGraphAzureAppConfig)
        CqlSession newSession = Mock(CqlSession)
        RefreshScopeRefreshedEvent refreshEvent = Mock(RefreshScopeRefreshedEvent)

        CassandraConfiguration config = new CassandraConfiguration(appConfig) {
            @Override
            protected CqlSession buildCqlSession() {
                return newSession
            }
        }
        ReflectionTestUtils.setField(config, "cqlSession", null)

        when:
        config.onConfigurationRefresh(refreshEvent)

        then:
        ReflectionTestUtils.getField(config, "cqlSession") == newSession
        1 * refreshEvent.getName() >> "refresh"
        1 * appConfig.getVersion() >> "v1"
        1 * appConfig.getCassandraConnectTimeoutMs() >> 1000
        1 * appConfig.getCassandraInitQueryTimeoutMs() >> 2000
        1 * appConfig.getCassandraRequestTimeoutMs() >> 3000
        1 * appConfig.getMaxConnectionPoolSize() >> 4
        0 * _
    }

    def "should swallow close exception and still keep new session"() {
        given:
        IDGraphAzureAppConfig appConfig = Mock(IDGraphAzureAppConfig)
        CqlSession oldSession = Mock(CqlSession)
        CqlSession newSession = Mock(CqlSession)
        RefreshScopeRefreshedEvent refreshEvent = Mock(RefreshScopeRefreshedEvent)

        CassandraConfiguration config = new CassandraConfiguration(appConfig) {
            @Override
            protected CqlSession buildCqlSession() {
                return newSession
            }
        }
        ReflectionTestUtils.setField(config, "cqlSession", oldSession)

        when:
        config.onConfigurationRefresh(refreshEvent)

        then:
        ReflectionTestUtils.getField(config, "cqlSession") == newSession
        1 * refreshEvent.getName() >> "refresh"
        1 * oldSession.close() >> { throw new RuntimeException("close failed") }
        1 * appConfig.getVersion() >> "v1"
        1 * appConfig.getCassandraConnectTimeoutMs() >> 1000
        1 * appConfig.getCassandraInitQueryTimeoutMs() >> 2000
        1 * appConfig.getCassandraRequestTimeoutMs() >> 3000
        1 * appConfig.getMaxConnectionPoolSize() >> 4
        0 * _
    }

    def "shutdown should close active session and clear cqlSession"() {
        given:
        IDGraphAzureAppConfig appConfig = Mock(IDGraphAzureAppConfig)
        CqlSession activeSession = Mock(CqlSession)
        CassandraConfiguration config = new CassandraConfiguration(appConfig)

        ReflectionTestUtils.setField(config, "cqlSession", activeSession)

        when:
        config.shutdown()

        then:
        ReflectionTestUtils.getField(config, "cqlSession") == null
        1 * activeSession.close()
        0 * _
    }

    def "shutdown should handle null session gracefully"() {
        given:
        IDGraphAzureAppConfig appConfig = Mock(IDGraphAzureAppConfig)
        CassandraConfiguration config = new CassandraConfiguration(appConfig)
        ReflectionTestUtils.setField(config, "cqlSession", null)

        when:
        config.shutdown()

        then:
        ReflectionTestUtils.getField(config, "cqlSession") == null
        0 * _
    }
}