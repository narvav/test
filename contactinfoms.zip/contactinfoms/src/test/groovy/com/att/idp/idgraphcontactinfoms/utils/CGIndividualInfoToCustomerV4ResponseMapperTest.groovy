package com.att.idp.idgraphcontactinfoms.utils

import com.att.idp.core.exception.ServiceException
import com.att.idp.dpl.profile.bsse.customerv4.CustomerV4Response
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import io.swagger.client.model.CGIndividualInfo
import io.swagger.client.model.Characteristic
import io.swagger.client.model.Contact
import io.swagger.client.model.ContactMedium
import io.swagger.client.model.IndividualAccountResponse
import io.swagger.client.model.Subscribers
import spock.lang.Specification

class CGIndividualInfoToCustomerV4ResponseMapperTest extends Specification {

    def mapper = new CGIndividualInfoToCustomerV4ResponseMapper()

    def "test mapToCustomerV4Response with valid CGIndividualInfo"() {
        given:
        CGIndividualInfo cgIndividualInfo = new CGIndividualInfo()
        cgIndividualInfo.setId("12345")
        cgIndividualInfo.setStatus("active")
        cgIndividualInfo.setCreatedOn("2023-01-01T00:00:00Z")
        cgIndividualInfo.setUpdatedOn("2023-01-02T00:00:00Z")

        // Add contact mediums
        List<ContactMedium> contactMediums = new ArrayList<>()
        ContactMedium contactMedium = new ContactMedium()
        contactMedium.setMediumType("email")
        contactMedium.setPreferred(true)
        Characteristic characteristic = new Characteristic()
        characteristic.setEmailAddress("test@example.com")
        characteristic.setVerified(true)
        contactMedium.setCharacteristic(characteristic)
        contactMediums.add(contactMedium)
        cgIndividualInfo.setContactMedium(contactMediums)

        // Add accounts
        List<IndividualAccountResponse> accounts = new ArrayList<>()
        IndividualAccountResponse account = new IndividualAccountResponse()
        List<Contact> contactList = new ArrayList<>()
        Contact contact = new Contact()
        List<ContactMedium> contactMediumList = new ArrayList<>()
        ContactMedium contactMedium1 = new ContactMedium()
        contactMedium1.setPreferred(true)
        contactMedium1.setMediumType("wireless")
        Characteristic characteristic1 = new Characteristic()
        characteristic1.setPhoneNumber("123456789")
        contactMedium1.setCharacteristic(characteristic1)
        contactMediumList.add(contactMedium1)

        contact.setContactMedium(contactMediumList)
        contactList.add(contact)

        List<Subscribers> subscribersList = new ArrayList<>()
        Subscribers subscribers = new Subscribers()
        subscribers.setCreatedOn("2023-01-01T00:00:00Z")
        subscribers.setStatus("active")
        subscribers.setCtn("6436375435")
        subscribers.setSmsCapable(true)

        subscribersList.add(subscribers)



        account.setId("67890")
        account.setAccountType("I")
        account.setContact(contactList)
        account.setCreatedOn("2023-01-01T00:00:00Z")
        account.setSubscribers(subscribersList)
        accounts.add(account)
        cgIndividualInfo.setAccounts(accounts)

        when:
        CustomerV4Response response = mapper.mapToCustomerV4Response(cgIndividualInfo)

        then:
        response != null
        response.individual.contactMedium.size() == 1
        response.individual.accounts.size() == 1
    }

    def "test mapToCustomerV4Response with null CGIndividualInfo"() {
        given:
        CGIndividualInfo cgIndividualInfo = null

        when:
        CustomerV4Response response = mapper.mapToCustomerV4Response(cgIndividualInfo)

        then:
        thrown(ServiceException.class)
    }

    def "test mapToCustomerV4Response with empty contact mediums and accounts"() {
        given:
        CGIndividualInfo cgIndividualInfo = new CGIndividualInfo()
        cgIndividualInfo.setId("12345")
        cgIndividualInfo.setStatus("active")
        cgIndividualInfo.setCreatedOn("2023-01-01T00:00:00Z")
        cgIndividualInfo.setUpdatedOn("2023-01-02T00:00:00Z")
        cgIndividualInfo.setContactMedium(new ArrayList<>())
        cgIndividualInfo.setAccounts(new ArrayList<>())

        when:
        CustomerV4Response response = mapper.mapToCustomerV4Response(cgIndividualInfo)

        then:
        response != null
        response.individual.contactMedium.isEmpty()
        response.individual.accounts.isEmpty()
    }

    def "test mapToCustomerV4Response with null fields in CGIndividualInfo"() {
        given:
        CGIndividualInfo cgIndividualInfo = new CGIndividualInfo()
        cgIndividualInfo.setId(null)
        cgIndividualInfo.setStatus(null)
        cgIndividualInfo.setCreatedOn(null)
        cgIndividualInfo.setUpdatedOn(null)
        cgIndividualInfo.setContactMedium(null)
        cgIndividualInfo.setAccounts(null)

        when:
        CustomerV4Response response = mapper.mapToCustomerV4Response(cgIndividualInfo)

        then:
        response != null
        response.individual.id == null
        response.individual.status == null
        response.individual.contactMedium == null
        response.individual.accounts == null
    }

    def "test mapToCustomerV4Response when convertAccount throws exception"() {
        given:
        CGIndividualInfo cgIndividualInfo = new CGIndividualInfo()
        cgIndividualInfo.setId("12345")
        cgIndividualInfo.setStatus("active")
        cgIndividualInfo.setCreatedOn("2023-01-01T00:00:00Z")
        cgIndividualInfo.setUpdatedOn("2023-01-02T00:00:00Z")
        cgIndividualInfo.setContactMedium(new ArrayList<>())

        // Add a mock account to ensure convertAccount() is called
        List<IndividualAccountResponse> accounts = new ArrayList<>()
        IndividualAccountResponse account = new IndividualAccountResponse()
        account.setId("67890")
        accounts.add(account)
        cgIndividualInfo.setAccounts(accounts)

        mapper = Spy(CGIndividualInfoToCustomerV4ResponseMapper) {
            convertProfileToCGAccount(accounts) >> { throw new RuntimeException("Test Exception") }
        }
        when:
        CustomerV4Response response = mapper.mapToCustomerV4Response(cgIndividualInfo)

        then:
        thrown(RuntimeException)
    }
}