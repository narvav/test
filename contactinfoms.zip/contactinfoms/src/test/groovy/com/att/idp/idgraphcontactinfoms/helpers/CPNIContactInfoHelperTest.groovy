package com.att.idp.idgraphcontactinfoms.helpers

import com.att.idp.cgclienthelpers.integration.CGApiRestClient
import com.att.idp.core.exception.ServiceException
import com.att.idp.dpl.profile.bsse.customerv4.Account
import com.att.idp.dpl.profile.bsse.customerv4.CustomerV4Response
import com.att.idp.idgraphcontactinfoms.model.Individual
import com.att.idp.idgraphcontactinfoms.utils.CGIndividualInfoToCustomerV4ResponseMapper
import com.att.idp.cgclienthelpers.utils.CGUtilHelper
import com.fasterxml.jackson.databind.ObjectMapper
import io.swagger.client.model.CGIndividualInfo
import io.swagger.client.model.Characteristic
import io.swagger.client.model.Contact
import io.swagger.client.model.IndividualAccountResponse
import io.swagger.client.model.Subscribers
import jakarta.ws.rs.core.MultivaluedHashMap
import jakarta.ws.rs.core.MultivaluedMap
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import spock.lang.Unroll

import java.time.ZonedDateTime

class CPNIContactInfoHelperTest extends Specification {

    def cpniContactInfoHelper
    def profileHelper
    def cgApiRestClient
    def responseMapper
    def cpniEligibilityHelperMock
    def cgUtilHelperMock
    MultivaluedMap<String, String> headers
    Logger logger = null

    def setup() {
        cpniContactInfoHelper = new CPNIContactInfoHelper()
        profileHelper = Mock(ProfileHelper)
        cgApiRestClient = Mock(CGApiRestClient)
        responseMapper = Mock(CGIndividualInfoToCustomerV4ResponseMapper)
        cpniEligibilityHelperMock = Mock(CPNIEligibilityHelper)
        cgUtilHelperMock = Mock(CGUtilHelper)
        logger = LoggerFactory.getLogger('CPNIContactInfoHelper')
        headers = createBaseHeaders()

        ReflectionTestUtils.setField(cpniContactInfoHelper, "profileHelper", profileHelper)
        ReflectionTestUtils.setField(cpniContactInfoHelper, "cpniEligibilityHelper", cpniEligibilityHelperMock)
        ReflectionTestUtils.setField(cpniContactInfoHelper, "cgApiRestClient", cgApiRestClient)
        ReflectionTestUtils.setField(cpniContactInfoHelper, "responseMapper", responseMapper)
        ReflectionTestUtils.setField(cpniContactInfoHelper, "cgUtilHelper", cgUtilHelperMock)
    }

    def "test cpniContactInfoByIndividualId with valid response for account type I"() {
        given:
        String individualId = "3c0b9dc3-e62a-4a18-aa19-4b9dd4edc1a6"

        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByIndividualId(individualId, headers, false)

        then:
        1 * profileHelper.profileMsSearchByIndividualId(individualId, headers) >> buildMockCGIndividualInfo_AccountType("I")
        1 * responseMapper.mapToCustomerV4Response(_) >> getMockCGCustomerV4Data("mock-customer-v4-data.json")
        _ * cpniEligibilityHelperMock.isActiveStatus(_) >> true
        _ * cpniEligibilityHelperMock.updateCPNIEligibility(_, _, _, _)
        _ * cpniEligibilityHelperMock.updateSubscriberCPNIEligibility(_, _, _, _, _) >> { characteristic, status, smsCapable, simSwapDate, accountCreatedOn ->
            characteristic.setCpniEligible(true)
        }
        2 * cgUtilHelperMock.resolveSubscriberDeviceDetailsByTargetSOR(_, _) >> ["smsCapabilityInd": true, "simSwapDateValue": null]
        0 * _
        result != null
        result.contactMediums.size() == 2
        result.accounts.size() == 1
        result.accounts.get(0).getSubscribers().size() == 2
    }

    def "test cpniContactInfoByIndividualId with valid response for exploitable Y"() {
        given:
        String individualId = "3c0b9dc3-e62a-4a18-aa19-4b9dd4edc1a6"
        def headers = createBaseHeaders()
        headers.putSingle("exploitable", "Y")  // Overrides the base value

        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByIndividualId(individualId, headers, false)

        then:
        1 * profileHelper.profileMsSearchByIndividualId(individualId, headers) >> buildMockCGIndividualInfo_AccountType("I")
        1 * responseMapper.mapToCustomerV4Response(_) >> getMockCGCustomerV4Data("mock-customer-v4-data.json")
        _ * cpniEligibilityHelperMock.isActiveStatus(_) >> true
        _ * cpniEligibilityHelperMock.updateCPNIEligibility(_, _, _, _) >> { individualCharacteristic, establishmentDate, createdOn, targetSOR ->
            individualCharacteristic.setCpniEligible(true)
        }
        _ * cpniEligibilityHelperMock.updateSubscriberCPNIEligibility(_, _, _, _, _) >> { characteristic, status, smsCapable, simSwapDate, accountCreatedOn ->
            characteristic.setCpniEligible(true)
        }
        2 * cgUtilHelperMock.resolveSubscriberDeviceDetailsByTargetSOR(_, _) >> ["smsCapabilityInd": true, "simSwapDateValue": null]
        0 * _
        result != null
        result.contactMediums.size() == 0
        result.accounts.size() == 1
        result.accounts.get(0).getContacts().size() == 1
        result.accounts.get(0).getSubscribers().size() == 2
    }

    def "test cpniContactInfoByIndividualId with valid response for exploitable Y and CpniEligible false"() {
        given:
        String individualId = "3c0b9dc3-e62a-4a18-aa19-4b9dd4edc1a6"
        def headers = createBaseHeaders()
        headers.putSingle("exploitable", "Y")  // Overrides the base value

        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByIndividualId(individualId, headers, false)

        then:
        1 * profileHelper.profileMsSearchByIndividualId(individualId, headers) >> buildMockCGIndividualInfo_AccountType("I")
        1 * responseMapper.mapToCustomerV4Response(_) >> getMockCGCustomerV4Data("mock-customer-v4-data.json")
        _ * cpniEligibilityHelperMock.isActiveStatus(_) >> true
        _ * cpniEligibilityHelperMock.updateCPNIEligibility(_, _, _, _) >> { individualCharacteristic, establishmentDate, createdOn, targetSOR ->
            individualCharacteristic.setCpniEligible(false)
        }
        _ * cpniEligibilityHelperMock.updateSubscriberCPNIEligibility(_, _, _, _, _) >> { characteristic, status, smsCapable, simSwapDate, accountCreatedOn ->
            characteristic.setCpniEligible(false)
        }
        2 * cgUtilHelperMock.resolveSubscriberDeviceDetailsByTargetSOR(_, _) >> ["smsCapabilityInd": true, "simSwapDateValue": null]
        0 * _
        result != null
        result.contactMediums.size() == 0
        result.accounts.size() == 1
        result.accounts.get(0).getContacts().size() == 1
        result.accounts.get(0).getContacts().get(0).getContactMediums().size()== 0
        result.accounts.get(0).getSubscribers().size() == 0
    }

    def "test cpniContactInfoByIndividualId with valid response for exploitable Y and CpniEligible false for fiber account"() {
        given:
        String individualId = "3c0b9dc3-e62a-4a18-aa19-4b9dd4edc1a6"
        def headers = createBaseHeaders()
        headers.putSingle("exploitable", "Y")  // Overrides the base value

        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByIndividualId(individualId, headers, false)

        then:
        1 * profileHelper.profileMsSearchByIndividualId(individualId, headers) >> buildMockCGIndividualInfo_AccountType("I")
        1 * responseMapper.mapToCustomerV4Response(_) >> getMockCGCustomerV4Data("mock-customer-v4-data_fiber_account.json")
        _ * cpniEligibilityHelperMock.isActiveStatus(_) >> true
        _ * cpniEligibilityHelperMock.updateCPNIEligibility(_, _, _, _) >> { individualCharacteristic, establishmentDate, createdOn, targetSOR ->
            individualCharacteristic.setCpniEligible(false)
        }
        _ * cpniEligibilityHelperMock.updateSubscriberCPNIEligibility(_, _, _, _, _) >> { characteristic, status, smsCapable, simSwapDate, accountCreatedOn ->
            characteristic.setCpniEligible(false)
        }
        _ * cgUtilHelperMock.resolveSubscriberDeviceDetailsByTargetSOR(_, _) >> ["smsCapabilityInd": true, "simSwapDateValue": null]
        0 * _
        result != null
        result.contactMediums.size() == 0
        result.accounts.size() == 1
        result.accounts.get(0).getContacts().size() == 1
        result.accounts.get(0).getContacts().get(0).getContactMediums().size()== 1
        result.accounts.get(0).getSubscribers().size() == 0
    }

    def "test cpniContactInfoByIndividualId with null response from profile api"() {
        given:
        String individualId = "3c0b9dc3-e62a-4a18-aa19-4b9dd4edc1a6"

        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByIndividualId(individualId, headers, false)

        then:
        1 * profileHelper.profileMsSearchByIndividualId(individualId, headers) >> null
        0 * _
        thrown(ServiceException.class)
    }

    def "test cpniContactInfoByIndividualId when profile api throws service exception"() {
        given:
        String individualId = "3c0b9dc3-e62a-4a18-aa19-4b9dd4edc1a6"

        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByIndividualId(individualId, headers, false)

        then:
        1 * profileHelper.profileMsSearchByIndividualId(individualId, headers) >> { throw new ServiceException("Profile API returned ServiceException for individualId: " + individualId) }
        0 * _
        thrown(ServiceException.class)
    }

    def "test cpniContactInfoByIndividualId when profile api throws system error"() {
        given:
        String individualId = "3c0b9dc3-e62a-4a18-aa19-4b9dd4edc1a6"

        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByIndividualId(individualId, headers, false)

        then:
        1 * profileHelper.profileMsSearchByIndividualId(individualId, headers) >> { throw new Exception("Profile API returned system error for individualId: " + individualId) }
        0 * _
        thrown(Exception.class)
    }

    def "test cpniContactInfoByAccountId with valid response for account type I"() {
        given:
        String accountId = "557786423846"
        String accountType = "wireless"

        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByAccountId(accountId, accountType, headers, true)

        then:
        1 * cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> getMockCGCustomerV4Data("mock-customer-v4-data.json")
        _ * cpniEligibilityHelperMock.isActiveStatus(_) >> true
        _ * cpniEligibilityHelperMock.updateCPNIEligibility(_, _, _, _)
        _ * cpniEligibilityHelperMock.updateSubscriberCPNIEligibility(_, _, _, _, _) >> { characteristic, status, smsCapable, simSwapDate, accountCreatedOn -> characteristic.setCpniEligible(true) }
        2 * cgUtilHelperMock.resolveSubscriberDeviceDetailsByTargetSOR(_, _) >> ["smsCapabilityInd": true, "simSwapDateValue": null]
        0 * _
        result != null
        result.id == null
        result.contactMediums.size() == 2
        result.accounts.size() == 1
        result.accounts.get(0).getSubscribers().size() == 2
    }

    def "test cpniContactInfoByAccountId with valid response along with individualId in response"() {
        given:
        String accountId = "557786423846"
        String accountType = "wireless"

        def headers = createBaseHeaders()
        headers.add("isIndividualIdInResEnabled", "Y")

        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByAccountId(accountId, accountType, headers, true)

        then:
        1 * cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> getMockCGCustomerV4Data("mock-customer-v4-data.json")
        _ * cpniEligibilityHelperMock.isActiveStatus(_) >> true
        _ * cpniEligibilityHelperMock.updateCPNIEligibility(_, _, _, _)
        _ * cpniEligibilityHelperMock.updateSubscriberCPNIEligibility(_, _, _, _, _) >> { characteristic, status, smsCapable, simSwapDate, accountCreatedOn -> characteristic.setCpniEligible(true) }
        2 * cgUtilHelperMock.resolveSubscriberDeviceDetailsByTargetSOR(_, _) >> ["smsCapabilityInd": true, "simSwapDateValue": null]
        0 * _
        result != null
        result.id == "6a9f7b99-214e-44af-8f7c-2336b834fc70"
        result.contactMediums.size() == 2
        result.accounts.size() == 1
        result.accounts.get(0).getSubscribers().size() == 2
    }

    def "test cpniContactInfoByAccountId with valid response for legacy wireless account type I"() {
        given:
        String accountId = "177333434256"
        String accountType = "wireless"

        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByAccountId(accountId, accountType, headers, true)

        then:
        1 * cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> getMockCGCustomerV4Data("mock-customer-v4-legacy-wireless-data.json")
        _ * cpniEligibilityHelperMock.isActiveStatus(_) >> true
        _ * cpniEligibilityHelperMock.updateCPNIEligibility(_, _, _, _) >> { individualCharacteristic, establishmentDate, createdOn, targetSOR ->
            individualCharacteristic.setCpniEligible(false)
        }
        _ * cpniEligibilityHelperMock.updateSubscriberCPNIEligibilityForLegacy(_, _, _, _, _) >> { characteristic, status, smsCapable, simSwapDate, accountCreatedOn -> characteristic.setCpniEligible(true) }
        1 * cgUtilHelperMock.resolveSubscriberDeviceDetailsByTargetSOR(_, _) >> ["smsCapabilityInd": "Y", "simSwapDateValue": null]
        0 * _
        result != null
        result.contactMediums.size() == 3
        result.accounts.size() == 1
        result.accounts.get(0).getSubscribers().size() == 1
    }

    def "test cpniContactInfoByAccountId with valid response for legacy uverse account type I"() {
        given:
        String accountId = "177333434256"
        String accountType = "uverse"

        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByAccountId(accountId, accountType, headers, true)

        then:
        1 * cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> getMockCGCustomerV4Data("mock-customer-v4-legacy-uverse-data.json")
        _ * cpniEligibilityHelperMock.isActiveStatus(_) >> true
        _ * cpniEligibilityHelperMock.updateCPNIEligibility(_, _, _, _)
        _ * cpniEligibilityHelperMock.updateCPNIEligibilityForUverseCBR(_, _, _, _) >> { individualCharacteristic, establishmentDate, createdOn, targetSOR ->
            individualCharacteristic.setCpniEligible(false)
        }
        0 * _
        result != null
        result.contactMediums.size() == 3
        result.accounts.size() == 1
        result.accounts.get(0).getSubscribers().size() == 0
    }

    def "test cpniContactInfoByAccountId without subscribers for account type I"() {
        given:
        String accountId = "557786423846"
        String accountType = "wireless"

        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByAccountId(accountId, accountType, headers, true)

        then:
        1 * cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> getMockCGCustomerV4Data("mock-customer-v4-data-without-subscribers.json")
        _ * cpniEligibilityHelperMock.updateCPNIEligibility(_, _, _, _)
        0 * _
        result != null
        result.contactMediums.size() == 2
        result.accounts.size() == 1
        result.accounts.get(0).getSubscribers().size() == 0
    }

    def "test cpniContactInfoByAccountId with createdOn as null"() {
        given:
        String accountId = "557786423846"
        String accountType = "wireless"
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        CustomerV4Response customerV4Response = new CustomerV4Response()
        com.att.idp.dpl.profile.bsse.customerv4.Individual individual = new com.att.idp.dpl.profile.bsse.customerv4.Individual()
        List<com.att.idp.dpl.profile.bsse.model.common.ContactMedium> contactMediumList = new ArrayList<>()
        com.att.idp.dpl.profile.bsse.model.common.ContactMedium contactMedium = new com.att.idp.dpl.profile.bsse.model.common.ContactMedium()
        contactMedium.setPreferred(true)
        contactMediumList.add(contactMedium)
        individual.setContactMedium(contactMediumList)
        customerV4Response.setIndividual(individual)
        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByAccountId(accountId, accountType, headers, true)

        then:
        1 * cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> customerV4Response
        0 * _
        result != null
        result.contactMediums.size() == 0
        result.accounts.size() == 0
    }


    def "test cpniContactInfoByAccountId with mediumType as null"() {
        given:
        String accountId = "557786423846"
        String accountType = "wireless"
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        CustomerV4Response customerV4Response = new CustomerV4Response()
        com.att.idp.dpl.profile.bsse.customerv4.Individual individual = new com.att.idp.dpl.profile.bsse.customerv4.Individual()
        List<com.att.idp.dpl.profile.bsse.model.common.ContactMedium> contactMediumList = new ArrayList<>()
        com.att.idp.dpl.profile.bsse.model.common.ContactMedium contactMedium = new com.att.idp.dpl.profile.bsse.model.common.ContactMedium()
        contactMedium.setPreferred(true)
        contactMediumList.add(contactMedium)
        individual.setContactMedium(contactMediumList)
        individual.setCreatedOn("2025-01-27T13:53:32.582Z")
        customerV4Response.setIndividual(individual)
        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByAccountId(accountId, accountType, headers, true)

        then:
        1 * cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> customerV4Response
        0 * _
        result != null
        result.contactMediums.size() == 0
        result.accounts.size() == 0
    }

    def "test cpniContactInfoByAccountId with null response from cg api "() {
        given:
        String accountId = "557786423846"
        String accountType = "wireless"
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByAccountId(accountId, accountType, headers, true)

        then:
        1 * cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> null
        0 * _
        thrown(ServiceException.class)
    }

    def "test cpniContactInfoByAccountId when cg api throws service exception"() {
        given:
        String accountId = "557786423846"
        String accountType = "wireless"
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByAccountId(accountId, accountType, headers, true)

        then:
        1 * cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> { throw new ServiceException("CG API returned ServiceException for accountId: " + accountId) }
        0 * _
        thrown(ServiceException.class)
    }

    def "test cpniContactInfoByAccountId when cg api throws system error"() {
        given:
        String accountId = "557786423846"
        String accountType = "wireless"
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByAccountId(accountId, accountType, headers,true)

        then:
        1 * cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> { throw new Exception("CG API returned system error for accountId: " + accountId) }
        0 * _
        thrown(Exception.class)
    }


    def "test cpniContactInfoByAccountId with empty contact medium and empty accounts"() {
        given:
        String accountId = "557786423846"
        String accountType = "wireless"
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);
        CustomerV4Response customerV4Response = new CustomerV4Response()
        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByAccountId(accountId, accountType, headers, true)

        then:
        1 * cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> customerV4Response
        0 * _
        result != null
        result.contactMediums.size() == 0
        result.accounts.size() == 0
    }

    def "test cpniContactInfo with valid response for account type B"() {
        given:
        String individualId = "3c0b9dc3-e62a-4a18-aa19-4b9dd4edc1a6"

        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByIndividualId(individualId, headers, false)

        then:
        1 * profileHelper.profileMsSearchByIndividualId(individualId, headers) >> buildMockCGIndividualInfo_AccountType("B")
        1 * responseMapper.mapToCustomerV4Response(_) >> getMockCGCustomerV4Data("mock-customer-v4-data-accountType_B.json")
        _ * cpniEligibilityHelperMock.isActiveStatus(_) >> true
        _ * cpniEligibilityHelperMock.updateCPNIEligibility(_, _, _, _)
        _ * cpniEligibilityHelperMock.updateSubscriberCPNIEligibility(_, _, _, _, _) >> { characteristic, status, smsCapable, simSwapDate, accountCreatedOn -> characteristic.setCpniEligible(true) }
        _ * cgUtilHelperMock.resolveSubscriberDeviceDetailsByTargetSOR(_, _) >> ["smsCapabilityInd": true, "simSwapDateValue": null]
        0 * _
        result != null
        result.contactMediums.size() == 2
        result.accounts.size() == 1
        result.accounts.get(0).getSubscribers().size() == 0
    }



    @Unroll
    def "test sortSubscribers with accountType=#accountType and returnBizCTNs=#returnBizCTNs for BSSE wireless account"() {
        given:
        List<com.att.idp.idgraphcontactinfoms.model.Subscribers> subscribers = createMockSubscribers()
        int originalSize = subscribers.size()

        when:
        List<com.att.idp.idgraphcontactinfoms.model.Subscribers> result = cpniContactInfoHelper.sortSubscribers(accountType, subscribers, returnBizCTNs)

        then:
        result != null
        if (accountType == "B" && returnBizCTNs == "Y") {
            result.size() <= 25 // Should be limited to 25 max for CRU
        } else {
            result.size() == originalSize // Should not be filtered or limited
        }
        result.every { it != null }

        where:
        accountType | returnBizCTNs
        "B"          | "Y"
        "B"          | "N"
        "I"          | "Y"
        "I"          | "N"
    }

    @Unroll
    def "test sortSubscribers with accountType=#accountType and returnBizCTNs=#returnBizCTNs for Legacy wireless account"() {
        given:
        List<com.att.idp.idgraphcontactinfoms.model.Subscribers> subscribers = createMockSubscribersForLegacy()
        int originalSize = subscribers.size()

        when:
        List<com.att.idp.idgraphcontactinfoms.model.Subscribers> result = cpniContactInfoHelper.sortSubscribers(accountType, subscribers, returnBizCTNs)

        then:
        result != null
        if (accountType == "B" && returnBizCTNs == "Y") {
            result.size() <= 25 // Should be limited to 25 max for CRU
        } else {
            result.size() == originalSize // Should not be filtered or limited
        }
        result.every { it != null }

        where:
        accountType | returnBizCTNs
        "B"          | "Y"
        "B"          | "N"
        "I"          | "Y"
        "I"          | "N"
    }

    @Unroll
    def "test sortSubscribersByEffectiveDate with #scenario"() {
        given:
        List<com.att.idp.idgraphcontactinfoms.model.Subscribers> subscribers = getSubscribersForScenario(scenario)

        when:
        cpniContactInfoHelper.sortSubscribersByEffectiveDate(subscribers)

        then:
        if (scenario == "valid dates") {
            subscribers.size() == 3
            subscribers[0].getEffectiveDate() == "2025-01-15T10:00:00.000Z"
            subscribers[1].getEffectiveDate() == "2025-02-20T15:30:00.000Z"
            subscribers[2].getEffectiveDate() == "2025-03-10T08:45:00.000Z"
        } else if (scenario == "null dates") {
            subscribers.size() == 3
            subscribers[0].getEffectiveDate() != null
            subscribers[1].getEffectiveDate() != null
            subscribers[2].getEffectiveDate() == null
        } else if (scenario == "empty") {
            subscribers.isEmpty()
        }
        noExceptionThrown()

        where:
        scenario << ["valid dates", "null dates", "invalid dates", "null list", "empty"]
    }

    @Unroll
    def "test getSortedSubscribersForCRU with #scenario"() {
        given:
        List<com.att.idp.idgraphcontactinfoms.model.Subscribers> subscribers = getSubscribersForCRUScenario(scenario)

        when:
        List<com.att.idp.idgraphcontactinfoms.model.Subscribers> result = cpniContactInfoHelper.getSortedSubscribersForCRU(subscribers)

        then:
        result != null
        if (scenario == "mixed CPNI") {
            result.size() == 2 // Only CPNI eligible subscribers
            result[0].getEffectiveDate() == "2025-01-15T10:00:00.000Z"
            result[1].getEffectiveDate() == "2025-03-10T08:45:00.000Z"
        } else if (scenario == "30 subscribers") {
            result.size() <= 25
        } else if (scenario == "null" || scenario == "empty") {
            result.isEmpty()
        }
        noExceptionThrown()

        where:
        scenario << ["mixed CPNI", "30 subscribers", "null", "empty", "invalid data"]
    }

    @Unroll
    def "test isCpniEligible with #scenario"() {
        given:
        com.att.idp.idgraphcontactinfoms.model.Subscribers subscriber = getSubscriberForEligibilityScenario(scenario)

        when:
        boolean result = cpniContactInfoHelper.isCpniEligible(subscriber)

        then:
        result == expectedResult

        where:
        scenario                    | expectedResult
        "eligible subscriber"       | true
        "ineligible subscriber"     | false
        "null subscriber"           | false
        "null contact"              | false
        "null contact mediums"      | false
        "null characteristic"        | false
    }

    private MultivaluedMap<String, String> createBaseHeaders() {
        def baseHeaders = new MultivaluedHashMap<>()
        baseHeaders.add("idp-trace-id", "trace123")
        baseHeaders.add("idpctx-session-id", "workinghsession123")
        baseHeaders.add("exploitable", "N")
        baseHeaders.add("returnBizCTNs", "N")
        return baseHeaders
    }

    def "test cpniContactInfoByAccountId with createdOn null in mapIndividualContactMedium"() {
        given:
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", "557354426");
        cgInput.put("accountType", "WIRELESS");
        CustomerV4Response customerV4Response = new CustomerV4Response()
        com.att.idp.dpl.profile.bsse.customerv4.Individual individual = new com.att.idp.dpl.profile.bsse.customerv4.Individual()
        List<com.att.idp.dpl.profile.bsse.model.common.ContactMedium> contactMediumList = new ArrayList<>()
        com.att.idp.dpl.profile.bsse.model.common.ContactMedium contactMedium = new com.att.idp.dpl.profile.bsse.model.common.ContactMedium()
        contactMedium.setPreferred(true)
        contactMedium.setMediumType("email")
        contactMediumList.add(contactMedium)

        Account account = new Account()
        account.setTargetSOR("CG")
        individual.setAccounts([account])
        individual.setContactMedium(contactMediumList)
        individual.setCreatedOn(null) // Set createdOn to null to trigger the early return
        customerV4Response.setIndividual(individual)
        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByAccountId("557354426","WIRELESS", headers, true)

        then:
        1 * cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> customerV4Response
        0 * _
        result != null
        result.contactMediums.size() == 0
        result.accounts.size() == 0
    }

    def "test cpniContactInfoByAccountId with null contactMedium and null mediumType"() {
        given:
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", "557354426");
        cgInput.put("accountType", "WIRELESS");
        CustomerV4Response customerV4Response = new CustomerV4Response()
        com.att.idp.dpl.profile.bsse.customerv4.Individual individual = new com.att.idp.dpl.profile.bsse.customerv4.Individual()
        List<com.att.idp.dpl.profile.bsse.model.common.ContactMedium> contactMediumList = new ArrayList<>()


        // Add a contact medium with null mediumType to test mediumType null check
        com.att.idp.dpl.profile.bsse.model.common.ContactMedium contactMediumWithNullType = new com.att.idp.dpl.profile.bsse.model.common.ContactMedium()
        contactMediumWithNullType.setPreferred(true)
        contactMediumList.add(contactMediumWithNullType)

        Account account = new Account()
        account.setTargetSOR("CG")
        account.setCreatedOn("2025-01-27T13:53:32.582Z")
        individual.setAccounts([account])
        individual.setContactMedium(contactMediumList)
        customerV4Response.setIndividual(individual)
        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoByAccountId("557354426","WIRELESS", headers, true)

        then:
        1 * cgApiRestClient.getCustomerDetailsByAccountId(cgInput) >> customerV4Response
        0 * _
        result != null
        result.contactMediums.size() == 0
        result.accounts.size() == 0
    }


    private List<com.att.idp.idgraphcontactinfoms.model.Subscribers> getSubscribersForScenario(String scenario) {
        switch (scenario) {
            case "valid dates":
                return createMockSubscribersWithDifferentDates()
            case "null dates":
                return createMockSubscribersWithNullDates()
            case "invalid dates":
                return createMockSubscribersWithInvalidDates()
            case "null list":
                return null
            case "empty":
                return new ArrayList<>()
            default:
                return new ArrayList<>()
        }
    }

    private List<com.att.idp.idgraphcontactinfoms.model.Subscribers> getSubscribersForCRUScenario(String scenario) {
        switch (scenario) {
            case "mixed CPNI":
                return createMockSubscribersMixedCPNI()
            case "30 subscribers":
                return createMockSubscribers(30)
            case "null":
                return null
            case "empty":
                return new ArrayList<>()
            case "invalid data":
                return createMockSubscribersWithInvalidData()
            default:
                return new ArrayList<>()
        }
    }

    private com.att.idp.idgraphcontactinfoms.model.Subscribers getSubscriberForEligibilityScenario(String scenario) {
        switch (scenario) {
            case "eligible subscriber":
                return createMockCPNIEligibleSubscriber(true)
            case "ineligible subscriber":
                return createMockCPNIEligibleSubscriber(false)
            case "null subscriber":
                return null
            case "null contact":
                def subscriber = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
                subscriber.setContact(null)
                return subscriber
            case "null contact mediums":
                def subscriber = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
                def contact = new com.att.idp.idgraphcontactinfoms.model.Contact()
                contact.setContactMediums(null)
                subscriber.setContact(Arrays.asList(contact))
                return subscriber
            case "null characteristic":
                def subscriber = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
                def contact = new com.att.idp.idgraphcontactinfoms.model.Contact()
                def contactMedium = new com.att.idp.idgraphcontactinfoms.model.ContactMedium()
                contactMedium.setCharacteristic(null)
                contact.setContactMediums(Arrays.asList(contactMedium))
                subscriber.setContact(Arrays.asList(contact))
                return subscriber
            default:
                return null
        }
    }

    private List<com.att.idp.idgraphcontactinfoms.model.Subscribers> createMockSubscribers() {
        return createMockSubscribers(3)
    }

    private List<com.att.idp.idgraphcontactinfoms.model.Subscribers> createMockSubscribersForLegacy() {
        return createMockSubscribersForLegacy(3)
    }

    private List<com.att.idp.idgraphcontactinfoms.model.Subscribers> createMockSubscribers(int count) {
        List<com.att.idp.idgraphcontactinfoms.model.Subscribers> subscribers = new ArrayList<>()
        for (int i = 0; i < count; i++) {
            com.att.idp.idgraphcontactinfoms.model.Subscribers subscriber = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
            //subscriber.set("123456789" + i)
            subscriber.setEffectiveDate("2025-0${i + 1}-15T10:00:00.000Z")
            subscriber.setContact(Arrays.asList(createMockContact(true)))
            subscribers.add(subscriber)
        }
        return subscribers
    }

    private List<com.att.idp.idgraphcontactinfoms.model.Subscribers> createMockSubscribersForLegacy(int count) {
        List<com.att.idp.idgraphcontactinfoms.model.Subscribers> subscribers = new ArrayList<>()
        for (int i = 0; i < count; i++) {
            com.att.idp.idgraphcontactinfoms.model.Subscribers subscriber = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
            //subscriber.set("123456789" + i)
            subscriber.setEffectiveDate("2025-0${i + 1}-15 10:00:00")
            subscriber.setContact(Arrays.asList(createMockContact(true)))
            subscribers.add(subscriber)
        }
        return subscribers
    }

    private List<com.att.idp.idgraphcontactinfoms.model.Subscribers> createMockSubscribersWithDifferentDates() {
        List<com.att.idp.idgraphcontactinfoms.model.Subscribers> subscribers = new ArrayList<>()

        def subscriber1 = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
        //subscriber1.setCtn("1234567890")
        subscriber1.setEffectiveDate("2025-02-20T15:30:00.000Z")
        subscriber1.setContact(Arrays.asList(createMockContact(true)))

        def subscriber2 = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
        //subscriber2.setCtn("1234567891")
        subscriber2.setEffectiveDate("2025-01-15T10:00:00.000Z")
        subscriber2.setContact(Arrays.asList(createMockContact(true)))

        def subscriber3 = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
       // subscriber3.setCtn("1234567892")
        subscriber3.setEffectiveDate("2025-03-10T08:45:00.000Z")
        subscriber3.setContact(Arrays.asList(createMockContact(true)))

        subscribers.add(subscriber1)
        subscribers.add(subscriber2)
        subscribers.add(subscriber3)
        return subscribers
    }

    private List<com.att.idp.idgraphcontactinfoms.model.Subscribers> createMockSubscribersWithNullDates() {
        List<com.att.idp.idgraphcontactinfoms.model.Subscribers> subscribers = new ArrayList<>()

        def subscriber1 = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
        //subscriber1.setCtn("1234567890")
        subscriber1.setEffectiveDate("2025-02-20T15:30:00.000Z")
        subscriber1.setContact(Arrays.asList(createMockContact(true)))

        def subscriber2 = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
       // subscriber2.setCtn("1234567891")
        subscriber2.setEffectiveDate(null)
        subscriber2.setContact(Arrays.asList(createMockContact(true)))

        def subscriber3 = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
        //subscriber3.setCtn("1234567892")
        subscriber3.setEffectiveDate("2025-01-15T10:00:00.000Z")
        subscriber3.setContact(Arrays.asList(createMockContact(true)))

        subscribers.add(subscriber1)
        subscribers.add(subscriber2)
        subscribers.add(subscriber3)
        return subscribers
    }

    private List<com.att.idp.idgraphcontactinfoms.model.Subscribers> createMockSubscribersWithInvalidDates() {
        List<com.att.idp.idgraphcontactinfoms.model.Subscribers> subscribers = new ArrayList<>()

        def subscriber1 = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
        //subscriber1.setCtn("1234567890")
        subscriber1.setEffectiveDate("invalid-date")
        subscriber1.setContact(Arrays.asList(createMockContact(true)))

        def subscriber2 = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
        //subscriber2.setCtn("1234567891")
        subscriber2.setEffectiveDate("2025-01-15T10:00:00.000Z")
        subscriber2.setContact(Arrays.asList(createMockContact(true)))

        def subscriber3 = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
        //subscriber3.setCtn("1234567892")
        subscriber3.setEffectiveDate("")
        subscriber3.setContact(Arrays.asList(createMockContact(true)))

        subscribers.add(subscriber1)
        subscribers.add(subscriber2)
        subscribers.add(subscriber3)
        return subscribers
    }

    private List<com.att.idp.idgraphcontactinfoms.model.Subscribers> createMockSubscribersMixedCPNI() {
        List<com.att.idp.idgraphcontactinfoms.model.Subscribers> subscribers = new ArrayList<>()

        def subscriber1 = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
        //subscriber1.setCtn("1234567890")
        subscriber1.setEffectiveDate("2025-02-20T15:30:00.000Z")
        subscriber1.setContact(Arrays.asList(createMockContact(false))) // Not eligible

        def subscriber2 = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
        //subscriber2.setCtn("1234567891")
        subscriber2.setEffectiveDate("2025-01-15T10:00:00.000Z")
        subscriber2.setContact(Arrays.asList(createMockContact(true))) // Eligible

        def subscriber3 = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
        //subscriber3.setCtn("1234567892")
        subscriber3.setEffectiveDate("2025-03-10T08:45:00.000Z")
        subscriber3.setContact(Arrays.asList(createMockContact(true))) // Eligible

        subscribers.add(subscriber1)
        subscribers.add(subscriber2)
        subscribers.add(subscriber3)
        return subscribers
    }

    private List<com.att.idp.idgraphcontactinfoms.model.Subscribers> createMockSubscribersWithInvalidData() {
        List<com.att.idp.idgraphcontactinfoms.model.Subscribers> subscribers = new ArrayList<>()

        def subscriber1 = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
        //subscriber1.setCtn(null)
        subscriber1.setEffectiveDate("2025-02-20T15:30:00.000Z")
        subscriber1.setContact(null)

        def subscriber2 = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
       // subscriber2.setCtn("1234567891")
        subscriber2.setEffectiveDate(null)
        subscriber2.setContact(Arrays.asList(createMockContact(true)))

        subscribers.add(subscriber1)
        subscribers.add(subscriber2)
        return subscribers
    }

    private com.att.idp.idgraphcontactinfoms.model.Contact createMockContact(boolean cpniEligible) {
        def contact = new com.att.idp.idgraphcontactinfoms.model.Contact()
        def contactMedium = new com.att.idp.idgraphcontactinfoms.model.ContactMedium()
        def characteristic = new com.att.idp.idgraphcontactinfoms.model.Characteristic()
        characteristic.setCpniEligible(cpniEligible)
        contactMedium.setCharacteristic(characteristic)
        contact.setContactMediums(Arrays.asList(contactMedium))
        return contact
    }

    private com.att.idp.idgraphcontactinfoms.model.Subscribers createMockCPNIEligibleSubscriber(boolean cpniEligible) {
        def subscriber = new com.att.idp.idgraphcontactinfoms.model.Subscribers()
        //subscriber.setCtn("1234567890")
        subscriber.setEffectiveDate("2025-01-15T10:00:00.000Z")
        subscriber.setContact(Arrays.asList(createMockContact(cpniEligible)))
        return subscriber
    }

    @Unroll
    def "companion subscriber with duoIdentifier=#duoIdentifier and targetSOR=#targetSOR should have cpniEligible=false and skip BAU rules"() {
        given: "a mock companion subscriber"
        def subscriber = Mock(com.att.idp.dpl.profile.bsse.customerv4.Subscriber)
        def status = Mock(com.att.idp.dpl.profile.bsse.customerv4.Status)
        def accountCreatedOn = "2025-01-27T13:54:08.172Z"
        def phoneNumber = "1234567890"

        when: "populateIndividualSubscriberContacts is called"
        def result = cpniContactInfoHelper.populateIndividualSubscriberContacts(subscriber, targetSOR, accountCreatedOn)

        then: "status and cgUtil are called unconditionally, but CPNI eligibility helpers are NOT called"
        2 * subscriber.getStatus() >> status
        1 * status.getStatus() >> null
        1 * cgUtilHelperMock.resolveSubscriberDeviceDetailsByTargetSOR(subscriber, targetSOR) >> [:]
        1 * subscriber.getDuoIdentifier() >> duoIdentifier
        2 * subscriber.getPhoneNumber() >> phoneNumber
        0 * cpniEligibilityHelperMock.updateSubscriberCPNIEligibility(_, _, _, _, _)
        0 * cpniEligibilityHelperMock.updateSubscriberCPNIEligibilityForLegacy(_, _, _, _, _)
        0 * _

        and: "the result has cpniEligible=false"
        result != null
        result.size() == 1
        result[0].contactMediums.size() == 1
        result[0].contactMediums[0].characteristic.cpniEligible == false
        result[0].contactMediums[0].characteristic.phoneNumber == phoneNumber

        where:
        duoIdentifier | targetSOR
        "companion"   | "CG"
        "companion"   | "LEGACY"
        "COMPANION"   | "CG"
    }

    @Unroll
    def "non-companion subscriber with duoIdentifier=#duoIdentifier and targetSOR=#targetSOR should #expectedBehavior"() {
        given: "a mock non-companion subscriber"
        def subscriber = Mock(com.att.idp.dpl.profile.bsse.customerv4.Subscriber)
        def status = Mock(com.att.idp.dpl.profile.bsse.customerv4.Status)
        def accountCreatedOn = "2025-01-27T13:54:08.172Z"
        def phoneNumber = "1234567890"

        when: "populateIndividualSubscriberContacts is called"
        def result = cpniContactInfoHelper.populateIndividualSubscriberContacts(subscriber, targetSOR, accountCreatedOn)

        then: "BAU CPNI rules are applied based on targetSOR"
        2 * subscriber.getStatus() >> status
        1 * status.getStatus() >> "active"
        1 * cgUtilHelperMock.resolveSubscriberDeviceDetailsByTargetSOR(subscriber, targetSOR) >> ["smsCapabilityInd": "Y", "simSwapDateValue": null]
        1 * subscriber.getDuoIdentifier() >> duoIdentifier
        1 * subscriber.getPhoneNumber() >> phoneNumber
        expectedCpniCalls * cpniEligibilityHelperMock.updateSubscriberCPNIEligibility(_, "active", _, null, accountCreatedOn)
        expectedLegacyCalls * cpniEligibilityHelperMock.updateSubscriberCPNIEligibilityForLegacy(_, "active", _, null, accountCreatedOn)
        0 * _

        and: "the result is properly structured"
        result != null
        result.size() == 1
        result[0].contactMediums.size() == 1
        result[0].contactMediums[0].characteristic.phoneNumber == phoneNumber

        where:
        duoIdentifier | targetSOR | expectedBehavior                                             | expectedCpniCalls | expectedLegacyCalls
        "anchor"      | "CG"      | "call updateSubscriberCPNIEligibility"                        | 1                 | 0
        "anchor"      | "LEGACY"  | "call updateSubscriberCPNIEligibilityForLegacy"               | 0                 | 1
        null          | "CG"      | "call updateSubscriberCPNIEligibility"                        | 1                 | 0
        null          | "LEGACY"  | "call updateSubscriberCPNIEligibilityForLegacy"               | 0                 | 1
        ""            | "CG"      | "call updateSubscriberCPNIEligibility"                        | 1                 | 0
        ""            | "LEGACY"  | "call updateSubscriberCPNIEligibilityForLegacy"               | 0                 | 1
    }


    private CGIndividualInfo buildMockCGIndividualInfo_AccountType(String accountType) {
        CGIndividualInfo cgIndividualInfo = new CGIndividualInfo();

        // Populate contact mediums
        List<io.swagger.client.model.ContactMedium> contactMediums = new ArrayList<>();
        io.swagger.client.model.ContactMedium contactMedium = new io.swagger.client.model.ContactMedium();
        contactMedium.setMediumType("email");
        contactMedium.setPreferred(true);

        Characteristic characteristic = new Characteristic();
        characteristic.setEmailAddress("test@example.com");
        characteristic.setVerified(true);
        characteristic.setEstablishmentDate("2025-01-27T13:53:32.582Z");
        contactMedium.setCharacteristic(characteristic);

        io.swagger.client.model.ContactMedium contactMedium1 = new io.swagger.client.model.ContactMedium();
        contactMedium1.setMediumType("telephone");
        contactMedium1.setPreferred(true);

        Characteristic characteristic1 = new Characteristic();
        characteristic1.setPhoneNumber("2604080012");
        characteristic1.setVerified(true);
        characteristic1.setEstablishmentDate("2025-01-27T13:53:32.582Z");
        contactMedium1.setCharacteristic(characteristic1);

        contactMediums.add(contactMedium);
        contactMediums.add(contactMedium1);

        cgIndividualInfo.setContactMedium(contactMediums);

        // Populate accounts with contacts
        List<IndividualAccountResponse> accounts = new ArrayList<>();
        IndividualAccountResponse account = new IndividualAccountResponse();
        account.setId("12345");
        account.setAccountType(accountType);
        List<String> serviceType = new ArrayList<>();
        serviceType.add("wireless")
        account.setServiceType(serviceType);
        account.setCreatedOn("2025-01-27T13:54:08.172Z");
        List<String> serviceTypeList = new ArrayList<>()
        serviceTypeList.add("wireless");
        account.setServiceType(serviceTypeList)

        // Add contacts to the account
        List<Contact> contacts = new ArrayList<>();
        List<io.swagger.client.model.ContactMedium> accContactMediumList = new ArrayList<>()
        Contact contact = new Contact();

        io.swagger.client.model.ContactMedium accContactMedium = new io.swagger.client.model.ContactMedium();
        Characteristic accCharacteristic = new Characteristic();
        accContactMedium.setMediumType("postalAddress")
        accContactMedium.setPreferred(true)
        accCharacteristic.setCity("CHULA VISTA")
        accCharacteristic.setPostCode("91911-3907")
        accCharacteristic.setVerified(false)
        accCharacteristic.setEstablishmentDate("2025-01-27T13:54:08.172Z")
        accContactMedium.setCharacteristic(accCharacteristic)

        io.swagger.client.model.ContactMedium accContactMedium2 = new io.swagger.client.model.ContactMedium();
        Characteristic accCharacteristic2 = new Characteristic();
        accContactMedium2.setMediumType("email")
        accContactMedium2.setPreferred(true)
        accCharacteristic2.setEmailAddress("M59031@att.com")
        accCharacteristic2.setVerified(false)
        accCharacteristic2.setEstablishmentDate("2025-02-27T13:54:08.172Z")
        accContactMedium2.setCharacteristic(accCharacteristic2)

        accContactMediumList.add(accContactMedium)
        accContactMediumList.add(accContactMedium2)

        contact.contactMedium(accContactMediumList)
        contacts.add(contact)

        account.setContact(contacts);

        // Add subscribers to the account
        List<Subscribers> subscribers = new ArrayList<>();
        Subscribers subscriber = new Subscribers();
        subscriber.setSmsCapable(true)
        subscriber.setCtn("75463627")
        subscriber.setStatus("active");
        subscriber.setCreatedOn("2025-01-27T13:54:08.172Z");
        subscriber.setUpdatedOn("2025-02-27T13:54:08.172Z");

        Subscribers subscriber1 = new Subscribers();
        subscriber1.setSmsCapable(true)
        subscriber1.setCtn("745389302")
        subscriber1.setStatus("active");
        subscriber1.setCreatedOn("2025-02-15T13:54:08.172Z");
        subscriber1.setUpdatedOn("2025-03-17T13:54:08.172Z");

        Subscribers subscriber2 = new Subscribers();
        subscriber2.setSmsCapable(true)
        subscriber2.setCtn("7453899867")
        subscriber2.setStatus("active");
        subscriber2.setCreatedOn("2025-02-15T13:54:08.172Z");
        subscriber2.setUpdatedOn("2025-03-17T13:54:08.172Z");


        subscribers.add(subscriber1);
        subscribers.add(subscriber2);

        account.setSubscribers(subscribers)

        accounts.add(account)

        cgIndividualInfo.setAccounts(accounts);

        // Populate other fields
        cgIndividualInfo.setId("3c0b9dc3-e62a-4a18-aa19-4b9dd4edc1a6");
        cgIndividualInfo.setStatus("active");
        cgIndividualInfo.setCreatedOn("2025-01-27T13:54:06.289Z");
        cgIndividualInfo.setUpdatedOn("2025-01-27T13:54:06.289Z");

        return cgIndividualInfo;
    }

    def "test cpniContactInfoBySubscriberNumber with valid response"() {
        given:
        String subscriberNumber = "1234567890"

        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoBySubscriberNumber(subscriberNumber, headers, true)

        then:
        1 * cgApiRestClient.getCustomerDetailsByAccountId({ it["phoneNumber"] == subscriberNumber }) >> getMockCGCustomerV4Data("mock-customer-v4-data.json")
        _ * cpniEligibilityHelperMock.isActiveStatus(_) >> true
        _ * cpniEligibilityHelperMock.updateCPNIEligibility(_, _, _, _)
        _ * cpniEligibilityHelperMock.updateSubscriberCPNIEligibility(_, _, _, _, _) >> { characteristic, status, smsCapable, simSwapDate, accountCreatedOn ->
            characteristic.setCpniEligible(true)
        }
        _ * cgUtilHelperMock.resolveSubscriberDeviceDetailsByTargetSOR(_, _) >> ["smsCapabilityInd": true, "simSwapDateValue": null]
        0 * _
        result != null
        result instanceof Individual
    }

    @Unroll
    def "test cpniContactInfoBySubscriberNumber returnBizCTNs behavior: #scenario"() {
        given:
        String subscriberNumber = "1234567890"
        def testHeaders = createBaseHeaders()
        testHeaders.putSingle("subscriberNumber", headerSubscriberNumber)

        when:
        Individual result = cpniContactInfoHelper.cpniContactInfoBySubscriberNumber(subscriberNumber, testHeaders, true)

        then:
        1 * cgApiRestClient.getCustomerDetailsByAccountId({ it["phoneNumber"] == subscriberNumber }) >> getMockCGCustomerV4Data("mock-customer-v4-data-accountType_B.json")
        _ * cpniEligibilityHelperMock.isActiveStatus(_) >> true
        _ * cpniEligibilityHelperMock.updateCPNIEligibility(_, _, _, _)
        _ * cpniEligibilityHelperMock.updateSubscriberCPNIEligibility(_, _, _, _, _) >> { characteristic, status, smsCapable, simSwapDate, accountCreatedOn ->
            characteristic.setCpniEligible(true)
        }
        _ * cgUtilHelperMock.resolveSubscriberDeviceDetailsByTargetSOR(_, _) >> ["smsCapabilityInd": true, "simSwapDateValue": null]
        0 * _
        result != null
        result.accounts.size() == 1
        result.accounts.get(0).accountType == expectedAccountType
        result.accounts.get(0).getSubscribers().size() == expectedSubscriberCount

        where:
        scenario                                              | headerSubscriberNumber | expectedAccountType | expectedSubscriberCount
        "subscriberNumber header present sets returnBizCTNs Y"| "1234567890"           | "B"                 | 2
        "blank subscriberNumber header keeps returnBizCTNs N" | ""                     | "B"                 | 0
    }

    def "test cpniContactInfoBySubscriberNumber with null response throws ServiceException"() {
        given:
        String subscriberNumber = "1234567890"

        when:
        cpniContactInfoHelper.cpniContactInfoBySubscriberNumber(subscriberNumber, headers, true)

        then:
        1 * cgApiRestClient.getCustomerDetailsByAccountId(_) >> null
        0 * _
        def ex = thrown(ServiceException)
        ex.error.errorId == "MS_MPSYS_BE_610"
    }

    def "test cpniContactInfoBySubscriberNumber with exception throws ServiceException"() {
        given:
        String subscriberNumber = "1234567890"

        when:
        cpniContactInfoHelper.cpniContactInfoBySubscriberNumber(subscriberNumber, headers, true)

        then:
        1 * cgApiRestClient.getCustomerDetailsByAccountId(_) >> { throw new RuntimeException("CG API failed") }
        0 * _
        def ex = thrown(ServiceException)
        ex.error.errorId == "MS_MPSYS_BE_602"
    }

    private static CustomerV4Response getMockCGCustomerV4Data(String inputJson) {
        ObjectMapper objMapper = new ObjectMapper()
        try {
            // Use getResourceAsStream to avoid NullPointerException
            InputStream inputStream = CPNIContactInfoHelperTest.class.getClassLoader().getResourceAsStream(inputJson)
            if (inputStream == null) {
                throw new RuntimeException("Resource file {} not found" + inputJson)
            }
            return objMapper.readValue(inputStream, CustomerV4Response)
        } catch (Exception e) {
            throw new RuntimeException("Failed to load mock profile data", e)
        }
    }
}
