package com.att.idp.integration

import spock.lang.Specification
import static org.hamcrest.CoreMatchers.anyOf
import static org.hamcrest.CoreMatchers.is

class SecurityCodeIT extends IntegrationTestBase {

	private Map<String, String> getHeaders() {
		Map<String, String> headers = new HashMap<>()
		headers.put("Content-Type", "application/json")
		headers.put("idp.trace_id", "3454323453")
		headers.put("X-ATT-UniqueTransactionId", "1234567890")
		return headers
	}

	def "generate pin success"() {
		given:
		String uri = "/pin/generate"
		String req = """{
            "transactionName" : "GeneratePIN",
            "callingSystemId" : "OPUS",
            "accountId" : "167856783345",
            "identificationType" : "EMAILPIN",
            "agentId" : "ad4567",
            "sourceIPAddress" : "12.12.2.34",
            "returnSecurityCode" : "Y",
            "browserLanguage" : "EN",
            "resBusInd" : "R",
            "deliveryMethods" : { "email": { "emailAddress":"vl6562@att.com"}}
        }"""

		when:
		def response = givenBaseSpec().headers(getHeaders()).body(req).post(uri)

		then:
		response.statusCode() in [200, 400]
	}

	def "validate pin success"() {
		given:
		String uri = "/pin/validate"
		String req = """{
            "transactionName" : "ValidatePIN",
            "callingSystemId" : "OPUS",
            "accountId" : "167856783345",
            "identificationType" : "EMAILPIN",
            "securityCode" : "710574",
            "sourceIPAddress" : "12.12.2.34",
            "deletePINOnSuccess" : "CURRENT",
            "agentId": "ad4567"
        }"""

		when:
		def response = givenBaseSpec().headers(getHeaders()).body(req).post(uri)

		then:
		response.statusCode() in [200, 400]
	}

	def "delete pin success"() {
		given:
		String uri = "/pin/delete"
		String req = """{
            "transactionName" : "DeletePIN",
            "callingSystemId" : "IDPSALES",
            "accountId" : "12345677111",
            "identificationType" : "ENCPIN",
            "securityCode" : "231832",
            "deleteAll" : "Y",
            "reasonCode" : "REGISTERED",
            "sourceIPAddress" : "12.12.2.34"
        }"""

		when:
		def response = givenBaseSpec().headers(getHeaders()).body(req).post(uri)

		then:
		response.statusCode() in [200, 400]
	}
}