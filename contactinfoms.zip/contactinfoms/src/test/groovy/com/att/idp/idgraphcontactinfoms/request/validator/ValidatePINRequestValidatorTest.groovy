package com.att.idp.idgraphcontactinfoms.request.validator

import com.att.idp.idgraphcontactinfoms.db.helper.CosmosDataStore
import com.att.idp.idgraphcontactinfoms.resource.request.ValidatePINRequest
import com.att.idp.idgraphcontactinfoms.resource.response.ValidatePINResponse
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap

class ValidatePINRequestValidatorTest extends Specification {
	
	def ValidatePINReqValidatorObj = new ValidatePINRequestValidator()
	public ValidatePINRequest ValidatePINReqObj

	def requestHeader = Stub(HttpHeaders)
	public MultivaluedHashMap requestHeaders = null
	private Map<String, String> headers = new HashMap<>()

	CosmosDataStore cosmosDataStore = Mock(CosmosDataStore)


	def setup() {

		requestHeaders = new MultivaluedHashMap<>(headers)
		ValidatePINReqObj = new ValidatePINRequest()

		ValidatePINReqObj.callingSystemId = 'IDP'
		ValidatePINReqObj.identificationType = 'EMAILOTP'
		ValidatePINReqObj.accountId = '4256374859'
		ValidatePINReqObj.agentId = '12345'
		ValidatePINReqObj.securityCode = 'securityCode'

		ReflectionTestUtils.setField(ValidatePINReqValidatorObj, 'propValidPINCSI',
				'IDSEMOB:IDP|DATAMGT,BANPCS:OPUS|IDP|CSRIDP,BANPCE:OPUS,BANPTONLS:MYATTSALES|IDP|UPPERFUNNEL|ANDIVA,BANPTONLE:MYATTSALES|IDP|ANDIVA,DTVNOWOTP:CSRIDP,CTNKSK:EXPKSK,BTN:IDP|DATAMGT,PINVALID:IDP|CSRIDP,NONATTCTN:IDP|CSRIDP|OPUS,ATTCTN:IDP|CSRIDP,EMAILOTP:IDP|OPUS,CRICKETOTP:IDP|CSRIDP|OPUS,EMAILPIN:IDP|CSRIDP|OPUS|ERICSSON|MYATTSALES|IDPSALES|MULESOFT|MYATTMOBILE,CTNDIH:IDP|CSRIDP|OPUS,BANAP:PENNYVA,TITANIMD:IDP|CSRIDP,CTN:IDP|CSRIDP,WBAN:IDP|CSRIDP,ECOMMSEC:IDP|CSRIDP,WBANSEC:IDP|CSRIDP,TITANSEC:IDP|CSRIDP,DTVOTP:DIRECTV,CTNAUTH:MULESOFT,CTNOPR:IDP|CSRIDP,ENCPIN:IDPSALES,PORTOUT:AVERTACK,CCPADTV:IDP,BSSEOTP:IDP|MULESOFT|IVR,BSSEONL:IDP,BSSEREGOTP:IDP')
		ReflectionTestUtils.setField(ValidatePINReqValidatorObj, 'propDeliveryMethods',
				'IDSEMOB:sms|email,BANPCS:sms,BANPCE:email,BANPTONLS:sms,BANPTONLE:email,DTVNOWOTP:sms|email,CTNKSK:sms,BTN:sms|email|letter|ao,PINVALID:sms|email,NONATTCTN:sms,ATTCTN:sms,EMAILOTP:email,CRICKETOTP:email,EMAILPIN:email,CTNDIH:sms,BANAP:sms|email,TITANIMD:sms|email|letter|ao,CTN:sms|email|letter|ao,WBAN:sms|email|letter|ao,ECOMMSEC:sms|email|letter|ao,WBANSEC:sms|email|letter|ao,TITANSEC:sms|email|letter|ao,DTVOTP:email,CTNAUTH:sms,CTNOPR:sms,ENCPIN:sms|email,CCPADTV:email,BSSEOTP:sms|email,BSSEONL:sms|email,BSSEREGOTP:sms|email')
		ReflectionTestUtils.setField(ValidatePINReqValidatorObj, 'propValidAgentCSI', 'OPUS|CSRIDP')


		//Mockito.doReturn("99dfs999:8dfs8888:77777:66666ccc").when(requestHeader).getHeaderString("X-ATT-UniqueTransactionId");
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('idpauthctx-sessionid') >> '202501_2341'
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		//Mockito.doReturn(requestHeaders).when(requestHeader).getRequestHeaders();

	
	}


	def "request validator success test"() {
		when:
		ValidatePINResponse validatePINResponse = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader,
				ValidatePINReqObj)
		then:
		validatePINResponse == null
	}


	def "validate p i n null request test"() {
		given:
		ValidatePINRequest ValidatePINRequestObj = null
		when:
		ValidatePINResponse ValidatePINResponse = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader,ValidatePINRequestObj)
		then:
		ValidatePINResponse.appInfo == 'Input Request is NULL / Empty.'
	}


	def "null calling system i d test"() {
		given:
		//Mockito.doReturn(null).when(requestHeader).getHeaderString('X-ATT-ClientId')
		ValidatePINReqObj.callingSystemId = null
		when:
		ValidatePINResponse ValidatePINResponse = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader,
				ValidatePINReqObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> null
		ValidatePINResponse.appInfo == 'Either X-ATT-ClientId in request header or callingSystemId in request body must be present'
	}

	def "invalid calling system i d test"() {
		given:
		//Mockito.lenient().doReturn(null).when(requestHeader).getHeaderString('X-ATT-ClientId')
		ValidatePINReqObj.callingSystemId = 'IDM'
		when:
		ValidatePINResponse ValidatePINResponse = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader,
				ValidatePINReqObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> null
		ValidatePINResponse.appInfo == 'EMAILOTP is not valid for :IDM'
	}

	def "null calling system i dand valid client i d test"() {
		given:
		//Mockito.doReturn('IDP').when(requestHeader).getHeaderString('X-ATT-ClientId')
		ValidatePINReqObj.callingSystemId = null
		when:
		ValidatePINResponse ValidatePINResponse = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader,
				ValidatePINReqObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		ValidatePINResponse == null
	}

	def "valid calling system i dand invalid client i d test"() {
		given:
		//Mockito.lenient().doReturn('IDM').when(requestHeader).getHeaderString('X-ATT-ClientId')
		ValidatePINReqObj.callingSystemId = 'IDP'
		when:
		ValidatePINResponse ValidatePINResponse = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader,
				ValidatePINReqObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDM'
		ValidatePINResponse == null
	}


	def "null identification type test"() {
		given:
		ValidatePINReqObj.identificationType = null
		when:
		ValidatePINResponse ValidatePINResponse = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader,
				ValidatePINReqObj)
		then:
		ValidatePINResponse.appInfo == 'IdentificationType can not be null / empty.'
	}


	def "null account i d test"() {
		given:
		ValidatePINReqObj.accountId = null
		when:
		ValidatePINResponse ValidatePINResponse = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader,
				ValidatePINReqObj)
		then:
		ValidatePINResponse.appInfo == 'AccountID can not be null / empty.'
	}


	def "invalid identification type test"() {
		given:
		ValidatePINReqObj.identificationType = 'IEMOB'
		when:
		ValidatePINResponse ValidatePINResponse = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader,
				ValidatePINReqObj)
		then:
		ValidatePINResponse.appInfo == 'IEMOB is not valid'
	}


	def "invalid c s i test"() {
		given:
		//Mockito.doReturn('DATAMGT').when(requestHeader).getHeaderString('X-ATT-ClientId')
		ValidatePINReqObj.callingSystemId = null
		when:
		ValidatePINResponse ValidatePINResponse = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader,
				ValidatePINReqObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'DATAMGT'
		ValidatePINResponse.appInfo == 'EMAILOTP is not valid for :DATAMGT'
	}


	def "null agent id for agent c s i test"() {
		given:
		//Mockito.doReturn('OPUS').when(requestHeader).getHeaderString('X-ATT-ClientId')
		ValidatePINReqObj.callingSystemId = null
		ValidatePINReqObj.agentId = null
		when:
		ValidatePINResponse ValidatePINResponse = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader,
				ValidatePINReqObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'OPUS'
		ValidatePINResponse.appInfo == 'AgentId is required'
	}


	def "null security code test"() {
		given:
		ValidatePINReqObj.securityCode = null
		when:
		ValidatePINResponse ValidatePINResponse = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader,ValidatePINReqObj)
		then:
		ValidatePINResponse.appInfo == 'SecurityCode can not be null / empty.'
	}
	
////	@Test
//	void CSIValidatorNullTest() {
//		ReflectionTestUtils.setField(ValidatePINReqValidatorObj, 'propValidPINCSI',null)
//		ValidatePINResponse ValidatePINResponse = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader,ValidatePINReqObj)
//		assertEquals('PROP_PIN_CSI  property is not configured in the properties file', ValidatePINResponse.appInfo)
//	}


	def "delete p i n on success invalid test"() {
		given:
		ValidatePINReqObj.deletePINOnSuccess = 'ok'
		when:
		ValidatePINResponse ValidatePINResponse = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader,ValidatePINReqObj)
		then:
		ValidatePINResponse.appInfo == 'DeletePINOnSuccess is Invalid :: Should be one of [ALL,CURRENT,NONE ]'
	}

	// ============================================================
	// Missing / AutoGen idp-trace-id
	// ============================================================

	def "null idp-trace-id returns error"() {
		given:
		def noTraceHeader = Stub(HttpHeaders)
		noTraceHeader.getHeaderString('idp-trace-id') >> null
		noTraceHeader.getHeaderString('idpauthctx-sessionid') >> null
		noTraceHeader.getHeaderString('X-ATT-UniqueTransactionId') >> null
		noTraceHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		org.slf4j.MDC.clear()

		when:
		ValidatePINResponse resp = ValidatePINReqValidatorObj.validatePINRequestValidator(noTraceHeader, ValidatePINReqObj)

		then:
		resp.appInfo == 'ValidatePIN Request idp-trace-id is missing'
		resp.appStatusCode != null
	}

	def "AutoGen idp-trace-id returns error"() {
		given:
		def autoGenHeader = Stub(HttpHeaders)
		autoGenHeader.getHeaderString('idp-trace-id') >> 'AutoGen_12345'
		autoGenHeader.getHeaderString('idpauthctx-sessionid') >> null
		autoGenHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'

		when:
		ValidatePINResponse resp = ValidatePINReqValidatorObj.validatePINRequestValidator(autoGenHeader, ValidatePINReqObj)

		then:
		resp.appInfo == 'ValidatePIN Request idp-trace-id is missing'
	}

	// ============================================================
	// idpgwbiz X-ATT-ClientId with idpctx-appname
	// ============================================================

	def "idpgwbiz client id uses idpctx-appname as callingSystemId"() {
		given:
		ValidatePINReqObj.callingSystemId = null
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'idpgwbiz'
		requestHeader.getHeaderString('idpctx-appname') >> 'IDP'

		when:
		ValidatePINResponse resp = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader, ValidatePINReqObj)

		then:
		resp == null
	}

	def "idpgwbiz client id with blank appname falls back to X-ATT-ClientId"() {
		given:
		def gwbizHeader = Stub(HttpHeaders)
		gwbizHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		gwbizHeader.getHeaderString('idpauthctx-sessionid') >> '202501_2341'
		gwbizHeader.getHeaderString('X-ATT-ClientId') >> 'idpgwbiz'
		gwbizHeader.getHeaderString('idpctx-appname') >> ''
		ValidatePINReqObj.callingSystemId = null

		when:
		ValidatePINResponse resp = ValidatePINReqValidatorObj.validatePINRequestValidator(gwbizHeader, ValidatePINReqObj)

		then:
		resp != null
		resp.appInfo == 'EMAILOTP is not valid for :IDPGWBIZ'
	}

	// ============================================================
	// CSIGATEWAY + BANPC → NTRETAILER mapping
	// ============================================================

	def "CSIGATEWAY with BANPC maps to NTRETAILER"() {
		given:
		ValidatePINReqObj.callingSystemId = 'CSIGATEWAY'
		ValidatePINReqObj.identificationType = 'BANPC'
		ReflectionTestUtils.setField(ValidatePINReqValidatorObj, 'propValidPINCSI',
				'NTRETAILER:CSIGATEWAY,EMAILOTP:IDP|OPUS')

		when:
		ValidatePINResponse resp = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader, ValidatePINReqObj)

		then:
		resp == null
	}

	// ============================================================
	// Unknown attributes in request
	// ============================================================

	def "unknown attributes returns error"() {
		given:
		ValidatePINReqObj.unknownAttributes.put('bogusField', 'someValue')

		when:
		ValidatePINResponse resp = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader, ValidatePINReqObj)

		then:
		resp.appInfo.startsWith('Invalid Attributes passed in ValidatePINRequest')
	}


	// ============================================================
	// Valid deletePINOnSuccess values
	// ============================================================

	def "deletePINOnSuccess ALL is valid"() {
		given:
		ValidatePINReqObj.deletePINOnSuccess = 'ALL'

		when:
		ValidatePINResponse resp = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader, ValidatePINReqObj)

		then:
		resp == null
	}

	def "deletePINOnSuccess CURRENT is valid"() {
		given:
		ValidatePINReqObj.deletePINOnSuccess = 'CURRENT'

		when:
		ValidatePINResponse resp = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader, ValidatePINReqObj)

		then:
		resp == null
	}

	def "deletePINOnSuccess NONE is valid"() {
		given:
		ValidatePINReqObj.deletePINOnSuccess = 'NONE'

		when:
		ValidatePINResponse resp = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader, ValidatePINReqObj)

		then:
		resp == null
	}

	// ============================================================
	// Empty string variants
	// ============================================================

	def "empty callingSystemId with null header returns error"() {
		given:
		ValidatePINReqObj.callingSystemId = ''
		requestHeader.getHeaderString('X-ATT-ClientId') >> null

		when:
		ValidatePINResponse resp = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader, ValidatePINReqObj)

		then:
		resp.appInfo == 'Either X-ATT-ClientId in request header or callingSystemId in request body must be present'
	}

	def "empty identificationType returns error"() {
		given:
		ValidatePINReqObj.identificationType = ''

		when:
		ValidatePINResponse resp = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader, ValidatePINReqObj)

		then:
		resp.appInfo == 'IdentificationType can not be null / empty.'
	}

	def "empty accountId returns error"() {
		given:
		ValidatePINReqObj.accountId = ''

		when:
		ValidatePINResponse resp = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader, ValidatePINReqObj)

		then:
		resp.appInfo == 'AccountID can not be null / empty.'
	}

	def "empty securityCode returns error"() {
		given:
		ValidatePINReqObj.securityCode = ''

		when:
		ValidatePINResponse resp = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader, ValidatePINReqObj)

		then:
		resp.appInfo == 'SecurityCode can not be null / empty.'
	}

	def "empty agentId for agent CSI returns error"() {
		given:
		ValidatePINReqObj.callingSystemId = null
		ValidatePINReqObj.agentId = ''

		when:
		ValidatePINResponse resp = ValidatePINReqValidatorObj.validatePINRequestValidator(requestHeader, ValidatePINReqObj)

		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'OPUS'
		resp.appInfo == 'AgentId is required'
	}


}
