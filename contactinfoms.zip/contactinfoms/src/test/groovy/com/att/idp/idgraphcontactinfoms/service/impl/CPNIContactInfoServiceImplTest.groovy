package com.att.idp.idgraphcontactinfoms.service.impl

import com.att.idp.core.exception.ServiceException
import com.att.idp.idgraphcontactinfoms.helpers.CPNIContactInfoHelper
import com.att.idp.idgraphcontactinfoms.message.ErrorMessages
import com.att.idp.idgraphcontactinfoms.model.Individual
import com.att.idp.idgraphcontactinfoms.resource.response.CPNIContactInfoResponse
import jakarta.ws.rs.core.MultivaluedHashMap
import jakarta.ws.rs.core.MultivaluedMap
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class CPNIContactInfoServiceImplTest extends Specification {

    def service = new CPNIContactInfoServiceImpl()
    def helper = Mock(CPNIContactInfoHelper)
    MultivaluedMap<String, String> headers

    def setup() {
        ReflectionTestUtils.setField(service, "cpniContactInfoHelper", helper)
    }

    def "should return success response when individual is found for individualId"() {
        given:
        def individual = new Individual()
        headers = new MultivaluedHashMap<>()
        headers.add("idp-trace-id", "trace123")
        headers.add("individualId", "d6141ec8-f423-4bbe-85ee-305ba823d2e2")
        headers.add("exploitable", "N")
        headers.add("returnBizCTNs", "N")
        helper.cpniContactInfoByIndividualId("d6141ec8-f423-4bbe-85ee-305ba823d2e2", headers, false) >> individual

        when:
        def resp = service.cpniContactInfo(headers)

        then:
        resp != null
        resp instanceof CPNIContactInfoResponse
        resp.appInfo == "Success"
        resp.idpTraceId == "trace123"
    }

    def "should throw ServiceException when individual is null for individualId"() {
        given:
        headers = new MultivaluedHashMap<>()
        headers.add("idp-trace-id", "trace123")
        headers.add("individualId", "d6141ec8-f423-4bbe-85ee-305ba823d2e2")
        headers.add("exploitable", "N")
        headers.add("returnBizCTNs", "N")
        helper.cpniContactInfoByIndividualId("d6141ec8-f423-4bbe-85ee-305ba823d2e2", headers, false) >> null

        when:
        service.cpniContactInfo(headers)

        then:
        def ex = thrown(ServiceException)
        ex.error.errorId == "MS_MPSYS_BE_602"
    }

    def "should rethrow ServiceException from helper for individualId"() {
        given:
        headers = new MultivaluedHashMap<>()
        headers.add("idp-trace-id", "trace123")
        headers.add("individualId", "d6141ec8-f423-4bbe-85ee-305ba823d2e2")
        headers.add("exploitable", "N")
        headers.add("returnBizCTNs", "N")
        helper.cpniContactInfoByIndividualId("d6141ec8-f423-4bbe-85ee-305ba823d2e2", headers, false) >> { throw new ServiceException(ErrorMessages.MS_MPSYS_BE_610,"fail") }

        when:
        service.cpniContactInfo(headers)

        then:
        def ex = thrown(ServiceException)
        ex.error.errorId == "MS_MPSYS_BE_610"
    }

    def "should return error response when generic exception is thrown for individualId"() {
        given:
        headers = new MultivaluedHashMap<>()
        headers.add("idp-trace-id", "trace123")
        headers.add("individualId", "d6141ec8-f423-4bbe-85ee-305ba823d2e2")
        headers.add("exploitable", "N")
        headers.add("returnBizCTNs", "N")
        helper.cpniContactInfoByIndividualId("d6141ec8-f423-4bbe-85ee-305ba823d2e2", headers, false) >> { throw new RuntimeException("unexpected") }

        when:
        def resp = service.cpniContactInfo(headers)

        then:
        resp != null
        resp instanceof CPNIContactInfoResponse
        resp.idpTraceId == "trace123"
        resp.errors != null
    }

    def "should return success response when individual is found for accountId"() {
        given:
        headers = new MultivaluedHashMap<>()
        headers.add("idp-trace-id", "trace123")
        headers.add("accountId", "554674556832")
        headers.add("accountType", "wireless")
        headers.add("exploitable", "N")
        headers.add("returnBizCTNs", "N")
        def individual = new Individual()
        helper.cpniContactInfoByAccountId("554674556832", "wireless", headers, true) >> individual

        when:
        def resp = service.cpniContactInfo(headers)

        then:
        resp != null
        resp instanceof CPNIContactInfoResponse
        resp.appInfo == "Success"
        resp.idpTraceId == "trace123"
    }

    def "should throw ServiceException when individual is null for accountId"() {
        given:
        headers = new MultivaluedHashMap<>()
        headers.add("idp-trace-id", "trace123")
        headers.add("accountId", "554674556832")
        headers.add("accountType", "wireless")
        headers.add("exploitable", "N")
        headers.add("returnBizCTNs", "N")
        helper.cpniContactInfoByAccountId("554674556832", "wireless", headers, true) >> null

        when:
        service.cpniContactInfo(headers)

        then:
        def ex = thrown(ServiceException)
        ex.error.errorId == "MS_MPSYS_BE_602"
    }


    def "should rethrow ServiceException from helper for accountId"() {
        given:
        headers = new MultivaluedHashMap<>()
        headers.add("idp-trace-id", "trace123")
        headers.add("accountId", "554674556832")
        headers.add("accountType", "wireless")
        headers.add("exploitable", "N")
        headers.add("returnBizCTNs", "N")
        helper.cpniContactInfoByAccountId("554674556832", "wireless", headers, true) >> { throw new ServiceException(ErrorMessages.MS_MPSYS_BE_610,"fail") }

        when:
        service.cpniContactInfo(headers)

        then:
        def ex = thrown(ServiceException)
        ex.error.errorId == "MS_MPSYS_BE_610"
    }

    def "should return error response when generic exception is thrown for accountId"() {
        given:
        headers = new MultivaluedHashMap<>()
        headers.add("idp-trace-id", "trace123")
        headers.add("accountId", "554674556832")
        headers.add("accountType", "wireless")
        headers.add("exploitable", "N")
        headers.add("returnBizCTNs", "N")
        helper.cpniContactInfoByAccountId("554674556832", "wireless", headers, true) >> { throw new RuntimeException("unexpected") }

        when:
        def resp = service.cpniContactInfo(headers)

        then:
        resp != null
        resp instanceof CPNIContactInfoResponse
        resp.idpTraceId == "trace123"
        resp.errors != null
    }

    def "should return success response when individual is found for subscriberNumber"() {
        given:
        headers = new MultivaluedHashMap<>()
        headers.add("idp-trace-id", "trace123")
        headers.add("subscriberNumber", "1234567890")
        headers.add("exploitable", "N")
        headers.add("returnBizCTNs", "N")
        def individual = new Individual()

        when:
        def resp = service.cpniContactInfo(headers)

        then:
        1 * helper.cpniContactInfoBySubscriberNumber("1234567890", headers, true) >> individual
        resp != null
        resp instanceof CPNIContactInfoResponse
        resp.appInfo == "Success"
        resp.idpTraceId == "trace123"
        0 * _
    }

    def "should throw ServiceException when individual is null for subscriberNumber"() {
        given:
        headers = new MultivaluedHashMap<>()
        headers.add("idp-trace-id", "trace123")
        headers.add("subscriberNumber", "1234567890")
        headers.add("exploitable", "N")
        headers.add("returnBizCTNs", "N")

        when:
        service.cpniContactInfo(headers)

        then:
        1 * helper.cpniContactInfoBySubscriberNumber("1234567890", headers, true) >> null
        def ex = thrown(ServiceException)
        ex.error.errorId == "MS_MPSYS_BE_602"
        0 * _
    }

    def "should rethrow ServiceException from helper for subscriberNumber"() {
        given:
        headers = new MultivaluedHashMap<>()
        headers.add("idp-trace-id", "trace123")
        headers.add("subscriberNumber", "1234567890")
        headers.add("exploitable", "N")
        headers.add("returnBizCTNs", "N")

        when:
        service.cpniContactInfo(headers)

        then:
        1 * helper.cpniContactInfoBySubscriberNumber("1234567890", headers, true) >> { throw new ServiceException(ErrorMessages.MS_MPSYS_BE_610, "CG API failed") }
        def ex = thrown(ServiceException)
        ex.error.errorId == "MS_MPSYS_BE_610"
        0 * _
    }

    def "should return error response when generic exception is thrown for subscriberNumber"() {
        given:
        headers = new MultivaluedHashMap<>()
        headers.add("idp-trace-id", "trace123")
        headers.add("subscriberNumber", "1234567890")
        headers.add("exploitable", "N")
        headers.add("returnBizCTNs", "N")

        when:
        def resp = service.cpniContactInfo(headers)

        then:
        1 * helper.cpniContactInfoBySubscriberNumber("1234567890", headers, true) >> { throw new RuntimeException("unexpected error") }
        resp != null
        resp instanceof CPNIContactInfoResponse
        resp.idpTraceId == "trace123"
        resp.errors != null
        0 * _
    }
}