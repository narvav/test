package com.att.idp.idgraphcontactinfoms.db.helper
import com.att.idp.idgraphcontactinfoms.cassandra.entity.SessionId
import com.att.idp.idgraphcontactinfoms.cassandra.entity.ValidatePinAuthInfo
import com.att.idp.idgraphcontactinfoms.cassandra.repository.ValidatePinAuthInfoRepository
import com.att.idp.idgraphcontactinfoms.exceptions.MPSException
import org.apache.commons.lang3.StringUtils
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Specification
import spock.lang.Subject

class CosmosDataStoreTest extends Specification {

    @Subject
    CosmosDataStore cosmosDataStore

    ValidatePinAuthInfoRepository validatePinAuthInfoRepository = Mock(ValidatePinAuthInfoRepository)
    Logger logger = LoggerFactory.getLogger(CosmosDataStore)

    def setup() {
        cosmosDataStore = new CosmosDataStore()
        cosmosDataStore.validatePinAuthInfoRepository = validatePinAuthInfoRepository
    }

    def "test PersistValidatePinInfoToDatabase with valid input"() {
        given:
        ValidatePinInfoBean bean = new ValidatePinInfoBean()
        bean.setSessionId("session123")
        bean.setAccountNumber("account123")
        bean.setAccountType("type123")
        bean.setAuthenticationMethod("OPTEMAIL")
        bean.setChannel("channel123")
        bean.setStatus("status123")
        bean.setFailureReason("failureReason123")
        bean.setEmailAddress("test123@att.com");
        bean.setPhoneNumber("2345678901");

        when:
        cosmosDataStore.PersistValidatePinInfoToDatabase(bean)

        then:
        1 * validatePinAuthInfoRepository.save(_ as ValidatePinAuthInfo)
    }

    def "test PersistValidatePinInfoToDatabase with null bean"() {
        when:
        cosmosDataStore.PersistValidatePinInfoToDatabase(null)

        then:
        thrown(NullPointerException)
    }



    def "test PersistValidatePinInfoToDatabase with exception"() {
        given:
        ValidatePinInfoBean bean = new ValidatePinInfoBean()
        bean.setSessionId("session123")
        validatePinAuthInfoRepository.save(_ as ValidatePinAuthInfo) >> { throw new RuntimeException("DB error") }

        when:
        cosmosDataStore.PersistValidatePinInfoToDatabase(bean)

        then:
        def e = thrown(MPSException)
        e.message == "Exception in CosmosDBHelper::DB error"
    }
}
