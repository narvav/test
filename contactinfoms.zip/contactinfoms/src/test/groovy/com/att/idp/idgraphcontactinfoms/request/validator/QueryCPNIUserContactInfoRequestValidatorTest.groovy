package com.att.idp.idgraphcontactinfoms.request.validator

import com.att.idp.idgraphcontactinfoms.resource.request.QueryCPNIUserContactInfoRequest
import com.att.idp.idgraphcontactinfoms.resource.response.QueryCPNIUserContactInfoResponse
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap

class QueryCPNIUserContactInfoRequestValidatorTest extends Specification {

	def queryCPNIUserContactInfoRequestValidatorObj = new QueryCPNIUserContactInfoRequestValidator()
	QueryCPNIUserContactInfoRequest queryCPNIUserContactInfoRequestObj

	def requestHeader = Stub(HttpHeaders)
	public MultivaluedHashMap requestHeaders = null
	private Map<String, String> headers = new HashMap<>()


	def setup() {

		requestHeaders = new MultivaluedHashMap<>(headers)
		queryCPNIUserContactInfoRequestObj = new QueryCPNIUserContactInfoRequest()
		queryCPNIUserContactInfoRequestObj.callingSystemId = 'IDP'
		queryCPNIUserContactInfoRequestObj.userId = 'qay3958924'
		queryCPNIUserContactInfoRequestObj.domain = 'slid.dum'
		queryCPNIUserContactInfoRequestObj.guid = 'TITAN'
		queryCPNIUserContactInfoRequestObj.returnCBRCTNs = 'Y'
		queryCPNIUserContactInfoRequestObj.isExternalCall = 'Y'

		ReflectionTestUtils.setField(queryCPNIUserContactInfoRequestValidatorObj, 'propQueryCpniUserCSI', 'DATAMGT|IDP|CSRIDP|ILM|MULESOFT|OPUS|CUSTOMERGRAPH')

		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getRequestHeaders() >> requestHeaders

	}


	def "query cpni user contact info success request test"() {
		when:
		QueryCPNIUserContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		queryCPNIAccountContactInfoResponse == null
	}


	def "query cpni user contact info null request test"() {
		when:
		QueryCPNIUserContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, null)
		then:
		queryCPNIAccountContactInfoResponse.appInfo == 'Input Request Parameter is NULL / Empty.'
	}


	def "query cpni user contact info calling system i d test"() {
		given:
		//Mockito.doReturn(null).when(requestHeader).getHeaderString('X-ATT-ClientId')
		queryCPNIUserContactInfoRequestObj.callingSystemId = null
		when:
		QueryCPNIUserContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> null
		queryCPNIAccountContactInfoResponse.appInfo == 'Either X-ATT-ClientId in request header or callingSystemId in request body must be present'
	}

	def "query cpni user contact info invalid calling system i d test"() {
		given:
		//Mockito.doReturn('IDP').when(requestHeader).getHeaderString('X-ATT-ClientId')
		queryCPNIUserContactInfoRequestObj.callingSystemId = 'IDM'
		when:
		QueryCPNIUserContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		queryCPNIAccountContactInfoResponse.appInfo == 'Invalid X-ATT-ClientId or callingSystemId passed in request '
	}


	def "query cpni user contact info return c b r c t ns test"() {
		given:
		queryCPNIUserContactInfoRequestObj.returnCBRCTNs = 'aha'
		when:
		QueryCPNIUserContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		queryCPNIAccountContactInfoResponse.appInfo == 'returnCBRCTNs should be either Y or N'
	}


	def "query cpni user contact info is external call test"() {
		given:
		queryCPNIUserContactInfoRequestObj.isExternalCall = '9876534567'
		when:
		QueryCPNIUserContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		queryCPNIAccountContactInfoResponse.appInfo == 'isExternalCall should be either Y or N'
	}


	def "query cpni user contact info calling system i ds test"() {
		given:
		//Mockito.doReturn('ooooo').when(requestHeader).getHeaderString('X-ATT-ClientId')
		queryCPNIUserContactInfoRequestObj.callingSystemId = null
		when:
		QueryCPNIUserContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'ooooooo'
		queryCPNIAccountContactInfoResponse.appInfo == 'Invalid X-ATT-ClientId or callingSystemId passed in request '
	}


	def "query cpni user contact infos domain test"() {
		given:
		queryCPNIUserContactInfoRequestObj.domain = 'att.dum'
		when:
		QueryCPNIUserContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		queryCPNIAccountContactInfoResponse.appInfo == 'Input domain should be slid.dum'
	}


	def "query cpni user contact infos handle domain guid null test"() {
		given:
		queryCPNIUserContactInfoRequestObj.guid = null
		queryCPNIUserContactInfoRequestObj.userId = null
		queryCPNIUserContactInfoRequestObj.domain = null
		when:
		QueryCPNIUserContactInfoResponse queryCPNIAccountContactInfoResponse = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		queryCPNIAccountContactInfoResponse.appInfo == 'Either guid OR userId must be present'
	}

	def "query cpni user contact info idp trace id null test"() {
		given:
		requestHeader.getHeaderString('idp-trace-id') >> null
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		response == null
	}

	def "query cpni user contact info idp trace id empty string test"() {
		given:
		requestHeader.getHeaderString('idp-trace-id') >> ''
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		response == null // Should proceed, not error, as empty string is not null or AutoGen_
	}

	def "query cpni user contact info idp trace id whitespace test"() {
		given:
		requestHeader.getHeaderString('idp-trace-id') >> '   '
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		response == null // Should proceed, not error, as whitespace is not null or AutoGen_
	}

	def "query cpni user contact info idp trace id autogen test"() {
		given:
		requestHeader.getHeaderString('idp-trace-id') >> 'AutoGen_12345'
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		response == null
	}

	def "query cpni user contact info calling system id empty string test"() {
		given:
		queryCPNIUserContactInfoRequestObj.callingSystemId = ''
		requestHeader.getHeaderString('X-ATT-ClientId') >> ''
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		response.appInfo == 'Either X-ATT-ClientId in request header or callingSystemId in request body must be present'
	}

	def "query cpni user contact info calling system id whitespace test"() {
		given:
		queryCPNIUserContactInfoRequestObj.callingSystemId = '   '
		requestHeader.getHeaderString('X-ATT-ClientId') >> '   '
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		response.appStatusMsg == 'ERR_INVALID_DATA'
	}

	def "query cpni user contact info unknown attributes present test"() {
		given:
		queryCPNIUserContactInfoRequestObj.unknownAttributes = ["foo": "bar"]
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		response.appInfo.contains('Invalid Attributes passed in QueryCPNIUserContactInfoRequest')
	}

	def "query cpni user contact info unknown attributes empty test"() {
		given:
		queryCPNIUserContactInfoRequestObj.unknownAttributes = [:]
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		response == null
	}

	def "query cpni user contact info user id empty string test"() {
		given:
		queryCPNIUserContactInfoRequestObj.userId = ''
		queryCPNIUserContactInfoRequestObj.guid = null
		queryCPNIUserContactInfoRequestObj.domain = 'slid.dum'
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		response.appInfo == 'Either guid OR userId must be present'
	}

	def "query cpni user contact info user id whitespace test"() {
		given:
		queryCPNIUserContactInfoRequestObj.userId = '   '
		queryCPNIUserContactInfoRequestObj.guid = null
		queryCPNIUserContactInfoRequestObj.domain = 'slid.dum'
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		response.appInfo == 'Either guid OR userId must be present'
	}

	def "query cpni user contact info guid empty string test"() {
		given:
		queryCPNIUserContactInfoRequestObj.guid = ''
		queryCPNIUserContactInfoRequestObj.userId = null
		queryCPNIUserContactInfoRequestObj.domain = null
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		response.appInfo == 'Either guid OR userId must be present'
	}

	def "query cpni user contact info guid whitespace test"() {
		given:
		queryCPNIUserContactInfoRequestObj.guid = '   '
		queryCPNIUserContactInfoRequestObj.userId = null
		queryCPNIUserContactInfoRequestObj.domain = null
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		response.appInfo == 'Either guid OR userId must be present'
	}

	def "query cpni user contact info domain empty string test"() {
		given:
		queryCPNIUserContactInfoRequestObj.domain = ''
		queryCPNIUserContactInfoRequestObj.userId = 'user123'
		queryCPNIUserContactInfoRequestObj.guid = null
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		response.appInfo == 'Either guid OR userId must be present'
	}

	def "query cpni user contact info domain whitespace test"() {
		given:
		queryCPNIUserContactInfoRequestObj.domain = '   '
		queryCPNIUserContactInfoRequestObj.userId = 'user123'
		queryCPNIUserContactInfoRequestObj.guid = null
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		response.appInfo == 'Input domain should be slid.dum'
	}

	def "query cpni user contact info return c b r c t ns empty string test"() {
		given:
		queryCPNIUserContactInfoRequestObj.returnCBRCTNs = ''
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		response.appInfo=="returnCBRCTNs should be either Y or N"
	}

	def "query cpni user contact info return c b r c t ns whitespace test"() {
		given:
		queryCPNIUserContactInfoRequestObj.returnCBRCTNs = '   '
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		response.appInfo == 'returnCBRCTNs should be either Y or N'
	}

	def "query cpni user contact info is external call empty string test"() {
		given:
		queryCPNIUserContactInfoRequestObj.isExternalCall = null
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		queryCPNIUserContactInfoRequestObj.isExternalCall == 'Y'
	}

	def "query cpni user contact info is external call whitespace test"() {
		given:
		queryCPNIUserContactInfoRequestObj.isExternalCall = '   '
		when:
		QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
		then:
		response.appInfo == 'isExternalCall should be either Y or N'
	}

	def "query cpni user contact info exception test"() {
        given:
        ReflectionTestUtils.setField(queryCPNIUserContactInfoRequestValidatorObj, 'propQueryCpniUserCSI', "")
        when:
        QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
        then:
        response != null // Should not throw NPE
    }

    def "query cpni user contact info guid non empty sets userId and domain null test"() {
        given:
        queryCPNIUserContactInfoRequestObj.guid = 'G123'
        queryCPNIUserContactInfoRequestObj.userId = null
        queryCPNIUserContactInfoRequestObj.domain = null
        when:
        queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
        then:
        queryCPNIUserContactInfoRequestObj.userId == null
        queryCPNIUserContactInfoRequestObj.domain == null
    }

    def "query cpni user contact info invalid callingSystemId with Y external call test"() {
        given:
        queryCPNIUserContactInfoRequestObj.isExternalCall = 'Y'
        queryCPNIUserContactInfoRequestObj.callingSystemId = 'INVALID'
        when:
        QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
        then:
        response.appInfo.contains('Invalid X-ATT-ClientId or callingSystemId passed in request')
    }

    def "query cpni user contact info valid callingSystemId with Y external call test"() {
        given:
        queryCPNIUserContactInfoRequestObj.isExternalCall = 'Y'
        queryCPNIUserContactInfoRequestObj.callingSystemId = 'IDP'
        when:
        QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
        then:
        response == null
    }

    def "query cpni user contact info domain not slid.dum test"() {
        given:
        queryCPNIUserContactInfoRequestObj.userId = 'user123'
        queryCPNIUserContactInfoRequestObj.domain = 'notdum'
        queryCPNIUserContactInfoRequestObj.guid = null
        when:
        QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
        then:
        response.appInfo == 'Input domain should be slid.dum'
    }

    def "query cpni user contact info domain slid.dum test"() {
        given:
        queryCPNIUserContactInfoRequestObj.userId = 'user123'
        queryCPNIUserContactInfoRequestObj.domain = 'slid.dum'
        queryCPNIUserContactInfoRequestObj.guid = null
        when:
        QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
        then:
        response == null
    }

    def "query cpni user contact info mock getTraceId returns null test"() {
        given:
        GroovyMock(com.att.mpsys.common.utils.CommonUtil, global: true)
        com.att.mpsys.common.utils.CommonUtil.getTraceId(_) >> null
        when:
        QueryCPNIUserContactInfoResponse response = queryCPNIUserContactInfoRequestValidatorObj.queryCPNIUserContactInfoRequestValidator(requestHeader, queryCPNIUserContactInfoRequestObj)
        then:
        response == null
    }
}