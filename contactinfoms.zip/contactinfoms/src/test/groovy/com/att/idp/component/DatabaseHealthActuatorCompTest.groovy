package com.att.idp.component

import com.att.ajsc.common.utility.SystemPropertiesLoader
import io.restassured.RestAssured
import io.restassured.http.ContentType
import io.restassured.specification.RequestSpecification
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.ContextConfiguration
import org.springframework.test.context.TestPropertySource
import com.att.idp.idgraphcontactinfoms.Application
import com.att.idp.idgraphcontactinfoms.config.CassandraConfiguration

@ContextConfiguration(classes = [Application.class, TestKafkaPropertiesConfig.class, CompBaseTest.TestConfig.class])
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = [Application.class, CompBaseTest.TestConfig.class])
@TestPropertySource(properties = [
	'management.endpoint.health.indicator.override=true'
])
class DatabaseHealthActuatorCompTest extends CompBaseTest {

	static {
		SystemPropertiesLoader.addSystemProperties()
	}

	private String url

	def setup() throws Exception {
		if (contextPath == null || contextPath.isEmpty()) {
			throw new IllegalStateException("Context path is not set or is empty.")
		}
		url = 'http://localhost:' + randomServerPort + contextPath + '/' + 'actuator/health/database'
	}

	protected RequestSpecification givenBasicSpec() {
		return RestAssured.given()
				.relaxedHTTPSValidation()
				.accept(ContentType.JSON)
				.contentType(ContentType.JSON)
	}

	private Map<String, String> getHeaders() {
		return ["Content-Type": "application/json"]
	}

	def "check database health is success"() {
		when:
		def response = givenBasicSpec().headers(getHeaders()).get(url)

		then:
		response.statusCode == 200
		response.body().jsonPath().getString("status") == "UP"
		0 * _
	}
}
