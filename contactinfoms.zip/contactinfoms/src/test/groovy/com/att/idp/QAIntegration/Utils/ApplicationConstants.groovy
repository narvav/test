package com.att.idp.QAIntegration.Utils

import groovy.util.logging.Slf4j

@Slf4j
class ApplicationConstants {
	static String clusterName = System.getProperty("INTEGRATION_TEST_CLUSTER")?.trim()?.toLowerCase()
	static String BASE_URL = System.getProperty("BASE_URL")?.trim()
	def static env = clusterName ?: System.getProperty("env")?.trim()?.toLowerCase() ?: "graph1eus2-test3"
	static final String CONFIG_FILE_PATH = "src/test/resources/config.json"

	static class Header {
		//Header key
		static final String AUTHORIZATION = "Authorization"
		static final String CONTENT_TYPE = "Content-Type"
		static final String ACCEPT = "Accept"
		static final String ATT_CLIENT_ID = "x-att-clientId"
		static final String IDP_CG_ACCOUNT_ID = "idp-cg-account-id"
		static final String IDP_CG_SUBSCRIBER_ID = "idp-cg-subscriber-id"
		//Header values
		static final String CONTENT_TYPE_VALUE = "application/json"
		static final String ACCEPT_VALUE = "application/json"
		static final String ATT_CLIENT_ID_VALUE = "IDGraphContactInfoMs"
	}

	static class AzureKeyVault {
		static final String KEY_VAULT_NAME = "nprodcgautomationglblkv" //nproddtapautoglblkv
		static final String KEY_VAULT_URL = "https://${KEY_VAULT_NAME}.vault.azure.net"
		static final String TEST_AUTH_SECRET_NAME = "test-auth"
		static final String STAGE_AUTH_SECRET_NAME = "stg-auth"
		static final String TEST_REDIS_PASSWORD = "test-redis-password"
		static final String QG7_AUTH_SECRET_NAME = "idgraph-auto-test-api-auth-token"
		static final String DEV_KEY_VAULT_NAME = "dev31467eus2glblkv"
		static final String DEV_SALES_KEY_VAULT_NAME = "dev32411eu2glblsaleskv"
		static final String DEV_GRAPH_KEY_VAULT_NAME = "dev31468eu2glblgraphkv"
		static final String TEST_2_5_6_KEY_VAULT_NAME = "test31467eus2glblkv"
		static final String TEST_3_KEY_VAULT_NAME = "tst3-test31467eus2glblkv"
		static final String TEST_GRAPH_EAST_KEY_VAULT_NAME = "test31468eu2glblgraphkv"
		static final String TEST_GRAPH_WEST_KEY_VAULT_NAME = "test31468wu2glblgraphkv"
		static final String TEST_SALES_EAST_KEY_VAULT_NAME = "test32411eu2glblsaleskv"
		static final String TEST_SALES_WEST_KEY_VAULT_NAME = "test32411wu2glblsaleskv"
		static final String PERF_KEY_VAULT_NAME = "perf31467eastus2glblkv"
		static final String PERF_GRAPH_KEY_VAULT_NAME = "perf31468eu2glblgraphkv"
		static final String PERF_SALES_KEY_VAULT_NAME = "perf32411eu2glblsaleskv"
		static final String STAGE_EAST_KEY_VAULT_NAME = "stage31467eastus2glblkv"
		static final String STAGE_WEST_KEY_VAULT_NAME = "stage31467westus2glblkv"
		static final String PROD_KEY_VAULT_NAME = "prod31467eastus2glblkv"
		static final String PROD_GRAPH_EAST_KEY_VAULT_NAME = "prd31467grpheus2glblkv"
		static final String PROD_GRAPH_WEST_KEY_VAULT_NAME = "prd31467grphwus2glblkv"
		static final String PROD_GRAPH_SC_KEY_VAULT_NAME = "prd31467grphscglblkv"
		static final String PROD_GRAPH_CANARY_KEY_VAULT_NAME = "prd31467grphcnryglblkv"
		static final String PROD_SALES_EAST_KEY_VAULT_NAME = "prd31467slseus2glblkv"
		static final String PROD_SALES_WEST_KEY_VAULT_NAME = "prd31467slswus2glblkv"
		static final String PROD_SALES_SC_KEY_VAULT_NAME = "prd31467slsscglblkv"
		static final String PROD_SALES_CANARY_KEY_VAULT_NAME = "prd31467slscnryglblkv"

	}

}
