package com.att.idp.idgraphcontactinfoms.helpers

import com.att.mpsys.common.utils.*
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class CPNIDataConsolidationHelperTest extends Specification {
	
	def CPNIDataConsolidationHelper CPNIDataConsolidationHelperObj  = new CPNIDataConsolidationHelper()

    CPNIDataAddressHelper helper = Mock(CPNIDataAddressHelper)

    Logger logger = null
    HashMap resultHashSuccess = null
    HashMap resultHashError = null
    HashMap hmResult = null
    HashMap hmInput = null
    String stAppStatusMsg = null
    String stAppInfo = null

    HashMap hmEmailAddress=new HashMap()
    ArrayList alEmailAddress=new ArrayList()
    HashMap hmCPNIAddressInput= CommonUtil.hashMap
    HashMap contactInfo=new HashMap()
    HashMap validateCPNIAddressSuccess=new HashMap()

    ArrayList alCTNList=new ArrayList()
    ArrayList alPostalAddress=new ArrayList()
    HashMap hmCTNList=new HashMap()
    HashMap hmPostalAddress=new HashMap()
    ArrayList CBRCTNList =new ArrayList()
    HashMap hmCBRCTNList=new HashMap()


    def setup(){

        CPNIDataConsolidationHelperObj.helper = helper
        logger = LoggerFactory.getLogger('QueryCPNIUserContactInfo')

        System.setProperty('CommonConfigurationFilePath', './opt/att/ajsc/config/CommonConfigurationTest.xml')

        hmInput = CommonUtil.hashMap
        ArrayList alValidCPNIAddress=new ArrayList()

        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput['AccountStatus'] = '564748493'
        hmInput[CommonDefs.TRANSACTION_ID] = '564748493'
        hmInput[CommonDefs.KEY_EMAIL_ADDRESSES] = 'gb555e@gmail.com'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['AccountId'] = '2132434334'
        hmInput['NewCPNIEilibilityRule'] = 'Y'
        hmInput[CommonDefs.ACTIVATED_IND] = 'Y'
        hmInput[CommonDefs.KEY_EMAIL_ADDRESSES] = alEmailAddress
        hmInput['CBRCTNList'] = CBRCTNList

        hmCBRCTNList[CommonDefs.TRANSACTION_ID] = '3785638754'
        hmCBRCTNList[CommonDefs.TRANSACTION_NAME] = '3785638754'
        hmCBRCTNList[CommonDefs.CALLING_SYSTEM_ID] = '3785638754'
        hmCBRCTNList[CommonDefs.CONTACT_INFO] = '3785638754'
        CBRCTNList.add(hmCBRCTNList)

        hmEmailAddress[CommonDefs.EMAIL_ADDRESS] = 'gb555e@gmail.com'
        hmEmailAddress[CommonDefs.KEY_EMAIL_ESTABLISHED_DATE] = '2018312'
        hmEmailAddress[CommonDefs.EMAIL_STATUS] = 'V'
        hmEmailAddress[CommonDefs.KEY_ACCOUNT_ESTABLISHED_DATE] = '20180806'
        hmEmailAddress['CPNIEligibleEmail'] = 'Y'
        alEmailAddress.add(hmEmailAddress)

        hmCTNList[CommonDefs.CTN] = '3213123213'
        hmCTNList[CommonDefs.STATUS] = 'A'
        hmCTNList[CommonDefs.SIM_SWAP_DATE] = '12092018 20:12:10'

        hmPostalAddress[CommonDefs.KEY_FOREIGN_ADDR_IND] = 'N'
        hmPostalAddress[CommonDefs.KEY_ZIPCODE] = '1213232'
        hmPostalAddress[CommonDefs.KEY_FOREIGN_ADDR_IND] = 'N'
        hmPostalAddress[CommonDefs.KEY_ZIPCODE] = '1213232'
        hmPostalAddress[CommonDefs.KEY_BILLNAME] = 'N'
        hmPostalAddress[CommonDefs.KEY_ADDRESS2] = '1213232'
        hmPostalAddress[CommonDefs.KEY_ADDRESS3] = 'N'
        hmPostalAddress[CommonDefs.KEY_ADDRESS4] = '1213232'
        hmPostalAddress[CommonDefs.KEY_NBR_NON_ADDRESS_LINES] = 'N'
        hmPostalAddress[CommonDefs.KEY_POSTOFFICE] = '1213232'
        hmPostalAddress[CommonDefs.KEY_FOREIGN_ADDR_IND] = 'N'
        hmPostalAddress[CommonDefs.KEY_CITY] = '1213232'
        hmPostalAddress[CommonDefs.KEY_ZIPCODE] = 'N'
        hmPostalAddress[CommonDefs.KEY_ZIPPLUSFOUR] = '1213232'
        hmPostalAddress[CommonDefs.KEY_STATE] = 'N'
        hmPostalAddress[CommonDefs.KEY_COUNTRY] = '1213232'

        HashMap hmValidCPNIAddress=new HashMap()
        hmValidCPNIAddress[MPSDefs.DB_EMAIL_ADDRESS] = 'gb555e@gmail.com'
        hmValidCPNIAddress['email_est_date'] = '20180806'

        hmCPNIAddressInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmCPNIAddressInput[CommonDefs.TRANSACTION_ID] = '564748493'
        hmCPNIAddressInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmCPNIAddressInput['NewCPNIEilibilityRule'] = 'Y'
        hmCPNIAddressInput[CommonDefs.ACTIVATED_IND] = 'Y'

        contactInfo['contact_type'] = 'PEMAIL'
        contactInfo['email_address'] = 'gb555e@gmail.com'
        contactInfo['CPNIEligibleEmail'] = 'Y'
        contactInfo['account_create_date'] = '20180806'
        contactInfo['contact_status'] = 'V'
        contactInfo['email_est_date'] = '2018312'

        resultHashError=new HashMap()
        resultHashError[CErrorDefs.COMMON_APP_CATEGORY_CODE] = '101'
        resultHashError[CErrorDefs.COMMON_APP_INFO] = 'ERROR'
        resultHashSuccess= CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG)

        validateCPNIAddressSuccess= CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG)
        alValidCPNIAddress.add(hmValidCPNIAddress)
        validateCPNIAddressSuccess[CommonDefs.VALID_CPNI_ADDRESSES] = alValidCPNIAddress
        ReflectionTestUtils.setField(CPNIDataConsolidationHelperObj, 'sSimSwapAgingDays', '3')

    }


    def "test c p n i data consolidation helper null error"() {
        when:
        hmResult = CPNIDataConsolidationHelperObj.generateCPNIConsolidation(null)
        then:
        hmResult['appInfo'] == ' Input Hash is NULL / EMPTY '
    }

    def "test c p n i data consolidation helper empty error"() {
        when:
        hmResult = CPNIDataConsolidationHelperObj.generateCPNIConsolidation(CommonUtil.hashMap)
        then:
        hmResult['appInfo'] == ' Input Hash is NULL / EMPTY '
    }

    def "test c p n i data consolidation helper c s i null error"() {
        given:
        hmInput.remove(CommonDefs.CALLING_SYSTEM_ID)
        when:
        hmResult = CPNIDataConsolidationHelperObj.generateCPNIConsolidation(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'CPNI Address Helper Response  is null'
    }

    def "test c p n i data consolidation helper c s i empty error"() {
        given:
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = ''
        when:
        hmResult = CPNIDataConsolidationHelperObj.generateCPNIConsolidation(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'CPNI Address Helper Response  is null'
    }

    def "test c p n i data consolidation helper c s i email empty error"() {
        given:
        hmInput[CommonDefs.KEY_EMAIL_ADDRESSES] = CommonUtil.arrayList
        when:
        hmResult = CPNIDataConsolidationHelperObj.generateCPNIConsolidation(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "test c p n i data consolidation helper c s i email null error"() {
        given:
        hmInput[CommonDefs.KEY_EMAIL_ADDRESSES] = null
        when:
        hmResult = CPNIDataConsolidationHelperObj.generateCPNIConsolidation(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }



    def "test c p n i data consolidation helper validate c p n i address null test"() {
        given:
        helper.validateCPNIAddress(_ as HashMap) >> null
        when:
        hmResult = CPNIDataConsolidationHelperObj.generateCPNIConsolidation(hmInput)
        then:
        hmResult['appInfo'] == 'CPNI Address Helper Response  is null'
    }


    def "test c p n i data consolidation helper validate c p n i address not success test"() {
        given:
        alEmailAddress = new ArrayList()
        alEmailAddress.add(contactInfo)
        hmCPNIAddressInput['contactInfo'] = alEmailAddress
        helper.validateCPNIAddress(_ as HashMap) >> resultHashError
        when:
        hmResult = CPNIDataConsolidationHelperObj.generateCPNIConsolidation(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'ERROR'
    }


    def "test c p n i data consolidation helper validate c p n i address success test"() {
        given:
        alEmailAddress = new ArrayList()
        alEmailAddress.add(contactInfo)

        hmInput['DslDryLoopInd'] = 'N'
        hmInput['Service_NBR'] = 'Y'

        alCTNList.add(hmCTNList)
        alPostalAddress.add(hmPostalAddress)

        hmInput[CommonDefs.KEY_CTN_LIST] = alCTNList
        hmInput[CommonDefs.POSTAL_ADDRESS] = alPostalAddress
        hmInput[CommonDefs.KEY_IGNORE_POSTAL_ADDRESS_VALIDATION] = 'Y'
        hmInput[CommonDefs.KEY_PROBATIONARY_ADDRESS_IND] = 'Y'
        helper.validateCPNIAddress(_ as HashMap) >> validateCPNIAddressSuccess

        when:
        hmResult = CPNIDataConsolidationHelperObj.generateCPNIConsolidation(hmInput)

        then:
        hmResult[CommonDefs.COMMON_SUCCESS_NUM] == null
    }


    def "test c p n i data consolidation helper validate c p n i address success n test"() {
        given:
        alEmailAddress = new ArrayList()
        alEmailAddress.add(contactInfo)

        hmInput['DslDryLoopInd'] = 'N'
        hmCTNList.remove(CommonDefs.SIM_SWAP_DATE)
        alCTNList.add(hmCTNList)
        alPostalAddress.add(hmPostalAddress)
        hmInput[CommonDefs.SERVICE_NBR] = '122210'
        hmInput[CommonDefs.KEY_CTN_LIST] = alCTNList
        hmInput[CommonDefs.POSTAL_ADDRESS] = alPostalAddress
        hmInput[CommonDefs.KEY_IGNORE_POSTAL_ADDRESS_VALIDATION] = 'N'
        hmInput[CommonDefs.KEY_PROBATIONARY_ADDRESS_IND] = 'N'
        helper.validateCPNIAddress(_ as HashMap) >> validateCPNIAddressSuccess
        when:
        hmResult = CPNIDataConsolidationHelperObj.generateCPNIConsolidation(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }


    def "test c p n i data consolidation helper postal addess y n test"() {
        given:
        alEmailAddress = new ArrayList()
        alEmailAddress.add(contactInfo)

        hmInput['DslDryLoopInd'] = 'N'
        hmCTNList.remove(CommonDefs.SIM_SWAP_DATE)
        alCTNList.add(hmCTNList)
        alPostalAddress.add(hmPostalAddress)
        hmInput[CommonDefs.KEY_CTN_LIST] = alCTNList
        hmInput[CommonDefs.POSTAL_ADDRESS] = alPostalAddress
        hmInput[CommonDefs.KEY_IGNORE_POSTAL_ADDRESS_VALIDATION] = 'Y'
        hmInput[CommonDefs.KEY_PROBATIONARY_ADDRESS_IND] = 'N'
        helper.validateCPNIAddress(_ as HashMap) >> validateCPNIAddressSuccess
        when:
        hmResult = CPNIDataConsolidationHelperObj.generateCPNIConsolidation(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    // New tests for isAccountCreatedOnSimSwapDate logic
    def "test cpni data consolidation helper account created on sim swap date allows non aged ctn"() {
        given:
        alEmailAddress = new ArrayList()
        alEmailAddress.add(contactInfo)

        hmInput['DslDryLoopInd'] = 'N'
        hmInput[CommonDefs.CUSTOMER_ACTIVE_DATE] = hmCTNList[CommonDefs.SIM_SWAP_DATE]

        // Ensure CTN would be considered non-aged
        ReflectionTestUtils.setField(CPNIDataConsolidationHelperObj, 'sSimSwapAgingDays', '0')

        alCTNList = new ArrayList()
        alCTNList.add(hmCTNList)
        alPostalAddress = new ArrayList()
        alPostalAddress.add(hmPostalAddress)

        hmInput[CommonDefs.KEY_CTN_LIST] = alCTNList
        hmInput[CommonDefs.POSTAL_ADDRESS] = alPostalAddress
        hmInput[CommonDefs.KEY_IGNORE_POSTAL_ADDRESS_VALIDATION] = 'Y'
        hmInput[CommonDefs.KEY_PROBATIONARY_ADDRESS_IND] = 'Y'
        helper.validateCPNIAddress(_ as HashMap) >> validateCPNIAddressSuccess

        when:
        hmResult = CPNIDataConsolidationHelperObj.generateCPNIConsolidation(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

    def "test cpni data consolidation helper account created not on sim swap date uses aging"() {
        given:
        alEmailAddress = new ArrayList()
        alEmailAddress.add(contactInfo)

        hmInput['DslDryLoopInd'] = 'N'
        hmInput[CommonDefs.CUSTOMER_ACTIVE_DATE] = '08232018 00:00:00'
        // Sim swap aging days such that CTN is not aged
        ReflectionTestUtils.setField(CPNIDataConsolidationHelperObj, 'sSimSwapAgingDays', '2')

        alCTNList = new ArrayList()
        alCTNList.add(hmCTNList)
        alPostalAddress = new ArrayList()
        alPostalAddress.add(hmPostalAddress)

        hmInput[CommonDefs.KEY_CTN_LIST] = alCTNList
        hmInput[CommonDefs.POSTAL_ADDRESS] = alPostalAddress
        hmInput[CommonDefs.KEY_IGNORE_POSTAL_ADDRESS_VALIDATION] = 'Y'
        hmInput[CommonDefs.KEY_PROBATIONARY_ADDRESS_IND] = 'Y'
        helper.validateCPNIAddress(_ as HashMap) >> validateCPNIAddressSuccess

        when:
        hmResult = CPNIDataConsolidationHelperObj.generateCPNIConsolidation(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }

}
