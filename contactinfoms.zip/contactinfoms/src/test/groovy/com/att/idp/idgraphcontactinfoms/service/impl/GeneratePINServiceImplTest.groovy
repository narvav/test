package com.att.idp.idgraphcontactinfoms.service.impl

import com.att.idp.idgraphcontactinfoms.exceptions.InvalidInputDataException
import com.att.idp.idgraphcontactinfoms.helpers.GeneratePINHelper
import com.att.idp.idgraphcontactinfoms.resource.request.GeneratePINRequest
import com.att.idp.idgraphcontactinfoms.resource.response.GeneratePINResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import jakarta.ws.rs.core.MultivaluedMap
import spock.lang.Specification
import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap
import static org.junit.jupiter.api.Assertions.assertThrows

class GeneratePINServiceImplTest extends Specification {

	GeneratePINHelper generatePINHelperObj = Mock(GeneratePINHelper)
	GeneratePINServiceImpl generatePINServiceImplObj = new GeneratePINServiceImpl()
	private GeneratePINRequest generatePinRequest = null
	private MultivaluedMap<String, String> requestHeader = null
	private Map<String, String> headers = new HashMap<>()

	def setup() throws Exception {
		generatePINServiceImplObj.generatePINHelper = generatePINHelperObj
		generatePinRequest = new GeneratePINRequest()
		requestHeader = new MultivaluedHashMap<>(headers)

		generatePinRequest.callingSystemId = 'IDP'
		generatePinRequest.accountId = '64573738'
		generatePinRequest.returnSecurityCode = 'Y'
		generatePinRequest.identificationType = 'EMAILOTP'
		generatePinRequest.deliveryMethods = null
		generatePinRequest.agentId = 'ad4637'
		generatePinRequest.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
	}

	def "test generate pin null case"() {
		// when generate pin helper response not set
		when:
		GeneratePINResponse response = generatePINServiceImplObj.generatePIN(generatePinRequest, requestHeader)
		then:
		response.appInfo == 'Null response from generatePINHelper.generatePin'

		// when generate pin helper response has been set, app status code is null
		HashMap hmResponse = new HashMap()
		when:
		hmResponse[MPSDefs.APP_STATUS_CODE] = null
		generatePINHelperObj.generatePin(_) >> hmResponse
		response = generatePINServiceImplObj.generatePIN(generatePinRequest, requestHeader)
		then:
		response.appInfo == 'Null response from generatePINHelper.generatePin'
	}

	def "test generate pin success case"() {
		given:
		HashMap hmResponse = new HashMap()
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_16374856'
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		hmResponse['appInfo'] = 'Success'
		generatePINHelperObj.generatePin(_) >> hmResponse
		when:
		GeneratePINResponse response = generatePINServiceImplObj.generatePIN(generatePinRequest, requestHeader)
		then:
		response != null
		response.idpTraceId != null
		response.transactionName == 'GeneratePIN'
	}

	def "test generate pin when trans rollback set"() {
		given:
		HashMap hmResponse = new HashMap()
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_16374856'
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		hmResponse['isTransactionRollback'] = 'true'
		generatePINHelperObj.generatePin(_) >> hmResponse

		expect:
		InvalidInputDataException excep = assertThrows(InvalidInputDataException.class, () -> {
			generatePINServiceImplObj.generatePIN(generatePinRequest, requestHeader)
		})
	}

	def "generate pin success when trans id null"() {
		given:
		HashMap hmResponse = new HashMap()
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_16374856'
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		generatePinRequest.idpTraceId = null
		generatePINHelperObj.generatePin(_) >> hmResponse
		when:
		GeneratePINResponse response = generatePINServiceImplObj.generatePIN(generatePinRequest, requestHeader)
		then:
		hmResponse != null
		// when its calling auto generated method
		hmResponse[CommonDefs.TRANSACTION_ID] != null
	}
}