package com.att.idp.QAIntegration.Utils

import com.azure.identity.ClientSecretCredentialBuilder
import com.azure.identity.DefaultAzureCredentialBuilder
import com.azure.security.keyvault.secrets.SecretClientBuilder
import groovy.util.logging.Slf4j

@Slf4j
class AzureKeyVaultUtil {

	static Map getSecretValue() {
		def secrets = [:]
		def keyVaultUrl = ApplicationConstants.AzureKeyVault.KEY_VAULT_URL
		try {
			def tenantId = System.getenv("AZURE_TENANT_ID")
			def clientId = System.getenv("AZURE_CLIENT_ID")
			def clientSecret = System.getenv("AZURE_CLIENT_SECRET")

			def credential
			if (tenantId && clientId && clientSecret) {
				log.info("Using ClientSecretCredential to authenticate with Key Vault")
				credential = new ClientSecretCredentialBuilder()
						.tenantId(tenantId)
						.clientId(clientId)
						.clientSecret(clientSecret)
						.build()
			} else {
				log.info("Using DefaultAzureCredential to authenticate with Key Vault")
				credential = new DefaultAzureCredentialBuilder().build()
			}

			def client = new SecretClientBuilder()
					.vaultUrl(keyVaultUrl)
					.credential(credential)
					.buildClient()
			secrets['stg-auth'] = client.getSecret(ApplicationConstants.AzureKeyVault.STAGE_AUTH_SECRET_NAME).value
			secrets['test-auth'] = client.getSecret(ApplicationConstants.AzureKeyVault.TEST_AUTH_SECRET_NAME).value
			return secrets
		} catch (Exception e) {
			log.error("Failed to retrieve secrets from Azure Key Vault", e)
			throw new RuntimeException("Failed to retrieve secrets from Azure Key Vault", e)
		}
	}

}