package com.att.idp.QAIntegration.spec

import com.att.idp.QAIntegration.Base.TestBase
import com.att.idp.QAIntegration.Config.ContactInfoGlobalConfig
import com.att.idp.QAIntegration.Helpers.ContactInfoMsApiHelpers
import groovy.util.logging.Slf4j
import io.restassured.response.Response
import spock.lang.IgnoreIf
import spock.lang.Shared
import spock.lang.Tag
import spock.lang.Unroll

/**
 * QG7 Integration Test — OTP E2E Flow
 *
 * Full PIN lifecycle:  Delete(deleteAll) → Generate → Inquire → Validate
 *
 * 100 % YAML-driven — reads test cases from 'otpFlowTests' in the environment
 * YAML file.  Every parameter (accountId, identificationType, deliveryMethod,
 * smsPhoneNumber, emailAddress, deleteAll, …) comes from YAML.
 *
 * OMNI Compliance:
 * - Spec suffix: *ITSpec.groovy (testing-foundation.md E1)
 * - then: 0 * _ mandatory (HS-8)
 * - No mocks — real HTTP calls to deployed service
 */
@Slf4j
@Tag("Regression")
@Tag("OTPSuite")
@Tag("Smoke")
@Tag("IDGraphContactInfoMs")
@IgnoreIf({ !ContactInfoGlobalConfig.isTestCaseEnabled("OtpFlowITSpec") })
class OtpFlowITSpec extends TestBase {

    @Shared
    Map testData = ContactInfoGlobalConfig.getTestData()

    @Shared
    List<Map> otpFlowTests = (testData?.get("otpFlowTests") as List<Map>) ?: []

    // ═══════════════════════════════════════════════════════════════════════════
    // OTP E2E Flow — Delete(deleteAll) → Generate → Inquire → Validate
    // ═══════════════════════════════════════════════════════════════════════════

    @Unroll("OTP E2E — #tc.testCaseName")
    def "OTP E2E Flow — Delete, Generate, Inquire, Validate PIN"() {
        setup: "Prepare test data from YAML"
        setTestName(tc.testCaseName as String)
        Map data = new LinkedHashMap<>(tc as Map)
        data.put("extraHeaders", [
                "X-ATT-ClientId": data.clientId ?: "IDP",
                "idpctx-feature-svc-idgraph-simswap-newlogic": "true"
        ])

        expect: "Step 0 — Pre-cleanup: Delete all existing PINs (deleteAll=Y)"
        logStep("Pre-cleanup: deleteAll for accountId=${data.accountId} | type=${data.identificationType}")
        Response deletePreResponse = ContactInfoMsApiHelpers.deleteAllPins(data)
        deletePreResponse.statusCode() in [200, 400, 404]

        when: "Step 1 — Generate PIN"
        logStep("Generating PIN | accountId=${data.accountId} | type=${data.identificationType} | delivery=${data.deliveryMethod}")
        Response generateResponse = ContactInfoMsApiHelpers.generatePIN(data)

        then: "No mock interactions"
        0 * _

        and: "Generate PIN returns 200 with SUCCESS"
        assert generateResponse.statusCode() == 200 :
                "Generate failed: ${generateResponse.statusCode()} — ${generateResponse.body().asString().take(500)}"
        generateResponse.body().jsonPath().getString("appStatusMsg") == "SUCCESS"

        and: "Security code is present with expected length"
        String securityCode = generateResponse.body().jsonPath().getString("securityCode")
        int expectedLength = ContactInfoMsApiHelpers.getPinLength(data.identificationType as String)
        assert securityCode != null && securityCode.length() == expectedLength :
                "Expected PIN length ${expectedLength} but got ${securityCode?.length()}"

        when: "Step 2 — Inquire PIN"
        logStep("Inquiring PIN | accountId=${data.accountId}")
        Response inquireResponse = ContactInfoMsApiHelpers.inquirePIN(data)

        then: "No mock interactions"
        0 * _

        and: "Inquire PIN returns 200"
        assert inquireResponse.statusCode() == 200 :
                "Inquire failed: ${inquireResponse.statusCode()} — ${inquireResponse.body().asString().take(500)}"

        and: "Inquire response contains securityPins"
        def securityPins = inquireResponse.body().jsonPath().getList("securityPins")
        assert securityPins != null && securityPins.size() > 0 : "No securityPins found in inquire response"

        when: "Step 3 — Validate PIN"
        logStep("Validating PIN | securityCode=${securityCode}")
        Response validateResponse = ContactInfoMsApiHelpers.validatePIN(data, securityCode)

        then: "No mock interactions"
        0 * _

        and: "Validate PIN returns 200 with SUCCESS"
        assert validateResponse.statusCode() == 200 :
                "Validate failed: ${validateResponse.statusCode()} — ${validateResponse.body().asString().take(500)}"
        validateResponse.body().jsonPath().getString("appStatusMsg") == "SUCCESS"

        cleanup: "Step 4 — Final cleanup: Delete PIN"
        logStep("Cleanup: deleteAll for accountId=${data.accountId}")
        ContactInfoMsApiHelpers.deleteAllPins(data)

        where:
        tc << otpFlowTests
    }
}
