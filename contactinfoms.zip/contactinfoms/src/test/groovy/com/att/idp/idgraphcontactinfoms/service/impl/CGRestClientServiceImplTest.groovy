/*
package com.att.idp.idgraphcontactinfoms.service.impl

import com.att.idp.cgclienthelpers.integration.CGRestClient
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import org.junit.jupiter.api.extension.ExtendWith
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.junit.jupiter.MockitoExtension
import spock.lang.Specification

import static org.mockito.Mockito.when

@ExtendWith(MockitoExtension.class)
class CGRestClientServiceImplTest extends Specification {
	
	@InjectMocks
	CGRestClientServiceImpl cgRestClientServiceImplTestObj

	@Mock
	private CGRestClient cgRestClient


	def "test query c p n i account contact info success"() throws Exception {
		given:
		HashMap hmSuccessResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'SUCCESS')
		HashMap hmNotify = new HashMap<>()
		hmNotify['idp-trace-id'] = '123456:1233:1234'
		when(cgRestClient.getCGSyncCall(Mockito.any())).thenReturn(hmSuccessResponse)
		when:
		Map<String, Object> response = cgRestClientServiceImplTestObj.cgRestClient(hmNotify)
		then:
		response[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
	}


	def "test query c p n i account contact info error"() throws Exception {
		given:
		HashMap resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, 'Invalid data')
		HashMap hmNotify = new HashMap<>()
		hmNotify['idp-trace-id'] = '123456:1233:1234'
		when(cgRestClient.getCGSyncCall(Mockito.any())).thenReturn(resultHashError)
		when:
		Map<String, Object> response = cgRestClientServiceImplTestObj.cgRestClient(hmNotify)
		then:
		response[CommonDefs.COMMON_APP_STATUS_MSG] == CErrorDefs.ERR_INVALID_DATA_MSG
	}


	def "test query c p n i account contact info null response"() throws Exception {
		given:
		HashMap resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, 'Invalid data')
		HashMap hmNotify = new HashMap<>()
		hmNotify['idp-trace-id'] = '123456:1233:1234'
		when(cgRestClient.getCGSyncCall(Mockito.any())).thenReturn(null)
		when:
		Map<String, Object> response = cgRestClientServiceImplTestObj.cgRestClient(hmNotify)
		then:
		response[CommonDefs.COMMON_APP_INFO] == 'Null response from cgRestClient call'
	}
	
}
*/
