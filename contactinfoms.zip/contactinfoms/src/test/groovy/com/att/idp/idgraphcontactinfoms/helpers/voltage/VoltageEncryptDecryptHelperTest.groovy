package com.att.idp.idgraphcontactinfoms.helpers.voltage

import com.att.ajsc.common.utility.SystemPropertiesLoader
import com.att.idp.voltage.common.VoltageEfpeFormatType
import spock.lang.Specification

class VoltageEncryptDecryptHelperTest extends Specification {
	
	def voltageEncryptDecryptHelper = new VoltageEncryptDecryptHelper()

	def encryptUtil = Mock(EncryptUtil)

	def decryptUtil = Mock(DecryptUtil)

	def setup()
	{
		SystemPropertiesLoader.addSystemProperties()
		voltageEncryptDecryptHelper.encryptUtil = encryptUtil
		voltageEncryptDecryptHelper.decryptUtil = decryptUtil
	}


	def "test decrypted value"() {
		given:
		decryptUtil.getDecryptedValue(_ as String, _ as String) >> 'decryptValue'
		when:
		String decryptValue = voltageEncryptDecryptHelper.getDecryptedValue('1234569', VoltageEfpeFormatType.B64_GENERIC.toString())
		then:
		decryptValue != null
	}


	def "test encrypted value"() {
		given:
		encryptUtil.getEncryptedValue(_ as String, _ as String) >> 'encryptValue'
		when:
		String encryptValue = voltageEncryptDecryptHelper.getEncryptedValue('1234569', VoltageEfpeFormatType.B64_GENERIC.toString())
		then:
		encryptValue != null
	}
	
}
