package com.att.idp.idgraphcontactinfoms.metrics

import spock.lang.Specification
import spock.lang.Subject

class ErrorMetricHandlerSpecTest extends Specification {

    @Subject
    ErrorMetricHandler errorMetricHandler = new ErrorMetricHandler()

    def "should verify @TimedMetrics annotation on recordDBErrorMetric method"() {
        when:
        def method = ErrorMetricHandler.class.getDeclaredMethod("recordDBErrorMetric", String.class)

        then:
        method.isAnnotationPresent(com.att.idp.cd.observability.metrics.annotation.TimedMetrics)
    }

    def "shouldn't throw any error"() {
        when:
        errorMetricHandler.recordDBErrorMetric("Sample error metric")

        then:
        noExceptionThrown()
    }
}
