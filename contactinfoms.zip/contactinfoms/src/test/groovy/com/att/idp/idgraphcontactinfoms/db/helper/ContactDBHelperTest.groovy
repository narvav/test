package com.att.idp.idgraphcontactinfoms.db.helper

import com.att.idp.idgraphcontactinfoms.exceptions.MPSException
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.springframework.jdbc.core.JdbcTemplate
import spock.lang.Specification

class ContactDBHelperTest extends Specification {

	def contactDBHelperObj = new ContactDBHelper()

    def DBHelperObj = Mock(DBHelper)

    def jdbcTemplate = Mock(JdbcTemplate)

    private List<Object> objectList = new ArrayList<Object>()
    private List alQueryResponse = new ArrayList<Object>()
    private String selectStatement = null

    HashMap hmInput = new HashMap()


    def setup() {
        contactDBHelperObj.oDBHelper = DBHelperObj
        contactDBHelperObj.jdbcTemplate = jdbcTemplate

        hmInput['contact_id'] = '466'
        hmInput['member_num'] = '3253535'
        hmInput['contact_type'] = '35245'
        hmInput['subscription_id'] = '876543'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['phone_number'] = '8765439876'
        hmInput['contact_status'] = '876543'
        hmInput['contact_desc'] = '876543'
        hmInput['phone_ext'] = '87654334567'
        hmInput['phone_number_type'] = '876543'
        hmInput['validation_status'] = '876543'
        hmInput['updateEstablishedDate'] = '876543'
        hmInput['validation_status_date_flag'] = MPSDefs.YES

    }


    def "get user contact null"() throws MPSException {
        given:
        hmInput['contact_id'] = null
        hmInput['member_num'] = null
        hmInput['subscription_id'] = null
        when:
        HashMap Response = contactDBHelperObj.getUserContact(hmInput)
        then:
        Response['appInfo'] == 'contact_id and member_num and subscription_id all are null or empty in input'
    }


    def "get user contacts member num null"() throws MPSException {
        given:
        hmInput['contact_type'] = null
        when:
        HashMap Response = contactDBHelperObj.getUserContact(hmInput)
        then:
        Response['appInfo'] == 'REC_NOT_FOUND'
    }


    def "get user contact not found"() throws MPSException {
        given:
        String dateFormat = 'MMDDYYYY HH24:mi:ss'
        selectStatement = 'SELECT CONTACT_ID, MEMBER_NUM, ' +
				'CONTACT_TYPE, CONTACT_DESC, PHONE_NUMBER, PHONE_EXT, PHONE_NUMBER_TYPE, ' +
				'SUBSCRIPTION_ID, EMAIL_ADDRESS, CONTACT_STATUS, TO_CHAR(ESTABLISHED_DATE, \'' + dateFormat +
				'\') AS ESTABLISHED_DATE, TO_CHAR(CREATE_DATE, \'' + dateFormat +
				'\') AS CREATE_DATE, CREATED_BY, TO_CHAR(LAST_MODIFIED, \'' + dateFormat +
				'\') AS LAST_MODIFIED, TO_CHAR(VALIDATION_STATUS_DATE, \'' + dateFormat +
				'\') AS VALIDATION_STATUS_DATE, VALIDATION_STATUS, LAST_MODIFIED_BY ' + 'FROM contact '
        String domain_name = 'slid.dum'
        objectList.add('3253535')
        objectList.add('35245')

        HashMap<String, Object> domainList = new HashMap<String, Object>()
        domainList[MPSDefs.DB_DOMAIN_ID] = '15'
        alQueryResponse.add(domainList)
        jdbcTemplate.queryForList(_ as String, _ as List) >> alQueryResponse

        when:
        HashMap Response = contactDBHelperObj.getUserContact(hmInput)
        then:
        Response['appInfo'] == 'REC_NOT_FOUND'
    }


    def "get user contact exception"() throws MPSException {
        when:
        HashMap Response = contactDBHelperObj.getUserContact(null)
        then:
        Response['appStatusMsg'] == 'ERR_SYS_APPL'
    }


    def "add user contact null"() throws MPSException {
        given:
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = null
        hmInput['contact_id'] = null
        hmInput['member_num'] = null
        hmInput['contact_type'] = null
        when:
        HashMap Response = contactDBHelperObj.addUserContact(hmInput)
        then:
        Response['appInfo'] == 'callingSystemId/member_num/contact_id/contact_type is null or empty in input'
    }


    def "add user contacts phone number null"() throws MPSException {
        given:
        hmInput['email_address'] = 'ax1794@att.com'
        when:
        HashMap Response = contactDBHelperObj.addUserContact(hmInput)
        then:
        Response['appInfo'] == 'phone_number and email_address cannot be both null or present at the same time'
    }


    def "add user contact success"() {
        when:
        HashMap Response = contactDBHelperObj.addUserContact(hmInput)
        then:
        Response['appInfo'] == 'Number of rows inserted:= 0'
    }


    def "add user contact successnull"() {
        given:
        hmInput['contact_status'] = null
        hmInput['contact_desc'] = null
        hmInput['phone_ext'] = null
        hmInput['subscription_id'] = null
        hmInput['phone_number'] = '9324857'
        hmInput['phone_number_type'] = null
        hmInput['validation_status'] = null
        when:
        HashMap Response = contactDBHelperObj.addUserContact(hmInput)
        then:
        Response['appInfo'] == 'Number of rows inserted:= 0'
    }


    def "add user contact exception"() throws MPSException {
        when:
        HashMap Response = contactDBHelperObj.addUserContact(null)
        then:
        Response['appStatusMsg'] == 'ERR_SYS_APPL'
    }


    def "update user contact c s i null"() {
        given:
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = null
        when:
        HashMap Response = contactDBHelperObj.updateUserContact(hmInput)
        then:
        Response['appInfo'] == 'callingSystemId is null or empty in input'
    }


    def "update user contact no record"() {
        given:
        hmInput[MPSDefs.DB_VALIDATION_STATUS] = null
        when:
        HashMap Response = contactDBHelperObj.updateUserContact(hmInput)
        then:
        Response['appInfo'] == 'No Record found for given contact_id'
    }


    def "update user contact exception"() throws MPSException {
        when:
        HashMap Response = contactDBHelperObj.updateUserContact(null)
        then:
        Response['appStatusMsg'] == 'ERR_SYS_APPL'
    }


    def "should get user contact for #scenarioName"() {
        given: "Input parameters and mock setup"
        HashMap<String, Object> hmInput = new HashMap<>()
        hmInput.put("contact_id", contactId)
        hmInput.put("member_num", memberNum)
        hmInput.put("contact_type", contactType)
        hmInput.put("subscription_id", subscriptionId)

        String expectedSql = "SELECT CONTACT_ID, MEMBER_NUM, CONTACT_TYPE, CONTACT_DESC, PHONE_NUMBER, PHONE_EXT, PHONE_NUMBER_TYPE, SUBSCRIPTION_ID, EMAIL_ADDRESS, CONTACT_STATUS, TO_CHAR(ESTABLISHED_DATE, 'MMDDYYYY HH24:mi:ss') AS ESTABLISHED_DATE, TO_CHAR(CREATE_DATE, 'MMDDYYYY HH24:mi:ss') AS CREATE_DATE, CREATED_BY, TO_CHAR(LAST_MODIFIED, 'MMDDYYYY HH24:mi:ss') AS LAST_MODIFIED, TO_CHAR(VALIDATION_STATUS_DATE, 'MMDDYYYY HH24:mi:ss') AS VALIDATION_STATUS_DATE, VALIDATION_STATUS, LAST_MODIFIED_BY FROM contact  WHERE MEMBER_NUM = ? AND CONTACT_TYPE = ?"

        if (mockQuery) {
            List<Map<String, Object>> queryResult = queryResponse
            jdbcTemplate.queryForList(expectedSql, [memberNum, contactType?.toUpperCase()?.trim()]) >> queryResult
            if (!queryResult.isEmpty()) {
                DBHelperObj.getStatusNameByCode(Integer.parseInt(queryResult[0].get("VALIDATION_STATUS") as String)) >> "VALID"
            }
        }

        when: "getUserContact is called"
        HashMap<String, Object> result = contactDBHelperObj.getUserContact(hmInput)

        then: "Mock interactions"
        if (mockQuery) {
            1 * jdbcTemplate.queryForList(expectedSql, [memberNum, contactType?.toUpperCase()?.trim()]) >> queryResponse
            if (!queryResponse.isEmpty()) {
                1 * DBHelperObj.getStatusNameByCode(Integer.parseInt(queryResponse[0].get("VALIDATION_STATUS") as String)) >> "VALID"
            }
        }
        0 * _

        and: "Comprehensive assertions"
        result.get("appInfo") == expectedAppInfo
        if (expectedContacts != null) {
            List<Map<String, Object>> contacts = (List<Map<String, Object>>) result.get("contacts")
            contacts.size() == expectedContacts.size()
            contacts[0].get("contact_id") == expectedContacts[0].get("contact_id")
            contacts[0].get("validation_status_name") == "VALID"
        }

        where: "Different scenarios"
        scenarioName                | contactId | memberNum | contactType | subscriptionId | mockQuery | queryResponse                                                                 | expectedAppInfo                                               | expectedContacts
        "all required fields null"  | null      | null      | null        | null           | false     | []                                                                             | "contact_id and member_num and subscription_id all are null or empty in input" | null
        "no contacts found"         | null      | "12345"   | "EMAIL"     | null           | true      | []                                                                             | "REC_NOT_FOUND"                                               | null
        "contact found"             | null      | "12345"   | "EMAIL"     | null           | true      | [[CONTACT_ID: "789", MEMBER_NUM: "12345", CONTACT_TYPE: "EMAIL", VALIDATION_STATUS: "1"]] | "0" | [[contact_id: "789"]]

    }


    def "should handle exception when input is null"() {
        given: "Null input"
        HashMap<String, Object> hmInput = null

        when: "getUserContact is called"
        HashMap<String, Object> result = contactDBHelperObj.getUserContact(hmInput)

        then: "No mock interactions"
        0 * _

        and: "Exception result"
        result.get("appStatusMsg") == "ERR_SYS_APPL"
    }

}
