package com.att.idp.idgraphcontactinfoms.utils


import spock.lang.Specification

import java.sql.Date

class DateUtilTest extends Specification {


	def "test string to sql date success"() {
		given:
		String dateString = '09/15/2022'
		when:
		Date result = DateUtil.stringToSqlDate(dateString)
		then:
		result != null
	}


	def "test string to sql date failure"() {
		// when the given date format is not parseable, parse exception is thrown
		when:
		String dateString = '15092022'
		then:
		DateUtil.stringToSqlDate(dateString) == null
	}

}
