package com.att.idp.idgraphcontactinfoms.integration.Async

import com.att.idp.cgclienthelpers.integration.CGRestClient
import com.att.idp.idgraphcontactinfoms.helpers.CGHelper
import com.att.mpsys.common.helpers.SoapHelper
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class CallDestinationAsyncTest extends Specification {

	def callDestinationAsyncObj = new CallDestinationAsync()

	def soapHelper = Mock(SoapHelper)

	def cgRestClient = Mock(CGRestClient)

	def cgHelper = Spy(CGHelper)

	HashMap hmInput = null


	def idGraphAzureAppConfig = Mock(com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig)

	def setup() {
		callDestinationAsyncObj.soapHelper = soapHelper
		ReflectionTestUtils.setField(cgHelper, 'cgRestClient', cgRestClient)
		callDestinationAsyncObj.cgHelper = cgHelper
		callDestinationAsyncObj.idGraphAzureAppConfig = idGraphAzureAppConfig // Inject the mock
		hmInput = new HashMap()
		hmInput['topics'] = 'ntg'
	}

	def "call destination async test"() throws Exception {
		expect:
		callDestinationAsyncObj.callDestinationAsync(hmInput)
	}


	def "call destination asyncdestination c s i test"() throws Exception {
		given:
		hmInput['CallingDestination'] = 'CSI'
		hmInput['eventname'] = 'QueryCSIInquireAccountProfile'

		cgRestClient.getCGSyncCall(_) >> hmInput
		expect:
		callDestinationAsyncObj.callDestinationAsync(hmInput)
	}


	def "call destination asyncdestination c s i esle test"() throws Exception {
		given:
		hmInput['CallingDestination'] = 'CSI'
		hmInput['eventname'] = 'else'

		cgRestClient.getCGSyncCall(_) >> hmInput
		expect:
		callDestinationAsyncObj.callDestinationAsync(hmInput)
	}


	def "call destination asyncdestination b d s test"() throws Exception {
		given:
		hmInput['CallingDestination'] = 'BDS'

		soapHelper.callBDS(_) >> hmInput
		expect:
		callDestinationAsyncObj.callDestinationAsync(hmInput)
	}


	def "call destination async else test"() throws Exception {
		given:
		hmInput['CallingDestination'] = 'ak_pak_karepak'
		expect:
		callDestinationAsyncObj.callDestinationAsync(hmInput)
	}
}
