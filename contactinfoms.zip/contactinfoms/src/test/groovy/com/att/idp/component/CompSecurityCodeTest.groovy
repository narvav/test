package com.att.idp.component

import com.att.idp.idgraphcontactinfoms.db.model.Tsecurityaccount
import com.att.idp.idgraphcontactinfoms.db.model.Tsecuritycode
import com.att.idp.idgraphcontactinfoms.db.model.TsecuritycodeId
import com.att.idp.idgraphcontactinfoms.resource.request.GeneratePINRequest
import com.att.idp.idgraphcontactinfoms.utils.JsonService
import com.att.idp.dpl.profile.bsse.customerv4.CustomerV4Response
import com.att.idp.dpl.profile.bsse.customerv4.Individual
import com.att.idp.dpl.profile.bsse.customerv4.Account
import com.att.idp.core.exception.ServiceException
import com.att.idp.idgraphcontactinfoms.message.ErrorMessages
import com.att.idp.cgclienthelpers.utils.CGUtilHelper
import com.fasterxml.jackson.databind.ObjectMapper
import org.hamcrest.CoreMatchers

import java.security.MessageDigest
import java.time.LocalDate

import org.spockframework.spring.SpringBean

class CompSecurityCodeTest extends CompBaseTest {

	@SpringBean
	CGUtilHelper cgUtilHelper = Mock()

	def getHeaders() {
		Map<String, String> headers = new HashMap<>()
		headers.put("Content-Type", "application/json")
		headers.put("idp-trace-id", "ed44414d155475a6:ed44414d155475a6:0:0")
		headers.put("X-ATT-ClientId", "IDP")
		return headers
	}

	// ==================== Generate PIN Tests ====================

	def "generate pin success with security code returned"() {
		given:
		String uri = "/pin/generate"
		Map<String, String> headers = getHeaders()
		headers.put("X-ATT-ClientId", "ERICSSON")
		featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ONLYORACLE"
		featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled") >> false
		securityCodeRepository.getSecurityCodeDataQuery(_ as String, _ as String) >> populateSecurityCodeList()
		securityCodeRepository.deleteByIdIdentificationTypeAndIdAccountId(_ as String, _ as String) >> 0
		securityAccountDataRepository.getSecurityAccountData(_ as String, _ as String) >> getSecurityAccountList()
		securityAccountDataRepository.getCumulativeFailureCount(_ as String, _ as String) >> 0
		securityAccountDataRepository.updateSecurityAccount(_ as HashMap, _ as Boolean, _ as Long) >> 1
		securityCodeRepository.setSecurityCode(_ as HashMap) >> 1
		muleSoftRestClient.postCCMuleSyncCall(_ as HashMap, null, _ as String) >> getMockMuleSoftResult()

		expect:
		givenBaseSpec()
				.body(mockGeneratePINRequest())
				.when().headers(headers)
				.post(uri)
				.then()
				.statusCode(200).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
				.body("appStatusCode", CoreMatchers.equalTo("0"))
				.body("securityCode", CoreMatchers.notNullValue())
				.body("securityCodeExpires", CoreMatchers.notNullValue())
				.body("idp-trace-id", CoreMatchers.equalTo("ed44414d155475a6:ed44414d155475a6:0:0"))
	}

	def "generate pin validation error - missing identification type"() {
		given:
		String uri = "/pin/generate"
		Map<String, String> headers = getHeaders()
		headers.put("X-ATT-ClientId", "ERICSSON")
		GeneratePINRequest request = mockGeneratePINRequest()
		request.identificationType = ""

		expect:
		givenBaseSpec()
				.body(request)
				.when().headers(headers)
				.post(uri)
				.then()
				.statusCode(400).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
				.body("appStatusCode", CoreMatchers.equalTo("100"))
				.body("appInfo", CoreMatchers.notNullValue())
				.body("idp-trace-id", CoreMatchers.equalTo("ed44414d155475a6:ed44414d155475a6:0:0"))
	}

	def "generate pin validation error - missing accountId"() {
		given:
		String uri = "/pin/generate"
		Map<String, String> headers = getHeaders()
		headers.put("X-ATT-ClientId", "ERICSSON")
		GeneratePINRequest request = mockGeneratePINRequest()
		request.accountId = ""

		expect:
		givenBaseSpec()
				.body(request)
				.when().headers(headers)
				.post(uri)
				.then()
				.statusCode(400).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
				.body("appStatusCode", CoreMatchers.equalTo("100"))
				.body("appInfo", CoreMatchers.notNullValue())
				.body("idp-trace-id", CoreMatchers.equalTo("ed44414d155475a6:ed44414d155475a6:0:0"))
	}

	// ==================== Validate PIN Tests ====================

	def "validate pin validation error - missing security code"() {
		given:
		String uri = "/pin/validate"
		String req = """{
            "transactionName" : "ValidatePIN",
            "callingSystemId" : "OPUS",
            "accountId" : "167856783345",
            "identificationType" : "EMAILPIN",
            "sourceIPAddress" : "12.12.2.34",
            "deletePINOnSuccess" : "CURRENT",
            "agentId": "ad4567"
        }"""

		when:
		def response = givenBaseSpec().headers(getHeaders()).body(req).post(uri)

		then:
		response.statusCode() == 400
		response.then()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
				.body("appStatusCode", CoreMatchers.equalTo("100"))
				.body("appInfo", CoreMatchers.notNullValue())
				.body("idp-trace-id", CoreMatchers.equalTo("ed44414d155475a6:ed44414d155475a6:0:0"))
	}

	def "validate pin validation error - missing transactionName"() {
		given:
		String uri = "/pin/validate"
		String req = """{
            "callingSystemId" : "OPUS",
            "accountId" : "167856783345",
            "identificationType" : "EMAILPIN",
            "securityCode" : "710574",
            "sourceIPAddress" : "12.12.2.34",
            "deletePINOnSuccess" : "CURRENT",
            "agentId": "ad4567"
        }"""

		when:
		def response = givenBaseSpec().headers(getHeaders()).body(req).post(uri)

		then:
		response.statusCode() == 400
		response.then()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
				.body("appStatusCode", CoreMatchers.equalTo("100"))
				.body("appInfo", CoreMatchers.notNullValue())
				.body("idp-trace-id", CoreMatchers.equalTo("ed44414d155475a6:ed44414d155475a6:0:0"))
	}

	// ==================== Delete PIN Tests ====================

	def "delete pin success"() {
		given:
		String uri = "/pin/delete"
		featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ONLYORACLE"
		securityCodeRepository.deleteByIdIdentificationTypeAndIdAccountId(_ as String, _ as String) >> 1
		String req = """{
            "transactionName" : "DeletePIN",
            "callingSystemId" : "IDPSALES",
            "accountId" : "12345677111",
            "identificationType" : "ENCPIN",
            "securityCode" : "231832",
            "deleteAll" : "Y",
            "reasonCode" : "REGISTERED"
        }"""

		when:
		def response = givenBaseSpec().headers(getHeaders()).body(req).post(uri)

		then:
		response.statusCode() == 200
		response.then()
				.body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
				.body("appStatusCode", CoreMatchers.equalTo("0"))
				.body("idp-trace-id", CoreMatchers.equalTo("ed44414d155475a6:ed44414d155475a6:0:0"))
	}

	def "delete pin validation error - missing deleteAll"() {
		given:
		String uri = "/pin/delete"
		String req = """{
            "transactionName" : "DeletePIN",
            "callingSystemId" : "IDPSALES",
            "accountId" : "12345677111",
            "identificationType" : "ENCPIN",
            "securityCode" : "231832",
            "reasonCode" : "REGISTERED",
            "sourceIPAddress" : "12.12.2.34"
        }"""

		when:
		def response = givenBaseSpec().headers(getHeaders()).body(req).post(uri)

		then:
		response.statusCode() == 400
		response.then()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
				.body("appStatusCode", CoreMatchers.equalTo("100"))
				.body("appInfo", CoreMatchers.notNullValue())
				.body("idp-trace-id", CoreMatchers.equalTo("ed44414d155475a6:ed44414d155475a6:0:0"))
	}

	// ==================== CPNI Account Tests ====================

	def "query CPNI account contact info success"() {
		given:
		String uri = "/cpniContactInfo/account"
		Map<String, String> headers = getHeaders()
		featureManager.isEnabled("svc-idgraph-contactinfo-cpni-uverse-callcg") >> true
		ObjectMapper mapper = new ObjectMapper()
		HashMap<String, String> hmSyncResp = mapper.readValue(CGResponse(), HashMap.class)
		cgRestClient.getCGSyncCall(_ as HashMap) >> hmSyncResp
		String req = """{
			"accountInvariantId" : "105138279",
			"accountType" : "TITAN",
			"returnCBRCTNs" : "Y"
		}"""

		when:
		def response = givenBaseSpec().headers(headers).body(req).post(uri)

		then:
		response.statusCode() == 200
		response.then()
				.body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
				.body("appStatusCode", CoreMatchers.equalTo("0"))
				.body("idp-trace-id", CoreMatchers.notNullValue())
	}

	def "query CPNI account contact info validation error - missing accountType"() {
		given:
		String uri = "/cpniContactInfo/account"
		String req = """{
			"accountInvariantId" : "105138279",
			"returnCBRCTNs" : "Y"
		}"""

		when:
		def response = givenBaseSpec().headers(getHeaders()).body(req).post(uri)

		then:
		response.statusCode() == 400
		response.then()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
				.body("appStatusCode", CoreMatchers.equalTo("100"))
				.body("appInfo", CoreMatchers.notNullValue())
				.body("idp-trace-id", CoreMatchers.notNullValue())
	}

	// ==================== CPNI User Tests ====================

	def "query CPNI user contact info validation error - invalid callingSystemId"() {
		given:
		String uri = "/cpniContactInfo/user"
		Map<String, String> headers = getHeaders()
		headers.put("X-ATT-ClientId", "INVALID_CSI")
		String req = """{
            "guid": "1020425284",
            "returnCBRCTNs": "Y"
        }"""

		when:
		def response = givenBaseSpec().headers(headers).body(req).post(uri)

		then:
		response.statusCode() == 400
		response.then()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
				.body("appStatusCode", CoreMatchers.equalTo("100"))
				.body("appInfo", CoreMatchers.notNullValue())
				.body("idp-trace-id", CoreMatchers.notNullValue())
	}

	// ==================== Validate PIN Tests (V4 SIM check) ====================

	def "validate pin V4 SIM check - CG API throws ServiceException - returns error"() {
		given:
		String uri = "/pin/validate"
		String codeHash = sha1Base64('710574')

		featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ONLYORACLE"
		featureManager.isEnabled("svc-idgraph-validatepin-cg-v4-enabled") >> true

		securityCodeRepository.getSecurityCodeDataQuery(_ as String, _ as String) >> populateSecurityCodeListForSIMCheck(codeHash)
		securityCodeRepository.getDbCurrentDate() >> new Date()

		cgApiRestClient.getCustomerDetailsByAccountId(_) >> { throw new ServiceException(ErrorMessages.MS_MPSYS_BE_100, 'CG V4 unavailable') }

		String req = """{
            "transactionName" : "ValidatePIN",
            "callingSystemId" : "IDP",
            "accountId" : "9899545",
            "identificationType" : "IDSEMOB",
            "securityCode" : "710574",
            "deletePINOnSuccess" : "CURRENT"
        }"""

		when:
		def response = givenBaseSpec().headers(getHeaders()).body(req).post(uri)

		then:
		response.statusCode() == 400
		response.then()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
				.body("appStatusCode", CoreMatchers.equalTo("100"))
				.body("idp-trace-id", CoreMatchers.equalTo("ed44414d155475a6:ed44414d155475a6:0:0"))
	}

	def "validate pin V4 SIM check - SIM date matches account date - returns success"() {
		given:
		String uri = "/pin/validate"
		String codeHash = sha1Base64('710574')
		String sameBsseDate = '2020-01-01T00:00:00.000+0000'

		featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource") >> "ONLYORACLE"
		featureManager.isEnabled("svc-idgraph-validatepin-cg-v4-enabled") >> true

		securityCodeRepository.getSecurityCodeDataQuery(_ as String, _ as String) >> populateSecurityCodeListForSIMCheck(codeHash)
		securityCodeRepository.getDbCurrentDate() >> new Date()

		CustomerV4Response mockResponse = Mock(CustomerV4Response)
		Individual mockIndividual = Mock(Individual)
		Account mockAccount = Mock(Account)
		mockAccount.getCreatedOn() >> sameBsseDate
		mockAccount.getTargetSOR() >> 'CG'
		mockAccount.getSubscribers() >> []
		mockIndividual.getAccounts() >> [mockAccount]
		mockResponse.getIndividual() >> mockIndividual

		cgApiRestClient.getCustomerDetailsByAccountId(_) >> mockResponse
		cgUtilHelper.extractSubscriberDetailsFromV4Response(_) >> ['9899545': ['simSwapDateValue': sameBsseDate]]

		securityCodeRepository.updateBySecurityCodeId(_ as String, _ as String, _ as String, _ as String) >> 1

		String req = """{
            "transactionName" : "ValidatePIN",
            "callingSystemId" : "IDP",
            "accountId" : "9899545",
            "identificationType" : "IDSEMOB",
            "securityCode" : "710574",
            "deletePINOnSuccess" : "CURRENT"
        }"""

		when:
		def response = givenBaseSpec().headers(getHeaders()).body(req).post(uri)

		then:
		response.statusCode() == 200
		response.then()
				.body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
				.body("appStatusCode", CoreMatchers.equalTo("0"))
				.body("idp-trace-id", CoreMatchers.equalTo("ed44414d155475a6:ed44414d155475a6:0:0"))
	}

	// ==================== Helper Methods ====================

	private GeneratePINRequest mockGeneratePINRequest() {
		String requestStr = "{\"accountId\":\"2543916110\"," +
				"\"identificationType\":\"GENERICOTP\"," +
				"\"agentId\":\"ad4567\"," +
				"\"returnSecurityCode\":\"Y\"," +
				"\"browserLanguage\":\"en\"," +
				"\"deliveryMethods\":{" +
				"\"email\":{\"emailaddress\":\"test@att.com\"" +
				"}}}"
		return JsonService.convertToObject(requestStr, GeneratePINRequest.class)
	}

	private List<Tsecuritycode> populateSecurityCodeList() {
		List<Tsecuritycode> securityCodeList = new ArrayList<>()
		Tsecuritycode securityCode = new Tsecuritycode()
		TsecuritycodeId secCode2 = new TsecuritycodeId()
		secCode2.accountId = '2543916110'
		securityCode.id = secCode2
		securityCode.securityCodeStatus = 'ACTIVE'
		securityCode.securityCodeExpires = java.sql.Date.valueOf(LocalDate.now())
		securityCode.createDate = java.sql.Date.valueOf(LocalDate.now())
		securityCode.lastModified = java.sql.Date.valueOf(LocalDate.now())
		securityCode.sorInvariantId = null
		securityCode.passcodeVenc = '1234567'
		securityCode.verificationFailureCount = 10
		securityCode.deliveryDetail = '2146759270'
		securityCodeList.add(securityCode)
		return securityCodeList
	}

	private List<Tsecurityaccount> getSecurityAccountList() {
		List<Tsecurityaccount> securityList = new ArrayList<>()
		Tsecurityaccount securityAccount = new Tsecurityaccount()
		securityAccount.accountEntryExpires = java.sql.Date.valueOf(LocalDate.now())
		securityAccount.lastModified = java.sql.Date.valueOf(LocalDate.now())
		securityAccount.createDate = java.sql.Date.valueOf(LocalDate.now())
		securityAccount.lastModifiedBy = "ERICSSON"
		securityAccount.cumulativeFailureCount = 0
		securityList.add(securityAccount)
		return securityList
	}

	private HashMap getMockMuleSoftResult() {
		HashMap<String, Object> mockResult = new HashMap<>()
		mockResult.put("appCategoryCode", "0")
		mockResult.put("appStatusMsg ", "SUCCESS")
		mockResult.put("traceId", "676d86c553c8c866:676d86c553c8c866:0:1")
		mockResult.put("appStatusCode", "0")
		mockResult.put("COMMON_APP_STATUS_CODE", "0")
		mockResult.put("APP_STATUS_CODE", "0")
		mockResult.put("COMMON_APP_INFO", "SUCCESS")
		return mockResult
	}

	private List<Tsecuritycode> populateSecurityCodeListForSIMCheck(String securityCodeHash) {
		List<Tsecuritycode> securityCodeList = new ArrayList<>()
		Tsecuritycode securityCode = new Tsecuritycode()
		TsecuritycodeId secCodeId = new TsecuritycodeId()
		secCodeId.accountId = '9899545'
		secCodeId.identificationType = 'IDSEMOB'
		secCodeId.securityCode = securityCodeHash
		securityCode.id = secCodeId
		securityCode.securityCodeStatus = 'ACTIVE'
		securityCode.securityCodeExpires = java.sql.Date.valueOf(LocalDate.now().plusDays(1))
		securityCode.createDate = java.sql.Date.valueOf(LocalDate.now())
		securityCode.lastModified = java.sql.Date.valueOf(LocalDate.now())
		securityCode.verificationFailureCount = 0
		securityCode.deliveryMethod = 'S'
		securityCode.deliveryDetail = '9899545'
		securityCodeList.add(securityCode)
		return securityCodeList
	}

	private String sha1Base64(String input) {
		MessageDigest md = MessageDigest.getInstance('SHA-1')
		md.reset()
		md.update(input.toUpperCase().getBytes())
		byte[] digestBytes = md.digest()
		return jakarta.xml.bind.DatatypeConverter.printBase64Binary(digestBytes)
	}

	String CGResponse() {
		return "{\n" +
				"  \"traceId\": null,\n" +
				"  \"appStatusMsg\": \"SUCCESS\",\n" +
				"  \"appCategoryCode\": \"0\",\n " +
				"  \"appInfo\": \"SUCCESS\",\n" +
				"  \"accounts\": {\n" +
				"    \"id\": 658028253,\n" +
				"    \"firstName\": \"KAKASHI\",\n" +
				"    \"lastName\": \"HATAKE\",\n" +
				"    \"subscribersCount\": 0,\n" +
				"    \"systemOfRecord\": \"LS-CRM-DB\",\n" +
				"    \"secondaryPhoneNumberAttIndicator\": false,\n" +
				"    \"state\": \"P\",\n" +
				"    \"isEmployee\": \"N\",\n" +
				"    \"emailStatusUpdateDate\": \"2025-08-08 12:15:59\",\n" +
				"    \"languagePreference\": \"English\",\n" +
				"    \"convergedCustomerOption\": 0,\n" +
				"    \"firstnetIndicator\": false,\n" +
				"    \"emailStatus\": 2,\n" +
				"    \"serviceDiscount\": 0,\n" +
				"    \"convergedCustomerOptionDisplay\": \"none\",\n" +
				"    \"hboMaxEntitlementIndicator\": false,\n" +
				"    \"serviceType\": \"UVERSE\",\n" +
				"    \"accountType\": \"Consumer\",\n" +
				"    \"accountSubType\": \"Consumer\",\n" +
				"    \"createdOn\": \"2025-09-22 14:16:17\",\n" +
				"    \"phoneNumberAttIndicator\": false,\n" +
				"    \"customerInTreatment\": false,\n" +
				"    \"profileType\": \"BILLINGACCOUNT\",\n" +
				"    \"emailEstablishDate\": \"2025-10-16 07:27:46\",\n" +
				"    \"contact\": {\n" +
				"      \"email\": {\n" +
				"        \"emailAddress\": \"dc940s@att.com\",\n" +
				"        \"emailStatusUpdateDate\": \"2025-08-08 12:15:59\",\n" +
				"        \"emailStatus\": 2,\n" +
				"        \"isEmailRTV\": \"Y\"\n" +
				"      },\n" +
				"      \"cbrInfo\": {\n" +
				"        \"phoneNumber\": \"3343353030\",\n" +
				"        \"subContactType\": \"primary\",\n" +
				"        \"contactType\": \"other\",\n" +
				"        \"isATTNumber\": false,\n" +
				"        \"phoneModifiedDate\": \"2025-08-08 12:15:59\",\n" +
				"        \"phoneType\": \"HOME_PHONE\"\n" +
				"      },\n" +
				"      \"address\": {\n" +
				"        \"preferred\": true,\n" +
				"        \"country\": \"USA\",\n" +
				"        \"city\": \"ORLANDO\",\n" +
				"        \"county\": \"ORANGE\",\n" +
				"        \"contactType\": \"Billing\",\n" +
				"        \"postCode\": \"32819-7553\",\n" +
				"        \"street1\": \"5094 ERNST CT\",\n" +
				"        \"state\": \"FL\"\n" +
				"      }\n" +
				"    }\n" +
				"  },\n" +
				"  \"appStatusCode\": \"0\"\n" +
				"}"
	}
}
