import com.att.idp.core.exception.ServiceException;
import com.att.idp.idgraphcontactinfoms.integration.LscrmGetAuthInfoClient;
import com.att.idp.idgraphcontactinfoms.message.ErrorMessages;
import com.att.idp.soap.config.SOAPClientConfigurer
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.sbc.cc.clarify.api.mps.message.GetAuthInfoResponse;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.soap.client.SoapFaultClientException;
import org.springframework.ws.soap.SoapFaultDetail;
import org.springframework.ws.soap.SoapFaultDetailElement;
import org.springframework.ws.soap.security.wss4j2.Wss4jSecurityInterceptor;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;
import spock.lang.Specification;
import spock.lang.Unroll;
import javax.xml.transform.dom.DOMResult;

class LscrmGetAuthInfoClientTest extends Specification {

    HttpComponentsMessageSender httpComponentsMessageSender;
    SOAPClientConfigurer soapClientConfigurer;
    WebServiceTemplate webServiceTemplate;
    LscrmGetAuthInfoClient<Object> client;

    void setup() {
        httpComponentsMessageSender = Mock(HttpComponentsMessageSender);
        soapClientConfigurer = Mock(SOAPClientConfigurer);
        webServiceTemplate = Mock(WebServiceTemplate);
        client = new LscrmGetAuthInfoClient<>();
        client.httpComponentsMessageSender = httpComponentsMessageSender;
        client.soapClientConfigurer = soapClientConfigurer;
        client.setWebServiceTemplate(webServiceTemplate);
        client.lscrmSecurityHeaderUser = "testUser";
        client.lscrmSecurityHeaderPwd = "encryptedPwd";
    }

    @Unroll
    def "should invokeAPI successfully for #scenarioName"() {
        given: "A valid request and successful SOAP response"
        Object objRequest = new Object();
        GetAuthInfoResponse response = Mock(GetAuthInfoResponse);
        Map<String, Object> expectedMap = [key: "value"];
        webServiceTemplate.getInterceptors() >> ([] as ClientInterceptor[]);
        webServiceTemplate.marshalSendAndReceive(objRequest) >> response;
        0 * CommonUtil.getAESDecryption("encryptedPwd") >> "decryptedPwd";
        0 * CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, "SUCCESS") >> [status: "SUCCESS"];
        0 * client.getWebServiceTemplate() >> webServiceTemplate;

        when: "invokeAPI is called"
        Map<String, Object> result = client.invokeAPI(objRequest);

        then: "SOAP response is mapped and returned"
        result['appStatusMsg'] != null

        where:
        scenarioName | request
        "valid request" | new Object()
    }



    def "should throw ServiceException for SocketTimeoutException"() {
        given: "A request that triggers SocketTimeoutException"
        Object request = new Object();
        webServiceTemplate.getInterceptors() >> ([] as ClientInterceptor[]);
        webServiceTemplate.marshalSendAndReceive(request) >> { throw new SocketTimeoutException("timeout") };
        0 * CommonUtil.getAESDecryption("encryptedPwd") >> "decryptedPwd";
        0 * client.getWebServiceTemplate() >> webServiceTemplate;

        when: "invokeAPI is called"
        client.invokeAPI(request);

        then: "ServiceException is thrown"
        ServiceException ex = thrown();
        ex.message == '{userMessage=null, resourceId=MS_MPSYS_BE_602, resourceMsg=ERR_SYS_APPL : {0}, errorId=MS_MPSYS_BE_602, httpCode=500}'

    }

    def "should throw ServiceException for general Exception"() {
        given: "A request that triggers a general Exception"
        Object request = new Object();
        webServiceTemplate.getInterceptors() >> ([] as ClientInterceptor[]);
        webServiceTemplate.marshalSendAndReceive(request) >> { throw new RuntimeException("general error") };
        0 * CommonUtil.getAESDecryption("encryptedPwd") >> "decryptedPwd";
        0 * client.getWebServiceTemplate() >> webServiceTemplate;

        when: "invokeAPI is called"
        client.invokeAPI(request);

        then: "ServiceException is thrown"
        ServiceException ex = thrown();
        ex.message== '{userMessage=null, resourceId=MS_MPSYS_BE_602, resourceMsg=ERR_SYS_APPL : {0}, errorId=MS_MPSYS_BE_602, httpCode=500}'

    }

    @Unroll
    def "should handle SOAPFault with valid detail for #scenarioName"() {
        given: "A SoapFaultClientException with valid detail"
        SoapFaultClientException soapFault = Mock(SoapFaultClientException);
        SoapFaultDetail soapFaultDetail = Mock(SoapFaultDetail);
        SoapFaultDetailElement detailElement = Mock(SoapFaultDetailElement);
        DOMResult domResult = Mock(DOMResult);
        org.w3c.dom.Node node = Mock(org.w3c.dom.Node);
        org.w3c.dom.Node firstChild = Mock(org.w3c.dom.Node);
        org.w3c.dom.Node nextSibling = Mock(org.w3c.dom.Node);
        soapFault.getSoapFault() >> Mock(org.springframework.ws.soap.SoapFault) {
            getFaultDetail() >> soapFaultDetail
        };
        soapFaultDetail.getDetailEntries() >> [detailElement].iterator();
        detailElement.getResult() >> domResult;
        domResult.getNode() >> node;
        node.getFirstChild() >> firstChild;
        firstChild.getFirstChild() >> Mock(org.w3c.dom.Node) {
            getTextContent() >> "message"
        };
        firstChild.getNextSibling() >> Mock(org.w3c.dom.Node) {
            getTextContent() >> "code"
        };

        when: "handleSOAPFault is called"
        Map<String, Object> result = client.handleSOAPFault(soapFault);

        then: "Result contains expected keys"
        result.get(CErrorDefs.ERR_EXTERNAL_DATA_NUM) == null

        where:
        scenarioName | _
        "valid detail" | null
    }

    @Unroll
    def "should throw ServiceException with MS_MPSYS_BE_606 for read timeout for #scenarioName"() {
        given: "A request that triggers a read timeout exception"
        Object request = new Object()
        WebServiceTemplate webServiceTemplate = Mock(WebServiceTemplate)
        LscrmGetAuthInfoClient<Object> client = new LscrmGetAuthInfoClient<>()
        client.setWebServiceTemplate(webServiceTemplate)
        client.lscrmSecurityHeaderUser = "testUser"
        client.lscrmSecurityHeaderPwd = "encryptedPwd"
        client.httpComponentsMessageSender = Mock(HttpComponentsMessageSender)
        client.soapClientConfigurer = Mock(SOAPClientConfigurer)

        webServiceTemplate.getInterceptors() >> ([] as ClientInterceptor[])
        webServiceTemplate.marshalSendAndReceive(request) >> { throw new RuntimeException("Read timed out") }
        0 * CommonUtil.getAESDecryption("encryptedPwd") >> "decryptedPwd"
        0 * client.getWebServiceTemplate() >> webServiceTemplate

        when: "invokeAPI is called"
        client.invokeAPI(request)

        then: "ServiceException is thrown with correct error message"
        ServiceException ex = thrown()
        ex.message == '{userMessage=null, resourceId=MS_MPSYS_BE_606, resourceMsg=ERR_TRAN_TIME_OUT : {0}, errorId=MS_MPSYS_BE_606, httpCode=500}'

        where:
        scenarioName | _
        "read timeout" | null
    }

    def "should throw ServiceException when SOAPFault detail is missing"() {
        given: "A SoapFaultClientException with missing detail"
        SoapFaultClientException soapFault = Mock(SoapFaultClientException);
        soapFault.getSoapFault() >> Mock(org.springframework.ws.soap.SoapFault) {
            getFaultDetail() >> null
        };

        when: "handleSOAPFault is called"
        client.handleSOAPFault(soapFault);

        then: "ServiceException is thrown"
        ServiceException ex = thrown();
        ex.message == '{userMessage=null, resourceId=MS_MPSYS_BE_602, resourceMsg=ERR_SYS_APPL : {0}, errorId=MS_MPSYS_BE_602, httpCode=500}'

    }

    def "should throw ServiceException when SOAPFault detail entries are empty"() {
        given: "A SoapFaultClientException with empty detail entries"
        SoapFaultClientException soapFault = Mock(SoapFaultClientException);
        SoapFaultDetail soapFaultDetail = Mock(SoapFaultDetail);
        soapFault.getSoapFault() >> Mock(org.springframework.ws.soap.SoapFault) {
            getFaultDetail() >> soapFaultDetail
        };
        soapFaultDetail.getDetailEntries() >> [].iterator();

        when: "handleSOAPFault is called"
        client.handleSOAPFault(soapFault);

        then: "ServiceException is thrown"
        ServiceException ex = thrown();
        ex.message == '{userMessage=null, resourceId=MS_MPSYS_BE_602, resourceMsg=ERR_SYS_APPL : {0}, errorId=MS_MPSYS_BE_602, httpCode=500}'

    }

    def "should throw ServiceException when SOAPFault detail message or code is missing"() {
        given: "A SoapFaultClientException with missing message/code"
        SoapFaultClientException soapFault = Mock(SoapFaultClientException);
        SoapFaultDetail soapFaultDetail = Mock(SoapFaultDetail);
        SoapFaultDetailElement detailElement = Mock(SoapFaultDetailElement);
        DOMResult domResult = Mock(DOMResult);
        org.w3c.dom.Node node = Mock(org.w3c.dom.Node);
        org.w3c.dom.Node firstChild = Mock(org.w3c.dom.Node);
        soapFault.getSoapFault() >> Mock(org.springframework.ws.soap.SoapFault) {
            getFaultDetail() >> soapFaultDetail
        };
        soapFaultDetail.getDetailEntries() >> [detailElement].iterator();
        detailElement.getResult() >> domResult;
        domResult.getNode() >> node;
        node.getFirstChild() >> firstChild;
        firstChild.getFirstChild() >> Mock(org.w3c.dom.Node) {
            getTextContent() >> ""
        };
        firstChild.getNextSibling() >> Mock(org.w3c.dom.Node) {
            getTextContent() >> ""
        };

        when: "handleSOAPFault is called"
        client.handleSOAPFault(soapFault);

        then: "ServiceException is thrown"
        ServiceException ex = thrown();
        ex.message == '{userMessage=null, resourceId=MS_MPSYS_BE_602, resourceMsg=ERR_SYS_APPL : {0}, errorId=MS_MPSYS_BE_602, httpCode=500}'

    }
    @Unroll
    def "should initialize SOAP client configuration for #scenarioName"() {
        given: "A LscrmGetAuthInfoClient instance with a mock SOAPClientConfigurer"
        HttpComponentsMessageSender httpComponentsMessageSender = Mock(HttpComponentsMessageSender)
        SOAPClientConfigurer soapClientConfigurer = Mock(SOAPClientConfigurer)
        WebServiceTemplate webServiceTemplate = Mock(WebServiceTemplate)
        LscrmGetAuthInfoClient<Object> client = new LscrmGetAuthInfoClient<>()
        client.httpComponentsMessageSender = httpComponentsMessageSender
        client.soapClientConfigurer = soapClientConfigurer
        client.setWebServiceTemplate(webServiceTemplate

        )
        client.lscrmSecurityHeaderUser = "testUser"
        client.lscrmSecurityHeaderPwd = "encryptedPwd"

        when: "init is called"
        client.init()

        then: "SOAPClientConfigurer.configure is called with correct parameters"
        1 * soapClientConfigurer.configure(client, "GetAuthInfo")


        where:
        scenarioName | _
        "SOAP client config present" | null
    }
    @Unroll
    def "should handle SoapFaultClientException and IOException for #scenarioName"() {
        given: "A SoapFaultClientException and IOException during handleSOAPFault"
        Object request = new Object()

        SoapFaultClientException soapFaultClientException = Mock(SoapFaultClientException)
        soapFaultClientException.getSoapFault() >> Mock(org.springframework.ws.soap.SoapFault)
        IOException ioException = new IOException("IO error")
        LscrmGetAuthInfoClient<Object> client = new LscrmGetAuthInfoClient<>()
        client.httpComponentsMessageSender = Mock(HttpComponentsMessageSender)
        client.soapClientConfigurer = Mock(SOAPClientConfigurer)
        WebServiceTemplate webServiceTemplate = Mock(WebServiceTemplate)
        client.setWebServiceTemplate(webServiceTemplate)
        client.lscrmSecurityHeaderUser = "testUser"
        client.lscrmSecurityHeaderPwd = "encryptedPwd"

        webServiceTemplate.getInterceptors() >> ([] as ClientInterceptor[])
        webServiceTemplate.marshalSendAndReceive(request) >> { throw soapFaultClientException }

        0 * CommonUtil.getAESDecryption("encryptedPwd") >> "decryptedPwd"
        0 * client.getWebServiceTemplate() >> webServiceTemplate

        when: "invokeAPI is called"
        client.invokeAPI(request)

        then: "ServiceException is thrown"
        ServiceException ex = thrown()


        then: "makeErrorMap is called and errorCode is returned"
        ex.message == '{userMessage=null, resourceId=MS_MPSYS_BE_602, resourceMsg=ERR_SYS_APPL : {0}, errorId=MS_MPSYS_BE_602, httpCode=500}'


        where:
        scenarioName | _
        "SoapFaultClientException with IOException" | null
    }


    @Unroll
    def "should create error map with correct errorCode for #scenarioName"() {
        given: "An ErrorMessages instance"
        ErrorMessages error = errorMessage

        when: "makeErrorMap is called"
        HashMap<String, Object> result = client.makeErrorMap(error)

        then: "Result contains the correct errorCode"
        result != null
        result.size() == 1
        result.get("errorCode") == error.toString()

        where:
        scenarioName                | errorMessage
        "MS_MPSYS_BE_602 error"     | ErrorMessages.MS_MPSYS_BE_602
        "MS_MPSYS_BE_606 error"     | ErrorMessages.MS_MPSYS_BE_606
    }

}
