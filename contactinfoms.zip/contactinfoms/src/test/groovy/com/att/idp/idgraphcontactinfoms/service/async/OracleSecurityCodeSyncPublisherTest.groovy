package com.att.idp.idgraphcontactinfoms.service.async

import com.att.idp.idgraph.events.service.EventPublisher
import com.att.idp.idgraphcontactinfoms.model.EventData
import com.att.idp.idgraphcontactinfoms.model.OTPEventModel
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class OracleSecurityCodeSyncPublisherTest extends Specification {

    EventPublisher eventPublisher = Mock(EventPublisher)

    OracleSecurityCodeSyncPublisher service = new OracleSecurityCodeSyncPublisher()

    def setup() {
        ReflectionTestUtils.setField(service, 'eventPublisher', eventPublisher)
    }

    def "publish should send OTP event to EventPublisher with correct envelope"() {
        given:
        String accountId = "acct-1"
        EventData eventData = new EventData()
        eventData.setAccountId(accountId)
        eventData.setIdentificationType("IDTYPE")

        when:
        service.publish(accountId, OracleSecurityCodeSyncPublisher.EVENT_TYPE_UPDATE, eventData, "ValidatePIN")

        then:
        1 * eventPublisher.send("OracleSecurityCodeSync", accountId, { OTPEventModel model ->
            model != null &&
                    model.getEventId() != null &&
                    !model.getEventId().isEmpty() &&
                    model.getEventTime() != null &&
                    model.getEventType() == "OracleSecurityCodeSync" &&
                    model.getResourceName() == "OTP" &&
                    model.getEventDetails() != null &&
                    model.getEventDetails().getType() == OracleSecurityCodeSyncPublisher.EVENT_TYPE_UPDATE &&
                    model.getEventDetails().getData() == eventData
        })
        0 * _
    }

    def "publish should propagate eventDetailsType into eventDetails"() {
        given:
        String accountId = "acct-2"
        EventData eventData = new EventData()
        eventData.setAccountId(accountId)
        eventData.setIdentificationType("IDTYPE")

        when:
        service.publish(accountId, OracleSecurityCodeSyncPublisher.EVENT_TYPE_DELETE, eventData, "DeletePIN")

        then:
        1 * eventPublisher.send("OracleSecurityCodeSync", accountId, { OTPEventModel model ->
            model != null &&
                    model.getEventDetails() != null &&
                    model.getEventDetails().getType() == OracleSecurityCodeSyncPublisher.EVENT_TYPE_DELETE
        })
        0 * _
    }
}
