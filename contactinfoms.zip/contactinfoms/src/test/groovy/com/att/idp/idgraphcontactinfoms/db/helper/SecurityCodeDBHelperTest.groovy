package com.att.idp.idgraphcontactinfoms.db.helper

import com.att.idp.idgraphcontactinfoms.db.model.Tsecurityaccount
import com.att.idp.idgraphcontactinfoms.db.model.Tsecuritycode
import com.att.idp.idgraphcontactinfoms.db.model.TsecuritycodeId
import com.att.idp.idgraphcontactinfoms.db.model.Tsystemofrecord
import com.att.idp.idgraphcontactinfoms.db.repository.SecurityAccountDataRepository
import com.att.idp.idgraphcontactinfoms.db.repository.SecurityCodeRepository
import com.att.idp.idgraphcontactinfoms.helpers.GeneratePINBase
import com.att.idp.idgraphcontactinfoms.metrics.ErrorMetricHandler
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Specification
import spock.lang.Unroll

import java.sql.Date
import java.sql.SQLException
import java.text.SimpleDateFormat
import java.time.LocalDate

class SecurityCodeDBHelperTest extends Specification {

	def securityCodeDBHelperO = new SecurityCodeDBHelper()

	def securityAccountDataRepository = Mock(SecurityAccountDataRepository)

	def securityCodeRepository = Mock(SecurityCodeRepository)

	def errMetricHandler = Mock(ErrorMetricHandler)

	HashMap<String, Object> inpParamHash = new HashMap<>()

	private HashMap<String, Object> inpParam = null
	private HashMap<String, Object> hmInput = null
	public static final Logger logger = LoggerFactory.getLogger(GeneratePINBase.class)


	def setup() {
		securityCodeDBHelperO.securityAccountDataRepository = securityAccountDataRepository
		securityCodeDBHelperO.securityCodeRepository = securityCodeRepository
		securityCodeDBHelperO.errorMetricHandler = errMetricHandler

		inpParam = new HashMap<String, Object>()
		hmInput = new HashMap<String, Object>()

		inpParam[MPSDefs.DB_IDENTIFICATION_TYPE] = 'EMAILPIN'
		inpParam[MPSDefs.DB_ACCOUNT_ID] = '22536476778'

		hmInput[MPSDefs.DB_IDENTIFICATION_TYPE] = 'EMAILPIN'
		hmInput[MPSDefs.DB_ACCOUNT_ID] = '22536476778'
		hmInput[MPSDefs.DB_SECURITY_CODE] = '220869'
		hmInput[MPSDefs.DB_REASON_CODE] = '12345'
	}


	def "set security code success test"() {
		given:
		int rowCount = 2
		securityCodeRepository.setSecurityCode(inpParam) >> rowCount
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.setSecurityCode(inpParam)
		then:
		resultHash[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
	}


	def "set security code exception test1"() {
		given:
		NullPointerException ex = new NullPointerException('ORA-00001: unique constraint')
		securityCodeRepository.setSecurityCode(inpParam) >> { throw ex }
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.setSecurityCode(inpParam)
		then:
		resultHash[CommonDefs.COMMON_APP_INFO] == 'ERR_ACCOUNT_ALREADY_EXISTS'
	}


	def "set security code exception test2"() {
		given:
		NullPointerException ex = new NullPointerException('Null output')
		securityCodeRepository.setSecurityCode(inpParam) >> { throw ex }
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.setSecurityCode(inpParam)
		then:
		resultHash[CommonDefs.COMMON_APP_INFO] == 'Exception: Null output'
	}


	def "set security account data success test"() throws Exception {
		given:
		int rowCount = 2
		securityAccountDataRepository.setSecurityAccountData(inpParam) >> rowCount
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.setSecurityAccountData(inpParam)
		then:
		resultHash[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
	}


	def "set security account data test1"() throws Exception {
		given:
		NullPointerException ex = new NullPointerException('ORA-00001: unique constraint')
		securityAccountDataRepository.setSecurityAccountData(inpParam) >> { throw ex }
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.setSecurityAccountData(inpParam)
		then:
		resultHash[CommonDefs.COMMON_APP_INFO] == 'ERR_ACCOUNT_ALREADY_EXISTS'
	}


	def "set security account data test2"() throws Exception {
		given:
		NullPointerException ex = new NullPointerException('Null output')
		securityAccountDataRepository.setSecurityAccountData(inpParam) >> { throw ex }
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.setSecurityAccountData(inpParam)
		then:
		resultHash[CommonDefs.COMMON_APP_INFO] == 'Exception: Null output'
	}


	def "update security account success test"() throws Exception {
		given:
		int rowCount = 2
		Long cumulativeFailureCount = 2L
		Boolean isSaveSecurityCode = true
		securityAccountDataRepository.getCumulativeFailureCount(_ as String, _ as String) >> cumulativeFailureCount
		securityAccountDataRepository.updateSecurityAccount(inpParam, isSaveSecurityCode, cumulativeFailureCount) >> rowCount
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.updateSecurityAccount(inpParam,
				isSaveSecurityCode)
		then:
		resultHash[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
	}


	def "update security account exception test"() throws SQLException {
		given:
		inpParam = null
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.updateSecurityAccount(inpParam, true)
		then:
		resultHash[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
	}


	def "get security account data success test"() throws SQLException {
		given:
		List<Tsecurityaccount> securityList = new ArrayList<>()

		Tsecurityaccount securityAccount = new Tsecurityaccount()
		Date date = new Date(1736546235L)
		securityAccount.accountType = 'R'
		securityAccount.accountRegion = 'abc'
		securityAccount.cumulativeFailureCount = 2L
		securityAccount.accountEntryExpires = date
		securityAccount.createDate = date
		securityList.add(securityAccount)

		securityAccountDataRepository.getSecurityAccountData(_ as String, _ as String) >> securityList
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.getSecurityAccountData(inpParam)
		then:
		resultHash[CommonDefs.COMMON_APP_STATUS_MSG] == 'OK'
	}


	def "get security account data error test1"() throws SQLException {
		given:
		List<Tsecurityaccount> securityList = new ArrayList<>()
		securityAccountDataRepository.getSecurityAccountData(_ as String, _ as String) >> securityList
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.getSecurityAccountData(inpParam)
		then:
		resultHash[CommonDefs.COMMON_APP_INFO] == 'REC_NOT_FOUND'
	}


	def "get security account data error test2"() throws SQLException {
		given:
		inpParam[MPSDefs.DB_IDENTIFICATION_TYPE] = null
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.getSecurityAccountData(inpParam)
		then:
		resultHash[CommonDefs.COMMON_APP_INFO] == 'Required Field missing'
	}


	def "get security account data error test3"() throws SQLException {
		given:
		inpParam[MPSDefs.DB_ACCOUNT_ID] = null
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.getSecurityAccountData(inpParam)
		then:
		resultHash[CommonDefs.COMMON_APP_INFO] == 'Required Field missing'
	}


	def "get security account data exception test"() throws SQLException {
		given:
		inpParam = null
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.getSecurityAccountData(inpParam)
		then:
		resultHash[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
	}


	def "delete security p i n success test1"() throws SQLException {
		given:
		int rowCount = 2
		Boolean isDeleteAllFlag = true
		securityCodeRepository.deleteByIdIdentificationTypeAndIdAccountId(_ as String, _ as String) >> rowCount
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.deleteSecurityPIN(hmInput, isDeleteAllFlag)
		then:
		resultHash[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
	}


	def "delete security p i n success test2"() throws SQLException {
		given:
		int rowCount = 0
		Boolean isDeleteAllFlag = true
		securityCodeRepository.deleteByIdIdentificationTypeAndIdAccountId(_ as String, _ as String) >> rowCount
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.deleteSecurityPIN(hmInput, isDeleteAllFlag)
		then:
		resultHash[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
	}


	def "delete security p i n error test"() throws SQLException {
		given:
		int rowCount = 0
		Boolean isDeleteAllFlag = false
		securityCodeRepository.updateBySecurityCodeId(_ as String, _ as String, _ as String, _ as String) >> rowCount
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.deleteSecurityPIN(hmInput, isDeleteAllFlag)
		then:
		resultHash[CommonDefs.COMMON_APP_INFO] == 'No Record Found in SECURITYCODE table for this account and SecurityCode. '
	}


	def "delete security p i n exception test"() throws SQLException {
		given:
		Boolean isDeleteAllFlag = true
		hmInput = null
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.deleteSecurityPIN(hmInput, isDeleteAllFlag)
		then:
		resultHash[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
	}


	def "update security code success test1"() throws SQLException {
		given:
		int rowCount = 2
		String event = 'IncrementFailureCount'
		inpParam[MPSDefs.DB_LAST_MODIFIED_BY] = 'DATAMGT'
		inpParam[MPSDefs.MAX_FAILURE_COUNT] = '5'
		inpParam[MPSDefs.DB_REASON_CODE] = 'FAILED'
		securityCodeRepository.updateSecurityCdByIncVeriffailCntSql(_ as String, _ as String, _ as String, _ as int,_ as String) >> rowCount
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.updateSecurityCode(inpParam, event)
		then:
		resultHash[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
	}


	def "update security code success test2"() throws SQLException {
		given:
		int rowCount = 2
		String event = 'UnlockSecurityCodes'
		securityCodeRepository.updateSecurityCdUnlockSql('EMAILPIN',null, '22536476778') >> rowCount
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.updateSecurityCode(inpParam, event)
		then:
		resultHash[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
	}


	def "update security code exception test"() throws SQLException {
		given:
		String event = null
		when:
		HashMap<String, Object> resultHash = securityCodeDBHelperO.updateSecurityCode(inpParam, event)
		then:
		resultHash[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
	}


	def "get security code data query test"() throws SQLException {
		given:
		inpParamHash[MPSDefs.DB_IDENTIFICATION_TYPE] = 'email'
		inpParamHash[MPSDefs.DB_ACCOUNT_ID] = 'test@test.com'
		inpParamHash[MPSDefs.GET_EXCEEDED_UNLOCKED_TIME] = MPSDefs.NO
		when:
		Map<String, Object> resultHash = securityCodeDBHelperO.getSecurityCodeDataQuery(inpParamHash)
		then:
		resultHash['SECURITY_CODE'] == null
	}


	def "get security code data querye else n o test"() throws SQLException {
		given:
		inpParamHash[MPSDefs.GET_EXCEEDED_UNLOCKED_TIME] = MPSDefs.NO
		inpParamHash[MPSDefs.DB_IDENTIFICATION_TYPE] = ''
		inpParamHash[MPSDefs.DB_ACCOUNT_ID] = ''
		when:
		Map<String, Object> resultHash = securityCodeDBHelperO.getSecurityCodeDataQuery(inpParamHash)
		then:
		resultHash['SECURITY_CODE'] == null
	}


	def "get security code data querye else2 n o test"() throws SQLException {
		given:
		inpParamHash[MPSDefs.GET_EXCEEDED_UNLOCKED_TIME] = MPSDefs.NO
		inpParamHash[MPSDefs.DB_IDENTIFICATION_TYPE] = 'email'
		inpParamHash[MPSDefs.DB_ACCOUNT_ID] = ''
		when:
		Map<String, Object> resultHash = securityCodeDBHelperO.getSecurityCodeDataQuery(inpParamHash)
		then:
		resultHash['SECURITY_CODE'] == null
	}


	def "get security code data querye else yes test"() throws SQLException {
		given:
		inpParamHash[MPSDefs.GET_EXCEEDED_UNLOCKED_TIME] = MPSDefs.YES
		inpParamHash[MPSDefs.DB_IDENTIFICATION_TYPE] = ''
		inpParamHash[MPSDefs.DB_ACCOUNT_ID] = ''
		when:
		Map<String, Object> resultHash = securityCodeDBHelperO.getSecurityCodeDataQuery(inpParamHash)
		then:
		resultHash['SECURITY_CODE'] == null
	}


	def "get security code data querye else2 yes test"() throws SQLException {
		given:
		inpParamHash[MPSDefs.GET_EXCEEDED_UNLOCKED_TIME] = MPSDefs.YES
		inpParamHash[MPSDefs.DB_IDENTIFICATION_TYPE] = 'email'
		inpParamHash[MPSDefs.DB_ACCOUNT_ID] = ''
		when:
		Map<String, Object> resultHash = securityCodeDBHelperO.getSecurityCodeDataQuery(inpParamHash)
		then:
		resultHash['SECURITY_CODE'] == null
	}


	def "get security code data query tsecuritycode test"() throws SQLException {
		given:
		LocalDate localDate = LocalDate.now()
		java.sql.Date now = java.sql.Date.valueOf(localDate)

		TsecuritycodeId secCode2 = new TsecuritycodeId()
		secCode2.securityCode = '142'

		Tsecuritycode secCode = new Tsecuritycode()
		secCode.securityCodeStatus = '123456'
		secCode.verificationFailureCount = 10
		secCode.createDate = now
		secCode.lastModified = now
		secCode.sorInvariantId = null
		secCode.passcodeVenc = '1234567'
		secCode.deliveryMethod = 'EMAIL'
		secCode.deliveryDetail = 'test@example.com'
		secCode.id = secCode2

		inpParamHash[MPSDefs.DB_SECURITY_CODE] = '123456'
		inpParamHash[MPSDefs.DB_VERIFICATION_FAILURE_COUNT] = '0'
		inpParamHash[MPSDefs.DB_SECURITY_CODE_EXPIRES] = '2'
		inpParamHash[MPSDefs.DB_CREATE_DATE] = '29/09/1988'
		inpParamHash[MPSDefs.DB_SOR_NAME] = 'att'
		inpParamHash[MPSDefs.DB_SOR_INVARIANT_ID] = 'att'
		inpParamHash[MPSDefs.DB_PASSCODE_VENC] = 'password'
		inpParamHash[MPSDefs.DB_DELIVERY_METHOD] = '2e'
		inpParamHash[MPSDefs.DB_DELIVERY_DETAIL] = 'kemf'
		inpParamHash[MPSDefs.DB_IDENTIFICATION_TYPE] = 'email'
		inpParamHash[MPSDefs.DB_ACCOUNT_ID] = 'test@test.com'
		inpParamHash[MPSDefs.GET_EXCEEDED_UNLOCKED_TIME] = MPSDefs.YES
		inpParamHash[MPSDefs.UNLOCK_PERIOD] = 14.55

		List<Tsecuritycode> securityCodeList = new ArrayList<>()
		securityCodeList.add(secCode)

		securityCodeRepository.getSecurityCodeDataQuery(_, _) >> securityCodeList
		securityCodeRepository.getDbCurrentDate() >> now
		when:
		Map<String, Object> resultHash = securityCodeDBHelperO.getSecurityCodeDataQuery(inpParamHash)
		then:
		resultHash['SECURITY_CODE'] == null
	}


	def "get security code data query exception test"() throws SQLException {
		given:
		inpParamHash[MPSDefs.GET_EXCEEDED_UNLOCKED_TIME] = 'trma_16374856'
		expect:
		Map<String, Object> response = securityCodeDBHelperO.getSecurityCodeDataQuery(inpParamHash)
	}


    def "should return DB time zone for #scenarioName"() {
        given: "A mocked DB time zone value"
        String expectedTimeZone = dbTimeZone

        when: "getDbTimeZone is called"
        String result = securityCodeDBHelperO.getDbTimeZone()

        then: "Repository is called with no parameters and returns expected value"
        1 * securityCodeRepository.getDbTimeZone() >> expectedTimeZone
        0 * _

        and: "Result matches expected time zone"
        result == expectedTimeZone

        where: "Different time zone scenarios"
        scenarioName         | dbTimeZone
        "UTC time zone"      | "UTC"
        "EST time zone"      | "EST"
        "PST time zone"      | "PST"
    }

    @Unroll
    def "should convert string to Date for #scenarioName"() {
        given: "A date string and expected Date"
        String inputDateString = dateString
        java.util.Date expectedDate = expectedDateValue

        when: "stringToDate is called"
        java.util.Date result = securityCodeDBHelperO.stringToDate(inputDateString)

        then: "Result matches expected Date"
        if (expectedDate != null) {
            result != null
            result.time == expectedDate.time
        } else {
            result == null
        }

        where: "Different date string scenarios"
        scenarioName           | dateString                | expectedDateValue
        "valid date string"    | "12/31/2023 15:45:00"     | new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").parse("12/31/2023 15:45:00")
    }


    // ============================================================
    // Coverage: getSecurityCodeDataQuery success path with populated Tsecuritycode
    // Covers lines 526-587 (field mapping, success result)
    // ============================================================

    def "getSecurityCodeDataQuery returns success with fully populated security code"() {
        given:
        LocalDate localDate = LocalDate.now()
        java.sql.Date now = java.sql.Date.valueOf(localDate)

        TsecuritycodeId secCodeId = new TsecuritycodeId()
        secCodeId.securityCode = 'ABC123'

        Tsystemofrecord sor = new Tsystemofrecord()
        sor.sorName = 'ATT_SOR'

        Tsecuritycode secCode = new Tsecuritycode()
        secCode.id = secCodeId
        secCode.verificationFailureCount = 3
        secCode.securityCodeExpires = now
        secCode.createDate = now
        secCode.lastModified = now
        secCode.lastModifiedBy = 'SYSTEM'
        secCode.securityCodeStatus = 'ACTIVE'
        secCode.sorInvariantId = 'INV-001'
        secCode.passcodeVenc = 'VENC123'
        secCode.deliveryMethod = 'EMAIL'
        secCode.deliveryDetail = 'test@att.com'
        secCode.tsystemofrecord = sor

        List<Tsecuritycode> securityCodeList = [secCode]

        inpParamHash[MPSDefs.DB_IDENTIFICATION_TYPE] = 'EMAILPIN'
        inpParamHash[MPSDefs.DB_ACCOUNT_ID] = 'test@test.com'

        securityCodeRepository.getSecurityCodeDataQuery('EMAILPIN', 'test@test.com') >> securityCodeList

        when:
        Map<String, Object> resultHash = securityCodeDBHelperO.getSecurityCodeDataQuery(inpParamHash)

        then:
        resultHash[MPSDefs.APP_STATUS_CODE] == MPSDefs.MPS_SUCCESS
        resultHash[MPSDefs.SECURITY_CODE_INFO] != null
        ((ArrayList) resultHash[MPSDefs.SECURITY_CODE_INFO]).size() == 1
    }

    // ============================================================
    // Coverage: getSecurityCodeDataQuery with null tsystemofrecord (ternary false branch)
    // Covers line 533 (ternary null branch)
    // ============================================================

    def "getSecurityCodeDataQuery returns success with null tsystemofrecord"() {
        given:
        LocalDate localDate = LocalDate.now()
        java.sql.Date now = java.sql.Date.valueOf(localDate)

        TsecuritycodeId secCodeId = new TsecuritycodeId()
        secCodeId.securityCode = 'DEF456'

        Tsecuritycode secCode = new Tsecuritycode()
        secCode.id = secCodeId
        secCode.verificationFailureCount = 0
        secCode.securityCodeExpires = now
        secCode.createDate = now
        secCode.lastModified = now
        secCode.lastModifiedBy = 'USER'
        secCode.securityCodeStatus = 'REGISTERED'
        secCode.sorInvariantId = null
        secCode.passcodeVenc = null
        secCode.deliveryMethod = 'SMS'
        secCode.deliveryDetail = '5551234567'
        secCode.tsystemofrecord = null

        List<Tsecuritycode> securityCodeList = [secCode]

        inpParamHash[MPSDefs.DB_IDENTIFICATION_TYPE] = 'IDSEMOB'
        inpParamHash[MPSDefs.DB_ACCOUNT_ID] = '000123456'

        securityCodeRepository.getSecurityCodeDataQuery('IDSEMOB', '000123456') >> securityCodeList

        when:
        Map<String, Object> resultHash = securityCodeDBHelperO.getSecurityCodeDataQuery(inpParamHash)

        then:
        resultHash[MPSDefs.APP_STATUS_CODE] == MPSDefs.MPS_SUCCESS
        resultHash[MPSDefs.SECURITY_CODE_COUNT] == '1'
    }

    // ============================================================
    // Coverage: getSecurityCodeDataQuery with unlock time calculation
    // Covers lines 544-576 (GET_EXCEEDED_UNLOCKED_TIME=YES, UNLOCK_PERIOD present)
    // ============================================================

    def "getSecurityCodeDataQuery calculates exceeded unlock time when requested"() {
        given:
        LocalDate localDate = LocalDate.now()
        java.sql.Date now = java.sql.Date.valueOf(localDate)

        TsecuritycodeId secCodeId = new TsecuritycodeId()
        secCodeId.securityCode = 'LOCK789'

        Tsecuritycode secCode = new Tsecuritycode()
        secCode.id = secCodeId
        secCode.verificationFailureCount = 5
        secCode.securityCodeExpires = now
        secCode.createDate = now
        secCode.lastModified = now
        secCode.lastModifiedBy = 'LOCKOUT'
        secCode.securityCodeStatus = 'LOCKED'
        secCode.deliveryMethod = 'SMS'
        secCode.deliveryDetail = '5559876543'
        secCode.tsystemofrecord = null

        List<Tsecuritycode> securityCodeList = [secCode]

        inpParamHash[MPSDefs.DB_IDENTIFICATION_TYPE] = 'EMAILPIN'
        inpParamHash[MPSDefs.DB_ACCOUNT_ID] = 'locktest@att.com'
        inpParamHash[MPSDefs.GET_EXCEEDED_UNLOCKED_TIME] = MPSDefs.YES
        inpParamHash[MPSDefs.UNLOCK_PERIOD] = Double.valueOf(15.0)

        securityCodeRepository.getSecurityCodeDataQuery('EMAILPIN', 'locktest@att.com') >> securityCodeList
        securityCodeRepository.getDbCurrentDate() >> now

        when:
        Map<String, Object> resultHash = securityCodeDBHelperO.getSecurityCodeDataQuery(inpParamHash)

        then:
        resultHash[MPSDefs.APP_STATUS_CODE] == MPSDefs.MPS_SUCCESS
        ArrayList codes = (ArrayList) resultHash[MPSDefs.SECURITY_CODE_INFO]
        codes.size() == 1
        HashMap codeMap = (HashMap) codes.get(0)
        codeMap[MPSDefs.EXCEEDED_UNLOCKED_TIME] != null
    }

    // ============================================================
    // Coverage: getSecurityCodeDataQuery with null lastModified (line 556 false branch)
    // ============================================================

    def "getSecurityCodeDataQuery handles null lastModified in unlock time calculation"() {
        given:
        LocalDate localDate = LocalDate.now()
        java.sql.Date now = java.sql.Date.valueOf(localDate)

        TsecuritycodeId secCodeId = new TsecuritycodeId()
        secCodeId.securityCode = 'NULLMOD'

        Tsecuritycode secCode = new Tsecuritycode()
        secCode.id = secCodeId
        secCode.verificationFailureCount = 2
        secCode.securityCodeExpires = now
        secCode.createDate = now
        secCode.lastModified = null
        secCode.lastModifiedBy = 'SYSTEM'
        secCode.securityCodeStatus = 'ACTIVE'
        secCode.deliveryMethod = 'EMAIL'
        secCode.deliveryDetail = 'null@att.com'
        secCode.tsystemofrecord = null

        List<Tsecuritycode> securityCodeList = [secCode]

        inpParamHash[MPSDefs.DB_IDENTIFICATION_TYPE] = 'EMAILPIN'
        inpParamHash[MPSDefs.DB_ACCOUNT_ID] = 'nullmod@att.com'
        inpParamHash[MPSDefs.GET_EXCEEDED_UNLOCKED_TIME] = MPSDefs.YES
        inpParamHash[MPSDefs.UNLOCK_PERIOD] = Double.valueOf(10.0)

        securityCodeRepository.getSecurityCodeDataQuery('EMAILPIN', 'nullmod@att.com') >> securityCodeList
        securityCodeRepository.getDbCurrentDate() >> now

        when:
        Map<String, Object> resultHash = securityCodeDBHelperO.getSecurityCodeDataQuery(inpParamHash)

        then:
        // When lastModified is null, stringToDate("") returns null → NPE in diffInMillies → exception path
        resultHash[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    // ============================================================
    // Coverage: getSecurityCodeDataQuery returns empty list (REC_NOT_FOUND)
    // Covers lines 589-593
    // ============================================================

    def "getSecurityCodeDataQuery returns REC_NOT_FOUND when list is empty"() {
        given:
        List<Tsecuritycode> emptyList = []

        inpParamHash[MPSDefs.DB_IDENTIFICATION_TYPE] = 'EMAILPIN'
        inpParamHash[MPSDefs.DB_ACCOUNT_ID] = 'nobody@att.com'

        securityCodeRepository.getSecurityCodeDataQuery('EMAILPIN', 'nobody@att.com') >> emptyList

        when:
        Map<String, Object> resultHash = securityCodeDBHelperO.getSecurityCodeDataQuery(inpParamHash)

        then:
        resultHash[CommonDefs.COMMON_APP_INFO] == 'REC_NOT_FOUND'
    }

    // ============================================================
    // Coverage: stringToDate with invalid date string (ParseException path)
    // Covers line 637
    // ============================================================

    def "stringToDate returns null for invalid date string"() {
        when:
        java.util.Date result = SecurityCodeDBHelper.stringToDate('NOT-A-DATE')

        then:
        result == null
    }

}