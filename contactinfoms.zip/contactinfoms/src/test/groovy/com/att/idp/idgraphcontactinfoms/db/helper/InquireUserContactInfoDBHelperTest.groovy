package com.att.idp.idgraphcontactinfoms.db.helper

import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.springframework.jdbc.core.JdbcTemplate
import spock.lang.Specification

class InquireUserContactInfoDBHelperTest extends Specification {
	
	def inquireUserContactInfoDBHelperObj = new InquireUserContactInfoDBHelper()

    def jdbcTemplate = Mock(JdbcTemplate)

    HashMap<String, Object> hminput = null
    HashMap<String, Object> inpParam = null
    String sGuid = '23475'
    List<Map<String, Object>> hmlist = null


    def setup() {
        inquireUserContactInfoDBHelperObj.jdbcTemplate = jdbcTemplate

		inpParam = new HashMap<String, Object>()
        hminput = new HashMap<String, Object>()
        hmlist = new ArrayList()

        inpParam[MPSDefs.DB_IDENTIFICATION_TYPE] = 'EMAILPIN'
        inpParam[MPSDefs.DB_ACCOUNT_ID] = '22536476778'

        hminput[MPSDefs.DB_IDENTIFICATION_TYPE] = 'EMAILPIN'
		hminput[MPSDefs.DB_ACCOUNT_ID] = '22536476778'
		hminput[MPSDefs.DB_SECURITY_CODE] = '220869'
		hminput[MPSDefs.DB_REASON_CODE] = '12345'
		hmlist.add(inpParam)
	}


    def "inquire user contact info null test"() {
        when:
        HashMap<String, Object> resultHash = inquireUserContactInfoDBHelperObj.inquireUserContactInfo(null)
        then:
        resultHash[CommonDefs.COMMON_APP_INFO] == 'Guid must be present in Input'
    }


    def "inquire user contact infoal query response null test"() {
        given:
        jdbcTemplate.queryForList(_, _ as String) >> null
        when:
        HashMap<String, Object> resultHash = inquireUserContactInfoDBHelperObj.inquireUserContactInfo(sGuid)
        then:
        resultHash[CommonDefs.COMMON_APP_INFO] == 'Input guid or handle/domain not found'
    }


    def "inquire user contact info test"() {
        given:
        jdbcTemplate.queryForList(_, _ as String) >> hmlist
        when:
        HashMap<String, Object> resultHash = inquireUserContactInfoDBHelperObj.inquireUserContactInfo(sGuid)
        then:
        resultHash[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }
}
