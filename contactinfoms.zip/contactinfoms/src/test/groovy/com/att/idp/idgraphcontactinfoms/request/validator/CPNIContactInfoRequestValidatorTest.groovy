package com.att.idp.idgraphcontactinfoms.request.validator


import com.att.idp.idgraphcontactinfoms.resource.response.CPNIContactInfoResponse
import jakarta.ws.rs.core.MultivaluedHashMap
import jakarta.ws.rs.core.MultivaluedMap
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import spock.lang.Unroll
import jakarta.ws.rs.core.HttpHeaders

class CPNIContactInfoRequestValidatorTest extends Specification {

    def validator = new CPNIContactInfoRequestValidator()
    MultivaluedMap<String, String> headersMap = new MultivaluedHashMap<>()


    def setup() {
        ReflectionTestUtils.setField(validator, 'propValidCallers', 'IDP|DATAMGT')
        ReflectionTestUtils.setField(validator, 'stValidAccountTypes', 'WIRELESS')
        ReflectionTestUtils.setField(validator, 'alValidExploitableValues', 'Y|N')
        ReflectionTestUtils.setField(validator, 'alValidReturnBizCTNsValues', 'Y|N')
        headersMap.add("idp-trace-id", "trace123")
        headersMap.add("individualId", "d6141ec8-f423-4bbe-85ee-305ba823d2e2")
    }

    def "should return error when headers are null"() {
        when:
        def resp = validator.cpniContactInfoRequestValidator(null)

        then:
        resp instanceof CPNIContactInfoResponse
        resp.errors.errorId == "MS_MPSYS_BE_100"
        resp.errors.message == "ERR_INVALID_DATA : Input Request is NULL / Empty."
    }

    def "should return error when idp-trace-id is missing or starts with AutoGen_"() {
        given:
        def headers = Mock(HttpHeaders)
        headers.getRequestHeaders() >> headersMap
        headers.getHeaderString("individualId") >> "id"
        headers.getHeaderString("X-ATT-ClientId") >> "VALID1"
        headers.getHeaderString("isExternalCall") >> null
        headers.getHeaderString("idp-trace-id") >> null


        when:
        def resp = validator.cpniContactInfoRequestValidator(headers)

        then:
        resp.errors.errorId == "MS_MPSYS_BE_100"

        when:
        headers.getHeaderString("idp-trace-id") >> "AutoGen_123"
        resp = validator.cpniContactInfoRequestValidator(headers)

        then:
        resp.errors.errorId == "MS_MPSYS_BE_100"

    }

    def "should return error when individualId is missing or blank"() {
        given:
        def headers = Mock(HttpHeaders)
        headers.getRequestHeaders() >> headersMap
        headers.getHeaderString("individualId") >> null
        headers.getHeaderString("X-ATT-ClientId") >> "VALID1"
        headers.getHeaderString("idp-trace-id") >>  "794c8b28197431:794c8b28197560:0:1"

        when:
        def resp = validator.cpniContactInfoRequestValidator(headers)

        then:
        resp.errors.errorId == "MS_MPSYS_BE_100"

        when:
        headers.getHeaderString("individualId") >> ""
        resp = validator.cpniContactInfoRequestValidator(headers)

        then:
        resp.errors.errorId == "MS_MPSYS_BE_100"

    }

    def "should return error when X-ATT-ClientId is missing or blank"() {
        given:
        def headers = Mock(HttpHeaders)
        headers.getRequestHeaders() >> headersMap
        headers.getHeaderString("individualId") >> "id"
        headers.getHeaderString("X-ATT-ClientId") >> null
        headers.getHeaderString("idp-trace-id") >>  "794c8b28197431:794c8b28197560:0:1"

        when:
        def resp = validator.cpniContactInfoRequestValidator(headers)

        then:
        resp.errors.errorId == "MS_MPSYS_BE_100"

        when:
        headers.getHeaderString("X-ATT-ClientId") >> ""
        resp = validator.cpniContactInfoRequestValidator(headers)

        then:
        resp.errors.errorId == "MS_MPSYS_BE_100"

    }

    def "should return error for invalid X-ATT-ClientId when isExternalCall is Y"() {
        given:
        def headers = Mock(HttpHeaders)
        headers.getRequestHeaders() >> headersMap
        headers.getHeaderString("individualId") >> "id"
        headers.getHeaderString("X-ATT-ClientId") >> "INVALID"
        headers.getHeaderString("isExternalCall") >> "Y"
        headers.getHeaderString("idp-trace-id") >>  "794c8b28197431:794c8b28197560:0:1"

        when:
        def resp = validator.cpniContactInfoRequestValidator(headers)

        then:
        resp.errors.errorId == "MS_MPSYS_BE_100"

    }

    def "should return null for valid headers and valid caller"() {
        given:
        def headers = Mock(HttpHeaders)
        headers.getRequestHeaders() >> headersMap
        headers.getHeaderString("individualId") >> "794c8b28197431"
        headers.getHeaderString("X-ATT-ClientId") >> "IDP"
        headers.getHeaderString("isExternalCall") >> "Y"
        headers.getHeaderString("idp-trace-id") >>  "794c8b28197431:794c8b28197560:0:1"

        when:
        def resp = validator.cpniContactInfoRequestValidator(headers)

        then:
        resp == null

    }

    def "should handle exception in cpniContactInfoRequestValidator"() {
        given:
        def headers = Mock(HttpHeaders)
        headers.getRequestHeaders() >> headersMap
        headers.getHeaderString("individualId") >> { throw new RuntimeException("fail") }
        headers.getHeaderString("idp-trace-id") >>  "794c8b28197431:794c8b28197560:0:1"

        when:
        def resp = validator.cpniContactInfoRequestValidator(headers)

        then:
        resp.errors.errorId == "MS_MPSYS_BE_602"
        resp.errors.message == "ERR_SYS_APPL : Exception thrown in CPNIContactInfoRequestValidator : fail"

    }

    def "should return error when accountId is present and accountType is missing"() {
        given:
        def headers = Mock(HttpHeaders)
        headers.getRequestHeaders() >> headersMap
        headers.getHeaderString("accountId") >> "554638872"
        headers.getHeaderString("accountType") >> null
        headers.getHeaderString("X-ATT-ClientId") >> "IDP"
        headers.getHeaderString("idp-trace-id") >>  "794c8b28197431:794c8b28197560:0:1"

        when:
        def resp = validator.cpniContactInfoRequestValidator(headers)

        then:
        resp != null
        resp.errors.errorId == "MS_MPSYS_BE_100"

    }

    def "should return error when accountId is present and accountType is invalid"() {
        given:
        def headers = Mock(HttpHeaders)
        headers.getRequestHeaders() >> headersMap
        headers.getHeaderString("accountId") >> "554638872"
        headers.getHeaderString("accountType") >> "bssewireless"
        headers.getHeaderString("X-ATT-ClientId") >> "IDP"
        headers.getHeaderString("idp-trace-id") >>  "794c8b28197431:794c8b28197560:0:1"

        when:
        def resp = validator.cpniContactInfoRequestValidator(headers)

        then:
        resp.errors.errorId == "MS_MPSYS_BE_100"

    }

    def "should return error when request has both accountId and individualId"() {
        given:
        def headers = Mock(HttpHeaders)
        headers.getRequestHeaders() >> headersMap
        headers.getHeaderString("individualId") >> "794c8b28197431"
        headers.getHeaderString("accountId") >> "554638872"
        headers.getHeaderString("accountType") >> "wireless"
        headers.getHeaderString("X-ATT-ClientId") >> "IDP"
        headers.getHeaderString("idp-trace-id") >>  "794c8b28197431:794c8b28197560:0:1"

        when:
        def resp = validator.cpniContactInfoRequestValidator(headers)

        then:
        resp.errors.errorId == "MS_MPSYS_BE_100"

    }

    def "should return error when invalid exploitable is passed"() {
        given:
        def headers = Mock(HttpHeaders)
        headers.getRequestHeaders() >> headersMap
        headers.getHeaderString("accountId") >> "554638872"
        headers.getHeaderString("accountType") >> "wireless"
        headers.getHeaderString("X-ATT-ClientId") >> "IDP"
        headers.getHeaderString("idp-trace-id") >> "794c8b28197431:794c8b28197560:0:1"
        headers.getHeaderString("exploitable") >> "A"

        when:
        def resp = validator.cpniContactInfoRequestValidator(headers)

        then:
        resp.errors.errorId == "MS_MPSYS_BE_100"
        resp.errors.message == "ERR_INVALID_DATA : Invalid exploitable value provided in the request : A"

    }

    def "should return error when invalid returnBizCTNs is passed"() {
        given:
        def headers = Mock(HttpHeaders)
        headers.getRequestHeaders() >> headersMap
        headers.getHeaderString("accountId") >> "554638872"
        headers.getHeaderString("accountType") >> "wireless"
        headers.getHeaderString("X-ATT-ClientId") >> "IDP"
        headers.getHeaderString("idp-trace-id") >> "794c8b28197431:794c8b28197560:0:1"
        headers.getHeaderString("returnBizCTNs") >> "A"

        when:
        def resp = validator.cpniContactInfoRequestValidator(headers)

        then:
        resp.errors.errorId == "MS_MPSYS_BE_100"
        resp.errors.message == "ERR_INVALID_DATA : Invalid returnBizCTNs value provided in the request : A"

    }

    @Unroll
    def "should validate identifier mutual exclusivity: #scenario"() {
        given:
        HttpHeaders headers = Stub(HttpHeaders)
        headers.getRequestHeaders() >> headersMap
        headers.getHeaderString(_) >> { String key ->
            switch (key) {
                case "subscriberNumber": return subscriberNumber
                case "individualId": return individualId
                case "accountId": return accountId
                case "accountType": return accountType
                case "X-ATT-ClientId": return "IDP"
                case "isExternalCall": return "Y"
                case "idp-trace-id": return "794c8b28197431:794c8b28197560:0:1"
                default: return null
            }
        }

        when:
        CPNIContactInfoResponse resp = validator.cpniContactInfoRequestValidator(headers)

        then:
        if (expectedError) {
            assert resp != null
            assert resp.errors.errorId == "MS_MPSYS_BE_100"
            assert resp.errors.message == expectedMessage
        } else {
            assert resp == null
        }
        0 * _

        where:
        scenario                                          | subscriberNumber | individualId      | accountId   | accountType | expectedError | expectedMessage
        "only subscriberNumber present"                   | "1234567890"     | null              | null        | null        | false         | null
        "subscriberNumber without accountType"            | "1234567890"     | null              | null        | null        | false         | null
        "subscriberNumber and individualId both present"  | "1234567890"     | "794c8b28197431"  | null        | null        | true          | "ERR_INVALID_DATA : Request can have only one of individualId, accountId, or subscriberNumber. Please provide only one."
        "subscriberNumber and accountId both present"     | "1234567890"     | null              | "554638872" | "wireless"  | true          | "ERR_INVALID_DATA : Request can have only one of individualId, accountId, or subscriberNumber. Please provide only one."
        "all three identifiers present"                   | "1234567890"     | "794c8b28197431"  | "554638872" | "wireless"  | true          | "ERR_INVALID_DATA : Request can have only one of individualId, accountId, or subscriberNumber. Please provide only one."
        "none of the three identifiers present"           | null             | null              | null        | null        | true          | "ERR_INVALID_DATA : All of individualId, accountId, and subscriberNumber cannot be null/empty in request headers."
        "only individualId present"   | null             | "794c8b28197431"  | null        | null        | false         | null
        "only accountId present"      | null             | null              | "554638872" | "wireless"  | false         | null

    }

    }