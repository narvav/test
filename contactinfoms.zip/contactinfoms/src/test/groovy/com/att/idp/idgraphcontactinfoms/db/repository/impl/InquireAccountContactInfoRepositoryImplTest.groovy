package com.att.idp.idgraphcontactinfoms.db.repository.impl

import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import org.hibernate.Session
import org.hibernate.query.NativeQuery
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import jakarta.persistence.EntityManager
import java.sql.SQLException
import java.time.LocalDate

class InquireAccountContactInfoRepositoryImplTest extends Specification {

    def inquireAccountContactInfoRepositoryImplObj = new InquireAccountContactInfoRepositoryImpl()

    def query = Mock(NativeQuery)

    def sessionMock = Mock(Session)

    def entityManager = Mock(EntityManager)

    ArrayList alSorIdList = new ArrayList()
    ArrayList alAccountInvariantId = new ArrayList()
    List<Object[]> alQueryResponse = null
    HashMap hmResult = null
    HashMap hmDBInput = null


    public static final Logger logger = LoggerFactory.getLogger(InquireAccountContactInfoRepositoryImplTest.class)


    def setup() {
        inquireAccountContactInfoRepositoryImplObj.entityManager = entityManager

        alQueryResponse = new ArrayList<Object[]>()
        hmDBInput = CommonUtil.hashMap

        alSorIdList.add('16')
        alAccountInvariantId.add('000830046589')

        hmDBInput[CommonDefs.ACCOUNT_INVARIANT_ID] = '000830046589'
        hmDBInput['sorIdList'] = alSorIdList

        ReflectionTestUtils.setField(inquireAccountContactInfoRepositoryImplObj, 'entityManager', entityManager)
        entityManager.unwrap(_) >> sessionMock
        sessionMock.unwrap(_) >> query
    }


    def "test inquire account contact system error"() throws Exception {

        given:
        hmResult = inquireAccountContactInfoRepositoryImplObj.inquireAccountContactInfo(hmDBInput)

        when:
        String stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_SYS_APPL'

    }

    def "test inquire account invarient id empty contact system error"() throws Exception {
        hmDBInput[CommonDefs.ACCOUNT_INVARIANT_ID] = ''
        given:
        hmResult = inquireAccountContactInfoRepositoryImplObj.inquireAccountContactInfo(hmDBInput)

        when:
        String stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'ERR_SYS_APPL'

    }


    def "inquire account contact info success test"() throws SQLException {

        given:
        alQueryResponse.add(stubData)
        query.setParameterList('alAccountInvariantIdList', alAccountInvariantId) >> query
        query.setParameterList('sorIdList', alSorIdList) >> query
        sessionMock.createNativeQuery(_) >> query
        entityManager.unwrap(Session.class) >> sessionMock
        query.list() >> alQueryResponse

        hmResult = inquireAccountContactInfoRepositoryImplObj.inquireAccountContactInfo(hmDBInput)

        when:
        String stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'SUCCESS'
    }


    def "test inquire account contact rec not found error"() throws Exception {
        given:
        query.setParameterList('alAccountInvariantIdList', alAccountInvariantId) >> query
        query.setParameterList('sorIdList', alSorIdList) >> query
        sessionMock.createNativeQuery(_) >> query
        entityManager.unwrap(Session.class) >> sessionMock
        query.list() >> null

        hmResult = inquireAccountContactInfoRepositoryImplObj.inquireAccountContactInfo(hmDBInput)

        when:
        String stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'REC_NOT_FOUND'

    }

    private Object[] getStubData() {
        LocalDate localDate = LocalDate.now()
        java.sql.Date createDate = java.sql.Date.valueOf(localDate)
        java.sql.Date lastModifieddate = java.sql.Date.valueOf(localDate)
        Object lastModifiedby = (Object) 'MYWORLD'
        Object[] oQueryResponse = new Object[15]
        oQueryResponse[0] = 'COLA'
        oQueryResponse[1] = createDate
        oQueryResponse[2] = lastModifieddate
        oQueryResponse[3] = lastModifiedby
        oQueryResponse[4] = '16'
        oQueryResponse[5] = '00008127681'
        oQueryResponse[6] = 'SPHONE'
        oQueryResponse[7] = '829019199'
        oQueryResponse[8] = 'test'
        return oQueryResponse
    }


    def "dbHealthCheck returns true when database responds"() {
        given:
        // Ensure repository uses our mocked session
        inquireAccountContactInfoRepositoryImplObj.entityManager = entityManager
        entityManager.unwrap(Session) >> sessionMock
        sessionMock.createNativeQuery("SELECT 1 FROM DUAL") >> query
        List<Object[]> oneRow = [new Object[]{1}]
        query.list() >> oneRow

        when:
        boolean up = inquireAccountContactInfoRepositoryImplObj.dbHealthCheck()

        then:
        up
    }

    def "dbHealthCheck returns false when query returns empty list"() {
        given:
        inquireAccountContactInfoRepositoryImplObj.entityManager = entityManager
        entityManager.unwrap(Session) >> sessionMock
        sessionMock.createNativeQuery("SELECT 1 FROM DUAL") >> query
        query.list() >> Collections.emptyList()

        when:
        boolean up = inquireAccountContactInfoRepositoryImplObj.dbHealthCheck()

        then:
        !up
    }

    def "dbHealthCheck returns false when exception thrown"() {
        given:
        inquireAccountContactInfoRepositoryImplObj.entityManager = entityManager
        entityManager.unwrap(Session) >> sessionMock
        sessionMock.createNativeQuery("SELECT 1 FROM DUAL") >> { throw new RuntimeException("DB down") }

        when:
        boolean up = inquireAccountContactInfoRepositoryImplObj.dbHealthCheck()

        then:
        !up
    }
}