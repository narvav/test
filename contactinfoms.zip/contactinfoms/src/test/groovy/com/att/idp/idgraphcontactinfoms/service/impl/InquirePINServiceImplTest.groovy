package com.att.idp.idgraphcontactinfoms.service.impl

import com.att.idp.idgraphcontactinfoms.exceptions.InvalidInputDataException
import com.att.idp.idgraphcontactinfoms.helpers.InquirePINHelper
import com.att.idp.idgraphcontactinfoms.resource.request.InquirePINRequest
import com.att.idp.idgraphcontactinfoms.resource.request.ValidatePINRequest
import com.att.idp.idgraphcontactinfoms.resource.response.InquirePINResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import jakarta.ws.rs.core.MultivaluedHashMap
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedMap

import static org.junit.jupiter.api.Assertions.assertThrows

class InquirePINServiceImplTest extends Specification {

    def InquirePINServiceImpl inquirePINServiceImplObj = new InquirePINServiceImpl()
    InquirePINHelper inquirePINHelperObj = Mock(InquirePINHelper)
    InquirePINRequest inquirePinRequest
    MultivaluedMap<String, String> requestHeader
    Map<String, String> headers = new HashMap<>()

    def setup() {
        inquirePINServiceImplObj.inquirePINHelper = inquirePINHelperObj
        inquirePinRequest = new InquirePINRequest(
                callingSystemId: 'IDP',
                accountId: '64573738',
                identificationType: 'CTNDIH',
                idpTraceId: '99dfs999:8dfs8888:77777:66666ccc'
        )
        requestHeader = new MultivaluedHashMap<>(headers)
    }

    def "test inquire pin null case"() {
        when:
        InquirePINResponse response = inquirePINServiceImplObj.inquirePIN(inquirePinRequest, requestHeader)
        then:
        response.appInfo == 'Null response from InquirePINHelper.InquirePin'

        when:
        def hmResponse = [(MPSDefs.APP_STATUS_CODE): null]
        inquirePINHelperObj.inquirePIN(_) >> hmResponse
        response = inquirePINServiceImplObj.inquirePIN(inquirePinRequest, requestHeader)
        then:
        response.appInfo == 'Null response from InquirePINHelper.InquirePin'
    }

    def "test inquire pin success case"() {
        given:
        def hmResponse = [
                (CommonDefs.TRANSACTION_ID): 'trma_16374856',
                (MPSDefs.APP_STATUS_CODE): '0',
                'appInfo': 'Success'
        ]
        inquirePINHelperObj.inquirePIN(_) >> hmResponse
        when:
        InquirePINResponse response = inquirePINServiceImplObj.inquirePIN(inquirePinRequest, requestHeader)
        then:
        response != null
        response.idpTraceId != null
        response.transactionName == 'InquirePIN'
    }
}