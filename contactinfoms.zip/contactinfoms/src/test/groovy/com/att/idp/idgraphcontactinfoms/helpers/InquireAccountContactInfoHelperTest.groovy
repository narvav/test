package com.att.idp.idgraphcontactinfoms.helpers

import com.att.idp.idgraphcontactinfoms.db.repository.InquireAccountContactInfoRepository
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class InquireAccountContactInfoHelperTest extends Specification {
	
	def InquireAccountContactInfoHelper inquireAccountContactInfoHelperObj = new InquireAccountContactInfoHelper()
    InquireAccountContactInfoRepository inquireACIRepo = Mock(InquireAccountContactInfoRepository)

    String stTransactionId = null
    HashMap resultHashSuccess = null
    HashMap resultHashError = null
    HashMap hmInput = null
    HashMap hmResults = null
    ArrayList alServiceContactList = null
    Map hmServiceContactHashMap = null
    Map hmResult = null
    HashMap linkedMemberHash = null
    ArrayList alAccountInvariantIdList = null


    def setup() {
        inquireAccountContactInfoHelperObj.inquireACIRepo = inquireACIRepo
        System.setProperty('CommonConfigurationFilePath', './opt/att/ajsc/config/CommonConfigurationTest.xml')

        hmInput = CommonUtil.hashMap
        hmInput[CommonDefs.TRANSACTION_NAME] = 'InquireAccountContactInfo'
        hmInput[CommonDefs.TRANSACTION_ID] = 'kan_123'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.IS_EXTERNAL_CALL] = 'Y'
        hmInput[CommonDefs.HANDLE] = 'qyma123'
        hmInput[CommonDefs.DOMAIN] = 'slid.dum'
        hmInput[CommonDefs.GUID] = '123456789'
        hmInput[CommonDefs.ACCOUNT_TYPE] = CommonDefs.ECOMM_SERVICE
        hmInput[CommonDefs.ACCOUNT_INVARIANT_ID] = '398725786'
        hmInput['accountInvariantIdList'] = alAccountInvariantIdList

        alAccountInvariantIdList = CommonUtil.arrayList
        alAccountInvariantIdList.add(linkedMemberHash)

        hmServiceContactHashMap = CommonUtil.hashMap
        hmServiceContactHashMap[MPSDefs.DB_CONTACT_TYPE] = CommonDefs.CONTACT_TYPE_PRIMARY_PHONE
        hmServiceContactHashMap[MPSDefs.DB_CONTACT_TYPE] = CommonDefs.CONTACT_TYPE_SECONDARY_PHONE
        hmServiceContactHashMap[MPSDefs.DB_PHONE_NUMBER_EXT] = '987678'
        hmServiceContactHashMap[MPSDefs.DB_VALIDATION_STATUS] = '100'
        hmServiceContactHashMap[MPSDefs.DB_VALIDATION_INITIATED_DATE] = '10-10-1000'

        alServiceContactList = CommonUtil.arrayList
        alServiceContactList.add(hmServiceContactHashMap)

        hmResults = CommonUtil.hashMap
        hmResults[CErrorDefs.COMMON_APP_STATUS_CODE] = '0'
        hmResults[MPSDefs.DB_SERVICE_CONTACTS] = alServiceContactList

        ReflectionTestUtils.setField(inquireAccountContactInfoHelperObj, 'stInquireAccountContactInfoCSI', 'DATAMGT|IDP|CSRIDP')
    }


    def "inquire account contact info helper t r a n s a c t i o n n a m e"() {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'aa'
        when:
        hmResult = inquireAccountContactInfoHelperObj.inquireAccountContactInfo(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Transaction Not Allowed :: TransactionName Should be InquireAccountContactInfo'
    }


    def "inquire account contact info helper i s e x t e r n a l c a l l"() {
        given:
        hmInput[CommonDefs.IS_EXTERNAL_CALL] = 'A'
        when:
        hmResult = inquireAccountContactInfoHelperObj.inquireAccountContactInfo(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'sIsExternalCall must be one of Y or N'
    }


    def "inquire account contact info helper c a l l i n g s y s t e m i d"() {
        given:
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = null
        when:
        hmResult = inquireAccountContactInfoHelperObj.inquireAccountContactInfo(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'CallingSystemId must be present'
    }


    def "inquire account contact info helper a c c o u n t t y p e"() {
        given:
        hmInput[CommonDefs.ACCOUNT_TYPE] = null
        when:
        hmResult = inquireAccountContactInfoHelperObj.inquireAccountContactInfo(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'accountType must be present'
    }


    def "inquire account contact info helper a c c o u n t i n v a r i a n t i d"() {
        given:
        hmInput[CommonDefs.ACCOUNT_INVARIANT_ID] = null
        when:
        hmResult = inquireAccountContactInfoHelperObj.inquireAccountContactInfo(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'AccountInvariantId must be present'
    }


    def "inquire account contact info helper invalid c s i"() {
        given:
        ReflectionTestUtils.setField(inquireAccountContactInfoHelperObj, 'stInquireAccountContactInfoCSI', 'AAA|sss')
        when:
        hmResult = inquireAccountContactInfoHelperObj.inquireAccountContactInfo(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Invalid CallingSystemId passed in input'
    }


    def "inquire account contact info helper a c c o u n t t y p eunsupported"() {
        given:
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'Ooooo'
        when:
        hmResult = inquireAccountContactInfoHelperObj.inquireAccountContactInfo(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'unsupported accountType'
    }


    def "inquire account contact info helper null query c p n i account contact info repository"() {
        given:
        inquireACIRepo.inquireAccountContactInfo(_ as HashMap) >> null
        when:
        hmResult = inquireAccountContactInfoHelperObj.inquireAccountContactInfo(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'QueryCPNIAccountContactInfoRepository returned null response.'
    }


    def "inquire account contact info helper b a n"() {
        given:
        hmResults[CErrorDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.ERR_REC_NOT_FOUND
        inquireACIRepo.inquireAccountContactInfo(_) >> hmResults
        when:
        hmResult = inquireAccountContactInfoHelperObj.inquireAccountContactInfo(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'BAN not found in MPS.'
    }


    def "inquire account contact info helper account s u c c e s s"() {
        given:
        inquireACIRepo.inquireAccountContactInfo(_) >> hmResults
        when:
        hmResult = inquireAccountContactInfoHelperObj.inquireAccountContactInfo(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "inquire account contact info helper accountelse s u c c e s s"() {
        given:
        hmServiceContactHashMap[MPSDefs.DB_CONTACT_TYPE] = CommonDefs.CONTACT_TYPE_PRIMARY_EMAIL
        hmServiceContactHashMap[MPSDefs.DB_CONTACT_TYPE] = CommonDefs.CONTACT_TYPE_TEXT_ACCOUNT_EMAIL

        inquireACIRepo.inquireAccountContactInfo(_) >> hmResults
        when:
        hmResult = inquireAccountContactInfoHelperObj.inquireAccountContactInfo(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

}
