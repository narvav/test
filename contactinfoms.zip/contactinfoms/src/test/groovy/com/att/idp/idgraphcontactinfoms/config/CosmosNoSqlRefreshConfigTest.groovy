package com.att.idp.idgraphcontactinfoms.config

import com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig
import com.azure.cosmos.CosmosAsyncClient
import com.azure.spring.data.cosmos.config.CosmosConfig
import com.azure.spring.data.cosmos.core.ReactiveCosmosOperations
import com.azure.spring.data.cosmos.core.ReactiveCosmosTemplate
import com.azure.spring.data.cosmos.core.convert.MappingCosmosConverter
import com.azure.spring.data.cosmos.core.mapping.CosmosMappingContext
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class CosmosNoSqlRefreshConfigTest extends Specification {

    IDGraphAzureAppConfig idGraphAzureAppConfig = Mock(IDGraphAzureAppConfig)
    CosmosNoSqlRefreshConfig subject

    def setup() {
        subject = new CosmosNoSqlRefreshConfig(idGraphAzureAppConfig)
        ReflectionTestUtils.setField(subject, "endpoint", "https://test-cosmos.documents.azure.com:443/")
        ReflectionTestUtils.setField(subject, "key", "ZmFrZS1rZXk=") // valid base64
        ReflectionTestUtils.setField(subject, "database", "idm_dev")
        ReflectionTestUtils.setField(subject, "throttlingRetryMaxWaitTime", java.time.Duration.ofSeconds(10))
    }

    def "should create cosmos config and mapping beans"() {
        when:
        CosmosConfig config = subject.cosmosConfig()
        CosmosMappingContext context = subject.cosmosMappingContext()
        MappingCosmosConverter converter = subject.cosmosConverter(context)

        then:
        config != null
        context != null
        converter != null
        0 * _
    }

    def "should build initial cosmos template proxy without real client creation"() {
        given:
        CosmosAsyncClient client = GroovyMock(CosmosAsyncClient, global: false)

        when:
        ReactiveCosmosOperations ops = subject.cosmosTemplate(
                client,
                subject.cosmosConfig(),
                subject.cosmosConverter(subject.cosmosMappingContext())
        )

        then: "config values read, template created and set, proxy returned"
        1 * idGraphAzureAppConfig.getMaxConnectionPoolSize() >> 100
        1 * idGraphAzureAppConfig.getIdleConnectionTimeoutMs() >> 5000
        ops != null
        0 * _

        and:
        ReflectionTestUtils.getField(subject, "currentTemplate") != null
    }

    def "should keep existing references when refresh rebuild fails"() {
        given:
        RefreshScopeRefreshedEvent event = Mock(RefreshScopeRefreshedEvent)
        CosmosAsyncClient existingClient = GroovyMock(CosmosAsyncClient, global: false)
        ReactiveCosmosTemplate existingTemplate = Mock(ReactiveCosmosTemplate)

        ReflectionTestUtils.setField(subject, "activeClient", existingClient)
        ReflectionTestUtils.setField(subject, "currentTemplate", existingTemplate)

        // Force failure in buildClientBuilder path before SDK call
        ReflectionTestUtils.setField(subject, "endpoint", null)

        when:
        subject.onRefresh(event)

        then: "event name logged, config values read twice, no client close, references retained"
        1 * event.getName() >> "appConfigRefresh"
        2 * idGraphAzureAppConfig.getMaxConnectionPoolSize() >> 100
        2 * idGraphAzureAppConfig.getIdleConnectionTimeoutMs() >> 5000
        2 * idGraphAzureAppConfig.getPreferredRegions() >> ["East US 2", "West US 2"]
        0 * existingClient.close()
        0 * _

        and:
        ReflectionTestUtils.getField(subject, "activeClient") == existingClient
        ReflectionTestUtils.getField(subject, "currentTemplate") == existingTemplate
    }
}