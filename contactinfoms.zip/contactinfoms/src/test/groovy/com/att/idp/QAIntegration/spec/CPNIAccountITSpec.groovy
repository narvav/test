package com.att.idp.QAIntegration.spec

import com.att.idp.QAIntegration.Base.TestBase
import com.att.idp.QAIntegration.Config.ContactInfoGlobalConfig
import com.att.idp.QAIntegration.Helpers.ContactInfoMsApiHelpers
import groovy.util.logging.Slf4j
import io.restassured.response.Response
import spock.lang.IgnoreIf
import spock.lang.Shared
import spock.lang.Tag
import spock.lang.Unroll

/**
 * QG7 Integration Test — CPNI Contact Info Account API
 *
 * Tests for POST /cpniContactInfo/account endpoint with YAML-driven test data.
 * Tests various account types: MOBILITY, TITAN, ECOMM with accountId and accountInvariantId.
 *
 * OMNI Compliance:
 * - Spec suffix: *ITSpec.groovy (testing-foundation.md E1)
 * - then: 0 * _ mandatory (HS-8)
 * - No mocks — real HTTP calls to deployed service
 */
@Slf4j
@Tag("Regression")
@Tag("CPNI")
@Tag("IDGraphContactInfoMs")
@IgnoreIf({ !ContactInfoGlobalConfig.isTestCaseEnabled("CPNIAccountITSpec") })
class CPNIAccountITSpec extends TestBase {

    @Shared
    Map testData = ContactInfoGlobalConfig.getTestData()

    @Shared
    List<Map> cpniAccountWithInvariantId = (testData?.get("cpniAccountWithInvariantId") as List<Map>) ?: []

    @Shared
    List<Map> cpniAccountWithAccountId = (testData?.get("cpniAccountWithAccountId") as List<Map>) ?: []

    @Shared
    List<Map> cpniAccountNegative = (testData?.get("cpniAccountNegative") as List<Map>) ?: []

    // ═══════════════════════════════════════════════════════════════════════════
    // CPNI Account — Tests with AccountInvariantId (from YAML)
    // ═══════════════════════════════════════════════════════════════════════════

    @Unroll("CPNI Account — #tc.testCaseName")
    def "CPNI Account Contact Info — With AccountInvariantId"() {
        setup:
        setTestName(tc.testCaseName as String)
        logStep("POST ${ContactInfoGlobalConfig.Endpoints.CPNI_CONTACT_INFO_ACCOUNT}")

        when: "POST CPNI Account Contact Info is called"
        Response response = ContactInfoMsApiHelpers.cpniContactInfoAccount(tc as Map)

        then: "No mock interactions"
        0 * _

        and: "Response status matches expected"
        int expectedStatus = (tc.expectedStatus ?: 200) as int
        assert response.statusCode() == expectedStatus :
                "Expected ${expectedStatus} but got ${response.statusCode()}"

        where:
        tc << cpniAccountWithInvariantId
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CPNI Account — Negative Tests (from YAML)
    // ═══════════════════════════════════════════════════════════════════════════

    @Unroll("CPNI Account Negative — #tc.testCaseName")
    def "CPNI Account Contact Info — Negative Tests"() {
        setup:
        setTestName(tc.testCaseName as String)
        logStep("POST ${ContactInfoGlobalConfig.Endpoints.CPNI_CONTACT_INFO_ACCOUNT} (expecting 400)")

        when: "POST CPNI Account Contact Info is called with invalid data"
        Response response = ContactInfoMsApiHelpers.cpniContactInfoAccount(tc as Map)

        then: "No mock interactions"
        0 * _

        and: "Response status matches expected"
        int expectedStatus = (tc.expectedStatus ?: 400) as int
        assert response.statusCode() == expectedStatus :
                "Expected ${expectedStatus} but got ${response.statusCode()}"

        where:
        tc << cpniAccountNegative
    }
}
