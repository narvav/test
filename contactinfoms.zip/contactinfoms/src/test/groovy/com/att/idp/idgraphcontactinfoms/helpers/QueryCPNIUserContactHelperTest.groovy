package com.att.idp.idgraphcontactinfoms.helpers

import com.att.idp.idgraphcontactinfoms.integration.InquireProfileRestClient
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.CommonUtil
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ArrayNode
import org.slf4j.Logger
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import spock.lang.Ignore
import spock.lang.Unroll


class QueryCPNIUserContactHelperTest extends Specification {

    def QueryCPNIUserContactHelper testObj = new QueryCPNIUserContactHelper()

    InquireProfileRestClient inquireProfileRestClient = Mock(InquireProfileRestClient)

    CommonUtilHelper oCommonUtilHelper = Mock(CommonUtilHelper)

    QueryCPNIAcccountContactHelper queryCPNIAccountContactHelper = Mock(QueryCPNIAcccountContactHelper)

    InquireUserContactInfoHelper inquireUserContactInfoHelper = Mock(InquireUserContactInfoHelper)

    ExternalDestinationHelper externalDestinationHelper = Mock(ExternalDestinationHelper)

    CPNIDataAddressHelper objCPNIDataAddressHelper = Mock(CPNIDataAddressHelper)

    InquireContactInfoHelper inquireContactInfoHelper = Mock(InquireContactInfoHelper)

    String stTransactionId = null
    HashMap resultHashSuccess = null
    HashMap resultHashError = null
    HashMap hmResult = null
    HashMap hmInput = null
    String stAppStatusMsg = null
    String stAppInfo = null
    HashMap hmInqProfileInp = null
    HashMap hmInqProfileResp = null
    HashMap memberHash = null
    ArrayList memberServiceList = null
    ArrayList linkedMemberList = null
    HashMap userFraudHash = null
    HashMap linkedMemberHash = null
    HashMap hmInqContactEmailInp = null
    HashMap hmUserEmailContactCPNIResp = null
    HashMap memberServiceHashMOSUB = null
    HashMap memberServiceHashMobility = null
    HashMap memberServiceHashTITAN = null
    HashMap memberServiceHashEcomm = null
    HashMap memberServiceHashMobilityPSORID = null
    HashMap hmInputDBUS = null
    HashMap ctnHash = null
    HashMap hmDbusResp = null
    HashMap hmCSIMosubResp = null
    ArrayList alSubscribers = null
    HashMap hmSubscriber = null
    HashMap hmSubscriberStatus = null
    HashMap hmDeviceInformation = null
    ArrayList alDevices = null
    HashMap hmDevice = null
    ArrayList alCBRList = new ArrayList()
    ArrayList alMemSvcRoleList = null
    ArrayList alLinkedUsersList = null
    TimeZone originalTimeZone = TimeZone.getDefault()

    def setup() {
        testObj.inquireUserContactInfoHelper = inquireUserContactInfoHelper
        testObj.inquireProfileRestClient = inquireProfileRestClient
        testObj.queryCPNIAccountContactHelper = queryCPNIAccountContactHelper
        testObj.externalDestinationHelper = externalDestinationHelper
        testObj.objCPNIDataAddressHelper = objCPNIDataAddressHelper
        testObj.oCommonUtilHelper = oCommonUtilHelper
        testObj.inquireContactInfoHelper = inquireContactInfoHelper


        System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')
        stTransactionId = 'kan_123'

        hmInput = CommonUtil.hashMap
        hmInqProfileResp = CommonUtil.hashMap
        memberHash = CommonUtil.hashMap
        userFraudHash = CommonUtil.hashMap
        memberServiceList = CommonUtil.arrayList
        linkedMemberList = CommonUtil.arrayList
        linkedMemberHash = CommonUtil.hashMap
        hmUserEmailContactCPNIResp = CommonUtil.hashMap
        memberServiceHashMOSUB = CommonUtil.hashMap
        memberServiceHashMobility = CommonUtil.hashMap
        memberServiceHashTITAN = CommonUtil.hashMap
        memberServiceHashEcomm = CommonUtil.hashMap
        memberServiceHashMobilityPSORID = CommonUtil.hashMap
        hmInputDBUS = CommonUtil.hashMap
        ctnHash = CommonUtil.hashMap
        alSubscribers = CommonUtil.arrayList
        hmSubscriber = CommonUtil.hashMap
        hmSubscriberStatus = CommonUtil.hashMap
        hmDeviceInformation = CommonUtil.hashMap
        alDevices = CommonUtil.arrayList
        hmDevice = CommonUtil.hashMap

        alMemSvcRoleList = CommonUtil.arrayList
        alLinkedUsersList = CommonUtil.arrayList

        memberHash['lastName'] = 'Panther'
        memberHash['securityQuestionId2'] = '20'
        memberHash['memberName'] = 'qayma0005163'
        memberHash['securityQuestionId1'] = '27'
        memberHash['contactEmailStatus'] = 'H'
        memberHash['memberNum'] = '123456789'
        memberHash['securityAnswer1'] = 'eKIEn0eBR/8S4i/hGh2DHqmoDv4='
        memberHash['activatedDate'] = '05252018 07:20:07'
        memberHash['activatedInd'] = 'Y'
        memberHash['passwordDirty'] = 'Y'
        memberHash['securityAnswer2'] = '7GvGs62myDnEbvS7yhhUqfrpH6A='
        memberHash['browserLanguage'] = 'es'
        memberHash['contactEmail'] = 'ash12356@gmail.com'
        memberHash['lastModifiedBy'] = 'IDP'
        memberHash['fullName'] = 'Louis Panther'
        memberHash['parentChildInd'] = 'S'
        memberHash['domainId'] = '15'
        memberHash['contactEmailEstDate'] = '02092015 09:29:12'
        memberHash['autogeneratedInd'] = 'Y'
        memberHash['firstName'] = 'Ashwin'
        memberHash['domainName'] = 'slid.dum'
        memberHash['onlQaEstDate'] = null
        memberHash['lastModified'] = '05252018 07:20:07'
        memberHash['securityQuestion2'] = 'What country would you like to visit?'
        memberHash['securityQuestion1'] = 'What is your dream job?'

        userFraudHash['userLockReason'] = 'RS'
        userFraudHash['userLockLevel'] = '1'
        userFraudHash['memberNum'] = '123456789'

        linkedMemberHash['memberNum'] = '123456789'
        linkedMemberHash['sorName'] = 'ACE'
        linkedMemberHash['lastName'] = 'DSL-PARENT'
        linkedMemberHash['memberState'] = 'INUSE'
        linkedMemberHash['mailHost'] = 'mx.att.yahoo.com'
        linkedMemberHash['gender'] = 'M'
        linkedMemberHash['slidMemberNum'] = '123456789'
        linkedMemberHash['nickName'] = 'TEST'
        linkedMemberHash['accountType'] = 'R'
        linkedMemberHash['lastModifiedBy'] = 'CDR'
        linkedMemberHash['memberName'] = 'qayma0049998'
        linkedMemberHash['fullName'] = 'TEST PARENT'
        linkedMemberHash['domainId'] = '11'
        linkedMemberHash['ban'] = null
        linkedMemberHash['deleteRequestDate'] = null
        linkedMemberHash['firstName'] = 'TEST'
        linkedMemberHash['parentChildInd'] = 'P'
        linkedMemberHash['createdBy'] = 'CDR'
        linkedMemberHash['domainName'] = 'att.net'
        linkedMemberHash['sorId'] = '1'
        linkedMemberHash['lastModified'] = '2017-03-17 03:09:26.0'
        linkedMemberHash['aggServiceStatus'] = '0'
        linkedMemberHash['passwordDirty'] = null
        linkedMemberHash['createDate'] = '2017-03-17 03:09:22.0'

        memberServiceHashMobility['sorName'] = 'MO'
        memberServiceHashMobility['roleStatusName'] = 'Enabled'
        memberServiceHashMobility['nickName'] = null
        memberServiceHashMobility['roleId'] = '2'
        memberServiceHashMobility['lastModifiedBy'] = 'MYWORLD'
        memberServiceHashMobility['roleStatusCode'] = null
        memberServiceHashMobility['sorInvariantId'] = 'd165c47fbf19aebf1a980ffd1100a2d6'
        memberServiceHashMobility['memberStatus'] = '0'
        memberServiceHashMobility['parentSorInvariantId'] = null
        memberServiceHashMobility['defaultAccount'] = 'Y'
        memberServiceHashMobility['memberNum'] = '123456789'
        memberServiceHashMobility['serviceName'] = 'MOBILITY'
        memberServiceHashMobility['cpniImpacted'] = null
        memberServiceHashMobility['parentSorId'] = null
        memberServiceHashMobility['instanceId'] = '0009057929'
        memberServiceHashMobility['dateDefaultEst'] = null
        memberServiceHashMobility['sorId'] = '13'
        memberServiceHashMobility['lastModified'] = '07282014 06:15:47'
        memberServiceHashMobility['serviceId'] = '32'
        memberServiceHashMobility['createDate'] = '07282014 06:15:47'
        memberServiceHashMobility['memberStatusName'] = 'Enabled'
        memberServiceHashMobility['roleName'] = 'OWNER'

        memberServiceHashMobilityPSORID['sorName'] = 'MO'
        memberServiceHashMobilityPSORID['roleStatusName'] = 'Enabled'
        memberServiceHashMobilityPSORID['nickName'] = null
        memberServiceHashMobilityPSORID['roleId'] = '2'
        memberServiceHashMobilityPSORID['lastModifiedBy'] = 'MYWORLD'
        memberServiceHashMobilityPSORID['roleStatusCode'] = null
        memberServiceHashMobilityPSORID['sorInvariantId'] = 'd165c47fbf19aebf1a980ffd1100a2d6'
        memberServiceHashMobilityPSORID['memberStatus'] = '0'
        memberServiceHashMobilityPSORID['parentSorInvariantId'] = 'd165c47fbf19aebf1a980ffd1100a2d6'
        memberServiceHashMobilityPSORID['defaultAccount'] = 'Y'
        memberServiceHashMobilityPSORID['memberNum'] = '123456789'
        memberServiceHashMobilityPSORID['serviceName'] = 'MOBILITY'
        memberServiceHashMobilityPSORID['cpniImpacted'] = null
        memberServiceHashMobilityPSORID['parentSorId'] = null
        memberServiceHashMobilityPSORID['instanceId'] = '0009057929'
        memberServiceHashMobilityPSORID['dateDefaultEst'] = null
        memberServiceHashMobilityPSORID['sorId'] = '13'
        memberServiceHashMobilityPSORID['lastModified'] = '07282014 06:15:47'
        memberServiceHashMobilityPSORID['serviceId'] = '32'
        memberServiceHashMobilityPSORID['createDate'] = '07282014 06:15:47'
        memberServiceHashMobilityPSORID['memberStatusName'] = 'Enabled'
        memberServiceHashMobilityPSORID['roleName'] = 'OWNER'

        memberServiceHashMOSUB['sorName'] = 'MO'
        memberServiceHashMOSUB['roleStatusName'] = 'Enabled'
        memberServiceHashMOSUB['nickName'] = null
        memberServiceHashMOSUB['roleId'] = '2'
        memberServiceHashMOSUB['lastModifiedBy'] = 'MYWORLD'
        memberServiceHashMOSUB['roleStatusCode'] = null
        memberServiceHashMOSUB['sorInvariantId'] = 'd165c47fbf19aebf1a980ffd1100a2d6'
        memberServiceHashMOSUB['memberStatus'] = '0'
        memberServiceHashMOSUB['parentSorInvariantId'] = null
        memberServiceHashMOSUB['defaultAccount'] = 'Y'
        memberServiceHashMOSUB['memberNum'] = '123456789'
        memberServiceHashMOSUB['serviceName'] = 'MOSUB'
        memberServiceHashMOSUB['cpniImpacted'] = null
        memberServiceHashMOSUB['parentSorId'] = null
        memberServiceHashMOSUB['instanceId'] = '0009057929'
        memberServiceHashMOSUB['dateDefaultEst'] = null
        memberServiceHashMOSUB['sorId'] = '13'
        memberServiceHashMOSUB['lastModified'] = '07282014 06:15:47'
        memberServiceHashMOSUB['serviceId'] = '23'
        memberServiceHashMOSUB['createDate'] = '07282014 06:15:47'
        memberServiceHashMOSUB['memberStatusName'] = 'Enabled'
        memberServiceHashMOSUB['roleName'] = null

        memberServiceHashEcomm['sorName'] = 'BDS'
        memberServiceHashEcomm['roleStatusName'] = 'Enabled'
        memberServiceHashEcomm['nickName'] = null
        memberServiceHashEcomm['roleId'] = '2'
        memberServiceHashEcomm['lastModifiedBy'] = 'MYWORLD'
        memberServiceHashEcomm['roleStatusCode'] = null
        memberServiceHashEcomm['sorInvariantId'] = 'd165c47fbf19aebf1a980ffd1100a2d6'
        memberServiceHashEcomm['memberStatus'] = '0'
        memberServiceHashEcomm['parentSorInvariantId'] = null
        memberServiceHashEcomm['defaultAccount'] = 'Y'
        memberServiceHashEcomm['memberNum'] = '123456789'
        memberServiceHashEcomm['serviceName'] = 'ECOMM'
        memberServiceHashEcomm['cpniImpacted'] = null
        memberServiceHashEcomm['parentSorId'] = null
        memberServiceHashEcomm['instanceId'] = '0009057929'
        memberServiceHashEcomm['dateDefaultEst'] = null
        memberServiceHashEcomm['sorId'] = '13'
        memberServiceHashEcomm['lastModified'] = '07282014 06:15:47'
        memberServiceHashEcomm['serviceId'] = '10'
        memberServiceHashEcomm['createDate'] = '07282014 06:15:47'
        memberServiceHashEcomm['memberStatusName'] = 'Enabled'
        memberServiceHashEcomm['roleName'] = 'OWNER'

        memberServiceHashTITAN['sorName'] = 'LS'
        memberServiceHashTITAN['roleStatusName'] = 'Enabled'
        memberServiceHashTITAN['nickName'] = null
        memberServiceHashTITAN['roleId'] = '2'
        memberServiceHashTITAN['lastModifiedBy'] = 'MYWORLD'
        memberServiceHashTITAN['roleStatusCode'] = null
        memberServiceHashTITAN['sorInvariantId'] = 'd165c47fbf19aebf1a980ffd1100a2d6'
        memberServiceHashTITAN['memberStatus'] = '0'
        memberServiceHashTITAN['parentSorInvariantId'] = null
        memberServiceHashTITAN['defaultAccount'] = 'Y'
        memberServiceHashTITAN['memberNum'] = '123456789'
        memberServiceHashTITAN['serviceName'] = 'TITAN'
        memberServiceHashTITAN['cpniImpacted'] = null
        memberServiceHashTITAN['parentSorId'] = null
        memberServiceHashTITAN['instanceId'] = '0009057929'
        memberServiceHashTITAN['dateDefaultEst'] = null
        memberServiceHashTITAN['sorId'] = '13'
        memberServiceHashTITAN['lastModified'] = '07282014 06:15:47'
        memberServiceHashTITAN['serviceId'] = '33'
        memberServiceHashTITAN['createDate'] = '07282014 06:15:47'
        memberServiceHashTITAN['memberStatusName'] = 'Enabled'
        memberServiceHashTITAN['roleName'] = 'OWNER'

        linkedMemberList.add(linkedMemberHash)

        hmInqProfileResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG)
        hmInqProfileResp['member'] = memberHash

        hmInqProfileResp['linkedMember'] = linkedMemberList
        hmInqProfileResp['userfraudlock'] = userFraudHash
        hmInqProfileResp['memberServiceRole'] = memberServiceList
        ctnHash['transactionName'] = 'QueryCPNIUserContactInfo'
        ctnHash['ctn'] = '0009057929'
        ctnHash['callingSystemId'] = 'IDP'
        ctnHash['transactionId'] = stTransactionId
        ctnHash['eventname'] = 'QueryCSIInquireSubscriberProfile'
        ctnHash['mask'] = 'SD:DI'

        hmInputDBUS['mosubCTN'] = ctnHash

        hmDevice[CommonDefs.SMS_CAPABILITY_INDICATOR] = 'true'

        alDevices.add(hmDevice)

        hmDeviceInformation[CommonDefs.DEVICE] = alDevices

        hmSubscriberStatus[CommonDefs.SUBSCRIBER_STATUS] = 'A'

        hmSubscriber[CommonDefs.DEVICE_INFORMATION] = hmDeviceInformation

        hmSubscriber['SubscriberStatus'] = hmSubscriberStatus

        hmSubscriber[CommonDefs.SIM_SWAP_DATE] = '2018-09-09'

        hmSubscriber[CommonDefs.SUBSCRIBER_NUMBER] = '0009057929'
        hmSubscriber[CommonDefs.BILLING_ACCOUNT_NUMBER] = 'd165c47fbf19aebf1a980ffd1100a2d6'
        alSubscribers.add(hmSubscriber)

        HashMap hmAccount = new HashMap<>()
        hmAccount['id'] = 'd165c47fbf19aebf1a980ffd1100a2d6'
        hmCSIMosubResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG)
        ObjectMapper objectMapper = new ObjectMapper()
        ArrayNode anSubscribers = objectMapper.valueToTree(alSubscribers)
        hmCSIMosubResp['subscribers'] = anSubscribers
        hmCSIMosubResp['accounts'] = hmAccount

        hmDbusResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG)
        hmDbusResp['mosubCTN'] = hmCSIMosubResp

        hmUserEmailContactCPNIResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
                CErrorDefs.COMMON_SUCCESS_MSG)
        hmUserEmailContactCPNIResp['contactEmailValid'] = 'Y'
        hmUserEmailContactCPNIResp['contactEmail'] = 'qayma0064110@att.net'
        hmUserEmailContactCPNIResp['contactEmailStatus'] = 'V'
        hmUserEmailContactCPNIResp['contactEmailEstDate'] = '06082018 06:10:30'
        hmUserEmailContactCPNIResp['previousContactEmail'] = null

        alCBRList.add('userCBRList')
        alCBRList.add('accountCBRList')

        resultHashSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
                CErrorDefs.COMMON_SUCCESS_MSG)
        stAppInfo = 'Error returned from Helper'
        resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo)

        ReflectionTestUtils.setField(testObj, 'stValidCPNIAccts', 'MOBILITY|TITAN|ECOMM')
        ReflectionTestUtils.setField(testObj, 'sSimSwapAgingDays', '2')
        TimeZone.setDefault(TimeZone.getTimeZone("GMT"))
    }


    def "query cpni user contact null #scenarioName"() throws Exception {
        given:
        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> response
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContact'
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == expectedAppInfo

        where: 'response from queryCPNIAccountContactHelper in different senarios'
        scenarioName         | response                | expectedAppInfo
        "null response"      | null                    | "Null Response returned from InquireProfileRestClient.postInquireProfileSyncCall()"
        "empty HashMap"      | new HashMap<>()         | "Null Response returned from InquireProfileRestClient.postInquireProfileSyncCall()"

    }




    def "query cpni user contact a j s c error"() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.GUID] = '123456789'
        hmInput[CommonDefs.TRANSID] = stTransactionId

        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> resultHashError
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Error returned from Helper'
    }

//    Prashant
    def "query cpni user contact a j s c error | scenario guid == empty"() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.GUID] = ''
        hmInput[CommonDefs.TRANSID] = stTransactionId

        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> resultHashError
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Error returned from Helper'
    }



    def "query cpni user contact member hash domain error #scenarioName"() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.GUID] = sGuid
        hmInput[CommonDefs.TRANSID] = stTransactionId

        memberHash['domainName'] = 'att.net'

        hmInqProfileInp = CommonUtil.hashMap
        hmInqProfileInp[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInqProfileInp[CommonDefs.LEVEL] = 'LM'
        hmInqProfileInp['isExternalCall'] = 'N'
        hmInqProfileInp[CommonDefs.MS_NAME] = 'MOUP'
        hmInqProfileInp[CommonDefs.TRANSID] = stTransactionId
        hmInqProfileInp[CommonDefs.GUID] = '123456789'

        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> hmInqProfileResp
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == expectedAppInfo

        where: 'sDBDomain domain scenarioName'
        sGuid | scenarioName | expectedAppInfo
        "123456789"  | "invalid"    | 'Input Member is not an Access ID'
        " "      | "empty"      | 'Input Member is not an Access ID'
    }


    def "query cpni user contact user error"() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.HANDLE] = 'qayma0005163'
        hmInput[CommonDefs.DOMAIN] = 'slid.dum'
        hmInput[CommonDefs.TRANSID] = stTransactionId

        alMemSvcRoleList.add(memberServiceHashMOSUB)

        hmInqProfileResp['memberServiceRole'] = alMemSvcRoleList

        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> hmInqProfileResp
        inquireUserContactInfoHelper.inquireUserContactInfo(_) >> resultHashError
        externalDestinationHelper.callMultipleDestinations(_) >> hmDbusResp
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }
    // prashant
    def "query cpni user contact user with handle #Scenario error "() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.HANDLE] = sHandle
        //hmInput[CommonDefs.DOMAIN] = 'slid.dum'
        hmInput[CommonDefs.TRANSID] = stTransactionId

        alMemSvcRoleList.add(memberServiceHashMOSUB)

        hmInqProfileResp['memberServiceRole'] = alMemSvcRoleList

        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> hmInqProfileResp
        inquireUserContactInfoHelper.inquireUserContactInfo(_) >> resultHashError
        externalDestinationHelper.callMultipleDestinations(_) >> hmDbusResp
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == expectedAppInfo
        where: 'handle scenarioName'
        sHandle | Scenario | expectedAppInfo
        null    | "null"  | 'SUCCESS'
        ""      | "empty" | 'SUCCESS'

    }

    def "query cpni user contact user with Domain #Scenario error "() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.HANDLE] = ""
        hmInput[CommonDefs.DOMAIN] = sDomain
        hmInput[CommonDefs.TRANSID] = stTransactionId

        alMemSvcRoleList.add(memberServiceHashMOSUB)

        hmInqProfileResp['memberServiceRole'] = alMemSvcRoleList

        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> hmInqProfileResp
        resultHashError[CommonDefs.COMMON_APP_CATEGORY_CODE] = '2'
        inquireUserContactInfoHelper.inquireUserContactInfo(_) >> resultHashError
        externalDestinationHelper.callMultipleDestinations(_) >> hmDbusResp
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == expectedAppInfo
        where :'domain scenarioName'
        sDomain | Scenario | expectedAppInfo
        null | "null" | 'SUCCESS'
        "" | "empty" | 'SUCCESS'
    }


    def "query cpni user contact user m o b i l i t y s u c c e s s"() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.HANDLE] = 'qayma0005163'
        hmInput[CommonDefs.DOMAIN] = 'slid.dum'
        hmInput[CommonDefs.TRANSID] = stTransactionId

        memberServiceList.add(memberServiceHashMobility)

        hmInqProfileResp['linkedMember'] = memberServiceList

        ArrayList alAcctContactList = CommonUtil.arrayList
        HashMap hmAcctContactCPNIResp = CommonUtil.hashMap
        alAcctContactList.add(hmAcctContactCPNIResp)
        HashMap<String, Object> contactWithUSPhone = new HashMap<>()
        contactWithUSPhone.put(CommonDefs.US_PHONE_NUMBER, "1234567890")
        contactWithUSPhone.put("otherKey", "otherValue")

        hmAcctContactCPNIResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
                CErrorDefs.COMMON_SUCCESS_MSG)
        hmAcctContactCPNIResp[CommonDefs.ACCOUNT_CONTACT_LIST] = contactWithUSPhone
        hmAcctContactCPNIResp['mosubCTN'] = hmCSIMosubResp
        queryCPNIAccountContactHelper.queryCPNIAccountContact(_, _, _) >> hmAcctContactCPNIResp
        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> hmInqProfileResp
        inquireUserContactInfoHelper.inquireUserContactInfo(_) >> hmUserEmailContactCPNIResp
        externalDestinationHelper.callMultipleDestinations(_) >> hmDbusResp
        objCPNIDataAddressHelper.validateCPNIAddress(_) >> resultHashSuccess
        queryCPNIAccountContactHelper.queryCPNIAccountContact(_) >> hmAcctContactCPNIResp
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

//    Prashant
    def "query cpni user contact user m o b i l i t y s u c c e s s | validateCPNIAddress error"() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.HANDLE] = 'qayma0005163'
        hmInput[CommonDefs.DOMAIN] = 'slid.dum'
        hmInput[CommonDefs.TRANSID] = stTransactionId

        memberServiceList.add(memberServiceHashMobility)

        hmInqProfileResp['linkedMember'] = memberServiceList

        ArrayList alAcctContactList = CommonUtil.arrayList
        HashMap hmAcctContactCPNIResp = CommonUtil.hashMap
        alAcctContactList.add(hmAcctContactCPNIResp)

        hmAcctContactCPNIResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
                CErrorDefs.COMMON_SUCCESS_MSG)
        hmAcctContactCPNIResp[CommonDefs.ACCOUNT_CONTACT_LIST] = hmAcctContactCPNIResp
        hmAcctContactCPNIResp['mosubCTN'] = hmCSIMosubResp
        queryCPNIAccountContactHelper.queryCPNIAccountContact(_, _, _) >> hmAcctContactCPNIResp
        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> hmInqProfileResp
        inquireUserContactInfoHelper.inquireUserContactInfo(_) >> hmUserEmailContactCPNIResp
        externalDestinationHelper.callMultipleDestinations(_) >> hmDbusResp
        resultHashError[CommonDefs.COMMON_APP_CATEGORY_CODE] = '3'
        objCPNIDataAddressHelper.validateCPNIAddress(_) >> resultHashError
        queryCPNIAccountContactHelper.queryCPNIAccountContact(_) >> resultHashSuccess
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "query cpni user contact user m o b i l i t y s u c c e s s | queryCPNIAccountContact error"() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.HANDLE] = 'qayma0005163'
        hmInput[CommonDefs.DOMAIN] = 'slid.dum'
        hmInput[CommonDefs.TRANSID] = stTransactionId

        memberServiceList.add(memberServiceHashMobility)

        hmInqProfileResp['linkedMember'] = memberServiceList

        ArrayList alAcctContactList = CommonUtil.arrayList
        HashMap hmAcctContactCPNIResp = CommonUtil.hashMap
        alAcctContactList.add(hmAcctContactCPNIResp)

        hmAcctContactCPNIResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
                CErrorDefs.COMMON_SUCCESS_MSG)
        hmAcctContactCPNIResp[CommonDefs.ACCOUNT_CONTACT_LIST] = hmAcctContactCPNIResp
        hmAcctContactCPNIResp['mosubCTN'] = hmCSIMosubResp
        queryCPNIAccountContactHelper.queryCPNIAccountContact(_, _, _) >> hmAcctContactCPNIResp
        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> hmInqProfileResp
        inquireUserContactInfoHelper.inquireUserContactInfo(_) >> hmUserEmailContactCPNIResp
        externalDestinationHelper.callMultipleDestinations(_) >> hmDbusResp
        resultHashError[CommonDefs.COMMON_APP_CATEGORY_CODE] = '3'
        objCPNIDataAddressHelper.validateCPNIAddress(_) >> resultHashSuccess
        queryCPNIAccountContactHelper.queryCPNIAccountContact(_) >> resultHashError
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "query cpni user contact user m o b i l i t y s u c c e s s having email key"() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.HANDLE] = 'qayma0005163'
        hmInput[CommonDefs.DOMAIN] = 'slid.dum'
        hmInput[CommonDefs.TRANSID] = stTransactionId

        memberServiceList.add(memberServiceHashMobility)

        hmInqProfileResp['linkedMember'] = memberServiceList
        HashMap<String, Object> hmCPNIDataAddressResult = new HashMap<>()
        ArrayList<HashMap<String, Object>> alValidAddresses = new ArrayList<>()
        HashMap<String, Object> validAddress = new HashMap<>()
        validAddress.put(CommonDefs.KEY_EMAIL_ADDRESS, "test@example.com")
        validAddress.put(CommonDefs.KEY_CONTACT_TYPE, "Primary")
        validAddress.put(CommonDefs.KEY_CONTACT_STATUS, "Active")
        validAddress.put(CommonDefs.KEY_EMAIL_EST_DATE, "2023-10-01")
        alValidAddresses.add(validAddress)
        hmCPNIDataAddressResult.put(CommonDefs.VALID_CPNI_ADDRESSES, alValidAddresses)
        hmCPNIDataAddressResult.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)

        ArrayList alAcctContactList = CommonUtil.arrayList
        HashMap hmAcctContactCPNIResp = CommonUtil.hashMap
        alAcctContactList.add(hmAcctContactCPNIResp)

        hmAcctContactCPNIResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
                CErrorDefs.COMMON_SUCCESS_MSG)
        hmAcctContactCPNIResp[CommonDefs.ACCOUNT_CONTACT_LIST] = hmAcctContactCPNIResp
        hmAcctContactCPNIResp['mosubCTN'] = hmCSIMosubResp
        queryCPNIAccountContactHelper.queryCPNIAccountContact(_, _, _) >> hmAcctContactCPNIResp
        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> hmInqProfileResp
        inquireUserContactInfoHelper.inquireUserContactInfo(_) >> hmUserEmailContactCPNIResp
        externalDestinationHelper.callMultipleDestinations(_) >> hmDbusResp
        objCPNIDataAddressHelper.validateCPNIAddress(_) >> hmCPNIDataAddressResult
        queryCPNIAccountContactHelper.queryCPNIAccountContact(_) >> resultHashSuccess
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "query cpni user contact user m o b i l i t y Error in validateCPNIAddress "() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.HANDLE] = 'qayma0005163'
        hmInput[CommonDefs.DOMAIN] = 'slid.dum'
        hmInput[CommonDefs.TRANSID] = stTransactionId

        memberServiceList.add(memberServiceHashMobility)

        hmInqProfileResp['linkedMember'] = memberServiceList

        ArrayList alAcctContactList = CommonUtil.arrayList
        HashMap hmAcctContactCPNIResp = CommonUtil.hashMap
        alAcctContactList.add(hmAcctContactCPNIResp)

        hmAcctContactCPNIResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
                CErrorDefs.COMMON_SUCCESS_MSG)
        hmAcctContactCPNIResp[CommonDefs.ACCOUNT_CONTACT_LIST] = hmAcctContactCPNIResp
        hmAcctContactCPNIResp['mosubCTN'] = hmCSIMosubResp
        queryCPNIAccountContactHelper.queryCPNIAccountContact(_, _, _) >> hmAcctContactCPNIResp
        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> hmInqProfileResp
        inquireUserContactInfoHelper.inquireUserContactInfo(_) >> hmUserEmailContactCPNIResp
        externalDestinationHelper.callMultipleDestinations(_) >> hmDbusResp
        resultHashError[CommonDefs.COMMON_APP_CATEGORY_CODE] = '2'
        objCPNIDataAddressHelper.validateCPNIAddress(_) >> resultHashError
        queryCPNIAccountContactHelper.queryCPNIAccountContact(_) >> resultHashSuccess
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "query cpni user contact user m o s u b s u c c e s s"() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.HANDLE] = 'qayma0005163'
        hmInput[CommonDefs.DOMAIN] = 'slid.dum'
        hmInput[CommonDefs.TRANSID] = stTransactionId

        memberServiceList.add(memberServiceHashMOSUB)

        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> hmInqProfileResp
        inquireUserContactInfoHelper.inquireUserContactInfo(_) >> hmUserEmailContactCPNIResp
        objCPNIDataAddressHelper.validateCPNIAddress(_) >> resultHashSuccess
        externalDestinationHelper.callMultipleDestinations(_) >> hmDbusResp
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "query cpni user contact user t i t a n s u c c e s s"() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.HANDLE] = 'qayma0005163'
        hmInput[CommonDefs.DOMAIN] = 'slid.dum'
        hmInput[CommonDefs.TRANSID] = stTransactionId

        memberServiceList.add(memberServiceHashTITAN)

        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> hmInqProfileResp
        inquireUserContactInfoHelper.inquireUserContactInfo(_) >> hmUserEmailContactCPNIResp
        objCPNIDataAddressHelper.validateCPNIAddress(_) >> resultHashSuccess
        externalDestinationHelper.callMultipleDestinations(_) >> hmDbusResp
        queryCPNIAccountContactHelper.queryCPNIAccountContact(_) >> resultHashSuccess
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'


    }


    def "query cpni user contact m o s u b process s u c c e s s"() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.HANDLE] = 'qayma0005163'
        hmInput[CommonDefs.DOMAIN] = 'slid.dum'
        hmInput[CommonDefs.TRANSID] = stTransactionId

        memberServiceList.add(memberServiceHashMOSUB)

        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> hmInqProfileResp
        inquireUserContactInfoHelper.inquireUserContactInfo(_) >> hmUserEmailContactCPNIResp
        externalDestinationHelper.callMultipleDestinations(_) >> hmDbusResp

        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "query cpni user contact user mobility m o s u b s u c c e s s"() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.HANDLE] = 'qayma0005163'
        hmInput[CommonDefs.DOMAIN] = 'slid.dum'
        hmInput[CommonDefs.TRANSID] = stTransactionId

        memberServiceList.add(memberServiceHashMobility)
        memberServiceList.add(memberServiceHashMOSUB)

        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> hmInqProfileResp
        inquireUserContactInfoHelper.inquireUserContactInfo(_) >> hmUserEmailContactCPNIResp
        objCPNIDataAddressHelper.validateCPNIAddress(_) >> resultHashSuccess
        queryCPNIAccountContactHelper.queryCPNIAccountContact(_) >> resultHashSuccess
        externalDestinationHelper.callMultipleDestinations(_) >> hmDbusResp
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "query cpni user contact user mobility t i t i a n m o s u b s u c c e s s"() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.HANDLE] = 'qayma0005163'
        hmInput[CommonDefs.DOMAIN] = 'slid.dum'
        hmInput[CommonDefs.TRANSID] = stTransactionId

        memberServiceList.add(memberServiceHashMobility)
        memberServiceList.add(memberServiceHashMOSUB)
        memberServiceList.add(memberServiceHashTITAN)

        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> hmInqProfileResp
        inquireUserContactInfoHelper.inquireUserContactInfo(_) >> hmUserEmailContactCPNIResp
        objCPNIDataAddressHelper.validateCPNIAddress(_) >> resultHashSuccess
        queryCPNIAccountContactHelper.queryCPNIAccountContact(_) >> resultHashSuccess
        externalDestinationHelper.callMultipleDestinations(_) >> hmDbusResp

        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "query cpni user contact user titanized mobility s u c c e s s"() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.HANDLE] = 'qayma0005163'
        hmInput[CommonDefs.DOMAIN] = 'slid.dum'
        hmInput[CommonDefs.TRANSID] = stTransactionId

        memberServiceList.add(memberServiceHashMobilityPSORID)
        memberServiceList.add(memberServiceHashMobility)
        memberServiceList.add(memberServiceHashMOSUB)
        memberServiceList.add(memberServiceHashTITAN)

        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> hmInqProfileResp
        inquireUserContactInfoHelper.inquireUserContactInfo(_) >> hmUserEmailContactCPNIResp
        objCPNIDataAddressHelper.validateCPNIAddress(_) >> resultHashSuccess
        queryCPNIAccountContactHelper.queryCPNIAccountContact(_) >> resultHashSuccess
        externalDestinationHelper.callMultipleDestinations(_) >> hmDbusResp
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "query cpni user contact user no linked users s u c c e s s"() throws Exception {
        given:
        hmInqProfileResp['linkedmember'] = null

        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.HANDLE] = 'qayma0005163'
        hmInput[CommonDefs.DOMAIN] = 'slid.dum'
        hmInput[CommonDefs.TRANSID] = stTransactionId

        memberServiceHashMobility['parentSorInvariantId'] = 'd165c47fbf19aebf1a980ffd1100a2d6'

        memberServiceList.add(memberServiceHashMobility)
        memberServiceList.add(memberServiceHashMOSUB)
        memberServiceList.add(memberServiceHashTITAN)

        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> hmInqProfileResp
        inquireUserContactInfoHelper.inquireUserContactInfo(_) >> hmUserEmailContactCPNIResp
        objCPNIDataAddressHelper.validateCPNIAddress(_) >> resultHashSuccess
        queryCPNIAccountContactHelper.queryCPNIAccountContact(_) >> resultHashSuccess
        externalDestinationHelper.callMultipleDestinations(_) >> hmDbusResp
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "query cpni user contact exception case"() {
        given:
        hmInput[CommonDefs.GUID] = 12345

        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)

        then:
        //hmResult[CommonDefs.COMMON_APP_INFO] == 'SYSTEM ERROR'
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "query cpni user contact user return c b r s u c c e s s"() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.HANDLE] = 'qayma0005163'
        hmInput[CommonDefs.DOMAIN] = 'slid.dum'
        hmInput[CommonDefs.TRANSID] = stTransactionId
        hmInput['returnCBRCTNs'] = 'Y'

        memberServiceList.add(memberServiceHashTITAN)

        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> hmInqProfileResp
        inquireUserContactInfoHelper.inquireUserContactInfo(_) >> hmUserEmailContactCPNIResp
        inquireContactInfoHelper.inquireContactInfo(_, _) >> resultHashError
        objCPNIDataAddressHelper.validateCPNIAddress(_) >> resultHashSuccess
        queryCPNIAccountContactHelper.queryCPNIAccountContact(_) >> resultHashSuccess
        externalDestinationHelper.callMultipleDestinations(_) >> hmDbusResp
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "query cpni user contact user s u c c e s s c b r list"() throws Exception {
        given:
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryCPNIUserContactInfo'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput['isExternalCall'] = 'Y'
        hmInput[CommonDefs.HANDLE] = 'qayma0005163'
        hmInput[CommonDefs.DOMAIN] = 'slid.dum'
        hmInput[CommonDefs.TRANSID] = stTransactionId
        hmInput['returnCBRCTNs'] = 'Y'

        resultHashSuccess['userCBRList'] = alCBRList
        resultHashSuccess['accountCBRList'] = alCBRList

        memberServiceList.add(memberServiceHashTITAN)

        inquireProfileRestClient.postInquireProfileSyncCall(_, _, _) >> hmInqProfileResp
        inquireUserContactInfoHelper.inquireUserContactInfo(_) >> hmUserEmailContactCPNIResp
        inquireContactInfoHelper.inquireContactInfo(_, _) >> resultHashSuccess
        objCPNIDataAddressHelper.validateCPNIAddress(_) >> resultHashSuccess
        queryCPNIAccountContactHelper.queryCPNIAccountContact(_) >> resultHashSuccess
        externalDestinationHelper.callMultipleDestinations(_) >> hmDbusResp
        when:
        hmResult = testObj.queryCPNIUserContact(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }

    def "formatDate should return formatted date for valid input"() {
        given:
        String sDateKey = CommonDefs.CUSTOMER_ACTIVE_DATE
        String sDateValue = "2023-10-01"
         when:
        String result = QueryCPNIUserContactHelper.formatDate(sDateKey, sDateValue)

        then:
        result == "10012023 00:00:00"

    }

    def "formatDate should handle invalid sDateKey"() {
        given:
        String sDateKey = "INVALID_KEY"
        String sDateValue = "2023-10-01"
        when:
        String result = QueryCPNIUserContactHelper.formatDate(sDateKey, sDateValue)

        then:
        result == null

    }

    def "formatDate should handle invalid sDateValue"() {
        given:
        String sDateKey = "CUSTOMER_ACTIVE_DATE"
        String sDateValue = "invalid-date"
        when:
        String result = QueryCPNIUserContactHelper.formatDate(sDateKey, sDateValue)

        then:
        result == null

    }

    def "formatDate should handle exception"() {
        given:
        String sDateKey = "simSwapDate"
        String sDateValue = "2025-02-13 00:00:00"
        when:
        String result = QueryCPNIUserContactHelper.formatDate(sDateKey, sDateValue)

        then:
        result == "02132025 00:00:00"

    }

    def "formatDate should handle exception1"() {
        given:
        String sDateKey = CommonDefs.CUSTOMER_ACTIVE_DATE
        String sDateValue = "2023-10-01T12:00:00Z"
        when:
        String result = QueryCPNIUserContactHelper.formatDate(sDateKey, sDateValue)

        then:
        result == "10012023 00:00:00"

    }
    def "formatDate should handle exception2"() {
        given:
        String sDateKey = CommonDefs.TIME_MODIFIED
        String sDateValue = "2023-10-01T12:00:00Z"
        when:
        String result = QueryCPNIUserContactHelper.formatDate(sDateKey, sDateValue)

        then:
        result == "10012023 00:00:00"

    }
    def "formatDate should handle exception3"() {
        given:
        String sDateKey = "EmailAddrLastUpdateTs"
        String sDateValue = "2023-10-01T12:00:00Z"
        when:
        String result = QueryCPNIUserContactHelper.formatDate(sDateKey, sDateValue)

        then:
        result == "10012023 00:00:00"

    }
    def "formatDate should handle exception4"() {
        given:
        String sDateKey = "establishDate"
        String sDateValue = "2023-10-01T12:00:00Z"
        when:
        String result = QueryCPNIUserContactHelper.formatDate(sDateKey, sDateValue)

        then:
        result == "10012023 00:00:00"

    }
    def "should process valid addresses and update response"() {
        given:
        HashMap<String, Object> hmInput = new HashMap<>()
        HashMap<String, Object> hmMemberDBInfo = new HashMap<>()
        HashMap<String, Object> hmUserContactEmail = new HashMap<>()
        HashMap<String, Object> hmCPNIDataAddressResult = new HashMap<>()
        ArrayList<HashMap<String, Object>> alValidAddresses = new ArrayList<>()
        HashMap<String, Object> validAddress = new HashMap<>()
        validAddress.put(CommonDefs.KEY_EMAIL_ADDRESS, "test@example.com")
        validAddress.put(CommonDefs.KEY_CONTACT_TYPE, "Primary")
        validAddress.put(CommonDefs.KEY_CONTACT_STATUS, "Active")
        validAddress.put(CommonDefs.KEY_EMAIL_EST_DATE, "2023-10-01")
        alValidAddresses.add(validAddress)
        hmCPNIDataAddressResult.put(CommonDefs.VALID_CPNI_ADDRESSES, alValidAddresses)
        hmCPNIDataAddressResult.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        hmUserContactEmail.put(CommonDefs.CONTACT_EMAIL, "test@example.com")
        hmUserContactEmail.put(CommonDefs.CONTACT_EMAIL_STATUS, "Active")
        hmUserContactEmail.put(CommonDefs.CONTACT_EMAIL_EST_DATE, "2023-10-01")
        hmMemberDBInfo.put(CommonDefs.CREATE_DATE, "2023-01-01")

        when:
        objCPNIDataAddressHelper.validateCPNIAddress(_) >> hmCPNIDataAddressResult
        HashMap<String, Object> hmResponse = testObj.processUserCPNIAddresses(hmInput, hmMemberDBInfo, hmUserContactEmail)

        then:
        hmResponse.containsKey(CommonDefs.KEY_EMAIL)
        HashMap<String, Object> hmEmail = hmResponse.get(CommonDefs.KEY_EMAIL)
        hmEmail.get(CommonDefs.CONTACT_EMAIL) == "test@example.com"
        HashMap<String, Object> hmGeneralContactDetails = hmEmail.get(CommonDefs.GENERAL_CONTACT_DETAILS)
        hmGeneralContactDetails.get(CommonDefs.CONTACT_TYPE) == "Primary"
        hmGeneralContactDetails.get(CommonDefs.CONTACT_STATUS) == "Active"
        hmGeneralContactDetails.get(CommonDefs.ESTABLISHED_DATE) == "2023-10-01"
        hmGeneralContactDetails.get(CommonDefs.CPNI_ELGIBLE) == CommonDefs.IND_Y
    }
    def "should process valid MOSUB addresses and update response"() {
        given:
        HashMap<String, Object> hmInput = new HashMap<>()
        HashMap<String, Object> hmMOSUB = new HashMap<>()
        HashMap<String, Object> hmCSIMosubResp = new HashMap<>()
        ArrayList<HashMap<String, Object>> alSubscribers = new ArrayList<>()
        HashMap<String, Object> subscriber = new HashMap<>()
        subscriber.put(CommonDefs.SUBSCRIBER_NUMBER, "12345")
        subscriber.put(CommonDefs.SIM_SWAP_DATE, "2023-10-01T12:00:00Z")
        HashMap<String, Object> subscriberStatus = new HashMap<>()
        subscriberStatus.put(CommonDefs.SUBSCRIBER_STATUS, CommonDefs.ACTIVE)
        subscriber.put("SubscriberStatus", subscriberStatus)
        HashMap<String, Object> deviceInformation = new HashMap<>()
        ArrayList<HashMap<String, Object>> devices = new ArrayList<>()
        HashMap<String, Object> device = new HashMap<>()
        device.put(CommonDefs.SMS_CAPABILITY_INDICATOR, CommonDefs.DEFAULT_TRUE)
        devices.add(device)
        deviceInformation.put(CommonDefs.DEVICE, devices)
        subscriber.put(CommonDefs.DEVICE_INFORMATION, deviceInformation)
        alSubscribers.add(subscriber)
        hmCSIMosubResp.put(CommonDefs.CSI_SUBSCRIBER, alSubscribers)
        hmCSIMosubResp.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        hmMOSUB.put(CommonDefs.INSTANCE_ID, "12345")
        hmMOSUB.put(CommonDefs.DATE_DEFAULT_EST, "2023-01-01")

        when:
        oCommonUtilHelper.checkAging(_, _) >> true
        HashMap<String, Object> hmResponse = testObj.processMOSUBCPNIAddresses(hmInput, hmMOSUB, hmCSIMosubResp)

        then:
        hmResponse != null
    }
    def "should process valid MOSUB addresses and update response2"() {
        given:
        HashMap<String, Object> hmInput = new HashMap<>()
        HashMap<String, Object> hmMOSUB = new HashMap<>()
        HashMap<String, Object> hmCSIMosubResp = new HashMap<>()
        ArrayList<HashMap<String, Object>> alSubscribers = new ArrayList<>()
        HashMap<String, Object> subscriber = new HashMap<>()
        subscriber.put(CommonDefs.SUBSCRIBER_NUMBER, "12345")
        subscriber.put(CommonDefs.SIM_SWAP_DATE, "2023-10-01T12:00:00Z")
        HashMap<String, Object> subscriberStatus = new HashMap<>()
        subscriberStatus.put(CommonDefs.SUBSCRIBER_STATUS, CommonDefs.ACTIVE)
        subscriber.put("SubscriberStatus", subscriberStatus)
        HashMap<String, Object> deviceInformation = new HashMap<>()
        ArrayList<HashMap<String, Object>> devices = new ArrayList<>()
        HashMap<String, Object> device = new HashMap<>()
        device.put(CommonDefs.SMS_CAPABILITY_INDICATOR, CommonDefs.DEFAULT_TRUE)
        devices.add(device)
        deviceInformation.put(CommonDefs.DEVICE, devices)
        subscriber.put(CommonDefs.DEVICE_INFORMATION, deviceInformation)
        alSubscribers.add(subscriber)
        hmCSIMosubResp.put(CommonDefs.CSI_SUBSCRIBER, alSubscribers)
        hmCSIMosubResp.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        hmMOSUB.put(CommonDefs.INSTANCE_ID, "12345")
        hmMOSUB.put(CommonDefs.DATE_DEFAULT_EST, "2023-01-01")
        oCommonUtilHelper.checkAging(_, _) >> true
        when:

        HashMap<String, Object> hmResponse = testObj.processMOSUBCPNIAddresses(hmInput, hmMOSUB, hmCSIMosubResp)

        then:
        hmResponse != null
    }



    def cleanup() {
        TimeZone.setDefault(originalTimeZone)
    }
}
