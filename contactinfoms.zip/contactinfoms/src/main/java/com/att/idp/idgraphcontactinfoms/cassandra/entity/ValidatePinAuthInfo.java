package com.att.idp.idgraphcontactinfoms.cassandra.entity;

import java.util.Date;

import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.Indexed;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

/*
 * table definition
 * CREATE TABLE IDM_AUTHENTICATION_INFO ( SESSION_ID TEXT,
 *  AUTHENTICATION_METHOD TEXT,
 *  ACCOUNT_TYPE TEXT,
 *  ACCOUNT_NUMBER TEXT,
 *  STATUS TEXT,
 *  FAILURE_REASON TEXT,
 *  CREATE_DATE TIMESTAMP,
 *  CHANNEL TEXT,
 *  PRIMARY KEY (SESSION_ID , CREATE_DATE))
 *  WITH CLUSTERING ORDER BY (CREATE_DATE DESC);
 * 
 */

/**
 * The ValidatePinAuthInfo class represents the IDM_AUTHENTICATION_INFO table in the Cassandra database.
 * It contains various fields that map to the columns in the table.
 * 
 * The class uses the Lombok library to automatically generate getters and setters for the fields.
 * It also uses annotations from the Spring Data Cassandra and Jackson libraries for ORM mapping and JSON serialization/deserialization respectively.
 * 
 * The primary key for the table is a composite key consisting of the session ID and the creation date.
 */

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
//@Table(value = "IDM_AUTHENTICATION_INFO")
@Table(value = "idm_authentication_info")
public class ValidatePinAuthInfo {
	
	/**
	 * Constructor for the ValidateCredAuthInfo class.
	 *
	 * @param sId A SessionId object that contains the session ID.
	 */
	public ValidatePinAuthInfo(SessionId sId) {
		super();
		this.sId = sId;
		  if(sId != null) { setSessionId(sId.getSessionId()); }
	}
	
	@PrimaryKey
    private SessionId sId;

	//@Column(value = "SESSION_ID")
	@Column(value = "session_id")
	private String sessionId;
	
	//@Column(value = "AUTHENTICATION_METHOD")
	@Column(value = "authentication_method")
	private String authMethod;
	
	//@Column(value = "ACCOUNT_TYPE")
	@Column(value = "account_type")
	private String accountType;
	
	//@Column(value = "ACCOUNT_NUMBER")
	//@Indexed(value="account_number")
	@Column(value = "account_number")
	private String accountNumber;
	
	//@Column(value = "STATUS")
	@Column(value = "status")
	private String status;
	
	//@Column(value = "FAILURE_REASON")
	@Column(value = "failure_reason")
	private String failureReason;
	
	//@PrimaryKeyColumn(name="CREATE_DATE",ordinal = 1,type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING )
	//@Column(value = "CREATE_DATE")
	@Column(value = "create_date")
	private Date createdDate;
	
	//@Column(value = "CHANNEL")
	@Column(value = "channel")
	private String channel;
	
	//@Column(value = "EMAIL_ADDRESS")
	@Column(value = "email_address")
	private String emailAddress;
	
	//@Column(value = "PHONE_NUMBER")
	@Column(value = "phone_number")
	private String phoneNumber;
}