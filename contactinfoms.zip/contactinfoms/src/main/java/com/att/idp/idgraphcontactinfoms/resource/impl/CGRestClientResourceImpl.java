package com.att.idp.idgraphcontactinfoms.resource.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.att.idp.idgraphcontactinfoms.cgclient.response.CGResponse;
import com.att.idp.idgraphcontactinfoms.exceptions.MPSException;
import com.att.idp.idgraphcontactinfoms.resource.CGRestClientResource;
import com.att.idp.idgraphcontactinfoms.service.CGRestClientService;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;

/**
 * This class is the implementation of the CGRestClientResource interface.
 *
 * It is annotated with @Controller, indicating that it's a Spring MVC Controller.
 * The class has a dependency on CGRestClientService, which is autowired.
 * It also has a Logger instance for logging.
 *
 * The class has one main method: cgRestClient.
 * This method takes HttpHeaders as an input parameter and returns a Response.
 * The method is responsible for handling the CGRestClient request.
 * It throws MPSException, JsonProcessingException, IOException that can occur during the execution of the method.
 */
@Controller
@OpenAPIDefinition(
		info = @Info(title="Contact Info",
				description="IDGraphContactInfoMs supports multiple functions.  " +
						"This application provides APIs that support multiple functions including returning CPNI " +
						"eligible contact methods for accessId, wireless, enabler and wireline accounts, OTP generation," +
						" validation and deletion.\n.", version="0.0.1"),
		servers = {
				@Server(url="https://apporigin-dev2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphcontactinfoms/"),
				@Server(url="https://apporigin-tst2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphcontactinfoms/")
		})
public class CGRestClientResourceImpl implements CGRestClientResource{
	
	private static final Logger logger = LoggerFactory.getLogger(CGRestClientResourceImpl.class);
	
	@Autowired
	private CGRestClientService cgRestClientService;
	
	private static String sClassName = "CGRestClientResourceImpl";

	@Override
	public Response cgRestClient(HttpHeaders httpHeaders) throws MPSException, JsonProcessingException, IOException {
		String sMethodName = ".cgRestClient.";
		Response responseObj = null;
		CGResponse cgResponse = null;
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		HashMap<String, Object> hmNotification =  new HashMap<>();
		if(StringUtils.isNotBlank(httpHeaders.getHeaderString("accountId"))) {
			hmNotification.put(CommonDefs.ACCOUNT_ID, httpHeaders.getHeaderString("accountId"));
			}
			else if(StringUtils.isNotBlank(httpHeaders.getHeaderString("subscriberNumber"))) {
				hmNotification.put("subscriberNumber", httpHeaders.getHeaderString("subscriberNumber"));
			}
		hmNotification.put(CommonDefs.SERVICE_TYPE, httpHeaders.getHeaderString("serviceType"));
		hmNotification.put("topics", httpHeaders.getHeaderString("topics"));
		
		hmResponse = cgRestClientService.cgRestClient(hmNotification);
		logger.info("{}{}CGR_01 : Response from CGRestClient : {}", sClassName, sMethodName, hmResponse);
		hmResponse.put("idp-trace-id", httpHeaders.getHeaderString("idp-trace-id"));
		cgResponse = CommonUtilHelper.generateCGResponse(hmResponse);
		responseObj = CommonUtilHelper.buildMSResponse(cgResponse);
		
		return responseObj;
	}
}