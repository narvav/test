package com.att.idp.idgraphcontactinfoms.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * The class Contact
 *
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "contactMedium"
})
@Schema(name = "Contact")
public class Contact implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -3224104987004114748L;

    /** The list of LegacyContactMedium. */
    @JsonProperty("contactMediums")
    private List<ContactMedium> contactMediums = null;
}
