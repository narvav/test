package com.att.idp.idgraphcontactinfoms.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;

/**
 * The Class Characteristic.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "contactType", "simSwap", "emailAddress", "isAged", "cpniEligible",
        "verified", "establishmentDate", "city", "country", "postCode", "stateOrProvince", "street1", "street2", "phoneNumber", "phoneModifiedDate",
        "isATTNumber", "deviceInHandValidationSts", "subContactType" })
@Schema(name = "Characteristic")
public class Characteristic implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The contact type. */
    @JsonProperty("contactType")
    private String contactType;

    /** The simswap. */
    @JsonProperty("simSwap")
    private String simSwap;

    /** The email address. */
    @JsonProperty("emailAddress")
    private String emailAddress;

    /** The isAged. */
    @JsonProperty("isAged")
    private Boolean isAged;

    /** The cpniEligible. */
    @JsonProperty("cpniEligible")
    private Boolean cpniEligible;

    /** The verified. */
    @JsonProperty("verified")
    private Boolean verified;

    /** The establishmentDate. */
    @JsonProperty("establishmentDate")
    private String establishmentDate;

    /** The city. */
    @JsonProperty("city")
    private String city;

    /** The country. */
    @JsonProperty("country")
    private String country;

    /** The postCode. */
    @JsonProperty("postCode")
    private String postCode;

    /** The stateOrProvince. */
    @JsonProperty("stateOrProvince")
    private String stateOrProvince;

    /** The street1. */
    @JsonProperty("street1")
    private String street1;

    /** The street2. */
    @JsonProperty("street2")
    private String street2;

    /** The phoneNumber. */
    @JsonProperty("phoneNumber")
    private String phoneNumber;

    /** The phoneModifiedDate. */
    @JsonProperty("phoneModifiedDate")
    private String phoneModifiedDate;

    /** The isATTNumber. */
    @JsonProperty("isATTNumber")
    private Boolean isATTNumber;

    /** The deviceInHandValidationSts. */
    @JsonProperty("deviceInHandValidationSts")
    private String deviceInHandValidationSts;

    /** The subContactType. */
    @JsonProperty("subContactType")
    private String subContactType;
}
