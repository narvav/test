package com.att.idp.idgraphcontactinfoms.resource.response;

import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.response package.
 *
 * The CBRUSPhoneNumber class is used to represent a US phone number with various attributes.
 * It contains several fields, each of which represents a parameter of the phone number.
 * These fields include contactStatus, contactType, establishedDate, aged, validated, phoneNumber, and phoneNumberType.
 *
 * Each field has a corresponding getter and setter method, allowing the fields to be accessed and modified.
 * The class also overrides the toString method, providing a custom string representation of the object.
 */
@Data
public class CBRUSPhoneNumber {

	private String contactStatus;
	private String contactType;
	private String establishedDate;
	private String aged;
	private String validated;
	private String phoneNumber;
	private String phoneNumberType;
}