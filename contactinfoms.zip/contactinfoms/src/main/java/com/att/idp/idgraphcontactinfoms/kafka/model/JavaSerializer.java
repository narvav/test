package com.att.idp.idgraphcontactinfoms.kafka.model;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import org.apache.kafka.common.serialization.Serializer;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.kafka.model package.
 * It implements the Serializer interface provided by Apache Kafka, with NTRetailerNotification as the type of object to be serialized.
 *
 * The class is used to serialize NTRetailerNotification objects into a byte array that can be sent to Kafka.
 * It overrides three methods from the Serializer interface: serialize, configure, and close.
 *
 * The serialize method is used to convert a NTRetailerNotification object into a byte array.
 * The configure method is currently empty and can be used to configure the serializer with the given map of configs.
 * The close method is currently empty and can be used to perform any cleanup when the serializer is closed.
 */
public class JavaSerializer implements Serializer<NTRetailerNotification> {

    @Override
    public byte[] serialize(String topic, NTRetailerNotification data) {
        try {
            ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
            ObjectOutputStream objectStream = new ObjectOutputStream(byteStream);
            objectStream.writeObject(data);
            objectStream.flush();
            objectStream.close();
            return byteStream.toByteArray();
        }
        catch (IOException e) {
            throw new IllegalStateException("Can't serialize object: " + data, e);
        }
    }

    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {

    }

    @Override
    public void close() {

    }

}
