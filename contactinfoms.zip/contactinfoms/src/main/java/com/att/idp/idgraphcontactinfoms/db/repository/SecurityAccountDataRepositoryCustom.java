package com.att.idp.idgraphcontactinfoms.db.repository;

import java.sql.SQLException;
import java.util.HashMap;

import org.slf4j.Logger;

/**
 * This is the SecurityAccountDataRepositoryCustom interface.
 *
 * It is used to declare custom repository methods for the SecurityAccountData entity.
 * These methods are not provided by the JpaRepository and need to be implemented manually.
 *
 * The methods declared in this interface can be used to perform complex queries or database operations that are not supported by the standard JpaRepository methods.
 *
 * The interface declares two methods setSecurityAccountData() and updateSecurityAccount() that take a HashMap and other parameters as arguments and return an integer.
 * These methods can be used to set and update security account data respectively.
 */
public interface SecurityAccountDataRepositoryCustom {

	/**
	 * This method is used to set security account data.
	 *
	 * It takes a HashMap as an input parameter, which represents the input parameters for setting the security account data.
	 * The HashMap contains key-value pairs where the key is the parameter name and the value is the parameter value.
	 *
	 * The method performs a database operation to set the security account data using the provided HashMap.
	 * It returns an integer representing the result of the operation. A return value of 1 indicates success, while a return value of 0 indicates failure.
	 *
	 * @param InpParam a HashMap representing the input parameters for setting the security account data.
	 * @return an integer representing the result of the operation.
	 * @throws SQLException if a database access error occurs or this method is called on a closed connection.
	 * @throws Exception if any other error occurs during the execution of the method.
	 */
	public int setSecurityAccountData(HashMap InpParam) throws SQLException, Exception;

	/**
	 * This method is used to update security account data.
	 *
	 * It takes three parameters: a HashMap, a boolean, and a Long.
	 * The HashMap, InpParam, represents the input parameters for updating the security account data.
	 * The HashMap contains key-value pairs where the key is the parameter name and the value is the parameter value.
	 * The boolean, isSaveSecurityCode, indicates whether the security code should be saved or not.
	 * The Long, cumulativeFailureCount, represents the cumulative failure count for the account.
	 *
	 * The method performs a database operation to update the security account data using the provided parameters.
	 * It returns an integer representing the result of the operation. A return value of 1 indicates success, while a return value of 0 indicates failure.
	 *
	 * @param InpParam a HashMap representing the input parameters for updating the security account data.
	 * @param isSaveSecurityCode a boolean indicating whether the security code should be saved or not.
	 * @param cumulativeFailureCount a Long representing the cumulative failure count for the account.
	 * @return an integer representing the result of the operation.
	 * @throws SQLException if a database access error occurs or this method is called on a closed connection.
	 * @throws Exception if any other error occurs during the execution of the method.
	 */
	public int updateSecurityAccount(HashMap InpParam, boolean isSaveSecurityCode, Long cumulativeFailureCount) throws SQLException, Exception;

	//public Tsecurityaccount getCumulativeFailureCount(String identification_type, String account_id) throws SQLException;

}
