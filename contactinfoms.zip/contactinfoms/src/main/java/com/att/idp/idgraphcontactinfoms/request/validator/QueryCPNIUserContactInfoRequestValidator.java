package com.att.idp.idgraphcontactinfoms.request.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import jakarta.ws.rs.core.HttpHeaders;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphcontactinfoms.message.ErrorMessages;
import com.att.idp.idgraphcontactinfoms.resource.request.QueryCPNIUserContactInfoRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.QueryCPNIUserContactInfoResponse;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.idp.idgraphcontactinfoms.utils.QueryCPNIUserContactInfoResponseGenerator;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;

/**
 * This class is responsible for validating the QueryCPNIUserContactInfoRequest.
 *
 * It uses the Spring Framework's @Configuration and @PropertySource annotations to indicate that it is a source of bean definitions and to load properties from a specified location.
 *
 * The class has several instance variables that are injected using the @Value annotation.
 * These variables are used to store configuration values such as the valid callers.
 *
 * The main method in this class is the queryCPNIUserContactInfoRequestValidator method, which takes HttpHeaders and a QueryCPNIUserContactInfoRequest as input and returns a QueryCPNIUserContactInfoResponse.
 * The queryCPNIUserContactInfoRequestValidator method performs various checks on the input parameters and calls other private methods for further validation.
 *
 * The class also contains several private methods for validating the input parameters and constructing an error response.
 *
 * The class also contains a logger for logging information and error messages.
 */
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class QueryCPNIUserContactInfoRequestValidator {
	private static final Logger logger = LoggerFactory.getLogger(QueryCPNIUserContactInfoRequestValidator.class);

	private String sClassName = "QueryCPNIUserContactInfoRequestValidator";

	@Value("${PROP_QUERY_CPNI_USER_CSI}")
	private String propQueryCpniUserCSI;

	/**
	 * This method is responsible for validating the QueryCPNIUserContactInfoRequest.
	 *
	 * It takes HttpHeaders and a QueryCPNIUserContactInfoRequest as input parameters and returns a QueryCPNIUserContactInfoResponse.
	 * The method performs various checks on the input parameters and calls other private methods for further validation.
	 * If the validation is successful, the method returns a QueryCPNIUserContactInfoResponse. If the validation fails, the method constructs an error response and returns it.
	 *
	 * The method also handles exceptions that can occur during the validation process.
	 *
	 * @param requestHeader HttpHeaders that contains the request headers. These headers are used for logging and tracing purposes.
	 * @param queryCPNIUserContactInfoRequest QueryCPNIUserContactInfoRequest that contains the request data for the query CPNI user contact info operation. This data is validated by the method.
	 * @return a QueryCPNIUserContactInfoResponse that contains the result of the validation. If the validation is successful, the response contains a success message. If the validation fails, the response contains an error message.
	 */
	public QueryCPNIUserContactInfoResponse queryCPNIUserContactInfoRequestValidator(HttpHeaders requestHeader,
			QueryCPNIUserContactInfoRequest queryCPNIUserContactInfoRequest) {

		String stAppInfo = null;
		String sMethodName = ".QueryCPNIUserContactInfoRequestValidator.";
		String stIdpTraceId = null;

		
		stIdpTraceId = CommonUtil.getTraceId(requestHeader);
		
		if(stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
			stAppInfo="QueryCPNIUserContactInfo Request idp-trace-id is missing";
			return queryCPNIUserContactInfoErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		

		if (queryCPNIUserContactInfoRequest == null) {
			stAppInfo = "Input Request Parameter is NULL / Empty.";
			logger.info("{}{}QCPNI_UCIV_03 :: {}", sClassName, sMethodName, stAppInfo);
			return queryCPNIUserContactInfoErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,stIdpTraceId);
		}
		queryCPNIUserContactInfoRequest.setIdpTraceId(stIdpTraceId);
		
		// checking Invalid attributes passed in Request
		Map<String, Object> allUnknownAttributes = new HashMap<>(queryCPNIUserContactInfoRequest.unknownAttributes);

		if (!allUnknownAttributes.isEmpty()) {
			stAppInfo = "Invalid Attributes passed in QueryCPNIUserContactInfoRequest : " + allUnknownAttributes;
			return queryCPNIUserContactInfoErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					queryCPNIUserContactInfoRequest.getIdpTraceId());
		}


		String sCallingSystemId = Optional.ofNullable(queryCPNIUserContactInfoRequest.getCallingSystemId()).orElse(requestHeader.getHeaderString("X-ATT-ClientId"));
		if (sCallingSystemId == null || sCallingSystemId.isEmpty()) {
			stAppInfo = "Either X-ATT-ClientId in request header or callingSystemId in request body must be present";
			logger.info("{}{}QCPNI_UCIV_04 : {}", sClassName, sMethodName, stAppInfo);
			return queryCPNIUserContactInfoErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,stIdpTraceId);
		}
		queryCPNIUserContactInfoRequest.setCallingSystemId(sCallingSystemId.toUpperCase());
		Optional.ofNullable(queryCPNIUserContactInfoRequest.getUserId()).ifPresent(x->{
			queryCPNIUserContactInfoRequest.setUserId(x.trim().toLowerCase());
		});
		
		Optional.ofNullable(queryCPNIUserContactInfoRequest.getGuid()).ifPresent(x->{
			queryCPNIUserContactInfoRequest.setGuid(x.trim());
		});
		String sHandle = queryCPNIUserContactInfoRequest.getUserId();
		String sDomain = queryCPNIUserContactInfoRequest.getDomain();
		String sGuid = queryCPNIUserContactInfoRequest.getGuid();
		String sIsExternalCall = Optional.ofNullable(queryCPNIUserContactInfoRequest.getIsExternalCall()).orElse("Y");
		queryCPNIUserContactInfoRequest.setIsExternalCall(sIsExternalCall);
		String sReturnCBRCTNs = queryCPNIUserContactInfoRequest.getReturnCBRCTNs();

		if (sReturnCBRCTNs != null && !(sReturnCBRCTNs.equalsIgnoreCase("Y") || sReturnCBRCTNs.equalsIgnoreCase("N"))) {
			stAppInfo = "returnCBRCTNs should be either Y or N";
			logger.info("{}{}QCPNI_UCIV_05 : {}", sClassName, sMethodName, stAppInfo);
			return queryCPNIUserContactInfoErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,stIdpTraceId);
		}

		if (sIsExternalCall != null
				&& !(sIsExternalCall.equalsIgnoreCase("Y") || sIsExternalCall.equalsIgnoreCase("N"))) {
			stAppInfo = "isExternalCall should be either Y or N";
			logger.info("{}{}QCPNI_UCIV_06 : {}", sClassName, sMethodName, stAppInfo);
			return queryCPNIUserContactInfoErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,stIdpTraceId);
		}

		ArrayList<String> alValidCallers = CommonUtil.parseToArray(propQueryCpniUserCSI,
				CommonDefs.VALUE_SEPARATOR_CHAR);
		logger.info("{}{}QCPNI_UCIV_07 : PROP_QUERY_CPNI_USER_CSI : {}", sClassName, sMethodName, alValidCallers);

		if ((sIsExternalCall != null && sIsExternalCall.equalsIgnoreCase("Y"))
				&& (sCallingSystemId != null && !alValidCallers.contains(sCallingSystemId))) {
			stAppInfo = "Invalid X-ATT-ClientId or callingSystemId passed in request ";
			logger.info("{}{}QCPNI_UCIV_08 : {}", sClassName, sMethodName, stAppInfo);
			return queryCPNIUserContactInfoErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,stIdpTraceId);
		}

		if (sHandle != null && !sHandle.isEmpty() && sDomain != null && !sDomain.isEmpty()) {

			if (!sDomain.equals("slid.dum")) {
				stAppInfo = "Input domain should be slid.dum";
				logger.info("{}{}QCPNI_UCIV_09 : {}", sClassName, sMethodName, stAppInfo);
				return queryCPNIUserContactInfoErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,stIdpTraceId);
			}
			sGuid = null;
			queryCPNIUserContactInfoRequest.setGuid(null);
		} else if (sGuid != null && !sGuid.isEmpty()) {

			queryCPNIUserContactInfoRequest.setUserId(null);
			queryCPNIUserContactInfoRequest.setDomain(null);

		} else {
			stAppInfo = "Either guid OR userId must be present";
			logger.info("{}{}QCPNI_UCIV_10 : {}", sClassName, sMethodName, stAppInfo);
			return queryCPNIUserContactInfoErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		return null;

	}

	private QueryCPNIUserContactInfoResponse queryCPNIUserContactInfoErrorResponse(int appStatusCode, String stAppInfo,String stIdpTraceId) {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		return QueryCPNIUserContactInfoResponseGenerator.getQueryCPNIUserContactInfoResponse(hmResponse);
	}
}
