package com.att.idp.idgraphcontactinfoms.helpers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphcontactinfoms.db.helper.ContactDBHelper;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This class is a helper class for inquiring user contact information.
 *
 * It contains methods for inquiring user contact information based on the input parameters.
 * The class uses the Spring Framework's @Component annotation to indicate that it is a bean and can be used for dependency injection.
 * It also uses the @PropertySource annotation to specify the location of the properties file.
 *
 * The class has several instance variables that are injected using the @Autowired and @Value annotations.
 * These variables include a ContactDBHelper, a CommonUtilHelper, and a String for the inquire user contact info CSI.
 *
 * The main method in this class is the inquireUserContactCBR method, which takes a HashMap as input and returns a HashMap as output.
 * The inquireUserContactCBR method uses several other methods in the class to validate the input data, process the input data, and store the data.
 *
 * The class also contains a logger for logging information and error messages.
 */
@Component
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class InquireUserContactCBRHelper {

	@Autowired
	private ContactDBHelper contactDBHelper;

	@Autowired
	private CommonUtilHelper oCommonUtilHelper;

    @Value("${PROP_INQUIRE_USER_CONTACT_CBR_CSI}")
	private String sPropInquireUserContactInfoCSI;

	private static final Logger logger = LoggerFactory.getLogger(InquireUserContactCBRHelper.class);
	private static final String SCLASSNAME = "InquireUserContactCBRHelper";

	/**
	 * This method inquires user contact information based on the input parameters.
	 *
	 * It first retrieves the calling system ID, external call flag, GUID, and linked member list from the input HashMap.
	 * Then, it validates the input data. If the input data is invalid, the method constructs an error response and returns it.
	 * If the input data is valid, the method processes the input data and makes a call to the ContactDBHelper to inquire user contact information.
	 * The method then checks the response from the ContactDBHelper. If the response indicates an error, the method constructs an error response and returns it.
	 * If the response from the ContactDBHelper indicates success, the method constructs a success response and returns it.
	 * The success response includes the user CBR list.
	 *
	 * @param hmInput a HashMap that contains the input data for the user contact information inquiry. The HashMap should include the calling system ID, external call flag, GUID, and linked member list.
	 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code, an application info message, and the user CBR list.
	 * @throws Exception if an error occurs during the operation.
	 */
	public HashMap inquireUserContactCBR(HashMap hmInput) {
		String sMethodName = ".inquireUserContactCBR.";

		logger.info("{}{}HLP000 : Input Hash : {}", SCLASSNAME, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmInput)));
		HashMap<String, Object> hmResult = null;
		HashMap<String, Object> hmResponse = null;
		String stAppInfo = null;
		String stAppStatusCode = null;

		if (hmInput == null || hmInput.isEmpty()) {
			stAppInfo = "Input Hash is NULL";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			logger.info("{}{}IUCCBRH_100 : {}", SCLASSNAME, sMethodName, stAppInfo);
			return hmResult;
		}

		try {
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sIsExternalCall = (String) hmInput.get(CommonDefs.IS_EXTERNAL_CALL);

			ArrayList alPropInquireUserContactInfoCSI = null;

			if (sPropInquireUserContactInfoCSI != null && !sPropInquireUserContactInfoCSI.isEmpty()) {
				alPropInquireUserContactInfoCSI = CommonUtil.parseToArray(sPropInquireUserContactInfoCSI,
						CommonDefs.VALUE_SEPARATOR_CHAR);
			} else {
				stAppInfo = "Property value is null or empty";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
				logger.error("{}{}IUCCBRH_101 : {}", SCLASSNAME, sMethodName, stAppInfo);
				return hmResult;
			}

			logger.info("{}{}IUCCBRH_102 : Property PROP_INQUIRE_USER_CONTACT_CBR_CSI : {}", SCLASSNAME, sMethodName,
					alPropInquireUserContactInfoCSI);

			if ((CommonDefs.IND_Y.equalsIgnoreCase(sIsExternalCall))
					&& (!alPropInquireUserContactInfoCSI.contains(sCallingSystemId))) {
				stAppInfo = "Invalid CallingSystemId";
				logger.info("{}{}IUCCBRH_103 : {}", SCLASSNAME, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			String sGuid = (String) hmInput.get(CommonDefs.GUID);
			ArrayList alLinkedMemberList = (ArrayList) hmInput.get("linkedMemberList");

			if (sGuid != null && !sGuid.isEmpty() && alLinkedMemberList != null && !alLinkedMemberList.isEmpty()) {
				sGuid = null;
			}

			HashMap<String, Object> hmGuid = CommonUtil.getHashMap();

			if (sGuid != null && !sGuid.isEmpty()) {
				HashMap<String, Object> hmMember = CommonUtil.getHashMap();
				hmMember.put(MPSDefs.DB_MEMBER_NAME, "");
				hmMember.put(MPSDefs.DB_DOMAIN_NAME, "");
				hmGuid.put(sGuid, hmMember);
			} else if (alLinkedMemberList != null && !alLinkedMemberList.isEmpty()) {
				for (int i = 0; i < alLinkedMemberList.size(); i++) {
					HashMap<String, Object> hmLinkedMember = (HashMap<String, Object>) alLinkedMemberList.get(i);

					HashMap<String, Object> hmMember = CommonUtil.getHashMap();
					hmMember.put(MPSDefs.DB_MEMBER_NAME, (String) hmLinkedMember.get(CommonDefs.MEMBER_NAME));
					hmMember.put(MPSDefs.DB_DOMAIN_NAME, (String) hmLinkedMember.get("domainName"));
					hmGuid.put((String) hmLinkedMember.get(CommonDefs.MEMBER_NUM), hmMember);
				}
			}

			ArrayList alDBContactList = new ArrayList();

			Set setGuid = hmGuid.keySet();
			Iterator itrGuid = setGuid.iterator();

			while (itrGuid.hasNext()) {
				String stGuid = (String) itrGuid.next();
				HashMap<String, Object> hmContactHelperInp = CommonUtil.getHashMap();

				hmContactHelperInp.put(MPSDefs.DB_MEMBER_NUM, stGuid);

				logger.debug("{}{}IUCCBRH_104 : Calling ContactDBHelper.getUserContact() with hmContactHelperInp : {}",
						SCLASSNAME, sMethodName, hmContactHelperInp);

				hmResult = contactDBHelper.getUserContact(hmContactHelperInp);

				logger.info("{}{}IUCCBRH_105 : Response from ContactDBHelper.getUserContact() : {}", SCLASSNAME,
						sMethodName, hmResult);

				if (hmResult == null || hmResult.isEmpty()) {
					stAppInfo = "Null Response returned from ContactDBHelper.getUserContact()";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					logger.info("{}{}IUCCBRH_106 : {}", SCLASSNAME, sMethodName, stAppInfo);
					return hmResult;
				}

				stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);

				if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					if (CErrorDefs.ERR_REC_NOT_FOUND.equals(stAppStatusCode)) {
						stAppInfo = "No record found in contact table for : ";
						logger.info("{}{}IUCCBRH_107 : {} {}", SCLASSNAME, sMethodName, stAppInfo,
								HtmlUtils.htmlEscape(String.valueOf(stGuid)));
					} else {
						logger.info("{}{}IUCCBRH_108 : Error returned from ContactDBHelper.getUserContact() : {}",
								SCLASSNAME, sMethodName, hmResult);
						return hmResult;
					}
				} else {
					ArrayList alContactList = (ArrayList) hmResult.get("contacts");

					if (alContactList != null && !alContactList.isEmpty()) {
						alDBContactList.addAll(alContactList);
					}
				}
			}

			ArrayList alUserCBRList = new ArrayList();

			for (int i = 0; i < alDBContactList.size(); i++) {
				HashMap<String, Object> hmDBContact = (HashMap<String, Object>) alDBContactList.get(i);
				String sContactType = (String) hmDBContact.get(MPSDefs.DB_CONTACT_TYPE);

				if ("SMS".equalsIgnoreCase(sContactType)) {
					HashMap<String, Object> hmUserCBR = CommonUtil.getHashMap();
					String sDBGuid = (String) hmDBContact.get(MPSDefs.DB_MEMBER_NUM);
					hmUserCBR.put(CommonDefs.GUID, sDBGuid);

					HashMap<String, Object> hmMember = (HashMap<String, Object>) hmGuid.get(sDBGuid);
					String sMemberName = (String) hmMember.get(MPSDefs.DB_MEMBER_NAME);
					String sDomainName = (String) hmMember.get(MPSDefs.DB_DOMAIN_NAME);

					if (sMemberName != null && !sMemberName.isEmpty()) {
						hmUserCBR.put(CommonDefs.HANDLE, sMemberName);
					}
					if (sDomainName != null && !sDomainName.isEmpty()) {
						hmUserCBR.put(CommonDefs.DOMAIN, sDomainName);
					}

					String sIsAged = "N";
					String sIsValidated = "N";

					String sDateEst = (String) hmDBContact.get("established_date");
					String dateTimeFormat = "MMddyyyy HH:mm:ss";
					boolean bIsAged = oCommonUtilHelper.checkAging(sDateEst, "31", dateTimeFormat);

					if (sDateEst != null && !sDateEst.isEmpty() && bIsAged) {
						sIsAged = "Y";
					}

					String sContactStatus = (String) hmDBContact.get(MPSDefs.DB_CONTACT_STATUS);
					String sValidationStatus = (String) hmDBContact.get(MPSDefs.DB_VALIDATION_STATUS);

					if ("V".equalsIgnoreCase(sContactStatus) && "8".equals(sValidationStatus)) {
						sIsValidated = "Y";
					}

					HashMap<String, Object> hmUSPhoneNumber = CommonUtil.getHashMap();
					hmUSPhoneNumber.put(CommonDefs.CONTACT_STATUS, sContactStatus);
					hmUSPhoneNumber.put(CommonDefs.CONTACT_TYPE, sContactType);
					hmUSPhoneNumber.put("aged", sIsAged);
					hmUSPhoneNumber.put("validated", sIsValidated);
					hmUSPhoneNumber.put(CommonDefs.ESTABLISHED_DATE, sDateEst);
					hmUSPhoneNumber.put(CommonDefs.PHONE_NUMBER, (String) hmDBContact.get(MPSDefs.DB_PHONE_NUMBER));
					hmUSPhoneNumber.put(CommonDefs.PHONE_NUMBER_TYPE,
							(String) hmDBContact.get(MPSDefs.DB_PHONE_NUMBER_TYPE));
					hmUserCBR.put(CommonDefs.US_PHONE_NUMBER, hmUSPhoneNumber);
					alUserCBRList.add(hmUserCBR);
				}
			}

			hmResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

			if (alUserCBRList != null && !alUserCBRList.isEmpty()) {
				hmResponse.put("userCBRList", alUserCBRList);
			}

		} catch (Exception e) {
			hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown in inquireUserContactCBR method";
			logger.error("{}{}IUCCBRH_150e : {} : {}", SCLASSNAME, sMethodName, stAppInfo, hmResponse);
			return hmResponse;
		} finally {
			logger.info("{}{}HLP999 : response from inquireUserContactCBR :: {}", SCLASSNAME, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmResponse)));
		}
		return hmResponse;
	}
}
