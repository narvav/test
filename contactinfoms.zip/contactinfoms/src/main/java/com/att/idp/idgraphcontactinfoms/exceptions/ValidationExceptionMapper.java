package com.att.idp.idgraphcontactinfoms.exceptions;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;

import com.att.idp.idgraphcontactinfoms.message.ErrorMessages;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;

/**
 * This is the ValidationExceptionMapper class.
 *
 * It implements the ExceptionMapper interface with ConstraintViolationException as the type parameter. This means that an instance of ValidationExceptionMapper can be used to map ConstraintViolationException instances to Response objects.
 *
 * The purpose of this class is to provide a way to convert ConstraintViolationException instances into Response objects that can be returned by a JAX-RS resource method. This is done in the toResponse method, which is overridden from the ExceptionMapper interface.
 */
public class ValidationExceptionMapper implements ExceptionMapper<ConstraintViolationException> {

	@Context
	private HttpHeaders headers;

	@Override
	public Response toResponse(ConstraintViolationException ex) {

		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		String sAppInfo = "";
		Response response = null;
		String sEndPoint = "";

		Set<ConstraintViolation<?>> set = ex.getConstraintViolations();
		for (Iterator<ConstraintViolation<?>> iterator = set.iterator(); iterator.hasNext();) {
			ConstraintViolation<?> next = iterator.next();
			sAppInfo = next.getMessage();
			break;
		}

		if (sAppInfo != null && sAppInfo.contains("|")) {
			ArrayList alAppInfo = CommonUtil.parseToArray(sAppInfo, CommonDefs.VALUE_SEPARATOR_CHAR);
			sAppInfo = (String) alAppInfo.get(0);
			sEndPoint = (String) alAppInfo.get(1);
		}
		
		String stIdpTraceId = CommonUtil.getTraceId(headers);
		if (stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
			sAppInfo = "Missing or Invalid IdpTraceId";
		}
		
		hmResponse.put(CommonDefs.COMMON_APP_INFO, sAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.TRANSACTION_NAME, sEndPoint);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(CErrorDefs.ERR_INVALID_DATA_NUM));

		response = CommonUtilHelper.buildMSResponse(CommonUtilHelper.generateCIRResponse(hmResponse));
		
		return response;

	}

}