package com.att.idp.idgraphcontactinfoms.resource.request;

import lombok.Data;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.request package.
 *
 * The class is used to represent an Ao object, which contains a phoneNumber field.
 * The phoneNumber field is annotated with @NotNull and @Size, indicating that it is a required field and has a size constraint.
 *
 * The class provides a no-argument constructor, as well as getter and setter methods for the phoneNumber field.
 * It also overrides the toString method, providing a custom string representation of the object using reflection.
 */
@Data
public class Ao {

	@NotNull(message="phoneNumber is required field in input request.|GeneratePIN")
	@Size(min=1, max=10, message="phoneNumber length is invalid|GeneratePIN")
	protected String phoneNumber;
}