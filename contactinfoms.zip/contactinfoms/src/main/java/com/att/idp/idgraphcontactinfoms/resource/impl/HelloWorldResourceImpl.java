package com.att.idp.idgraphcontactinfoms.resource.impl;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;

import com.att.idp.idgraphcontactinfoms.resource.HelloWorldResource;
/**
 * This is the Controller class for User mService
 * 
 * @author LEGOS - Platform Team
 * @version $Id$
 * 
 */
@Controller
public class HelloWorldResourceImpl implements HelloWorldResource {

	private static final Logger LOGGER = LoggerFactory.getLogger(HelloWorldResourceImpl.class);

	@Override
	public Response getHelloWorld(HttpServletRequest request) {

		String str = "Testing IDGraphContactInfoMs changes";
		LOGGER.info("IDGraphContactInfoMs Sample Test : " + str);
		return Response.ok(str).build();
	}
}