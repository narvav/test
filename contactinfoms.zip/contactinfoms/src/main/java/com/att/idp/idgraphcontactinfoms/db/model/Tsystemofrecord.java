package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "TSYSTEMOFRECORD", schema = "MPS_OWNER", uniqueConstraints = @UniqueConstraint(columnNames = "SOR_NAME"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tsystemofrecord implements java.io.Serializable {

	@Id
	@Column(name = "SOR_ID", unique = true, nullable = false, precision = 22, scale = 0)
	private BigDecimal sorId;

	@Column(name = "SOR_NAME", unique = true, nullable = false, length = 30)
	private String sorName;

	@Column(name = "SOR_DESC")
	private String sorDesc;

	@Column(name = "SOR_TYPE")
	private String sorType;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tsystemofrecord")
	private Set<Tmemberdevice> tmemberdevices = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tsystemofrecord")
	private Set<Tloyaltyprogacctassoc> tloyaltyprogacctassocs = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tsystemofrecord")
	private Set<Tdynservicesor> tdynservicesors = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tsystemofrecord")
	private Set<Tloyaltyofferacceptance> tloyaltyofferacceptances = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tsystemofrecord")
	private Set<Tsecuritycode> tsecuritycodes = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tsystemofrecord")
	private Set<Tmember> tmembers = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tsystemofrecord")
	private Set<Tmemberservice> tmemberservices = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tsystemofrecord")
	private Set<Tmemberservicerole> tmemberserviceroles = new HashSet<>(0);
}