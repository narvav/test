package com.att.idp.idgraphcontactinfoms.helpers;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.cgclienthelpers.integration.CGApiRestClient;
import com.att.idp.cgclienthelpers.utils.CGUtilHelper;
import com.att.idp.core.exception.ServiceException;
import com.att.idp.dpl.profile.bsse.customerv4.CustomerV4Response;
import com.att.idp.dpl.profile.bsse.customerv4.Subscriber;
import com.att.idp.dpl.profile.bsse.model.common.Characteristic;
import com.att.idp.idgraphcontactinfoms.message.ErrorMessages;
import com.att.idp.idgraphcontactinfoms.model.Account;
import com.att.idp.idgraphcontactinfoms.model.Contact;
import com.att.idp.idgraphcontactinfoms.model.ContactMedium;
import com.att.idp.idgraphcontactinfoms.model.Individual;
import com.att.idp.idgraphcontactinfoms.model.Subscribers;
import com.att.idp.idgraphcontactinfoms.utils.CGIndividualInfoToCustomerV4ResponseMapper;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.idp.idgraphcontactinfoms.utils.Constants;
import com.att.mpsys.common.utils.CommonDefs;

import io.swagger.client.model.CGIndividualInfo;
import jakarta.ws.rs.core.MultivaluedMap;

@Component
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class CPNIContactInfoHelper {

    @Autowired
    private ProfileHelper profileHelper;
    @Autowired
    private CGApiRestClient cgApiRestClient;
    @Autowired
    private CPNIEligibilityHelper cpniEligibilityHelper;
    @Autowired
    private CGIndividualInfoToCustomerV4ResponseMapper responseMapper;
    @Autowired
    private CGUtilHelper cgUtilHelper;
    private static String sClassName = "CPNIContactInfoHelper";
    public static final Logger logger = LoggerFactory.getLogger(CPNIContactInfoHelper.class);
    private static final String CBR = "cbr";
    private static final String TELEPHONE = "telephone";
    private static final String POSTAL_ADDRESS = "postalAddress";


    /**
     * Retrieves the CPNI (Customer Proprietary Network Information) contact information for an individual
     * based on their individual ID.
     * <p>
     * This method interacts with the Profile Microservice to fetch the individual's information and maps
     * it to an `Individual` object. If the Profile Microservice returns a null response, a `ServiceException`
     * is thrown. The method logs the input, processing steps, and output for debugging and monitoring purposes.
     *
     * @param individualId      The unique identifier of the individual whose CPNI contact information is to be retrieved.
     * @param cpniContactInfoRequestHeader Provides header details passed in the request
     * @param isAccountIdOrSubscriberSearch The identifier to understand is accountId passed in the api request or not
     * @return An `Individual` object containing the mapped CPNI contact information.
     * @throws Exception If an error occurs during the process, such as a null response from the Profile Microservice
     *                   or any other unexpected exception.
     */
    public Individual cpniContactInfoByIndividualId(String individualId, MultivaluedMap<String, String> cpniContactInfoRequestHeader, boolean isAccountIdOrSubscriberSearch) throws Exception {
        String sMethodName = ".cpniContactInfoByIndividualId.";
        Individual individual = null;
        String stAppInfo = null;
        logger.info("{}{}CCIH_01 HLP000: input individualId {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(individualId)));
        try {
            CGIndividualInfo cgIndividualInfo = profileHelper.profileMsSearchByIndividualId(individualId,cpniContactInfoRequestHeader);
            if (cgIndividualInfo == null) {
                stAppInfo = "CPNIContactInfoHelper.cpniContactInfo() : profile api response is null";
                logger.info("{}{}CCIH_02 : {}", sClassName, sMethodName, stAppInfo);
                throw new ServiceException(ErrorMessages.MS_MPSYS_BE_610, stAppInfo);
            }
            individual = updateIndividualResponse(responseMapper.mapToCustomerV4Response(cgIndividualInfo), cpniContactInfoRequestHeader, isAccountIdOrSubscriberSearch);
        } catch (ServiceException ex) {
            stAppInfo = "Exception recieved from profile api call - profileMsSearchByIndividualId for individualId " + individualId;
            logger.error("{}{}CCIH_03 : Exception = {}", sClassName, sMethodName, stAppInfo);
            throw ex ;
        } catch (Exception ex) {
            stAppInfo = "Exception occurred while fetching cpniContactInfoByIndividualId for individualId " + individualId;
            logger.error("{}{}CCIH_04 : Exception = {}", sClassName, sMethodName, ex);
            throw new ServiceException(ErrorMessages.MS_MPSYS_BE_602, stAppInfo);
        }
        logger.debug("{}{}CCIH_05 : output individual", sClassName, sMethodName, individual);
        logger.info("{}{}HLP999: cpniContactInfo processing completed successfully for individualId {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(individualId)));
        return individual;
    }

    /**
     * Retrieves the CPNI (Customer Proprietary Network Information) contact information for an individual
     * based on their account ID.
     * <p>
     * This method interacts with the CG API to fetch the customer's details using the provided account ID.
     * It maps the response to an `Individual` object. If the CG API returns a null response, a `ServiceException`
     * is thrown. The method logs the input, processing steps, and output for debugging and monitoring purposes.
     *
     * @param accountId         The unique identifier of the account whose CPNI contact information is to be retrieved.
     * @param accountType       The unique identifier of the account whose CPNI contact information is to be retrieved.
     * @param isAccountIdOrSubscriberSearch The identifier to understand is accountId passed in the api request or not
     * @param cpniContactInfoRequestHeader Provides header details passed in the request
     * @return An `Individual` object containing the mapped CPNI contact information.
     * @throws ServiceException If the CG API response is null or any other unexpected exception occurs.
     */
    public Individual cpniContactInfoByAccountId(String accountId, String accountType, MultivaluedMap<String, String> cpniContactInfoRequestHeader, boolean isAccountIdOrSubscriberSearch) {
        String sMethodName = ".cpniContactInfoByAccountId.";
        Individual individual = null;
        CustomerV4Response customerV4Response = null;
        String stAppInfo = null;
        HashMap<String, Object> cgInput = new HashMap<>();
        cgInput.put("accountID", accountId);
        cgInput.put("accountType", accountType);

        logger.info("{}{}HLP_01 : Calling CGRestClient getCustomerDetailsByAccountId API {}", sClassName, sMethodName, cgInput);
        logger.info("{}{}HLP000: input accountId {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(accountId)));
        try {
            customerV4Response = cgApiRestClient.getCustomerDetailsByAccountId(cgInput);
            if (customerV4Response == null) {
                stAppInfo = "CPNIContactInfoHelper.cpniContactInfoByAccountId() : CG api response is null";
                logger.info("{}{}CCIH_02 : {}", sClassName, sMethodName, stAppInfo);
                throw new ServiceException(ErrorMessages.MS_MPSYS_BE_610, stAppInfo);
            }
            individual = updateIndividualResponse(customerV4Response, cpniContactInfoRequestHeader, isAccountIdOrSubscriberSearch);
        } catch (ServiceException ex) {
            stAppInfo = "Exception received from cg api call - getCustomerDetailsByAccountId for accountId" + accountId;
            logger.error("{}{}CCIH_03 : Exception = {}", sClassName, sMethodName, stAppInfo);
            throw ex ;
        } catch (Exception ex) {
            stAppInfo = "Exception occurred while fetching getCustomerDetailsByAccountId for accountId " + accountId;
            logger.error("{}{}CCIH_03 : Exception = {}", sClassName, sMethodName, ex);
            throw new ServiceException(ErrorMessages.MS_MPSYS_BE_602, stAppInfo);
        }
        logger.debug("{}{}CCIH_04 : output individual", sClassName, sMethodName, individual);
        logger.info("{}{}HLP999: cpniContactInfo processing completed successfully for accountId {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(accountId)));
        return individual;
    }

    /**
     * Retrieves CPNI contact information by subscriber number.
     * This method calls the CG API with the subscriber number (phoneNumber) to fetch customer details.
     *
     * @param subscriberNumber - the subscriber number to search for
     * @param cpniContactInfoRequestHeader - request headers containing trace ID and other metadata
     * @param isAccountIdOrSubscriberSearch - flag indicating if this is an account-based search
     * @return Individual - the individual contact information
     * @throws ServiceException if CG API call fails or returns null
     */
    public Individual cpniContactInfoBySubscriberNumber(String subscriberNumber, MultivaluedMap<String, String> cpniContactInfoRequestHeader, boolean isAccountIdOrSubscriberSearch) {
        String sMethodName = ".cpniContactInfoBySubscriberNumber.";
        Individual individual = null;
        CustomerV4Response customerV4Response = null;
        String stAppInfo = null;
        HashMap<String, Object> cgInput = new HashMap<>();
        String sanitizedSubscriberNumber = CommonUtilHelper.sanitizeForLog(String.valueOf(subscriberNumber));
        cgInput.put(Constants.PHONE_NUMBER, subscriberNumber);

        logger.info("{}{}HLP_01 : Calling CGRestClient getCustomerDetailsByAccountId API with subscriberNumber {}", sClassName, sMethodName, cgInput);
        logger.info("{}{}HLP000: input subscriberNumber {}", sClassName, sMethodName, sanitizedSubscriberNumber);
        try {
            customerV4Response = cgApiRestClient.getCustomerDetailsByAccountId(cgInput);
            if (customerV4Response == null) {
                stAppInfo = "CPNIContactInfoHelper.cpniContactInfoBySubscriberNumber() : CG api response is null";
                logger.info("{}{}CCIH_02 : {}", sClassName, sMethodName, stAppInfo);
                throw new ServiceException(ErrorMessages.MS_MPSYS_BE_610, stAppInfo);
            }
            individual = updateIndividualResponse(customerV4Response, cpniContactInfoRequestHeader, isAccountIdOrSubscriberSearch);
        } catch (ServiceException ex) {
            stAppInfo = "Exception received from cg api call - getCustomerDetailsByAccountId for subscriberNumber " + sanitizedSubscriberNumber;
            logger.error("{}{}CCIH_03 : Exception = {}", sClassName, sMethodName, stAppInfo);
            throw ex ;
        } catch (Exception ex) {
            stAppInfo = "Exception occurred while fetching getCustomerDetailsByAccountId for subscriberNumber " + sanitizedSubscriberNumber;
            logger.error("{}{}CCIH_03 : Exception = {}", sClassName, sMethodName, ex);
            throw new ServiceException(ErrorMessages.MS_MPSYS_BE_602, stAppInfo);
        }
        logger.debug("{}{}CCIH_04 : output individual {}", sClassName, sMethodName, individual);
        logger.info("{}{}HLP999: cpniContactInfo processing completed successfully for subscriberNumber {}", sClassName, sMethodName, sanitizedSubscriberNumber);
        return individual;
    }


    /**
     * Updates the `Individual` object by mapping contact mediums and accounts from the provided `CustomerV4Response` object.
     *
     * @param customerV4Response The `CustomerV4Response` object containing the data to be mapped to the `Individual` object.
     * @param isAccountIdOrSubscriberSearch  The identifier to understand is accountId passed in the api request or not
     * @param cpniContactInfoRequestHeader Provides header details passed in the request
     * @return An `Individual` object populated with contact mediums and accounts mapped from the input `CustomerV4Response`.
     * @throws Exception If an error occurs during the mapping process.
     */
    private Individual updateIndividualResponse(CustomerV4Response customerV4Response, MultivaluedMap<String, String> cpniContactInfoRequestHeader, boolean isAccountIdOrSubscriberSearch) {
        String sMethodName = ".updateIndividualResponse.";
        Individual individual = new Individual();
        String returnBizCTNs = cpniContactInfoRequestHeader.getFirst(Constants.RETURN_BIZ_CTNS);
        if(returnBizCTNs == null) {
            returnBizCTNs = "N";
        }
        String  subscriberNumber= cpniContactInfoRequestHeader.getFirst(Constants.SUBSCRIBER_NUMBER);
        if(!StringUtils.isBlank(subscriberNumber)) {
            returnBizCTNs = "Y";
        }
        String exploitable = cpniContactInfoRequestHeader.getFirst(Constants.EXPLOITABLE);
        String isIndividualIdInResEnabled = cpniContactInfoRequestHeader.getFirst("isIndividualIdInResEnabled");


        logger.info("{}{}CCIH_06 : CustomerV4Response response processing has started", sClassName, sMethodName);
        // Map the contact mediums from the CustomerV4Response object to the Individual object
        List<ContactMedium> alContactMedium = mapIndividualContactMedium(customerV4Response,isAccountIdOrSubscriberSearch);

        // Map the accounts from the CustomerV4Response object to the Individual object
        List<Account> accounts = mapIndividualAccounts(customerV4Response,returnBizCTNs);

        if (exploitable != null && CommonDefs.IND_Y.equalsIgnoreCase(exploitable)) {
            applyExploitableRulesForIndividual(alContactMedium, accounts);
            applyExploitableRulesForAccounts(accounts);
        }

        if(CommonDefs.IND_Y.equals(isIndividualIdInResEnabled) && customerV4Response.getIndividual() != null){
            individual.setId(customerV4Response.getIndividual().getId());
        }
        individual.setContactMediums(alContactMedium);
        individual.setAccounts(accounts);

        logger.info("CCIH_07 : successfully updated the Individual with cpniEligibility");
        return individual;
    }

    /**
     * Maps the contact mediums from the provided `CustomerV4Response` object to a list of `ContactMedium` objects.
     * <p>
     * This method processes the `ContactMedium` list from the input `CustomerV4Response` object, filters for valid
     * mediums (e.g., "email" or "telephone"), and populates the corresponding `ContactMedium` objects.
     *
     * @param customerV4Response The `CustomerV4Response` object containing the contact medium data to be mapped.
     * @param isAccountIdOrSubscriberSearch The identifier to understand is accountId passed in the api request or not
     * @return A list of `ContactMedium` objects mapped from the input `CustomerV4Response`. If the input is null
     * or contains no valid contact mediums, an empty list is returned.
     */
    private List<ContactMedium> mapIndividualContactMedium(CustomerV4Response customerV4Response, boolean isAccountIdOrSubscriberSearch) {
        List<ContactMedium> contactMediums = new ArrayList<>();
        String serviceType = null;
        String targetSOR = null;
        logger.info("CCIH_08 : mapIndividualContactMedium method processing has started.");
        if (customerV4Response == null || customerV4Response.getIndividual()== null
                || customerV4Response.getIndividual().getContactMedium() == null || customerV4Response.getIndividual().getContactMedium().isEmpty()) {
            logger.warn("CCIH_09 : customerV4Response or its ContactMedium list is null/empty.Hence not processing individualContactMediums.");
            return contactMediums;
        }

        if(isAccountIdOrSubscriberSearch) {
            if(customerV4Response.getIndividual().getAccounts() == null ||
                    customerV4Response.getIndividual().getAccounts().isEmpty()) {
                logger.warn("CCIH_09a : customerV4Response or its Accounts list is null/empty.Hence not processing individualContactMediums.");
                return contactMediums;
            }
            serviceType = customerV4Response.getIndividual().getAccounts().get(0).getServiceType();
            targetSOR = customerV4Response.getIndividual().getAccounts().get(0).getTargetSOR();
        } else {
            targetSOR = Constants.TARGET_SOR_CG;
        }

        String createdOn = isAccountIdOrSubscriberSearch ? customerV4Response.getIndividual().getAccounts().get(0).getCreatedOn()
                : customerV4Response.getIndividual().getCreatedOn();


        if (createdOn == null) {
            logger.warn("mapIndividualContactMedium.CCIH_10 :CreatedOn is null from customerV4Response.Hence not processing individualContactMediums.");
            return contactMediums;
        }

        for (com.att.idp.dpl.profile.bsse.model.common.ContactMedium contactMedium : customerV4Response.getIndividual().getContactMedium()) {
            if (contactMedium == null || contactMedium.getMediumType() == null) {
                logger.warn("CCIH_11 : ContactMedium or its MediumType is null.");
                continue;
            }
            if (CommonDefs.EMAIL.equals(contactMedium.getMediumType()) || TELEPHONE.equals(contactMedium.getMediumType())) {
                contactMediums.add(populateIndividualContactMedium(contactMedium, createdOn, serviceType, targetSOR));
            }
        }
        logger.info("CCIH_12 : mapIndividualContactMedium method processing has been completed.");
        return contactMediums;
    }



    /**
     * Maps the accounts from the provided `CustomerV4Response` object to a list of `Account` objects.
     * <p>
     * This method processes the `Accounts` list from the input `CustomerV4Response` object, maps each account's
     * details (e.g., ID, state, service type, account type, and contact mediums), and populates the corresponding
     * `Account` objects. It also maps account-level subscribers and limits the number of subscribers to the first 25.
     *
     * @param customerV4Response The `CustomerV4Response` object containing the account data to be mapped.
     * @param returnBizCTNs The identifier to decide to include business CTNs in response or not
     * @return A list of `Account` objects mapped from the input `CustomerV4Response`. If the input is null
     * or contains no accounts, an empty list is returned.
     */
    private List<Account> mapIndividualAccounts(CustomerV4Response customerV4Response, String returnBizCTNs) {
        List<Account> accounts = new ArrayList<>();
        logger.info("CCIH_13 : mapIndividualAccounts method processing has started.");

        if (validateCustomerV4Response(customerV4Response)) {
            logger.warn("Accounts are null/empty for given accountId/individualId.");
            return accounts;
        }

        customerV4Response.getIndividual().getAccounts().forEach(account -> {
            if (validateCustomerV4Account(account)) {
                logger.warn("CCIH_14 : Account or its Contact list is null/empty.");
                return;
            }

            Account individualAccount = createIndividualAccount(account);
            individualAccount.setContacts(mapAccountContacts(account));

            List<com.att.idp.idgraphcontactinfoms.model.Subscribers> allSubscribers = mapAccountSubscribers(account,returnBizCTNs);
            if (allSubscribers == null || allSubscribers.isEmpty()) {
                logger.warn("CCIH_15 : No subscribers found for account ID: {}", account.getId());
                individualAccount.setSubscribers(new ArrayList<>());
            } else if (allSubscribers.size() > 25) {
                individualAccount.setSubscribers(allSubscribers.subList(0, 25));
            } else {
                individualAccount.setSubscribers(allSubscribers);
            }

            accounts.add(individualAccount);
        });

        logger.info("CCIH_22 : mapIndividualAccounts method processing has been completed.");
        return accounts;
    }

    /**
     * Validates the `CustomerV4Response` object to check if it contains valid account data.
     *
     * This method checks whether the provided `CustomerV4Response` object is null, whether its `Individual` object
     * is null, or whether the `Accounts` list within the `Individual` object is null or empty.
     *
     * @param customerV4Response The `CustomerV4Response` object to be validated.
     * @return `true` if the `CustomerV4Response` object is invalid (null, missing `Individual`, or empty `Accounts` list),
     *         otherwise `false`.
     */
    private boolean validateCustomerV4Response(CustomerV4Response customerV4Response) {
        return customerV4Response == null || customerV4Response.getIndividual() == null ||
                customerV4Response.getIndividual().getAccounts() == null ||
                customerV4Response.getIndividual().getAccounts().isEmpty();
    }

    /**
     * Validates the `Account` object to check if it contains valid data.
     *
     * This method checks whether the provided `Account` object is null, whether its `Contact` list is null or empty,
     * or whether the `CreatedOn` field is null. These validations ensure that the `Account` object has the necessary
     * data for further processing.
     *
     * @param account The `Account` object to be validated.
     * @return `true` if the `Account` object is invalid (null, missing `Contact` list, or null `CreatedOn` field),
     *         otherwise `false`.
     */
    private boolean validateCustomerV4Account(com.att.idp.dpl.profile.bsse.customerv4.Account account) {
        return account == null || account.getContact() == null || account.getContact().isEmpty() || account.getCreatedOn() == null;
    }

    /**
     * Creates an `Account` object and populates its fields based on the provided `Account` data.
     *
     * This method maps the details from the input `Account` object to a new `Account` instance.
     * It processes fields such as ID, state, service type, account type, account sub-type, and creation date.
     *
     * @param account The input `Account` object containing the data to be mapped.
     * @return A populated `Account` object with the mapped data.
     */
    private Account createIndividualAccount(com.att.idp.dpl.profile.bsse.customerv4.Account account) {
        Account individualAccount = new Account();
        individualAccount.setId(account.getId());
        if (account.getState() != null) {
            individualAccount.setState(account.getState().getState());
        }
        individualAccount.setServiceType(account.getServiceType());
        individualAccount.setAccountType(account.getAccountType());
        individualAccount.setAccountSubType(account.getAccountSubType());
        individualAccount.setCreatedOn(account.getCreatedOn());
        individualAccount.setTargetSOR(account.getTargetSOR());
        return individualAccount;
    }

    /**
     * Maps the contacts from the provided `Account` object to a list of `Contact` objects.
     *
     * This method processes the `Contact` list from the input `Account` object, maps each contact's
     * associated contact mediums, and populates the corresponding `Contact` objects. It filters out
     * any null or invalid contacts during the mapping process.
     *
     * @param account The `Account` object containing the contact data to be mapped.
     * @return A list of `Contact` objects mapped from the input `Account`. If the input `Account` has
     *         no valid contacts, an empty list is returned.
     */
    private List<Contact> mapAccountContacts(com.att.idp.dpl.profile.bsse.customerv4.Account account) {
        return account.getContact().stream().map(contact -> {
            if (contact == null || contact.getContactMedium() == null || contact.getContactMedium().isEmpty()) {
                return null;
            }
            Contact accountContact = new Contact();
            List<ContactMedium> contactMediums = contact.getContactMedium().stream()
                    .map(contactMedium -> populateAccountContactMedium(contactMedium, account.getCreatedOn(),account.getTargetSOR()))
                    .collect(Collectors.toList());
            accountContact.setContactMediums(contactMediums);
            return accountContact;
        }).filter(Objects::nonNull).collect(Collectors.toList());
    }

    /**
     * Maps the subscribers from the provided `Account` object to a list of `Subscribers` objects.
     * <p>
     * This method processes the `Subscribers` list from the input `Account` object, filters for active subscribers,
     * updates their CPNI (Customer Proprietary Network Information) details, and sorts them based on account type.
     * If the input `Account` has no subscribers or is of type "B", an empty list is returned.
     *
     * @param account       The `Account` object containing the subscriber data to be mapped.
     * @param returnBizCTNs The identifier to decide to include business CTNs in response or not
     * @return A list of `Subscribers` objects mapped from the input `Account`. If the input `Account` has no valid
     * subscribers, an empty list is returned.
     */
    private List<com.att.idp.idgraphcontactinfoms.model.Subscribers> mapAccountSubscribers(com.att.idp.dpl.profile.bsse.customerv4.Account account, String returnBizCTNs) {
        if (account.getSubscribers() == null || account.getSubscribers().isEmpty()
                || (Constants.ACCOUNT_TYPE_B.equals(account.getAccountType()) && CommonDefs.IND_N.equalsIgnoreCase(returnBizCTNs))) {
            logger.warn("CCIH_17 : mapAccountSubscribers: Input subscribers list is null or empty or accountType is B but returnBizCTNs is N . Hence, Returning empty list.");
            return new ArrayList<>();
        }

        List<Subscriber> activeSubscribers = getActiveSubscribers(account.getSubscribers());
        if (activeSubscribers == null || activeSubscribers.isEmpty()) {
            logger.warn("CCIH_19 : No active subscribers found for account ID: {}", account.getId());
            return new ArrayList<>();
        }

        List<com.att.idp.idgraphcontactinfoms.model.Subscribers> cpniUpdatedSubscribers = getCpniUpdatedSubscribers(activeSubscribers,account.getTargetSOR(),account.getCreatedOn());
        if (cpniUpdatedSubscribers == null || cpniUpdatedSubscribers.isEmpty()) {
            return new ArrayList<>();
        }

        return sortSubscribers(account.getAccountType(), cpniUpdatedSubscribers, returnBizCTNs);
    }

    /**
     * Sorts a list of `Subscribers` objects based on the account type and effective date.
     * <p>
     * This method sorts the input list of `Subscribers` objects differently depending on the account type:
     * - If the account type is "I", the subscribers are sorted by their effective date in ascending order.
     * - For other account types, the subscribers are sorted using the `getSortedSubscribersForCRU` method.
     * <p>
     * Any errors encountered during the sorting process are logged for debugging purposes.
     *
     * @param accountType            The type of account used to determine the sorting logic.
     * @param cpniUpdatedSubscribers A list of `Subscribers` objects to be sorted.
     * @param returnBizCTNs The identifier to decide to include business CTNs in response or not
     * @return A sorted list of `Subscribers` objects based on the account type and effective date.
     */
    private List<com.att.idp.idgraphcontactinfoms.model.Subscribers> sortSubscribers(String accountType, List<Subscribers> cpniUpdatedSubscribers, String returnBizCTNs) {
        if (Constants.ACCOUNT_TYPE_B.equals(accountType) && CommonDefs.IND_Y.equalsIgnoreCase(returnBizCTNs)) {
            try {
                cpniUpdatedSubscribers = getSortedSubscribersForCRU(cpniUpdatedSubscribers);
            } catch (Exception e) {
                logger.error("CCIH_20 : Error sorting subscribers by effective date: {}", e.getMessage(), e);
            }
        } else {
            if (cpniUpdatedSubscribers != null && !cpniUpdatedSubscribers.isEmpty()) {
                try {
                    sortSubscribersByEffectiveDate(cpniUpdatedSubscribers);
                } catch (Exception e) {
                    logger.error("CCIH_20 : Error sorting subscribers by effective date: {}", e.getMessage(), e);
                }
            }
        }
        return cpniUpdatedSubscribers;
    }

    /**
     * Generates a list of `Contact` objects for a given subscriber.
     * <p>
     * This method creates a `Individual Subscriber Contact` object for the provided subscriber, including its associated
     * `ContactMedium` and `Characteristic` details. It also updates the CPNI eligibility of the subscriber
     * based on their status and SMS capability.
     *
     * @param subscriber       The `Subscribers` object containing the subscriber's details.
     * @param targetSOR The identifier of the system of record, used for CPNI eligibility updates.
     * @param accountCreatedOn
     * @return A list of `Contact` objects for the given subscriber. The list will contain one `Contact` object
     * with its associated `ContactMedium` and `Characteristic`.
     */
    private List<Contact> populateIndividualSubscriberContacts(Subscriber subscriber, String targetSOR, String accountCreatedOn) {
        List<ContactMedium> alSubContactMedium = new ArrayList<>();
        List<Contact> alSubContact = new ArrayList<>();
        Contact contact = new Contact();
        ContactMedium contactMedium = new ContactMedium();
        String status = subscriber.getStatus() != null ? subscriber.getStatus().getStatus() : null;
        boolean smsCapable = false;
        String simSwapDate = null;
        Map<String, Object> subscriberAttrs = cgUtilHelper.resolveSubscriberDeviceDetailsByTargetSOR(subscriber, targetSOR);
        if (subscriberAttrs == null) {
            subscriberAttrs = new HashMap<>();
        }

        com.att.idp.idgraphcontactinfoms.model.Characteristic characteristic = new com.att.idp.idgraphcontactinfoms.model.Characteristic();
        characteristic.setPhoneNumber(subscriber.getPhoneNumber());

        Object smsCapabilityOfSub = subscriberAttrs.get(Constants.SMS_CAPABILITY_IND);
        Object simSwapDateOfSub = subscriberAttrs.get(Constants.SIM_SWAP_DATE_VALUE);

        String duoIdentifier = subscriber.getDuoIdentifier();
        if (Constants.DUO_IDENTIFIER_COMPANION.equalsIgnoreCase(duoIdentifier)) {
            // companion subscribers are CPNI ineligible
            logger.info("{}{}CCIH_DUO_01 : duoIdentifier is companion for CTN {}, setting cpniEligible=false",
                    sClassName, ".populateIndividualSubscriberContacts.", CommonUtilHelper.sanitizeForLog(subscriber.getPhoneNumber()));
            characteristic.setCpniEligible(false);
        } else {
            //  anchor / null / empty — apply existing BAU CPNI eligibility rules
            if(targetSOR != null  && Constants.TARGET_SOR_CG.equalsIgnoreCase(targetSOR)) {
                // to process BSSE wireless
                smsCapable = smsCapabilityOfSub != null ? Boolean.valueOf(smsCapabilityOfSub.toString()) : false;
                simSwapDate = simSwapDateOfSub != null ? simSwapDateOfSub.toString() : null;
                cpniEligibilityHelper.updateSubscriberCPNIEligibility(characteristic, status, smsCapable,simSwapDate,accountCreatedOn);
            } else {
                // to process legacy wireless
                String smsCapabilityValue = smsCapabilityOfSub != null ? smsCapabilityOfSub.toString() : null;
                if (CommonDefs.IND_Y.equals(smsCapabilityValue)) {
                    smsCapable = true;
                } else if (CommonDefs.IND_N.equals(smsCapabilityValue)) {
                    smsCapable = false;
                }
                simSwapDate = simSwapDateOfSub != null ? simSwapDateOfSub.toString() : null;
                cpniEligibilityHelper.updateSubscriberCPNIEligibilityForLegacy(characteristic, status, smsCapable, simSwapDate, accountCreatedOn);
            }
        }

        contactMedium.setMediumType("ctn");
        contactMedium.setCharacteristic(characteristic);
        alSubContactMedium.add(contactMedium);
        contact.setContactMediums(alSubContactMedium);
        alSubContact.add(contact);
        return alSubContact;
    }

    /**
     * Updates the list of subscribers with CPNI (Customer Proprietary Network Information) details.
     * <p>
     * This method processes a list of active subscribers, maps their details to a new list of
     * `Subscribers` objects, and updates their CPNI-related information such as contact details
     * and effective date.
     *
     * @param activeSubscribers A list of active `Subscribers` objects to be processed.
     * @param targetSOR The identifier of the system of record, used for CPNI eligibility updates.
     * @param accountCreatedOn account creation date
     * @return A list of `Subscribers` objects with updated CPNI details.
     */
    private List<com.att.idp.idgraphcontactinfoms.model.Subscribers> getCpniUpdatedSubscribers(List<Subscriber> activeSubscribers, String targetSOR, String accountCreatedOn) {
        List<com.att.idp.idgraphcontactinfoms.model.Subscribers> cpniUpdatedSubscribers = new ArrayList<>();
        if (activeSubscribers == null) {
            return cpniUpdatedSubscribers;
        }
        activeSubscribers.forEach(subscriber -> {
            if(subscriber != null) {
                com.att.idp.idgraphcontactinfoms.model.Subscribers accSubscriber = new com.att.idp.idgraphcontactinfoms.model.Subscribers();
                List<Contact> alSubContact = populateIndividualSubscriberContacts(subscriber,targetSOR,accountCreatedOn);
                if(subscriber.getStatus() != null) {
                    String status = subscriber.getStatus().getStatus();
                    accSubscriber.setStatus(status);
                }
                if(Constants.TARGET_SOR_CG.equalsIgnoreCase(targetSOR) && subscriber.getUpdatedOn() != null) {
                    accSubscriber.setEffectiveDate(subscriber.getUpdatedOn());
                } else if(subscriber.getEffectiveDate() != null) {
                    accSubscriber.setEffectiveDate(subscriber.getEffectiveDate());
                }
                accSubscriber.setSubscriberId(subscriber.getPhoneNumber());
                accSubscriber.setContact(alSubContact);
                cpniUpdatedSubscribers.add(accSubscriber);
            }
        });

        return cpniUpdatedSubscribers;
    }

    /**
     * Sorts a list of subscribers by their effective date in ascending order (oldest first).
     * <p>
     * This method handles null safety and date parsing errors gracefully.
     * Subscribers with null effective dates are placed at the end of the sorted list.
     *
     * @param subscribers The list of subscribers to sort
     */
    private void sortSubscribersByEffectiveDate(List<com.att.idp.idgraphcontactinfoms.model.Subscribers> subscribers) {
        if (subscribers == null || subscribers.isEmpty()) {
            return;
        }
        
        subscribers.sort((s1, s2) -> {
            try {
                if (s1 == null || s1.getEffectiveDate() == null) {
                    return 1;
                }
                if (s2 == null || s2.getEffectiveDate() == null) {
                    return -1;
                }
                
                ZonedDateTime date1 = parseEffectiveDate(s1.getEffectiveDate());
                ZonedDateTime date2 = parseEffectiveDate(s2.getEffectiveDate());
                return date1.toLocalDate().compareTo(date2.toLocalDate());
            } catch (Exception parseException) {
                logger.warn("CCIH_22 : Error parsing effective date for subscriber sorting: {}", parseException.getMessage());
                return 0;
            }
        });
    }

    /**
     * Parses effective date string into ZonedDateTime, handling multiple date formats.
     * <p>
     * This method attempts to parse the date string using multiple formatters:
     * 1. ISO_ZONED_DATE_TIME (e.g., "2026-02-09T09:35:04.298Z")
     * 2. DATE_TIME_FORMAT_LEGACY (e.g., "2025-12-18 00:00:00")

     *
     * @param dateString The date string to parse
     * @return ZonedDateTime representation of the date
     * @throws Exception if the date cannot be parsed with any supported format
     */
    private ZonedDateTime parseEffectiveDate(String dateString) throws Exception {
        if (dateString == null || dateString.trim().isEmpty()) {
            throw new Exception("Date string is null or empty for subscriber sorting");
        }

        //  ISO_ZONED_DATE_TIME first (e.g., "2026-02-09T09:35:04.298Z") - BSSE format
        try {
            return ZonedDateTime.parse(dateString, DateTimeFormatter.ISO_ZONED_DATE_TIME);
        } catch (Exception e) {
            try {
                //  custom format for "2025-12-18 00:00:00" - Legacy Format
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern( Constants.DATE_TIME_FORMAT_LEGACY);
                return LocalDateTime.parse(dateString, formatter).atZone(ZoneId.systemDefault());
            } catch (Exception ex) {
                logger.error("CCIH_21 : Error parseEffectiveDate: Unable to parse date '{}' with either ISO or legacy format", dateString, ex);
                throw new Exception("Unable to parse date while subscriber sorting: " + dateString);
            }
        }
    }

    /**
     * Sorts a list of `Subscribers` objects based on CPNI eligibility and effective date.
     *
     * This method performs the following operations in sequence:
     * 1. Filters to include only CPNI-eligible subscribers
     * 2. Sorts the filtered subscribers by effective date in ascending order (oldest first)
     * 3. Limits the final result to maximum 25 subscribers
     *
     * @param cpniUpdatedSubscribers A list of `Subscribers` objects to be filtered and sorted.
     * @return A list containing maximum 25 CPNI-eligible subscribers sorted by effective date (oldest first).
     */
    private List<com.att.idp.idgraphcontactinfoms.model.Subscribers> getSortedSubscribersForCRU(List<com.att.idp.idgraphcontactinfoms.model.Subscribers> cpniUpdatedSubscribers) {

        List<com.att.idp.idgraphcontactinfoms.model.Subscribers> sortedSubscribers = new ArrayList<>();
        try {
            // First: Filter CPNI-eligible subscribers only
            List<com.att.idp.idgraphcontactinfoms.model.Subscribers> cpniEligibleSubscribers = cpniUpdatedSubscribers.stream()
                    .filter(this::isCpniEligible)
                    .collect(Collectors.toList());

            // Second: Sort by effective date (oldest first) using reusable method
            sortSubscribersByEffectiveDate(cpniEligibleSubscribers);

            // Third: Limit to maximum 25 subscribers
            sortedSubscribers = cpniEligibleSubscribers.stream()
                    .limit(25)
                    .collect(Collectors.toList());

        } catch (Exception e) {
            logger.error("CCIH_21 : getSortedSubscribersForCRU: Error occurred while sorting subscribers: {}", e.getMessage(), e);
        }
        return sortedSubscribers;
    }

    /**
     * Filters and retrieves a list of active subscribers from the provided list of subscribers.
     *
     * This method processes the input list of `Subscribers` objects and filters out only those
     * subscribers whose status is "active".
     *
     * @param subscribers A list of `Subscribers` objects to be filtered.
     * @return A list of `Subscribers` objects with a status of "active". If the input list is null
     *         or contains no active subscribers, an empty list is returned.
     */
    private List<Subscriber> getActiveSubscribers(List<Subscriber> subscribers) {
        // Filter subscribers to get only those with status "active"/"A"
        return subscribers.stream()
                .filter(subscriber -> {
                    if (subscriber == null || subscriber.getStatus() == null) {
                        logger.warn("CCIH_18 : getActiveSubscribers: Subscriber or its Status is null.");
                        return false;
                    }
                    return cpniEligibilityHelper.isActiveStatus(subscriber.getStatus().getStatus());
                })
                .collect(Collectors.toList());
    }

    /**
     * Populates a `ContactMedium` object with the provided data.
     *
     * This method maps the details from the input `ContactMedium` object to a new `ContactMedium` instance.
     * It processes the medium type, preferred status, and associated characteristics, and updates the
     * CPNI (Customer Proprietary Network Information) eligibility based on the provided establishment
     * and creation dates.
     *
     * @param contactMedium The input `ContactMedium` object containing the data to be mapped.
     * @param createdOn The creation date of the contact medium, used for CPNI eligibility updates.
     * @return A populated `ContactMedium` object with the mapped data.
     */
    private ContactMedium populateIndividualContactMedium(com.att.idp.dpl.profile.bsse.model.common.ContactMedium contactMedium, String createdOn, String serviceType, String targetSOR) {
        ContactMedium individualContactMedium = new ContactMedium();

        String dateTimeFormat = Constants.TARGET_SOR_CG.equalsIgnoreCase(targetSOR) ? Constants.DATE_TIME_FORMAT_BSSE : Constants.DATE_TIME_FORMAT_LEGACY;

        if (TELEPHONE.equals(contactMedium.getMediumType())) {
            individualContactMedium.setMediumType(CBR);
        } else {
            individualContactMedium.setMediumType(contactMedium.getMediumType());
        }
        individualContactMedium.setPreferred(contactMedium.getPreferred());
        com.att.idp.idgraphcontactinfoms.model.Characteristic individualCharacteristic = new com.att.idp.idgraphcontactinfoms.model.Characteristic();
        com.att.idp.dpl.profile.bsse.model.common.Characteristic characteristic = contactMedium.getCharacteristic();
        if (characteristic != null) {
            String establishmentDate = characteristic.getEstablishmentDate();
            individualCharacteristic.setEmailAddress(characteristic.getEmailAddress());
            individualCharacteristic.setVerified(characteristic.getVerified());
            individualCharacteristic.setEstablishmentDate(establishmentDate);
            individualCharacteristic.setPhoneNumber(characteristic.getPhoneNumber());
            individualCharacteristic.setSubContactType(characteristic.getSubContactType());
            // handling Uverse CBR specific CPNI eligibility separately because it is different than remaining
            if(serviceType != null && "UVERSE".equalsIgnoreCase(serviceType) && TELEPHONE.equals(contactMedium.getMediumType())) {
                // verified = true means phoneNumberValidationStatus is "8"
                // verified = false means phoneNumberValidationStatus is "7" or "9"
                // establishmentDate is nothing but phoneNumberModifiedDate
                cpniEligibilityHelper.updateCPNIEligibilityForUverseCBR(individualCharacteristic, establishmentDate, characteristic.getVerified(),dateTimeFormat);
            } else {
                cpniEligibilityHelper.updateCPNIEligibility(individualCharacteristic, establishmentDate, createdOn, targetSOR);
            }
        }
        individualContactMedium.setCharacteristic(individualCharacteristic);
        return individualContactMedium;
    }

    /**
     * Populates a `ContactMedium` object with the provided data.
     * <p>
     * This method maps the details from the input `ContactMedium` object to a new `ContactMedium` instance.
     * It processes the medium type, preferred status, and associated characteristics, and updates the
     * CPNI (Customer Proprietary Network Information) eligibility based on the provided establishment
     * and creation dates.
     *
     * @param contactMedium The input `ContactMedium` object containing the data to be mapped.
     * @param createdOn     The creation date of the contact medium, used for CPNI eligibility updates.
     * @param targetSOR The identifier of the system of record, used for CPNI eligibility updates.
     * @return A populated `ContactMedium` object with the mapped data.
     */
    private ContactMedium populateAccountContactMedium(com.att.idp.dpl.profile.bsse.model.common.ContactMedium contactMedium, String createdOn, String targetSOR) {
        ContactMedium accContactMedium = new ContactMedium();
        try {
            String mediumType = contactMedium.getMediumType();
            accContactMedium.setMediumType(mediumType);
            accContactMedium.setPreferred(contactMedium.getPreferred());
            com.att.idp.idgraphcontactinfoms.model.Characteristic individualAccCharacteristic = new com.att.idp.idgraphcontactinfoms.model.Characteristic();
            Characteristic characteristic = contactMedium.getCharacteristic();
            if (characteristic != null) {
                String establishmentDate = characteristic.getEstablishmentDate();
                individualAccCharacteristic.setContactType(characteristic.getContactType());
                individualAccCharacteristic.setVerified(characteristic.getVerified());
                individualAccCharacteristic.setEstablishmentDate(establishmentDate);
                if (CommonDefs.EMAIL.equals(mediumType)) {
                    individualAccCharacteristic.setEmailAddress(characteristic.getEmailAddress());
                } else if (POSTAL_ADDRESS.equals(mediumType)) {
                    individualAccCharacteristic.setCity(characteristic.getCity());
                    individualAccCharacteristic.setCountry(characteristic.getCountry());
                    individualAccCharacteristic.setPostCode(characteristic.getPostCode());
                    individualAccCharacteristic.setStateOrProvince(characteristic.getStateOrProvince());
                    individualAccCharacteristic.setStreet1(characteristic.getStreet1());
                    individualAccCharacteristic.setStreet2(characteristic.getStreet2());
                }
                cpniEligibilityHelper.updateCPNIEligibility(individualAccCharacteristic, establishmentDate, createdOn, targetSOR);
            }
            accContactMedium.setCharacteristic(individualAccCharacteristic);
        } catch (Exception e) {
            logger.error("CCIH_16 : populateIndividualAccContactMedium: Error processing contactMedium: {}", e.getMessage(), e);
        }
        return accContactMedium;
    }
    /**
     * Determines if a `Subscribers` object is CPNI (Customer Proprietary Network Information) eligible.
     *
     * This method checks the `Contact` list within the provided `Subscribers` object and iterates through
     * its associated `ContactMedium` objects to find a `Characteristic` with a non-null `cpniEligible` property.
     * If such a property is found and is `true`, the subscriber is considered CPNI eligible.
     *
     * @param subscriber The `Subscribers` object to be checked for CPNI eligibility.
     * @return `true` if the subscriber is CPNI eligible, otherwise `false`.
     */
    private boolean isCpniEligible(com.att.idp.idgraphcontactinfoms.model.Subscribers subscriber) {
        if (subscriber == null || subscriber.getContact() == null) {
            return false;
        }

        for (Contact contact : subscriber.getContact()) {
            if (contact == null || contact.getContactMediums() == null) {
                continue;
            }

            for (ContactMedium contactMedium : contact.getContactMediums()) {
                if (contactMedium != null && contactMedium.getCharacteristic() != null
                        && contactMedium.getCharacteristic().getCpniEligible() != null) {
                    return contactMedium.getCharacteristic().getCpniEligible();
                }
            }
        }

        return false;
    }

    /**
     * Checks if the provided list of accounts contains at least one account with service type "wireless".
     *
     * @param accounts the list of {@link Account} objects to check
     * @return {@code true} if any account in the list has a service type of "wireless"; {@code false} otherwise,
     *         or if the list is null or empty
     */
    public boolean isWirelessPresent(List<Account> accounts) {
        if (accounts == null || accounts.isEmpty()) {
            return false;
        }
        return accounts.stream().anyMatch(account -> "wireless".equalsIgnoreCase(account.getServiceType()));
    }

    /**
     * Applies exploitable rules to the provided list of individual contact mediums.
     *
     * <p>
     * If any wireless account is present in the provided accounts list, this method removes all contact mediums
     * of type "email" or "cbr" from the contactMediums list and returns immediately.
     * <br>
     * If no wireless account is present, it removes contact mediums of type "email" or "cbr" only if their
     * characteristic's cpniEligible or verified property is explicitly set to false.
     * </p>
     *
     * @param contactMediums the list of {@link ContactMedium} objects to which exploitable rules will be applied
     * @param accounts the list of {@link Account} objects used to determine if wireless accounts are present
     */
    private void applyExploitableRulesForIndividual(List<ContactMedium> contactMediums, List<Account> accounts) {
        if (isWirelessPresent(accounts)) {
            contactMediums.removeIf(cm ->
                    (CommonDefs.EMAIL.equalsIgnoreCase(cm.getMediumType()) || CBR.equalsIgnoreCase(cm.getMediumType())));
            return;
        }

        if (contactMediums == null || contactMediums.isEmpty()) {
            return;
        }

        contactMediums.removeIf(cm ->
                (CommonDefs.EMAIL.equalsIgnoreCase(cm.getMediumType()) || CBR.equalsIgnoreCase(cm.getMediumType())) &&
                        (Boolean.FALSE.equals(cm.getCharacteristic().getCpniEligible()) ||
                                Boolean.FALSE.equals(cm.getCharacteristic().getVerified()))
        );
    }

    /**
     * Applies exploitable rules to the provided list of accounts.
     *
     * <p>
     * This method enforces the following rules for accounts with service type "wireless":
     * <ul>
     *   <li>Removes contact mediums of type "postalAddress" or "email" from all contacts of wireless accounts.</li>
     *   <li>Removes subscribers from wireless accounts if all their contact mediums have <code>cpniEligible</code> set to <code>false</code>
     *       (i.e., keeps only subscribers with at least one contact medium where <code>cpniEligible</code> is <code>true</code>).</li>
     * </ul>
     * If the input list is null, empty, or contains no wireless accounts, the method returns immediately.
     *
     * @param accounts the list of {@link Account} objects to which exploitable rules will be applied
     */
    private void applyExploitableRulesForAccounts(List<Account> accounts) {
        if (accounts == null || accounts.isEmpty()) {
            return;
        }

        // Check if any wireless account is present
        boolean hasWirelessAccount = accounts.stream()
                .anyMatch(account -> "wireless".equalsIgnoreCase(account.getServiceType()));

        // If there is no wireless account, we can skip further checks
        if (!hasWirelessAccount) {
            return;
        }


        for (Account account : accounts) {
            if ("wireless".equalsIgnoreCase(account.getServiceType()) && account.getContacts() != null) {

                // Remove contact mediums of type "postalAddress" or "email" from contacts of wireless accounts
                for (Contact contact : account.getContacts()) {
                    if (contact.getContactMediums() != null) {
                        contact.getContactMediums().removeIf(contactMedium ->
                                POSTAL_ADDRESS.equalsIgnoreCase(contactMedium.getMediumType()) ||
                                        CommonDefs.EMAIL.equalsIgnoreCase(contactMedium.getMediumType())
                        );
                    }
                }

                // Remove subscribers where all contactMediums' cpniEligible is false from contacts of wireless accounts
                if (account.getSubscribers() != null) {
                    account.getSubscribers().removeIf(subscriber -> {
                        if (subscriber.getContact() == null) return true;
                        // Remove if cpniEligible is not true
                        return subscriber.getContact().stream()
                                .flatMap(c -> c.getContactMediums() != null ? c.getContactMediums().stream() : Stream.empty())
                                .filter(cm -> cm != null && cm.getMediumType() != null)
                                .noneMatch(cm -> cm.getCharacteristic() != null &&
                                        Boolean.TRUE.equals(cm.getCharacteristic().getCpniEligible()));
                    });
                }
            }
        }

    }
}

