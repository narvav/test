package com.att.idp.idgraphcontactinfoms.helpers;

import com.att.idp.core.exception.ServiceException;
import com.att.idp.idgraphcontactinfoms.message.ErrorMessages;
import com.att.idp.idgraphcontactinfoms.model.Characteristic;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.idp.idgraphcontactinfoms.utils.Constants;
import com.att.idp.logging.marker.SpiMarker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDate;

@Component
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class CPNIEligibilityHelper {

    private static String sClassName = "CPNIEligibilityHelper";
    public static final Logger logger = LoggerFactory.getLogger(CPNIEligibilityHelper.class);

    @Value("${SIM_SWAP_AGING_DAYS}")
    private String sSimSwapAgingDays;

    /**
     * Updates the CPNI (Customer Proprietary Network Information) eligibility and isAged of a `individualCharacteristic` object.
     *
     * This method determines whether the provided `Characteristic` object is CPNI eligible based on the
     * establishment date of the email, the creation date of the individual, and the current date minus 30 days.
     * It updates the `cpniEligible` and `isAged` properties of the `Characteristic` object accordingly.
     *
     * @param individualCharacteristic The `individualCharacteristic` object to be updated with CPNI eligibility and isAged.
     * @param establishmentDate The establishment date of the email in the format "yyyy-MM-dd'T'HH:mm:ss.SSSX".
     * @param creationDate The creation date of the individual in the format "yyyy-MM-dd'T'HH:mm:ss.SSSX".
     * @return The updated `individualCharacteristic` object with the `cpniEligible` and `isAged` properties set.
     */
    public Characteristic updateCPNIEligibility(Characteristic individualCharacteristic, String establishmentDate, String creationDate, String targetSOR) {

        logger.info(SpiMarker.getInstance(), "CPNIEligibilityHelper.updateCPNIEligibility.HLP000 : Input : {} {} {}",
                individualCharacteristic,establishmentDate,creationDate);
        String stAppInfo = null;
        String sMethodName = ".updateCPNIEligibility.";
        if(StringUtils.isBlank(targetSOR)) {
            stAppInfo = "targetSOR is null/empty.";
            logger.error("{}{}CEH_00 : {}", sClassName, sMethodName, stAppInfo);
            throw new ServiceException(ErrorMessages.MS_MPSYS_BE_100, stAppInfo);
        }
        String dateTimeFormat = Constants.TARGET_SOR_CG.equalsIgnoreCase(targetSOR) ? Constants.DATE_TIME_FORMAT_BSSE : Constants.DATE_TIME_FORMAT_LEGACY;

        //Setting CpniEligible and isAged as false when outbound api returns establishmentDate as null
        if( StringUtils.isBlank(establishmentDate)) {
            stAppInfo = "establishmentDate from outbound api response is null. We are setting CPNI eligibility as false";
            individualCharacteristic.setCpniEligible(Boolean.FALSE);
            individualCharacteristic.setIsAged(Boolean.FALSE);
            logger.info("{}{}CEH_01 : {}", sClassName, sMethodName, stAppInfo);
        } else if(StringUtils.isBlank(creationDate)) {
            stAppInfo = "creationDate from outbound api response is null. We are setting CPNI eligibility as false";
            individualCharacteristic.setCpniEligible(Boolean.FALSE);
            LocalDate establishmentDateOnly = CommonUtilHelper.extractDate(establishmentDate,dateTimeFormat);
            LocalDate currentDateMinus30Days = LocalDate.now().minusDays(30);
            boolean isAged = !establishmentDateOnly.isAfter(currentDateMinus30Days);
            individualCharacteristic.setIsAged(isAged);
            logger.info("{}{}CEH_01 : {}", sClassName, sMethodName, stAppInfo);
        }else {
            // Extract only the date part (yyyy-MM-dd) from the input strings
            LocalDate establishmentDateOnly = CommonUtilHelper.extractDate(establishmentDate,dateTimeFormat);
            LocalDate individualCreationDateOnly = CommonUtilHelper.extractDate(creationDate,dateTimeFormat);
            LocalDate currentDateMinus30Days = LocalDate.now().minusDays(30);

            boolean isAged = !establishmentDateOnly.isAfter(currentDateMinus30Days);
            boolean cpniEligible = isAged || !establishmentDateOnly.isAfter(individualCreationDateOnly);
            individualCharacteristic.setCpniEligible(cpniEligible);
            individualCharacteristic.setIsAged(isAged);
        }
        return individualCharacteristic;
    }
    /**
     * Updates the CPNI (Customer Proprietary Network Information) eligibility of a `Characteristic` object
     * based on the subscriber's status and SMS capability.
     * <p>
     * This method checks if the subscriber's status is "active" (case-insensitive) and if they are SMS capable.
     * If both conditions are met, the `cpniEligible` property of the `Characteristic` object is set to `true`.
     * Otherwise, it is set to `false`.
     *
     * @param characteristic   The `Characteristic` object to be updated with CPNI eligibility.
     * @param status           The status of the subscriber (e.g., "active").
     * @param smsCapable       A boolean indicating whether the subscriber is SMS capable.
     * @return The updated `Characteristic` object with the `cpniEligible` property set.
     */
    public Characteristic updateSubscriberCPNIEligibility(Characteristic characteristic, String status, boolean smsCapable,String simSwapDate, String accountCreatedOn) {
        boolean isSimSwapValidationPassed = simSwapDate != null ? simSwapDateValidation(simSwapDate, accountCreatedOn, Constants.DATE_TIME_FORMAT_BSSE) : true;
        if(isActiveStatus(status) && smsCapable && isSimSwapValidationPassed) {
            characteristic.setCpniEligible(true);
        } else {
            characteristic.setCpniEligible(false);
        }
        return characteristic;
    }

    /**
     * Updates the CPNI (Customer Proprietary Network Information) eligibility of a {@link Characteristic} object
     * for legacy systems based on subscriber status, SMS capability, and SIM swap validation.
     * <p>
     * This method checks if the subscriber's status is active, if they are SMS capable, and if the SIM swap date
     * validation passes. If all conditions are met, the {@code cpniEligible} property of the {@link Characteristic}
     * object is set to {@code true}; otherwise, it is set to {@code false}.
     *
     * @param characteristic   the {@link Characteristic} object to be updated with CPNI eligibility
     * @param status           the status of the subscriber (e.g., "active")
     * @param smsCapable       {@code true} if the subscriber is SMS capable; {@code false} otherwise
     * @param simSwapDate      the SIM swap date string
     * @param accountCreatedOn the account creation date string
     * @return the updated {@link Characteristic} object with the {@code cpniEligible} property set
     */
    public Characteristic updateSubscriberCPNIEligibilityForLegacy(Characteristic characteristic, String status, boolean smsCapable, String simSwapDate, String accountCreatedOn) {
        boolean isSimSwapValidationPassed = simSwapDateValidation(simSwapDate, accountCreatedOn, Constants.DATE_TIME_FORMAT_LEGACY);
        if(isActiveStatus(status) && smsCapable && isSimSwapValidationPassed) {
            characteristic.setCpniEligible(true);
        } else {
            characteristic.setCpniEligible(false);
        }
        return characteristic;
    }

    /**
     * Checks if the subscriber status is active.
     *
     * @param status The status of the subscriber.
     * @return True if the status is active, false otherwise.
     */
    boolean isActiveStatus(String status) {
        return "active".equalsIgnoreCase(status) || "A".equalsIgnoreCase(status);
    }

    /**
     * Validates SIM swap date against aging days and account creation date.
     *
     * @param simSwapDate      SIM swap date string
     * @param accountCreatedOn Account creation date string
     * @param dateTimeFormat date-time pattern used to parse the date strings (for example, "yyyy-MM-dd HH:mm:ss")
     * @return true if SIM swap validation passes, false otherwise
     */
    boolean simSwapDateValidation(String simSwapDate, String accountCreatedOn, String dateTimeFormat) {
        logger.info("CEH_01: SIM_SWAP_AGING_DAYS : {}", sSimSwapAgingDays);
        String simSwapAgingDays = StringUtils.isBlank(sSimSwapAgingDays) ? "2" : sSimSwapAgingDays;
        if (StringUtils.isNotBlank(simSwapDate)) {
            boolean isCtnAged = CommonUtilHelper.checkAging(simSwapDate, simSwapAgingDays, dateTimeFormat);
            logger.info("{}{}CEH_02 : CTN Aged:: {}", sClassName, ".simSwapDateValidation.", isCtnAged);
            if (isCtnAged) {
                return true;
            }
            if (StringUtils.isNotBlank(accountCreatedOn)) {
                LocalDate createdOnDate = CommonUtilHelper.extractDate(accountCreatedOn,dateTimeFormat);
                LocalDate simSwapLocalDate = CommonUtilHelper.extractDate(simSwapDate,dateTimeFormat);
                if (createdOnDate.isEqual(simSwapLocalDate)) {
                    logger.info("{}{}CEH_03 : Account CreatedOn is same as SIM_SWAP_DATE", sClassName, ".simSwapDateValidation.");
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Updates the CPNI (Customer Proprietary Network Information) eligibility and aging status for U-verse CBR.
     * <p>
     * This method determines CPNI eligibility and aging status for the provided {@link Characteristic} object
     * based on the establishment date and verification status. If either the establishment date is blank or
     * the verification status is null, both eligibility and aging are set to false. Otherwise, the method
     * extracts the date portion from the establishment date, checks if it is aged (older than 30 days),
     * and sets CPNI eligibility to true only if both aged and verified.
     *
     * @param individualCharacteristic the {@link Characteristic} object to update
     * @param establishmentDate the establishment date in ISO format (e.g., "yyyy-MM-dd'T'HH:mm:ss.SSSX")
     * @param isVerified the verification status; may be {@code null}
     * @return the updated {@link Characteristic} object with CPNI eligibility and aging status set
     */
    public Characteristic updateCPNIEligibilityForUverseCBR(Characteristic individualCharacteristic, String establishmentDate, Boolean isVerified, String dateTimeFormat) {

        logger.info(SpiMarker.getInstance(), "CPNIEligibilityHelper.updateCPNIEligibilityForUverseCBR.HLP000 : Input : {} {} {}", individualCharacteristic,establishmentDate,isVerified);
        String stAppInfo = null;
        String sMethodName = ".updateCPNIEligibilityForUverseCBR.";
        LocalDate currentDateMinus30Days = LocalDate.now().minusDays(30);
        //Setting CpniEligible and isAged as false when outbound api returns establishmentDate as null
        if( StringUtils.isBlank(establishmentDate)) {
            stAppInfo = "establishmentDate or isVerified from outbound api response is null. We are setting CPNI eligibility as false";
            individualCharacteristic.setCpniEligible(Boolean.FALSE);
            individualCharacteristic.setIsAged(Boolean.FALSE);
            logger.info("{}{}CEH_01 : {}", sClassName, sMethodName, stAppInfo);
        } else if( isVerified == null) {
            //Setting CpniEligible and isAged as false when outbound api returns isVerified as null
            stAppInfo = "isVerified from outbound api response is null. We are setting CPNI eligibility as false";
            individualCharacteristic.setCpniEligible(Boolean.FALSE);
            LocalDate establishmentDateOnly = CommonUtilHelper.extractDate(establishmentDate,dateTimeFormat);
            boolean isAged = !establishmentDateOnly.isAfter(currentDateMinus30Days);
            individualCharacteristic.setIsAged(isAged);
            logger.info("{}{}CEH_01 : {}", sClassName, sMethodName, stAppInfo);

        }else {
            // Extract only the date part (yyyy-MM-dd) from the input strings
            LocalDate establishmentDateOnly = CommonUtilHelper.extractDate(establishmentDate,dateTimeFormat);
            boolean isAged = !establishmentDateOnly.isAfter(currentDateMinus30Days);
            boolean cpniEligible = isAged && isVerified;
            individualCharacteristic.setCpniEligible(cpniEligible);
            individualCharacteristic.setIsAged(isAged);
        }
        return individualCharacteristic;
    }

}