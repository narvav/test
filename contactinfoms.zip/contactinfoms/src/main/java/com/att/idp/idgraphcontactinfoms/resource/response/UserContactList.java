package com.att.idp.idgraphcontactinfoms.resource.response;

import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.response package.
 *
 * The UserContactList class is used to represent a list of user contacts.
 * It contains two fields: email and usPhoneNumber.
 *
 * The email field is an object of the Email class, representing the email of the user.
 * The usPhoneNumber field is an object of the USPhoneNumber class, representing the US phone number of the user.
 *
 * Each field has a corresponding getter and setter method, allowing the fields to be accessed and modified.
 */
@Data
public class UserContactList {

	private Email email;
	private USPhoneNumber usPhoneNumber;
}