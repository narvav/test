package com.att.idp.idgraphcontactinfoms.service;

import java.io.IOException;
import java.util.Map;

/**
 * This interface is part of the com.att.idp.idgraphcontactinfoms.service package.
 *
 * The CGRestClientService interface defines a contract for a service that interacts with a CG REST client.
 * It declares a single method, cgRestClient, which takes a Map of String to Object as input and returns a Map of String to Object.
 *
 * The cgRestClient method is expected to perform some operation using the CG REST client, using the input Map as parameters for the operation.
 * The method is declared to throw an IOException, indicating that it may encounter an IO error during its operation.
 */
public interface CGRestClientService {

	/**
	 * This method is part of the CGRestClientService interface in the com.att.idp.idgraphcontactinfoms.service package.
	 *
	 * The cgRestClient method is used to perform some operation using the CG REST client.
	 * It takes a Map of String to Object as input, which represents the parameters for the operation.
	 * It returns a Map of String to Object, which represents the result of the operation.
	 *
	 * The method is declared to throw an IOException, indicating that it may encounter an IO error during its operation.
	 */
	public Map<String, Object> cgRestClient(Map<String, Object> hmNotification) throws IOException;

}
