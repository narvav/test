package com.att.idp.idgraphcontactinfoms.helpers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import com.att.mpsys.common.helpers.FeatureManagerHelper;

import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.RILDefs;

import net.logstash.logback.argument.StructuredArguments;

import static com.att.idp.idgraphcontactinfoms.utils.Constants.CLIENT_ID_CSIGATEWAY;

/**
 * This class is a helper class for generating PINs.
 *
 * It contains methods for generating a security code with respect to identification type and account ID.
 * The class uses the Spring Framework's @Component annotation to indicate that it is a bean and can be used for dependency injection.
 * It also uses the @PropertySource annotation to specify the location of the properties file.
 *
 * The class has several instance variables that are injected using the @Autowired and @Value annotations.
 * These variables include a BeanFactory,  a DeletePINHelper, and several properties from the properties file.
 *
 * The main method in this class is the generatePin method, which takes a HashMap as input and returns a HashMap as output.
 * The generatePin method uses several other methods in the class to validate the input data, process the input data, and store the data.
 * It also makes synchronous and asynchronous calls to the MULESOFT service.
 *
 * The class also contains a logger for logging information and error messages.
 */
@Component
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class GeneratePINHelper {

	private static String sClassName = "GeneratePINHelper.";
	public static final Logger logger = LoggerFactory.getLogger(GeneratePINHelper.class);

	@Value("${PROP_DELETE_PREVIOUS_PIN_CSI}")
	private String propDeletePreviousPinCSI;

	@Value("${PROP_CCMULE_IDENTIFICATION_TYPES}")
	private String sCCMuleIdentificationTypes;

    @Value("${PROP_CCMULE_IDENTIFICATION_TYPES_CLM}")
    private String sCCMuleIdentificationTypesClm;
	
	@Value("${PROP_AEHGENERICOTP_IDENTIFICATION_TYPES}")
	private String sAEHGENERICOTPIdentificationTypes;

	@Autowired
	private BeanFactory objGeneratePINBaseFactory;

	@Autowired
	private DeletePINHelper deletePinHelper;

    @Autowired
    FeatureManagerHelper featureManager;
	
	
	/**
	 * This method generates a PIN (Personal Identification Number) based on the input parameters.
	 *
	 * It first retrieves the identification type and account ID from the input HashMap.
	 * Then, it validates the input data, processes the input data, and stores the data.
	 * If the identification type is included in the 'CCMULE_IDENTIFICATION_TYPES' property, the method makes a synchronous call to the MULESOFT service.
	 * If the identification type is not included in the 'CCMULE_IDENTIFICATION_TYPES' property, the method makes an asynchronous call.
	 * The method then checks the response from the MULESOFT service. If the response indicates an error, the method constructs an error response and returns it.
	 * If the response from the MULESOFT service indicates success, the method constructs a success response and returns it.
	 * The success response includes the generated PIN and its expiration date.
	 *
	 * @param hmInput a HashMap that contains the input data for the PIN generation. The HashMap should include the identification type, account ID, and other necessary information.
	 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code, an application info message, the generated PIN, and its expiration date.
	 * @throws Exception if an error occurs during the operation.
	 */
	public Map<String, Object> generatePin(Map<String, Object> hmInput) {
		String sMethodName = ".generatePin.";
		logger.info(SpiMarker.getInstance(), "GeneratePINHelper.generatePin.HLP000 : Input Hash : {}",
				StructuredArguments.entries(hmInput));

		Map hmResult = null;
		String stAppInfo = null;
		String stAppStatusCode = null;
		boolean isTransactionRollbackOnError = false;

		String sIdentificationType = (String) hmInput.get(CommonDefs.IDENTIFICATION_TYPE);
		String sAccountID = (String) hmInput.get(CommonDefs.ACCOUNT_ID);
		String sAgentId = (String) hmInput.get(CommonDefs.AGENT_ID);
		String sReturnSecurityCode = (String) hmInput.get(CommonDefs.RETURN_SECURITY_CODE);
        boolean isOtpEddToClmEnabled = false;

		try {

            isOtpEddToClmEnabled = featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled");

			GeneratePINBase generatePINBaseObj = (GeneratePINBase) objGeneratePINBaseFactory.getBean("generatePINBase");

			generatePINBaseObj.initialize(hmInput);
			
			
			logger.info(sClassName + sMethodName +"GPH_02 : Calling generatePINBaseObj.validateInputData with hminput : " + hmInput);

			hmResult = generatePINBaseObj.validateSecurityCodeData();

			logger.info(sClassName + sMethodName +"GPH_03 : Response from generatePINBaseObj.validateInputData : " + hmResult);

			stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
				logger.info(sClassName + sMethodName +"GPH_02.2 : " + stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);				
				return hmResult;
			}
			

			HashMap hmPropDeletePreviousPinCsi = CommonUtil.parseMultiDelimiterProperty(propDeletePreviousPinCSI);
			ArrayList alValidDeletePINCaller = null;
			HashMap hmDeletePinInp = new HashMap();
			logger.info("{}{}GPH_1 : PROP_DELETE_PREVIOUS_PIN_CSI : {}", sClassName, sMethodName,
					hmPropDeletePreviousPinCsi);

			if (hmPropDeletePreviousPinCsi != null && !hmPropDeletePreviousPinCsi.isEmpty()
					&& hmPropDeletePreviousPinCsi.containsKey(sIdentificationType)) {
				alValidDeletePINCaller = (ArrayList) hmPropDeletePreviousPinCsi.get(sIdentificationType);

				if (alValidDeletePINCaller != null
						&& alValidDeletePINCaller.contains((String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID))) {

					hmDeletePinInp.put(CommonDefs.TRANSACTION_NAME, "DeletePIN");
					hmDeletePinInp.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(CommonDefs.TRANSACTION_ID));
					hmDeletePinInp.put(CommonDefs.ACCOUNT_ID, sAccountID);
					hmDeletePinInp.put(CommonDefs.IDENTIFICATION_TYPE, sIdentificationType);
					hmDeletePinInp.put(CommonDefs.CALLING_SYSTEM_ID,
							(String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
					hmDeletePinInp.put(CommonDefs.DELETE_All, CommonDefs.IND_Y);
					hmDeletePinInp.put(CommonDefs.AGENT_ID, sAgentId);
					if ((String) hmInput.get(CommonDefs.SOURCE_IP_ADDRESS) != null
							&& !((String) hmInput.get(CommonDefs.SOURCE_IP_ADDRESS)).isEmpty()) {
						hmDeletePinInp.put(CommonDefs.SOURCE_IP_ADDRESS,
								(String) hmInput.get(CommonDefs.SOURCE_IP_ADDRESS));
					}

					logger.debug("{}{}GPH_2 : Calling DeletePinHelper.deletePIN() with input: : {}", sClassName,
							sMethodName, hmDeletePinInp);

					hmResult = deletePinHelper.deletePin(hmDeletePinInp);

					logger.debug("{}{}GPH_3 : Response from DeletePinHelper.deletePIN() is: {}", sClassName,
							sMethodName, hmResult);

					stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
					if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {

						logger.debug("{}{}GPH_4 : DeletePinHelper.deletePIN() returned error: {}", sClassName,
								sMethodName, hmResult);
						return hmResult;
					}
				}

			}

			logger.debug("{}{}GPH_5 : Calling generatePINBaseObj.generateOTPWithLockoutCheck with hminput : {}", sClassName,
					sMethodName, ESAPI.encoder().encodeForHTML(String.valueOf(hmInput)));

			hmResult = generatePINBaseObj.generateOTPWithLockoutCheck();

			logger.debug("{}{}GPH_6 : Response from generatePINBaseObj.generateOTPWithLockoutCheck : {}", sClassName, sMethodName,
					ESAPI.encoder().encodeForHTML(String.valueOf(hmResult)));

			stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
				logger.debug("{}{}GPH_7 : Response from generatePINBaseObj.generateOTPWithLockoutCheck : {}", sClassName,
						sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
				return hmResult;
			}

			hmResult = generatePINBaseObj.storeMPSData();

			logger.debug("{}{}GPH_8 : Response from generatePINBaseObj.storeMPSData : {}", sClassName, sMethodName,
					hmResult);

			stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
				logger.debug("{}{}GPH_9 : Response from generatePINBaseObj.storeMPSData : {}", sClassName, sMethodName,
						stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
				isTransactionRollbackOnError = true;
				return hmResult;
//			} else {
				
			}

			ArrayList alCCMuleIdentificationTypes = null;
			ArrayList alCommNotifications = null;
			ArrayList alGenericAEHNotificationIdentificationTypes= null;

			if (sCCMuleIdentificationTypes == null || sCCMuleIdentificationTypes.isEmpty()) {
				stAppInfo = "PROP_CCMULE_IDENTIFICATION_TYPES is null or empty";

				logger.debug("{}{}GPH_10 :{}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
				return hmResult;
			}
			
			if (sAEHGENERICOTPIdentificationTypes != null && !sAEHGENERICOTPIdentificationTypes.isEmpty())
				alGenericAEHNotificationIdentificationTypes = CommonUtil.parseToArray(sAEHGENERICOTPIdentificationTypes, CommonDefs.VALUE_SEPARATOR_CHAR);

            if(isOtpEddToClmEnabled){
                alCCMuleIdentificationTypes = CommonUtil.parseToArray(sCCMuleIdentificationTypesClm, CommonDefs.VALUE_SEPARATOR_CHAR);
            } else{
                alCCMuleIdentificationTypes = CommonUtil.parseToArray(sCCMuleIdentificationTypes, CommonDefs.VALUE_SEPARATOR_CHAR);
            }

			if (alCCMuleIdentificationTypes != null && alCCMuleIdentificationTypes.contains(sIdentificationType)) {

				HashMap hmInpDeliveryMethods = (HashMap) hmInput.get(CommonDefs.DELIVERY_METHODS);

				if (hmInpDeliveryMethods != null && !hmInpDeliveryMethods.isEmpty()) {
					logger.info("{}{}GPH_11 : Calling generatePINBaseObj.prepareDataForCCMuleSyncCall() {}", sClassName,
							sMethodName, sMethodName);
					hmResult = generatePINBaseObj.prepareDataForCCMuleSyncCall();

					if (hmResult == null || hmResult.isEmpty()) {

						stAppInfo = "Null Response returned from prepareDataForCCMuleSyncCall";
						logger.info("{}{}GPH_13 : {}", sClassName, sMethodName, stAppInfo);
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
						return hmResult;
					}

					stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
					if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {

						stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
						logger.info("{}{}GPH_14 : {}", sClassName, sMethodName, stAppInfo);
						hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
						return hmResult;
					}

					alCommNotifications = (ArrayList) hmResult.get(CommonDefs.COMMUNICATION_NOTIFICATION);

//				logger.info("{}{}GPH_15 : Calling generatePINBaseObj.makeCCMuleSyncCall() with input : {}", sClassName,
//						sMethodName, alCommNotifications);
					hmResult = generatePINBaseObj.makeCCMuleSyncCall(alCommNotifications);

					logger.info(SpiMarker.getInstance(),
							"GeneratePINHelper.generatePin.GPH_16 : Response from generatePINBaseObj.makeCCMuleSyncCall : {}",
							StructuredArguments.entries(hmResult));

					if (hmResult == null || hmResult.isEmpty()) {

						stAppInfo = "Null Response returned by makeCCMuleSyncCall";
						logger.info("{}{}GPH_17 : {}", sClassName, sMethodName, stAppInfo);
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
						return hmResult;
					}

					stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
					if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {

						if (stAppStatusCode == null) {
							stAppInfo = "Error Response returned by makeCCMuleSyncCall";
							logger.info("{}{}GPH_18.1 : {}:{}", sClassName, sMethodName, stAppInfo, hmResult);
							hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
						} else {
							stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
							logger.info("{}{}GPH_18.2 : {}", sClassName, sMethodName, stAppInfo);
							hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
						}

						return hmResult;

					} else {
						isTransactionRollbackOnError = true;
					}

				} else {
					logger.info("{}{}GPH_18.3 : CCMule call is skipped since delivery method is null", sClassName,
							sMethodName);

					if (sReturnSecurityCode != null && !sReturnSecurityCode.isEmpty()
							&& sReturnSecurityCode.equalsIgnoreCase(RILDefs.YES)) {
						hmResult.put(CommonDefs.SECURITY_CODE, (String) hmInput.get(CommonDefs.SECURITY_CODE));
					}
					hmResult.put(CommonDefs.SECURITY_PIN_EXPIRATION_DATE, (String) hmInput.get(CommonDefs.SECURITY_PIN_EXPIRATION_DATE));
				}
			}
			else {

				logger.info(SpiMarker.getInstance(),
						"GeneratePINHelper.generatePin.GPH_19 : Calling generatePINBaseObj.prepareDataForAsyncCall with hminput : {}",
						StructuredArguments.entries(hmInput));

				hmResult = generatePINBaseObj.prepareDataForAsyncCall();

				stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

				if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
					logger.debug("{}{}GPH_21 : Response from generatePINBaseObj.prepareDataForAsyncCall : {}",
							sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
					return hmResult;
				}

				ArrayList alDbusInp = (ArrayList) hmResult.get(CommonDefs.CONSOLIDATED_DBUS_INPUT);

				hmResult = generatePINBaseObj.makeAsyncCall(alDbusInp);

				logger.debug(SpiMarker.getInstance(),
						"GeneratePINHelper.generatePin.GPH_23 : Response from generatePINBaseObj.makeAsyncCall : {}",
						StructuredArguments.entries(hmResult));

				stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

				if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);

					logger.debug("{}{}GPH_24: {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
					isTransactionRollbackOnError = true;
					return hmResult;
					
				}
			}
			//Check for async GENERIC Notification Via AEH required
			if(alGenericAEHNotificationIdentificationTypes != null && alGenericAEHNotificationIdentificationTypes.contains(sIdentificationType))
			{
				hmResult = generatePINBaseObj.makeGenericOTPAEHCall(hmInput);

				logger.info(SpiMarker.getInstance(),"GeneratePINHelper.generatePin.GPH_16 : Response from generatePINBaseObj.makeGenericOTPAEHCall : {}",
						StructuredArguments.entries(hmResult));

				if (hmResult == null || hmResult.isEmpty()) {

					stAppInfo = "Null Response returned by makeGenericOTPAEHCall";
					logger.info("{}{}GPH_17 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					return hmResult;
				}

				hmResult.put(CommonDefs.SECURITY_CODE, (String) hmInput.get(CommonDefs.SECURITY_CODE));
				hmResult.put(CommonDefs.SECURITY_PIN_EXPIRATION_DATE, (String) hmInput.get(CommonDefs.SECURITY_PIN_EXPIRATION_DATE));

			}
			
			//to support CSIGATEWAY callers need to return security code till test environment
			boolean iscsigatewayReturnSecrutiyCode=false;
			iscsigatewayReturnSecrutiyCode = featureManager.isEnabled("svc-idgraph-contactinfoms-csigateway-return-securitycode");
			String sSecurityCode = (String) hmResult.get(CommonDefs.SECURITY_CODE);
			String stSecurityCodeExpiryDate = (String) hmResult.get(CommonDefs.SECURITY_PIN_EXPIRATION_DATE);
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "SUCCESS");
            String callingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			if ((sReturnSecurityCode != null && !sReturnSecurityCode.isEmpty()	&& sReturnSecurityCode.equalsIgnoreCase(RILDefs.YES) && callingSystemId != null && !CLIENT_ID_CSIGATEWAY.equalsIgnoreCase(callingSystemId) ) ||
					(CLIENT_ID_CSIGATEWAY.equalsIgnoreCase(callingSystemId) && iscsigatewayReturnSecrutiyCode)) {
				hmResult.put(CommonDefs.SECURITY_CODE, sSecurityCode);
			}

            if (callingSystemId != null && CLIENT_ID_CSIGATEWAY.equalsIgnoreCase(callingSystemId)) {
                if (stSecurityCodeExpiryDate != null && stSecurityCodeExpiryDate.length() >= 8) {
                    hmResult.put(CommonDefs.SECURITY_CODE_EXPIRES, (stSecurityCodeExpiryDate.substring(0, 8)));
                }
            } else {
                hmResult.put(CommonDefs.SECURITY_CODE_EXPIRES, stSecurityCodeExpiryDate); // 1810 : return
            }																		// stSecurityCodeExpiryDate
																						// always irrespective to
																						// sReturnSecurityCode value

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);

		} finally {

			logger.debug(SpiMarker.getInstance(),
					"GeneratePINHelper.generatePin.GPH_25 : Response from GeneratePINHelper.generatePIN : {}",
					StructuredArguments.entries(hmResult));

			if (hmResult == null || hmResult.isEmpty()) {
				stAppInfo = "Response from GeneratePINHelper is NULL";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.debug("{}{}GPH_26 : Response from GeneratePINHelper.generatePIN : {}", sClassName,
						sMethodName, stAppInfo);
			}

			String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);

			if (isTransactionRollbackOnError && sAppCategoryCode != null
					&& !sAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
				hmResult.put("isTransactionRollback", "Y");
			}

			logger.info(SpiMarker.getInstance(), "GeneratePINHelper response.HLP999 : Input Hash : {}",
					StructuredArguments.entries(hmResult));
		}
		return hmResult;

	}
}
