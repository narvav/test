package com.att.idp.idgraphcontactinfoms.db.helper;


import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.StatusMsg;
/**
 * The ContactDBHelper class is a helper class that interacts with the database for contact-related operations.
 * It is annotated with @Component to indicate that it is an autodetectable bean, so Spring can pick it up and pull it into the application context.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.db.helper package.
 *
 * It contains a JdbcTemplate property and a DBHelper property that are autowired, meaning Spring will automatically inject instances of JdbcTemplate and DBHelper into this class.
 * JdbcTemplate is a Spring JDBC template used to run SQL queries and updates, while DBHelper is a custom helper class.
 *
 * It also contains a Logger property for logging purposes.
 *
 * The class defines several methods for interacting with the contact database, including getUserContact, addUserContact, and updateUserContact.
 */
@Component
public class ContactDBHelper {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private DBHelper oDBHelper;
	
	private static final Logger logger = LoggerFactory.getLogger(ContactDBHelper.class);
	private static String sClassName = "ContactDBHelper";

	private static final ArrayList<Object> alUpdateKeys = CommonUtil.getArrayList();
	static {
		alUpdateKeys.add("contact_desc");
		alUpdateKeys.add("phone_number");
		alUpdateKeys.add("phone_ext");
		alUpdateKeys.add("subscription_id");
		alUpdateKeys.add("email_address");
		alUpdateKeys.add("contact_status");
		alUpdateKeys.add("phone_number_type");
		alUpdateKeys.add("validation_status");
		alUpdateKeys.add("atlas_last_timestamp");
	}

	private static final ArrayList<Object> alUpperCaseKeys = CommonUtil.getArrayList();
	static {
		alUpperCaseKeys.add("contact_status");
	}

	private static final ArrayList<Object> alLowerCaseKeys = CommonUtil.getArrayList();
	static {
		alLowerCaseKeys.add("phone_number");
		alLowerCaseKeys.add("email_address");
	}

	/**
	 * This method is responsible for retrieving user contact information from the database.
	 *
	 * It takes a HashMap as an input parameter, which contains key-value pairs of the contact details to be retrieved.
	 * The keys in the HashMap can include "contact_id", "member_num", "contact_type", and "subscription_id".
	 *
	 * The method first checks if the required keys are present in the HashMap. If not, it returns an error.
	 * Then, it constructs a SQL query based on the input parameters and executes it using the jdbcTemplate.
	 * The result of the query is a list of HashMaps, where each HashMap represents a row in the result set.
	 * Each key-value pair in the HashMap corresponds to a column name and its value in the result set.
	 *
	 * If the query is successful, the method returns a HashMap containing the result set and a success message.
	 * If the query fails, it returns a HashMap containing an error message.
	 *
	 * @param hmInput a HashMap containing the contact details to be retrieved.
	 * @return a HashMap containing the result of the query.
	 */
	public HashMap<String, Object> getUserContact(HashMap<String, Object> hmInput) {
		String sMethodName = ".getUserContact.";

		HashMap<String, Object> hmResult = null;
		String stAppInfo = null;
		String dateFormat = "MMDDYYYY HH24:mi:ss";
		List<Object> objectList = new ArrayList<Object>();
		List alQueryResponse = null;

		String getContactSql = "SELECT CONTACT_ID, MEMBER_NUM, "
				+ "CONTACT_TYPE, CONTACT_DESC, PHONE_NUMBER, PHONE_EXT, PHONE_NUMBER_TYPE, "
				+ "SUBSCRIPTION_ID, EMAIL_ADDRESS, CONTACT_STATUS, TO_CHAR(ESTABLISHED_DATE, '" + dateFormat
				+ "') AS ESTABLISHED_DATE, TO_CHAR(CREATE_DATE, '" + dateFormat
				+ "') AS CREATE_DATE, CREATED_BY, TO_CHAR(LAST_MODIFIED, '" + dateFormat
				+ "') AS LAST_MODIFIED, TO_CHAR(VALIDATION_STATUS_DATE, '" + dateFormat
				+ "') AS VALIDATION_STATUS_DATE, VALIDATION_STATUS, LAST_MODIFIED_BY " + "FROM contact ";

		String sWhereClause = null;

		logger.info("{}{}DB_GC_01 : CVS KEYWORDS: ", sClassName, sMethodName);
		logger.info("{}{}DBTOOLS000 : Input Hash : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmInput)));

		try {
			String sContactId = (String) hmInput.get("contact_id");
			String sMemberNum = (String) hmInput.get("member_num");
			String sContactType = (String) hmInput.get("contact_type");
			String sSubscriptionId = (String) hmInput.get("subscription_id");

			if ((sContactId == null || sContactId.trim().length() == 0)
					&& (sMemberNum == null || sMemberNum.trim().length() == 0)
					&& (sSubscriptionId == null || sSubscriptionId.trim().length() == 0)) {
				stAppInfo = "contact_id and member_num and subscription_id all are null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}DB_GC_03 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			if (sContactType != null && !sContactType.isEmpty()) {
				sContactType = sContactType.toUpperCase().trim();
			}

			/*if (sContactId != null && !sContactId.isEmpty()) {
				sWhereClause = " WHERE CONTACT_ID = ?";
				getContactSql = getContactSql + sWhereClause;
				logger.info("{}{}SQL000 : getContactSql : {}", sClassName, sMethodName, getContactSql);
				objectList.add(sContactId);
			} else*/ if (sContactType != null && !sContactType.isEmpty() && sMemberNum != null && !sMemberNum.isEmpty()) {
				sWhereClause = " WHERE MEMBER_NUM = ? AND CONTACT_TYPE = ?";
				getContactSql = getContactSql + sWhereClause;
				logger.info("{}{}SQL000 : getContactSql : {}", sClassName, sMethodName, getContactSql);
				objectList.add(sMemberNum);
				objectList.add(sContactType);
			} else if (sMemberNum != null && !sMemberNum.isEmpty()) {
				sWhereClause = " WHERE MEMBER_NUM = ?";
				getContactSql = getContactSql + sWhereClause;
				logger.info("{}{}SQL000 : getContactSql : {}", sClassName, sMethodName, getContactSql);
				objectList.add(sMemberNum);
			} /*else if (sSubscriptionId != null && !sSubscriptionId.isEmpty()) {
				sWhereClause = " WHERE SUBSCRIPTION_ID = ?";
				getContactSql = getContactSql + sWhereClause;
				logger.info("{}{}SQL000 : getContactSql : {}", sClassName, sMethodName, getContactSql);
				objectList.add(sSubscriptionId);
			}*/

			alQueryResponse = jdbcTemplate.queryForList(new String(getContactSql),
					objectList.toArray(new Object[objectList.size()]));

			if (alQueryResponse != null && !alQueryResponse.isEmpty()) {
				ArrayList<Object> alContactList = CommonUtil.getArrayList();
				HashMap<String, Object> hmContacts = CommonUtil.getHashMap();
				int numRowsFound = 0;

				for (int j = 0; j < alQueryResponse.size(); j++) {
					Map hmQueryResponse = (Map) alQueryResponse.get(j);

					Iterator itr = hmQueryResponse.keySet().iterator();
					while (itr.hasNext()) {
						String key = (String) itr.next();
						Object value = hmQueryResponse.get(key);
						String strValue = (value == null ? null : value.toString());
						hmContacts.put(key.toLowerCase(), strValue);
					}
					
					String validation_status = (String) hmContacts.get("validation_status");

					if (validation_status != null) {
						String validation_status_name = oDBHelper.getStatusNameByCode(Integer.parseInt(validation_status));
						hmContacts.put("validation_status_name", validation_status_name);
					}

					/*HashMap<String, Object> hmContacts = CommonUtil.getHashMap();
					hmContacts.put("contact_id", (String) hmQueryResponse.get("contact_id"));
					hmContacts.put("member_num", (String) hmQueryResponse.get("member_num"));
					hmContacts.put("contact_type", (String) hmQueryResponse.get("contact_type"));

					hmContacts.put("phone_number_type", (String) hmQueryResponse.get("phone_number_type"));

					String validation_status = (String) hmQueryResponse.get("validation_status");
					hmContacts.put("validation_status", validation_status);

					if (validation_status != null) {
						String validation_status_name = oDBHelper.getStatusNameByCode(Integer.parseInt(validation_status));
						hmContacts.put("validation_status_name", validation_status_name);
					}

					hmContacts.put("validation_status_date", (String) hmQueryResponse.get("validation_status_date"));

					if ((String) hmQueryResponse.get("contact_desc") != null) {
						hmContacts.put("contact_desc", (String) hmQueryResponse.get("contact_desc"));
					}

					if ((String) hmQueryResponse.get("phone_number") != null) {
						hmContacts.put("phone_number", (String) hmQueryResponse.get("phone_number"));
					}

					if ((String) hmQueryResponse.get("phone_ext") != null) {
						hmContacts.put("phone_ext", (String) hmQueryResponse.get("phone_ext"));
					}

					if ((String) hmQueryResponse.get("subscription_id") != null) {
						hmContacts.put("subscription_id", (String) hmQueryResponse.get("subscription_id"));
					}

					if ((String) hmQueryResponse.get("email_address") != null) {
						hmContacts.put("email_address", (String) hmQueryResponse.get("email_address"));
					}

					hmContacts.put("contact_status", (String) hmQueryResponse.get("contact_status"));
					hmContacts.put("established_date", (String) hmQueryResponse.get("established_date"));
					hmContacts.put("create_date", (String) hmQueryResponse.get("create_date"));
					hmContacts.put("created_by", (String) hmQueryResponse.get("created_by"));
					hmContacts.put("last_modified", (String) hmQueryResponse.get("last_modified"));
					hmContacts.put("last_modified_by", (String) hmQueryResponse.get("last_modified_by"));*/

					alContactList.add(hmContacts);
					++numRowsFound;
				}

				logger.info("{}{}DBTOOLS09.1 : Number of rows found : {}", sClassName, sMethodName, numRowsFound);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS);
				hmResult.put("contacts", alContactList);

			} else {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
						CErrorDefs.ERR_REC_NOT_FOUND_MSG);
				logger.info("{}{}DBTOOLS05 : No rows found", sClassName, sMethodName);
				return hmResult;
			}

		} catch (Exception e) {
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}DBHLPE01 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}DBHLPE02 : Exception = {}", sClassName, sMethodName, e);
		} finally {
			logger.info("{}{}DBTOOLS999 response : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmResult)));
		}
		return hmResult;
	}

	/**
	 * This method is responsible for adding new user contact information to the database.
	 *
	 * It takes a HashMap as an input parameter, which contains key-value pairs of the contact details to be added.
	 * The keys in the HashMap can include "contact_id", "member_num", "contact_type", "phone_number", "email_address", and others.
	 *
	 * The method first checks if the required keys are present in the HashMap. If not, it returns an error.
	 * Then, it constructs a SQL insert query based on the input parameters and executes it using the jdbcTemplate.
	 *
	 * If the insert is successful, the method returns a HashMap containing a success message and the number of rows inserted.
	 * If the insert fails, it returns a HashMap containing an error message.
	 *
	 * @param hmInput a HashMap containing the contact details to be added.
	 * @return a HashMap containing the result of the insert operation.
	 */
	public HashMap<String, Object> addUserContact(HashMap<String, Object> hmInput) {
		String sMethodName = ".addUserContact.";

		HashMap<String, Object> hmResult = null;
		String stAppInfo = null;
		List<Object> objectList = new ArrayList<Object>();

		String addContactSql = "INSERT INTO contact(" + "CONTACT_ID, " + "MEMBER_NUM, " + "CONTACT_TYPE, "
				+ "CONTACT_DESC, " + "PHONE_NUMBER, " + "PHONE_EXT, " + "SUBSCRIPTION_ID, " + "EMAIL_ADDRESS, "
				+ "CONTACT_STATUS, " + "ESTABLISHED_DATE, " + "CREATED_BY, " + "LAST_MODIFIED_BY, "
				+ "PHONE_NUMBER_TYPE, VALIDATION_STATUS, VALIDATION_STATUS_DATE " + ") VALUES("
				+ "?, ?, ?, ?, ?, ?, ?, ?, ?, SYSDATE, ?, ?, ?, ?, ?)";

		logger.info("{}{}DB_AC_01 : CVS KEYWORDS: ", sClassName, sMethodName);
		logger.info("{}{}DBTOOLS000 : Input Hash : {}", sClassName, sMethodName,
				hmInput != null ? StringUtils.normalizeSpace(hmInput.toString()) : null);

		Date dtStart = new Date();

		try {
			String stCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sMemberNum = (String) hmInput.get("member_num");
			String sContactId = (String) hmInput.get("contact_id");
			String sContactType = (String) hmInput.get("contact_type");
			String sPhoneNumber = (String) hmInput.get("phone_number");
			String sEmailAddress = (String) hmInput.get("email_address");
			String sContactStatus = (String) hmInput.get("contact_status");
			String sContactDesc = (String) hmInput.get("contact_desc");
			String sPhoneExt = (String) hmInput.get("phone_ext");
			String sSubscriptionId = (String) hmInput.get("subscription_id");
			String sPhoneNumberType = (String) hmInput.get("phone_number_type");
			String sValidationStatus = (String) hmInput.get("validation_status");

			if (stCallingSystemId == null || stCallingSystemId.trim().length() == 0 || sMemberNum == null
					|| sMemberNum.trim().length() == 0 || sContactId == null || sContactId.trim().length() == 0
					|| sContactType == null || sContactType.trim().length() == 0) {
				stAppInfo = "callingSystemId/member_num/contact_id/contact_type is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}DB_AC_03 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			if (((sPhoneNumber == null || sPhoneNumber.isEmpty()) && (sEmailAddress == null || sEmailAddress.isEmpty()))
					|| ((sPhoneNumber != null && !sPhoneNumber.isEmpty())
							&& (sEmailAddress != null && !sEmailAddress.isEmpty()))) {
				stAppInfo = "phone_number and email_address cannot be both null or present at the same time";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}DB_AC_04 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			sContactType = sContactType.toUpperCase().trim();

			if (sContactStatus != null && !sContactStatus.isEmpty()) {
				sContactStatus = sContactStatus.toUpperCase().trim();
			} else {
				sContactStatus = "V";
			}

			long member_num = Long.parseLong(sMemberNum);
			long contact_id = Long.parseLong(sContactId);

			logger.info("{}{}SQL000 : addContactSql : {}", sClassName, sMethodName, addContactSql);

			objectList.add(contact_id);
			objectList.add(member_num);
			objectList.add(sContactType);

			if (sContactDesc != null) {
				objectList.add(sContactDesc);
				logger.debug("{}{}DB_AC_05 : sContactDesc::PARAM 4 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sContactDesc)));
			} else {
				objectList.add(null);
				logger.debug("{}{}DB_AC_05 : sContactDesc::PARAM 4 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sContactDesc)));
			}

			if (sPhoneNumber != null) {
				sPhoneNumber = sPhoneNumber.trim().toLowerCase();
				objectList.add(sPhoneNumber);
				logger.debug("{}{}DB_AC_06 : sPhoneNumber::PARAM 5 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sPhoneNumber)));
			} else {
				objectList.add(null);
				logger.debug("{}{}DB_AC_06 : sPhoneNumber::PARAM 5 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sPhoneNumber)));
			}

			if (sPhoneExt != null) {
				objectList.add(sPhoneExt);
				logger.debug("{}{}DB_AC_07 : sPhoneExt::PARAM 6 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sPhoneExt)));
			} else {
				objectList.add(null);
				logger.debug("{}{}DB_AC_07 : sPhoneExt::PARAM 6 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sPhoneExt)));
			}

			if (sSubscriptionId != null) {
				objectList.add(sSubscriptionId);
				logger.debug("{}{}DB_AC_08 : sSubscriptionId::PARAM 7 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sSubscriptionId)));
			} else {
				objectList.add(null);
				logger.debug("{}{}DB_AC_08 : sSubscriptionId::PARAM 7 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sSubscriptionId)));
			}

			if (sEmailAddress != null) {
				sEmailAddress = sEmailAddress.trim().toLowerCase();
				objectList.add(sEmailAddress);
				logger.debug("{}{}DB_AC_09 : sEmailAddress::PARAM 8 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sEmailAddress)));
			} else {
				objectList.add(null);
				logger.debug("{}{}DB_AC_09 : sEmailAddress::PARAM 8 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sEmailAddress)));
			}

			objectList.add(sContactStatus);
			logger.debug("{}{}DB_AC_10 : sContactStatus::PARAM 9 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sContactStatus)));
			objectList.add(stCallingSystemId);
			objectList.add(stCallingSystemId);
			logger.debug("{}{}DB_AC_11 : stCallingSystemId::PARAM 10 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stCallingSystemId)));

			if (sPhoneNumberType != null && !sPhoneNumberType.isEmpty()) {
				objectList.add(sPhoneNumberType);
				logger.debug("{}{}DB_AC_12 : sPhoneNumberType::PARAM 12 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sPhoneNumberType)));
			} else {
				objectList.add(null);
				logger.debug("{}{}DB_AC_12 : sPhoneNumberType::PARAM 12 = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sPhoneNumberType)));
			}

			Date dtStartDate = new Date();
			java.sql.Date sysDate = null;

			if (sValidationStatus != null && !sValidationStatus.isEmpty()) {
				sysDate = new java.sql.Date(dtStartDate.getTime());
				objectList.add(sValidationStatus);
				logger.debug("{}{}DB_AC_13 : sValidationStatus::PARAM 13 = {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(sValidationStatus)));
				objectList.add(sysDate);
				logger.debug("{}{}DB_AC_14 : sysDate::PARAM 14 = {}", sClassName, sMethodName, sysDate);
			} else {
				objectList.add(null);
				logger.debug("{}{}DB_AC_13 : sValidationStatus::PARAM 13 = {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(sValidationStatus)));
				objectList.add(null);
				logger.debug("{}{}DB_AC_14 : sysDate::PARAM 14 = {}", sClassName, sMethodName, sysDate);
			}

			int rowCount = jdbcTemplate.update(new String(addContactSql),
					objectList.toArray(new Object[objectList.size()]));

			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
					"Number of rows inserted:= " + rowCount);

			logger.info("{}{}DB_AC_10 : Number of rows inserted:= {}", sClassName, sMethodName, rowCount);

		} catch (Exception e) {
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}DBHLPE01 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}DBHLPE02 : Exception = {}", sClassName, sMethodName, e);
			
		} finally {
			logger.info("{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmResult)));
		}
		return hmResult;
	}

	/**
	 * This method is responsible for updating user contact information in the database.
	 *
	 * It takes a HashMap as an input parameter, which contains key-value pairs of the contact details to be updated.
	 * The keys in the HashMap can include "contact_id", "member_num", "contact_type", "phone_number", "email_address", and others.
	 *
	 * The method first checks if the required keys are present in the HashMap. If not, it returns an error.
	 * Then, it constructs a SQL update query based on the input parameters and executes it using the jdbcTemplate.
	 *
	 * If the update is successful, the method returns a HashMap containing a success message and the number of rows updated.
	 * If the update fails, it returns a HashMap containing an error message.
	 *
	 * @param hmInput a HashMap containing the contact details to be updated.
	 * @return a HashMap containing the result of the update operation.
	 */
	public HashMap<String, Object> updateUserContact(HashMap<String, Object> hmInput) {
		String sMethodName = ".updateUserContact.";

		HashMap<String, Object> hmResult = null;
		String stAppInfo = null;
		List<Object> objectList = new ArrayList<Object>();

		StringBuilder updateContactSql = new StringBuilder("UPDATE contact SET ");
		String sWhereClause = "";

		logger.info("{}{}DB_UC_01 : CVS KEYWORDS: ", sClassName, sMethodName);
		logger.info("{}{}DBTOOLS000 : Input Hash : {}", sClassName, sMethodName, StringUtils.normalizeSpace(hmInput!=null ? hmInput.toString() : null));

		Date dtStart = new Date();

		try {
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sUpdateEstablishedDate = (String) hmInput.get("updateEstablishedDate");
			String sValidationStatusDateFlag = (String) hmInput.get("validation_status_date_flag");
			String sMemberNum = (String) hmInput.get("member_num");
			String sContactType = (String) hmInput.get("contact_type");

			if (sCallingSystemId == null || sCallingSystemId.trim().length() == 0) {
				stAppInfo = "callingSystemId is null or empty in input";
				hmResult = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}DB_UC_02 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			sContactType = sContactType.toUpperCase().trim();
			
			if (sMemberNum != null && !sMemberNum.isEmpty() && 
					sContactType != null && !sContactType.isEmpty()) {
				sWhereClause = " WHERE MEMBER_NUM = ? AND CONTACT_TYPE = ?";
			} /*else if (sContactId != null && !sContactId.isEmpty()) {
				sWhereClause = " WHERE CONTACT_ID = ?";
			} else if (sSubscriptionId != null && !sSubscriptionId.isEmpty()) {
				sWhereClause = " WHERE SUBSCRIPTION_ID = ?";
				alUpdateKeys.remove("subscription_id");
			}*/

			String key = null;
			String value = null;

			for (Iterator iter = hmInput.keySet().iterator(); iter.hasNext();) {
				key = (String) iter.next();
				value = (String) hmInput.get(key);

				if (key != null && alUpdateKeys.contains(key) && value != null) {
					updateContactSql.append(key.toUpperCase() + " = ? , ");
				}
			}

			if (sValidationStatusDateFlag != null) {
				if (sValidationStatusDateFlag.equals(MPSDefs.YES)) {
					updateContactSql.append("VALIDATION_STATUS_DATE" + " = SYSDATE, ");
				} else if (sValidationStatusDateFlag.equals(MPSDefs.NO)) {
					updateContactSql.append("VALIDATION_STATUS_DATE" + " = '', ");
				}
			}

			String stValidationStatus = (String) hmInput.get(MPSDefs.DB_VALIDATION_STATUS);
			if (hmInput.containsKey(MPSDefs.DB_VALIDATION_STATUS)
					&& (stValidationStatus == null || stValidationStatus.isEmpty())) {
				updateContactSql.append("VALIDATION_STATUS" + " = '', ");
			}

			if (sUpdateEstablishedDate == null || (!sUpdateEstablishedDate.equalsIgnoreCase("N"))) {
				updateContactSql.append("ESTABLISHED_DATE" + " = SYSDATE, ");
			}

			updateContactSql.append("LAST_MODIFIED_BY = ? ");
			updateContactSql.append(sWhereClause);

			logger.info("{}{}SQL999 : SQL Query = {}", sClassName, sMethodName, updateContactSql);

			int i = 0;
			for (Iterator iter = hmInput.keySet().iterator(); iter.hasNext();) {
				key = (String) iter.next();
				value = (String) hmInput.get(key);

				if (key != null && alUpdateKeys.contains(key) && value != null) {
					if (alUpperCaseKeys.contains(key)) {
						value = value.trim().toUpperCase();
					} else if (alLowerCaseKeys.contains(key)) {
						value = value.trim().toLowerCase();
					}
					objectList.add(value);
				}
			}

			objectList.add(sCallingSystemId);

			if (sMemberNum != null && !sMemberNum.isEmpty() && 
					sContactType != null && !sContactType.isEmpty()) {
				objectList.add(Long.parseLong(sMemberNum));
				objectList.add(sContactType);
			}/*else if (sContactId != null && !sContactId.isEmpty()) {
				objectList.add(sContactId);
			} else if (sSubscriptionId != null && !sSubscriptionId.isEmpty()) {
				objectList.add(sSubscriptionId);
			}*/

			int rowCount = jdbcTemplate.update(new String(updateContactSql),
					objectList.toArray(new Object[objectList.size()]));		

			logger.info("{}{}DB_UC_03 : Number of rows updated:= {}", sClassName, sMethodName, rowCount);

			if (rowCount == 0) {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
						"No Record found for given contact_id");
			} else {
				hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,
						"Number of records updated=" + rowCount);
			}

		} catch (Exception e) {
			hmResult = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}DBHLPE01 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}DBHLPE02 : Exception = {}", sClassName, sMethodName, e);
			
		} finally {
			logger.info("{}{}DBHLP999 response : {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;
	}
}
