package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TserviceroleId implements Serializable {

	private static final long serialVersionUID = 101270078243437261L;

	@Column(name = "SERVICE_ID", nullable = false, precision = 22, scale = 0)
	private Long serviceId;

	@Column(name = "ROLE_ID", nullable = false, precision = 22, scale = 0)
	private Long roleId;


	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TserviceroleId))
			return false;
		TserviceroleId castOther = (TserviceroleId) other;

		return ((this.getServiceId() == castOther.getServiceId()) || (this.getServiceId() != null
				&& castOther.getServiceId() != null && this.getServiceId().equals(castOther.getServiceId())))
				&& ((this.getRoleId() == castOther.getRoleId()) || (this.getRoleId() != null
						&& castOther.getRoleId() != null && this.getRoleId().equals(castOther.getRoleId())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getServiceId() == null ? 0 : this.getServiceId().hashCode());
		result = 37 * result + (getRoleId() == null ? 0 : this.getRoleId().hashCode());
		return result;
	}

}
