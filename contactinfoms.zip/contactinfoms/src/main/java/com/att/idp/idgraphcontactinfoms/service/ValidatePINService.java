package com.att.idp.idgraphcontactinfoms.service;

import jakarta.ws.rs.core.MultivaluedMap;

import com.att.idp.idgraphcontactinfoms.resource.request.ValidatePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.ValidatePINResponse;

/**
 * This interface is part of the com.att.idp.idgraphcontactinfoms.service package.
 *
 * The ValidatePINService interface defines a contract for a service that handles the validation of a PIN.
 * It declares a single method, validatePIN, which takes a ValidatePINRequest and a MultivaluedMap of String to String as input and returns a ValidatePINResponse.
 *
 * The validatePIN method is expected to perform the operation of validating a PIN, using the ValidatePINRequest as the request body and the MultivaluedMap as the request headers.
 */
public interface ValidatePINService {

	/**
	 * This method is part of the ValidatePINService interface in the com.att.idp.idgraphcontactinfoms.service package.
	 *
	 * The validatePIN method is used to perform the operation of validating a PIN.
	 * It takes a ValidatePINRequest object and a MultivaluedMap of String to String as input.
	 * The ValidatePINRequest object represents the request body, containing the details required for validating a PIN.
	 * The MultivaluedMap represents the request headers.
	 *
	 * The method returns a ValidatePINResponse object, which represents the response from the operation of validating a PIN.
	 */
	ValidatePINResponse validatePIN(ValidatePINRequest validatePINRequest, MultivaluedMap<String, String> requestHeader);

}