package com.att.idp.idgraphcontactinfoms.helpers;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * The CPNIDataConsolidationHelper class is a Spring component that provides methods for consolidating CPNI data.
 *
 * It uses several properties from a properties file located at "file:opt/ajsc/etc/config/contactInfo.properties".
 * These properties include "SIM_SWAP_AGING_DAYS".
 *
 * The class contains a method named generateCPNIConsolidation which takes a HashMap as input and returns a HashMap as output.
 * This method performs various checks and validations on the input data and constructs a response HashMap.
 *
 * The class uses the SLF4J Logger for logging.
 */
@Component
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class CPNIDataConsolidationHelper {

	private String sThisClass = "CPNIDataConsolidationHelper";
	public static final Logger log = LoggerFactory.getLogger(CPNIDataConsolidationHelper.class);

	@Autowired
	private CPNIDataAddressHelper helper;

	@Value("${SIM_SWAP_AGING_DAYS}")
	private String sSimSwapAgingDays;

	/**
	 * This method generates the CPNI consolidation.
	 *
	 * It takes a HashMap as input which contains the CPNI data and performs various checks and validations on the input data.
	 * The method constructs a response HashMap which contains the result of the consolidation.
	 *
	 * The method uses several properties from a properties file located at "file:opt/ajsc/etc/config/contactInfo.properties".
	 * These properties include "SIM_SWAP_AGING_DAYS".
	 *
	 * The method uses the SLF4J Logger for logging.
	 *
	 * @param hmInput a HashMap that contains the CPNI data.
	 * @return a HashMap that contains the result of the consolidation.
	 */
	public HashMap generateCPNIConsolidation(HashMap hmInput) {

		String sThisMethod = ".generateCPNIConsolidation.";

		String sAppInfo = null;
		String sAppCategoryCode = null;

		HashMap<String, Object> hmResponse = CommonUtil.getHashMap();

		ArrayList alAccountContactList = new ArrayList();
		HashMap<String, Object> hmAccountContactList = null;

		HashMap<String, Object> hmUSPhoneNumhber = null;

		//HashMap<String, Object> hmAddress = null;

		String sDslDryLoopInd = null;
		String sAccountId = null;
		String sServiceNBR = null;
		String sIgnorePostalAddressValidation = null;

		log.info("{}{}HLP000 : Input Hash : {}", sThisClass, sThisMethod,
				HtmlUtils.htmlEscape(String.valueOf(hmInput)));

		try {
			if (hmInput == null || hmInput.isEmpty()) {
				sAppInfo = " Input Hash is NULL / EMPTY ";
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				log.info("{}{}CPNIDCH_01 : {}", sThisClass, sThisMethod, sAppInfo);
				return hmResponse;
			}

			/*
			 * if AccountStatus in input is except L, I, TO or FO then return ERR_NOT_ACTIVE
			 */

			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			if (sCallingSystemId == null || sCallingSystemId.trim().length() == 0) {
				sCallingSystemId = "";
			}
			sAccountId = (String) hmInput.get(CommonDefs.KEY_ACCOUNT_ID);

			/*
			 * emailAddress processing
			 */

			ArrayList alEmailAddress = (ArrayList) hmInput.get(CommonDefs.KEY_EMAIL_ADDRESSES);
			String sNewCPNIEilibilityRule = (String) hmInput.get("NewCPNIEilibilityRule");

			if (alEmailAddress != null && !alEmailAddress.isEmpty()) {

				Iterator itEmailAddress = alEmailAddress.iterator();

				ArrayList alContactInfo = new ArrayList();
				HashMap<String, Object> hmContactInfo = null;

				while (itEmailAddress.hasNext()) {

					HashMap<String, Object> hmEmailAddress = (HashMap<String, Object>) itEmailAddress.next();
					hmContactInfo = CommonUtil.getHashMap();

					if (hmEmailAddress != null && !hmEmailAddress.isEmpty()) {

						hmContactInfo.put(MPSDefs.DB_CONTACT_TYPE, CommonDefs.CONTACT_TYPE_PRIMARY_EMAIL);
						hmContactInfo.put(MPSDefs.DB_EMAIL_ADDRESS,
								(String) hmEmailAddress.get(CommonDefs.EMAIL_ADDRESS));
						hmContactInfo.put(CommonDefs.KEY_EMAIL_EST_DATE,
								(String) hmEmailAddress.get(CommonDefs.KEY_EMAIL_ESTABLISHED_DATE));
						hmContactInfo.put(MPSDefs.DB_CONTACT_STATUS,
								(String) hmEmailAddress.get(CommonDefs.EMAIL_STATUS));
						hmContactInfo.put(CommonDefs.KEY_ACCOUNT_CREATE_DATE,
								(String) hmEmailAddress.get(CommonDefs.KEY_ACCOUNT_ESTABLISHED_DATE));

						String sCPNIEligible = (String) hmEmailAddress.get(CommonDefs.CPNI_ELIGIBLE_EMAIL_FLAG);
						if (sCPNIEligible != null && sCPNIEligible.trim().length() > 0
								&& sCPNIEligible.equals(MPSDefs.YES)) {
							hmContactInfo.put(CommonDefs.CPNI_ELIGIBLE_EMAIL_FLAG, MPSDefs.YES);
						}
						alContactInfo.add(hmContactInfo);

					}
				}

				if (!alContactInfo.isEmpty()) {

					HashMap<String, Object> hmCPNIAddressInput = new HashMap<String, Object>();

					hmCPNIAddressInput.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(CommonDefs.TRANSACTION_ID));
					hmCPNIAddressInput.put(CommonDefs.TRANSACTION_NAME,
							(String) hmInput.get(CommonDefs.TRANSACTION_NAME));
					hmCPNIAddressInput.put(CommonDefs.CALLING_SYSTEM_ID,
							(String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
					hmCPNIAddressInput.put(CommonDefs.CONTACT_INFO, alContactInfo);

					if (sNewCPNIEilibilityRule != null && !sNewCPNIEilibilityRule.isEmpty()
							&& sNewCPNIEilibilityRule.equals(MPSDefs.YES)) {
						hmCPNIAddressInput.put("NewCPNIEilibilityRule", sNewCPNIEilibilityRule);
					}

					if (hmInput.get(CommonDefs.ACTIVATED_IND) != null) {
						hmCPNIAddressInput.put(CommonDefs.ACTIVATED_IND, hmInput.get(CommonDefs.ACTIVATED_IND));
					}

					// call the CPNI Address Helper
					hmResponse = helper.validateCPNIAddress(hmCPNIAddressInput);

					if (hmResponse == null) {
						sAppInfo = "CPNI Address Helper Response  is null";
						hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
						log.info("{}{}CPNIDCH_06 : {}", sThisClass, sThisMethod, sAppInfo);
						return hmResponse;
					}

					sAppCategoryCode = (String) hmResponse.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
					if (sAppCategoryCode != null && !sAppCategoryCode.equals(CErrorDefs.COMMON_SUCCESS)) {
						sAppInfo = (String) hmResponse.get(CErrorDefs.COMMON_APP_INFO);
						log.info("{}{}CPNIDCH_07 : {}", sThisClass, sThisMethod, sAppInfo);
						return hmResponse;
					}

					ArrayList alValidCPNIAddress = (ArrayList) hmResponse.get(CommonDefs.VALID_CPNI_ADDRESSES);
					HashMap<String, Object> hmEmail = null;
					if (alValidCPNIAddress != null && !alValidCPNIAddress.isEmpty()) {

						Iterator itValidCPNIAddresses = alValidCPNIAddress.iterator();
						while (itValidCPNIAddresses.hasNext()) {

							HashMap<String, Object> hmValidCPNIAddress = (HashMap<String, Object>) itValidCPNIAddresses
									.next();
							if (hmValidCPNIAddress != null && !hmValidCPNIAddress.isEmpty()) {

								String sEmailAddress = (String) hmValidCPNIAddress.get(MPSDefs.DB_EMAIL_ADDRESS);
								String sEmailEstablishedDate = (String) hmValidCPNIAddress
										.get(CommonDefs.KEY_EMAIL_EST_DATE);
								hmEmail = CommonUtil.getHashMap();

								hmEmail.put(CommonDefs.CONTACT_EMAIL, sEmailAddress);
								HashMap<String, Object> hmGeneralContactDetails = CommonUtil.getHashMap();

								hmGeneralContactDetails.put(CommonDefs.CONTACT_TYPE,
										CommonDefs.CONTACT_TYPE_PRIMARY_EMAIL);
								hmGeneralContactDetails.put(CommonDefs.CONTACT_STATUS,
										CommonDefs.PROOFING_STATUS_VALID);
								hmGeneralContactDetails.put(CommonDefs.CPNI_ELGIBLE, CommonDefs.IND_Y);
								hmGeneralContactDetails.put(CommonDefs.ESTABLISHED_DATE, sEmailEstablishedDate);

								hmEmail.put(CommonDefs.GENERAL_CONTACT_DETAILS, hmGeneralContactDetails);

								hmAccountContactList = CommonUtil.getHashMap();
								hmAccountContactList.put(CommonDefs.KEY_EMAIL, hmEmail);

								alAccountContactList.add(hmAccountContactList);

							}
						}
					}

				}

			}

			/*
			 * DslDryLoopInd Processing
			 */

			sDslDryLoopInd = (String) hmInput.get(CommonDefs.KEY_DSL_DRY_LOOP_IND);
			sServiceNBR = (String) hmInput.get(CommonDefs.SERVICE_NBR);

			log.debug("{}{}CPNIDCH_08 : DslDryLoopInd in input:: {}", sThisClass, sThisMethod, sDslDryLoopInd);
			log.debug("{}{}CPNIDCH_09 : Service_NBR in input::{}", sThisClass, sThisMethod, sServiceNBR);
			boolean bBPHONEEntryRequired = false;

			if (sServiceNBR != null && sServiceNBR.trim().length() > 0) {
				for (int i = 0; i < sServiceNBR.trim().length(); i++) {

					char cItem = sServiceNBR.charAt(i);
					if (cItem != '0') {
						bBPHONEEntryRequired = true;
						log.debug("{}{}CPNIDCH_10 : Service_NBR does not have all the Zeros::{}", sThisClass,
								sThisMethod, sServiceNBR);
						break;
					}

				}
			} else {
				bBPHONEEntryRequired = true;
			}

			if (((sDslDryLoopInd != null && sDslDryLoopInd.trim().length() > 0 && sDslDryLoopInd.equals(MPSDefs.NO))
					|| (sDslDryLoopInd == null || sDslDryLoopInd.trim().length() == 0)) && bBPHONEEntryRequired) {

				hmUSPhoneNumhber = new HashMap<String, Object>();
				String sPhoneNumber = null;
				if (sAccountId != null && sAccountId.trim().length() > 0) {
					sPhoneNumber = sAccountId.substring(0, 10);

					hmUSPhoneNumhber.put(CommonDefs.PHONE_NUMBER, sPhoneNumber);
					hmUSPhoneNumhber.put(CommonDefs.PHONE_NUMBER_TYPE, CommonDefs.PHONE_NUMBER_TYPE_BTN);

					HashMap<String, Object> hmGeneralContactDetails = new HashMap();

					hmGeneralContactDetails.put(CommonDefs.CONTACT_TYPE, "BPHONE");
					hmGeneralContactDetails.put(CommonDefs.CONTACT_STATUS, CommonDefs.PROOFING_STATUS_VALID);
					hmGeneralContactDetails.put(CommonDefs.CPNI_ELGIBLE, CommonDefs.IND_Y);

					hmUSPhoneNumhber.put(CommonDefs.GENERAL_CONTACT_DETAILS, hmGeneralContactDetails);

					hmAccountContactList = new HashMap<String, Object>();
					hmAccountContactList.put(CommonDefs.US_PHONE_NUMBER, hmUSPhoneNumhber);

					alAccountContactList.add(hmAccountContactList);
				}

			}

			log.debug("{}{}CPNIDCH_11 : After Processing DslDryLoopInd Contact List is:: {}", sThisClass, sThisMethod,
					alAccountContactList);

			/*
			 * CTNList Processing
			 */

			ArrayList alCTNList = (ArrayList) hmInput.get(CommonDefs.KEY_CTN_LIST);
			//String sAccountType = (String) hmInput.get(CommonDefs.KEY_ACCOUNT_TYPE);
			//TODO:what happens when titan acc calls this
			String sAccountType = (String) hmInput.get(CommonDefs.ACCOUNT_TYPE);

			if (alCTNList != null && !alCTNList.isEmpty()
					&& (sAccountType == null || sAccountType.isEmpty() || !sAccountType.equals("B"))) {

				Iterator itCTNList = alCTNList.iterator();
				while (itCTNList.hasNext()) {

					HashMap<String, Object> hmCTNList = (HashMap<String, Object>) itCTNList.next();
					if (hmCTNList != null && !hmCTNList.isEmpty()) {

						boolean bCTNAged = true;

						log.debug("{}{}CPNIDCH_12 : Processing each CTN :: {}", sThisClass, sThisMethod,
								HtmlUtils.htmlEscape(String.valueOf(hmCTNList)));
						String sCTN = (String) hmCTNList.get(CommonDefs.CTN);
						String sCTNStatus = (String) hmCTNList.get(CommonDefs.STATUS);

						// 1510: US195229 Check SIM SWAP DATE
						String sSimSwapDate = (String) hmCTNList.get(CommonDefs.SIM_SWAP_DATE);

						log.info("{}{}CPNIDCH_12a : SIM_SWAP_AGING_DAYS : {}", sThisClass, sThisMethod,
								sSimSwapAgingDays);

						if (sSimSwapAgingDays == null || sSimSwapAgingDays.isEmpty()) {
							sSimSwapAgingDays = "2"; // If config is missing, default to 2 days
						}
						String stCreatedOn = (String) hmInput.get(CommonDefs.CUSTOMER_ACTIVE_DATE);
						boolean isAccountCreatedOnSimSwapDate = false;
						if (sSimSwapDate != null && !sSimSwapDate.isEmpty()) {
							String dateTimeFormat = "MMddyyyy HH:mm:ss";
							bCTNAged = CommonUtilHelper.checkAging(sSimSwapDate, sSimSwapAgingDays, dateTimeFormat);
							log.info("{}{}CPNIDCH_13 : CTN Aged:: {}", sThisClass, sThisMethod, bCTNAged);
							if (stCreatedOn != null && !stCreatedOn.isEmpty()) {
								LocalDate createdOn = CommonUtilHelper.extractDate(stCreatedOn,dateTimeFormat);
								LocalDate simSwapDate = CommonUtilHelper.extractDate(sSimSwapDate,dateTimeFormat);
								if(createdOn.isEqual(simSwapDate)){
									isAccountCreatedOnSimSwapDate = true;
									log.info("{}{}CPNIDCH_13b : Account Created On is same as SIM SWAP DATE", sThisClass, sThisMethod);
								}
							}
						}

						if (sCTNStatus != null && !sCTNStatus.isEmpty()
								&& sCTNStatus.equalsIgnoreCase(CommonDefs.ACTIVE) && (bCTNAged || isAccountCreatedOnSimSwapDate)) {
							hmUSPhoneNumhber = CommonUtil.getHashMap();

							hmUSPhoneNumhber.put(CommonDefs.PHONE_NUMBER, sCTN);
							hmUSPhoneNumhber.put(CommonDefs.PHONE_NUMBER_TYPE, CommonDefs.PHONE_NUMBER_TYPE_ATTMOBILE);

							HashMap hmGeneralContactDetails = CommonUtil.getHashMap();

							// 1510: Updated contactType from BPHONE to SMS as confirmed by Amy
							// Reverted because of MyATT issue
							hmGeneralContactDetails.put(CommonDefs.CONTACT_TYPE, CommonDefs.CC_MULE_SMS);
							hmGeneralContactDetails.put(CommonDefs.CONTACT_STATUS, CommonDefs.PROOFING_STATUS_VALID);
							hmGeneralContactDetails.put(CommonDefs.CPNI_ELGIBLE, CommonDefs.IND_Y);

							hmUSPhoneNumhber.put(CommonDefs.GENERAL_CONTACT_DETAILS, hmGeneralContactDetails);

							hmAccountContactList = CommonUtil.getHashMap();
							hmAccountContactList.put(CommonDefs.US_PHONE_NUMBER, hmUSPhoneNumhber);

							alAccountContactList.add(hmAccountContactList);
						}
					}
				}
			}

			log.debug("{}{}CPNIDCH_14 : After Processing USPhoneNumber Contact List is:: {}", sThisClass, sThisMethod,
					alAccountContactList);

			/*
			 * Postal Address Processing
			 */

			ArrayList alPostalAddress = (ArrayList) hmInput.get(CommonDefs.POSTAL_ADDRESS);
			sIgnorePostalAddressValidation = (String) hmInput.get(CommonDefs.KEY_IGNORE_POSTAL_ADDRESS_VALIDATION);
			log.debug("{}{}CPNIDCH_15 : PostalAddress in input:: {}", sThisClass, sThisMethod,
					HtmlUtils.htmlEscape(String.valueOf(alPostalAddress)));

			if (alPostalAddress != null && !alPostalAddress.isEmpty()) {
				ArrayList alValidCPNIAddress = new ArrayList();
				if (sIgnorePostalAddressValidation != null && !sIgnorePostalAddressValidation.isEmpty()
						&& sIgnorePostalAddressValidation.equals(MPSDefs.YES)) {
					alValidCPNIAddress.addAll(alPostalAddress);
					log.info("{}{}CPNIDCH_16 : Postal Address Validation is not required for ECOMM/UVERSE Accounts",
							sThisClass, sThisMethod);
				} else {
					HashMap<String, Object> hmCPNIAddressInput = new HashMap<String, Object>();

					hmCPNIAddressInput.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(CommonDefs.TRANSACTION_ID));
					hmCPNIAddressInput.put(CommonDefs.TRANSACTION_NAME,
							(String) hmInput.get(CommonDefs.TRANSACTION_NAME));
					hmCPNIAddressInput.put(CommonDefs.CALLING_SYSTEM_ID,
							(String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
					hmCPNIAddressInput.put(CommonDefs.POSTAL_ADDRESS, alPostalAddress);
					if (sNewCPNIEilibilityRule != null && !sNewCPNIEilibilityRule.isEmpty()
							&& sNewCPNIEilibilityRule.equals(MPSDefs.YES)) {
						hmCPNIAddressInput.put("NewCPNIEilibilityRule", sNewCPNIEilibilityRule);
					}
					log.debug("{}{}CPNIDCH_17 : Calling CPNI Address Helper with input {}", sThisClass, sThisMethod,
							hmCPNIAddressInput);

					// call the CPNI Address Helper
					// hmResponse = this.dummyResponse();
					hmResponse = helper.validateCPNIAddress(hmCPNIAddressInput);
					if (hmResponse == null) {
						sAppInfo = "CPNI Address Helper Response  is null";
						hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
						log.info("{}{}CPNIDCH_18 : {}", sThisClass, sThisMethod, sAppInfo);
						return hmResponse;
					}
					log.debug("{}{}CPNIDCH_19 : Response from CPNI Address Helper:: {}", sThisClass, sThisMethod,
							hmResponse);
					sAppCategoryCode = (String) hmResponse.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
					if (sAppCategoryCode != null && !sAppCategoryCode.equals(CErrorDefs.COMMON_SUCCESS)) {
						sAppInfo = (String) hmResponse.get(CErrorDefs.COMMON_APP_INFO);
						log.info("{}{}CPNIDCH_20 : {}", sThisClass, sThisMethod, sAppInfo);
						return hmResponse;
					}
					alValidCPNIAddress = (ArrayList) hmResponse.get(CommonDefs.VALID_CPNI_ADDRESSES);
				}

				if (alValidCPNIAddress != null && !alValidCPNIAddress.isEmpty()) {
					Iterator itPostalAddress = alValidCPNIAddress.iterator();
					String sProbationaryAddressInd = (String) hmInput.get(CommonDefs.KEY_PROBATIONARY_ADDRESS_IND);
					String sForeignAddrInd = null;
					String sZipCode = null;
					while (itPostalAddress.hasNext()) {
						sZipCode = null;
						sForeignAddrInd = null;
						HashMap hmPostalAddress = (HashMap) itPostalAddress.next();

						if (hmPostalAddress != null && !hmPostalAddress.isEmpty()) {

							/*
							 * Updated for JUNE-2011 Release SID: 17074 If ForeignAddrInd is Y or ZipCode is
							 * null/empty then do not return PostalAddress in response.
							 */
							sForeignAddrInd = (String) hmPostalAddress.get(CommonDefs.KEY_FOREIGN_ADDR_IND);
							sZipCode = (String) hmPostalAddress.get(CommonDefs.KEY_ZIPCODE);

							if ((sForeignAddrInd == null || sForeignAddrInd.trim().length() == 0
									|| (MPSDefs.NO.equals(sForeignAddrInd)))
									&& (sZipCode != null && sZipCode.trim().length() > 0)) {

								HashMap<String, Object> hmAddress = CommonUtil.getHashMap();

								if (sProbationaryAddressInd != null && !sProbationaryAddressInd.isEmpty()) {
									if (sProbationaryAddressInd.equals(MPSDefs.YES)) {
										hmAddress.put(CommonDefs.PROBATIONARY_ADDRESS_EXISTS, MPSDefs.YES);
									} else if (sProbationaryAddressInd.equals(MPSDefs.NO)) {
										hmAddress.put(CommonDefs.PROBATIONARY_ADDRESS_EXISTS, MPSDefs.NO);
									}
								} // Updated as a part of Defect #319 for APRIL 2012

								hmAddress.put(CommonDefs.NAME, (String) hmPostalAddress.get(CommonDefs.KEY_BILLNAME));
								hmAddress.put(CommonDefs.STREET1,
										(String) hmPostalAddress.get(CommonDefs.KEY_ADDRESS2));
								hmAddress.put(CommonDefs.STREET2,
										(String) hmPostalAddress.get(CommonDefs.KEY_ADDRESS3));

								Optional.ofNullable(hmPostalAddress.get(CommonDefs.STREET1)).ifPresent(x->hmAddress.put(CommonDefs.STREET1,x));
								
								String sAddress4 = (String) hmPostalAddress.get(CommonDefs.KEY_ADDRESS4);
								if (sAddress4 != null && !sAddress4.isEmpty()) {
									hmAddress.put(CommonDefs.STREET3, sAddress4);
								}

								String sPostOffice = (String) hmPostalAddress.get(CommonDefs.KEY_POSTOFFICE);
								if (sPostOffice != null && !sPostOffice.isEmpty()) {
									hmAddress.put(CommonDefs.POST_OFFICE, sPostOffice);
								}

								String sNBRNonAddresLines = (String) hmPostalAddress
										.get(CommonDefs.KEY_NBR_NON_ADDRESS_LINES);
								if (sNBRNonAddresLines != null && !sNBRNonAddresLines.isEmpty()) {
									hmAddress.put(CommonDefs.NBR_NON_ADDRESS_LINES, sNBRNonAddresLines);
								}

								hmAddress.put(CommonDefs.FOREIGN_ADDR_IND,
										(String) hmPostalAddress.get(CommonDefs.KEY_FOREIGN_ADDR_IND));
								hmAddress.put(CommonDefs.CITY, (String) hmPostalAddress.get(CommonDefs.KEY_CITY));
								hmAddress.put(CommonDefs.ZIP_CODE,
										(String) hmPostalAddress.get(CommonDefs.KEY_ZIPCODE));
								hmAddress.put(CommonDefs.ZIP_PLUS_FOUR,
										(String) hmPostalAddress.get(CommonDefs.KEY_ZIPPLUSFOUR));
								hmAddress.put(CommonDefs.STATE, (String) hmPostalAddress.get(CommonDefs.KEY_STATE));
								hmAddress.put(CommonDefs.COUNTRY, (String) hmPostalAddress.get(CommonDefs.KEY_COUNTRY));

								HashMap<String, Object> hmGeneralContactDetails = CommonUtil.getHashMap();

								hmGeneralContactDetails.put(CommonDefs.CONTACT_TYPE, "BILLING");
								hmGeneralContactDetails.put(CommonDefs.CONTACT_STATUS,
										CommonDefs.PROOFING_STATUS_VALID);
								hmGeneralContactDetails.put(CommonDefs.CPNI_ELGIBLE, CommonDefs.IND_Y);

								hmAddress.put(CommonDefs.GENERAL_CONTACT_DETAILS, hmGeneralContactDetails);

								hmAccountContactList = CommonUtil.getHashMap();
								hmAccountContactList.put(CommonDefs.KEY_POSTAL_ADDRESS, hmAddress);
								alAccountContactList.add(hmAccountContactList);
							}
						}
					}

					log.debug("{}{}CPNIDCH_21 : After Processing Postal Address Contact List is:: {}", sThisClass,
							sThisMethod, alAccountContactList);

				}

			}
			// LSCRM cbrctnlist
			ArrayList alCBRCTNList = (ArrayList) hmInput.get("CBRCTNList");
			if (alCBRCTNList != null && !alCBRCTNList.isEmpty()) {
				HashMap<String, Object> hmCPNIAddressInput = new HashMap<String, Object>();

				hmCPNIAddressInput.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(CommonDefs.TRANSACTION_ID));
				hmCPNIAddressInput.put(CommonDefs.TRANSACTION_NAME, (String) hmInput.get(CommonDefs.TRANSACTION_NAME));
				hmCPNIAddressInput.put(CommonDefs.CALLING_SYSTEM_ID,
						(String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
				hmCPNIAddressInput.put(CommonDefs.CONTACT_INFO, (ArrayList) hmInput.get("CBRCTNList"));

				if (sNewCPNIEilibilityRule != null && !sNewCPNIEilibilityRule.isEmpty()
						&& sNewCPNIEilibilityRule.equals(MPSDefs.YES)) {
					hmCPNIAddressInput.put("NewCPNIEilibilityRule", sNewCPNIEilibilityRule);
				}

				if (hmInput.get(CommonDefs.ACTIVATED_IND) != null) {
					hmCPNIAddressInput.put(CommonDefs.ACTIVATED_IND, hmInput.get(CommonDefs.ACTIVATED_IND));
				}

				// call the CPNI Address Helper
				// hmResponse = this.dummyResponse();
				hmResponse = helper.validateCPNIAddress(hmCPNIAddressInput);

				if (hmResponse == null) {
					sAppInfo = "CPNI Address Helper Response  is null";
					hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
					log.info("{}{}CPNIDCH_06 : {}", sThisClass, sThisMethod, sAppInfo);
					return hmResponse;
				}

				sAppCategoryCode = (String) hmResponse.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
				if (sAppCategoryCode != null && !sAppCategoryCode.equals(CErrorDefs.COMMON_SUCCESS)) {
					sAppInfo = (String) hmResponse.get(CErrorDefs.COMMON_APP_INFO);
					log.info("{}{}CPNIDCH_07 : {}", sThisClass, sThisMethod, sAppInfo);
					return hmResponse;
				}

				ArrayList alValidCPNIAddress = (ArrayList) hmResponse.get(CommonDefs.VALID_CPNI_ADDRESSES);

				if (alValidCPNIAddress != null && !alValidCPNIAddress.isEmpty()) {

					Iterator itValidCPNIAddresses = alValidCPNIAddress.iterator();
					while (itValidCPNIAddresses.hasNext()) {

						HashMap<String, Object> hmValidCPNIAddress = (HashMap<String, Object>) itValidCPNIAddresses
								.next();
						HashMap<String, Object> hmUSPhone = CommonUtil.getHashMap();

						hmUSPhone.put(CommonDefs.PHONE_NUMBER, hmValidCPNIAddress.get(CommonDefs.KEY_PHONE));
						hmUSPhone.put(CommonDefs.PHONE_NUMBER_TYPE,
								hmValidCPNIAddress.get(CommonDefs.PHONE_NUMBER_TYPE));

						HashMap<String, Object> hmGeneralContactDetails = CommonUtil.getHashMap();

						hmGeneralContactDetails.put(CommonDefs.CONTACT_TYPE,
								hmValidCPNIAddress.get(CommonDefs.KEY_CONTACT_TYPE));
						hmGeneralContactDetails.put(CommonDefs.CONTACT_STATUS,
								hmValidCPNIAddress.get(CommonDefs.KEY_CONTACT_STATUS));
						hmGeneralContactDetails.put(CommonDefs.CPNI_ELGIBLE, CommonDefs.IND_Y);

						hmUSPhone.put(CommonDefs.GENERAL_CONTACT_DETAILS, hmGeneralContactDetails);

						HashMap<String, Object> hmPhoneList = CommonUtil.getHashMap();
						hmPhoneList.put(CommonDefs.US_PHONE_NUMBER, hmUSPhone);

						alAccountContactList.add(hmPhoneList);
					}
				}
			}

			hmResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

			if (alAccountContactList != null) {

				hmResponse.put(CommonDefs.ACCOUNT_CONTACT_LIST, alAccountContactList);
			}

		} catch (Exception e) {
			hmResponse = CommonErrorMap.makeExceptionMap(e, log);

		} finally {
			if (hmResponse == null || hmResponse.isEmpty()) {
				sAppInfo = " Result Hash is NULL ";
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				log.debug("{}{}CPNIDCH_22 : {}", sThisClass, sThisMethod, sAppInfo);
			}

			log.info("{}{}HLP999 : response from CPNIDataConsolidationHelper : {}", sThisClass, sThisMethod,
					hmResponse);

		}

		return hmResponse;
	}

}
