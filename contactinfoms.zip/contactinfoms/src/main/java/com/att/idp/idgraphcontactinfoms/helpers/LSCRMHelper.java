package com.att.idp.idgraphcontactinfoms.helpers;

import com.att.mpsys.common.utils.CommonDefs;
import com.sbc.cc.clarify.api.mps.message.GetAuthInfoRequest;


import com.sbc.cc.clarify.api.mps.message.ObjectFactory;
import com.sbc.cc.clarify.api.mps.types.RequestHeaderType;
import com.sbc.cc.clarify.api.mps.types.UserType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import java.util.HashMap;

@Component
public class LSCRMHelper {


    @Value("${lscrm.authinfo.loginname}")
    public String lscrmLoginName;

    @Value("${lscrm.authinfo.applicationid}")
    public String lscrmApplicationId;



    public static final Logger log = LoggerFactory.getLogger(LSCRMHelper.class);
    private final String sClassName = "LSCRMHelper";

    public GetAuthInfoRequest buildGetAuthInfoRequest(HashMap<String, Object> hmInput ) {

        GetAuthInfoRequest authInfoRequest= new GetAuthInfoRequest();
        String sMethodName = ".buildGetAuthInfoRequest.";
        log.info("{}{}LSH_01: preparing LSCRM GetAuthInfoRequest with input : {} ", sClassName, sMethodName, hmInput);
        RequestHeaderType requestHeader = new RequestHeaderType();
        UserType userType = new UserType();
        userType.setLoginName(lscrmLoginName);
        userType.setPassword(lscrmLoginName);
        userType.setChannel((String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
        requestHeader.setSbcuid(lscrmLoginName);
        requestHeader.setClarifyUser(userType);
        requestHeader.setApplicationID(lscrmApplicationId);
        authInfoRequest.setRequestHeader(requestHeader);
        authInfoRequest.setBan((String) hmInput.get(CommonDefs.BAN));
        log.info("{}{}LSH_02: LSCRM GetAuthInfoRequest : {} ", sClassName, sMethodName, authInfoRequest);
        return authInfoRequest;
    }
}
