package com.att.idp.idgraphcontactinfoms.helpers;

import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphcontactinfoms.db.helper.InquireUserContactInfoDBHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;

/**
 * This class is a helper class for inquiring user contact information.
 *
 * It contains methods for inquiring user contact information based on the input parameters.
 * The class uses the Spring Framework's @Component annotation to indicate that it is a bean and can be used for dependency injection.
 *
 * The class has an instance variable inquireUserContactInfoDBHelper that is injected using the @Autowired annotation.
 * This variable is used to interact with the database to inquire user contact information.
 *
 * The main method in this class is the inquireUserContactInfo method, which takes a HashMap as input and returns a HashMap as output.
 * The inquireUserContactInfo method uses several other methods in the class to validate the input data, process the input data, and store the data.
 *
 * The class also contains a logger for logging information and error messages.
 */
@Component
public class InquireUserContactInfoHelper {

	@Autowired
	private InquireUserContactInfoDBHelper inquireUserContactInfoDBHelper;

	private static String sThisClass = "InquireUserContactInfoHelper";
	private static final Logger logger = LoggerFactory.getLogger(InquireUserContactInfoHelper.class);

	/**
	 * This method inquires user contact information based on the input parameters.
	 *
	 * It first retrieves the transaction ID, transaction name, GUID, and calling system ID from the input HashMap.
	 * Then, it validates the input data. If the input data is invalid, the method constructs an error response and returns it.
	 * If the input data is valid, the method processes the input data and makes a call to the InquireUserContactInfoDBHelper to inquire user contact information.
	 * The method then checks the response from the InquireUserContactInfoDBHelper. If the response indicates an error, the method constructs an error response and returns it.
	 * If the response from the InquireUserContactInfoDBHelper indicates success, the method constructs a success response and returns it.
	 *
	 * @param hmInput a HashMap that contains the input data for the user contact information inquiry. The HashMap should include the transaction ID, transaction name, GUID, and calling system ID.
	 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code, an application info message, and the user contact information.
	 * @throws Exception if an error occurs during the operation.
	 */
	public HashMap inquireUserContactInfo(HashMap hmInput) {
		HashMap<String, Object> hmResult = null;
		String sAppInfo = null;
		String sThisMethod = ".inquireUserContactInfo.";

		logger.info("{}{}HLP000 : Input Hash : {}", sThisClass, sThisMethod, HtmlUtils.htmlEscape(String.valueOf(hmInput)));

		try {
			if (hmInput == null || hmInput.isEmpty()) {
				sAppInfo = "Input Hash is NULL or EMPTY";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
				logger.info("{}{}ICEH_01 : {}", sThisClass, sThisMethod, sAppInfo);
				return hmResult;
			}
			String sTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);
			String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
			String sGuid = (String) hmInput.get(CommonDefs.GUID);
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

			if (sCallingSystemId != null && !sCallingSystemId.isEmpty()) {
				sCallingSystemId = sCallingSystemId.toUpperCase();
			} else {
				sCallingSystemId = "";
			}

			if (sTransactionId == null || sTransactionId.isEmpty()) {
				sAppInfo = "transactionId must be present";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
				logger.info("{}{}ICEH_02 : {}", sThisClass, sThisMethod, sAppInfo);
				return hmResult;
			}
			if (sTransactionName == null || sTransactionName.isEmpty()
					|| !sTransactionName.equals("InquireUserContactInfo")) {
				sAppInfo = "transactionName should be InquireUserContactInfo";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
				logger.info("{}{}ICEH_03 : {}", sThisClass, sThisMethod, sAppInfo);
				return hmResult;
			}
			if (sGuid == null || sGuid.isEmpty()) {
				sAppInfo = "guid must be present";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
				logger.info("{}{}ICEH_04 : {}", sThisClass, sThisMethod, sAppInfo);
				return hmResult;
			}

			logger.debug("{}{}ICEH_05 : Calling InquireUserContactInfoDBHelper.inquireUserContactInfo() with input: {}",
					sThisClass, sThisMethod, HtmlUtils.htmlEscape(String.valueOf(sGuid)));
			hmResult = inquireUserContactInfoDBHelper.inquireUserContactInfo(sGuid);
			logger.debug("{}{}ICEH_06 : Response from InquireUserContactInfoDBHelper.inquireUserContactInfo() is: {}",
					sThisClass, sThisMethod, hmResult);

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e);

		} finally {
			if (hmResult == null || hmResult.isEmpty()) {
				sAppInfo = "Result Hash is NULL ";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				logger.info("{}{}ICEH_ : {}", sThisClass, sThisMethod, sAppInfo);
			}
			logger.info("{}{}HLP999 : Response from InquireContactInfoHelper : {}", sThisClass, sThisMethod, HtmlUtils.htmlEscape(String.valueOf(hmResult)));
		}

		return hmResult;

	}
}
