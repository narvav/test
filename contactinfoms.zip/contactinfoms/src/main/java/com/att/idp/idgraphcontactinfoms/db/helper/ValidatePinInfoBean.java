package com.att.idp.idgraphcontactinfoms.db.helper;

import java.util.Date;

import lombok.Data;

/**
 * This class represents a bean for ValidatePinInfo.
 * It contains fields for status, failure reason, creation date, channel, session ID, account type, authentication method, and account number.
 * The class uses the @Data annotation from the Lombok library, which automatically generates getters, setters, equals, hashCode, and toString methods.
 * The toString method is overridden to provide a custom string representation of the object.
 */
@Data
public class ValidatePinInfoBean {

	private String status;
	private String failureReason;
	private Date createDate;
	private String channel ;
	private String sessionId ;
	private String accountType;
	private String authenticationMethod;
	private String accountNumber;
	private String emailAddress;
	private String phoneNumber;
	
	@Override
	public String toString() {
		return "ValidatePinInfoBean [status=" + status + ", failureReason=" + failureReason + ", createDate="
				+ createDate + ", channel=" + channel + ", sessionId=" + sessionId + ", accountType=" + accountType
				+ ", authenticationMethod=" + authenticationMethod + ", accountNumber=" + accountNumber + ",emailAddress="+ emailAddress+", phoneNumber="+ phoneNumber+"]";
	}
}