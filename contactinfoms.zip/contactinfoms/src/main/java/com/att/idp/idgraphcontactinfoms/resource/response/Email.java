package com.att.idp.idgraphcontactinfoms.resource.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.response package.
 *
 * The Email class is used to represent an email contact associated with an account.
 * It contains two fields: contactEmail and generalContactDetails.
 *
 * The contactEmail field is a string that represents the email address of the contact.
 * The generalContactDetails field is an object of the GeneralContactDetails class, representing general contact details associated with the email.
 *
 * Each field has a corresponding getter and setter method, allowing the fields to be accessed and modified.
 * The setter method for generalContactDetails is annotated with @JsonProperty, indicating the JSON property name to be used during serialization and deserialization.
 *
 * The class overrides the toString method, providing a custom string representation of the object.
 */
@Data
public class Email {

	private String contactEmail;

	private GeneralContactDetails generalContactDetails;

	@JsonProperty("GeneralContactDetails")
	public void setGeneralContactDetails(GeneralContactDetails generalContactDetails) {
		this.generalContactDetails = generalContactDetails;
	}
}