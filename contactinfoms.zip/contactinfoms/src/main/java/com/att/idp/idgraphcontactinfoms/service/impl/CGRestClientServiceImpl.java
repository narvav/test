package com.att.idp.idgraphcontactinfoms.service.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.att.idp.idgraphcontactinfoms.utils.ProfileOrchestrationConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.att.idp.cgclienthelpers.integration.CGRestClient;
import com.att.idp.idgraphcontactinfoms.service.CGRestClientService;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This class implements the CGRestClientService interface and is responsible for handling operations related to CGRestClient.
 *
 * It is annotated with @Service, indicating that it's a Spring Service.
 * The class has a dependency on CGRestClient, which is autowired.
 * It also has a Logger instance for logging.
 *
 * The class has one main method: cgRestClient.
 * This method takes a Map<String, Object> as an input parameter and returns a Map<String, Object>.
 * The method is responsible for making a synchronous call to the CGRestClient and handling the response.
 *
 * The class also has a String field cgEndpoint, which is the endpoint for the CGRestClient and is injected via @Value annotation.
 */
@Service
public class CGRestClientServiceImpl implements CGRestClientService {
	
	private static final Logger logger = LoggerFactory.getLogger(CGRestClientServiceImpl.class);
	
	@Value("${apiclient.rest.cg.endpoint}")
	private String cgEndpoint;
	
	@Autowired
	private CGRestClient cgRestClient;
	
	private static String sClassName = "CGRestClientServiceImpl";
	
	@Override
	public Map<String, Object> cgRestClient(Map<String, Object> hmNotification) throws IOException {
		String sMethodName = ".cgRestClient.";
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmNotification.put(ProfileOrchestrationConstants.API_NAME, ProfileOrchestrationConstants.CG_CUSTOMER_SEARCH);
		hmNotification.put(ProfileOrchestrationConstants.CG_END_POINT,cgEndpoint);
		hmResponse = cgRestClient.getCGSyncCall((HashMap<String, Object>) hmNotification);
		logger.info("{}{}CGS_02 : Response from CGRestClient : {}", sClassName, sMethodName, hmResponse);

		if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
			hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from cgRestClient call");
			logger.info("{}{}CGS_03 : Null response from cgRestClient call", sClassName, sMethodName);
		} else {
			String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (stAppStatusCode == null) {
				hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from cgRestClient call");
				logger.info("{}{}CGS_04 : Null response from cgRestClient", sClassName, sMethodName);
			}
		}
		hmResponse.put("idp-trace-id", hmNotification.get("idp-trace-id"));
		return hmResponse;
	}
}
