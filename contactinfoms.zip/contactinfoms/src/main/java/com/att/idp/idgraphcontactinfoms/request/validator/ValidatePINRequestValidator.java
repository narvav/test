package com.att.idp.idgraphcontactinfoms.request.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.att.idp.idgraphcontactinfoms.utils.Constants;
import jakarta.ws.rs.core.HttpHeaders;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphcontactinfoms.resource.request.ValidatePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.ValidatePINResponse;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.idp.idgraphcontactinfoms.utils.ProfileOrchestrationConstants;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;

/**
 * This class is responsible for validating the ValidatePINRequest.
 *
 * It uses the Spring Framework's @Component, @Configuration and @PropertySource annotations to indicate that it is a source of bean definitions and to load properties from a specified location.
 *
 * The class has several instance variables that are injected using the @Value annotation.
 * These variables are used to store configuration values such as the valid PIN CSI, delivery methods, agent CSI, and unlock period hours.
 *
 * The main method in this class is the validatePINRequestValidator method, which takes HttpHeaders and a ValidatePINRequest as input and returns a ValidatePINResponse.
 * The validatePINRequestValidator method performs various checks on the input parameters and calls other private methods for further validation.
 *
 * The class also contains several private methods for validating the input parameters and constructing an error response.
 *
 * The class also contains a logger for logging information and error messages.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")

public class ValidatePINRequestValidator {
	
	private static final Logger logger = LoggerFactory.getLogger(ValidatePINRequestValidator.class);

	private String sClassName = "ValidatePINRequestValidator";
	
	@Value("${PROP_PIN_CSI}")
	private String propValidPINCSI;

	@Value("${PROP_PIN_DELIVERY_METHODS}")
	private String propDeliveryMethods;
	
	@Value("${PROP_PIN_AGENT_CSI}")
	private String propValidAgentCSI;
	/**
	 * This method is responsible for validating the ValidatePINRequest.
	 *
	 * It takes HttpHeaders and a ValidatePINRequest as input parameters and returns a ValidatePINResponse.
	 * The method performs various checks on the input parameters and calls other private methods for further validation.
	 * If the validation is successful, the method returns a ValidatePINResponse. If the validation fails, the method constructs an error response and returns it.
	 *
	 * The method also handles exceptions that can occur during the validation process.
	 *
	 * @param requestHeader HttpHeaders that contains the request headers. These headers are used for logging and tracing purposes.
	 * @param validatePINRequest ValidatePINRequest that contains the request data for the validate PIN operation. This data is validated by the method.
	 * @return a ValidatePINResponse that contains the result of the validation. If the validation is successful, the response contains a success message. If the validation fails, the response contains an error message.
	 */
public ValidatePINResponse validatePINRequestValidator(HttpHeaders requestHeader, ValidatePINRequest validatePINRequest) {
		
	ValidatePINResponse validatePINResponse = null;

		String stAppInfo = null;
		String sMethodName = ".validatePINRequestValidator.";
		String stIdpTraceId = null;
		String stTransactionId = null;
		String stXAttClientId = null;
		String stSessionId = null;
		
		stIdpTraceId = CommonUtil.getTraceId(requestHeader);
				
		if(stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
			stAppInfo="ValidatePIN Request idp-trace-id is missing";
			return validatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		
		if (validatePINRequest == null) {
			stAppInfo = "Input Request is NULL / Empty.";
			logger.info("{}{}VPRV_101 :: {}", sClassName, sMethodName, stAppInfo);
			return validatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		validatePINRequest.setIdpTraceId(stIdpTraceId);
		Optional.ofNullable(requestHeader.getHeaderString("idpauthctx-sessionid")).ifPresent(x -> validatePINRequest.setIdpSessionId(x.trim()));
		
		String stCallingSystemId = validatePINRequest.getCallingSystemId();
		Optional.ofNullable(stCallingSystemId)
				.ifPresent(x -> validatePINRequest.setCallingSystemId(x.trim().toUpperCase()));
		Optional.ofNullable(validatePINRequest.getAccountType()).ifPresent(x -> validatePINRequest.setAccountType(x.trim().toUpperCase()));
		
		
		if (stCallingSystemId == null && requestHeader.getHeaderString("X-ATT-ClientId") != null) {
			if (requestHeader.getHeaderString("X-ATT-ClientId").equalsIgnoreCase("idpgwbiz")
					&& StringUtils.isNotBlank(requestHeader.getHeaderString("idpctx-appname"))) {
				stXAttClientId = requestHeader.getHeaderString("idpctx-appname").toUpperCase();
			} else {
				stXAttClientId = requestHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
			}
			logger.info("{}{}VPRV_102: callingSystemId: {}", sClassName, sMethodName,stXAttClientId);
			validatePINRequest.setCallingSystemId(stXAttClientId);
		}

        if (stCallingSystemId != null
            && Constants.CLIENT_ID_CSIGATEWAY.equalsIgnoreCase(stCallingSystemId)
            && Constants.IDENTIFICATION_TYPE_BANPC.equalsIgnoreCase(validatePINRequest.getIdentificationType())) {
            validatePINRequest.setIdentificationType(Constants.IDENTIFICATION_TYPE_NTRETAILER);
        }

		// checking Invalid attributes passed in Request
			Map<String, Object> allUnknownAttributes = new HashMap<>(validatePINRequest.unknownAttributes);

			if (!allUnknownAttributes.isEmpty()) {
				stAppInfo = "Invalid Attributes passed in ValidatePINRequest : " + allUnknownAttributes;
				return validatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						validatePINRequest.getIdpTraceId());
			}
		try {

			validatePINResponse = validatePINRequestValidatorInputValidator(validatePINRequest);

			if (validatePINResponse != null) {
				logger.info("{}{}VPRV_103 Response from ValidatePINRequestValidator : {}", sClassName, sMethodName,
						validatePINResponse);
				return validatePINResponse;
			} else {
				logger.info("{}{}VPRV_104 Success Response from ValidatePINRequestValidator ", sClassName, sMethodName);
			}

			validatePINResponse = validatePINRequestCSIValidator(validatePINRequest);

			if (validatePINResponse != null) {
				logger.info("{}{}VPRV_105 Response from ValidatePINRequestCSIValidator : {}", sClassName, sMethodName,
						validatePINResponse);
				return validatePINResponse;
			} else {
				logger.info("{}{}VPRV_106 Success Response from ValidatePINRequestCSIValidator ", sClassName,
						sMethodName);
			}
			stAppInfo = "Input Validation Successful";
			logger.info("{}{}VPRV_107 : {}", sClassName, sMethodName, stAppInfo);
		} catch (Exception e) {
			stAppInfo = "Exception thrown in ValidatePINRequestValidator.validatePINRequestValidator : " + e.getMessage();
			validatePINErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo, stIdpTraceId);
			logger.info("{}{}VPRV_108 : Exception in ValidatePINRequestValidator: {}",  sClassName, sMethodName, stAppInfo);
		}
		return validatePINResponse;

}

private ValidatePINResponse validatePINRequestCSIValidator(ValidatePINRequest validatePINRequest) {
	ValidatePINResponse validatePINResponse=null;
	String stAppInfo = null;
	String sMethodName = ".validatePINRequestCSIValidator.";
	String stCallingSystemID = validatePINRequest.getCallingSystemId();
	String stIdentificationType = validatePINRequest.getIdentificationType();
//	String stTransactionId = validatePINRequest.getTransactionId();
	String stIdpTraceId = validatePINRequest.getIdpTraceId();
	String stAgentID = validatePINRequest.getAgentId();

	logger.info("{}{}VPRV_104.1 : Property PROP_PIN_CSI ::  {}", sClassName, sMethodName, propValidPINCSI);
	
	//commented as unreachable
	/*if (propValidPINCSI == null || propValidPINCSI.isEmpty()) {

		stAppInfo = "PROP_PIN_CSI  property is not configured in the properties file";

		return validatePINErrorResponse(CErrorDefs.ERR_CONFIG_NUM, stAppInfo, stIdpTraceId);
	} */

	HashMap hmValidPINCSI = CommonUtil.parseMultiDelimiterProperty(propValidPINCSI);

	if (hmValidPINCSI != null && hmValidPINCSI.containsKey(stIdentificationType)) {
		ArrayList alValidCallers = (ArrayList) hmValidPINCSI.get(stIdentificationType);
		if (!alValidCallers.contains(stCallingSystemID)) {
		stAppInfo = stIdentificationType + " is not valid for :" + stCallingSystemID;

		return validatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
	}
		else {
			stAppInfo = stIdentificationType + " is not valid";
			return validatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
	
	
	logger.info("{}{}VPRV_104.2 : Property PROP_PIN_AGENT_CSI ::  {}", sClassName, sMethodName, propValidAgentCSI);
	
	ArrayList alValidAgentCSI= CommonUtil.parseToArray(propValidAgentCSI, CommonDefs.VALUE_SEPARATOR_CHAR);

	if(alValidAgentCSI != null && alValidAgentCSI.contains(stCallingSystemID)) {
		if (stAgentID == null || stAgentID.isEmpty()) {
			stAppInfo = "AgentId is required";
			logger.info("{}{}VPRV_104.3 : {}", sClassName, sMethodName, stAppInfo);
			return validatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
	}
   
	return validatePINResponse;
}
		
private ValidatePINResponse validatePINRequestValidatorInputValidator(ValidatePINRequest validatePINRequest) {
	ValidatePINResponse validatePINResponse = null;

	String stAppInfo = null;
	String sMethodName = ".validatePINRequestValidatorInputValidator.";
//	String stTransactionId = validatePINRequest.getTransactionId();
	String stTransactionName = validatePINRequest.getTransactionName();
	String stCallingSystemID = validatePINRequest.getCallingSystemId();
	String stIdentificationType = validatePINRequest.getIdentificationType();
	String stAccountID = validatePINRequest.getAccountId();
	String stSecurityCode = validatePINRequest.getSecurityCode();
	String stIdpTraceId = validatePINRequest.getIdpTraceId();
	Optional.ofNullable(validatePINRequest.getDeletePINOnSuccess()).ifPresent(x -> validatePINRequest.setDeletePINOnSuccess(x.trim().toUpperCase()));
	String stDeletePINOnSuccess=validatePINRequest.getDeletePINOnSuccess();
	if (stTransactionName == null || stTransactionName.isEmpty()) {

		stAppInfo = "TransactionName can not be null / empty.";
		logger.info("{}{}VPRV_102.2 : {}", sClassName, sMethodName, stAppInfo);
		return validatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
	}

	if (stCallingSystemID == null || stCallingSystemID.isEmpty()) {

		stAppInfo = "Either X-ATT-ClientId in request header or callingSystemId in request body must be present";
		logger.info("{}{}VPRV_102.3 : {}", sClassName, sMethodName, stAppInfo);
		return validatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
	}

	if (stIdentificationType == null || stIdentificationType.isEmpty()) {

		stAppInfo = "IdentificationType can not be null / empty.";
		logger.info("{}{}VPRV_102.4 : {}", sClassName, sMethodName, stAppInfo);
		return validatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
	}

	if (stAccountID == null || stAccountID.isEmpty()) {

		stAppInfo = "AccountID can not be null / empty.";
		logger.info("{}{}VPRV_102.5 : {}", sClassName, sMethodName, stAppInfo);
		return validatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
	}

	if (stSecurityCode == null || stSecurityCode.isEmpty()) {

		stAppInfo = "SecurityCode can not be null / empty.";
		logger.info("{}{}VPRV_102.6 : {}", sClassName, sMethodName, stAppInfo);
		return validatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
	}

	validatePINRequest.setAccountId(stAccountID.trim().toLowerCase());
	validatePINRequest.setIdentificationType(stIdentificationType.trim().toUpperCase());
	Optional.ofNullable(validatePINRequest.getAccountType()).ifPresent(x -> validatePINRequest.setAccountType(x.trim().toUpperCase()));
	
	if (!"ValidatePIN".equals(stTransactionName)) {
		stAppInfo = "Transaction Not Allowed :: TransactionName Should be ValidatePIN";
		logger.info("{}{}VPRV_102.7 : {}", sClassName, sMethodName, stAppInfo);
		return validatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
	}

	if (stDeletePINOnSuccess != null && !stDeletePINOnSuccess.isEmpty()) {
		if (!(stDeletePINOnSuccess.equals("ALL") || stDeletePINOnSuccess.equals("CURRENT") ||stDeletePINOnSuccess.equals("NONE") )) {
			stAppInfo = "DeletePINOnSuccess is Invalid :: Should be one of [ALL,CURRENT,NONE ]";
			return validatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
	}

	Optional.ofNullable(validatePINRequest.getAgentId())
			.ifPresent(x -> validatePINRequest.setAgentId(x.trim().toLowerCase()));
	
//	Optional.ofNullable(validatePINRequest.getSourceIPAddress()).ifPresent(x -> validatePINRequest.setSourceIPAddress(x.trim()));
	return validatePINResponse;
}

		private ValidatePINResponse validatePINErrorResponse(int appStatusCode, String stAppInfo, String stIdpTraceId) {
			Map<String, Object> hmResponse = CommonUtil.getHashMap();
			hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
//			hmResponse.put(CommonDefs.TRANSACTION_ID, transactionId);
			hmResponse.put("idp-trace-id", stIdpTraceId);
			hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
			hmResponse.put(CommonDefs.TRANSACTION_NAME, "ValidatePIN");
			return (ValidatePINResponse)CommonUtilHelper.generateCIRResponse(hmResponse);
		}

}
