package com.att.idp.idgraphcontactinfoms.helpers.voltage;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.att.idp.core.exception.ServiceException;
import com.att.idp.idgraphcontactinfoms.message.ErrorMessages;
import com.att.idp.logging.marker.SpiMarker;
import com.att.idp.voltage.common.VoltageEfpeFormatType;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.helpers.voltage package.
 * It is used for handling encryption and decryption of values using the Voltage encryption system.
 * The class contains methods for encrypting and decrypting values using the specified format.
 * It interacts with the VoltageEncryptDecryptHelper to perform the encryption and decryption.
 * The class is annotated with @Component, @Configuration, and @PropertySource, indicating that it is a Spring bean and can be automatically
 * picked up and instantiated by Spring's container. It also loads properties from a specified file.
 * The class contains several fields that are injected via Spring's @Value annotation, which are used to configure the encryption and decryption process.
 * The class also contains two methods, getEFPEEncryptedValues and getEFPEDecryptedValues, which are used to encrypt and decrypt values respectively.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class VoltageEncryptionHelper {
	private static final String sInfo = "@(#) RcsModuleId = $Id: VoltageEncryption_H.java 78567 2020-10-28 15:54:01Z ga441j $ $HeadURL: svn://scm.it.att.com:14056/common/trunk/tools/CommonHelper/src/com/att/common/helper/VoltageEncryption_H.java $";
	public static final Logger logger = LoggerFactory.getLogger(VoltageEncryptionHelper.class);
	
	
	@Value("${voltageEncryptFields}")
	private String propVoltageEncryptionFields;
	
	@Value("${voltageDecryptFields}")
	private String propVoltageDecryptionFields ;
		
	@Value("${voltagePCIEncryptFields}")
	private String propVoltagePCIEncryptionFields ;
	
	@Value("${voltagePCIDecryptFields}")
	private String propVoltagePCIDecryptionFields ;
	
	@Value("${voltageSSNEncryptFields}")
	private String propVoltageSSNEncryptionFields;
	
	@Value("${voltageSSNEncryptFields}")
	private String propVoltageSSNDecryptionFields;
	
	@Value("${voltageGenStringEncryptFields}")
	private String propVoltageGenStrEncryptionFields;
	
	@Value("${voltageGenStringDecryptFields}")
	private String propVoltageGenStrDecryptionFields;
	
	
	private static ArrayList alVoltageDecryptionFields = null;
	private static ArrayList alVoltageEncryptionFields = null;
	private static ArrayList alVoltagePCIEncryptionFields = null;
	private static ArrayList alVoltagePCIDecryptionFields = null;
	private static ArrayList alVoltageSSNEncryptionFields = null;
	private static ArrayList alVoltageSSNDecryptionFields = null;
	private static ArrayList alVoltageGenStrEncryptionFields = null;
	private static ArrayList alVoltageGenStrDecryptionFields = null;

	@Autowired
	private VoltageEncryptDecryptHelper voltageEncryptDecryptHelper;

	@Autowired
	private VoltageEncryptDecryptHelper voltageHelper;


	/**
	 * This method is used to encrypt values using the Voltage encryption system.
	 *
	 * It takes a HashMap as input, which contains the values to be encrypted.
	 * The method iterates over the HashMap, encrypting the values based on their key.
	 * The encrypted values are then added to a new HashMap, which is returned as the result.
	 * The method also logs information about the encryption process, and handles any exceptions that may occur.
	 *
	 * @param hmInput A HashMap containing the values to be encrypted.
	 * @return A HashMap containing the encrypted values.
	 */
	public HashMap getEFPEEncryptedValues(HashMap hmInput) {
		HashMap hmResponse = new HashMap();
		HashMap hmUpdatedInput = new HashMap();
		String sMethodName = "getEFPEEncryptedValues";
		Date dtStart = new Date();
		String sEncryptedValue = null;
		String sEncryptField = null;
		String sKey = null;
		String sVoltageEncryptionField = null;

		String sAppInfo = null;

		logger.info("GEV-E0 : " + "TMS");
		logger.info("CVS KEYWORDS:" + sInfo);
		logger.info(SpiMarker.getInstance(),"VoltageEncryptionHelper.getEFPEEncryptedValues.HLP000 : inputHash=", StructuredArguments.entries(hmInput));

		try {

			if (propVoltageEncryptionFields == null || propVoltageEncryptionFields.trim().length() == 0) {
				sAppInfo = "Missing or empty config parameter - VOLTAGE_ENCRYPTION_FIELDS";
				logger.error("GEV-E4 : " + sAppInfo);
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, sAppInfo);
				return hmResponse;
			}

			alVoltageEncryptionFields = CommonUtil.parseToArray(propVoltageEncryptionFields, '|');
			sAppInfo = "alVoltageEncryptionFields = " + alVoltageEncryptionFields;
			logger.info("GEV-1a : " + sAppInfo);

			if (propVoltagePCIEncryptionFields == null || propVoltagePCIEncryptionFields.trim().length() == 0) {
				// 1802 : 57618 : Remove PCI data from RegisterMember API and stop CreditRIL API
				// since DIAL registration is sunset
				alVoltagePCIEncryptionFields = new ArrayList();
			} else {
				alVoltagePCIEncryptionFields = CommonUtil.parseToArray(propVoltagePCIEncryptionFields, '|');
				sAppInfo = "sVoltagePCIEncryptionFields = " + alVoltagePCIEncryptionFields;
				logger.info("GEV-1b : " + sAppInfo);
			}

			if (propVoltageSSNEncryptionFields == null || propVoltageSSNEncryptionFields.trim().length() == 0) {
				// Unlike the other list fields, we expect this one to be blank because we do
				// not encrypt fedTaxId
				alVoltageSSNEncryptionFields = new ArrayList();
			} else
				alVoltageSSNEncryptionFields = CommonUtil.parseToArray(propVoltageSSNEncryptionFields, '|');

			sAppInfo = "sVoltageSSNEncryptionFields = " + alVoltageSSNEncryptionFields;
			logger.info("GEV-2b : " + sAppInfo);

			// 1410: to encrypt CBR
			if (propVoltageGenStrEncryptionFields == null || propVoltageGenStrEncryptionFields.trim().length() == 0) {
				alVoltageGenStrEncryptionFields = new ArrayList();
			} else {
				alVoltageGenStrEncryptionFields = CommonUtil.parseToArray(propVoltageGenStrEncryptionFields, '|');
			}

			sAppInfo = "alVoltageGenStrEncryptionFields = " + alVoltageGenStrEncryptionFields;
			logger.info("GEV-3b : {}", sAppInfo);

			java.util.Map.Entry mapEntry = null;
			Iterator hmInputIterator = hmInput.entrySet().iterator();
			while (hmInputIterator.hasNext()) {
				mapEntry = (java.util.Map.Entry) hmInputIterator.next();
				sKey = (String) mapEntry.getKey();
				Object oKeyObject = mapEntry.getValue();
				if (oKeyObject instanceof String) {
					sEncryptField = (String) hmInput.get(sKey);
					if (alVoltageEncryptionFields.contains(sKey)) {

						sEncryptedValue =voltageHelper.getEncryptedValue(sEncryptField,
								VoltageEfpeFormatType.B64_GENERIC.toString());
						logger.info("Encrypted Value1 : " + sEncryptedValue);

						hmUpdatedInput.put("voltage_" + sKey, sEncryptedValue);
					} else if (alVoltagePCIEncryptionFields.contains(sKey)) {

						sEncryptedValue = voltageHelper.getEncryptedValue(sEncryptField,
								VoltageEfpeFormatType.CC_NUM.toString());

						logger.info("Encrypted Value2 : " + sEncryptedValue);

						hmUpdatedInput.put("voltage_" + sKey, sEncryptedValue);
					} else if (alVoltageSSNEncryptionFields.contains(sKey)) {

						sEncryptedValue = voltageHelper.getEncryptedValue(sEncryptField,
								VoltageEfpeFormatType.ALLNUM_SSN.toString());
						logger.info("Encrypted Value3 : " + sEncryptedValue);

						hmUpdatedInput.put("voltage_" + sKey, sEncryptedValue);
					} else if (alVoltageGenStrEncryptionFields.contains(sKey)) {
						sEncryptedValue = voltageHelper.getEncryptedValue(sEncryptField,
								VoltageEfpeFormatType.ALPHA_NUM.toString());
						logger.info("GAV-E5a.1 : " + "EncryptedValue with ALPHA_NUM format: " + sEncryptedValue);
						hmUpdatedInput.put("voltage_" + sKey, sEncryptedValue);
					} else
						hmUpdatedInput.put(sKey, sEncryptField);
				}
			}

		} catch (Exception e) {
			sAppInfo = "Error Encrypting";
			logger.error("GAV-E5a : " + "Exception thrown: " + e.toString());
			logger.error("GEV-E5b : " + sAppInfo);
			
			try {
				// changed by pm675e for voltage upgrade 6.0
				logger.error("GEV-E5c : " + e.getMessage());
			} catch (Exception e1) {
				logger.error("GEV-E5c.1 : " + e1);
				// e1.printStackTrace();//1704 Release - Commenting SONAR Violation
				logger.error("GAV-E5c.2 : " + "Exception thrown: VeException.getDetailedMessage()");
			}
			if (e instanceof ServiceException) {
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, e.getMessage());

			} else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			}
			hmResponse.put("ErrorEnum", ErrorMessages.ERROR_VOLTAGE_ENCRYPT);

			return hmResponse;
		}

		hmResponse = CommonErrorMap.makeCommonStatusMap(CErrorDefs.COMMON_SUCCESS_NUM, "");
		hmResponse.putAll(hmUpdatedInput);
		hmInput.putAll(hmUpdatedInput);
		logger.info(SpiMarker.getInstance(),"VoltageEncryptionHelper.getEFPEEncryptedValues.HLP999 : " + dtStart.getTime() + " hmResponse :", StructuredArguments.entries(hmResponse));
		return hmResponse;
	}

	/**
	 * This method is used to decrypt values using the Voltage encryption system.
	 *
	 * It takes a HashMap as input, which contains the values to be decrypted.
	 * The method iterates over the HashMap, decrypting the values based on their key.
	 * The decrypted values are then added to a new HashMap, which is returned as the result.
	 * The method also logs information about the decryption process, and handles any exceptions that may occur.
	 *
	 * @param hmInput A HashMap containing the values to be decrypted.
	 * @return A HashMap containing the decrypted values.
	 */
	public HashMap getEFPEDecryptedValues(HashMap hmInput) {
		HashMap hmResponse = new HashMap();
		Date dtStart = new Date();
		String sDecryptedValue = null;
		String sDecryptField = null;

		String sAppInfo = null;

		logger.info("GDV-E0 : " + "TMS");
		logger.info("CVS KEYWORDS:" + sInfo);
		logger.info("HLP000 : " + "Input Hash = " + hmInput);

		try {

			if (propVoltageDecryptionFields == null || propVoltageDecryptionFields.trim().length() == 0) {
				sAppInfo = "Missing or empty config parameter - VOLTAGE_DECRYPTED_FIELDS";
				logger.error("GADV-E4a : " + sAppInfo);
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, sAppInfo);
				return hmResponse;
			}
			alVoltageDecryptionFields = CommonUtil.parseToArray(propVoltageDecryptionFields, '|');
			logger.debug("GADV-1a : " + "alVoltageDecryptionFields=" + alVoltageDecryptionFields);

			if (propVoltagePCIDecryptionFields == null || propVoltagePCIDecryptionFields.trim().length() == 0) {
				// Unlike the other list fields, we expect this one to be blank because we do
				// not decrypt ccNumber
				alVoltagePCIDecryptionFields = new ArrayList();
			} else
				alVoltagePCIDecryptionFields = CommonUtil.parseToArray(propVoltagePCIDecryptionFields, '|');

			logger.debug("GADV-1b : " + "alVoltagePCIDecryptionFields=" + alVoltagePCIDecryptionFields);

			if (propVoltageSSNDecryptionFields == null || propVoltageSSNDecryptionFields.trim().length() == 0) {
				sAppInfo = "Missing or empty config parameter - VOLTAGE_SSN_DECRYPTED_FIELDS";
				logger.error("GADV-E4a : " + sAppInfo);
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, sAppInfo);
				return hmResponse;
			}

			alVoltageSSNDecryptionFields = CommonUtil.parseToArray(propVoltageSSNDecryptionFields, '|');
			logger.debug("GADV-2a : " + "alVoltageSSNDecryptionFields=" + alVoltageSSNDecryptionFields);

			// 1410: to decrypt CBR
			if (propVoltageGenStrDecryptionFields == null || propVoltageGenStrDecryptionFields.trim().length() == 0) {
				alVoltageGenStrDecryptionFields = new ArrayList();
			} else {
				alVoltageGenStrDecryptionFields = CommonUtil.parseToArray(propVoltageGenStrDecryptionFields, '|');
			}

			logger.debug("GADV-2a : " + "alVoltageGenStrDecryptionFields=" + alVoltageGenStrDecryptionFields);

			java.util.Map.Entry mapEntry = null;
			Iterator hmInputIterator = hmInput.entrySet().iterator();
			while (hmInputIterator.hasNext()) {
				mapEntry = (java.util.Map.Entry) hmInputIterator.next();
				String sKey = (String) mapEntry.getKey();

				Object oKeyObject = mapEntry.getValue();
				if (oKeyObject instanceof String) {
					sDecryptField = (String) hmInput.get(sKey);

					if (alVoltageDecryptionFields.contains(sKey)) {
						sDecryptedValue = voltageHelper.getDecryptedValue(sDecryptField, VoltageEfpeFormatType.B64_GENERIC.toString());
						
//						logger.debug("Decrypted Value : " + sDecryptedValue);
						hmInput.put(sKey, sDecryptedValue);
					} else if (alVoltagePCIDecryptionFields.contains(sKey)) {
						sDecryptedValue = voltageHelper.getDecryptedValue(sDecryptField, VoltageEfpeFormatType.CC_NUM.toString());
						hmInput.put(sKey, sDecryptedValue);
					} else if (alVoltageSSNDecryptionFields.contains(sKey)) {
						sDecryptedValue = voltageHelper.getDecryptedValue(sDecryptField, VoltageEfpeFormatType.ALLNUM_SSN.toString());

						hmInput.put(sKey, sDecryptedValue);
					} else if (alVoltageGenStrDecryptionFields.contains(sKey)) {
						sDecryptedValue = voltageHelper.getDecryptedValue(sDecryptField, VoltageEfpeFormatType.ALPHA_NUM.toString());
						hmInput.put(sKey, sDecryptedValue);
					} else
						hmInput.put(sKey, sDecryptField);
				}
			}

		} catch (Exception e) {
			sAppInfo = "Error Decrypting";
			logger.error("GDV-E5a : " + "VeException thrown: " + e.toString());
			logger.error("GDV-E5b : " + sAppInfo);
			try {
				// change by pm675e for voltage upgrade 6.0
				logger.error("GDV-E5c : " + e.getMessage());
			} catch (Exception e1) {
				logger.error("GEV-E5c.1 : " + e1);
				// e1.printStackTrace();//1704 Release - Commenting SONAR Violation
				logger.error("GDV-E5c.2 : " + "Exception thrown: VeException.getDetailedMessage()");
			}
			hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			return hmResponse;
		}

		hmResponse = CommonErrorMap.makeCommonStatusMap(CErrorDefs.COMMON_SUCCESS_NUM, "");
		hmResponse.putAll(hmInput);
		logger.info(SpiMarker.getInstance(),"VoltageEncryptionHelper.getEFPEDecryptedValues.HLP999 : " + dtStart.getTime() + " hmResponse :", StructuredArguments.entries(hmResponse));
		return hmResponse;
	}
}