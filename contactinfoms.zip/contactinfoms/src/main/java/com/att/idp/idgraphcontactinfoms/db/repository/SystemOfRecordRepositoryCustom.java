package com.att.idp.idgraphcontactinfoms.db.repository;

/**
 * This is a custom repository interface for SystemOfRecord.
 *
 * It is meant to be extended by other interfaces to provide custom methods for SystemOfRecord related operations.
 * Currently, it does not define any methods.
 *
 * This interface is meant to be implemented by a class that provides the actual implementation of the custom methods.
 */
public interface SystemOfRecordRepositoryCustom {
	
}
