package com.att.idp.idgraphcontactinfoms.integration;


import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.impl.routing.DefaultProxyRoutePlanner;
import org.apache.hc.core5.util.Timeout;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig;


@Component
public class OutboundRestClientBuilder {

	private final IDGraphAzureAppConfig appConfig;

	@Autowired
	public OutboundRestClientBuilder(IDGraphAzureAppConfig appConfig) {
		this.appConfig = appConfig;
	}

	/**
	 * Builds and customizes a RestTemplate instance by configuring connection and read timeouts,
	 * with optional proxy support.
	 * <p>
	 * This method sets up a custom `HttpComponentsClientHttpRequestFactory` with the specified
	 * connection and read timeouts. It uses an Apache HttpClient to handle HTTP requests and wraps
	 * the request factory in a `BufferingClientHttpRequestFactory` to enable request/response logging
	 * if needed. If proxy support is enabled, it configures the HTTP client with the provided
	 * `DefaultProxyRoutePlanner`.
	 *
	 * @param restTemplate   the original RestTemplate instance to be customized.
	 * @param connectTimeout the connection timeout in milliseconds.
	 * @param readTimeout    the read timeout in milliseconds.
	 * @param useProxy       a boolean indicating whether to configure the RestTemplate with a proxy.
	 * @param routePlanner   the proxy route planner to use if `useProxy` is true.
	 * @return the customized RestTemplate instance with the configured timeouts and optional proxy.
	 *
	 */

	public RestTemplate buildRestTemplate(RestTemplate restTemplate, int connectTimeout, int readTimeout, boolean useProxy, DefaultProxyRoutePlanner routePlanner) {

		RequestConfig requestConfig = RequestConfig.custom()
				.setConnectTimeout(Timeout.ofMilliseconds(connectTimeout))
				.setResponseTimeout(Timeout.ofMilliseconds(readTimeout))
				.setConnectionRequestTimeout(Timeout.ofMilliseconds(appConfig.getHttpPoolConnectionRequestTimeout()))
				.build();

		PoolingHttpClientConnectionManager connectionManager = PoolingHttpClientConnectionManagerBuilder.create()
				.setMaxConnTotal(appConfig.getHttpPoolMaxTotal())
				.setMaxConnPerRoute(appConfig.getHttpPoolDefaultMaxPerRoute())
				.build();

		CloseableHttpClient httpClient;

		if (useProxy) {
			httpClient = HttpClients.custom()
					.setConnectionManager(connectionManager)
					.setDefaultRequestConfig(requestConfig)
					.setRoutePlanner(routePlanner)
					.build();
		} else {
			httpClient = HttpClients.custom()
					.setConnectionManager(connectionManager)
					.setDefaultRequestConfig(requestConfig)
					.build();
		}

		HttpComponentsClientHttpRequestFactory customRequestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
		restTemplate.setRequestFactory(new BufferingClientHttpRequestFactory(customRequestFactory));

		return restTemplate;
	}
}
