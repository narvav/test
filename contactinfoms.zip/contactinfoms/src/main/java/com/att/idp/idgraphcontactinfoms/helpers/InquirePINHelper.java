package com.att.idp.idgraphcontactinfoms.helpers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import com.att.idp.idgraph.db.cosmos.helper.IdgOtpDBHelper;
import com.att.mpsys.common.helpers.FeatureManagerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphcontactinfoms.db.helper.SecurityCodeDBHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This class is a helper class for inquiring PINs.
 *
 * It contains methods for inquiring PINs based on the input parameters.
 * The class uses the Spring Framework's @Component annotation to indicate that it is a bean and can be used for dependency injection.
 *
 * The class has several instance variables that are injected using the @Autowired annotation.
 * These variables are used to interact with various other helper classes and services to process and validate PINs.
 *
 * The main method in this class is the inquirePIN method, which takes a Map as input and returns a HashMap as output.
 *
 * The class also contains a logger for logging information and error messages.
 */
@Component
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class InquirePINHelper {

	@Autowired
	private SecurityCodeDBHelper securityCodeDBHelperObj;

	@Autowired
	private FeatureManagerHelper featureManager;

	@Autowired
	private IdgOtpDBHelper idgOtpDBHelper;

	@Value("${PROP_PIN_MAX_PINS}")
	private String propPinMaxPins;

	public static final String sClassName = "InquirePINHelper.";
	private static final String ERROR_ENUM = "ErrorEnum";
	public static final Logger logger = LoggerFactory.getLogger(InquirePINHelper.class);
	
	public static String dbTimeZone = null;

	/**
	 * This method is used to inquire PINs.
	 *
	 * It takes a Map as input which contains various keys related to the PIN inquiry process.
	 * The method performs various checks and validations on the input data and constructs a response HashMap.
	 * The response HashMap contains the result of the PIN inquiry process.
	 *
	 * The method interacts with various other helper classes and services to process and inquire PINs.
	 * It also handles various error scenarios and constructs appropriate error responses.
	 *
	 * @param hmInput A Map containing the input data for the PIN inquiry process.
	 * @return A HashMap containing the result of the PINs.
	 * @throws Exception if an error occurs during the operation.
	 */
	public HashMap<String, Object> inquirePIN(Map<String, Object> hmInput) {

		String sMethodName =  "inquirePIN.";
		logger.info(SpiMarker.getInstance(), "InquirePINHelper.inquirePIN.HLP000 : Input Hash :",
				StructuredArguments.entries(hmInput));

		HashMap<String, Object> hmResult = null;
		String stAppInfo = null;
		String stAppStatusCode = null;
		
		try {
			String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sAccountId = (String) hmInput.get(CommonDefs.ACCOUNT_ID);
			String sIdentificationType = (String) hmInput.get(CommonDefs.IDENTIFICATION_TYPE);

			if ((sTransactionName == null || sCallingSystemId == null || sAccountId == null
					|| sIdentificationType == null)) {
				stAppInfo = "Either of the parameters TransactionName|CallingSystemId|AccountId|IdentificationType is null";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}IPH_01 :: {}",sClassName, sMethodName , hmResult);
				return hmResult;
			}

			sAccountId = sAccountId.trim().toLowerCase();
			hmInput.put(CommonDefs.ACCOUNT_ID, sAccountId);
			sIdentificationType = sIdentificationType.trim().toUpperCase();
			hmInput.put(CommonDefs.IDENTIFICATION_TYPE, sIdentificationType);

			HashMap<String, Object> hmGetDBPinInput = CommonUtil.getHashMap();
			hmGetDBPinInput.put(MPSDefs.DB_IDENTIFICATION_TYPE, sIdentificationType);
			hmGetDBPinInput.put(MPSDefs.DB_ACCOUNT_ID, sAccountId);
			hmGetDBPinInput.put(MPSDefs.GET_EXCEEDED_UNLOCKED_TIME, MPSDefs.NO);

			logger.debug("{}{}IPH_06 :Calling GetSecurityCodeDataService.getSecurityCodeData() with input : {}",
					sClassName, sMethodName , hmGetDBPinInput);
			String otpDataSource = getOtpDataSource();
			HashMap<String, Object> hmSecurityCodeResp = null;
			if ("ORACLEMASTER".equalsIgnoreCase(otpDataSource) || "ONLYORACLE".equalsIgnoreCase(otpDataSource)) {
				hmSecurityCodeResp =
						(HashMap<String, Object>) securityCodeDBHelperObj.getSecurityCodeDataQuery(hmGetDBPinInput);
			}
			else if("COSMOSMASTER".equalsIgnoreCase(otpDataSource) || "ONLYCOSMOS".equalsIgnoreCase(otpDataSource))
			{
				hmSecurityCodeResp = (HashMap<String, Object>) idgOtpDBHelper.getSecurityCodeDataQuery(hmGetDBPinInput);

			}
			logger.debug("{}{}IPH_07 :Response from GetSecurityCodeDataService.getSecurityCodeData() is: {}",
					sClassName, sMethodName , hmSecurityCodeResp);
            if ( hmSecurityCodeResp!=null) {
				stAppStatusCode = (String) hmSecurityCodeResp.get(CommonDefs.COMMON_APP_STATUS_CODE);
				}
			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))
					&& !(CErrorDefs.ERR_REC_NOT_FOUND.equals(stAppStatusCode))) {
				logger.info("{}{}IPH_08 :GetSecurityCodeDataService.getSecurityCodeData() returned error: {}",
						sClassName, sMethodName , hmSecurityCodeResp);
				return hmSecurityCodeResp;
			}

			if (CErrorDefs.ERR_REC_NOT_FOUND.equals(stAppStatusCode)) {
				stAppInfo = "No record found in DB.";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, stAppInfo);
				return hmResult;
			}
			String sMaxPins = "0";
			HashMap hmMaxPins = CommonUtil.parsePropertyToHash(propPinMaxPins);
			logger.info("{}{}IPH_09 :PROP_PIN_MAX_PINS : {}",sClassName, sMethodName , hmMaxPins);

			if (hmMaxPins.containsKey(sIdentificationType)) {
				sMaxPins = (String) hmMaxPins.get(sIdentificationType);
			}
			if (sMaxPins.equals("0") || sMaxPins.isEmpty()) {
				stAppInfo = "PROP_PIN_MAX_PINS is not set for IdentificationType : " + sIdentificationType;
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}IPH_10 :: {}",sClassName, sMethodName , hmResult);
				return hmResult;
			}

			if (dbTimeZone == null) dbTimeZone = securityCodeDBHelperObj.getDbTimeZone();
			hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
			ArrayList alSecurityCodeData = (ArrayList) hmSecurityCodeResp.get(MPSDefs.SECURITY_CODE_INFO);
			ArrayList alSecurityPins = CommonUtil.getArrayList();
			if (alSecurityCodeData != null && !alSecurityCodeData.isEmpty()) {
				for(int i=0; i<alSecurityCodeData.size(); i++) {
					HashMap eachCode = (HashMap) alSecurityCodeData.get(i);
					HashMap eachPIN = CommonUtil.getHashMap(); 
					eachPIN.put(CommonDefs.ACCOUNT_ID, sAccountId);
					eachPIN.put(CommonDefs.IDENTIFICATION_TYPE, sIdentificationType);
					eachPIN.put(CommonDefs.STATUS, eachCode.get("security_code_status"));
					eachPIN.put("createTime", getGMTDate((String)eachCode.get(MPSDefs.DB_CREATE_DATE), dbTimeZone));
					eachPIN.put("expirationTime", getGMTDate((String)eachCode.get(MPSDefs.DB_SECURITY_CODE_EXPIRES), dbTimeZone));
					eachPIN.put("verificationFailureCount", String.valueOf(eachCode.get(MPSDefs.DB_VERIFICATION_FAILURE_COUNT)));
					eachPIN.put("requestedBy",  eachCode.get(MPSDefs.DB_LAST_MODIFIED_BY));
					eachPIN.put(CommonDefs.DELIVERY_METHOD,  eachCode.get(MPSDefs.DB_DELIVERY_METHOD));
					eachPIN.put(CommonDefs.DELIVERY_DETAIL,  eachCode.get(MPSDefs.DB_DELIVERY_DETAIL));
					
					alSecurityPins.add(eachPIN);
				}

// Initialize variables for PIN counts
				int totalPins = 0;
				int activePins = 0;
				int unusedPins = 0;

// Parse the maximum allowed PINs and calculate active and unused PINs
				totalPins = Integer.parseInt(sMaxPins);
				activePins = alSecurityPins.size();
				unusedPins = Math.max(0, totalPins - activePins);

// Add PIN-related data to the result map
				hmResult.put("securityPins", alSecurityPins);
				hmResult.put("maxAllowedPINs", totalPins);
				hmResult.put("unusedPINs", unusedPins);
			}
			
			

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);

		} finally {

			if (hmResult == null || hmResult.isEmpty()) {
				stAppInfo = "Response from InquirePINHelper is NULL";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}IPH_31 :: {}",sClassName, sMethodName , stAppInfo);
			}
			String sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
			String sAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);

			if (!CErrorDefs.COMMON_SUCCESS.equalsIgnoreCase(sAppStatusCode)) {
				sAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
				logger.info("{}{}IPH_32 :: {}",sClassName, sMethodName , HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
			}

			logger.info(SpiMarker.getInstance(), "InquirePINHelper.HLP999 : {}",
					HtmlUtils.htmlEscape(String.valueOf(hmResult)));
		}

		return hmResult;
	}

	private String getGMTDate(String inpStr, String dbTimeZone) throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat("MMddyyyy HH:mm:ss");
		format.setTimeZone(TimeZone.getTimeZone("GMT"+dbTimeZone));
		Date inpDate = format.parse(inpStr); //date with db timezone
		
		SimpleDateFormat gmtFormat = new SimpleDateFormat("MMddyyyy HH:mm:ss z");
		gmtFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		String formattedDate = gmtFormat.format(inpDate); //string with GMT date
		
		return formattedDate;
	}

	/**
	 * This method is responsible for retrieving the OTP data source from the feature manager.
	 *
	 * It checks if the feature manager has a value for the key "cfg-idgraph-contactinfo-otpdatasource".
	 * If the value is found, it returns that value.
	 * If the value is not found (i.e., it is null), it sets a default value of "COSMOSMASTER" and logs an error message.
	 *
	 * @return a String representing the OTP data source.
	 */
	public String getOtpDataSource() {
		String otpDataSource = featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource");
		if (otpDataSource == null) {
			otpDataSource = "COSMOSMASTER";
			logger.error("IXP Flag cfg-idgraph-contactinfo-otpdatasource is null, setting default value {} ", otpDataSource);
		}
		else if (!("ORACLEMASTER".equalsIgnoreCase(otpDataSource)
				|| "ONLYORACLE".equalsIgnoreCase(otpDataSource)
				|| "ONLYCOSMOS".equalsIgnoreCase(otpDataSource)
				|| "COSMOSMASTER".equalsIgnoreCase(otpDataSource))) {
			throw new IllegalArgumentException("Invalid OTP data source: " + otpDataSource);
		}
		return otpDataSource;
	}

}