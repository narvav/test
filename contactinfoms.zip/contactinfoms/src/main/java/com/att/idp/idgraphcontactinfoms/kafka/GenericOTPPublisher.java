package com.att.idp.idgraphcontactinfoms.kafka;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.apache.commons.text.StringEscapeUtils;
import org.apache.kafka.common.errors.AuthenticationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.retry.annotation.Backoff;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphcontactinfoms.exceptions.PrimaryProducerException;
import com.att.idp.idgraphcontactinfoms.exceptions.SecondaryProducerException;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
@EnableRetry
public class GenericOTPPublisher {

	@Autowired
	@Qualifier("primaryGOTPKafkaTemplate")
    private KafkaTemplate<String, Object> kafkaTemplatePrimary;
	
    @Autowired
    @Qualifier("secondaryGOTPKafkaTemplate")
    private KafkaTemplate<String, Object> kafkaTemplateSecondary;


    @Value(value = "${genericotp.azureeventhub.publisher.topic}")
    private String gotpTopicname;

    @Value(value = "${genericotp.azureeventhub.secondary.publisher.topic}")
    private String gotpSecondaryTopicname;

    
    private static String sClassName = "GenericOTPPublisher.";

    public static final Logger logger = LoggerFactory.getLogger(GenericOTPPublisher.class);


    @Retryable(
            value = {Exception.class},
            maxAttemptsExpression = "${genericotp.retry.maxAttempts}",
            backoff = @Backoff(delayExpression = "${genericotp.retry.backoff.delay}")
    )
    public void sendToPrimary(String msgJson) throws PrimaryProducerException {
        String sMethodName = "sendToPrimary";
        Map<String, String> contextMap = MDC.getCopyOfContextMap();
        //ListenableFuture<SendResult<String, Object>> future;
        CompletableFuture<SendResult<String, Object>> future;

        try {
                future = kafkaTemplatePrimary.send(gotpTopicname, msgJson);
            } catch (AuthenticationException e) {
                throw new PrimaryProducerException("MS_MPSYS_BE_604", "Message publishing to Primary topic failed due to bad Credentials", 500);
            } catch (Exception e) {
                throw new PrimaryProducerException("MS_MPSYS_BE_604", "Message publishing to Primary topic failed for Generic OTP notification", 500);
            }

        future.whenComplete((result, ex) -> {
            if (ex != null) {
                try (MDC.MDCCloseable ignored = MDC.putCloseable("idp-trace-id", contextMap.get("idp-trace-id"))) {
                    logger.error(sClassName, sMethodName,
                            "MS_MPSYS_BE_604: Message publishing failed"+ex.getMessage());
                    logger.info(sClassName, sMethodName, "Exception occured during publishing the message : {}", ex.getMessage());
                }
                recover(new PrimaryProducerException("MS_MPSYS_BE_604", "Message publishing to OTP Primary topic failed", 500), msgJson, contextMap);

            } else {
                try (MDC.MDCCloseable ignored = MDC.putCloseable("idp-trace-id", contextMap.get("idp-trace-id"))) {
                    logger.info(
                            "{} {} Notification {} created and message published to Primary topic: {} with offset: {} to partition {}",
                            sClassName, sMethodName, msgJson, gotpTopicname, result.getRecordMetadata().offset(),
                            result.getRecordMetadata().partition());
                    logger.info("Message Published succesfully to {}",gotpTopicname);
                }


            }
        });

    }


    @Recover
    public void recover(Exception e, String message, Map<String, String> contextMap) {
        logger.info("Recovery action triggered [Primary Cluster] for Kafka message -  Topic: {},  Error: {}, Message: {}",
        		gotpTopicname, e.getMessage(), message);
        sendToSecondary(message, contextMap);
        
    }


    @Retryable(
            recover = "recoverSendToSecondary",
            value = {SecondaryProducerException.class},
            maxAttemptsExpression = "${genericotp.retry.maxAttempts}",
            backoff = @Backoff(delayExpression = "${genericotp.retry.backoff.delay}")
    )
    public void sendToSecondary(String msgJson, Map<String, String> contextMap) {
        String sMethodName = "sendToSecondary";
        CompletableFuture<SendResult<String, Object>>  future;
        try {
            future = kafkaTemplateSecondary.send(gotpSecondaryTopicname, msgJson);
        } catch (AuthenticationException e) {
            throw new PrimaryProducerException("MS_MPSYS_BE_604", "Message publishing to Secondary topic failed due to bad Credentials", 500);
        } catch (Exception e) {
            throw new PrimaryProducerException("MS_MPSYS_BE_604", "Message publishing to Secondary topic failed for Generic OTP notification", 500);
        }   
        // write a method to handle future object
        future.whenComplete((result, ex) -> {
            if (ex != null) {
                try (MDC.MDCCloseable ignored = MDC.putCloseable("idp-trace-id", contextMap.get("idp-trace-id"))) {
                    logger.error(sClassName, sMethodName,
                            "MS_MPSYS_BE_604: Message publishing failed"+ex.getMessage());
                    logger.info(sClassName, sMethodName, "Exception occured during publishing the message : {}", ex.getMessage());
                }
                recover(new PrimaryProducerException("MS_MPSYS_BE_604", "Message publishing to OTP Primary topic failed", 500), msgJson, contextMap);

            } else {
                try (MDC.MDCCloseable ignored = MDC.putCloseable("idp-trace-id", contextMap.get("idp-trace-id"))) {
                    logger.info(
                            "{} {} Notification {} created and message published to Primary topic: {} with offset: {} to partition {}",
                            sClassName, sMethodName, msgJson, gotpTopicname, result.getRecordMetadata().offset(),
                            result.getRecordMetadata().partition());
                    logger.info("Message Published succesfully to {}",gotpTopicname);
                }


            }
        });


    }

    @Recover
    public void recoverSendToSecondary(SecondaryProducerException e, String message) {
        logger.info("Recovery action triggered [Secondary Cluster] for Kafka message -  Topic: {},  Error: {}, Message: {}",
                StringEscapeUtils.escapeJava(gotpSecondaryTopicname), StringEscapeUtils.escapeJava(e.getMessage()), StringEscapeUtils.escapeJava(message));
        throw new SecondaryProducerException("MS_MPSYS_BE_604", "Message publishing to Secondary OTP topic failed", 500);
    }
    
}
