package com.att.idp.idgraphcontactinfoms.cgclient.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

/**
 * The Profile class represents a user's profile in the system.
 * It implements the Serializable interface, which means its instances can be converted to a byte stream and
 * restored back to the same object later. This is useful for storing objects in a file or sending them over a network.
 *
 * This class contains properties related to a user's profile such as firstName, lastName, phoneNumber, phoneNumberAttIndicator, secondaryPhoneNumberAttIndicator, and emailAddress.
 * Each property has its corresponding getter and setter methods.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.cgclient.response package.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(name = "Profile")
@Getter
@Setter
@NoArgsConstructor
public class Profile implements Serializable {

	private static final long serialVersionUID = -1928527398142269679L;

	private String firstName;
	private String lastName;
	private String phoneNumber;
	private boolean phoneNumberAttIndicator;
	private boolean secondaryPhoneNumberAttIndicator;
	private String emailAddress;
}