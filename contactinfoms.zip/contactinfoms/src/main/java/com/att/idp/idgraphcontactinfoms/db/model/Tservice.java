package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "TSERVICE", schema = "MPS_OWNER", uniqueConstraints = @UniqueConstraint(columnNames = "SERVICE_NAME"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tservice implements java.io.Serializable {

	private static final long serialVersionUID = 6140087848220167832L;

	@Id
	@Column(name = "SERVICE_ID", unique = true, nullable = false, precision = 22, scale = 0)
	private Long serviceId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MAJOR_SERVICE_ID")
	private Tservice tservice;

	@Column(name = "SERVICE_NAME", unique = true, nullable = false, length = 100)
	private String serviceName;

	@Column(name = "SERVICE_TYPE", nullable = false, length = 30)
	private String serviceType;

	@Column(name = "SERVICE_DESC")
	private String serviceDesc;

	@Column(name = "EMAIL_ELIGIBLE", nullable = false, length = 1)
	private char emailEligible;

	@Column(name = "SUBACCOUNT_ELIGIBLE", nullable = false, length = 1)
	private char subaccountEligible;

	@Column(name = "ENTITY_TYPE", nullable = false, length = 20)
	private String entityType;

	@Column(name = "PROCESS_DYNAMICALLY", length = 1)
	private Character processDynamically;

	@Column(name = "ELIGIBILITY", length = 50)
	private String eligibility;

	@Column(name = "SINGLE_INSTANCE", length = 1)
	private Character singleInstance;

	@Column(name = "UNIQUE_INSTANCE", length = 1)
	private Character uniqueInstance;

	@Column(name = "MERGE_ACTION", length = 50)
	private String mergeAction;

	@Column(name = "TRANSFER_OF_OWNERSHIP", length = 50)
	private String transferOfOwnership;

	@Column(name = "ACCESS_GROUP", length = 50)
	private String accessGroup;

	@Column(name = "PROMOTE", length = 1)
	private Character promote;

	@Column(name = "INHERIT", length = 1)
	private Character inherit;

	@Column(name = "CPNI_ADDRESSES_AVAILABLE", length = 1)
	private Character cpniAddressesAvailable;

	@Column(name = "AUTHORIZED_USER", length = 1)
	private Character authorizedUser;

	@Column(name = "ENTITY_SUBTYPE", length = 20)
	private String entitySubtype;

	@Column(name = "USE_DYNAMIC_NOTIFICATION", length = 1)
	private Character useDynamicNotification;

	@Column(name = "CALLING_SYSTEM_IDS")
	private String callingSystemIds;

	@Column(name = "SOR_NAMES")
	private String sorNames;

	@Column(name = "CREATE_DATE", length = 7)
	private Date createDate;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tservice")
	private Set<Tservicerole> tserviceroles = new HashSet<>(0);

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "tservice")
	private Tserviceproduct tserviceproduct;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tserviceByServiceId")
	private Set<Tmonitorconfig> tmonitorconfigsForServiceId = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tservice")
	private Set<Tservice> tservices = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tserviceByListenerId")
	private Set<Tmonitorconfig> tmonitorconfigsForListenerId = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tservice")
	private Set<Tmemberservice> tmemberservices = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tservice")
	private Set<Tdynservicesor> tdynservicesors = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tservice")
	private Set<Tdynnotifications> tdynnotificationses = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tservice")
	private Set<Tmemberserviceattribute> tmemberserviceattributes = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tservice")
	private Set<Tprovisionedservice> tprovisionedservices = new HashSet<>(0);
}