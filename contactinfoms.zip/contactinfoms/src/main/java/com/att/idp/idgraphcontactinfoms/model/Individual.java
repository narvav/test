package com.att.idp.idgraphcontactinfoms.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The class Individual
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "Individual")
public class Individual {
    /** The individualId. */
    @JsonProperty("id")
    private String id;

    /** The contactMediums. */
    @JsonProperty("contactMediums")
    private List<ContactMedium> contactMediums = null;

    /** The accounts. */
    @JsonProperty("accounts")
    private List<Account> accounts;
}
