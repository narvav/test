package com.att.idp.idgraphcontactinfoms.db.repository.impl;

import java.time.LocalDate;
import java.util.HashMap;

import com.att.idp.idgraphcontactinfoms.utils.DateUtil;
import com.att.idp.idgraphcontactinfoms.utils.ProfileOrchestrationConstants;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.idp.idgraphcontactinfoms.db.model.Tsecuritycode;
import com.att.idp.idgraphcontactinfoms.db.repository.IDGraphContactInfoCustomRepository;
import com.att.idp.idgraphcontactinfoms.db.repository.SecurityCodeRepositoryCustom;
import com.att.idp.idgraphcontactinfoms.db.repository.SystemOfRecordRepository;
import com.att.idp.idgraphcontactinfoms.exceptions.MPSException;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.StatusMsg;

/**
 * This is the implementation class for the SecurityCodeRepositoryCustom interface.
 *
 * It extends IDGraphContactInfoCustomRepository, which is a custom repository for IDGraphContactInfo. The IDGraphContactInfoCustomRepository takes two parameters: Tsecuritycode and Long. Tsecuritycode is the entity and Long is the type of the entity's primary key.
 *
 * This class is meant to provide the actual implementation of the methods defined in the SecurityCodeRepositoryCustom interface.
 */
public class SecurityCodeRepositoryImpl extends IDGraphContactInfoCustomRepository<Tsecuritycode, Long>
		implements SecurityCodeRepositoryCustom {

	private static final Logger logger = LoggerFactory.getLogger(SecurityCodeRepositoryImpl.class);
	private static String sClassName = "SecurityCodeRepositoryImpl";

	@Autowired
	private SystemOfRecordRepository systemOfRecordRepo;

	@Override
	public int setSecurityCode(HashMap InpParam) throws Exception {

		String sMethodName = ".setSecurityCode.";
		int rowCount = 0;
		
		HashMap resultHash = null;

		logger.info("{}{}DBTOOLS000 : InpParam = {}", sClassName, sMethodName, InpParam);

		String identification_type = ((String) InpParam.get(MPSDefs.DB_IDENTIFICATION_TYPE));
		if (identification_type != null) {
			identification_type = (identification_type.toUpperCase()).trim();
		}

		String last_modified_by = ((String) InpParam.get(MPSDefs.DB_LAST_MODIFIED_BY));

		String stSecurityCodeExpirationTime = ((String) InpParam.get("security_code_expiration_time"));

		double securityCodeExpirationTime = Double.parseDouble(stSecurityCodeExpirationTime);

		LocalDate localDate = LocalDate.now();
		java.sql.Date now = java.sql.Date.valueOf(localDate);

		String setSecurityCodeDataSql = "INSERT INTO MPS_OWNER.TSECURITYCODE(IDENTIFICATION_TYPE,ACCOUNT_ID,"
				+ "SECURITY_CODE,VERIFICATION_FAILURE_COUNT,SECURITY_CODE_EXPIRES, "
				+ "SECURITY_CODE_STATUS, "
				+ "LAST_MODIFIED_BY,SOURCE,SOR_ID,SOR_INVARIANT_ID,"
				+ "SLID_MEMBER_NUM,DELIVERY_METHOD,DELIVERY_DETAIL,PASSCODE_VENC) "
				+ "values (:identificationType,:accountId,:securityCode, "
				+ ":verificationFailureCount, sysdate + :securityCodeExpires,:securityCodeStatus, "
				+ ":lastModifiedBy, :source,:sorId, :sorInvariantId,:slidMemberNum,:deliveryMethod, "
				+ ":deliveryDetail,:passcodeVenc )";

		String account_id = ((String) InpParam.get(MPSDefs.DB_ACCOUNT_ID));
		if (account_id != null) {
			account_id = (account_id.toLowerCase()).trim();
		}
		String security_code = ((String) InpParam.get(MPSDefs.DB_SECURITY_CODE));
		String security_code_expires = ((String) InpParam.get(MPSDefs.DB_SECURITY_CODE_EXPIRES));
		String security_code_status = "ACTIVE"; // Defaults to 'ACTIVE' for New Security Codes.

		String sor_name = (String) InpParam.get(MPSDefs.DB_SOR_NAME);
		String sor_invariant_id = (String) InpParam.get(MPSDefs.DB_SOR_INVARIANT_ID);

		String stSlidMemberNum = (String) InpParam.get(MPSDefs.DB_SLID_MEMBER_NUM);
		String delivery_detail = (String) InpParam.get(MPSDefs.DB_DELIVERY_DETAIL);
		String delivery_method = (String) InpParam.get(MPSDefs.DB_DELIVERY_METHOD);
		String source = (String) InpParam.get(CommonDefs.SOURCE);

		Long slid_member_num = (long) -1;

		Long sor_id = 0L;
		String passcode_venc = (String) InpParam.get(MPSDefs.DB_PASSCODE_VENC);
		int verification_failure_count = 0;

		try {
			if (sor_name != null && sor_name.trim().length() > 0) {

				sor_id = getSorId(sor_name);
			}

			if (stSlidMemberNum != null && stSlidMemberNum.trim().length() > 0) {

				slid_member_num = Long.parseLong(stSlidMemberNum);
			}

			logger.info("{}{}DBSCR_00 : Query setSecurityCodeDataSql = {}", sClassName, sMethodName,
					setSecurityCodeDataSql);

			logger.info("{}{}DBSCR_01 : identification_type::PARAM 1 = {}", sClassName, sMethodName, identification_type);

			logger.info("{}{}DBSCR_02 : account_id::PARAM 2 = {}", sClassName, sMethodName, account_id);

			logger.info("{}{}DBSCR_03 : security_code::PARAM 3 = {}", sClassName, sMethodName, security_code);

			logger.info("{}{}DBSCR_04 : verification_failure_count::PARAM 4 = {}", sClassName, sMethodName,
					verification_failure_count);

			logger.info("{}{}DBSCR_05 : last_modified_by ::PARAM 5 = {}", sClassName, sMethodName, last_modified_by);

			logger.info("{}{}DBSCR_06 : security_code_status::PARAM 6 = {}", sClassName, sMethodName,
					security_code_status);

			if (sor_id != 0L) {
				logger.info("{}{}DBSCR_07 : sor_id::PARAM 7 = {}", sClassName, sMethodName, sor_id);
			} else {
				logger.info("{}{}DBSCR_07.1 : sor_id::PARAM 7 = null", sClassName, sMethodName);
			}
			if (sor_invariant_id != null) {
				logger.info("{}{}DBSCR_08 : sor_invariant_id::PARAM 8 = {}", sClassName, sMethodName, sor_invariant_id);
			} else {
				logger.info("{}{}DBSCR_08.1 : sor_invariant_id::PARAM 8 = null", sClassName, sMethodName);
			}
			if (slid_member_num != -1) {
				logger.info("{}{}DBSCR_09 : slid_member_num::PARAM 9 = {}", sClassName, sMethodName, slid_member_num);

			} else {
				logger.info("{}{}DBSCR_09.1 : slid_member_num::PARAM 9 = null", sClassName, sMethodName);
			}

			if (delivery_method != null) {
				logger.info("{}{}DBSCR_10 : delivery_method::PARAM 10 = {}", sClassName, sMethodName, delivery_method);
			} else {
				logger.info("{}{}DBSCR_10.1 : delivery_method::PARAM 10 = null", sClassName, sMethodName);
			}

			if (delivery_detail != null) {
				logger.info("{}{}DBSCR_11 : delivery_detail::PARAM 11 = {}", sClassName, sMethodName, delivery_detail);
			} else {
				logger.info("{}{}DBSCR_11.1 : " + "delivery_detail::PARAM 11 = null", sClassName, sMethodName);
			}

			if (source != null) {
				logger.info("{}{}DBSCR_12 : source::PARAM 12 = {}", sClassName, sMethodName, source);
			} else {
				logger.info("{}{}DBSCR_12.1 : source::PARAM 12 = null", sClassName, sMethodName);
			}
			if (passcode_venc != null) {
				logger.info("{}{}DBSCR_13 : passcode_venc::PARAM 13 = {}", sClassName, sMethodName, passcode_venc);
			} else {
				logger.info("{}{}DBSCR_13.1 : passcode_venc::PARAM 13 = null", sClassName, sMethodName);
			}

			Session hibSession = getSession();

			rowCount = hibSession.createNativeQuery(setSecurityCodeDataSql)
					.setParameter("identificationType",
							(StringUtils.isNotBlank(identification_type) ? identification_type.trim() : null))
					.setParameter("accountId", (StringUtils.isNotBlank(account_id) ? account_id : null))
					.setParameter("securityCode", (StringUtils.isNotBlank(security_code) ? security_code : null))
					.setParameter("verificationFailureCount", verification_failure_count)
					.setParameter("securityCodeExpires",
							DateUtil.getsecurityCodeExpiryTime(securityCodeExpirationTime,
									(String) InpParam.get(ProfileOrchestrationConstants.EXPIRY_TIME_UNIT)))
					.setParameter("securityCodeStatus",
							(StringUtils.isNotBlank(security_code_status) ? security_code_status : null))
					//.setParameter("statusChangeDate", now).setParameter("createDate", now)
					//.setParameter("lastModified", now)
					.setParameter("lastModifiedBy",
							(StringUtils.isNotBlank(last_modified_by) ? last_modified_by : null))
					.setParameter("source", (StringUtils.isNotBlank(source) ? source : "ONL"))
					.setParameter("sorId", sor_id != 0L ? sor_id : null)
					.setParameter("sorInvariantId",
							(StringUtils.isNoneBlank(sor_invariant_id) ? sor_invariant_id : null))
					.setParameter("slidMemberNum",slid_member_num != -1 ? slid_member_num : null)
					.setParameter("deliveryMethod", (StringUtils.isNoneBlank(delivery_method) ? delivery_method : null))
					.setParameter("deliveryDetail", (StringUtils.isNoneBlank(delivery_detail) ? delivery_detail : null))
					.setParameter("passcodeVenc", (StringUtils.isNoneBlank(passcode_venc) ? passcode_venc : null))
					.executeUpdate();

			logger.info("{}{}DBSCR_15 : rowCount = {}", sClassName, sMethodName, rowCount);
			resultHash = StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS,MPSDefs.MPS_ALL_OK,"0",MPSDefs.SQL_SUCCESS,MPSDefs.SQL_SUCCESS_MSG,Integer.toString(rowCount));
		} catch (Exception e) {
			if (e.getMessage().contains("ORA-00001: unique constraint")) {
				resultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ACCOUNT_ALREADY_EXISTS_NUM, CErrorDefs.ERR_ACCOUNT_ALREADY_EXISTS_MSG);
				logger.info("{}{}DBSCR_15a : resultHash :: {}",sClassName,sMethodName,resultHash);
				throw e;
			} else {
				resultHash = StatusMsg.makeExceptionSQLStatus(e);
				logger.error("{}{}DBSCRE_01 : " + " Error:: {}", sClassName, sMethodName, e.getMessage());
				logger.error("{}{}DBSCRE_02 : " + "Exception = {}", sClassName, sMethodName, e);
				throw e;
			}

		} finally {
			logger.info("{}{}DBTOOLS999 : response : {}", sClassName, sMethodName,resultHash);
		}
		return rowCount;
	}

	/**
	 * This method is used to retrieve the System of Record ID (SOR ID) based on the provided System of Record name (SOR name).
	 *
	 * @param sor_name The name of the System of Record. This is a String value.
	 * @return A Long value representing the SOR ID associated with the provided SOR name.
	 * @throws MPSException If there is an error while retrieving the SOR ID.
	 */
	public Long getSorId(String sor_name) throws MPSException {

		String sMethodName = ".getSorId.";
		Long sor_id = 0L;

		try {
			sor_id = systemOfRecordRepo.getSorId(sor_name);
		} catch (Exception e) {
			logger.info("{}{}DBTOOLS.EX : response : {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getSorId::" + e.getMessage());

		} finally {
			logger.info("{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, sor_id);
		}
		return sor_id;
	}
}