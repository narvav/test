package com.att.idp.idgraphcontactinfoms.db.model;

import java.sql.Date;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrimaryKeyJoinColumn;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "TMERGEDYAHOOID", schema = "MPS_OWNER", uniqueConstraints = @UniqueConstraint(columnNames = "YAHOO_ID"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tmergedyahooid implements java.io.Serializable {

	private static final long serialVersionUID = 1398685945816572860L;

	@Id
	@GenericGenerator(name = "generator", strategy = "foreign", parameters = @Parameter(name = "property", value = "tmember"))
	@GeneratedValue(generator = "generator")
	@Column(name = "MEMBER_NUM", unique = true, nullable = false, precision = 22, scale = 0)
	private Long memberNum;

	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	private Tmember tmember;

	@Column(name = "YAHOO_ID", unique = true, nullable = false, length = 200)
	private String yahooId;

	@Column(name = "ATT_MEMBER_ID", nullable = false, length = 200)
	private String attMemberId;

	@Column(name = "STATUS", nullable = false, length = 1)
	private char status;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;
}