package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TaccountlockoutId implements java.io.Serializable {

	private static final long serialVersionUID = 6510319188141656424L;

	@Column(name = "IDENTIFICATION_TYPE", nullable = false, length = 10)
	private String identificationType;

	@Column(name = "ACCOUNT_ID", nullable = false, length = 60)
	private String accountId;

	@Column(name = "LOCKOUT_ID", nullable = false, precision = 22, scale = 0)
	private Long lockoutId;

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TaccountlockoutId))
			return false;
		TaccountlockoutId castOther = (TaccountlockoutId) other;

		return ((this.getIdentificationType() == castOther.getIdentificationType())
				|| (this.getIdentificationType() != null && castOther.getIdentificationType() != null
						&& this.getIdentificationType().equals(castOther.getIdentificationType())))
				&& ((this.getAccountId() == castOther.getAccountId()) || (this.getAccountId() != null
						&& castOther.getAccountId() != null && this.getAccountId().equals(castOther.getAccountId())))
				&& ((this.getLockoutId() == castOther.getLockoutId()) || (this.getLockoutId() != null
						&& castOther.getLockoutId() != null && this.getLockoutId().equals(castOther.getLockoutId())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getIdentificationType() == null ? 0 : this.getIdentificationType().hashCode());
		result = 37 * result + (getAccountId() == null ? 0 : this.getAccountId().hashCode());
		result = 37 * result + (getLockoutId() == null ? 0 : this.getLockoutId().hashCode());
		return result;
	}

}
