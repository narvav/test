package com.att.idp.idgraphcontactinfoms.exceptions;

import java.io.Serializable;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.idp.idgraphcontactinfoms.model.ErrorMessage;
import com.att.mpsys.common.utils.CommonDefs;

/**
 * This is a custom exception class named InvalidInputDataException.
 *
 * It extends RuntimeException, which is a type of unchecked exception. Unchecked exceptions are exceptions that can be thrown during the execution of the program but they do not need to be declared in the method signature.
 *
 * It also implements Serializable, which is a marker interface that classes must implement if they need to be serialized and deserialized. Serialization is the process of converting an object's state to a byte stream, and deserialization is the process of creating an object from a byte stream.
 *
 * This class is meant to be used when there is invalid input data. It provides constructors to create an instance of the exception with a custom message, an ErrorMessage object, or a HashMap containing error information.
 */
public class InvalidInputDataException extends RuntimeException implements Serializable{

	private static final long serialVersionUID = -8606161666751198322L;
	
	public static final Logger logger = LoggerFactory.getLogger(InvalidInputDataException.class);

	/**
	 * This is an instance variable of the InvalidInputDataException class.
	 *
	 * It is of type ErrorMessage, which is a custom class used to represent error messages.
	 * This variable is used to store the error message associated with an instance of InvalidInputDataException.
	 * It is initialized in the constructor of the InvalidInputDataException class that takes a String and an ErrorMessage as parameters.
	 * If the other constructors of the InvalidInputDataException class are used to create an instance of the class, this variable is not initialized.
	 */
	public ErrorMessage errorMessage;
	
	/**
	 * This is an instance variable of the InvalidInputDataException class.
	 *
	 * It is of type Map, which is a data structure used to store key-value pairs.
	 * This variable is used to store the error information associated with an instance of InvalidInputDataException.
	 * It is initialized in the constructor of the InvalidInputDataException class that takes a Map as a parameter.
	 * If the other constructors of the InvalidInputDataException class are used to create an instance of the class, this variable is not initialized.
	 */
	public Map errorHashMap;
	
	/**
	 * This is a constructor for the InvalidInputDataException class.
	 *
	 * It takes one parameter: message. message is a String that represents the detail message. The detail message is saved for later retrieval by the Throwable.getMessage() method.
	 *
	 * When an instance of InvalidInputDataException is created using this constructor, the detail message is set to the provided message, but the ErrorMessage object and the errorHashMap are not initialized.
	 *
	 * @param message a String that represents the detail message.
	 */
	public InvalidInputDataException(String message){
		super(message);
	}
	
	/**
	 * This is a constructor for the InvalidInputDataException class.
	 *
	 * It takes two parameters: message and errorMessage. 
	 * message is a String that represents the detail message. The detail message is saved for later retrieval by the Throwable.getMessage() method.
	 * errorMessage is an ErrorMessage object that represents the error message.
	 *
	 * When an instance of InvalidInputDataException is created using this constructor, the detail message is set to the provided message, and the ErrorMessage object is set to the provided errorMessage. The errorHashMap is not initialized.
	 *
	 * @param message a String that represents the detail message.
	 * @param errorMessage an ErrorMessage object that represents the error message.
	 */
	public InvalidInputDataException(String message, ErrorMessage errorMessage){
		super(message);
		this.errorMessage = errorMessage;
//		logger.error(" InvalidInputDataException class :: " + errorMessage);
	}
	
	
	/**
	 * This is a constructor for the InvalidInputDataException class.
	 *
	 * It takes one parameter: hmResponse. hmResponse is a Map that represents the response HashMap.
	 *
	 * When an instance of InvalidInputDataException is created using this constructor, the detail message is set to the value associated with the key CommonDefs.COMMON_APP_STATUS_MSG in the provided HashMap, and the errorHashMap is set to the provided HashMap. The ErrorMessage object is not initialized.
	 *
	 * @param hmResponse a Map that represents the response HashMap.
	 */
	public InvalidInputDataException(Map hmResponse){
		super((String)hmResponse.get(CommonDefs.COMMON_APP_STATUS_MSG));
		this.errorHashMap = hmResponse;
		
		//this.errorMessage = errorMessage;
	}

}
