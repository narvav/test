package com.att.idp.idgraphcontactinfoms.resource;

import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import com.att.idp.idgraphcontactinfoms.resource.request.InquirePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.InquirePINResponse;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.web.bind.annotation.RequestBody;

import com.att.idp.idgraphcontactinfoms.exceptions.MPSException;
import com.att.idp.idgraphcontactinfoms.resource.request.DeletePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.request.GeneratePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.request.ValidatePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.DeletePinResponse;
import com.att.idp.idgraphcontactinfoms.resource.response.GeneratePINResponse;
import com.att.idp.idgraphcontactinfoms.resource.response.ValidatePINResponse;

import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;


/**
 * This is the Interface definition for SecurityPINResource.
 *
 * It uses the JAX-RS annotations to define the HTTP methods, paths, consumed and produced media types.
 * It also uses the Swagger annotations to provide metadata about the API such as the API's name, path, operations, responses.
 *
 * The interface has three main methods: generatePIN, deletePin, and validatePIN.
 * Each of these methods takes specific request objects as input and returns a Response.
 * These methods are annotated with @POST, @Path, @Consumes, @Produces, @ApiOperation, @ApiResponses to define their HTTP method, path, consumed and produced media types, operation description, responses.
 * The methods also throw MPSException that can occur during the execution of the methods.
 */
@Tag(name = "SecurityPin")
@Path("/pin")
@Produces({ MediaType.APPLICATION_JSON })
public interface SecurityPINResource {
	
	/**
	 * This method is responsible for generating a security PIN.
	 *
	 * It takes a GeneratePINRequest object and HttpHeaders as input parameters and returns a Response.
	 * The method is annotated with @POST, @Path, @Consumes, @Produces, @ApiOperation, @ApiResponses to define its HTTP method, path, consumed and produced media types, operation description, responses.
	 * The method also throws MPSException that can occur during the execution of the method.
	 *
	 * @param generatePINRequest GeneratePINRequest object that contains the request data for the "Generate PIN" operation.
	 * @param httpHeader HttpHeaders that contains the HTTP headers for the request.
	 * @return a Response that contains the result of the operation. If the operation is successful, the response contains a success message. If the operation fails, the response contains an error message.
	 * @throws MPSException if there is an exception in the application.
	 */
	@POST
	@Path("/generate")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Generate PIN", description =  "Generates Security PIN",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = GeneratePINResponse.class))),
			                @ApiResponse(responseCode = "400", description =  "Bad Request"),
			                @ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	
	Response generatePIN(@Valid @RequestBody GeneratePINRequest generatePINRequest, @Context HttpHeaders httpHeader) throws MPSException;
	
	/**
	 * This method is responsible for deleting a security PIN.
	 *
	 * It takes a DeletePINRequest object and HttpHeaders as input parameters and returns a Response.
	 * The method is annotated with @POST, @Path, @Consumes, @Produces, @ApiOperation, @ApiResponses to define its HTTP method, path, consumed and produced media types, operation description, responses.
	 * The method also throws MPSException that can occur during the execution of the method.
	 *
	 * @param deletePINRequest DeletePINRequest object that contains the request data for the "Delete PIN" operation.
	 * @param httpHeader HttpHeaders that contains the HTTP headers for the request.
	 * @return a Response that contains the result of the operation. If the operation is successful, the response contains a success message. If the operation fails, the response contains an error message.
	 * @throws MPSException if there is an exception in the application.
	 */
	@POST
	@Path("/delete")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Delete Pin", description =  "Delete Pin from the MPSYS system",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = DeletePinResponse.class))),
			@ApiResponse(responseCode = "400", description =  "Bad Request"),
			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	Response deletePin(@Valid @RequestBody DeletePINRequest deletePINRequest, @Context HttpHeaders httpHeader)
			throws MPSException;
	
	
	/**
	 * This method is responsible for validating a security PIN.
	 *
	 * It takes a ValidatePINRequest object and HttpHeaders as input parameters and returns a Response.
	 * The method is annotated with @POST, @Path, @Consumes, @Produces, @ApiOperation, @ApiResponses to define its HTTP method, path, consumed and produced media types, operation description, responses.
	 * The method also throws MPSException that can occur during the execution of the method.
	 *
	 * @param validatePINRequest ValidatePINRequest object that contains the request data for the "Validate PIN" operation.
	 * @param httpHeader HttpHeaders that contains the HTTP headers for the request.
	 * @return a Response that contains the result of the operation. If the operation is successful, the response contains a success message. If the operation fails, the response contains an error message.
	 * @throws MPSException if there is an exception in the application.
	 */
	@POST
	@Path("/validate")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Validate Pin", description =  "Validate Pin from the MPSYS system",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = ValidatePINResponse.class))),
			@ApiResponse(responseCode = "400", description =  "Bad Request"),
			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	Response validatePIN(@RequestBody ValidatePINRequest validatePINRequest, @Context HttpHeaders httpHeader)
			throws MPSException;
	
	
	
	@POST
	@Path("/inquire")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Inquire Pin", description =  "inquire Pin from the MPSYS system",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = InquirePINResponse.class))),
			@ApiResponse(responseCode = "400", description =  "Bad Request"),
			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	Response inquirePin(@Valid @RequestBody InquirePINRequest inquirePINRequest, @Context HttpHeaders httpHeader)
			throws MPSException;

	}
