package com.att.idp.idgraphcontactinfoms.resource.response;

import com.att.idp.core.exception.ServiceError;
import com.att.idp.idgraphcontactinfoms.model.Individual;
import com.fasterxml.jackson.annotation.*;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
/**
 * The class CPNIContactInfoResponse
 *
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "CPNIContactInfoResponse")
public class CPNIContactInfoResponse {
    @JsonIgnore
    protected final String transactionName = "CPNIContactInfo";
    private String idpTraceId;
    @JsonIgnore
    private String appInfo;
    @JsonIgnore
    private String appCategoryCode;
    private ServiceError errors;
    private Individual individual;

    @JsonProperty("error")
    public void setErrors(ServiceError errors) {
        this.errors = errors;
    }

    @JsonProperty("idp-trace-id")
    public void setIdpTraceId(String idpTraceId) {
        this.idpTraceId = idpTraceId;
    }

    private static final long serialVersionUID = 1L;


}
