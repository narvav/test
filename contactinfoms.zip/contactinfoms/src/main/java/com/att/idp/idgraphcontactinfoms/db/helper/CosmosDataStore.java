package com.att.idp.idgraphcontactinfoms.db.helper;

import java.time.Instant;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.idp.idgraphcontactinfoms.cassandra.entity.SessionId;
import com.att.idp.idgraphcontactinfoms.cassandra.entity.ValidatePinAuthInfo;
import com.att.idp.idgraphcontactinfoms.cassandra.repository.ValidatePinAuthInfoRepository;
import com.att.idp.idgraphcontactinfoms.exceptions.MPSException;
import com.att.idp.idgraphcontactinfoms.helpers.GeneratePINBase;


/**
 * This class implements the PersistValidatePinDataInterface and provides functionality for persisting ValidatePin Info data to a Cosmos database.
 * It contains a method for persisting ValidatePin Info data to the database.
 * The class uses the ValidatePinAuthInfoRepository for interacting with the Cosmos database.
 * It also uses the SessionId and ValidatePinInfo entities for representing the data to be persisted.
 * The class is annotated with @Service, meaning it is a Spring Bean and can be autowired into other classes.
 */
@Service
public class CosmosDataStore implements PersistValidatePinDataInterface {

	@Autowired
	private ValidatePinAuthInfoRepository validatePinAuthInfoRepository;

	private static String sClassName = "CosmosDataStore";
	public static final Logger logger = LoggerFactory.getLogger(GeneratePINBase.class);

	/**
	 * Default constructor for the CosmosDataStore class.
	 * This constructor does not take any parameters and does not perform any operations.
	 * It is used to create an instance of the CosmosDataStore class.
	 */
	public CosmosDataStore() {
		super();
	}

	@Override
	public void PersistValidatePinInfoToDatabase(ValidatePinInfoBean bean ) throws MPSException {

		String sMethodName = ".PersistValidateCredentialsDataToDatabase";

		logger.info("{}{}CDS_01 PersistValidateCredentialsDataToDatabase_START: {}", sClassName, sMethodName, StringUtils.normalizeSpace(bean.getSessionId()));
		try {
			if (null != bean && StringUtils.isNotBlank(bean.getSessionId())) {

				SessionId sid = new SessionId(bean.getSessionId());
				ValidatePinAuthInfo validatePinAuthInfo = new ValidatePinAuthInfo(sid);
				validatePinAuthInfo.setCreatedDate(Date.from(Instant.now()));
				validatePinAuthInfo.setAccountNumber(bean.getAccountNumber());
				validatePinAuthInfo.setAccountType(bean.getAccountType());
				validatePinAuthInfo.setAuthMethod(bean.getAuthenticationMethod());
				validatePinAuthInfo.setChannel(bean.getChannel());
				validatePinAuthInfo.setStatus(bean.getStatus());
				validatePinAuthInfo.setFailureReason(bean.getFailureReason());
				validatePinAuthInfo.setEmailAddress(bean.getEmailAddress());
				validatePinAuthInfo.setPhoneNumber(bean.getPhoneNumber());
				
				validatePinAuthInfoRepository.save(validatePinAuthInfo);
				logger.debug("{}{}CDS_02 Updated CosmosDB for sessionId: {}", sClassName, sMethodName, StringUtils.normalizeSpace(bean.getSessionId()));
			}
		} catch(Exception e) {

			logger.error("{}{}CDS_03 Exception while saving validatePinAuthInfo to cosmosDB {}", sClassName, sMethodName, e.getMessage());
			throw new MPSException("Exception in CosmosDBHelper::" + e.getMessage());
		}
	}

	
}