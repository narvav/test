package com.att.idp.idgraphcontactinfoms.kafka.config;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

@Configuration
public class GenericOTPPublisherSecondaryConfig {
	
	public static final Logger logger = LoggerFactory.getLogger(GenericOTPPublisherSecondaryConfig.class);

    @Value(value = "${genericotp.azureeventhub.publisher.key.serializer}")
    private String keySerializer;

    @Value(value = "${genericotp.azureeventhub.publisher.value.serializer}")
    private String valueSerializer;

    @Value(value = "${genericotp.azureeventhub.secondary.publisher.client.id}")
    private String clientId;

    @Value(value = "${genericotp.azureeventhub.publisher.jaas.enabled}")
    private String jaasEnabled;

    @Value(value = "${genericotp.azureeventhub.publisher.security.protocol}")
    private String securityProtocol;

    @Value(value = "${genericotp.azureeventhub.publisher.sasl.mechanism}")
    private String saslMechanism;

    @Value(value = "${genericotp.azureeventhub.secondary.publisher.bootstrap.servers}")
    private String genericotpKafkaBootstrapServer;

    @Value(value = "${genericotp.azureeventhub.secondary.publisher.jaas.endpoint}")
    private String genericotpKafkaJaasEndpoint;

    @Value(value = "${genericotp.azureeventhub.secondary.publisher.jaas.sharedaccesskeyname}")
    private String genericotpKafkaJaasSharedAccessKeyName;

    @Value(value = "${genericotp.azureeventhub.secondary.publisher.jaas.sharedaccesskey}")
    private String genericotpKafkaJaasSharedAccessKey;

    @Value(value = "${genericotp.azureeventhub.secondary.publisher.topic}")
    private String genericotpTopicname;

    @Value(value = "${genericotp.azureeventhub.publisher.default.maxblockmsconfig:2000}")
    private String maxBlockMsConfig;


    @Bean("secondaryGOTPProducerFactory")
    public ProducerFactory<String, Object> secondaryGOTPProducerFactory() {
        Map<String, Object> producerConfig = new HashMap<>();
        String saslJaasConfigStr = "org.apache.kafka.common.security.plain.PlainLoginModule required "
                + "username='$ConnectionString'" + " password='Endpoint=" + genericotpKafkaJaasEndpoint
                + ";SharedAccessKeyName=" + genericotpKafkaJaasSharedAccessKeyName + ";SharedAccessKey="
                + genericotpKafkaJaasSharedAccessKey + ";EntityPath=" + genericotpTopicname + "';";
        producerConfig.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, genericotpKafkaBootstrapServer);
        producerConfig.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, keySerializer);
        producerConfig.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        producerConfig.put(ProducerConfig.CLIENT_ID_CONFIG, clientId);
        producerConfig.put("sasl.jaas.config", saslJaasConfigStr);
        producerConfig.put("security.protocol", securityProtocol);
        producerConfig.put("sasl.mechanism", saslMechanism);
        producerConfig.put(ProducerConfig.RETRIES_CONFIG, 3);
        producerConfig.put(ProducerConfig.MAX_BLOCK_MS_CONFIG,maxBlockMsConfig);
        producerConfig.put(ProducerConfig.RETRY_BACKOFF_MS_CONFIG,3000);
        return new DefaultKafkaProducerFactory<>(producerConfig);
    }

    @Bean("secondaryGOTPKafkaTemplate")
    public KafkaTemplate<String, Object> kafkaTemplate() {
        KafkaTemplate<String, Object> kafkaTemplate = new KafkaTemplate<String, Object>(secondaryGOTPProducerFactory());
        return kafkaTemplate;
    }

}
