package com.att.idp.idgraphcontactinfoms.db.model;

import java.sql.Date;
import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "TMEMBERFRAUDPASSWORD", schema = "MPS_OWNER")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tmemberfraudpassword implements java.io.Serializable {

	private static final long serialVersionUID = 9161224460001100303L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "memberNum", column = @Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "fraudCounter", column = @Column(name = "FRAUD_COUNTER", nullable = false, precision = 22, scale = 0))
	})
	private TmemberfraudpasswordId id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MEMBER_NUM", nullable = false, insertable = false, updatable = false)
	private Tmember tmember;

	@Column(name = "PASSWORD_TYPE", nullable = false, length = 10)
	private String passwordType;

	@Column(name = "PASSWORD_VENC", nullable = false, length = 512)
	private String passwordVenc;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", nullable = false, length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;
}