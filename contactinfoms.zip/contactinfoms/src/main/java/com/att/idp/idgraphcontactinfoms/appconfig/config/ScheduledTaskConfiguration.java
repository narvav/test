package com.att.idp.idgraphcontactinfoms.appconfig.config;

import com.azure.spring.cloud.appconfiguration.config.AppConfigurationRefresh;
import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

// ...existing code...

/**
 * Configuration class for scheduling tasks.
 */
@Configuration
@EnableScheduling
public class ScheduledTaskConfiguration {

    private static final String TASK_NAME_SCHEDULED_APP_CONFIG_PRINTER = "scheduledAppConfigPrinter";
    private static final Logger logger = LoggerFactory
            .getLogger(ScheduledTaskConfiguration.class.getName() + "." + TASK_NAME_SCHEDULED_APP_CONFIG_PRINTER);

    private final IDGraphAzureAppConfig appConfiguration;

    private final AppConfigurationRefresh appConfigurationRefresh;

    /**
     * Constructor for ScheduledTaskConfiguration.
     *
     * @param appConfiguration          the application configuration properties
     * @param appConfigurationRefresh   the App Configuration refresh helper
     */
    public ScheduledTaskConfiguration(IDGraphAzureAppConfig appConfiguration,
                                      AppConfigurationRefresh appConfigurationRefresh) {
        this.appConfiguration = appConfiguration;
        this.appConfigurationRefresh = appConfigurationRefresh;
    }
    // Track previous state to log only on configuration changes
    private volatile String lastConfigSnapshot = "";


    /**
     * Scheduled task that refreshes App Configuration and logs a sanitized
     * snapshot when configuration values change.
     */
    @Scheduled(initialDelayString = "30000", fixedDelayString = "30000")
    public void doScheduledAppConfigPrinter() {
        appConfigurationRefresh.refreshConfigurations();
        String currentSnapshot = buildConfigSnapshot();
        if (!currentSnapshot.equals(lastConfigSnapshot)) {
            logger.info("App Configuration changed. Details: {}", currentSnapshot);

            lastConfigSnapshot = currentSnapshot;
        }
    }
    /**
     * Builds a string representation of the current configuration state for change detection.
     * All values are encoded with ESAPI to avoid log injection.
     *
     * @return Configuration state as a formatted string
     */
    private String buildConfigSnapshot() {
        return String.format(
                "appconfig.version [%s], connTimeout [%s], maxSize [%s], queryTimeout [%s], validationQuery [%s], initialSize [%s], testWhileIdle [%s], testOnBorrow [%s], evictTime [%s], minSize [%s], inquireprofilerestclientConnectTimeout [%s], inquireprofilerestclientReadTimeout [%s], ccmulesoftConnectTimeout [%s], ccmulesoftReadTimeout [%s], cgConnectTimeout [%s], cgReadTimeout [%s], mqReconnectTimeoutSec [%s], bdsConnectTimeout [%s], bdsReadTimeout [%s], lscrmConnectTimeout [%s], lscrmReadTimeout [%s], dataSourceRefreshEnabled [%s], mqconnectRefreshEnabled [%s], ccmulesoftRestClientRefreshEnabled [%s], inquireRestClientRefreshEnabled [%s], cgRestClientRefreshEnabled [%s], lscrmSoapHttpClientRefreshEnabled [%s], profileConnectTimeout [%s], profileReadTimeout [%s], profileRestClientRefreshEnabled [%s]",
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getVersion())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getConnTimeout())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getMaxSize())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getQueryTimeout())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getValidationQuery())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getInitialSize())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.isTestWhileIdle())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.isTestOnBorrow())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getEvictTime())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getMinSize())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getInquireprofilerestclientConnectTimeout())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getInquireprofilerestclientReadTimeout())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getCcmulesoftConnectTimeout())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getCcmulesoftReadTimeout())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getCgConnectTimeout())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getCgReadTimeout())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getMqReconnectTimeoutSec())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getBdsConnectTimeoutSec())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getBdsReadTimeoutSec())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getLscrmConnectTimeout())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getLscrmReadTimeout())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.isDataSourceRefreshEnabled())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.isMqconnectRefreshEnabled())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.isCcmulesoftRestClientRefreshEnabled())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.isInquireRestClientRefreshEnabled())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.isCgRestClientRefreshEnabled())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.isLscrmSoapHttpClientRefreshEnabled())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getProfileConnectTimeout())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.getProfileReadTimeout())),
                StringEscapeUtils.escapeJava(String.valueOf(appConfiguration.isProfileRestClientRefreshEnabled()))
        );
    }

}
