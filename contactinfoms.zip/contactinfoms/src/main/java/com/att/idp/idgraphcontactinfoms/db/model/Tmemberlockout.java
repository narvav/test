package com.att.idp.idgraphcontactinfoms.db.model;

import java.sql.Date;
import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "TMEMBERLOCKOUT", schema = "MPS_OWNER")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tmemberlockout implements java.io.Serializable {

	private static final long serialVersionUID = 711031964161404704L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "memberNum", column = @Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "lockoutId", column = @Column(name = "LOCKOUT_ID", nullable = false, precision = 22, scale = 0))
	})
	private TmemberlockoutId id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "LOCKOUT_ID", referencedColumnName = "LOCKOUT_ID", insertable = false, updatable = false),
			@JoinColumn(name = "SET_NUMBER", referencedColumnName = "SET_NUMBER", insertable = false, updatable = false)
	})
	private Tlockoutconfig tlockoutconfig;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MEMBER_NUM", nullable = false, insertable = false, updatable = false)
	private Tmember tmember;

	@Column(name = "FAILED_AUTH_COUNT", precision = 22, scale = 0)
	private Long failedAuthCount;

	@Column(name = "LOCKOUT_EXPIRATION", length = 7)
	private Date lockoutExpiration;

	@Column(name = "LAST_FAILED_AUTH", length = 7)
	private Date lastFailedAuth;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;
}