package com.att.idp.idgraphcontactinfoms.db.helper;

import com.att.idp.idgraphcontactinfoms.db.model.Tsecurityaccount;
import com.att.idp.idgraphcontactinfoms.db.repository.IDGraphContactInfoCustomRepository;
import com.att.idp.idgraphcontactinfoms.db.repository.InquireAccountContactInfoRepositoryCustom;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
/**
 * HealthCheckDBHelper is a helper class responsible for performing database health checks
 * in the application. It extends the IDGraphContactInfoCustomRepository to provide custom
 * database operations for the Tsecurityaccount entity.
 *
 * This class uses the JdbcTemplate for database interactions and provides a method to
 * verify the availability of the database by executing a simple query.
 */
@Component
public class HealthCheckDBHelper extends IDGraphContactInfoCustomRepository<Tsecurityaccount, Long> {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    private static final Logger logger = LoggerFactory.getLogger(HealthCheckDBHelper.class);

    /**
     * Performs a health check on the database by executing a simple query.
     *
     * @return true if the database is up and the query executes successfully, false otherwise.
     */
    public boolean dbHealthCheck() {
        boolean isDatabaseUp = false;
        try {
            String selectStatement = "SELECT 1 FROM DUAL";
            List<Object[]> queryResponse = getSession().createNativeQuery(selectStatement).list();
            if (queryResponse != null && !queryResponse.isEmpty()) {
                logger.debug("Performing scheduled db health check - Database is UP");
                isDatabaseUp = true;
            }
        } catch (Exception e) {
            logger.error("DB Health Check failed", e);
        }
        return isDatabaseUp;
    }

}