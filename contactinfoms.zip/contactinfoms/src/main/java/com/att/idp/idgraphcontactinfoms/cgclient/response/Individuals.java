package com.att.idp.idgraphcontactinfoms.cgclient.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

/**
 * The Individuals class represents an individual in the system.
 * It implements the Serializable interface, which means its instances can be converted to a byte stream and
 * restored back to the same object later. This is useful for storing objects in a file or sending them over a network.
 *
 * This class contains various properties related to an individual such as givenName, familyName, contactMedium, accounts, products, contracts, installments, and subscribers.
 * Each property has its corresponding getter and setter methods.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.cgclient.response package.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(name = "Individuals")
@Getter
@Setter
@NoArgsConstructor
public class Individuals implements Serializable {

	private static final long serialVersionUID = -1363670046010762896L;

	@JsonProperty("givenName")
	private String givenName;

	@JsonProperty("familyName")
	private String familyName;

	@JsonProperty("contactMedium")
	private List<ContactMedium> contactMedium;

	@JsonProperty("accounts")
	private List<Accounts> accounts;

	@JsonProperty("products")
	private List<Products> products;

	@JsonProperty("contracts")
	private List<Contracts> contracts;

	@JsonProperty("installments")
	private List<Installments> installments;

	@JsonProperty("subscribers")
	private List<Subscribers> subscribers;
}