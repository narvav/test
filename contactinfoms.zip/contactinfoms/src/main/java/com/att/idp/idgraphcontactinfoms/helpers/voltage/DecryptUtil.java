package com.att.idp.idgraphcontactinfoms.helpers.voltage;

 

import com.voltage.securedata.enterprise.VeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.idp.core.exception.ServiceException;
import com.att.idp.idgraphcontactinfoms.message.ErrorMessages;
import com.att.idp.voltage.common.VoltageEfpeFormatType;
import com.att.idp.voltage.decrypt.api.DecryptorVoltageHelper;
import com.att.idp.voltage.decrypt.api.VoltageDecryptorAutoConfiguration;

/**
 * This class is used for decryption utilities.
 *
 * It contains methods for decrypting values using the VoltageEfpeFormatType format.
 * The class interacts with the DecryptorVoltageHelper to perform the decryption.
 * It also handles exceptions that may occur during the decryption process.
 *
 * The class is annotated with @Component, indicating that it is an autodetectable bean and can be automatically
 * picked up and instantiated by Spring's container.
 */
@Component
public class DecryptUtil {


	
	private static final Logger log = LoggerFactory.getLogger(DecryptUtil.class);
	
	private static DecryptorVoltageHelper volHelper=null;	
	
	/**
	 * Constructor for the DecryptUtil class.
	 *
	 * It takes a VoltageDecryptorAutoConfiguration object as input which is autowired by Spring's container.
	 * The constructor initializes the DecryptorVoltageHelper instance for default identity.
	 *
	 * @param pVDAC An autowired VoltageDecryptorAutoConfiguration object.
	 */
	public DecryptUtil(@Autowired VoltageDecryptorAutoConfiguration pVDAC) throws VeException {
		volHelper = DecryptorVoltageHelper.getInstanceForDefaultIdentity();
	
}

	/**
	 * This method is used to decrypt a value.
	 *
	 * It takes two Strings as input - the value to be decrypted and the format name.
	 * The method uses the DecryptorVoltageHelper to decrypt the value using the specified format.
	 * The decrypted value is then returned as a String.
	 *
	 * The method handles exceptions that may occur during the decryption process and logs an error message.
	 * If an exception occurs, a ServiceException is thrown with an appropriate error message.
	 *
	 * @param value A String containing the value to be decrypted.
	 * @param formatName A String containing the name of the format to be used for decryption.
	 * @return A String containing the decrypted value.
	 * @throws ServiceException if an error occurs during the decryption process.
	 */
public  String getDecryptedValue(String value, String formatName) {
	try {	
		
		return volHelper.decrypt(value, VoltageEfpeFormatType.valueOf(formatName));			
		 
		} catch(Exception e) {
			log.error("Error while getting voltage resource", e);
			throw new ServiceException(ErrorMessages.ERROR_VOLTAGE_RESOURCE); 
		}

	}
}
