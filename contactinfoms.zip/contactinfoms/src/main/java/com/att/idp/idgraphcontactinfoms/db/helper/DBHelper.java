package com.att.idp.idgraphcontactinfoms.db.helper;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphcontactinfoms.exceptions.MPSException;
import com.att.mpsys.common.utils.MPSDefs;


/**
 * DBHelper is a class that extends MPSDefs. It contains helper methods for components
 * that access MPS databases. It uses Spring's JdbcTemplate to execute SQL queries.
 * 
 * It provides methods to fetch and manipulate data related to various entities like
 * domain, member, contact, group, system of record, service, network access, and status.
 * 
 * It also provides methods to fetch the next sequence values for member, contact, and group.
 * 
 * Each method in this class throws an MPSException in case of any error during the database operation.
 * 
 * This class is annotated with @Component, indicating that an instance of this class will be created by Spring.
 */
@Component
public class DBHelper extends MPSDefs {
	
	public static final Logger logger = LoggerFactory.getLogger(DBHelper.class);
	private static String sClassName = "DBHelper";

	@Autowired 
	private JdbcTemplate jdbcTemplate;
	
	private static String wtnQuery =
		"SELECT mem.member_name, dom.domain_name "
			+ "FROM MEMBER mem, DOMAIN dom, DSLUSER dslUser "
			+ "WHERE mem.domain_id = dom.domain_id AND "
			+ "mem.member_num= dslUser.member_num AND "
			+ "mem.parent_child_ind='P' AND "
			+ "dslUser.wtn = ?";

	/**
	 * 
	 * @param conn
	 * @return long
	 * @throws SQLException
	 */
	public long getNextMemberId()
		throws MPSException {

		return getNextId("member_num_seq");
	} 
	
	/**
	 * 
	 * @return long
	 * @throws MPSException
	 */
	public long getNextContactId() 
			throws MPSException { 
		return getNextId("contact_seq"); 
	}
	
	/**
	 * 
	 * @param conn
	 * @return long
	 * @throws SQLException
	 */
	public long getNextMemberGroupId()
		throws MPSException {

		return getNextId("group_num_seq");
	} 

	/**
	 * This method is used to get the domain id from the database.
	 * It executes a SQL query to fetch the domain id for the given domain name.
	 *
	 * @param domain_name The name of the domain for which the id is to be fetched.
	 * @return int The id of the domain.
	 * @throws MPSException If there is an error during the database operation.
	 */
	public int getDomainId(String domain_name)
		throws MPSException {
		
		String sMethodName = ".getDomainId.";
		String selectStatement = "SELECT domain_id FROM domain WHERE domain_name = ?";
		
		int domain_id = 0;
		
		List<Object> objectList = new ArrayList<Object>();

		try {
			
			objectList.add(domain_name);
						
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement), objectList.toArray(new Object[objectList.size()]));
			
			for(int j=0; j<alQueryResponse.size(); j++){
            	Map hmQueryResponse = (Map)alQueryResponse.get(j);
            	domain_id = Integer.parseInt(hmQueryResponse.get(MPSDefs.DB_DOMAIN_ID).toString());
			}

		} catch (Exception e) {
			logger.info("{}{}DBH_GDI.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getDomainId::" + e.getMessage());

		} finally {
			
			
		}
		return domain_id;
	} 
	
	
	/**
	 * This method is used to get the domain name from the database.
	 * It executes a SQL query to fetch the domain name for the given domain id.
	 *
	 * @param domain_id The id of the domain for which the name is to be fetched.
	 * @return String The name of the domain.
	 * @throws MPSException If there is an error during the database operation.
	 */
	public String getDomainName(String domain_id)
		throws MPSException {
		
		String sMethodName = ".getDomainName.";
		String selectStatement = "SELECT domain_name FROM domain WHERE domain_id = ?";
		
		String domain_name = "";
		List<Object> objectList = new ArrayList<Object>();

		try {
			objectList.add(domain_id);
			
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement), objectList.toArray(new Object[objectList.size()]));
			
			for(int j=0; j<alQueryResponse.size(); j++){
            	Map hmQueryResponse = (Map)alQueryResponse.get(j);
            	domain_name = (String)hmQueryResponse.get(MPSDefs.DB_DOMAIN_NAME);
			}

		} catch (Exception e) {
			logger.info("{}{}DBH_GDN.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getDomainName::" + e.getMessage());

		} finally {
			
			
		}
		return domain_name;
	} 	
	
	/**
	 * This method is used to get the System of Record (SOR) id from the database.
	 * It executes a SQL query to fetch the SOR id for the given SOR name.
	 *
	 * @param sor_name The name of the System of Record for which the id is to be fetched.
	 * @return int The id of the System of Record.
	 * @throws MPSException If there is an error during the database operation.
	 */
	public int getSorId(String sor_name)
		throws MPSException {
		
		String sMethodName = ".getSorId.";
		String stAppInfo = null;
		String selectStatement = "SELECT sor_id FROM systemofrecord WHERE sor_name = ?";
		
		int sor_id = 0;
		List<Object> objectList = new ArrayList<Object>();

		try {

			objectList.add(sor_name);
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement), objectList.toArray(new Object[objectList.size()]));
			
			for(int j=0; j<alQueryResponse.size(); j++){
            	Map hmQueryResponse = (Map)alQueryResponse.get(j);
            	sor_id = Integer.parseInt(hmQueryResponse.get(MPSDefs.DB_SOR_ID).toString());
			}
			
		} catch (Exception e) {
			logger.info("{}{}DBH_GSI.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getSorId::" + e.getMessage());

		} finally {
			
		}
		return sor_id;
	} 
	
	
	
	/**
	 * This method is used to get the System of Record (SOR) name from the database.
	 * It executes a SQL query to fetch the SOR name for the given SOR id.
	 *
	 * @param sor_id The id of the System of Record for which the name is to be fetched.
	 * @return String The name of the System of Record.
	 * @throws MPSException If there is an error during the database operation.
	 */
	public String getSorName(String sor_id)
		throws MPSException {
		String sMethodName = ".getSorName.";
		String selectStatement = "SELECT sor_name FROM systemofrecord WHERE sor_id = ?";
		String sor_name = "";
		List<Object> objectList = new ArrayList<Object>();

		try {
			objectList.add(sor_id);
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement), objectList.toArray(new Object[objectList.size()]));
			
			for(int j=0; j<alQueryResponse.size(); j++){
            	Map hmQueryResponse = (Map)alQueryResponse.get(j);
            	sor_name = (String)hmQueryResponse.get(MPSDefs.DB_SOR_NAME);
			}
			
		} catch (Exception e) {
			logger.info("{}{}DBH_GSN.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getSorName::" + e.getMessage());

		} finally {
			
		}
		return sor_name;
	} 
	
	
	
	/**
	 * This method is used to get the Security Question id from the database.
	 * It executes a SQL query to fetch the Security Question id for the given Security Question.
	 *
	 * @param sSecurityQuestion The Security Question for which the id is to be fetched.
	 * @return int The id of the Security Question.
	 * @throws MPSException If there is an error during the database operation.
	 */
	public int getSecurityQuestionId(String sSecurityQuestion)
			throws MPSException {
				
		    String sMethodName = ".getSecurityQuestionId.";
			if (sSecurityQuestion != null && sSecurityQuestion.length() > 80) {
				sSecurityQuestion = sSecurityQuestion.substring(0, 80);
			}
			String selectStatement = "SELECT security_question_id FROM SecurityQuestion WHERE SUBSTR(TRIM(LOWER(security_question)), 1, 80) = TRIM(LOWER(?))";
				
			List<Object> objectList = new ArrayList<Object>();
			int iSecurityQuestionId = -1;

			try {
				
				objectList.add(sSecurityQuestion);
				List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement), objectList.toArray(new Object[objectList.size()]));
				
				for(int j=0; j<alQueryResponse.size(); j++){
	            	Map hmQueryResponse = (Map)alQueryResponse.get(j);
	            	iSecurityQuestionId = Integer.parseInt(hmQueryResponse.get(MPSDefs.DB_SECURITY_QUESTION_ID).toString());
				}

			} catch (Exception e) {
				logger.info("{}{}DBH_GSQI.01 : Exception occured {}", sClassName, sMethodName, e);
				throw new MPSException("DBHelper::getSecurityQuestionId::" + e.getMessage());
			} finally {
				
			}
			return iSecurityQuestionId;
		} // End getSecurityQuestionId

	private long getNextId(String sequence)
		throws MPSException {
		String sMethodName = ".getNextId.";
		String selectStatement = "SELECT " + sequence + ".NEXTVAL FROM dual";
		
		long id = 0;

		try {
			
			List alQueryResponse = jdbcTemplate.queryForList(selectStatement, String.class);
			
			id = Long.parseLong((String)alQueryResponse.get(0));
			
			if (id <= 0) {
				throw new MPSException("Sequence " + sequence + " is empty.");
			}
		} catch (Exception e) {
			logger.info("{}{}DBH_GNI.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getNextId::" + e.getMessage());

		} finally {
		
		}
		return id;
	} // getNextId
	
	
	/**
	 * This method is used to get the service id from the database.
	 * It executes a SQL query to fetch the service id for the given service name.
	 *
	 * @param service_name The name of the service for which the id is to be fetched.
	 * @return int The id of the service.
	 * @throws MPSException If there is an error during the database operation.
	 */
	public int getServiceId(String service_name) throws MPSException
		{
		String sMethodName = ".getServiceId.";
		String selectStatement = "SELECT service_id FROM service WHERE service_name = ?";
		
		int service_id = 0;
		List<Object> objectList = new ArrayList<Object>();

		try {

			objectList.add(service_name);
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement), objectList.toArray(new Object[objectList.size()]));
			
			for(int j=0; j<alQueryResponse.size(); j++){
            	Map hmQueryResponse = (Map)alQueryResponse.get(j);
            	service_id = Integer.parseInt(hmQueryResponse.get("service_id").toString());
			}
			
		} catch (Exception e) {
			logger.info("{}{}DBH_GSI.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getServiceId::" + e.getMessage());

		} finally {
			
		}
		return service_id;
	} // getServiceId
	
	
	
	/**
	 * This method is used to get the service name from the database.
	 * It executes a SQL query to fetch the service name for the given service id.
	 *
	 * @param service_id The id of the service for which the name is to be fetched.
	 * @return String The name of the service.
	 * @throws MPSException If there is an error during the database operation.
	 */
	public String getServiceName(String service_id) throws MPSException
		{
		String sMethodName = ".getServiceName.";
		String selectStatement = "SELECT service_name FROM service WHERE service_id = ?";
		List<Object> objectList = new ArrayList<Object>();
		String service_name = "";

		try {
			objectList.add(service_id);
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement), objectList.toArray(new Object[objectList.size()]));
			
			for(int j=0; j<alQueryResponse.size(); j++){
            	Map hmQueryResponse = (Map)alQueryResponse.get(j);
            	service_name = (String)hmQueryResponse.get("service_name");
			}

		} catch (Exception e) {
			logger.info("{}{}DBH_GSN.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getServiceName::" + e.getMessage());

		} finally {
			
		}
		return service_name;
	} // getServiceName	
	
	
	/**
	 * This method is used to get the network access id from the database.
	 * It executes a SQL query to fetch the network access id for the given network access name.
	 *
	 * @param access_name The name of the network access for which the id is to be fetched.
	 * @return int The id of the network access.
	 * @throws MPSException If there is an error during the database operation.
	 */
	public int getAccessId(String access_name)
		throws MPSException {
		String sMethodName = ".getAccessId.";
		String selectStatement = "SELECT access_id FROM networkaccess WHERE access_name = ?";
		
		List<Object> objectList = new ArrayList<Object>();
		
		int access_id = 0;

		try {
			
			objectList.add(access_name);
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement), objectList.toArray(new Object[objectList.size()]));
			
			for(int j=0; j<alQueryResponse.size(); j++){
            	Map hmQueryResponse = (Map)alQueryResponse.get(j);
            	access_id = Integer.parseInt(hmQueryResponse.get("access_id").toString());
			}
			
		} catch (Exception e) {
			logger.info("{}{}DBH_GAI.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getAccessId::" + e.getMessage());

		} finally {
		
		}
		return access_id;
	} // getAccessId
	
	
	
	/**
	 * This method is used to get the network access name from the database.
	 * It executes a SQL query to fetch the network access name for the given network access id.
	 *
	 * @param access_id The id of the network access for which the name is to be fetched.
	 * @return String The name of the network access.
	 * @throws MPSException If there is an error during the database operation.
	 */
	public String getAccessName(String access_id)
		throws MPSException {
		String sMethodName = ".getAccessName.";
		String selectStatement = "SELECT access_name FROM networkaccess WHERE access_id = ?";
		List<Object> objectList = new ArrayList<Object>();
		
		String access_name = "";

		try {
			
			objectList.add(access_id);
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement), objectList.toArray(new Object[objectList.size()]));
			
			for(int j=0; j<alQueryResponse.size(); j++){
            	Map hmQueryResponse = (Map)alQueryResponse.get(j);
            	access_name = (String)hmQueryResponse.get("access_name");
			}
			
		} catch (Exception e) {
			logger.info("{}{}DBH_GAN.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException("DBHelper::getAccessName::" + e.getMessage());

		} finally {
		
		}
		return access_name;
	} // getAccessName
	
	
	/**
	 * This method is used to get the status code from the database.
	 * It executes a SQL query to fetch the status code for the given status name.
	 *
	 * @param status_name The name of the status for which the code is to be fetched.
	 * @return int The code of the status.
	 * @throws MPSException If there is an error during the database operation.
	 */
	public int getStatusCode(String status_name)
		throws MPSException {
		String sMethodName = ".getStatusCode.";
		String selectStatement = "SELECT status_code FROM status WHERE status_name = ?";
		List<Object> objectList = new ArrayList<Object>();
		int status_code = 0;

		try {			
			objectList.add(status_name);
			List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement), objectList.toArray(new Object[objectList.size()]));
			
			for(int j=0; j<alQueryResponse.size(); j++){
            	Map hmQueryResponse = (Map)alQueryResponse.get(j);
            	status_code = Integer.parseInt(hmQueryResponse.get("status_code").toString());
			}
			
		} catch (Exception e) {
			logger.info("{}{}DBH_GSC.01 : Exception occured {}", sClassName, sMethodName, e);
			throw new MPSException(
				"DBHelper::getStatusCode::" + e.getMessage());

		} finally {
			
		}
		return status_code;
	} // getStatusCode
	
	/**
	 * This method is used to get the status name from the database.
	 * It executes a SQL query to fetch the status name for the given status code.
	 *
	 * @param status_code The code of the status for which the name is to be fetched.
	 * @return String The name of the status.
	 * @throws MPSException If there is an error during the database operation.
	 */
	public String getStatusNameByCode(int status_code)
			throws MPSException {
		    String sMethodName = ".getStatusNameByCode.";
			String selectStatement = "SELECT status_name FROM status WHERE status_code = ?";
			List<Object> objectList = new ArrayList<Object>();
			String status_name = "";

			try {			
				objectList.add(status_code);
				List alQueryResponse = jdbcTemplate.queryForList(new String(selectStatement), objectList.toArray(new Object[objectList.size()]));
				
				for(int j=0; j<alQueryResponse.size(); j++){
	            	Map hmQueryResponse = (Map)alQueryResponse.get(j);
	            	status_name = (String) (hmQueryResponse.get("status_name"));
				}
				
			} catch (Exception e) {
				logger.info("{}{}DBH_GSNBC.01 : Exception occured {}", sClassName, sMethodName, e);
				throw new MPSException(
					"DBHelper::getStatusNameByCode::" + e.getMessage());

			} finally {
				
			}
			return status_name;
		} // getStatusNameByCode
}
