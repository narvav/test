package com.att.idp.idgraphcontactinfoms.cassandra.entity;

import java.io.Serializable;

import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyClass;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;

import lombok.Data;

/**
 * This class represents a SessionId entity in the application.
 * It implements the Serializable interface, which means its instances can be converted to a byte stream and
 * restored back to an instance of the class. This is useful for storing the state of an object or transmitting
 * it over a network.
 *
 * The class is annotated with @Data from the Lombok library, which automatically generates getters, setters,
 * equals, hashCode, and toString methods.
 *
 * The class is also annotated with @PrimaryKeyClass from Spring Data Cassandra, indicating that this class
 * is used as a composite primary key class in a Cassandra table.
 */
@Data
@PrimaryKeyClass
public class SessionId  implements Serializable{

    private static final long serialVersionUID = 1L;

    @PrimaryKeyColumn(name = "session_id", ordinal = 1, type = PrimaryKeyType.PARTITIONED)
    private String sessionId;

    /**
     * Constructor for the SessionId class.
     *
     * @param sessionId A unique identifier for the session.
     */
    public SessionId(String sessionId) {
        super();
        this.sessionId = sessionId;
    }

    /**
     * @return
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((sessionId == null) ? 0 : sessionId.hashCode());
        return result;
    }

    /**
     * @param obj
     * @return
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        SessionId other = (SessionId) obj;
        if (sessionId == null) {
            if (other.sessionId != null)
                return false;
        } else if (!sessionId.equals(other.sessionId))
            return false;
        return true;
    }
}