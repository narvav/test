package com.att.idp.idgraphcontactinfoms.db.model;

import java.math.BigDecimal;
import java.util.Date;
import jakarta.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "TMEMBERAUX", schema = "MPS_OWNER")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tmemberaux implements java.io.Serializable {

	@GenericGenerator(name = "generator", strategy = "foreign", parameters = @Parameter(name = "property", value = "tmember"))
	@Id
	@GeneratedValue(generator = "generator")
	@Column(name = "MEMBER_NUM", unique = true, nullable = false, precision = 22, scale = 0)
	private BigDecimal memberNum;

	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	private Tmember tmember;

	@Column(name = "ENC_PASSWORD_VENC", length = 512)
	private String encPasswordVenc;

	@Column(name = "MD5_PASSWORD_VENC", length = 512)
	private String md5PasswordVenc;

	@Column(name = "SHA1_PASSWORD_VENC", length = 512)
	private String sha1PasswordVenc;

	@Column(name = "DES3_PASSWORD_VENC", length = 512)
	private String des3PasswordVenc;

	@Column(name = "SSHA_PASSWORD_VENC", length = 512)
	private String sshaPasswordVenc;

	@Column(name = "SECURITY_ANSWER_1_VENC", length = 512)
	private String securityAnswer1Venc;

	@Column(name = "SECURITY_ANSWER_2_VENC", length = 512)
	private String securityAnswer2Venc;

	@Temporal(TemporalType.DATE)
	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_MODIFIED", nullable = false, length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_MODIFIED_PW", length = 7)
	private Date lastModifiedPw;

	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_MODIFIED_SEC", length = 7)
	private Date lastModifiedSec;

	@Temporal(TemporalType.DATE)
	@Column(name = "RECENT_FRAUD_PW_DATE", length = 7)
	private Date recentFraudPwDate;

	@Column(name = "PASSWORD_VENC", length = 512)
	private String passwordVenc;

	@Column(name = "PASSWORD_TYPE", length = 10)
	private String passwordType;
}