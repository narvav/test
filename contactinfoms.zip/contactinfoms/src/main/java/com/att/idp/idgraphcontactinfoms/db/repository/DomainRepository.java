package com.att.idp.idgraphcontactinfoms.db.repository;

import java.sql.SQLException;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.att.idp.idgraphcontactinfoms.db.model.Tdomain;

/**
 * This is the DomainRepository interface which extends JpaRepository and DomainRepositoryCustom.
 *
 * It is responsible for providing CRUD operations for the Tdomain entity.
 * It also provides custom methods defined in the DomainRepositoryCustom interface.
 *
 * JpaRepository provides JPA related methods such as save(), findOne(), findAll(), count(), delete() etc.
 * DomainRepositoryCustom is used to declare custom repository methods.
 *
 * The Tdomain entity represents a domain in the system.
 * The Long parameter represents the type of the ID of the domain.
 */
@Repository 
public interface DomainRepository extends JpaRepository<Tdomain, Long> , DomainRepositoryCustom {
	
	/**
	 * This method is responsible for retrieving the domain ID from the Tdomain table.
	 *
	 * It takes a string as an input parameter, which represents the name of the domain.
	 *
	 * The method uses the @Query annotation to define a SQL query that retrieves the domain ID for the given domain name.
	 * The @Param annotation is used to bind the method parameter to a named parameter in the SQL query.
	 *
	 * If the retrieval operation is successful, the method returns the domain ID as a Long.
	 * If a SQLException occurs during the retrieval operation, it is thrown to the caller to handle.
	 *
	 * @param domainName a String representing the name of the domain.
	 * @return a Long representing the domain ID, or null if no domain with the given name is found.
	 * @throws SQLException if a database access error occurs or this method is called on a closed connection.
	 */
	@Query(value =  "select domain.domainId from Tdomain domain where domain.domainName=:domainName")
	public Long getDomainId(@Param(value = "domainName") String domainName) throws SQLException;
	
	
	/**
	 * This method is responsible for retrieving the Tdomain entity from the Tdomain table.
	 *
	 * It takes a string as an input parameter, which represents the name of the domain.
	 *
	 * The method uses the @Query annotation to define a SQL query that retrieves the Tdomain entity for the given domain name.
	 * The @Param annotation is used to bind the method parameter to a named parameter in the SQL query.
	 *
	 * If the retrieval operation is successful, the method returns the Tdomain entity.
	 * If a SQLException occurs during the retrieval operation, it is thrown to the caller to handle.
	 *
	 * @param domainName a String representing the name of the domain.
	 * @return a Tdomain entity representing the domain, or null if no domain with the given name is found.
	 * @throws SQLException if a database access error occurs or this method is called on a closed connection.
	 */
	@Query(value =  "select domain from Tdomain domain where domain.domainName=:domainName")
	public Tdomain getTDomainByDomainName(@Param(value = "domainName") String domainName) throws SQLException;
}
