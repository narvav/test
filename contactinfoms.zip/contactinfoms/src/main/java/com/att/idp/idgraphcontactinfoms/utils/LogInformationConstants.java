package com.att.idp.idgraphcontactinfoms.utils;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.utils package.
 *
 * The LogInformationConstants class is a utility class that provides constant string values for logging information.
 * It contains nested classes for different logging contexts, each of which contains its own set of constant string values.
 *
 * The class is designed to be non-instantiable, i.e., an object of this class cannot be created. 
 * This is enforced by a private constructor that throws an exception if called.
 *
 * This class is useful when you need to use consistent, predefined string values for logging information across your application.
 */
public class LogInformationConstants {
	
	private LogInformationConstants() {
		throw new IllegalStateException("LogInformationConstants");
	}
	
	
	public static class AddMemberGroup {
		
		private AddMemberGroup() {
			throw new IllegalStateException("AddMemberGroup");
		}

		public static final String ADD_MEM_GRP_SUCCESS_MESSAGE  = "Successfully saved addMemberGroup data :  ";
		public static final String EMPTY_STRING					= "   ";
		public static final String RECORDS_COUNT			    = " count of rows saved : ";
		
	}
}