package com.att.idp.idgraphcontactinfoms.service;

import jakarta.ws.rs.core.MultivaluedMap;

import com.att.idp.idgraphcontactinfoms.resource.request.GeneratePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.GeneratePINResponse;

/**
 * This interface is part of the com.att.idp.idgraphcontactinfoms.service package.
 *
 * The GeneratePINService interface defines a contract for a service that handles the generation of a PIN.
 * It declares a single method, generatePIN, which takes a GeneratePINRequest and a MultivaluedMap of String to String as input and returns a GeneratePINResponse.
 *
 * The generatePIN method is expected to perform the operation of generating a PIN, using the GeneratePINRequest as the request body and the MultivaluedMap as the request headers.
 */
public interface GeneratePINService {

	/**
	 * This method is part of the GeneratePINService interface in the com.att.idp.idgraphcontactinfoms.service package.
	 *
	 * The generatePIN method is used to perform the operation of generating a PIN.
	 * It takes a GeneratePINRequest object and a MultivaluedMap of String to String as input.
	 * The GeneratePINRequest object represents the request body, containing the details required for generating a PIN.
	 * The MultivaluedMap represents the request headers.
	 *
	 * The method returns a GeneratePINResponse object, which represents the response from the operation of generating a PIN.
	 */
	GeneratePINResponse generatePIN(GeneratePINRequest generatePINRequest, MultivaluedMap<String, String> requestHeader);

}


