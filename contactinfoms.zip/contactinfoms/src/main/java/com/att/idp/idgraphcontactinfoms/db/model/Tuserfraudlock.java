package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import jakarta.persistence.*;
import java.io.Serializable;
import java.sql.Date;

@Entity
@Table(name = "TUSERFRAUDLOCK", schema = "MPS_OWNER")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tuserfraudlock implements Serializable {

	private static final long serialVersionUID = 8654258584466530452L;

	@Id
	@GenericGenerator(name = "generator", strategy = "foreign", parameters = @Parameter(name = "property", value = "tmember"))
	@GeneratedValue(generator = "generator")
	@Column(name = "MEMBER_NUM", unique = true, nullable = false, precision = 22, scale = 0)
	private Long memberNum;

	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	private Tmember tmember;

	@Column(name = "USER_LOCK_LEVEL", length = 5)
	private String userLockLevel;

	@Column(name = "USER_LOCK_REASON", length = 50)
	private String userLockReason;

	@Column(name = "FRAUD_AGENT", length = 20)
	private String fraudAgent;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;
}