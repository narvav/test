package com.att.idp.idgraphcontactinfoms.resource.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.response package.
 *
 * The CCMuleSyncCallResponse class is used to represent the response from a synchronous call to the CC Mule service.
 * It contains two fields: message and traceId.
 *
 * The message field is a string that contains the message from the response.
 * The traceId field is a string that contains the trace ID from the response.
 *
 * Each field has a corresponding getter and setter method, allowing the fields to be accessed and modified.
 *
 * The class is annotated with @JsonIgnoreProperties and @JsonInclude, which control the JSON serialization and deserialization behavior.
 * The @JsonIgnoreProperties annotation indicates that any unknown properties encountered during JSON processing should be ignored.
 * The @JsonInclude annotation indicates that only non-null properties should be included in the JSON.
 *
 * The class is also annotated with @ApiModel, which provides additional metadata for the Swagger documentation.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "CCMuleSyncCallResponse")
public class CCMuleSyncCallResponse {
	private String message;
	private String traceId;
}