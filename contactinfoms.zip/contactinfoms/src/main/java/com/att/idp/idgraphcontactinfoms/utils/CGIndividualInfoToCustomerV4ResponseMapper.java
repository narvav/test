package com.att.idp.idgraphcontactinfoms.utils;

import com.att.idp.core.exception.ServiceException;
import com.att.idp.dpl.profile.bsse.customerv4.*;
import com.att.idp.dpl.profile.bsse.model.common.ContactMedium;
import com.att.idp.idgraphcontactinfoms.message.ErrorMessages;
import io.swagger.client.model.CGIndividualInfo;
import io.swagger.client.model.Characteristic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Utility class to map CGIndividualInfo objects to CustomerV4Response objects.
 */
@Component
public class CGIndividualInfoToCustomerV4ResponseMapper {

    private static String sClassName = "CGIndividualInfoToCustomerV4ResponseMapper";
    public static final Logger logger = LoggerFactory.getLogger(CGIndividualInfoToCustomerV4ResponseMapper.class);

    /**
     * Maps a CGIndividualInfo object to a CustomerV4Response object.
     *
     * @param cgIndividualInfo The CGIndividualInfo object to map.
     * @return A CustomerV4Response object containing the mapped data.
     * @throws ServiceException If the input CGIndividualInfo object is null.
     */
    public CustomerV4Response mapToCustomerV4Response(CGIndividualInfo cgIndividualInfo) {
        String stAppInfo = null;
        String sMethodName = ".mapToCustomerV4Response.";

        if (cgIndividualInfo == null) {
            stAppInfo = "CGIndividualInfoToCustomerV4ResponseMapper.CGIndividualInfo cannot be null";
            logger.info("{}{}CCIH_02 : {}", sClassName, sMethodName, stAppInfo);
            throw new ServiceException(ErrorMessages.MS_MPSYS_BE_610, stAppInfo);
        }
        logger.info("{}{}CCIH_01 : Mapping CGIndividualInfo to CustomerV4Response is started", sClassName, sMethodName);
        CustomerV4Response customerV4Response = new CustomerV4Response();
        Individual individual = new Individual();
        try {
            // Map contactMedium
            if (cgIndividualInfo.getContactMedium() != null) {
                List<ContactMedium> contactMediumList = convertProfiletoCGContactMedium(cgIndividualInfo.getContactMedium());
                individual.setContactMedium(contactMediumList);
            }

            // Map createdOn
            individual.setCreatedOn(cgIndividualInfo.getCreatedOn());

            // Map accounts
            if (cgIndividualInfo.getAccounts() != null) {
                List<Account> accounts = convertProfileToCGAccount(cgIndividualInfo.getAccounts());
                individual.setAccounts(accounts);
            }

            customerV4Response.setIndividual(individual);
            logger.info("{}{}CCIH_02 : Mapping CGIndividualInfo to CustomerV4Response is successful", sClassName, sMethodName);
            return customerV4Response;
        } catch (Exception ex) {
            stAppInfo = "Error occurred while converting profile response to cg response: " + ex.getMessage();
            logger.error("{}{}CCIH_02 : {}", sClassName, sMethodName, stAppInfo);
            throw ex;
        }
    }

    /**
     * Converts a list of ContactMedium objects from the input model to the target model.
     *
     * @param profileIndContactMediumList The list of ContactMedium objects to convert.
     * @return A list of converted ContactMedium objects.
     */
    private List<ContactMedium> convertProfiletoCGContactMedium(List<io.swagger.client.model.ContactMedium> profileIndContactMediumList) {
        if (profileIndContactMediumList == null || profileIndContactMediumList.isEmpty()) {
            return new ArrayList<>();
        }

        return profileIndContactMediumList.stream().map(profileIndContactMedium -> {
            if (profileIndContactMedium == null) {
                logger.warn("convertContactMedium: Encountered null profileIndContactMedium in profileIndContactMediumList. Skipping.");
                return null;
            }
            ContactMedium cgIndContactMedium = new ContactMedium();

            cgIndContactMedium.setMediumType(profileIndContactMedium.getMediumType());
            cgIndContactMedium.setPreferred(profileIndContactMedium.isPreferred());

            // Map characteristic
            com.att.idp.dpl.profile.bsse.model.common.Characteristic cgIndCharacteristic = new com.att.idp.dpl.profile.bsse.model.common.Characteristic();
            Characteristic profileIndCharacteristic = profileIndContactMedium.getCharacteristic();
            if (profileIndCharacteristic != null) {
                cgIndCharacteristic.setEmailAddress(profileIndCharacteristic.getEmailAddress());
                cgIndCharacteristic.setPhoneNumber(profileIndCharacteristic.getPhoneNumber());
                cgIndCharacteristic.setVerified(profileIndCharacteristic.isVerified());
                cgIndCharacteristic.setEstablishmentDate(profileIndCharacteristic.getEstablishmentDate());
                cgIndCharacteristic.setCity(profileIndCharacteristic.getCity());
                cgIndCharacteristic.setCountry(profileIndCharacteristic.getCountry());
                cgIndCharacteristic.setPostCode(profileIndCharacteristic.getPostCode());
                cgIndCharacteristic.setStateOrProvince(profileIndCharacteristic.getStateOrProvince());
                cgIndCharacteristic.setStreet1(profileIndCharacteristic.getStreet1());
                cgIndCharacteristic.setStreet2(profileIndCharacteristic.getStreet2());
                cgIndCharacteristic.setContactType(profileIndCharacteristic.getContactType());
            }
            cgIndContactMedium.setCharacteristic(cgIndCharacteristic);

            return cgIndContactMedium;
        }).filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    /**
     * Converts a list of IndividualAccountResponse objects to Account objects.
     *
     * @param profileAccountList The list of IndividualAccountResponse objects to convert.
     * @return A list of converted Account objects.
     */
    public List<Account> convertProfileToCGAccount(List<io.swagger.client.model.IndividualAccountResponse> profileAccountList) {
        if (profileAccountList == null || profileAccountList.isEmpty()) {
            return new ArrayList<>();
        }

        return profileAccountList.stream().map(profileAccount -> {
            if (profileAccount == null) {
                logger.warn("convertAccount: Encountered null Account in profileAccountList. Skipping.");
                return null;
            }
            Account cgAccount = new Account();
            cgAccount.setId(profileAccount.getId());
            State cgAccountState = new State();
            cgAccountState.setState(profileAccount.getState());
            cgAccount.setState(cgAccountState);
            cgAccount.setAccountType(profileAccount.getAccountType());
            cgAccount.setAccountSubType(profileAccount.getAccountSubType());
            cgAccount.setCreatedOn(profileAccount.getCreatedOn());
            // since IndividualId search for CPNI Eligibility supports only BSSE, setting TargetSOR as "CG"
            cgAccount.setTargetSOR(Constants.TARGET_SOR_CG);

            if (profileAccount.getServiceType() != null && !profileAccount.getServiceType().isEmpty()) {
                cgAccount.setServiceType(profileAccount.getServiceType().get(0));
            }

            // Map contacts
            if (profileAccount.getContact() != null) {
                List<Contact> contacts = profileAccount.getContact().stream()
                        .map(contact -> convertProfileToCGContact(contact))
                        .collect(Collectors.toList());
                cgAccount.setContact(contacts);
            }
            cgAccount.setSubscribers(convertProfileToCGSubscribers(profileAccount.getSubscribers()));
            return cgAccount;
        }).collect(Collectors.toList());
    }

    /**
     * Converts a Contact object from the profileContact to the cgContact.
     *
     * @param profileContact The Contact object to convert.
     * @return A converted Contact object.
     */
    private Contact convertProfileToCGContact(io.swagger.client.model.Contact profileContact) {
        Contact cgContact = new Contact();

        if (profileContact!= null && profileContact.getContactMedium() != null) {
            List<ContactMedium> contactMediums = convertProfiletoCGContactMedium(profileContact.getContactMedium());
            cgContact.setContactMedium(contactMediums);
        }
        return cgContact;
    }

    /**
     * Converts a list of Subscribers objects to the target model.
     *
     * @param profileSubscribersList The list of Subscribers objects to convert.
     * @return A list of converted Subscriber objects.
     */
    private List<com.att.idp.dpl.profile.bsse.customerv4.Subscriber> convertProfileToCGSubscribers(
            List<io.swagger.client.model.Subscribers> profileSubscribersList) {
        if (profileSubscribersList == null || profileSubscribersList.isEmpty()) {
            return new ArrayList<>();
        }
        return profileSubscribersList.stream().map(profileSubscriber -> {
            if (profileSubscriber == null) {
                logger.warn("convertSubscribers: Encountered null Subscriber in profileSubscribersList. Skipping.");
                return null;
            }
            com.att.idp.dpl.profile.bsse.customerv4.Subscriber cgSubscriber = new com.att.idp.dpl.profile.bsse.customerv4.Subscriber();

            cgSubscriber.setCreatedOn(profileSubscriber.getCreatedOn());
            cgSubscriber.setUpdatedOn(profileSubscriber.getUpdatedOn());
            cgSubscriber.setEffectiveDate(profileSubscriber.getUpdatedOn());
            Status status = new Status();
            status.setStatus(profileSubscriber.getStatus());
            cgSubscriber.setStatus(status);
            cgSubscriber.setPhoneNumber(profileSubscriber.getCtn());
            if (profileSubscriber.isSmsCapable() != null) {
                cgSubscriber.setIsSMSCapable(profileSubscriber.isSmsCapable());
            }
           SubscriberExtensions extensions = new SubscriberExtensions();
            extensions.setSimSwapDate(profileSubscriber.getSimSwapDate());
            cgSubscriber.setExtensions(extensions);
            return cgSubscriber;
        }).collect(Collectors.toList());
    }

}
