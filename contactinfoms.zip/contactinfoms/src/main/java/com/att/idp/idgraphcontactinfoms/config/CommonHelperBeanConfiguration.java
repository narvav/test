package com.att.idp.idgraphcontactinfoms.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.att.mpsys.common.helpers.AsyncCall;
import com.att.mpsys.common.helpers.CallDestinationAsync;
import com.att.mpsys.common.helpers.SoapHelper;
import com.att.mpsys.common.helpers.SoapHttpClient;

/**
 * The CommonHelperBeanConfiguration class is a configuration class in the Spring framework.
 * It is annotated with @Configuration to indicate that it is a source of bean definitions.
 * It is also annotated with @EnableTransactionManagement to enable Spring's annotation-driven transaction management capability.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.config package.
 *
 * It contains four bean definitions:
 * - getSoapHelper: This method returns a SoapHelper bean.
 * - getSoapHttpClient: This method returns a SoapHttpClient bean.
 * - getAsyncCall: This method returns an AsyncCall bean.
 * - getCallDestinationAsync: This method returns a CallDestinationAsync bean.
 *
 * Each bean is defined in a separate method annotated with @Bean, which tells Spring that the return value of the method should be registered as a bean in the Spring application context.
 */
@Configuration
@EnableTransactionManagement(proxyTargetClass=true)
public class CommonHelperBeanConfiguration {

	@Bean
	public SoapHelper getSoapHelper() {
		SoapHelper soapHelper = new SoapHelper();
		return soapHelper;
	}

	
	@Bean
	public SoapHttpClient getSoapHttpClient() {
		SoapHttpClient oSoapHttpClient = new SoapHttpClient();
		return oSoapHttpClient;
	}
	 
	@Bean
	public AsyncCall getAsyncCall() {
		AsyncCall aSyncCall = new AsyncCall();
		return aSyncCall;
	}

	@Bean
	public CallDestinationAsync getCallDestinationAsync() {
		CallDestinationAsync callDestinationAsync = new CallDestinationAsync();
		return callDestinationAsync;
	}

}