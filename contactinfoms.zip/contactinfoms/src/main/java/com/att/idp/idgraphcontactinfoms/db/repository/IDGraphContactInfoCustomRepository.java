package com.att.idp.idgraphcontactinfoms.db.repository;

import java.io.Serializable;

import jakarta.persistence.EntityManager;

import org.hibernate.LockOptions;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

/**
 * This is the IDGraphContactInfoCustomRepository class.
 *
 * It is a generic class that provides custom repository methods for a given entity type T with an ID of type I.
 * These methods are not provided by the JpaRepository and need to be implemented manually.
 *
 * The class uses the EntityManager to interact with the database.
 * The EntityManager is autowired and qualified with "entityManagerFactory".
 *
 * The class provides methods to get the current Hibernate Session, get the Class of the entity type T, and get an entity by its ID with a write lock.
 *
 * @param <T> the type of the entity.
 * @param <I> the type of the entity's ID.
 */
public class IDGraphContactInfoCustomRepository<T, I> {

	@Autowired
	@Qualifier("entityManagerFactory")
	protected EntityManager entityManager;

	/**
	 * This method is used to get the current Hibernate Session.
	 *
	 * It uses the EntityManager to unwrap and return the current Hibernate Session.
	 * The EntityManager is autowired and qualified with "entityManagerFactory".
	 *
	 * The returned Session can be used to perform operations directly on the database.
	 *
	 * @return the current Hibernate Session.
	 */
	public Session getSession() {
		return entityManager.unwrap(Session.class);
	}

	protected Class<T> getClassT() {

		return null;
	}

	/**
	 * This method is used to retrieve an entity by its ID with a write lock.
	 *
	 * It takes an ID of type I as an input parameter, which represents the ID of the entity.
	 *
	 * The method uses the getSession() method to get the current Hibernate Session.
	 * Then it uses the get() method of the Session to retrieve the entity with the given ID.
	 * The LockOptions.READ is used to apply a write lock to the entity.
	 *
	 * If the retrieval operation is successful, the method returns the entity of type T.
	 * If no entity with the given ID is found, the method returns null.
	 *
	 * @param id an I representing the ID of the entity.
	 * @return an entity of type T with the given ID, or null if no entity with the given ID is found.
	 */
	public T getByIdWithWriteLock(I id) {

		return (T) getSession().get(getClassT(), (Serializable) id, LockOptions.READ);
	}
}
