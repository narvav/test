package com.att.idp.idgraphcontactinfoms.integration.Async;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.google.common.html.HtmlEscapers;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.integration.Async package.
 * It is used for handling asynchronous calls in the application.
 *
 * The class is annotated with @Component, indicating that it is a Spring bean and can be automatically
 * picked up and instantiated by Spring's container.
 * The class contains several fields that are injected via Spring's @Autowired and @Value annotations.
 * The @Autowired annotation is used to inject the CallDestinationAsync object, which is used to make asynchronous calls.
 * The @Value annotation is used to inject the value of the DEST_EVENT property from the application's properties file.
 *
 * The class contains a single public method, processRequest, which is used to process a request.
 * The method takes a HashMap as input, which contains the details of the request.
 * The method then processes the request asynchronously, and returns a HashMap containing the response.
 */
@Component
public class AsyncCall {
	private static Logger logger = LoggerFactory.getLogger(AsyncCall.class);
	private static String className = "AsyncCall";
	
	private String sAppInfo = null;
	private String sAppStatusCode=null;
	@Autowired
	private CallDestinationAsync  callDestinationAsync;
	
	@Value("${DEST_EVENT}")
	private String propDestionationEvent;
	
	/**
	 * This method is used to process a request asynchronously.
	 *
	 * It takes a HashMap as input, which contains the details of the request.
	 * The method then processes the request asynchronously, and returns a HashMap containing the response.
	 * The method also logs information about the processing, and handles any exceptions that may occur.
	 *
	 * @param hmInput A HashMap containing the details of the request.
	 * @return A HashMap containing the response.
	 */
	public HashMap<String, Object> processRequest(HashMap<String, Object> hmInput) {
		
		String sMethodName=".processRequest.";
		logger.debug("{}{} ASC_01 : START : Input Hash = {}",className,sMethodName, HtmlEscapers.htmlEscaper().escape(String.valueOf(hmInput)));
		
		HashMap<String, Object> hmResponse = new HashMap<String, Object>();	
		try {
			if(hmInput == null  || hmInput.isEmpty()){
				sAppInfo = "Missing or empty input hash.";
				logger.error("{}{}ASC_02 : Async : {}",className,sMethodName,sAppInfo);
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EXTERNAL_SYS_NUM, sAppInfo);
				return hmResponse;
			}
			int noOfEvents = hmInput.size();
			CompletableFuture<Map<String, Object>>[] fs = new CompletableFuture[noOfEvents];

			Iterator itr = hmInput.keySet().iterator();
			int i = 0;
			while (itr.hasNext()) {
				String obj = (String)itr.next();
				HashMap<String, Object> hmEvent = (HashMap<String, Object>) hmInput.get(obj);
				
				if(hmEvent == null || hmEvent.isEmpty()){
					sAppInfo = "Input request hash for the key '"+ hmInput.get(obj) +"' is null or empty.";
					logger.debug("{}{}ASC_03 : Async : {}",className,sMethodName, HtmlEscapers.htmlEscaper().escape(String.valueOf(sAppInfo)));
					hmResponse.put(obj, hmEvent);
					i++;
					continue;
				}
				String eventname = (String) hmEvent.get(CommonDefs.EVENTNAME);
				if(eventname == null || eventname.isEmpty()){
					sAppInfo = "Missing or empty eventname in request.";
					logger.debug("{}{}ASC_04 : Eventname is null or empty in ",className,sMethodName);
					HashMap hmtemp = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EXTERNAL_SYS_NUM, sAppInfo);
					hmResponse.put(obj, hmtemp);
					i++;
					continue;
				}
				String[] events = propDestionationEvent.split("\\|");
				String callingDestination = null;
				for(String event : events){
					if(event.contains(eventname))
						callingDestination=event.substring(0, event.indexOf(":"));
				}
				
				hmEvent.put("CallingDestination", callingDestination);
				hmEvent.put("destinationKey", obj);
				logger.debug("{}{}ASC_05 Calling Destination {} with input : {}",className,sMethodName,HtmlEscapers.htmlEscaper().escape(String.valueOf(hmEvent)), obj);
				fs[i++] = callDestinationAsync.callDestinationAsync(hmEvent);

			}

			// wait until they are completed.
			CompletableFuture.allOf(fs).join();

			for (CompletableFuture<Map<String, Object>> item : fs) {
				if (item.isDone()) {
					String key = item.get().get("destinationKey").toString();
//					String escapedValueOfKey = (key!=null)?StringUtils.normalizeSpace(String.valueOf(key)):null;
					logger.debug("{}{}ASC_06 preparing final hm for Destination: {}",className,sMethodName, ESAPI.encoder().encodeForHTML(key));
					
					Map<String, Object> hmEventResponse = item.get();
					hmEventResponse.remove("destinationKey");
					hmResponse.put(key, hmEventResponse);

				}
			}
			
			if(hmResponse == null || hmResponse.isEmpty()){
				sAppInfo = "hmResponse  is null or empty";
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				logger.error("{}{} ASC_07  ASYNC : {}",className,sMethodName, sAppInfo);
				return hmResponse;
			}
			sAppInfo="Successfully called all events.";
			hmResponse.put(CommonDefs.COMMON_APP_INFO, sAppInfo);
			hmResponse.putAll(CommonErrorMap.makeCommonStatusMap(CErrorDefs.COMMON_SUCCESS_NUM, sAppInfo));
			
			
		} catch (InterruptedException | ExecutionException e) {
			logger.error("{}{} ASC_08 ASYNCCALL : {}",className,sMethodName,e.getMessage());
			hmResponse     = CommonErrorMap.makeExceptionMap(e, logger);
			logger.error("{}{}error hash map = {}",className,sMethodName, hmResponse);
			sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
			
		} catch (Exception e) {
			logger.error("{}{}ASC_09 ASYNCCALL : {}",className,sMethodName,e.getMessage());
			hmResponse     = CommonErrorMap.makeExceptionMap(e, logger);
			sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
			logger.error("{}{}ASC_10 ASYNCCALL : error hash map = {}",className,sMethodName, hmResponse);
		}
		
		logger.debug(SpiMarker.getInstance(),"{}{}END :: Final response returned to the caller : {}",
				className, sMethodName, hmResponse);
		
		return hmResponse;

	}


}
