package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "TMEMBERSERVICEROLE", schema = "MPS_OWNER", uniqueConstraints = @UniqueConstraint(columnNames = {
		"MEMBER_NUM", "SERVICE_ID", "SOR_ID", "SOR_INVARIANT_ID", "ROLE_ID" }))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tmemberservicerole implements java.io.Serializable {

	private TmemberserviceroleId id;
	private Tservicerole tservicerole;
	private Tsystemofrecord tsystemofrecord;
	private Tstatus tstatus;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "roleId", column = @Column(name = "ROLE_ID", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "memberNum", column = @Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "serviceId", column = @Column(name = "SERVICE_ID", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "sorId", column = @Column(name = "SOR_ID", precision = 22, scale = 0)),
			@AttributeOverride(name = "sorInvariantId", column = @Column(name = "SOR_INVARIANT_ID")),
			@AttributeOverride(name = "status", column = @Column(name = "STATUS", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "createDate", column = @Column(name = "CREATE_DATE", nullable = false, length = 7)),
			@AttributeOverride(name = "lastModified", column = @Column(name = "LAST_MODIFIED", length = 7)),
			@AttributeOverride(name = "lastModifiedBy", column = @Column(name = "LAST_MODIFIED_BY", nullable = false)) })
	public TmemberserviceroleId getId() {
		return this.id;
	}

	public void setId(TmemberserviceroleId id) {
		this.id = id;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "SERVICE_ID", referencedColumnName = "SERVICE_ID", nullable = false, insertable = false, updatable = false),
			@JoinColumn(name = "ROLE_ID", referencedColumnName = "ROLE_ID", nullable = false, insertable = false, updatable = false) })
	public Tservicerole getTservicerole() {
		return this.tservicerole;
	}

	public void setTservicerole(Tservicerole tservicerole) {
		this.tservicerole = tservicerole;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SOR_ID", insertable = false, updatable = false)
	public Tsystemofrecord getTsystemofrecord() {
		return this.tsystemofrecord;
	}

	public void setTsystemofrecord(Tsystemofrecord tsystemofrecord) {
		this.tsystemofrecord = tsystemofrecord;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "STATUS", nullable = false, insertable = false, updatable = false)
	public Tstatus getTstatus() {
		return this.tstatus;
	}

	public void setTstatus(Tstatus tstatus) {
		this.tstatus = tstatus;
	}
}