package com.att.idp.idgraphcontactinfoms.resource.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.response package.
 *
 * The AccountContactList class is used to represent a list of account contacts.
 * It contains several fields, each of which represents a different type of contact information for the account.
 * These fields include email, usPhoneNumber, and postalAddress.
 *
 * The email field is an object of the Email class, representing the email contact information for the account.
 * The usPhoneNumber field is an object of the USPhoneNumber class, representing the US phone number contact information for the account.
 * The postalAddress field is an object of the PostalAddress class, representing the postal address contact information for the account.
 *
 * Each field has a corresponding getter and setter method, allowing the fields to be accessed and modified.
 * The setter methods are annotated with @JsonProperty, indicating the JSON property name to be used during serialization and deserialization.
 *
 * The class also overrides the toString method, providing a custom string representation of the object.
 */
@Data
public class AccountContactList {

	private Email email;

	private USPhoneNumber usPhoneNumber;

	private PostalAddress postalAddress;

	@JsonProperty("Email")
	public void setEmail(Email email) {
		this.email = email;
	}

	@JsonProperty("USPhoneNumber")
	public void setUsPhoneNumber(USPhoneNumber usPhoneNumber) {
		this.usPhoneNumber = usPhoneNumber;
	}

	@JsonProperty("PostalAddress")
	public void setPostalAddress(PostalAddress postalAddress) {
		this.postalAddress = postalAddress;
	}
}