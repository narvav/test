package com.att.idp.idgraphcontactinfoms.service;


import com.att.idp.idgraphcontactinfoms.resource.response.CPNIContactInfoResponse;
import jakarta.ws.rs.core.MultivaluedMap;


public interface CPNIContactInfoService {

	CPNIContactInfoResponse cpniContactInfo(MultivaluedMap<String, String> cpniContactInfoRequestHeader) throws Exception;

}
