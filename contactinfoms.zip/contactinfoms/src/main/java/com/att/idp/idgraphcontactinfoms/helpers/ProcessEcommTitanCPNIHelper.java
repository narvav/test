package com.att.idp.idgraphcontactinfoms.helpers;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TimeZone;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;


/**
 * This class is a helper class for processing Ecomm Titan CPNI.
 *
 * It contains methods for processing Ecomm Titan CPNI based on the input parameters.
 * The class uses the Spring Framework's @Component annotation to indicate that it is a bean and can be used for dependency injection.
 *
 * The class has several instance variables that are injected using the @Autowired annotation.
 * These variables include a CPNIDataConsolidationHelper, a QueryProfileProofingInfoHelper, and an InquireAccountContactInfoHelper.
 *
 * The main method in this class is the processEcommTitanCPNI method, which takes two HashMaps as input and returns a HashMap as output.
 * The processEcommTitanCPNI method uses several other methods in the class to validate the input data, process the input data, and store the data.
 *
 * The class also contains a logger for logging information and error messages.
 */
@Component
public class ProcessEcommTitanCPNIHelper {

	private static String sClassName = "ProcessEcommTitanCPNIHelper";
	
	@Autowired
	private CPNIDataConsolidationHelper oCPNIConsolidationHelper;
	
	@Autowired
	private QueryProfileProofingInfoHelper oQueryProfileProofingInfoH;
	
	@Autowired
	private InquireAccountContactInfoHelper oInquireAccountContactInfoHelper;
	
	public static final Logger logger = LoggerFactory.getLogger(ProcessEcommTitanCPNIHelper.class);

	
	/**
	 * This method processes Ecomm Titan CPNI based on the input parameters.
	 *
	 * It first validates the input data. If the input data is invalid, the method constructs an error response and returns it.
	 * If the input data is valid, the method processes the input data and makes a call to the CPNIDataConsolidationHelper to process Ecomm Titan CPNI.
	 * The method then checks the response from the CPNIDataConsolidationHelper. If the response indicates an error, the method constructs an error response and returns it.
	 * If the response from the CPNIDataConsolidationHelper indicates success, the method constructs a success response and returns it.
	 *
	 * @param hmInput a HashMap that contains the input data for the Ecomm Titan CPNI processing. The HashMap should include the transaction ID, transaction name, GUID, and calling system ID.
	 * @param hmBDSResponse a HashMap that contains the BDS response data. The HashMap should include the application status code, application info message, and the user contact information.
	 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code, an application info message, and the processed Ecomm Titan CPNI data.
	 * @throws Exception if an error occurs during the operation.
	 */
	public HashMap processEcommTitanCPNI(HashMap hmInput, HashMap hmBDSResponse) {
		String sMethodName = ".processEcommTitanCPNI.";
		HashMap<String, Object> hmResult = null;
		String stAppInfo = null;
		String stAppStatusCode = null;
		String stAppCatogoryCode = null;
		HashMap<String, Object> hmCPNIConResponse = CommonUtil.getHashMap();
		boolean bIgnoreBDSError = false;

		try {
			logger.info("{}{}HLP000 : Input Hash : {}", sClassName, sMethodName, hmInput);

			if (hmInput == null || hmInput.isEmpty()) {
				stAppInfo = "Input Hash is null or empty";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}ET_CPNI_H_01 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			stAppStatusCode = (String) hmBDSResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
			stAppCatogoryCode = (String) hmBDSResponse.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
			String sReturnCBRCTNs = (String) hmInput.get("returnCBRCTNs");
			String sAccountType = (String) hmInput.get(CommonDefs.ACCOUNT_TYPE);

			if (sAccountType.equals(CommonDefs.TITAN_SERVICE) && sReturnCBRCTNs != null
					&& sReturnCBRCTNs.equalsIgnoreCase(CommonDefs.IND_Y)) {
				bIgnoreBDSError = true;
				hmInput.put("ignoreBDSError", CommonDefs.IND_Y);
			}

			if (!bIgnoreBDSError) {
				if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					if (stAppCatogoryCode != null && stAppCatogoryCode.equals(CErrorDefs.CATEGORY_CODE_SYSTEM_ERROR)) {
						stAppInfo = (String) hmBDSResponse.get(CommonDefs.COMMON_APP_INFO);
						logger.info("{}{}ET_CPNI_H_02 : {}", sClassName, sMethodName,
								ESAPI.encoder().encodeForHTML(stAppInfo));
						hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
						return hmResult;
					} else {
						stAppInfo = "Account Not found in DB.";
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ACCOUNT_NOT_FOUND_NUM,
								CErrorDefs.ERR_ACCOUNT_NOT_FOUND_MSG);
						logger.info("{}{}ET_CPNI_H_03 : {}", sClassName, sMethodName, stAppInfo);
						return hmResult;
					}
				}
			}

			logger.debug(SpiMarker.getInstance(),"{}{}ET_CPNI_H_04 : Calling callCPNIConsHelper() with hmBDSResponse : {}", sClassName,
					sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmBDSResponse)));

			hmCPNIConResponse = callCPNIConsHelper(hmInput, hmBDSResponse);

			logger.debug("{}{}ET_CPNI_H_05 : ResponseHash from callCPNIConsHelper() : {}", sClassName, sMethodName,
					hmCPNIConResponse);

			stAppStatusCode = (String) hmCPNIConResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);

			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				stAppInfo = (String) hmCPNIConResponse.get(CommonDefs.COMMON_APP_INFO);
				logger.info("{}{}ET_CPNI_H_06 : {}", sClassName, sMethodName,
						HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
				hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
				return hmResult;
			}

			ArrayList alContactList = (ArrayList) hmCPNIConResponse.get(CommonDefs.ACCOUNT_CONTACT_LIST);
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

			if (alContactList != null && !alContactList.isEmpty()) {
				hmResult.put(CommonDefs.ACCOUNT_CONTACT_LIST, alContactList);
			}

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
		} finally {
			stAppInfo = "Response from ProcessEcommTitanCPNIHelper = " + hmResult;
			logger.info("{}{}ET_CPNI_H_06.3 : {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));

			if (hmResult == null || hmResult.isEmpty()) {
				stAppInfo = "Response from ProcessEcommTitanCPNIHelper is NULL";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}ET_CPNI_H_06.4 : {}", sClassName, sMethodName, stAppInfo);
			}

			logger.info("{}{}HLP999 : response from ProcessEcommTitanCPNIHelper : {}", sClassName, sMethodName,
					hmResult);
		}
		return hmResult;
	}

	/**
	 * This method calls the CPNIConsolidationHelper to process the input data.
	 *
	 * It first retrieves the account type and ignore BDSError flag from the input HashMap.
	 * Then, it constructs a new HashMap for the CPNIConsolidationHelper input.
	 * It populates the new HashMap with the transaction ID, transaction name, and calling system ID from the input HashMap.
	 * It also retrieves the BDS account contacts from the BDS response and adds them to the new HashMap.
	 * If the account type is Titan and the return CBR CTNs flag is set, it processes the CBR CTNs and adds them to the new HashMap.
	 * If the account type is not Titan, it adds the account ID to the new HashMap.
	 * It then calls the CPNIConsolidationHelper's generateCPNIConsolidation method with the new HashMap as input.
	 * The method checks the response from the CPNIConsolidationHelper. If the response indicates an error, the method constructs an error response and returns it.
	 * If the response from the CPNIConsolidationHelper indicates success, the method constructs a success response and returns it.
	 *
	 * @param hmInput a HashMap that contains the input data for the CPNI consolidation. The HashMap should include the transaction ID, transaction name, calling system ID, account type, and ignore BDSError flag.
	 * @param hmBDSResponse a HashMap that contains the BDS response data. The HashMap should include the application status code, application info message, and the BDS account contacts.
	 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code, an application info message, and the processed CPNI consolidation data.
	 * @throws Exception if an error occurs during the operation.
	 */
	public HashMap callCPNIConsHelper(HashMap hmInput, HashMap hmBDSResponse) {
		String sMethodName = ".callCPNIConsHelper.";
		HashMap<String, Object> hmResult = null;
		String stAppInfo = null;
		String stAppStatusCode = null;

		try {
			String sAccountType = (String) hmInput.get(CommonDefs.ACCOUNT_TYPE);
			String sIgnoreBDSError = (String) hmInput.get("ignoreBDSError");

			HashMap<String, Object> hmCPNIConsHelperInput = CommonUtil.getHashMap();

			hmCPNIConsHelperInput.put(CommonDefs.TRANSACTION_NAME, (String) hmInput.get(CommonDefs.TRANSACTION_NAME));
			hmCPNIConsHelperInput.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(CommonDefs.TRANSACTION_ID));
			hmCPNIConsHelperInput.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));

			HashMap<String, Object> hmBDSAcctResp = retrieveBDSAcctContacts(hmBDSResponse, hmInput);
			stAppStatusCode = (String) hmBDSAcctResp.get(CommonDefs.COMMON_APP_STATUS_CODE);

			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)
					&& (sIgnoreBDSError == null || sIgnoreBDSError.isEmpty()
							|| !sIgnoreBDSError.equals(CommonDefs.IND_Y))) {
				hmResult = hmBDSAcctResp;
				return hmResult;
			}

			HashMap<String, Object> hmBDSAcctContacts = (HashMap<String, Object>) hmBDSAcctResp
					.get("BDSAccountContacts");

			if (hmBDSAcctContacts != null && !hmBDSAcctContacts.isEmpty()) {
				hmCPNIConsHelperInput.putAll(hmBDSAcctContacts);
			}

			if (hmInput.get(CommonDefs.ACTIVATED_IND) != null) {
				hmCPNIConsHelperInput.put(CommonDefs.ACTIVATED_IND, hmInput.get(CommonDefs.ACTIVATED_IND));
			}

			// 1911 : Updates to processCBRCTNs
			String sReturnCBRCTNs = (String) hmInput.get("returnCBRCTNs");

			if (sReturnCBRCTNs != null && sReturnCBRCTNs.equalsIgnoreCase(CommonDefs.IND_Y)) {
				String sAcctSorInvId = null;

				if (hmBDSAcctResp != null && hmBDSAcctResp.containsKey(CommonDefs.BDS_BILLING_ID)
						&& (sAccountType != null && sAccountType.equals(CommonDefs.ECOMM_SERVICE))) {
					sAcctSorInvId = (String) hmBDSAcctResp.get(CommonDefs.BDS_BILLING_ID);
				} else {
					sAcctSorInvId = (String) hmInput.get(CommonDefs.ACCOUNT_INVARIANT_ID);
				}

				hmResult = processCBRCTNs(hmInput, sAcctSorInvId);
				logger.debug("{}{}ET_CPNI_H_04.1 : ResponseHash from processCBRCTNs : {}", sClassName, sMethodName,
						hmResult);
				stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

				if (stAppStatusCode != null && stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					ArrayList alCBRCTNs = (ArrayList) hmResult.get("CBRCTN");
					if (alCBRCTNs != null && !alCBRCTNs.isEmpty()) {
						hmCPNIConsHelperInput.put("CBRCTNList", alCBRCTNs);
					}
				}
			}

			if (CommonDefs.TITAN_SERVICE.equalsIgnoreCase(sAccountType))
				hmCPNIConsHelperInput.put("NewCPNIEilibilityRule", CommonDefs.IND_Y);

			logger.debug(
					"{}{}ET_CPNI_H_04.2 : Calling CPNIConsolidationHelper.generateCPNIConsolidation with inputHash : {}",
					sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmCPNIConsHelperInput)));

			hmResult = oCPNIConsolidationHelper.generateCPNIConsolidation(hmCPNIConsHelperInput);

			logger.debug("{}{}ET_CPNI_H_04.3 : ResponseHash from CPNIConsolidationHelper.generateCPNIConsolidation : {}",
					sClassName, sMethodName, hmResult);

			if (hmResult == null || hmResult.isEmpty()) {
				stAppInfo = "null Hash returned from CPNIConsolidationHelper.generateCPNIConsolidation() ";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}ET_CPNI_H_04.4 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
				logger.info("{}{}ET_CPNI_H_04.5 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
				return hmResult;
			}

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
		}
		return hmResult;
	}
		
	private HashMap retrieveBDSAcctContacts(HashMap hmBDSResponse, HashMap hmInput) {

		String sMethodName = ".retrieveBDSAcctContacts.";
		HashMap<String, Object> hmResult = null;
		String stAppInfo = null;

		String sAccountType = (String) hmInput.get(CommonDefs.ACCOUNT_TYPE);
		HashMap<String, Object> hmCPNIConsHelperInput = CommonUtil.getHashMap();

		ArrayList alAccountDetails = CommonUtil.getList(hmBDSResponse, CommonDefs.ACCOUNT_DETAIL_RESPONSE);

		if (alAccountDetails == null || alAccountDetails.isEmpty()) {
			stAppInfo = "AccountDetailResponse is null or empty in BDS response";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ACCOUNT_INELIGIBLE_NUM, stAppInfo);
			logger.info("{}{}ET_CPNI_RBDS_01 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		HashMap<String, Object> hmEachAccount = (HashMap<String, Object>) alAccountDetails.get(0);

		HashMap<String, Object> hmAnchorAccount = CommonUtil.getMap(hmEachAccount, CommonDefs.ANCHOR_ACCOUNT);

		if (hmAnchorAccount == null || hmAnchorAccount.isEmpty()) {
			stAppInfo = "AnchorAccount is null or empty in BDS response";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ACCOUNT_INELIGIBLE_NUM, stAppInfo);
			logger.info("{}{}ET_CPNI_RBDS_02 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		String sCustActiveDt = (String) hmAnchorAccount.get(CommonDefs.CUSTOMER_ACTIVE_DATE);

		String sEmailAddress = (String) hmAnchorAccount.get("EmailAddress");
		if (sEmailAddress != null && sEmailAddress.length() > 0) {
			hmCPNIConsHelperInput.put("UverseMemberEmailAddress", sEmailAddress);
			hmCPNIConsHelperInput.put(CommonDefs.CONTACT_EMAIL, sEmailAddress);
		}

		if (sEmailAddress != null && sEmailAddress.trim().length() > 0) {
			String sEmailLastModified = (String) hmAnchorAccount.get("EmailAddrLastUpdateTs");

			if (sEmailLastModified != null && sEmailLastModified.trim().length() > 0) {
				sEmailLastModified = formatDate("EmailAddrLastUpdateTs", sEmailLastModified);
				hmCPNIConsHelperInput.put("UverseEmailEstablishedDate", sEmailLastModified);
			}

			// 2210: There is a discrepancy between LSCRM and BDS for emailStatus. Hence
			// ignoring BDS value.
			/*
			 * String sEmailStatus = null; if ((sEmailUndeliverableInd == null ||
			 * sEmailUndeliverableInd.isEmpty()) || (sEmailUndeliverableInd != null &&
			 * sEmailUndeliverableInd.equals("0"))) { sEmailStatus = "V";
			 * hmCPNIConsHelperInput.put("UverseEmailStatus", sEmailStatus); } else if
			 * (sIgnoreEmailStatusValidation != null &&
			 * sIgnoreEmailStatusValidation.equalsIgnoreCase(CommonDefs.IND_Y)) {
			 * sEmailStatus = "V"; hmCPNIConsHelperInput.put("UverseEmailStatus",
			 * sEmailStatus); }
			 */

			String sEmailStatus = "V";
			hmCPNIConsHelperInput.put("UverseEmailStatus", sEmailStatus);

			HashMap<String, Object> hmEmailAddress = CommonUtil.getHashMap();
			ArrayList alEmailAddresses = CommonUtil.getArrayList();
			hmEmailAddress.put(CommonDefs.EMAIL_ADDRESS, sEmailAddress);
			hmEmailAddress.put(CommonDefs.EMAIL_STATUS, sEmailStatus);
			hmEmailAddress.put(CommonDefs.KEY_EMAIL_ESTABLISHED_DATE, sEmailLastModified);
			hmEmailAddress.put(CommonDefs.KEY_ACCOUNT_ESTABLISHED_DATE, sCustActiveDt);
			
			String stSkipAgingRuleFlag = (String) hmInput.get("skipAgingRuleFlag");

			if(stSkipAgingRuleFlag != null && stSkipAgingRuleFlag.equals(CommonDefs.IND_Y))
				hmEmailAddress.put(CommonDefs.CPNI_ELIGIBLE_EMAIL_FLAG, CommonDefs.IND_Y);
			

			if (hmEmailAddress != null && !hmEmailAddress.isEmpty()) {
				alEmailAddresses.add(hmEmailAddress);
				hmCPNIConsHelperInput.put(CommonDefs.KEY_EMAIL_ADDRESSES, alEmailAddresses);
			}
		} // end of if emailAddress is not null

		hmCPNIConsHelperInput.put(CommonDefs.KEY_ACCOUNT_STATUS,
				(String) hmAnchorAccount.get(CommonDefs.KEY_ACCOUNT_STATUS));
		sCustActiveDt = (String) hmAnchorAccount.get(CommonDefs.CUSTOMER_ACTIVE_DATE);

		if (sCustActiveDt != null && sCustActiveDt.trim().length() > 0) {
			sCustActiveDt = formatDate(CommonDefs.CUSTOMER_ACTIVE_DATE, sCustActiveDt);
			hmCPNIConsHelperInput.put(CommonDefs.CUSTOMER_ACTIVE_DATE, sCustActiveDt);
		}

		hmCPNIConsHelperInput.put(CommonDefs.KEY_DSL_DRY_LOOP_IND,
				hmAnchorAccount.get(CommonDefs.KEY_DSL_DRY_LOOP_IND));
		hmCPNIConsHelperInput.put(CommonDefs.SERVICE_NBR, hmAnchorAccount.get(CommonDefs.SERVICE_NBR));

		if (!CommonDefs.TITAN_SERVICE.equalsIgnoreCase(sAccountType)) {
			hmCPNIConsHelperInput.put(CommonDefs.KEY_ACCOUNT_ID, hmAnchorAccount.get(CommonDefs.KEY_ACCOUNT_ID));
		}

		if (hmAnchorAccount.get(CommonDefs.PROBATIONARY_BILLING_ADDRESS) != null) {
			hmCPNIConsHelperInput.put(CommonDefs.KEY_PROBATIONARY_ADDRESS_IND, CommonDefs.IND_Y);
		}

		HashMap<String, Object> hmAddressInfo = CommonUtil.getMap(hmAnchorAccount, "AddressInfo");

		if (hmAddressInfo != null) {
			HashMap<String, Object> hmAddrOfRecord = null;
			ArrayList alAddrOfRecord = CommonUtil.getArrayList();
			HashMap<String, Object> hmProbationaryAddress = null;
			if (hmAddressInfo.get("AddressOfRecord") != null) {
				hmAddrOfRecord = CommonUtil.getMap(hmAddressInfo, "AddressOfRecord");
				alAddrOfRecord.add(hmAddrOfRecord);
				hmCPNIConsHelperInput.put(CommonDefs.POSTAL_ADDRESS, alAddrOfRecord); // TODO
			}
		}

		hmCPNIConsHelperInput.put(CommonDefs.KEY_IGNORE_POSTAL_ADDRESS_VALIDATION, CommonDefs.IND_Y);

		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

		String sAcctSorInvId = (String) hmAnchorAccount.get(CommonDefs.BDS_BILLING_ID);
		if (sAcctSorInvId != null && sAcctSorInvId.length() > 0) {
			hmResult.put(CommonDefs.BDS_BILLING_ID, sAcctSorInvId);
		}
		hmResult.put("BDSAccountContacts", hmCPNIConsHelperInput);
		return hmResult;
	}

	private static String formatDate(String sDateKey, String sDateValue) {
		String sMethodName = ".formatDate.";
		Date dtParsedDate = null;
		String sFormattedDate = null;

		try {
			DateFormat sdfCustActiveDt = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat sdfTimeModified = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat sdfEmailAddrDt = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat newDtFormat = new SimpleDateFormat("MMddyyyy HH:mm:ss");
			DateFormat sdfPhoneModifiedDt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

			// parse input date
			if (sDateKey != null && sDateKey.equals(CommonDefs.CUSTOMER_ACTIVE_DATE))
				dtParsedDate = sdfCustActiveDt.parse(sDateValue);
			if (sDateKey != null && sDateKey.equals(CommonDefs.TIME_MODIFIED))
				dtParsedDate = sdfTimeModified.parse(sDateValue);
			if (sDateKey != null && sDateKey.equals("EmailAddrLastUpdateTs"))
				dtParsedDate = sdfEmailAddrDt.parse(sDateValue);
			if (sDateKey != null && sDateKey.equals("establishDate"))
				dtParsedDate = sdfEmailAddrDt.parse(sDateValue);

			if (sDateKey != null && sDateKey.equals("simSwapDateTime") && sDateValue != null && !sDateValue.isEmpty()) {

				sDateValue = sDateValue.substring(0, sDateValue.length() - 2);
				sDateValue += " " + TimeZone.getTimeZone("UTC").getDisplayName();
				DateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
				dtParsedDate = simpleDateFormat.parse(sDateValue);
				newDtFormat.setTimeZone(TimeZone.getTimeZone("US/Central"));
			}

			if (sDateKey != null && sDateKey.equals(CommonDefs.PHONE_MODIFIED_DATE)) {
				dtParsedDate = sdfPhoneModifiedDt.parse(sDateValue);

			}

			// convert to new date format
			sFormattedDate = newDtFormat.format(dtParsedDate);
			logger.info("{}{}ET_CPNI_FD_01 : {} : {}, Formatted Date : {}", sClassName, sMethodName, sDateKey, sDateValue,
					sFormattedDate);

		} catch (Exception exp) {
			logger.error("{}{}ET_CPNI_FD_02 : Exception = {}", sClassName, sMethodName, exp);
		}

		return sFormattedDate;
	}
	
	private HashMap processCBRCTNs(HashMap hmInput, String sAcctSorInvId) {
		HashMap<String, Object> hmResult = null;
		String sMethodName = ".processCBRCTNs.";
		String stAppStatusCode = null;
		String stAppInfo = null;
		ArrayList alCBRCTNs = CommonUtil.getArrayList();
		String sTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);
		String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
		String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
		String sAcctType = (String) hmInput.get(CommonDefs.ACCOUNT_TYPE);
		String stSkipAgingRuleFlag = (String) hmInput.get("skipAgingRuleFlag");
		
		if(StringUtils.isEmpty(stSkipAgingRuleFlag))
			stSkipAgingRuleFlag = CommonDefs.IND_N;

		if (sAcctType.equals(CommonDefs.TITAN_SERVICE)) {
			HashMap<String, String> hmCRMInp = CommonUtil.getHashMap();
			hmCRMInp.put(CommonDefs.TRANSACTION_ID, sTransactionId);
			hmCRMInp.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
			hmCRMInp.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
			hmCRMInp.put(CommonDefs.BAN, sAcctSorInvId);
			
        	HashMap<String, Object> hmGetAuthInfoResp = oQueryProfileProofingInfoH.queryCRMProofingInfo(hmCRMInp);
			logger.info(SpiMarker.getInstance(),"{}{}PCBR_1 : ResponseHash from queryCRMProofingInfo : {}", sClassName, sMethodName,
					hmGetAuthInfoResp);

			stAppStatusCode = (String) hmGetAuthInfoResp.get(CommonDefs.COMMON_APP_STATUS_CODE);

			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				stAppInfo = (String) hmGetAuthInfoResp.get(CommonDefs.COMMON_APP_INFO);
				logger.info("{}{}PCBR_2 : Error returned : {}", sClassName, sMethodName, stAppInfo);
			}
			if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
				HashMap<String, Object> hmCBRInfo = (HashMap<String, Object>) hmGetAuthInfoResp
						.get(CommonDefs.CBR_INFO);
				HashMap<String, Object> hmAltCBRInfo = (HashMap<String, Object>) hmGetAuthInfoResp
						.get(CommonDefs.ALT_CBR_INFO);

				if (hmCBRInfo != null && !hmCBRInfo.isEmpty() && hmCBRInfo.get(CommonDefs.PHONE) != null
						&& !hmCBRInfo.get(CommonDefs.PHONE).toString().isBlank()) {
					String sValidationStatusCode = (String) hmCBRInfo.get(CommonDefs.DEVICE_IN_HAND_VALIDATION_STS);
					if ((sValidationStatusCode != null && sValidationStatusCode.equals("8")) || stSkipAgingRuleFlag.equals(CommonDefs.IND_Y)) {
						HashMap<String, Object> hmContactInfo = CommonUtil.getHashMap();
						hmContactInfo.put(MPSDefs.DB_CONTACT_TYPE, CommonDefs.CONTACT_TYPE_PRIMARY_PHONE);
						hmContactInfo.put(MPSDefs.DB_CONTACT_STATUS, "V");
						hmContactInfo.put(CommonDefs.KEY_PHONE, hmCBRInfo.get(CommonDefs.PHONE));
						String stPhoneModifiedDate = (String) hmCBRInfo.get(CommonDefs.PHONE_MODIFIED_DATE);
						if (stPhoneModifiedDate != null && !stPhoneModifiedDate.isEmpty()) {
							stPhoneModifiedDate = formatDate(CommonDefs.PHONE_MODIFIED_DATE, stPhoneModifiedDate);
							hmContactInfo.put(CommonDefs.KEY_PHONE_EST_DATE, stPhoneModifiedDate);
						}

						String sPhoneType = (String) hmCBRInfo.get(CommonDefs.PHONE_TYPE);
						String sIsATTNumber = (String) hmCBRInfo.get(CommonDefs.IS_ATT_NUMBER);

						if (sIsATTNumber != null && sIsATTNumber.trim().equals("0")
								&& hmCBRInfo.get(CommonDefs.SUBSCRIBER_ID) != null) {
							sIsATTNumber = "1";
						}
						String sContactType = (String) CommonDefs.PHONE_TYPE_MAPPING.get(sPhoneType);
						if (sIsATTNumber != null && sIsATTNumber.trim().equals("0") && sContactType != null
								&& sContactType.equals(CommonDefs.PHONE_NUMBER_TYPE_MOBILE)) {
							hmContactInfo.put(CommonDefs.PHONE_NUMBER_TYPE, CommonDefs.PHONE_NUMBER_TYPE_MOBILE);
						} else if (sIsATTNumber != null && sIsATTNumber.trim().equals("1") && sContactType != null
								&& sContactType.equals(CommonDefs.PHONE_NUMBER_TYPE_MOBILE)) {
							hmContactInfo.put(CommonDefs.PHONE_NUMBER_TYPE, CommonDefs.PHONE_NUMBER_TYPE_ATTMOBILE);
						} else {
							hmContactInfo.put(CommonDefs.PHONE_NUMBER_TYPE, sContactType);
						}

						if(stSkipAgingRuleFlag.equals(CommonDefs.IND_Y))
							hmContactInfo.put(CommonDefs.CPNI_ELIGIBLE_EMAIL_FLAG, CommonDefs.IND_Y);
						alCBRCTNs.add(hmContactInfo);
					}
				}

				if (hmAltCBRInfo != null && !hmAltCBRInfo.isEmpty()
						&& hmAltCBRInfo.get(CommonDefs.PHONE) != null
						&& !hmAltCBRInfo.get(CommonDefs.PHONE).toString().isBlank()) {
					String sValidationStatusCode = (String) hmAltCBRInfo.get(CommonDefs.DEVICE_IN_HAND_VALIDATION_STS);
					if ((sValidationStatusCode != null && sValidationStatusCode.equals("8")) || stSkipAgingRuleFlag.equals(CommonDefs.IND_Y)) {
						HashMap<String, Object> hmContactInfo = CommonUtil.getHashMap();
						hmContactInfo.put(MPSDefs.DB_CONTACT_TYPE, CommonDefs.CONTACT_TYPE_SECONDARY_PHONE);
						hmContactInfo.put(MPSDefs.DB_CONTACT_STATUS, "V");
						hmContactInfo.put(CommonDefs.KEY_PHONE, hmAltCBRInfo.get(CommonDefs.PHONE));
						String stPhoneModifiedDate = (String) hmAltCBRInfo.get(CommonDefs.PHONE_MODIFIED_DATE);
						if (stPhoneModifiedDate != null && !stPhoneModifiedDate.isEmpty()) {
							stPhoneModifiedDate = formatDate(CommonDefs.PHONE_MODIFIED_DATE, stPhoneModifiedDate);
							hmContactInfo.put(CommonDefs.KEY_PHONE_EST_DATE, stPhoneModifiedDate);
						}

						String sPhoneType = (String) hmAltCBRInfo.get(CommonDefs.PHONE_TYPE);
						String sIsATTNumber = (String) hmAltCBRInfo.get(CommonDefs.IS_ATT_NUMBER);
						if (sIsATTNumber != null && sIsATTNumber.trim().equals("0")
								&& hmAltCBRInfo.get(CommonDefs.SUBSCRIBER_ID) != null) {
							sIsATTNumber = "1";
						}
						String sContactType = (String) CommonDefs.PHONE_TYPE_MAPPING.get(sPhoneType);
						if (sIsATTNumber != null && sIsATTNumber.trim().equals("0") && sContactType != null
								&& sContactType.equals(CommonDefs.PHONE_NUMBER_TYPE_MOBILE)) {
							hmContactInfo.put(CommonDefs.PHONE_NUMBER_TYPE, CommonDefs.PHONE_NUMBER_TYPE_MOBILE);
						} else if (sIsATTNumber != null && sIsATTNumber.trim().equals("1") && sContactType != null
								&& sContactType.equals(CommonDefs.PHONE_NUMBER_TYPE_MOBILE)) {
							hmContactInfo.put(CommonDefs.PHONE_NUMBER_TYPE, CommonDefs.PHONE_NUMBER_TYPE_ATTMOBILE);
						} else {
							hmContactInfo.put(CommonDefs.PHONE_NUMBER_TYPE, sContactType);
						}
						
						if(stSkipAgingRuleFlag.equals(CommonDefs.IND_Y))
							hmContactInfo.put(CommonDefs.CPNI_ELIGIBLE_EMAIL_FLAG, CommonDefs.IND_Y);
						
						alCBRCTNs.add(hmContactInfo);
					}
				}
			}
		} else if (sAcctType.equals(CommonDefs.ECOMM_SERVICE)) {
			HashMap<String, Object> hmInquireAcctContactInp = CommonUtil.getHashMap();
			hmInquireAcctContactInp.put(CommonDefs.TRANSACTION_ID, sTransactionId);
			hmInquireAcctContactInp.put(CommonDefs.TRANSACTION_NAME, "InquireAccountContactInfo");
			hmInquireAcctContactInp.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
			hmInquireAcctContactInp.put(CommonDefs.ACCOUNT_INVARIANT_ID, sAcctSorInvId);
			hmInquireAcctContactInp.put(CommonDefs.ACCOUNT_TYPE, CommonDefs.ECOMM_SERVICE);

			HashMap<String, Object> hmInquireAcctContactResp = (HashMap<String, Object>) oInquireAccountContactInfoHelper.inquireAccountContactInfo(hmInquireAcctContactInp);
			logger.info("{}{}PCBR_3 : ResponseHash from oInquireAccountContactInfoHelper : {}", sClassName, sMethodName,
					hmInquireAcctContactResp);

			stAppStatusCode = (String) hmInquireAcctContactResp.get(CommonDefs.COMMON_APP_STATUS_CODE);

			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				stAppInfo = (String) hmInquireAcctContactResp.get(CommonDefs.COMMON_APP_INFO);
				logger.info("{}{}PCBR_4 : Error returned : {}", sClassName, sMethodName, stAppInfo);
			}
			if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
				HashMap<String, Object> hmAccountContacts = (HashMap<String, Object>) hmInquireAcctContactResp
						.get("accountContacts");
				ArrayList alDBPhoneList = (ArrayList) hmAccountContacts.get("phoneList");
				if (alDBPhoneList != null && !alDBPhoneList.isEmpty()) {
					Iterator ialDBPhoneList = alDBPhoneList.iterator();

					while (ialDBPhoneList.hasNext()) {
						HashMap<String, Object> hmDBPhone = (HashMap<String, Object>) ialDBPhoneList.next();
						String sDBContactType = (String) hmDBPhone.get(CommonDefs.CONTACT_TYPE);
						String sDBContactStatus = (String) hmDBPhone.get(CommonDefs.CONTACT_STATUS);
						String sDBValidationStatus = (String) hmDBPhone.get(CommonDefs.VALIDATION_STATUS);

						if (sDBContactType != null && (sDBContactType.equals(CommonDefs.CONTACT_TYPE_PRIMARY_PHONE)
								|| sDBContactType.equals(CommonDefs.CONTACT_TYPE_SECONDARY_PHONE))
								&& hmDBPhone.get(CommonDefs.PHONE_NUMBER)!=null
								&& !hmDBPhone.get(CommonDefs.PHONE_NUMBER).toString().isBlank()) {
							if (sDBContactStatus != null && sDBContactStatus.equals("V") && sDBValidationStatus != null
									&& sDBValidationStatus.equals("8")) {
								HashMap<String, Object> hmContactInfo = CommonUtil.getHashMap();
								hmContactInfo.put(MPSDefs.DB_CONTACT_TYPE, sDBContactType);
								hmContactInfo.put(MPSDefs.DB_CONTACT_STATUS, sDBContactStatus);
								hmContactInfo.put(CommonDefs.KEY_PHONE, hmDBPhone.get(CommonDefs.PHONE_NUMBER));
								hmContactInfo.put(CommonDefs.KEY_PHONE_EST_DATE, hmDBPhone.get("dateEstablished"));
								hmContactInfo.put(CommonDefs.PHONE_NUMBER_TYPE,
										hmDBPhone.get(CommonDefs.PHONE_NUMBER_TYPE));

								alCBRCTNs.add(hmContactInfo);
							}
						}
					}
				}
			}
		}

		hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		if (alCBRCTNs != null && !alCBRCTNs.isEmpty()) {
			hmResult.put("CBRCTN", alCBRCTNs);
		}
		return hmResult;

	}
}
