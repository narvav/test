package com.att.idp.idgraphcontactinfoms.service.async;

import com.att.idp.idgraph.events.service.EventPublisher;
import com.att.idp.idgraphcontactinfoms.model.EventData;
import com.att.idp.idgraphcontactinfoms.model.EventDetails;
import com.att.idp.idgraphcontactinfoms.model.OTPEventModel;
import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

/**
 * Shared service for publishing OracleSecurityCodeSync events.
 * Consolidates common event publishing logic from GeneratePINBase, ValidatePINHelper, and DeletePINHelper.
 */
@Service
public class OracleSecurityCodeSyncPublisher {

    private static final Logger logger = LoggerFactory.getLogger(OracleSecurityCodeSyncPublisher.class);
    private static final String BINDING = "OracleSecurityCodeSync";
    private static final String RESOURCE_NAME = "OTP";

    @Autowired
    private EventPublisher eventPublisher;

    /**
     * Event type constants for different operations
     */
    public static final String EVENT_TYPE_INSERT = "INSERT";
    public static final String EVENT_TYPE_UPDATE = "UPDATE";
    public static final String EVENT_TYPE_DELETE = "DELETE";

    /**
     * Publishes an OracleSecurityCodeSync event with the given event data.
     *
     * @param accountId       The account ID used as the partition key for the event
     * @param eventDetailsType The type of event (INSERT, UPDATE, or DELETE)
     * @param eventData       The event data payload
     * @param operationLabel  A label for logging (e.g., "generatePin", "ValidatePIN", "DeletePIN")
     */
    public void publish(String accountId, String eventDetailsType, EventData eventData, String operationLabel) {
        logger.info("Publishing {} OTP event for accountId: {} to binding: {}",
                StringEscapeUtils.escapeJava(operationLabel),
                StringEscapeUtils.escapeJava(accountId),
                StringEscapeUtils.escapeJava(BINDING));

        OTPEventModel otpEventModel = buildOTPEventModel(eventDetailsType, eventData);
        eventPublisher.send(BINDING, accountId, otpEventModel);

        logger.info("Published {} OTP event: {}", operationLabel, otpEventModel);
    }

    /**
     * Builds the common OTPEventModel envelope with the provided event details type and data.
     *
     * @param eventDetailsType The type of event (INSERT, UPDATE, or DELETE)
     * @param eventData        The event data payload
     * @return The constructed OTPEventModel
     */
    private OTPEventModel buildOTPEventModel(String eventDetailsType, EventData eventData) {
        OTPEventModel otpEventModel = new OTPEventModel();
        otpEventModel.setEventId(UUID.randomUUID().toString());
        otpEventModel.setEventType(BINDING);
        otpEventModel.setResourceName(RESOURCE_NAME);
        otpEventModel.setEventTime(Instant.now());

        EventDetails eventDetails = new EventDetails();
        eventDetails.setType(eventDetailsType);
        eventDetails.setData(eventData);

        otpEventModel.setEventDetails(eventDetails);
        return otpEventModel;
    }
}
