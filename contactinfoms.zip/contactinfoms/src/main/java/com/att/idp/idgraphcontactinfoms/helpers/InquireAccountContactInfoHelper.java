package com.att.idp.idgraphcontactinfoms.helpers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphcontactinfoms.db.repository.InquireAccountContactInfoRepository;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import org.springframework.web.util.HtmlUtils;

/**
 * This method generates a PIN (Personal Identification Number) based on the input parameters.
 *
 * It first retrieves the identification type and account ID from the input HashMap.
 * Then, it validates the input data, processes the input data, and stores the data.
 * If the identification type is included in the 'CCMULE_IDENTIFICATION_TYPES' property, the method makes a synchronous call to the MULESOFT service.
 * If the identification type is not included in the 'CCMULE_IDENTIFICATION_TYPES' property, the method makes an asynchronous call.
 * The method then checks the response from the MULESOFT service. If the response indicates an error, the method constructs an error response and returns it.
 * If the response from the MULESOFT service indicates success, the method constructs a success response and returns it.
 * The success response includes the generated PIN and its expiration date.
 *
 * @param hmInput a HashMap that contains the input data for the PIN generation. The HashMap should include the identification type, account ID, and other necessary information.
 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code, an application info message, the generated PIN, and its expiration date.
 * @throws Exception if an error occurs during the operation.
 */
@Component
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class InquireAccountContactInfoHelper {
	
	public static final Logger logger = LoggerFactory.getLogger(InquireAccountContactInfoHelper.class);
	
	@Value("${PROP_INQUIRE_ACCOUNT_CONTACT_INFO_CSI}")
	private String stInquireAccountContactInfoCSI;
	
	@Autowired
	private InquireAccountContactInfoRepository inquireACIRepo;
	
	private static String sClassName = "InquireAccountContactInfoHelper"; 

	/**
	 * This method inquires account contact information based on the input parameters.
	 *
	 * It first retrieves the account type, account invariant ID, transaction name, calling system ID, and external call flag from the input HashMap.
	 * Then, it validates the input data. If the input data is invalid, the method constructs an error response and returns it.
	 * If the input data is valid, the method processes the input data and makes a call to the inquireACIRepo to inquire account contact information.
	 * The method then checks the response from the inquireACIRepo. If the response indicates an error, the method constructs an error response and returns it.
	 * If the response from the inquireACIRepo indicates success, the method constructs a success response and returns it.
	 * The success response includes the account contacts.
	 *
	 * @param hmInput a HashMap that contains the input data for the account contact information inquiry. The HashMap should include the account type, account invariant ID, transaction name, calling system ID, and other necessary information.
	 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code, an application info message, and the account contacts.
	 * @throws Exception if an error occurs during the operation.
	 */
	public Map<String, Object> inquireAccountContactInfo(Map<String,Object> hmInput) {
		String sMethodName = ".inquireAccountContactInfo.";

		logger.info("{}{}HLP000 : hmInput = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmInput)));
		HashMap<String, Object> hmResult = null;
		String stAppInfo = null;
		String stAppStatusCode = null;
		ArrayList alAccountInvariantIdList = null;
		Boolean isAcctIvdList = false;

		try {
			String sAccountType = (String) hmInput.get(CommonDefs.ACCOUNT_TYPE);
			String sAccountInvariantId = (String) hmInput.get(CommonDefs.ACCOUNT_INVARIANT_ID);
			String sInpTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sIsExternalCall = (String) hmInput.get(CommonDefs.IS_EXTERNAL_CALL);

			if (!"InquireAccountContactInfo".equals(sInpTransactionName)) {
				stAppInfo = "Transaction Not Allowed :: TransactionName Should be InquireAccountContactInfo";
				logger.info("{}{}IACI_01.1 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			if (sCallingSystemId != null && !sCallingSystemId.isEmpty()) {
				sCallingSystemId = sCallingSystemId.trim().toUpperCase();
				hmInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
			}

			if (sAccountType != null && !sAccountType.isEmpty()) {
				sAccountType = sAccountType.trim().toUpperCase();
				hmInput.put(CommonDefs.ACCOUNT_TYPE, sAccountType);
			}

			if (sAccountInvariantId != null && !sAccountInvariantId.isEmpty()) {
				sAccountInvariantId = sAccountInvariantId.trim();
				hmInput.put(CommonDefs.ACCOUNT_INVARIANT_ID, sAccountInvariantId);
				
			}else if(hmInput.containsKey("accountInvariantIdList")){ //2001
				alAccountInvariantIdList = (ArrayList) hmInput.get("accountInvariantIdList");
				if(alAccountInvariantIdList != null && !alAccountInvariantIdList.isEmpty()) {
					isAcctIvdList = true;
				}
			}

			if (sIsExternalCall != null && !sIsExternalCall.isEmpty()) {
				sIsExternalCall = sIsExternalCall.trim();
				hmInput.put(CommonDefs.IS_EXTERNAL_CALL, sIsExternalCall);
			}
			
			if ((sIsExternalCall != null && !sIsExternalCall.isEmpty())
					&& !(sIsExternalCall.equals(CommonDefs.IND_Y) || sIsExternalCall.equals(CommonDefs.IND_N))) {
				stAppInfo = "sIsExternalCall must be one of Y or N";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}IACI_01.1.0 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			
			if (sCallingSystemId == null || sCallingSystemId.isEmpty()) {
				stAppInfo = "CallingSystemId must be present";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}IACI_01.1.1 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			if (sAccountType == null || sAccountType.isEmpty()) {
				stAppInfo = "accountType must be present";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}IACI_01.2 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			
			if ((sAccountInvariantId == null || sAccountInvariantId.isEmpty()) && !isAcctIvdList) {
				stAppInfo = "AccountInvariantId must be present";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}IACI_01.3 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			ArrayList alInquireAccountContactInfoVaildCSI = CommonUtil.parseToArray(stInquireAccountContactInfoCSI,CommonDefs.VALUE_SEPARATOR_CHAR);
			
			if (CommonDefs.IND_Y.equalsIgnoreCase(sIsExternalCall) && (alInquireAccountContactInfoVaildCSI != null
					&& !alInquireAccountContactInfoVaildCSI.contains(sCallingSystemId))) {
				
				stAppInfo = "Invalid CallingSystemId passed in input";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}IACI_01.4 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;

			}

			ArrayList alSorIdList = new ArrayList();
			if (sAccountType.equals(CommonDefs.ECOMM_SERVICE)) {
				alSorIdList.add("16");
				alSorIdList.add("7");
			}

			else if (sAccountType.equals(CommonDefs.TITAN_SERVICE)) {
				alSorIdList.add("6");
			} else if (sAccountType.equals(CommonDefs.MOBILITY_SERVICE)) {
				alSorIdList.add("13");
			} else {
				stAppInfo = "unsupported accountType";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			HashMap<String, Object> hmDbHashMap = CommonUtil.getHashMap();
			
			if (isAcctIvdList) {
				hmDbHashMap.put("accountInvariantIdList", alAccountInvariantIdList);
			}else {
				hmDbHashMap.put(CommonDefs.ACCOUNT_INVARIANT_ID, sAccountInvariantId);
			}
		
			hmDbHashMap.put("sorIdList", alSorIdList);

			hmResult = (HashMap) inquireACIRepo.inquireAccountContactInfo(hmDbHashMap);

			if (hmResult == null || hmResult.isEmpty()) {
				stAppInfo = "QueryCPNIAccountContactInfoRepository returned null response.";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}IACI_01.5 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			stAppStatusCode = (String) hmResult.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				stAppInfo = (String) hmResult.get(CErrorDefs.COMMON_APP_INFO);
				
				if (stAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND)) {
					stAppInfo = "BAN not found in MPS.";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_BAN_NOT_FOUND_NUM, stAppInfo);
					
				}
				
				logger.info("{}{}IACI_01.6 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			HashMap<String, Object> hmAccountContacts = CommonUtil.getHashMap();
			if (hmResult != null && hmResult.containsKey(MPSDefs.DB_SERVICE_CONTACTS)) {

				ArrayList alServiceContactList = (ArrayList) hmResult.get(MPSDefs.DB_SERVICE_CONTACTS);

				if (alServiceContactList != null && !alServiceContactList.isEmpty()) {

					ArrayList alPhoneList = new ArrayList();
					ArrayList alEmailList = new ArrayList();
					for (int i = 0; i < alServiceContactList.size(); i++) {

						Map hmServiceContactHashMap = (Map) alServiceContactList.get(i);

						if (hmServiceContactHashMap != null && !hmServiceContactHashMap.isEmpty()) {

							if (hmServiceContactHashMap.get(MPSDefs.DB_CONTACT_TYPE).equals(CommonDefs.CONTACT_TYPE_PRIMARY_PHONE)
									|| hmServiceContactHashMap.get(MPSDefs.DB_CONTACT_TYPE).equals(CommonDefs.CONTACT_TYPE_SECONDARY_PHONE)
									|| ((String) hmServiceContactHashMap.get(MPSDefs.DB_CONTACT_TYPE))
											.contains("SMS_")) {

								stAppInfo = "contact type: " + hmServiceContactHashMap.get(MPSDefs.DB_CONTACT_TYPE);
								logger.info("{}{}IACI_02.1 : {}", sClassName, sMethodName, stAppInfo);

								HashMap<String, Object> hmPhone = CommonUtil.getHashMap();
								hmPhone.put(CommonDefs.CREATE_DATE,
										hmServiceContactHashMap.get(MPSDefs.DB_CREATE_DATE));
								hmPhone.put(CommonDefs.LAST_MODIFIED_BY,
										hmServiceContactHashMap.get(MPSDefs.DB_LAST_MODIFIED_BY));
								hmPhone.put(CommonDefs.LAST_MODIFIED,
										hmServiceContactHashMap.get(MPSDefs.DB_LAST_MODIFIED));
								hmPhone.put(CommonDefs.SOR_ID, hmServiceContactHashMap.get(MPSDefs.DB_SOR_ID));
								hmPhone.put(CommonDefs.KEY_SOR_NAME, hmServiceContactHashMap.get(MPSDefs.DB_SOR_NAME));
								hmPhone.put(CommonDefs.SOR_INVARIANT_ID,
										hmServiceContactHashMap.get(MPSDefs.DB_SOR_INVARIANT_ID));
								hmPhone.put(CommonDefs.CONTACT_TYPE,
										hmServiceContactHashMap.get(MPSDefs.DB_CONTACT_TYPE));
								hmPhone.put(CommonDefs.PHONE_NUMBER,
										hmServiceContactHashMap.get(MPSDefs.DB_PHONE_NUMBER));
								hmPhone.put(CommonDefs.PHONE_NUMBER_TYPE,
										hmServiceContactHashMap.get(MPSDefs.DB_PHONE_NUMBER_TYPE));
								hmPhone.put(CommonDefs.CONTACT_STATUS,
										hmServiceContactHashMap.get(MPSDefs.DB_CONTACT_STATUS));
								hmPhone.put("dateEstablished",
										hmServiceContactHashMap.get(MPSDefs.DB_DATE_ESTABLISHED));

								if (hmServiceContactHashMap.get(MPSDefs.DB_PHONE_NUMBER_EXT) != null
										&& !((String) hmServiceContactHashMap.get(MPSDefs.DB_PHONE_NUMBER_EXT))
												.isEmpty()) {
									hmPhone.put(CommonDefs.PHONE_NUMBER_EXT,
											hmServiceContactHashMap.get(MPSDefs.DB_PHONE_NUMBER_EXT));
								}

								if (hmServiceContactHashMap.get(MPSDefs.DB_VALIDATION_STATUS) != null
										&& !((String) hmServiceContactHashMap.get(MPSDefs.DB_VALIDATION_STATUS))
												.isEmpty()) {
									hmPhone.put(CommonDefs.VALIDATION_STATUS,
											hmServiceContactHashMap.get(MPSDefs.DB_VALIDATION_STATUS));
								}

								if (hmServiceContactHashMap.get(MPSDefs.DB_VALIDATION_INITIATED_DATE) != null
										&& !((String) hmServiceContactHashMap.get(MPSDefs.DB_VALIDATION_INITIATED_DATE))
												.isEmpty()) {
									hmPhone.put(CommonDefs.VALIDATION_INIT_DATE,
											hmServiceContactHashMap.get(MPSDefs.DB_VALIDATION_INITIATED_DATE));
								}

								alPhoneList.add(hmPhone);
							} else if (hmServiceContactHashMap.get(MPSDefs.DB_CONTACT_TYPE).equals(CommonDefs.CONTACT_TYPE_PRIMARY_EMAIL)
									|| hmServiceContactHashMap.get(MPSDefs.DB_CONTACT_TYPE).equals(CommonDefs.CONTACT_TYPE_SECONDARY_EMAIL)
									|| hmServiceContactHashMap.get(MPSDefs.DB_CONTACT_TYPE).equals(CommonDefs.CONTACT_TYPE_BUSINESS_EMAIL)
									|| hmServiceContactHashMap.get(MPSDefs.DB_CONTACT_TYPE).equals(CommonDefs.CONTACT_TYPE_TEXT_ACCOUNT_EMAIL)) {

								stAppInfo = "contact type: " + hmServiceContactHashMap.get(MPSDefs.DB_CONTACT_TYPE);
								logger.info("{}{}IACI_02.2 : {}", sClassName, sMethodName, stAppInfo);

								HashMap<String, Object> hmEmail = CommonUtil.getHashMap();
								hmEmail.put(CommonDefs.CREATE_DATE,
										hmServiceContactHashMap.get(MPSDefs.DB_CREATE_DATE));
								hmEmail.put(CommonDefs.LAST_MODIFIED_BY,
										hmServiceContactHashMap.get(MPSDefs.DB_LAST_MODIFIED_BY));
								hmEmail.put(CommonDefs.LAST_MODIFIED,
										hmServiceContactHashMap.get(MPSDefs.DB_LAST_MODIFIED));
								hmEmail.put(CommonDefs.SOR_ID, hmServiceContactHashMap.get(MPSDefs.DB_SOR_ID));
								hmEmail.put(CommonDefs.KEY_SOR_NAME, hmServiceContactHashMap.get(MPSDefs.DB_SOR_NAME));
								hmEmail.put(CommonDefs.SOR_INVARIANT_ID,
										hmServiceContactHashMap.get(MPSDefs.DB_SOR_INVARIANT_ID));
								hmEmail.put(CommonDefs.CONTACT_TYPE,
										hmServiceContactHashMap.get(MPSDefs.DB_CONTACT_TYPE));
								hmEmail.put(CommonDefs.EMAIL_ADDRESS,
										hmServiceContactHashMap.get(MPSDefs.DB_EMAIL_ADDRESS));
								hmEmail.put(CommonDefs.CONTACT_STATUS,
										hmServiceContactHashMap.get(MPSDefs.DB_CONTACT_STATUS));
								hmEmail.put("dateEstablished",
										hmServiceContactHashMap.get(MPSDefs.DB_DATE_ESTABLISHED));

								if (hmServiceContactHashMap.get(MPSDefs.DB_VALIDATION_STATUS) != null
										&& !((String) hmServiceContactHashMap.get(MPSDefs.DB_VALIDATION_STATUS))
												.isEmpty()) {
									hmEmail.put(CommonDefs.VALIDATION_STATUS,
											hmServiceContactHashMap.get(MPSDefs.DB_VALIDATION_STATUS));
								}

								if (hmServiceContactHashMap.get(MPSDefs.DB_VALIDATION_INITIATED_DATE) != null
										&& !((String) hmServiceContactHashMap.get(MPSDefs.DB_VALIDATION_INITIATED_DATE))
												.isEmpty()) {
									hmEmail.put(CommonDefs.VALIDATION_INIT_DATE,
											hmServiceContactHashMap.get(MPSDefs.DB_VALIDATION_INITIATED_DATE));
								}

								alEmailList.add(hmEmail);

							} else {
								stAppInfo = "DANGER----unsupported contact type: "
										+ hmServiceContactHashMap.get(MPSDefs.DB_CONTACT_TYPE);
								logger.info("{}{}IACI_02.3 : {}", sClassName, sMethodName, stAppInfo);
							}

						}

					}

					if (!alPhoneList.isEmpty()) {
						hmAccountContacts.put("phoneList", alPhoneList);
					}

					if (!alEmailList.isEmpty()) {
						hmAccountContacts.put("emailList", alEmailList);
					}

					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
					if (hmAccountContacts != null && !hmAccountContacts.isEmpty()) {
						hmResult.put("accountContacts", hmAccountContacts);
					}

				}
			}
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown validateCredentials method : " + hmResult;
			logger.error("{}{}IACI_03 : {}", sClassName, sMethodName, stAppInfo);

		} finally {
			if (hmResult == null || hmResult.isEmpty()) {
				stAppInfo = "Response Map is NULL or EMPTY";
				logger.error("{}{}HLP_20 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			}
			logger.info("{}{}HLP999 : hmResult = {}", sClassName, sMethodName, hmResult);
		}

		return hmResult;
	}
}