package com.att.idp.idgraphcontactinfoms.healthcheck;


import com.att.idp.idgraphcontactinfoms.queue.message.sender.JMSQueueSender;
import jakarta.jms.Connection;
import jakarta.jms.JMSException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import java.util.Objects;


@Component
public class JMHealthCheckIndicator extends AbstractHealthIndicator{

	private static Logger log = LoggerFactory.getLogger(JMHealthCheckIndicator.class);
	
	@Autowired
	private JmsTemplate jmsTemplate;

    @Autowired
    private JMSQueueSender jmsQueueSender;



    @Override
    protected void doHealthCheck(Health.Builder builder) {

        try (Connection conn = Objects.requireNonNull(jmsTemplate.getConnectionFactory()).createConnection()) {
            log.info("checking JMS HealthCheck ");
            conn.start();

            if (jmsQueueSender.isMessagePublished()) {
                log.info("JMS healthcheck is successful as message publisher flag is true");
                builder.up().withDetail("JmsHealthIndicator", "Connected and published to JMS queue successfully.");
            } else {
                log.error("JMS healthcheck failed as message publisher flag is false");
                builder.down().withDetail("JmsHealthIndicator", "Failed to publish message to JMS Queue.");
            }

        } catch (JMSException e) {
        	log.error("JMS HealthCheck failed");
            builder.down().withDetail("JmsHealthIndicator", e.getMessage());
                    
        }

    }
}
