package com.att.idp.idgraphcontactinfoms.cgclient.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
/**
 * The Contact class represents a contact in the system.
 * It implements the Serializable interface, which means its instances can be converted to a byte stream and
 * restored back to the same object later. This is useful for storing objects in a file or sending them over a network.
 *
 * This class contains a property related to a contact's medium, represented as a list of ContactMedium objects.
 * Each property has its corresponding getter and setter methods.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.cgclient.response package.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "contact")
@Getter
@Setter
@NoArgsConstructor
public class Contact implements Serializable {

	private static final long serialVersionUID = -9044795316818313777L;

	@JsonProperty("contactMedium")
	private List<ContactMedium> contactMedium;
}