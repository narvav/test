package com.att.idp.idgraphcontactinfoms.db.helper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.att.idp.idgraphcontactinfoms.metrics.ErrorMetricHandler;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphcontactinfoms.db.model.Tsecurityaccount;
import com.att.idp.idgraphcontactinfoms.db.model.Tsecuritycode;
import com.att.idp.idgraphcontactinfoms.db.repository.SecurityAccountDataRepository;
import com.att.idp.idgraphcontactinfoms.db.repository.SecurityCodeRepository;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.StatusMsg;

import net.logstash.logback.argument.StructuredArguments;

/**
 * The SecurityCodeDBHelper class is a helper class that interacts with the database to manage security codes and related data.
 *
 * It is annotated with @Component to indicate that it is an autodetectable bean, so Spring can pick it up and pull it into the application context.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.db.helper package.
 *
 * It contains two properties that are autowired: SecurityAccountDataRepository and SecurityCodeRepository. 
 * These are Spring Data JPA repositories used to interact with the SECURITYACCOUNT and SECURITYCODE tables in the database.
 *
 * It also contains a Logger property for logging purposes.
 *
 * The class defines several methods for managing security codes and related data, including:
 * - setSecurityCode: Inserts new security code information into the SECURITYCODE table.
 * - setSecurityAccountData: Inserts new security account information into the SECURITYACCOUNT table.
 * - updateSecurityAccount: Updates security account information in the SECURITYACCOUNT table.
 * - getSecurityAccountData: Retrieves security account information from the SECURITYACCOUNT table.
 * - deleteSecurityPIN: Deletes a security PIN from the SECURITYCODE table.
 * - updateSecurityCode: Updates a security code in the SECURITYCODE table.
 * - getSecurityCodeDataQuery: Retrieves security code data from the SECURITYCODE table.
 */
@Component
public class SecurityCodeDBHelper {

	private static String sClassName = "SecurityCodeDBHelper";
	public static final Logger logger = LoggerFactory.getLogger(SecurityCodeDBHelper.class);

	@Autowired
	private SecurityAccountDataRepository securityAccountDataRepository;

	@Autowired
	private SecurityCodeRepository securityCodeRepository;

	@Autowired
	private ErrorMetricHandler errorMetricHandler;

	/**
	 * This method is responsible for inserting new security code information into the SECURITYCODE table.
	 *
	 * It takes a HashMap as an input parameter, which contains key-value pairs of the security code details to be inserted.
	 * The keys in the HashMap can include various security code related parameters.
	 *
	 * The method first logs the input parameters for debugging purposes.
	 * Then, it calls the setSecurityCode method of the securityCodeRepository to execute the insert operation.
	 *
	 * If the insert operation is successful, the method returns a HashMap containing a success message and the number of rows inserted.
	 * If a unique constraint violation occurs during the insert operation, it returns a HashMap containing an error message indicating that the account already exists.
	 * For other exceptions, it returns a HashMap containing an error message based on the exception.
	 *
	 * @param InpParam a HashMap containing the security code details to be inserted.
	 * @return a HashMap containing the result of the insert operation.
	 */
	public HashMap<String, Object> setSecurityCode(HashMap<String, Object> InpParam) {
		String sMethodName = ".setSecurityCode.";
		HashMap<String, Object> resultHash = null;
		int rowCount = 0;
		logger.info("{}{}DBTOOLS000 : InpParam = {}", sClassName, sMethodName, InpParam);

		try {

			rowCount = securityCodeRepository.setSecurityCode(InpParam);
			logger.info("{}{}DBSC_001 : rowCount = {}", sClassName, sMethodName, rowCount);

			resultHash = StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS, MPSDefs.MPS_ALL_OK, "0", MPSDefs.SQL_SUCCESS,
					MPSDefs.SQL_SUCCESS_MSG, Integer.toString(rowCount));

		} catch (Exception e) {
			if (e.getMessage().contains("ORA-00001: unique constraint")) {
				resultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ACCOUNT_ALREADY_EXISTS_NUM,
						CErrorDefs.ERR_ACCOUNT_ALREADY_EXISTS_MSG);
				logger.info("{}{}DBSC_002 : resultHash :: {}", sClassName, sMethodName, resultHash);
			} else {
				resultHash = StatusMsg.makeExceptionSQLStatus(e);
				logger.error("{}{}DBSC_003 : Error:: {}", sClassName, sMethodName, e.getMessage());
				logger.error("{}{}DBSC_004 : Exception = {}", sClassName, sMethodName, e);
			}

		} finally {
			logger.info("{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, resultHash);
		}
		return resultHash;
	}

	/**
	 * This method is responsible for inserting new security account information into the SECURITYACCOUNT table.
	 *
	 * It takes a HashMap as an input parameter, which contains key-value pairs of the security account details to be inserted.
	 * The keys in the HashMap can include various security account related parameters.
	 *
	 * The method first logs the input parameters for debugging purposes.
	 * Then, it calls the setSecurityAccountData method of the securityAccountDataRepository to execute the insert operation.
	 *
	 * If the insert operation is successful, the method returns a HashMap containing a success message and the number of rows inserted.
	 * If a unique constraint violation occurs during the insert operation, it returns a HashMap containing an error message indicating that the account already exists.
	 * For other exceptions, it returns a HashMap containing an error message based on the exception.
	 *
	 * @param InpParam a HashMap containing the security account details to be inserted.
	 * @return a HashMap containing the result of the insert operation.
	 */
	public HashMap<String, Object> setSecurityAccountData(HashMap<String, Object> InpParam) {
		String sMethodName = ".setSecurityAccountData.";
		logger.info("{}{}DBTOOLS000 : InpParam = {}", sClassName, sMethodName, InpParam);

		HashMap<String, Object> resultHash = null;

		try {

			int rowCount = securityAccountDataRepository.setSecurityAccountData(InpParam);
			logger.info("{}{}DBSA_001 : rowCount = {}", sClassName, sMethodName, rowCount);

			resultHash = StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS, MPSDefs.MPS_ALL_OK, "0", MPSDefs.SQL_SUCCESS,
					MPSDefs.SQL_SUCCESS_MSG, Integer.toString(rowCount));
		} catch (Exception e) {
			if (e.getMessage().contains("ORA-00001: unique constraint")) {

				resultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ACCOUNT_ALREADY_EXISTS_NUM,
						CErrorDefs.ERR_ACCOUNT_ALREADY_EXISTS_MSG);

				logger.info("{}{}DBSA_002 : resultHash :: {}", sClassName, sMethodName, resultHash);
			} else {

				resultHash = StatusMsg.makeExceptionSQLStatus(e);
				logger.error("{}{}DBSA003 : Error:: {}", sClassName, sMethodName, e.getMessage());
				logger.error("{}{}DBSA004 : Exception = {}", sClassName, sMethodName, e);
			}

		} finally {
			logger.info("{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, resultHash);
		}
		return resultHash;
	}

	/**
	 * This method is responsible for updating security account information in the SECURITYACCOUNT table.
	 *
	 * It takes a HashMap as an input parameter, which contains key-value pairs of the security account details to be updated.
	 * The keys in the HashMap can include various security account related parameters.
	 *
	 * The method first logs the input parameters for debugging purposes.
	 * Then, it retrieves the cumulative failure count for the account from the database.
	 * After that, it calls the updateSecurityAccount method of the securityAccountDataRepository to execute the update operation.
	 *
	 * If the update operation is successful, the method returns a HashMap containing a success message and the number of rows updated.
	 * If an exception occurs during the update operation, it returns a HashMap containing an error message based on the exception.
	 *
	 * @param InpParam a HashMap containing the security account details to be updated.
	 * @param isSaveSecurityCode a boolean indicating whether to save the security code.
	 * @return a HashMap containing the result of the update operation.
	 */
	public HashMap<String, Object> updateSecurityAccount(HashMap<String, Object> InpParam,
			boolean isSaveSecurityCode) {

		String sMethodName = ".updateSecurityAccount.";
		logger.info(sClassName + sMethodName + "DBTOOLS000 : " + "InpParam = " + InpParam);

		HashMap<String, Object> resultHash = null;
		int rowCount = 0;
		String identification_type = "";
		String account_id = "";
		try {

			identification_type = (String) InpParam.get(MPSDefs.DB_IDENTIFICATION_TYPE);
			identification_type = (identification_type.toUpperCase()).trim();
			account_id = (String) InpParam.get(MPSDefs.DB_ACCOUNT_ID);
			account_id = account_id.trim();

			Long cumulativeFailureCount = securityAccountDataRepository.getCumulativeFailureCount(identification_type,
					account_id);
			rowCount = securityAccountDataRepository.updateSecurityAccount(InpParam, isSaveSecurityCode,
					cumulativeFailureCount);

			resultHash = StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS, MPSDefs.MPS_ALL_OK, "0", MPSDefs.SQL_SUCCESS,
					MPSDefs.SQL_SUCCESS_MSG, Integer.toString(rowCount));
		} catch (Exception e) {
			resultHash = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}DBUSA_01 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}DBUSA_02 : Exception = {}", sClassName, sMethodName, e);
		} finally {
			logger.info("{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, resultHash);
		}
		return resultHash;
	}

	/**
	 * This method is responsible for retrieving security account information from the SECURITYACCOUNT table.
	 *
	 * It takes a HashMap as an input parameter, which contains key-value pairs of the security account details to be retrieved.
	 * The keys in the HashMap can include various security account related parameters.
	 *
	 * The method first logs the input parameters for debugging purposes.
	 * Then, it retrieves the security account information from the SECURITYACCOUNT table using the getSecurityAccountData method of the securityAccountDataRepository.
	 *
	 * If the retrieval operation is successful, the method returns a HashMap containing the retrieved security account information.
	 * If no rows are found in the SECURITYACCOUNT table for the given parameters, it returns a HashMap containing an error message.
	 * If an exception occurs during the retrieval operation, it returns a HashMap containing an error message based on the exception.
	 *
	 * @param inpParamHash a HashMap containing the security account details to be retrieved.
	 * @return a HashMap containing the result of the retrieval operation.
	 */

	public HashMap<String, Object> getSecurityAccountData(HashMap<String, Object> inpParamHash) {
		String sMethodName = ".getSecurityAccountData.";
		logger.info("{}{}DBTOOLS000 : InpParam = {}", sClassName, sMethodName, inpParamHash);

		HashMap<String, Object> resultHash = null;
		String identification_type = "";
		String account_id = "";

		List<Tsecurityaccount> securityList = new ArrayList<>();

		try {

			identification_type = (String) inpParamHash.get(MPSDefs.DB_IDENTIFICATION_TYPE);
			account_id = (String) inpParamHash.get(MPSDefs.DB_ACCOUNT_ID);

			if (identification_type != null && (identification_type = identification_type.trim()).length() != 0) {

				logger.info("{}{}DBGSA_01 : identification_type = {}", sClassName, sMethodName,
						identification_type.toUpperCase());
			} else {
				resultHash = StatusMsg.makeSQLStatus(MPSDefs.ERR_EMPTY, MPSDefs.ERR_EMPTY_MSG, "Required Field missing",
						MPSDefs.SQL_ERR, MPSDefs.SQL_ERR_MSG, MPSDefs.NO_ROW_UPDATED);

				logger.info("{}{}DBGSA_01.1 : Required Field  identification_type is Missing", sClassName, sMethodName);

				return resultHash;
			}

			if (account_id != null && (account_id = account_id.trim()).length() != 0) {
				logger.info("{}{}DBGSA_02 : account_id = {}", sClassName, sMethodName, account_id.toLowerCase());
			} else {
				resultHash = StatusMsg.makeSQLStatus(MPSDefs.ERR_EMPTY, MPSDefs.ERR_EMPTY_MSG, "Required Field missing",
						MPSDefs.SQL_ERR, MPSDefs.SQL_ERR_MSG, MPSDefs.NO_ROW_UPDATED);

				logger.info("{}{}DBGSA_02.1 : Required Field account_id is Missing", sClassName, sMethodName);
				return resultHash;
			}

			securityList = securityAccountDataRepository.getSecurityAccountData(identification_type, account_id);

			logger.debug("{}{}DBGSA_02.2 Security Account List Size : {}", sClassName, sMethodName,
					securityList.size());

			resultHash = CommonUtil.getHashMap();

			for (Tsecurityaccount securityAccount : securityList) {

				resultHash.put(MPSDefs.DB_ACCOUNT_TYPE, securityAccount.getAccountType());
				resultHash.put(MPSDefs.DB_ACCOUNT_REGION, securityAccount.getAccountRegion());
				resultHash.put(MPSDefs.DB_CUMULATIVE_FAILURE_COUNT, securityAccount.getCumulativeFailureCount());
				resultHash.put(MPSDefs.DB_ACCOUNT_ENTRY_EXPIRES, securityAccount.getAccountEntryExpires());
				resultHash.put(MPSDefs.DB_CREATE_DATE, securityAccount.getCreateDate());
			}

			resultHash.put(MPSDefs.APP_STATUS_CODE, MPSDefs.MPS_SUCCESS);
			resultHash.put(MPSDefs.APP_STATUS_MSG, MPSDefs.MPS_ALL_OK);
			resultHash.put(MPSDefs.APP_CATEGORY_CODE, MPSDefs.MPS_SUCCESS_MSG);
			resultHash.put(MPSDefs.SQLCODE, MPSDefs.SQL_SUCCESS);
			resultHash.put(MPSDefs.SQLMSG, MPSDefs.SQL_SUCCESS_MSG);

			if (securityList.isEmpty()) {
				resultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
						CErrorDefs.ERR_REC_NOT_FOUND_MSG);
				logger.info("{}{}DBGSA_08.2 : No row found", sClassName, sMethodName);
				return resultHash;
			}
		} catch (Exception e) {
			resultHash = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}DBGSAE01 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}DBGSAE_02 : Exception = {}", sClassName, sMethodName, e);
		} finally {
			logger.info("{}{}DBTOOLS999 : response : {}", sClassName, sMethodName, resultHash);
		}
		return resultHash;
	}

	/**
	 * This method is responsible for deleting a security PIN from the SECURITYCODE table.
	 *
	 * It takes a HashMap and a boolean flag as input parameters. The HashMap contains key-value pairs of the security PIN details to be deleted.
	 * The keys in the HashMap can include various security PIN related parameters.
	 * The boolean flag indicates whether all security PINs should be deleted.
	 *
	 * The method first logs the input parameters for debugging purposes.
	 * Then, based on the boolean flag, it either deletes all security PINs for the account or only the specified security PIN.
	 *
	 * If the delete operation is successful, the method returns a HashMap containing a success message and the number of rows deleted.
	 * If no rows are found in the SECURITYCODE table for the given parameters, it returns a HashMap containing an error message.
	 * If an exception occurs during the delete operation, it returns a HashMap containing an error message based on the exception.
	 *
	 * @param hmInput a HashMap containing the security PIN details to be deleted.
	 * @param isDeleteAllFlag a boolean indicating whether all security PINs should be deleted.
	 * @return a HashMap containing the result of the delete operation.
	 */
	public HashMap<String, Object> deleteSecurityPIN(HashMap<String, Object> hmInput, boolean isDeleteAllFlag) {

		String sMethodName = ".deleteSecurityPIN.";
		HashMap<String, Object> hmResponse = null;
		String sAppInfo = null;

		try {

			logger.info(SpiMarker.getInstance(), "SecurityCodeDBHelper.deleteSecurityPIN.DBTOOLS000 :: Input Hash",
					StructuredArguments.entries(hmInput));

			int rowCount = 0;

			String identification_type = (String) hmInput.get(MPSDefs.DB_IDENTIFICATION_TYPE);
			String account_id = (String) hmInput.get(MPSDefs.DB_ACCOUNT_ID);
			String security_code = (String) hmInput.get(MPSDefs.DB_SECURITY_CODE);
			String reason_code = (String) hmInput.get(MPSDefs.DB_REASON_CODE);

			if (isDeleteAllFlag) {

				rowCount = securityCodeRepository.deleteByIdIdentificationTypeAndIdAccountId(identification_type,
						account_id);
				logger.info("{}{} DBDSP_1.0 : SecurityCode table row deleted = {}", sClassName, sMethodName, rowCount);
				if (rowCount == 0) {
					sAppInfo = "No Record Found in SECURITYCODE table for this account.";
					logger.info("{}{} DBDSP_2.0 :: {}", sClassName, sMethodName, sAppInfo);
					hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "SUCCESS");
					return hmResponse;
				}
			} else {

				rowCount = securityCodeRepository.updateBySecurityCodeId(reason_code, identification_type, account_id,
						security_code);

				logger.info("{}{} DBDSP_3.0 : SecurityCode table row updated = {}", sClassName, sMethodName, rowCount);

				if (rowCount == 0) {
					sAppInfo = "No Record Found in SECURITYCODE table for this account and SecurityCode. ";
					logger.info("{}{} DBDSP_4.0 :: {}", sClassName, sMethodName, sAppInfo);
					hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INCORRECT_CODE_NUM, sAppInfo);
					return hmResponse;
				}
			}
			hmResponse = StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS, MPSDefs.MPS_ALL_OK, "0", MPSDefs.SQL_SUCCESS,
					MPSDefs.SQL_SUCCESS_MSG, Integer.toString(rowCount));
		} catch (Exception e) {
			hmResponse = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}DBHLPE01 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}DBHLPE02 : " + "Exception = {}", sClassName, sMethodName, e);
			errorMetricHandler.recordDBErrorMetric(e.getMessage());
		} finally {
			logger.info("{}{} DBTOOLS999 :: {}", sClassName, sMethodName, hmResponse);
		}
		return hmResponse;
	}

	/**
	 * This method is responsible for updating a security code in the SECURITYCODE table.
	 *
	 * It takes a HashMap and a String as input parameters. The HashMap contains key-value pairs of the security code details to be updated.
	 * The keys in the HashMap can include various security code related parameters.
	 * The String parameter represents the event that triggers the update operation.
	 *
	 * The method first logs the input parameters for debugging purposes.
	 * Then, based on the event, it either increments the failure count for the security code or unlocks the security codes.
	 *
	 * If the update operation is successful, the method returns a HashMap containing a success message and the number of rows updated.
	 * If an exception occurs during the update operation, it returns a HashMap containing an error message based on the exception.
	 *
	 * @param InpParam a HashMap containing the security code details to be updated.
	 * @param event a String representing the event that triggers the update operation.
	 * @return a HashMap containing the result of the update operation.
	 */
	public HashMap<String, Object> updateSecurityCode(HashMap<String, Object> InpParam, String event) {

		String sMethodName = ".updateSecurityCode.";
		logger.info("{}{}DBTOOLS000 : InpParam = {}", sClassName, sMethodName, InpParam);

		HashMap<String, Object> resultHash = null;
		int rowCount_SecurityCode = 0;

		String identification_type = (String) InpParam.get(MPSDefs.DB_IDENTIFICATION_TYPE);
		if (identification_type != null) {
			identification_type = (identification_type.toUpperCase()).trim();
		}
		String account_id = (String) InpParam.get(MPSDefs.DB_ACCOUNT_ID);
		if (account_id != null) {
			account_id = (account_id.toLowerCase()).trim();
		}

		String last_modified_by = (String) InpParam.get(MPSDefs.DB_LAST_MODIFIED_BY);
		if (last_modified_by != null) {
			last_modified_by = last_modified_by.trim();
		}

		try {

			if (event.equals(MPSDefs.INCREMENT_FAILURE_COUNT)) {

				String maxFailureCountStr = (String) InpParam.get(MPSDefs.MAX_FAILURE_COUNT);
				int max_failure_count = Integer.parseInt(maxFailureCountStr);
				String security_code_status = (String) InpParam.get(MPSDefs.DB_REASON_CODE);
				logger.info("{}{}DBUSC_01 : last_modified_by = {}", sClassName, sMethodName, last_modified_by);
				logger.info("{}{}DBUSC_02 : identification_type = {}", sClassName, sMethodName, identification_type);
				logger.info("{}{}DBUSC_03 : account_id = {}", sClassName, sMethodName, account_id);
				logger.info("{}{}DBUSC_04 : max_failure_count = {}", sClassName, sMethodName, max_failure_count);
				logger.info("{}{}DBUSC_05 : reasonCode = {}", sClassName, sMethodName, security_code_status);

				rowCount_SecurityCode = securityCodeRepository.updateSecurityCdByIncVeriffailCntSql(last_modified_by,
						identification_type, account_id, max_failure_count, security_code_status);
			}
			if (event.equals(MPSDefs.UNLOCK_SECURITY_CODES)) {

				logger.info("{}{}DBUSC_06 : last_modified_by = {}", sClassName, sMethodName, last_modified_by);
				logger.info("{}{}DBUSC_07 : identification_type = {}", sClassName, sMethodName, identification_type);
				logger.info("{}{}DBUSC_08 : account_id = {}", sClassName, sMethodName, account_id);

				rowCount_SecurityCode = securityCodeRepository.updateSecurityCdUnlockSql(identification_type,
						last_modified_by, account_id);
			}

			logger.info("{}{}DBUSC_09 : SecurityCode table row updated = {}", sClassName, sMethodName,
					rowCount_SecurityCode);

			resultHash = StatusMsg.makeSQLStatus(MPSDefs.MPS_SUCCESS, MPSDefs.MPS_ALL_OK, "0", MPSDefs.SQL_SUCCESS,
					MPSDefs.SQL_SUCCESS_MSG, Integer.toString(rowCount_SecurityCode));
		} catch (Exception e) {
			resultHash = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}DBUSCE01 : Error:: {}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}DBUSCE02 : Exception = {}", sClassName, sMethodName, e);
		} finally {
			logger.info("{}{}DBTOOLS999 response : {}", sClassName, sMethodName, resultHash);
		}
		return resultHash;
	}
	
	/**
	 * This method is responsible for retrieving security code data from the SECURITYCODE table.
	 *
	 * It takes a HashMap as an input parameter, which contains key-value pairs of the security code details to be retrieved.
	 * The keys in the HashMap can include various security code related parameters.
	 *
	 * The method first logs the input parameters for debugging purposes.
	 * Then, it retrieves the security code data from the SECURITYCODE table using the getSecurityCodeDataQuery method of the securityCodeRepository.
	 *
	 * If the retrieval operation is successful, the method returns a HashMap containing the retrieved security code data.
	 * If no rows are found in the SECURITYCODE table for the given parameters, it returns a HashMap containing an error message.
	 * If an exception occurs during the retrieval operation, it returns a HashMap containing an error message based on the exception.
	 *
	 * @param inpParamHash a HashMap containing the security code details to be retrieved.
	 * @return a Map containing the result of the retrieval operation.
	 */
	public Map<String, Object> getSecurityCodeDataQuery(HashMap<String, Object> inpParamHash) {

		String sMethodName = ".getSecurityCodeDataQuery.";

		logger.info("{}{}DBTOOLS000 : {}" + "InpParam = " ,sClassName , sMethodName , inpParamHash);

		HashMap<String, Object> resultHash = null;
		ArrayList<Object> alSecurityCode = CommonUtil.getArrayList();
		List<Tsecuritycode> securityCodeList = null;
		String identification_type = "";
		String account_id = "";
		double dbUnlockPeriod = 0.0;

		try {
			identification_type = (String) inpParamHash.get(MPSDefs.DB_IDENTIFICATION_TYPE);
			identification_type = (identification_type.toUpperCase()).trim();
			account_id = (String) inpParamHash.get(MPSDefs.DB_ACCOUNT_ID);
			account_id = account_id.trim();

			securityCodeList = securityCodeRepository.getSecurityCodeDataQuery(identification_type, account_id);
			
			logger.debug("{}{}DBGSCQ_01 : GetSecurityCodeDataQuery List Size : {} GetSecurityCodeDataQuery List : {}",sClassName , sMethodName ,securityCodeList.size() , securityCodeList);


				if (identification_type != null && (identification_type = identification_type.trim()).length() != 0) {
					logger.info("{}{}DBGSCQ_02 :identification_type = {}",sClassName , sMethodName ,
								 identification_type.toUpperCase());
				} else {
					resultHash = StatusMsg.makeSQLStatus(MPSDefs.ERR_EMPTY, MPSDefs.ERR_EMPTY_MSG,
							"Required Field missing", MPSDefs.SQL_ERR, MPSDefs.SQL_ERR_MSG, MPSDefs.NO_ROW_UPDATED);
					logger.info("{}{}DBGSCQ_03 : Required Field identification_type is Missing",sClassName , sMethodName);
					return resultHash;
				}

				if (account_id != null && (account_id = account_id.trim()).length() != 0) {
					logger.info("{}{}DBGSCQ_04 : account_id = {}"
								,sClassName , sMethodName, account_id.toLowerCase());

				} else {
					resultHash = StatusMsg.makeSQLStatus(MPSDefs.ERR_EMPTY, MPSDefs.ERR_EMPTY_MSG,
							"Required Field missing", MPSDefs.SQL_ERR, MPSDefs.SQL_ERR_MSG, MPSDefs.NO_ROW_UPDATED);
					logger.info("{}{}DBGSCQ_04 : Required Field account_id is Missing",sClassName , sMethodName);
					return resultHash;
				}


			resultHash = CommonUtil.getHashMap();

			for (Tsecuritycode secCode : securityCodeList) {
				HashMap<String, Object> hmSecurityCode = CommonUtil.getHashMap();
				hmSecurityCode.put(MPSDefs.DB_SECURITY_CODE, secCode.getId().getSecurityCode());
				hmSecurityCode.put(MPSDefs.DB_VERIFICATION_FAILURE_COUNT, secCode.getVerificationFailureCount());
				hmSecurityCode.put(MPSDefs.DB_SECURITY_CODE_EXPIRES, DateFormatUtils.format(secCode.getSecurityCodeExpires(), "MMddyyyy HH:mm:ss"));
				hmSecurityCode.put(MPSDefs.DB_CREATE_DATE, DateFormatUtils.format(secCode.getCreateDate(),"MMddyyyy HH:mm:ss"));
				hmSecurityCode.put(MPSDefs.DB_SOR_NAME,
						(secCode.getTsystemofrecord() != null ? secCode.getTsystemofrecord().getSorName() : null));
				hmSecurityCode.put(MPSDefs.DB_SOR_INVARIANT_ID, secCode.getSorInvariantId());
				hmSecurityCode.put(MPSDefs.DB_PASSCODE_VENC, secCode.getPasscodeVenc());

				hmSecurityCode.put(MPSDefs.DB_DELIVERY_METHOD, secCode.getDeliveryMethod());
				hmSecurityCode.put(MPSDefs.DB_DELIVERY_DETAIL, secCode.getDeliveryDetail());
				
				//added for inquirePIN
				hmSecurityCode.put("security_code_status", secCode.getSecurityCodeStatus());
				hmSecurityCode.put(MPSDefs.DB_LAST_MODIFIED_BY, secCode.getLastModifiedBy());

				if (inpParamHash.containsKey(MPSDefs.GET_EXCEEDED_UNLOCKED_TIME)
						&& (inpParamHash.get(MPSDefs.GET_EXCEEDED_UNLOCKED_TIME).equals(MPSDefs.YES))) {

					if (inpParamHash.containsKey(MPSDefs.UNLOCK_PERIOD)) {
						Object o = inpParamHash.get(MPSDefs.UNLOCK_PERIOD);
						Double dbUnlockPeriodObj = (Double) o;
						dbUnlockPeriod = dbUnlockPeriodObj.doubleValue();
						Date dbSystemDate = securityCodeRepository.getDbCurrentDate();
						logger.info("{}{}DBGSCQ_05 : DB Current Date : {}" ,sClassName , sMethodName,dbSystemDate);
						long dbSystemDateTimeInMillis = dbSystemDate.getTime();
						String lastModified = "";

						if (secCode.getLastModified() != null) {
							lastModified = DateFormatUtils.format(secCode.getLastModified(), "MM/dd/yyyy HH:mm:ss");
							logger.info("{}{}DBGSCQ_06 : Last Modified Date Format to 24 Hours : {}" ,sClassName , sMethodName,lastModified);
						}
						logger.info("{}{}DBGSCQ_07 : Security Code Last Modified Date : {}", sClassName , sMethodName,lastModified);

						long diffInMillies = (dbSystemDateTimeInMillis - stringToDate(lastModified).getTime());
						long minutes = TimeUnit.MILLISECONDS.toMinutes(diffInMillies);

						double numberOfMinutesDifference = Long.valueOf(minutes).doubleValue();

						Double exceededUnlockTime = Double.valueOf(numberOfMinutesDifference - dbUnlockPeriod);

						//long days = TimeUnit.MILLISECONDS.toDays(diffInMillies);

						//double numberOfDaysDifference = Long.valueOf(days).doubleValue();
						//Double exceededUnlockTime = Double.valueOf(numberOfDaysDifference - dbUnlockPeriod);

						logger.info("{}{}DBGSCQ_08 : Exceeded Unlock Time : {}",sClassName , sMethodName, exceededUnlockTime);

						hmSecurityCode.put(MPSDefs.EXCEEDED_UNLOCKED_TIME, String.valueOf(exceededUnlockTime));
					}
				}
				alSecurityCode.add(hmSecurityCode);
			}
			resultHash.put(MPSDefs.APP_STATUS_CODE, MPSDefs.MPS_SUCCESS);
			resultHash.put(MPSDefs.APP_STATUS_MSG, MPSDefs.MPS_ALL_OK);
			resultHash.put(MPSDefs.APP_CATEGORY_CODE, MPSDefs.MPS_SUCCESS_MSG);
			resultHash.put(MPSDefs.SQLCODE, MPSDefs.SQL_SUCCESS);
			resultHash.put(MPSDefs.SQLMSG, MPSDefs.SQL_SUCCESS_MSG);
			resultHash.put(MPSDefs.SECURITY_CODE_COUNT, Integer.toString(securityCodeList.size()));
			resultHash.put(MPSDefs.SECURITY_CODE_INFO, alSecurityCode);

			if (securityCodeList.isEmpty()) {
				resultHash = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM,
							 								CErrorDefs.ERR_REC_NOT_FOUND_MSG);
				logger.info("{}{}DBGSCQ_09 : No row found",sClassName , sMethodName);
				return resultHash;
			}
		} catch (Exception e) {
			resultHash = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}DBGSCE01 :  Error:: {}" ,sClassName , sMethodName, e.getMessage());
			logger.error("{}{}DBGSCE02 : Exception = {}",sClassName , sMethodName, e);
			errorMetricHandler.recordDBErrorMetric(e.getMessage());
		} finally {
			logger.info("{}{}DBTOOLS999 : response : {}" ,sClassName , sMethodName, resultHash);
		}
		return resultHash;
	}
	
	/**
	 * This method is responsible for returning dbtimezone.
	 *
	 *
	 * @return a String representation of DB timezone
	 */
	public String getDbTimeZone() {

		return securityCodeRepository.getDbTimeZone();
	}
	
	/**
	 * This method is responsible for converting a string representation of a date into a Date object.
	 *
	 * It takes a string as an input parameter, which represents the date in the format "MM/dd/yyyy HH:mm:ss".
	 *
	 * The method uses the SimpleDateFormat class to parse the string into a Date object.
	 * If the parsing is successful, the method returns the Date object.
	 * If a ParseException occurs during the parsing operation, it logs the exception and returns null.
	 *
	 * @param dateString a String representing the date to be converted.
	 * @return a Date object representing the parsed date, or null if a ParseException occurred.
	 */
	public static Date stringToDate(String dateString) {

		Date date = null;
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

		try {
			date = sdf.parse(dateString);
		} catch (ParseException ex) {
			logger.error("Exception parsing date '" + dateString + "'", ex);
		}
		return date;
	}

	
}