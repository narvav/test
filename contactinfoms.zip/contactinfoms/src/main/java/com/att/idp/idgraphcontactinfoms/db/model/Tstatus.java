package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "TSTATUS", schema = "MPS_OWNER", uniqueConstraints = @UniqueConstraint(columnNames = "STATUS_NAME"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tstatus implements Serializable {

	private static final long serialVersionUID = -807267582105340314L;

	@Id
	@Column(name = "STATUS_CODE", unique = true, nullable = false, precision = 22, scale = 0)
	private Long statusCode;

	@Column(name = "STATUS_NAME", unique = true, nullable = false, length = 30)
	private String statusName;

	@Column(name = "STATUS_DESC")
	private String statusDesc;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tstatus")
	private Set<Tservicecontact> tservicecontacts = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tstatusByMemberStatus")
	private Set<Tmemberservice> tmemberservicesForMemberStatus = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tstatus")
	private Set<Tmember> tmembers = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tstatus")
	private Set<Tmemberservicerole> tmemberserviceroles = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tstatus")
	private Set<Tcontact> tcontacts = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tstatusByGroupStatus")
	private Set<Tmemberservice> tmemberservicesForGroupStatus = new HashSet<>(0);
}