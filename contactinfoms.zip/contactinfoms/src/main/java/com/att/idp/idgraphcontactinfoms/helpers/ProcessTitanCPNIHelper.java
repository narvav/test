package com.att.idp.idgraphcontactinfoms.helpers;

import com.att.idp.cgclienthelpers.utils.CommonConstants;
import com.att.idp.idgraphcontactinfoms.utils.Constants;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TimeZone;

/**
 * Helper responsible for retrieving Titan (Uverse) account data from CG, transforming it
 * into the input structure expected by {@link CPNIDataConsolidationHelper} and returning
 * the consolidated CPNI contact information.
 */

@Component
@RequiredArgsConstructor
public class ProcessTitanCPNIHelper {

    @Autowired
    private CPNIDataConsolidationHelper cpniDataConsolidationHelper;
    @Autowired
    private CGHelper cgHelper;

    @Value("${apiclient.rest.cg.endpoint}")
    private String cgV2Endpoint;

    public static final Logger log = LoggerFactory.getLogger(ProcessTitanCPNIHelper.class);
    private static String sClassName = "ProcessTitanCPNIHelper";

    /**
     * Retrieves Titan CPNI related contacts for a given account identifier(s).
     * <p>
     * Steps:
     * 1. Validate input map.
     * 2. Determine account identifier used for consolidation.
     * 3. Call CG (Customer Graph) to obtain account information.
     * 4. Process CG response and build input to consolidation helper.
     * 5. Return consolidated CPNI contacts or error map.
     *
     * @param hmInput
     * @return result map containing status codes and (on success) ACCOUNT_CONTACT_LIST
     */
    public HashMap<String, Object> getTitanCPNIContacts(HashMap<String, Object> hmInput) {
        final String sMethodName = ".getTitanCPNIContacts.";
        HashMap<String, Object> hmResult = CommonUtil.getHashMap();

        try {

            // Validate input
            if (hmInput == null || hmInput.isEmpty()) {
                return logAndReturnError(sMethodName, "PTCH_01", CErrorDefs.ERR_INVALID_DATA_NUM, "Input Hash is null or empty");
            }
            log.info("{}{}HLP000 : Entered into ProcessTitanCPNIHelper : Input : {}", sClassName, sMethodName,
                    HtmlUtils.htmlEscape(hmInput.toString()));
            //  Determine account identifier (ACCOUNT_INVARIANT_ID preferred)
            String accountInvariantId = (String) hmInput.get(CommonDefs.ACCOUNT_INVARIANT_ID);
            String accountId = (String) hmInput.get(CommonDefs.ACCOUNT_ID);
            String accountIdForConsolidation = StringUtils.isNotBlank(accountInvariantId) ? accountInvariantId : accountId;
            log.debug("{}{}Resolved accountIdForConsolidation = {}", sClassName, sMethodName,
                    ESAPI.encoder().encodeForHTML(String.valueOf(accountIdForConsolidation)));

            //  Call CG for account information
            Map<String, Object> hmCGResponse = callCGforUverse(hmInput);
            if (hmCGResponse == null || hmCGResponse.isEmpty()) {
                return logAndReturnError(sMethodName, "PTCH_02", CErrorDefs.ERR_SYS_APPL_NUM, "Null/empty response from CG");
            }

            //  Process CG response and return consolidation helper result
            hmResult = processCGResponse(hmInput, hmCGResponse, accountIdForConsolidation);
            log.info("{}{}HLP999 : response from ProcessTitanCPNIHelper : {}", sClassName, sMethodName,
                    ESAPI.encoder().encodeForHTML(hmResult.toString()));
        } catch (Exception e) {
            log.error("Exception in getTitanCPNIContacts", e);
            return CommonErrorMap.makeExceptionMap(e, log);
        }
        return hmResult;
    }

    /**
     * Invokes CG (Customer Gateway) synchronously to obtain Uverse account data using either
     * ACCOUNT_INVARIANT_ID (preferred) or ACCOUNT_ID present in the provided input map.
     *
     * @param hmInput caller input containing identifiers & metadata
     * @return CG response map or an error map if an exception occurs
     */
    public HashMap<String, Object> callCGforUverse(HashMap<String, Object> hmInput) {
        final String method = ".callCG.";
        try {
            HashMap<String, Object> hmCGInput = CommonUtil.getHashMap();
            hmCGInput.put("topics", CommonDefs.ACCOUNTS);
            hmCGInput.put(CommonConstants.CG_API_NAME, CommonConstants.CG_CUSTOMER_SEARCH_API_NAME);
            hmCGInput.put(CommonConstants.CG_END_POINT, cgV2Endpoint);
            hmCGInput.put(CommonDefs.SERVICE_TYPE, Constants.SERVICE_TYPE_UVERSE);

            String accountInvariantId = (String) hmInput.get(CommonDefs.ACCOUNT_INVARIANT_ID);
            String accountId = (String) hmInput.get(CommonDefs.ACCOUNT_ID);
            if (StringUtils.isNotBlank(accountInvariantId)) {
                hmCGInput.put(CommonDefs.ACCOUNT_ID, accountInvariantId);
            } else if (StringUtils.isNotBlank(accountId)) {
                hmCGInput.put(CommonDefs.ACCOUNT_ID, accountId);
            }
            log.debug("{}{}Calling CG with accountId = {}", sClassName, method,
                    ESAPI.encoder().encodeForHTML(String.valueOf(hmCGInput.get(CommonDefs.ACCOUNT_ID))));

            @SuppressWarnings("unchecked") HashMap<String, Object> hmResult = (HashMap<String, Object>) cgHelper.makeCGSyncCall(hmCGInput, cgV2Endpoint);
            return hmResult;
        } catch (Exception e) {
            log.error("Exception in callCG", e);
            return CommonErrorMap.makeExceptionMap(e, log);
        }
    }

    // ========================== Internal Processing ==========================

    /**
     * Processes the CG response: extracts raw contact components, builds consolidation helper
     * input, invokes consolidation helper and returns its response (or an error map).
     */
    private HashMap<String, Object> processCGResponse(HashMap<String, Object> hmInput,
                                                      Map<String, Object> hmCGResponse,
                                                      String accountIdForConsolidation) {
        final String method = ".processCGResponse.";
        String skipAgingRuleFlag = (String) hmInput.get(Constants.SKIP_AGING_RULE_FLAG);
        if (StringUtils.isBlank(skipAgingRuleFlag)) {
            skipAgingRuleFlag = CommonDefs.IND_N;
        }

        if (hmCGResponse == null || !hmCGResponse.containsKey(CommonDefs.ACCOUNTS)) {
            return logAndReturnError(method, "PTCH_03", CErrorDefs.ERR_ACCOUNT_NOT_FOUND_NUM, "No Account data found in CG response.");
        }
        @SuppressWarnings("unchecked") HashMap<String, Object> hmCGAccountInfo = (HashMap<String, Object>) hmCGResponse.get(CommonDefs.ACCOUNTS);
        if (hmCGAccountInfo == null || hmCGAccountInfo.isEmpty()) {
            return logAndReturnError(method, "PTCH_04", CErrorDefs.ERR_ACCOUNT_NOT_FOUND_NUM, "No Account data found in CG response.");
        }

        // Build input for consolidation helper (single pass extraction)
        HashMap<String, Object> hmCPNIConsHelperInput = buildCPNIConsolidationInput(hmInput, hmCGAccountInfo, accountIdForConsolidation, skipAgingRuleFlag);
        log.debug("{}{}Prepared consolidation input with keys: {}", sClassName, method,
                ESAPI.encoder().encodeForHTML(String.valueOf(hmCPNIConsHelperInput.keySet())));

        HashMap<String, Object> consolidationResponse = cpniDataConsolidationHelper.generateCPNIConsolidation(hmCPNIConsHelperInput);
        if (consolidationResponse == null) {
            return logAndReturnError(method, "PTCH_05", CErrorDefs.ERR_SYS_APPL_NUM, "Null response from CPNIDataConsolidationHelper");
        }
        return consolidationResponse;
    }

    /**
     * Builds hmCPNIConsHelperInput consumed by {@link CPNIDataConsolidationHelper} using CG account info.
     */
    private HashMap<String, Object> buildCPNIConsolidationInput(HashMap<String, Object> hmInput,
                                                                HashMap<String, Object> hmCGAccountInfo,
                                                                String accountIdForConsolidation,
                                                                String skipAgingRuleFlag) {
        HashMap<String, Object> hmCPNIConsHelperInput = CommonUtil.getHashMap();
        hmCPNIConsHelperInput.put(CommonDefs.TRANSACTION_NAME, hmInput.get(CommonDefs.TRANSACTION_NAME));
        hmCPNIConsHelperInput.put(CommonDefs.TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
        hmCPNIConsHelperInput.put(CommonDefs.CALLING_SYSTEM_ID, hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
        hmCPNIConsHelperInput.put(Constants.NEW_CPNI_ELIGIBILITY_RULE, CommonDefs.IND_Y);
        hmCPNIConsHelperInput.put(CommonDefs.KEY_IGNORE_POSTAL_ADDRESS_VALIDATION, CommonDefs.IND_Y);
        hmCPNIConsHelperInput.put(CommonDefs.KEY_ACCOUNT_STATUS_CHECK, CommonDefs.IND_N);
        if (StringUtils.isNotBlank(accountIdForConsolidation)) {
            hmCPNIConsHelperInput.put(CommonDefs.KEY_ACCOUNT_ID, accountIdForConsolidation);
        }

        // Service number (not used for Titan, but mandatory in consolidation input)
        hmCPNIConsHelperInput.put(CommonDefs.SERVICE_NBR, "0000000000");

        // Account status & created-on (customer active date)
        String accountStatus = (String) hmCGAccountInfo.get(CommonDefs.STATE);
        Optional.ofNullable(accountStatus).ifPresent(x -> hmCPNIConsHelperInput.put(CommonDefs.KEY_ACCOUNT_STATUS, x));
        String createdOn = (String) hmCGAccountInfo.get(Constants.CREATED_ON);
        if (StringUtils.isNotBlank(createdOn)) {
            String formatted = formatDate(CommonDefs.CUSTOMER_ACTIVE_DATE, createdOn);
            Optional.ofNullable(formatted).ifPresent(x -> hmCPNIConsHelperInput.put(CommonDefs.CUSTOMER_ACTIVE_DATE, x));
        }

        @SuppressWarnings("unchecked") Map<String, Object> contact = (Map<String, Object>) hmCGAccountInfo.get(Constants.CONTACT);
        if (contact != null) {
            // CBR CTNs (primary/secondary) - collected first as per new flow
            List<Map<String, Object>> cbrCtnList = collectCbrCtnList(hmCGAccountInfo, contact, skipAgingRuleFlag);
            if (!cbrCtnList.isEmpty()) {
                hmCPNIConsHelperInput.put(Constants.CBR_CTN_LIST, cbrCtnList);
            }
            // Email
            setEmailDetailsContacts(hmCGAccountInfo, hmCPNIConsHelperInput, hmInput);
            // Postal Address
            setPostalAddress(hmCGAccountInfo, hmCPNIConsHelperInput);
        }
        return hmCPNIConsHelperInput;
    }

    // Collects primary/secondary CBR phone entries applying validation rules.
    private List<Map<String, Object>> collectCbrCtnList(Map<String, Object> hmCGAccountInfo, Map<String, Object> contact, String skipAgingRuleFlag) {
        List<Map<String, Object>> result = new ArrayList<>();
        String primaryValidationStatus = (String) hmCGAccountInfo.get(Constants.PRIMARY_PHONE_VALIDATION_STATUS);
        String secondaryValidationStatus = (String) hmCGAccountInfo.get(Constants.SECONDARY_PHONE_VALIDATION_STATUS);

        addCbrIfEligible(contact, CommonDefs.CBR_INFO, CommonDefs.CONTACT_TYPE_PRIMARY_PHONE, skipAgingRuleFlag, primaryValidationStatus, result);
        addCbrIfEligible(contact, CommonDefs.ALT_CBR_INFO, CommonDefs.CONTACT_TYPE_SECONDARY_PHONE, skipAgingRuleFlag, secondaryValidationStatus, result);
        return result;
    }

    private void addCbrIfEligible(Map<String, Object> contact,
                                  String cbrInfoKey,
                                  String contactType,
                                  String skipAgingRuleFlag,
                                  String validationStatus,
                                  List<Map<String, Object>> collector) {
        @SuppressWarnings("unchecked") Map<String, Object> cbrInfo = (Map<String, Object>) contact.get(cbrInfoKey);
        if (cbrInfo == null || cbrInfo.isEmpty()) {
            return;
        }
        Object phoneObj = cbrInfo.get(CommonDefs.PHONE_NUMBER);
        if (phoneObj == null || StringUtils.isBlank(phoneObj.toString())) {
            return;
        }
        boolean eligible = ("8".equals(validationStatus)) || CommonDefs.IND_Y.equals(skipAgingRuleFlag);
        if (!eligible) {
            return;
        }
        Map<String, Object> contactInfo = CommonUtil.getHashMap();
        contactInfo.put(MPSDefs.DB_CONTACT_TYPE, contactType);
        contactInfo.put(MPSDefs.DB_CONTACT_STATUS, Constants.CONTACT_STATUS_VERIFIED);
        contactInfo.put(CommonDefs.KEY_PHONE, phoneObj);

        String modified = (String) cbrInfo.get(CommonDefs.PHONE_MODIFIED_DATE);
        if (StringUtils.isNotBlank(modified)) {
            String formatted = formatDate(CommonDefs.PHONE_MODIFIED_DATE, modified);
            contactInfo.put(CommonDefs.KEY_PHONE_EST_DATE, formatted != null ? formatted : modified);
        }
        String phoneType = (String) cbrInfo.get(CommonDefs.PHONE_TYPE);
        Boolean isAttNumber = (Boolean) cbrInfo.get(CommonDefs.IS_ATT_NUMBER);
        String mappedType = (String) CommonDefs.PHONE_TYPE_MAPPING.get(phoneType);
        if (!CommonDefs.PHONE_NUMBER_TYPE_MOBILE.equals(mappedType)) {
            log.info("{}{}CBR phone skipped — PhoneNumberType  is not Cell Phone",
                    sClassName, ".addCbrIfEligible.");
            return;
        }
        if (Boolean.TRUE.equals(isAttNumber)) {
            contactInfo.put(CommonDefs.PHONE_NUMBER_TYPE, CommonDefs.PHONE_NUMBER_TYPE_ATTMOBILE);
        } else {
            contactInfo.put(CommonDefs.PHONE_NUMBER_TYPE, CommonDefs.PHONE_NUMBER_TYPE_MOBILE);
        }
        if (CommonDefs.IND_Y.equals(skipAgingRuleFlag)) {
            contactInfo.put(CommonDefs.CPNI_ELIGIBLE_EMAIL_FLAG, CommonDefs.IND_Y);
        }
        collector.add(contactInfo);
    }

    /**
     * Populates email-related fields for consolidation input.
     */
    private void setEmailDetailsContacts(HashMap<String, Object> hmCGAccountInfo,
                                         HashMap<String, Object> consolidationInput,
                                         HashMap<String, Object> hmInput) {
        @SuppressWarnings("unchecked") Map<String, Object> contact = (Map<String, Object>) hmCGAccountInfo.get(Constants.CONTACT);
        if (contact == null) {
            return;
        }
        @SuppressWarnings("unchecked") Map<String, Object> hmEmailDetails = (Map<String, Object>) contact.get(CommonDefs.EMAIL);
        if (hmEmailDetails == null || hmEmailDetails.isEmpty()) {
            return;
        }
        String accountActiveDate = (String) hmCGAccountInfo.get(Constants.CREATED_ON);
        String emailAddress = (String) hmEmailDetails.get(CommonDefs.EMAIL_ADDRESS);
        if (StringUtils.isNotBlank(emailAddress)) {
            consolidationInput.put(Constants.UVERSE_MEMBER_EMAIL_ADDRESS, emailAddress);
            consolidationInput.put(CommonDefs.CONTACT_EMAIL, emailAddress);
        }
        String emailEstablished = (String) hmCGAccountInfo.get(CommonDefs.EMAIL_ESTABLISH_DATE);
        if (StringUtils.isNotBlank(emailEstablished)) {
            String formatted = formatDate(Constants.EMAIL_ADDR_LAST_UPDATE_TS, emailEstablished);
            consolidationInput.put(Constants.UVERSE_EMAIL_ESTABLISHED_DATE, formatted);
        }
        String emailStatus = Constants.CONTACT_STATUS_VERIFIED;
        consolidationInput.put(Constants.UVERSE_EMAIL_STATUS, emailStatus);

        HashMap<String, Object> emailEntry = CommonUtil.getHashMap();
        emailEntry.put(CommonDefs.EMAIL_ADDRESS, emailAddress);
        emailEntry.put(CommonDefs.EMAIL_STATUS, emailStatus);
        emailEntry.put(CommonDefs.KEY_EMAIL_ESTABLISHED_DATE, consolidationInput.get(Constants.UVERSE_EMAIL_ESTABLISHED_DATE));
        emailEntry.put(CommonDefs.KEY_ACCOUNT_ESTABLISHED_DATE, accountActiveDate);

        String skipAgingRuleFlagLocal = (String) hmInput.get(Constants.SKIP_AGING_RULE_FLAG);
        if (CommonDefs.IND_Y.equals(skipAgingRuleFlagLocal)) {
            emailEntry.put(CommonDefs.CPNI_ELIGIBLE_EMAIL_FLAG, CommonDefs.IND_Y);
        }
        if (!emailEntry.isEmpty()) {
            ArrayList<HashMap<String, Object>> emailAddresses = CommonUtil.getArrayList();
            emailAddresses.add(emailEntry);
            consolidationInput.put(CommonDefs.KEY_EMAIL_ADDRESSES, emailAddresses);
        }
    }

    /**
     * Adds postal address (billing) information if present.
     */
    private void setPostalAddress(HashMap<String, Object> hmCGAccountInfo,
                                  HashMap<String, Object> consolidationInput) {
        @SuppressWarnings("unchecked") Map<String, Object> contact = (Map<String, Object>) hmCGAccountInfo.get(Constants.CONTACT);
        if (contact == null) {
            return;
        }
        @SuppressWarnings("unchecked") Map<String, Object> address = (Map<String, Object>) contact.get(Constants.ADDRESS);
        String acctCreationDate = (String) hmCGAccountInfo.get(Constants.CREATED_ON);
        if (address == null || address.isEmpty()) {
            return;
        }

        ArrayList<HashMap<String, Object>> addresses = CommonUtil.getArrayList();
        HashMap<String, Object> billingAddress = CommonUtil.getHashMap();

        String firstName = (String) hmCGAccountInfo.get(CommonDefs.DB_FIRSTNAME);
        String lastName = (String) hmCGAccountInfo.get(CommonDefs.DB_LASTNAME);
        String customerName = (StringUtils.defaultString(firstName) + " " + StringUtils.defaultString(lastName)).trim();
        if (StringUtils.isNotBlank(customerName)) {
            billingAddress.put(CommonDefs.KEY_BILLNAME, customerName);
        }

        String country = (String) address.get(CommonDefs.COUNTRY);

        Optional.ofNullable(address.get(Constants.POST_CODE)).ifPresent(x -> {
            String postcode = String.valueOf(x);
            if (postcode.contains("-")) {
                String[] parts = postcode.split("-");
                if (parts.length > 1) {
                    billingAddress.put(CommonDefs.KEY_ZIPPLUSFOUR, parts[1]);
                }
                billingAddress.put(CommonDefs.KEY_ZIPCODE, parts[0]);
            } else {
                billingAddress.put(CommonDefs.KEY_ZIPCODE, postcode);
            }
        });
        //setting NbrNonAddressLines to default as 1
        billingAddress.put(CommonDefs.KEY_NBR_NON_ADDRESS_LINES, "1");
        billingAddress.put(CommonDefs.KEY_ADDRESS2, address.get(CommonDefs.STREET1));
        billingAddress.put(CommonDefs.KEY_CITY, address.get(CommonDefs.CITY));
        billingAddress.put(CommonDefs.KEY_STATE, address.get(CommonDefs.STATE));
        billingAddress.put(CommonDefs.KEY_COUNTRY, address.get(CommonDefs.COUNTRY));
        String postOffice = address.get(CommonDefs.CITY) + " " + address.get(CommonDefs.STATE) + " " + address.get(Constants.POST_CODE);
        billingAddress.put(CommonDefs.KEY_POSTOFFICE, postOffice.trim());
        billingAddress.put(
                CommonDefs.KEY_FOREIGN_ADDR_IND,
                StringUtils.isNotBlank(country) && !"USA".equalsIgnoreCase(country) ? CommonDefs.IND_Y : CommonDefs.IND_N
        );
        String addressEstablished = (String) address.get(Constants.LAST_UPDATE);
        if (StringUtils.isNotBlank(addressEstablished)) {
            String formatted = formatDate(CommonDefs.CUSTOMER_ACTIVE_DATE, addressEstablished);
            billingAddress.put(CommonDefs.KEY_ADDRESS_ESTABLISHED_DATE, formatted);
        }
        // Overwrite with account creation date (legacy behavior retained)
        billingAddress.put(CommonDefs.KEY_ADDRESS_ESTABLISHED_DATE, acctCreationDate);
        billingAddress.put(CommonDefs.KEY_ACCOUNT_ESTABLISHED_DATE, acctCreationDate);

        if (!billingAddress.isEmpty()) {
            addresses.add(billingAddress);
        }
        if (!addresses.isEmpty()) {
            consolidationInput.put(CommonDefs.POSTAL_ADDRESS, addresses);
        }
    }

    /**
     * Formats provided date value into "MMddyyyy HH:mm:ss" according to various possible input keys.
     *
     * @param sDateKey   semantic key describing the date type
     * @param sDateValue input date string from upstream sources
     * @return formatted date string or null if parsing fails
     */
    private static String formatDate(String sDateKey, String sDateValue) {
        final String method = ".formatDate.";
        Date parsedDate = null;
        String formattedDate = null;
        try {
            DateFormat sdfCustActiveDt = new SimpleDateFormat("yyyy-MM-dd");
            DateFormat sdfTimeModified = new SimpleDateFormat("yyyy-MM-dd");
            DateFormat sdfEmailAddrDt = new SimpleDateFormat("yyyy-MM-dd");
            DateFormat newDtFormat = new SimpleDateFormat("MMddyyyy HH:mm:ss");
            DateFormat sdfPhoneModifiedDt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

            if (CommonDefs.CUSTOMER_ACTIVE_DATE.equals(sDateKey)) {
                parsedDate = sdfCustActiveDt.parse(sDateValue);
            } else if (CommonDefs.TIME_MODIFIED.equals(sDateKey)) {
                parsedDate = sdfTimeModified.parse(sDateValue);
            } else if (Constants.EMAIL_ADDR_LAST_UPDATE_TS.equals(sDateKey) || Constants.ESTABLISH_DATE.equals(sDateKey)) {
                parsedDate = sdfEmailAddrDt.parse(sDateValue);
            } else if (Constants.SIM_SWAP_DATE_TIME.equals(sDateKey) && StringUtils.isNotBlank(sDateValue)) {
                String adj = sDateValue.substring(0, sDateValue.length() - 2) + " " + TimeZone.getTimeZone("UTC").getDisplayName();
                DateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
                parsedDate = simpleDateFormat.parse(adj);
                newDtFormat.setTimeZone(TimeZone.getTimeZone("US/Central"));
            } else if (CommonDefs.PHONE_MODIFIED_DATE.equals(sDateKey)) {
                parsedDate = sdfPhoneModifiedDt.parse(sDateValue);
            }
            if (parsedDate != null) {
                formattedDate = newDtFormat.format(parsedDate);
                log.info("{}{}ET_CPNI_FD_01 : {} : {}, Formatted Date : {}", ProcessTitanCPNIHelper.class.getSimpleName(), method,
                        ESAPI.encoder().encodeForHTML(sDateKey), ESAPI.encoder().encodeForHTML(sDateValue), ESAPI.encoder().encodeForHTML(formattedDate));
            }
        } catch (Exception exp) {
            log.error("{}{}ET_CPNI_FD_02 : Exception = {}", ProcessTitanCPNIHelper.class.getSimpleName(), method, ESAPI.encoder().encodeForHTML(String.valueOf(exp.getMessage())));
        }
        return formattedDate;
    }

    // ============================ Helper Methods =============================

    /**
     * Centralized logging + error map creation to keep main flow clean.
     */
    private HashMap<String, Object> logAndReturnError(String method, String logNumber, int errorCode, String message) {
        log.info("{}{}{} : {}", sClassName, method, logNumber, ESAPI.encoder().encodeForHTML(message));
        return CommonErrorMap.makeCategoryMap(errorCode, message);
    }
}
