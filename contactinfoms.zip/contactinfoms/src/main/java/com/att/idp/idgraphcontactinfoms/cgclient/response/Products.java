package com.att.idp.idgraphcontactinfoms.cgclient.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

/**
 * The Products class represents a collection of products in the system.
 * It implements the Serializable interface, which means its instances can be converted to a byte stream and
 * restored back to the same object later. This is useful for storing objects in a file or sending them over a network.
 *
 * This class contains properties related to a product such as productId, startDate, productOfferingCharacteristic, productRelationship, and productOffering.
 * Each property has its corresponding getter and setter methods.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.cgclient.response package.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(name = "Products")
@Getter
@Setter
@NoArgsConstructor
public class Products implements Serializable {

	private static final long serialVersionUID = 3215976665799591963L;

	private String productId;
	private String startDate;
	private ProductOfferingCharacteristic productOfferingCharacteristic;
	private ProductRelationship productRelationship;
	private ProductOffering productOffering;
}