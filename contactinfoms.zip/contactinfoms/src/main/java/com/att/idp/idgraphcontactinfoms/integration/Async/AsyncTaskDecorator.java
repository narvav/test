package com.att.idp.idgraphcontactinfoms.integration.Async;

import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.api.GlobalOpenTelemetry;
import org.slf4j.MDC;
import org.springframework.core.task.TaskDecorator;

import java.util.Map;

public class AsyncTaskDecorator implements TaskDecorator {

	@Override
	public Runnable decorate(Runnable runnable) {
		// Capture the current MDC context
		Map<String, String> contextMap = MDC.getCopyOfContextMap();

		// Get the OpenTelemetry tracer
		Tracer tracer = GlobalOpenTelemetry.getTracer("com.att.idp");

		// Capture the current span
		Span parentSpan = Span.current();

		return () -> {
			Span internalSpan = null;
			try {
				// Restore MDC context
				MDC.setContextMap(contextMap);

				// Start a new span as a child of the parent span
				internalSpan = tracer.spanBuilder("async-span")
						.setParent(io.opentelemetry.context.Context.current().with(parentSpan))
						.startSpan();

				// Run the task
				runnable.run();
			} finally {
				// End the span
				if (internalSpan != null) {
					internalSpan.end();
				}

				// Clear MDC context
				MDC.clear();
			}
		};
	}
}