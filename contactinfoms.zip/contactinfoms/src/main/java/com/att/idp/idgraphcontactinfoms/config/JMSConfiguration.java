package com.att.idp.idgraphcontactinfoms.config;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;

import com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig;
import jakarta.jms.BytesMessage;
import jakarta.jms.Connection;
import jakarta.jms.Destination;
import jakarta.jms.JMSException;
import jakarta.jms.MessageProducer;
import jakarta.jms.Session;

import org.apache.tomcat.jdbc.pool.interceptor.QueryTimeoutInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.event.EventListener;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.att.mpsys.common.utils.CommonUtil;

import com.ibm.mq.jakarta.jms.MQConnectionFactory;
import com.ibm.msg.client.jakarta.wmq.WMQConstants;
/**
 * The JMSConfiguration class is a configuration class in the Spring framework.
 * It is annotated with @Configuration to indicate that it is a source of bean definitions.
 * It is also annotated with @EnableTransactionManagement to enable Spring's annotation-driven transaction management capability.
 * The @ComponentScan annotation is used to specify the base packages to scan for annotated components.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.config package.
 *
 * It contains several properties related to the MQ configuration such as mqHost, mqPort, mqChannel, mqFFHost, mqFFPort, mqFFChannel, isMqReconnect, mqReconnectTimeoutSec, isJmsReconnect, and jmsSessionCacheSize. Each property is annotated with @Value to inject property values from the properties file.
 *
 * It also contains three bean definitions:
 * - mqConnectionFactory: This method returns a MQConnectionFactory bean. It is responsible for setting up the MQ  Connection Factory.
 * - cachingConnectionFactory: This method returns a CachingConnectionFactory bean. It is responsible for setting up the Caching Connection Factory.
 * - jmsTemplate: This method returns a JmsTemplate bean. It is responsible for setting up the JMS Template.
 */
@Configuration
@EnableTransactionManagement
@ComponentScan("com.att.idp.idgraphcontactinfoms")
public class JMSConfiguration {
	
    private static Logger log = LoggerFactory.getLogger(JMSConfiguration.class);
	
    private static final String MQ_HOST_DL = "zlp15103.vci.att.com";

    private static final String MQ_HOST_FF = "zlp15117.vci.att.com";
    
    private static final String QUEUE_NAME = "MPSQL.MSDBUS.PROD1.INT.MSRIL.0";
    
	@Value("${mq.host}")
	private String mqHost;
	
	@Value("${mq.port}")
	private int mqPort;
	
	@Value("${mq.channel}")
	private String mqChannel;
	
	@Value("${mq.ff.host}")
	private String mqFFHost;

	@Value("${mq.ff.port}")
	private int mqFFPort;

	@Value("${mq.ff.channel}")
	private String mqFFChannel;
	
	@Value("${mq.reconnect}")
	private boolean isMqReconnect;
	
	@Value("${jms.reconnect}")
	private boolean isJmsReconnect;
	
	@Value("${jms.session.cache.size}")
	private int jmsSessionCacheSize;

	@Autowired
	private IDGraphAzureAppConfig idGraphAzureAppConfig;

	@Autowired
	private ApplicationContext applicationContext;


	/**
	 * Handles the refresh event triggered by the Spring Cloud RefreshScope.
	 *
	 * This method is invoked when the application context is refreshed, typically due to
	 * configuration changes. It synchronizes the update of the `RestTemplate` instance
	 * with new timeout values retrieved from the `IDGraphAzureAppConfig` bean.
	 * If the update fails, the method logs the error and retains the existing `RestTemplate`.
	 *
	 * @throws Exception if an error occurs while updating the `RestTemplate` instance.
	/**
	 * Handles the refresh event triggered by the Spring Cloud RefreshScope.
	 *
	 * This method is invoked when the application context is refreshed, typically due to
	 * configuration changes. It synchronizes the update of the `MQConnectionFactory` bean
	 * with new reconnect timeout values retrieved from the `IDGraphAzureAppConfig` bean.
	 * If the update fails, the method logs the error and retains the existing `MQConnectionFactory`.
	 *
	 * @throws Exception if an error occurs while updating the `MQConnectionFactory` bean.
	 */
	@EventListener(RefreshScopeRefreshedEvent.class)
	public void onConfigurationRefresh() throws Exception {
        if (idGraphAzureAppConfig.isMqconnectRefreshEnabled()) {
		synchronized (this) {
			try {
				MQConnectionFactory mqConnectionFactory = applicationContext.getBean(MQConnectionFactory.class);
				if(mqConnectionFactory == null) {
					log.warn("MQConnectionFactory bean is not available in the application context.");
					mqConnectionFactory = mqConnectionFactory();
					ConfigurableApplicationContext configurableContext = (ConfigurableApplicationContext) applicationContext;
					configurableContext.getBeanFactory().registerSingleton("mqConnectionFactory", mqConnectionFactory);
				}

				if(isMqReconnect) {
					mqConnectionFactory.setClientReconnectOptions(WMQConstants.WMQ_CLIENT_RECONNECT);
					mqConnectionFactory.setClientReconnectTimeout(idGraphAzureAppConfig.getMqReconnectTimeoutSec());
				}

				log.info("Updating MQConnectionFactory bean dynamically with new appconfig values: ReconnectTimeout={}",
						idGraphAzureAppConfig.getMqReconnectTimeoutSec());
			} catch (Exception e) {
				log.error("Failed to update MQConnectionFactory  with new appconfig values. Retaining the old MQConnectionFactory.", e);
			}
		}
        } else {
            log.info("MQ Connection Factory refresh is disabled. Retaining the old MQConnectionFactory.");
        }
	}



	/**
	 * This method is responsible for setting up the MQConnectionFactory bean.
	 * MQConnectionFactory is a factory that creates queue connections with a specific IBM MQ queue manager.
	 *
	 * It sets the host name, transport type, channel, and port for the MQConnectionFactory.
	 * It also handles the reconnection options if the MQ host is either MQ_HOST_DL or MQ_HOST_FF.
	 * If the MQ host is either MQ_HOST_DL or MQ_HOST_FF, it sends a dummy request to trigger a queue put.
	 * If there is a JMSException during the queue put, it switches the host name, channel, and port to the failover (FF) values.
	 * If the isMqReconnect property is true, it sets the client reconnect options and client reconnect timeout.
	 *
	 * @return MQConnectionFactory bean configured with the properties defined in the method.
	 */
	@Bean
	public MQConnectionFactory mqConnectionFactory() {
		MQConnectionFactory mqConnectionFactory = new MQConnectionFactory();

	    try {
			/*
			 * InetAddress inetHost = InetAddress.getByName(mqHost);
			 * log.debug("Mq Channel Before : " + mqChannel);
			 * mqChannel=mqChannel.concat(".").concat(inetHost.getCanonicalHostName().
			 * substring(0, inetHost.getCanonicalHostName().indexOf("."))).trim();
			 * 
			 * log.debug("Mq Channel After : " + mqChannel);
			 */

			mqConnectionFactory.setHostName(mqHost);
			mqConnectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
			mqConnectionFactory.setChannel(mqChannel.toUpperCase());
			mqConnectionFactory.setPort(mqPort);
			
		    if (MQ_HOST_DL.equalsIgnoreCase(mqHost) || MQ_HOST_FF.equalsIgnoreCase(mqHost))
		    {
		    	
		    	//dummy request to trigger to q put
		    	HashMap testhmInput = getMQData();

				try(ByteArrayOutputStream bos = new ByteArrayOutputStream();
					ObjectOutput out = new ObjectOutputStream(bos);
					Connection tconnection = mqConnectionFactory.createConnection();
					Session tsession = tconnection.createSession(false, Session.AUTO_ACKNOWLEDGE);
				) {
				    out.writeObject(testhmInput); 
				    out.flush(); 

				    byte[] tinputBytes = bos.toByteArray();
				  

					Destination destination = tsession.createQueue(QUEUE_NAME);
					  
					BytesMessage bMsg = tsession.createBytesMessage();
					  bMsg.writeBytes(tinputBytes);
					  bMsg.setJMSCorrelationID("test12345");
					try(MessageProducer msgProducer = tsession.createProducer(destination);) {
					log.info("before sending: ");
						msgProducer.send(bMsg);
						
					  log.info("result of qput: SUCCESS");}
				  
				  }
				  catch (IOException e1) {
					  log.info("in mqConnectionFactory exception error message,IOException" + e1.getMessage());
					} 
				  catch(JMSException e) {
					  
					  log.info("in mqConnectionFactory exception error message" + e.getMessage() + "error code: " + e.getErrorCode());
					  log.info("in mqConnectionFactory exception error cause" + e.getCause());
					  log.info("existing :" + mqConnectionFactory.getHostName() + mqConnectionFactory.getChannel() + mqConnectionFactory.getPort());
					  mqConnectionFactory.setHostName(mqFFHost);
					  mqConnectionFactory.setChannel(mqFFChannel.toUpperCase());
					  mqConnectionFactory.setPort(mqFFPort);
					  			  				  
				  }
            }
			
			
			
			if(isMqReconnect) {
				mqConnectionFactory.setClientReconnectOptions(WMQConstants.WMQ_CLIENT_RECONNECT);
				mqConnectionFactory.setClientReconnectTimeout(idGraphAzureAppConfig.getMqReconnectTimeoutSec());
			}
			log.info("MQ Configuration :" + mqConnectionFactory.getHostName() + mqConnectionFactory.getChannel() + mqConnectionFactory.getPort());
			
		} 
		/*
		 * catch (UnknownHostException e) { log.error("JMC1.1",
		 * "UnknownHostException while checking for hostname :" + e.getMessage()); }
		 */
	    catch (JMSException e) {

			Exception linked = e.getLinkedException();
			if (linked != null) {
				log.error("Linked Exception=" + e.getMessage());
				log.error("Linked StackTrace=" + e.getStackTrace());
				log.error("Linked Cause=" + e.getCause());
				log.error("Linked=" + e);
			}
			log.error("JMC1.2", "JMSException while creating mqConnectionFactory:" + e.getMessage());
					
		}
	    log.info("final :" + mqConnectionFactory.getHostName() + mqConnectionFactory.getChannel() + mqConnectionFactory.getPort());
	    return mqConnectionFactory;
	}


	private static HashMap getMQData() {
		
		HashMap testnF = CommonUtil.getHashMap();
		testnF.put("securityCode", "123456");
		testnF.put("securityCodeExpires", ZonedDateTime.now( ZoneOffset.UTC ));
		
		HashMap emailAddr = CommonUtil.getHashMap();
		 emailAddr.put("emailAddress", "qaytest1@att.com");
		 
		ArrayList emailAddressList = CommonUtil.getArrayList();
		  emailAddressList.add(emailAddr);
		HashMap email = CommonUtil.getHashMap();
		  email.put("emailAddressList", emailAddressList);
		HashMap delMethods = CommonUtil.getHashMap();
		delMethods.put("email", email);
		    
  
		HashMap testhmEventData = CommonUtil.getHashMap(); 
		  testhmEventData.put("expirationDays", "0.041666666666666664");
		  testhmEventData.put("subEvent", "EDDORC");
		  testhmEventData.put("identificationType", "EMAILPIN");
		  testhmEventData.put("transactionName", "GenerateSecurityCode");
		  testhmEventData.put("callingSystemId", "MULESOFT");
		  testhmEventData.put("transactionId", "test12345");
		  testhmEventData.put("eventname", "EDDORCNotification");
		  testhmEventData.put("accountID", "1000006780");
		  testhmEventData.put("expirationHours", "1");
		  testhmEventData.put("dbus_DictionaryName", "Dict");
		  testhmEventData.put("origTransactionId", "test12345");
		  testhmEventData.put("expirationDays", "0.041666666666666664");
		  testhmEventData.put("notificationFields", testnF);
		  testhmEventData.put("deliveryMethods", delMethods);		  
		ArrayList alEventData = CommonUtil.getArrayList();
		  alEventData.add(testhmEventData);	  
		HashMap testhmInput = CommonUtil.getHashMap();		  
		  testhmInput.put("dbus_DictionaryName", "Dict");
		  testhmInput.put("mainHashKey", "1000006780");
		  testhmInput.put("msOperation", "GeneratePIN");
		  testhmInput.put("transactionName", "GeneratePIN");
		  testhmInput.put("callingSystemId", "MULESOFT");
		  testhmInput.put("eventname", "MicroServiceEvent");
		  testhmInput.put("transactionId", "test12345");
		  testhmInput.put("stopkeyfield", "stopfield");
		  testhmInput.put("stopfield", "mstodbusStopKey1000006780");
		  testhmInput.put("eventsData", alEventData);
		return testhmInput;
	}


	/**
	 * This method is responsible for setting up the CachingConnectionFactory bean.
	 * CachingConnectionFactory is a Spring helper class that adds session caching to any underlying JMS ConnectionFactory.
	 *
	 * It creates a new CachingConnectionFactory and sets its target ConnectionFactory with the MQConnectionFactory bean passed as a parameter.
	 * If the isJmsReconnect property is true, it enables reconnection on exception.
	 * It also sets the session cache size with the jmsSessionCacheSize property.
	 *
	 * @param mqConnectionFactory the MQConnectionFactory bean used to set the target ConnectionFactory of the CachingConnectionFactory.
	 * @return CachingConnectionFactory bean configured with the MQConnectionFactory and properties defined in the method.
	 */
    @Bean
    @Primary
    public CachingConnectionFactory cachingConnectionFactory(MQConnectionFactory mqConnectionFactory) {
        CachingConnectionFactory cachingConnectionFactory = new CachingConnectionFactory(mqConnectionFactory);
    	
    	if (isJmsReconnect) {
    		cachingConnectionFactory.setReconnectOnException(true);    		
    	}
    	cachingConnectionFactory.setSessionCacheSize(jmsSessionCacheSize);
        return cachingConnectionFactory;
    }

    /**
     * This method is responsible for setting up the JmsTemplate bean.
     * JmsTemplate is a helper class that simplifies synchronous JMS access code.
     *
     * It creates a new JmsTemplate and sets its ConnectionFactory with the CachingConnectionFactory bean created by the cachingConnectionFactory method.
     *
     * @param cachingConnectionFactory the CachingConnectionFactory bean used to set the ConnectionFactory of the JmsTemplate.
     * @return JmsTemplate bean configured with the CachingConnectionFactory defined in the method.
     */
    @Bean
    public JmsTemplate jmsTemplate(CachingConnectionFactory cachingConnectionFactory) {
    	
    	JmsTemplate jmsTemplate = new JmsTemplate(cachingConnectionFactory);
    	
        return jmsTemplate;
    }
}
