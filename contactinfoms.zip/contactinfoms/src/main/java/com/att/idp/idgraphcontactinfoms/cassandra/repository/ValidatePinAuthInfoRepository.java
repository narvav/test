package com.att.idp.idgraphcontactinfoms.cassandra.repository;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;

import com.att.idp.idgraphcontactinfoms.cassandra.entity.SessionId;
import com.att.idp.idgraphcontactinfoms.cassandra.entity.ValidatePinAuthInfo;


/**
 * The ValidatePinAuthInfoRepository interface extends the CassandraRepository interface provided by Spring Data Cassandra.
 * This interface will be used to perform CRUD operations on the ValidateCredAuthInfo table in the Cassandra database.
 *
 * The ValidatePinAuthInfoRepository interface is annotated with @Repository to indicate that it's a Bean and it will be automatically
 * detected by Spring during component scanning.
 *
 * The ValidatePinAuthInfoRepository interface takes  two parameters:
 * - ValidatePinAuthInfo: The entity class that represents the table in the database.
 * - SessionId: The class that represents the primary key of the ValidateCredAuthInfo table.
 */
@Repository
public interface ValidatePinAuthInfoRepository extends CassandraRepository<ValidatePinAuthInfo,SessionId>{

}