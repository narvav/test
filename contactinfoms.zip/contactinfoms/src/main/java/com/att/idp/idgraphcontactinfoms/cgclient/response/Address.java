package com.att.idp.idgraphcontactinfoms.cgclient.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

/**
 * The Address class represents an address in the system.
 * It implements the Serializable interface, which means its instances can be converted to a byte stream and
 * restored back to the same object later. This is useful for storing objects in a file or sending them over a network.
 *
 * This class contains various properties related to an address such as preferred, country, city, county, contactType, postCode, street1, addressSubType, and state.
 * Each property has its corresponding getter and setter methods.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.cgclient.response package.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(name = "Address")
@Getter
@Setter
@NoArgsConstructor
public class Address implements Serializable {

	private static final long serialVersionUID = 384798578510642827L;

	private boolean preferred;
	private String country;
	private String city;
	private String county;
	private String contactType;
	private String postCode;
	private String street1;
	private String addressSubType;
	private String state;
}