package com.att.idp.idgraphcontactinfoms.db.helper;

import org.slf4j.Logger;

import com.att.idp.idgraphcontactinfoms.exceptions.MPSException;


/**
 * This interface defines a contract for persisting and validating credential data in the database.
 * It contains a method for persisting and validating credential data, which takes a ValidateCredentialsBean object and a Logger object as parameters.
 * The method throws an MPSException if any error occurs during the operation.
 */
public interface PersistValidatePinDataInterface {

	/**
	 * This method persists and validates credential data to the database.
	 * It takes a ValidatePinInfoBean object and a Logger object as parameters.
	 * The ValidatePinInfoBean object contains the validate pin info to be persisted and validated.
	 * The Logger object is used for logging any important information or errors during the operation.
	 * The method throws an MPSException if any error occurs during the operation.
	 *
	 * @param bean A ValidatePinInfoBean object containing the credential data to be persisted and validated.
	 * @param logger A Logger object for logging any important information or errors.
	 * @throws MPSException If any error occurs during the operation.
	 */
	void PersistValidatePinInfoToDatabase( ValidatePinInfoBean bean) throws MPSException;

}