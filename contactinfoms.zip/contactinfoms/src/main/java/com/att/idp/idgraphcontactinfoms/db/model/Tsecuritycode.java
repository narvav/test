package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.util.Date;
import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name = "TSECURITYCODE", schema = "MPS_OWNER")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tsecuritycode implements java.io.Serializable {

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "identificationType", column = @Column(name = "IDENTIFICATION_TYPE", nullable = false, length = 10)),
			@AttributeOverride(name = "accountId", column = @Column(name = "ACCOUNT_ID", nullable = false, length = 60)),
			@AttributeOverride(name = "securityCode", column = @Column(name = "SECURITY_CODE", nullable = false)) })
	private TsecuritycodeId id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SLID_MEMBER_NUM")
	private Tmember tmember;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SOR_ID")
	private Tsystemofrecord tsystemofrecord;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "IDENTIFICATION_TYPE", referencedColumnName = "IDENTIFICATION_TYPE", nullable = false, insertable = false, updatable = false),
			@JoinColumn(name = "ACCOUNT_ID", referencedColumnName = "ACCOUNT_ID", nullable = false, insertable = false, updatable = false) })
	private Tsecurityaccount tsecurityaccount;

	@Column(name = "VERIFICATION_FAILURE_COUNT", precision = 22, scale = 0)
	private int verificationFailureCount;

	@Temporal(TemporalType.DATE)
	@Column(name = "SECURITY_CODE_EXPIRES", nullable = false, length = 7)
	private Date securityCodeExpires;

	@Column(name = "SECURITY_CODE_STATUS", nullable = false, length = 10)
	private String securityCodeStatus;

	@Temporal(TemporalType.DATE)
	@Column(name = "STATUS_CHANGE_DATE", length = 7)
	private Date statusChangeDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false, length = 256)
	private String lastModifiedBy;

	@Column(name = "SOURCE", length = 3)
	private String source;

	@Column(name = "SOR_INVARIANT_ID")
	private String sorInvariantId;

	@Column(name = "DELIVERY_METHOD", length = 2)
	private String deliveryMethod;

	@Column(name = "DELIVERY_DETAIL", length = 1024)
	private String deliveryDetail;

	@Column(name = "PASSCODE_VENC", length = 512)
	private String passcodeVenc;
}