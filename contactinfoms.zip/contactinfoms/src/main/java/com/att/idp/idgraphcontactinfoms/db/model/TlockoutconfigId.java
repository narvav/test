package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class TlockoutconfigId implements Serializable {

	private static final long serialVersionUID = -3815437781620973625L;

	@Column(name = "LOCKOUT_ID", nullable = false, precision = 22, scale = 0)
	private Long lockoutId;

	@Column(name = "SET_NUMBER", nullable = false, precision = 22, scale = 0)
	private Long setNumber;


	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TlockoutconfigId))
			return false;
		TlockoutconfigId castOther = (TlockoutconfigId) other;

		return ((this.getLockoutId() == castOther.getLockoutId()) || (this.getLockoutId() != null
				&& castOther.getLockoutId() != null && this.getLockoutId().equals(castOther.getLockoutId())))
				&& ((this.getSetNumber() == castOther.getSetNumber()) || (this.getSetNumber() != null
						&& castOther.getSetNumber() != null && this.getSetNumber().equals(castOther.getSetNumber())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getLockoutId() == null ? 0 : this.getLockoutId().hashCode());
		result = 37 * result + (getSetNumber() == null ? 0 : this.getSetNumber().hashCode());
		return result;
	}

}
