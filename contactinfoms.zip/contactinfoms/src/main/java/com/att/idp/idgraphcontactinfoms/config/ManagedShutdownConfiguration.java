package com.att.idp.idgraphcontactinfoms.config;

import org.springframework.context.annotation.Configuration;

import com.att.idp.shutdown.config.EnableIdpShutdownManagement;
import com.att.idp.shutdown.jersey.config.EnableJerseyShutdownAdapter;

/**
 * Configuration that activates the IDP Shutdown Library
 * 
 * @author pg5345
 *
 */
@Configuration
@EnableIdpShutdownManagement
@EnableJerseyShutdownAdapter
public class ManagedShutdownConfiguration {
	
}
