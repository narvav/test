package com.att.idp.idgraphcontactinfoms.integration;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.Map;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig;
import jakarta.annotation.PostConstruct;

import org.apache.hc.client5.http.ConnectTimeoutException;
import org.apache.hc.client5.http.impl.routing.DefaultProxyRoutePlanner;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;


import com.att.idp.http.client.RestApiClient;
import com.att.idp.http.client.config.RestTemplateBeanFactory;
import com.att.idp.idgraphcontactinfoms.utils.JsonService;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;

import org.apache.hc.core5.http.HttpHost;

import static com.att.idp.cd.observability.metrics.utils.Constants.GET;
import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_75;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_90;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_95;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_99;
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_OB;
import static com.att.idp.cd.observability.metrics.utils.Constants.URI;
import static com.att.idp.idgraphcontactinfoms.utils.Constants.IDGRAPH_CONTACT_INFO_MS_OB;


/**
 * This class is an implementation of the RestApiClient interface and is used to make REST API calls to the MuleSoft service.
 * <p>
 * It contains methods for making synchronous POST calls to the MuleSoft service and processing the response.
 * The class uses the Spring Framework's @Component annotation to indicate that it is a bean and can be used for dependency injection.
 * <p>
 * The class has several instance variables that are injected using the @Autowired and @Value annotations.
 * These variables are used to interact with the RestTemplateBeanFactory and to store configuration values such as the MuleSoft server URL, endpoint, client ID, and client secret.
 * <p>
 * The main method in this class is the postCCMuleSyncCall method, which takes a HashMap and a String as input and returns a Map as output.
 * The postCCMuleSyncCall method uses the RestTemplate's exchange method to make the POST call and processes the response.
 * <p>
 * The class also contains a private method for populating the HTTP headers for the REST API call.
 * <p>
 * The class also contains a logger for logging information and error messages.
 */
@Component
public class MuleSoftRestClient implements RestApiClient {

    private static final Logger logger = LoggerFactory.getLogger(MuleSoftRestClient.class);

    private static final String MULE_SOFT_REST_CLIENT = "ccmulesoft";

    private static String sClassName = "MuleSoftRestClient";

    @Value("${proxy.onprem.enabledFor.ccmulesoft}")
    private boolean proxyEnabled;

    @Value("${proxy.auth.host}")
    private String proxyAuthHost;

    @Value("${proxy.auth.port}")
    private int proxyAuthPort;

    @Value("${apiclient.rest.ccmulesoft.clientid}")
    private String clientid;

    @Value("${apiclient.rest.ccmulesoft.clientsecret}")
    private String clientsecret;
    DefaultProxyRoutePlanner routePlanner = null;
    private RestTemplate restTemplate;
    private IDGraphAzureAppConfig appConfiguration;
    private final RestTemplateBeanFactory restTemplateFactory;
    private OutboundRestClientBuilder outboundRestClientBuilder;

    public boolean isProxyEnabled() {
        return proxyEnabled;
    }

    public MuleSoftRestClient() {
        this.restTemplateFactory = null;
        this.appConfiguration = null;
        this.outboundRestClientBuilder = null;
    }


    @Autowired
    public MuleSoftRestClient(RestTemplateBeanFactory restTemplateBeanFactory, IDGraphAzureAppConfig appConfiguration, OutboundRestClientBuilder outboundRestClientBuilder) throws Exception {
        this.restTemplateFactory = restTemplateBeanFactory;
        this.appConfiguration = appConfiguration;
        this.outboundRestClientBuilder = outboundRestClientBuilder;
        this.restTemplate = restTemplateFactory.getObject(MULE_SOFT_REST_CLIENT);
    }

    /**
     * This method is annotated with @PostConstruct, which means it is executed after the bean is fully initialized.
     * It checks if the proxy is enabled by calling the isProxyEnabled method.
     * If the proxy is enabled, it calls the setProxy method to set up the proxy for the RestTemplate.
     */
    @PostConstruct
    public void init() {
        if (isProxyEnabled()) {
            HttpHost proxy = new HttpHost(proxyAuthHost, proxyAuthPort);
            routePlanner = new DefaultProxyRoutePlanner(proxy);
        }

        this.restTemplate = this.initializeRestTemplate(this.restTemplate);
        logger.info("RestTemplate connectTimeout={} ms, readTimeout={} ms", appConfiguration.getCcmulesoftConnectTimeout(), appConfiguration.getCcmulesoftReadTimeout());
    }


    /**
     * Handles the refresh event triggered by the Spring Cloud RefreshScope.
     * <p>
     * This method is invoked when the application context is refreshed, typically due to
     * configuration changes. It synchronizes the update of the `RestTemplate` instance
     * with new timeout values retrieved from the `IDGraphAzureAppConfig` bean.
     * If the update fails, the method logs the error and retains the existing `RestTemplate`.
     *
     * @throws Exception if an error occurs while updating the `RestTemplate` instance.
     */
    @EventListener(RefreshScopeRefreshedEvent.class)
    public void onConfigurationRefresh() throws Exception {
        if (appConfiguration.isCcmulesoftRestClientRefreshEnabled()) {
            synchronized (this) {
                try {

                    if (this.restTemplate == null) {
                        this.restTemplate = restTemplateFactory.getObject(MULE_SOFT_REST_CLIENT);
                    }

                    this.restTemplate = initializeRestTemplate(this.restTemplate);

                    logger.info("MuleSoftRestClient dynamically updated from azureappconfig with new timeout values: connectTimeout={} ms, readTimeout={} ms", appConfiguration.getCcmulesoftConnectTimeout(), appConfiguration.getCcmulesoftReadTimeout());
                } catch (Exception e) {
                    // Log the error and retain the old RestTemplate
                    logger.error("Failed to update MuleSoftRestClient RestTemplate with new timeout values. Retaining the old RestTemplate.", e);
                }
            }
        } else {
            logger.info("MuleSoftRestClient RestTemplate refresh is disabled. Retaining the existing RestTemplate.");
        }
    }

    private RestTemplate initializeRestTemplate(RestTemplate restTemplate) {
        try {
            if (restTemplate == null) {
                restTemplate = restTemplateFactory.getObject(MULE_SOFT_REST_CLIENT);
            }

            restTemplate = outboundRestClientBuilder.buildRestTemplate(restTemplate, appConfiguration.getCcmulesoftConnectTimeout(), appConfiguration.getCcmulesoftReadTimeout(), isProxyEnabled(), routePlanner);
            logger.info("Initializing RestTemplate dynamically updated from azureappconfig with new timeout values: connectTimeout={} ms, readTimeout={} ms", appConfiguration.getCcmulesoftConnectTimeout(), appConfiguration.getCcmulesoftReadTimeout());
        } catch (Exception e) {
            logger.error("Error in initializing RestTemplate for MuleSoftRestClient: {}", e.getMessage(), e);
        }
        return restTemplate;
    }

    /**
     * This method makes a synchronous POST call to the MuleSoft service and processes the response.
     * <p>
     * It first populates the HTTP headers for the REST API call and creates an HttpEntity object with the input HashMap and the headers.
     * The method then uses the RestTemplate's exchange method to make the POST call to the MuleSoft service.
     * If the HTTP status code in the response is OK or CREATED, the method processes the response body and constructs a success response.
     * If the HTTP status code in the response is not OK or CREATED, the method constructs an error response.
     * The method also handles various exceptions that can occur during the REST API call, such as timeouts and HTTP client errors.
     *
     * @param hmNotification a HashMap that contains the notification data for the POST call. The HashMap should be convertible to a JSON string.
     * @param sTransactionId a String that contains the transaction ID for the POST call. This is used for logging and tracing purposes.
     * @return a Map that contains the result of the operation. The Map contains an application status code, an application info message, and the response from the MuleSoft service.
     * @throws JsonProcessingException if an error occurs while converting the input HashMap to a JSON string.
     * @throws IOException             if an I/O error occurs during the operation.
     */
    @TimedMetrics(name = IDGRAPH_CONTACT_INFO_MS_OB, type = REST_OB, description = "Mulesoft events API call", tags = {METHOD, GET, URI, "/clm-priority-comms-e/api/v1/commevents"}, histogram = true, percentiles = {PERCENTILE_75, PERCENTILE_90, PERCENTILE_95, PERCENTILE_99})
    public Map<String, Object> postCCMuleSyncCall(HashMap<String, Object> hmNotification, String sTransactionId, String resourceUri) throws JsonProcessingException, IOException {

        String sMethodName = ".postCCMuleSyncCall.";
        logger.debug("{}{}MSRC_01 : invoking postCCMuleSyncCall", sClassName, sMethodName);


        JsonNode jsonNode = null;

        Map<String, Object> hmResult = new HashMap<>();

        HttpHeaders reqheaders = populatingHeader(sTransactionId);
        HttpEntity httpEntity = new HttpEntity<>(hmNotification, reqheaders);


        logger.info("{}{}MSRC_02 : postCCMuleSyncCall:", sClassName, sMethodName);

        try {

            ResponseEntity<JsonNode> output = restTemplate.exchange(resourceUri, HttpMethod.POST, httpEntity, JsonNode.class);
            if (HttpStatus.OK.equals(output.getStatusCode()) || HttpStatus.CREATED.equals(output.getStatusCode())) {

                jsonNode = JsonService.getObjectFromJson(output.getBody(), JsonNode.class);
                HashMap hmSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
                hmSuccess.put("traceId", jsonNode.get("traceId"));
                hmResult.putAll(hmSuccess);

            } else {
                if (null != output) {
                    logger.error("{}{}MSRC_03 : Response from postCCMuleSyncCall MulesoftClient's status code when not success {} for attachment", sClassName, sMethodName, output.getStatusCode());
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EXTERNAL_SYS_NUM, output.getBody().toString());
                }
            }
        } catch (Exception restClientException) {
            if (restClientException.getCause() instanceof SocketTimeoutException || restClientException.getCause() instanceof ConnectTimeoutException) {
                String stAppInfo = "Timeout in call to postCCMuleSyncCall : " + restClientException.getMessage();
                logger.error("{}{}MSRC_04 : Timeout in call to postCCMuleSyncCall : {}", sClassName, sMethodName, restClientException.getMessage());
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_TRAN_TIME_OUT_NUM, stAppInfo);
            } else {
                logger.error("{}{}MSRC_05 : MulesoftClient:postCCMuleSyncCall error found while making the call, Exception is: {}", sClassName, sMethodName, restClientException.getMessage());
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EXTERNAL_SYS_NUM, restClientException.getMessage());
            }
        }
        return hmResult;

    }

    private HttpHeaders populatingHeader(String traceID) {
        HttpHeaders reqheaders = new HttpHeaders();

        reqheaders.setContentType(MediaType.APPLICATION_JSON);
        reqheaders.add("client_id", clientid);
        // reqheaders.add("idp-trace-id", traceID);
        reqheaders.add("client_secret", clientsecret);
        // reqheaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        return reqheaders;
    }
}