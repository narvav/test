package com.att.idp.idgraphcontactinfoms.helpers.voltage;

import com.voltage.securedata.enterprise.VeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.idp.core.exception.ServiceException;
import com.att.idp.idgraphcontactinfoms.message.ErrorMessages;
import com.att.idp.voltage.common.VoltageEfpeFormatType;
import com.att.idp.voltage.encrypt.api.EncryptorVoltageHelper;
import com.att.idp.voltage.encrypt.api.VoltageEncryptorAutoConfiguration;


/**
 * This is the EncryptUtil class.
 * It is a utility class that provides methods to encrypt values using the Voltage security framework.
 * It contains methods to interact with the Voltage API and handle any exceptions that may occur during the encryption process.
 * It is annotated as a Spring Component, indicating that an instance of this class will be created and managed by the Spring framework.
 */
@Component
public class EncryptUtil {
	
	private static final Logger log = LoggerFactory.getLogger(EncryptUtil.class);

	private EncryptorVoltageHelper volHelper=null;	
	
	/**
	 * This is the constructor for the EncryptUtil class.
	 * It takes a VoltageEncryptorAutoConfiguration object as an input, which is autowired by Spring.
	 * The constructor initializes the volHelper instance variable with an instance of EncryptorVoltageHelper for the default identity.
	 *
	 * @param pVEAC An autowired VoltageEncryptorAutoConfiguration object.
	 */
	public EncryptUtil(@Autowired VoltageEncryptorAutoConfiguration pVEAC ) throws VeException {
		
			volHelper =EncryptorVoltageHelper.getInstanceForDefaultIdentity();
		
	}

	/**
	 * This method is part of the EncryptUtil class.
	 * It takes a value and a format name as inputs, and returns the encrypted value.
	 * The method interacts with the Voltage API to encrypt the value, and handles any exceptions that may occur during the encryption process.
	 * It logs any errors that occur during the encryption process.
	 * The method returns a String which is the encrypted value.
	 *
	 * @param value The value to be encrypted.
	 * @param formatName The name of the format to be used for encryption.
	 * @return A String containing the encrypted value.
	 * @throws ServiceException If an error occurs during the encryption process.
	 */
	public String getEncryptedValue(String value, String formatName) {
		try {
			return volHelper.encrypt(value, VoltageEfpeFormatType.valueOf(formatName));			
			 
		} catch (Exception e) {			
			log.error("Error while encrypting value", e);
			throw new ServiceException(ErrorMessages.ERROR_VOLTAGE_ENCRYPT);
		}
		
	}   
}
