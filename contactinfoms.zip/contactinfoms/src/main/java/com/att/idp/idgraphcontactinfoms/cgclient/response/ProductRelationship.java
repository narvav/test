package com.att.idp.idgraphcontactinfoms.cgclient.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

/**
 * The ProductRelationship class represents a relationship between products in the system.
 * It implements the Serializable interface, which means its instances can be converted to a byte stream and
 * restored back to the same object later. This is useful for storing objects in a file or sending them over a network.
 *
 * This class contains properties related to a product relationship such as product and type.
 * Each property has its corresponding getter and setter methods.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.cgclient.response package.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(name = "ProductRelationship")
@Getter
@Setter
@NoArgsConstructor
public class ProductRelationship implements Serializable {

	private static final long serialVersionUID = -6506413446508408442L;

	private Product product;
	private String type;
}