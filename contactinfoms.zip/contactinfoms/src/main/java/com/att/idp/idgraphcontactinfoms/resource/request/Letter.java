package com.att.idp.idgraphcontactinfoms.resource.request;

import static org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString;
import static org.apache.commons.lang3.builder.ToStringStyle.JSON_STYLE;

import java.io.Serializable;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.request package.
 *
 * The Letter class implements the Serializable interface, allowing instances of this class to be converted into a byte stream.
 *
 * The class is used to represent a Letter object, which contains several fields related to a physical address.
 * These fields include name, street1, street2, street3, postOffice, nbrNonAddressLines, foreignAddrInd, city, state, zipCode, zipPlusFour, and country.
 *
 * Each field is annotated with @Size and/or @NotNull, indicating that they are required fields and have size constraints.
 * The messages associated with these annotations provide additional information about the requirements for each field.
 *
 * The class provides a no-argument constructor, as well as getter and setter methods for each field.
 * It also overrides the toString method, providing a custom string representation of the object using reflection.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Letter implements Serializable{

	@Size(min=1, max=100,message="name length is invalid|GeneratePIN")
	protected String name;

	@NotNull(message="street1 is required field in input request.|GeneratePIN")
	@Size(min=1, max=100,message="street1 length is invalid|GeneratePIN")
	protected String street1;

	@Size(min=1, max=100,message="street2 length is invalid|GeneratePIN")
	protected String street2;

	@Size(min=1, max=100,message="street3 length is invalid|GeneratePIN")
	protected String street3;

	@Size(min=1, max=100,message="postOffice length is invalid|GeneratePIN")
	protected String postOffice;

	@Size(min=1, max=2,message="nbrNonAddressLines length is invalid|GeneratePIN")
	protected String nbrNonAddressLines;

	@Size(min=1, max=1,message="foreignAddrInd length is invalid|GeneratePIN")
	protected String foreignAddrInd;

	@NotNull(message="city is required field in input request.|GeneratePIN")
	@Size(min=1, max=100,message="city length is invalid|GeneratePIN")
	protected String city;

	@NotNull(message="state is required field in input request.|GeneratePIN")
	@Size(min=1, max=2,message="state length is invalid|GeneratePIN")
	protected String state;

	@NotNull(message="zipCode is required field in input request.|GeneratePIN")
	@Size(min=1, max=5,message="zipCode length is invalid|GeneratePIN")
	protected String zipCode;

	@Size(min=1, max=4,message="zipPlusFour length is invalid|GeneratePIN")
	protected String zipPlusFour;

	@Size(min=1, max=20,message="country length is invalid|GeneratePIN")
	protected String country;

	@Override
	public String toString() {
		return reflectionToString(this, JSON_STYLE);
	}
}