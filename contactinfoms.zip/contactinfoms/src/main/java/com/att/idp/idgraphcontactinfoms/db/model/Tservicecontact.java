package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Date;
import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "TSERVICECONTACT", schema = "MPS_OWNER")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tservicecontact implements java.io.Serializable {

	private static final long serialVersionUID = -6133105449974328516L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "sorId", column = @Column(name = "SOR_ID", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "sorInvariantId", column = @Column(name = "SOR_INVARIANT_ID", nullable = false)),
			@AttributeOverride(name = "contactType", column = @Column(name = "CONTACT_TYPE", nullable = false, length = 30)) })
	private TservicecontactId id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "VALIDATION_STATUS")
	private Tstatus tstatus;

	@Column(name = "PHONE_NUMBER", length = 10)
	private String phoneNumber;

	@Column(name = "PHONE_NUMBER_EXT", length = 10)
	private String phoneNumberExt;

	@Column(name = "PHONE_NUMBER_TYPE", length = 10)
	private String phoneNumberType;

	@Column(name = "EMAIL_ADDRESS")
	private String emailAddress;

	@Column(name = "CONTACT_STATUS", length = 1)
	private Character contactStatus;

	@Column(name = "DATE_ESTABLISHED", nullable = false, length = 7)
	private Date dateEstablished;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;

	@Column(name = "MOBILITY_INVARIANT_ID")
	private String mobilityInvariantId;

	@Column(name = "ATLAS_LAST_TIMESTAMP")
	private String atlasLastTimestamp;

	@Column(name = "VALIDATION_INITIATED_DATE", length = 7)
	private Date validationInitiatedDate;
}