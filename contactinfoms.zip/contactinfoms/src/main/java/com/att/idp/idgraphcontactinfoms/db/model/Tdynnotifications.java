package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "TDYNNOTIFICATIONS", schema = "MPS_OWNER")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tdynnotifications implements java.io.Serializable {

	private static final long serialVersionUID = -3965314934668736085L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "serviceId", column = @Column(name = "SERVICE_ID", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "ctype", column = @Column(name = "CTYPE", nullable = false, length = 50)),
			@AttributeOverride(name = "action", column = @Column(name = "ACTION", nullable = false, length = 20)),
			@AttributeOverride(name = "NName", column = @Column(name = "N_NAME", nullable = false, length = 50)) })
	private TdynnotificationsId id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SERVICE_ID", nullable = false, insertable = false, updatable = false)
	private Tservice tservice;

	@Column(name = "N_VALUE")
	private String NValue;

	@Column(name = "CALLING_SYSTEM_IDS")
	private String callingSystemIds;
}