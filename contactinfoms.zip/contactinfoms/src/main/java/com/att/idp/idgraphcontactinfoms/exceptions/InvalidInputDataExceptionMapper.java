package com.att.idp.idgraphcontactinfoms.exceptions;

import java.util.HashMap;

import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;

/**
 * This is a constructor for the InvalidInputDataException class.
 *
 * It takes one parameter: hmResponse. hmResponse is a Map that represents the response HashMap.
 *
 * When an instance of InvalidInputDataException is created using this constructor, the detail message is set to the value associated with the key CommonDefs.COMMON_APP_STATUS_MSG in the provided HashMap, and the errorHashMap is set to the provided HashMap. The ErrorMessage object is not initialized.
 *
 * @param hmResponse a Map that represents the response HashMap.
 */
@Provider
public class InvalidInputDataExceptionMapper implements ExceptionMapper<InvalidInputDataException>{
		
	public static final Logger logger = LoggerFactory.getLogger(InvalidInputDataExceptionMapper.class);
	@Override
	public Response toResponse(InvalidInputDataException ex) {
		
		HashMap hmResponse = (HashMap) ex.errorHashMap;
		return CommonUtilHelper.buildMSResponse(CommonUtilHelper.generateCIRResponse(hmResponse));
		
	}
	
}
