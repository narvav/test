package com.att.idp.idgraphcontactinfoms.resource;

import java.io.IOException;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import com.att.idp.idgraphcontactinfoms.cgclient.response.CGResponse;
import com.att.idp.idgraphcontactinfoms.exceptions.MPSException;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * This interface defines the contract for the CGRestClientResource.
 *
 * It uses the JAX-RS annotations to define the HTTP methods, paths, consumed and produced media types.
 * It also uses the Swagger annotations to provide metadata about the API such as the API's name, path, operations, responses and implicit parameters.
 *
 * The main method in this interface is the cgRestClient method, which takes HttpHeaders as input and returns a Response.
 * The cgRestClient method is annotated with @GET, @Path, @Consumes, @Produces, @ApiOperation, @ApiResponses and @ApiImplicitParams to define its HTTP method, path, consumed and produced media types, operation description, responses and implicit parameters.
 *
 * The interface also throws MPSException, JsonProcessingException and IOException that can occur during the execution of the cgRestClient method.
 */
@Tag(name = "cgRestClient")
@Path("/cgRestClient")
@Produces({ MediaType.APPLICATION_JSON })
public interface CGRestClientResource {
	
	/**
	 * This method is responsible for invoking the CG Rest Client endpoint.
	 *
	 * It takes HttpHeaders as an input parameter and returns a Response.
	 * The method is annotated with @GET, @Path, @Consumes, @Produces, @ApiOperation, @ApiResponses and @ApiImplicitParams to define its HTTP method, path, consumed and produced media types, operation description, responses and implicit parameters.
	 * The method also throws MPSException, JsonProcessingException and IOException that can occur during the execution of the method.
	 *
	 * @param httpHeaders HttpHeaders that contains the request headers. These headers are used for logging and tracing purposes and also contain the accountId, subscriberNumber, serviceType, and topics.
	 * @return a Response that contains the result of the invocation. If the invocation is successful, the response contains a success message. If the invocation fails, the response contains an error message.
	 * @throws MPSException if there is an exception in the application.
	 * @throws JsonProcessingException if there is an error in processing the JSON.
	 * @throws IOException if there is an input-output exception.
	 */
	@GET
	@Path("/cgSyncCall")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "CG Rest Client", description = "Invoking CG Rest Client endpoint",
			parameters = {
					@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER),
					@Parameter(name = "accountId", description = "accountId", required = true, in = ParameterIn.HEADER, schema = @Schema(type = "string", defaultValue = "177071112120")),
					@Parameter(name = "subscriberNumber", description = "subscriberNumber", required = true, in = ParameterIn.HEADER, schema = @Schema(type = "string", defaultValue = "177071112120")),
					@Parameter(name = "serviceType", description = "serviceType", required = true, in = ParameterIn.HEADER, schema = @Schema(type = "string", defaultValue = "wireless")),
					@Parameter(name = "topics", description = "topics", required = true, in = ParameterIn.HEADER, schema = @Schema(type = "string", defaultValue = "accounts,subscribers,equipments"))
			})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = CGResponse.class))),
			@ApiResponse(responseCode = "400", description =  "Bad Request"),
			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	Response cgRestClient(@Context  HttpHeaders httpHeaders) throws MPSException , JsonProcessingException, IOException;
}