package com.att.idp.idgraphcontactinfoms.resource.response;

import java.util.ArrayList;
import com.att.idp.core.exception.ServiceError;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "InquirePinResponse")
@Data
public class InquirePINResponse {

	@JsonIgnore
	private String transactionName = "InquirePIN";
	@JsonIgnore
	private String appStatusMsg;
	@JsonIgnore
	private String appStatusCode;
	@JsonIgnore
	private String appInfo;
	@JsonIgnore
	private String appCategoryCode;
	private ServiceError errors;
	private String idpTraceId;
	private ArrayList<SecurityPins> securityPins;

    @JsonProperty("maxAllowedPINs")
	private int totalPins;

	@JsonProperty("unusedPINs")
	private int unusedPins;

	@JsonProperty("error")
	public void setErrors(ServiceError errors) {
		this.errors = errors;
	}

	@JsonProperty("idp-trace-id")
	public void setIdpTraceId(String idpTraceId) {
		this.idpTraceId = idpTraceId;
	}
}