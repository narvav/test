package com.att.idp.idgraphcontactinfoms.config;

import java.sql.SQLException;
import java.util.Properties;

import com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig;
import org.apache.tomcat.jdbc.pool.XADataSource;
import org.apache.tomcat.jdbc.pool.interceptor.QueryTimeoutInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.event.EventListener;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;

/**
 * The DataBaseConfiguration class is a configuration class in the Spring framework.
 * It is annotated with @Configuration to indicate that it is a source of bean definitions.
 * It is also annotated with @EnableTransactionManagement and @EnableJpaRepositories to enable Spring's transaction management and JPA repositories respectively.
 * The @PropertySource annotation is used to specify the location of the properties file.
 * <p>
 * This class is part of the com.att.idp.idgraphcontactinfoms.config package.
 * <p>
 * It contains several properties related to the database configuration such as url, driverClassName, dbUserName, dbPassword, minIdle, maximumPoolSize, connectionTimeOut, maxLifeTime, autoCommit, and idleTimeout. Each property is annotated with @Value to inject property values from the properties file.
 * <p>
 * It also contains three bean definitions:
 * - entityManagerFactory: This method returns a LocalContainerEntityManagerFactoryBean bean. It is responsible for creating the EntityManagerFactory.
 * - dataSource: This method returns a HikariDataSource bean. It is responsible for setting up the data source.
 * - transactionManagerRef: This method returns a PlatformTransactionManager bean. It is responsible for managing transactions for a single EntityManagerFactory.
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "com.att.idp.idgraphcontactinfoms.db.repository")
@PropertySource(value = "${contactinfo.credentials.path}")
public class DataBaseConfiguration {

    private static final Logger log = LoggerFactory.getLogger(DataBaseConfiguration.class);

    @Value("${AES256KEY}")
    private String propAes256Key;

    @Value("${spring.datasource.url}")
    private String url;

    @Value("${spring.datasource.driver-class-name}")
    private String driverClassName;

    @Value("${spring.datasource.username}")
    private String dbUserName;

    @Value("${spring.datasource.password}")
    private String dbPassword;

    @Autowired
    private IDGraphAzureAppConfig idGraphAzureAppConfig;

    @Autowired
    private ApplicationContext applicationContext;

    /**
     * Handles the refresh event triggered by the Spring Cloud RefreshScope.
     *
     * This method is invoked when the application context is refreshed, typically due to
     * configuration changes. It synchronizes the update of the `RestTemplate` instance
     * with new timeout values retrieved from the `IDGraphAzureAppConfig` bean.
     * If the update fails, the method logs the error and retains the existing `RestTemplate`.
     *
     * @throws Exception if an error occurs while updating the `RestTemplate` instance.
    /**
     * Handles the refresh event triggered by the Spring Cloud RefreshScope.
     *
     * This method is invoked when the application context is refreshed, typically due to
     * configuration changes. It synchronizes the update of the `XADataSource` instance
     * with new configuration values retrieved from the `IDGraphAzureAppConfig` bean.
     * If the update fails, the method logs the error and retains the existing `XADataSource`.
     *
     * @throws Exception if an error occurs while updating the `XADataSource` instance.
     */
    @EventListener(RefreshScopeRefreshedEvent.class)
    public void onConfigurationRefresh() throws Exception {
        if (idGraphAzureAppConfig.isDataSourceRefreshEnabled()) {
        synchronized (this) {
            try {

                XADataSource xaDataSource = applicationContext.getBean(XADataSource.class);

                if(xaDataSource == null) {
                    log.error("XADataSource bean is not available in the application context.");
                    xaDataSource = xaDataSource();
                    ConfigurableApplicationContext configurableContext = (ConfigurableApplicationContext) applicationContext;
                    configurableContext.getBeanFactory().registerSingleton("xaDataSource", xaDataSource);
                }

                xaDataSource.setValidationQuery(idGraphAzureAppConfig.getValidationQuery());
                xaDataSource.setInitialSize(idGraphAzureAppConfig.getInitialSize());
                xaDataSource.setMaxActive(idGraphAzureAppConfig.getMaxSize());
                xaDataSource.setMinIdle(idGraphAzureAppConfig.getMinSize());
                xaDataSource.setTestOnBorrow(idGraphAzureAppConfig.isTestOnBorrow());
                xaDataSource.setTestWhileIdle(idGraphAzureAppConfig.isTestWhileIdle());
                xaDataSource.setJdbcInterceptors(QueryTimeoutInterceptor.class.getName() + "(queryTimeout=" + idGraphAzureAppConfig.getQueryTimeout() + ")");
                xaDataSource.setMinEvictableIdleTimeMillis(idGraphAzureAppConfig.getEvictTime());
                xaDataSource.setMaxWait(idGraphAzureAppConfig.getConnTimeout());

                log.info("XADataSource dynamically updated with new values from appconfig: appconfig.version [{}], connTimeout [{}], maxSize [{}], queryTimeout [{}], validationQuery [{}], initialSize [{}], testWhileIdle [{}], testOnBorrow [{}], evictTime [{}], minSize [{}]",
                        idGraphAzureAppConfig.getVersion(),
                        idGraphAzureAppConfig.getConnTimeout(),
                        idGraphAzureAppConfig.getMaxSize(),
                        idGraphAzureAppConfig.getQueryTimeout(),
                        idGraphAzureAppConfig.getValidationQuery(),
                        idGraphAzureAppConfig.getInitialSize(),
                        idGraphAzureAppConfig.isTestWhileIdle(),
                        idGraphAzureAppConfig.isTestOnBorrow(),
                        idGraphAzureAppConfig.getEvictTime(),
                        idGraphAzureAppConfig.getMinSize());
            } catch (Exception e) {
                log.error("Failed to update XADataSource  with new appconfig values. Retaining the old XADataSource.", e);
            }
        }} else {
            log.info("DataSource refresh is disabled. Skipping XADataSource update on configuration refresh.");
        }
    }


    /**
     * This method is responsible for setting up the LocalContainerEntityManagerFactoryBean bean.
     * LocalContainerEntityManagerFactoryBean is a FactoryBean that creates a JPA EntityManagerFactory according to JPA's standard container bootstrap contract.
     * <p>
     * It sets the data source, packages to scan, and JPA vendor adapter for the EntityManagerFactory.
     * The data source is set with the HikariDataSource bean created by the dataSource method.
     * The packages to scan are set to "com.att.idp.idgraphcontactinfoms.db.model" and "com.att.idp.idgraphcontactinfoms".
     * The JPA vendor adapter is set with a new instance of HibernateJpaVendorAdapter.
     * <p>
     * It also sets several JPA properties such as dialect, hbm2ddl auto, format sql, show sql, default schema, JDBC batch size, order inserts, order updates, and general statistics.
     *
     * @return LocalContainerEntityManagerFactoryBean bean configured with the properties defined in the method.
     */
    @Bean
    @Primary
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {

        LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();

        try {
            entityManagerFactoryBean.setDataSource(xaDataSource());
        } catch (Exception e) {
            log.error("DBC1.1", "Error while creating xaDataSource:" + e.getMessage());
        }
        entityManagerFactoryBean.setPackagesToScan("com.att.idp.idgraphcontactinfoms.db.model");

        final HibernateJpaVendorAdapter jpaVendorAdapter = new HibernateJpaVendorAdapter();
        entityManagerFactoryBean.setJpaVendorAdapter(jpaVendorAdapter);
        entityManagerFactoryBean.setPackagesToScan("com.att.idp.idgraphcontactinfoms");
        Properties jpaProperties = new Properties();

/*
		jpaProperties.put("hibernate.dialect", "org.hibernate.dialect.Oracle12cDialect");
*/
        jpaProperties.put("hibernate.hbm2ddl.auto", "none");
        jpaProperties.put("hibernate.format_sql", "true");
        jpaProperties.put("hibernate.show_sql", "false");
        jpaProperties.put("hibernate.default_schema", "BROKEN");
        jpaProperties.put("hibernate.jdbc.batch_size", 30);
        jpaProperties.put("hibernate.order_inserts", "true");
        jpaProperties.put("hibernate.order_updates", "true");
        jpaProperties.put("hibernate.general_statistics", "false");

        entityManagerFactoryBean.setJpaProperties(jpaProperties);

        return entityManagerFactoryBean;
    }

    /**
     * Defining xaDataSource details.
     *
     * @return dataSource instance of XADatasource
     */
    @Bean(name = "xaDataSource")
    XADataSource xaDataSource() throws SQLException, Exception {

        XADataSource xaDataSource = null;
        xaDataSource = new XADataSource();
        xaDataSource.setUrl(url);
        xaDataSource.setUsername(dbUserName);
        xaDataSource.setPassword(CommonUtilHelper.getAESDecryption(dbPassword, propAes256Key));
        xaDataSource.setDriverClassName(driverClassName);
        xaDataSource.setValidationQuery(idGraphAzureAppConfig.getValidationQuery());
        xaDataSource.setInitialSize(idGraphAzureAppConfig.getInitialSize());
        xaDataSource.setMaxActive(idGraphAzureAppConfig.getMaxSize());
        xaDataSource.setMinIdle(idGraphAzureAppConfig.getMinSize());
        xaDataSource.setTestOnBorrow(idGraphAzureAppConfig.isTestOnBorrow());
        xaDataSource.setTestWhileIdle(idGraphAzureAppConfig.isTestWhileIdle());
        xaDataSource.setJdbcInterceptors(QueryTimeoutInterceptor.class.getName() + "(queryTimeout=" + idGraphAzureAppConfig.getQueryTimeout() + ")");
        xaDataSource.setMinEvictableIdleTimeMillis(idGraphAzureAppConfig.getEvictTime());
        xaDataSource.setMaxWait(idGraphAzureAppConfig.getConnTimeout());

        return xaDataSource;
    }


    /**
     * This method is responsible for setting up the PlatformTransactionManager bean.
     * PlatformTransactionManager is an interface specifying the basic functionality of Spring's transaction infrastructure.
     * <p>
     * It creates a new JpaTransactionManager and sets its EntityManagerFactory with the one created by the entityManagerFactory method.
     *
     * @return PlatformTransactionManager bean configured with the EntityManagerFactory defined in the method.
     */
    @Bean
    public PlatformTransactionManager transactionManagerRef() {
        final JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
        return transactionManager;
    }
}