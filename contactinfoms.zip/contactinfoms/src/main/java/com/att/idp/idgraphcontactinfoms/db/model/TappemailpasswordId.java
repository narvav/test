package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.sql.Date;

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TappemailpasswordId implements java.io.Serializable {

	private static final long serialVersionUID = -1788091150583667550L;

	@Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)
	private Long memberNum;

	@Column(name = "PASSWORD_NAME", nullable = false, length = 50)
	private String passwordName;

	@Column(name = "PASSWORD_VENC", nullable = false, length = 512)
	private String passwordVenc;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", nullable = false, length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;

	@Column(name = "PASSWORD_OX", length = 512)
	private String passwordOx;


	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TappemailpasswordId))
			return false;
		TappemailpasswordId castOther = (TappemailpasswordId) other;

		return ((this.getMemberNum() == castOther.getMemberNum()) || (this.getMemberNum() != null
				&& castOther.getMemberNum() != null && this.getMemberNum().equals(castOther.getMemberNum())))
				&& ((this.getPasswordName() == castOther.getPasswordName())
						|| (this.getPasswordName() != null && castOther.getPasswordName() != null
								&& this.getPasswordName().equals(castOther.getPasswordName())))
				&& ((this.getPasswordVenc() == castOther.getPasswordVenc())
						|| (this.getPasswordVenc() != null && castOther.getPasswordVenc() != null
								&& this.getPasswordVenc().equals(castOther.getPasswordVenc())))
				&& ((this.getCreateDate() == castOther.getCreateDate()) || (this.getCreateDate() != null
						&& castOther.getCreateDate() != null && this.getCreateDate().equals(castOther.getCreateDate())))
				&& ((this.getLastModified() == castOther.getLastModified())
						|| (this.getLastModified() != null && castOther.getLastModified() != null
								&& this.getLastModified().equals(castOther.getLastModified())))
				&& ((this.getLastModifiedBy() == castOther.getLastModifiedBy())
						|| (this.getLastModifiedBy() != null && castOther.getLastModifiedBy() != null
								&& this.getLastModifiedBy().equals(castOther.getLastModifiedBy())))
				&& ((this.getPasswordOx() == castOther.getPasswordOx())
						|| (this.getPasswordOx() != null && castOther.getPasswordOx() != null
								&& this.getPasswordOx().equals(castOther.getPasswordOx())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getMemberNum() == null ? 0 : this.getMemberNum().hashCode());
		result = 37 * result + (getPasswordName() == null ? 0 : this.getPasswordName().hashCode());
		result = 37 * result + (getPasswordVenc() == null ? 0 : this.getPasswordVenc().hashCode());
		result = 37 * result + (getCreateDate() == null ? 0 : this.getCreateDate().hashCode());
		result = 37 * result + (getLastModified() == null ? 0 : this.getLastModified().hashCode());
		result = 37 * result + (getLastModifiedBy() == null ? 0 : this.getLastModifiedBy().hashCode());
		result = 37 * result + (getPasswordOx() == null ? 0 : this.getPasswordOx().hashCode());
		return result;
	}

}
