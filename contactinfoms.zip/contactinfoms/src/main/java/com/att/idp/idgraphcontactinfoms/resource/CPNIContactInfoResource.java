package com.att.idp.idgraphcontactinfoms.resource;

import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import com.att.idp.idgraphcontactinfoms.resource.response.CPNIContactInfoResponse;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.web.bind.annotation.RequestBody;

import com.att.idp.idgraphcontactinfoms.exceptions.MPSException;
import com.att.idp.idgraphcontactinfoms.resource.request.QueryCPNIAccountContactInfoRequest;
import com.att.idp.idgraphcontactinfoms.resource.request.QueryCPNIUserContactInfoRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.QueryCPNIAccountContactInfoResponse;
import com.att.idp.idgraphcontactinfoms.resource.response.QueryCPNIUserContactInfoResponse;

import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * This is the Interface definition for CPNIContactInfoResource.
 *
 * It uses the JAX-RS annotations to define the HTTP methods, paths, consumed and produced media types.
 * It also uses the Swagger annotations to provide metadata about the API such as the API's name, path, operations, responses.
 *
 * The main methods in this interface are the queryCPNIAccountContactInfo and queryCPNIUserContactInfo methods, which take HttpHeaders and a request object as input and return a Response.
 * These methods are annotated with @POST, @Path, @Consumes, @Produces, @ApiOperation, @ApiResponses to define their HTTP method, path, consumed and produced media types, operation description, responses.
 *
 * The interface also throws MPSException that can occur during the execution of the methods.
 */
@Tag(name = "cpniContactInfo")
@Path("/cpniContactInfo")
@Produces({ MediaType.APPLICATION_JSON })
public interface CPNIContactInfoResource {

	
	/**
	 * This method is responsible for querying the CPNI Account Contact Information.
	 *
	 * It takes a QueryCPNIAccountContactInfoRequest and HttpHeaders as input parameters and returns a Response.
	 * The method is annotated with @POST, @Path, @Consumes, @Produces, @ApiOperation, @ApiResponses to define its HTTP method, path, consumed and produced media types, operation description, responses.
	 * The method also throws MPSException that can occur during the execution of the method.
	 *
	 * @param queryCPNIAccountContactInfoRequest QueryCPNIAccountContactInfoRequest that contains the request data for the query CPNI Account Contact Information operation. This data is validated by the method.
	 * @param httpHeader HttpHeaders that contains the request headers. These headers are used for logging and tracing purposes.
	 * @return a Response that contains the result of the query. If the query is successful, the response contains a success message. If the query fails, the response contains an error message.
	 * @throws MPSException if there is an exception in the application.
	 */
	@POST
	@Path("/account")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "QueryCPNIAccountContactInfo", description =  "QueryCPNIAccountContactInfo in the MPSYS system",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = QueryCPNIAccountContactInfoResponse.class))),

			@ApiResponse(responseCode = "400", description =  "Bad Request"),

			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	Response queryCPNIAccountContactInfo(@Valid @RequestBody QueryCPNIAccountContactInfoRequest queryCPNIAccountContactInfoRequest,@Context HttpHeaders httpHeader) throws MPSException;

	
	/**
	 * This method is responsible for querying the CPNI User Contact Information.
	 *
	 * It takes a QueryCPNIUserContactInfoRequest and HttpHeaders as input parameters and returns a Response.
	 * The method is annotated with @POST, @Path, @Consumes, @Produces, @ApiOperation, @ApiResponses to define its HTTP method, path, consumed and produced media types, operation description, responses.
	 * The method also throws MPSException that can occur during the execution of the method.
	 *
	 * @param queryCPNIUserContactInfoRequest QueryCPNIUserContactInfoRequest that contains the request data for the query CPNI User Contact Information operation. This data is validated by the method.
	 * @param httpHeader HttpHeaders that contains the request headers. These headers are used for logging and tracing purposes.
	 * @return a Response that contains the result of the query. If the query is successful, the response contains a success message. If the query fails, the response contains an error message.
	 * @throws MPSException if there is an exception in the application.
	 */
	@POST
	@Path("/user")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "QueryCPNIUserContactInfo", description =  "QueryCPNIUserContactInfo in the MPSYS system",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = QueryCPNIUserContactInfoResponse.class))),

			@ApiResponse(responseCode = "400", description =  "Bad Request"),

			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	Response queryCPNIUserContactInfo(@Valid @RequestBody QueryCPNIUserContactInfoRequest queryCPNIUserContactInfoRequest,
			@Context HttpHeaders httpHeader) throws MPSException;



	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "CPNIContactInfo", description =  "CPNIContactInfo in the MPSYS system",parameters = {
			@Parameter(name = "X-ATT-ClientId", description = "Caller MS/Application Name which serves to identify the calling application/service", required = true, in = ParameterIn.HEADER)})
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = CPNIContactInfoResponse.class))),

			@ApiResponse(responseCode = "400", description =  "Bad Request"),

			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	Response cpniContactInfo( @Context HttpHeaders httpHeader) throws Exception;

}