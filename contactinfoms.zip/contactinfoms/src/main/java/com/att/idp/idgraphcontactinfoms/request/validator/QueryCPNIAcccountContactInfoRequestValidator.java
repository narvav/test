package com.att.idp.idgraphcontactinfoms.request.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import jakarta.ws.rs.core.HttpHeaders;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphcontactinfoms.resource.request.QueryCPNIAccountContactInfoRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.QueryCPNIAccountContactInfoResponse;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;

/**
 * This class is responsible for validating the QueryCPNIAccountContactInfoRequest.
 *
 * It uses the Spring Framework's @Configuration and @PropertySource annotations to indicate that it is a source of bean definitions and to load properties from a specified location.
 *
 * The class has several instance variables that are injected using the @Value annotation.
 * These variables are used to store configuration values such as the valid callers.
 *
 * The main method in this class is the queryCPNIAccountContactRequestValidator method, which takes HttpHeaders and a QueryCPNIAccountContactInfoRequest as input and returns a QueryCPNIAccountContactInfoResponse.
 * The queryCPNIAccountContactRequestValidator method performs various checks on the input parameters and calls other private methods for further validation.
 *
 * The class also contains several private methods for validating the input parameters and constructing an error response.
 *
 * The class also contains a logger for logging information and error messages.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class QueryCPNIAcccountContactInfoRequestValidator {

	@Value("${PROP_QUERY_CPNI_ACCOUNT_CSI}")
	private String propValidCallers;
	
	private static final Logger logger = LoggerFactory.getLogger(QueryCPNIAcccountContactInfoRequestValidator.class);

	private String sClassName = "QueryCPNIAcccountClontactInfoRequestValidator";

	
	/**
	 * This method is responsible for validating the QueryCPNIAccountContactInfoRequest.
	 *
	 * It takes HttpHeaders and a QueryCPNIAccountContactInfoRequest as input parameters and returns a QueryCPNIAccountContactInfoResponse.
	 * The method performs various checks on the input parameters and calls other private methods for further validation.
	 * If the validation is successful, the method returns a QueryCPNIAccountContactInfoResponse. If the validation fails, the method constructs an error response and returns it.
	 *
	 * The method also handles exceptions that can occur during the validation process.
	 *
	 * @param requestHeader HttpHeaders that contains the request headers. These headers are used for logging and tracing purposes.
	 * @param queryCPNIAccountContactInfoRequest QueryCPNIAccountContactInfoRequest that contains the request data for the query CPNI account contact info operation. This data is validated by the method.
	 * @return a QueryCPNIAccountContactInfoResponse that contains the result of the validation. If the validation is successful, the response contains a success message. If the validation fails, the response contains an error message.
	 */
	public QueryCPNIAccountContactInfoResponse queryCPNIAccountContactRequestValidator(HttpHeaders requestHeader,
			QueryCPNIAccountContactInfoRequest queryCPNIAccountContactInfoRequest) {
		
		QueryCPNIAccountContactInfoResponse queryCPNIAccountContactResponse=null;
		String stAppInfo = null;
		String sMethodName = ".queryCPNIAccountContactRequestValidator.";
		String stIdpTraceId = null;
		
		stIdpTraceId = CommonUtil.getTraceId(requestHeader);
		
		if(stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
			stAppInfo="QueryCPNIAcccountContactInfo Request idp-trace-id is missing";
			return queryCPNIAccountContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		if (queryCPNIAccountContactInfoRequest == null) {
			stAppInfo = "Input Request is NULL / Empty.";
			logger.info("{}{}CPNIRV_101 :: {}", sClassName, sMethodName, stAppInfo);
		return queryCPNIAccountContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					 stIdpTraceId);
		}
		
		queryCPNIAccountContactInfoRequest.setIdpTraceId(stIdpTraceId);
			
		// checking Invalid attributes passed in Request
		Map<String, Object> allUnknownAttributes = new HashMap<>(queryCPNIAccountContactInfoRequest.unknownAttributes);

		if (!allUnknownAttributes.isEmpty()) {
			stAppInfo = "Invalid Attributes passed in QueryCPNIAccountContactInfoRequest : " + allUnknownAttributes;
			return queryCPNIAccountContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					queryCPNIAccountContactInfoRequest.getIdpTraceId());
		}
		
		try {
			queryCPNIAccountContactResponse = queryCPNIAccountContactInputValidator(queryCPNIAccountContactInfoRequest,requestHeader);
			if (queryCPNIAccountContactResponse != null) {
				logger.info("{}{}CPNIRV_103 Response from queryCPNIAccountContactInputValidator : {}", sClassName, sMethodName,
						queryCPNIAccountContactResponse);
				return queryCPNIAccountContactResponse;
			}
			
			queryCPNIAccountContactResponse = queryCPNIAccountTypeAndCSIValidator(queryCPNIAccountContactInfoRequest);
			if (queryCPNIAccountContactResponse != null) {
				logger.info("{}{}CPNIRV_104 Response from queryCPNIAccountTypeAndCSIValidator : {}", sClassName, sMethodName,
						queryCPNIAccountContactResponse);
				return queryCPNIAccountContactResponse;
			}
			
			stAppInfo = "Input Validation Successful";
			logger.info("{}{}CPNIRV_105 : {}", sClassName, sMethodName, stAppInfo);

		} catch (Exception e) {
			stAppInfo = "Exception thrown in QueryCPNIAcccountContactInfoRequestValidator : "
					+ e.getMessage();
			queryCPNIAccountContactResponse=queryCPNIAccountContactErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo,
				 stIdpTraceId);
			logger.info("{}{}CPNIRV_105: Exception in QueryCPNIAcccountContactInfoRequestValidator: {}", sClassName,sMethodName,stAppInfo);
		}

		
		return queryCPNIAccountContactResponse;
		
		
	}


	private QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInputValidator(
			QueryCPNIAccountContactInfoRequest queryCPNIAccountContactInfoRequest,HttpHeaders requestHeader) {

		QueryCPNIAccountContactInfoResponse queryCPNIAccountResponse = null;
		String stAppInfo=null;
		String sMethodName=".queryCPNIAccountContactInputValidator.";
		
		String sAccountType =  queryCPNIAccountContactInfoRequest.getAccountType();
		String sAccountInvId = queryCPNIAccountContactInfoRequest.getAccountInvariantId();
		String sIsExternalCall = queryCPNIAccountContactInfoRequest.getIsExternalCall();
		String sAccountId = queryCPNIAccountContactInfoRequest.getAccountId();
		String sReturnCBRCTNs = queryCPNIAccountContactInfoRequest.getReturnCBRCTNs();
		String sSkipAgingRuleFlag = queryCPNIAccountContactInfoRequest.getSkipAgingRuleFlag();
				
		Optional.ofNullable(sIsExternalCall)
		.ifPresent(x -> queryCPNIAccountContactInfoRequest.setIsExternalCall(x.trim()));
		
		queryCPNIAccountResponse = queryCPNIAccountIsExternalCallCheck(queryCPNIAccountContactInfoRequest);
		if (queryCPNIAccountResponse != null) {
			return queryCPNIAccountResponse;
		}
				
		Optional.ofNullable(sAccountType)
				.ifPresent(x -> queryCPNIAccountContactInfoRequest.setAccountType(x.trim().toUpperCase()));

		Optional.ofNullable(sAccountInvId)
				.ifPresent(x -> queryCPNIAccountContactInfoRequest.setAccountInvariantId(x.trim()));

		Optional.ofNullable(sAccountId).ifPresent(x -> queryCPNIAccountContactInfoRequest.setAccountId(x.trim()));
		
		Optional.ofNullable(sSkipAgingRuleFlag).ifPresent(x -> queryCPNIAccountContactInfoRequest.setSkipAgingRuleFlag(x.trim().toUpperCase()));

        String sCallingSystemId = Optional.ofNullable(queryCPNIAccountContactInfoRequest.getCallingSystemId()).orElse(requestHeader.getHeaderString("X-ATT-ClientId"));
		if (sCallingSystemId == null || sCallingSystemId.isBlank()) {
			stAppInfo = "Either X-ATT-ClientId in request header or callingSystemId in request body must be present";
			logger.info("{}{}CPNIRV_102.1 : {}", sClassName, sMethodName, stAppInfo);
			return queryCPNIAccountContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
				 queryCPNIAccountContactInfoRequest.getIdpTraceId());
		}
		
		queryCPNIAccountContactInfoRequest.setCallingSystemId(sCallingSystemId.toUpperCase());
		
		sAccountType=queryCPNIAccountContactInfoRequest.getAccountType();
		if (sAccountType == null || sAccountType.isEmpty()) {
			stAppInfo = "accountType must be present";
			logger.info("{}{}CPNIRV_102.2 : {}", sClassName, sMethodName, stAppInfo);
			return queryCPNIAccountContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					 queryCPNIAccountContactInfoRequest.getIdpTraceId());			
			
		}
		
		sAccountInvId=queryCPNIAccountContactInfoRequest.getAccountInvariantId();
		sAccountId=queryCPNIAccountContactInfoRequest.getAccountId();
		if (sAccountInvId != null && !sAccountInvId.isEmpty()) {
			queryCPNIAccountContactInfoRequest.setAccountId(null);
			
		} else if(sAccountId == null || sAccountId.isEmpty()) {
			stAppInfo = "Either accountInvariantId or accountId must be present in input";
			logger.info("{}{}CPNIRV_102.3 : {}", sClassName, sMethodName, stAppInfo);
			return queryCPNIAccountContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					 queryCPNIAccountContactInfoRequest.getIdpTraceId());			
			
		}
		
		if (sReturnCBRCTNs != null && !(sReturnCBRCTNs.equalsIgnoreCase("Y") || sReturnCBRCTNs.equalsIgnoreCase("N"))){
			stAppInfo = "returnCBRCTNs should be either Y or N";
			logger.info("{}{}CPNIRV_102.4 : {}", sClassName, sMethodName, stAppInfo);
			return queryCPNIAccountContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					 queryCPNIAccountContactInfoRequest.getIdpTraceId());
		}
		sSkipAgingRuleFlag=queryCPNIAccountContactInfoRequest.getSkipAgingRuleFlag();
		if (sSkipAgingRuleFlag != null
				&& !(sSkipAgingRuleFlag.equals(CommonDefs.IND_Y) || sSkipAgingRuleFlag.equals(CommonDefs.IND_N))) {
			stAppInfo = "sSkipAgingRuleFlag must be one of Y or N";			
			logger.info("{}{}CPNIRV_102.4a : {}", sClassName, sMethodName, stAppInfo);			
			return queryCPNIAccountContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					 queryCPNIAccountContactInfoRequest.getIdpTraceId());
		}
		return queryCPNIAccountResponse;
	}

	
	
	
	private QueryCPNIAccountContactInfoResponse queryCPNIAccountTypeAndCSIValidator(
			QueryCPNIAccountContactInfoRequest queryCPNIAccountContactInfoRequest) {
		QueryCPNIAccountContactInfoResponse queryCPNIAccountResponse = null;
		
		String stAppInfo=null;
		String sMethodName=".queryCPNIAccountTypeAndCSIValidator.";
		
		String sIsExternalCall=queryCPNIAccountContactInfoRequest.getIsExternalCall();
		String sAccountType=queryCPNIAccountContactInfoRequest.getAccountType();
		String sAccountInvId=queryCPNIAccountContactInfoRequest.getAccountInvariantId();		
		String sCallingSystemId=queryCPNIAccountContactInfoRequest.getCallingSystemId();
		
		ArrayList<String> alValidCallers = CommonUtil.parseToArray(propValidCallers, CommonDefs.VALUE_SEPARATOR_CHAR);
		
		logger.info("{}{}CPNIRV_103.1 : PROP_QUERY_CPNI_ACCOUNT_CSI : {}", sClassName, sMethodName, alValidCallers);

		if ((sIsExternalCall != null && sIsExternalCall.equalsIgnoreCase("Y")) && (sCallingSystemId != null && !alValidCallers.contains(sCallingSystemId))) {
			stAppInfo = "Invalid X-ATT-ClientId in request header or callingSystemId in request body";
			logger.info("{}{}CPNIRV_103.2 : {}", sClassName, sMethodName, stAppInfo);
			return queryCPNIAccountContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					 queryCPNIAccountContactInfoRequest.getIdpTraceId());
		}
		
		if (!(sAccountType.equals("ECOMM") || sAccountType.equals("MOBILITY") || sAccountType.equals("TITAN")
				|| sAccountType.equals("BSSEWIRELESS"))) {
			stAppInfo = "accountType is invalid";
			logger.info("{}{}CPNIRV_103.3 : {}", sClassName, sMethodName, stAppInfo);
			return queryCPNIAccountContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					 queryCPNIAccountContactInfoRequest.getIdpTraceId());
		}
		
		if (sAccountType.equals("TITAN") && (sAccountInvId == null || sAccountInvId.isEmpty()) ) {
			stAppInfo = "accountInvariantId is required for accountType " + sAccountType;
			logger.info("{}{}CPNIRV_103.4 : {}", sClassName, sMethodName, StringUtils.normalizeSpace(stAppInfo));
			return queryCPNIAccountContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					 queryCPNIAccountContactInfoRequest.getIdpTraceId());
		}
		
		
		return queryCPNIAccountResponse;
	}
	

	private QueryCPNIAccountContactInfoResponse queryCPNIAccountContactErrorResponse(int appStatusCode, String stAppInfo,  String stIdpTraceId) {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		hmResponse.put(CommonDefs.TRANSACTION_NAME,"QueryCPNIAccountContactInfo");
		return (QueryCPNIAccountContactInfoResponse) CommonUtilHelper.generateCIRResponse(hmResponse);
	}
	
	
	private QueryCPNIAccountContactInfoResponse queryCPNIAccountIsExternalCallCheck(QueryCPNIAccountContactInfoRequest queryCPNIAccountContactInfoRequest) {
		QueryCPNIAccountContactInfoResponse queryCPNIAccountResponse = null;
		String stAppInfo;
		String isExternalCall = queryCPNIAccountContactInfoRequest.getIsExternalCall();
		String stIdpTraceId=queryCPNIAccountContactInfoRequest.getIdpTraceId();
		
		if ((isExternalCall != null && !isExternalCall.isEmpty())) {
			if (!(isExternalCall.equalsIgnoreCase(CommonDefs.IND_Y)
					|| isExternalCall.equalsIgnoreCase(CommonDefs.IND_N))) {
				stAppInfo = "isExternalCall must be one of Y or N";
				return queryCPNIAccountContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						 stIdpTraceId);
			} else {
				queryCPNIAccountContactInfoRequest.setIsExternalCall(isExternalCall.trim().toUpperCase());
			}
		} else {
			queryCPNIAccountContactInfoRequest.setIsExternalCall(CommonDefs.IND_Y);
		}
		return queryCPNIAccountResponse;
	}
}

