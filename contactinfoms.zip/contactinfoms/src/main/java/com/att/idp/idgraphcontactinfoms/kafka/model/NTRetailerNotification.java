package com.att.idp.idgraphcontactinfoms.kafka.model;

import java.io.Serializable;

import com.att.idp.idgraphcontactinfoms.resource.request.DeliveryMethods;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.kafka.model package.
 * It implements the Serializable interface, allowing instances of this class to be converted into a byte stream.
 *
 * The class is used to represent notifications from the NTRetailer system.
 * It contains several fields that represent various properties of the notification, such as the calling system ID, trace ID, transaction name, account ID, account type, identification type, browser language, and delivery methods.
 *
 * The class is annotated with @NoArgsConstructor, @Data, @AllArgsConstructor, and @JsonInclude.
 * The @NoArgsConstructor annotation is used to generate a no-argument constructor.
 * The @Data annotation is used to generate getters, setters, equals, hashCode, and toString methods.
 * The @AllArgsConstructor annotation is used to generate a constructor with arguments for all fields.
 * The @JsonInclude annotation is used to specify that only non-null properties are to be included in JSON serialization/deserialization.
 *
 * The class also overrides the toString method, providing a custom string representation of the object.
 */
@NoArgsConstructor
@Data
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NTRetailerNotification  implements Serializable{

	private static final long serialVersionUID = 1L;

	private String callingSystemId;
	
	private String idpTraceId;
	private String transactionName;
	private String accountId;
	private String accountType;
	private String identificationType;
	private String browserLanguage;
	private DeliveryMethods deliveryMethods;
	@Override
	public String toString() {
		return "NTRetailerNotification [callingSystemId=" + callingSystemId + ", idpTraceId=" + idpTraceId
				+ ", transactionName=" + transactionName + ", accountId=" + accountId + ", accountType=" + accountType
				+ ", identificationType=" + identificationType + ", browserLanguage=" + browserLanguage
				+ ", deliveryMethods=" + deliveryMethods + "]";
	}
	
}
