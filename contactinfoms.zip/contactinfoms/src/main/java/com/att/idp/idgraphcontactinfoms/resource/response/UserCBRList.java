package com.att.idp.idgraphcontactinfoms.resource.response;

import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.response package.
 *
 * The UserCBRList class is used to represent a list of user CBRs (Customer Behavior Reports).
 * It contains four fields: guid, handle, domain, and usPhoneNumber.
 *
 * The guid field is a string that represents the globally unique identifier of the user.
 * The handle field is a string that represents the handle of the user.
 * The domain field is a string that represents the domain of the user.
 * The usPhoneNumber field is an object of the CBRUSPhoneNumber class, representing the US phone number of the user.
 *
 * Each field has a corresponding getter and setter method, allowing the fields to be accessed and modified.
 */
@Data
public class UserCBRList {

	private String guid;
	private String handle;
	private String domain;
	private CBRUSPhoneNumber usPhoneNumber;
}