package com.att.idp.idgraphcontactinfoms.appconfig.config;

import jakarta.annotation.PostConstruct;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;
import java.util.List;

@Configuration
@RefreshScope
@Getter
@Setter
public class IDGraphAzureAppConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(IDGraphAzureAppConfig.class);
    private static final String DEFAULT_PREFERRED_REGIONS_RAW = "East US 2, West US 2";

    @Value("${appconfig.version:0.0.0}")
    private String version;

    @Value("${appconfig.tomcat.jdbc.pool.max_size:${tomcat.jdbc.pool.max_size:100}}")
    private int maxSize;

    @Value("${appconfig.tomcat.jdbc.pool.min_size:${tomcat.jdbc.pool.min_size:5}}")
    private int minSize;

    @Value("${appconfig.tomcat.jdbc.pool.initial-size:${tomcat.jdbc.pool.initial-size:5}}")
    private int initialSize;

    @Value("${appconfig.tomcat.jdbc.pool.test-on-borrow:${tomcat.jdbc.pool.test-on-borrow:true}}")
    private boolean testOnBorrow;

    @Value("${appconfig.tomcat.jdbc.pool.test-while-idle:${tomcat.jdbc.pool.test-while-idle:true}}")
    private boolean testWhileIdle;

    @Value("${appconfig.tomcat.jdbc.pool.validation-query:${tomcat.jdbc.pool.validation-query:SELECT 1 FROM DUAL}}")
    private String validationQuery;

    @Value("${appconfig.tomcat.jdbc.pool.query-timeout:${tomcat.jdbc.pool.query-timeout:60}}")
    private int queryTimeout;

    @Value("${appconfig.tomcat.jdbc.pool.max-wait:${tomcat.jdbc.pool.max-wait:30000}}")
    private int connTimeout;

    @Value("${appconfig.tomcat.jdbc.pool.evictTime:${tomcat.jdbc.pool.evictTime:5000}}")
    private int evictTime;

    @Value("${appconfig.apiclient.rest.inquireprofilerestclient.connectTimeout:${apiclient.rest.inquireprofilerestclient.connectTimeout:30000}}")
    private int inquireprofilerestclientConnectTimeout;

    @Value("${appconfig.apiclient.rest.inquireprofilerestclient.readTimeout:${apiclient.rest.inquireprofilerestclient.readTimeout:10000}}")
    private int inquireprofilerestclientReadTimeout;

    @Value("${appconfig.apiclient.rest.ccmulesoft.connectTimeout:${apiclient.rest.ccmulesoft.connectTimeout:30000}}")
    private int ccmulesoftConnectTimeout;

    @Value("${appconfig.apiclient.rest.ccmulesoft.readTimeout:${apiclient.rest.ccmulesoft.readTimeout:10000}}")
    private int ccmulesoftReadTimeout;

    @Value("${appconfig.apiclient.rest.cgrestclient.connectTimeout:${apiclient.rest.cgrestclient.connectTimeout:30000}}")
    private int cgConnectTimeout;

    @Value("${appconfig.apiclient.rest.cgrestclient.readTimeout:${apiclient.rest.cgrestclient.readTimeout:10000}}")
    private int cgReadTimeout;

    @Value("${appconfig.mq.reconnect.timeout.sec:${mq.reconnect.timeout.sec:10}}")
    private int mqReconnectTimeoutSec;

    @Value("${appconfig.bds.connect.timeout.sec:${bds.connect.timeout.sec:10}}")
    private int bdsConnectTimeoutSec;

    @Value("${appconfig.bds.read.timeout.sec:${bds.read.timeout.sec:5}}")
    private int bdsReadTimeoutSec;

    @Value("${appconfig.lscrm.connect.timeout.millisec:${lscrm.connect.timeout:10000}}")
    private int lscrmConnectTimeout;

    @Value("${appconfig.lscrm.read.timeout.millisec:${lscrm.read.timeout:10000}}")
    private int lscrmReadTimeout;

    @Value("${appconfig.lscrm.soap.connect.timeout.refreshEnabled:${lscrm.soap.connect.timeout.refreshEnabled:false}}")
    private boolean lscrmSoapHttpClientRefreshEnabled;

    @Value("${appconfig.tomcat.datasource.refreshEnabled:${tomcat.datasource.refreshEnabled:false}}")
    private boolean dataSourceRefreshEnabled;

    @Value("${appconfig.contactms.jms.mqconnect.refreshEnabled:${contactms.jms.mqconnect.refreshEnabled:false}}")
    private boolean mqconnectRefreshEnabled;

    @Value("${appconfig.apiclient.rest.ccmulesoft.timeout.refreshEnabled:${apiclient.rest.ccmulesoft.timeout.refreshEnabled:false}}")
    private boolean ccmulesoftRestClientRefreshEnabled;

    @Value("${appconfig.apiclient.rest.inquire.timeout.refreshEnabled:${apiclient.rest.inquire.timeout.refreshEnabled:false}}")
    private boolean inquireRestClientRefreshEnabled;

    @Value("${appconfig.apiclient.rest.cg.timeout.refreshEnabled:${apiclient.rest.cg.timeout.refreshEnabled:false}}")
    private boolean cgRestClientRefreshEnabled;

    @Value("${appconfig.apiclient.rest.profilerestclient.connectTimeout:${apiclient.rest.profilerestclient.connectTimeout:30000}}")
    private int profileConnectTimeout;

    @Value("${appconfig.apiclient.rest.profilerestclient.readTimeout:${apiclient.rest.profilerestclient.readTimeout:10000}}")
    private int profileReadTimeout;

    @Value("${appconfig.apiclient.rest.profile.timeout.refreshEnabled:${apiclient.rest.profile.timeout.refreshEnabled:false}}")
    private boolean profileRestClientRefreshEnabled;

    @Value("${http.pool.maxTotal:200}")
    private int httpPoolMaxTotal;

    @Value("${http.pool.defaultMaxPerRoute:50}")
    private int httpPoolDefaultMaxPerRoute;

    @Value("${http.pool.connectionRequestTimeout:5000}")
    private int httpPoolConnectionRequestTimeout;

    // === Cassandra Connection Timeout Properties ===

    @Value("${spring.cassandra.connection.connect-timeout:2000}")
    private int cassandraConnectTimeoutMs;

    @Value("${spring.cassandra.connection.init-query-timeout:10000}")
    private int cassandraInitQueryTimeoutMs;

    @Value("${spring.cassandra.request.timeout:5000}")
    private int cassandraRequestTimeoutMs;

    // === Cosmos DB Connection Timeout Properties ===

    @Value("${idle-connection-timeout:5000}")
    private int idleConnectionTimeoutMs;

    @Value("${max-connection-pool-size:100}")
    private int maxConnectionPoolSize;

    @Value("${spring.cloud.azure.cosmos.preferred-regions:East US 2, West US 2}")
    private String preferredRegionsRaw;

    @Value("${appconfig.logging.level.root:${logging.level.root:INFO}}")
    private String logLevelRoot;

    @Value("${appconfig.logging.level.com.att.idp:${logging.level.com.att.idp:DEBUG}}")
    private String logLevelIdp;

    @Value("${appconfig.logging.level.com.att.idp.logging:${logging.level.com.att.idp.logging:DEBUG}}")
    private String logLevelIdpApi;

    private List<String> preferredRegions;

    @PostConstruct
    void initializeCosmosConnectionSettings() {
        preferredRegions = parsePreferredRegionsOrDefault(
                preferredRegionsRaw,
                DEFAULT_PREFERRED_REGIONS_RAW,
                "spring.cloud.azure.cosmos.preferred-regions");
    }

    private List<String> parsePreferredRegionsOrDefault(String rawValue, String defaultRawValue, String propertyName) {
        String valueToParse = rawValue;
        if (rawValue == null || rawValue.isBlank()) {
            LOGGER.warn("{} is missing; using default value", propertyName);
            valueToParse = defaultRawValue;
        }

        List<String> parsedRegions = Arrays.stream(valueToParse.split(","))
                .map(String::trim)
                .filter(region -> !region.isBlank())
                .toList();

        if (parsedRegions.isEmpty()) {
            LOGGER.warn("{} did not contain valid values; using default value", propertyName);
            return Arrays.stream(defaultRawValue.split(","))
                    .map(String::trim)
                    .filter(region -> !region.isBlank())
                    .toList();
        }

        return parsedRegions;
    }
}

