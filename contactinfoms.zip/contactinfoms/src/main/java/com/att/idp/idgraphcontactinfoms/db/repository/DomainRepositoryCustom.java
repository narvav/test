package com.att.idp.idgraphcontactinfoms.db.repository;

/**
 * This is the DomainRepositoryCustom interface.
 *
 * It is used to declare custom repository methods for the Tdomain entity.
 * These methods are not provided by the JpaRepository and need to be implemented manually.
 *
 * The methods declared in this interface can be used to perform complex queries or database operations that are not supported by the standard JpaRepository methods.
 */
public interface DomainRepositoryCustom {
	
}
