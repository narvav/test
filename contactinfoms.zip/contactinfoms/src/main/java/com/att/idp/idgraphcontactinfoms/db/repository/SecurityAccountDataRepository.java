package com.att.idp.idgraphcontactinfoms.db.repository;

import java.sql.SQLException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.att.idp.idgraphcontactinfoms.db.model.Tsecurityaccount;

/**
 * This is the SecurityAccountDataRepository interface.
 *
 * It extends JpaRepository to provide standard database operations for the Tsecurityaccount entity.
 * The JpaRepository interface is a JPA specific extension of Repository and provides some additional standard JPA operations.
 * It includes methods like save(), findOne(), findAll(), count(), delete() etc.
 *
 * The interface also extends SecurityAccountDataRepositoryCustom to include custom methods for the Tsecurityaccount entity.
 * These methods are not provided by the JpaRepository and need to be implemented manually.
 *
 * The @Repository annotation is used to indicate that the interface is a repository.
 * Spring will detect the interface by classpath scanning and plug in the persistence layer at runtime.
 */

@Repository 
public interface SecurityAccountDataRepository extends JpaRepository<Tsecurityaccount, Long>, SecurityAccountDataRepositoryCustom {
	
	/**
	 * This method is used to get security account data.
	 *
	 * It takes two parameters: identification_type and account_id. Both are of type String.
	 * The identification_type represents the type of identification used for the account.
	 * The account_id represents the ID of the account.
	 *
	 * The method performs a native SQL query on the TSECURITYACCOUNT table where the IDENTIFICATION_TYPE and ACCOUNT_ID match the provided parameters.
	 * The result of the query is a list of Tsecurityaccount entities.
	 *
	 * The @Param annotation is used to bind the method parameters to the query parameters.
	 *
	 * @param identification_type a String representing the type of identification used for the account.
	 * @param account_id a String representing the ID of the account.
	 * @return a List of Tsecurityaccount entities that match the provided identification_type and account_id.
	 * @throws SQLException if a database access error occurs or this method is called on a closed connection.
	 */
	@Query(value = "select * from MPS_OWNER.TSECURITYACCOUNT tsa where tsa.IDENTIFICATION_TYPE = :identification_type and tsa.ACCOUNT_ID = :account_id " , nativeQuery = true)
	public List<Tsecurityaccount> getSecurityAccountData( @Param(value = "identification_type") String identification_type,
										   				  @Param(value = "account_id") String account_id) throws SQLException;
	
	/**
	 * This method is used to get the cumulative failure count for a specific account.
	 *
	 * It takes two parameters: identification_type and account_id. Both are of type String.
	 * The identification_type represents the type of identification used for the account.
	 * The account_id represents the ID of the account.
	 *
	 * The method performs a query on the Tsecurityaccount table where the identificationType and accountId match the provided parameters.
	 * The result of the query is the cumulative failure count for the specified account.
	 *
	 * The @Param annotation is used to bind the method parameters to the query parameters.
	 *
	 * @param identification_type a String representing the type of identification used for the account.
	 * @param account_id a String representing the ID of the account.
	 * @return a Long representing the cumulative failure count for the specified account.
	 * @throws SQLException if a database access error occurs or this method is called on a closed connection.
	 */
	@Query(value = "select tsa.cumulativeFailureCount from Tsecurityaccount tsa where tsa.id.identificationType = :identification_type and tsa.id.accountId = :account_id ")
	public Long getCumulativeFailureCount( @Param(value = "identification_type") String identification_type,
										   				  @Param(value = "account_id") String account_id) throws SQLException;
	

}