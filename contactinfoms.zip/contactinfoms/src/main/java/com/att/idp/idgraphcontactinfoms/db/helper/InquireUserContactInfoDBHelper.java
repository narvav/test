package com.att.idp.idgraphcontactinfoms.db.helper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphcontactinfoms.integration.InquireProfileRestClient;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;

/**
 * The InquireUserContactInfoDBHelper class is a helper class that interacts with the database to retrieve user contact information.
 *
 * It is annotated with @Component to indicate that it is an autodetectable bean, so Spring can pick it up and pull it into the application context.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.db.helper package.
 *
 * It contains a JdbcTemplate property that is autowired, meaning Spring will automatically inject an instance of JdbcTemplate into this class.
 * JdbcTemplate is a Spring JDBC template used to run SQL queries and updates.
 *
 * It also contains a Logger property for logging purposes.
 *
 * The class defines a method for retrieving user contact information from the database, namely inquireUserContactInfo.
 */
@Component
public class InquireUserContactInfoDBHelper {
	
	private static final Logger logger = LoggerFactory.getLogger(InquireUserContactInfoDBHelper.class);
	private static String sClassName = "InquireUserContactInfoDBHelper";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String sContactDetailsQuery = "SELECT contact_email as contactEmail, "
			+ "contact_email_valid as contactEmailValid, "
			+ "TO_CHAR(contact_email_est_date,'MMDDYYYY hh:mm:ss') AS contactEmailEstDate, "
			+ "previous_contact_email as previousContactEmail, contact_email_status as contactEmailStatus "
			+ "FROM MEMBER WHERE member_num = ?";

	/**
	 * This method is responsible for retrieving user contact information from the database based on a given GUID.
	 *
	 * It takes a String as an input parameter, which is the GUID of the user whose contact information is to be retrieved.
	 *
	 * The method first checks if the GUID is null or empty. If it is, it returns an error.
	 * Then, it constructs a SQL query based on the GUID and executes it using the jdbcTemplate.
	 * The result of the query is a list of Maps, where each Map represents a row in the result set.
	 * Each key-value pair in the Map corresponds to a column name and its value in the result set.
	 *
	 * If the query is successful and returns at least one row, the method returns a HashMap containing the result set and a success message.
	 * If the query does not return any rows, it returns a HashMap containing an error message.
	 * If an exception occurs during the execution of the query, it returns a HashMap containing an error message.
	 *
	 * @param sGuid a String containing the GUID of the user whose contact information is to be retrieved.
	 * @return a HashMap containing the result of the query.
	 */
	public HashMap inquireUserContactInfo(String sGuid) {
		String sMethodName =  ".inquireUserContactInfo.";
		HashMap hmResponse = null;
		List alQueryResponse = null;

		try {
			logger.info("{}{}CVS KEYWORDS: ", sClassName, sMethodName);
			logger.info("{}{}DBTOOLS000 : InpParam = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sGuid)));
			
			if (sGuid == null || sGuid.isEmpty()) {
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, "Guid must be present in Input");
				logger.error("{}{}DBTOOLS02 : Guid must be present in Input{}", sClassName, sMethodName);
				return hmResponse;
			}

			logger.info("{}{}DBTOOLS03 : sContactDetailsQuery = {}", sClassName, sMethodName, sContactDetailsQuery);
			alQueryResponse = jdbcTemplate.queryForList(sContactDetailsQuery, sGuid);
			if (alQueryResponse == null || alQueryResponse.isEmpty()) {
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM,
						"Input guid or handle/domain not found");
				logger.info("{}{}DBTOOLS_05 : No rows found", sClassName, sMethodName);
				return hmResponse;
			}
			
			hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "SUCCESS");

			Map hmQueryResponse = (Map) alQueryResponse.get(0);

			hmResponse.put(CommonDefs.CONTACT_EMAIL, hmQueryResponse.get(CommonDefs.CONTACT_EMAIL));
			hmResponse.put(CommonDefs.CONTACT_EMAIL_VALID, hmQueryResponse.get(CommonDefs.CONTACT_EMAIL_VALID));
			hmResponse.put(CommonDefs.CONTACT_EMAIL_EST_DATE, hmQueryResponse.get(CommonDefs.CONTACT_EMAIL_EST_DATE));
			hmResponse.put(CommonDefs.PREVIOUS_CONTACT_EMAIL, hmQueryResponse.get(CommonDefs.PREVIOUS_CONTACT_EMAIL));
			hmResponse.put(CommonDefs.CONTACT_EMAIL_STATUS, hmQueryResponse.get(CommonDefs.CONTACT_EMAIL_STATUS));

		} catch (Exception excp) {
			hmResponse = CommonErrorMap.makeExceptionMap(excp, logger);
		} finally {
			logger.info("{}{}DBTOOLS999: Resposne = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmResponse)));
		}

		return hmResponse;
	}
}
