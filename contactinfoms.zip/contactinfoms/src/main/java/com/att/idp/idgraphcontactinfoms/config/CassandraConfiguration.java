package com.att.idp.idgraphcontactinfoms.config;

import com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig;
import com.datastax.oss.driver.api.core.CqlIdentifier;
import com.datastax.oss.driver.api.core.CqlSession;
import com.datastax.oss.driver.api.core.CqlSessionBuilder;
import com.datastax.oss.driver.api.core.config.DefaultDriverOption;
import com.datastax.oss.driver.api.core.config.DriverConfigLoader;
import jakarta.annotation.PreDestroy;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;

import javax.net.ssl.SSLContext;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.InetSocketAddress;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;

/**
 * Wires Cassandra session refresh into Spring Data Cassandra by exposing a stable proxy CqlSession bean.
 */
@Configuration
@RequiredArgsConstructor
public class CassandraConfiguration {

    private static final Logger log = LoggerFactory.getLogger(CassandraConfiguration.class);

    private final IDGraphAzureAppConfig idGraphAzureAppConfig;

    @Value("${spring.cassandra.contact-points}")
    private String contactPoints;

    @Value("${spring.cassandra.port}")
    private int port;

    @Value("${spring.cassandra.local-datacenter}")
    private String localDatacenter;

    @Value("${spring.cassandra.username}")
    private String username;

    @Value("${spring.cassandra.password}")
    private String password;

    @Value("${spring.cassandra.keyspace-name}")
    private String keyspaceName;

    @Value("${spring.cassandra.ssl.enabled:false}")
    private boolean sslEnabled;

    // Keep field for compatibility with existing tests/reflection.
    protected volatile CqlSession cqlSession;

    @Bean
    public CqlSession cassandraSessionProxy() throws NoSuchAlgorithmException {
        if (cqlSession == null) {
            cqlSession = buildCqlSession();
        }

        InvocationHandler handler = new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                CqlSession target = cqlSession;
                if (target == null) {
                    throw new IllegalStateException("No active Cassandra session available");
                }
                return method.invoke(target, args);
            }
        };

        return (CqlSession) Proxy.newProxyInstance(
                CqlSession.class.getClassLoader(),
                new Class<?>[]{CqlSession.class},
                handler
        );
    }

    @EventListener(RefreshScopeRefreshedEvent.class)
    public synchronized void onConfigurationRefresh(RefreshScopeRefreshedEvent event) {
        log.info("Config refresh detected (name={}). Rebuilding CqlSession...",
                event != null ? event.getName() : "<null>");
        try {
            CqlSession newSession = buildCqlSession();
            CqlSession oldSession = cqlSession;
            cqlSession = newSession;
            closeQuietly(oldSession);

            log.info("CqlSession rebuilt: appconfig.version [{}], connectTimeoutMs [{}], initQueryTimeoutMs [{}], requestTimeoutMs [{}], maxConnectionPoolSize [{}], sslEnabled [{}]",
                    idGraphAzureAppConfig.getVersion(),
                    idGraphAzureAppConfig.getCassandraConnectTimeoutMs(),
                    idGraphAzureAppConfig.getCassandraInitQueryTimeoutMs(),
                    idGraphAzureAppConfig.getCassandraRequestTimeoutMs(),
                    idGraphAzureAppConfig.getMaxConnectionPoolSize(),
                    sslEnabled);
        } catch (Exception e) {
            log.error("Failed to rebuild CqlSession on config refresh. Retaining the existing session.", e);
        }
    }

    protected CqlSession buildCqlSession() throws NoSuchAlgorithmException {
        int maxPoolSize = idGraphAzureAppConfig.getMaxConnectionPoolSize();
        int connectTimeout = idGraphAzureAppConfig.getCassandraConnectTimeoutMs();
        int initQueryTimeout = idGraphAzureAppConfig.getCassandraInitQueryTimeoutMs();
        int requestTimeout = idGraphAzureAppConfig.getCassandraRequestTimeoutMs();

        DriverConfigLoader configLoader = DriverConfigLoader.programmaticBuilder()
                .withDuration(DefaultDriverOption.CONNECTION_CONNECT_TIMEOUT, Duration.ofMillis(connectTimeout))
                .withDuration(DefaultDriverOption.CONNECTION_INIT_QUERY_TIMEOUT, Duration.ofMillis(initQueryTimeout))
                .withDuration(DefaultDriverOption.REQUEST_TIMEOUT, Duration.ofMillis(requestTimeout))
                .withInt(DefaultDriverOption.CONNECTION_POOL_LOCAL_SIZE, maxPoolSize)
                .build();

        log.info("Building CqlSession: host [{}], port [{}], datacenter [{}], keyspace [{}], usernamePresent [{}], passwordPresent [{}], connectTimeoutMs [{}], initQueryTimeoutMs [{}], requestTimeoutMs [{}], maxPoolSize [{}], sslEnabled [{}]",
                contactPoints, port, localDatacenter, keyspaceName,
                username != null && !username.isBlank(),
                password != null && !password.isBlank(),
                connectTimeout, initQueryTimeout, requestTimeout, maxPoolSize, sslEnabled);

        CqlSessionBuilder builder = CqlSession.builder()
                .addContactPoint(new InetSocketAddress(contactPoints, port))
                .withLocalDatacenter(localDatacenter)
                .withAuthCredentials(username, password)
                .withKeyspace(CqlIdentifier.fromCql(keyspaceName))
                .withConfigLoader(configLoader);

        if (sslEnabled) {
            builder.withSslContext(SSLContext.getDefault());
        }

        return builder.build();
    }

    @PreDestroy
    public void shutdown() {
        CqlSession session = cqlSession;
        cqlSession = null;
        closeQuietly(session);
    }

    private void closeQuietly(CqlSession session) {
        if (session == null) {
            return;
        }
        try {
            session.close();
        } catch (Exception e) {
            log.warn("Failed to close Cassandra session cleanly.", e);
        }
    }
}