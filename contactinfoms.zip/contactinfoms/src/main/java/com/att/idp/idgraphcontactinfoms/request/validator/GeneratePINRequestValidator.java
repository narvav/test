package com.att.idp.idgraphcontactinfoms.request.validator;

import java.util.*;

import jakarta.ws.rs.core.HttpHeaders;

import com.att.idp.idgraphcontactinfoms.resource.request.AttributeList;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphcontactinfoms.resource.request.GeneratePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.GeneratePINResponse;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.idp.idgraphcontactinfoms.utils.ProfileOrchestrationConstants;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.idp.idgraphcontactinfoms.utils.Constants;

/**
 * This class is responsible for validating the GeneratePINRequest.
 *
 * It uses the Spring Framework's @Configuration and @PropertySource annotations to indicate that it is a source of bean definitions and to load properties from a specified location.
 *
 * The class has several instance variables that are injected using the @Value annotation.
 * These variables are used to store configuration values such as the valid PIN CSI, PIN delivery methods, PIN agent CSI, PIN attribute name, and PIN attribute value.
 *
 * The main method in this class is the generatePINRequestValidator method, which takes HttpHeaders and a GeneratePINRequest as input and returns a GeneratePINResponse.
 * The generatePINRequestValidator method performs various checks on the input parameters and calls other private methods for further validation.
 *
 * The class also contains several private methods for validating the input parameters and constructing an error response.
 *
 * The class also contains a logger for logging information and error messages.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class GeneratePINRequestValidator {

	private static final Logger logger = LoggerFactory.getLogger(GeneratePINRequestValidator.class);
	private static final String CLIENT_ID_UST = "UST";

	private String sClassName = "GeneratePINRequestValidator";

	@Value("${PROP_PIN_CSI}")
	private String propCallingSystemId;

	@Value("${PROP_PIN_DELIVERY_METHODS}")
	private String propDeliveryMethods;

	@Value("${PROP_PIN_AGENT_CSI}")
	private String propAgentCallingSystemId;

	@Value("${PROP_PIN_ATTRIBUTE_NAME}")
	private String propAttributeName;

	@Value("${PROP_PIN_ATTRIBUTE_VALUE}")
	private String propAttributeValue;


	/**
	 * This method is responsible for validating the GeneratePINRequest.
	 *
	 * It takes HttpHeaders and a GeneratePINRequest as input parameters and returns a GeneratePINResponse.
	 * The method performs various checks on the input parameters and calls other private methods for further validation.
	 * If the validation is successful, the method returns a GeneratePINResponse. If the validation fails, the method constructs an error response and returns it.
	 *
	 * The method also handles exceptions that can occur during the validation process.
	 *
	 * @param requestHeader HttpHeaders that contains the request headers. These headers are used for logging and tracing purposes.
	 * @param generatePINRequest GeneratePINRequest that contains the request data for the generate PIN operation. This data is validated by the method.
	 * @return a GeneratePINResponse that contains the result of the validation. If the validation is successful, the response contains a success message. If the validation fails, the response contains an error message.
	 */
	public GeneratePINResponse generatePINRequestValidator(HttpHeaders requestHeader,
			GeneratePINRequest generatePINRequest) {

		GeneratePINResponse generatePINResponse = null;

		String stAppInfo = null;
		String sMethodName = ".generatePINRequestValidator.";
		String stIdpTraceId = null;
		String stXAttClientId = null;

		
		
		stIdpTraceId = CommonUtil.getTraceId(requestHeader);
		
		if(stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
			stAppInfo="GeneratePIN Request idp-trace-id is missing";
			return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		
		if (generatePINRequest == null) {
			stAppInfo = "Input Request is NULL / Empty.";
			logger.info("{}{}GPRV_101 :: {}", sClassName, sMethodName, stAppInfo);
			return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		
		generatePINRequest.setIdpTraceId(stIdpTraceId);
		
		String stCallingSystemId = generatePINRequest.getCallingSystemId();
		Optional.ofNullable(stCallingSystemId)
		.ifPresent(x -> generatePINRequest.setCallingSystemId(x.trim().toUpperCase()));
		
		if (stCallingSystemId == null && requestHeader.getHeaderString("X-ATT-ClientId") != null) {
			if (requestHeader.getHeaderString("X-ATT-ClientId").equalsIgnoreCase("idpgwbiz")
					&& StringUtils.isNotBlank(requestHeader.getHeaderString("idpctx-appname"))) {
				stXAttClientId = requestHeader.getHeaderString("idpctx-appname").toUpperCase();
			} else {
				stXAttClientId = requestHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
			}
			logger.info("{}{}: callingSystemId: {}", sClassName, sMethodName, stXAttClientId);
			generatePINRequest.setCallingSystemId(stXAttClientId);
		}

        if (stCallingSystemId != null
                && Constants.CLIENT_ID_CSIGATEWAY.equalsIgnoreCase(stCallingSystemId)
                && Constants.IDENTIFICATION_TYPE_BANPC.equalsIgnoreCase(generatePINRequest.getIdentificationType())) {
            generatePINRequest.setIdentificationType(Constants.IDENTIFICATION_TYPE_NTRETAILER);
            generatePINRequest.setAccountType(CommonDefs.MOBILITY_SERVICE);
        }

        if(CLIENT_ID_UST.equalsIgnoreCase(generatePINRequest.getCallingSystemId())){//For UST, we will not be calling backend (EDD/CLM) to send PIN. Instead, we will generate PIN and return it to the user.
			generatePINRequest.setReturnSecurityCode(CommonDefs.IND_Y);
			generatePINRequest.setDeliveryMethods(null);
		}
				
		// checking Invalid attributes passed in Request
		Map<String, Object> allUnknownAttributes = new HashMap<>(generatePINRequest.unknownAttributes);
		if (generatePINRequest.getAttributeList()!=null && !generatePINRequest.getAttributeList().isEmpty()) {
			List<AttributeList> attributeListList = generatePINRequest.getAttributeList();
			for (AttributeList attributeList : attributeListList) {
				allUnknownAttributes.putAll(attributeList.getUnknownAttributes());
			}
		}
		if (!allUnknownAttributes.isEmpty()) {
			stAppInfo = "Invalid Attributes passed in generatePINRequest : " + allUnknownAttributes;
			return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					generatePINRequest.getIdpTraceId());
		}
		try {
			generatePINResponse = generatePINRequestInputValidator(generatePINRequest);
			if (generatePINResponse != null) {
				logger.info("{}{}GPRV_112 Response from generatePINRequestInputValidator : {}", sClassName, sMethodName,
						generatePINResponse);
				return generatePINResponse;
			}

			generatePINResponse = generatePINRequestCSIValidator(generatePINRequest);
			if (generatePINResponse != null) {
				logger.info("{}{}GPRV_116 Response from generatePINRequestCSIValidator : {}", sClassName, sMethodName,
						generatePINResponse);
				return generatePINResponse;
			}

			generatePINResponse = generatePINRequestAgentCSIValidator(generatePINRequest);
			if (generatePINResponse != null) {
				logger.info("{}{}GPRV_120 Response from generatePINRequestAgentCSIValidator : {}", sClassName,
						sMethodName, generatePINResponse);
				return generatePINResponse;
			}

			generatePINResponse = generatePINRequestDeliveryMethodsValidator(generatePINRequest);
			if (generatePINResponse != null) {
				logger.info("{}{}GPRV_130 Response from generatePINRequestDeliveryMethodsValidator : {}", sClassName,
						sMethodName, generatePINResponse);
				return generatePINResponse;
			}

			if (Optional.ofNullable(generatePINRequest.getAttributeList()).isPresent()) {
				generatePINResponse = generatePINRequestAttributeListValidator(generatePINRequest);

				if (generatePINResponse != null) {
					logger.info("{}{}GPRV_136 Response from generatePINRequestAttributeListValidator : {}", sClassName,
							sMethodName, generatePINResponse);
					return generatePINResponse;
				}
			}
			stAppInfo = "Input Validation Successful";
			logger.info("{}{}GPRV_137 : {}", sClassName, sMethodName, stAppInfo);

		} catch (Exception e) {
			stAppInfo = "Exception thrown in generatePINRequestValidator.generatePINRequestValidator : "
					+ e.getMessage();
			generatePINErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo, stIdpTraceId);
			logger.info("Exception in generatePINRequestValidator: {}", stAppInfo);
		}

		return generatePINResponse;
	}

	private GeneratePINResponse generatePINRequestCSIValidator(GeneratePINRequest generatePINRequest) {
		String sMethodName = ".generatePINRequestCSIValidator.";
		String stCallingSystemId = generatePINRequest.getCallingSystemId();
		String stIdentificationType = generatePINRequest.getIdentificationType();
		String stIdpTraceId = generatePINRequest.getIdpTraceId();
		String stAppInfo = null;

		ArrayList alValidCaller = null;

		logger.info("{}{}GPB_112.1 : PROP_PIN_CSI : {}", sClassName, sMethodName, propCallingSystemId);
		if (propCallingSystemId.isEmpty()) {
			stAppInfo = "The value of generatePINCallingSystemIds is not configured in property files";
			logger.debug("{}{}GPRV_113 : {}", sClassName, sMethodName, stAppInfo);
			return generatePINErrorResponse(CErrorDefs.ERR_CONFIG_NUM, stAppInfo, stIdpTraceId);
		}

		HashMap<String, Object> hmPropPinCsi = CommonUtil.parseMultiDelimiterProperty(propCallingSystemId);

		if (hmPropPinCsi != null && !hmPropPinCsi.isEmpty()) {
			if (!hmPropPinCsi.containsKey(stIdentificationType)) {
				stAppInfo = "Input identificationType is not valid";
				logger.info("{}{}GPRV_114 : {}", sClassName, sMethodName, stAppInfo);
				return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}

			alValidCaller = (ArrayList) hmPropPinCsi.get(stIdentificationType);
		}

		if (alValidCaller != null && !alValidCaller.contains(stCallingSystemId)) {
			stAppInfo = "X-ATT-ClientId or callingSystemId is not valid for input identificationType";
			logger.info("{}{}GPRV_115 : {}", sClassName, sMethodName, stAppInfo);
			return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		return null;
	}

	private GeneratePINResponse generatePINRequestAgentCSIValidator(GeneratePINRequest generatePINRequest) {
		String sMethodName = ".generatePINRequestAgentCSIValidator.";
		String stCallingSystemId = generatePINRequest.getCallingSystemId();
		Map<String, Object> hmInpDeliveryMethods = CommonUtilHelper
				.objectToMap(generatePINRequest.getDeliveryMethods());
		String stAgentId = generatePINRequest.getAgentId();
		String stIdpTraceId = generatePINRequest.getIdpTraceId();
		String stIdentificationType = generatePINRequest.getIdentificationType();
		String stAppInfo = null;

		ArrayList alPropPinAgentCsi = CommonUtil.parseToArray(propAgentCallingSystemId,
				CommonDefs.VALUE_SEPARATOR_CHAR);

		logger.debug("{}{}GPRV_117 : PROP_PIN_AGENT_CSI : {}", sClassName, sMethodName, alPropPinAgentCsi);

		if (alPropPinAgentCsi != null && !alPropPinAgentCsi.isEmpty()
				&& alPropPinAgentCsi.contains(stCallingSystemId) ) {
			if (StringUtils.isEmpty(stAgentId)) {
				stAppInfo = "agentId is required";
				logger.info("{}{}GPRV_118 : {}", sClassName, sMethodName, stAppInfo);
				return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}

			if ((hmInpDeliveryMethods == null || hmInpDeliveryMethods.isEmpty() )&& !stIdentificationType.equals(ProfileOrchestrationConstants.PORTOUTABS_IDENTIFICATION_TYPE)) {
				stAppInfo = "deliveryMethods is required for agentId";
				logger.info("{}{}GPRV_119 : {}", sClassName, sMethodName, stAppInfo);
				return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
		}

		return null;
	}

	/**
	 * This method is responsible for validating the input parameters of the GeneratePINRequest.
	 *
	 * It first retrieves various values from the GeneratePINRequest, such as the idpTraceId, browserLanguage, returnSecurityCode, resBusInd, and agentId.
	 * It then trims and formats these values as necessary.
	 *
	 * The method performs various checks on these values. If any of the checks fail, it returns an error response.
	 * These checks include:
	 * - Checking if the transactionName is "GeneratePIN".
	 * - Checking if the callingSystemId is not null or empty.
	 * - Checking if the identificationType and accountId are not null or empty.
	 * - Checking if the accountType is not null or empty when the identificationType is "NTRETAILER".
	 *
	 * If all checks pass, the method returns null, indicating that the validation was successful.
	 *
	 * @param generatePINRequest GeneratePINRequest that contains the request data for the generate PIN operation. This data is validated by the method.
	 * @return a GeneratePINResponse that contains the result of the validation. If the validation is successful, the method returns null. If the validation fails, the method constructs an error response and returns it.
	 */
	public GeneratePINResponse generatePINRequestInputValidator(GeneratePINRequest generatePINRequest) {
		String stAppInfo = null;
		GeneratePINResponse generatePINResponse = null;
		String sMethodName = ".generatePINRequestInputValidator.";

		String stIdpTraceId = generatePINRequest.getIdpTraceId();
//		String stTransactionId = generatePINRequest.getTransactionId();
		String stBrowserLang = generatePINRequest.getBrowserLanguage();
		String sReturnSecurityCode = generatePINRequest.getReturnSecurityCode();
		String stResBusInd = generatePINRequest.getResBusInd();
		String stAgentId = generatePINRequest.getAgentId();
		String stIdentificationType = generatePINRequest.getIdentificationType();

		Optional.ofNullable(stIdentificationType)
				.ifPresent(x -> generatePINRequest.setIdentificationType(x.trim().toUpperCase()));
		Optional.ofNullable(stBrowserLang)
				.ifPresent(x -> generatePINRequest.setBrowserLanguage(x.trim().toLowerCase()));
		Optional.ofNullable(sReturnSecurityCode)
				.ifPresent(x -> generatePINRequest.setReturnSecurityCode(x.trim().toUpperCase()));
		Optional.ofNullable(stResBusInd).ifPresent(x -> generatePINRequest.setResBusInd(x.trim().toUpperCase()));
		Optional.ofNullable(stAgentId).ifPresent(x -> generatePINRequest.setAgentId(x.trim().toLowerCase()));
		Optional.ofNullable(generatePINRequest.getAccountType())
		.ifPresent(x -> generatePINRequest.setAccountType(x.trim().toLowerCase()));
		Optional.ofNullable(generatePINRequest.getAccountId())
				.ifPresent(x -> generatePINRequest.setAccountId(x.trim().toLowerCase()));
		
		stBrowserLang = generatePINRequest.getBrowserLanguage();
		sReturnSecurityCode = generatePINRequest.getReturnSecurityCode();
		stResBusInd = generatePINRequest.getResBusInd();

		generatePINResponse = generatePINRequiredFieldCheck(generatePINRequest);

		if (generatePINResponse != null) {
			return generatePINResponse;
		}

		if (StringUtils.isNotEmpty(stBrowserLang) && (!(stBrowserLang.equals("en") || stBrowserLang.equals("es")))) {
			stAppInfo = "BrowserLanguage is Invalid :: Should be one of [en, es]";
			logger.info("{}{}GPRV_109 : {}", sClassName, sMethodName, stAppInfo);
			return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (StringUtils.isNotEmpty(sReturnSecurityCode)
				&& !(sReturnSecurityCode.equals(CommonDefs.IND_Y) || sReturnSecurityCode.equals(CommonDefs.IND_N))) {
			stAppInfo = "returnSecurityCode is Invalid :: Should be one of [Y, N]";
			logger.info("{}{}GPRV_110 : {}", sClassName, sMethodName, stAppInfo);
			return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (StringUtils.isNotEmpty(stResBusInd) && (!(stResBusInd.equals("R") || stResBusInd.equals("B")))) {
			stAppInfo = "resBusInd is Invalid :: Should be one of [R, B]";
			logger.info("{}{}GPRV_111 : {}", sClassName, sMethodName, stAppInfo);
			return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		return generatePINResponse;
	}

	private GeneratePINResponse generatePINRequestDeliveryMethodsValidator(GeneratePINRequest generatePINRequest) {
		String sMethodName = ".generatePINRequestDeliveryMethodsValidator.";
		String stIdpTraceId = generatePINRequest.getIdpTraceId();
		String stAppInfo = null;

		Map<String, Object> hmInpDeliveryMethods = CommonUtilHelper
				.objectToMap(generatePINRequest.getDeliveryMethods());
		HashMap<String, Object> hmpropDeliveryMethods = null;

		if (hmInpDeliveryMethods == null || hmInpDeliveryMethods.isEmpty()) {
		    String returnSecurityCode = generatePINRequest.getReturnSecurityCode();
		    if (returnSecurityCode == null || returnSecurityCode.isEmpty() || !returnSecurityCode.equals(CommonDefs.IND_Y)) {
		        stAppInfo = "Both deliveryMethods and returnSecurityCode are not available. At least one of them is needed in the request.";
		        logger.info("{}{}GPRV_121 : {}", sClassName, sMethodName, stAppInfo);
		        return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		    }
		}else {
			hmpropDeliveryMethods = CommonUtil.parseMultiDelimiterProperty(propDeliveryMethods);
			logger.debug("{}{}GPB_122 : PROP_PIN_DELIVERY_METHODS : {}", sClassName, sMethodName,
					hmpropDeliveryMethods);

			if (hmInpDeliveryMethods.containsKey(CommonDefs.SMS)) {
				if (hmInpDeliveryMethods.containsKey(CommonDefs.EMAIL)
						|| hmInpDeliveryMethods.containsKey(CommonDefs.LETTER)
						|| hmInpDeliveryMethods.containsKey(CommonDefs.AO)) {
					stAppInfo = "exactly one of sms or email or letter or ao deliveryMethod must be present in input";
					logger.info("{}{}GPRV_123 : {}", sClassName, sMethodName, stAppInfo);
					return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
				} else if (!Optional.ofNullable(generatePINRequest.getDeliveryMethods().getSms().getSmsPhoneNumber())
						.isPresent()) {
					stAppInfo = "smsPhoneNumber is missing for sms deliveryMethod";
					logger.info("{}{}GPRV_124 : {}", sClassName, sMethodName, stAppInfo);
					return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
				}
			} else if (hmInpDeliveryMethods.containsKey(CommonDefs.EMAIL)) {
				if (hmInpDeliveryMethods.containsKey(CommonDefs.LETTER)) {
					stAppInfo = "exactly one of sms or email or letter deliveryMethod must be present in input";
					logger.info("{}{}GPRV_125 : {}", sClassName, sMethodName, stAppInfo);
					return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
				} else if (!Optional.ofNullable(generatePINRequest.getDeliveryMethods().getEmail().getEmailAddress())
						.isPresent()) {
					stAppInfo = "emailAddress is missing for email deliveryMethod";
					logger.info("{}{}GPRV_126 : {}", sClassName, sMethodName, stAppInfo);
					return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
				}
			} else if (hmInpDeliveryMethods.containsKey(CommonDefs.LETTER)) {
				HashMap hmLetter = (HashMap) hmInpDeliveryMethods.get(CommonDefs.LETTER);

				String sStreet1 = (String) hmLetter.get(CommonDefs.STREET1);
				String sCity = (String) hmLetter.get(CommonDefs.CITY);
				String sState = (String) hmLetter.get(CommonDefs.STATE);
				String sZipCode = (String) hmLetter.get(CommonDefs.ZIP_CODE);

				if (sStreet1 == null || sStreet1.isEmpty() || sCity == null || sCity.isEmpty()
						|| sState == null || sState.isEmpty() || sZipCode == null || sZipCode.isEmpty()) {
					stAppInfo = "street1|city|state|zipCode are required for letter deliveryMethod";
					logger.info("{}{}GPRV_127 : {}", sClassName, sMethodName, stAppInfo);
					return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
				}
			}

			if (hmInpDeliveryMethods.containsKey(CommonDefs.AO)) {
				String sAoPhoneNumber = generatePINRequest.getDeliveryMethods().getAo().getPhoneNumber();
				if (sAoPhoneNumber == null || sAoPhoneNumber.trim().isEmpty()) {
					stAppInfo = "phoneNumber is required for ao deliveryMethod";
					logger.info("{}{}GPRV_128 : {}", sClassName, sMethodName, stAppInfo);
					return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
				}
			}

			if (hmpropDeliveryMethods != null && !hmpropDeliveryMethods.isEmpty()
					&& hmpropDeliveryMethods.containsKey(generatePINRequest.getIdentificationType())) {
				ArrayList alDeliveryMethods = (ArrayList) hmpropDeliveryMethods
						.get(generatePINRequest.getIdentificationType());
				boolean bValidDeliveryMethodPresent = false;

				for (int i = 0; i < alDeliveryMethods.size(); i++) {
					String sDeliveryMethod = (String) alDeliveryMethods.get(i);
					if (hmInpDeliveryMethods.containsKey(sDeliveryMethod)) {
						bValidDeliveryMethodPresent = true;
						break;
					}
				}

				if (!bValidDeliveryMethodPresent) {
					stAppInfo = "Input delivery method is not supported for input identificationType";
					logger.info("{}{}GPRV_129 : {}", sClassName, sMethodName, stAppInfo);
					return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
				}
			}
		}
		return null;
	}

	private GeneratePINResponse generatePINRequestAttributeListValidator(GeneratePINRequest generatePINRequest) {
		String sMethodName = ".generatePINRequestAttributeListValidator.";
		String stIdpTraceId = generatePINRequest.getIdpTraceId();
		String stIdentificationType = generatePINRequest.getIdentificationType();
		String stAppInfo = null;

		if (!(Optional.ofNullable(propAttributeName).isPresent()
				|| Optional.ofNullable(propAttributeValue).isPresent())) {
			stAppInfo = "PropPinAttributeName | propAttributeValue value is null or empty";
			logger.debug("{}{}GPRV_131 : {}", sClassName, sMethodName, stAppInfo);
			return generatePINErrorResponse(CErrorDefs.ERR_CONFIG_NUM, stAppInfo, stIdpTraceId);
		}

		HashMap<String, Object> hmPropPinAttributeName = CommonUtil.parseMultiDelimiterProperty(propAttributeName);
		HashMap<String, Object> hmPropPinAttributeValue = CommonUtil.parseMultiDelimiterProperty(propAttributeValue);

		ArrayList<HashMap<String, Object>> alAttributes = (ArrayList) CommonUtilHelper
				.objectToListOfMap(generatePINRequest.getAttributeList());

		for (HashMap<String, Object> hmAttributes : alAttributes) {

			if (hmAttributes != null && !hmAttributes.isEmpty()) {
				String sAttributeName = (String) hmAttributes.get(CommonDefs.ATTRIBUTE_NAME);
				String sAttributeValue = (String) hmAttributes.get(CommonDefs.ATTRIBUTE_VALUE);

				if (StringUtils.isEmpty(sAttributeName)) {
					stAppInfo = "Input AttributeName is null or empty";
					logger.info("{}{}GPRV_132 : {}", sClassName, sMethodName, stAppInfo);
					return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
				}

				if (StringUtils.isEmpty(sAttributeValue)) {
					stAppInfo = "Input AttributeValue is null or empty";
					logger.info("{}{}GPRV_133 : {}", sClassName, sMethodName, stAppInfo);
					return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
				}

				if (hmPropPinAttributeName != null && !hmPropPinAttributeName.isEmpty()) {
					ArrayList alValidAttributes = (ArrayList) hmPropPinAttributeName.get(stIdentificationType);
					if (alValidAttributes == null || !alValidAttributes.contains(sAttributeName)) {
						stAppInfo = "Input IdentificationType is not valid for input attributeName";
						logger.info("{}{}GPRV_134 : {}", sClassName, sMethodName, stAppInfo);
						return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
					}
				}

				if (hmPropPinAttributeValue != null && !hmPropPinAttributeValue.isEmpty()) {
					ArrayList alValidAttributesValues = (ArrayList) hmPropPinAttributeValue.get(sAttributeName);
					if (!sAttributeName.equals("CustomerName") && (alValidAttributesValues == null || !alValidAttributesValues.contains(sAttributeValue))) {
						stAppInfo = "Input attributeName is not valid for input attributeValue";
						logger.info("{}{}GPRV_135 : {}", sClassName, sMethodName, stAppInfo);
						return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
					}
				}
			}
		}
		return null;
	}

	private GeneratePINResponse generatePINRequiredFieldCheck(GeneratePINRequest generatePINRequest) {

		String stAppInfo = null;
		GeneratePINResponse generatePINResponse = null;
		String sMethodName = ".generatePINRequiredFieldCheck.";

		String stCallingSystemId = generatePINRequest.getCallingSystemId();
//		String stTransactionId = generatePINRequest.getTransactionId();
		String stTransactionName = generatePINRequest.getTransactionName();
		String stIdentificationType = generatePINRequest.getIdentificationType();
		String stAccountId = generatePINRequest.getAccountId();
		String stAccountType = generatePINRequest.getAccountType();
		String stIdpTraceId = generatePINRequest.getIdpTraceId();

		if (StringUtils.isEmpty(stTransactionName)) {
			stAppInfo = "TransactionName can not be null / empty.";
			logger.info("{}{}GPRV_104 : {}", sClassName, sMethodName, stAppInfo);
			return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		} else if (!"GeneratePIN".equals(stTransactionName)) {
			stAppInfo = "Transaction Not Allowed :: TransactionName Should be GeneratePIN";
			logger.info("{}{}GPRV_105 : {}", sClassName, sMethodName, stAppInfo);
			return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (StringUtils.isEmpty(stCallingSystemId)) {
			stAppInfo = "Either X-ATT-ClientId in request header or callingSystemId in request body must be present";
			logger.info("{}{}GPRV_106 : {}", sClassName, sMethodName, stAppInfo);
			return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (StringUtils.isBlank(stIdentificationType)) {
			stAppInfo = "IdentificationType can not be null / empty.";
			logger.info("{}{}GPRV_107 : {}", sClassName, sMethodName, stAppInfo);
			return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (StringUtils.isBlank(stAccountId)) {
			stAppInfo = "AccountID can not be null / empty.";
			logger.info("{}{}GPRV_108 : {}", sClassName, sMethodName, stAppInfo);
			return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		
		if (StringUtils.isNotBlank(stIdentificationType) && stIdentificationType.equalsIgnoreCase("NTRETAILER")
				&& StringUtils.isBlank(stAccountType)) {
				stAppInfo = "AccountType can not be null / empty.";
			logger.info("{}{}GPRV_109 : {}", sClassName, sMethodName, stAppInfo);
			return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		
		if(generatePINRequest.getReturnSecurityCode()==null && generatePINRequest.getDeliveryMethods()==null) {
			stAppInfo = "ReturnSecurityCode and DeliveryMethods both can not be null / empty.";
			logger.info("{}{}GPRV_109.1 : {}", sClassName, sMethodName, stAppInfo);
			return generatePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		
		return generatePINResponse;
	}

	private GeneratePINResponse generatePINErrorResponse(int appStatusCode, String stAppInfo, String stIdpTraceId) {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		return CommonUtilHelper.generatePINResponse(hmResponse);
	}
}
