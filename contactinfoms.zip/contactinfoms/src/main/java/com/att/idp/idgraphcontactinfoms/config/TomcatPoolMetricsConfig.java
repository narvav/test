package com.att.idp.idgraphcontactinfoms.config;

import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.binder.MeterBinder;
import org.apache.tomcat.jdbc.pool.ConnectionPool;
import org.apache.tomcat.jdbc.pool.XADataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration class to expose Tomcat JDBC connection pool metrics
 * to Spring Boot Actuator /metrics endpoint.
 */
@Configuration
public class TomcatPoolMetricsConfig {

    @Autowired
    private XADataSource xaDataSource;

    private ConnectionPool connectionPool() {
        try {
            return xaDataSource.getPool();
        } catch (Exception e) {
            return null;
        }
    }

    @Bean
    public MeterBinder tomcatPoolMetrics() {
        return new MeterBinder() {
            @Override
            public void bindTo(MeterRegistry registry) {
                // Active connections
                Gauge.builder("tomcat.pool.connections.active", TomcatPoolMetricsConfig.this,
                                cfg -> {
                                    ConnectionPool pool = cfg.connectionPool();
                                    return pool == null ? 0.0d : pool.getActive();
                                })
                        .description("Number of active connections in the pool")
                        .register(registry);

                // Idle connections
                Gauge.builder("tomcat.pool.connections.idle", TomcatPoolMetricsConfig.this,
                                cfg -> {
                                    ConnectionPool pool = cfg.connectionPool();
                                    return pool == null ? 0.0d : pool.getIdle();
                                })
                        .description("Number of idle connections in the pool")
                        .register(registry);

                // Maximum pool size
                Gauge.builder("tomcat.pool.max.active", TomcatPoolMetricsConfig.this,
                                cfg -> {
                                    XADataSource ds = cfg.xaDataSource;
                                    return ds == null ? 0.0d : ds.getMaxActive();
                                })
                        .description("Maximum number of active connections")
                        .register(registry);

                // Minimum idle connections
                Gauge.builder("tomcat.pool.min.idle", TomcatPoolMetricsConfig.this,
                                cfg -> {
                                    XADataSource ds = cfg.xaDataSource;
                                    return ds == null ? 0.0d : ds.getMinIdle();
                                })
                        .description("Minimum number of idle connections")
                        .register(registry);

                // Total connections created
                Gauge.builder("tomcat.pool.connections.created", TomcatPoolMetricsConfig.this,
                                cfg -> {
                                    ConnectionPool pool = cfg.connectionPool();
                                    return pool == null ? 0.0d : pool.getSize();
                                })
                        .description("Total number of connections created")
                        .register(registry);

                // Connection requests
                Gauge.builder("tomcat.pool.connection.requests", TomcatPoolMetricsConfig.this,
                                cfg -> {
                                    ConnectionPool pool = cfg.connectionPool();
                                    return pool == null ? 0.0d : pool.getBorrowedCount();
                                })
                        .description("Total number of connection requests")
                        .register(registry);

                // Max wait time
                Gauge.builder("tomcat.pool.max.wait", TomcatPoolMetricsConfig.this,
                                cfg -> {
                                    XADataSource ds = cfg.xaDataSource;
                                    return ds == null ? 0.0d : ds.getMaxWait();
                                })
                        .description("Maximum wait time for a connection (ms)")
                        .register(registry);

                // Pool size (active + idle)
                Gauge.builder("tomcat.pool.size", TomcatPoolMetricsConfig.this,
                                cfg -> {
                                    ConnectionPool pool = cfg.connectionPool();
                                    return pool == null ? 0.0d : (pool.getActive() + pool.getIdle());
                                })
                        .description("Current pool size (active + idle)")
                        .register(registry);
            }
        };
    }
}
