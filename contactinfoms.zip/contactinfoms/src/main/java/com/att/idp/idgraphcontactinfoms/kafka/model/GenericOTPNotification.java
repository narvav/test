package com.att.idp.idgraphcontactinfoms.kafka.model;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.kafka.model package.
 * It implements the Serializable interface, allowing instances of this class to be converted into a byte stream.
 *
 * The class is used to represent notifications from the GenericOTPNotification system.
 * It contains several fields that represent various properties of the notification, such as the calling system ID, trace ID, transaction name, account ID, account type, identification type, browser language, and delivery methods.
 *
 * The class is annotated with @NoArgsConstructor, @Data, @AllArgsConstructor, and @JsonInclude.
 * The @NoArgsConstructor annotation is used to generate a no-argument constructor.
 * The @Data annotation is used to generate getters, setters, equals, hashCode, and toString methods.
 * The @AllArgsConstructor annotation is used to generate a constructor with arguments for all fields.
 * The @JsonInclude annotation is used to specify that only non-null properties are to be included in JSON serialization/deserialization.
 *
 * The class also overrides the toString method, providing a custom string representation of the object.
 * 
 * message Format
 * {
    "notificationID": "IDGRAPHContactInfoMs-8c906f568000f61:8c906f568000f61:0:0",
    "notificationType": "OTP",
    "notificationCategory": "GeneratePIN",
    "notificationsubCategory": "PORTOUTBSS",
    "notificationTime": "2024-09-09 01:47:22Z",
    "notificationDetails": {
        "accountId": "123401681234",
        "accountType": "BSSEWIRELESS",
        "langPreference": "EN",
        "customerType": "R",
        "clientId": "IDPWAM",
        "communicationMode": "BOTH",
        "deliveryMethods": {
            "emailAddress": "test@att.com",
            "smsPhoneNumber": "1234567890"
        },
        "OTPExpires": "2024-09-09 03:47:22Z",
        "attributeList ": [
            {
                "attributeName": "firstName",
                "attributeValue": "Tester"
            }
        ]
    }
}
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "GenericOTPNotification")
public class GenericOTPNotification{
	
	  private String notificationID;
	  private String notificationType;
	  private String notificationCategory;
	  private String notificationsubCategory;
	  private String notificationTime;
	  private NotificationDetails notificationDetails;
	    
	    /**
	     * This static inner class, NotificationDetails, represents a Notification in the NotificationDetails.
	     *
	     * It is annotated with several Jackson annotations to control how it is serialized and deserialized:
	     * - @JsonIgnoreProperties(ignoreUnknown = true) means that any unknown properties encountered during deserialization will be ignored.
	     * - @JsonInclude(JsonInclude.Include.NON_NULL) means that null values will not be included in the serialized JSON.
	     *
	     * The class contains several instance variables, each representing a different piece of information about the customer.
	     * These variables include mode, subCategory, langPreference, eventSentTime, serviceType, customerType, ban, ctn, emailAddress, and complexVal.
	     * - mode is a string that represents the mode of the customer.
	     * - subCategory is a string that represents the sub category of the customer.
	     * - langPreference is a string that represents the language preference of the customer.
	     * - eventSentTime is a string that represents the event sent time.
	     * - serviceType is a string that represents the service type.
	     * - customerType is a string that represents the customer type.
	     * - ban is a string that represents the ban of the customer.
	     * - ctn is a list of strings that represents the ctn of the customer.
	     * - emailAddress is a list of strings that represents the email address of the customer.
	     * - complexVal is a list of ComplexValue objects that represents the complex values of the customer.
	     *
	     * The class also contains getter and setter methods for each of the instance variables, allowing their values to be retrieved and modified.
	     */
	    @Data
	    @NoArgsConstructor
	    @AllArgsConstructor
	    @JsonIgnoreProperties(ignoreUnknown = true)
	    @JsonInclude(JsonInclude.Include.NON_NULL)
	    public static class NotificationDetails {
	    	private String accountId;
	    	private String accountType;
	    	private String langPreference;
	    	private String customerType;
	    	private String clientId;
	    	private String channel;
	    	
	    	@JsonProperty("OTP")
	    	private String OTP;
	    	
	    	@JsonProperty("OTPExpires")
	    	private String OTPExpires;
	    	
	    	private String communicationMode;
	    	private DeliveryMethods deliveryMethods;	    	
	    	private List<Attributes> attributeList;
	        
	    }
	    
	    /**
	     * This static inner class, ComplexValue, represents a complex value in the NationalRetailerOTPMessage.
	     *
	     * It is annotated with several Jackson annotations to control how it is serialized and deserialized:
	     * - @JsonIgnoreProperties(ignoreUnknown = true) means that any unknown properties encountered during deserialization will be ignored.
	     * - @JsonInclude(JsonInclude.Include.NON_NULL) means that null values will not be included in the serialized JSON.
	     *
	     * The class contains two instance variables: name and value.
	     * - name is a string that represents the name of the complex value.
	     * - value is a string that represents the value of the complex value.
	     *
	     * The class also contains getter and setter methods for each of the instance variables, allowing their values to be retrieved and modified.
	     */
	    @Data
	    @NoArgsConstructor
	    @AllArgsConstructor
	    @JsonIgnoreProperties(ignoreUnknown = true)
	    @JsonInclude(JsonInclude.Include.NON_NULL)
	    public static class DeliveryMethods {
	    	
	    	private String emailAddress;
	    	private String smsPhoneNumber;    	
	        
	    }
	    
	    /**
	     * This static inner class, ComplexValue, represents a complex value in the NationalRetailerOTPMessage.
	     *
	     * It is annotated with several Jackson annotations to control how it is serialized and deserialized:
	     * - @JsonIgnoreProperties(ignoreUnknown = true) means that any unknown properties encountered during deserialization will be ignored.
	     * - @JsonInclude(JsonInclude.Include.NON_NULL) means that null values will not be included in the serialized JSON.
	     *
	     * The class contains two instance variables: name and value.
	     * - name is a string that represents the name of the complex value.
	     * - value is a string that represents the value of the complex value.
	     *
	     * The class also contains getter and setter methods for each of the instance variables, allowing their values to be retrieved and modified.
	     */
	    @Data
	    @NoArgsConstructor
	    @AllArgsConstructor
	    @JsonIgnoreProperties(ignoreUnknown = true)
	    @JsonInclude(JsonInclude.Include.NON_NULL)
	    public static class Attributes {
	    	
	    	private String attributeName;
	    	private String attributeValue;    	
	        
	    }
	    

		
		
		 
	}




