package com.att.idp.idgraphcontactinfoms.db.repository;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.att.idp.idgraphcontactinfoms.db.model.Tsecuritycode;
import com.att.idp.idgraphcontactinfoms.db.model.TsecuritycodeId;


/**
 * This is the SecurityCodeRepository interface.
 *
 * It extends JpaRepository, which provides methods for CRUD operations on the Tsecuritycode entity.
 * The TsecuritycodeId is used as the ID type for the JpaRepository.
 *
 * It also extends SecurityCodeRepositoryCustom, which is used to declare custom repository methods for the Tsecuritycode entity.
 * These methods are not provided by the JpaRepository and need to be implemented manually.
 *
 * The interface is annotated with @Repository, which indicates that it is a Spring Data repository.
 */
@Repository 
public interface SecurityCodeRepository extends JpaRepository<Tsecuritycode, TsecuritycodeId>, SecurityCodeRepositoryCustom {

	/**
	 * This method is used to get security code data.
	 *
	 * It takes two parameters: identification_type and account_id. Both are of type String.
	 * The identification_type represents the type of identification used for the account.
	 * The account_id represents the ID of the account.
	 *
	 * The method performs a query on the Tsecuritycode table where the identificationType and accountId match the provided parameters.
	 * The result of the query is a list of Tsecuritycode objects that match the criteria.
	 *
	 * The @Param annotation is used to bind the method parameters to the query parameters.
	 *
	 * @param identification_type a String representing the type of identification used for the account.
	 * @param account_id a String representing the ID of the account.
	 * @return a List of Tsecuritycode objects that match the criteria.
	 * @throws SQLException if a database access error occurs or this method is called on a closed connection.
	 */
	@Query(value = "SELECT sc.*, sor.SOR_NAME, sor.SOR_DESC, sor.SOR_TYPE " +
			" FROM MPS_OWNER.TSECURITYCODE sc ,  MPS_OWNER.TSYSTEMOFRECORD sor "
			+ "WHERE sc.IDENTIFICATION_TYPE = :identification_type " + "AND sc.ACCOUNT_ID = :account_id "
			+ "AND sc.SECURITY_CODE_STATUS IN ('ACTIVE','FAILED') "
			+ "AND sc.SECURITY_CODE_EXPIRES > SYSDATE and sc.SOR_ID=sor.SOR_ID(+) ", nativeQuery = true)
	public List<Tsecuritycode> getSecurityCodeDataQuery(@Param(value = "identification_type") String identification_type,
			@Param(value = "account_id") String account_id) throws SQLException;

	/**
	 * This method is used to get the current date from the database.
	 *
	 * It performs a query on the database to retrieve the current date. The query is "SELECT SYSDATE FROM DUAL", which is a standard SQL query to get the current date from an Oracle database.
	 *
	 * The method returns a Date object representing the current date.
	 *
	 * @return a Date object representing the current date from the database.
	 * @throws SQLException if a database access error occurs or this method is called on a closed connection.
	 */
	@Query(value = "SELECT SYSDATE FROM DUAL", nativeQuery=true)
	public Date getDbCurrentDate();
	
	/**
	 * This method is used to get the current dbtimezone from the database.
	 *
	 * It performs a query on the database to retrieve the current date. The query is "SELECT DBTIMEZONE FROM DUAL", which is a standard SQL query to get the current date from an Oracle database.
	 *
	 * The method returns a Date object representing the current date.
	 *
	 * @return a Date object representing the current date from the database.
	 * @throws SQLException if a database access error occurs or this method is called on a closed connection.
	 */
	@Query(value = "SELECT TO_CHAR(DBTIMEZONE) FROM DUAL", nativeQuery=true)
	public String getDbTimeZone();
	
	/**
	 * This method is used to delete a record from the Tsecuritycode table.
	 *
	 * It takes two parameters: identificationType and accountId. Both are of type String.
	 * The identificationType represents the type of identification used for the account.
	 * The accountId represents the ID of the account.
	 *
	 * The method performs a delete operation on the Tsecuritycode table where the identificationType and accountId match the provided parameters.
	 * The result of the operation is the number of rows affected by the delete operation.
	 *
	 * @param identificationType a String representing the type of identification used for the account.
	 * @param accountId a String representing the ID of the account.
	 * @return an integer representing the number of rows affected by the delete operation.
	 */
	@Modifying
	int deleteByIdIdentificationTypeAndIdAccountId(String identificationType, String accountId);
	
	/**
	 * This method is used to update the status of a security code in the Tsecuritycode table.
	 *
	 * It takes four parameters: securityCodeStatus, identificationType, accountId, and securityCode. All are of type String.
	 * The securityCodeStatus represents the new status to be set for the security code.
	 * The identificationType represents the type of identification used for the account.
	 * The accountId represents the ID of the account.
	 * The securityCode represents the security code that needs to be updated.
	 *
	 * The method performs an update operation on the Tsecuritycode table where the identificationType, accountId, and securityCode match the provided parameters.
	 * The result of the operation is the number of rows affected by the update operation.
	 *
	 * The @Param annotation is used to bind the method parameters to the query parameters.
	 *
	 * @param securityCodeStatus a String representing the new status to be set for the security code.
	 * @param identificationType a String representing the type of identification used for the account.
	 * @param accountId a String representing the ID of the account.
	 * @param securityCode a String representing the security code that needs to be updated.
	 * @return an integer representing the number of rows affected by the update operation.
	 */
	@Modifying
	@Query(value = "UPDATE Tsecuritycode SET securityCodeStatus = :securityCodeStatus, statusChangeDate = CAST(SYSDATE AS java.sql.Date) WHERE id.identificationType = :identificationType AND id.accountId = :accountId AND id.securityCode= :securityCode")
	int updateBySecurityCodeId(@Param(value = "securityCodeStatus")String securityCodeStatus, @Param(value = "identificationType")String identificationType,
			@Param(value = "accountId")String accountId, @Param(value = "securityCode")String securityCode);
	
	
	/**
	 * This method is used to increment the verification failure count for a security code in the Tsecuritycode table.
	 *
	 * It takes four parameters: last_modified_by, identification_type, account_id, and verification_failure_count. 
	 * The last_modified_by is a String representing the last user who modified the record.
	 * The identification_type is a String representing the type of identification used for the account.
	 * The account_id is a String representing the ID of the account.
	 * The verification_failure_count is an integer representing the maximum number of allowed verification failures.
	 *
	 * The method performs an update operation on the Tsecuritycode table where the identificationType, accountId match the provided parameters and the current verification failure count is less than the provided verification_failure_count.
	 * The verification failure count for the matching record is incremented by 1.
	 *
	 * The @Param annotation is used to bind the method parameters to the query parameters.
	 *
	 * @param last_modified_by a String representing the last user who modified the record.
	 * @param identification_type a String representing the type of identification used for the account.
	 * @param account_id a String representing the ID of the account.
	 * @param verification_failure_count an integer representing the maximum number of allowed verification failures.
	 * @return an integer representing the number of rows affected by the update operation.
	 * @throws SQLException if a database access error occurs or this method is called on a closed connection.
	 */
	
	@Modifying
	@Query(value = "UPDATE MPS_OWNER.TSECURITYCODE sc SET sc.VERIFICATION_FAILURE_COUNT = sc.VERIFICATION_FAILURE_COUNT + 1 , "
			   + "sc.LAST_MODIFIED_BY=:last_modified_by, sc.SECURITY_CODE_STATUS=:security_code_status WHERE sc.IDENTIFICATION_TYPE = :identification_type "
			   + "AND sc.SECURITY_CODE_STATUS IN ('ACTIVE','FAILED') "
			   + "AND sc.ACCOUNT_ID = :account_id AND sc.VERIFICATION_FAILURE_COUNT < :verification_failure_count ", nativeQuery = true)
	public int updateSecurityCdByIncVeriffailCntSql(@Param(value = "last_modified_by") String last_modified_by,
													@Param(value = "identification_type") String identification_type,
													@Param(value = "account_id") String account_id,
													@Param(value = "verification_failure_count") int verification_failure_count, 
													@Param(value = "security_code_status") String security_code_status) throws SQLException;
	
	/**
	 * This method is used to reset the verification failure count for a security code in the Tsecuritycode table.
	 *
	 * It takes three parameters: identification_type, last_modified_by, and account_id.
	 * The identification_type is a String representing the type of identification used for the account.
	 * The last_modified_by is a String representing the last user who modified the record.
	 * The account_id is a String representing the ID of the account.
	 *
	 * The method performs an update operation on the Tsecuritycode table where the identificationType and accountId match the provided parameters.
	 * The verification failure count for the matching record is reset to 0.
	 *
	 * The @Param annotation is used to bind the method parameters to the query parameters.
	 *
	 * @param identification_type a String representing the type of identification used for the account.
	 * @param last_modified_by a String representing the last user who modified the record.
	 * @param account_id a String representing the ID of the account.
	 * @return an integer representing the number of rows affected by the update operation.
	 * @throws SQLException if a database access error occurs or this method is called on a closed connection.
	 */
	@Modifying
	@Query(value = "UPDATE MPS_OWNER.TSECURITYCODE sc SET sc.VERIFICATION_FAILURE_COUNT = 0 , "
			   + "sc.LAST_MODIFIED_BY= :last_modified_by WHERE sc.IDENTIFICATION_TYPE = :identification_type "
			   + "AND sc.ACCOUNT_ID = :account_id AND sc.SECURITY_CODE_STATUS IN ('FAILED')", nativeQuery = true)
	public int updateSecurityCdUnlockSql(@Param(value = "identification_type") String identification_type,
																   @Param(value = "last_modified_by") String last_modified_by, 
																   @Param(value = "account_id") String account_id) throws SQLException;
}