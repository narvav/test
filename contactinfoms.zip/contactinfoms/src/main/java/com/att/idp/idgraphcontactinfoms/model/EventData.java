package com.att.idp.idgraphcontactinfoms.model;

import com.att.idp.idgraph.events.model.JsonSealizable;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class EventData implements JsonSealizable {
    private String accountId;
    private String identificationType;
    @JsonProperty("securityAccount")
    private SecurityAccountEvent securityAccountEvent;
    @JsonProperty("securityCode")
    private SecurityCodeEvent securityCodeEvent;
}
