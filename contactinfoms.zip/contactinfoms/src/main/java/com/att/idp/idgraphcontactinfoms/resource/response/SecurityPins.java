package com.att.idp.idgraphcontactinfoms.resource.response;

import static org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString;
import static org.apache.commons.lang3.builder.ToStringStyle.JSON_STYLE;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "SecurityPins")
@Data
public class SecurityPins {

	private String accountId;
	private String identificationType;
	private String status;
	private String createTime;
	private String expirationTime;
	private String verificationFailureCount;
	private String requestedBy;
	private String deliveryMethod;
	private String deliveryDetail;

	@Override
	public String toString() {
		return reflectionToString(this, JSON_STYLE);
	}
}