package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "TDYNSERVICESOR", schema = "MPS_OWNER", uniqueConstraints = @UniqueConstraint(columnNames = {
		"SERVICE_ID", "SOR_ID" }))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tdynservicesor implements java.io.Serializable {

	private static final long serialVersionUID = 7619114769097499200L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "serviceId", column = @Column(name = "SERVICE_ID", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "sorId", column = @Column(name = "SOR_ID", nullable = false, precision = 22, scale = 0)) })
	private TdynservicesorId id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SOR_ID", nullable = false, insertable = false, updatable = false)
	private Tsystemofrecord tsystemofrecord;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SERVICE_ID", nullable = false, insertable = false, updatable = false)
	private Tservice tservice;
}