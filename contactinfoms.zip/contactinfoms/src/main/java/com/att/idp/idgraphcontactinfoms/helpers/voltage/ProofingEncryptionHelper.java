package com.att.idp.idgraphcontactinfoms.helpers.voltage;

import java.security.MessageDigest;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.stereotype.Component;

import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This is the ProofingEncryptionHelper class.
 * It is a utility class that provides methods to encrypt and decrypt values using the AES256 and SHA1 encryption methods.
 * It contains methods to interact with the Voltage API and handle any exceptions that may occur during the encryption and decryption process.
 * It is annotated as a Spring Component, indicating that an instance of this class will be created and managed by the Spring framework.
 *
 * @author pg076f
 * 
 * NOTE: THIS CLASS REFERS TO FIELDS DEFINED IN ril.properties AND
 * PROBABLY EVEN dslreg.properties, IN CASE NEW ENTRIES ARE ADDED THE
 * SHOULD BE ADDED TO ALL THE REFERED properties FILES.
 *
 * 8/24/2007, vd7314, converted oneway and 2 way encryption fields to   
 */
@Component
@Configuration
@PropertySources({
    @PropertySource("file:opt/ajsc/etc/config/contactInfo.properties"),
	@PropertySource(value = "${contactinfo.credentials.path}")
})
public class ProofingEncryptionHelper {

	private static final String sInfo = "$Id: master/com/att/mpsys/common/helpers/ProofingEncryption_H.java v1 2019-07-12 sp7569 $";
	public static final Logger logger = LoggerFactory.getLogger(ProofingEncryptionHelper.class);

	@Value("${SPI_ENCRYPTION_TYPE}")
	private String propSpiEncyptionType;

	@Value("${voltageEncryptFields}")
	private String propVoltageEncryptFields;
	
	@Value("${RemoveFieldsWhenSPIEncryptionTypeA}")
	private String propRemoveFieldsWhenSPIEncryptionTypeA;
	
	@Value("${oneWayEncryptFields}")
	private String propOneWayEncrypt;

	@Value("${twoWayEncryptFields}")
	private String propTwoWayEncrypt;
	
	@Value("${twoWayEncryptServices}")
	private String propTwoWayServicesEncrypt;
	
	@Value("${PopulateVoltageFields}")
	private String propPopulateVoltageFields;
	
	@Value("${AES256KEY}")
	private String aes256key;
	
	@Value("${MOSUBAttrDecryption}")
	private String propMosubAttrDecryption;
	
	@Value("${ISSAttrDecryption}")
	private String propIssAttrDecryption;
	
	
	@Autowired
	private VoltageEncryptionHelper voltageHelper;

	/**
	 * This method is part of the ProofingEncryptionHelper class.
	 * It takes a HashMap containing input values as input, and returns a HashMap containing the encrypted values.
	 * The method interacts with the Voltage API and the AES256 and SHA1 encryption methods to encrypt specific fields in the input HashMap, and handles any exceptions that may occur during the encryption process.
	 * It logs any errors that occur during the encryption process.
	 * The method returns a HashMap which contains the encrypted values, or an error map if an exception occurs.
	 *
	 * @param hmInput A HashMap containing input values to be encrypted.
	 * @return A HashMap containing the encrypted values, or an error map if an exception occurs.
	 */
	public HashMap getEncryptedValues(HashMap hmInput) {
		ArrayList oneWayEncryptFieldsArray = null;
		ArrayList twoWayEncryptFieldsArray = null;
		String sAppInfo = null;
		String sMethodName = "getEncryptedValues";
		Date tmsStartDate = new Date();

		try {

			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss");
			String tStartDate = dateFormat.format(tmsStartDate);
			logger.info("CH1 : " + "CVS Info = " + sInfo);
			logger.info("CH1.1 : " + "Start time in Helper = " + tStartDate);

			logger.info(SpiMarker.getInstance(), "ProofingEncryptionHelper.getEncryptedValues.HLP000 : inputHash={}",
					StructuredArguments.entries(hmInput));

			if (hmInput == null || hmInput.isEmpty()) {
				sAppInfo = " hmInput is NULL ";
				logger.debug("CH1 : " + sAppInfo);
				return null;
			}
			oneWayEncryptFieldsArray = init(logger, CommonDefs.ONEWAY_ENCRYPT_FIELDS);
			twoWayEncryptFieldsArray = init(logger, CommonDefs.TWOWAY_ENCRYPT_FIELDS);

			logger.info("CH2 : " + "SPI_ENCRYPTION_TYPE config value = " + propSpiEncyptionType);

			if (propSpiEncyptionType.equalsIgnoreCase("AV") || propSpiEncyptionType.equalsIgnoreCase("V")) {

				if (propVoltageEncryptFields != null && propVoltageEncryptFields.trim().length() > 0) {

					HashMap hmResult = voltageHelper.getEFPEEncryptedValues(hmInput);

					if (hmResult == null || hmResult.isEmpty()) {
						logger.error("CH3 : " + "VoltageEncryption_H.getEFPEDecryptedValues return null / empty");
						hmInput = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM,
								"VoltageEncryption_H.getEFPEDecryptedValues return null / empty");
						return hmInput;
					}

					String sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
					if (sAppStatusCode != null && !sAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
						sAppInfo = "VoltageEncryption_H.getEFPEDecryptedValues call failed.";
						logger.info("CH4 : " + sAppInfo);
						hmInput = hmResult;
						return hmInput;
					} else {

						// START-Remove Original fields when Encryption Type =V
						if (propSpiEncyptionType.equalsIgnoreCase("V")) {

							ArrayList alVoltageFields = CommonUtil.parseToArray(propVoltageEncryptFields, '|');

							for (int i = 0; i < alVoltageFields.size(); i++) {
								String stVoltageField = (String) alVoltageFields.get(i);
								if (hmInput.containsKey(stVoltageField)) {

									hmInput.remove(stVoltageField);
								}

							}
						}
						// END-Remove Original fields when Encryption Type =V

						if (hmInput != null && hmInput.containsKey("voltage_" + MPSDefs.DB_DSL_NET_PASSWORD)) {
							hmInput.put(MPSDefs.DB_DSL_NET_PASSWORD,
									hmInput.get("voltage_" + MPSDefs.DB_DSL_NET_PASSWORD));
							hmInput.put(MPSDefs.DB_DSL_NET_ENCR_TYPE, "V");
							hmInput.remove("voltage_" + MPSDefs.DB_DSL_NET_PASSWORD);
						}

					}

				} // end stVoltageEncryptFields null/empty check
			} // end stSpiEncyptionType = AV|V check

			if (oneWayEncryptFieldsArray == null || oneWayEncryptFieldsArray.isEmpty()) {
				sAppInfo = " oneWayEncryptFieldsArray is NULL ";
				logger.error("CH2 : " + sAppInfo);
			} else {
				for (int i = 0; i < oneWayEncryptFieldsArray.size(); i++) {
					String oneWayEncryptField = (String) oneWayEncryptFieldsArray.get(i);
					if (hmInput.containsKey(oneWayEncryptField)) {
						String strValue = (String) hmInput.get(oneWayEncryptField);
						strValue = processEncryption(strValue);
						String generatedOneWaySHA = generateSHA1Value(strValue);

						if (generatedOneWaySHA == null || generatedOneWaySHA.trim().length() < 1) {
							logger.error("CH5 : " + "generateSHA1Value failed for field=" + oneWayEncryptField);
							hmInput = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM,
									"generateSHA1Value failed for field=" + oneWayEncryptField);
							return hmInput;
						}

						hmInput.put(oneWayEncryptField, generatedOneWaySHA);
					}
				}
			} // one way

			if (twoWayEncryptFieldsArray == null || twoWayEncryptFieldsArray.isEmpty()) {
				sAppInfo = " twoWayEncryptFieldsArray is NULL ";
				logger.error("CH6 : " + sAppInfo);
			} else {
				for (int i = 0; i < twoWayEncryptFieldsArray.size(); i++) {
					String twoWayEncryptField = (String) twoWayEncryptFieldsArray.get(i);
					if (hmInput.containsKey(twoWayEncryptField)) {

						String strValue = (String) hmInput.get(twoWayEncryptField);
						String generatedTwoWayAES = generateAES256Value(strValue);

						if (generatedTwoWayAES == null || generatedTwoWayAES.trim().length() < 1) {
							logger.error("CH7 : " + "generateAES256Value failed for field=" + twoWayEncryptField);
							hmInput = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM,
									"generateAES256Value failed for field=" + twoWayEncryptField);
							return hmInput;
						}

						hmInput.put(twoWayEncryptField, generatedTwoWayAES);

						if (twoWayEncryptField != null && twoWayEncryptField.equals(MPSDefs.DB_DSL_NET_PASSWORD)) {
							hmInput.put(MPSDefs.DB_DSL_NET_ENCR_TYPE, "A");
						}

					}
				}
			} // two way

			// Remove the *_VENC Elements when SPI_ENCRYPTION_TYPE=A -Start
			if (propSpiEncyptionType == null || propSpiEncyptionType.trim().length() < 1
					|| propSpiEncyptionType.equalsIgnoreCase("A")) {

				ArrayList alVoltageFields = CommonUtil.parseToArray(propRemoveFieldsWhenSPIEncryptionTypeA, '|');

				logger.info("CH06.1 : " + "RemoveFieldsWhenSPIEncryptionTypeA=" + propRemoveFieldsWhenSPIEncryptionTypeA);

				if (alVoltageFields != null && !alVoltageFields.isEmpty()) {
					for (int k = 0; k < alVoltageFields.size(); k++) {
						hmInput.remove(alVoltageFields.get(k));
					}
				}

			}
			// Remove the *_VENC Elements when SPI_ENCRYPTION_TYPE=A -END

		} catch (Exception e) {

			hmInput = CommonErrorMap.makeExceptionMap(e, logger);

		} finally {
			if (hmInput == null || hmInput.isEmpty()) {
				logger.error("CH10 : " + "getEncryptedValues return null / empty");
				hmInput = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM,
						"getEncryptedValues return null / empty");
			}

			String sAppStatusCode = (String) hmInput.get(CommonDefs.COMMON_APP_STATUS_CODE);
			if (sAppStatusCode == null || sAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				// Add Success appCategory,appStatusCode in the return HashMap
				HashMap hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "");
				hmInput.putAll(hmResult);

			}
			logger.info(SpiMarker.getInstance(),
					"ProofingEncryptionHelper.getEncryptedValues.HLP999 : " + tmsStartDate.getTime() + "hmInput:",
					StructuredArguments.entries(hmInput));
		}
		return hmInput;
	}

	/**
	 * This method is part of the ProofingEncryptionHelper class.
	 * It takes a HashMap containing encrypted values as input, and returns a HashMap containing the decrypted values.
	 * The method interacts with the AES256 and SHA1 decryption methods to decrypt specific fields in the input HashMap, and handles any exceptions that may occur during the decryption process.
	 * It logs any errors that occur during the decryption process.
	 * The method returns a HashMap which contains the decrypted values, or an error map if an exception occurs.
	 *
	 * @param hmInput A HashMap containing encrypted values to be decrypted.
	 * @return A HashMap containing the decrypted values, or an error map if an exception occurs.
	 */
	public HashMap getDecryptedValues(HashMap hmInput) {
		ArrayList encryptFieldsArray = null;
		ArrayList encryptServiceArray = null;
		String sMethodName = "getDecryptedValues";
		String sAppInfo = null;
		String stDslEncType = null;
		Date tmsStartDate = new Date();

		try {

			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss");
			String tStartDate = dateFormat.format(tmsStartDate);
			logger.info("CH1 : " + "CVS Info = " + sInfo);
			logger.info("CH1.1 : " + "Start time in Helper = " + tStartDate);

			logger.info("HLP000 : " + "inputHash=" + hmInput);

			if (hmInput == null || hmInput.isEmpty()) {
				sAppInfo = " hmInput is NULL ";
				/*
				 * oMinf.log(Mpslog.debug, CErrorDefs.ERR_SYS_APPL_NUM, sClassName, sMethodName,
				 * "CH5", sAppInfo); return null;
				 */
				logger.error("CH1 : " + sAppInfo);

				hmInput = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, sAppInfo);
				return hmInput;
			}
			encryptFieldsArray = init(logger, CommonDefs.TWOWAY_ENCRYPT_FIELDS);
			if (encryptFieldsArray == null || encryptFieldsArray.isEmpty()) {
				sAppInfo = " encryptFieldsArray is NULL ";
				logger.error("CH2 : " + sAppInfo);
				hmInput = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				return hmInput;
			}

			String stDSLNetPassEncrType = (String) hmInput.get(MPSDefs.DB_DSL_NET_ENCR_TYPE);

			logger.info("CH3 : " + "SPI_ENCRYPTION_TYPE config value = " + propSpiEncyptionType);

			if (propSpiEncyptionType.equalsIgnoreCase("V")) {

				String stDecryptedDSLPass = null;
				if (stDSLNetPassEncrType != null && stDSLNetPassEncrType.equals("A")
						&& hmInput.containsKey(MPSDefs.DB_DSL_NET_PASSWORD)) {

					stDecryptedDSLPass = getClearTextFromAES((String) hmInput.get(MPSDefs.DB_DSL_NET_PASSWORD));

					if (stDecryptedDSLPass == null || stDecryptedDSLPass.trim().length() < 1) {
						logger.error("CH7.1 : " + "generatedClearText failed for field=" + MPSDefs.DB_DSL_NET_PASSWORD);
						hmInput = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM,
								"generatedClearText failed for field=" + MPSDefs.DB_DSL_NET_PASSWORD);
						return hmInput;
					}

					hmInput.remove(MPSDefs.DB_DSL_NET_PASSWORD);

				} else if (stDSLNetPassEncrType != null && !stDSLNetPassEncrType.equals("A")
						&& !stDSLNetPassEncrType.equals("V") && hmInput.containsKey(MPSDefs.DB_DSL_NET_PASSWORD)) {

					logger.info("CH7.1.1 : " + "Skip decryption for " + MPSDefs.DB_DSL_NET_PASSWORD + " As "
							+ MPSDefs.DB_DSL_NET_ENCR_TYPE + " = " + stDSLNetPassEncrType);
					stDecryptedDSLPass = (String) hmInput.get(MPSDefs.DB_DSL_NET_PASSWORD);
					hmInput.remove(MPSDefs.DB_DSL_NET_PASSWORD);
				}

				if (propVoltageEncryptFields != null && propVoltageEncryptFields.trim().length() > 0) {

					HashMap hmResult = voltageHelper.getEFPEDecryptedValues(hmInput);

					if (hmResult == null || hmResult.isEmpty()) {
						logger.error("CH4 : " + "VoltageEncryption_H.getEFPEDecryptedValues return null / empty");
						hmInput = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM,
								"VoltageEncryption_H.getEFPEDecryptedValues return null / empty");
						return hmInput;
					}

					String sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
					if (sAppStatusCode != null && !sAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
						sAppInfo = "VoltageEncryption_H.getEFPEDecryptedValues call failed.";
						logger.info("CH5 : " + sAppInfo);
						hmInput = hmResult;
						return hmInput;
					}
				}

				if (stDecryptedDSLPass != null) {
					hmInput.put(MPSDefs.DB_DSL_NET_PASSWORD, stDecryptedDSLPass);
				}

			}

			HashMap hmPopulateVoltageFields = null;

			if (propSpiEncyptionType != null && propSpiEncyptionType.equalsIgnoreCase("AV")) {

				HashMap hmResponse = prepareConfigHash("PopulateVoltageFields", '|', ':');

				String stAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
				if (stAppStatusCode == null || !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					sAppInfo = "prepareConfigHash call failed.";
					logger.info("CH6 : " + sAppInfo);
					hmInput = hmResponse;
					return hmInput;
				}

				hmPopulateVoltageFields = (HashMap) hmResponse.get("consolidatedHash");

				logger.info("CH7 : " + "PopulateVoltageFields: " + hmPopulateVoltageFields);

			}

			for (int i = 0; i < encryptFieldsArray.size(); i++) {
				String twoWayEncryptField = (String) encryptFieldsArray.get(i);
				if (hmInput.containsKey(twoWayEncryptField) && (String) hmInput.get(twoWayEncryptField) != null) {

					if (twoWayEncryptField.equals(MPSDefs.DB_DSL_NET_PASSWORD) && !stDSLNetPassEncrType.equals("A")) {
						logger.info("CH7.1.1 : " + "Skip decryption for = " + twoWayEncryptField + " As "
								+ MPSDefs.DB_DSL_NET_ENCR_TYPE + " = " + stDSLNetPassEncrType);
						continue;
					}

					String generatedClearText = getClearTextFromAES((String) hmInput.get(twoWayEncryptField));

					if (generatedClearText == null || generatedClearText.trim().length() < 1) {
						logger.error("CH7.1 : " + "generatedClearText failed for field=" + twoWayEncryptField);
						hmInput = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM,
								"generatedClearText failed for field=" + twoWayEncryptField);
						return hmInput;
					}

					hmInput.put(twoWayEncryptField, generatedClearText);

					if (hmPopulateVoltageFields != null && hmPopulateVoltageFields.containsKey(twoWayEncryptField)) {

						hmInput.put(hmPopulateVoltageFields.get(twoWayEncryptField), generatedClearText);
					}

				}
			}
			// Retrieve Services from hmInput for doing service level attributes
			// decryption
			HashMap hmServices = new HashMap();
			hmServices = (HashMap) hmInput.get(MPSDefs.SERVICES);
			if (hmServices != null && !hmServices.isEmpty()) {
				// twoWayEncryptServices=MOSUB
				encryptServiceArray = initServices(CommonDefs.PROP_TWOWAY_ENCRYPT_SERVICES);
				if (encryptServiceArray == null || encryptServiceArray.isEmpty()) {
					sAppInfo = " encryptServiceArray is NULL ";
					logger.error("CH8 : " + sAppInfo);
					hmInput = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
					return hmInput;
				}
				for (int i = 0; i < encryptServiceArray.size(); i++) {
					String sEachService = (String) encryptServiceArray.get(i);
					// Retrieve each service attrdecryption like
					// MOSUBAttrDecryption=sorInvariantId
					String sEachServiceEncryptFields = "MOSUB".equalsIgnoreCase(sEachService)? propMosubAttrDecryption
							:"ISS".equalsIgnoreCase(sEachService)? propIssAttrDecryption:"";
					if(sEachServiceEncryptFields == null || sEachServiceEncryptFields.isEmpty() ) {
						sAppInfo = "The value of AttrDecryption is not configured in property files";
						logger.error("CH8.1 : {}", sAppInfo);
						hmInput = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, sAppInfo);
						return hmInput;
					}
					ArrayList alEachServiceEncryptFields = CommonUtil.parseToArray(sEachServiceEncryptFields, '|');
					sAppInfo = sEachService+"AttrDecryption property values = " + alEachServiceEncryptFields;
					logger.info("CH8.2 : " + sAppInfo);
					if (hmServices.containsKey(sEachService)) {
						HashMap hmEachService = (HashMap) hmServices.get(sEachService);
						if (hmEachService != null && !hmEachService.isEmpty()) {
							if (CommonUtil.getInstanceServices(logger).contains(sEachService)) { // 1610 - Updated for
																									// PID 287102 to
																									// treat dynamic
																									// services too as
																									// instance services
								Iterator itrInnerServic = hmEachService.keySet().iterator();
								while (itrInnerServic.hasNext()) {
									String sServiceInstancId = (String) itrInnerServic.next();
									Object eachInnerValue = (Object) hmEachService.get(sServiceInstancId);
									if (eachInnerValue instanceof HashMap) {
										HashMap hmInnerServices = (HashMap) hmEachService.get(sServiceInstancId);
										for (int j = 0; j < alEachServiceEncryptFields.size(); j++) {
											String sServiceEncryptField = (String) alEachServiceEncryptFields.get(j);
											if (hmInnerServices.containsKey(sServiceEncryptField)
													&& (String) hmInnerServices.get(sServiceEncryptField) != null) {
												String generatedClearText = getClearTextFromAES(
														(String) hmInnerServices.get(sServiceEncryptField));

												if (generatedClearText == null
														|| generatedClearText.trim().length() < 1) {
													logger.error("CH7.2 : " + "generatedClearText failed for field="
															+ sServiceEncryptField);
													hmInput = CommonErrorMap.makeCategoryMap(
															CErrorDefs.ERR_SYS_APPL_NUM,
															"generatedClearText failed for field="
																	+ sServiceEncryptField);
													return hmInput;
												}

												hmInnerServices.put(sServiceEncryptField, generatedClearText);

												if (hmPopulateVoltageFields != null
														&& hmPopulateVoltageFields.containsKey(sServiceEncryptField)) {

													hmInput.put(hmPopulateVoltageFields.get(sServiceEncryptField),
															generatedClearText);
												}

											}
										}
									}
								}
							} // end of instanceid services decryption attributes
							else {
								for (int j = 0; j < alEachServiceEncryptFields.size(); j++) {
									String sServiceEncryptField = (String) alEachServiceEncryptFields.get(j);
									if (hmEachService.containsKey(sServiceEncryptField)
											&& (String) hmEachService.get(sServiceEncryptField) != null) {
										String generatedClearText = getClearTextFromAES(
												(String) hmEachService.get(sServiceEncryptField));

										if (generatedClearText == null || generatedClearText.trim().length() < 1) {
											logger.error("CH7.3 : " + "generatedClearText failed for field="
													+ sServiceEncryptField);
											hmInput = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM,
													"generatedClearText failed for field=" + sServiceEncryptField);
											return hmInput;
										}

										hmEachService.put(sServiceEncryptField, generatedClearText);

										if (hmPopulateVoltageFields != null
												&& hmPopulateVoltageFields.containsKey(sServiceEncryptField)) {

											hmInput.put(hmPopulateVoltageFields.get(sServiceEncryptField),
													generatedClearText);
										}
									}
								}
							} // end of non instanceid services decryption
						}
					}
				} // end of twowayservices decrypt.
			} // end of services check

			// }//end of stSpiEncyptionType if

			// Remove the *_VENC Elements when SPI_ENCRYPTION_TYPE=A -Start
			if (propSpiEncyptionType == null || propSpiEncyptionType.trim().length() < 1
					|| propSpiEncyptionType.equalsIgnoreCase("A")) {

				ArrayList alVoltageFields = CommonUtil.parseToArray(propRemoveFieldsWhenSPIEncryptionTypeA, '|');

				logger.info("CH06.1 : " + "RemoveFieldsWhenSPIEncryptionTypeA=" + propRemoveFieldsWhenSPIEncryptionTypeA);

				if (alVoltageFields != null && !alVoltageFields.isEmpty()) {
					for (int k = 0; k < alVoltageFields.size(); k++) {
						hmInput.remove(alVoltageFields.get(k));
					}
				}

			}
			// Remove the *_VENC Elements when SPI_ENCRYPTION_TYPE=A -END

		} catch (Exception e) {

			hmInput = CommonErrorMap.makeExceptionMap(e, logger);

		} finally {
			if (hmInput == null || hmInput.isEmpty()) {
				logger.error("CH10 : " + "getEncryptedValues return null / empty");
				hmInput = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM,
						"getEncryptedValues return null / empty");
			}

			String sAppStatusCode = (String) hmInput.get(CommonDefs.COMMON_APP_STATUS_CODE);
			if (sAppStatusCode == null || sAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				// Add Success appCategory,appStatusCode in the return HashMap
				HashMap hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "");
				hmInput.putAll(hmResult);

			}
			logger.info(SpiMarker.getInstance(),
					"ProofingEncryptionHelper.getDecryptedValues.HLP999 : " + tmsStartDate.getTime() + "hmInput:",
					StructuredArguments.entries(hmInput));

		}

		return hmInput;
	}

	private ArrayList init(Logger logger, String configEncriptFields) throws Exception {
		String sAppInfo = null;
		String sAppStatusCode = null;
		String sErrMsg;
		String sMethodName = "init";
		ArrayList encryptFieldsArray = null;

		try {

			if (configEncriptFields.equals(CommonDefs.ONEWAY_ENCRYPT_FIELDS)) {
				
				encryptFieldsArray = CommonUtil.parseToArray(propOneWayEncrypt, '|');
				sAppInfo = "oneWayEncryptFieldsArray = " + encryptFieldsArray;
				logger.info("CH8 : " + sAppInfo);
			}

			else {
				encryptFieldsArray = CommonUtil.parseToArray(propTwoWayEncrypt, '|');
				sAppInfo = "twoWayEncryptFieldsArray = " + encryptFieldsArray;
				logger.info("CH9 : " + sAppInfo);
			}
		} catch (Exception e) {
			logger.error("CH10 : " + "Exception = " + e.getMessage());
			throw e;
		}
		return encryptFieldsArray;
	}

	/**
	 * This method is part of the ProofingEncryptionHelper class.
	 * It takes a string representing clear text as input and returns a string representing the SHA1 hash of the input.
	 * The method uses the SHA1 hashing algorithm to generate a hash of the input string.
	 * It handles any exceptions that may occur during the hashing process.
	 * The method returns a string which contains the SHA1 hash of the input string.
	 *
	 * @param sCleartext A string representing clear text to be hashed.
	 * @return A string representing the SHA1 hash of the input string.
	 */
	public String generateSHA1Value(String sCleartext) {
		String sDigest = null;
		byte[] digestBytes = null;
		String sErrMsg;

		try {

			MessageDigest md = MessageDigest.getInstance(CommonDefs.ENCRYPT_SHA1);
			md.reset();
			md.update(sCleartext.getBytes());
			digestBytes = md.digest();
			sDigest = new String(jakarta.xml.bind.DatatypeConverter.printBase64Binary(digestBytes));
		} catch (Exception e) {
			sErrMsg = "CommonHelper.ProofingEncryption_H.generateSHA1Value.CH11:Exception::" + e.getMessage();
			logger.error("Exception : " + e.getMessage());
			logger.error("Exception :={} ", e);
			return sDigest;
		}
		return sDigest;
	}

	/**
	 * This method is part of the ProofingEncryptionHelper class.
	 * It takes a string representing clear text as input and returns a string representing the AES256 encrypted value of the input.
	 * The method uses the AES256 encryption algorithm to encrypt the input string.
	 * It handles any exceptions that may occur during the encryption process.
	 * The method returns a string which contains the AES256 encrypted value of the input string.
	 *
	 * @param cleartext A string representing clear text to be encrypted.
	 * @return A string representing the AES256 encrypted value of the input string.
	 */
	public String generateAES256Value(String cleartext) {
		String thisMethod = "generateAES256Value";
		String generatedAES = null;
		String sDigest = null;
		String sErrMsg;
		String appInfo = null;
		try {


			byte[] raw = hexToByteArray(aes256key);

			// Create SecretKeySpec
			SecretKeySpec skeySpec = new SecretKeySpec(raw, CommonDefs.ENCRYPT_AES);

			// Instantiate the AES Cipher in encrypt mode
			Cipher cipher = Cipher.getInstance(CommonDefs.ENCRYPT_AES);

			cipher.init(Cipher.ENCRYPT_MODE, skeySpec);

			// Encrypt Clear Text using AES256 Cipher
			byte[] encrypted = cipher.doFinal(cleartext.getBytes());

			sDigest = asHex(encrypted);

		} catch (Exception e) {
			sErrMsg = "CommonHelper.ProofingEncryption_H.generateAES256Value.CH12:Exception::" + e.getMessage();
			logger.error("Exception : " + e.getMessage());
			logger.error("Exception : ={}", e);
			return sDigest;
		}
		return sDigest;
	}

	/**
	 * This method is part of the ProofingEncryptionHelper class.
	 * It takes a string representing an AES256 encrypted password as input and returns a string representing the clear text of the password.
	 * The method uses the AES256 decryption algorithm to decrypt the input string.
	 * It handles any exceptions that may occur during the decryption process.
	 * The method returns a string which contains the clear text of the input password.
	 *
	 * @param aesPassword A string representing an AES256 encrypted password.
	 * @return A string representing the clear text of the input password.
	 */
	public String getClearTextFromAES(String aesPassword) {
		String sErrMsg;
		String AES256Key = null;
		String sClearText = null;
		String thisMethod = "getClearTextFromAES";
		try {
			
			byte[] raw = hexToByteArray(aes256key);

			// Create SecretKeySpec
			SecretKeySpec skeySpec = new SecretKeySpec(raw, CommonDefs.ENCRYPT_AES);

			// Get AES Cipher instance in decrypt mode
			Cipher cipher = Cipher.getInstance(CommonDefs.ENCRYPT_AES);
			cipher.init(Cipher.DECRYPT_MODE, skeySpec);

			// Retrieve original clear text password
			byte[] original = cipher.doFinal(hexToByteArray(aesPassword));
			sClearText = new String(original);
		} catch (Exception e) {
			sErrMsg = "CommonHelper.ProofingEncryption_H.getClearTextFromAES.CH13:Exception::" + e.getMessage();
			logger.error("Exception : " + e.getMessage());
			logger.error("Exception : ={}", e);
			return sClearText;
		}
		return sClearText;
	}

	private byte[] hexToByteArray(String sHex) {
		byte[] bts = new byte[sHex.length() / 2];
		for (int i = 0; i < bts.length; i++) {
			bts[i] = (byte) Integer.parseInt(sHex.substring(2 * i, 2 * i + 2), 16);
		}
		return bts;
	}

	private String asHex(byte buf[]) {
		StringBuffer strbuf = new StringBuffer(buf.length * 2);

		for (int i = 0; i < buf.length; i++) {
			if (((int) buf[i] & 0xff) < 0x10)
				strbuf.append("0");
			strbuf.append(Long.toString((int) buf[i] & 0xff, 16));
		}

		return strbuf.toString();
	}

	/**
	 * This method is part of the ProofingEncryptionHelper class.
	 * It takes a string representing a field value as input and returns a string with all spaces removed and converted to lower case.
	 * The method uses the Java String class's toLowerCase() and replaceAll() methods to process the input string.
	 * The method returns a string which contains the processed value of the input string.
	 *
	 * @param fieldValue A string representing a field value to be processed.
	 * @return A string representing the processed value of the input string.
	 */
	public final String processEncryption(String fieldValue) {
		if (fieldValue != null) {
			fieldValue = fieldValue.toLowerCase();
			fieldValue = replaceAll(fieldValue, " ", "");
		}
		return fieldValue;
	}

	/**
	 * Replace all occurances of replaceString in the originalString with
	 * replaceWithString Creation date: (8/24/2007 12:00:06 PM)
	 * 
	 * @return java.lang.String
	 * @param originalString    java.lang.String
	 * @param replaceString     java.lang.String
	 * @param replaceWithString java.lang.String
	 */
	public final String replaceAll(String originalString, String replaceString, String replaceWithString) {
		if (originalString == null)
			return null;
		if (replaceString == null)
			return originalString;
		int pos = originalString.indexOf(replaceString);
		int len = 0;
		if (pos != -1) {
			if (replaceString != null)
				len = replaceString.length();
			String firstString = originalString.substring(0, pos);
			String secondString = originalString.substring(pos + len);

			if (replaceWithString == null)
				return firstString + replaceAll(secondString, replaceString, replaceWithString);
			else
				return firstString + replaceWithString + replaceAll(secondString, replaceString, replaceWithString);
		} else
			return originalString;
	}

	private ArrayList initServices(String configEncriptFields) throws Exception {
		String sAppInfo = null;
		ArrayList encryptFieldsArray = null;

		try {

			encryptFieldsArray = CommonUtil.parseToArray(propTwoWayServicesEncrypt, '|');
			sAppInfo = "twoWayServicesEncryptArray = " + encryptFieldsArray;
			logger.info("CH39 : " + sAppInfo);
		} catch (Exception e) {
			logger.error("CH40 : " + "Exception = " + e.getMessage());
			throw e;
		}
		return encryptFieldsArray;
	}

	private HashMap prepareConfigHash(String stPropertiesName, char outerDelimeter, char innerDelimeter) {

		String stAppInfo = null;
		String stThisMethod = "prepareConfigHash";
		HashMap hmResult = null;

		ArrayList alOuter = null;
		try {

			if (propPopulateVoltageFields != null && propPopulateVoltageFields.trim().length() > 0) {

				alOuter = CommonUtil.parseToArray(propPopulateVoltageFields, outerDelimeter);
			}
			if (alOuter == null || alOuter.isEmpty()) {
				stAppInfo = stPropertiesName + " is either not configured or empty in the config file ";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
				logger.info("CMNT001 : " + stAppInfo);
				return hmResult;
			}

			HashMap hmTemp = new HashMap();
			java.util.Iterator itConfig = alOuter.iterator();
			while (itConfig.hasNext()) {
				String currentOuterConfig = (String) itConfig.next();

				String stSplitConfig[] = currentOuterConfig.split("" + innerDelimeter);

				if (stSplitConfig == null || stSplitConfig.length != 2)
				// Above 'size() == 1' is to ensure that an invalid value hasn't been set in
				// Config-file.
				{
					stAppInfo = "Config-value Parsing for [" + stPropertiesName + "] Failed for value: "
							+ currentOuterConfig;
					logger.error("CMNT002 : " + stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
					return hmResult;
				}

				hmTemp.put(stSplitConfig[0], stSplitConfig[1]);
			} // while loop end

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "");
			hmResult.put("consolidatedHash", hmTemp);
		} catch (Exception e) {
			stAppInfo = "CH12:Exception::" + e.getMessage();
			logger.error("Exception : " + e.getMessage());
			logger.error("Exception : ={}", e);
			return hmResult;
		}

		return hmResult;
	}

}