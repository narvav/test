package com.att.idp.idgraphcontactinfoms.helpers;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import com.att.idp.idgraphcontactinfoms.integration.LscrmGetAuthInfoClient;
import com.att.mpsys.common.utils.*;
import com.sbc.cc.clarify.api.mps.message.GetAuthInfoRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.helpers.SoapHttpClient;

/**
 * This class is a helper class for querying profile proofing information.
 *
 * It contains methods for querying profile proofing information based on the input parameters.
 * The class uses the Spring Framework's @Component annotation to indicate that it is a bean and can be used for dependency injection.
 *
 * The class has several instance variables that are injected using the @Autowired annotation.
 * These variables are used to interact with various other helper classes and services to process and query profile proofing information.
 *
 * The main method in this class is the queryCRMProofingInfo method, which takes a HashMap as input and returns a HashMap as output.
 * The queryCRMProofingInfo method uses several other methods in the class to validate the input data, process the input data, and store the data.
 *
 * The class also contains a logger for logging information and error messages.
 */
@Component
public class QueryProfileProofingInfoHelper {

	private static final String SCLASSNAME = "QueryProfileProofingInfoHelper";
	public static final Logger log = LoggerFactory.getLogger(QueryProfileProofingInfoHelper.class);

	@Autowired
	private SoapHttpClient oSoapHttpClient;

	@Autowired
	private LSCRMHelper oLSCRMHelper;

	@Autowired
	private LscrmGetAuthInfoClient<GetAuthInfoRequest> lscrmGetAuthInfoClient;



	private String sPropCallUpdateGetAuthInfoXML;

	private String sPropCRMLSGetAuthInfoURL;

	private String sPropCRMLSGetAuthInfoConnectTimeout;

	private String sPropCRMLSGetAuthInfoReadTimeout;

	private String sPropCRMLSGetAuthInfoMethodRequest;

	private String sPropCRMLSGetAuthInfom1NS;

	private String sPropCRMLSGetAuthInfom1NSPrefix;

	private String sPropCRMLSGetAuthInfom2NS;

	private String sPropCRMLSGetAuthInfom2NSPrefix;

	private String sPropCRMLSGetAuthInfom3NS;

	private String sPropCRMLSGetAuthInfom3NSPrefix;

	private String sPropCRMLSGetAuthInfom4NS;

	private String sPropCRMLSGetAuthInfom4NSPrefix;

	private String sPropCRMLSGetAuthInfoTypeNS;

	private String sPropCRMLSGetAuthInfoPasswordType;

	private String sPropCRMLSGetAuthInfoUserNameTokenType;

	private String sPropCRMLSGetAuthInfoSbcUID;

	private String sPropCRMLSGetAuthInfoLoginName;

	private String sPropCRMLSGetAuthInfoPassword;

	private String sPropCRMLSGetAuthInfoApplicationId;


	private String sPropLSCRMSecurityHeaderUser;


	private String sPropLSCRMSecurityHeaderPassword;


	private String sCfgIsParserNamespaceAware;

	private String sPropCRMLSGetAuthInfom0NS;

	private PropertyManagerLoader propertyManagerLoader;

	public QueryProfileProofingInfoHelper(PropertyManagerLoader propertyManagerLoader) {
		this.propertyManagerLoader = propertyManagerLoader;

		FileInputStream fIn = null;
		try {
			sPropCallUpdateGetAuthInfoXML = PropertyManager.getProperty(CommonDefs.MOUPConfig,
					CommonDefs.PROP_CRM_GetAUTHINFO_REQUEST_NEW);
			sPropCRMLSGetAuthInfoURL = PropertyManager.getProperty(CommonDefs.MOUPConfig,
					"CRMLSGetAuthInfoURL");
			sPropCRMLSGetAuthInfoConnectTimeout = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfoConnectTimeout");
			sPropCRMLSGetAuthInfoReadTimeout = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfoReadTimeout");
			sPropCRMLSGetAuthInfoMethodRequest = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfoMethodRequest");
			sPropCRMLSGetAuthInfom1NS = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfom1NS");
			sPropCRMLSGetAuthInfom1NSPrefix = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfom1NSPrefix");
			sPropCRMLSGetAuthInfom2NS = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfom2NS");
			sPropCRMLSGetAuthInfom2NSPrefix = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfom2NSPrefix");
			sPropCRMLSGetAuthInfom3NS = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfom3NS");
			sPropCRMLSGetAuthInfom3NSPrefix = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfom3NSPrefix");
			sPropCRMLSGetAuthInfom4NS = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfom4NS");
			sPropCRMLSGetAuthInfom4NSPrefix = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfom4NSPrefix");
			sPropCRMLSGetAuthInfoTypeNS = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfoTypeNS");
			sPropCRMLSGetAuthInfoPasswordType = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfoPasswordType");
			sPropCRMLSGetAuthInfoUserNameTokenType = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfoUserNameTokenType");
			sPropCRMLSGetAuthInfoSbcUID = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfoSbcUID");
			sPropCRMLSGetAuthInfoLoginName = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfoLoginName");
			sPropCRMLSGetAuthInfoPassword = PropertyManager.getProperty(CommonDefs.MOUPSECRETConfig, "CRMLSGetAuthInfoPassword");
			sPropCRMLSGetAuthInfoApplicationId = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfoApplicationId");
			sPropLSCRMSecurityHeaderUser = PropertyManager.getProperty(CommonDefs.MOUPConfig, "LSCRM_SecurityHeader_User");
			sPropLSCRMSecurityHeaderPassword = PropertyManager.getProperty(CommonDefs.MOUPSECRETConfig, "LSCRM_SecurityHeader_Password");
			sCfgIsParserNamespaceAware = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfoParserNSAware");
			sPropCRMLSGetAuthInfom0NS = PropertyManager.getProperty(CommonDefs.MOUPConfig, "CRMLSGetAuthInfom0NS");

		} catch (Exception e) {
			log.error("GC-E2b : " + "General Exception creating the Voltage library "+e);

		} finally {
			if (fIn != null) {
				try {
					fIn.close();
				} catch (IOException e) {
					log.error("GC-E2c : " + "IOException closing keys.properties "+e);
				}
			}
		}


	}

	/**
	 * This method is used to query CRM for proofing information.
	 *
	 * It takes a HashMap as input which contains various keys related to CRM proofing information.
	 * The method performs various checks and validations on the input data and constructs a response HashMap.
	 * The response HashMap contains the result of the CRM proofing information query.
	 *
	 * @param inputParams A HashMap containing the input data for CRM proofing information query.
	 * @return A HashMap containing the result of the CRM proofing information query.
	 */
	public HashMap<String, Object> queryCRMProofingInfo(HashMap<String, String> inputParams) {

		String sMethodName = ".queryCRMProofingInfo.";
		HashMap<String, Object> hmResponse = null;
		String sAppStatusCode = null;
		String sAppInfo = null;
		String soapReq = null;
		GetAuthInfoRequest getAuthInfoRequest =null;

		try {
			log.info("{}{}HLP000 : Input Hash : {}", SCLASSNAME, sMethodName, inputParams);

			String ban = inputParams.get(CommonDefs.BAN);
			String callingSystemId = inputParams.get(CommonDefs.CALLING_SYSTEM_ID);
			if ((ban == null) || (ban = ban.trim()).length() == 0) {
				sAppInfo = "ban is NULL";
				log.info("{}{}QCRM_H_01 : {}", SCLASSNAME, sMethodName, sAppInfo);
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, sAppInfo);
				return hmResponse;
			}

			if ((callingSystemId == null) || (callingSystemId = callingSystemId.trim()).length() == 0) {
				sAppInfo = "callingSystemId is NULL";
				log.info("{}{}QCRM_H_02 : {}", SCLASSNAME, sMethodName, sAppInfo);
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, sAppInfo);
				return hmResponse;
			}

			HashMap<String, Object> soapIn = getProperties();
			soapIn.put(CommonDefs.BAN, ban);
			soapIn.put(CommonDefs.CALLING_SYSTEM_ID, callingSystemId);
//update IDPClient call vp1820
			getAuthInfoRequest = oLSCRMHelper.buildGetAuthInfoRequest(soapIn);

			hmResponse = (HashMap<String, Object>)lscrmGetAuthInfoClient.invokeAPI(getAuthInfoRequest);

			log.info(SpiMarker.getInstance(),"{}{}QCRM_H_06 : Response from executeSoapHttps = {}", SCLASSNAME, sMethodName, hmResponse);
			String appCategoryCode = (String) hmResponse.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
			appCategoryCode = (appCategoryCode == null) ? CErrorDefs.CATEGORY_CODE_SYSTEM_ERROR
					: appCategoryCode.trim();

			if (!appCategoryCode.equals(CErrorDefs.COMMON_SUCCESS_CATEGORY_ID)) {

				sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
				sAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
				if ((sAppStatusCode.equals(CErrorDefs.ERR_SYS_APPL))
						&& (sAppInfo.equalsIgnoreCase("Error returned from HTTP call"))) {
					sAppInfo = "CLARIFY CRM GetAuthInfo - HTTP Call Failed";
					hmResponse.put(CommonDefs.COMMON_APP_INFO, sAppInfo);
				} else if ((sAppStatusCode.equals(CErrorDefs.ERR_SYS_APPL))
						&& (sAppInfo.equalsIgnoreCase("Connection refused"))) {
					sAppInfo = "CLARIFY CRM GetAuthInfo Call - Connection Refused";
					hmResponse.put(CommonDefs.COMMON_APP_INFO, sAppInfo);
				} else if (sAppStatusCode.equals(CErrorDefs.ERR_TRAN_TIME_OUT)) {
					sAppInfo = "CLARIFY CRM GetAuthInfo Call - " + sAppInfo;
					hmResponse.put(CommonDefs.COMMON_APP_INFO, sAppInfo);
				}
				log.info("{}{}QCRM_H_07 : {}", SCLASSNAME, sMethodName, sAppInfo);
				return hmResponse;
			}

			HashMap<String, Object> getAuthInfoSoapResp = (HashMap<String, Object>) hmResponse.get(CommonDefs.SOAP_RESPONSE);
			hmResponse = parseGetAuthInfoResponse(getAuthInfoSoapResp);

			log.debug(SpiMarker.getInstance(),"{}{}QCRM_H_08 : Response from parseGetAuthInfoResponse = {}", SCLASSNAME, sMethodName, hmResponse);

			appCategoryCode = (String) hmResponse.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
			appCategoryCode = (appCategoryCode == null) ? CErrorDefs.CATEGORY_CODE_SYSTEM_ERROR
					: appCategoryCode.trim();

			if (!appCategoryCode.equals(CErrorDefs.COMMON_SUCCESS_CATEGORY_ID)) {
				sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
				sAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
				log.info("{}{}QCRM_H_09 : {}", SCLASSNAME, sMethodName, sAppInfo);
				return hmResponse;
			}
		} catch (Exception e) {
			sAppInfo = "Caught Exception: " + e.toString();
			hmResponse = CommonErrorMap.makeExceptionMap(e);
			sAppStatusCode = (String) hmResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			log.error("{}{}QCRM_H_E01 : {}", SCLASSNAME, sMethodName, sAppInfo);
		} finally {
			log.info(SpiMarker.getInstance(),"{}{}HLP999 : STATUS : {}", SCLASSNAME, sMethodName, hmResponse);
		}
		return hmResponse;

	}

	public HashMap<String, Object> parseGetAuthInfoResponse(HashMap<String, Object> soapRes) {
		final String sMethodName = ".parseGetAuthInfoResponse.";
		final String CRM_BAN_NOT_FOUND_ERROR = "001";
		final String CRM_UNAUTH_LOGIN_ERROR = "002";
		final String CRM_SYS_ERROR = "003";
		final String CRM_ROLENAME_PRIMARY = "Primary";

		HashMap<String, Object> outHs = null;
		String sAppInfo = null;
		String crmErrorCode = null;
		String contactRole = null;


		log.info(SpiMarker.getInstance(),"{}{}PGIR1 : STATUS : {}", SCLASSNAME, sMethodName, soapRes);
		try {

			crmErrorCode = (String)soapRes.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			// Now, if an Error-code exists in SOAP-Fault, translate it to get appropriate
			// error-Response from CLARIFY.
			if (crmErrorCode != null && crmErrorCode.equals(CRM_BAN_NOT_FOUND_ERROR)) {
				sAppInfo = "BAN is NOT found in LS CRM";
				outHs = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_BAN_NOT_FOUND_IN_CRM_NUM, sAppInfo);
				log.info("{}{}PGIR1 : {}", SCLASSNAME, sMethodName, sAppInfo);
				return outHs;
			} else if (crmErrorCode != null && crmErrorCode.equals(CRM_UNAUTH_LOGIN_ERROR)) {
				sAppInfo = "Unauthorized Login to LS CRM";
				outHs = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_UNAUTH_LOGIN_CRM_NUM, sAppInfo);
				log.info("{}{}PGIR2 : {}", SCLASSNAME, sMethodName, sAppInfo);
				return outHs;
			} else if (crmErrorCode != null && crmErrorCode.equals(CRM_SYS_ERROR)) {
				sAppInfo = "Internal LS CRM Error";
				outHs = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_CRM_NUM, sAppInfo);
				log.info("{}{}PGIR3 : {}", SCLASSNAME, sMethodName, sAppInfo);
				return outHs;
			}



			// 2. Retrieve <contacts> and relevant info from xml
			// <contacts> could be 0 - many
			// <contacts> sub tags are
			// <contact> (ssn, dob)
			// <authinfo> (question, answer)
			// <contactRole> (roleName="Primary" is what we're interested in)
			// <serviceAddress> (zipCode)

			// 3. Retrieve <passCode> info
			// 4. Retrieve <VOIPTN> info
			// 4. Retrieve <memberId> info
			//5. Retrieve <CWBAN> info
			// 6. Retrieve <billingAddress> info
			// Return SUCCESS, Only If Details are found for PRIMARY Contact in CLARIFY
			// Response.
			// Else, return with ERR_INVALID_DATA.


			List<Map<String, Object>> contacts = soapRes.get("contacts") instanceof List
					? (List<Map<String, Object>>) soapRes.get("contacts") : null;

			Map<String, Object> primaryContact = getPrimaryContact(contacts);

			log.info(SpiMarker.getInstance(),"{}{}PGIR4 : STATUS : {}", SCLASSNAME, sMethodName, primaryContact);

			if (primaryContact == null) {
				sAppInfo = CRM_ROLENAME_PRIMARY + " Contact Details Unavailable in CLARIFY GetAuthInfo Response.";
				outHs = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
				log.info("{}{}PGIR5 : {}", SCLASSNAME, sMethodName, sAppInfo);
			}
			else
			{
				outHs = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, "SUCCESS");
				Map<String, Object> priContact = (Map<String, Object>) primaryContact.get("contact");
				Map<String, Object> priAuthInfo = (Map<String, Object>) primaryContact.get("authInfo");
				Map<String, Object> priServiceAddress = (Map<String, Object>) primaryContact.get("serviceAddress");
				Map<String, Object> priBillingAddress = (Map<String, Object>) soapRes.get("billingAddress");


				if(StringUtils.hasText((String) priContact.get("ssn")))
				{
					String ssn = (String) priContact.get("ssn");
					outHs.put(CommonDefs.LAST_FOUR_SSN, ssn.substring(ssn.length() - 4));
				}
				if(StringUtils.hasText((String)priContact.get("firstName")))
					outHs.put(CommonDefs.FIRST_NAME, priContact.get("firstName"));

				if (StringUtils.hasText((String)priContact.get("lastName")))
					outHs.put(CommonDefs.LAST_NAME, priContact.get("lastName"));

				if (priContact.containsKey("dob") && priContact.get("dob") != null)
					outHs.put(CommonDefs.DATE_OF_BIRTH, parseDate(priContact.get("dob")));


				if(priContact.containsKey("cbrInfo"))
					outHs.put(CommonDefs.CBR_INFO, changePhoneDateToString((HashMap<String, Object>) priContact.get("cbrInfo")));

				if(priContact.containsKey("altCbrInfo"))
					outHs.put(CommonDefs.ALT_CBR_INFO, changePhoneDateToString((HashMap<String, Object>)priContact.get("altCbrInfo")));

				if(priContact.containsKey("emailInfo") && priContact.get("emailInfo") instanceof Map) {
					Map<String, Object> emailInfo = (Map<String, Object>) priContact.get("emailInfo");
					if(StringUtils.hasText((String)emailInfo.get("email")))
						outHs.put(CommonDefs.CONTACT_EMAIL, emailInfo.get("email"));
					if(StringUtils.hasText((String)emailInfo.get("emailValidity")))
						outHs.put(CommonDefs.EMAIL_STATUS, emailInfo.get("emailValidity"));
					if(emailInfo.containsKey(CommonDefs.EMAIL_ESTABLISH_DATE))
						outHs.put(CommonDefs.EMAIL_ESTABLISH_DATE, parseDate(emailInfo.get(CommonDefs.EMAIL_ESTABLISH_DATE)));
				}
				if(StringUtils.hasText((String)priAuthInfo.get("question")))
					outHs.put(CommonDefs.SECURITY_QUESTION, priAuthInfo.get("question"));
				if(StringUtils.hasText((String)priAuthInfo.get("answer")))
					outHs.put(CommonDefs.SECURITY_ANSWER, priAuthInfo.get("answer"));

				if(StringUtils.hasText((String)priServiceAddress.get("state")))
					outHs.put(CommonDefs.STATE, priServiceAddress.get("state"));
				if(StringUtils.hasText((String)priServiceAddress.get("zipCode")))
					outHs.put(CommonDefs.PROOF_ZIP, priServiceAddress.get("zipCode"));

				if(StringUtils.hasText((String)priBillingAddress.get("zipcode")))
					outHs.put(CommonDefs.BILLING_ZIPCODE, priBillingAddress.get("zipCode"));
				if(StringUtils.hasText((String)priBillingAddress.get("state")))
					outHs.put(CommonDefs.BILLING_STATE, priBillingAddress.get("state"));

				if(StringUtils.hasText((String)soapRes.get("passCode")))
					outHs.put(CommonDefs.PASSCODE, soapRes.get("passCode"));
				if(StringUtils.hasText((String)soapRes.get("VOIPTN")))
					outHs.put(CommonDefs.VOIPTN, soapRes.get("VOIPTN"));
				if(StringUtils.hasText((String)soapRes.get("memberId")))
					outHs.put(CommonDefs.MEMBERID, soapRes.get("memberId"));
				if(StringUtils.hasText((String)soapRes.get("CWBAN")))
					outHs.put(CommonDefs.CW_BAN, soapRes.get("CWBAN"));



				log.info(SpiMarker.getInstance(),"{}{}PGIR10 : STATUS : {}", SCLASSNAME, sMethodName, outHs);
			}

		} catch (Exception e) {
			log.error("{}{}PRNSE0 : Exception occured {}", SCLASSNAME, sMethodName, e);
			sAppInfo = "Exception while parsing SOAP Response: " + e.toString();
			outHs = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
			log.error("{}{}PRNSE1 : {}", SCLASSNAME, sMethodName, sAppInfo);
		} finally {
			if (outHs == null || outHs.isEmpty()) {
				sAppInfo = "outHs within parseGetAuthInfoResponse is NULL";
				outHs = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				log.info("{}{}PRNSF1 : {}", SCLASSNAME, sMethodName, sAppInfo);
			}
		}
		return outHs;
	}

	public Map<String, Object> getPrimaryContact(List<Map<String, Object>> contacts) {

		if (contacts == null) return null;
		for (Map<String, Object> contactMap : contacts) {
			if (contactMap == null) continue;
			Object contactRoleObj = contactMap.get("contactRole");
			if (contactRoleObj instanceof Map) {
				Map<String, Object> contactRole = (Map<String, Object>) contactRoleObj;
				Object roleName = contactRole.get("roleName");
				if ("Primary".equals(roleName)) {
					return contactMap;
				}
			}
		}
		return null;
	}

	private String parseDate(Object inDate) {
		final String sMethodName = ".parseDate.";

		if (inDate !=null && inDate instanceof Long) {
			Instant instant = Instant.ofEpochMilli((Long) inDate);
			ZoneOffset offset = ZoneOffset.of("-05:00");
			OffsetDateTime odt = instant.atOffset(offset);
			String formattedDateTime = odt.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
			log.debug(SpiMarker.getInstance(),"{}{}PD1 : Formatted Date Time : {}", SCLASSNAME, sMethodName, formattedDateTime);
			return formattedDateTime;
		}
		else
			return String.valueOf(inDate);
	}

	private HashMap<String, Object> changePhoneDateToString(HashMap<String, Object> contInfo) {
		if (contInfo.containsKey("phoneModifiedDate")) {
			Object phoneModDt = contInfo.get("phoneModifiedDate");
			if (phoneModDt != null && phoneModDt instanceof Long) {
				contInfo.put("phoneModifiedDate", parseDate(phoneModDt));
			}
		}
		return contInfo;
	}
	/**
	 * This method is used to build a new GetAuthInfo request.
	 *
	 * It takes a HashMap as input which contains various keys related to the GetAuthInfo request.
	 * The method constructs a SOAP request using the input data and returns it as a String.
	 *
	 * @param inputHs A HashMap containing the input data for the GetAuthInfo request.
	 * @return A String representing the constructed SOAP request.
	 */
	public String buildNewGetAuthInfoRequest(HashMap<String, Object> inputHs) {
		final String sMethodName = ".buildNewGetAuthInfoRequest.";
		log.info(SpiMarker.getInstance(),"{}{}BR1 : Input Hash : {}", SCLASSNAME, sMethodName, inputHs);

		String inputBAN = (String) inputHs.get(CommonDefs.BAN);
		String inputChannel = (String) inputHs.get(CommonDefs.CALLING_SYSTEM_ID);

		String configRequestMethod = (String) inputHs.get(RILDefs.CRMLS_GETAUTHINFO_METHOD_REQUEST);
		String configNSm1 = (String) inputHs.get(RILDefs.PROP_CRMLS_GETAUTHINFO_NS_M1);
		String configPREm1 = (String) inputHs.get(RILDefs.PROP_CRMLS_GETAUTHINFO_PRE_M1);
		String configNSm2 = (String) inputHs.get(RILDefs.PROP_CRMLS_GETAUTHINFO_NS_M2);
		String configPREm2 = (String) inputHs.get(RILDefs.PROP_CRMLS_GETAUTHINFO_PRE_M2);
		String configNSm3 = (String) inputHs.get(RILDefs.PROP_CRMLS_GETAUTHINFO_NS_M3);
		String configPREm3 = (String) inputHs.get(RILDefs.PROP_CRMLS_GETAUTHINFO_PRE_M3);
		String configNSm4 = (String) inputHs.get(RILDefs.PROP_CRMLS_GETAUTHINFO_NS_M4);
		String configPREm4 = (String) inputHs.get(RILDefs.PROP_CRMLS_GETAUTHINFO_PRE_M4);
		String configLoginName = (String) inputHs.get(RILDefs.CRMLS_GETAUTHINFO_LOGIN_NAME);
		String configPWD = (String) inputHs.get(RILDefs.CRMLS_GETAUTHINFO_PASSWORD);
		String configApplicationID = (String) inputHs.get(RILDefs.CRMLS_GETAUTHINFO_APPLICATION_ID);
		String configSBCUID = (String) inputHs.get(RILDefs.PROP_CRMLS_GETAUTHINFO_CLARIFY_SBCUID);
		String configUserNameTokenType = (String) inputHs.get(RILDefs.PROP_CRMLS_GETAUTHINFO_TYPE_USERNAMETOKEN);
		String configUserNameTokenPWDType = (String) inputHs.get(RILDefs.PROP_CRMLS_GETAUTHINFO_TYPE_PASSWORDTOKEN);
		String configNSPWD = (String) inputHs.get(RILDefs.PROP_CRMLS_GETAUTHINFO_NS_PWDTYPE);

		// 1402 - Updated to pass new userid and pwd in securityHeader
		String configSecurityHeaderUID = (String) inputHs.get(RILDefs.LSCRM_SECURITY_HEADER_USER);
		String configSecurityHeaderPWD = (String) inputHs.get(RILDefs.LSCRM_SECURITY_HEADER_PASSWORD);
		// END

		String xml = "";
		try {
			// TagName & AttributeName definitions
			final String ELEM_BAN = "ban";
			final String ELEM_ENVELOPE = "Envelope";
			final String ELEM_HEADER = "SOAP-ENV:Header";
			final String ELEM_SECURITY = "Security";
			final String ELEM_SECURITY_USERNAMETOKEN = "UsernameToken";
			final String ELEM_SECURITY_USERNAME = "Username";
			final String ELEM_SECURITY_PASSWORD = "Password";
			final String ELEM_WSREQUESTHEADER = "wsRequestHeader";
			final String ELEM_WSHEADER = "WSHeader";
			final String ELEM_WSBODY = "Body";
			final String ELEM_REQUESTHEADER = "requestHeader";
			final String ELEM_CLARIFY_USER = "clarifyUser";
			final String ELEM_CLARIFY_USERNAME = "loginName";
			final String ELEM_CLARIFY_PASSWORD = "password";
			final String ELEM_CLARIFY_CHANNEL = "channel";
			final String ELEM_APPL_ID = "applicationID";
			final String ELEM_SBCUID = "sbcuid";
			final String ATTR_XSI_TYPE = "type";
			final String ATTR_TYPE = "Type";

			// Schema Namespace and Prefix definitions.
			final String constNS_SOAPENV = "http://schemas.xmlsoap.org/soap/envelope/";
			final String constPRE_SOAPENV = "SOAP-ENV";
			final String constNS_XSI = "http://www.w3.org/2001/XMLSchema-instance";
			final String constPRE_XSI = "xsi";
			final String constNS_XSD = "http://www.w3.org/2001/XMLSchema";
			final String constPRE_XSD = "xsd";

			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBld = factory.newDocumentBuilder();
			Document doc = docBld.newDocument();
			Element soapEnv = doc.createElementNS(constNS_SOAPENV, ELEM_ENVELOPE);
			soapEnv.setPrefix(constPRE_SOAPENV);
			soapEnv.setAttribute("xmlns:" + constPRE_XSI, constNS_XSI);
			soapEnv.setAttribute("xmlns:" + constPRE_XSD, constNS_XSD);
			soapEnv.setAttribute("xmlns:" + configPREm1, configNSm1);
			soapEnv.setAttribute("xmlns:" + configPREm2, configNSm2);
			soapEnv.setAttribute("xmlns:" + configPREm3, configNSm3);

			doc.appendChild(soapEnv);

			org.w3c.dom.Element soapHeader = doc.createElement(ELEM_HEADER);

			org.w3c.dom.Element soapSecurity = doc.createElementNS(configNSm4, ELEM_SECURITY);
			soapSecurity.setPrefix(configPREm4);

			org.w3c.dom.Element soapSecurityUserNameToken = doc.createElementNS(configNSm4,
					ELEM_SECURITY_USERNAMETOKEN);
			soapSecurityUserNameToken.setPrefix(configPREm4); // Uncommented for FEB 2014 - DF# 17832

			soapSecurityUserNameToken.setAttribute(constPRE_XSI + ":" + ATTR_XSI_TYPE, configUserNameTokenType);

			org.w3c.dom.Element soapSecurityUserName = doc.createElementNS(configNSm4, ELEM_SECURITY_USERNAME);
			soapSecurityUserName.setPrefix(configPREm4);
			org.w3c.dom.Text securityUserName = doc.createTextNode(configSecurityHeaderUID);
			soapSecurityUserName.appendChild(securityUserName);

			org.w3c.dom.Element soapSecurityPassword = doc.createElementNS(configNSm4, ELEM_SECURITY_PASSWORD);
			soapSecurityPassword.setPrefix(configPREm4);
			org.w3c.dom.Text securityPassword = doc.createTextNode(configSecurityHeaderPWD);
			soapSecurityPassword.appendChild(securityPassword);

			soapSecurityPassword.setAttribute(constPRE_XSI + ":" + ATTR_XSI_TYPE, configUserNameTokenPWDType);
			soapSecurityPassword.setAttribute(ATTR_TYPE, configNSPWD);

			soapSecurityUserNameToken.appendChild(soapSecurityUserName);
			soapSecurityUserNameToken.appendChild(soapSecurityPassword);
			soapSecurity.appendChild(soapSecurityUserNameToken);
			soapHeader.appendChild(soapSecurity);
			soapEnv.appendChild(soapHeader);

			org.w3c.dom.Element soapBody = doc.createElement("SOAP-ENV:Body");
			soapEnv.appendChild(soapBody);

			org.w3c.dom.Element soapBodyGAIRequest = doc.createElementNS(configNSm1, configRequestMethod);
			soapBodyGAIRequest.setPrefix(configPREm1);

			org.w3c.dom.Element soapBBodyGAIRequestWSRHeader = doc.createElementNS(configNSm1, ELEM_WSREQUESTHEADER);
			soapBBodyGAIRequestWSRHeader.setPrefix(configPREm1);

			org.w3c.dom.Element soapBodyGAIRequestWSRHeaderWSHeader = doc.createElementNS(configNSm3, ELEM_WSHEADER);
			soapBodyGAIRequestWSRHeaderWSHeader.setPrefix(configPREm3);

			org.w3c.dom.Element soapBodyGAIRequestWSRHeaderBody = doc.createElementNS(configNSm2, ELEM_WSBODY);
			soapBodyGAIRequestWSRHeaderBody.setPrefix(configPREm2);

			soapBBodyGAIRequestWSRHeader.appendChild(soapBodyGAIRequestWSRHeaderWSHeader);
			soapBBodyGAIRequestWSRHeader.appendChild(soapBodyGAIRequestWSRHeaderBody);
			soapBodyGAIRequest.appendChild(soapBBodyGAIRequestWSRHeader);

			org.w3c.dom.Element soapBodyGAIRequestRHeader = doc.createElementNS(configNSm1, ELEM_REQUESTHEADER);
			soapBodyGAIRequestRHeader.setPrefix(configPREm1);

			org.w3c.dom.Element soapBodyGAIRequestRHClarifyUser = doc.createElementNS(configNSm2, ELEM_CLARIFY_USER);
			soapBodyGAIRequestRHClarifyUser.setPrefix(configPREm2);

			org.w3c.dom.Element soapBodyGAIRequestRHCUUserName = doc.createElementNS(configNSm2,
					ELEM_CLARIFY_USERNAME);
			soapBodyGAIRequestRHCUUserName.setPrefix(configPREm2);
			org.w3c.dom.Text bodyGAIRequestRHCUUserName = doc.createTextNode(configLoginName);
			soapBodyGAIRequestRHCUUserName.appendChild(bodyGAIRequestRHCUUserName);

			org.w3c.dom.Element soapBodyGAIRequestRHCUPassword = doc.createElementNS(configNSm2,
					ELEM_CLARIFY_PASSWORD);
			soapBodyGAIRequestRHCUPassword.setPrefix(configPREm2);
			org.w3c.dom.Text bodyGAIRequestRHCUPassword = doc.createTextNode(configPWD);
			soapBodyGAIRequestRHCUPassword.appendChild(bodyGAIRequestRHCUPassword);

			org.w3c.dom.Element soapBodyGAIRequestRHCUChannel = doc.createElementNS(configNSm2, ELEM_CLARIFY_CHANNEL);
			soapBodyGAIRequestRHCUChannel.setPrefix(configPREm2);
			org.w3c.dom.Text bodyGAIRequestRHCUChannel = doc.createTextNode(inputChannel);
			soapBodyGAIRequestRHCUChannel.appendChild(bodyGAIRequestRHCUChannel);

			soapBodyGAIRequestRHClarifyUser.appendChild(soapBodyGAIRequestRHCUUserName);
			soapBodyGAIRequestRHClarifyUser.appendChild(soapBodyGAIRequestRHCUPassword);
			soapBodyGAIRequestRHClarifyUser.appendChild(soapBodyGAIRequestRHCUChannel);

			soapBodyGAIRequestRHeader.appendChild(soapBodyGAIRequestRHClarifyUser);

			org.w3c.dom.Element soapBodyGAIRequestRHsbcuid = doc.createElementNS(configNSm2, ELEM_SBCUID);
			soapBodyGAIRequestRHsbcuid.setPrefix(configPREm2);
			org.w3c.dom.Text bodyGAIRequestRHsbcuid = doc.createTextNode(configSBCUID);
			soapBodyGAIRequestRHsbcuid.appendChild(bodyGAIRequestRHsbcuid);

			org.w3c.dom.Element soapBodyGAIRequestRHApplicationID = doc.createElementNS(configNSm2, ELEM_APPL_ID);
			soapBodyGAIRequestRHApplicationID.setPrefix(configPREm2);
			org.w3c.dom.Text bodyGAIRequestRHApplicationID = doc.createTextNode(configApplicationID);
			soapBodyGAIRequestRHApplicationID.appendChild(bodyGAIRequestRHApplicationID);

			soapBodyGAIRequestRHeader.appendChild(soapBodyGAIRequestRHsbcuid);
			soapBodyGAIRequestRHeader.appendChild(soapBodyGAIRequestRHApplicationID);

			soapBodyGAIRequest.appendChild(soapBodyGAIRequestRHeader);

			org.w3c.dom.Element soapBodyGAIRequestBAN = doc.createElementNS(configNSm1, ELEM_BAN);
			soapBodyGAIRequestBAN.setPrefix(configPREm1);
			org.w3c.dom.Text bodyGAIRequestBAN = doc.createTextNode(inputBAN);
			soapBodyGAIRequestBAN.appendChild(bodyGAIRequestBAN);

			soapBodyGAIRequest.appendChild(soapBodyGAIRequestBAN);

			soapBody.appendChild(soapBodyGAIRequest);

			soapEnv.appendChild(soapBody);

			TransformerFactory transfac = TransformerFactory.newInstance();
			transfac.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
			transfac.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
			transfac.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
			Transformer trans = transfac.newTransformer();
			trans.setOutputProperty(OutputKeys.INDENT, "yes");

			StringWriter sw = new StringWriter();
			StreamResult result = new StreamResult(sw);
			DOMSource source = new DOMSource(doc);
			trans.transform(source, result);
			xml = sw.toString();

			return xml;
		} catch (Exception e) {
			log.error("{}{}BR2 : Exception while building SOAP Request: {}", SCLASSNAME, sMethodName, e.getMessage());
			return xml;
		}
	}

	/**
	 * This method is used to parse the SOAP response from the GetAuthInfo request.
	 *
	 * It takes a String as input which is the SOAP response from the GetAuthInfo request.
	 * The method parses the SOAP response and extracts the relevant information.
	 * The extracted information is then stored in a HashMap and returned.
	 *
	 * @param soapRes A String containing the SOAP response from the GetAuthInfo request.
	 * @return A HashMap containing the parsed information from the SOAP response.
	 */
	public HashMap<String, Object> parseNewGetAuthInfoResponse(String soapRes) {
		final String sMethodName = ".parseNewGetAuthInfoResponse.";

		HashMap<String, Object> outHs = null;
		String sAppInfo = null;

		try {
			// Support for Namespace-Aware Response Parsing... Call the other method for
			// NS-aware parsing based on CFG-Switch.

			if (sCfgIsParserNamespaceAware.trim().equalsIgnoreCase(MPSDefs.YES)) {
				outHs = parseNewGetAuthInfoResponseWithNSSupport(soapRes);
				return outHs;
			}

		} catch (Exception e) {
			log.error("{}{}PRE0 : Exception occured {}", SCLASSNAME, sMethodName, e);
			sAppInfo = "Exception while parsing SOAP Response: " + e.toString();
			outHs = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
			log.error("{}{}PRE1 : {}", SCLASSNAME, sMethodName, sAppInfo);
		} finally {
			if (outHs == null || outHs.isEmpty()) {
				sAppInfo = "outHs within parseGetAuthInfoResponse is NULL";
				outHs = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				log.info("{}{}PRF1 : {}", SCLASSNAME, sMethodName, sAppInfo);
			}
		}
		return outHs;
	}

	/**
	 * This method is used to parse the SOAP response from the GetAuthInfo request with namespace support.
	 *
	 * It takes a String as input which is the SOAP response from the GetAuthInfo request.
	 * The method parses the SOAP response and extracts the relevant information.
	 * The extracted information is then stored in a HashMap and returned.
	 *
	 * The method handles various tags in the SOAP response such as <contacts>, <authInfo>, <contact>, <serviceAddress>, <passCode>, <VOIPTN>, <CWBAN>, <billingAddress>, <memberId>, <cbrInfo>, <altCbrInfo>, and <emailInfo>.
	 * It also handles various error codes in the SOAP response and constructs appropriate error responses.
	 *
	 * @param soapRes A String containing the SOAP response from the GetAuthInfo request.
	 * @return A HashMap containing the parsed information from the SOAP response.
	 * @throws Exception if an error occurs during the operation.
	 */
	public HashMap<String, Object> parseNewGetAuthInfoResponseWithNSSupport(String soapRes) {
		final String sMethodName = ".parseNewGetAuthInfoResponseWithNSSupport.";

		final String CRM_DETAIL_TAG = "detail";
		final String CRM_DETAIL_ERROR_CODE_TAG = "ErrorCode";
		final String CRM_CONTACTS_TAG = "contacts";
		final String CRM_CONTACT_TAG = "contact";
		final String CRM_CONTACT_SSN_TAG = "ssn";
		final String CRM_CONTACT_DOB_TAG = "dob";
		final String CRM_AUTHINFO_TAG = "authInfo";
		final String CRM_AUTHINFO_QUESTION_TAG = "question";
		final String CRM_AUTHINFO_ANSWER_TAG = "answer";
		final String CRM_CONTACTROLE_TAG = "contactRole";
		final String CRM_CONTACTROLE_ROLENAME_TAG = "roleName";
		final String CRM_SERVCIEADDRESS_TAG = "serviceAddress";
		final String CRM_SERVCIEADDRESS_ZIPCODE_TAG = "zipcode";
		final String CRM_PASSCODE_TAG = "passCode";
		final String CRM_BAN_NOT_FOUND_ERROR = "001";
		final String CRM_UNAUTH_LOGIN_ERROR = "002";
		final String CRM_SYS_ERROR = "003";
		final String CRM_ROLENAME_PRIMARY = "Primary";
		final String CRM_CONTACT_FIRSTNAME_TAG = "firstName";
		final String CRM_CONTACT_LASTNAME_TAG = "lastName";
		final String CRM_SERVCIEADDRESS_STATE_TAG = "state";
		final String CRM_VOIPTN_TAG = "VOIPTN";
		final String CRM_CWBAN_TAG = "CWBAN";
		final String CRM_BILLINGADDRESS_TAG = "billingAddress";
		final String CRM_BILLINGADDRESS_ZIPCODE_TAG = "zipcode";
		final String CRM_BILLINGADDRESS_STATE_TAG = "state";
		final String CRM_MEMBER_ID_TAG = "memberId";
		// 1510:US421459: RIL QueryDestination changes in support of Uverse CBRs
		final String CRM_CBRINFO_TAG = "cbrInfo";
		final String CRM_CBRINFO_PHONE_TAG = "phone";
		final String CRM_CBRINFO_PHONETYPE_TAG = "phoneType";
		final String CRM_CBRINFO_ISATTNUMBER_TAG = "isATTNumber";
		final String CRM_CBRINFO_DEVICEINHANDVALIDATIONSTS_TAG = "deviceInHandValidationSts";
		final String CRM_CBRINFO_PHONEMODIFIEDDATE_TAG = "phoneModifiedDate";
		final String CRM_CBRINFO_SUBSCRIBERID_TAG = "subscriberId";
		final String CRM_ALTCBRINFO_TAG = "altCbrInfo";
		final String CRM_ALTCBRINFO_PHONE_TAG = "phone";
		final String CRM_ALTCBRINFO_PHONETYPE_TAG = "phoneType";
		final String CRM_ALTCBRINFO_ISATTNUMBER_TAG = "isATTNumber";
		final String CRM_ALTCBRINFO_DEVICEINHANDVALIDATIONSTS_TAG = "deviceInHandValidationSts";
		final String CRM_ALTCBRINFO_PHONEMODIFIEDDATE_TAG = "phoneModifiedDate";
		final String CRM_ALTCBRINFO_SUBSCRIBERID_TAG = "subscriberId";
		final String CRM_EMAILINFO_TAG = "emailInfo";
		final String CRM_EMAILINFO_EMAIL_TAG = "email";
		final String CRM_EMAILINFO_EMAILVALIDITY_TAG = "emailValidity";
		final String CRM_EMAILINFO_EMAILESTABLISHDATE_TAG = "emailEstablishDate";

		String sAppInfo = null;
		String crmErrorCode = null;
		HashMap<String, Object> outHs = null;
		String crmQuestion = null;
		String crmAnswer = null;
		String crmSSN = null;
		String crmSSNlast4 = null;
		String crmDOB = null;
		String crmDOBmmddyyyy = null;
		String crmZipcode = null;
		String crmPasscode = null;
		String contactRole = null;
		String crmFirstName = null;
		String crmLastName = null;
		String crmEmail = null;
		String crmState = null;
		String crmVoiptn = null;
		String crmCwban = null;
		String crmBillingZipcode = null;
		String crmBillingState = null;
		String crmMemberId = null;
		// 1510:US421459: RIL QueryDestination changes in support of Uverse CBRs
		String crmCBRInfophone = null;
		String crmCBRInfophoneType = null;
		String crmCBRInfoisATTNumber = null;
		String crmCBRInfodeviceInHandValidationSts = null;
		String crmCBRInfophoneModifiedDate = null;
		String crmCBRInfosubscriberId = null;
		String crmAltCBRInfophone = null;
		String crmAltCBRInfophoneType = null;
		String crmAltCBRInfoisATTNumber = null;
		String crmAltCBRInfodeviceInHandValidationSts = null;
		String crmAltCBRInfophoneModifiedDate = null;
		String crmAltCBRInfosubscriberId = null;
		String crmEmailValidity = null;
		String crmEmailEstablishDate = null;

		try {

			DocumentBuilderFactory docFac = DocumentBuilderFactory.newInstance();
			docFac.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
			docFac.setNamespaceAware(true);
			docFac.setIgnoringComments(true);
			DocumentBuilder docBld = docFac.newDocumentBuilder();
			StringReader sr = new StringReader(soapRes);
			InputSource inputSource = new InputSource(sr);
			Document doc = (Document) docBld.parse(inputSource);

			NodeList elements = doc.getChildNodes();
			if (elements == null) {
				sAppInfo = "LSCRM GetAuthInfo SOAP Response: Node list is NULL";
				outHs = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				log.info("{}{}PRNS1 : {}", SCLASSNAME, sMethodName, sAppInfo);
				return outHs;
			}

			String crmLSGetAuthInfoNS0 = (sPropCRMLSGetAuthInfom0NS == null) ? "" : sPropCRMLSGetAuthInfom0NS;
			String crmLSGetAuthInfoNS1 = (sPropCRMLSGetAuthInfom1NS == null) ? "" : sPropCRMLSGetAuthInfom1NS;
			String crmLSGetAuthInfoNS2 = (sPropCRMLSGetAuthInfom2NS == null) ? "" : sPropCRMLSGetAuthInfom2NS;

			// 1. Check if CLARIFY's call has a SOAP-Fault which contains WSException and
			// error-code.
			NodeList detailNodeL = doc.getElementsByTagName(CRM_DETAIL_TAG);

			if (detailNodeL.getLength() > 0) {
				sAppInfo = "<detail> tag exists under fault envelope in the SOAP Response. Error Node Length: "
						+ detailNodeL.getLength();
				log.info("{}{}PRNS2 : {}", SCLASSNAME, sMethodName, sAppInfo);

				NodeList errorCodeNodeL = doc.getElementsByTagNameNS(crmLSGetAuthInfoNS0, CRM_DETAIL_ERROR_CODE_TAG);

				if (errorCodeNodeL != null) {
					Node errorCodeNode = errorCodeNodeL.item(0);
					if (errorCodeNode != null) {
						if (errorCodeNode.getFirstChild() != null) {
							crmErrorCode = errorCodeNode.getFirstChild().getNodeValue();
							log.info("{}{}PRNS3 : <ErrorCode> value = {}", SCLASSNAME, sMethodName, crmErrorCode);
						}
					}
				}

				// Now, if an Error-code exists in SOAP-Fault, translate it to get appropriate
				// error-Response from CLARIFY.
				if (crmErrorCode != null && crmErrorCode.equals(CRM_BAN_NOT_FOUND_ERROR)) {
					sAppInfo = "BAN is NOT found in LS CRM";
					outHs = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_BAN_NOT_FOUND_IN_CRM_NUM, sAppInfo);
					log.info("{}{}PRNS4 : {}", SCLASSNAME, sMethodName, sAppInfo);
					return outHs;
				} else if (crmErrorCode != null && crmErrorCode.equals(CRM_UNAUTH_LOGIN_ERROR)) {
					sAppInfo = "Unauthorized Login to LS CRM";
					outHs = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_UNAUTH_LOGIN_CRM_NUM, sAppInfo);
					log.info("{}{}PRNS5 : {}", SCLASSNAME, sMethodName, sAppInfo);
					return outHs;
				} else if (crmErrorCode != null && crmErrorCode.equals(CRM_SYS_ERROR)) {
					sAppInfo = "Internal LS CRM Error";
					outHs = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_CRM_NUM, sAppInfo);
					log.info("{}{}PRNS6 : {}", SCLASSNAME, sMethodName, sAppInfo);
					return outHs;
				}
			}

			// 2. Retrieve <contacts> and relevant info from xml
			// <contacts> could be 0 - many
			// <contacts> sub tags are
			// <contact> (ssn, dob)
			// <authinfo> (question, answer)
			// <contactRole> (roleName="Primary" is what we're interested in)
			// <serviceAddress> (zipCode)



			// If contactRole is Primary then retrieve info from
			// authInfo, contact and serviceAddress nodes


			NodeList contactsL = doc.getElementsByTagNameNS(crmLSGetAuthInfoNS1, CRM_CONTACTS_TAG);
			if (contactsL.getLength() > 0) {
				sAppInfo = "<contacts> tag exists in the SOAP Response. contacts Node Length: " + contactsL.getLength();
				log.info("{}{}PRNS7 : {}", SCLASSNAME, sMethodName, sAppInfo);
				for (int k = 0; k < contactsL.getLength(); k++) {
					// If Primay Contact Details have been recorded, break the loop.
					if (contactRole != null && contactRole.equalsIgnoreCase(CRM_ROLENAME_PRIMARY))
						break;

					boolean isContactRolePopulated = false;
					boolean isAuthInfoPopulated = false;
					boolean isContactPopulated = false;
					boolean isServiceAddressPopulated = false;
					// 1510:US421459: RIL QueryDestination changes in support of Uverse CBRs
					boolean isCbrInfoPopulated = false;
					boolean isAltCbrInfoPopulated = false;
					boolean isEmailInfoPopulated = false;

					Node currentContactNode = contactsL.item(k);
					NodeList currentContactNodeChildren = currentContactNode.getChildNodes();
					if (currentContactNodeChildren != null) {
						Node authInfoN = null;
						Node contactN = null;
						Node serviceAddressN = null;

						for (int l = 0; l < currentContactNodeChildren.getLength(); l++) {

							Node n = currentContactNodeChildren.item(l);
							if (n.getNodeName() != null && CRM_CONTACTROLE_TAG.equals(n.getLocalName())
									&& n.getNamespaceURI().equals(crmLSGetAuthInfoNS2) && !isContactRolePopulated) {

								NodeList contactRoleChildren = n.getChildNodes();
								for (int m = 0; m < contactRoleChildren.getLength(); m++) {

									Node N = contactRoleChildren.item(m);
									if (N.getNodeName() != null && CRM_CONTACTROLE_ROLENAME_TAG.equals(N.getLocalName())
											&& crmLSGetAuthInfoNS2.equals(N.getNamespaceURI())) {
										if (N.getFirstChild() != null) {
											contactRole = N.getFirstChild().getNodeValue();
											log.debug("{}{}PRNS8 : <contacts> -> <contactRole> -> <roleName> value = {}", SCLASSNAME, sMethodName, contactRole);
											isContactRolePopulated = true;
										}
									}
								}
							} else if (n.getNodeName() != null && CRM_AUTHINFO_TAG.equals(n.getLocalName())
									&& n.getNamespaceURI().equals(crmLSGetAuthInfoNS2))
								authInfoN = n;
							else if (n.getNodeName() != null && CRM_CONTACT_TAG.equals(n.getLocalName())
									&& n.getNamespaceURI().equals(crmLSGetAuthInfoNS2))
								contactN = n;
							else if (n.getNodeName() != null && CRM_SERVCIEADDRESS_TAG.equals(n.getLocalName())
									&& n.getNamespaceURI().equals(crmLSGetAuthInfoNS2))
								serviceAddressN = n;

							// If contactRole is Primary then retrieve info from
							// authInfo, contact and serviceAddress nodes
							if (contactRole != null && contactRole.equalsIgnoreCase(CRM_ROLENAME_PRIMARY)) {
								if (authInfoN != null && !isAuthInfoPopulated) {
									NodeList authInfoChildren = authInfoN.getChildNodes();

									for (int m = 0; m < authInfoChildren.getLength(); m++) {

										Node N = authInfoChildren.item(m);
										if (N.getNodeName() != null
												&& CRM_AUTHINFO_QUESTION_TAG.equals(N.getLocalName())
												&& crmLSGetAuthInfoNS2.equals(N.getNamespaceURI())) {
											if (N.getFirstChild() != null) {
												crmQuestion = N.getFirstChild().getNodeValue();
												if (crmQuestion != null)
													log.debug("{}{}PRNS9 : <contacts> -> <authInfo> -> <question> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
											}
										}
										if (N.getNodeName() != null && CRM_AUTHINFO_ANSWER_TAG.equals(N.getLocalName())
												&& crmLSGetAuthInfoNS2.equals(N.getNamespaceURI())) {
											if (N.getFirstChild() != null) {
												crmAnswer = N.getFirstChild().getNodeValue();
												if (crmAnswer != null)
													log.debug("{}{}PRNS10 : <contacts> -> <authInfo> -> <answer> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
											}
										}
										isAuthInfoPopulated = true;
									}
								}

								if (contactN != null && !isContactPopulated) {
									NodeList contactChildren = contactN.getChildNodes();

									for (int m = 0; m < contactChildren.getLength(); m++) {

										Node N = contactChildren.item(m);
										if (N.getNodeName() != null && CRM_CONTACT_SSN_TAG.equals(N.getLocalName())
												&& crmLSGetAuthInfoNS2.equals(N.getNamespaceURI())) {
											if (N.getFirstChild() != null)
												crmSSN = N.getFirstChild().getNodeValue();
											if (crmSSN != null && crmSSN.length() > 4) {
												crmSSNlast4 = crmSSN.substring(crmSSN.length() - 4);
												if (crmSSNlast4 != null)
													log.debug("{}{}PRNS11 : <contacts> -> <contact> -> <ssn> (last 4) value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);

											}
										}
										if (N.getNodeName() != null && CRM_CONTACT_DOB_TAG.equals(N.getLocalName())
												&& crmLSGetAuthInfoNS2.equals(N.getNamespaceURI())) {
											if (N.getFirstChild() != null)
												crmDOB = N.getFirstChild().getNodeValue();
											// crm_dob format - 2006-06-01T20:11:04.878Z
											// or crm_dob format - 2008-12-02T15:51:13-06:00
											if (crmDOB != null) {
												String yyyy = crmDOB.substring(0, 4);
												String mm = crmDOB.substring(5, 7);
												String dd = crmDOB.substring(8, 10);
												crmDOBmmddyyyy = mm + dd + yyyy;
												if (yyyy != null && mm != null && dd != null)
													log.debug("{}{}PRNS12 : <contacts> -> <contact> -> <dob> (MMDDYYYY) value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
											}
										}
										if (N.getNodeName() != null
												&& CRM_CONTACT_FIRSTNAME_TAG.equals(N.getLocalName())
												&& crmLSGetAuthInfoNS2.equals(N.getNamespaceURI())) {
											if (N.getFirstChild() != null)
												crmFirstName = N.getFirstChild().getNodeValue();
											if (crmFirstName != null)
												log.debug("{}{}PRNS13 : <contacts> -> <contact> -> <firstName> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
										}
										if (N.getNodeName() != null && CRM_CONTACT_LASTNAME_TAG.equals(N.getLocalName())
												&& crmLSGetAuthInfoNS2.equals(N.getNamespaceURI())) {
											if (N.getFirstChild() != null)
												crmLastName = N.getFirstChild().getNodeValue();
											if (crmLastName != null)
												log.debug("{}{}PRNS14 : <contacts> -> <contact> -> <lastName> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
										}

										// 1510::US421459: RIL QueryDestination changes in support of Uverse CBRs
										// Block for CbrInfo

										if (N.getNodeName() != null && CRM_CBRINFO_TAG.equals(N.getLocalName())
												&& N.getNamespaceURI().equals(crmLSGetAuthInfoNS2)) {
											Node cbrInfoN = N;
											if (cbrInfoN != null && !isCbrInfoPopulated) {
												NodeList cbrInfoChildren = cbrInfoN.getChildNodes();

												for (int p = 0; p < cbrInfoChildren.getLength(); p++) {

													Node N1 = cbrInfoChildren.item(p);
													if (N1.getNodeName() != null
															&& CRM_CBRINFO_PHONE_TAG.equals(N1.getLocalName())
															&& crmLSGetAuthInfoNS2.equals(N1.getNamespaceURI())) {
														if (N1.getFirstChild() != null) {
															crmCBRInfophone = N1.getFirstChild().getNodeValue();
															log.debug("{}{}PRNS33.1 : <contacts> -> <contact> -> <cbrInfo> -> <phone> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
														}
													}
													if (N1.getNodeName() != null
															&& CRM_CBRINFO_PHONETYPE_TAG.equals(N1.getLocalName())
															&& crmLSGetAuthInfoNS2.equals(N1.getNamespaceURI())) {
														if (N1.getFirstChild() != null) {
															crmCBRInfophoneType = N1.getFirstChild().getNodeValue();
															log.debug("{}{}PRNS33.2 : <contacts> -> <contact> -> <cbrInfo> -> <phoneType> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
														}
													}
													if (N1.getNodeName() != null
															&& CRM_CBRINFO_ISATTNUMBER_TAG.equals(N1.getLocalName())
															&& crmLSGetAuthInfoNS2.equals(N1.getNamespaceURI())) {
														if (N1.getFirstChild() != null) {
															crmCBRInfoisATTNumber = N1.getFirstChild().getNodeValue();
															log.debug("{}{}PRNS33.3 : <contacts> -> <contact> -> <cbrInfo> -> <isATTNumber> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
														}
													}
													if (N1.getNodeName() != null
															&& CRM_CBRINFO_DEVICEINHANDVALIDATIONSTS_TAG
															.equals(N1.getLocalName())
															&& crmLSGetAuthInfoNS2.equals(N1.getNamespaceURI())) {
														if (N1.getFirstChild() != null) {
															crmCBRInfodeviceInHandValidationSts = N1.getFirstChild()
																	.getNodeValue();
															log.debug("{}{}PRNS33.4 : <contacts> -> <contact> -> <cbrInfo> -> <deviceInHandValidationSts> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
														}
													}
													if (N1.getNodeName() != null
															&& CRM_CBRINFO_PHONEMODIFIEDDATE_TAG
															.equals(N1.getLocalName())
															&& crmLSGetAuthInfoNS2.equals(N1.getNamespaceURI())) {
														if (N1.getFirstChild() != null) {
															crmCBRInfophoneModifiedDate = N1.getFirstChild()
																	.getNodeValue();
															log.debug("{}{}PRNS33.5 : <contacts> -> <contact> -> <cbrInfo> -> <phoneModifiedDate> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
														}
													}
													if (N1.getNodeName() != null
															&& CRM_CBRINFO_SUBSCRIBERID_TAG.equals(N1.getLocalName())
															&& crmLSGetAuthInfoNS2.equals(N1.getNamespaceURI())) {
														if (N1.getFirstChild() != null) {
															crmCBRInfosubscriberId = N1.getFirstChild().getNodeValue();
															log.debug("{}{}PRNS33.6 : <contacts> -> <contact> -> <cbrInfo> -> <subscriberId> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
														}
													}
													isCbrInfoPopulated = true;
												}
											}
										}
										// Block for altCbrInfo
										if (N.getNodeName() != null && CRM_ALTCBRINFO_TAG.equals(N.getLocalName())
												&& N.getNamespaceURI().equals(crmLSGetAuthInfoNS2)) {
											Node altCbrInfoN = N;

											if (altCbrInfoN != null && !isAltCbrInfoPopulated) {
												NodeList altCbrInfoChildren = altCbrInfoN.getChildNodes();

												for (int p = 0; p < altCbrInfoChildren.getLength(); p++) {

													Node N1 = altCbrInfoChildren.item(p);
													if (N1.getNodeName() != null
															&& CRM_ALTCBRINFO_PHONE_TAG.equals(N1.getLocalName())
															&& crmLSGetAuthInfoNS2.equals(N1.getNamespaceURI())) {
														if (N1.getFirstChild() != null) {
															crmAltCBRInfophone = N1.getFirstChild().getNodeValue();
															log.debug("{}{}PRNS34.1 : <contacts> -> <contact> -> <altCbrInfo> -> <phone> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
														}
													}
													if (N1.getNodeName() != null
															&& CRM_ALTCBRINFO_PHONETYPE_TAG.equals(N1.getLocalName())
															&& crmLSGetAuthInfoNS2.equals(N1.getNamespaceURI())) {
														if (N1.getFirstChild() != null) {
															crmAltCBRInfophoneType = N1.getFirstChild().getNodeValue();
															log.debug("{}{}PRNS34.2 : <contacts> -> <contact> -> <altCbrInfo> -> <phoneType> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
														}
													}
													if (N1.getNodeName() != null
															&& CRM_ALTCBRINFO_ISATTNUMBER_TAG.equals(N1.getLocalName())
															&& crmLSGetAuthInfoNS2.equals(N1.getNamespaceURI())) {
														if (N1.getFirstChild() != null) {
															crmAltCBRInfoisATTNumber = N1.getFirstChild()
																	.getNodeValue();
															log.debug("{}{}PRNS34.3 : <contacts> -> <contact> -> <altCbrInfo> -> <isATTNumber> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
														}
													}
													if (N1.getNodeName() != null
															&& CRM_ALTCBRINFO_DEVICEINHANDVALIDATIONSTS_TAG
															.equals(N1.getLocalName())
															&& crmLSGetAuthInfoNS2.equals(N1.getNamespaceURI())) {
														if (N1.getFirstChild() != null) {
															crmAltCBRInfodeviceInHandValidationSts = N1.getFirstChild()
																	.getNodeValue();
															log.debug("{}{}PRNS34.4 : <contacts> -> <contact> -> <altCbrInfo> -> <deviceInHandValidationSts> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
														}
													}
													if (N1.getNodeName() != null
															&& CRM_ALTCBRINFO_PHONEMODIFIEDDATE_TAG
															.equals(N1.getLocalName())
															&& crmLSGetAuthInfoNS2.equals(N1.getNamespaceURI())) {
														if (N1.getFirstChild() != null) {
															crmAltCBRInfophoneModifiedDate = N1.getFirstChild()
																	.getNodeValue();
															log.debug("{}{}PRNS34.5 : <contacts> -> <contact> -> <altCbrInfo> -> <phoneModifiedDate> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
														}
													}
													if (N1.getNodeName() != null
															&& CRM_ALTCBRINFO_SUBSCRIBERID_TAG.equals(N1.getLocalName())
															&& crmLSGetAuthInfoNS2.equals(N1.getNamespaceURI())) {
														if (N1.getFirstChild() != null) {
															crmAltCBRInfosubscriberId = N1.getFirstChild()
																	.getNodeValue();
															log.debug("{}{}PRNS34.6 : <contacts> -> <contact> -> <altCbrInfo> -> <subscriberId> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
														}
													}
													isAltCbrInfoPopulated = true;
												}
											}
										}
										// Block for emailInfo
										if (N.getNodeName() != null && CRM_EMAILINFO_TAG.equals(N.getLocalName())
												&& N.getNamespaceURI().equals(crmLSGetAuthInfoNS2)) {
											Node emailInfoN = N;

											if (emailInfoN != null && !isEmailInfoPopulated) {
												NodeList emailInfoChildren = emailInfoN.getChildNodes();

												for (int p = 0; p < emailInfoChildren.getLength(); p++) {

													Node n1 = emailInfoChildren.item(p);
													if (n1.getNodeName() != null
															&& CRM_EMAILINFO_EMAIL_TAG.equals(n1.getLocalName())
															&& crmLSGetAuthInfoNS2.equals(n1.getNamespaceURI())) {
														if (n1.getFirstChild() != null) {
															crmEmail = n1.getFirstChild().getNodeValue();
															log.debug("{}{}PRNS35.1 : <contacts> -> <contact> -> <emailInfo> -> <email> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
														}
													}
													if (n1.getNodeName() != null
															&& CRM_EMAILINFO_EMAILVALIDITY_TAG.equals(n1.getLocalName())
															&& crmLSGetAuthInfoNS2.equals(n1.getNamespaceURI())) {
														if (n1.getFirstChild() != null) {
															crmEmailValidity = n1.getFirstChild().getNodeValue();
															log.debug("{}{}PRNS35.2 : <contacts> -> <contact> -> <emailInfo> -> <emailValidity> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
														}
													}
													if (n1.getNodeName() != null
															&& CRM_EMAILINFO_EMAILESTABLISHDATE_TAG
															.equals(n1.getLocalName())
															&& crmLSGetAuthInfoNS2.equals(n1.getNamespaceURI())) {
														if (n1.getFirstChild() != null) {
															crmEmailEstablishDate = n1.getFirstChild().getNodeValue();
															log.debug("{}{}PRNS35.3 : <contacts> -> <contact> -> <emailInfo> -> <emailEstablishDate> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
														}
													}
													isEmailInfoPopulated = true;
												}
											}
										}
										isContactPopulated = true;
									}
								}

								if (serviceAddressN != null && !isServiceAddressPopulated) {
									NodeList serviceAddressChildren = serviceAddressN.getChildNodes();

									for (int m = 0; m < serviceAddressChildren.getLength(); m++) {

										Node N = serviceAddressChildren.item(m);
										if (N.getNodeName() != null
												&& CRM_SERVCIEADDRESS_ZIPCODE_TAG.equals(N.getLocalName())
												&& crmLSGetAuthInfoNS2.equals(N.getNamespaceURI())) {
											if (N.getFirstChild() != null) {
												crmZipcode = N.getFirstChild().getNodeValue();
												if (crmZipcode != null)
													log.debug("{}{}PRNS17 : <contacts> -> <serviceAddress> -> <zipCode> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
											}
										}
										if (N.getNodeName() != null
												&& CRM_SERVCIEADDRESS_STATE_TAG.equals(N.getLocalName())
												&& crmLSGetAuthInfoNS2.equals(N.getNamespaceURI())) {
											if (N.getFirstChild() != null) {
												crmState = N.getFirstChild().getNodeValue();
												if (crmState != null)
													log.debug("{}{}PRNS18 : <contacts> -> <serviceAddress> -> <state> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
											}
										}
										isServiceAddressPopulated = true;
									}
								}
							} // End of If contactRole is Primary
						}
					}
				}
			}

			// 3. Retrieve <passCode> info

			NodeList passCodeNodeL = doc.getElementsByTagNameNS(crmLSGetAuthInfoNS1, CRM_PASSCODE_TAG);
			if (passCodeNodeL.getLength() > 0) {
				if ((passCodeNodeL.item(0) != null) && (passCodeNodeL.item(0).getNodeType() == Node.ELEMENT_NODE)
						&& (passCodeNodeL.item(0).getFirstChild() != null)) {
					crmPasscode = passCodeNodeL.item(0).getFirstChild().getNodeValue();
					if (crmPasscode != null)
						log.debug("{}{}PRNS19 : <passCode> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
				}
			}

			// 4. Retrieve <VOIPTN> info
			NodeList voipTNNodeL = doc.getElementsByTagNameNS(crmLSGetAuthInfoNS1, CRM_VOIPTN_TAG);
			if (voipTNNodeL.getLength() > 0) {
				sAppInfo = "<VOIPTN> tag exists in the SOAP Response. VOIPTN Node Length: " + voipTNNodeL.getLength();
				log.debug("{}{}PRNS20 : {}", SCLASSNAME, sMethodName, sAppInfo);
				if ((voipTNNodeL.item(0) != null) && (voipTNNodeL.item(0).getNodeType() == Node.ELEMENT_NODE)
						&& (voipTNNodeL.item(0).getFirstChild() != null)) {
					crmVoiptn = voipTNNodeL.item(0).getFirstChild().getNodeValue();
					if (crmVoiptn != null)
						log.debug("{}{}PRNS21 : <VOIPTN> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
				}
			}

			// 4. Retrieve <memberId> info
			NodeList memberIdNodeL = doc.getElementsByTagNameNS(crmLSGetAuthInfoNS1, CRM_MEMBER_ID_TAG);
			if (memberIdNodeL.getLength() > 0) {
				sAppInfo = "<memberId> tag exists in the SOAP Response. memberId Node Length: "
						+ memberIdNodeL.getLength();
				log.debug("{}{}PRNS21.1 : {}", SCLASSNAME, sMethodName, sAppInfo);
				if ((memberIdNodeL.item(0) != null) && (memberIdNodeL.item(0).getNodeType() == Node.ELEMENT_NODE)
						&& (memberIdNodeL.item(0).getFirstChild() != null)) {
					crmMemberId = memberIdNodeL.item(0).getFirstChild().getNodeValue();
					if (crmMemberId != null)
						log.debug("{}{}PRNS21.2 : <memberId> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
				}
			}

			// 5. Retrieve <CWBAN> info
			NodeList cwBANNodeL = doc.getElementsByTagNameNS(crmLSGetAuthInfoNS1, CRM_CWBAN_TAG);
			if (cwBANNodeL.getLength() > 0) {
				sAppInfo = "<CWBAN> tag exists in the SOAP Response. CWBAN Node Length: " + cwBANNodeL.getLength();
				log.debug("{}{}PRNS22 : {}", SCLASSNAME, sMethodName, sAppInfo);
				if ((cwBANNodeL.item(0) != null) && (cwBANNodeL.item(0).getNodeType() == Node.ELEMENT_NODE)
						&& (cwBANNodeL.item(0).getFirstChild() != null)) {
					crmCwban = cwBANNodeL.item(0).getFirstChild().getNodeValue();
					if (crmCwban != null)
						log.debug("{}{}PRNS23 : <CWBAN> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
				}
			}

			// 6. Retrieve <billingAddress> info
			NodeList billingAddressNodeL = doc.getElementsByTagNameNS(crmLSGetAuthInfoNS1, CRM_BILLINGADDRESS_TAG);
			if (billingAddressNodeL.getLength() > 0) {
				sAppInfo = "<billingAddress> tag exists in the SOAP Response. billingAddress Node Length: "
						+ billingAddressNodeL.getLength();
				log.debug("{}{}PRNS24 : {}", SCLASSNAME, sMethodName, sAppInfo);
				Node addressTypeNode = billingAddressNodeL.item(0);
				NodeList addressTypeChildren = addressTypeNode.getChildNodes();
				if (addressTypeChildren != null) {
					for (int i = 0; i < addressTypeChildren.getLength(); i++) {
						Node N = addressTypeChildren.item(i);
						if (N.getNodeName() != null && CRM_BILLINGADDRESS_ZIPCODE_TAG.equals(N.getLocalName())
								&& crmLSGetAuthInfoNS2.equals(N.getNamespaceURI())) {
							if (N.getFirstChild() != null) {
								crmBillingZipcode = N.getFirstChild().getNodeValue();
								if (crmBillingZipcode != null)
									log.debug("{}{}PRNS25 : <contacts> -> <billingAddress> -> <zipCode> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
							}
						}
						if (N.getNodeName() != null && CRM_BILLINGADDRESS_STATE_TAG.equals(N.getLocalName())
								&& crmLSGetAuthInfoNS2.equals(N.getNamespaceURI())) {
							if (N.getFirstChild() != null) {
								crmBillingState = N.getFirstChild().getNodeValue();
								if (crmBillingState != null)
									log.debug("{}{}PRNS26 : <contacts> -> <serviceAddress> -> <state> value = {}", SCLASSNAME, sMethodName, CommonDefs.PASSWORD_MASK);
							}
						}
					}
				}
			}

			// Return SUCCESS, Only If Details are found for PRIMARY Contact in CLARIFY
			// Response.
			// Else, return with ERR_INVALID_DATA.
			if (contactRole != null && contactRole.equalsIgnoreCase(CRM_ROLENAME_PRIMARY)) {

				outHs = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, "");

				if (crmQuestion != null)
					outHs.put(CommonDefs.SECURITY_QUESTION, crmQuestion);
				if (crmAnswer != null)
					outHs.put(CommonDefs.SECURITY_ANSWER, crmAnswer);
				if (crmPasscode != null)
					outHs.put(CommonDefs.PASSCODE, crmPasscode);
				if (crmDOBmmddyyyy != null)
					outHs.put(CommonDefs.DATE_OF_BIRTH, crmDOBmmddyyyy);
				if (crmSSNlast4 != null)
					outHs.put(CommonDefs.LAST_FOUR_SSN, crmSSNlast4);
				if (crmZipcode != null)
					outHs.put(CommonDefs.PROOF_ZIP, crmZipcode);
				if (crmFirstName != null)
					outHs.put(CommonDefs.FIRST_NAME, crmFirstName);
				if (crmLastName != null)
					outHs.put(CommonDefs.LAST_NAME, crmLastName);
				if (crmState != null)
					outHs.put(CommonDefs.STATE, crmState);
				if (crmVoiptn != null)
					outHs.put(CommonDefs.VOIPTN, crmVoiptn);
				if (crmCwban != null)
					outHs.put(CommonDefs.CW_BAN, crmCwban);
				if (crmBillingZipcode != null)
					outHs.put(CommonDefs.BILLING_ZIPCODE, crmBillingZipcode);
				if (crmBillingState != null)
					outHs.put(CommonDefs.BILLING_STATE, crmBillingState);
				if (crmMemberId != null)
					outHs.put(CommonDefs.MEMBERID, crmMemberId);
				// 1510:US421459: RIL QueryDestination changes in support of Uverse CBRs
				// putting cbrInfo as HashMap.
				HashMap<String, Object> hmCbrInfo = CommonUtil.getHashMap();
				if (crmCBRInfophone != null)
					hmCbrInfo.put(CommonDefs.PHONE, crmCBRInfophone);
				if (crmCBRInfophoneType != null)
					hmCbrInfo.put(CommonDefs.PHONE_TYPE, crmCBRInfophoneType);
				if (crmCBRInfoisATTNumber != null)
					hmCbrInfo.put(CommonDefs.IS_ATT_NUMBER, crmCBRInfoisATTNumber);
				if (crmCBRInfodeviceInHandValidationSts != null)
					hmCbrInfo.put(CommonDefs.DEVICE_IN_HAND_VALIDATION_STS, crmCBRInfodeviceInHandValidationSts);
				if (crmCBRInfophoneModifiedDate != null)
					hmCbrInfo.put(CommonDefs.PHONE_MODIFIED_DATE, crmCBRInfophoneModifiedDate);
				if (crmCBRInfosubscriberId != null)
					hmCbrInfo.put(CommonDefs.SUBSCRIBER_ID, crmCBRInfosubscriberId);
				if (hmCbrInfo != null && !hmCbrInfo.isEmpty()) {
					outHs.put(CommonDefs.CBR_INFO, hmCbrInfo);
				}
				// putting AltcbrInfo as HashMap.
				HashMap<String, Object> hmAltCbrInfo = CommonUtil.getHashMap();
				if (crmAltCBRInfophone != null)
					hmAltCbrInfo.put(CommonDefs.PHONE, crmAltCBRInfophone);
				if (crmAltCBRInfophoneType != null)
					hmAltCbrInfo.put(CommonDefs.PHONE_TYPE, crmAltCBRInfophoneType);
				if (crmAltCBRInfoisATTNumber != null)
					hmAltCbrInfo.put(CommonDefs.IS_ATT_NUMBER, crmAltCBRInfoisATTNumber);
				if (crmAltCBRInfodeviceInHandValidationSts != null)
					hmAltCbrInfo.put(CommonDefs.DEVICE_IN_HAND_VALIDATION_STS, crmAltCBRInfodeviceInHandValidationSts);
				if (crmAltCBRInfophoneModifiedDate != null)
					hmAltCbrInfo.put(CommonDefs.PHONE_MODIFIED_DATE, crmAltCBRInfophoneModifiedDate);
				if (crmAltCBRInfosubscriberId != null)
					hmAltCbrInfo.put(CommonDefs.SUBSCRIBER_ID, crmAltCBRInfosubscriberId);
				if (hmAltCbrInfo != null && !hmAltCbrInfo.isEmpty()) {
					outHs.put(CommonDefs.ALT_CBR_INFO, hmAltCbrInfo);
				}
				// for email.
				if (crmEmail != null)
					outHs.put(CommonDefs.CONTACT_EMAIL, crmEmail);
				if (crmEmailValidity != null)
					outHs.put(CommonDefs.EMAIL_STATUS, crmEmailValidity);
				if (crmEmailEstablishDate != null)
					outHs.put(CommonDefs.EMAIL_ESTABLISH_DATE, crmEmailEstablishDate);

			}

			if (contactRole == null || !contactRole.trim().equalsIgnoreCase(CRM_ROLENAME_PRIMARY)) {
				sAppInfo = CRM_ROLENAME_PRIMARY + " Contact Details Unavailable in CLARIFY GetAuthInfo Response.";
				outHs = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
				log.info("{}{}PRNS27 : {}", SCLASSNAME, sMethodName, sAppInfo);
			}

		} catch (Exception e) {
			log.error("{}{}PRNSE0 : Exception occured {}", SCLASSNAME, sMethodName, e);
			sAppInfo = "Exception while parsing SOAP Response: " + e.toString();
			outHs = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
			log.error("{}{}PRNSE1 : {}", SCLASSNAME, sMethodName, sAppInfo);
		} finally {
			if (outHs == null || outHs.isEmpty()) {
				sAppInfo = "outHs within parseGetAuthInfoResponse is NULL";
				outHs = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				log.info("{}{}PRNSF1 : {}", SCLASSNAME, sMethodName, sAppInfo);
			}
		}
		return outHs;
	}

	private HashMap<String, Object> getProperties(){

		HashMap<String, Object> hmProperties = CommonUtil.getHashMap();
		String sMethodName="getProperties";

		hmProperties.put(RILDefs.CRMLS_GETAUTHINFO_URL, sPropCRMLSGetAuthInfoURL);
		hmProperties.put(RILDefs.CRMLS_GETAUTHINFO_CONNECT_TIMEOUT, sPropCRMLSGetAuthInfoConnectTimeout);
		hmProperties.put(RILDefs.CRMLS_GETAUTHINFO_READ_TIMEOUT, sPropCRMLSGetAuthInfoReadTimeout);
		hmProperties.put(RILDefs.CRMLS_GETAUTHINFO_METHOD_REQUEST, sPropCRMLSGetAuthInfoMethodRequest);
		hmProperties.put(RILDefs.PROP_CRMLS_GETAUTHINFO_NS_M1, sPropCRMLSGetAuthInfom1NS);
		hmProperties.put(RILDefs.PROP_CRMLS_GETAUTHINFO_PRE_M1, sPropCRMLSGetAuthInfom1NSPrefix);
		hmProperties.put(RILDefs.PROP_CRMLS_GETAUTHINFO_NS_M2, sPropCRMLSGetAuthInfom2NS);
		hmProperties.put(RILDefs.PROP_CRMLS_GETAUTHINFO_PRE_M2, sPropCRMLSGetAuthInfom2NSPrefix);
		hmProperties.put(RILDefs.PROP_CRMLS_GETAUTHINFO_NS_M3, sPropCRMLSGetAuthInfom3NS);
		hmProperties.put(RILDefs.PROP_CRMLS_GETAUTHINFO_PRE_M3, sPropCRMLSGetAuthInfom3NSPrefix);
		hmProperties.put(RILDefs.PROP_CRMLS_GETAUTHINFO_NS_M4, sPropCRMLSGetAuthInfom4NS);
		hmProperties.put(RILDefs.PROP_CRMLS_GETAUTHINFO_PRE_M4, sPropCRMLSGetAuthInfom4NSPrefix);
		hmProperties.put(RILDefs.PROP_CRMLS_GETAUTHINFO_NS_PWDTYPE, sPropCRMLSGetAuthInfoTypeNS);
		hmProperties.put(RILDefs.PROP_CRMLS_GETAUTHINFO_TYPE_PASSWORDTOKEN, sPropCRMLSGetAuthInfoPasswordType);
		hmProperties.put(RILDefs.PROP_CRMLS_GETAUTHINFO_TYPE_USERNAMETOKEN, sPropCRMLSGetAuthInfoUserNameTokenType);
		hmProperties.put(RILDefs.PROP_CRMLS_GETAUTHINFO_CLARIFY_SBCUID, sPropCRMLSGetAuthInfoSbcUID);
		hmProperties.put(RILDefs.CRMLS_GETAUTHINFO_LOGIN_NAME, sPropCRMLSGetAuthInfoLoginName);
		hmProperties.put(RILDefs.CRMLS_GETAUTHINFO_PASSWORD, CommonUtil.getAESDecryption(sPropCRMLSGetAuthInfoPassword));
		hmProperties.put(RILDefs.CRMLS_GETAUTHINFO_APPLICATION_ID, sPropCRMLSGetAuthInfoApplicationId);
		// FEB 2014 - Updated for PID# 268073
		hmProperties.put(RILDefs.LSCRM_SECURITY_HEADER_USER, sPropLSCRMSecurityHeaderUser);
		hmProperties.put(RILDefs.LSCRM_SECURITY_HEADER_PASSWORD, CommonUtil.getAESDecryption(sPropLSCRMSecurityHeaderPassword));

		log.debug("{}{}GP1 : value in config-file : {}", SCLASSNAME, sMethodName, hmProperties);

		return hmProperties;

	}
}