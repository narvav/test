package com.att.idp.idgraphcontactinfoms.resource.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Optional;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import com.att.idp.cd.observability.metrics.utils.Constants;
import com.att.mpsys.common.helpers.FeatureManagerHelper;
import com.att.mpsys.common.utils.CommonDefs;
import jakarta.validation.Valid;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;

import com.att.idp.core.exception.ServiceException;
import com.att.idp.idgraphcontactinfoms.request.validator.CPNIContactInfoRequestValidator;
import com.att.idp.idgraphcontactinfoms.resource.response.CPNIContactInfoResponse;
import com.att.idp.idgraphcontactinfoms.service.CPNIContactInfoService;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.NestedExceptionUtils;

import com.att.idp.idgraphcontactinfoms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphcontactinfoms.exceptions.MPSException;
import com.att.idp.idgraphcontactinfoms.request.validator.QueryCPNIAcccountContactInfoRequestValidator;
import com.att.idp.idgraphcontactinfoms.request.validator.QueryCPNIUserContactInfoRequestValidator;
import com.att.idp.idgraphcontactinfoms.resource.CPNIContactInfoResource;
import com.att.idp.idgraphcontactinfoms.resource.request.QueryCPNIAccountContactInfoRequest;
import com.att.idp.idgraphcontactinfoms.resource.request.QueryCPNIUserContactInfoRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.QueryCPNIAccountContactInfoResponse;
import com.att.idp.idgraphcontactinfoms.resource.response.QueryCPNIUserContactInfoResponse;
import com.att.idp.idgraphcontactinfoms.service.QueryCPNIAccountContactInfoService;
import com.att.idp.idgraphcontactinfoms.service.QueryCPNIUserContactInfoService;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.idp.idgraphcontactinfoms.utils.QueryCPNIUserContactInfoResponseGenerator;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import static org.apache.commons.text.StringEscapeUtils.escapeJava;
import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_75;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_90;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_95;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_99;
import static com.att.idp.cd.observability.metrics.utils.Constants.POST;
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_IB;
import static com.att.idp.idgraphcontactinfoms.utils.Constants.IDGRAPH_CONTACT_INFO_MS_IB;

/**
 * This class is the implementation of the CPNIContactInfoResource interface.
 *
 * It is responsible for handling the CPNI (Customer Proprietary Network Information) contact information requests.
 * The class has two main methods: queryCPNIAccountContactInfo and queryCPNIUserContactInfo.
 * Each of these methods takes specific request objects and HttpHeaders as input and returns a Response.
 * These methods are responsible for querying the CPNI contact information for an account and a user respectively.
 *
 * The class has dependencies on QueryCPNIAccountContactInfoService, QueryCPNIAcccountContactInfoRequestValidator,
 * QueryCPNIUserContactInfoService, QueryCPNIUserContactInfoRequestValidator which are autowired.
 * It also has a Logger instance for logging.
 *
 * The class is annotated with @ApiImplicitParams to provide metadata about the API such as the API's name, path, operations, responses.
 */
@OpenAPIDefinition(
		info = @Info(title="Contact Info",
				description="IDGraphContactInfoMs supports multiple functions.  " +
						"This application provides APIs that support multiple functions including returning CPNI " +
						"eligible contact methods for accessId, wireless, enabler and wireline accounts, OTP generation," +
						" validation and deletion.\n.", version="0.0.1"),
		servers = {
				@Server(url="https://apporigin-dev2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphcontactinfoms/"),
				@Server(url="https://apporigin-tst2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphcontactinfoms/")
		})
public class CPNIContactInfoResourceImpl implements CPNIContactInfoResource {

	public static final Logger logger = LoggerFactory.getLogger(CPNIContactInfoResourceImpl.class);
	
	@Autowired
	private QueryCPNIAccountContactInfoService queryCPNIAccountContactInfoService;
	
	@Autowired 
	private QueryCPNIAcccountContactInfoRequestValidator queryCPNIAcccountInfoRequestValidator;
	
	@Autowired
	private QueryCPNIUserContactInfoService queryCPNIUserContactInfoService;

	@Autowired
	private CPNIContactInfoService cpniContactInfoService;
	
	@Autowired
	private QueryCPNIUserContactInfoRequestValidator queryCPNIUserContactInfoRequestValidator;

	@Autowired
	private CPNIContactInfoRequestValidator cpniContactInfoRequestValidator;

    @Autowired
    private FeatureManagerHelper featureManager;

	@Override
	@TimedMetrics(name = IDGRAPH_CONTACT_INFO_MS_IB, type = REST_IB, description = "Query account contact info",
			tags = { Constants.URI , "/v1/cpniContactInfo/account", METHOD, POST}, histogram = true, percentiles =
			{PERCENTILE_75, PERCENTILE_90, PERCENTILE_95, PERCENTILE_99})
	public Response queryCPNIAccountContactInfo(
			@Valid QueryCPNIAccountContactInfoRequest queryCPNIAccountContactInfoRequest, HttpHeaders httpHeader)
			throws MPSException {
		
		QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse = null;
		long startTm = System.currentTimeMillis();
		Response responseObj = null;
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		try {

			MultivaluedMap<String, String> requestHeader = httpHeader.getRequestHeaders();

			logger.info(SpiMarker.getInstance(),"WEB_01 : QueryCPNIAccountContactInfo Input : {} | QueryCPNIAccountContactInfo Request Header  : {}", queryCPNIAccountContactInfoRequest, CommonUtilHelper.objectToString(requestHeader));

			queryCPNIAccountContactInfoResponse = queryCPNIAcccountInfoRequestValidator.queryCPNIAccountContactRequestValidator(httpHeader, queryCPNIAccountContactInfoRequest);
    
			logger.info(SpiMarker.getInstance(),"WEB000 : QueryCPNIAccountContactInfo Input : {}", queryCPNIAccountContactInfoRequest);
			
			if (queryCPNIAccountContactInfoResponse == null) {
				// call the service class
				queryCPNIAccountContactInfoResponse = queryCPNIAccountContactInfoService.queryCPNIAccountContactInfo(queryCPNIAccountContactInfoRequest,requestHeader);
				logger.info("WEB_02 : QueryCPNIAccountContactInfo Service Response : {}", queryCPNIAccountContactInfoResponse);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: {}", e.getMessage());
				throw e;
			}
			else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
            }
			else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			}	
			
			hmResponse.put("idp-trace-id", queryCPNIAccountContactInfoRequest.getIdpTraceId());
			queryCPNIAccountContactInfoResponse = CommonUtilHelper.queryCPNIAccountContactInfoResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(queryCPNIAccountContactInfoResponse);
		String sTimeTaken = getElapsedTimeInSecs(startTm) + " seconds";

		logger.info("WEB999 : Total time taken : {} QueryCPNIAccountContactInfo Response : {}",sTimeTaken, queryCPNIAccountContactInfoResponse);
		return responseObj;
	}
	
	@Override
	public Response queryCPNIUserContactInfo(
			@Valid QueryCPNIUserContactInfoRequest queryCPNIUserContactInfoRequest, HttpHeaders httpHeader)
			throws MPSException {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		QueryCPNIUserContactInfoResponse queryCPNIUserContactInfoResponse = null;
		long startTm = System.currentTimeMillis();
		Response responseObj = null;
		
		try {
			MultivaluedMap<String, String> requestHeader = httpHeader.getRequestHeaders();

			logger.info(SpiMarker.getInstance(), "WEB_01 : QueryCPNIUserContactInfo Input : {} | QueryCPNIAccountContactInfo Request Header  : {}",
					queryCPNIUserContactInfoRequest != null ?  escapeJava(queryCPNIUserContactInfoRequest.toString()):null,
                    escapeJava(CommonUtilHelper.objectToString(requestHeader)));

			queryCPNIUserContactInfoResponse = queryCPNIUserContactInfoRequestValidator.queryCPNIUserContactInfoRequestValidator(httpHeader, queryCPNIUserContactInfoRequest);
    
			logger.info("WEB000 : QueryCPNIUserContactInfo Input : {}", queryCPNIUserContactInfoRequest);
			
			if (queryCPNIUserContactInfoResponse == null) {
				// call the service class
				queryCPNIUserContactInfoResponse = queryCPNIUserContactInfoService.queryCPNIUserContactInfo(queryCPNIUserContactInfoRequest, requestHeader);
				logger.info("WEB_02 : QueryCPNIUserContactInfo Service Response : {}", queryCPNIUserContactInfoResponse);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: {}", e.getMessage());
				throw e;
			}
			else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
            }
			else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			}	
			hmResponse.put("idp-trace-id", queryCPNIUserContactInfoRequest.getIdpTraceId());
			queryCPNIUserContactInfoResponse = QueryCPNIUserContactInfoResponseGenerator
					.getQueryCPNIUserContactInfoResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(queryCPNIUserContactInfoResponse);
		String sTimeTaken = getElapsedTimeInSecs(startTm) + " seconds";

		logger.info("WEB999 : Total time taken : {} QueryCPNIUserContactInfo Response : {}",sTimeTaken, queryCPNIUserContactInfoResponse);
		return responseObj;
	}

	/**
	 * Handles the CPNI contact info request.
	 *
	 * Validates the request headers and processes the CPNI contact information request.
	 * If validation passes, calls the service layer
	 * Handles exceptions and builds a standardized response.
	 *
	 * @param cpniContactInfoRequestHeader the HTTP headers for the request
	 * @return a JAX-RS Response containing the CPNI contact info response
	 * @throws MPSException if an error occurs during processing
	 */
	@Override
	public Response cpniContactInfo(HttpHeaders cpniContactInfoRequestHeader) throws Exception {
		{
			Map<String, Object> hmResponse = CommonUtil.getHashMap();
			CPNIContactInfoResponse cpniContactInfoResponse = null;
			long startTm = System.currentTimeMillis();
			Response responseObj = null;

            boolean isIndividualIdInResEnabled = featureManager.isEnabled("svc-idgraph-cpnicontactinfo-enable-individualid-in-response");
            logger.info("CPNIContactInfo : ixp flag svc-idgraph-cpnicontactinfo-enable-individualid-in-response = {}", isIndividualIdInResEnabled);

			try {
				MultivaluedMap<String, String> requestHeader = cpniContactInfoRequestHeader.getRequestHeaders();

                if(isIndividualIdInResEnabled) {
                    requestHeader.put("isIndividualIdInResEnabled", java.util.Arrays.asList(CommonDefs.IND_Y.toString()));
                }

				logger.info(SpiMarker.getInstance(), "WEB_01 : CPNIContactInfo Request Header  : {}", CommonUtilHelper.sanitizeForLog(CommonUtilHelper.objectToString(requestHeader)));

				cpniContactInfoResponse = cpniContactInfoRequestValidator.cpniContactInfoRequestValidator(cpniContactInfoRequestHeader);

				logger.info("WEB000 : CPNIContactInfo Input Request : {}", StringEscapeUtils.escapeJava(cpniContactInfoRequestHeader.toString() ));

				if (cpniContactInfoResponse == null) {
					cpniContactInfoResponse = cpniContactInfoService.cpniContactInfo(requestHeader);
					logger.info("WEB_02 : CPNIContactInfo Service Response : {}", cpniContactInfoResponse);
				}
			} catch(ServiceException e) {
				logger.error("ServiceException: {}", e.getMessage());
				cpniContactInfoResponse = new CPNIContactInfoResponse();
				String stIdpTraceId =Optional.ofNullable(cpniContactInfoRequestHeader.getHeaderString("idp-trace-id")).orElse(CommonUtilHelper.getTraceIdFromContextMap());
				cpniContactInfoResponse.setIdpTraceId(stIdpTraceId);
				cpniContactInfoResponse.setErrors(e.getError());
				return Response.status(e.getHttpCode()).entity(cpniContactInfoResponse).build();

			}catch (Exception e) {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
				hmResponse.put("idp-trace-id", cpniContactInfoRequestHeader.getHeaderString("idp-trace-id"));
				cpniContactInfoResponse = CommonUtilHelper.cpniContactInfoResponse(hmResponse);
			}
			responseObj = CommonUtilHelper.buildMSResponse(cpniContactInfoResponse);
			String sTimeTaken = getElapsedTimeInSecs(startTm) + " seconds";

			logger.info("WEB999 : Total time taken : {} CPNIContactInfo Response : {}",sTimeTaken, cpniContactInfoResponse);
			return responseObj;
		}
	}


	/**
	 * 
	 * @param startTime
	 * @return
	 */
	private String getElapsedTimeInSecs(long startTime) {

		StringBuffer sElapsedTime = new StringBuffer();

		long diff = (System.currentTimeMillis() - startTime);
		long ms = diff % 1000;

		sElapsedTime.append(diff / 1000).append('.'); // secs.

		if (ms < 10)
			sElapsedTime.append("00").append(ms); // 3 digits ms 0 padded
		else if (ms < 100)
			sElapsedTime.append('0').append(ms);
		else
			sElapsedTime.append(ms);

		return sElapsedTime.toString();
	}
	

}


