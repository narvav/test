package com.att.idp.idgraphcontactinfoms.service.impl;

import java.util.Map;
import java.util.Random;

import jakarta.ws.rs.core.MultivaluedMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.idp.idgraphcontactinfoms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphcontactinfoms.helpers.InquirePINHelper;
import com.att.idp.idgraphcontactinfoms.resource.request.InquirePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.InquirePINResponse;
import com.att.idp.idgraphcontactinfoms.service.InquirePINService;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;


@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class InquirePINServiceImpl implements InquirePINService {

	@Autowired
	private InquirePINHelper inquirePINHelper;

	public static final Logger logger = LoggerFactory.getLogger(InquirePINServiceImpl.class);

	private static String sClassName = "InquirePINServiceImpl";

	@Override
	public InquirePINResponse inquirePIN(InquirePINRequest inquirePINRequest,
			MultivaluedMap<String, String> requestHeader) {

		Map<String, Object> hmInput = null;
		Map<String, Object> hmResponse = null;
		String sMethodName = ".InquirePIN.";

		hmInput = CommonUtilHelper.objectToMap(inquirePINRequest);
		
		logger.debug(SpiMarker.getInstance(),
				"InquirePINServiceImpl.InquirePIN.IPS_1.3 : Calling InquirePINHelper with Input : {}",
				StructuredArguments.entries(hmInput));

		hmResponse = inquirePINHelper.inquirePIN(hmInput);

		logger.info(SpiMarker.getInstance(),"InquirePINServiceImpl.InquirePIN.IPS_02 : Response from InquirePin Helper : {}", StructuredArguments.entries(hmInput));

		if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
			hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from InquirePINHelper.InquirePin");
			logger.info("{}{}IPS_03 : Null response from InquirePINHelper.InquirePin", sClassName, sMethodName);
		} else {
			String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (stAppStatusCode == null) {
				hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from InquirePINHelper.InquirePin");
				logger.info("{}{}IPS_04 : Null response from InquirePINHelper.InquirePin", sClassName, sMethodName);
			}
		}

		hmResponse.put("idp-trace-id", inquirePINRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME, inquirePINRequest.getTransactionName());

		InquirePINResponse InquirePINResponse = (InquirePINResponse) CommonUtilHelper
				.inquirePinResponse(hmResponse);

		logger.info(SpiMarker.getInstance(),"InquirePINServiceImpl.InquirePIN.IPS_05 : Response from InquirePINServiceImpl.InquirePIN : {}",
				InquirePINResponse);
		return InquirePINResponse;
	}
	
}
