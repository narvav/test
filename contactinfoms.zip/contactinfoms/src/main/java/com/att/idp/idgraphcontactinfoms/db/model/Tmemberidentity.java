package com.att.idp.idgraphcontactinfoms.db.model;

import java.sql.Date;
import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "TMEMBERIDENTITY", schema = "MPS_OWNER")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tmemberidentity implements java.io.Serializable {

	private static final long serialVersionUID = 2147780168388485936L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "memberNum", column = @Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "identity", column = @Column(name = "IDENTITY", nullable = false))
	})
	private TmemberidentityId id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MEMBER_NUM", nullable = false, insertable = false, updatable = false)
	private Tmember tmember;

	@Column(name = "IDENTITY_TYPE", nullable = false, length = 30)
	private String identityType;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;
}