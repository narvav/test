package com.att.idp.idgraphcontactinfoms.resource.request;

import static org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString;
import static org.apache.commons.lang3.builder.ToStringStyle.JSON_STYLE;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.request package.
 *
 * The class implements the Serializable interface, allowing instances of this class to be converted into a byte stream.
 *
 * The AttributeList class is used to represent a list of attributes, each of which has a name and a value.
 * The attributeName and attributeValue fields are annotated with @NotNull and @Size, indicating that they are required fields and have size constraints.
 *
 * The class also contains a map of unknownAttributes, which can be used to store any additional attributes that are not part of the attributeName and attributeValue fields.
 * The unknownAttributes map is annotated with @JsonAnySetter and @JsonAnyGetter, allowing it to be included in JSON serialization and deserialization.
 *
 * The class provides a toString method, which returns a string representation of the object using reflection.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Schema(name = "AttributeList")
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class AttributeList implements Serializable{

	@NotNull(message="attributeName is required field in input request.|GeneratePIN")
    @Size(min=1, max=100,message="attributeName length is invalid|GeneratePIN")
    protected String attributeName;
	
	@NotNull(message="attributeValue is required field in input request.|GeneratePIN")
    @Size(min=1, max=100,message="attributeValue length is invalid|GeneratePIN")
    protected String attributeValue;

	/**
	 * This field represents a map of unknown attributes.
	 *
	 * The unknownAttributes map is used to store any additional attributes that are not part of the attributeName and attributeValue fields.
	 * It is initialized as a new HashMap.
	 *
	 * The field is annotated with @JsonAnySetter and @JsonAnyGetter, allowing it to be included in JSON serialization and deserialization.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();


	@Override
    public String toString() {
        return reflectionToString(this, JSON_STYLE);
    }
}
