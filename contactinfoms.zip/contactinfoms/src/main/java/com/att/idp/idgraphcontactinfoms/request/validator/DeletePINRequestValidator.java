package com.att.idp.idgraphcontactinfoms.request.validator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import jakarta.ws.rs.core.HttpHeaders;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphcontactinfoms.message.ErrorMessages;
import com.att.idp.idgraphcontactinfoms.resource.request.DeletePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.DeletePinResponse;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;

/**
 * This class is responsible for validating the DeletePINRequest.
 *
 * It uses the Spring Framework's @Configuration and @PropertySource annotations to indicate that it is a source of bean definitions and to load properties from a specified location.
 *
 * The class has several instance variables that are injected using the @Value annotation.
 * These variables are used to store configuration values such as the valid PIN CSI and PIN agent CSI.
 *
 * The main method in this class is the deletePINRequestValidator method, which takes HttpHeaders and a DeletePINRequest as input and returns a DeletePinResponse.
 * The deletePINRequestValidator method performs various checks on the input parameters and calls other private methods for further validation.
 *
 * The class also contains several private methods for validating the input parameters and constructing an error response.
 *
 * The class also contains a logger for logging information and error messages.
 */
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class DeletePINRequestValidator {

	private static final Logger logger = LoggerFactory.getLogger(DeletePINRequestValidator.class);

	private String sClassName = "DeletePINRequestValidator";

	@Value("${PROP_PIN_CSI}")
	private String propValidPINIDENTypeAndCSI;

	@Value("${PROP_PIN_AGENT_CSI}")
	private String propPINAgentCSI;

	
	/**
	 * This method is responsible for validating the DeletePINRequest.
	 *
	 * It takes HttpHeaders and a DeletePINRequest as input parameters and returns a DeletePinResponse.
	 * The method performs various checks on the input parameters and calls other private methods for further validation.
	 * If the validation is successful, the method returns a DeletePinResponse. If the validation fails, the method constructs an error response and returns it.
	 *
	 * The method also handles exceptions that can occur during the validation process.
	 *
	 * @param requestHeader HttpHeaders that contains the request headers. These headers are used for logging and tracing purposes.
	 * @param deletePINRequest DeletePINRequest that contains the request data for the delete PIN operation. This data is validated by the method.
	 * @return a DeletePinResponse that contains the result of the validation. If the validation is successful, the response contains a success message. If the validation fails, the response contains an error message.
	 */
	public DeletePinResponse deletePINRequestValidator(HttpHeaders requestHeader, DeletePINRequest deletePINRequest) {

		DeletePinResponse deletePINResponse = null;

		String stAppInfo = null;
		String sMethodName = ".deletePINRequestValidator.";
		String stIdpTraceId = null;
		String stTransactionId = null;
		String stXAttClientId = null;

		stIdpTraceId = CommonUtil.getTraceId(requestHeader);
		if (deletePINRequest != null) {
			
			if(stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
				stAppInfo="DeletePIN Request idp-trace-id is missing";
				return deletePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
			deletePINRequest.setIdpTraceId(stIdpTraceId);
			
			String stCallingSystemId = deletePINRequest.getCallingSystemId();
			Optional.ofNullable(stCallingSystemId)
			.ifPresent(x -> deletePINRequest.setCallingSystemId(x.trim().toUpperCase()));
			
			if (stCallingSystemId == null && requestHeader.getHeaderString("X-ATT-ClientId") != null) {
				stXAttClientId = requestHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
				logger.info("{}{}DPRV_101.2 : Setting callingSystemId: {}", sClassName, sMethodName,stXAttClientId);
				deletePINRequest.setCallingSystemId(stXAttClientId.trim().toUpperCase());
			}
			
		}

		if (deletePINRequest == null) {
			stAppInfo = "Input Request Parameter is NULL / Empty.";
			logger.info("{}{}DPRV_102 :: {}", sClassName, sMethodName, stAppInfo);
			return deletePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		// checking Invalid attributes passed in Request
		Map<String, Object> allUnknownAttributes = new HashMap<>(deletePINRequest.unknownAttributes);

		if (!allUnknownAttributes.isEmpty()) {
			stAppInfo = "Invalid Attributes passed in deletePINRequest : " + allUnknownAttributes;
			return deletePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					deletePINRequest.getIdpTraceId());
		}
		try {

			deletePINResponse = deletePINRequestValidatorInputValidator(deletePINRequest);

			if (deletePINResponse != null) {
				logger.info("{}{}DPRV_103 Response from DeletePINRequestValidator : {}", sClassName, sMethodName,
						deletePINResponse);
				return deletePINResponse;
			} else {
				logger.info("{}{}DPRV_104 Success Response from DeletePINRequestValidator ", sClassName, sMethodName);
			}

			deletePINResponse = deletePINRequestCSIValidator(deletePINRequest);

			if (deletePINResponse != null) {
				logger.info("{}{}DPRV_105 Response from deletePINRequestCSIValidator : {}", sClassName, sMethodName,
						deletePINResponse);
				return deletePINResponse;
			} else {
				logger.info("{}{}DPRV_106 Success Response from deletePINRequestCSIValidator ", sClassName,
						sMethodName);
			}
			stAppInfo = "Input Validation Successful";
			logger.info("{}{}DPRV_107 : {}", sClassName, sMethodName, stAppInfo);
		} catch (Exception e) {
			stAppInfo = "Exception thrown in DeletePINRequestValidator.deletePINRequestValidator : " + e.getMessage();
			deletePINErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo, stIdpTraceId);
			logger.info("{}{}DPRV_108 : Exception in DeletePINRequestValidator: {}", sClassName, sMethodName, stAppInfo);
		}
		return deletePINResponse;
	}

	private DeletePinResponse deletePINRequestCSIValidator(DeletePINRequest deletePINRequest) {
		DeletePinResponse deletePINResonse=null;
		String stAppInfo = null;
		String sMethodName = ".deletePINRequestCSIValidator.";
		String stCallingSystemID = deletePINRequest.getCallingSystemId();
		String stIdentificationType = deletePINRequest.getIdentificationType();
		//String stTransactionId = deletePINRequest.getTransactionId();
		String stIdpTraceId = deletePINRequest.getIdpTraceId();
		String stAgentID = deletePINRequest.getAgentId();
		

		logger.info("{}{}DPRV_104.1 : Property PROP_PIN_CSI ::  {}", sClassName, sMethodName, propValidPINIDENTypeAndCSI);
		
		if (propValidPINIDENTypeAndCSI == null || propValidPINIDENTypeAndCSI.isEmpty()) {

			stAppInfo = "PROP_PIN_CSI  property is not configured in the properties file";

			return deletePINErrorResponse(CErrorDefs.ERR_CONFIG_NUM, stAppInfo, stIdpTraceId);
		}

		HashMap hmIdenCSIValidCombination = CommonUtil.parseMultiDelimiterProperty(propValidPINIDENTypeAndCSI);

		if (!hmIdenCSIValidCombination.containsKey(stIdentificationType)) {

			stAppInfo = "Input IdentificationType is not valid for CallingSystemId :" + stCallingSystemID;

			return deletePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);

		}

		ArrayList<String> alValidCSIforIden = (ArrayList) hmIdenCSIValidCombination.get(stIdentificationType);

		if (alValidCSIforIden != null && !alValidCSIforIden.contains(stCallingSystemID)) {
			stAppInfo = " Input X-ATT-ClientId or CallingSystemID  is not valid for IdentificationType :" + stIdentificationType;
			//stAppInfo = "Missing or invalid X-ATT-ClientId in request header";
			return deletePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		logger.info("{}{}DPRV_104.2 : Property PROP_PIN_AGENT_CSI ::  {}", sClassName, sMethodName, propPINAgentCSI);
		
		ArrayList alValidPinAgentCSI = null;

		if (propPINAgentCSI != null && !propPINAgentCSI.isEmpty()) {

			alValidPinAgentCSI = new ArrayList<String>(Arrays.asList(propPINAgentCSI.split("\\|")));
		}

		if (alValidPinAgentCSI != null && alValidPinAgentCSI.contains(stCallingSystemID)) {

			if (stAgentID == null || stAgentID.isEmpty()) {

				stAppInfo = "AgentId is required";
				logger.info("{}{}DPRV_104.3 : {}", sClassName, sMethodName, stAppInfo);
				return deletePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
		}
		return deletePINResonse;
	}

	private DeletePinResponse deletePINRequestValidatorInputValidator(DeletePINRequest deletePINRequest) {
		DeletePinResponse deletePINResponse = null;

		String stAppInfo = null;
		String sMethodName = ".deletePINRequestValidatorInputValidator.";
//		String stTransactionId = deletePINRequest.getTransactionId();
		String stTransactionName = deletePINRequest.getTransactionName();
		String stCallingSystemID = deletePINRequest.getCallingSystemId();
		String stIdentificationType = deletePINRequest.getIdentificationType();
		String stAccountID = deletePINRequest.getAccountId();
		String stDeleteAll = deletePINRequest.getDeleteAll();
		String stIdpTraceId = deletePINRequest.getIdpTraceId();

		if (stTransactionName == null || stTransactionName.isEmpty()) {

			stAppInfo = "TransactionName can not be null / empty.";
			logger.info("{}{}DPRV_102.2 : {}", sClassName, sMethodName, stAppInfo);
			return deletePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (stCallingSystemID == null || stCallingSystemID.isEmpty()) {
			stAppInfo = "Either X-ATT-ClientId in request header or callingSystemId in request body must be present";
			logger.info("{}{}DPRV_102.3 : {}", sClassName, sMethodName, stAppInfo);
			return deletePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (stIdentificationType == null || stIdentificationType.isEmpty()) {

			stAppInfo = "IdentificationType can not be null / empty.";
			logger.info("{}{}DPRV_102.4 : {}", sClassName, sMethodName, stAppInfo);
			return deletePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (stAccountID == null || stAccountID.isEmpty()) {

			stAppInfo = "AccountID can not be null / empty.";
			logger.info("{}{}DPRV_102.5 : {}", sClassName, sMethodName, stAppInfo);
			return deletePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (stDeleteAll == null || stDeleteAll.isEmpty()) {

			stAppInfo = "DeleteAll can not be null / empty.";
			logger.info("{}{}DPRV_102.6 : {}", sClassName, sMethodName, stAppInfo);
			return deletePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		deletePINRequest.setAccountId(stAccountID.trim().toLowerCase());
		deletePINRequest.setIdentificationType(stIdentificationType.trim().toUpperCase());

		if (!"DeletePIN".equals(stTransactionName)) {
			stAppInfo = "Transaction Not Allowed :: TransactionName Should be DeletePIN";
			logger.info("{}{}DPRV_102.7 : {}", sClassName, sMethodName, stAppInfo);
			return deletePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		Optional.ofNullable(deletePINRequest.getSecurityCode())
				.ifPresent(x -> deletePINRequest.setSecurityCode(x.trim()));

		Optional.ofNullable(deletePINRequest.getAgentId())
				.ifPresent(x -> deletePINRequest.setAgentId(x.trim().toLowerCase()));

		Optional.ofNullable(deletePINRequest.getReasonCode())
				.ifPresent(x -> deletePINRequest.setReasonCode(x.trim().toUpperCase()));
		
		stDeleteAll = stDeleteAll.toUpperCase();
		if (!CommonDefs.IND_Y.equalsIgnoreCase(stDeleteAll) && !CommonDefs.IND_N.equalsIgnoreCase(stDeleteAll)) {

			stAppInfo = "DeleteAll should be either Y or N";
			logger.info("{}{}DPRV_102.8 : {}", sClassName, sMethodName, stAppInfo);
			return deletePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		deletePINRequest.setDeleteAll(stDeleteAll);

		return deletePINResponse;
	}

	private DeletePinResponse deletePINErrorResponse(int appStatusCode, String stAppInfo, String stIdpTraceId) {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
//		hmResponse.put(CommonDefs.TRANSACTION_ID, transactionId);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		//hmResponse.put("ErrorEnum", errorEnum);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		hmResponse.put(CommonDefs.TRANSACTION_NAME, "DeletePIN");
		return (DeletePinResponse) CommonUtilHelper.generateCIRResponse(hmResponse);
	}

}
