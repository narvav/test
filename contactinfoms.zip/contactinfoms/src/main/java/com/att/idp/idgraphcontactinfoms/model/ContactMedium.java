package com.att.idp.idgraphcontactinfoms.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;

/**
 * The class ContactMedium
 *
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "mediumType",
        "preferred",
        "characteristic"
})
@Schema(name = "ContactMedium")
public class ContactMedium implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The mediumType. */
    @JsonProperty("mediumType")
    private String mediumType;

    /** The preferred. */
    @JsonProperty("preferred")
    private Boolean preferred;

    /** The characteristic. */
    @JsonProperty("characteristic")
    private Characteristic characteristic;
}
