package com.att.idp.idgraphcontactinfoms.resource.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.response package.
 *
 * The USPhoneNumber class is used to represent a US phone number.
 * It contains three fields: generalContactDetails, phoneNumber, and phoneNumberType.
 *
 * The generalContactDetails field is an object of the GeneralContactDetails class, representing general contact details associated with the US phone number.
 * The phoneNumber field is a string representing the phone number.
 * The phoneNumberType field is a string representing the type of the phone number.
 *
 * Each field has a corresponding getter and setter method, allowing the fields to be accessed and modified.
 * The setter method for generalContactDetails is annotated with @JsonProperty, indicating the JSON property name to be used during serialization and deserialization.
 *
 * The class overrides the toString method, providing a custom string representation of the object.
 */
@Data
public class USPhoneNumber {

	private GeneralContactDetails generalContactDetails;
	private String phoneNumber;
	private String phoneNumberType;

	@JsonProperty("GeneralContactDetails")
	public void setGeneralContactDetails(GeneralContactDetails generalContactDetails) {
		this.generalContactDetails = generalContactDetails;
	}
}