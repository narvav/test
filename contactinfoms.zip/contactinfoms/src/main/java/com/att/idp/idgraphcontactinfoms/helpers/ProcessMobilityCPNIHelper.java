package com.att.idp.idgraphcontactinfoms.helpers;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Optional;
import java.util.TimeZone;

import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphcontactinfoms.utils.Constants;
import com.att.idp.idgraphcontactinfoms.utils.JsonService;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import com.fasterxml.jackson.databind.node.ArrayNode;

/**
 * This class is a helper class for processing Mobility CPNI.
 *
 * It contains methods for processing Mobility CPNI based on the input parameters.
 * The class uses the Spring Framework's @Component annotation to indicate that it is a bean and can be used for dependency injection.
 *
 * The class has an instance variable oCPNIConsolidationHelper that is injected using the @Autowired annotation.
 * This variable is used to interact with the CPNIConsolidationHelper to process Mobility CPNI.
 *
 * The main method in this class is the processMobilityCPNI method, which takes two HashMaps as input and returns a HashMap as output.
 * The processMobilityCPNI method uses several other methods in the class to validate the input data, process the input data, and store the data.
 *
 * The class also contains a logger for logging information and error messages.
 */
@Component
public class ProcessMobilityCPNIHelper {

	private static String sClassName = "ProcessMobilityCPNIHelper";
	public static final Logger logger = LoggerFactory.getLogger(ProcessMobilityCPNIHelper.class);

	@Autowired
	private CPNIDataConsolidationHelper oCPNIConsolidationHelper;

	/**
	 * This method processes Mobility CPNI based on the input parameters.
	 *
	 * It first validates the input data. If the input data is invalid, the method constructs an error response and returns it.
	 * If the input data is valid, the method processes the input data and makes a call to the CPNIDataConsolidationHelper to process Mobility CPNI.
	 * The method then checks the response from the CPNIDataConsolidationHelper. If the response indicates an error, the method constructs an error response and returns it.
	 * If the response from the CPNIDataConsolidationHelper indicates success, the method constructs a success response and returns it.
	 *
	 * @param hmInput a HashMap that contains the input data for the Mobility CPNI processing. The HashMap should include the transaction ID, transaction name, GUID, and calling system ID.
	 * @param hmIAPResponse a HashMap that contains the IAP response data. The HashMap should include the application status code, application info message, and the user contact information.
	 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code, an application info message, and the processed Mobility CPNI data.
	 * @throws Exception if an error occurs during the operation.
	 */
	public HashMap processMobilityCPNI(HashMap hmInput, HashMap hmIAPResponse) {
		String sMethodName = ".processMobilityCPNI.";
		HashMap<String, Object> hmResult = null;
		String stAppInfo = null;
		String stAppStatusCode = null;
		String stAppCatogoryCode = null;
		HashMap<String, Object> hmCPNIConResponse = CommonUtil.getHashMap();

		logger.info("{}{}HLP000 : Input Hash : {}", sClassName, sMethodName, hmInput);

		if (hmInput == null || hmInput.isEmpty()) {
			stAppInfo = "Input Hash is null or empty";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			logger.info("{}{}MOB_CPNI_H_01 : {}", sClassName, sMethodName, stAppInfo);
			return hmResult;
		}

		try {


			if (hmIAPResponse == null) {
				stAppInfo = "Null IAPResponse";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}MOB_CPNI_H_04 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			stAppStatusCode = (String) hmIAPResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
			stAppCatogoryCode = (String) hmIAPResponse.get(CommonDefs.COMMON_APP_CATEGORY_CODE);

			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				if (stAppCatogoryCode != null && stAppCatogoryCode.equals(CErrorDefs.CATEGORY_CODE_SYSTEM_ERROR)) {
					stAppInfo = (String) hmIAPResponse.get(CommonDefs.COMMON_APP_INFO);
					logger.info("{}{}MOB_CPNI_H_05 : {}", sClassName, sMethodName, ESAPI.encoder().encodeForHTML(stAppInfo));
					hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
					return hmResult;
				} else {
					stAppInfo = "Account Not found in DB.";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ACCOUNT_NOT_FOUND_NUM,
							CErrorDefs.ERR_ACCOUNT_NOT_FOUND_MSG);
					logger.info("{}{}MOB_CPNI_H_06 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}
			}

			String sCheckSMS = (String) hmInput.get("checkSMS");
			Boolean bCheckSMS = false;

			if (sCheckSMS == null || sCheckSMS.isEmpty() || sCheckSMS.equalsIgnoreCase(MPSDefs.YES))
				bCheckSMS = true;
			else if (sCheckSMS.equalsIgnoreCase(MPSDefs.NO))
				bCheckSMS = false;

			HashMap<String, Object> hmCPNIConsHelperInput = CommonUtil.getHashMap();
			hmCPNIConsHelperInput.put(CommonDefs.TRANSACTION_NAME, (String) hmInput.get(CommonDefs.TRANSACTION_NAME));
			hmCPNIConsHelperInput.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(CommonDefs.TRANSACTION_ID));
			hmCPNIConsHelperInput.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
			hmCPNIConsHelperInput.put("NewCPNIEilibilityRule", MPSDefs.YES);
			hmCPNIConsHelperInput.put(CommonDefs.KEY_ACCOUNT_STATUS_CHECK, CommonDefs.IND_N);

			HashMap hmAcctProfResponse = CommonUtil.getMap(hmIAPResponse, "accounts");

			ArrayList alContactList = CommonUtil.getArrayList();
			String sAccountStatus = null;
			String sAccountType = null;
			String sAcctCreationDate = null;

			if (hmAcctProfResponse != null && !hmAcctProfResponse.isEmpty()) {
				sAccountStatus = (String) hmAcctProfResponse.get("state");
				Optional.ofNullable(sAccountStatus).ifPresent(x->hmCPNIConsHelperInput.put(CommonDefs.KEY_ACCOUNT_STATUS, x));
				sAccountType = (String) hmAcctProfResponse.get(CommonDefs.ACCOUNT_TYPE);
				Optional.ofNullable(sAccountType).ifPresent(x->hmCPNIConsHelperInput.put(CommonDefs.ACCOUNT_TYPE, x));

				sAcctCreationDate = (String) hmAcctProfResponse.get("createdOn");
				if (sAcctCreationDate != null && sAcctCreationDate.trim().length() > 0) {
					sAcctCreationDate = formatDate(CommonDefs.CUSTOMER_ACTIVE_DATE, sAcctCreationDate);
					hmCPNIConsHelperInput.put(CommonDefs.CUSTOMER_ACTIVE_DATE, sAcctCreationDate);
				}
			
				
				
				ArrayList alCSISubscriber = JsonService.convertToObject(((ArrayNode) hmIAPResponse.get("subscribers")), ArrayList.class);
				
				ArrayList alSubscribers = new ArrayList();
				
				if(alCSISubscriber != null && !alCSISubscriber.isEmpty()){
					for(int i=0; i<alCSISubscriber.size(); i++){
						HashMap<String, Object> hmAccSubscriber = (HashMap<String, Object>)alCSISubscriber.get(i);
						
						if(hmAccSubscriber != null && !hmAccSubscriber.isEmpty()){
							alSubscribers.add(hmAccSubscriber);
						}
					}
				}
				HashMap<String, Object> hmContact = CommonUtil.getMap(hmAcctProfResponse, "contact");

				if (hmContact != null && !hmContact.isEmpty()) {

					HashMap<String, Object> hmAddress = CommonUtil.getMap(hmContact, "address");
					HashMap<String, Object> hmEmail = CommonUtil.getMap(hmContact, CommonDefs.EMAIL);

					if (hmEmail != null && !hmEmail.isEmpty()) {
						ArrayList alEmailAddresses = CommonUtil.getArrayList();
						String sEmailAddess = (String) hmEmail.get(CommonDefs.EMAIL_ADDRESS);
						//String sEffectiveDate = (String) hmEmail.get("emailStatusUpdateDate");
						String sEffectiveDate = (String) hmAcctProfResponse.get("emailEstablishDate");

						if (sEffectiveDate != null && sEffectiveDate.trim().length() > 0)
							sEffectiveDate = formatDate(CommonDefs.TIME_MODIFIED, sEffectiveDate);

						HashMap<String, Object> hmEmailAddress = CommonUtil.getHashMap();
						hmEmailAddress.put(CommonDefs.EMAIL_ADDRESS, sEmailAddess);
						hmEmailAddress.put(CommonDefs.EMAIL_STATUS, "V");
						hmEmailAddress.put(CommonDefs.KEY_EMAIL_ESTABLISHED_DATE, sEffectiveDate);
						hmEmailAddress.put(CommonDefs.KEY_ACCOUNT_ESTABLISHED_DATE, sAcctCreationDate);

						alEmailAddresses.add(hmEmailAddress);

						if (alEmailAddresses != null && alEmailAddresses.size() > 0)
							hmCPNIConsHelperInput.put(CommonDefs.KEY_EMAIL_ADDRESSES, alEmailAddresses);
					}

					if (hmAddress != null && !hmAddress.isEmpty()) {
						String sUnitDesc = "";
						String sStreet = "";
						String sCustomerName = "";
						ArrayList alAddresses = CommonUtil.getArrayList();
						HashMap<String, Object> hmBillingAddress = CommonUtil.getHashMap();

						String sFirstName = (String) hmAcctProfResponse.get(CommonDefs.DB_FIRSTNAME);
						String sLastName = (String) hmAcctProfResponse.get(CommonDefs.DB_LASTNAME);
						
						// Retrieve customerName/businessName info

							if (sFirstName != null && sFirstName.trim().length() > 0)
								sCustomerName = sFirstName;

							if (sLastName != null && sLastName.trim().length() > 0)
								sCustomerName += " " + sLastName;

						if (sCustomerName != null && sCustomerName.trim().length() > 0)
							hmBillingAddress.put(CommonDefs.KEY_BILLNAME, sCustomerName);

						String sAddressType = (String) hmAddress.get("contactType");
						//or accounts/contact/Address/addressSubType

						String sZipCode=null;
						String sZipPlusFour=null;
						
						Optional.ofNullable(hmAddress.get("postCode")).ifPresent(x->{
							String postcode = (String)x;
							if(postcode.contains("-")) {
								hmBillingAddress.put(CommonDefs.KEY_ZIPPLUSFOUR, (postcode).split("-")[1]);
							}
							hmBillingAddress.put(CommonDefs.KEY_ZIPCODE, (postcode).split("-")[0]);
							
						});
						
						hmBillingAddress.put(CommonDefs.KEY_ADDRESS2, hmAddress.get("street1"));

						hmBillingAddress.put(CommonDefs.KEY_CITY, hmAddress.get("city"));
						hmBillingAddress.put(CommonDefs.KEY_STATE, hmAddress.get("state"));

						if (sAddressType != null && sAddressType.equalsIgnoreCase("F"))
							hmBillingAddress.put(CommonDefs.KEY_FOREIGN_ADDR_IND, CommonDefs.IND_Y);
						else
							hmBillingAddress.put(CommonDefs.KEY_FOREIGN_ADDR_IND, CommonDefs.IND_N);

						hmBillingAddress.put(CommonDefs.KEY_COUNTRY, hmAddress.get("country"));
						//TODO:not coming in hmAddress
						String sAddressEstablishedDate = (String) hmAddress.get("lastUpdate");
						if (sAddressEstablishedDate != null && sAddressEstablishedDate.trim().length() > 0) {
							sAddressEstablishedDate = formatDate(CommonDefs.CUSTOMER_ACTIVE_DATE,
									sAddressEstablishedDate);
							
							hmBillingAddress.put(CommonDefs.KEY_ADDRESS_ESTABLISHED_DATE, sAddressEstablishedDate);
						}
						//TODO:invalid value assigned below just for testing
						hmBillingAddress.put(CommonDefs.KEY_ADDRESS_ESTABLISHED_DATE, sAcctCreationDate);
						hmBillingAddress.put(CommonDefs.KEY_ACCOUNT_ESTABLISHED_DATE, sAcctCreationDate);

						if (hmBillingAddress != null && !hmBillingAddress.isEmpty()) {
							alAddresses.add(hmBillingAddress);
						}

						if (alAddresses != null && !alAddresses.isEmpty())
							hmCPNIConsHelperInput.put(CommonDefs.POSTAL_ADDRESS, alAddresses);
					}
				}

				ArrayList alCTNList = new ArrayList();
				if (alSubscribers != null && !alSubscribers.isEmpty()) {
					for (int k = 0; k < alSubscribers.size(); k++) {
						HashMap<String, Object> hmCTN = CommonUtil.getHashMap();
						HashMap<String, Object> hmSubscriber = (HashMap<String, Object>) alSubscribers.get(k);
						if (hmSubscriber != null && !hmSubscriber.isEmpty()) {
							String sSubscriberStatus = null;
							String sCTNActivationDate = null;

							String sSubscriberNumber = (String) hmSubscriber.get("subscriberId");
							String sSubscriptionId = (String) hmSubscriber.get("subscriptionId");
							sSubscriberStatus = (String) hmSubscriber.get("status");
							String duoIdentifier = (String) hmSubscriber.get("duoIdentifier");
							

							// 1406: US211311: Determine which CTN has the oldest
							
							sCTNActivationDate = (String) hmSubscriber.get("effectiveDate");
							String sSimSwapDate = (String) hmSubscriber.get(CommonDefs.SIM_SWAP_DATE);
							if (sSimSwapDate != null && !sSimSwapDate.isEmpty()) {
								sSimSwapDate = formatDate(CommonDefs.SIM_SWAP_DATE, sSimSwapDate);
							}

							// June 2013, dm7141
							
							String sDeviceSMSCapable = (String) hmSubscriber.get("smsCapability");
							String stIMEI = (String) hmSubscriber.get(CommonDefs.IMEI);
							

							if (bCheckSMS) {
								if (sDeviceSMSCapable != null && sDeviceSMSCapable.equals("Y")) {
									if (sSubscriberNumber != null) {
										hmCTN.put(CommonDefs.CTN, sSubscriberNumber);
									}

									if (sSubscriberStatus != null)
										hmCTN.put(CommonDefs.STATUS, sSubscriberStatus);

									if (sSubscriptionId != null)
										hmCTN.put(CommonDefs.KEY_SUBSCRIPTION_ID, sSubscriptionId);

									if (sCTNActivationDate != null)
										hmCTN.put(CommonDefs.ACTIVATION_DATE, sCTNActivationDate);

									if (stIMEI != null)
										hmCTN.put(CommonDefs.IMEI, stIMEI);

									if (sSimSwapDate != null)
										hmCTN.put(CommonDefs.SIM_SWAP_DATE, sSimSwapDate);
								}
							} else {
								if (sSubscriberNumber != null) {
									hmCTN.put(CommonDefs.CTN, sSubscriberNumber);
								}

								if (sSubscriberStatus != null)
									hmCTN.put(CommonDefs.STATUS, sSubscriberStatus);

								if (sSubscriptionId != null)
									hmCTN.put(CommonDefs.KEY_SUBSCRIPTION_ID, sSubscriptionId);

								if (sCTNActivationDate != null)
									hmCTN.put(CommonDefs.ACTIVATION_DATE, sCTNActivationDate);

								if (stIMEI != null)
									hmCTN.put(CommonDefs.IMEI, stIMEI);

								if (sSimSwapDate != null)
									hmCTN.put(CommonDefs.SIM_SWAP_DATE, sSimSwapDate);
							}
							// End - June 2013

							if (hmCTN != null && !hmCTN.isEmpty()) {
								if (duoIdentifier == null || !Constants.DUO_IDENTIFIER_COMPANION.equalsIgnoreCase(duoIdentifier)) {
									alCTNList.add(hmCTN);
								}
							}
						}
					}

					String sPrimaryAccountHolder = (String) hmAcctProfResponse.get("primaryAccountHolder");

					if (alCTNList != null && !alCTNList.isEmpty()) {
						// 1406 US211311: RIL QueryCPNIAddresses enhancements
						hmResult = moveOldestCTNFirst(alCTNList, sPrimaryAccountHolder);

						stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
						if (stAppStatusCode != null && !stAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
							stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
							logger.info("{}{}MOB_CPNI_H_05.23 : Error returned by findOldestCTN method : {}", 
									sClassName, sMethodName, stAppInfo);
							hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
							return hmResult;
						}
						hmCPNIConsHelperInput.put(CommonDefs.KEY_CTN_LIST, alCTNList);
					}
				}
				

				logger.debug("{}{}MOB_CPNI_H_07 : Calling CPNIConsolidationHelper.generateCPNIConsolidation with inputHash : {}", 
						sClassName, sMethodName, hmCPNIConsHelperInput);

				hmCPNIConResponse = oCPNIConsolidationHelper.generateCPNIConsolidation(hmCPNIConsHelperInput);

				logger.debug("{}{}MOB_CPNI_H_08 : ResponseHash from CPNIConsolidationHelper.generateCPNIConsolidation : {}", 
						sClassName, sMethodName, hmCPNIConResponse);

				if (hmCPNIConResponse == null || hmCPNIConResponse.isEmpty()) {
					stAppInfo = "null Hash returned from CPNIConsolidationHelper.generateCPNIConsolidation() ";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					logger.info("{}{}MOB_CPNI_H_08.1 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}

				stAppStatusCode = (String) hmCPNIConResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);

				if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					stAppInfo = (String) hmCPNIConResponse.get(CommonDefs.COMMON_APP_INFO);
					logger.info("{}{}MOB_CPNI_H_08.2 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
					return hmResult;
				}

				alContactList = (ArrayList) hmCPNIConResponse.get(CommonDefs.ACCOUNT_CONTACT_LIST);
			}else{
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ACCOUNT_INELIGIBLE_NUM, "CSI did not return any account profiles");
			}

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
			
			if (alContactList != null && !alContactList.isEmpty()) {
				hmResult.put(CommonDefs.ACCOUNT_CONTACT_LIST, alContactList);
			}
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
		} finally {
			stAppInfo = "Response from ProcessMobilityCPNIHelper = " + hmResult;
			logger.info("{}{}MOB_CPNI_H_08.5 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));

			if (hmResult == null || hmResult.isEmpty()) {
				stAppInfo = "Response from ProcessMobilityCPNIHelper is NULL";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}MOB_CPNI_H_08.6 : {}", sClassName, sMethodName, stAppInfo);
			}
			logger.info("{}{}HLP999 : response from ProcessMobilityCPNIHelper : {}", sClassName, sMethodName, hmResult);
		}
		return hmResult;
	}

	private static String formatDate(String sDateKey, String sDateValue) {
		String sMethodName = ".formatDate.";
		Date dtParsedDate = null;
		String sFormattedDate = null;

		try {
			DateFormat sdfCustActiveDt = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat sdfTimeModified = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat sdfEmailAddrDt = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat newDtFormat = new SimpleDateFormat("MMddyyyy HH:mm:ss");

			// parse input date
			if (sDateKey != null && sDateKey.equals(CommonDefs.CUSTOMER_ACTIVE_DATE))
				dtParsedDate = sdfCustActiveDt.parse(sDateValue);
			if (sDateKey != null && sDateKey.equals(CommonDefs.TIME_MODIFIED))
				dtParsedDate = sdfTimeModified.parse(sDateValue);
			if (sDateKey != null && sDateKey.equals("EmailAddrLastUpdateTs"))
				dtParsedDate = sdfEmailAddrDt.parse(sDateValue);
			if (sDateKey != null && sDateKey.equals("establishDate"))
				dtParsedDate = sdfEmailAddrDt.parse(sDateValue);

			if (sDateKey != null && sDateKey.equals(CommonDefs.SIM_SWAP_DATE) && sDateValue != null && !sDateValue.isEmpty()) {

				DateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				dtParsedDate = simpleDateFormat.parse(sDateValue);
				newDtFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
			}

			// convert to new date format
			if (dtParsedDate != null) {
				sFormattedDate = newDtFormat.format(dtParsedDate);
			}
			logger.info("{}{}FD_01 : {} : {}, Formatted Date : {}", sClassName, sMethodName, sDateKey, sDateValue,
					sFormattedDate);

		} catch (Exception exp) {
			logger.error("{}{}MOB_CPNI_H_06.12 : Exception = {}", sClassName, sMethodName, exp);
		}

		return sFormattedDate;
	}

	private HashMap moveOldestCTNFirst(ArrayList alListOfCTN, String sPrimaryAccountHolder) {
		String sMethodName = ".moveOldestCTNFirst.";
		HashMap<String, Object> hmResult = null;
		Date dtActivationDate = null;
		Date dOldestActivationDate = null;
		HashMap<String, Object> hmPrimaryAcctHolder = null;
		HashMap<String, Object> hmOldestCTN = null;
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		int indexPAHCTN = -1;
		int indexOldestCTN = -1;

		try {
			logger.info("{}{}FOC_1 : List of CTNs:: {} : PrimaryAccountHolder: {}", sClassName, sMethodName,
					HtmlUtils.htmlEscape(String.valueOf(alListOfCTN)),
					HtmlUtils.htmlEscape(String.valueOf(sPrimaryAccountHolder)));

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "");

			// Iterate through all CTNs to get PAH and oldest CTN
			for (int i = 0; i < alListOfCTN.size(); i++) {
				HashMap<String, Object> hmCTN = (HashMap<String, Object>) alListOfCTN.get(i);
				if (hmCTN != null) {
					String sCTNStatus = (String) hmCTN.get(CommonDefs.STATUS);

					if (sCTNStatus != null && !sCTNStatus.isEmpty() && sCTNStatus.equalsIgnoreCase(CommonDefs.ACTIVE)) {
						String sCTN = (String) hmCTN.get(CommonDefs.CTN);
						String strActivationDate = (String) hmCTN.get(CommonDefs.ACTIVATION_DATE);
						if (strActivationDate != null && !strActivationDate.isEmpty())
							dtActivationDate = df.parse(strActivationDate);

						logger.info("{}{}FOC_2 : dtActivationDate: {} :dOldestActivationDate: {}", sClassName,
								sMethodName, dtActivationDate, dOldestActivationDate);

						if (sCTN != null && sPrimaryAccountHolder != null && sCTN.equals(sPrimaryAccountHolder)) {
							indexPAHCTN = i;
							hmPrimaryAcctHolder = hmCTN;
							if (dOldestActivationDate == null) {
								dOldestActivationDate = dtActivationDate;
							}
						} else if (dOldestActivationDate == null) { // first CTN hash where nothing to compare
							indexOldestCTN = i;
							dOldestActivationDate = dtActivationDate;
							hmOldestCTN = hmCTN;
						} else if (dtActivationDate != null && dOldestActivationDate != null
								&& dtActivationDate.before(dOldestActivationDate)) {
							indexOldestCTN = i;
							dOldestActivationDate = dtActivationDate;
							hmOldestCTN = hmCTN;
						}
					}
				}
			} // end of for

			if (indexPAHCTN > indexOldestCTN) {
				if (hmPrimaryAcctHolder != null)
					alListOfCTN.remove(indexPAHCTN);

				if (hmOldestCTN != null)
					alListOfCTN.remove(indexOldestCTN);
			} else {
				if (hmOldestCTN != null)
					alListOfCTN.remove(indexOldestCTN);

				if (hmPrimaryAcctHolder != null)
					alListOfCTN.remove(indexPAHCTN);
			}

			// Move Oldest CTN 2nd if PAH present, else 1st position
			if (hmOldestCTN != null)
				alListOfCTN.add(0, hmOldestCTN);

			// move PAH first
			if (hmPrimaryAcctHolder != null)
				alListOfCTN.add(0, hmPrimaryAcctHolder);

			logger.info("{}{}FOC_4 : Ordered list of CTNs ::{}", sClassName, sMethodName, alListOfCTN);

		} catch (Exception ex) {
			hmResult = CommonErrorMap.makeExceptionMap(ex);
			String exceptionCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
			logger.error("{}{}FOC_E1 : Exception::Exception = {}", sClassName, sMethodName, ex);
			return hmResult;
		}

		return hmResult;
	}
}
