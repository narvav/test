package com.att.idp.idgraphcontactinfoms.config;

import jakarta.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

/**
 * The MPSYSConfiguration class is a configuration class in the Spring framework.
 * It is annotated with @Configuration to indicate that it is a source of bean definitions.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.config package.
 *
 * It contains an EntityManager property that is autowired, meaning Spring will automatically inject an instance of EntityManager into this class.
 * EntityManager is an interface to the persistence service in Java Persistence API (JPA). It is used to create and remove persistent entity instances, to find entities by their primary key, and to query over entities.
 */
@Configuration
public class MPSYSConfiguration {

	@Autowired
	private EntityManager entityManager;
}
