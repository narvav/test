package com.att.idp.idgraphcontactinfoms.resource;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/metrics")
@Produces({MediaType.APPLICATION_JSON})
public interface HikariCPResource {
    @GET
    @Path("/getMetrics")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMetrics ();

    //another method to softEvictConnnections
    @GET
    @Path("/softEvictDBPool")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response softEvictConnection ();

}
