package com.att.idp.idgraphcontactinfoms.utils;

import java.lang.reflect.Field;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import com.att.idp.idgraphcontactinfoms.model.Individual;
import com.att.idp.idgraphcontactinfoms.resource.response.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.PropertyAccessor;
import org.springframework.beans.PropertyAccessorFactory;
import org.springframework.stereotype.Component;
import com.att.idp.core.exception.ServiceError;
import com.att.idp.core.exception.ServiceException;
import com.att.idp.idgraphcontactinfoms.cgclient.response.CGResponse;
import com.att.idp.idgraphcontactinfoms.kafka.model.NTRetailerNotification;
import com.att.idp.idgraphcontactinfoms.message.ErrorMessages;
import com.att.idp.idgraphcontactinfoms.resource.request.DeliveryMethods;
import com.att.idp.idgraphcontactinfoms.resource.request.Sms;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.RILDefs;
import com.att.mpsys.common.utils.CommonUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

/**
 * The CommonUtilHelper class is part of the com.att.idp.idgraphcontactinfoms.utils package.
 *
 * This class provides a set of utility methods that are used across the application.
 * These methods include functionalities such as:
 * - Building responses for different types of requests.
 * - Generating error responses.
 * - Converting objects to different formats (e.g., Map, String).
 * - Checking if a collection or map is null or empty.
 * - Decrypting AES encrypted strings.
 * - Generating random numbers.
 * - Checking the aging of a field.
 * - Populating fields of an object from a HashMap.
 * - Converting an ArrayNode to a List of Maps.
 * - Populating a notification object from a HashMap.
 * - Keeping only the digits in a string.
 * - Getting delivery details from an ArrayList.
 *
 * This class is annotated with @Component, meaning it is a Spring Bean and can be autowired in other components.
 */
@Component
public class CommonUtilHelper {

	/**
	 * this is the common method and redirects to specific buildResponse methods for
	 * generatePIN etc.
	 *
	 * @param contactInfoRegResponse
	 * @return
	 */

	public static final Logger logger = LoggerFactory.getLogger(CommonUtilHelper.class);
	private static String sClassName = "CommonUtilHelper";

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The buildMSResponse method is used to build a response for the contact information registration.
	 * It takes an Object as input which represents the contact information registration response.
	 * The input object can be an instance of any of the following classes:
	 * - GeneratePINResponse
	 * - DeletePinResponse
	 * - ValidatePINResponse
	 * - QueryCPNIAccountContactInfoResponse
	 * - QueryCPNIUserContactInfoResponse
	 * - CGResponse
	 *
	 * The method checks the type of the input object and based on its type, it calls the appropriate method to create the response.
	 * The response is then returned as an instance of javax.ws.rs.core.Response.
	 *
	 * @param contactInfoRegResponse The contact information registration response object.
	 * @return A javax.ws.rs.core.Response object representing the response.
	 */
	public static Response buildMSResponse(Object contactInfoRegResponse) {
		Response response = null;
		GeneratePINResponse generatePINResponse = null;
		DeletePinResponse deletePinResponse = null;
		ValidatePINResponse validatePINResponse = null;
		QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse = null;
		QueryCPNIUserContactInfoResponse queryCPNIUserContactInfoResponse = null;
		CGResponse cgResponse = null;
		InquirePINResponse inquirePINResponse = null;
		CPNIContactInfoResponse cpniContactInfoResponse = null;

		if (contactInfoRegResponse instanceof GeneratePINResponse) {

			generatePINResponse = (GeneratePINResponse) contactInfoRegResponse;
			String sCategoryCode = generatePINResponse.getAppCategoryCode();
			response = createResponse(generatePINResponse, response, sCategoryCode);
		} else if (contactInfoRegResponse instanceof DeletePinResponse) {
			deletePinResponse = (DeletePinResponse) contactInfoRegResponse;
			String sCategoryCode = deletePinResponse.getAppCategoryCode();
			response = createResponse(deletePinResponse, response, sCategoryCode);
		} else if (contactInfoRegResponse instanceof ValidatePINResponse) {
			validatePINResponse = (ValidatePINResponse) contactInfoRegResponse;
			String sCategoryCode = validatePINResponse.getAppCategoryCode();
			response = createResponse(validatePINResponse, response, sCategoryCode);
		} else if (contactInfoRegResponse instanceof QueryCPNIAccountContactInfoResponse) {
			queryCPNIAccountContactInfoResponse = (QueryCPNIAccountContactInfoResponse) contactInfoRegResponse;
			String sCategoryCode = queryCPNIAccountContactInfoResponse.getAppCategoryCode();
			response = createResponse(queryCPNIAccountContactInfoResponse, response, sCategoryCode);
		} else if (contactInfoRegResponse instanceof QueryCPNIUserContactInfoResponse) {
			queryCPNIUserContactInfoResponse = (QueryCPNIUserContactInfoResponse) contactInfoRegResponse;
			String sCategoryCode = queryCPNIUserContactInfoResponse.getAppCategoryCode();
			response = createResponse(queryCPNIUserContactInfoResponse, response, sCategoryCode);
		} else if (contactInfoRegResponse instanceof CGResponse) {
			cgResponse = (CGResponse) contactInfoRegResponse;
			String sCategoryCode = cgResponse.getAppCategoryCode();
			response = createResponse(cgResponse, response, sCategoryCode);
		}else if (contactInfoRegResponse instanceof InquirePINResponse) {
			inquirePINResponse = (InquirePINResponse) contactInfoRegResponse;
			String sCategoryCode = inquirePINResponse.getAppCategoryCode();
			response = createResponse(contactInfoRegResponse, response, sCategoryCode);
		}else if (contactInfoRegResponse instanceof CPNIContactInfoResponse) {
			cpniContactInfoResponse = (CPNIContactInfoResponse) contactInfoRegResponse;
			String sCategoryCode = cpniContactInfoResponse.getAppCategoryCode();
			response = createResponse(contactInfoRegResponse, response, sCategoryCode);
		}
		return response;

	}

	private static Response createResponse(Object contactInfoRegResponse, Response response, String sCategoryCode) {
		String commonSuccessCategoryId = "0";
		String commonErrCategoryId = "1";
		String categoryCodeSystemError = "2";
		String categoryCodeDataError = "3";
		//Added this category code for mapping USER_NO_FOUND and BAN_NOT_FOUND to 404 statuscode
		String categoryCodeNotFoundError = "4";
		if (commonErrCategoryId.equals(sCategoryCode)) {
			response = Response.status(Status.INTERNAL_SERVER_ERROR).entity(contactInfoRegResponse).build();
		} else if (categoryCodeSystemError.equals(sCategoryCode)) {
			response = Response.status(Status.INTERNAL_SERVER_ERROR).entity(contactInfoRegResponse).build();
		} else if (categoryCodeDataError.equals(sCategoryCode)) {
			response = Response.status(Status.BAD_REQUEST).entity(contactInfoRegResponse).build();
		} else if (categoryCodeNotFoundError.equals(sCategoryCode)) {
			response = Response.status(Status.NOT_FOUND).entity(contactInfoRegResponse).build();
		} else if (commonSuccessCategoryId.equals(sCategoryCode)) {
			response = Response.status(Status.OK).entity(contactInfoRegResponse).build();
		}
		return response;
	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The generatePINErrorResponse method is used to generate an error response for the GeneratePIN operation.
	 * It takes an integer appStatusCode and a String appInfo as input.
	 * The appStatusCode represents the application status code, and the appInfo provides additional information about the application status.
	 *
	 * The method creates a HashMap using the appStatusCode and appInfo, and sets various fields of the GeneratePINResponse object using the values from the HashMap.
	 * It also sets the transaction name to "GeneratePIN" and the idpTraceId to the provided stIdpTraceId.
	 * If the appStatusCode indicates an error, it creates a ServiceException with the appropriate error message and sets it in the GeneratePINResponse object.
	 *
	 * The method returns a GeneratePINResponse object, which represents the error response for the GeneratePIN operation.
	 *
	 * @param appStatusCode The application status code.
	 * @param appInfo Additional information about the application status.
	 * @param errorMessage The error message to be included in the response if the appStatusCode indicates an error.
	 * @param stIdpTraceId The IDP trace ID.
	 * @return A GeneratePINResponse object representing the error response.
	 */
	public static GeneratePINResponse generatePINErrorResponse(int appStatusCode, String appInfo,
			ErrorMessages errorMessage, String stIdpTraceId) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		GeneratePINResponse generatePINResponse = new GeneratePINResponse();
		generatePINResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		generatePINResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		generatePINResponse.setTransactionName(ProfileOrchestrationConstants.TRANSACTION_NAME_GENERATE_PIN);
		generatePINResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		generatePINResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		generatePINResponse.setErrors(new ServiceException(errorMessage, appInfo).getError());
		generatePINResponse.setIdpTraceId(stIdpTraceId);

		return generatePINResponse;

	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The validatePINErrorResponse method is used to generate an error response for the ValidatePIN operation.
	 * It takes an integer appStatusCode and a String appInfo as input.
	 * The appStatusCode represents the application status code, and the appInfo provides additional information about the application status.
	 *
	 * The method creates a HashMap using the appStatusCode and appInfo, and sets various fields of the ValidatePINResponse object using the values from the HashMap.
	 * It also sets the transaction name to "ValidatePIN" and the idpTraceId to the provided stIdpTraceId.
	 * If the appStatusCode indicates an error, it creates a ServiceException with the appropriate error message and sets it in the ValidatePINResponse object.
	 *
	 * The method returns a ValidatePINResponse object, which represents the error response for the ValidatePIN operation.
	 *
	 * @param appStatusCode The application status code.
	 * @param appInfo Additional information about the application status.
	 * @return A ValidatePINResponse object representing the error response.
	 */
	public static ValidatePINResponse validatePINErrorResponse(int appStatusCode, String appInfo,
			ErrorMessages errorMessage, String stIdpTraceId, String remainingCodes) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		ValidatePINResponse validatePINResponse = new ValidatePINResponse();
		validatePINResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		validatePINResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		validatePINResponse.setTransactionName(ProfileOrchestrationConstants.TRANSACTION_NAME_VALIDATE_PIN);
		validatePINResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		validatePINResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		validatePINResponse.setRemainingCodes(remainingCodes);
		validatePINResponse.setErrors(new ServiceException(errorMessage, appInfo).getError());
		validatePINResponse.setIdpTraceId(stIdpTraceId);
		return validatePINResponse;

	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The generatePINSuccessResponse method is used to generate a successful response for the GeneratePIN operation.
	 * It takes an integer appStatusCode, a String appInfo, and a String idpTraceId as input.
	 * The appStatusCode represents the application status code, and the appInfo provides additional information about the application status.
	 * The idpTraceId is a unique identifier for the traceability of the request.
	 *
	 * The method creates a HashMap using the appStatusCode and appInfo, and sets various fields of the GeneratePINResponse object using the values from the HashMap.
	 * It also sets the transaction name to "GeneratePIN" and the idpTraceId to the provided idpTraceId.
	 *
	 * The method returns a GeneratePINResponse object, which represents the successful response for the GeneratePIN operation.
	 *
	 * @param appStatusCode The application status code.
	 * @param appInfo Additional information about the application status.
	 * @param idpTraceId The IDP trace ID.
	 * @return A GeneratePINResponse object representing the successful response.
	 */
	public static GeneratePINResponse generatePINSuccessResponse(int appStatusCode, String appInfo, String idpTraceId,
			String securityCode, String securityCodeExpires) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		GeneratePINResponse generatePINResponse = new GeneratePINResponse();
		generatePINResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		generatePINResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		generatePINResponse.setTransactionName(ProfileOrchestrationConstants.TRANSACTION_NAME_GENERATE_PIN);
		generatePINResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		generatePINResponse.setIdpTraceId(idpTraceId);
		generatePINResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		generatePINResponse.setSecurityCode(securityCode);
		generatePINResponse.setSecurityCodeExpires(securityCodeExpires);
		generatePINResponse.setIdpTraceId(idpTraceId);
		return generatePINResponse;

	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The validatePINSuccessResponse method is used to generate a successful response for the ValidatePIN operation.
	 * It takes an integer appStatusCode, a String appInfo, and a String idpTraceId as input.
	 * The appStatusCode represents the application status code, and the appInfo provides additional information about the application status.
	 * The idpTraceId is a unique identifier for the traceability of the request.
	 *
	 * The method creates a HashMap using the appStatusCode and appInfo, and sets various fields of the ValidatePINResponse object using the values from the HashMap.
	 * It also sets the transaction name to "ValidatePIN" and the idpTraceId to the provided idpTraceId.
	 *
	 * The method returns a ValidatePINResponse object, which represents the successful response for the ValidatePIN operation.
	 *
	 * @param appStatusCode The application status code.
	 * @param appInfo Additional information about the application status.
	 * @param idpTraceId The IDP trace ID.
	 * @return A ValidatePINResponse object representing the successful response.
	 */
	public static ValidatePINResponse validatePINSuccessResponse(int appStatusCode, String appInfo, String idpTraceId, String securityCodeCreatedOn) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		ValidatePINResponse validatePINResponse = new ValidatePINResponse();
		validatePINResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		validatePINResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		validatePINResponse.setTransactionName(ProfileOrchestrationConstants.TRANSACTION_NAME_VALIDATE_PIN);
		validatePINResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		validatePINResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
        validatePINResponse.setSecurityCodeCreatedOn(securityCodeCreatedOn);
		validatePINResponse.setIdpTraceId(idpTraceId);
		return validatePINResponse;
	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The generatePINResponse method is used to generate a response for the GeneratePIN operation.
	 * It takes a Map as input which contains the response details for the GeneratePIN operation.
	 *
	 * The method retrieves the application status code from the input Map and checks if it indicates a success.
	 * If the application status code indicates a success, it calls the generatePINSuccessResponse method to generate a successful response.
	 * If the application status code does not indicate a success, it calls the generatePINErrorResponse method to generate an error response.
	 *
	 * The method returns a GeneratePINResponse object, which represents the response for the GeneratePIN operation.
	 *
	 * @param hmResponse The Map containing the response details for the GeneratePIN operation.
	 * @return A GeneratePINResponse object representing the response for the GeneratePIN operation.
	 */
	public static GeneratePINResponse generatePINResponse(Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get("idp-trace-id");
		String stSecurityCode = (String) hmResponse.get(CommonDefs.SECURITY_CODE);
		String stSecurityCodeExpires = (String) hmResponse.get(CommonDefs.SECURITY_CODE_EXPIRES);

		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		int appStatusCode = Integer.parseInt(stAppStatusCode);
		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			return generatePINSuccessResponse(appStatusCode, stAppInfo, stIdpTraceId, stSecurityCode,
					stSecurityCodeExpires);
		} else {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf("MS_MPSYS_BE_" + appStatusCode);

			return generatePINErrorResponse(appStatusCode, stAppInfo, errMsg, stIdpTraceId);

		}
	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The generateCGResponse method is used to generate a response for the CG operation.
	 * It takes a Map as input which contains the response details for the CG operation.
	 *
	 * The method retrieves the application status code from the input Map and checks if it indicates a success.
	 * If the application status code indicates a success, it calls the generateCGSuccessResponse method to generate a successful response.
	 * If the application status code does not indicate a success, it calls the generateCGErrorResponse method to generate an error response.
	 *
	 * The method returns a CGResponse object, which represents the response for the CG operation.
	 *
	 * @param hmResponse The Map containing the response details for the CG operation.
	 * @return A CGResponse object representing the response for the CG operation.
	 */
	public static CGResponse generateCGResponse(Map<String, Object> hmResponse) {
		CGResponse cgResponse = new CGResponse();
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get("idp-trace-id");
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		int appStatusCode = Integer.parseInt(stAppStatusCode);

		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			cgResponse = generateCGSuccessResponse(appStatusCode, stAppInfo, stIdpTraceId);
			cgResponse.setAccounts((Map)hmResponse.get("accounts"));
			cgResponse.setSubscribers((ArrayNode) hmResponse.get("subscribers"));
		} else {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf("MS_MPSYS_BE_" + appStatusCode);

			cgResponse = generateCGErrorResponse(appStatusCode, stAppInfo, errMsg, stIdpTraceId);

		}

		return cgResponse;
	}

	private static CGResponse generateCGErrorResponse(int appStatusCode, String stAppInfo, ErrorMessages errMsg,
			String stIdpTraceId) {
		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, stAppInfo);

		CGResponse cgResponse = new CGResponse();
		cgResponse.setAppStatusCode((String) hmResult.get("appStatusCode"));
		cgResponse.setAppStatusMsg((String) hmResult.get("appStatusMsg"));
		cgResponse.setAppInfo((String) hmResult.get("appInfo"));
		cgResponse.setAppCategoryCode((String) hmResult.get("appCategoryCode"));
		cgResponse.setErrors(new ServiceException(errMsg, stAppInfo).getError());
		cgResponse.setIdpTraceId(stIdpTraceId);

		return cgResponse;
	}

	private static CGResponse generateCGSuccessResponse(int appStatusCode, String stAppInfo, String stIdpTraceId) {
		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, stAppInfo);
		CGResponse cgResponse = new CGResponse();
		cgResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		cgResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		cgResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		cgResponse.setIdpTraceId(stIdpTraceId);
		cgResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		cgResponse.setIdpTraceId(stIdpTraceId);
		return cgResponse;
	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The deletePINResponse method is used to generate a response for the DeletePIN operation.
	 * It takes a Map as input which contains the response details for the DeletePIN operation.
	 *
	 * The method retrieves the application status code from the input Map and checks if it indicates a success.
	 * If the application status code indicates a success, it calls the deletePINSuccessResponse method to generate a successful response.
	 * If the application status code does not indicate a success, it calls the deletePINErrorResponse method to generate an error response.
	 *
	 * The method returns a DeletePinResponse object, which represents the response for the DeletePIN operation.
	 *
	 * @param hmResponse The Map containing the response details for the DeletePIN operation.
	 * @return A DeletePinResponse object representing the response for the DeletePIN operation.
	 */
	public static DeletePinResponse deletePINResponse(Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get("idp-trace-id");

		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		int appStatusCode = Integer.parseInt(stAppStatusCode);

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, stAppInfo);

		DeletePinResponse deletePinResponse = new DeletePinResponse();
		deletePinResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		deletePinResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		deletePinResponse.setTransactionName("DeletePIN");
		deletePinResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		deletePinResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		deletePinResponse.setIdpTraceId(stIdpTraceId);
		if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf("MS_MPSYS_BE_" + stAppStatusCode);
			deletePinResponse.setErrors(new ServiceException(errMsg, stAppInfo).getError());
		}

		return deletePinResponse;
	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The validatePINResponse method is used to generate a response for the ValidatePIN operation.
	 * It takes a Map as input which contains the response details for the ValidatePIN operation.
	 *
	 * The method retrieves the application status code from the input Map and checks if it indicates a success.
	 * If the application status code indicates a success, it calls the validatePINSuccessResponse method to generate a successful response.
	 * If the application status code does not indicate a success, it calls the validatePINErrorResponse method to generate an error response.
	 *
	 * The method returns a ValidatePINResponse object, which represents the response for the ValidatePIN operation.
	 *
	 * @param hmResponse The Map containing the response details for the ValidatePIN operation.
	 * @return A ValidatePINResponse object representing the response for the ValidatePIN operation.
	 */
	public static ValidatePINResponse validatePINResponse(Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get("idp-trace-id");
		String remainingCodes = (String) hmResponse.get(CommonDefs.REMAINING_CODES);
        String securityCodeCreatedOn = (String) hmResponse.get(CommonDefs.SECURITY_CODE_CREATED_ON);
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		int appStatusCode = Integer.parseInt(stAppStatusCode);
		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			return validatePINSuccessResponse(appStatusCode, stAppInfo, stIdpTraceId, securityCodeCreatedOn);
		} else {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf("MS_MPSYS_BE_" + stAppStatusCode);

			return validatePINErrorResponse(appStatusCode, stAppInfo, errMsg, stIdpTraceId, remainingCodes);

		}
	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The generateCIRResponse method is used to generate a response for the Contact Information Registration (CIR) operation.
	 * It takes a Map as input which contains the response details for the CIR operation.
	 *
	 * The method retrieves the transaction name from the input Map and based on its value, it calls the appropriate method to create the response.
	 * The possible transaction names are "GeneratePIN", "DeletePIN", "ValidatePIN", "QueryCPNIAccountContactInfo", and "QueryCPNIUserContactInfo".
	 * For each transaction name, the corresponding method is called to generate the response.
	 *
	 * The method returns an Object which represents the response for the CIR operation.
	 * The returned object can be an instance of any of the following classes:
	 * - GeneratePINResponse
	 * - DeletePinResponse
	 * - ValidatePINResponse
	 * - QueryCPNIAccountContactInfoResponse
	 * - QueryCPNIUserContactInfoResponse
	 *
	 * @param hmResponse The Map containing the response details for the CIR operation.
	 * @return An Object representing the response for the CIR operation.
	 */
	public static Object generateCIRResponse(Map<String, Object> hmResponse) {
		String stTransactionName = (String) hmResponse.get(CommonDefs.TRANSACTION_NAME);
		if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.TRANSACTION_NAME_GENERATE_PIN)) {
			return generatePINResponse(hmResponse);
		} else if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.TRANSACTION_NAME_DELETE_PIN)) {
			return deletePINResponse(hmResponse);
		} else if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.TRANSACTION_NAME_VALIDATE_PIN)) {
			return validatePINResponse(hmResponse);
		} else if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.TRANSACTION_NAME_QUERY_CPN_I_ACCOUNT_CONTACT_INFO)) {
			return queryCPNIAccountContactInfoResponse(hmResponse);
		} else if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.TRANSACTION_NAME_QUERY_CPN_I_USER_CONTACT_INFO)) {
			return queryCPNIUserContactInfoResponse(hmResponse);
		} else if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.TRANSACTION_NAME_IQUIRE_PIN)) {
			return inquirePinResponse(hmResponse);
		}else if (stTransactionName.equalsIgnoreCase(ProfileOrchestrationConstants.TRANSACTION_NAME_CPNI_CONTACT_INFO)) {
			return cpniContactInfoResponse(hmResponse);
		}
		return null;
	}


	public static CPNIContactInfoResponse cpniContactInfoResponse(
			Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) Optional.ofNullable(hmResponse.get("idp-trace-id")).orElse(getTraceIdFromContextMap());
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		int appStatusCode = Integer.parseInt(stAppStatusCode);
		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			Individual individual = (Individual) hmResponse.get("Individual");
			return cpniContactInfoSuccessResponse(stIdpTraceId,individual);

		} else {
			ErrorMessages errMsg = ErrorMessages.valueOf("MS_MPSYS_BE_" + stAppStatusCode);
			return buildErrorResponse(
					appStatusCode, stAppInfo, errMsg, stIdpTraceId, CPNIContactInfoResponse.class);
		}
	}

	private static QueryCPNIUserContactInfoResponse queryCPNIUserContactInfoResponse(Map<String, Object> hmResponse) {

		return QueryCPNIUserContactInfoResponseGenerator.getQueryCPNIUserContactInfoResponse(hmResponse);

	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The queryCPNIAccountContactInfoResponse method is used to generate a response for the QueryCPNIAccountContactInfo operation.
	 * It takes a Map as input which contains the response details for the QueryCPNIAccountContactInfo operation.
	 *
	 * The method retrieves the application status code from the input Map and checks if it indicates a success.
	 * If the application status code indicates a success, it calls the queryCPNIAccountContactInfoSuccessResponse method to generate a successful response.
	 * If the application status code does not indicate a success, it calls the queryCPNIContactInfoErrorResponse method to generate an error response.
	 *
	 * The method returns a QueryCPNIAccountContactInfoResponse object, which represents the response for the QueryCPNIAccountContactInfo operation.
	 *
	 * @param hmResponse The Map containing the response details for the QueryCPNIAccountContactInfo operation.
	 * @return A QueryCPNIAccountContactInfoResponse object representing the response for the QueryCPNIAccountContactInfo operation.
	 */
	public static QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse(
			Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get("idp-trace-id");

		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		int appStatusCode = Integer.parseInt(stAppStatusCode);
		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			return queryCPNIAccountContactInfoSuccessResponse(appStatusCode, hmResponse);
		} else {
			ErrorMessages errMsg = ErrorMessages.valueOf("MS_MPSYS_BE_" + stAppStatusCode);
			return queryCPNIContactInfoErrorResponse(appStatusCode, stAppInfo, errMsg, stIdpTraceId);
		}
	}

	public static InquirePINResponse inquirePinResponse(
			Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get("idp-trace-id");

		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		int appStatusCode = Integer.parseInt(stAppStatusCode);
		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			return inquirePinSuccessResponse(appStatusCode, hmResponse);
		} else {
			ErrorMessages errMsg = ErrorMessages.valueOf("MS_MPSYS_BE_" + stAppStatusCode);
			return inquirePinErrorResponse(appStatusCode, stAppInfo, errMsg, stIdpTraceId);
		}
	}

	private static QueryCPNIAccountContactInfoResponse queryCPNIContactInfoErrorResponse(int appStatusCode,
			String appInfo, ErrorMessages errorMessage, String stIdpTraceId) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		String stAppStatusMsg = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG);

		QueryCPNIAccountContactInfoResponse response = new QueryCPNIAccountContactInfoResponse();
		response.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		response.setAppStatusMsg(stAppStatusMsg);
		response.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		response.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		response.setErrors(new ServiceException(errorMessage, appInfo).getError());
		response.setIdpTraceId(stIdpTraceId);
		return response;
	}

	private static QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoSuccessResponse(int appStatusCode,
			Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get("idp-trace-id");
		String sMethodName = ".queryCPNIAccountContactInfoSuccessResponse.";

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, stAppInfo);

		QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfoResponse = new QueryCPNIAccountContactInfoResponse();
		queryCPNIAccountContactInfoResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		queryCPNIAccountContactInfoResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		queryCPNIAccountContactInfoResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		queryCPNIAccountContactInfoResponse
				.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		queryCPNIAccountContactInfoResponse.setIdpTraceId(stIdpTraceId);

		try {
			if (hmResponse.get("AccountContactList") != null) {
				ArrayList<HashMap<String, Object>> alAccountContactListResp = (ArrayList<HashMap<String, Object>>) hmResponse
						.get("AccountContactList");
				ArrayList<AccountContactList> alAccountContactList = cpniListDetails(hmResponse,
						alAccountContactListResp);
				queryCPNIAccountContactInfoResponse.setAccountContactList(alAccountContactList);
			}
		} catch (Exception e) {
			stAppInfo = "Exception thrown in QueryCPNIAccountContactInfoResponseHelper : " + e.getMessage();
			logger.error("{}{}DBCHE01 :  Error::{}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}DBCHE02 : Exception = {}", sClassName, sMethodName, e);
			queryCPNIAccountContactInfoResponse = queryCPNIContactInfoErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM,
					stAppInfo, ErrorMessages.valueOf("MS_MPSYS_BE_" + appStatusCode), stIdpTraceId);
		}
		return queryCPNIAccountContactInfoResponse;
	}

	private static InquirePINResponse inquirePinSuccessResponse(int appStatusCode,
			Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get("idp-trace-id");
		String sMethodName = ".inquirePinSuccessResponse.";

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, stAppInfo);

		InquirePINResponse inquirePINResponse = new InquirePINResponse();
		inquirePINResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		inquirePINResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		inquirePINResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		inquirePINResponse
				.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		try {
			 if (hmResponse.get("maxAllowedPINs") != null) {
			 inquirePINResponse.setTotalPins((Integer) hmResponse.get("maxAllowedPINs"));
			 } if (hmResponse.get("unusedPINs") != null) {
			 inquirePINResponse.setUnusedPins((Integer) hmResponse.get("unusedPINs")); }
			inquirePINResponse.setIdpTraceId(stIdpTraceId);


			if (hmResponse.get("securityPins") != null) {
				ArrayList<HashMap<String, Object>> alSecurityPinsListResp = (ArrayList<HashMap<String, Object>>) hmResponse
						.get("securityPins");
				ArrayList<SecurityPins> alSecurityPinsList = securityPinDetails(alSecurityPinsListResp);
				inquirePINResponse.setSecurityPins(alSecurityPinsList);
			}
		} catch (Exception e) {
			stAppInfo = "Exception thrown in inquirePinSuccessResponse : " + e.getMessage();
			logger.error("{}{}IPR_01 :  Error::{}", sClassName, sMethodName, e.getMessage());
			logger.error("{}{}IPR_02 : Exception = {}", sClassName, sMethodName, e);
			inquirePINResponse = inquirePinErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM,
					stAppInfo, ErrorMessages.valueOf("MS_IDGRAPH_BE_" + appStatusCode), stIdpTraceId);
		}
		return inquirePINResponse;
	}
	
	private static InquirePINResponse inquirePinErrorResponse(int appStatusCode,
			String appInfo, ErrorMessages errorMessage, String stIdpTraceId) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		String stAppStatusMsg = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG);

		InquirePINResponse response = new InquirePINResponse();
		response.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		response.setAppStatusMsg(stAppStatusMsg);
		response.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		response.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		response.setErrors(new ServiceException(errorMessage, appInfo).getError());
		response.setIdpTraceId(stIdpTraceId);
		return response;
	}

	/**
	 * Builds an error response object of the specified type, setting common error fields.
	 *
	 * @param appStatusCode The application status code.
	 * @param appInfo Additional information about the application status.
	 * @param errorMessage The error message to be included in the response.
	 * @param stIdpTraceId The IDP trace ID.
	 * @param responseClass The class of the response object to create.
	 * @param <T> The type of the response object.
	 * @return An instance of the response object with error fields populated.
	 */
	private static <T> T buildErrorResponse(
			int appStatusCode,
			String appInfo,
			ErrorMessages errorMessage,
			String stIdpTraceId,
			Class<T> responseClass) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);
		stIdpTraceId = Optional.ofNullable(stIdpTraceId).orElse(getTraceIdFromContextMap());

		try {
			T response = responseClass.getDeclaredConstructor().newInstance();
			Stream.of(
					new Object[]{"setAppStatusCode", String.class, hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE)},
					new Object[]{"setAppStatusMsg", String.class, hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG)},
					new Object[]{"setAppInfo", String.class, hmResult.get(CommonDefs.COMMON_APP_INFO)},
					new Object[]{"setAppCategoryCode", String.class, hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE)},
					new Object[]{"setErrors", ServiceError.class, new ServiceException(errorMessage, appInfo).getError()},
					new Object[]{"setIdpTraceId", String.class, stIdpTraceId}
			).forEach(args -> {
				try {
					Optional.ofNullable(
							response.getClass().getMethod((String) args[0], (Class<?>) args[1])
					).ifPresent(m -> {
						try {
							m.invoke(response, args[2]);
						} catch (Exception e) {
							throw new RuntimeException(e);
						}
					});
				} catch (NoSuchMethodException e) {
					// Method is optional, ignore if not present
				}
			});
			return response;
		} catch (Exception e) {
			throw new RuntimeException("Failed to build error response", e);
		}
	}

	//  for creating common success response fields for CPNIContactInfoSuccessResponse
	public static CPNIContactInfoResponse cpniContactInfoSuccessResponse(String stIdpTraceId, Individual individual) {
		HashMap<String, Object> hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, "Success");
		CPNIContactInfoResponse cpniContactInfoResponse = new CPNIContactInfoResponse();
		cpniContactInfoResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		cpniContactInfoResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		stIdpTraceId = Optional.ofNullable(stIdpTraceId).orElse(getTraceIdFromContextMap());
		cpniContactInfoResponse.setIdpTraceId(stIdpTraceId);
		if (individual != null) {
			cpniContactInfoResponse.setIndividual(individual);
		}
		return cpniContactInfoResponse;
	}

	private static ArrayList<SecurityPins> securityPinDetails(ArrayList<HashMap<String, Object>> alSecurityPinsListResp) {
		ArrayList<SecurityPins> alSecurityPinsList = new ArrayList<>();
		for (HashMap hmAccountList : alSecurityPinsListResp) {
			SecurityPins securityPin = new SecurityPins();
			
			securityPin.setAccountId((String) hmAccountList.get("accountId"));
			securityPin.setCreateTime((String) hmAccountList.get("createTime"));
			securityPin.setDeliveryDetail((String) hmAccountList.get("deliveryDetail"));
			securityPin.setDeliveryMethod((String) hmAccountList.get("deliveryMethod"));
			securityPin.setExpirationTime((String) hmAccountList.get("expirationTime"));
			securityPin.setIdentificationType((String) hmAccountList.get("identificationType"));
			securityPin.setRequestedBy((String) hmAccountList.get("requestedBy"));
			securityPin.setStatus((String) hmAccountList.get("status"));
			securityPin.setVerificationFailureCount((String) hmAccountList.get("verificationFailureCount"));
			alSecurityPinsList.add(securityPin)	;
		}
		return alSecurityPinsList;
	}

	static ArrayList cpniListDetails(Map<String, Object> hmResponse,
			ArrayList<HashMap<String, Object>> alAccountContactList) throws Exception {

		ArrayList accountCPNIContactListAl = new ArrayList<AccountContactList>();
		for (HashMap hmAccountList : alAccountContactList) {
			HashMap hmGeneralContactDetails = null;
			HashMap hmResult = new HashMap();
			GeneralContactDetails generalContactDetails = null;
			if (hmAccountList.containsKey(CommonDefs.KEY_EMAIL)) {
				HashMap hmAccountContactList = (HashMap) hmAccountList.get(CommonDefs.KEY_EMAIL);
				Email email = (Email) CommonUtilHelper.populateFields(hmResponse, Email.class,
						(HashMap) hmAccountContactList);
				hmGeneralContactDetails = (HashMap) hmAccountContactList.get(CommonDefs.GENERAL_CONTACT_DETAILS);
				generalContactDetails = (GeneralContactDetails) CommonUtilHelper.populateFields(hmResponse,
						GeneralContactDetails.class, (HashMap) hmGeneralContactDetails);
				email.setGeneralContactDetails(generalContactDetails);

				hmResult.put(CommonDefs.KEY_EMAIL, email);
			}
			if (hmAccountList.containsKey(CommonDefs.US_PHONE_NUMBER)) {
				HashMap hmAccountContactList = (HashMap) hmAccountList.get(CommonDefs.US_PHONE_NUMBER);
				USPhoneNumber uSPhoneNumber = (USPhoneNumber) CommonUtilHelper.populateFields(hmResponse,
						USPhoneNumber.class, (HashMap) hmAccountContactList);

				hmGeneralContactDetails = (HashMap) hmAccountContactList.get(CommonDefs.GENERAL_CONTACT_DETAILS);
				if(hmGeneralContactDetails!=null) {
				generalContactDetails = (GeneralContactDetails) CommonUtilHelper.populateFields(hmResponse,
						GeneralContactDetails.class, (HashMap) hmGeneralContactDetails);
				uSPhoneNumber.setGeneralContactDetails(generalContactDetails);
				}
				hmResult.put(CommonDefs.US_PHONE_NUMBER, uSPhoneNumber);
				
			}
			if (hmAccountList.containsKey(CommonDefs.KEY_POSTAL_ADDRESS)) {
				HashMap hmAccountContactList = (HashMap) hmAccountList.get(CommonDefs.KEY_POSTAL_ADDRESS);

				PostalAddress postalAddress = (PostalAddress) CommonUtilHelper.populateFields(hmResponse,
						PostalAddress.class, (HashMap) hmAccountContactList);

				hmGeneralContactDetails = (HashMap) hmAccountContactList.get(CommonDefs.GENERAL_CONTACT_DETAILS);
				generalContactDetails = (GeneralContactDetails) CommonUtilHelper.populateFields(hmResponse,
						GeneralContactDetails.class, (HashMap) hmGeneralContactDetails);
				postalAddress.setGeneralContactDetails(generalContactDetails);

				hmResult.put("PostalAddress", postalAddress);
			}
			accountCPNIContactListAl.add(hmResult);
		}
		return accountCPNIContactListAl;
	}
	

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The sysErrorHashMap method is used to generate a HashMap that represents a system error.
	 * It takes a String appInfo as input which provides additional information about the application status.
	 *
	 * The method calls the makeExceptionMap method of the CommonErrorMap class, passing the ERR_SYS_APPL_NUM constant and the appInfo as parameters.
	 * The makeExceptionMap method returns a HashMap which is then returned by the sysErrorHashMap method.
	 *
	 * The returned HashMap contains details about the system error, including the application status code, status message, info, and category code.
	 * It also includes an ErrorEnum object which represents the error message.
	 *
	 * @param appInfo Additional information about the application status.
	 * @return A HashMap representing a system error.
	 */
	public static Map<String, Object> sysErrorHashMap(String appInfo) {
		Map<String, Object> hmResult = null;
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, appInfo);
		hmResult.put("ErrorEnum", ErrorMessages.MS_MPSYS_BE_602);
		return hmResult;
	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The objectToMap method is a generic method that converts an object of any type to a Map.
	 * It uses the Jackson library's ObjectMapper to perform the conversion.
	 * The keys in the returned Map are the field names of the object, and the values are the corresponding field values.
	 *
	 * This method is useful when you need to manipulate or inspect the data of an object in a more flexible or dynamic way than the object's class allows.
	 * For example, you can use this method to convert an object to a Map and then iterate over the Map to inspect the fields and values of the object.
	 *
	 * Note: The method does not handle complex nested structures. If the object contains other objects as fields, those inner objects will be converted to Map-like structures (nested Maps).
	 *
	 * @param t The object to be converted to a Map. It can be an instance of any class.
	 * @return A Map representing the input object. The keys are the field names of the object, and the values are the corresponding field values.
	 * @throws IllegalArgumentException if the input object is null.
	 */
	public static <T> Map<String, Object> objectToMap(T t) {

		ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		Map<String, Object> map = mapper.convertValue(t, new TypeReference<Map<String, Object>>() {
		});
		return map;
	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The objectToListOfMap method is a generic method that converts an object of any type to a List of Maps.
	 * It uses the Jackson library's ObjectMapper to perform the conversion.
	 * Each Map in the returned List represents an item in the input object, with the keys being the field names and the values being the corresponding field values.
	 *
	 * This method is useful when you need to manipulate or inspect the data of an object in a more flexible or dynamic way than the object's class allows.
	 * For example, you can use this method to convert an object to a List of Maps and then iterate over the List to inspect the fields and values of each item in the object.
	 *
	 * Note: The method does not handle complex nested structures. If the object contains other objects as fields, those inner objects will be converted to Map-like structures (nested Maps).
	 *
	 * @param t The object to be converted to a List of Maps. It can be an instance of any class.
	 * @return A List of Maps representing the input object. Each Map represents an item in the object, with the keys being the field names and the values being the corresponding field values.
	 * @throws IllegalArgumentException if the input object is null.
	 */
	public static <T> List<Map<String, Object>> objectToListOfMap(T t) {

		ObjectMapper mapper = new ObjectMapper();
		List<Map<String, Object>> list = mapper.convertValue(t, new TypeReference<List<Map<String, Object>>>() {
		});
		return list;
	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The objectToString method is used to convert an object of any type to a String.
	 * It uses the Jackson library's ObjectMapper to perform the conversion.
	 * The method returns a String representation of the input object.
	 *
	 * This method is useful when you need to convert an object to a String for logging, debugging, or other purposes where a textual representation of the object is needed.
	 *
	 * Note: The method handles the conversion of complex nested structures. If the object contains other objects as fields, those inner objects will be included in the returned String.
	 *
	 * @param obj The object to be converted to a String. It can be an instance of any class.
	 * @return A String representing the input object.
	 * @throws JsonProcessingException if the input object cannot be converted to a String.
	 */
	public static String objectToString(Object obj) {

		if (obj == null)
			return null;
		ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.writeValueAsString(obj);
		} catch (JsonProcessingException e) {
			logger.error("JsonProcessingException while processing object {} to string: {}",StringUtils.normalizeSpace(obj!=null ? obj.getClass().getName() : null), StringUtils.normalizeSpace(e.getMessage()));
		}
		return obj.toString();
	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The isCollectionMapNullOrEmpty method checks if a given Map is null or empty.
	 * It takes a Map as input and returns a boolean value indicating whether the Map is null or empty.
	 *
	 * This method is useful when you need to ensure that a Map is not null and contains at least one entry before performing operations on it.
	 * For example, you can use this method to check if a Map is null or empty before iterating over it or accessing its entries.
	 *
	 * @param m The Map to be checked. It can be a Map of any type.
	 * @return A boolean value indicating whether the Map is null or empty. Returns true if the Map is null or empty, and false otherwise.
	 */
	public static boolean isCollectionMapNullOrEmpty(final Map<?, ?> m) {
		return m == null || m.isEmpty();
	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The getAESDecryption method is used to decrypt an AES encrypted string.
	 * It takes two parameters: an encrypted string and a key for the AES256 encryption.
	 *
	 * The method first checks if the encrypted string is empty. If it is, it returns an empty string.
	 * If the key is null or empty, an error is logged and the method returns an empty string.
	 *
	 * The method then converts the key from a hexadecimal string to a byte array and creates a SecretKeySpec from it.
	 * It initializes a Cipher for AES decryption with the SecretKeySpec and decrypts the encrypted string.
	 * The decrypted string is then returned.
	 *
	 * Note: This method uses the javax.crypto.Cipher and javax.crypto.spec.SecretKeySpec classes for decryption.
	 *
	 * @param encrypted The AES encrypted string to be decrypted.
	 * @param propAes256Key The key for the AES256 encryption.
	 * @return The decrypted string. If the encrypted string or the key is null or empty, an empty string is returned.
	 */
	public static String getAESDecryption(String encrypted, String propAes256Key) {

		logger.info("In AESDecryption method");

		try {
			if (encrypted.isEmpty()) {
				logger.debug("GDPWD1 No config-value to decrypt. Returning an Empty-String...");
				return encrypted;
			}

			// Something's wrong if AES256Key is still null or empty
			if (propAes256Key == null || propAes256Key.length() == 0) {
				logger.error("AES256Key is null or empty");
			}

			logger.debug("AES256Key = {}", propAes256Key);

			byte[] raw = hexToByteArray(propAes256Key);

			// Create SecretKeySpec
			SecretKeySpec secretKeySpec = new SecretKeySpec(raw, RILDefs.ENCRYPT_AES);

			if (secretKeySpec == null) {
				logger.debug("GDPWD2 No {} is available for decryption. Returning an Empty-String...",
						CommonDefs.APP_AES256KEY);
				return "";
			}

			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.DECRYPT_MODE, secretKeySpec);

			byte[] decryptedBytes = cipher.doFinal(hexToByteArray(encrypted));
			return new String(decryptedBytes);
			// }

		} catch (Exception e) {
			logger.error("GDPWDEX1 Exception : {}.", e.getMessage());
			return "";
		}
	}

	/**
	 * hexToByteArray converts Hex String to byte array
	 * 
	 * @param hex hexadecimal String
	 * @return byte array
	 */
	public static byte[] hexToByteArray(String hex) {
		byte[] bts = new byte[hex.length() / 2];
		for (int i = 0; i < bts.length; i++) {
			bts[i] = (byte) Integer.parseInt(hex.substring(2 * i, 2 * i + 2), 16);
		}
		return bts;
	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The generateRandomNum method is used to generate a random integer between 0 (inclusive) and the specified upper limit (exclusive).
	 * It uses the java.security.SecureRandom class to generate the random number.
	 *
	 * This method is useful when you need to generate a random number within a specific range. For example, you can use this method to generate a random index for an array or list.
	 *
	 * @param upperLimit The upper limit for the random number. The generated number will be less than this value.
	 * @return A random integer between 0 (inclusive) and the specified upper limit (exclusive).
	 */
	public static int generateRandomNum(int upperLimit) {
		return new SecureRandom().nextInt(upperLimit);
	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 * <p>
	 * The checkAging method is used to check if a given date is older than a specified number of days.
	 * It takes two parameters: a date string in the format "MMddyyyy HH:mm:ss" and a string representing the number of days.
	 * <p>
	 * The method first parses the date string into a Date object. It then creates a Calendar object and sets its time to the parsed date.
	 * It adds the specified number of days to the Calendar object.
	 * The method then creates a new Date object representing the current date and time, and checks if the date in the Calendar object is before the current date.
	 * If it is, the method returns true, indicating that the input date is older than the specified number of days. Otherwise, it returns false.
	 * <p>
	 * This method is useful when you need to check if a certain event or data is older than a certain number of days.
	 *
	 * @param sAgingFieldDate The date to be checked. It should be a string in the format "MMddyyyy HH:mm:ss".
	 * @param sNumOfDays      The number of days to check against. It should be a string representing an integer.
	 * @param dateTimeFormat The format pattern for parsing the date string (e.g., "MMddyyyy HH:mm:ss")
	 * @return A boolean value indicating whether the input date is older than the specified number of days. Returns true if the date is older, and false otherwise.
	 */
	public static boolean checkAging(String sAgingFieldDate, String sNumOfDays, String dateTimeFormat) {

		String sThisMethod = ".checkAging.";
		boolean bInputFieldAged = false;

		try {
			if (sAgingFieldDate != null && !sAgingFieldDate.isEmpty()) {
				Calendar cal = Calendar.getInstance();
				DateFormat dtFmt = new SimpleDateFormat(dateTimeFormat);
				Date dtOnlineQAEstDate = dtFmt.parse(sAgingFieldDate);
				cal.setTime(dtOnlineQAEstDate);

				logger.info("CommonUtilHelper.{}CUH_01 : Input Date: {} Days: {}", sThisMethod, sAgingFieldDate,
						sNumOfDays);

				int iAgingDays = 0;

				if (sNumOfDays != null && !sNumOfDays.isEmpty()) {
					iAgingDays = Integer.parseInt(sNumOfDays);
				}

				cal.add(Calendar.DAY_OF_MONTH, iAgingDays);

				Date systemDate = dtFmt.parse(dtFmt.format(new Date()));
				Date dtFieldEstDate = dtFmt.parse(dtFmt.format(cal.getTime()));

				logger.debug("CommonUtilHelper.{}CUH_02 : dtFieldEstDate : {}", sThisMethod, dtFieldEstDate);
				logger.debug("CommonUtilHelper.{}CUH_03 : systemDate : {}", sThisMethod, systemDate);

				if (dtFieldEstDate.before(systemDate)) {
					bInputFieldAged = true;
				}

			}
		} catch (Exception exp) {
			HashMap hmResponse = CommonErrorMap.makeExceptionMap(exp, logger);
		}

		logger.info("CommonUtilHelper.{}CUH_6 : bInputFieldAged : {}", sThisMethod, bInputFieldAged);
		return bInputFieldAged;
	}

	/**
	 * Extracts a LocalDate from the input string (MMddyyyy HH:mm:ss).
	 * Throws ServiceException if the string is blank, too short, or not a valid date.
	 *
	 * @param dateStr the date string in "MMddyyyy HH:mm:ss" format
	 * @return LocalDate parsed date
	 * @throws ServiceException if parsing fails
	 */
	public static LocalDate extractDate(String dateStr, String format) {
		if (dateStr == null || dateStr.trim().isEmpty()) {
			throw new ServiceException(ErrorMessages.MS_MPSYS_BE_602, "Date string is null or empty");
		}
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
			return LocalDateTime.parse(dateStr, formatter).toLocalDate();
		} catch (Exception e) {
			throw new ServiceException(ErrorMessages.MS_MPSYS_BE_602, "Unrecognized date format: " + dateStr);
		}
	}
	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The populateFields method is a generic method that populates the fields of an object from a HashMap.
	 * It takes three parameters: an object, a Class representing the type of the object, and a HashMap containing the field values.
	 *
	 * The method uses reflection to access the fields of the object. It iterates over the fields and sets their values using the values from the HashMap.
	 * The keys in the HashMap should match the field names in the object.
	 *
	 * This method is useful when you need to populate an object with data from a dynamic source, such as a database query result or a JSON object.
	 *
	 * Note: The method handles complex nested structures. If the object contains other objects as fields, those inner objects will be populated as well.
	 *
	 * @param obj The object to be populated. It can be an instance of any class.
	 * @param className The Class representing the type of the object.
	 * @param hashMap The HashMap containing the field values. The keys should match the field names in the object.
	 * @return The populated object.
	 * @throws InstantiationException if the class that declares the underlying constructor represents an abstract class.
	 * @throws IllegalAccessException if this Constructor object is enforcing Java language access control and the underlying constructor is inaccessible.
	 * @throws ClassNotFoundException if the class cannot be located
	 */
	public static Object populateFields(Object obj, Class className, HashMap hashMap)
			throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		obj = Class.forName(className.getName()).newInstance();
		Field[] fields = obj.getClass().getDeclaredFields();
		PropertyAccessor accessor = PropertyAccessorFactory.forBeanPropertyAccess(obj);
		for (Field field : fields) {
			if (hashMap.get(field.getName()) != null) {
				if (hashMap.get(field.getName()) instanceof Long || hashMap.get(field.getName()) instanceof Character)
					accessor.setPropertyValue(field.getName(), hashMap.get(field.getName()).toString());
				else
					accessor.setPropertyValue(field.getName(), (String) hashMap.get(field.getName()));
			}
		}
		return obj;
	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The convertToList method is used to convert an ArrayNode to a List of Maps.
	 * It uses the Jackson library's ObjectMapper to perform the conversion.
	 * Each Map in the returned List represents an item in the ArrayNode, with the keys being the field names and the values being the corresponding field values.
	 *
	 * This method is useful when you need to convert an ArrayNode to a List of Maps for easier manipulation or inspection.
	 * For example, you can use this method to convert an ArrayNode to a List of Maps and then iterate over the List to inspect the fields and values of each item in the ArrayNode.
	 *
	 * Note: The method handles the conversion of complex nested structures. If the ArrayNode contains other objects as fields, those inner objects will be converted to Map-like structures (nested Maps).
	 *
	 * @param values The ArrayNode to be converted to a List of Maps.
	 * @return A List of Maps representing the input ArrayNode. Each Map represents an item in the ArrayNode, with the keys being the field names and the values being the corresponding field values.
	 */
	public static List<Map<String, Object>> convertToList(ArrayNode values) {
		List<Map<String, Object>> result = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> resultHm = null;
		for (int i = 0; i < values.size(); i++) {

			resultHm = mapper.convertValue(values.get(i), new TypeReference<Map<String, Object>>() {
			});
			result.add(resultHm);
		}
		return result;
	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The populateNotificationObject method is used to populate a NTRetailerNotification object from a HashMap.
	 * It takes a HashMap as input which contains the data to be used to populate the NTRetailerNotification object.
	 *
	 * The method first checks if the HashMap contains certain keys (such as "SMS", "EMAIL", and "BROWSER_LANGUAGE") and if so, it retrieves the corresponding values and sets them in the NTRetailerNotification object.
	 * It also creates a DeliveryMethods object and populates it with the data from the HashMap.
	 * The populated DeliveryMethods object is then set in the NTRetailerNotification object.
	 *
	 * The method returns the populated NTRetailerNotification object.
	 *
	 * This method is useful when you need to create a NTRetailerNotification object from a dynamic data source, such as a database query result or a JSON object.
	 *
	 * @param hmInput The HashMap containing the data to be used to populate the NTRetailerNotification object.
	 * @return The populated NTRetailerNotification object.
	 */
	public static NTRetailerNotification populateNotificationObject(Map<String, Object> hmInput) {
		NTRetailerNotification notification = null;
		HashMap hmDeliveryMethods = (HashMap) hmInput.get(CommonDefs.DELIVERY_METHODS);
		DeliveryMethods deliveryMethods = new DeliveryMethods();
		if(hmInput != null && !hmInput.isEmpty()) {
			notification = new NTRetailerNotification();
		if (hmDeliveryMethods != null && !hmDeliveryMethods.isEmpty()) {
			if (hmDeliveryMethods.containsKey(CommonDefs.SMS)) {
				Sms sms = new Sms();
				HashMap hmInputSMS = (HashMap) hmDeliveryMethods.get(CommonDefs.SMS);
				if (hmInputSMS != null && !hmInputSMS.isEmpty()) {
					sms.setSmsPhoneNumber((String) hmInputSMS.get(CommonDefs.SMS_PHONE_NUMBER));
					deliveryMethods.setSms(sms);
				}
			}

			if (hmDeliveryMethods.containsKey(CommonDefs.EMAIL)) {

				HashMap hmEmail = (HashMap) hmDeliveryMethods.get(CommonDefs.EMAIL);
				com.att.idp.idgraphcontactinfoms.resource.request.Email email = new com.att.idp.idgraphcontactinfoms.resource.request.Email();
				if (hmEmail != null && !hmEmail.isEmpty()) {
					String stEmailAddress = (String) hmEmail.get(CommonDefs.EMAIL_ADDRESS);
					if (stEmailAddress != null && stEmailAddress.trim().length() > 0) {
						email.setEmailAddress(stEmailAddress);
						deliveryMethods.setEmail(email);
					}
				}
			}
			
		}
		
		String stBrowserLang =  (String) hmInput.get(CommonDefs.BROWSER_LANGUAGE);
		
		if(stBrowserLang!=null && !stBrowserLang.isBlank()) {
			notification.setBrowserLanguage(stBrowserLang);
		}
//		notification = NTRetailerNotification.builder().transactionName("GeneratePin").callingSystemId((String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID)).accountId((String) hmInput.get(CommonDefs.ACCOUNT_ID)).accountType((String) hmInput.get(CommonDefs.MOBILITY_SERVICE))
//				.identificationType((String) hmInput.get(CommonDefs.IDENTIFICATION_TYPE)).deliveryMethods(deliveryMethods).build();
			notification.setTransactionName(ProfileOrchestrationConstants.TRANSACTION_NAME_GENERATE_PIN);
			notification.setAccountId((String) hmInput.get(CommonDefs.ACCOUNT_ID));
			notification.setAccountType((String)CommonDefs.MOBILITY_SERVICE);
			notification.setCallingSystemId((String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
			notification.setIdentificationType((String) hmInput.get(CommonDefs.IDENTIFICATION_TYPE));
			notification.setIdpTraceId((String) hmInput.get("idpTraceId"));
			notification.setDeliveryMethods(deliveryMethods);
			
		}
		return notification;
	}

	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The keepDigits method is used to extract all the digits from a given string.
	 * It takes a string as input, iterates over each character in the string, and checks if the character is a digit.
	 * If the character is a digit, it is appended to a StringBuilder.
	 * The method then returns the string representation of the StringBuilder, which contains all the digits from the input string in their original order.
	 *
	 * This method is useful when you need to process a string that contains digits mixed with other characters, and you are only interested in the digits.
	 * For example, you can use this method to extract the digits from a phone number that is formatted with non-digit characters (such as parentheses, spaces, or dashes).
	 *
	 * @param stPhone The string from which to extract the digits. It can contain any characters.
	 * @return A string containing all the digits from the input string, in their original order.
	 */
	public static String keepDigits(String stPhone) {
		StringBuilder stStringBuff = new StringBuilder();

		for (int i = 0; i < stPhone.length(); i++) {

			char c = stPhone.charAt(i);
			if (Character.isDigit(c)) {

				stStringBuff.append(c);
			}
		}
		return stStringBuff.toString();
	}
	
	/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The getDeliveryDetail method is used to convert an ArrayList of delivery details into a single string.
	 * It takes an ArrayList as input, iterates over its elements, and appends each element to a StringBuilder.
	 * Each element is separated by a comma, except for the last element.
	 *
	 * This method is useful when you need to convert a list of delivery details into a single string for logging, debugging, or other purposes where a textual representation of the list is needed.
	 *
	 * @param alDeliveryDetail The ArrayList of delivery details to be converted to a string. It can contain any objects, but they should have a meaningful string representation (i.e., their toString method should be overridden).
	 * @return A string representing the input ArrayList of delivery details. Each element is separated by a comma, except for the last element.
	 */
	public static String getDeliveryDetail(ArrayList alDeliveryDetail) {
		StringBuilder stReturnString = new StringBuilder();

		int n = alDeliveryDetail.size();

		for (int i = 0; i < alDeliveryDetail.size(); i++) {

			stReturnString.append(alDeliveryDetail.get(i));

			if (i != (n - 1)) {
				stReturnString.append(",");
			}
		}

		return stReturnString.toString();
	}


	public static String getTraceIdFromContextMap() {
		String stIdpTraceId = null;
		Map<String, String> contextMap = MDC.getCopyOfContextMap();
		if (contextMap != null && contextMap.get("idp-trace-id") != null) {
			stIdpTraceId = contextMap.get("idp-trace-id");
			logger.info("Context idp-trace-id: {}", StringUtils.normalizeSpace(stIdpTraceId));
		}
		return stIdpTraceId;
	}

/**
	 * This method is part of the CommonUtilHelper class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The generateGenericPassword method is used to generate a generic password based on the specified encryption type.
	 * It takes a HashMap containing password parameters and a string representing the encryption type as input.
	 *
	 * The method uses the MessageDigest class to compute the hash of the password using the specified algorithm (e.g., SHA256).
	 * It then encodes the resulting byte array into a Base64 string and returns a HashMap containing the generated password and its type.
	 *
	 * This method is useful when you need to generate a secure password based on a specific encryption algorithm.
	 *
	 * @param passwordParameters A HashMap containing the password parameters, including the clear text password under the key MPSDefs.WS_CLEAR_TEXT.
	 * @param genericPasswordEncryptionType The type of encryption to be used for generating the password (e.g., "SHA256").
	 * @return A HashMap containing the generated password under RILDefs.RIL_GEN_PASSWORD and its type under RILDefs.RIL_GEN_PASSWORD_TYPE.
	 */
	public static HashMap generateGenericPassword(HashMap passwordParameters, String genericPasswordEncryptionType) {
		HashMap statusTMS;
		String digest = "";
		byte[] digestBytes = null;
		String password = (String) passwordParameters.get(MPSDefs.WS_CLEAR_TEXT);
		String algorithm = null;

		switch (genericPasswordEncryptionType) {
			case "SHA256":
				algorithm = RILDefs.ENCRYPT_SHA256;
				break;
			default:
		}

		try {
			MessageDigest md = MessageDigest.getInstance(algorithm);
			md.reset();
			md.update(password.getBytes());
			digestBytes = md.digest();
			// Convert to BASE 64
			digest = CommonUtil.base64Encode(digestBytes);

		} catch (Exception e) {
			statusTMS = CommonErrorMap.makeExceptionMap(e, logger);
			return statusTMS;
		}
		statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG);
		statusTMS.put(RILDefs.RIL_GEN_PASSWORD, digest);
		statusTMS.put(RILDefs.RIL_GEN_PASSWORD_TYPE, genericPasswordEncryptionType);
		logger.debug("STATUS:: {} " , statusTMS);
		return statusTMS;
	}

	/**
	 * Sanitizes a string for safe logging by removing CR, LF, and other control characters.
	 */
	public static String sanitizeForLog(String input) {
		if (input == null) return null;
		// Remove CR, LF, and other non-printable control characters
		return input.replaceAll("[\\r\\n\\x00-\\x1F\\x7F]+", " ");
	}
}
