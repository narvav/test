package com.att.idp.idgraphcontactinfoms.model;

import java.io.Serializable;
import org.springframework.stereotype.Component;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * This class represents an error message that can be returned by the application.
 *
 * It contains several instance variables for storing the details of the error message, such as the message ID, application status message, application status code, application info, and transaction name.
 * The class uses the Spring Framework's @Component annotation to indicate that it is a bean and can be used for dependency injection.
 *
 * The class has a default constructor and a parameterized constructor for creating an instance of the class with the specified values.
 *
 * The class also contains getter and setter methods for each of the instance variables.
 *
 * The getErrorResponseInfo method is used to construct a JSON string representation of the error message.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Component
public class ErrorMessage implements Serializable {
	private static final long serialVersionUID = 3564385830384461845L;
	private String MessageId;
	private String appStatusMsg;
	private String appStatusCode;
	private String appInfo;
	private String transactionName;

	public String getErrorResponseInfo() {
		return "{"
				+ "\"appStatusCode\":\"" + appStatusCode + "\","
				+ "\"appStatusMsg\":\"" + appStatusMsg + "\","
				+ "\"appInfo\":\"" + appInfo + "\","
				+ "\"X-ATT-UniqueTransactionId\":\"" + MessageId + "\","
				+ "\"transactionName\":\"" + transactionName + "\""
				+ "}";
	}
}