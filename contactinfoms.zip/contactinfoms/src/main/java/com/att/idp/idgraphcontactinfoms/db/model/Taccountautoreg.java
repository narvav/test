package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "TACCOUNTAUTOREG", schema = "MPS_OWNER", uniqueConstraints = @UniqueConstraint(columnNames = { "SOR_ID",
		"SOR_INVARIANT_ID" }))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Taccountautoreg implements java.io.Serializable {

	private static final long serialVersionUID = -8302037290685173488L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "memberNum", column = @Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "sorId", column = @Column(name = "SOR_ID", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "sorInvariantId", column = @Column(name = "SOR_INVARIANT_ID", nullable = false)),
			@AttributeOverride(name = "createDate", column = @Column(name = "CREATE_DATE", nullable = false, length = 7)),
			@AttributeOverride(name = "lastModified", column = @Column(name = "LAST_MODIFIED", nullable = false, length = 7)),
			@AttributeOverride(name = "lastModifiedBy", column = @Column(name = "LAST_MODIFIED_BY", nullable = false)) })
	private TaccountautoregId id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MEMBER_NUM", nullable = false, insertable = false, updatable = false)
	private Tmember tmember;
}