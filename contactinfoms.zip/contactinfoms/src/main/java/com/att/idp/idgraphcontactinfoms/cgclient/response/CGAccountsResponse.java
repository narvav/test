package com.att.idp.idgraphcontactinfoms.cgclient.response;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(name = "CGAccountsResponse")
@Getter
@Setter
@NoArgsConstructor
public class CGAccountsResponse implements Serializable {

	private static final long serialVersionUID = 4168230317890701620L;

	@JsonProperty("contact")
	private CGContactResponse cgContactResponse;
	private String id;
	private String firstName;
	private String lastName;
	private String subMarket;
	private int subscribersCount;
	private String systemOfRecord;
	private String autoPayIndicator;
	private boolean secondaryPhoneNumberAttIndicator;
	private List<String> productTypes;
	private FanDetails fanDetails;
	private String state;
	private String bmgIndicator;
	private String businessVipInd;
	private String taxExemptStatus;
	private String companyCode;
	private String creditClass;
	private String isEmployee;
	private String securityLevelCode;
	private String bundleDiscExists;
	private String emailStatusUpdateDate;
	private String enterpriseType;
	private String amountDue;
	private String languagePreference;
	private String convergedCustomerOption;
	private boolean firstnetIndicator;
	private String emailStatus;
	private String billingAccountTypeDisplay;
	private String billingMarket;
	private int serviceDiscount;
	private String convergedCustomerOptionDisplay;
	private String billDueDate;
	private boolean hboMaxEntitlementIndicator;
	private String serviceType;
	private String accountType;
	private String accountSubType;
	private String statusReasonCode;
	private BigDecimal pastDue;
	private String createdOn;
	private String liabilityType;
	private boolean phoneNumberAttIndicator;
	private boolean customerInTreatment;
	private String profileType;
	private String statusReasonActivity;
	private String ratingType;
	private String statusReasonDescription;
	private String primaryAccountHolder;
}