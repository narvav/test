package com.att.idp.idgraphcontactinfoms.service.impl;

import java.util.Map;
import java.util.Random;

import jakarta.ws.rs.core.MultivaluedMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.idp.idgraphcontactinfoms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphcontactinfoms.helpers.GeneratePINHelper;
import com.att.idp.idgraphcontactinfoms.resource.request.GeneratePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.GeneratePINResponse;
import com.att.idp.idgraphcontactinfoms.service.GeneratePINService;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This class implements the GeneratePINService interface and is responsible for handling operations related to generating a Security PIN.
 *
 * It is annotated with @Service, indicating that it's a Spring Service.
 * The class has a dependency on GeneratePINHelper, which is autowired.
 * It also has a Logger instance for logging.
 *
 * The class has one main method: generatePIN.
 * This method takes a GeneratePINRequest and MultivaluedMap<String, String> as input parameters and returns a GeneratePINResponse.
 * The method is responsible for generating a Security PIN and handling the response.
 *
 * The class is also annotated with @Transactional, indicating that it's a transactional class with a specific transaction manager and rollback rules.
 */
@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class GeneratePINServiceImpl implements GeneratePINService {

	@Autowired
	private GeneratePINHelper generatePINHelper;

	public static final Logger logger = LoggerFactory.getLogger(GeneratePINServiceImpl.class);

	private static String sClassName = "GeneratePINServiceImpl";

	@Override
	public GeneratePINResponse generatePIN(GeneratePINRequest generatePINRequest,
			MultivaluedMap<String, String> requestHeader) {

		Map<String, Object> hmInput = null;
		Map<String, Object> hmResponse = null;
		String sMethodName = ".generatePIN.";

		hmInput = CommonUtilHelper.objectToMap(generatePINRequest);
		
		setDbusTransactionId(hmInput);

		logger.debug(SpiMarker.getInstance(),
				"GeneratePINServiceImpl.generatePIN.GPS_1.3 : Calling generatePINHelper with Input : {}",
				StructuredArguments.entries(hmInput));

		hmResponse = generatePINHelper.generatePin(hmInput);

		logger.info(SpiMarker.getInstance(),"GeneratePINServiceImpl.generatePIN.GPS_02 : Response from GeneratePin Helper : {}", StructuredArguments.entries(hmInput));

		if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
			hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from generatePINHelper.generatePin");
			logger.info("{}{}GPS_03 : Null response from generatePINHelper.generatePin", sClassName, sMethodName);
		} else {
			String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (stAppStatusCode == null) {
				hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from generatePINHelper.generatePin");
				logger.info("{}{}GPS_04 : Null response from generatePINHelper.generatePin", sClassName, sMethodName);
			}
		}

//		hmResponse.put(CommonDefs.TRANSACTION_ID, hmInput.get(CommonDefs.TRANSACTION_ID));
		hmResponse.put("idp-trace-id", generatePINRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME, generatePINRequest.getTransactionName());

		GeneratePINResponse generatePINResponse = (GeneratePINResponse) CommonUtilHelper
				.generateCIRResponse(hmResponse);

		String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

		if (sTxnRollBack != null) {
			throw new InvalidInputDataException(hmResponse);
		}
		logger.info(SpiMarker.getInstance(),"GeneratePINServiceImpl.generatePIN.GPS_05 : Response from GeneratePINServiceImpl.generatePIN : {}",
				generatePINResponse);
		return generatePINResponse;
	}
	
	private void setDbusTransactionId(Map<String, Object> hmInput) {

		String sMethodName=".setDbusTransactionId.";
		String idpTraceid = (String) hmInput.get("idpTraceId");

		 if(idpTraceid!=null && !idpTraceid.isBlank()) {

			hmInput.put("dbusTransactionId", idpTraceid.split(":")[0]);

		} 

	}
}
