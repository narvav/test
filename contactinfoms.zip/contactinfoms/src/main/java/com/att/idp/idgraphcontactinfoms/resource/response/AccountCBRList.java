package com.att.idp.idgraphcontactinfoms.resource.response;

import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.response package.
 *
 * The AccountCBRList class is used to represent a list of accounts with Customer Billing Records (CBR).
 * It contains several fields, each of which represents a parameter of the account.
 * These fields include accountType, accountInvariantId, and usPhoneNumber.
 *
 * The accountType field represents the type of the account.
 * The accountInvariantId field represents the invariant ID of the account.
 * The usPhoneNumber field is an object of the CBRUSPhoneNumber class, representing the US phone number associated with the account.
 *
 * Each field has a corresponding getter and setter method, allowing the fields to be accessed and modified.
 */
@Data
public class AccountCBRList {
	private String accountType;
	private String accountInvariantId;
	private CBRUSPhoneNumber usPhoneNumber;
}