package com.att.idp.idgraphcontactinfoms.model;

import com.att.idp.idgraph.events.model.JsonSealizable;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.ToString;

import java.time.Instant;

@Data
@ToString
public class SecurityAccountEvent implements JsonSealizable {
    private String accountType;
    private String cumulativeFailureCount;
    @JsonFormat(
            pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            shape = JsonFormat.Shape.STRING,
            timezone = "UTC"
    )
    private Instant accountEntryExpires;
    @JsonFormat(
            pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            shape = JsonFormat.Shape.STRING,
            timezone = "UTC"
    )
    private Instant createdDate;
    @JsonFormat(
            pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            shape = JsonFormat.Shape.STRING,
            timezone = "UTC"
    )
    private Instant updatedDate;
    private String updatedBy;
}
