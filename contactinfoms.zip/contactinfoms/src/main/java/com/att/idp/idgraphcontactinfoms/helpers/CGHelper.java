package com.att.idp.idgraphcontactinfoms.helpers;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import com.att.idp.cgclienthelpers.integration.CGRestClient;
import com.att.idp.http.client.config.RestTemplateBeanFactory;
import com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig;
import com.att.idp.idgraphcontactinfoms.integration.OutboundRestClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static com.att.idp.cd.observability.metrics.utils.Constants.GET;
import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_75;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_90;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_95;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_99;
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_OB;
import static com.att.idp.idgraphcontactinfoms.utils.Constants.IDGRAPH_CONTACT_INFO_MS_OB;

/**
 * The CGHelper class provides utility methods for interacting with the CGRestClient.
 * It includes functionality for making synchronous calls to the CG API and integrates
 * observability metrics using the @TimedMetrics annotation.
 */
@Component
public class CGHelper {
    public static final String REFRESHED_REST_TEMPLATE_BEAN = "refreshedRestTemplateBean";
    private static final Logger logger = LoggerFactory.getLogger(CGHelper.class);

    private static final String CG_REST_CLIENT = "cgrestclient";


    @Autowired
    private CGRestClient cgRestClient;
    private RestTemplate restTemplate;


    private IDGraphAzureAppConfig appConfiguration;
    private final RestTemplateBeanFactory restTemplateFactory;
    private OutboundRestClientBuilder outboundRestClientBuilder;

    public CGHelper() {
        this.restTemplateFactory = null;
        this.appConfiguration = null;
        this.outboundRestClientBuilder = null;
    }


    @Autowired
    public CGHelper(RestTemplateBeanFactory restTemplateBeanFactory, IDGraphAzureAppConfig appConfiguration, OutboundRestClientBuilder outboundRestClientBuilder) throws Exception {
        this.restTemplateFactory = restTemplateBeanFactory;
        this.appConfiguration = appConfiguration;
        this.outboundRestClientBuilder = outboundRestClientBuilder;
        this.restTemplate = restTemplateFactory.getObject(CG_REST_CLIENT);
    }

    @PostConstruct
    public void init() {
        this.restTemplate = this.initializeRestTemplate(this.restTemplate);
        logger.info("RestTemplate connectTimeout={} ms, readTimeout={} ms", appConfiguration.getCgConnectTimeout(), appConfiguration.getCgReadTimeout());
    }

    /**
     * Handles the refresh event triggered by the Spring Cloud RefreshScope.
     * <p>
     * This method is invoked when the application context is refreshed, typically due to
     * configuration changes. It synchronizes the update of the `RestTemplate` instance
     * with new timeout values retrieved from the `IDGraphAzureAppConfig` bean.
     * If the update fails, the method logs the error and retains the existing `RestTemplate`.
     *
     * @throws Exception if an error occurs while updating the `RestTemplate` instance.
     */
    @EventListener(RefreshScopeRefreshedEvent.class)
    public void onConfigurationRefresh() throws Exception {
        if (appConfiguration.isCgRestClientRefreshEnabled()) {
            synchronized (this) {
                try {

                    if (this.restTemplate == null) {
                        this.restTemplate = restTemplateFactory.getObject(CG_REST_CLIENT);
                    }

                    this.restTemplate = initializeRestTemplate(this.restTemplate);

                    logger.info("CGRestClient dynamically updated with new timeout values: connectTimeout={} ms, readTimeout={} ms", appConfiguration.getCgConnectTimeout(), appConfiguration.getCgReadTimeout());
                } catch (Exception e) {
                    // Log the error and retain the old RestTemplate
                    logger.error("Failed to update CGHelper RestTemplate with new timeout values. Retaining the old RestTemplate.", e);
                }
            }
        } else {
            logger.info("CGRestClient refresh is disabled. Retaining the existing RestTemplate.");
        }
    }

    private RestTemplate initializeRestTemplate(RestTemplate restTemplate) {
        try {
            if (restTemplate == null) {
                restTemplate = restTemplateFactory.getObject(CG_REST_CLIENT);
            }
            restTemplate = outboundRestClientBuilder.buildRestTemplate(restTemplate, appConfiguration.getCgConnectTimeout(), appConfiguration.getCgReadTimeout(), false, null);
            logger.info("Initializing RestTemplate dynamically updated from azureappconfig with new timeout values: connectTimeout={} ms, readTimeout={} ms", appConfiguration.getCgConnectTimeout(), appConfiguration.getCgReadTimeout());
        } catch (Exception e) {
            logger.error("Error in initializing RestTemplate for Cgrestclient: {}", e.getMessage(), e);
        }
        return restTemplate;
    }


    /**
     * Makes a synchronous call to the CG API using the provided input parameters and endpoint.
     * This method is annotated with @TimedMetrics to capture observability metrics such as
     * execution time and percentiles for performance monitoring.
     *
     * @param hmCGInput A HashMap containing the input parameters for the CG API call.
     * @param uri       The endpoint URL to be used for the CG API call.
     * @return A Map containing the response from the CG API.
     * @throws IOException If an I/O error occurs during the API call.
     */
    @TimedMetrics(name = IDGRAPH_CONTACT_INFO_MS_OB, type = REST_OB, description = "CG search API", tags = {METHOD, GET}, histogram = true, percentiles = {PERCENTILE_75, PERCENTILE_90, PERCENTILE_95, PERCENTILE_99}, paramKeys = {"uri"})
    public Map<String, Object> makeCGSyncCall(HashMap<String, Object> hmCGInput, String uri) throws IOException {
        if (hmCGInput != null) {
            hmCGInput.put(REFRESHED_REST_TEMPLATE_BEAN, this.restTemplate);
            hmCGInput.put("cgEndPoint", uri);
            return cgRestClient.getCGSyncCall(hmCGInput);
        }
        return new HashMap<>();
    }
}