package com.att.idp.idgraphcontactinfoms.helpers;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphcontactinfoms.integration.InquireProfileRestClient;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.fasterxml.jackson.databind.node.ArrayNode;

/**
 * This class is a helper class for querying CPNI user contact information.
 *
 * It contains methods for querying CPNI user contact information based on the input parameters.
 * The class uses the Spring Framework's @Component annotation to indicate that it is a bean and can be used for dependency injection.
 *
 * The class has several instance variables that are injected using the @Autowired annotation.
 * These variables are used to interact with various other helper classes and services to process and query CPNI user contact information.
 *
 * The main method in this class is the queryCPNIUserContact method, which takes a HashMap as input and returns a HashMap as output.
 * The queryCPNIUserContact method uses several other methods in the class to validate the input data, process the input data, and store the data.
 *
 * The class also contains a logger for logging information and error messages.
 */
@Component
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class QueryCPNIUserContactHelper {

	@Autowired
	private InquireProfileRestClient inquireProfileRestClient;

	@Autowired
	private InquireUserContactInfoHelper inquireUserContactInfoHelper;

	@Autowired
	private CommonUtilHelper oCommonUtilHelper;
	
	@Autowired
	private	ExternalDestinationHelper externalDestinationHelper;

	@Autowired
	private QueryCPNIAcccountContactHelper queryCPNIAccountContactHelper;

	@Autowired
	private CPNIDataAddressHelper objCPNIDataAddressHelper;

	@Autowired
	private InquireContactInfoHelper inquireContactInfoHelper;
	
	@Value("${PROP_CPNI_ACCOUNTS}")
	private String stValidCPNIAccts;
	
	@Value("${SIM_SWAP_AGING_DAYS}")
	private String sSimSwapAgingDays;

	private static String sClassName = "QueryCPNIUserContactHelper";
	public static final Logger log = LoggerFactory.getLogger(QueryCPNIUserContactHelper.class);

	/**
	 * This method queries CPNI user contact information based on the input parameters.
	 *
	 * It first retrieves various parameters from the input HashMap such as the calling system ID, handle, domain, GUID, transaction name, returnCBRCTNs, and transaction ID.
	 * It then constructs a new HashMap for the InquireProfileRestClient input and populates it with the necessary parameters.
	 * The method calls the InquireProfileRestClient's postInquireProfileSyncCall method with the new HashMap as input and checks the response.
	 * If the response indicates an error, the method constructs an error response and returns it.
	 * If the response from the InquireProfileRestClient indicates success, the method processes the user contact email and MOSUB details.
	 * Finally, it constructs a success response with the user contact list and account contact list and returns it.
	 *
	 * @param hmInput a HashMap that contains the input data for the CPNI user contact information query. The HashMap should include the calling system ID, handle, domain, GUID, transaction name, returnCBRCTNs, and transaction ID.
	 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code, an application info message, and the queried CPNI user contact information.
	 * @throws Exception if an error occurs during the operation.
	 */
	public HashMap queryCPNIUserContact(HashMap<String, Object> hmInput) {
		String sMethodName = ".queryCPNIUserContact.";
		log.info("{}{}HLP000 : Input Hash : {}", sClassName, sMethodName, hmInput);
		HashMap<String, Object> hmResult = null;
		HashMap<String, Object> hmResponse = null;
		String stAppInfo = null;
		String stAppStatusCode = null;

		try {
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sHandle = (String) hmInput.get(CommonDefs.HANDLE);
			String sDomain = (String) hmInput.get(CommonDefs.DOMAIN);
			String sGuid = (String) hmInput.get(CommonDefs.GUID);
			String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
			String sReturnCBRCTNs = (String) hmInput.get("returnCBRCTNs");
			String sTransactionId = (String) hmInput.get("idpTraceId");

			HashMap<String, String> hmInqProfileInp = CommonUtil.getHashMap();
			hmInqProfileInp.put(CommonDefs.LEVEL, "LM");
			hmInqProfileInp.put(CommonDefs.IS_EXTERNAL_CALL, CommonDefs.IND_N);

			if (sGuid != null && !sGuid.isEmpty()) {
				hmInqProfileInp.put(CommonDefs.GUID, sGuid);
			} else {
				hmInqProfileInp.put("userId", sHandle);
			}

			log.info("{}{}QCUCH_01 : Calling InquireProfileRestClient.postInquireProfileSyncCall() with hmInqProfileInp : {}",
					sClassName, sMethodName, hmInqProfileInp);

			HashMap<String, Object> hmInqProfileResp = (HashMap<String, Object>) inquireProfileRestClient.postInquireProfileSyncCall(hmInqProfileInp, sTransactionId,sCallingSystemId);

			log.info("{}{}QCUCH_02 : Response from InquireProfileRestClient.postInquireProfileSyncCall() : {}", sClassName, sMethodName,
					hmInqProfileResp);

			if (hmInqProfileResp == null || hmInqProfileResp.isEmpty()) {
				stAppInfo = "Null Response returned from InquireProfileRestClient.postInquireProfileSyncCall()";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				log.info("{}{}QCUCH_03 : {}", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}

			stAppStatusCode = (String) hmInqProfileResp.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				log.info("{}{}QCUCH_04 : {}", sClassName, sMethodName, hmInqProfileResp);
				return hmInqProfileResp;
			}

			HashMap<String, Object> hmDBMemberInfo = (HashMap<String, Object>) hmInqProfileResp.get("member");

			if (sGuid != null && !sGuid.isEmpty()) {
				String sDBDomain = (String) hmDBMemberInfo.get("domainName");
				if (sDBDomain != null && !sDBDomain.isEmpty() && !sDBDomain.equals(CommonDefs.SLID_DUM)) {
					stAppInfo = "Input Member is not an Access ID";
					log.info("{}{}QCUCH_05 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
					return hmResult;
				}
			} else {
				sGuid = (String) hmDBMemberInfo.get(CommonDefs.MEMBER_NUM);
				hmInput.put(CommonDefs.GUID, sGuid);
			}

			if (sHandle == null || sHandle.isEmpty() || sDomain == null || sDomain.isEmpty()) {
				sHandle = (String) hmDBMemberInfo.get(CommonDefs.MEMBER_NAME);
				sDomain = (String) hmDBMemberInfo.get("domainName");

				hmInput.put(CommonDefs.HANDLE, sHandle);
				hmInput.put(CommonDefs.DOMAIN, sDomain);
			}

			ArrayList alMemSvcRole = (ArrayList) hmInqProfileResp.get("memberServiceRole");
			ArrayList alLinkedUsers = (ArrayList) hmInqProfileResp.get("linkedMember");

			log.debug("{}{}QCUCH_06 : member Hash from inquireProfile operation : {}", sClassName, sMethodName,
					 StringUtils.normalizeSpace(hmDBMemberInfo!=null ? hmDBMemberInfo.toString() : null));


			log.debug("{}{}QCUCH_07 : memberServiceRole list from inquireProfile operation : {}", sClassName,
					sMethodName, StringUtils.normalizeSpace(alMemSvcRole!=null ? alMemSvcRole.toString() : null));

			log.debug("{}{}QCUCH_08 : linkedMember list from inquireProfile operation : {}", sClassName, sMethodName,
					StringUtils.normalizeSpace(alLinkedUsers!=null ? alLinkedUsers.toString() : null));

			HashMap<String, Object> hmUserEmailContactCPNIResponse = queryCPNIUserContactEmail(hmInput, hmDBMemberInfo);

			stAppStatusCode = (String) hmUserEmailContactCPNIResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
				log.info("{}{}QCUCH_09 : {}", sClassName, sMethodName, hmUserEmailContactCPNIResponse);
			}

			ArrayList alUserContactList = CommonUtil.getArrayList();

			if (hmUserEmailContactCPNIResponse != null
					&& hmUserEmailContactCPNIResponse.containsKey(CommonDefs.KEY_EMAIL)) {
				HashMap<String, Object> hmUserEmail = (HashMap<String, Object>) hmUserEmailContactCPNIResponse.get(CommonDefs.KEY_EMAIL);

				if (hmUserEmail != null && !hmUserEmail.isEmpty()) {
					HashMap<String, Object> hmUserContact = CommonUtil.getHashMap();
					hmUserContact.put(CommonDefs.KEY_EMAIL, hmUserEmail);
					alUserContactList.add(hmUserContact);
				}
			}

			String sIncludeMosub = "N";
			HashMap<String, Object> hmMOSUBCTN = null;

			HashMap<String, Object> hmMOSUB = getMOSUBDetails(alMemSvcRole);

			if (hmMOSUB != null && !hmMOSUB.isEmpty()) {
				boolean isEnabledCPNIAcct = isEnabledCPNIAcctPresent(alMemSvcRole);
				log.info("{}{}QCUCH_10 : Enabled CPNI Account in DB : {}", sClassName, sMethodName, isEnabledCPNIAcct);
				
				if (!isEnabledCPNIAcct) {
					sIncludeMosub = "Y";
				} 

				hmMOSUBCTN = CommonUtil.getHashMap();
				hmMOSUBCTN.put(CommonDefs.TRANSACTION_ID, sTransactionId);
				hmMOSUBCTN.put(CommonDefs.TRANSACTION_NAME, "QueryCPNIAccountContactInfo");
				hmMOSUBCTN.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
				hmMOSUBCTN.put(CommonDefs.EVENTNAME, "QueryCSIInquireSubscriberProfile");
				hmMOSUBCTN.put(CommonDefs.SUBSCRIBER_MASK, "SD:DI");
				hmMOSUBCTN.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_DICTIONARY_NAME_VALUE);
				hmMOSUBCTN.put(CommonDefs.CTN, hmMOSUB.get("instanceId"));
			}

			ArrayList alAcctContactList = null;
			HashMap<String, Object> hmCSIMosubResp = null;

			HashMap hmOnlyOneCPNIEnabledAccount = getOnlyOneEnabledCPNIOWNERAccount(alMemSvcRole);

			if (hmOnlyOneCPNIEnabledAccount != null && !hmOnlyOneCPNIEnabledAccount.isEmpty()) {
				HashMap<String, Object> hmAcctInput = CommonUtil.getHashMap();

				hmAcctInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
				hmAcctInput.put(CommonDefs.TRANSACTION_NAME, "QueryCPNIAccountContactInfo");
				hmAcctInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);

				String sSorInvarientId = (String) hmOnlyOneCPNIEnabledAccount.get(CommonDefs.SOR_INVARIANT_ID);
				hmAcctInput.put(CommonDefs.ACCOUNT_INVARIANT_ID, sSorInvarientId);

				String sAcctType = (String) hmOnlyOneCPNIEnabledAccount.get(CommonDefs.SERVICE_NAME);
				hmAcctInput.put(CommonDefs.ACCOUNT_TYPE, sAcctType);

				if (CommonDefs.MOBILITY_SERVICE.equals(sAcctType)) {
					hmAcctInput.put("filterSIMSwapCTNs", CommonDefs.IND_Y);
				}

				hmAcctInput.put(CommonDefs.ACTIVATED_IND, (String) hmDBMemberInfo.get(CommonDefs.ACTIVATED_IND));

				if (hmMOSUBCTN != null && !hmMOSUBCTN.isEmpty()) {
					hmAcctInput.put("mosubCTN", hmMOSUBCTN);
				}

				log.debug(
						"{}{}QCPNI_U_56 : Calling queryCPNIAccountContactHelper.queryCPNIAccountContact() with hmAcctInput : {}",
						sClassName, sMethodName, hmAcctInput);

				HashMap hmAcctContactCPNIResp = queryCPNIAccountContactHelper.queryCPNIAccountContact(hmAcctInput);

				log.debug("{}{}QCPNI_U_57 : Response from queryCPNIAccountContactHelper.queryCPNIAccountContact() : {}",
						sClassName, sMethodName, hmAcctContactCPNIResp);

				stAppStatusCode = (String) hmAcctContactCPNIResp.get(CErrorDefs.COMMON_APP_STATUS_CODE);
				if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					log.info("{}{}QCPNI_U_58 : {}", sClassName, sMethodName, hmAcctContactCPNIResp);
				}

				hmCSIMosubResp = CommonUtil.getMap(hmAcctContactCPNIResp, "mosubCTN");

				if ((CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					alAcctContactList = CommonUtil.getList(hmAcctContactCPNIResp, CommonDefs.ACCOUNT_CONTACT_LIST);
				}

				if (alLinkedUsers != null && !alLinkedUsers.isEmpty()
						&& CommonDefs.MOBILITY_SERVICE.equals(sAcctType)) {
					if (alAcctContactList != null && !alAcctContactList.isEmpty()) {
						ArrayList alTempContactList = CommonUtil.getArrayList();
						alTempContactList.addAll(alAcctContactList);
						for (int k = 0; k < alTempContactList.size(); k++) {
							HashMap hmContact = (HashMap) alTempContactList.get(k);
							if (hmContact.containsKey(CommonDefs.US_PHONE_NUMBER)) {
								alAcctContactList.remove(hmContact);
							}
						}
					}
				}
			} else {
				HashMap hmDefaultEnabledCPNIMultiAccount = getDefaultEnabledCPNIMultiAccount(alMemSvcRole);

				if (hmDefaultEnabledCPNIMultiAccount != null && !hmDefaultEnabledCPNIMultiAccount.isEmpty()) {

					HashMap<String, Object> hmAcctInput = CommonUtil.getHashMap();

					hmAcctInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
					hmAcctInput.put(CommonDefs.TRANSACTION_NAME, "QueryCPNIAccountContactInfo");
					hmAcctInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);

					String sSorInvarientId = (String) hmDefaultEnabledCPNIMultiAccount.get(CommonDefs.SOR_INVARIANT_ID);
					hmAcctInput.put(CommonDefs.ACCOUNT_INVARIANT_ID, sSorInvarientId);

					String sAcctType = (String) hmDefaultEnabledCPNIMultiAccount.get(CommonDefs.SERVICE_NAME);
					hmAcctInput.put(CommonDefs.ACCOUNT_TYPE, sAcctType);

					if (CommonDefs.MOBILITY_SERVICE.equals(sAcctType)) {
						hmAcctInput.put("filterSIMSwapCTNs", CommonDefs.IND_Y);
					}

					hmAcctInput.put(CommonDefs.ACTIVATED_IND, (String) hmDBMemberInfo.get(CommonDefs.ACTIVATED_IND));

					if (hmMOSUBCTN != null && !hmMOSUBCTN.isEmpty()) {
						hmAcctInput.put("mosubCTN", hmMOSUBCTN);
					}

					log.debug(
							"{}{}QCPNI_U_56.8 : Calling queryCPNIAccountContactHelper.queryCPNIAccountContact() with hmAcctInput : {}",
							sClassName, sMethodName, hmAcctInput);

					HashMap hmAcctContactCPNIResp =queryCPNIAccountContactHelper.queryCPNIAccountContact(hmAcctInput);

					log.debug(
							"{}{}QCPNI_U_57.9 : Response from queryCPNIAccountContactHelper.queryCPNIAccountContact() : {}",
							sClassName, sMethodName, hmAcctContactCPNIResp);

					stAppStatusCode = (String) hmAcctContactCPNIResp.get(CErrorDefs.COMMON_APP_STATUS_CODE);
					if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
						log.info("{}{}QCPNI_U_58.8 : {}", sClassName, sMethodName, hmAcctContactCPNIResp);
					}

					hmCSIMosubResp = CommonUtil.getMap(hmAcctContactCPNIResp, "mosubCTN");

					if ((CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
						alAcctContactList = CommonUtil.getList(hmAcctContactCPNIResp, CommonDefs.ACCOUNT_CONTACT_LIST);
					}

					if (alLinkedUsers != null && !alLinkedUsers.isEmpty()
							&& CommonDefs.MOBILITY_SERVICE.equals(sAcctType)) {
						if (alAcctContactList != null && !alAcctContactList.isEmpty()) {
							ArrayList alTempContactList = CommonUtil.getArrayList();
							alTempContactList.addAll(alAcctContactList);
							for (int k = 0; k < alTempContactList.size(); k++) {
								HashMap hmContact = (HashMap) alTempContactList.get(k);
								if (hmContact.containsKey(CommonDefs.US_PHONE_NUMBER)) {
									alAcctContactList.remove(hmContact);
								}
							}
						}
					}

				}
			}

			if (hmMOSUBCTN != null && !hmMOSUBCTN.isEmpty() && (hmCSIMosubResp == null || hmCSIMosubResp.isEmpty())) {
				hmMOSUBCTN.put(CommonDefs.TRANSACTION_NAME, sTransactionName);

				HashMap<String, Object> hmDbusInput = CommonUtil.getHashMap();
				hmDbusInput.put("mosubCTN", hmMOSUBCTN);

				log.debug(
						"{}{}QCPNI_U_54 : Calling externalDestinationHelper.callMultipleDestinations() with hmDbusInput : {}",
						sClassName, sMethodName, hmDbusInput);

				HashMap hmDbusResp =
						externalDestinationHelper.callMultipleDestinations(hmDbusInput);

				log.debug("{}{}QCPNI_U_55 : Response from externalDestinationHelper.callMultipleDestinations() : {}",
						sClassName, sMethodName, hmDbusResp);

				stAppStatusCode = (String) hmDbusResp.get(CErrorDefs.COMMON_APP_STATUS_CODE);
				if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					log.info("{}{}QCPNI_U_08 : {}", sClassName, sMethodName, hmDbusResp);
				}

				hmCSIMosubResp = (HashMap) hmDbusResp.get("mosubCTN");
			}
			
			if (hmCSIMosubResp != null && !hmCSIMosubResp.isEmpty() && !sIncludeMosub.equals(CommonDefs.IND_Y)) {
				
				List alSubscribers = null;
				String ban = null;
				HashMap hmAccount = (HashMap) hmCSIMosubResp.get("accounts");
				if (hmAccount != null)
					ban = (String) hmAccount.get("id");
				ArrayNode aNsubcriber = (ArrayNode) hmCSIMosubResp.get("subscribers");
				if (aNsubcriber != null) {
					alSubscribers = CommonUtilHelper.convertToList(aNsubcriber);
				}
				
				if (alSubscribers != null && alSubscribers.size() > 0) {
					HashMap hmMOSUBSubscriber = (HashMap) alSubscribers.get(0);
					hmMOSUBSubscriber.put(CommonDefs.BILLING_ACCOUNT_NUMBER,ban);
					if (hmMOSUBSubscriber != null) {
						String sBillingIdOfMOSUBCTN = null;
						if (hmMOSUBSubscriber.containsKey(CommonDefs.BILLING_ACCOUNT_NUMBER)) {
							sBillingIdOfMOSUBCTN = (String) hmMOSUBSubscriber.get(CommonDefs.BILLING_ACCOUNT_NUMBER);
						}

						ArrayList alMOBILITYSorInvariantId = CommonUtil.getArrayList();
						if (alMemSvcRole != null && !alMemSvcRole.isEmpty()) {
							for (int k = 0; k < alMemSvcRole.size(); k++) {
								HashMap hmDBService = (HashMap) alMemSvcRole.get(k);
								String sDBSvcName = (String) hmDBService.get(CommonDefs.SERVICE_NAME);

								if (sDBSvcName != null && !sDBSvcName.isEmpty()
										&& sDBSvcName.equals(CommonDefs.MOBILITY_SERVICE)) {
									alMOBILITYSorInvariantId.add(hmDBService.get(CommonDefs.SOR_INVARIANT_ID));
								}
							}
						}
						
						if (alMOBILITYSorInvariantId != null
								&& alMOBILITYSorInvariantId.contains(sBillingIdOfMOSUBCTN)) {
							sIncludeMosub = "Y";
						}
					}
				}
			}
			
			if (sIncludeMosub.equals(CommonDefs.IND_Y)) {
				HashMap hmUserMOSUBCPNIResponse = processMOSUBCPNIAddresses(hmInput, hmMOSUB, hmCSIMosubResp);

				stAppStatusCode = (String) hmUserMOSUBCPNIResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);
				if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					log.info("{}{}QCPNI_U_69 : {}", sClassName, sMethodName, hmUserMOSUBCPNIResponse);
				}

				HashMap hmUSPhoneDetails = CommonUtil.getMap(hmUserMOSUBCPNIResponse, CommonDefs.US_PHONE_NUMBER);

				if (hmUSPhoneDetails != null && !hmUSPhoneDetails.isEmpty()) {
					HashMap hmMOSUBContact = CommonUtil.getHashMap();
					hmMOSUBContact.put(CommonDefs.US_PHONE_NUMBER, hmUSPhoneDetails);
					alUserContactList.add(hmMOSUBContact);
				}
			}

			hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

			if (alUserContactList != null && !alUserContactList.isEmpty()) {
				hmResponse.put("userContactList", alUserContactList);
			}

			if (alAcctContactList != null && !alAcctContactList.isEmpty()) {
				hmResponse.put("accountContactList", alAcctContactList);
			}

			if (sReturnCBRCTNs != null && sReturnCBRCTNs.equalsIgnoreCase(CommonDefs.IND_Y)) {
				HashMap hmResponseCBR = queryCPNIUserAndAccountCBR(hmInput, hmInqProfileResp);

				if (hmResponseCBR != null && !hmResponseCBR.isEmpty()) {
					hmResponse.putAll(hmResponseCBR);
				}
			}

		} catch (Exception e) {
			hmResponse = CommonErrorMap.makeExceptionMap(e, log);
		} finally {
			if (hmResponse == null || hmResponse.isEmpty()) {
				stAppInfo = "Response from QueryCPNIUserContactHelper is NULL";
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			}
			log.info("{}{}HLP999 : response from QueryCPNIUserContactHelper : {}", sClassName, sMethodName, hmResponse);
		}
		return hmResponse;
	}

	/**
	 * 
	 * @param sDateKey
	 * @param sDateValue
	 * @return String
	 */
	private static String formatDate(String sDateKey, String sDateValue) {
		String sMethodName = ".formatDate.";
		Date dtParsedDate = null;
		String sFormattedDate = null;

		try {
			DateFormat sdfCustActiveDt = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat sdfTimeModified = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat sdfEmailAddrDt = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat newDtFormat = new SimpleDateFormat("MMddyyyy HH:mm:ss");

			// parse input date
			if (sDateKey != null && sDateKey.equals(CommonDefs.CUSTOMER_ACTIVE_DATE))
				dtParsedDate = sdfCustActiveDt.parse(sDateValue);
			if (sDateKey != null && sDateKey.equals(CommonDefs.TIME_MODIFIED))
				dtParsedDate = sdfTimeModified.parse(sDateValue);
			if (sDateKey != null && sDateKey.equals("EmailAddrLastUpdateTs"))
				dtParsedDate = sdfEmailAddrDt.parse(sDateValue);
			if (sDateKey != null && sDateKey.equals("establishDate"))
				dtParsedDate = sdfEmailAddrDt.parse(sDateValue);

			if (sDateKey != null && sDateKey.equals(CommonDefs.SIM_SWAP_DATE) && sDateValue != null && !sDateValue.isEmpty()) {

				DateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				dtParsedDate = simpleDateFormat.parse(sDateValue);
				newDtFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
			}

			// convert to new date format
			sFormattedDate = newDtFormat.format(dtParsedDate);
			log.info("{}{}FD_01 : {} : {}, Formatted Date : {}", sClassName, sMethodName, sDateKey, sDateValue,
					sFormattedDate);

		} catch (Exception exp) {
			log.error("{}{}ET_CPNI_H_06.11 : Exception = {}", sClassName, sMethodName, exp);
		}

		return sFormattedDate;
	}

	/**
	 * 
	 * @param hmInput
	 * @param hmDBMemberInfo
	 * @return HashMap
	 */
	private HashMap queryCPNIUserContactEmail(HashMap hmInput, HashMap hmDBMemberInfo) {
		String sMethodName = ".queryCPNIUserContactEmail.";
		String stAppStatusCode = null;

		String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
		String sGuid = (String) hmInput.get(CommonDefs.GUID);
		String sTransactionId = (String) hmInput.get("idpTraceId");

		HashMap<String, Object> hmInqContactEmailInp = CommonUtil.getHashMap();
		hmInqContactEmailInp.put(CommonDefs.TRANSACTION_NAME, "InquireUserContactInfo");
		hmInqContactEmailInp.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
		hmInqContactEmailInp.put(CommonDefs.GUID, sGuid);
		hmInqContactEmailInp.put(CommonDefs.TRANSACTION_ID, sTransactionId);

		log.debug(
				"{}{}QCPNI_U_52 : Calling inquireContactEmailHelper.inquireUserContactInfo() with hmInqContactEmailInp : {}",
				sClassName, sMethodName, hmInqContactEmailInp);

		HashMap hmUserContactEmail = inquireUserContactInfoHelper.inquireUserContactInfo(hmInqContactEmailInp);

		log.debug("{}{}QCPNI_U_53 : Response from inquireContactEmailHelper.inquireUserContactInfo() : {}", sClassName,
				sMethodName, hmUserContactEmail);

		stAppStatusCode = (String) hmUserContactEmail.get(CErrorDefs.COMMON_APP_STATUS_CODE);
		if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
			log.info("{}{}QCPNI_U_06 : {}", sClassName, sMethodName, hmUserContactEmail);
			return hmUserContactEmail;
		}

		HashMap hmUserEmailContactCPNIResp = processUserCPNIAddresses(hmInput, hmDBMemberInfo, hmUserContactEmail);

		return hmUserEmailContactCPNIResp;
	}

	/**
	 * 
	 * @param hmInput
	 * @param hmMemberDBInfo
	 * @param hmUserContactEmail
	 * @return HashMap
	 */
	private HashMap processUserCPNIAddresses(HashMap hmInput, HashMap hmMemberDBInfo, HashMap hmUserContactEmail) {
		String sMethodName = ".processUserCPNIAddresses.";

		HashMap<String, Object> hmResponse = null;
		String stAppInfo = null;
		String stAppStatusCode = null;
		String stAppCatogoryCode = null;

		log.info("{}{}QCPNIUCH_000 : Input Hash : {}", sClassName, sMethodName, hmInput);

		try {

			hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
			String sContactEmail = (String) hmUserContactEmail.get(CommonDefs.CONTACT_EMAIL);

			if (sContactEmail == null || sContactEmail.isEmpty()) {
				return hmResponse;
			}

			HashMap<String, Object> hmContactInfo = CommonUtil.getHashMap();

			hmContactInfo.put(CommonDefs.KEY_EMAIL_ADDRESS, sContactEmail);
			hmContactInfo.put(CommonDefs.KEY_CONTACT_TYPE, (String) CommonDefs.CONTACT_TYPE_PRIMARY_EMAIL);
			hmContactInfo.put(CommonDefs.KEY_CONTACT_STATUS,
					(String) hmUserContactEmail.get(CommonDefs.CONTACT_EMAIL_STATUS));
			hmContactInfo.put(CommonDefs.KEY_EMAIL_EST_DATE,
					(String) hmUserContactEmail.get(CommonDefs.CONTACT_EMAIL_EST_DATE));
			hmContactInfo.put(CommonDefs.KEY_ACCOUNT_CREATE_DATE, (String) hmMemberDBInfo.get(CommonDefs.CREATE_DATE));

			ArrayList alContactInfo = new ArrayList();
			alContactInfo.add(hmContactInfo);

			HashMap<String, Object> hmCPNIHelperInput = CommonUtil.getHashMap();
			hmCPNIHelperInput.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(CommonDefs.TRANSACTION_ID));
			hmCPNIHelperInput.put(CommonDefs.TRANSACTION_NAME, (String) hmInput.get(CommonDefs.TRANSACTION_NAME));
			hmCPNIHelperInput.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
			hmCPNIHelperInput.put(CommonDefs.CONTACT_INFO, alContactInfo);

			log.info("{}{}QCPNIUCH_003 : Calling CPNIDataAddressHelper.validateCPNIAddress with hmCPNIHelperInput : {}",
					sClassName, sMethodName, hmCPNIHelperInput);

			HashMap hmCPNIDataAddressResult=objCPNIDataAddressHelper.validateCPNIAddress(hmCPNIHelperInput);

			log.info("{}{}QCPNIUCH_004 : Response from CPNIDataAddressHelper.validateCPNIAddress : {}", sClassName,
					sMethodName, hmCPNIDataAddressResult);

			stAppStatusCode = (String) hmCPNIDataAddressResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
			stAppCatogoryCode = (String) hmCPNIDataAddressResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);

			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				if (stAppCatogoryCode != null && stAppCatogoryCode.equals(CErrorDefs.CATEGORY_CODE_SYSTEM_ERROR)) {
					stAppInfo = (String) hmCPNIDataAddressResult.get(CommonDefs.COMMON_APP_INFO);
					log.info("{}{}QCPNIUCH_005 : {}", sClassName, sMethodName, stAppInfo);
					hmResponse = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
					return hmResponse;
				} else {
					stAppInfo = (String) hmCPNIDataAddressResult.get(CommonDefs.COMMON_APP_INFO);
					log.info("{}{}QCPNIUCH_006 : {}", sClassName, sMethodName, stAppInfo);

				}
			} else {

				ArrayList alValidAddresses = (ArrayList) hmCPNIDataAddressResult.get(CommonDefs.VALID_CPNI_ADDRESSES);

				HashMap<String, Object> hmValidAddresses = null;
				if (alValidAddresses != null && !alValidAddresses.isEmpty()) {
					for (int i = 0; i < alValidAddresses.size(); i++) {
						hmValidAddresses = (HashMap) alValidAddresses.get(i);
						if (hmValidAddresses != null && !hmValidAddresses.isEmpty()) {

							HashMap<String, Object> hmEmail = CommonUtil.getHashMap();
							hmEmail.put(CommonDefs.CONTACT_EMAIL, hmValidAddresses.get(CommonDefs.KEY_EMAIL_ADDRESS));

							HashMap<String, Object> hmGeneralContactDetails = CommonUtil.getHashMap();

							hmGeneralContactDetails.put(CommonDefs.CONTACT_TYPE,
									(String) hmValidAddresses.get(CommonDefs.KEY_CONTACT_TYPE));
							hmGeneralContactDetails.put(CommonDefs.CONTACT_STATUS,
									(String) hmValidAddresses.get(CommonDefs.KEY_CONTACT_STATUS));
							hmGeneralContactDetails.put(CommonDefs.ESTABLISHED_DATE,
									(String) hmValidAddresses.get(CommonDefs.KEY_EMAIL_EST_DATE));
							hmGeneralContactDetails.put(CommonDefs.CPNI_ELGIBLE, CommonDefs.IND_Y);

							hmEmail.put(CommonDefs.GENERAL_CONTACT_DETAILS, hmGeneralContactDetails);
							hmResponse.put(CommonDefs.KEY_EMAIL, hmEmail);

						}
					}
				}
			}

		} catch (Exception exp) {
			hmResponse = CommonErrorMap.makeExceptionMap(exp, log);
		}
		return hmResponse;
	}

	/**
	 * 
	 * @param alDBMemSvc
	 * @return boolean
	 */
	private boolean isEnabledCPNIAcctPresent(ArrayList alDBMemSvc) {
		String sMethodName = ".isEnabledCPNIAcctPresent.";
		boolean isCPNIAcctInDB = false;

		try {
			ArrayList<String> alValidCPNIAccts = CommonUtil.parseToArray(stValidCPNIAccts,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			log.info("{}{}QCPNI_U_21 : PROP_CPNI_ACCOUNTS : {}", sClassName, sMethodName, alValidCPNIAccts);

			if (alDBMemSvc != null && !alDBMemSvc.isEmpty()) {

				for (int k = 0; k < alDBMemSvc.size(); k++) {
					HashMap hmDBService = (HashMap) alDBMemSvc.get(k);
					String sDBSvcName = (String) hmDBService.get(CommonDefs.SERVICE_NAME);
					String sDBParentSorInvId = (String) hmDBService.get(CommonDefs.PARENT_SOR_INVARIANT_ID);
					String sDBRoleStatus = (String) hmDBService.get("roleStatusName");

					if (alValidCPNIAccts.contains(sDBSvcName)) {
						if ((sDBParentSorInvId == null || sDBParentSorInvId.isEmpty())
								&& CommonDefs.ROLE_STATUS_ENABLED.equals(sDBRoleStatus)) {
							isCPNIAcctInDB = true;
							break;
						}
					}
				}

			}
		} catch (Exception e) {
			HashMap hmResult = CommonErrorMap.makeExceptionMap(e, log);
			log.error("{}{}QCPNI_U_22 : response from QueryCPNIUserContactHelper : {}", sClassName, sMethodName,
					hmResult);
		}
		return isCPNIAcctInDB;
	}

	/**
	 * 
	 * @param alMemSvcRole
	 * @return HashMap
	 */
	private HashMap getMOSUBDetails(ArrayList alMemSvcRole) {
		String sMethodName = ".getMOSUBDetails.";
		HashMap<String, Object> hmMOSUB = null;
		if (alMemSvcRole != null && !alMemSvcRole.isEmpty()) {
			for (int k = 0; k < alMemSvcRole.size(); k++) {
				HashMap hmDBService = (HashMap) alMemSvcRole.get(k);
				String sDBSvcName = (String) hmDBService.get(CommonDefs.SERVICE_NAME);

				if (sDBSvcName != null && !sDBSvcName.isEmpty() && sDBSvcName.equals(CommonDefs.MOSUB_SERVICE)) {
					hmMOSUB = CommonUtil.getHashMap();
					hmMOSUB.putAll(hmDBService);
					log.info("{}{}QCPNI_U_07_02 : MOSUB service present in DB", sClassName, sMethodName);
					break;
				}
			}
		}
		return hmMOSUB;
	}

	/**
	 * 
	 * @param hmInput
	 * @param hmMOSUB
	 * @param hmCSIMosubResp
	 * @return HashMap
	 */
	private HashMap processMOSUBCPNIAddresses(HashMap hmInput, HashMap hmMOSUB, HashMap hmCSIMosubResp) {
		String sMethodName = ".processMOSUBCPNIAddresses.";
		String stAppStatusCode = null;
		HashMap<String, Object> hmResponse = null;

		log.info("{}{}QCPNIU_PM_000 : Input Hash : {}", sClassName, sMethodName, hmInput);
		log.info("{}{}QCPNIU_PM_003 : hmCSIMosubResp Hash : {}", sClassName, sMethodName, hmCSIMosubResp);

		try {

			Boolean isMOSUBValid = true;

			if (hmCSIMosubResp == null || hmCSIMosubResp.isEmpty()) {
				isMOSUBValid = false;
			} else {
				stAppStatusCode = (String) hmCSIMosubResp.get(CommonDefs.COMMON_APP_STATUS_CODE);
				if (!stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					isMOSUBValid = false;
				}

				ArrayList alSubscribers = CommonUtil.getList(hmCSIMosubResp, CommonDefs.CSI_SUBSCRIBER);

				if (alSubscribers != null && alSubscribers.size() > 0) {

					for (int k = 0; k < alSubscribers.size(); k++) {
						HashMap hmSubscriber = (HashMap) alSubscribers.get(k);
						if (hmSubscriber != null && !hmSubscriber.isEmpty()) {

							String sSubscriberNumber = (String) hmSubscriber.get(CommonDefs.SUBSCRIBER_NUMBER);
							if (sSubscriberNumber != null
									&& sSubscriberNumber.equals(hmMOSUB.get(CommonDefs.INSTANCE_ID))) {
								HashMap hmSubscriberStatus = CommonUtil.getMap(hmSubscriber, "SubscriberStatus");
								if (hmSubscriberStatus != null) {
									String sSubscriberStatus = (String) hmSubscriberStatus
											.get(CommonDefs.SUBSCRIBER_STATUS);
									if (sSubscriberStatus != null && !sSubscriberStatus.equals(CommonDefs.ACTIVE)) {
										isMOSUBValid = false;
									}
								}

								HashMap hmDeviceInformation = CommonUtil.getMap(hmSubscriber,
										CommonDefs.DEVICE_INFORMATION);
								if (hmDeviceInformation != null && !hmDeviceInformation.isEmpty()) {

									ArrayList alDevices = CommonUtil.getList(hmDeviceInformation, CommonDefs.DEVICE);
									if (alDevices != null && !alDevices.isEmpty()) {

										for (int j = 0; j < alDevices.size(); j++) {
											HashMap hmDevice = (HashMap) alDevices.get(j);
											if (hmDevice != null && !hmDevice.isEmpty()) {

												String sDeviceSMSCapable = (String) hmDevice
														.get(CommonDefs.SMS_CAPABILITY_INDICATOR);
												if (sDeviceSMSCapable != null
														&& sDeviceSMSCapable.equals(CommonDefs.DEFAULT_FALSE)) {
													isMOSUBValid = false;
												}
											}
										}
									}
								}

								log.info("{}{}QCPNIU_PM_004 : SIM_SWAP_AGING_DAYS : {}", sClassName, sMethodName,
										sSimSwapAgingDays);

								String sSimSwapDate = (String) hmSubscriber.get(CommonDefs.SIM_SWAP_DATE);
								if (sSimSwapDate != null && !sSimSwapDate.isEmpty()) {
									sSimSwapDate = formatDate(CommonDefs.SIM_SWAP_DATE, sSimSwapDate);
									String dateTimeFormat = "MMddyyyy HH:mm:ss";
									boolean bCTNAged = oCommonUtilHelper.checkAging(sSimSwapDate, sSimSwapAgingDays, dateTimeFormat);

									if (bCTNAged == false) {
										isMOSUBValid = false;
									}
								}
							}
						}
					}
				}

			}

			HashMap<String, Object> hmPhoneInfo = null;
			if (isMOSUBValid) {
				hmPhoneInfo = CommonUtil.getHashMap();
				hmPhoneInfo.put(CommonDefs.PHONE_NUMBER_TYPE, CommonDefs.PHONE_NUMBER_TYPE_ATTMOBILE);
				hmPhoneInfo.put(CommonDefs.PHONE_NUMBER, hmMOSUB.get(CommonDefs.INSTANCE_ID));

				HashMap<String, Object> hmGeneralContactDetails = CommonUtil.getHashMap();
				hmGeneralContactDetails.put(CommonDefs.CONTACT_STATUS, "V");
				hmGeneralContactDetails.put(CommonDefs.CONTACT_TYPE, "DMCTN");
				hmGeneralContactDetails.put(CommonDefs.CPNI_ELGIBLE, CommonDefs.IND_Y);

				if (((String) hmMOSUB.get(CommonDefs.DATE_DEFAULT_EST)) != null
						&& (!((String) hmMOSUB.get(CommonDefs.DATE_DEFAULT_EST)).isEmpty())) {
					hmGeneralContactDetails.put(CommonDefs.ESTABLISHED_DATE, hmMOSUB.get(CommonDefs.DATE_DEFAULT_EST));
				} else {
					hmGeneralContactDetails.put(CommonDefs.ESTABLISHED_DATE, hmMOSUB.get(CommonDefs.CREATE_DATE));
				}

				hmPhoneInfo.put(CommonDefs.GENERAL_CONTACT_DETAILS, hmGeneralContactDetails);
			}

			hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
			if (hmPhoneInfo != null && !hmPhoneInfo.isEmpty()) {
				hmResponse.put(CommonDefs.US_PHONE_NUMBER, hmPhoneInfo);
			}

		} catch (Exception exp) {

			hmResponse = CommonErrorMap.makeExceptionMap(exp, log);

		}
		return hmResponse;
	}

	/**
	 * 
	 * @param alDBMemSvc
	 * @return HashMap
	 */
	private HashMap getOnlyOneEnabledCPNIOWNERAccount(ArrayList alDBMemSvc) {
		String sMethodName = ".getOnlyOneEnabledCPNIOWNERAccount.";
		int cpniCounter = 0;
		HashMap<String, Object> hmOnlyOneEnabledCPNIOWNERAccount = CommonUtil.getHashMap();

		try {
			ArrayList<String> alValidCPNIAccts = CommonUtil.parseToArray(stValidCPNIAccts,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			log.info("{}{}QCPNI_U_24 : PROP_CPNI_ACCOUNTS : {}", sClassName, sMethodName, alValidCPNIAccts);

			if (alDBMemSvc != null && !alDBMemSvc.isEmpty()) {
				ArrayList alMemberServices = CommonUtil.getArrayList();
				alMemberServices.addAll(alDBMemSvc);

				for (int k = 0; k < alDBMemSvc.size(); k++) {
					HashMap hmDBSvc = (HashMap) alDBMemSvc.get(k);
					String sDBSvc = (String) hmDBSvc.get(CommonDefs.SERVICE_NAME);
					String sDBParentSorInvId = (String) hmDBSvc.get(CommonDefs.PARENT_SOR_INVARIANT_ID);
					String sDBRoleStatus = (String) hmDBSvc.get("roleStatusName");

					if (alValidCPNIAccts.contains(sDBSvc) && (sDBParentSorInvId == null || sDBParentSorInvId.isEmpty())
							&& CommonDefs.ROLE_STATUS_ENABLED.equals(sDBRoleStatus)) {
						cpniCounter++;
						hmOnlyOneEnabledCPNIOWNERAccount.putAll(hmDBSvc);
					}
				}

				String sDBRole = (String) hmOnlyOneEnabledCPNIOWNERAccount.get(CommonDefs.ROLE_NAME);
				if (cpniCounter == 1 && CommonDefs.KEY_ROLE_NAME_OWNER.equals(sDBRole)) {
					String sDbSvcName = (String) hmOnlyOneEnabledCPNIOWNERAccount.get(CommonDefs.SERVICE_NAME);
					String sSorInvId = (String) hmOnlyOneEnabledCPNIOWNERAccount
							.get(CommonDefs.SOR_INVARIANT_ID);
					if (CommonDefs.TITAN_SERVICE.equals(sDbSvcName)) {
						for (int i = 0; i < alMemberServices.size(); i++) {
							HashMap hmSvc = (HashMap) alMemberServices.get(i);
							String sSvcName = (String) hmSvc.get(CommonDefs.SERVICE_NAME);
							String sParentSorInvId = (String) hmSvc.get(CommonDefs.PARENT_SOR_INVARIANT_ID);

							if ((CommonDefs.MOBILITY_SERVICE).equals(sSvcName) && sParentSorInvId != null
									&& sParentSorInvId.equals(sSorInvId)) {
								hmOnlyOneEnabledCPNIOWNERAccount.putAll(hmSvc);
								break;
							}
						}
					}
				} else {
					hmOnlyOneEnabledCPNIOWNERAccount = CommonUtil.getHashMap();
				}
			}
		} catch (Exception e) {
			HashMap hmResult = CommonErrorMap.makeExceptionMap(e, log);
			log.error("{}{}QCPNI_U_25 : response from QueryCPNIUserContactHelper : {}", sClassName, sMethodName,
					hmResult);
		}
		return hmOnlyOneEnabledCPNIOWNERAccount;
	}

	/**
	 * 
	 * @param alDBMemSvc
	 * @return HashMap
	 */
	private HashMap getDefaultEnabledCPNIMultiAccount(ArrayList alDBMemSvc) {
		String sMethodName = ".getDefaultEnabledCPNIMultiAccount.";
		int cpniCounter = 0;
		HashMap hmDefaultCPNIAcct = null;

		try {
			ArrayList<String> alValidCPNIAccts = CommonUtil.parseToArray(stValidCPNIAccts,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			log.info("{}{}QCPNI_U_24 : PROP_CPNI_ACCOUNTS : {}", sClassName, sMethodName, alValidCPNIAccts);

			if (alDBMemSvc != null && !alDBMemSvc.isEmpty()) {
				ArrayList alMemberServices = CommonUtil.getArrayList();
				alMemberServices.addAll(alDBMemSvc);

				for (int k = 0; k < alDBMemSvc.size(); k++) {
					HashMap hmDBSvc = (HashMap) alDBMemSvc.get(k);
					String sSvcName = (String) hmDBSvc.get(CommonDefs.SERVICE_NAME);
					String sDefaultAcct = (String) hmDBSvc.get(CommonDefs.DEFAULT_ACCOUNT);
					String sRoleStatus = (String) hmDBSvc.get("roleStatusName");
					String sParentSorInvId = (String) hmDBSvc.get(CommonDefs.PARENT_SOR_INVARIANT_ID);

					if (alValidCPNIAccts.contains(sSvcName) && (sParentSorInvId == null || sParentSorInvId.isEmpty())
							&& CommonDefs.ROLE_STATUS_ENABLED.equals(sRoleStatus)) {
						cpniCounter++;
					}

					if ("Y".equals(sDefaultAcct)) {
						if (!CommonDefs.TITAN_SERVICE.equals(sSvcName)
								&& (sParentSorInvId == null || sParentSorInvId.isEmpty())
								&& CommonDefs.ROLE_STATUS_ENABLED.equals(sRoleStatus)) {
							hmDefaultCPNIAcct = CommonUtil.getHashMap();
							hmDefaultCPNIAcct.putAll(hmDBSvc);
						}

						if (CommonDefs.TITAN_SERVICE.equals(sSvcName)
								&& CommonDefs.ROLE_STATUS_ENABLED.equals(sRoleStatus)) {
							String sTitanSorInvId = (String) hmDBSvc.get(CommonDefs.SOR_INVARIANT_ID);

							for (int i = 0; i < alMemberServices.size(); i++) {
								HashMap hmSvc = (HashMap) alMemberServices.get(i);

								String sDBSvc = (String) hmSvc.get(CommonDefs.SERVICE_NAME);
								String sDBParentSorInvId = (String) hmSvc.get(CommonDefs.PARENT_SOR_INVARIANT_ID);

								if (CommonDefs.MOBILITY_SERVICE.equals(sDBSvc) && sDBParentSorInvId != null
										&& !sDBParentSorInvId.isEmpty() && sDBParentSorInvId.equals(sTitanSorInvId)) {
									hmDefaultCPNIAcct = CommonUtil.getHashMap();
									hmDefaultCPNIAcct.putAll(hmSvc);
									break;
								}
							}
						}

						if (hmDefaultCPNIAcct == null || hmDefaultCPNIAcct.isEmpty()) {
							hmDefaultCPNIAcct = CommonUtil.getHashMap();
							hmDefaultCPNIAcct.putAll(hmDBSvc);
						}
					}
				}
			}

			if (cpniCounter <= 1) {
				hmDefaultCPNIAcct = CommonUtil.getHashMap();
			}
		} catch (Exception e) {
			HashMap hmResult = CommonErrorMap.makeExceptionMap(e, log);
			log.error("{}{}QCPNI_U_273e : response from QueryCPNIUserContactHelper : {}", sClassName, sMethodName,
					hmResult);
		}
		return hmDefaultCPNIAcct;
	}

	/**
	 * 
	 * @param hmInput
	 * @param hmInqProfileResp
	 * @return HashMap
	 */
	private HashMap queryCPNIUserAndAccountCBR(HashMap hmInput, HashMap hmInqProfileResp) {
		String sMethodName = ".queryCPNIUserAndAccountCBR.";
		String stAppStatusCode = null;
		HashMap hmContactInfo = null;
		ArrayList userCBRList = null;
		ArrayList accountCBRList = null;
		HashMap hmCBRDetails = new HashMap();

		log.debug("{}{}QCPNI_U_56.5 : Calling inquireContactInfoHelper.inquireContactInfo() : {}", sClassName,
				sMethodName, hmInqProfileResp);

		hmContactInfo = inquireContactInfoHelper.inquireContactInfo(hmInput, hmInqProfileResp);

		log.debug("{}{}QCPNI_U_57.5 : Response from inquireContactInfoHelper.inquireContactInfo() : {}", sClassName,
				sMethodName, hmContactInfo);

		stAppStatusCode = (String) hmContactInfo.get(CErrorDefs.COMMON_APP_STATUS_CODE);
		if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
			log.info("{}{}QCPNI_U_07.1 : {}", sClassName, sMethodName, hmContactInfo);
		}

		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			if (hmContactInfo.containsKey("userCBRList")) {
				userCBRList = (ArrayList) hmContactInfo.get("userCBRList");
				if (userCBRList != null && !userCBRList.isEmpty()) {
					hmCBRDetails.put("userCBRList", userCBRList);
				}
			}

			if (hmContactInfo.containsKey("accountCBRList")) {
				accountCBRList = (ArrayList) hmContactInfo.get("accountCBRList");
				if (accountCBRList != null && !accountCBRList.isEmpty()) {
					hmCBRDetails.put("accountCBRList", accountCBRList);
				}
			}
		}
		return hmCBRDetails;
	}
}