package com.att.idp.idgraphcontactinfoms.cgclient.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * The Addresses class represents an address in the system.
 * It implements the Serializable interface, which means its instances can be converted to a byte stream and
 * restored back to the same object later. This is useful for storing objects in a file or sending them over a network.
 *
 * This class contains various properties related to an address such as addressLine1, city, state, zip, addressType, addressCategory, and addressSubType.
 * Each property has its corresponding getter and setter methods.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.cgclient.response package.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(name = "Addresses")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Addresses implements Serializable {

	private static final long serialVersionUID = -6079177105053233172L;

	private String addressLine1;
	private String city;
	private String state;
	private String zip;
	private String addressType;
	private String addressCategory;
	private String addressSubType;
}