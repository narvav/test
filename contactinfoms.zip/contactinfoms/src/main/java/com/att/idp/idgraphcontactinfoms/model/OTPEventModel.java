package com.att.idp.idgraphcontactinfoms.model;

import com.att.idp.idgraph.events.model.JsonSealizable;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.ToString;

import java.time.Instant;

@Data
@ToString
public class OTPEventModel implements JsonSealizable {
    private String eventId;
    private String eventType;
    @JsonFormat(
            pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            shape = JsonFormat.Shape.STRING,
            timezone = "UTC"
    )
    private Instant eventTime;
    private String resourceName;
    @JsonProperty("event")
    private EventDetails eventDetails;
}
