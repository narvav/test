package com.att.idp.idgraphcontactinfoms.request.validator;

import com.att.idp.idgraphcontactinfoms.resource.response.CPNIContactInfoResponse;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.idp.idgraphcontactinfoms.utils.Constants;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import jakarta.ws.rs.core.HttpHeaders;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Map;
import java.util.Optional;

/**
 * Validator class for CPNI Contact Info requests.
 * This class provides methods to validate HTTP headers for CPNI contact info requests,
 * ensuring required fields are present and valid, and generating appropriate error responses.
 * It uses configuration properties to determine valid callers and supports both internal and external call validation.
 *
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class CPNIContactInfoRequestValidator {

	@Value("${PROP_CPNI_CONTACT_CSI}")
	private String propValidCallers;

	@Value("${PROP_CPNI_ACCOUNT_TYPES}")
	private String stValidAccountTypes;

	@Value("#{'${PROP_CPNI_ALLOWED_EXPLOITABLE_VALUES}'.split('\\|')}")
	private String alValidExploitableValues;

    @Value("#{'${PROP_CPNI_ALLOWED_RETURN_BIZ_CTN_VALUES}'.split('\\|')}")
    private String alValidReturnBizCTNsValues;

	private static final Logger logger = LoggerFactory.getLogger(CPNIContactInfoRequestValidator.class);

	private static final String sClassName = "CPNIContactInfoRequestValidator";
	private String stRequestTraceId = null;

	public CPNIContactInfoResponse cpniContactInfoRequestValidator(HttpHeaders cpniContactInfoRequestHeader) {
		
		CPNIContactInfoResponse cpniContactInfoResponse=null;
		String stAppInfo = null;
		String sMethodName = ".cpniContactInfoRequestValidator.";


		if (cpniContactInfoRequestHeader == null || cpniContactInfoRequestHeader.getRequestHeaders().isEmpty()) {
			stAppInfo = "Input Request is NULL / Empty.";
			logger.info("{}{}CPNIRV_101 :: {}", sClassName, sMethodName, stAppInfo);
			return cpniContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					stRequestTraceId);
		}

		stRequestTraceId = CommonUtil.getTraceId(cpniContactInfoRequestHeader);
		
		if(stRequestTraceId == null || stRequestTraceId.startsWith("AutoGen_")) {
			stAppInfo="CPNIContactInfo  Request Header idp-trace-id is missing";
			return cpniContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stRequestTraceId);
		}

		//TODO: we can't add anything in the header so we cant set idp-trace-id in the header
		//cpniContactInfoRequestHeader.setIdpTraceId(stIdpTraceId);
			
		// We can't check Invalid attributes passed in Request header as header will have multiple values

		try {
			cpniContactInfoResponse = cpniContactInputValidator(cpniContactInfoRequestHeader);
			if (cpniContactInfoResponse != null) {
				logger.info("{}{}CPNIRV_103 Response from CPNIContactInfoRequestValidator : {}", sClassName, sMethodName,
						cpniContactInfoResponse);
				return cpniContactInfoResponse;
			}
			
			cpniContactInfoResponse = cpniContactInfoCSIValidator(cpniContactInfoRequestHeader);
			if (cpniContactInfoResponse != null) {
				logger.info("{}{}CPNIRV_104 Response from CPNIContactInfoRequestValidator : {}", sClassName, sMethodName,
						cpniContactInfoResponse);
				return cpniContactInfoResponse;
			}
			
			stAppInfo = "Input Validation Successful";
			logger.info("{}{}CPNIRV_105 : {}", sClassName, sMethodName, stAppInfo);

		} catch (Exception e) {
			stAppInfo = "Exception thrown in CPNIContactInfoRequestValidator : "
					+ e.getMessage();
			cpniContactInfoResponse= cpniContactErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo,
					stRequestTraceId);
			logger.info("{}{}CPNIRV_106: Exception in CPNIContactInfoRequestValidator: {}", sClassName,sMethodName,stAppInfo);
		}

		return cpniContactInfoResponse;
		
		
	}

	/**
	 * Validates the input headers for a CPNI contact info request.
	 *
	 * @param cpniContactInfoRequestHeader the HTTP headers containing request information
	 * @return a CPNIContactInfoResponse with error details if validation fails, or null if validation passes
	 */
	private CPNIContactInfoResponse cpniContactInputValidator(HttpHeaders cpniContactInfoRequestHeader) {

		String stAppInfo=null;
		String sMethodName=".cpniContactInputValidator.";
		
		String sIndividualId = cpniContactInfoRequestHeader.getHeaderString(Constants.INDIVIDUAL_ID) ;
		String sAccountId = cpniContactInfoRequestHeader.getHeaderString(CommonDefs.ACCOUNT_ID) ;
		String sSubscriberNumber = cpniContactInfoRequestHeader.getHeaderString(Constants.SUBSCRIBER_NUMBER) ;
		String sAccountType = cpniContactInfoRequestHeader.getHeaderString(CommonDefs.ACCOUNT_TYPE) ;
		String sCallingSystemId = cpniContactInfoRequestHeader.getHeaderString(CommonDefs.X_ATT_CLIENT_ID);
		String sExploitable = cpniContactInfoRequestHeader.getHeaderString(Constants.EXPLOITABLE);
        String sReturnBizCTNs = cpniContactInfoRequestHeader.getHeaderString(Constants.RETURN_BIZ_CTNS);

		int identifierCount = 0;
		if (!StringUtils.isBlank(sIndividualId)) identifierCount++;
		if (!StringUtils.isBlank(sAccountId)) identifierCount++;
		if (!StringUtils.isBlank(sSubscriberNumber)) identifierCount++;

		if (identifierCount == 0) {
			stAppInfo = "All of individualId, accountId, and subscriberNumber cannot be null/empty in request headers.";
			logger.info("{}{}CPNIRV_102.1 : {}", sClassName, sMethodName, stAppInfo);
			return cpniContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stRequestTraceId);
		}

		if (identifierCount > 1) {
			stAppInfo = "Request can have only one of individualId, accountId, or subscriberNumber. Please provide only one.";
			logger.info("{}{}CPNIRV_102.2 : {}", sClassName, sMethodName, stAppInfo);
			return cpniContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stRequestTraceId);
		}

		ArrayList<String> alValidAccountTypes = CommonUtil.parseToArray(stValidAccountTypes,
				CommonDefs.VALUE_SEPARATOR_CHAR);
		logger.info("{}{}CPNIRV_102.3 : PROP_CPNI_ACCOUNT_TYPES : {}", sClassName, sMethodName, alValidAccountTypes);

		if(!StringUtils.isBlank(sAccountId)) {
			if(sAccountType == null || sAccountType.isBlank()) {
				stAppInfo = "accountType can not be null/empty when accountId is provided.";
				logger.info("{}{}CPNIRV_102.4 : {}", sClassName, sMethodName, stAppInfo);
				return cpniContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						stRequestTraceId);
			} else if(alValidAccountTypes != null && !alValidAccountTypes.contains(sAccountType.toUpperCase())) {
				stAppInfo = "invalid accountType provided in the request : " + sAccountType;
				logger.info("{}{}CPNIRV_102.5 : {}", sClassName, sMethodName, stAppInfo);
				return cpniContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						stRequestTraceId);
			}
		}

		if(!StringUtils.isBlank(sExploitable)) {
			logger.info("{}{}CPNIRV_102.6 : PROP_CPNI_ALLOWED_EXPLOITABLE_VALUES : {}", sClassName, sMethodName, alValidExploitableValues);
			if(!alValidExploitableValues.contains(sExploitable.toUpperCase())) {
				stAppInfo = "Invalid exploitable value provided in the request : " + sExploitable;
				logger.info("{}{}CPNIRV_102.7 : {}", sClassName, sMethodName, stAppInfo);
				return cpniContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
						stRequestTraceId);
			}

		}

		if (sCallingSystemId == null || sCallingSystemId.isBlank()) {
			stAppInfo = " X-ATT-ClientId in request header must be present";
			logger.info("{}{}CPNIRV_102.2 : {}", sClassName, sMethodName, stAppInfo);
			return cpniContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					stRequestTraceId);
		}

        if(!StringUtils.isBlank(sReturnBizCTNs)) {
            logger.info("{}{}CPNIRV_102.8 : PROP_CPNI_ALLOWED_RETURN_BIZ_CTN_VALUES : {}", sClassName, sMethodName, alValidReturnBizCTNsValues);
            if(!alValidReturnBizCTNsValues.contains(sReturnBizCTNs.toUpperCase())) {
                stAppInfo = "Invalid returnBizCTNs value provided in the request : " + sReturnBizCTNs;
                logger.info("{}{}CPNIRV_102.9 : {}", sClassName, sMethodName, stAppInfo);
                return cpniContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
                        stRequestTraceId);
            }

        }

		return null;
	}



	/**
	 * Validates the calling system ID for CPNI contact info requests when the call is external.
	 *
	 * @param cpniContactInfoRequestHeader the HTTP headers containing request information
	 * @return a CPNIContactInfoResponse with error details if validation fails, or null if validation passes
	 */
	private CPNIContactInfoResponse cpniContactInfoCSIValidator(
			HttpHeaders cpniContactInfoRequestHeader) {

		String stAppInfo=null;
		String sMethodName=".cpniContactInfoCSIValidator.";

		String sIsExternalCall = Optional.ofNullable(cpniContactInfoRequestHeader.getHeaderString("isExternalCall")).orElse(CommonDefs.IND_Y);
		String sCallingSystemId = cpniContactInfoRequestHeader.getHeaderString("X-ATT-ClientId");

		
		ArrayList<String> alValidCallers = CommonUtil.parseToArray(propValidCallers, CommonDefs.VALUE_SEPARATOR_CHAR);
		
		logger.info("{}{}CPNIRV_103.1 : PROP_QUERY_CPNI_ACCOUNT_CSI : {}", sClassName, sMethodName, alValidCallers);

		if (CommonDefs.IND_Y.equalsIgnoreCase(sIsExternalCall) && (sCallingSystemId != null && !alValidCallers.contains(sCallingSystemId.toUpperCase()))) {
			stAppInfo = "Invalid X-ATT-ClientId in request header";
			logger.info("{}{}CPNIRV_103.2 : {}", sClassName, sMethodName, stAppInfo);
			return cpniContactErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					 stRequestTraceId);
		}

		return null;
	}
	

	private CPNIContactInfoResponse cpniContactErrorResponse(int appStatusCode, String stAppInfo, String stIdpTraceId) {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put(Constants.IDP_TRACE_ID, stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		hmResponse.put(CommonDefs.TRANSACTION_NAME,"CPNIContactInfo");
		return (CPNIContactInfoResponse) CommonUtilHelper.generateCIRResponse(hmResponse);
	}
	

}

