package com.att.idp.idgraphcontactinfoms.cgclient.response;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "Accounts")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Accounts implements Serializable {

	private static final long serialVersionUID = -2349146278265552914L;

	@JsonProperty("id")
	private String id;

	@JsonProperty("state")
	private String state;

	@JsonProperty("serviceType")
	private String serviceType;

	@JsonProperty("accountType")
	private String accountType;

	@JsonProperty("accountSubType")
	private String accountSubType;

	@JsonProperty("createdOn")
	private String createdOn;

	@JsonProperty("contact")
	private List<Contact> contact;

	@JsonProperty("billStructure")
	private BillStructure billStructure;

	@JsonProperty("ratingType")
	private String ratingType;

	@JsonProperty("billingMarket")
	private String billingMarket;

	@JsonProperty("fanDetails")
	private FanDetails fanDetails;

	@JsonProperty("pastDue")
	private BigDecimal pastDue;

	@JsonProperty("bmgIndicator")
	private String bmgIndicator;

	@JsonProperty("taxExemptStatus")
	private String taxExemptStatus;

	@JsonProperty("companyCode")
	private String companyCode;

	@JsonProperty("isEmployee")
	private String isEmployee;

	@JsonProperty("bundleDiscExists")
	private String bundleDiscExists;

	@JsonProperty("subscribersCount")
	private String subscribersCount;

	@JsonProperty("productTypes")
	private List<String> productTypes;

	@JsonProperty("amountDue")
	private String amountDue;

	@JsonProperty("languagePreference")
	private String languagePreference;

	@JsonProperty("convergedCustomerOption")
	private String convergedCustomerOption;

	@JsonProperty("firstnetIndicator")
	private boolean firstnetIndicator;

	@JsonProperty("billingAccountTypeDisplay")
	private String billingAccountTypeDisplay;

	@JsonProperty("serviceDiscount")
	private String serviceDiscount;

	@JsonProperty("convergedCustomerOptionDisplay")
	private String convergedCustomerOptionDisplay;

	@JsonProperty("securityLevelCode")
	private String securityLevelCode;

	@JsonProperty("profileType")
	private String profileType;

	@JsonProperty("hboMaxEntitlementIndicator")
	private boolean hboMaxEntitlementIndicator;

	@JsonProperty("givenName")
	private String givenName;

	@JsonProperty("familyName")
	private String familyName;

	@JsonProperty("creditClass")
	private String creditClass;

	@JsonProperty("subMarket")
	private String subMarket;

	@JsonProperty("systemOfRecord")
	private String systemOfRecord;

	@JsonProperty("autoPayIndicator")
	private String autoPayIndicator;

	@JsonProperty("billDueDate")
	private String billDueDate;

	@JsonProperty("primaryAccountHolder")
	private String primaryAccountHolder;

	@JsonProperty("statusReasonCode")
	private String statusReasonCode;

	@JsonProperty("customerInTreatment")
	private boolean customerInTreatment;

	@JsonProperty("statusReasonDescription")
	private String statusReasonDescription;

	@JsonProperty("statusReasonActivity")
	private String statusReasonActivity;

	@JsonProperty("secondaryPhoneNumberAttIndicator")
	private boolean secondaryPhoneNumberAttIndicator;

	@JsonProperty("phoneNumberAttIndicator")
	private boolean phoneNumberAttIndicator;

	private String emailStatusUpdateDate;
	private String emailStatus;

	private String businessVipInd;

	private String enterpriseType;

	private String liabilityType;
}