package com.att.idp.idgraphcontactinfoms.service.impl;

import com.att.idp.core.exception.ServiceException;
import com.att.idp.dpl.profile.bsse.customerv4.CustomerV4Response;
import com.att.idp.idgraphcontactinfoms.helpers.CPNIContactInfoHelper;
import com.att.idp.idgraphcontactinfoms.message.ErrorMessages;
import com.att.idp.idgraphcontactinfoms.model.Individual;
import com.att.idp.idgraphcontactinfoms.resource.response.CPNIContactInfoResponse;
import com.att.idp.idgraphcontactinfoms.service.CPNIContactInfoService;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.idp.idgraphcontactinfoms.utils.Constants;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import jakarta.ws.rs.core.MultivaluedMap;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;


@Service
public class CPNIContactInfoServiceImpl implements CPNIContactInfoService {
	
	private static final Logger logger = LoggerFactory.getLogger(CPNIContactInfoServiceImpl.class);

	@Autowired
	private CPNIContactInfoHelper cpniContactInfoHelper;

	private static final String CLASS_NAME = "CPNIContactInfoServiceImpl";

	/**
	 * This method is used to search for individual contact information by individual ID.
	 * It calls the CPNIContactInfoHelper to retrieve the contact information.
	 *
	 * @param cpniContactInfoRequestHeader - contains the request headers including individualId and traceId
	 * @return CPNIContactInfoResponse - response containing the contact information or error details
	 */
	@Override
	public CPNIContactInfoResponse cpniContactInfo(MultivaluedMap<String, String> cpniContactInfoRequestHeader){
		String sMethodName = ".cpniContactInfo.";
        String stAppInfo= null;
		CPNIContactInfoResponse cpniContactInfoResponse = null;
		String traceId = cpniContactInfoRequestHeader.getFirst(Constants.IDP_TRACE_ID);
		String sIndividualId = cpniContactInfoRequestHeader.getFirst(Constants.INDIVIDUAL_ID);
		String accountId = cpniContactInfoRequestHeader.getFirst(CommonDefs.ACCOUNT_ID);
		String accountType = cpniContactInfoRequestHeader.getFirst(CommonDefs.ACCOUNT_TYPE);
		String subscriberNumber = cpniContactInfoRequestHeader.getFirst(Constants.SUBSCRIBER_NUMBER);

		logger.info("{}{}CCS01: Calling CPNI Helper with Individual ID {} or with accountId {} or with subscriberNumber {}" , CLASS_NAME, sMethodName,StringEscapeUtils.escapeJava(sIndividualId) , StringEscapeUtils.escapeJava(accountId), StringEscapeUtils.escapeJava(subscriberNumber));
        Individual individual = null;
		CustomerV4Response customerV4Response = null;
        try {
			if(!StringUtils.isBlank(sIndividualId)) {
				individual = cpniContactInfoHelper.cpniContactInfoByIndividualId(sIndividualId,cpniContactInfoRequestHeader,false);
			} else if(!StringUtils.isBlank(accountId) && !StringUtils.isBlank(accountType)) {
				individual = cpniContactInfoHelper.cpniContactInfoByAccountId(accountId,accountType,cpniContactInfoRequestHeader,true);
			} else if(!StringUtils.isBlank(subscriberNumber)) {
				individual = cpniContactInfoHelper.cpniContactInfoBySubscriberNumber(subscriberNumber,cpniContactInfoRequestHeader,true);
			}

			if(individual != null) {
				return CommonUtilHelper.cpniContactInfoSuccessResponse(traceId,individual);
			}else{
				stAppInfo = "Null response returned from CPNIContactInfoHelper for sIndividualId : " + sIndividualId + " or accountId : " +accountId + " or subscriberNumber : " + subscriberNumber;
				throw new ServiceException(ErrorMessages.MS_MPSYS_BE_602, stAppInfo);
			}

        } catch(ServiceException e) {
			stAppInfo = "ServiceException thrown from cpniContactInfoHelper with error message: "+ e.getError().getMessage();
			logger.info("{}{}CCS02: {}", CLASS_NAME, sMethodName, stAppInfo);
			throw e;
		} catch(Exception e) {
			HashMap<String, Object> hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			hmResponse.put(Constants.IDP_TRACE_ID, traceId);
			cpniContactInfoResponse = CommonUtilHelper.cpniContactInfoResponse(hmResponse);

		}

		return cpniContactInfoResponse;
	}
}
