package com.att.idp.idgraphcontactinfoms.config;

/**
 * The ApplicationDataSourceConstant interface represents the constants used for the application's data source configuration.
 * 
 * This interface is part of the com.att.idp.idgraphcontactinfoms.config package.
 * 
 * It contains three constants:
 * - DATA_SOURCE: Represents the data source of the application.
 * - ENTITY_MANAGER_FACTORY: Represents the entity manager factory of the application.
 * - TRANSACTION_MANAGER: Represents the transaction manager of the application.
 */
public interface ApplicationDataSourceConstant {

	/** The data source **/
	String DATA_SOURCE = "dataSource";
	
	/** The entity manager factory **/
	String ENTITY_MANAGER_FACTORY = "entityManagerFactory";
	
	/** The transaction manager .**/
	String TRANSACTION_MANAGER = "transactionManager";
}
