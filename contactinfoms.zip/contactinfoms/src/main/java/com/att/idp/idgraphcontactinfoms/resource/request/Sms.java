package com.att.idp.idgraphcontactinfoms.resource.request;

import static org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString;
import static org.apache.commons.lang3.builder.ToStringStyle.JSON_STYLE;

import java.io.Serializable;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.request package.
 *
 * The Sms class implements the Serializable interface, allowing instances of this class to be converted into a byte stream.
 *
 * The class is used to represent an Sms object, which contains a smsPhoneNumber field.
 * The smsPhoneNumber field is annotated with @NotNull and @Size, indicating that it is a required field and has a size constraint.
 *
 * The class provides a no-argument constructor, as well as getter and setter methods for the smsPhoneNumber field.
 * It also overrides the toString method, providing a custom string representation of the object using reflection.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Sms implements Serializable{

	@NotNull(message="smsPhoneNumber is required field in input request.|GeneratePIN")
	@Size(min=1, max=10,message="smsPhoneNumber length is invalid|GeneratePIN")
	protected String smsPhoneNumber;

	@Override
	public String toString() {
		return reflectionToString(this, JSON_STYLE);
	}
}