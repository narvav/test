package com.att.idp.idgraphcontactinfoms.db.model;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "TMEMBERGROUP", schema = "MPS_OWNER", uniqueConstraints = @UniqueConstraint(columnNames = { "PARENT_NAME", "DOMAIN_ID" }))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tmembergroup implements java.io.Serializable {

	private static final long serialVersionUID = -3057124733167198053L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "GROUP_NUM", unique = true, nullable = false, precision = 22, scale = 0)
	private Long groupNum;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "DOMAIN_ID", nullable = false)
	private Tdomain tdomain;

	@Column(name = "PARENT_NAME", nullable = false, length = 127)
	private String parentName;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;

	@Column(name = "PREMIUM_800_IND", length = 1)
	private Character premium800Ind;

	@Column(name = "BULK_BILLING_IND", length = 1)
	private Character bulkBillingInd;

	@Column(name = "ACCESS_CODE", length = 20)
	private String accessCode;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tmembergroup")
	private Set<Tmember> tmembers = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tmembergroup")
	private Set<Tmemberservice> tmemberservices = new HashSet<>(0);
}