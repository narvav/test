package com.att.idp.idgraphcontactinfoms.service.impl;

import java.util.HashMap;
import java.util.Map;

import jakarta.ws.rs.core.MultivaluedMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.idp.idgraphcontactinfoms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphcontactinfoms.helpers.QueryCPNIUserContactHelper;
import com.att.idp.idgraphcontactinfoms.resource.request.QueryCPNIUserContactInfoRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.QueryCPNIUserContactInfoResponse;
import com.att.idp.idgraphcontactinfoms.service.QueryCPNIUserContactInfoService;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.idp.idgraphcontactinfoms.utils.QueryCPNIUserContactInfoResponseGenerator;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This class implements the QueryCPNIUserContactInfoService interface and is responsible for handling operations related to querying CPNI (Customer Proprietary Network Information) user contact information.
 *
 * It is annotated with @Service, indicating that it's a Spring Service.
 * The class has a dependency on QueryCPNIUserContactHelper, which is autowired.
 * It also has a Logger instance for logging.
 *
 * The class has two main methods: queryCPNIUserContactInfo and stubResponse.
 * The queryCPNIUserContactInfo method takes a QueryCPNIUserContactInfoRequest and MultivaluedMap<String, String> as input parameters and returns a QueryCPNIUserContactInfoResponse.
 * The method is responsible for querying the CPNI user contact information and handling the response.
 * The stubResponse method is used to generate a stub response for testing purposes.
 *
 * The class is also annotated with @Transactional, indicating that it's a transactional class with a specific transaction manager and rollback rules.
 */
@Service
public class QueryCPNIUserContactInfoServiceImpl implements QueryCPNIUserContactInfoService {

	public static final Logger logger = LoggerFactory.getLogger(QueryCPNIUserContactInfoServiceImpl.class);

	private static String sClassName = "QueryCPNIAccountContactInfoServiceImpl";

	@Autowired
	private QueryCPNIUserContactHelper queryCPNIUserContactHelper;

	@Override
	public QueryCPNIUserContactInfoResponse queryCPNIUserContactInfo(
			QueryCPNIUserContactInfoRequest queryUserInfoRequest, MultivaluedMap<String, String> requestHeader) {
		Map<String, Object> hmInput = null;
		Map<String, Object> hmResponse = null;
		String sMethodName = ".queryCPNIUserContactInfo.";

		hmInput = CommonUtilHelper.objectToMap(queryUserInfoRequest);
		hmInput.put(CommonDefs.HANDLE, queryUserInfoRequest.getUserId());
		
		hmResponse = queryCPNIUserContactHelper.queryCPNIUserContact((HashMap<String, Object>) hmInput);

		if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
			hmResponse = CommonUtilHelper
					.sysErrorHashMap("Null response from queryUserContactInfoHelper.queryCPNIUserContactInfo");
			logger.info("{}{}QUS_01 : Null response from queryUserContactInfoHelper.queryCPNIUserContactInfo",
					sClassName, sMethodName);
		} else {
			String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (stAppStatusCode == null) {
				hmResponse = CommonUtilHelper.sysErrorHashMap(
						"Null response from queryAccountContactInfoHelper.queryCPNIAccountContactInfo");
				logger.info("{}{}QUS_02 : Null response from queryAccountContactInfoHelper.queryCPNIAccountContactInfo",
						sClassName, sMethodName);
			}
		}

		hmResponse.put("idp-trace-id", queryUserInfoRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME, queryUserInfoRequest.getTransactionName());
		QueryCPNIUserContactInfoResponse queryCPNIUserResponse = QueryCPNIUserContactInfoResponseGenerator
				.getQueryCPNIUserContactInfoResponse(hmResponse);

		return queryCPNIUserResponse;
	}

	/**
	 * This method is part of the QueryCPNIUserContactInfoServiceImpl class in the com.att.idp.idgraphcontactinfoms.service.impl package.
	 *
	 * The stubResponse method is used to generate a stub response for testing purposes.
	 * It does not take any input parameters.
	 *
	 * The method returns a QueryCPNIUserContactInfoResponse object, which represents a stub response with hardcoded values.
	 * This stub response can be used for testing the functionality of the QueryCPNIUserContactInfoService without making actual calls to the service.
	 */
	public QueryCPNIUserContactInfoResponse stubResponse() {

		String response = "{\r\n" + "    \"idp-trace-id\": \"48f9de4f104b345a:48f9de4f104b345a:0:0\",\r\n"
				+ "    \"transactionName\": \"QueryCPNIUserContactInfo\",\r\n"
				+ "    \"appStatusMsg\": \"SUCCESS\",\r\n" + "    \"appStatusCode\": \"0\"}";

		QueryCPNIUserContactInfoResponse responseObj = new QueryCPNIUserContactInfoResponse();
		responseObj.setAppStatusCode("0");
		//responseObj.setTransactionName("QueryCPNIUserContactInfo");
		responseObj.setAppStatusMsg("SUCCESS");
		responseObj.setIdpTraceId("48f9de4f104b345a:48f9de4f104b345a:0:0");
		responseObj.setAppCategoryCode("0");

		return responseObj;

	}

}
