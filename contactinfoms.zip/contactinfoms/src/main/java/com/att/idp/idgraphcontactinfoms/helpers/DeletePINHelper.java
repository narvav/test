package com.att.idp.idgraphcontactinfoms.helpers;

import java.time.Instant;
import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import com.att.idp.idgraphcontactinfoms.service.async.AsyncOtpEventPublisher;
import groovy.json.StringEscapeUtils;
import com.att.idp.idgraph.db.cosmos.entity.IdgOtpContainerHistory;
import com.att.idp.idgraph.db.cosmos.entity.HistoryMetadata;
import com.att.idp.idgraph.db.cosmos.entity.Operation;
import com.att.idp.idgraph.db.cosmos.entity.IdgOtpContainer;
import com.att.idp.idgraph.db.cosmos.entity.SecurityCode;
import com.att.idp.idgraph.db.cosmos.helper.IdgOtpDBHelper;
import com.att.idp.idgraph.db.cosmos.helper.OtpHistoryDBHelper;
import java.time.ZoneId;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import com.att.idp.idgraphcontactinfoms.model.EventData;
import com.att.idp.idgraphcontactinfoms.model.SecurityAccountEvent;
import com.att.idp.idgraphcontactinfoms.model.SecurityCodeEvent;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.mpsys.common.helpers.FeatureManagerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;
import com.att.idp.idgraphcontactinfoms.db.helper.SecurityCodeDBHelper;
import com.att.idp.idgraphcontactinfoms.helpers.voltage.ProofingEncryptionHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.RILDefs;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * The DeletePINHelper class is a Spring component that provides methods for deleting a PIN.
 *
 * It uses the ProofingEncryptionHelper and SecurityCodeDBHelper Spring components to perform its operations.
 * The class contains two main methods: deletePin and validateInput.
 *
 * The deletePin method takes a Map as input and returns a HashMap as output.
 * This method performs various operations including input validation, PIN deletion, and response construction.
 *
 * The validateInput method takes a Map as input and returns a Map as output.
 * This method performs various checks and validations on the input data.
 *
 * The class uses the SLF4J Logger for logging.
 */
@Component
public class DeletePINHelper {

	@Autowired
	private ProofingEncryptionHelper proofingEncryptionHelper;

	@Autowired
	private SecurityCodeDBHelper  securityCodeDBHelper;

	@Autowired
	private FeatureManagerHelper featureManager;

	@Autowired
	private IdgOtpDBHelper idgOtpDBHelper;

	private final OtpHistoryDBHelper otpHistoryDBHelper;

	@Qualifier("otpHistoryExecutor")
	private final Executor otpHistoryExecutor;

	private static final String OTP_HISTORY_SOURCE = "IDGraphContactInfoMs";

	// Constructor for OtpHistoryDBHelper and otpHistoryExecutor
	public DeletePINHelper(OtpHistoryDBHelper otpHistoryDBHelper, @Qualifier("otpHistoryExecutor") Executor otpHistoryExecutor) {
		this.otpHistoryDBHelper = otpHistoryDBHelper;
		this.otpHistoryExecutor = otpHistoryExecutor;
	}
	private static final String DELETE_ALL_HISTORY_MESSAGE = "Delete All was used to clear all OTPs";

	@Autowired
	AsyncOtpEventPublisher otpEventPublisher;
	/**
	 * This is a static variable of the DeletePINHelper class.
	 *
	 * It is of type String and is used to store the class name.
	 * This variable is used for logging purposes, where it is prefixed to the method name to create a log entry.
	 * The value of this variable is set to "DeletePinHelper." and it does not change throughout the execution of the program.
	 */
	public static final String sClassName =  "DeletePinHelper.";
	private static final Logger logger = LoggerFactory.getLogger(DeletePINHelper.class);
	
	private static final String ERROR_ENUM = "ErrorEnum";

	/**
	 * This method deletes a PIN.
	 *
	 * It takes a Map as input which contains the details for the deletePin operation.
	 * The method performs various operations including input validation, PIN deletion, and response construction.
	 *
	 * The method uses the validateInput method to validate the input data.
	 * If the validation fails, the method returns the response from the validateInput method.
	 *
	 * If the validation passes, the method proceeds to delete the PIN.
	 * The method uses the ProofingEncryptionHelper to encrypt the security code and the SecurityCodeDBHelper to delete the PIN from the database.
	 *
	 * If the deletion operation fails, the method constructs an error response and returns it.
	 * If the deletion operation succeeds, the method constructs a success response and returns it.
	 *
	 * The method uses the SLF4J Logger for logging.
	 *
	 * @param hmInput a Map that contains the details for the deletePin operation.
	 * @return a HashMap that contains the result of the deletePin operation.
	 */
	public HashMap<String, Object> deletePin(Map<String, Object> hmInput) {

		HashMap<String, Object> hmResponse   = null;
		String sAppInfo = null;
		String sAppStatusCode = null;
		boolean isTransactionRollbackOnError = false;
		String sMethodName =  "deletePIN.";
		List<SecurityCode> removedSecurityCodes = null;

		try {
			logger.info(SpiMarker.getInstance(), "DeletePinHelper.deletePin.HLP000 : Input Hash : {}",
					StructuredArguments.entries(hmInput));

			hmResponse   = (HashMap<String, Object>) validateInput(hmInput);

			logger.info(SpiMarker.getInstance(), "DeletePinHelper.deletePin.DPH_2.0 : hmInput after from  " +
							"validateInput() method :: {}",	StructuredArguments.entries(hmInput));

			sAppStatusCode = (String)hmResponse.get(CErrorDefs.COMMON_APP_STATUS_CODE);

			if (!sAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				sAppInfo = "Error returned from validationInput method = " + (String) hmResponse.get(CErrorDefs.COMMON_APP_STATUS_MSG);
				logger.info("{}{}DPH_2.1 :: {}",sClassName, sMethodName , sAppInfo);
				return hmResponse;
			}

			String sIdentificationType  = (String)hmInput.get(CommonDefs.IDENTIFICATION_TYPE);
			String sAccountID			= (String)hmInput.get(CommonDefs.ACCOUNT_ID);
			String sDeleteAll			= (String)hmInput.get(CommonDefs.DELETE_All);
			String sSecurityCode		= (String)hmInput.get(CommonDefs.SECURITY_CODE);
			String sReasonCode			= (String)hmInput.get(CommonDefs.REASON_CODE);
			String sCallingSystemId		= (String)hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

			Boolean isDeleteAllFlag = false;

			if(CommonDefs.IND_Y.equalsIgnoreCase(sDeleteAll)) {

				isDeleteAllFlag = true;
			}

			HashMap<String,Object> hmMPSInput  = CommonUtil.getHashMap();

			hmMPSInput.put(MPSDefs.DB_IDENTIFICATION_TYPE, sIdentificationType);
			hmMPSInput.put(MPSDefs.DB_ACCOUNT_ID, sAccountID);

			if(!isDeleteAllFlag) {

				String sEncryptedSecurityCode  = proofingEncryptionHelper.generateSHA1Value(sSecurityCode);
				hmMPSInput.put(MPSDefs.DB_SECURITY_CODE, sEncryptedSecurityCode);
				hmMPSInput.put(MPSDefs.DB_REASON_CODE, sReasonCode);
			}

			String otpDataSource = getOtpDataSource();
			if (!"ONLYCOSMOS".equalsIgnoreCase(otpDataSource)) {
				hmResponse = securityCodeDBHelper.deleteSecurityPIN(hmMPSInput, isDeleteAllFlag );
				sAppStatusCode = (String)hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);

				if (!CErrorDefs.COMMON_SUCCESS.equalsIgnoreCase(sAppStatusCode)) {
					sAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
					logger.info("{}{}DPH_2.3 :: {}", sClassName, sMethodName, sAppInfo);
					hmResponse = CommonErrorMap.makeCategoryMap(Integer.parseInt(sAppStatusCode), sAppInfo);
					return hmResponse;

				}else {
					isTransactionRollbackOnError = true;
				}
			}


			if(!"ONLYORACLE".equalsIgnoreCase(otpDataSource)) {
				try {
				//override the security code with SHA256 encrypted value for Cosmos DB
				String sSHA256EncryptedSecurityCode = null;
				if (sSecurityCode != null) {
					HashMap<String, String> passwordMap = new HashMap<>();
					passwordMap.put(MPSDefs.WS_CLEAR_TEXT, sSecurityCode);
					sSHA256EncryptedSecurityCode = CommonUtilHelper.generateGenericPassword(passwordMap,
							"SHA256").get(RILDefs.RIL_GEN_PASSWORD).toString();
					hmMPSInput.put(MPSDefs.DB_SECURITY_CODE, sSHA256EncryptedSecurityCode);
				}

				hmResponse = idgOtpDBHelper.deleteSecurityPIN(hmMPSInput, isDeleteAllFlag);
				removedSecurityCodes = (List<SecurityCode>) hmResponse.get("removedSecurityCodes");

				sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);

				if (!CErrorDefs.COMMON_SUCCESS.equalsIgnoreCase(sAppStatusCode)) {
					sAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
					if ("ORACLEMASTER".equalsIgnoreCase(otpDataSource)) {
						logger.error("{}{}DPH_2.3_COSMOS : Cosmos DB ORACLEMASTER ERROR SKIP - deleteSecurityPIN failed. Continuing. Error: {}", sClassName, sMethodName, sAppInfo);
					} else {
						logger.info("{}{}DPH_2.3 :: {}", sClassName, sMethodName, sAppInfo);
						hmResponse = CommonErrorMap.makeCategoryMap(Integer.parseInt(sAppStatusCode), sAppInfo);
						return hmResponse;
					}

				} else {
					if(featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata")) {
						if (isDeleteAllFlag) {
							final Map<String, Object> hmInputFinal = new HashMap<>(hmInput);
							EventData eventData = buildEventData(hmInputFinal);
							String accountId = hmInputFinal.get(CommonDefs.ACCOUNT_ID).toString();
							otpEventPublisher.publishDeletePinEvent(accountId, eventData);
						} else {
							// Use removedSecurityCodes directly instead of re-querying the DB.
							// updateSecurityCodeStatus removes the matched code from the container,
							// so a re-query would not find it.
							if (removedSecurityCodes != null && !removedSecurityCodes.isEmpty()) {
								SecurityCode matchedCode = removedSecurityCodes.get(0);
								EventData eventData = buildValidateEventData(sIdentificationType, sAccountID, sCallingSystemId, matchedCode);
								otpEventPublisher.publishValidatePinEvent(sAccountID, eventData);
							}
							}
					}
				}
				} catch (Exception cosmosEx) {
					if ("ORACLEMASTER".equalsIgnoreCase(otpDataSource)) {
						logger.error("{}{}DPH_2.3_COSMOS : Cosmos DB ORACLEMASTER ERROR SKIP - deleteSecurityPIN exception. Continuing. Error: {}", sClassName, sMethodName, cosmosEx.getMessage(), cosmosEx);
					} else {
						throw cosmosEx;
					}
				}

			}
			hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "SUCCESS");

			if (!"ONLYORACLE".equalsIgnoreCase(otpDataSource)) {
				if (isDeleteAllFlag) {
					saveOtpHistoryAsync(sIdentificationType, sAccountID, sCallingSystemId,
							Operation.DELETE, null, DELETE_ALL_HISTORY_MESSAGE);
				} else {
					saveDeleteHistoryPairAsync(sIdentificationType, sAccountID, sCallingSystemId, removedSecurityCodes);
				}
			}

		}catch (Exception e) {

			hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			sAppInfo = "Exception thrown DeletePIN method : " + hmResponse;
			logger.info("{}{}AUH_125 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(sAppInfo)));

		}finally {

			sAppInfo = "Response from DeletePIN = " + hmResponse;
			logger.info("{}{}DPH_3 : {}",sClassName,sMethodName , sAppInfo );

			String sAppCategoryCode = (String)hmResponse.get(CommonDefs.COMMON_APP_CATEGORY_CODE);

			if(isTransactionRollbackOnError &&  !CommonDefs.COMMON_SUCCESS.equalsIgnoreCase(sAppCategoryCode)){
				hmResponse.put("isTransactionRollback", "Y");
			}
			logger.info("{}{}HLP999 : hmResult = {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmResponse)));
		}

		return hmResponse;
	}

	private EventData buildEventData(Map<String, Object> hmInput) {
		String accountId = hmInput.get(CommonDefs.ACCOUNT_ID).toString();
		String identificationType = hmInput.get(CommonDefs.IDENTIFICATION_TYPE).toString();

		EventData eventData = new EventData();
		eventData.setAccountId(accountId);
		eventData.setIdentificationType(identificationType);

		return eventData;
	}

	private EventData buildValidateEventData(String sIdentificationType, String sAccountId, String sCallingSystemId, SecurityCode secCode) {
		EventData eventData = new EventData();
		eventData.setAccountId(sAccountId);
		eventData.setIdentificationType(sIdentificationType);
		eventData.setSecurityAccountEvent(buildSecurityAccountEvent(sCallingSystemId, secCode));
		eventData.setSecurityCodeEvent(buildSecurityCodeEvent(sCallingSystemId, secCode));
		return eventData;
	}

	private SecurityAccountEvent buildSecurityAccountEvent(String sCallingSystemId, SecurityCode secCode) {
		SecurityAccountEvent accountEvent = new SecurityAccountEvent();

		String expiryStr = secCode.getSecurityCodeExpires();
		if (expiryStr != null && !expiryStr.isEmpty()) {
			try {
				accountEvent.setAccountEntryExpires(Instant.parse(expiryStr));
			} catch (Exception e) {
				logger.warn("Failed to parse account entry expires date: {}", e.getMessage());
				accountEvent.setAccountEntryExpires(Instant.now());
			}
		}

		accountEvent.setCumulativeFailureCount(String.valueOf(secCode.getVerificationFailureCount()));
		accountEvent.setCreatedDate(Instant.now());
		accountEvent.setUpdatedDate(Instant.now());
		accountEvent.setUpdatedBy(sCallingSystemId);

		return accountEvent;
	}

	private SecurityCodeEvent buildSecurityCodeEvent(String sCallingSystemId, SecurityCode secCode) {
		SecurityCodeEvent codeEvent = new SecurityCodeEvent();

		codeEvent.setSecurityCode(secCode.getSecurityCode());
		codeEvent.setVerificationFailureCount(String.valueOf(secCode.getVerificationFailureCount()));

		String expiryStr = secCode.getSecurityCodeExpires();
		if (expiryStr != null && !expiryStr.isEmpty()) {
			try {
				codeEvent.setSecurityCodeExpires(Instant.parse(expiryStr));
			} catch (Exception e) {
				logger.warn("Failed to parse security code expires date: {}", e.getMessage());
			}
		}

		codeEvent.setSecurityCodeStatus(secCode.getSecurityCodeStatus());
		codeEvent.setStatusChangeDate(Instant.now());
		codeEvent.setSource(secCode.getSource());
		codeEvent.setDeliveryMethod(secCode.getDeliveryMethod());
		codeEvent.setDeliveryDetail(secCode.getDeliveryDetail());

		if (secCode.getCreatedDate() != null) {
			codeEvent.setCreatedDate(secCode.getCreatedDate().atZone(ZoneId.of("UTC")).toInstant());
		} else {
			codeEvent.setCreatedDate(Instant.now());
		}

		codeEvent.setUpdatedDate(Instant.now());
		codeEvent.setUpdatedBy(sCallingSystemId);

		return codeEvent;
	}

	/**
	 * This method validates the input for the deletePin operation.
	 *
	 * It takes a Map as input which contains the details for the deletePin operation.
	 * The method performs various checks and validations on the input data.
	 *
	 * If the 'DELETE_All' flag in the input map is set to 'N', the method checks if the 'SECURITY_CODE' and 'REASON_CODE' are present and valid.
	 * If any of these checks fail, the method returns a map with an error code and message.
	 *
	 * If all checks pass, the method returns a map with a success code and message.
	 *
	 * @param hmInput a Map that contains the details for the deletePin operation.
	 * @return a Map that contains the result of the validation.
	 */
	public Map<String, Object> validateInput(Map<String, Object> hmInput) {
        String stAppInfo = null;
        String sMethodName = ".validateInput.";
        HashMap<String, Object> hmResult = null;
        String stDeleteAll = (String) hmInput.get(CommonDefs.DELETE_All);
        String stSecurityCode = (String) hmInput.get(CommonDefs.SECURITY_CODE);
        String stReasonCode = (String) hmInput.get(CommonDefs.REASON_CODE);
		Optional.ofNullable(hmInput.get(CommonDefs.IS_EXTERNAL_CALL))
				.ifPresentOrElse(
						value -> {},
						() -> hmInput.put(CommonDefs.IS_EXTERNAL_CALL, "Y")
				);
        if (CommonDefs.IND_N.equalsIgnoreCase(stDeleteAll)) {

            if (stSecurityCode == null || stSecurityCode.isEmpty()) {
                stAppInfo = "SecurityCode is missing";
                logger.info("{}{}DPH_1.1 :: {}",sClassName, sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                return hmResult;
            }

            if (stReasonCode == null || stReasonCode.isEmpty()) {
                stAppInfo = "ReasonCode is missing";
                logger.info("{}{}DPH_1.2 :: {}",sClassName,sMethodName ,stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                return hmResult;
            }
			if(hmInput.get(CommonDefs.IS_EXTERNAL_CALL) != null && CommonDefs.IND_Y.equalsIgnoreCase((String)hmInput.get(CommonDefs.IS_EXTERNAL_CALL))) {
				if (!"REGISTERED".equalsIgnoreCase(stReasonCode) && !"PW RESET".equalsIgnoreCase(stReasonCode)) {
					stAppInfo = "reasonCode should be one of REGISTERED or PW RESET";
					logger.info("{}{}DPH_1.3 :: {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
					return hmResult;
				}
			}
        }

        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "SUCCESS");
        return hmResult;
    }

	private void saveOtpHistoryAsync(String identificationType, String accountId, String callingSystemId,
			Operation operation, List<SecurityCode> securityCodes, String historyMessage) {
		CompletableFuture.runAsync(() -> {
			try {
				IdgOtpContainerHistory history = IdgOtpContainerHistory.builder()
						.id(UUID.randomUUID().toString())
						.accountId(accountId)
						.identificationType(identificationType)
						.updatedBy(callingSystemId)
						.securityCodes(securityCodes)
						.historyMetadata(HistoryMetadata.builder()
								.operation(operation)
								.source(OTP_HISTORY_SOURCE)
								.timestamp(com.att.idp.idgraph.db.cosmos.util.DateUtil.getUTCNow())
								.message(historyMessage)
								.build())
						.build();
				otpHistoryDBHelper.saveOtpHistory(history);
			} catch (Exception e) {
				logger.error("Failed to save OTP history asynchronously for accountId: {}: {}",
						accountId, StringEscapeUtils.escapeJava(e.getMessage()), e);
			}
		}, otpHistoryExecutor);
	}

	private void saveDeleteHistoryPairAsync(String identificationType, String accountId, String callingSystemId,
			List<SecurityCode> removedSecurityCodes) {
		CompletableFuture.runAsync(() -> {
			try {
				List<SecurityCode> allCodesPostUpdate = new ArrayList<>();
				try {
					IdgOtpContainer query = new IdgOtpContainer();
					query.setIdentificationType(identificationType);
					query.setAccountId(accountId);
					Optional<IdgOtpContainer> container = idgOtpDBHelper.findByIdentificationTypeAndAccountId(query);
					if (container.isPresent() && container.get().getSecurityCodes() != null) {
						allCodesPostUpdate.addAll(container.get().getSecurityCodes());
					}
				} catch (Exception e) {
					logger.warn("Failed to read OTP container for history snapshot: {}", StringEscapeUtils.escapeJava(e.getMessage()));
				}
				if (removedSecurityCodes != null) {
					allCodesPostUpdate.addAll(removedSecurityCodes);
				}

				IdgOtpContainerHistory updateHistory = IdgOtpContainerHistory.builder()
						.id(UUID.randomUUID().toString())
						.accountId(accountId)
						.identificationType(identificationType)
						.updatedBy(callingSystemId)
						.securityCodes(allCodesPostUpdate)
						.historyMetadata(HistoryMetadata.builder()
								.operation(Operation.UPDATE)
								.source(OTP_HISTORY_SOURCE)
								.timestamp(com.att.idp.idgraph.db.cosmos.util.DateUtil.getUTCNow())
								.build())
						.build();
				otpHistoryDBHelper.saveOtpHistory(updateHistory);

				IdgOtpContainerHistory deleteHistory = IdgOtpContainerHistory.builder()
						.id(UUID.randomUUID().toString())
						.accountId(accountId)
						.identificationType(identificationType)
						.updatedBy(callingSystemId)
						.securityCodes(removedSecurityCodes)
						.historyMetadata(HistoryMetadata.builder()
								.operation(Operation.DELETE)
								.source(OTP_HISTORY_SOURCE)
								.timestamp(com.att.idp.idgraph.db.cosmos.util.DateUtil.getUTCNow())
								.build())
						.build();
				otpHistoryDBHelper.saveOtpHistory(deleteHistory);
			} catch (Exception e) {
				logger.error("Failed to save OTP delete history pair for accountId: {}: {}",
						accountId, StringEscapeUtils.escapeJava(e.getMessage()), e);
			}
		}, otpHistoryExecutor);
	}

	/**
	 * This method is responsible for retrieving the OTP data source from the feature manager.
	 *
	 * It checks if the feature manager has a value for the key "cfg-idgraph-contactinfo-otpdatasource".
	 * If the value is found, it returns that value.
	 * If the value is not found (i.e., it is null), it sets a default value of "COSMOSMASTER" and logs an error message.
	 *
	 * @return a String representing the OTP data source.
	 */
	public String getOtpDataSource() {
		String otpDataSource = featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource");
		if (otpDataSource == null) {
			otpDataSource = "COSMOSMASTER";
			logger.error("IXP Flag cfg-idgraph-contactinfo-otpdatasource is null, setting default value {} ", otpDataSource);
		}
		else if (!("ORACLEMASTER".equalsIgnoreCase(otpDataSource)
				|| "ONLYORACLE".equalsIgnoreCase(otpDataSource)
				|| "ONLYCOSMOS".equalsIgnoreCase(otpDataSource)
				|| "COSMOSMASTER".equalsIgnoreCase(otpDataSource))) {
			throw new IllegalArgumentException("Invalid OTP data source: " + otpDataSource);
		}
		return otpDataSource;
	}

}
