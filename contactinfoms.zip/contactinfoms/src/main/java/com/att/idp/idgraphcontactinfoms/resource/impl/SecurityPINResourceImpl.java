package com.att.idp.idgraphcontactinfoms.resource.impl;

import java.sql.SQLException;
import java.util.Map;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import com.att.idp.cd.observability.metrics.utils.Constants;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.Response;

import com.att.idp.idgraphcontactinfoms.resource.request.InquirePINRequest;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.stereotype.Controller;

import com.att.idp.idgraphcontactinfoms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphcontactinfoms.exceptions.MPSException;
import com.att.idp.idgraphcontactinfoms.request.validator.DeletePINRequestValidator;
import com.att.idp.idgraphcontactinfoms.request.validator.GeneratePINRequestValidator;
import com.att.idp.idgraphcontactinfoms.request.validator.InquirePINRequestValidator;
import com.att.idp.idgraphcontactinfoms.request.validator.ValidatePINRequestValidator;
import com.att.idp.idgraphcontactinfoms.resource.SecurityPINResource;
import com.att.idp.idgraphcontactinfoms.resource.request.DeletePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.request.GeneratePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.request.ValidatePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.DeletePinResponse;
import com.att.idp.idgraphcontactinfoms.resource.response.GeneratePINResponse;
import com.att.idp.idgraphcontactinfoms.resource.response.InquirePINResponse;
import com.att.idp.idgraphcontactinfoms.resource.response.ValidatePINResponse;
import com.att.idp.idgraphcontactinfoms.service.DeletePINService;
import com.att.idp.idgraphcontactinfoms.service.GeneratePINService;
import com.att.idp.idgraphcontactinfoms.service.InquirePINService;
import com.att.idp.idgraphcontactinfoms.service.ValidatePINService;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_75;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_90;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_95;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_99;
import static com.att.idp.cd.observability.metrics.utils.Constants.POST;
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_IB;
import static com.att.idp.idgraphcontactinfoms.utils.Constants.IDGRAPH_CONTACT_INFO_MS_IB;

/**
 * This class implements the SecurityPINResource interface and is responsible for handling operations related to Security PIN.
 *
 * It is annotated with @Controller, indicating that it's a Spring MVC Controller.
 * The class has dependencies on GeneratePINService, GeneratePINRequestValidator, DeletePINService, DeletePINRequestValidator, ValidatePINRequestValidator, ValidatePINService which are autowired.
 * It also has a Logger instance for logging.
 *
 * The class has three main methods: generatePIN, deletePin, validatePIN.
 * Each of these methods takes specific request objects and HttpHeaders as input and returns a Response.
 * These methods are responsible for generating, deleting, and validating a Security PIN respectively.
 *
 * The class is annotated with @ApiImplicitParams to provide metadata about the API such as the API's name, path, operations, responses.
 */
@Controller
@OpenAPIDefinition(
		info = @Info(title="Contact Info",
				description="IDGraphContactInfoMs supports multiple functions.  " +
						"This application provides APIs that support multiple functions including returning CPNI " +
						"eligible contact methods for accessId, wireless, enabler and wireline accounts, OTP generation," +
						" validation and deletion.\n.", version="0.0.1"),
		servers = {
				@Server(url="https://apporigin-dev2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphcontactinfoms/"),
				@Server(url="https://apporigin-tst2-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphcontactinfoms/")
		})
public class SecurityPINResourceImpl implements SecurityPINResource{
	
	@Autowired
	private GeneratePINService generatePINService;
	
	@Autowired
	private GeneratePINRequestValidator generatePINRequestValidator;
	
	@Autowired
	private DeletePINService deletePinService;
	
	@Autowired
	private DeletePINRequestValidator deletePINRequestValidator;
	
	@Autowired
	private ValidatePINRequestValidator validatePINRequestValidator;
	
	@Autowired
	private ValidatePINService validatePINService;
	
	@Autowired
	private InquirePINService inquirePinService;
	
	@Autowired
	private InquirePINRequestValidator inquirePINRequestValidator;
	
	
	public static final Logger logger = LoggerFactory.getLogger(SecurityPINResourceImpl.class);

	@Override
	@TimedMetrics(name = IDGRAPH_CONTACT_INFO_MS_IB, type = REST_IB, description = "Generates security PIN",
			tags = { Constants.URI , "/v1/pin/generate", METHOD, POST}, histogram = true)
	public Response generatePIN(GeneratePINRequest generatePINRequest, HttpHeaders httpHeaders) throws MPSException {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		GeneratePINResponse generatePINResponse = null;
		long startTm = System.currentTimeMillis();
		Response responseObj = null;
		try {

			MultivaluedMap<String, String> requestHeader = httpHeaders.getRequestHeaders();

			logger.info(SpiMarker.getInstance(), "WEB_01 : GeneratePIN Input : {} | GeneratePIN Request Header  : {}",
					generatePINRequest != null ? CommonUtilHelper.sanitizeForLog(generatePINRequest.toString()) : null,
					CommonUtilHelper.sanitizeForLog(CommonUtilHelper.objectToString(httpHeaders)));

			generatePINResponse = generatePINRequestValidator.generatePINRequestValidator(httpHeaders, generatePINRequest);
    
			logger.info("WEB000 : GeneratePIN Input : {}", generatePINRequest);
			
			if (generatePINResponse == null) {
				// call the service class
				generatePINResponse = generatePINService.generatePIN(generatePINRequest, requestHeader);
				logger.info(SpiMarker.getInstance(),"WEB_02 : GeneratePIN Service Response : {}", generatePINResponse);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: {}", e.getMessage());
				throw e;
			}
			else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
            }
			else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			}	
			
			hmResponse.put(CommonDefs.TRANSACTION_ID, generatePINRequest.getTransactionId());
			hmResponse.put("idp-trace-id", generatePINRequest.getIdpTraceId());
			if(generatePINResponse!=null && generatePINResponse.getSecurityCode()!=null) {
				hmResponse.put(CommonDefs.SECURITY_CODE,generatePINResponse.getSecurityCode());
			}
			if(generatePINResponse!=null && generatePINResponse.getSecurityCodeExpires()!=null) {
				hmResponse.put(CommonDefs.SECURITY_CODE_EXPIRES,generatePINResponse.getSecurityCodeExpires());
			}
			generatePINResponse = CommonUtilHelper.generatePINResponse(hmResponse);
		}
		
		responseObj = CommonUtilHelper.buildMSResponse(generatePINResponse); 
		
		String sTimeTaken = getElapsedTimeInSecs(startTm) + " seconds";

		logger.info(SpiMarker.getInstance(),"WEB999 : Total time taken : "+sTimeTaken+" GeneratePIN Response : {}", generatePINResponse);
		return responseObj;
		
	}
	
	@Override
	public Response deletePin(DeletePINRequest deletePINRequest,HttpHeaders httpHeaders) throws MPSException {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		DeletePinResponse deletePinResponse = null;
		long startTm = System.currentTimeMillis();
		Response responseObj = null;
		try {

			MultivaluedMap<String, String> requestHeader = httpHeaders.getRequestHeaders();

			logger.info(SpiMarker.getInstance(),"SecurityPINResourceImpl.deletePin.WEB_01 : DeletePin Input : {} | DeletePin Request Header  : {}", deletePINRequest, CommonUtilHelper.objectToString(requestHeader));
			
			deletePinResponse = deletePINRequestValidator.deletePINRequestValidator(httpHeaders, deletePINRequest);
    
			logger.info(SpiMarker.getInstance(),"SecurityPINResourceImpl.deletePin.WEB000 : DeletePin Input : {}", deletePINRequest);
			
			if (deletePinResponse == null) {
				// call the service class
				deletePinResponse = deletePinService.deletePin(deletePINRequest, requestHeader);
				logger.info("SecurityPINResourceImpl.deletePin.WEB_02 : DeletePin Service Response : {}", deletePinResponse);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: {}", e.getMessage());
				throw e;
			}
			else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
            }
			else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			}	
			
			hmResponse.put(CommonDefs.TRANSACTION_NAME, deletePINRequest.getTransactionName());
			hmResponse.put("idp-trace-id", deletePINRequest.getIdpTraceId());
			deletePinResponse = (DeletePinResponse) CommonUtilHelper.generateCIRResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(deletePinResponse);
		String sTimeTaken = getElapsedTimeInSecs(startTm) + " seconds";

		logger.info("SecurityPINResourceImpl.deletePin.WEB999 : Total time taken : {} deletePin Response : {}",sTimeTaken, deletePinResponse);
		return responseObj;
	}
	
	@Override
	@TimedMetrics(name = IDGRAPH_CONTACT_INFO_MS_IB, type = REST_IB, description = "Validates security PIN",
			tags = { Constants.URI , "/v1/pin/validate", METHOD, POST}, histogram = true)
	public Response validatePIN(ValidatePINRequest validatePINRequest,HttpHeaders httpHeaders) throws MPSException {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		ValidatePINResponse validatePINResponse = null;
		long startTm = System.currentTimeMillis();
		Response responseObj = null;
		try {

			MultivaluedMap<String, String> requestHeader = httpHeaders.getRequestHeaders();

			logger.info(SpiMarker.getInstance(),"SecurityPINResourceImpl.validatePIN.WEB_01 : validatePIN Input : {} | validatePIN Request Header  : {}", validatePINRequest, StringUtils.normalizeSpace(CommonUtilHelper.objectToString(requestHeader)));

			validatePINResponse = validatePINRequestValidator.validatePINRequestValidator(httpHeaders, validatePINRequest);
    
			logger.info(SpiMarker.getInstance(),"SecurityPINResourceImpl.validatePIN.WEB000 : validatePIN Input : {}",  StringUtils.normalizeSpace(CommonUtilHelper.objectToString(validatePINRequest)));
			
			if (validatePINResponse == null) {
				// call the service class
				validatePINResponse = validatePINService.validatePIN(validatePINRequest, requestHeader);
				logger.info("SecurityPINResourceImpl.validatePIN.WEB_02 : ValidatePINService Response : {}", validatePINResponse);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: {}", e.getMessage());
				throw e;
			}
			else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
            }
			else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			}	
			
			hmResponse.put("idp-trace-id", validatePINRequest.getIdpTraceId());
			hmResponse.put(CommonDefs.TRANSACTION_NAME, validatePINRequest.getTransactionName());
			validatePINResponse = (ValidatePINResponse) CommonUtilHelper.generateCIRResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(validatePINResponse);
		String sTimeTaken = getElapsedTimeInSecs(startTm) + " seconds";

		logger.info("WEB999 : Total time taken : {} ValidatePIN Response : {}",sTimeTaken, validatePINResponse);
		return responseObj;
	}
	
	@Override
	public Response inquirePin(InquirePINRequest inquirePINRequest, HttpHeaders httpHeader) throws MPSException {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		InquirePINResponse inquirePINResponse = null;
		long startTm = System.currentTimeMillis();
		Response responseObj = null;
		try {

			MultivaluedMap<String, String> requestHeader = httpHeader.getRequestHeaders();

			logger.info(SpiMarker.getInstance(),"SecurityPINResourceImpl.inquirePin.WEB_01 : InquirePin Input : {} | InquirePin Request Header  : {}", inquirePINRequest, CommonUtilHelper.objectToString(requestHeader));
			
			inquirePINResponse = inquirePINRequestValidator.inquirePINRequestValidator(httpHeader, inquirePINRequest);
    
			logger.info(SpiMarker.getInstance(),"SecurityPINResourceImpl.inquirePin.WEB000 : InquirePin Input : {}", inquirePINRequest);
			
			if (inquirePINResponse == null) {
				// call the service class
				inquirePINResponse = inquirePinService.inquirePIN(inquirePINRequest, requestHeader);
				logger.info("SecurityPINResourceImpl.inquirePin.WEB_02 : inquirePin Service Response : {}", inquirePINRequest);
			}
		} catch (Exception e) {
			if (e instanceof InvalidInputDataException) {
				logger.error("InvalidInputDataException: {}", e.getMessage());
				throw e;
			}
			else if(NestedExceptionUtils.getRootCause(e) instanceof SQLException){
                hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, e.getMessage());
            }
			else {
				hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			}	
			
			hmResponse.put(CommonDefs.TRANSACTION_NAME, inquirePINRequest.getTransactionName());
			hmResponse.put("idp-trace-id", inquirePINRequest.getIdpTraceId());
			inquirePINResponse = (InquirePINResponse) CommonUtilHelper.generateCIRResponse(hmResponse);
		}
		responseObj = CommonUtilHelper.buildMSResponse(inquirePINResponse);
		String sTimeTaken = getElapsedTimeInSecs(startTm) + " seconds";

		logger.info("SecurityPINResourceImpl.inquirePin.WEB999 : Total time taken : {} inquirePIN Response : {}",sTimeTaken, inquirePINResponse);
		return responseObj;
	}
	
	
	/**
	 * 
	 * @param startTime
	 * @return
	 */
	private String getElapsedTimeInSecs(long startTime) {

		StringBuffer sElapsedTime = new StringBuffer();

		long diff = (System.currentTimeMillis() - startTime);
		long ms = diff % 1000;

		sElapsedTime.append(diff / 1000).append('.'); // secs.

		if (ms < 10)
			sElapsedTime.append("00").append(ms); // 3 digits ms 0 padded
		else if (ms < 100)
			sElapsedTime.append('0').append(ms);
		else
			sElapsedTime.append(ms);

		return sElapsedTime.toString();
	}


		
}
