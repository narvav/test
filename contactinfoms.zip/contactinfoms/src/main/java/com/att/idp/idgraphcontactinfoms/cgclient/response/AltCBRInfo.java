package com.att.idp.idgraphcontactinfoms.cgclient.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * The AltCBRInfo class represents alternative customer billing record information in the system.
 * It implements the Serializable interface, which means its instances can be converted to a byte stream and
 * restored back to the same object later. This is useful for storing objects in a file or sending them over a network.
 *
 * This class contains various properties related to a customer's billing record such as phoneNumber, subContactType, contactType, and isATTNumber.
 * Each property has its corresponding getter and setter methods.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.cgclient.response package.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "AltCBRInfo")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class AltCBRInfo implements Serializable {

	private static final long serialVersionUID = -2327317846208097250L;

	private String phoneNumber;
	private String subContactType;
	private String contactType;
	private Boolean isATTNumber;
}