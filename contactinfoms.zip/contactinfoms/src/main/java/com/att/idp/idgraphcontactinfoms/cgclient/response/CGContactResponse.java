package com.att.idp.idgraphcontactinfoms.cgclient.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

/**
 * The CGContactResponse class represents a customer's contact response in the system.
 * It implements the Serializable interface, which means its instances can be converted to a byte stream and
 * restored back to the same object later. This is useful for storing objects in a file or sending them over a network.
 *
 * This class contains various properties related to a customer's contact such as email, cbrInfo, altCbrInfo, and address.
 * Each property has its corresponding getter and setter methods.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.cgclient.response package.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "CGContactResponse")
@Getter
@Setter
@NoArgsConstructor
public class CGContactResponse implements Serializable {

	private static final long serialVersionUID = 8864035158291938561L;

	private Email email;
	private CBRInfo cbrInfo;
	private AltCBRInfo altCbrInfo;
	private Address address;
}