package com.att.idp.idgraphcontactinfoms.resource;

import java.sql.SQLException;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import com.att.idp.idgraphcontactinfoms.cgclient.response.CGResponse;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.web.bind.annotation.GetMapping;

import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * This is the Interface definition for GetSecurityCodeData.
 *
 * It uses the JAX-RS annotations to define the HTTP methods, paths, consumed and produced media types.
 * It also uses the Swagger annotations to provide metadata about the API such as the API's name, path, operations, responses.
 *
 * The main method in this interface is the getSecurityCodeDataQuery method, which does not take any input and returns a Response.
 * This method is annotated with @GetMapping, @Path, @Consumes, @Produces, @ApiResponses to define its HTTP method, path, consumed and produced media types, operation description, responses.
 *
 * The interface also throws SQLException that can occur during the execution of the method.
 */
@Tag(name = "getSecurityCode")
@Path("/getSecurityCode")
@Produces({ MediaType.APPLICATION_JSON })
public interface GetSecurityCodeData {

	/**
	 * This method is responsible for getting the security code data.
	 *
	 * It does not take any input parameters and returns a Response.
	 * The method is annotated with @GetMapping, @Path, @Consumes, @Produces, @ApiResponses to define its HTTP method, path, consumed and produced media types, operation description, responses.
	 * The method also throws SQLException that can occur during the execution of the method.
	 *
	 * @return a Response that contains the result of the query. If the query is successful, the response contains a success message. If the query fails, the response contains an error message.
	 * @throws SQLException if there is an exception in the database operation.
	 */
	@GetMapping
	@Path("/getSecurityCodeDataQuery")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description =  "Success",
			content = @Content(mediaType = "application/json", schema = @Schema(implementation = CGResponse.class))),

			@ApiResponse(responseCode = "400", description =  "Bad Request"),

			@ApiResponse(responseCode = "500", description =  "Unknown exception in application") })
	public Response getSecurityCodeDataQuery() throws SQLException;
}