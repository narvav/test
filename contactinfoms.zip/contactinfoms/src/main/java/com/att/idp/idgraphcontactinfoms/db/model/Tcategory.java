package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "TCATEGORY", schema = "MPS_OWNER", uniqueConstraints = @UniqueConstraint(columnNames = "CATEGORY_NAME"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tcategory implements java.io.Serializable {

	private static final long serialVersionUID = -4557867915461604954L;

	@Id
	@Column(name = "CATEGORY_ID", unique = true, nullable = false, precision = 22, scale = 0)
	private Long categoryId;

	@Column(name = "CATEGORY_NAME", unique = true, nullable = false, length = 30)
	private String categoryName;

	@Column(name = "CATEGORY_DESC")
	private String categoryDesc;

	@Column(name = "CATEGORY_TYPE", length = 10)
	private String categoryType;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tcategory")
	private Set<Tmemberdevice> tmemberdevices = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tcategory")
	private Set<Tmpsattribute> tmpsattributes = new HashSet<>(0);
}