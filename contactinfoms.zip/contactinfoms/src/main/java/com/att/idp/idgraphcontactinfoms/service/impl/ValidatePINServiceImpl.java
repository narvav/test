package com.att.idp.idgraphcontactinfoms.service.impl;

import java.util.Map;

import jakarta.ws.rs.core.MultivaluedMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.idp.idgraphcontactinfoms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphcontactinfoms.helpers.ValidatePINHelper;
import com.att.idp.idgraphcontactinfoms.resource.request.ValidatePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.ValidatePINResponse;
import com.att.idp.idgraphcontactinfoms.service.ValidatePINService;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.MPSDefs;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This class implements the ValidatePINService interface and is responsible for handling operations related to validating a Security PIN.
 *
 * It is annotated with @Service, indicating that it's a Spring Service.
 * The class has a dependency on ValidatePINHelper, which is autowired.
 * It also has a Logger instance for logging.
 *
 * The class has one main method: validatePIN.
 * This method takes a ValidatePINRequest and MultivaluedMap<String, String> as input parameters and returns a ValidatePINResponse.
 * The method is responsible for validating a Security PIN and handling the response.
 *
 * The class is also annotated with @Transactional, indicating that it's a transactional class with a specific transaction manager and rollback rules.
 */
@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class ValidatePINServiceImpl implements ValidatePINService{

	public static final Logger logger = LoggerFactory.getLogger(ValidatePINServiceImpl.class);

	private static String sClassName = "ValidatePINServiceImpl";
	@Autowired
	private ValidatePINHelper validatePINHelper;
	@Override
	public ValidatePINResponse validatePIN(ValidatePINRequest validatePINRequest, MultivaluedMap<String, String> requestHeader) {

		Map<String, Object> hmInput = null;
		Map<String, Object> hmResponse = null;
		String sMethodName = ".validatePIN.";

		hmInput = CommonUtilHelper.objectToMap(validatePINRequest);

		logger.info(SpiMarker.getInstance(),"ValidatePINServiceImpl.validatePIN.VPS_01 : Calling validatePINHelper.validatePIN with Input : {}", StructuredArguments.entries(hmInput));

		hmResponse = validatePINHelper.validatePIN(hmInput);
		logger.info("{}{}VPS_02 : Response from ValidatePIN Helper : {}", sClassName, sMethodName, hmResponse);

		if (hmResponse ==null || hmResponse.isEmpty()) {
			hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from validatePINHelper.validatePIN");
			logger.info("{}{}VPS_03 : Null response from validatePINHelper.validatePIN", sClassName, sMethodName);
		} else {
			String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (stAppStatusCode == null) {
				hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from validatePINHelper.validatePIN");
				logger.info("{}{}VPS_04 : Null response from validatePINHelper.validatePIN", sClassName, sMethodName);
			}
		}

		hmResponse.put("idp-trace-id", validatePINRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME,"ValidatePIN");
		ValidatePINResponse validatePINResponse = (ValidatePINResponse) CommonUtilHelper.generateCIRResponse(hmResponse);

		String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

		if (sTxnRollBack != null) {
			throw new InvalidInputDataException(hmResponse);
		}
		logger.info("{}{}VPS_05 : Response from ValidatePINServiceImpl.validatePIN : {}", sClassName, sMethodName,
				validatePINResponse);
		return validatePINResponse;
	}
}
