package com.att.idp.idgraphcontactinfoms.db.repository;

import java.sql.SQLException;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.att.idp.idgraphcontactinfoms.db.model.Tsystemofrecord;

/**
 * This is an interface for the SystemOfRecordRepository.
 *
 * It extends JpaRepository, which is a JPA specific extension of Repository. It contains the full API of CrudRepository and PagingAndSortingRepository. So it contains API for basic CRUD operations and API for pagination and sorting.
 * The JpaRepository takes two parameters: Tsystemofrecord and Long. Tsystemofrecord is the entity and Long is the type of the entity's primary key.
 *
 * It also extends SystemOfRecordRepositoryCustom. This is a custom repository interface that can be used to define custom methods.
 *
 * This interface is meant to be implemented by a class that provides the actual implementation of the JpaRepository and SystemOfRecordRepositoryCustom methods.
 */
@Repository 
public interface SystemOfRecordRepository extends JpaRepository<Tsystemofrecord, Long> , SystemOfRecordRepositoryCustom {
	
	
	/**
	 * This method is used to get the System of Record (SoR) ID based on the SoR name.
	 *
	 * It takes one parameter: sorName. sorName is a String representing the name of the System of Record.
	 *
	 * The method performs a select operation on the Tsystemofrecord table where the sorName matches the provided parameter.
	 * The result of the operation is the SoR ID associated with the provided SoR name.
	 *
	 * The @Param annotation is used to bind the method parameter to the query parameter.
	 *
	 * @param sorName a String representing the name of the System of Record.
	 * @return a Long representing the SoR ID associated with the provided SoR name.
	 * @throws SQLException if a database access error occurs or this method is called on a closed connection.
	 */
	@Query(value =  "select sor.sorId from Tsystemofrecord sor where sor.sorName=:sorName")
	public Long getSorId(@Param(value = "sorName") String sorName) throws SQLException;
}
