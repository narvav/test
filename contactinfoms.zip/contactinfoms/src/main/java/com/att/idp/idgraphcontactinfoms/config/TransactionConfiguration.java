package com.att.idp.idgraphcontactinfoms.config;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * The TransactionConfiguration class is a configuration class in the Spring framework.
 * It is annotated with @Configuration to indicate that it is a source of bean definitions.
 * It is also annotated with @EnableTransactionManagement to enable Spring's annotation-driven transaction management capability.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.config package.
 *
 * It contains an EntityManagerFactory property that is autowired, meaning Spring will automatically inject an instance of EntityManagerFactory into this class.
 * EntityManagerFactory is a factory for EntityManager instances in Java Persistence API (JPA). It is used to create and manage multiple EntityManager instances.
 *
 * It defines beans for JpaTransactionManager, PersistenceExceptionTranslationPostProcessor, and EntityManager.
 * JpaTransactionManager is a specific implementation of the Spring transaction manager interface for JPA.
 * PersistenceExceptionTranslationPostProcessor is a bean post-processor that automatically applies persistence exception translation to any bean marked with Spring's @Repository annotation.
 * EntityManager is an interface to the persistence service in Java Persistence API (JPA). It is used to create and remove persistent entity instances, to find entities by their primary key, and to query over entities.
 */
@Configuration
@EnableTransactionManagement(proxyTargetClass=true)
public class TransactionConfiguration {
	
	@Autowired
	private EntityManagerFactory entityManagerFactory;

	/**
	 * This method is responsible for setting up the JpaTransactionManager bean.
	 * JpaTransactionManager is a specific implementation of the Spring transaction manager interface for JPA.
	 *
	 * It creates a new JpaTransactionManager and sets its EntityManagerFactory with the EntityManagerFactory bean passed as a parameter.
	 * EntityManagerFactory is a factory for EntityManager instances in Java Persistence API (JPA). It is used to create and manage multiple EntityManager instances.
	 *
	 * @param entityManagerFactory the EntityManagerFactory bean used to set the EntityManagerFactory of the JpaTransactionManager.
	 * @return JpaTransactionManager bean configured with the EntityManagerFactory defined in the method.
	 */
	@Bean
	@Primary
	public JpaTransactionManager transactionManager(EntityManagerFactory entityManagerFactory) {

		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManagerFactory);
		return transactionManager;
	}
	
	/**
	 * This method is responsible for setting up the PersistenceExceptionTranslationPostProcessor bean.
	 * PersistenceExceptionTranslationPostProcessor is a bean post-processor that automatically applies persistence exception translation to any bean marked with Spring's @Repository annotation.
	 *
	 * It creates a new instance of PersistenceExceptionTranslationPostProcessor.
	 *
	 * @return PersistenceExceptionTranslationPostProcessor bean.
	 */
	@Bean
	public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
		
		return new PersistenceExceptionTranslationPostProcessor();
	}
	
	
	/**
	 * This method is responsible for setting up the EntityManager bean.
	 * EntityManager is an interface to the persistence service in Java Persistence API (JPA). It is used to create and remove persistent entity instances, to find entities by their primary key, and to query over entities.
	 *
	 * It creates a new EntityManager instance by calling the createEntityManager method on the EntityManagerFactory bean.
	 * EntityManagerFactory is a factory for EntityManager instances in Java Persistence API (JPA). It is used to create and manage multiple EntityManager instances.
	 *
	 * @return EntityManager bean.
	 */
	@Bean
	@Qualifier("entityManager")
	public EntityManager entityManager() {
		
		return entityManagerFactory.createEntityManager();
	}
}