package com.att.idp.idgraphcontactinfoms.exceptions;

import java.io.Serializable;

import com.att.idp.idgraphcontactinfoms.model.ErrorMessage;

/**
 * This is the MPSException class.
 *
 * It extends the Exception class and implements the Serializable interface. This means that an instance of MPSException can be converted to a byte stream and restored later.
 *
 * The purpose of this class is to represent exceptions that are specific to the MPS (Message Processing System). It includes a field for an ErrorMessage object, which can provide more detailed information about the exception.
 */
public class MPSException extends Exception implements Serializable{

	private static final long serialVersionUID = 7728046821967210029L;

	/**
	 * This is a field of the MPSException class.
	 *
	 * It is an ErrorMessage object that represents the error message associated with the MPSException.
	 *
	 * When an instance of MPSException is created using the constructor that takes an ErrorMessage as a parameter, this field is set to the provided ErrorMessage.
	 */
	public ErrorMessage errorMessage;
	
	/**
	 * This is a no-argument constructor for the MPSException class.
	 *
	 * When an instance of MPSException is created using this constructor, the detail message and the ErrorMessage object are not initialized.
	 */
	public MPSException(){
		super();
	}
	
	/**
	 * This is a constructor for the MPSException class.
	 *
	 * It takes one parameter: message. message is a String that represents the detail message of the exception.
	 *
	 * When an instance of MPSException is created using this constructor, the detail message is set to the provided String, and the ErrorMessage object is not initialized.
	 *
	 * @param message a String that represents the detail message of the exception.
	 */
	public MPSException(String message){
		super(message);
	}
	
	
	/**
	 * This is a constructor for the MPSException class.
	 *
	 * It takes one parameter: errorMessage. errorMessage is an ErrorMessage object that represents the error message associated with the MPSException.
	 *
	 * When an instance of MPSException is created using this constructor, the detail message is set to the application information from the provided ErrorMessage, and the ErrorMessage object is set to the provided ErrorMessage.
	 *
	 * @param errorMessage an ErrorMessage object that represents the error message associated with the MPSException.
	 */
	public MPSException(ErrorMessage errorMessage){
		super(errorMessage.getAppInfo());
		this.errorMessage = errorMessage;
	}
	
	

}
