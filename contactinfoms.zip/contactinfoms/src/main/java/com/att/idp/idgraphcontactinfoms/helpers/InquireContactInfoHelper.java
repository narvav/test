package com.att.idp.idgraphcontactinfoms.helpers;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphcontactinfoms.integration.InquireProfileRestClient;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This class is a helper class for inquiring contact information.
 *
 * It contains methods for inquiring contact information based on the input parameters.
 * The class uses the Spring Framework's @Component annotation to indicate that it is a bean and can be used for dependency injection.
 * It also uses the @PropertySource annotation to specify the location of the properties file.
 *
 * The class has several instance variables that are injected using the @Autowired and @Value annotations.
 * These variables include an InquireProfileRestClient, an InquireAccountContactInfoHelper, an InquireUserContactCBRHelper, a ProcessTitanCBRHelper, a CommonUtilHelper, and a String for the valid callers.
 *
 * The main method in this class is the inquireContactInfo method, which takes a HashMap as input and returns a HashMap as output.
 * The inquireContactInfo method uses several other methods in the class to validate the input data, process the input data, and store the data.
 *
 * The class also contains a logger for logging information and error messages.
 */
@Component
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class InquireContactInfoHelper {

	@Autowired
	private InquireProfileRestClient inquireProfileRestClient;

	@Autowired
	private InquireAccountContactInfoHelper objInquireAccountContactInfoHelper;

	@Autowired
	private InquireUserContactCBRHelper inquireUserContactCBRHelper;

	@Autowired
	private ProcessTitanCBRHelper objProcessTITANCBRHelper;

	@Autowired
	private CommonUtilHelper oCommonUtilHelper;

	@Value("${PROP_INQUIRE_CONTACT_INFO_CSI}")
	private String slValidCallers;

	private static final Logger logger = LoggerFactory.getLogger(InquireContactInfoHelper.class);
	private static final String SCLASSNAME = "InquireContactInfoHelper";

	/**
	 * This method inquires contact information based on the input parameters.
	 *
	 * It first retrieves the transaction name, transaction ID, calling system ID, and external call flag from the input HashMap.
	 * Then, it validates the input data. If the input data is invalid, the method constructs an error response and returns it.
	 * If the input data is valid, the method processes the input data and makes a call to the inquireProfileRestClient to inquire profile information.
	 * The method then checks the response from the inquireProfileRestClient. If the response indicates an error, the method constructs an error response and returns it.
	 * If the response from the inquireProfileRestClient indicates success, the method constructs a success response and returns it.
	 * The success response includes the access ID, user CBR list, and account CBR list.
	 *
	 * @param hmInput a HashMap that contains the input data for the contact information inquiry. The HashMap should include the transaction name, transaction ID, calling system ID, and other necessary information.
	 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code, an application info message, the access ID, user CBR list, and account CBR list.
	 * @throws Exception if an error occurs during the operation.
	 */
	public HashMap inquireContactInfo(HashMap hmInput) {
		HashMap<String, Object> hmResult = inquireContactInfo(hmInput, null);
		return hmResult;
	}

	/**
	 * This method inquires contact information based on the input parameters and the database profile.
	 *
	 * It first retrieves the transaction name, transaction ID, calling system ID, and external call flag from the input HashMap.
	 * Then, it validates the input data. If the input data is invalid, the method constructs an error response and returns it.
	 * If the input data is valid, the method processes the input data and makes a call to the inquireProfileRestClient to inquire profile information.
	 * The method then checks the response from the inquireProfileRestClient. If the response indicates an error, the method constructs an error response and returns it.
	 * If the response from the inquireProfileRestClient indicates success, the method constructs a success response and returns it.
	 * The success response includes the access ID, user CBR list, and account CBR list.
	 *
	 * @param hmInput a HashMap that contains the input data for the contact information inquiry. The HashMap should include the transaction name, transaction ID, calling system ID, and other necessary information.
	 * @param hmDBProfile a HashMap that contains the database profile information.
	 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code, an application info message, the access ID, user CBR list, and account CBR list.
	 * @throws Exception if an error occurs during the operation.
	 */
	public HashMap inquireContactInfo(HashMap hmInput, HashMap hmDBProfile) {
		String sMethodName = ".inquireContactInfo.";
		//String escapedValueHmInput = (hmInput!=null)?HtmlUtils.htmlEscape(String.valueOf(hmInput)):null;
		logger.info("{}{}HLP000 : Input Hash : {}", SCLASSNAME, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmInput)));
		HashMap<String, Object> hmResult = null;
		HashMap<String, Object> hmResponse = null;
		String stAppInfo = null;
		String stAppStatusCode = null;

		if (hmInput == null || hmInput.isEmpty()) {
			stAppInfo = "Input Hash is NULL";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
			logger.info("{}{}ICIH_100 : {}", SCLASSNAME, sMethodName, stAppInfo);
			return hmResult;
		}

		String sHandle = null;
		String sDomain = null;
		String sGuid = null;
		HashMap<String, Object> hmInqProfileResp = null;

		try {
			String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
			String sTransactionId = (String) hmInput.get("idpTraceId");
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sIsExternalCall = (String) hmInput.get(CommonDefs.IS_EXTERNAL_CALL);

			ArrayList alValidCallers = null;

			if (slValidCallers != null && !slValidCallers.isEmpty()) {
				alValidCallers = CommonUtil.parseToArray(slValidCallers, CommonDefs.VALUE_SEPARATOR_CHAR);
			} else {
				stAppInfo = "Property value is null or empty";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
				logger.error("{}{}ICIH_101 : {}", SCLASSNAME, sMethodName, stAppInfo);
				return hmResult;
			}

			logger.info("{}{}ICIH_102 : Property PROP_INQUIRE_CONTACT_INFO_CSI : {}", SCLASSNAME, sMethodName,
					alValidCallers);

			if ((CommonDefs.IND_Y.equalsIgnoreCase(sIsExternalCall)) && (!alValidCallers.contains(sCallingSystemId))) {
				stAppInfo = "Invalid CallingSystemId in Input";
				logger.info("{}{}ICIH_103 : {}", SCLASSNAME, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			if (hmDBProfile == null || hmDBProfile.isEmpty()) {
				sHandle = (String) hmInput.get(CommonDefs.HANDLE);
				sDomain = (String) hmInput.get(CommonDefs.DOMAIN);
				sGuid = (String) hmInput.get(CommonDefs.GUID);

				if (sHandle != null && !sHandle.isEmpty() && sDomain != null && !sDomain.isEmpty()) {
					sHandle = sHandle.trim().toLowerCase();
					sDomain = sDomain.trim().toLowerCase();
					sGuid = null;
					hmInput.put(CommonDefs.GUID, sGuid);
				} else if (sGuid != null && !sGuid.isEmpty()) {
					sHandle = null;
					hmInput.put(CommonDefs.HANDLE, sHandle);
					sDomain = null;
					hmInput.put(CommonDefs.DOMAIN, sDomain);
					sGuid = sGuid.trim();
				} else {
					stAppInfo = "Either guid OR handle/domain must be present";
					logger.info("{}{}ICIH_104 : {}", SCLASSNAME, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
					return hmResult;
				}

				HashMap<String, String> hmInqProfileInp = CommonUtil.getHashMap();

				hmInqProfileInp.put(CommonDefs.TRANSACTION_NAME, CommonDefs.INQUIRE_PROFILE);
				hmInqProfileInp.put(CommonDefs.CALLING_SYSTEM_ID, CommonDefs.MPSYS);
				hmInqProfileInp.put(CommonDefs.LEVEL, "LM");
				//hmInqProfileInp.put("sourceCallingSystemId", sCallingSystemId);
				hmInqProfileInp.put(CommonDefs.IS_EXTERNAL_CALL, CommonDefs.IND_N);

				if (sGuid == null || sGuid.isEmpty()) {
					hmInqProfileInp.put(CommonDefs.HANDLE, sHandle);
					hmInqProfileInp.put(CommonDefs.DOMAIN, sDomain);
				} else {
					hmInqProfileInp.put(CommonDefs.GUID, sGuid);
				}

				hmInqProfileInp.put(CommonDefs.TRANSID, sTransactionId);

				logger.debug(
						"{}{}ICIH_105 : Calling InquireProfileRestClient.postInquireProfileSyncCall() with hmInqProfileInp : {}",
						SCLASSNAME, sMethodName, hmInqProfileInp);

				hmInqProfileResp = (HashMap) inquireProfileRestClient.postInquireProfileSyncCall(hmInqProfileInp,
						sTransactionId,sCallingSystemId);

				logger.debug("{}{}ICIH_106 : Response from InquireProfileRestClient.postInquireProfileSyncCall() : {}",
						SCLASSNAME, sMethodName, hmInqProfileResp);

				if (hmInqProfileResp == null || hmInqProfileResp.isEmpty()) {
					stAppInfo = "Null Response returned from ajscServiceHelper.processRequest()";
					hmInqProfileResp = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					logger.info("{}{}ICIH_107 : {}", SCLASSNAME, sMethodName, stAppInfo);
					return hmInqProfileResp;
				}

				stAppStatusCode = (String) hmInqProfileResp.get(MPSDefs.APP_STATUS_CODE);
				if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					stAppInfo = "Error occured from inquireProfile operation call";
					logger.info("{}{}ICIH_108 : {}", SCLASSNAME, sMethodName, stAppInfo);
					return hmInqProfileResp;
				}
			} else {
				hmInqProfileResp = CommonUtil.getHashMap();
				hmInqProfileResp.putAll(hmDBProfile);

				sGuid = null;
				hmInput.put(CommonDefs.GUID, sGuid);
				sHandle = null;
				hmInput.put(CommonDefs.HANDLE, sHandle);
				sDomain = null;
				hmInput.put(CommonDefs.DOMAIN, sDomain);
			}

			HashMap<String, Object> hmDBMemberInfo = (HashMap<String, Object>) hmInqProfileResp.get("member");
			ArrayList alMemSvcRole = (ArrayList) hmInqProfileResp.get("memberServiceRole");
			ArrayList alLinkedUsers = (ArrayList) hmInqProfileResp.get("linkedMember");

			if (sGuid == null && hmDBMemberInfo != null && !hmDBMemberInfo.isEmpty()) {
				sGuid = (String) hmDBMemberInfo.get(CommonDefs.MEMBER_NUM);
				hmInput.put(CommonDefs.GUID, sGuid);
			}

			ArrayList alUserCBRs = null;

			if (alLinkedUsers != null && !alLinkedUsers.isEmpty()) {
				HashMap<String, Object> hmInqUserContactRespInput = CommonUtil.getHashMap();
				hmInqUserContactRespInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
				hmInqUserContactRespInput.put(CommonDefs.IS_EXTERNAL_CALL, sIsExternalCall);
				// hmInqUserContactRespInput.put(CommonDefs.GUID, sGuid);
				hmInqUserContactRespInput.put("linkedMemberList", alLinkedUsers);

				logger.debug(
						"{}{}ICIH_109 : Calling InquireUserContactCBRHelper.inquireUserContactCBR() with alLinkedUsers : {}",
						SCLASSNAME, sMethodName, hmInqUserContactRespInput);

				HashMap<String, Object> hmInqUserContactResp = inquireUserContactCBRHelper
						.inquireUserContactCBR(hmInqUserContactRespInput);

				logger.debug("{}{}ICIH_110 : Response from InquireUserContactCBRHelper.inquireUserContactCBR() : {}",
						SCLASSNAME, sMethodName, hmInqUserContactResp);

				if (hmInqUserContactResp == null || hmInqUserContactResp.isEmpty()) {
					stAppInfo = "Null Response returned from InquireUserContactCBRHelper.inquireUserContactCBR()";
					hmInqUserContactResp = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					logger.info("{}{}ICIH_111 : {}", SCLASSNAME, sMethodName, stAppInfo);
					return hmInqUserContactResp;
				}

				stAppStatusCode = (String) hmInqUserContactResp.get(MPSDefs.APP_STATUS_CODE);
				if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					stAppInfo = "Error occured from InquireUserContactCBRHelper.inquireUserContactCBR call";
					logger.info("{}{}ICIH_112 : {}", SCLASSNAME, sMethodName, stAppInfo);
					return hmInqUserContactResp;
				}

				alUserCBRs = (ArrayList) hmInqUserContactResp.get("userCBRList");
			}

			ArrayList alECOMMAccts = new ArrayList();
			ArrayList alLSAccts = new ArrayList();
			String sDBLSSorInvId = null;
			String sDBLSAcctCreateDate = null;
			String sDBLSAcctRoleName = null;

			if (alMemSvcRole != null && !alMemSvcRole.isEmpty()) {
				for (int k = 0; k < alMemSvcRole.size(); k++) {
					HashMap hmDBService = (HashMap) alMemSvcRole.get(k);
					String sDBSorName = (String) hmDBService.get(CommonDefs.KEY_SOR_NAME);
					String sDBAcctRole = (String) hmDBService.get(CommonDefs.ROLE_NAME);
					String sDBAcctCreateDate = (String) hmDBService.get(CommonDefs.CREATE_DATE);

					// 2005 : MPSYS-US26 : This OWNER check is made to make sure we don�t return
					// CBRs for AUTHORIZEDUSER accounts.
					if (sDBAcctRole != null && sDBAcctRole.equalsIgnoreCase(CommonDefs.KEY_ROLE_NAME_OWNER)) {

						logger.info("{}{}ICIH_113.0 : Owner Account {} ", SCLASSNAME, sMethodName,
								HtmlUtils.htmlEscape(String.valueOf(sDBAcctRole)));

						if (sDBSorName != null && (sDBSorName.equalsIgnoreCase(CommonDefs.SOR_COLA)
								|| (sDBSorName.equalsIgnoreCase(CommonDefs.SOR_CPR)))) {
							String sSorInvariantId = (String) hmDBService.get(CommonDefs.SOR_INVARIANT_ID);
							alECOMMAccts.add(sSorInvariantId);
						} else if (sDBSorName != null && sDBSorName.equalsIgnoreCase(CommonDefs.SOR_LS)) {
							if (sDBLSSorInvId == null || sDBLSSorInvId.isEmpty()) {
								sDBLSSorInvId = (String) hmDBService.get(CommonDefs.SOR_INVARIANT_ID);
								sDBLSAcctCreateDate = (String) hmDBService.get(CommonDefs.CREATE_DATE);
								sDBLSAcctRoleName = (String) hmDBService.get(CommonDefs.ROLE_NAME);
							} else if (sDBAcctRole != null
									&& sDBAcctRole.equalsIgnoreCase(CommonDefs.KEY_ROLE_NAME_OWNER)) {
								if (sDBLSAcctRoleName != null
										&& !sDBLSAcctRoleName.equalsIgnoreCase(CommonDefs.KEY_ROLE_NAME_OWNER)) {
									sDBLSSorInvId = (String) hmDBService.get(CommonDefs.SOR_INVARIANT_ID);
									sDBLSAcctCreateDate = (String) hmDBService.get(CommonDefs.CREATE_DATE);
									sDBLSAcctRoleName = (String) hmDBService.get(CommonDefs.ROLE_NAME);
								} else if (compareIfDateOld(sDBAcctCreateDate, sDBLSAcctCreateDate)) {
									sDBLSSorInvId = (String) hmDBService.get(CommonDefs.SOR_INVARIANT_ID);
									sDBLSAcctCreateDate = (String) hmDBService.get(CommonDefs.CREATE_DATE);
									sDBLSAcctRoleName = (String) hmDBService.get(CommonDefs.ROLE_NAME);
								}
							} else {
								if (sDBLSAcctRoleName != null
										&& !sDBLSAcctRoleName.equalsIgnoreCase(CommonDefs.KEY_ROLE_NAME_OWNER)) {
									if (compareIfDateOld(sDBAcctCreateDate, sDBLSAcctCreateDate)) {
										sDBLSSorInvId = (String) hmDBService.get(CommonDefs.SOR_INVARIANT_ID);
										sDBLSAcctCreateDate = (String) hmDBService.get(CommonDefs.CREATE_DATE);
										sDBLSAcctRoleName = (String) hmDBService.get(CommonDefs.ROLE_NAME);
									}
								}
							}

						} else {
							logger.info("{}{}ICIH_113 : Account {} is not supported", SCLASSNAME, sMethodName,
									HtmlUtils.htmlEscape(String.valueOf(sDBSorName)));
						}
					}
				}
			}

			if (sDBLSSorInvId != null && !sDBLSSorInvId.isEmpty()) {
				alLSAccts.add(sDBLSSorInvId);
			}

			ArrayList alAcctContacts = new ArrayList();

			if (alECOMMAccts != null && !alECOMMAccts.isEmpty()) {
				HashMap<String, Object> hmInquireAcctContactInp = CommonUtil.getHashMap();
				hmInquireAcctContactInp.put(CommonDefs.TRANSACTION_ID, sTransactionId);
				hmInquireAcctContactInp.put(CommonDefs.TRANSACTION_NAME, "InquireAccountContactInfo");
				hmInquireAcctContactInp.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
				hmInquireAcctContactInp.put("accountInvariantIdList", alECOMMAccts);
				hmInquireAcctContactInp.put(CommonDefs.ACCOUNT_TYPE, CommonDefs.ECOMM_SERVICE);

				logger.debug(
						"{}{}ICIH_114 : Calling InquireAccountContactInfoHelper.inquireAccountContactInfo() with input : {}",
						SCLASSNAME, sMethodName, hmInquireAcctContactInp);

				HashMap<String, Object> hmInqAcctResp = (HashMap<String, Object>) objInquireAccountContactInfoHelper.inquireAccountContactInfo(hmInquireAcctContactInp);

				logger.info(
						"{}{}ICIH_115 : Response from InquireAccountContactInfoHelper.inquireAccountContactInfo() : {}",
						SCLASSNAME, sMethodName, hmInqAcctResp);

				if (hmInqAcctResp == null || hmInqAcctResp.isEmpty()) {
					stAppInfo = "Null Response returned from InquireAccountContactInfoHelper.inquireAccountContactInfo()";
					hmInqAcctResp = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					logger.info("{}{}ICIH_116 : {}", SCLASSNAME, sMethodName, stAppInfo);
					return hmInqAcctResp;
				}

				stAppStatusCode = (String) hmInqAcctResp.get(CommonDefs.COMMON_APP_STATUS_CODE);

				if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					stAppInfo = (String) hmInqAcctResp.get(CommonDefs.COMMON_APP_INFO);
					logger.info("{}{}ICIH_117 : Error returned : {}", SCLASSNAME, sMethodName, stAppInfo);
				}

				if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
					HashMap<String, Object> hmAccountContacts = (HashMap<String, Object>) hmInqAcctResp
							.get("accountContacts");
					ArrayList alDBPhoneList = (ArrayList) hmAccountContacts.get("phoneList");

					if (alDBPhoneList != null && !alDBPhoneList.isEmpty()) {
						alAcctContacts.addAll(alDBPhoneList);
					}
				}
			}

			if (alLSAccts != null && !alLSAccts.isEmpty()) {
				HashMap<String, Object> hmTITANCBRInp = CommonUtil.getHashMap();
				hmTITANCBRInp.put(CommonDefs.TRANSACTION_ID, sTransactionId);
				hmTITANCBRInp.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
				hmTITANCBRInp.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
				hmTITANCBRInp.put("accountInvariantIdList", alLSAccts);

				logger.debug("{}{}ICIH_118 : Calling ProcessTITANCBRHelper.processTitanCBRInfo() with input : {}",
						SCLASSNAME, sMethodName, hmTITANCBRInp);

				HashMap hmTITANCBRResp = objProcessTITANCBRHelper.processTitanCBRInfo(hmTITANCBRInp);

				logger.info("{}{}ICIH_119 : Response from ProcessTITANCBRHelper.processTitanCBRInfo() : {}", SCLASSNAME,
						sMethodName, hmTITANCBRResp);

				if (hmTITANCBRResp == null || hmTITANCBRResp.isEmpty()) {
					stAppInfo = "Null Response returned from ProcessTITANCBRHelper.processTitanCBRInfo()";
					hmTITANCBRResp = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					logger.info("{}{}ICIH_120 : {}", SCLASSNAME, sMethodName, stAppInfo);
					return hmTITANCBRResp;
				}

				stAppStatusCode = (String) hmTITANCBRResp.get(CommonDefs.COMMON_APP_STATUS_CODE);

				if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					stAppInfo = (String) hmTITANCBRResp.get(CommonDefs.COMMON_APP_INFO);
					logger.info("{}{}ICIH_121 : Error returned : {}", SCLASSNAME, sMethodName, stAppInfo);
				}

				if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
					HashMap<String, Object> hmAccountContacts = (HashMap) hmTITANCBRResp.get("accountContacts");
					ArrayList alDBPhoneList = (ArrayList) hmAccountContacts.get("phoneList");

					if (alDBPhoneList != null && !alDBPhoneList.isEmpty()) {
						alAcctContacts.addAll(alDBPhoneList);
					}
				}
			}

			hmResponse = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

			if (hmDBMemberInfo != null && !hmDBMemberInfo.isEmpty()) {
				String sAccessID = (String) hmDBMemberInfo.get(CommonDefs.MEMBER_NAME);
				hmResponse.put("accessID", sAccessID);
			}

			if (alUserCBRs != null && !alUserCBRs.isEmpty()) {
				hmResponse.put("userCBRList", alUserCBRs);
			}

			if (alAcctContacts != null && !alAcctContacts.isEmpty()) {
				ArrayList alAcctCBRs = processAccountCBR(alAcctContacts);
				if (alAcctCBRs != null && !alAcctCBRs.isEmpty()) {
					hmResponse.put("accountCBRList", alAcctCBRs);
				}
			}

		} catch (Exception e) {
			hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown in inquireContactInfo method";
			logger.error("{}{}ICIH_150e : {} : {}", SCLASSNAME, sMethodName, stAppInfo, hmResponse);
			return hmResponse;
		} finally {
			logger.info("{}{}HLP999 : response from inquireContactInfo :: {}", SCLASSNAME, sMethodName, hmResponse);
		}
		return hmResponse;
	}

	/**
	 * 
	 * @param alAccountContacts
	 * @return ArrayList
	 */
	private ArrayList processAccountCBR(ArrayList alAccountContacts) {
		ArrayList alAcctCBRs = new ArrayList();

		for (int k = 0; k < alAccountContacts.size(); k++) {
			HashMap<String, Object> hmAcctContact = (HashMap<String, Object>) alAccountContacts.get(k);
			String sContactType = (String) hmAcctContact.get(CommonDefs.CONTACT_TYPE);

			if (sContactType != null && (sContactType.equalsIgnoreCase(CommonDefs.CONTACT_TYPE_PRIMARY_PHONE)
					|| (sContactType.equalsIgnoreCase(CommonDefs.CONTACT_TYPE_SECONDARY_PHONE)))) {
				String sIsAged = "N";
				String sIsValidated = "N";

				String sDateEst = (String) hmAcctContact.get("dateEstablished");
				String dateTimeFormat = "MMddyyyy HH:mm:ss";
				boolean bIsAged = oCommonUtilHelper.checkAging(sDateEst, "31", dateTimeFormat);

				if (sDateEst != null && !sDateEst.isEmpty() && bIsAged) {
					sIsAged = "Y";
				}

				String sContactStatus = (String) hmAcctContact.get(CommonDefs.CONTACT_STATUS);
				String sValidationStatus = (String) hmAcctContact.get(CommonDefs.VALIDATION_STATUS);
				String sSorName = (String) hmAcctContact.get(CommonDefs.KEY_SOR_NAME);

				if ("V".equalsIgnoreCase(sContactStatus) && "8".equals(sValidationStatus)) {
					sIsValidated = "Y";
				}

				HashMap<String, Object> hmAcctCBR = CommonUtil.getHashMap();

				if (sSorName != null && (sSorName.equalsIgnoreCase(CommonDefs.SOR_COLA)
						|| (sSorName.equalsIgnoreCase(CommonDefs.SOR_CPR)))) {
					hmAcctCBR.put(CommonDefs.ACCOUNT_TYPE, CommonDefs.ECOMM_SERVICE);
				} else if (sSorName != null && sSorName.equalsIgnoreCase(CommonDefs.SOR_LS)) {
					hmAcctCBR.put(CommonDefs.ACCOUNT_TYPE, CommonDefs.TITAN_SERVICE);
				}

				hmAcctCBR.put(CommonDefs.ACCOUNT_INVARIANT_ID, (String) hmAcctContact.get(CommonDefs.SOR_INVARIANT_ID));

				HashMap<String, Object> hmUSPhoneNum = CommonUtil.getHashMap();
				hmUSPhoneNum.put(CommonDefs.CONTACT_STATUS, sContactStatus);
				hmUSPhoneNum.put(CommonDefs.CONTACT_TYPE, sContactType);
				hmUSPhoneNum.put("aged", sIsAged);
				hmUSPhoneNum.put("validated", sIsValidated);
				hmUSPhoneNum.put(CommonDefs.ESTABLISHED_DATE, sDateEst);
				hmUSPhoneNum.put(CommonDefs.PHONE_NUMBER, (String) hmAcctContact.get(CommonDefs.PHONE_NUMBER));
				hmUSPhoneNum.put(CommonDefs.PHONE_NUMBER_TYPE,
						(String) hmAcctContact.get(CommonDefs.PHONE_NUMBER_TYPE));

				hmAcctCBR.put(CommonDefs.US_PHONE_NUMBER, hmUSPhoneNum);
				alAcctCBRs.add(hmAcctCBR);
			}
		}

		return alAcctCBRs;
	}

	/**
	 * 
	 * @param sDBAcctCreateDate
	 * @param sDBLSAcctCreateDate
	 * @return boolean
	 */
	private boolean compareIfDateOld(String sDBAcctCreateDate, String sDBLSAcctCreateDate) {
		String sMethodName = ".compareDates.";
		String stAppInfo = null;
		DateFormat df = new SimpleDateFormat("MMddyyyy HH:mm:ss");

		Date dParsedDBAcctCreateDate = null;
		Date dParsedDBLSAcctCreateDate = null;

		try {
			dParsedDBAcctCreateDate = df.parse(sDBAcctCreateDate);
			dParsedDBLSAcctCreateDate = df.parse(sDBLSAcctCreateDate);

			if (dParsedDBLSAcctCreateDate.after(dParsedDBAcctCreateDate)) {
				return true;
			}
		} catch (Exception e) {
			HashMap<String, Object> hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown in compareDates method";
			logger.error("{}{}ICIH_1501e : {} : {}", SCLASSNAME, sMethodName, stAppInfo, hmResult);
		}
		return false;
	}
}
