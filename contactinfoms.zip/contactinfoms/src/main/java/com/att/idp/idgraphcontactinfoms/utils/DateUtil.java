package com.att.idp.idgraphcontactinfoms.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The DateUtil class is part of the com.att.idp.idgraphcontactinfoms.utils package.
 *
 * This class provides utility methods for handling dates. It includes methods for converting strings to SQL dates.
 * The class uses the SimpleDateFormat class from the java.text package to define a date format that is used for parsing date strings.
 *
 * The class also uses the Logger class from the org.slf4j package to log errors that may occur during the parsing of date strings.
 *
 * Note: The class is designed to be used as a utility class, and as such, it does not have any instance variables or non-static methods.
 */
public class DateUtil {

	private static Logger logger = LoggerFactory.getLogger(DateUtil.class);
	
	private static final DateFormat GLOBAL_DATE_PATTERN_MMDDYYYY = new SimpleDateFormat("MM/dd/yyyy");
	
	/**
	 * This method is part of the DateUtil class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The stringToSqlDate method is used to convert a string representing a date into a java.sql.Date object.
	 * It uses the SimpleDateFormat class from the java.text package to parse the date string.
	 * The date string is expected to be in the "MM/dd/yyyy" format.
	 *
	 * If the parsing is successful, the method returns a java.sql.Date object representing the parsed date.
	 * If the parsing fails (for example, if the date string is not in the expected format), the method logs an error message and returns null.
	 *
	 * This method is useful when you need to convert a date string into a java.sql.Date object, for example, when you need to insert a date into a SQL database.
	 *
	 * @param dateString The string representing the date to be converted. It is expected to be in the "MM/dd/yyyy" format.
	 * @return A java.sql.Date object representing the parsed date, or null if the parsing fails.
	 */
	public static java.sql.Date stringToSqlDate(String dateString) {

		java.util.Date parsed = null;
		java.sql.Date sqlDate = null;

		try {
			parsed = GLOBAL_DATE_PATTERN_MMDDYYYY.parse(dateString);
			sqlDate = new java.sql.Date(parsed.getTime());
		} catch (ParseException ex) {
			logger.error("Error while parsing date string :" + ex.getMessage());
		}
		return sqlDate;
	}

	public static Double  getsecurityCodeExpiryTime(double  securityCodeExpiryData, String timeUnit) {

		if (ProfileOrchestrationConstants.HOURS.equalsIgnoreCase(timeUnit))
			return securityCodeExpiryData / 24;
		else
			return securityCodeExpiryData / 1440;
	}
}
