package com.att.idp.idgraphcontactinfoms.cgclient.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

/**
 * The Subscribers class represents a subscriber in the system.
 * It implements the Serializable interface, which means its instances can be converted to a byte stream and
 * restored back to the same object later. This is useful for storing objects in a file or sending them over a network.
 *
 * This class contains properties related to a subscriber such as subscriberId, effectiveDate, status, profile, addressesList, subscriptionId, subscriberStatusReasonCode, statusReasonActivity, statusReasonCodeDescription, subStatusDate, blueNetworkIndicator, techType, migrated, primarySubscriber, firstnetIndicator, lastSwActvDateValue, and smsCapability.
 * Each property has its corresponding getter and setter methods.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.cgclient.response package.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(name = "Subscribers")
@Getter
@Setter
@NoArgsConstructor
public class Subscribers implements Serializable {

	private static final long serialVersionUID = 1647488365389225977L;

	private String subscriberId;
	private String effectiveDate;
	private String status;
	private Profile profile;
	private List<Addresses> addressesList;
	private String subscriptionId;
	private String subscriberStatusReasonCode;
	private String statusReasonActivity;
	private String statusReasonCodeDescription;
	private String subStatusDate;
	private String blueNetworkIndicator;
	private String techType;
	private String migrated;
	private String primarySubscriber;
	private String firstnetIndicator;
	private String lastSwActvDateValue;
	private String smsCapability;
}