package com.att.idp.idgraphcontactinfoms.request.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import jakarta.ws.rs.core.HttpHeaders;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.att.idp.idgraphcontactinfoms.resource.request.InquirePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.InquirePINResponse;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;

@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class InquirePINRequestValidator {

	private static final Logger logger = LoggerFactory.getLogger(InquirePINRequestValidator.class);

	private String sClassName = "InquirePINRequestValidator";

	@Value("${PROP_PIN_CSI}")
	private String propValidPINIDENTypeAndCSI;

	public InquirePINResponse inquirePINRequestValidator(HttpHeaders requestHeader, InquirePINRequest inquirePINRequest) {

		InquirePINResponse inquirePINResponse = null;

		String stAppInfo = null;
		String sMethodName = ".inquirePINRequestValidator.";
		String stIdpTraceId = null;
		String stXAttClientId = null;

		stIdpTraceId = CommonUtil.getTraceId(requestHeader);
		if (inquirePINRequest != null) {
			
			if(stIdpTraceId == null || stIdpTraceId.startsWith("AutoGen_")) {
				stAppInfo="InquirePIN Request idp-trace-id is missing";
				return inquirePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
			}
			inquirePINRequest.setIdpTraceId(stIdpTraceId);
			
			String stCallingSystemId = inquirePINRequest.getCallingSystemId();
			Optional.ofNullable(stCallingSystemId)
			.ifPresent(x -> inquirePINRequest.setCallingSystemId(x.trim().toUpperCase()));
			
			if (stCallingSystemId == null && requestHeader.getHeaderString("X-ATT-ClientId") != null) {
				stXAttClientId = requestHeader.getHeaderString("X-ATT-ClientId").toUpperCase();
				logger.info("{}{}IPRV_101.2 : Setting callingSystemId: {}", sClassName, sMethodName,stXAttClientId);
				inquirePINRequest.setCallingSystemId(stXAttClientId.trim().toUpperCase());
			}
			
		}

		if (inquirePINRequest == null) {
			stAppInfo = "Input Request Parameter is NULL / Empty.";
			logger.info("{}{}IPRV_102 :: {}", sClassName, sMethodName, stAppInfo);
			return inquirePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		// checking Invalid attributes passed in Request
		Map<String, Object> allUnknownAttributes = new HashMap<>(inquirePINRequest.unknownAttributes);

		if (!allUnknownAttributes.isEmpty()) {
			stAppInfo = "Invalid Attributes passed in InquirePINRequest : " + allUnknownAttributes;
			return inquirePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo,
					inquirePINRequest.getIdpTraceId());
		}
		try {

			inquirePINResponse = inquirePINRequestValidatorInputValidator(inquirePINRequest);

			if (inquirePINResponse != null) {
				logger.info("{}{}IPRV_103 Response from InquirePINRequestValidator : {}", sClassName, sMethodName,
						inquirePINResponse);
				return inquirePINResponse;
			} else {
				logger.info("{}{}IPRV_104 Success Response from InquirePINRequestValidator ", sClassName, sMethodName);
			}

			inquirePINResponse = inquirePINRequestCSIValidator(inquirePINRequest);

			if (inquirePINResponse != null) {
				logger.info("{}{}IPRV_105 Response from inquirePINRequestCSIValidator : {}", sClassName, sMethodName,
						inquirePINResponse);
				return inquirePINResponse;
			} else {
				logger.info("{}{}IPRV_106 Success Response from inquirePINRequestCSIValidator ", sClassName,
						sMethodName);
			}
			stAppInfo = "Input Validation Successful";
			logger.info("{}{}IPRV_107 : {}", sClassName, sMethodName, stAppInfo);
		} catch (Exception e) {
			stAppInfo = "Exception thrown in InquirePINRequestValidator.InquirePINRequestValidator : " + e.getMessage();
			inquirePINErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo, stIdpTraceId);
			logger.info("{}{}IPRV_108 : Exception in InquirePINRequestValidator: {}", sClassName, sMethodName, stAppInfo);
		}
		return inquirePINResponse;
	}

	private InquirePINResponse inquirePINRequestCSIValidator(InquirePINRequest inquirePINRequest) {
		InquirePINResponse InquirePINResonse=null;
		String stAppInfo = null;
		String sMethodName = ".InquirePINRequestCSIValidator.";
		String stCallingSystemID = inquirePINRequest.getCallingSystemId();
		String stIdentificationType = inquirePINRequest.getIdentificationType();
		String stIdpTraceId = inquirePINRequest.getIdpTraceId();
		

		logger.info("{}{}IPRV_104.1 : Property PROP_PIN_CSI ::  {}", sClassName, sMethodName, propValidPINIDENTypeAndCSI);
		
		if (propValidPINIDENTypeAndCSI == null || propValidPINIDENTypeAndCSI.isEmpty()) {

			stAppInfo = "PROP_PIN_CSI  property is not configured in the properties file";

			return inquirePINErrorResponse(CErrorDefs.ERR_CONFIG_NUM, stAppInfo, stIdpTraceId);
		}

		HashMap hmIdenCSIValidCombination = CommonUtil.parseMultiDelimiterProperty(propValidPINIDENTypeAndCSI);

		if (!hmIdenCSIValidCombination.containsKey(stIdentificationType)) {

			stAppInfo = "Input IdentificationType is not valid for CallingSystemId :" + stCallingSystemID;

			return inquirePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);

		}

		ArrayList<String> alValidCSIforIden = (ArrayList) hmIdenCSIValidCombination.get(stIdentificationType);

		if (alValidCSIforIden != null && !alValidCSIforIden.contains(stCallingSystemID)) {
			stAppInfo = " Input X-ATT-ClientId or CallingSystemID  is not valid for IdentificationType :" + stIdentificationType;
			return inquirePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		return InquirePINResonse;
	}

	private InquirePINResponse inquirePINRequestValidatorInputValidator(InquirePINRequest inquirePINRequest) {
		InquirePINResponse inquirePINResponse = null;

		String stAppInfo = null;
		String sMethodName = ".inquirePINRequestValidatorInputValidator.";
		String stTransactionName = inquirePINRequest.getTransactionName();
		String stCallingSystemID = inquirePINRequest.getCallingSystemId();
		String stIdentificationType = inquirePINRequest.getIdentificationType();
		String stAccountID = inquirePINRequest.getAccountId();
		String stIdpTraceId = inquirePINRequest.getIdpTraceId();

		if (stCallingSystemID == null || stCallingSystemID.isEmpty()) {
			stAppInfo = "Either X-ATT-ClientId in request header or callingSystemId in request body must be present";
			logger.info("{}{}IPRV_102.3 : {}", sClassName, sMethodName, stAppInfo);
			return inquirePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (stIdentificationType == null || stIdentificationType.isEmpty()) {

			stAppInfo = "IdentificationType can not be null / empty.";
			logger.info("{}{}IPRV_102.4 : {}", sClassName, sMethodName, stAppInfo);
			return inquirePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		if (stAccountID == null || stAccountID.isEmpty()) {

			stAppInfo = "AccountID can not be null / empty.";
			logger.info("{}{}IPRV_102.5 : {}", sClassName, sMethodName, stAppInfo);
			return inquirePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}

		inquirePINRequest.setAccountId(stAccountID.trim().toLowerCase());
		inquirePINRequest.setIdentificationType(stIdentificationType.trim().toUpperCase());

		if (!"InquirePIN".equals(stTransactionName)) {
			stAppInfo = "Transaction Not Allowed :: TransactionName Should be InquirePIN";
			logger.info("{}{}IPRV_102.7 : {}", sClassName, sMethodName, stAppInfo);
			return inquirePINErrorResponse(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo, stIdpTraceId);
		}
		return inquirePINResponse;
	}

	private InquirePINResponse inquirePINErrorResponse(int appStatusCode, String stAppInfo, String stIdpTraceId) {
		Map<String, Object> hmResponse = CommonUtil.getHashMap();
		hmResponse.put(CommonDefs.COMMON_APP_INFO, stAppInfo);
		hmResponse.put("idp-trace-id", stIdpTraceId);
		hmResponse.put(CommonDefs.COMMON_APP_STATUS_CODE, String.valueOf(appStatusCode));
		hmResponse.put(CommonDefs.TRANSACTION_NAME, "InquirePIN");
		return (InquirePINResponse) CommonUtilHelper.generateCIRResponse(hmResponse);
	}

}
