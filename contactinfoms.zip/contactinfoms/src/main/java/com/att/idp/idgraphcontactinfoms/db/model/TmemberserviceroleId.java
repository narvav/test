package com.att.idp.idgraphcontactinfoms.db.model;

import java.math.BigDecimal;
import java.util.Date;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TmemberserviceroleId implements java.io.Serializable {

	private BigDecimal roleId;
	private BigDecimal memberNum;
	private BigDecimal serviceId;
	private BigDecimal sorId;
	private String sorInvariantId;
	private BigDecimal status;
	private Date createDate;
	private Date lastModified;
	private String lastModifiedBy;


	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TmemberserviceroleId))
			return false;
		TmemberserviceroleId castOther = (TmemberserviceroleId) other;

		return ((this.getRoleId() == castOther.getRoleId()) || (this.getRoleId() != null
				&& castOther.getRoleId() != null && this.getRoleId().equals(castOther.getRoleId())))
				&& ((this.getMemberNum() == castOther.getMemberNum()) || (this.getMemberNum() != null
						&& castOther.getMemberNum() != null && this.getMemberNum().equals(castOther.getMemberNum())))
				&& ((this.getServiceId() == castOther.getServiceId()) || (this.getServiceId() != null
						&& castOther.getServiceId() != null && this.getServiceId().equals(castOther.getServiceId())))
				&& ((this.getSorId() == castOther.getSorId()) || (this.getSorId() != null
						&& castOther.getSorId() != null && this.getSorId().equals(castOther.getSorId())))
				&& ((this.getSorInvariantId() == castOther.getSorInvariantId())
						|| (this.getSorInvariantId() != null && castOther.getSorInvariantId() != null
								&& this.getSorInvariantId().equals(castOther.getSorInvariantId())))
				&& ((this.getStatus() == castOther.getStatus()) || (this.getStatus() != null
						&& castOther.getStatus() != null && this.getStatus().equals(castOther.getStatus())))
				&& ((this.getCreateDate() == castOther.getCreateDate()) || (this.getCreateDate() != null
						&& castOther.getCreateDate() != null && this.getCreateDate().equals(castOther.getCreateDate())))
				&& ((this.getLastModified() == castOther.getLastModified())
						|| (this.getLastModified() != null && castOther.getLastModified() != null
								&& this.getLastModified().equals(castOther.getLastModified())))
				&& ((this.getLastModifiedBy() == castOther.getLastModifiedBy())
						|| (this.getLastModifiedBy() != null && castOther.getLastModifiedBy() != null
								&& this.getLastModifiedBy().equals(castOther.getLastModifiedBy())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getRoleId() == null ? 0 : this.getRoleId().hashCode());
		result = 37 * result + (getMemberNum() == null ? 0 : this.getMemberNum().hashCode());
		result = 37 * result + (getServiceId() == null ? 0 : this.getServiceId().hashCode());
		result = 37 * result + (getSorId() == null ? 0 : this.getSorId().hashCode());
		result = 37 * result + (getSorInvariantId() == null ? 0 : this.getSorInvariantId().hashCode());
		result = 37 * result + (getStatus() == null ? 0 : this.getStatus().hashCode());
		result = 37 * result + (getCreateDate() == null ? 0 : this.getCreateDate().hashCode());
		result = 37 * result + (getLastModified() == null ? 0 : this.getLastModified().hashCode());
		result = 37 * result + (getLastModifiedBy() == null ? 0 : this.getLastModifiedBy().hashCode());
		return result;
	}

}
