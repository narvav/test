package com.att.idp.idgraphcontactinfoms.cgclient.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

/**
 * The ContactMedium class represents a contact medium in the system.
 * It implements the Serializable interface, which means its instances can be converted to a byte stream and
 * restored back to the same object later. This is useful for storing objects in a file or sending them over a network.
 *
 * This class contains various properties related to a contact medium such as mediumType, preferred, and characteristic.
 * Each property has its corresponding getter and setter methods.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.cgclient.response package.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(name = "ContactMedium")
@Getter
@Setter
public class ContactMedium implements Serializable {

	private static final long serialVersionUID = -9028905776656013325L;

	@JsonProperty("mediumType")
	private String mediumType;

	@JsonProperty("preferred")
	private boolean preferred;

	@JsonProperty("characteristic")
	private Characteristic characteristic;
}