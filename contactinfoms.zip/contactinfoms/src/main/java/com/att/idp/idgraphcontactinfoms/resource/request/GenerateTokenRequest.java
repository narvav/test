package com.att.idp.idgraphcontactinfoms.resource.request;

import lombok.Data;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.request package.
 *
 * The GenerateTokenRequest class is used to represent a request to generate a token.
 * It contains several fields, each of which represents a parameter of the request.
 * These fields include transactionName, callingSystemId, accountId, identificationType, agentId, browserLanguage, sourceIPAddress, and deliveryMethods.
 *
 * Each field is annotated with @NotNull and/or @Size, indicating that they are required fields and have size constraints.
 * The messages associated with these annotations provide additional information about the requirements for each field.
 *
 * The class provides getter and setter methods for each field, allowing the fields to be accessed and modified.
 * It also overrides the toString method, providing a custom string representation of the object using reflection.
 */
@Data
public class GenerateTokenRequest {

	@NotNull(message="TransactionName is required field in input request.|GenerateToken")
	protected String transactionName;

	@NotNull(message="CallingSystemId is required field in input request.|GenerateToken")
	@Size(min=1, max=20,message="CallingSystemId length is invalid|GenerateToken")
	protected String callingSystemId;

	@NotNull(message="AccountId is required field in input request.|GenerateToken")
	@Size(min=1, max=60,message="AccountId length is invalid|GenerateToken")
	protected String accountId;

	@NotNull(message="IdentificationType is required field in input request.|GenerateToken")
	@Size(min=1,max=10,message="IdentificationType length is invalid.|GenerateToken")
	protected String identificationType;

	@Size(min=1, max=20,message="AgentId length is invalid|GenerateToken")
	protected String agentId;

	@Size(min=1, max=2,message="browserLanguage value can only be EN or ES|GenerateToken")
	protected String browserLanguage;

	@Size(min=1, max=100,message="sourceIPAddress length is invalid|GenerateToken")
	protected String sourceIPAddress;

	@Valid
	protected DeliveryMethods deliveryMethods;
}