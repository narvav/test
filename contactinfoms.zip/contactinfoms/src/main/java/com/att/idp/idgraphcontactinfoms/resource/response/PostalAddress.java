package com.att.idp.idgraphcontactinfoms.resource.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.response package.
 *
 * The PostalAddress class is used to represent a postal address associated with an account.
 * It contains several fields, each of which represents a different attribute of the postal address.
 * These fields include generalContactDetails, city, country, foreignAddrInd, name, state, street1, street2, street3, nbrNonAddressLines, zipCode, zipPlusFour, postOffice, and probationaryAddressExists.
 *
 * The generalContactDetails field is an object of the GeneralContactDetails class, representing general contact details associated with the postal address.
 * The city, country, name, state, street1, street2, street3, zipCode, zipPlusFour, and postOffice fields are strings representing the respective parts of the postal address.
 * The foreignAddrInd field is a string indicating whether the address is foreign.
 * The nbrNonAddressLines field is a string representing the number of non-address lines.
 * The probationaryAddressExists field is a string indicating whether a probationary address exists.
 *
 * Each field has a corresponding getter and setter method, allowing the fields to be accessed and modified.
 * The setter method for generalContactDetails is annotated with @JsonProperty, indicating the JSON property name to be used during serialization and deserialization.
 *
 * The class overrides the toString method, providing a custom string representation of the object.
 */
@Data
public class PostalAddress {

	private GeneralContactDetails generalContactDetails;
	private String city;
	private String country;
	private String foreignAddrInd;
	private String name;
	private String state;
	private String street1;
	private String street2;
	private String street3;
	private String nbrNonAddressLines;
	private String zipCode;
	private String zipPlusFour;
	private String postOffice;
	private String probationaryAddressExists;

	@JsonProperty("GeneralContactDetails")
	public void setGeneralContactDetails(GeneralContactDetails generalContactDetails) {
		this.generalContactDetails = generalContactDetails;
	}
}