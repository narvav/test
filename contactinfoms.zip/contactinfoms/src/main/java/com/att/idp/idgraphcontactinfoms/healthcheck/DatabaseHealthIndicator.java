package com.att.idp.idgraphcontactinfoms.healthcheck;

import com.att.idp.idgraphcontactinfoms.db.helper.HealthCheckDBHelper;
import com.att.idp.idgraphcontactinfoms.db.repository.impl.InquireAccountContactInfoRepositoryImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
/**
 * The `DatabaseHealthIndicator` class is a custom health indicator for monitoring the health of the database
 * in a Spring Boot application. It extends the `AbstractHealthIndicator` class provided by Spring Boot Actuator
 * and performs periodic health checks to determine the status of the database connection.
 *
 * <p>Key Features:
 * <ul>
 *   <li>Uses a scheduled task to periodically check the database health.</li>
 *   <li>Provides an override flag to skip health checks when necessary.</li>
 *   <li>Logs the health status of the database for debugging and monitoring purposes.</li>
 * </ul>
 *
 * <p>Dependencies:
 * <ul>
 *   <li>`HealthCheckDBHelper`: Helper class for performing database health checks.</li>
 *   <li>`InquireAccountContactInfoRepositoryImpl`: Repository implementation for database operations.</li>
 * </ul>
 *
 * <p>Configuration:
 * <ul>
 *   <li>`management.endpoint.health.indicator.override`: Flag to override health checks.</li>
 *   <li>`management.endpoint.health.db.indicator.scheduler-duration`: Duration for periodic health checks.</li>
 * </ul>
 *
 * <p>Usage:
 * This class is automatically detected as a Spring component and integrated into the application's
 * health check mechanism.
 */
@EnableScheduling
@Component
public class DatabaseHealthIndicator extends AbstractHealthIndicator {

    private boolean isDatabaseUp = false;

    @Value("${management.endpoint.health.indicator.override:false}")
    private boolean healthcheckOverrideFlag;

    public static final Logger logger = LoggerFactory.getLogger(DatabaseHealthIndicator.class);

    @Autowired
    private HealthCheckDBHelper healthCheckDBHelper;

    @Autowired
    private InquireAccountContactInfoRepositoryImpl inquireAccountContactInfoRepository;
    /**
     * Performs a periodic health check of the database connection.
     *
     * <p>This method is scheduled to run at a fixed interval, as defined by the
     * `management.endpoint.health.db.indicator.scheduler-duration` property. It uses the
     * `HealthCheckDBHelper` to verify the database's health status and updates the
     * `isDatabaseUp` flag accordingly.
     */
    @Scheduled(fixedRateString = "${management.endpoint.health.db.indicator.scheduler-duration:30000}")
    public void periodicCheck() {
        this.isDatabaseUp = healthCheckDBHelper.dbHealthCheck();
    }
    /**
     * Performs a health check on the database connection and updates the health status.
     *
     * <p>This method is invoked periodically based on the interval defined by the
     * `management.endpoint.health.db.indicator.scheduler-duration` property. It uses the
     * `HealthCheckDBHelper` to verify the database's health and updates the `isDatabaseUp` flag
     * to reflect the current status.
     */
    @Override
    protected void doHealthCheck(Health.Builder builder) throws Exception {
        if (healthcheckOverrideFlag) {
            logger.info("Skipping healthcheck as IDP healthcheck override flag is set to true");
            builder.up();
        } else {

            if (isDatabaseUp) {
                logger.debug("Database healthcheck successful, db is up: {}", isDatabaseUp);
                builder.up();
            } else {
                logger.error("Error occurred while checking idgraph ms database health status: {}", isDatabaseUp);
                builder.down();
            }
        }
    }

}