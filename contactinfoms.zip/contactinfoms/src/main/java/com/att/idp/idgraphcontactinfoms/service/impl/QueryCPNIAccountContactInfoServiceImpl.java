package com.att.idp.idgraphcontactinfoms.service.impl;

import java.util.HashMap;
import java.util.Map;

import jakarta.ws.rs.core.MultivaluedMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.att.idp.idgraphcontactinfoms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphcontactinfoms.helpers.QueryCPNIAcccountContactHelper;
import com.att.idp.idgraphcontactinfoms.resource.request.QueryCPNIAccountContactInfoRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.QueryCPNIAccountContactInfoResponse;
import com.att.idp.idgraphcontactinfoms.service.QueryCPNIAccountContactInfoService;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This class implements the QueryCPNIAccountContactInfoService interface and is responsible for handling operations related to querying CPNI (Customer Proprietary Network Information) account contact information.
 *
 * It is annotated with @Service, indicating that it's a Spring Service.
 * The class has a dependency on QueryCPNIAcccountContactHelper, which is autowired.
 * It also has a Logger instance for logging.
 *
 * The class has one main method: queryCPNIAccountContactInfo.
 * This method takes a QueryCPNIAccountContactInfoRequest and MultivaluedMap<String, String> as input parameters and returns a QueryCPNIAccountContactInfoResponse.
 * The method is responsible for querying the CPNI account contact information and handling the response.
 *
 * The class is also annotated with @Transactional, indicating that it's a transactional class with a specific transaction manager and rollback rules.
 */
@Service
public class QueryCPNIAccountContactInfoServiceImpl implements QueryCPNIAccountContactInfoService {

	@Autowired
	private QueryCPNIAcccountContactHelper queryAccountContactInfoHelper;

	public static final Logger logger = LoggerFactory.getLogger(QueryCPNIAccountContactInfoServiceImpl.class);
	
	private static String sClassName = "QueryCPNIAccountContactInfoServiceImpl";

	@Override
	public QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfo(
			QueryCPNIAccountContactInfoRequest queryAccountInfoRequest, MultivaluedMap<String, String> requestHeader) {

		
		HashMap<String, Object> hmInput = null;
		Map<String, Object> hmResponse = null;
		String sMethodName = ".queryCPNIAccountContactInfo.";

		hmInput = (HashMap<String, Object>) CommonUtilHelper.objectToMap(queryAccountInfoRequest);
		
		logger.info("QueryCPNIAccountContactInfoServiceImpl.queryCPNIAccountContactInfo.QAS_01 : Calling queryCPNIAccountContact with Input : {}",
				StructuredArguments.entries(hmInput));
		
		hmResponse = queryAccountContactInfoHelper.queryCPNIAccountContact(hmInput);
		
		logger.info("{}{}QAS_02 : Response from queryCPNIAccountContact Helper : {}", sClassName, sMethodName, hmResponse);
		
		if (CommonUtilHelper.isCollectionMapNullOrEmpty(hmResponse)) {
			hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from queryAccountContactInfoHelper.queryCPNIAccountContactInfo");
			logger.info("{}{}QAS_03 : Null response from queryAccountContactInfoHelper.queryCPNIAccountContactInfo", sClassName, sMethodName);
		} else {
			String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (stAppStatusCode == null) {
				hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from queryAccountContactInfoHelper.queryCPNIAccountContactInfo");
				logger.info("{}{}QAS_04 : Null response from queryAccountContactInfoHelper.queryCPNIAccountContactInfo", sClassName, sMethodName);
			}
		}

		hmResponse.put("idp-trace-id", queryAccountInfoRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME, "QueryCPNIAccountContactInfo");

		QueryCPNIAccountContactInfoResponse queryCPNIAccountResponse =  CommonUtilHelper
																		.queryCPNIAccountContactInfoResponse(hmResponse);

    	logger.info("{}{}QAS_05 : Response from QueryCPNIAccountContactInfoServiceImpl.queryCPNIAccountContactInfo : {}", sClassName, sMethodName,
    			queryCPNIAccountResponse);
		
		return queryCPNIAccountResponse;
	}
}