package com.att.idp.idgraphcontactinfoms.resource.response;

import com.att.idp.core.exception.ServiceError;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.response package.
 *
 * The GeneratePINResponse class is used to represent the response from a Generate PIN operation.
 * It contains several fields, each of which represents a different attribute of the response.
 * These fields include transactionName, appStatusMsg, appStatusCode, appInfo, appCategoryCode, errors, idpTraceId, securityCode, and securityCodeExpires.
 *
 * The transactionName field represents the name of the transaction.
 * The appStatusMsg field represents the status message of the application.
 * The appStatusCode field represents the status code of the application.
 * The appInfo field represents the information of the application.
 * The appCategoryCode field represents the category code of the application.
 * The errors field is an object of the ServiceError class, representing any errors that occurred during the operation.
 * The idpTraceId field represents the trace ID of the IDP.
 * The securityCode field represents the generated security code.
 * The securityCodeExpires field represents the expiration date of the security code.
 *
 * Each field has a corresponding getter and setter method, allowing the fields to be accessed and modified.
 * The setter methods for errors and idpTraceId are annotated with @JsonProperty, indicating the JSON property name to be used during serialization and deserialization.
 *
 * The class is annotated with @JsonIgnoreProperties and @JsonInclude, which control the JSON serialization and deserialization behavior.
 * The @JsonIgnoreProperties annotation indicates that any unknown properties encountered during JSON processing should be ignored.
 * The @JsonInclude annotation indicates that only non-null properties should be included in the JSON.
 *
 * The class is also annotated with @ApiModel, which provides additional metadata for the Swagger documentation.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "GeneratePINResponse")
public class GeneratePINResponse {

	@JsonIgnore
	private String transactionName;
	private String appStatusMsg;
	private String appStatusCode;
	private String appInfo;
	@JsonIgnore
	private String appCategoryCode;
	private ServiceError errors;
	private String idpTraceId;

	private String securityCode;
	private String securityCodeExpires;

	@JsonProperty("error")
	public void setErrors(ServiceError errors) {
		this.errors = errors;
	}

	@JsonProperty("idp-trace-id")
	public void setIdpTraceId(String idpTraceId) {
		this.idpTraceId = idpTraceId;
	}
}