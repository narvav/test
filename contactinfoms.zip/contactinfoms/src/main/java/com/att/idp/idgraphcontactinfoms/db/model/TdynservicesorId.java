package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TdynservicesorId implements java.io.Serializable {

	private static final long serialVersionUID = 8906295566627099390L;

	@Column(name = "SERVICE_ID", nullable = false, precision = 22, scale = 0)
	private Long serviceId;

	@Column(name = "SOR_ID", nullable = false, precision = 22, scale = 0)
	private Long sorId;


	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TdynservicesorId))
			return false;
		TdynservicesorId castOther = (TdynservicesorId) other;

		return ((this.getServiceId() == castOther.getServiceId()) || (this.getServiceId() != null
				&& castOther.getServiceId() != null && this.getServiceId().equals(castOther.getServiceId())))
				&& ((this.getSorId() == castOther.getSorId()) || (this.getSorId() != null
						&& castOther.getSorId() != null && this.getSorId().equals(castOther.getSorId())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getServiceId() == null ? 0 : this.getServiceId().hashCode());
		result = 37 * result + (getSorId() == null ? 0 : this.getSorId().hashCode());
		return result;
	}

}
