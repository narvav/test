package com.att.idp.idgraphcontactinfoms.db.model;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "TMEMBERSERVICE", schema = "MPS_OWNER", uniqueConstraints = @UniqueConstraint(columnNames = {
		"MEMBER_NUM", "SERVICE_ID", "SOR_ID", "SOR_INVARIANT_ID" }))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tmemberservice implements java.io.Serializable {

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "memberNum", column = @Column(name = "MEMBER_NUM", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "serviceId", column = @Column(name = "SERVICE_ID", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "groupNum", column = @Column(name = "GROUP_NUM", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "groupStatus", column = @Column(name = "GROUP_STATUS", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "memberStatus", column = @Column(name = "MEMBER_STATUS", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "terminateDate", column = @Column(name = "TERMINATE_DATE", length = 7)),
			@AttributeOverride(name = "createDate", column = @Column(name = "CREATE_DATE", nullable = false, length = 7)),
			@AttributeOverride(name = "lastModified", column = @Column(name = "LAST_MODIFIED", length = 7)),
			@AttributeOverride(name = "lastModifiedBy", column = @Column(name = "LAST_MODIFIED_BY", nullable = false)),
			@AttributeOverride(name = "instanceId", column = @Column(name = "INSTANCE_ID", length = 24)),
			@AttributeOverride(name = "pendingDisconnectDate", column = @Column(name = "PENDING_DISCONNECT_DATE", length = 7)),
			@AttributeOverride(name = "siteId", column = @Column(name = "SITE_ID", length = 9)),
			@AttributeOverride(name = "sorId", column = @Column(name = "SOR_ID", precision = 22, scale = 0)),
			@AttributeOverride(name = "sorInvariantId", column = @Column(name = "SOR_INVARIANT_ID")),
			@AttributeOverride(name = "atlasLastTimestamp", column = @Column(name = "ATLAS_LAST_TIMESTAMP")),
			@AttributeOverride(name = "ownedBy", column = @Column(name = "OWNED_BY", precision = 22, scale = 0)),
			@AttributeOverride(name = "nickname", column = @Column(name = "NICKNAME", length = 30)),
			@AttributeOverride(name = "defaultAccount", column = @Column(name = "DEFAULT_ACCOUNT", length = 1)),
			@AttributeOverride(name = "dateDefaultEst", column = @Column(name = "DATE_DEFAULT_EST", length = 7)),
			@AttributeOverride(name = "cpniImpacted", column = @Column(name = "CPNI_IMPACTED", length = 1)),
			@AttributeOverride(name = "suspendReasonCode", column = @Column(name = "SUSPEND_REASON_CODE", length = 30)),
			@AttributeOverride(name = "parentSorId", column = @Column(name = "PARENT_SOR_ID", precision = 22, scale = 0)),
			@AttributeOverride(name = "parentSorInvariantId", column = @Column(name = "PARENT_SOR_INVARIANT_ID")),
			@AttributeOverride(name = "uverseServiceInd", column = @Column(name = "UVERSE_SERVICE_IND", length = 1)),
			@AttributeOverride(name = "unificationPending", column = @Column(name = "UNIFICATION_PENDING", length = 1)) })
	private TmemberserviceId id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MEMBER_NUM", nullable = false, insertable = false, updatable = false)
	private Tmember tmember;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SOR_ID", insertable = false, updatable = false)
	private Tsystemofrecord tsystemofrecord;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SERVICE_ID", nullable = false, insertable = false, updatable = false)
	private Tservice tservice;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "MEMBER_STATUS", nullable = false, insertable = false, updatable = false)
	private Tstatus tstatusByMemberStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "GROUP_STATUS", nullable = false, insertable = false, updatable = false)
	private Tstatus tstatusByGroupStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "GROUP_NUM", nullable = false, insertable = false, updatable = false)
	private Tmembergroup tmembergroup;
}