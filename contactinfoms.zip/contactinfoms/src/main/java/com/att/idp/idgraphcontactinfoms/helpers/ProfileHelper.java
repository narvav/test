package com.att.idp.idgraphcontactinfoms.helpers;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import com.att.idp.cgclienthelpers.integration.ProfileRestClient;
import com.att.idp.http.client.config.RestTemplateBeanFactory;
import com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig;
import com.att.idp.idgraphcontactinfoms.integration.OutboundRestClientBuilder;
import io.swagger.client.model.CGIndividualInfo;
import jakarta.ws.rs.core.MultivaluedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.io.IOException;

import static com.att.idp.cd.observability.metrics.utils.Constants.GET;
import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_75;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_90;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_95;
import static com.att.idp.cd.observability.metrics.utils.Constants.PERCENTILE_99;
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_OB;
import static com.att.idp.idgraphcontactinfoms.utils.Constants.IDGRAPH_CONTACT_INFO_MS_OB;

@Component
public class ProfileHelper {

    private static final Logger logger = LoggerFactory.getLogger(ProfileHelper.class);

    private static final String PROFILE_REST_CLIENT = "profilerestclient";


    @Autowired
    private ProfileRestClient profileRestClient;
    private RestTemplate restTemplate;


    private IDGraphAzureAppConfig appConfiguration;
    private final RestTemplateBeanFactory restTemplateFactory;
    private OutboundRestClientBuilder outboundRestClientBuilder;


    @Autowired
    public ProfileHelper(RestTemplateBeanFactory restTemplateBeanFactory, IDGraphAzureAppConfig appConfiguration, OutboundRestClientBuilder outboundRestClientBuilder) throws Exception {
        this.restTemplateFactory = restTemplateBeanFactory;
        this.appConfiguration = appConfiguration;
        this.outboundRestClientBuilder = outboundRestClientBuilder;
        this.restTemplate = restTemplateFactory.getObject(PROFILE_REST_CLIENT);
    }

    @PostConstruct
    public void init() {
        this.restTemplate = this.initializeRestTemplate(this.restTemplate);
        logger.info("RestTemplate connectTimeout={} ms, readTimeout={} ms", appConfiguration.getProfileConnectTimeout(), appConfiguration.getProfileReadTimeout());
    }

    /**
     * Handles the refresh event triggered by the Spring Cloud RefreshScope.
     * <p>
     * This method is invoked when the application context is refreshed, typically due to
     * configuration changes. It synchronizes the update of the `RestTemplate` instance
     * with new timeout values retrieved from the `IDGraphAzureAppConfig` bean.
     * If the update fails, the method logs the error and retains the existing `RestTemplate`.
     *
     * @throws Exception if an error occurs while updating the `RestTemplate` instance.
     */
    @EventListener(RefreshScopeRefreshedEvent.class)
    public void onConfigurationRefresh() throws Exception {
        if (appConfiguration.isProfileRestClientRefreshEnabled()) {
            synchronized (this) {
                try {

                    if (this.restTemplate == null) {
                        this.restTemplate = restTemplateFactory.getObject(PROFILE_REST_CLIENT);
                    }

                    this.restTemplate = initializeRestTemplate(this.restTemplate);

                    logger.info("ProfileRestClient dynamically updated with new timeout values: connectTimeout={} ms, readTimeout={} ms", appConfiguration.getProfileConnectTimeout(), appConfiguration.getProfileReadTimeout());
                } catch (Exception e) {
                    // Log the error and retain the old RestTemplate
                    logger.error("Failed to update ProfileHelper RestTemplate with new timeout values. Retaining the old RestTemplate.", e);
                }
            }
        } else {
            logger.info("ProfileRestClient refresh is disabled. Retaining the existing RestTemplate.");
        }
    }

    private RestTemplate initializeRestTemplate(RestTemplate restTemplate) {
        try {
            if (restTemplate == null) {
                restTemplate = restTemplateFactory.getObject(PROFILE_REST_CLIENT);
            }
            restTemplate = outboundRestClientBuilder.buildRestTemplate(restTemplate, appConfiguration.getProfileConnectTimeout(), appConfiguration.getProfileReadTimeout(), false, null);
            logger.info("Initializing RestTemplate dynamically updated from azureappconfig with new timeout values: connectTimeout={} ms, readTimeout={} ms", appConfiguration.getProfileConnectTimeout(), appConfiguration.getProfileReadTimeout());
        } catch (Exception e) {
            logger.error("Error in initializing RestTemplate for ProfileRestClient: {}", e.getMessage(), e);
        }
        return restTemplate;
    }


    /**
     * Searches for a profile in the Profile MS by the given individual ID.
     *
     * <p>
     * This method delegates the search operation to the {@link ProfileRestClient}, passing the provided
     * individual ID, request headers, and the configured {@link RestTemplate} instance.
     * </p>
     *
     * <p>
     * Note: The @TimedMetrics annotation previously included paramKeys = {"uri"}, but this method does not have a
     * "uri" parameter. The paramKeys attribute has been removed for correctness and clarity.
     * </p>
     *
     * @param individualId   the unique identifier of the individual to search for
     * @param requestHeaders the HTTP headers to include in the request
     * @return a {@link CGIndividualInfo} object containing the individual's profile information
     * @throws IOException if an error occurs during the REST call
     */
    @TimedMetrics(name = IDGRAPH_CONTACT_INFO_MS_OB, type = REST_OB, description = "Profile API", tags = {METHOD, GET}, histogram = true, percentiles = {PERCENTILE_75, PERCENTILE_90, PERCENTILE_95, PERCENTILE_99})
    public CGIndividualInfo profileMsSearchByIndividualId(String individualId, MultivaluedMap<String, String> requestHeaders) throws IOException {
        return profileRestClient.profileMsSearchByIndividualId(individualId, requestHeaders, this.restTemplate);
    }
}
