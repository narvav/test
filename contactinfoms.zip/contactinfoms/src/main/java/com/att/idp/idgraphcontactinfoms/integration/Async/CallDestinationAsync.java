package com.att.idp.idgraphcontactinfoms.integration.Async;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig;
import com.att.idp.idgraphcontactinfoms.helpers.CGHelper;
import com.att.mpsys.common.utils.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.att.mpsys.common.helpers.SoapHelper;
import com.google.common.html.HtmlEscapers;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.integration.Async package.
 * It is annotated with @Component, indicating that it is a Spring bean and can be automatically
 * picked up and instantiated by Spring's container.
 *
 * The class is used to make asynchronous calls to different destinations based on the input parameters.
 * It contains several fields that are injected via Spring's @Autowired and @Value annotations.
 * The @Autowired annotation is used to inject the SoapHelper and CGRestClient objects, which are used to make SOAP and REST calls respectively.
 * The @Value annotation is used to inject the value of the apiclient.rest.cg.endpoint property from the application's properties file.
 *
 * The class contains a single public method, callDestinationAsync, which is used to make an asynchronous call to a destination.
 * The method takes a HashMap as input, which contains the details of the request, and returns a CompletableFuture containing a Map with the response.
 * The method uses the input parameters to determine the destination of the call, and then makes the appropriate call using the SoapHelper or CGRestClient.
 * The method handles any exceptions that may occur, and logs information about the processing.
 */
@Component
public class CallDestinationAsync {
	public static final String SOAP_CONNECTION_TIMEOUT = "SOAP_CONNECTION_TIMEOUT";
	public static final String SOAP_READ_TIMEOUT = "SOAP_READ_TIMEOUT";
	public static final String BDS_URL_GC = "BDS_URL_GC";
	private static Logger log = LoggerFactory.getLogger(CallDestinationAsync.class);
	public static final String ACCOUNTS = "accounts";
	public static final String SUBSCRIBERS = "subscribers";
	
	private static String sClassName = "CallDestinationAsync";
			
	@Autowired
	private SoapHelper soapHelper;

	@Autowired
	private CGHelper cgHelper;
	
	@Value("${apiclient.rest.cg.endpoint}")
	private String cgV2Endpoint;

	@Value("${apiclient.rest.cg.custsearch.v3.endpoint}")
	private String cgV3Endpoint;

	@Autowired
	private IDGraphAzureAppConfig idGraphAzureAppConfig;

	private PropertyManagerLoader propertyManagerLoader;

	@Value("${BDS_URL_GC:}")
	private String bdsURL;
	private String bdsUser;
	private String bdsPwrd;


	public CallDestinationAsync(PropertyManagerLoader propertyManagerLoader) {
		this.propertyManagerLoader = propertyManagerLoader;

		FileInputStream fIn = null;
		try {
			bdsUser = PropertyManager.getProperty(CommonDefs.MOUPConfig,
					"BDS_USER");
			bdsPwrd = PropertyManager.getProperty(CommonDefs.MOUPSECRETConfig,
					"BDS_PWD");

		} catch (Exception e) {
			log.error("GC-E2b : " + "General Exception creating the Voltage library " + e);

		} finally {
			if (fIn != null) {
				try {
					fIn.close();
				} catch (IOException e) {
					log.error("GC-E2c : " + "IOException closing keys.properties " + e);
				}
			}
		}
	}

	/**
	 * This method is used to make an asynchronous call to a destination.
	 *
	 * It takes a HashMap as input, which contains the details of the request, and returns a CompletableFuture containing a Map with the response.
	 * The method uses the input parameters to determine the destination of the call, and then makes the appropriate call using the SoapHelper or CGRestClient.
	 * The method handles any exceptions that may occur, and logs information about the processing.
	 *
	 * @param hmInput A HashMap containing the details of the request.
	 * @return A CompletableFuture containing a Map with the response.
	 * @throws JsonProcessingException If there is an error processing the JSON.
	 * @throws IOException If there is an error with I/O operations.
	 */
	@Async("CIRAsyncTaskExecutor")
	public CompletableFuture<Map<String, Object>> callDestinationAsync(HashMap<String, Object> hmInput) throws JsonProcessingException, IOException {

		String sMethodName=".callDestinationAsync.";
		log.debug("{}{}CDA_01 START ::  with Inputparam: {}",sClassName,sMethodName, HtmlEscapers.htmlEscaper().escape(String.valueOf(hmInput)));
		String sAppInfo = null;
		Map hmResponse = new HashMap<String, Object>();

		String destination = (String) hmInput.get("CallingDestination");
		String destinationKey = (String) hmInput.get("destinationKey");
		
		if(destination == null){
			sAppInfo = "Not able to identify the CallingDestination";
			log.error("{}{}CDA_02 CDAsync : {}",sClassName,sMethodName,  sAppInfo);
			hmResponse.put("CallingDestination", "NO_DEST");
			hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EXTERNAL_SYS_NUM, sAppInfo);
			return CompletableFuture.completedFuture(hmResponse);
		}
		// removing CallingDestination attribute from the input hash.
		hmInput.remove("CallingDestination");
		hmInput.remove("destinationKey");
		
		//calling external destination according to the Calling Destination.
		if("CSI".equals(destination)){
			log.debug("{}{}CDA_03 : Calling CSI Destination with request {}",sClassName,sMethodName,  HtmlEscapers.htmlEscaper().escape(String.valueOf(hmInput)));
			
			//getCGSyncCall
			
			HashMap hmCGInput = new HashMap();
			hmCGInput.put("RESPONSE", ACCOUNTS);
			String stTopicName = null;
			if(hmInput.get(CommonDefs.BILLING_ACCOUNT_NUMBER)!= null) {
				hmCGInput.put(CommonDefs.ACCOUNT_ID, (String) hmInput.get(CommonDefs.BILLING_ACCOUNT_NUMBER));
				hmCGInput.put(CommonDefs.SERVICE_TYPE, "wireless");
			}
			if(hmInput.get(CommonDefs.SUBSCRIBER_NUMBER)!= null ) {
				hmCGInput.put(CommonDefs.SUBSCRIBER_NUMBER, (String) hmInput.get(CommonDefs.SUBSCRIBER_NUMBER));
			}else if(hmInput.get("ctn")!= null) {
				hmCGInput.put(CommonDefs.SUBSCRIBER_NUMBER, (String) hmInput.get("ctn"));
			}
			stTopicName = ACCOUNTS+","+SUBSCRIBERS+",equipments";	
			
			hmCGInput.put("topics", stTopicName);			
			hmCGInput.put("apiName","CGCustomerSearch");

			String cgEndpoint = "BSSEWIRELESS".equals(hmInput.get("accountType")) ? cgV3Endpoint : cgV2Endpoint;

			hmResponse = cgHelper.makeCGSyncCall(hmCGInput, cgEndpoint);
			
			log.debug("{}{}CDA_04 : Response returned from CG with  topic:{}. Response= {}",sClassName,sMethodName, stTopicName, hmResponse);

		}else if("BDS".equals(destination)){
			log.debug("{}{}CDA_05 : Calling BDS Destination with request {}",sClassName,sMethodName, 
					HtmlEscapers.htmlEscaper().escape(String.valueOf(hmInput)));

			hmInput.put(SOAP_CONNECTION_TIMEOUT, idGraphAzureAppConfig.getBdsConnectTimeoutSec());
			hmInput.put(SOAP_READ_TIMEOUT, idGraphAzureAppConfig.getBdsReadTimeoutSec());
			if (bdsURL == null || bdsURL.isBlank()) {
				String appInfo = "Missing required config: BDS_URL_GC";
				log.error("{}{}CDA_05a : {}", sClassName, sMethodName, appInfo);
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, appInfo);
				hmResponse.put("destinationKey", destinationKey);
				return CompletableFuture.completedFuture(hmResponse);
			}
			hmInput.put(BDS_URL_GC, bdsURL);

			hmResponse = soapHelper.callBDS(hmInput);

			log.debug("{}{}CDA_06 : Response returned from BDS Destination. Response= {}",sClassName,sMethodName, hmResponse);
						
		}else{
			sAppInfo = "Destination :" + destination + ", name not found in the calling list.";
			log.debug("{}{}CDA_07 CDAsync : {}",sClassName,sMethodName,  sAppInfo);
			hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
			hmResponse.put("destinationKey", destinationKey);
			return CompletableFuture.completedFuture(hmResponse);
		}
		hmResponse.put("destinationKey", destinationKey);
		log.debug("{}{}CDA_08 END :: Destination call Completed. Response : {}" ,sClassName,sMethodName,  hmResponse);
		return CompletableFuture.completedFuture(hmResponse);
	}


}
