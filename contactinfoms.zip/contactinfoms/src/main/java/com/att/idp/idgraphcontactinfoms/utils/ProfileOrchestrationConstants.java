package com.att.idp.idgraphcontactinfoms.utils;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.utils package.
 *
 * The ProfileOrchestrationConstants class is a utility class that provides constant string values used in profile orchestration.
 * It contains a set of public static final string constants that represent various identifiers and names used in the orchestration of profiles.
 *
 * The class is designed to be non-instantiable, i.e., an object of this class cannot be created.
 * This is enforced by not providing a public constructor.
 *
 * This class is useful when you need to use consistent, predefined string values across your application, particularly for profile orchestration.
 */
public class ProfileOrchestrationConstants {

	public static final String CG_CUSTOMER_SEARCH ="CGCustomerSearch";
	public static final String API_NAME="apiName";
	public static final String CG_END_POINT="cgEndPoint";
	public static final String  TRANSACTION_NAME_DELETE_PIN= "DeletePIN";
	public static final String TRANSACTION_NAME_GENERATE_PIN = "GeneratePIN";
	public static final String TRANSACTION_NAME_VALIDATE_PIN = "ValidatePIN";
	public static final String TRANSACTION_NAME_QUERY_CPN_I_USER_CONTACT_INFO = "QueryCPNIUserContactInfo";
	public static final String TRANSACTION_NAME_QUERY_CPN_I_ACCOUNT_CONTACT_INFO = "QueryCPNIAccountContactInfo";
	public static final String TRANSACTION_NAME_IQUIRE_PIN = "InquirePIN";
	public static final String TRANSACTION_NAME_CPNI_CONTACT_INFO = "CPNIContactInfo";
	public static final String IDP_CHECKOUT_MS = "com.att.idp.CheckoutMs";
	public static final String IDPCHECKOUT = "IDPCHECKOUT";
	
	// Added for GeneratePIN identification type PORTOUTABS
	public static final String PORTOUTABS_IDENTIFICATION_TYPE = "PORTOUTABS";
	public static final String  HIDEPIN_ATTR= "hidePINInNotification";
	public static final String STATUS_CODE_ACTIVE="ACTIVE";
	public static final String STATUS_CODE_REGISTERED="REGISTERED";
	public static final String  EXPIRY_TIME_UNIT="expiryTimeUnit";
	public static final String  HOURS="Hours";
	public static final String  MINUTES="Minutes";
	public static final String DELIVERY_METHOD_TYPE_SMS ="S";


}
