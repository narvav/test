package com.att.idp.idgraphcontactinfoms.resource.request;

import static org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString;
import static org.apache.commons.lang3.builder.ToStringStyle.JSON_STYLE;

import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.request package.
 *
 * The QueryCPNIAccountContactInfoRequest class is used to represent a request to query CPNI account contact information.
 * It contains several fields, each of which represents a parameter of the request.
 * These fields include transactionName, callingSystemId, accountInvariantId, accountId, accountType, returnCBRCTNs, idpTraceId, skipAgingRuleFlag, isExternalCall, and unknownAttributes.
 *
 * Each field is annotated with @Size and/or @NotNull, indicating that they are required fields and have size constraints.
 * The messages associated with these annotations provide additional information about the requirements for each field.
 *
 * The class provides a map of unknownAttributes, which can be used to store any additional attributes that are not part of the other fields.
 * The unknownAttributes map is annotated with @JsonAnySetter and @JsonAnyGetter, allowing it to be included in JSON serialization and deserialization.
 *
 * The class also overrides the toString method, providing a custom string representation of the object using reflection.
 */

@Schema(name = "queryCPNIAccountContactInfoRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class QueryCPNIAccountContactInfoRequest {
	
    protected final String transactionName="QueryCPNIAccountContactInfo";
   
    @Size(min=1, max=20,message="CallingSystemId length is invalid|QueryCPNIAccountContactInfo")
    protected String callingSystemId;
    
    @Size(min=1, max=255,message="accountInvariantId length is invalid|QueryCPNIAccountContactInfo")
    protected String accountInvariantId;
    
    @Size(min=1,max=13,message="accountId length is invalid|QueryCPNIAccountContactInfo") 
    protected String accountId;
    
    @NotNull(message="accountType is required field in input request.|QueryCPNIAccountContactInfo")
    @Size(min=1,max=30,message="accountType length is invalid|QueryCPNIAccountContactInfo") 
    protected String accountType;
    
    @Size(min=1,max=1,message="returnCBRCTNs value can only be Y or N|QueryCPNIAccountContactInfo") 
	private String returnCBRCTNs;
   
    @Schema(name = "idpTraceId")
	private String idpTraceId;

    @Size(min=1,max=1,message="skipAgingRuleFlag value can only be Y or N|QueryCPNIAccountContactInfo") 
	private String skipAgingRuleFlag;

    @Schema(name = "isExternalCall")
    protected String isExternalCall;

    /**
     * This field represents a map of unknown attributes.
     *
     * The unknownAttributes map is used to store any additional attributes that are not part of the attributeName and attributeValue fields.
     * It is initialized as a new HashMap.
     *
     * The field is annotated with @JsonAnySetter and @JsonAnyGetter, allowing it to be included in JSON serialization and deserialization.
     */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();

	@Override
    public String toString() {
        return reflectionToString(this, JSON_STYLE);
    }
    
}
