package com.att.idp.idgraphcontactinfoms.db.repository.impl;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.att.idp.idgraphcontactinfoms.utils.DateUtil;
import com.att.idp.idgraphcontactinfoms.utils.ProfileOrchestrationConstants;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.idp.idgraphcontactinfoms.db.model.Tsecurityaccount;
import com.att.idp.idgraphcontactinfoms.db.repository.IDGraphContactInfoCustomRepository;
import com.att.idp.idgraphcontactinfoms.db.repository.SecurityAccountDataRepositoryCustom;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This is the implementation class for the SecurityAccountDataRepositoryCustom interface.
 *
 * It extends IDGraphContactInfoCustomRepository, which is a custom repository for IDGraphContactInfo. The IDGraphContactInfoCustomRepository takes two parameters: Tsecurityaccount and Long. Tsecurityaccount is the entity and Long is the type of the entity's primary key.
 *
 * This class is meant to provide the actual implementation of the methods defined in the SecurityAccountDataRepositoryCustom interface.
 */
public class SecurityAccountDataRepositoryImpl extends IDGraphContactInfoCustomRepository<Tsecurityaccount, Long>
		implements SecurityAccountDataRepositoryCustom {

	private static final Logger logger = LoggerFactory.getLogger(SecurityAccountDataRepositoryImpl.class);
	private static String sClassName = "SecurityAccountDataRepositoryImpl";
	
	@Override
	public int setSecurityAccountData(HashMap InpParam) throws SQLException, Exception {

		String sMethodName = "";

		int rowsCount = 0;

		LocalDate localDate = LocalDate.now();
		java.sql.Date now = java.sql.Date.valueOf(localDate);

		logger.info("{}{}DBTOOLS000 :  InpParam = {}",sClassName, sMethodName,InpParam);

		HashMap resultHash = null;

		String identification_type = ((String) InpParam.get(MPSDefs.DB_IDENTIFICATION_TYPE));

		if (identification_type != null) {
			identification_type = (identification_type.toUpperCase()).trim();
		}

		String last_modified_by = (String) InpParam.get(MPSDefs.DB_LAST_MODIFIED_BY);

		String stSecurityCodeExpirationTime = ((String) InpParam.get("security_code_expiration_time"));

		double securityCodeExpirationTime = Double.parseDouble(stSecurityCodeExpirationTime);

		String account_id = (String) InpParam.get(MPSDefs.DB_ACCOUNT_ID);
		String account_type = (String) InpParam.get(MPSDefs.DB_ACCOUNT_TYPE);
		String account_region = (String) InpParam.get(MPSDefs.DB_ACCOUNT_REGION);
		String sor_invariant_id = (String) InpParam.get(MPSDefs.DB_SOR_INVARIANT_ID);

		int cumulative_failure_count = 0;

		try {
			logger.debug("{}{}DBSAD_01 : identification_type::PARAM 1 = {}", sClassName, sMethodName,
					identification_type);

			logger.debug("{}{}DBHSAD_02 : account_id::PARAM 2 = {}", sClassName, sMethodName, account_id);

			if (account_type != null) {
				logger.debug("{}{}DBSAD_03 : account_type::PARAM 3 = {}", sClassName, sMethodName, account_type);
			} else {
				logger.debug("{}{}DBSAD_03.1 : account_type::PARAM 3 = null",sClassName, sMethodName);
			}

			if (account_region != null) {
				logger.debug("{}{}DBSAD_04 : account_region::PARAM 4 = {}",
						sClassName, sMethodName, account_region);
			} else {
				logger.debug("{}{}DBSAD_04.1 : account_region::PARAM 4 = null", sClassName, sMethodName);
			}

			logger.debug("{}{}DBSAD_05 : cumulative_failure_count::PARAM 5 = {}",
					sClassName, sMethodName,cumulative_failure_count);

			logger.debug("{}{}DBSAD_06 : last_modified_by::PARAM 6 = {}", sClassName, sMethodName, last_modified_by);

			if (sor_invariant_id != null) {
				logger.debug("{}{}DBSAD_07 : sor_invariant_id::PARAM 7 = {}",sClassName, sMethodName,
						sor_invariant_id);
			} else {
				logger.debug("{}{}DBSAD_07.1 : sor_invariant_id::PARAM 7 = null",sClassName, sMethodName);
			}

			String sql = "INSERT INTO MPS_OWNER.TSECURITYACCOUNT (IDENTIFICATION_TYPE,ACCOUNT_ID,ACCOUNT_TYPE,ACCOUNT_REGION, "
					+ "CUMULATIVE_FAILURE_COUNT,ACCOUNT_ENTRY_EXPIRES,LAST_MODIFIED_BY,SOR_INVARIANT_ID) "
					+ "values (:identificationType,:accountId,:accountType, "
					+ ":accountRegion, :cumulativeFailureCount, sysdate + :accountEntryExpires, "
					+ ":lastModifiedBy, :sorInvariantId)";

			Session hibSession = getSession();

			rowsCount = hibSession.createNativeQuery(sql).setParameter("identificationType",
					(StringUtils.isNoneBlank(identification_type) ? (identification_type.toUpperCase()).trim() : null))
					.setParameter("accountId", (StringUtils.isNoneBlank(account_id) ? (account_id.toLowerCase()).trim() : null))
					.setParameter("accountType", (StringUtils.isNoneBlank(account_type) ? account_type : null))
					.setParameter("accountRegion", (StringUtils.isNoneBlank(account_region) ? account_region : null))
					.setParameter("cumulativeFailureCount", cumulative_failure_count)
					.setParameter("accountEntryExpires",
							DateUtil.getsecurityCodeExpiryTime(securityCodeExpirationTime,
									(String) InpParam.get(ProfileOrchestrationConstants.EXPIRY_TIME_UNIT)))
					//.setParameter("createDate", now).setParameter("lastModified", now)
					.setParameter("lastModifiedBy", last_modified_by)
					.setParameter("sorInvariantId", (StringUtils.isNoneBlank(sor_invariant_id) ? sor_invariant_id : null))
					.executeUpdate();

			logger.info("{}{}DBSAD_15 : rowCount = {}",sClassName, sMethodName , rowsCount);
		} catch (Exception e) {
			
			logger.error("{}{}DBSADE01 : Error:: {}",sClassName, sMethodName, e.getMessage());
			logger.error("{}{}DBSADE02 : Exception = {}", sClassName, sMethodName ,e);
			throw e;

		} finally {
			logger.info("{}{}DBTOOLS999 : total row count : {}",sClassName , sMethodName ,rowsCount);
		}
		return rowsCount;
	}

	@Override
	public int updateSecurityAccount(HashMap InpParam, boolean isSaveSecurityCode, Long cumulativeFailureCount) throws SQLException,Exception {
		
		int rowCount = 0;
		
		String sMethodName =  ".updateSecurityAccount.";
		logger.info("{}{}DBTOOLS000 : InpParam = {}",sClassName,sMethodName, InpParam);

		HashMap resultHash = null;
		List<Object> objectList = new ArrayList<Object>();
		double securityCodeExpirationTime = 0.0;
		
		LocalDate localDate = LocalDate.now();
		java.sql.Date now = java.sql.Date.valueOf(localDate);

		// get info from HashMap
		String identification_type = (String) InpParam.get(MPSDefs.DB_IDENTIFICATION_TYPE);
		if (identification_type != null) {
			identification_type = (identification_type.toUpperCase()).trim();
		}
		String account_id = (String) InpParam.get(MPSDefs.DB_ACCOUNT_ID);
		if (account_id != null) {
			account_id = (account_id.toLowerCase()).trim();
		}
		String last_modified_by = (String) InpParam.get(MPSDefs.DB_LAST_MODIFIED_BY);

		String sor_invariant_id = (String) InpParam.get(MPSDefs.DB_SOR_INVARIANT_ID);

		String stSecurityCodeExpirationTime = ((String) InpParam.get("security_code_expiration_time"));

		if(stSecurityCodeExpirationTime != null && !stSecurityCodeExpirationTime.isEmpty())
			securityCodeExpirationTime = Double.parseDouble(stSecurityCodeExpirationTime);
		
		String setAccountExpirySql = "UPDATE MPS_OWNER.TSECURITYACCOUNT " +
				"SET ACCOUNT_ENTRY_EXPIRES = sysdate + :accountEntryExpires, LAST_MODIFIED_BY= :last_modified_by "
				+ "WHERE " + "IDENTIFICATION_TYPE = :identification_type " + "AND ACCOUNT_ID = :account_id ";
		
		String setCumulativeCountSql = "UPDATE MPS_OWNER.TSECURITYACCOUNT SET "
				+ "CUMULATIVE_FAILURE_COUNT = :cumulativeFailureCount, LAST_MODIFIED_BY=:last_modified_by "
				+ "WHERE IDENTIFICATION_TYPE= :identification_type " + "AND ACCOUNT_ID=:account_id ";

		String setAccountExpirySorInvariantIdSql = "UPDATE MPS_OWNER.TSECURITYACCOUNT " + "SET ACCOUNT_ENTRY_EXPIRES = sysdate + :accountEntryExpires + "
				+ ", LAST_MODIFIED_BY= :last_modified_by " + ", SOR_INVARIANT_ID= :sor_invariant_id " + " WHERE "
				+ "IDENTIFICATION_TYPE = :identification_type " + " AND ACCOUNT_ID = :account_id ";
		
		Session hibSession = getSession();
		
		try {
			if (isSaveSecurityCode) { 
				
				// indicates that the call is from MPSTMS_SecurityCode saveSecurityCode Method
				// for updating the account_entry_expires field in SECURITYACCOUNT table.

				if (sor_invariant_id == null || sor_invariant_id.trim().length() == 0) {

					logger.info("{}{}DBUSAI_0a : theSql = {}",sClassName,sMethodName, setAccountExpirySql);
					logger.info("{}{}DBUSA_0b : account_entry_expires = {}",sClassName,sMethodName,  securityCodeExpirationTime);
					objectList.add(last_modified_by);
					logger.info("{}{}DBUSAI_01 : last_modified_by PARAM 1 = {}",sClassName,sMethodName, last_modified_by);
					objectList.add(identification_type);
					logger.info("{}{}DBUSAI_02 : identification_type PARAM 2 = {}",sClassName,sMethodName, identification_type);
					objectList.add(account_id);
					logger.info("{}{}DBUSAI_03 : account_id PARAM 3 = {}",sClassName,sMethodName,account_id);

					rowCount = hibSession.createNativeQuery(setAccountExpirySql)
										.setParameter("accountEntryExpires",
												DateUtil.getsecurityCodeExpiryTime(securityCodeExpirationTime,
													(String) InpParam.get(ProfileOrchestrationConstants.EXPIRY_TIME_UNIT)))
										 .setParameter("last_modified_by", last_modified_by)
										 .setParameter("identification_type",(StringUtils.isNoneBlank(identification_type) ? (identification_type.toUpperCase()).trim() : null))
										.setParameter("account_id", (StringUtils.isNoneBlank(account_id) ? (account_id.toLowerCase()).trim() : null))
										.executeUpdate();

				} else {
					logger.debug("{}{}DBUSAI_0a : theSql = {}",sClassName,sMethodName, setAccountExpirySorInvariantIdSql);
					logger.debug("{}{}DBUSAI_0b : account_entry_expires = {}",sClassName,sMethodName, securityCodeExpirationTime);

					logger.debug("{}{}DBUSAI_01 : last_modified_by PARAM 1 = {}",sClassName,sMethodName, last_modified_by);
					logger.debug("{}{}DBUSAI_02 : sor_invariant_id PARAM 2 = {}" ,sClassName,sMethodName, sor_invariant_id);
					logger.debug("{}{}DBUSAI_03 : identification_type PARAM 3 = {}",sClassName,sMethodName, identification_type);
					logger.debug("{}{}DBUSAI_04 : account_id PARAM 4 = {}" ,sClassName,sMethodName, account_id);

					rowCount = hibSession.createNativeQuery(setAccountExpirySorInvariantIdSql)
										 .setParameter("accountEntryExpires",
												 DateUtil.getsecurityCodeExpiryTime(securityCodeExpirationTime,
														 (String) InpParam.get(ProfileOrchestrationConstants.EXPIRY_TIME_UNIT)))
										 .setParameter("last_modified_by", last_modified_by)
										 .setParameter("sor_invariant_id",(StringUtils.isNotBlank(sor_invariant_id) ? sor_invariant_id : null))
										 .setParameter("identification_type",(StringUtils.isNoneBlank(identification_type)
												 							 ? (identification_type.toUpperCase()).trim()
												 							 : null))
										 .setParameter("account_id", (StringUtils.isNoneBlank(account_id) ? (account_id.toLowerCase()).trim() : null))
										 .executeUpdate();
				}

			} else { 
				
				// indicates that the call is to update the cumulative_failure_count in
				// SECURITYACCOUNT table.

				logger.debug("{}{}DBUSAI_0a : theSql = {}",sClassName,sMethodName,  setCumulativeCountSql);

				objectList.add(last_modified_by);
				logger.debug("{}{}DBUSAI_01 : last_modified_by PARAM 1 = {}",sClassName,sMethodName, last_modified_by);

				objectList.add(identification_type);
				logger.debug("{}{}DBUSAI_02 : identification_type PARAM 2 = {}" ,sClassName,sMethodName, identification_type);

				objectList.add(account_id);
				logger.debug("{}{}DBUSAI_03 : account_id PARAM 3 = {}" ,sClassName,sMethodName, account_id);

				rowCount = hibSession.createNativeQuery(setCumulativeCountSql)
									 .setParameter("cumulativeFailureCount", cumulativeFailureCount+1)
									 .setParameter("last_modified_by", last_modified_by)									 
									 .setParameter("identification_type",(StringUtils.isNoneBlank(identification_type)
											 							 ? (identification_type.toUpperCase()).trim()
											 							 : null))
									 .setParameter("account_id", (StringUtils.isNoneBlank(account_id) ? (account_id.toLowerCase()).trim() : null))
									 .executeUpdate();
			}

			logger.debug("{}{}DBUSAI_10 :  identification_type  = {}" ,sClassName,sMethodName, identification_type);
			logger.debug("{}{}DBUSAI_11 : account_id = {}" ,sClassName,sMethodName, account_id);

			logger.info("{}{}DBUSAI_15 : rowCount = {}" ,sClassName,sMethodName, rowCount);
		} catch (Exception e) {
			//resultHash = StatusMsg.makeExceptionSQLStatus(e);
			logger.error("{}{}DBUSAE01 :  Error:: {}",sClassName,sMethodName,e.getMessage());
			logger.error("{}{}DBUSAE02 : Exception = {}",sClassName,sMethodName ,e);
			throw e;
		} finally {
			logger.info("{}{}DBTOOLS999 : total row count : {}" ,sClassName,sMethodName, rowCount);
		}
		return rowCount;
	}
}