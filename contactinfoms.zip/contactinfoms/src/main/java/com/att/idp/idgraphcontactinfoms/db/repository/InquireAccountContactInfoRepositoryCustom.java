package com.att.idp.idgraphcontactinfoms.db.repository;

import java.util.HashMap;

/**
 * This is the InquireAccountContactInfoRepositoryCustom interface.
 *
 * It is used to declare custom repository methods for the InquireAccountContactInfo entity.
 * These methods are not provided by the JpaRepository and need to be implemented manually.
 *
 * The methods declared in this interface can be used to perform complex queries or database operations that are not supported by the standard JpaRepository methods.
 *
 * The interface declares a method inquireAccountContactInfo() that takes a HashMap as an argument and returns a HashMap.
 * This method can be used to inquire account contact information.
 */
public interface InquireAccountContactInfoRepositoryCustom {

	/**
	 * This method is used to inquire account contact information.
	 *
	 * It takes a HashMap as an input parameter, which represents the database HashMap.
	 * The HashMap contains key-value pairs where the key is the account ID and the value is the contact information.
	 *
	 * The method performs a query on the database using the provided HashMap and returns a HashMap with the queried account contact information.
	 *
	 * @param hmDbHashMap a HashMap representing the database HashMap.
	 * @return a HashMap with the queried account contact information.
	 */
	HashMap inquireAccountContactInfo(HashMap hmDbHashMap);

}
