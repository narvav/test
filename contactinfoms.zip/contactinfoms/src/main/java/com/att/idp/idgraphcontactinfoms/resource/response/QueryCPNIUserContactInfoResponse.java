package com.att.idp.idgraphcontactinfoms.resource.response;

import java.util.ArrayList;
import com.att.idp.core.exception.ServiceError;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.response package.
 *
 * The QueryCPNIUserContactInfoResponse class is used to represent the response from a Query CPNI User Contact Info operation.
 * It contains several fields, each of which represents a different attribute of the response.
 * These fields include transactionName, appStatusMsg, appStatusCode, appInfo, appCategoryCode, errors, accountContactList, userContactList, userCBRList, accountCBRList, and idpTraceId.
 *
 * The transactionName field represents the name of the transaction.
 * The appStatusMsg field represents the status message of the application.
 * The appStatusCode field represents the status code of the application.
 * The appInfo field represents the information of the application.
 * The appCategoryCode field represents the category code of the application.
 * The errors field is an object of the ServiceError class, representing any errors that occurred during the operation.
 * The accountContactList field is an ArrayList of AccountContactList objects, representing the list of account contacts.
 * The userContactList field is an ArrayList of UserContactList objects, representing the list of user contacts.
 * The userCBRList field is an ArrayList of UserCBRList objects, representing the list of user CBRs.
 * The accountCBRList field is an ArrayList of AccountCBRList objects, representing the list of account CBRs.
 * The idpTraceId field represents the trace ID of the IDP.
 *
 * Each field has a corresponding getter and setter method, allowing the fields to be accessed and modified.
 * The setter methods for errors, accountContactList, userContactList, userCBRList, accountCBRList, and idpTraceId are annotated with @JsonProperty, indicating the JSON property name to be used during serialization and deserialization.
 *
 * The class is annotated with @JsonIgnoreProperties and @JsonInclude, which control the JSON serialization and deserialization behavior.
 * The @JsonIgnoreProperties annotation indicates that any unknown properties encountered during JSON processing should be ignored.
 * The @JsonInclude annotation indicates that only non-null properties should be included in the JSON.
 *
 * The class is also annotated with @ApiModel, which provides additional metadata for the Swagger documentation.
 *
 * The class overrides the toString method, providing a custom string representation of the object using reflection and JSON style.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(name = "QueryCPNIUserContactInfoResponse")
public class QueryCPNIUserContactInfoResponse {

	@JsonIgnore
	protected final String transactionName = "QueryCPNIUserContactInfo";
	private String appStatusMsg;
	private String appStatusCode;
	private String appInfo;
	@JsonIgnore
	private String appCategoryCode;
	private ServiceError errors;
	private ArrayList<AccountContactList> accountContactList;
	private ArrayList<UserContactList> userContactList;
	private ArrayList<UserCBRList> userCBRList;
	private ArrayList<AccountCBRList> accountCBRList;
	private String idpTraceId;

	@JsonProperty("error")
	public void setErrors(ServiceError errors) {
		this.errors = errors;
	}

	@JsonProperty("AccountContactList")
	public void setAccountContactList(ArrayList<AccountContactList> accountContactList) {
		this.accountContactList = accountContactList;
	}

	@JsonProperty("idp-trace-id")
	public void setIdpTraceId(String idpTraceId) {
		this.idpTraceId = idpTraceId;
	}
}