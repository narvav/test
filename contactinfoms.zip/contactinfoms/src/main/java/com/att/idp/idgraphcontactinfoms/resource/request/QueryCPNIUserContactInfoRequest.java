package com.att.idp.idgraphcontactinfoms.resource.request;

import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.request package.
 *
 * The QueryCPNIUserContactInfoRequest class is used to represent a request to query CPNI user contact information.
 * It contains several fields, each of which represents a parameter of the request.
 * These fields include transactionName, callingSystemId, userId, domain, guid, returnCBRCTNs, isExternalCall, idpTraceId, and unknownAttributes.
 *
 * Each field is annotated with @Size, indicating that they have size constraints.
 * The messages associated with these annotations provide additional information about the requirements for each field.
 *
 * The class provides a map of unknownAttributes, which can be used to store any additional attributes that are not part of the other fields.
 * The unknownAttributes map is annotated with @JsonAnySetter and @JsonAnyGetter, allowing it to be included in JSON serialization and deserialization.
 */
@Schema(name = "queryCPNIUserContactInfoRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class QueryCPNIUserContactInfoRequest {
	
	protected final String transactionName="QueryCPNIUserContactInfo";
    
    @Size(min=1, max=20,message="CallingSystemId length is invalid|QueryCPNIUserContactInfo")
    protected String callingSystemId;
    
    @Size(min=1, max=127,message="handle length is invalid|QueryCPNIUserContactInfo")
    protected String userId;

    protected String domain="slid.dum";
    
    @Size(min=1,max=12,message="guid length is invalid|QueryCPNIUserContactInfo") 
    protected String guid;
    
    @Size(min=1,max=1,message="returnCBRCTNs value can only be Y or N|QueryCPNIUserContactInfo") 
	protected String returnCBRCTNs;
    
    protected String isExternalCall;

    @Schema(name = "idpTraceId")
    private String idpTraceId;

    /**
     * This field represents a map of unknown attributes.
     *
     * The unknownAttributes map is used to store any additional attributes that are not part of the attributeName and attributeValue fields.
     * It is initialized as a new HashMap.
     *
     * The field is annotated with @JsonAnySetter and @JsonAnyGetter, allowing it to be included in JSON serialization and deserialization.
     */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();

	}
