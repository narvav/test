package com.att.idp.idgraphcontactinfoms.helpers.voltage;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This is the ProcessVoltageHelper class.
 * It is a utility class that provides methods to encrypt and decrypt values using the Voltage security framework.
 * It contains methods to interact with the Voltage API and handle any exceptions that may occur during the encryption and decryption process.
 * It is annotated as a Spring Component, indicating that an instance of this class will be created and managed by the Spring framework.
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class ProcessVoltageHelper {

	@Value("${GET_MEMBER_SPI}")
	private String propGetMemberSPI;

	@Value("${PUT_MEMBER_SPI}")
	private String propPutMemberSPI;

	private static final String info = "@(#) RcsModuleId = $Id: ProcessVoltageHelper.java 78646 2018-03-01 14:52:58Z dp609j $ $HeadURL: svn://scm.it.att.com:14056/mps/trunk/tools/mpsrules/com/att/mps/mpsrules/ProcessVoltageHelper.java $";
	public static final Logger logger = LoggerFactory.getLogger(ProcessVoltageHelper.class);
	@Autowired
	private VoltageEncryptionHelper oVoltageEncryption_H;

	/**
	 * This method is part of the ProcessVoltageHelper class.
	 * It takes a HashMap containing member information as input, and returns a HashMap containing the response.
	 * The method interacts with the Voltage API to decrypt specific fields in the input HashMap, and handles any exceptions that may occur during the decryption process.
	 * It logs any errors that occur during the decryption process.
	 * The method returns a HashMap which contains the response from the Voltage API, or an error map if an exception occurs.
	 *
	 * @param hmMemberInfo A HashMap containing member information to be decrypted.
	 * @return A HashMap containing the response from the Voltage API, or an error map if an exception occurs.
	 */
	public HashMap voltageDecryptSPIFields(HashMap hmMemberInfo) {
		HashMap hmResponse = null;
		String sAppInfo = null;
		String sAppStatusCode = null;
		Date dtStart = new Date();

		logger.info("HLP_DEC_1 : " + "CVS KEYWORDS:" + info);
		logger.info("HLP000 : " + "Input Params = " + StringUtils.normalizeSpace(String.valueOf(hmMemberInfo)));
		try {
			if (hmMemberInfo == null || hmMemberInfo.isEmpty()) {
				sAppInfo = "hmMemberInfo is null or empty.";
				logger.info("HLP_DEC_3 : " + sAppInfo);
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
				return hmResponse;
			}

			String sMd5PasswordVenc = (String) hmMemberInfo.get(MPSDefs.DB_MD5_PASSWORD_VENC);
			String sEncPasswordVenc = (String) hmMemberInfo.get(MPSDefs.DB_ENC_PASSWORD_VENC);
			String sSha1PasswordVenc = (String) hmMemberInfo.get(MPSDefs.DB_SHA1_PASSWORD_VENC);
			String sGenericPasswordVenc = (String) hmMemberInfo.get(MPSDefs.DB_GEN_PASSWORD_VENC);
			String sDes3PasswordVenc = (String) hmMemberInfo.get(MPSDefs.DB_DES3_PASSWORD_VENC);
			String sSshaPasswordVenc = (String) hmMemberInfo.get(MPSDefs.DB_SSHA_PASSWORD_VENC);
			String sSecurityAnswer1Venc = (String) hmMemberInfo.get(MPSDefs.DB_SECURITY_ANSWER_1_VENC);
			String sSecurityAnswer2Venc = (String) hmMemberInfo.get(MPSDefs.DB_SECURITY_ANSWER_2_VENC);
			String sPasswordVenc = (String) hmMemberInfo.get(MPSDefs.DB_PASSWORD_VENC);

			HashMap hmDecrypt = new HashMap();

			if (sPasswordVenc != null && !sPasswordVenc.isEmpty()) {
				hmDecrypt.put(MPSDefs.DB_PASSWORD_VENC, sPasswordVenc);
			}

			if (sMd5PasswordVenc != null && !sMd5PasswordVenc.isEmpty()) {
				hmDecrypt.put(MPSDefs.DB_MD5_PASSWORD_VENC, sMd5PasswordVenc);
			}

			if (sEncPasswordVenc != null && !sEncPasswordVenc.isEmpty()) {
				hmDecrypt.put(MPSDefs.DB_ENC_PASSWORD_VENC, sEncPasswordVenc);

			}

			if (sSha1PasswordVenc != null && !sSha1PasswordVenc.isEmpty()) {
				hmDecrypt.put(MPSDefs.DB_SHA1_PASSWORD_VENC, sSha1PasswordVenc);
			}

//			2103 - SSHA-256 encryption changes
			if (sGenericPasswordVenc != null && !sGenericPasswordVenc.isEmpty()) {
				hmDecrypt.put(MPSDefs.DB_GEN_PASSWORD_VENC, sGenericPasswordVenc);
			}

			if (sDes3PasswordVenc != null && !sDes3PasswordVenc.isEmpty()) {
				hmDecrypt.put(MPSDefs.DB_DES3_PASSWORD_VENC, sDes3PasswordVenc);
			}

			if (sSshaPasswordVenc != null && !sSshaPasswordVenc.isEmpty()) {
				hmDecrypt.put(MPSDefs.DB_SSHA_PASSWORD_VENC, sSshaPasswordVenc);
			}

			if (sSecurityAnswer1Venc != null && !sSecurityAnswer1Venc.isEmpty()) {
				hmDecrypt.put(MPSDefs.DB_SECURITY_ANSWER_1_VENC, sSecurityAnswer1Venc);
			}

			if (sSecurityAnswer2Venc != null && !sSecurityAnswer2Venc.isEmpty()) {
				hmDecrypt.put(MPSDefs.DB_SECURITY_ANSWER_2_VENC, sSecurityAnswer2Venc);
			}

			// calling VoltageEncryption_H for decryption
			logger.debug("HLP_DEC_11 : " + "Input to VoltageEncryption_H.getEFPEDecryptedValues() : " + hmDecrypt);

			hmResponse = oVoltageEncryption_H.getEFPEDecryptedValues(hmDecrypt);

			logger.debug(SpiMarker.getInstance(),
					"ProcessVoltageHelper.voltageDecryptSPIFields.HLP_DEC_12 : Response from VoltageEncryption_H.getEFPEDecryptedValues() : ",
					StructuredArguments.entries(hmResponse));

			if (hmResponse == null || hmResponse.isEmpty()) {
				sAppInfo = "VoltageEncryption_H.getEFPEDecryptedValues() Response  is null";
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				logger.error("HLP_DEC_13 : " + sAppInfo);
				return hmResponse;
			}

			sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
			if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
				sAppInfo = (String) hmResponse.get(CErrorDefs.COMMON_APP_INFO);
				logger.error("HLP_DEC_14 : " + sAppInfo);
				return hmResponse;
			}

			String sMd5DecValue = (String) hmResponse.get(MPSDefs.DB_MD5_PASSWORD_VENC);
			String sEncDecValue = (String) hmResponse.get(MPSDefs.DB_ENC_PASSWORD_VENC);
			String sSha1DecValue = (String) hmResponse.get(MPSDefs.DB_SHA1_PASSWORD_VENC);
			String sGenericDecValue = (String) hmResponse.get(MPSDefs.DB_GEN_PASSWORD_VENC);
			String sDes3DecValue = (String) hmResponse.get(MPSDefs.DB_DES3_PASSWORD_VENC);
			String sSshaDecValue = (String) hmResponse.get(MPSDefs.DB_SSHA_PASSWORD_VENC);
			String sSecAns1DecValue = (String) hmResponse.get(MPSDefs.DB_SECURITY_ANSWER_1_VENC);
			String sSecAns2DecValue = (String) hmResponse.get(MPSDefs.DB_SECURITY_ANSWER_2_VENC);
			String sPasswordDecValue = (String) hmResponse.get(MPSDefs.DB_PASSWORD_VENC);

			propGetMemberSPI = (propGetMemberSPI == null || propGetMemberSPI.isEmpty()) ? CommonDefs.DEFAULT_NO
					: propGetMemberSPI;

			// 1612- For Testing Purpose only
			String sMemberInfoSPI = (String) hmMemberInfo.get(MPSDefs.PROP_GET_MEMBER_SPI);
			if (sMemberInfoSPI != null && !sMemberInfoSPI.isEmpty()) {
				propGetMemberSPI = sMemberInfoSPI.toUpperCase();
			} // END

			logger.info("HLP_DEC_14.1 : " + "PROP_GET_MEMBER_SPI : " + propGetMemberSPI);

			// if PROP_GET_MEMBER_SPI is null or N, then put decrypted values into
			// hmMemberInfo hashmap to return, else if Y then do not return SPI decrypted
			// values
			if (propGetMemberSPI.equals("N")) {

				if (sMd5DecValue != null && !sMd5DecValue.isEmpty()) {
					hmMemberInfo.put(MPSDefs.DB_MD5_PASSWORD, sMd5DecValue);
				}

				if (sEncDecValue != null && !sEncDecValue.isEmpty()) {
					hmMemberInfo.put(MPSDefs.DB_ENC_PASSWORD, sEncDecValue);
				}

				if (sSha1DecValue != null && !sSha1DecValue.isEmpty()) {
					hmMemberInfo.put(MPSDefs.DB_SHA1_PASSWORD, sSha1DecValue);
				}

//				2103 - SSHA-256 encryption changes
				if (sGenericDecValue != null && !sGenericDecValue.isEmpty()) {
					hmMemberInfo.put(MPSDefs.DB_GEN_PASSWORD, sGenericDecValue);
				}

				if (sDes3DecValue != null && !sDes3DecValue.isEmpty()) {
					hmMemberInfo.put(MPSDefs.DB_DES3_PASSWORD, sDes3DecValue);
				}

				if (sSshaDecValue != null && !sSshaDecValue.isEmpty()) {
					hmMemberInfo.put(MPSDefs.DB_SSHA_PASSWORD, sSshaDecValue);
				}

				if (sSecAns1DecValue != null && !sSecAns1DecValue.isEmpty()) {
					hmMemberInfo.put(MPSDefs.DB_SECURITY_ANSWER_1, sSecAns1DecValue);
				}

				if (sSecAns2DecValue != null && !sSecAns2DecValue.isEmpty()) {
					hmMemberInfo.put(MPSDefs.DB_SECURITY_ANSWER_2, sSecAns2DecValue);
				}

				if (sPasswordDecValue != null && !sPasswordDecValue.isEmpty()) {
					hmMemberInfo.put(MPSDefs.DB_PASSWORD, sPasswordDecValue);
				}
			}

			// remove all venc keys from hmMemberInfo
			hmMemberInfo.remove(MPSDefs.DB_MD5_PASSWORD_VENC);
			hmMemberInfo.remove(MPSDefs.DB_ENC_PASSWORD_VENC);
			hmMemberInfo.remove(MPSDefs.DB_SHA1_PASSWORD_VENC);
//			2103 -  SSHA-256 encryption changes
			hmMemberInfo.remove(MPSDefs.DB_GEN_PASSWORD_VENC);
			hmMemberInfo.remove(MPSDefs.DB_DES3_PASSWORD_VENC);
			hmMemberInfo.remove(MPSDefs.DB_SSHA_PASSWORD_VENC);
			hmMemberInfo.remove(MPSDefs.DB_SECURITY_ANSWER_1_VENC);
			hmMemberInfo.remove(MPSDefs.DB_SECURITY_ANSWER_2_VENC);
			hmMemberInfo.remove(MPSDefs.DB_PASSWORD_VENC);

			logger.debug(SpiMarker.getInstance(),
					"ProcessVoltageHelper.voltageDecryptSPIFields.HLP_DEC_15 : Updated hmMemberInfo : ",
					StructuredArguments.entries(hmMemberInfo));

			hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

		} catch (Exception exp) {
			hmResponse = CommonErrorMap.makeExceptionMap(exp, logger);
			sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
			logger.debug("HLP_DEC_16 : " + "error hash map = " + hmResponse);

		} finally {
			if (hmResponse == null || hmResponse.isEmpty()) {
				sAppInfo = "Response Map is NULL or EMPTY";
				logger.error("HLP_DEC_19 : " + sAppInfo);
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
			}

			sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
			if (sAppStatusCode != null && !sAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				sAppInfo = (String) hmResponse.get(CErrorDefs.COMMON_APP_INFO);
				logger.info("HLP_DEC_20 : " + sAppInfo);
			}

			logger.info("HLP999  :  " + dtStart.getTime() + " hmResponse : " + hmResponse);
		}

		return hmResponse;
	}

	/**
	 * This method is part of the ProcessVoltageHelper class.
	 * It takes a HashMap containing member information as input, and returns a HashMap containing the response.
	 * The method interacts with the Voltage API to encrypt specific fields in the input HashMap, and handles any exceptions that may occur during the encryption process.
	 * It logs any errors that occur during the encryption process.
	 * The method returns a HashMap which contains the response from the Voltage API, or an error map if an exception occurs.
	 *
	 * @param hmMemberInfo A HashMap containing member information to be encrypted.
	 * @return A HashMap containing the response from the Voltage API, or an error map if an exception occurs.
	 */
	public HashMap voltageEncryptSPIFields(HashMap hmMemberInfo) {
		HashMap hmResponse = null;
		String sAppInfo = null;
		String sAppStatusCode = null;
		DateFormat dtFormat = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss");
		Date dtStart = new Date();
		String sStartDate = dtFormat.format(dtStart);

		logger.info("HLP_ENC_2 : " + "Start time in HLP = " + sStartDate);
		logger.info(SpiMarker.getInstance(), "ProcessVoltageHelper.voltageEncryptSPIFields.HLP000 :Input Params = ",
				StructuredArguments.entries(hmMemberInfo));

		try {
			if (hmMemberInfo == null || hmMemberInfo.isEmpty()) {
				sAppInfo = "hmMemberInfo is null or empty.";
				logger.info("HLP_ENC_3 : " + sAppInfo);
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, sAppInfo);
				return hmResponse;
			}

			String sMd5Password = (String) hmMemberInfo.get(MPSDefs.DB_MD5_PASSWORD);
			String sEncPassword = (String) hmMemberInfo.get(MPSDefs.DB_ENC_PASSWORD);
			String sSha1Password = (String) hmMemberInfo.get(MPSDefs.DB_SHA1_PASSWORD);
			String genericPassword = (String) hmMemberInfo.get(MPSDefs.DB_GEN_PASSWORD);
			String sDes3Password = (String) hmMemberInfo.get(MPSDefs.DB_DES3_PASSWORD);
			String sSshaPassword = (String) hmMemberInfo.get(MPSDefs.DB_SSHA_PASSWORD);
			String sSecurityAnswer1 = (String) hmMemberInfo.get(MPSDefs.DB_SECURITY_ANSWER_1);
			String sSecurityAnswer2 = (String) hmMemberInfo.get(MPSDefs.DB_SECURITY_ANSWER_2);

			HashMap hmEncrypt = new HashMap();

			propPutMemberSPI = (propPutMemberSPI == null || propPutMemberSPI.isEmpty()) ? CommonDefs.DEFAULT_NO
					: propPutMemberSPI;

			logger.info("HLP_ENC_4 : " + "PROP_PUT_MEMBER_SPI : " + propPutMemberSPI);

			// if PROP_PUT_MEMBER_SPI is null or N, then null out fields in hmMemberInfo

			if (sMd5Password != null && !sMd5Password.isEmpty()) {
				hmEncrypt.put(MPSDefs.DB_MD5_PASSWORD_VENC, sMd5Password);

				if (propPutMemberSPI.equals("N")) {
					sMd5Password = null;
					hmMemberInfo.put(MPSDefs.DB_MD5_PASSWORD, sMd5Password);
				}
			}

			if (sEncPassword != null && !sEncPassword.isEmpty()) {
				hmEncrypt.put(MPSDefs.DB_ENC_PASSWORD_VENC, sEncPassword);
				if (propPutMemberSPI.equals("N")) {
					sEncPassword = null;
					hmMemberInfo.put(MPSDefs.DB_ENC_PASSWORD, sEncPassword);
				}

			}

			if (sSha1Password != null && !sSha1Password.isEmpty()) {
				hmEncrypt.put(MPSDefs.DB_SHA1_PASSWORD_VENC, sSha1Password);
				if (propPutMemberSPI.equals("N")) {
					sSha1Password = null;
					hmMemberInfo.put(MPSDefs.DB_SHA1_PASSWORD, sSha1Password);
				}

			}

//			2103 - SSHA-256 encryption changes
			if (genericPassword != null && !genericPassword.isEmpty()) {
				hmEncrypt.put(MPSDefs.DB_GEN_PASSWORD_VENC, genericPassword);
				if (propPutMemberSPI.equals("N")) {
					genericPassword = null;
					hmMemberInfo.put(MPSDefs.DB_GEN_PASSWORD, genericPassword);
				}

			}

			if (sDes3Password != null && !sDes3Password.isEmpty()) {
				hmEncrypt.put(MPSDefs.DB_DES3_PASSWORD_VENC, sDes3Password);
				if (propPutMemberSPI.equals("N")) {
					sDes3Password = null;
					hmMemberInfo.put(MPSDefs.DB_DES3_PASSWORD, sDes3Password);
				}

			}

			if (sSshaPassword != null && !sSshaPassword.isEmpty()) {
				hmEncrypt.put(MPSDefs.DB_SSHA_PASSWORD_VENC, sSshaPassword);
				if (propPutMemberSPI.equals("N")) {
					sSshaPassword = null;
					hmMemberInfo.put(MPSDefs.DB_SSHA_PASSWORD, sSshaPassword);
				}

			}

			if (sSecurityAnswer1 != null && !sSecurityAnswer1.isEmpty()) {
				hmEncrypt.put(MPSDefs.DB_SECURITY_ANSWER_1_VENC, sSecurityAnswer1);
				if (propPutMemberSPI.equals("N")) {
					sSecurityAnswer1 = null;
					hmMemberInfo.put(MPSDefs.DB_SECURITY_ANSWER_1, sSecurityAnswer1);
				}

			}

			if (sSecurityAnswer2 != null && !sSecurityAnswer2.isEmpty()) {
				hmEncrypt.put(MPSDefs.DB_SECURITY_ANSWER_2_VENC, sSecurityAnswer2);
				if (propPutMemberSPI.equals("N")) {
					sSecurityAnswer2 = null;
					hmMemberInfo.put(MPSDefs.DB_SECURITY_ANSWER_2, sSecurityAnswer2);
				}

			}

			// calling VoltageEncryption_H for encryption
			// logger.debug("HLP_ENC_11 : "+"Input to
			// VoltageEncryption_H.getEFPEEncryptedValues() : " + hmEncrypt);

			hmResponse = oVoltageEncryption_H.getEFPEEncryptedValues(hmEncrypt);

			// logger.debug("HLP_ENC_12 : "+"Response from
			// VoltageEncryption_H.getEFPEEncryptedValues() : " + hmResponse);

			if (hmResponse == null || hmResponse.isEmpty()) {
				sAppInfo = "VoltageEncryption_H.getEFPEEncryptedValues() Response  is null";
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				logger.error("HLP_ENC_13 : " + sAppInfo);
				return hmResponse;
			}

			sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
			if (sAppStatusCode != null && !sAppStatusCode.equals(CErrorDefs.COMMON_SUCCESS)) {
				sAppInfo = (String) hmResponse.get(CErrorDefs.COMMON_APP_INFO);
				logger.error("HLP_ENC_14 : " + sAppInfo);
				return hmResponse;
			}

			String sMd5EncValue = (String) hmResponse.get("voltage_" + MPSDefs.DB_MD5_PASSWORD_VENC);
			String sEncEncValue = (String) hmResponse.get("voltage_" + MPSDefs.DB_ENC_PASSWORD_VENC);
			String sSha1EncValue = (String) hmResponse.get("voltage_" + MPSDefs.DB_SHA1_PASSWORD_VENC);
			String sGenericEncValue = (String) hmResponse.get("voltage_" + MPSDefs.DB_GEN_PASSWORD_VENC);
			String sDes3EncValue = (String) hmResponse.get("voltage_" + MPSDefs.DB_DES3_PASSWORD_VENC);
			String sSshaEncValue = (String) hmResponse.get("voltage_" + MPSDefs.DB_SSHA_PASSWORD_VENC);
			String sSecAns1EncValue = (String) hmResponse.get("voltage_" + MPSDefs.DB_SECURITY_ANSWER_1_VENC);
			String sSecAns2EncValue = (String) hmResponse.get("voltage_" + MPSDefs.DB_SECURITY_ANSWER_2_VENC);

			if (sMd5EncValue != null && !sMd5EncValue.isEmpty()) {
				hmMemberInfo.put(MPSDefs.DB_MD5_PASSWORD_VENC, sMd5EncValue);
			} else if (hmMemberInfo.containsKey(MPSDefs.DB_MD5_PASSWORD)) {
				hmMemberInfo.put(MPSDefs.DB_MD5_PASSWORD_VENC, null);
			}

			if (sEncEncValue != null && !sEncEncValue.isEmpty()) {
				hmMemberInfo.put(MPSDefs.DB_ENC_PASSWORD_VENC, sEncEncValue);
			} else if (hmMemberInfo.containsKey(MPSDefs.DB_ENC_PASSWORD)) {
				hmMemberInfo.put(MPSDefs.DB_ENC_PASSWORD_VENC, null);
			}

			if (sSha1EncValue != null && !sSha1EncValue.isEmpty()) {
				hmMemberInfo.put(MPSDefs.DB_SHA1_PASSWORD_VENC, sSha1EncValue);
			} else if (hmMemberInfo.containsKey(MPSDefs.DB_SHA1_PASSWORD)) {
				hmMemberInfo.put(MPSDefs.DB_SHA1_PASSWORD_VENC, null);
			}

//			2103 - SSHA-256 encryption changes
			if (sGenericEncValue != null && !sGenericEncValue.isEmpty()) {
				hmMemberInfo.put(MPSDefs.DB_GEN_PASSWORD_VENC, sGenericEncValue);
			} else if (hmMemberInfo.containsKey(MPSDefs.DB_GEN_PASSWORD)) {
				hmMemberInfo.put(MPSDefs.DB_GEN_PASSWORD_VENC, null);
			}

			if (sDes3EncValue != null && !sDes3EncValue.isEmpty()) {
				hmMemberInfo.put(MPSDefs.DB_DES3_PASSWORD_VENC, sDes3EncValue);
			} else if (hmMemberInfo.containsKey(MPSDefs.DB_DES3_PASSWORD)) {
				hmMemberInfo.put(MPSDefs.DB_DES3_PASSWORD_VENC, null);
			}

			if (sSshaEncValue != null && !sSshaEncValue.isEmpty()) {
				hmMemberInfo.put(MPSDefs.DB_SSHA_PASSWORD_VENC, sSshaEncValue);
			} else if (hmMemberInfo.containsKey(MPSDefs.DB_SSHA_PASSWORD)) {
				hmMemberInfo.put(MPSDefs.DB_SSHA_PASSWORD_VENC, null);
			}

			if (sSecAns1EncValue != null && !sSecAns1EncValue.isEmpty()) {
				hmMemberInfo.put(MPSDefs.DB_SECURITY_ANSWER_1_VENC, sSecAns1EncValue);
			} else if (hmMemberInfo.containsKey(MPSDefs.DB_SECURITY_ANSWER_1)) {
				hmMemberInfo.put(MPSDefs.DB_SECURITY_ANSWER_1_VENC, null);
			}

			if (sSecAns2EncValue != null && !sSecAns2EncValue.isEmpty()) {
				hmMemberInfo.put(MPSDefs.DB_SECURITY_ANSWER_2_VENC, sSecAns2EncValue);
			} else if (hmMemberInfo.containsKey(MPSDefs.DB_SECURITY_ANSWER_2)) {
				hmMemberInfo.put(MPSDefs.DB_SECURITY_ANSWER_2_VENC, null);
			}

			logger.info(SpiMarker.getInstance(),
					"ProcessVoltageHelper.voltageEncryptSPIFields.HLP_ENC_15 :Updated hmMemberInfo : ",
					StructuredArguments.entries(hmMemberInfo));

			hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

		} catch (Exception exp) {
			hmResponse = CommonErrorMap.makeExceptionMap(exp, logger);
			sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
			logger.debug("HLP_ENC_16 : " + "error hash map = " + hmResponse);

		} finally {
			if (hmResponse == null || hmResponse.isEmpty()) {
				sAppInfo = "Response Map is NULL or EMPTY";
				logger.error("HLP_ENC_19 : " + sAppInfo);
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
			}

			sAppStatusCode = (String) hmResponse.get(CommonDefs.COMMON_APP_STATUS_CODE);
			if (sAppStatusCode != null && !sAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				sAppInfo = (String) hmResponse.get(CErrorDefs.COMMON_APP_INFO);
				logger.info("HLP_ENC_20 : " + sAppInfo);
			}

			logger.info("HLP999 : " + dtStart.getTime() + " hmResponse : " + hmResponse);
		}

		return hmResponse;
	}
}