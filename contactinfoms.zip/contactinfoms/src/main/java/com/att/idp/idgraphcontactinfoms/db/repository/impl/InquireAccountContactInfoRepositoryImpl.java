package com.att.idp.idgraphcontactinfoms.db.repository.impl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphcontactinfoms.db.model.Tsecurityaccount;
import com.att.idp.idgraphcontactinfoms.db.repository.IDGraphContactInfoCustomRepository;
import com.att.idp.idgraphcontactinfoms.db.repository.InquireAccountContactInfoRepositoryCustom;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * This is the implementation class for the InquireAccountContactInfoRepositoryCustom interface.
 *
 * It extends IDGraphContactInfoCustomRepository, which is a custom repository for IDGraphContactInfo. The IDGraphContactInfoCustomRepository takes two parameters: Tsecurityaccount and Long. Tsecurityaccount is the entity and Long is the type of the entity's primary key.
 *
 * This class is meant to provide the actual implementation of the methods defined in the InquireAccountContactInfoRepositoryCustom interface.
 */
public class InquireAccountContactInfoRepositoryImpl extends IDGraphContactInfoCustomRepository<Tsecurityaccount, Long>
		implements InquireAccountContactInfoRepositoryCustom {

	private static final Logger logger = LoggerFactory.getLogger(InquireAccountContactInfoRepositoryImpl.class);
	private static String sClassName = "InquireAccountContactInfoRepositoryImpl";
	
	private static final String queryServiceContact = "SELECT sr.sor_name,sc.create_date ,sc.last_modified "
			+ ",sc.last_modified_by ,sc.sor_id, sc.sor_invariant_id, sc.contact_type, sc.phone_number,"
			+ " sc.phone_number_ext, sc.phone_number_type, sc.email_address,"
			+ "sc.contact_status, TO_CHAR(sc.date_established, 'MMDDYYYY HH24:mi:ss') AS date_established,"
			+ "sc.validation_status, sc.validation_initiated_date FROM mps_owner.servicecontact sc, mps_owner.SYSTEMOFRECORD sr";
	
	@SuppressWarnings({ "unused", "rawtypes", "unchecked" })
	@Override
	public HashMap inquireAccountContactInfo(HashMap hmDbInput) {

		String sMethodName =  ".inquireAccountContactInfo.";
		HashMap<String, Object> hmResponse = null;

		HashMap<String,Object> hmQueryResponse = null;
		
		ArrayList alAccountInvariantIdList = new ArrayList();
		ArrayList alServiceContactList = new ArrayList();

		String sAppInfo = null;
		logger.info("{}{}DBTOOLS000 :  InpParam = {}",sClassName, sMethodName,hmDbInput);
		
		try {
			int rowCount = 0;
			
			String sAccountInvariantId=(String) hmDbInput.get(CommonDefs.ACCOUNT_INVARIANT_ID); 
			if(sAccountInvariantId != null && !sAccountInvariantId.isEmpty()) {
				alAccountInvariantIdList.add(sAccountInvariantId);
					
			}else {
				alAccountInvariantIdList = (ArrayList) hmDbInput.get("accountInvariantIdList");	
			}
			
			ArrayList sorIdList=(ArrayList) hmDbInput.get("sorIdList");
			
			logger.info("{}{}DBTOOLS01 : Start::InpParam = sAccountInvariantId : {}  sorIdList : {}", sClassName ,sMethodName , HtmlUtils.htmlEscape(String.valueOf(alAccountInvariantIdList)) , HtmlUtils.htmlEscape(String.valueOf(sorIdList)));

			StringBuilder where = new StringBuilder(" WHERE ");
			
			Long initMillis = Long.valueOf(System.currentTimeMillis());
			
			where.append("sc.sor_id IN (:sorIdList)");
			where.append(" and sc.sor_invariant_id IN (:alAccountInvariantIdList)");
			where.append(" and sc.sor_id=sr.sor_id");
			logger.info("{}{}DBTOOLS02 : sContactDetailsQuery = {}", sClassName ,sMethodName , queryServiceContact+where);
			
			List<Object[]> alQueryResponse = getSession().createNativeQuery(queryServiceContact+where)
								  						 .setParameterList("sorIdList", sorIdList)
								  						 .setParameterList("alAccountInvariantIdList", alAccountInvariantIdList)
								  						 .list();

			if (alQueryResponse == null || alQueryResponse.isEmpty()) {
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, CErrorDefs.ERR_REC_NOT_FOUND_MSG);
				logger.info("{}{}DBTOOLS03 : No rows found", sClassName ,sMethodName);
				return hmResponse;
			}
			
			DateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
			SimpleDateFormat dtEst = new SimpleDateFormat("MMddyyyy HH:mm:ss");
			
			for (Object[] oQueryResponse : alQueryResponse) {

				BigDecimal sorId = null;
				String dateEstablished = "";
				String sorName = (String) oQueryResponse[0];
				String createDate = sdf.format(oQueryResponse[1]);
				String lastModified = sdf.format(oQueryResponse[2]);
				String lastModifiedBy = (String) oQueryResponse[3];
				if (oQueryResponse[4] != null) {
					sorId = new BigDecimal(oQueryResponse[4].toString());
				}
				String sorInvariantId = (String) oQueryResponse[5];
				String contactType = (String) oQueryResponse[6];
				String phoneNumber = (String) oQueryResponse[7];
				String phoneNumberExtension = (String) oQueryResponse[8];
				String phoneNumberType = (String) oQueryResponse[9];
				String emailAddress = (String) oQueryResponse[10];
				String contactStatus = String.valueOf(oQueryResponse[11]);
				if(oQueryResponse[12] != null) {
					Date dt = dtEst.parse(oQueryResponse[12].toString());
					dateEstablished = DateFormatUtils.format(dt,"MMddyyyy HH:mm:ss");
				}
				String validationStatus =  String.valueOf(oQueryResponse[13]);
				String validationInitiatedDate = String.valueOf(oQueryResponse[14]);
								
				
				hmQueryResponse = CommonUtil.getHashMap();
				hmQueryResponse.put(MPSDefs.DB_SOR_NAME, sorName);
				hmQueryResponse.put(MPSDefs.DB_CREATE_DATE, createDate);
				hmQueryResponse.put(MPSDefs.DB_LAST_MODIFIED, lastModified);
				hmQueryResponse.put(MPSDefs.DB_LAST_MODIFIED_BY, lastModifiedBy);
				hmQueryResponse.put(MPSDefs.DB_SOR_ID, sorId);
				hmQueryResponse.put(MPSDefs.DB_SOR_INVARIANT_ID, sorInvariantId);
				hmQueryResponse.put(MPSDefs.DB_CONTACT_TYPE, contactType);
				hmQueryResponse.put(MPSDefs.DB_PHONE_NUMBER, phoneNumber);
				hmQueryResponse.put(MPSDefs.DB_PHONE_NUMBER_EXT, phoneNumberExtension);
				hmQueryResponse.put(MPSDefs.DB_PHONE_NUMBER_TYPE, phoneNumberType);
				hmQueryResponse.put(MPSDefs.DB_EMAIL_ADDRESS, emailAddress);
				hmQueryResponse.put(MPSDefs.DB_CONTACT_STATUS, contactStatus);
				hmQueryResponse.put(MPSDefs.DB_DATE_ESTABLISHED, dateEstablished);
				hmQueryResponse.put(MPSDefs.DB_VALIDATION_STATUS, validationStatus);
				hmQueryResponse.put(CommonDefs.VALIDATION_INIT_DATE, validationInitiatedDate);
				alServiceContactList.add(hmQueryResponse);
				++rowCount;
			}
			 
			 if (rowCount == 0) {
				 hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_USER_NOT_FOUND_NUM, "No rows found for InquireAccountContactInfo");
					logger.info("{}{}DBTOOLS04 : No rows found",sClassName,sMethodName);
					return hmResponse;
				}
			 hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "Success");
				if (alServiceContactList != null && alServiceContactList.size() > 0) {
					hmResponse.put(MPSDefs.DB_SERVICE_CONTACTS, alServiceContactList);
				}
		} catch (Exception excp) {
			if (NestedExceptionUtils.getRootCause(excp) instanceof SQLException) {
				hmResponse = CommonErrorMap.makeCategoryMap(MPSDefs.ERR_DB_NUM, excp.getMessage());
			} else {
				hmResponse = CommonErrorMap.makeExceptionMap(excp);
			}
			sAppInfo = (String) hmResponse.get(CErrorDefs.COMMON_APP_INFO);
			if (sAppInfo == null) {
				hmResponse.put(CErrorDefs.COMMON_APP_INFO, excp.getMessage());
			}
		} finally {
			logger.info("{}{}DBHLP999: Resposne to caller = {}", sClassName ,sMethodName , hmResponse);
		}
		
		return hmResponse;
	}


	public boolean dbHealthCheck(){
		boolean isDatabaseUp = false;
		try {
			String selectStatement = "SELECT 1 FROM DUAL";
			List<Object[]> queryResponse = getSession().createNativeQuery(selectStatement).list();
			if (queryResponse != null && !queryResponse.isEmpty()) {
				logger.debug("Performing scheduled db health check - Database is UP");
				isDatabaseUp = true;
			}
		} catch (Exception e) {
			logger.error("DB Health Check failed", e);
		}
		return isDatabaseUp;
	}
}
