package com.att.idp.idgraphcontactinfoms.service;

import jakarta.ws.rs.core.MultivaluedMap;

import com.att.idp.idgraphcontactinfoms.resource.request.QueryCPNIAccountContactInfoRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.QueryCPNIAccountContactInfoResponse;

/**
 * This interface is part of the com.att.idp.idgraphcontactinfoms.service package.
 *
 * The QueryCPNIAccountContactInfoService interface defines a contract for a service that handles the querying of CPNI account contact information.
 * It declares a single method, queryCPNIAccountContactInfo, which takes a QueryCPNIAccountContactInfoRequest and a MultivaluedMap of String to String as input and returns a QueryCPNIAccountContactInfoResponse.
 *
 * The queryCPNIAccountContactInfo method is expected to perform the operation of querying CPNI account contact information, using the QueryCPNIAccountContactInfoRequest as the request body and the MultivaluedMap as the request headers.
 */
public interface QueryCPNIAccountContactInfoService {

	/**
	 * This method is part of the QueryCPNIAccountContactInfoService interface in the com.att.idp.idgraphcontactinfoms.service package.
	 *
	 * The queryCPNIAccountContactInfo method is used to perform the operation of querying CPNI account contact information.
	 * It takes a QueryCPNIAccountContactInfoRequest object and a MultivaluedMap of String to String as input.
	 * The QueryCPNIAccountContactInfoRequest object represents the request body, containing the details required for querying CPNI account contact information.
	 * The MultivaluedMap represents the request headers.
	 *
	 * The method returns a QueryCPNIAccountContactInfoResponse object, which represents the response from the operation of querying CPNI account contact information.
	 */
	QueryCPNIAccountContactInfoResponse queryCPNIAccountContactInfo(QueryCPNIAccountContactInfoRequest queryAccountInfoRequest, MultivaluedMap<String, String> requestHeader);

}