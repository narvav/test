package com.att.idp.idgraphcontactinfoms.service.impl;

import java.util.Map;

import jakarta.ws.rs.core.MultivaluedMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.att.idp.idgraphcontactinfoms.utils.ProfileOrchestrationConstants;
import com.att.idp.idgraphcontactinfoms.exceptions.InvalidInputDataException;
import com.att.idp.idgraphcontactinfoms.helpers.DeletePINHelper;
import com.att.idp.idgraphcontactinfoms.resource.request.DeletePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.DeletePinResponse;
import com.att.idp.idgraphcontactinfoms.service.DeletePINService;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

import net.logstash.logback.argument.StructuredArguments;

/**
 * This class implements the DeletePINService interface and is responsible for handling operations related to deleting a Security PIN.
 *
 * It is annotated with @Service, indicating that it's a Spring Service.
 * The class has a dependency on DeletePINHelper, which is autowired.
 * It also has a Logger instance for logging.
 *
 * The class has one main method: deletePin.
 * This method takes a DeletePINRequest and MultivaluedMap<String, String> as input parameters and returns a DeletePinResponse.
 * The method is responsible for deleting a Security PIN and handling the response.
 *
 * The class is also annotated with @Transactional, indicating that it's a transactional class with a specific transaction manager and rollback rules.
 */
@Service
@Transactional(value = "transactionManager", rollbackFor = InvalidInputDataException.class)
public class DeletePINServiceImpl implements DeletePINService {

	public static final Logger logger = LoggerFactory.getLogger(DeletePINServiceImpl.class);

	private static String sClassName = "DeletePINServiceImpl";
	@Autowired
	private DeletePINHelper deletePinHelper;
	@Override
	public DeletePinResponse deletePin(DeletePINRequest deletePINRequest, MultivaluedMap<String, String> requestHeader) {

		Map<String, Object> hmInput = null;
		Map<String, Object> hmResponse = null;
		String sMethodName = ".deletePin.";

		hmInput = CommonUtilHelper.objectToMap(deletePINRequest);

		logger.info(SpiMarker.getInstance(),"DeletePINServiceImpl.deletePin.DPS_01 : Calling deletePinHelper.deletePin with Input : {}", StructuredArguments.entries(hmInput));

		hmResponse = deletePinHelper.deletePin(hmInput);
		
		logger.info("{}{}DPS_02 : Response from DeletePin Helper : {}", sClassName, sMethodName, hmResponse);

		if (hmResponse ==null || hmResponse.isEmpty()) {
			hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from deletePinHelper.deletePin");
			logger.info("{}{}DPS_03 : Null response from deletePinHelper.deletePin", sClassName, sMethodName);
		} else {
			String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
			if (stAppStatusCode == null) {
				hmResponse = CommonUtilHelper.sysErrorHashMap("Null response from deletePinHelper.deletePin");
				logger.info("{}{}DPS_04 : Null response from deletePinHelper.deletePin", sClassName, sMethodName);
			}
		}

		//hmResponse.put(CommonDefs.TRANSACTION_ID, deletePINRequest.getTransactionId());
		hmResponse.put("idp-trace-id", deletePINRequest.getIdpTraceId());
		hmResponse.put(CommonDefs.TRANSACTION_NAME,ProfileOrchestrationConstants.TRANSACTION_NAME_DELETE_PIN);
		DeletePinResponse deletePinResponse = (DeletePinResponse) CommonUtilHelper.generateCIRResponse(hmResponse);

		String sTxnRollBack = (String) hmResponse.get("isTransactionRollback");

		if (sTxnRollBack != null) {
			throw new InvalidInputDataException(hmResponse);
		}
		logger.info("{}{}DPS_05 : Response from DeletePINServiceImpl.deletePin : {}", sClassName, sMethodName,
				deletePinResponse);
		return deletePinResponse;
	}

}
