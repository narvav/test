package com.att.idp.idgraphcontactinfoms.service.async;

import com.att.idp.idgraphcontactinfoms.model.EventData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * Service for asynchronously publishing OTP events to Oracle sync.
 *
 * This service uses Spring's @Async annotation with the "otpPublishExecutor" to run
 * event publishing on a dedicated thread pool. This avoids blocking the request thread
 * and prevents thread starvation by using a dedicated, tunable executor instead of the
 * global ForkJoinPool common pool.
 *
 * Note: @Async methods must be called from a different Spring bean to work correctly
 * (self-invocation bypasses the proxy). This is why this service is separate from the
 * helper classes.
 */
@Service
public class AsyncOtpEventPublisher {

    private static final Logger logger = LoggerFactory.getLogger(AsyncOtpEventPublisher.class);

    @Autowired
    private OracleSecurityCodeSyncPublisher oracleSecurityCodeSyncPublisher;

    /**
     * Asynchronously publishes a DELETE OTP event for Oracle sync.
     *
     * @param accountId the account identifier
     * @param eventData the event data to publish
     */
    @Async("otpPublishExecutor")
    public void publishDeletePinEvent(String accountId, EventData eventData) {
        try {
            oracleSecurityCodeSyncPublisher.publish(
                    accountId,
                    OracleSecurityCodeSyncPublisher.EVENT_TYPE_DELETE,
                    eventData,
                    "DeletePIN"
            );
        } catch (Exception ex) {
            logger.warn("AsyncOtpEventPublisher: Failed to publish DeletePIN OTP event for AccountId {}: {}",
                    accountId, ex.getMessage());
        }
    }

    /**
     * Asynchronously publishes a ValidatePIN (UPDATE) OTP event for Oracle sync.
     *
     * @param accountId the account identifier
     * @param eventData the event data to publish
     */
    @Async("otpPublishExecutor")
    public void publishValidatePinEvent(String accountId, EventData eventData) {
        try {
            oracleSecurityCodeSyncPublisher.publish(
                    accountId,
                    OracleSecurityCodeSyncPublisher.EVENT_TYPE_UPDATE,
                    eventData,
                    "ValidatePIN"
            );
        } catch (Exception ex) {
            logger.warn("AsyncOtpEventPublisher: Failed to publish ValidatePIN OTP event for AccountId {}: {}",
                    accountId, ex.getMessage());
        }
    }

    /**
     * Asynchronously publishes a GeneratePIN (INSERT or UPDATE) OTP event for Oracle sync.
     *
     * @param accountId the account identifier
     * @param eventType the event type (INSERT or UPDATE)
     * @param eventData the event data to publish
     */
    @Async("otpPublishExecutor")
    public void publishGeneratePinEvent(String accountId, String eventType, EventData eventData) {
        try {
            oracleSecurityCodeSyncPublisher.publish(
                    accountId,
                    eventType,
                    eventData,
                    "generatePin"
            );
        } catch (Exception ex) {
            logger.warn("AsyncOtpEventPublisher: Failed to publish GeneratePIN OTP event for AccountId {}: {}",
                    accountId, ex.getMessage());
        }
    }
}
