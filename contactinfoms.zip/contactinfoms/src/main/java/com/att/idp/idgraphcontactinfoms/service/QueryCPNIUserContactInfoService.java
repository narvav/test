package com.att.idp.idgraphcontactinfoms.service;

import jakarta.ws.rs.core.MultivaluedMap;

import com.att.idp.idgraphcontactinfoms.resource.request.QueryCPNIUserContactInfoRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.QueryCPNIUserContactInfoResponse;

/**
 * This interface is part of the com.att.idp.idgraphcontactinfoms.service package.
 *
 * The QueryCPNIUserContactInfoService interface defines a contract for a service that handles the querying of CPNI user contact information.
 * It declares a single method, queryCPNIUserContactInfo, which takes a QueryCPNIUserContactInfoRequest and a MultivaluedMap of String to String as input and returns a QueryCPNIUserContactInfoResponse.
 *
 * The queryCPNIUserContactInfo method is expected to perform the operation of querying CPNI user contact information, using the QueryCPNIUserContactInfoRequest as the request body and the MultivaluedMap as the request headers.
 */
public interface QueryCPNIUserContactInfoService {

	/**
	 * This method is part of the QueryCPNIUserContactInfoService interface in the com.att.idp.idgraphcontactinfoms.service package.
	 *
	 * The queryCPNIUserContactInfo method is used to perform the operation of querying CPNI user contact information.
	 * It takes a QueryCPNIUserContactInfoRequest object and a MultivaluedMap of String to String as input.
	 * The QueryCPNIUserContactInfoRequest object represents the request body, containing the details required for querying CPNI user contact information.
	 * The MultivaluedMap represents the request headers.
	 *
	 * The method returns a QueryCPNIUserContactInfoResponse object, which represents the response from the operation of querying CPNI user contact information.
	 */
	QueryCPNIUserContactInfoResponse queryCPNIUserContactInfo(QueryCPNIUserContactInfoRequest queryUserInfoRequest, MultivaluedMap<String, String> requestHeader);
}
