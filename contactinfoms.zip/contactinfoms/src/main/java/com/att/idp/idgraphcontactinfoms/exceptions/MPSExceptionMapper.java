package com.att.idp.idgraphcontactinfoms.exceptions;

import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;
import jakarta.ws.rs.ext.ExceptionMapper;

/**
 * This is the MPSExceptionMapper class.
 *
 * It implements the ExceptionMapper interface with MPSException as the type parameter. This means that an instance of MPSExceptionMapper can be used to map MPSException instances to Response objects.
 *
 * The purpose of this class is to provide a way to convert MPSException instances into Response objects that can be returned by a JAX-RS resource method. This is done in the toResponse method, which is overridden from the ExceptionMapper interface.
 */
public class MPSExceptionMapper implements ExceptionMapper<MPSException> {
	
	@Override
	public Response toResponse(MPSException ex) {
		return Response.status(Status.INTERNAL_SERVER_ERROR)
				.entity(ex.errorMessage.getErrorResponseInfo())
				.type(MediaType.APPLICATION_JSON)
				.build();
	}

}