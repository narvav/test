package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;
import java.io.Serializable;
import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "TACCOUNTINFO", schema = "MPS_OWNER")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Taccountinfo implements Serializable {

	private static final long serialVersionUID = -6133402165512591572L;

	@Id
	@Column(name = "BAN", unique = true, nullable = false, length = 40)
	private String ban;

	@Column(name = "BILL_CYCLE", length = 2)
	private String billCycle;

	@Column(name = "LEGAL_ENTITY", length = 6)
	private String legalEntity;

	@Column(name = "FULLNAME")
	private String fullname;

	@Column(name = "ACCOUNT_TYPE", length = 1)
	private Character accountType;

	@Column(name = "ACCOUNT_SUBTYPE", length = 1)
	private Character accountSubtype;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;

	@Column(name = "SITE_ID", length = 9)
	private String siteId;

	@Column(name = "STREET1")
	private String street1;

	@Column(name = "STREET2")
	private String street2;

	@Column(name = "STREET3")
	private String street3;

	@Column(name = "STREET4")
	private String street4;

	@Column(name = "STREET5")
	private String street5;

	@Column(name = "CITY", length = 50)
	private String city;

	@Column(name = "STATE", length = 2)
	private String state;

	@Column(name = "ZIP", length = 10)
	private String zip;

	@Column(name = "IPDSLAM_IND", length = 1)
	private String ipdslamInd;

	@Column(name = "SUPERSEDED_MAIN_MID", length = 51)
	private String supersededMainMid;

	@Column(name = "TOS_ACCEPTANCE_FLAGS")
	private String tosAcceptanceFlags;

	@Column(name = "HSIA_TOS_DATE", length = 7)
	private Date hsiaTosDate;

	@Column(name = "E911_TOS_DATE", length = 7)
	private Date e911TosDate;

	@Column(name = "IPTV_TOS_DATE", length = 7)
	private Date iptvTosDate;

	@Column(name = "PREPROVISION_IND", length = 1)
	private Character preprovisionInd;

	@Column(name = "ORDER_DUE_DATE")
	private Serializable orderDueDate;

	@Column(name = "ORDER_TAKEN_DATE")
	private Serializable orderTakenDate;

	@Column(name = "RG_ACTIVATED", length = 1)
	private Character rgActivated;

	@Column(name = "TN_ACTIVATED", length = 1)
	private Character tnActivated;

	@Column(name = "INSTALLATION_TYPE", length = 15)
	private String installationType;

	@Column(name = "WLL_TOS_ACCEPTANCE_FLAGS")
	private String wllTosAcceptanceFlags;

	@Column(name = "WDM_TOS_DATE", length = 7)
	private Date wdmTosDate;

	@Column(name = "WVM_TOS_DATE", length = 7)
	private Date wvmTosDate;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "taccountinfo")
	private Set<Tprovisionedservice> tprovisionedservices = new HashSet<>(0);
}