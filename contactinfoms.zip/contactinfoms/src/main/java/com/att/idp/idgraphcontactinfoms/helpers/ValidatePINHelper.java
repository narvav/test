package com.att.idp.idgraphcontactinfoms.helpers;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import com.att.idp.core.exception.ServiceException;
import com.att.idp.idgraphcontactinfoms.message.ErrorMessages;
import org.apache.commons.text.StringEscapeUtils;
import com.att.idp.idgraph.db.cosmos.entity.IdgOtpContainerHistory;
import com.att.idp.idgraph.db.cosmos.entity.HistoryMetadata;
import com.att.idp.idgraph.db.cosmos.entity.Operation;
import com.att.idp.idgraph.db.cosmos.entity.IdgOtpContainer;
import com.att.idp.idgraph.db.cosmos.helper.IdgOtpDBHelper;
import com.att.idp.idgraph.db.cosmos.helper.OtpHistoryDBHelper;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import com.att.idp.idgraphcontactinfoms.metrics.ErrorMetricHandler;
import org.apache.commons.lang3.StringUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;
import com.att.idp.idgraphcontactinfoms.cgclient.response.CombinedSubscribers;
import com.att.idp.idgraphcontactinfoms.db.helper.CosmosDataStore;
import com.att.idp.idgraphcontactinfoms.db.helper.SecurityCodeDBHelper;
import com.att.idp.idgraphcontactinfoms.db.helper.ValidatePinInfoBean;
import com.att.idp.idgraphcontactinfoms.helpers.voltage.ProofingEncryptionHelper;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.idp.idgraphcontactinfoms.utils.DateUtil;
import com.att.idp.idgraphcontactinfoms.utils.JsonService;
import com.att.idp.idgraphcontactinfoms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.helpers.FeatureManagerHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.RILDefs;
import com.fasterxml.jackson.databind.node.ArrayNode;
import net.logstash.logback.argument.StructuredArguments;
import com.att.idp.cgclienthelpers.integration.CGApiRestClient;
import com.att.idp.cgclienthelpers.utils.CGUtilHelper;
import com.att.idp.idgraphcontactinfoms.utils.Constants;
import com.att.idp.dpl.profile.bsse.customerv4.CustomerV4Response;

/**
 * This class is a helper class for validating PINs.
 *
 * It contains methods for validating PINs based on the input parameters.
 * The class uses the Spring Framework's @Component annotation to indicate that it is a bean and can be used for dependency injection.
 *
 * The class has several instance variables that are injected using the @Autowired annotation.
 * These variables are used to interact with various other helper classes and services to process and validate PINs.
 *
 * The main method in this class is the validatePIN method, which takes a Map as input and returns a HashMap as output.
 * The validatePIN method uses several other methods in the class to validate the input data, process the input data, and store the data.
 *
 * The class also contains a logger for logging information and error messages.
 */
@Component
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class ValidatePINHelper {

	@Autowired
	private ProofingEncryptionHelper proofingEncryptionHelper;
	
	@Autowired
	private SecurityCodeDBHelper securityCodeDBHelperObj;

	@Autowired
	private DeletePINHelper objDeletePINHelper;

	@Autowired
	private IdgOtpDBHelper idgOtpDBHelper;

	private final OtpHistoryDBHelper otpHistoryDBHelper;

	@Qualifier("otpHistoryExecutor")
	private final Executor otpHistoryExecutor;

	private static final String OTP_HISTORY_SOURCE = "IDGraphContactInfoMs";

	// Constructor for OtpHistoryDBHelper and otpHistoryExecutor
	public ValidatePINHelper(OtpHistoryDBHelper otpHistoryDBHelper, @Qualifier("otpHistoryExecutor") Executor otpHistoryExecutor) {
		this.otpHistoryDBHelper = otpHistoryDBHelper;
		this.otpHistoryExecutor = otpHistoryExecutor;
	}

	@Autowired
	private ErrorMetricHandler errorMetricHandler;
	
	@Value("${PROP_PIN_CSI}")
	private String propValidPINCSI;
		
	@Value("${PROP_PIN_AGENT_CSI}")
	private String propValidAgentCSI;
	
	@Value("${PROP_PIN_UNLOCK_PERIOD_MINUTES}")
	private String propUnlockPeriodMins;

	@Value("${PROP_PIN_MAX_FAILURE_COUNT}")
	private String propPINMaxFailureCnt;
	
	@Value("${PROP_PIN_MAX_PINS}")
	private String propPinMaxPins;
	
	@Value("${PROP_PIN_SIM_CHECK}")
	private String propSIMCheckIdentificationType;
	
	@Value("${PROP_PIN_CTN_ACTIVE_DAYS}")
	private String propCTNActiveDays;
	
	@Value("${PROP_PIN_SIM_ACTIVE_DAYS}")
	private String propSIMActiveDays;
	
	@Value("${apiclient.rest.cg.endpoint}")
	private String cgEndpoint;

	@Value("${apiclient.rest.cg.custsearch.v3.endpoint}")
	private String cgEndpointV3;

	@Value("${PROP_REUSE_PIN_IDENTIFICATIONTYPES}")
	private String propReuseIdentificationTypes;
	
	@Value("${PROP_ValidatePIN_Status_COSMOSDB_CSI}")
	private String propCosmosUpdateCSI;

	@Value("${PROP_OTP_UNLOCK_ACCOUNT_MINUTES}")
	private String propOtpUnlockAccountMinutes;

	@Autowired
	private CGHelper cgHelper;

	@Autowired
	private CGApiRestClient cgApiRestClient;

	@Autowired
	private CGUtilHelper cgUtilHelper;

	@Autowired
	FeatureManagerHelper featureManager;
	
	@Autowired
	private CosmosDataStore cosmosDataStore;

	private String propUnlockPeriod;
	
	public static final String sClassName = "ValidatePINHelper.";
	private static final String ERROR_ENUM = "ErrorEnum";
	public static final Logger logger = LoggerFactory.getLogger(ValidatePINHelper.class);

	/**
	 * This method is used to validate a PIN.
	 *
	 * It takes a Map as input which contains various keys related to the PIN validation process.
	 * The method performs various checks and validations on the input data and constructs a response HashMap.
	 * The response HashMap contains the result of the PIN validation process.
	 *
	 * The method interacts with various other helper classes and services to process and validate PINs.
	 * It also handles various error scenarios and constructs appropriate error responses.
	 *
	 * @param hmInput A Map containing the input data for the PIN validation process.
	 * @return A HashMap containing the result of the PIN validation process.
	 * @throws Exception if an error occurs during the operation.
	 */
	public HashMap<String, Object> validatePIN(Map<String, Object> hmInput) {

		String sMethodName =  "validatePIN.";
		logger.info(SpiMarker.getInstance(), "ValidatePINHelper.validatePIN.HLP000 : Input Hash :",
				StructuredArguments.entries(hmInput));

		HashMap<String, Object> hmResult = null;
		String stAppInfo = null;
		String stAppStatusCode = null;
		String sMaxFailureCnt = "0";
		boolean isTransactionRollbackOnError = false;
		HashMap<String, Object> hmCosmosDBInput = null;
		String sResponseCode = "";

		try {
				propUnlockPeriod = propUnlockPeriodMins;
				hmInput.put(ProfileOrchestrationConstants.EXPIRY_TIME_UNIT, ProfileOrchestrationConstants.MINUTES);

			String sTransactionId = (String) hmInput.get("idpTraceId");
			String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sAccountId = (String) hmInput.get(CommonDefs.ACCOUNT_ID);
			String sIdentificationType = (String) hmInput.get(CommonDefs.IDENTIFICATION_TYPE);
			String sSecurityCode = (String) hmInput.get(CommonDefs.SECURITY_CODE);
			String sDeletePINOnSuccess = (String) hmInput.get(CommonDefs.DELETE_PIN_ON_SUCCESS);
			String sSourceIPAddress = (String) hmInput.get(CommonDefs.SOURCE_IP_ADDRESS);
			String sAccountType = (String) hmInput.get(CommonDefs.ACCOUNT_TYPE);
			
			if ((sTransactionName == null || sCallingSystemId == null || sAccountId == null
					|| sIdentificationType == null || sSecurityCode == null || sDeletePINOnSuccess == null)) {
				stAppInfo = "Either of the parameters TransactionName|CallingSystemId|AccountId|IdentificationType|SecurityCode|DeletePINOnSuccess is null";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				logger.info("{}{}VPH_01 :: {}",sClassName, sMethodName , hmResult);
				return hmResult;
			}
									
			ArrayList alSIMCheckIdentificationType = CommonUtil.parseToArray(propSIMCheckIdentificationType, CommonDefs.VALUE_SEPARATOR_CHAR);
			logger.info("{}{}VPH_09 :PROP_PIN_SIM_CHECK : {}",sClassName, sMethodName , alSIMCheckIdentificationType);
			
			ArrayList<String> alCosmosUpdateCSI = CommonUtil.parseToArray(propCosmosUpdateCSI, CommonDefs.VALUE_SEPARATOR_CHAR);
			logger.info("{}{}VPH_121 :PROP_ValidatePIN_Status_COSMOSDB_CSI : {}",sClassName, sMethodName , alCosmosUpdateCSI);
			logger.info("{}{}VPH_122 :transaction details : {}",sClassName, sMethodName , sTransactionId);
			

			sAccountId = sAccountId.trim().toLowerCase();
			hmInput.put(CommonDefs.ACCOUNT_ID, sAccountId);
			sSecurityCode = sSecurityCode.trim();
			hmInput.put(CommonDefs.SECURITY_CODE, sSecurityCode);
			sIdentificationType = sIdentificationType.trim().toUpperCase();
			hmInput.put(CommonDefs.IDENTIFICATION_TYPE, sIdentificationType);
			sDeletePINOnSuccess = sDeletePINOnSuccess.trim().toUpperCase();
			hmInput.put("deletePINOnSuccess", sDeletePINOnSuccess);

			String sAgentId = (String) hmInput.get(CommonDefs.AGENT_ID);
			if (sAgentId != null && !sAgentId.isEmpty()) {
				sAgentId = sAgentId.trim().toLowerCase();
				hmInput.put(CommonDefs.AGENT_ID, sAgentId);
			}
			
			sSecurityCode = sSecurityCode.toUpperCase();
			String sEncryptedSecurityCode = proofingEncryptionHelper.generateSHA1Value(sSecurityCode);
			logger.info("{}{}VPH_02 :EncryptedSecurityCode : {}",sClassName, sMethodName , sEncryptedSecurityCode);
			hmInput.put(CommonDefs.ENCRYPTED_SECURITY_CODE, sEncryptedSecurityCode);

			//override the security code with SHA256 encrypted value for Cosmos DB
			HashMap<String, String> passwordMap = new HashMap<>();
			passwordMap.put(MPSDefs.WS_CLEAR_TEXT, sSecurityCode);
			String sSHA256EncryptedSecurityCode = CommonUtilHelper.generateGenericPassword(passwordMap,
					"SHA256").get(RILDefs.RIL_GEN_PASSWORD).toString();
			
			//String propUnlockPeriodHrs = PropertyManager.getProperty(CommonDefs.MSConfig, "PROP_PIN_UNLOCK_PERIOD_HOURS");
			HashMap hmUnlockPeriod = CommonUtil.parsePropertyToHash(propUnlockPeriod);
			logger.info("{}{}VPH_03 :PROP_PIN_UNLOCK_PERIOD_HOURS/PROP_PIN_UNLOCK_PERIOD_MINUTES : {}",sClassName, sMethodName , hmUnlockPeriod);

			if (hmUnlockPeriod != null && hmUnlockPeriod.containsKey(sIdentificationType)) {
				String sUnlockPeriod = (String) hmUnlockPeriod.get(sIdentificationType);
				Double unlockPeriodDays = DateUtil.getsecurityCodeExpiryTime(Double.parseDouble(sUnlockPeriod),
						(String) hmInput.get(ProfileOrchestrationConstants.EXPIRY_TIME_UNIT));
				hmInput.put(MPSDefs.UNLOCK_PERIOD, unlockPeriodDays);
			}

			//String propPINMaxFailureCnt = PropertyManager.getProperty(CommonDefs.MSConfig, "PROP_PIN_MAX_FAILURE_COUNT");
			HashMap hmPINMaxFailureCnt = CommonUtil.parsePropertyToHash(propPINMaxFailureCnt);
			logger.info("{}{}VPH_04 :PROP_PIN_MAX_FAILURE_COUNT : {}",sClassName, sMethodName , hmPINMaxFailureCnt);

			if (hmPINMaxFailureCnt != null && hmPINMaxFailureCnt.containsKey(sIdentificationType)) {
				sMaxFailureCnt = (String) hmPINMaxFailureCnt.get(sIdentificationType);
				hmInput.put("maxFailureCount", sMaxFailureCnt);
			}

			String sMaxPins = "0";
//			String propPinMaxPins = PropertyManager.getProperty(CommonDefs.MSConfig, "PROP_PIN_MAX_PINS");
			HashMap hmMaxPins = CommonUtil.parsePropertyToHash(propPinMaxPins);
			logger.info("{}{}VPH_05 :PROP_PIN_MAX_PINS : {}",sClassName, sMethodName , hmMaxPins);

			if (hmMaxPins != null && hmMaxPins.containsKey(sIdentificationType)) {
				sMaxPins = (String) hmMaxPins.get(sIdentificationType);
			}

			HashMap<String, Object> hmGetDBPinInput = CommonUtil.getHashMap();
			hmGetDBPinInput.put(MPSDefs.DB_IDENTIFICATION_TYPE, sIdentificationType);
			hmGetDBPinInput.put(MPSDefs.DB_ACCOUNT_ID, sAccountId);
			hmGetDBPinInput.put(MPSDefs.GET_EXCEEDED_UNLOCKED_TIME, MPSDefs.YES);
			hmGetDBPinInput.put(MPSDefs.UNLOCK_PERIOD, hmInput.get(MPSDefs.UNLOCK_PERIOD));
			hmGetDBPinInput.put(ProfileOrchestrationConstants.EXPIRY_TIME_UNIT,
					hmInput.get(ProfileOrchestrationConstants.EXPIRY_TIME_UNIT));

			logger.debug("{}{}VPH_06 :Calling GetSecurityCodeDataService.getSecurityCodeData() with input : {}",
					sClassName, sMethodName , hmGetDBPinInput);

			String otpDataSource = getOtpDataSource();
			HashMap<String, Object> hmSecurityCodeResp = null;
			if ("ORACLEMASTER".equalsIgnoreCase(otpDataSource) || "ONLYORACLE".equalsIgnoreCase(otpDataSource)) {
				hmSecurityCodeResp =
						(HashMap<String, Object>) securityCodeDBHelperObj.getSecurityCodeDataQuery(hmGetDBPinInput);
			}
			else if("COSMOSMASTER".equalsIgnoreCase(otpDataSource) || "ONLYCOSMOS".equalsIgnoreCase(otpDataSource))
			{
				hmSecurityCodeResp = (HashMap<String, Object>) idgOtpDBHelper.getSecurityCodeDataQuery(hmGetDBPinInput);
			}

			logger.debug("{}{}VPH_07 :Response from GetSecurityCodeDataService.getSecurityCodeData() is: {}",
					sClassName, sMethodName , hmSecurityCodeResp);

			stAppStatusCode = (String) hmSecurityCodeResp.get(CommonDefs.COMMON_APP_STATUS_CODE);

			if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))
					&& !(CErrorDefs.ERR_REC_NOT_FOUND.equals(stAppStatusCode))) {
				logger.info("{}{}VPH_08 :GetSecurityCodeDataService.getSecurityCodeData() returned error: {}",
						sClassName, sMethodName , hmSecurityCodeResp);
				return hmSecurityCodeResp;
			}

			int iDBSecurityCodeCount = 0;
			if (CErrorDefs.ERR_REC_NOT_FOUND.equals(stAppStatusCode)) {
				stAppInfo = "No record found in DB.";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INCORRECT_CODE_NUM, stAppInfo);
				int iLeftSecurityCodes = Integer.parseInt(sMaxPins) - iDBSecurityCodeCount;
				hmResult.put(CommonDefs.REMAINING_CODES, Integer.toString(iLeftSecurityCodes));
				return hmResult;
			}

			boolean isAccountLocked = true;
			

			ArrayList alSecurityCodeData = (ArrayList) hmSecurityCodeResp.get(MPSDefs.SECURITY_CODE_INFO);
			if (alSecurityCodeData != null && !alSecurityCodeData.isEmpty()) {
				iDBSecurityCodeCount = alSecurityCodeData.size();
				for (int i = 0; i < iDBSecurityCodeCount; i++) {
					HashMap hmDBSecurityCode = (HashMap) alSecurityCodeData.get(i);
					if (hmDBSecurityCode != null && !hmDBSecurityCode.isEmpty()) {
						Integer sVerificationFailureCnt = (Integer) hmDBSecurityCode
								.get(MPSDefs.DB_VERIFICATION_FAILURE_COUNT);
						String sExceededUnlockTime = (String) hmDBSecurityCode.get(MPSDefs.EXCEEDED_UNLOCKED_TIME);

						if ((sVerificationFailureCnt) < Integer.parseInt(sMaxFailureCnt)) {
							isAccountLocked = false;
							break;
						} else if (Double.parseDouble(sExceededUnlockTime) > 0) {
							isAccountLocked = false;
							break;
						}
					}
				}
			}
			if (isAccountLocked) {
				sResponseCode = CErrorDefs.ERR_ACCOUNT_LOCKOUT_MSG;
				// --- Begin: Account Lockout UnlockAccountTime Update for OnlyCosmos/CosmosMaster ---
			String unlockAccountTime = hmSecurityCodeResp.get("unlockAccountTime")!=null?hmSecurityCodeResp.get("unlockAccountTime").toString():null;
			HashMap<String, String> otpUnlockAccountMinutesMap = parseOtpUnlockAccountMinutes();
				if (otpUnlockAccountMinutesMap.containsKey(sIdentificationType) &&
						("ONLYCOSMOS".equalsIgnoreCase(otpDataSource) || "COSMOSMASTER".equalsIgnoreCase(otpDataSource)))
						updateUnlockTime(sIdentificationType, sAccountId,unlockAccountTime ,sCallingSystemId);
			}

			String sDBDeliveryMethod = null;
			String sDBDeliveryDetail = null;
			String sDBCreateDate = null;
			HashMap hmMatchedSecurityCode = null;

			if (sResponseCode.isEmpty()) {
				if (alSecurityCodeData != null && !alSecurityCodeData.isEmpty()) {
					for (int i = 0; i < alSecurityCodeData.size(); i++) {
						HashMap hmDBSecurityCode = (HashMap) alSecurityCodeData.get(i);
						String sDBSecurityCode = (String) hmDBSecurityCode.get(MPSDefs.DB_SECURITY_CODE);
						if (sDBSecurityCode != null &&
								((("ORACLEMASTER".equalsIgnoreCase(otpDataSource) || "ONLYORACLE".equalsIgnoreCase(otpDataSource))&&
										sDBSecurityCode.equals(sEncryptedSecurityCode)) ||
										((!"ORACLEMASTER".equalsIgnoreCase(otpDataSource) && !"ONLYORACLE".equalsIgnoreCase(otpDataSource))&&
												sDBSecurityCode.equals(sSHA256EncryptedSecurityCode)))) {
							Integer sVerificationFailureCnt = (Integer) hmDBSecurityCode
									.get(MPSDefs.DB_VERIFICATION_FAILURE_COUNT);
							String sExceededUnlockTime = (String) hmDBSecurityCode.get(MPSDefs.EXCEEDED_UNLOCKED_TIME);
							if ((sVerificationFailureCnt < Integer.parseInt(sMaxFailureCnt))
									|| (Double.parseDouble(sExceededUnlockTime) > 0)) {
								sResponseCode = CErrorDefs.COMMON_SUCCESS_MSG;
								sDBCreateDate =  hmDBSecurityCode.get(MPSDefs.DB_CREATE_DATE).toString();
								sDBDeliveryMethod = (String) hmDBSecurityCode.get(MPSDefs.DB_DELIVERY_METHOD);
								sDBDeliveryDetail = (String) hmDBSecurityCode.get(MPSDefs.DB_DELIVERY_DETAIL);
								hmMatchedSecurityCode = hmDBSecurityCode;
							} else {
								sResponseCode = CErrorDefs.ERR_ACCOUNT_LOCKOUT_MSG;
							}
							break;
						}
					}
				}
			}

			if (sResponseCode.isEmpty()) {
				sResponseCode = CErrorDefs.ERR_INCORRECT_CODE_MSG;				
			}

			//String propSIMCheckIdentificationType = PropertyManager.getProperty(CommonDefs.MSConfig,"PROP_PIN_SIM_CHECK");
			
			
			//String sInputTxnName = (String) hmInput.get(MPSDefs.WS_TRANSACTION_NAME);
			if (alSIMCheckIdentificationType != null && !alSIMCheckIdentificationType.isEmpty()
					&& alSIMCheckIdentificationType.contains(sIdentificationType) && "ValidatePIN".equals(sTransactionName)) {
				if (sDBDeliveryMethod != null && sDBDeliveryMethod.equalsIgnoreCase("S") && sDBDeliveryDetail != null) {
					boolean useCGV4 = featureManager.isEnabled("svc-idgraph-validatepin-cg-v4-enabled");
					logger.info("{}{}VPH_09.1 : Feature flag svc-idgraph-validatepin-cg-v4-enabled : {}", sClassName, sMethodName, useCGV4);

					if (useCGV4) {
						// ===================== NEW V4 FLOW =====================
						try {
							sResponseCode = performSimSwapV4Check(sDBDeliveryDetail, hmInput);
						}catch(ServiceException e){
							logger.error("{}{}VPH_09.2 : Exception occurred while performing SIM swap check with CG V4 for CTN: {}. Error: {}",
									sClassName, sMethodName, sDBDeliveryDetail, e.getMessage());
							int errorNum = Integer.parseInt(e.getError().getErrorId().replaceAll("\\D+", ""));
							String rawMsg = e.getError().getMessage();
							String displayMsg = rawMsg != null && rawMsg.contains(":") ? rawMsg.substring(rawMsg.indexOf(':') + 1).strip() : rawMsg;
							hmResult = CommonErrorMap.makeCategoryMap(errorNum, displayMsg);
							return hmResult;
						}

					} else {
						// ===================== OLD V2 FLOW =====================
					HashMap hmSyncCGCall = CommonUtil.getHashMap();
					hmSyncCGCall.put(CommonDefs.SUBSCRIBER_NUMBER, sDBDeliveryDetail);
					hmSyncCGCall.put("topics", "subscribers,equipments,accounts");
					hmSyncCGCall.put("apiName","CGCustomerSearch");
					String stAccountType = (String) hmInput.get(CommonDefs.ACCOUNT_TYPE);
					String cgURL = "BSSEWIRELESS".equals(stAccountType) ? cgEndpointV3 : cgEndpoint;

					logger.info("{}{}VPH_10 :Calling CgRestClient.getCGSyncCall with input: {}",sClassName, sMethodName , hmSyncCGCall);
					//HashMap hmSyncResp = objRestServiceHelper.call(hmRestCall, logger);
					HashMap hmSyncResp = (HashMap) cgHelper.makeCGSyncCall(hmSyncCGCall, cgURL);
					
					logger.info("{}{}VPH_11 :Response from CgRestClient.getCGSyncCall: {}",sClassName, sMethodName , hmSyncResp);

					if (hmSyncResp == null || hmSyncResp.isEmpty()) {
						stAppInfo = "Response from CgRestClient.getCGSyncCall() is null or empty";
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
						return hmResult;
					}
					stAppStatusCode = (String) hmSyncResp.get(CommonDefs.COMMON_APP_STATUS_CODE);
					hmResult = hmSyncResp;
					if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
						if (CErrorDefs.ERR_TRAN_TIME_OUT.equals(stAppStatusCode)) {
							logger.info("{}{}VPH_12 :CGRestClient.getCGSyncCall() returned TimeOut error for CTN: {} :  {}",
									sClassName,	sMethodName, sDBDeliveryDetail, hmResult);
							return hmResult;
						} else if (CErrorDefs.ERR_EXTERNAL_SYS.equals(stAppStatusCode)) {
							logger.info("{}{}VPH_13 : CGRestClient.getCGSyncCall() returned ERR_SYS_APPL error for CTN: {} : {}",
									sClassName,	sMethodName, sDBDeliveryDetail, hmResult);
							return hmResult;
						} else if (CErrorDefs.ERR_INVALID_DATA.equals(stAppStatusCode)) {
							logger.info("{}{}VPH_13 : CGRestClient.getCGSyncCall() returned ERR_INVALID_DATA error for CTN: {} : {}",
									sClassName,	sMethodName, sDBDeliveryDetail, hmResult);
							return hmResult;
						} else {
							stAppInfo = (String) hmSyncResp.get(CommonDefs.COMMON_APP_INFO);
							logger.info("{}{}VPH_14:: {}",sClassName, sMethodName , HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
							stAppInfo = "subscriber data not found for CTN:" + sDBDeliveryDetail; //1809 - PID: 301329a MPSYS-US6
							sResponseCode = CErrorDefs.ERR_SIM_DATE_MISSING_MSG; 
						}
					} else if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
						CombinedSubscribers hmSubscribers = JsonService.convertToObject(((ArrayNode) hmSyncResp.get("subscribers")).get(0), CombinedSubscribers.class);
						String duoIdentifier = hmSubscribers.getDuoIdentifier();
						if (duoIdentifier != null && Constants.DUO_IDENTIFIER_COMPANION.equalsIgnoreCase(duoIdentifier)) {
							stAppInfo = "DUO companion CTN is not eligible for ValidatePIN";
							hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
							return hmResult;
						}
						Map<String, Object> accounts = null;
						if(hmSyncResp.get("accounts") != null) {
							accounts = (Map<String, Object>) hmSyncResp.get("accounts");
						}
						String accountCreatedOn = null;
						if(accounts!=null){
							accountCreatedOn = (String) accounts.get("createdOn");
						}


//						String sActivationDate = (String) hmSyncResp.get("activationDate");
						String sSIMEffectiveDate = null;
						if (hmSubscribers != null) {
							sSIMEffectiveDate = (String) hmSubscribers.getSimSwapDate();
						}
						if (sSIMEffectiveDate != null && !sSIMEffectiveDate.isEmpty()) {

							logger.info("{}{}VPH_15:: SimSwapDate:{}",sClassName, sMethodName , HtmlUtils.htmlEscape(String.valueOf(sSIMEffectiveDate)));
							
//							sActivationDate = sActivationDate.substring(0, 10);
							sSIMEffectiveDate = sSIMEffectiveDate.substring(0, 10);
							String sDateFormat = "yyyy-MM-dd";

							/*
							 * String propCTNActiveDays = PropertyManager.getProperty(CommonDefs.MSConfig,
							 * "PROP_PIN_CTN_ACTIVE_DAYS"); String propSIMActiveDays =
							 * PropertyManager.getProperty(CommonDefs.MSConfig, "PROP_PIN_SIM_ACTIVE_DAYS");
							 */
//							if (checkAging(sActivationDate, propCTNActiveDays, sDateFormat)) {
//								logger.info("{}{}VPH_15 : CTN activationDate:: {} is more than {} days old for CTN :: {} ",
//										sClassName , sMethodName , sActivationDate, propCTNActiveDays , sDBDeliveryDetail);
								
								if (checkAging(sSIMEffectiveDate, propSIMActiveDays, sDateFormat)) {
									logger.debug("{}{}VPH_16 : simEffectiveDate:: {} is more than {} days for CTN :: {} ",
											sClassName , sMethodName, sSIMEffectiveDate, propSIMActiveDays, sDBDeliveryDetail);
								} else {
									// accountCreatedOn is only required when the SIM swap date is recent (not yet aged).
									// Guard against a null/empty createdOn here to avoid a NullPointerException on substring().
									if (accountCreatedOn == null || accountCreatedOn.isEmpty()) {
										stAppInfo = "createdOn value is null for CTN :: " + sDBDeliveryDetail;
										logger.info("{}{}VPH_16.1 :: createdOn value is null for CTN :: {}", sClassName, sMethodName, CommonUtilHelper.sanitizeForLog(sDBDeliveryDetail));
										hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EXTERNAL_SYS_NUM, stAppInfo);
										return hmResult;
									}
									accountCreatedOn = accountCreatedOn.substring(0, 10);
									if(compareAcctAndSIMEffectDate(accountCreatedOn,sSIMEffectiveDate,sDateFormat)) {
										stAppInfo = "SIM changed recently for CTN :: " + sDBDeliveryDetail;
										sResponseCode = CErrorDefs.ERR_SIM_NOT_YET_ELIGIBLE_MSG;    //1809 - PID: 301329a MPSYS-US6
										logger.info("{}{}VPH_17.1 :: {}", sClassName, sMethodName, stAppInfo);
									}else{
										stAppInfo = "SUCCESS";
										sResponseCode = CommonDefs.COMMON_SUCCESS_MSG;
										logger.info("{}{}VPH_17.2 :: {}", sClassName, sMethodName, stAppInfo);
									}
								}
//							}
						} else {
//							if (sActivationDate == null || sActivationDate.isEmpty()) {
//								stAppInfo = "activationDate is null from syncRestCall response for CTN :: "+ sDBDeliveryDetail;
							if (sSIMEffectiveDate == null || sSIMEffectiveDate.isEmpty()) {
								stAppInfo = "simEffectiveDate is null from syncCGCall response for CTN :: "+ sDBDeliveryDetail;
							}
							logger.info("{}{}VPH_18 :: {}",sClassName, sMethodName , stAppInfo);
							stAppInfo = "sim related dates missing for CTN:: "+ sDBDeliveryDetail;	 //1809 - PID: 301329a MPSYS-US6
							sResponseCode = CErrorDefs.ERR_SIM_DATE_MISSING_MSG;
						}
					}
				}
			}
			}
			boolean isAnyCodeExceedUnlockTime = false;
			if (alSecurityCodeData != null && !alSecurityCodeData.isEmpty()) {
				for (int i = 0; i < alSecurityCodeData.size(); i++) {
					HashMap hmDBSecurityCode = (HashMap) alSecurityCodeData.get(i);
					String sExceededUnlockTime = (String) hmDBSecurityCode.get(MPSDefs.EXCEEDED_UNLOCKED_TIME);
					if (Double.parseDouble(sExceededUnlockTime) > 0) {
						isAnyCodeExceedUnlockTime = true;
						break;
					}
				}
			}

			if (isAnyCodeExceedUnlockTime) {
				HashMap<String, Object> hmUnlock = CommonUtil.getHashMap();
				hmUnlock.put(MPSDefs.DB_IDENTIFICATION_TYPE, sIdentificationType);
				hmUnlock.put(MPSDefs.DB_ACCOUNT_ID, sAccountId);
				hmUnlock.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);
				hmUnlock.put(MPSDefs.UNLOCK_PERIOD, hmInput.get(MPSDefs.UNLOCK_PERIOD));

				logger.debug("{}{}VPH_19 : Calling SecurityCodeDBHelper.updateSecurityCode() with input: {}",sClassName, sMethodName , hmUnlock);
				if (!"ONLYCOSMOS".equalsIgnoreCase(otpDataSource)) {
					hmResult = securityCodeDBHelperObj.updateSecurityCode(hmUnlock, MPSDefs.UNLOCK_SECURITY_CODES);
					logger.debug("{}{}VPH_20 : Response from SecurityCodeDBHelper.updateSecurityCode() is: {}",sClassName, sMethodName , hmResult);

					stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
					if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
						logger.info("{}{}VPH_21 : SecurityCodeDBHelper.updateSecurityCode() returned error : {}",sClassName, sMethodName , hmResult);
						return hmResult;
					}
				}
				if (!"ONLYORACLE".equalsIgnoreCase(otpDataSource)) {
					try {
					hmResult = idgOtpDBHelper.updateSecurityCode(hmUnlock, MPSDefs.UNLOCK_SECURITY_CODES);
					logger.debug("{}{}VPH_20 : Response from idgOtpDBHelper.updateSecurityCode() is: {}", sClassName, sMethodName, hmResult);

					stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
					if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
						if ("ORACLEMASTER".equalsIgnoreCase(otpDataSource)) {
							logger.error("{}{}VPH_21a : Cosmos DB ORACLEMASTER ERROR SKIP - updateSecurityCode (unlock) failed. Continuing. Error: {}", sClassName, sMethodName, hmResult);
						} else {
							logger.info("{}{}VPH_21b : idgOtpDBHelper.updateSecurityCode() returned error : {}", sClassName, sMethodName, hmResult);
							return hmResult;
						}
					}
					} catch (Exception cosmosEx) {
						if ("ORACLEMASTER".equalsIgnoreCase(otpDataSource)) {
							logger.error("{}{}VPH_21c : Cosmos DB ORACLEMASTER ERROR SKIP - updateSecurityCode (unlock) exception. Continuing. Error: {}", sClassName, sMethodName, cosmosEx.getMessage(), cosmosEx);
						} else {
							throw cosmosEx;
						}
					}
				}
			}

			if (!sResponseCode.equals(CommonDefs.COMMON_SUCCESS_MSG)) {
				HashMap hmUpdateInp = CommonUtil.getHashMap();
				hmUpdateInp.put(MPSDefs.DB_IDENTIFICATION_TYPE, sIdentificationType);
				hmUpdateInp.put(MPSDefs.DB_ACCOUNT_ID, sAccountId);
				hmUpdateInp.put(MPSDefs.DB_LAST_MODIFIED_BY, sCallingSystemId);
				hmUpdateInp.put(MPSDefs.MAX_FAILURE_COUNT, hmInput.get("maxFailureCount"));
				hmUpdateInp.put(MPSDefs.DB_REASON_CODE, "FAILED");
				
				logger.debug("{}{}VPH_22 : Calling SecurityCodeDBHelper.updateSecurityCode() with input : {}",sClassName, sMethodName , hmUpdateInp);
				if (!"ONLYCOSMOS".equalsIgnoreCase(otpDataSource)) {
					hmResult = securityCodeDBHelperObj.updateSecurityCode(hmUpdateInp, MPSDefs.INCREMENT_FAILURE_COUNT);
					logger.debug("{}{}VPH_23 : Response from SecurityCodeDBHelper.updateSecurityCode() is : {}",
							sClassName, sMethodName , hmResult);

					stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
					if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
						logger.info("{}{}VPH_24 : SecurityCodeDBHelper.updateSecurityCode()returned error: {}",
								sClassName, sMethodName , hmResult);
						return hmResult;
					}
				}
				if (!"ONLYORACLE".equalsIgnoreCase(otpDataSource)) {
					try {
					hmResult = idgOtpDBHelper.updateSecurityCode(hmUpdateInp, MPSDefs.INCREMENT_FAILURE_COUNT);
					logger.debug("{}{}VPH_23 : Response from idgOtpDBHelper.updateSecurityCode() is : {}",
							sClassName, sMethodName, hmResult);

					stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
					if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
						if ("ORACLEMASTER".equalsIgnoreCase(otpDataSource)) {
							logger.error("{}{}VPH_24a : Cosmos DB ORACLEMASTER ERROR SKIP - updateSecurityCode (incrementFailure) failed. Continuing. Error: {}", sClassName, sMethodName, hmResult);
						} else {
							logger.info("{}{}VPH_24b : idgOtpDBHelper.updateSecurityCode()returned error: {}",
									sClassName, sMethodName, hmResult);
							return hmResult;
						}
					}
					} catch (Exception cosmosEx) {
						if ("ORACLEMASTER".equalsIgnoreCase(otpDataSource)) {
							logger.error("{}{}VPH_24c : Cosmos DB ORACLEMASTER ERROR SKIP - updateSecurityCode (incrementFailure) exception. Continuing. Error: {}", sClassName, sMethodName, cosmosEx.getMessage(), cosmosEx);
						} else {
							throw cosmosEx;
						}
					}
				}
				logger.debug("{}{}VPH_25 : Calling SecurityCodeDBHelper.updateSecurityAccount() with input : {}",
						sClassName, sMethodName , hmUpdateInp);
				if (!"ONLYCOSMOS".equalsIgnoreCase(otpDataSource)) {
					hmResult = securityCodeDBHelperObj.updateSecurityAccount(hmUpdateInp, false);
					logger.debug("{}{}VPH_26 : Response from SecurityCodeDBHelper.updateSecurityAccount() is : {}",
							sClassName, sMethodName , hmResult);

					stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
					if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
						logger.info("{}{}VPH_27 : SecurityCodeDBHelper.updateSecurityAccount()returned error: {}",
								sClassName, sMethodName , hmResult);
						return hmResult;
					}
				}
				if (!"ONLYORACLE".equalsIgnoreCase(otpDataSource)) {
					try {
					hmResult = idgOtpDBHelper.updateSecurityAccount(hmUpdateInp);
					logger.debug("{}{}VPH_26 : Response from idgOtpDBHelper.updateSecurityAccount() is : {}",
							sClassName, sMethodName, hmResult);

					stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
					if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
						if ("ORACLEMASTER".equalsIgnoreCase(otpDataSource)) {
							logger.error("{}{}VPH_27a : Cosmos DB ORACLEMASTER ERROR SKIP - updateSecurityAccount failed. Continuing. Error: {}", sClassName, sMethodName, hmResult);
						} else {
							logger.info("{}{}VPH_27b : idgOtpDBHelper.updateSecurityAccount()returned error: {}",
									sClassName, sMethodName, hmResult);
							return hmResult;
						}
					}
					} catch (Exception cosmosEx) {
						if ("ORACLEMASTER".equalsIgnoreCase(otpDataSource)) {
							logger.error("{}{}VPH_27c : Cosmos DB ORACLEMASTER ERROR SKIP - updateSecurityAccount exception. Continuing. Error: {}", sClassName, sMethodName, cosmosEx.getMessage(), cosmosEx);
						} else {
							throw cosmosEx;
						}
					}
				}
				saveOtpHistoryAsync(sIdentificationType, sAccountId, sCallingSystemId, Operation.UPDATE);

				if (sResponseCode.equals(CErrorDefs.ERR_ACCOUNT_LOCKOUT_MSG)) {
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ACCOUNT_LOCKOUT_NUM, sResponseCode);
				} else if (sResponseCode.equals(CErrorDefs.ERR_INCORRECT_CODE_MSG)) {
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INCORRECT_CODE_NUM, sResponseCode);
				}else if (sResponseCode.equals(CErrorDefs.ERR_SIM_NOT_YET_ELIGIBLE_MSG)) {
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SIM_NOT_YET_ELIGIBLE_NUM, sResponseCode);
				}else if (sResponseCode.equals(CErrorDefs.ERR_SIM_DATE_MISSING_MSG)) {
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SIM_DATE_MISSING_NUM, sResponseCode);
				}

				int iLeftSecurityCounts = Integer.parseInt(sMaxPins) - iDBSecurityCodeCount;
				String stLeftSecurityCounts = Integer.toString(iLeftSecurityCounts);
				hmResult.put(CommonDefs.REMAINING_CODES, stLeftSecurityCounts);
				} else if (sResponseCode.equals(CommonDefs.COMMON_SUCCESS_MSG)) {
					ArrayList<String> alReusePinIdentificationType =
							CommonUtil.parseToArray(propReuseIdentificationTypes, CommonDefs.VALUE_SEPARATOR_CHAR);
				
					boolean isReusable = alReusePinIdentificationType.contains(sIdentificationType);
					boolean isDeleteAll = sDeletePINOnSuccess.equals("ALL");
					if (isReusable && !isDeleteAll) {
						// Reusable identification type: do not delete OTP unless delete-all is requested
						hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
					} else {
						HashMap hmDeletePIN = CommonUtil.getHashMap();
						hmDeletePIN.put(CommonDefs.TRANSACTION_ID, sTransactionId);
						hmDeletePIN.put(CommonDefs.TRANSACTION_NAME, "DeletePIN");
						hmDeletePIN.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
						hmDeletePIN.put(CommonDefs.ACCOUNT_ID, sAccountId);
						hmDeletePIN.put(CommonDefs.IDENTIFICATION_TYPE, sIdentificationType);
						hmDeletePIN.put(CommonDefs.AGENT_ID, sAgentId);
						if (sSourceIPAddress != null && !sSourceIPAddress.isEmpty()) {
							hmDeletePIN.put(CommonDefs.SOURCE_IP_ADDRESS, sSourceIPAddress);
						}
				
						hmDeletePIN.put(CommonDefs.DELETE_All, CommonDefs.IND_N);
						hmDeletePIN.put(CommonDefs.SECURITY_CODE, sSecurityCode);
						hmDeletePIN.put(CommonDefs.IS_EXTERNAL_CALL, CommonDefs.IND_N);
						if (alReusePinIdentificationType.contains(sIdentificationType)) {
							hmDeletePIN.put(CommonDefs.REASON_CODE, ProfileOrchestrationConstants.STATUS_CODE_ACTIVE);
						} else {
							hmDeletePIN.put(CommonDefs.REASON_CODE, ProfileOrchestrationConstants.STATUS_CODE_REGISTERED);
						}
				
						hmResult = objDeletePINHelper.deletePin(hmDeletePIN);
						stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
						if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
							return hmResult;
						}
				
						if (sDeletePINOnSuccess.equals("ALL")) {
							hmDeletePIN.put(CommonDefs.DELETE_All, CommonDefs.IND_Y);
							hmResult = objDeletePINHelper.deletePin(hmDeletePIN);
							stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
							if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
								return hmResult;
							}
						}
				
						hmResult = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
					}
				
					// this code is for MPSYS Modernization for CSI Client.
					if (sDBCreateDate != null && !sDBCreateDate.isEmpty()) {
						if (sCallingSystemId.equalsIgnoreCase("CSIGATEWAY") ||
								sCallingSystemId.equalsIgnoreCase("EDS") ||
								sCallingSystemId.equalsIgnoreCase("EVA")) {
                        hmResult.put(CommonDefs.SECURITY_CODE_CREATED_ON, sDBCreateDate.substring(0,8));
						}
					}
				}
			//add code to call cosmos db update
			String idpSessionId = (String) hmInput.get("idpSessionId");
			if (idpSessionId != null && alCosmosUpdateCSI != null && !alCosmosUpdateCSI.isEmpty() && alCosmosUpdateCSI.contains(sCallingSystemId) && sAccountType !=null)
			   {
				    String stCosmosAccountType=null;
				    hmCosmosDBInput = CommonUtil.getHashMap();
				    
				    hmCosmosDBInput.put(CommonDefs.TRANSACTION_ID, sTransactionId);
				    hmCosmosDBInput.put("sessionId", idpSessionId);
					hmCosmosDBInput.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
					hmCosmosDBInput.put(CommonDefs.ACCOUNT_ID, sAccountId);
					hmCosmosDBInput.put(CommonDefs.IDENTIFICATION_TYPE, sIdentificationType);
                 
					if (sAccountType.equalsIgnoreCase("MOBILITY")) stCosmosAccountType = "WIRELESS";
					else if (sAccountType.equalsIgnoreCase("TITAN")) stCosmosAccountType = "UVERSE";
					else stCosmosAccountType = sAccountType;					
					hmCosmosDBInput.put(CommonDefs.ACCOUNT_TYPE, stCosmosAccountType);
					
					if(sDBDeliveryMethod != null && (sDBDeliveryMethod.equalsIgnoreCase("S") || sDBDeliveryMethod.equalsIgnoreCase("E")) && sDBDeliveryDetail != null)
					{
					hmCosmosDBInput.put(CommonDefs.DELIVERY_METHOD, sDBDeliveryMethod);
					hmCosmosDBInput.put(CommonDefs.DELIVERY_METHOD_VALUE, sDBDeliveryDetail);
					}
					
			   }
			   
			
           
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			errorMetricHandler.recordDBErrorMetric(e.getMessage());
		} finally {

			if (hmResult == null || hmResult.isEmpty()) {
				stAppInfo = "Response from ValidatePINHelper is NULL";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}VPH_31 :: {}",sClassName, sMethodName , stAppInfo);
			}
			String sAppCategoryCode = (String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
			String sAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
			String sAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);

			if (isTransactionRollbackOnError && !(CommonDefs.COMMON_SUCCESS.equals(sAppCategoryCode))
					&& (!(CErrorDefs.ERR_INCORRECT_CODE.equals(sAppStatusCode))
							&& !(CErrorDefs.ERR_ACCOUNT_LOCKOUT.equals(sAppStatusCode)))) {
				hmResult.put("isTransactionRollback", "Y");
			}
			if (!CErrorDefs.COMMON_SUCCESS.equalsIgnoreCase(sAppStatusCode)) {
				sAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
				logger.info("{}{}VPH_32 :: {}",sClassName, sMethodName , HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));
			}

			logger.info(SpiMarker.getInstance(), "ValidatePINHelper response.HLP999 : {}",
					HtmlUtils.htmlEscape(String.valueOf(hmResult)));
			if(hmCosmosDBInput != null)
			{
				if (hmCosmosDBInput.containsKey(CommonDefs.DELIVERY_METHOD) || !sResponseCode.isEmpty())
				{
				HashMap<String, Object> hmCosmosDBResponse = CommonUtil.getHashMap();
				hmCosmosDBResponse = updateIDMCosmosDB(hmCosmosDBInput, hmResult);
				logger.info("{}{}EXT999 : Response from CosmosDB call : {}", sClassName, sMethodName, hmCosmosDBResponse);
				}
			}
		}
		

		return hmResult;
	}

	/**
	 * Updates the unlock time for a locked account.
	 *
	 * This method calculates the unlock minutes from the configured properties and updates the unlock time
	 * in the idg_otp document for the specified identification type and account ID.
	 *
	 * @param sIdentificationType the identification type (e.g., "custS", "custE")
	 * @param sAccountId the account ID
	 * @param unlockAccountTime the current unlock time as a string (ISO 8601 format)
	 * @param sCallingSystemId the calling system ID, used for logging and auditing
	 */
	public boolean updateUnlockTime(String sIdentificationType, String sAccountId, String unlockAccountTime, String sCallingSystemId) {
			HashMap<String, String> otpUnlockMinutesMap = parseOtpUnlockAccountMinutes();
			boolean otpUpdateResult=false;
			String unlockMinutesStr = null;
		try {
			if (otpUnlockMinutesMap.containsKey(sIdentificationType)) {
				 unlockMinutesStr = otpUnlockMinutesMap.get(sIdentificationType);
				int unlockMinutes = 0;
				Instant currentTime = Instant.now();
				Instant existingUnlockTime = unlockAccountTime != null ? Instant.parse(unlockAccountTime) : null;
				if (existingUnlockTime != null && existingUnlockTime.isAfter(currentTime)) {
					logger.info("{}{}LOCKOUT_OTP: Current unlock time {} is in the future. No update needed for identificationType {} and accountId {}.",
							sClassName, "updateUnlockTime", existingUnlockTime, sIdentificationType, sAccountId);
					return false;
				} else {
					unlockMinutes = Integer.parseInt(unlockMinutesStr);
					if (unlockMinutes > 0) {
						// Update idg_otp document
						otpUpdateResult = idgOtpDBHelper.updateUnlockAccountTime(sIdentificationType, sAccountId, unlockMinutes, sCallingSystemId);
						if (!otpUpdateResult) {
							logger.error("{}{}LOCKOUT_OTP: Failed to update unlockAccountTime: {}",
									sClassName, "updateUnlockTime", ESAPI.encoder().encodeForHTML(String.valueOf(otpUpdateResult)));
							return otpUpdateResult;
						}

					}
				}
			}else{
				logger.warn("{}{}LOCKOUT_OTP: No unlock minutes configured for identificationType {}. Check property {}.",
						sClassName, "updateUnlockTime", sIdentificationType, propOtpUnlockAccountMinutes);
				throw new ServiceException(ErrorMessages.MS_MPSYS_BE_602,"Unlock minutes not configured for identificationType: " + sIdentificationType);
			}
		}catch (Exception nfe) {
					logger.error("{}{}LOCKOUT_OTP: Invalid unlock minutes for identificationType {}: {}", sClassName,
							"updateUnlockTime", CommonUtilHelper.sanitizeForLog(sIdentificationType), CommonUtilHelper.sanitizeForLog(unlockMinutesStr));
				throw nfe;
				}
		return otpUpdateResult;
		}



	/**
	 * Parses the  property into a HashMap for identificationType lookup.
	 * Example property value: "IdentificationType:360|cust:360"
	 * Result: {"custS"=>"360", "custE"=>"360"}
	 * @return HashMap<String, String> mapping identificationType to unlock minutes
	 */
	public HashMap<String, String> parseOtpUnlockAccountMinutes() {
		HashMap<String, String> result = new HashMap<>();
		if (propOtpUnlockAccountMinutes != null && !propOtpUnlockAccountMinutes.trim().isEmpty()) {
			String[] pairs = propOtpUnlockAccountMinutes.split("\\|");
			for (String pair : pairs) {
				String[] parts = pair.split(":");
				if (parts.length == 2) {
					String key = parts[0].trim();
					String value = parts[1].trim();
					if (!key.isEmpty() && !value.isEmpty()) {
						result.put(key, value);
					}
				}
			}
		}
		return result;
	}

	/**
	 * Performs SIM swap validation using the CG V4 API.
	 *
	 * <p>
	 * Calls {@code CGApiRestClient.getCustomerDetailsByAccountId} with the delivery detail (CTN)
	 * to retrieve subscriber and account information. Extracts the SIM swap date and account creation
	 * date from the V4 response, then applies aging and date-comparison checks to determine if the
	 * SIM was recently swapped.
	 * </p>
	 *
	 * <p>
	 * Returns a {@code sResponseCode} string, matching the V2 flow behavior:
	 * <ul>
	 *   <li>{@code ERR_SIM_NOT_YET_ELIGIBLE_MSG} — SIM was recently swapped</li>
	 *   <li>{@code ERR_SIM_DATE_MISSING_MSG} — SIM swap date or account creation date is missing</li>
	 *   <li>{@code COMMON_SUCCESS_MSG} — SIM check passed (aged or dates match)</li>
	 *   <li>empty string — CG V4 response was null/empty or no subscriber data found</li>
	 * </ul>
	 * </p>
	 *
	 * @param sDBDeliveryDetail the CTN (phone number) used as the delivery detail
	 * @param hmInput the original input HashMap containing account type and other request data
	 * @return a sResponseCode string indicating the SIM check result
	 * @throws ServiceException if the CG V4 API call throws a ServiceException
	 */
	private String performSimSwapV4Check(String sDBDeliveryDetail, Map<String, Object> hmInput) {
		String sMethodName = "performSimSwapV4Check.";
		String stAppInfo = null;
		String sResponseCode = "";

		// Step 1: Build CG V4 API request with wireless account type and CTN as phone number
		HashMap<String, Object> cgInput = new HashMap<>();
		cgInput.put("accountType", "wireless");
		cgInput.put("phoneNumber", sDBDeliveryDetail);

		logger.info("{}{}VPH_10_V4 : Calling CGApiRestClient.getCustomerDetailsByAccountId with input: {}",
				sClassName, sMethodName, cgInput);

		// Step 2: Call CG V4 API to fetch customer/subscriber details
		// ServiceException is re-thrown to the caller; generic exceptions set sResponseCode and return
		CustomerV4Response customerV4Response;
		try {
			customerV4Response = cgApiRestClient.getCustomerDetailsByAccountId(cgInput);
		} catch (ServiceException se) {
			logger.error("{}{}VPH_12_V4 : CGApiRestClient.getCustomerDetailsByAccountId() threw ServiceException for CTN: {} : {}",
					sClassName, sMethodName, ESAPI.encoder().encodeForHTML(sDBDeliveryDetail), se.getMessage());
			throw se;
			} catch (Exception e) {
			stAppInfo = "Exception while calling CGApiRestClient.getCustomerDetailsByAccountId() for CTN: " + sDBDeliveryDetail;
			logger.error("{}{}VPH_13_V4 :: {} : {}", sClassName, sMethodName, stAppInfo, e.getMessage(), e);
			throw new ServiceException(ErrorMessages.MS_MPSYS_BE_602, stAppInfo);
		}

		logger.info("{}{}VPH_11_V4 : Response from CGApiRestClient.getCustomerDetailsByAccountId: {}",
				sClassName, sMethodName, customerV4Response);

		// Step 3: Validate CG V4 response — if null or missing individual data, treat as subscriber not found
		if (customerV4Response == null || customerV4Response.getIndividual() == null) {
			stAppInfo = "Response from CGApiRestClient.getCustomerDetailsByAccountId() is null or empty";
			logger.info("{}{}VPH_14_V4 :: {}", sClassName, sMethodName, stAppInfo);
			throw new ServiceException(ErrorMessages.MS_MPSYS_BE_100, stAppInfo);
		}

		// Step 4: Extract subscriber-level SIM swap details from the V4 response using CGUtilHelper
		Map<String, Map<String, Object>> hmAllSubscriberDetails =
				cgUtilHelper.extractSubscriberDetailsFromV4Response(customerV4Response);

		// Step 5: Retrieve SIM swap info for the specific CTN (delivery detail)
		Map<String, Object> hmSubscriberDetails = hmAllSubscriberDetails.get(sDBDeliveryDetail);

		//DUOIdentifier check
		String duoIdentifier = (String) Optional.ofNullable(hmSubscriberDetails)
				.map(info -> info.get(Constants.DUO_IDENTIFIER))
				.orElse(null);

		if ( Constants.DUO_IDENTIFIER_COMPANION.equalsIgnoreCase(duoIdentifier)) {
			stAppInfo = "DUO companion CTN is not eligible for ValidatePIN";
			logger.info("{}{}VPH_14.1_V4 :: {}", sClassName, sMethodName, stAppInfo);
			throw new ServiceException(ErrorMessages.MS_MPSYS_BE_100, stAppInfo);
		}
		// Step 6: Extract SIM effective date (simSwapDateValue) from the subscriber's SIM swap info
		String sSIMEffectiveDate = (String) Optional.ofNullable(hmSubscriberDetails)
				.map(info -> info.get( Constants.SIM_SWAP_DATE_VALUE))
				.orElse(null);

		// Step 7: Extract account creation date from the first account in the V4 response
		String accountCreatedOn = null;
		if (customerV4Response.getIndividual().getAccounts() != null
				&& !customerV4Response.getIndividual().getAccounts().isEmpty()) {
			accountCreatedOn = customerV4Response.getIndividual().getAccounts().get(0).getCreatedOn();
		}

		logger.info("{}{}VPH_15_V4 : sSIMEffectiveDate={}, accountCreatedOn={} for CTN: {}",
				sClassName, sMethodName, CommonUtilHelper.sanitizeForLog(sSIMEffectiveDate),
				CommonUtilHelper.sanitizeForLog(accountCreatedOn), CommonUtilHelper.sanitizeForLog(sDBDeliveryDetail));

		// Step 8: Perform SIM aging check only when the SIM effective date is available
		if (sSIMEffectiveDate != null && !sSIMEffectiveDate.isEmpty()) {

			// Step 8a: Normalize the SIM effective date to legacy format (yyyy-MM-dd) for consistent comparison, regardless of source format (ISO 8601 vs legacy)

			sSIMEffectiveDate = normalizeDateToLegacy(sSIMEffectiveDate);
			String sDateFormat = Constants.DATE_FORMAT_DATE_ONLY;
			// Step 8b: Check if SIM swap date has aged past the configured threshold (propSIMActiveDays)
			if (checkAging(sSIMEffectiveDate, propSIMActiveDays, sDateFormat)) {
				logger.debug("{}{}VPH_16_V4 : simEffectiveDate:: {} is more than {} days for CTN :: {} ",
						sClassName, sMethodName, sSIMEffectiveDate, propSIMActiveDays, sDBDeliveryDetail);
				stAppInfo = "SUCCESS";
				sResponseCode = CommonDefs.COMMON_SUCCESS_MSG;
			} else {
				// Step 8c: SIM is NOT aged — the account creation date is required to compare against the SIM effective date.
				// Guard against a null/empty createdOn here to avoid a NullPointerException on normalization/comparison.
				if (accountCreatedOn == null || accountCreatedOn.isEmpty()) {
					stAppInfo = "createdOn value is null for CTN :: " + sDBDeliveryDetail;
					logger.info("{}{}VPH_16.1_V4 :: createdOn value is null for CTN :: {}", sClassName, sMethodName, CommonUtilHelper.sanitizeForLog(sDBDeliveryDetail));
					throw new ServiceException(ErrorMessages.MS_MPSYS_BE_610, stAppInfo);
				}
				accountCreatedOn = normalizeDateToLegacy(accountCreatedOn);
				if (compareAcctAndSIMEffectDate(accountCreatedOn, sSIMEffectiveDate, sDateFormat)) {
					stAppInfo = "SIM changed recently for CTN :: " + sDBDeliveryDetail;
					sResponseCode = CErrorDefs.ERR_SIM_NOT_YET_ELIGIBLE_MSG;
					logger.info("{}{}VPH_17.1_V4 :: {}", sClassName, sMethodName, stAppInfo);
				} else {
					stAppInfo = "SUCCESS";
					sResponseCode = CommonDefs.COMMON_SUCCESS_MSG;
					logger.info("{}{}VPH_17.2_V4 :: {}", sClassName, sMethodName, stAppInfo);
				}
			}
		} else {
			// Step 9: SIM swap date is missing
			stAppInfo = "simEffectiveDate is null from CG V4 response for CTN :: " + sDBDeliveryDetail;
			logger.info("{}{}VPH_18_V4 :: {}", sClassName, sMethodName, stAppInfo);
			stAppInfo = "sim related dates missing for CTN:: " + sDBDeliveryDetail;
			sResponseCode = CErrorDefs.ERR_SIM_DATE_MISSING_MSG;
		}

		// Step 10: Return sResponseCode — caller continues the same downstream flow as V2
		return sResponseCode;
	}


	/**
	 * Normalizes a date string to date-only format ({@code yyyy-MM-dd}) regardless of the source format.
	 *
	 * <p>
	 * Handles multiple date formats that may arrive from different SORs:
	 * <ul>
	 *   <li>ISO 8601 with timezone (e.g., {@code "2024-01-15T10:30:00.123Z"}) - BSSE/CG format</li>
	 *   <li>Legacy with timestamp (e.g., {@code "2024-01-15 10:30:00"}) - Legacy format</li>
	 *   <li>Date-only (e.g., {@code "2024-01-15"}) - Already normalized</li>
	 * </ul>
	 * Since all downstream date comparisons ({@code checkAging}, {@code compareAcctAndSIMEffectDate})
	 * operate at date granularity only, the time component is safely discarded.
	 * </p>
	 *
	 * @param dateStr the date string to normalize; may be any supported format
	 * @return date string in {@code yyyy-MM-dd} format, or original string if null/blank or unparseable
	 */
	private String normalizeDateToLegacy(String dateStr) {
		String sMethodName = "normalizeDateToLegacy.";
		if (dateStr == null || dateStr.trim().isEmpty()) {
			logger.warn("{}{}VPH_NDL_1 : Input date string is null or empty.", sClassName, sMethodName);
			return dateStr;
		}

		String normalizedDate = dateStr;

		try {
			// Pattern 1: ISO 8601 format with 'T' separator (e.g., "2024-01-15T10:30:00.123Z")
			if (dateStr.contains("T") && dateStr.length() >= 10) {
				normalizedDate = dateStr.substring(0, 10);
				logger.debug("{}{}VPH_NDL_2 : ISO 8601 format detected, extracted date-only: {}",
						sClassName, sMethodName, StringEscapeUtils.escapeJava(normalizedDate));
			}
			// Pattern 2: Legacy format with space separator (e.g., "2024-01-15 10:30:00")
			else if (dateStr.contains(" ") && dateStr.length() >= 10) {
				normalizedDate = dateStr.substring(0, 10);
				logger.debug("{}{}VPH_NDL_3 : Legacy timestamp format detected, extracted date-only: {}",
						sClassName, sMethodName, StringEscapeUtils.escapeJava(normalizedDate));
			}
			// Pattern 3: Already date-only format (e.g., "2024-01-15") - validate length
			else if (dateStr.length() == 10) {
				normalizedDate = dateStr;
				logger.debug("{}{}VPH_NDL_4 : Date-only format detected, no conversion needed: {}",
						sClassName, sMethodName, StringEscapeUtils.escapeJava(normalizedDate));
			}
			// Pattern 4: Unexpected format - log warning and return as-is
			else {
				logger.warn("{}{}VPH_NDL_5 : Unexpected date format, returning original: {}",
						sClassName, sMethodName, StringEscapeUtils.escapeJava(dateStr));
			}
		} catch (Exception e) {
			logger.error("{}{}VPH_NDL_6 : Exception normalizing date '{}': {}",
					sClassName, sMethodName, StringEscapeUtils.escapeJava(dateStr), StringEscapeUtils.escapeJava(e.getMessage()), e);
			return dateStr;
		}

		return normalizedDate;
	}

	/**
	 * Compares the account created-on date with the SIM effective date.
	 *
	 * <p>
	 * Returns {@code true} when both dates are present and they are not equal; otherwise returns {@code false}.
	 * Any parsing or comparison errors are swallowed and logged.
	 * </p>
	 *
	 * @param accountCreatedOn the account created-on date string
	 * @param sSIMEffectiveDate the SIM effective date string
	 * @param sDateFormat the date format used to parse both dates
	 * @return {@code true} if the parsed dates are not equal; {@code false} otherwise
	 */
	private boolean compareAcctAndSIMEffectDate(String accountCreatedOn, String sSIMEffectiveDate, String sDateFormat) {
		String sMethodName = "compareAcctAndSIMEffectDate";
		boolean bAcctSIMDateNotSame = false;
		try {
			if (accountCreatedOn != null && sSIMEffectiveDate != null) {
				SimpleDateFormat dateFormat = new SimpleDateFormat(sDateFormat);
				Date createdOnDate = dateFormat.parse(accountCreatedOn);
				Date simEffectiveDate = dateFormat.parse(sSIMEffectiveDate);
				if (!createdOnDate.equals(simEffectiveDate)) {
					logger.info("{}{}VPH_CC_1: Dates are not equal.", sClassName, sMethodName);
					bAcctSIMDateNotSame = true;
				}
			}
		} catch (Exception e) {
			logger.error("{}{}VPH_CC_2: Exception occurred while comparing dates: {}", sClassName, sMethodName, e.getMessage());
		}
		return bAcctSIMDateNotSame;
	}

	/**
	 * Checks if a given date has aged a specified number of days.
	 *
	 * @param sAgingFieldDate The date to check, in string format (expected format: yyyy-MM-dd).
	 * @param sNumOfDays The number of days to check against.
	 * @param sDateFormat The format of the date string (should be "yyyy-MM-dd" for normalized dates).
	 * @return true if the date has aged the specified number of days, false otherwise.
	 */
	private boolean checkAging(String sAgingFieldDate, String sNumOfDays, String sDateFormat) {

		String sMethodName = "checkAging";
		boolean bInputFieldAged = false;

		try {
			if (sAgingFieldDate != null && !sAgingFieldDate.isEmpty()) {
				logger.info("{}{}VPH_CA_1 : Input: {} : {}",
						sClassName, sMethodName, sAgingFieldDate, sNumOfDays);

				int iAgingDays = 0;
				if (sNumOfDays != null && !sNumOfDays.isEmpty()) {
					iAgingDays = Integer.parseInt(sNumOfDays);
				}

				// Parse input date using DateTimeFormatter for consistency
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern(sDateFormat);
				LocalDate inputDate = LocalDate.parse(sAgingFieldDate, formatter);

				// Calculate the date after adding aging days to input date
				LocalDate agedDate = inputDate.plusDays(iAgingDays);

				// Get current system date in GMT
				LocalDate systemDate = LocalDate.now(ZoneId.of("GMT"));

				logger.info("{}{}VPH_CA_2 : agedDate= {}", sClassName, sMethodName, agedDate);
				logger.info("{}{}VPH_CA_3 : systemDate= {}", sClassName, sMethodName, systemDate);

				// Check if aged date is before system date (meaning the input date has aged past threshold)
				if (agedDate.isBefore(systemDate)) {
					bInputFieldAged = true;
				}
			}
		} catch (Exception exp) {
			logger.info("{}{}VPH_CA_4 : Exception : {}", sClassName, sMethodName, exp.getMessage());
		}
		logger.info("{}{}VPH_CA_5 : bInputFieldAged: {}", sClassName, sMethodName, bInputFieldAged);

		return bInputFieldAged;
	}

	/**
	 * This method is used to update the IDM Cosmos DB with the results of the account validation.
     * This method updates the ValidatePinInfoBean in CosmosDB with the provided input and result maps.
	 *
	 * @param hmCosmosInput A map containing input data for the CosmosDB update.
	 * @param hmResult A map containing the result of the validation process.
	 * @return A HashMap containing the response from the CosmosDB update operation.
	 */
	public HashMap updateIDMCosmosDB(Map<String, Object> hmCosmosInput, Map<String, Object> hmResult)
	{
		String sMethodName = ".updateIDMCosmosDB.";
		HashMap<String, Object> hmResponse = null;
		logger.info(SpiMarker.getInstance(), "ValidatePINHelper.updateIDMCosmosDB.000 : Input Hash :", StructuredArguments.entries(hmCosmosInput));
		
		String sAuthenticationMethod = null, sStatus = null, sFailureReason = null, sDeliveryMethod = null, sDeliveryDetail = null;
		ValidatePinInfoBean vbean = new ValidatePinInfoBean();
		
		String stAppCategoryCode = (String)hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE);
		String stAppStatusmsg = (String)hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG);
		String stAppInfo = (String)hmResult.get(CommonDefs.COMMON_APP_INFO);
		
		
		if (stAppCategoryCode.equals(CommonDefs.COMMON_SUCCESS)) {
			sStatus = "SUCCESS";
		}
		else if (stAppCategoryCode.equals("2"))
		{
			sStatus = "FAILURE";			
			sFailureReason= new StringBuilder("SYSTEM:").append(stAppStatusmsg).append(":").append(stAppInfo).toString();
		}
		else if (stAppCategoryCode.equals("3"))
		{
			sStatus = "FAILURE";			
			sFailureReason= new StringBuilder("DATA:").append(stAppStatusmsg).append(":").append(stAppInfo).toString();
		}

		
		vbean.setSessionId((String) hmCosmosInput.get("sessionId"));
		vbean.setAccountNumber((String) hmCosmosInput.get(CommonDefs.ACCOUNT_ID));
		vbean.setAccountType((String) hmCosmosInput.get(CommonDefs.ACCOUNT_TYPE));
		if (hmCosmosInput.containsKey(CommonDefs.DELIVERY_METHOD) && hmCosmosInput.containsKey(CommonDefs.DELIVERY_METHOD_VALUE))
		{
			sDeliveryMethod = (String) hmCosmosInput.get(CommonDefs.DELIVERY_METHOD);
			sDeliveryDetail = (String) hmCosmosInput.get(CommonDefs.DELIVERY_METHOD_VALUE);
			
			if (sDeliveryMethod.equalsIgnoreCase("E")) {
			vbean.setAuthenticationMethod("OTPEMAIL");
			vbean.setEmailAddress(sDeliveryDetail);
			}
			else if (sDeliveryMethod.equalsIgnoreCase("S")) {
			vbean.setAuthenticationMethod("OTPSMS");
			vbean.setPhoneNumber(sDeliveryDetail);
			}
		}
		else if(sStatus.equalsIgnoreCase("FAILURE"))
		{
			vbean.setAuthenticationMethod("OTP");
		}
		vbean.setChannel((String) hmCosmosInput.get(CommonDefs.CALLING_SYSTEM_ID));
		vbean.setFailureReason(sFailureReason);
		vbean.setStatus(sStatus);
		try {
			logger.info("{}{}EXT000:Updating CosmosDB with ValidatePinInfo request: {}",
					StringUtils.normalizeSpace(sClassName), StringUtils.normalizeSpace(sMethodName),
					StringUtils.normalizeSpace(CommonUtilHelper.objectToString(vbean)));
			cosmosDataStore.PersistValidatePinInfoToDatabase(vbean);
			hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
		}
		catch(Exception e) {
			hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown updateIDMCosmosDB method : " + hmResponse;
			logger.error("{}{} updateIDMCosmosDB : {}",sClassName , sMethodName , stAppInfo);
		}
			return hmResponse;
		}

	private void saveOtpHistoryAsync(String identificationType, String accountId, String callingSystemId, Operation operation) {
		CompletableFuture.runAsync(() -> {
			try {
				IdgOtpContainerHistory.IdgOtpContainerHistoryBuilder builder = IdgOtpContainerHistory.builder()
						.id(UUID.randomUUID().toString())
						.accountId(accountId)
						.identificationType(identificationType)
						.updatedBy(callingSystemId)
						.historyMetadata(HistoryMetadata.builder()
								.operation(operation)
								.source(OTP_HISTORY_SOURCE)
								.timestamp(com.att.idp.idgraph.db.cosmos.util.DateUtil.getUTCNow())
								.build());

				if (operation == Operation.UPDATE) {
					try {
						IdgOtpContainer query = new IdgOtpContainer();
						query.setIdentificationType(identificationType);
						query.setAccountId(accountId);
						Optional<IdgOtpContainer> container = idgOtpDBHelper.findByIdentificationTypeAndAccountId(query);
						if (container.isPresent() && container.get().getSecurityCodes() != null) {
							builder.securityCodes(container.get().getSecurityCodes());
						}
					} catch (Exception e) {
						logger.warn("Failed to read OTP container for history snapshot: {}", e.getMessage());
					}
				}

				otpHistoryDBHelper.saveOtpHistory(builder.build());
			} catch (Exception e) {
				logger.error("Failed to save OTP history asynchronously for accountId: {}: {}",
						accountId, StringEscapeUtils.escapeJava(e.getMessage()), e);
			}
		}, otpHistoryExecutor);
	}

	/**
	 * This method is responsible for retrieving the OTP data source from the feature manager.
	 *
	 * It checks if the feature manager has a value for the key "cfg-idgraph-contactinfo-otpdatasource".
	 * If the value is found, it returns that value.
	 * If the value is not found (i.e., it is null), it sets a default value of "COSMOSMASTER" and logs an error message.
	 *
	 * @return a String representing the OTP data source.
	 */
	public String getOtpDataSource() {
		String otpDataSource = featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource");
		if (otpDataSource == null) {
			otpDataSource = "COSMOSMASTER";
			logger.error("IXP Flag cfg-idgraph-contactinfo-otpdatasource is null, setting default value {} ", otpDataSource);
		}
		else if (!("ORACLEMASTER".equalsIgnoreCase(otpDataSource)
				|| "ONLYORACLE".equalsIgnoreCase(otpDataSource)
				|| "ONLYCOSMOS".equalsIgnoreCase(otpDataSource)
				|| "COSMOSMASTER".equalsIgnoreCase(otpDataSource))) {
			throw new IllegalArgumentException("Invalid OTP data source: " + otpDataSource);
		}
		return otpDataSource;
	}

}

