package com.att.idp.idgraphcontactinfoms.utils;

/*
 * The Constants class contains constant values used in the ID Graph Contact Info Microservice.
 *
 */
public class Constants {
    public static final String IDGRAPH_CONTACT_INFO_MS_IB = "IDGRAPH_CONTACT_INFO_MS_IB";
    public static final String IDGRAPH_CONTACT_INFO_MS_OB = "IDGRAPH_CONTACT_INFO_MS_OB";
    public static final String IDGRAPH_CONTACT_INFO_MS_DB_ERR = "IDGRAPH_CONTACT_INFO_MS_DB_ERR";
    public static final String CREATED_ON = "createdOn";
    public static final String CONTACT = "contact";
    public static final String SKIP_AGING_RULE_FLAG = "skipAgingRuleFlag";
    public static final String CBR_CTN_LIST = "CBRCTNList";
    public static final String EMAIL_ADDR_LAST_UPDATE_TS = "EmailAddrLastUpdateTs";
    public static final String ESTABLISH_DATE = "establishDate";
    public static final String SIM_SWAP_DATE_TIME = "simSwapDateTime";
    public static final String UVERSE_MEMBER_EMAIL_ADDRESS = "UverseMemberEmailAddress";
    public static final String UVERSE_EMAIL_ESTABLISHED_DATE = "UverseEmailEstablishedDate";
    public static final String UVERSE_EMAIL_STATUS = "UverseEmailStatus";
    public static final String ADDRESS = "address";
    public static final String POST_CODE = "postCode";
    public static final String LAST_UPDATE = "lastUpdate";
    public static final String PRIMARY_PHONE_VALIDATION_STATUS = "phoneNumberValidationStatus";
    public static final String SECONDARY_PHONE_VALIDATION_STATUS = "secondaryPhoneNumberValidationStatus";
    public static final String NEW_CPNI_ELIGIBILITY_RULE = "NewCPNIEilibilityRule";
    public static final String CONTACT_STATUS_VERIFIED = "V"; // phone/email verified status
    public static final String SERVICE_TYPE_UVERSE = "uverse";
    public static final String CLIENT_ID_CSIGATEWAY = "CSIGATEWAY";
    public static final String IDENTIFICATION_TYPE_BANPC = "BANPC";
    public static final String IDENTIFICATION_TYPE_NTRETAILER = "NTRETAILER";
    public static final String MOBILE_DEVICE_GROUP = "mobileDevice";
    public static final String SMS_CAPABILITY ="SMS_CAPABILITY";
    public static final String LAST_SW_ACTVDATE ="LAST_SW_ACTVDATE";
    public static final String TARGET_SOR_CG = "CG";
    public static final String DATE_TIME_FORMAT_BSSE = "yyyy-MM-dd'T'HH:mm:ss.SSSX";
    public static final String DATE_TIME_FORMAT_LEGACY = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE_FORMAT_DATE_ONLY = "yyyy-MM-dd";
    public static final String ACCOUNT_TYPE_B = "B";
    public static final String EXPLOITABLE= "exploitable";
    public static final String INDIVIDUAL_ID= "individualId";
    public static final String SUBSCRIBER_NUMBER= "subscriberNumber";
    public static final String PHONE_NUMBER= "phoneNumber";
    public static final String RETURN_BIZ_CTNS= "returnBizCTNs";
    public static final String IDP_TRACE_ID= "idp-trace-id";
    public static final String SMS_CAPABILITY_IND = "smsCapabilityInd";
    public static final String SIM_SWAP_DATE_VALUE = "simSwapDateValue";
    public static final String DUO_IDENTIFIER_COMPANION = "companion";
    public static final String DUO_IDENTIFIER = "duoIdentifier";

    public static final String CC_MULE_POSTAL = "POSTAL";
    public static final String CLM_ADDRESSES = "addresses";
    public static final String CLM_ADDRESS_CLASSIFICATION = "addressClasification";
    public static final String CLM_ADDRESS_CLASSIFICATION_SERVICE = "SERVICE";
    public static final String COUNTRY_USA = "USA";
    public static final String CLM_AO_TN = "aoTn";
    public static final String CLM_ADDRESS_NAME = "name";

}
