package com.att.idp.idgraphcontactinfoms.resource.request;

import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.request package.
 *
 * The DeletePINRequest class is used to represent a request to delete a PIN.
 * It contains several fields, each of which represents a parameter of the request.
 * These fields include callingSystemId, transactionName, accountId, identificationType, deleteAll, securityCode, reasonCode, agentId, idpTraceId, and unknownAttributes.
 *
 * Each field is annotated with @Size and/or @NotNull, indicating that they are required fields and have size constraints.
 * The messages associated with these annotations provide additional information about the requirements for each field.
 *
 * The class provides a map of unknownAttributes, which can be used to store any additional attributes that are not part of the other fields.
 * The unknownAttributes map is annotated with @JsonAnySetter and @JsonAnyGetter, allowing it to be included in JSON serialization and deserialization.
 *
 * The class also overrides the toString method, providing a custom string representation of the object.
 */
@Schema(name = "DeletePINRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class DeletePINRequest {
	
	@Size(min = 1, max = 20, message =  "CallingSystemId length is invalid|DeletePIN")
	private String callingSystemId;
	
	private final String transactionName = "DeletePIN";
	
	@Schema(name = "accountId")
	@NotNull(message="AccountId is required in input request.|DeletePIN")
	@Size(min=1, max=60, message="AccountId length is invalid|DeletePIN")
	private String accountId;
	
	@Schema(name = "identificationType")
	@NotNull(message="IdentificationType is required in input request.|DeletePIN")
	@Size(min=1, max=10, message="IdentificationType length is invalid|DeletePIN")
	private String identificationType;
	
	@Schema(name = "channel")
	@Size(min = 1, max = 40, message =  "channel length is invalid|DeletePIN")
	protected String channel;
	
	@Schema(name = "deleteAll")
	@NotNull(message="DeleteAll is required in input request.|DeletePIN")
	@Size(min=1, max=1, message="DeleteAll length is invalid|DeletePIN")
	private String deleteAll;
	
	@Schema(name = "securityCode")
	@Size(min=1, max=20, message="SecurityCode length is invalid|DeletePIN")
	private String securityCode;
	
	@Schema(name = "reasonCode")
	@Size(min=1, max=10, message="ReasonCode length is invalid|DeletePIN")
	private String reasonCode;
	
	@Schema(name = "agentId")
	@Size(min=1, max=20, message="AgentId length is invalid|DeletePIN")
	private String agentId;
	
//	@Schema(name = "transactionId")
//	private String transactionId;
	
	@Schema(name = "idpTraceId")
	private String idpTraceId;

	/**
	 * This field represents a map of unknown attributes.
	 *
	 * The unknownAttributes map is used to store any additional attributes that are not part of the attributeName and attributeValue fields.
	 * It is initialized as a new HashMap.
	 *
	 * The field is annotated with @JsonAnySetter and @JsonAnyGetter, allowing it to be included in JSON serialization and deserialization.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();

	@Override
	public String toString() {
		return "DeletePINRequest [callingSystemID=" + callingSystemId + ", transactionName=" + transactionName
				+ ", accountId=" + accountId + ", identificationType=" + identificationType + ", deleteAll=" + deleteAll
				+ ", securityCode=" + securityCode + ", reasonCode=" + reasonCode + ", agentId=" + agentId
				+ ", idpTraceId=" + idpTraceId + "]";
	}

	
}
