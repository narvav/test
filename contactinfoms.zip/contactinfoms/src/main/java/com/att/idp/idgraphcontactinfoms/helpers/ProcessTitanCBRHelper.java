package com.att.idp.idgraphcontactinfoms.helpers;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;

/**
 * This class is a helper class for processing Titan CBR information.
 *
 * It contains methods for processing Titan CBR information based on the input parameters.
 * The class uses the Spring Framework's @Component annotation to indicate that it is a bean and can be used for dependency injection.
 *
 * The class has an instance variable oQueryProfileProofingInfoH that is injected using the @Autowired annotation.
 * This variable is used to interact with the QueryProfileProofingInfoHelper to query CRM proofing information.
 *
 * The main method in this class is the processTitanCBRInfo method, which takes a HashMap as input and returns a HashMap as output.
 * The processTitanCBRInfo method uses several other methods in the class to validate the input data, process the input data, and store the data.
 *
 * The class also contains a logger for logging information and error messages.
 */
@Component
public class ProcessTitanCBRHelper {

	@Autowired
	private QueryProfileProofingInfoHelper oQueryProfileProofingInfoH;

	private static String sClassName = "ProcessTitanCBRHelper";
	public static final Logger logger = LoggerFactory.getLogger(ProcessTitanCBRHelper.class);

	/**
	 * This method processes Titan CBR information based on the input parameters.
	 *
	 * It first retrieves the account invariant ID list, transaction name, calling system ID, and transaction ID from the input HashMap.
	 * Then, it iterates over the account invariant ID list and for each account invariant ID, it constructs a new HashMap for the QueryProfileProofingInfoHelper input.
	 * It populates the new HashMap with the transaction ID, transaction name, calling system ID, and account invariant ID.
	 * It then calls the QueryProfileProofingInfoHelper's queryCRMProofingInfo method with the new HashMap as input.
	 * The method checks the response from the QueryProfileProofingInfoHelper. If the response indicates an error, the method constructs an error response and returns it.
	 * If the response from the QueryProfileProofingInfoHelper indicates success, the method parses the Titan CBR information and adds it to a phone list.
	 * Finally, it constructs a success response with the phone list and returns it.
	 *
	 * @param hmInput a HashMap that contains the input data for the Titan CBR information processing. The HashMap should include the account invariant ID list, transaction name, calling system ID, and transaction ID.
	 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code, an application info message, and the processed Titan CBR information.
	 * @throws Exception if an error occurs during the operation.
	 */
	public HashMap processTitanCBRInfo(HashMap hmInput) {

		String sMethodName = ".processTitanCBRInfo.";

		logger.info("{}{}HLP000 : Input Hash : {}", sClassName, sMethodName, hmInput);
		HashMap<String, Object> hmResponse = null;
		ArrayList alAllPhoneList = new ArrayList();
		HashMap<String, Object> hmAccountContacts = CommonUtil.getHashMap();
		String stAppInfo = null;
		String stAppStatusCode = null;

		try {

			ArrayList<String> alAcctSorInvId = (ArrayList) hmInput.get("accountInvariantIdList");
			String sTransactionName = (String) hmInput.get(CommonDefs.TRANSACTION_NAME);
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);

			for (String sAcctSorInvId : alAcctSorInvId) {

				HashMap<String, String> hmCRMInp = CommonUtil.getHashMap();
				hmCRMInp.put(CommonDefs.TRANSACTION_ID, sTransactionId);
				hmCRMInp.put(CommonDefs.TRANSACTION_NAME, sTransactionName);
				hmCRMInp.put(CommonDefs.CALLING_SYSTEM_ID, sCallingSystemId);
				hmCRMInp.put(CommonDefs.BAN, sAcctSorInvId);

				logger.info("{}{}PTCI_04.1 : Calling QueryProfileProofingInfo_H with Input: {}", sClassName,
						sMethodName, hmCRMInp);
				HashMap<String, Object> hmGetAuthInfoResp = oQueryProfileProofingInfoH.queryCRMProofingInfo(hmCRMInp);
				logger.debug("{}{}PTCI_04.2 : Response from QueryProfileProofingInfo_H : {}", sClassName, sMethodName,
						hmGetAuthInfoResp);

				if (hmGetAuthInfoResp == null || hmGetAuthInfoResp.isEmpty()) {
					stAppInfo = "QueryProfileProofingInfo_H returned null response.";
					logger.info("{}{}PTCI_04.3 : {}", sClassName, sMethodName, stAppInfo);
				}

				if (hmGetAuthInfoResp != null) {
					stAppStatusCode = (String) hmGetAuthInfoResp.get(CommonDefs.COMMON_APP_STATUS_CODE);
				}

				if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					stAppInfo = (String) hmGetAuthInfoResp.get(CommonDefs.COMMON_APP_INFO);
					logger.info("{}{}PTCI_04.4 : {}", sClassName, sMethodName, stAppInfo);
				}

				if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
					ArrayList alPhoneList = parseTitanCBRInfo(hmGetAuthInfoResp, sAcctSorInvId);

					if (alPhoneList != null && !alPhoneList.isEmpty()) {
						alAllPhoneList.addAll(alPhoneList);
					}
				}
			}

			hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

			if (!alAllPhoneList.isEmpty()) {

				hmAccountContacts.put("phoneList", alAllPhoneList);
				hmResponse.put("accountContacts", hmAccountContacts);

			} else {

				stAppInfo = "BAN not found in MPS";
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_BAN_NOT_FOUND_NUM, stAppInfo);
				logger.info("{}{}PTCI_04.7 : {}", sClassName, sMethodName, stAppInfo);

			}

		} catch (Exception e) {
			hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown ProcessTitanCBRHelper : " + hmResponse;
			logger.error("{}{}PTCI_04.5 : {}", sClassName, sMethodName, stAppInfo);

		} finally {

			stAppInfo = "Response from ProcessTitanCBRHelper = " + hmResponse;
			logger.info("{}{}PTCI_04.6 : {}", sClassName, sMethodName, stAppInfo);

			logger.info("{}{}HLP999 : hmResponse = {}", sClassName, sMethodName, hmResponse);
		}

		return hmResponse;
	}

	private ArrayList parseTitanCBRInfo(HashMap hmGetAuthInfoResp, String sAcctSorInvId) {

		ArrayList alPhoneList = CommonUtil.getArrayList();
		HashMap<String, Object> hmCBRInfo = (HashMap<String, Object>) hmGetAuthInfoResp.get(CommonDefs.CBR_INFO);
		HashMap<String, Object> hmAltCBRInfo = (HashMap<String, Object>) hmGetAuthInfoResp.get(CommonDefs.ALT_CBR_INFO);

		if (hmCBRInfo != null && !hmCBRInfo.isEmpty()) {

			String sValidationStatusCode = (String) hmCBRInfo.get(CommonDefs.DEVICE_IN_HAND_VALIDATION_STS);
			String stPhoneModifiedDate = (String) hmCBRInfo.get(CommonDefs.PHONE_MODIFIED_DATE);
			String sPhoneType = (String) hmCBRInfo.get(CommonDefs.PHONE_TYPE);
			String sIsATTNumber = (String) hmCBRInfo.get(CommonDefs.IS_ATT_NUMBER);

			HashMap<String, Object> hmContactInfo = CommonUtil.getHashMap();
			hmContactInfo.put(CommonDefs.CONTACT_TYPE, CommonDefs.CONTACT_TYPE_PRIMARY_PHONE);
			hmContactInfo.put(CommonDefs.CONTACT_STATUS, "V");
			hmContactInfo.put(CommonDefs.KEY_SOR_NAME, CommonDefs.SOR_LS);
			hmContactInfo.put(CommonDefs.SOR_INVARIANT_ID, sAcctSorInvId);
			hmContactInfo.put(CommonDefs.VALIDATION_STATUS, sValidationStatusCode);
			hmContactInfo.put(CommonDefs.PHONE_NUMBER, hmCBRInfo.get(CommonDefs.PHONE));

			if (stPhoneModifiedDate != null && !stPhoneModifiedDate.isEmpty()) {
				stPhoneModifiedDate = formatDate(CommonDefs.PHONE_MODIFIED_DATE, stPhoneModifiedDate);
				hmContactInfo.put("dateEstablished", stPhoneModifiedDate);
			}

			if (sIsATTNumber != null && sIsATTNumber.trim().equals("0")
					&& hmCBRInfo.get(CommonDefs.SUBSCRIBER_ID) != null) {
				sIsATTNumber = "1";
			}

			hmContactInfo.put(CommonDefs.PHONE_NUMBER_TYPE, getPhoneType(sIsATTNumber, sPhoneType));
			alPhoneList.add(hmContactInfo);
		}

		if (hmAltCBRInfo != null && !hmAltCBRInfo.isEmpty()) {

			String sValidationStatusCode = (String) hmAltCBRInfo.get(CommonDefs.DEVICE_IN_HAND_VALIDATION_STS);
			String stPhoneModifiedDate = (String) hmAltCBRInfo.get(CommonDefs.PHONE_MODIFIED_DATE);
			String sPhoneType = (String) hmAltCBRInfo.get(CommonDefs.PHONE_TYPE);
			String sIsATTNumber = (String) hmAltCBRInfo.get(CommonDefs.IS_ATT_NUMBER);

			HashMap<String, Object> hmContactInfo = CommonUtil.getHashMap();
			hmContactInfo.put(CommonDefs.CONTACT_TYPE, CommonDefs.CONTACT_TYPE_SECONDARY_PHONE);
			hmContactInfo.put(CommonDefs.CONTACT_STATUS, "V");
			hmContactInfo.put(CommonDefs.KEY_SOR_NAME, CommonDefs.SOR_LS);
			hmContactInfo.put(CommonDefs.SOR_INVARIANT_ID, sAcctSorInvId);
			hmContactInfo.put(CommonDefs.VALIDATION_STATUS, sValidationStatusCode);
			hmContactInfo.put(CommonDefs.PHONE_NUMBER, hmAltCBRInfo.get(CommonDefs.PHONE));

			if (stPhoneModifiedDate != null && !stPhoneModifiedDate.isEmpty()) {
				stPhoneModifiedDate = formatDate(CommonDefs.PHONE_MODIFIED_DATE, stPhoneModifiedDate);
				hmContactInfo.put("dateEstablished", stPhoneModifiedDate);
			}

			if (sIsATTNumber != null && sIsATTNumber.trim().equals("0")
					&& hmAltCBRInfo.get(CommonDefs.SUBSCRIBER_ID) != null) {
				sIsATTNumber = "1";
			}

			hmContactInfo.put(CommonDefs.PHONE_NUMBER_TYPE, getPhoneType(sIsATTNumber, sPhoneType));
			alPhoneList.add(hmContactInfo);

		}

		return alPhoneList;
	}

	private String formatDate(String sDateKey, String sDateValue) {

		String sMethodName = ".formatDate.";
		Date dtParsedDate = null;
		String sFormattedDate = null;
		DateFormat newDtFormat = new SimpleDateFormat("MMddyyyy HH:mm:ss");
		DateFormat sdfPhoneModifiedDt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

		try {

			if (sDateKey != null && sDateKey.equals(CommonDefs.PHONE_MODIFIED_DATE)) {
				dtParsedDate = sdfPhoneModifiedDt.parse(sDateValue);
			}

			sFormattedDate = newDtFormat.format(dtParsedDate);

			logger.info("{}{}FD_01 : Formatted Date : {}", sClassName, sMethodName, sFormattedDate);

		} catch (Exception exp) {
			logger.error("{}{}ET_CPNI_H_06.11 : Exception = {}", sClassName, sMethodName, exp);
		}

		return sFormattedDate;

	}

	private String getPhoneType(String sIsATTNumber, String sPhoneType) {

		String stPhoneType = null;
		String sContactType = (String) CommonDefs.PHONE_TYPE_MAPPING.get(sPhoneType);
		if (sIsATTNumber != null && sIsATTNumber.trim().equals("0") && sContactType != null
				&& sContactType.equals(CommonDefs.PHONE_NUMBER_TYPE_MOBILE)) {
			stPhoneType = CommonDefs.PHONE_NUMBER_TYPE_MOBILE;
		} else if (sIsATTNumber != null && sIsATTNumber.trim().equals("1") && sContactType != null
				&& sContactType.equals(CommonDefs.PHONE_NUMBER_TYPE_MOBILE)) {
			stPhoneType = CommonDefs.PHONE_NUMBER_TYPE_ATTMOBILE;
		} else {
			stPhoneType = sContactType;
		}
		return stPhoneType;

	}
}
