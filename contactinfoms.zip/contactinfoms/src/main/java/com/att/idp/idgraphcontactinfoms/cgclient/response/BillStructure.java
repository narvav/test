package com.att.idp.idgraphcontactinfoms.cgclient.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
/**
 * The BillStructure class represents a bill structure in the system.
 * It is part of the com.att.idp.idgraphcontactinfoms.cgclient.response package.
 *
 * This class contains a property related to a bill structure such as presentationMedia.
 * The presentationMedia property is a list of PresentationMedia objects.
 * Each property has its corresponding getter and setter methods.
 *
 * This class is annotated with @JsonIgnoreProperties(ignoreUnknown = true) to ignore unknown properties during deserialization.
 * It is also annotated with @JsonInclude(JsonInclude.Include.NON_EMPTY) to exclude properties with empty values from serialization.
 * The @Schema(name = "BillStructure") annotation is used to provide additional metadata for Swagger.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(name = "BillStructure")
@Getter
@Setter
@NoArgsConstructor
public class BillStructure implements Serializable {

	private static final long serialVersionUID = -5786821824123354865L;

	@JsonProperty("presentationMedia")
	private List<PresentationMedia> presentationMedia;
}