package com.att.idp.idgraphcontactinfoms.db.model;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;
import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "TSECURITYACCOUNT", schema = "MPS_OWNER")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tsecurityaccount implements java.io.Serializable {

	private static final long serialVersionUID = 4571901002904040844L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "identificationType", column = @Column(name = "IDENTIFICATION_TYPE", nullable = false, length = 10)),
			@AttributeOverride(name = "accountId", column = @Column(name = "ACCOUNT_ID", nullable = false, length = 60)) })
	private TsecurityaccountId id;

	@Column(name = "ACCOUNT_TYPE", length = 1)
	private Character accountType;

	@Column(name = "ACCOUNT_REGION", length = 2)
	private String accountRegion;

	@Column(name = "CUMULATIVE_FAILURE_COUNT", nullable = false, precision = 22, scale = 0)
	private Long cumulativeFailureCount;

	@Column(name = "ACCOUNT_ENTRY_EXPIRES", nullable = false, length = 7)
	private Date accountEntryExpires;

	@Column(name = "CREATE_DATE", nullable = false, length = 7)
	private Date createDate;

	@Column(name = "LAST_MODIFIED", length = 7)
	private Date lastModified;

	@Column(name = "LAST_MODIFIED_BY", nullable = false)
	private String lastModifiedBy;

	@Column(name = "SOR_INVARIANT_ID")
	private String sorInvariantId;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tsecurityaccount")
	private Set<Tsecuritycode> tsecuritycodes = new HashSet<>(0);
}