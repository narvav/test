package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TserviceassociationId implements java.io.Serializable {

	private static final long serialVersionUID = -5846557551619813809L;

	@Column(name = "SOR_ID1", nullable = false, precision = 22, scale = 0)
	private Long sorId1;

	@Column(name = "SOR_INVARIANT_ID1", nullable = false)
	private String sorInvariantId1;

	@Column(name = "SOR_ID2", nullable = false, precision = 22, scale = 0)
	private Long sorId2;

	@Column(name = "SOR_INVARIANT_ID2", nullable = false)
	private String sorInvariantId2;


	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TserviceassociationId))
			return false;
		TserviceassociationId castOther = (TserviceassociationId) other;

		return ((this.getSorId1() == castOther.getSorId1()) || (this.getSorId1() != null
				&& castOther.getSorId1() != null && this.getSorId1().equals(castOther.getSorId1())))
				&& ((this.getSorInvariantId1() == castOther.getSorInvariantId1())
						|| (this.getSorInvariantId1() != null && castOther.getSorInvariantId1() != null
								&& this.getSorInvariantId1().equals(castOther.getSorInvariantId1())))
				&& ((this.getSorId2() == castOther.getSorId2()) || (this.getSorId2() != null
						&& castOther.getSorId2() != null && this.getSorId2().equals(castOther.getSorId2())))
				&& ((this.getSorInvariantId2() == castOther.getSorInvariantId2())
						|| (this.getSorInvariantId2() != null && castOther.getSorInvariantId2() != null
								&& this.getSorInvariantId2().equals(castOther.getSorInvariantId2())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getSorId1() == null ? 0 : this.getSorId1().hashCode());
		result = 37 * result + (getSorInvariantId1() == null ? 0 : this.getSorInvariantId1().hashCode());
		result = 37 * result + (getSorId2() == null ? 0 : this.getSorId2().hashCode());
		result = 37 * result + (getSorInvariantId2() == null ? 0 : this.getSorInvariantId2().hashCode());
		return result;
	}

}
