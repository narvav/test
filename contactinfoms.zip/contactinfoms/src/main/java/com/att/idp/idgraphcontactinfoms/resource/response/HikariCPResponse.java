package com.att.idp.idgraphcontactinfoms.resource.response;

import lombok.Data;

@Data
public class HikariCPResponse {
    public HikariCPResponse() {

    }

    private int activeConnections;
    private int idleConnections;
    private int totalConnections;
    private int threadsAwaitingConnection;
    private Threshold threshold;
    private DefaultConfig defaultConfig;



     @Data
    public static class DefaultConfig {
        private int maxConnections;
        private int minConnections;
        private long connectionTimeout;
        private long idleTimeout;
        private long maxLifetime;

        private long validationTimeout;
        private long leakDetectionThreshold;
        private int maxPoolSize;
        private int minIdle;
        private int maxIdle;

        private int initializationFailTimeout;
        }


    @Data
    public static class Threshold {

        String poolThresholdLimit;
        String poolExhaustionStatus;
    }


    @Override
    public String toString() {
        return "HikariCPResponse{" +
                "activeConnections=" + activeConnections +
                ", idleConnections=" + idleConnections +
                ", totalConnections=" + totalConnections +
                ", threadsAwaitingConnection=" + threadsAwaitingConnection +
                ", threshold=" + threshold +
                ", defaultConfig=" + defaultConfig +
                '}';
    }
}
