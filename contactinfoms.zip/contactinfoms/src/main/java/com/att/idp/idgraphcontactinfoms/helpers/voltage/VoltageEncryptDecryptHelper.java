package com.att.idp.idgraphcontactinfoms.helpers.voltage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * This class is used for encryption and decryption utilities.
 *
 * It contains methods for encrypting and decrypting values using the specified format.
 * The class interacts with the EncryptUtil and DecryptUtil to perform the encryption and decryption.
 * It is annotated with @Component, indicating that it is an autodetectable bean and can be automatically
 * picked up and instantiated by Spring's container.
 */
@Component
public class VoltageEncryptDecryptHelper {
@Autowired
private EncryptUtil encryptUtil;

@Autowired
private DecryptUtil decryptUtil;

/**
 * This method is used to encrypt a value.
 *
 * It takes two Strings as input - the value to be encrypted and the format name.
 * The method uses the EncryptUtil to encrypt the value using the specified format.
 * The encrypted value is then returned as a String.
 *
 * @param value A String containing the value to be encrypted.
 * @param formatName A String containing the name of the format to be used for encryption.
 * @return A String containing the encrypted value.
 */
	public String getEncryptedValue(String value, String formatName) {
		return encryptUtil.getEncryptedValue(value, formatName);
	}
	
	/**
	 * This method is used to decrypt a value.
	 *
	 * It takes two Strings as input - the value to be decrypted and the format name.
	 * The method uses the DecryptUtil to decrypt the value using the specified format.
	 * The decrypted value is then returned as a String.
	 *
	 * @param value A String containing the value to be decrypted.
	 * @param formatName A String containing the name of the format to be used for decryption.
	 * @return A String containing the decrypted value.
	 */
	public String getDecryptedValue(String value, String formatName) {
		return decryptUtil.getDecryptedValue(value, formatName);
	}
	
}

