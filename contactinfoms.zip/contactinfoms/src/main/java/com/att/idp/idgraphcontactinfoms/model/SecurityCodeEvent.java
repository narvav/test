package com.att.idp.idgraphcontactinfoms.model;

import com.att.idp.idgraph.events.model.JsonSealizable;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.ToString;

import java.time.Instant;

@Data
@ToString
public class SecurityCodeEvent implements JsonSealizable {
    private String securityCode;
    private String verificationFailureCount;
    @JsonFormat(
            pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            shape = JsonFormat.Shape.STRING,
            timezone = "UTC"
    )
    private Instant securityCodeExpires;
    private String securityCodeStatus;
    @JsonFormat(
            pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            shape = JsonFormat.Shape.STRING,
            timezone = "UTC"
    )
    private Instant statusChangeDate;
    private String source;
    private String deliveryMethod;
    private String deliveryDetail;
    @JsonFormat(
            pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            shape = JsonFormat.Shape.STRING,
            timezone = "UTC"
    )
    private Instant createdDate;
    @JsonFormat(
            pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            shape = JsonFormat.Shape.STRING,
            timezone = "UTC"
    )
    private Instant updatedDate;
    private String updatedBy;
}
