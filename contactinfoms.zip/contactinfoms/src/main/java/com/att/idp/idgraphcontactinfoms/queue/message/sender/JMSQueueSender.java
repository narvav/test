package com.att.idp.idgraphcontactinfoms.queue.message.sender;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import jakarta.jms.BytesMessage;
import jakarta.jms.Connection;
import jakarta.jms.Destination;
import jakarta.jms.JMSException;
import jakarta.jms.MessageProducer;
import jakarta.jms.Queue;
import jakarta.jms.Session;

import net.logstash.logback.argument.StructuredArguments;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;


import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;

import com.att.idp.logging.marker.SpiMarker;

/**
 * This class is responsible for sending messages to a JMS queue.
 *
 * It uses the Spring Framework's JmsTemplate for sending messages and handles the creation and closing of JMS connections and sessions.
 * The class also handles the conversion of the message payload from a Map to a byte array.
 *
 * The class uses the @Component annotation to indicate that it is a bean and can be used for dependency injection.
 * The class also uses the @Configuration annotation to indicate that it is a source of bean definitions.
 *
 * The class has several instance variables that are injected using the @Autowired and @Value annotations.
 * These variables are used to interact with the JmsTemplate and to store configuration values such as the queue name and queue count.
 *
 * The main method in this class is the send method, which takes a Map as input and returns a Map as output.
 * The send method handles the entire process of sending a message to the JMS queue, including error handling and logging.
 *
 * The class also contains several private helper methods for converting the message payload to a byte array, calculating the elapsed time, and hashing a string.
 */
@Configuration
@Component
public class JMSQueueSender {

	
	public static final Logger logger = LoggerFactory.getLogger(JMSQueueSender.class);
	
	@Autowired
	private JmsTemplate jmsTemplate;

	private AtomicBoolean messagePublished = new AtomicBoolean(true); // Thread-safe flag

	public boolean isMessagePublished() {
		return messagePublished.get(); // Retrieve the flag value atomically
	}




	@Value("${mq.queue.name}")
	private String mqQueueName;
	
	@Value("${mq.queue.count}")
	private int mqQueueCount;

	/**
	 * This method is responsible for sending a message to a JMS queue.
	 *
	 * It takes a Map as input, which represents the message to be sent.
	 * The method first checks if the input map is null or empty, and if so, it returns an error map.
	 * It then retrieves various values from the input map, such as the msOperation, transactionId, and mainHashKey.
	 * If any of these values are null or empty, the method returns an error map.
	 *
	 * The method then creates a JMS connection and session, and creates a queue with the appropriate name.
	 * It converts the input map to a byte array and creates a BytesMessage with the byte array.
	 * The BytesMessage is then sent to the queue.
	 *
	 * If any exceptions are caught during this process, the method returns an error map.
	 * Finally, the method closes the JMS session and connection, and returns the result map.
	 *
	 * @param hmInput The input map representing the message to be sent.
	 * @return A map representing the result of the send operation.
	 */
	public Map<String, Object> send(Map<String, Object> hmInput) {
		
		long startTm				= System.currentTimeMillis();
		Map<String, Object> hmResult = new HashMap<String, Object>();
		String appInfo = null;


		Queue queue = null;
		
		String queueName = null;

			//check if input is populated
			if(hmInput==null || hmInput.isEmpty()) {
				appInfo = "Input map is null";
				
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, appInfo);
				return hmResult;

			}
			logger.debug(SpiMarker.getInstance(),
					"JMSQueueSender.send with inputHash : {}",
					StructuredArguments.entries(hmInput));

			//get the msOperation name
			String msOperation = (String)hmInput.get("msOperation");
			if(msOperation==null || msOperation.isEmpty()){
				appInfo = "msOperation is null or empty";				

				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, appInfo);
				return hmResult;
			}
			
			//get the transactionId name
			String transactionId = (String)hmInput.get(CommonDefs.TRANSACTION_ID);
			if(transactionId==null || transactionId.isEmpty()){
				appInfo = "transactionId is null or empty";				

				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, appInfo);
				return hmResult;
			}


			//get the mainHashKey
			String mainHashKey = (String)hmInput.get("mainHashKey");
			if(mainHashKey==null || mainHashKey.isEmpty()){
				appInfo = "mainHashKey is null or empty";

				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, appInfo);
				return hmResult;
			}
			
			//get queue name
			logger.debug(" 1. queueName=" + mqQueueName);
			
			if(mqQueueName==null || mqQueueName.isEmpty()) {
				appInfo = "queueName value not found in property";
				
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EMPTY_NUM, appInfo);
				return hmResult;
			}
			
			

			//get the hashCount
			int iHash = hash(mainHashKey, mqQueueCount);			
			logger.debug("queue hash=" + iHash);			
			
			//set queue name
			queueName = mqQueueName + "." + iHash;

			try(Connection conn = (Connection) jmsTemplate.getConnectionFactory().createConnection();
			Session session 	= (Session) conn.createSession(false, Session.AUTO_ACKNOWLEDGE);){
			
			queue = session.createQueue(queueName);
			Destination destination = session.createQueue(queue.getQueueName());
			logger.info("Destination[" + queue.getQueueName() + "] created");
						
			//convert map to byte
			byte[] inputBytes = convertToBytes(logger, hmInput);
			
			if(inputBytes==null) {
				appInfo = "Failed to convert input to bytes";

				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, appInfo);
				return hmResult;
				
			}
			logger.debug("msg length=" + inputBytes.length);
			
			
			BytesMessage bMsg = session.createBytesMessage();
			bMsg.writeBytes(inputBytes);
			bMsg.setJMSCorrelationID(transactionId);
//			bMsg.setJMSMessageID(transactionId);
			MessageProducer msgProducer =session.createProducer(destination);
			
			String sentInfo = sendmessagetoQueue(msgProducer, bMsg);
			/*
			 * msgProducer.send(bMsg); 
			 * appInfo = "Message " + msOperation + " sent successfully";
			 */
			
			appInfo = msOperation +" "+ sentInfo;

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, appInfo);
			
			logger.debug("send Result=" + HtmlUtils.htmlEscape(String.valueOf(appInfo)));


		} catch (JMSException e) {
			Exception linked = e.getLinkedException();
			if (linked != null) {
				logger.error("Linked Exception=" + linked.getMessage());
				logger.error("Linked StackTrace=" + linked.getStackTrace());
				logger.error("Linked Cause=" + linked.getCause());
				logger.error("Linked=" + linked);
			}

			appInfo = "JMSException:" + e.getMessage();
			
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, appInfo);

			logger.error("JQS1.7:" + HtmlUtils.htmlEscape(String.valueOf(hmResult)));

			return hmResult;

		} catch (Exception e) {
			logger.error("Error occured in JMSQueueSender.send():" + e);
			appInfo = "Exception caught:" + e.getMessage();
				if (e instanceof NullPointerException) {
					appInfo = "Exception caught:null";
				} else {
					appInfo = "Exception caught:" + e.getMessage();
				}
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, appInfo);

			logger.error("JQS1.8:" + HtmlUtils.htmlEscape(String.valueOf(hmResult)));
			return hmResult;


		} finally {
			appInfo = "Total time taken:" + getElapsedTimeInSecs(startTm);
			logger.info("JMSQueueSender result:" + HtmlUtils.htmlEscape(String.valueOf(hmResult)) + "." + HtmlUtils.htmlEscape(String.valueOf(appInfo)));
		}
		return hmResult;

	}
	
	
	//@Retryable(maxAttempts = 3, value = {JMSException.class})
		private String sendmessagetoQueue(MessageProducer msgproducer, BytesMessage bMsg) throws JMSException {
			int attempts = 0;
			logger.info("in sendmessagetoQueue {} and bsmg {}", msgproducer.getDestination(), bMsg.getJMSCorrelationID());
			try {
				msgproducer.send(bMsg);
				messagePublished.set(true); // Set the flag to true on successful publish
			} catch (JMSException e) {
				logger.info("JMSException occured, Trying manual retry");

				while (attempts < 3) {
					try {

						logger.info("in sendmessagetoQueue {} attempt {}", msgproducer.getDestination(), attempts);
						msgproducer.send(bMsg);
						messagePublished.set(true); // Set the flag to true on successful publish
						return "Message sent successfully from sendmessagetoQueue";
					} catch (JMSException ex) {
						attempts++;
						if (attempts == 3) {
							messagePublished.set(false); // Set the flag to true on successful publish
							throw new JMSException("Retry not working");
						}
					}
				}
			}
			return "Message sent successfully from sendmessagetoQueue";
		}
	
	/**
	 * 
	 * @param log
	 * @param object
	 * @return
	 */
	private byte[] convertToBytes(Logger log, Object object){
		try {
			ByteArrayOutputStream bos = new ByteArrayOutputStream(); 
		    ObjectOutput out = new ObjectOutputStream(bos); 
		    out.writeObject(object); 
		    out.flush(); 
		    out.close(); 
		    return bos.toByteArray();
		} 
        catch (IOException ioe) {
        	log.error("IOException while converting message to byte array:" + ioe.getMessage());        	 
        	return null; 
        } 
	}
	
	/**
	 * 
	 * @param startTime
	 * @return
	 */
	private String getElapsedTimeInSecs(long startTime) {

		StringBuffer sElapsedTime = new StringBuffer();

		long diff = (System.currentTimeMillis() - startTime);
		long ms = diff % 1000;

		sElapsedTime.append(diff / 1000).append('.'); // secs.

		if (ms < 10)
			sElapsedTime.append("00").append(ms); // 3 digits ms 0 padded
		else if (ms < 100)
			sElapsedTime.append('0').append(ms);
		else
			sElapsedTime.append(ms);

		return sElapsedTime.toString();
	}
	
	/**
	 * 
	 * @param valueToHash
	 * @param denomVal
	 * @return
	 */
	private int hash(String valueToHash, int denomVal) {

	       int iHash = 0;
	       //get the q number to be used for hash 
	       //default to 1 if not found so it will return a hash of 0
	       
	       if(denomVal <=0) denomVal = 1;
	       
	       iHash = valueToHash.hashCode() % denomVal;

	       if (iHash < 0) iHash=-iHash;

	       return iHash;
	} 
}
