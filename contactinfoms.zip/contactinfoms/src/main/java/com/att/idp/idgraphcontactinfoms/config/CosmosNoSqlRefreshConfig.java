package com.att.idp.idgraphcontactinfoms.config;

import com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig;
import com.azure.cosmos.CosmosAsyncClient;
import com.azure.cosmos.CosmosClientBuilder;
import com.azure.cosmos.GatewayConnectionConfig;
import com.azure.cosmos.ThrottlingRetryOptions;
import com.azure.spring.data.cosmos.config.CosmosConfig;
import com.azure.spring.data.cosmos.core.ReactiveCosmosOperations;
import com.azure.spring.data.cosmos.core.ReactiveCosmosTemplate;
import com.azure.spring.data.cosmos.core.ResponseDiagnostics;
import com.azure.spring.data.cosmos.core.ResponseDiagnosticsProcessor;
import com.azure.spring.data.cosmos.core.convert.MappingCosmosConverter;
import com.azure.spring.data.cosmos.core.mapping.CosmosMappingContext;
import io.micrometer.core.lang.Nullable;
import jakarta.annotation.PreDestroy;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Proxy;
import java.time.Duration;
import java.util.List;

/**
 * Configuration for Azure Cosmos DB (NoSQL) connection.
 * Supports dynamic refresh of idle-connection-timeout and max-connection-pool-size
 * via IDGraphAzureAppConfig (@RefreshScope). On RefreshScopeRefreshedEvent, the
 * CosmosAsyncClient and ReactiveCosmosTemplate are rebuilt with the latest values.
 */
@Configuration
@RequiredArgsConstructor
public class CosmosNoSqlRefreshConfig {

    private static final Logger log = LoggerFactory.getLogger(CosmosNoSqlRefreshConfig.class);

    // Injected via constructor (RequiredArgsConstructor) — @RefreshScope bean
    private final IDGraphAzureAppConfig idGraphAzureAppConfig;

    @Value("${spring.cloud.azure.cosmos.endpoint}")
    private String endpoint;

    @Value("${spring.cloud.azure.cosmos.key}")
    private String key;

    @Value("${spring.cloud.azure.cosmos.database}")
    private String database;

    @Value("${spring.cloud.azure.cosmos.throttling-retry-options.max-retry-wait-time:10s}")
    private Duration throttlingRetryMaxWaitTime;

    @Value("${spring.cloud.azure.cosmos.throttling-retry-options.max-retry-attempts-on-throttled-requests:5}")
    private int throttlingRetryMaxAttempts;

    private volatile CosmosAsyncClient activeClient;
    private volatile ReactiveCosmosTemplate currentTemplate;

    @Bean(name = "idGraphCosmosConfig")
    public CosmosConfig cosmosConfig() {
        return CosmosConfig.builder()
                .enableQueryMetrics(true)
                .responseDiagnosticsProcessor(new ResponseDiagnosticsProcessorImpl())
                .build();
    }

    @Bean(name = "idGraphCosmosMappingContext")
    public CosmosMappingContext cosmosMappingContext() {
        return new CosmosMappingContext();
    }

    @Bean(name = "idGraphCosmosConverter")
    public MappingCosmosConverter cosmosConverter(
            @Qualifier("idGraphCosmosMappingContext") CosmosMappingContext context) {
        return new MappingCosmosConverter(context, null);
    }

    @Bean(name = "idGraphCosmosAsyncClient")
    public CosmosAsyncClient cosmosAsyncClient() {
        CosmosAsyncClient client = buildClientBuilder()
                .contentResponseOnWriteEnabled(true)
                .buildAsyncClient();
        this.activeClient = client;
        return client;
    }

    @Bean(name = "idGraphCosmosTemplate")
    public ReactiveCosmosOperations cosmosTemplate(
            @Qualifier("idGraphCosmosAsyncClient") CosmosAsyncClient client,
            @Qualifier("idGraphCosmosConfig") CosmosConfig cosmosConfig,
            @Qualifier("idGraphCosmosConverter") MappingCosmosConverter converter) {
        log.info("Connecting to Cosmos DB (database={}, maxPoolSize={}, idleTimeoutMs={})",
                database,
                idGraphAzureAppConfig.getMaxConnectionPoolSize(),
                idGraphAzureAppConfig.getIdleConnectionTimeoutMs());
        this.currentTemplate = new ReactiveCosmosTemplate(client, database, cosmosConfig, converter);
        return (ReactiveCosmosOperations) Proxy.newProxyInstance(
                ReactiveCosmosOperations.class.getClassLoader(),
                new Class<?>[]{ReactiveCosmosOperations.class},
                (proxy, method, args) -> {
                    ReactiveCosmosTemplate template = currentTemplate;
                    if (template == null) {
                        throw new IllegalStateException("No active Cosmos template available");
                    }
                    try {
                        return method.invoke(template, args);
                    } catch (InvocationTargetException e) {
                        Throwable cause = e.getCause();
                        throw cause != null ? cause : e;
                    }
                });
    }

    /**
     * Rebuilds CosmosAsyncClient and ReactiveCosmosTemplate on config refresh.
     * Reads the latest idle-connection-timeout and max-connection-pool-size
     * from IDGraphAzureAppConfig (@RefreshScope), so the new values are picked up
     * without a pod restart.
     */
    @EventListener(RefreshScopeRefreshedEvent.class)
    public synchronized void onRefresh(RefreshScopeRefreshedEvent event) {
        List<String> preferredRegions = idGraphAzureAppConfig.getPreferredRegions();
        log.info("Refresh detected (name={}). Rebuilding Cosmos client/template with maxPoolSize={}, idleTimeoutMs={}, preferredRegionsCount={}",
                event != null ? event.getName() : "<null>",
                idGraphAzureAppConfig.getMaxConnectionPoolSize(),
                idGraphAzureAppConfig.getIdleConnectionTimeoutMs(),
                preferredRegions != null ? preferredRegions.size() : 0);
        try {
            CosmosAsyncClient newClient = buildClientBuilder()
                    .contentResponseOnWriteEnabled(true)
                    .buildAsyncClient();
            ReactiveCosmosTemplate newTemplate = new ReactiveCosmosTemplate(
                    newClient,
                    database,
                    cosmosConfig(),
                    cosmosConverter(cosmosMappingContext()));

            CosmosAsyncClient oldClient = this.activeClient;
            this.activeClient = newClient;
            this.currentTemplate = newTemplate;

            log.info("Cosmos rebuilt: database={}, maxPoolSize={}, idleTimeoutMs={}",
                    database,
                    idGraphAzureAppConfig.getMaxConnectionPoolSize(),
                    idGraphAzureAppConfig.getIdleConnectionTimeoutMs());

            closeQuietly(oldClient);
        } catch (Exception e) {
            log.error("Failed to rebuild Cosmos client/template on refresh", e);
        }
    }

    @PreDestroy
    public void shutdown() {
        CosmosAsyncClient client = this.activeClient;
        this.activeClient = null;
        this.currentTemplate = null;
        closeQuietly(client);
    }

    private CosmosClientBuilder buildClientBuilder() {
        int maxPoolSize = idGraphAzureAppConfig.getMaxConnectionPoolSize();
        int idleTimeout = idGraphAzureAppConfig.getIdleConnectionTimeoutMs();
        List<String> preferredRegions = idGraphAzureAppConfig.getPreferredRegions();

        GatewayConnectionConfig gatewayConfig = new GatewayConnectionConfig();
        gatewayConfig.setMaxConnectionPoolSize(maxPoolSize);
        gatewayConfig.setIdleConnectionTimeout(Duration.ofMillis(idleTimeout));

        ThrottlingRetryOptions throttlingRetryOptions = new ThrottlingRetryOptions();
        throttlingRetryOptions.setMaxRetryWaitTime(throttlingRetryMaxWaitTime);
        throttlingRetryOptions.setMaxRetryAttemptsOnThrottledRequests(throttlingRetryMaxAttempts);

        log.info("Building Cosmos client: endpoint={}, database={}, maxPoolSize={}, idleTimeoutMs={}, preferredRegionsCount={}",
                endpoint, database, maxPoolSize, idleTimeout, preferredRegions != null ? preferredRegions.size() : 0);

        return new CosmosClientBuilder()
                .endpoint(endpoint)
                .key(key)
                .preferredRegions(preferredRegions)
                .throttlingRetryOptions(throttlingRetryOptions)
                .gatewayMode(gatewayConfig);
    }

    private void closeQuietly(CosmosAsyncClient client) {
        if (client == null) {
            return;
        }
        try {
            client.close();
        } catch (Exception e) {
            log.warn("Failed closing CosmosAsyncClient", e);
        }
    }

    private static class ResponseDiagnosticsProcessorImpl implements ResponseDiagnosticsProcessor {
        @Override
        public void processResponseDiagnostics(@Nullable ResponseDiagnostics responseDiagnostics) {
            log.debug("Cosmos response diagnostics: {}", responseDiagnostics);
        }
    }
}