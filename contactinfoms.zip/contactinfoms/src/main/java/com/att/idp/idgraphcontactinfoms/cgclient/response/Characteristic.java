package com.att.idp.idgraphcontactinfoms.cgclient.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

/**
 * The Characteristic class represents a characteristic in the system.
 * It implements the Serializable interface, which means its instances can be converted to a byte stream and
 * restored back to the same object later. This is useful for storing objects in a file or sending them over a network.
 *
 * This class contains various properties related to a characteristic such as contactType, phoneNumber, subContactType, city, country, postCode, stateOrProvince, street1, place, addressSubType, county, and emailAddress.
 * Each property has its corresponding getter and setter methods.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.cgclient.response package.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(name = "Characteristic")
@Getter
@Setter
@NoArgsConstructor
public class Characteristic implements Serializable {

	private static final long serialVersionUID = -6982024394975347334L;

	private String contactType;
	private String phoneNumber;
	private String subContactType;
	private String city;
	private String country;
	private String postCode;
	private String stateOrProvince;
	private String street1;
	private Place place;
	private String addressSubType;
	private String county;
	private String emailAddress;
}