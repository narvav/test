package com.att.idp.idgraphcontactinfoms.integration.Async;

import java.util.concurrent.Executor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.integration.Async package.
 * It is annotated with @Configuration and @EnableAsync, indicating that it is a source of bean definitions
 * for the Spring application context and enables Spring's asynchronous method execution capability.
 *
 * The class contains methods to create TaskExecutor beans:
 * - CIRAsyncTaskExecutor: Used for general async tasks
 * - otpPublishExecutor: Dedicated executor for OTP event publishing via @Async methods
 *
 * Inside the taskExecutor method, it creates a new SimpleAsyncTaskExecutor, sets its thread name prefix to "CIRAsyncThread",
 * sets its task decorator to a new instance of AsyncTaskDecorator, and returns it.
 *
 * The TaskExecutor created by this method is used to execute tasks asynchronously in the application.
 */
@EnableAsync
@Configuration
public class AsyncTaskExecutorConfig {

	@Value("${otp.publish.executor.corePoolSize:4}")
	private int otpCorePoolSize;

	@Value("${otp.publish.executor.maxPoolSize:16}")
	private int otpMaxPoolSize;

	@Value("${otp.publish.executor.queueCapacity:500}")
	private int otpQueueCapacity;

	@Value("${otp.history.executor.corePoolSize:4}")
	private int otpHistoryCorePoolSize;

	@Value("${otp.history.executor.maxPoolSize:8}")
	private int otpHistoryMaxPoolSize;

	@Value("${otp.history.executor.queueCapacity:200}")
	private int otpHistoryQueueCapacity;
	
	/**
	 * This method is used to create a TaskExecutor bean.
	 *
	 * It creates a new SimpleAsyncTaskExecutor, sets its thread name prefix to "CIRAsyncThread",
	 * sets its task decorator to a new instance of AsyncTaskDecorator, and returns it.
	 * The TaskExecutor created by this method is used to execute tasks asynchronously in the application.
	 *
	 * @return A TaskExecutor that is configured to use the AsyncTaskDecorator and has a thread name prefix of "CIRAsyncThread".
	 */
	@Bean(name="CIRAsyncTaskExecutor")
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
		taskExecutor.setThreadNamePrefix("CIRAsyncThread");
		taskExecutor.setTaskDecorator(new AsyncTaskDecorator());
		return taskExecutor;
	}

	/**
	 * Creates a dedicated ThreadPoolTaskExecutor for OTP event publishing.
	 *
	 * This executor is used by GeneratePINBase, ValidatePINHelper, and DeletePINHelper
	 * to publish OTP events asynchronously without using the global ForkJoinPool common pool.
	 * Using a dedicated executor allows for better tuning, observability, and prevents
	 * thread starvation under load.
	 *
	 * @return An Executor configured for OTP event publishing with configurable pool sizes.
	 */
	@Bean(name = "otpPublishExecutor")
	public Executor otpPublishExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(otpCorePoolSize);
		executor.setMaxPoolSize(otpMaxPoolSize);
		executor.setQueueCapacity(otpQueueCapacity);
		executor.setThreadNamePrefix("otp-publish-");
		executor.initialize();
		return executor;
	}

	/**
	 * Creates a dedicated ThreadPoolTaskExecutor for OTP history persistence.
	 *
	 * This executor is used by GeneratePINBase, ValidatePINHelper, and DeletePINHelper
	 * to save OTP history records to Cosmos DB asynchronously. Isolated from
	 * otpPublishExecutor to prevent noisy-neighbor effects between Oracle sync
	 * and Cosmos DB history writes.
	 *
	 * @return An Executor configured for OTP history writes with MDC propagation.
	 */
	@Bean(name = "otpHistoryExecutor")
	public Executor otpHistoryExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(otpHistoryCorePoolSize);
		executor.setMaxPoolSize(otpHistoryMaxPoolSize);
		executor.setQueueCapacity(otpHistoryQueueCapacity);
		executor.setThreadNamePrefix("otp-history-");
		executor.setWaitForTasksToCompleteOnShutdown(true);
		executor.setAwaitTerminationSeconds(30);
		executor.setRejectedExecutionHandler(new java.util.concurrent.ThreadPoolExecutor.CallerRunsPolicy());
		executor.setTaskDecorator(new AsyncTaskDecorator());
		executor.initialize();
		return executor;
	}

}
