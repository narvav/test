package com.att.idp.idgraphcontactinfoms.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * The class Subscriber
 *
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "subscriberId",
        "status",
        "effectiveDate",
        "primaryAccountHolder",
        "simSwap",
        "contact"
})
public class Subscribers implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The subscriberId. */
    @JsonProperty("subscriberId")
    private String subscriberId;

    /** The status. */
    @JsonProperty("status")
    private String status;

    /** The effectiveDate. */
    @JsonProperty("effectiveDate")
    private String effectiveDate;

    /** The primaryAccountHolder. */
    @JsonProperty("primaryAccountHolder")
    private Boolean primaryAccountHolder;

    /** The simSwap. */
    @JsonProperty("simSwap")
    private String simSwap;

    /** The list of contact. */
    @JsonProperty("contact")
    private List<Contact> contact = null;
}
