package com.att.idp.idgraphcontactinfoms.db.repository;

import java.util.HashMap;

import com.att.idp.idgraphcontactinfoms.exceptions.MPSException;
import org.slf4j.Logger;

/**
 * This is a custom repository interface for SecurityCode.
 *
 * It provides a method to set a security code. The method takes a HashMap as input parameter.
 * The HashMap contains the necessary information to set the security code.
 *
 * This interface is meant to be implemented by a class that provides the actual implementation of the setSecurityCode method.
 */
public interface SecurityCodeRepositoryCustom {

	
	/**
	 * This method is used to set a security code.
	 *
	 * It takes one parameter: InpParam. InpParam is a HashMap that contains the necessary information to set the security code.
	 *
	 * The method performs an operation to set the security code using the information provided in the InpParam HashMap.
	 * The result of the operation is an integer representing the status of the operation.
	 *
	 * @param InpParam a HashMap containing the necessary information to set the security code.
	 * @return an integer representing the status of the operation.
	 */
	public int setSecurityCode(HashMap InpParam) throws Exception;
}
