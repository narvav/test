package com.att.idp.idgraphcontactinfoms.service;

import jakarta.ws.rs.core.MultivaluedMap;

import com.att.idp.idgraphcontactinfoms.resource.request.DeletePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.DeletePinResponse;

/**
 * This interface is part of the com.att.idp.idgraphcontactinfoms.service package.
 *
 * The DeletePINService interface defines a contract for a service that handles the deletion of a PIN.
 * It declares a single method, deletePin, which takes a DeletePINRequest and a MultivaluedMap of String to String as input and returns a DeletePinResponse.
 *
 * The deletePin method is expected to perform the operation of deleting a PIN, using the DeletePINRequest as the request body and the MultivaluedMap as the request headers.
 */
public interface DeletePINService {

	/**
	 * This method is part of the DeletePINService interface in the com.att.idp.idgraphcontactinfoms.service package.
	 *
	 * The deletePin method is used to perform the operation of deleting a PIN.
	 * It takes a DeletePINRequest object and a MultivaluedMap of String to String as input.
	 * The DeletePINRequest object represents the request body, containing the details of the PIN to be deleted.
	 * The MultivaluedMap represents the request headers.
	 *
	 * The method returns a DeletePinResponse object, which represents the response from the operation of deleting a PIN.
	 */
	DeletePinResponse deletePin(DeletePINRequest deletePINRequest, MultivaluedMap<String, String> requestHeader);

}
