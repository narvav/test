package com.att.idp.idgraphcontactinfoms.resource.request;

import static org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString;
import static org.apache.commons.lang3.builder.ToStringStyle.JSON_STYLE;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.request package.
 *
 * The GeneratePINRequest class is used to represent a request to generate a PIN.
 * It contains several fields, each of which represents a parameter of the request.
 * These fields include transactionName, callingSystemId, accountId, accountType, identificationType, returnSecurityCode, agentId, browserLanguage, resBusInd, transactionId, idpTraceId, deliveryMethods, attributeList, and unknownAttributes.
 *
 * Each field is annotated with @Size and/or @NotNull, indicating that they are required fields and have size constraints.
 * The messages associated with these annotations provide additional information about the requirements for each field.
 *
 * The class provides a map of unknownAttributes, which can be used to store any additional attributes that are not part of the other fields.
 * The unknownAttributes map is annotated with @JsonAnySetter and @JsonAnyGetter, allowing it to be included in JSON serialization and deserialization.
 *
 * The class also overrides the toString method, providing a custom string representation of the object using reflection.
 */
@Schema(name = "GeneratePINRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class GeneratePINRequest {

	protected final String transactionName = "GeneratePIN";

	@Size(min = 1, max = 20, message =  "CallingSystemId length is invalid|GeneratePIN")
	protected String callingSystemId;

	@Schema(name = "accountId")
	@NotNull(message = "AccountId is required field in input request.|GeneratePIN")
	@Size(min = 1, max = 60, message =  "AccountId length is invalid|GeneratePIN")
	protected String accountId;
	
	@Schema(name = "accountType")
	@Size(min = 1, max = 20, message =  "AccountType length is invalid|GeneratePIN")
	protected String accountType;
	
	@Schema(name = "identificationType")
	@NotNull(message = "IdentificationType is required field in input request.|GeneratePIN")
	@Size(min = 1, max = 10, message =  "IdentificationType length is invalid|GeneratePIN")
	protected String identificationType;
	
	@Schema(name = "channel")
	@Size(min = 1, max = 40, message =  "channel length is invalid|GeneratePIN")
	protected String channel;

	@Schema(name = "returnSecurityCode")
	@Size(min = 1, max = 1, message =  "returnSecurityCode value can only be Y or N|GeneratePIN")
	protected String returnSecurityCode;

	@Schema(name = "agentId")
	@Size(min = 1, max = 20, message =  "AgentId length is invalid|GeneratePIN")
	protected String agentId;

	@Schema(name = "browserLanguage")
	@Size(min = 2, max = 2, message =  "browserLanguage value can only be EN or ES|GeneratePIN")
	protected String browserLanguage;

	@Schema(name = "resBusInd")
	@Size(min = 1, max = 1, message =  "resBusInd value can only be R or B|GeneratePIN")
	protected String resBusInd;

	@Schema(name = "transactionId")
	private String transactionId;

	@Schema(name = "idpTraceId")
	private String idpTraceId;

	@Valid
	@Schema(name = "deliveryMethods")
	protected DeliveryMethods deliveryMethods;

	@Valid
	@Schema(name = "attributeList")
	protected List<AttributeList> attributeList;

	/**
	 * This field represents a map of unknown attributes.
	 *
	 * The unknownAttributes map is used to store any additional attributes that are not part of the attributeName and attributeValue fields.
	 * It is initialized as a new HashMap.
	 *
	 * The field is annotated with @JsonAnySetter and @JsonAnyGetter, allowing it to be included in JSON serialization and deserialization.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();


	@Override
    public String toString() {
        return reflectionToString(this, JSON_STYLE);
    }

}
