package com.att.idp.idgraphcontactinfoms.helpers;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

import com.att.idp.idgraph.db.cosmos.entity.HistoryMetadata;
import com.att.idp.idgraph.db.cosmos.entity.IdgOtpContainer;
import com.att.idp.idgraph.db.cosmos.entity.IdgOtpContainerHistory;
import com.att.idp.idgraph.db.cosmos.entity.Operation;
import com.att.idp.idgraph.db.cosmos.entity.SecurityCode;
import com.att.idp.idgraph.db.cosmos.helper.IdgOtpDBHelper;
import com.att.idp.idgraph.db.cosmos.helper.OtpHistoryDBHelper;
import com.att.idp.idgraphcontactinfoms.model.*;
import com.att.idp.idgraphcontactinfoms.service.async.AsyncOtpEventPublisher;
import com.att.idp.idgraphcontactinfoms.service.async.OracleSecurityCodeSyncPublisher;
import com.att.idp.idgraphcontactinfoms.utils.DateUtil;
import groovy.json.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphcontactinfoms.db.helper.SecurityCodeDBHelper;
import com.att.idp.idgraphcontactinfoms.exceptions.PrimaryProducerException;
import com.att.idp.idgraphcontactinfoms.exceptions.SecondaryProducerException;
import com.att.idp.idgraphcontactinfoms.helpers.voltage.ProofingEncryptionHelper;
import com.att.idp.idgraphcontactinfoms.helpers.voltage.VoltageEncryptionHelper;
import com.att.idp.idgraphcontactinfoms.integration.MuleSoftRestClient;
import com.att.idp.idgraphcontactinfoms.kafka.GenericOTPPublisher;
import com.att.idp.idgraphcontactinfoms.kafka.model.GenericOTPNotification;
import com.att.idp.idgraphcontactinfoms.kafka.model.GenericOTPNotification.Attributes;
import com.att.idp.idgraphcontactinfoms.kafka.model.GenericOTPNotification.NotificationDetails;
import com.att.idp.idgraphcontactinfoms.queue.message.sender.JMSQueueSender;
import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.idp.idgraphcontactinfoms.utils.Constants;
import com.att.idp.idgraphcontactinfoms.utils.JsonService;
import com.att.idp.idgraphcontactinfoms.utils.ProfileOrchestrationConstants;
import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.helpers.FeatureManagerHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.JsonUtils;
import com.att.mpsys.common.utils.MPSDefs;
import com.att.mpsys.common.utils.RILDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.logstash.logback.argument.StructuredArguments;
import org.springframework.web.util.HtmlUtils;

/**
 * The GeneratePINBase class is a Spring component that provides methods for generating and managing PINs.
 *
 * It uses various Spring components and helpers such as SecurityCodeDBHelper, ProofingEncryptionHelper, VoltageEncryptionHelper, JMSQueueSender, and MuleSoftRestClient to perform its operations.
 *
 * The class contains several methods including initialize, validateSecurityCodeData, processInputData, generateVoltageEncryptedToken, storeMPSData, prepareDataForCCMuleSyncCall, makeCCMuleSyncCall, createSecurityCode, getDeliveryMethodAndDetails, and others.
 *
 * Each method performs a specific operation related to PIN generation and management. For example, the validateSecurityCodeData method validates the security code data, the processInputData method processes the input data, the generateVoltageEncryptedToken method generates an encrypted token using Voltage, and so on.
 *
 * The class uses the SLF4J Logger for logging.
 */
@Component
@Scope("prototype")
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class GeneratePINBase {

	private static String sClassName = "GeneratePINBase.";
	public static final Logger logger = LoggerFactory.getLogger(GeneratePINBase.class);
	
	private static final String DBUS_TRANSACTION_ID="dbusTransactionId";

	@Value("${PROP_PIN_LENGTH}")
	private String propPINLength;

	@Value("${PROP_PIN_EXPIRATION_MINUTES}")
	private String propPINExpirationMinutes;

	@Value("${PROP_PIN_EXCLUDE_EXPIRY_TIME_OVERWRITE_IDTYPE}")
	private String propPinExcludeTimeOverwiteIDType;

	@Value("${PROP_CALL_CCMULE_STUB}")
	private String propStubCCMULECall;

	@Value("${PROP_PIN_DELIVERY_METHODS}")
	private String sPropPinDeliveryMethods;

	@Value("${PROP_PIN_MAX_PINS}")
	private String sPropPinMaxPins;

	@Value("${PROP_IDENTIFICATIONTYPES_CLM_SUBCATEGORY_MAPPING}")
	private String propSubCategory;

    @Value("${PROP_IDENTIFICATIONTYPES_CLM_SUBCATEGORY_MAPPING_CLM}")
    private String propSubCategoryClm;

    @Value("${PROP_CLM_HIGH_PRIORITY_IDENTIFICATIONTYPES}")
	private String propHighPriorityIdentificationTypes;

    @Value("${PROP_CLM_HIGH_PRIORITY_IDENTIFICATIONTYPES_CLM}")
    private String propHighPriorityIdentificationTypesClm;

    @Value("${PROP_IDENTIFICATIONTYPES_CLM_SERVICETYPE_MAPPING}")
    private String propIdentificationTypeToServiceTypeMapping;

	@Value("${apiclient.rest.ccmulesoft.serverUrl}")
	private String ccmulesoftServerUrl;

	@Value("${apiclient.rest.ccmulesoft.endpoint}")
	private String ccmulesoftEndpoint;

	@Value("${apiclient.rest.clmHighPriority.serverUrl}")
	private String clmHighPriorityServerUrl;

	@Value("${apiclient.rest.clmHighPriority.endpoint}")
	private String clmHighPriorityEndpoint;

	protected Map<String, Object> hmInput;

	private String propPINExpirationTime;

	@Autowired
	private SecurityCodeDBHelper securityCodeDBHelper;

	@Autowired
	private ProofingEncryptionHelper proofingEncryptionHelper;

	@Autowired
	private VoltageEncryptionHelper voltageEncryptionHelper;

	@Autowired
	private JMSQueueSender oJMSQueueSender;

	@Autowired
	private MuleSoftRestClient muleSoftRestClient;

	@Autowired
	FeatureManagerHelper featureManager;

	@Autowired
	private GenericOTPPublisher gotpPublisher;

	@Autowired
	private IdgOtpDBHelper idgOtpDBHelper;

	private final OtpHistoryDBHelper otpHistoryDBHelper;

	@Qualifier("otpHistoryExecutor")
	private final Executor otpHistoryExecutor;

	private static final String OTP_HISTORY_SOURCE = "IDGraphContactInfoMs";

	@Autowired
	AsyncOtpEventPublisher otpEventPublisher;

	@Autowired
	ValidatePINHelper validatePINHelper;

	public GeneratePINBase(OtpHistoryDBHelper otpHistoryDBHelper, @Qualifier("otpHistoryExecutor") Executor otpHistoryExecutor) {
		this.otpHistoryDBHelper = otpHistoryDBHelper;
		this.otpHistoryExecutor = otpHistoryExecutor;
	}

	/**
	 * This method initializes the GeneratePINBase class.
	 *
	 * It takes a HashMap as input which contains the details for the PIN generation process.
	 * The method sets the input HashMap to the class variable 'hmInput' for further use in other methods.
	 *
	 * @param hmInput a HashMap that contains the details for the PIN generation process.
	 */
	public void initialize(Map<String, Object> hmInput) {
		this.hmInput = hmInput;
		if(hmInput != null) {
				propPINExpirationTime = propPINExpirationMinutes;
				hmInput.put(ProfileOrchestrationConstants.EXPIRY_TIME_UNIT, ProfileOrchestrationConstants.MINUTES);
				logger.info("GPB_IXP_Flag:Expiration Time Unit is set to Minutes");

		}
	}
	
	/**
	 * This method validates the security code data.
	 *
	 * It first retrieves the identification type and account ID from the input HashMap.
	 * Then, it calls the getSecurityCodeDataQuery method of the SecurityCodeDBHelper class to get the security code data from the database.
	 *
	 * If the response from the getSecurityCodeDataQuery method indicates an error (other than record not found), the method constructs an error response and returns it.
	 *
	 * If the response from the getSecurityCodeDataQuery method indicates that the record was not found or if the number of security codes is less than the maximum allowed number of security codes, the method constructs a success response and returns it.
	 *
	 * If the number of security codes is equal to or more than the maximum allowed number of security codes, the method constructs an error response indicating that the maximum number of security codes has been reached and returns it.
	 *
	 * The method uses the SLF4J Logger for logging.
	 *
	 * @return a HashMap that contains the result of the validation. The HashMap contains an application status code and an application info message.
	 */
	public Map validateSecurityCodeData() {
		String sMethodName =  ".validateSecurityCodeData.";
		Map hmResult = null;
		String stAppInfo = null;
		String stAppStatusCode = null;
		HashMap hmGetDBInput = CommonUtil.getHashMap();
		boolean isGeneratePINMaxPINCheckDisabled = false;
		
		String sInpIdentificationType = (String) hmInput.get(CommonDefs.IDENTIFICATION_TYPE);
		String sInpAccountId = (String) hmInput.get(CommonDefs.ACCOUNT_ID);
		
		hmGetDBInput.put(MPSDefs.DB_ACCOUNT_ID, sInpAccountId);
		hmGetDBInput.put(MPSDefs.DB_IDENTIFICATION_TYPE, sInpIdentificationType);
		hmGetDBInput.put(ProfileOrchestrationConstants.EXPIRY_TIME_UNIT,
				hmInput.get(ProfileOrchestrationConstants.EXPIRY_TIME_UNIT));

		logger.debug("{}{}GPB_105 : Calling MPSDB_SecurityCode_H.getSecurityCodeData with input: {}", sClassName, sMethodName, hmGetDBInput);
		String otpDataSource = getOtpDataSource();
		Map hmGetDBResult = null;
		if ("ORACLEMASTER".equalsIgnoreCase(otpDataSource) || "ONLYORACLE".equalsIgnoreCase(otpDataSource)) {
			hmGetDBResult = securityCodeDBHelper.getSecurityCodeDataQuery(hmGetDBInput);
		}
		else if("COSMOSMASTER".equalsIgnoreCase(otpDataSource) || "ONLYCOSMOS".equalsIgnoreCase(otpDataSource)){
			hmGetDBResult = idgOtpDBHelper.getSecurityCodeDataQuery(hmGetDBInput);
		}
		logger.debug("{}{}GPB_106 : Response from  MPSDB_SecurityCode_H.getSecurityCodeData: {}", sClassName, sMethodName, hmGetDBResult);

		stAppStatusCode = (String) hmGetDBResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

		if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)
				&& !stAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND)) {	
			stAppInfo = (String) hmGetDBResult.get(CommonDefs.COMMON_APP_INFO);
			logger.info("{}{}GPB_106.2 : {}", sClassName, sMethodName, stAppInfo);
			hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
			return hmResult;
		}

		String stDBSecurityCodeCount = "0";

		if (hmGetDBResult.containsKey(MPSDefs.SECURITY_CODE_COUNT)) {
			stDBSecurityCodeCount = (String) hmGetDBResult.get(MPSDefs.SECURITY_CODE_COUNT);
		}
		
		isGeneratePINMaxPINCheckDisabled = featureManager.isEnabled("svc-idgraph-generate-pin-disable-max-count");
		logger.debug("IXP Flag svc-idgraph-generate-pin-disable-max-count value :" + isGeneratePINMaxPINCheckDisabled);
		if(!isGeneratePINMaxPINCheckDisabled){
			logger.info("{}{}GPB_106.3 : PROP_PIN_MAX_PINS : {}", sClassName, sMethodName, sPropPinMaxPins);
			HashMap hmPropPinMaxPins = CommonUtil.parsePropertyToHash(sPropPinMaxPins);

			String sMaxAllowedPins = null;
			if(hmPropPinMaxPins != null && !hmPropPinMaxPins.isEmpty())
				sMaxAllowedPins = (String) hmPropPinMaxPins.get(sInpIdentificationType);

			if (stDBSecurityCodeCount != null && !stDBSecurityCodeCount.isEmpty()
					&& (Integer.parseInt(sMaxAllowedPins) <= Integer.parseInt(stDBSecurityCodeCount))) {
				stAppInfo = "Security Codes cannot be more than " + sMaxAllowedPins;
				logger.info("{}{}GPB_107 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_MAX_CODES_ACTIVE_NUM, stAppInfo);
				return hmResult;
			}
		}

		stAppInfo = "Input Validation Successful";
		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
		logger.info("{}{}GPB_108 : {}", sClassName, sMethodName, stAppInfo);
		
		return hmResult;
	}

	/**
	 * This method processes the input data for PIN generation.
	 *
	 * It first retrieves the identification type and account ID from the input HashMap.
	 * Then, it generates a security code using the createSecurityCode method.
	 * The security code is then encrypted using the generateSHA1Value method of the ProofingEncryptionHelper class.
	 *
	 * If the identification type is 'ENCPIN', the method generates an encrypted token using the generateVoltageEncryptedToken method.
	 * The encrypted token is then set to the input HashMap.
	 *
	 * The method also retrieves the delivery method and details using the getDeliveryMethodAndDetails method.
	 * The retrieved delivery method and details are then set to the input HashMap.
	 *
	 * The method also sets the security code expiration hours to the input HashMap.
	 *
	 * Finally, the method returns a HashMap that contains the result of the operation. The HashMap contains an application status code and an application info message.
	 *
	 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code and an application info message.
	 */
	public Map<String, Object> processInputData() {
		String sMethodName = ".processInputData.";
		String stAppStatusCode = null;
		String stAppInfo = null;
		String stSecurityCodeLength = null;

		Map<String, Object> hmResult = null;
		try {

			logger.debug("{}{}GPB_101 : PROP_PIN_LENGTH :: {}", sClassName, sMethodName, propPINLength);
			HashMap hmPropPinLength = CommonUtil.parsePropertyToHash(propPINLength);

			String sInpIdentificationType = (String) hmInput.get(CommonDefs.IDENTIFICATION_TYPE);
			String sAccountId = (String) hmInput.get(CommonDefs.ACCOUNT_ID);

			if (hmPropPinLength != null && !hmPropPinLength.isEmpty())
				stSecurityCodeLength = (String) hmPropPinLength.get(sInpIdentificationType);

			String sSecurityCode = createSecurityCode(stSecurityCodeLength);
//			logger.debug(SpiMarker.getInstance(), "GeneratePINBase.processInputData.GPB_102 : securityCode: {}",
//					sSecurityCode);

			String encryptedSecurityCode = proofingEncryptionHelper.generateSHA1Value(sSecurityCode);

			//override the security code with SHA256 encrypted value for Cosmos DB
			HashMap<String, String> passwordMap = new HashMap<>();
			passwordMap.put(MPSDefs.WS_CLEAR_TEXT, sSecurityCode);
			String sSHA256EncryptedSecurityCode = CommonUtilHelper.generateGenericPassword(passwordMap,
					"SHA256").get(RILDefs.RIL_GEN_PASSWORD).toString();
			hmInput.put("encryptedSHA256SecurityCode" , sSHA256EncryptedSecurityCode);

			hmInput.put(CommonDefs.SOURCE, CommonDefs.SOURCE_ONL);
			hmInput.put(CommonDefs.SECURITY_CODE, sSecurityCode);
			hmInput.put(CommonDefs.ENCRYPTED_SECURITY_CODE, encryptedSecurityCode);

			if (StringUtils.isNotBlank(sInpIdentificationType)
					&& (sInpIdentificationType.equalsIgnoreCase(CommonDefs.IDENTIFICATION_TYPE_ENCPIN)||sInpIdentificationType.equalsIgnoreCase("PORTOUTBSS"))) {
				if (StringUtils.isNotBlank(sSecurityCode)) {
					hmResult = generateVoltageEncryptedToken(sSecurityCode, sAccountId);
				}
				stAppStatusCode= (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
				if (!(CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode))) {
					if (stAppStatusCode == null || stAppStatusCode.equals(CErrorDefs.ERR_SYS_APPL) )
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					return hmResult;
				}
				String sEncryptedKey = (String) hmResult.get("voltage_CBR");
				hmInput.put(CommonDefs.TOKEN, sEncryptedKey);
				hmInput.put("voltageEncryptedOTP", (String) hmResult.get("voltage_VOTP"));
				
			}

			HashMap hmInpDeliveryMethods = (HashMap) hmInput.get(CommonDefs.DELIVERY_METHODS);

			hmResult = getDeliveryMethodAndDetails(hmInpDeliveryMethods);

			stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

			if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
				stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
				logger.debug("{}{}GPB_103 : sSecurityCode:: {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);				
				return hmResult;
			}

			String stDeliveryDetail = (String) hmResult.get(CommonDefs.DELIVERY_DETAIL);
			String stDeliveryMethod = (String) hmResult.get(CommonDefs.DELIVERY_METHOD);
			ArrayList alExcludeTimeOverwiteIDType = CommonUtil.parseToArray(propPinExcludeTimeOverwiteIDType,
					CommonDefs.VALUE_SEPARATOR_CHAR);
			if (stDeliveryMethod != null && !stDeliveryMethod.isEmpty()) {
				hmInput.put(CommonDefs.DELIVERY_METHOD, stDeliveryMethod);
				//for ExpirytimeUnit to Minutes and Delivery method as SMS , setting expiry time to 10 mins
				if (ProfileOrchestrationConstants.DELIVERY_METHOD_TYPE_SMS.equalsIgnoreCase(stDeliveryMethod)
						&& ProfileOrchestrationConstants.MINUTES.equalsIgnoreCase(
						(String) hmInput.get(ProfileOrchestrationConstants.EXPIRY_TIME_UNIT))) {
					if(!alExcludeTimeOverwiteIDType.contains(sInpIdentificationType)) {
						propPINExpirationTime = sInpIdentificationType + ":10";
						logger.info("{}{}GPB_105.a : updating PROP_PIN_EXPIRATION_MINUTES for deliveryType SMS : {}",
								sClassName, sMethodName, propPINExpirationTime);
					}

				}
			}

			if (stDeliveryDetail != null && !stDeliveryDetail.isEmpty()) {
				hmInput.put(CommonDefs.DELIVERY_DETAIL, stDeliveryDetail);
			}

			logger.info("{}{}GPB_105 : PROP_PIN_EXPIRATION_HOURS/PROP_PIN_EXPIRATION_MINUTES: {}", sClassName, sMethodName, propPINExpirationTime);
			HashMap hmPropPinExpirationTime = CommonUtil.parsePropertyToHash(propPINExpirationTime);

			String stSecurityCodeExpirationTime = null;
			if (hmPropPinExpirationTime != null && !hmPropPinExpirationTime.isEmpty())
				stSecurityCodeExpirationTime = (String) hmPropPinExpirationTime.get(sInpIdentificationType);

			hmInput.put("security_code_expiration_time", stSecurityCodeExpirationTime);

			double securityCodeExpirationTime = Double.parseDouble(stSecurityCodeExpirationTime);

			int securityExpirationMins = (int) securityCodeExpirationTime;
			DateFormat df = new SimpleDateFormat("MMddyyyy HH:mm");
			Calendar cal1 = Calendar.getInstance();
			cal1.setTimeZone(TimeZone.getTimeZone("GMT"));
			cal1.add(Calendar.MINUTE, securityExpirationMins);
			Date dtSecurityCodeExpiryDate = cal1.getTime();
			TimeZone tz = cal1.getTimeZone();
			String stSecurityCodeExpiryDate = df.format(dtSecurityCodeExpiryDate) + " "
					+ tz.getDisplayName(true, tz.SHORT);

			hmInput.put(CommonDefs.SECURITY_PIN_EXPIRATION_DATE, stSecurityCodeExpiryDate);

			stAppInfo = "Input Data processed Successfully";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, stAppInfo);
			logger.debug("{}{}GPB_106 : PROP_PIN_EXPIRATION_HOURS: {}", sClassName, sMethodName, stAppInfo);

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
		}
		return hmResult;
	}

	/**
	 * This method is used to generate an encrypted token using Voltage.
	 *
	 * It takes a security code and an account ID as input. The method concatenates the account ID and the security code with an underscore in between to form a string.
	 * This string is then encrypted using the Voltage encryption method.
	 *
	 * @param sSecurityCode The security code to be encrypted. This is a String value.
	 * @param sAccountId The account ID to be used in the encryption process. This is a String value.
	 * @return A Map containing the result of the encryption process. The Map contains an application status code and an application info message.
	 */
	public Map<String, Object> generateVoltageEncryptedToken(String sSecurityCode, String sAccountId) {
		String sMethodName = ".generateVoltageEncryptedToken.";
		String sVoltageEncryptString = sAccountId + "_" + sSecurityCode;
		HashMap<String, Object> hmVoltageEncrypt = new HashMap<String, Object>();
		hmVoltageEncrypt.put(CommonDefs.VOLTAGE_TOKEN, sVoltageEncryptString);
		hmVoltageEncrypt.put("VOTP", sSecurityCode);
		Map<String, Object> hmResult = null;
		String stAppInfo = null;

//		logger.debug("{}{}GPB_141 : Calling VoltageEncryption_H.getEFPEEncryptedValues() with hmVoltageEncrypt : {}",
//				sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmVoltageEncrypt)));

		hmResult = voltageEncryptionHelper.getEFPEEncryptedValues(hmVoltageEncrypt);

		logger.debug("{}{}GPB_142 : Response from VoltageEncryption_H.getEFPEEncryptedValues() : {}", sClassName,
				sMethodName, HtmlUtils.htmlEscape(String.valueOf(hmResult)));

		if (hmResult == null || hmResult.isEmpty()) {
			stAppInfo = "Null Response returned from VoltageEncryption_H.getEFPEEncryptedValues()";
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
			return hmResult;
		}

		return hmResult;
	}

	/**
	 * This method stores the MPS (Mobile Phone Service) data.
	 *
	 * It first retrieves various details such as the identification type, account ID, calling system ID, security code expiration hours, source, delivery method, and encrypted security code from the input HashMap.
	 *
	 * Then, it calls the getSecurityAccountData method of the SecurityCodeDBHelper class to get the security account data from the database.
	 *
	 * If the response from the getSecurityAccountData method indicates an error (other than record not found), the method constructs an error response and returns it.
	 *
	 * If the response from the getSecurityAccountData method indicates that the record was not found, the method calls the setSecurityAccountData method of the SecurityCodeDBHelper class to set the security account data in the database.
	 *
	 * If the response from the getSecurityAccountData method indicates that the record was found, the method calls the updateSecurityAccount method of the SecurityCodeDBHelper class to update the security account data in the database.
	 *
	 * After that, it calls the setSecurityCode method of the SecurityCodeDBHelper class to set the security code in the database.
	 *
	 * The method uses the SLF4J Logger for logging.
	 *
	 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code and an application info message.
	 */
	public Map<String, Object> storeMPSData() {
		String sMethodName = ".storeMPSData.";
		Map<String, Object> hmResult = null;
		String stAppInfo = null;
		String stAppStatusCode = null;
		HashMap<String, Object> hmGetDBInput = CommonUtil.getHashMap();

		try {
			String sInpAccountId = (String) hmInput.get(CommonDefs.ACCOUNT_ID);
			String sInpIdentificationType = (String) hmInput.get(CommonDefs.IDENTIFICATION_TYPE);
			String sInpCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);
			String sSecurityCodeExpirationHours = (String) hmInput.get(CommonDefs.SECURITY_PIN_EXPIRATION_HOURS);
			String sSource = (String) hmInput.get(CommonDefs.SOURCE);
			String sDeliveryMethod = (String) hmInput.get(CommonDefs.DELIVERY_METHOD);
			String sEncryptedSecurityCode = (String) hmInput.get(CommonDefs.ENCRYPTED_SECURITY_CODE);
			String sSHA256EncryptedSecurityCode = (String) hmInput.get("encryptedSHA256SecurityCode");
			String sDeliveryDetail = (String) hmInput.get(CommonDefs.DELIVERY_DETAIL);
			String sSecurityCodeExpirationTime = (String) hmInput.get("security_code_expiration_time");

			hmGetDBInput.put(MPSDefs.DB_ACCOUNT_ID, sInpAccountId);
			hmGetDBInput.put(MPSDefs.DB_IDENTIFICATION_TYPE, sInpIdentificationType);
			String otpDataSource = getOtpDataSource();
			HashMap<String, Object> hmGetDBResult  = null;

			if (!"ONLYCOSMOS".equalsIgnoreCase(otpDataSource)) {
				hmGetDBResult = securityCodeDBHelper.getSecurityAccountData(hmGetDBInput);
				logger.debug("{}{}GPB_108 : Response from  SecurityCodeDBHelper.getSecurityAccountData: {}", sClassName,
						sMethodName, hmGetDBResult);

				stAppStatusCode = (String) hmGetDBResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

				if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)
						&& !stAppStatusCode.equals(CErrorDefs.ERR_REC_NOT_FOUND)) {
					stAppInfo = (String) hmGetDBResult.get(CommonDefs.COMMON_APP_INFO);
					logger.debug("{}{}GPB_109 : Response from  SecurityCodeDBHelper.getSecurityAccountData: {}", sClassName,
							sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
					return hmResult;
				}
				HashMap<String, Object> hmDBAccountInput = CommonUtil.getHashMap();

				hmDBAccountInput.put(MPSDefs.DB_IDENTIFICATION_TYPE, sInpIdentificationType);
				hmDBAccountInput.put(MPSDefs.DB_LAST_MODIFIED_BY, sInpCallingSystemId);
				hmDBAccountInput.put(MPSDefs.DB_ACCOUNT_ID, sInpAccountId);
				hmDBAccountInput.put("security_code_expiration_time", sSecurityCodeExpirationTime);
				hmDBAccountInput.put(ProfileOrchestrationConstants.EXPIRY_TIME_UNIT,
						hmInput.get(ProfileOrchestrationConstants.EXPIRY_TIME_UNIT));

				if (CErrorDefs.ERR_REC_NOT_FOUND.equals(stAppStatusCode)) {

					logger.debug("{}{}GPB_110 : Calling SecurityCodeDBHelper.setSecurityAccountData with input: {}",
							sClassName, sMethodName, hmDBAccountInput);
					hmResult = securityCodeDBHelper.setSecurityAccountData(hmDBAccountInput);
					logger.debug("{}{}GPB_111 : Response from  SecurityCodeDBHelper.setSecurityAccountData: {}", sClassName,
							sMethodName, hmResult);

					stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

					if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
						stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
						logger.debug("{}{}GPB_112 : {}", sClassName, sMethodName, stAppInfo);
						hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
						return hmResult;
					}
				} else {

					logger.debug("{}{}GPB_113 : Calling SecurityCodeDBHelper.updateSecurityAccount with input: {}",
							sClassName, sMethodName, hmDBAccountInput);

					hmResult = securityCodeDBHelper.updateSecurityAccount(hmDBAccountInput, true);

					logger.debug("{}{}GPB_114 : Response from  SecurityCodeDBHelper.updateSecurityAccount: {}", sClassName,
							sMethodName, hmResult);

					stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

					if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
						stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
						logger.debug("{}{}GPB_115 : {}", sClassName, sMethodName, stAppInfo);
						hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
						return hmResult;
					}
				}

				HashMap<String, Object> hmDBInsert = CommonUtil.getHashMap();

				hmDBInsert.put(MPSDefs.DB_IDENTIFICATION_TYPE, sInpIdentificationType);
				hmDBInsert.put(MPSDefs.DB_ACCOUNT_ID, sInpAccountId);
				hmDBInsert.put(MPSDefs.DB_LAST_MODIFIED_BY, sInpCallingSystemId);
				hmDBInsert.put("security_code_expiration_time", sSecurityCodeExpirationTime);
				hmDBInsert.put(CommonDefs.SOURCE, sSource);
				hmDBInsert.put(MPSDefs.DB_DELIVERY_METHOD, sDeliveryMethod);
				hmDBInsert.put(MPSDefs.DB_SECURITY_CODE, sEncryptedSecurityCode);
				hmDBInsert.put(MPSDefs.DB_DELIVERY_DETAIL, sDeliveryDetail);
				hmDBInsert.put(ProfileOrchestrationConstants.EXPIRY_TIME_UNIT, hmInput.get(ProfileOrchestrationConstants.EXPIRY_TIME_UNIT));

				logger.debug(SpiMarker.getInstance(),
						"GeneratePINBase.storeMPSData.GPB_116 : Calling SecurityCodeDBHelper.setSecurityCode with input: {}",
						StructuredArguments.entries(hmDBInsert));
				hmResult = securityCodeDBHelper.setSecurityCode(hmDBInsert);

				logger.debug("{}{}GPB_117 : Response from  SecurityCodeDBHelper.setSecurityCode: {}", sClassName,
						sMethodName, hmResult);

				stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

				if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {
					stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
					logger.debug("{}{}GPB_118 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
					return hmResult;
				}
			}

			if(!"ONLYORACLE".equalsIgnoreCase(otpDataSource)) {
				try {
				IdgOtpContainer queryContainer = new IdgOtpContainer();
				queryContainer.setIdentificationType(sInpIdentificationType);
				queryContainer.setAccountId(sInpAccountId);

				Optional<IdgOtpContainer> existingContainer = idgOtpDBHelper.findByIdentificationTypeAndAccountId(queryContainer);
				IdgOtpContainer idgOtpContainer;
				if (existingContainer.isEmpty()) {
					// No container found, create a new one
					idgOtpContainer = new IdgOtpContainer();
					idgOtpContainer.setIdentificationType(sInpIdentificationType);
					idgOtpContainer.setAccountId(sInpAccountId);
					idgOtpContainer.setCumulativeFailureCount(0);

				} else {
					// Container found, update the existing one
					idgOtpContainer = existingContainer.get();
				}
				// Remove expired PINs from the document to prevent unbounded growth
				try {
					int removedCount = idgOtpDBHelper.removeExpiredSecurityCodes(sInpIdentificationType, sInpAccountId);
					if (removedCount > 0) {
						logger.info("{}{}GPB_109a : Removed {} expired security codes for IdentificationType: {}, AccountId: {}",
								sClassName, sMethodName, removedCount, sInpIdentificationType, sInpAccountId);
						// Re-fetch the container after removal to get updated state
						Optional<IdgOtpContainer> refreshedContainer = idgOtpDBHelper.findByIdentificationTypeAndAccountId(
								idgOtpContainer);
						if (refreshedContainer.isPresent()) {
							idgOtpContainer = refreshedContainer.get();
						}
					}
				} catch (Exception expEx) {
					logger.warn("{}{}GPB_109b : Failed to remove expired security codes, continuing: {}",
							sClassName, sMethodName, expEx.getMessage());
				}

				// Set or update fields
				idgOtpContainer.setUpdatedBy(sInpCallingSystemId);

				// Calculate the expiration Instant by adding minutes to the current Instant (UTC)
				int minutesToAdd = 0;
				try {
					String expiryUnit = (String) hmInput.get(ProfileOrchestrationConstants.EXPIRY_TIME_UNIT);
					double expiryValue = Double.parseDouble(sSecurityCodeExpirationTime);
					if (ProfileOrchestrationConstants.HOURS.equalsIgnoreCase(expiryUnit)) {
						// expiryValue is in hours -> convert to minutes
						minutesToAdd = (int) Math.ceil(expiryValue * 60.0);
					} else {
						// default and explicit handling for minutes
						minutesToAdd = (int) Math.ceil(expiryValue);
					}
				} catch (Exception ex) {
					logger.warn("{}{}GPB_XXX : Failed to parse security code expiration time '{}' or unit; defaulting to 0 minutes: {}",
							sClassName, sMethodName, sSecurityCodeExpirationTime, ex.getMessage());
					minutesToAdd = 0;
				}

				// Use java.time.Instant for UTC-aware arithmetic
				Instant now = Instant.now();
				Instant expiryInstant = now.plusSeconds((long) minutesToAdd * 60L);
				String formattedExpiryDate = DateTimeFormatter.ISO_INSTANT.format(expiryInstant);

				// Set the calculated expiry time to the container
				idgOtpContainer.setAccountEntryExpires(formattedExpiryDate);

				// Check if the container already has a list of security codes
				List<SecurityCode> securityCodes = idgOtpContainer.getSecurityCodes();
				if (securityCodes == null) {
					// If no list exists, create a new one
					securityCodes = new ArrayList<>();
				}

				// Populate the security code attributes
				SecurityCode securityCode = new SecurityCode();
				securityCode.setSecurityCode(sSHA256EncryptedSecurityCode);
				securityCode.setVerificationFailureCount(0);
				securityCode.setSecurityCodeExpires(formattedExpiryDate);
				securityCode.setSecurityCodeStatus("ACTIVE"); // Default status
				securityCode.setSource(sSource);
				securityCode.setDeliveryMethod(sDeliveryMethod);
				securityCode.setDeliveryDetail(sDeliveryDetail);
				// Capture the creation/update instant (UTC) and set entity fields as UTC LocalDateTime
				Instant createdInstant = Instant.now();
				securityCode.setCreatedDate(LocalDateTime.ofInstant(createdInstant, ZoneId.of("UTC")));
				securityCode.setUpdatedDate(LocalDateTime.ofInstant(createdInstant, ZoneId.of("UTC")));
				securityCode.setUpdatedBy(sInpCallingSystemId);
				// Add the new security code to the list
				securityCodes.add(securityCode);

				// Set the updated list back to the container
				idgOtpContainer.setSecurityCodes(securityCodes);

				// Save the container
				IdgOtpContainer otpContainer = idgOtpDBHelper.createOrUpdateEntity(idgOtpContainer);
				logger.info("{}{}GPB_110 : Updated Cosmos DB container for IdentificationType: {}, AccountId: {}",
						sClassName, sMethodName, sInpIdentificationType, sInpAccountId);

				saveOtpHistoryAsync(otpContainer, Operation.CREATE, sInpCallingSystemId);
				final String sInpAccountIdFinal = sInpAccountId;

				if (featureManager.isEnabled("svc-idgraph-contactinfo-publishotpdata")) {
					if (otpContainer.getId() != null
							|| (otpContainer.getSecurityCodes() != null && otpContainer.getSecurityCodes().size() > 1)) {
						String eventType = OracleSecurityCodeSyncPublisher.EVENT_TYPE_INSERT;
						EventData eventData = buildEventData(sInpIdentificationType, sInpAccountIdFinal, formattedExpiryDate,
								sInpCallingSystemId, securityCode);
						otpEventPublisher.publishGeneratePinEvent(sInpAccountIdFinal, eventType, eventData);
					}
				}
				} catch (Exception cosmosEx) {
					if ("ORACLEMASTER".equalsIgnoreCase(otpDataSource)) {
						logger.error("{}{}GPB_111 : Cosmos DB ORACLEMASTER ERROR SKIP - write failed for IdentificationType: {}, AccountId: {}. Error: {}",
								sClassName, sMethodName, sInpIdentificationType, sInpAccountId, cosmosEx.getMessage(), cosmosEx);
					} else {
						throw cosmosEx;
					}
				}
			}
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
			logger.debug("{}{}GPB_115 : {}", sClassName, sMethodName, hmResult);
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
		}
		return hmResult;
	}



	/**
	 * This method prepares the data for a synchronous call to the MULESOFT service.
	 *
	 * It first retrieves various details such as the browser language, identification type, security code expiration hours, security code, security code expiration date, attribute list, and token from the input HashMap.
	 *
	 * Then, it constructs a HashMap that contains the details for the MULESOFT call. The HashMap includes the source ID, domain, customer type, event sent time, language preference, and other details.
	 *
	 * The method also constructs a HashMap for the delivery methods. If the delivery method is SMS, it retrieves the phone number and sets it to the HashMap. If the delivery method is email, it retrieves the email address and sets it to the HashMap. If the delivery method is letter, it retrieves the address details and sets them to the HashMap.
	 *
	 * If the identification type is 'ENCPIN', it sets the encrypted key and security code expiration date to the notification fields HashMap. Otherwise, it sets the security code and security code expiration date to the notification fields HashMap.
	 *
	 * Finally, the method returns a HashMap that contains the result of the operation. The HashMap contains an application status code and an application info message.
	 *
	 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code and an application info message.
	 */
	public Map<String, Object> prepareDataForCCMuleSyncCall() {

		String sMethodName = ".prepareDataForCCMuleSyncCall.";
		Map<String, Object> hmResult = null;
		String stAppInfo = null;
		ArrayList alCommunication = CommonUtil.getArrayList();
		ArrayList alCommNotifications = CommonUtil.getArrayList();
		ArrayList alTemplateData = CommonUtil.getArrayList();
		HashMap<String, Object> hmCommNotification = CommonUtil.getHashMap();
		HashMap<String, Object> hmDbusDeliveryMethods = CommonUtil.getHashMap();
		HashMap<String, Object> hmDeliveryMethods = CommonUtil.getHashMap();
		HashMap<String, Object> hmIdentification = CommonUtil.getHashMap();
		HashMap<String, Object> hmSecurityCode = CommonUtil.getHashMap();
		HashMap<String, Object> hmSecurityCodeExpire = CommonUtil.getHashMap();

		ArrayList alCtn = CommonUtil.getArrayList();
		ArrayList alEmail = CommonUtil.getArrayList();
		HashMap<String, Object> hmSMS = CommonUtil.getHashMap();
		HashMap<String, Object> hmEmail = CommonUtil.getHashMap();
		HashMap hmAccountId = CommonUtil.getHashMap();
		HashMap hmTemplateData = CommonUtil.getHashMap();
        boolean isOtpEddToClmEnabled = false;
		try {
            isOtpEddToClmEnabled = featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled");

			String sBrowserLanguage = (String) hmInput.get(CommonDefs.BROWSER_LANGUAGE);
			String sSecurityCode = (String) hmInput.get(CommonDefs.SECURITY_CODE);
			String sSecurityCodeExpirationDate = (String) hmInput.get(CommonDefs.SECURITY_PIN_EXPIRATION_DATE);
			ArrayList<Map<String, String>> alAttributes = (ArrayList) hmInput.get(CommonDefs.ATTRIBUTE_LIST);

			hmDeliveryMethods = (HashMap) hmInput.get(CommonDefs.DELIVERY_METHODS);

			if (hmDeliveryMethods != null) {
				if (hmDeliveryMethods.isEmpty()) {
					stAppInfo = "Delivery method is empty";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
					return hmResult;
				}

				if (hmDeliveryMethods.containsKey(CommonDefs.SMS)) {
					ArrayList alSMSPhone = CommonUtil.getArrayList();
					alSMSPhone.add(hmDeliveryMethods.get(CommonDefs.SMS));

					hmSMS.put(CommonDefs.SMS_PHONE, alSMSPhone);
					hmSMS.put(CommonDefs.NOTIFY_VIA_SMS, RILDefs.YES);
					hmDbusDeliveryMethods.put(CommonDefs.SMS, hmSMS);
				}
				if (hmDeliveryMethods.containsKey(CommonDefs.EMAIL)) {
					ArrayList alEmailAddressList = CommonUtil.getArrayList();
					alEmailAddressList.add(hmDeliveryMethods.get(CommonDefs.EMAIL));

					hmEmail.put(CommonDefs.EMAIL_ADDRESS_LIST, alEmailAddressList);
					hmEmail.put(CommonDefs.NOTIFY_VIA_EMAIL, RILDefs.YES);
					hmDbusDeliveryMethods.put(CommonDefs.EMAIL, hmEmail);
				}
			} else {
				stAppInfo = "Please provide a delivery method";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			HashMap<String, Object> hmCommunication = new HashMap();
			HashMap<String, Object> hmCustomerInfo = CommonUtil.getHashMap();
			hmCommunication.put(CommonDefs.SOURCE_ID, "33944");
			hmCommunication.put(CommonDefs.DOMAIN, "IdentityGraph");
			hmCommunication.put(CommonDefs.IS_CPNI_EMAIL_REQ, false);
			hmCommunication.put(CommonDefs.IS_ACCOUNT_SYNC_REQ, false);
			hmCommunication.put(CommonDefs.IS_NUMBER_VAL_REQ, false);
			hmCommunication.put(CommonDefs.IS_PREFERENCE_REQ, false);
			hmCommunication.put(CommonDefs.IS_SHORT_URL_REQ, false);

			// Customer Info
			String stIdentificationType = (String) hmInput.get(CommonDefs.IDENTIFICATION_TYPE);

			HashMap hmSubCategory = null;
            if(isOtpEddToClmEnabled){
                hmSubCategory = CommonUtil.parsePropertyToHash(propSubCategoryClm);
            } else{
                hmSubCategory = CommonUtil.parsePropertyToHash(propSubCategory);
            }
			hmCustomerInfo.put(CommonDefs.SUB_CATEGORY, (String) hmSubCategory.get(stIdentificationType));

            // Use accountType (lowercased) as serviceType if present in request, otherwise fall back to config mapping
            String accountType = (String) hmInput.get(CommonDefs.ACCOUNT_TYPE);
            if (accountType != null && !accountType.isEmpty()) {
                hmCustomerInfo.put(CommonDefs.SERVICE_TYPE, accountType.trim().toLowerCase());
            } else {
                HashMap hmIdentificationTypeToServiceTypeMapping = CommonUtil.parsePropertyToHash(propIdentificationTypeToServiceTypeMapping);
                String serviceType = (String) hmIdentificationTypeToServiceTypeMapping.get(stIdentificationType);
                if (serviceType != null) {
                    hmCustomerInfo.put(CommonDefs.SERVICE_TYPE, serviceType);
                }
            }

			
			hmSMS = (HashMap) hmDeliveryMethods.get(CommonDefs.SMS);
			hmEmail = (HashMap) hmDeliveryMethods.get(CommonDefs.EMAIL);
			if (hmSMS != null && !hmSMS.isEmpty()) {
				alCtn.add(hmSMS.get(CommonDefs.SMS_PHONE_NUMBER));
				hmCustomerInfo.put(CommonDefs.CTN, alCtn);
				hmCustomerInfo.put(CommonDefs.Mode, CommonDefs.CC_MULE_SMS);
			}
			if (hmEmail != null && !hmEmail.isEmpty()) {
				alEmail.add(hmEmail.get(CommonDefs.EMAIL_ADDRESS));
				hmCustomerInfo.put(CommonDefs.EMAIL_ID, alEmail);
				hmCustomerInfo.put(CommonDefs.Mode, CommonDefs.CC_MULE_EMAIL);
			}

			HashMap hmAo = (HashMap) hmDeliveryMethods.get(CommonDefs.AO);
			if (hmAo != null && !hmAo.isEmpty()) {
				String sAoPhoneNumber = (String) hmAo.get(CommonDefs.PHONE_NUMBER);
				ArrayList alAoTn = CommonUtil.getArrayList();
				alAoTn.add(sAoPhoneNumber);
				hmCustomerInfo.put(Constants.CLM_AO_TN, alAoTn);
				hmCustomerInfo.put(CommonDefs.Mode, CommonDefs.AO);
			}

			HashMap hmLetterInput = (HashMap) hmDeliveryMethods.get(CommonDefs.LETTER);
			if (hmLetterInput != null && !hmLetterInput.isEmpty()) {
				String sName = (String) hmLetterInput.get(CommonDefs.NAME);
				String sStreet1 = (String) hmLetterInput.get(CommonDefs.STREET1);
				String sStreet2 = (String) hmLetterInput.get(CommonDefs.STREET2);
				String sCity = (String) hmLetterInput.get(CommonDefs.CITY);
				String sState = (String) hmLetterInput.get(CommonDefs.STATE);
				String sZipCode = (String) hmLetterInput.get(CommonDefs.ZIP_CODE);
				String sCountry = (String) hmLetterInput.get(CommonDefs.COUNTRY);

				// Default country to USA if not provided for CLM
				if (StringUtils.isBlank(sCountry)) {
					sCountry = Constants.COUNTRY_USA;
				}

				HashMap<String, Object> hmAddress = CommonUtil.getHashMap();
				hmAddress.put(Constants.CLM_ADDRESS_CLASSIFICATION, Constants.CLM_ADDRESS_CLASSIFICATION_SERVICE);
				if (sName != null && !sName.trim().isEmpty()) {
					hmAddress.put(Constants.CLM_ADDRESS_NAME, sName);
				}
				hmAddress.put(CommonDefs.ADDRESS1, sStreet1);
				if (sStreet2 != null && !sStreet2.trim().isEmpty()) {
					hmAddress.put(CommonDefs.ADDRESS2, sStreet2);
				}
				hmAddress.put(CommonDefs.CITY, sCity);
				hmAddress.put(CommonDefs.STATE, sState);
				hmAddress.put(CommonDefs.COUNTRY, sCountry);
				hmAddress.put(CommonDefs.ZIP, sZipCode);

				ArrayList alAddresses = CommonUtil.getArrayList();
				alAddresses.add(hmAddress);
				hmCustomerInfo.put(Constants.CLM_ADDRESSES, alAddresses);
				hmCustomerInfo.put(CommonDefs.Mode, Constants.CC_MULE_POSTAL);
			}

			hmCustomerInfo.put(CommonDefs.PRIORITY, CommonDefs.HIGH);
			if (hmInput.get(CommonDefs.RES_BUS_IND)!=null) {
				hmCustomerInfo.put(CommonDefs.CUSTOMER_TYPE, (String) hmInput.get(CommonDefs.RES_BUS_IND));
			}else{
				hmCustomerInfo.put(CommonDefs.CUSTOMER_TYPE, CommonDefs.INDIVIDUAL);
			}
			SimpleDateFormat gmtDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			gmtDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
			hmCustomerInfo.put(CommonDefs.EVENTSENTTIME, gmtDateFormat.format(new java.util.Date()));
			if (sBrowserLanguage != null && !sBrowserLanguage.isEmpty())
				hmCustomerInfo.put(CommonDefs.LANGUAGE_PREFERENCE, sBrowserLanguage);
			else
				hmCustomerInfo.put(CommonDefs.LANGUAGE_PREFERENCE, CommonDefs.LANGUAGE_EN);

			hmIdentification.put(CommonDefs.NAME, CommonDefs.IDENTIFICATION_TYPE);
			hmIdentification.put(CommonDefs.VALUE, stIdentificationType);
			hmSecurityCode.put(CommonDefs.NAME, CommonDefs.OTP);
			hmSecurityCode.put(CommonDefs.VALUE, sSecurityCode);

			hmSecurityCodeExpire.put(CommonDefs.NAME, CommonDefs.OTP_EXPIRES);
			hmSecurityCodeExpire.put(CommonDefs.VALUE, sSecurityCodeExpirationDate);
			
			hmAccountId.put(CommonDefs.NAME, CommonDefs.ACCOUNT_ID);
			hmAccountId.put(CommonDefs.VALUE, hmInput.get(CommonDefs.ACCOUNT_ID));

			ArrayList alComplexVal = CommonUtil.getArrayList();
			alComplexVal.add(hmIdentification);

				alTemplateData.add(hmSecurityCode);
				alTemplateData.add(hmSecurityCodeExpire);

				if (alAttributes != null && !alAttributes.isEmpty()) {

					for (Map<String, String> hmAttributes : alAttributes) {

						if (hmAttributes != null && !hmAttributes.isEmpty()) {
							HashMap<String, Object> hmAttributeMap = CommonUtil.getHashMap();
							hmAttributeMap.put(CommonDefs.NAME, hmAttributes.get(CommonDefs.ATTRIBUTE_NAME));
							hmAttributeMap.put(CommonDefs.VALUE, hmAttributes.get(CommonDefs.ATTRIBUTE_VALUE));
							alTemplateData.add(hmAttributeMap);
						} else {
							logger.error("Unexpected type in alAttributes: {}", alAttributes.getClass().getName());
						}

					}
				}

				
				hmTemplateData.put(CommonDefs.NAME, "templateData");
				hmTemplateData.put(CommonDefs.VALUE, alTemplateData);
				alComplexVal.add(hmTemplateData);
			alComplexVal.add(hmAccountId);

			hmCustomerInfo.put(CommonDefs.COMPLEX_VALUE, alComplexVal);

			ArrayList alCustomers = CommonUtil.getArrayList();
			alCustomers.add(hmCustomerInfo);
			hmCommunication.put(CommonDefs.CUSTOMERS, alCustomers);
			alCommunication.add(hmCommunication);

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
			hmResult.put(CommonDefs.COMMUNICATION_NOTIFICATION, alCommunication);
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown prepareDataForCCMuleSyncCall method : " + hmResult;
			logger.error("{}{}GPB_142.3 :  {} ", sClassName, sMethodName, stAppInfo);
		}

		return hmResult;
	}

	/**
	 * this method  genericOTPmessageObject, generates the GenericOTP AEH request to publish
	 * @param hmInput input hashmap
	 * @return GenericOTPNotification
	 */

	public GenericOTPNotification genericOTPmessageObject(Map<String, Object> hmInput) {
		GenericOTPNotification request = new GenericOTPNotification();
		NotificationDetails notificationdetails = new NotificationDetails();
		ArrayList<Attributes> attributesList = CommonUtil.getArrayList();
		String stIdentificationType = (String) hmInput.get(CommonDefs.IDENTIFICATION_TYPE);
		String stbrowserLanguage = (String) hmInput.get(CommonDefs.BROWSER_LANGUAGE);
		SimpleDateFormat gmtDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		gmtDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));

		logger.info("CommonUtilHelper.CUHAEH_01 : Input Data: {} ", hmInput);
		if(hmInput != null && !hmInput.isEmpty()) {
			request.setNotificationID("IDGRAPHContactInfoMs-"+(String) hmInput.get("idpTraceId"));
			request.setNotificationType("OTP");
			request.setNotificationCategory(ProfileOrchestrationConstants.TRANSACTION_NAME_GENERATE_PIN);
			request.setNotificationsubCategory(stIdentificationType);
			request.setNotificationTime(gmtDateFormat.format(new java.util.Date()));

			notificationdetails.setAccountId((String) hmInput.get(CommonDefs.ACCOUNT_ID));

			if(stIdentificationType.equalsIgnoreCase("PORTOUTBSS"))
				notificationdetails.setAccountType("BSSEWIRELESS");
			else
				notificationdetails.setAccountType("WIRELESS");

			if (stbrowserLanguage != null && !stbrowserLanguage.isEmpty())
				notificationdetails.setLangPreference(stbrowserLanguage.toUpperCase());
			else
				notificationdetails.setLangPreference("EN");
			notificationdetails.setCustomerType("R");
			notificationdetails.setClientId((String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
			if((String) hmInput.get("channel") != null) {
				notificationdetails.setChannel((String) hmInput.get("channel"));
			}
			notificationdetails.setCommunicationMode("BOTH");
			notificationdetails.setOTPExpires((String) hmInput.get(CommonDefs.SECURITY_PIN_EXPIRATION_DATE));

			HashMap<String, Object> hmDeliveryMethods = CommonUtil.getHashMap();
			hmDeliveryMethods = (HashMap) hmInput.get(CommonDefs.DELIVERY_METHODS);
			String phoneNumberOTP=null, emailAddressOTP=null;

			if (hmDeliveryMethods != null && !hmDeliveryMethods.isEmpty() && hmDeliveryMethods.containsKey(CommonDefs.SMS))
				phoneNumberOTP = (String)((HashMap)hmDeliveryMethods.get(CommonDefs.SMS)).get("smsPhoneNumber");

			if (hmDeliveryMethods != null && !hmDeliveryMethods.isEmpty() && hmDeliveryMethods.containsKey(CommonDefs.EMAIL))
				emailAddressOTP = (String)((HashMap)hmDeliveryMethods.get(CommonDefs.EMAIL)).get("emailaddress");


			if(stIdentificationType.equalsIgnoreCase("PORTOUTBSS"))
			{
				notificationdetails.setAccountType("BSSEWIRELESS");
				attributesList.add(new Attributes("isBsseEvent", "Y"));
			}
			else
			{
				attributesList.add(new Attributes("isBsseEvent", "N"));

				if (phoneNumberOTP != null && !phoneNumberOTP.isEmpty())
				    attributesList.add(new Attributes("phoneNumber", phoneNumberOTP));
				else if (emailAddressOTP != null && !emailAddressOTP.isEmpty())
					attributesList.add(new Attributes("emailAddress", emailAddressOTP));
			}
			notificationdetails.setAttributeList(attributesList);
			request.setNotificationDetails(notificationdetails);


		}

		logger.info("CommonUtilHelper.CUHAEH_02 :message to publish: {}  {}", request.toString(), request);

		return request;
	}

	/**
	 * This method makes an asynchronous call.
	 *
	 * It first retrieves the transaction ID from the input HashMap.
	 * Then, it checks if the 'propStubCCMULECall' property is set to 'N'. If it is, the method constructs a HashMap for the MULESOFT call and adds it to the result HashMap.
	 * If the 'propStubCCMULECall' property is not set to 'N', the method calls the 'postCCMuleSyncCall' method of the 'muleSoftRestClient' class to make the MULESOFT call.
	 * The method then checks the response from the 'postCCMuleSyncCall' method. If the response indicates an error, the method constructs an error response and returns it.
	 * If the response from the 'postCCMuleSyncCall' method indicates success, the method constructs a success response and returns it.
	 * If the 'propStubCCMULECall' property is set to 'N', the method calls the 'callStubCcmuleMS' method to get the stub data for the MULESOFT call.
	 * The method then checks the response from the 'callStubCcmuleMS' method. If the response indicates an error, the method constructs an error response and returns it.
	 * If the response from the 'callStubCcmuleMS' method indicates success, the method constructs a success response and returns it.
	 *
	 * @param alDbusInput an ArrayList that contains the input data for the MULESOFT call.
	 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code and an application info message.
	 * @throws Exception if an error occurs during the operation.
	 */
	public HashMap<String, Object> makeCCMuleSyncCall(ArrayList alDbusInput) {
		String sMethodName = ".makeCCMuleSyncCall.";
		HashMap<String, Object> hmRestCall = CommonUtil.getHashMap();
		HashMap<String, Object> hmNotification = CommonUtil.getHashMap();
		HashMap<String, Object> hmResult = CommonUtil.getHashMap();
		String stAppStatusCode = null;
		String stAppInfo = null;
		String clmurl = null;

		String clmregularurl = ccmulesoftServerUrl + ccmulesoftEndpoint;
		String clmHighPriorityUrl = clmHighPriorityServerUrl + clmHighPriorityEndpoint;
        boolean isOtpEddToClmEnabled = false;

		try {
            isOtpEddToClmEnabled = featureManager.isEnabled("svc-idgraph-phase1-otp-edd-to-clm-enabled");

			String sTransactionId = (String) hmInput.get(CommonDefs.TRANSACTION_ID);


			hmNotification.put(CommonDefs.COMMUNICATION, alDbusInput);

			if (propStubCCMULECall == null || propStubCCMULECall.trim().isEmpty()) {
				stAppInfo = "PROP_CALL_CCMULE_STUB Config is null or empty";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM, stAppInfo);
				logger.error("{}{}GPB_141.1 :  {} ", sClassName, sMethodName, stAppInfo);
				return hmResult;
			}
			logger.info("{}{}GPB_141.2: PROP_CALL_CCMULE_STUB : {}", sClassName, sMethodName, propStubCCMULECall);

			if (propStubCCMULECall.equalsIgnoreCase(CommonDefs.IND_N)) {

				logger.info(SpiMarker.getInstance(),"{}{}GPB_141.3: calling muleSoftRestClient.postCCMuleSyncCall with input :{}",sClassName , sMethodName
						,hmNotification);

                ArrayList alHighPriorityIdentificationTypes = null;
                if(isOtpEddToClmEnabled){
                    alHighPriorityIdentificationTypes = CommonUtil.parseToArray(propHighPriorityIdentificationTypesClm, CommonDefs.VALUE_SEPARATOR_CHAR);
                } else{
                    alHighPriorityIdentificationTypes = CommonUtil.parseToArray(propHighPriorityIdentificationTypes, CommonDefs.VALUE_SEPARATOR_CHAR);
                }

				logger.info("{}{}GPB_141.13 : alHighPriorityIdentificationTypes : {} ", sClassName, sMethodName,
                        alHighPriorityIdentificationTypes != null ? alHighPriorityIdentificationTypes.toString() : "null");
				if (alHighPriorityIdentificationTypes != null && alHighPriorityIdentificationTypes.contains((String) hmInput.get(CommonDefs.IDENTIFICATION_TYPE)))
					clmurl = clmHighPriorityUrl;
				else
					clmurl = clmregularurl;
				logger.info("{}{}GPB_141.14 : clm url : {}", sClassName, sMethodName, clmurl);

				// external call to ccmule
				hmResult = (HashMap<String, Object>) muleSoftRestClient.postCCMuleSyncCall(hmNotification, sTransactionId, clmurl);

				logger.info("{}{}GPB_141.4 : ResponseHash from muleSoftRestClient.postCCMuleSyncCall : {}", sClassName,
						sMethodName, hmResult);
				if (hmResult == null || hmResult.isEmpty()) {
					stAppInfo = "Null Response returned by muleSoftRestClient.postCCMuleSyncCall";
					logger.info("{}{}GPB_141.5 : {}", sClassName, sMethodName, stAppInfo);
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
					return hmResult;
				} else {
					stAppStatusCode = (String) hmResult.get(MPSDefs.APP_STATUS_CODE);
					if (!CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
						stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
						logger.info("{}{}GPB_141.6 : {}", sClassName, sMethodName, stAppInfo);
						return hmResult;
					}
				}
			} else {

				logger.info("{}{}GPB_141.8: Requesting Stub data for Mulesoft MS call for GeneratePin ",
						sClassName, sMethodName);
				hmResult = callStubCcmuleMS();

				logger.info("{}{}GPB_141.9 : ResponseHash from callStubCcmuleMS : {}", sClassName, sMethodName,
						hmResult);
			}
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
			String sReturnSecurityCode = (String) hmInput.get(CommonDefs.RETURN_SECURITY_CODE);
			if (MPSDefs.YES.equalsIgnoreCase(sReturnSecurityCode)) {
				hmResult.put(CommonDefs.SECURITY_CODE, (String) hmInput.get(CommonDefs.SECURITY_CODE));
			}
			hmResult.put(CommonDefs.SECURITY_PIN_EXPIRATION_DATE,
					(String) hmInput.get(CommonDefs.SECURITY_PIN_EXPIRATION_DATE));

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
			stAppInfo = "Exception thrown makeCCMuleSyncCall method : " + hmResult;
			logger.error("{}{}GPB_142.1 :  {} ", sClassName, sMethodName, stAppInfo);
		}

		return hmResult;
	}
	
	/**
	 * Publishes a Generic OTP notification message to Azure Event Hub.
	 *
	 * <p>
	 * Builds a {@link GenericOTPNotification} from the provided input map, serializes it to JSON, and
	 * sends the JSON payload using the configured publisher.
	 * </p>
	 *
	 * @param hmInput input map used to build the {@link GenericOTPNotification}
	 * @return a result map containing status code and message
	 */
	public HashMap<String, Object> makeGenericOTPAEHCall(Map<String, Object> hmInput) {
		String sMethodName = "makeGenericOTPAEHCall";
		HashMap<String, Object> hmResult = CommonUtil.getHashMap();
		String stAppStatusCode = null;
		String jsonMessage = null;
		String stAppInfo = null;

		try {
			
			ObjectMapper mapper = JsonService.getMapper();
			jsonMessage = mapper.writeValueAsString(genericOTPmessageObject(hmInput));
			logger.info("{}{}GPB_142.01 :  {} ", sClassName, sMethodName, jsonMessage);
			gotpPublisher.sendToPrimary(jsonMessage);
			
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "SUCCESS");

		} 
		       
        catch (PrimaryProducerException | SecondaryProducerException ex) {
			hmResult = CommonErrorMap.makeExceptionMap(ex);
			stAppInfo = "Exception thrown makeGenericOTPAEHCall method : " + hmResult;
			logger.error("{}{}GPB_142.1 :  {} ", sClassName, sMethodName, stAppInfo);
		}
		catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e);
			String exceptionCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
			logger.info("{}{}GPB_142.2 : {} Exception:: {} ", sClassName, sMethodName, exceptionCode, e.getMessage());
			return hmResult;
		}

		return hmResult;
	}

	/**
	 * returning stub data for ccmule
	 *
	 * @return
	 */
	private HashMap<String, Object> callStubCcmuleMS() {

		String sMethodName = ".callStubCcmuleMS.";
				
		String sTransactionId = "STUB_Txid";
		String stCCMULEResponse = "{\r\n" + "\"message\": \"" + "Success" + "\",\r\n" + "\"traceId\": \""
				+ sTransactionId + "\"" + "}";
		HashMap<String, Object> hmResult = new HashMap<>();
		try {

			HashMap<String, Object> hmSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
					CommonDefs.COMMON_SUCCESS_MSG);

			hmResult = (HashMap) JsonUtils.jsonToMap(stCCMULEResponse);
			hmResult.putAll(hmSuccess);
		} catch (Exception e) {

			hmResult = CommonErrorMap.makeExceptionMap(e);
			String exceptionCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);
			logger.info("{}{}GPB_142.2 : {} Exception:: {} ", sClassName, sMethodName, exceptionCode, e.getMessage());
			return hmResult;
		}
		return hmResult;
	}

	/**
	 * This method prepares the data for an asynchronous call.
	 *
	 * It first retrieves various details such as the browser language, identification type, security code expiration hours, security code, security code expiration date, attribute list, and token from the input HashMap.
	 *
	 * Then, it constructs a HashMap that contains the details for the asynchronous call. The HashMap includes the source ID, domain, customer type, event sent time, language preference, and other details.
	 *
	 * The method also constructs a HashMap for the delivery methods. If the delivery method is SMS, it retrieves the phone number and sets it to the HashMap. If the delivery method is email, it retrieves the email address and sets it to the HashMap. If the delivery method is letter, it retrieves the address details and sets them to the HashMap.
	 *
	 * If the identification type is 'ENCPIN', it sets the encrypted key and security code expiration date to the notification fields HashMap. Otherwise, it sets the security code and security code expiration date to the notification fields HashMap.
	 *
	 * Finally, the method returns a HashMap that contains the result of the operation. The HashMap contains an application status code and an application info message.
	 *
	 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code and an application info message.
	 */
	public Map<String, Object> prepareDataForAsyncCall() {
		String sMethodName = ".prepareDataForAsyncCall.";
		Map<String, Object> hmResult = null;
		ArrayList alConsDbus = CommonUtil.getArrayList();
		HashMap<String, Object> hmDbusInput = CommonUtil.getHashMap();

		try {
			String sBrowserLanguage = (String) hmInput.get(CommonDefs.BROWSER_LANGUAGE);
			String sInpIdentificationType = (String) hmInput.get(CommonDefs.IDENTIFICATION_TYPE);
			String sSecurityCodeExpirationTime = (String) hmInput.get("security_code_expiration_time");
			String sSecurityCode = (String) hmInput.get(CommonDefs.SECURITY_CODE);
			String sSecurityCodeExpirationDate = (String) hmInput.get(CommonDefs.SECURITY_PIN_EXPIRATION_DATE);
			List alAttributes = (ArrayList) hmInput.get(CommonDefs.ATTRIBUTE_LIST);
			String sToken = (String) hmInput.get(CommonDefs.TOKEN);
			if (sBrowserLanguage != null && !sBrowserLanguage.isEmpty()) {
				hmDbusInput.put(CommonDefs.BROWSER_LANGUAGE, sBrowserLanguage);
			}


			if (sSecurityCodeExpirationTime != null && sSecurityCodeExpirationTime.trim().length() > 0) {

				double dSecurityCodeExpirationTime = Double.parseDouble(sSecurityCodeExpirationTime);
				double dSecurityCodeExpirationHours = DateUtil.getsecurityCodeExpiryTime(dSecurityCodeExpirationTime,
						(String) hmInput.get(ProfileOrchestrationConstants.EXPIRY_TIME_UNIT));

				hmDbusInput.put(CommonDefs.EXPIRATION_DAYS, Double.toString(dSecurityCodeExpirationHours));
				hmDbusInput.put(CommonDefs.EXPIRATION_HOURS, sSecurityCodeExpirationTime+" minutes");
			}

			hmDbusInput.put(CommonDefs.SUBEVENT, CommonDefs.EDDORC);
			hmDbusInput.put(CommonDefs.IDENTIFICATION_TYPE, sInpIdentificationType);
			hmDbusInput.put(CommonDefs.TRANSACTION_NAME, CommonDefs.TRANS_NAME_GENERATE_SECURITY_CODE);

			if (hmInput.get(CommonDefs.DELIVERY_METHODS) != null) {
				HashMap<String, Object> hmDbusDeliveryMethods = CommonUtil.getHashMap();
				HashMap<String, Object> hmDeliveryMethods = (HashMap) hmInput.get(CommonDefs.DELIVERY_METHODS);
				if (hmDeliveryMethods.get(CommonDefs.SMS) != null) {
					HashMap<String, Object> hmSMS = CommonUtil.getHashMap();
					ArrayList alSMSPhone = CommonUtil.getArrayList();
					alSMSPhone.add(hmDeliveryMethods.get(CommonDefs.SMS));

					hmSMS.put(CommonDefs.SMS_PHONE, alSMSPhone);
					hmSMS.put(CommonDefs.NOTIFY_VIA_SMS, RILDefs.YES);
					hmDbusDeliveryMethods.put(CommonDefs.SMS, hmSMS);
				}

				if (hmDeliveryMethods.get(CommonDefs.EMAIL) != null) {
					HashMap<String, Object> hmEmail = CommonUtil.getHashMap();
					ArrayList alEmailAddressList = CommonUtil.getArrayList();
					alEmailAddressList.add(hmDeliveryMethods.get(CommonDefs.EMAIL));

					hmEmail.put(CommonDefs.EMAIL_ADDRESS_LIST, alEmailAddressList);
					hmEmail.put(CommonDefs.NOTIFY_VIA_EMAIL, RILDefs.YES);
					hmDbusDeliveryMethods.put(CommonDefs.EMAIL, hmEmail);
				}

				if (hmDeliveryMethods.get(CommonDefs.LETTER) != null) {
					HashMap<String, Object> hmLetter = (HashMap) hmDeliveryMethods.get(CommonDefs.LETTER);
					hmLetter.put(CommonDefs.NOTIFY_VIA_LETTER, RILDefs.YES);
					hmDbusDeliveryMethods.put(CommonDefs.LETTER, hmLetter);
				}

				if (hmDeliveryMethods.get(CommonDefs.AO) != null) {
					HashMap hmPhone = CommonUtil.getHashMap();
					ArrayList alphoneInfoList = CommonUtil.getArrayList();

					hmPhone.put(CommonDefs.PHONE_INFO, hmDeliveryMethods.get(CommonDefs.AO));
					alphoneInfoList.add(hmPhone);

					HashMap<String, Object> hmphoneInfo = CommonUtil.getHashMap();
					hmphoneInfo.put(CommonDefs.NOTIFY_VIA_PHONE, RILDefs.YES);
					hmphoneInfo.put(CommonDefs.PHONE_INFO_LIST, alphoneInfoList);

					hmDbusDeliveryMethods.put(CommonDefs.PHONE, hmphoneInfo);
				}

				if (hmDbusDeliveryMethods != null && !hmDeliveryMethods.isEmpty()) {
					hmDbusInput.put(CommonDefs.DELIVERY_METHODS, hmDbusDeliveryMethods);
				}

			}

			if (alAttributes != null && !alAttributes.isEmpty()) {
				hmDbusInput.put(CommonDefs.ATTRIBUTE_LIST, alAttributes);
			}

			hmDbusInput.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
			hmDbusInput.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(DBUS_TRANSACTION_ID));
			hmDbusInput.put(CommonDefs.EVENTNAME, CommonDefs.EDDORC_NOTIFICATION);
			String sAccountID = (String) hmInput.get(CommonDefs.ACCOUNT_ID);
			hmDbusInput.put("accountID", sAccountID);
			if (sAccountID.matches("[0-9]+"))
				hmDbusInput.put("ban", (String) sAccountID); // R2011: Changes for Wireless ban scenario, sending blank
																// BAN to EDD

			if (hmInput.containsKey(CommonDefs.RES_BUS_IND)) {
				hmDbusInput.put(CommonDefs.ACCOUNT_TYPE, (String) hmInput.get(CommonDefs.RES_BUS_IND));
			}
			HashMap<String, Object> hmNotificationFields = CommonUtil.getHashMap();
			if (StringUtils.isNotBlank(sInpIdentificationType)
					&& sInpIdentificationType.equalsIgnoreCase(CommonDefs.IDENTIFICATION_TYPE_ENCPIN)) {
				hmNotificationFields.put(CommonDefs.ENCRYPTED_KEY, sToken);
				hmNotificationFields.put(CommonDefs.SECURITY_CODE_EXPIRES, sSecurityCodeExpirationDate);
			} else {
				hmNotificationFields.put(CommonDefs.SECURITY_CODE, sSecurityCode);
				hmNotificationFields.put(CommonDefs.SECURITY_CODE_EXPIRES, sSecurityCodeExpirationDate);
			}
			hmDbusInput.put(CommonDefs.NOTIFICATION_FIELDS, hmNotificationFields);

			hmDbusInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);

			hmDbusInput.put(CommonDefs.ORIG_TRANSID, (String) hmInput.get(DBUS_TRANSACTION_ID));

			alConsDbus.add(hmDbusInput);
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "SUCCESS");

			if (alConsDbus != null && !alConsDbus.isEmpty()) {
				hmResult.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, alConsDbus);
			}

//			logger.info(SpiMarker.getInstance(),"GeneratePINBase.prepareDataForAsyncCall.GPB_135 : response hash from prepareDataForAsyncCall: {}",
//					StructuredArguments.entries(hmResult));
		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
		}
		return hmResult;
	}

	/**
	 * This method makes an asynchronous call.
	 *
	 * It first retrieves the transaction ID from the input HashMap.
	 * Then, it checks if the 'propStubCCMULECall' property is set to 'N'. If it is, the method constructs a HashMap for the MULESOFT call and adds it to the result HashMap.
	 * If the 'propStubCCMULECall' property is not set to 'N', the method calls the 'postCCMuleSyncCall' method of the 'muleSoftRestClient' class to make the MULESOFT call.
	 * The method then checks the response from the 'postCCMuleSyncCall' method. If the response indicates an error, the method constructs an error response and returns it.
	 * If the response from the 'postCCMuleSyncCall' method indicates success, the method constructs a success response and returns it.
	 * If the 'propStubCCMULECall' property is set to 'N', the method calls the 'callStubCcmuleMS' method to get the stub data for the MULESOFT call.
	 * The method then checks the response from the 'callStubCcmuleMS' method. If the response indicates an error, the method constructs an error response and returns it.
	 * If the response from the 'callStubCcmuleMS' method indicates success, the method constructs a success response and returns it.
	 *
	 * @param alDbusInput an ArrayList that contains the input data for the MULESOFT call.
	 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code and an application info message.
	 * @throws Exception if an error occurs during the operation.
	 */
	public HashMap makeAsyncCall(ArrayList alDbusInput) {
		String sMethodName = ".makeAsyncCall.";
		HashMap hmResult = CommonUtil.getHashMap();
		String sCallDbus = (String) hmInput.get(CommonDefs.CALLDBUS);
		HashMap hmDbusInput = CommonUtil.getHashMap();
		String stAppStatusCode = null;
		String stAppInfo = null;

		try {
			hmDbusInput.put(CommonDefs.DBUS_DICTIONARY_NAME, CommonDefs.DBUS_COMMON_DICTIONARY_NAME_VALUE);
			hmDbusInput.put(CommonDefs.MAIN_HASH_KEY, (String) hmInput.get(CommonDefs.ACCOUNT_ID));
			hmDbusInput.put(CommonDefs.MS_OPERTAION, "GeneratePIN");
			hmDbusInput.put(CommonDefs.TRANSACTION_NAME, "GeneratePIN");
			hmDbusInput.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));
			hmDbusInput.put(CommonDefs.EVENTNAME, CommonDefs.MICRO_SERVICE_EVENT);
			hmDbusInput.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(DBUS_TRANSACTION_ID));
			hmDbusInput.put(CommonDefs.EVENTS_DATA, alDbusInput);

			if (sCallDbus != null && sCallDbus.equals(CommonDefs.IND_N)) {
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "SUCCESS");
				hmResult.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, hmDbusInput);
			} else {

				HashMap hmInpDeliveryMethods = (HashMap) hmInput.get(CommonDefs.DELIVERY_METHODS);

				if (hmInpDeliveryMethods != null && !hmInpDeliveryMethods.isEmpty()) {

				
					logger.info(SpiMarker.getInstance(),
							sClassName + sMethodName + "GPB_140.1 : Calling JMSQueueSender.send with inputHash : {}",
							StructuredArguments.entries(hmDbusInput));

					hmResult = (HashMap) oJMSQueueSender.send((Map) hmDbusInput);

					logger.info("{}{}GPB_140.2 : ResponseHash from JMSQueueSender.send : {}", sClassName, sMethodName,
							hmResult);

					if (hmResult == null) {
						stAppInfo = "Null Response returned from JMSQueueSender.send";
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
						logger.info("{}{}GPB_140.3 : {}", sClassName, sMethodName, stAppInfo);
						return hmResult;
					}

					stAppStatusCode = (String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE);

					if (stAppStatusCode != null && !stAppStatusCode.equals(CommonDefs.COMMON_SUCCESS)) {

						stAppInfo = (String) hmResult.get(CommonDefs.COMMON_APP_INFO);
						logger.info("{}{}GPB_140.4 : {}", sClassName, sMethodName, stAppInfo);
						hmResult = CommonErrorMap.makeCategoryMap(Integer.parseInt(stAppStatusCode), stAppInfo);
						return hmResult;
					}
				} else {
					logger.info("{}{}GPB_140.5 : Dbus call not made as deliverymethod is null", sClassName,
							sMethodName);
				}
			}

			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "SUCCESS");
			String sReturnSecurityCode = (String) hmInput.get(CommonDefs.RETURN_SECURITY_CODE);
			if (MPSDefs.YES.equalsIgnoreCase(sReturnSecurityCode)) {
				hmResult.put(CommonDefs.SECURITY_CODE, (String) hmInput.get(CommonDefs.SECURITY_CODE));
			}

			hmResult.put(CommonDefs.SECURITY_PIN_EXPIRATION_DATE,
					(String) hmInput.get(CommonDefs.SECURITY_PIN_EXPIRATION_DATE)); // 1810 : return
																					// stSecurityCodeExpiryDate always
																					// irrespective to
																					// sReturnSecurityCode value

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
		}
		return hmResult;
	}

	/**
	 * This method generates a security code of a specified length.
	 *
	 * It uses the SecureRandom class to generate a random number within the range of the length of the security code characters.
	 * The security code characters are the digits from 0 to 9.
	 *
	 * The method then appends the randomly selected character to a StringBuilder until the specified length is reached.
	 *
	 * @param stSecurityCodeLength a String that specifies the length of the security code to be generated.
	 * @return a String that represents the generated security code.
	 * @throws NoSuchAlgorithmException if no Provider supports a SecureRandomSpi implementation for the specified algorithm.
	 */
	public String createSecurityCode(String stSecurityCodeLength) {

		String securityCodeChar = "0123456789";
		int strLength = securityCodeChar.length();

		StringBuilder buf;

		char c = 0;
		SecureRandom secRandom = new SecureRandom();
		buf = new StringBuilder();

		int randNum = 0;

		int iSecurityCodeLength = Integer.parseInt(stSecurityCodeLength);

		for (int i = 0; i < iSecurityCodeLength; i++) {

			randNum = secRandom.nextInt(strLength);

			c = (char)securityCodeChar.charAt(randNum);
			buf.append(c);
		}
		return buf.toString();
	}

	/**
	 * This method retrieves the delivery method and details from the provided HashMap.
	 *
	 * It first checks if the provided HashMap is not null and not empty. If it is, the method returns an error response.
	 *
	 * Then, it checks if the HashMap contains the keys 'SMS', 'EMAIL', 'LETTER', and 'AO'. If it does, it retrieves the corresponding values and sets them to the delivery method and details.
	 *
	 * If the 'SMS' key is present, it retrieves the phone number and sets it as the delivery detail and 'S' as the delivery method.
	 * If the 'EMAIL' key is present, it retrieves the email address and sets it as the delivery detail and 'E' as the delivery method.
	 * If the 'LETTER' key is present, it retrieves the address details and sets them as the delivery detail and 'M' as the delivery method.
	 * If the 'AO' key is present, it retrieves the phone number and sets it as the delivery detail and 'A' as the delivery method.
	 *
	 * Finally, the method returns a HashMap that contains the delivery method and details.
	 *
	 * @param hmDeliveryMethods a HashMap that contains the delivery methods and details.
	 * @return a HashMap that contains the delivery method and details. The HashMap contains an application status code and an application info message.
	 */
	public HashMap getDeliveryMethodAndDetails(HashMap hmDeliveryMethods) {

		HashMap statusTMS = null;
		String appStatusCode = null;
		String appInfo = null;
		String stDeliveryDetail = null;
		String stDeliveryMethod = null;

		if (hmDeliveryMethods != null && !hmDeliveryMethods.isEmpty()) {

			if (hmDeliveryMethods.containsKey(CommonDefs.SMS)) {
				HashMap hmInputSMS = (HashMap) hmDeliveryMethods.get(CommonDefs.SMS);
				if (hmInputSMS != null && !hmInputSMS.isEmpty()) {
					stDeliveryMethod = "S";

					String stSMSPhoneNumber = (String) hmInputSMS.get(CommonDefs.SMS_PHONE_NUMBER);

					stDeliveryDetail = CommonUtilHelper.keepDigits(stSMSPhoneNumber);
				}
			}

			if (hmDeliveryMethods.containsKey(CommonDefs.EMAIL)) {

				HashMap hmEmail = (HashMap) hmDeliveryMethods.get(CommonDefs.EMAIL);

				if (hmEmail != null && !hmEmail.isEmpty()) {

					stDeliveryMethod = "E";

					String stEmailAddress = (String) hmEmail.get(CommonDefs.EMAIL_ADDRESS);

					if (stEmailAddress != null && stEmailAddress.trim().length() > 0) {

						stDeliveryDetail = stEmailAddress;

					}
				}
			}

			if (hmDeliveryMethods.containsKey(CommonDefs.LETTER)) {

				HashMap hmInputLetter = (HashMap) hmDeliveryMethods.get(CommonDefs.LETTER);

				ArrayList alInputPostalAdd = CommonUtil.getArrayList();

				if (hmInputLetter != null && !hmInputLetter.isEmpty()) {

					String sForeignAddInd = (String) hmInputLetter.get(CommonDefs.FOREIGN_ADDR_IND);
					String sStreet1 = (String) hmInputLetter.get(CommonDefs.STREET1);
					String sName = (String) hmInputLetter.get(CommonDefs.NAME);
					String sPostOffice = (String) hmInputLetter.get(CommonDefs.POST_OFFICE);
					// String sNbrAddressLines = (String)
					// hmInputLetter.get(CommonDefs.NBR_NON_ADDRESS_LINES);
					String sState = (String) hmInputLetter.get(CommonDefs.STATE);
					String sZipCode = (String) hmInputLetter.get(CommonDefs.ZIP_CODE);
					String sCity = (String) hmInputLetter.get(CommonDefs.CITY);
					String stStreet2 = (String) hmInputLetter.get(CommonDefs.STREET2);
					String stStreet3 = (String) hmInputLetter.get(CommonDefs.STREET3);
					String stZipPlusFour = (String) hmInputLetter.get(CommonDefs.ZIP_PLUS_FOUR);
					String stCountry = (String) hmInputLetter.get(CommonDefs.COUNTRY);

					if ((sForeignAddInd != null && sForeignAddInd.trim().length() > 0)
							&& (!sForeignAddInd.equalsIgnoreCase(RILDefs.YES)
									&& !sForeignAddInd.equalsIgnoreCase(RILDefs.NO))) {

						statusTMS = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM,
								"ForeignAddInd can have Values one of Y/N");
						return statusTMS;
					}

					if (sForeignAddInd == null || sForeignAddInd.isEmpty())
						sForeignAddInd = RILDefs.NO;

					hmInputLetter.put(CommonDefs.FOREIGN_ADDR_IND, sForeignAddInd);
					hmDeliveryMethods.put(CommonDefs.LETTER, hmInputLetter);
					hmInput.put(CommonDefs.DELIVERY_METHODS, hmDeliveryMethods);

					stDeliveryMethod = "M";

					alInputPostalAdd.add(sName);
					alInputPostalAdd.add(sStreet1);

					if (stStreet2 != null && stStreet2.trim().length() > 0)
						alInputPostalAdd.add(stStreet2);

					if (stStreet3 != null && stStreet3.trim().length() > 0)
						alInputPostalAdd.add(stStreet3);

					alInputPostalAdd.add(sPostOffice);
					alInputPostalAdd.add(sCity);
					alInputPostalAdd.add(sState);
					alInputPostalAdd.add(sZipCode);

					if (stZipPlusFour != null && stZipPlusFour.trim().length() > 0)
						alInputPostalAdd.add(stZipPlusFour);

					if (stCountry != null && stCountry.trim().length() > 0)
						alInputPostalAdd.add(stCountry);

					stDeliveryDetail = CommonUtilHelper.getDeliveryDetail(alInputPostalAdd);

				}
			}

			if (hmDeliveryMethods.containsKey(CommonDefs.AO)) {

				HashMap hmAo = (HashMap) hmDeliveryMethods.get(CommonDefs.AO);
				if (hmAo != null && !hmAo.isEmpty()) {

					stDeliveryMethod = "A";
					String stphoneNumber = (String) hmAo.get(CommonDefs.PHONE_NUMBER);
					if (stphoneNumber != null && stphoneNumber.trim().length() > 0) {
						stDeliveryDetail = stphoneNumber;

					}
				}
			}

		}
		statusTMS = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM, "");
		statusTMS.put(CommonDefs.DELIVERY_DETAIL, stDeliveryDetail);
		statusTMS.put(CommonDefs.DELIVERY_METHOD, stDeliveryMethod);
		return statusTMS;

	}


	/**
	 * This method is responsible for retrieving the OTP data source from the feature manager.
	 *
	 * It checks if the feature manager has a value for the key "cfg-idgraph-contactinfo-otpdatasource".
	 * If the value is found, it returns that value.
	 * If the value is not found (i.e., it is null), it sets a default value of "COSMOSMASTER" and logs an error message.
	 *
	 * @return a String representing the OTP data source.
	 */
	public String getOtpDataSource() {
		String otpDataSource = featureManager.getValue("cfg-idgraph-contactinfo-otpdatasource");
		if (otpDataSource == null) {
			otpDataSource = "COSMOSMASTER";
			logger.error("IXP Flag cfg-idgraph-contactinfo-otpdatasource is null, setting default value {} ", otpDataSource);
		}
		else if (!("ORACLEMASTER".equalsIgnoreCase(otpDataSource)
				|| "ONLYORACLE".equalsIgnoreCase(otpDataSource)
				|| "ONLYCOSMOS".equalsIgnoreCase(otpDataSource)
				|| "COSMOSMASTER".equalsIgnoreCase(otpDataSource))) {
			throw new IllegalArgumentException("Invalid OTP data source: " + otpDataSource);
		}
		return otpDataSource;
	}

	/**
	 * Builds the {@link EventData} payload for the OracleSecurityCodeSync INSERT/UPDATE event.
	 *
	 * @param sInpIdentificationType identification type for the OTP record
	 * @param sInpAccountId account identifier for the OTP record
	 * @param formattedExpiryDate expiry timestamp string
	 * @param sInpCallingSystemId calling system identifier
	 * @param securityCode generated security code entity
	 * @return populated {@link EventData}
	 */
	private EventData buildEventData(String sInpIdentificationType, String sInpAccountId, String formattedExpiryDate,
									 String sInpCallingSystemId, SecurityCode securityCode) {
		EventData eventData = new EventData();
		eventData.setAccountId(sInpAccountId);
		eventData.setIdentificationType(sInpIdentificationType);
		eventData.setSecurityAccountEvent(buildSecurityAccountEvent(formattedExpiryDate, sInpCallingSystemId));
		eventData.setSecurityCodeEvent(buildSecurityCodeEvent(sInpCallingSystemId, securityCode));
		return eventData;
	}

	/**
	 * Builds the security-account portion of the event payload for Oracle sync.
	 *
	 * @param formattedExpiryDate expiry timestamp string
	 * @param sInpCallingSystemId calling system identifier used for updated-by
	 * @return populated {@link SecurityAccountEvent}
	 */
	private SecurityAccountEvent buildSecurityAccountEvent(String formattedExpiryDate, String sInpCallingSystemId) {
		SecurityAccountEvent accountEvent = new SecurityAccountEvent();
		accountEvent.setAccountEntryExpires(Instant.parse(formattedExpiryDate));
		accountEvent.setCumulativeFailureCount("0");
		accountEvent.setCreatedDate(Instant.now());
		accountEvent.setUpdatedDate(Instant.now());
		accountEvent.setUpdatedBy(sInpCallingSystemId);
		return accountEvent;
	}

	/**
	 * Builds the security-code portion of the event payload for Oracle sync.
	 *
	 * @param sInpCallingSystemId calling system identifier used for updated-by
	 * @param securityCode generated security code entity
	 * @return populated {@link SecurityCodeEvent}
	 */
	private SecurityCodeEvent buildSecurityCodeEvent(String sInpCallingSystemId, SecurityCode securityCode) {
		SecurityCodeEvent codeEvent = new SecurityCodeEvent();
		codeEvent.setCreatedDate(securityCode.getCreatedDate().atZone(ZoneId.of("UTC")).toInstant());
		codeEvent.setUpdatedDate(securityCode.getUpdatedDate().atZone(ZoneId.of("UTC")).toInstant());
		codeEvent.setSecurityCode(securityCode.getSecurityCode());
		codeEvent.setSecurityCodeExpires(Instant.parse(securityCode.getSecurityCodeExpires()));
		codeEvent.setSource(securityCode.getSource());
		codeEvent.setUpdatedBy(sInpCallingSystemId);
		codeEvent.setVerificationFailureCount(String.valueOf(securityCode.getVerificationFailureCount()));
		codeEvent.setDeliveryDetail(securityCode.getDeliveryDetail());
		codeEvent.setDeliveryMethod(securityCode.getDeliveryMethod());
		return codeEvent;
	}

	public Map<String, Object> generateOTPWithLockoutCheck() {
		String sMethodName = ".generateOTPWithLockoutCheck.";
		String sInpIdentificationType = (String) hmInput.get(CommonDefs.IDENTIFICATION_TYPE);
		String sInpAccountId = (String) hmInput.get(CommonDefs.ACCOUNT_ID);
		IdgOtpContainer otpContainer ;
		Instant unlockAccountTime=null;
		String otpDataSource = getOtpDataSource();
		try {
			otpContainer = new IdgOtpContainer();
			otpContainer.setAccountId(sInpAccountId);
			otpContainer.setIdentificationType(sInpIdentificationType);

		HashMap<String, String> otpUnlockMinutesMap = validatePINHelper.parseOtpUnlockAccountMinutes();
		if (otpUnlockMinutesMap.containsKey(sInpIdentificationType)
				&& ("ONLYCOSMOS".equalsIgnoreCase(otpDataSource) || "COSMOSMASTER".equalsIgnoreCase(otpDataSource))) {
			unlockAccountTime = getUnlockTime(otpContainer);
			if (unlockAccountTime != null) {
					Instant now = Instant.now();
					if (unlockAccountTime.isAfter(now)) {
						String appInfo = "Auth method is locked for OTP generation";
						logger.info("{}{}LOCKOUT_OTP: Account is locked for IdentificationType: {}, AccountId: {}", sClassName,
								sMethodName, ESAPI.encoder().encodeForHTML(sInpIdentificationType), ESAPI.encoder().encodeForHTML(sInpAccountId));
						return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ACCOUNT_LOCKOUT_NUM, appInfo);
					}

			}
		}
		} catch (Exception ex) {
			logger.warn("{}{}LOCKOUT_OTP: Failed to parse unlockAccountTime : {}", sClassName, sMethodName,
					ESAPI.encoder().encodeForHTML(ex.getMessage()));
			return CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "Failed to parse unlock account time");
		}
		// else BAU to generate next OTP
		return processInputData();
	}

	private void saveOtpHistoryAsync(IdgOtpContainer savedContainer, Operation operation, String callingSystemId) {
		CompletableFuture.runAsync(() -> {
			try {
				IdgOtpContainerHistory history = IdgOtpContainerHistory.builder()
						.id(UUID.randomUUID().toString())
						.accountId(savedContainer.getAccountId())
						.identificationType(savedContainer.getIdentificationType())
						.accountType(savedContainer.getAccountType())
						.cumulativeFailureCount(savedContainer.getCumulativeFailureCount())
						.accountEntryExpires(savedContainer.getAccountEntryExpires())
						.securityCodes(savedContainer.getSecurityCodes())
						.unlockAccountTime(savedContainer.getUnlockAccountTime())
						.createdDate(savedContainer.getCreatedDate())
						.updatedDate(savedContainer.getUpdatedDate())
						.updatedBy(callingSystemId)
						.historyMetadata(HistoryMetadata.builder()
								.operation(operation)
								.source(OTP_HISTORY_SOURCE)
								.timestamp(com.att.idp.idgraph.db.cosmos.util.DateUtil.getUTCNow())
								.build())
						.build();
				otpHistoryDBHelper.saveOtpHistory(history);
			} catch (Exception e) {
				logger.error("Failed to save OTP history asynchronously for accountId: {}: {}",
						savedContainer.getAccountId(), StringEscapeUtils.escapeJava(e.getMessage()), e);
			}
		}, otpHistoryExecutor);
	}

	public Instant getUnlockTime(IdgOtpContainer otpContainer){
		try {
			Optional<IdgOtpContainer> idgOtpContainer = idgOtpDBHelper.findByIdentificationTypeAndAccountId(otpContainer);
			if (idgOtpContainer.isPresent()) {
				String unlockTimeStr = idgOtpContainer.get().getUnlockAccountTime();
				if (unlockTimeStr != null && !unlockTimeStr.isEmpty()) {
					return Instant.parse(unlockTimeStr);
				}
			}
		}catch (Exception e) {
			logger.error("{}{}GET_UNLOCK_TIME: Exception while retrieving unlock time: {}", sClassName,
					"getUnlockTime", ESAPI.encoder().encodeForHTML(e.getMessage()));
			throw e;
		}
		return null;
	}

}
