package com.att.idp.idgraphcontactinfoms.helpers;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphcontactinfoms.utils.CommonUtilHelper;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.mpsys.common.utils.MPSDefs;

/**
 * The CPNIDataAddressHelper class is a Spring component that provides methods for validating CPNI addresses.
 *
 * It uses several properties from a properties file located at "file:opt/ajsc/etc/config/contactInfo.properties".
 * These properties include "BYPASS_CPNI_ELIGIBILITY_CSI" and "SIM_SWAP_AGING_DAYS".
 *
 * The class contains a method named validateCPNIAddress which takes a HashMap as input and returns a HashMap as output.
 * This method performs various checks and validations on the input data and constructs a response HashMap.
 *
 * The class uses the SLF4J Logger for logging.
 */
@Component
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class CPNIDataAddressHelper {

	private String sThisClass = "CPNIDataAddressHelper";
	public static final Logger log = LoggerFactory.getLogger(CPNIDataAddressHelper.class);

	@Value("${BYPASS_CPNI_ELIGIBILITY_CSI}")
	private String sBypassCallingSystemIds;

	@Value("${SIM_SWAP_AGING_DAYS}")
	private String sSimSwapAgingDays;

	/**
	 * This method is used to validate CPNI addresses.
	 *
	 * It takes a HashMap as input which contains various keys related to CPNI address validation.
	 * The method performs various checks and validations on the input data and constructs a response HashMap.
	 * The response HashMap contains the result of the validation process.
	 *
	 * @param hmInput A HashMap containing the input data for CPNI address validation.
	 * @return A HashMap containing the result of the CPNI address validation.
	 */
	public HashMap validateCPNIAddress(HashMap hmInput) {

		String sThisMethod = ".validateCPNIAddress.";

		String sAppInfo = null;
		HashMap<String, Object> hmResponse = CommonUtil.getHashMap();

		ArrayList alValidCPNIAddress = new ArrayList();
		ArrayList alEligibleCPNIAddress = new ArrayList();

		String sContactEstDate = null;
		String sAccountCreateDate = null;
		String sContactStatus = null;
		String sEmail = null;
		String sPhone = null;
		String sContactType = null;
		String sSimSwapDate = null;

		boolean bCPNINotEligible = false;

		log.info("{}{}HLP000 : Input Hash : {}", sThisClass, sThisMethod, hmInput);

		try {

			if (hmInput == null || hmInput.isEmpty()) {
				sAppInfo = " Input Hash is NULL / EMPTY ";
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				log.info("{}{}CPNIDAH_01 : {}", sThisClass, sThisMethod, sAppInfo);
				return hmResponse;
			}

			String sNewCPNIEilibilityRule = (String) hmInput.get("NewCPNIEilibilityRule");
			alValidCPNIAddress = (ArrayList) hmInput.get(CommonDefs.CONTACT_INFO);
			String sActivatedInd = (String) hmInput.get(CommonDefs.ACTIVATED_IND);
			String sCallingSystemId = (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID);

			ArrayList alPostAddress = (ArrayList) hmInput.get(CommonDefs.POSTAL_ADDRESS);
			if (alPostAddress != null && !alPostAddress.isEmpty()) {
				alValidCPNIAddress = new ArrayList();
				alValidCPNIAddress.addAll(alPostAddress);
			}

			if (alValidCPNIAddress != null & !alValidCPNIAddress.isEmpty()) {

				Iterator itValidCPNIAddress = alValidCPNIAddress.iterator();

				Date today = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
				DateFormat df = new SimpleDateFormat("MMddyyyy");
				SimpleDateFormat cstDateFormat = new SimpleDateFormat("MMddyyyy");

				while (itValidCPNIAddress.hasNext()) {

					bCPNINotEligible = false;

					HashMap<String, Object> hmValidCPNIAddress = (HashMap<String, Object>) itValidCPNIAddress.next();
					if (hmValidCPNIAddress != null && !hmValidCPNIAddress.isEmpty()) {

						sContactType = (String) hmValidCPNIAddress.get(MPSDefs.DB_CONTACT_TYPE);

						// override top value if this flag is present in lower level contact hash
						if (hmValidCPNIAddress.get("NewCPNIEilibilityRule") != null)
							sNewCPNIEilibilityRule = (String) hmValidCPNIAddress.get("NewCPNIEilibilityRule");

						if (sContactType == null || sContactType.isEmpty()) {
							sContactEstDate = (String) hmValidCPNIAddress.get(CommonDefs.KEY_ADDRESS_ESTABLISHED_DATE);
							sAccountCreateDate = (String) hmValidCPNIAddress
									.get(CommonDefs.KEY_ACCOUNT_ESTABLISHED_DATE);
						} else {
							if (sContactType != null && !sContactType.isEmpty()
									&& (sContactType.equals(CommonDefs.CONTACT_TYPE_PRIMARY_PHONE)
											|| sContactType.equals(CommonDefs.CC_MULE_SMS)
											|| sContactType.equals(CommonDefs.CONTACT_TYPE_SECONDARY_PHONE))) {
								sContactEstDate = (String) hmValidCPNIAddress.get(CommonDefs.KEY_PHONE_EST_DATE);
								sPhone = (String) hmValidCPNIAddress.get(CommonDefs.KEY_PHONE);
								sAccountCreateDate = (String) hmValidCPNIAddress
										.get(CommonDefs.KEY_ACCOUNT_CREATE_DATE);
								sSimSwapDate = (String) hmValidCPNIAddress.get(CommonDefs.SIM_SWAP_DATE);
							} else if (sContactType != null && !sContactType.isEmpty()
									&& sContactType.equals(CommonDefs.CONTACT_TYPE_PRIMARY_EMAIL)) {
								sContactEstDate = (String) hmValidCPNIAddress.get(CommonDefs.KEY_EMAIL_EST_DATE);
								sEmail = (String) hmValidCPNIAddress.get(MPSDefs.DB_EMAIL_ADDRESS);
								sAccountCreateDate = (String) hmValidCPNIAddress
										.get(CommonDefs.KEY_ACCOUNT_CREATE_DATE);
							}
						}

						log.info("{}{}CPNIDAH_02 : Contact Established Date:: {}", sThisClass, sThisMethod,
								sContactEstDate);
						log.info("{}{}CPNIDAH_03 : Account Create Date:: {}", sThisClass, sThisMethod,
								sAccountCreateDate);

						String sCPNIEligileEmail = (String) hmValidCPNIAddress.get(CommonDefs.CPNI_ELIGIBLE_EMAIL_FLAG);

						Date dParsedContactEstDate = null;
						Date dAccountCreateDate = null;

						/*
						 * Update code to support CPNIEligibleEmail flag, if this is present and it is Y
						 * then no validation checks are performed. for rest cases all the validation
						 * checks are performed.
						 */
						if ((sCPNIEligileEmail == null || sCPNIEligileEmail.trim().length() == 0)
								|| (sCPNIEligileEmail != null && sCPNIEligileEmail.trim().length() > 0
										&& !sCPNIEligileEmail.equals(MPSDefs.YES))) {

							// 1308 Ignore 30 day CPNI eligibility check for email if slid's activated_ind
							// is N
							if (sContactType != null && sContactType.equals(CommonDefs.CONTACT_TYPE_PRIMARY_EMAIL)
									&& sActivatedInd != null && sActivatedInd.equalsIgnoreCase(CommonDefs.IND_N)) {
								log.info(
										"{}{}CPNIDAH_04 : Slid's activated_ind is N, ignoring CPNI eligibility check for email.",
										sThisClass, sThisMethod);

							} else if ((sContactEstDate != null && sContactEstDate.trim().length() > 0)) {
								log.debug("{}{}CPNIDAH_05 : Date on Server {}", sThisClass, sThisMethod, today);

								TimeZone cst = TimeZone.getTimeZone("CST");
								sdf.setTimeZone(cst);
								String sCSTDate = sdf.format(today);

								Date cstDate = cstDateFormat.parse(sCSTDate);
								log.debug("{}{}CPNIDAH_06 : Date on after conversion to CST {}", sThisClass,
										sThisMethod, cstDate);

								long currentTime = cstDate.getTime();

								dParsedContactEstDate = df.parse(sContactEstDate);

								if (sAccountCreateDate != null && sAccountCreateDate.trim().length() > 0) {
									dAccountCreateDate = df.parse(sAccountCreateDate);
								}

								long lContactEstTime = dParsedContactEstDate.getTime();
								long diff = currentTime - lContactEstTime;

								if (diff >= 0) {
									int days = (int) (diff / 86400000);
									log.debug("{}{}CPNIDAH_07 : Days after Email Established: {}", sThisClass,
											sThisMethod, days);
									if (days < 30) {

										// 1512: SID42035 Bypass 30 day aging check for config CSI
										boolean bBypassCPNIEligCheck = false;

										log.info("{}{}CPNIDAH_07a : BYPASS_CPNI_ELIGIBILITY_CSI : {}", sThisClass,
												sThisMethod, sBypassCallingSystemIds);
										ArrayList alBypassCallingSystemIds = CommonUtil
												.parseToArray(sBypassCallingSystemIds, CommonDefs.VALUE_SEPARATOR_CHAR);

										log.debug("{}{}CPNIDAH_08 : BypassCallingSystemIds List: {} Input CSI: {}",
												sThisClass, sThisMethod, alBypassCallingSystemIds,
												HtmlUtils.htmlEscape(String.valueOf(sCallingSystemId)));
										if (sCallingSystemId != null && alBypassCallingSystemIds != null
												&& alBypassCallingSystemIds.contains(sCallingSystemId)) {
											bBypassCPNIEligCheck = true;
										}

										if (!bBypassCPNIEligCheck && ((sAccountCreateDate == null
												|| sAccountCreateDate.trim().length() == 0)
												|| (!dParsedContactEstDate.equals(dAccountCreateDate)))) {
											// Updated for CR 72036. If emailEstablisedDate is less than 30 days and
											// emailEstablisedDate is not same as accountEstablisedDate
											// Then if emailEstablisedDate is before the AccountEstablishedDate then
											// consider it as CPNIEligible

											// Fix for TT #157349580: Account Create Date is returned as Null from BDS
											// in that case Added Null check for Date
											if (sNewCPNIEilibilityRule != null && !sNewCPNIEilibilityRule.isEmpty()
													&& sNewCPNIEilibilityRule.equals(MPSDefs.YES)
													&& dAccountCreateDate != null) {
												if (dParsedContactEstDate.after(dAccountCreateDate)) {
													bCPNINotEligible = true;
												}
											} else {
												if (dAccountCreateDate == null && sNewCPNIEilibilityRule != null
														&& !sNewCPNIEilibilityRule.isEmpty()
														&& sNewCPNIEilibilityRule.equals(MPSDefs.YES)) {
													log.info(
															"{}{}CPNIDAH_09 : Account Create Date is returned as null for TITAN/UVERSE Account, So Considering it as CPNI Eligible",
															sThisClass, sThisMethod);
												} else {
													if (dAccountCreateDate == null) {
														log.info(
																"{}{}CPNIDAH_10 : Account Create Date is returned as null, So Considering it as CPNI Not Eligible",
																sThisClass, sThisMethod);
													}
													bCPNINotEligible = true;
												}

											}

										}
									}

								} else {

									bCPNINotEligible = true;
								}
							} else {
								bCPNINotEligible = true;
							}

							if (sContactType != null && !sContactType.isEmpty()
									&& (sContactType.equals(CommonDefs.CONTACT_TYPE_PRIMARY_PHONE)
											|| sContactType.equals(CommonDefs.CONTACT_TYPE_PRIMARY_EMAIL))) {
								sContactStatus = (String) hmValidCPNIAddress.get(MPSDefs.DB_CONTACT_STATUS);

								// 1308 Defect#4086, if contact_status is null, treat it as CPNI not eligible
								if (!bCPNINotEligible && (sContactStatus == null || (sContactStatus != null
										&& !sContactStatus.trim().equals(CommonDefs.PROOFING_STATUS_VALID)))) {
									bCPNINotEligible = true;
								}
							}

							// 1510 US434068: Check for SIM SWAP Date
							if (sContactType != null && sSimSwapDate != null && !sSimSwapDate.isEmpty()
									&& (sContactType.equals(CommonDefs.CONTACT_TYPE_PRIMARY_PHONE)
											|| sContactType.equals(CommonDefs.CONTACT_TYPE_SECONDARY_PHONE)
											|| sContactType.equals(CommonDefs.CC_MULE_SMS))) {
								log.info("{}{}CPNIDAH_11a : SIM_SWAP_AGING_DAYS : {}", sThisClass, sThisMethod,
										sSimSwapAgingDays);

								if (sSimSwapAgingDays == null || sSimSwapAgingDays.isEmpty()) {
									log.info("{}{}CPNIDAH_11 : Config SIM_SWAP_AGING_DAYS is missing", sThisClass,
											sThisMethod);
									hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_CONFIG_NUM,
											"Config SIM_SWAP_AGING_DAYS is missing");
									return hmResponse;
								}
								String dateTimeFormat = "MMddyyyy HH:mm:ss";
								boolean sCTNAged = CommonUtilHelper.checkAging(sSimSwapDate, sSimSwapAgingDays, dateTimeFormat);
								if (!bCPNINotEligible && !sCTNAged) {
									bCPNINotEligible = true;
									log.info("{}{}CPNIDAH_12 : SIM is not aged: {}", sThisClass, sThisMethod,
											sSimSwapDate);
								}
							}

						} else {
							if (sContactType != null && !sContactType.isEmpty()
									&& sContactType.equals(CommonDefs.CONTACT_TYPE_PRIMARY_PHONE)) {
								log.debug("{}{}CPNIDAH_13 : No Validation Required for Phone::{}", sThisClass,
										sThisMethod, sPhone);
							}
							if (sContactType != null && !sContactType.isEmpty()
									&& sContactType.equals(CommonDefs.CONTACT_TYPE_PRIMARY_EMAIL)) {
								log.debug("{}{}CPNIDAH_14 : No Validation Required for Email::{}", sThisClass,
										sThisMethod, sEmail);
							}

						}

						if (!bCPNINotEligible) {
							alEligibleCPNIAddress.add(hmValidCPNIAddress);
						}
					}

				}

			}

			hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, "");
			if (alEligibleCPNIAddress != null && !alEligibleCPNIAddress.isEmpty()) {
				hmResponse.put(CommonDefs.VALID_CPNI_ADDRESSES, alEligibleCPNIAddress);
			}

		} catch (Exception e) {
			hmResponse = CommonErrorMap.makeExceptionMap(e, log);

		} finally {
			if (hmResponse == null || hmResponse.isEmpty()) {
				sAppInfo = " Result Hash is NULL ";
				hmResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, sAppInfo);
				log.info("{}{}CPNIDAH_15 : {}", sThisClass, sThisMethod, sAppInfo);
			}

			log.info("{}{}HLP999 : response from CPNIDataAddressHelper : {}", sThisClass, sThisMethod, hmResponse);
		}

		return hmResponse;
	}

}
