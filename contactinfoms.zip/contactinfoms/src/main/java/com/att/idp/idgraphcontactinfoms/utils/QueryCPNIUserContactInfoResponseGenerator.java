package com.att.idp.idgraphcontactinfoms.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.idp.core.exception.ServiceException;
import com.att.idp.idgraphcontactinfoms.message.ErrorMessages;
import com.att.idp.idgraphcontactinfoms.resource.response.AccountCBRList;
import com.att.idp.idgraphcontactinfoms.resource.response.AccountContactList;
import com.att.idp.idgraphcontactinfoms.resource.response.CBRUSPhoneNumber;
import com.att.idp.idgraphcontactinfoms.resource.response.QueryCPNIAccountContactInfoResponse;
import com.att.idp.idgraphcontactinfoms.resource.response.QueryCPNIUserContactInfoResponse;
import com.att.idp.idgraphcontactinfoms.resource.response.USPhoneNumber;
import com.att.idp.idgraphcontactinfoms.resource.response.UserContactList;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.MPSDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.utils package.
 *
 * The QueryCPNIUserContactInfoResponseGenerator class is a component that generates responses for the QueryCPNIUserContactInfo operation.
 * It contains methods to generate both success and error responses based on the input parameters.
 *
 * The class uses the Logger class from the SLF4J library for logging.
 * It also uses various classes from the com.att.idp.idgraphcontactinfoms.resource.response package to construct the response objects.
 *
 * This class is annotated with the @Component annotation, which means it is a Spring component.
 * Spring will automatically create an instance of this class and manage its lifecycle.
 * Other classes can use the @Autowired annotation to have Spring automatically inject an instance of this class where needed.
 *
 * This class is useful when you need to generate a response for the QueryCPNIUserContactInfo operation.
 * It provides a centralized place to handle the creation of these responses, which can help ensure consistency across your application.
 */
@Component
public class QueryCPNIUserContactInfoResponseGenerator {

	private static Object sClassName="QueryCPNIUserContactInfoResponseGenerator";
	public static final Logger logger = LoggerFactory.getLogger(QueryCPNIUserContactInfoResponseGenerator.class);
	
	/**
	 * This method is part of the QueryCPNIUserContactInfoResponseGenerator class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The queryCPNIUserContactInfoErrorResponse method is used to generate an error response for the QueryCPNIUserContactInfo operation.
	 * It takes an application status code, application info, error message, and IDP trace ID as input.
	 *
	 * The method first creates a category map based on the application status code and application info using the makeCategoryMap method of the CommonErrorMap class.
	 * It then creates a new QueryCPNIUserContactInfoResponse object and sets its properties based on the values in the category map and the input parameters.
	 * The method also creates a new ServiceException object based on the error message and application info and sets the errors property of the response object to the error of the ServiceException.
	 *
	 * The method returns the created QueryCPNIUserContactInfoResponse object.
	 *
	 * This method is useful when you need to generate an error response for the QueryCPNIUserContactInfo operation.
	 *
	 * @param appStatusCode The application status code to be included in the response.
	 * @param appInfo The application info to be included in the response.
	 * @param errorMessage The error message to be included in the response.
	 * @param stIdpTraceId The IDP trace ID to be included in the response.
	 * @return A QueryCPNIUserContactInfoResponse object representing the error response.
	 */
	public static QueryCPNIUserContactInfoResponse queryCPNIUserContactInfoErrorResponse(int appStatusCode,
			String appInfo, ErrorMessages errorMessage, String stIdpTraceId) {

		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, appInfo);

		QueryCPNIUserContactInfoResponse response = new QueryCPNIUserContactInfoResponse();
		response.setAppStatusCode((String) hmResult.get("appStatusCode"));
		response.setAppStatusMsg((String) hmResult.get("appStatusMsg"));
		response.setAppInfo((String) hmResult.get("appInfo"));
		response.setAppCategoryCode((String) hmResult.get("appCategoryCode"));
		response.setErrors(new ServiceException(errorMessage, appInfo).getError());
		response.setIdpTraceId(stIdpTraceId);
		return response;
	}

	/**
	 * This method is part of the QueryCPNIUserContactInfoResponseGenerator class in the com.att.idp.idgraphcontactinfoms.utils package.
	 *
	 * The getQueryCPNIUserContactInfoResponse method is used to generate a response for the QueryCPNIUserContactInfo operation based on the input response map.
	 * It takes a map of response data as input.
	 *
	 * The method first retrieves the application status code, application info, and IDP trace ID from the response map.
	 * If the application status code indicates success, it calls the queryCPNIUserContactInfoSuccessResponse method to generate a success response.
	 * If the application status code indicates an error, it retrieves the corresponding error message and calls the queryCPNIUserContactInfoErrorResponse method to generate an error response.
	 *
	 * The method returns the created QueryCPNIUserContactInfoResponse object.
	 *
	 * This method is useful when you need to generate a response for the QueryCPNIUserContactInfo operation based on a map of response data.
	 *
	 * @param hmResponse The map of response data.
	 * @return A QueryCPNIUserContactInfoResponse object representing the response.
	 */
	public static QueryCPNIUserContactInfoResponse getQueryCPNIUserContactInfoResponse(Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId = (String) hmResponse.get("idp-trace-id");
		String stAppStatusCode = (String) hmResponse.getOrDefault(MPSDefs.APP_STATUS_CODE, null);
		int appStatusCode = Integer.parseInt(stAppStatusCode);
		if (CommonDefs.COMMON_SUCCESS.equals(stAppStatusCode)) {
			return queryCPNIUserContactInfoSuccessResponse(appStatusCode, hmResponse);
		} else {
			ErrorMessages errMsg = (ErrorMessages) ErrorMessages.valueOf("MS_MPSYS_BE_" + appStatusCode);
			return queryCPNIUserContactInfoErrorResponse(appStatusCode, stAppInfo, errMsg, stIdpTraceId);

		}
	}

	private static QueryCPNIUserContactInfoResponse queryCPNIUserContactInfoSuccessResponse(
			int appStatusCode, Map<String, Object> hmResponse) {
		String stAppInfo = (String) hmResponse.get(CommonDefs.COMMON_APP_INFO);
		String stIdpTraceId=(String) hmResponse.get("idp-trace-id");
		String sMethodName=".queryCPNIUSerContactInfoSuccessResponse.";
		
		HashMap hmResult = CommonErrorMap.makeCategoryMap(appStatusCode, stAppInfo);

		QueryCPNIUserContactInfoResponse queryCPNIUserContactInfoResponse = new QueryCPNIUserContactInfoResponse();
		queryCPNIUserContactInfoResponse.setAppStatusCode((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_CODE));
		queryCPNIUserContactInfoResponse.setAppStatusMsg((String) hmResult.get(CommonDefs.COMMON_APP_STATUS_MSG));
		queryCPNIUserContactInfoResponse.setAppInfo((String) hmResult.get(CommonDefs.COMMON_APP_INFO));
		queryCPNIUserContactInfoResponse.setAppCategoryCode((String) hmResult.get(CommonDefs.COMMON_APP_CATEGORY_CODE));
		queryCPNIUserContactInfoResponse.setIdpTraceId(stIdpTraceId);
		
		try {
			if (hmResponse.get("accountContactList") != null) {
				ArrayList<AccountContactList> alAccountContactList  = CommonUtilHelper.cpniListDetails(hmResponse,(ArrayList<HashMap<String, Object>>) hmResponse
						.get("accountContactList"));				
				queryCPNIUserContactInfoResponse.setAccountContactList(alAccountContactList);
			}
			
			if (hmResponse.get("userContactList") != null) {
				ArrayList userCPNIContactListAl = new ArrayList<UserContactList>();
				userCPNIContactListAl = CommonUtilHelper.cpniListDetails(hmResponse, (ArrayList<HashMap<String, Object>>) hmResponse
						.get("userContactList"));
				queryCPNIUserContactInfoResponse.setUserContactList(userCPNIContactListAl);
			}
			if (hmResponse.get("accountCBRList") != null) {

				ArrayList accountCBRList = new ArrayList<>();
				ArrayList<HashMap<String, Object>> accountCBRListAl = (ArrayList<HashMap<String, Object>>) hmResponse.get("accountCBRList");
				for (HashMap hmAccountCBRList : accountCBRListAl) {
					HashMap hmAccountCBRContact = new HashMap<>();
					if (hmAccountCBRList.containsKey("USPhoneNumber")) {
						HashMap hmAccountCBRContactList = (HashMap) hmAccountCBRList.get("USPhoneNumber");
						CBRUSPhoneNumber uSPhoneNumber = (CBRUSPhoneNumber) CommonUtilHelper.populateFields(hmResponse,
								CBRUSPhoneNumber.class, (HashMap) hmAccountCBRContactList);
						hmAccountCBRContact.put("USPhoneNumber", uSPhoneNumber);
						hmAccountCBRContact.put(CommonDefs.ACCOUNT_INVARIANT_ID, hmAccountCBRList.get(CommonDefs.ACCOUNT_INVARIANT_ID));
						hmAccountCBRContact.put(CommonDefs.ACCOUNT_TYPE, hmAccountCBRList.get(CommonDefs.ACCOUNT_TYPE));
						accountCBRList.add(hmAccountCBRContact);
					}

				}
				queryCPNIUserContactInfoResponse.setAccountCBRList(accountCBRList);
			}
			if (hmResponse.get("userCBRList") != null) {
				HashMap hmUserCBRContact = new HashMap<>();
				ArrayList userCBRList = new ArrayList<>();
				ArrayList<HashMap<String, Object>> userCBRListAl =
						(ArrayList<HashMap<String, Object>>) hmResponse.get("userCBRList");
				for (HashMap hmUserCBRList : userCBRListAl) {
					if (hmUserCBRList.containsKey("USPhoneNumber")) {
						HashMap hmUserCBRContactList = (HashMap) hmUserCBRList.get("USPhoneNumber");
						CBRUSPhoneNumber uSPhoneNumber = (CBRUSPhoneNumber) CommonUtilHelper.populateFields(hmResponse,
								CBRUSPhoneNumber.class, (HashMap) hmUserCBRContactList);
						hmUserCBRContact.put("USPhoneNumber", uSPhoneNumber);
					}
					hmUserCBRContact.put(CommonDefs.GUID, hmUserCBRList.get(CommonDefs.GUID));
					hmUserCBRContact.put(CommonDefs.HANDLE, hmUserCBRList.get(CommonDefs.HANDLE));
					hmUserCBRContact.put(CommonDefs.DOMAIN, hmUserCBRList.get(CommonDefs.DOMAIN));
					
				}
				userCBRList.add(hmUserCBRContact);
				queryCPNIUserContactInfoResponse.setUserCBRList(userCBRList);
			}
			
		}
		catch (Exception e) {
			stAppInfo="Exception thrown in QueryCPNIAccountContactInfoResponseHelper : " + e.getMessage();
			logger.error("{}{}CPNIURG01 :  Error::{}", sClassName, sMethodName,e.getMessage());
			logger.error("{}{}CPNIURG02 : Exception = {}", sClassName, sMethodName, e);			
			queryCPNIUserContactInfoResponse= queryCPNIUserContactInfoErrorResponse(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo,
					ErrorMessages.valueOf("MS_MPSYS_BE_"+appStatusCode), stIdpTraceId);
		}
		return queryCPNIUserContactInfoResponse;
	}
}
