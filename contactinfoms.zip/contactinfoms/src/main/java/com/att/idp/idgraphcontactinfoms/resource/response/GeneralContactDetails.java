package com.att.idp.idgraphcontactinfoms.resource.response;

import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.response package.
 *
 * The GeneralContactDetails class is used to represent general contact details associated with an account.
 * It contains four fields: contactStatus, contactType, cpniEligible, and establishedDate.
 *
 * The contactStatus field is a string that represents the status of the contact.
 * The contactType field is a string that represents the type of the contact.
 * The cpniEligible field is a string that represents whether the contact is eligible for CPNI (Customer Proprietary Network Information).
 * The establishedDate field is a string that represents the date when the contact was established.
 *
 * Each field has a corresponding getter and setter method, allowing the fields to be accessed and modified.
 *
 * The class overrides the toString method, providing a custom string representation of the object.
 */
@Data
public class GeneralContactDetails {

	private String contactStatus;
	private String contactType;
	private String cpniEligible;
	private String establishedDate;
}