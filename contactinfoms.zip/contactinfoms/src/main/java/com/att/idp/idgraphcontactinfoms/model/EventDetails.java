package com.att.idp.idgraphcontactinfoms.model;

import com.att.idp.idgraph.events.model.JsonSealizable;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class EventDetails implements JsonSealizable {
    private String type;
    private EventData data;
}
