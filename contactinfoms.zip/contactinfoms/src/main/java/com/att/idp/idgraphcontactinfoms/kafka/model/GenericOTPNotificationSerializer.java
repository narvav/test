package com.att.idp.idgraphcontactinfoms.kafka.model;

import org.springframework.kafka.support.serializer.JsonSerializer;

/**
 * This class, GenericOTPNotificationSerializer, is a custom serializer for the GenericOTPNotification class.
 *
 * It extends the JsonSerializer class from the Spring Kafka library, which provides functionality for serializing Java objects to JSON format.
 *
 * The JsonSerializer class uses the Jackson ObjectMapper for serialization, which can be configured to control how objects are converted to JSON.
 *
 * In this case, the GenericOTPNotificationSerializer class is a simple subclass that does not override any methods or add any additional functionality. It simply specifies that the JsonSerializer should be used to serialize objects of the GenericOTPNotification class.
 */
public class GenericOTPNotificationSerializer extends JsonSerializer<GenericOTPNotification>{

}
