package com.att.idp.idgraphcontactinfoms.resource.request;

import static org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString;
import static org.apache.commons.lang3.builder.ToStringStyle.JSON_STYLE;

import java.io.Serializable;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.request package.
 *
 * The Email class implements the Serializable interface, allowing instances of this class to be converted into a byte stream.
 *
 * The class is used to represent an Email object, which contains a single field, emailAddress.
 * The emailAddress field is annotated with @NotNull and @Size, indicating that it is a required field and has size constraints.
 * The messages associated with these annotations provide additional information about the requirements for the emailAddress field.
 *
 * The class provides a no-argument constructor, as well as a getter and setter method for the emailAddress field.
 * It also overrides the toString method, providing a custom string representation of the object using reflection.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Email implements Serializable{

	@NotNull(message="emailAddress is required field in input request.|GeneratePIN")
	@Size(min=1, max=255,message="emailAddress length is invalid|GeneratePIN")
	protected String emailAddress;

	@Override
	public String toString() {
		return reflectionToString(this, JSON_STYLE);
	}
}