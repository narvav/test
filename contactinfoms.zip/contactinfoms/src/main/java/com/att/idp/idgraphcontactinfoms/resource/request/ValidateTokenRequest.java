package com.att.idp.idgraphcontactinfoms.resource.request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.request package.
 *
 * The ValidateTokenRequest class is used to represent a request to validate a token.
 * It contains several fields, each of which represents a parameter of the request.
 * These fields include transactionName, callingSystemId, identificationType, token, agentId, sourceIPAddress, and deletePINOnSuccess.
 *
 * Each field is annotated with @NotNull and/or @Size, indicating that they are required fields and have size constraints.
 * The messages associated with these annotations provide additional information about the requirements for each field.
 *
 * The class provides getter and setter methods for each field, allowing the fields to be accessed and modified.
 * It also overrides the toString method, providing a custom string representation of the object using reflection.
 */
@Data
public class ValidateTokenRequest {

	@NotNull(message="TransactionName is required field in input request.|ValidateTOKEN")
	protected String transactionName;

	@NotNull(message="CallingSystemId is required field in input request.|ValidateTOKEN")
	@Size(min=1, max=20,message="CallingSystemId length is invalid|ValidateTOKEN")
	protected String callingSystemId;

	@NotNull(message="IdentificationType is required field in input request.|ValidateTOKEN")
	@Size(min=1,max=10,message="IdentificationType length is invalid.|ValidateTOKEN")
	protected String identificationType;

	@NotNull(message="Token is required field in input request.|ValidateTOKEN")
	@Size(min=1,max=20,message="Token length is invalid.|ValidateTOKEN")
	protected String token;

	@Size(min=1, max=20,message="AgentId length is invalid|ValidateTOKEN")
	protected String agentId;

	@Size(min=1, max=100,message="sourceIPAddress length is invalid|ValidateTOKEN")
	protected String sourceIPAddress;

	protected String deletePINOnSuccess;
}