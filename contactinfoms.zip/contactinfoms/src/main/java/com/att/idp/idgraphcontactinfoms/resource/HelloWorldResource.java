package com.att.idp.idgraphcontactinfoms.resource;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Operation;

/**
 * This is the Interface definition for HelloWorldResource.
 *
 * It uses the JAX-RS annotations to define the HTTP methods, paths, consumed and produced media types.
 * It also uses the Swagger annotations to provide metadata about the API such as the API's name, path, operations, responses.
 *
 * The main method in this interface is the getHelloWorld method, which takes a HttpServletRequest as input and returns a Response.
 * This method is annotated with @POST, @Path, @Consumes, @Produces, @ApiOperation to define its HTTP method, path, consumed and produced media types, operation description, responses.
 */
@Tag(name = "helloworld")
@Path("/helloworld")
@Produces({MediaType.APPLICATION_JSON})
public interface HelloWorldResource {
	
	
	/**
	 * This method is responsible for handling the "Hello World" request.
	 *
	 * It takes a HttpServletRequest as an input parameter and returns a Response.
	 * The method is annotated with @POST, @Path, @Consumes, @Produces, @ApiOperation to define its HTTP method, path, consumed and produced media types, operation description.
	 *
	 * @param request HttpServletRequest that contains the request data for the "Hello World" operation.
	 * @return a Response that contains the result of the operation. If the operation is successful, the response contains a success message. If the operation fails, the response contains an error message.
	 */
	@POST
	@Path("/getHelloWorld")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Hello World",
			 description = "Hello World")
	public Response getHelloWorld ( HttpServletRequest request);

}
