package com.att.idp.idgraphcontactinfoms.db.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.att.idp.idgraphcontactinfoms.db.model.Tdomain;

/**
 * This is the InquireAccountContactInfoRepository interface.
 *
 * It extends JpaRepository to provide standard database operations for the Tdomain entity.
 * The JpaRepository interface is a JPA specific extension of Repository and provides some additional standard JPA operations.
 * It includes methods like save(), findOne(), findAll(), count(), delete() etc.
 *
 * The interface also extends InquireAccountContactInfoRepositoryCustom to include custom methods for the Tdomain entity.
 * These methods are not provided by the JpaRepository and need to be implemented manually.
 *
 * The @Repository annotation is used to indicate that the interface is a repository.
 * Spring will detect the interface by classpath scanning and plug in the persistence layer at runtime.
 */
@Repository 
public interface InquireAccountContactInfoRepository extends JpaRepository<Tdomain, Long> , InquireAccountContactInfoRepositoryCustom {
	
}
