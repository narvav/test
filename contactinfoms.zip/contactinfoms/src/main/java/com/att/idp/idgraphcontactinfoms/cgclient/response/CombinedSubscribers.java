package com.att.idp.idgraphcontactinfoms.cgclient.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

/**
 * The CombinedSubscribers class represents a combined subscriber's information in the system.
 * It implements the Serializable interface, which means its instances can be converted to a byte stream and
 * restored back to the same object later. This is useful for storing objects in a file or sending them over a network.
 *
 * This class contains various properties related to a combined subscriber such as subscriberId, effectiveDate, status, subscriptionId, simSwapDate, smsCapability, primarySubscriber, firstName, lastName, phoneNumber, phoneNumberAttIndicator, secondaryPhoneNumberAttIndicator, and emailAddress.
 * Each property has its corresponding getter and setter methods.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.cgclient.response package.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(name = "CombinedSubscribers")
@Getter
@Setter
@NoArgsConstructor
public class CombinedSubscribers implements Serializable {

	private static final long serialVersionUID = 1647488365389225977L;

	private String subscriberId;
	private String effectiveDate;
	private String status;
	private String subscriptionId;
	private String simSwapDate;
	private String smsCapability;
	private String primarySubscriber;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private boolean phoneNumberAttIndicator;
	private boolean secondaryPhoneNumberAttIndicator;
	private String emailAddress;
	private String duoIdentifier;
}