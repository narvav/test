package com.att.idp.idgraphcontactinfoms.resource.request;

import java.io.Serializable;
import jakarta.validation.Valid;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.request package.
 *
 * The DeliveryMethods class implements the Serializable interface, allowing instances of this class to be converted into a byte stream.
 *
 * The class is used to represent a DeliveryMethods object, which contains several fields related to different delivery methods.
 * These fields include sms, email, letter, and ao.
 *
 * Each field is annotated with @Valid, indicating that the nested constraints on the associated object should be evaluated.
 *
 * The class provides a no-argument constructor, as well as getter and setter methods for each field.
 * It also overrides the toString method, providing a custom string representation of the object using reflection.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DeliveryMethods implements Serializable{

	@Valid
	protected Sms sms;

	@Valid
	protected Email email;

	@Valid
	protected Letter letter;

	@Valid
	protected Ao ao;
}