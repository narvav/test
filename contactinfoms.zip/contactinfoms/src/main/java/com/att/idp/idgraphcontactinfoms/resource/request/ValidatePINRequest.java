package com.att.idp.idgraphcontactinfoms.resource.request;

import java.util.HashMap;
import java.util.Map;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * This class is part of the com.att.idp.idgraphcontactinfoms.resource.request package.
 *
 * The ValidatePINRequest class is used to represent a request to validate a PIN.
 * It contains several fields, each of which represents a parameter of the request.
 * These fields include transactionName, callingSystemId, accountId, identificationType, securityCode, agentId, idpTraceId, deletePINOnSuccess, and unknownAttributes.
 *
 * Each field is annotated with @NotNull and/or @Size, indicating that they are required fields and have size constraints.
 * The messages associated with these annotations provide additional information about the requirements for each field.
 *
 * The class provides a toString method, which returns a string representation of the object.
 */
@Schema(name = "ValidatePINRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class ValidatePINRequest {
	
	protected final String transactionName = "ValidatePIN";
	
	@Size(min = 1, max = 20, message =  "CallingSystemId length is invalid|ValidatePIN")
	protected String callingSystemId;
	
	@Schema(name = "accountId")
	@NotNull(message="AccountId is required field in input request.|ValidatePIN")
    @Size(min=1, max=60,message="AccountId length is invalid|ValidatePIN")
    protected String accountId;
	
	@Schema(name = "identificationType")
	@NotNull(message="IdentificationType is required field in input request.|ValidatePIN")
    @Size(min=1,max=10,message="IdentificationType length is invalid.|ValidatePIN")
    protected String identificationType;
	
	@Schema(name = "channel")
	@Size(min = 1, max = 40, message =  "channel length is invalid|ValidatePIN")
	protected String channel;
	
	@Schema(name = "securityCode")
	@NotNull(message="SecurityCode is required field in input request.|ValidatePIN")
    @Size(min=1,max=20,message="securityCode length is invalid.|ValidatePIN")
    protected String securityCode;
	
	@Schema(name = "agentId")
	@Size(min=1, max=20,message="AgentId length is invalid|ValidatePIN")
    protected String agentId;
  
	@Schema(name = "idpTraceId")
	protected String idpTraceId;
	
	@Schema(name = "deletePINOnSuccess")
    protected String deletePINOnSuccess;
	
	@Schema(name = "accountType")
	@Size(min=1, max=20, message="accountType length is invalid|ValidatePIN")
    protected String accountType;
	
	@Schema(name = "idpSessionId")
	protected String idpSessionId;

	/**
	 * This field represents a map of unknown attributes.
	 *
	 * The unknownAttributes map is used to store any additional attributes that are not part of the attributeName and attributeValue fields.
	 * It is initialized as a new HashMap.
	 *
	 * The field is annotated with @JsonAnySetter and @JsonAnyGetter, allowing it to be included in JSON serialization and deserialization.
	 */
	@JsonAnySetter
	@JsonAnyGetter
	public Map<String,Object> unknownAttributes = new HashMap<>();

	@Override
	public String toString() {
		return "ValidatePINRequest [transactionName=" + transactionName + ", callingSystemId=" + callingSystemId
				+ ", accountId=" + accountId + ", identificationType=" + identificationType + ", securityCode="
				+ securityCode + ", agentId=" + agentId + ", idpTraceId=" + idpTraceId + ", deletePINOnSuccess="
				+ deletePINOnSuccess + "]";
	}
	
	
    
}
