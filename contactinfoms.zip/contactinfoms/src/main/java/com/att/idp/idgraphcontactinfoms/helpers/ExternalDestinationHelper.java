package com.att.idp.idgraphcontactinfoms.helpers;

import java.util.ArrayList;
import java.util.HashMap;

import com.att.idp.logging.marker.SpiMarker;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphcontactinfoms.integration.Async.AsyncCall;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import org.springframework.web.util.HtmlUtils;

/**
 * The ExternalDestinationHelper class is a Spring component that provides methods for handling external destinations.
 *
 * It uses the AsyncCall Spring component to perform its operations.
 * The class contains three main methods: prepareCSIResponse, prepareBDSResponse, and callMultipleDestinations.
 *
 * The prepareCSIResponse method takes a HashMap as input and returns a HashMap as output.
 * This method prepares the response for the CSI service.
 *
 * The prepareBDSResponse method takes a HashMap as input and returns a HashMap as output.
 * This method prepares the response for the BDS service.
 *
 * The callMultipleDestinations method takes a HashMap as input and returns a HashMap as output.
 * This method calls multiple destinations and processes the responses.
 *
 * The class uses the SLF4J Logger for logging.
 */
@Component
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class ExternalDestinationHelper {
	private static String sClassName = "ExternalDestinationHelper";
	public static final Logger log = LoggerFactory.getLogger(ExternalDestinationHelper.class);
	@Autowired
	private AsyncCall asyncCall;

//	@Autowired
//	private SoapHelper oSoapHelper;

	@Value("${PROP_CALL_CPNI_STUB}")
	private String sPropCallCPNIStub;

	/**
	 *
	 * @param hmCSIInput
	 * @return HashMap
	 */
	private HashMap prepareCSIResponse(HashMap hmCSIInput) {
		HashMap<String, Object> hmResult = null;

		if (hmCSIInput == null) {
			hmCSIInput = CommonUtil.getHashMap();
		}

		if (((String) hmCSIInput.get(CommonDefs.BILLING_ACCOUNT_NUMBER) != null)
				&& ((String) hmCSIInput.get(CommonDefs.BILLING_ACCOUNT_NUMBER)).startsWith("00")) {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ACCOUNT_NOT_FOUND_NUM,
					CErrorDefs.ERR_ACCOUNT_NOT_FOUND_MSG);
			return hmResult;
		}

		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

		HashMap<String, Object> hmAccount = CommonUtil.getHashMap();
		HashMap<String, Object> hmCustomer = CommonUtil.getHashMap();
		HashMap<String, Object> hmSubscriber = CommonUtil.getHashMap();
		HashMap<String, Object> hmCSISubscriber = CommonUtil.getHashMap();
		HashMap<String, Object> hmSubscriber1 = CommonUtil.getHashMap();
		ArrayList alSubscriber = new ArrayList();
		ArrayList alDevice = new ArrayList();
		HashMap<String, Object> hmDeviceInfo = CommonUtil.getHashMap();
		HashMap<String, Object> hmDevice = CommonUtil.getHashMap();
		HashMap<String, Object> hmServiceActivationDate = CommonUtil.getHashMap();
		HashMap<String, Object> hmServiceActivationDate1 = CommonUtil.getHashMap();
		HashMap<String, Object> hmSubscriberStatus = CommonUtil.getHashMap();
		HashMap<String, Object> hmSubscriberStatus1 = CommonUtil.getHashMap();
		HashMap<String, Object> hmName = CommonUtil.getHashMap();
		HashMap<String, Object> hmEmail = CommonUtil.getHashMap();

		HashMap<String, Object> hmAddress = CommonUtil.getHashMap();
		HashMap<String, Object> hmZip = CommonUtil.getHashMap();
		HashMap<String, Object> hmStreet = CommonUtil.getHashMap();
		HashMap<String, Object> hmCounty = CommonUtil.getHashMap();

		HashMap<String, Object> hmAccountCreationDate = CommonUtil.getHashMap();
		HashMap<String, Object> hmAccountStatus = CommonUtil.getHashMap();
		HashMap<String, Object> hmAccountType = CommonUtil.getHashMap();

		hmCounty.put("countyName", "1234");

		hmStreet.put("streetName", "FRANKLIN");
		hmStreet.put("streetType", "ST");
		hmStreet.put("streetNumber", "123");
		hmStreet.put("streetDirection", "E");

		hmZip.put(CommonDefs.ZIP_CODE, "75206");
		hmZip.put(CommonDefs.ZIPCODE_EXTENSION, "1111");

		hmAddress.put(CommonDefs.ZIP, hmZip);
		hmAddress.put(CommonDefs.ADDRESS_LINE_1, "208 E FRANKLIN ST");
		hmAddress.put("addressType", "S");
		hmAddress.put(CommonDefs.KEY_STATE, "TX");
		hmAddress.put("lastUpdate", "2017-06-05T11:19:00Z");
		hmAddress.put("Street", hmStreet);
		hmAddress.put(CommonDefs.KEY_COUNTRY, "US");
		hmAddress.put(CommonDefs.KEY_CITY, "TYLER");
		hmAddress.put("County", hmCounty);

		hmEmail.put(CommonDefs.EMAIL_ADDRESS, "aaa@aaa.com");
		hmEmail.put("emailType", "P");
		hmEmail.put("effectiveDate", "2017-08-22Z");

		hmName.put(CommonDefs.DB_FIRSTNAME, "Amanda");
		hmName.put(CommonDefs.DB_LASTNAME, "JESSIE");

		hmCustomer.put(CommonDefs.NAME, hmName);
		hmCustomer.put(CommonDefs.KEY_EMAIL, hmEmail);
		hmCustomer.put("Address", hmAddress);

		hmAccountCreationDate.put("effectiveDate", "2017-06-05Z");
		hmAccountStatus.put(CommonDefs.STATUS, "A");
		hmAccountType.put(CommonDefs.ACCOUNT_TYPE, "R");

		hmDevice.put(CommonDefs.SMS_CAPABILITY_INDICATOR, "true");
		alDevice.add(hmDevice);

		hmServiceActivationDate.put("effectiveDate", "2017-06-05Z");
		hmSubscriberStatus.put("statusDate", "2017-06-05Z");
		hmSubscriberStatus.put(CommonDefs.SUBSCRIBER_STATUS, "A");
		hmSubscriberStatus.put("statusReasonCode", "323232");

		hmDeviceInfo.put(CommonDefs.DEVICE, alDevice);

		hmSubscriber.put(CommonDefs.DEVICE_INFORMATION, hmDeviceInfo);

		if (hmCSIInput.get(CommonDefs.SUBSCRIBER_NUMBER) != null) {
			hmSubscriber.put(CommonDefs.SUBSCRIBER_NUMBER, (String) hmCSIInput.get(CommonDefs.SUBSCRIBER_NUMBER));
		} else if (hmCSIInput.get(CommonDefs.BILLING_ACCOUNT_NUMBER) != null) {
			hmSubscriber.put(CommonDefs.SUBSCRIBER_NUMBER,
					((String) hmCSIInput.get(CommonDefs.BILLING_ACCOUNT_NUMBER)).substring(0, 10));
		} else {
			hmSubscriber.put(CommonDefs.SUBSCRIBER_NUMBER, (String) hmCSIInput.get(CommonDefs.CTN));
		}

		hmSubscriber.put("ServiceActivationDate", hmServiceActivationDate);
		hmSubscriber.put("SubscriberStatus", hmSubscriberStatus);
		hmSubscriber.put(CommonDefs.KEY_SUBSCRIPTION_ID, "T_DLS_TLG_1496677938000109166343");

		if (((String) hmCSIInput.get(CommonDefs.CTN) != null)
				&& (hmCSIInput.get(CommonDefs.CTN).equals("1234567890"))) {
			hmSubscriber.put(CommonDefs.KEY_SUBSCRIPTION_ID, "T_STUB_DLS_TLG_1496677938000109166000");
		}
		hmCSISubscriber.put(CommonDefs.CSI_SUBSCRIBER, hmSubscriber);
		alSubscriber.add(hmCSISubscriber);

		if ((String) hmCSIInput.get(CommonDefs.BILLING_ACCOUNT_NUMBER) != null
				&& ((String) hmCSIInput.get(CommonDefs.BILLING_ACCOUNT_NUMBER)).startsWith("10")) {

			hmServiceActivationDate1.put("effectiveDate", "2018-06-05Z");

			hmSubscriberStatus1.put("statusDate", "2018-06-05Z");
			hmSubscriberStatus1.put(CommonDefs.SUBSCRIBER_STATUS, "A");
			hmSubscriberStatus1.put("statusReasonCode", "323232");

			hmSubscriber1.put(CommonDefs.DEVICE_INFORMATION, hmDeviceInfo);
			hmSubscriber1.put(CommonDefs.SUBSCRIBER_NUMBER, "1234567890");
			hmSubscriber1.put("ServiceActivationDate", hmServiceActivationDate1);
			hmSubscriber1.put("SubscriberStatus", hmSubscriberStatus1);
			hmSubscriber1.put(CommonDefs.KEY_SUBSCRIPTION_ID, "T_DLS_TLG_1496677938000109100000");

			hmCSISubscriber.put(CommonDefs.CSI_SUBSCRIBER, hmSubscriber1);
			alSubscriber.add(hmCSISubscriber);
			hmAccountType.put(CommonDefs.ACCOUNT_TYPE, "B");
		}

		hmAccount.put(CommonDefs.CUSTOMER, hmCustomer);
		hmAccount.put(CommonDefs.CSI_SUBSCRIBER, alSubscriber);
		hmAccount.put("AccountCreationDate", hmAccountCreationDate);
		hmAccount.put(CommonDefs.KEY_ACCOUNT_STATUS, hmAccountStatus);
		hmAccount.put(CommonDefs.KEY_ACCOUNT_TYPE, hmAccountType);

		if (hmCSIInput.get(CommonDefs.BILLING_ACCOUNT_NUMBER) != null) {
			hmAccount.put(CommonDefs.BILLING_ACCOUNT_NUMBER,
					(String) hmCSIInput.get(CommonDefs.BILLING_ACCOUNT_NUMBER));
		} else {
			hmAccount.put(CommonDefs.BILLING_ACCOUNT_NUMBER,
					(String) hmCSIInput.get(CommonDefs.SUBSCRIBER_NUMBER) + "00");
		}

		hmAccount.put(CommonDefs.CUSTOMER, hmCustomer);

		hmResult.put(CommonDefs.CSI_SUBSCRIBER, hmSubscriber);
		hmResult.put(CommonDefs.KEY_CSI_ACCOUNT, hmAccount);

		return hmResult;
	}

	/**
	 *
	 * @param hmBDSInput
	 * @return HashMap
	 */
	private HashMap prepareBDSResponse(HashMap hmBDSInput) {
		HashMap<String, Object> hmResult = null;
		if (hmBDSInput.get(CommonDefs.ACCOUNT_ID) != null
				&& ((String) hmBDSInput.get(CommonDefs.ACCOUNT_ID)).startsWith("00")) {
			hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_ACCOUNT_NOT_FOUND_NUM,
					CErrorDefs.ERR_ACCOUNT_NOT_FOUND_MSG);
			return hmResult;
		}

		hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);

		ArrayList alAccountDetailResponse = new ArrayList();
		HashMap<String, Object> hmAnchorAccount = CommonUtil.getHashMap();
		HashMap<String, Object> hmAccountDetailResponse = CommonUtil.getHashMap();
		HashMap<String, Object> hmAddressInfo = CommonUtil.getHashMap();
		HashMap<String, Object> hmAddressOfRecord = CommonUtil.getHashMap();

		hmAddressOfRecord.put(CommonDefs.KEY_ZIPPLUSFOUR, "123");
		hmAddressOfRecord.put(CommonDefs.KEY_ADDRESS4, "fds ds dsss");
		hmAddressOfRecord.put(CommonDefs.KEY_STATE, "TX");
		hmAddressOfRecord.put(CommonDefs.KEY_NBR_NON_ADDRESS_LINES, "75201");
		hmAddressOfRecord.put(CommonDefs.KEY_ADDRESS2, "209 N ALABAMA ST");
		hmAddressOfRecord.put(CommonDefs.KEY_ADDRESS3, "");
		hmAddressOfRecord.put(CommonDefs.KEY_POSTOFFICE, "AMARILLO TX  79106-7646");
		hmAddressOfRecord.put(CommonDefs.KEY_CITY, "AMARILLO");
		hmAddressOfRecord.put(CommonDefs.KEY_BILLNAME, "ENEDINA OTERO");
		hmAddressOfRecord.put(CommonDefs.KEY_FOREIGN_ADDR_IND, "N");

		hmAddressInfo.put("AddressOfRecord", hmAddressOfRecord);

		hmAnchorAccount.put("EmailAddress", "aaa@aaa.com");
		hmAnchorAccount.put(CommonDefs.CUSTOMER_ACTIVE_DATE, "2016-04-22");
		hmAnchorAccount.put("EmailUndeliverableInd", "0");
		hmAnchorAccount.put("EmailAddrLastUpdateTs", "2016-04-22 18:01:32.009161");
		hmAnchorAccount.put(CommonDefs.KEY_ACCOUNT_STATUS, "Live");
		hmAnchorAccount.put(CommonDefs.SERVICE_NBR, "0000000000");
		hmAnchorAccount.put(CommonDefs.KEY_ACCOUNT_ID, (String) hmBDSInput.get(CommonDefs.ACCOUNT_ID));
		hmAnchorAccount.put("AddressInfo", hmAddressInfo);
		if (hmBDSInput.get(CommonDefs.BDS_BILLING_ID) != null) {
			hmAnchorAccount.put(CommonDefs.BDS_BILLING_ID, (String) hmBDSInput.get(CommonDefs.BDS_BILLING_ID));
		} else {
			hmAnchorAccount.put(CommonDefs.BDS_BILLING_ID, (String) hmBDSInput.get(CommonDefs.KEY_ACCOUNT_ID));
		}

		hmAccountDetailResponse.put(CommonDefs.ANCHOR_ACCOUNT, hmAnchorAccount);

		hmResult.put(CommonDefs.ACCOUNT_DETAIL_RESPONSE, hmAccountDetailResponse);
		return hmResult;
	}

	/**
	 * This method calls multiple destinations.
	 *
	 * It takes a HashMap as input which contains the details for the multiple destinations call.
	 * The method performs various operations including input validation, multiple destinations call, and response construction.
	 *
	 * The method uses the prepareCSIResponse and prepareBDSResponse methods to prepare the responses for the CSI and BDS services respectively.
	 * If the 'PROP_CALL_CPNI_STUB' property is set to 'Y', the method uses the prepareCSIResponse and prepareBDSResponse methods to prepare the responses.
	 * Otherwise, the method calls the multiple destinations and gets the responses.
	 *
	 * The method uses the AsyncCall Spring component to perform its operations.
	 * The method uses the SLF4J Logger for logging.
	 *
	 * @param hmInput a HashMap that contains the details for the multiple destinations call.
	 * @return a HashMap that contains the result of the multiple destinations call.
	 */
	public HashMap callMultipleDestinations(HashMap hmInput) {
		String sThisMethod = ".callMultipleDestinations.";
		HashMap<String, Object> hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
				CommonDefs.COMMON_SUCCESS_MSG);

		try {
			log.info("{}{}HLP000 : hmInput = {}", sClassName, sThisMethod, HtmlUtils.htmlEscape(String.valueOf(hmInput)));
			HashMap<String, Object> hmConsDbusInput = CommonUtil.getHashMap();
			HashMap<String, Object> hmDbusInput = CommonUtil.getHashMap();

			hmDbusInput.put(CommonDefs.TRANSACTION_NAME, (String) hmInput.get(CommonDefs.TRANSACTION_NAME));
			hmDbusInput.put(CommonDefs.TRANSACTION_ID, (String) hmInput.get(CommonDefs.TRANSACTION_ID));
			hmDbusInput.put(CommonDefs.CALLING_SYSTEM_ID, (String) hmInput.get(CommonDefs.CALLING_SYSTEM_ID));

			String sAccountType = (String) hmInput.get(CommonDefs.ACCOUNT_TYPE);
			String sAccountInvariantId = (String) hmInput.get(CommonDefs.ACCOUNT_INVARIANT_ID);
			String sAccountId = (String) hmInput.get(CommonDefs.ACCOUNT_ID);

			if (sAccountType != null && !sAccountType.isEmpty()) {
				if (CommonDefs.ECOMM_SERVICE.equalsIgnoreCase(sAccountType)) {
					if ((sAccountInvariantId != null && !sAccountInvariantId.isEmpty())) {
						hmDbusInput.put(CommonDefs.BDS_BILLING_ID, sAccountInvariantId);
					} else if (sAccountId != null && !sAccountId.isEmpty()) {
						hmDbusInput.put(CommonDefs.KEY_ACCOUNT_ID, sAccountId);
					}
					hmDbusInput.put(CommonDefs.ACCOUNT_TYPE, sAccountType);
					hmDbusInput.put(CommonDefs.EVENTNAME, "QueryBDSInquireAccountDetail");

					hmConsDbusInput.put(CommonDefs.BDS_SOR, hmDbusInput);
				}

				else if (CommonDefs.TITAN_SERVICE.equalsIgnoreCase(sAccountType)) {
					if ((sAccountInvariantId != null && !sAccountInvariantId.isEmpty())) {
						hmDbusInput.put(CommonDefs.KEY_ACCOUNT_ID, sAccountInvariantId);
					} else if (sAccountId != null && !sAccountId.isEmpty()) {
						hmDbusInput.put(CommonDefs.KEY_ACCOUNT_ID, sAccountId);
					}
					hmDbusInput.put(CommonDefs.REGION_PROVIDER_ID, "V");
					hmDbusInput.put(CommonDefs.ACCOUNT_TYPE, sAccountType);
					hmDbusInput.put(CommonDefs.EVENTNAME, "QueryBDSInquireAccountDetail");

					hmConsDbusInput.put(CommonDefs.BDS_SOR, hmDbusInput);
				} else {
					if ((sAccountInvariantId != null && !sAccountInvariantId.isEmpty())) {
						hmDbusInput.put(CommonDefs.BILLING_ACCOUNT_NUMBER, sAccountInvariantId);
					} else if (sAccountId != null && !sAccountId.isEmpty()) {
						hmDbusInput.put(CommonDefs.SUBSCRIBER_NUMBER, sAccountId);
					}
					hmDbusInput.put(CommonDefs.SUBSCRIBER_MASK, (String) hmInput.get(CommonDefs.SUBSCRIBER_MASK));
					hmDbusInput.put(CommonDefs.EVENTNAME, "QueryCSIInquireAccountProfile");

					hmDbusInput.put(CommonDefs.ACCOUNT_TYPE, sAccountType);
					hmConsDbusInput.put(CommonDefs.DESTINATION_CSI, hmDbusInput);
				}
			}

			HashMap<String, Object> hmMosubCTN = (HashMap<String, Object>) hmInput.remove("mosubCTN");
			if (hmMosubCTN != null && !hmMosubCTN.isEmpty()) {
				hmConsDbusInput.put("mosubCTN", hmMosubCTN);
			}

			// call dbus
			log.info("{}{}EDH_01 : Property PROP_CALL_CPNI_STUB : {}", sClassName, sThisMethod, sPropCallCPNIStub);

			if (sPropCallCPNIStub != null && sPropCallCPNIStub.equals(CommonDefs.IND_Y)) {

				if (CommonDefs.ECOMM_SERVICE.equalsIgnoreCase(sAccountType)
						|| CommonDefs.TITAN_SERVICE.equalsIgnoreCase(sAccountType)) {
					HashMap hmBDSResponse = prepareBDSResponse((HashMap) hmConsDbusInput.get(CommonDefs.BDS_SOR));
					hmResult.put(CommonDefs.BDS_SOR, hmBDSResponse);

				} else {
					HashMap hmCSIResponse = prepareCSIResponse(
							(HashMap) hmConsDbusInput.get(CommonDefs.DESTINATION_CSI));
					hmResult.put(CommonDefs.DESTINATION_CSI, hmCSIResponse);
				}

				if (hmMosubCTN != null && !hmMosubCTN.isEmpty()) {
					HashMap<String, Object> hmCSIResponse = prepareCSIResponse(hmMosubCTN);
					hmResult.put("mosubCTN", hmCSIResponse);
				}
			} else {

				log.info("{}{}EDH_02 Calling AsyncCall.processRequest() with input : {}", sClassName, sThisMethod,
						hmConsDbusInput);
				hmResult = asyncCall.processRequest(hmConsDbusInput);
			}

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, log);

		}
		log.info(SpiMarker.getInstance(),"{}{}HLP999 : hmResult = {}", sClassName, sThisMethod, HtmlUtils.htmlEscape(String.valueOf(hmResult)));
		return hmResult;

	}

	/**
	 * This method calls the CSI service.
	 *
	 * It takes a HashMap as input which contains the details for the CSI service call.
	 * The method performs various operations including input validation, CSI service call, and response construction.
	 *
	 * The method uses the prepareCSIResponse method to prepare the response for the CSI service.
	 * If the 'PROP_CALL_CPNI_STUB' property is set to 'Y', the method uses the prepareCSIResponse method to prepare the response.
	 * Otherwise, the method calls the CSI service and gets the response.
	 *
	 * The method uses the SLF4J Logger for logging.
	 *
	 * @param hmInput a HashMap that contains the details for the CSI service call.
	 * @return a HashMap that contains the result of the CSI service call.
	 */
	public HashMap callCSI(HashMap hmInput) {
		String sThisMethod = ".callDestination.";
		HashMap<String, Object> hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
				CommonDefs.COMMON_SUCCESS_MSG);

		try {
			HashMap<String, Object> hmConsDbusInput = CommonUtil.getHashMap();

			// call dbus
			log.info("{}{}CC_01 : Property PROP_CALL_CPNI_STUB : {}", sClassName, sThisMethod, sPropCallCPNIStub);

			if (sPropCallCPNIStub != null && sPropCallCPNIStub.equals(CommonDefs.IND_Y)) {

				hmResult = prepareCSIResponse(hmInput);

			} else {
				//String escapedValueHmInput = (hmInput!=null)?HtmlUtils.htmlEscape(String.valueOf(hmInput)):null;
				log.info("{}{}CC_02 Calling SoapHelper.callCSI() with input : {}", sClassName, sThisMethod, StringUtils.normalizeSpace(hmInput!=null ? hmInput.toString() : null));
				log.debug("{}{}CC_03 Response from SoapHelper.callCSI() : {}", sClassName, sThisMethod, hmResult);
			}

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, log);

		}
		return hmResult;

	}
}
