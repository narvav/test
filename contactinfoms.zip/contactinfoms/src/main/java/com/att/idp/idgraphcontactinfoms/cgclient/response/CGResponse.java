package com.att.idp.idgraphcontactinfoms.cgclient.response;

import static org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString;
import static org.apache.commons.lang3.builder.ToStringStyle.JSON_STYLE;

import java.util.Map;

import com.att.idp.core.exception.ServiceError;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.node.ArrayNode;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

/**
 * The CGResponse class represents a customer's response in the system.
 * It implements the Serializable interface, which means its instances can be converted to a byte stream and
 * restored back to the same object later. This is useful for storing objects in a file or sending them over a network.
 *
 * This class contains various properties related to a customer's response such as transactionName, appStatusMsg, appStatusCode, appInfo, appCategoryCode, errors, idpTraceId, subscribers, and accounts.
 * Each property has its corresponding getter and setter methods.
 *
 * This class is part of the com.att.idp.idgraphcontactinfoms.cgclient.response package.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Schema(name = "CGResponse")
@Getter
@Setter
@NoArgsConstructor
public class CGResponse {

	@JsonIgnore
	private String transactionName;

	private String appStatusMsg;

	private String appStatusCode;

	private String appInfo;

	@JsonIgnore
	private String appCategoryCode;

	private ServiceError errors;

	private String idpTraceId;

	private ArrayNode subscribers;

	@JsonProperty("subscribers")
	public void setSubscribers(ArrayNode subscribers) {
		this.subscribers = subscribers;
	}

	private Map accounts;

	@JsonProperty("error")
	public void setErrors(ServiceError errors) {
		this.errors = errors;
	}

	@JsonProperty("idp-trace-id")
	public void setIdpTraceId(String idpTraceId) {
		this.idpTraceId = idpTraceId;
	}

	@Override
	public String toString() {
		return reflectionToString(this, JSON_STYLE);
	}
}