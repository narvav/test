package com.att.idp.idgraphcontactinfoms.helpers;

import java.util.HashMap;

import com.att.mpsys.common.helpers.FeatureManagerHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.logging.marker.SpiMarker;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;

/**
 * This class is a helper class for querying CPNI account contact information.
 *
 * It contains methods for querying CPNI account contact information based on the input parameters.
 * The class uses the Spring Framework's @Component annotation to indicate that it is a bean and can be used for dependency injection.
 *
 * The class has instance variables objProcessEcommTitanCPNIHelper, objprocessMobilityCPNIHelper, and objExternalDestinationHelper that are injected using the @Autowired annotation.
 * These variables are used to interact with the ProcessEcommTitanCPNIHelper, ProcessMobilityCPNIHelper, and ExternalDestinationHelper respectively to process and query CPNI account contact information.
 *
 * The main method in this class is the queryCPNIAccountContact method, which takes a HashMap as input and returns a HashMap as output.
 * The queryCPNIAccountContact method uses several other methods in the class to validate the input data, process the input data, and store the data.
 *
 * The class also contains a logger for logging information and error messages.
 */
@Component
@PropertySource(value = "file:opt/ajsc/etc/config/contactInfo.properties")
public class QueryCPNIAcccountContactHelper {

	@Autowired
	private ProcessEcommTitanCPNIHelper objProcessEcommTitanCPNIHelper;

	@Autowired
	private ProcessMobilityCPNIHelper objprocessMobilityCPNIHelper;

	@Autowired
	private ExternalDestinationHelper objExternalDestinationHelper;

	@Autowired
	private ProcessTitanCPNIHelper objProcessTitanCPNIHelper;

	@Autowired
	FeatureManagerHelper featureManager;

	@Value("${PROP_QUERY_CPNI_ACCOUNT_CSI}")
	private String stValidCallers;

	private static String sClassName = "QueryCPNIAcccountContactHelper";
	public static final Logger logger = LoggerFactory.getLogger(QueryCPNIAcccountContactHelper.class);

	/**
	 * This method queries CPNI account contact information based on the input parameters.
	 *
	 * It first retrieves the account type, account invariant ID, and account ID from the input HashMap.
	 * Depending on the account type, it calls the appropriate helper method to process the CPNI account contact information.
	 * If the account type is mobility, it calls the ProcessMobilityCPNIHelper's processMobilityCPNI method.
	 * If the account type is ecomm or titan, it calls the ProcessEcommTitanCPNIHelper's processEcommTitanCPNI method.
	 * The method then checks the response from the helper method. If the response indicates an error, the method constructs an error response and returns it.
	 * If the response from the helper method indicates success, the method constructs a success response and returns it.
	 *
	 * @param hmInput a HashMap that contains the input data for the CPNI account contact information query. The HashMap should include the account type, account invariant ID, and account ID.
	 * @return a HashMap that contains the result of the operation. The HashMap contains an application status code, an application info message, and the queried CPNI account contact information.
	 * @throws Exception if an error occurs during the operation.
	 */
	public HashMap<String, Object> queryCPNIAccountContact(HashMap<String, Object> hmInput) {

		String sMethodName = ".queryCPNIAccountContact.";
		logger.info("{}{}HLP000 : Input Hash : {}", sClassName, sMethodName, hmInput);

		HashMap<String, Object> hmResult = null;
		String stAppInfo = null;

		try {
			String sAccountType = (String) hmInput.get(CommonDefs.ACCOUNT_TYPE);
			String sAccountInvId = (String) hmInput.get(CommonDefs.ACCOUNT_INVARIANT_ID);
			String sAccountId = (String) hmInput.get(CommonDefs.ACCOUNT_ID);
			if (sAccountInvId != null && !sAccountInvId.isEmpty()) {
				sAccountId = null;
				hmInput.put(CommonDefs.ACCOUNT_ID, sAccountId);

			} else if (sAccountId == null || sAccountId.isEmpty()) {
				stAppInfo = "Either accountInvariantId or accountId must be present in input";
				logger.info("{}{}QCACH_01 : {}", sClassName, sMethodName, stAppInfo);
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
				return hmResult;
			}

			HashMap<String, Object> hmMosubCTN = null;

			if (sAccountType.equals(CommonDefs.MOBILITY_SERVICE) || sAccountType.equals("BSSEWIRELESS")) {

				if (sAccountId != null && sAccountId.trim().length() != 10) {
					stAppInfo = "CTN should be of 10 digits";
					hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
					logger.info("{}{}QCACH_02 : {}", sClassName, sMethodName, stAppInfo);
					return hmResult;
				}

				String sInputMask = (String) hmInput.get(CommonDefs.SUBSCRIBER_MASK);

				if (sInputMask == null || sInputMask.isEmpty()) {
					String sFilterSIMSwap = (String) hmInput.get("filterSIMSwapCTNs");

					if (sFilterSIMSwap != null && sFilterSIMSwap.trim().equalsIgnoreCase(CommonDefs.IND_Y)) {
						sInputMask = "SL:SN:SD";
					} else {
						sInputMask = "SL:SN";
					}

					hmInput.put(CommonDefs.SUBSCRIBER_MASK, sInputMask);
				}

				String sCheckSMS = (String) hmInput.get("checkSMS");

				if (sCheckSMS == null || sCheckSMS.isEmpty()) {
					sCheckSMS = "Y";
					hmInput.put("checkSMS", sCheckSMS);
				}

				logger.info(
						"{}{}QCACH_03 : Calling ExternalDestinationHelper.callMultipleDestinations with hminput : {}",
						sClassName, sMethodName, hmInput);

				HashMap<String, Object> hmDbusResponse = objExternalDestinationHelper.callMultipleDestinations(hmInput);

				logger.info("{}{}QCACH_04 : Response from ExternalDestinationHelper.callMultipleDestinations : {}",
						sClassName, sMethodName, hmDbusResponse);

				hmMosubCTN = (HashMap) hmDbusResponse.get("mosubCTN");

				logger.info("{}{}QCACH_05 : Calling ProcessMobilityCPNIHelper with hminput : {}", sClassName,
						sMethodName, hmInput);

				hmResult = objprocessMobilityCPNIHelper.processMobilityCPNI(hmInput,
						(HashMap) hmDbusResponse.get(CommonDefs.DESTINATION_CSI));

				logger.info("{}{}QCACH_06 : Response from ProcessMobilityCPNIHelper: {}", sClassName, sMethodName,
						hmResult);

			} else if (sAccountType.equals(CommonDefs.ECOMM_SERVICE) || sAccountType.equals(CommonDefs.TITAN_SERVICE)) {

				boolean isCGCallforUverse = featureManager.isEnabled("svc-idgraph-contactinfo-cpni-uverse-callcg");
				logger.debug("IXP Flag svc-idgraph-contactinfo-cpni-uverse-callcg :" + isCGCallforUverse);
				if (CommonDefs.TITAN_SERVICE.equals(sAccountType) && isCGCallforUverse) {
					hmResult = objProcessTitanCPNIHelper.getTitanCPNIContacts(hmInput);
					logger.debug("{}{}QCACH_07.1 : ResponseHash from getTitanCPNIContacts : {}", sClassName, sMethodName,
							hmResult);
					return hmResult;

				} else {

					if (sAccountType.equals(CommonDefs.ECOMM_SERVICE) && sAccountId != null
							&& sAccountId.trim().length() != 13) {
						stAppInfo = "BTN should be 13 digits";
						hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
						logger.info("{}{}QCACH_07 : {}", sClassName, sMethodName, stAppInfo);
						return hmResult;
					}

					logger.info(
							"{}{}QCACH_08 : Calling ExternalDestinationHelper.callMultipleDestinations with hminput : {}",
							sClassName, sMethodName, hmInput);

					HashMap<String, Object> hmDbusResponse = objExternalDestinationHelper.callMultipleDestinations(hmInput);

					logger.info(SpiMarker.getInstance(), "{}{}QCACH_09 : Response from ExternalDestinationHelper.callMultipleDestinations : {}",
							sClassName, sMethodName, hmDbusResponse);

					hmMosubCTN = (HashMap) hmDbusResponse.get("mosubCTN");

					logger.info("{}{}QCACH_10 : Calling ProcessEcommTitanCPNIHelper with hminput : {}", sClassName,
							sMethodName, hmInput);

					hmResult = objProcessEcommTitanCPNIHelper.processEcommTitanCPNI(hmInput,
							(HashMap) hmDbusResponse.get(CommonDefs.BDS_SOR));

					logger.info("{}{}QCACH_11 : Response from ProcessEcommTitanCPNIHelper: {}", sClassName, sMethodName,
							hmResult);

				}
			}

			if (hmMosubCTN != null && !hmMosubCTN.isEmpty()) {
				hmResult.put("mosubCTN", hmMosubCTN);
			}

		} catch (Exception e) {
			hmResult = CommonErrorMap.makeExceptionMap(e, logger);
		} finally {

			stAppInfo = "Response from QueryCPNIAcccountContactHelper = " + hmResult;
			logger.info("{}{}QCACH_12 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(String.valueOf(stAppInfo)));

			if (hmResult == null || hmResult.isEmpty()) {
				stAppInfo = "Response from QueryCPNIAcccountContactHelper is NULL";
				hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
				logger.info("{}{}QCACHE_13 : {}", sClassName, sMethodName, stAppInfo);
			}

			logger.info(SpiMarker.getInstance(),"{}{}HLP999 : response from QueryCPNIAcccountContactHelper{}", sClassName, sMethodName,
					hmResult);
		}
		return hmResult;
	}

}
