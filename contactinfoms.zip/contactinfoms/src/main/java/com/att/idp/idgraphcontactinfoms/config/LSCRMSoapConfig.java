package com.att.idp.idgraphcontactinfoms.config;


import com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig;
import org.apache.http.HttpHost;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.event.EventListener;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;

@Configuration
@PropertySource(value = "${contactinfo.credentials.path}")
public class LSCRMSoapConfig {

    @Value("${proxy.auth.host:proxy.conexus.svc.local}")
    public String azProxyHost;

    @Value("${proxy.auth.port:3128}")
    public String azProxyPort;

    @Value("${lscrm.enable.http.proxy:false}")
    public boolean proxyEnabled;

    @Autowired
    private IDGraphAzureAppConfig idGraphAzureAppConfig;

    @Autowired
    private ApplicationContext applicationContext;

    public static final Logger logger = LoggerFactory.getLogger(LSCRMSoapConfig.class);


    @EventListener(RefreshScopeRefreshedEvent.class)
    public void onConfigurationRefresh() throws Exception {
        if (idGraphAzureAppConfig.isLscrmSoapHttpClientRefreshEnabled()) {
            synchronized (this) {
                try {
                    RequestConfig cfg = RequestConfig.custom()
                            .setConnectTimeout(idGraphAzureAppConfig.getLscrmConnectTimeout())
                            .setSocketTimeout(idGraphAzureAppConfig.getLscrmReadTimeout()).build();
                    HttpComponentsMessageSender httpComponentsMessageSender = applicationContext.getBean(HttpComponentsMessageSender.class);
                    if (proxyEnabled) {
                        CloseableHttpClient client = HttpClients
                                .custom()
                                .setProxy(new HttpHost(azProxyHost, Integer.parseInt(azProxyPort)))
                                .addInterceptorFirst(new HttpComponentsMessageSender.RemoveSoapHeadersInterceptor())
                                .setDefaultRequestConfig(cfg)
                                .build();
                        httpComponentsMessageSender.setHttpClient(client);
                    } else {
                        httpComponentsMessageSender.setReadTimeout(idGraphAzureAppConfig.getLscrmReadTimeout());
                        httpComponentsMessageSender.setConnectionTimeout(idGraphAzureAppConfig.getLscrmConnectTimeout());
                    }
                    logger.info("Updating httpComponentsMessageSender bean dynamically with new appconfig values: lscrmreadTimeout={} lscrmConnectTimeout={}",
                            idGraphAzureAppConfig.getLscrmReadTimeout(), idGraphAzureAppConfig.getLscrmConnectTimeout());
                } catch (Exception e) {
                    logger.error("Failed to update httpComponentsMessageSender  with new appconfig values.", e);
                }
            }
        } else {
            logger.info("httpComponentsMessageSender refresh is disabled. Retaining the old httpComponentsMessageSender.");
        }
    }

    /**
     * Creates and configures the HttpComponentsMessageSender bean for SOAP communication.
     * Handles proxy and non-proxy scenarios with proper timeout and error handling.
     * @return configured HttpComponentsMessageSender
     * @throws IllegalArgumentException if proxy configuration is invalid
     */
    @Bean
    public HttpComponentsMessageSender httpComponentsMessageSender() {
        HttpComponentsMessageSender httpComponentsMessageSender = null;
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(idGraphAzureAppConfig.getLscrmConnectTimeout())
                .setSocketTimeout(idGraphAzureAppConfig.getLscrmReadTimeout())
                .build();
        if(proxyEnabled) {
            logger.info("setting proxy for HttpComponentsMessageSender() with proxy flow as  azProxyHost: {} & azProxyPort: {}", azProxyHost, azProxyPort);

            /*Proxy Initialization*/
            CloseableHttpClient client = HttpClients
                    .custom()
                    .setProxy(new HttpHost(azProxyHost, Integer.parseInt(azProxyPort)))
                    .addInterceptorFirst(new HttpComponentsMessageSender.RemoveSoapHeadersInterceptor())
                    .setDefaultRequestConfig(requestConfig)
                    .build();
            httpComponentsMessageSender = new HttpComponentsMessageSender(client);
        } else {
            /*On-Prem Flow for Soap Endpoints*/
            logger.info("MPSConfig.idpHttpComponentsMessageSender() for onPremise flow");
            httpComponentsMessageSender = new HttpComponentsMessageSender();
            httpComponentsMessageSender.setReadTimeout(idGraphAzureAppConfig.getLscrmReadTimeout());
            httpComponentsMessageSender.setConnectionTimeout(idGraphAzureAppConfig.getLscrmConnectTimeout());
        }

        logger.info("initial httpComponentsMessageSender bean dynamically with new appconfig values: lscrmreadTimeout={} lscrmConnectTimeout={}",
                idGraphAzureAppConfig.getLscrmReadTimeout(), idGraphAzureAppConfig.getLscrmConnectTimeout());
        return httpComponentsMessageSender;
    }

}