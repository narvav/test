package com.att.idp.idgraphcontactinfoms.service;

import jakarta.ws.rs.core.MultivaluedMap;

import com.att.idp.idgraphcontactinfoms.resource.request.InquirePINRequest;
import com.att.idp.idgraphcontactinfoms.resource.response.InquirePINResponse;


public interface InquirePINService {


	InquirePINResponse inquirePIN(InquirePINRequest inquirePINRequest, MultivaluedMap<String, String> requestHeader);

}


