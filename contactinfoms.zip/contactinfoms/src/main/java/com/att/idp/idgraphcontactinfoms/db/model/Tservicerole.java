package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "TSERVICEROLE", schema = "MPS_OWNER")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Tservicerole implements Serializable {

	private static final long serialVersionUID = -7553755351401420401L;

	@EmbeddedId
	@AttributeOverrides({
			@AttributeOverride(name = "serviceId", column = @Column(name = "SERVICE_ID", nullable = false, precision = 22, scale = 0)),
			@AttributeOverride(name = "roleId", column = @Column(name = "ROLE_ID", nullable = false, precision = 22, scale = 0)) })
	private TserviceroleId id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SERVICE_ID", nullable = false, insertable = false, updatable = false)
	private Tservice tservice;

	@Column(name = "ROLE_NAME", nullable = false, length = 30)
	private String roleName;

	@Column(name = "ROLE_DESC", nullable = false)
	private String roleDesc;

	@Column(name = "DELEGATION_MODEL", nullable = false, length = 1)
	private char delegationModel;

	@Column(name = "DEFAULT_ROLE", nullable = false, length = 1)
	private char defaultRole;

	@Column(name = "INHERITED_ROLE", nullable = false, length = 1)
	private char inheritedRole;

	@Column(name = "REQUIRED_STATUS", nullable = false, precision = 22, scale = 0)
	private Long requiredStatus;

	@Column(name = "COLLECTION", nullable = false, length = 1)
	private char collection;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tservicerole")
	private Set<Tmemberservicerole> tmemberserviceroles = new HashSet<>(0);

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "tservicerole")
	private Set<Trolecollection> trolecollections = new HashSet<>(0);
}