package com.att.idp.idgraphcontactinfoms.metrics;

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import static com.att.idp.cd.observability.metrics.utils.Constants.DB;
import static com.att.idp.idgraphcontactinfoms.utils.Constants.IDGRAPH_CONTACT_INFO_MS_DB_ERR;

/**
 * ErrorMetricHandler is a Spring component responsible for capturing error metrics
 * related to security code and contact information operations in the database.
 *
 * <p>This class uses the @TimedMetrics annotation to define metrics that are
 * automatically captured during method execution. The metrics include constant tags
 * for database, container, and operation details.</p>
 */
@Component
public class ErrorMetricHandler {

    /**
     * Captures error metrics for retrieving security codes from the database.
     *
     * <p>The @TimedMetrics annotation specifies the metric name, type, description,
     * and parameter keys. This method is intended to be intercepted by the metrics
     * library to record relevant metrics.</p>
     *
     * @param errMsg The error message to be recorded in the metric.
     */
    @TimedMetrics(
            name = IDGRAPH_CONTACT_INFO_MS_DB_ERR,
            type = DB,
            description = "Error retrieving/validating security codes from db"
    )
    @Async
    public void recordDBErrorMetric(String errMsg) {
        // Placeholder for actual metric recording logic
    }
}