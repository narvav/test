package com.att.idp.idgraphcontactinfoms.db.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TservicecontactId implements java.io.Serializable {

	private static final long serialVersionUID = 3198480054831751466L;

	@Column(name = "SOR_ID", nullable = false, precision = 22, scale = 0)
	private Long sorId;

	@Column(name = "SOR_INVARIANT_ID", nullable = false)
	private String sorInvariantId;

	@Column(name = "CONTACT_TYPE", nullable = false, length = 30)
	private String contactType;


	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof TservicecontactId))
			return false;
		TservicecontactId castOther = (TservicecontactId) other;

		return ((this.getSorId() == castOther.getSorId()) || (this.getSorId() != null && castOther.getSorId() != null
				&& this.getSorId().equals(castOther.getSorId())))
				&& ((this.getSorInvariantId() == castOther.getSorInvariantId())
						|| (this.getSorInvariantId() != null && castOther.getSorInvariantId() != null
								&& this.getSorInvariantId().equals(castOther.getSorInvariantId())))
				&& ((this.getContactType() == castOther.getContactType())
						|| (this.getContactType() != null && castOther.getContactType() != null
								&& this.getContactType().equals(castOther.getContactType())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result + (getSorId() == null ? 0 : this.getSorId().hashCode());
		result = 37 * result + (getSorInvariantId() == null ? 0 : this.getSorInvariantId().hashCode());
		result = 37 * result + (getContactType() == null ? 0 : this.getContactType().hashCode());
		return result;
	}

}
