package com.att.idp.idgraphcontactinfoms.integration;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import com.att.idp.idgraphcontactinfoms.appconfig.config.IDGraphAzureAppConfig;
import org.apache.hc.client5.http.ConnectTimeoutException;
import org.apache.hc.client5.http.impl.routing.DefaultProxyRoutePlanner;
import org.apache.hc.core5.http.HttpHost;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.att.idp.http.client.RestApiClient;
import com.att.idp.http.client.config.RestTemplateBeanFactory;
import com.att.idp.idgraphcontactinfoms.utils.JsonService;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;

import javax.annotation.PostConstruct;

/**
 * This class is an implementation of the RestApiClient interface and is used to make REST API calls to the InquireProfile service.
 * <p>
 * It contains methods for making synchronous POST calls to the InquireProfile service and processing the response.
 * The class uses the Spring Framework's @Component annotation to indicate that it is a bean and can be used for dependency injection.
 * <p>
 * The class has several instance variables that are injected using the @Autowired and @Value annotations.
 * These variables are used to interact with the RestTemplateBeanFactory and to store configuration values such as the IDM OUD endpoint and client credentials.
 * <p>
 * The main method in this class is the postInquireProfileSyncCall method, which takes a HashMap and two Strings as input and returns a Map as output.
 * The postInquireProfileSyncCall method uses the RestTemplate's exchange method to make the POST call and processes the response.
 * <p>
 * The class also contains a private method for populating the HTTP headers for the REST API call.
 * <p>
 * The class also contains a logger for logging information and error messages.
 */
@Component
public class InquireProfileRestClient implements RestApiClient {

    private static final Logger logger = LoggerFactory.getLogger(InquireProfileRestClient.class);

    private static final String INQUIRE_PROFILE_REST_CLIENT = "inquireprofilerestclient";

    private static String sClassName = "InquireProfileRestClient";

    @Value("${apiclient.rest.idmoud.endpoint}")
    private String idmoudEndpoint;

    @Value("${apiclient.rest.default.userTypes.registered.username}")
    private String clientid;

    @Value("${apiclient.rest.default.userTypes.registered.password}")
    private String clientsecret;

    private RestTemplate restTemplate;
    private static final String ERROR_ENUM = "ErrorEnum";

    private IDGraphAzureAppConfig appConfiguration;
    private final RestTemplateBeanFactory restTemplateFactory;
    private OutboundRestClientBuilder outboundRestClientBuilder;

    public InquireProfileRestClient() {
        this.restTemplateFactory = null;
        this.appConfiguration = null;
        this.outboundRestClientBuilder = null;
    }


    @Autowired
    public InquireProfileRestClient(RestTemplateBeanFactory restTemplateBeanFactory, IDGraphAzureAppConfig appConfiguration, OutboundRestClientBuilder outboundRestClientBuilder) throws Exception {
        this.restTemplateFactory = restTemplateBeanFactory;
        this.appConfiguration = appConfiguration;
        this.outboundRestClientBuilder = outboundRestClientBuilder;
        this.restTemplate = restTemplateFactory.getObject(INQUIRE_PROFILE_REST_CLIENT);
    }

    @PostConstruct
    public void init() {
        this.restTemplate = this.initializeRestTemplate(this.restTemplate);
        logger.info("RestTemplate connectTimeout={} ms, readTimeout={} ms", appConfiguration.getInquireprofilerestclientConnectTimeout(), appConfiguration.getInquireprofilerestclientReadTimeout());
    }


    /**
     * Handles the refresh event triggered by the Spring Cloud RefreshScope.
     * <p>
     * This method is invoked when the application context is refreshed, typically due to
     * configuration changes. It synchronizes the update of the `RestTemplate` instance
     * with new timeout values retrieved from the `IDGraphAzureAppConfig` bean.
     * If the update fails, the method logs the error and retains the existing `RestTemplate`.
     *
     * @throws Exception if an error occurs while updating the `RestTemplate` instance.
     */
    @EventListener(RefreshScopeRefreshedEvent.class)
    public void onConfigurationRefresh() throws Exception {
        if (appConfiguration.isInquireRestClientRefreshEnabled()) {
            synchronized (this) {
                try {

                    if (this.restTemplate == null) {
                        this.restTemplate = restTemplateFactory.getObject(INQUIRE_PROFILE_REST_CLIENT);
                    }

                    this.restTemplate = initializeRestTemplate(this.restTemplate);

                    logger.info("InquireProfileRestClient dynamically updated with new timeout values: connectTimeout={} ms, readTimeout={} ms", appConfiguration.getInquireprofilerestclientConnectTimeout(), appConfiguration.getInquireprofilerestclientReadTimeout());
                } catch (Exception e) {
                    // Log the error and retain the old RestTemplate
                    logger.error("Failed to update InquireProfileRestClient RestTemplate with new timeout values. Retaining the old RestTemplate.", e);
                }
            }
        } else {
            logger.info("InquireProfileRestClient refresh is disabled. Retaining the existing RestTemplate.");
        }
    }

    private RestTemplate initializeRestTemplate(RestTemplate restTemplate) {
        try {

            if (restTemplate == null) {
                restTemplate = restTemplateFactory.getObject(INQUIRE_PROFILE_REST_CLIENT);
            }

            restTemplate = outboundRestClientBuilder.buildRestTemplate(restTemplate, appConfiguration.getInquireprofilerestclientConnectTimeout(), appConfiguration.getInquireprofilerestclientReadTimeout(), false, null);
            logger.info("Initializing RestTemplate dynamically updated from azureappconfig with new timeout values: connectTimeout={} ms, readTimeout={} ms", appConfiguration.getInquireprofilerestclientConnectTimeout(), appConfiguration.getInquireprofilerestclientReadTimeout());
        } catch (Exception e) {
            logger.error("Error in initializing RestTemplate for InquireProfileRestClient: {}", e.getMessage(), e);
        }
        return restTemplate;
    }


    /**
     * This method makes a synchronous POST call to the InquireProfile service and processes the response.
     * <p>
     * It first converts the input HashMap to a JSON string and populates the HTTP headers for the REST API call.
     * The method then uses the RestTemplate's exchange method to make the POST call to the InquireProfile service.
     * If the HTTP status code in the response is OK or CREATED, the method processes the response body and constructs a success response.
     * If the HTTP status code in the response is not OK or CREATED, the method constructs an error response.
     * The method also handles various exceptions that can occur during the REST API call, such as timeouts and HTTP client errors.
     *
     * @param hmReqPayload     a HashMap that contains the request payload for the POST call. The HashMap should be convertible to a JSON string.
     * @param sTransactionId   a String that contains the transaction ID for the POST call. This is used for logging and tracing purposes.
     * @param sCallingSystemId a String that contains the calling system ID for the POST call. This is used for logging and tracing purposes.
     * @return a Map that contains the result of the operation. The Map contains an application status code, an application info message, and the response from the InquireProfile service.
     * @throws JsonProcessingException if an error occurs while converting the input HashMap to a JSON string.
     * @throws IOException             if an I/O error occurs during the operation.
     */
    public Map<String, Object> postInquireProfileSyncCall(HashMap<String, String> hmReqPayload, String sTransactionId, String sCallingSystemId) throws JsonProcessingException, IOException {
        String sMethodName = ".postInquireProfileSyncCall.";
        logger.debug("invoking postInquireProfileSyncCall");
        HashMap jsonNode = null;
        String resourceUri = null;
        Map<String, Object> hmResult = new HashMap<>();

        String jsonObj = JsonService.getJsonFromObject(hmReqPayload);
        HttpHeaders reqheaders = populatingHeader(sTransactionId, sCallingSystemId);
        HttpEntity httpEntity = new HttpEntity<String>(jsonObj, reqheaders);
        logger.info("postInquireProfileSyncCall: PostUri:{}", idmoudEndpoint);

        try {

            ResponseEntity<JsonNode> output = restTemplate.exchange(idmoudEndpoint, HttpMethod.POST, httpEntity, JsonNode.class);
            jsonNode = JsonService.getObjectFromJson(output.getBody(), HashMap.class);
            if (HttpStatus.OK.equals(output.getStatusCode()) || HttpStatus.CREATED.equals(output.getStatusCode())) {
                HashMap hmSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
                hmSuccess.putAll(jsonNode);
                hmResult.putAll(hmSuccess);

            } else {
                if (null != output) {
                    logger.error("Response from postInquireProfileSyncCall status code is not success. Status code: {}  ", output.getStatusCode());
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EXTERNAL_SYS_NUM, output.getBody().toString());
                }
            }
        } catch (Exception restClientException) {


            if (restClientException.getCause() instanceof SocketTimeoutException || restClientException.getCause() instanceof ConnectTimeoutException) {
                String stAppInfo = "Timeout in call to OUD.InquireProfile : " + restClientException.getMessage();
                logger.error("{}{}IPRC_01 : Timeout in call to InquireProfile : {}", sClassName, sMethodName, restClientException.getMessage());
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_TRAN_TIME_OUT_NUM, stAppInfo);
            } else if (restClientException instanceof HttpClientErrorException) {
                HttpClientErrorException excp = (HttpClientErrorException) restClientException;

                if (excp.getStatusCode().equals(HttpStatus.BAD_REQUEST) || excp.getStatusCode().equals(HttpStatus.NOT_FOUND)) {
                    hmResult = JsonService.convertToObject(excp.getResponseBodyAsString(), HashMap.class);
                } else {
                    String stAppInfo = "Error from OUD.InquireProfile:" + excp.getMessage();
                    logger.error("{}{}IPRC_02 : Error from OUD.InquireProfile - HttpStatusCode : {}", sClassName, sMethodName, excp.getRawStatusCode());
                    hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EXTERNAL_SYS_NUM, stAppInfo);
                }
            } else {

                logger.error("postInquireProfileSyncCall error found while making the call with Endpoint_url: {}, Request_Entity: {} and Exception is: {}", resourceUri, reqheaders, restClientException.getMessage());
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EXTERNAL_SYS_NUM, restClientException.getMessage());
            }

        }
        return hmResult;

    }

    private HttpHeaders populatingHeader(String traceID, String callingSystemId) {
        HttpHeaders reqheaders = new HttpHeaders();

        reqheaders.setContentType(MediaType.APPLICATION_JSON);
        reqheaders.add("Authorization", "Basic " + Base64.getEncoder().encodeToString((clientid + ":" + clientsecret).getBytes()));
        reqheaders.add("idp-trace-id", traceID);
        reqheaders.add("X-ATT-ClientId", callingSystemId);
        return reqheaders;
    }
}