package com.att.idp.idgraphcontactinfoms.integration;

import com.att.idp.core.exception.ServiceException;
import com.att.idp.idgraphcontactinfoms.message.ErrorMessages;
import com.att.idp.logging.marker.SpiMarker;
import com.att.idp.soap.config.SOAPClientConfigurer;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbc.cc.clarify.api.mps.message.GetAuthInfoResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.soap.client.SoapFaultClientException;
import org.springframework.ws.soap.security.wss4j2.Wss4jSecurityInterceptor;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;
import org.springframework.ws.soap.SoapFaultDetail;
import org.springframework.ws.soap.SoapFaultDetailElement;

import javax.annotation.PostConstruct;
import javax.xml.transform.dom.DOMResult;
import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.RequiredArgsConstructor;

@Service
public class LscrmGetAuthInfoClient<I> extends WebServiceGatewaySupport {

    @Value("${lscrm.securityheader.user}")
    private String lscrmSecurityHeaderUser;

    @Value("${lscrm.securityheader.password}")
    private String lscrmSecurityHeaderPwd;

    @Autowired
    private HttpComponentsMessageSender httpComponentsMessageSender;

    @Autowired
    private SOAPClientConfigurer soapClientConfigurer;

    public static final Logger log = LoggerFactory.getLogger(LscrmGetAuthInfoClient.class);
    private static final String API_NAME = "GetAuthInfo";
    private final String sClassName = "LscrmGetAuthInfoClient";

    @PostConstruct
    public void init() {
        String sMethodName = ".init.";
        log.debug("{}{}LGAC_01 : Invoked for SOAP client configuration", sClassName, sMethodName);
        if (soapClientConfigurer != null) {
            soapClientConfigurer.configure(this, API_NAME);
        }
    }

    /**
     * Invokes the LSCRM GetAuthInfo SOAP API with security interceptors and handles all error scenarios.
     * Ensures proper logging and error mapping for downstream consumers.
     * Guarantees resource cleanup and robust error handling.
     * @param request the request object for the LSCRM API
     * @return a map containing the response or error details
     * @throws ServiceException if a critical error occurs during invocation
     */
    public Map<String, Object> invokeAPI(I request) {
        String sMethodName = ".invokeAPI.";
        WebServiceTemplate webServiceTemplate = getWebServiceTemplate();
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
        Map<String, Object> resphm;
        try {
            Wss4jSecurityInterceptor wss4jSecurityInterceptor = new Wss4jSecurityInterceptor();
            wss4jSecurityInterceptor.setSecurementActions("UsernameToken");
            wss4jSecurityInterceptor.setSecurementUsername(lscrmSecurityHeaderUser);
            wss4jSecurityInterceptor.setSecurementPassword(CommonUtil.getAESDecryption(lscrmSecurityHeaderPwd));
            wss4jSecurityInterceptor.setSecurementPasswordType("PasswordText");

            webServiceTemplate.setInterceptors(new ClientInterceptor[] {wss4jSecurityInterceptor});
            webServiceTemplate.setMessageSender(httpComponentsMessageSender);

            GetAuthInfoResponse response = (GetAuthInfoResponse) webServiceTemplate.marshalSendAndReceive(request);
            resphm = mapper.convertValue(response, Map.class);
            log.info(SpiMarker.getInstance(),"{}{}LGAC_04 : LSCRM response {}", sClassName, sMethodName, resphm);
            HashMap<String, Object> hmStatus = CommonErrorMap.makeCategoryMap(CommonDefs.COMMON_SUCCESS_NUM,"SUCCESS");
            hmStatus.put(CommonDefs.SOAP_RESPONSE, resphm);
            return hmStatus;
        } catch(Exception ex){
            if (ex.getMessage() != null && ex.getMessage().contains("Read timed out")) {
                log.error("{}{}LGAC_05 : ReadTimeOut while calling LSCRMGetAuthInfo API - {}", sClassName,sMethodName, ex.getMessage(),ex);
                throw new ServiceException(ErrorMessages.MS_MPSYS_BE_606);
            }
            else if(ex instanceof SoapFaultClientException) {
                log.error("{}{}LGAC_03 : Soap Fault Exception while calling LSCRM API - {}",  sClassName,
                        sMethodName, ex.getMessage(), ex);
                try {
                    resphm = handleSOAPFault((SoapFaultClientException)ex);
                    return resphm;
                } catch (IOException exp) {
                    ErrorMessages error = null;
                    try {
                        log.error("{}{}LGAC_04 : ERROR from LSCRM API - {}", sClassName,sMethodName, exp.getMessage());
                        error = ErrorMessages.MS_MPSYS_BE_602;
                    } catch (IllegalArgumentException iaex) {
                        error = ErrorMessages.MS_MPSYS_BE_602;
                    }
                    return makeErrorMap(error);
                }
            }
            else {
                log.error("{}{}LGAC_06 : Exception while calling LSCRMGetAuthInfo API - {}", sClassName, sMethodName,
                        ex.getMessage(), ex);
                throw new ServiceException(ErrorMessages.MS_MPSYS_BE_602);
            }
        }
    }

    private HashMap<String, Object> makeErrorMap(ErrorMessages error) {
        HashMap<String, Object> errorMap = new HashMap<>();
        errorMap.put("errorCode", error.toString());
        return errorMap;
    }


    public Map<String, Object> handleSOAPFault(SoapFaultClientException soapFault) throws IOException {
        SoapFaultDetail soapFaultDetail = soapFault.getSoapFault().getFaultDetail();
        HashMap<String, Object> resphm = CommonUtil.getHashMap();
        if (soapFaultDetail !=null && soapFaultDetail.getDetailEntries() != null
                && soapFaultDetail.getDetailEntries().hasNext()) {
            SoapFaultDetailElement detailElementChild = soapFaultDetail.getDetailEntries().next();
            DOMResult node=(DOMResult) detailElementChild.getResult();
            String message = node.getNode().getFirstChild().getFirstChild().getTextContent();
            String errorCode= node.getNode().getFirstChild().getNextSibling().getTextContent();

            if(StringUtils.hasText(message) &&  StringUtils.hasText(errorCode)){
                resphm=CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_EXTERNAL_DATA_NUM, message +":"+ errorCode);
            } else {
                log.error("{}{}LGAC_02 : Error while parsing SOAP Fault Detail - {}", sClassName, ".handleSOAPFault.", soapFault.getMessage());
                throw new ServiceException(ErrorMessages.MS_MPSYS_BE_602);
            }
        } else {
            throw new ServiceException(ErrorMessages.MS_MPSYS_BE_602);
        }
        return resphm;
    }
}
