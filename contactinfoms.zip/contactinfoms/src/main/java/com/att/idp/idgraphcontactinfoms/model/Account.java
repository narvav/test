package com.att.idp.idgraphcontactinfoms.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * The class Account
 *
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "id",
        "state",
        "serviceType",
        "accountType",
        "accountSubType",
        "createdOn",
        "givenName",
        "familyName",
        "billingMarket",
        "languagePreference",
        "contacts",
        "subscribers"
})
@Schema(name = "Account")
public class Account implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    @JsonProperty("id")
    private String id;

    /** The state. */
    @JsonProperty("state")
    private String state;

    /** The accountType. */
    @JsonProperty("serviceType")
    private String serviceType;

    /** The accountType. */
    @JsonProperty("accountType")
    private String accountType;

    /** The accountSubType. */
    @JsonProperty("accountSubType")
    private String accountSubType;

    /** The createdOn. */
    @JsonProperty("createdOn")
    private String createdOn;

    /** The givenName. */
    @JsonProperty("givenName")
    private String givenName;

    /** The familyName. */
    @JsonProperty("familyName")
    private String familyName;

    /** The billingMarket. */
    @JsonProperty("billingMarket")
    private String billingMarket;

    /** The languagePreference. */
    @JsonProperty("languagePreference")
    private String languagePreference;

    @JsonProperty("targetSOR")
    private String targetSOR;

    /** The list of contact. */
    @JsonProperty("contacts")
    private List<Contact> contacts = null;

    /** The list of subscribers. */
    @JsonProperty("subscribers")
    private List<Subscribers> subscribers = null;
}
