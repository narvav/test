package com.att.idp.idgraphcontactinfoms.resource.request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Schema(name = "InquirePINRequest")
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class InquirePINRequest {

	protected final String transactionName = "InquirePIN";

	@Size(min = 1, max = 20, message =  "CallingSystemId length is invalid|InquirePIN")
	protected String callingSystemId;

	@Schema(name = "accountId")
	@NotNull(message = "AccountId is required field in input request.|InquirePIN")
	@Size(min = 1, max = 60, message =  "AccountId length is invalid|InquirePIN")
	protected String accountId;

	@Schema(name = "identificationType")
	@NotNull(message = "IdentificationType is required field in input request.|InquirePIN")
	@Size(min = 1, max = 10, message =  "IdentificationType length is invalid|InquirePIN")
	protected String identificationType;

	protected String isExternalCall;

	@Schema(name = "idpTraceId")
	private String idpTraceId;

	@JsonAnySetter
	@JsonAnyGetter
	public Map<String, Object> unknownAttributes = new HashMap<>();
}