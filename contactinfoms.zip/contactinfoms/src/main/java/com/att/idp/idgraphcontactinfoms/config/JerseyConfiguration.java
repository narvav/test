package com.att.idp.idgraphcontactinfoms.config;

import java.util.logging.Logger;

import jakarta.ws.rs.ApplicationPath;

import com.att.idp.idgraphcontactinfoms.resource.impl.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.azure.spring.cloud.appconfiguration.config.AppConfigurationRefresh;

import com.att.idp.core.config.BaseJerseyConfiguration; // Seed 2.4.0, 'idp-config' new repository in CodeCloud
import com.att.idp.idgraphcontactinfoms.exceptions.InvalidInputDataExceptionMapper;
import com.att.idp.idgraphcontactinfoms.exceptions.MPSExceptionMapper;
import com.att.idp.idgraphcontactinfoms.exceptions.ValidationExceptionMapper;
import com.att.idp.shutdown.jersey.adapter.JerseyShutdownAdapter; // Seed 2.5.0, Jersey default shutdown behavior
import com.att.idp.shutdown.jersey.filter.AfterResourceResponseFilter;
import com.att.idp.shutdown.jersey.filter.BeforeResourceRequestFilter;

/**
 * This Class reads and sets all configuration related to Jersey
 * 
 * 
 */
@Component
@ApplicationPath("/idgraphcontactinfoms/v1")
public class JerseyConfiguration extends BaseJerseyConfiguration {

	
	/*Please do not edit or remove the LOGGER_NAME name declaration as it is critical
	*to have this identifier for server side logging
	*/	
	public final static String LOGGER_NAME="com.att.idp.logging.server.JerseyLogging";
	private static final Logger eelfLogger = Logger.getLogger(LOGGER_NAME);

    /**
	 * This is the main constructor which register the Jersey configs
	 * 
	 * @param pJerseyShutdownAdapter
	 *            - added in Seed 2.5.0, will be autowired with
	 *            JerseyShutdownAdapter started by idp-shutdown-jersey module
	 */
	@Autowired
    public JerseyConfiguration(
            @Autowired JerseyShutdownAdapter pJerseyShutdownAdapter,
            @Autowired AppConfigurationRefresh appConfigurationRefresh) {
		super();
		eelfLogger.info(" JERSEY CONFIGURATION ");
		register(new BeforeResourceRequestFilter(pJerseyShutdownAdapter));
		register(new AfterResourceResponseFilter(pJerseyShutdownAdapter));
		register(HelloWorldResourceImpl.class);
		register(SecurityPINResourceImpl.class);
		register(CGRestClientResourceImpl.class);
		register(ValidationExceptionMapper.class);
		register(CPNIContactInfoResourceImpl.class);
		register(MPSExceptionMapper.class);
		register(InvalidInputDataExceptionMapper.class);
	}
}