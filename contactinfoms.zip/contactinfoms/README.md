# IDGraphContactInfoMs — Contact Information & Security PIN Microservice

| Field | Value |
|---|---|
| **Domain / Team** | `IDGraph / LEGOS Platform Team` |
| **Artifact ID** | `IDGraphContactInfoMs` |
| **Version** | `0.0.1-SNAPSHOT` |
| **Component Type** | `REST (JAX-RS) + SOAP + Kafka + JMS` |
| **Runtime / Parent** | `sdk-java-parent 3.0.1` |
| **Language / Java Version** | `Java 17` |
| **Base Path / Entry Point** | `/idgraphcontactinfoms/v1` |
| **API / Contract Docs** | Swagger UI — `/idgraphcontactinfoms/swagger-ui.html` · OpenAPI JSON — `target/classes/META-INF/resources/idgraphcontactinfoms/swagger/swagger.json` |
| **MOTS ID** | `33944` |
| **Kubernetes Namespace** | `com-att-idp-idgraph` |

## Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Project Structure](#project-structure)
4. [Domain Capability Map](#domain-capability-map)
5. [Integration Context](#integration-context)
6. [Process Flows](#process-flows)
7. [Interfaces & Endpoints](#interfaces--endpoints)
8. [Data Stores & State Management](#data-stores--state-management)
9. [Configuration](#configuration)
10. [Dependencies](#dependencies)
11. [Observability and Operations](#observability-and-operations)
12. [Security and Compliance](#security-and-compliance)
13. [Build and Test](#build-and-test)
14. [Deployment](#deployment)
15. [Change Log / History](#change-log--history)

---

## Overview

**IDGraphContactInfoMs** is an IDGraph platform microservice responsible for **managing customer contact information and security PIN (OTP) lifecycle operations**. It acts as the central service for CPNI-compliant contact data queries and one-time passcode management, handling:

- **CPNI Contact Info Queries**: Account-level and user-level queries with 30-day CPNI eligibility enforcement and configurable bypass logic
- **Security PIN (OTP) Lifecycle**: Generate, Validate, Delete, and Inquire operations backed by Oracle DB and Cosmos DB, with configurable expiration, max-PIN limits, and account lockout
- **SIM Swap Protection**: CG API integration during ValidatePIN to enforce aging periods before SMS-delivered PINs are accepted after a SIM swap
- **Notification Delivery**: PINs delivered via CLM synchronous calls (SMS/email/letter) or asynchronous DBUS calls depending on identification type
- **Kafka Event Publishing**: Publishes `GenericOTPNotification` events to primary/secondary Kafka clusters with retry and failover
- **LSCRM SOAP Integration**: Calls LSCRM GetAuthInfo SOAP API for authentication data retrieval
- **Dynamic Configuration**: Azure App Configuration with runtime refresh of timeouts, pool sizes, and feature flags
- **Observability**: `@TimedMetrics` histograms (75th/90th/95th/99th percentile), HikariCP pool metrics, and OpenTelemetry distributed tracing

This component uses JAX-RS (Jersey) REST APIs, Spring WS SOAP clients, Spring Kafka producers, IBM MQ JMS messaging, Spring Data JPA (Oracle), Spring Data Cassandra, and Azure App Configuration.

---

## Architecture

```mermaid
graph TD
    subgraph EntryPoints["Entry Points"]
        Client["Calling Systems"]
    end

    subgraph IDGraphContactInfoMs["IDGraphContactInfoMs"]
        subgraph Interface_Layer["Resource Layer (JAX-RS)"]
            CPNI["CPNIContactInfoResource"]
            PIN["SecurityPINResource"]
            CGR["CGRestClientResource"]
            SEC["GetSecurityCodeData"]
            MET["HikariCPResource"]
        end

        subgraph Validation["Validator Layer"]
            VAL["Request Validators (7)"]
        end

        subgraph Core_Layer["Service + Helper Layer"]
            SVC["Service Impls (8)"]
            HLP["Business Helpers (24)"]
        end

        subgraph Data_Layer["Data Access Layer"]
            DBH["DBHelper / SecurityCodeDBHelper"]
            CDB["ContactDBHelper"]
            COS["CosmosDataStore"]
            CASS["ValidatePinAuthInfoRepository"]
        end
    end

    subgraph Dependencies["External Dependencies"]
        OracleDB[("Oracle DB")]
        CosmosDB[("Cosmos DB")]
        CassandraDB[("Cassandra")]
        CG["Customer Graph API"]
        CLM["CLM / MuleSoft"]
        LSCRM["LSCRM SOAP"]
        Kafka["Kafka (GenericOTP)"]
        MQ["IBM MQ (DBUS)"]
        AzureAppConfig["Azure App Config"]
        Voltage["Voltage Encrypt/Decrypt"]
    end

    Client --> Interface_Layer
    Interface_Layer --> Validation --> Core_Layer --> Data_Layer
    Data_Layer --> OracleDB & CosmosDB & CassandraDB
    Core_Layer --> CG & CLM & LSCRM & Kafka & MQ
    IDGraphContactInfoMs --> AzureAppConfig & Voltage
```

**Key architectural patterns:**
- **Layered architecture**: Resource → Validator → Service → Helper → DB/Integration
- **JAX-RS interface + implementation split**: Interfaces define contracts with OpenAPI 3 annotations; `*Impl` classes implement business routing
- **Dual Kafka cluster failover**: Primary/secondary producers with `@Retryable` + `@Recover`
- **Azure App Config refresh**: `@RefreshScope` beans with `RefreshScopeRefreshedEvent` listeners for dynamic timeout/pool updates
- **CommonErrorMap contract**: All error responses use `CommonErrorMap.makeCategoryMap()` with `CErrorDefs` error codes

---

## Project Structure

```text
apm0045194-idgraph-idgraphcontactinfoms/
├── src/
│   ├── main/
│   │   ├── java/com/att/idp/idgraphcontactinfoms/
│   │   │   ├── Application.java                    # Spring Boot entry point
│   │   │   ├── appconfig/config/                   # Azure App Config (IDGraphAzureAppConfig)
│   │   │   ├── cassandra/                          # Cassandra entities + repositories
│   │   │   ├── cgclient/response/                  # CG API response models
│   │   │   ├── config/                             # Spring configuration beans
│   │   │   │   ├── JerseyConfiguration.java        # JAX-RS resource registration
│   │   │   │   ├── DataBaseConfiguration.java      # Oracle XADataSource + JPA
│   │   │   │   ├── JMSConfiguration.java           # IBM MQ connection factory
│   │   │   │   └── LSCRMSoapConfig.java            # LSCRM SOAP client config
│   │   │   ├── db/                                 # DB helpers, models, repositories
│   │   │   ├── exceptions/                         # Custom exceptions + mappers
│   │   │   ├── healthcheck/                        # DatabaseHealthIndicator (Actuator)
│   │   │   ├── helpers/                            # Business logic helpers (30 classes)
│   │   │   ├── integration/                        # Outbound REST/SOAP clients
│   │   │   │   ├── InquireProfileRestClient.java   # OUD InquireProfile REST
│   │   │   │   ├── MuleSoftRestClient.java         # CLM MuleSoft REST
│   │   │   │   ├── LscrmGetAuthInfoClient.java     # LSCRM GetAuthInfo SOAP
│   │   │   │   └── OutboundRestClientBuilder.java  # RestTemplate factory
│   │   │   ├── kafka/                              # Kafka producers + configs
│   │   │   │   ├── GenericOTPPublisher.java         # Primary/secondary with failover
│   │   │   │   └── config/                          # Producer configs (primary + secondary)
│   │   │   ├── message/                            # Error/log message enums
│   │   │   ├── metrics/                            # Custom metrics beans
│   │   │   ├── model/                              # Domain models
│   │   │   ├── queue/message/sender/               # JMSQueueSender (DBUS)
│   │   │   ├── request/validator/                  # Request validators (7 classes)
│   │   │   ├── resource/                           # JAX-RS interfaces (6)
│   │   │   │   └── impl/                           # JAX-RS implementations
│   │   │   ├── service/                            # Service interfaces + impls
│   │   │   └── utils/                              # Constants, JsonService, CommonUtilHelper
│   │   ├── resources/
│   │   │   ├── application.properties              # Spring config baseline
│   │   │   ├── errormessages.properties            # Error message definitions
│   │   │   ├── logmessages.properties              # Log message definitions
│   │   │   ├── banner.txt                          # Startup banner
│   │   │   └── schemas/lscrm/                      # LSCRM WSDL/XSD schemas
│   │   ├── docker/                                 # Dockerfile assets
│   │   └── jenkins/                                # Jenkins helper scripts
│   └── test/                                       # Spock/Groovy + JUnit tests
├── opt/ajsc/etc/config/                            # Runtime config (contactInfo.properties)
├── docs/                                           # Execution plans + documentation
├── voltageKeyCache/                                # Voltage encryption key cache
├── voltageTrustStore/                              # Voltage trust store
├── Jenkinsfile                                     # CI/CD pipeline definition
├── pom.xml                                         # Maven build descriptor
├── idpsecretsloader.yaml                           # Key Vault secret mappings
├── CODEOWNERS                                      # Code ownership rules
└── sum_junit_tests.sh                              # Test summary aggregation
```

---

## Domain Capability Map

| Capability | Description | Key Classes |
|---|---|---|
| **CPNI Contact Info** | Account/user-level contact queries with 30-day eligibility | `CPNIContactInfoResource`, `QueryCPNIAcccountContactHelper`, `CPNIEligibilityHelper` |
| **Security PIN Generate** | OTP generation with CLM/DBUS delivery and Kafka eventing | `SecurityPINResource`, `GeneratePINHelper`, `GeneratePINBase` |
| **Security PIN Validate** | PIN validation with SIM swap check and account lockout | `ValidatePINHelper`, `CGHelper` |
| **Security PIN Delete** | Delete individual or all PINs from Oracle + Cosmos | `DeletePINHelper` |
| **Security PIN Inquire** | Query active PINs for an account | `InquirePINHelper` |
| **CG API Proxy** | Synchronous CG REST call wrapper | `CGRestClientResource`, `CGHelper` |
| **LSCRM Auth Info** | SOAP call to LSCRM GetAuthInfo | `LscrmGetAuthInfoClient`, `LSCRMHelper` |
| **MuleSoft CLM** | REST notification to CLM via MuleSoft | `MuleSoftRestClient` |
| **Generic OTP Events** | Kafka publish to primary/secondary clusters | `GenericOTPPublisher` |
| **DBUS Notifications** | JMS queue messaging to DBUS | `JMSQueueSender` |

---

## Integration Context

| System | Protocol | Direction | Client Class | Config Refresh |
|---|---|---|---|---|
| **Oracle DB** | JDBC (XADataSource) | Read/Write | `DataBaseConfiguration` | `dataSourceRefreshEnabled` |
| **Cosmos DB** | Spring Data | Read/Write | `CosmosDataStore` | — |
| **Cassandra** | Spring Data Cassandra | Read/Write | `ValidatePinAuthInfoRepository` | — |
| **Customer Graph API** | REST GET | Outbound | `CGHelper` | `cgRestClientRefreshEnabled` |
| **OUD InquireProfile** | REST POST | Outbound | `InquireProfileRestClient` | `inquireRestClientRefreshEnabled` |
| **MuleSoft CLM** | REST POST | Outbound | `MuleSoftRestClient` | `ccmulesoftRestClientRefreshEnabled` |
| **LSCRM GetAuthInfo** | SOAP | Outbound | `LscrmGetAuthInfoClient` | `lscrmSoapHttpClientRefreshEnabled` |
| **Kafka (GenericOTP)** | Kafka Producer | Outbound | `GenericOTPPublisher` | — |
| **IBM MQ (DBUS)** | JMS | Outbound | `JMSQueueSender` | `mqconnectRefreshEnabled` |
| **Azure App Config** | Spring Cloud Azure | Inbound | `IDGraphAzureAppConfig` | Always (polling) |
| **Voltage** | Library | Local | `EncryptUtil` / `DecryptUtil` | — |

**RestTemplate management**: `OutboundRestClientBuilder` constructs `RestTemplate` instances with configurable connect/read timeouts. Each outbound REST client listens on `RefreshScopeRefreshedEvent` to dynamically update timeouts from Azure App Config.

---

## Process Flows

### CPNI Contact Info Query

```mermaid
sequenceDiagram
    participant C as Calling System
    participant R as CPNIContactInfoResourceImpl
    participant V as RequestValidator
    participant S as QueryCPNIAcctContactInfoSvcImpl
    participant H as QueryCPNIAcccountContactHelper
    participant E as CPNIEligibilityHelper
    participant D as DBHelper

    C->>R: POST /cpniContactInfo/account
    R->>V: Validate X-ATT-ClientId + body
    V-->>R: OK / Error 400
    R->>S: queryCPNIAccountContactInfo()
    S->>H: getContactInfo(inputMap)
    H->>D: Query account + contact records
    D-->>H: Raw contact data
    H->>E: Check CPNI eligibility (30-day rule)
    E-->>H: Eligible / Not eligible
    H-->>S: Filtered result map
    S-->>R: QueryCPNIAccountContactInfoResponse
    R-->>C: HTTP 200 JSON
```

**Business rules:** Contact info established < 30 days ago is CPNI-ineligible unless `callingSystemId` is in `BYPASS_CPNI_ELIGIBILITY_CSI`.

> **Code Reference**: `CPNIContactInfoResourceImpl.queryCPNIAccountContactInfo()` → `QueryCPNIAccountContactInfoServiceImpl` → `QueryCPNIAcccountContactHelper` → `CPNIEligibilityHelper`

### Security PIN Generate

```mermaid
sequenceDiagram
    participant C as Calling System
    participant R as SecurityPINResourceImpl
    participant V as GeneratePINRequestValidator
    participant S as GeneratePINServiceImpl
    participant H as GeneratePINHelper
    participant B as GeneratePINBase
    participant D as SecurityCodeDBHelper
    participant CO as CosmosDataStore
    participant CLM as CLM / MuleSoft
    participant K as Kafka

    C->>R: POST /pin/generate
    R->>V: Validate CSI + agent + delivery
    V-->>R: OK / Error
    R->>S: generatePIN(request, headers)
    S->>H: generatePin(inputMap)
    H->>B: processInputData()
    B->>D: storeMPSData()
    B->>CO: Store PIN in Cosmos
    B->>CLM: makeCCMuleSyncCall()
    B->>K: Publish GenericOTPNotification
    H-->>S: Result (securityCode + expiry)
    S-->>R: GeneratePINResponse
    R-->>C: HTTP 200 JSON
```

**Business rules:**
- CSI authorization matrix (`PROP_PIN_CSI`) controls which systems can generate PINs for which identification types
- Agent CSIs (`PROP_PIN_AGENT_CSI`) require `agentId` and `deliveryMethods`
- PIN length, expiration, and max active count are configurable per identification type
- SMS delivery overrides expiration to 10 min unless type is in `PROP_PIN_EXCLUDE_EXPIRY_TIME_OVERWRITE_IDTYPE`

> **Code Reference**: `SecurityPINResourceImpl.generatePIN()` → `GeneratePINServiceImpl` → `GeneratePINHelper` → `GeneratePINBase`

### Security PIN Validate (with SIM Swap Check)

```mermaid
sequenceDiagram
    participant C as Calling System
    participant R as SecurityPINResourceImpl
    participant S as ValidatePINServiceImpl
    participant H as ValidatePINHelper
    participant D as SecurityCodeDBHelper
    participant CG as CGHelper / CG API
    participant CO as CosmosDataStore
    participant CA as Cassandra

    C->>R: POST /pin/validate
    R->>S: validatePIN(request, headers)
    S->>H: validatePIN(inputMap)
    H->>D: Query security code records
    H->>H: Check lockout + unlock period + code match
    alt SIM check required
        H->>CG: makeCGSyncCall(CTN, topics)
        CG-->>H: simSwapDate + accountCreatedOn
        H->>H: checkAging()
    end
    H->>D: Update status
    opt Cosmos update
        H->>CO: Update validation status
    end
    opt Cassandra tracking
        H->>CA: Persist ValidatePinAuthInfo
    end
    H-->>S: ValidatePIN result
    S-->>R: ValidatePINResponse
    R-->>C: HTTP 200 JSON
```

> **Code Reference**: `SecurityPINResourceImpl.validatePIN()` → `ValidatePINServiceImpl` → `ValidatePINHelper` → `CGHelper.makeCGSyncCall()`
>
> Full SIM swap logic details: [`docs/SIM_SWAP_LOGIC_WIKI.md`](docs/SIM_SWAP_LOGIC_WIKI.md)

---

## Interfaces & Endpoints

All endpoints are served under base path `/msapi/idgraphcontactinfoms/v1`. **Required header**: `X-ATT-ClientId`.

### CPNI Contact Info (`/cpniContactInfo`)

| Method | Path | Request DTO | Response DTO |
|---|---|---|---|
| `POST` | `/cpniContactInfo/account` | `QueryCPNIAccountContactInfoRequest` | `QueryCPNIAccountContactInfoResponse` |
| `POST` | `/cpniContactInfo/user` | `QueryCPNIUserContactInfoRequest` | `QueryCPNIUserContactInfoResponse` |
| `GET` | `/cpniContactInfo` | Headers only | `CPNIContactInfoResponse` |

### Security PIN (`/pin`)

| Method | Path | Request DTO | Response DTO |
|---|---|---|---|
| `POST` | `/pin/generate` | `GeneratePINRequest` | `GeneratePINResponse` |
| `POST` | `/pin/validate` | `ValidatePINRequest` | `ValidatePINResponse` |
| `POST` | `/pin/delete` | `DeletePINRequest` | `DeletePinResponse` |
| `POST` | `/pin/inquire` | `InquirePINRequest` | `InquirePINResponse` |

### Utility Endpoints

| Method | Path | Description |
|---|---|---|
| `GET` | `/cgRestClient/cgSyncCall` | CG API proxy (headers: `accountId`, `subscriberNumber`, `serviceType`, `topics`) |
| `GET` | `/getSecurityCode/getSecurityCodeDataQuery` | Query security code data |
| `GET` | `/metrics/getMetrics` | HikariCP pool metrics |
| `GET` | `/metrics/softEvictDBPool` | Soft-evict idle DB connections |
| `POST` | `/helloworld/getHelloWorld` | Liveness / smoke test |

### Common Response Contract

All responses include: `appStatusCode` (`0` = success), `appStatusMsg`, `transactionId`, `idp-trace-id`. Error responses use `CommonErrorMap.makeCategoryMap()` with `CErrorDefs` codes.

### Downstream Service Integrations

| # | Dependency | Protocol | Backend Resource Endpoint URL | Purpose | Code Reference |
|---|---|---|---|---|---|
| 1 | Customer Graph API | REST GET | `/msapi/customerms/v4/customer/accounts` | Account/subscriber data, SIM swap dates | `CGHelper.makeCGSyncCall()` |
| 2 | OUD InquireProfile | REST POST | `/msapi/profilems/v2/profiles` | Profile queries for contact info | `InquireProfileRestClient.postInquireProfileSyncCall()` |
| 3 | MuleSoft CLM | REST POST | `/api/idp/mps/otpEventNotification/v1/event` | Synchronous notification delivery (SMS/email/letter) | `MuleSoftRestClient.getNotificationSyncCall()` |
| 4 | LSCRM GetAuthInfo | SOAP | `/mps/getAuthInfo` | Authentication data retrieval (WS-Security) | `LscrmGetAuthInfoClient.callLscrmGetAuthInfoService()` |

---

## Data Stores & State Management

### Oracle DB (Primary)

- **Connection**: `XADataSource` via `DataBaseConfiguration` with dynamic pool refresh
- **ORM**: Spring Data JPA + Hibernate (`@EnableJpaRepositories`)
- **Key helpers**: `DBHelper`, `SecurityCodeDBHelper`, `ContactDBHelper`, `InquireUserContactInfoDBHelper`
- **Entities**: `Taccountinfo`, `Tcontact`, `Taccountlockout`, `Taccountautoreg`, `Tdsluser`, `Tdomain`, `Tcategory`, `Tdynnotifications`, `Tdynservicesor`
- **Pool metrics**: Exposed via `HikariCPResource` (`/metrics/getMetrics`)

### Cosmos DB

- **Purpose**: PIN status storage and updates (hybrid Oracle/Cosmos tracking)
- **Client**: `CosmosDataStore`

### Cassandra

- **Purpose**: PIN validation auth info persistence
- **Repository**: `ValidatePinAuthInfoRepository` (`CassandraRepository<ValidatePinAuthInfo, SessionId>`)
- **Entity**: `ValidatePinAuthInfo` with composite key `SessionId`

---

## Configuration

Configuration is externalized across three layers:

| Layer | File | Purpose |
|---|---|---|
| **Application baseline** | `src/main/resources/application.properties` | Spring Boot defaults, component scanning |
| **Runtime overrides** | `opt/ajsc/etc/config/contactInfo.properties` | Business rules, CSI matrices, feature flags |
| **Helm deployment** | `apm0045194-idgraph-idgraphcontactinfoms-helm/configs/` | Environment-specific overrides |

### Azure App Configuration (`IDGraphAzureAppConfig`)

Centralized runtime config with `@RefreshScope`. All properties support dynamic refresh via `RefreshScopeRefreshedEvent`.

| Property Pattern | Purpose | Default |
|---|---|---|
| `appconfig.tomcat.jdbc.pool.*` | DB pool sizing (maxSize, minSize, initialSize, queryTimeout) | Varies |
| `appconfig.apiclient.rest.*.connectTimeout` | Outbound REST connect timeout (ms) | `30000` |
| `appconfig.apiclient.rest.*.readTimeout` | Outbound REST read timeout (ms) | `10000` |
| `appconfig.lscrm.*` | LSCRM SOAP timeouts | `10000` |
| `appconfig.mq.reconnect.timeout.sec` | MQ reconnect timeout | `10` |
| `appconfig.*.refreshEnabled` | Per-component dynamic refresh toggle | `false` |

### Key Business Properties (`contactInfo.properties`)

| Property | Purpose |
|---|---|
| `PROP_PIN_CSI` | CSI authorization matrix for PIN operations |
| `PROP_PIN_AGENT_CSI` | CSIs requiring `agentId` + `deliveryMethods` |
| `PROP_PIN_MAX_PINS` | Max active PINs per identification type |
| `PROP_PIN_LENGTH` | PIN code length per type |
| `PROP_PIN_EXPIRATION_MINUTES` | PIN expiry per type |
| `PROP_PIN_SIM_CHECK` | Types requiring SIM swap check |
| `PROP_PIN_SIM_ACTIVE_DAYS` | Minimum SIM swap aging days |
| `BYPASS_CPNI_ELIGIBILITY_CSI` | CPNI 30-day bypass CSIs |
| `PROP_AEHGENERICOTP_IDENTIFICATION_TYPES` | Types triggering Kafka GenericOTP publish |
| `PROP_CCMULE_IDENTIFICATION_TYPES` | Types using CLM sync delivery |

> Full property documentation: [`docs/CONTACTINFO_PROPERTIES_DOCUMENTATION.md`](docs/CONTACTINFO_PROPERTIES_DOCUMENTATION.md)

### Feature Flags

All flags prefixed with `svc-idgraph-` in Azure App Configuration:

| Flag | Effect |
|---|---|
| `generate-pin-disable-max-count` | Disable max-PIN enforcement |
| `simswap-newlogic` | Priority-based SIM swap logic |
| `simswap-use-startdate` | Use startDate fallback for SIM check |
| `cpnicontactinfo-enable-individualid` | Enable individual ID in CPNI queries |

---

## Dependencies

### Core Framework

| Library | Version | Purpose |
|---|---|---|
| Spring Boot | `sdk-java-parent 3.0.1` | Application framework |
| Spring Data JPA | 3.5.5 | Oracle ORM layer |
| Spring Data Cassandra | (managed) | Cassandra data access |
| Spring Cloud Azure | 5.23.0 | Azure App Configuration |
| Spring Kafka | (managed) | Kafka producer |
| Spring JMS | (managed) | IBM MQ JMS messaging |
| Spring WS Security | (managed) | SOAP WS-Security |
| Spring Retry | (managed) | `@Retryable` / `@Recover` |

### REST, SOAP & API

| Library | Version | Purpose |
|---|---|---|
| JAX-RS / Jersey | (managed) | REST API layer |
| SpringDoc OpenAPI | 2.6.0 | Swagger UI |
| OkHttp | 4.12.0 | HTTP client |

### Data & Messaging

| Library | Version | Purpose |
|---|---|---|
| Oracle JDBC (ojdbc8) | 19.8.0.0 | Oracle driver |
| Cassandra Driver | 3.7.1 | Cassandra client |
| Kafka Clients | 3.9.1 | Kafka producer |
| IBM MQ Jakarta | 9.4.2.1 | JMS / DBUS |

### IDGraph Shared Libraries

| Library | Version   | Purpose |
|---|-----------|---|
| `CGClientHelpers` | 3.0.2     | CG API client |
| `IDGraphCommonHelper` | 3.0.8     | CommonErrorMap, CommonUtil, CErrorDefs |
| `idgraphdbhelper` | 3.3.4     | Database helper utilities |
| `idgrapheventshelper` | 4.0.1     | Event publishing |
| `idp-cd-observability` | 3.0.1     | `@TimedMetrics` annotation |
| `idp-logging-core` | 2.9.101   | Structured logging + `SpiMarker` |
| `idp-voltage-*` | (managed) | Voltage encrypt/decrypt |
| `idp-shutdown-*` | (managed) | Graceful shutdown (Jersey adapter) |

### Testing

| Library | Version | Purpose |
|---|---|---|
| Spock Framework | 2.3 | BDD test framework |
| Groovy | 4.0.21 / 3.0.15 | Test scripting |
| Spring Kafka Test | (managed) | Kafka testing |
| JaCoCo | (managed) | Code coverage |

---

## Observability and Operations

### Metrics

| Metric Name | Type | Description |
|---|---|---|
| `IDGRAPH_CONTACT_INFO_MS_IB` | Histogram | Inbound request latency (75/90/95/99th pct) |
| `IDGRAPH_CONTACT_INFO_MS_OB` | Histogram | Outbound call latency (75/90/95/99th pct) |
| HikariCP pool active / idle | Gauge | DB connection pool health |

Metrics are exposed via `@TimedMetrics` annotations (`idp-cd-observability`) and the `/metrics/getMetrics` endpoint.

### Distributed Tracing

- **OpenTelemetry**: `opentelemetry-api`, `opentelemetry-sdk`, `opentelemetry-context`
- **Correlation**: `idp-trace-id` propagated via MDC and HTTP headers

### Logging

- **Framework**: `idp-logging-core` with `SpiMarker` for structured log correlation
- **Inbound**: `api-inbound-logging-interceptor` for request/response logging
- **Log sanitization**: ESAPI-based sanitization of external values (IDGraph HS-3)

### Health Checks

- **`DatabaseHealthIndicator`**: Periodic Oracle health check via `@Scheduled` with configurable interval (`management.endpoint.health.db.indicator.scheduler-duration`)
- **Override flag**: `management.endpoint.health.indicator.override` skips health checks when `true`

---

## Security and Compliance

### Secret Management

Secrets are loaded from Azure Key Vault via `idpsecretsloader.yaml`:

| Secret | Purpose |
|---|---|
| `idgraph-aes256key` | AES-256 encryption key for DB password decryption |
| `idgraph-spring-datasource-password` | Oracle DB password |
| `idgraph-spring-data-cassandra-password` | Cassandra password |
| `idgraph-lscrm-*` | LSCRM SOAP credentials |
| `idgraph-bds-password` | BDS service password |
| `idgraph-idg-write-kafka-jaas-sharedaccesskey` | Kafka JAAS shared access key |
| `idgraph-genericotp-pub-jaas-sharedaccesskey` | GenericOTP primary Kafka key |
| `idgraph-genericotp-pubsec-jaas-sharedaccesskey` | GenericOTP secondary Kafka key |
| `idgraph-ccmule-clientid` / `clientsecret` | MuleSoft CLM credentials |
| `idgraph-azure-appconfig-connection-string` | Azure App Config connection |

### Encryption

- **Voltage**: `EncryptUtil` / `DecryptUtil` for PII/SPI data protection
- **AES-256**: DB password decryption via `CommonUtilHelper.getAESDecryption()`
- **WS-Security**: LSCRM SOAP calls use `Wss4jSecurityInterceptor` (UsernameToken)

### Input Validation

- **Request validators** (7 classes) enforce header presence, field constraints, and CSI authorization
- **Exception mappers**: `InvalidInputDataExceptionMapper`, `MPSExceptionMapper`, `ValidationExceptionMapper`
- **ESAPI sanitization**: All external input values sanitized before logging

---

## Build and Test

### Prerequisites

- **Java 17+** (per `sdk-java-parent 3.0.1`)
- **Maven 3.8+**
- Access to AT&T internal Maven repositories

### Build

```bash
mvn clean install
```

### Run Unit Tests

```bash
mvn test
```

Tests use **Spock Framework** (Groovy) with patterns: `*Test.java`, `*Tests.java`, `*Spec.java`, `*Test.groovy`, `*Spec.groovy`. Integration/contract tests excluded from unit runs.

### Run Integration Tests

```bash
mvn verify -P integration-test
```

### Run Locally

```bash
mvn clean install
java -jar target/IDGraphContactInfoMs.jar
```

### Test Aggregation

```bash
./sum_junit_tests.sh
```

### Code Coverage

JaCoCo configured with exclusions for models, configs, DTOs, and utility classes:

```bash
mvn verify
# Report: target/site/jacoco/index.html
```

---

## Deployment

### CI/CD Pipeline

Defined in `Jenkinsfile` using `idp-shared-library@release/3.0.0`:

| Parameter | Value |
|---|---|
| **MOTS ID** | `33944` |
| **Repo Project** | `ST_IDGRAPH` |
| **Veracode Profile** | `33944-IDGraph-IDGraphContactInfoMs` |
| **Default Cluster** | `Graph1EUS2-dev2` |
| **Default Namespace** | `com-att-idp-idgraph-dev2` |
| **Skipped QGs** | QG4.1, QG4.2, QG7 |
| **GitHub Migrated** | `true` |

Pipeline stages: Build → Unit Tests → SonarQube → Veracode SAST → Docker Image → Helm Deploy.

### Related Repositories

| Repository | Purpose |
|---|---|
| `apm0045194-idgraph-idgraphcontactinfoms-helm` | Helm charts, configs, and environment values |
| `apm0045194-idgraph-cgclienthelpers` | CG API client library |
| `apm0045194-idgraph-idgraphcommonhelper` | CommonErrorMap, CommonUtil, CErrorDefs |
| `apm0045194-idgraph-idgraphdbhelper` | Database helper library |
| `apm0045194-idgraph-idgrapheventshelper` | Event publishing library |
| `apm0045194-idgraph-idgraphextclienthelpers` | External client helpers |

### Swagger UI (per environment)

```
https://apporigin-{ENV}-idpgraph-e2.az.3pc.att.com:8443/msapi/idgraphcontactinfoms/swagger-ui/index.html
```

Replace `{ENV}` with target environment (e.g., `dev2`, `tst2`).

### Additional Documentation

- **[Properties Documentation](docs/CONTACTINFO_PROPERTIES_DOCUMENTATION.md)** — All configuration properties in `contactInfo.properties` with code flow, business logic, and class mappings
- **[SIM Swap Logic Wiki](docs/SIM_SWAP_LOGIC_WIKI.md)** — Detailed SIM swap validation logic with sequence diagrams, feature flags, error codes, and data models

---

## Change Log / History

| Version | Date | Author | Summary |
|---|---|---|---|
| 5.0.0 | 2026-04-02 | IDGraph Team | OMNI plan-readme workflow — verified project tree, fixed dependency versions, added code reference callouts, downstream endpoint URLs |
| 4.0.0 | 2026-03-21 | IDGraph Team | OMNI-compliant README rewrite |
| 3.0.0 | 2026-03-20 | IDGraph Team | Recreated for constitution compliance |
| 2.0.0 | 2025-02-28 | IDGraph Team | Full API docs, diagrams, schemas |
| 1.0.0 | — | IDGraph Team | Initial README |

---

*Internal AT&T use only. This repo uses Seed v3.0.0.*
