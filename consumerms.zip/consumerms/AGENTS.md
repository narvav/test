# AGENTS.md — IDGraphConsumerMs

> AI agent coding guidelines for `apm0045194-idgraph-idgraphconsumerms`.
> Last updated: 2026-08-03

| Field | Value |
|---|---|
| **Repository** | `ATT-DP1/apm0045194-idgraph-idgraphconsumerms` |
| **Service** | IDGraphConsumerMs (`idgraphconsumerms`, `0.0.2-SNAPSHOT`) |
| **Domain** | IDGraph / Identity Platform (APM apm0045194) |
| **SDK / Parent** | `com.att.idp:sdk-java-parent:3.0.1` (Java 17, Spring Boot 3.x) |
| **Last Updated** | 2026-08-03 |

---

## Build Commands

```bash
# Full build with unit tests
mvn clean install

# Skip tests
mvn clean install -DskipTests

# Integration tests only
mvn clean install -P integration-test

# Run unit tests
mvn test

# Docker build
mvn docker:build -DpushImage
```

---

## Key File Paths

| Category | Path | Description |
|----------|------|-------------|
| **Entry Point** | `src/main/java/com/att/idp/idgraphconsumerms/Application.java` | Spring Boot main class (`@EnableRetry`, `@EnableAsync`, `@EnableCaching`, `@EnableConfigurationProperties`) |
| **Constants** | `src/main/java/.../constants/ConsumerConstants.java` | All domain constants (event types, header keys, status values) |
| **Kafka Config** | `src/main/java/.../kafka/config/` | `IDGraphKafkaConsumerConfig` (single consolidated class, 15 factory beans) + `KafkaConsumersConfig`, `KafkaConsumerProperties`, `ErrorTrackerProperties` |
| **Kafka Listeners** | `src/main/java/.../kafka/listener/` | 13 listener classes / 15 `@KafkaListener` endpoints consuming from Azure Event Hubs and Confluent Cloud |
| **Kafka Models** | `src/main/java/.../kafka/model/` | 23 event model POJOs |
| **DMCTN Services** | `src/main/java/.../kafka/dmctn/service/` | 21 service classes for subscriber/account lifecycle processing |
| **Helpers** | `src/main/java/.../helpers/` | 21 business logic helpers (rules, notification, migration, ODS notes, circuit breaker) |
| **BSSE Reverse** | `src/main/java/.../bsse/reverse/` | 3 classes for reverse migration processing |
| **Cosmos DB** | `src/main/java/.../cosmos/nosql/` | Config, helpers, model, repository for Cosmos DB |
| **REST Resources** | `src/main/java/.../resource/` | JAX-RS interfaces; `resource/impl/` for implementations |
| **REST Client** | `src/main/java/.../rest/client/GenericApiRestClient.java` | REST client with retry for downstream API calls |
| **Error Handler** | `src/main/java/.../kafka/errorhandler/IDGraphKafkaErrorHandler.java` | Custom Kafka error handler (retryable vs non-retryable) |
| **App Config** | `src/main/java/.../appconfig/config/` | Azure App Configuration refresh + dynamic log level (4 files) |
| **DB Config** | `src/main/java/.../config/DataBaseConfiguration.java` | Oracle datasource and JPA entity manager factory |
| **Application Props** | `opt/ajsc/etc/config/application.properties` | Main runtime config (681 lines) |
| **Consumer Rules** | `opt/ajsc/etc/config/consumer.properties` | Destination routing rules (Yahoo, PLDAP, LSCRM, HaloC) |
| **Distribution Events** | `src/main/resources/distributionevent.properties` | Event-to-system routing map |
| **Error Messages** | `src/main/resources/errormessages.properties` | Error message definitions |
| **Log Messages** | `src/main/resources/logmessages.properties` | Log message definitions |
| **Unit Tests** | `src/test/groovy/com/att/idp/idgraphconsumerms/` | 82 Spock test files |
| **Component Tests** | `src/test/groovy/com/att/idp/component/` | 4 component test files |
| **IST Tests** | `src/test/ist/cadevtest/` | 12 integration/IST test files |
| **Helm Chart** | `apm0045194-idgraph-idgraphconsumerms-helm` (separate repo) | Deployment configuration |

---

## Coding Conventions

### Java Standards (IDGraph + OMNI)
- **Java 17** | **Spring Boot 3.x** | **JAX-RS (Jersey)** for REST
- **Constructor injection**: `@RequiredArgsConstructor` + `private final` fields (no `@Autowired` on fields)
- **Constants**: All literals in `ConsumerConstants.java` or `application.properties` — never inline
- **Lombok**: Use `@Getter`, `@Setter`, `@Builder`, `@RequiredArgsConstructor`; avoid `@Data`
- **No empty catch blocks**: Every `catch` must log and handle
- **No `System.out.println`**: Use structured logging (`log.info`, `log.error`)
- **ESAPI sanitization**: All external values must be sanitized before logging
- **Error responses**: Use `CommonErrorMap` + `CErrorDefs` (IDGraph hard-stop HS-1)
- **No wildcard imports**: All imports must be explicit (IDGraph hard-stop HS-6)

### Layered Architecture
```
Resource (JAX-RS Interface) → ResourceImpl → Validator → Helper/Service → Repository/Client
```

### Kafka Conventions
- **AckMode**: `MANUAL_IMMEDIATE` on all consumers
- **autoStartup**: `false` for external consumers; `true` for internal test consumers
- **Error handling**: `IDGraphKafkaErrorHandler` as common handler
- **Auth patterns**: OAUTHBEARER for Confluent, PLAIN for Azure Event Hubs — **do not change** (HS-5)
- **Consumer config**: Via `@ConfigurationProperties(prefix = "idgraph")` → `KafkaConsumersConfig`
- **Listener ID naming**: `{featureName}Listener` (e.g., `accountNotificationEventListener`)

### Brownfield Rules
- **Default = ADD, not REPLACE** — never remove existing code without approval
- **Tag dead code** `// DEAD_CODE:` instead of deleting
- **Feature flags** for new paths alongside legacy
- **Sync config** to Helm chart repo for every config change (HS-7)
- **Execution plans** go in `docs/{TICKET-ID}/` directory (HS-9)

---

## Domain-Specific Patterns

### Adding a New Kafka Consumer
1. Add consumer properties under `idgraph.consumer.<name>.*` in `application.properties`
2. Create `@Bean` method in `IDGraphKafkaConsumerConfig` for `ConcurrentKafkaListenerContainerFactory`
3. Create `@Service` listener class with `@KafkaListener(containerFactory = "<beanName>")`
4. Create `@Component` processor if shared processing logic is needed
5. Register error handling, validation, or Cosmos DB storage as needed
6. **Sync config** to the Helm chart repository

### Event Processing Pattern
```
Listener.onMessage(ConsumerRecord, Acknowledgment)
  → Set MDC idp-trace-id
  → Deserialize payload
  → Delegate to Processor/Helper
  → Process event (validate, transform, call downstream)
  → ack.acknowledge()
```

### Downstream REST Call Pattern
```java
// Via GenericApiRestClient (BSSE migration, reverse migration)
@Retryable(value = {HttpServerErrorException.class}, maxAttempts = 2)
public ResponseEntity<String> sendPostRequest(APIRequestWrapper wrapper) { ... }

@Recover
public ResponseEntity<String> recoverFromRetry(HttpServerErrorException ex, ...) {
    // Save failed event to Cosmos DB
}
```

### DMCTN Service Factory Pattern
```java
// Factory resolves event name → service implementation
AccountServiceFactory.getService("CloseAccount") → CloseAccountNotificationService
SubscriberServiceFactory.getService("RestoreSubscriber") → RestoreSubscriberService
RGPHOServiceFactory.getService("ChangeProduct") → ChangeProductService
```

### Destination Rules Pattern
```
External event → ExternalEventsProcessingHelper
  → Load distributionevent.properties mapping
  → For each target system:
    → Apply rules (YahooRulesHelper, HaloCRulesHelper, etc.)
    → Publish to system-specific outbound topic via Spring Cloud Stream
```

---

## Integration Points

| Downstream Service | Protocol | Key Endpoints | Client Class |
|-------------------|----------|---------------|--------------|
| **IDGraphUserAssociationMs** | REST | `/migration/bsse`, `/credentials`, `/association/remove`, `/reversemig/bsse`, `/association/changeStatus`, `/association/changeData` | `GenericApiRestClient`, `ApiRestClient` |
| **CustomerGraphOrchestrationMs** | REST | `/authContactMethods` | `ApiRestClient` |
| **IDGraphUserRegistrationMs** | REST | `/orchestration/wireless` | `OrchestrationWirelessApiRestClient` |
| **Oracle DB (MPSYS)** | JDBC | Member service queries | `MemberServiceDBHelper` via `idgraphdbhelper` |
| **Cosmos DB** | Spring Data | Failed events, migration status | `CosmosFailedEventsWriter` (via `FailedEventUtil`), `CosmosMigrationStatusDBHelper` |

### Shared Libraries
| Library | Version | What It Provides |
|---------|---------|-----------------|
| `IDGraphCommonHelper` | `3.0.1` | `CommonErrorMap`, `CErrorDefs`, shared utilities |
| `idgraphdbhelper` | `3.5.8` | DB access abstractions (Oracle, Cosmos) |
| `idgrapheventshelper` | `4.2.1` | Event publishing with primary/secondary failover (`ResilientEventPublisher`) |
| `rest-api-client` | Managed | IDP REST client framework |

---

## Testing

### Framework
- **Spock 2.3** + **Groovy 3.0.15** for unit and component tests
- **Testcontainers** (kafka, azure) for integration tests
- **Awaitility 4.2.0** for async test assertions

### Test Conventions
- **`0 * _` mandatory** in every Spock `then:` block (IDGraph HS-8)
- Test files mirror source structure in `src/test/groovy/`
- Component tests in `src/test/groovy/com/att/idp/component/`
- IST tests in `src/test/ist/cadevtest/`

### Key Test Commands
```bash
mvn test                                    # Unit tests only
mvn verify -P integration-test              # Integration tests only
mvn verify -P integration-test -Dskip.unit.tests=true  # Skip unit, run integration
```

### Coverage Exclusions (Sonar/JaCoCo)
- `Application.*`, `config/*`, `exception/*`
- `model/*`, `utils/*`, `resource/impl/*`
- `integration/*`, `KafkaListenerAutomation.java`
- `HelloWorld*`, `BsseMigrationStatus.java`
- `repository/*`, `IdgraphFailedEvents.java`

---

## Secrets and Configuration

### Secret References (Azure Key Vault)
All secrets use `${idp-secrets-v1:<secret-name>}` pattern:
- `idgraph-spring-datasource-username` / `password` — Oracle DB
- `idgraph-azure-cosmos-nosql-db-key` — Cosmos DB
- `idgraph-confluent-kafka-jaas-sharedaccesskey` — Confluent Kafka
- `idgraph-gddn-*-read-kafka-jaas-sharedaccesskey` — Event Hub consumers
- `idgraph-isbus-kafka-client-id` / `client-pwd` — ISBUS Kafka
- `idgraph-aes256key` — AES256 encryption key

### Configuration Hierarchy
1. `opt/ajsc/etc/config/application.properties` — Local dev defaults
2. Helm `configs/application.properties` — Deployed config
3. Azure App Configuration — Dynamic runtime overrides (`@RefreshScope`)
4. Azure Key Vault — Secrets (loaded at startup)

> **CRITICAL**: Any config change must be synced to the Helm chart repo (`apm0045194-idgraph-idgraphconsumerms-helm`).
