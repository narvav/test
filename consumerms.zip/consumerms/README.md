---
title: "IDGraphConsumerMs"
version: "5.0.0"
last_updated: "2026-08-03"
author: "IDGraph Platform Team"
---

# IDGraphConsumerMs — Kafka Event Consumer Microservice

| Field | Value |
|---|---|
| **Domain / Team** | `IDGraph / Identity Platform` |
| **Artifact ID** | `idgraphconsumerms` |
| **Version** | `0.0.2-SNAPSHOT` |
| **Component Type** | `Kafka Consumer + REST API` |
| **Runtime / Parent** | `sdk-java-parent 3.0.1` |
| **Language / Java Version** | `Java 17` |
| **Base Path / Entry Point** | `/msapi` (REST), Kafka topic listeners |
| **API / Contract Docs** | `Swagger UI at /msapi/idgraphconsumerms/swagger/index.html` |
| **Helm Chart** | `apm0045194-idgraph-idgraphconsumerms-helm` |

## Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Project Structure](#project-structure)
4. [Domain Capability Map](#domain-capability-map)
5. [Integration Context](#integration-context)
6. [Data Flow](#data-flow)
7. [Process Flows](#process-flows)
8. [Interfaces & Endpoints](#interfaces--endpoints)
9. [Data Stores & State Management](#data-stores--state-management)
10. [Configuration](#configuration)
11. [Dependencies](#dependencies)
12. [Observability and Operations](#observability-and-operations)
13. [Security and Compliance](#security-and-compliance)
14. [Build and Test](#build-and-test)
15. [Deployment](#deployment)
16. [Schema Definitions](#schema-definitions)
17. [Key Classes and Code References](#key-classes-and-code-references)
18. [Workflows](#workflows)
19. [Change Log / History](#change-log--history)

---

## Overview

**IDGraphConsumerMs** is a Spring Boot microservice in the
IDGraph platform that consumes events from multiple Kafka
topics across Azure Event Hubs and Confluent Cloud.
It processes identity-graph lifecycle
events and dispatches them to downstream backend services
and outbound Kafka topics.

| Attribute | Value |
|-----------|-------|
| **Group ID** | `com.att.idp` |
| **Artifact ID** | `idgraphconsumerms` |
| **Parent** | `sdk-java-parent:3.0.1` |
| **Java** | 17 |
| **Spring Boot** | 3.x (managed by IDP Seed) |
| **Context Path** | `/msapi` |
| **Helm Chart** | `apm0045194-idgraph-idgraphconsumerms-helm` |

**Key capabilities:**

- **Multi-topic Kafka consumption** — 15 `@KafkaListener`
  endpoints across 13 listener classes consuming from
  Azure Event Hubs (SASL/PLAIN) and Confluent Cloud
  (OAUTHBEARER via Entra ID)
- **Dual authentication** — PLAIN for Azure Event Hubs,
  OAUTHBEARER for Confluent Cloud; unified per-consumer
  config via `KafkaConsumersConfig`
- **Dynamic listener management** — start, stop, and list
  Kafka listeners at runtime via JAX-RS REST endpoints
- **Event routing** — routes external events to Yahoo,
  HALOC, G2, LSCRM, SUBSVC, BBNMS, IDGRAPH, CSI based on
  `distributionevent.properties`
- **ODS Notes generation** — consumes Oracle events,
  profile-update and userid notifications, transforms them
  via `OdsNotesTransformHelper`, and publishes
  `OdsGenerateNotesEvent` payloads to the ODS notes topic
- **CG billing account close** — `BillingAccountCloseEventListener`
  processes `BillingAccountStateChangeEvent` close events with
  per-BAN sequencing and a failed-event circuit breaker
  (`GddnFailedEventCircuitBreaker`, `TransientErrorTracker`)
- **Notification publishing** — builds and publishes
  `UserIdNotification` payloads to the CLM topic
- **BSSE migration orchestration** — validates migration
  BAN notifications, calls `IDGraphUserAssociationMs`,
  handles retry with `@Retryable`
- **BSSE reverse migration** — validates inbound
  reverse-migration data events and forwards to backend
- **Subscriber lifecycle** — processes CG subscriber
  create/change events (status changes, phone number
  changes, remove associations)
- **Account/Product/Subscriber notifications** — delegates
  to service factories for event-specific business logic
- **Individual account close** — queries Oracle DB for
  member services and calls remove-association and
  credential-delete APIs
- **Order events failure handling** — consumes
  `SALES-PIVOT-CONVERSION-FAILED` events from the
  commerce order-events Event Hub topic and deletes
  user credentials
- **Failed event tracking** — persists failed events to
  Azure Cosmos DB for monitoring and replay
- **Migration status tracking** — stores BSSE migration
  status in Cosmos DB
- **Spring Retry** — `@Retryable` with recovery for
  transient `HttpServerErrorException` failures
- **Azure App Configuration** — dynamic configuration
  refresh via `spring-cloud-azure-appconfiguration-config`;
  dynamic listener `autoStartup` refresh
  (`KafkaConsumerAutoStartupRefresher`) and runtime log-level
  changes (`DynamicLogLevelConfig`)

---

## Architecture

```mermaid
flowchart TD
    subgraph Sources["Kafka Sources"]
        AEH["Azure Event Hubs<br/>(SASL/PLAIN)"]
        CC["Confluent Cloud<br/>(OAUTHBEARER)"]
    end

    subgraph ConsumerMs["IDGraphConsumerMs"]
        subgraph Listeners["Kafka Listeners (15 endpoints)"]
            L1["ExternalEvents"]
            L2["BsseMigration<br/>(OAuth + Internal)"]
            L3["BsseReverseMigration<br/>(OAuth + Internal)"]
            L4["DmctnCGSubscriber"]
            L5["AccountNotification"]
            L6["SubscriberNotification"]
            L7["ProductNotification"]
            L8["OrderEvents"]
            L9["IndividualAccountsClose"]
            L10["BillingAccountClose"]
            L11["OdsNotes (x3)"]
        end

        subgraph Processing["Processors and Helpers"]
            P1["ExternalEventsProcessingHelper"]
            P2["BsseMigrationNotificationProcessor"]
            P3["BsseReverseMigrationEventProcessor"]
            P4["DmctnCGSubscriberEventProcessor"]
            P5["NotificationEventProcessorHelper"]
            P6["IndividualAccountsCloseEventProcessor"]
            P7["PasscodeProcessor / CloseAccountPasscodeProcessor"]
            P8["OdsNotesTransformHelper"]
            P9["GddnFailedEventCircuitBreaker"]
            P10["Rules Helpers<br/>(Yahoo, HALOC, G2, LSCRM,<br/>SUBSVC, BBNMS, CSI, IDGRAPH)"]
        end
    end

    subgraph Outputs["Downstream Systems"]
        OKafka["Outbound Kafka<br/>(Yahoo, HALOC, G2, SUBSVC,<br/>AllOtherExtSystems, CLM, ODS Notes)"]
        REST["REST APIs<br/>(UserAssociation, Backend)"]
        OracleDB["Oracle DB<br/>(Member Service)"]
        CosmosDB["Cosmos DB<br/>(Failed Events,<br/>Migration Status)"]
    end

    AEH --> Listeners
    CC --> Listeners
    Listeners --> Processing
    Processing --> OKafka
    Processing --> REST
    Processing --> OracleDB
    Processing --> CosmosDB
```

---

## Project Structure

```
apm0045194-idgraph-idgraphconsumerms/
├── pom.xml                                    # Maven build (sdk-java-parent 3.0.1)
├── Jenkinsfile                                # CI/CD pipeline (idp-shared-library 3.0.1)
├── idpsecretsloader.yaml                      # Key Vault secrets manifest
├── CODEOWNERS                                 # Code ownership
├── README.md                                  # This file
├── AGENTS.md                                  # AI agent coding guidelines
├── src/
│   ├── main/
│   │   ├── java/com/att/idp/idgraphconsumerms/
│   │   │   ├── Application.java               # Spring Boot entry point
│   │   │   ├── appconfig/config/              # Azure App Config refresh + dynamic log level (4 files)
│   │   │   ├── bsse/reverse/                  # BSSE reverse migration (3 files)
│   │   │   ├── config/                        # DB config, Jersey config (3 files)
│   │   │   ├── constants/                     # ConsumerConstants, KafkaListenerConstants, OdsNotesConstants
│   │   │   ├── cosmos/nosql/                  # Cosmos DB config, helpers, model (5 files)
│   │   │   ├── helpers/                       # Business logic helpers (21 files)
│   │   │   ├── kafka/
│   │   │   │   ├── config/                    # Kafka consumer config (4 files)
│   │   │   │   ├── dmctn/service/             # DMCTN event services (21 files)
│   │   │   │   ├── errorhandler/              # Kafka error handling (5 files)
│   │   │   │   ├── listener/                  # Kafka event listeners (17 files)
│   │   │   │   ├── model/                     # Kafka event models (23 files)
│   │   │   │   ├── KafkaConsumerAutoStartupRefresher.java
│   │   │   │   └── KafkaListenerAutomation.java
│   │   │   ├── message/                       # Error/Log message keys (2 files)
│   │   │   ├── model/                         # Domain models (9 files)
│   │   │   ├── oracle/                        # Oracle DB helper + model (2 files)
│   │   │   ├── request/validator/             # Request validators (2 files)
│   │   │   ├── resource/                      # JAX-RS interfaces + impls (4 files)
│   │   │   ├── rest/client/                   # REST client (GenericApiRestClient)
│   │   │   └── utils/                         # ConsumerUtil, EventCategoryResolver, FailedEventUtil, JsonService
│   │   ├── resources/
│   │   │   ├── META-INF/                      # Service metadata
│   │   │   ├── distributionevent.properties   # Distribution event rules
│   │   │   ├── errormessages.properties       # Error message definitions
│   │   │   └── logmessages.properties         # Log message definitions
│   │   ├── docker/                            # Dockerfile + startService.sh
│   │   └── jenkins/                           # versioning.groovy
│   └── test/
│       ├── groovy/com/att/idp/
│       │   ├── idgraphconsumerms/             # Unit tests — Spock (82 files)
│       │   └── component/                     # Component tests (4 files)
│       ├── ist/cadevtest/                     # Integration/IST tests (12 files)
│       └── resources/                         # Test configs, mock responses, Kafka payloads
├── opt/ajsc/etc/config/                       # Runtime configuration
│   ├── application.properties                 # Main application config (681 lines)
│   ├── consumer.properties                    # Destination rules
│   ├── bootstrap.properties                   # Azure App Config bootstrap
│   ├── cadi.properties                        # CADI security
│   ├── redis.properties                       # Redis cache config
│   ├── masking.properties                     # Log masking rules
│   ├── security-filter-config.yaml            # Security filters
│   ├── logback.xml / logback-custom.properties # Logging
│   └── keys/                                  # CADI key files (idp-secret refs)
└── .github/copilot-instructions.md            # AI coding guidelines
```

---

## Domain Capability Map

| Capability | Description | Primary Interfaces / Entry Points |
|------------|-------------|-----------------------------------|
| **BSSE Migration Processing** | Consumes wireless/fiber customer migration events and orchestrates registration, credential creation, and association via downstream IDGraph services | `BsseMigrationNotificationOAuthListener`, `BsseMigrationNotificationInternalListener` |
| **BSSE Reverse Migration** | Handles customer reversion from BSSE to legacy TLG, propagating reverse migration state | `BsseReverseMigrationEventOAuthListener`, `BsseReverseMigrationEventInternalListener` |
| **DMCTN CG Subscriber Sync** | Processes CustomerGraph subscriber lifecycle events (create, status change, phone change, removal) to synchronize IDGraph | `DmctnCGSubscriberEventOAuthListener` |
| **Account Notification Handling** | Processes account activate/close/update GDDN events and cascades changes | `AccountNotificationEventListener` |
| **Subscriber Notification Handling** | Processes subscriber restore/cancel/suspend/change events | `SubscriberNotificationEventListener` |
| **Product Notification Handling** | Handles product change, RG activation, and connected car events | `ProductNotificationEventListener` |
| **Order Events Processing** | Consumes commerce order events for sales pivot conversion failure handling | `OrderEventsNotificationListener` |
| **CG Billing Account Close** | Processes CG `BillingAccountStateChangeEvent` close events with per-BAN circuit breaker and sequencing | `BillingAccountCloseEventListener` |
| **ODS Notes Generation** | Transforms Oracle events, profile-update and userid notifications into ODS generate-notes events | `OdsNotesEventListener` (3 listeners) |
| **External Event Distribution** | Routes external events to system-specific outbound topics (Yahoo, HaloC, AllOtherExtSystems) | `IDGraphExternalEventsListener` |
| **User ID Notification Publishing** | Publishes identity change events to the userid-notifications topic | Spring Cloud Stream `userIdNotifications-out-0` |
| **Kafka Listener Management** | Runtime start/stop/list of Kafka listeners via REST API | `GET /kafka/start/{listenerId}`, `GET /kafka/stop/{listenerId}`, `GET /kafka/listeners` |

---

## Integration Context

| Interface / Dependency | Direction | Type | Purpose | Notes |
|------------------------|-----------|------|---------|-------|
| **Confluent Kafka — BSSE Migration** | Inbound | Kafka (OAUTHBEARER) | Receives `acf_migration_notifications` events | OAuth + Internal listeners |
| **Confluent Kafka — CG Individual** | Inbound | Kafka (OAUTHBEARER) | Receives `individual-v1` account close events | OAuth listener |
| **Confluent Kafka — DMCTN CG Subscriber** | Inbound | Kafka (OAUTHBEARER) | Receives `CustomerGraph_subscriber-v1` events | OAuth listener |
| **Confluent Kafka — BSSE Reverse Migration** | Inbound | Kafka (OAUTHBEARER) | Receives `acf_to_critical_app_payload` events | OAuth + Internal listeners |
| **Azure Event Hub — Account Notification** | Inbound | Kafka (PLAIN) | Receives `gddn-accountnotification-v1` events | SASL_SSL PLAIN auth |
| **Azure Event Hub — Subscriber Notification** | Inbound | Kafka (PLAIN) | Receives `gddn-subscribernotification-v1` events | SASL_SSL PLAIN auth |
| **Azure Event Hub — Product Notification** | Inbound | Kafka (PLAIN) | Receives `gddn-rgphosnotification-v1` events | SASL_SSL PLAIN auth |
| **Azure Event Hub — External Events** | Inbound | Kafka (PLAIN) | Receives `idgraph-external-events-v1` | SASL_SSL PLAIN auth |
| **Azure Event Hub — Order Events** | Inbound | Kafka (PLAIN) | Receives `idp-commerce-order-events` | Migrated from ISBUS (SPTAUTHREG-37306) |
| **Confluent Kafka — CG Billing Account Close** | Inbound | Kafka (OAUTHBEARER) | Receives `individual-v1` billing account state change events | `cgCloseAccountListener` |
| **Azure Event Hub — ODS Notes sources** | Inbound | Kafka (PLAIN) | Receives `idgraph-oracleevents-v1`, `idgraph-profile-update-notification-v1`, `idgraph-userid-notifications-v1` | Three listeners in `OdsNotesEventListener` |
| **IDGraphUserAssociationMs** | Outbound | REST | BSSE migration, credentials, remove association, change status, change data, reverse migration | Via `GenericApiRestClient` and `ApiRestClient` |
| **CustomerGraphOrchestrationMs** | Outbound | REST | Auth contact methods lookup for DMCTN processing | Via `ApiRestClient` |
| **IDGraphUserRegistrationMs** | Outbound | REST | Wireless orchestration for subscriber create events | Via `OrchestrationWirelessApiRestClient` |
| **Oracle DB (MPSYS)** | Outbound | JDBC | Member service data lookups for notification processing | Via `MemberServiceDBHelper` + `idgraphdbhelper` |
| **Cosmos DB NoSQL** | Outbound | Spring Data | Failed event tracking; migration status | Via `CosmosFailedEventsWriter` (through `FailedEventUtil`), `CosmosMigrationStatusDBHelper` |
| **Azure App Configuration** | Outbound | Config | Dynamic runtime configuration refresh | Via `ScheduledTaskConfiguration` |
| **Azure Key Vault** | Outbound | Secrets | Secret loading at startup | Via `idpsecretsloader.yaml` |
| **userid-notifications topic** | Outbound | Kafka (SCS) | Publishes processed user ID notification events | Spring Cloud Stream |
| **yahoo-events topic** | Outbound | Kafka (SCS) | Publishes Yahoo-targeted notification events | Spring Cloud Stream |
| **haloc-events topic** | Outbound | Kafka (SCS) | Publishes HaloC-targeted notification events | Spring Cloud Stream |
| **allotherextsystems-events topic** | Outbound | Kafka (SCS) | Publishes notifications for all other external systems (incl. BBNMS, CSI) | Spring Cloud Stream |
| **g2-events topic** | Outbound | Kafka (SCS) | Publishes G2-targeted notification events | Spring Cloud Stream |
| **subsvc-events topic** | Outbound | Kafka (SCS) | Publishes SUBSVC transformed subscription-service events | Spring Cloud Stream |
| **ods-generate-notes topic** | Outbound | Kafka (SCS) | Publishes ODS generate-notes events | Spring Cloud Stream (`odsGenerateNotes-out-0`) |

---

## Data Flow

The service acts as a central event consumer and router
within the IDGraph platform. Events arrive from two
Kafka broker types (Azure Event Hubs and Confluent
Cloud) and flow through processing layers
before reaching downstream systems.

```mermaid
sequenceDiagram
    participant K as Kafka Brokers
    participant L as Kafka Listeners
    participant P as Processors/Helpers
    participant D as Downstream

    K->>L: Consume event (JSON)
    L->>L: Deserialize payload
    L->>L: Set MDC idp-trace-id
    L->>P: Delegate to processor
    alt Outbound Kafka
        P->>D: Publish to Yahoo/HALOC/CLM topics
    else REST Call
        P->>D: POST to UserAssociation or Backend API
    else Database Write
        P->>D: Save to Cosmos DB or query Oracle DB
    end
    L->>K: ack.acknowledge()
```

**Event flow summary:**

| Source | Event Category | Processing | Output |
|--------|---------------|------------|--------|
| Azure Event Hub | External events | Rules-based routing | Yahoo, HALOC, G2, LSCRM, SUBSVC, BBNMS, IDGRAPH, CSI topics |
| Azure Event Hub | Account/Subscriber/Product notifications | Service factory delegation | REST API calls |
| Confluent | BSSE migration | Validation + retry | REST API to UserAssociationMs |
| Confluent | BSSE reverse migration | Validation | REST API via GenericApiRestClient |
| Confluent | CG subscriber events | Event-type routing | REST API calls |
| Azure Event Hub | Order events failures | Credential deletion | REST API to UserAssociationMs |
| Confluent | Individual account close | Oracle query + loop | REST API calls |
| Confluent | CG billing account close | Circuit breaker + sequencing | REST API calls |
| Azure Event Hub | ODS notes source events | Transformation | ODS generate-notes topic |

All failed events are persisted to **Cosmos DB** for
monitoring and replay. BSSE migration status is also
tracked in Cosmos DB.

---

## Process Flows

### 1. External Events Processing

Consumes external IDGraph events from Azure Event Hub
and dispatches to downstream systems (Yahoo, HALOC,
G2, LSCRM, SUBSVC, BBNMS, IDGRAPH, CSI) based on
configurable event-to-system mapping.

```mermaid
sequenceDiagram
    participant AEH as Azure Event Hub
    participant Listener as IDGraphExternalEventsListener
    participant EEPH as ExternalEventsProcessingHelper
    participant Rules as Rules Helpers (Yahoo/HALOC/G2/LSCRM/SUBSVC/BBNMS)
    participant Publisher as EventPublisher
    participant NEPH as NotificationEventProcessorHelper

    AEH->>Listener: Kafka message (JSON)
    Listener->>Listener: Deserialize JSON to Map
    Listener->>Listener: Set MDC idp-trace-id from transactionId
    Listener->>EEPH: processExternalEvents(map)
    EEPH->>EEPH: Load distributionevent.properties
    EEPH->>EEPH: Extract eventsData list
    loop Each event in eventsData
        alt eventName == "NotificationEvent"
            EEPH->>NEPH: processNotificationEvent(event, inputMap)
            NEPH->>NEPH: Generate cTypes, build UserIdNotification
            NEPH->>Publisher: send to CLM topic
        end
        EEPH->>EEPH: Lookup systems from distributionevent.properties
        loop Each target system
            alt YAHOO
                EEPH->>Rules: processYahooMessage(event)
                Rules-->>EEPH: true/false
                EEPH->>Publisher: send to Yahoo topic
            else HALOC
                EEPH->>Rules: processHaloCMessage(event)
                EEPH->>Publisher: send to HALOC topic
            else SUBSVC
                EEPH->>Rules: processSubSvcMessage(event)
                EEPH->>Publisher: send to SUBSVC topic
            else LSCRM / G2 / BBNMS / IDGRAPH / CSI
                EEPH->>Rules: system-specific rules helper
                EEPH->>Publisher: send to respective topic
            end
        end
    end
    Listener->>AEH: ack.acknowledge()
```

**Listener:** `IDGraphExternalEventsListener` (id: `idgraphExtEventsListener`)
**Config:** `IDGraphKafkaConsumerConfig` → factory `idgraphExtEventsConsumerContainerFactory`
**Topic property:** `idgraph.consumer.idgraphexternalevents.topic`

### 2. BSSE Migration Notification

Processes BSSE migration BAN notifications from Confluent topics. Validates event type, sub-status, and status; stores migration status in Cosmos DB; then calls `IDGraphUserAssociationMs` REST API with retry.

```mermaid
flowchart TD
    A[Kafka Message] --> B[BsseMigrationNotificationOAuthListener / InternalListener]
    B --> C[Deserialize to MigrationBANNotification]
    C --> D[Store migration status in Cosmos DB]
    D --> E{eventType == MigrationBanNotification?<br/>subStatus == Request_ALL_Commit_To_Target?<br/>status == Inflight_PONR?<br/>replayFlag != Y?}
    E -->|No| F[Log and acknowledge]
    E -->|Yes| G[Validate required fields]
    G -->|Valid| H["callBSSEMigrationService() @Retryable"]
    G -->|Invalid| I[Save failed event to Cosmos DB]
    H --> J[POST to IDGraphUserAssociationMs]
    J -->|200 OK| K[Log response]
    J -->|5xx| L[Retry up to 2 attempts]
    L -->|Exhausted| M["@Recover: Save to Cosmos DB"]
    J -->|Other error| I
```

**Listeners:**
- `BsseMigrationNotificationOAuthListener` (id: `idpMigrationNotificationOAuthListener`)
- `BsseMigrationNotificationInternalListener` (id: `idpMigrationNotificationInternalOAuthListener`, internal test topic)

**Shared processor:** `BsseMigrationNotificationProcessor`
**Service helper:** `BsseMigrationServiceHelper` — `@Retryable(maxAttempts=2, retryFor=HttpServerErrorException.class)`

### 3. BSSE Reverse Migration

Processes reverse migration events to roll back BSSE migrations. Validates required fields, stores status in Cosmos DB, and calls the backend reverse-migration API.

```mermaid
flowchart TD
    A[Kafka Message] --> B[BsseReverseMigrationEventOAuthListener / InternalListener]
    B --> C[BsseReverseMigrationEventProcessor.processEvent]
    C --> D[Parse eventType from JSON]
    D --> E{eventType == ReverseMigratedData?}
    E -->|No| F[Log unsupported, acknowledge]
    E -->|Yes| G[Deserialize ReverseMigratedInboundDataEvent]
    G --> H[Store migration status in Cosmos DB]
    H --> I[Validate required fields]
    I -->|Invalid| J[Log error, acknowledge]
    I -->|Valid| K[Build ReverseMigratedOutboundRequest]
    K --> L[BsseReverseMigrationService.callBackendAPI]
    L --> M[POST via GenericApiRestClient]
```

**Listeners:**
- `BsseReverseMigrationEventOAuthListener` (id: `bsseRevMigEventOAuthListener`)
- `BsseReverseMigrationEventInternalListener` (id: `bsseRevMigEventOAuthInternalListener`, internal test topic)

**Config:** `IDGraphKafkaConsumerConfig` → factories `bsseRevMigOAuthConsumerContainerFactory`, `bsseRevMigOAuthInternalConsumerContainerFactory`

### 4. DMCTN CG Subscriber Events

Processes Customer Graph subscriber create and change events. Routes to the appropriate processor based on `eventType`.

```mermaid
flowchart TD
    A[Kafka Message] --> B[DmctnCGSubscriberEventOAuthListener]
    B --> C[DmctnCGSubscriberEventProcessor.processEvent]
    C --> D[Deserialize CGSubscriberEvent]
    D --> E{eventType?}
    E -->|SubscriberChangeEvent| F{Header ChangeType present?}
    F -->|No| G[Acknowledge and skip]
    F -->|Yes| H[SubscriberChangeEventProcessor.processEvent]
    E -->|SubscriberCreateEvent| I[SubscriberCreateEventProcessor.processEvent]
    E -->|Other| J[Log unsupported]
    H & I & J --> K[ack.acknowledge]
```

**Listener:** `DmctnCGSubscriberEventOAuthListener` (id: `dmctnSubChangeEventOAuthListener`)

**Config:** `IDGraphKafkaConsumerConfig` → factory `cgDmctnOAuthConsumerContainerFactory`

### 5. Account Notification Events

Consumes account notification events and delegates to event-specific services via `AccountServiceFactory`.

```mermaid
flowchart TD
    A[Kafka Message] --> B[AccountNotificationEventListener]
    B --> C[Deserialize AccountNotificationEvent]
    C --> D[Extract eventName]
    D --> E[AccountServiceFactory.getService eventName]
    E -->|Service found| F[service.execute event]
    E -->|null| G[Log unsupported event]
    F & G --> H[ack.acknowledge]
```

**Listener:** `AccountNotificationEventListener` (id: `accountNotificationEventListener`)
**Config:** `IDGraphKafkaConsumerConfig` → factory `accountNotificationConsumerContainerFactory`
**Supported events:** resolved via `AccountServiceFactory` (e.g. `CloseAccount`, `ActivateAccount`, `UpdateAccount`, provision-enabler and platform-handler notifications)

### 6. Subscriber Notification Events

Consumes subscriber notification events and delegates to backend services via `SubscriberServiceFactory`.

```mermaid
flowchart TD
    A[Kafka Message] --> B[SubscriberNotificationEventListener]
    B --> C[Deserialize SubscriberEventNotification]
    C --> D[Build Subscriber model from notification]
    D --> E[SubscriberServiceFactory.getService eventName]
    E -->|Service found| F[service.execute subscriber]
    E -->|null| G[Log unsupported event]
    F & G --> H[ack.acknowledge]
```

**Listener:** `SubscriberNotificationEventListener` (id: `subscriberNotificationEventListener`)
**Config:** `IDGraphKafkaConsumerConfig` → factory `subscriberNotificationConsumerContainerFactory`
**Supported events:** `RestoreSubscriber`, `CancelSubscriber`, `SuspendSubscriber`, `ChangeData` (via `SubscriberServiceFactory`)

### 7. Product Notification Events

Consumes product notification events and delegates to `RGPHOServiceFactory` for product change and RG activation processing.

**Listener:** `ProductNotificationEventListener` (id: `productNotificationEventListener`)
**Config:** `IDGraphKafkaConsumerConfig` → factory `productNotificationConsumerContainerFactory`
**Supported events:** `ChangeProduct`, `RGActivation` (via `RGPHOServiceFactory`)

### 8. Order Events Conversion Failed

Listens for `SALES-PIVOT-CONVERSION-FAILED` events from the commerce order-events Event Hub topic. Extracts the `individualId` and calls `PasscodeProcessor` to delete user credentials.

```mermaid
flowchart TD
    A[Kafka Message] --> B[OrderEventsNotificationListener]
    B --> C[Deserialize OGraphConversionFailedEvent]
    C --> D{eventType == SALES-PIVOT-CONVERSION-FAILED?}
    D -->|No| E[Acknowledge and skip]
    D -->|Yes| F[Extract individualId]
    F --> G{individualId empty?}
    G -->|Yes| H[Log error]
    G -->|No| I[PasscodeProcessor.callUserAssociationDeleteCredService]
    I --> J[ack.acknowledge]
```

**Listener:** `OrderEventsNotificationListener` (id: `orderEventsNotificationListener`)
**Config:** `IDGraphKafkaConsumerConfig` → factory `orderEventsConsumerContainerFactory`
**Topic property:** `idgraph.consumer.ordereventsconsumer.topic` (Azure Event Hub, migrated from ISBUS)

### 9. Individual Accounts Close Events

Processes `IndividualAccountsCloseEvent` events. Queries Oracle DB for member services associated with an `individualId`, calls remove-association for each, then deletes credentials.

```mermaid
flowchart TD
    A[Kafka Message] --> B[IndividualAccountsCloseEventOAuthListener]
    B --> C[Deserialize IndividualAccountsCloseEvent]
    C --> D{eventType == IndividualAccountsCloseEvent?}
    D -->|No| E[Acknowledge and skip]
    D -->|Yes| F[Extract individualId from event.individual JSON]
    F --> G[IndividualAccountsCloseEventProcessor.process]
    G --> H[MemberServiceDBHelper.queryMemberService - Oracle DB]
    H --> I[Loop: RemoveAssociationApiHelper per memberNum]
    I --> J[PasscodeProcessor.callUserAssociationDeleteCredService]
    J --> K[ack.acknowledge]
```

**Listener:** `IndividualAccountsCloseEventOAuthListener` (id: `individualAccountsCloseEventOAuthListener`)

**Config:** `IDGraphKafkaConsumerConfig` → factory `cgIndividualOAuthConsumerContainerFactory`

### 9a. CG Billing Account Close Events

Processes CG `BillingAccountStateChangeEvent` close events from the `individual-v1` Confluent topic. Uses `GddnFailedEventCircuitBreaker` and `TransientErrorTracker` to block out-of-order processing for BANs with prior failures.

**Listener:** `BillingAccountCloseEventListener` (id: `cgCloseAccountListener`)
**Config:** `IDGraphKafkaConsumerConfig` → factory `cgCloseAccountOAuthConsumerContainerFactory`
**Processor:** `CloseAccountPasscodeProcessor`

### 9b. ODS Notes Events

Three listeners in `OdsNotesEventListener` (ids: `notesOracleEventsListener`, `notesProfileUpdateListener`, `notesUserIdNotificationsListener`) consume Oracle events, profile-update notifications, and userid notifications, transform them via `OdsNotesTransformHelper`, and publish `OdsGenerateNotesEvent` payloads to the ODS generate-notes topic via `ResilientEventPublisher` (`odsGenerateNotes-out-0`).

### 10. Kafka Listener Lifecycle Management

Operators can start, stop, and list all Kafka listeners at runtime via REST endpoints without redeployment.

```mermaid
flowchart TD
    A[Spring Boot Startup] --> B[Config classes create ConsumerFactory per topic]
    B --> C[Register ConcurrentKafkaListenerContainerFactory beans]
    C --> D[KafkaListenerEndpointRegistry]
    D --> E{autoStartup = true?}
    E -->|true| F[Listener starts consuming]
    E -->|false| G[Listener idle]
    G --> H[GET /kafka/start/listenerId]
    H --> I[KafkaListenerAutomation.startListener]
    I --> F
    F --> J[GET /kafka/stop/listenerId]
    J --> K[KafkaListenerAutomation.stopListener]
    K --> G
```

---

## Inputs and Outputs

### Consumed Kafka Topics (Inputs)

| # | Topic Property | Event Type | Server | Auth | Listener ID |
|---|----------------|-----------|--------|------|-------------|
| 1 | `idgraph.consumer.idgraphexternalevents.topic` | External IDGraph Events | Azure Event Hub | PLAIN | `idgraphExtEventsListener` |
| 2 | `idgraph.consumer.bssemigrationoauth.topic` | BSSE Migration BAN Notification | Confluent | OAUTHBEARER | `idpMigrationNotificationOAuthListener` |
| 3 | `idgraph.consumer.bssemigrationoauthinternal.topic` | BSSE Migration (internal test) | Confluent | OAUTHBEARER | `idpMigrationNotificationInternalOAuthListener` |
| 4 | `idgraph.consumer.bssereversemigoauth.topic` | BSSE Reverse Migration | Confluent | OAUTHBEARER | `bsseRevMigEventOAuthListener` |
| 5 | `idgraph.consumer.bssereversemigoauthinternal.topic` | BSSE Reverse Migration (internal test) | Confluent | OAUTHBEARER | `bsseRevMigEventOAuthInternalListener` |
| 6 | `idgraph.consumer.cgdmctnoauth.topic` | CG Subscriber Events | Confluent | OAUTHBEARER | `dmctnSubChangeEventOAuthListener` |
| 7 | `idgraph.consumer.cgindividualoauth.topic` | Individual Accounts Close | Confluent | OAUTHBEARER | `individualAccountsCloseEventOAuthListener` |
| 8 | `idgraph.consumer.cgcloseaccountoauth.topic` | CG Billing Account Close | Confluent | OAUTHBEARER | `cgCloseAccountListener` |
| 9 | `idgraph.consumer.ordereventsconsumer.topic` | Order Events Conversion Failed | Azure Event Hub | PLAIN | `orderEventsNotificationListener` |
| 10 | `idgraph.consumer.accountnotificationconsumer.topic` | GDDN Account Notifications | Azure Event Hub | PLAIN | `accountNotificationEventListener` |
| 11 | `idgraph.consumer.subscribernotificationconsumer.topic` | GDDN Subscriber Notifications | Azure Event Hub | PLAIN | `subscriberNotificationEventListener` |
| 12 | `idgraph.consumer.productnotificationconsumer.topic` | GDDN Product (RGPHO) Notifications | Azure Event Hub | PLAIN | `productNotificationEventListener` |
| 13 | `idgraph.consumer.notesoracleeventsconsumer.topic` | ODS Oracle Events | Azure Event Hub | PLAIN | `notesOracleEventsListener` |
| 14 | `idgraph.consumer.notesprofileupdateconsumer.topic` | Profile Update Notifications | Azure Event Hub | PLAIN | `notesProfileUpdateListener` |
| 15 | `idgraph.consumer.notesuseridnotificationsconsumer.topic` | UserId Notifications | Azure Event Hub | PLAIN | `notesUserIdNotificationsListener` |

All listeners default to `autoStartup=false` (property-driven per consumer, refreshable at runtime via `KafkaConsumerAutoStartupRefresher`).

### Produced Kafka Topics (Outputs)

| Topic Property | Content | Producer |
|----------------|---------|----------|
| `spring.cloud.stream.bindings.yahooNotifications-out-0.destination` | Yahoo downstream notifications | `ExternalEventsProcessingHelper` |
| `spring.cloud.stream.bindings.halocNotifications-out-0.destination` | HALOC downstream notifications | `ExternalEventsProcessingHelper` |
| `spring.cloud.stream.bindings.userIdNotifications-out-0.destination` | CLM User ID Notifications | `NotificationEventProcessorHelper` |
| `spring.cloud.stream.bindings.allOtherExtSysNotifications-out-0.destination` | BBNMS outbound notifications | `ExternalEventsProcessingHelper` |
| `spring.cloud.stream.bindings.subsvcNotifications-out-0.destination` | SUBSVC transformed subscription-service envelope | `ExternalEventsProcessingHelper` |
| `spring.cloud.stream.bindings.g2Notifications-out-0.destination` | G2 outbound notifications | `ExternalEventsProcessingHelper` |
| `spring.cloud.stream.bindings.odsGenerateNotes-out-0.destination` | ODS generate-notes events | `OdsNotesEventListener` via `ResilientEventPublisher` |

### REST API Calls (Outputs)

| Target Service | Endpoint Property | HTTP Method | Caller |
|----------------|-------------------|-------------|--------|
| IDGraphUserAssociationMs | `apiclient.rest.ua.serverUrl` + `apiclient.rest.ua.endpoint` | POST | `BsseMigrationServiceHelper` |
| IDGraphUserAssociationMs (reverse) | `apiclient.rest.ua.serverUrl` + `apiclient.rest.ua.bssereversemigration.endpoint` | POST | `BsseReverseMigrationService` |
| Remove Association API | Configured per service | POST | `RemoveAssociationApiHelper` |
| Delete Credentials API | Configured per service | POST | `PasscodeProcessor` |
| DMCTN Backend Services | Configured per service | Various | `ApiRestClient`, `OrchestrationWirelessApiRestClient`, `CloseAccountApiClient` |

### Cosmos DB Writes (Outputs)

| Container | Entity | Helper Class | Purpose |
|-----------|--------|-------------|---------|
| Failed Events | `IdgraphFailedEvents` | `CosmosFailedEventsWriter` (via `FailedEventUtil`) | Stores events that failed processing for replay |
| Migration Status | `BSSEMigrationStatus` (from `idgraphdbhelper`) | `CosmosMigrationStatusDBHelper` | Tracks BSSE migration and reverse-migration status |

---

## Interfaces & Endpoints

### REST Endpoints

| # | Interface | Method | Path | Description | Code Reference |
|---|-----------|--------|------|-------------|----------------|
| 1 | REST | `POST` | `/msapi/idgraphconsumerms/v1/helloworld/getHelloWorld` | Health check / Hello World | `HelloWorldResourceImpl.getHelloWorld()` |
| 2 | REST | `GET` | `/msapi/idgraphconsumerms/v1/kafka/start/{listenerId}` | Start a Kafka listener by ID | `KakfaListenerResourceImpl.start()` |
| 3 | REST | `GET` | `/msapi/idgraphconsumerms/v1/kafka/stop/{listenerId}` | Stop a Kafka listener by ID | `KakfaListenerResourceImpl.stop()` |
| 4 | REST | `GET` | `/msapi/idgraphconsumerms/v1/kafka/listeners` | List all Kafka listeners and status | `KakfaListenerResourceImpl.listListeners()` |

**Implementation:** `KakfaListenerResource` (interface) → `KakfaListenerResourceImpl` (controller)

**Sample `GET /kafka/listeners` Response:**

```json
[
  "idgraphExtEventsListener : RUNNING",
  "idpMigrationNotificationOAuthListener : RUNNING",
  "accountNotificationEventListener : STOPPED"
]
```

### Downstream Service Integrations

| # | Dependency | Protocol | Backend Resource Endpoint URL | Purpose | Code Reference |
|---|------------|----------|-------------------------------|---------|----------------|
| 1 | IDGraphUserAssociationMs | REST | `/msapi/idgraph/idgraphuserassociationms/v1/migration/bsse` | BSSE forward migration | `GenericApiRestClient` |
| 2 | IDGraphUserAssociationMs | REST | `/msapi/idgraph/idgraphuserassociationms/v1/credentials` | Credential creation during migration | `GenericApiRestClient` |
| 3 | IDGraphUserAssociationMs | REST | `/msapi/idgraph/idgraphuserassociationms/v1/association/remove` | Remove user association | `GenericApiRestClient` / `ApiRestClient` |
| 4 | IDGraphUserAssociationMs | REST | `/msapi/idgraph/idgraphuserassociationms/v1/reversemig/bsse` | BSSE reverse migration | `GenericApiRestClient` |
| 5 | IDGraphUserAssociationMs | REST | `/msapi/idgraph/idgraphuserassociationms/v1/association/changeStatus` | Change association status (DMCTN) | `ApiRestClient` |
| 6 | IDGraphUserAssociationMs | REST | `/msapi/idgraph/idgraphuserassociationms/v1/association/changeData` | Change association data (DMCTN) | `ApiRestClient` |
| 7 | CustomerGraphOrchestrationMs | REST | `/msapi/customergraphorchestrationms/v1/authContactMethods` | Auth contact methods lookup | `ApiRestClient` |
| 8 | IDGraphUserRegistrationMs | REST | `/msapi/idgraph/idgraphuserregistrationms/v1/orchestration/wireless` | Wireless orchestration (subscriber create) | `OrchestrationWirelessApiRestClient` |

---

## Data Stores & State Management

| Store / State | Type | Purpose | Access Pattern | Notes |
|---------------|------|---------|----------------|-------|
| **Oracle DB (MPSYS)** | DB | Member service data lookups for notification event processing | `MemberServiceDBHelper` via JdbcTemplate / `idgraphdbhelper` | Read-only access; XA DataSource with Tomcat connection pool |
| **Cosmos DB NoSQL** | DB | Failed event tracking; migration status records | `CosmosFailedEventsWriter`, `CosmosMigrationStatusDBHelper` | azure-spring-data-cosmos |
| **In-Memory (Consumer Properties)** | Config | Kafka consumer configurations loaded at startup | `KafkaConsumersConfig` | `@EnableConfigurationProperties` binding |
| **Azure App Configuration** | Config | Dynamic runtime property refresh | `IDGraphAzureAppConfig` (`@RefreshScope`) | Polled via `ScheduledTaskConfiguration` |

---

## Schema Definitions

### Kafka Consumer Configuration (Unified)

Consumer properties are bound via `@ConfigurationProperties(prefix = "idgraph")` in `KafkaConsumersConfig`:

| Property | Type | Description |
|----------|------|-------------|
| `idgraph.consumer.<name>.consumerName` | String | Logical consumer name |
| `idgraph.consumer.<name>.bootstrapServers` | String | Kafka broker addresses |
| `idgraph.consumer.<name>.groupId` | String | Consumer group ID |
| `idgraph.consumer.<name>.topic` | String | Topic to consume |
| `idgraph.consumer.<name>.securityProtocol` | String | Security protocol (e.g., `SASL_SSL`) |
| `idgraph.consumer.<name>.saslMechanism` | String | `PLAIN` or `OAUTHBEARER` |
| `idgraph.consumer.<name>.saslJaasUsername` | String | SASL username (PLAIN) |
| `idgraph.consumer.<name>.saslJaasPwd` | String | SASL password (PLAIN) |
| `idgraph.consumer.<name>.saslJaasConfig` | String | Full JAAS config string (OAUTH) |
| `idgraph.consumer.<name>.saslOauthbearerTokenEndpointUrl` | String | OAuth token endpoint (OAUTH) |
| `idgraph.consumer.<name>.saslLoginCallbackHandlerClass` | String | Login callback class (OAUTH) |
| `idgraph.consumer.<name>.maxPollRecords` | int | Max records per poll |
| `idgraph.consumer.<name>.maxPollIntervalMs` | int | Max poll interval (ms) |
| `idgraph.consumer.<name>.autoOffsetReset` | String | Offset reset policy |
| `idgraph.consumer.<name>.bufferMemory` | Integer | Receive buffer size |
| `idgraph.consumer.<name>.autoStartup` | Boolean | Start listener on boot |

### External Events Payload

```json
{
  "transactionId": "string",
  "eventsData": [
    {
      "eventname": "AddServicesList | ChangePassword | NotificationEvent | ...",
      "Handle": "string",
      "Domain": "string",
      "ban": "string"
    }
  ]
}
```

### MigrationBANNotification Payload

```json
{
  "event_type": "MigrationBanNotification",
  "migration_id": "string",
  "source_ban_id": "string",
  "target_ba_id": "string",
  "target_individual_id": "string",
  "guid": "string",
  "status": "Inflight_PONR",
  "sub_status": "Request_ALL_Commit_To_Target",
  "replay_flag": "N",
  "passcode_venc": "string",
  "source_market_code": "string"
}
```

### ReverseMigratedInboundDataEvent Payload

```json
{
  "eventType": "ReverseMigratedData",
  "sourceBSSEBan": "string",
  "targetTLGBan": "string",
  "migrationId": "string",
  "iterationId": "string",
  "event": {
    "IDMAttributes": {
      "accessIDs": [{ "guid": "string", "roleId": "string", "individualId": "string" }],
      "ctnList": [{ "ctn": "string", "cgSubId": "string", "tlgSubId": "string" }]
    }
  }
}
```

### CGSubscriberEvent Payload

```json
{
  "eventType": "SubscriberChangeEvent | SubscriberCreateEvent",
  "event": {
    "subscriber": "{ JSON string of Subscriber object }",
    "key": "string"
  }
}
```

### AccountNotificationEvent / SubscriberEventNotification Payload

```json
{
  "eventName": "CloseAccount | ActivateAccount | RestoreSubscriber | ...",
  "subId": "string",
  "subscriberNumber": "string",
  "billingAccountNumber": "string",
  "subscriberStatus": "string"
}
```

Full AsyncAPI specification: `src/main/resources/META-INF/resources/asyncapi.yaml`

---

## Key Classes and Code References

### Application Entry Point

| Class | Path | Role |
|-------|------|------|
| `Application` | `com.att.idp.idgraphconsumerms` | Spring Boot main class; `@EnableRetry`, `@EnableAsync`, `@EnableCaching`, `@EnableConfigurationProperties(KafkaConsumersConfig.class)` |

Startup sequence: `SystemPropertiesLoader.addSystemProperties()` → `IdpSecretsCacheHelper.init()` → `SpringApplicationBuilder.run()`

### Kafka Configuration

| Class | Path | Role |
|-------|------|------|
| `KafkaConsumersConfig` | `kafka.config` | `@ConfigurationProperties(prefix="idgraph")` — holds `Map<String, KafkaConsumerProperties>` |
| `KafkaConsumerProperties` | `kafka.config` | Unified consumer properties DTO (auth, bootstrap, SASL, poll settings) |
| `IDGraphKafkaConsumerConfig` | `kafka.config` | Single consolidated config class creating all `ConsumerFactory`/`ConcurrentKafkaListenerContainerFactory` beans (15 factory beans, one per consumer) |
| `ErrorTrackerProperties` | `kafka.config` | `@ConfigurationProperties` for the transient-error tracker / circuit breaker |

All consumer factories use:
- `StringDeserializer` for key and value
- `AckMode.MANUAL_IMMEDIATE`
- `IDGraphKafkaErrorHandler` as common error handler

### Kafka Listeners

| Class | Listener ID | Topic Property | Container Factory |
|-------|-------------|----------------|-------------------|
| `IDGraphExternalEventsListener` | `idgraphExtEventsListener` | `idgraph.consumer.idgraphexternalevents.topic` | `idgraphExtEventsConsumerContainerFactory` |
| `BsseMigrationNotificationOAuthListener` | `idpMigrationNotificationOAuthListener` | `idgraph.consumer.bssemigrationoauth.topic` | `bsseMigrationOAuthConsumerContainerFactory` |
| `BsseMigrationNotificationInternalListener` | `idpMigrationNotificationInternalOAuthListener` | `idgraph.consumer.bssemigrationoauthinternal.topic` | `bsseMigrationOAuthInternalConsumerContainerFactory` |
| `BsseReverseMigrationEventOAuthListener` | `bsseRevMigEventOAuthListener` | `idgraph.consumer.bssereversemigoauth.topic` | `bsseRevMigOAuthConsumerContainerFactory` |
| `BsseReverseMigrationEventInternalListener` | `bsseRevMigEventOAuthInternalListener` | `idgraph.consumer.bssereversemigoauthinternal.topic` | `bsseRevMigOAuthInternalConsumerContainerFactory` |
| `DmctnCGSubscriberEventOAuthListener` | `dmctnSubChangeEventOAuthListener` | `idgraph.consumer.cgdmctnoauth.topic` | `cgDmctnOAuthConsumerContainerFactory` |
| `OrderEventsNotificationListener` | `orderEventsNotificationListener` | `idgraph.consumer.ordereventsconsumer.topic` | `orderEventsConsumerContainerFactory` |
| `IndividualAccountsCloseEventOAuthListener` | `individualAccountsCloseEventOAuthListener` | `idgraph.consumer.cgindividualoauth.topic` | `cgIndividualOAuthConsumerContainerFactory` |
| `BillingAccountCloseEventListener` | `cgCloseAccountListener` | `idgraph.consumer.cgcloseaccountoauth.topic` | `cgCloseAccountOAuthConsumerContainerFactory` |
| `AccountNotificationEventListener` | `accountNotificationEventListener` | `idgraph.consumer.accountnotificationconsumer.topic` | `accountNotificationConsumerContainerFactory` |
| `SubscriberNotificationEventListener` | `subscriberNotificationEventListener` | `idgraph.consumer.subscribernotificationconsumer.topic` | `subscriberNotificationConsumerContainerFactory` |
| `ProductNotificationEventListener` | `productNotificationEventListener` | `idgraph.consumer.productnotificationconsumer.topic` | `productNotificationConsumerContainerFactory` |
| `OdsNotesEventListener` | `notesOracleEventsListener` | `idgraph.consumer.notesoracleeventsconsumer.topic` | `notesOracleEventsConsumerContainerFactory` |
| `OdsNotesEventListener` | `notesProfileUpdateListener` | `idgraph.consumer.notesprofileupdateconsumer.topic` | `notesProfileUpdateConsumerContainerFactory` |
| `OdsNotesEventListener` | `notesUserIdNotificationsListener` | `idgraph.consumer.notesuseridnotificationsconsumer.topic` | `notesUserIdNotificationsConsumerContainerFactory` |

### Event Processors and Helpers

| Class | Package | Role |
|-------|---------|------|
| `ExternalEventsProcessingHelper` | `helpers` | Routes external events to Yahoo/HALOC/G2/LSCRM/SUBSVC/BBNMS/IDGRAPH/CSI via rules helpers and `EventPublisher` |
| `NotificationEventProcessorHelper` | `helpers` | Builds `UserIdNotification` objects and publishes to CLM topic |
| `UserIDNotificationEventDetailsHelper` | `helpers` | Populates CLM notification fields from event data |
| `CTypeHelper` | `helpers` | Generates cType classification for notification events |
| `AttributesHelper` | `helpers` | Builds attribute maps for notification event details |
| `BsseMigrationNotificationProcessor` | `kafka.listener` | Shared processor for BSSE migration events (validation, status tracking, service invocation) |
| `BsseReverseMigrationEventProcessor` | `bsse.reverse` | Processes reverse migration events (validation, Cosmos storage, backend API call) |
| `BsseReverseMigrationEventValidator` | `bsse.reverse` | Validates required fields on reverse migration events |
| `BsseReverseMigrationService` | `bsse.reverse` | Builds outbound request and calls backend API via `GenericApiRestClient` |
| `BsseMigrationServiceHelper` | `helpers` | Calls IDGraphUserAssociationMs with `@Retryable` and `@Recover` |
| `DmctnCGSubscriberEventProcessor` | `kafka.listener` | Shared processor for CG subscriber events; routes to change/create processors |
| `IndividualAccountsCloseEventProcessor` | `helpers` | Queries Oracle for member services, calls remove-association and credential-delete |
| `PasscodeProcessor` | `helpers` | Calls user-association delete-credential service |
| `RemoveAssociationApiHelper` | `helpers` | Calls remove-association API for a given member number |
| `IDGraphYahooRulesHelper` | `helpers` | Applies Yahoo-specific rules to determine if event should be forwarded |
| `IDGraphHaloCRulesHelper` | `helpers` | Applies HALOC-specific rules |
| `IDGraphSubSvcRulesHelper` | `helpers` | Applies SUBSVC-specific rules and transforms payloads (LSRegNotify, UpdateServicesStatusList) into the SUBSVC envelope |
| `IDGraphLSCRMRulesHelper` | `helpers` | Applies LSCRM-specific rules |
| `IDGraphG2RulesHelper` | `helpers` | Applies G2-specific rules (WLLmoduser, AddUpdateMember, DeleteMember) |
| `IDGraphBbnmsRulesHelper` | `helpers` | Applies BBNMS-specific rules (DeleteMemberList, LSRegNotify remap, ActivateTNByBAN) |
| `IDGraphCSIRulesHelper` | `helpers` | Applies CSI-specific rules (UpdatePaymentProfile → allotherextsystems topic) |
| `IDGraphIdgraphRulesHelper` | `helpers` | Applies IDGRAPH-internal rules (LSServicesActivation) |
| `OdsNotesTransformHelper` | `helpers` | Transforms consumed events into `OdsGenerateNotesEvent` payloads |
| `GddnFailedEventCircuitBreaker` | `helpers` | Blocks processing for BANs with prior failed events to preserve ordering |
| `CloseAccountPasscodeProcessor` | `helpers` | Processes CG billing account close events (credential deletion) |
| `BaseRuleHelper` | `helpers` | Base class for rules helpers |

### DMCTN Services

| Class | Package | Role |
|-------|---------|------|
| `SubscriberChangeEventProcessor` | `kafka.dmctn.service` | Processes subscriber status changes and phone number changes |
| `SubscriberCreateEventProcessor` | `kafka.dmctn.service` | Processes subscriber creation events |
| `ChangeAssociationStatusService` | `kafka.dmctn.service` | Changes subscriber association status in IDGraph |
| `ChangeAssociationDataService` | `kafka.dmctn.service` | Updates association data (e.g., phone number) |
| `ChangeAssociationDataMigrationService` | `kafka.dmctn.service` | Handles association data changes during migration |
| `RemoveAssociationService` | `kafka.dmctn.service` | Removes subscriber associations |
| `CloseAccountNotificationService` | `kafka.dmctn.service` | Processes account close notifications |
| `OrchestrationWirelessService` | `kafka.dmctn.service` | Orchestrates wireless-related API calls |
| `UpdateAccountNotificationService` | `kafka.dmctn.service` | Processes account update notifications |
| `ProvisionEnablerNotificationService` | `kafka.dmctn.service` | Processes provision-enabler notifications |
| `DeletePlatformHandlerNotificationService` | `kafka.dmctn.service` | Processes platform-handler delete notifications |
| `RGActivationNotificationService` | `kafka.dmctn.service` | Processes RG activation notifications |
| `EventSource` | `kafka.dmctn.service` | Distinguishes GDDN vs CG event origins for categorization |
| `AccountServiceFactory` | `kafka.dmctn.service` | Factory: resolves account notification event name → `BaseService` |
| `SubscriberServiceFactory` | `kafka.dmctn.service` | Factory: resolves subscriber notification event name → `BackendService` |
| `RGPHOServiceFactory` | `kafka.dmctn.service` | Factory: resolves product notification event name → `BaseService` |
| `BackendServiceFactory` | `kafka.dmctn.service` | General factory for DMCTN backend services |
| `ApiRestClient` | `kafka.dmctn.service` | REST client for DMCTN backend API calls |
| `OrchestrationWirelessApiRestClient` | `kafka.dmctn.service` | REST client for orchestration wireless API |

### REST Resources

| Class | Package | Role |
|-------|---------|------|
| `KakfaListenerResource` | `resource` | JAX-RS interface defining `/kafka/start`, `/kafka/stop`, `/kafka/listeners` |
| `KakfaListenerResourceImpl` | `resource.impl` | Controller implementation; delegates to `KafkaListenerAutomation` |
| `KafkaListenerAutomation` | `kafka` | Start/stop/list listeners via `KafkaListenerEndpointRegistry` |
| `HelloWorldResource` / `HelloWorldResourceImpl` | `resource` / `resource.impl` | Health-check endpoint |

### Cosmos DB Layer

| Class | Package | Role |
|-------|---------|------|
| `CosmosDbConfig` | `cosmos.nosql.config` | Cosmos DB configuration |
| `CosmosProperties` | `cosmos.nosql.config` | `@ConfigurationProperties` for Cosmos connection (URI, key, database name) |
| `FailedEventDetails` | `cosmos.nosql.model` | Model for failed event detail (accountId, eventName, error details) |
| `CosmosFailedEventsWriter` | `cosmos.nosql.helpers` | Writes failed event documents to Cosmos DB |
| `CosmosMigrationStatusDBHelper` | `cosmos.nosql.helpers` | Helper to save migration status |
| `FailedEventUtil` | `utils` | Utility for persisting unprocessable events via `CosmosFailedEventsWriter` |

### REST Client Layer

| Class | Package | Role |
|-------|---------|------|
| `GenericApiRestClient` | `rest.client` | Generic REST client for backend API calls (used by reverse migration, etc.) |
| `APIDetails` | `rest.model` | Builder model for API connection details (server URI, endpoint, credentials) |
| `APIRequestWrapper` | `rest.model` | Wrapper combining `APIDetails`, outgoing request JSON, and `FailedEventDetails` |

### Configuration and Utilities

| Class | Package | Role |
|-------|---------|------|
| `IdpSecretsCacheHelper` | `config` | Loads and decrypts secrets at startup via `DecryptOperation` |
| `DataBaseConfiguration` | `config` | Oracle database/JPA configuration |
| `JerseyConfiguration` | `config` | JAX-RS/Jersey endpoint registration |
| `ManagedShutdownConfiguration` | `config` | Graceful shutdown behavior |
| `IDGraphAzureAppConfig` | `appconfig.config` | Azure App Configuration integration |
| `ScheduledTaskConfiguration` | `appconfig.config` | Scheduled task for config refresh |
| `SchedulerConfig` | `appconfig.config` | Thread pool configuration for schedulers |
| `DynamicLogLevelConfig` | `appconfig.config` | Runtime log-level changes driven by Azure App Config |
| `KafkaConsumerAutoStartupRefresher` | `kafka` | Starts/stops listeners when `autoStartup` properties change at runtime |
| `ListenerContainerManager` | `kafka.listener` | Pauses/resumes listener containers (used by circuit-breaker flows) |
| `TransientErrorTracker` | `kafka.listener` | Tracks transient errors per listener for retry decisions |
| `EventCategoryResolver` | `utils` | Resolves event category based on Kafka topic origin (GDDN vs CG) |
| `ConsumerConstants` | `constants` | Central constants: event types, header keys, status values |
| `ConsumerUtil` | `utils` | Utility methods: elapsed time, encoding, delivery methods |
| `JsonService` | `utils` | JSON serialization/deserialization utilities |
| `MigrationBANNotificationRequestValidator` | `request.validator` | Validates BSSE migration notification payloads |
| `RequestValidator` | `request.validator` | General request validation |
| `IDGraphKafkaErrorHandler` | `kafka.errorhandler` | Custom Kafka error handler |
| `ErrorDetailsBuilder` | `kafka.errorhandler` | Builder for structured error detail maps |

---

## Repository Structure

```
apm0045194-idgraph-idgraphconsumerms/
├── src/
│   ├── main/
│   │   ├── java/com/att/idp/idgraphconsumerms/
│   │   │   ├── Application.java
│   │   │   ├── appconfig/config/
│   │   │   │   ├── IDGraphAzureAppConfig.java
│   │   │   │   ├── ConfigChangeEventListener.java
│   │   │   │   ├── ScheduledTaskConfiguration.java
│   │   │   │   └── SchedulerConfig.java
│   │   │   ├── bsse/reverse/
│   │   │   │   ├── BsseReverseMigrationEventProcessor.java
│   │   │   │   ├── BsseReverseMigrationEventValidator.java
│   │   │   │   └── BsseReverseMigrationService.java
│   │   │   ├── config/
│   │   │   │   ├── DataBaseConfiguration.java
│   │   │   │   ├── JerseyConfiguration.java
│   │   │   │   └── ManagedShutdownConfiguration.java
│   │   │   ├── constants/
│   │   │   │   └── ConsumerConstants.java
│   │   │   ├── cosmos/nosql/
│   │   │   │   ├── config/
│   │   │   │   ├── helpers/
│   │   │   │   ├── model/
│   │   │   │   └── repository/
│   │   │   ├── helpers/
│   │   │   │   ├── ExternalEventsProcessingHelper.java
│   │   │   │   ├── BsseMigrationServiceHelper.java
│   │   │   │   ├── IndividualAccountsCloseEventProcessor.java
│   │   │   │   ├── PasscodeProcessor.java
│   │   │   │   ├── IDGraph*RulesHelper.java
│   │   │   │   └── ...
│   │   │   ├── kafka/
│   │   │   │   ├── config/        (7 config classes)
│   │   │   │   ├── dmctn/service/ (15 service classes)
│   │   │   │   ├── errorhandler/
│   │   │   │   ├── listener/      (15 listener classes)
│   │   │   │   └── model/         (21 model classes)
│   │   │   ├── oracle/helpers/
│   │   │   ├── request/validator/
│   │   │   ├── resource/
│   │   │   │   └── impl/
│   │   │   ├── rest/client/
│   │   │   └── utils/
│   │   └── resources/
│   │       ├── distributionevent.properties
│   │       ├── errormessages.properties
│   │       ├── logmessages.properties
│   │       └── META-INF/resources/asyncapi.yaml
│   └── test/groovy/
│       └── com/att/idp/
│           ├── component/       (component tests)
│           └── idgraphconsumerms/
│               ├── bsse/reverse/ (3 test files)
│               ├── cosmos/       (5 test files)
│               └── helpers/      (14 test files)
├── opt/ajsc/etc/config/
│   ├── application.properties
│   ├── bootstrap.properties
│   ├── consumer.properties
│   ├── guide-file.yaml
│   ├── security-filter-config.yaml
│   └── logback.xml
├── docs/                          (execution plans)
├── Jenkinsfile
├── pom.xml
└── README.md
```

---

## Dependencies

### Core Framework

| Library | Version | Purpose |
|---------|---------|---------|
| Spring Boot | Parent `sdk-java-parent:3.0.1` | Application framework |
| Spring Kafka | (managed) | Kafka consumer/producer infrastructure |
| Spring Retry + Aspects | `5.3.31` | `@Retryable` / `@Recover` |
| Spring Data JPA | `3.5.5` | Oracle DB access |
| Spring Cloud | `2025.0.0` | Cloud config support |

### Kafka

| Library | Version | Purpose |
|---------|---------|---------|
| `kafka-clients` | `3.9.1` | Apache Kafka client |
| `spring-kafka` | (managed) | Spring Kafka consumers |
| `spring-kafka-test` | (managed) | Test support |

### Azure

| Library | Version | Purpose |
|---------|---------|---------|
| `spring-cloud-azure-appconfiguration-config-web` | `5.23.0` | Azure App Config dynamic refresh |
| `spring-cloud-azure-appconfiguration-config` | `5.23.0` | Azure App Config core |
| `azure-spring-data-cosmos` | (managed) | Cosmos DB Spring Data |
| `spring-cloud-azure-dependencies` | `6.1.0` | Azure BOM |

### Database

| Library | Version | Purpose |
|---------|---------|---------|
| `ojdbc10` | `19.8.0.0` | Oracle JDBC driver |
| `tomcat-jdbc` | (managed) | Connection pooling |

### API and Serialization

| Library | Version | Purpose |
|---------|---------|---------|
| Jackson | (managed) | JSON serde |
| OkHttp3 | `4.12.0` | HTTP client |
| SpringDoc OpenAPI | `2.6.0` | API documentation |
| Lombok | `1.18.32` | Boilerplate reduction |
| ESAPI | (managed) | OWASP log encoding |

### IDGraph Internal Dependencies

| Library | Version | Purpose |
|---------|---------|---------|
| `idgrapheventshelper` | `4.2.1` | Outbound Kafka publishing (`ResilientEventPublisher`, primary/secondary failover) |
| `idgraphdbhelper` | `3.5.8` | Database helper utilities (Oracle, Cosmos entities/repositories) |
| `IDGraphCommonHelper` | `3.0.1` | `CommonDefs`, `CErrorDefs`, utilities |
| `idp-seed-sdk-core` | (managed) | IDP SDK core framework |
| `idp-config` | (managed) | IDP configuration |
| `rest-api-client` | (managed) | IDP REST client |
| `idp-shutdown-jersey` | (managed) | Graceful shutdown (Jersey) |
| `idp-shutdown-actuator` | (managed) | Graceful shutdown (Actuator) |

### Testing

| Library | Version | Purpose |
|---------|---------|---------|
| Spock (`spock-core`, `spock-spring`) | `2.3-groovy-3.0` | BDD testing framework |
| Groovy | `3.0.15` | Spock test language |
| Testcontainers (kafka, azure) | `1.20.x` | Integration test containers |
| Awaitility | `4.2.0` | Async test waiting |
| JUnit Platform Suite | (managed) | Test suite aggregation |

---

## Configuration

### Key Configuration Files

| File | Location | Purpose |
|------|----------|---------|
| `application.properties` | `opt/ajsc/etc/config/` | Local dev config (681 lines) |
| `application.properties` | Helm `configs/` | Deployed config (Helm-templated) |
| `bootstrap.properties` | `opt/ajsc/etc/config/` | Azure App Config bootstrap |
| `consumer.properties` | `opt/ajsc/etc/config/` | Kafka consumer defaults |
| `guide-file.yaml` | `opt/ajsc/etc/config/` | Secret decryption guide |
| `security-filter-config.yaml` | `opt/ajsc/etc/config/` | Security filter rules |
| `distributionevent.properties` | `src/main/resources/` | Event-to-system routing map |

### Event Distribution Mapping

Event-to-downstream-system routing is configured in
`distributionevent.properties`:

```properties
AddServicesList              = HALOC|YAHOO
RemoveServicesList           = HALOC|YAHOO
UpdateServicesStatusList     = HALOC|YAHOO|SUBSVC
ChangePassword               = HALOC|YAHOO
AddMember                    = HALOC|YAHOO
UpdateProfileInfo            = HALOC|YAHOO
UpdateMember                 = HALOC|YAHOO|LSCRM
UpdateAliasList              = HALOC
AddServices                  = HALOC
AddRemoveServices            = HALOC
AddMemberList                = HALOC|YAHOO
UpdateMemberList             = HALOC
DeleteMemberList             = HALOC|YAHOO|BBNMS
AddRemoveServicesList        = HALOC|LSCRM
UpdateServicesList           = HALOC
WLLmoduser                   = G2
AddUpdateMember              = G2
DeleteMember                 = G2
UpdatePaymentProfile         = CSI
CreateInteraction            = LSCRM
LSRegNotify                  = SUBSVC|BBNMS
LSServicesActivation         = IDGRAPH
ActivateTNByBAN              = BBNMS
```

### Environment-Specific Overrides

Helm values files are stored in the companion Helm
chart repository and override properties per cluster:

- `values-dev-Graph1EUS2-dev2.yaml`
- `values-dev-Graph1EUS2-dev3.yaml`
- `values-stage-*.yaml`
- `values-prod-*.yaml`

> **Important:** Any configuration change in the
> microservice repo **must** be synced to the
> corresponding Helm chart repository.

---

## Observability and Operations

| Area | Mechanism | Notes |
|------|-----------|-------|
| **Logging** | SLF4J + Logback | Custom `logback.xml` with `masking.properties` for PII; ESAPI sanitization on external values |
| **Tracing / Correlation** | `idp-trace-id`, `idpctx-session-id` | Propagated via MDC across all layers and outbound REST calls |
| **Metrics** | Spring Actuator | Exposed at `management.endpoints.web.exposure.include=*` |
| **Health Checks** | `/actuator/health` | Disk space enabled; Kafka, DB, Redis health disabled by default |
| **Kafka Listener Ops** | `GET /kafka/start/{id}`, `GET /kafka/stop/{id}`, `GET /kafka/listeners` | Runtime listener management — `autoStartup=false` for external consumers |
| **Failed Event Tracking** | Cosmos DB (`CosmosFailedEventsWriter` via `FailedEventUtil`) | Records failed events for operational replay |
| **Error Handling** | `IDGraphKafkaErrorHandler`, `InvalidInputDataException`, `IDGraphRetryableException` | Custom error handler distinguishes retryable vs non-retryable; `CommonErrorMap` / `CErrorDefs` for REST responses |

---

## Security and Compliance

| Area | Approach | Notes |
|------|----------|-------|
| **Authentication** | AAF (disabled), CADI | `idp.aaf.enabled=false`; CADI properties configured; `security-filter-config.yaml` for filter chain |
| **Kafka Auth** | OAUTHBEARER (Confluent) / PLAIN (Azure Event Hubs) | Per-consumer auth type; JAAS configs via Key Vault |
| **REST Auth** | Basic Auth (downstream calls) | Guest/Registered user credentials from Key Vault |
| **Secrets Management** | Azure Key Vault | `idpsecretsloader.yaml` loads secrets before Spring context; `${idp-secrets-v1:*}` references |
| **Sensitive Data Handling** | ESAPI log sanitization, `masking.properties`, Voltage encryption | XSS filter enabled (`idp.xss.filter.enabled=true`) |
| **Compliance** | Veracode SAST (`33944-IDGraph-IDGraphConsumerMs`) | Quality gates: QG4.1, QG4.2, QG7, QG2 skipped per Jenkinsfile |

---

## Workflows

### Application Startup

1. `SystemPropertiesLoader.addSystemProperties()`
   loads system properties
2. Spring Boot starts; `@EnableConfigurationProperties`
   binds `KafkaConsumersConfig`
3. `IDGraphKafkaConsumerConfig` creates all
   `ConsumerFactory` and `ContainerFactory` beans
   (one factory per consumer)
4. Listeners with `autoStartup=true` begin consuming
   (`KafkaConsumerAutoStartupRefresher` can start/stop
   them later on config refresh)
5. Azure App Configuration refresh scheduler starts
6. REST endpoints available at
   `/msapi/idgraphconsumerms/v1/`

### Starting / Stopping a Listener at Runtime

```bash
# Start a specific listener
GET /msapi/idgraphconsumerms/v1/kafka/start/{listenerId}

# Stop a specific listener
GET /msapi/idgraphconsumerms/v1/kafka/stop/{listenerId}

# List all listeners and their status
GET /msapi/idgraphconsumerms/v1/kafka/listeners
```

### Adding a New Kafka Topic Consumer

1. Add consumer properties under
   `idgraph.consumer.<name>.*` in
   `application.properties`
2. Create a `@Bean` method in the appropriate config
   class to produce a
   `ConcurrentKafkaListenerContainerFactory`
3. Create a new `@KafkaListener` method in a
   `@Service` class, referencing
   `containerFactory = "<beanName>"`
4. If using shared processing logic, create a
   `@Component` processor and inject into the listener
5. Register any new error handling, validation, or
   Cosmos DB storage as needed
6. **Sync config** to the Helm chart repository

---

## Build and Test

### Build

```bash
# Full build with unit tests (default profile)
mvn clean install

# Skip unit tests
mvn clean install -DskipTests

# Integration tests only
mvn clean install -P integration-test

# Azure profile (includes idp-spring-boot-autoconfigure)
mvn clean install -P azure
```

### Unit Tests

```bash
mvn test
```

- **Includes:** `**/*Test.java`, `**/*Spec.java`,
  `**/*Test.groovy`, `**/*Spec.groovy`
- **Excludes:** `**/contract/*`, `**/integration/*`,
  `**/component/*`
- **Framework:** Spock 2.3 + Groovy 3.0.15

### Integration Tests

```bash
mvn verify -P integration-test
```

Uses Testcontainers for Kafka and Azure emulation.

### Component Tests

Located in `src/test/groovy/com/att/idp/component/`.
Run with dedicated test suite aggregation via
`ComponentTestSuite`.

### Profiles

| Profile | Description |
|---------|-------------|
| `local` | Default — runs unit tests, skips integration tests |
| `integration-test` | Skips unit tests, runs integration tests |
| `azure` | Adds `idp-spring-boot-autoconfigure` dependency |

### Code Coverage

JaCoCo is configured with exclusions matching the
Sonar exclusion list:

- `Application.*`, `config/*`, `exception/*`
- `model/*`, `utils/*`, `resource/impl/*`
- `integration/*`, `KafkaListenerAutomation.java`
- `HelloWorld*`, `BsseMigrationStatus.java`
- `repository/*`, `IdgraphFailedEvents.java`

---

## Deployment

### Build Artifact / Image

```bash
# Docker build
mvn docker:build -DpushImage
```

Docker image is configured via the Spotify Docker
Maven Plugin with registry
`dockercentral.it.att.com:5100`.

### Pipeline

- **GitHub Actions**: `.github/workflows/ci.yaml` uses the IDP `v1-java-svc` reusable workflow (adopted 2026-07, SPTAUTHREG-36247); config in `.github/variables/idp-configuration.yaml` (`pr-increments-version-rule-v1: warn`)
- **Jenkinsfile**: Uses `idp-shared-library@release/3.0.1` → `pl_idp_ms(ovrParams)` (legacy pipeline, still present)
- **Veracode Profile**: `33944-IDGraph-IDGraphConsumerMs`
- **Default Cluster**: `Graph1EUS2-dev2` / `com-att-idp-idgraph-dev2`
- **Helm Chart**: `apm0045194-idgraph-idgraphconsumerms-helm` (separate repository)

| Parameter | Value |
|-----------|-------|
| **Veracode profile** | `33944-IDGraph-IDGraphConsumerMs` |
| **Default cluster** | `Graph1EUS2-dev2` |
| **Default namespace** | `com-att-idp-idgraph-dev2` |
| **Skipped quality gates** | QG4.1, QG4.2, QG7, QG2 |
| **GitHub migrated** | `true` |

### Runtime Notes

| Area | Value |
|------|-------|
| **Deployment Target** | Kubernetes (AKS) |
| **Namespace** | `com-att-idp-idgraph` |
| **Service DNS** | `idgraphconsumerms.com-att-idp.svc.cluster.local` |
| **Tomcat Threads** | Max 200, Min Spare 25 |
| **Shutdown** | Managed shutdown with 45s jersey wait timeout |

---

## Metrics Glossary

| Metric | Type | Description |
|--------|------|-------------|
| Kafka messages consumed | Counter | Total events received per topic per listener |
| Kafka processing success | Counter | Events processed successfully |
| Kafka processing failure | Counter | Events that failed processing (logged, saved to Cosmos) |
| Listener status | Gauge | `RUNNING` or `STOPPED` per listener ID |
| REST call latency | Timer | Time for backend API calls (logged per method) |
| Cosmos DB writes | Counter | Failed events and migration status documents persisted |
| Retry attempts | Counter | `@Retryable` invocations for transient 5xx failures |

---

## Change Log / History

| Version | Date | Description |
|---------|------|-------------|
| 5.0.0 | 2026-08-03 | Full refresh against latest codebase: artifact renamed to `idgraphconsumerms` (0.0.2-SNAPSHOT); documented ODS Notes listeners/flow, CG billing account close listener with `GddnFailedEventCircuitBreaker`/`TransientErrorTracker`, Order events migration from ISBUS to Azure Event Hub, consolidated `IDGraphKafkaConsumerConfig`, `KafkaConsumerAutoStartupRefresher`, `DynamicLogLevelConfig`; removed stale Plain/ISBUS listeners; updated topics, dependency versions (idgrapheventshelper 4.2.1, idgraphdbhelper 3.5.8), distribution-event map, GitHub Actions `v1-java-svc` CI adoption; merged duplicate sections |
| 4.1.0 | 2026-05-06 | Added BBNMS/SUBSVC external event routing: LSRegNotify -> BBNMS remap (`BBNMSAssignUverseAddressBookP2`), SUBSVC envelope transformation and publish, plus Spock tests for helpers and dispatch/publish paths |
| 4.0.0 | 2026-04-27 | OMNI-standard refresh: added YAML frontmatter, title metadata table, Observability and Operations section, Security and Compliance section; updated TOC |
| 3.0.0 | 2026-03-20 | README recreated: added Data Flow section, Repository Structure, Configuration section, Mermaid architecture diagram, fixed dependency versions to match pom.xml, removed duplicate metrics, parameterized deployment links, added Changelog |
| 2.0.0 | 2025-02-28 | Comprehensive README with process flows, schema definitions, and class references |
| 1.0.0 | — | Initial README from IDP Seed scaffold |

> This repo has been upgraded using Seed v3.0.0
> upgrade automation.
