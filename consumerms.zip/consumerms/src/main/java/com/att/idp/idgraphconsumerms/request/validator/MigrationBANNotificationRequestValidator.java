package com.att.idp.idgraphconsumerms.request.validator;

import com.att.idp.idgraphconsumerms.kafka.model.MigrationBANNotification;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class MigrationBANNotificationRequestValidator {

    private static final Logger logger = LoggerFactory.getLogger(MigrationBANNotificationRequestValidator.class);

    public Map<String, Object> validateMessage(MigrationBANNotification migrationBANNotification) {
        String stAppInfo;
        String sMethodName = ".validateMessage.";
        Map<String, Object> hmResult;
        if (migrationBANNotification == null) {
            stAppInfo = "Input Request Parameter is NULL / Empty.";
            logger.info("{}{}IDGCRV.VC.01 :: {}", MigrationBANNotificationRequestValidator.class.getSimpleName(), sMethodName, stAppInfo);
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, stAppInfo);
            return hmResult;
        } else {
            if (StringUtils.isBlank(migrationBANNotification.getMigrationId())) {
                stAppInfo = "Migration Id is required";
                logger.info("{}{}IDGCRV.VC.02 :: {}", MigrationBANNotificationRequestValidator.class.getSimpleName(), sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                return hmResult;
            }
            if (StringUtils.isBlank(migrationBANNotification.getSourceBanId())) {
                stAppInfo = "Source BAN Id is required";
                logger.info("{}{}IDGCRV.VC.04 :: {}", MigrationBANNotificationRequestValidator.class.getSimpleName(), sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                return hmResult;
            }
            if (StringUtils.isBlank(migrationBANNotification.getSourceMarketCode())) {
                stAppInfo = "Source market code is required";
                logger.info("{}{}IDGCRV.VC.05 :: {}", MigrationBANNotificationRequestValidator.class.getSimpleName(), sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                return hmResult;
            }
            if (StringUtils.isBlank(migrationBANNotification.getTargetBanId())) {
                stAppInfo = "Target BAN is required";
                logger.info("{}{}IDGCRV.VC.07 :: {}", MigrationBANNotificationRequestValidator.class.getSimpleName(), sMethodName, stAppInfo);
                hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo);
                return hmResult;
            }
        }
        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
        return hmResult;
    }
}
