package com.att.idp.idgraphconsumerms.helpers;

import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.oracle.helpers.MemberServiceDBHelper;
import com.att.idp.idgraphconsumerms.oracle.model.MemberServiceResult;
import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.att.mpsys.common.utils.CErrorDefs;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IndividualAccountsCloseEventProcessor {
    private static final Logger logger = LoggerFactory.getLogger(IndividualAccountsCloseEventProcessor.class);

    @Value("${apiclient.rest.ua.removeassociation.endpoint}")
    private String removeAssociationEndpoint;

    @Autowired
    private MemberServiceDBHelper memberServiceDBHelper;

    @Autowired
    private PasscodeProcessor credentialsProcessor;

    @Autowired
    private RemoveAssociationApiHelper removeAssociationApiHelper;

    @Autowired
    private GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker;

    @Autowired
    private CosmosFailedEventsWriter cosmosFailedEventsWriter;

    public void process(String individualId) {
        final String eventName = ConsumerConstants.BsseMigration.EVENT_CG_INDIVIDUAL_CLOSE;

        logger.info("IndividualAccountsCloseEventProcessor execute called for individualId: {}",
                ESAPI.encoder().encodeForHTML(individualId));

        // Circuit breaker: if pending failed events exist for this individual+category,
        // short-circuit directly to Cosmos to preserve sequenced processing order
        if (gddnFailedEventCircuitBreaker.shouldShortCircuit(individualId, eventName)) {
            logger.warn("IndividualAccountsCloseEventProcessor: Circuit breaker OPEN for individualId={}. " +
                    "Saving directly to Cosmos without calling downstream API.",
                    ESAPI.encoder().encodeForHTML(individualId));
            FailedEventUtil.saveFailedEventCircuitOpen(
                    cosmosFailedEventsWriter,
                    individualId,
                    JsonService.getJsonFromObject(individualId),
                    eventName,
                    CErrorDefs.SYS_ERR,
                    ConsumerConstants.GridGddnNotification.ERROR_CIRCUIT_BREAKER_OPEN,
                    this.removeAssociationEndpoint,
                    ConsumerConstants.BsseMigration.INDIVIDUAL_ID
            );
            return;
        }

        List<MemberServiceResult> memberServices = memberServiceDBHelper.queryMemberService(individualId);

        if (memberServices == null) {
            memberServices = java.util.Collections.emptyList();
        }

        logger.debug("memberServices returned from database: {} ", memberServices);
        for (MemberServiceResult result : memberServices) {
            try {
                removeAssociationApiHelper.callRemoveAssociationApi(result.getMemberNum(), individualId);
                logger.info("Processed memberNum: {} for individualId: {}", result.getMemberNum(), individualId);
            } catch (Exception e) {
                logger.error("Failed to process memberNum: {} for individualId: {}. Error: {}", result.getMemberNum(), individualId, e.getMessage());
            }
        }
        credentialsProcessor.callUserAssociationDeleteCredService(
                individualId,
                eventName
        );
    }
}