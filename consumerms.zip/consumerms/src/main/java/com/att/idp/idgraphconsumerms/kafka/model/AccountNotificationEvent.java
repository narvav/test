package com.att.idp.idgraphconsumerms.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountNotificationEvent implements Serializable {

    /**
     * The name of the event.
     */
    private String eventName;

    /**
     * The subscriber ID.
     */

    private String subId;

    /**
     * The subscriber's phone number.
     */
    private String subscriberNumber;

    /**
     * The billing account number.
     */
    private String billingAccountNumber;

    /**
     * The status of the subscriber.
     */
    private String subscriberStatus;

    private String contactEmail;

    private String firstName;

    private String lastName;

    private String serviceName;

    private String phoneNumber;

    private String isConnectedCar;

    private String tlgMessageId;

    private String accountNumber;

    private String oldFan;

    private String newFan;

    private String phFan;

    private String serialNumber;

    private String titanBan;

    private String mobilityBan;

    private String sorId;

    private String eventTime;

    private String eventId;

}