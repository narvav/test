package com.att.idp.idgraphconsumerms.helpers;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import org.apache.commons.text.StringEscapeUtils;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Helper class for processing HaloC event rules for IDGraph Consumer Microservice.
 * This class provides methods to validate and process various HaloC event types
 * such as AddMember, UpdateMember, AddServices, etc., based on configuration properties
 * and event data. It extends {@link BaseRuleHelper} and uses configuration properties
 * loaded from consumer.properties.
 */

@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/consumer.properties")
public class IDGraphHaloCRulesHelper  extends BaseRuleHelper {

	private static final String sClassName = "IDGraphHaloCRulesHelper.";
	public static final Logger logger = LoggerFactory.getLogger(IDGraphHaloCRulesHelper.class);

	private static final Set<String> ADD_MEMBER_ALLOWED_SERVICE_TYPES = Set.of(
			ConsumerConstants.IPTV,
			ConsumerConstants.HaloCAddMemberServiceTypes.LSO,
			ConsumerConstants.HaloCAddMemberServiceTypes.DSLD,
			ConsumerConstants.HaloCAddMemberServiceTypes.ECOMM,
			ConsumerConstants.HaloCAddMemberServiceTypes.PORTAL,
			ConsumerConstants.HaloCAddMemberServiceTypes.LS_ACCT,
			ConsumerConstants.HaloCAddMemberServiceTypes.DIRECTV,
			ConsumerConstants.BsseMigration.MOBILITY,
			ConsumerConstants.HaloCAddMemberServiceTypes.DIRECTVNOW,
			ConsumerConstants.HaloCAddMemberServiceTypes.WLLVCTN,
			ConsumerConstants.HaloCAddMemberServiceTypes.CCARRIER,
			ConsumerConstants.HaloCAddMemberServiceTypes.PREPAID,
			ConsumerConstants.HaloCAddMemberServiceTypes.CCAR_PREPAID,
			ConsumerConstants.HaloCAddMemberServiceTypes.INDIVIDUAL,
			ConsumerConstants.HaloCAddMemberServiceTypes.INDIVIDUALUSER,
			ConsumerConstants.HaloCAddMemberServiceTypes.VAS,
			ConsumerConstants.HaloCAddMemberServiceTypes.CONNECTEDHOME,
			ConsumerConstants.DmctnSubscriberChangeEvent.MOSUB
	);

	@Value("${haloC_SubEvents}")
	private String haloCSubEvents;

	@Value("${haloC_SubEvents_AddMember}")
	private String haloCSubEventsAddMember;

	@Value("${haloC_SubEvents_UpdateMember}")
	private String haloCSubEventsUpdateMember;

	@Value("${haloC_Services}")
	private String haloCServices;

	@Value("${haloC_ProfileInfo_Update}")
	private String haloCProfileInfoUpdate;

	/**
	 * Processes a HaloC event message by validating event data and applying event-specific rules.
	 * @param event the event data as a map of key-value pairs
	 * @return true if the event passes all validation and rule checks, false otherwise
	 */
	public boolean processHaloCMessage(Map<String, Object> event) {
		String stAppInfo = "";
		String sMethodName = ".processHaloCMessage.";
		boolean processHaloCMsg=false;
		try {
			if (!isValidEventsData(event)) {
				stAppInfo = "Events data is null or empty";
				logger.error("{}{}IDGHRH.PHM.01 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(stAppInfo));
				return false;
			}
			if (validateCommonRules(event) && processEventRules(event)) {
				processHaloCMsg=true;
			}

		} catch (Exception e) {
			stAppInfo = "Exception thrown from processMessage : ";
			logger.error("{}{}IDGHRH.PHM.02 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(stAppInfo));
		}
		return processHaloCMsg;
	}

	/**
	 * Validates common rules for the provided event.
	 * @param event the event data as a map of key-value pairs
	 * @return true if the event passes all common rule checks, false otherwise
	 */
	private boolean validateCommonRules(Map<String, Object> event) {
		String stAppInfo = null;
		String sMethodName= ".validateCommonRules.";
		if (inValidSubEvent(event)) {
			stAppInfo = "Invalid SubEvent: " + event.get(ConsumerConstants.SUB_EVENT);
			logger.error("IDGHRH.VCR.01: {}", StringEscapeUtils.escapeJava(stAppInfo));
			return false;
		}
		if (InvalidFiltercGate(event)) {
			stAppInfo = "Invalid filtercGate: " + event.get("filtercGate");
			logger.error("IDGHRH.VCR.02 : {}", StringEscapeUtils.escapeJava(stAppInfo));
			return false;
		}
		return true;
	}


	/*	 * Checks if the sub-event in the event is valid.
	 * @param event the event data as a map of key-value pairs
	 * @return true if the sub-event is valid, false otherwise
	 */
	private boolean inValidSubEvent(Map<String, Object> event) {
		ArrayList<?> haloCsubEventList = CommonUtil.parseToArray(haloCSubEvents, CommonDefs.VALUE_SEPARATOR_CHAR);
		String subEvent = (String) event.get(ConsumerConstants.SUB_EVENT);
		return haloCsubEventList.contains(subEvent);
	}

	/**
	 * Checks if the filtercGate value in the event is valid.
	 * @param event the event data as a map of key-value pairs
	 * @return true if filtercGate is "Y", false otherwise
	 */
	private boolean InvalidFiltercGate(Map<String, Object> event) {
		String filtercGate = (String) event.get("filtercGate");
		return "Y".equals(filtercGate);
	}

	/**
	 * Processes event-specific rules based on the event name and sub-event.
	 * @param event the event data as a map of key-value pairs
	 * @return true if the event passes all event-specific rule checks, false otherwise
	 */
	private boolean processEventRules(Map<String, Object> event) {
		String eventName = (String) event.get("eventname");
		String subEvent = (String) event.get(ConsumerConstants.SUB_EVENT);
		List<Map<String, Object>> allServices = ConsumerUtil.extractAllServicesWithFallback(event);
		return switch (eventName) {
			case "AddMember" -> processAddMember(subEvent, allServices);
			case "UpdateMember" -> processUpdateMember(event, subEvent);
			case ConsumerConstants.UPDATE_PROFILE_INFO -> processUpdateProfileInfo(event, subEvent, allServices);
			case "ChangePassword" -> true;
			case "AddServices" -> processAddServices(event, subEvent);
			case "AddRemoveServices" -> processAddRemoveServices(event, subEvent);
			case "AddMemberList" -> processAddMemberList(event, subEvent, allServices);
			case "RemoveServicesList" -> processRemoveServicesList(event, subEvent, allServices);
			case "UpdateServicesStatusList" -> processUpdateServicesStatusList(allServices);
			case "UpdateServicesList" -> processUpdateServicesList(allServices);
			case "DeleteMemberList" -> processDeleteMemberList(event, subEvent, allServices);
			case "AddServicesList" -> processAddServicesList(allServices);
			case "AddRemoveServicesList" -> processAddRemoveServicesList(allServices);
			case "UpdateMemberList" -> true;
			case "UpdateAliasList" -> true;
			default -> false;
		};
	}

	/**
	 * Processes AddMember event rules.
	 * @param subEvent the sub-event type
	 * @param allServices list of services extracted from the event
	 * @return true if the AddMember event passes all rule checks, false otherwise
	 */
	private boolean processAddMember(String subEvent, List<Map<String, Object>> allServices) {

		if ("NullifyBAN".equals(subEvent)) {
			return false;
		} else {
			if ("SLID".equals(subEvent)) {
				return true;
			}
			if (allServices != null) {
				for (Map<String, Object> service : allServices) {
					String serviceType = service != null ? (String) service.get(ConsumerConstants.SERVICE_TYPE) : null;
					if (ADD_MEMBER_ALLOWED_SERVICE_TYPES.contains(serviceType)) {
						return true;
					} else if ("MOSUB".equalsIgnoreCase(serviceType)) {
						return true;
					}
				}
			}
		}
		return false;
	}

	/**
	 * Processes UpdateMember event rules.
	 * @param event    the event data as a map of key-value pairs
	 * @param subEvent the sub-event type
	 * @return true if the UpdateMember event passes all rule checks, false otherwise
	 */
	private boolean processUpdateMember(Map<String, Object> event, String subEvent) {
		// Filter conditions
		ArrayList servicesUpdateMember = CommonUtil.parseToArray(haloCSubEventsUpdateMember, CommonDefs.VALUE_SEPARATOR_CHAR);
		if (servicesUpdateMember.contains(subEvent)) {
			return false;
		}
		if ("AddSWH".equals(subEvent) && event.get("proofingVersion") == null) {
			return false;
		}

		if (event.get("tokenIndicator")!=null) {
			Object tokenIndicator = event.get("tokenIndicator");
			return "sbclightspeed".equals(tokenIndicator);
		}
		return true;
	}

	/**
	 * Processes UpdateProfileInfo event rules.
	 * @param event    the event data as a map of key-value pairs
	 * @param subEvent the sub-event type
	 * @param allServices list of services extracted from the event
	 * @return true if the UpdateProfileInfo event passes all rule checks, false otherwise
	 */
	private boolean processUpdateProfileInfo(Map<String, Object> event, String subEvent, List<Map<String, Object>> allServices) {
		if ("SyncSouthEast".equals(subEvent))
			return false;

		if (ConsumerConstants.UPDATE_PROFILE_INFO.equals(subEvent) && event.get("password_dirty") == null)
			return false;

		List<String> servicesUpdateProfileInfo = CommonUtil.parseToArray(haloCProfileInfoUpdate, CommonDefs.VALUE_SEPARATOR_CHAR);
		if (allServices != null) {
			for (Map<String, Object> service : allServices) {
				String serviceType = service != null ? (String) service.get(ConsumerConstants.SERVICE_TYPE) : null;
				if (servicesUpdateProfileInfo.contains(serviceType)) {
					return true;
					}
				}
				return false;
		}
		return true;
	}

	/**
	 * Processes AddServices event rules.
	 * @param event    the event data as a map of key-value pairs
	 * @param subEvent the sub-event type
	 * @return true if the AddServices event passes all rule checks, false otherwise
	 */
	private boolean processAddServices(Map<String, Object> event, String subEvent) {
		if ("SyncSouthEast".equals(subEvent))
			return false;
		return !ConsumerConstants.UPDATE_PROFILE_INFO.equals(subEvent) && event.get("password_dirty") == null;
	}

	/**
	 * Processes AddRemoveServices event rules.
	 * @param event    the event data as a map of key-value pairs
	 * @param subEvent the sub-event type
	 * @return true if the AddRemoveServices event passes all rule checks, false otherwise
	 */
	private boolean processAddRemoveServices(Map<String, Object> event, String subEvent) {
		if ("HomeZoneDisconnect".equals(subEvent)) {
			Map<String, Object> removeServices = (Map<String, Object>) event.get("removeServices");
			if (removeServices != null) {
				String portalProvider = (String) removeServices.get("portalProvider");
				return "AT&T NAP".equals(portalProvider);

			}
		}
		// Process in all other cases
		return true;
	}

	/**
	 * Processes AddMemberList event rules.
	 * @param event the event data as a map of key-value pairs
	 * @param subEvent the sub-event type
	 * @param allServices list of services extracted from the event
	 * @return true if the AddMemberList event passes all rule checks, false otherwise
	 */
	private boolean processAddMemberList(Map<String, Object> event, String subEvent, List<Map<String, Object>> allServices) {

		String callingSystemId = (String) event.get("callingSystemId");
		String handle = (String) event.get(ConsumerConstants.HANDLE);

		if ("CPR".equals(callingSystemId) || (handle != null && handle.matches(ConsumerConstants.SBC_IPTV)) || "ExistingRegVoIP".equalsIgnoreCase(subEvent) || "AddingVoIPToParent".equalsIgnoreCase(subEvent) ||
		     "NewMiniEnrolledId".equalsIgnoreCase(subEvent) || "ExistingRegMiniRegId".equalsIgnoreCase(subEvent) || "ExistingRegNotInYahoo".equalsIgnoreCase(subEvent) ||
				"ExistingReg".equalsIgnoreCase(subEvent) || "NotInYahoo".equalsIgnoreCase(subEvent)) {
			return false;
		}

		ArrayList servicesAddMemberList = CommonUtil.parseToArray(haloCServices, CommonDefs.VALUE_SEPARATOR_CHAR);
		return validateServices(allServices, subEvent, servicesAddMemberList);
	}

	/**
	 * Validates services against business rules for AddMemberList processing.
	 * @param allServices list of services to validate
	 * @param subEvent the sub-event type
	 * @param servicesAddMemberList allowed services list
	 *  @return true if at least one serviceType is in the allowed list (or if no services are provided);
	 *  false if services are present but none match, or if Autogen contains IPTV
	 */
	private boolean validateServices(List<Map<String, Object>> allServices, String subEvent, ArrayList servicesAddMemberList) {
		if (allServices != null) {
			for (Map<String, Object> service : allServices) {
				String serviceType = service != null ? (String) service.get(ConsumerConstants.SERVICE_TYPE) : null;
				if ("Autogen".equals(subEvent) && ConsumerConstants.IPTV.equals(serviceType)) {
					return false;
				}
				if (serviceType != null) {
					// If service exists and IS in allowed list, return true immediately
					if (servicesAddMemberList.contains(serviceType)) {
						return true;
					}
				}
			}
			// Return false only if we found services but NONE were in allowed list
			return false;
		}
		return true;
	}

	/**
	 * Processes RemoveServicesList event rules.
	 * @param event the event data as a map of key-value pairs
	 * @param subEvent the sub-event type
	 * @param allServices list of services extracted from the event
	 * @return true if the RemoveServicesList event passes all rule checks, false otherwise
	 */
	private boolean processRemoveServicesList(Map<String, Object> event, String subEvent, List<Map<String, Object>> allServices) {

		if ("ChangeToBYOP".equals(subEvent)) {
			return false;
		}

		ArrayList servicesRemoveList = CommonUtil.parseToArray(haloCServices, CommonDefs.VALUE_SEPARATOR_CHAR);
		String handle = (String) event.get(ConsumerConstants.HANDLE);
		return validateRemoveServices(allServices, subEvent, handle, servicesRemoveList);
	}

	/**
	 * Validates services against business rules for RemoveServicesList processing.
	 * @param allServices list of services to validate
	 * @param subEvent the sub-event type
	 * @param handle the handle value
	 * @param servicesRemoveList allowed services list
	 * @return true if all services pass validation, false otherwise
	 */
	private boolean validateRemoveServices(List<Map<String, Object>> allServices, String subEvent, String handle, ArrayList servicesRemoveList) {
		if ("RemoveServicesList".equals(subEvent) && handle != null && handle.matches(ConsumerConstants.SBC_IPTV)) {
			if (allServices != null) {
				for (Map<String, Object> service : allServices) {
					String serviceType = service != null ? (String) service.get(ConsumerConstants.SERVICE_TYPE) : null;
					if (!ConsumerConstants.IPTV.equals(serviceType)) {
						return false;
					}
				}
			}
		}

		if (allServices != null) {
			for (Map<String, Object> service : allServices) {
				String serviceType = service != null ? (String) service.get(ConsumerConstants.SERVICE_TYPE) : null;
				if (serviceType != null) {
					// If service exists and IS in allowed list, return true immediately
					if (servicesRemoveList.contains(serviceType)) {
						return true;
					}
				}
			}
			// Return false only if we found services but NONE were in allowed list
			return false;
		}
		return true;
	}

	/**
	 * Processes UpdateServicesStatusList event rules.
	 * @param allServices list of services extracted from the event
	 * @return true if the UpdateServicesStatusList event passes all rule checks, false otherwise
	 */
	private boolean processUpdateServicesStatusList(List<Map<String, Object>> allServices) {
		ArrayList servicesUpdateStausList = CommonUtil.parseToArray(haloCServices, CommonDefs.VALUE_SEPARATOR_CHAR);
		return validateUpdateServicesStatus(allServices, servicesUpdateStausList);
	}


	/**
	 * Validates services against business rules for UpdateServicesStatusList processing.
	 * @param allServices list of services to validate
	 * @param servicesUpdateStausList allowed services list
	 * @return true if all services pass validation, false otherwise
	 */
	private boolean validateUpdateServicesStatus(List<Map<String, Object>> allServices, ArrayList servicesUpdateStausList) {
		if (allServices != null) {
			for (Map<String, Object> service : allServices) {
				String serviceType = service != null ? (String) service.get(ConsumerConstants.SERVICE_TYPE) : null;
				if (serviceType != null) {
					// If service exists and is in allowed list, return true immediately
					if (servicesUpdateStausList.contains(serviceType)) {
						return true;
					}
				}
			}
			// Return false only if we found services but NONE were in allowed list
			return false;
		}
		return true;
	}

	/**
	 * Processes UpdateServicesList event rules.
	 * @param allServices list of services extracted from the event
	 * @return true if the UpdateServicesList event passes all rule checks, false otherwise
	 */
	private boolean processUpdateServicesList(List<Map<String, Object>> allServices) {

		ArrayList servicesUpdateList = CommonUtil.parseToArray(haloCServices, CommonDefs.VALUE_SEPARATOR_CHAR);
		return validateUpdateServices(allServices, servicesUpdateList);

	}

	/**
	 * Validates services against business rules for UpdateServicesList processing.
	 * @param allServices list of services to validate
	 * @param servicesUpdateList allowed services list
	 * @return true if all services pass validation, false otherwise
	 */
	private boolean validateUpdateServices(List<Map<String, Object>> allServices, ArrayList servicesUpdateList) {
		if (allServices != null) {
			for (Map<String, Object> service : allServices) {
				String serviceType = service != null ? (String) service.get(ConsumerConstants.SERVICE_TYPE) : null;
				if (serviceType != null) {
					// If service exists and is in allowed list, return true immediately
					if (servicesUpdateList.contains(serviceType)) {
						return true;
					}
				}
			}
			// Return false only if we found services but NONE were in allowed list
			return false;
		}
		return true;
	}

	/**
	 * Processes DeleteMemberList event rules.
	 * @param event    the event data as a map of key-value pairs
	 * @param subEvent the sub-event type
	 * @param allServices list of services extracted from the event
	 * @return true if the DeleteMemberList event passes all rule checks, false otherwise
	 */
	private boolean processDeleteMemberList(Map<String, Object> event, String subEvent, List<Map<String, Object>> allServices) {
		if ("VoIPSubGettingTerminated".equals(subEvent)) {
			return false;
		}
		if ("DeleteMemberList".equals(subEvent)) {
			String handle = (String) event.get(ConsumerConstants.HANDLE);
			return validateDeleteMemberServices(allServices, handle);
		}
		return true;
	}

	/**
	 * Validates services against business rules for DeleteMemberList processing.
	 * @param allServices list of services to validate
	 * @param handle the handle value
	 * @return true if all services pass validation, false otherwise
	 */
	private boolean validateDeleteMemberServices(List<Map<String, Object>> allServices, String handle) {
		if (handle != null && handle.matches(ConsumerConstants.SBC_IPTV)) {
			if (allServices != null) {
				for (Map<String, Object> service : allServices) {
					String serviceType = service != null ? (String) service.get(ConsumerConstants.SERVICE_TYPE) : null;
					if (!ConsumerConstants.IPTV.equals(serviceType)) {
						return false;
					}
				}
			}
		}
		return true;
	}

	/**
	 * Processes AddServicesList event rules.
	 * @param allServices list of services extracted from the event
	 * @return true if the AddServicesList event passes all rule checks, false otherwise
	 */
	private boolean processAddServicesList(List<Map<String, Object>> allServices) {
		ArrayList addServicesList = CommonUtil.parseToArray(haloCServices, CommonDefs.VALUE_SEPARATOR_CHAR);
		return validateAddServices(allServices, addServicesList);
	}
	/**
	 * Validates services against business rules for AddServicesList processing.
	 * @param allServices list of services to validate
	 * @param addServicesList excluded services list
	 * @return true if all services pass validation, false otherwise
	 */
	private boolean validateAddServices(List<Map<String, Object>> allServices, ArrayList addServicesList) {
		if (allServices != null) {
			for (Map<String, Object> service : allServices) {
				String serviceType = service != null ? (String) service.get(ConsumerConstants.SERVICE_TYPE) : null;
				if (serviceType != null) {
					// If service exists and is in allowed list, return true immediately
					if (addServicesList.contains(serviceType)) {
						return true;
					}
				}
			}
			// Return false only if we found services but NONE were in allowed list
			return false;
		}
		return true;
	}
	/**
	 * Processes AddRemoveServicesList event rules.
	 * @param allServices list of services extracted from the event
	 * @return true if the AddRemoveServicesList event passes all rule checks, false otherwise
	 */
	private boolean processAddRemoveServicesList(List<Map<String, Object>> allServices) {
		ArrayList addRemoveServicesList = CommonUtil.parseToArray(haloCServices, CommonDefs.VALUE_SEPARATOR_CHAR);
		return ConsumerUtil.validateAddRemoveServices(allServices, addRemoveServicesList);
	}




}
