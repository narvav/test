package com.att.idp.idgraphconsumerms.cosmos.nosql.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration properties for Azure Cosmos DB NoSQL.
 */
@Configuration
@Data
@AllArgsConstructor
@NoArgsConstructor
@ConfigurationProperties(prefix = "azure.cosmos.idm.nosql.db")
public class CosmosProperties {
    private String uri;
    private String key;
    private String name;
    private boolean queryMetricsEnabled;
    private boolean responseDiagnosticsEnabled;
}
