package com.att.idp.idgraphconsumerms.kafka.errorhandler;

import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * This enum consists of error messages for all resolvable error codes
 *
 */
@Component
public class ErrorMessage implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2923900569407987881L;
	private String MessageId;
	private String appStatusMsg;
	private String appStatusCode;
	private String appInfo;
	private String transactionName;


	public ErrorMessage(){}

	/**
	 * This is a constructor for the ErrorMessage class.
	 * It takes five parameters: MessageId, appStatusMsg, appStatusCode, appInfo, and transactionName.
	 * These parameters represent the ID of the message, the status message of the application, the status code of the application, the information of the application, and the name of the transaction respectively.
	 * The constructor initializes the instance variables of the class with the values of the parameters.
	 *
	 * @param MessageId A string representing the ID of the message.
	 * @param appStatusMsg A string representing the status message of the application.
	 * @param appStatusCode A string representing the status code of the application.
	 * @param appInfo A string representing the information of the application.
	 * @param transactionName A string representing the name of the transaction.
	 */
	public ErrorMessage(String MessageId, String appStatusMsg, String appStatusCode, String appInfo, String transactionName) {
		this.MessageId = MessageId;
		this.appStatusMsg = appStatusMsg;
		this.appInfo = appInfo;
		this.appStatusCode = appStatusCode;
		this.transactionName = transactionName;
	}

	public String getMessageId() {
		return MessageId;
	}

	public void setMessageId(String MessageId) {
		this.MessageId = MessageId;
	}

	public String getTransactionName() {
		return transactionName;
	}

	public void setTransactionName(String transactionName) {
		this.transactionName = transactionName;
	}

	public String getAppStatusMsg() {
		return appStatusMsg;
	}

	public void setAppStatusMsg(String appStatusMsg) {
		this.appStatusMsg = appStatusMsg;
	}

	public String getAppInfo() {
		return appInfo;
	}

	public void setAppInfo(String appInfo) {
		this.appInfo = appInfo;
	}

	public String getErrInfo() {
		return appStatusCode;
	}

	public void setErrInfo(String appStatusCode) {
		this.appStatusCode = appStatusCode;
	}

	public String getErrorResponseInfo(){
		return "{"
				+ "\"appStatusCode\":\""+ appStatusCode +"\","
				+ "\"appStatusMsg\":\""+ appStatusMsg +"\","
				+ "\"appInfo\":\""+ appInfo +"\","
				+ "\"X-ATT-UniqueTransactionId\":\""+ MessageId +"\","
				+ "\"transactionName\":\""+ transactionName +"\""
				+ "}";

	}

}