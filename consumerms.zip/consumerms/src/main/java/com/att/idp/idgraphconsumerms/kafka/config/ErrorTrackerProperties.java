package com.att.idp.idgraphconsumerms.kafka.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

@Getter
@Setter
@Validated
@ConfigurationProperties(prefix = "idgraph.error")
public class ErrorTrackerProperties {

    private int windowSeconds = 300;
    private int threshold = 20;
}
