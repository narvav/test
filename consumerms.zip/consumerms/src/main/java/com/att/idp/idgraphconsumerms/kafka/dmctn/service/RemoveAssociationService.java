package com.att.idp.idgraphconsumerms.kafka.dmctn.service;


import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker;
import com.att.idp.idgraphconsumerms.kafka.model.Association;
import com.att.idp.idgraphconsumerms.kafka.model.Subscriber;
import com.att.idp.idgraphconsumerms.model.UserAssociationChangeRequest;
import com.att.idp.idgraphconsumerms.oracle.helpers.MemberServiceDBHelper;
import com.att.idp.idgraphconsumerms.request.validator.RequestValidator;
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;
import org.jetbrains.annotations.NotNull;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service("terminated")
public class RemoveAssociationService implements BackendService {

    private static final Logger logger = LoggerFactory.getLogger(RemoveAssociationService.class);


    @Value("${apiclient.rest.ua.removeassociation.endpoint}")
    private String removeAssociationEndpoint;

    private final CosmosFailedEventsWriter cosmosFailedEventsWriter;
    private final GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker;
    private final ApiRestClient apiRestClient;
    private final MemberServiceDBHelper memberServiceDBHelper;

    @Autowired
    public RemoveAssociationService(ApiRestClient apiRestClient, MemberServiceDBHelper memberServiceDBHelper,
                                    CosmosFailedEventsWriter cosmosFailedEventsWriter,
                                    GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker) {
        this.apiRestClient = apiRestClient;
        this.memberServiceDBHelper = memberServiceDBHelper;
        this.cosmosFailedEventsWriter = cosmosFailedEventsWriter;
        this.gddnFailedEventCircuitBreaker = gddnFailedEventCircuitBreaker;
    }

    @Override
    public void execute(Subscriber subscriber, EventSource eventSource) {
        String phoneNumber = subscriber.getPhoneNumber();
        String eventName = (eventSource == EventSource.GDDN) 
            ? ConsumerConstants.GridGddnNotification.EVENT_GDDN_CANCEL_SUBSCRIBER
            : ConsumerConstants.GridGddnNotification.EVENT_CG_CANCEL_SUBSCRIBER;

        logger.info("RemoveAssociationService execute method called for subscriber: {} with source: {}", 
            ESAPI.encoder().encodeForHTML(phoneNumber), eventSource);

        // Circuit breaker: if pending failed events exist for this phone/category,
        // short-circuit directly to Cosmos to preserve sequenced processing order
        if (gddnFailedEventCircuitBreaker.shouldShortCircuit(phoneNumber, eventName)) {
            logger.warn("RemoveAssociationService: Circuit breaker OPEN for CTN={}. "
                            + "Saving directly to Cosmos without calling downstream API.",
                    ESAPI.encoder().encodeForHTML(phoneNumber));
            UserAssociationChangeRequest cbRequest = buildOutgoingRequest(subscriber, null);
            FailedEventUtil.saveFailedEventCircuitOpen(
                    cosmosFailedEventsWriter,
                    phoneNumber,
                    JsonService.getJsonFromObject(cbRequest),
                    eventName,
                    CErrorDefs.SYS_ERR,
                    ConsumerConstants.GridGddnNotification.ERROR_CIRCUIT_BREAKER_OPEN,
                    this.removeAssociationEndpoint,
                    ConsumerConstants.DmctnSubscriberChangeEvent.TRAN_TYPE_REMOVE_ASSOCIATION
            );
            return;
        }

        //We expect that the phone number is always present in the subscriber for this service
        Map<String, Object> validationResult = RequestValidator.validate(phoneNumber, ConsumerConstants.DmctnSubscriberChangeEvent.HEADER_CHANGETYPE_VALUE_PHONENUMBER);

        //BSSE Reverse migration scenario where CG sends termination reason code for terminated CTNs, we will acknowledge the event without further processing
        if (subscriber.getStatusChangeReason() != null &&
                subscriber.getStatusChangeReason().stream()
                        .anyMatch(reason -> ConsumerConstants.DmctnSubscriberChangeEvent.CG_CTN_TERMINATED_REASON_CODE.equalsIgnoreCase(reason.getName()))) {
            logger.info("CTN: {} has termination reason code from CG: {}, this event will be acknowledged without further action.", phoneNumber, ConsumerConstants.DmctnSubscriberChangeEvent.CG_CTN_TERMINATED_REASON_CODE);
            return;
        }

        String statusCode = (String) validationResult.get(MPSDefs.APP_STATUS_CODE);
        if (!CommonDefs.COMMON_SUCCESS.equals(statusCode)) {
            FailedEventUtil.saveFailedEventValidationFailed(
                    cosmosFailedEventsWriter,
                    phoneNumber,
                    JsonService.getJsonFromObject(subscriber),
                    eventName,
                    statusCode,
                    (String) validationResult.get(MPSDefs.APP_STATUS_MSG),
                    ConsumerConstants.ErrorDetails.VALIDATION_FAILED,
                    ConsumerConstants.DmctnSubscriberChangeEvent.TRAN_TYPE_REMOVE_ASSOCIATION
            );
            return;
        }

        String guid = null;
        Optional<String> guidOptional;
        UserAssociationChangeRequest outgoingRequest = null;

        try {

            guidOptional = memberServiceDBHelper.getGuidForGivenCTN(subscriber.getPhoneNumber());

            if (guidOptional.isEmpty() || guidOptional.get() == null || guidOptional.get().isEmpty()) {
                logger.error("No GUID found for CTN: {}", subscriber.getPhoneNumber());
                return;
            }

            guid = guidOptional.get();
            logger.info("Retrieved GUID: {} for CTN: {}", ESAPI.encoder().encodeForHTML(guid), ESAPI.encoder().encodeForHTML(subscriber.getPhoneNumber()));

            outgoingRequest = buildOutgoingRequest(subscriber, guid);
            apiRestClient.sendPostRequest(removeAssociationEndpoint, outgoingRequest, eventName);

        } catch (Exception e) {
            logger.error("Error retrieving GUID for CTN: {}: {}", subscriber.getPhoneNumber(), e.getMessage());
            outgoingRequest = buildOutgoingRequest(subscriber, guid);
            FailedEventUtil.saveFailedEventResolvingCategory(
                    cosmosFailedEventsWriter,
                    phoneNumber,
                    JsonService.getJsonFromObject(outgoingRequest),
                    eventName,
                    CErrorDefs.SYS_ERR,
                    e.getMessage(),
                    this.removeAssociationEndpoint,
                    ConsumerConstants.DmctnSubscriberChangeEvent.TRAN_TYPE_REMOVE_ASSOCIATION
            );
        }
    }

    private static @NotNull UserAssociationChangeRequest buildOutgoingRequest(Subscriber subscriber, String guid) {
        UserAssociationChangeRequest outgoingRequest = new UserAssociationChangeRequest();
        outgoingRequest.setGuid(guid);
        outgoingRequest.setSuppressNotification("N");

        Association association = new Association();
        association.setServiceName(ConsumerConstants.DmctnSubscriberChangeEvent.MOSUB);
        association.setInstanceId(subscriber.getPhoneNumber());

        outgoingRequest.setAssociationList(List.of(association));
        return outgoingRequest;
    }
}