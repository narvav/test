package com.att.idp.idgraphconsumerms.kafka.dmctn.service;

/**
 * Enum to distinguish the source of subscriber events for correct event name prefixing.
 * - GDDN: Events originating from GDDN Kafka topic (Event Hub) → use GDDN-prefixed event names
 * - CG: Events originating from CustomerGraph Kafka topic (Confluent) → use CG-prefixed event names
 */
public enum EventSource {
    /**
     * Events from GDDN (Event Hub topic: idgraph-gddn-subscribernotification-v1)
     */
    GDDN,
    
    /**
     * Events from CustomerGraph (Confluent topic: CustomerGraph_subscriber-v1)
     */
    CG
}
