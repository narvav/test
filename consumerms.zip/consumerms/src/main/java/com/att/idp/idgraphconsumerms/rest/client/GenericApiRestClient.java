package com.att.idp.idgraphconsumerms.rest.client;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails;
import com.att.idp.idgraphconsumerms.rest.model.APIDetails;
import com.att.idp.idgraphconsumerms.rest.model.APIRequestWrapper;
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil;
import com.att.mpsys.common.utils.CErrorDefs;
import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class GenericApiRestClient {

    @Autowired
    private CosmosFailedEventsWriter cosmosFailedEventsWriter;

    private final RestTemplate restTemplate;


    private static final Logger logger = LoggerFactory.getLogger(GenericApiRestClient.class);
    private static final int MAX_ATTEMPTS = 2;


    public GenericApiRestClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Retryable(maxAttempts = MAX_ATTEMPTS, retryFor = {HttpServerErrorException.class})
    public ResponseEntity<JsonNode> sendPostRequest(final APIRequestWrapper apiRequestWrapper) {
        logger.info("Invoking GenericApiRestClient.sendPostRequest with APIRequestWrapper: {}", sanitizeForLog(apiRequestWrapper != null ? apiRequestWrapper.toString() : "null"));
        ApiRequestContext ctx = extractApiRequestContext(apiRequestWrapper);

        APIDetails apiDetails = ctx.getApiDetails();
        String requestJson = ctx.getRequestJson();
        FailedEventDetails inputFailedEventDetails = ctx.getInputFailedEventDetails();
        Map<String, String> inputErrorDetails = ctx.getInputErrorDetails();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(ConsumerConstants.Keys.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString((apiDetails.getUsername() + ":" + apiDetails.getPassword()).getBytes()));
        headers.add(ConsumerConstants.Keys.X_ATT_CLIENTID, apiDetails.getXATTClientId());
        headers.add(ConsumerConstants.Keys.IDP_TRACE_ID, MDC.get(ConsumerConstants.Keys.IDP_TRACE_ID));
        HttpEntity<String> httpEntity = new HttpEntity<>(requestJson, headers);

        logger.info("Calling API url: {} with sanitized request payload", sanitizeForLog(apiDetails.getServerURI() + apiDetails.getApiEndpoint()));

        try {
            ResponseEntity<JsonNode> response = restTemplate.exchange(apiDetails.getServerURI() + apiDetails.getApiEndpoint(), apiDetails.getHttpMethod(), httpEntity, JsonNode.class);
            logger.info("Response from downstream API: {}", sanitizeForLog(response.getBody() != null ? response.getBody().toString() : "null"));
            if (!HttpStatus.OK.equals(response.getStatusCode())) {
                if (response.getStatusCode().is5xxServerError()) {
                    logger.error("Received 5xx Server Error from downstream API. Status: {}, AccountId: {}, Endpoint: {}",
                        sanitizeForLog(response.getStatusCode().toString()),
                        sanitizeForLog(inputFailedEventDetails.getAccountId()),
                        sanitizeForLog(apiDetails.getApiEndpoint()));
                    throw new HttpServerErrorException(response.getStatusCode(), "Received 5xx Server Error from API");
                }
                logger.error("Non-5xx error from downstream API. Status: {}, AccountId: {}, Endpoint: {}",
                    sanitizeForLog(response.getStatusCode().toString()),
                    sanitizeForLog(inputFailedEventDetails.getAccountId()),
                    sanitizeForLog(apiDetails.getApiEndpoint()));
                FailedEventUtil.saveFailedEvent(cosmosFailedEventsWriter, inputFailedEventDetails.getAccountId(), requestJson, inputFailedEventDetails.getEventName(),
                        CErrorDefs.ERR_INVALID_DATA, response.getStatusCode().toString(),
                        apiDetails.getApiEndpoint(), inputErrorDetails.get(ConsumerConstants.ErrorDetails.ACCOUNT_TYPE));
            }
        } catch (HttpServerErrorException e) {
            logger.error("Retryable 5xx exception in GenericApiRestClient. Will be retried up to {} times. Exception: {}", MAX_ATTEMPTS, sanitizeForLog(e.getMessage()));
            throw e;
        } catch (Exception e) {
            logger.error("Non-retryable exception in GenericApiRestClient: {}", sanitizeForLog(e.getMessage()));
            handleNonRetryableFailure(e, apiRequestWrapper, CErrorDefs.ERR_INVALID_DATA);
        }
        return null;
    }

    @Recover
    public ResponseEntity<JsonNode> recover(HttpServerErrorException e, APIRequestWrapper apiRequestWrapper) {
        logger.error("HttpServerErrorException in GenericApiRestClient, exhausted retries: {}", sanitizeForLog(e.getMessage()));
        handleNonRetryableFailure(e, apiRequestWrapper, CErrorDefs.SYS_ERR);
        return null;
    }

    private void handleNonRetryableFailure(Exception e, APIRequestWrapper apiRequestWrapper, String errorCode) {
        ApiRequestContext ctx = extractApiRequestContext(apiRequestWrapper);
        String responsePayload = extractResponsePayload(e);
        logger.error("Non-retryable failure in GenericApiRestClient. Exception: {}, ResponsePayload: {}", sanitizeForLog(e.getMessage()), sanitizeForLog(responsePayload));
        FailedEventUtil.saveFailedEvent(cosmosFailedEventsWriter, ctx.getInputFailedEventDetails().getAccountId(), ctx.getRequestJson(),
                ctx.getInputFailedEventDetails().getEventName(), errorCode, responsePayload, ctx.getApiDetails().getApiEndpoint(), ctx.inputErrorDetails.get(ConsumerConstants.ErrorDetails.ACCOUNT_TYPE));
    }

    private String extractResponsePayload(Exception e) {
        if (e instanceof HttpStatusCodeException httpStatusCodeException) {
            String responseBody = httpStatusCodeException.getResponseBodyAsString();
            if (responseBody != null && !responseBody.isBlank()) {
                return sanitizeForLog(responseBody);
            }
        }
        String exceptionMessage = e.getMessage();
        if (exceptionMessage != null && !exceptionMessage.isBlank()) {
            return exceptionMessage;
        }
        return e.getClass().getSimpleName();
    }

    private String sanitizeForLog(String input) {
        if (input == null) return null;
        return input.replaceAll("[\\r\\n]", " ");
    }

    /**
     * Holder for extracted API request context.
     */
    private static class ApiRequestContext {
        private final APIDetails apiDetails;
        private final String requestJson;
        private final FailedEventDetails inputFailedEventDetails;
        private final Map<String, String> inputErrorDetails;

        ApiRequestContext(APIRequestWrapper apiRequestWrapper) {
            this.apiDetails = apiRequestWrapper.getApiDetails();
            this.requestJson = apiRequestWrapper.getOutgoingAPIRequestJson();
            this.inputFailedEventDetails = apiRequestWrapper.getFailedEventDetails();
            this.inputErrorDetails = Optional.ofNullable(inputFailedEventDetails.getErrorDetails())
                    .orElse(new HashMap<>());
        }

        public APIDetails getApiDetails() {
            return apiDetails;
        }

        public String getRequestJson() {
            return requestJson;
        }

        public FailedEventDetails getInputFailedEventDetails() {
            return inputFailedEventDetails;
        }

        public Map<String, String> getInputErrorDetails() {
            return inputErrorDetails;
        }
    }

    /**
     * Extracts API request context from APIRequestWrapper.
     *
     * @param apiRequestWrapper the API request wrapper
     * @return ApiRequestContext containing all required fields
     */
    private ApiRequestContext extractApiRequestContext(APIRequestWrapper apiRequestWrapper) {
        return new ApiRequestContext(apiRequestWrapper);
    }


}