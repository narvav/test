package com.att.idp.idgraphconsumerms.kafka.dmctn.service;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.kafka.model.Subscriber;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class BackendServiceFactory {

    // private final Map<String, BackendService> serviceMap;

/*
    @Autowired
    public BackendServiceFactory(Map<String, BackendService> serviceMap) {
        this.serviceMap = serviceMap;
    }
*/

    @Autowired
    private ChangeAssociationStatusService changeAssociationStatusService;
    @Autowired
    private ChangeAssociationDataService changeAssociationDataService;
    @Autowired
    private RemoveAssociationService removeAssociationService;

    public BackendService getService(List<String> changeTypes, Subscriber subscriber) {

        BackendService service = null;

        if (changeTypes.contains(ConsumerConstants.DmctnSubscriberChangeEvent.HEADER_CHANGETYPE_VALUE_STATUS)) {
            String status = subscriber.getStatus();
            if (ConsumerConstants.DmctnSubscriberChangeEvent.SERVICE_STAUS_TERMINATED.equalsIgnoreCase(status) || ConsumerConstants.DmctnSubscriberChangeEvent.SERVICE_STAUS_CANCELLED.equalsIgnoreCase(status)) {
                service = removeAssociationService;
            } else if (ConsumerConstants.DmctnSubscriberChangeEvent.SERVICE_STAUS_ACTIVE.equalsIgnoreCase(status) || ConsumerConstants.DmctnSubscriberChangeEvent.SERVICE_STAUS_SUSPENDED.equalsIgnoreCase(status)) {
                service = changeAssociationStatusService;
            }
        }

        if (changeTypes.contains(ConsumerConstants.DmctnSubscriberChangeEvent.HEADER_CHANGETYPE_VALUE_PHONENUMBER)) {
            service = changeAssociationDataService;
        }

        return service;
    }
}