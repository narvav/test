package com.att.idp.idgraphconsumerms.utils;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails;
import com.att.idp.idgraphconsumerms.kafka.errorhandler.ErrorDetailsBuilder;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.att.idp.idgraph.db.cosmos.entity.FailedEventStatus;
import com.att.mpsys.common.utils.CErrorDefs;
import java.util.Map;

/**
 * Utility class for building and saving failed event details.
 */
public final class FailedEventUtil {

    private FailedEventUtil() {
        // Utility class
    }

    /**
     * Builds and saves failed event details.
     *
     * @param cosmosFailedEventsWriter the processor to save failed events
     * @param sourceBanId the source BAN ID
     * @param notificationJson the notification as JSON
     * @param eventType the event type
     * @param errorCode the error code
     * @param errorMessage the error message
     * @param failedEndpoint the failed endpoint
     * @param accountType the account type
     */
    public static void saveFailedEvent(
            CosmosFailedEventsWriter cosmosFailedEventsWriter,
            String sourceBanId,
            String notificationJson,
            String eventType,
            String errorCode,
            String errorMessage,
            String failedEndpoint,
            String accountType) {

        Map<String, String> errorDetails = ErrorDetailsBuilder.builder()
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_CODE, errorCode)
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_MESSAGE, errorMessage)
                .addDetail(ConsumerConstants.ErrorDetails.FAILED_ENDPOINT, failedEndpoint)
                .addDetail(ConsumerConstants.ErrorDetails.ACCOUNT_TYPE, accountType)
                .build();

        FailedEventDetails failedEventDetails = new FailedEventDetails(
                sourceBanId,
                notificationJson,
                eventType,
                errorDetails
        );
        cosmosFailedEventsWriter.saveFailedEventsToCosmos(failedEventDetails);
    }

    /**
     * Builds and saves failed event details with an explicit processedSvrUrl.
     * Use this overload when the target service URL differs from the default UA server URL
     * (e.g. OrchestrationWirelessApiRestClient uses the UR/UserRegistration server URL).
     *
     * @param processedSvrUrl the server URL to record against the failed event
     */
    public static void saveFailedEvent(
            CosmosFailedEventsWriter cosmosFailedEventsWriter,
            String sourceBanId,
            String notificationJson,
            String eventType,
            String errorCode,
            String errorMessage,
            String failedEndpoint,
            String accountType,
            String processedSvrUrl) {

        Map<String, String> errorDetails = ErrorDetailsBuilder.builder()
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_CODE, errorCode)
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_MESSAGE, errorMessage)
                .addDetail(ConsumerConstants.ErrorDetails.FAILED_ENDPOINT, failedEndpoint)
                .addDetail(ConsumerConstants.ErrorDetails.ACCOUNT_TYPE, accountType)
                .build();

        FailedEventDetails failedEventDetails = FailedEventDetails.builder()
                .accountId(sourceBanId)
                .requestPayload(notificationJson)
                .eventName(eventType)
                .processedSvrUrl(processedSvrUrl)
                .errorDetails(errorDetails)
                .build();
        cosmosFailedEventsWriter.saveFailedEventsToCosmos(failedEventDetails);
    }

    /**
     * Builds and saves failed event details with explicit eventCategory.
     * Use this overload for GDDN events where the category is known at the call site.
     */
    public static void saveFailedEventWithCategory(
            CosmosFailedEventsWriter cosmosFailedEventsWriter,
            String sourceBanId,
            String notificationJson,
            String eventType,
            String eventCategory,
            String errorCode,
            String errorMessage,
            String failedEndpoint,
            String accountType) {

        Map<String, String> errorDetails = ErrorDetailsBuilder.builder()
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_CODE, errorCode)
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_MESSAGE, errorMessage)
                .addDetail(ConsumerConstants.ErrorDetails.FAILED_ENDPOINT, failedEndpoint)
                .addDetail(ConsumerConstants.ErrorDetails.ACCOUNT_TYPE, accountType)
                .build();

        FailedEventDetails failedEventDetails = FailedEventDetails.builder()
                .accountId(sourceBanId)
                .requestPayload(notificationJson)
                .eventName(eventType)
                .eventCategory(eventCategory)
                .errorDetails(errorDetails)
                .build();
        cosmosFailedEventsWriter.saveFailedEventsToCosmos(failedEventDetails);
    }

    /**
     * Builds and saves failed event details with status=CIRCUIT_OPEN.
     * Use this overload when the circuit breaker has detected pending failed events
     * and the new event must be parked without calling the downstream API.
     */
    public static void saveFailedEventCircuitOpen(
            CosmosFailedEventsWriter cosmosFailedEventsWriter,
            String sourceBanId,
            String notificationJson,
            String eventType,
            String errorCode,
            String errorMessage,
            String failedEndpoint,
            String accountType) {

        String eventCategory = EventCategoryResolver.resolve(eventType).orElse(null);

        Map<String, String> errorDetails = ErrorDetailsBuilder.builder()
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_CODE, errorCode)
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_MESSAGE, errorMessage)
                .addDetail(ConsumerConstants.ErrorDetails.FAILED_ENDPOINT, failedEndpoint)
                .addDetail(ConsumerConstants.ErrorDetails.ACCOUNT_TYPE, accountType)
                .build();

        FailedEventDetails failedEventDetails = FailedEventDetails.builder()
                .accountId(sourceBanId)
                .requestPayload(notificationJson)
                .eventName(eventType)
                .eventCategory(eventCategory)
                .status(FailedEventStatus.CIRCUIT_OPEN.name())
                .errorDetails(errorDetails)
                .build();
        cosmosFailedEventsWriter.saveFailedEventsToCosmos(failedEventDetails);
    }

    /**
     * Builds and saves failed event details with status=CIRCUIT_OPEN and an explicit processedSvrUrl.
     * Use this overload when the circuit breaker is open and the target service URL differs from
     * the default UA server URL (e.g. OrchestrationWirelessService uses the UR server URL).
     *
     * @param processedSvrUrl the server URL to record against the failed event
     */
    public static void saveFailedEventCircuitOpen(
            CosmosFailedEventsWriter cosmosFailedEventsWriter,
            String sourceBanId,
            String notificationJson,
            String eventType,
            String errorCode,
            String errorMessage,
            String failedEndpoint,
            String accountType,
            String processedSvrUrl) {

        String eventCategory = EventCategoryResolver.resolve(eventType).orElse(null);

        Map<String, String> errorDetails = ErrorDetailsBuilder.builder()
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_CODE, errorCode)
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_MESSAGE, errorMessage)
                .addDetail(ConsumerConstants.ErrorDetails.FAILED_ENDPOINT, failedEndpoint)
                .addDetail(ConsumerConstants.ErrorDetails.ACCOUNT_TYPE, accountType)
                .build();

        FailedEventDetails failedEventDetails = FailedEventDetails.builder()
                .accountId(sourceBanId)
                .requestPayload(notificationJson)
                .eventName(eventType)
                .eventCategory(eventCategory)
                .status(FailedEventStatus.CIRCUIT_OPEN.name())
                .processedSvrUrl(processedSvrUrl)
                .errorDetails(errorDetails)
                .build();
        cosmosFailedEventsWriter.saveFailedEventsToCosmos(failedEventDetails);
    }

    /**
     * Builds and saves failed event details, auto-resolving eventCategory from eventName.
     * Use this overload for GDDN events in catch blocks where the category should be set
     * so the circuit breaker can detect pending events for subsequent events.
     */
    public static void saveFailedEventResolvingCategory(
            CosmosFailedEventsWriter cosmosFailedEventsWriter,
            String sourceBanId,
            String notificationJson,
            String eventType,
            String errorCode,
            String errorMessage,
            String failedEndpoint,
            String accountType) {

        String eventCategory = EventCategoryResolver.resolve(eventType).orElse(null);
        saveFailedEventWithCategory(cosmosFailedEventsWriter, sourceBanId, notificationJson,
                eventType, eventCategory, errorCode, errorMessage, failedEndpoint, accountType);
    }

    /**
     * Builds and saves failed event details, auto-resolving eventCategory from eventName,
     * with an explicit processedSvrUrl.
     * Use this overload when the target service URL differs from the default UA server URL
     * (e.g. OrchestrationWirelessService uses the UR server URL).
     *
     * @param processedSvrUrl the server URL to record against the failed event
     */
    public static void saveFailedEventResolvingCategory(
            CosmosFailedEventsWriter cosmosFailedEventsWriter,
            String sourceBanId,
            String notificationJson,
            String eventType,
            String errorCode,
            String errorMessage,
            String failedEndpoint,
            String accountType,
            String processedSvrUrl) {

        String eventCategory = EventCategoryResolver.resolve(eventType).orElse(null);

        Map<String, String> errorDetails = ErrorDetailsBuilder.builder()
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_CODE, errorCode)
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_MESSAGE, errorMessage)
                .addDetail(ConsumerConstants.ErrorDetails.FAILED_ENDPOINT, failedEndpoint)
                .addDetail(ConsumerConstants.ErrorDetails.ACCOUNT_TYPE, accountType)
                .build();

        FailedEventDetails failedEventDetails = FailedEventDetails.builder()
                .accountId(sourceBanId)
                .requestPayload(notificationJson)
                .eventName(eventType)
                .eventCategory(eventCategory)
                .processedSvrUrl(processedSvrUrl)
                .errorDetails(errorDetails)
                .build();
        cosmosFailedEventsWriter.saveFailedEventsToCosmos(failedEventDetails);
    }

    /**
     * Builds and saves failed event details with status=VALIDATION_FAILED.
     * Use this overload when the event fails input validation (e.g., blank phone number,
     * missing required field). These events are persisted for audit but never retried by batchms.
     */
    public static void saveFailedEventValidationFailed(
            CosmosFailedEventsWriter cosmosFailedEventsWriter,
            String sourceBanId,
            String notificationJson,
            String eventType,
            String errorCode,
            String errorMessage,
            String failedEndpoint,
            String accountType) {

        String eventCategory = EventCategoryResolver.resolve(eventType).orElse(null);

        Map<String, String> errorDetails = ErrorDetailsBuilder.builder()
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_CODE, errorCode)
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_MESSAGE, errorMessage)
                .addDetail(ConsumerConstants.ErrorDetails.FAILED_ENDPOINT, failedEndpoint)
                .addDetail(ConsumerConstants.ErrorDetails.ACCOUNT_TYPE, accountType)
                .build();

        FailedEventDetails failedEventDetails = FailedEventDetails.builder()
                .accountId(sourceBanId)
                .requestPayload(notificationJson)
                .eventName(eventType)
                .eventCategory(eventCategory)
                .status(FailedEventStatus.VALIDATION_FAILED.name())
                .errorDetails(errorDetails)
                .build();
        cosmosFailedEventsWriter.saveFailedEventsToCosmos(failedEventDetails);
    }

    /**
     * Builds and saves failed event details with conditional eventCategory based on transaction type.
     * Use this overload for UpdateAccount events where the category depends on transaction type
     * (UpdateFan → GDDNFanUpdate, UpdateWlsUnification → GDDNWlsUnification).
     */
    public static void saveFailedEventWithTransactionType(
            CosmosFailedEventsWriter cosmosFailedEventsWriter,
            String sourceBanId,
            String notificationJson,
            String eventType,
            String transactionType,
            String errorCode,
            String errorMessage,
            String failedEndpoint,
            String accountType) {

        String eventCategory = EventCategoryResolver.resolve(eventType, transactionType).orElse(null);

        Map<String, String> errorDetails = ErrorDetailsBuilder.builder()
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_CODE, errorCode)
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_MESSAGE, errorMessage)
                .addDetail(ConsumerConstants.ErrorDetails.FAILED_ENDPOINT, failedEndpoint)
                .addDetail(ConsumerConstants.ErrorDetails.ACCOUNT_TYPE, accountType)
                .build();

        FailedEventDetails failedEventDetails = FailedEventDetails.builder()
                .accountId(sourceBanId)
                .requestPayload(notificationJson)
                .eventName(eventType)
                .eventCategory(eventCategory)
                .errorDetails(errorDetails)
                .build();
        cosmosFailedEventsWriter.saveFailedEventsToCosmos(failedEventDetails);
    }
}
