package com.att.idp.idgraphconsumerms.kafka.dmctn.service;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Factory for resolving subscriber event types to their corresponding backend services.
 * Routes unprefixed event names (RestoreSubscriber, SuspendSubscriber, CancelSubscriber, ChangeData)
 * to the appropriate service implementation.
 */
@Component
public class SubscriberServiceFactory {

    @Autowired
    private ChangeAssociationStatusService changeAssociationStatusService;
    @Autowired
    private ChangeAssociationDataService changeAssociationDataService;
    @Autowired
    private RemoveAssociationService removeAssociationService;

    /**
     * Get the appropriate backend service for the given event type.
     *
     * @param eventType Unprefixed event type (e.g., "RestoreSubscriber", "SuspendSubscriber", "CancelSubscriber", "ChangeData")
     * @return The corresponding BackendService implementation, or null if event type is not supported
     */
    public BackendService getService(String eventType) {

        BackendService service = null;
        if(eventType.equalsIgnoreCase(
                ConsumerConstants.SubscriberNotificationConstants.RESTORE_SUBSCRIBER ) || eventType.equalsIgnoreCase(
                ConsumerConstants.SubscriberNotificationConstants.SUSPEND_SUBSCRIBER )){
            service = changeAssociationStatusService;
        }else if(eventType.equalsIgnoreCase(ConsumerConstants.SubscriberNotificationConstants.CHANGE_DATA)) {
            service =  changeAssociationDataService;
        }else if(eventType.equalsIgnoreCase(ConsumerConstants.SubscriberNotificationConstants.CANCEL_SUBSCRIBER)) {
            service =  removeAssociationService;
        }

        return service;
    }
}