package com.att.idp.idgraphconsumerms.rest.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpMethod;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class APIDetails {

    private String serverURI;// e.g., https://api.att.com
    private String apiEndpoint;// e.g., /v1/idgraph
    private HttpMethod httpMethod;// GET, POST, etc.
    private String username;
    private String password;
    private String xATTClientId;// x-ATT-ClientId header value
}
