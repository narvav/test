package com.att.idp.idgraphconsumerms.kafka.dmctn.service;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.kafka.model.AccountNotificationEvent;
import org.springframework.stereotype.Component;

@Component
public class RGPHOServiceFactory {

    private final OrchestrationWirelessService changeProductNotificationService;
    private final DeletePlatformHandlerNotificationService deletePlatformHandlerNotificationService;
    private final RGActivationNotificationService rgActivationNotificationService;

    public RGPHOServiceFactory(OrchestrationWirelessService changeProductNotificationService,
                               DeletePlatformHandlerNotificationService deletePlatformHandlerNotificationService,
                               RGActivationNotificationService rgActivationNotificationService) {
        this.changeProductNotificationService = changeProductNotificationService;
        this.deletePlatformHandlerNotificationService = deletePlatformHandlerNotificationService;
        this.rgActivationNotificationService = rgActivationNotificationService;
    }

    public BaseService<AccountNotificationEvent> getService(String eventType) {

        BaseService<AccountNotificationEvent> service = null;
        if(eventType.equalsIgnoreCase(ConsumerConstants.ProductNotificationConstants.EVENT_TYPE_PRODUCT_CHANGE) ) {
            service = changeProductNotificationService;
        }else if(eventType.equalsIgnoreCase(ConsumerConstants.ProductNotificationConstants.EVENT_TYPE_RG_NOTIFICATION)) {
           service = rgActivationNotificationService;
        }else if(eventType.equalsIgnoreCase(ConsumerConstants.ProductNotificationConstants.EVENT_TYPE_PLATFORM_HANDLER)) {
            service = deletePlatformHandlerNotificationService;
        }else {
            return null;
        }

        return service;
    }
}