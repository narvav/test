package com.att.idp.idgraphconsumerms.utils;


import static org.apache.commons.lang3.StringUtils.isBlank;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;

/**
 * Utility class used to create and handle Json string. It facilitates
 * conversion from Object to Json String and from Json String to Object.
 */
public final class JsonService {

	private static final Logger LOGGER = LoggerFactory.getLogger(JsonService.class);

	private static final ObjectMapper MAPPER;

	private JsonService() {

	}

	static {
		MAPPER = new ObjectMapper();
		MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		MAPPER.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		MAPPER.setSerializationInclusion(Include.NON_NULL);
		MAPPER.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
		
		MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		MAPPER.setPropertyNamingStrategy(PropertyNamingStrategies.LOWER_CAMEL_CASE);
		MAPPER.setSerializationInclusion(Include.NON_NULL);
		MAPPER.setSerializationInclusion(Include.NON_EMPTY);
		MAPPER.configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true);
		MAPPER.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		MAPPER.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		MAPPER.enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES);
		MAPPER.enable(DeserializationFeature.READ_ENUMS_USING_TO_STRING);
		MAPPER.configure(MapperFeature.AUTO_DETECT_SETTERS, true);
		
	}

	/**
	 * Takes an object as parameter and converts it into json string format like
	 * {"dataValue":"Data Value","cloudType":"cart"}.
	 *
	 * @param object
	 *            holds the object which need to be converted into json string
	 * @return Json String 
	 */
	public static String getJsonFromObject(final Object object) {
		String jsonString = null;
		try {
			jsonString = MAPPER.writeValueAsString(object);
		} catch (JsonProcessingException jex) {
			LOGGER.error("JsonProcessingException occurred when converting  to Json from Object: " + jex);
		}

		return jsonString;
	}

	/**
	 * Takes an object as parameter and converts it into json string format like
	 * {"dataValue":"Data Value","cloudType":"cart"}.
	 *
	 * @param object
	 *            holds the object which need to be converted in json string
	 * @return Json String
	 */
	public static String getJsonWithPrettyPrintFromObject(final Object object) {
		String jsonString = null;
		try {
			jsonString = MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(object);
		} catch (JsonProcessingException jex) {
			LOGGER.error("JsonProcessingException occurred when converting Json with Pretty from Object: " + jex);
			//throw new ClientException(jex.getMessage(), shortenedStackTrace(jex, 1), 500);
		}

		return jsonString;
	}

	/**
	 * Takes Json object as parameter and converts the Json string as object of
	 * valueType.
	 *
	 * @param <T>
	 *            the generic type
	 * @param jsonString
	 *            holds the json string which needs to be converted in object
	 * @param valueType
	 *            describe the type in which json string needs to converted
	 * @return <T>
	 */

	public static <T> T getObjectFromJson(final Object jsonString, final Class<T> valueType) {
		T object = null;
		if (jsonString != null) {
			try {
				object = MAPPER.readValue(jsonString.toString(), valueType);
			} catch (IOException jex) {
				LOGGER.error("IOException occurred when converting Json to Object: " + jex);
			}
		}
		return object;
	}

	/**
	 * This method, shortenedStackTrace, is used to get a shortened version of the stack trace from an exception.
	 *
	 * It takes an Exception and an integer as parameters:
	 * - The Exception is the one from which the stack trace is to be obtained.
	 * - The integer specifies the maximum number of lines from the stack trace that should be included in the output.
	 *
	 * The method works by first writing the stack trace to a StringWriter, then splitting it into lines and appending the specified number of lines to a StringBuilder. The contents of the StringBuilder are then returned as a String.
	 *
	 * @param e the Exception from which the stack trace is to be obtained
	 * @param maxLines the maximum number of lines from the stack trace to include in the output
	 * @return a String containing the shortened stack trace
	 */
	public static String shortenedStackTrace(Exception e, int maxLines) {
		StringWriter writer = new StringWriter();
		e.printStackTrace(new PrintWriter(writer));
		String[] lines = writer.toString().split("\n");
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < Math.min(lines.length, maxLines); i++) {
			sb.append(lines[i]).append("\n");
		}
		return sb.toString();
	}

	/**
	 * Takes Json node as parameter and converts it into object of valueType.
	 *
	 * @param <T>
	 *            the generic type
	 * @param jsonNode
	 *            holds the json node which needs to be converted in object
	 * @param valueType
	 *            describe the type in which json node needs to converted
	 * @return <T>
	 */
	public static <T> T getObjectFromJsonNode(final JsonNode jsonNode, final Class<T> valueType) {
		T object = null;
		try {
			object = MAPPER.treeToValue(jsonNode, valueType);

		} catch (JsonProcessingException jex) {
			LOGGER.error("JsonProcessingException occurred when converting Json node to Object: " + jex);
		}

		return object;
	}
	
	public static ObjectMapper getMapper() {
		return MAPPER.copy();
	}

	/**
	 * This method, isValidJson, checks if the provided string is a valid JSON.
	 *
	 * It takes a string as input and uses the convertToJson method to try to convert it to a JsonNode.
	 * If the conversion is successful, the method returns true, indicating that the input string is a valid JSON.
	 * If the conversion fails, the method returns false, indicating that the input string is not a valid JSON.
	 *
	 * @param inputJson the string to be checked for validity as a JSON
	 * @return a boolean indicating whether the input string is a valid JSON
	 */
	public static boolean isValidJson(String inputJson) {
	    return convertToJson(inputJson) != null;
	}

	/**
	 * This method, convertToJson, attempts to convert a string into a JsonNode.
	 *
	 * It takes a string as input, which is expected to be a JSON string.
	 * The method uses the ObjectMapper's readTree method to try to parse the input string into a JsonNode.
	 * If the parsing is successful, the method returns the resulting JsonNode.
	 * If the parsing fails (i.e., if the input string is not a valid JSON), the method returns null.
	 *
	 * @param inputJson the string to be converted into a JsonNode
	 * @return a JsonNode representing the parsed JSON, or null if the input string is not a valid JSON
	 */
	public static JsonNode convertToJson(String inputJson) {
		if (isBlank(inputJson)) {
			return null;
		}

		try {
			return MAPPER.readTree(inputJson);
	    } catch (JsonProcessingException e) {
	    	LOGGER.error("JsonProcessingException occurred when converting  to Json from String: " + e);
	        return null;
	    }
	}

	/**
	 * This method, convertToObject, attempts to convert a JSON string into an object of a specified class.
	 *
	 * It takes two parameters:
	 * - A string, which is expected to be a JSON string.
	 * - A Class object, which represents the class to which the JSON string should be converted.
	 *
	 * The method first uses the convertToJson method to convert the input string into a JsonNode.
	 * It then uses the convertToObject method that takes a JsonNode and a Class as parameters to convert the JsonNode into an object of the specified class.
	 *
	 * If the conversion is successful, the method returns the resulting object.
	 * If the conversion fails (i.e., if the input string is not a valid JSON or if it cannot be converted into an object of the specified class), the method returns null.
	 *
	 * @param inputJson the string to be converted into an object
	 * @param theClass the Class object representing the class to which the JSON string should be converted
	 * @return an object of the specified class representing the parsed JSON, or null if the conversion fails
	 */
	public static <T> T convertToObject(String inputJson, Class<T> theClass) {
		JsonNode jsonNode = convertToJson(inputJson);
		return convertToObject(jsonNode, theClass);
	}

	/**
	 * This method, convertToObject, attempts to convert a JsonNode into an object of a specified class.
	 *
	 * It takes two parameters:
	 * - A JsonNode, which is expected to be a valid JSON node.
	 * - A Class object, which represents the class to which the JSON node should be converted.
	 *
	 * The method uses the ObjectMapper's readValue method to try to parse the JsonNode into an object of the specified class.
	 * If the parsing is successful, the method returns the resulting object.
	 * If the parsing fails (i.e., if the JsonNode cannot be converted into an object of the specified class), the method logs an error and returns null.
	 *
	 * @param jsonNode the JsonNode to be converted into an object
	 * @param theClass the Class object representing the class to which the JSON node should be converted
	 * @return an object of the specified class representing the parsed JSON node, or null if the conversion fails
	 */
	public static <T> T convertToObject(JsonNode jsonNode, Class<T> theClass) {
		if (jsonNode == null) {
			return null;
		}

		try {
			return MAPPER.readValue(jsonNode.toString(), theClass);
		} catch (Exception e) {
			String errorMsg = new StringBuilder().append("JSON Mapping Exception: Could not convert the input: [").append(jsonNode.toString()).append("] to object of Class: [").append(theClass.getName()).append("].").toString();
			LOGGER.error(StringUtils.normalizeSpace(errorMsg), e);
		}

		return null;
	}

	/**
	 * This method, toJsonString, converts an object into a JSON string.
	 *
	 * It takes an object as input, which can be any object.
	 * The method uses the ObjectMapper's writeValueAsString method to try to convert the input object into a JSON string.
	 * If the conversion is successful, the method returns the resulting JSON string.
	 * If the conversion fails (i.e., if the input object cannot be converted into a JSON string), the method logs an error and returns the string "EMPTY_JSON".
	 *
	 * @param obj the object to be converted into a JSON string
	 * @return a JSON string representing the input object, or "EMPTY_JSON" if the conversion fails
	 */
	public static String toJsonString(Object obj) {

		
		if (obj == null) {
			return "EMPTY_JSON";
		}

		try {
			return MAPPER.writeValueAsString(obj);
		} catch (Exception e) {
			String errorMsg = new StringBuilder().append("JSON Serialization Exception: Could not serialize the input object of Class: [").append(obj.getClass().getName()).append("]").toString();
			LOGGER.error(StringUtils.normalizeSpace(errorMsg), e);
		}

		return "EMPTY_JSON";
	}

}
