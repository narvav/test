package com.att.idp.idgraphconsumerms.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class OGraphConversionFailedEvent implements Serializable {

    @JsonProperty("eventId")
    private String eventId;

    @JsonProperty("eventType")
    private String eventType;

    @JsonProperty("eventTime")
    private String eventTime;

    @JsonProperty("eventTraceId")
    private String eventTraceId;

    @JsonProperty("event")
    private EventDetail event;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class EventDetail implements Serializable {
        @JsonProperty("billingAccountId")
        private String billingAccountId;

        @JsonProperty("individualId")
        private String individualId;

        @JsonProperty("customerId")
        private String customerId;

        @JsonProperty("productOrder")
        private ProductOrder productOrder;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ProductOrder implements Serializable {
        @JsonProperty("id")
        private String id;

        @JsonProperty("externalId")
        private String externalId;

        @JsonProperty("orderDate")
        private String orderDate;
    }
}
