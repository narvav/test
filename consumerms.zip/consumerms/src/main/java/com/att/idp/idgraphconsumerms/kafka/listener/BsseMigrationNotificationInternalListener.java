package com.att.idp.idgraphconsumerms.kafka.listener;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.kafka.model.MigrationBANNotification;
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.util.Random;

/**
 * Kafka listener for OAUTHBEARER SASL configuration.
 */
@Service
@RequiredArgsConstructor
public class BsseMigrationNotificationInternalListener {
    private static final Logger logger = LoggerFactory.getLogger(BsseMigrationNotificationInternalListener.class);
    private final ObjectMapper objectMapper = new ObjectMapper()
            .configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true)
            .enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
    private final BsseMigrationNotificationProcessor notificationProcessor;
    @KafkaListener(id = "idpMigrationNotificationInternalOAuthListener",
                    topics = "${idgraph.consumer.bssemigrationoauthinternal.topic}",
                    containerFactory = "bsseMigrationOAuthInternalConsumerContainerFactory",
                    groupId = "${idgraph.consumer.bssemigrationoauthinternal.group-id}",
                    concurrency = "${idgraph.consumer.bssemigrationoauthinternal.concurrency:1}",
                    autoStartup = "${idgraph.consumer.bssemigrationoauthinternal.autoStartup:false}")
    public void consumeMigrationBANNotification(@Payload String msg, @Headers MessageHeaders messageHeaders, Acknowledgment ack) throws JsonProcessingException {
        long startTm = System.currentTimeMillis();
        String traceId = this.generateTraceId();
        MDC.put(ConsumerConstants.Keys.IDP_TRACE_ID, traceId);
        try {
            MigrationBANNotification payload = objectMapper.readValue(msg, MigrationBANNotification.class);
            logger.info("messageheaders from consumeMigrationBANNotification Internal OAuth listener: {}, with the received payload: {}",
                    ConsumerUtil.encode(messageHeaders.toString()),
                    ConsumerUtil.encode(payload != null ? payload.toString() : "null"));
            if (payload != null && ConsumerConstants.BsseMigration.SERVICE_TYPE_REVERSE_WIRELESS.equalsIgnoreCase(payload.getServiceType())) {
                logger.info("Reverse Migration Event received on forward topic, acknowledging the event. migrationId: {}, eventId: {}",
                        ConsumerUtil.encode(payload.getMigrationId()),
                        ConsumerUtil.encode(payload.getEventId()));
                return;
            }
            notificationProcessor.processNotification(payload, msg, traceId, "BsseMigrationNotificationInternalListener");
            String sTimeTaken = ConsumerUtil.getElapsedTimeInSecs(startTm) + " seconds";
            logger.info("WEB999 : Total time taken : {} MigrationNotification Internal OAuth consumer Response : {}",
                    ConsumerUtil.encode(sTimeTaken),
                    ConsumerUtil.encode(payload != null ? payload.toString() : "null"));
            logger.info("CONSUMER_EVENT_SUCCESS: listenerId=idpMigrationNotificationInternalOAuthListener");
        } catch (JsonProcessingException e) {
            logger.error("Failed to deserialize message in MigrationBANNotification: Raw Message: {} | Exception: {}",
                    ConsumerUtil.encode(msg), ConsumerUtil.encode(e.getMessage()));
            logger.error("CONSUMER_EVENT_FAILED: listenerId=idpMigrationNotificationInternalOAuthListener, error={}", e.getMessage());
        } catch (Exception e){
            logger.error("Unexpected error in consumeMigrationBANNotification: Raw Message: {} | Exception: {}",
                    ConsumerUtil.encode(msg), ConsumerUtil.encode(e.getMessage()));
            logger.error("CONSUMER_EVENT_FAILED: listenerId=idpMigrationNotificationInternalOAuthListener, error={}", e.getMessage());
        } finally {
            logger.info("Committing the offset for the message");
            ack.acknowledge();
            MDC.clear();
        }
    }

    private String generateTraceId() {
        Random r = new Random();
        String spanId = Long.toHexString(r.nextLong());
        return spanId + ":" + spanId + ":0:0";
    }
}
