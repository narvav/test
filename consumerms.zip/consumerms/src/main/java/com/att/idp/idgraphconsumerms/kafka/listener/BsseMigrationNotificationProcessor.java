package com.att.idp.idgraphconsumerms.kafka.listener;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosMigrationStatusDBHelper;
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails;
import com.att.idp.idgraphconsumerms.helpers.BsseMigrationServiceHelper;
import com.att.idp.idgraphconsumerms.kafka.errorhandler.ErrorDetailsBuilder;
import com.att.idp.idgraphconsumerms.kafka.model.MigrationBANNotification;
import com.att.idp.idgraphconsumerms.request.validator.MigrationBANNotificationRequestValidator;
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Shared processor for BSSE Migration Notification listeners.
 * Encapsulates business logic to avoid duplication.
 */
@Service
@RequiredArgsConstructor
public class BsseMigrationNotificationProcessor {
    private static final Logger logger = LoggerFactory.getLogger(BsseMigrationNotificationProcessor.class);
    private final MigrationBANNotificationRequestValidator requestValidator;
    private final BsseMigrationServiceHelper processor;
    private final CosmosFailedEventsWriter cosmosFailedEventsWriter;
    private final CosmosMigrationStatusDBHelper cosmosMigrationStatusDBHelper;

    /**
     * Processes a MigrationBANNotification message with shared business logic.
     * @param payload the deserialized MigrationBANNotification
     * @param rawMsg the raw Kafka message
     * @param traceId the generated traceId for logging/MDC
     * @param listenerName the name of the calling listener (for logging)
     */
    public void processNotification(MigrationBANNotification payload, String rawMsg, String traceId, String listenerName) {
        String methodName = ".consumeMigrationBANNotification.";
        long startTm = System.currentTimeMillis();
        MDC.put(ConsumerConstants.Keys.IDP_TRACE_ID, traceId);
        MDC.put(ConsumerConstants.Keys.X_ATT_CLIENTID, ConsumerConstants.BsseMigration.CLIENT_BSSEMIPAAS);

        logger.info("[traceId={}] WEB000 : MigrationNotification consumer initiation: {}", ConsumerUtil.encode(traceId), ConsumerUtil.encode(payload != null ? payload.toString() : "null"));
        cosmosMigrationStatusDBHelper.storeBSSEMigrationStatus(payload, rawMsg);

        if (!ConsumerConstants.BsseMigration.MIGRATION_BAN_NOTIFICATION.equalsIgnoreCase(payload.getEventType()) ||
                !ConsumerConstants.BsseMigration.SUB_STATUS_COMMIT_ALL.equalsIgnoreCase(payload.getSubStatus()) ||
                !ConsumerConstants.BsseMigration.STATUS_INFLIGHT_PONR.equalsIgnoreCase(payload.getStatus()) ||
                "Y".equalsIgnoreCase(payload.getReplayFlag())) {
            logger.info("[traceId={}] Received message with eventType: {}, replayFlag: {}, subStatus: {}, and status: {}, and sourceBanId: {}. Acknowledging the message",
                    ConsumerUtil.encode(traceId),
                    ConsumerUtil.encode(payload.getEventType()),
                    ConsumerUtil.encode(payload.getReplayFlag()),
                    ConsumerUtil.encode(payload.getSubStatus()),
                    ConsumerUtil.encode(payload.getStatus()),
                    ConsumerUtil.encode(payload.getSourceBanId()));
            return;
        }

        boolean isFiber = ConsumerConstants.BsseMigration.SERVICE_TYPE_FIBER.equalsIgnoreCase(payload.getServiceType());
        if (isFiber) {
            payload.setSourceMarketCode("NA");
        }
        String accountType = isFiber
                ? ConsumerConstants.BsseMigration.ACCOUNT_TYPE_BSSEFIBER
                : ConsumerConstants.BsseMigration.ACCOUNT_TYPE_BSSEWIRELESS;
        String eventName = isFiber
                ? ConsumerConstants.BsseMigration.EVENT_BSSE_MIG_FIBER_FORWARD
                : ConsumerConstants.BsseMigration.EVENT_BSSE_MIG_WIRELESS;

        Map<String, Object> validationResult = requestValidator.validateMessage(payload);
        String statusCode = (String) validationResult.get(MPSDefs.APP_STATUS_CODE);

        if (CommonDefs.COMMON_SUCCESS.equals(statusCode)) {
            logger.info("[traceId={}] {}{}IDGAC.RM.03 : Validation successful, calling bsse migration api: {}", ConsumerUtil.encode(traceId), listenerName, methodName, ConsumerUtil.encode(payload != null ? payload.toString() : "null"));
        } else {
            String appInfo = "Validation failed for the received msg";
            logger.error("[traceId={}] {}{}IDGAC.RM.05 : {}:{}", ConsumerUtil.encode(traceId), listenerName, methodName, appInfo, ConsumerUtil.encode(payload != null ? payload.toString() : "null"));
            Map<String, String> errorDetails = ErrorDetailsBuilder.builder()
                    .addDetail(ConsumerConstants.ErrorDetails.ERROR_CODE, CErrorDefs.ERR_INVALID_DATA)
                    .addDetail(ConsumerConstants.ErrorDetails.ERROR_MESSAGE, CErrorDefs.ERR_INVALID_DATA_MSG + ":" + String.valueOf(validationResult.get(MPSDefs.APP_STATUS_MSG)))
                    .addDetail(ConsumerConstants.ErrorDetails.FAILED_ENDPOINT, ConsumerConstants.ErrorDetails.VALIDATION_FAILED)
                    .addDetail(ConsumerConstants.ErrorDetails.ACCOUNT_TYPE, accountType)
                    .build();
            FailedEventDetails failedEventDetails = new FailedEventDetails(
                    payload.getSourceBanId(),
                    JsonService.getJsonFromObject(payload),
                    eventName,
                    errorDetails
            );
            cosmosFailedEventsWriter.saveFailedEventsToCosmos(failedEventDetails);
        }

        processor.callBSSEMigrationService(payload);

        String sTimeTaken = ConsumerUtil.getElapsedTimeInSecs(startTm) + " seconds";
        logger.info("[traceId={}] WEB999 : Total time taken : {} MigrationNotification consumer Response : {}", ConsumerUtil.encode(traceId), ConsumerUtil.encode(sTimeTaken), ConsumerUtil.encode(payload != null ? payload.toString() : "null"));
        logger.info("[traceId={}] Committing the offset for the message", ConsumerUtil.encode(traceId));
    }
}
