package com.att.idp.idgraphconsumerms.kafka;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphconsumerms.constants.KafkaListenerConstants;
import com.att.idp.idgraphconsumerms.kafka.config.KafkaConsumerProperties;
import com.att.idp.idgraphconsumerms.kafka.config.KafkaConsumersConfig;
import com.att.idp.idgraphconsumerms.resource.response.KafkaListenerConnectionDetail;
import com.att.idp.idgraphconsumerms.resource.response.KafkaListenerStatusDetail;
import com.att.idp.idgraphconsumerms.resource.response.KafkaListenersResponse;

/**
 * This class, KafkaListenerAutomation, is responsible for managing Kafka listeners.
 * It uses Spring's @Component annotation, which means it is a candidate for Spring's
 * dependency injection. It is automatically detected during classpath scanning.
 *
 * It has a KafkaListenerEndpointRegistry instance variable for managing Kafka listeners. This object is autowired using Spring's @Autowired annotation.
 *
 * The class has two main methods: startListener and stopListener. 
 * The startListener method starts a Kafka listener with a given ID. It first retrieves the listener from the KafkaListenerEndpointRegistry, logs some information about it, and then starts it.
 * The stopListener method stops a Kafka listener with a given ID. It first retrieves the listener from the KafkaListenerEndpointRegistry, logs some information about it, and then stops it.
 */
@Component
public class KafkaListenerAutomation {

	private static final Logger logger = LoggerFactory.getLogger(KafkaListenerAutomation.class);
	private static String sClassName = "KafkaListenerAutomation";

	@Autowired
	private KafkaListenerEndpointRegistry kafkaListenerEndpointRegistry;

	@Autowired
	private KafkaConsumersConfig kafkaConsumersConfig;

	/**
	 * This method, startListener, is responsible for starting a Kafka listener with a given ID.
	 *
	 * It first retrieves the listener from the KafkaListenerEndpointRegistry using the listener's ID.
	 * It logs some information about the listener, including its class name and method name.
	 *
	 * The method then starts the listener using the MessageListenerContainer's start method.
	 * After the listener is started, it logs a message indicating that the listener has been started.
	 *
	 * @param listenerId The ID of the Kafka listener to be started.
	 * @return true if the listener is started successfully.
	 */
	public boolean startListener(String listenerId) {
		String sMethodName = ".startListener.";
		MessageListenerContainer listenerContainer = kafkaListenerEndpointRegistry.getListenerContainer(listenerId);
		logger.info("{}{}: MessageListenerContainer {} ", sClassName, sMethodName, listenerContainer);
		assert listenerContainer != null : false;
		listenerContainer.start();
		logger.info("{} Kafka Listener Started", StringUtils.normalizeSpace(listenerId));
		return true;
	}

	
	/**
	 * This method, stopListener, is responsible for stopping a Kafka listener with a given ID.
	 *
	 * It first retrieves the listener from the KafkaListenerEndpointRegistry using the listener's ID.
	 * It logs some information about the listener, including its class name and method name.
	 *
	 * The method then stops the listener using the MessageListenerContainer's stop method.
	 * After the listener is stopped, it logs a message indicating that the listener has been stopped.
	 *
	 * @param listenerId The ID of the Kafka listener to be stopped.
	 * @return true if the listener is stopped successfully.
	 */
	public boolean stopListener(String listenerId) {
		String sMethodName = ".stopListener.";
		MessageListenerContainer listenerContainer = kafkaListenerEndpointRegistry.getListenerContainer(listenerId);
		logger.info("{}{}: MessageListenerContainer {} ", sClassName, sMethodName, listenerContainer);
		assert listenerContainer != null : false;
		listenerContainer.stop();
		logger.info("{} Kafka Listener Stopped.", StringUtils.normalizeSpace(listenerId));
		return true;
	}

	/**
	 * Lists all Kafka listener IDs and their running status on this pod.
	 *
	 * @return a list of strings with listener ID and status (RUNNING/STOPPED)
	 */
	public java.util.List<String> listAllListenersWithStatus() {
		java.util.List<String> result = new java.util.ArrayList<>();
		for (String id : kafkaListenerEndpointRegistry.getListenerContainerIds()) {
			MessageListenerContainer container = kafkaListenerEndpointRegistry.getListenerContainer(id);
			boolean running = container != null && container.isRunning();
			result.add(id + " : " + (running ? "RUNNING" : "STOPPED"));
		}
		return result;
	}

	public KafkaListenersResponse getKafkaListenersResponse() {
		List<KafkaListenerStatusDetail> listeners = new ArrayList<>();
		List<KafkaListenerConnectionDetail> listenerDetails = new ArrayList<>();
		Map<String, String> listenerConsumerMappings = getListenerConsumerMappings();

		for (String listenerId : kafkaListenerEndpointRegistry.getListenerContainerIds()) {
			MessageListenerContainer container = kafkaListenerEndpointRegistry.getListenerContainer(listenerId);
			boolean running = container != null && container.isRunning();
			String status = running ? KafkaListenerConstants.STATUS_RUNNING : KafkaListenerConstants.STATUS_STOPPED;
			listeners.add(KafkaListenerStatusDetail.builder()
					.listenerId(listenerId)
					.status(status)
					.running(running)
					.build());
			listenerDetails.add(buildConnectionDetail(listenerId, running, status, listenerConsumerMappings.get(listenerId)));
		}

		return KafkaListenersResponse.builder()
				.listeners(listeners)
				.listenerDetails(listenerDetails)
				.build();
	}

	private KafkaListenerConnectionDetail buildConnectionDetail(String listenerId, boolean running, String status,
			String consumerName) {
		KafkaConsumerProperties properties = getKafkaConsumerProperties(consumerName);
		if (properties == null) {
			return KafkaListenerConnectionDetail.builder()
					.listenerId(listenerId)
					.consumerName(consumerName)
					.running(running)
					.status(status)
					.build();
		}

		return KafkaListenerConnectionDetail.builder()
				.listenerId(listenerId)
				.consumerName(properties.getConsumerName())
				.topic(properties.getTopic())
				.bootstrapServers(properties.getBootstrapServers())
				.groupId(properties.getGroupId())
				.securityProtocol(properties.getSecurityProtocol())
				.saslMechanism(properties.getSaslMechanism())
				.autoStartup(properties.getAutoStartup())
				.concurrency(properties.getConcurrency())
				.autoOffsetReset(properties.getAutoOffsetReset())
				.maxPollRecords(properties.getMaxPollRecords())
				.maxPollIntervalMs(properties.getMaxPollIntervalMs())
				.authExceptionRetryInterval(properties.getAuthExceptionRetryInterval())
				.logicalCluster(properties.getLogicalCluster())
				.poolId(properties.getPoolId())
				.running(running)
				.status(status)
				.build();
	}

	private KafkaConsumerProperties getKafkaConsumerProperties(String consumerName) {
		if (consumerName == null || kafkaConsumersConfig == null || kafkaConsumersConfig.getConsumer() == null) {
			return null;
		}

		return kafkaConsumersConfig.getConsumer().values().stream()
				.filter(properties -> consumerName.equalsIgnoreCase(properties.getConsumerName()))
				.findFirst()
				.orElse(null);
	}

	private Map<String, String> getListenerConsumerMappings() {
		Map<String, String> mappings = new HashMap<>();
		mappings.put(KafkaListenerConstants.LISTENER_ACCOUNT_NOTIFICATION,
				KafkaListenerConstants.CONSUMER_ACCOUNT_NOTIFICATION);
		mappings.put(KafkaListenerConstants.LISTENER_SUBSCRIBER_NOTIFICATION,
				KafkaListenerConstants.CONSUMER_SUBSCRIBER_NOTIFICATION);
		mappings.put(KafkaListenerConstants.LISTENER_PRODUCT_NOTIFICATION,
				KafkaListenerConstants.CONSUMER_PRODUCT_NOTIFICATION);
		mappings.put(KafkaListenerConstants.LISTENER_EXTERNAL_EVENTS,
				KafkaListenerConstants.CONSUMER_EXTERNAL_EVENTS);
		mappings.put(KafkaListenerConstants.LISTENER_BSSE_MIGRATION_OAUTH,
				KafkaListenerConstants.CONSUMER_BSSE_MIGRATION_OAUTH);
		mappings.put(KafkaListenerConstants.LISTENER_BSSE_MIGRATION_INTERNAL,
				KafkaListenerConstants.CONSUMER_BSSE_MIGRATION_INTERNAL);
		mappings.put(KafkaListenerConstants.LISTENER_BSSE_REVERSE_MIGRATION_OAUTH,
				KafkaListenerConstants.CONSUMER_BSSE_REVERSE_MIGRATION_OAUTH);
		mappings.put(KafkaListenerConstants.LISTENER_BSSE_REVERSE_MIGRATION_INTERNAL,
				KafkaListenerConstants.CONSUMER_BSSE_REVERSE_MIGRATION_INTERNAL);
		mappings.put(KafkaListenerConstants.LISTENER_CG_DMCTN, KafkaListenerConstants.CONSUMER_CG_DMCTN);
		mappings.put(KafkaListenerConstants.LISTENER_CG_INDIVIDUAL, KafkaListenerConstants.CONSUMER_CG_INDIVIDUAL);
		mappings.put(KafkaListenerConstants.LISTENER_ORDER_EVENTS, KafkaListenerConstants.CONSUMER_ORDER_EVENTS);
		mappings.put(KafkaListenerConstants.LISTENER_CG_CLOSE_ACCOUNT, KafkaListenerConstants.CONSUMER_CG_CLOSE_ACCOUNT);
		mappings.put(KafkaListenerConstants.LISTENER_NOTES_ORACLE_EVENTS,
				KafkaListenerConstants.CONSUMER_NOTES_ORACLE_EVENTS);
		mappings.put(KafkaListenerConstants.LISTENER_NOTES_PROFILE_UPDATE,
				KafkaListenerConstants.CONSUMER_NOTES_PROFILE_UPDATE);
		mappings.put(KafkaListenerConstants.LISTENER_NOTES_USERID_NOTIFICATIONS,
				KafkaListenerConstants.CONSUMER_NOTES_USERID_NOTIFICATIONS);
		return Collections.unmodifiableMap(mappings);
	}

}
