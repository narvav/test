package com.att.idp.idgraphconsumerms.cosmos.nosql.config;

import com.att.idp.idgraphconsumerms.appconfig.config.IDGraphAzureAppConfig;
import com.azure.cosmos.CosmosAsyncClient;
import com.azure.cosmos.CosmosClientBuilder;
import com.azure.cosmos.GatewayConnectionConfig;
import com.azure.cosmos.ThrottlingRetryOptions;
import com.azure.spring.data.cosmos.CosmosFactory;
import com.azure.spring.data.cosmos.config.AbstractCosmosConfiguration;
import com.azure.spring.data.cosmos.config.CosmosConfig;
import com.azure.spring.data.cosmos.core.CosmosTemplate;
import com.azure.spring.data.cosmos.core.ReactiveCosmosTemplate;
import com.azure.spring.data.cosmos.core.ResponseDiagnostics;
import com.azure.spring.data.cosmos.core.ResponseDiagnosticsProcessor;
import com.azure.spring.data.cosmos.core.convert.MappingCosmosConverter;
import com.azure.spring.data.cosmos.repository.config.EnableCosmosRepositories;
import com.azure.spring.data.cosmos.repository.config.EnableReactiveCosmosRepositories;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;
import org.springframework.context.event.EventListener;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;

import java.time.Duration;
import java.util.List;

/**
 * Configuration class for Cosmos DB.
 * Supports dynamic refresh of {@code azure.cosmos.nosql.db.idle-connection-timeout} and
 * {@code azure.cosmos.nosql.db.max-connection-pool-size} via {@link IDGraphAzureAppConfig}
 * ({@code @RefreshScope}). On {@link RefreshScopeRefreshedEvent} the active
 * {@link CosmosAsyncClient} and {@link ReactiveCosmosTemplate} are rebuilt with the
 * latest values without a pod restart.
 */
@Configuration
@ConditionalOnProperty(name = "azure.cosmos.nosql.enabled", havingValue = "false")
@EnableCosmosRepositories(basePackages = {"com.att.idp.idgraphconsumerms.cosmos.nosql.repository"})
@RequiredArgsConstructor
public class CosmosDbConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(CosmosDbConfig.class);

    /** Injected via constructor — carries @RefreshScope values for idle timeout and pool size. */
    private final IDGraphAzureAppConfig idGraphAzureAppConfig;

    /** Tracks the currently active async client so it can be closed on refresh. */
    private volatile CosmosAsyncClient activeClient;

    /**
     * Returns the currently tracked active client (for testing only).
     *
     * @return the active client, or null if none has been recorded
     */
    CosmosAsyncClient getActiveClient() {
        return this.activeClient;
    }

    // -------------------------------------------------------------------------
    // Static beans (no refresh required)
    // -------------------------------------------------------------------------

    /**
     * Creates a CosmosProperties bean.
     *
     * @return the CosmosProperties bean
     */
    @Bean(name = "cosmosNoSqlProperties")
    @Primary
    public CosmosProperties cosmosProperties() {
        return new CosmosProperties();
    }

    /**
     * Creates the initial {@link CosmosClientBuilder} bean, applying
     * {@code idle-connection-timeout} and {@code max-connection-pool-size} from
     * {@link IDGraphAzureAppConfig}.
     * <p>
     * This method only returns a builder and does not create a side-effect client.
     * The actual {@link CosmosAsyncClient} used by repositories is created in
     * {@link IdmDatabaseConfiguration#idmDatabaseTemplate(CosmosAsyncClient, CosmosConfig, MappingCosmosConverter)}.
     *
     * @param cosmosProperties the CosmosProperties bean
     * @return the CosmosClientBuilder bean (no side effects)
     */
     @Bean(name = "cosmosClientBuilder")
     @RefreshScope
     public CosmosClientBuilder primaryClientBuilder(CosmosProperties cosmosProperties) {
         CosmosClientBuilder builder = buildClientBuilder(cosmosProperties);
         LOGGER.info("CosmosClientBuilder created: uri={}, maxPoolSize={}, idleTimeoutMs={}",
                 cosmosProperties.getUri(),
                 idGraphAzureAppConfig.getMaxConnectionPoolSize(),
                 idGraphAzureAppConfig.getIdleConnectionTimeoutMs());
         return builder;
     }


    /**
     * Creates a CosmosConfig bean.
     *
     * @return the CosmosConfig bean
     */
    public CosmosConfig getCosmosConfig() {
        return CosmosConfig.builder()
                .enableQueryMetrics(true)
                .maxDegreeOfParallelism(0)
                .maxBufferedItemCount(0)
                .responseContinuationTokenLimitInKb(0)
                .responseDiagnosticsProcessor(new ResponseDiagnosticsProcessorImplementation())
                .build();
    }


    // -------------------------------------------------------------------------
    // Refresh listener — rebuilds client + template when Azure App Config pushes
    // new values for idle-connection-timeout or max-connection-pool-size
    // -------------------------------------------------------------------------

     /**
      * Logs refresh signal; actual client/template rebuild is handled by
      * {@code @RefreshScope} on {@code cosmosClientBuilder} and {@code idmDatabaseTemplate}.
      * <p>
      * The latest {@code idle-connection-timeout} and {@code max-connection-pool-size} values
      * are read from {@link IDGraphAzureAppConfig} which is annotated with
      * {@code @RefreshScope}, so they are already updated by the time this listener runs.
      *
      * @param event the refresh event (may be {@code null} in test scenarios)
      */
     @EventListener(RefreshScopeRefreshedEvent.class)
     public synchronized void onRefresh(RefreshScopeRefreshedEvent event) {
         List<String> preferredRegions = idGraphAzureAppConfig.getPreferredRegions();
         LOGGER.info("Refresh detected (name={}). cosmosClientBuilder/idmDatabaseTemplate will be reloaded with maxPoolSize={}, idleTimeoutMs={}, preferredRegionsCount={}",
                 event != null ? event.getName() : "<null>",
                 idGraphAzureAppConfig.getMaxConnectionPoolSize(),
                 idGraphAzureAppConfig.getIdleConnectionTimeoutMs(),
                 preferredRegions != null ? preferredRegions.size() : 0);
     }

    // -------------------------------------------------------------------------
    // Inner configuration — IDM database template
    // -------------------------------------------------------------------------

    /**
     * Configuration class for the IDM database.
     */
    @EnableReactiveCosmosRepositories(
            basePackages = {"com.att.idp.idgraphconsumerms.cosmos.nosql.repository"},
            reactiveCosmosTemplateRef = "idmDatabaseTemplate")
    public class IdmDatabaseConfiguration extends AbstractCosmosConfiguration {

        /**
         * Overrides default Cosmos async client creation and delegates directly to
         * {@link #createAsyncClient(CosmosClientBuilder)}.
         * <p>
         * This avoids reflection-based client initialization paths that can fail with
         * {@code java.lang.NoSuchFieldException: userAgentSuffix} in mixed SDK environments.
         *
         * @param cosmosClientBuilder the builder with endpoint, key and connection settings
         * @return the Cosmos async client created from the provided builder
         */
        @Bean
        @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
        public CosmosAsyncClient cosmosAsyncClient(CosmosClientBuilder cosmosClientBuilder) {
            LOGGER.info("Creating CosmosAsyncClient via direct builder invocation");
            return CosmosDbConfig.this.createAsyncClient(cosmosClientBuilder);
        }

        /**
         * Creates the reactive Cosmos template for the IDM usage database.
         * <p>
         * This bean is refresh-scoped so repositories continue using the same bean reference
         * while the underlying target is recreated with updated connection settings.
         *
         * @param cosmosAsyncClient      refreshed cosmos client bean
         * @param cosmosConfig           the Cosmos config bean
         * @param mappingCosmosConverter the converter bean
         * @return the ReactiveCosmosTemplate, or {@code null} if client is absent
         */
        @Bean
        @RefreshScope
        public synchronized ReactiveCosmosTemplate idmDatabaseTemplate(CosmosAsyncClient cosmosAsyncClient,
                                                                       CosmosConfig cosmosConfig,
                                                                       MappingCosmosConverter mappingCosmosConverter) {
            if (cosmosAsyncClient == null) {
                LOGGER.warn("CosmosAsyncClient is null, skipping ReactiveCosmosTemplate creation");
                return null;
            }
            CosmosAsyncClient oldClient = CosmosDbConfig.this.activeClient;
            CosmosDbConfig.this.activeClient = cosmosAsyncClient;
            LOGGER.info("Connecting to cosmos usage db: database={}, maxPoolSize={}, idleTimeoutMs={}",
                    cosmosProperties().getName(),
                    idGraphAzureAppConfig.getMaxConnectionPoolSize(),
                    idGraphAzureAppConfig.getIdleConnectionTimeoutMs());
            ReactiveCosmosTemplate template = new ReactiveCosmosTemplate(
                    cosmosAsyncClient, cosmosProperties().getName(), cosmosConfig, mappingCosmosConverter);
            if (oldClient != null && oldClient != cosmosAsyncClient) {
                try {
                    oldClient.close();
                } catch (Exception ex) {
                    LOGGER.warn("Failed to close old CosmosAsyncClient during template refresh", ex);
                }
            }
            return template;
        }

        @Override
        protected String getDatabaseName() {
            return cosmosProperties().getName();
        }

        /**
         * Overrides the default {@code cosmosTemplate} so shared library repositories that
         * inject {@code CosmosOperations} are wired with a compatible bean type.
         *
         * @param cosmosFactory          factory created from the configured async client
         * @param cosmosConfig           the Cosmos config bean
         * @param mappingCosmosConverter the converter bean
         * @return the non-reactive Cosmos template used by shared repositories
         */
        @Bean(name = "cosmosTemplate")
        @Primary
        @Override
        public CosmosTemplate cosmosTemplate(CosmosFactory cosmosFactory,
                                             CosmosConfig cosmosConfig,
                                             MappingCosmosConverter mappingCosmosConverter) {
            return new CosmosTemplate(cosmosFactory, cosmosConfig, mappingCosmosConverter);
        }
    }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    /**
     * Builds a {@link CosmosClientBuilder} applying the two refreshable connection settings
     * from {@link IDGraphAzureAppConfig}.
     *
     * @param cosmosProperties source of endpoint and key
     * @return configured builder (not yet built into a client)
     */
    private CosmosClientBuilder buildClientBuilder(CosmosProperties cosmosProperties) {
        int maxPoolSize  = idGraphAzureAppConfig.getMaxConnectionPoolSize();
        int idleTimeout  = idGraphAzureAppConfig.getIdleConnectionTimeoutMs();
        List<String> preferredRegions = idGraphAzureAppConfig.getPreferredRegions();

        GatewayConnectionConfig gatewayConnectionConfig = new GatewayConnectionConfig();
        gatewayConnectionConfig.setMaxConnectionPoolSize(maxPoolSize);
        gatewayConnectionConfig.setIdleConnectionTimeout(Duration.ofMillis(idleTimeout));

        ThrottlingRetryOptions throttlingRetryOptions = new ThrottlingRetryOptions();
        throttlingRetryOptions.setMaxRetryAttemptsOnThrottledRequests(3);
        throttlingRetryOptions.setMaxRetryWaitTime(Duration.ofSeconds(1L));

        LOGGER.info("Building CosmosClientBuilder: uri={}, maxPoolSize={}, idleTimeoutMs={}, preferredRegionsCount={}",
                cosmosProperties.getUri(), maxPoolSize, idleTimeout, preferredRegions != null ? preferredRegions.size() : 0);

        return new CosmosClientBuilder()
                .key(cosmosProperties.getKey())
                .endpoint(cosmosProperties.getUri())
                .preferredRegions(preferredRegions)
                .gatewayMode(gatewayConnectionConfig)
                .throttlingRetryOptions(throttlingRetryOptions);
    }

    CosmosAsyncClient createAsyncClient(CosmosClientBuilder builder) {
        return builder.contentResponseOnWriteEnabled(true).buildAsyncClient();
    }

    private static class ResponseDiagnosticsProcessorImplementation implements ResponseDiagnosticsProcessor {
        @Override
        public void processResponseDiagnostics(ResponseDiagnostics responseDiagnostics) {
            LOGGER.debug("Response Diagnostics {}", responseDiagnostics);
        }
    }
}