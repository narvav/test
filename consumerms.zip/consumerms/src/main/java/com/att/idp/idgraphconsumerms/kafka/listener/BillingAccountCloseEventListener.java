package com.att.idp.idgraphconsumerms.kafka.listener;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.constants.KafkaListenerConstants;
import com.att.idp.idgraphconsumerms.helpers.CloseAccountPasscodeProcessor;
import com.att.idp.idgraphconsumerms.kafka.model.BillingAccountStateChangeEvent;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import static com.att.idp.idgraphconsumerms.utils.ConsumerUtil.sanitizeForLog;

@Service
@RequiredArgsConstructor
public class BillingAccountCloseEventListener {

    private static final Logger logger = LoggerFactory.getLogger(BillingAccountCloseEventListener.class);

    private final CloseAccountPasscodeProcessor closeAccountPasscodeProcessor;
    private final ObjectMapper objectMapper;

    @KafkaListener(
            id = KafkaListenerConstants.LISTENER_CG_CLOSE_ACCOUNT,
            topics = "${idgraph.consumer.cgcloseaccountoauth.topic}",
            containerFactory = "cgCloseAccountOAuthConsumerContainerFactory",
            groupId = "${idgraph.consumer.cgcloseaccountoauth.group-id}",
            concurrency = "${idgraph.consumer.cgcloseaccountoauth.concurrency:1}",
            autoStartup = "${idgraph.consumer.cgcloseaccountoauth.autoStartup:false}"
    )
    public void consumeBillingAccountCloseEvent(@Payload String msg, Acknowledgment ack) {
        try {
            BillingAccountStateChangeEvent payload = objectMapper.readValue(msg, BillingAccountStateChangeEvent.class);
            MDC.put(ConsumerConstants.Keys.IDP_TRACE_ID, payload.getEventId());

            if (ConsumerConstants.BsseMigration.EVENT_TYPE_BILLING_ACCOUNT_STATE_CHANGE.equals(payload.getEventType())) {
                logger.info("Received BillingAccountStateChangeEvent for eventId: {}", sanitizeForLog(payload.getEventId()));
                boolean result = closeAccountPasscodeProcessor.process(msg);
                logger.info("CloseAccount processing result: {} for eventId: {}", result, sanitizeForLog(payload.getEventId()));
            } else {
                logger.debug("Skipping eventType: {} — not a BillingAccountStateChangeEvent", sanitizeForLog(payload.getEventType()));
            }
        } catch (Exception e) {
            logger.error("Failed to process BillingAccountCloseEvent message: {}", sanitizeForLog(e.getMessage()), e);
        } finally {
            ack.acknowledge();
            MDC.clear();
        }
    }
}
