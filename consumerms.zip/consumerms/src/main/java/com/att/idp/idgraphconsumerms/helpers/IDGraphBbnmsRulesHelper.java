package com.att.idp.idgraphconsumerms.helpers;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Helper class for BBNMS event filtering and event-name remapping.
 */
@Slf4j
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/consumer.properties")
public class IDGraphBbnmsRulesHelper extends BaseRuleHelper {

    private static final String CLASS_NAME = "IDGraphBbnmsRulesHelper";
    private static final String EVENT_NAME_KEY = "eventname";
    private static final String IS_SDP_MIGRATED_KEY = "isSDPMigrated";
    private static final String TARGET_EVENT_NAME_ADDRESSBOOK = "BBNMSAssignUverseAddressBookP2";
    private static final String TARGET_EVENT_NAME_ACTIVATETN = "BBNMSActivateTNP2";

    /**
     * Applies BBNMS routing rules.
     *
     * @param event source event data
     * @return true when the event should be published to BBNMS
     */
    public boolean processBbnmsMessage(Map<String, Object> event) {
        final String sMethodName = ".processBbnmsMessage";
        if (!isValidEventsData(event)) {
            log.info("{}{} IDGBRH.PBM.01: Event payload is empty", CLASS_NAME, sMethodName);
            return false;
        }

        String eventName = event.get(EVENT_NAME_KEY) != null ? event.get(EVENT_NAME_KEY).toString() : null;
        if (eventName == null || !ConsumerConstants.BbnmsConstants.SOURCE_EVENT_NAMES.contains(eventName)) {
            return false;
        }

        String isSdpMigrated = event.get(IS_SDP_MIGRATED_KEY) != null ? event.get(IS_SDP_MIGRATED_KEY).toString() : null;
        if (!"Y".equalsIgnoreCase(StringUtils.trimToEmpty(isSdpMigrated))) {
            log.info("{}{} IDGBRH.PBM.02: Skipping {} due to isSDPMigrated={}",
                    CLASS_NAME,
                    sMethodName,
                    eventName,
                    isSdpMigrated);
            return false;
        }

        if(eventName.equalsIgnoreCase("LSRegNotify")) {
            event.put(EVENT_NAME_KEY, TARGET_EVENT_NAME_ADDRESSBOOK);
            log.info("{}{} IDGBRH.PBM.03: Remapped eventname from {} to {}",
                    CLASS_NAME,
                    sMethodName,
                    eventName,
                    TARGET_EVENT_NAME_ADDRESSBOOK);
        }
        else if(eventName.equalsIgnoreCase("ActivateTNByBAN")) {
            event.put(EVENT_NAME_KEY, TARGET_EVENT_NAME_ACTIVATETN);
            log.info("{}{} IDGBRH.PBM.03: Remapped eventname from {} to {}",
                    CLASS_NAME,
                    sMethodName,
                    eventName,
                    TARGET_EVENT_NAME_ACTIVATETN);
        }

        return true;
    }
}

