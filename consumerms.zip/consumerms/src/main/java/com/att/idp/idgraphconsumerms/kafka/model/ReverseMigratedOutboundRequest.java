package com.att.idp.idgraphconsumerms.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * Represents a mobility migration request with access IDs and CTN list.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReverseMigratedOutboundRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private String productType;
    private String sourceBSSEBan;
    private String targetTLGBan;
    private String migrationId;
    private String iterationId;
    private String retryCounter;
    private String eventId;
    private String accountType;
    private String accountSubType;
    private List<AccessId> accessIDs;
    private List<Ctn> ctnList;

    /**
     * Represents an access ID entry.
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AccessId implements Serializable {
        private static final long serialVersionUID = 1L;
        private String guid;
        private String roleName;
        private String individualId;
    }

    /**
     * Represents a CTN (cellular telephone number) entry.
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Ctn implements Serializable {
        private static final long serialVersionUID = 1L;
        private String ctn;
        private String cgSubId;
        private String tlgSubId;
    }
}
