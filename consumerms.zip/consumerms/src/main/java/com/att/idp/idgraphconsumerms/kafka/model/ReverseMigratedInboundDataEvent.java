package com.att.idp.idgraphconsumerms.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Represents a Reverse Migrated Data event payload.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReverseMigratedInboundDataEvent implements MigrationEvent {

    /**
     * Type of the event.
     */
    private String eventType;

    /**
     * Unique event identifier.
     */
    private String eventId;

    /**
     * Event timestamp in ISO format.
     */
    private String eventTime;

    /**
     * Service type for the event.
     */
    private String serviceType;

    /**
     * Source BSSE BAN.
     */
    private String sourceBSSEBan;

    /**
     * Target TLG BAN.
     */
    private String targetTLGBan;

    /**
     * Migration identifier.
     */
    private String migrationId;

    /**
     * Iteration identifier.
     */
    private String iterationId;

    /**
     * GUID for the event.
     */
    private String guid;

    /**
     * Individual ID associated with this reverse migration event.
     */
    private String individualId;

    @JsonIgnore
    private String sourceTLGBan;

    @JsonIgnore
    private String targetBSSEBan;



    /**
     * Event details.
     */
    private EventDetails event;

    /**
     * Event details inner class.
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class EventDetails {

        /**
         * IDM attributes.
         */
        @JsonProperty("IDMAttributes")
        private IDMAttributes idmAttributes;

        /**
         * List of CAPM attributes.
         */
        @JsonProperty("CAPMAttributes")
        private List<CAPMAttributes> capmAttributes;

        /**
         * CFM attributes.
         */
        @JsonProperty("CFMAttributes")
        private CFMAttributes cfmAttributes;
    }

    /**
     * IDM attributes.
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class IDMAttributes {

        /**
         * Account type (e.g., "I" for Individual).
         */
        private String accountType;

        /**
         * Account sub-type (e.g., "R" for Regular).
         */
        private String accountSubType;

        /**
         * List of access IDs.
         */
        private List<AccessID> accessIDs;

        /**
         * List of CTN details.
         */
        private List<CtnDetail> ctnList;
    }

    /**
     * Access ID details.
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AccessID {

        /**
         * GUID for the access ID.
         */
        private String guid;

        /**
         * Role ID for the access.
         */
        private String roleId;

        /**
         * Individual ID associated with the access.
         */
        private String individualId;
    }

    /**
     * CTN detail.
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class CtnDetail {

        /**
         * CTN value.
         */
        private String ctn;

        /**
         * CG subscriber ID.
         */
        private String cgSubId;

        /**
         * TLG subscriber ID.
         */
        private String tlgSubId;
    }

    /**
     * CAPM attributes.
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class CAPMAttributes {

        /**
         * Individual ID.
         */
        private String individualId;

        /**
         * GUID.
         */
        private String guid;

        /**
         * Default payment method ID.
         */
        private String defaultPaymentMethodID;

        /**
         * Market code.
         */
        private String marketCode;
    }

    /**
     * CFM attributes (empty object).
     */
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class CFMAttributes {
        // No fields as per the provided JSON
    }

    @JsonIgnore
    @Override
    public String getSourceBan() {
        return this.sourceBSSEBan;
    }

    @JsonIgnore
    @Override
    public String getTargetBan() {
        return this.targetTLGBan;
    }

    @JsonIgnore
    @Override
    public String getOriginalRequestAsString() {
        return this.toString();
    }

    @JsonIgnore
    @Override
    public Object getOriginalRequest() {
        return this;
    }

    @JsonIgnore
    @Override
    public String getSubStatus() {
        return "";
    }

    @JsonIgnore
    @Override
    public String getStatus() {
        return "";
    }

}
