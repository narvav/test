/**
 *
 */
package com.att.idp.idgraphconsumerms.helpers;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.kafka.model.BsseMigrationRequest;
import com.att.idp.idgraphconsumerms.kafka.model.MigrationBANNotification;
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.att.mpsys.common.utils.CErrorDefs;
import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;
import java.util.Map;

@Service
public class BsseMigrationServiceHelper {

    @Value("${apiclient.rest.ua.serverUrl}")
    private String userAssoServerUrl;
    @Value("${apiclient.rest.ua.endpoint}")
    private String uaServiceEndPoint;
    @Value("${apiclient.rest.ua.username}")
    private String userName;
    @Value("${apiclient.rest.ua.password}")
    private String userPassword;

    private static final Logger logger = LoggerFactory.getLogger(BsseMigrationServiceHelper.class);
    private static final int MAX_ATTEMPTS = 2;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private CosmosFailedEventsWriter cosmosFailedEventsWriter;

    @Retryable(maxAttempts = MAX_ATTEMPTS, retryFor = {HttpServerErrorException.class})
    public void callBSSEMigrationService(MigrationBANNotification notification) {

        String resourceUri = this.userAssoServerUrl + this.uaServiceEndPoint;
        BsseMigrationRequest request = new BsseMigrationRequest();

        request.setBan(notification.getSourceBanId());
        request.setIndividualId(notification.getTargetIndividualId());
        boolean isFiber = ConsumerConstants.BsseMigration.SERVICE_TYPE_FIBER.equalsIgnoreCase(notification.getServiceType());
        String productType = isFiber
                ? ConsumerConstants.BsseMigration.UVERSE
                : ConsumerConstants.BsseMigration.MOBILITY;
        String accountType = isFiber
                ? ConsumerConstants.BsseMigration.ACCOUNT_TYPE_BSSEFIBER
                : ConsumerConstants.BsseMigration.ACCOUNT_TYPE_BSSEWIRELESS;
        String eventName = isFiber
                ? ConsumerConstants.BsseMigration.EVENT_BSSE_MIG_FIBER_FORWARD
                : ConsumerConstants.BsseMigration.EVENT_BSSE_MIG_WIRELESS;
        request.setProductType(productType);
        request.setMigrationId(notification.getMigrationId());
        request.setRetryCounter("0");
        request.setIdpTraceId(MDC.get(ConsumerConstants.Keys.IDP_TRACE_ID));
        request.setSourceMarketCode(notification.getSourceMarketCode());
        request.setGuid(notification.getGuid());
        request.setPasscodeVenc(notification.getPasscodeVenc());
        request.setTargetBan(notification.getTargetBanId());
        request.setEventId(notification.getEventId());

        String jsonObj = JsonService.getJsonFromObject(request);


        HttpHeaders reqheaders = new HttpHeaders();
        reqheaders.setContentType(MediaType.APPLICATION_JSON);
        reqheaders.add(ConsumerConstants.Keys.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString((this.userName + ":" + this.userPassword).getBytes()));
        reqheaders.add(ConsumerConstants.Keys.X_ATT_CLIENTID, ConsumerConstants.BsseMigration.CLIENT_BSSEMIPAAS);
        reqheaders.add(ConsumerConstants.Keys.IDP_TRACE_ID, MDC.get(ConsumerConstants.Keys.IDP_TRACE_ID));
        HttpEntity<?> httpEntity = new HttpEntity(jsonObj, reqheaders);

        logger.info("Calling IDGraphUserAssociationMs Rest endpoint URI: {} with this request : {}", resourceUri, request);
        ResponseEntity<JsonNode> response = null;
        String responseStatusCode = null;

        try {
            response = this.restTemplate.exchange(resourceUri, HttpMethod.POST, httpEntity, JsonNode.class);
            if (response != null) {
                responseStatusCode = response.getStatusCode().toString();
            }
            if (!HttpStatus.OK.equals(response.getStatusCode())) {
                FailedEventUtil.saveFailedEvent(cosmosFailedEventsWriter, notification.getSourceBanId(), JsonService.getJsonFromObject(notification), eventName, CErrorDefs.ERR_INVALID_DATA, responseStatusCode, uaServiceEndPoint, accountType);
                logger.error("Non-retryable error response received from IDGraphUserAssociationMs: {}", response.getStatusCode());
                return;
            }
            JsonNode jsonNode = (JsonNode) JsonService.getObjectFromJson(response.getBody(), JsonNode.class);
            logger.info("Response from IDGraphUserAssociationMs: {}", jsonNode);
        } catch (HttpServerErrorException e) {
            logger.error("Retryable exception while calling IDGraphUserAssociationMs. {} Will be retried for a max attemps of: {}", e, MAX_ATTEMPTS);
            throw e;
        } catch (Exception e) {
            logger.error("Non-retryable exception received: {}", e);
            FailedEventUtil.saveFailedEvent(cosmosFailedEventsWriter, notification.getSourceBanId(), JsonService.getJsonFromObject(notification), eventName, CErrorDefs.ERR_INVALID_DATA, responseStatusCode, uaServiceEndPoint, accountType);
        }
    }


    @Recover
    public void recover(HttpServerErrorException e, MigrationBANNotification notification) {
        //store in cosmos db
        logger.error("HttpServerErrorException while calling IDGraphUserAssociationMs from recover method, Exhausted retries : {}", e.getMessage());
        boolean isFiber = ConsumerConstants.BsseMigration.SERVICE_TYPE_FIBER.equalsIgnoreCase(notification.getServiceType());
        String accountType = isFiber
                ? ConsumerConstants.BsseMigration.ACCOUNT_TYPE_BSSEFIBER
                : ConsumerConstants.BsseMigration.ACCOUNT_TYPE_BSSEWIRELESS;
        String eventName = isFiber
                ? ConsumerConstants.BsseMigration.EVENT_BSSE_MIG_FIBER_FORWARD
                : ConsumerConstants.BsseMigration.EVENT_BSSE_MIG_WIRELESS;
        FailedEventUtil.saveFailedEvent(cosmosFailedEventsWriter, notification.getSourceBanId(), JsonService.getJsonFromObject(notification), eventName, CErrorDefs.SYS_ERR, e.getMessage(), uaServiceEndPoint, accountType);

    }
}
