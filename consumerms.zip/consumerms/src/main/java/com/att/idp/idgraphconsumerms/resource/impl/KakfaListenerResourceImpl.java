package com.att.idp.idgraphconsumerms.resource.impl;

import jakarta.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.att.idp.idgraphconsumerms.kafka.KafkaListenerAutomation;
import com.att.idp.idgraphconsumerms.resource.KakfaListenerResource;
import com.att.idp.idgraphconsumerms.resource.response.KafkaListenersResponse;

/**
 * This class, KakfaListenerResourceImpl, is an implementation of the KakfaListenerResource interface.
 *
 * It is annotated with @Controller, indicating that it's a Spring MVC Controller.
 *
 * The class contains two methods:
 * - start is a method that overrides the same method from the KakfaListenerResource interface. It takes a listenerId as input and starts the corresponding Kafka listener. It returns a Response object.
 * - stop is a method that overrides the same method from the KakfaListenerResource interface. It takes a listenerId as input and stops the corresponding Kafka listener. It returns a Response object.
 *
 * The class also contains a Logger instance, logger, for logging purposes, and a KafkaListenerAutomation instance, kafkaListenerAutomation, for controlling Kafka listeners.
 */
@Controller
public class KakfaListenerResourceImpl implements KakfaListenerResource {

	private static final Logger logger = LoggerFactory.getLogger(KakfaListenerResourceImpl.class);
	private static String sClassName = "KakfaListenerResourceImpl";

	@Autowired
	private KafkaListenerAutomation kafkaListenerAutomation;

	@Override
	public Response start(String listenerId) {
		String msg = null;
		String sMethodName = ".start.";
		try {
			kafkaListenerAutomation.startListener(listenerId);
			msg = "Started kafka listener successfully";
			logger.info("{}{}.{} ", sClassName, sMethodName, msg);
		} catch (Exception e) {
			logger.error("{}{}.Exception thrown while starting kafka listener : {} ", sClassName, sMethodName, e.getMessage());
		}
		return Response.ok(msg).build();

	}

	@Override
	public Response stop(String listenerId) {
		String msg = null;
		String sMethodName = ".stop.";
		try {
			kafkaListenerAutomation.stopListener(listenerId);
			msg = "Stopped kafka listener successfully";
			logger.info("{}{}.{} ", sClassName, sMethodName, msg);
		} catch (Exception e) {
			logger.error("{}{}.Exception thrown while stopping kafka listener : {} ", sClassName, sMethodName, e.getMessage());
		}
		return Response.ok(msg).build();

	}

	@Override
	public Response listListeners() {
		String sMethodName = ".listListeners.";
		try {
			KafkaListenersResponse listenersResponse = kafkaListenerAutomation.getKafkaListenersResponse();
			logger.info("{}{}.{}", sClassName, sMethodName, listenersResponse);
			return Response.ok(listenersResponse).build();
		} catch (Exception e) {
			logger.error("{}{}.Exception thrown while listing kafka listeners : {} ", sClassName, sMethodName, e.getMessage());
			return Response.serverError().entity("Error listing listeners").build();
		}
	}

}
