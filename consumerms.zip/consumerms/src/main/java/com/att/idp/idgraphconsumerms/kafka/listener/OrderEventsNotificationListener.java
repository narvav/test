package com.att.idp.idgraphconsumerms.kafka.listener;


import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.helpers.PasscodeProcessor;
import com.att.idp.idgraphconsumerms.kafka.model.OGraphConversionFailedEvent;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.util.Random;

@Service
public class OrderEventsNotificationListener {
    @Autowired
    private PasscodeProcessor credentialsProcessor;
    private static final Logger logger = LoggerFactory.getLogger(OrderEventsNotificationListener.class);
    public static final String SALES_PIVOT_CONVERSION_FAILED = "SALES-PIVOT-CONVERSION-FAILED";
    private final ObjectMapper objectMapper;


    public OrderEventsNotificationListener() {
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
        objectMapper.enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
    }

    @KafkaListener(
            id = "orderEventsNotificationListener",
            topics = "${idgraph.consumer.ordereventsconsumer.topic}",
            containerFactory = "orderEventsConsumerContainerFactory",
            groupId = "${idgraph.consumer.ordereventsconsumer.group-id}"
    )
    public void consumeOrderEventsNotification(
            @Payload String msg,
            @Headers MessageHeaders messageHeaders,
            Acknowledgment ack) {

        String traceId = this.generateTraceId();
        MDC.put(ConsumerConstants.Keys.IDP_TRACE_ID, traceId);
        try {
            logger.info("WEB000 : OrderEvents consumer initiation: {}", msg);
            logger.info("Received message headers: {}", messageHeaders);
            OGraphConversionFailedEvent payload = objectMapper.readValue(msg, OGraphConversionFailedEvent.class);
            logger.info("Deserialized Order Events Conversion Failed Event: {}", payload);
            if (payload.getEvent() != null) {
                if (!SALES_PIVOT_CONVERSION_FAILED.equals(payload.getEventType()) ) {
                    logger.info("Received message with eventType: {} that is not intended for this consumer ", payload.getEventType());
                    ack.acknowledge();
                    return;
                }
                logger.debug("Order Events Conversion Failed Event - IndividualId: {}", payload.getEvent().getIndividualId());
                String individualId = payload.getEvent().getIndividualId();
                if(!StringUtils.isEmpty(individualId)) {
                    credentialsProcessor.callUserAssociationDeleteCredService(individualId,
                            ConsumerConstants.BsseMigration.EVENT_ORDERGRAPH_FAILURE);
                }else{
                    logger.error("IndividualId is null or empty in the Order Events Conversion Failed Event: {}", payload);
                }
            }
            logger.info("CONSUMER_EVENT_SUCCESS: listenerId=orderEventsNotificationListener");
        } catch (Exception e) {
            logger.error("Failed to process message: {}", msg, e);
            logger.error("CONSUMER_EVENT_FAILED: listenerId=orderEventsNotificationListener, error={}", e.getMessage());
        } finally {
            logger.info("Acknowledging Kafka message");
            ack.acknowledge();
            MDC.clear();
        }
    }

    private String generateTraceId() {
        Random r = new Random();
        String spanId = Long.toHexString(r.nextLong());
        return spanId + ":" + spanId + ":0:0";
    }
}
