package com.att.idp.idgraphconsumerms.kafka.listener;

import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.stereotype.Component;

import com.att.idp.idgraphconsumerms.kafka.config.ErrorTrackerProperties;
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@EnableConfigurationProperties(ErrorTrackerProperties.class)
public class ListenerContainerManager {

    private final KafkaListenerEndpointRegistry registry;
    private final int windowSeconds;
    private final int threshold;
    private final ConcurrentHashMap<String, TransientErrorTracker> trackersByListener = new ConcurrentHashMap<>();

    public ListenerContainerManager(KafkaListenerEndpointRegistry registry,
                                    ErrorTrackerProperties properties) {
        this.registry = registry;
        this.windowSeconds = properties.getWindowSeconds();
        this.threshold = properties.getThreshold();
    }

    private TransientErrorTracker getOrCreateTracker(String listenerId) {
        return trackersByListener.computeIfAbsent(listenerId,
                id -> new TransientErrorTracker(windowSeconds, threshold));
    }

    /**
     * Records a transient error for the given listener and, if the configured threshold is breached,
     * pauses that specific listener container and resets the error counter.
     *
     * @param listenerId the id value from @KafkaListener of the target container
     */
    public void onTransientError(String listenerId) {
        TransientErrorTracker tracker = getOrCreateTracker(listenerId);
        boolean breached = tracker.recordErrorAndCheckThreshold();
        int currentCount = tracker.currentCount();
        log.info("NOTES_TRANSIENT_ERR: Transient error recorded for listener: {}. Current error count in window: {}",
                ConsumerUtil.sanitizeForLog(listenerId),
                currentCount);

        if (breached) {
            log.error("NOTES_LISTENER_PAUSED: Transient error threshold breached. Pausing listener: {}",
                    ConsumerUtil.sanitizeForLog(listenerId));
            pauseListenerContainer(listenerId);
            tracker.reset();
            log.info("Error tracker reset to zero after pausing listener: {}",
                    ConsumerUtil.sanitizeForLog(listenerId));
        }
    }

    private void pauseListenerContainer(String listenerId) {
        Collection<MessageListenerContainer> containers = registry.getAllListenerContainers();
        for (MessageListenerContainer container : containers) {
            if (container.getListenerId() != null
                    && container.getListenerId().equalsIgnoreCase(listenerId)
                    && container.isRunning()) {
                log.info("Pausing Kafka listener container: {}",
                        ConsumerUtil.sanitizeForLog(container.getListenerId()));
                container.pause();
            }
        }
    }

    TransientErrorTracker getErrorTracker(String listenerId) {
        return getOrCreateTracker(listenerId);
    }
}
