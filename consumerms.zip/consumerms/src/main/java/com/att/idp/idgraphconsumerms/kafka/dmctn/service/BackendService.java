package com.att.idp.idgraphconsumerms.kafka.dmctn.service;

import com.att.idp.idgraphconsumerms.kafka.model.Subscriber;
import com.att.idp.idgraphconsumerms.model.UserAssociationChangeRequest;

public interface BackendService {
    /**
     * Execute the backend service logic for the given subscriber.
     *
     * @param subscriber The subscriber data to process
     * @param eventSource The source of the event (GDDN or CG) to determine correct event name prefixing
     */
    void execute(Subscriber subscriber, EventSource eventSource);
}