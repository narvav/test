package com.att.idp.idgraphconsumerms.kafka.dmctn.service;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker;
import com.att.idp.idgraphconsumerms.kafka.model.AccountNotificationEvent;
import com.att.idp.idgraphconsumerms.model.ProvisionEnablerRequest;
import com.att.idp.idgraphconsumerms.model.ProvisionServiceEntry;
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.att.mpsys.common.utils.CErrorDefs;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProvisionEnablerNotificationService implements BaseService<AccountNotificationEvent> {

    private static final Logger logger = LoggerFactory.getLogger(ProvisionEnablerNotificationService.class);

    @Value("${apiclient.rest.ua.provisionenableracct.endpoint}")
    private String provisionEnablerEndpoint;

    private final ApiRestClient apiRestClient;
    private final CosmosFailedEventsWriter cosmosFailedEventsWriter;
    private final GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker;

    public ProvisionEnablerNotificationService(ApiRestClient apiRestClient,
                                               CosmosFailedEventsWriter cosmosFailedEventsWriter,
                                               GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker) {
        this.apiRestClient = apiRestClient;
        this.cosmosFailedEventsWriter = cosmosFailedEventsWriter;
        this.gddnFailedEventCircuitBreaker = gddnFailedEventCircuitBreaker;
    }

    @Override
    public void execute(AccountNotificationEvent accountNotificationEvent) {
        String titanBan = accountNotificationEvent.getTitanBan();
        String billingAccountNumber = accountNotificationEvent.getBillingAccountNumber();
        String eventName = ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT;

        // Circuit breaker: if pending failed events exist for this account/category,
        // short-circuit directly to Cosmos to preserve sequenced processing order
        if (!isBlank(titanBan) && gddnFailedEventCircuitBreaker.shouldShortCircuit(titanBan, eventName)) {
            logger.warn("ProvisionEnablerNotificationService: Circuit breaker OPEN for titanBan={}. "
                            + "Saving directly to Cosmos without calling downstream API.",
                    ESAPI.encoder().encodeForHTML(titanBan));
            FailedEventUtil.saveFailedEventCircuitOpen(
                    cosmosFailedEventsWriter,
                    titanBan,
                    JsonService.getJsonFromObject(accountNotificationEvent),
                    eventName,
                    CErrorDefs.SYS_ERR,
                    ConsumerConstants.GridGddnNotification.ERROR_CIRCUIT_BREAKER_OPEN,
                    provisionEnablerEndpoint,
                    ConsumerConstants.AccountNotificationConstants.GRID_GDDN
            );
            return;
        }

        try {
            if (isBlank(titanBan) || isBlank(billingAccountNumber)) {
                logger.error("Missing titanBan or BAN for ProvisionEnabler event. titanBanPresent={}, BanPresent={}, traceId={}",
                        !isBlank(titanBan),
                        !isBlank(billingAccountNumber),
                        ESAPI.encoder().encodeForHTML(accountNotificationEvent.getEventId()));
                FailedEventUtil.saveFailedEventValidationFailed(
                        cosmosFailedEventsWriter,
                        billingAccountNumber,
                        JsonService.getJsonFromObject(accountNotificationEvent),
                        eventName,
                        CErrorDefs.ERR_INVALID_DATA,
                        "titanBan and Ban are mandatory for ProvisionEnabler event",
                        ConsumerConstants.ErrorDetails.VALIDATION_FAILED,
                        ConsumerConstants.AccountNotificationConstants.WIRELESS
                );
                return;
            }

            ProvisionEnablerRequest outgoingRequest = buildOutgoingRequest(accountNotificationEvent);
            apiRestClient.sendPostRequest(provisionEnablerEndpoint, outgoingRequest, eventName);
        } catch (Exception e) {
            logger.error("Error processing ProvisionEnabler for BAN: {}", ESAPI.encoder().encodeForHTML(billingAccountNumber), e);
            FailedEventUtil.saveFailedEventResolvingCategory(
                    cosmosFailedEventsWriter,
                    titanBan,
                    JsonService.getJsonFromObject(accountNotificationEvent),
                    eventName,
                    CErrorDefs.SYS_ERR,
                    e.getMessage(),
                    provisionEnablerEndpoint,
                    ConsumerConstants.AccountNotificationConstants.WIRELESS
            );
        }
    }

    private static ProvisionEnablerRequest buildOutgoingRequest(AccountNotificationEvent event) {
        ProvisionServiceEntry serviceEntry = new ProvisionServiceEntry(
                ConsumerConstants.AccountNotificationConstants.MOBILITY,
                event.getBillingAccountNumber(),
                ConsumerConstants.AccountNotificationConstants.CONVERGE_PENDING_IND_NO
        );
        return new ProvisionEnablerRequest(event.getTitanBan(), List.of(serviceEntry));
    }

    private static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
