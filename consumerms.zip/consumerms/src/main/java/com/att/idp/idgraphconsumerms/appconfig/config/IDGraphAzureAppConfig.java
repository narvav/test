package com.att.idp.idgraphconsumerms.appconfig.config;

import jakarta.annotation.PostConstruct;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component("iDGraphAzureAppConfig")
@RefreshScope
@Getter
@Setter
public class IDGraphAzureAppConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(IDGraphAzureAppConfig.class);
    private static final int DEFAULT_IDLE_CONNECTION_TIMEOUT_MS = 5000;
    private static final int DEFAULT_MAX_CONNECTION_POOL_SIZE = 100;
    private static final String DEFAULT_PREFERRED_REGIONS_RAW = "East US 2, West US 2";

    @Value("${appconfig.version:0.0.0}")
    private String version;

    @Value("${appconfig.tomcat.jdbc.pool.max_size:${tomcat.jdbc.pool.max_size:100}}")
    private int maxSize;

    @Value("${appconfig.tomcat.jdbc.pool.min_size:${tomcat.jdbc.pool.min_size:5}}")
    private int minSize;

    @Value("${appconfig.tomcat.jdbc.pool.initial-size:${tomcat.jdbc.pool.initial-size:5}}")
    private int initialSize;

    @Value("${appconfig.tomcat.jdbc.pool.test-on-borrow:${tomcat.jdbc.pool.test-on-borrow:true}}")
    private boolean testOnBorrow;

    @Value("${appconfig.tomcat.jdbc.pool.test-while-idle:${tomcat.jdbc.pool.test-while-idle:true}}")
    private boolean testWhileIdle;

    @Value("${appconfig.tomcat.jdbc.pool.validation-query:${tomcat.jdbc.pool.validation-query:SELECT 1 FROM DUAL}}")
    private String validationQuery;

    @Value("${appconfig.tomcat.jdbc.pool.query-timeout:${tomcat.jdbc.pool.query-timeout:60}}")
    private int queryTimeout;

    @Value("${appconfig.tomcat.jdbc.pool.max-wait:${tomcat.jdbc.pool.max-wait:30000}}")
    private int connTimeout;

    @Value("${appconfig.tomcat.jdbc.pool.evictTime:${tomcat.jdbc.pool.evictTime:5000}}")
    private int evictTime;

    @Value("${appconfig.tomcat.datasource.refreshEnabled:${tomcat.datasource.refreshEnabled:false}}")
    private boolean dataSourceRefreshEnabled;

    @Value("${kafka.resiliency.use-unified-entity:false}")
    private boolean useUnifiedEntity;

    @Value("${environment.region:east}")
    private String environmentRegion;

    @Value("${kafka.event.record.container.name:idg_kafka_failed_events}")
    private String kafkaEventRecordContainerName;

    @Value("${kafka.event.record.ttl.seconds:604800}")
    private int kafkaEventRecordTtlSeconds;

    @Value("${idle-connection-timeout:5000}")
    private String idleConnectionTimeoutMsRaw;

    private int idleConnectionTimeoutMs;

    @Value("${max-connection-pool-size:100}")
    private String maxConnectionPoolSizeRaw;

    private int maxConnectionPoolSize;

    @Value("${spring.cloud.azure.cosmos.preferred-regions:East US 2, West US 2}")
    private String preferredRegionsRaw;

    private List<String> preferredRegions;

    @PostConstruct
    void initializeCosmosConnectionSettings() {
        idleConnectionTimeoutMs = parseIntegerOrDefault(
                idleConnectionTimeoutMsRaw,
                DEFAULT_IDLE_CONNECTION_TIMEOUT_MS,
                "idle-connection-timeout");
        maxConnectionPoolSize = parseIntegerOrDefault(
                maxConnectionPoolSizeRaw,
                DEFAULT_MAX_CONNECTION_POOL_SIZE,
                "max-connection-pool-size");
        preferredRegions = parsePreferredRegionsOrDefault(
                preferredRegionsRaw,
                DEFAULT_PREFERRED_REGIONS_RAW,
                "spring.cloud.azure.cosmos.preferred-regions");
    }

    private int parseIntegerOrDefault(String rawValue, int defaultValue, String propertyName) {
        if (rawValue == null || rawValue.isBlank()) {
            LOGGER.warn("{} is missing; using default value", propertyName);
            return defaultValue;
        }
        try {
            return Integer.parseInt(rawValue.trim());
        } catch (NumberFormatException ex) {
            LOGGER.warn("{} is not a valid integer; using default value", propertyName);
            return defaultValue;
        }
    }

    private List<String> parsePreferredRegionsOrDefault(String rawValue, String defaultRawValue, String propertyName) {
        String valueToParse = rawValue;
        if (rawValue == null || rawValue.isBlank()) {
            LOGGER.warn("{} is missing; using default value", propertyName);
            valueToParse = defaultRawValue;
        }

        List<String> parsedRegions = Arrays.stream(valueToParse.split(","))
                .map(String::trim)
                .filter(region -> !region.isBlank())
                .toList();

        if (parsedRegions.isEmpty()) {
            LOGGER.warn("{} did not contain valid values; using default value", propertyName);
            return Arrays.stream(defaultRawValue.split(","))
                    .map(String::trim)
                    .filter(region -> !region.isBlank())
                    .toList();
        }

        return parsedRegions;
    }

    @Value("${appconfig.logging.level.root:${logging.level.root:INFO}}")
    private String logLevelRoot;

    @Value("${appconfig.logging.level.com.att.idp:${logging.level.com.att.idp:DEBUG}}")
    private String logLevelIdp;

    @Value("${appconfig.logging.level.com.att.idp.logging:${logging.level.com.att.idp.logging:DEBUG}}")
    private String logLevelIdpApi;
}