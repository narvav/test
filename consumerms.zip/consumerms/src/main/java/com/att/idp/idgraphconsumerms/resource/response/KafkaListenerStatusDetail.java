package com.att.idp.idgraphconsumerms.resource.response;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class KafkaListenerStatusDetail {

    private final String listenerId;
    private final String status;
    private final Boolean running;
}
