package com.att.idp.idgraphconsumerms.helpers;

import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.util.ArrayList;
import java.util.Map;

/**
 * Helper class for processing LSCRM  event rules.
 * This class provides methods to validate and process LSCRM event messages based on configured rules and event data.
 * @author vn3904
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/consumer.properties")
public class IDGraphLSCRMRulesHelper extends BaseRuleHelper {

	@Value("${LSCRM_ADD_MEMBER}")
	private String lscrmSubEventsAddMember;

	@Value("${LSCRM_ADD_REMOVE_SVC_LIST}")
	private String lscrmSubEventsAddRemoveSvcList;

	@Value("${LSCRM_UPDATE_MEMBER}")
	private String lscrmSubEventsUpdateMember;

	@Value("${LSCRM_CREATE_INTERACTION}")
	private String lscrmSubEventsCreateInteraction;

	private static final String sClassName = "IDGraphLSCRMRulesHelper.";
	public static final Logger logger = LoggerFactory.getLogger(IDGraphLSCRMRulesHelper.class);

    /**
     * Processes an LSCRM event message by validating and applying event-specific rules.
     * @param event the event data as a map of key-value pairs
     * @return true if the event passes all validation and rule checks, false otherwise
     */
    public boolean processLSCRMMessage(Map<String, Object> event) {
        String stAppInfo = null;
        String sMethodName = ".processLSCRMMessageList.";
        boolean processLSCRMMsg=false;

		try {
			if (!isValidEventsData(event)) {
				stAppInfo = "Events data is null or empty";
				logger.error("{}{} IDGLSCRM.PLSCRM.01 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(stAppInfo));
				return false;
			}
			if (validateCommonRules(event) && processEventRules(event)) {
				processLSCRMMsg=true;
			}
		} catch (Exception e) {
			stAppInfo = "Exception thrown from processMessage ";
			logger.error("{}{} IDGLSCRM.PLSCRM.02 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(stAppInfo));
		}
		logger.info("{}{} HLP999 : hmResponse ", sClassName, sMethodName);
		return processLSCRMMsg;
	}

    /**
     * Validates common rules for LSCRM events, such as required fields.
     * @param event the event data as a map of key-value pairs
     * @return true if all common rules are satisfied, false otherwise
     */
    private boolean validateCommonRules(Map<String, Object> event) {
        String stAppInfo = null;
        boolean process=true;
        String sMethodName= ".validateCommonRules.";
        if (event.get("ban") == null)  {
            stAppInfo = "BAN does not exist";
            logger.error("{}{} IDGLSCRM.PLSCRM.03 : {}", sClassName, sMethodName,  HtmlUtils.htmlEscape(stAppInfo));
            process= false;
      		}
		return process;
	}

    /**
     * Processes event-specific rules for LSCRM events based on event name and sub-event.
     * @param event the event data as a map of key-value pairs
     * @return true if the event matches the configured rules, false otherwise
     */
    private boolean processEventRules(Map<String, Object> event) {
        String eventName = (String) event.get("eventname");
        String subEvent = (String) event.get("subEvent");
        boolean process=false;
        // LS CRM Event Rule:
        switch (eventName) {
            case "AddMember":
                ArrayList subEventListAddMember = CommonUtil.parseToArray(lscrmSubEventsAddMember, CommonDefs.VALUE_SEPARATOR_CHAR);
                if ( subEventListAddMember.contains(subEvent) &&	"P".equals(event.get("parent_child_ind"))) {
                    process = true;
                }
                break;
            case "AddRemoveServicesList":
                ArrayList subEventListAddRemoveSvcList = CommonUtil.parseToArray(lscrmSubEventsAddRemoveSvcList, CommonDefs.VALUE_SEPARATOR_CHAR);
                if (subEventListAddRemoveSvcList.contains(subEvent)) {
                    process = true;
                }
                break;
            case "UpdateMember":
                ArrayList subEventListUpdateMember = CommonUtil.parseToArray(lscrmSubEventsUpdateMember, CommonDefs.VALUE_SEPARATOR_CHAR);
                if (subEventListUpdateMember.contains(subEvent)) {
                    process = true;
                }
                break;
            case "CreateInteraction":
                ArrayList subEventListCreateInteraction = CommonUtil.parseToArray(lscrmSubEventsCreateInteraction, CommonDefs.VALUE_SEPARATOR_CHAR);
                boolean paperBillOpt = Boolean.TRUE.equals(event.get("paperBillOpt"));
                boolean primaryContactEmail = event.get("primaryContactEmail") != null;
                if (subEventListCreateInteraction.contains(subEvent) || (paperBillOpt && primaryContactEmail)) {
                    process = true;
                }
                break;
            default:
                return false;
        }
     return process;
	}
}
