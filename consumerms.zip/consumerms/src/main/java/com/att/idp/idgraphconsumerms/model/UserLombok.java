package com.att.idp.idgraphconsumerms.model;

import lombok.Data;

/**
 * This class, UserLombok, represents a user in the system.
 *
 * It is annotated with the @Data annotation from the Lombok library, which generates getters, setters, equals, hashCode, and toString methods for all fields.
 *
 * The class contains three instance variables:
 * - firstName is a string that represents the first name of the user.
 * - lastName is a string that represents the last name of the user.
 * - age is an integer that represents the age of the user.
 */
@Data
public class UserLombok {

	private String firstName;
    private String lastName;
    private int age;
}
