/**
 *
 */
package com.att.idp.idgraphconsumerms.utils;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import com.att.idp.idgraphconsumerms.kafka.model.DeliveryMethods;
import com.att.idp.idgraphconsumerms.kafka.model.PostalAddress;
import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.RILDefs;
import org.owasp.esapi.ESAPI;

/**
 * This is the ConsumerUtil class.
 * It is annotated as a Component in the Spring framework.
 * This class contains various utility methods that are used across the application.
 * These methods include response building, response generation, AES decryption, and more.
 * The class uses the LoggerFactory to log information, warnings, and errors.
 * It also uses various other classes and interfaces such as Response, SecretKeySpec, Cipher, and more.
 * The class contains methods for generating responses for different types of requests such as QueryByIPEligibility, UpdateUnifiedTOS, and more.
 * It also contains methods for error handling and generating appropriate responses in case of errors.
 */
@Component
public class ConsumerUtil {

	public static final Logger logger = LoggerFactory.getLogger(ConsumerUtil.class);

	/**
	 * Encodes a string for safe logging using ESAPI HTML encoding.
	 * Prevents log injection (CWE-117) by neutralizing CR/LF and special characters.
	 *
	 * @param value The value to encode
	 * @return The encoded value, or null if input is null
	 */
	public static String encode(String value) {
		return value == null ? null : ESAPI.encoder().encodeForHTML(value);
	}

	/**
	 * This method decrypts an encrypted string using the AES encryption algorithm.
	 * It uses the SecretKeySpec class from the javax.crypto.spec package to create a key specification for the AES algorithm.
	 * The key specification is created using the provided AES key.
	 * The method then uses the Cipher class from the javax.crypto package to decrypt the encrypted string.
	 * The decryption is done in the AES mode.
	 * If the encrypted string is empty, the method returns an empty string.
	 * If there is an exception during the decryption, the method logs the error and returns an empty string.
	 *
	 * @param encrypted The encrypted string to be decrypted. It is a hexadecimal string.
	 * @param propAes256Key The AES key to be used for the decryption. It is a hexadecimal string.
	 * @return The decrypted string. If there is an exception during the decryption, it returns an empty string.
	 */
	public static String getAESDecryption(String encrypted, String propAes256Key) {

		logger.info("In AESDecryption method");

		try {
			if (encrypted.isEmpty()) {
				logger.debug("GDPWD1 No config-value to decrypt. Returning an Empty-String...");
				return encrypted;
			}

			// Something's wrong if AES256Key is still null or empty
			if (propAes256Key == null || propAes256Key.length() == 0) {
				logger.error("AES256Key is null or empty");
			}

			logger.debug("AES256Key = {}", propAes256Key);

			byte[] raw = hexToByteArray(propAes256Key);

			// Create SecretKeySpec
			SecretKeySpec secretKeySpec = new SecretKeySpec(raw, RILDefs.ENCRYPT_AES);

			if (secretKeySpec == null) {
				logger.debug("GDPWD2 No {} is available for decryption. Returning an Empty-String...",
						CommonDefs.APP_AES256KEY);
				return "";
			}

			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.DECRYPT_MODE, secretKeySpec);

			byte[] decryptedBytes = cipher.doFinal(hexToByteArray(encrypted));
			return new String(decryptedBytes);
			// }

		} catch (Exception e) {
			logger.error("GDPWDEX1 Exception : {}.", e.getMessage());
			return "";
		}
	}

	/**
	 * This method converts a hexadecimal string into a byte array.
	 * It iterates over the hexadecimal string, taking two characters at a time (representing one byte),
	 * and converts these characters into the corresponding byte value.
	 * The resulting byte values are stored in a byte array.
	 * @param hex The hexadecimal string to be converted. Each pair of characters in the string represents one byte.
	 * @return A byte array containing the byte values corresponding to the input hexadecimal string.
	 */
	public static byte[] hexToByteArray(String hex) {
		byte[] bts = new byte[hex.length() / 2];
		for (int i = 0; i < bts.length; i++) {
			bts[i] = (byte) Integer.parseInt(hex.substring(2 * i, 2 * i + 2), 16);
		}
		return bts;
	}

	public static String generateAES256Value(String cleartext, String aes256key) {
		String thisMethod = "generateAES256Value";
		String generatedAES = null;
		String sDigest = null;
		String sErrMsg;
		String appInfo = null;
		try {


			byte[] raw = hexToByteArray(aes256key);

			// Create SecretKeySpec
			SecretKeySpec skeySpec = new SecretKeySpec(raw, CommonDefs.ENCRYPT_AES);

			// Instantiate the AES Cipher in encrypt mode
			Cipher cipher = Cipher.getInstance(CommonDefs.ENCRYPT_AES);

			cipher.init(Cipher.ENCRYPT_MODE, skeySpec);

			// Encrypt Clear Text using AES256 Cipher
			byte[] encrypted = cipher.doFinal(cleartext.getBytes());

			sDigest = asHex(encrypted);

		} catch (Exception e) {
			sErrMsg = "CommonHelper.ProofingEncryption_H.generateAES256Value.CH12:Exception::" + e.getMessage();
			logger.error("Exception : " + e.getMessage());
			logger.error("Exception : ={}", e);
			return sDigest;
		}
		return sDigest;
	}

	private static String asHex(byte buf[]) {
		StringBuffer strbuf = new StringBuffer(buf.length * 2);

		for (int i = 0; i < buf.length; i++) {
			if (((int) buf[i] & 0xff) < 0x10)
				strbuf.append("0");
			strbuf.append(Long.toString((int) buf[i] & 0xff, 16));
		}

		return strbuf.toString();
	}




	/**
	 * Calculates the elapsed time in seconds with millisecond precision
	 * since the given start time.
	 * This method computes the difference between the current system time
	 * and the provided start time, formats the result in seconds with
	 * three-digit millisecond precision, and returns it as a string.
	 * Example output: "5.123" (5 seconds and 123 milliseconds).
	 *
	 * @param startTime The start time in milliseconds (e.g., from System.currentTimeMillis()).
	 * @return A string representing the elapsed time in seconds with millisecond precision.
	 */
	public static String getElapsedTimeInSecs(long startTime) {

		StringBuffer sElapsedTime = new StringBuffer();

		long diff = (System.currentTimeMillis() - startTime);
		long ms = diff % 1000;

		sElapsedTime.append(diff / 1000).append('.'); // secs.

		if (ms < 10)
			sElapsedTime.append("00").append(ms); // 3 digits ms 0 padded
		else if (ms < 100)
			sElapsedTime.append('0').append(ms);
		else
			sElapsedTime.append(ms);

		return sElapsedTime.toString();
	}

	/**
	 * Builds a DeliveryMethods object from the input notification map.
	 * <p>
	 * This method constructs a DeliveryMethods instance based on the provided notification data.
	 * It checks for the presence of email address, instance ID, aoTN, and postal address to determine
	 * if a delivery method exists. If none are present, it logs an error.
	 * The method only creates a DeliveryMethods object if the "isCPNINotification" flag is set to "false".
	 * </p>
	 * @param hmClmInputNotification the input notification map containing delivery method data
	 * @return a populated DeliveryMethods object if applicable, otherwise null
	 */
	public static DeliveryMethods buildDeliveryMethods(Map<String, Object> hmClmInputNotification) {
		PostalAddress poAddress = null;
		DeliveryMethods deliveryMethods = null;
		if ("POSTAL".equalsIgnoreCase((String) hmClmInputNotification.get("communicationMode"))) {
			poAddress = buildPostalAddress(hmClmInputNotification);
		}
		if (hmClmInputNotification.get("isCPNINotification") != null && "false".equals(hmClmInputNotification.get("isCPNINotification"))) {

			if (hmClmInputNotification.get(CommonDefs.EMAIL_ADDRESS) == null
				&&  hmClmInputNotification.get("mainCTN") == null
				&&  hmClmInputNotification.get("aoTN") == null
				&&  (poAddress == null || poAddress.getAddress1() == null)) {
			logger.error("Data error: No delivery method exists, unable to publish.");
			//	throw new IllegalStateException("Data error: No delivery method exists, unable to publish.");
					}

			deliveryMethods = new DeliveryMethods(
					//if serviceType.equalsIgnoreCase("SMS"), pass null for email address and instanceId
					hmClmInputNotification.get(CommonDefs.EMAIL_ADDRESS) != null ? (String) hmClmInputNotification.get(CommonDefs.EMAIL_ADDRESS) : null,
					hmClmInputNotification.get("mainCTN") != null ? (String) hmClmInputNotification.get("mainCTN") :null,
					poAddress,
					null
			);

		}

		return deliveryMethods;
	}

	/**
	 * Builds a PostalAddress object from the input notification map.
	 * @param hmClmInputNotification the input notification map
	 * @return a populated PostalAddress object
	 */
	private static PostalAddress buildPostalAddress(Map<String, Object> hmClmInputNotification) {
		PostalAddress postalAddress = new PostalAddress();
		postalAddress.setBillingName(hmClmInputNotification.get("billingName") != null
				? (String) hmClmInputNotification.get("billingName") : "");
		postalAddress.setAddress1(hmClmInputNotification.get("address1") != null
				? (String) hmClmInputNotification.get("address1") : "");
		postalAddress.setAddress2(hmClmInputNotification.get("address2") != null
				? (String) hmClmInputNotification.get("address2") : "");
		postalAddress.setCity(hmClmInputNotification.get("city") != null
				? (String) hmClmInputNotification.get("city") : "");
		postalAddress.setState(hmClmInputNotification.get("state") != null
				? (String) hmClmInputNotification.get("state") : "");
		postalAddress.setCountry(hmClmInputNotification.get("country") != null
				? (String) hmClmInputNotification.get("country") : "");
		postalAddress.setZip5(hmClmInputNotification.get("zip5") != null
				? (String) hmClmInputNotification.get("zip5") : "");
		postalAddress.setZip4(hmClmInputNotification.get("zip4") != null
				? (String) hmClmInputNotification.get("zip4") : "");
		return postalAddress;
	}
	/**
	 * Sanitizes a string for safe logging by removing CR, LF, and other control characters.
	 */
	public static String sanitizeForLog(String input) {
		if (input == null) return null;
		// Maximum length to prevent log flooding and memory issues.
		int maxLen = 4096;
		String s = input.length() > maxLen ? input.substring(0, maxLen) + "…" : input;
		StringBuilder out = new StringBuilder(s.length());
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			// Explicitly neutralize line-breaking characters to prevent log forging.
			if (c == '\r') { out.append("\\r"); continue; }
			if (c == '\n') { out.append("\\n"); continue; }
			// Unicode line separators (can also break log parsing)
			if (c == '\u2028') { out.append("\\u2028"); continue; }
			if (c == '\u2029') { out.append("\\u2029"); continue; }
			// other control chars (includes ESC \u001B)
			if ((c < 0x20) || (c == 0x7F)) {
				out.append('?');
				continue;
			}
			out.append(c);
		}
		return out.toString();
	}

	/**
	 * Extracts all services from event data as a list of maps.
	 * Handles both List and Map structures for the services object.
	 * @param event the event data containing services information
	 * @return list of service maps, or null if not found or invalid structure
	 */
	public static List<Map<String, Object>> extractAllServicesWithFallback(Map<String, Object> event) {

		Object servicesObject = event.get(ConsumerConstants.SERVICES);
		String eventName = (String) event.get(ConsumerConstants.EVENT_NAME);

		if ((servicesObject == null || (servicesObject instanceof List<?> list && list.isEmpty()))
				&& ConsumerConstants.EVENT_ADD_REMOVE_SERVICES_LIST.equals(eventName)
				&& event.containsKey(ConsumerConstants.MEMBER_INFO)) {
			servicesObject = extractServicesFromMemberInfo(event);
		}

		if (servicesObject instanceof List<?> servicesList && !servicesList.isEmpty()) {
			List<Map<String, Object>> result = new ArrayList<>();
			for (Object service : servicesList) {
				if (service instanceof Map<?, ?> serviceMap) {
					result.add((Map<String, Object>) serviceMap);
				}
			}
			return result.isEmpty() ? null : result;
		}
		return null;
	}

	/**
	 * Extracts services using full fallback chain without event name restriction.
	 * Fallback order:
	 *   1. Root-level "services"
	 *   2. memberInfo[*].services
	 *   3. memberInfo[*].addServices or memberInfo[*].removeServices
	 * @param event the event data
	 * @return list of service maps, or null if not found
	 */
	@SuppressWarnings("unchecked")
	public static List<Map<String, Object>> extractServicesWithFullFallback(Map<String, Object> event) {
		Object servicesObject = event.get(ConsumerConstants.SERVICES);

		if (servicesObject instanceof List<?> servicesList && !servicesList.isEmpty()) {
			List<Map<String, Object>> result = new ArrayList<>();
			for (Object service : servicesList) {
				if (service instanceof Map<?, ?> serviceMap) {
					result.add((Map<String, Object>) serviceMap);
				}
			}
			if (!result.isEmpty()) return result;
		}

		if (event.containsKey(ConsumerConstants.MEMBER_INFO)) {
			return extractServicesFromMemberInfoFull(event);
		}
		return null;
	}

	/**
	 * Extracts services from memberInfo with full fallback:
	 *   1. memberInfo[*].services
	 *   2. memberInfo[*].addServices or memberInfo[*].removeServices
	 * @param event the event data containing memberInfo
	 * @return combined list of services, or null if not found
	 */
	@SuppressWarnings("unchecked")
	private static List<Map<String, Object>> extractServicesFromMemberInfoFull(Map<String, Object> event) {
		Object memberInfoObj = event.get(ConsumerConstants.MEMBER_INFO);
		if (!(memberInfoObj instanceof List<?> memberInfoList) || memberInfoList.isEmpty()) {
			return null;
		}

		List<Map<String, Object>> allServices = new ArrayList<>();
		for (Object memberObj : memberInfoList) {
			if (!(memberObj instanceof Map<?, ?> memberMap)) continue;
			Map<String, Object> member = (Map<String, Object>) memberMap;
			if (member.containsKey(ConsumerConstants.SERVICES)) {
				addServicesToList(member.get(ConsumerConstants.SERVICES), allServices);
			}
		}
		if (!allServices.isEmpty()) return allServices;

		for (Object memberObj : memberInfoList) {
			if (!(memberObj instanceof Map<?, ?> memberMap)) continue;
			Map<String, Object> member = (Map<String, Object>) memberMap;
			if (member.containsKey(ConsumerConstants.ADD_SERVICES)) {
				addServicesToList(member.get(ConsumerConstants.ADD_SERVICES), allServices);
			} else if (member.containsKey(ConsumerConstants.REMOVE_SERVICES)) {
				addServicesToList(member.get(ConsumerConstants.REMOVE_SERVICES), allServices);
			}
		}
		return allServices.isEmpty() ? null : allServices;
	}

	/**
	 * Extracts services from memberInfo list for AddRemoveServicesList events.
	 * Looks for addServices or removeServices within each memberInfo entry.
	 * @param event the event data containing memberInfo
	 * @return combined list of services from all memberInfo entries, or null if not found
	 */
	@SuppressWarnings("unchecked")
	private static List<Map<String, Object>> extractServicesFromMemberInfo(Map<String, Object> event) {

		Object memberInfoObj = event.get(ConsumerConstants.MEMBER_INFO);
		if (!(memberInfoObj instanceof List<?> memberInfoList) || memberInfoList.isEmpty()) {
			return null;
		}

		List<Map<String, Object>> allServices = new ArrayList<>();
		for (Object memberObj : memberInfoList) {
			if (!(memberObj instanceof Map<?, ?> memberMap)) {
				continue;
			}
			Map<String, Object> member = (Map<String, Object>) memberMap;

			// Extract addServices or removeServices if present

			if (member.containsKey(ConsumerConstants.ADD_SERVICES)) {
				Object addServicesObj = member.get(ConsumerConstants.ADD_SERVICES);
				addServicesToList(addServicesObj, allServices);
			} else  if(member.containsKey(ConsumerConstants.REMOVE_SERVICES)) {
				Object removeServicesObj = member.get(ConsumerConstants.REMOVE_SERVICES);
				addServicesToList(removeServicesObj, allServices);
			}
		}
		return allServices.isEmpty() ? null : allServices;
	}

	/**
	 * Helper method to add services from an object (List or Map) to the result list.
	 * @param servicesObj the services object (can be List or Map)
	 * @param resultList the list to add services to
	 */
	@SuppressWarnings("unchecked")
	private static void addServicesToList(Object servicesObj, List<Map<String, Object>> resultList) {
		if (servicesObj instanceof List<?> servicesList) {
			for (Object service : servicesList) {
				if (service instanceof Map<?, ?> serviceMap) {
					resultList.add((Map<String, Object>) serviceMap);
				}
			}
		} else if (servicesObj instanceof Map<?, ?> serviceMap) {
			resultList.add((Map<String, Object>) serviceMap);
		}
	}

	/**
	 * Validates services against business rules for AddRemoveServicesList processing.
	 * @param allServices list of services to validate
	 * @param addRemoveServicesList excluded services list
	 * @return true if all services pass validation, false otherwise
	 */
	public static boolean validateAddRemoveServices(List<Map<String, Object>> allServices, ArrayList addRemoveServicesList) {
		if (allServices != null) {
			for (Map<String, Object> service : allServices) {
				String serviceType = service != null ? (String) service.get(ConsumerConstants.SERVICE_TYPE) : null;
				if (serviceType != null) {
					// If service exists and is in allowed list, return true immediately
					if (addRemoveServicesList.contains(serviceType)) {
						return true;
					}
				}
			}
			// Return false only if we found services but NONE were in allowed list
			return false;
		}
		return true;
	}
}

