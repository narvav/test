package com.att.idp.idgraphconsumerms.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProvisionServiceEntry {
    private String serviceType;
    private String sorInvariantId;
    private String convergePendingInd;
}
