package com.att.idp.idgraphconsumerms.kafka.dmctn.service;


import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.kafka.model.Association;
import com.att.idp.idgraphconsumerms.kafka.model.Subscriber;
import com.att.idp.idgraphconsumerms.model.UserAssociationChangeRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class SubscriberCreateEventProcessor {

    private static final Logger logger = LoggerFactory.getLogger(SubscriberCreateEventProcessor.class);


    @Autowired
    private ChangeAssociationDataMigrationService changeAssociationDataMigrationService;

    public void processEvent(Subscriber subscriber, MessageHeaders headers) {
        MDC.put(ConsumerConstants.Keys.X_ATT_CLIENTID, ConsumerConstants.DmctnSubscriberChangeEvent.CLIENT_CUSTOMERGRAPH);
        String migratedOn = subscriber.getMigratedOn();
        if (migratedOn == null || migratedOn.isEmpty()) {
            logger.info("Received SubscriberCreateEvent for subscriber that is not migrated. Skipping processing. SubscriberId: {}", subscriber.getId());
            return;
        }

        logger.info("Processing SubscriberCreateEvent for migrated subscriber: {}, migratedOn: {}", subscriber.getId(), migratedOn);
        changeAssociationDataMigrationService.execute(subscriber, EventSource.CG);
        MDC.clear();
    }
}
