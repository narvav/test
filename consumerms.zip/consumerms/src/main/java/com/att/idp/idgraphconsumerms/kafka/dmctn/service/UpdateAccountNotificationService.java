package com.att.idp.idgraphconsumerms.kafka.dmctn.service;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker;
import com.att.idp.idgraphconsumerms.kafka.model.AccountNotificationEvent;
import com.att.idp.idgraphconsumerms.model.PlatformHandlerRequest;
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.att.mpsys.common.utils.CErrorDefs;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class UpdateAccountNotificationService implements BaseService<AccountNotificationEvent> {

    private static final Logger logger = LoggerFactory.getLogger(UpdateAccountNotificationService.class);

    @Value("${apiclient.rest.ua.platformhandler.endpoint}")
    private String platformHandlerEndpoint;

    @Autowired
    private CosmosFailedEventsWriter cosmosFailedEventsWriter;

    @Autowired
    private GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker;

    private final ApiRestClient apiRestClient;

    public UpdateAccountNotificationService(ApiRestClient apiRestClient) {
        this.apiRestClient = apiRestClient;
    }

    @Override
    public void execute(AccountNotificationEvent accountNotificationEvent) {
        String sourceBan = accountNotificationEvent.getBillingAccountNumber();
        String eventName = ConsumerConstants.GridGddnNotification.resolveEventName(accountNotificationEvent.getEventName());

        // Circuit breaker: short-circuit to Cosmos if pending failed events exist
        if (gddnFailedEventCircuitBreaker.shouldShortCircuit(sourceBan, eventName)) {
            logger.warn("UpdateAccountNotificationService: Circuit breaker OPEN for BAN={}. Saving directly to Cosmos.",
                    ESAPI.encoder().encodeForHTML(sourceBan));
            PlatformHandlerRequest cbRequest = buildOutgoingRequest(accountNotificationEvent);
            FailedEventUtil.saveFailedEventCircuitOpen(
                    cosmosFailedEventsWriter, sourceBan,
                    JsonService.getJsonFromObject(cbRequest), eventName,
                    CErrorDefs.SYS_ERR, "Circuit breaker open \u2014 pending failed events exist",
                    platformHandlerEndpoint, ConsumerConstants.AccountNotificationConstants.WIRELESS);
            return;
        }

        PlatformHandlerRequest outgoingRequest = buildOutgoingRequest(accountNotificationEvent);

        try {
            if (isBlank(accountNotificationEvent.getBillingAccountNumber()) || isBlank(accountNotificationEvent.getOldFan()) || isBlank(accountNotificationEvent.getNewFan())) {
                logger.error("Missing Ban/oldFan/newFan for UpdateAccount event. banPresent={}, oldFanPresent={}, newFanPresent={}, traceId={}",
                        !isBlank(accountNotificationEvent.getBillingAccountNumber()),
                        !isBlank(accountNotificationEvent.getOldFan()),
                        !isBlank(accountNotificationEvent.getNewFan()),
                        ESAPI.encoder().encodeForHTML(accountNotificationEvent.getEventId()));
                FailedEventUtil.saveFailedEventValidationFailed(
                        cosmosFailedEventsWriter,
                        sourceBan,
                        JsonService.getJsonFromObject(accountNotificationEvent),
                        eventName,
                        CErrorDefs.ERR_INVALID_DATA,
                        "billingAccountNumber, oldFan and newFan are mandatory for UpdateAccount",
                        ConsumerConstants.ErrorDetails.VALIDATION_FAILED,
                        ConsumerConstants.AccountNotificationConstants.WIRELESS
                );
                return;
            }

            apiRestClient.sendPostRequest(platformHandlerEndpoint, outgoingRequest, eventName);
        } catch (Exception e) {
            logger.error("Error processing UpdateAccount for billingAccountNumber: {}", ESAPI.encoder().encodeForHTML(sourceBan), e);
            FailedEventUtil.saveFailedEventResolvingCategory(
                    cosmosFailedEventsWriter,
                    sourceBan,
                    JsonService.getJsonFromObject(outgoingRequest),
                    eventName,
                    CErrorDefs.SYS_ERR,
                    e.getMessage(),
                    platformHandlerEndpoint,
                    ConsumerConstants.AccountNotificationConstants.WIRELESS
            );
        }
    }

    private static PlatformHandlerRequest buildOutgoingRequest(AccountNotificationEvent accountNotificationEvent) {
        PlatformHandlerRequest outgoingRequest = new PlatformHandlerRequest();
        outgoingRequest.setBan(accountNotificationEvent.getBillingAccountNumber());
        outgoingRequest.setOldFan(accountNotificationEvent.getOldFan());
        outgoingRequest.setNewFan(accountNotificationEvent.getNewFan());
        outgoingRequest.setTransactionType(ConsumerConstants.AccountNotificationConstants.UPDATE_FAN);
        outgoingRequest.setCallingSystemId(ConsumerConstants.DmctnSubscriberChangeEvent.CLIENT_ATLASBUS);
        outgoingRequest.setIdpTraceId(accountNotificationEvent.getEventId());
        return outgoingRequest;
    }

    private static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
