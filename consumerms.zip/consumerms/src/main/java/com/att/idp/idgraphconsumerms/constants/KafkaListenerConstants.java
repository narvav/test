package com.att.idp.idgraphconsumerms.constants;

public final class KafkaListenerConstants {

    public static final String STATUS_RUNNING = "RUNNING";
    public static final String STATUS_STOPPED = "STOPPED";

    public static final String LISTENER_ACCOUNT_NOTIFICATION = "accountNotificationEventListener";
    public static final String LISTENER_SUBSCRIBER_NOTIFICATION = "subscriberNotificationEventListener";
    public static final String LISTENER_PRODUCT_NOTIFICATION = "productNotificationEventListener";
    public static final String LISTENER_EXTERNAL_EVENTS = "idgraphExtEventsListener";
    public static final String LISTENER_BSSE_MIGRATION_OAUTH = "idpMigrationNotificationOAuthListener";
    public static final String LISTENER_BSSE_MIGRATION_INTERNAL = "idpMigrationNotificationInternalOAuthListener";
    public static final String LISTENER_BSSE_REVERSE_MIGRATION_OAUTH = "bsseRevMigEventOAuthListener";
    public static final String LISTENER_BSSE_REVERSE_MIGRATION_INTERNAL = "bsseRevMigEventOAuthInternalListener";
    public static final String LISTENER_CG_DMCTN = "dmctnSubChangeEventOAuthListener";
    public static final String LISTENER_CG_INDIVIDUAL = "individualAccountsCloseEventOAuthListener";
    public static final String LISTENER_ORDER_EVENTS = "orderEventsNotificationListener";

    public static final String CONSUMER_ACCOUNT_NOTIFICATION = "accountnotificationconsumer";
    public static final String CONSUMER_SUBSCRIBER_NOTIFICATION = "subscribernotificationconsumer";
    public static final String CONSUMER_PRODUCT_NOTIFICATION = "productnotificationconsumer";
    public static final String CONSUMER_EXTERNAL_EVENTS = "idgraphexternalevents";
    public static final String CONSUMER_BSSE_MIGRATION_OAUTH = "bssemigrationoauth";
    public static final String CONSUMER_BSSE_MIGRATION_INTERNAL = "bssemigrationoauthinternal";
    public static final String CONSUMER_BSSE_REVERSE_MIGRATION_OAUTH = "bssereversemigoauth";
    public static final String CONSUMER_BSSE_REVERSE_MIGRATION_INTERNAL = "bssereversemigoauthinternal";
    public static final String CONSUMER_CG_DMCTN = "cgdmctnoauth";
    public static final String CONSUMER_CG_INDIVIDUAL = "cgindividualoauth";
    public static final String CONSUMER_ORDER_EVENTS = "ordereventsconsumer";

    public static final String LISTENER_CG_CLOSE_ACCOUNT = "cgCloseAccountListener";
    public static final String CONSUMER_CG_CLOSE_ACCOUNT = "cgcloseaccountoauth";

    public static final String LISTENER_NOTES_ORACLE_EVENTS = "notesOracleEventsListener";
    public static final String LISTENER_NOTES_PROFILE_UPDATE = "notesProfileUpdateListener";
    public static final String LISTENER_NOTES_USERID_NOTIFICATIONS = "notesUserIdNotificationsListener";

    public static final String CONSUMER_NOTES_ORACLE_EVENTS = "notesoracleeventsconsumer";
    public static final String CONSUMER_NOTES_PROFILE_UPDATE = "notesprofileupdateconsumer";
    public static final String CONSUMER_NOTES_USERID_NOTIFICATIONS = "notesuseridnotificationsconsumer";

    private KafkaListenerConstants() {
    }
}
