package com.att.idp.idgraphconsumerms.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 *  *   "event": {
 *  *     "name": "Subscriber",
 *  *     "type": "CGSubscriberEvent",
 *  *     "resourceVersion": "1",
 *  *     "resourceIdentifier": "Subscriber",
 *  *     "subscriber": "{\"id\":\"019919b0-5fe3-76da-8d59-a0856d6f0571\",\"@type\":\"subscriber\",\"subscriberType\
 *  *     ":\"WIRELESS\",\"rootProductId\":\"30898851873012189\",\"status\":\"suspended\",\"statusChangeReason\":[{
 *  *     \"name\":\"WSU-CR\",\"date\":\"2025-09-06T00:01:14.392Z\"}],\"billingAccount\":\"553104420349\",\"phoneNumber\"
 *  *     :\"8583165341\",\"isSMSCapable\":\"N\",\"preferredCTN\":false,\"createdOn\":\"2025-09-05T11:44:08.982Z\",
 *  *     \"updatedOn\":\"2025-09-06T00:01:14.392Z\",\"contactMedium\":[{\"mediumType\":\"postalAddress\",\"characteristic\":
 *  *     {\"contactType\":\"ppu\",\"city\":\"CHULA VISTA\",\"country\":\"USA\",\"postCode\":\"91910-8013\",
 *  *     \"stateOrProvince\":\"CA\",\"street1\":\"458 ABETO DR\",\"place\":{\"id\":\"00000SLDX3\"},\"geocode\":\"050730630\"}}],
 *  *     \"activationDate\":\"2025-09-05T11:45:33.584Z\",\"serviceCharacteristic\":{\"networkFulfillmentDate\":\"2025-09-05T11:44:40.696Z\"}}",
 *  *     "key": "019919b0-5fe3-76da-8d59-a0856d6f0571",
 *  *     "resource": false
 *  *   }
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Event implements Serializable {

    @JsonProperty("name")
    private String name;

    @JsonProperty("type")
    private String type;

    @JsonProperty("resourceVersion")
    private String resourceVersion;

    @JsonProperty("resourceIdentifier")
    private String resourceIdentifier;

    @JsonProperty("subscriber")
    private String subscriber;

    @JsonProperty("key")
    private String key;

    @JsonProperty("resource")
    private boolean resource;
}