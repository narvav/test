package com.att.idp.idgraphconsumerms.kafka.listener;

import com.att.idp.idgraphconsumerms.helpers.IndividualAccountsCloseEventProcessor;
import com.att.idp.idgraphconsumerms.kafka.model.IndividualAccountsCloseEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

/**
 * Kafka listener for IndividualAccountsCloseEvent using OAuth consumer properties.
 */
@Service
@RequiredArgsConstructor
public class IndividualAccountsCloseEventOAuthListener {
    private static final Logger logger = LoggerFactory.getLogger(IndividualAccountsCloseEventOAuthListener.class);
    private static final String EVENT_TYPE = "IndividualAccountsCloseEvent";
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final IndividualAccountsCloseEventProcessor individualAccountsCloseEventProcessor;

    /**
     * Consumes IndividualAccountsCloseEvent messages from the Kafka topic (OAuth).
     *
     * @param msg the message received from the Kafka topic
     */
    @KafkaListener(
            id = "individualAccountsCloseEventOAuthListener",
            topics = "${idgraph.consumer.cgindividualoauth.topic}",
            containerFactory = "cgIndividualOAuthConsumerContainerFactory",
            groupId = "${idgraph.consumer.cgindividualoauth.group-id}",
            concurrency = "${idgraph.consumer.cgindividualoauth.concurrency:1}",
            autoStartup = "${idgraph.consumer.cgindividualoauth.autoStartup:false}"
    )
    public void consumeIndividualAccountsCloseEventOAuth(@Payload String msg, Acknowledgment ack) throws JsonProcessingException {
        try {
            IndividualAccountsCloseEvent payload = objectMapper.readValue(msg, IndividualAccountsCloseEvent.class);
            if (EVENT_TYPE.equals(payload.getEventType())) {
                String individualJson = payload.getEvent().getIndividual();
                String individualId = objectMapper.readTree(individualJson).get("id").asText();
                logger.info("Received IndividualAccountsCloseEvent (OAuth) for individualId: {}", individualId);
                individualAccountsCloseEventProcessor.process(individualId);
            } else {
                logger.debug("Received eventType: {} not intended for IndividualAccountsCloseEventProcessor (OAuth)",
                        payload.getEventType());
            }
            logger.info("CONSUMER_EVENT_SUCCESS: listenerId=individualAccountsCloseEventOAuthListener");
            logger.debug("Committing the offset for the IndividualAccountsCloseEvent message");
            ack.acknowledge();
        } catch (Exception e) {
            logger.error("Failed to process OAuth message: {}", msg, e);
            logger.error("CONSUMER_EVENT_FAILED: listenerId=individualAccountsCloseEventOAuthListener, error={}", e.getMessage());
        } finally {
            MDC.clear();
        }
    }
}
