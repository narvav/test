package com.att.idp.idgraphconsumerms.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;




@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubscriberEventNotification implements Serializable {

    /**
     * The name of the event.
     */
    private String eventName;

    /**
     * The subscriber ID.
     */

    private String subId;

    /**
     * The subscriber's phone number.
     */
    private String subscriberNumber;

    /**
     * The billing account number.
     */
    private String billingAccountNumber;

    /**
     * The status of the subscriber.
     */
    private String subscriberStatus;

    private String tlgMessageId;

    private String eventTime;

    private String eventId;
}