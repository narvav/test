package com.att.idp.idgraphconsumerms.helpers;

import com.att.idp.idgraphconsumerms.kafka.model.Account;
import com.att.idp.idgraphconsumerms.kafka.model.UserIdNotification;
import com.att.idp.idgraphconsumerms.kafka.model.UserIdNotificationEventDetails;
import com.att.idp.idgraph.events.service.ResilientEventPublisher;
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import lombok.RequiredArgsConstructor;
import net.logstash.logback.argument.StructuredArguments;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Helper service for processing NotificationEvent events.
 * Provides methods to process notification events, build notification event details,
 * and publish notifications to the CLM topic. Handles mapping event data to notification models,
 * determines communication modes, and manages notification delivery logic.
 */
@Component
@PropertySource(value = "file:opt/ajsc/etc/config/consumer.properties")
@RequiredArgsConstructor
public class NotificationEventProcessorHelper {

    private static final String CLASS_NAME = "NotificationEventProcessorHelper";
    private static final Logger log = LoggerFactory.getLogger(NotificationEventProcessorHelper.class);

    @Autowired
    ResilientEventPublisher resilientEventPublisher;

    @Autowired
    CTypeHelper ctypeHelper;

    @Autowired
    UserIDNotificationEventDetailsHelper userIDNotificationEventDetailsHelper;

    @Value(value = "${spring.cloud.stream.bindings.userIdNotifications-out-0.destination}")
    private String userIdNotificationsTopicName;

    @Value("${C_TYPES}")
    private String secondaryUserNotificationTypes;

    /**
     * Processes a NotificationEvent if eventName is 'NotificationEvent'.
     * @param event    the event data as a map
     * @param inputMap additional input data
     */
    @SuppressWarnings("unchecked")
    public void processNotificationEvent(Map<String, Object> event, Map<String, Object> inputMap) {

        final String sMethodName = ".processNotificationEvent";
        if (event == null) {
            log.warn("{} {}: event is null", CLASS_NAME, sMethodName);
            return;
        }

        try {
            List<Map<String, Object>> cTypes = CTypeHelper.generateCtype(event);
            List<String> cTypesList = CommonUtil.parseToArray(secondaryUserNotificationTypes, CommonDefs.VALUE_SEPARATOR_CHAR);

            for (Map<String, Object> cTypeMap : cTypes) {
                String cTypeValue = (String) cTypeMap.get("cType");
                String notificationLevel = (String) cTypeMap.get("NotificationLevel");
                String isCPNINotification = (String) cTypeMap.get("isCPNINotification");

               Map<String, Object> hmClmInputNotification = new HashMap<>();

            if (cTypesList.contains(cTypeValue)) {

                log.debug("{}{}  NEPH.PNE.0: populate CommonNotificationFields: {}", CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(cTypeValue));
                populateCommonNotificationFields(hmClmInputNotification, cTypeValue, notificationLevel, isCPNINotification);

                log.info("{}{}  NEPH.PNE.1: populate userIDNotificationEventDetails : {}", CLASS_NAME, sMethodName, StructuredArguments.entries(inputMap));
                userIDNotificationEventDetailsHelper.populateClmInputNotification(event, hmClmInputNotification, inputMap);

                log.info("{}{}  NEPH.PNE.2: buildEvent ", CLASS_NAME, sMethodName, StructuredArguments.entries(hmClmInputNotification));
                UserIdNotification userIdNotification = buildEvent(event, hmClmInputNotification, inputMap);

                log.info("{}{}  NEPH.PNE.3: Publishing event for Ctype: {}", CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(cTypeValue));
                publishNotificationEventToCLM(userIdNotification);
                log.info("{}{}  NEPH.PNE.4: Published event for Ctype: {}", CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(cTypeValue));
               }
            }
        } catch (Exception ex) {
            String errorMessage = ex.getMessage() != null ? ex.getMessage().replaceAll("[\\r\\n]", " ") : "null";
            log.error("{}{} NEPH.PNE.5: unexpected error processing notification event. transactionId: {}", CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(errorMessage));
        }
    }

    /**
     * Helper service for processing NotificationEvent events.
     * This class provides methods to process notification events, build notification event details,
     * and publish notifications to the CLM topic. It handles mapping event data to notification models,
     * determines communication modes, and manages notification delivery logic.
     */
    private UserIdNotificationEventDetails buildUserIdNotificationEventDetails(Map<String, Object> event,
                                                                               Map<String, Object> hmClmInputNotification, Map<String, Object> inputMap) {

        return UserIdNotificationEventDetails.builder()
                .subCategory(hmClmInputNotification.get("cType").toString())
                .isBSSEEvent((String) hmClmInputNotification.get("isBSSE"))
                .individualId((String) hmClmInputNotification.get("sIndividualSorInvariantId"))
                .accessId((String) event.get(CommonDefs.HANDLE))
                .domain((String) event.get(CommonDefs.DOMAIN))
                .guid(hmClmInputNotification.get(CommonDefs.GUID)!=null ? hmClmInputNotification.get(CommonDefs.GUID).toString() : null)
                .accountId((String) hmClmInputNotification.get(CommonDefs.KEY_ACCOUNT_ID)) //Account level notifications accountId must exists
                .roleType((String)hmClmInputNotification.get("roleType"))
                .serviceType(hmClmInputNotification.get("serviceType")!=null ? hmClmInputNotification.get("serviceType").toString() : null)
                .billingSystem((String) hmClmInputNotification.get("billingSystem"))
                .clientId((String) inputMap.get(CommonDefs.CALLING_SYSTEM_ID))
                .customerType((String) hmClmInputNotification.get(CommonDefs.CUSTOMER_TYPE))
                .language(hmClmInputNotification.get(CommonDefs.BROWSER_LANGUAGE)!=null ? hmClmInputNotification.get(CommonDefs.BROWSER_LANGUAGE).toString() : "")
                .notificationLevel((String) hmClmInputNotification.get("notificationLevel"))
                .communicationMode((String) hmClmInputNotification.get("communicationMode"))
                .isCPNINotification((String) hmClmInputNotification.get("isCPNINotification"))
                .autoGenInd((String) hmClmInputNotification.get(CommonDefs.AUTO_GENERATED_IND))
                .accountList(
                        Stream.of(
                             hmClmInputNotification.get("sorInvariantId"),
                             hmClmInputNotification.get(CommonDefs.INSTANCE_ID)
                          ).anyMatch(Objects::nonNull)
                        ? List.of(new Account(
                        hmClmInputNotification.get("serviceType") != null ? hmClmInputNotification.get("serviceType").toString() : null,
                        hmClmInputNotification.get("sorName") != null ? hmClmInputNotification.get("sorName").toString() : null,
                        hmClmInputNotification.get("sorInvariantId") != null ? hmClmInputNotification.get("sorInvariantId").toString() : null,
                        hmClmInputNotification.get(CommonDefs.INSTANCE_ID) != null ? hmClmInputNotification.get(CommonDefs.INSTANCE_ID).toString() : null,
                        hmClmInputNotification.get("entityType") != null ? hmClmInputNotification.get("entityType").toString() : null,
                        hmClmInputNotification.get("serviceStatus") != null ? hmClmInputNotification.get("serviceStatus").toString() : null
                ))
                        : null
                 )
                .deliveryMethods(ConsumerUtil.buildDeliveryMethods(hmClmInputNotification))
                .attributes(AttributesHelper.buildAttributes(event,hmClmInputNotification))
                .build();
    }

    /**
     * Builds a UserIdNotification event object using the provided event data, notification fields, and input map.
     * @param event the event data as a map
     * @param hmClmInputNotification the notification fields map
     * @param inputMap additional input data
     * @return a UserIdNotification object populated with event details
     */
    private UserIdNotification buildEvent(Map<String, Object> event, Map<String, Object> hmClmInputNotification, Map<String, Object> inputMap) {

        String customerNotification = "true";
        String eventName = Optional.ofNullable(inputMap)
                .map(m -> (String) m.get("msOperation"))
                .orElseGet(() -> Optional.ofNullable(inputMap)
                        .map(m -> (String) m.get("transactionName")).orElse(""));

        if(hmClmInputNotification.get("cType") != null && hmClmInputNotification.get("cType").toString().equalsIgnoreCase("ACCESSID_FRAUD_UNLOCK")){
            customerNotification="false";
        }

        return UserIdNotification.builder()
                .eventId(inputMap.get("msName") + String.valueOf(inputMap.get(CommonDefs.TRANSACTION_ID)))
                .eventType(String.valueOf(inputMap.get("eventType")))
                .eventName(eventName)
                .customerNotification(customerNotification)
                .eventTime(Instant.now())
                .eventDetails(buildUserIdNotificationEventDetails(event, hmClmInputNotification, inputMap))
                .build();
    }

    /**
     * Publishes notification to CLM topic.
     * @param userIdNotificationRequest the event data
     */
    private void publishNotificationEventToCLM(UserIdNotification userIdNotificationRequest) {
        final String sMethodName = ".publishNotificationEventToCLM";
        String binding = "userIdNotifications";
        if (userIdNotificationRequest == null || userIdNotificationRequest.getEventDetails() == null) {
            log.warn("{}{} : userIdNotificationRequest or eventDetails is null",CLASS_NAME, sMethodName);
            return;
        }
        log.info("{}{} NEPH.PNEC.1 :publish userIdNotificationReq to CLM with topic : {}",CLASS_NAME, sMethodName,userIdNotificationsTopicName);
        String partitionKey = userIdNotificationRequest.getEventDetails().getAccessId() != null
                ? userIdNotificationRequest.getEventDetails().getAccessId()
                : userIdNotificationRequest.getEventDetails().getAccountId();
        boolean published = resilientEventPublisher.sendWithFallback(binding, "CLM Notification", partitionKey, userIdNotificationRequest);
        if (published) {
            log.info("{}{} NEPH.PNEC.2 Published userIdNotificationReq to CLM with topic: {}",CLASS_NAME, sMethodName,userIdNotificationsTopicName);
        } else {
            log.warn("{}{} NEPH.PNEC.3 CLM notification saved to Cosmos DB fallback: {}",CLASS_NAME, sMethodName,userIdNotificationsTopicName);
        }
    }

     /**
     * Populates common notification map fields to avoid code duplication.
     */
    private void populateCommonNotificationFields(Map<String, Object> hmClmInputNotification, String cTypeValue, String notificationLevel, String isCPNINotification) {
        hmClmInputNotification.put("cType", cTypeValue);
        hmClmInputNotification.put("notificationLevel", notificationLevel);
        hmClmInputNotification.put("isCPNINotification", isCPNINotification);
    }
}
