package com.att.idp.idgraphconsumerms.constants;

import java.util.Set;

public class ConsumerConstants {

    private ConsumerConstants() {
    }

    public static class Keys {

        public static final String X_ATT_CLIENTID = "X-ATT-ClientId";
        public static final String IDP_TRACE_ID = "idp-trace-id";
        public static final String AUTHORIZATION = "Authorization";
        public static final String IDPCTX_SESSION_ID = "idpctx-session-id";

    }

    public static final String SUB_EVENT="subEvent";
    public static final String SUB_HAS_VOIP = "SubHasVoIP";
    public static final String PARENT_CHILD_IND = "parent_child_ind";
    public static final String CHILD_IND = "C";
    public static final  String UPDATE_PROFILE_INFO="UpdateProfileInfo";
    public static final String SERVICES="services";
    public static final String SERVICE_TYPE="serviceType";
    public static final String  MEMBER_INFO="memberInfo";
    public static final String ADD_SERVICES = "addServices";
    public static final String REMOVE_SERVICES = "removeServices";
    public static final String EVENT_NAME = "eventname";
    public static final String EVENT_ADD_REMOVE_SERVICES_LIST = "AddRemoveServicesList";
    public static final String PORTAL_PROVIDER = "portalProvider";
    public static final String ATT_YAHOO = "AT&T Yahoo";
    public static final String SERVICE_TYPE_PORTAL = "PORTAL";
    public static final String HANDLE="handle";
    public static final  String SBC_IPTV="sbciptv.*";
    public static final  String IPTV="IPTV";
    public static final String C_TYPE="cType";
    public static final String SOR_INVARIANT_ID="sor_invariant_id";
    public static class BsseMigration {

        public static final String CLIENT_BSSEMIPAAS = "BSSEMIPAAS";
        public static final String CLIENT_ORDERGRAPH = "ORDERGRAPH";
        public static final String MOBILITY = "MOBILITY";
        public static final String UVERSE = "UVERSE";
        public static final String SERVICE_TYPE_FIBER = "Fiber";
        public static final String PHASE_ONE = "Phase1";
        public static final String ACCOUNT_TYPE_BSSEWIRELESS = "BSSEWIRELESS";
        public static final String ACCOUNT_TYPE_BSSEFIBER = "BSSEFIBER";
        public static final String EVENT_BSSE_MIG_WIRELESS = "BSSEMigWireless";
        public static final String EVENT_BSSE_MIG_FIBER_FORWARD = "BSSEMigFiberForward";
        public static final String EVENT_BSSE_MIG_PASSCODE_UPD = "BSSEMigPasscodeUpd";
        public static final String EVENT_ORDERGRAPH_FAILURE = "OrderGraphSalesPivotFailure";
        public static final String EVENT_CG_INDIVIDUAL_CLOSE = "CGIndividualCloseEvent";
        public static final String MIGRATION_BAN_NOTIFICATION = "MigrationBanNotification";
        public static final String SUB_STATUS_COMMIT_ALL = "Request_ALL_Commit_To_Target";
        public static final String STATUS_INFLIGHT_PONR = "Inflight_PONR";
        public static final String MIGRATION_STATUS_STARTED = "STARTED";
        public static final String REVERSE_MIGRATION_STATUS_STARTED = "ReverseMigStarted";
        public static final String INDIVIDUAL_ID = "INDIVIDUALID";
        public static final String SERVICE_TYPE_REVERSE_WIRELESS = "ReverseWireless";
        public static final String EVENT_CG_INDI_ACCT_CLOSE = "CGIndiAcctCloseEvent";
        public static final String CLIENT_CUSTOMERGRAPH = "CUSTOMERGRAPH";
        public static final String EVENT_TYPE_BILLING_ACCOUNT_STATE_CHANGE = "BillingAccountStateChangeEvent";
        public static final String ACCOUNT_STATE_CLOSED = "closed";
    }

    public static class BsseReverseMigration {
        public static final String BSSE_REVERSE_MIGRATION_EVENT_TYPE = "ReverseMigratedData";
        public static final String SOURCE_BSSE_BAN = "sourceBSSEBan";
        public static final String TARGET_TLG_BAN = "targetTLGBan";
        public static final String MIGRATION_ID = "migrationId";
        public static final String ACCOUNT_TYPE = "accountType";
        public static final String ACCOUNT_SUB_TYPE = "accountSubType";

    }

    public static class ErrorDetails {
        public static final String ACCOUNT_TYPE = "accountType";
        public static final String ERROR_CODE = "errorCode";
        public static final String ERROR_MESSAGE = "errorMessage";
        public static final String FAILED_ENDPOINT = "failedEndpoint";
        public static final String VALIDATION_FAILED = "VALIDATION_FAILED";
    }

    public static class DmctnSubscriberChangeEvent {

        public static final String MOSUB = "MOSUB";
        public static final String SOR_NAME_MO = "MO";
        public static final String  EVENT_TYPE_SUBSCRIBER_CHANGE = "SubscriberChangeEvent";
        public static final String  EVENT_TYPE_CGT_GDDN = "CGTlgGddnEvent";

        public static final String  EVENT_TYPE_DMCTN_CG_SUBSCRIBER = "DMCTNCGSubscriberEvent";
        public static final String  EVENT_TYPE_SUBSCRIBER_CREATE = "SubscriberCreateEvent";
        public static final String  HEADER_KEY_CHANGETYPE = "ChangeType";
        public static final String  HEADER_CHANGETYPE_VALUE_STATUS = "status";
        public static final String  HEADER_CHANGETYPE_VALUE_PHONENUMBER = "PhoneNumber";
        public static final String  SUBSCRIBER_ID = "SubscriberId";

        public static final String  TRAN_TYPE_UPDATE_SUBID = "UpdateSubIdOfDMCTN";
        public static final String  TRAN_TYPE_CHANGE_STATUS = "ChangeStatusOfDMCTN";
        public static final String  TRAN_TYPE_REMOVE_ASSOCIATION = "RemoveAssociationOfDMCTN";
        public static final String  TRAN_TYPE_UPDATE_DMCTN = "UpdateDMCTNOfSubId";
        public static final String SERVICE_STAUS_ACTIVE = "active";//TODO: active in CG = Enabled in IDGraph
        public static final String  SERVICE_STAUS_SUSPENDED = "suspended";
        public static final String  SERVICE_STAUS_TERMINATED = "terminated";
        public static final String  SERVICE_STAUS_CANCELLED = "cancelled";//TODO: active in CG = Enabled in IDGraph
        public static final String  CLIENT_CUSTOMERGRAPH = "CUSTOMERGRAPH";
        public static final String  SUBSCRIBER_MIGRATED_ON = "migratedOn";
        public static final String  CLIENT_ATLASBUS = "ATLASBUS";


        public static final String CG_CTN_TERMINATED_REASON_CODE = "WTERM-REVMIG";
    }

    public static class AccountNotificationConstants {
        public static final String MOBILITY = "MOBILITY";
        public static final String CloseAccount = "CloseAccount";
        public static final String SOR_ID_13 = "13";
        public static final String ACTIVATE_ACCOUNT = "ActivateAccount";
        public static final String UPDATE_ACCOUNT = "UpdateAccount";
        public static final String UPDATE_FAN = "UpdateFan";
        public static final String UPDATE_WLS_UNIFICATION = "UpdateWlsUnification";
        public static final String SUPPRESS_NOTIFICATION = "Y";
        public static final String  GRID_GDDN = "GRID_GDDN_NOTIFICATION";
        public static final String WIRELESS = "WIRELESS";
        public static final String UVERSE = "UVERSE";
        public static final String PROVISION_ENABLER = "ProvisionEnablerAcct";
        public static final String SERVICE_STATUS_ACTIVE = "A";
        public static final String CONVERGE_PENDING_IND = "Y";
        public static final String CONVERGE_PENDING_IND_NO = "N";

    }

    public static class SubscriberNotificationConstants {
        public static final String RESTORE_SUBSCRIBER = "RestoreSubscriber";
        public static final String CANCEL_SUBSCRIBER = "CancelSubscriber";
        public static final String SUSPEND_SUBSCRIBER = "SuspendSubscriber";
        public static final String CHANGE_DATA = "ChangeData";
    }

    public static class ProductNotificationConstants {
        public static final String EVENT_TYPE_PRODUCT_CHANGE = "ChangeProduct";
        public static final String MOBILITY = "MOBILITY";
        public static final String CONNECTED_CAR = "Y";
        public static final String CHANGE_DATA = "ChangeData";
        public static final String EVENT_TYPE_RG_NOTIFICATION = "RGActivation";
        public static final String EVENT_TYPE_PLATFORM_HANDLER = "PlatformHandler";
        public static final String DELETE_PH_ACCOUNT = "DeletePHAccount";
    }

    public static class HaloCAddMemberServiceTypes {
        private HaloCAddMemberServiceTypes() {}
        public static final String LSO = "LSO";
        public static final String DSLD = "DSLD";
        public static final String ECOMM = "ECOMM";
        public static final String PORTAL = "PORTAL";
        public static final String LS_ACCT = "LS_ACCT";
        public static final String DIRECTV = "DIRECTV";
        public static final String DIRECTVNOW = "DIRECTVNOW";
        public static final String WLLVCTN = "WLLVCTN";
        public static final String CCARRIER = "CCARRIER";
        public static final String PREPAID = "PREPAID";
        public static final String CCAR_PREPAID = "CCAR_PREPAID";
        public static final String INDIVIDUAL = "INDIVIDUAL";
        public static final String INDIVIDUALUSER = "INDIVIDUALUSER";
        public static final String VAS = "VAS";
        public static final String CONNECTEDHOME = "CONNECTEDHOME";
    }
    public static final String ONLINE_ACCOUNT_ADD_SEC = "ONLINE_ACCOUNT_ADD_SEC";
    public static final String ONLINE_ACCOUNT_ADD2 = "ONLINE_ACCOUNT_ADD2";
    public static final String CTN_ADDED_TO_ACCESSID = "CTN_ADDED_TO_ACCESSID";
    public static final String CTN_REMOVED_FROM_ACCESSID = "CTN_REMOVED_FROM_ACCESSID";
    public static final String CTN_CHANGED_ON_ACCESSID = "CTN_CHANGED_ON_ACCESSID";

    public static final String EML_ADDR_VALIDATION = "EML_ADDR_VALIDATION";
    public static final String EML_ADDR_VALIDATION_LINK = "emlAddrValidationLink";
    public static final String ENCRYPTED_KEY = "EncryptedKey";
    public static final String SOR_SYSTEM = "sorSystem";

    public static class GridGddnNotification {
        // GDDN event names — new standardized names (saved to Cosmos failed_events table)
        public static final String EVENT_GDDN_ACTIVATE_ACCOUNT = "GDDNActivateAccount";
        public static final String EVENT_GDDN_CLOSE_ACCOUNT = "GDDNCloseAccount";
        public static final String EVENT_GDDN_UPDATE_ACCOUNT = "GDDNUpdateAccount";
        public static final String EVENT_GDDN_CHANGE_PRODUCT = "GDDNChangeProduct";
        public static final String EVENT_GDDN_RG_ACTIVATION = "GDDNRGActivation";
        public static final String EVENT_GDDN_PLATFORM_HANDLER = "GDDNPlatformHandler";

        // GDDN subscriber event names — granular names replacing the single SubscriberChangeEvent
        public static final String EVENT_GDDN_RESTORE_SUBSCRIBER = "GDDNRestoreSubscriber";
        public static final String EVENT_GDDN_SUSPEND_SUBSCRIBER = "GDDNSuspendSubscriber";
        public static final String EVENT_GDDN_CANCEL_SUBSCRIBER = "GDDNCancelSubscriber";
        public static final String EVENT_GDDN_CHANGE_DATA = "GDDNChangeData";

        // CG (CustomerGraph) subscriber event names — CG-prefixed variants for events originating from CustomerGraph
        // Uses CATEGORY_CG_SUBSCRIBER for independent sequencing from GDDN subscriber events
        public static final String EVENT_CG_RESTORE_SUBSCRIBER = "CGRestoreSubscriber";
        public static final String EVENT_CG_SUSPEND_SUBSCRIBER = "CGSuspendSubscriber";
        public static final String EVENT_CG_CANCEL_SUBSCRIBER = "CGCancelSubscriber";
        public static final String EVENT_CG_CHANGE_DATA = "CGChangeData";

        // Event categories for sequencing groups
        public static final String CATEGORY_GDDN_ACCOUNT = "GDDNAccount";
        public static final String CATEGORY_GDDN_SUBSCRIBER = "GDDNSubscriber";
        public static final String CATEGORY_CG_SUBSCRIBER = "CGSubscriber";
        public static final String CATEGORY_CG_INDIVIDUAL = "CGIndividual";
        public static final String CATEGORY_CG_ACCOUNT = "CGAccount";
        public static final String CATEGORY_GDDN_FAN_UPDATE = "GDDNFanUpdate";
        public static final String CATEGORY_GDDN_WLS_UNIFICATION = "GDDNWlsUnification";
        public static final String CATEGORY_GDDN_RG_ACTIVATION = "GDDNRGActivation";

        // Error messages
        public static final String ERROR_CIRCUIT_BREAKER_OPEN = "Circuit breaker open — pending failed events exist";

        private static final java.util.Map<String, String> INCOMING_TO_NEW_EVENT_NAME = new java.util.HashMap<>();
        static {
            // Account events
            INCOMING_TO_NEW_EVENT_NAME.put("ActivateAccount", EVENT_GDDN_ACTIVATE_ACCOUNT);
            INCOMING_TO_NEW_EVENT_NAME.put("CloseAccount", EVENT_GDDN_CLOSE_ACCOUNT);
            INCOMING_TO_NEW_EVENT_NAME.put("UpdateAccount", EVENT_GDDN_UPDATE_ACCOUNT);
            INCOMING_TO_NEW_EVENT_NAME.put("ChangeProduct", EVENT_GDDN_CHANGE_PRODUCT);
            INCOMING_TO_NEW_EVENT_NAME.put("RGActivation", EVENT_GDDN_RG_ACTIVATION);
            INCOMING_TO_NEW_EVENT_NAME.put("PlatformHandler", EVENT_GDDN_PLATFORM_HANDLER);
            // Subscriber events — resolve to GDDN-prefixed names (originating from GDDN topic)
            INCOMING_TO_NEW_EVENT_NAME.put("RestoreSubscriber", EVENT_GDDN_RESTORE_SUBSCRIBER);
            INCOMING_TO_NEW_EVENT_NAME.put("SuspendSubscriber", EVENT_GDDN_SUSPEND_SUBSCRIBER);
            INCOMING_TO_NEW_EVENT_NAME.put("CancelSubscriber", EVENT_GDDN_CANCEL_SUBSCRIBER);
            INCOMING_TO_NEW_EVENT_NAME.put("ChangeData", EVENT_GDDN_CHANGE_DATA);
        }

        /**
         * Resolves the incoming event name (from Kafka message) to the new GDDN-prefixed name
         * for storage in the failed events table. If already in new format, returns as-is.
         */
        public static String resolveEventName(String incomingEventName) {
            if (incomingEventName == null) return null;
            return INCOMING_TO_NEW_EVENT_NAME.getOrDefault(incomingEventName, incomingEventName);
        }
    }

    public static class BbnmsConstants {
        private BbnmsConstants() {}

        public static final Set<String> SOURCE_EVENT_NAMES = Set.of("LSRegNotify", "ActivateTNByBAN");
    }
}
