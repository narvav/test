package com.att.idp.idgraphconsumerms.bsse.reverse;


import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails;
import com.att.idp.idgraphconsumerms.kafka.model.ReverseMigratedInboundDataEvent;
import com.att.idp.idgraphconsumerms.kafka.model.ReverseMigratedOutboundRequest;
import com.att.idp.idgraphconsumerms.rest.client.GenericApiRestClient;
import com.att.idp.idgraphconsumerms.rest.model.APIDetails;
import com.att.idp.idgraphconsumerms.rest.model.APIRequestWrapper;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;


@Service
public class BsseReverseMigrationService {

    @Value("${apiclient.rest.ua.serverUrl}")
    private String userAssoServerUrl;

    @Value("${apiclient.rest.ua.username}")
    private String userName;

    @Value("${apiclient.rest.ua.password}")
    private String userPassword;

    @Value("${apiclient.rest.ua.bssereversemigration.endpoint}")
    private String reverseMigrationEndpoint;

    private final GenericApiRestClient apiRestClient;

    public BsseReverseMigrationService(GenericApiRestClient apiRestClient) {
        this.apiRestClient = apiRestClient;
    }

    public void callBackendAPI(ReverseMigratedInboundDataEvent inboundEvent) {

        APIDetails apiDetails = APIDetails.builder()
                .serverURI(userAssoServerUrl)
                .apiEndpoint(reverseMigrationEndpoint)
                .username(userName)
                .password(userPassword)
                .xATTClientId(ConsumerConstants.BsseMigration.CLIENT_BSSEMIPAAS) // Example client ID
                .httpMethod(HttpMethod.POST)
                .build();

        FailedEventDetails inboundFailedEventDetails = FailedEventDetails.builder()
                .eventName(ConsumerConstants.BsseReverseMigration.BSSE_REVERSE_MIGRATION_EVENT_TYPE)
                .accountId(inboundEvent.getTargetTLGBan())
                .build();

        APIRequestWrapper requestWrapper = APIRequestWrapper.builder()
                .apiDetails(apiDetails)
                .failedEventDetails(inboundFailedEventDetails)
                .outgoingAPIRequestJson(JsonService.getJsonFromObject(buildReverseMigratedOutboundRequest(inboundEvent)))
                .build();

        apiRestClient.sendPostRequest(requestWrapper);

    }

    private ReverseMigratedOutboundRequest buildReverseMigratedOutboundRequest(ReverseMigratedInboundDataEvent inboundEvent) {

        ReverseMigratedInboundDataEvent.EventDetails eventDetails = inboundEvent.getEvent();
        ReverseMigratedInboundDataEvent.IDMAttributes idmAttributes = (eventDetails != null) ? eventDetails.getIdmAttributes() : null;
        List<ReverseMigratedInboundDataEvent.AccessID> inboundAccessIDs = (idmAttributes != null) ? idmAttributes.getAccessIDs() : List.of();
        List<ReverseMigratedInboundDataEvent.CtnDetail> ctnDetails = (idmAttributes != null) ? idmAttributes.getCtnList() : List.of();

        ReverseMigratedOutboundRequest outboundRequest = new ReverseMigratedOutboundRequest();
        outboundRequest.setMigrationId(inboundEvent.getMigrationId());
        outboundRequest.setProductType(ConsumerConstants.BsseMigration.MOBILITY);//TODO: set actual product type
        outboundRequest.setSourceBSSEBan(inboundEvent.getSourceBSSEBan());
        outboundRequest.setTargetTLGBan(inboundEvent.getTargetTLGBan());
        outboundRequest.setIterationId(inboundEvent.getIterationId());
        outboundRequest.setRetryCounter("0"); // Initial retry counter set to 0
        outboundRequest.setEventId(inboundEvent.getEventId());
        outboundRequest.setAccountType(idmAttributes != null ? idmAttributes.getAccountType() : null);
        outboundRequest.setAccountSubType(idmAttributes != null ? idmAttributes.getAccountSubType() : null);

        if (inboundAccessIDs == null) {
            inboundAccessIDs = List.of();
        }
        List<ReverseMigratedOutboundRequest.AccessId> outboundAccessIds = inboundAccessIDs.stream()
                .map(inbound -> ReverseMigratedOutboundRequest.AccessId.builder()
                        .guid(inbound.getGuid())
                        .roleName(inbound.getRoleId())
                        .individualId(inbound.getIndividualId())
                        .build())
                .collect(Collectors.toList());

        if (ctnDetails == null) {
            ctnDetails = List.of();
        }
        List<ReverseMigratedOutboundRequest.Ctn> outboundCtns = ctnDetails.stream()
                .map(inbound -> ReverseMigratedOutboundRequest.Ctn.builder()
                        .ctn(inbound.getCtn())
                        .cgSubId(inbound.getCgSubId())
                        .tlgSubId(inbound.getTlgSubId())
                        .build())
                .collect(Collectors.toList());

        outboundRequest.setAccessIDs(outboundAccessIds);
        outboundRequest.setCtnList(outboundCtns);

        return outboundRequest;
    }
}
