package com.att.idp.idgraphconsumerms.helpers;

import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.att.mpsys.common.utils.CommonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Helper class for processing Yahoo-specific event rules in the IDGraph Consumer microservice.
 * <p>
 * This class provides logic to validate and process Yahoo-related events, including sub-event and domain validation,
 * and applies business rules for Yahoo event processing. It is configured via Spring properties and extends {@link BaseRuleHelper}.
 */

@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/consumer.properties")
public class IDGraphYahooRulesHelper extends BaseRuleHelper {

	private static final String sClassName = "IDGraphYahooRulesHelper.";
	public static final Logger logger = LoggerFactory.getLogger(IDGraphYahooRulesHelper.class);

	@Value("${Yahoo_SubEvents}")
	private  String yahooSubEvents;

	@Value("${Yahoo_CSI}")
	private  String yahooCSI;

	@Value("${Yahoo_Services}")
	private  String yahooServices;


	/**
	 * Processes a Yahoo event message by validating event data and applying Yahoo-specific business rules.
	 *
	 * @param event the event data as a map of key-value pairs
	 * @return {@code true} if the event passes all Yahoo rules and should be processed; {@code false} otherwise
	 */
	public boolean processYahooMessage(Map<String, Object> event) {
		String stAppInfo = "";
		String sMethodName = ".processYahooMessage.";
		Map<String, Object> hmResponse = null;
		boolean processYahooMsg=false;
     	//memberinfo list - more than 1 , consider each one request ...
		try {
			if (!isValidEventsData(event)) {
				stAppInfo = "Events data is null or empty";
				logger.error("{}{} IDGYRH.PYM.01 : {}", sClassName, sMethodName, stAppInfo);
				return false;
			}
			if (validateCommonRules(event) && processEventRules(event)) {
				processYahooMsg=true;
			}
		} catch (Exception e) {
			stAppInfo = "Exception thrown from processMessage : " + hmResponse;
			logger.error("{}{} IDGYRH.PYM.02 : {}", sClassName, sMethodName, HtmlUtils.htmlEscape(stAppInfo));
			hmResponse = CommonErrorMap.makeExceptionMap(e, logger);
		}
		logger.info("{}{}HLP999 : hmResponse = {}", sClassName, sMethodName, hmResponse);
		return processYahooMsg;
	}

	private boolean validateCommonRules(Map<String, Object> event){
		String stAppInfo ="";
		String sMethodName = ".validateCommonRules.";
		String subEvent = (String) event.get("subEvent");
		String domain = (String) event.get("domain");
		String callingSystemId = (String) event.get("callingSystemId");
		String filterYahoo = (String) event.get("filterYahoo");

	ArrayList subEventList = CommonUtil.parseToArray(yahooSubEvents, CommonDefs.VALUE_SEPARATOR_CHAR);

		if (subEventList.isEmpty() || subEventList.contains(subEvent)) {
			stAppInfo = "Invalid SubEvent: " + subEvent;
			logger.error("{}{} IDGYRH.PYM.03 : {}", sClassName, sMethodName, stAppInfo);
			return false;
		}
		if ("slid.dum".equals(domain)) {
			stAppInfo = "Invalid domain: " + domain;
			logger.error("{}{} IDGYRH.PYM.04 : {}", sClassName, sMethodName, stAppInfo);
			return false;
		}
		ArrayList yahooCallingSystemId = CommonUtil.parseToArray(yahooCSI, CommonDefs.VALUE_SEPARATOR_CHAR);
		if (yahooCallingSystemId.isEmpty() || yahooCallingSystemId.contains(callingSystemId)) {
			stAppInfo = "Invalid callingSystemId: " + callingSystemId;
			logger.error("{}{}IDGYEH.FYE.04 : {}", sClassName, sMethodName, stAppInfo);
			return false;
		}
		if ("Y".equalsIgnoreCase(filterYahoo)) {
			stAppInfo = "request not for yahoo filterYahoo : " + filterYahoo;
			logger.error("{}{} IDGYRH.PYM.03 : {}", sClassName, sMethodName, stAppInfo);
			return false;
		}
		return true;
	}

	private boolean processEventRules(Map<String, Object> event) {
		String eventName = (String) event.get("eventname");
		String migrationInd = (String) event.get("migrationInd");
		String portalProvider = (String) event.get("portalProvider");
		String subEvent = (String) event.get("subEvent");
		String callingSystemId = (String) event.get("callingSystemId");
		List<Map<String, Object>> services = ConsumerUtil.extractServicesWithFullFallback(event);

		switch (eventName) {
			case "UpdateServicesStatusList":
				return hasPortalServiceWithYahooProvider(services, portalProvider);
			case "ChangePassword":
			case "UpdateMember":
				return "Y".equals(migrationInd) || "M".equals(migrationInd);
			case "AddRemoveServicesList":
				return hasPortalServiceWithYahooProvider(services, portalProvider);

            case "UpdateProfileInfo":
				return "AT&T Yahoo".equals(portalProvider) || "M".equals(migrationInd) || "Y".equals(migrationInd);

			case "AddMember":
			case "AddMemberList":
				if ("ExistingRegVoIP".equalsIgnoreCase(subEvent) || "AddingVoIPToParent".equalsIgnoreCase(subEvent) || callingSystemId.equalsIgnoreCase("YAHOO")) {
					return false;
				}
				return "M".equals(migrationInd) || "Y".equals(migrationInd) || "P".equals(migrationInd);

			case "AddServices":
				if (services != null) {
					for (Object obj : services) {
						if (obj instanceof Map) {
							Map<String, Object> service = (Map<String, Object>) obj;
							String serviceType = (String) service.get("serviceType");
							String servicePortalProvider = (String) service.get("portalProvider");
							if (("HSIA".equals(serviceType) && "AT&T Yahoo".equals(servicePortalProvider))
									|| ("M".equals(migrationInd) || "Y".equals(migrationInd))) {
								return true;
							}
						}
					}
				}
				return false;

				default:
				return false;
		}
	}
	/**
	 * Checks if any service has serviceType PORTAL with portalProvider "AT&T Yahoo".
	 * portalProvider is checked in the service hashmap first, then at root level.
	 * @param services list of service maps extracted from the event
	 * @param rootPortalProvider portalProvider value from the root of the event
	 * @return true if a PORTAL service with AT&T Yahoo portalProvider is found
	 */
	private boolean hasPortalServiceWithYahooProvider(List<Map<String, Object>> services, String rootPortalProvider) {
		if (services == null) return false;
		for (Map<String, Object> service : services) {
			String serviceType = (String) service.get(ConsumerConstants.SERVICE_TYPE);
			if (ConsumerConstants.SERVICE_TYPE_PORTAL.equals(serviceType)) {
				String servicePortalProvider = (String) service.get(ConsumerConstants.PORTAL_PROVIDER);
				if (ConsumerConstants.ATT_YAHOO.equals(servicePortalProvider)
						|| ConsumerConstants.ATT_YAHOO.equals(rootPortalProvider)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Processes AddRemoveServicesList event rules.
	 * @param allServices list of services extracted from the event
	 * @return true if the AddRemoveServicesList event passes all rule checks, false otherwise
	 */
	private boolean processAddRemoveServicesList(List<Map<String, Object>> allServices) {
		ArrayList addRemoveServicesList = CommonUtil.parseToArray(yahooServices, CommonDefs.VALUE_SEPARATOR_CHAR);

		return ConsumerUtil.validateAddRemoveServices(allServices, addRemoveServicesList);

	}
}
