package com.att.idp.idgraphconsumerms.kafka.listener;

import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;

import org.slf4j.MDC;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import com.att.idp.idgraph.events.service.ResilientEventPublisher;
import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.constants.KafkaListenerConstants;
import com.att.idp.idgraphconsumerms.constants.OdsNotesConstants;
import com.att.idp.idgraphconsumerms.helpers.OdsNotesTransformHelper;
import com.att.idp.idgraphconsumerms.kafka.model.OdsGenerateNotesEvent;
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OdsNotesEventListener {

    private final OdsNotesTransformHelper transformHelper;
    private final ResilientEventPublisher resilientEventPublisher;
    private final ListenerContainerManager listenerContainerManager;
    private final ObjectMapper objectMapper;

    public OdsNotesEventListener(OdsNotesTransformHelper transformHelper,
                                  ResilientEventPublisher resilientEventPublisher,
                                  ListenerContainerManager listenerContainerManager,
                                  ObjectMapper objectMapper) {
        this.transformHelper = transformHelper;
        this.resilientEventPublisher = resilientEventPublisher;
        this.listenerContainerManager = listenerContainerManager;
        this.objectMapper = objectMapper;
    }

    @KafkaListener(
            id = KafkaListenerConstants.LISTENER_NOTES_ORACLE_EVENTS,
            topics = "${idgraph.consumer.notesoracleeventsconsumer.topic}",
            containerFactory = "notesOracleEventsConsumerContainerFactory",
            groupId = "${idgraph.consumer.notesoracleeventsconsumer.group-id}",
            concurrency = "${idgraph.consumer.notesoracleeventsconsumer.concurrency:1}",
            autoStartup = "${idgraph.consumer.notesoracleeventsconsumer.autoStartup:false}"
    )
    public void onOracleEvent(String message, Acknowledgment ack) {
        processAndPublish(message, ack, transformHelper::transformOracleSecurityCodeEvent,
                OdsNotesConstants.LOG_PREFIX_ORACLE_EVENTS,
                KafkaListenerConstants.LISTENER_NOTES_ORACLE_EVENTS);
    }

    @KafkaListener(
            id = KafkaListenerConstants.LISTENER_NOTES_PROFILE_UPDATE,
            topics = "${idgraph.consumer.notesprofileupdateconsumer.topic}",
            containerFactory = "notesProfileUpdateConsumerContainerFactory",
            groupId = "${idgraph.consumer.notesprofileupdateconsumer.group-id}",
            concurrency = "${idgraph.consumer.notesprofileupdateconsumer.concurrency:1}",
            autoStartup = "${idgraph.consumer.notesprofileupdateconsumer.autoStartup:false}"
    )
    public void onProfileUpdateEvent(String message, Acknowledgment ack) {
        processAndPublish(message, ack, transformHelper::transformProfileUpdateEvent,
                OdsNotesConstants.LOG_PREFIX_PROFILE_UPDATE,
                KafkaListenerConstants.LISTENER_NOTES_PROFILE_UPDATE);
    }

    @KafkaListener(
            id = KafkaListenerConstants.LISTENER_NOTES_USERID_NOTIFICATIONS,
            topics = "${idgraph.consumer.notesuseridnotificationsconsumer.topic}",
            containerFactory = "notesUserIdNotificationsConsumerContainerFactory",
            groupId = "${idgraph.consumer.notesuseridnotificationsconsumer.group-id}",
            concurrency = "${idgraph.consumer.notesuseridnotificationsconsumer.concurrency:1}",
            autoStartup = "${idgraph.consumer.notesuseridnotificationsconsumer.autoStartup:false}"
    )
    public void onUserIdNotificationEvent(String message, Acknowledgment ack) {
        processAndPublish(message, ack, transformHelper::transformUserFraudEvent,
                OdsNotesConstants.LOG_PREFIX_USERID_NOTIFICATIONS,
                KafkaListenerConstants.LISTENER_NOTES_USERID_NOTIFICATIONS);
    }

    /**
     * Common processing method for all 3 listeners.
     * Guarantees: ack.acknowledge() is called in EVERY code path. MDC is always cleared.
     */
    private void processAndPublish(String message, Acknowledgment ack,
                                    Function<JsonNode, Optional<OdsGenerateNotesEvent>> transformFn,
                                    String logPrefix, String listenerId) {
        long startTm = System.currentTimeMillis();
        try {
            // Step 1: Parse JSON (S2 — malformed data)
            JsonNode jsonNode;
            try {
                jsonNode = objectMapper.readTree(message);
            } catch (Exception e) {
                log.error("NOTES_PARSE_ERR: {} Failed to parse message: {}. Payload snippet: {}",
                        logPrefix,
                        ConsumerUtil.sanitizeForLog(e.getMessage()),
                        ConsumerUtil.sanitizeForLog(message));
                log.error("CONSUMER_EVENT_FAILED: listenerId={}, error={}", listenerId, e.getMessage());
                return;
            }

            // Handle double-encoded JSON (E1)
            if (jsonNode.isTextual()) {
                try {
                    jsonNode = objectMapper.readTree(jsonNode.asText());
                } catch (Exception e) {
                    log.error("NOTES_PARSE_ERR: {} Failed to re-parse double-encoded message: {}",
                            logPrefix,
                            ConsumerUtil.sanitizeForLog(e.getMessage()));
                    log.error("CONSUMER_EVENT_FAILED: listenerId={}, error={}", listenerId, e.getMessage());
                    return;
                }
            }

            // Step 2: Set MDC trace ID (E2 — fallback to UUID)
            String eventId = jsonNode.path("eventId").asText(null);
            String traceId = (eventId != null && !eventId.isBlank()) ? eventId : UUID.randomUUID().toString();
            MDC.put(ConsumerConstants.Keys.IDP_TRACE_ID, traceId);
            if (eventId == null || eventId.isBlank()) {
                log.warn("{}_001: Event received with null/empty eventId. Generated traceId: {}", logPrefix, traceId);
            }

            log.info("WEB000 : {} consumer initiation. traceId={}", logPrefix, traceId);
            log.info("{}_001: Event received. traceId={}, payload={}", logPrefix, traceId,
                    ConsumerUtil.sanitizeForLog(message));

            // Step 3: Transform (S3 — transformation error)
            Optional<OdsGenerateNotesEvent> result;
            try {
                result = transformFn.apply(jsonNode);
            } catch (Exception e) {
                log.error("NOTES_TRANSFORM_ERR: {} Transformation failed. traceId={}, error={}",
                        logPrefix, traceId, ConsumerUtil.sanitizeForLog(e.getMessage()));
                log.error("CONSUMER_EVENT_FAILED: listenerId={}, error={}", listenerId, e.getMessage());
                return;
            }

            // Step 4: Check filter result
            if (result.isEmpty()) {
                log.debug("NOTES_FILTER_SKIP: {} Event did not match filter criteria. traceId={}", logPrefix, traceId);
                log.info("CONSUMER_EVENT_SUCCESS: listenerId={}", listenerId);
                return;
            }

            // Step 5: Publish (S4 + S5)
            OdsGenerateNotesEvent event = result.get();
            boolean published = resilientEventPublisher.sendWithFallback(
                    OdsNotesConstants.ODS_GENERATE_NOTES_BINDING,
                    OdsNotesConstants.ODS_GENERATE_NOTES_LABEL,
                    event.getTransactionId(),
                    event);

            if (published) {
                log.info("NOTES_PUBLISH_OK: {} Published to output topic. traceId={}, eventType={}",
                        logPrefix, traceId, event.getEventType());
                log.info("CONSUMER_EVENT_SUCCESS: listenerId={}", listenerId);
            } else {
                log.error("NOTES_PUBLISH_ERR: {} Failed to publish after all retries. traceId={}, transactionId={}, eventType={}",
                        logPrefix, traceId, event.getTransactionId(), event.getEventType());
                log.error("CONSUMER_EVENT_FAILED: listenerId={}, error=publish failed after retries", listenerId);
                listenerContainerManager.onTransientError(listenerId);
            }

            String sTimeTaken = ConsumerUtil.getElapsedTimeInSecs(startTm) + " seconds";
            log.info("WEB999 : Total time taken : {} {} consumer. traceId={}", sTimeTaken, logPrefix, traceId);
        } finally {
            ack.acknowledge();
            MDC.clear();
        }
    }
}
