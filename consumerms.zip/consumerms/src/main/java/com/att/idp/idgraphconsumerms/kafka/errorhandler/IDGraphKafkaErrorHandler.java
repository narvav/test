package com.att.idp.idgraphconsumerms.kafka.errorhandler;

import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.RecordDeserializationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.listener.CommonErrorHandler;
import org.springframework.kafka.listener.ListenerExecutionFailedException;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.stereotype.Component;

/**
 * Custom Kafka error handler for handling deserialization and processing exceptions.
 */
@Component
public class IDGraphKafkaErrorHandler implements CommonErrorHandler {

    public static final Logger logger = LoggerFactory.getLogger(IDGraphKafkaErrorHandler.class);


    @Override
    public boolean handleOne(Exception exception, ConsumerRecord<?, ?> record, Consumer<?, ?> consumer, MessageListenerContainer container) {
        this.handle(exception, record, consumer);
        return true;
    }

    @Override
    public void handleOtherException(Exception exception, Consumer<?, ?> consumer, MessageListenerContainer container, boolean batchListener) {
        this.handle(exception, null, consumer);
    }

    /**
     * Handles exceptions from Kafka consumer.
     *
     * @param exception the exception thrown
     * @param record    the consumer record (may be null)
     * @param consumer  the Kafka consumer
     */
    void handle(Exception exception, ConsumerRecord<?, ?> record, Consumer<?, ?> consumer) {
        logger.info("Handling exception from IDGraphKafkaErrorHandler: {}", ConsumerUtil.encode(exception.getMessage()));

        // Log the root cause for debugging
        Throwable rootCause = exception.getCause();
        if (rootCause != null) {
            logger.error("Root cause exception: {} - {}", rootCause.getClass().getName(), ConsumerUtil.encode(rootCause.getMessage()));
        }

        if (exception instanceof RecordDeserializationException) {
            RecordDeserializationException ex = (RecordDeserializationException) exception;
            logger.error("RecordDeserializationException at topic={}, partition={}, offset={}. Skipping record.",
                    ConsumerUtil.encode(ex.topicPartition().topic()),
                    ex.topicPartition().partition(),
                    ex.offset());
            consumer.seek(ex.topicPartition(), ex.offset() + 1L);
            consumer.commitSync();
        } else if (isNonRetryableException(exception)) {
            // Handle non-retryable exceptions (e.g., JSON parsing errors) by skipping the record
            if (record != null) {
                TopicPartition topicPartition = new TopicPartition(record.topic(), record.partition());
                long nextOffset = record.offset() + 1L;
                logger.error("Non-retryable exception for topic={}, partition={}, offset={}. Skipping record. Error: {}",
                        ConsumerUtil.encode(record.topic()),
                        record.partition(),
                        record.offset(),
                        ConsumerUtil.encode(exception.getMessage()));
                consumer.seek(topicPartition, nextOffset);
                consumer.commitSync();
            } else {
                logger.error("Non-retryable exception with no record context: {}", ConsumerUtil.encode(exception.getMessage()));
            }
        } else {
            logger.error("Unhandled exception type: {}. Exception: {}",
                    ConsumerUtil.encode(exception.getClass().getName()),
                    ConsumerUtil.encode(exception.getMessage()));
        }
    }

    /**
     * Determines if an exception is non-retryable (should skip the record).
     *
     * @param exception the exception to check
     * @return true if the exception is non-retryable
     */
    private boolean isNonRetryableException(Exception exception) {
        Throwable cause = exception;

        // Unwrap ListenerExecutionFailedException to get the root cause
        if (exception instanceof ListenerExecutionFailedException && exception.getCause() != null) {
            cause = exception.getCause();
        }

        // Check for JSON parsing related exceptions
        return cause instanceof UnrecognizedPropertyException
                || cause instanceof com.fasterxml.jackson.core.JsonProcessingException
                || cause instanceof com.fasterxml.jackson.databind.JsonMappingException;
    }
}
