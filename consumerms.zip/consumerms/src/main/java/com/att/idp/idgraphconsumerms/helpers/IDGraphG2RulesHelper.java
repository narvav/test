package com.att.idp.idgraphconsumerms.helpers;

import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonUtil;
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Helper class for processing G2  event rules.
 * This class provides methods to validate and process G2 event messages based on configured rules and event data.
  * @author vn3904
 */
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/consumer.properties")
public class IDGraphG2RulesHelper extends BaseRuleHelper {

	private static final String sClassName = "IDGraphG2RulesHelper.";
	public static final Logger logger = LoggerFactory.getLogger(IDGraphG2RulesHelper.class);

	@Value("${G2_Events}")
	private String g2Events;

     /**
     * Processes a G2 event message by validating and applying event-specific rules.
     * @param event the event data as a map of key-value pairs
     * @return true if the event passes all validation and rule checks, false otherwise
     */
    public boolean processG2Message(Map<String, Object> event) {
        String sMethodName = ".processG2Message.";
        String stAppInfo = "";
        boolean processG2Msg = false;
            try {
                if (!isValidEventsData(event)) {
                    stAppInfo = "Events data is null or empty";
                    logger.error("{}{}IDGG2.PG2.01 : {}", sClassName, sMethodName, ConsumerUtil.sanitizeForLog(stAppInfo));
                    return false;
                }

               String eventName = (String) event.get("eventname");

                List<String> g2EventList = CommonUtil.parseToArray(g2Events, CommonDefs.VALUE_SEPARATOR_CHAR);
                if (g2EventList.isEmpty() || !g2EventList.contains(eventName)) {
                    stAppInfo = "Invalid eventName: " + event.get("eventname");
                    logger.error("{}{}IDGG2.PG2.03: {}", sClassName, sMethodName,  ConsumerUtil.sanitizeForLog(stAppInfo));

                    return false;
                }
                processG2Msg = true;
			} catch (Exception e) {
                stAppInfo = "Exception thrown from processG2Message : ";
                logger.error("{}{}IDGG2.PG2.05 : {}", sClassName, sMethodName,  ConsumerUtil.sanitizeForLog(stAppInfo),e);
			}
			return processG2Msg;
		}
}
