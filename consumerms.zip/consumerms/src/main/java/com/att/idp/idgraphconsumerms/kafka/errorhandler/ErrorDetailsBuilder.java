package com.att.idp.idgraphconsumerms.kafka.errorhandler;

import java.util.HashMap;
import java.util.Map;

public class ErrorDetailsBuilder {

    private final Map<String, String> errorDetails;

    private ErrorDetailsBuilder() {
        this.errorDetails = new HashMap<>();
    }

    public static ErrorDetailsBuilder builder() {
        return new ErrorDetailsBuilder();
    }

    public ErrorDetailsBuilder addDetail(String key, String value) {
        this.errorDetails.put(key, value);
        return this;
    }

    public Map<String, String> build() {
        return this.errorDetails;
    }
}