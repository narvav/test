package com.att.idp.idgraphconsumerms.helpers;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails;
import com.att.idp.idgraphconsumerms.kafka.errorhandler.ErrorDetailsBuilder;
import com.att.idp.idgraphconsumerms.kafka.model.BillingAccountStateChangeEvent;
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil;
import com.att.mpsys.common.utils.CErrorDefs;
import org.owasp.esapi.ESAPI;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;
import java.util.Map;

import static com.att.idp.idgraphconsumerms.utils.ConsumerUtil.sanitizeForLog;

@Service
public class CloseAccountPasscodeProcessor {

    private static final Logger logger = LoggerFactory.getLogger(CloseAccountPasscodeProcessor.class);
    private static final int MAX_ATTEMPTS = 2;
    private static final String SERVICE_TYPE_WIRELESS = "Wireless";
    private static final String SERVICE_TYPE_FIBER = "Fiber";

    @Value("${apiclient.rest.ua.serverUrl}")
    private String userAssoServerUrl;

    @Value("${apiclient.rest.ua.cred.endpoint}")
    private String uaCredEndpoint;

    @Value("${apiclient.rest.ua.username}")
    private String userName;

    @Value("${apiclient.rest.ua.password}")
    private String userPassword;

    private final RestTemplate restTemplate;
    private final CosmosFailedEventsWriter cosmosFailedEventsWriter;
    private final ObjectMapper objectMapper;
    private final GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker;

    public CloseAccountPasscodeProcessor(RestTemplate restTemplate,
                                         CosmosFailedEventsWriter cosmosFailedEventsWriter,
                                         ObjectMapper objectMapper,
                                         GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker) {
        this.restTemplate = restTemplate;
        this.cosmosFailedEventsWriter = cosmosFailedEventsWriter;
        this.objectMapper = objectMapper;
        this.gddnFailedEventCircuitBreaker = gddnFailedEventCircuitBreaker;
    }

    /**
     * Processes a BillingAccountStateChangeEvent message.
     * Extracts accountId and serviceType from the event payload,
     * maps serviceType to accountType (BSSEWIRELESS or BSSEFIBER),
     * and calls the deleteCredentials API.
     *
     * @param eventPayload the raw JSON string of the event
     * @return true if processing succeeded, false otherwise
     */
    public boolean process(String eventPayload) {
        try {
            BillingAccountStateChangeEvent event = objectMapper.readValue(eventPayload, BillingAccountStateChangeEvent.class);

            if (!ConsumerConstants.BsseMigration.EVENT_TYPE_BILLING_ACCOUNT_STATE_CHANGE.equals(event.getEventType())) {
                logger.debug("Skipping event with eventType: {}", sanitizeForLog(event.getEventType()));
                return false;
            }

            String accountJson = event.getEvent() != null ? event.getEvent().getAccount() : null;
            if (accountJson == null) {
                logger.warn("Event account JSON is null for eventId: {}", sanitizeForLog(event.getEventId()));
                return false;
            }

            JsonNode accountNode = objectMapper.readTree(accountJson);

            String state = accountNode.has("state") ? accountNode.get("state").asText() : null;
            if (!ConsumerConstants.BsseMigration.ACCOUNT_STATE_CLOSED.equalsIgnoreCase(state)) {
                logger.debug("Skipping event with account state: {} for eventId: {}", sanitizeForLog(state), sanitizeForLog(event.getEventId()));
                return false;
            }

            String accountId = accountNode.has("id") ? accountNode.get("id").asText() : null;
            if (accountId == null || accountId.isEmpty()) {
                logger.warn("Account id is missing in event payload for eventId: {}", sanitizeForLog(event.getEventId()));
                return false;
            }

            String serviceType = accountNode.has("serviceType") ? accountNode.get("serviceType").asText() : null;
            String accountType = mapServiceTypeToAccountType(serviceType);
            if (accountType == null) {
                logger.warn("Unknown or missing serviceType: {} for eventId: {}, accountId: {}",
                        sanitizeForLog(serviceType), sanitizeForLog(event.getEventId()), sanitizeForLog(accountId));
                return false;
            }

            logger.info("Processing CloseAccount for accountId: {}, accountType: {}, eventId: {}",
                    sanitizeForLog(accountId), sanitizeForLog(accountType), sanitizeForLog(event.getEventId()));

            // Circuit breaker: if pending failed events exist for this account+category,
            // short-circuit directly to Cosmos to preserve sequenced processing order
            final String eventName = ConsumerConstants.BsseMigration.EVENT_CG_INDI_ACCT_CLOSE;
            if (gddnFailedEventCircuitBreaker.shouldShortCircuit(accountId, eventName)) {
                logger.warn("CloseAccountPasscodeProcessor: Circuit breaker OPEN for accountId={}. " +
                        "Saving directly to Cosmos without calling downstream API.",
                        ESAPI.encoder().encodeForHTML(accountId));
                FailedEventUtil.saveFailedEventCircuitOpen(
                        cosmosFailedEventsWriter,
                        accountId,
                        eventPayload,
                        eventName,
                        CErrorDefs.SYS_ERR,
                        ConsumerConstants.GridGddnNotification.ERROR_CIRCUIT_BREAKER_OPEN,
                        this.uaCredEndpoint,
                        accountType
                );
                return true;
            }

            callDeleteCredentials(accountType, accountId, eventPayload);
            return true;

        } catch (JsonProcessingException e) {
            logger.error("Failed to parse BillingAccountStateChangeEvent payload: {}", sanitizeForLog(e.getMessage()), e);
            saveFailedEvent("UNKNOWN", eventPayload, CErrorDefs.ERR_INVALID_DATA, e.getMessage());
            return false;
        } catch (Exception e) {
            logger.error("Unexpected error processing CloseAccount event: {}", sanitizeForLog(e.getMessage()), e);
            return false;
        }
    }

    @Retryable(maxAttempts = MAX_ATTEMPTS, include = {HttpServerErrorException.class}, backoff = @Backoff(delay = 100))
    public void callDeleteCredentials(String accountType, String accountId, String eventPayload) {
        String resourceUri = userAssoServerUrl + uaCredEndpoint + "/" + accountId + "?accountType=" + accountType;

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(ConsumerConstants.Keys.AUTHORIZATION,
                "Basic " + Base64.getEncoder().encodeToString((userName + ":" + userPassword).getBytes()));
        headers.add(ConsumerConstants.Keys.X_ATT_CLIENTID, ConsumerConstants.BsseMigration.CLIENT_CUSTOMERGRAPH);
        headers.add(ConsumerConstants.Keys.IDP_TRACE_ID, MDC.get(ConsumerConstants.Keys.IDP_TRACE_ID));
        HttpEntity<?> httpEntity = new HttpEntity<>(headers);

        logger.info("Calling deleteCredentials API: {}", sanitizeForLog(resourceUri));

        try {
            ResponseEntity<JsonNode> response = restTemplate.exchange(resourceUri, HttpMethod.DELETE, httpEntity, JsonNode.class);
            logger.info("deleteCredentials API response status: {} for accountId: {}, accountType: {}",
                    response.getStatusCode(), sanitizeForLog(accountId), sanitizeForLog(accountType));
        } catch (HttpServerErrorException e) {
            logger.error("Retryable 5xx error from deleteCredentials API. Status: {}, accountId: {}, accountType: {}",
                    sanitizeForLog(e.getStatusCode().toString()), sanitizeForLog(accountId), sanitizeForLog(accountType));
            throw e;
        } catch (Exception e) {
            logger.error("Non-retryable exception calling deleteCredentials API for accountId: {}, accountType: {}: {}",
                    sanitizeForLog(accountId), sanitizeForLog(accountType), sanitizeForLog(e.getMessage()), e);
            saveFailedEvent(accountId, eventPayload, CErrorDefs.ERR_INVALID_DATA, e.getMessage());
        }
    }

    @Recover
    public void recoverDeleteCredentials(HttpServerErrorException e, String accountType, String accountId, String eventPayload) {
        logger.error("Exhausted retries calling deleteCredentials API for accountId: {}, accountType: {}: {}",
                sanitizeForLog(accountId), sanitizeForLog(accountType), sanitizeForLog(e.getMessage()));
        saveFailedEvent(accountId, eventPayload, CErrorDefs.ERR_INVALID_DATA, e.getMessage());
    }

    private String mapServiceTypeToAccountType(String serviceType) {
        if (serviceType == null) {
            return null;
        }
        if (serviceType.equalsIgnoreCase(SERVICE_TYPE_WIRELESS)) {
            return ConsumerConstants.BsseMigration.ACCOUNT_TYPE_BSSEWIRELESS;
        }
        if (serviceType.equalsIgnoreCase(SERVICE_TYPE_FIBER)) {
            return ConsumerConstants.BsseMigration.ACCOUNT_TYPE_BSSEFIBER;
        }
        return null;
    }

    private void saveFailedEvent(String accountId, String eventPayload, String errorCode, String errorMessage) {
        try {
            Map<String, String> errorDetails = ErrorDetailsBuilder.builder()
                    .addDetail(ConsumerConstants.ErrorDetails.ERROR_CODE, errorCode)
                    .addDetail(ConsumerConstants.ErrorDetails.ERROR_MESSAGE, errorMessage)
                    .addDetail(ConsumerConstants.ErrorDetails.FAILED_ENDPOINT, uaCredEndpoint)
                    .build();

            FailedEventDetails failedEventDetails = new FailedEventDetails(
                    accountId,
                    eventPayload,
                    ConsumerConstants.BsseMigration.EVENT_CG_INDI_ACCT_CLOSE,
                    errorDetails
            );
            cosmosFailedEventsWriter.saveFailedEventsToCosmos(failedEventDetails);
            logger.info("Saved failed event to Cosmos for accountId: {}, eventName: {}",
                    sanitizeForLog(accountId), ConsumerConstants.BsseMigration.EVENT_CG_INDI_ACCT_CLOSE);
        } catch (Exception ex) {
            logger.error("Failed to save failed event to Cosmos for accountId: {}: {}",
                    sanitizeForLog(accountId), sanitizeForLog(ex.getMessage()), ex);
        }
    }
}
