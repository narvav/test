package com.att.idp.idgraphconsumerms.kafka.model;

/**
 * Common interface for migration event payloads.
 * Implemented by MigrationBANNotification and ReverseMigratedInboundDataEvent.
 */
public interface MigrationEvent {

    /**
     * Gets the event type.
     * @return the event type
     */
    String getEventType();

    /**
     * Gets the event ID.
     * @return the event ID
     */
    String getEventId();

    /**
     * Gets the migration ID.
     * @return the migration ID
     */
    String getMigrationId();

    /**
     * Gets the source BAN.
     * @return the source BAN
     */
    String getSourceBan();

    /**
     * Gets the target BAN.
     * @return the target BAN
     */
    String getTargetBan();

    /**
     * Gets the GUID.
     * @return the GUID
     */
    String getGuid();

    /**
     * Gets the individual ID.
     * @return the individual ID
     */
    String getIndividualId();

    /**
     * Gets the original request as a string representation.
     * @return the original request as string
     */
    String getOriginalRequestAsString();

    /**
     * Gets the original request as an object for Cosmos DB storage.
     * This preserves the JSON structure when stored in Cosmos DB.
     * @return the original request object
     */
    Object getOriginalRequest();

    /**
     * Gets the subStatus.
     * @return the subStatus
     */
    String getSubStatus();

    /**
     * Gets the status.
     * @return the status
     */
    String getStatus();
}

