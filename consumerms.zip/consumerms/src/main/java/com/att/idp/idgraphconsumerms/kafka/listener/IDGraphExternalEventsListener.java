package com.att.idp.idgraphconsumerms.kafka.listener;

import com.att.idp.idgraphconsumerms.helpers.ExternalEventsProcessingHelper;
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import net.logstash.logback.argument.StructuredArguments;
import com.att.mpsys.common.utils.CommonErrorMap;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import com.att.idp.idgraph.events.model.ConsumerAction;
import com.att.idp.idgraph.events.service.ResilientEventConsumer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import java.util.Map;

/**
 * Kafka listener service for processing external IDGraph events and publishing notifications to downstream systems.
 * Delegates processing logic to {@link ExternalEventsProcessingHelper}.
 */
@Service
@Slf4j
public class IDGraphExternalEventsListener {

    private static final String CLASS_NAME = "IDGraphExternalEventsListener";

    @Autowired
    private  ExternalEventsProcessingHelper externalEventsProcessingHelper;
    private static final Logger logger = LoggerFactory.getLogger(IDGraphExternalEventsListener.class);
    private final ObjectMapper objectMapper;


    public IDGraphExternalEventsListener() {
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
        objectMapper.enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
    }

    /**
     * R5 / Phase B: dedup + sequence gate.
     * Conditional bean — absent when kafka.resiliency.use-unified-entity=false.
     */
    private ResilientEventConsumer resilientEventConsumer;

    /**
     * Setter injection for ResilientEventConsumer.
     * Called by Spring when kafka.resiliency.use-unified-entity=true.
     */
    @Autowired(required = false)
    public void setResilientEventConsumer(ResilientEventConsumer resilientEventConsumer) {
        this.resilientEventConsumer = resilientEventConsumer;
    }

    /**
     * Consumes external events from Kafka, processes each event, and publishes notifications to downstream systems.
     *
     * @param message  the map containing event data, expected to have a key "eventsData" with a list of events
     * @param messageHeaders Kafka message headers
     * @param ack Kafka acknowledgment object
     */
    @KafkaListener(
            id = "idgraphExtEventsListener",
            topics = "${idgraph.consumer.idgraphexternalevents.topic}",
            containerFactory = "idgraphExtEventsConsumerContainerFactory",
            groupId = "${idgraph.consumer.idgraphexternalevents.group-id}",
            concurrency = "${idgraph.consumer.idgraphexternalevents.concurrency:1}",
            autoStartup = "${idgraph.consumer.idgraphexternalevents.autoStartup:false}"
    )
    public void consumeIDGraphExtEventsData(
            @Payload String message,
           @Headers MessageHeaders messageHeaders,
            Acknowledgment ack) {
        // R5: skip duplicate / stale retried messages without processing.
        // Use Kafka message key (BAN/accountNumber) as entityKey fallback for dedup tracking.
        if (resilientEventConsumer != null) {
            String entityKey = messageHeaders.get("kafka_receivedMessageKey") != null
                    ? messageHeaders.get("kafka_receivedMessageKey").toString() : "";
            ConsumerAction action = resilientEventConsumer.evaluate(messageHeaders, entityKey);
            if (action != ConsumerAction.PROCESS) {
                log.info("REC_GATE: Skipping external events — action={}", action);
                ack.acknowledge();
                return;
            }
        }

        String sMethodName = ".consumeExternalEventsData.";
        log.info("{}{} WEB000 : Received eventsData. messageHeaders={}, payload={}", CLASS_NAME, sMethodName, StructuredArguments.entries(messageHeaders), ConsumerUtil.sanitizeForLog(message));

        Map<String, Object> hmResponse = null;
        String stAppInfo;

        try {
            logger.info("{}{}IDEEL.CIDGED.01 : {}", CLASS_NAME, sMethodName, HtmlUtils.htmlEscape(message));
            Map <String, Object> externalEventsMap = objectMapper.readValue(message, Map.class);
            // Delegate processing to helper
            MDC.put("idp-trace-id", externalEventsMap.get("transactionId") != null ? externalEventsMap.get("transactionId").toString() : "N/A");
            externalEventsProcessingHelper.processExternalEvents(externalEventsMap);
            MDC.remove("idp-trace-id");
            log.info("CONSUMER_EVENT_SUCCESS: listenerId=idgraphExtEventsListener");
            ack.acknowledge();
        } catch (Exception e) {
            hmResponse = CommonErrorMap.makeExceptionMap(e, log);
            stAppInfo = "Exception thrown from consumeIDGraphExtEventsData : " + hmResponse;
            logger.error("{}{}IDEEL.CIDGED.02 : {}", CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(stAppInfo));
            logger.error("CONSUMER_EVENT_FAILED: listenerId=idgraphExtEventsListener, error={}", e.getMessage());
        } finally {
            MDC.clear();
        }
        logger.info("{}{}WEB999 : hmResponse = {}", CLASS_NAME, sMethodName, StructuredArguments.entries(hmResponse));
    }
}