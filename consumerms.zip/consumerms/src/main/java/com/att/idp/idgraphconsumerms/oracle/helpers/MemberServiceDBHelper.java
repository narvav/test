package com.att.idp.idgraphconsumerms.oracle.helpers;

import java.util.List;
import java.util.Optional;

import com.att.idp.idgraphconsumerms.oracle.model.MemberServiceResult;
import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class MemberServiceDBHelper {

    private static final String sClassName = "MemberServiceDBHelper";
    public static final Logger logger = LoggerFactory.getLogger(MemberServiceDBHelper.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public MemberServiceDBHelper(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * Queries the member service database for services associated with a given sorInvariantId.
     *
     * @param sorInvariantId The unique identifier for the service of record.
     * @return A list of MemberServiceResult containing member details and service information.
     * @throws IllegalArgumentException if sorInvariantId is null or empty.
     * @throws RuntimeException if there is an error during the database query.
     */
    public List<MemberServiceResult> queryMemberService(String sorInvariantId) {
        String sMethodName = ".queryMemberService.";

        if (sorInvariantId == null || sorInvariantId.trim().isEmpty()) {
            logger.info("{}{} : Required parameter sor_invariant_id is missing", sClassName, sMethodName);
            throw new IllegalArgumentException("Required parameter sor_invariant_id is missing");
        }

        String sql = "SELECT m.member_num, m.member_name, ms.sor_invariant_id " +
                "FROM member m, memberservice ms " +
                "WHERE m.member_num = ms.member_num " +
                "AND ms.service_id = '61' " +
                "AND ms.sor_invariant_id = ?";

        try {
            return jdbcTemplate.query(sql, ps -> ps.setString(1, sorInvariantId), (rs, rowNum) -> {
                MemberServiceResult result = new MemberServiceResult();
                result.setMemberNum(rs.getString("member_num"));
                result.setMemberName(rs.getString("member_name"));
                result.setSorInvariantId(rs.getString("sor_invariant_id"));
                return result;
            });
        } catch (Exception e) {
            logger.error("{}{} : Error:: {}", sClassName, sMethodName, e.getMessage());
            throw new RuntimeException("Database query failed", e);
        }
    }

    public Optional<String> getGuidForGivenCTN(String ctn) {
        String sql = "SELECT member_num AS GUID FROM memberservice WHERE service_id='23' and instance_id = ?";
        try {
            String guid = jdbcTemplate.query(sql, ps -> ps.setString(1, ctn), (rs, rowNum) -> rs.getString("GUID"))
                    .stream()
                    .findFirst()
                    .orElse(null);
            return Optional.ofNullable(guid);
        } catch (Exception e) {
            logger.error("Error generating GUID for CTN {}: {}", ESAPI.encoder().encodeForHTML(ctn), ESAPI.encoder().encodeForHTML(e.getMessage()));
            throw new RuntimeException("Failed to get GUID for CTN", e);
        }
    }

    public Optional<MemberServiceResult> getOldPhoneNumberFromSubscriptionId(String sorInvariantId) {
        if (sorInvariantId == null || sorInvariantId.trim().isEmpty()) {
            logger.info("MemberServiceDBHelper.getOldPhoneNumberFromSubscriptionId : Required parameter sor_invariant_id is missing");
            throw new IllegalArgumentException("Required parameter sor_invariant_id is missing");
        }

        String sql = "SELECT ms.member_num, ms.instance_id FROM memberservice ms WHERE ms.service_id='23' and ms.sor_invariant_id = ?";
        try {
            List<MemberServiceResult> results = jdbcTemplate.query(sql, ps -> ps.setString(1, sorInvariantId), (rs, rowNum) -> {
                MemberServiceResult result = new MemberServiceResult();
                result.setMemberNum(rs.getString("member_num"));
                result.setInstanceId(rs.getString("instance_id"));
                return result;
            });
            return results.stream().findFirst();
        } catch (Exception e) {
            logger.error("Error retrieving member service details for SOR Invariant ID {}: {}", ESAPI.encoder().encodeForHTML(sorInvariantId), ESAPI.encoder().encodeForHTML(e.getMessage()));
            throw new RuntimeException("Failed to retrieve member service details", e);
        }
    }

    public Optional<MemberServiceResult> getOldSubscriptionIdFromInstanceId(String instanceId) {
        if (instanceId == null || instanceId.trim().isEmpty()) {
            logger.info("MemberServiceDBHelper.getOldSubscriptionIdFromInstanceId : Required parameter instanceId is missing");
            throw new IllegalArgumentException("Required parameter instanceId is missing");
        }

        String sql = "SELECT ms.member_num, ms.sor_invariant_id FROM memberservice ms WHERE ms.service_id='23' and ms.instance_id = ?";
        try {
            List<MemberServiceResult> results = jdbcTemplate.query(sql, ps -> ps.setString(1, instanceId), (rs, rowNum) -> {
                MemberServiceResult result = new MemberServiceResult();
                result.setMemberNum(rs.getString("member_num"));
                result.setSorInvariantId(rs.getString("sor_invariant_id"));
                return result;
            });
            return results.stream().findFirst();
        } catch (Exception e) {
            logger.error("Error retrieving member service details for instanceId {}: {}", ESAPI.encoder().encodeForHTML(instanceId), ESAPI.encoder().encodeForHTML(e.getMessage()));
            throw new RuntimeException("Failed to retrieve member service details", e);
        }
    }

    public Optional<String> getGuidForGivenBillingAccountNumber(String billingAccountNumber) {

        String sql = "SELECT member_num AS GUID FROM memberservice WHERE sor_id='13' and service_id='32' and sor_invariant_id= ? ";
        try {
            String guid = jdbcTemplate.query(sql, ps -> ps.setString(1, billingAccountNumber), (rs, rowNum) -> rs.getString("GUID"))
                    .stream()
                    .findFirst()
                    .orElse(null);
            return Optional.ofNullable(guid);
        } catch (Exception e) {
            logger.error("Error generating GUID for BAN {}: {}", ESAPI.encoder().encodeForHTML(billingAccountNumber), ESAPI.encoder().encodeForHTML(e.getMessage()));
            throw new RuntimeException("Failed to get GUID for BAN", e);
        }
    }
}