package com.att.idp.idgraphconsumerms.kafka.listener;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.kafka.dmctn.service.BackendService;
import com.att.idp.idgraphconsumerms.kafka.dmctn.service.SubscriberServiceFactory;
import com.att.idp.idgraphconsumerms.kafka.model.SubscriberEventNotification;
import com.att.idp.idgraphconsumerms.kafka.model.Subscriber;
import com.att.idp.idgraphconsumerms.request.validator.RequestValidator;
import com.att.idp.idgraph.events.model.ConsumerAction;
import com.att.idp.idgraph.events.service.ResilientEventConsumer;
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.Random;

/**
 * Listener for Subscriber Notification events from Azure Event Hubs (Kafka interface).
 * Uses manual acknowledgment and mirrors existing listener patterns without modifying them.
 */
@Service
public class SubscriberNotificationEventListener {

    private static final Logger logger = LoggerFactory.getLogger(SubscriberNotificationEventListener.class);

    private ObjectMapper objectMapper;

    @Autowired
    private RequestValidator requestValidator;

    @Autowired
    SubscriberServiceFactory subscriberServiceFactory;

    /**
     * R5 / Phase B: consumer-side dedup + sequence gate. Conditional bean (only present when
     * kafka.resiliency.use-unified-entity=true) so we inject as required=false. When absent,
     * the gate is bypassed and the listener behaves exactly as before.
     */
    private ResilientEventConsumer resilientEventConsumer;

    /**
     * Setter injection for ResilientEventConsumer.
     * Called by Spring when kafka.resiliency.use-unified-entity=true.
     */
    @Autowired(required = false)
    public void setResilientEventConsumer(ResilientEventConsumer resilientEventConsumer) {
        this.resilientEventConsumer = resilientEventConsumer;
    }

    public SubscriberNotificationEventListener() {
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
        objectMapper.enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
    }

    @KafkaListener(id = "subscriberNotificationEventListener",
            topics = "${idgraph.consumer.subscribernotificationconsumer.topic}",
            containerFactory = "subscriberNotificationConsumerContainerFactory",
            groupId = "${idgraph.consumer.subscribernotificationconsumer.group-id}",
            concurrency = "${idgraph.consumer.subscribernotificationconsumer.concurrency:1}",
            autoStartup = "${idgraph.consumer.subscribernotificationconsumer.autoStartup:false}")
    public void consumeSubscriberNotification(@Payload String message,
                                              @Headers MessageHeaders headers,
                                              Acknowledgment acknowledgment) throws Exception {
        // R5: dedup + sequence gate for batch-retried messages. Happy-path messages
        // (no x-idg-sequence header) always return PROCESS so this is a no-op overhead.
        // Use Kafka message key (BAN/accountNumber) as entityKey fallback for dedup tracking.
        if (resilientEventConsumer != null) {
            String entityKey = headers.get("kafka_receivedMessageKey") != null
                    ? headers.get("kafka_receivedMessageKey").toString() : "";
            ConsumerAction action = resilientEventConsumer.evaluate(headers, entityKey);
            if (action != ConsumerAction.PROCESS) {
                logger.info("REC_GATE: Skipping subscriber notification — action={}", action);
                acknowledgment.acknowledge();
                return;
            }
        }
        try {
            logger.info("SubscriberNotificationEvent received. headers={}, payload={}", headers, message);
            long startTm = System.currentTimeMillis();
            logger.info("WEB000 : GDDN SubscriberEvent consumer initiation: {}", message);
            MDC.put(ConsumerConstants.Keys.X_ATT_CLIENTID, ConsumerConstants.DmctnSubscriberChangeEvent.CLIENT_ATLASBUS);
            SubscriberEventNotification cgSubscriberEvent = safeConvertToObject(message, SubscriberEventNotification.class)
                    .orElseThrow(() -> new JsonProcessingException("Failed to deserialize message to ChangeSubscriberEvent") {
                    });

            if(cgSubscriberEvent!=null) {
                String eventType = cgSubscriberEvent.getEventName();
                Subscriber subscriber = getSubscriber(cgSubscriberEvent);
                MDC.put(ConsumerConstants.Keys.IDP_TRACE_ID, subscriber.getIdpTraceId());
                MDC.put(ConsumerConstants.Keys.IDPCTX_SESSION_ID, cgSubscriberEvent.getTlgMessageId());
                logger.info("idp-trace-id: {}", subscriber.getIdpTraceId());
                BackendService service = subscriberServiceFactory.getService(eventType);
                if (service != null) {
                    logger.info("Processing GDDN SubscriberEvent for eventType: {}, subscriber id: {}", eventType, subscriber.getId());
                    service.execute(subscriber, com.att.idp.idgraphconsumerms.kafka.dmctn.service.EventSource.GDDN);
                } else {
                    logger.error("Received message with unsupported eventId: {}. Acknowledging the message", eventType);
                }
                String sTimeTaken = ConsumerUtil.getElapsedTimeInSecs(startTm) + " seconds";
                logger.info("WEB999 : Total time taken : {} GDDN SubscriberEvent consumer Response : {}", sTimeTaken, message);
                logger.info("Committing the offset for the message");

            } else{
                logger.error("Deserialized ChangeDataEvent is null. Acknowledging the message without processing.");
            }
            logger.info("CONSUMER_EVENT_SUCCESS: listenerId=subscriberNotificationEventListener");
            acknowledgment.acknowledge();
        } catch (Exception e) {
            logger.error("CONSUMER_EVENT_FAILED: listenerId=subscriberNotificationEventListener, error={}", e.getMessage());
            throw e;
        } finally {
            MDC.clear();
        }
    }

    public static <T> Optional<T> safeConvertToObject(String inputJson, Class<T> theClass) {
        String actualJson = inputJson;
        // Detect and unwrap double-encoded JSON
        if (actualJson != null && actualJson.startsWith("\"") && actualJson.endsWith("\"")) {
            actualJson = actualJson.substring(1, actualJson.length() - 1)
                    .replace("\\\"", "\"");
        }
        T result = JsonService.convertToObject(actualJson, theClass);
        return Optional.ofNullable(result);
    }

    private  Subscriber getSubscriber(SubscriberEventNotification cgSubscriberEvent) {
        Subscriber subscriberRequest = new Subscriber();
        subscriberRequest.setId(cgSubscriberEvent.getSubId());
        subscriberRequest.setPhoneNumber(cgSubscriberEvent.getSubscriberNumber());
        subscriberRequest.setBillingAccount(cgSubscriberEvent.getBillingAccountNumber());
        subscriberRequest.setStatus(cgSubscriberEvent.getSubscriberStatus());
        subscriberRequest.setIdpTraceId(cgSubscriberEvent.getEventId());
        return subscriberRequest;
    }
}

