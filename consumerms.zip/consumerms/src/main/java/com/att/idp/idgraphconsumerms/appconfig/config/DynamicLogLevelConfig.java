package com.att.idp.idgraphconsumerms.appconfig.config;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;

import java.util.Set;

@Configuration
@Slf4j
@RequiredArgsConstructor
public class DynamicLogLevelConfig {

    static final String ROOT_LOGGER = Logger.ROOT_LOGGER_NAME;
    static final String IDP_LOGGER = "com.att.idp";
    static final String IDP_API_LOGGER = "com.att.idp.logging";

    private static final Set<String> VALID_LEVELS =
            Set.of("TRACE", "DEBUG", "INFO", "WARN", "ERROR");

    private final IDGraphAzureAppConfig azureAppConfig;

    @EventListener(ApplicationReadyEvent.class)
    public void onApplicationReady() {
        log.info("DynamicLogLevelConfig: applying initial log levels from Azure App Config");
        applyAllLogLevels();
    }

    @EventListener(RefreshScopeRefreshedEvent.class)
    public void onConfigurationRefresh() {
        log.info("DynamicLogLevelConfig: re-applying log levels after config refresh");
        applyAllLogLevels();
    }

    public void applyAllLogLevels() {
        applyLogLevel(ROOT_LOGGER,    azureAppConfig.getLogLevelRoot());
        applyLogLevel(IDP_LOGGER,     azureAppConfig.getLogLevelIdp());
        applyLogLevel(IDP_API_LOGGER, azureAppConfig.getLogLevelIdpApi());
    }

    public void applyLogLevel(String loggerName, String levelValue) {
        if (levelValue == null || levelValue.isBlank()) {
            log.warn("DynamicLogLevelConfig: null/blank level supplied for logger '{}' � skipping", loggerName);
            return;
        }
        String normalised = levelValue.trim().toUpperCase();
        if (!VALID_LEVELS.contains(normalised)) {
            log.warn("DynamicLogLevelConfig: invalid log level '{}' for logger '{}'. Accepted values: {}. Existing level retained.",
                    levelValue, loggerName, VALID_LEVELS);
            return;
        }
        LoggerContext loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();
        Logger targetLogger = loggerContext.getLogger(loggerName);
        Level previousLevel = targetLogger.getLevel();
        Level newLevel = Level.valueOf(normalised);
        if (newLevel.equals(previousLevel)) {
            log.debug("DynamicLogLevelConfig: logger '{}' level unchanged at {}", loggerName, normalised);
            return;
        }
        targetLogger.setLevel(newLevel);
        log.info("DynamicLogLevelConfig: logger '{}' level changed {} -> {}", loggerName, previousLevel, normalised);
    }
}