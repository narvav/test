package com.att.idp.idgraphconsumerms.model;

import com.att.idp.idgraphconsumerms.kafka.model.Association;
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserAssociationChangeRequest {
    private String guid;
    private List<Association> associationList;
    private String suppressNotification;
    private String transactionType;
    private String idpTraceId;
}