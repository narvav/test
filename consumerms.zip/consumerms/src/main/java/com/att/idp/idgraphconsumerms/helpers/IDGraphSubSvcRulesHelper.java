package com.att.idp.idgraphconsumerms.helpers;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Helper class for SUBSVC routing and payload transformation.
 */
@Slf4j
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/consumer.properties")
public class IDGraphSubSvcRulesHelper extends BaseRuleHelper {

    private static final String CLASS_NAME = "IDGraphSubSvcRulesHelper";
    private static final String EVENT_NAME_KEY = "eventname";
    private static final String HANDLE_KEY = "handle";
    private static final String DOMAIN_KEY = "domain";
    private static final String BAN_KEY = "ban";
    private static final String CALLING_SYSTEM_ID_KEY = "callingSystemId";
    private static final String REGISTRATION_DATE_KEY = "registrationDate";
    private static final String IDP_TRACE_ID_KEY = "idpTraceId";
    private static final String LS_REG_NOTIFY = "LSRegNotify";
    private static final String ADD_MEMBER_LIST = "AddMemberList";
    private static final String AUTOGEN = "Autogen";
    private static final String EXISTING_REG_VOIP = "ExistingRegVoIP";
    private static final String ADDING_VOIP_TO_PARENT = "AddingVoIPToParent";
    private static final String EXISTING_REG = "ExistingReg";
    private static final String UPDATE_SERVICES_STATUS_LIST = "UpdateServicesStatusList";
    private static final String TRANSACTION_NAME_KEY = "transactionName";
    private static final String ACCOUNT_STATUS_KEY = "accountStatus";
    private static final String USER_STATUS_ATTRIBUTE = "USERSTATUS";
    private static final String ACCOUNT_STATUS_SUSPENDED = "Suspended";
    private static final String ACCOUNT_STATUS_ENABLED = "Enabled";
    private static final String USER_STATUS_SUSPENDED = "SUSPENDED";
    private static final String USER_STATUS_ACTIVE = "ACTIVE";
    private static final String EVENT_TYPE_SUBSCRIPTION_SERVICE = "SubscriptionService";
    private static final String ATTRIBUTE_NAME_KEY = "attributeName";
    private static final String ATTRIBUTE_VALUE_KEY = "attributeValue";
    private static final String ATTRIBUTES_KEY = "attributes";

    private static final List<Map<String, String>> PARENT_ATTRIBUTES = List.of(
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONANONYMOUSCALLREJECTIONIND", ATTRIBUTE_VALUE_KEY, "Y"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONDONOTDISTURBIND", ATTRIBUTE_VALUE_KEY, "Y"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONCALLFORWARDUNREGISTEREDIND", ATTRIBUTE_VALUE_KEY, "Y"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONCALLFORWARDNOANSWERIND", ATTRIBUTE_VALUE_KEY, "Y"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONCALLFORWARDINGIND", ATTRIBUTE_VALUE_KEY, "Y"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONPUBLISHSUBSCRIBERIND", ATTRIBUTE_VALUE_KEY, "Y"),
            Map.of(ATTRIBUTE_NAME_KEY, "ADDRESSBOOKIND", ATTRIBUTE_VALUE_KEY, "N"),
            Map.of(ATTRIBUTE_NAME_KEY, "USERSTATUS", ATTRIBUTE_VALUE_KEY, "ACTIVE"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONCALLFORWARDALLIND", ATTRIBUTE_VALUE_KEY, "Y"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONCALLFORWARDBUSYIND", ATTRIBUTE_VALUE_KEY, "Y"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONSIMULTANEOUSRINGIND", ATTRIBUTE_VALUE_KEY, "Y"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONCALLACCEPTANCEIND", ATTRIBUTE_VALUE_KEY, "Y"),
            Map.of(ATTRIBUTE_NAME_KEY, "PRIMARYMEMBERIND", ATTRIBUTE_VALUE_KEY, "Y"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONCALLREJECTIND", ATTRIBUTE_VALUE_KEY, "Y"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONAUTOATTENDANTIND", ATTRIBUTE_VALUE_KEY, "Y")
    );

    private static final List<Map<String, String>> CHILD_ATTRIBUTES = List.of(
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONANONYMOUSCALLREJECTIONIND", ATTRIBUTE_VALUE_KEY, "N"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONDONOTDISTURBIND", ATTRIBUTE_VALUE_KEY, "N"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONCALLFORWARDUNREGISTEREDIND", ATTRIBUTE_VALUE_KEY, "N"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONCALLFORWARDNOANSWERIND", ATTRIBUTE_VALUE_KEY, "N"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONCALLFORWARDINGIND", ATTRIBUTE_VALUE_KEY, "N"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONPUBLISHSUBSCRIBERIND", ATTRIBUTE_VALUE_KEY, "N"),
            Map.of(ATTRIBUTE_NAME_KEY, "ADDRESSBOOKIND", ATTRIBUTE_VALUE_KEY, "N"),
            Map.of(ATTRIBUTE_NAME_KEY, "USERSTATUS", ATTRIBUTE_VALUE_KEY, "ACTIVE"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONCALLFORWARDALLIND", ATTRIBUTE_VALUE_KEY, "N"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONCALLFORWARDBUSYIND", ATTRIBUTE_VALUE_KEY, "N"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONSIMULTANEOUSRINGIND", ATTRIBUTE_VALUE_KEY, "N"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONCALLACCEPTANCEIND", ATTRIBUTE_VALUE_KEY, "N"),
            Map.of(ATTRIBUTE_NAME_KEY, "PRIMARYMEMBERIND", ATTRIBUTE_VALUE_KEY, "N"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONCALLREJECTIND", ATTRIBUTE_VALUE_KEY, "N"),
            Map.of(ATTRIBUTE_NAME_KEY, "PERMISSIONAUTOATTENDANTIND", ATTRIBUTE_VALUE_KEY, "N")
    );

    /**
     * Validates if source event qualifies for SUBSVC publishing.
     *
     * @param event source event
     * @return true when event is eligible for SUBSVC transformation
     */
    public boolean processSubSvcMessage(Map<String, Object> event) {
        final String sMethodName = ".processSubSvcMessage";
        if (!isValidEventsData(event)) {
            log.info("{}{} IDGSSRH.PSM.01: Event payload is empty", CLASS_NAME, sMethodName);
            return false;
        }

        String eventName = resolveStringField(event, EVENT_NAME_KEY);
        if (eventName == null) {
            log.info("{}{} IDGSSRH.PSM.05: SUBSVC skipped for eventName null - not a supported event type",
                    CLASS_NAME, sMethodName);
            return false;
        }
        return switch (eventName) {
            case UPDATE_SERVICES_STATUS_LIST -> validateUpdateServicesStatusList(event, sMethodName);
            case LS_REG_NOTIFY -> validateLsRegNotify(event, sMethodName);
            case ADD_MEMBER_LIST -> validateAddMemberList(event, sMethodName);
            default -> {
                log.info("{}{} IDGSSRH.PSM.05: SUBSVC skipped for event {} - not a supported event type",
                        CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(eventName));
                yield false;
            }
        };
    }

    private boolean validateUpdateServicesStatusList(Map<String, Object> event, String sMethodName) {
        if (!isSubHasVoIPChildEvent(event)) {
            log.info("{}{} IDGSSRH.PSM.03: SUBSVC skipped for UpdateServicesStatusList - not SubHasVoIP child event", CLASS_NAME, sMethodName);
            return false;
        }
        String memberInfoHandle = resolveMemberInfoField(event, HANDLE_KEY);
        if (StringUtils.isBlank(memberInfoHandle)) {
            log.info("{}{} IDGSSRH.PSM.04: SUBSVC skipped for UpdateServicesStatusList - memberInfo handle is blank", CLASS_NAME, sMethodName);
            return false;
        }
        return true;
    }

    private boolean validateLsRegNotify(Map<String, Object> event, String sMethodName) {
        String ban = resolveStringField(event, BAN_KEY);
        String handle = resolveStringField(event, HANDLE_KEY);
        String domain = resolveStringField(event, DOMAIN_KEY);

        boolean valid = StringUtils.isNotBlank(ban)
                && StringUtils.isNotBlank(handle)
                && (handle.contains("@") || StringUtils.isNotBlank(domain));

        if (!valid) {
            log.info("{}{} IDGSSRH.PSM.02: SUBSVC validation failed for event {}",
                    CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(LS_REG_NOTIFY));
        }
        return valid;
    }

    private boolean validateAddMemberList(Map<String, Object> event, String sMethodName) {
        String subEvent = resolveStringField(event, ConsumerConstants.SUB_EVENT);
        if (AUTOGEN.equals(subEvent)) {
            return true;
        }
        String parentChildInd = resolveMemberInfoField(event, ConsumerConstants.PARENT_CHILD_IND);
        boolean isChildWithEligibleSubEvent = ConsumerConstants.CHILD_IND.equals(parentChildInd)
                && (EXISTING_REG_VOIP.equals(subEvent) || ADDING_VOIP_TO_PARENT.equals(subEvent) || EXISTING_REG.equals(subEvent));
        if (!isChildWithEligibleSubEvent) {
            log.info("{}{} IDGSSRH.PSM.06: SUBSVC skipped for AddMemberList - subEvent={} parent_child_ind={} (expected Autogen, or child with subEvent in [ExistingRegVoIP, AddingVoIPToParent, ExistingReg])",
                    CLASS_NAME, sMethodName, subEvent, parentChildInd);
        }
        return isChildWithEligibleSubEvent;
    }

    private String resolveStringField(Map<String, Object> event, String key) {
        Object value = event.get(key);
        return value != null ? value.toString() : null;
    }

    private String resolveStringFieldOrEmpty(Map<String, Object> event, String key) {
        Object value = event.get(key);
        return value != null ? value.toString() : "";
    }

    /**
     * Transforms source event into SUBSVC envelope.
     *
     * @param event source event
     * @return transformed SUBSVC payload
     */
    public HashMap<String, Object> transformToSubSvcPayload(Map<String, Object> event) {
        String eventName = resolveStringField(event, EVENT_NAME_KEY);
        if (UPDATE_SERVICES_STATUS_LIST.equals(eventName)) {
            return buildUpdateServicesStatusListPayload(event);
        }

        if (LS_REG_NOTIFY.equals(eventName) || ADD_MEMBER_LIST.equals(eventName)) {
            HashMap<String, Object> payload = new HashMap<>();
            String traceId = resolveStringFieldOrEmpty(event, IDP_TRACE_ID_KEY);
            String subEvent = resolveStringFieldOrEmpty(event, ConsumerConstants.SUB_EVENT);

            String callingSystemId = resolveStringFieldOrEmpty(event, CALLING_SYSTEM_ID_KEY);
            String ban = "";
            String registrationDate = "";
            String handle = "";
            String domain = "";
            if (LS_REG_NOTIFY.equals(eventName)) {
                ban = resolveStringFieldOrEmpty(event, BAN_KEY);
                registrationDate = resolveStringFieldOrEmpty(event, REGISTRATION_DATE_KEY);
                handle = resolveStringFieldOrEmpty(event, HANDLE_KEY);
                domain = resolveStringFieldOrEmpty(event, DOMAIN_KEY);
            } else {
                ban = resolveMemberInfoField(event, BAN_KEY);
                registrationDate = resolveMemberInfoField(event, REGISTRATION_DATE_KEY);
                handle = resolveMemberInfoField(event, HANDLE_KEY);
                domain = resolveMemberInfoField(event, DOMAIN_KEY);
            }
            String memberId = resolveMemberId(handle, domain);

            payload.put("eventId", "IdgraphSubSvcMs-" + traceId);
            payload.put("eventType", EVENT_TYPE_SUBSCRIPTION_SERVICE);
            payload.put("eventTime", Instant.now().toString());

            List<Map<String, Object>> eventDetails = new ArrayList<>();
            if (LS_REG_NOTIFY.equals(eventName) || (ADD_MEMBER_LIST.equals(eventName) && AUTOGEN.equals(subEvent))) {
                Map<String, Object> updateMemberAsync = new HashMap<>();
                updateMemberAsync.put("category", "UpdateMemberAsync");
                updateMemberAsync.put("subCategory", "UpdateSubscriber");
                updateMemberAsync.put("clientId", callingSystemId);
                updateMemberAsync.put("transactionName", "UpdateSubscriber");
                updateMemberAsync.put(CALLING_SYSTEM_ID_KEY, callingSystemId);
                updateMemberAsync.put(BAN_KEY, ban);
                updateMemberAsync.put(REGISTRATION_DATE_KEY, registrationDate);
                updateMemberAsync.put("memberId", memberId);
                eventDetails.add(updateMemberAsync);
            }

            Map<String, Object> addUser = new HashMap<>();
            addUser.put("category", "AddUser");
            addUser.put(BAN_KEY, ban);
            addUser.put("clientId", callingSystemId);
            addUser.put("transactionName", "AddUser");
            addUser.put(CALLING_SYSTEM_ID_KEY, callingSystemId);
            addUser.put("memberId", memberId);
            if (LS_REG_NOTIFY.equals(eventName) || (ADD_MEMBER_LIST.equals(eventName) && AUTOGEN.equals(subEvent))) {
                addUser.put(ATTRIBUTES_KEY, PARENT_ATTRIBUTES);
            } else {
                addUser.put(ATTRIBUTES_KEY, CHILD_ATTRIBUTES);
            }
            eventDetails.add(addUser);

            payload.put("eventDetails", eventDetails);
            return payload;
        }
        return new HashMap<>(); // Return an empty payload for unsupported event names
    }

    private HashMap<String, Object> buildUpdateServicesStatusListPayload(Map<String, Object> event) {
        HashMap<String, Object> payload = new HashMap<>();
        String traceId = resolveStringFieldOrEmpty(event, IDP_TRACE_ID_KEY);
        String callingSystemId = resolveStringFieldOrEmpty(event, CALLING_SYSTEM_ID_KEY);
        String transactionName = resolveStringFieldOrEmpty(event, TRANSACTION_NAME_KEY);
        String memberInfoHandle = resolveMemberInfoField(event, HANDLE_KEY);
        String memberInfoDomain = resolveMemberInfoField(event, DOMAIN_KEY);
        String accountStatus = resolveMemberInfoField(event, ACCOUNT_STATUS_KEY);
        String userStatus = ACCOUNT_STATUS_SUSPENDED.equals(accountStatus) ? USER_STATUS_SUSPENDED
                : ACCOUNT_STATUS_ENABLED.equals(accountStatus) ? USER_STATUS_ACTIVE : "";

        payload.put("eventId", "IdgraphSubSvcMs-" + traceId);
        payload.put("eventType", EVENT_TYPE_SUBSCRIPTION_SERVICE);
        payload.put("eventTime", Instant.now().toString());

        List<Map<String, Object>> eventDetails = new ArrayList<>();

        Map<String, Object> updateUser = new HashMap<>();
        updateUser.put("clientId", callingSystemId);
        updateUser.put("category", "UpdateUser");
        updateUser.put(TRANSACTION_NAME_KEY, transactionName);
        updateUser.put(CALLING_SYSTEM_ID_KEY, callingSystemId);
        updateUser.put("memberId", memberInfoHandle);
        updateUser.put(DOMAIN_KEY, memberInfoDomain);
        updateUser.put(ATTRIBUTES_KEY, List.of(Map.of(ATTRIBUTE_NAME_KEY, USER_STATUS_ATTRIBUTE, ATTRIBUTE_VALUE_KEY, userStatus)));
        eventDetails.add(updateUser);

        payload.put("eventDetails", eventDetails);
        return payload;
    }

    private String resolveMemberInfoField(Map<String, Object> event, String fieldKey) {
        Object memberInfoObj = event.get(ConsumerConstants.MEMBER_INFO);
        if (memberInfoObj instanceof List<?> memberInfoList && !memberInfoList.isEmpty()) {
            Object firstEntry = memberInfoList.get(0);
            if (firstEntry instanceof Map<?, ?> memberInfo) {
                Object val = memberInfo.get(fieldKey);
                return val != null ? val.toString() : "";
            }
        }
        return "";
    }

    private boolean isSubHasVoIPChildEvent(Map<String, Object> event) {
        String subEvent = event.get(ConsumerConstants.SUB_EVENT) != null ? event.get(ConsumerConstants.SUB_EVENT).toString() : null;
        if (!ConsumerConstants.SUB_HAS_VOIP.equals(subEvent)) {
            return false;
        }
        Object memberInfoObj = event.get(ConsumerConstants.MEMBER_INFO);
        if (!(memberInfoObj instanceof List<?> memberInfoList) || memberInfoList.isEmpty()) {
            return false;
        }
        Object firstEntry = memberInfoList.get(0);
        if (!(firstEntry instanceof Map<?, ?> memberInfo)) {
            return false;
        }
        return ConsumerConstants.CHILD_IND.equals(memberInfo.get(ConsumerConstants.PARENT_CHILD_IND));
    }

    private String resolveMemberId(String handle, String domain) {
        if (handle.contains("@")) {
            return handle;
        }
        return StringUtils.isNotBlank(domain) ? handle + "@" + domain : handle;
    }
}
