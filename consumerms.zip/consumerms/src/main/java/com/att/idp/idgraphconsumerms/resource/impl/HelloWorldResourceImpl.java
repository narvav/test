package com.att.idp.idgraphconsumerms.resource.impl;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;

import com.att.idp.idgraphconsumerms.model.UserLombok;
import com.att.idp.idgraphconsumerms.resource.HelloWorldResource;

/**
 * This class, HelloWorldResourceImpl, is an implementation of the HelloWorldResource interface.
 *
 * It is annotated with @Controller, indicating that it's a Spring MVC Controller.
 *
 * The class contains one method:
 * - getHelloWorld is a method that overrides the same method from the HelloWorldResource interface. It takes a HttpServletRequest object as input and returns a Response object.
 *
 * The class also contains a Logger instance, LOGGER, for logging purposes.
 */
@Controller
public class HelloWorldResourceImpl implements HelloWorldResource {

	private static final Logger LOGGER = LoggerFactory.getLogger(HelloWorldResourceImpl.class);

	@Override
	public Response getHelloWorld(HttpServletRequest request) {

		String str = "Testing IDMUserRegistrationMs changes";
		LOGGER.info("IDMUserRegistrationMs Sample Test : " + str);
		UserLombok lombok = new UserLombok();
		lombok.setFirstName("Lombok");
		lombok.setLastName("Installation");
		return Response.ok(str).build();
	}
}