package com.att.idp.idgraphconsumerms.kafka.dmctn.service;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails;
import com.att.idp.idgraphconsumerms.kafka.errorhandler.ErrorDetailsBuilder;
import com.att.idp.idgraphconsumerms.kafka.model.Subscriber;
import com.att.idp.idgraphconsumerms.model.PlatformHandlerRequest;
import com.att.idp.idgraphconsumerms.model.ProvisionEnablerRequest;
import com.att.idp.idgraphconsumerms.model.UserAssociationChangeRequest;
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.att.mpsys.common.utils.CErrorDefs;

import com.fasterxml.jackson.databind.JsonNode;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;
import java.util.Map;

@Service
public class ApiRestClient {

    @Value("${apiclient.rest.ua.serverUrl}")
    private String userAssoServerUrl;

    @Value("${apiclient.rest.ua.username}")
    private String userName;

    @Value("${apiclient.rest.ua.password}")
    private String userPassword;

    @Autowired
    private CosmosFailedEventsWriter cosmosFailedEventsWriter;

    private final RestTemplate restTemplate;

    private static final Logger logger = LoggerFactory.getLogger(ApiRestClient.class);
    private static final int MAX_ATTEMPTS = 2;

    public ApiRestClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Retryable(maxAttempts = MAX_ATTEMPTS, retryFor = {HttpServerErrorException.class})
    public ResponseEntity<JsonNode> sendPostRequest(String endpoint, UserAssociationChangeRequest outgoingRequest, String eventName) {
        String resourceUri = userAssoServerUrl + endpoint;

        String requestBody = JsonService.getJsonFromObject(outgoingRequest);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(ConsumerConstants.Keys.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString((userName + ":" + userPassword).getBytes()));
        headers.add(ConsumerConstants.Keys.X_ATT_CLIENTID, MDC.get(ConsumerConstants.Keys.X_ATT_CLIENTID));
        headers.add(ConsumerConstants.Keys.IDP_TRACE_ID, MDC.get(ConsumerConstants.Keys.IDP_TRACE_ID));
        if(MDC.get(ConsumerConstants.Keys.IDPCTX_SESSION_ID) != null) {
            headers.add(ConsumerConstants.Keys.IDPCTX_SESSION_ID, MDC.get(ConsumerConstants.Keys.IDPCTX_SESSION_ID));
        }
        HttpEntity<String> httpEntity = new HttpEntity<>(requestBody, headers);

        logger.info("Calling  API URI: {} with request: {}", resourceUri, requestBody);

        try {
            ResponseEntity<JsonNode> response = restTemplate.exchange(resourceUri, HttpMethod.POST, httpEntity, JsonNode.class);
            logger.info("Response from  API: {}", sanitizeForLog(response.getBody() != null ? response.getBody().toString() : "null"));
            if (!HttpStatus.OK.equals(response.getStatusCode())) {
                logger.error("Received non-OK response from  API. Status: {}, Request GUID: {}, Endpoint: {}",
                        ESAPI.encoder().encodeForHTML(response.getStatusCode().toString()),
                        ESAPI.encoder().encodeForHTML(outgoingRequest.getGuid()),
                        ESAPI.encoder().encodeForHTML(endpoint));
                FailedEventUtil.saveFailedEventResolvingCategory(cosmosFailedEventsWriter, outgoingRequest.getGuid(), JsonService.getJsonFromObject(outgoingRequest), eventName, CErrorDefs.ERR_INVALID_DATA, response.getStatusCode().toString(), endpoint, ConsumerConstants.AccountNotificationConstants.WIRELESS);
            }

        } catch (HttpServerErrorException e) {
            logger.error("Retryable exception while calling IDGraphUserAssociationMs. {} Will be retried for a max attempts of: {}", e, MAX_ATTEMPTS);
            throw e;
        } catch (Exception e) {
            logger.error("Non-retryable exception received in Association API: {}", e);
            handleNonRetryableFailure(e, endpoint, outgoingRequest, CErrorDefs.ERR_INVALID_DATA, eventName);
        }
        return null;
    }

    @Retryable(maxAttempts = MAX_ATTEMPTS, retryFor = {HttpServerErrorException.class})
    public ResponseEntity<JsonNode> sendPostRequest(String endpoint, PlatformHandlerRequest outgoingRequest, String eventName) {
        return sendPostRequest(endpoint, outgoingRequest, eventName, ConsumerConstants.AccountNotificationConstants.WIRELESS);
    }

    @Retryable(maxAttempts = MAX_ATTEMPTS, retryFor = {HttpServerErrorException.class})
    public ResponseEntity<JsonNode> sendPostRequest(String endpoint, PlatformHandlerRequest outgoingRequest, String eventName, String accountType) {
        String resourceUri = userAssoServerUrl + endpoint;

        String requestBody = JsonService.getJsonFromObject(outgoingRequest);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(ConsumerConstants.Keys.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString((userName + ":" + userPassword).getBytes()));
        headers.add(ConsumerConstants.Keys.X_ATT_CLIENTID, MDC.get(ConsumerConstants.Keys.X_ATT_CLIENTID));
        headers.add(ConsumerConstants.Keys.IDP_TRACE_ID, MDC.get(ConsumerConstants.Keys.IDP_TRACE_ID));
        if (MDC.get(ConsumerConstants.Keys.IDPCTX_SESSION_ID) != null) {
            headers.add(ConsumerConstants.Keys.IDPCTX_SESSION_ID, MDC.get(ConsumerConstants.Keys.IDPCTX_SESSION_ID));
        }
        HttpEntity<String> httpEntity = new HttpEntity<>(requestBody, headers);

        logger.info("Calling API URI: {} with request: {}", resourceUri, requestBody);

        try {
            ResponseEntity<JsonNode> response = restTemplate.exchange(resourceUri, HttpMethod.POST, httpEntity, JsonNode.class);
            logger.info("Response from  API: {}", sanitizeForLog(response.getBody() != null ? response.getBody().toString() : "null"));
            if (!HttpStatus.OK.equals(response.getStatusCode())) {
                logger.error("Received non-OK response from  API. Status: {}, Request BAN: {}, Endpoint: {}",
                        ESAPI.encoder().encodeForHTML(response.getStatusCode().toString()),
                        ESAPI.encoder().encodeForHTML(outgoingRequest.getBan()),
                        ESAPI.encoder().encodeForHTML(endpoint));
                FailedEventUtil.saveFailedEventResolvingCategory(cosmosFailedEventsWriter, outgoingRequest.getBan(), JsonService.getJsonFromObject(outgoingRequest), eventName, CErrorDefs.ERR_INVALID_DATA, response.getStatusCode().toString(), endpoint, accountType);
            }
        } catch (HttpServerErrorException e) {
            logger.error("Retryable exception while calling  API. {} Will be retried for a max attempts of: {}", e, MAX_ATTEMPTS);
            throw e;
        } catch (Exception e) {
            logger.error("Non-retryable exception received in  API: {}", e);
            handleNonRetryableFailure(e, endpoint, outgoingRequest, CErrorDefs.ERR_INVALID_DATA, eventName, accountType);
        }
        return null;
    }

    @Recover
    public ResponseEntity<JsonNode> recover(HttpServerErrorException e, String endpoint, UserAssociationChangeRequest outgoingRequest, String eventName) {

        logger.error("HttpServerErrorException while calling RemoveAssociation API, Exhausted retries: {}", e.getMessage());
        handleNonRetryableFailure(e, endpoint, outgoingRequest, CErrorDefs.SYS_ERR, eventName);
        return null;
    }

    @Recover
    public ResponseEntity<JsonNode> recover(HttpServerErrorException e, String endpoint, PlatformHandlerRequest outgoingRequest, String eventName, String accountType) {
        logger.error("HttpServerErrorException while calling PlatformHandler API, Exhausted retries: {}", e.getMessage());
        handleNonRetryableFailure(e, endpoint, outgoingRequest, CErrorDefs.SYS_ERR, eventName, accountType);
        return null;
    }

    @Recover
    public ResponseEntity<JsonNode> recover(HttpServerErrorException e, String endpoint, ProvisionEnablerRequest outgoingRequest, String eventName) {
        logger.error("HttpServerErrorException while calling ProvisionEnabler API, Exhausted retries: {}", e.getMessage());
        handleNonRetryableFailure(e, endpoint, outgoingRequest, CErrorDefs.SYS_ERR, eventName);
        return null;
    }

    private void handleNonRetryableFailure(Exception e, String endpoint, UserAssociationChangeRequest outgoingRequest, String errorCode, String eventName) {
        logger.error("HttpServerErrorException while calling IDGraphUserAssociationMs, Exhausted retries : {}", e.getMessage());

        FailedEventUtil.saveFailedEventResolvingCategory(cosmosFailedEventsWriter, outgoingRequest.getGuid(), JsonService.getJsonFromObject(outgoingRequest), eventName, CErrorDefs.SYS_ERR, e.getMessage(), endpoint, ConsumerConstants.AccountNotificationConstants.WIRELESS);
    }

    private void handleNonRetryableFailure(Exception e, String endpoint, PlatformHandlerRequest outgoingRequest, String errorCode, String eventName, String accountType) {
        logger.error("PlatformHandler API call exhausted retries : {}", e.getMessage());

        FailedEventUtil.saveFailedEventResolvingCategory(cosmosFailedEventsWriter, outgoingRequest.getBan(), JsonService.getJsonFromObject(outgoingRequest), eventName, errorCode, e.getMessage(), endpoint, accountType);
    }

    @Retryable(maxAttempts = MAX_ATTEMPTS, retryFor = {HttpServerErrorException.class})
    public ResponseEntity<JsonNode> sendPostRequest(String endpoint, ProvisionEnablerRequest outgoingRequest, String eventName) {
        String resourceUri = userAssoServerUrl + endpoint;

        String requestBody = JsonService.getJsonFromObject(outgoingRequest);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(ConsumerConstants.Keys.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString((userName + ":" + userPassword).getBytes()));
        headers.add(ConsumerConstants.Keys.X_ATT_CLIENTID, MDC.get(ConsumerConstants.Keys.X_ATT_CLIENTID));
        headers.add(ConsumerConstants.Keys.IDP_TRACE_ID, MDC.get(ConsumerConstants.Keys.IDP_TRACE_ID));
        if (MDC.get(ConsumerConstants.Keys.IDPCTX_SESSION_ID) != null) {
            headers.add(ConsumerConstants.Keys.IDPCTX_SESSION_ID, MDC.get(ConsumerConstants.Keys.IDPCTX_SESSION_ID));
        }
        HttpEntity<String> httpEntity = new HttpEntity<>(requestBody, headers);

        logger.info("Calling ProvisionEnabler API URI: {} with request: {}", resourceUri, requestBody);

        try {
            ResponseEntity<JsonNode> response = restTemplate.exchange(resourceUri, HttpMethod.POST, httpEntity, JsonNode.class);
            logger.info("Response from ProvisionEnabler API: {}", sanitizeForLog(response.getBody() != null ? response.getBody().toString() : "null"));
            if (!HttpStatus.OK.equals(response.getStatusCode())) {
                logger.error("Received non-OK response from ProvisionEnabler API. Status: {}, Request BAN: {}, Endpoint: {}",
                        ESAPI.encoder().encodeForHTML(response.getStatusCode().toString()),
                        ESAPI.encoder().encodeForHTML(outgoingRequest.getBan()),
                        ESAPI.encoder().encodeForHTML(endpoint));
                FailedEventUtil.saveFailedEventResolvingCategory(cosmosFailedEventsWriter, outgoingRequest.getBan(), JsonService.getJsonFromObject(outgoingRequest), eventName, CErrorDefs.ERR_INVALID_DATA, response.getStatusCode().toString(), endpoint, ConsumerConstants.AccountNotificationConstants.WIRELESS);
            }
        } catch (HttpServerErrorException e) {
            logger.error("Retryable exception while calling ProvisionEnabler API. {} Will be retried for a max attempts of: {}", e, MAX_ATTEMPTS);
            throw e;
        } catch (Exception e) {
            logger.error("Non-retryable exception received in ProvisionEnabler API: {}", e);
            handleNonRetryableFailure(e, endpoint, outgoingRequest, CErrorDefs.ERR_INVALID_DATA, eventName);
        }
        return null;
    }

    private void handleNonRetryableFailure(Exception e, String endpoint, ProvisionEnablerRequest outgoingRequest, String errorCode, String eventName) {
        logger.error("ProvisionEnabler API call failed: {}", e.getMessage());

        FailedEventUtil.saveFailedEventResolvingCategory(cosmosFailedEventsWriter, outgoingRequest.getBan(), JsonService.getJsonFromObject(outgoingRequest), eventName, errorCode, e.getMessage(), endpoint, ConsumerConstants.AccountNotificationConstants.WIRELESS);
    }

    private String sanitizeForLog(String input) {
        if (input == null) return null;
        return input.replaceAll("[\\r\\n]", " ");
    }
}