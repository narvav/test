package com.att.idp.idgraphconsumerms.kafka.dmctn.service;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker;
import com.att.idp.idgraphconsumerms.kafka.model.AccountNotificationEvent;
import com.att.idp.idgraphconsumerms.model.PlatformHandlerRequest;
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.att.mpsys.common.utils.CErrorDefs;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class DeletePlatformHandlerNotificationService implements BaseService<AccountNotificationEvent> {

    private static final Logger logger = LoggerFactory.getLogger(DeletePlatformHandlerNotificationService.class);

    @Value("${apiclient.rest.ua.platformhandler.endpoint}")
    private String platformHandlerEndpoint;

    private final CosmosFailedEventsWriter cosmosFailedEventsWriter;
    private final ApiRestClient apiRestClient;

    @org.springframework.beans.factory.annotation.Autowired
    private GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker;

    public DeletePlatformHandlerNotificationService(ApiRestClient apiRestClient, CosmosFailedEventsWriter cosmosFailedEventsWriter) {
        this.apiRestClient = apiRestClient;
        this.cosmosFailedEventsWriter = cosmosFailedEventsWriter;
    }

    @Override
    public void execute(AccountNotificationEvent accountNotificationEvent) {
        String sourceIdentifier = getSourceIdentifier(accountNotificationEvent);
        String eventName = ConsumerConstants.GridGddnNotification.resolveEventName(accountNotificationEvent.getEventName());

        // Circuit breaker: short-circuit to Cosmos if pending failed events exist
        if (gddnFailedEventCircuitBreaker.shouldShortCircuit(sourceIdentifier, eventName)) {
            logger.warn("DeletePlatformHandlerNotificationService: Circuit breaker OPEN for id={}. Saving directly to Cosmos.",
                    ESAPI.encoder().encodeForHTML(sourceIdentifier));
            PlatformHandlerRequest cbRequest = buildOutgoingRequest(accountNotificationEvent);
            FailedEventUtil.saveFailedEventCircuitOpen(
                    cosmosFailedEventsWriter, sourceIdentifier,
                    JsonService.getJsonFromObject(cbRequest), eventName,
                    CErrorDefs.SYS_ERR, "Circuit breaker open \u2014 pending failed events exist",
                    platformHandlerEndpoint, ConsumerConstants.AccountNotificationConstants.WIRELESS);
            return;
        }

        PlatformHandlerRequest outgoingRequest = buildOutgoingRequest(accountNotificationEvent);

        try {
            if (isBlank(accountNotificationEvent.getBillingAccountNumber()) && isBlank(accountNotificationEvent.getPhFan())) {
                logger.error("Missing billingAccountNumber/phFan for PlatformHandler delete event. banPresent={}, phFanPresent={}, traceId={}",
                        !isBlank(accountNotificationEvent.getBillingAccountNumber()),
                        !isBlank(accountNotificationEvent.getPhFan()),
                        ESAPI.encoder().encodeForHTML(accountNotificationEvent.getEventId()));
                FailedEventUtil.saveFailedEventValidationFailed(
                        cosmosFailedEventsWriter,
                        sourceIdentifier,
                        JsonService.getJsonFromObject(accountNotificationEvent),
                        eventName,
                        CErrorDefs.ERR_INVALID_DATA,
                        "billingAccountNumber or phFan is mandatory for PlatformHandler delete event",
                        ConsumerConstants.ErrorDetails.VALIDATION_FAILED,
                        ConsumerConstants.AccountNotificationConstants.WIRELESS
                );
                return;
            }

            apiRestClient.sendPostRequest(platformHandlerEndpoint, outgoingRequest, eventName);
        } catch (Exception e) {
            logger.error("Error processing PlatformHandler delete for identifier: {}", ESAPI.encoder().encodeForHTML(sourceIdentifier), e);
            FailedEventUtil.saveFailedEventResolvingCategory(
                    cosmosFailedEventsWriter,
                    sourceIdentifier,
                    JsonService.getJsonFromObject(outgoingRequest),
                    eventName,
                    CErrorDefs.SYS_ERR,
                    e.getMessage(),
                    platformHandlerEndpoint,
                    ConsumerConstants.AccountNotificationConstants.WIRELESS
            );
        }
    }

    private static PlatformHandlerRequest buildOutgoingRequest(AccountNotificationEvent accountNotificationEvent) {
        PlatformHandlerRequest outgoingRequest = new PlatformHandlerRequest();
        outgoingRequest.setBan(hasText(accountNotificationEvent.getBillingAccountNumber()) ? accountNotificationEvent.getBillingAccountNumber() : null);
        outgoingRequest.setPhFan(hasText(accountNotificationEvent.getPhFan()) ? accountNotificationEvent.getPhFan() : null);
        outgoingRequest.setTransactionType(ConsumerConstants.ProductNotificationConstants.DELETE_PH_ACCOUNT);
        outgoingRequest.setCallingSystemId(ConsumerConstants.DmctnSubscriberChangeEvent.CLIENT_ATLASBUS);
        outgoingRequest.setIdpTraceId(accountNotificationEvent.getEventId());
        return outgoingRequest;
    }

    private static String getSourceIdentifier(AccountNotificationEvent accountNotificationEvent) {
        if (hasText(accountNotificationEvent.getBillingAccountNumber())) {
            return accountNotificationEvent.getBillingAccountNumber();
        }
        return accountNotificationEvent.getPhFan();
    }

    private static boolean hasText(String value) {
        return value != null && !value.trim().isEmpty();
    }

    private static boolean isBlank(String value) {
        return !hasText(value);
    }
}
