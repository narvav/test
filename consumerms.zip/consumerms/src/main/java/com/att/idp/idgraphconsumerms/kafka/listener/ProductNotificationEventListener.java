package com.att.idp.idgraphconsumerms.kafka.listener;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.kafka.dmctn.service.BaseService;
import com.att.idp.idgraphconsumerms.kafka.dmctn.service.RGPHOServiceFactory;
import com.att.idp.idgraphconsumerms.kafka.model.AccountNotificationEvent;
import com.att.idp.idgraphconsumerms.request.validator.RequestValidator;
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import com.att.idp.idgraph.events.model.ConsumerAction;
import com.att.idp.idgraph.events.service.ResilientEventConsumer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;
import java.util.Optional;
import java.util.Random;

/**
 * Listener for Product  Notification events from Azure Event Hubs (Kafka interface).
 * Added without modifying existing listeners; follows existing pattern and manual ack.
 */
@Service
public class ProductNotificationEventListener {

    private static final Logger logger = LoggerFactory.getLogger(ProductNotificationEventListener.class);
    private ObjectMapper objectMapper;

    @Autowired
    private RequestValidator requestValidator;

    @Autowired
    RGPHOServiceFactory rgphoServiceFactory;

    public ProductNotificationEventListener() {
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
        objectMapper.enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
    }


    /**
     * R5 / Phase B: dedup + sequence gate.
     * Conditional bean — absent when kafka.resiliency.use-unified-entity=false.
     */
    private ResilientEventConsumer resilientEventConsumer;

    /**
     * Setter injection for ResilientEventConsumer.
     * Called by Spring when kafka.resiliency.use-unified-entity=true.
     */
    @Autowired(required = false)
    public void setResilientEventConsumer(ResilientEventConsumer resilientEventConsumer) {
        this.resilientEventConsumer = resilientEventConsumer;
    }

    @KafkaListener(id = "productNotificationEventListener",
            topics = "${idgraph.consumer.productnotificationconsumer.topic}",
            containerFactory = "productNotificationConsumerContainerFactory",
            groupId = "${idgraph.consumer.productnotificationconsumer.group-id}",
            concurrency = "${idgraph.consumer.productnotificationconsumer.concurrency:1}",
            autoStartup = "${idgraph.consumer.productnotificationconsumer.autoStartup:false}")
    public void productNotificationEventListener(@Payload String message,
                                            @Headers MessageHeaders headers,
                                            Acknowledgment acknowledgment) throws Exception {
        // R5: skip duplicate / stale retried messages without processing.
        // Use Kafka message key (BAN/accountNumber) as entityKey fallback for dedup tracking.
        if (resilientEventConsumer != null) {
            String entityKey = headers.get("kafka_receivedMessageKey") != null
                    ? headers.get("kafka_receivedMessageKey").toString() : "";
            ConsumerAction action = resilientEventConsumer.evaluate(headers, entityKey);
            if (action != ConsumerAction.PROCESS) {
                logger.info("REC_GATE: Skipping product notification — action={}", action);
                acknowledgment.acknowledge();
                return;
            }
        }
        try {
            logger.info("productNotificationEvent received. headers={}, payload={}", headers, message);
            long startTm = System.currentTimeMillis();
            logger.info("WEB000 : ProductNotificationEvent consumer initiation: {}", message);
            MDC.put(ConsumerConstants.Keys.X_ATT_CLIENTID, ConsumerConstants.DmctnSubscriberChangeEvent.CLIENT_ATLASBUS);
            AccountNotificationEvent productNotificationEvent = safeConvertToObject(message, AccountNotificationEvent.class)
                    .orElseThrow(() -> new JsonProcessingException("Failed to deserialize message to ProductNotificationEvent") {
                    });

            if (productNotificationEvent!=null) {
                MDC.put(ConsumerConstants.Keys.IDP_TRACE_ID, productNotificationEvent.getEventId());
                MDC.put(ConsumerConstants.Keys.IDPCTX_SESSION_ID, productNotificationEvent.getTlgMessageId());
                logger.info("idp-trace-id: {}", productNotificationEvent.getEventId());
            String eventType = productNotificationEvent.getEventName();

                BaseService<AccountNotificationEvent> service = rgphoServiceFactory.getService(eventType);
                if (service != null) {
                    logger.info("Processing ProductNotificationEvent for eventType: {}, subscriber id: {}", eventType, productNotificationEvent.getSubscriberNumber());
                    service.execute(productNotificationEvent);
                }
                else {
                    logger.error("Received message with unsupported eventId: {}. Acknowledging the message", eventType);
                }

            } else {
                logger.error("ProductNotificationEvent is null. Acknowledging the message");
            }


            String sTimeTaken = ConsumerUtil.getElapsedTimeInSecs(startTm) + " seconds";
            logger.info("WEB999 : Total time taken : {} ProductNotificationEvent consumer Response : {}", sTimeTaken, message);
            logger.info("CONSUMER_EVENT_SUCCESS: listenerId=productNotificationEventListener");
            logger.info("Committing the offset for the message");
            acknowledgment.acknowledge();
        } catch (Exception e) {
            logger.error("CONSUMER_EVENT_FAILED: listenerId=productNotificationEventListener, error={}", e.getMessage());
            throw e;
        } finally {
            MDC.clear();
        }
    }

    public static <T> Optional<T> safeConvertToObject(String inputJson, Class<T> theClass) {
        String actualJson = inputJson;
        // Detect and unwrap double-encoded JSON
        if (actualJson != null && actualJson.startsWith("\"") && actualJson.endsWith("\"")) {
            actualJson = actualJson.substring(1, actualJson.length() - 1)
                    .replace("\\\"", "\"");
        }
        T result = JsonService.convertToObject(actualJson, theClass);
        return Optional.ofNullable(result);
    }


}

