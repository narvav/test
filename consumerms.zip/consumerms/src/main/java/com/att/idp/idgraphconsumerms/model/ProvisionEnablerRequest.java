package com.att.idp.idgraphconsumerms.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProvisionEnablerRequest {
    private String ban;
    private List<ProvisionServiceEntry> services;
}
