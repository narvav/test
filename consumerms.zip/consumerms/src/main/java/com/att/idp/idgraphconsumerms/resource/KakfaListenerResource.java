package com.att.idp.idgraphconsumerms.resource;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

/**
 * This interface, KakfaListenerResource, defines the contract for a RESTful resource in the system.
 *
 * It is annotated with several JAX-RS and Swagger annotations to define its behavior:
 * - @Api("kafka") indicates that this resource is part of the "kafka" API in the Swagger documentation.
 * - @Path("/kafka") sets the base path for all endpoints defined in this resource.
 *
 * The interface contains two methods:
 * - start is a GET endpoint that takes a listenerId as a path parameter and starts the corresponding Kafka listener. It returns a Response object.
 * - stop is a GET endpoint that takes a listenerId as a path parameter and stops the corresponding Kafka listener. It returns a Response object.
 */
@Tag(name = "kafka")
@Path("/kafka")
public interface KakfaListenerResource {

	/**
	 * This method, start, is a GET endpoint that starts a Kafka listener.
	 *
	 * It is annotated with several JAX-RS and Swagger annotations to define its behavior:
	 * - @GET indicates that this method handles HTTP GET requests.
	 * - @Path("/start/{listenerId}") sets the path for this endpoint and includes a path parameter, listenerId.
	 * - @ApiOperation provides additional information about this endpoint in the Swagger documentation.
	 *
	 * The method takes a listenerId as input, which is the ID of the Kafka listener to be started.
	 *
	 * @param listenerId the ID of the Kafka listener to be started
	 * @return a Response object representing the HTTP response to be sent by the endpoint
	 */
	@GET
	@Path("/start/{listenerId}")
	@Operation(summary = "Start Kafka Listener", description = "Start Kafka Listener")
	public Response start(@PathParam("listenerId") String listenerId);

	
	/**
	 * This method, stop, is a GET endpoint that stops a Kafka listener.
	 *
	 * It is annotated with several JAX-RS and Swagger annotations to define its behavior:
	 * - @GET indicates that this method handles HTTP GET requests.
	 * - @Path("/stop/{listenerId}") sets the path for this endpoint and includes a path parameter, listenerId.
	 * - @ApiOperation provides additional information about this endpoint in the Swagger documentation.
	 *
	 * The method takes a listenerId as input, which is the ID of the Kafka listener to be stopped.
	 *
	 * @param listenerId the ID of the Kafka listener to be stopped
	 * @return a Response object representing the HTTP response to be sent by the endpoint
	 */
	@GET
	@Path("/stop/{listenerId}")
	@Operation(summary = "Stop Kafka listener", description = "Stop Kafka listener")
	public Response stop(@PathParam("listenerId") String listenerId);

	/**
	 * Lists all Kafka listener IDs and their running status on this pod.
	 *
	 * @return a Response object containing a list of listener IDs and their status
	 */
	@GET
	@Path("/listeners")
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "List Kafka listeners", description = "List all Kafka listener IDs and their running status on this pod.")
	public Response listListeners();
}
