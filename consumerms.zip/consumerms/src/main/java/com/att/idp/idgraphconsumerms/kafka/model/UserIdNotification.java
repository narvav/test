package com.att.idp.idgraphconsumerms.kafka.model;

import com.att.idp.idgraph.events.model.JsonSealizable;
import com.att.idp.idgraphconsumerms.kafka.model.UserIdNotificationEventDetails;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.time.Instant;

@Data
@Builder
@AllArgsConstructor
public class UserIdNotification implements JsonSealizable {
    private String eventId;
    private String eventType;
    private String category;
    private String subCategory;
    private String eventName;
    private String customerNotification;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", shape = JsonFormat.Shape.STRING, timezone = "UTC")
    private Instant eventTime;
    private UserIdNotificationEventDetails eventDetails;
}