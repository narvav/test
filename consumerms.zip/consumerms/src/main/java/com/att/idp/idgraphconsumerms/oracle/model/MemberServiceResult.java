package com.att.idp.idgraphconsumerms.oracle.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MemberServiceResult {
    private String memberNum;
    private String memberName;
    private String sorInvariantId;
    private String instanceId;
  
}