package com.att.idp.idgraphconsumerms.cosmos.nosql.helpers;

import com.att.idp.idgraph.db.cosmos.entity.BSSEMigrationStatus;
import com.att.idp.idgraph.db.cosmos.helper.BSSEMigrationStatusDBHelper;
import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.kafka.KafkaListenerAutomation;
import com.att.idp.idgraphconsumerms.kafka.errorhandler.InvalidInputDataException;
import com.att.idp.idgraphconsumerms.kafka.model.MigrationBANNotification;
import com.att.idp.idgraphconsumerms.kafka.model.MigrationEvent;
import com.att.idp.idgraphconsumerms.kafka.model.ReverseMigratedInboundDataEvent;
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import com.att.idp.logging.marker.SpiMarker;
import com.azure.cosmos.implementation.ServiceUnavailableException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;


@Service
public class CosmosMigrationStatusDBHelper {

    public static final Logger logger = LoggerFactory.getLogger(CosmosMigrationStatusDBHelper.class);
    private static String sClassName = "CosmosMigrationStatusDBHelper";

    @Value("${idg.processed-env-prefix}")
    private String processedEnvPrefix;

    @Autowired
    private  BSSEMigrationStatusDBHelper bsseMigrationStatusDBHelper;

    @Autowired
    KafkaListenerAutomation kafkaListenerAutomation;

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    /**
     * Stores the BSSE Migration Status in Cosmos DB.
     * Accepts any MigrationEvent implementation (MigrationBANNotification or ReverseMigratedInboundDataEvent).
     *
     * @param migrationEvent the migration event payload
     * @param originalRequest the original raw request string
     */
    @Retryable(maxAttempts = 3, include = {ServiceUnavailableException.class}, backoff = @Backoff(delay = 2000))
    public void storeBSSEMigrationStatus(MigrationEvent migrationEvent, String originalRequest) {
        BSSEMigrationStatus bsseMigrationStatus = populateCosmosRecord(migrationEvent, originalRequest);
        String sMethodName = ".storeBSSEMigrationStatus.";
        logger.info(SpiMarker.getInstance(), "{}{}BM_01 : Storing BSSE Migration Status in Cosmos DB, payload: {}", sClassName, sMethodName, ConsumerUtil.encode(originalRequest));
        if(bsseMigrationStatusDBHelper == null) {
            logger.error(SpiMarker.getInstance(), "{}{}BM_02 : BSSE Migration Status DBHelper  is null", sClassName, sMethodName);
            throw new InvalidInputDataException("BSSE Migration Status DBHelper  is null");
        }
        try{
            bsseMigrationStatusDBHelper.storeBSSEMigrationStatus(bsseMigrationStatus);
        } catch (Exception e) {
            if(e instanceof ServiceUnavailableException) {
                logger.error(SpiMarker.getInstance(), "{}{}BM_02 : ServiceUnavailableException while storing BSSE Migration Status in Cosmos DB: {}", sClassName, sMethodName, ConsumerUtil.encode(e.getMessage()));
                throw e;
            }
            logger.error(SpiMarker.getInstance(), "{}{}BM_02 : Error storing BSSE Migration Status in Cosmos DB: {}", sClassName, sMethodName, ConsumerUtil.encode(e.getMessage()));
            kafkaListenerAutomation.stopListener("idpMigrationNotificationListener");
        }
        logger.info(SpiMarker.getInstance(), "{}{}BM_02 : BSSE Migration Status stored in Cosmos DB", sClassName, sMethodName);
    }


    private BSSEMigrationStatus populateCosmosRecord(MigrationEvent migrationEvent, String originalRequest) {
        String now = ZonedDateTime.now(ZoneOffset.UTC).format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
        BSSEMigrationStatus bsseMigrationStatus = new BSSEMigrationStatus();

        bsseMigrationStatus.setBan(migrationEvent.getSourceBan());
        bsseMigrationStatus.setMigrationId(migrationEvent.getMigrationId());
        bsseMigrationStatus.setCreatedDate(now);
        bsseMigrationStatus.setTargetBan(migrationEvent.getTargetBan());
        bsseMigrationStatus.setMigStatusReason("Status:"+migrationEvent.getStatus()+" SubStatus:"+migrationEvent.getSubStatus());

        bsseMigrationStatus.setTraceId(MDC.get(ConsumerConstants.Keys.IDP_TRACE_ID));
        bsseMigrationStatus.setEventId(migrationEvent.getEventId());
        bsseMigrationStatus.setUpdatedDate(now);
        bsseMigrationStatus.setUpdatedBy(MDC.get(ConsumerConstants.Keys.X_ATT_CLIENTID));
        try {
            JsonNode parsedRequest = OBJECT_MAPPER.readTree(originalRequest);
            bsseMigrationStatus.setOriginalRequest(parsedRequest);
        } catch (Exception e) {
            bsseMigrationStatus.setOriginalRequest(originalRequest);
        }
        bsseMigrationStatus.setProcessedEnvPrefix(processedEnvPrefix);

        // Set guid and individualId from common interface
        bsseMigrationStatus.setGuid(migrationEvent.getGuid());
        bsseMigrationStatus.setIndividualId(migrationEvent.getIndividualId());

        // Set additional fields if MigrationBANNotification
        if (migrationEvent instanceof MigrationBANNotification) {
            MigrationBANNotification notification = (MigrationBANNotification) migrationEvent;
            bsseMigrationStatus.setMigStatus(ConsumerConstants.BsseMigration.MIGRATION_STATUS_STARTED);
            bsseMigrationStatus.setIsMigrated("NA");
            bsseMigrationStatus.setSourceMarketCode(notification.getSourceMarketCode());
            bsseMigrationStatus.setPasscodeVenc(notification.getPasscodeVenc());
        }

        // Set additional fields if ReverseMigratedInboundDataEvent
        if (migrationEvent instanceof ReverseMigratedInboundDataEvent) {
            ReverseMigratedInboundDataEvent reverseEvent = (ReverseMigratedInboundDataEvent) migrationEvent;
            bsseMigrationStatus.setIsMigrated("NA");
            bsseMigrationStatus.setMigStatus(ConsumerConstants.BsseMigration.REVERSE_MIGRATION_STATUS_STARTED);
            bsseMigrationStatus.setIterationId(reverseEvent.getIterationId());
            bsseMigrationStatus.setServiceType(reverseEvent.getServiceType());
            bsseMigrationStatus.setEventTime(reverseEvent.getEventTime());
        }

        return bsseMigrationStatus;
    }

    @Recover
    public void recover(ServiceUnavailableException e, MigrationEvent migrationEvent, String originalRequest) {
        String sMethodName = ".recover.";
        logger.error(SpiMarker.getInstance(), "{}{}BM_03 : Exhausted from ServiceUnavailableException retry, stopping the consumer: {}", sClassName, sMethodName, ConsumerUtil.encode(e.getMessage()));
        kafkaListenerAutomation.stopListener("idpMigrationNotificationListener");
    }
}
