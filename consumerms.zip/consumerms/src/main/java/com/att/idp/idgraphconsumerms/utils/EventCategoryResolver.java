package com.att.idp.idgraphconsumerms.utils;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Resolves GDDN event names to their event categories for sequencing and circuit-breaker decisions.
 * <p>
 * Mirror of batchms EventCategoryRegistry — kept in consumerms to avoid a cross-service dependency.
 * If an event name has a category, it participates in sequenced failed-event processing;
 * otherwise it follows the existing parallel replay path.
 * </p>
 */
public final class EventCategoryResolver {

    private static final Map<String, String> EVENT_TO_CATEGORY;

    static {
        Map<String, String> map = new HashMap<>();
        // GDDNAccount category — account lifecycle events processed in order
        map.put(ConsumerConstants.GridGddnNotification.EVENT_GDDN_ACTIVATE_ACCOUNT,
                ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT);
        map.put(ConsumerConstants.GridGddnNotification.EVENT_GDDN_CHANGE_PRODUCT,
                ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT);
        map.put(ConsumerConstants.GridGddnNotification.EVENT_GDDN_CLOSE_ACCOUNT,
                ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT);
        map.put(ConsumerConstants.GridGddnNotification.EVENT_GDDN_PLATFORM_HANDLER,
                ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT);

        // GDDNFanUpdate category — FAN update events
        map.put(ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT,
                ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_FAN_UPDATE);

        // GDDNRGActivation category — RG activation events
        map.put(ConsumerConstants.GridGddnNotification.EVENT_GDDN_RG_ACTIVATION,
                ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_RG_ACTIVATION);

        // GDDNSubscriber category — granular subscriber events (accountNumber = phoneNumber/CTN)
        // GDDN-prefixed events (originating from GDDN)
        map.put(ConsumerConstants.GridGddnNotification.EVENT_GDDN_RESTORE_SUBSCRIBER,
                ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_SUBSCRIBER);
        map.put(ConsumerConstants.GridGddnNotification.EVENT_GDDN_SUSPEND_SUBSCRIBER,
                ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_SUBSCRIBER);
        map.put(ConsumerConstants.GridGddnNotification.EVENT_GDDN_CANCEL_SUBSCRIBER,
                ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_SUBSCRIBER);
        map.put(ConsumerConstants.GridGddnNotification.EVENT_GDDN_CHANGE_DATA,
                ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_SUBSCRIBER);
        // CG-prefixed events (originating from CustomerGraph) — independent CGSubscriber category
        map.put(ConsumerConstants.GridGddnNotification.EVENT_CG_RESTORE_SUBSCRIBER,
                ConsumerConstants.GridGddnNotification.CATEGORY_CG_SUBSCRIBER);
        map.put(ConsumerConstants.GridGddnNotification.EVENT_CG_SUSPEND_SUBSCRIBER,
                ConsumerConstants.GridGddnNotification.CATEGORY_CG_SUBSCRIBER);
        map.put(ConsumerConstants.GridGddnNotification.EVENT_CG_CANCEL_SUBSCRIBER,
                ConsumerConstants.GridGddnNotification.CATEGORY_CG_SUBSCRIBER);
        map.put(ConsumerConstants.GridGddnNotification.EVENT_CG_CHANGE_DATA,
                ConsumerConstants.GridGddnNotification.CATEGORY_CG_SUBSCRIBER);

        // CG Close events — individual and account-level close events
        map.put(ConsumerConstants.BsseMigration.EVENT_CG_INDIVIDUAL_CLOSE,
                ConsumerConstants.GridGddnNotification.CATEGORY_CG_INDIVIDUAL);
        map.put(ConsumerConstants.BsseMigration.EVENT_CG_INDI_ACCT_CLOSE,
                ConsumerConstants.GridGddnNotification.CATEGORY_CG_ACCOUNT);

        EVENT_TO_CATEGORY = Collections.unmodifiableMap(map);
    }

    private EventCategoryResolver() {
        // Utility class
    }

    /**
     * Returns the event category for the given event name, or empty if not a GDDN sequenced event.
     */
    public static Optional<String> resolve(String eventName) {
        if (eventName == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(EVENT_TO_CATEGORY.get(eventName));
    }

    /**
     * Returns the event category for the given event name and transaction type.
     * For UpdateAccount events, this resolves to GDDNFanUpdate or GDDNWlsUnification
     * based on the transaction type (UpdateFan vs UpdateWlsUnification).
     *
     * @param eventName the event name
     * @param transactionType the transaction type from the payload (nullable)
     * @return the event category, or empty if not a GDDN sequenced event
     */
    public static Optional<String> resolve(String eventName, String transactionType) {
        if (eventName == null) {
            return Optional.empty();
        }
        // UpdateAccount conditional mapping based on transaction type
        if (ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT.equals(eventName)) {
            if (ConsumerConstants.AccountNotificationConstants.UPDATE_WLS_UNIFICATION.equals(transactionType)) {
                return Optional.of(ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_WLS_UNIFICATION);
            }
            // Default to GDDNFanUpdate for UpdateFan or null/unknown transaction type
            return Optional.of(ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_FAN_UPDATE);
        }
        // For all other events, use the standard mapping
        return Optional.ofNullable(EVENT_TO_CATEGORY.get(eventName));
    }

    /**
     * Returns true if the event name requires sequenced processing (has a mapped category).
     */
    public static boolean requiresSequencing(String eventName) {
        return resolve(eventName).isPresent();
    }
}
