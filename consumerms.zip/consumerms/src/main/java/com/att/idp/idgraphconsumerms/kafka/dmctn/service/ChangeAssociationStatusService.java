package com.att.idp.idgraphconsumerms.kafka.dmctn.service;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker;
import com.att.idp.idgraphconsumerms.kafka.model.Association;
import com.att.idp.idgraphconsumerms.kafka.model.Subscriber;
import com.att.idp.idgraphconsumerms.model.UserAssociationChangeRequest;
import com.att.idp.idgraphconsumerms.oracle.helpers.MemberServiceDBHelper;
import com.att.idp.idgraphconsumerms.request.validator.RequestValidator;
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service("status")
public class ChangeAssociationStatusService implements BackendService {

    private static final Logger logger = LoggerFactory.getLogger(ChangeAssociationStatusService.class);

    @Value("${apiclient.rest.ua.changestatus.endpoint}")
    private String changeStatusEndpoint;

    private final CosmosFailedEventsWriter cosmosFailedEventsWriter;
    private final GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker;
    private final ApiRestClient apiRestClient;
    private final MemberServiceDBHelper memberServiceDBHelper;

    @Autowired
    public ChangeAssociationStatusService(ApiRestClient apiRestClient, MemberServiceDBHelper memberServiceDBHelper,
                                          CosmosFailedEventsWriter cosmosFailedEventsWriter,
                                          GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker) {
        this.apiRestClient = apiRestClient;
        this.memberServiceDBHelper = memberServiceDBHelper;
        this.cosmosFailedEventsWriter = cosmosFailedEventsWriter;
        this.gddnFailedEventCircuitBreaker = gddnFailedEventCircuitBreaker;
    }

    @Override
    public void execute(Subscriber subscriber, EventSource eventSource) {

        String phoneNumber = subscriber.getPhoneNumber();
        String eventName = resolveEventName(subscriber, eventSource);

        // Circuit breaker: if pending failed events exist for this phone/category,
        // short-circuit directly to Cosmos to preserve sequenced processing order
        if (gddnFailedEventCircuitBreaker.shouldShortCircuit(phoneNumber, eventName)) {
            logger.warn("ChangeAssociationStatusService: Circuit breaker OPEN for CTN={}. "
                            + "Saving directly to Cosmos without calling downstream API.",
                    ESAPI.encoder().encodeForHTML(phoneNumber));
            UserAssociationChangeRequest cbRequest = buildOutgoingRequest(subscriber, null);
            FailedEventUtil.saveFailedEventCircuitOpen(
                    cosmosFailedEventsWriter,
                    phoneNumber,
                    JsonService.getJsonFromObject(cbRequest),
                    eventName,
                    CErrorDefs.SYS_ERR,
                    ConsumerConstants.GridGddnNotification.ERROR_CIRCUIT_BREAKER_OPEN,
                    this.changeStatusEndpoint,
                    ConsumerConstants.DmctnSubscriberChangeEvent.TRAN_TYPE_CHANGE_STATUS
            );
            return;
        }

        //We expect that the phone number is always present in the subscriber for this service
        Map<String, Object> validationResult = RequestValidator.validate(phoneNumber, ConsumerConstants.DmctnSubscriberChangeEvent.HEADER_CHANGETYPE_VALUE_PHONENUMBER);

        String statusCode = (String) validationResult.get(MPSDefs.APP_STATUS_CODE);
        if (!CommonDefs.COMMON_SUCCESS.equals(statusCode)) {
            FailedEventUtil.saveFailedEventValidationFailed(
                    cosmosFailedEventsWriter,
                    phoneNumber,
                    JsonService.getJsonFromObject(subscriber),
                    eventName,
                    statusCode,
                    (String) validationResult.get(MPSDefs.APP_STATUS_MSG),
                    ConsumerConstants.ErrorDetails.VALIDATION_FAILED,
                    ConsumerConstants.DmctnSubscriberChangeEvent.TRAN_TYPE_CHANGE_STATUS
            );
            return;
        }

        logger.info("ChangeAssociationStatusService execute method called for subscriber: {}", subscriber.getPhoneNumber());
        String guid = null;
        Optional<String> guidOptional;
        UserAssociationChangeRequest outgoingRequest = null;

        try {

            guidOptional = memberServiceDBHelper.getGuidForGivenCTN(subscriber.getPhoneNumber());


            if (guidOptional.isEmpty() || guidOptional.get() == null || guidOptional.get().isEmpty()) {
                logger.error("No GUID found for CTN: {}", subscriber.getPhoneNumber());
                return;
            }

            guid = guidOptional.get();
            logger.info("Retrieved GUID: {} for CTN: {}", ESAPI.encoder().encodeForHTML(guid), ESAPI.encoder().encodeForHTML(subscriber.getPhoneNumber()));


            outgoingRequest = buildOutgoingRequest(subscriber, guid);
            apiRestClient.sendPostRequest(this.changeStatusEndpoint, outgoingRequest, eventName);

        } catch (IllegalArgumentException e) {
            logger.error("Unsupported status for CTN: {}: {}",
                    ESAPI.encoder().encodeForHTML(subscriber.getPhoneNumber()),
                    ESAPI.encoder().encodeForHTML(e.getMessage()));
        } catch (Exception e) {
            logger.error("Error retrieving GUID for CTN: {}: {}", subscriber.getPhoneNumber(), e.getMessage());
            outgoingRequest = buildOutgoingRequest(subscriber, guid);

                FailedEventUtil.saveFailedEventResolvingCategory(
                        cosmosFailedEventsWriter,
                        phoneNumber,
                        JsonService.getJsonFromObject(outgoingRequest),
                        eventName,
                        CErrorDefs.SYS_ERR,
                        e.getMessage(),
                        this.changeStatusEndpoint,
                        ConsumerConstants.DmctnSubscriberChangeEvent.TRAN_TYPE_CHANGE_STATUS
                );
        }
    }

    /**
     * Resolve the event name based on subscriber status and event source.
     * - GDDN source → use GDDN-prefixed event names
     * - CG source → use CG-prefixed event names
     */
    private String resolveEventName(Subscriber subscriber, EventSource eventSource) {
        String status = subscriber.getStatus();
        boolean isSuspended = ConsumerConstants.DmctnSubscriberChangeEvent.SERVICE_STAUS_SUSPENDED.equalsIgnoreCase(status);
        
        if (eventSource == EventSource.GDDN) {
            return isSuspended 
                ? ConsumerConstants.GridGddnNotification.EVENT_GDDN_SUSPEND_SUBSCRIBER
                : ConsumerConstants.GridGddnNotification.EVENT_GDDN_RESTORE_SUBSCRIBER;
        } else {
            return isSuspended 
                ? ConsumerConstants.GridGddnNotification.EVENT_CG_SUSPEND_SUBSCRIBER
                : ConsumerConstants.GridGddnNotification.EVENT_CG_RESTORE_SUBSCRIBER;
        }
    }

    private UserAssociationChangeRequest buildOutgoingRequest(Subscriber subscriber, String guid) {

        String idgraphStatus = subscriber.getIdgraphStatus();
        if (idgraphStatus == null) {
            throw new IllegalArgumentException("Unsupported subscriber status: " + subscriber.getStatus());
        }

        UserAssociationChangeRequest outgoingRequest = new UserAssociationChangeRequest();
        outgoingRequest.setGuid(guid);
        outgoingRequest.setSuppressNotification("N");

        Association association = new Association();
        association.setServiceName(ConsumerConstants.DmctnSubscriberChangeEvent.MOSUB);
        association.setServiceStatus(idgraphStatus);
        association.setInstanceId(subscriber.getPhoneNumber());

        outgoingRequest.setAssociationList(List.of(association));
        return outgoingRequest;
    }
}
