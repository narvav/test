package com.att.idp.idgraphconsumerms.kafka.dmctn.service;


public interface BaseService<T> {
    void execute(T request);
}