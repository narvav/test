package com.att.idp.idgraphconsumerms.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SorOrchestrationRequest {
    private String sorInvariantId;   // Immutable SOR identifier
    private String contactEmail;     // Contact email address
    private String sorId;            // SOR identifier
    private String serviceName;      // Service name (e.g., MOBILITY)
    private String firstName;        // First name
    private String lastName;         // Last name
    private String eventName;      // event name
    private String isConnectedCar; // isConnectedCar
    private String idpTraceId;
}

