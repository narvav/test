package com.att.idp.idgraphconsumerms.helpers;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Helper service for generating cType values based on event rules.
 */
@Slf4j
@Service
public class CTypeHelper {

    private static final String sClassName = "CTypeHelper";
    public static final Logger logger = LoggerFactory.getLogger(CTypeHelper.class);
    private static final String DEFAULT_CTYPE = "UNKNOWN";
    public static final String C_TYPE = "cType";

    /**
     * Generates cType by evaluating event rules.
     * @param event the event data as a map
     * @return the generated cType list
     */
    public static List<Map<String, Object>> generateCtype(Map<String, Object> event) {
        String sMethodName = ".generateCtype.";
        String serviceType = null;
        String accountType = null;
        Object servicesObj= null;
        if (event == null) {
            return List.of(Map.of(C_TYPE, DEFAULT_CTYPE));
        }
        Object notificationDataObj = event.get("notificationData");
        Map<String, Object> notificationData = null;
        if (notificationDataObj instanceof Map) {
            notificationData = (Map<String, Object>) notificationDataObj;
        } else if (notificationDataObj instanceof List && !((List<?>) notificationDataObj).isEmpty() && ((List<?>) notificationDataObj).get(0) instanceof Map) {
            notificationData = (Map<String, Object>) ((List<?>) notificationDataObj).get(0);
        }

        /* serviceName  */
        if (event.get("serviceType") != null) {
            serviceType = String.valueOf(event.get("serviceType"));
        } else {
            servicesObj = event.get("services");
            if (servicesObj instanceof List) {
                List<Map<String, Object>> servicesList = (List<Map<String, Object>>) servicesObj;
                for (Map<String, Object> serviceMap : servicesList) {
                    serviceType = Optional.ofNullable(serviceMap.get("serviceType")).map(Object::toString).orElse("");
                }
            }
        }

        /* AccountType  */
        if (event.get("AccountType") != null) {
            accountType = String.valueOf(event.get("AccountType"));
        }

        String transactionName = event.get("transactionName") instanceof String ? (String) event.get("transactionName") : null;
        String subEvent = event.get("subEvent") instanceof String ? (String) event.get("subEvent") : null;
        String identificationType = event.get("identificationType") instanceof String ? (String) event.get("identificationType") : null;
        String callingSystemId = event.get("callingSystemId") instanceof String ? (String) event.get("callingSystemId") : null;
        String titanInd = event.get("titanInd") instanceof String ? (String) event.get("titanInd") : null;
        String slid = event.get("slid") instanceof String ? (String) event.get("slid") : null;

        String addCTN = notificationData != null && notificationData.get("addCTN") instanceof String ? (String) notificationData.get("addCTN") : null;
        String changeMainCTN = notificationData != null && notificationData.get("changeMainCTN") instanceof String ? (String) notificationData.get("changeMainCTN") : null;
        String oldMainCTN = notificationData != null && notificationData.get("oldMainCTN") instanceof String ? (String) notificationData.get("oldMainCTN") : null;
        String deleteMainCTN = notificationData != null && notificationData.get("deleteMainCTN") instanceof String ? (String) notificationData.get("deleteMainCTN") : null;

        String secondaryAccessGranted = notificationData != null && notificationData.get("secondaryAccessGranted") instanceof String ? (String) notificationData.get("secondaryAccessGranted") : null;
        String secondaryAccountRoleEnabled = notificationData != null && notificationData.get("secondaryAccountRoleEnabled") instanceof String ? (String) notificationData.get("secondaryAccountRoleEnabled") : null;
        String primaryAddAccount = notificationData != null && notificationData.get("primaryAddAccount") instanceof String ? (String) notificationData.get("primaryAddAccount") : null;

        String defaultAccountChanged = notificationData != null && notificationData.get("defaultAccountChanged") instanceof String ? (String) notificationData.get("defaultAccountChanged") : null;
        String primaryEmailChanged = notificationData != null && notificationData.get("primaryEmailChanged") instanceof String ? (String) notificationData.get("primaryEmailChanged") : null;
        String serviceNotificationType = notificationData != null && notificationData.get("serviceNotificationType") instanceof String ? (String) notificationData.get("serviceNotificationType") : null;
        String serviceNotificationListChanged = notificationData != null && notificationData.get("serviceNotificationListChanged") instanceof String ? (String) notificationData.get("serviceNotificationListChanged") : null;


        String deleteAccount = notificationData != null && notificationData.get("deleteAccount") instanceof String ? (String) notificationData.get("deleteAccount") : null;
        String isCPNINotificationLinkedToSLID = notificationData != null && notificationData.get("isCPNINotificationLinkedToSLID") instanceof String ? (String) notificationData.get("isCPNINotificationLinkedToSLID") : null;
        String qarKey = notificationData != null && notificationData.get("qarKey") instanceof String ? (String) notificationData.get("qarKey") : null;


        String serviceNotification = notificationData != null && notificationData.get("serviceNotification") instanceof String ? (String) notificationData.get("serviceNotification") : null;
        String encryptedKey = notificationData != null && notificationData.get("EncryptedKey") instanceof String ? (String) notificationData.get("EncryptedKey") : null;
        String cPNIEligibleMobileNumber = notificationData != null && notificationData.get("CPNIEligibleMobileNumber") instanceof String ? (String) notificationData.get("CPNIEligibleMobileNumber") : null;
        String memberContactEmail = notificationData != null && notificationData.get("memberContactEmail") instanceof String ? (String) notificationData.get("memberContactEmail") : null;
        String validationStatus = notificationData != null && notificationData.get("validationStatus") instanceof String ? (String) notificationData.get("validationStatus") : null;
        String clearPassword = notificationData != null && notificationData.get("clearPassword") instanceof String ? (String) notificationData.get("clearPassword") : null;
        String deliveryMethodType = notificationData != null && notificationData.get("deliveryMethodType") instanceof String ? (String) notificationData.get("deliveryMethodType") : null;
        String userContactEmailChanged = notificationData != null && notificationData.get("userContactEmailChanged") instanceof String ? (String) notificationData.get("userContactEmailChanged") : null;
        String accessAccountViaTitan = notificationData != null && notificationData.get("AccessAccountViaTitan") instanceof String ? (String) notificationData.get("AccessAccountViaTitan") : null;
        String slidTitanized = notificationData != null && notificationData.get("slidTitanized") instanceof String ? (String) notificationData.get("slidTitanized") : null;

        String securityAnswerChanged = notificationData != null && notificationData.get("securityAnswerChanged") instanceof String ? (String) notificationData.get("securityAnswerChanged") : null;
        String linkedToSlid = notificationData != null && notificationData.get("linkedToSlid") instanceof String ? (String) notificationData.get("linkedToSlid") : null;
        String secondaryAcceptsOffer = notificationData != null && notificationData.get("secondaryAcceptsOffer") instanceof String ? (String) notificationData.get("secondaryAcceptsOffer") : null;
        String primaryApprovesAccess = notificationData != null && notificationData.get("primaryApprovesAccess") instanceof String ? (String) notificationData.get("primaryApprovesAccess") : null;
        String primaryLSLinkedToSLID= notificationData != null && notificationData.get("primaryLSLinkedToSLID") instanceof String ? (String) notificationData.get("primaryLSLinkedToSLID") : null;

        String sorInvariantId = Optional.ofNullable(event.get("sorInvariantId"))
                .map(String::valueOf)
                .orElse(null);

        String sorId = Optional.ofNullable(event.get("sorId"))
                .map(String::valueOf)
                .orElse(null);

        String accountFraudLocked = Optional.ofNullable(event.get("accountFraudLocked"))
                .map(String::valueOf)
                .orElse(null);

        String userLockLevel = Optional.ofNullable(event.get("userLockLevel"))
                .map(String::valueOf)
                .orElse(null);

        String deliveryMethodValue = notificationData != null && notificationData.get("deliveryMethodValue") instanceof String ? (String) notificationData.get("deliveryMethodValue") : null;
        String valueEmail = notificationData != null && notificationData.get("valueEmail") instanceof String ? (String) notificationData.get("valueEmail") : null;
        List<Map<String, Object>> resultList = new ArrayList<>();

        switch (Objects.requireNonNull(transactionName)) {
            case "AddServicesSync":
                if (qarKey != null) {
                    resultList.add(Map.of(
                            "cType", "ONLINE_ACCOUNT_REG",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "true"
                    ));
                }
                if (addCTN != null) {
                    resultList.add(Map.of(
                            "cType", "CTN_ADDED_TO_ACCESSID",
                            "NotificationLevel", "UserId",
                            "isCPNINotification", "false"
                    ));
                }
                if ("Y".equals(accessAccountViaTitan) && "Y".equals(titanInd)) {
                    resultList.add(Map.of(
                            "cType", "PRIN_USER_UPDATE",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "true"
                    ));
                }
                if ("Y".equals(titanInd) && "Y".equals(slidTitanized)) {
                    resultList.add(Map.of(
                            "cType", "SLID_TITANIZED",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "true"
                    ));
                }
                break;
            case "AtlasProcessor":
                if (qarKey != null) {
                    resultList.add(Map.of(
                            "cType", "ONLINE_ACCOUNT_REG",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "true"
                    ));
                }
                if ("Y".equals(titanInd) && "Y".equals(accessAccountViaTitan)) {
                    resultList.add(Map.of(
                            "cType", "PRIN_USER_UPDATE",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "true"
                    ));
                }
                if ("Y".equals(titanInd) && "Y".equals(slidTitanized)) {
                    resultList.add(Map.of(
                            "cType", "SLID_TITANIZED",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "true"
                    ));
                }
                if ( "ECOMM".equals(subEvent) && notificationData != null && notificationData.get("PhoneUpdateDetailsChanged") != null) {
                    resultList.add(Map.of(
                            "cType", "WIRELINE_HS_CBR_UPDATE",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "false"
                    ));
                }
                break;
            case "AddRole":
                if (("UVERSE".equals(serviceType) || "TITAN".equals(serviceType)) && "Y".equals(secondaryAccountRoleEnabled)) {
                    resultList.add(Map.of(
                            "cType", "ACCESS_GRANTED_PRIMARY",
                            "NotificationLevel", "Owner",
                            "isCPNINotification", "false"
                    ));
                    resultList.add(Map.of(
                            "cType", "ACCESS_GRANTED_SECONDARY",
                            "NotificationLevel", "Delegate",
                            "isCPNINotification", "false"
                    ));
                }
                break;
            case "UpdateMember":
                if ("Y".equals(securityAnswerChanged) && "ECOMM".equals(subEvent) && ("MYWORLD".equals(callingSystemId) || "CSRMYWORLD".equals(callingSystemId) || "IDP".equals(callingSystemId))) {
                    resultList.add(Map.of(
                            "cType", "ONLINE_SQA_UPDATE",
                            "NotificationLevel", "UserId",
                            "isCPNINotification", "true"
                    ));
                }
                if (linkedToSlid == null && userContactEmailChanged != null) {
                    resultList.add(Map.of(
                            "cType", "UPDATE_CONTACT_EMAIL",
                            "NotificationLevel", "UserId",
                            "isCPNINotification", "true"
                    ));
                }
                if (sorInvariantId != null && sorId != null && serviceType != null && "Y".equals(accountFraudLocked)) {
                    resultList.add(Map.of(
                            "cType", "ACCOUNT_LOCK",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "true"
                    ));
                }

                if ("0".equals(userLockLevel)) {
                    resultList.add(Map.of(
                            "cType", "ACCESSID_FRAUD_UNLOCK",
                            "NotificationLevel", "UserId",
                            "isCPNINotification", "true"
                    ));
                }
                if (slid != null && "1".equals(userLockLevel)) {
                    resultList.add(Map.of(
                            "cType", "LVLONE_ACCESSID_LOCK",
                            "NotificationLevel", "UserId",
                            "isCPNINotification", "true"
                    ));
                }
                if ("2".equals(userLockLevel)) {
                    resultList.add(Map.of(
                            "cType", "LVLTWO_ACCESSID_LOCK",
                            "NotificationLevel", "UserId",
                            "isCPNINotification", "true"
                    ));
                }
                if ("Y".equals(linkedToSlid) && notificationData != null &&
                    (notificationData.containsKey("contactEmail") || notificationData.containsKey("securityQuestion") ||
                    notificationData.containsKey("securityAnswer") || notificationData.containsKey("online1SecurityQuestion") ||
                    notificationData.containsKey("online1SecurityAnswer") || notificationData.containsKey("online2SecurityQuestion") ||
                    notificationData.containsKey("online2SecurityAnswer") || notificationData.containsKey("proofZip") ||
                    notificationData.containsKey("passcode"))) {
                    resultList.add(Map.of(
                            "cType", "PROFILE_UPDATE",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "true"
                    ));
                }
                if ("HS_WIRELESS_CBR".equals(serviceNotificationType) && ("update".equals(serviceNotification) || "delete".equals(serviceNotification))) {
                    resultList.add(Map.of(
                            "cType", "HS_CBR_CHANGE",
                            "NotificationLevel", "UserId",
                            "isCPNINotification", "false"
                    ));
                }
            break;
            case "ChangeData":
                if (changeMainCTN != null && oldMainCTN != null) {
                    resultList.add(Map.of(
                            "cType", "CTN_CHANGED_ON_ACCESSID",
                            "NotificationLevel", "UserId",
                            "isCPNINotification", "true"
                    ));
                }
                break;
            case "DisconnectServices":
            case "RemoveServicesGeneric":
            case "RemoveAccount":
                if (deleteMainCTN != null) {
                    resultList.add(Map.of(
                            "cType", "CTN_REMOVED_FROM_ACCESSID",
                            "NotificationLevel", "UserId",
                            "isCPNINotification", "true"
                    ));
                }
                if ("Y".equals(deleteAccount)) {
                    resultList.add(Map.of(
                            "cType", "DELETE_ACCOUNT",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "true"
                    ));
                }
                break;
            case "ChangeStatusByBANAsync":
            case "ChangeStatus":
                if ("Y".equals(deleteAccount)) {
                    resultList.add(Map.of(
                            "cType", "DELETE_ACCOUNT",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "true"
                    ));
                }
                break;
            case "LinkInternetAccount":
                if ("Y".equals(primaryLSLinkedToSLID)) {
                    resultList.add(Map.of(
                            "cType", "ONLINE_ACCOUNT_ADD2",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "true"
                    ));
                }
                break;
            case "AddAccount":
                // Add ONLINE_ACCOUNT_REG when qarKey is provided
                if ((qarKey != null && !qarKey.isEmpty())) {
                    resultList.add(Map.of(
                            "cType", "ONLINE_ACCOUNT_REG",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "true"
                    ));
                }
                if ("Y".equals(primaryAddAccount)||
                        "Y".equals(secondaryAccessGranted) || notificationData==null) {
                    resultList.add(Map.of(
                            "cType", "ONLINE_ACCOUNT_ADD2",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "true"
                    ));
                }
                if ("Y".equals(secondaryAccessGranted) && !"ECOMM".equals(serviceType)) {
                    resultList.add(Map.of(
                            "cType", "ONLINE_ACCOUNT_ADD_SEC",
                            "NotificationLevel", "UserId",
                            "isCPNINotification", "false"
                    ));
                }
                if (("Y".equals(secondaryAcceptsOffer) || "Y".equals(primaryApprovesAccess))) {
                    resultList.add(Map.of(
                            "cType", "SEC_REQ_APPROVE_TO_PRIN",
                            "NotificationLevel", "UserId",
                            "isCPNINotification", "true"
                    ));
                    resultList.add(Map.of(
                            "cType", "SEC_REQ_APPROVE_TO_SEC",
                            "NotificationLevel", "Delegate",
                            "isCPNINotification", "false"
                    ));
                }
                if (event.get("AccountId") != null && encryptedKey != null && cPNIEligibleMobileNumber != null) {
                    resultList.add(Map.of(
                            "cType", "HS_CBR_CONFIRM",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "false"
                    ));
                }
                if ( "ECOMM".equals(subEvent) && notificationData != null && notificationData.get("PhoneUpdateDetailsChanged") != null) {
                    resultList.add(Map.of(
                            "cType", "WIRELINE_HS_CBR_UPDATE",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "false"
                    ));
                }
                break;
            case "UpdateAccount":
                if (("TITAN".equals(accountType) || "MOBILITY".equals(accountType)) && "SLID".equals(subEvent) &&
                        encryptedKey != null && memberContactEmail != null && event.get("AccountId") != null) {
                    resultList.add(Map.of(
                            "cType", "EML_ADDR_VALIDATION",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "false"
                    ));
                }
                if (event.get("AccountId") != null && encryptedKey != null && cPNIEligibleMobileNumber != null) {
                    resultList.add(Map.of(
                            "cType", "HS_CBR_CONFIRM",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "false"
                    ));
                }

                if ( "ECOMM".equals(subEvent) && notificationData != null && notificationData.get("PhoneUpdateDetailsChanged") != null) {
                    resultList.add(Map.of(
                            "cType", "WIRELINE_HS_CBR_UPDATE",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "false"
                    ));
                }

                if (("Y".equals(serviceNotificationListChanged) && ("ECOMM".equals(serviceType) || "TITAN".equals(serviceType)))
                        || ("Y".equals(defaultAccountChanged) || "Y".equals(primaryEmailChanged))) {
                    resultList.add(Map.of(
                            "cType", "PROFILE_UPDATE",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "true"
                    ));
                }
                break;
            case "ChangeMemberPassword":

            case "ResetMemberPassword":
                if ((clearPassword != null && deliveryMethodType != null && "SLID".equals(subEvent))
                        || "ResetMemberPassword".equals(transactionName) || "ChangeMemberPassword".equals(transactionName)) {
                    resultList.add(Map.of(
                            "cType", "ONLINE_TEMP_PASSWD"
                    ));
                    resultList.add(Map.of(
                            "cType", "UPDATE_ONLINE_PASSWD"
                    ));
                }
                break;
            case "MergeSLIDProfile":
                if ("Y".equals(isCPNINotificationLinkedToSLID)) {
                    resultList.add(Map.of(
                            "cType", "MERGE_ACCOUNT_NOTIFY1",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "true"
                    ));
                }
                if ("N".equals(isCPNINotificationLinkedToSLID)) {
                    resultList.add(Map.of(
                            "cType", "MERGE_ACCOUNT_NOTIFY1",
                            "NotificationLevel", "UserId",
                            "isCPNINotification", "false"
                    ));
                }
                break;

            case "ChangeSLID":
                resultList.add(Map.of(
                        "cType", "SLID_UPDATE",
                        "NotificationLevel", "UserId",
                        "isCPNINotification", "false"
                ));
                if ("Y".equals(titanInd)) {
                    resultList.add(Map.of(
                            "cType", "PM_ACCT_CREATION",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "true"
                    ));
                }
                break;
            case "LSReg":
                if ("Y".equals(titanInd)) {
                    resultList.add(Map.of(
                            "cType", "PM_ACCT_CREATION",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "true"
                    ));
                }
                if (event.get("AccountId") != null && encryptedKey != null && cPNIEligibleMobileNumber != null) {
                    resultList.add(Map.of(
                            "cType", "HS_CBR_CONFIRM",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "false"
                    ));
                }
                break;
            case "CreateEmailAppPassword":
            case "DeleteEmailAppPassword":
                if (valueEmail != null) {
                    resultList.add(Map.of(
                            "cType", "PROFILE_UPDATE_SECURE_KEY"
                    ));
                }
                break;
            case "ChangeAccountOwner":
                if ("MOBILITY".equals(serviceType) || "ECOMM".equals(serviceType)) {
                    resultList.add(Map.of(
                            "cType", "SWAP_OWNERSHIP",
                            "NotificationLevel", "Account",
                            "isCPNINotification", "true"
                    ));
                }
                if ("TITAN".equals(serviceType)) {
                    resultList.add(Map.of(
                            "cType", "PRIN_USER_UPDATE",
                            "NotificationLevel", "UserId",
                            "isCPNINotification", "false"
                    ));
                }
                break;
            case "UpdateRole":
                if ("Y".equals(secondaryAcceptsOffer) || "Y".equals(primaryApprovesAccess)) {
                    resultList.add(Map.of(
                            "cType", "SEC_REQ_APPROVE_TO_PRIN",
                            "NotificationLevel", "UserId",
                            "isCPNINotification", "true"
                    ));
                    resultList.add(Map.of(
                            "cType", "SEC_REQ_APPROVE_TO_SEC",
                            "NotificationLevel", "Delegate",
                            "isCPNINotification", "false"
                    ));
                }
                break;
            case "GenerateSecurityCode":
                if ("APPTSCHED".equals(identificationType)) {
                    resultList.add(Map.of(
                            "cType", "APPT_VERIFICATION_CODE"
                    ));
                }
                if ("SLIDREG".equals(identificationType) || "OPR".equals(identificationType) || "OPRMOBILE".equals(identificationType) || "CTNOPR".equals(identificationType) || "CTNAUTH".equals(identificationType)) {
                    resultList.add(Map.of(
                            "cType", "HS_OPR_CBR_CONFIRM_WEB"
                    ));
                }
                if ("EDDORCACS".equals(identificationType)) {
                    resultList.add(Map.of(
                            "cType", "SECURITY_CODE"
                    ));
                }
                if ("EMAILOTP".equals(identificationType)) {
                    resultList.add(Map.of(
                            "cType", "EMAIL_VERIFICATION"
                    ));
                }
                if ("CRICKETOTP".equals(identificationType)) {
                    resultList.add(Map.of(
                            "cType", "EMAIL_VERIFICATION_CRKT"
                    ));
                }
                if ("EMAILPIN".equals(identificationType)) {
                    resultList.add(Map.of(
                            "cType", "EMAIL_VERIFICATION_PIN"
                    ));
                }
                if ("ENCPIN".equals(identificationType)) {
                    resultList.add(Map.of(
                            "cType", "NOTIFY_ME"
                    ));
                }
                if ("NONATTCTN".equals(identificationType) || "ATTCTN".equals(identificationType)) {
                    resultList.add(Map.of(
                            "cType", "ONE_TIME_PIN"
                    ));
                }
                if ("BANPC".equals(identificationType)) {
                    resultList.add(Map.of(
                            "cType", "TEMP_PIN"
                    ));
                }
                if ("IDSEMOB".equals(identificationType) || "BANPTONL".equals(identificationType)) {
                    resultList.add(Map.of(
                            "cType", "TEMP_PIN_ONLINE"
                    ));
                }
                if ("AUTHUSER".equals(identificationType)) {
                    resultList.add(Map.of(
                            "cType", "TEMP_PIN_ONLINE_AU"
                    ));
                }
                if ("CTNSEC".equals(identificationType) || "ECOMMSEC".equals(identificationType) || "TIATANSEC".equals(identificationType) || "WBANSEC".equals(identificationType)) {
                    resultList.add(Map.of(
                            "cType", "ORC_SEC"
                    ));
                }
                // Always add ORC for GenerateSecurityCode
                resultList.add(Map.of(
                        "cType", "ORC"
                ));
                break;
            default:
                break;
        }
        // If no rules matched, return default
        if (resultList.isEmpty()) {
            resultList.add(Map.of(C_TYPE, event.getOrDefault(C_TYPE, DEFAULT_CTYPE).toString()));
        }
        return resultList;
    }
    /**
     * Retrieves the customer type from the event map.
     * @param event the event data as a map
     * @return an Optional containing the customer type if present, otherwise empty
     */
    public static Optional<String> getCustomerType(Map<String, Object> event) {
        if (event == null) {
            log.warn("CTypeHelper.getCustomerType: event is null");
            return Optional.empty();
        }
        Object customerTypeObj = event.get("customerType");
        if (customerTypeObj instanceof String) {
            return Optional.of((String) customerTypeObj);
        }
        return Optional.empty();
    }

}

