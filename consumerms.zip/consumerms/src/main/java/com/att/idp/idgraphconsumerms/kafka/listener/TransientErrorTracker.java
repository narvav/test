package com.att.idp.idgraphconsumerms.kafka.listener;

import java.time.Instant;
import java.util.concurrent.ConcurrentLinkedDeque;

public class TransientErrorTracker {

    private final int windowSeconds;
    private final int threshold;
    private final ConcurrentLinkedDeque<Instant> errorTimestamps = new ConcurrentLinkedDeque<>();

    public TransientErrorTracker(int windowSeconds, int threshold) {
        this.windowSeconds = windowSeconds;
        this.threshold = threshold;
    }

    public boolean recordErrorAndCheckThreshold() {
        Instant now = Instant.now();
        errorTimestamps.addLast(now);
        evictExpired(now);
        return errorTimestamps.size() >= threshold;
    }

    public void reset() {
        errorTimestamps.clear();
    }

    public int currentCount() {
        evictExpired(Instant.now());
        return errorTimestamps.size();
    }

    private void evictExpired(Instant now) {
        Instant cutoff = now.minusSeconds(windowSeconds);
        while (!errorTimestamps.isEmpty()) {
            Instant oldest = errorTimestamps.peekFirst();
            if (oldest != null && oldest.isBefore(cutoff)) {
                errorTimestamps.pollFirst();
            } else {
                break;
            }
        }
    }
}
