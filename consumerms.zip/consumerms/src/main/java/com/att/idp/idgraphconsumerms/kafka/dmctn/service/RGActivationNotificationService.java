package com.att.idp.idgraphconsumerms.kafka.dmctn.service;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker;
import com.att.idp.idgraphconsumerms.kafka.model.AccountNotificationEvent;
import com.att.idp.idgraphconsumerms.model.RGActivationPlatformHandlerRequest;
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.att.mpsys.common.utils.CErrorDefs;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class RGActivationNotificationService implements BaseService<AccountNotificationEvent> {

    private static final Logger logger = LoggerFactory.getLogger(RGActivationNotificationService.class);

    @Value("${apiclient.rest.ua.rgactivation.endpoint}")
    private String rgActivationEndpoint;

    @Autowired
    private CosmosFailedEventsWriter cosmosFailedEventsWriter;

    @Autowired
    private GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker;

    private final ApiRestClient apiRestClient;

    public RGActivationNotificationService(ApiRestClient apiRestClient) {
        this.apiRestClient = apiRestClient;
    }

    @Override
    public void execute(AccountNotificationEvent accountNotificationEvent) {
        String sourceBan = accountNotificationEvent.getAccountNumber();
        String eventName = ConsumerConstants.GridGddnNotification.resolveEventName(accountNotificationEvent.getEventName());

        // Circuit breaker: short-circuit to Cosmos if pending failed events exist
        if (gddnFailedEventCircuitBreaker.shouldShortCircuit(sourceBan, eventName)) {
            logger.warn("RGActivationNotificationService: Circuit breaker OPEN for BAN={}. Saving directly to Cosmos.",
                    ESAPI.encoder().encodeForHTML(sourceBan));
            RGActivationPlatformHandlerRequest cbRequest = buildOutgoingRequest(accountNotificationEvent);
            FailedEventUtil.saveFailedEventCircuitOpen(
                    cosmosFailedEventsWriter, sourceBan,
                    JsonService.getJsonFromObject(cbRequest), eventName,
                    CErrorDefs.SYS_ERR, "Circuit breaker open \u2014 pending failed events exist",
                    rgActivationEndpoint, ConsumerConstants.AccountNotificationConstants.UVERSE);
            return;
        }

        RGActivationPlatformHandlerRequest outgoingRequest = buildOutgoingRequest(accountNotificationEvent);

        try {
            if (isBlank(sourceBan)) {
                logger.error("Missing billingAccountNumber for RGActivation event. traceId={}",
                        ESAPI.encoder().encodeForHTML(accountNotificationEvent.getEventId()));
                FailedEventUtil.saveFailedEventValidationFailed(
                        cosmosFailedEventsWriter,
                        sourceBan,
                        JsonService.getJsonFromObject(accountNotificationEvent),
                        eventName,
                        CErrorDefs.ERR_INVALID_DATA,
                        "billingAccountNumber is mandatory for RGActivation",
                        ConsumerConstants.ErrorDetails.VALIDATION_FAILED,
                        ConsumerConstants.AccountNotificationConstants.UVERSE
                );
                return;
            }

            apiRestClient.sendPostRequest(rgActivationEndpoint, outgoingRequest, eventName, ConsumerConstants.AccountNotificationConstants.UVERSE);
        } catch (Exception e) {
            logger.error("Error processing RGActivation for billingAccountNumber: {}", ESAPI.encoder().encodeForHTML(sourceBan), e);
            FailedEventUtil.saveFailedEventResolvingCategory(
                    cosmosFailedEventsWriter,
                    sourceBan,
                    JsonService.getJsonFromObject(outgoingRequest),
                    eventName,
                    CErrorDefs.SYS_ERR,
                    e.getMessage(),
                    rgActivationEndpoint,
                    ConsumerConstants.AccountNotificationConstants.UVERSE
            );
        }
    }

    private static RGActivationPlatformHandlerRequest buildOutgoingRequest(AccountNotificationEvent accountNotificationEvent) {
        RGActivationPlatformHandlerRequest outgoingRequest = new RGActivationPlatformHandlerRequest();
        outgoingRequest.setBan(accountNotificationEvent.getAccountNumber());
        outgoingRequest.setCallingSystemId(ConsumerConstants.DmctnSubscriberChangeEvent.CLIENT_ATLASBUS);
        outgoingRequest.setRgActivated("Y");
        return outgoingRequest;
    }

    private static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
