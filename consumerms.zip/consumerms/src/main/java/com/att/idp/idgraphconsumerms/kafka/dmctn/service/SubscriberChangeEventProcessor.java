package com.att.idp.idgraphconsumerms.kafka.dmctn.service;


import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.kafka.model.Subscriber;
import com.att.idp.idgraphconsumerms.oracle.helpers.MemberServiceDBHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Component
public class SubscriberChangeEventProcessor {

    private static final Logger logger = LoggerFactory.getLogger(SubscriberChangeEventProcessor.class);


    @Autowired
    private BackendServiceFactory backendServiceFactory;

    public void processEvent(Subscriber subscriber, MessageHeaders headers) {

        logger.info("Processing SubscriberChangeEvent for subscriber id: {}, subscriber: {}", subscriber.getId(), subscriber.getPhoneNumber());
        MDC.put(ConsumerConstants.Keys.X_ATT_CLIENTID, ConsumerConstants.DmctnSubscriberChangeEvent.CLIENT_CUSTOMERGRAPH);

        Object changeTypeObj = headers.get("ChangeType");
        String changeTypeHeader = null;
        if (changeTypeObj instanceof byte[]) {
            changeTypeHeader = new String((byte[]) changeTypeObj, StandardCharsets.UTF_8);
        } else if (changeTypeObj instanceof String) {
            changeTypeHeader = (String) changeTypeObj;
        }

        List<String> changeTypes = changeTypeHeader != null ? Arrays.asList(changeTypeHeader.split(",")) : Collections.emptyList();

        if (changeTypes != null) {
            for (String changeType : changeTypes) {
                BackendService service = backendServiceFactory.getService(changeTypes, subscriber);
                if (service != null) {
                    service.execute(subscriber, EventSource.CG);
                }
            }
        }
        MDC.clear();
    }

}
