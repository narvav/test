package com.att.idp.idgraphconsumerms.resource.response;

import java.util.List;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class KafkaListenersResponse {

    private final List<KafkaListenerStatusDetail> listeners;
    private final List<KafkaListenerConnectionDetail> listenerDetails;
}
