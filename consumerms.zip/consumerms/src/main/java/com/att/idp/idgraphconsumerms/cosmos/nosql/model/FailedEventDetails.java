package com.att.idp.idgraphconsumerms.cosmos.nosql.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FailedEventDetails {
    private String accountId;
    private String requestPayload;
    private String eventName;
    private String eventCategory;
    private String status;
    private Map<String, String> errorDetails;
    private String processedSvrUrl;

    public FailedEventDetails(String accountId, String requestPayload, String eventName, Map<String, String> errorDetails) {
        this.accountId = accountId;
        this.requestPayload = requestPayload;
        this.eventName = eventName;
        this.errorDetails = errorDetails;
    }
}
