package com.att.idp.idgraphconsumerms.helpers;

import java.util.Map;

/**
 * Helper class providing base rule validation utilities.
 * <p>
 * Contains common methods for validating event data structures.
 * </p>
 */
public class BaseRuleHelper {


    /**
     * Validates that the provided event data map is not null and not empty.
     *
     * @param event the event data as a map of key-value pairs
     * @return true if the event map is not null and not empty, false otherwise
     */
    protected boolean isValidEventsData(Map<String, Object> event) {
        return event != null && !event.isEmpty();
    }

}
