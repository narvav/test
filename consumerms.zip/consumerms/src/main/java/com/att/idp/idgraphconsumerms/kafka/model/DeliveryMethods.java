package com.att.idp.idgraphconsumerms.kafka.model;

import com.att.idp.idgraph.events.model.JsonSealizable;
import com.att.idp.idgraphconsumerms.kafka.model.PostalAddress;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DeliveryMethods implements JsonSealizable {
    private String emailAddress;
    private String ctn;
    private PostalAddress postalAddress;
    private String aoTN;

}