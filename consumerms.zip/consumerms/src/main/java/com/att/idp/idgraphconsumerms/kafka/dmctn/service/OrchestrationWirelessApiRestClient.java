package com.att.idp.idgraphconsumerms.kafka.dmctn.service;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.model.SorOrchestrationRequest;
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.att.mpsys.common.utils.CErrorDefs;
import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;

@Service
public class OrchestrationWirelessApiRestClient {

    @Value("${apiclient.rest.ur.serverUrl}")
    private String userRegServerUrl;

    @Value("${apiclient.rest.ur.username}")
    private String userName;

    @Value("${apiclient.rest.ur.password}")
    private String userPassword;

    @Autowired
    private CosmosFailedEventsWriter cosmosFailedEventsWriter;

    private final RestTemplate restTemplate;


    private static final Logger logger = LoggerFactory.getLogger(OrchestrationWirelessApiRestClient.class);
    private static final int MAX_ATTEMPTS = 2;


    public OrchestrationWirelessApiRestClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Retryable(maxAttempts = MAX_ATTEMPTS, retryFor = {HttpServerErrorException.class})
    public ResponseEntity<JsonNode> sendPostRequest(String endpoint, SorOrchestrationRequest outgoingRequest, String eventName) {
        String resourceUri = userRegServerUrl + endpoint;

        String requestBody = JsonService.getJsonFromObject(outgoingRequest);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(ConsumerConstants.Keys.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString((userName + ":" + userPassword).getBytes()));
        headers.add(ConsumerConstants.Keys.X_ATT_CLIENTID, MDC.get(ConsumerConstants.Keys.X_ATT_CLIENTID));
        headers.add(ConsumerConstants.Keys.IDP_TRACE_ID, MDC.get(ConsumerConstants.Keys.IDP_TRACE_ID));
        if(MDC.get(ConsumerConstants.Keys.IDPCTX_SESSION_ID) != null) {
            headers.add(ConsumerConstants.Keys.IDPCTX_SESSION_ID, MDC.get(ConsumerConstants.Keys.IDPCTX_SESSION_ID));
        }
        HttpEntity<String> httpEntity = new HttpEntity<>(requestBody, headers);

        logger.info("Calling  API URI: {} with request: {}", resourceUri, requestBody);

        try {
            ResponseEntity<JsonNode> response = restTemplate.exchange(resourceUri, HttpMethod.POST, httpEntity, JsonNode.class);
            logger.info("Response from WirelessOrchestrationService API: {}", sanitizeForLog(response.getBody() != null ? response.getBody().toString() : "null"));
            if (!HttpStatus.OK.equals(response.getStatusCode())) {
                FailedEventUtil.saveFailedEvent(cosmosFailedEventsWriter, outgoingRequest.getSorInvariantId(), JsonService.getJsonFromObject(outgoingRequest), eventName, CErrorDefs.ERR_INVALID_DATA, response.getStatusCode().toString(), endpoint, ConsumerConstants.AccountNotificationConstants.WIRELESS, userRegServerUrl);
            }

        } catch (HttpServerErrorException e) {
            logger.error("Retryable exception while calling IDGraphUserRegistrationMs. {} Will be retried for a max attempts of: {}", e, MAX_ATTEMPTS);
            throw e;
        } catch (Exception e) {
            logger.error("Non-retryable exception received in wirelessOrchestration API: {}", e);
            handleNonRetryableFailure(e, endpoint, outgoingRequest, CErrorDefs.ERR_INVALID_DATA, eventName);
        }
        return null;
    }


    @Recover
    public ResponseEntity<JsonNode> recover(HttpServerErrorException e, String endpoint, SorOrchestrationRequest outgoingRequest, String eventName) {

        logger.error("HttpServerErrorException while calling wirelessOrchestration API, Exhausted retries: {}", e.getMessage());
        handleNonRetryableFailure(e, endpoint, outgoingRequest, CErrorDefs.SYS_ERR, eventName);
        return null;
    }

    private void handleNonRetryableFailure(Exception e, String endpoint, SorOrchestrationRequest outgoingRequest, String errorCode, String eventName) {
        logger.error("HttpServerErrorException while calling IDGraphUserRegistrationMs, Exhausted retries : {}", e.getMessage());

        FailedEventUtil.saveFailedEvent(cosmosFailedEventsWriter, outgoingRequest.getSorInvariantId(), JsonService.getJsonFromObject(outgoingRequest), eventName, CErrorDefs.SYS_ERR, e.getMessage(), endpoint, ConsumerConstants.AccountNotificationConstants.WIRELESS, userRegServerUrl);
    }

    private String sanitizeForLog(String input) {
        if (input == null) return null;
        return input.replaceAll("[\\r\\n]", " ");
    }
}