package com.att.idp.idgraphconsumerms.constants;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public final class OdsNotesConstants {

    private OdsNotesConstants() {
    }

    // Domain & compare type (shared across all 3 flows)
    public static final String DOMAIN = "idGraph";
    public static final String COMPARE_TYPE = "NA";

    // Event types
    public static final String EVENT_TYPE_CHANGE_BAN_PASSCODE = "Change BAN Passcode";
    public static final String EVENT_TYPE_PASSCODE_CHANGED = "Passcode Changed";
    public static final String EVENT_TYPE_NUMBER_TRANSFER_PIN = "Number Transfer PIN";
    public static final String EVENT_TYPE_GENERATE_PIN_BSSEGENS = "Generate PIN - BSSEGENS";
    public static final String EVENT_TYPE_GENERATE_PIN_BSSEGENE = "Generate PIN - BSSEGENE";
    public static final String EVENT_TYPE_VERIFY_PIN_BSSEGENS = "Verify PIN - BSSEGENS";
    public static final String EVENT_TYPE_VERIFY_PIN_BSSEGENE = "Verify PIN - BSSEGENE";
    public static final String EVENT_TYPE_FRAUD_LOCK = "Fraud Lock";
    public static final String EVENT_TYPE_FRAUD_UNLOCK = "Fraud Unlock";

    // ID types
    public static final String ID_TYPE_INDIVIDUAL = "individual";
    public static final String ID_TYPE_BILLING_ACCOUNT = "billingAccount";

    // Filter values — Profile Update
    public static final String FILTER_EVENT_TYPE_PROFILE_UPDATE = "ProfileUpdate";
    public static final String FILTER_CATEGORY_PASSCODE = "Passcode";
    public static final String FILTER_PASSCODE_TYPE_DIGITAL = "D";
    public static final String FIELD_PASSCODE_TYPE = "passcodeType";

    // Filter values — Oracle Security Code
    public static final String FILTER_EVENT_TYPE_ORACLE_SECURITY_CODE_SYNC = "OracleSecurityCodeSync";
    public static final String FILTER_RESOURCE_NAME_OTP = "OTP";
    public static final String FILTER_IDENTIFICATION_TYPE_PORTOUTBSS = "PORTOUTBSS";
    public static final String FILTER_IDENTIFICATION_TYPE_BSSEGENS = "BSSEGENS";
    public static final String FILTER_IDENTIFICATION_TYPE_BSSEGENE = "BSSEGENE";
    public static final String FILTER_ORACLE_EVENT_TYPE_INSERT = "INSERT";
    public static final String FILTER_ORACLE_EVENT_TYPE_UPDATE = "UPDATE";
    public static final Set<String> FILTER_ORACLE_EVENT_TYPES = Set.of("INSERT", "UPDATE");
    public static final Map<String, String> BSSE_OTP_EVENT_TYPE_MAP = Map.of(
            FILTER_IDENTIFICATION_TYPE_BSSEGENS, EVENT_TYPE_GENERATE_PIN_BSSEGENS,
            FILTER_IDENTIFICATION_TYPE_BSSEGENE, EVENT_TYPE_GENERATE_PIN_BSSEGENE
    );
    public static final Map<String, String> BSSE_OTP_VERIFY_EVENT_TYPE_MAP = Map.of(
            FILTER_IDENTIFICATION_TYPE_BSSEGENS, EVENT_TYPE_VERIFY_PIN_BSSEGENS,
            FILTER_IDENTIFICATION_TYPE_BSSEGENE, EVENT_TYPE_VERIFY_PIN_BSSEGENE
    );

    // Filter values — Fraud
    public static final String FILTER_EVENT_NAME_UPDATE_USER_FRAUD = "UpdateUserFraud";
    public static final String FILTER_SUB_CATEGORY_LVLONE = "LVLONE_ACCESSID_LOCK";
    public static final String FILTER_SUB_CATEGORY_LVLTWO = "LVLTWO_ACCESSID_LOCK";
    public static final String FILTER_SUB_CATEGORY_UNLOCK = "ACCESSID_FRAUD_UNLOCK";
    public static final Set<String> FILTER_FRAUD_SUB_CATEGORIES = Set.of(
            FILTER_SUB_CATEGORY_LVLONE, FILTER_SUB_CATEGORY_LVLTWO, FILTER_SUB_CATEGORY_UNLOCK
    );
    public static final String ATTRIBUTE_USER_LOCKED_REASON_CODE = "userLockedReasonCode";

    // Data array field keys
    public static final String DATA_INDIVIDUAL_ID = "individualId";
    public static final String DATA_ACCOUNT_TYPE = "accountType";
    public static final String DATA_ACCOUNT_ID = "accountId";
    public static final String DATA_PORTOUT_TYPE = "portoutType";
    public static final String DATA_OTP_TYPE = "otpType";
    public static final String DATA_VALIDATION_STATUS = "validationStatus";
    public static final String DATA_AGENT_ID = "agentId";
    public static final String DATA_CREATED_DATE = "createdDate";
    public static final String DATA_PIN_EXPIRY_DATE = "pinExpiryDate";
    public static final String DATA_DELIVERED_TO = "deliveredTo";
    public static final String DATA_USER_ID = "userId";
    public static final String DATA_USER_LOCK_TYPE = "userLockType";
    public static final String DATA_USER_LOCKED_REASON_CODE = "userLockedReasonCode";
    public static final String DATA_ACCOUNT_TYPE_POSTPAID = "postPaid";
    public static final String DATA_DEFAULT_NA = "NA";

    // Channel mapping — Profile Update (clientId → channel)
    public static final Map<String, String> PASSCODE_CHANNEL_MAP;

    static {
        Map<String, String> map = new HashMap<>();
        map.put("IVRSAG", "IVR");
        map.put("IDP", "DIGITAL");
        map.put("IDMPROFILEMS", "DIGITAL");
        map.put("CCMULE", "CARE");
        map.put("BSSEMIPAAS", "MIGRATION");
        PASSCODE_CHANNEL_MAP = Collections.unmodifiableMap(map);
    }

    // Channel mapping — Oracle PIN (updatedBy → channel)
    public static final Map<String, String> PIN_CHANNEL_MAP;

    static {
        Map<String, String> map = new HashMap<>();
        map.put("IDPWAM", "DIGITAL");
        map.put("IDP", "DIGITAL");
        map.put("IVRSAG", "IVR");
        PIN_CHANNEL_MAP = Collections.unmodifiableMap(map);
    }

    // Channel mapping — Fraud (clientId → channel)
    public static final Map<String, String> FRAUD_CHANNEL_MAP;

    static {
        Map<String, String> map = new HashMap<>();
        map.put("AVERTACK", "AVERTACK");
        map.put("YAHOO", "YAHOO");
        map.put("NEMESIS", "Fraud Team");
        map.put("CSRIDP", "CARE");
        map.put("IDPCALM", "CARE");
        map.put("IDPCOMENBSER", "Digital");
        FRAUD_CHANNEL_MAP = Collections.unmodifiableMap(map);
    }

    // Publisher binding name
    public static final String ODS_GENERATE_NOTES_BINDING = "odsGenerateNotes";
    public static final String ODS_GENERATE_NOTES_LABEL = "OdsGenerateNotes";

    // Log prefixes
    public static final String LOG_PREFIX_ORACLE_EVENTS = "NOTES_OE";
    public static final String LOG_PREFIX_PROFILE_UPDATE = "NOTES_PU";
    public static final String LOG_PREFIX_USERID_NOTIFICATIONS = "NOTES_UN";
}
