package com.att.idp.idgraphconsumerms.kafka.listener;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.kafka.dmctn.service.SubscriberChangeEventProcessor;
import com.att.idp.idgraphconsumerms.kafka.dmctn.service.SubscriberCreateEventProcessor;
import com.att.idp.idgraphconsumerms.kafka.model.CGSubscriberEvent;
import com.att.idp.idgraphconsumerms.kafka.model.Event;
import com.att.idp.idgraphconsumerms.kafka.model.Subscriber;
import com.att.idp.idgraphconsumerms.request.validator.RequestValidator;
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;

import java.util.Random;

/**
 * Processor for CG Subscriber Event logic shared by OAuth and Plain listeners.
 */
@Component
public class DmctnCGSubscriberEventProcessor {
    private static final Logger logger = LoggerFactory.getLogger(DmctnCGSubscriberEventProcessor.class);
    private final ObjectMapper objectMapper;
    private final RequestValidator requestValidator;
    private final SubscriberChangeEventProcessor subscriberChangeEventProcessor;
    private final SubscriberCreateEventProcessor subscriberCreateEventProcessor;

    public DmctnCGSubscriberEventProcessor(RequestValidator requestValidator,
                                           SubscriberChangeEventProcessor subscriberChangeEventProcessor,
                                           SubscriberCreateEventProcessor subscriberCreateEventProcessor) {
        this.objectMapper = new ObjectMapper();
        this.objectMapper.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
        this.objectMapper.enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
        this.requestValidator = requestValidator;
        this.subscriberChangeEventProcessor = subscriberChangeEventProcessor;
        this.subscriberCreateEventProcessor = subscriberCreateEventProcessor;
    }

    public void processEvent(String msg, MessageHeaders messageHeaders, Acknowledgment ack) throws JsonProcessingException {
        long startTm = System.currentTimeMillis();
        String traceId = generateTraceId();
        MDC.put(ConsumerConstants.Keys.IDP_TRACE_ID, traceId);
        logger.info("idp-trace-id generated: {}", traceId);
        logger.info("WEB000 : CGSubcriberEvent consumer initiation: {}", msg);

        CGSubscriberEvent cgSubscriberEvent = objectMapper.readValue(msg, CGSubscriberEvent.class);
        String eventType = cgSubscriberEvent.getEventType();
        Event subscriberEvent = cgSubscriberEvent.getEvent();
        String subscriberJsonString = subscriberEvent.getSubscriber();
        Subscriber subscriber = objectMapper.readValue(subscriberJsonString, Subscriber.class);

        logger.info("messageheaders from listener: {}, Storing the message cgSubscriberEvent to cosmos: {}", messageHeaders, cgSubscriberEvent);

        if (ConsumerConstants.DmctnSubscriberChangeEvent.EVENT_TYPE_SUBSCRIBER_CHANGE.equalsIgnoreCase(eventType)) {
            if (!messageHeaders.containsKey(ConsumerConstants.DmctnSubscriberChangeEvent.HEADER_KEY_CHANGETYPE)) {
                logger.info("Received message has invalid eventType or header changeType is missing: {}. Acknowledging the message", cgSubscriberEvent.getEventType());
                ack.acknowledge();
                return;
            }
            logger.info("Received message for Subscriber Change Event: {}", cgSubscriberEvent);
            subscriberChangeEventProcessor.processEvent(subscriber, messageHeaders);
        } else if (ConsumerConstants.DmctnSubscriberChangeEvent.EVENT_TYPE_SUBSCRIBER_CREATE.equalsIgnoreCase(eventType)) {
            logger.info("Received message for Subscriber Create Event: {}", cgSubscriberEvent);
            subscriberCreateEventProcessor.processEvent(subscriber, messageHeaders);
        } else {
            logger.error("Received message with unsupported eventId: {}. Acknowledging the message", eventType);
        }

        String sTimeTaken = ConsumerUtil.getElapsedTimeInSecs(startTm) + " seconds";
        logger.info("WEB999 : Total time taken : {} CGSubcriberEvent consumer Response : {}", sTimeTaken, msg);
        logger.info("Committing the offset for the message");
        ack.acknowledge();
    }

    private String generateTraceId() {
        Random r = new Random();
        String spanId = Long.toHexString(r.nextLong());
        return spanId + ":" + spanId + ":0:0";
    }
}

