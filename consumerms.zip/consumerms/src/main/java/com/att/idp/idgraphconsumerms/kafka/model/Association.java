package com.att.idp.idgraphconsumerms.kafka.model;


import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Association {
    private String serviceName;
    private String sorName;
    private String oldSorInvariantId;
    private String newSorInvariantId;
    private String oldInstanceId;
    private String newInstanceId;
    private String serviceStatus; // Enabled/Suspended
    private String instanceId; // CTN
    private String sorInvariantId;
}