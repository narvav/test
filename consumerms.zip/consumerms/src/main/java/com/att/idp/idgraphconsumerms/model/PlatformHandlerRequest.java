package com.att.idp.idgraphconsumerms.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PlatformHandlerRequest {
    private String ban;
    private String oldFan;
    private String newFan;
    private String phFan;
    private String transactionType;
    private String callingSystemId;
    private String idpTraceId;
    private String eventTime;
}
