package com.att.idp.idgraphconsumerms.helpers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Component;

import com.att.idp.idgraphconsumerms.constants.OdsNotesConstants;
import com.att.idp.idgraphconsumerms.kafka.model.OdsGenerateNotesEvent;
import com.fasterxml.jackson.databind.JsonNode;

@Component
public class OdsNotesTransformHelper {

    /**
     * Transforms a Profile Update event into an OdsGenerateNotesEvent.
     * Filter: eventType == 'ProfileUpdate' AND category == 'Passcode'
     */
    public Optional<OdsGenerateNotesEvent> transformProfileUpdateEvent(JsonNode input) {
        String eventType = input.path("eventType").asText("");
        String category = input.path("category").asText("");

        if (!OdsNotesConstants.FILTER_EVENT_TYPE_PROFILE_UPDATE.equals(eventType)
                || !OdsNotesConstants.FILTER_CATEGORY_PASSCODE.equals(category)) {
            return Optional.empty();
        }

        JsonNode eventDetails = input.path("eventDetails");
        String individualId = eventDetails.path("individualId").asText(null);
        String clientId = eventDetails.path("clientId").asText("");
        String channel = OdsNotesConstants.PASSCODE_CHANNEL_MAP.getOrDefault(clientId, clientId);

        // Extract passcodeType from attributes array
        String passcodeType = null;
        JsonNode attributes = eventDetails.path("attributes");
        if (attributes.isArray()) {
            for (JsonNode attr : attributes) {
                if (OdsNotesConstants.FIELD_PASSCODE_TYPE.equals(attr.path("attributeName").asText(""))) {
                    passcodeType = attr.path("attributeValue").asText(null);
                    break;
                }
            }
        }

        String noteEventType = OdsNotesConstants.FILTER_PASSCODE_TYPE_DIGITAL.equals(passcodeType)
                ? OdsNotesConstants.EVENT_TYPE_PASSCODE_CHANGED
                : OdsNotesConstants.EVENT_TYPE_CHANGE_BAN_PASSCODE;

        Map<String, Object> dataEntry = new HashMap<>();
        dataEntry.put(OdsNotesConstants.DATA_INDIVIDUAL_ID, individualId);
        dataEntry.put(OdsNotesConstants.DATA_AGENT_ID,
                eventDetails.path(OdsNotesConstants.DATA_AGENT_ID).asText(null));
        String accountType = eventDetails.path("accountType").asText(null);
        String accountId = eventDetails.path("accountId").asText(null);
        if (accountType != null && accountId != null) {
            dataEntry.put(OdsNotesConstants.DATA_ACCOUNT_TYPE, accountType);
            dataEntry.put(OdsNotesConstants.DATA_ACCOUNT_ID, accountId);
        }

        List<Map<String, Object>> data = new ArrayList<>();
        data.add(dataEntry);

        return Optional.of(buildEvent(
                input.path("eventId").asText(null),
                individualId,
                OdsNotesConstants.ID_TYPE_INDIVIDUAL,
                noteEventType,
                channel,
                data
        ));
    }

    /**
     * Transforms an Oracle Security Code event into an OdsGenerateNotesEvent.
     * Filter: eventType == 'OracleSecurityCodeSync' AND resourceName == 'OTP'
     *         AND event.type IN ('INSERT','UPDATE') AND event.data.identificationType == 'PORTOUTBSS'
     */
    public Optional<OdsGenerateNotesEvent> transformOracleSecurityCodeEvent(JsonNode input) {
        String eventType = input.path("eventType").asText("");
        String resourceName = input.path("resourceName").asText("");
        String oracleEventType = input.path("event").path("type").asText("");
        String identificationType = input.path("event").path("data").path("identificationType").asText("");

        boolean isPortoutEvent = OdsNotesConstants.FILTER_ORACLE_EVENT_TYPES.contains(oracleEventType)
                && OdsNotesConstants.FILTER_IDENTIFICATION_TYPE_PORTOUTBSS.equals(identificationType);
        boolean isBsseOtpEvent = OdsNotesConstants.FILTER_ORACLE_EVENT_TYPE_INSERT.equals(oracleEventType)
                && OdsNotesConstants.BSSE_OTP_EVENT_TYPE_MAP.containsKey(identificationType);
        boolean isBsseOtpVerifyEvent = OdsNotesConstants.FILTER_ORACLE_EVENT_TYPE_UPDATE.equals(oracleEventType)
                && OdsNotesConstants.BSSE_OTP_VERIFY_EVENT_TYPE_MAP.containsKey(identificationType);
        if (!OdsNotesConstants.FILTER_EVENT_TYPE_ORACLE_SECURITY_CODE_SYNC.equals(eventType)
                || !OdsNotesConstants.FILTER_RESOURCE_NAME_OTP.equals(resourceName)
                || (!isPortoutEvent && !isBsseOtpEvent && !isBsseOtpVerifyEvent)) {
            return Optional.empty();
        }

        JsonNode eventData = input.path("event").path("data");
        String accountId = eventData.path("accountId").asText(null);
        JsonNode securityCode = eventData.path("securityCode");
        String updatedBy = securityCode.path("updatedBy").asText("");
        String channel = OdsNotesConstants.PIN_CHANNEL_MAP.getOrDefault(updatedBy, updatedBy);
        String noteEventType = isBsseOtpVerifyEvent
                ? OdsNotesConstants.BSSE_OTP_VERIFY_EVENT_TYPE_MAP.get(identificationType)
                : isBsseOtpEvent
                        ? OdsNotesConstants.BSSE_OTP_EVENT_TYPE_MAP.get(identificationType)
                        : OdsNotesConstants.EVENT_TYPE_NUMBER_TRANSFER_PIN;

        Map<String, Object> dataEntry = new HashMap<>();
        dataEntry.put(OdsNotesConstants.DATA_ACCOUNT_ID, accountId);
        if (isBsseOtpVerifyEvent) {
            dataEntry.put(OdsNotesConstants.DATA_ACCOUNT_TYPE,
                    eventData.path("securityAccount").path("accountType").asText(null));
            dataEntry.put(OdsNotesConstants.DATA_OTP_TYPE, identificationType);
            dataEntry.put(OdsNotesConstants.DATA_VALIDATION_STATUS,
                    securityCode.path("securityCodeStatus").asText(null));
            dataEntry.put(OdsNotesConstants.DATA_AGENT_ID, eventData.path(OdsNotesConstants.DATA_AGENT_ID).asText(null));
        } else {
            dataEntry.put(OdsNotesConstants.DATA_ACCOUNT_TYPE, OdsNotesConstants.DATA_ACCOUNT_TYPE_POSTPAID);
            dataEntry.put(isBsseOtpEvent ? OdsNotesConstants.DATA_OTP_TYPE : OdsNotesConstants.DATA_PORTOUT_TYPE,
                    identificationType);
            dataEntry.put(OdsNotesConstants.DATA_CREATED_DATE, securityCode.path("createdDate").asText(null));
            dataEntry.put(OdsNotesConstants.DATA_PIN_EXPIRY_DATE,
                    securityCode.path("securityCodeExpires").asText(null));
            dataEntry.put(OdsNotesConstants.DATA_DELIVERED_TO, securityCode.path("deliveryDetail").asText(null));
        }

        List<Map<String, Object>> data = new ArrayList<>();
        data.add(dataEntry);

        return Optional.of(buildEvent(
                input.path("eventId").asText(null),
                accountId,
                OdsNotesConstants.ID_TYPE_BILLING_ACCOUNT,
                noteEventType,
                channel,
                data
        ));
    }

    /**
     * Transforms a User Fraud event into an OdsGenerateNotesEvent.
     * Filter: eventName == 'UpdateUserFraud' AND eventDetails.individualId != null
     *         AND eventDetails.subCategory IN (LVLONE_ACCESSID_LOCK, LVLTWO_ACCESSID_LOCK, ACCESSID_FRAUD_UNLOCK)
     */
    public Optional<OdsGenerateNotesEvent> transformUserFraudEvent(JsonNode input) {
        String eventName = input.path("eventName").asText("");
        if (!OdsNotesConstants.FILTER_EVENT_NAME_UPDATE_USER_FRAUD.equals(eventName)) {
            return Optional.empty();
        }

        JsonNode eventDetails = input.path("eventDetails");
        String individualId = eventDetails.path("individualId").asText(null);
        if (individualId == null || individualId.isBlank()) {
            return Optional.empty();
        }

        String subCategory = eventDetails.path("subCategory").asText("");
        if (!OdsNotesConstants.FILTER_FRAUD_SUB_CATEGORIES.contains(subCategory)) {
            return Optional.empty();
        }

        // Determine eventType from subCategory
        String noteEventType;
        if (OdsNotesConstants.FILTER_SUB_CATEGORY_UNLOCK.equals(subCategory)) {
            noteEventType = OdsNotesConstants.EVENT_TYPE_FRAUD_UNLOCK;
        } else {
            noteEventType = OdsNotesConstants.EVENT_TYPE_FRAUD_LOCK;
        }

        // Map clientId → channel
        String clientId = eventDetails.path("clientId").asText("");
        String channel = OdsNotesConstants.FRAUD_CHANNEL_MAP.getOrDefault(clientId, OdsNotesConstants.DATA_DEFAULT_NA);

        // Find userLockedReasonCode from attributes array
        String userLockedReasonCode = null;
        JsonNode attributes = eventDetails.path("attributes");
        if (attributes.isArray()) {
            for (JsonNode attr : attributes) {
                if (OdsNotesConstants.ATTRIBUTE_USER_LOCKED_REASON_CODE.equals(
                        attr.path("attributeName").asText(""))) {
                    userLockedReasonCode = attr.path("attributeValue").asText(null);
                    break;
                }
            }
        }

        String accessId = eventDetails.path("accessId").asText(null);

        Map<String, Object> dataEntry = new HashMap<>();
        dataEntry.put(OdsNotesConstants.DATA_INDIVIDUAL_ID,
                (individualId.isBlank()) ? OdsNotesConstants.DATA_DEFAULT_NA : individualId);
        dataEntry.put(OdsNotesConstants.DATA_USER_ID, accessId);
        dataEntry.put(OdsNotesConstants.DATA_USER_LOCK_TYPE,
                (subCategory.isBlank()) ? OdsNotesConstants.DATA_DEFAULT_NA : subCategory);
        dataEntry.put(OdsNotesConstants.DATA_USER_LOCKED_REASON_CODE, userLockedReasonCode);
        dataEntry.put(OdsNotesConstants.DATA_AGENT_ID,
                eventDetails.path(OdsNotesConstants.DATA_AGENT_ID).asText(null));

        List<Map<String, Object>> data = new ArrayList<>();
        data.add(dataEntry);

        return Optional.of(buildEvent(
                input.path("eventId").asText(null),
                individualId,
                OdsNotesConstants.ID_TYPE_INDIVIDUAL,
                noteEventType,
                channel,
                data
        ));
    }

    /**
     * Common builder — sets domain and compareType consistently across all 3 flows.
     */
    private OdsGenerateNotesEvent buildEvent(String transactionId, String id, String idType,
                                              String eventType, String channel,
                                              List<Map<String, Object>> data) {
        return OdsGenerateNotesEvent.builder()
                .transactionId(transactionId)
                .id(id)
                .idType(idType)
                .domain(OdsNotesConstants.DOMAIN)
                .eventType(eventType)
                .compareType(OdsNotesConstants.COMPARE_TYPE)
                .channel(channel)
                .data(data)
                .build();
    }
}
