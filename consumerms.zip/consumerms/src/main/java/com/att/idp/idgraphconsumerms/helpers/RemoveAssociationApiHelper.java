package com.att.idp.idgraphconsumerms.helpers;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails;
import com.att.idp.idgraphconsumerms.model.RemoveAssociationRequest;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.att.idp.idgraphconsumerms.kafka.errorhandler.ErrorDetailsBuilder;
import com.att.mpsys.common.utils.CErrorDefs;
import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;
import java.util.Map;

@Component
public class RemoveAssociationApiHelper {

    private static final Logger logger = LoggerFactory.getLogger(RemoveAssociationApiHelper.class);
    private static final int MAX_ATTEMPTS = 2;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private CosmosFailedEventsWriter cosmosFailedEventsWriter;

    @Value("${apiclient.rest.ua.serverUrl}")
    private String userAssoServerUrl;

    @Value("${apiclient.rest.ua.removeassociation.endpoint}")
    private String removeAssociationEndpoint;

    @Value("${apiclient.rest.ua.username}")
    private String userName;

    @Value("${apiclient.rest.ua.password}")
    private String userPassword;

    @Retryable(maxAttempts = MAX_ATTEMPTS, include = {HttpServerErrorException.class})
    public void callRemoveAssociationApi(String memberNum, String individualId) {
        String resourceUri = userAssoServerUrl + removeAssociationEndpoint;
        String requestBody = JsonService.getJsonFromObject(new RemoveAssociationRequest(memberNum, individualId));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(ConsumerConstants.Keys.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString((userName + ":" + userPassword).getBytes()));
        headers.add(ConsumerConstants.Keys.X_ATT_CLIENTID, ConsumerConstants.BsseMigration.CLIENT_BSSEMIPAAS);
        headers.add(ConsumerConstants.Keys.IDP_TRACE_ID, MDC.get(ConsumerConstants.Keys.IDP_TRACE_ID));
        HttpEntity<String> httpEntity = new HttpEntity<>(requestBody, headers);

        logger.info("Calling RemoveAssociation API URI: {} with request: {}", resourceUri, requestBody);

        try {
            ResponseEntity<JsonNode> response = restTemplate.exchange(resourceUri, HttpMethod.POST, httpEntity, JsonNode.class);
            logger.info("Response from RemoveAssociation API: {}", sanitizeForLog(response.getBody() != null ? response.getBody().toString() : "null"));
        } catch (HttpServerErrorException e) {
            logger.error("Retryable exception while calling IDGraphUserAssociationMs. {} Will be retried for a max attempts of: {}", e, MAX_ATTEMPTS);
            throw e;
        } catch (Exception e) {
            logger.error("Non-retryable exception received in RemoveAssociation API: {}", e);
            Map<String, String> errorDetails = ErrorDetailsBuilder.builder()
                    .addDetail(ConsumerConstants.ErrorDetails.ERROR_CODE, CErrorDefs.ERR_INVALID_DATA)
                    .addDetail(ConsumerConstants.ErrorDetails.ERROR_MESSAGE, e.getMessage())
                    .addDetail(ConsumerConstants.ErrorDetails.FAILED_ENDPOINT, removeAssociationEndpoint)
                    .addDetail(ConsumerConstants.ErrorDetails.ACCOUNT_TYPE, ConsumerConstants.BsseMigration.INDIVIDUAL_ID)
                    .build();

            FailedEventDetails failedEventDetails = new FailedEventDetails(
                    individualId,
                    JsonService.getJsonFromObject(new RemoveAssociationRequest(memberNum, individualId)),
                    ConsumerConstants.BsseMigration.EVENT_CG_INDIVIDUAL_CLOSE,
                    errorDetails
            );
            cosmosFailedEventsWriter.saveFailedEventsToCosmos(failedEventDetails);
        }
    }

    @Recover
    public void recover(HttpServerErrorException e, String memberNum, String individualId) {
        logger.error("HttpServerErrorException while calling RemoveAssociation API, Exhausted retries: {}", e.getMessage());
        handleFailure(memberNum, individualId, e);
    }

    private void handleFailure(String memberNum, String individualId, Exception e) {
        //store in cosmos db
        logger.error("HttpServerErrorException while calling IDGraphUserAssociationMs, Exhausted retries : {}", e.getMessage());
        Map<String, String> errorDetails = ErrorDetailsBuilder.builder()
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_CODE, CErrorDefs.SYS_ERR)
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_MESSAGE, e.getMessage())
                .addDetail(ConsumerConstants.ErrorDetails.FAILED_ENDPOINT, removeAssociationEndpoint)
                .addDetail(ConsumerConstants.ErrorDetails.ACCOUNT_TYPE, ConsumerConstants.BsseMigration.INDIVIDUAL_ID)
                .build();

        FailedEventDetails failedEventDetails = new FailedEventDetails(
                individualId,
                JsonService.getJsonFromObject(new RemoveAssociationRequest(memberNum, individualId)),
                ConsumerConstants.BsseMigration.EVENT_CG_INDIVIDUAL_CLOSE,
                errorDetails
        );
        cosmosFailedEventsWriter.saveFailedEventsToCosmos(failedEventDetails);
    }

    private static String sanitizeForLog(String input) {
        if (input == null) return null;
        return input.replaceAll("[\\r\\n]", " ");
    }
}