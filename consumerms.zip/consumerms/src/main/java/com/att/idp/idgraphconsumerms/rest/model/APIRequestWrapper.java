package com.att.idp.idgraphconsumerms.rest.model;

import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Wrapper for outgoing API request, failed event details, and API metadata.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class APIRequestWrapper {

    private String outgoingAPIRequestJson;
    private FailedEventDetails failedEventDetails;
    private APIDetails apiDetails;

}
