package com.att.idp.idgraphconsumerms.kafka.dmctn.service;



import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker;
import com.att.idp.idgraphconsumerms.kafka.model.AccountNotificationEvent;
import com.att.idp.idgraphconsumerms.kafka.model.Association;
import com.att.idp.idgraphconsumerms.kafka.model.Subscriber;
import com.att.idp.idgraphconsumerms.model.UserAssociationChangeRequest;
import com.att.idp.idgraphconsumerms.oracle.helpers.MemberServiceDBHelper;
import com.att.idp.idgraphconsumerms.request.validator.RequestValidator;
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;
import com.fasterxml.jackson.databind.JsonNode;
import org.jetbrains.annotations.NotNull;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service("CloseAccountNotificationService")
@RequiredArgsConstructor
public class CloseAccountNotificationService  implements  BaseService<AccountNotificationEvent> {

    private static final Logger logger = LoggerFactory.getLogger(CloseAccountNotificationService.class);


    @Value("${apiclient.rest.ua.removeassociation.endpoint}")
    private String removeAssociationEndpoint;

    private final CosmosFailedEventsWriter cosmosFailedEventsWriter;
    private final GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker;
    private final ApiRestClient apiRestClient;
    private final MemberServiceDBHelper memberServiceDBHelper;

    @Override
    public void execute(AccountNotificationEvent accountNotificationEvent) {
        final String billingAccountNumber = accountNotificationEvent.getBillingAccountNumber();
        final String eventName = ConsumerConstants.GridGddnNotification.EVENT_GDDN_CLOSE_ACCOUNT;

        logger.info("CloseAccountNotificationService execute called for billingAccountNumber: {}",
                ESAPI.encoder().encodeForHTML(billingAccountNumber));

        // Circuit breaker: if pending failed events exist for this account+category,
        // short-circuit directly to Cosmos to preserve sequenced processing order
        if (gddnFailedEventCircuitBreaker.shouldShortCircuit(billingAccountNumber, eventName)) {
            logger.warn("CloseAccountNotificationService: Circuit breaker OPEN for BAN={}. " +
                    "Saving directly to Cosmos without calling downstream API.",
                    ESAPI.encoder().encodeForHTML(billingAccountNumber));
            UserAssociationChangeRequest outgoingRequest = buildOutgoingRequest(accountNotificationEvent, null);
            FailedEventUtil.saveFailedEventCircuitOpen(
                    cosmosFailedEventsWriter,
                    billingAccountNumber,
                    JsonService.getJsonFromObject(outgoingRequest),
                    eventName,
                    CErrorDefs.SYS_ERR,
                    ConsumerConstants.GridGddnNotification.ERROR_CIRCUIT_BREAKER_OPEN,
                    this.removeAssociationEndpoint,
                    ConsumerConstants.AccountNotificationConstants.WIRELESS
            );
            return;
        }

        Optional<String> guidOptional;

        String guid = null;
        UserAssociationChangeRequest outgoingRequest = null ;

        try {
            guidOptional = memberServiceDBHelper.getGuidForGivenBillingAccountNumber(billingAccountNumber);

            if (guidOptional.isEmpty() || guidOptional.get() == null || guidOptional.get().isEmpty()) {
                logger.error("No GUID found for BAN: {}", ESAPI.encoder().encodeForHTML(billingAccountNumber));
                return;
            }

            guid = guidOptional.get();
            logger.info("Retrieved GUID: {} for BAN: {}", ESAPI.encoder().encodeForHTML(guid), ESAPI.encoder().encodeForHTML(billingAccountNumber));

            outgoingRequest = buildOutgoingRequest(accountNotificationEvent, guid);
            apiRestClient.sendPostRequest(removeAssociationEndpoint, outgoingRequest, eventName);
        } catch (Exception e) {
            logger.error("Error retrieving GUID for BAN: {}: {}", billingAccountNumber, e.getMessage());
            outgoingRequest = buildOutgoingRequest(accountNotificationEvent, guid);
            FailedEventUtil.saveFailedEventResolvingCategory(
                    cosmosFailedEventsWriter,
                    billingAccountNumber,
                    JsonService.getJsonFromObject(outgoingRequest),
                    eventName,
                    CErrorDefs.SYS_ERR,
                    e.getMessage(),
                    this.removeAssociationEndpoint,
                    ConsumerConstants.AccountNotificationConstants.WIRELESS
            );
        }
    }

    private static @NotNull UserAssociationChangeRequest buildOutgoingRequest(AccountNotificationEvent accountNotification, String guid) {
        UserAssociationChangeRequest outgoingRequest = new UserAssociationChangeRequest();
        outgoingRequest.setGuid(guid);
        outgoingRequest.setTransactionType(ConsumerConstants.AccountNotificationConstants.CloseAccount);
        Association association = new Association();
        association.setServiceName(ConsumerConstants.AccountNotificationConstants.MOBILITY);
        association.setSorInvariantId(accountNotification.getBillingAccountNumber());
        outgoingRequest.setAssociationList(List.of(association));
        outgoingRequest.setSuppressNotification("N");
        return outgoingRequest;
    }


}