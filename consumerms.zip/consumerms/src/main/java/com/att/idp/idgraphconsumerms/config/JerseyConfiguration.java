package com.att.idp.idgraphconsumerms.config;

import java.util.logging.Logger;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;
import jakarta.ws.rs.ApplicationPath;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.idp.core.config.BaseJerseyConfiguration; // Seed 2.4.0, 'idp-config' new repository in CodeCloud
import com.att.idp.idgraphconsumerms.resource.impl.HelloWorldResourceImpl;
import com.att.idp.idgraphconsumerms.resource.impl.KakfaListenerResourceImpl;
import com.att.idp.shutdown.jersey.adapter.JerseyShutdownAdapter; // Seed 2.5.0, Jersey default shutdown behavior
import com.att.idp.shutdown.jersey.filter.AfterResourceResponseFilter;
import com.att.idp.shutdown.jersey.filter.BeforeResourceRequestFilter;

/**
 * This Class reads and sets all configuration related to Jersey
 * 
 * 
 */
@Component
@ApplicationPath("/idgraphconsumerms/v1")
public class JerseyConfiguration extends BaseJerseyConfiguration {

	
	/*Please do not edit or remove the LOGGER_NAME name declaration as it is critical
	*to have this identifier for server side logging
	*/	
	public final static String LOGGER_NAME="com.att.idp.idgraphconsumerms.logging.server.JerseyLogging";
	private static final Logger log = Logger.getLogger(LOGGER_NAME);

    /**
	 * This is the main constructor which register the Jersey configs
	 * 
	 * @param pJerseyShutdownAdapter
	 *            - added in Seed 2.5.0, will be autowired with
	 *            JerseyShutdownAdapter started by idp-shutdown-jersey module
	 */

	@Autowired
    public JerseyConfiguration(
			@Autowired JerseyShutdownAdapter pJerseyShutdownAdapter) {
		super();
		register(HelloWorldResourceImpl.class);
		register(KakfaListenerResourceImpl.class);
		
		// Seed 2.5.0, filters to count in progress requests:
		register(new BeforeResourceRequestFilter(pJerseyShutdownAdapter));
		register(new AfterResourceResponseFilter(pJerseyShutdownAdapter));
    }

}