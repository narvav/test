package com.att.idp.idgraphconsumerms.kafka.model;

import com.att.idp.idgraph.events.model.JsonSealizable;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PostalAddress implements JsonSealizable {
    @JsonProperty("billingName")
    private String billingName;

    @JsonProperty("address1")
    private String address1;

    @JsonProperty("address2")
    private String address2;

    @JsonProperty("city")
    private String city;

    @JsonProperty("state")
    private String state;

    @JsonProperty("country")
    private String country;

    @JsonProperty("zip5")
    private String zip5;

    @JsonProperty("zip4")
    private String zip4;

}