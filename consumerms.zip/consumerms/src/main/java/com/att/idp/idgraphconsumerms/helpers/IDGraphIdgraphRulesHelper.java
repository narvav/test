package com.att.idp.idgraphconsumerms.helpers;

import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Helper class for IDGRAPH event filtering.
 * Validates that events with eventname {@code LSServicesActivation} are eligible
 * for publishing to the allOtherExtSysNotifications queue.
 */
@Slf4j
@Component
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/consumer.properties")
public class IDGraphIdgraphRulesHelper extends BaseRuleHelper {

    private static final String CLASS_NAME = "IDGraphIdgraphRulesHelper";
    private static final String EVENT_NAME_KEY = "eventname";
    private static final String SOURCE_EVENT_NAME = "LSServicesActivation";

    /**
     * Applies IDGRAPH routing rules.
     * Passes the event through when eventname is {@code LSServicesActivation}.
     *
     * @param event source event data
     * @return true when the event should be published to IDGRAPH destination
     */
    public boolean processIdgraphMessage(Map<String, Object> event) {
        final String sMethodName = ".processIdgraphMessage";
        if (!isValidEventsData(event)) {
            log.info("{}{} IDGIRH.PIM.01: Event payload is empty", CLASS_NAME, sMethodName);
            return false;
        }

        String eventName = event.get(EVENT_NAME_KEY) != null ? event.get(EVENT_NAME_KEY).toString() : null;
        if (!SOURCE_EVENT_NAME.equals(eventName)) {
            log.info("{}{} IDGIRH.PIM.02: Skipping event with name {}",
                    CLASS_NAME,
                    sMethodName,
                    ConsumerUtil.sanitizeForLog(eventName));
            return false;
        }

        log.info("{}{} IDGIRH.PIM.03: Event {} eligible for IDGRAPH publishing",
                CLASS_NAME,
                sMethodName,
                ConsumerUtil.sanitizeForLog(eventName));
        return true;
    }
}

