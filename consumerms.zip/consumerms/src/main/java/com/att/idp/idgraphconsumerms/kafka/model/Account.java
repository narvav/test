package com.att.idp.idgraphconsumerms.kafka.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * The class Account
 *
 */
@Data
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "accountType",
        "accountSor",
        "sorInvariantId",
        "instanceId",
        "entityType",
        "status"
})
public class Account implements JsonSealizable {


    /** The accountType. */
    @JsonProperty("accountType")
    private String accountType;

    /** The accountSor. */
    @JsonProperty("accountSor")
    private String accountSor;

    /** The accountId. */
    @JsonProperty("sorInvariantId")
    private String sorInvariantId;

    /** The instanceId. */
    @JsonProperty("instanceId")
    private String instanceId;

    /** The entityType. */
    @JsonProperty("entityType")
    private String entityType;

    /** The status. */
    @JsonProperty("status")
    private String status;

}
