package com.att.idp.idgraphconsumerms.kafka;

import com.att.idp.idgraphconsumerms.constants.KafkaListenerConstants;
import com.att.idp.idgraphconsumerms.kafka.config.KafkaConsumerProperties;
import com.att.idp.idgraphconsumerms.kafka.config.KafkaConsumersConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.Environment;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.MessageListenerContainer;

import java.util.Map;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class KafkaConsumerAutoStartupRefresher {

    private final KafkaListenerEndpointRegistry kafkaListenerEndpointRegistry;
    private final Environment environment;
    private final KafkaConsumersConfig kafkaConsumersConfig;

    private static final Map<String, String> LISTENER_TO_CONSUMER = Map.ofEntries(
            Map.entry(KafkaListenerConstants.LISTENER_ACCOUNT_NOTIFICATION, KafkaListenerConstants.CONSUMER_ACCOUNT_NOTIFICATION),
            Map.entry(KafkaListenerConstants.LISTENER_SUBSCRIBER_NOTIFICATION, KafkaListenerConstants.CONSUMER_SUBSCRIBER_NOTIFICATION),
            Map.entry(KafkaListenerConstants.LISTENER_PRODUCT_NOTIFICATION, KafkaListenerConstants.CONSUMER_PRODUCT_NOTIFICATION),
            Map.entry(KafkaListenerConstants.LISTENER_EXTERNAL_EVENTS, KafkaListenerConstants.CONSUMER_EXTERNAL_EVENTS),
            Map.entry(KafkaListenerConstants.LISTENER_BSSE_MIGRATION_OAUTH, KafkaListenerConstants.CONSUMER_BSSE_MIGRATION_OAUTH),
            Map.entry(KafkaListenerConstants.LISTENER_BSSE_MIGRATION_INTERNAL, KafkaListenerConstants.CONSUMER_BSSE_MIGRATION_INTERNAL),
            Map.entry(KafkaListenerConstants.LISTENER_BSSE_REVERSE_MIGRATION_OAUTH, KafkaListenerConstants.CONSUMER_BSSE_REVERSE_MIGRATION_OAUTH),
            Map.entry(KafkaListenerConstants.LISTENER_BSSE_REVERSE_MIGRATION_INTERNAL, KafkaListenerConstants.CONSUMER_BSSE_REVERSE_MIGRATION_INTERNAL),
            Map.entry(KafkaListenerConstants.LISTENER_CG_DMCTN, KafkaListenerConstants.CONSUMER_CG_DMCTN),
            Map.entry(KafkaListenerConstants.LISTENER_CG_INDIVIDUAL, KafkaListenerConstants.CONSUMER_CG_INDIVIDUAL),
            Map.entry(KafkaListenerConstants.LISTENER_ORDER_EVENTS, KafkaListenerConstants.CONSUMER_ORDER_EVENTS),
            Map.entry(KafkaListenerConstants.LISTENER_CG_CLOSE_ACCOUNT, KafkaListenerConstants.CONSUMER_CG_CLOSE_ACCOUNT)
    );

    @EventListener(ApplicationReadyEvent.class)
    public void onApplicationReady() {
        log.info("Applying Kafka consumer auto-startup states on application startup");
        applyAllListenerStates();
    }

    @EventListener(RefreshScopeRefreshedEvent.class)
    public void onConfigurationRefresh() {
        log.info("Re-applying Kafka consumer auto-startup states after AppConfig refresh");
        applyAllListenerStates();
    }

    void applyAllListenerStates() {
        log.info("Reconciling Kafka listener auto-startup states");
        LISTENER_TO_CONSUMER.forEach((listenerId, consumerKey) -> {
            try {
                boolean shouldRun = resolveAutoStartup(consumerKey);
                applyListenerState(listenerId, shouldRun);
            } catch (Exception ex) {
                log.error("Failed to reconcile listener '{}'", listenerId, ex);
            }
        });
    }

    boolean getAutoStartupProperty(String propertyName, boolean defaultValue) {
        return environment.getProperty(propertyName, Boolean.class, defaultValue);
    }

    boolean resolveAutoStartup(String consumerKey) {
        Map<String, KafkaConsumerProperties> consumerMap = kafkaConsumersConfig.getConsumer();
        if (consumerMap != null && consumerMap.containsKey(consumerKey)) {
            Boolean configured = consumerMap.get(consumerKey).getAutoStartup();
            if (configured != null) {
                return configured;
            }
        }

        return getAutoStartupProperty(String.format("idgraph.consumer.%s.autoStartup", consumerKey), false);
    }

    void applyListenerState(String listenerId, boolean shouldRun) {
        MessageListenerContainer container = kafkaListenerEndpointRegistry.getListenerContainer(listenerId);
        if (container == null) {
            log.warn("Kafka listener container '{}' not found during AppConfig sync", listenerId);
            return;
        }

        if (shouldRun) {
            if (!container.isRunning()) {
                container.start();
                log.info("Kafka listener '{}' started due to AppConfig autoStartup=true", listenerId);
            } else {
                log.debug("Kafka listener '{}' already running", listenerId);
            }
        } else {
            if (container.isRunning()) {
                container.stop();
                log.info("Kafka listener '{}' stopped due to AppConfig autoStartup=false", listenerId);
            } else {
                log.debug("Kafka listener '{}' already stopped", listenerId);
            }
        }
    }
}
