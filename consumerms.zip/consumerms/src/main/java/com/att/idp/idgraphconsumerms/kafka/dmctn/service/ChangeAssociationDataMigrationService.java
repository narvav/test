package com.att.idp.idgraphconsumerms.kafka.dmctn.service;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker;
import com.att.idp.idgraphconsumerms.kafka.model.Association;
import com.att.idp.idgraphconsumerms.kafka.model.Subscriber;
import com.att.idp.idgraphconsumerms.model.UserAssociationChangeRequest;
import com.att.idp.idgraphconsumerms.oracle.helpers.MemberServiceDBHelper;
import com.att.idp.idgraphconsumerms.oracle.model.MemberServiceResult;
import com.att.idp.idgraphconsumerms.request.validator.RequestValidator;
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;
import org.jetbrains.annotations.NotNull;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class ChangeAssociationDataMigrationService implements BackendService {

    private static final Logger logger = LoggerFactory.getLogger(ChangeAssociationDataMigrationService.class);
    private static final int MAX_ATTEMPTS = 2;

    @Value("${apiclient.rest.ua.changedata.endpoint}")
    private String changeDataEndpoint;

    @Value("${AES256KEY}")
    private String aes256key;

    private final CosmosFailedEventsWriter cosmosFailedEventsWriter;
    private final GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker;
    private final ApiRestClient apiRestClient;
    private final MemberServiceDBHelper memberServiceDBHelper;

    @Autowired
    public ChangeAssociationDataMigrationService(ApiRestClient apiRestClient, MemberServiceDBHelper memberServiceDBHelper,
                                                 CosmosFailedEventsWriter cosmosFailedEventsWriter,
                                                 GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker) {
        this.apiRestClient = apiRestClient;
        this.memberServiceDBHelper = memberServiceDBHelper;
        this.cosmosFailedEventsWriter = cosmosFailedEventsWriter;
        this.gddnFailedEventCircuitBreaker = gddnFailedEventCircuitBreaker;
    }

    @Override
    public void execute(Subscriber subscriber, EventSource eventSource) {

        final String phoneNumber = subscriber.getPhoneNumber();
        final String cgSubscriberId = subscriber.getId();
        final String eventName = (eventSource == EventSource.GDDN) 
            ? ConsumerConstants.GridGddnNotification.EVENT_GDDN_CHANGE_DATA
            : ConsumerConstants.GridGddnNotification.EVENT_CG_CHANGE_DATA;

        logger.info("ChangeAssociationDataMigrationService execute method called for subscriber CTN: {}, subscriber id: {}, source: {}", 
            ESAPI.encoder().encodeForHTML(phoneNumber), ESAPI.encoder().encodeForHTML(cgSubscriberId), eventSource);

        // Circuit breaker: if pending failed events exist for this phone/category,
        // short-circuit directly to Cosmos to preserve sequenced processing order
        if (gddnFailedEventCircuitBreaker.shouldShortCircuit(phoneNumber, eventName)) {
            logger.warn("ChangeAssociationDataMigrationService: Circuit breaker OPEN for CTN={}. "
                            + "Saving directly to Cosmos without calling downstream API.",
                    ESAPI.encoder().encodeForHTML(phoneNumber));
            UserAssociationChangeRequest cbRequest = buildOutgoingRequest(phoneNumber, cgSubscriberId);
            FailedEventUtil.saveFailedEventCircuitOpen(
                    cosmosFailedEventsWriter,
                    phoneNumber,
                    JsonService.getJsonFromObject(cbRequest),
                    eventName,
                    CErrorDefs.SYS_ERR,
                    ConsumerConstants.GridGddnNotification.ERROR_CIRCUIT_BREAKER_OPEN,
                    this.changeDataEndpoint,
                    ConsumerConstants.DmctnSubscriberChangeEvent.TRAN_TYPE_UPDATE_SUBID
            );
            return;
        }

        //We expect that the phone number is always present in the subscriber for this service
        Map<String, Object> validationResult = RequestValidator.validate(phoneNumber, ConsumerConstants.DmctnSubscriberChangeEvent.HEADER_CHANGETYPE_VALUE_PHONENUMBER);

        String statusCode = (String) validationResult.get(MPSDefs.APP_STATUS_CODE);
        if (!CommonDefs.COMMON_SUCCESS.equals(statusCode)) {
            FailedEventUtil.saveFailedEventValidationFailed(
                    cosmosFailedEventsWriter,
                    phoneNumber,
                    JsonService.getJsonFromObject(subscriber),
                    eventName,
                    statusCode,
                    (String) validationResult.get(MPSDefs.APP_STATUS_MSG),
                    ConsumerConstants.ErrorDetails.VALIDATION_FAILED,
                    ConsumerConstants.DmctnSubscriberChangeEvent.TRAN_TYPE_UPDATE_SUBID
            );
            return;
        }

        MemberServiceResult memberServiceResult = null;
        Optional<MemberServiceResult> memberServiceResultOptional;
        UserAssociationChangeRequest outgoingRequest = null;

        try {
            memberServiceResultOptional = memberServiceDBHelper.getOldSubscriptionIdFromInstanceId(subscriber.getPhoneNumber());

            if (memberServiceResultOptional.isEmpty()
                    || memberServiceResultOptional.get().getMemberNum() == null
                    || memberServiceResultOptional.get().getMemberNum().isEmpty()) {
                logger.error("No data found in MPSYS db for CTN: {}, subscriberId: {}",
                        ESAPI.encoder().encodeForHTML(phoneNumber),
                        ESAPI.encoder().encodeForHTML(cgSubscriberId));
                return;
            }
            memberServiceResult = memberServiceResultOptional.get();

            String aesDecodedOldSubscriberId = ConsumerUtil.getAESDecryption(memberServiceResult.getSorInvariantId(),aes256key);
            logger.info("Retrieved GUID: {}, old SubscriberId from DB: {}, for CTN: {}, CG subscriberId: {}, aesDecodedOldSubscriberId: {}", memberServiceResult.getMemberNum(), memberServiceResult.getSorInvariantId(), subscriber.getPhoneNumber(), cgSubscriberId, aesDecodedOldSubscriberId);

            outgoingRequest = buildOutgoingRequest(phoneNumber, cgSubscriberId);
            outgoingRequest.setGuid(memberServiceResult.getMemberNum());
            Association association = outgoingRequest.getAssociationList().get(0);
            association.setOldSorInvariantId(aesDecodedOldSubscriberId);

            apiRestClient.sendPostRequest(changeDataEndpoint, outgoingRequest, eventName);

        } catch (Exception e) {
            logger.error("Error retrieving GUID for CTN: {}: {}", phoneNumber, e.getMessage());
            outgoingRequest = buildOutgoingRequest(phoneNumber, cgSubscriberId);
            FailedEventUtil.saveFailedEventResolvingCategory(cosmosFailedEventsWriter,
                    phoneNumber,
                    JsonService.getJsonFromObject(outgoingRequest),
                    eventName,
                    CErrorDefs.SYS_ERR,
                    e.getMessage(),
                    this.changeDataEndpoint,
                    ConsumerConstants.DmctnSubscriberChangeEvent.TRAN_TYPE_UPDATE_SUBID
            );
        }
    }

    private static @NotNull UserAssociationChangeRequest buildOutgoingRequest(String phoneNumber, String cgSubscriberId) {
        UserAssociationChangeRequest outgoingRequest = new UserAssociationChangeRequest();
        outgoingRequest.setSuppressNotification("Y");
        outgoingRequest.setTransactionType(ConsumerConstants.DmctnSubscriberChangeEvent.TRAN_TYPE_UPDATE_SUBID);


        Association association = new Association();
        association.setServiceName(ConsumerConstants.DmctnSubscriberChangeEvent.MOSUB);
        association.setSorName(ConsumerConstants.DmctnSubscriberChangeEvent.SOR_NAME_MO);
        association.setOldInstanceId(phoneNumber);
        association.setNewSorInvariantId(cgSubscriberId);

        outgoingRequest.setAssociationList(List.of(association));
        return outgoingRequest;
    }
}
