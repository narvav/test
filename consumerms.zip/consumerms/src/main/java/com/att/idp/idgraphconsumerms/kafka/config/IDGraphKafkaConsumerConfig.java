package com.att.idp.idgraphconsumerms.kafka.config;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;

import com.att.idp.idgraphconsumerms.kafka.errorhandler.IDGraphKafkaErrorHandler;

/**
 * Unified Kafka consumer configuration supporting multiple consumers and authentication types.
 */
@EnableKafka
@Configuration
public class IDGraphKafkaConsumerConfig {

    private static final Logger log = LoggerFactory.getLogger(IDGraphKafkaConsumerConfig.class);

    private  KafkaConsumersConfig kafkaConsumersConfig;

    private  Map<String,KafkaConsumerProperties> consumerPropertiesMap;

    public IDGraphKafkaConsumerConfig(KafkaConsumersConfig kafkaConsumersConfig) {
        this.consumerPropertiesMap = kafkaConsumersConfig.getConsumer();
        log.info("Loaded {} consumer configurations", consumerPropertiesMap != null ? consumerPropertiesMap.size() : 0);
    }

    /**
     * Creates a ConsumerFactory for a given consumer name.
     * @param consumerName the logical name of the consumer
     * @return ConsumerFactory
     */
    public ConsumerFactory<String, String> consumerFactory(String consumerName) {
        KafkaConsumerProperties props = getPropsByName(consumerName);
        Map<String, Object> config = new HashMap<>();
        log.info("Creating ConsumerFactory for consumerName={} topic={} bootstrapServers={} groupId={}",
                props.getConsumerName(), props.getTopic(), props.getBootstrapServers(), props.getGroupId());
        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getBootstrapServers());
        config.put(ConsumerConfig.GROUP_ID_CONFIG, props.getGroupId());
        config.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, props.getSecurityProtocol());
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, props.getAutoOffsetReset());
        config.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, props.getMaxPollRecords());
        config.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, props.getMaxPollIntervalMs());
        if (props.getBufferMemory() != null) {
            config.put(ConsumerConfig.RECEIVE_BUFFER_CONFIG, props.getBufferMemory());
        }

        config.put(SaslConfigs.SASL_MECHANISM, props.getSaslMechanism());

        if ("OAUTHBEARER".equalsIgnoreCase(props.getSaslMechanism())) {
            String jaasConfig = props.getSaslJaasConfig();
            if (jaasConfig != null && props.getLogicalCluster() != null && props.getPoolId() != null) {
                jaasConfig = jaasConfig.replaceAll(
                    "extension_logicalCluster\\s*=\\s*[^\\s;]*",
                    "extension_logicalCluster=" + props.getLogicalCluster());
                jaasConfig = jaasConfig.replaceAll(
                    "extension_identityPoolId\\s*=\\s*[^\\s;]*",
                    "extension_identityPoolId=" + props.getPoolId());
            }
            if (jaasConfig != null && !jaasConfig.trim().endsWith(";")) {
                jaasConfig = jaasConfig.trim() + ";";
            }
            log.warn("OAUTHBEARER JAAS config diagnostic for consumerName={}: isNull={}, length={}, containsScope={}, containsUnresolvedPlaceholder={}, logicalCluster={}, poolId={}, autoStartup={}",
                    consumerName,
                    jaasConfig == null,
                    jaasConfig != null ? jaasConfig.length() : 0,
                    jaasConfig != null && jaasConfig.contains("scope"),
                    jaasConfig != null && jaasConfig.contains("${idp-secrets-v1:"),
                    props.getLogicalCluster(),
                    props.getPoolId(),
                    props.getAutoStartup());
            config.put(SaslConfigs.SASL_JAAS_CONFIG, jaasConfig);
            config.put(SaslConfigs.SASL_OAUTHBEARER_TOKEN_ENDPOINT_URL, props.getSaslOauthbearerTokenEndpointUrl());
            config.put(SaslConfigs.SASL_LOGIN_CALLBACK_HANDLER_CLASS, props.getSaslLoginCallbackHandlerClass());
        } else if ("PLAIN".equalsIgnoreCase(props.getSaslMechanism())) {
            String saslJaasConfig = String.format(
                    "org.apache.kafka.common.security.plain.PlainLoginModule required username=\"%s\" password=\"%s\";",
                    props.getSaslJaasUsername(), props.getSaslJaasPwd()
            );
            config.put(SaslConfigs.SASL_JAAS_CONFIG, saslJaasConfig);
        }
        return new DefaultKafkaConsumerFactory<>(config);
    }

    /**
     * Creates a KafkaListenerContainerFactory for a given consumer name.
     * @param consumerName the logical name of the consumer
     * @return ConcurrentKafkaListenerContainerFactory
     */
    public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory(String consumerName) {
        KafkaConsumerProperties props = getPropsByName(consumerName);
        ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory(consumerName));
        factory.setConcurrency(5); // or configurable
        factory.setAutoStartup(Boolean.TRUE.equals(props.getAutoStartup()));
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL_IMMEDIATE);
        factory.setCommonErrorHandler(new IDGraphKafkaErrorHandler());
        if (props.getAuthExceptionRetryInterval() != null) {
            factory.getContainerProperties().setAuthExceptionRetryInterval(Duration.ofSeconds(props.getAuthExceptionRetryInterval()));
        }
        return factory;
    }

    private KafkaConsumerProperties getPropsByName(String consumerName) {
        return consumerPropertiesMap.values().stream()
                .filter(p -> consumerName.equalsIgnoreCase(p.getConsumerName()))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException(
                        ESAPI.encoder().encodeForHTML("No consumer properties found for: " + consumerName)));
    }


    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    @Bean("bsseRevMigOAuthConsumerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, String> bsseRevMigOAuthConsumerContainerFactory() {
        return kafkaListenerContainerFactory("bssereversemigoauth");
    }

    @Bean("accountNotificationConsumerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, String> accountNotificationConsumerContainerFactory() {
        return kafkaListenerContainerFactory("accountnotificationconsumer");
    }

    @Bean("subscriberNotificationConsumerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, String> subscriberNotificationConsumerContainerFactory() {
        return kafkaListenerContainerFactory("subscribernotificationconsumer");
    }

    @Bean("productNotificationConsumerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, String> productNotificationConsumerContainerFactory() {
        return kafkaListenerContainerFactory("productnotificationconsumer");
    }

    @Bean(name = "idgraphExtEventsConsumerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, String> idgraphExtEventsConsumerContainerFactory() {
        return kafkaListenerContainerFactory("idgraphexternalevents");
    }

    @Bean(name = "bsseMigrationOAuthConsumerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, String> bsseMigrationOAuthConsumerContainerFactory() {
        return kafkaListenerContainerFactory("bssemigrationoauth");
    }

    @Bean(name = "cgDmctnOAuthConsumerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, String> cgDmctnOAuthConsumerContainerFactory() {
        return kafkaListenerContainerFactory("cgdmctnoauth");
    }

    @Bean(name = "cgIndividualOAuthConsumerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, String> cgIndividualOAuthConsumerContainerFactory() {
        return kafkaListenerContainerFactory("cgindividualoauth");
    }

    @Bean(name = "cgCloseAccountOAuthConsumerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, String> cgCloseAccountOAuthConsumerContainerFactory() {
        return kafkaListenerContainerFactory("cgcloseaccountoauth");
    }

    @Bean(name = "bsseMigrationOAuthInternalConsumerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, String> bsseMigrationOAuthInternalConsumerContainerFactory() {
        return kafkaListenerContainerFactory("bssemigrationoauthinternal");
    }

    @Bean(name = "bsseRevMigOAuthInternalConsumerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, String> bsseRevMigOAuthInternalConsumerContainerFactory() {
        return kafkaListenerContainerFactory("bssereversemigoauthinternal");
    }

    @Bean("notesOracleEventsConsumerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, String> notesOracleEventsConsumerContainerFactory() {
        return kafkaListenerContainerFactory("notesoracleeventsconsumer");
    }

    @Bean("notesProfileUpdateConsumerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, String> notesProfileUpdateConsumerContainerFactory() {
        return kafkaListenerContainerFactory("notesprofileupdateconsumer");
    }

    @Bean("notesUserIdNotificationsConsumerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, String> notesUserIdNotificationsConsumerContainerFactory() {
        return kafkaListenerContainerFactory("notesuseridnotificationsconsumer");
    }

    @Bean(name = "orderEventsConsumerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, String> orderEventsConsumerContainerFactory() {
        return kafkaListenerContainerFactory("ordereventsconsumer");
    }

}
