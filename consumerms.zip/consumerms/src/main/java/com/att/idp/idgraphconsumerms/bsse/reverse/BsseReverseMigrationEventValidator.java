package com.att.idp.idgraphconsumerms.bsse.reverse;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.kafka.model.ReverseMigratedInboundDataEvent;
import com.att.idp.idgraphconsumerms.request.validator.RequestValidator;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.MPSDefs;

import java.util.Map;

public class BsseReverseMigrationEventValidator {

    private static final String VALID = "VALID";

        /**
         * Validates that sourceBSSEBan, targetTLGBan, and migrationId are not null.
         * @param event the ReverseMigratedInboundDataEvent to validate
         */
    public static String validateRequiredFields(ReverseMigratedInboundDataEvent event) {
        if (event == null) {
            return "Event object must not be null.";
        }

        String sourceBSSEBanError = validateField(event.getSourceBSSEBan(), ConsumerConstants.BsseReverseMigration.SOURCE_BSSE_BAN);
        String targetTLGBanError = validateField(event.getTargetTLGBan(), ConsumerConstants.BsseReverseMigration.TARGET_TLG_BAN);
        String migrationIdError = validateField(event.getMigrationId(), ConsumerConstants.BsseReverseMigration.MIGRATION_ID);
        String accountTypeError = validateField(event.getEvent() != null && event.getEvent().getIdmAttributes() != null
                ? event.getEvent().getIdmAttributes().getAccountType() : null, ConsumerConstants.BsseReverseMigration.ACCOUNT_TYPE);
        String accountSubTypeError = validateField(event.getEvent() != null && event.getEvent().getIdmAttributes() != null
                ? event.getEvent().getIdmAttributes().getAccountSubType() : null, ConsumerConstants.BsseReverseMigration.ACCOUNT_SUB_TYPE);

        if (!VALID.equals(sourceBSSEBanError)) {
            return sourceBSSEBanError;
        }
        if (!VALID.equals(targetTLGBanError)) {
            return targetTLGBanError;
        }
        if (!VALID.equals(migrationIdError)) {
            return migrationIdError;
        }
        if (!VALID.equals(accountTypeError)) {
            return accountTypeError;
        }
        if (!VALID.equals(accountSubTypeError)) {
            return accountSubTypeError;
        }
        return null;
    }
    /**
     * Helper method to validate a field using RequestValidator.
     * @param value the field value
     * @param fieldName the field name
     * @return true if valid, false otherwise
     */
    private static String validateField(String value, String fieldName) {
        Map<String, Object> validationResult = RequestValidator.validate(value, fieldName);
        if (!CommonDefs.COMMON_SUCCESS.equals((String) validationResult.get(MPSDefs.APP_STATUS_CODE))){
            return (String)validationResult.get(MPSDefs.APP_INFO);
        }
        return VALID;
    }
}