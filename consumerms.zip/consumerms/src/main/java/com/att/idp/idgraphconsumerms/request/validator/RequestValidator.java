package com.att.idp.idgraphconsumerms.request.validator;

import com.att.mpsys.common.utils.CErrorDefs;
import com.att.mpsys.common.utils.CommonDefs;
import com.att.mpsys.common.utils.CommonErrorMap;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class RequestValidator {

    private static final Logger logger = LoggerFactory.getLogger(RequestValidator.class);

    private static String sClassName = "RequestValidator";

    public static Map<String, Object> validate(String requestAttribute, String attributeName) {

        String sMethodName = ".validate.";
        Map<String, Object> hmResult = null;

        if (StringUtils.isBlank(requestAttribute)) {
            String errorMessage = "Invalid input: " + attributeName + " is blank or null.";
            logger.info("{}{} :: {}", sClassName, sMethodName, errorMessage);
            hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, errorMessage);
            return hmResult;
        }

        hmResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG);
        return hmResult;
    }
}
