package com.att.idp.idgraphconsumerms.helpers;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.kafka.model.PostalAddress;
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import net.logstash.logback.argument.StructuredArguments;
import com.att.mpsys.common.utils.CommonDefs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Helper service for processing NotificationEvent events.
 * This class provides methods to process notification event details and populate notification input maps.
 * Handles mapping event data to notification models, determines communication modes, and manages notification delivery logic.
 */

@Component
public class UserIDNotificationEventDetailsHelper {

    private static final Logger log = LoggerFactory.getLogger(UserIDNotificationEventDetailsHelper.class);

    private static final String CLASS_NAME = "UserIDNotificationEventDetailsHelper";
    private static final String CTN_ADDED_TO_ACCESSID = "CTN_ADDED_TO_ACCESSID";
    private static final String CTN_REMOVED_FROM_ACCESSID = "CTN_REMOVED_FROM_ACCESSID";
    private static final String CTN_CHANGED_ON_ACCESSID = "CTN_CHANGED_ON_ACCESSID";
    private static final String HS_CBR_CONFIRM = "HS_CBR_CONFIRM";
    private static final String ALL = "ALL";
    private static final String EMAIL = "EMAIL";
    private static final String SMS = "SMS";
    private static final String POSTAL = "POSTAL";
    private static final String AOTN = "AOTN";
    // Billing address field constants
    private static final String BILLING_NAME_FIELD = "BillName";
    private static final String ADDRESS2_FIELD = "Address2";
    private static final String CITY_FIELD = "City";
    private static final String STATE_FIELD = "State";
    private static final String ZIP_CODE_FIELD = "ZipCode";
    private static final String ZIP_PLUS_FOUR_FIELD = "ZipPlusFour";
    private static final String COUNTRY_FIELD = "Country";

    @Autowired
    AttributesHelper attributesHelper;

    /**
     * Populates the CLM input notification map with event and inputMap data.
     * @param event Event data map
     * @param hmClmInputNotification Notification input map to populate
     * @param inputMap Additional input data
     */
    public void populateClmInputNotification(Map<String, Object> event, Map<String, Object> hmClmInputNotification, Map<String, Object> inputMap) {

        final String sMethodName = ".populateClmInputNotification";
        String serviceType = null;
        log.info(
                 "{}{} NEPH.PCINE.01: populateBasicNotificationFields event: {}, hmClmInputNotification: {}, inputMap: {}",
                CLASS_NAME, sMethodName, StructuredArguments.entries(event),
                StructuredArguments.entries(hmClmInputNotification), StructuredArguments.entries(inputMap));

        /* serviceName  */
        if (event.get("serviceType") != null) {
            serviceType = String.valueOf(event.get("serviceType"));
        }
        /* AccountType  */
        if (event.get("AccountType") != null) {
            String acctType = String.valueOf(event.get("AccountType"));
            hmClmInputNotification.put("acctType", acctType);

            // Set sorSystem based on acctType
            if (CommonDefs.TITAN_SERVICE.equalsIgnoreCase(acctType)) {
                hmClmInputNotification.put(ConsumerConstants.SOR_SYSTEM, "LS");
            } else if (CommonDefs.MOBILITY_SERVICE.equalsIgnoreCase(acctType)) {
                hmClmInputNotification.put(ConsumerConstants.SOR_SYSTEM, "MO");
            }
        }

        /* targetSOR */
        String targetSor = (String) event.get("targetSOR");

        Object notificationDataObj = event.get("notificationData");
        Map<String, Object> notificationData =
                notificationDataObj instanceof Map ? (Map<String, Object>) notificationDataObj :
                        (notificationDataObj instanceof List && !((List<?>) notificationDataObj).isEmpty() && ((List<?>) notificationDataObj).get(0) instanceof Map)
                                ? (Map<String, Object>) ((List<?>) notificationDataObj).get(0)
                                : null;

        /* customerType */
        hmClmInputNotification.put(CommonDefs.CUSTOMER_TYPE, getCustomerType(hmClmInputNotification));
        /* fetch IndividualSorInvariantId */
        hmClmInputNotification.put("sIndividualSorInvariantId", event.get("IndividualSorInvariantId"));
         /*  populateBasicNotificationFields */
        log.info("{}{} NEPH.PCINE.02: populateBasicNotificationFields  : ", CLASS_NAME, sMethodName);
        populateBasicNotificationFields(event, hmClmInputNotification, inputMap);

        /* notificationAcctType */
        log.info("{}{} NEPH.PCINE.03: setNotificationAcctType  : ", CLASS_NAME, sMethodName);
        setNotificationAcctType(event, serviceType, hmClmInputNotification);
        serviceType=serviceType!=null?serviceType:(String)hmClmInputNotification.get("serviceType");

        /* entityType */
        log.info("{}{} NEPH.PCINE.04: setEntityTypeBasedOnServiceType  : ", CLASS_NAME, sMethodName);
        setEntityTypeBasedOnServiceType(serviceType, hmClmInputNotification);

        /* Populate account details from services */
        log.info("{}{} NEPH.PCINE.06: populateAccountDetailsFromServices  : ", CLASS_NAME, sMethodName);
        populateAccountDetailsFromServices(event, inputMap, hmClmInputNotification, serviceType);

        log.info("{}{} NEPH.PCINE.07: getTargetSORSystemAttributes  : ", CLASS_NAME, sMethodName);
        getTargetSORSystemAttributes(hmClmInputNotification, targetSor, serviceType);

         /* fetch contactEmail from event notification data */
        log.info("{}{} NEPH.PCINE.08: extractAndPopulateNotificationData  : ", CLASS_NAME, sMethodName);
        extractAndPopulateNotificationData(event, hmClmInputNotification, notificationData);

        /*  getCommunicationMode from event notification data */
        log.info("{}{} NEPH.PCINE.09: getCommunicationMode  : ", CLASS_NAME, sMethodName);
        String communicationMode = getCommunicationMode(hmClmInputNotification, event, notificationData);
        hmClmInputNotification.put("communicationMode", communicationMode);
        log.info("{}{} NEPH.PCINE.10:  communicationMode : {}", CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(communicationMode));

    }

    /**
     * Sets the entityType in the notification input map based on the serviceType.
     * @param serviceType the type of service
     * @param hmClmInputNotification the notification input map to update
     */
    private void setEntityTypeBasedOnServiceType(String serviceType, Map<String, Object> hmClmInputNotification) {
        if (serviceType != null) {
            if (serviceType.equalsIgnoreCase(CommonDefs.MOSUB_SERVICE)) {
                hmClmInputNotification.put("entityType", "Service");
            } else if (
                    serviceType.equalsIgnoreCase(CommonDefs.TITAN_SERVICE)
                            || serviceType.equalsIgnoreCase(CommonDefs.MOBILITY_SERVICE)
                            || serviceType.equalsIgnoreCase(CommonDefs.ECOMM_SERVICE)
            ) {
                hmClmInputNotification.put("entityType", "Account");
            }
        }
    }

    /**
     * Sets the notification account type in the notification input map based on the service type.
     * @param serviceType the type of service
     * @param hmClmInputNotification the notification input map to update
     */
    protected void setNotificationAcctType(Map<String, Object> event, String serviceType, Map<String, Object> hmClmInputNotification) {
        final String sMethodName= "setNotificationAcctType";
        String serviceTypeVal = null;
        String sorName=null;

        if (serviceType != null) {
            serviceTypeVal = getServiceType(serviceType);
        } else if(event.get("sor_name") !=null || event.get("sorName")!=null) {
            sorName= event.get("sor_name")!=null? String.valueOf(event.get("sor_name")):String.valueOf(event.get("sorName"));
            if(sorName.equalsIgnoreCase("LS")) {
                serviceTypeVal = "uverse";
                hmClmInputNotification.put("serviceType", "uverse");
            } else if (sorName.equalsIgnoreCase("MO")) {
                serviceTypeVal = "wireless";
                hmClmInputNotification.put("serviceType", "wireless");
            } else if (sorName.equalsIgnoreCase("CPR")) {
                serviceTypeVal = "wireline";
                hmClmInputNotification.put("serviceType", "wireline");
            }
           }
        hmClmInputNotification.put("notificationAcctType", serviceTypeVal);
        log.info("{}{} NEPH.PCINE.11: notificationAcctType  : {}", CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(serviceTypeVal));
    }

    /**
     * Populates account details in the notification input map from the event's services.
     * Extracts SOR name, service status, service name, SOR invariant ID, and instance ID.
     * Handles both List and Map types for the services object.
     * @param event the event data map containing services
     * @param inputMap additional input data (not used in this method)
     * @param hmClmInputNotification the notification input map to populate
     * @param serviceType the type of service to extract details for
     */
    private void populateAccountDetailsFromServices(Map<String, Object> event, Map<String, Object> inputMap,
                                                                   Map<String, Object> hmClmInputNotification, String serviceType) {

        final String sMethodName= "populateAccountDetailsFromServices";
        Object servicesObj=null;
        
        if (event.get("services") != null) {
            servicesObj= event.get("services");
           } else if (inputMap.get("services") != null) {
            servicesObj = inputMap.get("services");
        }

        Map<String, Object> accountListDetails = new HashMap<>();

        if (servicesObj instanceof List<?> servicesList) {
            for (Object serviceObj : servicesList) {
                if (serviceObj instanceof Map<?, ?> serviceMap) {
                    accountListDetails = populateAccountListDetails((Map<String, Object>) serviceMap, serviceType);
                }
            }
        } else if (servicesObj instanceof Map<?, ?> serviceMap) {
            accountListDetails = populateAccountListDetails((Map<String, Object>) serviceMap, serviceType);
        }
        log.info("{}{} NEPH.PCINE.13:  populateAccountListDetails : {}", CLASS_NAME, sMethodName, StructuredArguments.entries(accountListDetails));

        hmClmInputNotification.put("sorName", accountListDetails.get("sorName"));
        hmClmInputNotification.put("serviceStatus", accountListDetails.get("serviceStatus"));
        hmClmInputNotification.put("serviceName", accountListDetails.get("serviceName"));
        hmClmInputNotification.put("sorInvariantId", accountListDetails.get("sorInvariantId"));
        hmClmInputNotification.put("instanceId", accountListDetails.get("instanceId"));
    }


    /**
     * Populates basic notification fields in the notification input map.
     * Sets transaction ID, original transaction name, calling system ID, browser language, auto-generated indicator,
     * GUID, account ID, owner main CTN, and delegate main CTN.
     * Defaults browser language to EN if not provided or not ES.
     * Defaults auto-generated indicator to "N" if not provided.
     * @param event the event data map containing notification details
     * @param hmClmInputNotification the notification input map to populate
     * @param inputMap the input map containing additional data
     */
    private void populateBasicNotificationFields(Map<String, Object> event,Map<String, Object> hmClmInputNotification,
                                                 Map<String, Object> inputMap) {

        hmClmInputNotification.put(CommonDefs.TRANSACTION_ID, inputMap.get(CommonDefs.TRANSACTION_ID));
        hmClmInputNotification.put(CommonDefs.ORIG_TRANSACTION_NAME, inputMap.get(CommonDefs.TRANSACTION_NAME));
        hmClmInputNotification.put(CommonDefs.CALLING_SYSTEM_ID, inputMap.get(CommonDefs.CALLING_SYSTEM_ID));

        Object browserLanguage = event.get(CommonDefs.BROWSER_LANGUAGE);
        if (browserLanguage != null && "ES".equalsIgnoreCase(browserLanguage.toString())) {
            hmClmInputNotification.put(CommonDefs.BROWSER_LANGUAGE, String.valueOf(browserLanguage));
        } else {
            hmClmInputNotification.put(CommonDefs.BROWSER_LANGUAGE, "EN");
        }

        Object autoGeneratedInd = event.get(CommonDefs.AUTO_GENERATED_IND);
        if (autoGeneratedInd != null && "Y".equalsIgnoreCase(autoGeneratedInd.toString())) {
            hmClmInputNotification.put(CommonDefs.AUTO_GENERATED_IND, String.valueOf(autoGeneratedInd));
        } else {
            hmClmInputNotification.put(CommonDefs.AUTO_GENERATED_IND, "N");
        }

        hmClmInputNotification.put(CommonDefs.GUID, getGUID(event, inputMap));
        hmClmInputNotification.put(CommonDefs.KEY_ACCOUNT_ID, getAccountID(event, inputMap));
        hmClmInputNotification.put("AccountLast4", getAccountLast4(event, inputMap));

        Object ownerMainCtn = event.get(CommonDefs.KEY_OWNER_MAIN_CTN);
        if (ownerMainCtn != null) {
            hmClmInputNotification.put(CommonDefs.KEY_OWNER_MAIN_CTN, String.valueOf(ownerMainCtn));
        }

        Object delegateMainCtn = event.get(CommonDefs.KEY_DELEGATE_MAIN_CTN);
        if (delegateMainCtn != null) {
            hmClmInputNotification.put(CommonDefs.KEY_DELEGATE_MAIN_CTN, String.valueOf(delegateMainCtn));
        }
        if(event.get("roleType")!=null)
            hmClmInputNotification.put("roleType", event.get("roleType"));
    }

    /**
     * Returns the normalized service type value for notification account type.
     * Maps known service types to their corresponding notification account type string.
     * @param serviceType the type of service (e.g., MOBILITY, MOSUB, TITAN, UVERSE, ECOMM)
     * @return the normalized service type value: "wireless", "uverse", "wireline", or "NA" if unknown
     */
    private String getServiceType(String serviceType) {
        String serviceTypeValue = null;
        if(serviceType!=null) {
            if (serviceType.equalsIgnoreCase(CommonDefs.MOBILITY_SERVICE) || serviceType.equalsIgnoreCase(CommonDefs.MOSUB_SERVICE)) {
                serviceTypeValue = "wireless";
            } else if (serviceType.equalsIgnoreCase(CommonDefs.TITAN_SERVICE) || serviceType.equalsIgnoreCase(CommonDefs.UVERSE_SERVICE)) {
                serviceTypeValue = "uverse";
            } else if (serviceType.equalsIgnoreCase("ECOMM")) {
                serviceTypeValue = "wireline";
            }
        }
        return serviceTypeValue;
    }

    /**
     * Populates account details from the provided service map and service type.
     * Extracts SOR name, service status, service name, SOR invariant ID, and instance ID.
     * Handles both nested and flat service map structures.
     * @param serviceMap the map containing service details
     * @param serviceType the type of service to extract details for
     * @return a map containing sorName, serviceName, instanceId, sorInvariantId, and serviceStatus
     */
    private Map<String, Object> populateAccountListDetails(Map<String, Object> serviceMap, String serviceType) {

    Map<String, Object> details = new HashMap<>();
        String sorName = null;
        String serviceName = null;
        String instanceId = null;
        String sorInvariantId = null;
        String serviceStatus = null;

          if(serviceMap.containsKey(serviceType)) {
              for (Map.Entry<String, Object> topEntry : serviceMap.entrySet()) {
                  if (topEntry.getKey().equals(serviceType)) {
                      Object topValue = topEntry.getValue();
                      Map<String, Object> nestedByInstanceId = (Map<String, Object>) topValue;
                        for (Object nestedEntryObj : nestedByInstanceId.entrySet()) {
                            Map.Entry<String, Object> nestedEntry = (Map.Entry<String, Object>) nestedEntryObj;
                            Object innerValue = nestedEntry.getValue();

                             if (innerValue instanceof Map<?, ?>) {
                                  Map<String, Object> innerDetails = (Map<String, Object>) innerValue;

                              if (sorName == null && innerDetails.get("sor_name") instanceof String) {
                                  sorName = (String) innerDetails.get("sor_name");
                              }
                              if (serviceName == null && innerDetails.get("service_name") instanceof String) {
                                  serviceName = (String) innerDetails.get("service_name");
                              }
                              if (instanceId == null && innerDetails.get("instance_id") instanceof String) {
                                  instanceId = (String) innerDetails.get("instance_id");
                              }
                              if (sorInvariantId == null && innerDetails.get(ConsumerConstants.SOR_INVARIANT_ID) instanceof String) {
                                  sorInvariantId = (String) innerDetails.get(ConsumerConstants.SOR_INVARIANT_ID);
                              }
                              if (serviceStatus == null && innerDetails.get("service_status") instanceof String) {
                                  serviceStatus = (String) innerDetails.get("service_status");
                              }
                          }
                      }
                  }
              }
          }else if (serviceMap.get("serviceType")!=null &&
                  serviceMap.get("serviceType").equals(serviceType)) {

                  if( serviceMap.get("serviceType")!=null) {
                      serviceName = (String) serviceMap.get("serviceType");

                  } if(serviceMap.get(ConsumerConstants.SOR_INVARIANT_ID)!=null) {
                      sorInvariantId = (String) serviceMap.get(ConsumerConstants.SOR_INVARIANT_ID);
                  } else if(serviceMap.get("sorInvariantId")!=null) {
                      sorInvariantId = (String) serviceMap.get("sorInvariantId");
                  }

                  if(serviceMap.get("instance_id")!=null) {
                      instanceId = (String) serviceMap.get("instance_id");
                  }else if(serviceMap.get("instanceId")!=null) {
                      instanceId = (String) serviceMap.get("instanceId");

                  } if(serviceMap.get("sor_name")!=null) {
                      sorName = (String) serviceMap.get("sor_name");
                    } else if(serviceMap.get("sorName")!=null) {
                        sorName = (String) serviceMap.get("sorName");
                  }

                  if(serviceMap.get("service_status")!=null) {
                      serviceStatus = (String) serviceMap.get("service_status");
                  }else if(serviceMap.get("serviceStatus")!=null) {
                      serviceStatus = (String) serviceMap.get("serviceStatus");
                  }
              }

        details.put("sorName", sorName);
        details.put("serviceName", serviceName);
        details.put("instanceId", instanceId);
        details.put("sorInvariantId", sorInvariantId);
        details.put("serviceStatus", serviceStatus);
        return details;
    }

    /**
     * Determines the customer type based on the accountType in the notification input map.
     * Returns "B" for business types and "R" for residential.
     * @param hmClmInputNotification the notification input map containing accountType
     * @return "B" if accountType is a business type, otherwise "R"
     */
    private String getCustomerType(Map<String, Object> hmClmInputNotification) {
        String accountType = hmClmInputNotification != null && hmClmInputNotification.get("accountType") != null
                ? (String) hmClmInputNotification.get("accountType") : "";
        Set<String> businessTypes = Set.of(
                "WRLS", "GOV", "COIN", "Toll", "BUS", "DA", "B", "E", "G", "S", "T", "C"
        );
        return businessTypes.contains(accountType) ? "B" : "R";
    }

    /**
     * Determines the communication mode (EMAIL, SMS, POSTAL, etc.) for a notification event.
     * @param hmClmInputNotification the notification input map containing notification attributes
     * @param event the event data map
     * @return the communication mode as a String (e.g., EMAIL, SMS, POSTAL, EMAIL,SMS, etc.)
     */
    public String getCommunicationMode(Map<String, Object> hmClmInputNotification, Map<String, Object> event, Map<String, Object> notificationData) {
        String commMode=null;
        String isCPNINotification = (String) hmClmInputNotification.get("isCPNINotification");
        if ("true".equalsIgnoreCase(isCPNINotification)){
            commMode="ALL";
        }else {

            Map<String, Object> deliveryDetails = getDeliveryMethods(event, notificationData);

            String stContactEmail = deliveryDetails.get("contactEmail") != null ? (String) deliveryDetails.get("contactEmail") : null;
            String stContactEmailStatus = deliveryDetails.get("contactEmailStatus") != null ? (String) deliveryDetails.get("contactEmailStatus") : null;
            String stCTN = deliveryDetails.get("ctn") != null ? (String) deliveryDetails.get("ctn") : null;
            String aoTN = deliveryDetails.get("aoTN") != null ? (String) deliveryDetails.get("aoTN") : null;
            String cPNIEligibleMobileNumber = notificationData != null && notificationData.get("CPNIEligibleMobileNumber") instanceof String ? (String) notificationData.get("CPNIEligibleMobileNumber") : null;

            PostalAddress postalAddress = (PostalAddress) deliveryDetails.get("postalAddress");
            if (postalAddress != null) {
                populatePostalAddressFields(hmClmInputNotification, postalAddress);
            }

            String cType = (String) hmClmInputNotification.get("cType");
            boolean isEmailValidation = ConsumerConstants.EML_ADDR_VALIDATION.equals(cType);

            if (stContactEmail != null && (isEmailValidation || "V".equals(stContactEmailStatus))) {
                hmClmInputNotification.put("emailAddress",stContactEmail);
                if (stCTN == null && aoTN == null && postalAddress == null) {
                    commMode = EMAIL;
                } else {
                    commMode = ALL;
                }
            } else {
               if ((stCTN != null && aoTN == null && postalAddress == null) ||cPNIEligibleMobileNumber!=null) {
                    commMode = SMS;
                } else if (stCTN == null && aoTN != null && postalAddress == null) {
                    commMode = AOTN;
                }  else if (stCTN == null && aoTN == null && postalAddress != null) {
                    commMode = POSTAL;
                } else {
                   commMode = ALL;
               }
            }
        }
        return commMode;
    }

    /**
     * Extracts notification data fields (contact email, CTN, postal address, etc.) from the event map.
     * @param event the event data map
     * @return a map containing extracted fields: stContactEmail, stContactEmailStatus, stCTN, postalAddress
     */
    public Map<String, Object> getDeliveryMethods( Map<String, Object> event, Map<String, Object> notificationData) {
        String stCTN = null;
        PostalAddress postalAddress = null;

        Map<String, String> contactEmailDetails = extractContactEmailDetails(event,notificationData);

        String stContactEmail = contactEmailDetails.get("contactEmail");
        String stContactEmailStatus = contactEmailDetails.get("contactEmailStatus");
        if (!notificationData.isEmpty()) {
            String addCtnValue = notificationData.get("addCTN") instanceof String addCtn ? addCtn : "";
            stCTN = addCtnValue.isEmpty() ? null : addCtnValue;

        }

        if (!notificationData.isEmpty() && notificationData.containsKey("billingAddress")) {
            Object billingAddressObj = notificationData.get("billingAddress");
            if (billingAddressObj instanceof Map) {
                Map<String, Object> billingAddress = (Map<String, Object>) billingAddressObj;
                // Extract postal address information from billingAddress
                postalAddress = extractPostalAddressFromBilling(billingAddress);
            }
        }
        Map<String, Object> result = new HashMap<>();
        result.put("contactEmail", stContactEmail);
        result.put("contactEmailStatus", stContactEmailStatus);
        result.put("ctn", stCTN);
        result.put("postalAddress", postalAddress);
        return result;
    }



    /**
     * Extracts postal address information from billing address data.
     * @param billingAddress the billing address map containing address fields
     * @return PostalAddress object if valid data exists, null otherwise
     */
    private PostalAddress extractPostalAddressFromBilling(Map<String, Object> billingAddress) {
        if (billingAddress == null || billingAddress.isEmpty()) {
            return null;
        }

        String billName = getStringValue(billingAddress, BILLING_NAME_FIELD);
        String address2 = getStringValue(billingAddress, ADDRESS2_FIELD);
        String city = getStringValue(billingAddress, CITY_FIELD);
        String state = getStringValue(billingAddress, STATE_FIELD);
        String zipCode = getStringValue(billingAddress, ZIP_CODE_FIELD);
        String zipPlusFour = getStringValue(billingAddress, ZIP_PLUS_FOUR_FIELD);
        String country = getStringValue(billingAddress, COUNTRY_FIELD);

        // Only create PostalAddress if at least one essential field has data
        if (hasValidAddressData(billName, address2, city, state, zipCode)) {
            return PostalAddress.builder()
                    .billingName(billName)
                    .address2(address2)
                    .city(city)
                    .state(state)
                    .zip5(zipCode)
                    .zip4(zipPlusFour)
                    .country(country)
                    .build();
        }

        return null;
    }

    /**
     * Safely extracts string value from map.
     * @param map the source map
     * @param key the key to extract
     * @return string value or null if not present or not a string
     */
    private String getStringValue(Map<String, Object> map, String key) {
        Object value = map.get(key);
        return value instanceof String ? (String) value : null;
    }

    /**
     * Validates if address data contains at least one non-null, non-empty essential field.
     * @param billName billing name
     * @param address2 street address
     * @param city city
     * @param state state
     * @param zipCode zip code
     * @return true if valid address data exists
     */
    private boolean hasValidAddressData(String billName, String address2, String city, String state, String zipCode) {
        return isNotBlank(billName) || isNotBlank(address2) || isNotBlank(city) || 
               isNotBlank(state) || isNotBlank(zipCode);
    }

    /**
     * Checks if string is not null and not empty after trimming.
     * @param str string to check
     * @return true if string has content
     */
    private boolean isNotBlank(String str) {
        return str != null && !str.trim().isEmpty();
    }

    /**
     * Sets notification system attributes (isBSSE, serviceType, billingSystem) based on targetSOR and serviceType.
     * @param hmClmInputNotification the notification input map to populate
     * @param targetSor the target SOR value
     * @param serviceType the service type value
     */
    private void getTargetSORSystemAttributes(Map<String, Object> hmClmInputNotification, String targetSor, String serviceType) {

         String acctType= (String) hmClmInputNotification.get("acctType");
        
         if ("CG".equalsIgnoreCase(targetSor)) {
            hmClmInputNotification.put("isBSSE", "true");
            hmClmInputNotification.put("serviceType", "wireless");
            hmClmInputNotification.put("billingSystem", "RTB");
        } else if ("TELEGANCE-DB".equalsIgnoreCase(targetSor)) {
            hmClmInputNotification.put("isBSSE", "false");
            hmClmInputNotification.put("serviceType", "wireless");
            hmClmInputNotification.put("billingSystem", "TLG");
        } else if ("LS-CRM-DB".equalsIgnoreCase(targetSor)) {
            hmClmInputNotification.put("isBSSE", "false");
            hmClmInputNotification.put("serviceType", "uverse");
            hmClmInputNotification.put("billingSystem", "ENB");
        } else if (targetSor == null || targetSor.isEmpty()) {
            hmClmInputNotification.put("isBSSE", "false");
            if(serviceType != null || acctType != null) {
                if(isMobilityOrMosubService(serviceType, acctType)) {
                    hmClmInputNotification.put("serviceType", "wireless");
                    hmClmInputNotification.put("billingSystem", "TLG");
                } else if(isTitanOrUverseService(serviceType, acctType)) {
                    hmClmInputNotification.put("billingSystem", "ENB");
                    hmClmInputNotification.put("serviceType", "uverse");
                } else if (CommonDefs.ECOMM_SERVICE.equalsIgnoreCase(serviceType)) {
                    hmClmInputNotification.put("billingSystem", "ENB");
                    hmClmInputNotification.put("serviceType", "wireline");
                }
            }
        }
    }
    /**
     * Extracts notification data fields from the event and populates the notification input map.
     * @param event the event data map
     * @param hmClmInputNotification the notification input map to populate
     */
    private void extractAndPopulateNotificationData(Map<String, Object> event, Map<String, Object> hmClmInputNotification, Map<String, Object> notificationData) {

        String sMethodName = ".extractAndPopulateNotificationData";
        String ownerSLID = "";

        Object notificationDataObj = event.get("notificationData");
        // Handle notificationDataObj as a List of Maps
        List<Map<String, Object>> notificationDataList = notificationDataObj instanceof List
                ? (List<Map<String, Object>>) notificationDataObj
                : Collections.emptyList();

        for (Map<String, Object> notificationEntry : notificationDataList) {
            if (notificationEntry != null && notificationEntry.containsKey("ownerSLID")) {
                ownerSLID = (String) notificationEntry.get("ownerSLID");
                break;
            }
        }
        if (ownerSLID == null || ownerSLID.isEmpty()) {
            ownerSLID = (String) event.get("slid");
        }
        hmClmInputNotification.put("ownerSLID", ownerSLID);

       String secondaryAccessGranted = notificationData != null && notificationData.get("secondaryAccessGranted") instanceof String ? (String) notificationData.get("secondaryAccessGranted") : null;
        hmClmInputNotification.put("secondaryAccessGranted", secondaryAccessGranted);

        String defaultAccountChanged = notificationData != null && notificationData.get("defaultAccountChanged") instanceof String ? (String) notificationData.get("defaultAccountChanged") : null;
        hmClmInputNotification.put("defaultAccountChanged", defaultAccountChanged);

        String primaryEmailChanged = notificationData != null && notificationData.get("primaryEmailChanged") instanceof String ? (String) notificationData.get("primaryEmailChanged") : null;
        hmClmInputNotification.put("primaryEmailChanged", primaryEmailChanged);

        String addCTN = notificationData != null && notificationData.get("addCTN") instanceof String ? (String) notificationData.get("addCTN") : null;
        String deleteMainCTN = notificationData != null && notificationData.get("deleteMainCTN") instanceof String ? (String) notificationData.get("deleteMainCTN") : null;
        String changeMainCTN = notificationData != null && notificationData.get("changeMainCTN") instanceof String ? (String) notificationData.get("changeMainCTN") : null;
        String oldMainCTN = notificationData != null && notificationData.get("oldMainCTN") instanceof String ? (String) notificationData.get("oldMainCTN") : null;
        String encryptedKey= notificationData != null && notificationData.get(ConsumerConstants.ENCRYPTED_KEY) instanceof String ? (String) notificationData.get(ConsumerConstants.ENCRYPTED_KEY) : null;
        hmClmInputNotification.put(ConsumerConstants.ENCRYPTED_KEY, encryptedKey);
        String cPNIEligibleMobileNumber = notificationData != null && notificationData.get("CPNIEligibleMobileNumber") instanceof String ? (String) notificationData.get("CPNIEligibleMobileNumber") : null;
        String cType = (String) hmClmInputNotification.get("cType");
        switch (cType) {
            case CTN_ADDED_TO_ACCESSID:
                if (addCTN != null) {
                    hmClmInputNotification.put("mainCTN", addCTN);
                }
                break;
            case CTN_REMOVED_FROM_ACCESSID:
                if (deleteMainCTN != null) {
                    hmClmInputNotification.put("mainCTN", deleteMainCTN);
                }
                break;
            case CTN_CHANGED_ON_ACCESSID:
                if (changeMainCTN != null) {
                    hmClmInputNotification.put("mainCTN", changeMainCTN);
                    if (oldMainCTN != null) {
                        hmClmInputNotification.put("oldMainCTN", oldMainCTN);
                    }
                }
                break;
            case HS_CBR_CONFIRM:
                if (cPNIEligibleMobileNumber != null) {
                    hmClmInputNotification.put("mainCTN", cPNIEligibleMobileNumber);
                }
                break;

            default:
                // No action needed
                break;
        }
    }

    /**
     * Extracts contact email and status from notificationData in the event.
     * @param event the event data map
     * @return a map containing contactEmail and contactEmailStatus
     */
    private Map<String, String> extractContactEmailDetails(Map<String, Object> event, Map<String, Object> notificationData) {

        String contactEmail = null;
        String contactEmailStatus = null;
        Object memberContactEmailObj = null;
        if (!notificationData.isEmpty()) {
                memberContactEmailObj = notificationData.get("memberContactEmail");
            if (memberContactEmailObj instanceof List) {
                List<Map<String, Object>> emailList = (List<Map<String, Object>>) memberContactEmailObj;
                for (Map<String, Object> emailMap : emailList) {
                    if (emailMap.containsKey("contactEmail") && emailMap.containsKey("contactEmailStatus")) {
                        contactEmail = emailMap.get("contactEmail") instanceof String
                                ? (String) emailMap.get("contactEmail")
                                : null;
                        contactEmailStatus = emailMap.get("contactEmailStatus") instanceof String
                                ? (String) emailMap.get("contactEmailStatus")
                                : null;
                        break;
                    }
                }
            } else {
                if (memberContactEmailObj instanceof String) {
                    contactEmail = (String) memberContactEmailObj;
                }
            }
        }
        Map<String, String> result = new HashMap<>();
        result.put("contactEmail", contactEmail);
        result.put("contactEmailStatus", contactEmailStatus);
        return result;
    }
/**
 * Determines the GUID value based on event and inputMap.
 * @param event Event data map
 * @param inputMap Additional input data
 * @return GUID value as String
 */
private String getGUID(Map<String, Object> event, Map<String, Object> inputMap) {

    if (event.get(CommonDefs.MEMBER_NUM) != null ) {
            return String.valueOf(event.get(CommonDefs.MEMBER_NUM));
        } else if( event.get(CommonDefs.DB_MEMBER_NUM) != null) {
        return String.valueOf(event.get(CommonDefs.DB_MEMBER_NUM));
    }
    return null;
}
/**
 * Retrieves the Account ID from the event or inputMap.
 * Checks multiple sources and falls back to a default if not found.
 * @param event Event data map
 * @return Account ID as String
 */
private String getAccountID(Map<String, Object> event, Map<String, Object> inputMap) {

    Object servicesObj = null;
    if (event.get(CommonDefs.KEY_ACCOUNT_ID) != null
            || event.get("accountId") != null
            || event.get("accountID") != null) {
        return String.valueOf(event.get(CommonDefs.KEY_ACCOUNT_ID));

    } else if (event.get("sorInvariantId") != null
            && String.valueOf(event.get("sorInvariantId")).matches("\\d+")) {
        return String.valueOf(event.get("sorInvariantId"));

    }else if (event.containsKey("services") && event.get("services") != null) {
        if (event.get("services") != null) {
            servicesObj = event.get("services");
        }

     if (servicesObj instanceof List<?> servicesList) {
            for (Object serviceObj : servicesList) {
                if (serviceObj instanceof Map<?, ?> serviceMap) {
                    String serviceTypeValue = (String) serviceMap.get("serviceType");
                    if ("MOBILITY".equalsIgnoreCase(serviceTypeValue)
                            || "ECOMM".equalsIgnoreCase(serviceTypeValue)
                            || "TITAN".equalsIgnoreCase(serviceTypeValue)) {
                        if (serviceMap.get("sorInvariantId") != null) {
                            return String.valueOf(serviceMap.get("sorInvariantId"));
                        } else if (serviceMap.get(ConsumerConstants.SOR_INVARIANT_ID) != null) {
                            return String.valueOf(serviceMap.get(ConsumerConstants.SOR_INVARIANT_ID));
                        }
                    }
                }
            }
        }
    }
    return "0000000000000";
    }
    /**
     * Populates postal address related fields in the notification map.
     * @param hmClmInputNotification the notification input map to populate
     * @param postalAddress the event data map
     */
    private void populatePostalAddressFields(Map<String, Object> hmClmInputNotification, PostalAddress postalAddress) {
        if (postalAddress.getBillingName() != null) {
            hmClmInputNotification.put("billingName", postalAddress.getBillingName());
        }
        if (postalAddress.getAddress1() != null) {
            hmClmInputNotification.put(CommonDefs.ADDRESS1, postalAddress.getAddress1());
        }
        if (postalAddress.getAddress2() != null) {
            hmClmInputNotification.put(CommonDefs.ADDRESS2, postalAddress.getAddress2());
        }
        if (postalAddress.getCity() != null) {
            hmClmInputNotification.put(CommonDefs.CITY, postalAddress.getCity());
        }
        if (postalAddress.getState() != null) {
            hmClmInputNotification.put(CommonDefs.STATE, postalAddress.getState());
        }
        if (postalAddress.getCountry() != null) {
            hmClmInputNotification.put(CommonDefs.COUNTRY, postalAddress.getCountry());
        }
        if (postalAddress.getZip4() != null) {
            hmClmInputNotification.put(CommonDefs.ZIP4, postalAddress.getZip4());
        }
        if (postalAddress.getZip5() != null) {
            hmClmInputNotification.put("zip5", postalAddress.getZip5());
        }
    }

    /**
     * Checks if the service type or account type is TITAN or UVERSE.
     * @param serviceType the service type to check
     * @param acctType the account type to check
     * @return true if either serviceType or acctType is TITAN or UVERSE, false otherwise
     */
    private boolean isTitanOrUverseService(String serviceType, String acctType) {
        return CommonDefs.TITAN_SERVICE.equalsIgnoreCase(serviceType)
                || CommonDefs.UVERSE_SERVICE.equalsIgnoreCase(serviceType)
                || CommonDefs.TITAN_SERVICE.equalsIgnoreCase(acctType)
                || CommonDefs.UVERSE_SERVICE.equalsIgnoreCase(acctType);
    }

    private boolean isMobilityOrMosubService(String serviceType, String acctType) {
        return CommonDefs.MOBILITY_SERVICE.equalsIgnoreCase(serviceType)
                || CommonDefs.MOSUB_SERVICE.equalsIgnoreCase(serviceType)
                || CommonDefs.MOBILITY_SERVICE.equalsIgnoreCase(acctType)
                || CommonDefs.MOSUB_SERVICE.equalsIgnoreCase(acctType);
    }


    /**
     * Returns the last 4 digits of the Account ID, or the full Account ID if it is 4 characters or less.
     * @param event the event data map
     * @param inputMap the input map containing additional data
     * @return the last 4 digits of the Account ID as a String, or the full Account ID if shorter
     */

    private String getAccountLast4(Map<String, Object> event, Map<String, Object> inputMap){
        String AccountID = getAccountID(event, inputMap);
        return AccountID.length() > 4 ? AccountID.substring(AccountID.length() - 4, AccountID.length()) : AccountID;
    }

}


