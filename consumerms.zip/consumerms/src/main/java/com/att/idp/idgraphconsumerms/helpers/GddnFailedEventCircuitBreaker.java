package com.att.idp.idgraphconsumerms.helpers;

import com.att.idp.idgraph.db.cosmos.helper.CosmosFailedEventsDBHelper;
import com.att.idp.idgraphconsumerms.utils.EventCategoryResolver;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * Circuit breaker for GDDN failed events.
 * <p>
 * Before a GDDN notification service calls its downstream API, this component checks
 * whether there are already pending failed events for the same (accountNumber, eventCategory).
 * If pending events exist, the new event must be short-circuited directly to Cosmos DB
 * to preserve ordering — the batch coordinator will replay them in sequence.
 * </p>
 * <p>
 * For non-GDDN events (no mapped category), this always returns false (no short-circuit).
 * </p>
 */
@Component
@RequiredArgsConstructor
public class GddnFailedEventCircuitBreaker {

    private static final Logger logger = LoggerFactory.getLogger(GddnFailedEventCircuitBreaker.class);
    private static final String CLASS_NAME = "GddnFailedEventCircuitBreaker";

    private final CosmosFailedEventsDBHelper cosmosFailedEventsDBHelper;

    /**
     * Checks if the downstream API call should be short-circuited for the given event.
     *
     * @param accountNumber the account number from the incoming event
     * @param eventName     the GDDN event name (e.g., CloseAccount)
     * @return {@code true} if there are pending failed events and the call should be
     *         short-circuited to Cosmos; {@code false} if safe to proceed with the API call
     */
    public boolean shouldShortCircuit(String accountNumber, String eventName) {
        Optional<String> categoryOpt = EventCategoryResolver.resolve(eventName);
        if (categoryOpt.isEmpty()) {
            // Non-GDDN event — no circuit breaker needed
            return false;
        }

        String eventCategory = categoryOpt.get();
        try {
            boolean hasPending = cosmosFailedEventsDBHelper.hasPendingFailedEvents(accountNumber, eventCategory);
            if (hasPending) {
                logger.warn("{} CB_01 : Circuit OPEN — pending failed events exist for account={}, category={}. " +
                                "Short-circuiting to Cosmos to preserve ordering.",
                        CLASS_NAME,
                        ESAPI.encoder().encodeForHTML(accountNumber),
                        ESAPI.encoder().encodeForHTML(eventCategory));
            }
            return hasPending;
        } catch (RuntimeException e) {
            // Fail-open: if the circuit breaker check itself fails (Cosmos unavailable),
            // return false and proceed with the API call — don't block the service.
            // Per design doc §Phase 7 Item 7.4: "Fail-open semantics"
            logger.error("{}CB_02 : Circuit breaker check failed for account={}, category={}. " +
                            "Defaulting to CLOSED (fail-open) — proceeding with API call: {}",
                    CLASS_NAME,
                    ESAPI.encoder().encodeForHTML(accountNumber),
                    ESAPI.encoder().encodeForHTML(eventCategory),
                    ESAPI.encoder().encodeForHTML(String.valueOf(e.getMessage())), e);
            return false;
        }
    }
}
