package com.att.idp.idgraphconsumerms.helpers;

import com.att.idp.idgraph.events.model.Attribute;
import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.mpsys.common.utils.CommonDefs;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Utility class for populating account-related attributes in notification input maps.
 * Extracted from UserIDNotificationEventDetailsHelper for reuse and clarity.
 */
@Component
public class AttributesHelper {

    // Attribute name constants
    private static final String ATTR_MAIN_CTN = "mainCTN";
    private static final String ATTR_MAIN_CTN_PREV = "mainCTNprev";
    private static final String ATTR_FIRST_NAME_OWN = "FirstNameOwn";
    private static final String ATTR_LAST_NAME_OWN = "LastNameOwn";
    private static final String ATTR_FIRST_NAME_SEC = "FirstNameSec";
    private static final String ATTR_LAST_NAME_SEC = "LastNameSec";
    private static final String ATTR_ACCESS_ID_OWN = "AccessIdOwn";
    private static final String ATTR_ACCESS_ID_SEC = "AccessIdSec";
    private static final String ATTR_ACCESS_ID_SEC_LOWER = "accessIdSec";
    private static final String ATTR_NOTIFICATION_ACCT_TYPE = "notificationAcctType";
    private static final String ATTR_NOTIFICATION_ACCOUNT_TYPE = "notificationAccountType";
    private static final String ATTR_FIRST_NAME = "FirstName";
    private static final String ATTR_LAST_NAME = "LastName";
    private static final String FIRST_NAME = "firstName";
    private static final String LAST_NAME = "lastName";
    private static final String ATTR_LONG_URL = "longUrl";
    private static final String ATTR_QAR_KEY = "qarKey";
    private static final String ATTR_OWNER_FIRST_NAME = "ownerFirstName";
    private static final String ATTR_OWNER_LAST_NAME = "ownerLastName";
    private static final String ATTR_DELEGATE_FIRST_NAME = "delegateFirstName";
    private static final String ATTR_DELEGATE_LAST_NAME = "delegateLastName";
    private static final String ATTR_DELEGATE_HANDLE = "delegateHandle";
    private static final String ATTR_DELEGATE_DOMAIN = "delegateDomain";

    // cType constantsyes
    private static final String CTYPE_ONLINE_ACCOUNT_ADD2 = "ONLINE_ACCOUNT_ADD2";
    private static final String CTYPE_ONLINE_ACCOUNT_ADD_SEC = "ONLINE_ACCOUNT_ADD_SEC";
    private static final String CTYPE_CTN_ADDED_TO_ACCESSID = "CTN_ADDED_TO_ACCESSID";
    private static final String CTYPE_CTN_REMOVED_FROM_ACCESSID = "CTN_REMOVED_FROM_ACCESSID";
    private static final String CTYPE_CTN_CHANGED_ON_ACCESSID = "CTN_CHANGED_ON_ACCESSID";
    private static final String CTYPE_LVLTWO_ACCESSID_LOCK = "LVLTWO_ACCESSID_LOCK";
    private static final String CTYPE_LVLONE_ACCESSID_LOCK = "LVLONE_ACCESSID_LOCK";
    private static final String CTYPE_ACCESSID_FRAUD_UNLOCK = "ACCESSID_FRAUD_UNLOCK";
    private static final String CTYPE_ACCOUNT_LOCK = "ACCOUNT_LOCK";
    private static final String EML_ADDR_VALIDATION = "EML_ADDR_VALIDATION";
    private static final String HS_CBR_CONFIRM = "HS_CBR_CONFIRM";
    private static final String CTYPE_PROFILE_UPDATE = "PROFILE_UPDATE";
    private static final String CTYPE_DELETE_ACCOUNT = "DELETE_ACCOUNT";
    private static final String CTYPE_ONLINE_ACCOUNT_REG = "ONLINE_ACCOUNT_REG";
    private static final String WIRELINE_HS_CBR_UPDATE = "WIRELINE_HS_CBR_UPDATE";
    private static final String PRIN_USER_UPDATE="PRIN_USER_UPDATE";
    private static final String  PM_ACCT_CREATION="PM_ACCT_CREATION";
    private static final String SLID_TITANIZED="SLID_TITANIZED";
    private static final String ACCESS_GRANTED_PRIMARY="ACCESS_GRANTED_PRIMARY";
    private static final String ACCESS_GRANTED_SECONDARY="ACCESS_GRANTED_SECONDARY";
    private static final String PROFILE_UPDATE_SECURE_KEY="PROFILE_UPDATE_SECURE_KEY";
    private static final String SWAP_OWNERSHIP="SWAP_OWNERSHIP";
    private static final String UPDATE_CONTACT_EMAIL="UPDATE_CONTACT_EMAIL";
    private static final String MERGE_ACCOUNT_NOTIFY1="MERGE_ACCOUNT_NOTIFY1";
    private static final String SLID_UPDATE="SLID_UPDATE";

    /**
     * Creates an Attribute instance with the specified name and value.
     * @param name  the name of the attribute
     * @param value the value of the attribute
     * @return a new Attribute object with the given name and value
     */
    public static Attribute createAttribute(String name, String value) {
        return new Attribute(name, value);
    }

    /**
     * Builds a list of Attribute objects based on the provided notification map.
     * @param event the event map containing attribute data
     * @param hmClmInputNotification the input notification map containing attribute data
     * @return a list of Attribute objects populated according to the cType value
     */
    public static List<Attribute> buildAttributes(Map<String, Object> event, Map<String, Object> hmClmInputNotification) {

        Object notificationDataObj = event.get("notificationData");
        Map<String, Object> notificationData =
                notificationDataObj instanceof Map ? (Map<String, Object>) notificationDataObj :
                        (notificationDataObj instanceof List && !((List<?>) notificationDataObj).isEmpty() && ((List<?>) notificationDataObj).get(0) instanceof Map)
                                ? (Map<String, Object>) ((List<?>) notificationDataObj).get(0)
                                : null;

        List<Attribute> attributes = new ArrayList<>();
        String cType = Optional.ofNullable(hmClmInputNotification.get("cType"))
                .filter(String.class::isInstance)
                .map(String.class::cast)
                .orElse(null);
        if (cType == null) {
            return attributes;
        }
        Object userLockReasonCode = event.get(CommonDefs.USER_LOCK_REASON_CODE);
        Object accountLockReasonCode= event.get(CommonDefs.ACCOUNT_LOCK_REASON);
        String encryptedKey= hmClmInputNotification.get(ConsumerConstants.ENCRYPTED_KEY) != null ? (String) hmClmInputNotification.get(ConsumerConstants.ENCRYPTED_KEY) : null;
        String sorSystem= hmClmInputNotification.get(ConsumerConstants.SOR_SYSTEM) != null ? (String) hmClmInputNotification.get(ConsumerConstants.SOR_SYSTEM) : null;
        Object longUrl = notificationData != null && notificationData.get("EncryptedKey") != null
                ? "https://www.att.com/acctmgmt/myprofile/verify?m=" + notificationData.get("EncryptedKey")
                : null;
        String qarKey = notificationData != null && notificationData.get("qarKey") instanceof String ? (String) notificationData.get("qarKey") : null;

        switch (cType.toUpperCase()) {
            case CTYPE_ONLINE_ACCOUNT_ADD2:
                if (StringUtils.isNotBlank((String) hmClmInputNotification.get(CommonDefs.KEY_OWNER_MAIN_CTN))) {
                    attributes.add(createAttribute(ATTR_MAIN_CTN, (String) event.get(CommonDefs.KEY_OWNER_MAIN_CTN)));
                }
                attributes.add(createAttribute(ATTR_FIRST_NAME_OWN, getStringOrDefault(event, CommonDefs.KEY_OWNER_FIRST_NAME, CommonDefs.FIRST_NAME)));
                attributes.add(createAttribute(ATTR_LAST_NAME_OWN, getStringOrDefault(event, CommonDefs.KEY_OWNER_LAST_NAME, CommonDefs.LAST_NAME)));
                if ("Y".equalsIgnoreCase((String) hmClmInputNotification.get("secondaryAccessGranted"))) {
                    if (StringUtils.isNotBlank((String) hmClmInputNotification.get("ownerSLID"))) {
                        attributes.add(createAttribute(ATTR_ACCESS_ID_OWN, (String) hmClmInputNotification.get("ownerSLID")));
                    }
                    if (StringUtils.isNotBlank((String) event.get(CommonDefs.DELEGATE_HANDLE))) {
                        attributes.add(createAttribute(ATTR_ACCESS_ID_SEC, (String) event.get(CommonDefs.DELEGATE_HANDLE)));
                    }
                    if (StringUtils.isNotBlank((String) event.get(CommonDefs.KEY_DELEGATE_FIRST_NAME))) {
                        attributes.add(createAttribute(ATTR_FIRST_NAME_SEC, (String) event.get(CommonDefs.KEY_DELEGATE_FIRST_NAME)));
                    }
                    if (StringUtils.isNotBlank((String) event.get(CommonDefs.KEY_DELEGATE_LAST_NAME))) {
                        attributes.add(createAttribute(ATTR_LAST_NAME_SEC, (String) event.get(CommonDefs.KEY_DELEGATE_LAST_NAME)));
                    }
                } else {
                    if (StringUtils.isNotBlank((String) event.get(CommonDefs.SLID)))
                        attributes.add(createAttribute(ATTR_ACCESS_ID_OWN, (String) event.get(CommonDefs.SLID)));
                }
                if (StringUtils.isNotBlank((String) hmClmInputNotification.get(ATTR_NOTIFICATION_ACCT_TYPE))) {
                    attributes.add(createAttribute(ATTR_NOTIFICATION_ACCT_TYPE, (String) hmClmInputNotification.get(ATTR_NOTIFICATION_ACCT_TYPE)));
                }
                break;
            case CTYPE_ONLINE_ACCOUNT_ADD_SEC:
                if (StringUtils.isNotBlank((String) event.get(CommonDefs.KEY_OWNER_MAIN_CTN))) {
                    attributes.add(createAttribute(ATTR_MAIN_CTN, (String) event.get(CommonDefs.KEY_DELEGATE_MAIN_CTN)));
                }
                if (StringUtils.isNotBlank((String) event.get(CommonDefs.KEY_DELEGATE_FIRST_NAME))) {
                    attributes.add(createAttribute(ATTR_FIRST_NAME_SEC, (String) event.get(CommonDefs.KEY_DELEGATE_FIRST_NAME)));
                }
                if (StringUtils.isNotBlank((String) event.get(CommonDefs.KEY_DELEGATE_LAST_NAME))) {
                    attributes.add(createAttribute(ATTR_LAST_NAME_SEC, (String) event.get(CommonDefs.KEY_DELEGATE_LAST_NAME)));
                }
                if (StringUtils.isNotBlank((String) event.get(CommonDefs.DELEGATE_HANDLE))) {
                    attributes.add(createAttribute(ATTR_ACCESS_ID_SEC_LOWER, (String) event.get(CommonDefs.DELEGATE_HANDLE)));
                }
                if (StringUtils.isNotBlank((String) hmClmInputNotification.get(ATTR_NOTIFICATION_ACCT_TYPE))) {
                    attributes.add(createAttribute(ATTR_NOTIFICATION_ACCT_TYPE, (String) hmClmInputNotification.get(ATTR_NOTIFICATION_ACCT_TYPE)));
                }
                break;
            case CTYPE_CTN_ADDED_TO_ACCESSID:
            case CTYPE_CTN_REMOVED_FROM_ACCESSID:
                if (StringUtils.isNotBlank((String) hmClmInputNotification.get(ATTR_MAIN_CTN))) {
                    attributes.add(createAttribute(ATTR_MAIN_CTN, (String) hmClmInputNotification.get(ATTR_MAIN_CTN)));
                }
                attributes.add(createAttribute(ATTR_NOTIFICATION_ACCOUNT_TYPE, "wireless"));
                break;
            case CTYPE_CTN_CHANGED_ON_ACCESSID:
                if (StringUtils.isNotBlank((String) hmClmInputNotification.get(ATTR_MAIN_CTN))) {
                    attributes.add(createAttribute(ATTR_MAIN_CTN, (String) hmClmInputNotification.get(ATTR_MAIN_CTN)));
                }
                if (StringUtils.isNotBlank((String) hmClmInputNotification.get("oldMainCTN"))) {
                    attributes.add(createAttribute(ATTR_MAIN_CTN_PREV, (String) hmClmInputNotification.get("oldMainCTN")));
                }
                break;
            case CTYPE_ACCESSID_FRAUD_UNLOCK:
                if (StringUtils.isNotBlank((String) event.get(FIRST_NAME))) {
                    attributes.add(createAttribute(ATTR_FIRST_NAME, (String) event.get(FIRST_NAME)));
                }
                if (StringUtils.isNotBlank((String) event.get(LAST_NAME))) {
                    attributes.add(createAttribute(ATTR_LAST_NAME, (String) event.get(LAST_NAME)));
                }
                break;
            case CTYPE_LVLTWO_ACCESSID_LOCK:
            case CTYPE_LVLONE_ACCESSID_LOCK:
                Object userLockLevel = event.get(CommonDefs.USER_LOCK_LEVEL);

                if (userLockLevel != null) {
                    attributes.add(createAttribute(CommonDefs.USER_LOCK_LEVEL, String.valueOf(userLockLevel)));
                }
                if (userLockReasonCode!= null) {
                    attributes.add(createAttribute(CommonDefs.USER_LOCK_REASON_CODE, String.valueOf(userLockReasonCode)));
                }
                if (StringUtils.isNotBlank((String) event.get(FIRST_NAME))) {
                    attributes.add(createAttribute(ATTR_FIRST_NAME, (String) event.get(FIRST_NAME)));
                }
                if (StringUtils.isNotBlank((String) event.get(LAST_NAME))) {
                    attributes.add(createAttribute(ATTR_LAST_NAME, (String) event.get(LAST_NAME)));
                }
                break;
            case CTYPE_ACCOUNT_LOCK:
                if (accountLockReasonCode != null) {
                    attributes.add(createAttribute(CommonDefs.ACCOUNT_LOCKED_REASON_CODE, String.valueOf(accountLockReasonCode)));
                }
                break;
            case EML_ADDR_VALIDATION:
                if (encryptedKey != null) {
                    attributes.add(createAttribute(ConsumerConstants.EML_ADDR_VALIDATION_LINK, encryptedKey));
                }
                if (sorSystem != null) {
                    attributes.add(createAttribute(ConsumerConstants.SOR_SYSTEM, sorSystem));
                }
                break;
            case HS_CBR_CONFIRM:
                if (longUrl != null) {
                    attributes.add(createAttribute(ATTR_LONG_URL, String.valueOf(longUrl)));
                }
                break;
            case  CTYPE_PROFILE_UPDATE:
                if (StringUtils.isNotBlank((String) event.get("action")))
                    attributes.add(createAttribute("action", (String) event.get("action")));
                if(StringUtils.isNotBlank((String) event.get(CommonDefs.CRM_HANDLE))) {
                    if("slid.dum".equalsIgnoreCase((String) event.get(CommonDefs.CRM_DOMAIN)))
                        attributes.add(createAttribute("profileId", (String) event.get(CommonDefs.CRM_HANDLE)));
                    else if(StringUtils.isNotBlank((String) event.get(CommonDefs.CRM_DOMAIN)))
                        attributes.add(createAttribute("profileId", (String) event.get(CommonDefs.CRM_HANDLE)+"@"+(String) event.get(CommonDefs.CRM_DOMAIN)));
                    else
                        attributes.add(createAttribute("profileId", (String) event.get(CommonDefs.CRM_HANDLE)));
                }
                if(hmClmInputNotification.get("defaultAccountChanged") !=null && "Y".equalsIgnoreCase((String) hmClmInputNotification.get("defaultAccountChanged")))
                    attributes.add(createAttribute("profileElement", "DEFAULT_ACCT"));
                else if (hmClmInputNotification.get("primaryEmailChanged") !=null && "Y".equalsIgnoreCase((String) hmClmInputNotification.get("primaryEmailChanged")))
                    attributes.add(createAttribute("profileElement", "CONTACT_EMAIL"));
                break;
            case CTYPE_ONLINE_ACCOUNT_REG:
                if (StringUtils.isNotBlank((String) hmClmInputNotification.get("AccountLast4")))
                    attributes.add(createAttribute("profileId", (String) hmClmInputNotification.get("AccountLast4")));
                attributes.add(createAttribute("profileIdType", "BAN"));
                if (StringUtils.isNotBlank((String) event.get(FIRST_NAME))) {
                    attributes.add(createAttribute(FIRST_NAME, (String) event.get(FIRST_NAME)));
                }
                if (StringUtils.isNotBlank(qarKey)) {
                    attributes.add(createAttribute(ATTR_QAR_KEY, qarKey));
                }
                break;
            case  CTYPE_DELETE_ACCOUNT:
                if (StringUtils.isNotBlank((String) hmClmInputNotification.get("AccountLast4")))
                    attributes.add(createAttribute("profileId", (String) hmClmInputNotification.get("AccountLast4")));
                attributes.add(createAttribute("profileIdType", "BAN"));
                if (StringUtils.isNotBlank((String) event.get(FIRST_NAME))) {
                    attributes.add(createAttribute(ATTR_FIRST_NAME, (String) event.get(FIRST_NAME)));
                }
                break;
            case WIRELINE_HS_CBR_UPDATE:
                if (notificationData != null && notificationData.get("PhoneUpdateDetailsChanged") instanceof List) {
                    List<Map<String, Object>> phoneUpdateList = (List<Map<String, Object>>) notificationData.get("PhoneUpdateDetailsChanged");
                    if (!phoneUpdateList.isEmpty()) {
                        Map<String, Object> phoneDetails = phoneUpdateList.get(0);

                        if (StringUtils.isNotBlank((String) phoneDetails.get("action"))) {
                            attributes.add(createAttribute("action", (String) phoneDetails.get("action")));
                        }
                        if (StringUtils.isNotBlank((String) phoneDetails.get("phoneCategory"))) {
                            attributes.add(createAttribute("phoneCategory", (String) phoneDetails.get("phoneCategory")));
                        }
                        if (StringUtils.isNotBlank((String) phoneDetails.get("phoneNumber"))) {
                            attributes.add(createAttribute("phoneNumber", (String) phoneDetails.get("phoneNumber")));
                        }
                        if (StringUtils.isNotBlank((String) phoneDetails.get("phoneType"))) {
                            attributes.add(createAttribute("phoneType", (String) phoneDetails.get("phoneType")));
                        }
                        if (StringUtils.isNotBlank((String) phoneDetails.get("phoneNumberOld"))) {
                            attributes.add(createAttribute("phoneNumberOld", (String) phoneDetails.get("phoneNumberOld")));
                        }
                        if (StringUtils.isNotBlank((String) phoneDetails.get("phoneTypeOld"))) {
                            attributes.add(createAttribute("phoneTypeOld", (String) phoneDetails.get("phoneTypeOld")));
                        }
                    }
                }
                break;
            case PRIN_USER_UPDATE, UPDATE_CONTACT_EMAIL:
                if (StringUtils.isNotBlank((String) event.get(FIRST_NAME)))
                    attributes.add(createAttribute(ATTR_FIRST_NAME, (String) event.get(FIRST_NAME)));
                if(StringUtils.isNotBlank((String) event.get(LAST_NAME)))
                    attributes.add(createAttribute(ATTR_LAST_NAME, (String) event.get(LAST_NAME)));
                if(StringUtils.isNotBlank((String) hmClmInputNotification.get("AccountLast4")))
                    attributes.add(createAttribute("AccountLast4", (String) hmClmInputNotification.get("AccountLast4")));
                break;
            case  PM_ACCT_CREATION:
                if (StringUtils.isNotBlank((String) event.get(FIRST_NAME)))
                    attributes.add(createAttribute(ATTR_FIRST_NAME, (String) event.get(FIRST_NAME)));
                break;
            case  SLID_TITANIZED:
                if (StringUtils.isNotBlank((String) event.get(FIRST_NAME)))
                    attributes.add(createAttribute(ATTR_FIRST_NAME, (String) event.get(FIRST_NAME)));
                if(StringUtils.isNotBlank((String) event.get(LAST_NAME))) {
                        attributes.add(createAttribute(ATTR_LAST_NAME, (String) event.get(LAST_NAME)));
                    }
                    if (StringUtils.isNotBlank((String) hmClmInputNotification.get("handle")))
                        attributes.add(createAttribute("AccessId", (String) hmClmInputNotification.get("handle")));
                    if (StringUtils.isNotBlank((String) hmClmInputNotification.get("MultiProductInd")))
                        attributes.add(createAttribute("MultiProductInd", (String) hmClmInputNotification.get("MultiProductInd")));
                    if (StringUtils.isNotBlank((String) hmClmInputNotification.get("ServiceType")))
                        attributes.add(createAttribute("ServiceType", (String) hmClmInputNotification.get("ServiceType")));
                break;
            case  ACCESS_GRANTED_PRIMARY:
                if (StringUtils.isNotBlank((String) event.get(ATTR_OWNER_FIRST_NAME)))
                    attributes.add(createAttribute(ATTR_FIRST_NAME_OWN, (String) event.get(ATTR_OWNER_FIRST_NAME)));
                if(StringUtils.isNotBlank((String) event.get(ATTR_OWNER_LAST_NAME)))
                        attributes.add(createAttribute(ATTR_LAST_NAME_OWN, (String) event.get(ATTR_OWNER_LAST_NAME)));
                if (StringUtils.isNotBlank((String) event.get(ATTR_DELEGATE_FIRST_NAME)))
                    attributes.add(createAttribute(ATTR_FIRST_NAME_SEC, (String) event.get(ATTR_DELEGATE_FIRST_NAME)));
                if (StringUtils.isNotBlank((String) event.get(ATTR_DELEGATE_LAST_NAME)))
                    attributes.add(createAttribute(ATTR_LAST_NAME_SEC, (String) event.get(ATTR_DELEGATE_LAST_NAME)));
                if (StringUtils.isNotBlank((String) event.get(ATTR_DELEGATE_HANDLE)) && StringUtils.isNotBlank((String) event.get(ATTR_DELEGATE_DOMAIN)))
                    attributes.add(createAttribute(ATTR_ACCESS_ID_SEC, (String) event.get(ATTR_DELEGATE_HANDLE) + "@" + event.get(ATTR_DELEGATE_DOMAIN)));
                break;
            case  ACCESS_GRANTED_SECONDARY:
                if (StringUtils.isNotBlank((String) event.get(ATTR_DELEGATE_FIRST_NAME)))
                    attributes.add(createAttribute(ATTR_FIRST_NAME, (String) event.get(ATTR_DELEGATE_FIRST_NAME)));
                if(StringUtils.isNotBlank((String) event.get(ATTR_DELEGATE_LAST_NAME)))
                        attributes.add(createAttribute(ATTR_LAST_NAME, (String) event.get(ATTR_DELEGATE_LAST_NAME)));
                break;
            case  PROFILE_UPDATE_SECURE_KEY:
                if (StringUtils.isNotBlank((String) event.get("action")))
                        attributes.add(createAttribute("ProfileAction", (String)(event.get("action"))));
                break;
            case  SWAP_OWNERSHIP:
                if (StringUtils.isNotBlank((String) event.get(FIRST_NAME)))
                    attributes.add(createAttribute(ATTR_FIRST_NAME_OWN, (String) event.get(FIRST_NAME)));
                if(StringUtils.isNotBlank((String) event.get(LAST_NAME)))
                    attributes.add(createAttribute(ATTR_LAST_NAME_OWN, (String) event.get(LAST_NAME)));
                if (StringUtils.isNotBlank((String) hmClmInputNotification.get("NewProfileId")))
                    attributes.add(createAttribute("NewProfileId", (String) hmClmInputNotification.get("NewProfileId")));
                if (StringUtils.isNotBlank((String) hmClmInputNotification.get("OldProfileId")))
                    attributes.add(createAttribute("OldProfileId", (String) hmClmInputNotification.get("OldProfileId")));
                break;
            case  MERGE_ACCOUNT_NOTIFY1:
                if (StringUtils.isNotBlank((String) event.get(FIRST_NAME)))
                    attributes.add(createAttribute("ATTAccessID", (String) event.get(FIRST_NAME)));
                if (StringUtils.isNotBlank((String) event.get(LAST_NAME)))
                    attributes.add(createAttribute("MainCTN2", (String) event.get(LAST_NAME)));
                if (StringUtils.isNotBlank((String) hmClmInputNotification.get("ProfileId")))
                    attributes.add(createAttribute("ProfileId", (String) hmClmInputNotification.get("ProfileId")));
                if (StringUtils.isNotBlank((String) event.get(FIRST_NAME)))
                    attributes.add(createAttribute("isProfileIdAutoGenerated", (String) event.get(FIRST_NAME)));
                if (StringUtils.isNotBlank((String) event.get(LAST_NAME)))
                    attributes.add(createAttribute("ServiceName", (String) event.get(LAST_NAME)));
                if (StringUtils.isNotBlank((String) hmClmInputNotification.get("ProfileIDElement")))
                    attributes.add(createAttribute("ProfileIDElement", (String) hmClmInputNotification.get("ProfileIDElement")));
                break;
            case  SLID_UPDATE:
                Object newSlidObj = notificationData != null ? notificationData.get("newSLID") : null;
                if (newSlidObj instanceof String newSlid && StringUtils.isNotBlank(newSlid)) {
                    attributes.add(createAttribute("SingleLoginId", newSlid));
                }
                break;
            default:
                break;
        }
        return attributes;
    }

    /**
     * Returns the value for the first key if present, otherwise the second key, or null if neither is present.
     * @param map the map to search
     * @param primaryKey the primary key
     * @param fallbackKey the fallback key
     * @return the value as a String, or null
     */
    private static String getStringOrDefault(Map<String, Object> map, String primaryKey, String fallbackKey) {
        Object value = map.get(primaryKey);
        if (value != null) {
            return (String) value;
        }
        value = map.get(fallbackKey);
        return value != null ? (String) value : null;
    }
}
