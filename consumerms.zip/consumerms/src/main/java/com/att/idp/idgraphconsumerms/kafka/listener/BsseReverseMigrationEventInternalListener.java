package com.att.idp.idgraphconsumerms.kafka.listener;

import com.att.idp.idgraphconsumerms.bsse.reverse.BsseReverseMigrationEventProcessor;
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

/**
 * OAuth-based Kafka listener for Bsse Reverse MigrationEvent Events.
 */
@Service
public class BsseReverseMigrationEventInternalListener {
    private final BsseReverseMigrationEventProcessor processor;
    private static final Logger logger = LoggerFactory.getLogger(BsseReverseMigrationEventInternalListener.class);

    public BsseReverseMigrationEventInternalListener(BsseReverseMigrationEventProcessor processor) {
        this.processor = processor;
    }

    @KafkaListener(
            id = "bsseRevMigEventOAuthInternalListener",
            topics = "${idgraph.consumer.bssereversemigoauthinternal.topic}",
            containerFactory = "bsseRevMigOAuthInternalConsumerContainerFactory",
            groupId = "${idgraph.consumer.bssereversemigoauthinternal.group-id}",
            concurrency = "${idgraph.consumer.bssereversemigoauthinternal.concurrency:1}",
            autoStartup = "${idgraph.consumer.bssereversemigoauthinternal.autoStartup:false}")
    public void consumeBsseReverseMigrationEvent(@Payload String msg, @Headers MessageHeaders messageHeaders, Acknowledgment ack) throws Exception {
        try {
            logger.info("Received BsseReverseMigrationEvent (OAuth), payload: {}", ConsumerUtil.encode(msg));
            processor.processEvent(msg, messageHeaders, ack);
            logger.info("CONSUMER_EVENT_SUCCESS: listenerId=bsseRevMigEventOAuthInternalListener");
        } catch (Exception e) {
            logger.error("CONSUMER_EVENT_FAILED: listenerId=bsseRevMigEventOAuthInternalListener, error={}", e.getMessage());
            throw e;
        } finally {
            MDC.clear();
        }
    }
}

