package com.att.idp.idgraphconsumerms.kafka.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

/**
 * Unified Kafka consumer properties supporting both Plain and OAuth authentication.
 */
@Data
@Validated
public class KafkaConsumerProperties {

    /**
     * Authentication type: PLAIN or OAUTH.
     */
    private String authType;
    private String consumerName;
    private String bootstrapServers;
    private String groupId;
    private String topic;
    private String securityProtocol;
    private String saslMechanism;
    private String saslJaasUsername;
    private String saslJaasPwd;
    private String saslJaasConfig;
    private String saslOauthbearerTokenEndpointUrl;
    private String saslLoginCallbackHandlerClass;
    private int maxPollRecords;
    private int maxPollIntervalMs;
    private String autoOffsetReset;
    private Integer bufferMemory;
    private Boolean autoStartup;
    private Integer concurrency = 1;
    private String logicalCluster;
    private String poolId;
    private Long authExceptionRetryInterval;
}
