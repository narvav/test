package com.att.idp.idgraphconsumerms.kafka.model;

import com.att.idp.idgraph.events.model.Attribute;
import com.att.idp.idgraphconsumerms.kafka.model.Account;
import com.att.idp.idgraphconsumerms.kafka.model.JsonSealizable;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserIdNotificationEventDetails implements JsonSealizable {
    private String individualId;
    private String accessId;
    private String domain;
    private String guid;
    private String clientId;
    private String language;
    private List<Account> accountList;
    private String notificationLevel;
    private String communicationMode;
    private String isCPNINotification;
    private DeliveryMethods deliveryMethods;
    private String customerType;
    private String autoGenInd;
    private String accountId;
    private String roleType;
    private String serviceType;
    private String billingSystem;
    private String subCategory;
    private String isBSSEEvent;
    private List<Attribute> attributes;
}