package com.att.idp.idgraphconsumerms.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BillingAccountStateChangeEvent {
    private String eventId;
    private String eventType;
    private String eventTime;
    private String resourceName;
    private Event event;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Event {
        private String name;
        private String type;
        private String resourceVersion;
        private String resourceIdentifier;
        private String account; // JSON string containing account details
    }
}
