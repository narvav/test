package com.att.idp.idgraphconsumerms.kafka.listener;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

/**
 * OAuth-based Kafka listener for CG Subscriber Events.
 */
@Service
public class DmctnCGSubscriberEventOAuthListener {
    private final DmctnCGSubscriberEventProcessor processor;
    private static final Logger logger = LoggerFactory.getLogger(DmctnCGSubscriberEventOAuthListener.class);

    public DmctnCGSubscriberEventOAuthListener(DmctnCGSubscriberEventProcessor processor) {
        this.processor = processor;
    }

    @KafkaListener(
            id = "dmctnSubChangeEventOAuthListener",
            topics = "${idgraph.consumer.cgdmctnoauth.topic}",
            containerFactory = "cgDmctnOAuthConsumerContainerFactory",
            groupId = "${idgraph.consumer.cgdmctnoauth.group-id}",
            concurrency = "${idgraph.consumer.cgdmctnoauth.concurrency:1}",
            autoStartup = "${idgraph.consumer.cgdmctnoauth.autoStartup:false}"
    )    public void consumeCGSubcriberEvent(@Payload String msg, @Headers MessageHeaders messageHeaders,
                                             Acknowledgment ack) throws Exception {
        try {
            logger.info("Received SubscriberChangeEvent (Oauth)");
            processor.processEvent(msg, messageHeaders, ack);
            logger.info("CONSUMER_EVENT_SUCCESS: listenerId=dmctnSubChangeEventOAuthListener");
        } catch (Exception e) {
            logger.error("CONSUMER_EVENT_FAILED: listenerId=dmctnSubChangeEventOAuthListener, error={}", e.getMessage());
            throw e;
        } finally {
            MDC.clear();
        }
    }
}

