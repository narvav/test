package com.att.idp.idgraphconsumerms.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MigrationBANNotification implements Serializable, MigrationEvent {

	//  "event_type": "MigrationBanNotification",

	//  "event_id": "ca09f791-9b5b-4c1f-bccd-60cab0d2519a", -- not in the model
	//  "migration_id": "202410311450",
	//  "service_type": "WIRELESS", -- not in the model

	//  "source_market_code": "AAA",
	//  "source_ban_id": "4708151887",
	//  "target_ban_id": "9708151887",
	//  "source_cycle_id": "13",
	//  "target_cycle_id": "23", -- not in the model
	//  "target_customer_id": "2677419f-9214-4fa7-aff3-52893505c03b", --	not in the model
	//  "target_individual_id": "63761bfc-54d5-4356-b546-ddb91f1a8c1b", ?? same as individual_id?
	//  "guid": "11242563",
	//  "status": "Inflight_PONR",
	//  "sub_status": "Request_All_Commit_To_Target",
	//  "op_ts": "2024-06-27 10:00:00.429107"

	public static final long serialVersionUID = 1L;

	@JsonProperty("event_type")
	private String eventType;

	@JsonProperty("event_id")
	private String eventId;

	@JsonProperty("migration_id")
	private String migrationId;

	@JsonProperty("service_type")
	private String serviceType;

	@JsonProperty("source_ban_id")
	private String sourceBanId;

	@JsonProperty("source_market_code")
	private String sourceMarketCode;

	@JsonProperty("target_ba_id")
	private String targetBanId;

	@JsonProperty("source_cycle_id")
	private String sourceCycleId;

	@JsonProperty("target_cycle_id")
	private String targetCycleId;

	@JsonProperty("target_customer_id")
	private String targetCustomerId;

	@JsonProperty("guid")
	private String guid;

	@JsonProperty("target_individual_id")
	private String targetIndividualId;

	@JsonProperty("status")
	private String status;

	@JsonProperty("sub_status")
	private String subStatus;

	@JsonProperty("op_ts")
	private String opTs;

	@JsonProperty("replay_flag")
	private String replayFlag;

	@JsonProperty("passcode_venc")
	private String passcodeVenc;


	@Override
	public String toString() {
		return "MigrationBANNotification{" + "eventType='" + eventType + '\'' + ", eventId='" + eventId + '\'' + ", migrationId='" + migrationId + '\'' + ", serviceType='" + serviceType + '\'' + ", sourceBanId='" + sourceBanId + '\'' + ", sourceMarketCode='" + sourceMarketCode + '\'' + ", targetBanId='" + targetBanId + '\'' + ", sourceCycleId='" + sourceCycleId + '\'' + ", targetCycleId='" + targetCycleId + '\'' + ", targetCustomerId='" + targetCustomerId + '\'' + ", guid='" + guid + '\'' + ", targetIndividualId='" + targetIndividualId + '\'' + ", status='" + status + '\'' + ", subStatus='" + subStatus + '\'' + ", opTs='" + opTs + '\'' + ", replayFlag='" + replayFlag + '\'' + ", passcodeVenc='[REDACTED]'}";
	}

	@JsonIgnore
	@Override
	public String getSourceBan() {
		return this.sourceBanId;
	}

	@JsonIgnore
	@Override
	public String getTargetBan() {
		return this.targetBanId;
	}

	@JsonIgnore
	@Override
	public String getIndividualId() {
		return this.targetIndividualId;
	}

	@JsonIgnore
	@Override
	public String getOriginalRequestAsString() {
		return this.toString();
	}

	@JsonIgnore
	@Override
	public Object getOriginalRequest() {
		return this;
	}
}


