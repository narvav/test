package com.att.idp.idgraphconsumerms.helpers;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails;
import com.att.idp.idgraphconsumerms.kafka.errorhandler.ErrorDetailsBuilder;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.att.mpsys.common.utils.CErrorDefs;
import com.fasterxml.jackson.databind.JsonNode;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;
import java.util.Map;

@Service
public class PasscodeProcessor {

    @Value("${apiclient.rest.ua.serverUrl}")
    private String userAssoServerUrl;
    @Value("${apiclient.rest.ua.cred.endpoint}")
    private String uaServiceEndPoint;
    @Value("${apiclient.rest.ua.username}")
    private String userName;
    @Value("${apiclient.rest.ua.password}")
    private String userPassword;

    private static final Logger logger = LoggerFactory.getLogger(PasscodeProcessor.class);

    private RestTemplate restTemplate;

    @Autowired
    private CosmosFailedEventsWriter cosmosFailedEventsWriter;

    @Autowired
    public void setRestTemplate(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    private static final int MAX_ATTEMPTS = 2;

    @Retryable(maxAttempts = MAX_ATTEMPTS, include = {HttpServerErrorException.class})
    public void callUserAssociationDeleteCredService(String individualId, String eventName) {

        String resourceUri =null;
            if(!StringUtils.isEmpty(individualId))
                resourceUri =this.userAssoServerUrl + this.uaServiceEndPoint + "/" + individualId;

        HttpHeaders reqheaders = new HttpHeaders();
        reqheaders.setContentType(MediaType.APPLICATION_JSON);
        reqheaders.add(ConsumerConstants.Keys.AUTHORIZATION, "Basic " + Base64.getEncoder().encodeToString((this.userName + ":" + this.userPassword).getBytes()));
        reqheaders.add(ConsumerConstants.Keys.X_ATT_CLIENTID,  ConsumerConstants.BsseMigration.CLIENT_ORDERGRAPH);
        reqheaders.add(ConsumerConstants.Keys.IDP_TRACE_ID, MDC.get(ConsumerConstants.Keys.IDP_TRACE_ID));
        HttpEntity<?> httpEntity = new HttpEntity<>(reqheaders);

        logger.info("Calling IDGraphUserAssociationMs Delete Credentials Rest endpoint URI: {}", resourceUri);
        ResponseEntity<JsonNode> response = null;

        try {
            JsonNode jsonNode=null;
            if( !StringUtils.isEmpty(resourceUri))
                response = this.restTemplate.exchange(resourceUri, HttpMethod.DELETE, httpEntity, JsonNode.class);
            if (response != null && response.getBody() != null) {
                jsonNode = JsonService.getObjectFromJson(response.getBody(), JsonNode.class);
                logger.info("Response from IDGraphUserAssociationMs Delete Credentials API: {}", jsonNode);
            }
        } catch (HttpServerErrorException e) {
            logger.error("Retryable exception while calling IDGraphUserAssociationMs. {} Will be retried for a max attempts of: {}", e, MAX_ATTEMPTS);
            throw e;
        } catch (Exception e) {
            logger.error("Non-retryable exception received", e);
            Map<String, String> errorDetails = ErrorDetailsBuilder.builder()
                    .addDetail(ConsumerConstants.ErrorDetails.ERROR_CODE, CErrorDefs.ERR_INVALID_DATA)
                    .addDetail(ConsumerConstants.ErrorDetails.ERROR_MESSAGE, e.getMessage())
                    .addDetail(ConsumerConstants.ErrorDetails.FAILED_ENDPOINT, uaServiceEndPoint)
                    .addDetail(ConsumerConstants.ErrorDetails.ACCOUNT_TYPE, ConsumerConstants.BsseMigration.INDIVIDUAL_ID)
                    .build();

            FailedEventDetails failedEventDetails = new FailedEventDetails(
                    individualId,
                    JsonService.toJsonString(individualId),
                    eventName,
                    errorDetails
            );
            cosmosFailedEventsWriter.saveFailedEventsToCosmos(failedEventDetails);
        }
    }


    @Recover
    public void recover(HttpServerErrorException e, String individualId, String eventName) {
        //store in cosmos db
        logger.error("HttpServerErrorException while calling IDGraphUserAssociationMs, Exhausted retries : {}", e.getMessage());
        Map<String, String> errorDetails = ErrorDetailsBuilder.builder()
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_CODE, CErrorDefs.ERR_INVALID_DATA)
                .addDetail(ConsumerConstants.ErrorDetails.ERROR_MESSAGE, e.getMessage())
                .addDetail(ConsumerConstants.ErrorDetails.FAILED_ENDPOINT, uaServiceEndPoint)
                .addDetail(ConsumerConstants.ErrorDetails.ACCOUNT_TYPE, ConsumerConstants.BsseMigration.INDIVIDUAL_ID)
                .build();

        FailedEventDetails failedEventDetails = new FailedEventDetails(
                individualId,
                JsonService.toJsonString(individualId),
                eventName,
                errorDetails
        );
        cosmosFailedEventsWriter.saveFailedEventsToCosmos(failedEventDetails);
    }

}

