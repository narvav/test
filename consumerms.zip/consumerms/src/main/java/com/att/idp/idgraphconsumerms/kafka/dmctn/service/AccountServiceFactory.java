package com.att.idp.idgraphconsumerms.kafka.dmctn.service;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.kafka.model.AccountNotificationEvent;
import org.springframework.stereotype.Component;

@Component
public class AccountServiceFactory {

    private final OrchestrationWirelessService orchestrationWirelessService;
    private final UpdateAccountNotificationService updateAccountNotificationService;
    private final CloseAccountNotificationService closeAccountNotificationService;
    private final ProvisionEnablerNotificationService provisionEnablerNotificationService;

    public AccountServiceFactory(OrchestrationWirelessService orchestrationWirelessService,
                                 UpdateAccountNotificationService updateAccountNotificationService,
                                 CloseAccountNotificationService closeAccountNotificationService,
                                 ProvisionEnablerNotificationService provisionEnablerNotificationService) {
        this.orchestrationWirelessService = orchestrationWirelessService;
        this.updateAccountNotificationService = updateAccountNotificationService;
        this.closeAccountNotificationService = closeAccountNotificationService;
        this.provisionEnablerNotificationService = provisionEnablerNotificationService;
    }

    public BaseService<AccountNotificationEvent> getService(AccountNotificationEvent accountNotificationEvent) {

        String eventType = accountNotificationEvent.getEventName();

        BaseService<AccountNotificationEvent> service = null;
        if(eventType.equalsIgnoreCase(ConsumerConstants.AccountNotificationConstants.ACTIVATE_ACCOUNT) ) {
            service = orchestrationWirelessService;
        }else if(eventType.equalsIgnoreCase(ConsumerConstants.AccountNotificationConstants.UPDATE_ACCOUNT)
                && hasText(accountNotificationEvent.getOldFan())
                && hasText(accountNotificationEvent.getNewFan())) {
            service = updateAccountNotificationService;
        }else if(eventType.equalsIgnoreCase(ConsumerConstants.AccountNotificationConstants.UPDATE_ACCOUNT)
                && !hasText(accountNotificationEvent.getNewFan())
                && hasText(accountNotificationEvent.getTitanBan())) {
            service = provisionEnablerNotificationService;
        }else if(eventType.equalsIgnoreCase(ConsumerConstants.AccountNotificationConstants.CloseAccount)) {
            service =  closeAccountNotificationService;
        }

        return service;
    }

    private boolean hasText(String value) {
        return value != null && !value.trim().isEmpty();
    }
}