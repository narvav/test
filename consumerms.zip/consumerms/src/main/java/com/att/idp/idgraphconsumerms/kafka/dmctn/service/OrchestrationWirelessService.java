package com.att.idp.idgraphconsumerms.kafka.dmctn.service;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter;
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker;
import com.att.idp.idgraphconsumerms.kafka.model.AccountNotificationEvent;
import com.att.idp.idgraphconsumerms.model.SorOrchestrationRequest;
import com.att.idp.idgraphconsumerms.oracle.helpers.MemberServiceDBHelper;
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil;
import com.att.idp.idgraphconsumerms.utils.JsonService;
import com.att.mpsys.common.utils.CErrorDefs;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service("orchestrationWirelessService")
public class OrchestrationWirelessService  implements BaseService<AccountNotificationEvent> {

    private static final Logger logger = LoggerFactory.getLogger(OrchestrationWirelessService.class);

    @Value("${apiclient.rest.ur.serverUrl}")
    private String userRegServerUrl;

    @Value("${apiclient.rest.ur.wireless}")
    private String wirelessEndpoint;

    @Autowired
    private CosmosFailedEventsWriter cosmosFailedEventsWriter;

    @Autowired
    private GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker;

    private OrchestrationWirelessApiRestClient apiRestClient;
    private MemberServiceDBHelper memberServiceDBHelper;


    public OrchestrationWirelessService(OrchestrationWirelessApiRestClient apiRestClient, MemberServiceDBHelper memberServiceDBHelper) {
        this.apiRestClient = apiRestClient;
        this.memberServiceDBHelper = memberServiceDBHelper;
    }

    @Override
    public void execute(AccountNotificationEvent accountNotificationEvent) {
        String subscriberId = accountNotificationEvent.getBillingAccountNumber();
        String eventName = ConsumerConstants.GridGddnNotification.resolveEventName(accountNotificationEvent.getEventName());
        String sorId = ConsumerConstants.AccountNotificationConstants.SOR_ID_13;

        // Circuit breaker: if pending failed events exist for this account+category,
        // short-circuit directly to Cosmos to preserve sequenced processing order
        if (gddnFailedEventCircuitBreaker.shouldShortCircuit(subscriberId, eventName)) {
            logger.warn("OrchestrationWirelessService: Circuit breaker OPEN for BAN={}. Saving directly to Cosmos.",
                    ESAPI.encoder().encodeForHTML(subscriberId));
            SorOrchestrationRequest cbRequest = buildOutgoingRequest(accountNotificationEvent, sorId);
            FailedEventUtil.saveFailedEventCircuitOpen(
                    cosmosFailedEventsWriter, subscriberId,
                    JsonService.getJsonFromObject(cbRequest), eventName,
                    CErrorDefs.SYS_ERR, "Circuit breaker open — pending failed events exist",
                    this.wirelessEndpoint, ConsumerConstants.AccountNotificationConstants.WIRELESS, userRegServerUrl);
            return;
        }

        SorOrchestrationRequest outgoingRequest = null;
        try {
            outgoingRequest = buildOutgoingRequest(accountNotificationEvent, sorId);
            apiRestClient.sendPostRequest(this.wirelessEndpoint, outgoingRequest, eventName);
        } catch (Exception e) {
            logger.error("Error retrieving sorId for CTN: {}: {}", subscriberId, e.getMessage());
            outgoingRequest = buildOutgoingRequest(accountNotificationEvent, sorId);
                FailedEventUtil.saveFailedEventResolvingCategory(
                        cosmosFailedEventsWriter,
                        subscriberId,
                        JsonService.getJsonFromObject(outgoingRequest),
                        eventName,
                        CErrorDefs.SYS_ERR,
                        e.getMessage(),
                        this.wirelessEndpoint,
                        ConsumerConstants.AccountNotificationConstants.WIRELESS,
                        userRegServerUrl
                );
        }
    }

    private SorOrchestrationRequest buildOutgoingRequest(AccountNotificationEvent accountNotificationEvent, String sorId) {
        SorOrchestrationRequest outgoingRequest = new SorOrchestrationRequest();
        outgoingRequest.setSorInvariantId(accountNotificationEvent.getBillingAccountNumber());
        outgoingRequest.setContactEmail(accountNotificationEvent.getContactEmail());
        outgoingRequest.setSorId(sorId);
        outgoingRequest.setFirstName(accountNotificationEvent.getFirstName());
        outgoingRequest.setLastName(accountNotificationEvent.getLastName());
        outgoingRequest.setServiceName(ConsumerConstants.AccountNotificationConstants.MOBILITY);
        outgoingRequest.setIsConnectedCar(accountNotificationEvent.getIsConnectedCar());
        return outgoingRequest;
    }
}
