package com.att.idp.idgraphconsumerms.config;
import java.sql.SQLException;

import com.att.idp.idgraphconsumerms.appconfig.config.IDGraphAzureAppConfig;
import org.apache.tomcat.jdbc.pool.XADataSource;
import org.apache.tomcat.jdbc.pool.interceptor.QueryTimeoutInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.event.EventListener;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;

/**
 * The class responsible for defining database configuration.
 *
 * @author gs799f
 *
 */
@Configuration
@EnableTransactionManagement
public class DataBaseConfiguration {

    //private static final Logger log = Logger.getLogger(DataBaseConfiguration.class.getName());
    private static Logger log = LoggerFactory.getLogger(DataBaseConfiguration.class);

    @Value("${AES256KEY}")
    private String propAes256Key;

    @Value("${spring.datasource.url}")
    private String url;

    @Value("${spring.datasource.username}")
    private String dbUserName;

    @Value("${spring.datasource.password}")
    private String dbPassword;

    @Value("${spring.datasource.driver-class-name}")
    private String driverClassName;

    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    private IDGraphAzureAppConfig idGraphAzureAppConfig;

    /**
     * Defining entityManagerFactory with datasource details
     *
     * @return entityManagerFactoryBean instance of
     *         LocalContainerEntityManagerFactoryBean
     */
    @Bean
    @Primary
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {

        LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();

        try {
            entityManagerFactoryBean.setDataSource(xaDataSource());
        } catch (Exception e) {

            log.error("DBC1.1", "Error while creating xaDataSource:" + e.getMessage());
        }
        final HibernateJpaVendorAdapter jpaVendorAdapter = new HibernateJpaVendorAdapter();
        entityManagerFactoryBean.setJpaVendorAdapter(jpaVendorAdapter);
        entityManagerFactoryBean.setPackagesToScan("com.att.idp.idgraphconsumerms");

        return entityManagerFactoryBean;
    }

    @EventListener(RefreshScopeRefreshedEvent.class)
    public void onConfigurationRefresh() throws Exception {
        if(idGraphAzureAppConfig.isDataSourceRefreshEnabled()) {
            synchronized (this) {
                try {

                    XADataSource xaDataSource = applicationContext.getBean(XADataSource.class);

                    if (xaDataSource == null) {
                        log.error("XADataSource bean is not available in the application context.");
                        xaDataSource = xaDataSource();
                        ConfigurableApplicationContext configurableContext = (ConfigurableApplicationContext) applicationContext;
                        configurableContext.getBeanFactory().registerSingleton("xaDataSource", xaDataSource);
                    }

                    xaDataSource.setValidationQuery(idGraphAzureAppConfig.getValidationQuery());
                    xaDataSource.setInitialSize(idGraphAzureAppConfig.getInitialSize());
                    xaDataSource.setMaxActive(idGraphAzureAppConfig.getMaxSize());
                    xaDataSource.setMinIdle(idGraphAzureAppConfig.getMinSize());
                    xaDataSource.setTestOnBorrow(idGraphAzureAppConfig.isTestOnBorrow());
                    xaDataSource.setTestWhileIdle(idGraphAzureAppConfig.isTestWhileIdle());
                    xaDataSource.setJdbcInterceptors(QueryTimeoutInterceptor.class.getName() + "(queryTimeout=" + idGraphAzureAppConfig.getQueryTimeout() + ")");
                    xaDataSource.setMinEvictableIdleTimeMillis(idGraphAzureAppConfig.getEvictTime());
                    xaDataSource.setMaxWait(idGraphAzureAppConfig.getConnTimeout());

                    log.info("XADataSource dynamically updated with new values from appconfig: appconfig.version [{}], connTimeout [{}], maxSize [{}], queryTimeout [{}], validationQuery [{}], initialSize [{}], testWhileIdle [{}], testOnBorrow [{}], evictTime [{}], minSize [{}]", idGraphAzureAppConfig.getVersion(), idGraphAzureAppConfig.getConnTimeout(), idGraphAzureAppConfig.getMaxSize(), idGraphAzureAppConfig.getQueryTimeout(), idGraphAzureAppConfig.getValidationQuery(), idGraphAzureAppConfig.getInitialSize(), idGraphAzureAppConfig.isTestWhileIdle(), idGraphAzureAppConfig.isTestOnBorrow(), idGraphAzureAppConfig.getEvictTime(), idGraphAzureAppConfig.getMinSize());
                } catch (Exception e) {
                    log.error("Failed to update XADataSource  with new appconfig values. Retaining the old XADataSource.", e);
                }
            }
        }
        else {
            log.info("DataSource refresh is disabled. Retaining the existing DataSource configuration, appconfig.isDataSourceRefreshEnabled [{}] ", idGraphAzureAppConfig.isDataSourceRefreshEnabled());
        }
    }


    /**
     * Defining xaDataSource details.
     *
     * @return dataSource instance of HikariDataSource
     */
    @Bean(name = "xaDataSource")
    XADataSource xaDataSource() throws SQLException, Exception {

        XADataSource xaDataSource = null;
        xaDataSource = new XADataSource();
        xaDataSource.setUrl(url);
        xaDataSource.setUsername(dbUserName);
        xaDataSource.setPassword(ConsumerUtil.getAESDecryption(dbPassword, propAes256Key));
        xaDataSource.setDriverClassName(driverClassName);
        xaDataSource.setValidationQuery(idGraphAzureAppConfig.getValidationQuery());
        xaDataSource.setInitialSize(idGraphAzureAppConfig.getInitialSize());
        xaDataSource.setMaxActive(idGraphAzureAppConfig.getMaxSize());
        xaDataSource.setMinIdle(idGraphAzureAppConfig.getMinSize());
        xaDataSource.setTestOnBorrow(idGraphAzureAppConfig.isTestOnBorrow());
        xaDataSource.setTestWhileIdle(idGraphAzureAppConfig.isTestWhileIdle());
        xaDataSource.setJdbcInterceptors(QueryTimeoutInterceptor.class.getName() + "(queryTimeout=" + idGraphAzureAppConfig.getQueryTimeout() + ")");
        xaDataSource.setMinEvictableIdleTimeMillis(idGraphAzureAppConfig.getEvictTime());
        xaDataSource.setMaxWait(idGraphAzureAppConfig.getConnTimeout());

        return xaDataSource;
    }

    /**
     * Defining JpaTransactionManager.
     *
     * @return transactionManager instance of PlatformTransactionManager
     */
    @Bean
    public PlatformTransactionManager transactionManagerRef() {
        final JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
        return transactionManager;
    }

}