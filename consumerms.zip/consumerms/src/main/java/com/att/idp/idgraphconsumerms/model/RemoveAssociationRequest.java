package com.att.idp.idgraphconsumerms.model;

import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class RemoveAssociationRequest {
    private String guid;
    private List<Association> associationList;
    private String suppressNotification = "Y";

    public RemoveAssociationRequest(String memberNum, String individualId) {
        this.guid = memberNum;
        this.associationList = List.of(new Association("INDIVIDUAL", individualId));
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Association {
        private String serviceName;
        private String sorInvariantId;
    }
}