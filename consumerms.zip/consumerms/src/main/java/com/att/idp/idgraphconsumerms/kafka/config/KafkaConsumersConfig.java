package com.att.idp.idgraphconsumerms.kafka.config;
/**
 * Wrapper for Kafka consumer properties list.
 */
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.validation.annotation.Validated;

import java.util.Map;

@Data
@Validated
@RefreshScope
@ConfigurationProperties(prefix = "idgraph")
public class KafkaConsumersConfig {
    private Map<String,KafkaConsumerProperties> consumer;
}
