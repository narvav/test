package com.att.idp.idgraphconsumerms.model;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class RGActivationPlatformHandlerRequest extends PlatformHandlerRequest {
    private String rgActivated;
}
