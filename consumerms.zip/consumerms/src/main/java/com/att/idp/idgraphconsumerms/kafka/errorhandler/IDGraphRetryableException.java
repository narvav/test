package com.att.idp.idgraphconsumerms.kafka.errorhandler;

public class IDGraphRetryableException extends RuntimeException {

    public IDGraphRetryableException(String message) {
        super(message);
    }

    public IDGraphRetryableException(String message, Throwable cause) {
        super(message, cause);
    }
}
