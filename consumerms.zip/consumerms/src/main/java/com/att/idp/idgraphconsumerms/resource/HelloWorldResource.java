package com.att.idp.idgraphconsumerms.resource;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

/**
 * This interface, HelloWorldResource, defines the contract for a RESTful resource in the system.
 *
 * It is annotated with several JAX-RS and Swagger annotations to define its behavior:
 * - @Api("helloworld") indicates that this resource is part of the "helloworld" API in the Swagger documentation.
 * - @Path("/helloworld") sets the base path for all endpoints defined in this resource.
 * - @Produces({MediaType.APPLICATION_JSON}) specifies that the endpoints in this resource produce JSON responses.
 *
 * The interface contains one method:
 * - getHelloWorld is a POST endpoint that consumes and produces JSON. It is annotated with @ApiOperation to provide additional information about it in the Swagger documentation. The method takes a HttpServletRequest object as input and returns a Response object.
 */
@Tag(name = "helloworld")
@Path("/helloworld")
@Produces({MediaType.APPLICATION_JSON})
public interface HelloWorldResource {
	
	
	/**
	 * This method, getHelloWorld, is a POST endpoint that consumes and produces JSON.
	 *
	 * It is annotated with several JAX-RS and Swagger annotations to define its behavior:
	 * - @POST indicates that this method handles HTTP POST requests.
	 * - @Path("/getHelloWorld") sets the path for this endpoint.
	 * - @Consumes(MediaType.APPLICATION_JSON) specifies that this endpoint consumes JSON requests.
	 * - @Produces(MediaType.APPLICATION_JSON) specifies that this endpoint produces JSON responses.
	 * - @ApiOperation provides additional information about this endpoint in the Swagger documentation.
	 *
	 * The method takes a HttpServletRequest object as input, which represents the HTTP request received by the endpoint.
	 *
	 * @param request the HttpServletRequest object representing the HTTP request
	 * @return a Response object representing the HTTP response to be sent by the endpoint
	 */
	@POST
	@Path("/getHelloWorld")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(summary = "Hello World",
			 description = "Hello World")
	public Response getHelloWorld ( HttpServletRequest request);

}
