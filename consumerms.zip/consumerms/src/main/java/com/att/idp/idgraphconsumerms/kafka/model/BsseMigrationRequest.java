package com.att.idp.idgraphconsumerms.kafka.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * The BSSEMigrationRequest class represents a request to migrate a wireless user to bsse.
 *
 * It contains several fields that represent different aspects of a user association request:
 * - callingSystemId: A string representing the ID of the calling system.
 * - transactionName: A string representing the name of the transaction.
 * - ban: A string representing the ban. Its length must be between 1 and 40 characters.
 * - mode: A string representing the phase. Its length must be between 1 and 10 characters.
 * - individualId: A string representing the individualId. Its length must be between 1 and 255 characters.
 * - isExternalCall: A string representing whether this is an external call.
 * - idpTraceId: A string representing the IDP trace ID.
 * - unknownAttributes: A map containing any other attributes that are not part of the defined fields.
 *
 * The class also overrides the toString method to provide a JSON-style representation of the object.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BsseMigrationRequest implements Serializable {

    private String ban;
    private String individualId;
    private String productType;
    protected String migrationId;
    protected String sourceMarketCode;
    protected String retryCounter;
    private String idpTraceId;
    private String guid;
    private String passcodeVenc;
    private String targetBan;
    private String eventId;
}