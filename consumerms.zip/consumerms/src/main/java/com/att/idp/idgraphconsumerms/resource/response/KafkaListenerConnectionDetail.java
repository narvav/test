package com.att.idp.idgraphconsumerms.resource.response;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class KafkaListenerConnectionDetail {

    private final String listenerId;
    private final String consumerName;
    private final String topic;
    private final String bootstrapServers;
    private final String groupId;
    private final String securityProtocol;
    private final String saslMechanism;
    private final Boolean autoStartup;
    private final Integer concurrency;
    private final String autoOffsetReset;
    private final Integer maxPollRecords;
    private final Integer maxPollIntervalMs;
    private final Long authExceptionRetryInterval;
    private final String logicalCluster;
    private final String poolId;
    private final Boolean running;
    private final String status;
}
