package com.att.idp.idgraphconsumerms.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 *     "subscriber": "{\"id\":\"01990719-19cd-7e61-9913-0aec4eee48de\",\"@type\":\"subscriber\",
 *     \"subscriberType\":\"WIRELESS\",\"rootProductId\":\"28579146318454339\",\"status\":\"active\",
 *     \"statusChangeReason\":[{\"name\":\"WNS-NEW\",\"date\":\"2025-09-04T21:09:55.713Z\"}],\"billingAccount\":
 *     \"558601915486\",\"phoneNumber\":\"2293282653\",\"isSMSCapable\":\"Y\",\"preferredCTN\":false,
 *     \"createdOn\":\"2025-09-01T21:09:23.695Z\",\"updatedOn\":\"2025-09-04T21:09:55.713Z\",\"contactMedium\":
 *     [{\"mediumType\":\"postalAddress\",\"characteristic\":{\"contactType\":\"ppu\",\"city\":\"ALBANY\",
 *     \"country\":\"USA\",\"postCode\":\"31705-2873\",\"stateOrProvince\":\"GA\",\"street1\":
 *     \"1188 1/2 E BROAD AVE\",\"place\":{\"id\":\"00000DWI00\"}}}],\"activationDate\":
 *     \"2025-09-04T21:09:51.096Z\",\"serviceCharacteristic\":{\"networkFulfillmentDate\":
 *     \"2025-09-01T21:10:14.102Z\"}}",
 *     "key": "01990719-19cd-7e61-9913-0aec4eee48de",
 *     "resource": false
 */

/**
 * {
 *   "id": "01990719-19cd-7e61-9913-0aec4eee48de",    -- Subscriber ID
 *   "@type": "subscriber",
 *   "subscriberType": "WIRELESS",
 *   "rootProductId": "28579146318454339",
 *   "status": "active",       -- Subscriber Status
 *   "statusChangeReason": [
 *     {
 *       "name": "WNS-NEW",
 *       "date": "2025-09-04T21:09:55.713Z"
 *     }
 *   ],
 *   "billingAccount": "558601915486",
 *   "phoneNumber": "2293282653",    -- Subscriber Number//TODO: oldPhoneNumber from CG
 *   "isSMSCapable": "Y",
 *   "preferredCTN": false,
 *   "createdOn": "2025-09-01T21:09:23.695Z",
 *   "updatedOn": "2025-09-04T21:09:55.713Z",
 *   "contactMedium": [
 *     {
 *       "mediumType": "postalAddress",
 *       "characteristic": {
 *         "contactType": "ppu",
 *         "city": "ALBANY",
 *         "country": "USA",
 *         "postCode": "31705-2873",
 *         "stateOrProvince": "GA",
 *         "street1": "1188 1/2 E BROAD AVE",
 *         "place": {
 *           "id": "00000DWI00"
 *         }
 *       }
 *     }
 *   ],
 *   "activationDate": "2025-09-04T21:09:51.096Z",
 *   "serviceCharacteristic": {
 *     "networkFulfillmentDate": "2025-09-01T21:10:14.102Z"
 *   }
 * }
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public class Subscriber implements Serializable {

    @JsonProperty("id")
    private String id;

    @JsonProperty("@type")
    private String type;

    @JsonProperty("subscriberType")
    private String subscriberType;

    @JsonProperty("rootProductId")
    private String rootProductId;

    @JsonProperty("status")
    private String status;

    @JsonProperty("statusChangeReason")
    private List<StatusChangeReason> statusChangeReason;

    @JsonProperty("billingAccount")
    private String billingAccount;

    @JsonProperty("phoneNumber")
    private String phoneNumber;

    @JsonProperty("isSMSCapable")
    private String isSMSCapable;

    @JsonProperty("preferredCTN")
    private boolean preferredCTN;

    @JsonProperty("createdOn")
    private String createdOn;

    @JsonProperty("updatedOn")
    private String updatedOn;

    @JsonProperty("migratedOn")
    private String migratedOn;

    @JsonProperty("contactMedium")
    private List<ContactMedium> contactMedium;

    @JsonProperty("activationDate")
    private String activationDate;

    @JsonProperty("serviceCharacteristic")
    private ServiceCharacteristic serviceCharacteristic;

    @JsonProperty("idpTraceId")
    private String idpTraceId;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class StatusChangeReason {
        @JsonProperty("name")
        private String name;

        @JsonProperty("date")
        private String date;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ContactMedium {
        @JsonProperty("mediumType")
        private String mediumType;

        @JsonProperty("characteristic")
        private Characteristic characteristic;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Characteristic {
        @JsonProperty("contactType")
        private String contactType;

        @JsonProperty("city")
        private String city;

        @JsonProperty("country")
        private String country;

        @JsonProperty("postCode")
        private String postCode;

        @JsonProperty("stateOrProvince")
        private String stateOrProvince;

        @JsonProperty("street1")
        private String street1;

        @JsonProperty("place")
        private Place place;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Place {
        @JsonProperty("id")
        private String id;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ServiceCharacteristic {
        @JsonProperty("networkFulfillmentDate")
        private String networkFulfillmentDate;
    }

    public String getIdgraphStatus() {
        if (this.status == null) {
            return null;
        }

        switch (this.status.toLowerCase()) {
            case "active", "enabled":
                return "Enabled";
            case "suspended":
                return "Suspended";
            default:
                return null;
        }
    }
}