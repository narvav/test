package com.att.idp.idgraphconsumerms.cosmos.nosql.helpers;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraph.db.cosmos.entity.IdgraphFailedEvents;
import com.att.idp.idgraph.db.cosmos.helper.CosmosFailedEventsDBHelper;
import com.att.idp.idgraph.db.cosmos.util.Constants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails;
import com.att.idp.idgraphconsumerms.kafka.KafkaListenerAutomation;
import com.att.idp.idgraphconsumerms.utils.EventCategoryResolver;
import com.azure.cosmos.implementation.ServiceUnavailableException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;



@Service
public class CosmosFailedEventsWriter {

    private static final Logger logger = LoggerFactory.getLogger(CosmosFailedEventsWriter.class);
    private static final String sClassName = "CosmosFailedEventsWriter";

    @Value("${idg.processed-env-prefix}")
    private String processedEnvPrefix;

    @Value("${apiclient.rest.ua.serverUrl}")
    private String processedSvrUrl;

    @Value("${environment.region:east}")
    private String region;

    private final ConcurrentHashMap<String, AtomicInteger> entityCounters = new ConcurrentHashMap<>();

    @Autowired
    private CosmosFailedEventsDBHelper cosmosFailedEventsDBHelper;

    @Autowired
    private KafkaListenerAutomation kafkaListenerAutomation;

    //@Retryable(maxAttempts = 3, include = {ServiceUnavailableException.class}, backoff = @Backoff(delay = 2000))
    public void saveFailedEventsToCosmos(FailedEventDetails failedEventDetails) {
        IdgraphFailedEvents failedEvent = populateFailedEvent(failedEventDetails);

        String sMethodName = ".saveFailedEventsToCosmos.";

        logger.info("{}{}BM_01 : Storing Failed Event in Cosmos DB", sClassName, sMethodName);
        try {
            cosmosFailedEventsDBHelper.addFailedEvents(failedEvent, null);
        } catch (Exception e) {
            if (e instanceof ServiceUnavailableException) {
                logger.error("{}{}BM_02 : ERROR_CRITICAL Error storing Failed Event in Cosmos DB, stopping the listener: {}", sClassName, sMethodName, e);
                if(failedEventDetails.getEventName() != null && !failedEventDetails.getEventName().equalsIgnoreCase("OrderGraphSalesPivotFailure")) {

                    kafkaListenerAutomation.stopListener("idpMigrationNotificationListener");
                }else{
                    kafkaListenerAutomation.stopListener("orderEventsNotificationListener");
                }

            }
            logger.error("{}{}BM_02 : Error storing Failed Event in Cosmos DB: {}", sClassName, sMethodName, e);
        }
    }

    private IdgraphFailedEvents populateFailedEvent(FailedEventDetails failedEventDetails) {
        IdgraphFailedEvents failedEvent = new IdgraphFailedEvents();
        String now = ZonedDateTime.now(ZoneOffset.UTC).format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
        logger.info("{} populateFailedEvent: FailedEventDetails: {}", sClassName, failedEventDetails);

        failedEvent.setEventName(failedEventDetails.getEventName());
        failedEvent.setRequestPayload(failedEventDetails.getRequestPayload());
        failedEvent.setAccountNumber(failedEventDetails.getAccountId());
        failedEvent.setTraceId(MDC.get(ConsumerConstants.Keys.IDP_TRACE_ID));
        failedEvent.setAccountType(failedEventDetails.getErrorDetails().get(ConsumerConstants.ErrorDetails.ACCOUNT_TYPE));
        failedEvent.setErrorId(failedEventDetails.getErrorDetails().get(ConsumerConstants.ErrorDetails.ERROR_CODE));
        failedEvent.setResponsePayload(failedEventDetails.getErrorDetails().get(ConsumerConstants.ErrorDetails.ERROR_MESSAGE));
        failedEvent.setFailedEndpoint(failedEventDetails.getErrorDetails().get(ConsumerConstants.ErrorDetails.FAILED_ENDPOINT));
        failedEvent.setRetryCounter("0");
        failedEvent.setCreatedDate(now);
        failedEvent.setUpdatedDate(now);
        failedEvent.setUpdatedBy(MDC.get(ConsumerConstants.Keys.X_ATT_CLIENTID));
        failedEvent.setClientId(MDC.get(ConsumerConstants.Keys.X_ATT_CLIENTID));
        failedEvent.setProcessedEnvPrefix(processedEnvPrefix);
        String svrUrl = (failedEventDetails.getProcessedSvrUrl() != null && !failedEventDetails.getProcessedSvrUrl().isEmpty())
                ? failedEventDetails.getProcessedSvrUrl() : processedSvrUrl;
        failedEvent.setProcessedSvrUrl(svrUrl);
        // Use status from FailedEventDetails if provided; otherwise default to FAILED
        String status = failedEventDetails.getStatus();
        failedEvent.setStatus(status != null && !status.isEmpty()
                ? status
                : com.att.idp.idgraph.db.cosmos.entity.FailedEventStatus.FAILED.name());

        // Generate sequenceNumber: <epochMillis>.<region>.<5-digit-counter>
        // Per design doc §Sequence Number Format — same contract as KafkaEventRecord
        String entityKey = (failedEventDetails.getAccountId() != null ? failedEventDetails.getAccountId() : "unknown")
                + "|" + (failedEventDetails.getEventName() != null ? failedEventDetails.getEventName() : "unknown");
        failedEvent.setSequenceNumber(generateSequenceNumber(entityKey));

        // Resolve eventCategory from the event name or from explicit value on FailedEventDetails
        String eventCategory = failedEventDetails.getEventCategory();
        if (eventCategory == null || eventCategory.isEmpty()) {
            eventCategory = EventCategoryResolver.resolve(failedEventDetails.getEventName()).orElse(null);
        }
        failedEvent.setEventCategory(eventCategory);

        return failedEvent;
    }

    /**
     * Generates a deterministic, lexicographically sortable sequence number.
     * Format: {@code <epochMillis>.<region>.<5-digit-counter>}
     * Example: {@code 1749408600000.east.00001}
     * <p>
     * Reuses the same contract as {@code ResilientEventPublisher.generateSequenceNumber()}.
     * </p>
     */
    private String generateSequenceNumber(String entityKey) {
        long epochMillis = System.currentTimeMillis();
        AtomicInteger counter = entityCounters.computeIfAbsent(entityKey, k -> new AtomicInteger(0)); //TODO
        int count = counter.incrementAndGet();
        return epochMillis + "." + region + "." + String.format("%05d", count);
    }
}
