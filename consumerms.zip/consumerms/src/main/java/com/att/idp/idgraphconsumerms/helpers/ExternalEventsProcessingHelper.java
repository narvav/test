package com.att.idp.idgraphconsumerms.helpers;

import com.att.idp.idgraph.events.service.ResilientEventPublisher;
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.argument.StructuredArguments;
import org.apache.commons.lang3.StringUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;

/**
 * Helper service that encapsulates the processing logic for external IDGraph events
 * consumed from Kafka. Determines target downstream systems for each event and
 * publishes notifications via {@link ResilientEventPublisher}.
 */
@Slf4j
@Service
@RequiredArgsConstructor
@Configuration
@PropertySource(value = "file:opt/ajsc/etc/config/consumer.properties")
public class ExternalEventsProcessingHelper {

    private static final String CLASS_NAME = "ExternalEventsProcessingHelper";
    public static final Logger logger = LoggerFactory.getLogger(ExternalEventsProcessingHelper.class);
    private static final String EVENTS_DATA_KEY = "eventsData";
    private static final String EVENTS_LIST_INFO= "eventsListInfo";
    private static final String DISTRIBUTION_EVENT_PROPERTIES = "distributionevent.properties";
    private static final String MEMBER_INFO_KEY = "memberInfo";
    private static final java.util.regex.Pattern MEMBER_LIST_EVENT_PATTERN = java.util.regex.Pattern.compile(
            "AddMemberList|UpdateMemberList|DeleteMemberList|AddServicesList|AddRemoveServicesList|RemoveServicesList|UpdateServicesStatusList|UpdateServicesList");

    @Value(value = "${spring.cloud.stream.bindings.yahooNotifications-out-0.destination}")
    private String yahooTopicName;

    @Value(value = "${spring.cloud.stream.bindings.halocNotifications-out-0.destination}")
    private String halocTopicName;

    @Value(value = "${spring.cloud.stream.bindings.g2Notifications-out-0.destination}")
    private String g2TopicName;

    @Value(value = "${spring.cloud.stream.bindings.allOtherExtSysNotifications-out-0.destination}")
    private String allOtherExtSysTopicName;

    @Value(value = "${spring.cloud.stream.bindings.allOtherExtSysNotifications-out-0.destination}")
    private String bbnmsTopicName;

    @Value(value = "${spring.cloud.stream.bindings.subsvcNotifications-out-0.destination}")
    private String subSvcTopicName;


    @Autowired
    private IDGraphYahooRulesHelper idGraphYahooRulesHelper;
    @Autowired
    private  IDGraphG2RulesHelper idGraphG2RulesHelper;
    @Autowired
    private  IDGraphLSCRMRulesHelper idGraphLSCRMRulesHelper;
    @Autowired
    private  IDGraphHaloCRulesHelper idGraphHaloCRulesHelper;
    @Autowired
    private NotificationEventProcessorHelper notificationEventProcessorHelper;

    @Autowired
    private IDGraphBbnmsRulesHelper idGraphBbnmsRulesHelper;

    @Autowired
    private IDGraphSubSvcRulesHelper idGraphSubSvcRulesHelper;

    @Autowired
    private IDGraphIdgraphRulesHelper idGraphIdgraphRulesHelper;

    @Autowired
    private IDGraphCSIRulesHelper idGraphCSIRulesHelper;

    @Autowired
    private  ResilientEventPublisher resilientEventPublisher;

    /**
     * Processes a map containing external events and publishes messages to the configured downstream systems.
     * Expected structure: key "eventsData" referencing a List of Map events.
     * @param inputMap map containing event list
     */
    @SuppressWarnings("unchecked")
    public void processExternalEvents(Map<String, Object> inputMap) {
          final String sMethodName = ".processExternalEvents";

          try {
              if (!inputMap.containsKey(EVENTS_DATA_KEY)) {
                  logger.info("{}{} EEPH.PEE.01: Main hash key eventsData not found in input, skipping processing", CLASS_NAME, sMethodName);
                  return;
              }

                List<Map<String, Object>> eventsList;
                      Object eventsData = inputMap.get(EVENTS_DATA_KEY);
              if (eventsData instanceof List) {
                  eventsList = (List<Map<String, Object>>) eventsData;
              } else if (eventsData instanceof Map) {
                  eventsList = List.of((Map<String, Object>) eventsData);
              } else {
                  String unsupportedType = eventsData != null ? eventsData.getClass().getName().replaceAll("[\\r\\n]", " ") : "null";
                  logger.info("{}{} EEPH.PEE.02: Unsupported eventsData type: {}", CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(unsupportedType));
                  return;
              }

              Properties eventProps = loadEventDistributionProperties();
              for (Map<String, Object> event : eventsList) {
                  String eventName = (String) event.get("eventname");
                  if (StringUtils.isBlank(eventName)) {
                      logger.debug("{}{} EEPH.PEE.03: Event without eventname encountered. Skipping.", CLASS_NAME, sMethodName);
                      continue;
                  }
                  if ("NotificationEvent".equals(eventName)) {
                      logger.info("{}{} EEPH.PEE.04: Processing the Notification event : {}{}", CLASS_NAME, sMethodName, ESAPI.encoder().encodeForHTML(eventName), StructuredArguments.entries(event));
                      notificationEventProcessorHelper.processNotificationEvent(event, inputMap);
                      logger.info("{}{} EEPH.PEE.05: Processed the Notification event : {}", CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(eventName));
                  }

                  if ("NotificationEventList".equals(eventName)) {
                      logger.info("{}{} EEPH.PEE.06: Processing NotificationEventList", CLASS_NAME, sMethodName);
                      Object eventsListInfoObj = event.get(EVENTS_LIST_INFO);
                      if (eventsListInfoObj instanceof List) {
                          List<Map<String, Object>> eventsListInfo = (List<Map<String, Object>>) eventsListInfoObj;
                          for (Map<String, Object> nestedEvent : eventsListInfo) {
                              String nestedEventName = (String) nestedEvent.get("eventname");
                              if ("NotificationEvent".equals(nestedEventName)) {
                                  logger.info("{}{} EEPH.PEE.07: Processing nested NotificationEvent from NotificationEventList", CLASS_NAME, sMethodName);
                                  notificationEventProcessorHelper.processNotificationEvent(nestedEvent, inputMap);
                                  logger.info("{}{} EEPH.PEE.08: Processed nested NotificationEvent from NotificationEventList", CLASS_NAME, sMethodName);
                              }
                          }
                      } else {
                          logger.debug("{}{} EEPH.PEE.09: NotificationEventList has no valid eventsListInfo", CLASS_NAME, sMethodName);
                      }
                  }

                  String systems = eventProps.getProperty(eventName);
                  if (systems != null) {
                      String[] systemList = systems.split("\\|");
                      event.put("idpTraceId", inputMap.get("transactionId") != null ? inputMap.get("transactionId").toString() : "");
                      // Process memberInfo for List-type events
                      if (MEMBER_LIST_EVENT_PATTERN.matcher(eventName).matches()) {
                          Object memberInfoObj = event.get(MEMBER_INFO_KEY);
                          if (memberInfoObj instanceof List) {
                              List<Map<String, Object>> memberInfoList = (List<Map<String, Object>>) memberInfoObj;
                              if (!memberInfoList.isEmpty()) {
                                  logger.info("{}{} EEPH.PEE.10: Processing {} memberInfo entries for event: {}",
                                          CLASS_NAME, sMethodName, memberInfoList.size(), ConsumerUtil.sanitizeForLog(eventName));
                                  //check memberInfo length and greater than 1 then only loop it
                                  for (Map<String, Object> memberInfo : memberInfoList) {
                                      if (memberInfo == null) {
                                          logger.debug("{}{} EEPH.PEE.10A: Skipping null memberInfo entry for event: {}", CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(eventName));
                                          continue;
                                      }
                                      HashMap<String, Object> memberInfoRequest = new HashMap<>(event);
                                      memberInfoRequest.remove(MEMBER_INFO_KEY);
                                      memberInfoRequest.put(MEMBER_INFO_KEY, List.of(memberInfo));
                                      memberInfoRequest.put("idpTraceId", inputMap.get("transactionId") != null ? inputMap.get("transactionId").toString() : "");
                                      for (String system : systemList) {
                                          dispatchToDestination(system.trim(), eventName, memberInfoRequest);
                                      }
                                  }
                              }
                          }
                      } else {
                          logger.debug("{}{} EEPH.PEE.11: Dispatching non-member-list event {} to configured systems", CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(eventName));
                          for (String system : systemList) {
                              dispatchToDestination(system.trim(), eventName, event);
                          }
                      }
                  }
              }
          } catch (Exception exception) {
              String errorMessage = exception.getMessage() != null ? exception.getMessage().replaceAll("[\\r\\n]", " ") : "null";
              logger.error("{}{} EEPH.PEE.99: Exception while processing external events: {}", CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(errorMessage));
          }
    }

    /**
     * Loads event distribution properties from the distributionevent.properties file on the classpath.
     * This method attempts to read the properties file and returns a Properties object containing
     * the event-to-system mapping configuration. If the file is not found or cannot be loaded,
     * an error is logged and an empty Properties object is returned.
     * @return Properties containing event distribution mappings; empty if file is missing or unreadable
     */
    Properties loadEventDistributionProperties() {
        final String sMethodName = ".loadEventDistributionProperties";
        Properties eventProps = new Properties();
        try (InputStream input = getClass().getClassLoader().getResourceAsStream(DISTRIBUTION_EVENT_PROPERTIES)) {
            if (input != null) {
                eventProps.load(input);
            }else {
                logger.error("{}{}  EEPH.LEDP.01: distributionevent.properties file not found on classpath", CLASS_NAME, sMethodName);
            }
        } catch (IOException ex) {
            String errorMsg = ex.getMessage() != null ? ex.getMessage().replaceAll("[\\r\\n]", " ") : "null";
            logger.error("{}{}  EEPH.LEDP.02: Failed to load distributionevent.properties : {}", CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(errorMsg));
        }
            return eventProps;

    }

    /**
     * Dispatches the event to the appropriate downstream system based on the provided system identifier.
     * For each supported system, processes the event using the corresponding rules helper and publishes
     * a notification if processing is successful.
     * @param system    the target downstream system identifier (e.g., "YAHOO", "G2", "LSCRM", "HALOC")
     * @param eventName the name of the event being processed
     * @param event     the event data as a map
     */
    private void dispatchToDestination(String system, String eventName, Map<String, Object> event) {
        switch (system) {
            case "YAHOO":
                if (idGraphYahooRulesHelper.processYahooMessage(event)) {
                    publishEventToYahooTopic( eventName, event);
                }
                break;
            case "G2":
                if (idGraphG2RulesHelper.processG2Message(event)) {
                    publishEventToG2Topic(eventName, event);
                }
                break;
            case "LSCRM":
                if (idGraphLSCRMRulesHelper.processLSCRMMessage(event)) {
                    publishEventToLscrmTopic(eventName, event);
                }
                break;
            case "HALOC":
                if (idGraphHaloCRulesHelper.processHaloCMessage(event)) {
                    publishEventToHalocTopic(eventName, event);
                }
                break;
            case "BBNMS":
                if (idGraphBbnmsRulesHelper.processBbnmsMessage(event)) {
                    String mappedEventName = event.get("eventname") != null ? event.get("eventname").toString() : eventName;
                    publishEventToBBNMSTopic(mappedEventName, event);
                }
                break;
            case "SUBSVC":
                if (idGraphSubSvcRulesHelper.processSubSvcMessage(event)) {
                    publishEventToSubSvcTopic(eventName, event);
                }
                break;
            case "IDGRAPH":
                if (idGraphIdgraphRulesHelper.processIdgraphMessage(event)) {
                    String mappedEventName = event.get("eventname") != null ? event.get("eventname").toString() : eventName;
                    publishEventToIdgraphTopic(mappedEventName, event);
                }
                break;
            case "CSI":
                if (idGraphCSIRulesHelper.processCSIMessage(event)) {
                    publishEventToCSITopic(eventName, event);
                }
                break;
            default:
        }
    }

    /**
     * Publishes an event to the Yahoo topic using the configured event publisher.
     * Encodes all log variables to prevent log injection.
     * @param eventName the name of the event to publish; must not be null
     * @param event     the event data as a map
     */
    private void publishEventToYahooTopic( String eventName, Map<String, Object> event ){
    final String sMethodName = ".publishEventToYahooTopic.";
        String binding = "yahooNotifications";
        String system="yahoo";
        String bindingKey=getBinderKey(system, event);

        if (eventName == null) {
            log.warn("{}{} : publishEventToYahooTopic eventName is null",CLASS_NAME, sMethodName);
            return;
        }
        log.info("{}{} EEPH.PETYT.1 :publish event with partitionKey:{} to Yahoo topic : {}",CLASS_NAME, sMethodName, bindingKey, ConsumerUtil.sanitizeForLog(yahooTopicName));
        boolean published = resilientEventPublisher.sendWithFallback(binding, "Yahoo", bindingKey, event);
        if (published) {
            log.info("{}{} EEPH.PETYT.2 Published event to Yahoo topic: {}",CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(yahooTopicName));
        } else {
            log.warn("{}{} EEPH.PETYT.3 Yahoo event saved to Cosmos DB fallback: {}",CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(yahooTopicName));
        }
    }

    /**
     * Publishes an event to the HALOC topic using the configured event publisher.
     * Encodes all log variables to prevent log injection.
     * @param eventName the name of the event to publish; must not be null
     * @param event     the event data as a map
     */
    private void publishEventToHalocTopic(String eventName, Map<String, Object> event){
    final String sMethodName = ".publishEventToHalocTopic";
        String binding = "halocNotifications";
        String system="haloc";
        String bindingKey=getBinderKey(system, event);

        if (eventName == null) {
            log.warn("{}{} : publishEventToHalocTopic eventName is null",CLASS_NAME, sMethodName);
            return;
        }
        log.info("{}{} EEPH.PETHT.1 :publishing event with partitionKey:{}  to  Haloc topic : {}",CLASS_NAME, sMethodName, bindingKey, ConsumerUtil.sanitizeForLog(halocTopicName));
        boolean published = resilientEventPublisher.sendWithFallback(binding, "Haloc", bindingKey, event);
        if (published) {
            log.info("{}{} EEPH.PETHT.2 Published event to Haloc topic: {}",CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(halocTopicName));
        } else {
            log.warn("{}{} EEPH.PETHT.3 Haloc event saved to Cosmos DB fallback: {}",CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(halocTopicName));
        }
    }

    /**
     * Publishes an event to the G2 topic using the configured event publisher.
     * This method sends the provided event to the "g2Notifications" binding,
     * which is mapped to the G2 downstream system. All log statements sanitize the topic name
     * to prevent log injection and ensure no PII/SPI is exposed. If {@code eventName} is {@code null},
     * the method logs a warning and returns without publishing.
     * @param eventName the name of the event to publish; must not be {@code null}
     * @param event     the event data as a map
     */
    private void publishEventToG2Topic(String eventName, Map<String, Object> event){
        final String sMethodName = ".publishEventToG2Topic";
        String binding = "g2Notifications";
        String system="g2";
        String bindingKey=getBinderKey(system, event);

        if (eventName == null) {
            log.warn("{}{} : publishEventToG2Topic eventName is null",CLASS_NAME, sMethodName);
            return;
        }
        log.info("{}{} EEPH.PETPT.1 :publishing event with partitionKey:{} to G2 topic : {}",CLASS_NAME, sMethodName, bindingKey, ConsumerUtil.sanitizeForLog(g2TopicName));
        boolean published = resilientEventPublisher.sendWithFallback(binding, "G2", bindingKey, event);
        if (published) {
            log.info("{}{} EEPH.PETPT.2 Published event to G2 topic: {}",CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(g2TopicName));
        } else {
            log.warn("{}{} EEPH.PETPT.3 G2 event saved to Cosmos DB fallback: {}",CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(g2TopicName));
        }
    }

    /**
     * Publishes an event to the LSCRM topic using the configured event publisher.
     * This method sends the provided event to the "allOtherExtSysNotifications" binding,
     * which is mapped to the LSCRM downstream system. All log statements sanitize the topic name
     * to prevent log injection and ensure no PII/SPI is exposed. If {@code eventName} is {@code null},
     * the method logs a warning and returns without publishing.
     * @param eventName the name of the event to publish; must not be {@code null}
     * @param event     the event data as a map
     */
    private void publishEventToLscrmTopic(String eventName, Map<String, Object> event){
        final String sMethodName = ".publishEventToLscrmTopic";
        String binding = "allOtherExtSysNotifications";
        String system="lscrm";
        String bindingKey=getBinderKey(system, event);

        if (eventName == null) {
            log.warn("{}{} : publishEventToLscrmTopic eventName is null",CLASS_NAME, sMethodName);
            return;
        }


        log.info("{}{} EEPH.PETLT.1 :publishing LSCRM event with partitionKey:{} to allotherextsystems topic : {}",CLASS_NAME, sMethodName, bindingKey, ConsumerUtil.sanitizeForLog(allOtherExtSysTopicName));
        boolean published = resilientEventPublisher.sendWithFallback(binding, "LSCRM", bindingKey, event);
        if (published) {
            log.info("{}{} EEPH.PETLT.2 Published LSCRM event to allotherextsystems topic: {}",CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(allOtherExtSysTopicName));
        } else {
            log.warn("{}{} EEPH.PETLT.3 LSCRM event saved to Cosmos DB fallback: {}",CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(allOtherExtSysTopicName));
        }
    }

    /**
     * Publishes a transformed BBNMS event using BBNMS binding.
     * @param eventName remapped BBNMS event name
     * @param event     event payload
     */
    private void publishEventToBBNMSTopic(String eventName, Map<String, Object> event){
        final String sMethodName = ".publishEventToBBNMSTopic";
        String binding = "allOtherExtSysNotifications";
        String system="bbnms";
        String bindingKey=getBinderKey(system, event);

        if (eventName == null) {
            log.warn("{}{} : publishEventToBBNMSTopic eventName is null", CLASS_NAME, sMethodName);
            return;
        }
        log.info("{}{} EEPH.PETBT.1 :publishing BBNMS event with partitionKey:{} to topic : {}", CLASS_NAME, sMethodName, bindingKey, bbnmsTopicName);
        boolean published = resilientEventPublisher.sendWithFallback(binding, "BBNMS", eventName, event);
        if (published) {
            log.info("{}{} EEPH.PETBT.2 Published BBNMS event to topic: {}", CLASS_NAME, sMethodName, bbnmsTopicName);
        } else {
            log.warn("{}{} EEPH.PETBT.3 BBNMS event saved to Cosmos DB fallback: {}", CLASS_NAME, sMethodName, bbnmsTopicName);
        }
    }

    /**
     * Publishes the transformed SUBSVC envelope to SUBSVC topic.
     * @param eventName source event name used as event key
     * @param event     transformed SUBSVC payload
     */
    private void publishEventToSubSvcTopic(String eventName, Map<String, Object> event){
        final String sMethodName = ".publishEventToSubSvcTopic";
        String binding = "subsvcNotifications";
        String system="subsvc";
        String bindingKey=getBinderKey(system, event);

       if (eventName == null) {
            log.warn("{}{} : publishEventToSubSvcTopic eventName is null", CLASS_NAME, sMethodName);
            return;
        }
        HashMap<String, Object> subSvcPayload = idGraphSubSvcRulesHelper.transformToSubSvcPayload(event);

        log.info("{}{} EEPH.PETST.1 :publishing SUBSVC event with partitionKey:{} to topic : {}", CLASS_NAME, sMethodName, bindingKey, subSvcTopicName);
        boolean published = resilientEventPublisher.sendWithFallback(binding, "SUBSVC", bindingKey, subSvcPayload);
        if (published) {
            log.info("{}{} EEPH.PETST.2 Published SUBSVC event to topic: {}", CLASS_NAME, sMethodName, subSvcTopicName);
        } else {
            log.warn("{}{} EEPH.PETST.3 SUBSVC event saved to Cosmos DB fallback: {}", CLASS_NAME, sMethodName, subSvcTopicName);
        }
    }

    /**
     * Publishes a CSI event to the allOtherExtSysNotifications queue.
     * @param eventName the event name used as event key
     * @param event     event payload
     */
    private void publishEventToCSITopic(String eventName, Map<String, Object> event) {
        final String sMethodName = ".publishEventToCSITopic";
        String binding = "allOtherExtSysNotifications";
        String system = "csi";
        String bindingKey = getBinderKey(system, event);

        if (eventName == null) {
            log.warn("{}{} : publishEventToCSITopic eventName is null", CLASS_NAME, sMethodName);
            return;
        }
        log.info("{}{} EEPH.PETCSIT.1 :publishing CSI event with partitionKey:{} to allotherextsystems topic : {}", CLASS_NAME, sMethodName, bindingKey, ConsumerUtil.sanitizeForLog(allOtherExtSysTopicName));
        boolean published = resilientEventPublisher.sendWithFallback(binding, "CSI", bindingKey, event);
        if (published) {
            log.info("{}{} EEPH.PETCSIT.2 Published CSI event to allotherextsystems topic: {}", CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(allOtherExtSysTopicName));
        } else {
            log.warn("{}{} EEPH.PETCSIT.3 CSI event saved to Cosmos DB fallback: {}", CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(allOtherExtSysTopicName));
        }
    }

    /**
     * Publishes an IDGRAPH event to the allOtherExtSysNotifications queue.
     * @param eventName the event name used as event key
     * @param event     event payload
     */
    private void publishEventToIdgraphTopic(String eventName, Map<String, Object> event){
        final String sMethodName = ".publishEventToIdgraphTopic";
        String binding = "allOtherExtSysNotifications";
        String system = "idgraph";
        String bindingKey=getBinderKey(system, event);

        if (eventName == null) {
            log.warn("{}{} : publishEventToIdgraphTopic eventName is null", CLASS_NAME, sMethodName);
            return;
        }
        log.info("{}{} EEPH.PETIIT.1 :publishing IDGRAPH event with partitionKey:{} to topic : {}", CLASS_NAME, sMethodName, bindingKey, ConsumerUtil.sanitizeForLog(allOtherExtSysTopicName));
        boolean published = resilientEventPublisher.sendWithFallback(binding, "IDGRAPH", eventName, event);
        if (published) {
            log.info("{}{} EEPH.PETIIT.2 Published IDGRAPH event to topic: {}", CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(allOtherExtSysTopicName));
        } else {
            log.warn("{}{} EEPH.PETIIT.3 IDGRAPH event saved to Cosmos DB fallback: {}", CLASS_NAME, sMethodName, ConsumerUtil.sanitizeForLog(allOtherExtSysTopicName));
        }
    }

    /**
     * Determines the partition/routing key for the given system from the event payload.
     * Priority order varies by system — see switch expression for per-system precedence.
     *
     * @param system lowercase system identifier (e.g., "yahoo", "g2", "haloc", "lscrm")
     * @param event  event payload map
     * @return the resolved binder key, or {@code null} if no applicable field is present
     */
    public String getBinderKey(String system, Map<String, Object> event) {
        var ban           = stringValue(event, "ban");
        var handle        = stringValue(event, "handle");
        var domain        = stringValue(event, "domain");
        var hashKey       = stringValue(event, "hashKey");
        var hashKeyAlt    = stringValue(event, "hash_key");
        var slidMemberNum = stringValue(event, "slid_member_num");
        var parentHandle  = stringValue(event, "parentHandle");
        var parentDomain  = stringValue(event, "parentDomain");

        String userId = null;
        String parentUserId = null;

        if (handle != null && domain !=null)
            userId = handle + "@" + domain;
        else if (handle != null)
            userId = handle;

        if(parentHandle != null && parentDomain != null)
            parentUserId = parentHandle + "@" + parentDomain;
        else if (parentHandle != null)
            parentUserId = parentHandle;

        return switch (system) {
            case "yahoo" -> {
                if (hashKey != null)       yield hashKey;
                if (slidMemberNum != null) yield slidMemberNum;
                if (parentUserId != null)  yield parentUserId;
                yield userId;
            }
            case "haloc" -> {
                if (hashKey != null)       yield hashKey;
                if (hashKeyAlt != null)    yield hashKeyAlt;
                if (slidMemberNum != null) yield slidMemberNum;
                if (parentUserId != null)  yield parentUserId;
                yield userId;
            }
            case "g2", "csi" -> userId;
            case "lscrm", "idgraph", "bbnms", "subsvc" -> ban != null ? ban : userId;
            default -> system;
        };
    }

    /**
     * Safely extracts and converts a value from the event map to a {@link String}.
     *
     * @param event event payload map
     * @param key   the map key to look up
     * @return string representation of the value, or {@code null} if the key is absent or its value is null
     */
    private String stringValue(Map<String, Object> event, String key) {
        return Optional.ofNullable(event.get(key)).map(Object::toString).orElse(null);
    }

  }
