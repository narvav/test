package com.att.idp.idgraphconsumerms.bsse.reverse;

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants;
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosMigrationStatusDBHelper;
import com.att.idp.idgraphconsumerms.kafka.model.ReverseMigratedInboundDataEvent;
import com.att.idp.idgraphconsumerms.request.validator.RequestValidator;
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;

import java.util.Random;

/**
 * Processor for Bsse Reverse Migration Event logic shared by OAuth and Plain listeners.
 */
@Component
public class BsseReverseMigrationEventProcessor {
    private static final Logger logger = LoggerFactory.getLogger(BsseReverseMigrationEventProcessor.class);
    private final ObjectMapper objectMapper;
    private final RequestValidator requestValidator;
    private BsseReverseMigrationService bsseReverseMigrationService;
    private CosmosMigrationStatusDBHelper cosmosMigrationStatusDBHelper;


    public BsseReverseMigrationEventProcessor(RequestValidator requestValidator, BsseReverseMigrationService bsseReverseMigrationService, CosmosMigrationStatusDBHelper cosmosMigrationStatusDBHelper) {
        this.objectMapper = new ObjectMapper();
        this.objectMapper.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
        this.objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        this.objectMapper.enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
        this.requestValidator = requestValidator;
        this.bsseReverseMigrationService = bsseReverseMigrationService;
        this.cosmosMigrationStatusDBHelper = cosmosMigrationStatusDBHelper;
    }

    public void processEvent(String msg, MessageHeaders messageHeaders, Acknowledgment ack) throws JsonProcessingException {
        long startTm = System.currentTimeMillis();
        String traceId = generateTraceId();
        MDC.put(ConsumerConstants.Keys.IDP_TRACE_ID, traceId);
        MDC.put(ConsumerConstants.Keys.X_ATT_CLIENTID, ConsumerConstants.BsseMigration.CLIENT_BSSEMIPAAS);
        logger.info("WEB000 : BsseReverseMigration consumer initiation: {}", ConsumerUtil.encode(msg));


        // Parse only eventType first
        String eventType = null;
        try {
            JsonNode rootNode = objectMapper.readTree(msg);
            eventType = rootNode.path("eventType").asText();
        } catch (Exception e) {
            logger.error("Failed to parse eventType from message, acknowledging the message: {}", ConsumerUtil.encode(e.getMessage()));
            ack.acknowledge();
            return;
        }

        if (ConsumerConstants.BsseReverseMigration.BSSE_REVERSE_MIGRATION_EVENT_TYPE.equalsIgnoreCase(eventType)) {
            ReverseMigratedInboundDataEvent reverseMigratedDataEvent = objectMapper.readValue(msg, ReverseMigratedInboundDataEvent.class);
            logger.info("Received BsseReverseMigration Event: headers={}, payload={}", ConsumerUtil.encode(messageHeaders.toString()), ConsumerUtil.encode(reverseMigratedDataEvent.toString()));

            cosmosMigrationStatusDBHelper.storeBSSEMigrationStatus(reverseMigratedDataEvent, msg);

            String validationError = BsseReverseMigrationEventValidator.validateRequiredFields(reverseMigratedDataEvent);
            if (validationError != null) {
                logger.error("Validation failed for BsseReverseMigration event: {}",
                        ConsumerUtil.encode(validationError));
                ack.acknowledge();
                return;
            }

            bsseReverseMigrationService.callBackendAPI(reverseMigratedDataEvent);
        } else {
            logger.error("Unsupported eventType received in BsseReverseMigrationEvent: {}", ConsumerUtil.encode(eventType));
        }
        String sTimeTaken = ConsumerUtil.getElapsedTimeInSecs(startTm) + " seconds";
        logger.info("WEB999 : Total time taken : {} BsseReverseMigration consumer Response : {}", ConsumerUtil.encode(sTimeTaken), ConsumerUtil.encode(msg));
        logger.info("Committing the offset for the message");
        ack.acknowledge();
    }

    private String generateTraceId() {
        Random r = new Random();
        String spanId = Long.toHexString(r.nextLong());
        return spanId + ":" + spanId + ":0:0";
    }
}
