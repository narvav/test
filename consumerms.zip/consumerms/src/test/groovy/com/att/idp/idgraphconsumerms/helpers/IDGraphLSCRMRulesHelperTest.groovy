package com.att.idp.idgraphconsumerms.helpers

import com.att.idp.component.CompTestBase
import com.fasterxml.jackson.core.type.TypeReference
import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class IDGraphLSCRMRulesHelperTest extends Specification {

	static Map<String, Object> readJsonFileToMap(String filePath) throws IOException {
		ObjectMapper objectMapper = new ObjectMapper()
		try (InputStream inputStream = CompTestBase.class.getClassLoader().getResourceAsStream(filePath)) {
			if (inputStream == null) {
				throw new IOException("File not found: " + filePath)
			}
			return objectMapper.readValue(inputStream, new TypeReference<Map<String, Object>>() {})
		}
	}

	static String readJsonFileAsString(String filePath) throws IOException {
		try (InputStream inputStream = CompTestBase.class.getClassLoader().getResourceAsStream(filePath)) {
			if (inputStream == null) {
				throw new IOException("File not found: " + filePath)
			}
			return new String(inputStream.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8)
		}
	}


	def helper = new IDGraphLSCRMRulesHelper()

	def setup() {
		ReflectionTestUtils.setField(helper, "lscrmSubEventsAddMember", 'NewReg|NewRegHSIA')
		ReflectionTestUtils.setField(helper, "lscrmSubEventsUpdateMember", 'SyncClarifyCRM')
		ReflectionTestUtils.setField(helper, "lscrmSubEventsAddRemoveSvcList", 'ExistingReg|ExistingRegNotInYahoo')
		ReflectionTestUtils.setField(helper, "lscrmSubEventsCreateInteraction", 'DialPwdReset')

	}
		def "processLSCRMMessage returns error when eventsData is null or empty"() {
			when:
			def resultNull = helper.processLSCRMMessage(null)

			then:
			resultNull == false
		}

		def "processLSCRMMessage returns error when BAN is missing in event"() {
			given:
			def event = [eventName: "AddMember", subEvent: "validSubEvent", parent_child_ind: "P"]
			def eventsData = [event]

			when:
			def result = helper.processLSCRMMessage(eventsData)

			then:
			result == false
		}

		def "processLSCRMMessage filters events correctly for AddMember with valid subEvent and parent_child_ind"() {
			given:
			def event = [eventName: "AddMember", subEvent: "validSubEvent", parent_child_ind: "P", ban: "12345"]
			def eventsData = [event]

			when:
			def result = helper.processLSCRMMessage(eventsData)

			then:
			result == false
		}

		def "processLSCRMMessage does not filter events for AddMember with invalid parent_child_ind"() {
			given:
			def event = [eventName: "AddMember", subEvent: "NewReg", parent_child_ind: "P", ban: "12345"]
			def eventsData = [event]

			when:
			def result = helper.processLSCRMMessage(eventsData)

			then:
			result == false
		}

		def "processLSCRMMessage filters events correctly for CreateInteraction with valid subEvent"() {
			given:
			def event = [eventName: "CreateInteraction", subEvent: "ExistingReg", ban: "12345"]
			def eventsData = [event]

			when:
			def result = helper.processLSCRMMessage(eventsData)

			then:
			result == false
		}

		def "processLSCRMMessage filters events correctly for CreateInteraction with paperBillOpt and primaryContactEmail"() {
			given:
			def event = [eventName: "CreateInteraction", paperBillOpt: true, primaryContactEmail: "email@example.com", ban: "12345"]
			def eventsData = [event]

			when:
			def result = helper.processLSCRMMessage(eventsData)

			then:
			result == false
		}

		def "processLSCRMMessage does not filter events for CreateInteraction without paperBillOpt and primaryContactEmail"() {
			given:
			def event = [eventName: "CreateInteraction", paperBillOpt: false, primaryContactEmail: null, ban: "12345"]
			def eventsData = [event]

			when:
			def result = helper.processLSCRMMessage(eventsData)

			then:
			result == false
		}

	def "processLSCRMMessage returns error map when exception is thrown"() {
		given:
		def helper = Spy(IDGraphLSCRMRulesHelper)
		// Simulate an exception in isValidEventsData
		helper.isValidEventsData(_) >> { throw new RuntimeException("Test exception") }

		when:
		def result = helper.processLSCRMMessage([[:]])

		then:
		result == false
	}
// Spock test for "AddRemoveServicesList" case
	def "processLSCRMMessage filters events correctly for AddRemoveServicesList with valid subEvent1"() {
		given:
		def event = [eventName: "AddRemoveServicesList", subEvent: "DialPwdReset", ban: "12345"]
		def eventsData = [event]

		when:
		def result1 = helper.processLSCRMMessage(eventsData)

		then:
		result1 == false
	}

	// Spock test for "AddRemoveServicesList" case
	def "processLSCRMMessage filters events correctly for AddRemoveServicesList with valid subEvent2"() {
		given:
		def event = [eventName: "AddRemoveServicesList", subEvent: "SyncClarifyCRM", ban: "12345"]
		def eventsData = [event]

		when:
		def result2 = helper.processLSCRMMessage(eventsData)

		then:
		result2 == false
	}

// Spock test for "UpdateMember" case
	def "processLSCRMMessage filters events correctly for UpdateMember with valid subEvent3"() {
		given:
		def event = [eventName: "UpdateMember", subEvent: "SyncClarifyCRM", ban: "12345"]
		def eventsData = [event]

		when:
		def result3 = helper.processLSCRMMessage(eventsData)

		then:
		result3 == false
	}
	def "processEventRules returns true for AddRemoveServicesList when subEvent is in lscrmSubEventsAddRemoveSvcList"() {
		given:
		def helper = new IDGraphLSCRMRulesHelper()
		// Simulate the injected value
		helper.lscrmSubEventsAddRemoveSvcList = "DialPwdReset|SyncClarifyCRM"
		def event = [eventname: "AddRemoveServicesList", subEvent: "DialPwdReset"]
		def eventsData = [event]
		when:
		def result = helper.processEventRules(eventsData)

		then:
		result == true
	}
	def "processEventRules returns false for unknown eventName"() {
		given:
		def helper = new IDGraphLSCRMRulesHelper()
		def event = [eventname: "UnknownEvent", subEvent: "AnySubEvent"]

		when:
		def result = helper.processEventRules(event)

		then:
		result == false
	}
	def "processEventRules returns true for AddMember when subEvent is in lscrmSubEventsAddMember and parent_child_ind is P"() {
		given:
		def helper = new IDGraphLSCRMRulesHelper()
		helper.lscrmSubEventsAddMember = "NewReg|NewRegHSIA"
		def event = [eventname: "AddMember", subEvent: "NewReg", parent_child_ind: "P"]

		when:
		def result = helper.processEventRules(event)

		then:
		result == true
	}

	def "processEventRules returns false for AddMember when subEvent is not in lscrmSubEventsAddMember"() {
		given:
		def helper = new IDGraphLSCRMRulesHelper()
		helper.lscrmSubEventsAddMember = "NewReg|NewRegHSIA"
		def event = [eventname: "AddMember", subEvent: "InvalidSubEvent", parent_child_ind: "P"]

		when:
		def result = helper.processEventRules(event)

		then:
		result == false
	}

	def "processEventRules returns false for AddMember when parent_child_ind is not P"() {
		given:
		def helper = new IDGraphLSCRMRulesHelper()
		helper.lscrmSubEventsAddMember = "NewReg|NewRegHSIA"
		def event = [eventname: "AddMember", subEvent: "NewReg", parent_child_ind: "C"]

		when:
		def result = helper.processEventRules(event)

		then:
		result == false
	}
	def "processEventRules returns true for UpdateMember when subEvent is in lscrmSubEventsUpdateMember"() {
		given:
		def helper = new IDGraphLSCRMRulesHelper()
		helper.lscrmSubEventsUpdateMember = "SyncClarifyCRM|AnotherSubEvent"
		def event = [eventname: "UpdateMember", subEvent: "SyncClarifyCRM"]

		when:
		def result = helper.processEventRules(event)

		then:
		result == true
	}

	def "processEventRules returns false for UpdateMember when subEvent is not in lscrmSubEventsUpdateMember"() {
		given:
		def helper = new IDGraphLSCRMRulesHelper()
		helper.lscrmSubEventsUpdateMember = "SyncClarifyCRM|AnotherSubEvent"
		def event = [eventname: "UpdateMember", subEvent: "InvalidSubEvent"]

		when:
		def result = helper.processEventRules(event)

		then:
		result == false
	}
	def "processEventRules returns true for CreateInteraction when subEvent is in lscrmSubEventsCreateInteraction"() {
		given:
		def helper = new IDGraphLSCRMRulesHelper()
		helper.lscrmSubEventsCreateInteraction = "DialPwdReset|ExistingReg"
		def event = [eventname: "CreateInteraction", subEvent: "DialPwdReset"]

		when:
		def result = helper.processEventRules(event)

		then:
		result == true
	}

	def "processEventRules returns true for CreateInteraction when paperBillOpt is true and primaryContactEmail is present"() {
		given:
		def helper = new IDGraphLSCRMRulesHelper()
		helper.lscrmSubEventsCreateInteraction = "SomeOtherEvent"
		def event = [eventname: "CreateInteraction", subEvent: "NotInList", paperBillOpt: true, primaryContactEmail: "test@email.com"]

		when:
		def result = helper.processEventRules(event)

		then:
		result == true
	}

	def "processEventRules returns false for CreateInteraction when subEvent is not in list and paperBillOpt/primaryContactEmail are not set"() {
		given:
		def helper = new IDGraphLSCRMRulesHelper()
		helper.lscrmSubEventsCreateInteraction = "DialPwdReset|ExistingReg"
		def event = [eventname: "CreateInteraction", subEvent: "NotInList", paperBillOpt: false, primaryContactEmail: null]

		when:
		def result = helper.processEventRules(event)

		then:
		result == false
	}
}