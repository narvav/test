package com.att.idp.idgraphconsumerms.helpers

import com.att.idp.idgraph.events.service.ResilientEventPublisher
import spock.lang.Specification
import spock.lang.Unroll

import java.lang.reflect.Field

class ExternalEventsProcessingHelperTest extends Specification {

    IDGraphYahooRulesHelper idGraphYahooRulesHelper
    IDGraphG2RulesHelper idGraphG2RulesHelper
    IDGraphLSCRMRulesHelper idGraphLSCRMRulesHelper
    IDGraphHaloCRulesHelper idGraphHaloCRulesHelper
    IDGraphBbnmsRulesHelper idGraphBbnmsRulesHelper
    IDGraphSubSvcRulesHelper idGraphSubSvcRulesHelper
    IDGraphIdgraphRulesHelper idGraphIdgraphRulesHelper
    IDGraphCSIRulesHelper idGraphCSIRulesHelper
    NotificationEventProcessorHelper notificationEventProcessorHelper
    ResilientEventPublisher resilientEventPublisher
    ExternalEventsProcessingHelper helper


    def setup() {
        idGraphYahooRulesHelper = Mock(IDGraphYahooRulesHelper)
        idGraphG2RulesHelper = Mock(IDGraphG2RulesHelper)
        idGraphLSCRMRulesHelper = Mock(IDGraphLSCRMRulesHelper)
        idGraphHaloCRulesHelper = Mock(IDGraphHaloCRulesHelper)
        idGraphBbnmsRulesHelper = Mock(IDGraphBbnmsRulesHelper)
        idGraphSubSvcRulesHelper = Mock(IDGraphSubSvcRulesHelper)
        idGraphIdgraphRulesHelper = Mock(IDGraphIdgraphRulesHelper)
        idGraphCSIRulesHelper = Mock(IDGraphCSIRulesHelper)
        notificationEventProcessorHelper = Mock(NotificationEventProcessorHelper)
        resilientEventPublisher = Mock(ResilientEventPublisher)
        helper = new ExternalEventsProcessingHelper()
        setPrivateField(helper, 'idGraphYahooRulesHelper', idGraphYahooRulesHelper)
        setPrivateField(helper, 'idGraphG2RulesHelper', idGraphG2RulesHelper)
        setPrivateField(helper, 'idGraphLSCRMRulesHelper', idGraphLSCRMRulesHelper)
        setPrivateField(helper, 'idGraphHaloCRulesHelper', idGraphHaloCRulesHelper)
        setPrivateField(helper, 'idGraphBbnmsRulesHelper', idGraphBbnmsRulesHelper)
        setPrivateField(helper, 'idGraphSubSvcRulesHelper', idGraphSubSvcRulesHelper)
        setPrivateField(helper, 'idGraphIdgraphRulesHelper', idGraphIdgraphRulesHelper)
        setPrivateField(helper, 'idGraphCSIRulesHelper', idGraphCSIRulesHelper)
        setPrivateField(helper, 'notificationEventProcessorHelper', notificationEventProcessorHelper)
        setPrivateField(helper, 'resilientEventPublisher', resilientEventPublisher)
    }


    @Unroll
    def "should skip processing when eventsData is missing or invalid for #scenarioName"() {
        given: "Input map with missing or invalid eventsData"
        Map<String, Object> inputMap = input
        helper.metaClass.loadEventDistributionProperties = { -> new Properties() }

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "No downstream system is called"

        where:
        scenarioName         | input
        "missing eventsData" | [:]
        "null eventsData"    | ["eventsData": null]
        "unsupported type"   | ["eventsData": 123]
    }

    def "should skip event with blank eventname"() {
        given: "Event with blank eventname"
        Map<String, Object> event = [eventname: ""]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList]
        helper.metaClass.loadEventDistributionProperties = { -> new Properties() }

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "No downstream system is called"
        0 * _
    }

    def "should skip event when no system mapping found"() {
        given: "Event with no system mapping"
        Map<String, Object> event = [eventname: "UNKNOWN_EVENT"]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList]
        Properties props = new Properties()
        helper.metaClass.loadEventDistributionProperties = { -> props }

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "No downstream system is called"
    }

    // Helper methods for system mocks

    private static void setPrivateField(Object target, String fieldName, Object value) {
        Field field = target.getClass().getDeclaredField(fieldName)
        field.setAccessible(true)
        field.set(target, value)
    }

    @Unroll
    def "should process NotificationEvent and call notificationEventProcessorHelper for #scenarioName"() {
        given: "A NotificationEvent with valid eventname and event data"
        Map<String, Object> event = [eventname: "NotificationEvent", key1: "value1"]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList]
        Properties props = new Properties()
        helper.metaClass.loadEventDistributionProperties = { -> props }

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "notificationEventProcessorHelper.processNotificationEvent is called with correct arguments"
        1 * notificationEventProcessorHelper.processNotificationEvent({ Map<String, Object> evt ->
            evt.eventname == "NotificationEvent" &&
                    evt.key1 == "value1"
        }, inputMap)
        0 * _

        and: "No other downstream system is called"

        where: "Different NotificationEvent scenarios"
        scenarioName                 | _
        "standard NotificationEvent" | _
    }

    @Unroll
    def "should publish event to Yahoo topic for #scenarioName"() {
        given: "A valid eventName and event map"
        String eventName = inputEventName
        Map<String, Object> event = inputEvent
        helper.yahooTopicName = "test-yahoo-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToYahooTopic is called"
        helper.publishEventToYahooTopic(eventName, event)

        then: "ResilientEventPublisher.sendWithFallback is called with correct arguments"
        1 * resilientEventPublisher.sendWithFallback("yahooNotifications", "Yahoo", _, event) >> true
        0 * _

        and: "No exception is thrown and logging occurs"
        // Logging is not directly asserted here, but can be verified with a log capturing extension if needed

        where: "Different event scenarios"
        scenarioName     | inputEventName | inputEvent
        "standard event" | "TestEvent"    | [key: "value"]
        "another event"  | "AnotherEvent" | [foo: "bar"]
    }

    @Unroll
    def "should publish event to Haloc topic for #scenarioName"() {
        given: "A valid eventName and event map"
        String eventName = inputEventName
        Map<String, Object> event = inputEvent
        helper.halocTopicName = "test-haloc-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToHalocTopic is called"
        helper.publishEventToHalocTopic(eventName, event)

        then: "ResilientEventPublisher.sendWithFallback is called with correct arguments"
        1 * resilientEventPublisher.sendWithFallback("halocNotifications", "Haloc", _, event) >> true
        0 * _

        and: "No exception is thrown and logging occurs"
        // Logging is not directly asserted here, but can be verified with a log capturing extension if needed

        where: "Different event scenarios"
        scenarioName     | inputEventName | inputEvent
        "standard event" | "TestEvent"    | [key: "value"]
        "another event"  | "AnotherEvent" | [foo: "bar"]
    }

    @Unroll
    def "should publish event to G2 topic for #scenarioName"() {
        given: "A valid eventName and event map"
        String eventName = inputEventName
        Map<String, Object> event = inputEvent
        helper.allOtherExtSysTopicName = "test-G2-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToG2Topic is called"
        helper.publishEventToG2Topic(eventName, event)

        then: "ResilientEventPublisher.sendWithFallback is called with correct arguments"
        1 * resilientEventPublisher.sendWithFallback("g2Notifications", "G2", _, event) >> true
        0 * _

        and: "No exception is thrown and logging occurs"
        // Logging is not directly asserted here, but can be verified with a log capturing extension if needed

        where: "Different event scenarios"
        scenarioName     | inputEventName | inputEvent
        "standard event" | "TestEvent"    | [key: "value"]
        "another event"  | "AnotherEvent" | [foo: "bar"]
    }

    def "should not publish to G2 topic when eventName is null"() {
        given: "A null eventName"
        String eventName = null
        Map<String, Object> event = [key: "value"]
        helper.allOtherExtSysTopicName = "test-G2-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToG2Topic is called"
        helper.publishEventToG2Topic(eventName, event)

        then: "ResilientEventPublisher.sendWithFallback is not called"
        0 * _

        and: "Method returns early without publishing"
        // Method logs warning and returns
    }

    @Unroll
    def "should publish event to LSCRM topic for #scenarioName"() {
        given: "A valid eventName and event map"
        String eventName = inputEventName
        Map<String, Object> event = inputEvent
        helper.allOtherExtSysTopicName = "test-lscrm-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToLscrmTopic is called"
        helper.publishEventToLscrmTopic(eventName, event)

        then: "ResilientEventPublisher.sendWithFallback is called with correct arguments"
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "LSCRM", _, event) >> true
        0 * _

        and: "No exception is thrown and logging occurs"
        // Logging is not directly asserted here, but can be verified with a log capturing extension if needed

        where: "Different event scenarios"
        scenarioName     | inputEventName | inputEvent
        "standard event" | "TestEvent"    | [key: "value"]
        "another event"  | "AnotherEvent" | [foo: "bar"]
    }

    def "should not publish to LSCRM topic when eventName is null"() {
        given: "A null eventName"
        String eventName = null
        Map<String, Object> event = [key: "value"]
        helper.allOtherExtSysTopicName = "test-lscrm-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToLscrmTopic is called"
        helper.publishEventToLscrmTopic(eventName, event)

        then: "ResilientEventPublisher.sendWithFallback is not called"
        0 * _

        and: "Method returns early without publishing"
        // Method logs warning and returns
    }

    def "should not publish to Yahoo topic when eventName is null"() {
        given: "A null eventName"
        String eventName = null
        Map<String, Object> event = [key: "value"]
        helper.yahooTopicName = "test-yahoo-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToYahooTopic is called"
        helper.publishEventToYahooTopic(eventName, event)

        then: "ResilientEventPublisher.sendWithFallback is not called"
        0 * _

        and: "Method returns early without publishing"
        // Method logs warning and returns
    }

    def "should not publish to Haloc topic when eventName is null"() {
        given: "A null eventName"
        String eventName = null
        Map<String, Object> event = [key: "value"]
        helper.halocTopicName = "test-haloc-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToHalocTopic is called"
        helper.publishEventToHalocTopic(eventName, event)

        then: "ResilientEventPublisher.sendWithFallback is not called"
        0 * _

        and: "Method returns early without publishing"
        // Method logs warning and returns
    }

    def "should load event distribution properties successfully"() {
        given: "distributionevent.properties file exists on classpath"
        ExternalEventsProcessingHelper helperForPropsTest = new ExternalEventsProcessingHelper()

        when: "loadEventDistributionProperties is called"
        Properties result = helperForPropsTest.loadEventDistributionProperties()

        then: "Properties object is returned"
        result != null
        result instanceof Properties
        0 * _
    }


    @Unroll
    def "should not publish when rules helper returns false for #scenarioName"() {
        given: "Event and system information"
        String system = targetSystem
        String eventName = "TestEvent"
        Map<String, Object> event = [key: "value"]
        helper.yahooTopicName = "yahoo-topic"
        helper.halocTopicName = "haloc-topic"
        helper.allOtherExtSysTopicName = "other-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        and: "Rules helper returns false"
        idGraphYahooRulesHelper.processYahooMessage(event) >> false
        idGraphG2RulesHelper.processG2Message(event) >> false
        idGraphLSCRMRulesHelper.processLSCRMMessage(event) >> false
        idGraphHaloCRulesHelper.processHaloCMessage(event) >> false

        when: "dispatchToDestination is called"
        helper.dispatchToDestination(system, eventName, event)

        then: "Correct rules helper is called but event is not published"
        expectedRulesHelperCalls * idGraphYahooRulesHelper.processYahooMessage(event)
        expectedRulesHelperCallsG2 * idGraphG2RulesHelper.processG2Message(event)
        expectedRulesHelperCallsLscrm * idGraphLSCRMRulesHelper.processLSCRMMessage(event)
        expectedRulesHelperCallsHaloc * idGraphHaloCRulesHelper.processHaloCMessage(event)
        0 * _

        and: "ResilientEventPublisher.sendWithFallback is not called"

        where: "Different system destinations"
        scenarioName | targetSystem | expectedRulesHelperCalls | expectedRulesHelperCallsG2 | expectedRulesHelperCallsLscrm | expectedRulesHelperCallsHaloc
        "YAHOO"      | "YAHOO"      | 1                        | 0                          | 0                             | 0
        "G2"         | "G2"         | 0                        | 1                          | 0                             | 0
        "LSCRM"      | "LSCRM"      | 0                        | 0                          | 1                             | 0
        "HALOC"      | "HALOC"      | 0                        | 0                          | 0                             | 1
    }

    def "should not dispatch for unknown system"() {
        given: "Unknown system identifier"
        String system = "UNKNOWN_SYSTEM"
        String eventName = "TestEvent"
        Map<String, Object> event = [key: "value"]
        helper.resilientEventPublisher = resilientEventPublisher

        when: "dispatchToDestination is called"
        helper.dispatchToDestination(system, eventName, event)

        then: "No rules helper is called and no event is published"

    }


    def "should handle exception during event processing gracefully"() {
        given: "Event that causes exception"
        Map<String, Object> event = [eventname: "EventWithError"]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList]

        helper.metaClass.loadEventDistributionProperties = { ->
            throw new RuntimeException("Error loading properties")
        }

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "Exception is caught and logged, no downstream calls are made"
        0 * _

        and: "Method completes without throwing exception"
        noExceptionThrown()
    }

    def "should process eventsData when it is a Map instead of List"() {
        given: "Event data as a Map instead of List"
        Map<String, Object> singleEvent = [eventname: "SingleEvent"]
        Map<String, Object> inputMap = ["eventsData": singleEvent]
        Properties props = new Properties()
        helper.metaClass.loadEventDistributionProperties = { -> props }

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "Event is processed as a single-item list"
        0 * _

        and: "No exception is thrown"
        noExceptionThrown()
    }

    def "should dispatch event to Yahoo when rules helper returns true"() {
        given: "Event dispatched to YAHOO system"
        Map<String, Object> event = [eventname: "YahooEvent1", handle: "user1", domain: "att.net"]
        helper.yahooTopicName = "yahoo-topic"

        when: "dispatchToDestination is called for YAHOO"
        helper.dispatchToDestination("YAHOO", "YahooEvent1", event)

        then: "Yahoo rules helper is invoked and event is published with bindingKey"
        1 * idGraphYahooRulesHelper.processYahooMessage(event) >> true
        1 * resilientEventPublisher.sendWithFallback("yahooNotifications", "Yahoo", _, event) >> true
        0 * _
    }


    def "should process NotificationEvent without system mapping"() {
        given: "NotificationEvent without system mapping in properties"
        Map<String, Object> event = [eventname: "NotificationEvent", data: "test"]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList]
        Properties props = new Properties()
        helper.metaClass.loadEventDistributionProperties = { -> props }

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "NotificationEvent is processed via notificationEventProcessorHelper"
        1 * notificationEventProcessorHelper.processNotificationEvent(_, inputMap)
        0 * _

        and: "No downstream system is called since there's no system mapping"
    }

    def "should transform and publish SUBSVC payload when SUBSVC rules pass"() {
        given: "LSRegNotify event mapped to SUBSVC"
        Map<String, Object> event = [
                eventname       : "LSRegNotify",
                ban             : "VD0017554",
                handle          : "qay_geetha_1751",
                domain          : "att.net",
                registrationDate: "260427194659",
                idpTraceId      : "trace-1"
        ]
        Map<String, Object> transformedPayload = [eventType: "SubscriptionService", eventDetails: []]
        helper.subSvcTopicName = "subsvc-topic"

        when: "dispatchToDestination is called for SUBSVC"
        helper.dispatchToDestination("SUBSVC", "LSRegNotify", event)

        then: "transformed payload is published to SUBSVC binding"
        1 * idGraphSubSvcRulesHelper.processSubSvcMessage(event) >> true
        1 * idGraphSubSvcRulesHelper.transformToSubSvcPayload(event) >> new HashMap<String, Object>(transformedPayload)
        1 * resilientEventPublisher.sendWithFallback("subsvcNotifications", "SUBSVC", _, {
            Map<String, Object> payload -> payload.eventType == "SubscriptionService"
        }) >> true
        0 * _
    }

    def "should not publish SUBSVC when SUBSVC rules fail"() {
        given: "Event mapped to SUBSVC"
        Map<String, Object> event = [eventname: "LSRegNotify"]

        when: "dispatchToDestination is called"
        helper.dispatchToDestination("SUBSVC", "LSRegNotify", event)

        then: "SUBSVC rules helper blocks publishing"
        1 * idGraphSubSvcRulesHelper.processSubSvcMessage(event) >> false
        0 * _
    }

    @Unroll
    def "should dispatch event to BBNMS when rules helper returns true for #scenarioName"() {
        given: "Event mapped to BBNMS system"
        Map<String, Object> event = [eventname: eventNameValue, key: "value"]
        helper.bbnmsTopicName = "test-bbnms-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "dispatchToDestination is called for BBNMS"
        helper.dispatchToDestination("BBNMS", eventNameValue, event)

        then: "BBNMS rules helper is invoked and event is published"
        1 * idGraphBbnmsRulesHelper.processBbnmsMessage(event) >> true
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "BBNMS", eventNameValue, event) >> true
        0 * _

        where: "Different BBNMS event scenarios"
        scenarioName           | eventNameValue
        "standard BBNMS event" | "BbnmsEvent1"
        "another BBNMS event"  | "BbnmsEvent2"
    }

    def "should not publish BBNMS when BBNMS rules fail"() {
        given: "Event mapped to BBNMS"
        Map<String, Object> event = [eventname: "BbnmsEvent"]

        when: "dispatchToDestination is called"
        helper.dispatchToDestination("BBNMS", "BbnmsEvent", event)

        then: "BBNMS rules helper blocks publishing"
        1 * idGraphBbnmsRulesHelper.processBbnmsMessage(event) >> false
        0 * _
    }

    def "should not publish to BBNMS topic when eventName is null"() {
        given: "A null eventName for BBNMS"
        Map<String, Object> event = [eventname: null]
        helper.bbnmsTopicName = "test-bbnms-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        and: "BBNMS rules helper returns true but mapped eventName is null"
        idGraphBbnmsRulesHelper.processBbnmsMessage(event) >> true

        when: "dispatchToDestination is called"
        helper.dispatchToDestination("BBNMS", "BbnmsEvent", event)

        then: "Event is not published because mapped eventName from event is null"
        1 * idGraphBbnmsRulesHelper.processBbnmsMessage(event) >> true

    }

    def "should not publish to SubSvc topic when eventName is null"() {
        given: "A null eventName"
        String eventName = null
        Map<String, Object> event = [key: "value"]
        helper.subSvcTopicName = "test-subsvc-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToSubSvcTopic is called"
        helper.publishEventToSubSvcTopic(eventName, event)

        then: "ResilientEventPublisher.sendWithFallback is not called"
        0 * _

        and: "Method returns early without publishing"
    }

    @Unroll
    def "should log fallback when publish returns false for #scenarioName"() {
        given: "Event and system info"
        String eventName = "TestEvent"
        Map<String, Object> event = [key: "value"]
        helper.yahooTopicName = "yahoo-topic"
        helper.halocTopicName = "haloc-topic"
        helper.allOtherExtSysTopicName = "other-topic"
        helper.bbnmsTopicName = "bbnms-topic"
        helper.subSvcTopicName = "subsvc-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publish method is called"
        switch (targetMethod) {
            case "yahoo": helper.publishEventToYahooTopic(eventName, event); break
            case "haloc": helper.publishEventToHalocTopic(eventName, event); break
            case "g2": helper.publishEventToG2Topic(eventName, event); break
            case "lscrm": helper.publishEventToLscrmTopic(eventName, event); break
        }

        then: "ResilientEventPublisher returns false indicating fallback"
        1 * resilientEventPublisher.sendWithFallback(expectedBinding, expectedSystem, _, event) >> false
        0 * _

        where: "Different topic fallback scenarios"
        scenarioName     | targetMethod | expectedBinding               | expectedSystem
        "Yahoo fallback" | "yahoo"      | "yahooNotifications"          | "Yahoo"
        "Haloc fallback" | "haloc"      | "halocNotifications"          | "Haloc"
        "G2 fallback"    | "g2"         | "g2Notifications"             | "G2"
        "LSCRM fallback" | "lscrm"      | "allOtherExtSysNotifications" | "LSCRM"
    }

    def "should dispatch to multiple systems when pipe-delimited mapping exists"() {
        given: "Event mapped to YAHOO|G2 via properties"
        Map<String, Object> event = [eventname: "MultiSystemEvent"]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList, "transactionId": "trace-multi"]
        Properties props = new Properties()
        props.setProperty("MultiSystemEvent", "YAHOO|G2")
        helper.metaClass.loadEventDistributionProperties = { -> props }
        helper.yahooTopicName = "yahoo-topic"
        helper.allOtherExtSysTopicName = "g2-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "Both YAHOO and G2 rules helpers are invoked"
        0 * idGraphYahooRulesHelper.processYahooMessage({ Map<String, Object> evt ->
            evt.eventname == "MultiSystemEvent" && evt.idpTraceId == "trace-multi"
        }) >> false
        0 * idGraphG2RulesHelper.processG2Message({ Map<String, Object> evt ->
            evt.eventname == "MultiSystemEvent" && evt.idpTraceId == "trace-multi"
        }) >> false
    }

    def "should use eventname from event map for BBNMS mapped event name"() {
        given: "BBNMS event with remapped eventname in event map"
        Map<String, Object> event = [eventname: "RemappedBbnmsEvent", key: "value"]
        helper.bbnmsTopicName = "test-bbnms-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "dispatchToDestination is called for BBNMS"
        helper.dispatchToDestination("BBNMS", "OriginalEventName", event)

        then: "BBNMS rules helper is invoked and event is published with remapped name"
        1 * idGraphBbnmsRulesHelper.processBbnmsMessage(event) >> true
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "BBNMS", "RemappedBbnmsEvent", event) >> true
        0 * _
    }

    def "should publish SUBSVC event to SubSvc topic successfully"() {
        given: "A valid eventName and transformed payload"
        String eventName = "SubSvcEvent"
        Map<String, Object> event = [eventType: "SubscriptionService"]
        helper.subSvcTopicName = "test-subsvc-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToSubSvcTopic is called"
        helper.publishEventToSubSvcTopic(eventName, event)

        then: "ResilientEventPublisher.sendWithFallback is called"
        1 * idGraphSubSvcRulesHelper.transformToSubSvcPayload(event) >> [transformedKey: "transformedValue"]
        1 * resilientEventPublisher.sendWithFallback("subsvcNotifications", "SUBSVC", null, [transformedKey: "transformedValue"]) >> true
     }

    def "should log fallback when SUBSVC publish returns false"() {
        given: "A valid eventName and event"
        String eventName = "SubSvcEvent"
        Map<String, Object> event = [eventType: "SubscriptionService"]
        Map<String, Object> transformedPayload = [transformedKey: "transformedValue"]
        helper.subSvcTopicName = "test-subsvc-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToSubSvcTopic is called"
        helper.publishEventToSubSvcTopic(eventName, event)

        then: "idGraphSubSvcRulesHelper transforms the payload and ResilientEventPublisher returns false"
        1 * idGraphSubSvcRulesHelper.transformToSubSvcPayload(event) >> transformedPayload
        1 * resilientEventPublisher.sendWithFallback("subsvcNotifications", "SUBSVC", null, transformedPayload) >> false
        0 * _
    }

    def "should log fallback when BBNMS publish returns false"() {
        given: "A valid eventName and event for BBNMS"
        Map<String, Object> event = [eventname: "BbnmsEvent", key: "value"]
        helper.bbnmsTopicName = "test-bbnms-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "dispatchToDestination is called for BBNMS"
        helper.dispatchToDestination("BBNMS", "BbnmsEvent", event)

        then: "BBNMS rules pass but publish returns false (fallback)"
        1 * idGraphBbnmsRulesHelper.processBbnmsMessage(event) >> true
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "BBNMS", "BbnmsEvent", event) >> false
        0 * _
    }

    def "should process NotificationEventList and invoke processNotificationEvent for nested NotificationEvent"() {
        given: "A NotificationEventList event with eventsListInfo containing a NotificationEvent"
        Map<String, Object> nestedEvent = [
                eventname          : "NotificationEvent",
                lastName           : "ggttata",
                slid               : "donna000121397ggttata",
                origTransactionName: "LSReg",
                AccountId          : "000121397",
                transactionName    : "LinkInternetAccount",
                ban                : "000121397",
                parentDomain       : "bellsouth.net",
                customerType       : "R",
                parent_child_ind   : "P",
                subEvent           : "SLID",
                sor_name           : "LS",
                handle             : "qayma0091292",
                callingSystemId    : "IDP",
                transactionId      : "a495a8ca39984530",
                firstName          : "donna000121397",
                member_num         : "1020456094",
                domain             : "bellsouth.net"
        ]
        Map<String, Object> event = [
                eventname        : "NotificationEventList",
                origTransactionId: "a495a8ca39984530",
                eventsListInfo   : [nestedEvent],
                transactionId    : "a495a8ca39984530"
        ]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList]
        Properties props = new Properties()
        helper.metaClass.loadEventDistributionProperties = { -> props }

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "processNotificationEvent is called for the nested NotificationEvent"
        1 * notificationEventProcessorHelper.processNotificationEvent({ Map<String, Object> evt ->
            evt.eventname == "NotificationEvent" &&
                    evt.slid == "donna000121397ggttata" &&
                    evt.ban == "000121397"
        }, inputMap)
        0 * _
    }

    def "should process multiple nested NotificationEvents from NotificationEventList"() {
        given: "A NotificationEventList with multiple nested NotificationEvents"
        Map<String, Object> nestedEvent1 = [eventname: "NotificationEvent", ban: "111"]
        Map<String, Object> nestedEvent2 = [eventname: "NotificationEvent", ban: "222"]
        Map<String, Object> nestedEvent3 = [eventname: "OtherEvent", ban: "333"]
        Map<String, Object> event = [
                eventname     : "NotificationEventList",
                eventsListInfo: [nestedEvent1, nestedEvent2, nestedEvent3],
                transactionId : "trace-multi"
        ]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList]
        Properties props = new Properties()
        helper.metaClass.loadEventDistributionProperties = { -> props }

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "processNotificationEvent is called only for NotificationEvent entries"
        1 * notificationEventProcessorHelper.processNotificationEvent({ Map<String, Object> evt ->
            evt.ban == "111"
        }, inputMap)
        1 * notificationEventProcessorHelper.processNotificationEvent({ Map<String, Object> evt ->
            evt.ban == "222"
        }, inputMap)
        0 * _
    }

    def "should skip NotificationEventList when eventsListInfo is not a List"() {
        given: "A NotificationEventList with invalid eventsListInfo"
        Map<String, Object> event = [
                eventname     : "NotificationEventList",
                eventsListInfo: "not-a-list",
                transactionId : "trace-invalid"
        ]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList]
        Properties props = new Properties()
        helper.metaClass.loadEventDistributionProperties = { -> props }

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "No notification processing occurs"
        0 * _
    }

    def "should skip NotificationEventList when eventsListInfo is missing"() {
        given: "A NotificationEventList without eventsListInfo key"
        Map<String, Object> event = [
                eventname    : "NotificationEventList",
                transactionId: "trace-missing"
        ]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList]
        Properties props = new Properties()
        helper.metaClass.loadEventDistributionProperties = { -> props }

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "No notification processing occurs"
        0 * _
    }

    @Unroll
    def "should dispatch event to IDGRAPH when rules helper returns true for #scenarioName"() {
        given: "Event mapped to IDGRAPH system"
        Map<String, Object> event = [eventname: eventNameValue, ban: "VD0017554"]
        helper.allOtherExtSysTopicName = "test-allother-topic"

        when: "dispatchToDestination is called for IDGRAPH"
        helper.dispatchToDestination("IDGRAPH", eventNameValue, event)

        then: "IDGRAPH rules helper is invoked and event is published"
        1 * idGraphIdgraphRulesHelper.processIdgraphMessage(event) >> true
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "IDGRAPH", eventNameValue, event) >> true
        0 * _

        where: "Different IDGRAPH event scenarios"
        scenarioName                 | eventNameValue
        "LSServicesActivation event" | "LSServicesActivation"
    }

    def "should not publish IDGRAPH when rules helper returns false"() {
        given: "Event mapped to IDGRAPH"
        Map<String, Object> event = [eventname: "LSServicesActivation"]

        when: "dispatchToDestination is called"
        helper.dispatchToDestination("IDGRAPH", "LSServicesActivation", event)

        then: "IDGRAPH rules helper blocks publishing"
        1 * idGraphIdgraphRulesHelper.processIdgraphMessage(event) >> false
        0 * _
    }

    def "should not publish to IDGRAPH topic when publishEventToIdgraphTopic receives null eventName"() {
        given: "A null eventName passed directly to publish method"
        Map<String, Object> event = [eventname: "LSServicesActivation"]
        helper.allOtherExtSysTopicName = "test-allother-topic"

        when: "publishEventToIdgraphTopic is called with null eventName"
        helper.publishEventToIdgraphTopic(null, event)

        then: "ResilientEventPublisher.sendWithFallback is not called"
        0 * _
    }

    def "should publish IDGRAPH event with fallback when publish returns false"() {
        given: "Event dispatched to IDGRAPH"
        Map<String, Object> event = [eventname: "LSServicesActivation", ban: "VD0017554"]
        helper.allOtherExtSysTopicName = "test-allother-topic"

        when: "dispatchToDestination is called"
        helper.dispatchToDestination("IDGRAPH", "LSServicesActivation", event)

        then: "IDGRAPH rules pass but publish returns false (fallback)"
        1 * idGraphIdgraphRulesHelper.processIdgraphMessage(event) >> true
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "IDGRAPH", "LSServicesActivation", event) >> false
        0 * _
    }

    // ==================== MEMBER_LIST_EVENT_PATTERN / memberInfo splitting tests ====================

    @Unroll
    def "should split memberInfo and dispatch each entry to all systems for #scenarioName"() {
        given: "A member-list event with multiple memberInfo entries mapped to a system"
        Map<String, Object> memberInfo1 = [member_num: "1001", domain: "att.net"]
        Map<String, Object> memberInfo2 = [member_num: "1002", domain: "bellsouth.net"]
        Map<String, Object> event = [
                eventname : eventNameValue,
                ban       : "000123456",
                memberInfo: [memberInfo1, memberInfo2]
        ]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList, "transactionId": "trace-member-split"]
        Properties props = new Properties()
        props.setProperty(eventNameValue, "YAHOO")
        helper.metaClass.loadEventDistributionProperties = { -> props }
        helper.yahooTopicName = "yahoo-topic"

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "Yahoo rules helper is invoked once per memberInfo entry with single-element memberInfo list"
        1 * idGraphYahooRulesHelper.processYahooMessage({ Map<String, Object> req ->
            req.memberInfo instanceof List &&
                    req.memberInfo.size() == 1 &&
                    req.memberInfo[0].member_num == "1001" &&
                    req.idpTraceId == "trace-member-split" &&
                    req.ban == "000123456"
        }) >> true
        1 * idGraphYahooRulesHelper.processYahooMessage({ Map<String, Object> req ->
            req.memberInfo instanceof List &&
                    req.memberInfo.size() == 1 &&
                    req.memberInfo[0].member_num == "1002" &&
                    req.idpTraceId == "trace-member-split" &&
                    req.ban == "000123456"
        }) >> true
        2 * resilientEventPublisher.sendWithFallback("yahooNotifications", "Yahoo", _, _) >> true
        0 * _

        where: "Different member list event names"
        scenarioName             | eventNameValue
        "AddMemberList event"    | "AddMemberList"
        "UpdateMemberList event" | "UpdateMemberList"
        "DeleteMemberList event" | "DeleteMemberList"
        "AddServicesList event"  | "AddServicesList"
    }


    def "should not dispatch when memberInfo list is empty for member-list event"() {
        given: "A member-list event with empty memberInfo list"
        Map<String, Object> event = [
                eventname : "AddMemberList",
                ban       : "000111222",
                memberInfo: []
        ]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList, "transactionId": "trace-empty"]
        Properties props = new Properties()
        props.setProperty("AddMemberList", "YAHOO")
        helper.metaClass.loadEventDistributionProperties = { -> props }

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "No dispatch occurs because memberInfo is empty"
        0 * _
    }

    def "should not dispatch when memberInfo is not a List for member-list event"() {
        given: "A member-list event with memberInfo as a non-List object"
        Map<String, Object> event = [
                eventname : "UpdateMemberList",
                ban       : "000333444",
                memberInfo: "not-a-list"
        ]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList, "transactionId": "trace-invalid"]
        Properties props = new Properties()
        props.setProperty("UpdateMemberList", "YAHOO")
        helper.metaClass.loadEventDistributionProperties = { -> props }

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "No dispatch occurs because memberInfo is not a List"
        0 * _
    }

    def "should not dispatch when memberInfo is null for member-list event"() {
        given: "A member-list event with null memberInfo"
        Map<String, Object> event = [
                eventname : "DeleteMemberList",
                ban       : "000555666",
                memberInfo: null
        ]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList, "transactionId": "trace-null"]
        Properties props = new Properties()
        props.setProperty("DeleteMemberList", "HALOC")
        helper.metaClass.loadEventDistributionProperties = { -> props }

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "No dispatch occurs because memberInfo is null"
        0 * _
    }

    def "should set idpTraceId to empty string when transactionId is null for member-list event"() {
        given: "A member-list event with null transactionId"
        Map<String, Object> memberInfo1 = [member_num: "3001", domain: "att.net"]
        Map<String, Object> event = [
                eventname : "AddRemoveServicesList",
                ban       : "000777888",
                memberInfo: [memberInfo1]
        ]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList, "transactionId": null]
        Properties props = new Properties()
        props.setProperty("AddRemoveServicesList", "YAHOO")
        helper.metaClass.loadEventDistributionProperties = { -> props }
        helper.yahooTopicName = "yahoo-topic"

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "idpTraceId is set to empty string in the dispatched request"
        1 * idGraphYahooRulesHelper.processYahooMessage({ Map<String, Object> req ->
            req.idpTraceId == "" &&
                    req.memberInfo instanceof List &&
                    req.memberInfo.size() == 1 &&
                    req.memberInfo[0].member_num == "3001"
        }) >> true
        1 * resilientEventPublisher.sendWithFallback("yahooNotifications", "Yahoo", _, _) >> true
        0 * _
    }


    def "should dispatch non-member-list event to multiple systems"() {
        given: "A non-member-list event mapped to YAHOO and HALOC"
        Map<String, Object> event = [eventname: "SomeEvent", ban: "000666777"]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList, "transactionId": "trace-multi"]
        Properties props = new Properties()
        props.setProperty("SomeEvent", "YAHOO|HALOC")
        helper.metaClass.loadEventDistributionProperties = { -> props }
        helper.yahooTopicName = "yahoo-topic"
        helper.halocTopicName = "haloc-topic"

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "Both YAHOO and HALOC systems receive the event"
        1 * idGraphYahooRulesHelper.processYahooMessage({ Map<String, Object> req ->
            req.eventname == "SomeEvent" &&
                    req.idpTraceId == "trace-multi"
        }) >> true
        1 * resilientEventPublisher.sendWithFallback("yahooNotifications", "Yahoo", _, _) >> true
        1 * idGraphHaloCRulesHelper.processHaloCMessage({ Map<String, Object> req ->
            req.eventname == "SomeEvent" &&
                    req.idpTraceId == "trace-multi"
        }) >> true
        1 * resilientEventPublisher.sendWithFallback("halocNotifications", "Haloc", _, _) >> true
        0 * _
    }

    @Unroll
    def "should process all MEMBER_LIST_EVENT_PATTERN event names correctly for #scenarioName"() {
        given: "A matching member-list event with a single memberInfo"
        Map<String, Object> memberInfo1 = [member_num: "5001", domain: "att.net"]
        Map<String, Object> event = [
                eventname : eventNameValue,
                ban       : "000222333",
                memberInfo: [memberInfo1]
        ]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList, "transactionId": "trace-pattern"]
        helper.yahooTopicName = "yahoo-topic"

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "Each memberInfo entry is dispatched individually to YAHOO (per distributionevent.properties)"
        1 * idGraphYahooRulesHelper.processYahooMessage({ Map<String, Object> req ->
            req.memberInfo instanceof List &&
                    req.memberInfo.size() == 1 &&
                    req.memberInfo[0].member_num == "5001" &&
                    req.idpTraceId == "trace-pattern"
        }) >> true
        1 * resilientEventPublisher.sendWithFallback("yahooNotifications", "Yahoo", _, _) >> true
        0 * _

        where: "All MEMBER_LIST_EVENT_PATTERN event names"
        scenarioName               | eventNameValue
        "AddMemberList"            | "AddMemberList"
        "UpdateMemberList"         | "UpdateMemberList"
        "DeleteMemberList"         | "DeleteMemberList"
        "AddServicesList"          | "AddServicesList"
        "AddRemoveServicesList"    | "AddRemoveServicesList"
        "RemoveServicesList"       | "RemoveServicesList"
        "UpdateServicesStatusList" | "UpdateServicesStatusList"
        "UpdateServicesList"       | "UpdateServicesList"
    }

    def "should not dispatch member-list event when rules helper returns false"() {
        given: "A member-list event where YAHOO rules fail"
        Map<String, Object> memberInfo1 = [member_num: "6001", domain: "att.net"]
        Map<String, Object> event = [
                eventname : "AddMemberList",
                ban       : "000444555",
                memberInfo: [memberInfo1]
        ]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList, "transactionId": "trace-fail"]
        Properties props = new Properties()
        props.setProperty("AddMemberList", "YAHOO")
        helper.metaClass.loadEventDistributionProperties = { -> props }
        helper.yahooTopicName = "yahoo-topic"

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "Yahoo rules helper rejects and no event is published"
        1 * idGraphYahooRulesHelper.processYahooMessage({ Map<String, Object> req ->
            req.memberInfo instanceof List &&
                    req.memberInfo.size() == 1 &&
                    req.memberInfo[0].member_num == "6001"
        }) >> false
        0 * resilientEventPublisher.sendWithFallback(_, _, _, _)
        0 * _
    }

    // ==================== getBinderKey tests ====================

    @Unroll
    def "getBinderKey should return correct key for yahoo system - #scenarioName"() {
        given: "Event with various fields"
        Map<String, Object> event = inputEvent

        when: "getBinderKey is called for yahoo"
        String result = helper.getBinderKey("yahoo", event)

        then: "Correct key is returned based on priority: hashKey > slidMemberNum > parentUserId > userId"
        result == expectedKey
        0 * _

        where:
        scenarioName                          | inputEvent                                                                   | expectedKey
        "hashKey present"                     | [hashKey: "hk123", slid_member_num: "sm1", handle: "h1", domain: "d.net"]    | "hk123"
        "slidMemberNum when no hashKey"       | [slid_member_num: "sm1", handle: "h1", domain: "d.net"]                      | "sm1"
        "parentUserId when no hashKey/slid"   | [parentHandle: "ph1", parentDomain: "pd.net", handle: "h1", domain: "d.net"] | "ph1@pd.net"
        "userId as fallback"                  | [handle: "h1", domain: "d.net"]                                              | "h1@d.net"
        "handle only without domain"          | [handle: "h1"]                                                               | "h1"
        "parentHandle only without domain"    | [parentHandle: "ph1", handle: "h1", domain: "d.net"]                         | "ph1"
        "no matching fields returns null"     | [ban: "12345"]                                                               | null
    }

    @Unroll
    def "getBinderKey should return correct key for haloc system - #scenarioName"() {
        given: "Event with various fields"
        Map<String, Object> event = inputEvent

        when: "getBinderKey is called for haloc"
        String result = helper.getBinderKey("haloc", event)

        then: "Correct key is returned based on haloc priority: hashKey > hash_key > slidMemberNum > parentUserId > userId"
        result == expectedKey
        0 * _

        where:
        scenarioName                        | inputEvent                                                                                  | expectedKey
        "hashKey present"                   | [hashKey: "hk123", hash_key: "alt1", slid_member_num: "sm1", handle: "h1", domain: "d.net"] | "hk123"
        "hash_key when no hashKey"          | [hash_key: "alt1", slid_member_num: "sm1", handle: "h1", domain: "d.net"]                   | "alt1"
        "slidMemberNum when no hash keys"   | [slid_member_num: "sm1", handle: "h1", domain: "d.net"]                                     | "sm1"
        "parentUserId as fallback"          | [parentHandle: "ph1", parentDomain: "pd.net", handle: "h1", domain: "d.net"]                | "ph1@pd.net"
        "userId as last resort"             | [handle: "h1", domain: "d.net"]                                                             | "h1@d.net"
    }

    def "getBinderKey should return userId for g2 system"() {
        given: "Event with handle and domain"
        Map<String, Object> event = [handle: "user1", domain: "att.net"]

        when: "getBinderKey is called for g2"
        String result = helper.getBinderKey("g2", event)

        then: "userId is returned"
        result == "user1@att.net"
        0 * _
    }

    def "getBinderKey should return null for g2 when no handle"() {
        given: "Event without handle"
        Map<String, Object> event = [ban: "12345"]

        when: "getBinderKey is called for g2"
        String result = helper.getBinderKey("g2", event)

        then: "null is returned"
        result == null
        0 * _
    }

    @Unroll
    def "getBinderKey should return ban or userId for #system system - #scenarioName"() {
        given: "Event with ban and/or handle"
        Map<String, Object> event = inputEvent

        when: "getBinderKey is called"
        String result = helper.getBinderKey(system, event)

        then: "ban takes priority over userId"
        result == expectedKey
        0 * _

        where:
        scenarioName                  | system    | inputEvent                                          | expectedKey
        "ban present for lscrm"       | "lscrm"   | [ban: "BAN123", handle: "h1", domain: "d.net"]     | "BAN123"
        "userId fallback for lscrm"   | "lscrm"   | [handle: "h1", domain: "d.net"]                    | "h1@d.net"
        "ban present for bbnms"       | "bbnms"   | [ban: "BAN123", handle: "h1", domain: "d.net"]     | "BAN123"
        "userId fallback for bbnms"   | "bbnms"   | [handle: "h1", domain: "d.net"]                    | "h1@d.net"
        "ban present for subsvc"      | "subsvc"  | [ban: "BAN123", handle: "h1", domain: "d.net"]     | "BAN123"
        "userId fallback for subsvc"  | "subsvc"  | [handle: "h1", domain: "d.net"]                    | "h1@d.net"
        "ban present for idgraph"     | "idgraph" | [ban: "BAN123", handle: "h1", domain: "d.net"]     | "BAN123"
        "userId fallback for idgraph" | "idgraph" | [handle: "h1", domain: "d.net"]                    | "h1@d.net"
    }

    def "getBinderKey should return system name for unknown system"() {
        given: "Event with all fields"
        Map<String, Object> event = [ban: "BAN123", handle: "h1", domain: "d.net"]

        when: "getBinderKey is called for unknown system"
        String result = helper.getBinderKey("unknownsystem", event)

        then: "System name is returned as default"
        result == "unknownsystem"
        0 * _
    }

    // ==================== null memberInfo entry skipping tests ====================

    def "should skip null memberInfo entries and dispatch remaining valid entries"() {
        given: "A member-list event with a null memberInfo entry mixed with valid entries"
        Map<String, Object> memberInfo1 = [member_num: "7001", domain: "att.net"]
        Map<String, Object> event = [
                eventname : "AddMemberList",
                ban       : "000999888",
                memberInfo: [null, memberInfo1]
        ]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList, "transactionId": "trace-null-member"]
        Properties props = new Properties()
        props.setProperty("AddMemberList", "YAHOO")
        helper.metaClass.loadEventDistributionProperties = { -> props }
        helper.yahooTopicName = "yahoo-topic"

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "Only the valid memberInfo entry is dispatched"
        1 * idGraphYahooRulesHelper.processYahooMessage({ Map<String, Object> req ->
            req.memberInfo instanceof List &&
                    req.memberInfo.size() == 1 &&
                    req.memberInfo[0].member_num == "7001"
        }) >> true
        1 * resilientEventPublisher.sendWithFallback("yahooNotifications", "Yahoo", _, _) >> true
        0 * _
    }

    def "should skip all null memberInfo entries without dispatching"() {
        given: "A member-list event where all memberInfo entries are null"
        Map<String, Object> event = [
                eventname : "DeleteMemberList",
                ban       : "000111999",
                memberInfo: [null, null]
        ]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList, "transactionId": "trace-all-null"]
        Properties props = new Properties()
        props.setProperty("DeleteMemberList", "HALOC")
        helper.metaClass.loadEventDistributionProperties = { -> props }

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "No dispatch occurs because all memberInfo entries are null"
        0 * _
    }

    // ==================== BBNMS/IDGRAPH eventname remapping edge cases ====================

    def "should use original eventName for BBNMS when event map eventname is null"() {
        given: "BBNMS event where eventname in event map becomes null after processing"
        Map<String, Object> event = [eventname: null, key: "value"]
        helper.bbnmsTopicName = "test-bbnms-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "dispatchToDestination is called for BBNMS"
        helper.dispatchToDestination("BBNMS", "OriginalEvent", event)

        then: "BBNMS rules helper decides and fallback eventName is used"
        1 * idGraphBbnmsRulesHelper.processBbnmsMessage(event) >> true
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "BBNMS", "OriginalEvent", event) >> true
        0 * _
    }

    def "should use remapped eventname from event map for IDGRAPH"() {
        given: "IDGRAPH event with remapped eventname in event map"
        Map<String, Object> event = [eventname: "RemappedIdgraphEvent", ban: "VD0017554"]
        helper.allOtherExtSysTopicName = "test-allother-topic"

        when: "dispatchToDestination is called for IDGRAPH"
        helper.dispatchToDestination("IDGRAPH", "OriginalEvent", event)

        then: "IDGRAPH uses the remapped eventname from the event map"
        1 * idGraphIdgraphRulesHelper.processIdgraphMessage(event) >> true
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "IDGRAPH", "RemappedIdgraphEvent", event) >> true
        0 * _
    }

    def "should use original eventName for IDGRAPH when event map eventname is null"() {
        given: "IDGRAPH event where eventname in event map is null"
        Map<String, Object> event = [eventname: null, ban: "VD0017554"]
        helper.allOtherExtSysTopicName = "test-allother-topic"

        when: "dispatchToDestination is called for IDGRAPH"
        helper.dispatchToDestination("IDGRAPH", "OriginalEvent", event)

        then: "IDGRAPH falls back to the original eventName parameter"
        1 * idGraphIdgraphRulesHelper.processIdgraphMessage(event) >> true
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "IDGRAPH", "OriginalEvent", event) >> true
        0 * _
    }

    // ==================== SUBSVC publishEventToSubSvcTopic ban binding key ====================

    def "should use ban as binding key when publishing SUBSVC event"() {
        given: "A SUBSVC event with ban in the payload"
        String eventName = "SubSvcEvent"
        Map<String, Object> event = [eventType: "SubscriptionService", ban: "VD0017554"]
        helper.subSvcTopicName = "test-subsvc-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToSubSvcTopic is called"
        helper.publishEventToSubSvcTopic(eventName, event)

        then: "ban is used as the binding key in sendWithFallback"
        1 * idGraphSubSvcRulesHelper.transformToSubSvcPayload(event) >> [transformedKey: "transformedValue"]
        1 * resilientEventPublisher.sendWithFallback("subsvcNotifications", "SUBSVC", "VD0017554", [transformedKey: "transformedValue"]) >> true
         }

    def "should use null binding key when ban and handle are absent in SUBSVC event"() {
        given: "A SUBSVC event without ban or handle/domain"
        String eventName = "SubSvcEvent"
        Map<String, Object> event = [eventType: "SubscriptionService"]
        helper.subSvcTopicName = "test-subsvc-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToSubSvcTopic is called"
        helper.publishEventToSubSvcTopic(eventName, event)

        then: "null is used as binding key since getBinderKey returns null when ban and userId are absent"
        1 * idGraphSubSvcRulesHelper.transformToSubSvcPayload(event) >> [transformedKey: "transformedValue"]
        1 * resilientEventPublisher.sendWithFallback("subsvcNotifications", "SUBSVC", null, [transformedKey: "transformedValue"]) >> true
          }

    // ==================== BBNMS/SUBSVC dispatch to multiple systems ====================

    def "should dispatch member-list event to BBNMS system per memberInfo entry"() {
        given: "Individual memberInfo requests as produced by member-list splitting"
        Map<String, Object> memberInfoReq1 = [
                eventname : "AddMemberList",
                ban       : "000123789",
                idpTraceId: "trace-bbnms-split",
                memberInfo: [[member_num: "8001", domain: "att.net"]]
        ]
        Map<String, Object> memberInfoReq2 = [
                eventname : "AddMemberList",
                ban       : "000123789",
                idpTraceId: "trace-bbnms-split",
                memberInfo: [[member_num: "8002", domain: "bellsouth.net"]]
        ]
        helper.bbnmsTopicName = "bbnms-topic"

        when: "dispatchToDestination is called for BBNMS for each memberInfo entry"
        helper.dispatchToDestination("BBNMS", "AddMemberList", memberInfoReq1)
        helper.dispatchToDestination("BBNMS", "AddMemberList", memberInfoReq2)

        then: "BBNMS rules helper is invoked once per entry and event is published"
        2 * idGraphBbnmsRulesHelper.processBbnmsMessage({ Map<String, Object> req ->
            req.memberInfo instanceof List && req.memberInfo.size() == 1
        }) >> true
        2 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "BBNMS", "AddMemberList", _) >> true
        0 * _
    }

    def "should not publish to BBNMS topic when publishEventToBBNMSTopic receives null eventName"() {
        given: "A null eventName for direct publish"
        Map<String, Object> event = [key: "value"]
        helper.bbnmsTopicName = "test-bbnms-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToBBNMSTopic is called with null"
        helper.publishEventToBBNMSTopic(null, event)

        then: "ResilientEventPublisher is not called"
        0 * _
    }

    // ==================== G2/LSCRM/HALOC dispatch success tests ====================

    def "should dispatch event to G2 when rules helper returns true"() {
        given: "Event dispatched to G2 system"
        Map<String, Object> event = [eventname: "G2Event", handle: "user1", domain: "att.net"]
        helper.allOtherExtSysTopicName = "test-g2-topic"

        when: "dispatchToDestination is called for G2"
        helper.dispatchToDestination("G2", "G2Event", event)

        then: "G2 rules helper is invoked and event is published"
        1 * idGraphG2RulesHelper.processG2Message(event) >> true
        1 * resilientEventPublisher.sendWithFallback("g2Notifications", "G2", _, event) >> true
        0 * _
    }

    def "should dispatch event to LSCRM when rules helper returns true"() {
        given: "Event dispatched to LSCRM system with ban"
        Map<String, Object> event = [eventname: "LSCRMEvent", ban: "BAN123", handle: "user1", domain: "att.net"]
        helper.allOtherExtSysTopicName = "test-lscrm-topic"

        when: "dispatchToDestination is called for LSCRM"
        helper.dispatchToDestination("LSCRM", "LSCRMEvent", event)

        then: "LSCRM rules helper is invoked and event is published with ban as bindingKey"
        1 * idGraphLSCRMRulesHelper.processLSCRMMessage(event) >> true
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "LSCRM", "BAN123", event) >> true
        0 * _
    }

    def "should dispatch event to HALOC when rules helper returns true"() {
        given: "Event dispatched to HALOC system"
        Map<String, Object> event = [eventname: "HalocEvent", handle: "user1", domain: "att.net"]
        helper.halocTopicName = "test-haloc-topic"

        when: "dispatchToDestination is called for HALOC"
        helper.dispatchToDestination("HALOC", "HalocEvent", event)

        then: "HALOC rules helper is invoked and event is published"
        1 * idGraphHaloCRulesHelper.processHaloCMessage(event) >> true
        1 * resilientEventPublisher.sendWithFallback("halocNotifications", "Haloc", _, event) >> true
        0 * _
    }

    // ==================== LSCRM publish with ban as bindingKey ====================

    def "should publish LSCRM event with ban as binding key"() {
        given: "LSCRM event with ban in the payload"
        String eventName = "LSCRMEvent"
        Map<String, Object> event = [ban: "VD0017554", handle: "user1", domain: "att.net"]
        helper.allOtherExtSysTopicName = "test-lscrm-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToLscrmTopic is called"
        helper.publishEventToLscrmTopic(eventName, event)

        then: "ban is used as binding key since LSCRM uses getBinderKey"
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "LSCRM", "VD0017554", event) >> true
        0 * _
    }

    def "should publish LSCRM event with userId fallback when ban is absent"() {
        given: "LSCRM event without ban but with handle and domain"
        String eventName = "LSCRMEvent"
        Map<String, Object> event = [handle: "user1", domain: "att.net"]
        helper.allOtherExtSysTopicName = "test-lscrm-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToLscrmTopic is called"
        helper.publishEventToLscrmTopic(eventName, event)

        then: "userId is used as fallback binding key"
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "LSCRM", "user1@att.net", event) >> true
        0 * _
    }

    // ==================== BBNMS publish uses eventName as 3rd arg ====================

    def "should publish BBNMS event with eventName as 3rd arg not bindingKey"() {
        given: "BBNMS event with ban in payload"
        String eventName = "BBNMSAssignUverseAddressBookP2"
        Map<String, Object> event = [eventname: eventName, ban: "VD0017554"]
        helper.bbnmsTopicName = "test-bbnms-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToBBNMSTopic is called"
        helper.publishEventToBBNMSTopic(eventName, event)

        then: "eventName is used as 3rd arg, not bindingKey"
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "BBNMS", "BBNMSAssignUverseAddressBookP2", event) >> true
        0 * _
    }

    // ==================== Multiple events in eventsData list ====================

    def "should dispatch multiple events independently to their respective systems"() {
        given: "Two events to dispatch to different systems"
        Map<String, Object> event1 = [eventname: "Event1", handle: "user1", domain: "att.net"]
        Map<String, Object> event2 = [eventname: "Event2", ban: "BAN999"]
        helper.yahooTopicName = "yahoo-topic"
        helper.bbnmsTopicName = "bbnms-topic"

        when: "dispatchToDestination is called for each event"
        helper.dispatchToDestination("YAHOO", "Event1", event1)
        helper.dispatchToDestination("BBNMS", "Event2", event2)

        then: "Both events are dispatched to their respective systems"
        1 * idGraphYahooRulesHelper.processYahooMessage(event1) >> true
        1 * resilientEventPublisher.sendWithFallback("yahooNotifications", "Yahoo", _, _) >> true
        1 * idGraphBbnmsRulesHelper.processBbnmsMessage(event2) >> true
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "BBNMS", _, _) >> true
        0 * _
    }

    // ==================== IDGRAPH publish with eventName as 3rd arg ====================

    def "should publish IDGRAPH event with eventName as 3rd arg not bindingKey"() {
        given: "IDGRAPH event with ban in payload"
        String eventName = "LSServicesActivation"
        Map<String, Object> event = [eventname: eventName, ban: "VD0017554"]
        helper.allOtherExtSysTopicName = "test-allother-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToIdgraphTopic is called"
        helper.publishEventToIdgraphTopic(eventName, event)

        then: "eventName is used as 3rd arg, not bindingKey"
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "IDGRAPH", "LSServicesActivation", event) >> true
        0 * _
    }

    def "should log fallback when IDGRAPH publish returns false via publishEventToIdgraphTopic"() {
        given: "IDGRAPH event where publish returns false"
        String eventName = "LSServicesActivation"
        Map<String, Object> event = [eventname: eventName, ban: "VD0017554"]
        helper.allOtherExtSysTopicName = "test-allother-topic"
        helper.resilientEventPublisher = resilientEventPublisher

        when: "publishEventToIdgraphTopic is called"
        helper.publishEventToIdgraphTopic(eventName, event)

        then: "Fallback is triggered"
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "IDGRAPH", "LSServicesActivation", event) >> false
        0 * _
    }

    // ==================== CSI dispatch tests ====================

    def "should dispatch UpdatePaymentProfile event to CSI when rules helper returns true"() {
        given: "UpdatePaymentProfile event mapped to CSI"
        Map<String, Object> event = [
                eventname    : "UpdatePaymentProfile",
                handle       : "taylorcollins90@gmail.com",
                domain       : "slid.dum",
                parentHandle : "taylorcollins90@gmail.com",
                parentDomain : "slid.dum",
                subEvent     : "MergeProfile",
                transactionId: "9a6e90082d97db3e-345255623"
        ]
        

        when: "dispatchToDestination is called for CSI"
        helper.dispatchToDestination("CSI", "UpdatePaymentProfile", event)

        then: "CSI rules helper is invoked and event is published to allOtherExtSysNotifications"
        1 * idGraphCSIRulesHelper.processCSIMessage(event) >> true
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "CSI", _, event) >> true
        0 * _
    }

    def "should not publish CSI when rules helper returns false"() {
        given: "UpdatePaymentProfile event where CSI rules reject"
        Map<String, Object> event = [eventname: "UpdatePaymentProfile"]

        when: "dispatchToDestination is called for CSI"
        helper.dispatchToDestination("CSI", "UpdatePaymentProfile", event)

        then: "CSI rules helper blocks publishing"
        1 * idGraphCSIRulesHelper.processCSIMessage(event) >> false
        0 * _
    }

    def "should not publish to CSI topic when publishEventToCSITopic receives null eventName"() {
        given: "A null eventName passed to CSI publish"
        Map<String, Object> event = [eventname: "UpdatePaymentProfile"]
        

        when: "publishEventToCSITopic is called with null eventName"
        helper.publishEventToCSITopic(null, event)

        then: "ResilientEventPublisher.sendWithFallback is not called"
        0 * _
    }

    def "should log fallback when CSI publish returns false"() {
        given: "CSI event where publish returns false"
        Map<String, Object> event = [eventname: "UpdatePaymentProfile", ban: "BAN001", handle: "user1", domain: "att.net"]
        

        when: "dispatchToDestination is called for CSI"
        helper.dispatchToDestination("CSI", "UpdatePaymentProfile", event)

        then: "CSI rules pass but publish returns false triggering fallback"
        1 * idGraphCSIRulesHelper.processCSIMessage(event) >> true
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "CSI", "user1@att.net", event) >> false
        0 * _
    }

    @Unroll
    def "getBinderKey should return userId for csi system - #scenarioName"() {
        given: "Event with handle and/or domain for CSI"
        Map<String, Object> event = inputEvent

        when: "getBinderKey is called for csi"
        String result = helper.getBinderKey("csi", event)

        then: "userId is returned (handle@domain)"
        result == expectedKey
        0 * _

        where:
        scenarioName                | inputEvent                                                                       | expectedKey
        "handle and domain"         | [handle: "h1", domain: "d.net", ban: "BAN123"]                                   | "h1@d.net"
        "handle only (no domain)"   | [handle: "taylorcollins90@gmail.com"]                                            | "taylorcollins90@gmail.com"
        "handle@domain composite"   | [handle: "taylorcollins90@gmail.com", domain: "slid.dum"]                         | "taylorcollins90@gmail.com@slid.dum"
        "no handle, no domain"      | [ban: "BAN123", transactionId: "abc123"]                                         | null
    }

    def "should process UpdatePaymentProfile end-to-end via processExternalEvents dispatching to CSI"() {
        given: "UpdatePaymentProfile event in eventsData"
        Map<String, Object> event = [
                eventname    : "UpdatePaymentProfile",
                handle       : "taylorcollins90@gmail.com",
                domain       : "slid.dum",
                subEvent     : "MergeProfile",
                transactionId: "9a6e90082d97db3e-345255623"
        ]
        List<Map<String, Object>> eventsList = [event]
        Map<String, Object> inputMap = ["eventsData": eventsList, "transactionId": "9a6e90082d97db3e-345255623"]
        Properties props = new Properties()
        props.setProperty("UpdatePaymentProfile", "CSI")
        helper.metaClass.loadEventDistributionProperties = { -> props }
        

        when: "processExternalEvents is called"
        helper.processExternalEvents(inputMap)

        then: "CSI rules helper is invoked and event is published to allOtherExtSysNotifications"
        1 * idGraphCSIRulesHelper.processCSIMessage({ Map<String, Object> evt ->
            evt.eventname == "UpdatePaymentProfile" &&
                    evt.idpTraceId == "9a6e90082d97db3e-345255623"
        }) >> true
        1 * resilientEventPublisher.sendWithFallback("allOtherExtSysNotifications", "CSI", _, _) >> true
        0 * _
    }

    // ==================== SUBSVC dispatch chain verifying bindingKey on transformed payload ====================

    def "should use bindingKey from transformed payload when dispatching SUBSVC"() {
        given: "LSRegNotify event dispatched to SUBSVC"
        Map<String, Object> event = [
                eventname       : "LSRegNotify",
                ban             : "VD0017554",
                handle          : "qay_geetha_1751",
                domain          : "att.net",
                registrationDate: "260427194659",
                idpTraceId      : "trace-subsvc"
        ]
        Map<String, Object> transformedPayload = [eventType: "SubscriptionService", ban: "VD0017554", eventDetails: []]
        helper.subSvcTopicName = "subsvc-topic"

        when: "dispatchToDestination is called for SUBSVC"
        helper.dispatchToDestination("SUBSVC", "LSRegNotify", event)

        then: "transformed payload is published with ban as bindingKey"
        1 * idGraphSubSvcRulesHelper.processSubSvcMessage(event) >> true
        1 * idGraphSubSvcRulesHelper.transformToSubSvcPayload(event) >> new HashMap<String, Object>(transformedPayload)
        1 * resilientEventPublisher.sendWithFallback("subsvcNotifications", "SUBSVC", "VD0017554", {
            Map<String, Object> payload -> payload.eventType == "SubscriptionService"
        }) >> true
        0 * _
    }
}

