package com.att.idp.idgraphconsumerms.kafka.errorhandler

import spock.lang.Specification

class ErrorMessageTest extends Specification {

    def "test default constructor and setters"() {
        given:
        def errorMessage = new ErrorMessage()

        when:
        errorMessage.setMessageId("12345")
        errorMessage.setAppStatusMsg("Success")
        errorMessage.setErrInfo("200")
        errorMessage.setAppInfo("Application Info")
        errorMessage.setTransactionName("Transaction1")

        then:
        errorMessage.getMessageId() == "12345"
        errorMessage.getAppStatusMsg() == "Success"
        errorMessage.getErrInfo() == "200"
        errorMessage.getAppInfo() == "Application Info"
        errorMessage.getTransactionName() == "Transaction1"
    }

    def "test parameterized constructor"() {
        when:
        def errorMessage = new ErrorMessage("12345", "Success", "200", "Application Info", "Transaction1")

        then:
        errorMessage.getMessageId() == "12345"
        errorMessage.getAppStatusMsg() == "Success"
        errorMessage.getErrInfo() == "200"
        errorMessage.getAppInfo() == "Application Info"
        errorMessage.getTransactionName() == "Transaction1"
    }

    def "test getErrorResponseInfo method"() {
        given:
        def errorMessage = new ErrorMessage("12345", "Success", "200", "Application Info", "Transaction1")

        when:
        def responseInfo = errorMessage.getErrorResponseInfo()

        then:
        responseInfo == '{"appStatusCode":"200","appStatusMsg":"Success","appInfo":"Application Info","X-ATT-UniqueTransactionId":"12345","transactionName":"Transaction1"}'
    }
}