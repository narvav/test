package com.att.idp.idgraphconsumerms.kafka.dmctn.service

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.att.idp.idgraphconsumerms.model.SorOrchestrationRequest
import com.att.idp.idgraphconsumerms.utils.JsonService
import com.fasterxml.jackson.databind.JsonNode
import org.slf4j.MDC
import org.springframework.http.HttpEntity
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.web.client.HttpServerErrorException
import org.springframework.web.client.RestTemplate
import spock.lang.Specification
import spock.lang.Unroll

class OrchestrationWirelessApiRestClientTest extends Specification {

    RestTemplate restTemplate
    CosmosFailedEventsWriter cosmosFailedEventsWriter
    OrchestrationWirelessApiRestClient client

    void setup() {
        restTemplate = Mock(RestTemplate)
        cosmosFailedEventsWriter = Mock(CosmosFailedEventsWriter)
        client = new OrchestrationWirelessApiRestClient(restTemplate)
        client.userRegServerUrl = "http://mockserver"
        client.userName = "user"
        client.userPassword = "pass"
        client.cosmosFailedEventsWriter = cosmosFailedEventsWriter
        MDC.clear()
    }

    @Unroll
    def "should send POST and return response for #scenarioName"() {
        given: "A valid request and mock response"
        SorOrchestrationRequest request = new SorOrchestrationRequest()
        request.setSorInvariantId(sorInvariantId)
        String endpoint = "/api/test"
        String requestBody = "{\"sorInvariantId\":\"BAN123\"}"
        JsonNode responseBody = Mock(JsonNode)
        ResponseEntity<JsonNode> responseEntity = new ResponseEntity<>(responseBody, HttpStatus.OK)
        GroovyMock(JsonService, global: true)
        JsonService.getJsonFromObject(request) >> requestBody
        GroovyMock(MDC, global: true)
        MDC.get(ConsumerConstants.Keys.IDP_TRACE_ID) >> null

        when: "sendPostRequest is called"
        1 * restTemplate.exchange("http://mockserver/api/test", HttpMethod.POST, { HttpEntity<String> entity ->
            entity.body == requestBody &&
            entity.headers.getContentType() == MediaType.APPLICATION_JSON &&
            entity.headers.getFirst(ConsumerConstants.Keys.AUTHORIZATION).startsWith("Basic ") &&
            entity.headers.getFirst(ConsumerConstants.Keys.X_ATT_CLIENTID) == null &&
            entity.headers.getFirst(ConsumerConstants.Keys.IDP_TRACE_ID) == null
        }, JsonNode) >> responseEntity
        ResponseEntity<JsonNode> result = client.sendPostRequest(endpoint, request, "GDDNActivateAccount")

        then: "No other interactions"
        0 * _

        and: "Response is returned and no failed event is saved"
        result == null // method always returns null

        where:
        scenarioName   | sorInvariantId
        "happy path"   | "BAN123"
    }

    @Unroll
    def "should save failed event when response is not OK for #scenarioName"() {
        given: "A valid request and mock non-OK response"
        SorOrchestrationRequest request = new SorOrchestrationRequest()
        request.setSorInvariantId(sorInvariantId)
        String endpoint = "/api/test"
        String requestBody = "{\"sorInvariantId\":\"BAN123\"}"
        JsonNode responseBody = Mock(JsonNode)
        ResponseEntity<JsonNode> responseEntity = new ResponseEntity<>(responseBody, HttpStatus.BAD_REQUEST)
        GroovyMock(JsonService, global: true)
        JsonService.getJsonFromObject(request) >> requestBody
        GroovyMock(MDC, global: true)
        MDC.get(ConsumerConstants.Keys.IDP_TRACE_ID) >> null

        when: "sendPostRequest is called"
        1 * restTemplate.exchange("http://mockserver/api/test", HttpMethod.POST, { HttpEntity<String> entity ->
            entity.body == requestBody &&
            entity.headers.getContentType() == MediaType.APPLICATION_JSON &&
            entity.headers.getFirst(ConsumerConstants.Keys.AUTHORIZATION).startsWith("Basic ") &&
            entity.headers.getFirst(ConsumerConstants.Keys.X_ATT_CLIENTID) == null &&
            entity.headers.getFirst(ConsumerConstants.Keys.IDP_TRACE_ID) == null
        }, JsonNode) >> responseEntity
        ResponseEntity<JsonNode> result = client.sendPostRequest(endpoint, request, "GDDNActivateAccount")

        then: "restTemplate.exchange is called with correct arguments and failed event is saved"
        1 * cosmosFailedEventsWriter._
        0 * _

        and: "No response is returned"
        result == null

        where:
        scenarioName   | sorInvariantId
        "bad request"  | "BAN123"
    }

    @Unroll
    def "should throw and retry on HttpServerErrorException for #scenarioName"() {
        given: "A request that triggers HttpServerErrorException"
        SorOrchestrationRequest request = new SorOrchestrationRequest()
        request.setSorInvariantId(sorInvariantId)
        String endpoint = "/api/test"
        String requestBody = "{\"sorInvariantId\":\"BAN123\"}"
        GroovyMock(JsonService, global: true)
        JsonService.getJsonFromObject(request) >> requestBody
        GroovyMock(MDC, global: true)
        MDC.get(ConsumerConstants.Keys.IDP_TRACE_ID) >> null
        HttpServerErrorException exception = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR)

        when: "sendPostRequest is called"
        1 * restTemplate.exchange("http://mockserver/api/test", HttpMethod.POST, { HttpEntity<String> entity ->
            entity.body == requestBody &&
            entity.headers.getContentType() == MediaType.APPLICATION_JSON &&
            entity.headers.getFirst(ConsumerConstants.Keys.AUTHORIZATION).startsWith("Basic ") &&
            entity.headers.getFirst(ConsumerConstants.Keys.X_ATT_CLIENTID) == null &&
            entity.headers.getFirst(ConsumerConstants.Keys.IDP_TRACE_ID) == null
        }, JsonNode) >> { throw exception }
        client.sendPostRequest(endpoint, request, "GDDNActivateAccount")

        then: "restTemplate.exchange is called and throws, no failed event is saved"
        0 * cosmosFailedEventsWriter._
        0 * _

        and: "Exception is thrown and retried"
        HttpServerErrorException ex = thrown()
        ex.statusCode == HttpStatus.INTERNAL_SERVER_ERROR

        where:
        scenarioName   | sorInvariantId
        "server error" | "BAN123"
    }

    @Unroll
    def "should save failed event on non-retryable exception for #scenarioName"() {
        given: "A request that triggers a non-retryable exception"
        SorOrchestrationRequest request = new SorOrchestrationRequest()
        request.setSorInvariantId(sorInvariantId)
        String endpoint = "/api/test"
        String requestBody = "{\"sorInvariantId\":\"BAN123\"}"
        GroovyMock(JsonService, global: true)
        JsonService.getJsonFromObject(request) >> requestBody
        GroovyMock(MDC, global: true)
        MDC.get(ConsumerConstants.Keys.IDP_TRACE_ID) >> null
        RuntimeException exception = new RuntimeException("fail")

        when: "sendPostRequest is called"
        1 * restTemplate.exchange("http://mockserver/api/test", HttpMethod.POST, { HttpEntity<String> entity ->
            entity.body == requestBody &&
            entity.headers.getContentType() == MediaType.APPLICATION_JSON &&
            entity.headers.getFirst(ConsumerConstants.Keys.AUTHORIZATION).startsWith("Basic ") &&
            entity.headers.getFirst(ConsumerConstants.Keys.X_ATT_CLIENTID) == null &&
            entity.headers.getFirst(ConsumerConstants.Keys.IDP_TRACE_ID) == null
        }, JsonNode) >> { throw exception }
        ResponseEntity<JsonNode> result = client.sendPostRequest(endpoint, request, "GDDNActivateAccount")

        then: "restTemplate.exchange is called and throws, failed event is saved"
        1 * cosmosFailedEventsWriter._
        0 * _

        and: "No response is returned"
        result == null

        where:
        scenarioName   | sorInvariantId
        "runtime ex"   | "BAN123"
    }
}
