package com.att.idp.idgraphconsumerms.bsse.reverse

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.kafka.model.ReverseMigratedInboundDataEvent
import com.att.idp.idgraphconsumerms.kafka.model.ReverseMigratedInboundDataEvent.EventDetails
import com.att.idp.idgraphconsumerms.kafka.model.ReverseMigratedInboundDataEvent.IDMAttributes
import com.att.idp.idgraphconsumerms.request.validator.RequestValidator
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import spock.lang.Specification
import spock.lang.Unroll

class BsseReverseMigrationEventValidatorTest extends Specification {

    @Unroll
    def "should validate required fields for #scenarioName"() {
        given: "A ReverseMigratedInboundDataEvent and static RequestValidator mock"
        ReverseMigratedInboundDataEvent event = new ReverseMigratedInboundDataEvent()
        event.setSourceBSSEBan(sourceBSSEBan)
        event.setTargetTLGBan(targetTLGBan)
        event.setMigrationId(migrationId)

        IDMAttributes idmAttributes = IDMAttributes.builder()
                .accountType(accountType)
                .accountSubType(accountSubType)
                .build()
        EventDetails eventDetails = EventDetails.builder()
                .idmAttributes(idmAttributes)
                .build()
        event.setEvent(eventDetails)

        Map<String, Object> validResult = [(MPSDefs.APP_STATUS_CODE): CommonDefs.COMMON_SUCCESS]
        Map<String, Object> invalidResult = [
                (MPSDefs.APP_STATUS_CODE): "FAIL",
                (MPSDefs.APP_STATUS_MSG): errorMsg
        ]

        GroovyMock(RequestValidator, global: true)
        RequestValidator.validate(sourceBSSEBan, ConsumerConstants.BsseReverseMigration.SOURCE_BSSE_BAN) >> (sourceBSSEBanValid ? validResult : invalidResult)
        RequestValidator.validate(targetTLGBan, ConsumerConstants.BsseReverseMigration.TARGET_TLG_BAN) >> (targetTLGBanValid ? validResult : invalidResult)
        RequestValidator.validate(migrationId, ConsumerConstants.BsseReverseMigration.MIGRATION_ID) >> (migrationIdValid ? validResult : invalidResult)
        RequestValidator.validate(accountType, ConsumerConstants.BsseReverseMigration.ACCOUNT_TYPE) >> (accountTypeValid ? validResult : invalidResult)
        RequestValidator.validate(accountSubType, ConsumerConstants.BsseReverseMigration.ACCOUNT_SUB_TYPE) >> (accountSubTypeValid ? validResult : invalidResult)

        when: "Validator is called"
        String result = BsseReverseMigrationEventValidator.validateRequiredFields(event)

        then: "Validation result matches expectation"
        result == expectedError

        0 * _

        where: "Different field validation scenarios"
        scenarioName                | sourceBSSEBan | targetTLGBan | migrationId | accountType | accountSubType | sourceBSSEBanValid | targetTLGBanValid | migrationIdValid | accountTypeValid | accountSubTypeValid | errorMsg                                      | expectedError
        "all valid"                 | "123"         | "456"        | "789"       | "I"         | "R"            | true               | true              | true            | true             | true                | null                                          | null
        "invalid sourceBSSEBan"     | null          | "456"        | "789"       | "I"         | "R"            | false              | true              | true            | true             | true                | "Invalid input: sourceBSSEBan is blank or null." | "Invalid input: sourceBSSEBan is blank or null."
        "invalid targetTLGBan"      | "123"         | null         | "789"       | "I"         | "R"            | true               | false             | true            | true             | true                | "Invalid input: targetTLGBan is blank or null."  | "Invalid input: targetTLGBan is blank or null."
        "invalid migrationId"       | "123"         | "456"        | null        | "I"         | "R"            | true               | true              | false           | true             | true                | "Invalid input: migrationId is blank or null."   | "Invalid input: migrationId is blank or null."
        "invalid accountType"       | "123"         | "456"        | "789"       | null        | "R"            | true               | true              | true            | false            | true                | "Invalid input: accountType is blank or null."   | "Invalid input: accountType is blank or null."
        "invalid accountSubType"    | "123"         | "456"        | "789"       | "I"         | null           | true               | true              | true            | true             | false               | "Invalid input: accountSubType is blank or null."| "Invalid input: accountSubType is blank or null."
    }

    def "should return error when event is null"() {
        when: "Validator is called with null event"
        String result = BsseReverseMigrationEventValidator.validateRequiredFields(null)

        then: "Error message is returned"
        result == "Event object must not be null."

        0 * _
    }
}
