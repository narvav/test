package com.att.idp.idgraphconsumerms.helpers

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.fasterxml.jackson.databind.JsonNode
import org.springframework.http.HttpEntity
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatusCode
import org.springframework.http.ResponseEntity
import org.springframework.web.client.HttpServerErrorException
import org.springframework.web.client.RestTemplate
import spock.lang.Specification

class PasscodeProcessorTest extends Specification {

    def restTemplate = Mock(RestTemplate)
    def cosmosFailedEventsWriter = Mock(CosmosFailedEventsWriter)
    def passcodeProcessor = new PasscodeProcessor()

    def setup() {
        passcodeProcessor.restTemplate = restTemplate
        passcodeProcessor.cosmosFailedEventsWriter = cosmosFailedEventsWriter
        passcodeProcessor.userAssoServerUrl = "http://test-server"
        passcodeProcessor.uaServiceEndPoint = "/test-endpoint"
        passcodeProcessor.userName = "testUser"
        passcodeProcessor.userPassword = "testPassword"
    }


    def "test callUserAssociationDeleteCredService success scenario"() {
        given:
        def individualId = "IND123"
        def responseEntity = Mock(ResponseEntity)
        responseEntity.getBody() >> null

        when:
        passcodeProcessor.callUserAssociationDeleteCredService(individualId,
                ConsumerConstants.BsseMigration.EVENT_ORDERGRAPH_FAILURE)

        then:
        1 * restTemplate.exchange(
                "http://test-server/test-endpoint/IND123",
                HttpMethod.DELETE,
                { HttpEntity entity ->
                    entity.headers.get("Authorization").get(0).startsWith("Basic")
                },
                JsonNode.class
        ) >> responseEntity
    }

    def "test callUserAssociationDeleteCredService retryable exception"() {
        given:
        def individualId = "IND123"

        when:
        passcodeProcessor.callUserAssociationDeleteCredService(individualId,
                ConsumerConstants.BsseMigration.EVENT_ORDERGRAPH_FAILURE)

        then:
        1 * restTemplate.exchange(_, _, _, _) >> { throw new HttpServerErrorException(HttpStatusCode.INTERNAL_SERVER_ERROR) }
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
            it.accountId == individualId &&
                    it.requestPayload == "\"IND123\"" &&
                    it.eventName == "OrderGraphSalesPivotFailure" &&
                    it.errorDetails["errorMessage"] == "No such property: INTERNAL_SERVER_ERROR for class: org.springframework.http.HttpStatusCode" && // Corrected value
                    it.errorDetails["errorCode"] == "100" &&
                    it.errorDetails["failedEndpoint"] == "/test-endpoint" &&
                    it.errorDetails["accountType"] == "INDIVIDUALID"
        })
    }

    def "test callUserAssociationDeleteCredService non-retryable exception"() {
        given:
        def individualId = "IND123"

        when:
        passcodeProcessor.callUserAssociationDeleteCredService(individualId,
                ConsumerConstants.BsseMigration.EVENT_ORDERGRAPH_FAILURE)

        then:
        1 * restTemplate.exchange(_, _, _, _) >> { throw new RuntimeException("Test exception") }
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
            it.accountId == "IND123" &&
                    it.requestPayload == "\"IND123\"" &&
                    it.eventName == "OrderGraphSalesPivotFailure" &&
                    it.errorDetails["errorMessage"] == "Test exception"
        })
    }

    def "test recover method for HttpServerErrorException with individualId"() {
        given:
        def individualId = "IND123"
        def eventName = ConsumerConstants.BsseMigration.EVENT_ORDERGRAPH_FAILURE
        def exception = new HttpServerErrorException(HttpStatusCode.valueOf(500), "Internal Server Error")

        when:
        passcodeProcessor.recover(exception, individualId, eventName)

        then:

        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
            it.accountId == individualId &&
                    it.requestPayload == "\"IND123\"" &&
                    it.eventName == "OrderGraphSalesPivotFailure" &&
                    it.errorDetails["errorMessage"] == "500 Internal Server Error" && // Match actual value
                    it.errorDetails["errorCode"] == "100" && // Match actual value
                    it.errorDetails["failedEndpoint"] == "/test-endpoint" &&
                    it.errorDetails["accountType"] == "INDIVIDUALID"
        })
    }
}