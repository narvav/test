package com.att.idp.idgraphconsumerms.oracle.helpers

import com.att.idp.idgraphconsumerms.oracle.model.MemberServiceResult
import org.springframework.jdbc.core.JdbcTemplate
import com.att.idp.idgraphconsumerms.constants.ConsumerConstants

import java.util.Optional

/**
 * Stub implementation of MemberServiceDBHelper for testing.
 * Provides mock data for member service lookups.
 */
class MemberServiceDBHelperStub extends MemberServiceDBHelper {

    private final JdbcTemplate jdbcTemplate = new JdbcTemplate()

    private final Map<String, String> guidByCtn = new HashMap<>()
    private final Map<String, MemberServiceResult> memberServiceResultsBySorId = new HashMap<>()
    private final Map<String, MemberServiceResult> memberServiceResultsByInstanceId = new HashMap<>()

    /**
     * Constructs the stub with mock data.
     * @param jdbcTemplate the JdbcTemplate instance
     */
    MemberServiceDBHelperStub(JdbcTemplate jdbcTemplate) {
        super(jdbcTemplate)

        guidByCtn.put("5551112222", "G12345")
        guidByCtn.put("5553334444", "G98765")

        memberServiceResultsBySorId.put("93fc9236d9214c3bd5ab998a673ef92c", createNew("G12345", ConsumerConstants.DmctnSubscriberChangeEvent.TRAN_TYPE_UPDATE_DMCTN, "sor-id-1", "5551112223"))
        memberServiceResultsBySorId.put("sor-id-2", createNew("G98765", ConsumerConstants.DmctnSubscriberChangeEvent.TRAN_TYPE_UPDATE_DMCTN, "sor-id-2", "5553334445"))

        memberServiceResultsByInstanceId.put("1111111111", createNew("G12345", ConsumerConstants.DmctnSubscriberChangeEvent.TRAN_TYPE_UPDATE_SUBID, "93fc9236d9214c3bd5ab998a673ef92c", "5551112222"))
        memberServiceResultsByInstanceId.put("2222222222", createNew("G98765", ConsumerConstants.DmctnSubscriberChangeEvent.TRAN_TYPE_UPDATE_SUBID, "sor-id-2", "5553334444"))
    }

    /**
     * Returns an Optional containing the GUID for the given CTN.
     * @param ctn the CTN to look up
     * @return Optional containing GUID if found, otherwise empty
     */
    @Override
    Optional<String> getGuidForGivenCTN(String ctn) {
        return Optional.ofNullable(guidByCtn.get(ctn))
    }

    /**
     * Returns an Optional containing MemberServiceResult for the given SOR Invariant ID.
     * Simulates SQL exception for specific test value.
     * @param sorInvariantId the SOR Invariant ID
     * @return Optional containing MemberServiceResult if found, otherwise empty
     */
    @Override
    Optional<MemberServiceResult> getOldPhoneNumberFromSubscriptionId(String sorInvariantId) {
        if (sorInvariantId == "eae9373abe05c5db4208d4c41bf9260b0eb382180221dd0116313d300582dfe5") {
            throw new RuntimeException("Simulated SQL Exception")
        }
        return Optional.ofNullable(memberServiceResultsBySorId.get(sorInvariantId))
    }

    /**
     * Returns an Optional containing MemberServiceResult for the given instanceId.
     * Simulates SQL exception for specific test value.
     * @param instanceId the instance ID
     * @return Optional containing MemberServiceResult if found, otherwise empty
     */
    @Override
    Optional<MemberServiceResult> getOldSubscriptionIdFromInstanceId(String instanceId) {
        if (instanceId == "throw-sql-exception") {
            throw new RuntimeException("Simulated SQL Exception")
        }

        return Optional.ofNullable(memberServiceResultsByInstanceId.get(instanceId))
    }

    private MemberServiceResult createNew(String guid, String transactionType, String sorInvariantId, String instanceId) {
        return new MemberServiceResult(guid, transactionType, sorInvariantId, instanceId)
    }
}
