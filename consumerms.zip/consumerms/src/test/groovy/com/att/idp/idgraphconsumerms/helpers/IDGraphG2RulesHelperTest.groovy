package com.att.idp.idgraphconsumerms.helpers

import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import spock.lang.Unroll

class IDGraphG2RulesHelperTest extends Specification {

	IDGraphG2RulesHelper helper

	def setup() {
		helper = new IDGraphG2RulesHelper()
		ReflectionTestUtils.setField(helper, "g2Events", "AddUpdateMember|DeleteMember|WLLmoduser")
	}

	def "processG2Message returns false when event is null"() {
		given: "a null event"
		Map<String, Object> event = null

		when: "processG2Message is called with null"
		boolean result = helper.processG2Message(event)

		then: "no unexpected interactions"
		0 * _

		and: "result is false"
		!result
	}

	def "processG2Message returns false when event is empty"() {
		given: "an empty event map"
		Map<String, Object> event = [:]

		when: "processG2Message is called with empty map"
		boolean result = helper.processG2Message(event)

		then: "no unexpected interactions"
		0 * _

		and: "result is false"
		!result
	}

	@Unroll
	def "processG2Message returns #expectedResult for eventname #eventname - #scenarioName"() {
		given: "an event with specified eventname"
		Map<String, Object> event = [
				eventname: eventname
		]

		when: "processG2Message is called"
		boolean result = helper.processG2Message(event)

		then: "no unexpected interactions"
		0 * _

		and: "result matches expected"
		result == expectedResult

		where:
		scenarioName              | eventname          || expectedResult
		"valid AddUpdateMember"   | "AddUpdateMember"  || true
		"valid DeleteMember"      | "DeleteMember"     || true
		"valid WLLmoduser"        | "WLLmoduser"       || true
		"invalid eventname"       | "UnknownEvent"     || false
		"null eventname"          | null               || false
	}

	def "processG2Message returns false when g2Events config is empty"() {
		given: "empty g2Events configuration"
		ReflectionTestUtils.setField(helper, "g2Events", "")
		Map<String, Object> event = [
				eventname: "AddUpdateMember"
		]

		when: "processG2Message is called"
		boolean result = helper.processG2Message(event)

		then: "no unexpected interactions"
		0 * _

		and: "result is false due to empty config"
		!result
	}

	def "processG2Message returns false when g2Events config is null"() {
		given: "null g2Events configuration"
		ReflectionTestUtils.setField(helper, "g2Events", null)
		Map<String, Object> event = [
				eventname: "AddUpdateMember"
		]

		when: "processG2Message is called"
		boolean result = helper.processG2Message(event)

		then: "no unexpected interactions"
		0 * _

		and: "result is false due to exception from null config"
		!result
	}
}
