package com.att.idp.idgraphconsumerms.helpers

import spock.lang.Specification
import spock.lang.Unroll

class BaseRuleHelperTest extends Specification {

    BaseRuleHelper baseRuleHelper

    def setup() {
        baseRuleHelper = new BaseRuleHelper()
    }

    @Unroll
    def "should validate isValidEventsData for #scenarioName"() {
        given: "A map representing event data"
        Map<String, Object> event = eventData

        when: "isValidEventsData is called"
        boolean result = baseRuleHelper.isValidEventsData(event)

        then: "The result matches the expected validity"
        result == expectedValid

        where: "Different event data scenarios"
        scenarioName                | eventData                          | expectedValid
        "null event"                | null                               | false
        "empty event"               | [:]                                | false
        "event with one entry"      | [key: "value"]                     | true
        "event with multiple keys"  | [a: 1, b: 2, c: 3]                 | true
    }
}