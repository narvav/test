package com.att.idp.idgraphconsumerms.appconfig.config

import spock.lang.Specification
import spock.lang.Unroll

class IDGraphAzureAppConfigTest extends Specification {

    @Unroll
    def "initializeCosmosConnectionSettings uses expected values for #scenarioName"() {
        given:
        IDGraphAzureAppConfig config = new IDGraphAzureAppConfig()
        config.setIdleConnectionTimeoutMsRaw(idleRaw)
        config.setMaxConnectionPoolSizeRaw(poolRaw)
        config.setPreferredRegionsRaw(preferredRegionsRaw)

        when:
        config.initializeCosmosConnectionSettings()

        then:
        config.getIdleConnectionTimeoutMs() == expectedIdle
        config.getMaxConnectionPoolSize() == expectedPool
        config.getPreferredRegions() == expectedPreferredRegions
        0 * _

        where:
        scenarioName                  | idleRaw   | poolRaw | preferredRegionsRaw           | expectedIdle | expectedPool | expectedPreferredRegions
        "valid integer values"       | "2500"   | "75"   | "East US 2,West US 2"        | 2500         | 75           | ["East US 2", "West US 2"]
        "decimal values fallback"    | "2500.5" | "75.1" | "Central US,East US 2"       | 5000         | 100          | ["Central US", "East US 2"]
        "blank values fallback"      | "   "    | ""     | ""                           | 5000         | 100          | ["East US 2", "West US 2"]
        "null values fallback"       | null      | null    | null                         | 5000         | 100          | ["East US 2", "West US 2"]
        "malformed values fallback"  | "5000"   | "100"  | " , ,   "                    | 5000         | 100          | ["East US 2", "West US 2"]
    }
}

