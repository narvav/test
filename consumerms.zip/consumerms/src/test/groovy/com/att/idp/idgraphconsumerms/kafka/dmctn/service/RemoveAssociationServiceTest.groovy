package com.att.idp.idgraphconsumerms.kafka.dmctn.service

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker
import com.att.idp.idgraphconsumerms.kafka.model.Subscriber
import com.att.idp.idgraphconsumerms.model.UserAssociationChangeRequest
import com.att.idp.idgraphconsumerms.oracle.helpers.MemberServiceDBHelper
import com.att.idp.idgraphconsumerms.oracle.helpers.MemberServiceDBHelperStub
import com.att.idp.idgraphconsumerms.request.validator.RequestValidator
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.messaging.MessageHeaders
import spock.lang.Specification
import spock.lang.Unroll

class RemoveAssociationServiceTest extends Specification {

    ApiRestClient apiRestClient = Mock()
    CosmosFailedEventsWriter cosmosFailedEventsWriter = Mock()
    GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker = Mock()
    RemoveAssociationService service
    JdbcTemplate jdbcTemplate = Mock()
    MemberServiceDBHelper memberServiceDBHelper = Mock()
    MemberServiceDBHelperStub memberServiceDBHelperStub = new MemberServiceDBHelperStub(jdbcTemplate)
    MemberServiceDBHelperStub spyStub = Spy(memberServiceDBHelperStub)

    void setup() {
        service = new RemoveAssociationService(apiRestClient, spyStub, cosmosFailedEventsWriter, gddnFailedEventCircuitBreaker)
        setField(service, "removeAssociationEndpoint", "/removeAssociation")
    }

    def "execute success path posts request (ctn=#ctn)"() {
        given:
        def subscriber = buildSubscriber(ctn, status)

        when:
        service.execute(subscriber, EventSource.GDDN)

        then:
        1 * spyStub.getGuidForGivenCTN(ctn)
        1 * apiRestClient.sendPostRequest("/removeAssociation", { body ->
            assert body instanceof UserAssociationChangeRequest
            assert body.guid == expectedGuid
            assert body.associationList?.size() == 1
            assert body.associationList[0].instanceId == ctn
            true
        }, ConsumerConstants.GridGddnNotification.EVENT_GDDN_CANCEL_SUBSCRIBER)
        0 * cosmosFailedEventsWriter.saveFailedEventsToCosmos(_)

        where:
        ctn          | status      | expectedGuid | idgraphStatus
        "5551112222" | "terminated"    | "G12345"     | "Terminated"
        "5553334444" | "cancelled" | "G98765"     | "Cancelled"

    }

    def "execute validation failure short circuits and saves failed event"() {
        given:
        overrideValidatorFailure("VAL_ERR", "Phone missing")
        def subscriber = buildSubscriber(null, "ACTIVE")

        when:
        service.execute(subscriber, EventSource.GDDN)

        then:
        0 * spyStub.getGuidForGivenCTN(_)
        0 * apiRestClient.sendPostRequest(_, _, _)
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
            assert it.errorDetails.toString().contains("VALIDATION_FAILED")
            true
        })
    }

    def "execute guid lookup returns null -> no post no failed event"() {
        given:
        def ctn = "5550000000"
        def subscriber = buildSubscriber(ctn, "ACTIVE")

        when:
        service.execute(subscriber, EventSource.GDDN)

        then:
        0 * apiRestClient.sendPostRequest(_, _, _)
        0 * cosmosFailedEventsWriter.saveFailedEventsToCosmos(_)
    }

    def "execute guid lookup returns blank -> no post no failed event"() {
        given:
        def ctn = "5559999999"
        def subscriber = buildSubscriber(ctn, "ACTIVE")
        1 * spyStub.getGuidForGivenCTN(ctn) >> Optional.of("")

        when:
        service.execute(subscriber, EventSource.GDDN)

        then:
        0 * apiRestClient.sendPostRequest(_, _, _)
        0 * cosmosFailedEventsWriter.saveFailedEventsToCosmos(_)
    }

    def "execute exception during guid lookup -> failed event saved with eventCategory"() {
        given:
        def ctn = "5557777777"
        def subscriber = buildSubscriber(ctn, "ACTIVE")

        when:
        service.execute(subscriber, EventSource.GDDN)

        then:
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(_, _) >> false
        1 * spyStub.getGuidForGivenCTN(ctn) >> { throw new RuntimeException("DB down") }
        0 * apiRestClient.sendPostRequest(_, _, _)
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ FailedEventDetails details ->
            assert details.eventName == ConsumerConstants.GridGddnNotification.EVENT_GDDN_CANCEL_SUBSCRIBER
            assert details.eventCategory == ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_SUBSCRIBER
            true
        })
        0 * _
    }

    def "circuit breaker open -> saves CIRCUIT_OPEN event without calling downstream"() {
        given:
        def ctn = "5558888888"
        def subscriber = buildSubscriber(ctn, "terminated")

        when:
        service.execute(subscriber, EventSource.GDDN)

        then:
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(ctn, ConsumerConstants.GridGddnNotification.EVENT_GDDN_CANCEL_SUBSCRIBER) >> true
        0 * spyStub.getGuidForGivenCTN(_)
        0 * apiRestClient.sendPostRequest(_, _, _)
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ FailedEventDetails details ->
            assert details.eventName == ConsumerConstants.GridGddnNotification.EVENT_GDDN_CANCEL_SUBSCRIBER
            assert details.eventCategory == ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_SUBSCRIBER
            assert details.status == "CIRCUIT_OPEN"
            assert details.accountId == ctn
            true
        })
        0 * _
    }

    def "short circuit processing if CG termination reason code exists"() {
        given:
        def ctn = "1234567890"
        def subscriber = buildSubscriber(ctn, "Terminated")
        Subscriber.StatusChangeReason statusChangeReason = new Subscriber.StatusChangeReason()
        statusChangeReason.setName(ConsumerConstants.DmctnSubscriberChangeEvent.CG_CTN_TERMINATED_REASON_CODE)

        List<Subscriber.StatusChangeReason> list1 = new ArrayList<>()
        list1.add(statusChangeReason)

        subscriber.setStatusChangeReason(list1)


        when:
        service.execute(subscriber, EventSource.GDDN)

        then:
        0 * apiRestClient.sendPostRequest(_, _, _)
        0 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
            assert it.eventName == ConsumerConstants.GridGddnNotification.EVENT_GDDN_CANCEL_SUBSCRIBER
            true
        })
    }



    private static Subscriber buildSubscriber(String phone, String status) {
        def s = new Subscriber()
        s.phoneNumber = phone
        s.status = status
        return s
    }

    private static void setField(Object target, String name, Object value) {
        def f = target.class.getDeclaredField(name)
        f.accessible = true
        f.set(target, value)
    }

    private void overrideValidatorSuccess() {
        restoreValidator()
        RequestValidator.metaClass.'static'.validate = { String v, String f ->
            [(MPSDefs.APP_STATUS_CODE): CommonDefs.COMMON_SUCCESS,
             (MPSDefs.APP_STATUS_MSG) : "OK"]
        }
    }

    private void overrideValidatorFailure(String code, String msg) {
        restoreValidator()
        RequestValidator.metaClass.'static'.validate = { String v, String f ->
            [(MPSDefs.APP_STATUS_CODE): code,
             (MPSDefs.APP_STATUS_MSG) : msg]
        }
    }

    private void restoreValidator() {
        GroovySystem.metaClassRegistry.removeMetaClass(RequestValidator)
    }
}
