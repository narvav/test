package com.att.idp.idgraphconsumerms.helpers

import spock.lang.Specification

class IDGraphBbnmsRulesHelperTest extends Specification {

    IDGraphBbnmsRulesHelper helper

    void setup() {
        helper = new IDGraphBbnmsRulesHelper()
    }

    def "should remap LSRegNotify to BBNMSAssignUverseAddressBookP2 when isSDPMigrated is Y"() {
        given:
        Map<String, Object> event = [eventname: "LSRegNotify", isSDPMigrated: "Y"]

        when:
        boolean result = helper.processBbnmsMessage(event)

        then:
        result
        event.get("eventname") == "BBNMSAssignUverseAddressBookP2"
        0 * _
    }

    def "should not process LSRegNotify when isSDPMigrated is not Y"() {
        given:
        Map<String, Object> event = [eventname: "LSRegNotify", isSDPMigrated: "N"]

        when:
        boolean result = helper.processBbnmsMessage(event)

        then:
        !result
        event.get("eventname") == "LSRegNotify"
        0 * _
    }

    def "should return false when event map is null"() {
        when:
        boolean result = helper.processBbnmsMessage(null)

        then:
        !result
        0 * _
    }

    def "should return false when event map is empty"() {
        when:
        boolean result = helper.processBbnmsMessage([:])

        then:
        !result
        0 * _
    }

    def "should return false when eventname key is missing from event"() {
        given:
        Map<String, Object> event = [isSDPMigrated: "Y"]

        when:
        boolean result = helper.processBbnmsMessage(event)

        then:
        !result
        0 * _
    }

    def "should return false when eventname is not in supported source event names"() {
        given:
        Map<String, Object> event = [eventname: "UnknownEvent", isSDPMigrated: "Y"]

        when:
        boolean result = helper.processBbnmsMessage(event)

        then:
        !result
        0 * _
    }

    def "should remap ActivateTNByBAN to BBNMSActivateTNP2 when isSDPMigrated is Y"() {
        given:
        Map<String, Object> event = [eventname: "ActivateTNByBAN", isSDPMigrated: "Y"]

        when:
        boolean result = helper.processBbnmsMessage(event)

        then:
        result
        event.get("eventname") == "BBNMSActivateTNP2"
        0 * _
    }

    def "should not process ActivateTNByBAN when isSDPMigrated is not Y"() {
        given:
        Map<String, Object> event = [eventname: "ActivateTNByBAN", isSDPMigrated: "N"]

        when:
        boolean result = helper.processBbnmsMessage(event)

        then:
        !result
        event.get("eventname") == "ActivateTNByBAN"
        0 * _
    }

    def "should return false when isSDPMigrated is null"() {
        given:
        Map<String, Object> event = [eventname: "LSRegNotify", isSDPMigrated: null]

        when:
        boolean result = helper.processBbnmsMessage(event)

        then:
        !result
        event.get("eventname") == "LSRegNotify"
        0 * _
    }

    def "should return false when isSDPMigrated key is absent"() {
        given:
        Map<String, Object> event = [eventname: "LSRegNotify"]

        when:
        boolean result = helper.processBbnmsMessage(event)

        then:
        !result
        event.get("eventname") == "LSRegNotify"
        0 * _
    }

    def "should remap event when isSDPMigrated is lowercase y"() {
        given:
        Map<String, Object> event = [eventname: "LSRegNotify", isSDPMigrated: "y"]

        when:
        boolean result = helper.processBbnmsMessage(event)

        then:
        result
        event.get("eventname") == "BBNMSAssignUverseAddressBookP2"
        0 * _
    }

    def "should return false when isSDPMigrated has whitespace only"() {
        given:
        Map<String, Object> event = [eventname: "LSRegNotify", isSDPMigrated: "   "]

        when:
        boolean result = helper.processBbnmsMessage(event)

        then:
        !result
        event.get("eventname") == "LSRegNotify"
        0 * _
    }

    def "should remap LSRegNotify when isSDPMigrated has leading and trailing whitespace around Y"() {
        given:
        Map<String, Object> event = [eventname: "LSRegNotify", isSDPMigrated: "  Y  "]

        when:
        boolean result = helper.processBbnmsMessage(event)

        then:
        result
        event.get("eventname") == "BBNMSAssignUverseAddressBookP2"
        0 * _
    }

    def "should return false when eventname value is null"() {
        given:
        Map<String, Object> event = [eventname: null, isSDPMigrated: "Y"]

        when:
        boolean result = helper.processBbnmsMessage(event)

        then:
        !result
        0 * _
    }

    def "should remap ActivateTNByBAN when isSDPMigrated is uppercase Y with whitespace"() {
        given:
        Map<String, Object> event = [eventname: "ActivateTNByBAN", isSDPMigrated: " Y "]

        when:
        boolean result = helper.processBbnmsMessage(event)

        then:
        result
        event.get("eventname") == "BBNMSActivateTNP2"
        0 * _
    }

    def "should not remap supported event when isSDPMigrated is empty string"() {
        given:
        Map<String, Object> event = [eventname: "ActivateTNByBAN", isSDPMigrated: ""]

        when:
        boolean result = helper.processBbnmsMessage(event)

        then:
        !result
        event.get("eventname") == "ActivateTNByBAN"
        0 * _
    }
}

