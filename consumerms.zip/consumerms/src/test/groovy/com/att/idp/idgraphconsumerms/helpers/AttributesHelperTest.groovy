package com.att.idp.idgraphconsumerms.helpers
import spock.lang.Specification
import spock.lang.Unroll
import com.att.idp.idgraph.events.model.Attribute
import com.att.mpsys.common.utils.CommonDefs

class AttributesHelperTest extends Specification {

    @Unroll
    def "should build attributes for #scenarioName"() {
        given: "Event and notification maps with concrete types"
        Map<String, Object> event = eventMap
        Map<String, Object> notification = notificationMap

        when: "buildAttributes is called"
        List<Attribute> result = AttributesHelper.buildAttributes(event, notification)

        then: "Result matches expected attributes"
        result.size() == expectedAttributes.size()
        for (int i = 0; i < expectedAttributes.size(); i++) {
            result.get(i).getAttributeName() == expectedAttributes.get(i).getAttributeName()
            result.get(i).getAttributeValue() == expectedAttributes.get(i).getAttributeValue()
        }

        and: "No unexpected interactions (no mocks here, but required by guidelines)"

        where: "Different cType and edge case scenarios"
        scenarioName | eventMap | notificationMap | expectedAttributes
        "null cType" | [:] | [:] | []
        "unknown cType" | [:] | [cType: "UNKNOWN"] | []
        "ONLINE_ACCOUNT_ADD2, secondaryAccessGranted=Y" |
                [(CommonDefs.KEY_OWNER_MAIN_CTN): "12345",
                 (CommonDefs.KEY_OWNER_FIRST_NAME): "John",
                 (CommonDefs.KEY_OWNER_LAST_NAME): "Doe",
                 (CommonDefs.DELEGATE_HANDLE): "secId",
                 (CommonDefs.KEY_DELEGATE_FIRST_NAME): "Jane",
                 (CommonDefs.KEY_DELEGATE_LAST_NAME): "Smith",
                 (CommonDefs.SLID): "slid1"] |
                [cType: "ONLINE_ACCOUNT_ADD2", (CommonDefs.KEY_OWNER_MAIN_CTN): "12345", secondaryAccessGranted: "Y", ownerSLID: "ownId", notificationAcctType: "wireless"] |
                [
                        new Attribute("mainCTN", "12345"),
                        new Attribute("FirstNameOwn", "John"),
                        new Attribute("LastNameOwn", "Doe"),
                        new Attribute("AccessIdOwn", "ownId"),
                        new Attribute("AccessIdSec", "secId"),
                        new Attribute("FirstNameSec", "Jane"),
                        new Attribute("LastNameSec", "Smith"),
                        new Attribute("notificationAcctType", "wireless")
                ]
        "ONLINE_ACCOUNT_ADD2, secondaryAccessGranted=N" |
                [(CommonDefs.KEY_OWNER_MAIN_CTN): "12345",
                 (CommonDefs.KEY_OWNER_FIRST_NAME): "John",
                 (CommonDefs.KEY_OWNER_LAST_NAME): "Doe",
                 (CommonDefs.SLID): "slid1"] |
                [cType: "ONLINE_ACCOUNT_ADD2", (CommonDefs.KEY_OWNER_MAIN_CTN): "12345", secondaryAccessGranted: "N"] |
                [
                        new Attribute("mainCTN", "12345"),
                        new Attribute("FirstNameOwn", "John"),
                        new Attribute("LastNameOwn", "Doe"),
                        new Attribute("AccessIdOwn", "slid1")
                ]
        "ONLINE_ACCOUNT_ADD_SEC" |
                [(CommonDefs.KEY_OWNER_MAIN_CTN): "12345",
                 (CommonDefs.KEY_DELEGATE_MAIN_CTN): "54321",
                 (CommonDefs.KEY_DELEGATE_FIRST_NAME): "Jane",
                 (CommonDefs.KEY_DELEGATE_LAST_NAME): "Smith",
                 (CommonDefs.DELEGATE_HANDLE): "secId"] |
                [cType: "ONLINE_ACCOUNT_ADD_SEC", notificationAcctType: "wireless"] |
                [
                        new Attribute("mainCTN", "54321"),
                        new Attribute("FirstNameSec", "Jane"),
                        new Attribute("LastNameSec", "Smith"),
                        new Attribute("accessIdSec", "secId"),
                        new Attribute("notificationAcctType", "wireless")
                ]
        "CTN_ADDED_TO_ACCESSID" |
                [:] |
                [cType: "CTN_ADDED_TO_ACCESSID", mainCTN: "99999"] |
                [
                        new Attribute("mainCTN", "99999"),
                        new Attribute("notificationAccountType", "wireless")
                ]
        "CTN_CHANGED_ON_ACCESSID with oldMainCTN" |
                [:] |
                [cType: "CTN_CHANGED_ON_ACCESSID", mainCTN: "11111", oldMainCTN: "22222"] |
                [
                        new Attribute("mainCTN", "11111"),
                        new Attribute("mainCTNprev", "22222")
                ]
        "LVLTWO_ACCESSID_LOCK" |
                [(CommonDefs.USER_LOCK_LEVEL): 2, (CommonDefs.USER_LOCK_REASON_CODE): "reason", firstName: "John", lastName: "Doe"] |
                [cType: "LVLTWO_ACCESSID_LOCK"] |
                [
                        new Attribute("userLockLevel", "2"),
                        new Attribute("userLockReasonCode", "reason"),
                        new Attribute("FirstName", "John"),
                        new Attribute("LastName", "Doe")
                ]
        "ACCOUNT_LOCK" |
                [(CommonDefs.ACCOUNT_LOCK_REASON): "locked"] |
                [cType: "ACCOUNT_LOCK"] |
                [
                        new Attribute("accountLockedReasonCode", "locked")
                ]
        "EML_ADDR_VALIDATION with both encryptedKey and sorSystem" |
                [:] |
                [cType: "EML_ADDR_VALIDATION", EncryptedKey: "abc123xyz", sorSystem: "CRIS"] |
                [
                        new Attribute("emlAddrValidationLink", "abc123xyz"),
                        new Attribute("sorSystem", "CRIS")
                ]
        "EML_ADDR_VALIDATION with only encryptedKey" |
                [:] |
                [cType: "EML_ADDR_VALIDATION", EncryptedKey: "key456"] |
                [
                        new Attribute("emlAddrValidationLink", "key456")
                ]
        "EML_ADDR_VALIDATION with only sorSystem" |
                [:] |
                [cType: "EML_ADDR_VALIDATION", sorSystem: "OPUS"] |
                [
                        new Attribute("sorSystem", "OPUS")
                ]
        "EML_ADDR_VALIDATION with neither encryptedKey nor sorSystem" |
                [:] |
                [cType: "EML_ADDR_VALIDATION"] |
                []
        "HS_CBR_CONFIRM with EncryptedKey in notificationData" |
                [notificationData: [EncryptedKey: "encKey789"]] |
                [cType: "HS_CBR_CONFIRM"] |
                [
                        new Attribute("longUrl", "https://www.att.com/acctmgmt/myprofile/verify?m=encKey789")
                ]
        "HS_CBR_CONFIRM with notificationData as List containing EncryptedKey" |
                [notificationData: [[EncryptedKey: "listKey123"]]] |
                [cType: "HS_CBR_CONFIRM"] |
                [
                        new Attribute("longUrl", "https://www.att.com/acctmgmt/myprofile/verify?m=listKey123")
                ]
        "HS_CBR_CONFIRM without EncryptedKey in notificationData" |
                [notificationData: [:]] |
                [cType: "HS_CBR_CONFIRM"] |
                []
        "HS_CBR_CONFIRM without notificationData" |
                [:] |
                [cType: "HS_CBR_CONFIRM"] |
                []
        "PROFILE_UPDATE with slid.dum domain and defaultAccountChanged" |
                [(CommonDefs.CRM_HANDLE): "testHandle", (CommonDefs.CRM_DOMAIN): "slid.dum", action: "update"] |
                [cType: "PROFILE_UPDATE", defaultAccountChanged: "Y"] |
                [
                        new Attribute("action", "update"),
                        new Attribute("profileId", "testHandle"),
                        new Attribute("profileElement", "DEFAULT_ACCT")
                ]
        "PROFILE_UPDATE with other domain and defaultAccountChanged" |
                [(CommonDefs.CRM_HANDLE): "testHandle", (CommonDefs.CRM_DOMAIN): "example.com", action: "update"] |
                [cType: "PROFILE_UPDATE", defaultAccountChanged: "Y"] |
                [
                        new Attribute("action", "update"),
                        new Attribute("profileId", "testHandle@example.com"),
                        new Attribute("profileElement", "DEFAULT_ACCT")
                ]
        "PROFILE_UPDATE with slid.dum domain and primaryEmailChanged" |
                [(CommonDefs.CRM_HANDLE): "testHandle", (CommonDefs.CRM_DOMAIN): "slid.dum", action: "update"] |
                [cType: "PROFILE_UPDATE", primaryEmailChanged: "Y"] |
                [
                        new Attribute("action", "update"),
                        new Attribute("profileId", "testHandle"),
                        new Attribute("profileElement", "CONTACT_EMAIL")
                ]
        "PROFILE_UPDATE with other domain and primaryEmailChanged" |
                [(CommonDefs.CRM_HANDLE): "testHandle", (CommonDefs.CRM_DOMAIN): "att.com", action: "update"] |
                [cType: "PROFILE_UPDATE", primaryEmailChanged: "Y"] |
                [
                        new Attribute("action", "update"),
                        new Attribute("profileId", "testHandle@att.com"),
                        new Attribute("profileElement", "CONTACT_EMAIL")
                ]
        "PROFILE_UPDATE with slid.dum domain and no changes" |
                [(CommonDefs.CRM_HANDLE): "testHandle", (CommonDefs.CRM_DOMAIN): "slid.dum", action: "update"] |
                [cType: "PROFILE_UPDATE"] |
                [
                        new Attribute("action", "update"),
                        new Attribute("profileId", "testHandle")
                ]
        "PROFILE_UPDATE with other domain and no changes" |
                [(CommonDefs.CRM_HANDLE): "testHandle", (CommonDefs.CRM_DOMAIN): "test.domain", action: "update"] |
                [cType: "PROFILE_UPDATE"] |
                [
                        new Attribute("action", "update"),
                        new Attribute("profileId", "testHandle@test.domain")
                ]
        "PROFILE_UPDATE with defaultAccountChanged = N (not Y)" |
                [(CommonDefs.CRM_HANDLE): "testHandle", (CommonDefs.CRM_DOMAIN): "slid.dum", action: "update"] |
                [cType: "PROFILE_UPDATE", defaultAccountChanged: "N"] |
                [
                        new Attribute("action", "update"),
                        new Attribute("profileId", "testHandle")
                ]
        "PROFILE_UPDATE with primaryEmailChanged = N (not Y)" |
                [(CommonDefs.CRM_HANDLE): "testHandle", (CommonDefs.CRM_DOMAIN): "slid.dum", action: "update"] |
                [cType: "PROFILE_UPDATE", primaryEmailChanged: "N"] |
                [
                        new Attribute("action", "update"),
                        new Attribute("profileId", "testHandle")
                ]
        "PROFILE_UPDATE with both defaultAccountChanged and primaryEmailChanged (defaultAccount takes precedence)" |
                [(CommonDefs.CRM_HANDLE): "testHandle", (CommonDefs.CRM_DOMAIN): "slid.dum", action: "update"] |
                [cType: "PROFILE_UPDATE", defaultAccountChanged: "Y", primaryEmailChanged: "Y"] |
                [
                        new Attribute("action", "update"),
                        new Attribute("profileId", "testHandle"),
                        new Attribute("profileElement", "DEFAULT_ACCT")
                ]
        "DELETE_ACCOUNT with firstName" |
                [firstName: "John"] |
                [cType: "DELETE_ACCOUNT", AccountLast4: "1234"] |
                [
                        new Attribute("profileId", "1234"),
                        new Attribute("profileIdType", "BAN"),
                        new Attribute("FirstName", "John")
                ]
        "DELETE_ACCOUNT without firstName" |
                [:] |
                [cType: "DELETE_ACCOUNT", AccountLast4: "5678"] |
                [
                        new Attribute("profileId", "5678"),
                        new Attribute("profileIdType", "BAN")
                ]
        "ONLINE_ACCOUNT_REG with firstName and qarKey in notificationData Map" |
                [firstName: "Jane", notificationData: [qarKey: "qar123xyz"]] |
                [cType: "ONLINE_ACCOUNT_REG", AccountLast4: "9876"] |
                [
                        new Attribute("profileId", "9876"),
                        new Attribute("profileIdType", "BAN"),
                        new Attribute("firstName", "Jane"),
                        new Attribute("qarKey", "qar123xyz")
                ]
        "ONLINE_ACCOUNT_REG with firstName and qarKey in notificationData List" |
                [firstName: "Bob", notificationData: [[qarKey: "qarABC456"]]] |
                [cType: "ONLINE_ACCOUNT_REG", AccountLast4: "4321"] |
                [
                        new Attribute("profileId", "4321"),
                        new Attribute("profileIdType", "BAN"),
                        new Attribute("firstName", "Bob"),
                        new Attribute("qarKey", "qarABC456")
                ]
        "ONLINE_ACCOUNT_REG with firstName but no qarKey" |
                [firstName: "Alice", notificationData: [:]] |
                [cType: "ONLINE_ACCOUNT_REG", AccountLast4: "5555"] |
                [
                        new Attribute("profileId", "5555"),
                        new Attribute("profileIdType", "BAN"),
                        new Attribute("firstName", "Alice")
                ]
        "ONLINE_ACCOUNT_REG without firstName but with qarKey" |
                [notificationData: [qarKey: "qarNoName789"]] |
                [cType: "ONLINE_ACCOUNT_REG", AccountLast4: "3333"] |
                [
                        new Attribute("profileId", "3333"),
                        new Attribute("profileIdType", "BAN"),
                        new Attribute("qarKey", "qarNoName789")
                ]
        "ONLINE_ACCOUNT_REG without firstName and without qarKey" |
                [notificationData: [:]] |
                [cType: "ONLINE_ACCOUNT_REG", AccountLast4: "7777"] |
                [
                        new Attribute("profileId", "7777"),
                        new Attribute("profileIdType", "BAN")
                ]
        "ONLINE_ACCOUNT_REG with notificationData as null" |
                [:] |
                [cType: "ONLINE_ACCOUNT_REG", AccountLast4: "8888"] |
                [
                        new Attribute("profileId", "8888"),
                        new Attribute("profileIdType", "BAN")
                ]
        "ONLINE_ACCOUNT_REG with firstName and notificationData as null" |
                [firstName: "Charlie"] |
                [cType: "ONLINE_ACCOUNT_REG", AccountLast4: "2222"] |
                [
                        new Attribute("profileId", "2222"),
                        new Attribute("profileIdType", "BAN"),
                        new Attribute("firstName", "Charlie")
                ]
        "ONLINE_ACCOUNT_REG with empty notificationData List" |
                [firstName: "David", notificationData: []] |
                [cType: "ONLINE_ACCOUNT_REG", AccountLast4: "6666"] |
                [
                        new Attribute("profileId", "6666"),
                        new Attribute("profileIdType", "BAN"),
                        new Attribute("firstName", "David")
                ]
        "ACCESS_GRANTED_PRIMARY with all owner and delegate attributes" |
                [ownerFirstName: "John", ownerLastName: "Doe", delegateFirstName: "Jane", delegateLastName: "Smith", delegateHandle: "jsmith", delegateDomain: "att.net"] |
                [cType: "ACCESS_GRANTED_PRIMARY"] |
                [
                        new Attribute("FirstNameOwn", "John"),
                        new Attribute("LastNameOwn", "Doe"),
                        new Attribute("FirstNameSec", "Jane"),
                        new Attribute("LastNameSec", "Smith"),
                        new Attribute("AccessIdSec", "jsmith@att.net")
                ]
        "ACCESS_GRANTED_PRIMARY with only owner attributes" |
                [ownerFirstName: "John", ownerLastName: "Doe"] |
                [cType: "ACCESS_GRANTED_PRIMARY"] |
                [
                        new Attribute("FirstNameOwn", "John"),
                        new Attribute("LastNameOwn", "Doe")
                ]
        "ACCESS_GRANTED_PRIMARY with only delegate attributes" |
                [delegateFirstName: "Jane", delegateLastName: "Smith", delegateHandle: "jsmith", delegateDomain: "att.net"] |
                [cType: "ACCESS_GRANTED_PRIMARY"] |
                [
                        new Attribute("FirstNameSec", "Jane"),
                        new Attribute("LastNameSec", "Smith"),
                        new Attribute("AccessIdSec", "jsmith@att.net")
                ]
        "ACCESS_GRANTED_PRIMARY with delegate handle but no domain" |
                [ownerFirstName: "John", delegateHandle: "jsmith"] |
                [cType: "ACCESS_GRANTED_PRIMARY"] |
                [
                        new Attribute("FirstNameOwn", "John")
                ]
        "ACCESS_GRANTED_PRIMARY with delegate domain but no handle" |
                [ownerFirstName: "John", delegateDomain: "att.net"] |
                [cType: "ACCESS_GRANTED_PRIMARY"] |
                [
                        new Attribute("FirstNameOwn", "John")
                ]
        "ACCESS_GRANTED_PRIMARY with no attributes" |
                [:] |
                [cType: "ACCESS_GRANTED_PRIMARY"] |
                []
        "ACCESS_GRANTED_SECONDARY with delegate attributes" |
                [delegateFirstName: "Jane", delegateLastName: "Smith"] |
                [cType: "ACCESS_GRANTED_SECONDARY"] |
                [
                        new Attribute("FirstName", "Jane"),
                        new Attribute("LastName", "Smith")
                ]
        "ACCESS_GRANTED_SECONDARY with only firstName" |
                [delegateFirstName: "Jane"] |
                [cType: "ACCESS_GRANTED_SECONDARY"] |
                [
                        new Attribute("FirstName", "Jane")
                ]
        "ACCESS_GRANTED_SECONDARY with only lastName" |
                [delegateLastName: "Smith"] |
                [cType: "ACCESS_GRANTED_SECONDARY"] |
                [
                        new Attribute("LastName", "Smith")
                ]
        "ACCESS_GRANTED_SECONDARY with no attributes" |
                [:] |
                [cType: "ACCESS_GRANTED_SECONDARY"] |
                []
        "PROFILE_UPDATE_SECURE_KEY" |
                [action: "Add"] |
                [cType: "PROFILE_UPDATE_SECURE_KEY"] |
                [
                        new Attribute("ProfileAction", "Add")
                ]
        "WIRELINE_HS_CBR_UPDATE with all phone details" |
                [notificationData: [PhoneUpdateDetailsChanged: [[action: "update", phoneCategory: "mobile", phoneNumber: "1234567890", phoneType: "primary", phoneNumberOld: "0987654321", phoneTypeOld: "secondary"]]]] |
                [cType: "WIRELINE_HS_CBR_UPDATE"] |
                [
                        new Attribute("action", "update"),
                        new Attribute("phoneCategory", "mobile"),
                        new Attribute("phoneNumber", "1234567890"),
                        new Attribute("phoneType", "primary"),
                        new Attribute("phoneNumberOld", "0987654321"),
                        new Attribute("phoneTypeOld", "secondary")
                ]
        "WIRELINE_HS_CBR_UPDATE with partial phone details" |
                [notificationData: [PhoneUpdateDetailsChanged: [[action: "add", phoneNumber: "5551234567"]]]] |
                [cType: "WIRELINE_HS_CBR_UPDATE"] |
                [
                        new Attribute("action", "add"),
                        new Attribute("phoneNumber", "5551234567")
                ]
        "WIRELINE_HS_CBR_UPDATE with empty phone details list" |
                [notificationData: [PhoneUpdateDetailsChanged: []]] |
                [cType: "WIRELINE_HS_CBR_UPDATE"] |
                []
        "WIRELINE_HS_CBR_UPDATE with no notificationData" |
                [:] |
                [cType: "WIRELINE_HS_CBR_UPDATE"] |
                []
        "PRIN_USER_UPDATE with all fields" |
                [firstName: "John", lastName: "Doe"] |
                [cType: "PRIN_USER_UPDATE", AccountLast4: "1234"] |
                [
                        new Attribute("FirstName", "John"),
                        new Attribute("LastName", "Doe"),
                        new Attribute("AccountLast4", "1234")
                ]
        "PRIN_USER_UPDATE with only firstName" |
                [firstName: "Jane"] |
                [cType: "PRIN_USER_UPDATE"] |
                [
                        new Attribute("FirstName", "Jane")
                ]
        "UPDATE_CONTACT_EMAIL with all fields" |
                [firstName: "Bob", lastName: "Smith"] |
                [cType: "UPDATE_CONTACT_EMAIL", AccountLast4: "5678"] |
                [
                        new Attribute("FirstName", "Bob"),
                        new Attribute("LastName", "Smith"),
                        new Attribute("AccountLast4", "5678")
                ]
        "PM_ACCT_CREATION with firstName" |
                [firstName: "Alice"] |
                [cType: "PM_ACCT_CREATION"] |
                [
                        new Attribute("FirstName", "Alice")
                ]
        "PM_ACCT_CREATION without firstName" |
                [:] |
                [cType: "PM_ACCT_CREATION"] |
                []
        "SLID_TITANIZED with all fields" |
                [firstName: "Charlie", lastName: "Brown"] |
                [cType: "SLID_TITANIZED", handle: "cbrown", MultiProductInd: "Y", ServiceType: "wireless"] |
                [
                        new Attribute("FirstName", "Charlie"),
                        new Attribute("LastName", "Brown"),
                        new Attribute("AccessId", "cbrown"),
                        new Attribute("MultiProductInd", "Y"),
                        new Attribute("ServiceType", "wireless")
                ]
        "SLID_TITANIZED with partial fields" |
                [firstName: "David"] |
                [cType: "SLID_TITANIZED", handle: "david123"] |
                [
                        new Attribute("FirstName", "David"),
                        new Attribute("AccessId", "david123")
                ]
        "SWAP_OWNERSHIP with all fields" |
                [firstName: "Eve", lastName: "Wilson"] |
                [cType: "SWAP_OWNERSHIP", NewProfileId: "profile123", OldProfileId: "profile456"] |
                [
                        new Attribute("FirstNameOwn", "Eve"),
                        new Attribute("LastNameOwn", "Wilson"),
                        new Attribute("NewProfileId", "profile123"),
                        new Attribute("OldProfileId", "profile456")
                ]
        "SWAP_OWNERSHIP with only names" |
                [firstName: "Frank", lastName: "Miller"] |
                [cType: "SWAP_OWNERSHIP"] |
                [
                        new Attribute("FirstNameOwn", "Frank"),
                        new Attribute("LastNameOwn", "Miller")
                ]
        "MERGE_ACCOUNT_NOTIFY1 with all fields" |
                [firstName: "Grace", lastName: "Taylor"] |
                [cType: "MERGE_ACCOUNT_NOTIFY1", ProfileId: "prof789", ProfileIDElement: "element123"] |
                [
                        new Attribute("ATTAccessID", "Grace"),
                        new Attribute("MainCTN2", "Taylor"),
                        new Attribute("ProfileId", "prof789"),
                        new Attribute("isProfileIdAutoGenerated", "Grace"),
                        new Attribute("ServiceName", "Taylor"),
                        new Attribute("ProfileIDElement", "element123")
                ]
        "MERGE_ACCOUNT_NOTIFY1 with minimal fields" |
                [firstName: "Henry"] |
                [cType: "MERGE_ACCOUNT_NOTIFY1"] |
                [
                        new Attribute("ATTAccessID", "Henry"),
                        new Attribute("isProfileIdAutoGenerated", "Henry")
                ]
        "SLID_UPDATE with newSLID in notificationData Map" |
                [notificationData: [newSLID: "newSlid123"]] |
                [cType: "SLID_UPDATE"] |
                [
                        new Attribute("SingleLoginId", "newSlid123")
                ]
        "SLID_UPDATE with newSLID in notificationData List" |
                [notificationData: [[newSLID: "newSlidList456"]]] |
                [cType: "SLID_UPDATE"] |
                [
                        new Attribute("SingleLoginId", "newSlidList456")
                ]
        "SLID_UPDATE with blank newSLID" |
                [notificationData: [newSLID: ""]] |
                [cType: "SLID_UPDATE"] |
                []
        "SLID_UPDATE with notificationData missing newSLID" |
                [notificationData: [otherKey: "value"]] |
                [cType: "SLID_UPDATE"] |
                []
    }

    def "should return empty attributes for SLID_UPDATE when notificationData is absent"() {
        given: "Event without notificationData and notification with cType SLID_UPDATE"
        Map<String, Object> event = [:]
        Map<String, Object> notification = [cType: "SLID_UPDATE"]

        when: "buildAttributes is called"
        List<Attribute> result = AttributesHelper.buildAttributes(event, notification)

        then: "No unexpected interactions"
        0 * _

        and: "Empty attributes returned since notificationData is null-safe"
        result.isEmpty()
    }

    @Unroll
    def "should build attributes for ACCESSID_FRAUD_UNLOCK for #scenarioName"() {
        given: "Event map with firstName and lastName, and notification map with cType ACCESSID_FRAUD_UNLOCK"
        Map<String, Object> event = eventMap
        Map<String, Object> notification = [cType: "ACCESSID_FRAUD_UNLOCK"]

        when: "buildAttributes is called"
        List<Attribute> result = AttributesHelper.buildAttributes(event, notification)

        then: "Result contains expected firstName and lastName attributes"
        result.size() == expectedAttributes.size()
        for (int i = 0; i < expectedAttributes.size(); i++) {
            Attribute actual = result.get(i)
            Attribute expected = expectedAttributes.get(i)
            actual.getAttributeName() == expected.getAttributeName()
            actual.getAttributeValue() == expected.getAttributeValue()
        }

        where: "Different event map scenarios"
        scenarioName                | eventMap                                                      | expectedAttributes
        "both names present"        | [firstName: "Alice", lastName: "Smith"]                       | [new Attribute("FirstName", "Alice"), new Attribute("LastName", "Smith")]
        "only firstName present"    | [firstName: "Bob"]                                            | [new Attribute("FirstName", "Bob")]
        "only lastName present"     | [lastName: "Johnson"]                                         | [new Attribute("LastName", "Johnson")]
        "neither name present"      | [:]                                                           | []
    }

}
