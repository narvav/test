package com.att.idp.idgraphconsumerms.helpers

import com.att.idp.idgraph.db.cosmos.helper.CosmosFailedEventsDBHelper
import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import spock.lang.Specification
import spock.lang.Unroll

class GddnFailedEventCircuitBreakerTest extends Specification {

    GddnFailedEventCircuitBreaker circuitBreaker
    CosmosFailedEventsDBHelper cosmosFailedEventsDBHelper = Mock()

    def setup() {
        circuitBreaker = new GddnFailedEventCircuitBreaker(cosmosFailedEventsDBHelper)
    }

    def "shouldShortCircuit returns false for non-GDDN events"() {
        when:
        boolean result = circuitBreaker.shouldShortCircuit("acct-123", "BSSEMigWireless")

        then: "no Cosmos check needed for non-GDDN events"
        0 * cosmosFailedEventsDBHelper._
        result == false
    }

    def "shouldShortCircuit returns false for null event name"() {
        when:
        boolean result = circuitBreaker.shouldShortCircuit("acct-123", null)

        then:
        0 * cosmosFailedEventsDBHelper._
        result == false
    }

    def "shouldShortCircuit returns true when pending failed events exist"() {
        when:
        boolean result = circuitBreaker.shouldShortCircuit("acct-123",
                ConsumerConstants.GridGddnNotification.EVENT_GDDN_CLOSE_ACCOUNT)

        then:
        1 * cosmosFailedEventsDBHelper.hasPendingFailedEvents("acct-123",
                ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT) >> true
        result == true
        0 * _
    }

    def "shouldShortCircuit returns false when no pending failed events"() {
        when:
        boolean result = circuitBreaker.shouldShortCircuit("acct-456",
                ConsumerConstants.GridGddnNotification.EVENT_GDDN_ACTIVATE_ACCOUNT)

        then:
        1 * cosmosFailedEventsDBHelper.hasPendingFailedEvents("acct-456",
                ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT) >> false
        result == false
        0 * _
    }

    @Unroll
    def "shouldShortCircuit resolves correct category for #eventName"() {
        when:
        circuitBreaker.shouldShortCircuit("acct-123", eventName)

        then:
        1 * cosmosFailedEventsDBHelper.hasPendingFailedEvents("acct-123", expectedCategory) >> false
        0 * _

        where:
        eventName                                                              | expectedCategory
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_ACTIVATE_ACCOUNT    | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_CLOSE_ACCOUNT       | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_CHANGE_PRODUCT      | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_PLATFORM_HANDLER    | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT      | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_FAN_UPDATE
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_RG_ACTIVATION       | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_RG_ACTIVATION
    }

    def "shouldShortCircuit returns false for empty string event name"() {
        when:
        boolean result = circuitBreaker.shouldShortCircuit("acct-123", "")

        then:
        0 * cosmosFailedEventsDBHelper.hasPendingFailedEvents(_, _)
        result == false
        0 * _
    }

    def "shouldShortCircuit defaults to CLOSED (false) when Cosmos check throws exception — fail-open"() {
        when:
        boolean result = circuitBreaker.shouldShortCircuit("acct-123",
                ConsumerConstants.GridGddnNotification.EVENT_GDDN_CLOSE_ACCOUNT)

        then: "Cosmos throws — fail-open: proceed with API call, don't block"
        1 * cosmosFailedEventsDBHelper.hasPendingFailedEvents("acct-123",
                ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT) >> { throw new RuntimeException("Cosmos unavailable") }
        result == false
        0 * _
    }

    def "shouldShortCircuit does not throw when Cosmos check fails — returns false (fail-open)"() {
        when:
        boolean result = circuitBreaker.shouldShortCircuit("acct-123",
                ConsumerConstants.GridGddnNotification.EVENT_GDDN_ACTIVATE_ACCOUNT)

        then:
        1 * cosmosFailedEventsDBHelper.hasPendingFailedEvents("acct-123",
                ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT) >> { throw new RuntimeException("timeout") }
        noExceptionThrown()
        result == false
    }
}
