package com.att.idp.idgraphconsumerms.cosmos.nosql

import com.att.idp.idgraph.db.cosmos.entity.BSSEMigrationStatus
import com.att.idp.idgraphconsumerms.kafka.model.MigrationBANNotification
import spock.lang.Specification

class BsseMigrationStatusTest extends Specification {

    def "test BsseMigrationStatus getters and setters"() {
        given:
        def migrationStatus = new BSSEMigrationStatus()

        def mbn = new MigrationBANNotification()

        when:
        migrationStatus.setBan("BAN123")
        migrationStatus.setIndividualId("IND456")
        migrationStatus.setSourceMarketCode("US")
        migrationStatus.setCreatedDate("2023-10-01")
        migrationStatus.setGuid("GUID789")
        migrationStatus.setTargetBan("TARGETBAN")
        migrationStatus.setIsMigrated("true")
        migrationStatus.setMigStatus("SUCCESS")
        migrationStatus.setMigStatusReason("None")
        migrationStatus.setTraceId("TRACE123")
        migrationStatus.setEventId("EVENT456")
        migrationStatus.setMigrationId("MIG789")
        migrationStatus.setOriginalRequest("mbn")
        migrationStatus.setPasscodeVenc("PASS123")

        then:
        migrationStatus.getBan() == "BAN123"
        migrationStatus.getIndividualId() == "IND456"
        migrationStatus.getSourceMarketCode() == "US"
        migrationStatus.getCreatedDate() == "2023-10-01"
        migrationStatus.getGuid() == "GUID789"
        migrationStatus.getTargetBan() == "TARGETBAN"
        migrationStatus.getIsMigrated() == "true"
        migrationStatus.getMigStatus() == "SUCCESS"
        migrationStatus.getMigStatusReason() == "None"
        migrationStatus.getTraceId() == "TRACE123"
        migrationStatus.getEventId() == "EVENT456"
        migrationStatus.getMigrationId() == "MIG789"
        migrationStatus.getOriginalRequest() == "mbn"
        migrationStatus.getPasscodeVenc() == "PASS123"
    }
}