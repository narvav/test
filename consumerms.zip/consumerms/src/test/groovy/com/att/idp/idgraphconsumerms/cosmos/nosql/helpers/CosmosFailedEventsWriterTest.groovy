package com.att.idp.idgraphconsumerms.cosmos.nosql.helpers

import com.att.idp.idgraph.db.cosmos.entity.IdgraphFailedEvents
import com.att.idp.idgraph.db.cosmos.helper.CosmosFailedEventsDBHelper
import com.att.idp.idgraph.db.cosmos.entity.FailedEventStatus
import com.att.idp.idgraph.db.cosmos.util.Constants
import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails
import com.att.idp.idgraphconsumerms.kafka.KafkaListenerAutomation
import com.att.idp.idgraphconsumerms.kafka.model.MigrationBANNotification
import com.att.idp.idgraphconsumerms.utils.JsonService
import com.azure.cosmos.implementation.ServiceUnavailableException
import spock.lang.Specification
import spock.lang.Unroll

class CosmosFailedEventsWriterTest extends Specification {

    def cosmosFailedEventsDBHelper = Mock(CosmosFailedEventsDBHelper)
    def kafkaListenerAutomation = Mock(KafkaListenerAutomation)
    def cosmosFailedEventsWriter = new CosmosFailedEventsWriter()

    def setup() {
        cosmosFailedEventsWriter.cosmosFailedEventsDBHelper = cosmosFailedEventsDBHelper
        cosmosFailedEventsWriter.kafkaListenerAutomation = kafkaListenerAutomation
        cosmosFailedEventsWriter.processedEnvPrefix = "TEST"
        cosmosFailedEventsWriter.region = "east"
    }

    def "test saveFailedEventsToCosmos with valid payload"() {
        given:
        FailedEventDetails details = new FailedEventDetails( "1234567",
                "{\"accountId\":\"1234567\"}",
                "idpMigrationNotificationListener",
                ["errorDetails":"test"])

        when:
        cosmosFailedEventsWriter.saveFailedEventsToCosmos(details)

        then:
        1 * cosmosFailedEventsDBHelper.addFailedEvents(_ as IdgraphFailedEvents, null)
        0 * kafkaListenerAutomation.stopListener(_)
    }

    def "test saveFailedEventsToCosmos with exception"() {
        given:
        FailedEventDetails details = new FailedEventDetails( "1234567",
                "{\"accountId\":\"1234567\"}",
                "idpMigrationNotificationListener",
                ["errorDetails":"test"])

        cosmosFailedEventsDBHelper.addFailedEvents(_, _) >> { throw new ServiceUnavailableException() }

        when:
        cosmosFailedEventsWriter.saveFailedEventsToCosmos(details)

        then:
        1 * kafkaListenerAutomation.stopListener("idpMigrationNotificationListener")
    }

    @Unroll
    def "should auto-resolve eventCategory from GDDN event name #eventName"() {
        given:
        FailedEventDetails details = new FailedEventDetails("ACC-CAT",
                '{"test":"payload"}',
                eventName,
                ["accountType": ConsumerConstants.AccountNotificationConstants.WIRELESS,
                 "errorCode": "SYS_ERR",
                 "errorMessage": "test error",
                 "failedEndpoint": "/mock/endpoint"])

        when:
        cosmosFailedEventsWriter.saveFailedEventsToCosmos(details)

        then: "Cosmos entity is saved with correct eventCategory and PENDING status"
        1 * cosmosFailedEventsDBHelper.addFailedEvents({ IdgraphFailedEvents fe ->
            fe.eventCategory == expectedCategory &&
            fe.eventName == eventName &&
            fe.accountNumber == "ACC-CAT" &&
            fe.status == FailedEventStatus.FAILED.name() &&
            fe.retryCounter == "0" &&
            fe.sequenceNumber != null
        }, null)
        0 * _

        where:
        eventName                                                                      | expectedCategory
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_CLOSE_ACCOUNT                | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_ACTIVATE_ACCOUNT             | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT               | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_FAN_UPDATE
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_RG_ACTIVATION                | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_RG_ACTIVATION
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_PLATFORM_HANDLER             | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_CHANGE_PRODUCT               | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT
    }

    def "should set eventCategory to null for non-GDDN event names"() {
        given:
        FailedEventDetails details = new FailedEventDetails("ACC-NOCAT",
                '{"test":"payload"}',
                "BSSEMigWireless",
                ["accountType": "BSSE", "errorCode": "SYS_ERR",
                 "errorMessage": "test", "failedEndpoint": "/mock"])

        when:
        cosmosFailedEventsWriter.saveFailedEventsToCosmos(details)

        then: "eventCategory is null because EventCategoryResolver does not map non-GDDN events"
        1 * cosmosFailedEventsDBHelper.addFailedEvents({ IdgraphFailedEvents fe ->
            fe.eventCategory == null &&
            fe.eventName == "BSSEMigWireless" &&
            fe.status == FailedEventStatus.FAILED.name() &&
            fe.sequenceNumber != null
        }, null)
        0 * _
    }

    def "should use explicit eventCategory from FailedEventDetails when provided"() {
        given:
        FailedEventDetails details = FailedEventDetails.builder()
                .accountId("ACC-EXPLICIT")
                .requestPayload('{"test":"payload"}')
                .eventName("CustomEvent")
                .eventCategory("CustomCategory")
                .errorDetails(["accountType": "CUSTOM", "errorCode": "ERR",
                               "errorMessage": "test", "failedEndpoint": "/mock"])
                .build()

        when:
        cosmosFailedEventsWriter.saveFailedEventsToCosmos(details)

        then: "Explicit eventCategory takes precedence over EventCategoryResolver"
        1 * cosmosFailedEventsDBHelper.addFailedEvents({ IdgraphFailedEvents fe ->
            fe.eventCategory == "CustomCategory" &&
            fe.eventName == "CustomEvent"
        }, null)
        0 * _
    }
}
