package com.att.idp.idgraphconsumerms.kafka.dmctn.service

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import spock.lang.Specification
import spock.lang.Shared
import spock.lang.Unroll

class RGPHOServiceFactoryTest extends Specification {

    @Shared OrchestrationWirelessService changeProductNotificationService = Mock(OrchestrationWirelessService)
    @Shared DeletePlatformHandlerNotificationService deletePlatformHandlerNotificationService = Mock(DeletePlatformHandlerNotificationService)
    @Shared RGActivationNotificationService rgActivationNotificationService = Mock(RGActivationNotificationService)

    @Unroll
    def "should select correct BaseService for #scenarioName"() {
        given:
        RGPHOServiceFactory factory = new RGPHOServiceFactory(changeProductNotificationService,
                deletePlatformHandlerNotificationService, rgActivationNotificationService)
        BaseService expectedService = expectedServiceKey == 'PRODUCT' ? changeProductNotificationService :
                expectedServiceKey == 'DELETE' ? deletePlatformHandlerNotificationService :
                expectedServiceKey == 'RGACTIVATION' ? rgActivationNotificationService : null

        when:
        BaseService result = factory.getService(eventType)

        then:
        result == expectedService
        0 * _

        where:
        scenarioName                    | eventType                                                                  | expectedServiceKey
        "ChangeProduct"                | ConsumerConstants.ProductNotificationConstants.EVENT_TYPE_PRODUCT_CHANGE   | 'PRODUCT'
        "RGActivation"                 | ConsumerConstants.ProductNotificationConstants.EVENT_TYPE_RG_NOTIFICATION  | 'RGACTIVATION'
        "PlatformHandler"              | ConsumerConstants.ProductNotificationConstants.EVENT_TYPE_PLATFORM_HANDLER | 'DELETE'
        "Unsupported event"            | 'UNSUPPORTED'                                                              | 'NULL'
    }
}
