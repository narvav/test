package com.att.idp.idgraphconsumerms.cosmos.nosql.config

import spock.lang.Specification

class CosmosPropertiesTest extends Specification {

    def "CosmosProperties setters and getters reflect assigned values"() {
        given:
        CosmosProperties cosmosProperties = new CosmosProperties()

        when:
        cosmosProperties.setUri("https://test-uri")
        cosmosProperties.setKey("test-key")
        cosmosProperties.setName("test-db")
        cosmosProperties.setQueryMetricsEnabled(true)
        cosmosProperties.setResponseDiagnosticsEnabled(false)

        then:
        cosmosProperties.getUri() == "https://test-uri"
        cosmosProperties.getKey() == "test-key"
        cosmosProperties.getName() == "test-db"
        cosmosProperties.isQueryMetricsEnabled()
        !cosmosProperties.isResponseDiagnosticsEnabled()
        0 * _
    }

    def "CosmosProperties all-args constructor populates all fields"() {
        when:
        CosmosProperties cosmosProperties = new CosmosProperties(
                "https://test-uri",
                "test-key",
                "test-db",
                true,
                false
        )

        then:
        cosmosProperties.uri == "https://test-uri"
        cosmosProperties.key == "test-key"
        cosmosProperties.name == "test-db"
        cosmosProperties.queryMetricsEnabled
        !cosmosProperties.responseDiagnosticsEnabled
        0 * _
    }

    def "CosmosProperties no-args constructor creates instance with null defaults"() {
        when:
        CosmosProperties cosmosProperties = new CosmosProperties()

        then:
        cosmosProperties != null
        cosmosProperties.getUri() == null
        cosmosProperties.getKey() == null
        cosmosProperties.getName() == null
        !cosmosProperties.isQueryMetricsEnabled()
        !cosmosProperties.isResponseDiagnosticsEnabled()
        0 * _
    }
}