package com.att.idp.idgraphconsumerms.kafka.dmctn.service

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker
import com.att.idp.idgraphconsumerms.kafka.model.AccountNotificationEvent
import com.att.idp.idgraphconsumerms.model.PlatformHandlerRequest
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class DeletePlatformHandlerNotificationServiceTest extends Specification {

    ApiRestClient apiRestClient
    CosmosFailedEventsWriter cosmosFailedEventsWriter
    DeletePlatformHandlerNotificationService serviceUnderTest

    void setup() {
        apiRestClient = Mock(ApiRestClient)
        cosmosFailedEventsWriter = Mock(CosmosFailedEventsWriter)
        serviceUnderTest = new DeletePlatformHandlerNotificationService(apiRestClient, cosmosFailedEventsWriter)
        ReflectionTestUtils.setField(serviceUnderTest, "platformHandlerEndpoint", "/mock/platformhandler")
        def circuitBreaker = Stub(GddnFailedEventCircuitBreaker) { shouldShortCircuit(_, _) >> false }
        ReflectionTestUtils.setField(serviceUnderTest, "gddnFailedEventCircuitBreaker", circuitBreaker)
    }

    def "should call platform handler delete with BAN"() {
        given:
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(ConsumerConstants.ProductNotificationConstants.EVENT_TYPE_PLATFORM_HANDLER)
        event.setBillingAccountNumber("BAN123")
        event.setEventId("trace-123")

        when:
        serviceUnderTest.execute(event)

        then:
        1 * apiRestClient.sendPostRequest("/mock/platformhandler", { PlatformHandlerRequest req ->
            req.ban == 'BAN123' &&
                    req.phFan == null &&
                    req.transactionType == ConsumerConstants.ProductNotificationConstants.DELETE_PH_ACCOUNT
        }, ConsumerConstants.GridGddnNotification.EVENT_GDDN_PLATFORM_HANDLER)
        0 * cosmosFailedEventsWriter._
        0 * _
    }

    def "should call platform handler delete with PH FAN when BAN absent"() {
        given:
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(ConsumerConstants.ProductNotificationConstants.EVENT_TYPE_PLATFORM_HANDLER)
        event.setPhFan("PH123")
        event.setEventId("trace-123")

        when:
        serviceUnderTest.execute(event)

        then:
        1 * apiRestClient.sendPostRequest("/mock/platformhandler", { PlatformHandlerRequest req ->
            req.ban == null &&
                    req.phFan == 'PH123' &&
                    req.transactionType == ConsumerConstants.ProductNotificationConstants.DELETE_PH_ACCOUNT
        }, ConsumerConstants.GridGddnNotification.EVENT_GDDN_PLATFORM_HANDLER)
        0 * cosmosFailedEventsWriter._
        0 * _
    }

    def "should save failed event with VALIDATION_FAILED status when BAN and PH FAN are missing"() {
        given:
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(ConsumerConstants.ProductNotificationConstants.EVENT_TYPE_PLATFORM_HANDLER)
        event.setEventId("trace-123")

        when:
        serviceUnderTest.execute(event)

        then:
        0 * apiRestClient._
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ it.status == "VALIDATION_FAILED" &&
                it.eventCategory == ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT })
        0 * _
    }

    def "should short-circuit to Cosmos when circuit breaker is OPEN"() {
        given: "Circuit breaker returns true (pending failed events exist)"
        def openCircuitBreaker = Stub(GddnFailedEventCircuitBreaker) {
            shouldShortCircuit("BAN-CB", ConsumerConstants.GridGddnNotification.EVENT_GDDN_PLATFORM_HANDLER) >> true
        }
        ReflectionTestUtils.setField(serviceUnderTest, "gddnFailedEventCircuitBreaker", openCircuitBreaker)

        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setBillingAccountNumber("BAN-CB")
        event.setEventName(ConsumerConstants.ProductNotificationConstants.EVENT_TYPE_PLATFORM_HANDLER)
        event.setEventId("trace-cb")

        when:
        serviceUnderTest.execute(event)

        then: "API client is never called"
        0 * apiRestClient._

        and: "Failed event is saved to Cosmos with circuit breaker message"
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ it.accountId == "BAN-CB" &&
                it.eventName == ConsumerConstants.GridGddnNotification.EVENT_GDDN_PLATFORM_HANDLER })
        0 * _
    }

    def "should save failed event when API client throws with valid BAN"() {
        given:
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setBillingAccountNumber("BAN-ERR")
        event.setEventName(ConsumerConstants.ProductNotificationConstants.EVENT_TYPE_PLATFORM_HANDLER)
        event.setEventId("trace-err")

        when:
        serviceUnderTest.execute(event)

        then:
        1 * apiRestClient.sendPostRequest("/mock/platformhandler", _, ConsumerConstants.GridGddnNotification.EVENT_GDDN_PLATFORM_HANDLER) >> { throw new RuntimeException("connection refused") }
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ it.accountId == "BAN-ERR" &&
                it.eventName == ConsumerConstants.GridGddnNotification.EVENT_GDDN_PLATFORM_HANDLER })
        0 * _
    }
}
