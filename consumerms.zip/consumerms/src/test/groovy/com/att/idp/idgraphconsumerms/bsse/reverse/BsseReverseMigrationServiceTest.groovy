package com.att.idp.idgraphconsumerms.bsse.reverse

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails
import com.att.idp.idgraphconsumerms.kafka.model.ReverseMigratedInboundDataEvent
import com.att.idp.idgraphconsumerms.kafka.model.ReverseMigratedInboundDataEvent.EventDetails
import com.att.idp.idgraphconsumerms.kafka.model.ReverseMigratedInboundDataEvent.IDMAttributes
import com.att.idp.idgraphconsumerms.kafka.model.ReverseMigratedInboundDataEvent.AccessID
import com.att.idp.idgraphconsumerms.kafka.model.ReverseMigratedInboundDataEvent.CtnDetail
import com.att.idp.idgraphconsumerms.kafka.model.ReverseMigratedOutboundRequest
import com.att.idp.idgraphconsumerms.rest.client.GenericApiRestClient
import com.att.idp.idgraphconsumerms.rest.model.APIDetails
import com.att.idp.idgraphconsumerms.rest.model.APIRequestWrapper
import org.springframework.http.HttpMethod
import spock.lang.Specification
import spock.lang.Unroll

class BsseReverseMigrationServiceTest extends Specification {

    GenericApiRestClient genericApiRestClient
    BsseReverseMigrationService bsseReverseMigrationService

    void setup() {
        genericApiRestClient = Mock(GenericApiRestClient)
        bsseReverseMigrationService = new BsseReverseMigrationService(genericApiRestClient)
        bsseReverseMigrationService.userAssoServerUrl = "http://ua-server"
        bsseReverseMigrationService.userName = "testUser"
        bsseReverseMigrationService.userPassword = "testPass"
        bsseReverseMigrationService.reverseMigrationEndpoint = "/reverse-migrate"
    }

    @Unroll
    def "should call backend API and send correct request for #scenarioName"() {
        given: "A ReverseMigratedInboundDataEvent and expected APIRequestWrapper"
        ReverseMigratedInboundDataEvent inboundEvent = new ReverseMigratedInboundDataEvent()
        inboundEvent.setSourceBSSEBan(sourceBSSEBan)
        inboundEvent.setTargetTLGBan(targetTLGBan)
        inboundEvent.setMigrationId(migrationId)
        inboundEvent.setIterationId(iterationId)
        IDMAttributes idmAttributes = IDMAttributes.builder()
                .accessIDs(accessIDs)
                .ctnList(ctnList)
                .build()
        EventDetails eventDetails = EventDetails.builder()
                .idmAttributes(idmAttributes)
                .build()
        inboundEvent.setEvent(eventDetails)

        1 * genericApiRestClient.sendPostRequest({ APIRequestWrapper wrapper ->
            APIDetails details = wrapper.getApiDetails()
            FailedEventDetails failedEvent = wrapper.getFailedEventDetails()
            String outgoingJson = wrapper.getOutgoingAPIRequestJson()
            details.serverURI == "http://ua-server" &&
                    details.apiEndpoint == "/reverse-migrate" &&
                    details.username == "testUser" &&
                    details.password == "testPass" &&
                    details.xATTClientId == ConsumerConstants.BsseMigration.CLIENT_BSSEMIPAAS &&
                    details.httpMethod == HttpMethod.POST &&
                    failedEvent.accountId == targetTLGBan &&
                    failedEvent.eventName == ConsumerConstants.BsseReverseMigration.BSSE_REVERSE_MIGRATION_EVENT_TYPE &&
                    outgoingJson.contains(migrationId) &&
                    outgoingJson.contains(sourceBSSEBan) &&
                    outgoingJson.contains(targetTLGBan) &&
                    outgoingJson.contains(iterationId)
        })
        0 * _

        when: "callBackendAPI is invoked"
        bsseReverseMigrationService.callBackendAPI(inboundEvent)

        then: "No exception is thrown"
        noExceptionThrown()

        where:
        scenarioName         | sourceBSSEBan | targetTLGBan | migrationId | iterationId | accessIDs                                                                 | ctnList
        "standard migration" | "BAN123"      | "TLG456"     | "MID789"    | "ITR001"    | [AccessID.builder().guid("g1").roleId("r1").individualId("i1").build()]  | [CtnDetail.builder().ctn("c1").cgSubId("cg1").tlgSubId("tlg1").build()]
        "empty iteration"    | "BAN999"      | "TLG888"     | "MID777"    | ""          | []                                                                       | []
        "null accessIDs"     | "BAN111"      | "TLG222"     | "MID333"    | "ITR002"    | null                                                                     | []
    }

    @Unroll
    def "should build outbound request with correct mapping for #scenarioName"() {
        given: "A ReverseMigratedInboundDataEvent with various accessIDs and ctnList"
        ReverseMigratedInboundDataEvent inboundEvent = new ReverseMigratedInboundDataEvent()
        inboundEvent.setSourceBSSEBan(sourceBSSEBan)
        inboundEvent.setTargetTLGBan(targetTLGBan)
        inboundEvent.setMigrationId(migrationId)
        inboundEvent.setIterationId(iterationId)
        IDMAttributes idmAttributes = IDMAttributes.builder()
                .accountType(accountType)
                .accountSubType(accountSubType)
                .accessIDs(accessIDs)
                .ctnList(ctnList)
                .build()
        EventDetails eventDetails = EventDetails.builder()
                .idmAttributes(idmAttributes)
                .build()
        inboundEvent.setEvent(eventDetails)

        when: "buildReverseMigratedOutboundRequest is called via reflection"
        ReverseMigratedOutboundRequest result
        result = bsseReverseMigrationService.class.getDeclaredMethod("buildReverseMigratedOutboundRequest", ReverseMigratedInboundDataEvent)
                .with { setAccessible(true); invoke(bsseReverseMigrationService, inboundEvent) }

        then: "All fields are mapped correctly"
        result != null
        result.migrationId == migrationId
        result.productType == ConsumerConstants.BsseMigration.MOBILITY
        result.sourceBSSEBan == sourceBSSEBan
        result.targetTLGBan == targetTLGBan
        result.iterationId == iterationId
        result.accountType == accountType
        result.accountSubType == accountSubType
        result.accessIDs.size() == (accessIDs == null ? 0 : accessIDs.size())
        result.ctnList.size() == ctnList.size()
        if (accessIDs != null && !accessIDs.isEmpty()) {
            result.accessIDs[0].guid == accessIDs[0].guid
            result.accessIDs[0].roleName == accessIDs[0].roleId
            result.accessIDs[0].individualId == accessIDs[0].individualId
        }
        if (!ctnList.isEmpty()) {
            result.ctnList[0].ctn == ctnList[0].ctn
            result.ctnList[0].cgSubId == ctnList[0].cgSubId
            result.ctnList[0].tlgSubId == ctnList[0].tlgSubId
        }

        where:
        scenarioName         | sourceBSSEBan | targetTLGBan | migrationId | iterationId | accountType | accountSubType | accessIDs                                                                 | ctnList
        "all fields"         | "BAN1"        | "TLG1"       | "MID1"      | "ITR1"      | "I"         | "R"            | [AccessID.builder().guid("g1").roleId("r1").individualId("i1").build()]  | [CtnDetail.builder().ctn("c1").cgSubId("cg1").tlgSubId("tlg1").build()]
        "no accessIDs"       | "BAN2"        | "TLG2"       | "MID2"      | "ITR2"      | "I"         | "R"            | []                                                                       | [CtnDetail.builder().ctn("c2").cgSubId("cg2").tlgSubId("tlg2").build()]
        "no ctnList"         | "BAN3"        | "TLG3"       | "MID3"      | "ITR3"      | "B"         | "S"            | [AccessID.builder().guid("g3").roleId("r3").individualId("i3").build()]  | []
        "null accessIDs"     | "BAN4"        | "TLG4"       | "MID4"      | "ITR4"      | null        | null           | null                                                                     | []
    }

    def "should include eventId from inbound event in outbound reverse migration request"() {
        given: "an inbound event with eventId"
        ReverseMigratedInboundDataEvent inboundEvent = new ReverseMigratedInboundDataEvent()
        inboundEvent.setSourceBSSEBan("BAN-BSSE")
        inboundEvent.setTargetTLGBan("BAN-TLG")
        inboundEvent.setMigrationId("MIG-001")
        inboundEvent.setIterationId("ITR-001")
        inboundEvent.setEventId("rev-evt-uuid-001")
        IDMAttributes idmAttributes = IDMAttributes.builder()
                .accountType("I")
                .accountSubType("R")
                .accessIDs([])
                .ctnList([])
                .build()
        EventDetails eventDetails = EventDetails.builder()
                .idmAttributes(idmAttributes)
                .build()
        inboundEvent.setEvent(eventDetails)

        when: "buildReverseMigratedOutboundRequest is called via reflection"
        ReverseMigratedOutboundRequest result
        result = bsseReverseMigrationService.class.getDeclaredMethod("buildReverseMigratedOutboundRequest", ReverseMigratedInboundDataEvent)
                .with { setAccessible(true); invoke(bsseReverseMigrationService, inboundEvent) }

        then: "eventId and account fields are mapped to the outbound request"
        result != null
        result.eventId == "rev-evt-uuid-001"
        result.accountType == "I"
        result.accountSubType == "R"
    }

    def "should throw exception if apiRestClient throws"() {
        given: "A valid inbound event and apiRestClient throws"
        ReverseMigratedInboundDataEvent inboundEvent = new ReverseMigratedInboundDataEvent()
        inboundEvent.setSourceBSSEBan("BANX")
        inboundEvent.setTargetTLGBan("TLGX")
        inboundEvent.setMigrationId("MIDX")
        inboundEvent.setIterationId("ITRX")
        IDMAttributes idmAttributes = IDMAttributes.builder()
                .accessIDs([])
                .ctnList([])
                .build()
        EventDetails eventDetails = EventDetails.builder()
                .idmAttributes(idmAttributes)
                .build()
        inboundEvent.setEvent(eventDetails)
        RuntimeException expectedException = new RuntimeException("API error")

        1 * genericApiRestClient.sendPostRequest({ APIRequestWrapper wrapper ->
            wrapper.getApiDetails().serverURI == "http://ua-server"
        }) >> { throw expectedException }
        0 * _

        when: "callBackendAPI is invoked"
        bsseReverseMigrationService.callBackendAPI(inboundEvent)

        then: "Exception is propagated"
        RuntimeException ex = thrown()
        ex.message == "API error"
    }
}
