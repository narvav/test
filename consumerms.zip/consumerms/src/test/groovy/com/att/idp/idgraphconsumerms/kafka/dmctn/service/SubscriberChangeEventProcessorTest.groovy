package com.att.idp.idgraphconsumerms.kafka.dmctn.service

import com.att.idp.idgraphconsumerms.kafka.model.Subscriber
import org.springframework.messaging.MessageHeaders
import spock.lang.Specification

class SubscriberChangeEventProcessorTest extends Specification {

    BackendServiceFactory backendServiceFactory = Mock()
    BackendService backendService = Mock()
    SubscriberChangeEventProcessor processor = new SubscriberChangeEventProcessor()

    def setup() {
        processor.backendServiceFactory = backendServiceFactory
    }

    private static Subscriber sub(String id, String phone) {
        Subscriber.builder().id(id).phoneNumber(phone).build()
    }

    def "processEvent - single string ChangeType header"() {
        given:
        def subscriber = sub("s1","11111")
        def headers = new MessageHeaders(["ChangeType": "TYPE_A"])

        when:
        processor.processEvent(subscriber, headers)

        then:
        1 * backendServiceFactory.getService(["TYPE_A"], subscriber) >> backendService
        1 * backendService.execute(subscriber, EventSource.CG)
        0 * _
    }

    def "processEvent - multiple string ChangeType values"() {
        given:
        def subscriber = sub("s2","22222")
        def headers = new MessageHeaders(["ChangeType": "TYPE_A,TYPE_B,TYPE_C"])

        when:
        processor.processEvent(subscriber, headers)

        then:
        3 * backendServiceFactory.getService(["TYPE_A","TYPE_B","TYPE_C"], subscriber) >> backendService
        3 * backendService.execute(subscriber, EventSource.CG)
        0 * _
    }

    def "processEvent - single byte[] ChangeType header"() {
        given:
        def subscriber = sub("s3","33333")
        def headers = new MessageHeaders(["ChangeType": "TYPE_X".getBytes("UTF-8")])

        when:
        processor.processEvent(subscriber, headers)

        then:
        1 * backendServiceFactory.getService(["TYPE_X"], subscriber) >> backendService
        1 * backendService.execute(subscriber, EventSource.CG)
        0 * _
    }

    def "processEvent - multiple byte[] ChangeType values with mixed null service returns"() {
        given:
        def subscriber = sub("s4","44444")
        def headers = new MessageHeaders(["ChangeType": "ONE,TWO,THREE".getBytes("UTF-8")])

        when:
        processor.processEvent(subscriber, headers)

        then:
        3 * backendServiceFactory.getService(["ONE","TWO","THREE"], subscriber) >>> [backendService, null, backendService]
        2 * backendService.execute(subscriber, EventSource.CG) // only for non-null services
        0 * _
    }

    def "processEvent - empty string ChangeType header (produces single empty token)"() {
        given:
        def subscriber = sub("s5","55555")
        def headers = new MessageHeaders(["ChangeType": ""])

        when:
        processor.processEvent(subscriber, headers)

        then:
        1 * backendServiceFactory.getService([""], subscriber) >> backendService
        1 * backendService.execute(subscriber, EventSource.CG)
        0 * _
    }

    def "processEvent - missing ChangeType header (no calls)"() {
        given:
        def subscriber = sub("s6","66666")
        def headers = new MessageHeaders([:])

        when:
        processor.processEvent(subscriber, headers)

        then:
        0 * backendServiceFactory._
        0 * _
    }
}
