package com.att.idp.idgraphconsumerms.request.validator

import com.att.idp.idgraphconsumerms.kafka.model.MigrationBANNotification
import com.att.mpsys.common.utils.CErrorDefs
import spock.lang.Specification

class MigrationBANNotificationRequestValidatorTest extends Specification {

    MigrationBANNotificationRequestValidator validator

    def setup() {
        validator = new MigrationBANNotificationRequestValidator()
    }

    def "test validateMessage with null payload"() {
        given:
        MigrationBANNotification payload = null

        when:
        Map<String, Object> result = validator.validateMessage(payload)

        then:
        result != null
        result.containsValue(CErrorDefs.ERR_SYS_APPL)
    }

    def "test validateMessage with missing migrationId"() {
        given:
        MigrationBANNotification payload = new MigrationBANNotification(
                migrationId: null, targetIndividualId: "123", sourceBanId: "456", sourceMarketCode: "US", guid: "GUID123", targetBanId: "789", passcodeVenc: "PASS123"
        )

        when:
        Map<String, Object> result = validator.validateMessage(payload)

        then:
        result != null
        result.containsValue(CErrorDefs.ERR_INVALID_DATA)
        result.get("appInfo") == "Migration Id is required"
    }

    def "test validateMessage with missing sourceBanId"() {
        given:
        MigrationBANNotification payload = new MigrationBANNotification(
                migrationId: "123", targetIndividualId: "456", sourceBanId: null, sourceMarketCode: "US", guid: "GUID123", targetBanId: "789", passcodeVenc: "PASS123"
        )

        when:
        Map<String, Object> result = validator.validateMessage(payload)

        then:
        result != null
        result.containsValue(CErrorDefs.ERR_INVALID_DATA)
        result.get("appInfo") == "Source BAN Id is required"
    }

    def "test validateMessage with missing sourceMarketCode"() {
        given:
        MigrationBANNotification payload = new MigrationBANNotification(
                migrationId: "123", targetIndividualId: "456", sourceBanId: "789", sourceMarketCode: null, guid: "GUID123", targetBanId: "789", passcodeVenc: "PASS123"
        )

        when:
        Map<String, Object> result = validator.validateMessage(payload)

        then:
        result != null
        result.containsValue(CErrorDefs.ERR_INVALID_DATA)
        result.get("appInfo") == "Source market code is required"
    }

    def "test validateMessage with missing targetBanId"() {
        given:
        MigrationBANNotification payload = new MigrationBANNotification(
                migrationId: "123", targetIndividualId: "456", sourceBanId: "789", sourceMarketCode: "US", guid: "GUID123", targetBanId: null, passcodeVenc: "PASS123"
        )

        when:
        Map<String, Object> result = validator.validateMessage(payload)

        then:
        result != null
        result.containsValue(CErrorDefs.ERR_INVALID_DATA)
        result.get("appInfo") == "Target BAN is required"
    }

    def "test validateMessage with valid payload"() {
        given:
        MigrationBANNotification payload = new MigrationBANNotification(
                migrationId: "123", targetIndividualId: "456", sourceBanId: "789", sourceMarketCode: "US", guid: "GUID123", targetBanId: "789", passcodeVenc: "PASS123"
        )

        when:
        Map<String, Object> result = validator.validateMessage(payload)

        then:
        result != null
        result.containsValue(CErrorDefs.COMMON_SUCCESS)
    }

    def "test validateMessage with valid payload without guid and individualId"() {
        given:
        MigrationBANNotification payload = new MigrationBANNotification(
                migrationId: "123", targetIndividualId: null, sourceBanId: "789", sourceMarketCode: "US", guid: null, targetBanId: "789", passcodeVenc: "PASS123"
        )

        when:
        Map<String, Object> result = validator.validateMessage(payload)

        then:
        result != null
        result.containsValue(CErrorDefs.COMMON_SUCCESS)
    }
}