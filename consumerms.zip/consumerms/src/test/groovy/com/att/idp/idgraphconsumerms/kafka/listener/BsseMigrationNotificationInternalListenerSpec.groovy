package com.att.idp.idgraphconsumerms.kafka.listener

import com.att.idp.idgraphconsumerms.kafka.model.MigrationBANNotification
import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.kafka.support.Acknowledgment
import org.springframework.messaging.MessageHeaders
import spock.lang.Specification
import spock.lang.Unroll

class BsseMigrationNotificationInternalListenerSpec extends Specification {

    BsseMigrationNotificationProcessor notificationProcessor
    BsseMigrationNotificationInternalListener listener
    ObjectMapper objectMapper

    void setup() {
        notificationProcessor = Mock(BsseMigrationNotificationProcessor)
        listener = new BsseMigrationNotificationInternalListener(notificationProcessor)
        objectMapper = new ObjectMapper()
    }

    @Unroll
    def "should process migration notification and acknowledge for #scenarioName"() {
        given: "A valid message, headers, and acknowledgment"
        MigrationBANNotification payload = new MigrationBANNotification()
        payload.setEventType(eventType)
        payload.setEventId(eventId)
        payload.setMigrationId(migrationId)
        payload.setServiceType(serviceType)
        payload.setSourceBanId(sourceBanId)
        String msg = objectMapper.writeValueAsString(payload)
        MessageHeaders headers = Mock(MessageHeaders)
        Acknowledgment ack = Mock(Acknowledgment)

        when: "consumeMigrationBANNotification is called"
        listener.consumeMigrationBANNotification(msg, headers, ack)

        then: "Notification processor is called and ack is acknowledged"
        1 * notificationProcessor.processNotification({ MigrationBANNotification p ->
            p.eventType == eventType &&
            p.eventId == eventId &&
            p.migrationId == migrationId &&
            p.serviceType == serviceType &&
            p.sourceBanId == sourceBanId
        }, msg, { String traceId -> traceId != null && !traceId.isEmpty() }, "BsseMigrationNotificationInternalListener")
        1 * ack.acknowledge()
        0 * _

        where:
        scenarioName      | eventType        | eventId        | migrationId      | serviceType | sourceBanId
        "standard event"  | "MigrationEvent" | "evt-123"      | "mig-456"       | "WIRELESS"  | "4708151887"
        "empty eventId"   | "MigrationEvent" | ""             | "mig-789"       | "WIRELESS"  | "4708151887"
    }

    @Unroll
    def "should skip processing and acknowledge when serviceType is ReverseWireless for #scenarioName"() {
        given: "A message with ReverseWireless serviceType"
        MigrationBANNotification payload = new MigrationBANNotification()
        payload.setEventType("MigrationEvent")
        payload.setEventId(eventId)
        payload.setMigrationId(migrationId)
        payload.setServiceType("ReverseWireless")
        payload.setSourceBanId("4708151887")
        String msg = objectMapper.writeValueAsString(payload)
        MessageHeaders headers = Mock(MessageHeaders)
        Acknowledgment ack = Mock(Acknowledgment)

        when: "consumeMigrationBANNotification is called"
        listener.consumeMigrationBANNotification(msg, headers, ack)

        then: "No notification processing occurs but ack is acknowledged"
        1 * ack.acknowledge()
        0 * _

        where: "Different ReverseWireless event scenarios"
        scenarioName                | eventId        | migrationId
        "standard reverse wireless"| "evt-rev-001" | "mig-rev-001"
        "reverse wireless empty id"| ""            | "mig-rev-002"
        "reverse wireless null ids"| null           | null
    }

    def "should handle JsonProcessingException for invalid JSON message"() {
        given: "An invalid JSON message, headers, and acknowledgment"
        String msg = "{invalidJson:}"
        MessageHeaders headers = Mock(MessageHeaders)
        Acknowledgment ack = Mock(Acknowledgment)

        when: "consumeMigrationBANNotification is called"
        listener.consumeMigrationBANNotification(msg, headers, ack)

        then: "No notification processing occurs and ack is acknowledged"
        1 * ack.acknowledge()
        0 * _
    }

    def "should log and acknowledge when unexpected exception occurs"() {
        given: "A valid JSON message, headers, and acknowledgment"
        String msg = '{"eventType":"MigrationEvent","eventId":"evt-123","migrationId":"mig-456","serviceType":"WIRELESS","sourceBanId":"4708151887"}'
        MessageHeaders headers = Mock(MessageHeaders)
        Acknowledgment ack = Mock(Acknowledgment)
        MigrationBANNotification payload = objectMapper.readValue(msg, MigrationBANNotification.class)
        RuntimeException unexpectedException = new RuntimeException("Unexpected error")
        notificationProcessor.processNotification(payload, msg, { String traceId -> traceId != null && !traceId.isEmpty() }, "BsseMigrationNotificationInternalListener") >> { throw unexpectedException }

        when: "consumeMigrationBANNotification is called"
        listener.consumeMigrationBANNotification(msg, headers, ack)

        then: "Exception is logged and ack is acknowledged"
        1 * notificationProcessor.processNotification(payload, msg, { String traceId -> traceId != null && !traceId.isEmpty() }, "BsseMigrationNotificationInternalListener")
        1 * ack.acknowledge()
        0 * _
    }
}
