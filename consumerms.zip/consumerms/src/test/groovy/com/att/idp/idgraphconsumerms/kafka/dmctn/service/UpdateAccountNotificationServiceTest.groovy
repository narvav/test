package com.att.idp.idgraphconsumerms.kafka.dmctn.service

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker
import com.att.idp.idgraphconsumerms.kafka.model.AccountNotificationEvent
import com.att.idp.idgraphconsumerms.model.PlatformHandlerRequest
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class UpdateAccountNotificationServiceTest extends Specification {

    ApiRestClient apiRestClient
    CosmosFailedEventsWriter cosmosFailedEventsWriter
    UpdateAccountNotificationService serviceUnderTest

    void setup() {
        apiRestClient = Mock(ApiRestClient)
        cosmosFailedEventsWriter = Mock(CosmosFailedEventsWriter)
        serviceUnderTest = new UpdateAccountNotificationService(apiRestClient)
        ReflectionTestUtils.setField(serviceUnderTest, "cosmosFailedEventsWriter", cosmosFailedEventsWriter)
        ReflectionTestUtils.setField(serviceUnderTest, "platformHandlerEndpoint", "/mock/platformhandler")
        def circuitBreaker = Stub(GddnFailedEventCircuitBreaker) { shouldShortCircuit(_, _) >> false }
        ReflectionTestUtils.setField(serviceUnderTest, "gddnFailedEventCircuitBreaker", circuitBreaker)
    }

    def "should call platform handler when mobilityBan oldFan and newFan are present"() {
        given:
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(ConsumerConstants.AccountNotificationConstants.UPDATE_ACCOUNT)
        event.setBillingAccountNumber("BAN123")
        event.setOldFan("OLDFAN123")
        event.setNewFan("NEWFAN123")
        event.setEventId("trace-123")

        when:
        serviceUnderTest.execute(event)

        then:
        1 * apiRestClient.sendPostRequest("/mock/platformhandler", { PlatformHandlerRequest req ->
            req.ban == "BAN123" &&
                    req.oldFan == "OLDFAN123" &&
                    req.newFan == "NEWFAN123" &&
                    req.transactionType == ConsumerConstants.AccountNotificationConstants.UPDATE_FAN &&
                    req.callingSystemId == ConsumerConstants.DmctnSubscriberChangeEvent.CLIENT_ATLASBUS &&
                    req.idpTraceId == "trace-123"
        }, ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT)
        0 * cosmosFailedEventsWriter._
        0 * _
    }

    def "should save failed event with VALIDATION_FAILED status when oldFan is missing"() {
        given:
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(ConsumerConstants.AccountNotificationConstants.UPDATE_ACCOUNT)
        event.setBillingAccountNumber("BAN123")
        event.setNewFan("NEWFAN123")
        event.setEventId("trace-123")

        when:
        serviceUnderTest.execute(event)

        then:
        0 * apiRestClient._
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ it.status == "VALIDATION_FAILED" &&
                it.eventCategory == ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_FAN_UPDATE })
        0 * _
    }

    def "should save failed event when client throws"() {
        given:
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(ConsumerConstants.AccountNotificationConstants.UPDATE_ACCOUNT)
        event.setBillingAccountNumber("BAN123")
        event.setOldFan("OLDFAN123")
        event.setNewFan("NEWFAN123")

        when:
        serviceUnderTest.execute(event)

        then:
        1 * apiRestClient.sendPostRequest("/mock/platformhandler", _ as PlatformHandlerRequest, ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT) >> { throw new RuntimeException("downstream error") }
        1 * cosmosFailedEventsWriter._
        0 * _
    }

    def "should short-circuit to Cosmos when circuit breaker is OPEN"() {
        given: "Circuit breaker returns true (pending failed events exist)"
        def openCircuitBreaker = Stub(GddnFailedEventCircuitBreaker) {
            shouldShortCircuit("BAN-CB", ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT) >> true
        }
        ReflectionTestUtils.setField(serviceUnderTest, "gddnFailedEventCircuitBreaker", openCircuitBreaker)

        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setBillingAccountNumber("BAN-CB")
        event.setEventName(ConsumerConstants.AccountNotificationConstants.UPDATE_ACCOUNT)
        event.setOldFan("OLDFAN")
        event.setNewFan("NEWFAN")

        when:
        serviceUnderTest.execute(event)

        then: "API client is never called"
        0 * apiRestClient._

        and: "Failed event is saved to Cosmos with circuit breaker message"
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ it.accountId == "BAN-CB" &&
                it.eventName == ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT })
        0 * _
    }
}
