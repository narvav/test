package com.att.idp.idgraphconsumerms.bsse.reverse

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosMigrationStatusDBHelper
import com.att.idp.idgraphconsumerms.kafka.model.ReverseMigratedInboundDataEvent
import com.att.idp.idgraphconsumerms.kafka.model.ReverseMigratedInboundDataEvent.EventDetails
import com.att.idp.idgraphconsumerms.kafka.model.ReverseMigratedInboundDataEvent.IDMAttributes
import com.att.idp.idgraphconsumerms.request.validator.RequestValidator
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.springframework.kafka.support.Acknowledgment
import org.springframework.messaging.MessageHeaders
import com.fasterxml.jackson.databind.ObjectMapper
import spock.lang.Specification
import spock.lang.Unroll

class BsseReverseMigrationEventProcessorTest extends Specification {

    RequestValidator requestValidator
    BsseReverseMigrationService bsseReverseMigrationService
    CosmosMigrationStatusDBHelper cosmosMigrationStatusDBHelper
    BsseReverseMigrationEventProcessor processor

    void setup() {
        requestValidator = Mock(RequestValidator)
        bsseReverseMigrationService = Mock(BsseReverseMigrationService)
        cosmosMigrationStatusDBHelper = Mock(CosmosMigrationStatusDBHelper)
        processor = new BsseReverseMigrationEventProcessor(requestValidator, bsseReverseMigrationService, cosmosMigrationStatusDBHelper)
    }

    private static Map<String, Object> validResult() {
        return [(MPSDefs.APP_STATUS_CODE): CommonDefs.COMMON_SUCCESS,
                (MPSDefs.APP_STATUS_MSG) : "OK"]
    }

    private static Map<String, Object> invalidResult(String msg) {
        return [(MPSDefs.APP_STATUS_CODE): "FAIL",
                (MPSDefs.APP_STATUS_MSG) : msg,
                (MPSDefs.APP_INFO)       : msg]
    }

    @Unroll
    def "should process valid BsseReverseMigration event and call service for #scenarioName"() {
        given: "A valid BsseReverseMigration event JSON and headers"
        String sourceBSSEBan = "123456789"
        String targetTLGBan = "987654321"
        String migrationId = "MIG123"
        List<ReverseMigratedInboundDataEvent.AccessID> accessIDs = [
                ReverseMigratedInboundDataEvent.AccessID.builder().guid("A1").build(),
                ReverseMigratedInboundDataEvent.AccessID.builder().guid("A2").build()
        ]
        List<ReverseMigratedInboundDataEvent.CtnDetail> ctnList = [
                ReverseMigratedInboundDataEvent.CtnDetail.builder().ctn("CTN1").build(),
                ReverseMigratedInboundDataEvent.CtnDetail.builder().ctn("CTN2").build()
        ]

        ReverseMigratedInboundDataEvent.IDMAttributes idmAttributes = ReverseMigratedInboundDataEvent.IDMAttributes.builder()
                .accessIDs(accessIDs)
                .ctnList(ctnList)
                .accountType("I")
                .accountSubType("R")
                .build()
        ReverseMigratedInboundDataEvent.EventDetails eventDetails = ReverseMigratedInboundDataEvent.EventDetails.builder()
                .idmAttributes(idmAttributes)
                .build()
        ReverseMigratedInboundDataEvent event = ReverseMigratedInboundDataEvent.builder()
                .eventType(ConsumerConstants.BsseReverseMigration.BSSE_REVERSE_MIGRATION_EVENT_TYPE)
                .sourceBSSEBan(sourceBSSEBan)
                .targetTLGBan(targetTLGBan)
                .migrationId(migrationId)
                .event(eventDetails)
                .build()
        String json = new ObjectMapper().writeValueAsString(event)
        MessageHeaders headers = new MessageHeaders([:])
        Acknowledgment ack = Mock(Acknowledgment)

        GroovyMock(RequestValidator, global: true)
        RequestValidator.validate(_, _) >> validResult()

        when: "processEvent is called"
        processor.processEvent(json, headers, ack)

        then: "Service is called and ack is acknowledged"
        1 * cosmosMigrationStatusDBHelper.storeBSSEMigrationStatus(_, _)
        1 * bsseReverseMigrationService.callBackendAPI(_)
        1 * ack.acknowledge()
        0 * _

        and: "EventType and fields are as expected"
        event.getEventType() == ConsumerConstants.BsseReverseMigration.BSSE_REVERSE_MIGRATION_EVENT_TYPE
        event.getSourceBSSEBan() == sourceBSSEBan
        event.getTargetTLGBan() == targetTLGBan
        event.getMigrationId() == migrationId
        event.getEvent().getIdmAttributes().getAccessIDs()*.getGuid() == ["A1", "A2"]
        event.getEvent().getIdmAttributes().getCtnList()*.getCtn() == ["CTN1", "CTN2"]

        where:
        scenarioName | _
        "happy path" | _
    }


    @Unroll
    def "should acknowledge and log warning for unsupported event type for #scenarioName"() {
        given: "An event with unsupported eventType"
        IDMAttributes idmAttributes = IDMAttributes.builder().accessIDs([]).ctnList([]).build()
        EventDetails eventDetails = EventDetails.builder().idmAttributes(idmAttributes).build()
        ReverseMigratedInboundDataEvent event = ReverseMigratedInboundDataEvent.builder()
                .eventType("UNSUPPORTED_EVENT")
                .event(eventDetails)
                .build()
        String json = new ObjectMapper().writeValueAsString(event)
        MessageHeaders headers = new MessageHeaders([:])
        Acknowledgment ack = Mock(Acknowledgment)

        when: "processEvent is called"
        processor.processEvent(json, headers, ack)

        then: "Service is not called, ack is acknowledged"
        0 * cosmosMigrationStatusDBHelper._
        0 * bsseReverseMigrationService._
        1 * ack.acknowledge()
        0 * _

        and: "EventType is as expected"
        event.getEventType() == "UNSUPPORTED_EVENT"

        where:
        scenarioName        | _
        "unsupported event" | _
    }

    def "should acknowledge and not call service for invalid JSON"() {
        given: "An invalid JSON string"
        String invalidJson = "{invalid:json}"
        MessageHeaders headers = new MessageHeaders([:])
        Acknowledgment ack = Mock(Acknowledgment)

        when: "processEvent is called"
        processor.processEvent(invalidJson, headers, ack)

        then: "Service is not called, ack is acknowledged"
        0 * cosmosMigrationStatusDBHelper._
        0 * bsseReverseMigrationService._
        1 * ack.acknowledge()
        0 * _
    }

    @Unroll
    def "should propagate exception if service throws during valid event for #scenarioName"() {
        given: "A valid BsseReverseMigration event and service throws"
        String sourceBSSEBan = "123456789"
        String targetTLGBan = "987654321"
        String migrationId = "MIG123"
        List<ReverseMigratedInboundDataEvent.AccessID> accessIDs = [
                ReverseMigratedInboundDataEvent.AccessID.builder().guid("A1").build(),
                ReverseMigratedInboundDataEvent.AccessID.builder().guid("A2").build()
        ]
        List<ReverseMigratedInboundDataEvent.CtnDetail> ctnList = [
                ReverseMigratedInboundDataEvent.CtnDetail.builder().ctn("CTN1").build(),
                ReverseMigratedInboundDataEvent.CtnDetail.builder().ctn("CTN2").build()
        ]

        ReverseMigratedInboundDataEvent.IDMAttributes idmAttributes = ReverseMigratedInboundDataEvent.IDMAttributes.builder()
                .accessIDs(accessIDs)
                .ctnList(ctnList)
                .accountType("I")
                .accountSubType("R")
                .build()
        ReverseMigratedInboundDataEvent.EventDetails eventDetails = ReverseMigratedInboundDataEvent.EventDetails.builder()
                .idmAttributes(idmAttributes)
                .build()
        ReverseMigratedInboundDataEvent event = ReverseMigratedInboundDataEvent.builder()
                .eventType(ConsumerConstants.BsseReverseMigration.BSSE_REVERSE_MIGRATION_EVENT_TYPE)
                .sourceBSSEBan(sourceBSSEBan)
                .targetTLGBan(targetTLGBan)
                .migrationId(migrationId)
                .event(eventDetails)
                .build()
        String json = new ObjectMapper().writeValueAsString(event)
        MessageHeaders headers = new MessageHeaders([:])
        Acknowledgment ack = Mock(Acknowledgment)
        RuntimeException expectedException = new RuntimeException("Service error")

        GroovyMock(RequestValidator, global: true)
        RequestValidator.validate(_, _) >> validResult()

        when: "processEvent is called"
        processor.processEvent(json, headers, ack)

        then: "Service is called and throws, no other interactions"
        1 * cosmosMigrationStatusDBHelper.storeBSSEMigrationStatus(_, _)
        1 * bsseReverseMigrationService.callBackendAPI({ ReverseMigratedInboundDataEvent evt ->
            evt.eventType == ConsumerConstants.BsseReverseMigration.BSSE_REVERSE_MIGRATION_EVENT_TYPE &&
                    evt.sourceBSSEBan == sourceBSSEBan &&
                    evt.targetTLGBan == targetTLGBan &&
                    evt.migrationId == migrationId &&
                    evt.event.idmAttributes.accessIDs*.guid == ["A1", "A2"] &&
                    evt.event.idmAttributes.ctnList*.ctn == ["CTN1", "CTN2"]
        }) >> { throw expectedException }
        0 * _

        and: "Exception is propagated"
        RuntimeException ex = thrown()
        ex.message == "Service error"

        where:
        scenarioName     | _
        "service throws" | _
    }

    def "should acknowledge and not call service if eventType cannot be parsed"() {
        given: "A JSON missing eventType"
        String jsonMissingEventType = '{"foo":"bar"}'
        MessageHeaders headers = new MessageHeaders([:])
        Acknowledgment ack = Mock(Acknowledgment)

        when: "processEvent is called"
        processor.processEvent(jsonMissingEventType, headers, ack)

        then: "Service is not called, ack is acknowledged"
        0 * cosmosMigrationStatusDBHelper._
        0 * bsseReverseMigrationService._
        1 * ack.acknowledge()
        0 * _
    }

    @Unroll
    def "should acknowledge and not call service for validation error for #scenarioName"() {
        given: "A BsseReverseMigration event with validation error"
        IDMAttributes idmAttributes = IDMAttributes.builder().accessIDs([]).ctnList([]).build()
        EventDetails eventDetails = EventDetails.builder().idmAttributes(idmAttributes).build()
        ReverseMigratedInboundDataEvent event = ReverseMigratedInboundDataEvent.builder()
                .eventType(ConsumerConstants.BsseReverseMigration.BSSE_REVERSE_MIGRATION_EVENT_TYPE)
                .event(eventDetails)
                .build()
        String json = new ObjectMapper().writeValueAsString(event)
        MessageHeaders headers = new MessageHeaders([:])
        Acknowledgment ack = Mock(Acknowledgment)

        GroovyMock(RequestValidator, global: true)
        RequestValidator.validate(_, _) >> invalidResult("ERR_INVALID_DATA")

        when: "processEvent is called"
        processor.processEvent(json, headers, ack)

        then: "Service is not called, ack is acknowledged"
        1 * cosmosMigrationStatusDBHelper.storeBSSEMigrationStatus(_, _)
        0 * bsseReverseMigrationService._
        1 * ack.acknowledge()
        0 * _

        where: "Different validation error scenarios"
        scenarioName              | _
        "missing required fields" | _
    }
}
