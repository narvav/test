package com.att.idp.idgraphconsumerms.kafka.dmctn.service

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker
import com.att.idp.idgraphconsumerms.kafka.model.Subscriber
import com.att.idp.idgraphconsumerms.oracle.helpers.MemberServiceDBHelperStub
import com.att.idp.idgraphconsumerms.oracle.model.MemberServiceResult
import com.att.idp.idgraphconsumerms.request.validator.RequestValidator
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil
import com.att.idp.idgraphconsumerms.utils.JsonService
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.messaging.MessageHeaders
import com.att.idp.idgraphconsumerms.model.UserAssociationChangeRequest
import spock.lang.Specification
import spock.lang.Unroll


class ChangeAssociationDataMigrationServiceTest extends Specification {
    ApiRestClient apiRestClient = Mock()
    CosmosFailedEventsWriter cosmosFailedEventsWriter = Mock()
    GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker = Mock()
    JdbcTemplate jdbcTemplate = Mock()

    MemberServiceDBHelperStub realStub = new MemberServiceDBHelperStub(jdbcTemplate)
    MemberServiceDBHelperStub stubSpy = Spy(realStub)
    ChangeAssociationDataMigrationService service

    String testAesKey = "16cd6d4581316cd7dfed29e087b10b145ddac92a62ed47ca2b4b60ea1b1f74fe"


    //        guidByCtn.put("5551112222", "G12345")
    //        guidByCtn.put("5553334444", "G98765") "sor-id-1",

    List<Map> failedEvents = []

    def setup() {
        service = new ChangeAssociationDataMigrationService(apiRestClient, stubSpy, cosmosFailedEventsWriter, gddnFailedEventCircuitBreaker)
        setField(service, "changeDataEndpoint", "/changeSubId")
        setField(service, "aes256key", testAesKey)

        // Default success validator unless overridden
        overrideValidatorSuccess()
        overrideJson()
        overrideFailedEventCapture()
    }

    def cleanup() {
        restoreValidator()
        restoreFailedEvent()
        restoreJson()
        failedEvents.clear()
    }

    def "validation failure triggers failed event and aborts"() {
        given:
        overrideValidatorFailure("VAL_ERR", "missing ctn")
        Subscriber sub = buildSubscriber("", "abc")
        when:
        service.execute(sub, EventSource.CG)
        then:
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
            assert it.errorDetails.toString().contains("VALIDATION_FAILED")
            true
        })

        0 * apiRestClient._
        0 * stubSpy.getOldSubscriptionIdFromInstanceId(_)
    }

    def "null memberServiceResult returns silently without posting or failing"() {
        given:
        Subscriber sub = buildSubscriber("15551230001", "sub-2")
        stubSpy.getOldSubscriptionIdFromInstanceId(_) >> null
        when:
        service.execute(sub, EventSource.CG)
        then:
        failedEvents.empty
        1 * stubSpy.getOldSubscriptionIdFromInstanceId(_)
        0 * apiRestClient._
    }

    def "empty memberNum in memberServiceResult returns silently"() {
        given:
        Subscriber sub = buildSubscriber("15551230002", "sub-3")
        MemberServiceResult res = new MemberServiceResult()
        res.setMemberNum("")        // empty
        res.setInstanceId("inst-xyz")
        stubSpy.getOldSubscriptionIdFromInstanceId(_) >> res
        when:
        service.execute(sub, EventSource.CG)
        then:
        failedEvents.empty
        1 * stubSpy.getOldSubscriptionIdFromInstanceId(_)
        0 * apiRestClient._
    }

    def "successful flow posts request with populated guid and oldInstanceId"() {
        given: "A subscriber with valid phone number and subscriberId"
        String subscriberId = "sor-id-1"
        Subscriber sub = buildSubscriber("1111111111", subscriberId)
        MemberServiceResult memberServiceResult = new MemberServiceResult()
        memberServiceResult.setMemberNum("G12345")
        memberServiceResult.setSorInvariantId(subscriberId)
        memberServiceResult.setInstanceId("1111111111")
        Optional<MemberServiceResult> memberServiceResultOptional = Optional.of(memberServiceResult)
        1 * stubSpy.getOldSubscriptionIdFromInstanceId("1111111111") >> memberServiceResultOptional

        when: "Service executes"
        service.execute(sub, EventSource.CG)

        then: "API client is called with correct request"
        1 * apiRestClient.sendPostRequest("/changeSubId", { UserAssociationChangeRequest body ->
            body.guid == "G12345" &&
                    body.associationList[0].oldSorInvariantId == "" &&
                    body.associationList[0].oldInstanceId == "1111111111"
        }, ConsumerConstants.GridGddnNotification.EVENT_CG_CHANGE_DATA)

        and: "No failed events are captured"
        failedEvents.empty
    }

    def "exception during DB lookup saves failed event with eventCategory"() {
        given:
        def subscriberId = "throw-sql-exception"
        Subscriber sub = buildSubscriber("throw-sql-exception", subscriberId)

        when:
        service.execute(sub, EventSource.CG)

        then:
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(_, _) >> false
        0 * apiRestClient.sendPostRequest(_, _, _)
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ FailedEventDetails details ->
            assert details.errorDetails.toString().contains(CErrorDefs.SYS_ERR)
            assert details.errorDetails.toString().contains("Simulated SQL Exception")
            assert details.eventCategory == ConsumerConstants.GridGddnNotification.CATEGORY_CG_SUBSCRIBER
            true
        })
        1 * stubSpy.getOldSubscriptionIdFromInstanceId("throw-sql-exception")
        0 * _
    }

    def "circuit breaker open -> saves CIRCUIT_OPEN event without calling downstream"() {
        given:
        def ctn = "5559999999"
        Subscriber sub = buildSubscriber(ctn, "sub-cb")

        when:
        service.execute(sub, EventSource.CG)

        then:
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(ctn, ConsumerConstants.GridGddnNotification.EVENT_CG_CHANGE_DATA) >> true
        0 * stubSpy.getOldSubscriptionIdFromInstanceId(_)
        0 * apiRestClient.sendPostRequest(_, _, _)
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ FailedEventDetails details ->
            assert details.eventName == ConsumerConstants.GridGddnNotification.EVENT_CG_CHANGE_DATA
            assert details.eventCategory == ConsumerConstants.GridGddnNotification.CATEGORY_CG_SUBSCRIBER
            assert details.status == "CIRCUIT_OPEN"
            assert details.accountId == ctn
            true
        })
        0 * _
    }

    // Helpers ------------------------------------------------------------

    private static Subscriber buildSubscriber(String phone, String subId) {
        def s = new Subscriber()
        s.setPhoneNumber(phone)
        s.setId(subId)
        return s
    }

    private static void setField(Object target, String name, Object value) {
        def f = target.class.getDeclaredField(name)
        f.accessible = true
        f.set(target, value)
    }

    private void overrideValidatorSuccess() {
        restoreValidator()
        RequestValidator.metaClass.'static'.validate = { String v, String f ->
            [(MPSDefs.APP_STATUS_CODE): CommonDefs.COMMON_SUCCESS,
             (MPSDefs.APP_STATUS_MSG) : "OK"]
        }
    }

    private void overrideValidatorFailure(String code, String msg) {
        restoreValidator()
        RequestValidator.metaClass.'static'.validate = { String v, String f ->
            [(MPSDefs.APP_STATUS_CODE): code,
             (MPSDefs.APP_STATUS_MSG) : msg]
        }
    }

    private void restoreValidator() {
        GroovySystem.metaClassRegistry.removeMetaClass(RequestValidator)
    }

    private void overrideFailedEventCapture() {
        restoreFailedEvent()
        def capture = { proc, phone, payload, eventType, statusCode, msg, endpoint, tranType ->
            failedEvents << [
                    phone     : phone,
                    payload   : payload,
                    eventType : eventType,
                    statusCode: statusCode,
                    msg       : msg,
                    endpoint  : endpoint,
                    tranType  : tranType
            ]
        }
        FailedEventUtil.metaClass.'static'.saveFailedEvent = capture
        FailedEventUtil.metaClass.'static'.saveFailedEventResolvingCategory = capture
    }

    private void restoreFailedEvent() {
        GroovySystem.metaClassRegistry.removeMetaClass(FailedEventUtil)
    }

    private void overrideJson() {
        restoreJson()
        JsonService.metaClass.'static'.getJsonFromObject = { Object o -> '{"json":"mock"}' }
    }

    private void restoreJson() {
        GroovySystem.metaClassRegistry.removeMetaClass(JsonService)
    }
}