package com.att.idp.idgraphconsumerms.util


import java.nio.charset.StandardCharsets;

/**
 * Utility to load classpath test resource files.
 */
public final class TestFileUtil {

	private TestFileUtil() {
	}

	public static String readClasspathFile(String path) {
		ClassLoader cl = Thread.currentThread().getContextClassLoader();
		try (InputStream is = cl.getResourceAsStream(path)) {
			if (is == null) {
				throw new IllegalArgumentException("Resource not found: " + path);
			}
			try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
				StringBuilder sb = new StringBuilder();
				String line;
				while ((line = br.readLine()) != null) {
					sb.append(line).append('\n');
				}
				return sb.toString();
			}
		} catch (IOException e) {
			throw new IllegalStateException("Failed to read resource: " + path, e);
		}
	}
}
