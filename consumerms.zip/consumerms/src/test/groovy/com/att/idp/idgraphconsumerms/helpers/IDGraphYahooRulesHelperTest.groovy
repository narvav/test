package com.att.idp.idgraphconsumerms.helpers

import com.att.idp.component.CompTestBase
import com.fasterxml.jackson.core.type.TypeReference
import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import spock.lang.Unroll

class IDGraphYahooRulesHelperTest extends Specification {

	static Map<String, Object> readJsonFileToMap(String filePath) throws IOException {
		ObjectMapper objectMapper = new ObjectMapper()
		try (InputStream inputStream = CompTestBase.class.getClassLoader().getResourceAsStream(filePath)) {
			if (inputStream == null) {
				throw new IOException("File not found: " + filePath)
			}
			return objectMapper.readValue(inputStream, new TypeReference<Map<String, Object>>() {})
		}
	}

	static String readJsonFileAsString(String filePath) throws IOException {
		try (InputStream inputStream = CompTestBase.class.getClassLoader().getResourceAsStream(filePath)) {
			if (inputStream == null) {
				throw new IOException("File not found: " + filePath)
			}
			return new String(inputStream.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8)
		}
	}

	IDGraphYahooRulesHelper helper = new IDGraphYahooRulesHelper()

	def setup() {
		ReflectionTestUtils.setField(helper, "yahooSubEvents", 'SLID1|UpdatecGateOnly1|MigrateMember1|SyncMaillennium1')
		ReflectionTestUtils.setField(helper, "yahooCSI", 'YAHOO1|MigratePortalWeb1')
	}

	def "processYahooMessage returns true for valid event"() {
		given: "a valid event loaded from JSON file"
		HashMap eventsJson = readJsonFileToMap("mockResponse/IDGraphExtEvents.json") as HashMap

		when: "processYahooMessage is called"
		boolean result = helper.processYahooMessage(eventsJson)

		then: "no unexpected interactions"
		0 * _

		and: "result is true"
		result == true
	}

	def "processYahooMessage returns false for null event"() {
		when: "processYahooMessage is called with null"
		boolean result = helper.processYahooMessage(null)

		then: "no unexpected interactions"
		0 * _

		and: "result is false"
		result == false
	}

	def "processYahooMessage returns false for empty event"() {
		when: "processYahooMessage is called with empty map"
		boolean result = helper.processYahooMessage([:])

		then: "no unexpected interactions"
		0 * _

		and: "result is false"
		result == false
	}

	def "processYahooMessage returns false for invalid eventname"() {
		given: "an event with an eventname not matching any switch case"
		Map<String, Object> event = [subEvent: "sub1", domain: "valid", callingSystemId: "valid", eventname: "InvalidEvent", migrationInd: "M", portalProvider: "AT&T Yahoo"]

		when: "processYahooMessage is called"
		boolean result = helper.processYahooMessage(event)

		then: "no unexpected interactions"
		0 * _

		and: "result is false because eventname does not match any rule"
		result == false
	}

	def "validateCommonRules returns false when subEventList is empty"() {
		given: "a helper with empty yahooSubEvents"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		testHelper.yahooSubEvents = ""
		Map<String, Object> event = [subEvent: "ANY_SUBEVENT", domain: "valid.domain", callingSystemId: "validCSI"]

		when: "validateCommonRules is called"
		boolean result = testHelper.validateCommonRules(event)

		then: "no unexpected interactions"
		0 * _

		and: "result is false because subEventList is empty"
		!result
	}

	def "validateCommonRules returns false for domain slid.dum"() {
		given: "a helper with configured subEvents and CSI, and event with domain slid.dum"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		testHelper.yahooSubEvents = "sub3|sub4"
		testHelper.yahooCSI = "csi1|csi2"
		Map<String, Object> event = [subEvent: "sub1", domain: "slid.dum", callingSystemId: "csi1"]

		when: "validateCommonRules is called"
		boolean result = testHelper.validateCommonRules(event)

		then: "no unexpected interactions"
		0 * _

		and: "result is false because domain is slid.dum"
		result == false
	}

	@Unroll
	def "validateCommonRules returns false for #scenarioName"() {
		given: "a helper with configured subEvents and CSI"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		testHelper.yahooSubEvents = "sub3|sub4"
		testHelper.yahooCSI = testCSI
		Map<String, Object> event = [callingSystemId: testCallingSystemId, subEvent: "subX", domain: "domainX"]

		when: "validateCommonRules is called"
		boolean result = testHelper.validateCommonRules(event)

		then: "no unexpected interactions"
		0 * _

		and: "result is false"
		!result

		where:
		scenarioName              | testCSI      | testCallingSystemId
		"empty CSI list"          | ""           | "anyCSI"
		"matching callingSystemId"| "csi1|csi2"  | "csi1"
	}

	@Unroll
	def "processEventRules returns #expected for #eventName with migrationInd #migrationInd"() {
		given: "a helper and event with specific eventname and migrationInd"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname   : eventName,
				migrationInd: migrationInd
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then: "no unexpected interactions"
		0 * _

		and: "result matches expected"
		result == expected

		where:
		eventName                    | migrationInd | expected
		"UpdateServicesStatusList"   | "M"          | false
		"UpdateServicesStatusList"   | "Y"          | false
		"UpdateServicesStatusList"   | "P"          | false
		"UpdateServicesStatusList"   | ""           | false
		"UpdateServicesStatusList"   | null         | false
		"ChangePassword"             | "M"          | true
		"ChangePassword"             | "Y"          | true
		"ChangePassword"             | "P"          | false
		"UpdateMember"               | "M"          | true
		"UpdateMember"               | "Y"          | true
		"UpdateMember"               | "P"          | false
		"RemoveServicesList"         | "M"          | false
		"RemoveServicesList"         | "Y"          | false
		"RemoveServicesList"         | "P"          | false
	}

	@Unroll
	def "processEventRules returns #expected for AddServices with serviceType #serviceType, portalProvider #portalProvider, migrationInd #migrationInd"() {
		given: "a helper and event with AddServices eventname and specific service configuration"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname   : "AddServices",
				migrationInd: migrationInd,
				services    : [
						[
								serviceType   : serviceType,
								sor_name      : "ACE",
								serviceStatus : "Enabled",
								portalProvider: portalProvider,
								memberStatus  : "Enabled"
						]
				]
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then: "no unexpected interactions"
		0 * _

		and: "result matches expected"
		result == expected

		where:
		serviceType | portalProvider  | migrationInd | expected
		"HSIA"      | "AT&T Yahoo"   | "M"          | true
		"HSIA"      | "AT&T Yahoo"   | "Y"          | true
		"HSIA"      | "AT&T Yahoo"   | "P"          | true
		"HSIA"      | "OtherProvider"| "M"          | true
		"OTHER"     | "AT&T Yahoo"   | "M"          | true
		null        | "AT&T Yahoo"   | "M"          | true
		"HSIA"      | null           | "M"          | true
		"HSIA"      | "AT&T Yahoo"   | null         | true
		"OTHER"     | "OtherProvider"| "P"          | false
		"OTHER"     | "OtherProvider"| null         | false
	}

	@Unroll
	def "processEventRules returns #expected for UpdateProfileInfo with portalProvider '#portalProvider' and migrationInd '#migrationInd'"() {
		given: "a helper and event with UpdateProfileInfo eventname"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname     : "UpdateProfileInfo",
				portalProvider: portalProvider,
				migrationInd  : migrationInd
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then: "no unexpected interactions"
		0 * _

		and: "result matches expected"
		result == expected

		where:
		portalProvider  | migrationInd | expected
		"AT&T Yahoo"    | "M"          | true
		"AT&T Yahoo"    | "Y"          | true
		"AT&T Yahoo"    | "P"          | true   // portalProvider match alone is sufficient (OR logic)
		"AT&T Yahoo"    | null         | true   // portalProvider match alone is sufficient
		"OtherProvider" | "M"          | true   // migrationInd M alone is sufficient (OR logic)
		"OtherProvider" | "Y"          | true   // migrationInd Y alone is sufficient
		"OtherProvider" | "P"          | false  // neither portalProvider nor valid migrationInd
		"OtherProvider" | null         | false
		null            | "M"          | true   // migrationInd M alone is sufficient
		null            | null         | false  // neither match
	}

	@Unroll
	def "processEventRules returns #expected for AddMember with migrationInd #migrationInd and subEvent #subEvent"() {
		given: "a helper and event with AddMember eventname"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname      : "AddMember",
				migrationInd   : migrationInd,
				subEvent       : subEvent,
				callingSystemId: callingSystemId
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then: "no unexpected interactions"
		0 * _

		and: "result matches expected"
		result == expected

		where:
		migrationInd | subEvent             | callingSystemId | expected
		"M"          | null                 | "SDP"           | true
		"Y"          | null                 | "SDP"           | true
		"P"          | null                 | "SDP"           | true
		""           | null                 | "SDP"           | false
		null         | null                 | "SDP"           | false
		"M"          | "ExistingRegVoIP"    | "SDP"           | false   // VoIP subEvent excluded
		"Y"          | "AddingVoIPToParent" | "SDP"           | false   // VoIP subEvent excluded
		"P"          | "existingregvoip"    | "SDP"           | false   // case-insensitive match
		"M"          | "addingvoiptoparent" | "SDP"           | false   // case-insensitive match
		"M"          | "OtherSubEvent"      | "SDP"           | true    // non-VoIP subEvent allowed
		"M"          | null                 | "YAHOO"         | false   // callingSystemId YAHOO excluded
		"M"          | null                 | "yahoo"         | false   // case-insensitive YAHOO match
	}

	@Unroll
	def "processEventRules returns #expected for AddMemberList with migrationInd #migrationInd and subEvent #subEvent"() {
		given: "a helper and event with AddMemberList eventname (shares AddMember logic)"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname      : "AddMemberList",
				migrationInd   : migrationInd,
				subEvent       : subEvent,
				callingSystemId: callingSystemId
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then: "no unexpected interactions"
		0 * _

		and: "result matches expected"
		result == expected

		where:
		migrationInd | subEvent             | callingSystemId | expected
		"M"          | null                 | "SDP"           | true
		"Y"          | null                 | "SDP"           | true
		"P"          | null                 | "SDP"           | true
		""           | null                 | "SDP"           | false
		"M"          | "ExistingRegVoIP"    | "SDP"           | false   // VoIP subEvent excluded
		"M"          | null                 | "YAHOO"         | false   // callingSystemId YAHOO excluded
	}

	def "processEventRules returns false for unrecognized eventname"() {
		given: "a helper and event with an unknown eventname"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname   : "UnknownEvent",
				migrationInd: "M"
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then: "no unexpected interactions"
		0 * _

		and: "result is false because eventname is not recognized"
		result == false
	}

	def "processEventRules returns false for AddServices with null services list"() {
		given: "a helper and event with null services"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname   : "AddServices",
				migrationInd: "M",
				services    : null
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then: "no unexpected interactions"
		0 * _

		and: "result is false because services is null"
		result == false
	}

	def "processEventRules returns false for AddServices with empty services list"() {
		given: "a helper and event with empty services"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname   : "AddServices",
				migrationInd: "P",
				services    : []
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then: "no unexpected interactions"
		0 * _

		and: "result is false because services list is empty"
		result == false
	}

	def "validateCommonRules returns false when filterYahoo is Y"() {
		given: "a helper with valid config and event with filterYahoo=Y"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		testHelper.yahooSubEvents = "sub3|sub4"
		testHelper.yahooCSI = "csi3|csi4"
		Map<String, Object> event = [subEvent: "sub1", domain: "valid.domain", callingSystemId: "csi1", filterYahoo: "Y"]

		when: "validateCommonRules is called"
		boolean result = testHelper.validateCommonRules(event)

		then: "no unexpected interactions"
		0 * _

		and: "result is false because filterYahoo=Y"
		result == false
	}

	def "validateCommonRules returns false when filterYahoo is y (case-insensitive)"() {
		given: "a helper with valid config and event with filterYahoo=y (lowercase)"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		testHelper.yahooSubEvents = "sub3|sub4"
		testHelper.yahooCSI = "csi3|csi4"
		Map<String, Object> event = [subEvent: "sub1", domain: "valid.domain", callingSystemId: "csi1", filterYahoo: "y"]

		when: "validateCommonRules is called"
		boolean result = testHelper.validateCommonRules(event)

		then: "no unexpected interactions"
		0 * _

		and: "result is false because filterYahoo is case-insensitive Y"
		result == false
	}

	def "validateCommonRules returns true when filterYahoo is N"() {
		given: "a helper with valid config and event with filterYahoo=N"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		testHelper.yahooSubEvents = "sub3|sub4"
		testHelper.yahooCSI = "csi3|csi4"
		Map<String, Object> event = [subEvent: "sub1", domain: "valid.domain", callingSystemId: "csi1", filterYahoo: "N"]

		when: "validateCommonRules is called"
		boolean result = testHelper.validateCommonRules(event)

		then: "no unexpected interactions"
		0 * _

		and: "result is true because filterYahoo is not Y"
		result == true
	}

	def "validateCommonRules returns true when filterYahoo is null"() {
		given: "a helper with valid config and event without filterYahoo"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		testHelper.yahooSubEvents = "sub3|sub4"
		testHelper.yahooCSI = "csi3|csi4"
		Map<String, Object> event = [subEvent: "sub1", domain: "valid.domain", callingSystemId: "csi1"]

		when: "validateCommonRules is called"
		boolean result = testHelper.validateCommonRules(event)

		then: "no unexpected interactions"
		0 * _

		and: "result is true because filterYahoo is null"
		result == true
	}

	def "processYahooMessage returns false when filterYahoo is Y (integration)"() {
		given: "a valid event but with filterYahoo=Y"
		Map<String, Object> event = [
				subEvent       : "sub1",
				domain         : "valid.domain",
				callingSystemId: "valid",
				eventname      : "UpdateMember",
				migrationInd   : "M",
				filterYahoo    : "Y"
		]

		when: "processYahooMessage is called"
		boolean result = helper.processYahooMessage(event)

		then: "no unexpected interactions"
		0 * _

		and: "result is false because filterYahoo=Y rejects the event"
		result == false
	}

	// ==================== processAddRemoveServicesList Tests ====================

	@Unroll
	def "AddRemoveServicesList PORTAL check returns #expected for scenario #scenarioName"() {
		given: "a helper"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()

		and: "event data with AddRemoveServicesList eventname"
		Map<String, Object> event = [
				eventname: "AddRemoveServicesList",
				services : services
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                              | services                                                                       || expected
		"null services"                           | null                                                                           || false
		"empty services"                          | []                                                                             || false
		"PORTAL with AT&T Yahoo"                  | [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]                        || true
		"PORTAL with AT&T Yahoo among others"     | [[serviceType: "HSIA"], [serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]] || true
		"PORTAL without AT&T Yahoo"               | [[serviceType: "PORTAL", portalProvider: "Other"]]                             || false
		"HSIA only (no PORTAL)"                   | [[serviceType: "HSIA"]]                                                        || false
		"IPTV only (no PORTAL)"                   | [[serviceType: "IPTV"]]                                                        || false
		"multiple services no PORTAL"             | [[serviceType: "HSIA"], [serviceType: "IPTV"]]                                 || false
		"PORTAL with no portalProvider"           | [[serviceType: "PORTAL"]]                                                      || false
	}

	def "AddRemoveServicesList with memberInfo fallback for PORTAL service"() {
		given: "a helper"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()

		and: "event with AddRemoveServicesList eventname and memberInfo containing PORTAL in addServices"
		Map<String, Object> event = [
				eventname : "AddRemoveServicesList",
				services  : null,
				memberInfo: [
						[addServices: [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]]
				]
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then:
		0 * _

		and: "result is true because memberInfo fallback extracts PORTAL with AT&T Yahoo"
		result == true
	}

	def "AddRemoveServicesList with memberInfo containing removeServices with PORTAL"() {
		given: "a helper"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()

		and: "event with memberInfo containing removeServices with PORTAL"
		Map<String, Object> event = [
				eventname : "AddRemoveServicesList",
				services  : null,
				memberInfo: [
						[removeServices: [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]]
				]
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then:
		0 * _

		and: "result is true because memberInfo fallback extracts PORTAL with AT&T Yahoo from removeServices"
		result == true
	}

	def "AddRemoveServicesList returns false when no PORTAL service exists"() {
		given: "a helper"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()

		and: "event with non-PORTAL services"
		Map<String, Object> event = [
				eventname: "AddRemoveServicesList",
				services : [[serviceType: "HSIA"]]
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then:
		0 * _

		and: "result is false because no PORTAL service with AT&T Yahoo exists"
		result == false
	}

	// ==================== validateCommonRules Edge Cases ====================

	def "validateCommonRules returns false when subEvent is in yahooSubEvents list"() {
		given: "a helper with configured subEvents containing the event's subEvent"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		testHelper.yahooSubEvents = "SLID|UpdatecGateOnly|MigrateMember"
		testHelper.yahooCSI = "csi3|csi4"
		Map<String, Object> event = [subEvent: "SLID", domain: "valid.domain", callingSystemId: "csi1"]

		when: "validateCommonRules is called"
		boolean result = testHelper.validateCommonRules(event)

		then:
		0 * _

		and: "result is false because subEvent SLID is in the rejection list"
		result == false
	}

	def "validateCommonRules returns false when subEvent is UpdatecGateOnly"() {
		given: "a helper with configured subEvents"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		testHelper.yahooSubEvents = "SLID|UpdatecGateOnly|MigrateMember"
		testHelper.yahooCSI = "csi3|csi4"
		Map<String, Object> event = [subEvent: "UpdatecGateOnly", domain: "valid.domain", callingSystemId: "csi1"]

		when: "validateCommonRules is called"
		boolean result = testHelper.validateCommonRules(event)

		then:
		0 * _

		and: "result is false because subEvent is in rejection list"
		result == false
	}

	// ==================== AddServices Edge Cases ====================

	def "processEventRules returns true for AddServices with multiple services where one matches"() {
		given: "a helper and event with multiple services"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname   : "AddServices",
				migrationInd: "P",
				services    : [
						[serviceType: "OTHER", portalProvider: "OtherProvider"],
						[serviceType: "HSIA", portalProvider: "AT&T Yahoo"]
				]
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then:
		0 * _

		and: "result is true because second service matches HSIA + AT&T Yahoo"
		result == true
	}

	def "processEventRules returns false for AddServices with non-Map service entries"() {
		given: "a helper and event with services containing non-Map entries"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname   : "AddServices",
				migrationInd: "P",
				services    : ["stringEntry", 123, null]
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then:
		0 * _

		and: "result is false because no valid Map service entries"
		result == false
	}

	def "processEventRules returns true for AddServices with migrationInd Y regardless of service content"() {
		given: "a helper and event with migrationInd Y"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname   : "AddServices",
				migrationInd: "Y",
				services    : [
						[serviceType: "RANDOM", portalProvider: "RandomProvider"]
				]
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then:
		0 * _

		and: "result is true because migrationInd Y triggers early return"
		result == true
	}

	// ==================== AddMember/AddMemberList Edge Cases ====================

	def "processEventRules returns false for AddMember with null callingSystemId"() {
		given: "a helper and event with null callingSystemId"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname      : "AddMember",
				migrationInd   : "M",
				subEvent       : "Normal",
				callingSystemId: null
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then: "NullPointerException is thrown because callingSystemId.equalsIgnoreCase is called on null"
		thrown(NullPointerException)
	}

	def "processEventRules returns true for AddMemberList with valid migrationInd P"() {
		given: "a helper and event with migrationInd P (allowed for AddMember/AddMemberList)"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname      : "AddMemberList",
				migrationInd   : "P",
				subEvent       : "Normal",
				callingSystemId: "SDP"
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then:
		0 * _

		and: "result is true because P is valid for AddMember/AddMemberList"
		result == true
	}

	// ==================== Integration Tests ====================

	def "processYahooMessage integration test for AddRemoveServicesList with valid services"() {
		given: "a helper with all required configurations"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		ReflectionTestUtils.setField(testHelper, "yahooSubEvents", "SLID|UpdatecGateOnly")
		ReflectionTestUtils.setField(testHelper, "yahooCSI", "YAHOO|MigratePortalWeb")
		ReflectionTestUtils.setField(testHelper, "yahooServices", "HSIA|IPTV|VOIP")

		and: "a complete valid event"
		Map<String, Object> event = [
				subEvent       : "ValidSubEvent",
				domain         : "valid.domain",
				callingSystemId: "SDP",
				eventname      : "AddRemoveServicesList",
				filterYahoo    : "N",
				services       : [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]
		]

		when: "processYahooMessage is called"
		boolean result = testHelper.processYahooMessage(event)

		then:
		0 * _

		and: "result is true because PORTAL service with AT&T Yahoo exists"
		result == true
	}

	def "processYahooMessage integration test for AddRemoveServicesList with invalid services"() {
		given: "a helper with all required configurations"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		ReflectionTestUtils.setField(testHelper, "yahooSubEvents", "SLID|UpdatecGateOnly")
		ReflectionTestUtils.setField(testHelper, "yahooCSI", "YAHOO|MigratePortalWeb")
		ReflectionTestUtils.setField(testHelper, "yahooServices", "HSIA|IPTV|VOIP")

		and: "event with services not in allowed list"
		Map<String, Object> event = [
				subEvent       : "ValidSubEvent",
				domain         : "valid.domain",
				callingSystemId: "SDP",
				eventname      : "AddRemoveServicesList",
				filterYahoo    : "N",
				services       : [[serviceType: "UNKNOWN"]]
		]

		when: "processYahooMessage is called"
		boolean result = testHelper.processYahooMessage(event)

		then:
		0 * _

		and: "result is false because service type not in allowed list"
		result == false
	}

	// ==================== processAddRemoveServicesList via Reflection ====================

	@Unroll
	def "processAddRemoveServicesList direct invocation returns #expected for scenario #scenarioName"() {
		given: "a helper with configured yahooServices"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		ReflectionTestUtils.setField(testHelper, "yahooServices", "svc1|svc2|svc3")

		when: "processAddRemoveServicesList is invoked via reflection"
		def method = IDGraphYahooRulesHelper.class.getDeclaredMethod("processAddRemoveServicesList", List.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, [allServices] as Object[])

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                          | allServices                                              || expected
		"null services returns true"          | null                                                     || true
		"empty services returns false"        | []                                                       || false
		"single service matches"              | [[serviceType: "svc1"]]                                  || true
		"single service no match"             | [[serviceType: "unknown"]]                               || false
		"multiple services one match"         | [[serviceType: "unknown"], [serviceType: "svc2"]]        || true
		"multiple services no match"          | [[serviceType: "unknown1"], [serviceType: "unknown2"]]   || false
		"service with null serviceType"       | [[serviceType: null]]                                    || false
		"mixed null and valid serviceType"    | [[serviceType: null], [serviceType: "svc3"]]             || true
	}

	// ==================== Additional validateCommonRules Coverage ====================

	def "validateCommonRules returns true for valid event passing all checks"() {
		given: "a helper with valid configuration"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		testHelper.yahooSubEvents = "SLID|UpdatecGateOnly"
		testHelper.yahooCSI = "YAHOO|MigratePortalWeb"

		and: "event that passes all validation checks"
		Map<String, Object> event = [
				subEvent       : "ValidSubEvent",
				domain         : "valid.domain",
				callingSystemId: "SDP",
				filterYahoo    : "N"
		]

		when: "validateCommonRules is called"
		boolean result = testHelper.validateCommonRules(event)

		then:
		0 * _

		and: "result is true because all checks pass"
		result == true
	}

	def "validateCommonRules returns false when subEvent is MigrateMember"() {
		given: "a helper with MigrateMember in rejection list"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		testHelper.yahooSubEvents = "SLID|UpdatecGateOnly|MigrateMember"
		testHelper.yahooCSI = "csi3|csi4"
		Map<String, Object> event = [subEvent: "MigrateMember", domain: "valid.domain", callingSystemId: "csi1"]

		when: "validateCommonRules is called"
		boolean result = testHelper.validateCommonRules(event)

		then:
		0 * _
		and: "result is false because MigrateMember is in rejection list"
		result == false
	}

	def "validateCommonRules returns false when subEvent is SyncMaillennium"() {
		given: "a helper with SyncMaillennium in rejection list"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		testHelper.yahooSubEvents = "SLID|UpdatecGateOnly|MigrateMember|SyncMaillennium"
		testHelper.yahooCSI = "csi3|csi4"
		Map<String, Object> event = [subEvent: "SyncMaillennium", domain: "valid.domain", callingSystemId: "csi1"]

		when: "validateCommonRules is called"
		boolean result = testHelper.validateCommonRules(event)

		then:
		0 * _

		and: "result is false because SyncMaillennium is in rejection list"
		result == false
	}

	// ==================== hasPortalServiceWithYahooProvider Tests ====================

	@Unroll
	def "hasPortalServiceWithYahooProvider returns #expected for scenario: #scenarioName"() {
		given: "service list and root portalProvider"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()

		when: "hasPortalServiceWithYahooProvider is invoked via reflection"
		def method = IDGraphYahooRulesHelper.class.getDeclaredMethod(
				"hasPortalServiceWithYahooProvider", List.class, String.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, services, rootPortalProvider)

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                                       | services                                                                       | rootPortalProvider || expected
		"PORTAL with AT&T Yahoo in service map"            | [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]                        | null               || true
		"PORTAL with AT&T Yahoo at root only"              | [[serviceType: "PORTAL"]]                                                      | "AT&T Yahoo"       || true
		"PORTAL with AT&T Yahoo in both service and root"  | [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]                        | "AT&T Yahoo"       || true
		"PORTAL with different provider in service"        | [[serviceType: "PORTAL", portalProvider: "OtherProvider"]]                     | null               || false
		"PORTAL with different provider, non-Yahoo root"   | [[serviceType: "PORTAL", portalProvider: "OtherProvider"]]                     | "OtherProvider"    || false
		"PORTAL with no portalProvider anywhere"           | [[serviceType: "PORTAL"]]                                                      | null               || false
		"non-PORTAL service with AT&T Yahoo"               | [[serviceType: "HSIA", portalProvider: "AT&T Yahoo"]]                          | "AT&T Yahoo"       || false
		"null services list"                               | null                                                                           | "AT&T Yahoo"       || false
		"empty services list"                              | []                                                                             | "AT&T Yahoo"       || false
		"multiple services - PORTAL with Yahoo"            | [[serviceType: "HSIA"], [serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]] | null               || true
		"multiple services - no PORTAL"                    | [[serviceType: "HSIA"], [serviceType: "VOIP"]]                                | "AT&T Yahoo"       || false
		"PORTAL null portalProvider, root AT&T Yahoo"      | [[serviceType: "PORTAL", portalProvider: null]]                                | "AT&T Yahoo"       || true
	}

	// ==================== processEventRules PORTAL Bypass Tests ====================

	@Unroll
	def "processEventRules returns #expected for #eventName when PORTAL service with AT&T Yahoo exists"() {
		given: "a helper with event containing PORTAL service with AT&T Yahoo portalProvider"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		ReflectionTestUtils.setField(testHelper, "yahooServices", "HSIA|IPTV|VOIP")
		Map<String, Object> event = [
				eventname      : eventName,
				migrationInd   : "P",
				portalProvider : rootPortalProvider,
				subEvent       : "Normal",
				callingSystemId: "SDP",
				services       : services
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then:
		0 * _

		and: "result matches expected"
		result == expected

		where:
		eventName                  | services                                                 | rootPortalProvider || expected
		"UpdateServicesStatusList" | [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]  | null               || true
		"ChangePassword"           | [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]  | null               || false
		"UpdateMember"             | [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]  | null               || false
		"AddRemoveServicesList"    | [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]  | null               || true
		"UpdateProfileInfo"        | [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]  | null               || false
		"AddMember"                | [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]  | null               || true
		"AddMemberList"            | [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]  | null               || true
		"AddServices"              | [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]  | null               || false
		"UnknownEvent"             | [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]  | null               || false
		"UpdateMember"             | [[serviceType: "PORTAL"]]                                | "AT&T Yahoo"       || false
		"UnknownEvent"             | [[serviceType: "PORTAL"]]                                | "AT&T Yahoo"       || false
	}

	def "processEventRules falls through to event rules when PORTAL has non-Yahoo provider"() {
		given: "event with PORTAL service having non-Yahoo portalProvider"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname      : "UpdateMember",
				migrationInd   : "P",
				services       : [[serviceType: "PORTAL", portalProvider: "OtherProvider"]]
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then:
		0 * _

		and: "result is false because PORTAL check fails and migrationInd P is invalid for UpdateMember"
		result == false
	}

	def "processEventRules falls through when services have no PORTAL type"() {
		given: "event with non-PORTAL services"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname      : "UpdateMember",
				migrationInd   : "M",
				portalProvider : "AT&T Yahoo",
				services       : [[serviceType: "HSIA", portalProvider: "AT&T Yahoo"]]
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then:
		0 * _

		and: "result is true via event-specific rule (migrationInd M), not PORTAL check"
		result == true
	}

	// ==================== Full Service Extraction Fallback Tests ====================

	def "processEventRules uses memberInfo/services fallback when root services is null"() {
		given: "event with PORTAL in memberInfo/services, no root services"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname : "AddRemoveServicesList",
				memberInfo: [
						[services: [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]]
				]
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then:
		0 * _

		and: "result is true because PORTAL found via memberInfo/services fallback"
		result == true
	}

	def "processEventRules uses memberInfo/addServices fallback when no root or memberInfo/services"() {
		given: "event with PORTAL in memberInfo/addServices"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname : "AddRemoveServicesList",
				memberInfo: [
						[addServices: [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]]
				]
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then:
		0 * _

		and: "result is true because PORTAL found via memberInfo/addServices fallback"
		result == true
	}

	def "processEventRules uses memberInfo/removeServices fallback"() {
		given: "event with PORTAL in memberInfo/removeServices"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname : "AddRemoveServicesList",
				memberInfo: [
						[removeServices: [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]]
				]
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then:
		0 * _

		and: "result is true because PORTAL found via memberInfo/removeServices fallback"
		result == true
	}

	def "processEventRules fallback prefers memberInfo/services over addServices"() {
		given: "memberInfo with both services (PORTAL) and addServices (HSIA)"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		ReflectionTestUtils.setField(testHelper, "yahooServices", "HSIA|IPTV")
		Map<String, Object> event = [
				eventname : "AddRemoveServicesList",
				memberInfo: [
						[
								services   : [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]],
								addServices: [[serviceType: "HSIA"]]
						]
				]
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then:
		0 * _

		and: "result is true — memberInfo/services (PORTAL) is preferred over addServices"
		result == true
	}

	def "processEventRules memberInfo fallback works for UpdateServicesStatusList"() {
		given: "UpdateServicesStatusList event with no root services but PORTAL in memberInfo/addServices"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		Map<String, Object> event = [
				eventname : "UpdateServicesStatusList",
				memberInfo: [
						[addServices: [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]]
				]
		]

		when: "processEventRules is called"
		boolean result = testHelper.processEventRules(event)

		then:
		0 * _

		and: "result is true — full fallback works for UpdateServicesStatusList PORTAL check"
		result == true
	}

	// ==================== PORTAL Integration Tests via processYahooMessage ====================

	def "processYahooMessage returns true for PORTAL service with AT&T Yahoo in service map"() {
		given: "a helper with all required configurations"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		ReflectionTestUtils.setField(testHelper, "yahooSubEvents", "SLID|UpdatecGateOnly")
		ReflectionTestUtils.setField(testHelper, "yahooCSI", "YAHOO|MigratePortalWeb")
		ReflectionTestUtils.setField(testHelper, "yahooServices", "HSIA|IPTV|VOIP")

		and: "event with PORTAL service having AT&T Yahoo portalProvider"
		Map<String, Object> event = [
				subEvent       : "ValidSubEvent",
				domain         : "valid.domain",
				callingSystemId: "SDP",
				eventname      : "UpdateServicesStatusList",
				filterYahoo    : "N",
				services       : [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]
		]

		when: "processYahooMessage is called"
		boolean result = testHelper.processYahooMessage(event)

		then:
		0 * _

		and: "result is true because PORTAL service with AT&T Yahoo found for UpdateServicesStatusList"
		result == true
	}

	def "processYahooMessage returns true for PORTAL service with AT&T Yahoo at root level"() {
		given: "a helper with all required configurations"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		ReflectionTestUtils.setField(testHelper, "yahooSubEvents", "SLID|UpdatecGateOnly")
		ReflectionTestUtils.setField(testHelper, "yahooCSI", "YAHOO|MigratePortalWeb")
		ReflectionTestUtils.setField(testHelper, "yahooServices", "HSIA|IPTV|VOIP")

		and: "event with PORTAL service and AT&T Yahoo at root portalProvider"
		Map<String, Object> event = [
				subEvent       : "ValidSubEvent",
				domain         : "valid.domain",
				callingSystemId: "SDP",
				eventname      : "UpdateServicesStatusList",
				filterYahoo    : "N",
				portalProvider : "AT&T Yahoo",
				services       : [[serviceType: "PORTAL"]]
		]

		when: "processYahooMessage is called"
		boolean result = testHelper.processYahooMessage(event)

		then:
		0 * _

		and: "result is true because PORTAL service found with root AT&T Yahoo portalProvider"
		result == true
	}

	def "processYahooMessage returns true for PORTAL in memberInfo/services fallback"() {
		given: "a helper with all required configurations"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		ReflectionTestUtils.setField(testHelper, "yahooSubEvents", "SLID|UpdatecGateOnly")
		ReflectionTestUtils.setField(testHelper, "yahooCSI", "YAHOO|MigratePortalWeb")
		ReflectionTestUtils.setField(testHelper, "yahooServices", "HSIA|IPTV|VOIP")

		and: "event with PORTAL service in memberInfo/services"
		Map<String, Object> event = [
				subEvent       : "ValidSubEvent",
				domain         : "valid.domain",
				callingSystemId: "SDP",
				eventname      : "AddRemoveServicesList",
				filterYahoo    : "N",
				memberInfo     : [
						[services: [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]]
				]
		]

		when: "processYahooMessage is called"
		boolean result = testHelper.processYahooMessage(event)

		then:
		0 * _

		and: "result is true because PORTAL found via memberInfo/services fallback"
		result == true
	}

	def "processYahooMessage returns true for PORTAL in memberInfo/addServices fallback"() {
		given: "a helper with all required configurations"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		ReflectionTestUtils.setField(testHelper, "yahooSubEvents", "SLID|UpdatecGateOnly")
		ReflectionTestUtils.setField(testHelper, "yahooCSI", "YAHOO|MigratePortalWeb")
		ReflectionTestUtils.setField(testHelper, "yahooServices", "HSIA|IPTV|VOIP")

		and: "event with PORTAL service in memberInfo/addServices"
		Map<String, Object> event = [
				subEvent       : "ValidSubEvent",
				domain         : "valid.domain",
				callingSystemId: "SDP",
				eventname      : "AddRemoveServicesList",
				filterYahoo    : "N",
				memberInfo     : [
						[addServices: [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]]
				]
		]

		when: "processYahooMessage is called"
		boolean result = testHelper.processYahooMessage(event)

		then:
		0 * _

		and: "result is true because PORTAL found via memberInfo/addServices fallback"
		result == true
	}

	def "processYahooMessage returns false when PORTAL exists but portalProvider is not AT&T Yahoo"() {
		given: "a helper with all required configurations"
		IDGraphYahooRulesHelper testHelper = new IDGraphYahooRulesHelper()
		ReflectionTestUtils.setField(testHelper, "yahooSubEvents", "SLID|UpdatecGateOnly")
		ReflectionTestUtils.setField(testHelper, "yahooCSI", "YAHOO|MigratePortalWeb")
		ReflectionTestUtils.setField(testHelper, "yahooServices", "HSIA|IPTV|VOIP")

		and: "event with PORTAL service but non-Yahoo portalProvider"
		Map<String, Object> event = [
				subEvent       : "ValidSubEvent",
				domain         : "valid.domain",
				callingSystemId: "SDP",
				eventname      : "UpdateMember",
				filterYahoo    : "N",
				migrationInd   : "P",
				services       : [[serviceType: "PORTAL", portalProvider: "OtherProvider"]]
		]

		when: "processYahooMessage is called"
		boolean result = testHelper.processYahooMessage(event)

		then:
		0 * _

		and: "result is false — PORTAL check fails, UpdateMember with migrationInd P also fails"
		result == false
	}
}