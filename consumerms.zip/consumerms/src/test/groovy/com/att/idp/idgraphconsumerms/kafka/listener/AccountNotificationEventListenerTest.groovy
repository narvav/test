package com.att.idp.idgraphconsumerms.kafka.listener

import com.att.idp.idgraphconsumerms.kafka.dmctn.service.AccountServiceFactory
import com.att.idp.idgraphconsumerms.kafka.dmctn.service.BaseService
import com.att.idp.idgraphconsumerms.kafka.model.AccountNotificationEvent
import com.att.idp.idgraphconsumerms.kafka.model.SubscriberEventNotification

import java.util.Collections
import org.springframework.kafka.support.Acknowledgment
import org.springframework.messaging.MessageHeaders
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

class AccountNotificationEventListenerTest extends Specification {

    @Shared
    AccountServiceFactory accountServiceFactory
    @Shared
    BaseService backendService

    def setup() {
        accountServiceFactory = Mock(AccountServiceFactory)
        backendService = Mock(BaseService)
    }

    private static void inject(AccountNotificationEventListener listener, AccountServiceFactory factory) {
        java.lang.reflect.Field f = AccountNotificationEventListener.class.getDeclaredField("accountServiceFactory")
        f.setAccessible(true)
        f.set(listener, factory)
    }

    private String buildJson(String eventName, String subId, String msisdn, String status) {
        return "{" +
                "\"eventName\":\"" + eventName + "\"," +
                "\"subId\":\"" + subId + "\"," +
                "\"subscriberNumber\":\"" + msisdn + "\"," +
                "\"billingAccountNumber\":\"" + msisdn + "\"," +
                "\"oldFan\":\"OLDFAN\"," +
                "\"newFan\":\"NEWFAN\"," +
                "\"subscriberStatus\":\"" + status + "\"" +
                "}";
    }

    @Unroll
    def "should consume account notification and execute backend for #scenarioName"() {
        given: "Listener with injected factory and a valid ChangeDataEvent JSON"
        AccountNotificationEventListener listener = new AccountNotificationEventListener()
        inject(listener, accountServiceFactory)
        String json = buildJson(eventName, subId, msisdn, status)
        MessageHeaders headers = new MessageHeaders(Collections.emptyMap())
        Acknowledgment acknowledgment = Mock(Acknowledgment)

        when: "consumeAccountNotification is invoked"
        listener.consumeAccountNotification(json, headers, acknowledgment)

        then: "Factory returns backend and execute called with mapped AccountNotificationEvent"
        1 * accountServiceFactory.getService({ AccountNotificationEvent e ->
            e.getEventName() == eventName &&
            e.getSubId() == subId &&
            e.getSubscriberNumber() == msisdn &&
            e.getBillingAccountNumber() == msisdn &&
            e.getOldFan() == "OLDFAN" &&
            e.getNewFan() == "NEWFAN" &&
            e.getSubscriberStatus() == status
        }) >> backendService
        1 * backendService.execute({ AccountNotificationEvent e ->
            e.getEventName() == eventName &&
            e.getSubId() == subId &&
            e.getSubscriberNumber() == msisdn &&
            e.getBillingAccountNumber() == msisdn &&
            e.getOldFan() == "OLDFAN" &&
            e.getNewFan() == "NEWFAN" &&
            e.getSubscriberStatus() == status
        })
        1 * acknowledgment.acknowledge()
        0 * _

        and: "No exception thrown and JSON contained event name"
        json.contains(eventName)

        where: "Supported event scenarios"
        scenarioName      | eventName         | subId    | msisdn       | status
        "ActivateAccount" | "ActivateAccount" | "SUB100" | "5551002222" | "ACTIVE"
        "UpdateAccount"   | "UpdateAccount"   | "SUB150" | "5551502222" | "ACTIVE"
        "CloseAccount"    | "CloseAccount"    | "SUB200" | "5552003333" | "CLOSED"
    }

    def "should acknowledge message when event unsupported"() {
        given: "Listener with factory returning null backend"
        AccountNotificationEventListener listener = new AccountNotificationEventListener()
        inject(listener, accountServiceFactory)
        String eventName = "UnsupportedEvent"
        String json = buildJson(eventName, "SUB999", "5559990000", "UNKNOWN")
        MessageHeaders headers = new MessageHeaders(Collections.emptyMap())
        Acknowledgment acknowledgment = Mock(Acknowledgment)

        when: "consumeAccountNotification called with unsupported event"
        listener.consumeAccountNotification(json, headers, acknowledgment)

        then: "Factory queried, returns null, no backend execute"
        1 * accountServiceFactory.getService({ AccountNotificationEvent e ->
            e.getEventName() == eventName
        }) >> null
        1 * acknowledgment.acknowledge()
        0 * _

        and: "JSON includes unsupported event name"
        json.contains(eventName)
    }

    def "should throw JsonProcessingException for invalid JSON input"() {
        given: "Listener and invalid JSON that cannot deserialize"
        AccountNotificationEventListener listener = new AccountNotificationEventListener()
        inject(listener, accountServiceFactory)
        String invalidJson = "not-a-json" // will cause safeConvertToObject to return Optional.empty -> orElseThrow
        MessageHeaders headers = new MessageHeaders(Collections.emptyMap())
        Acknowledgment acknowledgment = Mock(Acknowledgment)

        when: "consumeAccountNotification invoked with invalid JSON"
        listener.consumeAccountNotification(invalidJson, headers, acknowledgment)

        then: "JsonProcessingException thrown before factory or ack"
        0 * accountServiceFactory.getService(_ as AccountNotificationEvent)
        0 * acknowledgment.acknowledge()
        0 * _
        com.fasterxml.jackson.core.JsonProcessingException ex = thrown()

        ex.getMessage() == "Failed to deserialize message to ChangeSubscriberEvent"
    }

    @Unroll
    def "should safely convert for #scenarioName"() {
        given: "Potentially double-encoded JSON string"
        String input = rawJson

        when: "safeConvertToObject invoked"
        Optional<SubscriberEventNotification> result = AccountNotificationEventListener.safeConvertToObject(input, SubscriberEventNotification.class)

        then: "Presence matches expectation and fields verified when present"
        result.isPresent() == expectedPresent
        if (expectedPresent) {
            SubscriberEventNotification evt = result.get()
            evt.getEventName() == "ActivateAccount"
            evt.getSubId() == "SUBID"
        }
        0 * _

        where: "Encoding scenarios"
        scenarioName          | rawJson                                                     | expectedPresent
        "plain json"          | '{"eventName":"ActivateAccount","subId":"SUBID"}'           | true
        "double encoded json" | '"{\"eventName\":\"ActivateAccount\",\"subId\":\"SUBID\"}"' | true
        "blank json"          | ''                                                          | false
    }
}