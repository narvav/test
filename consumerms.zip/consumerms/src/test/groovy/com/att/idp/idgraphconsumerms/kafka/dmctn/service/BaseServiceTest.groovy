import spock.lang.Specification
import spock.lang.Unroll

/**
 * Unit tests for BaseService interface.
 */
class BaseServiceTest extends Specification {

    /**
     * Concrete implementation of BaseService for testing.
     */
    static class TestService implements com.att.idp.idgraphconsumerms.kafka.dmctn.service.BaseService<String> {
        boolean executed = false
        String lastRequest = null
        @Override
        void execute(String request) {
            executed = true
            lastRequest = request
        }
    }

    TestService testService

    def setup() {
        testService = new TestService()
    }

    @Unroll
    def "should execute service for #scenarioName"() {
        given: "A test service and input request"
        String request = inputRequest

        when: "execute is called"
        testService.execute(request)

        then: "Service is executed with correct request"
        testService.executed == true
        testService.lastRequest == expectedRequest

        where:
        scenarioName      | inputRequest   | expectedRequest
        "normal string"  | "test-input"   | "test-input"
        "empty string"   | ""             | ""
        "null value"     | null           | null
    }
}

