package com.att.idp.idgraphconsumerms.utils

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import spock.lang.Specification
import spock.lang.Unroll

class EventCategoryResolverTest extends Specification {

    @Unroll
    def "resolve returns #expectedCategory for GDDN event #eventName"() {
        when:
        Optional<String> result = EventCategoryResolver.resolve(eventName)

        then:
        result.isPresent() == true
        result.get() == expectedCategory
        0 * _

        where:
        eventName                                                                     | expectedCategory
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_ACTIVATE_ACCOUNT            | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_CHANGE_PRODUCT              | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_CLOSE_ACCOUNT               | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_PLATFORM_HANDLER            | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT              | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_FAN_UPDATE
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_RG_ACTIVATION               | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_RG_ACTIVATION
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_RESTORE_SUBSCRIBER            | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_SUBSCRIBER
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_SUSPEND_SUBSCRIBER            | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_SUBSCRIBER
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_CANCEL_SUBSCRIBER             | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_SUBSCRIBER
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_CHANGE_DATA                   | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_SUBSCRIBER
        ConsumerConstants.GridGddnNotification.EVENT_CG_RESTORE_SUBSCRIBER              | ConsumerConstants.GridGddnNotification.CATEGORY_CG_SUBSCRIBER
        ConsumerConstants.GridGddnNotification.EVENT_CG_SUSPEND_SUBSCRIBER              | ConsumerConstants.GridGddnNotification.CATEGORY_CG_SUBSCRIBER
        ConsumerConstants.GridGddnNotification.EVENT_CG_CANCEL_SUBSCRIBER               | ConsumerConstants.GridGddnNotification.CATEGORY_CG_SUBSCRIBER
        ConsumerConstants.GridGddnNotification.EVENT_CG_CHANGE_DATA                     | ConsumerConstants.GridGddnNotification.CATEGORY_CG_SUBSCRIBER
    }

    @Unroll
    def "resolve with transactionType returns #expectedCategory for #eventName with #transactionType"() {
        when:
        Optional<String> result = EventCategoryResolver.resolve(eventName, transactionType)

        then:
        result.isPresent() == true
        result.get() == expectedCategory
        0 * _

        where:
        eventName                                                                     | transactionType                                                                 | expectedCategory
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT              | ConsumerConstants.AccountNotificationConstants.UPDATE_FAN                       | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_FAN_UPDATE
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT              | ConsumerConstants.AccountNotificationConstants.UPDATE_WLS_UNIFICATION            | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_WLS_UNIFICATION
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT              | null                                                                            | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_FAN_UPDATE
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT              | "unknown"                                                                       | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_FAN_UPDATE
        ConsumerConstants.GridGddnNotification.EVENT_GDDN_ACTIVATE_ACCOUNT            | null                                                                            | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_ACCOUNT
    }

    def "resolve returns empty for unknown event name"() {
        when:
        Optional<String> result = EventCategoryResolver.resolve("BSSEMigWireless")

        then:
        result.isPresent() == false
        0 * _
    }

    def "resolve returns empty for null"() {
        when:
        Optional<String> result = EventCategoryResolver.resolve(null)

        then:
        result.isPresent() == false
        0 * _
    }

    @Unroll
    def "requiresSequencing returns true for GDDN event #eventName"() {
        expect:
        EventCategoryResolver.requiresSequencing(eventName) == true

        where:
        eventName << [
                ConsumerConstants.GridGddnNotification.EVENT_GDDN_ACTIVATE_ACCOUNT,
                ConsumerConstants.GridGddnNotification.EVENT_GDDN_CLOSE_ACCOUNT,
                ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT,
                ConsumerConstants.GridGddnNotification.EVENT_GDDN_CHANGE_PRODUCT,
                ConsumerConstants.GridGddnNotification.EVENT_GDDN_RG_ACTIVATION,
                ConsumerConstants.GridGddnNotification.EVENT_GDDN_PLATFORM_HANDLER,
                ConsumerConstants.GridGddnNotification.EVENT_GDDN_RESTORE_SUBSCRIBER,
                ConsumerConstants.GridGddnNotification.EVENT_GDDN_SUSPEND_SUBSCRIBER,
                ConsumerConstants.GridGddnNotification.EVENT_GDDN_CANCEL_SUBSCRIBER,
                ConsumerConstants.GridGddnNotification.EVENT_GDDN_CHANGE_DATA,
                ConsumerConstants.GridGddnNotification.EVENT_CG_RESTORE_SUBSCRIBER,
                ConsumerConstants.GridGddnNotification.EVENT_CG_SUSPEND_SUBSCRIBER,
                ConsumerConstants.GridGddnNotification.EVENT_CG_CANCEL_SUBSCRIBER,
                ConsumerConstants.GridGddnNotification.EVENT_CG_CHANGE_DATA
        ]
    }

    def "requiresSequencing returns false for non-GDDN events"() {
        expect:
        EventCategoryResolver.requiresSequencing("BSSEMigWireless") == false
        EventCategoryResolver.requiresSequencing(null) == false
    }
}
