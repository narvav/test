package com.att.idp.idgraphconsumerms.kafka.listener

import com.att.idp.idgraphconsumerms.helpers.ExternalEventsProcessingHelper
import org.slf4j.MDC
import org.springframework.kafka.support.Acknowledgment
import org.springframework.messaging.MessageHeaders
import spock.lang.Specification
import spock.lang.Unroll

class IDGraphExternalEventsListenerSpoc extends Specification {

    ExternalEventsProcessingHelper externalEventsProcessingHelper
    Acknowledgment acknowledgment
    MessageHeaders messageHeaders
    IDGraphExternalEventsListener listener

    def setup() {
        externalEventsProcessingHelper = Mock(ExternalEventsProcessingHelper)
        acknowledgment = Mock(Acknowledgment)
        messageHeaders = Mock(MessageHeaders)
        listener = new IDGraphExternalEventsListener()
        // Use reflection to set the private field for testability
        def field = IDGraphExternalEventsListener.class.getDeclaredField("externalEventsProcessingHelper")
        field.accessible = true
        field.set(listener, externalEventsProcessingHelper)
    }

    @Unroll
    def "should process event and acknowledge for #scenarioName"() {
        given: "A valid message and mocks"
        String transactionId = scenarioTransactionId
        String message = '{"transactionId":"' + transactionId + '","eventsData":[{"foo":"bar"}]}'

        when: "Listener consumes the event"
        listener.consumeIDGraphExtEventsData(message, messageHeaders, acknowledgment)

        then: "Helper is called, ack is called, MDC is set and removed"
        1 * externalEventsProcessingHelper.processExternalEvents({ Map map ->
            map.transactionId == transactionId && map.eventsData.size() == 1
        })
        1 * acknowledgment.acknowledge()

        and: "MDC is cleaned up"
        !MDC.get('idp-trace-id')

        where:
        scenarioName                | scenarioTransactionId
        "transactionId present"     | "abc-123"
    }

    def "should log and not acknowledge when JSON is invalid"() {
        given: "An invalid JSON message"
        String message = '{invalidJson}'

        when: "Listener consumes the event"
        listener.consumeIDGraphExtEventsData(message, messageHeaders, acknowledgment)

        then: "Helper and ack are not called, error is handled"
        0 * externalEventsProcessingHelper._
        0 * acknowledgment.acknowledge()
    }

    def "should log and not acknowledge when helper throws exception"() {
        given: "A valid message but helper throws"
        String message = '{"transactionId":"tx-err","eventsData":[{"foo":"bar"}]}'
        RuntimeException ex = new RuntimeException("Helper failed")

        when: "Listener consumes the event"
        listener.consumeIDGraphExtEventsData(message, messageHeaders, acknowledgment)

        then: "Helper is called and throws, ack is not called"
        1 * externalEventsProcessingHelper.processExternalEvents({ Map map ->
            map.transactionId == "tx-err"
        }) >> { throw ex }
        0 * acknowledgment.acknowledge()
    }

    @Unroll
    def "should handle edge case for #scenarioName"() {
        given: "Edge case message"
        String message = edgeMessage

        when: "Listener consumes the event"
        listener.consumeIDGraphExtEventsData(message, messageHeaders, acknowledgment)

        then: "Helper and ack are not called"
        0 * externalEventsProcessingHelper._
        0 * acknowledgment.acknowledge()

        where:
        scenarioName         | edgeMessage
        "empty string"      | ""
        "null message"      | null
    }
}
