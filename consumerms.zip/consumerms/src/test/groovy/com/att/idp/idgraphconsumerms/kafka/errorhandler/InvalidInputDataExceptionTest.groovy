package com.att.idp.idgraphconsumerms.kafka.errorhandler

import spock.lang.Specification

class InvalidInputDataExceptionTest extends Specification {

    def "test constructor with message"() {
        when:
        def exception = new InvalidInputDataException("Invalid input data")

        then:
        exception.message == "Invalid input data"
        exception.errorMessage == null
        exception.errorHashMap == null
    }

    def "test constructor with message and errorMessage"() {
        given:
        def errorMessage = new ErrorMessage("123", "Error occurred", "500", "App Info", "Transaction Name")

        when:
        def exception = new InvalidInputDataException("Invalid input data", errorMessage)

        then:
        exception.message == "Invalid input data"
        exception.errorMessage == errorMessage
        exception.errorHashMap == null
    }

    def "test constructor with errorHashMap"() {
        given:
        def errorMap = [
                "appStatusMsg": "Invalid input data",
                "appStatusCode": "400"
        ]

        when:
        def exception = new InvalidInputDataException(errorMap)

        then:
        exception.message == "Invalid input data"
        exception.errorMessage == null
        exception.errorHashMap == errorMap
    }
}