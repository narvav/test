package com.att.idp.idgraphconsumerms.kafka.dmctn.service

import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker
import com.att.idp.idgraphconsumerms.kafka.model.Association
import com.att.idp.idgraphconsumerms.kafka.model.Subscriber
import com.att.idp.idgraphconsumerms.model.UserAssociationChangeRequest
import com.att.idp.idgraphconsumerms.oracle.helpers.MemberServiceDBHelper
import com.att.idp.idgraphconsumerms.oracle.helpers.MemberServiceDBHelperStub
import com.att.idp.idgraphconsumerms.request.validator.RequestValidator
import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.springframework.jdbc.core.JdbcTemplate
import spock.lang.Specification
import spock.lang.Unroll

class ChangeAssociationStatusServiceTest extends Specification {

    ApiRestClient apiRestClient = Mock()
    CosmosFailedEventsWriter cosmosFailedEventsWriter = Mock()
    GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker = Mock()
    ChangeAssociationStatusService service
    JdbcTemplate jdbcTemplate = Mock()
    MemberServiceDBHelper memberServiceDBHelper = Mock()
    MemberServiceDBHelperStub memberServiceDBHelperStub = new MemberServiceDBHelperStub(jdbcTemplate)
    MemberServiceDBHelperStub spyStub = Spy(memberServiceDBHelperStub)

    void setup() {
        service = new ChangeAssociationStatusService(apiRestClient, spyStub, cosmosFailedEventsWriter, gddnFailedEventCircuitBreaker)
        setField(service, "changeStatusEndpoint", "/statusChange")
    }

    @Unroll
    def "execute success path posts request with source=#source status=#status"() {
        given:
        def subscriber = buildSubscriber(ctn, status)

        when:
        service.execute(subscriber, source)

        then:
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(_, _) >> false
        1 * spyStub.getGuidForGivenCTN(ctn)
        1 * apiRestClient.sendPostRequest("/statusChange", { body ->
            assert body instanceof UserAssociationChangeRequest
            assert body.guid == expectedGuid
            assert body.associationList?.size() == 1
            assert body.associationList[0].instanceId == ctn
            assert body.associationList[0].serviceStatus == idgraphStatus
            true
        }, expectedEventName)
        0 * cosmosFailedEventsWriter.saveFailedEventsToCosmos(_)
        0 * _

        where:
        source              | ctn          | status      | expectedGuid | idgraphStatus | expectedEventName
        EventSource.GDDN    | "5551112222" | "ACTIVE"    | "G12345"     | "Enabled"     | ConsumerConstants.GridGddnNotification.EVENT_GDDN_RESTORE_SUBSCRIBER
        EventSource.GDDN    | "5553334444" | "SUSPENDED" | "G98765"     | "Suspended"   | ConsumerConstants.GridGddnNotification.EVENT_GDDN_SUSPEND_SUBSCRIBER
        EventSource.CG      | "5551112222" | "ACTIVE"    | "G12345"     | "Enabled"     | ConsumerConstants.GridGddnNotification.EVENT_CG_RESTORE_SUBSCRIBER
        EventSource.CG      | "5553334444" | "SUSPENDED" | "G98765"     | "Suspended"   | ConsumerConstants.GridGddnNotification.EVENT_CG_SUSPEND_SUBSCRIBER
    }

    @Unroll
    def "execute validation failure short circuits and saves failed event with source=#source"() {
        given:
        overrideValidatorFailure("VAL_ERR", "Phone missing")
        def subscriber = buildSubscriber(null, "ACTIVE")

        when:
        service.execute(subscriber, source)

        then:
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(_, expectedEventName) >> false
        0 * spyStub.getGuidForGivenCTN(_)
        0 * apiRestClient.sendPostRequest(_, _, _)
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
            assert it.errorDetails.toString().contains("VALIDATION_FAILED")
            assert it.eventName == expectedEventName
            true
        })
        0 * _

        where:
        source           | expectedEventName
        EventSource.GDDN | ConsumerConstants.GridGddnNotification.EVENT_GDDN_RESTORE_SUBSCRIBER
        EventSource.CG   | ConsumerConstants.GridGddnNotification.EVENT_CG_RESTORE_SUBSCRIBER
    }

    def "execute guid lookup returns null -> no post no failed event"() {
        given:
        def ctn = "5550000000"
        def subscriber = buildSubscriber(ctn, "ACTIVE")

        when:
        service.execute(subscriber, EventSource.GDDN)

        then:
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(_, _) >> false
        1 * spyStub.getGuidForGivenCTN(ctn) >> Optional.empty()
        0 * apiRestClient.sendPostRequest(_, _, _)
        0 * cosmosFailedEventsWriter.saveFailedEventsToCosmos(_)
        0 * _
    }

    def "execute guid lookup returns blank -> no post no failed event"() {
        given:
        def ctn = "5559999999"
        def subscriber = buildSubscriber(ctn, "ACTIVE")

        when:
        service.execute(subscriber, EventSource.CG)

        then:
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(_, _) >> false
        1 * spyStub.getGuidForGivenCTN(ctn) >> Optional.of("")
        0 * apiRestClient.sendPostRequest(_, _, _)
        0 * cosmosFailedEventsWriter.saveFailedEventsToCosmos(_)
        0 * _
    }

    @Unroll
    def "execute exception during guid lookup -> failed event saved with correct category for source=#source"() {
        given:
        def ctn = "5557777777"
        def subscriber = buildSubscriber(ctn, "ACTIVE")

        when:
        service.execute(subscriber, source)

        then:
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(_, expectedEventName) >> false
        1 * spyStub.getGuidForGivenCTN(ctn) >> { throw new RuntimeException("DB down") }
        0 * apiRestClient.sendPostRequest(_, _, _)
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ FailedEventDetails details ->
            assert details.eventName == expectedEventName
            assert details.eventCategory == expectedCategory
            true
        })
        0 * _

        where:
        source           | expectedEventName                                                   | expectedCategory
        EventSource.GDDN | ConsumerConstants.GridGddnNotification.EVENT_GDDN_RESTORE_SUBSCRIBER | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_SUBSCRIBER
        EventSource.CG   | ConsumerConstants.GridGddnNotification.EVENT_CG_RESTORE_SUBSCRIBER   | ConsumerConstants.GridGddnNotification.CATEGORY_CG_SUBSCRIBER
    }

    @Unroll
    def "circuit breaker open -> saves CIRCUIT_OPEN event without calling downstream for source=#source"() {
        given:
        def ctn = "5558888888"
        def subscriber = buildSubscriber(ctn, "ACTIVE")

        when:
        service.execute(subscriber, source)

        then:
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(ctn, expectedEventName) >> true
        0 * spyStub.getGuidForGivenCTN(_)
        0 * apiRestClient.sendPostRequest(_, _, _)
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ FailedEventDetails details ->
            assert details.eventName == expectedEventName
            assert details.eventCategory == expectedCategory
            assert details.status == "CIRCUIT_OPEN"
            assert details.accountId == ctn
            true
        })
        0 * _

        where:
        source           | expectedEventName                                                   | expectedCategory
        EventSource.GDDN | ConsumerConstants.GridGddnNotification.EVENT_GDDN_RESTORE_SUBSCRIBER | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_SUBSCRIBER
        EventSource.CG   | ConsumerConstants.GridGddnNotification.EVENT_CG_RESTORE_SUBSCRIBER   | ConsumerConstants.GridGddnNotification.CATEGORY_CG_SUBSCRIBER
    }

    def "circuit breaker closed -> proceeds normally"() {
        given:
        def ctn = "5551112222"
        def subscriber = buildSubscriber(ctn, "ACTIVE")

        when:
        service.execute(subscriber, EventSource.GDDN)

        then:
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(ctn, ConsumerConstants.GridGddnNotification.EVENT_GDDN_RESTORE_SUBSCRIBER) >> false
        1 * spyStub.getGuidForGivenCTN(ctn)
        1 * apiRestClient.sendPostRequest("/statusChange", _, ConsumerConstants.GridGddnNotification.EVENT_GDDN_RESTORE_SUBSCRIBER)
        0 * cosmosFailedEventsWriter.saveFailedEventsToCosmos(_)
        0 * _
    }

    @Unroll
    def "validation failure saves event with correct eventCategory for source=#source"() {
        given:
        overrideValidatorFailure("VAL_ERR", "Phone missing")
        def subscriber = buildSubscriber(null, "ACTIVE")

        when:
        service.execute(subscriber, source)

        then:
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(_, expectedEventName) >> false
        0 * spyStub.getGuidForGivenCTN(_)
        0 * apiRestClient.sendPostRequest(_, _, _)
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ FailedEventDetails details ->
            assert details.eventCategory == expectedCategory
            assert details.eventName == expectedEventName
            assert details.errorDetails.toString().contains("VALIDATION_FAILED")
            true
        })
        0 * _

        where:
        source           | expectedEventName                                                   | expectedCategory
        EventSource.GDDN | ConsumerConstants.GridGddnNotification.EVENT_GDDN_RESTORE_SUBSCRIBER | ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_SUBSCRIBER
        EventSource.CG   | ConsumerConstants.GridGddnNotification.EVENT_CG_RESTORE_SUBSCRIBER   | ConsumerConstants.GridGddnNotification.CATEGORY_CG_SUBSCRIBER
    }

    private static Subscriber buildSubscriber(String phone, String status) {
        def s = new Subscriber()
        s.phoneNumber = phone
        s.status = status
        return s
    }

    private static void setField(Object target, String name, Object value) {
        def f = target.class.getDeclaredField(name)
        f.accessible = true
        f.set(target, value)
    }

    private void overrideValidatorSuccess() {
        restoreValidator()
        RequestValidator.metaClass.'static'.validate = { String v, String f ->
            [(MPSDefs.APP_STATUS_CODE): CommonDefs.COMMON_SUCCESS,
             (MPSDefs.APP_STATUS_MSG) : "OK"]
        }
    }

    private void overrideValidatorFailure(String code, String msg) {
        restoreValidator()
        RequestValidator.metaClass.'static'.validate = { String v, String f ->
            [(MPSDefs.APP_STATUS_CODE): code,
             (MPSDefs.APP_STATUS_MSG) : msg]
        }
    }

    private void restoreValidator() {
        GroovySystem.metaClassRegistry.removeMetaClass(RequestValidator)
    }
}
