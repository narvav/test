package com.att.idp.idgraphconsumerms.helpers

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.http.HttpEntity
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatusCode
import org.springframework.http.ResponseEntity
import org.springframework.web.client.HttpClientErrorException
import org.springframework.web.client.HttpServerErrorException
import org.springframework.web.client.RestTemplate
import spock.lang.Specification

class CloseAccountPasscodeProcessorSpec extends Specification {

    def restTemplate = Mock(RestTemplate)
    def cosmosFailedEventsWriter = Mock(CosmosFailedEventsWriter)
    def objectMapper = new ObjectMapper()
    def gddnFailedEventCircuitBreaker = Mock(GddnFailedEventCircuitBreaker)

    def processor = new CloseAccountPasscodeProcessor(restTemplate, cosmosFailedEventsWriter, objectMapper, gddnFailedEventCircuitBreaker)

    def setup() {
        processor.userAssoServerUrl = "http://test-server"
        processor.uaCredEndpoint = "/msapi/idgraph/idgraphuserassociationms/v1/credentials"
        processor.userName = "testUser"
        processor.userPassword = "testPassword"
        // Circuit breaker returns false by default (circuit closed)
        gddnFailedEventCircuitBreaker.shouldShortCircuit(_, _) >> false
    }

    private String buildEventPayload(String state, String serviceType, String accountId) {
        def accountObj = [:]
        if (accountId != null) accountObj.id = accountId
        if (state != null) accountObj.state = state
        if (serviceType != null) accountObj.serviceType = serviceType

        def event = [
                eventId   : "BillingAccountStateChangeEvent-test-123",
                eventType : "BillingAccountStateChangeEvent",
                eventTime : "2022-03-10 14:38:53.185",
                resourceName: "Account",
                event     : [
                        name              : "BillingAccountStateChange",
                        type              : "BillingAccountStateChangeEvent",
                        resourceVersion   : "1",
                        resourceIdentifier: "Account",
                        account           : objectMapper.writeValueAsString(accountObj)
                ]
        ]
        return objectMapper.writeValueAsString(event)
    }

    def "should call deleteCredentials with BSSEWIRELESS when serviceType is Wireless"() {
        given:
        def payload = buildEventPayload("closed", "Wireless", "556331445652")
        def responseEntity = new ResponseEntity<JsonNode>(HttpStatusCode.valueOf(200))

        when:
        def result = processor.process(payload)

        then:
        1 * restTemplate.exchange(
                { String url -> url.contains("accountType=BSSEWIRELESS") && url.contains("556331445652") },
                HttpMethod.DELETE,
                _ as HttpEntity,
                JsonNode.class
        ) >> responseEntity
        result == true
        0 * cosmosFailedEventsWriter._
    }

    def "should call deleteCredentials with BSSEFIBER when serviceType is Fiber"() {
        given:
        def payload = buildEventPayload("closed", "Fiber", "556331445652")
        def responseEntity = new ResponseEntity<JsonNode>(HttpStatusCode.valueOf(200))

        when:
        def result = processor.process(payload)

        then:
        1 * restTemplate.exchange(
                { String url -> url.contains("accountType=BSSEFIBER") && url.contains("556331445652") },
                HttpMethod.DELETE,
                _ as HttpEntity,
                JsonNode.class
        ) >> responseEntity
        result == true
        0 * cosmosFailedEventsWriter._
    }

    def "should skip processing when state is not closed"() {
        given:
        def payload = buildEventPayload("defined", "Wireless", "556331445652")

        when:
        def result = processor.process(payload)

        then:
        0 * restTemplate._
        0 * cosmosFailedEventsWriter._
        result == false
    }

    def "should skip processing when eventType is not BillingAccountStateChangeEvent"() {
        given:
        def event = [
                eventId  : "test-event",
                eventType: "SomeOtherEvent",
                event    : [
                        name   : "Other",
                        account: '{"id":"123","state":"closed","serviceType":"Wireless"}'
                ]
        ]
        def payload = objectMapper.writeValueAsString(event)

        when:
        def result = processor.process(payload)

        then:
        0 * restTemplate._
        0 * cosmosFailedEventsWriter._
        result == false
    }

    def "should skip processing when serviceType is unknown"() {
        given:
        def payload = buildEventPayload("closed", "UnknownType", "556331445652")

        when:
        def result = processor.process(payload)

        then:
        0 * restTemplate._
        0 * cosmosFailedEventsWriter._
        result == false
    }

    def "should skip processing when serviceType is null"() {
        given:
        def payload = buildEventPayload("closed", null, "556331445652")

        when:
        def result = processor.process(payload)

        then:
        0 * restTemplate._
        0 * cosmosFailedEventsWriter._
        result == false
    }

    def "should skip processing when accountId is missing"() {
        given:
        def payload = buildEventPayload("closed", "Wireless", null)

        when:
        def result = processor.process(payload)

        then:
        0 * restTemplate._
        0 * cosmosFailedEventsWriter._
        result == false
    }

    def "should save failed event to Cosmos when deleteCredentials throws non-retryable exception"() {
        given:
        def payload = buildEventPayload("closed", "Wireless", "556331445652")

        when:
        def result = processor.process(payload)

        then:
        1 * restTemplate.exchange(_, HttpMethod.DELETE, _, JsonNode.class) >> {
            throw new HttpClientErrorException(HttpStatusCode.valueOf(400))
        }
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
            it.accountId == "556331445652" &&
                    it.eventName == ConsumerConstants.BsseMigration.EVENT_CG_INDI_ACCT_CLOSE &&
                    it.errorDetails != null
        })
        result == true
    }

    def "should handle malformed account JSON gracefully"() {
        given:
        def event = [
                eventId  : "test-event",
                eventType: "BillingAccountStateChangeEvent",
                event    : [
                        name   : "BillingAccountStateChange",
                        account: "not-valid-json{"
                ]
        ]
        def payload = objectMapper.writeValueAsString(event)

        when:
        def result = processor.process(payload)

        then:
        0 * restTemplate._
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
            it.eventName == ConsumerConstants.BsseMigration.EVENT_CG_INDI_ACCT_CLOSE
        })
        result == false
    }

    def "should handle completely malformed event JSON gracefully"() {
        given:
        def payload = "this-is-not-json"

        when:
        def result = processor.process(payload)

        then:
        0 * restTemplate._
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
            it.eventName == ConsumerConstants.BsseMigration.EVENT_CG_INDI_ACCT_CLOSE
        })
        result == false
    }

    def "should call recoverDeleteCredentials and save failed event after retries exhausted"() {
        given:
        def exception = new HttpServerErrorException(HttpStatusCode.valueOf(500), "Internal Server Error")

        when:
        processor.recoverDeleteCredentials(exception, "BSSEWIRELESS", "556331445652", '{"test":"payload"}')

        then:
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
            it.accountId == "556331445652" &&
                    it.eventName == ConsumerConstants.BsseMigration.EVENT_CG_INDI_ACCT_CLOSE &&
                    it.requestPayload == '{"test":"payload"}'
        })
    }
}
