package com.att.idp.idgraphconsumerms.kafka.dmctn.service

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker
import com.att.idp.idgraphconsumerms.kafka.model.AccountNotificationEvent
import com.att.idp.idgraphconsumerms.model.SorOrchestrationRequest
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import spock.lang.Unroll
import com.att.idp.idgraphconsumerms.oracle.helpers.MemberServiceDBHelper


class OrchestrationWirelessServiceTest extends Specification {

    OrchestrationWirelessApiRestClient apiRestClient
    MemberServiceDBHelper memberServiceDBHelper
    CosmosFailedEventsWriter cosmosFailedEventsWriter
    OrchestrationWirelessService serviceUnderTest

    void setup() {
        apiRestClient = Mock(OrchestrationWirelessApiRestClient)
        memberServiceDBHelper = Mock(MemberServiceDBHelper)
        cosmosFailedEventsWriter = Mock(CosmosFailedEventsWriter)
        serviceUnderTest = new OrchestrationWirelessService(apiRestClient, memberServiceDBHelper)
        ReflectionTestUtils.setField(serviceUnderTest, "cosmosFailedEventsWriter", cosmosFailedEventsWriter)
        ReflectionTestUtils.setField(serviceUnderTest, "wirelessEndpoint", "/mock/wireless")
        def circuitBreaker = Stub(GddnFailedEventCircuitBreaker) { shouldShortCircuit(_, _) >> false }
        ReflectionTestUtils.setField(serviceUnderTest, "gddnFailedEventCircuitBreaker", circuitBreaker)
    }

    @Unroll
    def "should call API with correct request for #scenarioName"() {
        given: "A valid AccountNotificationEvent"
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setBillingAccountNumber(ban)
        event.setContactEmail(contactEmail)
        event.setFirstName(firstName)
        event.setLastName(lastName)
        event.setEventName("ActivateAccount")

        when: "execute is called"
        serviceUnderTest.execute(event)

        then: "API client is called with correct request"
        1 * apiRestClient.sendPostRequest("/mock/wireless", { SorOrchestrationRequest req ->
            req.sorInvariantId == ban &&
            req.contactEmail == contactEmail &&
            req.sorId == ConsumerConstants.AccountNotificationConstants.SOR_ID_13 &&
            req.firstName == firstName &&
            req.lastName == lastName &&
            req.serviceName == ConsumerConstants.AccountNotificationConstants.MOBILITY
        }, "GDDNActivateAccount")
        0 * _

        where:
        scenarioName      | ban        | contactEmail         | firstName | lastName
        "valid input"     | "BAN123"  | "test@email.com"    | "John"    | "Doe"
    }

    @Unroll
    def "should save failed event and not call API when exception for #scenarioName"() {
        given: "AccountNotificationEvent and API throws exception"
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setBillingAccountNumber(ban)
        event.setContactEmail(contactEmail)
        event.setFirstName(firstName)
        event.setLastName(lastName)
        event.setEventName("ActivateAccount")
        RuntimeException exception = new RuntimeException("API error")

        when: "execute is called"
        serviceUnderTest.execute(event)

        then: "API client throws, failed event processor is called"
        1 * apiRestClient.sendPostRequest("/mock/wireless", { SorOrchestrationRequest req ->
            req.sorInvariantId == ban &&
            req.contactEmail == contactEmail &&
            req.sorId == ConsumerConstants.AccountNotificationConstants.SOR_ID_13 &&
            req.firstName == firstName &&
            req.lastName == lastName &&
            req.serviceName == ConsumerConstants.AccountNotificationConstants.MOBILITY
        }, "GDDNActivateAccount") >> { throw exception }
        1 * cosmosFailedEventsWriter._
        0 * _

        where:
        scenarioName      | ban        | contactEmail         | firstName | lastName
        "api exception"   | "BAN123"  | "fail@email.com"    | "Jane"    | "Smith"
    }

    def "should short-circuit to Cosmos when circuit breaker is OPEN"() {
        given: "Circuit breaker returns true (pending failed events exist)"
        def openCircuitBreaker = Stub(GddnFailedEventCircuitBreaker) {
            shouldShortCircuit("BAN-CB", _) >> true
        }
        ReflectionTestUtils.setField(serviceUnderTest, "gddnFailedEventCircuitBreaker", openCircuitBreaker)

        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setBillingAccountNumber("BAN-CB")
        event.setEventName("SubscriberChangeEvent")
        event.setContactEmail("cb@email.com")
        event.setFirstName("Circuit")
        event.setLastName("Breaker")

        when:
        serviceUnderTest.execute(event)

        then: "API client is never called"
        0 * apiRestClient._
        0 * memberServiceDBHelper._

        and: "Failed event is saved to Cosmos with circuit breaker message"
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ it.accountId == "BAN-CB" &&
                it.eventName == "SubscriberChangeEvent" })
        0 * _
    }
}

