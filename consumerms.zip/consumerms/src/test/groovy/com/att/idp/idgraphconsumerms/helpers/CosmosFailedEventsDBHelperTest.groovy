package com.att.idp.idgraphconsumerms.helpers


import com.att.idp.idgraph.db.cosmos.entity.IdgraphFailedEvents
import com.att.idp.idgraph.db.cosmos.helper.CosmosFailedEventsDBHelper
import com.att.idp.idgraph.db.cosmos.repository.IdgraphFailedEventsRepository
import com.azure.cosmos.implementation.ServiceUnavailableException
import org.slf4j.Logger
import spock.lang.Specification
import spock.lang.Subject
import org.springframework.retry.annotation.Retryable

class CosmosFailedEventsDBHelperTest extends Specification {

    def idgraphFailedEventsRepository = Mock(IdgraphFailedEventsRepository)
    @Subject
    def cosmosFailedEventsDBHelper = new CosmosFailedEventsDBHelper(idgraphFailedEventsRepository: idgraphFailedEventsRepository)

    def "test addFailedEvents retries on ServiceUnavailableException"() {
        given:
        def failedEvent = new IdgraphFailedEvents()
        def errorMessage = "Error occurred"

        when:
        cosmosFailedEventsDBHelper.addFailedEvents(failedEvent, errorMessage)

        then:
        1 * idgraphFailedEventsRepository.save(failedEvent) >> { throw new ServiceUnavailableException() }
        thrown(ServiceUnavailableException)
    }

}