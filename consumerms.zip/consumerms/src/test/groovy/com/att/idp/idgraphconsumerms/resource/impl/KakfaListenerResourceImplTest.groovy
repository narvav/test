package com.att.idp.idgraphconsumerms.resource.impl

import com.att.idp.idgraphconsumerms.kafka.KafkaListenerAutomation
import spock.lang.Specification

import jakarta.ws.rs.core.Response

class KakfaListenerResourceImplTest extends Specification {

	def kafkaListenerAutomation = Mock(KafkaListenerAutomation)
	def kakfaListenerResourceImpl = new KakfaListenerResourceImpl()

	def setup() {
		kakfaListenerResourceImpl.kafkaListenerAutomation = kafkaListenerAutomation
	}

	def "test start method with valid listenerId"() {
		given:
		def listenerId = "testListener"

		when:
		def response = kakfaListenerResourceImpl.start(listenerId)

		then:
		1 * kafkaListenerAutomation.startListener(listenerId)
		response.status == Response.Status.OK.statusCode
		response.entity == "Started kafka listener successfully"
	}

	def "test stop method with valid listenerId"() {
		given:
		def listenerId = "testListener"

		when:
		def response = kakfaListenerResourceImpl.stop(listenerId)

		then:
		1 * kafkaListenerAutomation.stopListener(listenerId)
		response.status == Response.Status.OK.statusCode
		response.entity == "Stopped kafka listener successfully"
	}
}