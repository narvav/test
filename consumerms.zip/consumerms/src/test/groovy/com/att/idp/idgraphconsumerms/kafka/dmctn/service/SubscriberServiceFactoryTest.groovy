package com.att.idp.idgraphconsumerms.kafka.dmctn.service;

import spock.lang.Specification;
import spock.lang.Unroll;

/**
 * Unit tests for {@link SubscriberServiceFactory} covering all event type branches
 * including unknown, blank, and null (exception) scenarios.
 */
class SubscriberServiceFactoryTest extends Specification {

    ChangeAssociationStatusService changeAssociationStatusService
    ChangeAssociationDataService changeAssociationDataService
    RemoveAssociationService removeAssociationService
    SubscriberServiceFactory subscriberServiceFactory

    def setup() {
        changeAssociationStatusService = Mock(ChangeAssociationStatusService)
        changeAssociationDataService = Mock(ChangeAssociationDataService)
        removeAssociationService = Mock(RemoveAssociationService)
        subscriberServiceFactory = new SubscriberServiceFactory()
        // Inject mocks into private fields via Groovy reflection
        subscriberServiceFactory.@changeAssociationStatusService = changeAssociationStatusService
        subscriberServiceFactory.@changeAssociationDataService = changeAssociationDataService
        subscriberServiceFactory.@removeAssociationService = removeAssociationService
    }

    @Unroll
    def "should return expected service for #scenarioName"() {
        given: "A specific event type to resolve to a backend service"
        String eventTypeValue = eventType

        when: "Factory getService is invoked"
        BackendService result = subscriberServiceFactory.getService(eventTypeValue)

        then: "Returned service matches expected mapping and no other interactions occur"
        // No method calls are expected on mocks within factory logic
        0 * _

        and: "Result validation for each scenario"
        if (expectedCategory == "status") {
            assert result == changeAssociationStatusService
        } else if (expectedCategory == "data") {
            assert result == changeAssociationDataService
        } else if (expectedCategory == "remove") {
            assert result == removeAssociationService
        } else if (expectedCategory == "none") {
            assert result == null
        } else {
            assert false: "Unexpected expectedCategory value: " + expectedCategory
        }

        where: "Different event type scenarios including case-insensitive matches and unknown"
        scenarioName                | eventType               | expectedCategory
        "RestoreSubscriber exact"  | "RestoreSubscriber"     | "status"
        "SuspendSubscriber mixed"  | "sUsPeNdSuBsCrIbEr"     | "status"
        "ChangeData exact"         | "ChangeData"            | "data"
        "CancelSubscriber exact"   | "CancelSubscriber"      | "remove"
        "Blank event type"         | ""                      | "none"
        "Unknown event type"       | "NotHandledEventType"   | "none"
    }

    def "should throw NullPointerException for null eventType"() {
        given: "Null event type input"
        String eventTypeValue = null

        when: "Factory getService is invoked with null"
        subscriberServiceFactory.getService(eventTypeValue)

        then: "NullPointerException is thrown before any interactions"
        0 * _
        NullPointerException ex = thrown()
        ex != null
    }
}
