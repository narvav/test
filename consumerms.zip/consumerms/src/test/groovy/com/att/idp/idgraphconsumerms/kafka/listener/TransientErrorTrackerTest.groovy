package com.att.idp.idgraphconsumerms.kafka.listener

import spock.lang.Specification

class TransientErrorTrackerTest extends Specification {

    def "T-LCM-1: Below threshold — errors recorded but threshold not breached"() {
        given: "A tracker with threshold 3 and window 60s"
        TransientErrorTracker tracker = new TransientErrorTracker(60, 3)

        when: "2 errors are recorded"
        boolean breached1 = tracker.recordErrorAndCheckThreshold()
        boolean breached2 = tracker.recordErrorAndCheckThreshold()

        then: "Threshold is not breached"
        !breached1
        !breached2
        tracker.currentCount() == 2
        0 * _
    }

    def "T-LCM-2: Threshold breached — returns true when count reaches threshold"() {
        given: "A tracker with threshold 3"
        TransientErrorTracker tracker = new TransientErrorTracker(60, 3)

        when: "3 errors are recorded"
        tracker.recordErrorAndCheckThreshold()
        tracker.recordErrorAndCheckThreshold()
        boolean breached = tracker.recordErrorAndCheckThreshold()

        then: "Threshold is breached on 3rd error"
        breached
        0 * _
    }

    def "T-LCM-3: Sliding window — old errors evicted, count stays below threshold"() {
        given: "A tracker with 1-second window and threshold 3"
        TransientErrorTracker tracker = new TransientErrorTracker(1, 3)

        when: "2 errors, sleep past window, then 1 more error"
        tracker.recordErrorAndCheckThreshold()
        tracker.recordErrorAndCheckThreshold()
        Thread.sleep(1100)
        boolean breached = tracker.recordErrorAndCheckThreshold()

        then: "Old errors evicted, threshold not breached"
        !breached
        tracker.currentCount() == 1
        0 * _
    }

    def "T-LCM-5: Reset — after reset, count is zero"() {
        given: "A tracker with some errors recorded"
        TransientErrorTracker tracker = new TransientErrorTracker(60, 5)
        tracker.recordErrorAndCheckThreshold()
        tracker.recordErrorAndCheckThreshold()
        tracker.recordErrorAndCheckThreshold()

        when: "Tracker is reset"
        tracker.reset()

        then: "Count is zero"
        tracker.currentCount() == 0
        0 * _
    }
}
