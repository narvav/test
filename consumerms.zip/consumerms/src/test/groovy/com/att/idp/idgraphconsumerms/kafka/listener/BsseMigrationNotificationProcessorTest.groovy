package com.att.idp.idgraphconsumerms.kafka.listener

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosMigrationStatusDBHelper
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails

import com.att.idp.idgraphconsumerms.helpers.BsseMigrationServiceHelper
import com.att.idp.idgraphconsumerms.kafka.model.MigrationBANNotification
import com.att.idp.idgraphconsumerms.request.validator.MigrationBANNotificationRequestValidator
import com.att.mpsys.common.utils.MPSDefs
import com.att.mpsys.common.utils.CommonDefs
import spock.lang.Specification
import spock.lang.Unroll

class BsseMigrationNotificationProcessorTest extends Specification {

    MigrationBANNotificationRequestValidator requestValidator
    BsseMigrationServiceHelper processor
    CosmosFailedEventsWriter cosmosFailedEventsWriter
    CosmosMigrationStatusDBHelper cosmosMigrationStatusDBHelper
    BsseMigrationNotificationProcessor notificationProcessor

    void setup() {
        requestValidator = Mock(MigrationBANNotificationRequestValidator)
        processor = Mock(BsseMigrationServiceHelper)
        cosmosFailedEventsWriter = Mock(CosmosFailedEventsWriter)
        cosmosMigrationStatusDBHelper = Mock(CosmosMigrationStatusDBHelper)
        notificationProcessor = new BsseMigrationNotificationProcessor(requestValidator, processor, cosmosFailedEventsWriter, cosmosMigrationStatusDBHelper)
    }

    @Unroll
    def "should store status and skip processing for non-matching event for #scenarioName"() {
        given: "A MigrationBANNotification with non-matching eventType, subStatus, status, or replayFlag"
        MigrationBANNotification payload = new MigrationBANNotification()
        payload.setEventType(eventType)
        payload.setSubStatus(subStatus)
        payload.setStatus(status)
        payload.setReplayFlag(replayFlag)
        String rawMsg = "{\"event_type\":\"MigrationBanNotification\",\"migration_id\":\"test-mig-123\",\"source_ban_id\":\"1234567890\",\"target_ba_id\":\"9876543210\",\"status\":\"Inflight_PONR\",\"sub_status\":\"Request_ALL_Commit_To_Target\",\"replay_flag\":\"N\"}"
        String traceId = "trace-123"
        String listenerName = "Listener"

        when: "processNotification is called"
        notificationProcessor.processNotification(payload, rawMsg, traceId, listenerName)

        then: "Status is stored and no further processing occurs"
        1 * cosmosMigrationStatusDBHelper.storeBSSEMigrationStatus(payload, rawMsg)
        0 * requestValidator._
        0 * processor._
        0 * cosmosFailedEventsWriter._
        0 * _

        where:
        scenarioName                | eventType                                              | subStatus                                              | status                                              | replayFlag
        "wrong eventType"           | "OtherEvent"                                          | ConsumerConstants.BsseMigration.SUB_STATUS_COMMIT_ALL  | ConsumerConstants.BsseMigration.STATUS_INFLIGHT_PONR | "N"
        "wrong subStatus"           | ConsumerConstants.BsseMigration.MIGRATION_BAN_NOTIFICATION | "OtherSubStatus"                                 | ConsumerConstants.BsseMigration.STATUS_INFLIGHT_PONR | "N"
        "wrong status"              | ConsumerConstants.BsseMigration.MIGRATION_BAN_NOTIFICATION | ConsumerConstants.BsseMigration.SUB_STATUS_COMMIT_ALL | "OtherStatus"                                  | "N"
        "replay flag Y"             | ConsumerConstants.BsseMigration.MIGRATION_BAN_NOTIFICATION | ConsumerConstants.BsseMigration.SUB_STATUS_COMMIT_ALL | ConsumerConstants.BsseMigration.STATUS_INFLIGHT_PONR | "Y"
    }

    @Unroll
    def "should validate, call credentials, and process migration for valid event with passcode for #scenarioName"() {
        given: "A valid MigrationBANNotification with passcodeVenc"
        MigrationBANNotification payload = new MigrationBANNotification()
        payload.setEventType(ConsumerConstants.BsseMigration.MIGRATION_BAN_NOTIFICATION)
        payload.setSubStatus(ConsumerConstants.BsseMigration.SUB_STATUS_COMMIT_ALL)
        payload.setStatus(ConsumerConstants.BsseMigration.STATUS_INFLIGHT_PONR)
        payload.setReplayFlag("N")
        payload.setPasscodeVenc(passcodeVenc)
        String rawMsg = "{\"event_type\":\"MigrationBanNotification\",\"migration_id\":\"test-mig-456\",\"source_ban_id\":\"1234567890\",\"target_ba_id\":\"9876543210\",\"status\":\"Inflight_PONR\",\"sub_status\":\"Request_ALL_Commit_To_Target\",\"replay_flag\":\"N\",\"passcode_venc\":\"testPasscode\"}"
        String traceId = "trace-123"
        String listenerName = "Listener"
        Map<String, Object> validationResult = [(MPSDefs.APP_STATUS_CODE): CommonDefs.COMMON_SUCCESS]
        requestValidator.validateMessage(payload) >> validationResult

        when: "processNotification is called"
        notificationProcessor.processNotification(payload, rawMsg, traceId, listenerName)

        then: "Status is stored, credentials and migration service are called"
        1 * cosmosMigrationStatusDBHelper.storeBSSEMigrationStatus(payload, rawMsg)
        1 * requestValidator.validateMessage(payload) >> validationResult
        1 * processor.callBSSEMigrationService(payload)
        0 * cosmosFailedEventsWriter._
        0 * _

        where:
        scenarioName         | passcodeVenc
        "with passcodeVenc" | "some-passcode"
        "without passcode"  | null
    }

    @Unroll
    def "should save failed event with correct accountType and eventName on validation failure for #scenarioName"() {
        given: "A valid MigrationBANNotification with failed validation and serviceType"
        MigrationBANNotification payload = new MigrationBANNotification()
        payload.setEventType(ConsumerConstants.BsseMigration.MIGRATION_BAN_NOTIFICATION)
        payload.setSubStatus(ConsumerConstants.BsseMigration.SUB_STATUS_COMMIT_ALL)
        payload.setStatus(ConsumerConstants.BsseMigration.STATUS_INFLIGHT_PONR)
        payload.setReplayFlag("N")
        payload.setSourceBanId("1234567890")
        payload.setServiceType(serviceType)
        String rawMsg = "{\"event_type\":\"MigrationBanNotification\",\"migration_id\":\"test-mig-789\",\"source_ban_id\":\"1234567890\",\"target_ba_id\":\"9876543210\",\"status\":\"Inflight_PONR\",\"sub_status\":\"Request_ALL_Commit_To_Target\",\"replay_flag\":\"N\"}"
        String traceId = "trace-123"
        String listenerName = "Listener"
        Map<String, Object> validationResult = [(MPSDefs.APP_STATUS_CODE): "FAIL", (MPSDefs.APP_STATUS_MSG): "Invalid"]
        requestValidator.validateMessage(payload) >> validationResult

        when: "processNotification is called"
        notificationProcessor.processNotification(payload, rawMsg, traceId, listenerName)

        then: "Status is stored, failed event is saved with correct accountType and eventName"
        1 * cosmosMigrationStatusDBHelper.storeBSSEMigrationStatus(payload, rawMsg)
        1 * requestValidator.validateMessage(payload) >> validationResult
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ FailedEventDetails fed ->
            fed.eventName == expectedEventName
        })

        where:
        scenarioName              | serviceType | expectedEventName
        "Fiber serviceType"       | "Fiber"     | "BSSEMigFiberForward"
        "fiber lowercase"         | "fiber"     | "BSSEMigFiberForward"
        "WIRELESS serviceType"    | "WIRELESS"  | "BSSEMigWireless"
        "null serviceType"        | null        | "BSSEMigWireless"
    }

    @Unroll
    def "should set sourceMarketCode to NA when serviceType is Fiber for #scenarioName"() {
        given: "A valid MigrationBANNotification with serviceType and an original sourceMarketCode"
        MigrationBANNotification payload = new MigrationBANNotification()
        payload.setEventType(ConsumerConstants.BsseMigration.MIGRATION_BAN_NOTIFICATION)
        payload.setSubStatus(ConsumerConstants.BsseMigration.SUB_STATUS_COMMIT_ALL)
        payload.setStatus(ConsumerConstants.BsseMigration.STATUS_INFLIGHT_PONR)
        payload.setReplayFlag("N")
        payload.setSourceBanId("1234567890")
        payload.setServiceType(serviceType)
        payload.setSourceMarketCode(originalMarketCode)
        String rawMsg = "{}"
        String traceId = "trace-123"
        String listenerName = "Listener"
        Map<String, Object> validationResult = [(MPSDefs.APP_STATUS_CODE): CommonDefs.COMMON_SUCCESS]
        requestValidator.validateMessage(payload) >> validationResult

        when: "processNotification is called"
        notificationProcessor.processNotification(payload, rawMsg, traceId, listenerName)

        then: "sourceMarketCode is set correctly"
        payload.getSourceMarketCode() == expectedMarketCode

        where:
        scenarioName                      | serviceType | originalMarketCode | expectedMarketCode
        "Fiber sets NA"                   | "Fiber"     | "AAA"              | "NA"
        "fiber lowercase sets NA"         | "fiber"     | "BBB"              | "NA"
        "WIRELESS keeps original"         | "WIRELESS"  | "CCC"              | "CCC"
        "null serviceType keeps original" | null        | "DDD"              | "DDD"
    }
}

