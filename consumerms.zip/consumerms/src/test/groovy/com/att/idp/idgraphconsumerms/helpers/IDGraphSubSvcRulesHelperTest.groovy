package com.att.idp.idgraphconsumerms.helpers

import spock.lang.Specification
import spock.lang.Unroll

class IDGraphSubSvcRulesHelperTest extends Specification {

    IDGraphSubSvcRulesHelper helper

    void setup() {
        helper = new IDGraphSubSvcRulesHelper()
    }

    def "should validate LSRegNotify event for SUBSVC"() {
        given:
        Map<String, Object> event = [
                eventname: "LSRegNotify",
                ban: "VD0017554",
                handle: "qay_geetha_1751",
                domain: "att.net"
        ]

        when:
        boolean result = helper.processSubSvcMessage(event)

        then:
        result
        0 * _
    }

    def "should transform LSRegNotify event to SUBSVC payload"() {
        given:
        String callingSystemId = "SDP"
        Map<String, Object> event = [
                eventname: "LSRegNotify",
                ban: "VD0017554",
                handle: "qay_geetha_1751",
                domain: "att.net",
                registrationDate: "260427194659",
                idpTraceId: "c5afc061f701458e:c5afc061f701458e:0:1",
                callingSystemId: callingSystemId
        ]

        when:
        HashMap<String, Object> payload = helper.transformToSubSvcPayload(event)
        List<Map<String, Object>> eventDetails = (List<Map<String, Object>>) payload.get("eventDetails")

        then:
        payload.get("eventId") == "IdgraphSubSvcMs-c5afc061f701458e:c5afc061f701458e:0:1"
        payload.get("eventType") == "SubscriptionService"
        payload.get("eventTime") != null
        eventDetails.size() == 2
        eventDetails.get(0).get("category") == "UpdateMemberAsync"
        eventDetails.get(0).get("ban") == "VD0017554"
        eventDetails.get(0).get("clientId") == callingSystemId
        eventDetails.get(0).get("transactionName") == "UpdateSubscriber"
        eventDetails.get(0).get("callingSystemId") == callingSystemId
        eventDetails.get(0).get("memberId") == "qay_geetha_1751@att.net"
        eventDetails.get(1).get("category") == "AddUser"
        eventDetails.get(1).get("clientId") == callingSystemId
        eventDetails.get(1).get("transactionName") == "AddUser"
        eventDetails.get(1).get("callingSystemId") == callingSystemId
        eventDetails.get(1).get("memberId") == "qay_geetha_1751@att.net"

        List<Map<String, String>> attributes = (List<Map<String, String>>) eventDetails.get(1).get("attributes")
        attributes.size() == 15
        attributes.find { it.get("attributeName") == "PERMISSIONANONYMOUSCALLREJECTIONIND" }.get("attributeValue") == "Y"
        attributes.find { it.get("attributeName") == "PERMISSIONDONOTDISTURBIND" }.get("attributeValue") == "Y"
        attributes.find { it.get("attributeName") == "PERMISSIONCALLFORWARDUNREGISTEREDIND" }.get("attributeValue") == "Y"
        attributes.find { it.get("attributeName") == "PERMISSIONCALLFORWARDNOANSWERIND" }.get("attributeValue") == "Y"
        attributes.find { it.get("attributeName") == "PERMISSIONCALLFORWARDINGIND" }.get("attributeValue") == "Y"
        attributes.find { it.get("attributeName") == "PERMISSIONPUBLISHSUBSCRIBERIND" }.get("attributeValue") == "Y"
        attributes.find { it.get("attributeName") == "ADDRESSBOOKIND" }.get("attributeValue") == "N"
        attributes.find { it.get("attributeName") == "USERSTATUS" }.get("attributeValue") == "ACTIVE"
        attributes.find { it.get("attributeName") == "PERMISSIONCALLFORWARDALLIND" }.get("attributeValue") == "Y"
        attributes.find { it.get("attributeName") == "PERMISSIONCALLFORWARDBUSYIND" }.get("attributeValue") == "Y"
        attributes.find { it.get("attributeName") == "PERMISSIONSIMULTANEOUSRINGIND" }.get("attributeValue") == "Y"
        attributes.find { it.get("attributeName") == "PERMISSIONCALLACCEPTANCEIND" }.get("attributeValue") == "Y"
        attributes.find { it.get("attributeName") == "PRIMARYMEMBERIND" }.get("attributeValue") == "Y"
        attributes.find { it.get("attributeName") == "PERMISSIONCALLREJECTIND" }.get("attributeValue") == "Y"
        attributes.find { it.get("attributeName") == "PERMISSIONAUTOATTENDANTIND" }.get("attributeValue") == "Y"
        0 * _
    }

    def "should reject SUBSVC event when required fields are missing"() {
        given:
        Map<String, Object> event = [eventname: "LSRegNotify", handle: "qay_geetha_1751"]

        when:
        boolean result = helper.processSubSvcMessage(event)

        then:
        !result
        0 * _
    }

    def "should reject SUBSVC event when event map is null"() {
        given:
        Map<String, Object> event = null

        when:
        boolean result = helper.processSubSvcMessage(event)

        then:
        !result
        0 * _
    }

    def "should reject SUBSVC event when event map is empty"() {
        given:
        Map<String, Object> event = [:]

        when:
        boolean result = helper.processSubSvcMessage(event)

        then:
        !result
        0 * _
    }

    def "should reject SUBSVC event when eventname is not LSRegNotify"() {
        given:
        Map<String, Object> event = [
                eventname: "AddMember",
                ban: "VD0017554",
                handle: "qay_geetha_1751",
                domain: "att.net"
        ]

        when:
        boolean result = helper.processSubSvcMessage(event)

        then:
        !result
        0 * _
    }

    def "should reject SUBSVC event when ban is blank"() {
        given:
        Map<String, Object> event = [
                eventname: "LSRegNotify",
                ban: "",
                handle: "qay_geetha_1751",
                domain: "att.net"
        ]

        when:
        boolean result = helper.processSubSvcMessage(event)

        then:
        !result
        0 * _
    }

    def "should validate SUBSVC event when handle contains @ without domain"() {
        given:
        Map<String, Object> event = [
                eventname: "LSRegNotify",
                ban: "VD0017554",
                handle: "qay_geetha_1751@att.net"
        ]

        when:
        boolean result = helper.processSubSvcMessage(event)

        then:
        result
        0 * _
    }

    def "should resolve memberId from handle when handle contains @"() {
        given:
        Map<String, Object> event = [
                eventname: "LSRegNotify",
                ban: "VD0017554",
                handle: "qay_geetha_1751@bellsouth.net",
                domain: "att.net",
                registrationDate: "260427194659",
                idpTraceId: "trace-123",
                callingSystemId: "BBNMS"
        ]

        when:
        HashMap<String, Object> payload = helper.transformToSubSvcPayload(event)
        List<Map<String, Object>> eventDetails = (List<Map<String, Object>>) payload.get("eventDetails")

        then:
        eventDetails.get(0).get("memberId") == "qay_geetha_1751@bellsouth.net"
        eventDetails.get(1).get("memberId") == "qay_geetha_1751@bellsouth.net"
        0 * _
    }

    def "should not include attributes on UpdateMemberAsync event detail"() {
        given:
        Map<String, Object> event = [
                eventname: "LSRegNotify",
                ban: "VD0017554",
                handle: "qay_geetha_1751",
                domain: "att.net",
                registrationDate: "260427194659",
                idpTraceId: "trace-123",
                callingSystemId: "BBNMS"
        ]

        when:
        HashMap<String, Object> payload = helper.transformToSubSvcPayload(event)
        List<Map<String, Object>> eventDetails = (List<Map<String, Object>>) payload.get("eventDetails")

        then:
        eventDetails.get(0).get("attributes") == null
        eventDetails.get(1).get("attributes") != null
        0 * _
    }

    def "should set ADDRESSBOOKIND to N and all permission attributes to Y"() {
        given:
        Map<String, Object> event = [
                eventname: "LSRegNotify",
                ban: "VD0017554",
                handle: "qay_geetha_1751",
                domain: "att.net",
                registrationDate: "260427194659",
                idpTraceId: "trace-123",
                callingSystemId: "BBNMS"
        ]

        when:
        HashMap<String, Object> payload = helper.transformToSubSvcPayload(event)
        List<Map<String, Object>> eventDetails = (List<Map<String, Object>>) payload.get("eventDetails")
        List<Map<String, String>> attributes = (List<Map<String, String>>) eventDetails.get(1).get("attributes")

        then:
        attributes.find { it.get("attributeName") == "ADDRESSBOOKIND" }.get("attributeValue") == "N"
        attributes.findAll { it.get("attributeValue") == "Y" }.size() == 13
        attributes.findAll { it.get("attributeValue") == "N" }.size() == 1
        attributes.find { it.get("attributeName") == "USERSTATUS" }.get("attributeValue") == "ACTIVE"
        0 * _
    }

    def "should transform event with empty optional fields"() {
        given:
        Map<String, Object> event = [
                eventname: "LSRegNotify",
                ban: "VD0017554",
                handle: "qay_geetha_1751",
                domain: "att.net"
        ]

        when:
        HashMap<String, Object> payload = helper.transformToSubSvcPayload(event)
        List<Map<String, Object>> eventDetails = (List<Map<String, Object>>) payload.get("eventDetails")

        then:
        payload.get("eventId") == "IdgraphSubSvcMs-"
        payload.get("eventType") == "SubscriptionService"
        payload.get("eventTime") != null
        eventDetails.get(0).get("registrationDate") == ""
        eventDetails.get(0).get("callingSystemId") == ""
        eventDetails.get(1).get("attributes") != null
        ((List) eventDetails.get(1).get("attributes")).size() == 15
        0 * _
    }

    def "should reject SUBSVC event when handle is blank"() {
        given:
        Map<String, Object> event = [
                eventname: "LSRegNotify",
                ban: "VD0017554",
                handle: "",
                domain: "att.net"
        ]

        when:
        boolean result = helper.processSubSvcMessage(event)

        then:
        !result
        0 * _
    }

    def "should reject SUBSVC event when handle has no @ and domain is blank"() {
        given:
        Map<String, Object> event = [
                eventname: "LSRegNotify",
                ban: "VD0017554",
                handle: "qay_geetha_1751",
                domain: ""
        ]

        when:
        boolean result = helper.processSubSvcMessage(event)

        then:
        !result
        0 * _
    }

    def "should reject SUBSVC event when handle is null"() {
        given:
        Map<String, Object> event = [
                eventname: "LSRegNotify",
                ban: "VD0017554",
                handle: null,
                domain: "att.net"
        ]

        when:
        boolean result = helper.processSubSvcMessage(event)

        then:
        !result
        0 * _
    }

    def "should reject SUBSVC event when ban is null"() {
        given:
        Map<String, Object> event = [
                eventname: "LSRegNotify",
                ban: null,
                handle: "qay_geetha_1751",
                domain: "att.net"
        ]

        when:
        boolean result = helper.processSubSvcMessage(event)

        then:
        !result
        0 * _
    }

    def "should reject SUBSVC event when eventname is null"() {
        given:
        Map<String, Object> event = [
                eventname: null,
                ban: "VD0017554",
                handle: "qay_geetha_1751",
                domain: "att.net"
        ]

        when:
        boolean result = helper.processSubSvcMessage(event)

        then:
        !result
        0 * _
    }

    def "should resolve memberId as handle only when handle has no @ and domain is absent"() {
        given:
        Map<String, Object> event = [
                eventname: "LSRegNotify",
                ban: "VD0017554",
                handle: "qay_geetha_1751",
                registrationDate: "260427194659",
                idpTraceId: "trace-no-domain",
                callingSystemId: "IDP"
        ]

        when:
        HashMap<String, Object> payload = helper.transformToSubSvcPayload(event)
        List<Map<String, Object>> eventDetails = (List<Map<String, Object>>) payload.get("eventDetails")

        then:
        eventDetails.get(0).get("memberId") == "qay_geetha_1751"
        eventDetails.get(1).get("memberId") == "qay_geetha_1751"
        0 * _
    }

    def "should resolve memberId with handle and domain concatenation"() {
        given:
        Map<String, Object> event = [
                eventname: "LSRegNotify",
                ban: "VD0017554",
                handle: "qay_geetha_1751",
                domain: "bellsouth.net",
                registrationDate: "260427194659",
                idpTraceId: "trace-concat",
                callingSystemId: "IDP"
        ]

        when:
        HashMap<String, Object> payload = helper.transformToSubSvcPayload(event)
        List<Map<String, Object>> eventDetails = (List<Map<String, Object>>) payload.get("eventDetails")

        then:
        eventDetails.get(0).get("memberId") == "qay_geetha_1751@bellsouth.net"
        eventDetails.get(1).get("memberId") == "qay_geetha_1751@bellsouth.net"
        0 * _
    }

    def "should validate SUBSVC event when handle has no @ but domain is present"() {
        given:
        Map<String, Object> event = [
                eventname: "LSRegNotify",
                ban: "VD0017554",
                handle: "qay_geetha_1751",
                domain: "att.net"
        ]

        when:
        boolean result = helper.processSubSvcMessage(event)

        then:
        result
        0 * _
    }

    @Unroll
    def "processSubSvcMessage returns #expected for AddMemberList scenario #scenarioName"() {
        given:
        Map<String, Object> event = eventData

        when:
        boolean result = helper.processSubSvcMessage(event)

        then:
        result == expected
        0 * _

        where:
        scenarioName                                             | eventData                                                                                                                       || expected
        "Autogen subEvent accepted"                              | [eventname: "AddMemberList", subEvent: "Autogen"]                                                                               || true
        "ExistingRegVoIP child accepted"                         | [eventname: "AddMemberList", subEvent: "ExistingRegVoIP", memberInfo: [[parent_child_ind: "C"]]]                                 || true
        "AddingVoIPToParent child accepted"                      | [eventname: "AddMemberList", subEvent: "AddingVoIPToParent", memberInfo: [[parent_child_ind: "C"]]]                              || true
        "ExistingReg child accepted"                             | [eventname: "AddMemberList", subEvent: "ExistingReg", memberInfo: [[parent_child_ind: "C"]]]                                    || true
        "ExistingRegVoIP parent rejected"                        | [eventname: "AddMemberList", subEvent: "ExistingRegVoIP", memberInfo: [[parent_child_ind: "P"]]]                                 || false
        "ExistingReg no memberInfo rejected"                     | [eventname: "AddMemberList", subEvent: "ExistingReg"]                                                                            || false
        "non-eligible subEvent rejected"                         | [eventname: "AddMemberList", subEvent: "SomeOtherSubEvent", memberInfo: [[parent_child_ind: "C"]]]                               || false
        "null subEvent rejected"                                 | [eventname: "AddMemberList", subEvent: null]                                                                                     || false
        "missing subEvent rejected"                              | [eventname: "AddMemberList"]                                                                                                     || false
    }

    @Unroll
    def "processSubSvcMessage returns #expected for UpdateServicesStatusList scenario #scenarioName"() {
        given:
        Map<String, Object> event = eventData

        when:
        boolean result = helper.processSubSvcMessage(event)

        then:
        result == expected
        0 * _

        where:
        scenarioName                                        | eventData                                                                                                                               || expected
        "SubHasVoIP with parent_child_ind=C accepted"      | [eventname: "UpdateServicesStatusList", subEvent: "SubHasVoIP", memberInfo: [[parent_child_ind: "C", handle: "norm.mar"]]]            || true
        "SubHasVoIP with parent_child_ind=P rejected"      | [eventname: "UpdateServicesStatusList", subEvent: "SubHasVoIP", memberInfo: [[parent_child_ind: "P", handle: "norm.mar"]]]            || false
        "OtherSubEvent with parent_child_ind=C rejected"   | [eventname: "UpdateServicesStatusList", subEvent: "OtherSubEvent", memberInfo: [[parent_child_ind: "C", handle: "norm.mar"]]]        || false
        "SubHasVoIP with no memberInfo rejected"           | [eventname: "UpdateServicesStatusList", subEvent: "SubHasVoIP"]                                                                         || false
        "SubHasVoIP with empty memberInfo rejected"        | [eventname: "UpdateServicesStatusList", subEvent: "SubHasVoIP", memberInfo: []]                                                         || false
        "SubHasVoIP with null parent_child_ind rejected"   | [eventname: "UpdateServicesStatusList", subEvent: "SubHasVoIP", memberInfo: [[parent_child_ind: null, handle: "norm.mar"]]]           || false
        "SubHasVoIP with blank handle rejected"            | [eventname: "UpdateServicesStatusList", subEvent: "SubHasVoIP", memberInfo: [[parent_child_ind: "C", handle: ""]]]                     || false
        "SubHasVoIP with null handle rejected"             | [eventname: "UpdateServicesStatusList", subEvent: "SubHasVoIP", memberInfo: [[parent_child_ind: "C", handle: null]]]                   || false
        "SubHasVoIP with missing handle rejected"          | [eventname: "UpdateServicesStatusList", subEvent: "SubHasVoIP", memberInfo: [[parent_child_ind: "C"]]]                                  || false
    }

    def "should transform AddMemberList Autogen event to SUBSVC payload using memberInfo fields"() {
        given:
        Map<String, Object> event = [
                eventname      : "AddMemberList",
                subEvent       : "Autogen",
                callingSystemId: "IDP",
                idpTraceId     : "trace-autogen-123",
                memberInfo     : [[
                        handle          : "child_handle",
                        domain          : "att.net",
                        ban             : "BAN999",
                        registrationDate: "260501120000"
                ]]
        ]

        when:
        HashMap<String, Object> payload = helper.transformToSubSvcPayload(event)
        List<Map<String, Object>> eventDetails = (List<Map<String, Object>>) payload.get("eventDetails")

        then:
        payload.get("eventId") == "IdgraphSubSvcMs-trace-autogen-123"
        payload.get("eventType") == "SubscriptionService"
        payload.get("eventTime") != null
        eventDetails.size() == 2

        Map<String, Object> updateMemberAsync = eventDetails.get(0)
        updateMemberAsync.get("category") == "UpdateMemberAsync"
        updateMemberAsync.get("subCategory") == "UpdateSubscriber"
        updateMemberAsync.get("clientId") == "IDP"
        updateMemberAsync.get("transactionName") == "UpdateSubscriber"
        updateMemberAsync.get("callingSystemId") == "IDP"
        updateMemberAsync.get("ban") == "BAN999"
        updateMemberAsync.get("registrationDate") == "260501120000"
        updateMemberAsync.get("memberId") == "child_handle@att.net"

        Map<String, Object> addUser = eventDetails.get(1)
        addUser.get("category") == "AddUser"
        addUser.get("clientId") == "IDP"
        addUser.get("transactionName") == "AddUser"
        addUser.get("callingSystemId") == "IDP"
        addUser.get("ban") == "BAN999"
        addUser.get("memberId") == "child_handle@att.net"
        List<Map<String, String>> attributes = (List<Map<String, String>>) addUser.get("attributes")
        attributes.size() == 15
        attributes.find { it.get("attributeName") == "USERSTATUS" }.get("attributeValue") == "ACTIVE"
        0 * _
    }

    def "should resolve AddMemberList memberId from handle when handle contains @"() {
        given:
        Map<String, Object> event = [
                eventname      : "AddMemberList",
                subEvent       : "Autogen",
                callingSystemId: "IDP",
                idpTraceId     : "trace-at-sign",
                memberInfo     : [[
                        handle: "child@bellsouth.net",
                        domain: "att.net",
                        ban   : "BAN001"
                ]]
        ]

        when:
        HashMap<String, Object> payload = helper.transformToSubSvcPayload(event)
        List<Map<String, Object>> eventDetails = (List<Map<String, Object>>) payload.get("eventDetails")

        then:
        eventDetails.get(0).get("memberId") == "child@bellsouth.net"
        eventDetails.get(1).get("memberId") == "child@bellsouth.net"
        0 * _
    }

    def "should return empty payload for unsupported event name in transformToSubSvcPayload"() {
        given:
        Map<String, Object> event = [
                eventname      : "SomeUnsupportedEvent",
                ban            : "VD0017554",
                handle         : "qay_geetha_1751",
                domain         : "att.net",
                idpTraceId     : "trace-unsupported",
                callingSystemId: "IDP"
        ]

        when:
        HashMap<String, Object> payload = helper.transformToSubSvcPayload(event)

        then:
        payload.isEmpty()
        0 * _
    }

    def "should return empty payload when eventname is null in transformToSubSvcPayload"() {
        given:
        Map<String, Object> event = [
                ban            : "VD0017554",
                handle         : "qay_geetha_1751",
                domain         : "att.net"
        ]

        when:
        HashMap<String, Object> payload = helper.transformToSubSvcPayload(event)

        then:
        payload.isEmpty()
        0 * _
    }

    def "should use empty string for missing memberInfo fields in AddMemberList transform"() {
        given:
        Map<String, Object> event = [
                eventname      : "AddMemberList",
                subEvent       : "Autogen",
                callingSystemId: "IDP",
                idpTraceId     : "trace-empty-mi",
                memberInfo     : [[handle: "child_h", domain: "att.net"]]
        ]

        when:
        HashMap<String, Object> payload = helper.transformToSubSvcPayload(event)
        List<Map<String, Object>> eventDetails = (List<Map<String, Object>>) payload.get("eventDetails")

        then:
        eventDetails.get(0).get("ban") == ""
        eventDetails.get(0).get("registrationDate") == ""
        eventDetails.get(0).get("memberId") == "child_h@att.net"
        0 * _
    }

    def "should transform AddMemberList non-Autogen event with CHILD_ATTRIBUTES and no UpdateMemberAsync"() {
        given:
        Map<String, Object> event = [
                eventname      : "AddMemberList",
                subEvent       : "ExistingRegVoIP",
                callingSystemId: "IDP",
                idpTraceId     : "trace-non-autogen",
                memberInfo     : [[
                        handle          : "child_handle",
                        domain          : "att.net",
                        ban             : "BAN999",
                        registrationDate: "260501120000",
                        parent_child_ind: "C"
                ]]
        ]

        when:
        HashMap<String, Object> payload = helper.transformToSubSvcPayload(event)
        List<Map<String, Object>> eventDetails = (List<Map<String, Object>>) payload.get("eventDetails")

        then:
        payload.get("eventId") == "IdgraphSubSvcMs-trace-non-autogen"
        payload.get("eventType") == "SubscriptionService"
        payload.get("eventTime") != null
        eventDetails.size() == 1

        Map<String, Object> addUser = eventDetails.get(0)
        addUser.get("category") == "AddUser"
        addUser.get("clientId") == "IDP"
        addUser.get("transactionName") == "AddUser"
        addUser.get("callingSystemId") == "IDP"
        addUser.get("ban") == "BAN999"
        addUser.get("memberId") == "child_handle@att.net"

        List<Map<String, String>> attributes = (List<Map<String, String>>) addUser.get("attributes")
        attributes.size() == 15
        attributes.find { it.get("attributeName") == "PERMISSIONANONYMOUSCALLREJECTIONIND" }.get("attributeValue") == "N"
        attributes.find { it.get("attributeName") == "PERMISSIONDONOTDISTURBIND" }.get("attributeValue") == "N"
        attributes.find { it.get("attributeName") == "PERMISSIONCALLFORWARDUNREGISTEREDIND" }.get("attributeValue") == "N"
        attributes.find { it.get("attributeName") == "PERMISSIONCALLFORWARDNOANSWERIND" }.get("attributeValue") == "N"
        attributes.find { it.get("attributeName") == "PERMISSIONCALLFORWARDINGIND" }.get("attributeValue") == "N"
        attributes.find { it.get("attributeName") == "PERMISSIONPUBLISHSUBSCRIBERIND" }.get("attributeValue") == "N"
        attributes.find { it.get("attributeName") == "ADDRESSBOOKIND" }.get("attributeValue") == "N"
        attributes.find { it.get("attributeName") == "USERSTATUS" }.get("attributeValue") == "ACTIVE"
        attributes.find { it.get("attributeName") == "PERMISSIONCALLFORWARDALLIND" }.get("attributeValue") == "N"
        attributes.find { it.get("attributeName") == "PERMISSIONCALLFORWARDBUSYIND" }.get("attributeValue") == "N"
        attributes.find { it.get("attributeName") == "PERMISSIONSIMULTANEOUSRINGIND" }.get("attributeValue") == "N"
        attributes.find { it.get("attributeName") == "PERMISSIONCALLACCEPTANCEIND" }.get("attributeValue") == "N"
        attributes.find { it.get("attributeName") == "PRIMARYMEMBERIND" }.get("attributeValue") == "N"
        attributes.find { it.get("attributeName") == "PERMISSIONCALLREJECTIND" }.get("attributeValue") == "N"
        attributes.find { it.get("attributeName") == "PERMISSIONAUTOATTENDANTIND" }.get("attributeValue") == "N"
        0 * _
    }

    def "should use CHILD_ATTRIBUTES when AddMemberList has ExistingReg subEvent"() {
        given:
        Map<String, Object> event = [
                eventname      : "AddMemberList",
                subEvent       : "ExistingReg",
                callingSystemId: "IDP",
                idpTraceId     : "trace-existing-reg",
                memberInfo     : [[handle: "child_h", domain: "att.net", ban: "BAN001", parent_child_ind: "C"]]
        ]

        when:
        HashMap<String, Object> payload = helper.transformToSubSvcPayload(event)
        List<Map<String, Object>> eventDetails = (List<Map<String, Object>>) payload.get("eventDetails")

        then:
        eventDetails.size() == 1
        Map<String, Object> addUser = eventDetails.get(0)
        addUser.get("category") == "AddUser"
        List<Map<String, String>> attributes = (List<Map<String, String>>) addUser.get("attributes")
        attributes.size() == 15
        attributes.findAll { it.get("attributeValue") == "N" }.size() == 14
        attributes.find { it.get("attributeName") == "USERSTATUS" }.get("attributeValue") == "ACTIVE"
        0 * _
    }

    def "should use CHILD_ATTRIBUTES when AddMemberList has AddingVoIPToParent subEvent"() {
        given:
        Map<String, Object> event = [
                eventname      : "AddMemberList",
                subEvent       : "AddingVoIPToParent",
                callingSystemId: "IDP",
                idpTraceId     : "trace-voip-parent",
                memberInfo     : [[handle: "child_h", domain: "att.net", ban: "BAN002", parent_child_ind: "C"]]
        ]

        when:
        HashMap<String, Object> payload = helper.transformToSubSvcPayload(event)
        List<Map<String, Object>> eventDetails = (List<Map<String, Object>>) payload.get("eventDetails")

        then:
        eventDetails.size() == 1
        Map<String, Object> addUser = eventDetails.get(0)
        addUser.get("category") == "AddUser"
        List<Map<String, String>> attributes = (List<Map<String, String>>) addUser.get("attributes")
        attributes.size() == 15
        attributes.findAll { it.get("attributeValue") == "N" }.size() == 14
        attributes.find { it.get("attributeName") == "USERSTATUS" }.get("attributeValue") == "ACTIVE"
        0 * _
    }

    @Unroll
    def "transformToSubSvcPayload for UpdateServicesStatusList maps USERSTATUS to #expectedUserStatus when accountStatus=#accountStatus"() {
        given:
        Map<String, Object> event = [
                eventname       : "UpdateServicesStatusList",
                subEvent        : "SubHasVoIP",
                callingSystemId : "IDPWAM",
                transactionName : "ChangeSubStatus",
                idpTraceId      : "trace123",
                memberInfo      : [[parent_child_ind: "C", handle: "norm.mar", domain: "att.net", accountStatus: accountStatus]]
        ]

        when:
        HashMap<String, Object> payload = helper.transformToSubSvcPayload(event)

        then:
        payload.get("eventId") == "IdgraphSubSvcMs-trace123"
        payload.get("eventType") == "SubscriptionService"
        payload.get("eventTime") != null
        List eventDetails = payload.get("eventDetails") as List
        eventDetails.size() == 1

        Map updateUser = eventDetails[0] as Map
        updateUser.get("category") == "UpdateUser"
        updateUser.get("clientId") == "IDPWAM"
        updateUser.get("callingSystemId") == "IDPWAM"
        updateUser.get("transactionName") == "ChangeSubStatus"
        updateUser.get("memberId") == "norm.mar"
        updateUser.get("domain") == "att.net"
        List attributes = updateUser.get("attributes") as List
        attributes.size() == 1
        (attributes[0] as Map).get("attributeName") == "USERSTATUS"
        (attributes[0] as Map).get("attributeValue") == expectedUserStatus
        0 * _

        where:
        accountStatus | expectedUserStatus
        "Suspended"   | "SUSPENDED"
        "Enabled"     | "ACTIVE"
        "Other"       | ""
        null          | ""
    }
}

