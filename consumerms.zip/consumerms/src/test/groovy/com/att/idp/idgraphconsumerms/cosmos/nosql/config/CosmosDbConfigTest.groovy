package com.att.idp.idgraphconsumerms.cosmos.nosql.config

import com.att.idp.idgraphconsumerms.appconfig.config.IDGraphAzureAppConfig
import com.azure.cosmos.CosmosAsyncClient
import com.azure.cosmos.CosmosClientBuilder
import com.azure.spring.data.cosmos.config.CosmosConfig
import com.azure.spring.data.cosmos.core.convert.MappingCosmosConverter
import org.springframework.cloud.context.config.annotation.RefreshScope
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent
import org.springframework.context.annotation.Scope
import spock.lang.Specification
import spock.lang.Unroll

import java.lang.reflect.Constructor;
import java.lang.reflect.Method
import java.util.Arrays

class CosmosDbConfigTest extends Specification {

    IDGraphAzureAppConfig mockAppConfig
    CosmosDbConfig cosmosDbConfig

    def setup() {
        mockAppConfig = Mock(IDGraphAzureAppConfig)
        cosmosDbConfig = new CosmosDbConfig(mockAppConfig) {
            @Override
            CosmosAsyncClient createAsyncClient(CosmosClientBuilder builder) {
                return null
            }
        }
    }

    def "cosmosProperties returns a non-null CosmosProperties instance"() {
        when:
        CosmosProperties result = cosmosDbConfig.cosmosProperties()

        then:
        result != null
        0 * _
    }

    @Unroll
    def "primaryClientBuilder applies refreshable settings for #scenarioName"() {
        given:
        CosmosProperties props = new CosmosProperties()
        props.setKey(key)
        props.setUri(uri)
        props.setName("usage")

        when:
        CosmosClientBuilder clientBuilder = cosmosDbConfig.primaryClientBuilder(props)

        then:
        _ * mockAppConfig.getMaxConnectionPoolSize() >> maxPoolSize
        _ * mockAppConfig.getIdleConnectionTimeoutMs() >> idleTimeout
        _ * mockAppConfig.getPreferredRegions() >> ["East US 2", "West US 2"]
        clientBuilder instanceof CosmosClientBuilder
        0 * _

        where:
        scenarioName       | key        | uri                | maxPoolSize | idleTimeout
        "default values"   | "test-key" | "https://test-uri" | 100         | 5000
        "custom pool size" | "test-key" | "https://test-uri" | 200         | 3000
    }

    def "primaryClientBuilder returns builder without side effects"() {
        given:
        CosmosProperties props = new CosmosProperties()
        props.setKey("test-key")
        props.setUri("https://test-uri")
        props.setName("usage")

        when:
        CosmosClientBuilder clientBuilder = cosmosDbConfig.primaryClientBuilder(props)

        then:
        _ * mockAppConfig.getMaxConnectionPoolSize() >> 100
        _ * mockAppConfig.getIdleConnectionTimeoutMs() >> 5000
        _ * mockAppConfig.getPreferredRegions() >> ["East US 2", "West US 2"]
        clientBuilder != null
        clientBuilder instanceof CosmosClientBuilder
        // Verify that activeClient was NOT set as a side effect
        cosmosDbConfig.getActiveClient() == null
        0 * _
    }

    def "primaryClientBuilder is refresh scoped"() {
        when:
        Method method = CosmosDbConfig.getDeclaredMethod("primaryClientBuilder", CosmosProperties)

        then:
        method.getAnnotation(RefreshScope) != null
        0 * _
    }

    def "idmDatabaseTemplate is refresh scoped"() {
        when:
        Method method = CosmosDbConfig.IdmDatabaseConfiguration.getDeclaredMethod(
                "idmDatabaseTemplate", CosmosAsyncClient, CosmosConfig, MappingCosmosConverter)

        then:
        method.getAnnotation(RefreshScope) != null
        0 * _
    }

    def "cosmosAsyncClient bean method is prototype scoped"() {
        when:
        Method method = CosmosDbConfig.IdmDatabaseConfiguration.getDeclaredMethod("cosmosAsyncClient", CosmosClientBuilder)

        then:
        Scope scope = method.getAnnotation(Scope)
        scope != null
        scope.value() == "prototype"
        0 * _
    }

    def "cosmosAsyncClient delegates to createAsyncClient"() {
        given: "an outer config with tracked createAsyncClient calls"
        boolean createAsyncClientWasCalled = false
        CosmosDbConfig outerConfig = new CosmosDbConfig(mockAppConfig) {
            @Override
            CosmosAsyncClient createAsyncClient(CosmosClientBuilder builder) {
                createAsyncClientWasCalled = true
                return null
            }
        }

        and: "a reference to the inner class"
        Class<?>[] innerClasses = CosmosDbConfig.getDeclaredClasses()
        Class<?> innerConfigClass = Arrays.stream(innerClasses)
                .filter(c -> c.getSimpleName().equals("IdmDatabaseConfiguration"))
                .findFirst()
                .orElseThrow()

        when: "inner class instance is created and cosmosAsyncClient is called"
        Constructor<?> innerConfigConstructor = innerConfigClass.getDeclaredConstructor(CosmosDbConfig)
        innerConfigConstructor.setAccessible(true)
        Object innerConfig = innerConfigConstructor.newInstance(outerConfig)
        CosmosClientBuilder cosmosClientBuilder = new CosmosClientBuilder()
        Method method = innerConfigClass.getDeclaredMethod("cosmosAsyncClient", CosmosClientBuilder)
        CosmosAsyncClient client = (CosmosAsyncClient) method.invoke(innerConfig, cosmosClientBuilder)

        then: "createAsyncClient was called and returned null"
        client == null
        createAsyncClientWasCalled == true
        0 * _
    }

    def "getCosmosConfig returns a CosmosConfig with query metrics enabled"() {
        when:
        CosmosConfig config = cosmosDbConfig.getCosmosConfig()

        then:
        config instanceof CosmosConfig
        config.isQueryMetricsEnabled()
        0 * _
    }

    def "onRefresh logs and handles rebuild failure gracefully without propagating exception"() {
        given:
        RefreshScopeRefreshedEvent event = Mock(RefreshScopeRefreshedEvent)

        when:
        cosmosDbConfig.onRefresh(event)

        then:
        1 * event.getName() >> "testRefresh"
        _ * mockAppConfig.getMaxConnectionPoolSize() >> 50
        _ * mockAppConfig.getIdleConnectionTimeoutMs() >> 2000
        _ * mockAppConfig.getPreferredRegions() >> ["East US 2", "West US 2"]
        noExceptionThrown()
        0 * _
    }

    def "onRefresh handles null event gracefully"() {
        when:
        cosmosDbConfig.onRefresh(null)

        then:
        _ * mockAppConfig.getMaxConnectionPoolSize() >> 100
        _ * mockAppConfig.getIdleConnectionTimeoutMs() >> 5000
        _ * mockAppConfig.getPreferredRegions() >> ["East US 2", "West US 2"]
        noExceptionThrown()
        0 * _
    }
}