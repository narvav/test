// groovy
// File: 'src/test/groovy/com/att/idp/idgraphconsumerms/kafka/listener/ProductNotificationEventListenerSpec.groovy'
package com.att.idp.idgraphconsumerms.kafka.listener

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.kafka.dmctn.service.BaseService
import com.att.idp.idgraphconsumerms.kafka.dmctn.service.RGPHOServiceFactory
import com.att.idp.idgraphconsumerms.kafka.model.AccountNotificationEvent
import com.att.idp.idgraphconsumerms.request.validator.RequestValidator
import com.att.idp.idgraphconsumerms.utils.JsonService
import com.fasterxml.jackson.core.JsonProcessingException
import org.springframework.kafka.support.Acknowledgment
import org.springframework.messaging.MessageHeaders
import spock.lang.Specification
import spock.lang.Unroll

class ProductNotificationEventListenerTest extends Specification {

    RGPHOServiceFactory rgphoServiceFactory
    RequestValidator requestValidator
    Acknowledgment acknowledgment
    BaseService<AccountNotificationEvent> baseService
    ProductNotificationEventListener listener

    def setup() {
        rgphoServiceFactory = Mock(RGPHOServiceFactory)
        requestValidator = Mock(RequestValidator)
        acknowledgment = Mock(Acknowledgment)
        baseService = Mock(BaseService)

        listener = new ProductNotificationEventListener()

        java.lang.reflect.Field f1 = ProductNotificationEventListener.class.getDeclaredField("rgphoServiceFactory")
        f1.setAccessible(true)
        f1.set(listener, rgphoServiceFactory)

        java.lang.reflect.Field f2 = ProductNotificationEventListener.class.getDeclaredField("requestValidator")
        f2.setAccessible(true)
        f2.set(listener, requestValidator)
    }

    @Unroll
    def "should process event and acknowledge for #scenarioName"() {
        given: "A valid JSON message and headers"
        String subscriberNumber = "SUB12345"
        String eventName = ConsumerConstants.ProductNotificationConstants.EVENT_TYPE_PRODUCT_CHANGE
        String message = "{\"eventName\":\"${eventName}\",\"subscriberNumber\":\"${subscriberNumber}\"}"
        MessageHeaders headers = new MessageHeaders(new java.util.HashMap<String, Object>())

        and: "JsonService returns a populated AccountNotificationEvent"
        JsonService.metaClass.'static'.convertToObject = { String json, Class clazz ->
            AccountNotificationEvent evt = new AccountNotificationEvent()
            evt.setEventName(eventName)
            evt.setSubscriberNumber(subscriberNumber)
            return evt
        }

        when: "Listener processes the message"
        listener.productNotificationEventListener(message, headers, acknowledgment)

        then: "Factory provides service and it executes with correct event data"
        1 * rgphoServiceFactory.getService(eventName) >> baseService
        1 * baseService.execute({ AccountNotificationEvent evt ->
            evt.getEventName() == eventName &&
                    evt.getSubscriberNumber() == subscriberNumber
        })
        1 * acknowledgment.acknowledge()
        0 * _

        and: "Message contains expected subscriber number"
        message.contains(subscriberNumber)

        cleanup:
        GroovySystem.metaClassRegistry.removeMetaClass(JsonService)

        where:
        scenarioName | _
        "valid product change event" | _
    }

    @Unroll
    def "should skip execution and acknowledge for unsupported event type - #scenarioName"() {
        given: "A JSON message with unsupported event type"
        String unsupportedEvent = "UNSUPPORTED_EVENT"
        String subscriberNumber = "SUB0001"
        String message = "{\"eventName\":\"${unsupportedEvent}\",\"subscriberNumber\":\"${subscriberNumber}\"}"
        MessageHeaders headers = new MessageHeaders(new java.util.HashMap<String, Object>())

        and: "JsonService returns a populated event"
        JsonService.metaClass.'static'.convertToObject = { String json, Class clazz ->
            AccountNotificationEvent evt = new AccountNotificationEvent()
            evt.setEventName(unsupportedEvent)
            evt.setSubscriberNumber(subscriberNumber)
            return evt
        }

        when: "Listener processes the message"
        listener.productNotificationEventListener(message, headers, acknowledgment)

        then: "Factory returns null service and no execution occurs"
        1 * rgphoServiceFactory.getService(unsupportedEvent) >> null
        1 * acknowledgment.acknowledge()
        0 * _

        and: "Message contains expected subscriber number"
        message.contains(subscriberNumber)

        cleanup:
        GroovySystem.metaClassRegistry.removeMetaClass(JsonService)

        where:
        scenarioName | _
        "no matching service" | _
    }

    @Unroll
    def "should unwrap double-encoded JSON and process correctly for #scenarioName"() {
        given: "A double-encoded JSON payload"
        String eventName = ConsumerConstants.ProductNotificationConstants.EVENT_TYPE_PRODUCT_CHANGE
        String subscriberNumber = "SUB777"
        String rawJson = "{\"eventName\":\"${eventName}\",\"subscriberNumber\":\"${subscriberNumber}\"}"
        String doubleEncoded = "\"" + rawJson.replace("\"", "\\\"") + "\""
        MessageHeaders headers = new MessageHeaders(new java.util.HashMap<String, Object>())

        and: "JsonService returns parsed event when given unwrapped JSON"
        JsonService.metaClass.'static'.convertToObject = { String json, Class clazz ->
            assert json == rawJson
            AccountNotificationEvent evt = new AccountNotificationEvent()
            evt.setEventName(eventName)
            evt.setSubscriberNumber(subscriberNumber)
            return evt
        }

        when: "Listener processes the double-encoded message"
        listener.productNotificationEventListener(doubleEncoded, headers, acknowledgment)

        then: "Factory provides service and it executes"
        1 * rgphoServiceFactory.getService(eventName) >> baseService
        1 * baseService.execute({ AccountNotificationEvent evt ->
            evt.getEventName() == eventName &&
                    evt.getSubscriberNumber() == subscriberNumber
        })
        1 * acknowledgment.acknowledge()
        0 * _

        and: "Original double-encoded message still contains subscriber string in raw form"
        doubleEncoded.contains(subscriberNumber)

        cleanup:
        GroovySystem.metaClassRegistry.removeMetaClass(JsonService)

        where:
        scenarioName | _
        "double-encoded payload" | _
    }

    def "should log and acknowledge when service exists but event contains only subscriberNumber (eventName null) - no execution"() {
        given: "A JSON message missing eventName"
        String subscriberNumber = "SUBNIL"
        String message = "{\"subscriberNumber\":\"${subscriberNumber}\"}"
        MessageHeaders headers = new MessageHeaders(new java.util.HashMap<String, Object>())

        and: "JsonService creates event with null eventName"
        JsonService.metaClass.'static'.convertToObject = { String json, Class clazz ->
            AccountNotificationEvent evt = new AccountNotificationEvent()
            evt.setSubscriberNumber(subscriberNumber)
            evt.setEventName(null)
            return evt
        }

        when: "Listener processes the message"
        listener.productNotificationEventListener(message, headers, acknowledgment)

        then: "Factory asked with null event type; returns null; no execute; ack called"
        1 * rgphoServiceFactory.getService(null) >> null
        1 * acknowledgment.acknowledge()
        0 * _

        and: "Message contains expected subscriber number"
        message.contains(subscriberNumber)

        cleanup:
        GroovySystem.metaClassRegistry.removeMetaClass(JsonService)
    }
}