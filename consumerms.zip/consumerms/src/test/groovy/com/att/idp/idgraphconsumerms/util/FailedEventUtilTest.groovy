package com.att.idp.idgraphconsumerms.util

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil
import spock.lang.Specification
import spock.lang.Unroll

class FailedEventUtilTest extends Specification {

		CosmosFailedEventsWriter cosmosFailedEventsWriter

		def setup() {
			cosmosFailedEventsWriter = Mock(CosmosFailedEventsWriter)
		}

		@Unroll
		def "should save failed event with correct details for #scenarioName"() {
			given: "All required parameters for failed event"
			String sourceBanId = inputSourceBanId
			String notificationJson = inputNotificationJson
			String eventType = inputEventType
			String errorCode = inputErrorCode
			String errorMessage = inputErrorMessage
			String failedEndpoint = inputFailedEndpoint
			String accountType = inputAccountType

			when: "saveFailedEvent is called"
			FailedEventUtil.saveFailedEvent(
					cosmosFailedEventsWriter,
					sourceBanId,
					notificationJson,
					eventType,
					errorCode,
					errorMessage,
					failedEndpoint,
					accountType
			)

			then: "CosmosFailedEventsWriter is called with correct FailedEventDetails"
			1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
				FailedEventDetails details ->
					details.accountId == sourceBanId &&
							details.requestPayload == notificationJson &&
							details.eventName == eventType &&
							details.errorDetails.get(ConsumerConstants.ErrorDetails.ERROR_CODE) == errorCode &&
							details.errorDetails.get(ConsumerConstants.ErrorDetails.ERROR_MESSAGE) == errorMessage &&
							details.errorDetails.get(ConsumerConstants.ErrorDetails.FAILED_ENDPOINT) == failedEndpoint &&
							details.errorDetails.get(ConsumerConstants.ErrorDetails.ACCOUNT_TYPE) == accountType
			})
			0 * _

			and: "No exception is thrown"

			where: "Different failed event scenarios"
			scenarioName         | inputSourceBanId | inputNotificationJson | inputEventType | inputErrorCode | inputErrorMessage | inputFailedEndpoint | inputAccountType
			"standard failure"   | "BAN123"         | '{"foo":"bar"}'      | "TYPE_A"       | "ERR001"       | "Failure"         | "/api/test"         | "CONSUMER"
			"empty error fields" | "BAN456"         | '{}'                | "TYPE_B"       | ""             | ""                | ""                  | ""
		}

		def "saveFailedEventResolvingCategory resolves eventCategory from GDDN event name"() {
			given: "A GDDN subscriber event name"
			String eventType = ConsumerConstants.GridGddnNotification.EVENT_GDDN_RESTORE_SUBSCRIBER

			when: "saveFailedEventResolvingCategory is called"
			FailedEventUtil.saveFailedEventResolvingCategory(
					cosmosFailedEventsWriter,
					"BAN789",
					'{"test":"data"}',
					eventType,
					"ERR002",
					"Some error",
					"/api/downstream",
					"GRID_GDDN"
			)

			then: "FailedEventDetails includes resolved eventCategory"
			1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
				FailedEventDetails details ->
					details.accountId == "BAN789" &&
							details.eventName == eventType &&
							details.eventCategory == ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_SUBSCRIBER &&
							details.errorDetails.get(ConsumerConstants.ErrorDetails.ERROR_CODE) == "ERR002"
			})
			0 * _
		}

		def "saveFailedEventResolvingCategory sets null eventCategory for unknown event type"() {
			given: "An unknown event name"
			String eventType = "UnknownEventType"

			when: "saveFailedEventResolvingCategory is called"
			FailedEventUtil.saveFailedEventResolvingCategory(
					cosmosFailedEventsWriter,
					"BAN999",
					'{"test":"unknown"}',
					eventType,
					"ERR003",
					"Unknown event",
					"/api/unknown",
					"CONSUMER"
			)

			then: "FailedEventDetails has null eventCategory"
			1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
				FailedEventDetails details ->
					details.accountId == "BAN999" &&
							details.eventName == eventType &&
							details.eventCategory == null
			})
			0 * _
		}
}
