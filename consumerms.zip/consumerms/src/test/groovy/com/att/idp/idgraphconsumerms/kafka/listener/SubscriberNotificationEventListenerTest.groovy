package com.att.idp.idgraphconsumerms.kafka.listener

import com.att.idp.idgraph.events.model.ConsumerAction
import com.att.idp.idgraph.events.service.ResilientEventConsumer
import com.att.idp.idgraphconsumerms.kafka.dmctn.service.BackendService
import com.att.idp.idgraphconsumerms.kafka.dmctn.service.SubscriberServiceFactory
import com.att.idp.idgraphconsumerms.kafka.model.SubscriberEventNotification
import org.springframework.kafka.support.Acknowledgment
import org.springframework.messaging.MessageHeaders
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

class SubscriberNotificationEventListenerTest extends Specification {

    @Shared SubscriberServiceFactory subscriberServiceFactory
    @Shared BackendService backendService

    def setup() {
        subscriberServiceFactory = Mock(SubscriberServiceFactory)
        backendService = Mock(BackendService)
    }

    private static void injectDependencies(SubscriberNotificationEventListener listener,
                                           SubscriberServiceFactory factory) {
        java.lang.reflect.Field f1 = SubscriberNotificationEventListener.class.getDeclaredField("subscriberServiceFactory")
        f1.setAccessible(true)
        f1.set(listener, factory)
    }

    private String buildJson(String eventName, String subId, String subscriberNumber, String status) {
        return "{" +
                "\"eventName\":\"" + eventName + "\"," +
                "\"subId\":\"" + subId + "\"," +
                "\"subscriberNumber\":\"" + subscriberNumber + "\"," +
                "\"billingAccountNumber\":\"" + subscriberNumber + "\"," +
                "\"subscriberStatus\":\"" + status + "\"" +
                "}";
    }

    @Unroll
    def "should consume event and invoke backend for #scenarioName"() {
        given: "Listener with injected factory and message"
        SubscriberNotificationEventListener listener = new SubscriberNotificationEventListener()
        injectDependencies(listener, subscriberServiceFactory)
        String json = buildJson(eventName, subId, msisdn, status)
        MessageHeaders headers = new MessageHeaders([:])
        Acknowledgment acknowledgment = Mock(Acknowledgment)

        when: "consumeSubscriberNotification is invoked"
        listener.consumeSubscriberNotification(json, headers, acknowledgment)

        then: "Factory resolves backend and execute invoked once with GDDN source"
        1 * subscriberServiceFactory.getService(eventName) >> backendService
        1 * backendService.execute({ com.att.idp.idgraphconsumerms.kafka.model.Subscriber s ->
            s.id == subId &&
            s.phoneNumber == msisdn &&
            s.billingAccount == msisdn &&
            s.status == status
        }, com.att.idp.idgraphconsumerms.kafka.dmctn.service.EventSource.GDDN)
        1 * acknowledgment.acknowledge()
        0 * _

        and: "Message processed without exception"
        json.contains(eventName)

        where: "Various valid event scenarios"
        scenarioName      | eventName         | subId    | msisdn      | status
        "ActivateAccount" | "ActivateAccount" | "SUB123" | "5551112222" | "ACTIVE"
        "CloseAccount"    | "CloseAccount"    | "SUB456" | "5553334444" | "CLOSED"
    }

    def "should handle unsupported event when factory returns null"() {
        given: "Listener with factory returning null service"
        SubscriberNotificationEventListener listener = new SubscriberNotificationEventListener()
        injectDependencies(listener, subscriberServiceFactory)
        String eventName = "UnknownEvent"
        String json = buildJson(eventName, "SUB999", "5557778888", "SOMESTATUS")
        MessageHeaders headers = new MessageHeaders([:])
        Acknowledgment acknowledgment = Mock(Acknowledgment)

        when: "consumeSubscriberNotification invoked with unsupported event"
        listener.consumeSubscriberNotification(json, headers, acknowledgment)

        then: "Factory called, backend not executed, ack called"
        1 * subscriberServiceFactory.getService(eventName) >> null
        1 * acknowledgment.acknowledge()
        0 * _

        and: "JSON contains eventName and processing completed"
        json.contains(eventName)
    }

    def "should propagate backend exception and not acknowledge"() {
        given: "Listener where backend service throws runtime exception"
        SubscriberNotificationEventListener listener = new SubscriberNotificationEventListener()
        injectDependencies(listener, subscriberServiceFactory)
        String eventName = "ActivateAccount"
        String json = buildJson(eventName, "SUB777", "5550001111", "ACTIVE")
        MessageHeaders headers = new MessageHeaders([:])
        Acknowledgment acknowledgment = Mock(Acknowledgment)
        RuntimeException backendEx = new RuntimeException("Failure executing backend")

        when: "consumeSubscriberNotification invoked and backend throws"
        listener.consumeSubscriberNotification(json, headers, acknowledgment)

        then: "Factory resolves backend and execute throws with GDDN source"
        1 * subscriberServiceFactory.getService(eventName) >> backendService
        1 * backendService.execute({ com.att.idp.idgraphconsumerms.kafka.model.Subscriber s -> s.id == "SUB777" }, 
                                     com.att.idp.idgraphconsumerms.kafka.dmctn.service.EventSource.GDDN) >> { throw backendEx }
        0 * acknowledgment.acknowledge()
        0 * _

        and: "Exception propagated"
        RuntimeException ex = thrown()
        ex.message == "Failure executing backend"
    }

    def "should throw JsonProcessingException for invalid JSON"() {
        given: "Listener and invalid JSON input"
        SubscriberNotificationEventListener listener = new SubscriberNotificationEventListener()
        injectDependencies(listener, subscriberServiceFactory)
        String invalidJson = "not-a-json" // triggers failure inside safeConvertToObject -> Optional empty -> orElseThrow
        MessageHeaders headers = new MessageHeaders(Collections.emptyMap())
        Acknowledgment acknowledgment = Mock(Acknowledgment)

        when: "consumeSubscriberNotification invoked with invalid JSON"
        listener.consumeSubscriberNotification(invalidJson, headers, acknowledgment)

        then: "JsonProcessingException thrown before factory usage"
        0 * subscriberServiceFactory.getService({ String ev -> ev == null })
        0 * acknowledgment.acknowledge()
        0 * _
        com.fasterxml.jackson.core.JsonProcessingException ex = thrown()
        ex.message == "Failed to deserialize message to ChangeSubscriberEvent"
    }

    @Unroll
    def "should safely convert JSON for #scenarioName"() {
        given: "Input JSON possibly double encoded"
        String input = rawJson

        when: "safeConvertToObject called"
        Optional<SubscriberEventNotification> result = SubscriberNotificationEventListener.safeConvertToObject(input, SubscriberEventNotification.class)

        then: "Result presence matches expectation"
        result.isPresent() == expectedPresent
        if(expectedPresent) {
            SubscriberEventNotification evt = result.get()
            evt.eventName == "ActivateAccount"
            evt.subId == "SUBID"
        }
        0 * _

        where: "Different JSON encodings"
        scenarioName          | rawJson                                                                                                                                                              | expectedPresent
        "plain json"          | '{"eventName":"ActivateAccount","subId":"SUBID"}'                                                                                                              | true
        "double encoded json" | '"{\"eventName\":\"ActivateAccount\",\"subId\":\"SUBID\"}"'                                                                                              | true
        "blank json"          | ''                                                                                                                                                                   | false
    }

    private static void injectResilientConsumer(SubscriberNotificationEventListener listener,
                                                ResilientEventConsumer consumer) {
        java.lang.reflect.Field f = SubscriberNotificationEventListener.class.getDeclaredField("resilientEventConsumer")
        f.setAccessible(true)
        f.set(listener, consumer)
    }

    @Unroll
    def "R5: gate skips duplicate / stale retried message and acknowledges \u2014 action=#action"() {
        given: "a listener with the resilient gate wired and the consumer evaluating to a non-PROCESS action"
        SubscriberNotificationEventListener listener = new SubscriberNotificationEventListener()
        injectDependencies(listener, subscriberServiceFactory)
        ResilientEventConsumer evaluator = Mock(ResilientEventConsumer)
        injectResilientConsumer(listener, evaluator)
        Acknowledgment ack = Mock()
        MessageHeaders headers = new MessageHeaders([:])
        String json = buildJson("ActivateAccount", "SUB-1", "5550000001", "A")

        when: "the listener processes a message"
        listener.consumeSubscriberNotification(json, headers, ack)

        then: "the gate intercepts \u2014 backend is never invoked but the message is ack'd"
        1 * evaluator.evaluate(headers, "") >> action
        1 * ack.acknowledge()
        0 * subscriberServiceFactory._
        0 * _

        where:
        action << [ConsumerAction.SKIP_DUPLICATE, ConsumerAction.SKIP_STALE]
    }

    def "R5: gate returns PROCESS \u2014 listener continues to existing logic"() {
        given: "a listener with the gate wired and evaluator returning PROCESS"
        SubscriberNotificationEventListener listener = new SubscriberNotificationEventListener()
        injectDependencies(listener, subscriberServiceFactory)
        ResilientEventConsumer evaluator = Mock(ResilientEventConsumer)
        injectResilientConsumer(listener, evaluator)
        Acknowledgment ack = Mock()
        MessageHeaders headers = new MessageHeaders([:])
        String json = buildJson("ActivateAccount", "SUB-2", "5550000002", "A")

        when:
        listener.consumeSubscriberNotification(json, headers, ack)

        then: "the gate is consulted but does not short-circuit; downstream factory is consulted as usual"
        1 * evaluator.evaluate(headers, "") >> ConsumerAction.PROCESS
        1 * subscriberServiceFactory.getService("ActivateAccount") >> backendService
        1 * backendService.execute(_, com.att.idp.idgraphconsumerms.kafka.dmctn.service.EventSource.GDDN)
        1 * ack.acknowledge()
        0 * _
    }

    def "R5: gate is bypassed entirely when ResilientEventConsumer is not wired (legacy path)"() {
        given: "a listener WITHOUT the resilient gate (consumer bean absent)"
        SubscriberNotificationEventListener listener = new SubscriberNotificationEventListener()
        injectDependencies(listener, subscriberServiceFactory)
        // resilientEventConsumer field intentionally null
        Acknowledgment ack = Mock()
        MessageHeaders headers = new MessageHeaders([:])
        String json = buildJson("ActivateAccount", "SUB-3", "5550000003", "A")

        when:
        listener.consumeSubscriberNotification(json, headers, ack)

        then: "downstream factory is consulted as before \u2014 no behavior change for legacy adopters"
        1 * subscriberServiceFactory.getService("ActivateAccount") >> backendService
        1 * backendService.execute(_, com.att.idp.idgraphconsumerms.kafka.dmctn.service.EventSource.GDDN)
        1 * ack.acknowledge()
        0 * _
    }
}
