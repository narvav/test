package com.att.idp.idgraphconsumerms.kafka.listener

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.helpers.PasscodeProcessor
import com.att.idp.idgraphconsumerms.kafka.model.OGraphConversionFailedEvent
import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.kafka.support.Acknowledgment
import org.springframework.messaging.MessageHeaders
import spock.lang.Specification

class OrderEventsNotificationListenerTest extends Specification {

def credentialsProcessor = Mock(PasscodeProcessor)
def acknowledgment = Mock(Acknowledgment)
def messageHeaders = Mock(MessageHeaders)
def objectMapper = new ObjectMapper()
def listener = new OrderEventsNotificationListener()

def setup() {
listener.credentialsProcessor = credentialsProcessor
}

def "test consumeOrderEventsNotification with valid payload"() {
given:
def payload = new OGraphConversionFailedEvent(
        eventId: "COP-EVENT-0001",
        eventType: "SALES-PIVOT-CONVERSION-FAILED",
        eventTime: "2025-06-16T15:56:51.883Z",
        eventTraceId: "{trace-id-received-from-checkoutms}",
        event: new OGraphConversionFailedEvent.EventDetail(
                billingAccountId: "551625521206",
                individualId: "3b51a4d4-b8c4-4506-b06a-2f94915a7300",
                customerId: "d1f94c0b-b4fa-4f86-be1e-fdf62d1a249f",
                productOrder: new OGraphConversionFailedEvent.ProductOrder(
                        id: "{cartId}",
                        externalId: "{orderNumber}",
                        orderDate: "2025-06-16T11:56:51.883Z"
                )
        )
)
String msg = objectMapper.writeValueAsString(payload)

when:
listener.consumeOrderEventsNotification(msg, messageHeaders, acknowledgment)

then:
1 * credentialsProcessor.callUserAssociationDeleteCredService("3b51a4d4-b8c4-4506-b06a-2f94915a7300",
        ConsumerConstants.BsseMigration.EVENT_ORDERGRAPH_FAILURE)
1 * acknowledgment.acknowledge()
}

def "test consumeOrderEventsNotification with invalid eventType"() {
given:
def payload = new OGraphConversionFailedEvent(
        eventId: "COP-EVENT-0001",
        eventType: "SALES-PIVOT-CONVERSION-FAILEDed",
        eventTime: "2025-06-16T15:56:51.883Z",
        eventTraceId: "{trace-id-received-from-checkoutms}",
        event: new OGraphConversionFailedEvent.EventDetail(
                billingAccountId: "551625521206",
                individualId: "3b51a4d4-b8c4-4506-b06a-2f94915a7300",
                customerId: "d1f94c0b-b4fa-4f86-be1e-fdf62d1a249f",
                productOrder: new OGraphConversionFailedEvent.ProductOrder(
                        id: "{cartId}",
                        externalId: "{orderNumber}",
                        orderDate: "2025-06-16T11:56:51.883Z"
                )
        )
)
String msg = objectMapper.writeValueAsString(payload)

when:
listener.consumeOrderEventsNotification(msg, messageHeaders, acknowledgment)

then:
0 * credentialsProcessor.callUserAssociationDeleteCredService(_)
2 * acknowledgment.acknowledge()
}

def "test consumeOrderEventsNotification with null individualId"() {
given:
def payload = new OGraphConversionFailedEvent(
        eventId: "COP-EVENT-0001",
        eventType: "SALES-PIVOT-CONVERSION-FAILED",
        eventTime: "2025-06-16T15:56:51.883Z",
        eventTraceId: "{trace-id-received-from-checkoutms}",
        event: new OGraphConversionFailedEvent.EventDetail(
                billingAccountId: "551625521206",
                individualId: "",
                customerId: "d1f94c0b-b4fa-4f86-be1e-fdf62d1a249f",
                productOrder: new OGraphConversionFailedEvent.ProductOrder(
                        id: "{cartId}",
                        externalId: "{orderNumber}",
                        orderDate: "2025-06-16T11:56:51.883Z"
                )
        )
)
String msg = objectMapper.writeValueAsString(payload)

when:
listener.consumeOrderEventsNotification(msg, messageHeaders, acknowledgment)

then:
0 * credentialsProcessor.callUserAssociationDeleteCredService(_)
1 * acknowledgment.acknowledge()
}

def "test consumeOrderEventsNotification with exception during processing"() {
given:
def payload = new OGraphConversionFailedEvent(
        eventId: "COP-EVENT-0001",
        eventType: "SALES-PIVOT-CONVERSION-FAILED",
        eventTime: "2025-06-16T15:56:51.883Z",
        eventTraceId: "{trace-id-received-from-checkoutms}",
        event: new OGraphConversionFailedEvent.EventDetail(
                billingAccountId: "551625521206",
                individualId: "3b51a4d4-b8c4-4506-b06a-2f94915a7300",
                customerId: "d1f94c0b-b4fa-4f86-be1e-fdf62d1a249f",
                productOrder: new OGraphConversionFailedEvent.ProductOrder(
                        id: "{cartId}",
                        externalId: "{orderNumber}",
                        orderDate: "2025-06-16T11:56:51.883Z"
                )
        )
)
String msg = objectMapper.writeValueAsString(payload)
credentialsProcessor.callUserAssociationDeleteCredService(_) >> { throw new RuntimeException("Test exception") }

when:
listener.consumeOrderEventsNotification(msg, messageHeaders, acknowledgment)

then:
1 * credentialsProcessor.callUserAssociationDeleteCredService("3b51a4d4-b8c4-4506-b06a-2f94915a7300",
        ConsumerConstants.BsseMigration.EVENT_ORDERGRAPH_FAILURE)
1 * acknowledgment.acknowledge()
}
}
