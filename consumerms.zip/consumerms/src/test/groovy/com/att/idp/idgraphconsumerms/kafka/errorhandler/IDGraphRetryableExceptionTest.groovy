package com.att.idp.idgraphconsumerms.kafka.errorhandler

import spock.lang.Specification

class IDGraphRetryableExceptionTest extends Specification {

    def "test constructor with message"() {
        when:
        def exception = new IDGraphRetryableException("Retryable exception occurred")

        then:
        exception.message == "Retryable exception occurred"
    }

    def "test constructor with message and cause"() {
        given:
        def cause = new RuntimeException("Underlying cause")

        when:
        def exception = new IDGraphRetryableException("Retryable exception occurred", cause)

        then:
        exception.message == "Retryable exception occurred"
        exception.cause == cause
    }
}