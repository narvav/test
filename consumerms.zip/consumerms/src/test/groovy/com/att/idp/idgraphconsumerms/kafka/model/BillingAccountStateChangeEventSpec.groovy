package com.att.idp.idgraphconsumerms.kafka.model

import com.fasterxml.jackson.databind.ObjectMapper
import spock.lang.Specification

class BillingAccountStateChangeEventSpec extends Specification {

    def objectMapper = new ObjectMapper()

    def "should deserialize valid BillingAccountStateChangeEvent JSON"() {
        given:
        def json = '''
        {
            "eventId": "BillingAccountStateChangeEvent-0403a555",
            "eventType": "BillingAccountStateChangeEvent",
            "eventTime": "2022-03-10 14:38:53.185",
            "resourceName": "Account",
            "event": {
                "name": "BillingAccountStateChange",
                "type": "BillingAccountStateChangeEvent",
                "resourceVersion": "1",
                "resourceIdentifier": "Account",
                "account": "{\\"id\\":\\"556331445652\\",\\"state\\":\\"closed\\",\\"serviceType\\":\\"Wireless\\"}"
            }
        }
        '''

        when:
        def event = objectMapper.readValue(json, BillingAccountStateChangeEvent)

        then:
        event.eventId == "BillingAccountStateChangeEvent-0403a555"
        event.eventType == "BillingAccountStateChangeEvent"
        event.eventTime == "2022-03-10 14:38:53.185"
        event.resourceName == "Account"
        event.event != null
        event.event.name == "BillingAccountStateChange"
        event.event.type == "BillingAccountStateChangeEvent"
        event.event.resourceVersion == "1"
        event.event.resourceIdentifier == "Account"
        event.event.account != null
    }

    def "should extract account JSON from event"() {
        given:
        def accountJson = '{"id":"556331445652","state":"closed","serviceType":"Wireless"}'
        def json = """
        {
            "eventId": "test-event-id",
            "eventType": "BillingAccountStateChangeEvent",
            "event": {
                "name": "BillingAccountStateChange",
                "type": "BillingAccountStateChangeEvent",
                "account": ${objectMapper.writeValueAsString(accountJson)}
            }
        }
        """

        when:
        def event = objectMapper.readValue(json, BillingAccountStateChangeEvent)
        def accountNode = objectMapper.readTree(event.event.account)

        then:
        accountNode.get("id").asText() == "556331445652"
        accountNode.get("state").asText() == "closed"
        accountNode.get("serviceType").asText() == "Wireless"
    }

    def "should handle missing eventType gracefully"() {
        given:
        def json = '''
        {
            "eventId": "test-event-id",
            "resourceName": "Account",
            "event": {
                "name": "BillingAccountStateChange",
                "account": "{\\"id\\":\\"123\\"}"
            }
        }
        '''

        when:
        def event = objectMapper.readValue(json, BillingAccountStateChangeEvent)

        then:
        event.eventType == null
        event.eventId == "test-event-id"
        event.event.account != null
    }

    def "should extract accountId from embedded account JSON"() {
        given:
        def accountJson = '{"id":"556331445652","state":"closed"}'
        def event = new BillingAccountStateChangeEvent()
        def innerEvent = new BillingAccountStateChangeEvent.Event()
        innerEvent.account = accountJson
        event.event = innerEvent

        when:
        def accountNode = objectMapper.readTree(event.event.account)

        then:
        accountNode.get("id").asText() == "556331445652"
    }

    def "should extract state from embedded account JSON"() {
        given:
        def accountJson = '{"id":"556331445652","state":"closed","serviceType":"Fiber"}'
        def event = new BillingAccountStateChangeEvent()
        def innerEvent = new BillingAccountStateChangeEvent.Event()
        innerEvent.account = accountJson
        event.event = innerEvent

        when:
        def accountNode = objectMapper.readTree(event.event.account)

        then:
        accountNode.get("state").asText() == "closed"
        accountNode.get("serviceType").asText() == "Fiber"
    }
}
