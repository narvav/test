package com.att.idp.component

import com.att.ajsc.common.utility.SystemPropertiesLoader
import com.att.idp.idgraphconsumerms.Application
import com.att.idp.idgraphconsumerms.appconfig.config.IDGraphAzureAppConfig

import io.restassured.RestAssured
import io.restassured.http.ContentType
import io.restassured.specification.RequestSpecification
import org.junit.jupiter.api.Timeout
import org.mockito.Mockito
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.boot.test.web.server.LocalServerPort
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Primary
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.scheduling.TaskScheduler
import org.springframework.test.context.ContextConfiguration
import org.springframework.test.context.TestPropertySource
import org.springframework.web.client.RestTemplate
import com.azure.spring.cloud.appconfiguration.config.AppConfigurationRefresh
import org.springframework.boot.autoconfigure.kafka.KafkaProperties
import org.springframework.kafka.test.EmbeddedKafkaBroker
import com.azure.spring.data.cosmos.core.CosmosTemplate
import com.azure.spring.data.cosmos.core.convert.MappingCosmosConverter
import com.azure.spring.data.cosmos.core.mapping.CosmosMappingContext
import spock.lang.Specification
import java.util.concurrent.TimeUnit

@TestPropertySource(properties = [
    // Disable health checks and background tasks
    'management.health.voltage.enabled=false',
    'management.readiness.health.enabled=false',
    'ixp.library-enabled=false',
    'spring.task.scheduling.enabled=false',
    'spring.main.lazy-initialization=true',
    
    // Disable Azure App Configuration
    'spring.cloud.azure.appconfiguration.enabled=false',
    'spring.cloud.azure.appconfiguration.refresh.enabled=false',
    
    // Disable caching
    'spring.cache.type=none',
    
    // Disable auto-configuration for Kafka, Redis, Cosmos
    'spring.autoconfigure.exclude=org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration,com.att.idp.autoconfigure.kafka.KafkaAutoConfiguration,org.springframework.boot.autoconfigure.data.redis.RedisClientAutoConfiguration,com.azure.spring.cloud.autoconfigure.implementation.data.cosmos.CosmosDataAutoConfiguration,com.azure.spring.cloud.autoconfigure.implementation.cosmos.AzureCosmosAutoConfiguration,com.att.idp.idgraph.db.cosmos.CosmosConfiguration',
    
    // Disable Cosmos DB (CosmosDbConfig activates on havingValue=false, so set to true to disable)
    'azure.cosmos.nosql.enabled=true',
    
    // H2 Database configuration to replace Oracle
    'spring.datasource.url=jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1;MODE=Oracle',
    'spring.datasource.driver-class-name=org.h2.Driver',
    'spring.datasource.username=sa',
    'spring.datasource.password=',
    'spring.jpa.database-platform=org.hibernate.dialect.H2Dialect',
    'spring.jpa.hibernate.ddl-auto=none',
    
    // Allow bean definition overriding for test configurations
    'spring.main.allow-bean-definition-overriding=true',
    
    // API client credentials for REST Assured tests
    'apiclient.rest.default.userTypes.guest.username=guestuser',
    'apiclient.rest.default.userTypes.guest.password=guestpass',
    'apiclient.rest.default.userTypes.registered.username=registereduser',
    'apiclient.rest.default.userTypes.registered.password=registeredpass',
    
    // Add any microservice-specific properties (e.g., encryption keys)
    'AES256KEY=0123456789abcdef0123456789abcdef'
])
@ContextConfiguration(classes = [Application.class, CompTestBase.TestConfig.class])
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = [Application.class, CompTestBase.TestConfig.class])
@Timeout(value = 30L, unit = TimeUnit.SECONDS)
abstract class CompTestBase extends Specification {
	
	@Value('${server.servlet.context-path}')
    private String contextPath

	@Value('${api.schemaVersion}')
    private String apiVersion

	@Value('${spring.application.name}')
    private String appPath

	@LocalServerPort
	private int randomServerPort

	@Value('${apiclient.rest.default.userTypes.guest.username}')
	protected String guestUsername

	@Value('${apiclient.rest.default.userTypes.guest.password}')
	protected String guestPassword

	@Value('${apiclient.rest.default.userTypes.registered.username}')
	protected String registeredUsername

	@Value('${apiclient.rest.default.userTypes.registered.password}')
	protected String registeredPassword

    // Azure App Configuration mock
    @SpringBean
    protected AppConfigurationRefresh appConfigurationRefresh = Mock()

    // Task scheduler mock
    @SpringBean
    protected TaskScheduler taskScheduler = Mock()

    // JDBC Template mock (prevents actual DB queries)
    @SpringBean
    protected JdbcTemplate jdbcTemplate = Mock()

    // RestTemplate mock (prevents actual HTTP calls)
    @SpringBean
    protected RestTemplate restTemplate = Mock()

    private static final String host = 'localhost'

    static {
        SystemPropertiesLoader.addSystemProperties()
    }


    def setup() throws Exception {
        RestAssured.baseURI = 'http://' + host + ':' + randomServerPort + contextPath + '/' + appPath.toLowerCase() + '/' + apiVersion
    }

	/*
	 * Base spec with guest user
	 */
	protected RequestSpecification givenBaseSpec() {
		return RestAssured.given()
							.relaxedHTTPSValidation()
							.accept(ContentType.JSON)
							.contentType(ContentType.JSON)
							.auth().basic(guestUsername, guestPassword)
	}

	/*
	 * Base spec for registered user
	 */
    protected RequestSpecification givenRegisterdBaseSpec() {
        return RestAssured.given()
                .relaxedHTTPSValidation()
                .accept(ContentType.JSON)
                .contentType(ContentType.JSON)
                .auth()
                .basic(registeredUsername, registeredPassword)
    }

    @TestConfiguration
    static class TestConfig {
        // Provide KafkaProperties for IDP Kafka auto-configuration
        @Bean
        @Primary
        KafkaProperties kafkaProperties() {
            return new KafkaProperties()
        }

        // Mock CosmosTemplate with converter chain for shared library Cosmos repositories
        @Bean
        @Primary
        CosmosTemplate cosmosTemplate() {
            CosmosTemplate mockTemplate = Mockito.mock(CosmosTemplate.class)
            MappingCosmosConverter mockConverter = Mockito.mock(MappingCosmosConverter.class)
            CosmosMappingContext mockContext = Mockito.mock(CosmosMappingContext.class)
            Mockito.when(mockTemplate.getConverter()).thenReturn(mockConverter)
            Mockito.when(mockConverter.getMappingContext()).thenReturn(mockContext)
            return mockTemplate
        }

        // Mock Azure App Config bean
        @Bean
        @Primary
        IDGraphAzureAppConfig idGraphAzureAppConfig() {
            IDGraphAzureAppConfig mock = Mockito.mock(IDGraphAzureAppConfig.class)
            Mockito.when(mock.isDataSourceRefreshEnabled()).thenReturn(false)
            Mockito.when(mock.getValidationQuery()).thenReturn("SELECT 1")
            Mockito.when(mock.getInitialSize()).thenReturn(1)
            Mockito.when(mock.getMaxSize()).thenReturn(5)
            Mockito.when(mock.getMinSize()).thenReturn(1)
            Mockito.when(mock.isTestOnBorrow()).thenReturn(false)
            Mockito.when(mock.isTestWhileIdle()).thenReturn(false)
            Mockito.when(mock.getQueryTimeout()).thenReturn(30)
            Mockito.when(mock.getEvictTime()).thenReturn(10000)
            Mockito.when(mock.getConnTimeout()).thenReturn(30000)
            return mock
        }
    }

}
