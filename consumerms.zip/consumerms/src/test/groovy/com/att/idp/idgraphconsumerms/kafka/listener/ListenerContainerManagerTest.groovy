package com.att.idp.idgraphconsumerms.kafka.listener

import com.att.idp.idgraphconsumerms.kafka.config.ErrorTrackerProperties
import org.springframework.kafka.config.KafkaListenerEndpointRegistry
import org.springframework.kafka.listener.MessageListenerContainer
import spock.lang.Specification

class ListenerContainerManagerTest extends Specification {

    KafkaListenerEndpointRegistry registry = Mock(KafkaListenerEndpointRegistry)
    ErrorTrackerProperties properties = new ErrorTrackerProperties()
    ListenerContainerManager manager

    def setup() {
        properties.setWindowSeconds(300)
        properties.setThreshold(3)
        manager = new ListenerContainerManager(registry, properties)
    }

    def "T-LCM-1: Below threshold — errors recorded but listener NOT paused"() {
        given: "A listener that has not breached the threshold"
        MessageListenerContainer container = Mock(MessageListenerContainer)
        container.getListenerId() >> "testListener"
        container.isRunning() >> true
        registry.getAllListenerContainers() >> [container]

        when: "2 transient errors are recorded (threshold is 3)"
        manager.onTransientError("testListener")
        manager.onTransientError("testListener")

        then: "Listener is NOT paused"
        0 * container.pause()
    }

    def "T-LCM-2: Threshold breached — listener container is paused, tracker reset"() {
        given: "A listener about to breach threshold"
        MessageListenerContainer container = Mock(MessageListenerContainer)
        container.getListenerId() >> "testListener"
        container.isRunning() >> true
        registry.getAllListenerContainers() >> [container]

        when: "3 transient errors are recorded (threshold is 3)"
        manager.onTransientError("testListener")
        manager.onTransientError("testListener")
        manager.onTransientError("testListener")

        then: "Listener is paused on 3rd error"
        1 * container.pause()

        and: "Tracker is reset (subsequent error does not immediately pause)"
        TransientErrorTracker tracker = manager.getErrorTracker("testListener")
        tracker.currentCount() == 0
    }

    def "T-LCM-4: Per-listener tracking — errors for listener A don't affect listener B"() {
        given: "Two different listeners"
        MessageListenerContainer containerA = Mock(MessageListenerContainer)
        containerA.getListenerId() >> "listenerA"
        containerA.isRunning() >> true

        MessageListenerContainer containerB = Mock(MessageListenerContainer)
        containerB.getListenerId() >> "listenerB"
        containerB.isRunning() >> true

        registry.getAllListenerContainers() >> [containerA, containerB]

        when: "2 errors on A and 1 error on B"
        manager.onTransientError("listenerA")
        manager.onTransientError("listenerA")
        manager.onTransientError("listenerB")

        then: "Neither listener is paused (threshold is 3)"
        0 * containerA.pause()
        0 * containerB.pause()
        manager.getErrorTracker("listenerA").currentCount() == 2
        manager.getErrorTracker("listenerB").currentCount() == 1
    }
}
