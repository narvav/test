// File: src/test/groovy/com/att/idp/idgraphconsumerms/kafka/dmctn/service/ApiRestClientTest.groovy
package com.att.idp.idgraphconsumerms.kafka.dmctn.service

import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails
import com.att.idp.idgraphconsumerms.model.UserAssociationChangeRequest
import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ObjectNode
import org.slf4j.MDC
import org.springframework.http.HttpEntity
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.client.HttpServerErrorException
import org.springframework.web.client.RestTemplate
import spock.lang.Specification
import spock.lang.Unroll

import java.lang.reflect.Field

class ApiRestClientTest extends Specification {

    RestTemplate restTemplateStub = Mock(RestTemplate)
    CosmosFailedEventsWriter cosmosFailedEventsWriter
    ApiRestClient apiRestClient
    ObjectMapper objectMapper

    void setup() {
        cosmosFailedEventsWriter = Mock(CosmosFailedEventsWriter)
        apiRestClient = new ApiRestClient(restTemplateStub)
        setPrivate(apiRestClient, "userAssoServerUrl", "http://service")
        setPrivate(apiRestClient, "userName", "user")
        setPrivate(apiRestClient, "userPassword", "pass")
        apiRestClient.cosmosFailedEventsWriter = cosmosFailedEventsWriter
        objectMapper = new ObjectMapper()
        MDC.clear()
    }

    @Unroll
    def "should handle POST call (success path) for #scenarioName"() {
        given:
        String endpoint = "/change"
        String fullUrl = "http://service" + endpoint
        ObjectNode body = objectMapper.createObjectNode().put("result", expectedText)
        def okResponse = new ResponseEntity<JsonNode>(body, HttpStatus.OK)
        UserAssociationChangeRequest request = new UserAssociationChangeRequest(guid: guid,
                suppressNotification: suppressFlag, transactionType: txType)

        when:
        def response = apiRestClient.sendPostRequest(endpoint, request, "SubscriberChangeEvent")

        then:
        response == null
        1 * restTemplateStub.exchange(fullUrl,
                HttpMethod.POST,
                { HttpEntity<String> he ->
                    assert he.body.contains(guid)
                    assert he.headers.getFirst("Authorization").startsWith("Basic")
                    assert he.headers.getFirst("Content-Type") == "application/json"
                    true
                },
                JsonNode.class) >> okResponse
        0 * _

        where:
        scenarioName     | guid     | suppressFlag | txType   | expectedText
        "standard guid"  | "g-123"  | "Y"          | "CREATE" | "ok"
    }

    def "should handle non-OK response (failure path) and still return null"() {
        given:
        String endpoint = "/change"
        String fullUrl = "http://service" + endpoint
        ObjectNode body = objectMapper.createObjectNode().put("error", "invalid")
        def badResponse = new ResponseEntity<JsonNode>(body, HttpStatus.BAD_REQUEST)
        UserAssociationChangeRequest request = new UserAssociationChangeRequest(guid: "bad-guid",
                suppressNotification: "N", transactionType: "UPDATE")

        when:
        def response = apiRestClient.sendPostRequest(endpoint, request, "SubscriberChangeEvent")

        then:
        response == null
        1 * restTemplateStub.exchange(fullUrl,
                HttpMethod.POST,
                { HttpEntity<String> he -> he.body.contains("bad-guid") },
                JsonNode.class) >> badResponse
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
            assert it.accountId == "bad-guid"
            assert it.requestPayload.contains('"bad-guid"')
            assert it.errorDetails.toString().contains("400 BAD_REQUEST")
            true
        } as FailedEventDetails)
        0 * _
    }

    def "should handle retry scenario (server error) returning exception in plain unit test"() {
        given:
        String endpoint = "/retry"
        String fullUrl = "http://service" + endpoint
        def serverError = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "boom")
        UserAssociationChangeRequest request = new UserAssociationChangeRequest(guid: "retry-guid",
                suppressNotification: "Y", transactionType: "CREATE")

        when:
        apiRestClient.sendPostRequest(endpoint, request, "SubscriberChangeEvent")

        then:
        thrown(HttpServerErrorException)
        1 * restTemplateStub.exchange(fullUrl,
                HttpMethod.POST,
                { HttpEntity<String> he -> he.body.contains("retry-guid") },
                JsonNode.class) >> { throw serverError }
        0 * _
    }

    def "should save failed event for 202 Accepted response"() {
        given:
        String endpoint = "/changeStatus"
        String fullUrl = "http://service" + endpoint
        def acceptedResponse = new ResponseEntity<JsonNode>(null, HttpStatus.ACCEPTED)
        def req = new UserAssociationChangeRequest(guid: "guid-202", suppressNotification: "N", transactionType: "UPDATE")

        when:
        apiRestClient.sendPostRequest(endpoint, req, "SubscriberChangeEvent")

        then:
        1 * restTemplateStub.exchange(fullUrl, HttpMethod.POST, _ as HttpEntity<String>, JsonNode.class) >> acceptedResponse
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
            assert it.accountId == "guid-202"
            assert it.errorDetails.toString().contains("202 ACCEPTED")
            true
        } as FailedEventDetails)
        0 * _
    }

    def "should not save failed event for OK with null body"() {
        given:
        String endpoint = "/oknull"
        String fullUrl = "http://service" + endpoint
        def okNull = new ResponseEntity<JsonNode>(null, HttpStatus.OK)
        def req = new UserAssociationChangeRequest(guid: "ok-null", suppressNotification: "Y", transactionType: "CREATE")

        when:
        apiRestClient.sendPostRequest(endpoint, req, "SubscriberChangeEvent")

        then:
        1 * restTemplateStub.exchange(fullUrl, HttpMethod.POST, _ as HttpEntity<String>, JsonNode.class) >> okNull
        0 * cosmosFailedEventsWriter._
        0 * _
    }

    def "should save failed event for unauthorized 401 response"() {
        given:
        String endpoint = "/auth"
        String fullUrl = "http://service" + endpoint
        def unauthorized = new ResponseEntity<JsonNode>(null, HttpStatus.UNAUTHORIZED)
        def req = new UserAssociationChangeRequest(guid: "unauth-guid", suppressNotification: "N", transactionType: "UPDATE")

        when:
        apiRestClient.sendPostRequest(endpoint, req, "SubscriberChangeEvent")

        then:
        1 * restTemplateStub.exchange(fullUrl, HttpMethod.POST, _ as HttpEntity<String>, JsonNode.class) >> unauthorized
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
            assert it.accountId == "unauth-guid"
            assert it.errorDetails.toString().contains("401 UNAUTHORIZED")
            true
        } as FailedEventDetails)
        0 * _
    }

    def "should handle generic runtime exception and save failed event (non-retryable path)"() {
        given:
        String endpoint = "/generic"
        String fullUrl = "http://service" + endpoint
        def ex = new RuntimeException("boom-ex")
        def req = new UserAssociationChangeRequest(guid: "gen-ex", suppressNotification: "N", transactionType: "DELETE")

        when:
        apiRestClient.sendPostRequest(endpoint, req, "SubscriberChangeEvent")

        then:
        1 * restTemplateStub.exchange(fullUrl, HttpMethod.POST, _ as HttpEntity<String>, JsonNode.class) >> { throw ex }
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
            assert it.accountId == "gen-ex"
            assert it.errorDetails.toString().toLowerCase().contains("boom-ex")
            true
        } as FailedEventDetails)
        0 * _
    }


    private static void setPrivate(Object target, String fieldName, Object value) {
        Field f = target.getClass().getDeclaredField(fieldName)
        f.accessible = true
        f.set(target, value)
    }
}