package com.att.idp.idgraphconsumerms.kafka.listener

import com.att.idp.idgraphconsumerms.bsse.reverse.BsseReverseMigrationEventProcessor
import org.springframework.kafka.support.Acknowledgment
import org.springframework.messaging.MessageHeaders
import spock.lang.Specification
import spock.lang.Unroll

class BsseReverseMigrationEventInternalListenerSpec extends Specification {

    BsseReverseMigrationEventProcessor processor
    BsseReverseMigrationEventInternalListener listener

    void setup() {
        processor = Mock(BsseReverseMigrationEventProcessor)
        listener = new BsseReverseMigrationEventInternalListener(processor)
    }

    @Unroll
    def "should delegate reverse migration event processing for #scenarioName"() {
        given: "A reverse migration payload and mocks"
        String msg = payload
        MessageHeaders headers = Mock(MessageHeaders)
        Acknowledgment ack = Mock(Acknowledgment)

        when: "consumeBsseReverseMigrationEvent is invoked"
        listener.consumeBsseReverseMigrationEvent(msg, headers, ack)

        then: "Processor receives the message"
        1 * processor.processEvent(msg, headers, ack)
        0 * _

        where: "Different payloads are used"
        scenarioName             | payload
        "standard reverse event"| '{"eventType":"ReverseMigratedData","migrationId":"mid-1"}'
        "minimal payload"       | '{"eventType":"ReverseMigratedData"}'
    }

    def "should propagate processor exception"() {
        given: "A payload that triggers processor exception"
        String msg = '{"eventType":"ReverseMigratedData","migrationId":"mid-err"}'
        MessageHeaders headers = Mock(MessageHeaders)
        Acknowledgment ack = Mock(Acknowledgment)
        RuntimeException failure = new RuntimeException("processor failure")

        when: "consumeBsseReverseMigrationEvent is invoked"
        listener.consumeBsseReverseMigrationEvent(msg, headers, ack)

        then: "Processor throws and propagates"
        1 * processor.processEvent(msg, headers, ack) >> { throw failure }
        RuntimeException ex = thrown()
        ex.message == "processor failure"
        0 * _
    }
}
