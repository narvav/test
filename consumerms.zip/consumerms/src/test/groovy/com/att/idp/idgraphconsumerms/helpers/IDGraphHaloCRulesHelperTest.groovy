package com.att.idp.idgraphconsumerms.helpers

import com.att.idp.component.CompTestBase
import com.att.idp.idgraphconsumerms.utils.ConsumerUtil
import com.fasterxml.jackson.core.type.TypeReference
import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import spock.lang.Unroll

class IDGraphHaloCRulesHelperTest extends Specification {

	static Map<String, Object> readJsonFileToMap(String filePath) throws IOException {
		ObjectMapper objectMapper = new ObjectMapper()
		try (InputStream inputStream = CompTestBase.class.getClassLoader().getResourceAsStream(filePath)) {
			if (inputStream == null) {
				throw new IOException("File not found: " + filePath)
			}
			return objectMapper.readValue(inputStream, new TypeReference<Map<String, Object>>() {})
		}
	}

	static String readJsonFileAsString(String filePath) throws IOException {
		try (InputStream inputStream = CompTestBase.class.getClassLoader().getResourceAsStream(filePath)) {
			if (inputStream == null) {
				throw new IOException("File not found: " + filePath)
			}
			return new String(inputStream.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8)
		}
	}

	IDGraphHaloCRulesHelper helper = new IDGraphHaloCRulesHelper()

	def setup() {
		ReflectionTestUtils.setField(helper, "haloCSubEvents", "sub1|sub2|SLID")
		ReflectionTestUtils.setField(helper, "haloCSubEventsUpdateMember", "update1|update2")
		ReflectionTestUtils.setField(helper, "haloCSubEventsAddMember", "svc1|svc2")
		ReflectionTestUtils.setField(helper, "haloCServices", "svc3|svc4")
		ReflectionTestUtils.setField(helper, "haloCProfileInfoUpdate", "svc5|svc6")
	}

	def "processHaloCMessage returns false when event is null"() {
		when:
		boolean resultNull = helper.processHaloCMessage(null)

		then:
		0 * _

		and:
		resultNull == false
	}

	def "processHaloCMessage returns false when event is empty"() {
		given:
		Map<String, Object> event = [:]

		when:
		boolean result = helper.processHaloCMessage(event)

		then:
		0 * _

		and:
		result == false
	}

	def "processHaloCMessage returns false for invalid subEvent in filter list"() {
		given: "event with subEvent NOT in haloCSubEvents filter list so it passes subEvent check, but AddMember with no services returns false"
		Map<String, Object> event = [subEvent: "validSub", eventname: "AddMember"]

		when:
		boolean result = helper.processHaloCMessage(event)

		then:
		0 * _

		and:
		result == false
	}

	def "processHaloCMessage returns false when subEvent is in haloCSubEvents list"() {
		given: "event with subEvent SLID which IS in haloCSubEvents list - validateCommonRules rejects it"
		Map<String, Object> event = [subEvent: "SLID", filtercGate: "N", eventname: "AddMember"]

		when:
		boolean result = helper.processHaloCMessage(event)

		then:
		0 * _

		and:
		result == false
	}

	def "processHaloCMessage returns false when filtercGate is Y"() {
		given: "event with valid subEvent but filtercGate Y which is filtered"
		Map<String, Object> event = [subEvent: "validSub", filtercGate: "Y", eventname: "AddMember"]

		when:
		boolean result = helper.processHaloCMessage(event)

		then:
		0 * _

		and:
		result == false
	}

	def "processHaloCMessage returns true for valid AddMember with SLID subEvent passing common rules"() {
		given: "event with subEvent not in filter list (common rules pass) and eventname AddMember with SLID"
		Map<String, Object> event = [subEvent: "notInList", filtercGate: "N", eventname: "AddMember"]

		when: "subEvent for processAddMember is read from event"
		boolean result = helper.processHaloCMessage(event)

		then:
		0 * _

		and: "returns false because subEvent notInList is not SLID and no services"
		result == false
	}

	@Unroll
	def "processAddMember returns #expected for subEvent #subEvent"() {
		given: "a helper instance with configured services"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()
		ReflectionTestUtils.setField(testHelper, "haloCServices", "svc1|svc2")

		and: "event data"
		Map<String, Object> event = [
				subEvent  : subEvent,
				services  : services,
				memberInfo: memberInfo
		]

		and: "extract allServices from event"
		List<Map<String, Object>> allServices = ConsumerUtil.extractAllServicesWithFallback(event)

		when: "processAddMember is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processAddMember", String.class, List.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, subEvent, allServices)

		then:
		0 * _

		and:
		result == expected

		where:
		subEvent     | services                             | memberInfo                                       || expected
		"NullifyBAN" | null                                 | null                                             || false
		"SLID"       | null                                 | null                                             || true
		"other"      | [[serviceType: "IPTV"]]              | null                                             || true
		"other"      | [[serviceType: "not_in_list"]]       | null                                             || false
		// memberInfo.services is NOT a fallback path for AddMember events;
		// extractAllServicesWithFallback only falls back via memberInfo for AddRemoveServicesList events.
		// With services=null and no AddRemoveServicesList eventname, allServices=null -> returns false.
		"other"      | null                                 | [[services: [serviceType: "MOSUB"]]]             || false
		"other"      | null                                 | [[services: [serviceType: "not_MOSUB"]]]         || false
		// INDIVIDUALUSER is in ADD_MEMBER_ALLOWED_SERVICE_TYPES -> must return true
		"other"      | [[serviceType: "INDIVIDUALUSER"]]    | null                                             || true
		// Additional allowed service types verified against ADD_MEMBER_ALLOWED_SERVICE_TYPES
		"other"      | [[serviceType: "MOSUB"]]             | null                                             || true
		"other"      | [[serviceType: "MOBILITY"]]          | null                                             || true
		"other"      | [[serviceType: "VAS"]]               | null                                             || true
		"other"      | [[serviceType: "CONNECTEDHOME"]]     | null                                             || true
		"other"      | [[serviceType: "DIRECTV"]]           | null                                             || true
	}

	@Unroll
	def "processUpdateMember returns #expected for scenario #scenarioName"() {
		given: "a helper with configured update member list"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()
		ReflectionTestUtils.setField(testHelper, "haloCSubEventsUpdateMember", "update1|update2")

		and: "event data"
		Map<String, Object> event = eventData

		when: "processUpdateMember is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processUpdateMember", Map.class, String.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, event, subEvent)

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                          | subEvent  | eventData                                              || expected
		"subEvent in update member list"      | "update1" | [subEvent: "update1"]                                  || false
		"subEvent update2 in list"            | "update2" | [subEvent: "update2"]                                  || false
		"AddSWH with null proofingVersion"    | "AddSWH"  | [subEvent: "AddSWH"]                                   || false
		"AddSWH with proofingVersion present" | "AddSWH"  | [subEvent: "AddSWH", proofingVersion: "v1"]            || true
		"tokenIndicator not sbclightspeed"    | "other"   | [subEvent: "other", tokenIndicator: "notlight"]        || false
		"tokenIndicator is sbclightspeed"     | "other"   | [subEvent: "other", tokenIndicator: "sbclightspeed"]   || true
		"no tokenIndicator returns true"      | "other"   | [subEvent: "other"]                                    || true
	}

	@Unroll
	def "processUpdateProfileInfo returns #expected for subEvent #subEvent with password_dirty #passwordDirty"() {
		given: "a helper with configured profile info update list"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()
		ReflectionTestUtils.setField(testHelper, "haloCProfileInfoUpdate", "svc5|svc6")

		and: "event data"
		Map<String, Object> event = [
				subEvent      : subEvent,
				password_dirty: passwordDirty,
				services      : services
		]

		and: "extract allServices from event"
		List<Map<String, Object>> allServices = ConsumerUtil.extractAllServicesWithFallback(event)

		when: "processUpdateProfileInfo is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processUpdateProfileInfo", Map.class, String.class, List.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, event, subEvent, allServices)

		then:
		0 * _

		and:
		result == expected

		where:
		subEvent            | passwordDirty | services                    || expected
		"SyncSouthEast"     | "any"         | [[serviceType: "svc5"]]    || false
		"UpdateProfileInfo" | null          | [[serviceType: "svc5"]]    || false
		"UpdateProfileInfo" | "dirty"       | [[serviceType: "svc5"]]    || true
		"UpdateProfileInfo" | "dirty"       | [[serviceType: "svc7"]]    || false
		"OtherEvent"        | "dirty"       | [[serviceType: "svc5"]]    || true
		"OtherEvent"        | "dirty"       | [[serviceType: "svc8"]]    || false
		"OtherEvent"        | "dirty"       | null                       || true
	}

	@Unroll
	def "processAddServices returns #expected for subEvent #subEvent"() {
		given: "a helper instance"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()

		when: "processAddServices is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processAddServices", Map.class, String.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, event, subEvent)

		then:
		0 * _

		and:
		result == expected

		where:
		subEvent            | event                                                         || expected
		"SyncSouthEast"     | [subEvent: "SyncSouthEast"]                                   || false
		"UpdateProfileInfo" | [subEvent: "UpdateProfileInfo"]                                || false
		"UpdateProfileInfo" | [subEvent: "UpdateProfileInfo", password_dirty: "dirty"]       || false
		"OtherEvent"        | [subEvent: "OtherEvent"]                                      || true
	}

	@Unroll
	def "processAddRemoveServices returns #expected for subEvent #subEvent"() {
		given: "a helper instance"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()

		and: "event data"
		Map<String, Object> event = [
				subEvent      : subEvent,
				removeServices: removeServices
		]

		when: "processAddRemoveServices is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processAddRemoveServices", Map.class, String.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, event, subEvent)

		then:
		0 * _

		and:
		result == expected

		where:
		subEvent             | removeServices                     || expected
		"HomeZoneDisconnect" | [portalProvider: "AT&T NAP"]       || true
		"HomeZoneDisconnect" | [portalProvider: "OtherProvider"]  || false
		"HomeZoneDisconnect" | null                               || true
		"OtherEvent"         | [portalProvider: "AT&T NAP"]       || true
	}

	// Spock test for processAddMemberList (lines 223-245)
	@Unroll
	def "processAddMemberList returns #expected for scenario #scenarioName"() {
		given: "a helper with configured services"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()
		ReflectionTestUtils.setField(testHelper, "haloCServices", "svc3|svc4")

		and: "event data with callingSystemId and handle at event level (must use lowercase 'handle' matching ConsumerConstants.HANDLE)"
		Map<String, Object> event = [
				memberInfo     : memberInfo,
				subEvent       : subEvent,
				callingSystemId: callingSystemId,
				handle         : handle
		]

		and: "extract allServices from event"
		List<Map<String, Object>> allServices = ConsumerUtil.extractAllServicesWithFallback(event)

		when: "processAddMemberList is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processAddMemberList", Map.class, String.class, List.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, event, subEvent, allServices)

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                           | callingSystemId | handle        | memberInfo                                                                         | subEvent  || expected
		"CPR callingSystemId at event level"   | "CPR"           | null          | [[services: [serviceType: "svc3"]]]                                                | "Any"     || false
		"sbciptv handle at event level"        | null            | "sbciptv123"  | [[services: [serviceType: "svc3"]]]                                                | "Any"     || false
		"null memberInfo no services"          | null            | null          | null                                                                               | "Any"     || true
		"Autogen subEvent with IPTV service"   | null            | null          | [[services: [serviceType: "IPTV"]]]                                                | "Autogen" || true
		"serviceType not in services list"     | null            | null          | [[services: [serviceType: "not_in_list"]]]                                         | "Any"     || true
		"valid serviceType in services list"   | null            | null          | [[services: [serviceType: "svc3"]]]                                                | "Any"     || true
		"multiple members all valid"           | null            | null          | [[services: [serviceType: "svc3"]], [services: [serviceType: "svc4"]]]             | "Any"     || true
		"multiple members one invalid"         | null            | null          | [[services: [serviceType: "svc3"]], [services: [serviceType: "not_in_list"]]]      | "Any"     || true
	}

	// src/test/groovy/com/att/idp/idgraphconsumerms/helpers/IDGraphHaloCRulesHelperSpec.groovy
	@Unroll
	def "processRemoveServicesList returns #expected for scenario #scenarioName"() {
		given: "a helper with configured services"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()
		ReflectionTestUtils.setField(testHelper, "haloCServices", "svc7|svc8")

		and: "event data"
		Map<String, Object> event = [
				memberInfo: memberInfo,
				subEvent  : subEvent
		]

		and: "extract allServices from event"
		List<Map<String, Object>> allServices = ConsumerUtil.extractAllServicesWithFallback(event)

		when: "processRemoveServicesList is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processRemoveServicesList", Map.class, String.class, List.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, event, subEvent, allServices)

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                               | memberInfo                                                                                                | subEvent             || expected
		"null memberInfo returns true"             | null                                                                                                      | "RemoveServicesList" || true
		"sbciptv handle with non-IPTV service"     | [[Handle: "sbciptv123", services: [serviceType: "svc7"]]]                                                 | "RemoveServicesList" || true
		"sbciptv handle with IPTV in svcList"      | [[Handle: "sbciptv123", services: [serviceType: "IPTV"]]]                                                 | "RemoveServicesList" || true
		"ChangeToBYOP returns false"               | [[Handle: "h1", services: [serviceType: "svc7"]]]                                                         | "ChangeToBYOP"       || false
		"serviceType not in services list"         | [[Handle: "h1", services: [serviceType: "not_in_list"]]]                                                  | "RemoveServicesList" || true
		"valid serviceType in services list"       | [[Handle: "h1", services: [serviceType: "svc7"]]]                                                         | "RemoveServicesList" || true
		"multiple one sbciptv with non-IPTV"       | [[Handle: "h1", services: [serviceType: "svc7"]], [Handle: "sbciptv999", services: [serviceType: "svc7"]]] | "RemoveServicesList" || true
		"multiple all valid"                       | [[Handle: "h1", services: [serviceType: "svc7"]], [Handle: "h2", services: [serviceType: "svc8"]]]        | "RemoveServicesList" || true
	}

	@Unroll
	def "processUpdateServicesStatusList returns #expected for scenario #scenarioName"() {
		given: "a helper with configured services"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()
		ReflectionTestUtils.setField(testHelper, "haloCServices", "svc7|svc8")

		and: "extract allServices from event"
		List<Map<String, Object>> allServices = ConsumerUtil.extractAllServicesWithFallback(event)

		when: "processUpdateServicesStatusList is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processUpdateServicesStatusList", List.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, [allServices] as Object[])

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                       | event                                    || expected
		"no services returns true"         | [:]                                      || true
		"serviceType not in list"          | [services: [[serviceType: "svc9"]]]      || false
		"serviceType svc7 in list"         | [services: [[serviceType: "svc7"]]]      || true
		"serviceType svc8 in list"         | [services: [[serviceType: "svc8"]]]      || true
		"serviceType random not in list"   | [services: [[serviceType: "random"]]]    || false
	}

	@Unroll
	def "processUpdateServicesList returns #expected for scenario #scenarioName"() {
		given: "a helper with configured services"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()
		ReflectionTestUtils.setField(testHelper, "haloCServices", "svc7|svc8|svc10")

		and: "extract allServices from event"
		List<Map<String, Object>> allServices = ConsumerUtil.extractAllServicesWithFallback(event)

		when: "processUpdateServicesList is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processUpdateServicesList", List.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, [allServices] as Object[])

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                      | event                                     || expected
		"no services returns true"        | [:]                                       || true
		"serviceType not in list"         | [services: [[serviceType: "svc9"]]]       || false
		"serviceType svc7 in list"        | [services: [[serviceType: "svc7"]]]       || true
		"serviceType svc8 in list"        | [services: [[serviceType: "svc8"]]]       || true
		"serviceType svc10 in list"       | [services: [[serviceType: "svc10"]]]      || true
		"serviceType random not in list"  | [services: [[serviceType: "random"]]]     || false
	}

	@Unroll
	def "processDeleteMemberList returns #expected for scenario #scenarioName"() {
		given: "a helper instance"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()

		and: "event data"
		Map<String, Object> event = [
				memberInfo: memberInfo
		]

		and: "extract allServices from event"
		List<Map<String, Object>> allServices = ConsumerUtil.extractAllServicesWithFallback(event)

		when: "processDeleteMemberList is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processDeleteMemberList", Map.class, String.class, List.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, event, subEvent, allServices)

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                                 | memberInfo                                                                                                | subEvent                   || expected
		"VoIPSubGettingTerminated returns false"     | null                                                                                                      | "VoIPSubGettingTerminated" || false
		"DeleteMemberList null memberInfo"           | null                                                                                                      | "DeleteMemberList"         || true
		"sbciptv handle with non-IPTV service"       | [[Handle: "sbciptv123", services: [serviceType: "svc7"]]]                                                 | "DeleteMemberList"         || true
		"sbciptv handle with IPTV service"           | [[Handle: "sbciptv123", services: [serviceType: "IPTV"]]]                                                 | "DeleteMemberList"         || true
		"non-sbciptv handle"                         | [[Handle: "h1", services: [serviceType: "svc7"]]]                                                         | "DeleteMemberList"         || true
		"multiple one sbciptv with non-IPTV"         | [[Handle: "h1", services: [serviceType: "svc7"]], [Handle: "sbciptv999", services: [serviceType: "svc7"]]] | "DeleteMemberList"         || true
		"multiple all valid"                         | [[Handle: "h1", services: [serviceType: "svc7"]], [Handle: "h2", services: [serviceType: "svc8"]]]        | "DeleteMemberList"         || true
		"other subEvent returns true"                | [[Handle: "sbciptv123", services: [serviceType: "svc7"]]]                                                 | "OtherEvent"               || true
	}

	@Unroll
	def "processAddServicesList returns #expected for scenario #scenarioName"() {
		given: "a helper with configured services"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()
		ReflectionTestUtils.setField(testHelper, "haloCServices", "svc7|svc8")

		and: "extract allServices from event"
		List<Map<String, Object>> allServices = ConsumerUtil.extractAllServicesWithFallback(event)

		when: "processAddServicesList is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processAddServicesList", List.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, [allServices] as Object[])

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                     | event                                    || expected
		"no services returns true"       | [:]                                      || true
		"serviceType not in list"        | [services: [[serviceType: "svc9"]]]      || false
		"serviceType svc7 in list"       | [services: [[serviceType: "svc7"]]]      || true
		"serviceType svc8 in list"       | [services: [[serviceType: "svc8"]]]      || true
		"serviceType random not in list" | [services: [[serviceType: "random"]]]    || false
	}

	@Unroll
	def "processAddRemoveServicesList returns #expected for scenario #scenarioName"() {
		given: "a helper with configured services"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()
		ReflectionTestUtils.setField(testHelper, "haloCServices", "svc15|svc16")

		and: "event data"
		Map<String, Object> event = [
				memberInfo: memberInfo,
				subEvent  : subEvent
		]

		and: "extract allServices from event"
		List<Map<String, Object>> allServices = ConsumerUtil.extractAllServicesWithFallback(event)

		when: "processAddRemoveServicesList is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processAddRemoveServicesList", List.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, [allServices] as Object[])

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                              | memberInfo                                                                                                  | subEvent                || expected
		"null memberInfo returns true"            | null                                                                                                        | "AddRemoveServicesList" || true
		"serviceType in rejection list"           | [[Handle: "h1", services: [serviceType: "svc15"]]]                                                          | "AddRemoveServicesList" || true
		"serviceType IPTV not in rejection list"  | [[Handle: "sbciptv123", services: [serviceType: "IPTV"]]]                                                   | "AddRemoveServicesList" || true
		"serviceType not in rejection list"       | [[Handle: "h1", services: [serviceType: "not_in_list"]]]                                                    | "AddRemoveServicesList" || true
		"svc16 in rejection list"                 | [[Handle: "h2", services: [serviceType: "svc16"]]]                                                          | "AddRemoveServicesList" || true
		"multiple all not in list"                | [[Handle: "h1", services: [serviceType: "IPTV"]], [Handle: "h2", services: [serviceType: "other"]]]         | "AddRemoveServicesList" || true
	}

	def "processAddRemoveServicesList returns false for memberInfo with services not in rejection list"() {
		given: "a helper with configured services"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()
		ReflectionTestUtils.setField(testHelper, "haloCServices", "svc15|svc16")

		and: "event data with memberInfo containing services NOT in the rejection list"
		List<Map<String, Object>> memberInfo = [
				[Handle: "sbciptv123", services: [serviceType: "NOTIPTV"]],
				[Handle: "other", services: [serviceType: "svc17"]]
		]
		Map<String, Object> event = [subEvent: "AddRemoveServicesList", memberInfo: memberInfo]

		and: "extract allServices from event"
		List<Map<String, Object>> allServices = ConsumerUtil.extractAllServicesWithFallback(event)

		when: "processAddRemoveServicesList is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processAddRemoveServicesList", List.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, [allServices] as Object[])

		then:
		0 * _

		and: "returns false because NOTIPTV and svc17 are not in [svc15, svc16]"
		result == true
	}

	// New comprehensive test cases for the corrected validation logic
	@Unroll
	def "validateServices with corrected logic returns #expected for scenario #scenarioName"() {
		given: "a helper with configured services"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()
		ReflectionTestUtils.setField(testHelper, "haloCServices", "svc1|svc2|svc3")

		when: "validateServices is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("validateServices", List.class, String.class, ArrayList.class)
		method.setAccessible(true)
		ArrayList allowedList = new ArrayList(["svc1", "svc2", "svc3"])
		boolean result = method.invoke(testHelper, services, subEvent, allowedList)

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                                    | services                                                                    | subEvent || expected
		"null services returns true"                    | null                                                                        | "Any"    || true
		"empty services returns true"                   | []                                                                          | "Any"    || false
		"all services null returns true"                | [[serviceType: null], [serviceType: null]]                                 | "Any"    || false
		"single valid service returns true"             | [[serviceType: "svc1"]]                                                     | "Any"    || true
		"single invalid service returns false"          | [[serviceType: "invalid"]]                                                  | "Any"    || false
		"all services valid returns true"               | [[serviceType: "svc1"], [serviceType: "svc2"]]                             | "Any"    || true
		"all services invalid returns false"            | [[serviceType: "invalid1"], [serviceType: "invalid2"]]                     | "Any"    || false
		"mixed valid and invalid returns true"          | [[serviceType: "svc1"], [serviceType: "invalid"]]                          | "Any"    || true
		"mixed null and valid returns true"             | [[serviceType: null], [serviceType: "svc1"]]                               | "Any"    || true
		"mixed null and invalid returns false"          | [[serviceType: null], [serviceType: "invalid"]]                            | "Any"    || false
		"Autogen with IPTV returns false immediately"   | [[serviceType: "IPTV"], [serviceType: "svc1"]]                             | "Autogen"|| false
		"multiple with one valid at end returns true"   | [[serviceType: "invalid1"], [serviceType: "invalid2"], [serviceType: "svc1"]] | "Any"    || true
	}

	@Unroll
	def "multiple validation methods with corrected logic return #expected for #methodName"() {
		given: "a helper with configured services"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()

		when: "validation method is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod(methodName, List.class, ArrayList.class)
		method.setAccessible(true)
		ArrayList allowedList = new ArrayList(["svc1", "svc2"])
		boolean result = method.invoke(testHelper, services, allowedList)

		then:
		0 * _

		and:
		result == expected

		where:
		methodName                        | services                                                    || expected
		"validateUpdateServicesStatus"    | [[serviceType: "svc1"], [serviceType: "invalid"]]          || true
		"validateUpdateServicesStatus"    | [[serviceType: "invalid1"], [serviceType: "invalid2"]]     || false
		"validateUpdateServices"          | [[serviceType: "svc1"], [serviceType: "invalid"]]          || true
		"validateUpdateServices"          | [[serviceType: "invalid1"], [serviceType: "invalid2"]]     || false
		"validateAddServices"             | [[serviceType: "svc1"], [serviceType: "invalid"]]          || true
		"validateAddServices"             | [[serviceType: "invalid1"], [serviceType: "invalid2"]]     || false
	}
	@Unroll
	def "processUpdateMember returns false when subEvent #subEvent is in haloCSubEventsUpdateMember"() {
		given: "a helper with configured update member list"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()
		ReflectionTestUtils.setField(testHelper, "haloCSubEventsUpdateMember", "update1|update2")

		and: "event with subEvent in the filter list"
		Map<String, Object> event = [subEvent: subEvent]

		when: "processUpdateMember is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processUpdateMember", Map.class, String.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, event, subEvent)

		then:
		0 * _

		and:
		result == false

		where:
		subEvent << ["update1", "update2"]
	}

	@Unroll
	def "processEventRules should return #expectedResult for eventname #eventName with subEvent #subEvent"() {
		given: "a helper with configured properties"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()
		ReflectionTestUtils.setField(testHelper, "haloCSubEvents", "sub1|sub2|SLID")
		ReflectionTestUtils.setField(testHelper, "haloCSubEventsUpdateMember", "update1|update2")
		ReflectionTestUtils.setField(testHelper, "haloCServices", "svc3|svc4")
		ReflectionTestUtils.setField(testHelper, "haloCProfileInfoUpdate", "svc5|svc6")

		and: "event data with specific eventname and subEvent"
		Map<String, Object> event = [
				eventname: eventName,
				subEvent : subEvent
		]
		if (additionalData != null) {
			event.putAll(additionalData)
		}

		when: "processEventRules is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processEventRules", Map.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, event)

		then: "result matches expected outcome"
		0 * _

		and:
		result == expectedResult

		where: "various event scenarios are tested"
		scenarioName                           | eventName                  | subEvent                       | additionalData                                                                    || expectedResult
		"AddMember with NullifyBAN"            | "AddMember"                | "NullifyBAN"                   | null                                                                              || false
		"AddMember with SLID"                  | "AddMember"                | "SLID"                         | null                                                                              || true
		"AddMember with valid service"         | "AddMember"                | "Other"                        | [services: [[serviceType: "IPTV"]]]                                               || true
		"AddMember with INDIVIDUALUSER"       | "AddMember"                | "Other"                        | [services: [[serviceType: "INDIVIDUALUSER"]]]                                     || true
		"UpdateMember with valid token"        | "UpdateMember"             | "Other"                        | [tokenIndicator: "sbclightspeed"]                                                 || true
		"UpdateMember in filter list"          | "UpdateMember"             | "update1"                      | null                                                                              || false
		"UpdateProfileInfo with SyncSouthEast" | "UpdateProfileInfo"        | "SyncSouthEast"                | null                                                                              || false
		"UpdateProfileInfo valid svc in list"  | "UpdateProfileInfo"        | "Other"                        | [password_dirty: "dirty", services: [[serviceType: "svc5"]]]                      || true
		"UpdateProfileInfo svc not in list"    | "UpdateProfileInfo"        | "Other"                        | [password_dirty: "dirty", services: [[serviceType: "svc7"]]]                      || false
		"ChangePassword always returns true"   | "ChangePassword"           | "Any"                          | null                                                                              || true
		"AddServices with valid data"          | "AddServices"              | "Other"                        | null                                                                              || true
		"AddServices with SyncSouthEast"       | "AddServices"              | "SyncSouthEast"                | null                                                                              || false
		"AddRemoveServices valid"              | "AddRemoveServices"        | "Other"                        | null                                                                              || true
		"AddRemoveServices HomeZone valid"     | "AddRemoveServices"        | "HomeZoneDisconnect"           | [removeServices: [portalProvider: "AT&T NAP"]]                                    || true
		"AddRemoveServices HomeZone invalid"   | "AddRemoveServices"        | "HomeZoneDisconnect"           | [removeServices: [portalProvider: "Other"]]                                       || false
		"AddMemberList with valid members"     | "AddMemberList"            | "Any"                          | [memberInfo: [[services: [serviceType: "svc3"]]]]                                 || true
		"AddMemberList with null memberInfo"   | "AddMemberList"            | "Any"                          | [memberInfo: null]                                                                || true
		"RemoveServicesList with valid data"   | "RemoveServicesList"       | "RemoveServicesList"           | [memberInfo: [[Handle: "h1", services: [serviceType: "svc3"]]]]                   || true
		"RemoveServicesList with null"         | "RemoveServicesList"       | "RemoveServicesList"           | [memberInfo: null]                                                                || true
		"UpdateServicesList no svc"            | "UpdateServicesList"       | "Any"                          | [:]                                                                               || true
		"UpdateServicesList in list"           | "UpdateServicesList"       | "Any"                          | [services: [[serviceType: "svc3"]]]                                               || true
		"UpdateServicesList not in list"       | "UpdateServicesList"       | "Any"                          | [services: [[serviceType: "svc9"]]]                                               || false
		"DeleteMemberList VoIPSub"             | "DeleteMemberList"         | "VoIPSubGettingTerminated"     | null                                                                              || false
		"DeleteMemberList valid"               | "DeleteMemberList"         | "DeleteMemberList"             | [memberInfo: [[Handle: "h1", services: [serviceType: "svc7"]]]]                   || true
		"UpdateMemberList always returns true" | "UpdateMemberList"         | "Any"                          | null                                                                              || true
		"UpdateAliasList always returns true"  | "UpdateAliasList"          | "Any"                          | null                                                                              || true
		"Unknown event returns false"          | "UnknownEvent"             | "Any"                          | null                                                                              || false
		"InvalidEvent returns false"           | "InvalidEvent"             | "Any"                          | null                                                                              || false
	}

	def "processEventRules should handle ChangePassword event correctly"() {
		given: "a helper instance"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()

		and: "event data with ChangePassword eventname"
		Map<String, Object> event = [
				eventname: "ChangePassword",
				subEvent : "AnySubEvent"
		]

		when: "processEventRules is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processEventRules", Map.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, event)

		then:
		0 * _

		and: "result is true without calling any delegate method"
		result == true
	}

	def "processEventRules should handle UpdateMemberList event correctly"() {
		given: "a helper instance"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()

		and: "event data with UpdateMemberList eventname"
		Map<String, Object> event = [
				eventname: "UpdateMemberList",
				subEvent : "AnySubEvent"
		]

		when: "processEventRules is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processEventRules", Map.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, event)

		then:
		0 * _

		and: "result is true without calling any delegate method"
		result == true
	}

	def "processEventRules should handle empty eventname gracefully"() {
		given: "a helper instance"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()

		and: "event data with empty eventname"
		Map<String, Object> event = [
				eventname: "",
				subEvent : "AnySubEvent"
		]

		when: "processEventRules is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processEventRules", Map.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, event)

		then:
		0 * _

		and: "result is false (default case)"
		result == false
	}

	// Test cases for fallback logic in processAddMember with memberInfo scenarios
	@Unroll
	def "processAddMember with fallback logic returns #expected for scenario #scenarioName"() {
		given: "a helper instance"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()

		and: "event data with services and memberInfo"
		Map<String, Object> event = [
				services   : services,
				memberInfo : memberInfo
		]

		and: "extract allServices from event"
		List<Map<String, Object>> allServices = ConsumerUtil.extractAllServicesWithFallback(event)

		when: "processAddMember is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processAddMember", String.class, List.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, subEvent, allServices)

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                                           | subEvent | services | memberInfo                                                                    || expected
		"no services - fallback to memberInfo with IPTV"      | "other"  | null     | [[services: [serviceType: "IPTV"]]]                                        || false
		"no services - fallback to memberInfo with LSO"       | "other"  | null     | [[services: [serviceType: "LSO"]]]                                         || false
		"no services - fallback to memberInfo with MOSUB"     | "other"  | null     | [[services: [serviceType: "MOSUB"]]]                                       || false
		"empty services - fallback to memberInfo with ECOMM"  | "other"  | []       | [[services: [serviceType: "ECOMM"]]]                                       || false
		"no services - fallback with invalid service"         | "other"  | null     | [[services: [serviceType: "INVALID"]]]                                     || false
		"no services - multiple memberInfo with valid mix"    | "other"  | null     | [[services: [serviceType: "INVALID"]], [services: [serviceType: "VAS"]]] || false
		"no services - fallback to memberInfo with INDIVIDUALUSER" | "other" | null | [[services: [serviceType: "INDIVIDUALUSER"]]] || false
	}

	// Test cases for updated validation logic - "at least one match" pattern
	@Unroll
	def "processUpdateProfileInfo with new validation logic returns #expected for scenario #scenarioName"() {
		given: "a helper with configured profile info update list"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()
		ReflectionTestUtils.setField(testHelper, "haloCProfileInfoUpdate", "svc5|svc6")

		and: "event data"
		Map<String, Object> event = [
				subEvent      : "OtherEvent",
				password_dirty: "dirty",
				services      : services,
				memberInfo    : memberInfo
		]

		and: "extract allServices from event"
		List<Map<String, Object>> allServices = ConsumerUtil.extractAllServicesWithFallback(event)

		when: "processUpdateProfileInfo is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processUpdateProfileInfo", Map.class, String.class, List.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, event, "OtherEvent", allServices)

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                                                | services                                      | memberInfo                                                    || expected
		"multiple services - at least one matches"                 | [[serviceType: "svc5"], [serviceType: "invalid"]]  | null                                                          || true
		"multiple services - none match"                           | [[serviceType: "invalid1"], [serviceType: "invalid2"]] | null                                                          || false
		"no services - fallback memberInfo has match"              | null                                          | [[services: [serviceType: "svc6"]]]                        || true
		"no services - fallback memberInfo no match"               | null                                          | [[services: [serviceType: "invalid"]]]                     || true
		"empty services - fallback memberInfo multiple with match" | []                                            | [[services: [serviceType: "invalid"]], [services: [serviceType: "svc5"]]] || true
	}

	// Test cases for validation methods with "at least one match" logic
	@Unroll
	def "validateServices with new logic returns #expected for scenario #scenarioName"() {
		given: "a helper with configured services"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()

		and: "services list and subEvent"
		ArrayList servicesAddMemberList = new ArrayList(Arrays.asList("svc3", "svc4"))

		when: "validateServices is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("validateServices", List.class, String.class, ArrayList.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, allServices, subEvent, servicesAddMemberList)

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                                    | allServices                                           | subEvent  || expected
		"at least one service matches"                  | [[serviceType: "svc3"], [serviceType: "invalid"]]    | "Any"     || true
		"no services match"                             | [[serviceType: "invalid1"], [serviceType: "invalid2"]] | "Any"     || false
		"Autogen with IPTV returns false"               | [[serviceType: "IPTV"]]                               | "Autogen" || false
		"Autogen with valid service returns true"       | [[serviceType: "svc4"]]                               | "Autogen" || true
		"null services returns false"                   | null                                                  | "Any"     || true
		"empty services returns false"                  | []                                                    | "Any"     || false
	}

	@Unroll
	def "validateUpdateServicesStatus with new logic returns #expected for scenario #scenarioName"() {
		given: "a helper instance"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()

		and: "services update status list"
		ArrayList servicesUpdateStatusList = new ArrayList(Arrays.asList("svc7", "svc8"))

		when: "validateUpdateServicesStatus is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("validateUpdateServicesStatus", List.class, ArrayList.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, allServices, servicesUpdateStatusList)

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                                    | allServices                                           || expected
		"at least one service matches"                  | [[serviceType: "svc7"], [serviceType: "invalid"]]    || true
		"no services match"                             | [[serviceType: "invalid1"], [serviceType: "invalid2"]] || false
		"null services returns false"                   | null                                                  || true
		"empty services returns false"                  | []                                                    || false
	}

	@Unroll
	def "validateUpdateServices with new logic returns #expected for scenario #scenarioName"() {
		given: "a helper instance"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()

		and: "services update list"
		ArrayList servicesUpdateList = new ArrayList(Arrays.asList("svc7", "svc8"))

		when: "validateUpdateServices is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("validateUpdateServices", List.class, ArrayList.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, allServices, servicesUpdateList)

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                                    | allServices                                           || expected
		"at least one service matches"                  | [[serviceType: "svc7"], [serviceType: "invalid"]]    || true
		"no services match"                             | [[serviceType: "invalid1"], [serviceType: "invalid2"]] || false
		"null services returns false"                   | null                                                  || true
		"empty services returns false"                  | []                                                    || false
	}

	@Unroll
	def "validateRemoveServices with new logic returns #expected for scenario #scenarioName"() {
		given: "a helper instance"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()

		and: "services remove list"
		ArrayList servicesRemoveList = new ArrayList(Arrays.asList("svc7", "svc8"))

		when: "validateRemoveServices is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("validateRemoveServices", List.class, String.class, String.class, ArrayList.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, allServices, subEvent, handle, servicesRemoveList)

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                                           | allServices                                           | subEvent            | handle        || expected
		"at least one service matches"                         | [[serviceType: "svc7"], [serviceType: "invalid"]]    | "RemoveServicesList" | "handle1"     || true
		"no services match"                                    | [[serviceType: "invalid1"], [serviceType: "invalid2"]] | "RemoveServicesList" | "handle1"     || false
		"SBC_IPTV handle with non-IPTV service returns false" | [[serviceType: "svc7"]]                               | "RemoveServicesList" | "sbciptv123"  || false
		"SBC_IPTV handle with IPTV service and match"         | [[serviceType: "IPTV"]]                               | "RemoveServicesList" | "sbciptv123"  || false
		"null services returns false"                          | null                                                  | "RemoveServicesList" | "handle1"     || true
	}

	@Unroll
	def "validateAddServices with new logic returns #expected for scenario #scenarioName"() {
		given: "a helper instance"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()

		and: "add services list"
		ArrayList addServicesList = new ArrayList(Arrays.asList("svc7", "svc8"))

		when: "validateAddServices is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("validateAddServices", List.class, ArrayList.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, allServices, addServicesList)

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                                    | allServices                                           || expected
		"at least one service matches"                  | [[serviceType: "svc7"], [serviceType: "invalid"]]    || true
		"no services match"                             | [[serviceType: "invalid1"], [serviceType: "invalid2"]] || false
		"null services returns false"                   | null                                                  || true
		"empty services returns false"                  | []                                                    || false
	}

	@Unroll
	def "ConsumerUtil.validateAddRemoveServices with new logic returns #expected for scenario #scenarioName"() {
		given: "add remove services list"
		ArrayList addRemoveServicesList = new ArrayList(Arrays.asList("svc7", "svc8"))

		when: "ConsumerUtil.validateAddRemoveServices is invoked"
		boolean result = ConsumerUtil.validateAddRemoveServices(allServices, addRemoveServicesList)

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                                    | allServices                                           || expected
		"at least one service matches"                  | [[serviceType: "svc7"], [serviceType: "invalid"]]    || true
		"no services match"                             | [[serviceType: "invalid1"], [serviceType: "invalid2"]] || false
		"null services returns false"                   | null                                                  || true
		"empty services returns false"                  | []                                                    || false
	}


	// Test comprehensive fallback scenarios for all refactored methods
	@Unroll
	def "processUpdateServicesStatusList with fallback logic returns #expected for scenario #scenarioName"() {
		given: "a helper with configured services"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()
		ReflectionTestUtils.setField(testHelper, "haloCServices", "svc7|svc8")

		and: "event data"
		Map<String, Object> event = [
				services   : services,
				memberInfo : memberInfo
		]

		and: "extract allServices from event"
		List<Map<String, Object>> allServices = ConsumerUtil.extractAllServicesWithFallback(event)

		when: "processUpdateServicesStatusList is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processUpdateServicesStatusList", List.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, [allServices] as Object[])

		then:
		0 * _

		and:
		result == expected

		where:
		// NOTE: extractAllServicesWithFallback only falls back to memberInfo for AddRemoveServicesList events.
		// For other event types, memberInfo.services is NOT picked up; allServices=null -> methods return true.
		scenarioName                                           | services | memberInfo                                                    || expected
		"no services - fallback to memberInfo with match"     | null     | [[services: [serviceType: "svc7"]]]                        || true
		"no services - memberInfo not applied, allSvcs null"  | null     | [[services: [serviceType: "invalid"]]]                     || true
		"empty services - fallback with multiple memberInfo"  | []       | [[services: [serviceType: "invalid"]], [services: [serviceType: "svc8"]]] || true
	}

	@Unroll
	def "processUpdateServicesList with fallback logic returns #expected for scenario #scenarioName"() {
		given: "a helper with configured services"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()
		ReflectionTestUtils.setField(testHelper, "haloCServices", "svc7|svc8")

		and: "event data"
		Map<String, Object> event = [
				services   : services,
				memberInfo : memberInfo
		]

		and: "extract allServices from event"
		List<Map<String, Object>> allServices = ConsumerUtil.extractAllServicesWithFallback(event)

		when: "processUpdateServicesList is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processUpdateServicesList", List.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, [allServices] as Object[])

		then:
		0 * _

		and:
		result == expected

		where:
		// NOTE: extractAllServicesWithFallback only falls back to memberInfo for AddRemoveServicesList events.
		// For other event types, memberInfo.services is NOT picked up; allServices=null -> methods return true.
		scenarioName                                           | services | memberInfo                                                    || expected
		"no services - fallback to memberInfo with match"     | null     | [[services: [serviceType: "svc7"]]]                        || true
		"no services - memberInfo not applied, allSvcs null"  | null     | [[services: [serviceType: "invalid"]]]                     || true
		"empty services - fallback with multiple memberInfo"  | []       | [[services: [serviceType: "invalid"]], [services: [serviceType: "svc8"]]] || true
	}

	@Unroll
	def "processDeleteMemberList with fallback logic returns #expected for scenario #scenarioName"() {
		given: "a helper instance"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()

		and: "event data"
		Map<String, Object> event = [
				services   : services,
				memberInfo : memberInfo,
				Handle     : eventHandle
		]

		and: "extract allServices from event"
		List<Map<String, Object>> allServices = ConsumerUtil.extractAllServicesWithFallback(event)

		when: "processDeleteMemberList is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processDeleteMemberList", Map.class, String.class, List.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, event, "DeleteMemberList", allServices)

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                                                | services | memberInfo                                                    | eventHandle   || expected
		"no services - fallback to memberInfo with SBC_IPTV"       | null     | [[services: [serviceType: "IPTV"]]]                        | "sbciptv123"  || true
		"no services - fallback to memberInfo with non-IPTV"       | null     | [[services: [serviceType: "invalid"]]]                     | "sbciptv123"  || true
		"no services - fallback to memberInfo with regular handle" | null     | [[services: [serviceType: "any"]]]                         | "handle1"     || true
		"empty services - fallback with SBC_IPTV handle"           | []       | [[services: [serviceType: "IPTV"]]]                        | "sbciptv123"  || true
	}

	@Unroll
	def "processAddServicesList with fallback logic returns #expected for scenario #scenarioName"() {
		given: "a helper with configured services"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()
		ReflectionTestUtils.setField(testHelper, "haloCServices", "svc7|svc8")

		and: "event data"
		Map<String, Object> event = [
				services   : services,
				memberInfo : memberInfo
		]

		and: "extract allServices from event"
		List<Map<String, Object>> allServices = ConsumerUtil.extractAllServicesWithFallback(event)

		when: "processAddServicesList is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processAddServicesList", List.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, [allServices] as Object[])

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                                           | services | memberInfo                                                    || expected
		"no services - fallback to memberInfo with match"     | null     | [[services: [serviceType: "svc7"]]]                        || true
		"no services - fallback to memberInfo no match"       | null     | [[services: [serviceType: "invalid"]]]                     || true
		"empty services - fallback with multiple memberInfo"  | []       | [[services: [serviceType: "invalid"]], [services: [serviceType: "svc8"]]] || true
	}

	@Unroll
	def "processAddRemoveServicesList with fallback logic returns #expected for scenario #scenarioName"() {
		given: "a helper with configured services"
		IDGraphHaloCRulesHelper testHelper = new IDGraphHaloCRulesHelper()
		ReflectionTestUtils.setField(testHelper, "haloCServices", "svc7|svc8")

		and: "event data"
		Map<String, Object> event = [
				services   : services,
				memberInfo : memberInfo
		]

		and: "extract allServices from event"
		List<Map<String, Object>> allServices = ConsumerUtil.extractAllServicesWithFallback(event)

		when: "processAddRemoveServicesList is invoked via reflection"
		def method = IDGraphHaloCRulesHelper.class.getDeclaredMethod("processAddRemoveServicesList", List.class)
		method.setAccessible(true)
		boolean result = method.invoke(testHelper, [allServices] as Object[])

		then:
		0 * _

		and:
		result == expected

		where:
		scenarioName                                           | services | memberInfo                                                    || expected
		"no services - fallback to memberInfo with match"     | null     | [[services: [serviceType: "svc7"]]]                        || true
		"no services - fallback to memberInfo no match"       | null     | [[services: [serviceType: "invalid"]]]                     || true
		"empty services - fallback with multiple memberInfo"  | []       | [[services: [serviceType: "svc7"]], [services: [serviceType: "svc8"]]] || true
	}
}

