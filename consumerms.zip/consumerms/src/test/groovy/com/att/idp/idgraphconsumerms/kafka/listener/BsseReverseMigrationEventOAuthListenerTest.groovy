package com.att.idp.idgraphconsumerms.kafka.listener

import com.att.idp.idgraphconsumerms.bsse.reverse.BsseReverseMigrationEventProcessor
import com.fasterxml.jackson.core.JsonProcessingException
import org.springframework.kafka.support.Acknowledgment
import org.springframework.messaging.MessageHeaders
import spock.lang.Specification
import spock.lang.Unroll

class BsseReverseMigrationEventOAuthListenerTest extends Specification {

    BsseReverseMigrationEventProcessor processor
    BsseReverseMigrationEventOAuthListener listener

    void setup() {
        processor = Mock(BsseReverseMigrationEventProcessor)
        listener = new BsseReverseMigrationEventOAuthListener(processor)
    }

    @Unroll
    def "should consume and process BsseReverseMigrationEvent for #scenarioName"() {
        given: "A valid message, headers, and acknowledgment"
        String msg = eventJson
        MessageHeaders headers = new MessageHeaders([:])
        Acknowledgment ack = Mock(Acknowledgment)

        when: "consumeBsseReverseMigrationEvent is called"
        listener.consumeBsseReverseMigrationEvent(msg, headers, ack)

        then: "Processor is called with correct arguments"
        1 * processor.processEvent(msg, headers, ack)
        0 * _

        and: "No exception is thrown"

        where:
        scenarioName      | eventJson
        "valid event"     | '{"eventType":"BSSE_REVERSE_MIGRATION","event":{"idmAttributes":{}}}'
        "empty event"     | '{}'
    }

    def "should propagate JsonProcessingException from processor"() {
        given: "A message that causes JsonProcessingException"
        String msg = '{"invalidJson":}'
        MessageHeaders headers = new MessageHeaders([:])
        Acknowledgment ack = Mock(Acknowledgment)
        JsonProcessingException exception = new JsonProcessingException("Invalid JSON") {}

        when: "consumeBsseReverseMigrationEvent is called"
        listener.consumeBsseReverseMigrationEvent(msg, headers, ack)

        then: "Processor throws exception, and it is propagated"
        1 * processor.processEvent(msg, headers, ack) >> { throw exception }
        0 * _

        and: "Exception is propagated"
        JsonProcessingException ex = thrown()
        ex.message == "Invalid JSON"
    }
}
