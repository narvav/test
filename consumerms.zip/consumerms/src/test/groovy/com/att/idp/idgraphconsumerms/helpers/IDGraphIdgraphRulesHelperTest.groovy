package com.att.idp.idgraphconsumerms.helpers

import spock.lang.Specification
import spock.lang.Unroll

class IDGraphIdgraphRulesHelperTest extends Specification {

    IDGraphIdgraphRulesHelper helper

    void setup() {
        helper = new IDGraphIdgraphRulesHelper()
    }

    def "should allow LSServicesActivation event through for IDGRAPH"() {
        given:
        Map<String, Object> event = [eventname: "LSServicesActivation", ban: "VD0017554", handle: "qay_geetha_1751"]

        when:
        boolean result = helper.processIdgraphMessage(event)

        then:
        result
        0 * _
    }

    def "should reject event when eventname is not LSServicesActivation"() {
        given:
        Map<String, Object> event = [eventname: "AddMember", ban: "VD0017554"]

        when:
        boolean result = helper.processIdgraphMessage(event)

        then:
        !result
        0 * _
    }

    def "should reject event when event map is null"() {
        given:
        Map<String, Object> event = null

        when:
        boolean result = helper.processIdgraphMessage(event)

        then:
        !result
        0 * _
    }

    def "should reject event when event map is empty"() {
        given:
        Map<String, Object> event = [:]

        when:
        boolean result = helper.processIdgraphMessage(event)

        then:
        !result
        0 * _
    }

    def "should reject event when eventname is null"() {
        given:
        Map<String, Object> event = [ban: "VD0017554", handle: "qay_geetha_1751"]

        when:
        boolean result = helper.processIdgraphMessage(event)

        then:
        !result
        0 * _
    }

    @Unroll
    def "should reject event for non-matching eventname #scenarioName"() {
        given:
        Map<String, Object> event = [eventname: eventNameValue]

        when:
        boolean result = helper.processIdgraphMessage(event)

        then:
        !result
        0 * _

        where:
        scenarioName         | eventNameValue
        "LSRegNotify"        | "LSRegNotify"
        "AddMember"          | "AddMember"
        "NotificationEvent"  | "NotificationEvent"
        "DeleteMemberList"   | "DeleteMemberList"
    }
}

