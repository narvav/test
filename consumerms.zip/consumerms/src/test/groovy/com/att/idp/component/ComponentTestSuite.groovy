package com.att.idp.component

import org.junit.platform.suite.api.SelectClasses
import org.junit.platform.suite.api.Suite
import spock.lang.Specification
/*
 * All the component test classes must be registered in this suite class,
 * otherwise that component test class will be ignored.
 */
@Suite
@SelectClasses([
	UserResourceTest.class,
	OdsNotesEventComponentTest.class
	])
class ComponentTestSuite extends Specification {
}