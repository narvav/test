// File: `src/test/groovy/com/att/idp/idgraphconsumerms/kafka/dmctn/service/BackendServiceFactoryTest.groovy`
package com.att.idp.idgraphconsumerms.kafka.dmctn.service

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.kafka.model.Subscriber
import spock.lang.Specification

class BackendServiceFactoryTest extends Specification {

    BackendServiceFactory factory

    ChangeAssociationStatusService changeAssociationStatusService = Mock()
    ChangeAssociationDataService changeAssociationDataService = Mock()
    RemoveAssociationService removeAssociationService = Mock()

    def setup() {
        factory = new BackendServiceFactory()
        factory.changeAssociationStatusService = changeAssociationStatusService
        factory.changeAssociationDataService = changeAssociationDataService
        factory.removeAssociationService = removeAssociationService
    }

    private Subscriber subWithStatus(String status) {
        def s = Mock(Subscriber)
        s.getStatus() >> status
        s
    }

    def "returns removeAssociationService for TERMINATED status"() {
        given:
        def sub = subWithStatus(ConsumerConstants.DmctnSubscriberChangeEvent.SERVICE_STAUS_TERMINATED)
        def types = [ConsumerConstants.DmctnSubscriberChangeEvent.HEADER_CHANGETYPE_VALUE_STATUS]

        when:
        def svc = factory.getService(types, sub)

        then:
        svc.is(removeAssociationService)
    }

    def "returns removeAssociationService for CANCELLED status"() {
        given:
        def sub = subWithStatus(ConsumerConstants.DmctnSubscriberChangeEvent.SERVICE_STAUS_CANCELLED)
        def types = [ConsumerConstants.DmctnSubscriberChangeEvent.HEADER_CHANGETYPE_VALUE_STATUS]

        when:
        def svc = factory.getService(types, sub)

        then:
        svc.is(removeAssociationService)
    }

    def "returns changeAssociationStatusService for ACTIVE status"() {
        given:
        def sub = subWithStatus(ConsumerConstants.DmctnSubscriberChangeEvent.SERVICE_STAUS_ACTIVE)
        def types = [ConsumerConstants.DmctnSubscriberChangeEvent.HEADER_CHANGETYPE_VALUE_STATUS]

        when:
        def svc = factory.getService(types, sub)

        then:
        svc.is(changeAssociationStatusService)
    }

    def "returns changeAssociationStatusService for SUSPENDED status"() {
        given:
        def sub = subWithStatus(ConsumerConstants.DmctnSubscriberChangeEvent.SERVICE_STAUS_SUSPENDED)
        def types = [ConsumerConstants.DmctnSubscriberChangeEvent.HEADER_CHANGETYPE_VALUE_STATUS]

        when:
        def svc = factory.getService(types, sub)

        then:
        svc.is(changeAssociationStatusService)
    }

    def "PHONE header overrides prior STATUS selection"() {
        given:
        def sub = subWithStatus(ConsumerConstants.DmctnSubscriberChangeEvent.SERVICE_STAUS_TERMINATED)
        def types = [
                ConsumerConstants.DmctnSubscriberChangeEvent.HEADER_CHANGETYPE_VALUE_STATUS,
                ConsumerConstants.DmctnSubscriberChangeEvent.HEADER_CHANGETYPE_VALUE_PHONENUMBER
        ]

        when:
        def svc = factory.getService(types, sub)

        then:
        svc.is(changeAssociationDataService)
    }

    def "returns changeAssociationDataService when only PHONE header present"() {
        given:
        def sub = subWithStatus("WHATEVER")
        def types = [ConsumerConstants.DmctnSubscriberChangeEvent.HEADER_CHANGETYPE_VALUE_PHONENUMBER]

        when:
        def svc = factory.getService(types, sub)

        then:
        svc.is(changeAssociationDataService)
    }

    def "returns null when STATUS header present but status unmatched"() {
        given:
        def sub = subWithStatus("UNKNOWN_STATUS")
        def types = [ConsumerConstants.DmctnSubscriberChangeEvent.HEADER_CHANGETYPE_VALUE_STATUS]

        when:
        def svc = factory.getService(types, sub)

        then:
        svc == null
    }

    def "returns null when no relevant change type headers"() {
        given:
        def sub = subWithStatus(ConsumerConstants.DmctnSubscriberChangeEvent.SERVICE_STAUS_ACTIVE)
        def types = ["IRRELEVANT"]

        when:
        def svc = factory.getService(types, sub)

        then:
        svc == null
    }
}
