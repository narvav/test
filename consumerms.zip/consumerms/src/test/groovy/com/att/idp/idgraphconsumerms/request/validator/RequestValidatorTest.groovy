/*
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.idp.idgraphconsumerms.request.validator.RequestValidator
import spock.lang.Specification
import spock.lang.Unroll

class RequestValidatorTest extends Specification {

	@Unroll
	def "should validate request attribute for #scenarioName"() {
		given: "A request attribute and attribute name"
		String requestAttribute = inputValue
		String attributeName = inputName

		when: "validate is called"
		Map<String, Object> result = RequestValidator.validate(requestAttribute, attributeName)

		then: "Result contains correct status code and message"
		result != null
		result.containsKey("appStatusCode")
		result.containsKey("appInfo")

		and: "Result values are as expected"
		result.get("appStatusCode") == expectedCode
		result.get("appInfo") == expectedMessage

		0 * _

		where: "Different validation scenarios"
		scenarioName         | inputValue | inputName   | expectedCode                                 | expectedMessage
		"blank attribute"    | ""         | "testField" | CErrorDefs.ERR_INVALID_DATA_NUM.toString()   | "Invalid input: testField is blank or null."
		"null attribute"     | null       | "foo"       | CErrorDefs.ERR_INVALID_DATA_NUM.toString()   | "Invalid input: foo is blank or null."
		"valid attribute"    | "value"    | "bar"       | CErrorDefs.COMMON_SUCCESS_NUM.toString()     | CommonDefs.COMMON_SUCCESS_MSG
	}
}
*/
