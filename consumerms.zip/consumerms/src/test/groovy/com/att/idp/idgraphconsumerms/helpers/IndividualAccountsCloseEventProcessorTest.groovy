package com.att.idp.idgraphconsumerms.helpers

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.att.idp.idgraphconsumerms.oracle.helpers.MemberServiceDBHelper
import com.att.idp.idgraphconsumerms.oracle.model.MemberServiceResult
import spock.lang.Specification

class IndividualAccountsCloseEventProcessorTest extends Specification {

    def memberServiceDBHelper = Mock(MemberServiceDBHelper)
    def credentialsProcessor = Mock(PasscodeProcessor)
    def removeAssociationApiHelper = Mock(RemoveAssociationApiHelper)
    def gddnFailedEventCircuitBreaker = Mock(GddnFailedEventCircuitBreaker)
    def cosmosFailedEventsWriter = Mock(CosmosFailedEventsWriter)

    def processor = new IndividualAccountsCloseEventProcessor()

    def setup() {
        // Groovy allows setting private fields directly
        processor.memberServiceDBHelper = memberServiceDBHelper
        processor.credentialsProcessor = credentialsProcessor
        processor.removeAssociationApiHelper = removeAssociationApiHelper
        processor.gddnFailedEventCircuitBreaker = gddnFailedEventCircuitBreaker
        processor.cosmosFailedEventsWriter = cosmosFailedEventsWriter
        processor.removeAssociationEndpoint = "/test/endpoint"
        // Circuit breaker returns false by default (circuit closed)
        gddnFailedEventCircuitBreaker.shouldShortCircuit(_, _) >> false
    }

    def "process should call helper for each member service and then credentials cleanup"() {
        given:
        def individualId = "ind-1"
        memberServiceDBHelper.queryMemberService(individualId) >> [
                new MemberServiceResult(memberNum: "111"),
                new MemberServiceResult(memberNum: "222")
        ]

        when:
        processor.process(individualId)

        then:
        1 * memberServiceDBHelper.queryMemberService(individualId)
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(individualId, ConsumerConstants.BsseMigration.EVENT_CG_INDIVIDUAL_CLOSE) >> false
        1 * credentialsProcessor.callUserAssociationDeleteCredService(individualId, ConsumerConstants.BsseMigration.EVENT_CG_INDIVIDUAL_CLOSE)
    }

    def "process should handle exception from helper and continue with remaining members"() {
        given:
        def individualId = "ind-2"
        memberServiceDBHelper.queryMemberService(individualId) >> [
                new MemberServiceResult(memberNum: "AAA"),
                new MemberServiceResult(memberNum: "BBB"),
                new MemberServiceResult(memberNum: "CCC")
        ]
        removeAssociationApiHelper.callRemoveAssociationApi("AAA", individualId) >> { /* success */ }
        removeAssociationApiHelper.callRemoveAssociationApi("BBB", individualId) >> { throw new RuntimeException("boom") }
        removeAssociationApiHelper.callRemoveAssociationApi("CCC", individualId) >> { /* success */ }

        when:
        processor.process(individualId)

        then:
        1 * memberServiceDBHelper.queryMemberService(individualId)
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(individualId, ConsumerConstants.BsseMigration.EVENT_CG_INDIVIDUAL_CLOSE) >> false
        1 * credentialsProcessor.callUserAssociationDeleteCredService(individualId, ConsumerConstants.BsseMigration.EVENT_CG_INDIVIDUAL_CLOSE)
    }

    def "process should do nothing (except credentials call) when member services list empty"() {
        given:
        def individualId = "ind-empty"
        memberServiceDBHelper.queryMemberService(individualId) >> []

        when:
        processor.process(individualId)

        then:
        1 * memberServiceDBHelper.queryMemberService(individualId)
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(individualId, ConsumerConstants.BsseMigration.EVENT_CG_INDIVIDUAL_CLOSE) >> false
        0 * removeAssociationApiHelper._
        1 * credentialsProcessor.callUserAssociationDeleteCredService(individualId, ConsumerConstants.BsseMigration.EVENT_CG_INDIVIDUAL_CLOSE)
    }

    def "process should treat null member services as empty list"() {
        given:
        def individualId = "ind-null"
        memberServiceDBHelper.queryMemberService(individualId) >> null

        when:
        processor.process(individualId)

        then:
        1 * memberServiceDBHelper.queryMemberService(individualId)
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(individualId, ConsumerConstants.BsseMigration.EVENT_CG_INDIVIDUAL_CLOSE) >> false
        0 * removeAssociationApiHelper._
        1 * credentialsProcessor.callUserAssociationDeleteCredService(individualId, ConsumerConstants.BsseMigration.EVENT_CG_INDIVIDUAL_CLOSE)
    }
}
