package com.att.idp.idgraphconsumerms.rest.client;

import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails
import com.att.idp.idgraphconsumerms.rest.model.APIDetails
import com.att.idp.idgraphconsumerms.rest.model.APIRequestWrapper
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil
import com.fasterxml.jackson.databind.JsonNode
import org.springframework.http.HttpEntity
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.web.client.HttpClientErrorException
import org.springframework.web.client.HttpServerErrorException
import org.springframework.web.client.RestTemplate
import spock.lang.Specification
import spock.lang.Unroll

class GenericApiRestClientTest extends Specification {

    CosmosFailedEventsWriter cosmosFailedEventsWriter
    RestTemplate restTemplate
    GenericApiRestClient genericApiRestClient

    def setup() {
        cosmosFailedEventsWriter = Mock(CosmosFailedEventsWriter)
        restTemplate = Mock(RestTemplate)
        genericApiRestClient = new GenericApiRestClient(restTemplate)
        genericApiRestClient.cosmosFailedEventsWriter = cosmosFailedEventsWriter
    }

    @Unroll
    def "should send POST request and handle non-OK response for #scenarioName"() {
        given: "APIRequestWrapper and dependencies"
        APIDetails apiDetails = APIDetails.builder()
                .username("user")
                .password("pass")
                .xATTClientId("clientId")
                .serverURI("http://localhost")
                .apiEndpoint("/api/test")
                .httpMethod(HttpMethod.POST)
                .build()
        FailedEventDetails failedEventDetails = FailedEventDetails.builder()
                .accountId("acc123")
                .eventName("event1")
                .errorDetails(["accountType": "typeA"])
                .build()
        APIRequestWrapper apiRequestWrapper = Mock(APIRequestWrapper) {
            getApiDetails() >> apiDetails
            getOutgoingAPIRequestJson() >> requestJson
            getFailedEventDetails() >> failedEventDetails
        }
        JsonNode responseBody = Mock(JsonNode)
        ResponseEntity<JsonNode> responseEntity = new ResponseEntity<>(responseBody, responseStatus)
        1 * restTemplate.exchange(
                "http://localhost/api/test",
                HttpMethod.POST,
                { HttpEntity<String> entity ->
                    entity.body == requestJson &&
                            entity.headers.getContentType() == MediaType.APPLICATION_JSON
                },
                JsonNode
        ) >> responseEntity

        when: "sendPostRequest is called"
        ResponseEntity<JsonNode> result = genericApiRestClient.sendPostRequest(apiRequestWrapper)

        then: "No unexpected interactions"

        and: "Result is null as per implementation"
        result == null

        where:
        scenarioName         | requestJson      | responseStatus
        "non-OK response"    | '{"foo":"bar"}'  | HttpStatus.BAD_REQUEST
        "OK response"        | '{"foo":"baz"}'  | HttpStatus.OK
    }

    def "should throw and rethrow HttpServerErrorException for retryable error"() {
        given: "APIRequestWrapper and dependencies"
        APIDetails apiDetails = APIDetails.builder()
                .username("user")
                .password("pass")
                .xATTClientId("clientId")
                .serverURI("http://localhost")
                .apiEndpoint("/api/test")
                .httpMethod(HttpMethod.POST)
                .build()
        FailedEventDetails failedEventDetails = FailedEventDetails.builder()
                .accountId("acc123")
                .eventName("event1")
                .errorDetails(["accountType": "typeA"])
            .build()
        APIRequestWrapper apiRequestWrapper = Mock(APIRequestWrapper) {
            getApiDetails() >> apiDetails
            getOutgoingAPIRequestJson() >> '{"foo":"bar"}'
            getFailedEventDetails() >> failedEventDetails
        }
        HttpServerErrorException exception = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "Server error")
        1 * restTemplate.exchange(*_) >> { throw exception }

        when: "sendPostRequest is called"
        genericApiRestClient.sendPostRequest(apiRequestWrapper)

        then: "Exception is thrown and no failed event is saved"
        0 * FailedEventUtil.saveFailedEvent(*_)

        and: "Exception is propagated"
        HttpServerErrorException ex = thrown()
        ex.message.contains("Server error")
    }

    def "should handle non-retryable exception and save failed event"() {
        given: "APIRequestWrapper and dependencies"
        APIDetails apiDetails = APIDetails.builder()
                .username("user")
                .password("pass")
                .xATTClientId("clientId")
                .serverURI("http://localhost")
                .apiEndpoint("/api/test")
                .httpMethod(HttpMethod.POST)
                .build()
        Map<String, String> errorDetails = new HashMap<>()
        errorDetails.put("accountType", "typeA")
        FailedEventDetails expectedFailedEventDetails = FailedEventDetails.builder()
                .accountId("acc123")
                .requestPayload('{"foo":"bar"}')
                .eventName("event1")
                .errorDetails(new HashMap<>([
                        "failedEndpoint": "/api/test",
                        "accountType": "typeA",
                        "errorMessage": "{\"appStatusMsg\":\"ERR_ACCOUNT_INELIGIBLE\",\"missingGuids\":[\"1020445297\"],\"appCategoryCode\":\"3\"}",
                        "errorCode": "100"
                ]))
                .build()
        FailedEventDetails failedEventDetails = FailedEventDetails.builder()
                .accountId("acc123")
                .eventName("event1")
                .errorDetails(errorDetails)
                .build()
        APIRequestWrapper apiRequestWrapper = Mock(APIRequestWrapper) {
            getApiDetails() >> apiDetails
            getOutgoingAPIRequestJson() >> '{"foo":"bar"}'
            getFailedEventDetails() >> failedEventDetails
        }
        String errorResponseBody = '{"appStatusMsg":"ERR_ACCOUNT_INELIGIBLE","missingGuids":["1020445297"],"appCategoryCode":"3"}'
        HttpClientErrorException exception = HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "Bad Request", null, errorResponseBody.getBytes(), null)
        1 * restTemplate.exchange(*_) >> { throw exception }
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ FailedEventDetails fed ->
            fed.accountId == "acc123" &&
                    fed.requestPayload == '{"foo":"bar"}' &&
                    fed.eventName == "event1" &&
                    fed.errorDetails.get("failedEndpoint") == "/api/test" &&
                    fed.errorDetails.get("accountType") == "typeA" &&
                    fed.errorDetails.get("errorMessage") == errorResponseBody &&
                    fed.errorDetails.get("errorCode") == "100"
        })
        0 * _

        when: "sendPostRequest is called"
        ResponseEntity<JsonNode> result = genericApiRestClient.sendPostRequest(apiRequestWrapper)

        then: "No exception is thrown and result is null"
        result == null
    }


    def "should call saveFailedEvent on recover"() {
        given: "APIRequestWrapper and dependencies"
        APIDetails apiDetails = APIDetails.builder()
                .username("user")
                .password("pass")
                .xATTClientId("clientId")
                .serverURI("http://localhost")
                .apiEndpoint("/api/test")
                .httpMethod(HttpMethod.POST)
                .build()
        Map<String, String> errorDetails = new HashMap<>()
        errorDetails.put("accountType", "typeA")
        FailedEventDetails failedEventDetails = FailedEventDetails.builder()
                .accountId("acc123")
                .eventName("event1")
                .errorDetails(errorDetails)
                .build()
        APIRequestWrapper apiRequestWrapper = Mock(APIRequestWrapper) {
            getApiDetails() >> apiDetails
            getOutgoingAPIRequestJson() >> '{"foo":"bar"}'
            getFailedEventDetails() >> failedEventDetails
        }
        HttpServerErrorException exception = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "Server error")
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ FailedEventDetails fed ->
            fed.accountId == "acc123" &&
                    fed.requestPayload == '{"foo":"bar"}' &&
                    fed.eventName == "event1" &&
                    fed.errorDetails.get("failedEndpoint") == "/api/test" &&
                    fed.errorDetails.get("accountType") == "typeA" &&
                    fed.errorDetails.get("errorMessage") == "500 Server error" &&
                    fed.errorDetails.get("errorCode") == "500"
        })
        0 * _

        when: "recover is called"
        genericApiRestClient.recover(exception, apiRequestWrapper)

        then: "No exception is thrown"
        noExceptionThrown()
    }
}
