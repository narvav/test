package com.att.idp.idgraphconsumerms.cosmos.nosql

import com.att.idp.idgraph.db.cosmos.entity.IdgraphFailedEvents
import spock.lang.Specification

class IdgraphFailedEventsTest extends Specification {

    def "test IdgraphFailedEvents getters and setters"() {
        given:
        def failedEvent = new IdgraphFailedEvents()

        when:
        failedEvent.setAccountNumber("BAN123")
        failedEvent.setTraceId("TRACE123")
        failedEvent.setEventName("EventName")
        failedEvent.setAccountType("AccountType")
        failedEvent.setCreatedDate("2023-10-01")
        failedEvent.setErrorId("ERROR123")
        failedEvent.setRequestPayload("RequestPayload")
        failedEvent.setResponsePayload("ResponsePayload")
        failedEvent.setFailedEndpoint("FailedEndpoint")
        failedEvent.setRetryCounter("3")

        then:
        failedEvent.getAccountNumber() == "BAN123"
        failedEvent.getTraceId() == "TRACE123"
        failedEvent.getEventName() == "EventName"
        failedEvent.getAccountType() == "AccountType"
        failedEvent.getCreatedDate() == "2023-10-01"
        failedEvent.getErrorId() == "ERROR123"
        failedEvent.getRequestPayload() == "RequestPayload"
        failedEvent.getResponsePayload() == "ResponsePayload"
        failedEvent.getFailedEndpoint() == "FailedEndpoint"
        failedEvent.getRetryCounter() == "3"
    }

    def "test IdgraphFailedEvents constructor"() {
        when:
        def failedEvent = new IdgraphFailedEvents(
                accountNumber: "BAN123",
                traceId: "TRACE123",
                eventName: "EventName",
                accountType: "AccountType",
                createdDate: "2023-10-01",
                errorId: "ERROR123",
                requestPayload: "RequestPayload",
                responsePayload: "ResponsePayload",
                failedEndpoint: "FailedEndpoint",
                retryCounter: "3"
        )

        then:
        failedEvent.accountNumber == "BAN123"
        failedEvent.traceId == "TRACE123"
        failedEvent.eventName == "EventName"
        failedEvent.accountType == "AccountType"
        failedEvent.createdDate == "2023-10-01"
        failedEvent.errorId == "ERROR123"
        failedEvent.requestPayload == "RequestPayload"
        failedEvent.responsePayload == "ResponsePayload"
        failedEvent.failedEndpoint == "FailedEndpoint"
        failedEvent.retryCounter == "3"
    }
}