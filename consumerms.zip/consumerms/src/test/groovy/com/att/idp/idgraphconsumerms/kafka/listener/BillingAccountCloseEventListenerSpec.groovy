package com.att.idp.idgraphconsumerms.kafka.listener

import com.att.idp.idgraphconsumerms.helpers.CloseAccountPasscodeProcessor
import com.fasterxml.jackson.databind.ObjectMapper
import org.slf4j.MDC
import org.springframework.kafka.support.Acknowledgment
import spock.lang.Specification

class BillingAccountCloseEventListenerSpec extends Specification {

    def closeAccountPasscodeProcessor = Mock(CloseAccountPasscodeProcessor)
    def objectMapper = new ObjectMapper()
    def ack = Mock(Acknowledgment)

    def listener = new BillingAccountCloseEventListener(closeAccountPasscodeProcessor, objectMapper)

    def cleanup() {
        MDC.clear()
    }

    private String buildEventJson(String eventType, String state, String serviceType, String accountId) {
        def accountObj = [:]
        if (accountId != null) accountObj.id = accountId
        if (state != null) accountObj.state = state
        if (serviceType != null) accountObj.serviceType = serviceType

        def event = [
                eventId     : "BillingAccountStateChangeEvent-test-456",
                eventType   : eventType,
                eventTime   : "2022-03-10 14:38:53.185",
                resourceName: "Account",
                event       : [
                        name              : "BillingAccountStateChange",
                        type              : eventType,
                        resourceVersion   : "1",
                        resourceIdentifier: "Account",
                        account           : objectMapper.writeValueAsString(accountObj)
                ]
        ]
        return objectMapper.writeValueAsString(event)
    }

    def "should process valid BillingAccountStateChangeEvent and acknowledge"() {
        given:
        def msg = buildEventJson("BillingAccountStateChangeEvent", "closed", "Wireless", "556331445652")

        when:
        listener.consumeBillingAccountCloseEvent(msg, ack)

        then:
        1 * closeAccountPasscodeProcessor.process(msg) >> true
        1 * ack.acknowledge()
        0 * _
    }

    def "should skip non-BillingAccountStateChangeEvent and acknowledge"() {
        given:
        def msg = buildEventJson("SomeOtherEvent", "closed", "Wireless", "556331445652")

        when:
        listener.consumeBillingAccountCloseEvent(msg, ack)

        then:
        0 * closeAccountPasscodeProcessor._
        1 * ack.acknowledge()
    }

    def "should acknowledge on successful processing"() {
        given:
        def msg = buildEventJson("BillingAccountStateChangeEvent", "closed", "Fiber", "556331445652")

        when:
        listener.consumeBillingAccountCloseEvent(msg, ack)

        then:
        1 * closeAccountPasscodeProcessor.process(msg) >> true
        1 * ack.acknowledge()
    }

    def "should acknowledge on failed processing"() {
        given:
        def msg = buildEventJson("BillingAccountStateChangeEvent", "closed", "Wireless", "556331445652")

        when:
        listener.consumeBillingAccountCloseEvent(msg, ack)

        then:
        1 * closeAccountPasscodeProcessor.process(msg) >> false
        1 * ack.acknowledge()
    }

    def "should handle malformed JSON and acknowledge"() {
        given:
        def msg = "this-is-not-valid-json"

        when:
        listener.consumeBillingAccountCloseEvent(msg, ack)

        then:
        0 * closeAccountPasscodeProcessor._
        1 * ack.acknowledge()
    }

    def "should set MDC idp-trace-id from eventId"() {
        given:
        def msg = buildEventJson("BillingAccountStateChangeEvent", "closed", "Wireless", "556331445652")

        when:
        listener.consumeBillingAccountCloseEvent(msg, ack)

        then:
        1 * closeAccountPasscodeProcessor.process(msg) >> { String payload ->
            assert MDC.get("idp-trace-id") == "BillingAccountStateChangeEvent-test-456"
            return true
        }
        1 * ack.acknowledge()
    }

    def "should clear MDC in finally block"() {
        given:
        def msg = buildEventJson("BillingAccountStateChangeEvent", "closed", "Wireless", "556331445652")
        MDC.put("idp-trace-id", "some-old-value")

        when:
        listener.consumeBillingAccountCloseEvent(msg, ack)

        then:
        1 * closeAccountPasscodeProcessor.process(msg) >> true
        1 * ack.acknowledge()

        and:
        MDC.get("idp-trace-id") == null
    }

    def "should handle unexpected exception from processor and acknowledge"() {
        given:
        def msg = buildEventJson("BillingAccountStateChangeEvent", "closed", "Wireless", "556331445652")

        when:
        listener.consumeBillingAccountCloseEvent(msg, ack)

        then:
        1 * closeAccountPasscodeProcessor.process(msg) >> { throw new RuntimeException("Unexpected error") }
        1 * ack.acknowledge()
    }
}
