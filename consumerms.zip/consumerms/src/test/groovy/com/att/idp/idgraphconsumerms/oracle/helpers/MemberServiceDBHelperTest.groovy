package com.att.idp.idgraphconsumerms.oracle.helpers

import com.att.idp.idgraphconsumerms.oracle.model.MemberServiceResult
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.jdbc.core.PreparedStatementSetter
import org.springframework.jdbc.core.RowMapper
import spock.lang.Specification
import spock.lang.Unroll

class MemberServiceDBHelperTest extends Specification {

    def jdbcTemplate = Mock(JdbcTemplate)
    def helper = new MemberServiceDBHelper()

    def setup() {
        helper.metaClass.setProperty(helper, 'jdbcTemplate', jdbcTemplate)
    }


    def "should throw IllegalArgumentException for null sorInvariantId"() {
        when:
        helper.queryMemberService(null)

        then:
        def e = thrown(IllegalArgumentException)
        e.message == "Required parameter sor_invariant_id is missing"
    }

    def "should throw IllegalArgumentException for empty sorInvariantId"() {
        when:
        helper.queryMemberService("  ")

        then:
        def e = thrown(IllegalArgumentException)
        e.message == "Required parameter sor_invariant_id is missing"
    }

    def "should throw RuntimeException on database error"() {
        given:
        jdbcTemplate.query(*_) >> { throw new RuntimeException("db error") }

        when:
        helper.queryMemberService("test-id")

        then:
        def e = thrown(RuntimeException)
        e.message == "Database query failed"
        e.cause.message == "db error"
    }

    def "should map ResultSet to MemberServiceResult"() {
        given:
        def sorInvariantId = "test-id"
        def mockResultSet = Mock(java.sql.ResultSet)
        mockResultSet.getString("member_num") >> "1"
        mockResultSet.getString("member_name") >> "John Doe"
        mockResultSet.getString("sor_invariant_id") >> sorInvariantId

        jdbcTemplate.query(*_) >> { String sql, pss, rowMapper ->
            [rowMapper.mapRow(mockResultSet, 0)]
        }

        when:
        def result = helper.queryMemberService(sorInvariantId)

        then:
        result.size() == 1
        result[0].memberNum == "1"
        result[0].memberName == "John Doe"
        result[0].sorInvariantId == sorInvariantId
    }

    @Unroll
    def "should return Optional GUID for #scenarioName"() {
        given: "A CTN and a mocked JdbcTemplate response"
        String ctn = inputCtn
        List<String> dbResult = guidValue != null ? [guidValue] : []
        jdbcTemplate.query(_, _, _) >> dbResult

        when: "getGuidForGivenCTN is called"
        Optional<String> result = helper.getGuidForGivenCTN(ctn)

        then: "JdbcTemplate is called with correct SQL and parameter"
        1 * jdbcTemplate.query(
                { String sql -> sql == "SELECT member_num AS GUID FROM memberservice WHERE service_id='23' and instance_id = ?" },
                { PreparedStatementSetter setter -> true },
                { RowMapper rowMapper -> true }
        ) >> dbResult
        0 * _

        and: "Result matches expected Optional value"
        result.isPresent() == (guidValue != null)
        if (guidValue != null) {
            result.get() == guidValue
        }

        where: "Different CTN scenarios"
        scenarioName         | inputCtn      | guidValue
        "valid CTN"          | "5551112222"  | "G12345"
        "no GUID found"      | "0000000000"  | null
    }

    def "should throw RuntimeException and log error when JdbcTemplate throws for getGuidForGivenCTN"() {
        given: "A CTN and JdbcTemplate throws exception"
        String ctn = "5551112222"
        RuntimeException sqlException = new RuntimeException("DB error")
        jdbcTemplate.query(_, _, _) >> { throw sqlException }

        when: "getGuidForGivenCTN is called"
        helper.getGuidForGivenCTN(ctn)

        then: "JdbcTemplate is called and exception is thrown"
        1 * jdbcTemplate.query(
                { String sql -> sql == "SELECT member_num AS GUID FROM memberservice WHERE service_id='23' and instance_id = ?" },
                { PreparedStatementSetter setter -> true },
                { RowMapper rowMapper -> true }
        ) >> { throw sqlException }
        0 * _

        and: "RuntimeException is thrown with correct message"
        RuntimeException ex = thrown()
        ex.message == "Failed to get GUID for CTN"
        ex.cause == sqlException
    }


    def "should throw IllegalArgumentException when sorInvariantId is null or empty"() {
        given: "An invalid SOR Invariant ID"
        String sorInvariantId = invalidSorInvariantId

        when: "getOldPhoneNumberFromSubscriptionId is called"
        helper.getOldPhoneNumberFromSubscriptionId(sorInvariantId)

        then: "IllegalArgumentException is thrown and no query is made"
        0 * jdbcTemplate.query(_, _, _)
        IllegalArgumentException ex = thrown()
        ex.message == "Required parameter sor_invariant_id is missing"

        where:
        invalidSorInvariantId << [null, "", "   "]
    }

    def "should throw RuntimeException when JdbcTemplate throws exception"() {
        given: "A valid SOR Invariant ID and JdbcTemplate throws exception"
        String sorInvariantId = "sor-id-exception"
        RuntimeException sqlException = new RuntimeException("DB error")

        when: "getOldPhoneNumberFromSubscriptionId is called"
        helper.getOldPhoneNumberFromSubscriptionId(sorInvariantId)

        then: "JdbcTemplate is called and exception is propagated"
        1 * jdbcTemplate.query(_, _, _) >> { throw sqlException }
        0 * _
        RuntimeException ex = thrown()
        ex.message == "Failed to retrieve member service details"
        ex.cause == sqlException
    }

    @Unroll
    def "should return old phone number from subscription id for #scenarioName"() {
        given: "A valid SOR Invariant ID and mocked JdbcTemplate response"
        String sorInvariantId = inputSorInvariantId
        List<MemberServiceResult> queryResult = resultList

        when: "getOldPhoneNumberFromSubscriptionId is called"
        Optional<MemberServiceResult> result = helper.getOldPhoneNumberFromSubscriptionId(sorInvariantId)

        then: "JdbcTemplate is queried with correct SQL and parameter"
        1 * jdbcTemplate.query(
                { String sql -> sql == "SELECT ms.member_num, ms.instance_id FROM memberservice ms WHERE ms.service_id='23' and ms.sor_invariant_id = ?" },
                { PreparedStatementSetter setter -> true },
                { RowMapper<MemberServiceResult> mapper -> true }
        ) >> queryResult
        0 * _

        and: "Result matches expected outcome"
        result.isPresent() == expectedPresent
        if (expectedPresent) {
            result.get().memberNum == expectedMemberNum
            result.get().instanceId == expectedInstanceId
        }

        where: "Different SOR Invariant ID scenarios"
        scenarioName           | inputSorInvariantId                  | resultList                                                                 | expectedPresent | expectedMemberNum | expectedInstanceId
        "valid id with result" | "valid-sor-id"                       | [new MemberServiceResult(memberNum: "12345", instanceId: "5551112222")]   | true           | "12345"          | "5551112222"
        "valid id no result"   | "no-result-sor-id"                   | []                                                                        | false          | null             | null
    }

    def "should throw IllegalArgumentException for null or empty sorInvariantId"() {
        given: "A null or empty SOR Invariant ID"
        String sorInvariantId = inputSorInvariantId

        when: "getOldPhoneNumberFromSubscriptionId is called"
        helper.getOldPhoneNumberFromSubscriptionId(sorInvariantId)

        then: "IllegalArgumentException is thrown and no query is made"
        0 * jdbcTemplate.query(_, _, _)
        IllegalArgumentException ex = thrown()
        ex.message == "Required parameter sor_invariant_id is missing"

        where:
        inputSorInvariantId | _
        null                | _
        ""                  | _
        "   "               | _
    }

   }
