package com.att.idp.idgraphconsumerms.kafka.dmctn.service

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker
import com.att.idp.idgraphconsumerms.kafka.model.AccountNotificationEvent
import com.att.idp.idgraphconsumerms.model.ProvisionEnablerRequest
import com.att.idp.idgraphconsumerms.utils.JsonService
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class ProvisionEnablerNotificationServiceTest extends Specification {

    ApiRestClient apiRestClient
    CosmosFailedEventsWriter cosmosFailedEventsWriter
    GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker
    ProvisionEnablerNotificationService serviceUnderTest

    void setup() {
        apiRestClient = Mock(ApiRestClient)
        cosmosFailedEventsWriter = Mock(CosmosFailedEventsWriter)
        gddnFailedEventCircuitBreaker = Mock(GddnFailedEventCircuitBreaker)
        serviceUnderTest = new ProvisionEnablerNotificationService(apiRestClient, cosmosFailedEventsWriter, gddnFailedEventCircuitBreaker)
        ReflectionTestUtils.setField(serviceUnderTest, "provisionEnablerEndpoint", "/mock/provision/enableracct")
    }

    def "should call provisionEnabler endpoint with correct request when titanBan and mobilityBan present"() {
        given:
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(ConsumerConstants.AccountNotificationConstants.UPDATE_ACCOUNT)
        event.setTitanBan("110086697")
        event.setBillingAccountNumber("883308443")
        event.setServiceName("MOBILITY")
        event.setEventId("trace-123")

        when:
        serviceUnderTest.execute(event)

        then:
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit("110086697", ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT) >> false
        1 * apiRestClient.sendPostRequest("/mock/provision/enableracct", { ProvisionEnablerRequest req ->
            assert req.ban == '110086697'
            assert req.services != null
            assert req.services.size() == 1
            assert req.services[0].serviceType == 'MOBILITY'
            assert req.services[0].sorInvariantId == '883308443'
            assert req.services[0].convergePendingInd == 'N'
            true
        }, ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT)
        0 * cosmosFailedEventsWriter._
        0 * _
    }

    def "should save failed event with VALIDATION_FAILED status when titanBan is missing"() {
        given:
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(ConsumerConstants.AccountNotificationConstants.UPDATE_ACCOUNT)
        event.setBillingAccountNumber("883308443")
        event.setEventId("trace-456")

        when:
        serviceUnderTest.execute(event)

        then:
        0 * apiRestClient._
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ it.status == "VALIDATION_FAILED" &&
                it.eventCategory == ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_FAN_UPDATE })
        0 * _
    }

    def "should save failed event with VALIDATION_FAILED status when mobilityBan is missing"() {
        given:
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(ConsumerConstants.AccountNotificationConstants.UPDATE_ACCOUNT)
        event.setTitanBan("110086697")
        event.setEventId("trace-789")

        when:
        serviceUnderTest.execute(event)

        then:
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit("110086697", ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT) >> false
        0 * apiRestClient._
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ it.status == "VALIDATION_FAILED" &&
                it.eventCategory == ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_FAN_UPDATE })
        0 * _
    }

    def "should save failed event when apiRestClient throws exception"() {
        given:
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(ConsumerConstants.AccountNotificationConstants.UPDATE_ACCOUNT)
        event.setTitanBan("110086697")
        event.setBillingAccountNumber("883308443")
        event.setServiceName("MOBILITY")
        event.setEventId("trace-err")

        when:
        serviceUnderTest.execute(event)

        then:
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit("110086697", ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT) >> false
        1 * apiRestClient.sendPostRequest("/mock/provision/enableracct", _ as ProvisionEnablerRequest, ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT) >> {
            throw new RuntimeException("connection refused")
        }
        1 * cosmosFailedEventsWriter._
        0 * _
    }

    def "circuit breaker open -> saves CIRCUIT_OPEN event without calling downstream"() {
        given:
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(ConsumerConstants.AccountNotificationConstants.UPDATE_ACCOUNT)
        event.setTitanBan("110086697")
        event.setMobilityBan("883308443")
        event.setServiceName("MOBILITY")
        event.setEventId("trace-cb")

        when:
        serviceUnderTest.execute(event)

        then:
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit("110086697", ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT) >> true
        0 * apiRestClient._
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ FailedEventDetails details ->
            assert details.status == "CIRCUIT_OPEN"
            assert details.accountId == "110086697"
            true
        })
        0 * _
    }

    def "circuit breaker not checked when titanBan is blank"() {
        given:
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(ConsumerConstants.AccountNotificationConstants.UPDATE_ACCOUNT)
        event.setMobilityBan("883308443")
        event.setEventId("trace-no-cb")

        when:
        serviceUnderTest.execute(event)

        then:
        0 * gddnFailedEventCircuitBreaker.shouldShortCircuit(_, _)
        0 * apiRestClient._
        1 * cosmosFailedEventsWriter._
        0 * _
    }

    def "should generate valid JSON request with only required fields"() {
        given: "event with titanBan and billingAccountNumber"
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(ConsumerConstants.AccountNotificationConstants.UPDATE_ACCOUNT)
        event.setTitanBan("110987654")
        event.setBillingAccountNumber("123456789")
        event.setServiceName("MOBILITY")
        event.setEventId("trace-json-test")

        when: "service executes"
        serviceUnderTest.execute(event)

        then: "request is sent with simplified JSON structure"
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit("110987654", ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT) >> false
        1 * apiRestClient.sendPostRequest("/mock/provision/enableracct", { ProvisionEnablerRequest req ->
            assert req.ban == '110987654'
            assert req.services != null
            assert req.services.size() == 1
            assert req.services[0].serviceType == 'MOBILITY'
            assert req.services[0].sorInvariantId == '123456789'
            assert req.services[0].convergePendingInd == 'N'
            
            // Verify JSON serialization contains only required fields
            String json = JsonService.getJsonFromObject(req)
            assert json.contains('"ban":"110987654"')
            assert json.contains('"serviceType":"MOBILITY"')
            assert json.contains('"sorInvariantId":"123456789"')
            assert json.contains('"convergePendingInd":"N"')
            
            true
        }, ConsumerConstants.GridGddnNotification.EVENT_GDDN_UPDATE_ACCOUNT)
        0 * cosmosFailedEventsWriter._
        0 * _
    }
}
