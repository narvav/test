package com.att.idp.idgraphconsumerms.kafka.dmctn.service

import com.att.idp.idgraphconsumerms.kafka.model.Subscriber
import com.att.idp.idgraphconsumerms.kafka.dmctn.service.ChangeAssociationDataMigrationService
import com.att.idp.idgraphconsumerms.kafka.dmctn.service.SubscriberCreateEventProcessor
import org.springframework.messaging.MessageHeaders
import spock.lang.Specification
import spock.lang.Unroll

class SubscriberCreateEventProcessorTest extends Specification {

    ChangeAssociationDataMigrationService changeAssociationDataMigrationService
    SubscriberCreateEventProcessor subscriberCreateEventProcessor

    void setup() {
        changeAssociationDataMigrationService = Mock(ChangeAssociationDataMigrationService)
        subscriberCreateEventProcessor = new SubscriberCreateEventProcessor()
        subscriberCreateEventProcessor.changeAssociationDataMigrationService = changeAssociationDataMigrationService
    }

    @Unroll
    def "should process subscriber create event for #scenarioName"() {
        given: "A subscriber and message headers"
        Subscriber subscriber = Subscriber.builder()
                .id(subscriberId)
                .migratedOn(migratedOn)
                .build()
        MessageHeaders headers = new MessageHeaders([:])

        when: "Processor handles the event"
        subscriberCreateEventProcessor.processEvent(subscriber, headers)

        then: "Service is called only for migrated subscribers with CG source"
        expectedCalls * changeAssociationDataMigrationService.execute({
            it.id == subscriberId && it.migratedOn == migratedOn
        }, com.att.idp.idgraphconsumerms.kafka.dmctn.service.EventSource.CG)
        0 * _

        and: "Subscriber attributes are as expected"
        subscriber.id == subscriberId
        subscriber.migratedOn == migratedOn

        where: "Different migration scenarios"
        scenarioName              | subscriberId | migratedOn      | expectedCalls
        "migrated subscriber"     | "sub123"     | "2024-01-01"    | 1
        "not migrated (null)"     | "sub456"     | null            | 0
        "not migrated (empty)"    | "sub789"     | ""              | 0
    }
}
