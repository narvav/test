package com.att.idp.idgraphconsumerms.kafka.dmctn.service

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker
import com.att.idp.idgraphconsumerms.kafka.model.AccountNotificationEvent
import com.att.idp.idgraphconsumerms.model.UserAssociationChangeRequest
import com.att.idp.idgraphconsumerms.oracle.helpers.MemberServiceDBHelper
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import spock.lang.Unroll

class CloseAccountNotificationServiceTest extends Specification {

    ApiRestClient closeAccountApiClient
    MemberServiceDBHelper memberServiceDBHelper
    CosmosFailedEventsWriter cosmosFailedEventsWriter
    GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker
    CloseAccountNotificationService serviceUnderTest

    void setup() {
        closeAccountApiClient = Mock(ApiRestClient)
        memberServiceDBHelper = Mock(MemberServiceDBHelper)
        cosmosFailedEventsWriter = Mock(CosmosFailedEventsWriter)
        gddnFailedEventCircuitBreaker = Mock(GddnFailedEventCircuitBreaker)
        serviceUnderTest = new CloseAccountNotificationService(cosmosFailedEventsWriter, gddnFailedEventCircuitBreaker, closeAccountApiClient, memberServiceDBHelper)
        ReflectionTestUtils.setField(serviceUnderTest, "removeAssociationEndpoint", "/mock/endpoint")
    }

    @Unroll
    def "should call API when GUID is found for #scenarioName"() {
        given: "A valid AccountNotificationEvent and GUID"
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setSubscriberNumber(subscriberNumber)
        event.setBillingAccountNumber(ban)
        Optional<String> guidOptional = Optional.of(guid)

        when: "execute is called"
        serviceUnderTest.execute(event)

        then: "DB is queried once, API client is called with correct request"
        1 * memberServiceDBHelper.getGuidForGivenBillingAccountNumber(ban) >> guidOptional
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(ban, ConsumerConstants.GridGddnNotification.EVENT_GDDN_CLOSE_ACCOUNT) >> false
        1 * closeAccountApiClient.sendPostRequest("/mock/endpoint", { UserAssociationChangeRequest req ->
            req.guid == guid &&
                    req.transactionType == ConsumerConstants.AccountNotificationConstants.CloseAccount &&
                    req.associationList.size() == 1 &&
                    req.associationList[0].serviceName == ConsumerConstants.AccountNotificationConstants.MOBILITY &&
                    req.associationList[0].sorInvariantId == ban &&
                    req.suppressNotification == "N"
        }, ConsumerConstants.GridGddnNotification.EVENT_GDDN_CLOSE_ACCOUNT)
        0 * _

        where:
        scenarioName      | subscriberNumber | ban      | guid
        "valid input"     | "1234567890"     | "BAN123" | "GUID123"
    }

    @Unroll
    def "should not call API when GUID is missing for #scenarioName"() {
        given: "AccountNotificationEvent with no GUID found"
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setBillingAccountNumber(ban)
        when: "execute is called"
        serviceUnderTest.execute(event)

        then: "DB is queried once, API client is not called, no failed event saved"
        1 * memberServiceDBHelper.getGuidForGivenBillingAccountNumber(ban) >> guidOptional
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(ban, _) >> false
        0 * closeAccountApiClient.sendPostRequest(_, _, _)
        0 * cosmosFailedEventsWriter.saveFailedEventsToCosmos(_)
        0 * _

        where:
        scenarioName      | ban | guidOptional
        "null guid"       | "1234567890"     | Optional.empty()
        "empty guid"      | "1234567890"     | Optional.of("")
    }

    @Unroll
    def "should save failed event and not call API when DB throws for #scenarioName"() {
        given: "AccountNotificationEvent and DB throws exception"
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setSubscriberNumber(subscriberNumber)
        event.setBillingAccountNumber(ban)

        when: "execute is called"
        serviceUnderTest.execute(event)

        then: "DB is queried once and throws, failed event processor is called, API client is not called"
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(ban, _) >> false
        1 * memberServiceDBHelper.getGuidForGivenBillingAccountNumber(ban) >> { throw new RuntimeException("DB error") }
        1 * cosmosFailedEventsWriter._
        0 * closeAccountApiClient._
        0 * _

        where:
        scenarioName      | subscriberNumber | ban
        "db exception"    | "1234567890"     | "BAN123"
    }

    def "should short-circuit to Cosmos when circuit breaker is OPEN"() {
        given: "Circuit breaker returns true (pending failed events exist)"
        def openCircuitBreaker = Stub(GddnFailedEventCircuitBreaker) {
            shouldShortCircuit("BAN-CB", ConsumerConstants.GridGddnNotification.EVENT_GDDN_CLOSE_ACCOUNT) >> true
        }
        ReflectionTestUtils.setField(serviceUnderTest, "gddnFailedEventCircuitBreaker", openCircuitBreaker)

        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setBillingAccountNumber("BAN-CB")
        event.setEventName(ConsumerConstants.GridGddnNotification.EVENT_GDDN_CLOSE_ACCOUNT)

        when:
        serviceUnderTest.execute(event)

        then: "API client is never called"
        0 * closeAccountApiClient._
        0 * memberServiceDBHelper._

        and: "Failed event is saved to Cosmos with circuit breaker message"
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ it.accountId == "BAN-CB" &&
                it.eventName == ConsumerConstants.GridGddnNotification.EVENT_GDDN_CLOSE_ACCOUNT })
        0 * _
    }

    def "should save failed event when API client throws after GUID lookup succeeds"() {
        given:
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setBillingAccountNumber("BAN-API-ERR")
        event.setEventName(ConsumerConstants.GridGddnNotification.EVENT_GDDN_CLOSE_ACCOUNT)

        when:
        serviceUnderTest.execute(event)

        then: "Circuit breaker check"
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit("BAN-API-ERR", _) >> false

        and: "GUID lookup succeeds"
        1 * memberServiceDBHelper.getGuidForGivenBillingAccountNumber("BAN-API-ERR") >> Optional.of("GUID-API-ERR")

        and: "API call throws"
        1 * closeAccountApiClient.sendPostRequest("/mock/endpoint", _, _) >> { throw new RuntimeException("connection refused") }

        and: "Failed event is saved to Cosmos"
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ it.accountId == "BAN-API-ERR" &&
                it.eventName == ConsumerConstants.GridGddnNotification.EVENT_GDDN_CLOSE_ACCOUNT })
        0 * _
    }
}
