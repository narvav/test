package com.att.idp.idgraphconsumerms.integration.spec

import groovy.json.JsonSlurper
import io.restassured.RestAssured
import io.restassured.response.Response
import spock.lang.Specification

class ConsumerHeartbeatITSpec extends Specification {

    static final String HEARTBEAT_PATH = "/msapi/actuator/heartbeat"

    def "Heartbeat returns 200 and status UP"() {
        given: "A deployed service base URL"
        String baseUrl = System.getProperty("BASE_URL")?.trim()
        assert baseUrl : "BASE_URL system property must be set"
        String url = baseUrl + HEARTBEAT_PATH

        when: "GET heartbeat is called against the deployed service"
        Response response = RestAssured.given()
                .relaxedHTTPSValidation()
                .get(url)
        Map body = new JsonSlurper().parseText(response.body().asString()) as Map

        then: "No mock interactions — this is a real HTTP call, no mocks are defined"
        0 * _

        and: "Pod is alive and reporting healthy"
        response.statusCode() == 200
        body["status"] == "UP"
    }
}
