package com.att.idp.idgraphconsumerms.helpers


import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails
import com.att.idp.idgraphconsumerms.kafka.model.MigrationBANNotification
import com.fasterxml.jackson.databind.JsonNode
import org.springframework.http.HttpEntity
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.client.HttpServerErrorException
import org.springframework.web.client.RestClientException
import org.springframework.web.client.RestTemplate
import spock.lang.Specification
import spock.lang.Unroll

class BsseMigrationServiceHelperTest extends Specification {

    def restTemplate = Mock(RestTemplate)
    def cosmosFailedEventsDBHelper = Mock(CosmosFailedEventsWriter)
    def bsseMigrationServiceHelper = new BsseMigrationServiceHelper()


    def setup() {
        bsseMigrationServiceHelper.restTemplate = restTemplate
        bsseMigrationServiceHelper.cosmosFailedEventsWriter = cosmosFailedEventsDBHelper
        bsseMigrationServiceHelper.userAssoServerUrl = "http://test-server"
        bsseMigrationServiceHelper.uaServiceEndPoint = "/test-endpoint"
        bsseMigrationServiceHelper.userName = "testUser"
        bsseMigrationServiceHelper.userPassword = "testPassword"
    }

    def "test callBSSEMigrationService success scenario"() {
        given:
        def notification = new MigrationBANNotification(
                sourceBanId: "BAN123",
                targetIndividualId: "IND456",
                migrationId: "MIG789",
                sourceMarketCode: "US",
                guid: "GUID123",
                passcodeVenc: "testPasscode"
        )
        def responseEntity = Mock(ResponseEntity)
        responseEntity.getBody() >> Mock(JsonNode)

        when:
        bsseMigrationServiceHelper.callBSSEMigrationService(notification)

        then:
        1 * restTemplate.exchange(
                "http://test-server/test-endpoint",
                HttpMethod.POST,
                { HttpEntity entity ->
                    entity.headers.get("Authorization").get(0).startsWith("Basic")
                },
                JsonNode.class
        ) >> responseEntity
        0 * cosmosFailedEventsDBHelper.saveFailedEventsToCosmos(_, _)
    }

    def "test callBSSEMigrationService retryable exception"() {
        given:
        def notification = new MigrationBANNotification(
                sourceBanId: "BAN123",
                targetIndividualId: "IND456",
                migrationId: "MIG789",
                sourceMarketCode: "US",
                guid: "GUID123",
                passcodeVenc: "testPasscode"
        )
        when:
        bsseMigrationServiceHelper.callBSSEMigrationService(notification)

        then:
        1 * restTemplate.exchange(_, _, _, _) >> { throw new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR) }
        thrown(HttpServerErrorException)
    }

    @Unroll
    def "should call BSSE migration service with passcodevenc for #scenarioName"() {
        given: "A migration notification and expected passcodevenc"
        String expectedPasscodevenc = "testPasscode"
        MigrationBANNotification notification = new MigrationBANNotification(
                sourceBanId: "BAN123",
                targetIndividualId: "IND456",
                migrationId: "MIG789",
                sourceMarketCode: "US",
                guid: "GUID123",
                passcodeVenc: expectedPasscodevenc
        )
        ResponseEntity<JsonNode> responseEntity = Mock(ResponseEntity)
        responseEntity.getBody() >> Mock(JsonNode)

        when: "callBSSEMigrationService is invoked"
        bsseMigrationServiceHelper.callBSSEMigrationService(notification)

        then: "restTemplate.exchange is called with passcodevenc in the request body"
        1 * restTemplate.exchange(
                "http://test-server/test-endpoint",
                HttpMethod.POST,
                { HttpEntity<?> entity ->
                    String body = entity.body as String
                    body != null && body.contains("\"passcodeVenc\":\"${expectedPasscodevenc}\"")
                },
                JsonNode.class
        ) >> responseEntity
        0 * cosmosFailedEventsDBHelper.saveFailedEventsToCosmos(_, _)

        and: "No unexpected interactions occur"

        where:
        scenarioName | _
        "valid migration notification" | _
    }

    @Unroll
    def "should set productType based on serviceType for #scenarioName"() {
        given: "A migration notification with serviceType"
        MigrationBANNotification notification = new MigrationBANNotification(
                sourceBanId: "BAN123",
                targetIndividualId: "IND456",
                migrationId: "MIG789",
                sourceMarketCode: "US",
                guid: "GUID123",
                passcodeVenc: "testPasscode",
                serviceType: serviceType
        )
        ResponseEntity<JsonNode> responseEntity = Mock(ResponseEntity)
        responseEntity.getBody() >> Mock(JsonNode)

        when: "callBSSEMigrationService is invoked"
        bsseMigrationServiceHelper.callBSSEMigrationService(notification)

        then: "restTemplate.exchange is called with expected productType in the request body"
        1 * restTemplate.exchange(
                "http://test-server/test-endpoint",
                HttpMethod.POST,
                { HttpEntity<?> entity ->
                    String body = entity.body as String
                    body != null && body.contains("\"productType\":\"${expectedProductType}\"")
                },
                JsonNode.class
        ) >> responseEntity
        0 * cosmosFailedEventsDBHelper.saveFailedEventsToCosmos(_, _)

        where:
        scenarioName                  | serviceType | expectedProductType
        "Fiber serviceType"           | "Fiber"     | "UVERSE"
        "fiber lowercase"             | "fiber"     | "UVERSE"
        "FIBER uppercase"             | "FIBER"     | "UVERSE"
        "WIRELESS serviceType"        | "WIRELESS"  | "MOBILITY"
        "null serviceType"            | null        | "MOBILITY"
    }

    @Unroll
    def "should save failed event with correct eventName and accountType on non-OK response for #scenarioName"() {
        given: "A migration notification with serviceType and a non-OK response"
        MigrationBANNotification notification = new MigrationBANNotification(
                sourceBanId: "BAN123",
                targetIndividualId: "IND456",
                migrationId: "MIG789",
                sourceMarketCode: "US",
                guid: "GUID123",
                passcodeVenc: "testPasscode",
                serviceType: serviceType
        )
        ResponseEntity<JsonNode> responseEntity = Mock(ResponseEntity)
        responseEntity.getStatusCode() >> HttpStatus.BAD_REQUEST

        when: "callBSSEMigrationService is invoked"
        bsseMigrationServiceHelper.callBSSEMigrationService(notification)

        then: "failed event is saved with correct eventName"
        1 * restTemplate.exchange(_, _, _, _) >> responseEntity
        1 * cosmosFailedEventsDBHelper.saveFailedEventsToCosmos({ FailedEventDetails fed ->
            fed.eventName == expectedEventName
        })

        where:
        scenarioName           | serviceType | expectedEventName
        "Fiber serviceType"    | "Fiber"     | "BSSEMigFiberForward"
        "WIRELESS serviceType" | "WIRELESS"  | "BSSEMigWireless"
        "null serviceType"     | null        | "BSSEMigWireless"
    }

    @Unroll
    def "should save failed event with correct eventName on non-retryable exception for #scenarioName"() {
        given: "A migration notification with serviceType and a non-retryable exception"
        MigrationBANNotification notification = new MigrationBANNotification(
                sourceBanId: "BAN123",
                targetIndividualId: "IND456",
                migrationId: "MIG789",
                sourceMarketCode: "US",
                guid: "GUID123",
                passcodeVenc: "testPasscode",
                serviceType: serviceType
        )

        when: "callBSSEMigrationService is invoked"
        bsseMigrationServiceHelper.callBSSEMigrationService(notification)

        then: "failed event is saved with correct eventName"
        1 * restTemplate.exchange(_, _, _, _) >> { throw new RestClientException("Connection refused") }
        1 * cosmosFailedEventsDBHelper.saveFailedEventsToCosmos({ FailedEventDetails fed ->
            fed.eventName == expectedEventName
        })

        where:
        scenarioName           | serviceType | expectedEventName
        "Fiber serviceType"    | "Fiber"     | "BSSEMigFiberForward"
        "WIRELESS serviceType" | "WIRELESS"  | "BSSEMigWireless"
        "null serviceType"     | null        | "BSSEMigWireless"
    }

    def "should include eventId from notification in BsseMigrationRequest"() {
        given: "a notification with eventId"
        def notification = new MigrationBANNotification(
                sourceBanId: "BAN123",
                targetIndividualId: "IND456",
                migrationId: "MIG789",
                sourceMarketCode: "US",
                guid: "GUID123",
                passcodeVenc: "testPasscode",
                eventId: "evt-uuid-001"
        )
        def responseEntity = Mock(ResponseEntity)
        responseEntity.getBody() >> Mock(JsonNode)

        when: "callBSSEMigrationService is invoked"
        bsseMigrationServiceHelper.callBSSEMigrationService(notification)

        then: "restTemplate.exchange is called with eventId in the request body"
        1 * restTemplate.exchange(
                "http://test-server/test-endpoint",
                HttpMethod.POST,
                { HttpEntity<?> entity ->
                    String body = entity.body as String
                    body != null && body.contains('"eventId":"evt-uuid-001"')
                },
                JsonNode.class
        ) >> responseEntity
        0 * cosmosFailedEventsDBHelper.saveFailedEventsToCosmos(_, _)
    }
}