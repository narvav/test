package com.att.idp.idgraphconsumerms.kafka

import com.att.idp.idgraphconsumerms.constants.KafkaListenerConstants
import com.att.idp.idgraphconsumerms.kafka.config.KafkaConsumerProperties
import com.att.idp.idgraphconsumerms.kafka.config.KafkaConsumersConfig
import org.springframework.core.env.Environment
import org.springframework.kafka.config.KafkaListenerEndpointRegistry
import org.springframework.kafka.listener.MessageListenerContainer
import spock.lang.Specification

class KafkaConsumerAutoStartupRefresherTest extends Specification {

    def registry = Mock(KafkaListenerEndpointRegistry)
    def environment = Mock(Environment)
    def kafkaConsumersConfig = Mock(KafkaConsumersConfig)
    def refresher = new KafkaConsumerAutoStartupRefresher(registry, environment, kafkaConsumersConfig)

    def "should start listener when appconfig enables stopped consumer"() {
        given:
        def container = Mock(MessageListenerContainer)
        registry.getListenerContainer(KafkaListenerConstants.LISTENER_ACCOUNT_NOTIFICATION) >> container
        container.isRunning() >> false

        when:
        refresher.applyListenerState(KafkaListenerConstants.LISTENER_ACCOUNT_NOTIFICATION, true)

        then:
        1 * container.start()
        0 * container.stop()
    }

    def "should stop listener when appconfig disables running consumer"() {
        given:
        def container = Mock(MessageListenerContainer)
        registry.getListenerContainer(KafkaListenerConstants.LISTENER_ORDER_EVENTS) >> container
        container.isRunning() >> true

        when:
        refresher.applyListenerState(KafkaListenerConstants.LISTENER_ORDER_EVENTS, false)

        then:
        1 * container.stop()
        0 * container.start()
    }

    def "should apply all configured listener states"() {
        given:
        def account = Mock(MessageListenerContainer)
        def subscriber = Mock(MessageListenerContainer)
        def product = Mock(MessageListenerContainer)
        def external = Mock(MessageListenerContainer)
        def migration = Mock(MessageListenerContainer)
        def migrationInternal = Mock(MessageListenerContainer)
        def reverseMigration = Mock(MessageListenerContainer)
        def reverseMigrationInternal = Mock(MessageListenerContainer)
        def cgDmctn = Mock(MessageListenerContainer)
        def cgIndividual = Mock(MessageListenerContainer)
        def orderEvents = Mock(MessageListenerContainer)

        registry.getListenerContainer(KafkaListenerConstants.LISTENER_ACCOUNT_NOTIFICATION) >> account
        registry.getListenerContainer(KafkaListenerConstants.LISTENER_SUBSCRIBER_NOTIFICATION) >> subscriber
        registry.getListenerContainer(KafkaListenerConstants.LISTENER_PRODUCT_NOTIFICATION) >> product
        registry.getListenerContainer(KafkaListenerConstants.LISTENER_EXTERNAL_EVENTS) >> external
        registry.getListenerContainer(KafkaListenerConstants.LISTENER_BSSE_MIGRATION_OAUTH) >> migration
        registry.getListenerContainer(KafkaListenerConstants.LISTENER_BSSE_MIGRATION_INTERNAL) >> migrationInternal
        registry.getListenerContainer(KafkaListenerConstants.LISTENER_BSSE_REVERSE_MIGRATION_OAUTH) >> reverseMigration
        registry.getListenerContainer(KafkaListenerConstants.LISTENER_BSSE_REVERSE_MIGRATION_INTERNAL) >> reverseMigrationInternal
        registry.getListenerContainer(KafkaListenerConstants.LISTENER_CG_DMCTN) >> cgDmctn
        registry.getListenerContainer(KafkaListenerConstants.LISTENER_CG_INDIVIDUAL) >> cgIndividual
        registry.getListenerContainer(KafkaListenerConstants.LISTENER_ORDER_EVENTS) >> orderEvents

        def consumerMap = [
                accountnotificationconsumer: Stub(KafkaConsumerProperties) {
                    getAutoStartup() >> false
                },
                subscribernotificationconsumer: Stub(KafkaConsumerProperties) {
                    getAutoStartup() >> false
                },
                productnotificationconsumer: Stub(KafkaConsumerProperties) {
                    getAutoStartup() >> false
                },
                idgraphexternalevents: Stub(KafkaConsumerProperties) {
                    getAutoStartup() >> true
                },
                bssemigrationoauth: Stub(KafkaConsumerProperties) {
                    getAutoStartup() >> false
                },
                bssemigrationoauthinternal: Stub(KafkaConsumerProperties) {
                    getAutoStartup() >> true
                },
                bssereversemigoauth: Stub(KafkaConsumerProperties) {
                    getAutoStartup() >> false
                },
                bssereversemigoauthinternal: Stub(KafkaConsumerProperties) {
                    getAutoStartup() >> true
                },
                cgdmctnoauth: Stub(KafkaConsumerProperties) {
                    getAutoStartup() >> false
                },
                cgindividualoauth: Stub(KafkaConsumerProperties) {
                    getAutoStartup() >> false
                },
                ordereventsconsumer: Stub(KafkaConsumerProperties) {
                    getAutoStartup() >> false
                }
        ]
        kafkaConsumersConfig.getConsumer() >> consumerMap

        account.isRunning() >> true
        subscriber.isRunning() >> false
        product.isRunning() >> false
        external.isRunning() >> false
        migration.isRunning() >> false
        migrationInternal.isRunning() >> false
        reverseMigration.isRunning() >> false
        reverseMigrationInternal.isRunning() >> false
        cgDmctn.isRunning() >> false
        cgIndividual.isRunning() >> false
        orderEvents.isRunning() >> true

        when:
        refresher.applyAllListenerStates()

        then:
        1 * account.stop()
        1 * external.start()
        1 * migrationInternal.start()
        1 * reverseMigrationInternal.start()
        1 * orderEvents.stop()
    }

    def "should resolve auto startup from config before environment fallback"() {
        given:
        def consumerMap = [
                accountnotificationconsumer: Stub(KafkaConsumerProperties) {
                    getAutoStartup() >> true
                }
        ]
        kafkaConsumersConfig.getConsumer() >> consumerMap

        when:
        def result = refresher.resolveAutoStartup(KafkaListenerConstants.CONSUMER_ACCOUNT_NOTIFICATION)

        then:
        result == true
        0 * environment.getProperty(_, _, _)
    }

    def "should resolve order events auto startup from consumer config"() {
        given:
        def consumerMap = [
                ordereventsconsumer: Stub(KafkaConsumerProperties) {
                    getAutoStartup() >> true
                }
        ]
        kafkaConsumersConfig.getConsumer() >> consumerMap

        when:
        def result = refresher.resolveAutoStartup(KafkaListenerConstants.CONSUMER_ORDER_EVENTS)

        then:
        result == true
        0 * environment.getProperty(_, _, _)
    }

    def "should read default value when property is missing"() {
        when:
        def result = refresher.getAutoStartupProperty("idgraph.consumer.accountnotificationconsumer.autoStartup", false)

        then:
        1 * environment.getProperty("idgraph.consumer.accountnotificationconsumer.autoStartup", Boolean.class, false) >> false
        result == false
    }
}
