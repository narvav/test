package com.att.idp.component

import org.junit.jupiter.api.Test

import com.att.idp.idgraphconsumerms.model.User

class UserResourceTest extends CompTestBase {

    private String uri = '/users'

    def "test create user success"() {

        given:
        User user = new User('12345')
        user.name = 'Doe'

        expect:
        givenBaseSpec()
                .body(user)
                .when()
                .post(uri)
                .then()
                .statusCode(404) // Change to 201 when the endpoint is implemented
    }

/*


		@Test
		void "testCreateUser_failure"() {
			
			User user = new User('12345')

			givenBaseSpec()
				.body(user)
				.when()
					.post(uri)
					.then()
						.statusCode(400)

			givenBaseSpec()
			.body('')
			.when()
				.post(uri)
				.then()
					.statusCode(400)
		}
		
		@Test
		void "testGetUser_success"() {
			
			User user = new User('22222')
			user.name = 'Doe'

			givenBaseSpec()
				.body(user)
				.when()
					.post(uri)
					.then()
					.statusCode(201)

			givenBaseSpec()
			.when()
				.get(uri + '/22222')
				.then()
					.statusCode(200)

			givenBaseSpec()
			.when()
				.get(uri + '/string/22222')
				.then()
					.statusCode(200)

*/


//		@Test
//		public void testString_success() {
//				
//			givenBaseSpec()
//				.body("{Test123}")
//				.when()
//					.post(uri+"/string")
//					.then()
//					.statusCode(201);
//
//			givenBaseSpec()
//			.when()
//				.get(uri + "/string/Test123")
//				.then()
//					.statusCode(200);
//		}


}