package com.att.idp.idgraphconsumerms.helpers
import com.att.idp.idgraphconsumerms.kafka.model.UserIdNotification
import com.att.idp.idgraphconsumerms.kafka.model.UserIdNotificationEventDetails
import com.att.idp.idgraph.events.service.ResilientEventPublisher
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import spock.lang.Unroll

class NotificationEventProcessorHelperTest extends Specification {

    ResilientEventPublisher mockEventsPublisher = Mock(ResilientEventPublisher)
    CTypeHelper mockCTypeHelper = Mock(CTypeHelper)
    UserIDNotificationEventDetailsHelper mockUserIDNotificationEventDetailsHelper= Mock(UserIDNotificationEventDetailsHelper)
    NotificationEventProcessorHelper helper = new NotificationEventProcessorHelper()

    def setup() {

        helper.resilientEventPublisher = mockEventsPublisher
        helper.ctypeHelper = mockCTypeHelper
        helper.userIDNotificationEventDetailsHelper =mockUserIDNotificationEventDetailsHelper
        ReflectionTestUtils.setField(helper, "userIdNotificationsTopicName", "test-topic")
        ReflectionTestUtils.setField(helper, 'secondaryUserNotificationTypes', 'ONLINE_ACCOUNT_ADD_SEC|ONLINE_ACCOUNT_ADD2|CTN_ADDED_TO_ACCESSID|CTN_REMOVED_FROM_ACCESSID|CTN_CHANGED_ON_ACCESSID')
    }

    @Unroll
    def "should process notification event for #scenarioName"() {
        given: "A valid event and input map"

        Map<String, Object> event = [
                sorName            : "MO",
                "targetSOR" : "TELEGANCE-DB",
                accountId          : "345453434543",
                key                : 'val',
                transactionName    : 'AddAccount',
                serviceType        : 'MOSUB',
                slid               : 'qay_94455448',
                hashKey            : '1020447771',
                origTransactionName: 'AddAssociation',
                subEvent           : 'SLID',
                sor_name           : 'NA',
                sorInvariantId     : '4503495310',
                handle             : 'qay_94455448',
                callingSystemId    : 'IDP',
                services           : [
                        [
                                service_name: "MOBILITY",
                                serviceType: "MOBILITY",
                                instance_id: "4503495310",
                                instanceId: "4503495310",
                                sor_name: "MO",
                                sorName: "MO",
                                service_status:"Enabled",
                                sorInvariantId: "4503495310",
                                serviceStatus: "Enabled"
                        ]
                ],
                transactionId      : '5261649103111e53',
                eventname          : 'NotificationEvent',
                parentDomain       : 'slid.dum',
                dbus_DictionaryName: 'Dict',
                notificationData   : [
                        [
                                secondaryAccessGranted: "Y",
                                memberContactEmail    : [
                                        [memberType: "Delegate"],
                                        [contactEmail: "anusbgr766@mail.com", contactEmailStatus: "V", memberType: "Owner"]
                                ]
                        ],
                        [
                                ownerSLID: "qay_94455448"
                        ]
                ],
                member_num         : '1020447771',
                origTransactionId  : '5261649103111e53',
                domain             : 'slid.dum',
                parentHandle       : 'qay_94455448'
        ]
        Map<String, Object> inputMap = [
                sorName            : "MO",
                serviceType        : 'MOSUB',
                accountId          : "345453434543",
                msName             : "IDGraphUserAssociationMS-",
                mainHashKey        : "1020447771",
                msOperation        : "AddAssociation",
                eventType          : "UserAssociation",
                hmServices         : [
                        INDIVIDUAL: [[sor_invariant_id: "456456546546"]],
                        TITAN     : [/* fill with actual map if needed */]
                ],
                transactionName    : "AddAssociation",
                callingSystemId    : "IDP",
                eventname          : "MicroServiceEvent",
                transactionId      : "5261649103111e53:5261649103111e53:0:1",
                eventsData         : [/* fill with actual map if needed */],
                dbus_DictionaryName: "Dict",
                serviceStatus      : "Enabled",
                hmService          : [
                        sorName                : "MO",
                        instanceId             : "4503495310",
                        encryptedSorInvariantId: "9945f80f202f137dc04f8f260982121c",
                        serviceStatus          : "Enabled",
                        nickName               : "Account(1)",
                        attributeList          : [],
                        sorInvariantId         : "4503495310",
                        defaultAccount         : null,
                        serviceName            : "MOSUB",
                        cpniImpacted           : null
                ]
        ]
        List<Map<String, Object>> cTypes = [
                [cType: "CTN_ADDED_TO_ACCESSID", NotificationLevel: "LEVEL1", isCPNINotification: "Y"]
        ]
        UserIdNotificationEventDetails eventDetails = UserIdNotificationEventDetails.builder()
                .subCategory("CTN_ADDED_TO_ACCESSID")
                .build()
        UserIdNotification userIdNotification = UserIdNotification.builder()
                .eventId("ms123LOCAL")
                .eventType("type")
                .eventName("op")
                .customerNotification("true")
                .eventDetails(eventDetails)
                .build()

        mockCTypeHelper.generateCtype(event) >> cTypes
        mockUserIDNotificationEventDetailsHelper.populateClmInputNotification(event, _, inputMap) >> { args -> args[1].put("cType", "CTN_ADDED_TO_ACCESSID") }
        helper.metaClass.buildEvent = { Map e, Map n, Map i -> userIdNotification }

        when: "processNotificationEvent is called"
        helper.processNotificationEvent(event, inputMap)

        then: "Event is published with correct details"
        0 * mockEventsPublisher.sendWithFallback("userIdNotifications", "CLM Notification", _, userIdNotification)

        and: "No exception is thrown"
        noExceptionThrown()

        where:
        scenarioName | _
        "valid event" | _
    }

    def "should not process when event is null"() {
        given: "A null event"
        Map<String, Object> event = null
        Map<String, Object> inputMap = [:]

        when: "processNotificationEvent is called"
        helper.processNotificationEvent(event, inputMap)

        then: "No interactions with publisher"
        0 * mockEventsPublisher._
        0 * mockCTypeHelper._
        0 * mockUserIDNotificationEventDetailsHelper._
        0 * _
    }

    @Unroll
    def "should not publish event if cType not in secondaryUserNotificationTypes for #scenarioName"() {
        given: "Event with cType not in allowed list"
        Map<String, Object> event = [
                "cType" : "C3",
                "NotificationLevel": "LEVEL1",
                "isCPNINotification": "N",
                "transactionName": "txn"
        ]
        Map<String, Object> inputMap = [
                "msName": "ms",
                "eventType": "type",
                "msOperation": "op",
                "transactionName": "txn",
                "transactionId": "123"
        ]
        List<Map<String, Object>> cTypes = [
                [cType: "C3", NotificationLevel: "LEVEL1", isCPNINotification: "N"]
        ]
        mockCTypeHelper.generateCtype(event) >> cTypes

        when: "processNotificationEvent is called"
        helper.processNotificationEvent(event, inputMap)

        then: "No event is published"
        0 * mockEventsPublisher._
        0 * mockUserIDNotificationEventDetailsHelper._
        0 * _

        where:
        scenarioName | _
        "cType not allowed" | _
    }
    @Unroll
    def "should log error and not throw when exception occurs in processNotificationEvent for #scenarioName"() {
        given: "A scenario where generateCtype throws exception"
        Map<String, Object> event = [eventname: "NotificationEvent"]
        Map<String, Object> inputMap = [:]
        RuntimeException exception = new RuntimeException("Simulated failure\r\nwith CRLF")
        mockCTypeHelper.generateCtype(event) >> { throw exception }
        NotificationEventProcessorHelper helper = new NotificationEventProcessorHelper()
        helper.resilientEventPublisher = mockEventsPublisher
        helper.ctypeHelper = mockCTypeHelper
        helper.userIDNotificationEventDetailsHelper = mockUserIDNotificationEventDetailsHelper
        ReflectionTestUtils.setField(helper, "userIdNotificationsTopicName", "test-topic")
        ReflectionTestUtils.setField(helper, "secondaryUserNotificationTypes", "CTN_ADDED_TO_ACCESSID")

        when: "processNotificationEvent is called"
        helper.processNotificationEvent(event, inputMap)

        then: "No event is published and error is logged"
        0 * mockEventsPublisher._
        0 * mockUserIDNotificationEventDetailsHelper._
        0 * _

        and: "No exception is thrown"
        noExceptionThrown()

        where:
        scenarioName | _
        "exception thrown in generateCtype" | _
    }
}
