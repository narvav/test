package com.att.idp.idgraphconsumerms.kafka.dmctn.service

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker
import com.att.idp.idgraphconsumerms.kafka.model.AccountNotificationEvent
import com.att.idp.idgraphconsumerms.model.RGActivationPlatformHandlerRequest
import com.att.mpsys.common.utils.CErrorDefs
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class RGActivationNotificationServiceTest extends Specification {

    ApiRestClient apiRestClient
    CosmosFailedEventsWriter cosmosFailedEventsWriter
    RGActivationNotificationService serviceUnderTest

    void setup() {
        apiRestClient = Mock(ApiRestClient)
        cosmosFailedEventsWriter = Mock(CosmosFailedEventsWriter)
        serviceUnderTest = new RGActivationNotificationService(apiRestClient)
        ReflectionTestUtils.setField(serviceUnderTest, "cosmosFailedEventsWriter", cosmosFailedEventsWriter)
        ReflectionTestUtils.setField(serviceUnderTest, "rgActivationEndpoint", "/mock/rgActivation")
        def circuitBreaker = Stub(GddnFailedEventCircuitBreaker) { shouldShortCircuit(_, _) >> false }
        ReflectionTestUtils.setField(serviceUnderTest, "gddnFailedEventCircuitBreaker", circuitBreaker)
    }

    def "should call rgActivation endpoint with BAN"() {
        given:
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(ConsumerConstants.ProductNotificationConstants.EVENT_TYPE_RG_NOTIFICATION)
        event.setAccountNumber("883308443")
        event.setEventId("trace-123")

        when:
        serviceUnderTest.execute(event)

        then:
        1 * apiRestClient.sendPostRequest("/mock/rgActivation", { RGActivationPlatformHandlerRequest req ->
            req.ban == '883308443' &&
                    req.callingSystemId == ConsumerConstants.DmctnSubscriberChangeEvent.CLIENT_ATLASBUS &&
                    req.rgActivated == 'Y'
        }, ConsumerConstants.GridGddnNotification.EVENT_GDDN_RG_ACTIVATION, ConsumerConstants.AccountNotificationConstants.UVERSE)
        0 * _
    }

    def "should save failed event with VALIDATION_FAILED status when billingAccountNumber is missing"() {
        given:
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(ConsumerConstants.ProductNotificationConstants.EVENT_TYPE_RG_NOTIFICATION)
        event.setEventId("trace-456")

        when:
        serviceUnderTest.execute(event)

        then:
        0 * apiRestClient._
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ it.status == "VALIDATION_FAILED" &&
                it.eventCategory == ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_RG_ACTIVATION })
        0 * _
    }

    def "should save failed event with VALIDATION_FAILED status when billingAccountNumber is blank"() {
        given:
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(ConsumerConstants.ProductNotificationConstants.EVENT_TYPE_RG_NOTIFICATION)
        event.setAccountNumber("   ")
        event.setEventId("trace-789")

        when:
        serviceUnderTest.execute(event)

        then:
        0 * apiRestClient._
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ it.status == "VALIDATION_FAILED" &&
                it.eventCategory == ConsumerConstants.GridGddnNotification.CATEGORY_GDDN_RG_ACTIVATION })
        0 * _
    }

    def "should save failed event when apiRestClient throws exception"() {
        given:
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(ConsumerConstants.ProductNotificationConstants.EVENT_TYPE_RG_NOTIFICATION)
        event.setAccountNumber("883308443")
        event.setEventId("trace-err")

        when:
        serviceUnderTest.execute(event)

        then:
        1 * apiRestClient.sendPostRequest("/mock/rgActivation", { RGActivationPlatformHandlerRequest req ->
            req.ban == '883308443' &&
                    req.callingSystemId == ConsumerConstants.DmctnSubscriberChangeEvent.CLIENT_ATLASBUS &&
                    req.rgActivated == 'Y'
        }, ConsumerConstants.GridGddnNotification.EVENT_GDDN_RG_ACTIVATION, ConsumerConstants.AccountNotificationConstants.UVERSE) >> { throw new RuntimeException("connection refused") }
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ it.accountId == '883308443' &&
                it.eventName == ConsumerConstants.GridGddnNotification.EVENT_GDDN_RG_ACTIVATION &&
                it.errorDetails.errorCode == CErrorDefs.SYS_ERR &&
                it.errorDetails.errorMessage == 'connection refused' &&
                it.errorDetails.failedEndpoint == '/mock/rgActivation' &&
                it.errorDetails.accountType == ConsumerConstants.AccountNotificationConstants.UVERSE
        })
        0 * _
    }

    def "should short-circuit to Cosmos when circuit breaker is OPEN"() {
        given: "Circuit breaker returns true (pending failed events exist)"
        def openCircuitBreaker = Stub(GddnFailedEventCircuitBreaker) {
            shouldShortCircuit("883308443", ConsumerConstants.GridGddnNotification.EVENT_GDDN_RG_ACTIVATION) >> true
        }
        ReflectionTestUtils.setField(serviceUnderTest, "gddnFailedEventCircuitBreaker", openCircuitBreaker)

        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setAccountNumber("883308443")
        event.setEventName(ConsumerConstants.ProductNotificationConstants.EVENT_TYPE_RG_NOTIFICATION)
        event.setEventId("trace-cb")

        when:
        serviceUnderTest.execute(event)

        then: "API client is never called"
        0 * apiRestClient._

        and: "Failed event is saved to Cosmos with circuit breaker message"
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ it.accountId == "883308443" &&
                it.eventName == ConsumerConstants.GridGddnNotification.EVENT_GDDN_RG_ACTIVATION })
        0 * _
    }
}
