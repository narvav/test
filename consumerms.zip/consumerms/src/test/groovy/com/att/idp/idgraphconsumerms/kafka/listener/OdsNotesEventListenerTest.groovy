package com.att.idp.idgraphconsumerms.kafka.listener

import com.att.idp.idgraph.events.service.ResilientEventPublisher
import com.att.idp.idgraphconsumerms.constants.OdsNotesConstants
import com.att.idp.idgraphconsumerms.helpers.OdsNotesTransformHelper
import com.att.idp.idgraphconsumerms.kafka.model.OdsGenerateNotesEvent
import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.kafka.support.Acknowledgment
import spock.lang.Specification

class OdsNotesEventListenerTest extends Specification {

    OdsNotesTransformHelper transformHelper = Mock(OdsNotesTransformHelper)
    ResilientEventPublisher resilientEventPublisher = Mock(ResilientEventPublisher)
    ListenerContainerManager listenerContainerManager = Mock(ListenerContainerManager)
    ObjectMapper objectMapper = new ObjectMapper()
    Acknowledgment ack = Mock(Acknowledgment)

    OdsNotesEventListener listener

    def setup() {
        listener = new OdsNotesEventListener(transformHelper, resilientEventPublisher,
                listenerContainerManager, objectMapper)
    }

    // ==================== Happy Path ====================

    def "T-EL-1: Happy path — Oracle event consumed, transformed, published, acked"() {
        given: "A valid Oracle event JSON"
        String message = '{"eventId": "evt-1", "eventType": "OracleSecurityCodeSync"}'
        OdsGenerateNotesEvent event = OdsGenerateNotesEvent.builder()
                .transactionId("evt-1")
                .eventType("Number Transfer PIN")
                .build()

        when: "onOracleEvent is called"
        listener.onOracleEvent(message, ack)

        then: "Transform is called, event is published, and ack is called"
        1 * transformHelper.transformOracleSecurityCodeEvent(_) >> Optional.of(event)
        1 * resilientEventPublisher.sendWithFallback(
                OdsNotesConstants.ODS_GENERATE_NOTES_BINDING,
                OdsNotesConstants.ODS_GENERATE_NOTES_LABEL,
                "evt-1", event) >> true
        1 * ack.acknowledge()
        0 * _
    }

    def "T-EL-1b: Happy path — Profile Update event consumed, transformed, published, acked"() {
        given: "A valid Profile Update event JSON"
        String message = '{"eventId": "evt-pu", "eventType": "ProfileUpdate", "category": "Passcode"}'
        OdsGenerateNotesEvent event = OdsGenerateNotesEvent.builder()
                .transactionId("evt-pu")
                .eventType("Change BAN Passcode")
                .build()

        when: "onProfileUpdateEvent is called"
        listener.onProfileUpdateEvent(message, ack)

        then: "Transform is called, event is published, and ack is called"
        1 * transformHelper.transformProfileUpdateEvent(_) >> Optional.of(event)
        1 * resilientEventPublisher.sendWithFallback(_, _, "evt-pu", event) >> true
        1 * ack.acknowledge()
        0 * _
    }

    def "T-EL-1c: Happy path — UserId Notification event consumed, transformed, published, acked"() {
        given: "A valid UserId Notification event JSON"
        String message = '{"eventId": "evt-un", "eventName": "UpdateUserFraud"}'
        OdsGenerateNotesEvent event = OdsGenerateNotesEvent.builder()
                .transactionId("evt-un")
                .eventType("Fraud Lock")
                .build()

        when: "onUserIdNotificationEvent is called"
        listener.onUserIdNotificationEvent(message, ack)

        then: "Transform is called, event is published, and ack is called"
        1 * transformHelper.transformUserFraudEvent(_) >> Optional.of(event)
        1 * resilientEventPublisher.sendWithFallback(_, _, "evt-un", event) >> true
        1 * ack.acknowledge()
        0 * _
    }

    // ==================== Error Scenarios ====================

    def "T-EL-2: Malformed JSON — JsonProcessingException, log error, ack"() {
        given: "An invalid JSON string"
        String message = "this is not valid json {{"

        when: "onOracleEvent is called"
        listener.onOracleEvent(message, ack)

        then: "No transform or publish is called, ack is still called"
        0 * transformHelper._
        0 * resilientEventPublisher._
        1 * ack.acknowledge()
        0 * _
    }

    def "T-EL-3: Double-encoded JSON — re-parsed successfully"() {
        given: "A double-encoded JSON string"
        String innerJson = '{"eventId":"evt-double","eventType":"OracleSecurityCodeSync"}'
        String message = objectMapper.writeValueAsString(innerJson)
        OdsGenerateNotesEvent event = OdsGenerateNotesEvent.builder()
                .transactionId("evt-double")
                .eventType("Number Transfer PIN")
                .build()

        when: "onOracleEvent is called"
        listener.onOracleEvent(message, ack)

        then: "Transform is called after re-parse, event published"
        1 * transformHelper.transformOracleSecurityCodeEvent(_) >> Optional.of(event)
        1 * resilientEventPublisher.sendWithFallback(_, _, "evt-double", event) >> true
        1 * ack.acknowledge()
        0 * _
    }

    def "T-EL-4: Transformation exception — log error, ack"() {
        given: "A valid JSON that causes transform to throw"
        String message = '{"eventId": "evt-err", "eventType": "OracleSecurityCodeSync"}'

        when: "onOracleEvent is called"
        listener.onOracleEvent(message, ack)

        then: "Transform throws, no publish, ack still called"
        1 * transformHelper.transformOracleSecurityCodeEvent(_) >> {
            throw new RuntimeException("Unexpected null field")
        }
        0 * resilientEventPublisher._
        1 * ack.acknowledge()
        0 * _
    }

    def "T-EL-5: Filter rejection — Optional.empty, ack, no publish"() {
        given: "A valid JSON that doesn't match filter"
        String message = '{"eventId": "evt-skip", "eventType": "OracleSecurityCodeSync"}'

        when: "onOracleEvent is called"
        listener.onOracleEvent(message, ack)

        then: "Transform returns empty, no publish, ack called"
        1 * transformHelper.transformOracleSecurityCodeEvent(_) >> Optional.empty()
        0 * resilientEventPublisher._
        1 * ack.acknowledge()
        0 * _
    }

    def "T-EL-6: Publish success — sendWithFallback returns true"() {
        given: "A valid event that transforms and publishes successfully"
        String message = '{"eventId": "evt-ok"}'
        OdsGenerateNotesEvent event = OdsGenerateNotesEvent.builder()
                .transactionId("evt-ok")
                .eventType("Change BAN Passcode")
                .build()

        when: "onProfileUpdateEvent is called"
        listener.onProfileUpdateEvent(message, ack)

        then: "Publish returns true, no transient error recorded"
        1 * transformHelper.transformProfileUpdateEvent(_) >> Optional.of(event)
        1 * resilientEventPublisher.sendWithFallback(_, _, "evt-ok", event) >> true
        0 * listenerContainerManager.onTransientError(_)
        1 * ack.acknowledge()
        0 * _
    }

    def "T-EL-7: Publish failure — sendWithFallback returns false, transient error recorded, ack"() {
        given: "A valid event where publishing fails"
        String message = '{"eventId": "evt-fail"}'
        OdsGenerateNotesEvent event = OdsGenerateNotesEvent.builder()
                .transactionId("evt-fail")
                .eventType("Fraud Lock")
                .build()

        when: "onUserIdNotificationEvent is called"
        listener.onUserIdNotificationEvent(message, ack)

        then: "Publish returns false, transient error recorded, ack still called"
        1 * transformHelper.transformUserFraudEvent(_) >> Optional.of(event)
        1 * resilientEventPublisher.sendWithFallback(_, _, "evt-fail", event) >> false
        1 * listenerContainerManager.onTransientError("notesUserIdNotificationsListener")
        1 * ack.acknowledge()
        0 * _
    }

    def "T-EL-8: Null eventId — fallback to UUID for MDC"() {
        given: "A valid JSON with no eventId"
        String message = '{"eventType": "ProfileUpdate", "category": "Passcode"}'
        OdsGenerateNotesEvent event = OdsGenerateNotesEvent.builder()
                .transactionId(null)
                .eventType("Change BAN Passcode")
                .build()

        when: "onProfileUpdateEvent is called"
        listener.onProfileUpdateEvent(message, ack)

        then: "Transform and publish still proceed, ack called"
        1 * transformHelper.transformProfileUpdateEvent(_) >> Optional.of(event)
        1 * resilientEventPublisher.sendWithFallback(_, _, null, event) >> true
        1 * ack.acknowledge()
        0 * _
    }

    def "T-EL-9: ack always called — even when publish throws unexpected exception"() {
        given: "A valid event where sendWithFallback throws unexpectedly"
        String message = '{"eventId": "evt-boom"}'
        OdsGenerateNotesEvent event = OdsGenerateNotesEvent.builder()
                .transactionId("evt-boom")
                .eventType("Number Transfer PIN")
                .build()

        when: "onOracleEvent is called"
        listener.onOracleEvent(message, ack)

        then: "Even with unexpected exception, ack is called in finally"
        1 * transformHelper.transformOracleSecurityCodeEvent(_) >> Optional.of(event)
        1 * resilientEventPublisher.sendWithFallback(_, _, _, _) >> {
            throw new RuntimeException("Unexpected broker error")
        }
        1 * ack.acknowledge()
        thrown(RuntimeException)
    }
}
