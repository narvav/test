package com.att.idp.idgraphconsumerms.utils

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import com.att.idp.idgraphconsumerms.utils.JsonService
import spock.lang.Specification

class JsonServiceTest extends Specification {



	def "test convertToObject with valid JSON string"() {
		given:
		def jsonString = '{"key":"value"}'

		when:
		def result = JsonService.convertToObject(jsonString, Map.class)

		then:
		result == [key: "value"]
	}

	def "test toJsonString with valid object"() {
		given:
		def input = [key: "value"]

		when:
		def result = JsonService.toJsonString(input)

		then:
		result == '{"key":"value"}'
	}

	def "test toJsonString with null object"() {
		when:
		def result = JsonService.toJsonString(null)

		then:
		result == "EMPTY_JSON"
	}
}