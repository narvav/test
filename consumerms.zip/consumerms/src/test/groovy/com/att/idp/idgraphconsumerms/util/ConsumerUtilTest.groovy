package com.att.idp.idgraphconsumerms.util

import com.att.idp.idgraphconsumerms.utils.ConsumerUtil
import spock.lang.Specification

class ConsumerUtilTest extends Specification {

	def "should print decrypted value for AES decryption"() {
		given: "An encrypted string and AES key"
		String encrypted = "e9380e4835687c7153ff4b388e2fac63"
		String aesKey = "16cd6d4581316cd7dfed29e087b10b145ddac92a62ed47ca2b4b60ea1b1f74fe"

		when: "Decrypting the string"
		String decrypted = ConsumerUtil.getAESDecryption(encrypted, aesKey)

		then: "Print the decrypted value"
		println(decrypted)

		and: "Decrypted value should not be null"
		decrypted != null
	}

	// ==================== extractServicesWithFullFallback Tests ====================

	def "extractServicesWithFullFallback returns root services when present"() {
		given: "event with root-level services"
		Map<String, Object> event = [
				services: [[serviceType: "HSIA"], [serviceType: "PORTAL"]]
		]

		when:
		List<Map<String, Object>> result = ConsumerUtil.extractServicesWithFullFallback(event)

		then:
		0 * _

		and:
		result != null
		result.size() == 2
		result[0].serviceType == "HSIA"
		result[1].serviceType == "PORTAL"
	}

	def "extractServicesWithFullFallback falls back to memberInfo/services when root is null"() {
		given: "event with no root services but memberInfo containing services"
		Map<String, Object> event = [
				memberInfo: [
						[services: [[serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]]
				]
		]

		when:
		List<Map<String, Object>> result = ConsumerUtil.extractServicesWithFullFallback(event)

		then:
		0 * _

		and:
		result != null
		result.size() == 1
		result[0].serviceType == "PORTAL"
	}

	def "extractServicesWithFullFallback falls back to memberInfo/addServices when services not found"() {
		given: "event with no root or memberInfo/services but has addServices"
		Map<String, Object> event = [
				memberInfo: [
						[addServices: [[serviceType: "HSIA"]]]
				]
		]

		when:
		List<Map<String, Object>> result = ConsumerUtil.extractServicesWithFullFallback(event)

		then:
		0 * _

		and:
		result != null
		result.size() == 1
		result[0].serviceType == "HSIA"
	}

	def "extractServicesWithFullFallback falls back to memberInfo/removeServices"() {
		given: "event with removeServices in memberInfo"
		Map<String, Object> event = [
				memberInfo: [
						[removeServices: [[serviceType: "IPTV"]]]
				]
		]

		when:
		List<Map<String, Object>> result = ConsumerUtil.extractServicesWithFullFallback(event)

		then:
		0 * _

		and:
		result != null
		result.size() == 1
		result[0].serviceType == "IPTV"
	}

	def "extractServicesWithFullFallback returns null when no services found anywhere"() {
		given: "event with no services at any level"
		Map<String, Object> event = [eventname: "someEvent"]

		when:
		List<Map<String, Object>> result = ConsumerUtil.extractServicesWithFullFallback(event)

		then:
		0 * _

		and:
		result == null
	}

	def "extractServicesWithFullFallback returns null for empty root services and no memberInfo"() {
		given: "event with empty root services list"
		Map<String, Object> event = [services: []]

		when:
		List<Map<String, Object>> result = ConsumerUtil.extractServicesWithFullFallback(event)

		then:
		0 * _

		and:
		result == null
	}

	def "extractServicesWithFullFallback prefers memberInfo/services over addServices"() {
		given: "memberInfo with both services and addServices"
		Map<String, Object> event = [
				memberInfo: [
						[
								services   : [[serviceType: "PORTAL"]],
								addServices: [[serviceType: "HSIA"]]
						]
				]
		]

		when:
		List<Map<String, Object>> result = ConsumerUtil.extractServicesWithFullFallback(event)

		then:
		0 * _

		and: "memberInfo/services is returned (higher priority)"
		result != null
		result.size() == 1
		result[0].serviceType == "PORTAL"
	}

	def "extractServicesWithFullFallback handles non-list memberInfo"() {
		given: "event with non-list memberInfo"
		Map<String, Object> event = [memberInfo: "notAList"]

		when:
		List<Map<String, Object>> result = ConsumerUtil.extractServicesWithFullFallback(event)

		then:
		0 * _

		and:
		result == null
	}

	def "extractServicesWithFullFallback handles empty memberInfo list"() {
		given: "event with empty memberInfo list"
		Map<String, Object> event = [memberInfo: []]

		when:
		List<Map<String, Object>> result = ConsumerUtil.extractServicesWithFullFallback(event)

		then:
		0 * _

		and:
		result == null
	}

	def "extractServicesWithFullFallback combines services from multiple memberInfo entries"() {
		given: "event with multiple memberInfo entries each having services"
		Map<String, Object> event = [
				memberInfo: [
						[services: [[serviceType: "PORTAL"]]],
						[services: [[serviceType: "HSIA"]]]
				]
		]

		when:
		List<Map<String, Object>> result = ConsumerUtil.extractServicesWithFullFallback(event)

		then:
		0 * _

		and: "services from both memberInfo entries are combined"
		result != null
		result.size() == 2
		result[0].serviceType == "PORTAL"
		result[1].serviceType == "HSIA"
	}

	def "extractServicesWithFullFallback skips non-map entries in root services"() {
		given: "event with non-map entries in services list"
		Map<String, Object> event = [
				services: ["stringEntry", 123, [serviceType: "HSIA"]]
		]

		when:
		List<Map<String, Object>> result = ConsumerUtil.extractServicesWithFullFallback(event)

		then:
		0 * _

		and: "only map entries are included"
		result != null
		result.size() == 1
		result[0].serviceType == "HSIA"
	}

	def "extractServicesWithFullFallback skips non-map memberInfo entries"() {
		given: "event with non-map memberInfo entries"
		Map<String, Object> event = [
				memberInfo: ["notAMap", [services: [[serviceType: "PORTAL"]]]]
		]

		when:
		List<Map<String, Object>> result = ConsumerUtil.extractServicesWithFullFallback(event)

		then:
		0 * _

		and: "only valid map memberInfo entries are processed"
		result != null
		result.size() == 1
		result[0].serviceType == "PORTAL"
	}

	def "extractServicesWithFullFallback falls back to memberInfo when root has only non-map entries"() {
		given: "event with non-map root services but valid memberInfo"
		Map<String, Object> event = [
				services  : ["string1", 123],
				memberInfo: [
						[services: [[serviceType: "PORTAL"]]]
				]
		]

		when:
		List<Map<String, Object>> result = ConsumerUtil.extractServicesWithFullFallback(event)

		then:
		0 * _

		and: "falls back to memberInfo since root services had no valid map entries"
		result != null
		result.size() == 1
		result[0].serviceType == "PORTAL"
	}

	def "extractServicesWithFullFallback returns null when root has only non-map entries and no memberInfo"() {
		given: "event with non-map-only root services and no memberInfo"
		Map<String, Object> event = [
				services: ["string1", "string2"]
		]

		when:
		List<Map<String, Object>> result = ConsumerUtil.extractServicesWithFullFallback(event)

		then:
		0 * _

		and:
		result == null
	}

	def "extractServicesWithFullFallback combines addServices from multiple memberInfo entries"() {
		given: "event with multiple memberInfo entries having addServices"
		Map<String, Object> event = [
				memberInfo: [
						[addServices: [[serviceType: "HSIA"]]],
						[addServices: [[serviceType: "IPTV"]]]
				]
		]

		when:
		List<Map<String, Object>> result = ConsumerUtil.extractServicesWithFullFallback(event)

		then:
		0 * _

		and: "addServices from both entries are combined"
		result != null
		result.size() == 2
		result[0].serviceType == "HSIA"
		result[1].serviceType == "IPTV"
	}

	def "extractServicesWithFullFallback handles memberInfo with mixed addServices and removeServices"() {
		given: "memberInfo entries with one having addServices, another having removeServices"
		Map<String, Object> event = [
				memberInfo: [
						[addServices: [[serviceType: "HSIA"]]],
						[removeServices: [[serviceType: "IPTV"]]]
				]
		]

		when:
		List<Map<String, Object>> result = ConsumerUtil.extractServicesWithFullFallback(event)

		then:
		0 * _

		and: "both addServices and removeServices are included"
		result != null
		result.size() == 2
		result[0].serviceType == "HSIA"
		result[1].serviceType == "IPTV"
	}

	def "extractServicesWithFullFallback handles single map service in addServices"() {
		given: "memberInfo with addServices as a single map instead of list"
		Map<String, Object> event = [
				memberInfo: [
						[addServices: [serviceType: "PORTAL", portalProvider: "AT&T Yahoo"]]
				]
		]

		when:
		List<Map<String, Object>> result = ConsumerUtil.extractServicesWithFullFallback(event)

		then:
		0 * _

		and: "single map addServices is extracted"
		result != null
		result.size() == 1
		result[0].serviceType == "PORTAL"
	}
}
