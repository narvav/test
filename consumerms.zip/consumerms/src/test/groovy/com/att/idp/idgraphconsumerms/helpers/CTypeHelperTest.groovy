package com.att.idp.idgraphconsumerms.helpers

import spock.lang.Specification
import spock.lang.Unroll

class CTypeHelperTest extends Specification {


    @Unroll
    def "should extract customerType for #scenarioName"() {
        given: "An event map with or without customerType"
        Map<String, Object> event = inputEvent

        when: "getCustomerType is called"
        Optional<String> result = CTypeHelper.getCustomerType(event)

        then: "Result matches expected outcome"
        result.isPresent() == expectedPresent
        if (expectedPresent) {
            result.get() == expectedValue
        }

        where:
        scenarioName  | inputEvent                 | expectedPresent | expectedValue
        "null event"  | null                       | false           | null
        "missing key" | [foo: "bar"]               | false           | null
        "wrong type"  | [customerType: 123]        | false           | null
        "valid type"  | [customerType: "BUSINESS"] | true            | "BUSINESS"
    }

    @Unroll
    def "should generate correct cType for transactionName=#transactionName scenario #scenarioName"() {
        given: "A complex event map for transactionName"
        Map<String, Object> event = inputEvent

        when: "generateCtype is called"
        List<Map<String, Object>> result = CTypeHelper.generateCtype(event)

        then: "Result contains expected cType(s)"
        result != null
        result*.get("cType") == expectedCtypes
        if (expectedCtypes.contains("ONLINE_ACCOUNT_REG")) {
            Map<String, Object> onlineAccountReg = result.find { it.get("cType") == "ONLINE_ACCOUNT_REG" }
            assert onlineAccountReg.get("NotificationLevel") == "Account"
            assert onlineAccountReg.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.contains("CTN_ADDED_TO_ACCESSID")) {
            Map<String, Object> ctnAdded = result.find { it.get("cType") == "CTN_ADDED_TO_ACCESSID" }
            assert ctnAdded.get("NotificationLevel") == "UserId"
            assert ctnAdded.get("isCPNINotification") == "false"
        }
        if (expectedCtypes.contains("ACCESS_GRANTED_PRIMARY")) {
            Map<String, Object> accessPrimary = result.find { it.get("cType") == "ACCESS_GRANTED_PRIMARY" }
            assert accessPrimary.get("NotificationLevel") == "Owner"
            assert accessPrimary.get("isCPNINotification") == "false"
        }
        if (expectedCtypes.contains("ACCESS_GRANTED_SECONDARY")) {
            Map<String, Object> accessSecondary = result.find { it.get("cType") == "ACCESS_GRANTED_SECONDARY" }
            assert accessSecondary.get("NotificationLevel") == "Delegate"
            assert accessSecondary.get("isCPNINotification") == "false"
        }
        if (expectedCtypes.contains("CTN_CHANGED_ON_ACCESSID")) {
            Map<String, Object> ctnChanged = result.find { it.get("cType") == "CTN_CHANGED_ON_ACCESSID" }
            assert ctnChanged.get("NotificationLevel") == "UserId"
            assert ctnChanged.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.contains("CTN_REMOVED_FROM_ACCESSID")) {
            Map<String, Object> ctnRemoved = result.find { it.get("cType") == "CTN_REMOVED_FROM_ACCESSID" }
            assert ctnRemoved.get("NotificationLevel") == "UserId"
            assert ctnRemoved.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.contains("DELETE_ACCOUNT")) {
            Map<String, Object> deleteAccount = result.find { it.get("cType") == "DELETE_ACCOUNT" }
            assert deleteAccount.get("NotificationLevel") == "Account"
            assert deleteAccount.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.contains("ONLINE_ACCOUNT_ADD2")) {
            Map<String, Object> onlineAccountAdd2 = result.find { it.get("cType") == "ONLINE_ACCOUNT_ADD2" }
            assert onlineAccountAdd2.get("NotificationLevel") == "Account"
            assert onlineAccountAdd2.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.contains("SLID_UPDATE")) {
            Map<String, Object> slidUpdate = result.find { it.get("cType") == "SLID_UPDATE" }
            assert slidUpdate.get("NotificationLevel") == "UserId"
            assert slidUpdate.get("isCPNINotification") == "false"
        }

        where:
        scenarioName                     | transactionName        | inputEvent                                                                                                                                           | expectedCtypes
        "AddServicesSync qarKey"         | "AddServicesSync"      | [transactionName: "AddServicesSync", services: [[serviceType: "TITAN"]], notificationData: [qarKey: "QAR"]]                                          | ["ONLINE_ACCOUNT_REG"]
        "AddServicesSync addCTN"         | "AddServicesSync"      | [transactionName: "AddServicesSync", services: [[serviceType: "TITAN"]], notificationData: [addCTN: "1"]]                                            | ["CTN_ADDED_TO_ACCESSID"]
        "AtlasProcessor titanInd"        | "AtlasProcessor"       | [transactionName: "AtlasProcessor", titanInd: "Y", notificationData: [AccessAccountViaTitan: "Y"]]                                                   | ["PRIN_USER_UPDATE"]
        "AddRole enabled"                | "AddRole"              | [transactionName: "AddRole", services: [[serviceType: "TITAN"]], notificationData: [secondaryAccountRoleEnabled: "Y"]]                               | ["ACCESS_GRANTED_PRIMARY", "ACCESS_GRANTED_SECONDARY"]
        "ChangeData mainCTN"             | "ChangeData"           | [transactionName: "ChangeData", services: [[serviceType: "TITAN"]], notificationData: [changeMainCTN: "1", oldMainCTN: "2"]]                         | ["CTN_CHANGED_ON_ACCESSID"]
        "DisconnectServices delete"      | "DisconnectServices"   | [transactionName: "DisconnectServices", services: [[serviceType: "TITAN"]], notificationData: [deleteMainCTN: "1"]]                                  | ["CTN_REMOVED_FROM_ACCESSID"]
        "ChangeStatus delete"            | "ChangeStatus"         | [transactionName: "ChangeStatus", services: [[serviceType: "TITAN"]], notificationData: [deleteAccount: "Y"]]                                        | ["DELETE_ACCOUNT"]
        "LinkInternetAccount linked"     | "LinkInternetAccount"  | [transactionName: "LinkInternetAccount", services: [[serviceType: "TITAN"]], notificationData: [primaryLSLinkedToSLID: "Y"]]                     | ["ONLINE_ACCOUNT_ADD2"]
        "AddAccount secAccess"           | "AddAccount"           | [transactionName: "AddAccount", services: [[serviceType: "TITAN"]], notificationData: [primaryAddAccount: "Y"]]                                 | ["ONLINE_ACCOUNT_ADD2"]
        "ChangeSLID titanInd"            | "ChangeSLID"           | [transactionName: "ChangeSLID", services: [[serviceType: "TITAN"]], notificationData: [titanInd: "Y"]]                                               | ["SLID_UPDATE"]
        "GenerateSecurityCode APPTSCHED" | "GenerateSecurityCode" | [transactionName: "GenerateSecurityCode", services: [[serviceType: "TITAN"]], identificationType: "APPTSCHED"]                                       | ["APPT_VERIFICATION_CODE", "ORC"]
        "default fallback"               | "Unknown"              | [transactionName: "Unknown", services: [[serviceType: "TITAN"]]]                                                                                     | ["UNKNOWN"]
    }

    @Unroll
    def "should handle edge cases for #scenarioName"() {
        given: "Edge case event map"
        Map<String, Object> event = inputEvent

        when: "generateCtype is called"
        List<Map<String, Object>> result = CTypeHelper.generateCtype(event)

        then: "Result contains expected cType(s)"
        result != null
        result*.get("cType") == expectedCtypes

        where:
        scenarioName               | inputEvent                                                                                            | expectedCtypes
        "notificationData not Map" | [transactionName: "AddServicesSync", services: [[serviceType: "TITAN"]], notificationData: "notAMap"] | ["UNKNOWN"]
        "services not List"        | [transactionName: "AddServicesSync", services: "notAList"]                                            | ["UNKNOWN"]
        "notificationData empty"   | [transactionName: "AddServicesSync", services: [[serviceType: "TITAN"]], notificationData: []]        | ["UNKNOWN"]
        "null notificationDataObj" | [transactionName: "AddServicesSync", services: [[serviceType: "TITAN"]]]                              | ["UNKNOWN"]
    }

    @Unroll
    def "should add PRIN_USER_UPDATE cType for AddServicesSync and AtlasProcessor when accessAccountViaTitan and titanInd are Y for #scenarioName"() {
        given: "An event map with AddServicesSync or AtlasProcessor and both accessAccountViaTitan and titanInd as Y"
        Map<String, Object> event = [
                transactionName : transactionName,
                services        : [[serviceType: "TITAN"]],
                titanInd        : titanInd,
                notificationData: [qarKey: qarKey, titanInd: titanInd, AccessAccountViaTitan: accessAccountViaTitan, slidTitanized: slidTitanized]
        ]

        when: "generateCtype is called"
        List<Map<String, Object>> result = CTypeHelper.generateCtype(event)

        then: "Result contains expected cType(s)"
        result*.get("cType") == expectedCtypes

        where:
        scenarioName                   | transactionName   | qarKey | titanInd | accessAccountViaTitan | slidTitanized | expectedCtypes
        "AtlasProcessor qarKey"        | "AtlasProcessor"  | "QAR"  | null     | null                  | null          | ["ONLINE_ACCOUNT_REG"]
    }

    @Unroll
    def "should generate correct cType for UpdateAccount notificationData scenarios for #scenarioName"() {
        given: "An event map for UpdateAccount with various notificationData combinations"
        Map<String, Object> event = [
                transactionName : "UpdateMember",
                services        : [[serviceType: serviceType]],
                notificationData: notificationData,
                subEvent        : subEvent,
                sorInvariantId  : sorInvariantId,
                sorId           : sorId,
                slid              : "1234567890"
        ]

        when: "generateCtype is called"
        List<Map<String, Object>> result = CTypeHelper.generateCtype(event)

        then: "Result contains expected cType(s) and attributes"
        result*.get("cType") == expectedCtypes

        if (expectedCtypes.contains("LVLONE_ACCESSID_LOCK")) {
            Map<String, Object> lvlOneLock = result.find { it.get("cType") == "LVLONE_ACCESSID_LOCK" }
            assert lvlOneLock.get("NotificationLevel") == "UserId"
            assert lvlOneLock.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.contains("LVLTWO_ACCESSID_LOCK")) {
            Map<String, Object> lvlTwoLock = result.find { it.get("cType") == "LVLTWO_ACCESSID_LOCK" }
            assert lvlTwoLock.get("NotificationLevel") == "UserId"
            assert lvlTwoLock.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.contains("PROFILE_UPDATE")) {
            Map<String, Object> profileUpdate = result.find { it.get("cType") == "PROFILE_UPDATE" }
            assert profileUpdate.get("NotificationLevel") == "Account"
            assert profileUpdate.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.contains("HS_CBR_CHANGE")) {
            Map<String, Object> cbrChange = result.find { it.get("cType") == "HS_CBR_CHANGE" }
            assert cbrChange.get("NotificationLevel") == "UserId"
            assert cbrChange.get("isCPNINotification") == "false"
        }
        if (expectedCtypes.contains("WIRELINE_HS_CBR_UPDATE")) {
            Map<String, Object> wirelineUpdate = result.find { it.get("cType") == "WIRELINE_HS_CBR_UPDATE" }
            assert wirelineUpdate != null
        }

        where: "Different notificationData and event scenarios"
        scenarioName                        | serviceType | notificationData                                                                 | subEvent | sorInvariantId | sorId | expectedCtypes
      //  "level one lock"                    | "TITAN"     | [userLockLevel: "1"]                                                             | null     | null           | null  | ["LVLONE_ACCESSID_LOCK"]
  //      "level two lock"                    | "TITAN"     | [userLockLevel: "2"]                                                             | null     | null           | null  | ["LVLTWO_ACCESSID_LOCK"]
        "profile update with linkedToSlid and contactEmail" | "TITAN" | [linkedToSlid: "Y", contactEmail: "test@test.com"]                         | null     | null           | null  | ["PROFILE_UPDATE"]
        "profile update with linkedToSlid and securityQuestion" | "TITAN" | [linkedToSlid: "Y", securityQuestion: "What?"]                           | null     | null           | null  | ["PROFILE_UPDATE"]
        "profile update with linkedToSlid and passcode" | "TITAN" | [linkedToSlid: "Y", passcode: "123456"]                                      | null     | null           | null  | ["PROFILE_UPDATE"]
        "HS_CBR_CHANGE update"              | "TITAN"     | [serviceNotificationType: "HS_WIRELESS_CBR", serviceNotification: "update"]      | null     | null           | null  | ["HS_CBR_CHANGE"]
        "HS_CBR_CHANGE delete"              | "TITAN"     | [serviceNotificationType: "HS_WIRELESS_CBR", serviceNotification: "delete"]      | null     | null           | null  | ["HS_CBR_CHANGE"]
        "PhoneUpdateDetailsChanged in UpdateMember returns UNKNOWN" | "TITAN" | [PhoneUpdateDetailsChanged: "Y"]                                       | "ECOMM"  | null           | null  | ["UNKNOWN"]
       // "fraud lock"                        | "TITAN"     | [accountFraudLocked: "Y"]                                                        | null     | "1"            | "2"   | ["ACCOUNT_LOCK"]
    }
    @Unroll
    def "should generate correct cType for AddAccount, ChangeMemberPassword, UpdateMember, ResetMemberPassword, MergeSLIDProfile for #scenarioName"() {
        given: "An event map for #scenarioName"
        Map<String, Object> event = inputEvent

        when: "generateCtype is called"
        List<Map<String, Object>> result = CTypeHelper.generateCtype(event)

        then: "Result contains expected cType(s) and attributes"
        result*.get("cType") == expectedCtypes
        if (expectedCtypes.contains("SEC_REQ_APPROVE_TO_PRIN")) {
            Map<String, Object> prinApprove = result.find { it.get("cType") == "SEC_REQ_APPROVE_TO_PRIN" }
            assert prinApprove.get("NotificationLevel") == "UserId"
            assert prinApprove.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.contains("SEC_REQ_APPROVE_TO_SEC")) {
            Map<String, Object> secApprove = result.find { it.get("cType") == "SEC_REQ_APPROVE_TO_SEC" }
            assert secApprove.get("NotificationLevel") == "Delegate"
            assert secApprove.get("isCPNINotification") == "false"
        }
        if (expectedCtypes.contains("ONLINE_ACCOUNT_REG")) {
            Map<String, Object> secApprove = result.find { it.get("cType") == "ONLINE_ACCOUNT_REG" }
            assert secApprove.get("NotificationLevel") == "Account"
            assert secApprove.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.contains("HS_CBR_CONFIRM")) {
            Map<String, Object> cbrConfirm = result.find { it.get("cType") == "HS_CBR_CONFIRM" }
            assert cbrConfirm != null
        }
        if (expectedCtypes.contains("ONLINE_ACCOUNT_ADD_SEC")) {
            Map<String, Object> onlineAccountAddSec = result.find { it.get("cType") == "ONLINE_ACCOUNT_ADD_SEC" }
            assert onlineAccountAddSec.get("NotificationLevel") == "UserId"
            assert onlineAccountAddSec.get("isCPNINotification") == "false"
        }
        if (expectedCtypes.contains("WIRELINE_HS_CBR_UPDATE")) {
            Map<String, Object> wirelineUpdate = result.find { it.get("cType") == "WIRELINE_HS_CBR_UPDATE" }
            assert wirelineUpdate != null
        }
        if (expectedCtypes.contains("ONLINE_SQA_UPDATE")) {
            Map<String, Object> sqaUpdate = result.find { it.get("cType") == "ONLINE_SQA_UPDATE" }
            assert sqaUpdate.get("NotificationLevel") == "UserId"
            assert sqaUpdate.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.contains("PROFILE_UPDATE")) {
            Map<String, Object> profileUpdate = result.find { it.get("cType") == "PROFILE_UPDATE" }
            assert profileUpdate.get("NotificationLevel") == "Account"
            assert profileUpdate.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.contains("UPDATE_CONTACT_EMAIL")) {
            Map<String, Object> contactEmailUpdate = result.find { it.get("cType") == "UPDATE_CONTACT_EMAIL" }
            assert contactEmailUpdate.get("NotificationLevel") == "UserId"
            assert contactEmailUpdate.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.count { it == "UPDATE_ONLINE_PASSWD" } > 0) {
            List<Map<String, Object>> passwdUpdates = result.findAll { it.get("cType") == "UPDATE_ONLINE_PASSWD" }
            assert passwdUpdates.size() >= 1
        }
        if (expectedCtypes.contains("ONLINE_TEMP_PASSWD")) {
            Map<String, Object> tempPasswd = result.find { it.get("cType") == "ONLINE_TEMP_PASSWD" }
            assert tempPasswd != null
        }
        if (expectedCtypes.contains("MERGE_ACCOUNT_NOTIFY1")) {
            Map<String, Object> mergeAccount = result.find { it.get("cType") == "MERGE_ACCOUNT_NOTIFY1" }
            assert mergeAccount.get("NotificationLevel") == expectedMergeNotificationLevel
            assert mergeAccount.get("isCPNINotification") == expectedMergeIsCPNI
        }

        where: "Different event scenarios"
        scenarioName | inputEvent | expectedCtypes | expectedMergeNotificationLevel | expectedMergeIsCPNI
        "ONLINE_SQA_UPDATE" | [transactionName: "ChangeMemberPassword", services: [[serviceType: "TITAN"]], subEvent: "ECOMM", securityAnswerChanged: "Y", callingSystemId: "MYWORLD"] | ["ONLINE_TEMP_PASSWD","UPDATE_ONLINE_PASSWD"] | null | null
        "PROFILE_UPDATE" | [transactionName: "UpdateMember", services: [[serviceType: "TITAN"]], linkedToSlid: "Y"] | ["UNKNOWN"] | null | null
        "UPDATE_CONTACT_EMAIL" | [transactionName: "UpdateMember", services: [[serviceType: "TITAN"]], userContactEmailChanged: "Y"] | ["UNKNOWN"] | null | null
        "ONLINE_TEMP_PASSWD" | [transactionName: "ResetMemberPassword", services: [[serviceType: "TITAN"]], clearPassword: "abc", deliveryMethodType: "email", subEvent: "SLID"] | ["ONLINE_TEMP_PASSWD", "UPDATE_ONLINE_PASSWD"] | null | null
        "MERGE_ACCOUNT_NOTIFY1 Account" | [transactionName: "MergeSLIDProfile", services: [[serviceType: "TITAN"]], notificationData: [isCPNINotificationLinkedToSLID: "Y"]] | ["MERGE_ACCOUNT_NOTIFY1"] | "Account" | "true"
        "MERGE_ACCOUNT_NOTIFY1 User" | [transactionName: "MergeSLIDProfile", services: [[serviceType: "TITAN"]], notificationData: [isCPNINotificationLinkedToSLID: "N"]] | ["MERGE_ACCOUNT_NOTIFY1"] | "UserId" | "false"
        "AddAccount ONLINE_ACCOUNT_REG" | [transactionName: "AddAccount", services: [[serviceType: "TITAN"]], notificationData: [qarKey: "QAR123"]] | ["ONLINE_ACCOUNT_REG"] | null | null
        "AddAccount ONLINE_ACCOUNT_ADD_SEC" | [transactionName: "AddAccount", services: [[serviceType: "TITAN"]], notificationData: [secondaryAccessGranted: "Y"]] | ["ONLINE_ACCOUNT_ADD2", "ONLINE_ACCOUNT_ADD_SEC"] | null | null
        "AddAccount HS_CBR_CONFIRM" | [transactionName: "AddAccount", services: [[serviceType: "TITAN"]], AccountId: "ACC123", notificationData: [EncryptedKey: "enc123", CPNIEligibleMobileNumber: "5551234567"]] | ["HS_CBR_CONFIRM"] | null | null
        "AddAccount WIRELINE_HS_CBR_UPDATE" | [transactionName: "AddAccount", services: [[serviceType: "TITAN"]], subEvent: "ECOMM", notificationData: [PhoneUpdateDetailsChanged: "Y"]] | ["WIRELINE_HS_CBR_UPDATE"] | null | null
    }

    @Unroll
    def "should generate correct cType for ChangeSLID, LSReg, CreateEmailAppPassword, DeleteEmailAppPassword, ChangeAccountOwner, UpdateRole for #scenarioName"() {
        given: "An event map for #scenarioName"
        Map<String, Object> event = inputEvent

        when: "generateCtype is called"
        List<Map<String, Object>> result = CTypeHelper.generateCtype(event)

        then: "Result contains expected cType(s) and attributes"
        result*.get("cType") == expectedCtypes
        if (expectedCtypes.contains("PM_ACCT_CREATION")) {
            Map<String, Object> pmAcctCreation = result.find { it.get("cType") == "PM_ACCT_CREATION" }
            assert pmAcctCreation.get("NotificationLevel") == expectedNotificationLevel
            assert pmAcctCreation.get("isCPNINotification") == expectedIsCPNI
        }
        if (expectedCtypes.contains("PROFILE_UPDATE_SECURE_KEY")) {
            Map<String, Object> profileUpdateSecureKey = result.find { it.get("cType") == "PROFILE_UPDATE_SECURE_KEY" }
            assert profileUpdateSecureKey != null
        }
        if (expectedCtypes.contains("SWAP_OWNERSHIP")) {
            Map<String, Object> swapOwnership = result.find { it.get("cType") == "SWAP_OWNERSHIP" }
            assert swapOwnership.get("NotificationLevel") == "Account"
            assert swapOwnership.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.contains("PRIN_USER_UPDATE")) {
            Map<String, Object> prinUserUpdate = result.find { it.get("cType") == "PRIN_USER_UPDATE" }
            assert prinUserUpdate.get("NotificationLevel") == "UserId"
            assert prinUserUpdate.get("isCPNINotification") == "false"
        }
        if (expectedCtypes.contains("SEC_REQ_APPROVE_TO_PRIN")) {
            Map<String, Object> secReqApproveToPrin = result.find { it.get("cType") == "SEC_REQ_APPROVE_TO_PRIN" }
            assert secReqApproveToPrin.get("NotificationLevel") == "UserId"
            assert secReqApproveToPrin.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.contains("SEC_REQ_APPROVE_TO_SEC")) {
            Map<String, Object> secReqApproveToSec = result.find { it.get("cType") == "SEC_REQ_APPROVE_TO_SEC" }
            assert secReqApproveToSec.get("NotificationLevel") == "Delegate"
            assert secReqApproveToSec.get("isCPNINotification") == "false"
        }

        where: "Different event scenarios"
        scenarioName                | inputEvent                                                                                                         | expectedCtypes                                 | expectedNotificationLevel | expectedIsCPNI
        "ChangeSLID titanInd Y"     | [transactionName: "ChangeSLID", services: [[serviceType: "TITAN"]], notificationData: [titanInd: "Y"]]            | ["SLID_UPDATE"]            | "Account"                | "true"
        "LSReg titanInd Y"          | [transactionName: "LSReg", services: [[serviceType: "TITAN"]], notificationData: [titanInd: "Y"]]                 | ["UNKNOWN"]                           | "Account"                | "true"
        "CreateEmailAppPassword"    | [transactionName: "CreateEmailAppPassword", services: [[serviceType: "TITAN"]], notificationData: [valueEmail: "abc@att.com"]] | ["PROFILE_UPDATE_SECURE_KEY"]                  | null                     | null
        "DeleteEmailAppPassword"    | [transactionName: "DeleteEmailAppPassword", services: [[serviceType: "TITAN"]], notificationData: [valueEmail: "abc@att.com"]] | ["PROFILE_UPDATE_SECURE_KEY"]                  | null                     | null
        "ChangeAccountOwner TITAN"  | [transactionName: "ChangeAccountOwner", services: [[serviceType: "TITAN"]]]                                      | ["PRIN_USER_UPDATE"]                           | null                     | null
        "ChangeAccountOwner MOBILITY" | [transactionName: "ChangeAccountOwner", services: [[serviceType: "MOBILITY"]]]                                 | ["SWAP_OWNERSHIP"]                             | "Account"                | "true"
        "ChangeAccountOwner ECOMM"  | [transactionName: "ChangeAccountOwner", services: [[serviceType: "ECOMM"]]]                                      | ["SWAP_OWNERSHIP"]                             | "Account"                | "true"
        "UpdateRole secondaryAcceptsOffer" | [transactionName: "UpdateRole", services: [[serviceType: "TITAN"]], notificationData: [secondaryAcceptsOffer: "Y"]] | ["SEC_REQ_APPROVE_TO_PRIN", "SEC_REQ_APPROVE_TO_SEC"] | null                     | null
        "UpdateRole primaryApprovesAccess" | [transactionName: "UpdateRole", services: [[serviceType: "TITAN"]], notificationData: [primaryApprovesAccess: "Y"]] | ["SEC_REQ_APPROVE_TO_PRIN", "SEC_REQ_APPROVE_TO_SEC"] | null                     | null
    }
    @Unroll
    def "should generate correct cType for GenerateSecurityCode scenarios for #scenarioName"() {
        given: "An event map for #scenarioName"
        Map<String, Object> event = inputEvent

        when: "generateCtype is called"
        List<Map<String, Object>> result = CTypeHelper.generateCtype(event)

        then: "Result contains expected cType(s)"
        result*.get("cType") == expectedCtypes

        and: "All result maps are non-null and contain expected cType"
        result.each { Map<String, Object> res ->
            assert res != null
            assert ((String) res.get("cType")) in expectedCtypes
        }

        where: "Different GenerateSecurityCode scenarios"
        scenarioName                | inputEvent                                                                                                         | expectedCtypes
        "APPTSCHED"                 | [transactionName: "GenerateSecurityCode", identificationType: "APPTSCHED", services: [[serviceType: "TITAN"]]]     | ["APPT_VERIFICATION_CODE","ORC"]
        "SLIDREG"                   | [transactionName: "GenerateSecurityCode", identificationType: "SLIDREG", services: [[serviceType: "TITAN"]]]       | ["HS_OPR_CBR_CONFIRM_WEB","ORC"]
        "OPR"                       | [transactionName: "GenerateSecurityCode", identificationType: "OPR", services: [[serviceType: "TITAN"]]]           | ["HS_OPR_CBR_CONFIRM_WEB","ORC"]
        "EDDORCACS"                 | [transactionName: "GenerateSecurityCode", identificationType: "EDDORCACS", services: [[serviceType: "TITAN"]]]     | ["SECURITY_CODE","ORC"]
        "EMAILOTP"                  | [transactionName: "GenerateSecurityCode", identificationType: "EMAILOTP", services: [[serviceType: "TITAN"]]]      | ["EMAIL_VERIFICATION","ORC"]
        "CRICKETOTP"                | [transactionName: "GenerateSecurityCode", identificationType: "CRICKETOTP", services: [[serviceType: "TITAN"]]]    | ["EMAIL_VERIFICATION_CRKT","ORC"]
        "EMAILPIN"                  | [transactionName: "GenerateSecurityCode", identificationType: "EMAILPIN", services: [[serviceType: "TITAN"]]]      | ["EMAIL_VERIFICATION_PIN","ORC"]
        "ENCPIN"                    | [transactionName: "GenerateSecurityCode", identificationType: "ENCPIN", services: [[serviceType: "TITAN"]]]        | ["NOTIFY_ME","ORC"]
        "NONATTCTN"                 | [transactionName: "GenerateSecurityCode", identificationType: "NONATTCTN", services: [[serviceType: "TITAN"]]]     | ["ONE_TIME_PIN","ORC"]
        "ATTCTN"                    | [transactionName: "GenerateSecurityCode", identificationType: "ATTCTN", services: [[serviceType: "TITAN"]]]        | ["ONE_TIME_PIN","ORC"]
        "BANPC"                     | [transactionName: "GenerateSecurityCode", identificationType: "BANPC", services: [[serviceType: "TITAN"]]]         | ["TEMP_PIN","ORC"]
        "IDSEMOB"                   | [transactionName: "GenerateSecurityCode", identificationType: "IDSEMOB", services: [[serviceType: "TITAN"]]]       | ["TEMP_PIN_ONLINE","ORC"]
        "BANPTONL"                  | [transactionName: "GenerateSecurityCode", identificationType: "BANPTONL", services: [[serviceType: "TITAN"]]]      | ["TEMP_PIN_ONLINE","ORC"]
        "AUTHUSER"                  | [transactionName: "GenerateSecurityCode", identificationType: "AUTHUSER", services: [[serviceType: "TITAN"]]]      | ["TEMP_PIN_ONLINE_AU","ORC"]
        "CTNSEC"                    | [transactionName: "GenerateSecurityCode", identificationType: "CTNSEC", services: [[serviceType: "TITAN"]]]        | ["ORC_SEC","ORC"]
        "ECOMMSEC"                  | [transactionName: "GenerateSecurityCode", identificationType: "ECOMMSEC", services: [[serviceType: "TITAN"]]]      | ["ORC_SEC","ORC"]
        "TIATANSEC"                 | [transactionName: "GenerateSecurityCode", identificationType: "TIATANSEC", services: [[serviceType: "TITAN"]]]     | ["ORC_SEC","ORC"]
        "WBANSEC"                   | [transactionName: "GenerateSecurityCode", identificationType: "WBANSEC", services: [[serviceType: "TITAN"]]]       | ["ORC_SEC","ORC"]
    }
    @Unroll
    def "should return UNKNOWN cType when event is null for #scenarioName"() {
        given: "A null event"
        Map<String, Object> event = null

        when: "generateCtype is called"
        List<Map<String, Object>> result = CTypeHelper.generateCtype(event)

        then: "Result contains UNKNOWN cType"
        result != null
        result.size() == 1
        result.get(0).get("cType") == "UNKNOWN"

        where:
        scenarioName | _
        "null event" | _
    }

    @Unroll
    def "should generate correct cType for UpdateMember scenarios for #scenarioName"() {
        given: "An event map for UpdateMember with various notificationData combinations"
        Map<String, Object> event = inputEvent

        when: "generateCtype is called"
        List<Map<String, Object>> result = CTypeHelper.generateCtype(event)

        then: "Result contains expected cType(s) and attributes"
        result*.get("cType") == expectedCtypes
        if (expectedCtypes.contains("PROFILE_UPDATE")) {
            result.find { it.get("cType") == "PROFILE_UPDATE" }.get("NotificationLevel") == "Account"
            result.find { it.get("cType") == "PROFILE_UPDATE" }.get("isCPNINotification") == "false"
        }
        if (expectedCtypes.contains("UPDATE_CONTACT_EMAIL")) {
            result.find { it.get("cType") == "UPDATE_CONTACT_EMAIL" }.get("NotificationLevel") == "UserId"
            result.find { it.get("cType") == "UPDATE_CONTACT_EMAIL" }.get("isCPNINotification") == "true"
        }

        where: "Different UpdateMember scenarios"
        scenarioName                  | inputEvent                                                                                                         | expectedCtypes
        "linkedToSlid Y"              | [transactionName: "UpdateMember", services: [[serviceType: "TITAN"]], notificationData: [linkedToSlid: "Y"]]       | ["UNKNOWN"]
        "linkedToSlid null, email changed" | [transactionName: "UpdateMember", services: [[serviceType: "TITAN"]], notificationData: [userContactEmailChanged: "Y"]] | ["UPDATE_CONTACT_EMAIL"]
        "linkedToSlid null, no email change" | [transactionName: "UpdateMember", services: [[serviceType: "TITAN"]], notificationData: [:]]                | ["UNKNOWN"]
    }

    @Unroll
    def "should generate correct cType for ChangeSLID and LSReg titanInd Y for #scenarioName"() {
        given: "An event map for #scenarioName"
        Map<String, Object> event = [
                transactionName: transactionName,
                services: [[serviceType: "TITAN"]],
                titanInd: "Y",
                notificationData: [titanInd: "Y"]
        ]

        when: "generateCtype is called"
        List<Map<String, Object>> result = CTypeHelper.generateCtype(event)

        then: "Result contains expected cType(s) and attributes"
        result != null
        result*.get("cType").containsAll(expectedCtypes)
        result.find { it.get("cType") == "PM_ACCT_CREATION" }.get("NotificationLevel") == "Account"
        result.find { it.get("cType") == "PM_ACCT_CREATION" }.get("isCPNINotification") == "true"

        where: "Different scenarios for ChangeSLID and LSReg"
        scenarioName      | transactionName   | expectedCtypes
        "LSReg Y"         | "LSReg"           | ["PM_ACCT_CREATION"]
    }

    @Unroll
    def "should extract accountFraudLocked and userLockLevel for #scenarioName"() {
        given: "An event map with possible accountFraudLocked and userLockLevel"
        Map<String, Object> event = inputEvent

        when: "accountFraudLocked and userLockLevel are extracted"
        String accountFraudLocked = event.get("accountFraudLocked") instanceof String ? (String) event.get("accountFraudLocked") : null
        String userLockLevel = event.get("userLockLevel") instanceof String ? (String) event.get("userLockLevel") : null

        then: "Extracted values match expected"
        accountFraudLocked == expectedAccountFraudLocked
        userLockLevel == expectedUserLockLevel

        where: "Different scenarios for extraction"
        scenarioName                | inputEvent                                                      | expectedAccountFraudLocked | expectedUserLockLevel
        "both present as String"    | [accountFraudLocked: "Y", userLockLevel: "2"]                   | "Y"                       | "2"
        "accountFraudLocked int"    | [accountFraudLocked: 1, userLockLevel: "1"]                     | null                      | "1"
        "userLockLevel int"         | [accountFraudLocked: "N", userLockLevel: 2]                     | "N"                       | null
        "both missing"              | [:]                                                             | null                      | null
        "both null"                 | [accountFraudLocked: null, userLockLevel: null]                 | null                      | null
        "accountFraudLocked only"   | [accountFraudLocked: "Y"]                                       | "Y"                       | null
        "userLockLevel only"        | [userLockLevel: "1"]                                            | null                      | "1"

    }

    @Unroll
    def "should handle userLockLevel and slid for #scenarioName"() {
        given: "An event map with userLockLevel and slid"
        Map<String, Object> event = [
                transactionName: "UpdateMember",
                services: [[serviceType: "TITAN"]],
                userLockLevel: userLockLevel,
                slid: slid
        ]
        if (accountFraudLocked != null) {
            event.accountFraudLocked = accountFraudLocked
        }

        when: "generateCtype is called"
        List<Map<String, Object>> result = CTypeHelper.generateCtype(event)

        then: "Result contains expected cType(s) and attributes"
        result*.get("cType") == expectedCtypes
        if (expectedCtypes.contains("ACCESSID_FRAUD_UNLOCK")) {
            Map<String, Object> unlock = result.find { it.get("cType") == "ACCESSID_FRAUD_UNLOCK" }
            unlock.get("NotificationLevel") == "UserId"
            unlock.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.contains("LVLONE_ACCESSID_LOCK")) {
            Map<String, Object> lock1 = result.find { it.get("cType") == "LVLONE_ACCESSID_LOCK" }
            lock1.get("NotificationLevel") == "UserId"
            lock1.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.contains("LVLTWO_ACCESSID_LOCK")) {
            Map<String, Object> lock2 = result.find { it.get("cType") == "LVLTWO_ACCESSID_LOCK" }
            lock2.get("NotificationLevel") == "UserId"
            lock2.get("isCPNINotification") == "true"
        }

        where: "Different userLockLevel and slid scenarios"
        scenarioName                | userLockLevel | slid     | accountFraudLocked | expectedCtypes
        "fraud unlock"              | "0"           | null     | null               | ["ACCESSID_FRAUD_UNLOCK"]
        "level one lock with slid"  | "1"           | "SLID1"  | null               | ["LVLONE_ACCESSID_LOCK"]
        "level two lock"            | "2"           | null     | null               | ["LVLTWO_ACCESSID_LOCK"]
    }

    @Unroll
    def "should generate correct cType for UpdateAccount transaction for #scenarioName"() {
        given: "An event map for UpdateAccount with various combinations"
        Map<String, Object> event = inputEvent

        when: "generateCtype is called"
        List<Map<String, Object>> result = CTypeHelper.generateCtype(event)

        then: "No unexpected mock interactions"
        0 * _

        and: "Result contains expected cType(s) and attributes"
        result != null
        result*.get("cType") == expectedCtypes
        if (expectedCtypes.contains("EML_ADDR_VALIDATION")) {
            Map<String, Object> emailValidation = result.find { it.get("cType") == "EML_ADDR_VALIDATION" }
            assert emailValidation != null
            assert emailValidation.get("NotificationLevel") == "Account"
            assert emailValidation.get("isCPNINotification") == "false"
        }
        if (expectedCtypes.contains("WIRELINE_HS_CBR_UPDATE")) {
            Map<String, Object> wirelineUpdate = result.find { it.get("cType") == "WIRELINE_HS_CBR_UPDATE" }
            assert wirelineUpdate != null
            assert wirelineUpdate.get("NotificationLevel") == "Account"
            assert wirelineUpdate.get("isCPNINotification") == "false"
        }
        if (expectedCtypes.contains("HS_CBR_CONFIRM")) {
            Map<String, Object> cbrConfirm = result.find { it.get("cType") == "HS_CBR_CONFIRM" }
            assert cbrConfirm != null
            assert cbrConfirm.get("NotificationLevel") == "Account"
            assert cbrConfirm.get("isCPNINotification") == "false"
        }

        where: "Different UpdateAccount scenarios"
        scenarioName                                          | inputEvent                                                                                                                                                                                                         | expectedCtypes
        "EML_ADDR_VALIDATION for TITAN"                      | [transactionName: "UpdateAccount", AccountType: "TITAN", subEvent: "SLID", AccountId: "ACC123", notificationData: [EncryptedKey: "key123", memberContactEmail: "test@example.com"]]                              | ["EML_ADDR_VALIDATION"]
        "EML_ADDR_VALIDATION for MOBILITY"                   | [transactionName: "UpdateAccount", AccountType: "MOBILITY", subEvent: "SLID", AccountId: "ACC456", notificationData: [EncryptedKey: "key456", memberContactEmail: "user@example.com"]]                           | ["EML_ADDR_VALIDATION"]
        "WIRELINE_HS_CBR_UPDATE with ECOMM subEvent"         | [transactionName: "UpdateAccount", subEvent: "ECOMM", notificationData: [PhoneUpdateDetailsChanged: "Y"]]                                                                                                         | ["WIRELINE_HS_CBR_UPDATE"]
        "HS_CBR_CONFIRM with all required fields"            | [transactionName: "UpdateAccount", AccountId: "ACC789", notificationData: [EncryptedKey: "key789", CPNIEligibleMobileNumber: "1234567890"]]                                                                      | ["HS_CBR_CONFIRM"]
        "WIRELINE_HS_CBR_UPDATE and HS_CBR_CONFIRM combined" | [transactionName: "UpdateAccount", AccountId: "ACC999", subEvent: "ECOMM", notificationData: [PhoneUpdateDetailsChanged: "Y", EncryptedKey: "key999", CPNIEligibleMobileNumber: "9876543210"]]                   | ["HS_CBR_CONFIRM", "WIRELINE_HS_CBR_UPDATE"]
        "EML_ADDR_VALIDATION and HS_CBR_CONFIRM combined"    | [transactionName: "UpdateAccount", AccountType: "TITAN", subEvent: "SLID", AccountId: "ACC111", notificationData: [EncryptedKey: "key111", memberContactEmail: "combined@example.com", CPNIEligibleMobileNumber: "1111111111"]] | ["EML_ADDR_VALIDATION", "HS_CBR_CONFIRM"]
        "No matching conditions"                             | [transactionName: "UpdateAccount", AccountType: "WIRELESS", notificationData: [:]]                                                                                                                                 | ["UNKNOWN"]
        "Missing notificationData"                           | [transactionName: "UpdateAccount", AccountType: "TITAN", subEvent: "SLID", AccountId: "ACC333"]                                                                                                                   | ["UNKNOWN"]
        "Partial WIRELINE_HS_CBR_UPDATE missing PhoneUpdateDetailsChanged" | [transactionName: "UpdateAccount", subEvent: "ECOMM", notificationData: [otherField: "value"]]                                                                                                      | ["UNKNOWN"]
        "Partial HS_CBR_CONFIRM missing CPNIEligibleMobileNumber" | [transactionName: "UpdateAccount", AccountId: "ACC444", notificationData: [EncryptedKey: "key444"]]                                                                                                       | ["UNKNOWN"]
    }

    @Unroll
    def "should generate correct cType for DisconnectServices/RemoveServicesGeneric/RemoveAccount for #scenarioName"() {
        given: "An event map for #scenarioName"
        Map<String, Object> event = inputEvent

        when: "generateCtype is called"
        List<Map<String, Object>> result = CTypeHelper.generateCtype(event)

        then: "No unexpected mock interactions"
        0 * _

        and: "Result contains expected cType(s)"
        result != null
        result*.get("cType") == expectedCtypes

        and: "NotificationLevel and isCPNINotification attributes are correct"
        if (expectedCtypes.contains("CTN_REMOVED_FROM_ACCESSID")) {
            Map<String, Object> ctnRemoved = result.find { it.get("cType") == "CTN_REMOVED_FROM_ACCESSID" }
            assert ctnRemoved != null
            assert ctnRemoved.get("NotificationLevel") == "UserId"
            assert ctnRemoved.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.contains("DELETE_ACCOUNT")) {
            Map<String, Object> deleteAcct = result.find { it.get("cType") == "DELETE_ACCOUNT" }
            assert deleteAcct != null
            assert deleteAcct.get("NotificationLevel") == "Account"
            assert deleteAcct.get("isCPNINotification") == "true"
        }
        if (expectedCtypes.contains("PROFILE_UPDATE")) {
            Map<String, Object> profileUpdate = result.find { it.get("cType") == "PROFILE_UPDATE" }
            assert profileUpdate != null
            assert profileUpdate.get("NotificationLevel") == "Account"
            assert profileUpdate.get("isCPNINotification") == "true"
        }

        where: "Different DisconnectServices/RemoveServicesGeneric/RemoveAccount scenarios"
        scenarioName                                                         | inputEvent                                                                                                                                                                     | expectedCtypes
        "DisconnectServices deleteMainCTN only"                              | [transactionName: "DisconnectServices", notificationData: [deleteMainCTN: "5551234567"]]                                                                                       | ["CTN_REMOVED_FROM_ACCESSID"]
        "DisconnectServices deleteAccount Y"                                 | [transactionName: "DisconnectServices", notificationData: [deleteAccount: "Y"]]                                                                                                | ["DELETE_ACCOUNT"]
        "DisconnectServices defaultAccountChanged Y returns UNKNOWN"          | [transactionName: "DisconnectServices", notificationData: [defaultAccountChanged: "Y"]]                                                                                        | ["UNKNOWN"]
        "DisconnectServices deleteMainCTN and deleteAccount Y"               | [transactionName: "DisconnectServices", notificationData: [deleteMainCTN: "5551234567", deleteAccount: "Y"]]                                                                   | ["CTN_REMOVED_FROM_ACCESSID", "DELETE_ACCOUNT"]
        "DisconnectServices deleteMainCTN and defaultAccountChanged Y"       | [transactionName: "DisconnectServices", notificationData: [deleteMainCTN: "5551234567", defaultAccountChanged: "Y"]]                                                           | ["CTN_REMOVED_FROM_ACCESSID"]
        "DisconnectServices deleteAccount Y and defaultAccountChanged Y"     | [transactionName: "DisconnectServices", notificationData: [deleteAccount: "Y", defaultAccountChanged: "Y"]]                                                                    | ["DELETE_ACCOUNT"]
        "DisconnectServices all three conditions"                            | [transactionName: "DisconnectServices", notificationData: [deleteMainCTN: "5551234567", deleteAccount: "Y", defaultAccountChanged: "Y"]]                                       | ["CTN_REMOVED_FROM_ACCESSID", "DELETE_ACCOUNT"]
        "DisconnectServices no matching conditions"                          | [transactionName: "DisconnectServices", notificationData: [:]]                                                                                                                 | ["UNKNOWN"]
        "DisconnectServices null notificationData"                           | [transactionName: "DisconnectServices"]                                                                                                                                        | ["UNKNOWN"]
        "RemoveServicesGeneric deleteMainCTN only"                           | [transactionName: "RemoveServicesGeneric", notificationData: [deleteMainCTN: "5559876543"]]                                                                                    | ["CTN_REMOVED_FROM_ACCESSID"]
        "RemoveServicesGeneric deleteAccount Y"                              | [transactionName: "RemoveServicesGeneric", notificationData: [deleteAccount: "Y"]]                                                                                             | ["DELETE_ACCOUNT"]
        "RemoveServicesGeneric defaultAccountChanged Y returns UNKNOWN"       | [transactionName: "RemoveServicesGeneric", notificationData: [defaultAccountChanged: "Y"]]                                                                                     | ["UNKNOWN"]
        "RemoveServicesGeneric all three conditions"                         | [transactionName: "RemoveServicesGeneric", notificationData: [deleteMainCTN: "5559876543", deleteAccount: "Y", defaultAccountChanged: "Y"]]                                    | ["CTN_REMOVED_FROM_ACCESSID", "DELETE_ACCOUNT"]
        "RemoveServicesGeneric no matching conditions"                       | [transactionName: "RemoveServicesGeneric", notificationData: [:]]                                                                                                              | ["UNKNOWN"]
        "RemoveAccount deleteMainCTN only"                                   | [transactionName: "RemoveAccount", notificationData: [deleteMainCTN: "5550001111"]]                                                                                            | ["CTN_REMOVED_FROM_ACCESSID"]
        "RemoveAccount deleteAccount Y"                                      | [transactionName: "RemoveAccount", notificationData: [deleteAccount: "Y"]]                                                                                                     | ["DELETE_ACCOUNT"]
        "RemoveAccount defaultAccountChanged Y returns UNKNOWN"               | [transactionName: "RemoveAccount", notificationData: [defaultAccountChanged: "Y"]]                                                                                             | ["UNKNOWN"]
        "RemoveAccount all three conditions"                                 | [transactionName: "RemoveAccount", notificationData: [deleteMainCTN: "5550001111", deleteAccount: "Y", defaultAccountChanged: "Y"]]                                            | ["CTN_REMOVED_FROM_ACCESSID", "DELETE_ACCOUNT"]
        "RemoveAccount no matching conditions"                               | [transactionName: "RemoveAccount", notificationData: [:]]                                                                                                                      | ["UNKNOWN"]
        "DisconnectServices deleteAccount N does not trigger DELETE_ACCOUNT"  | [transactionName: "DisconnectServices", notificationData: [deleteAccount: "N"]]                                                                                                | ["UNKNOWN"]
        "RemoveAccount defaultAccountChanged N does not trigger PROFILE_UPDATE" | [transactionName: "RemoveAccount", notificationData: [defaultAccountChanged: "N"]]                                                                                           | ["UNKNOWN"]
    }
}