package com.att.idp.idgraphconsumerms.kafka.dmctn.service

import com.att.idp.idgraphconsumerms.kafka.model.AccountNotificationEvent
import spock.lang.Specification
import spock.lang.Shared
import spock.lang.Unroll

/**
 * Spock specification for AccountServiceFactory achieving full branch coverage.
 */
class AccountServiceFactoryTest extends Specification {

    @Shared OrchestrationWirelessService orchestrationWirelessService = Mock(OrchestrationWirelessService)
    @Shared UpdateAccountNotificationService updateAccountNotificationService = Mock(UpdateAccountNotificationService)
    @Shared CloseAccountNotificationService closeAccountNotificationService = Mock(CloseAccountNotificationService)
    @Shared ProvisionEnablerNotificationService provisionEnablerNotificationService = Mock(ProvisionEnablerNotificationService)

    @Unroll
    def "should select correct BaseService for #scenarioName"() {
        given: "An AccountServiceFactory and an account notification event"
        AccountServiceFactory accountServiceFactory = new AccountServiceFactory(orchestrationWirelessService,
                updateAccountNotificationService, closeAccountNotificationService, provisionEnablerNotificationService)
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(eventType)
        event.setOldFan(oldFan)
        event.setNewFan(newFan)
        BaseService expectedService
        if(expectedServiceKey == 'ORCH') {
            expectedService = orchestrationWirelessService
        } else if(expectedServiceKey == 'UPDATE') {
            expectedService = updateAccountNotificationService
        } else if(expectedServiceKey == 'REMOVE') {
            expectedService = closeAccountNotificationService
        } else {
            expectedService = null
        }

        when: "getService is invoked"
        BaseService result = accountServiceFactory.getService(event)

        then: "Expected service instance (or null) is returned"
        result == expectedService
        0 * _ // no interactions with mocks during selection

        and: "Result matches expected mapping for scenario"
        if(expectedService == null) {
            assert result == null
        } else {
            assert result.is(expectedService)
        }

        where: "Different event type scenarios"
        scenarioName                     | eventType         | oldFan     | newFan     | expectedServiceKey
        "ActivateAccount"               | "ActivateAccount" | null       | null       | "ORCH"
        "activateaccount lower"         | "activateaccount" | null       | null       | "ORCH"
        "CloseAccount"                  | "CloseAccount"    | null       | null       | "REMOVE"
        "UpdateAccount with both fans"  | "UpdateAccount"   | "OLDFAN" | "NEWFAN" | "UPDATE"
        "UpdateAccount missing oldFan"  | "UpdateAccount"   | null       | "NEWFAN" | "NULL"
        "UpdateAccount missing newFan"  | "UpdateAccount"   | "OLDFAN" | null       | "NULL"
        "Unknown event"                 | "SomeOtherEvent"  | null       | null       | "NULL"
    }

    def "should route UpdateAccount with titanBan and no fans to provisionEnablerNotificationService"() {
        given:
        AccountServiceFactory accountServiceFactory = new AccountServiceFactory(orchestrationWirelessService,
                updateAccountNotificationService, closeAccountNotificationService, provisionEnablerNotificationService)
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName("UpdateAccount")
        event.setTitanBan("110086697")

        when:
        BaseService result = accountServiceFactory.getService(event)

        then:
        result == provisionEnablerNotificationService
        0 * _
    }

    def "should return null for UpdateAccount when titanBan absent and fans absent"() {
        given:
        AccountServiceFactory accountServiceFactory = new AccountServiceFactory(orchestrationWirelessService,
                updateAccountNotificationService, closeAccountNotificationService, provisionEnablerNotificationService)
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName("UpdateAccount")

        when:
        BaseService result = accountServiceFactory.getService(event)

        then:
        result == null
        0 * _
    }

    def "should throw NullPointerException for null eventType"() {
        given: "A new AccountServiceFactory and null event type"
        AccountServiceFactory accountServiceFactory = new AccountServiceFactory(orchestrationWirelessService,
                updateAccountNotificationService, closeAccountNotificationService, provisionEnablerNotificationService)
        AccountNotificationEvent event = new AccountNotificationEvent()
        event.setEventName(null)

        when: "getService is invoked with null"
        accountServiceFactory.getService(event)

        then: "NullPointerException is thrown and no other interactions happen"
        NullPointerException ex = thrown(NullPointerException)
        ex.message == null || ex.message.length() >= 0 // minimal verification
        0 * _
    }
}
