package com.att.idp.idgraphconsumerms.kafka.listener

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.kafka.dmctn.service.SubscriberChangeEventProcessor
import com.att.idp.idgraphconsumerms.kafka.dmctn.service.SubscriberCreateEventProcessor
import com.att.idp.idgraphconsumerms.kafka.model.CGSubscriberEvent
import com.att.idp.idgraphconsumerms.kafka.model.Event
import com.att.idp.idgraphconsumerms.kafka.model.Subscriber
import com.att.idp.idgraphconsumerms.request.validator.RequestValidator
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.kafka.support.Acknowledgment
import org.springframework.messaging.MessageHeaders
import spock.lang.Specification
import spock.lang.Unroll

class DmctnCGSubscriberEventProcessorSpec extends Specification {

    RequestValidator requestValidator
    SubscriberChangeEventProcessor subscriberChangeEventProcessor
    SubscriberCreateEventProcessor subscriberCreateEventProcessor
    DmctnCGSubscriberEventProcessor processor
    ObjectMapper objectMapper

    void setup() {
        requestValidator = Mock(RequestValidator)
        subscriberChangeEventProcessor = Mock(SubscriberChangeEventProcessor)
        subscriberCreateEventProcessor = Mock(SubscriberCreateEventProcessor)
        processor = new DmctnCGSubscriberEventProcessor(requestValidator, subscriberChangeEventProcessor, subscriberCreateEventProcessor)
        objectMapper = new ObjectMapper()
    }

    @Unroll
    def "should process #eventType event and acknowledge for #scenarioName"() {
        given: "A CGSubscriberEvent message, headers, and acknowledgment"
        Subscriber subscriber = new Subscriber()
        String subscriberJson = objectMapper.writeValueAsString(subscriber)
        Event event = new Event()
        event.setSubscriber(subscriberJson)
        CGSubscriberEvent cgEvent = new CGSubscriberEvent()
        cgEvent.setEventType(eventType)
        cgEvent.setEvent(event)
        String msg = objectMapper.writeValueAsString(cgEvent)
        MessageHeaders headers = Mock(MessageHeaders)
        Acknowledgment ack = Mock(Acknowledgment)

        if (eventType == ConsumerConstants.DmctnSubscriberChangeEvent.EVENT_TYPE_SUBSCRIBER_CHANGE) {
            headers.containsKey(ConsumerConstants.DmctnSubscriberChangeEvent.HEADER_KEY_CHANGETYPE) >> headerPresent
        }

        when: "processEvent is called"
        processor.processEvent(msg, headers, ack)

        then: "Correct processor is called and ack is acknowledged"
        if (eventType == ConsumerConstants.DmctnSubscriberChangeEvent.EVENT_TYPE_SUBSCRIBER_CHANGE) {
            if (!headerPresent) {
                1 * ack.acknowledge()
                0 * subscriberChangeEventProcessor._
                0 * subscriberCreateEventProcessor._
            } else {
                1 * subscriberChangeEventProcessor.processEvent(_ as Subscriber, headers)
                1 * ack.acknowledge()
                0 * subscriberCreateEventProcessor._
            }
        } else if (eventType == ConsumerConstants.DmctnSubscriberChangeEvent.EVENT_TYPE_SUBSCRIBER_CREATE) {
            1 * subscriberCreateEventProcessor.processEvent(_ as Subscriber, headers)
            1 * ack.acknowledge()
            0 * subscriberChangeEventProcessor._
        } else {
            1 * ack.acknowledge()
            0 * subscriberChangeEventProcessor._
            0 * subscriberCreateEventProcessor._
        }

        where:
        scenarioName                | eventType                                                      | headerPresent
        "subscriber change missing" | ConsumerConstants.DmctnSubscriberChangeEvent.EVENT_TYPE_SUBSCRIBER_CHANGE | false
        "subscriber change present" | ConsumerConstants.DmctnSubscriberChangeEvent.EVENT_TYPE_SUBSCRIBER_CHANGE | true
        "subscriber create"         | ConsumerConstants.DmctnSubscriberChangeEvent.EVENT_TYPE_SUBSCRIBER_CREATE | null
        "unsupported event"         | "UNSUPPORTED_EVENT"                                            | null
    }

    def "should throw JsonProcessingException for invalid message"() {
        given: "An invalid JSON message, headers, and acknowledgment"
        String msg = "{invalidJson:}"
        MessageHeaders headers = Mock(MessageHeaders)
        Acknowledgment ack = Mock(Acknowledgment)

        when: "processEvent is called"
        processor.processEvent(msg, headers, ack)

        then: "JsonProcessingException is thrown and no processor/ack call occurs"
        0 * subscriberChangeEventProcessor._
        0 * subscriberCreateEventProcessor._
        0 * ack._
        thrown(JsonProcessingException)
    }
}

