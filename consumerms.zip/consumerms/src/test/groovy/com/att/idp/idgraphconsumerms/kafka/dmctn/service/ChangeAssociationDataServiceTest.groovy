package com.att.idp.idgraphconsumerms.kafka.dmctn.service

import com.att.idp.idgraphconsumerms.constants.ConsumerConstants
import com.att.idp.idgraphconsumerms.cosmos.nosql.helpers.CosmosFailedEventsWriter
import com.att.idp.idgraphconsumerms.cosmos.nosql.model.FailedEventDetails
import com.att.idp.idgraphconsumerms.helpers.GddnFailedEventCircuitBreaker
import com.att.idp.idgraphconsumerms.kafka.model.Association
import com.att.idp.idgraphconsumerms.kafka.model.Subscriber
import com.att.idp.idgraphconsumerms.model.UserAssociationChangeRequest
import com.att.idp.idgraphconsumerms.oracle.helpers.MemberServiceDBHelper
import com.att.idp.idgraphconsumerms.oracle.helpers.MemberServiceDBHelperStub
import com.att.idp.idgraphconsumerms.oracle.model.MemberServiceResult
import com.att.idp.idgraphconsumerms.request.validator.RequestValidator
import com.att.idp.idgraphconsumerms.utils.FailedEventUtil
import com.att.idp.idgraphconsumerms.utils.JsonService
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.messaging.MessageHeaders
import spock.lang.Specification
import spock.lang.Unroll
import com.att.mpsys.common.utils.CErrorDefs

class ChangeAssociationDataServiceTest extends Specification {
    ApiRestClient apiRestClient = Mock()
    CosmosFailedEventsWriter cosmosFailedEventsWriter = Mock()
    GddnFailedEventCircuitBreaker gddnFailedEventCircuitBreaker = Mock()
    JdbcTemplate jdbcTemplate = Mock()

    MemberServiceDBHelperStub realStub = new MemberServiceDBHelperStub(jdbcTemplate)
    MemberServiceDBHelperStub stubSpy = Spy(realStub)
    ChangeAssociationDataService service

    String testAesKey = "16cd6d4581316cd7dfed29e087b10b145ddac92a62ed47ca2b4b60ea1b1f74fe"


    //        guidByCtn.put("5551112222", "G12345")
    //        guidByCtn.put("5553334444", "G98765") "sor-id-1",

    List<Map> failedEvents = []

    def setup() {
        service = new ChangeAssociationDataService(apiRestClient, stubSpy, cosmosFailedEventsWriter, gddnFailedEventCircuitBreaker)
        setField(service, "changeDataEndpoint", "/changeAssoc")
        setField(service, "aes256key", testAesKey)

        // Default success validator unless overridden
        overrideValidatorSuccess()
        overrideJson()
        overrideFailedEventCapture()
    }

    def cleanup() {
        restoreValidator()
        restoreFailedEvent()
        restoreJson()
        failedEvents.clear()
    }

    def "validation failure triggers failed event and aborts"() {
        given:
        overrideValidatorFailure("VAL_ERR", "bad subscriber id")
        Subscriber sub = buildSubscriber("15551230000", "")
        when:
        service.execute(sub, EventSource.CG)
        then:
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({
            assert it.errorDetails.toString().contains("VALIDATION_FAILED")
            true
        })

        0 * apiRestClient._
        0 * stubSpy.getOldPhoneNumberFromSubscriptionId(_)
    }

    def "null memberServiceResult returns silently without posting or failing"() {
        given:
        Subscriber sub = buildSubscriber("15551230001", "sub-2")
        stubSpy.getOldPhoneNumberFromSubscriptionId(_) >> null
        when:
        service.execute(sub, EventSource.CG)
        then:
        failedEvents.empty
        1 * stubSpy.getOldPhoneNumberFromSubscriptionId(_)
        0 * apiRestClient._
    }

    def "empty memberNum in memberServiceResult returns silently"() {
        given:
        Subscriber sub = buildSubscriber("15551230002", "sub-3")
        MemberServiceResult res = new MemberServiceResult()
        res.setMemberNum("")        // empty
        res.setInstanceId("inst-xyz")
        stubSpy.getOldPhoneNumberFromSubscriptionId(_) >> res
        when:
        service.execute(sub, EventSource.CG)
        then:
        failedEvents.empty
        1 * stubSpy.getOldPhoneNumberFromSubscriptionId(_)
        0 * apiRestClient._
    }

    def "successful flow posts request with populated guid and oldInstanceId"() {
        given:
        def subscriberId = "sor-id-1"
        Subscriber sub = buildSubscriber("5551112222", subscriberId)

        // Generate the same encoded value the service will use
        def encodedId = "93fc9236d9214c3bd5ab998a673ef92c"  // MD5(sor-id-1)

        // Stub DB helper response
        MemberServiceResult res = new MemberServiceResult("G12345",ConsumerConstants.DmctnSubscriberChangeEvent.TRAN_TYPE_UPDATE_DMCTN,"sor-id-1","5551112223")
        stubSpy.getOldPhoneNumberFromSubscriptionId(encodedId) >> res

        when:
        service.execute(sub, EventSource.CG)

        then:
        1 * stubSpy.getOldPhoneNumberFromSubscriptionId(encodedId)
        1 * apiRestClient.sendPostRequest("/changeAssoc", { body ->
            assert body.guid == "G12345"
            assert body.associationList[0].oldSorInvariantId == subscriberId
            assert body.associationList[0].newInstanceId == "5551112222"
            assert body.associationList[0].oldInstanceId == "5551112223"
            true
        }, ConsumerConstants.GridGddnNotification.EVENT_CG_CHANGE_DATA)
        failedEvents.empty
    }

    def "exception during DB lookup saves failed event with eventCategory"() {
        given:
        def subscriberId = "throw-sql-exception"
        Subscriber sub = buildSubscriber("5551112222", subscriberId)
        def encodedId = "eae9373abe05c5db4208d4c41bf9260b0eb382180221dd0116313d300582dfe5"  // MD5(throw-sql-exception)

        when:
        service.execute(sub, EventSource.CG)

        then:
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(_, _) >> false
        0 * apiRestClient.sendPostRequest(_, _, _)
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ FailedEventDetails details ->
            assert details.errorDetails.toString().contains(CErrorDefs.SYS_ERR)
            assert details.errorDetails.toString().contains("Simulated SQL Exception")
            assert details.eventCategory == ConsumerConstants.GridGddnNotification.CATEGORY_CG_SUBSCRIBER
            true
        })
        1 * stubSpy.getOldPhoneNumberFromSubscriptionId(encodedId)
        0 * _
    }

    def "circuit breaker open -> saves CIRCUIT_OPEN event without calling downstream"() {
        given:
        def ctn = "5559999999"
        Subscriber sub = buildSubscriber(ctn, "sub-cb")

        when:
        service.execute(sub, EventSource.CG)

        then:
        1 * gddnFailedEventCircuitBreaker.shouldShortCircuit(ctn, ConsumerConstants.GridGddnNotification.EVENT_CG_CHANGE_DATA) >> true
        0 * stubSpy.getOldPhoneNumberFromSubscriptionId(_)
        0 * apiRestClient.sendPostRequest(_, _, _)
        1 * cosmosFailedEventsWriter.saveFailedEventsToCosmos({ FailedEventDetails details ->
            assert details.eventName == ConsumerConstants.GridGddnNotification.EVENT_CG_CHANGE_DATA
            assert details.eventCategory == ConsumerConstants.GridGddnNotification.CATEGORY_CG_SUBSCRIBER
            assert details.status == "CIRCUIT_OPEN"
            assert details.accountId == ctn
            true
        })
        0 * _
    }

    // Helpers ------------------------------------------------------------

    private static Subscriber buildSubscriber(String phone, String subId) {
        def s = new Subscriber()
        s.setPhoneNumber(phone)
        s.setId(subId)
        return s
    }

    private static void setField(Object target, String name, Object value) {
        def f = target.class.getDeclaredField(name)
        f.accessible = true
        f.set(target, value)
    }

    private void overrideValidatorSuccess() {
        restoreValidator()
        RequestValidator.metaClass.'static'.validate = { String v, String f ->
            [(MPSDefs.APP_STATUS_CODE): CommonDefs.COMMON_SUCCESS,
             (MPSDefs.APP_STATUS_MSG) : "OK"]
        }
    }

    private void overrideValidatorFailure(String code, String msg) {
        restoreValidator()
        RequestValidator.metaClass.'static'.validate = { String v, String f ->
            [(MPSDefs.APP_STATUS_CODE): code,
             (MPSDefs.APP_STATUS_MSG) : msg]
        }
    }

    private void restoreValidator() {
        GroovySystem.metaClassRegistry.removeMetaClass(RequestValidator)
    }

    private void overrideFailedEventCapture() {
        restoreFailedEvent()
        def capture = { proc, phone, payload, eventType, statusCode, msg, endpoint, tranType ->
            failedEvents << [
                    phone     : phone,
                    payload   : payload,
                    eventType : eventType,
                    statusCode: statusCode,
                    msg       : msg,
                    endpoint  : endpoint,
                    tranType  : tranType
            ]
        }
        FailedEventUtil.metaClass.'static'.saveFailedEvent = capture
        FailedEventUtil.metaClass.'static'.saveFailedEventResolvingCategory = capture
    }

    private void restoreFailedEvent() {
        GroovySystem.metaClassRegistry.removeMetaClass(FailedEventUtil)
    }

    private void overrideJson() {
        restoreJson()
        JsonService.metaClass.'static'.getJsonFromObject = { Object o -> '{"json":"mock"}' }
    }

    private void restoreJson() {
        GroovySystem.metaClassRegistry.removeMetaClass(JsonService)
    }
}