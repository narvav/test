package com.att.idp.idgraphconsumerms.kafka.listener

import com.fasterxml.jackson.core.JsonProcessingException
import org.springframework.kafka.support.Acknowledgment
import org.springframework.messaging.MessageHeaders
import spock.lang.Specification
import spock.lang.Unroll

class DmctnCGSubscriberEventOAuthListenerTest extends Specification {

    DmctnCGSubscriberEventProcessor processor
    DmctnCGSubscriberEventOAuthListener listener

    void setup() {
        processor = Mock(DmctnCGSubscriberEventProcessor)
        listener = new DmctnCGSubscriberEventOAuthListener(processor)
    }

    @Unroll
    def "should delegate event processing to processor for #scenarioName"() {
        given: "A message, headers, and acknowledgment"
        String msg = message
        MessageHeaders headers = Mock(MessageHeaders)
        Acknowledgment ack = Mock(Acknowledgment)

        when: "consumeCGSubcriberEvent is called"
        listener.consumeCGSubcriberEvent(msg, headers, ack)

        then: "Processor's processEvent is called with correct arguments"
        1 * processor.processEvent(msg, headers, ack)
        0 * _

        where:
        scenarioName      | message
        "valid message"   | "{\"event\":\"test\"}"
        "empty message"   | ""
    }

    def "should propagate JsonProcessingException from processor"() {
        given: "A message, headers, and acknowledgment"
        String msg = "{\"event\":\"bad\"}"
        MessageHeaders headers = Mock(MessageHeaders)
        Acknowledgment ack = Mock(Acknowledgment)
        JsonProcessingException exception = new JsonProcessingException("error") {}

        when: "Processor throws JsonProcessingException"
        listener.consumeCGSubcriberEvent(msg, headers, ack)

        then: "Exception is propagated"
        1 * processor.processEvent(msg, headers, ack) >> { throw exception }
        0 * _
        JsonProcessingException ex = thrown()
        ex.message == "error"
    }
}

