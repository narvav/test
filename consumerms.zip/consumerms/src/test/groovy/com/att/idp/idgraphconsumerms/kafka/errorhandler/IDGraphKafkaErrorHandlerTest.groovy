package com.att.idp.idgraphconsumerms.kafka.errorhandler

import com.fasterxml.jackson.core.JsonParseException
import com.fasterxml.jackson.databind.JsonMappingException
import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException
import org.apache.kafka.clients.consumer.Consumer
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.TopicPartition
import org.apache.kafka.common.errors.RecordDeserializationException
import org.springframework.kafka.listener.ListenerExecutionFailedException
import org.springframework.kafka.listener.MessageListenerContainer
import spock.lang.Specification
import spock.lang.Unroll

class IDGraphKafkaErrorHandlerTest extends Specification {

    IDGraphKafkaErrorHandler errorHandler
    Consumer consumer
    MessageListenerContainer container

    def setup() {
        errorHandler = new IDGraphKafkaErrorHandler()
        consumer = Mock(Consumer)
        container = Mock(MessageListenerContainer)
    }

    def "should handle RecordDeserializationException and skip record for #scenarioName"() {
        given: "A RecordDeserializationException with topic, partition and offset"
        TopicPartition topicPartition = new TopicPartition("test-topic", 0)
        RecordDeserializationException exception = new RecordDeserializationException(
                topicPartition,
                10L,
                "Deserialization error",
                new RuntimeException("Cause of the error")
        )
        ConsumerRecord<String, String> record = Mock(ConsumerRecord)

        when: "handleOne is called"
        boolean result = errorHandler.handleOne(exception, record, consumer, container)

        then: "Record is skipped by seeking to next offset"
        result == true
        1 * consumer.seek(topicPartition, 11L)
        1 * consumer.commitSync()
        0 * _

        where:
        scenarioName << ["RecordDeserializationException"]
    }

    @Unroll
    def "should handle non-retryable exception and skip record for #scenarioName"() {
        given: "A non-retryable exception wrapped in ListenerExecutionFailedException"
        ConsumerRecord<String, String> record = Mock(ConsumerRecord) {
            topic() >> "test-topic"
            partition() >> partitionNum
            offset() >> offsetNum
        }
        ListenerExecutionFailedException wrappedException = new ListenerExecutionFailedException(
                "Listener failed",
                causeException
        )

        when: "handleOne is called"
        boolean result = errorHandler.handleOne(wrappedException, record, consumer, container)

        then: "Record is skipped by seeking to next offset"
        result == true
        1 * consumer.seek(new TopicPartition("test-topic", partitionNum), offsetNum + 1L)
        1 * consumer.commitSync()

        where:
        scenarioName                      | causeException                                                                           | partitionNum | offsetNum
        "UnrecognizedPropertyException"   | Mock(UnrecognizedPropertyException) { getMessage() >> "Unrecognized field" }             | 0            | 100L
        "JsonProcessingException"         | new JsonParseException(null, "Invalid JSON")                                             | 1            | 200L
        "JsonMappingException"            | JsonMappingException.from(null as com.fasterxml.jackson.core.JsonParser, "Mapping error")| 2            | 300L
    }

    def "should handle non-retryable exception with no record context for #scenarioName"() {
        given: "A non-retryable exception without record"
        JsonParseException jsonException = new JsonParseException(null, "Invalid JSON")
        ListenerExecutionFailedException wrappedException = new ListenerExecutionFailedException(
                "Listener failed",
                jsonException
        )

        when: "handleOtherException is called with null record"
        errorHandler.handleOtherException(wrappedException, consumer, container, false)

        then: "No seek or commit occurs since record is null"
        0 * consumer.seek(_, _)
        0 * consumer.commitSync()
        0 * _

        where:
        scenarioName << ["JsonProcessingException without record"]
    }

    def "should not skip record for unhandled exception types for #scenarioName"() {
        given: "An unhandled exception type"
        RuntimeException exception = new RuntimeException("Unhandled exception")
        ConsumerRecord<String, String> record = Mock(ConsumerRecord)

        when: "handleOne is called"
        boolean result = errorHandler.handleOne(exception, record, consumer, container)

        then: "Record is not skipped"
        result == true
        0 * consumer.seek(_, _)
        0 * consumer.commitSync()
        0 * _

        where:
        scenarioName << ["RuntimeException"]
    }

    def "should handle handleOtherException with RecordDeserializationException"() {
        given: "A RecordDeserializationException"
        TopicPartition topicPartition = new TopicPartition("test-topic", 0)
        RecordDeserializationException exception = new RecordDeserializationException(
                topicPartition,
                10L,
                "Deserialization error",
                new RuntimeException("Cause of the error")
        )

        when: "handleOtherException is called"
        errorHandler.handleOtherException(exception, consumer, container, false)

        then: "Record is skipped by seeking to next offset"
        1 * consumer.seek(topicPartition, 11L)
        1 * consumer.commitSync()
        0 * _
    }

    def "should handle handleOtherException with unhandled exception"() {
        given: "An unhandled exception"
        RuntimeException exception = new RuntimeException("Unhandled exception")

        when: "handleOtherException is called"
        errorHandler.handleOtherException(exception, consumer, container, false)

        then: "No seek or commit occurs"
        0 * consumer.seek(_, _)
        0 * consumer.commitSync()
        0 * _
    }

    def "should handle direct JsonProcessingException without ListenerExecutionFailedException wrapper"() {
        given: "A direct JsonProcessingException"
        JsonParseException exception = new JsonParseException(null, "Invalid JSON")
        ConsumerRecord<String, String> record = Mock(ConsumerRecord) {
            topic() >> "test-topic"
            partition() >> 0
            offset() >> 50L
        }

        when: "handleOne is called"
        boolean result = errorHandler.handleOne(exception, record, consumer, container)

        then: "Record is skipped by seeking to next offset"
        result == true
        1 * consumer.seek(new TopicPartition("test-topic", 0), 51L)
        1 * consumer.commitSync()
    }

    def "should handle ListenerExecutionFailedException with non-JSON cause as unhandled"() {
        given: "A ListenerExecutionFailedException with non-JSON cause"
        IllegalArgumentException illegalArgException = new IllegalArgumentException("Invalid argument")
        ListenerExecutionFailedException wrappedException = new ListenerExecutionFailedException(
                "Listener failed",
                illegalArgException
        )
        ConsumerRecord<String, String> record = Mock(ConsumerRecord)

        when: "handleOne is called"
        boolean result = errorHandler.handleOne(wrappedException, record, consumer, container)

        then: "Record is not skipped since cause is not a JSON exception"
        result == true
        0 * consumer.seek(_, _)
        0 * consumer.commitSync()
        0 * _
    }

    def "should handle ListenerExecutionFailedException with null cause"() {
        given: "A ListenerExecutionFailedException with null cause"
        ListenerExecutionFailedException wrappedException = new ListenerExecutionFailedException(
                "Listener failed",
                (Throwable) null
        )
        ConsumerRecord<String, String> record = Mock(ConsumerRecord)

        when: "handleOne is called"
        boolean result = errorHandler.handleOne(wrappedException, record, consumer, container)

        then: "Record is not skipped"
        result == true
        0 * consumer.seek(_, _)
        0 * consumer.commitSync()
        0 * _
    }
}