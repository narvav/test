package com.att.idp.idgraphconsumerms.helpers

import com.att.idp.idgraphconsumerms.constants.OdsNotesConstants
import com.att.idp.idgraphconsumerms.kafka.model.OdsGenerateNotesEvent
import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import spock.lang.Specification
import spock.lang.Unroll

class OdsNotesTransformHelperTest extends Specification {

    OdsNotesTransformHelper helper = new OdsNotesTransformHelper()
    ObjectMapper objectMapper = new ObjectMapper()

    // ==================== Profile Update Tests ====================

    def "T-TH-1: Profile Update happy path — eventType=ProfileUpdate, category=Passcode"() {
        given: "A valid Profile Update event with category Passcode"
        JsonNode input = objectMapper.readTree('''{
            "eventId": "evt-123",
            "eventType": "ProfileUpdate",
            "category": "Passcode",
            "eventDetails": {
                "individualId": "IND-001",
                "clientId": "IDP",
                "agentId": "AGT-PROFILE-001",
                "accountType": "wireless",
                "accountId": "ACC-001",
                "attributes": [
                    {"attributeName": "passcodeType", "attributeValue": "P"}
                ]
            }
        }''')

        when: "transformProfileUpdateEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformProfileUpdateEvent(input)

        then: "A valid OdsGenerateNotesEvent is returned"
        result.isPresent()
        OdsGenerateNotesEvent event = result.get()
        event.transactionId == "evt-123"
        event.id == "IND-001"
        event.idType == "individual"
        event.domain == "idGraph"
        event.eventType == "Change BAN Passcode"
        event.compareType == "NA"
        event.channel == "DIGITAL"
        event.data.size() == 1
        event.data[0]["individualId"] == "IND-001"
        event.data[0]["agentId"] == "AGT-PROFILE-001"
        event.data[0]["accountType"] == "wireless"
        event.data[0]["accountId"] == "ACC-001"
        0 * _
    }

    def "T-TH-2: Profile Update — category != Passcode returns empty"() {
        given: "A Profile Update event with non-Passcode category"
        JsonNode input = objectMapper.readTree('''{
            "eventType": "ProfileUpdate",
            "category": "Email",
            "eventDetails": {"individualId": "IND-001"}
        }''')

        when: "transformProfileUpdateEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformProfileUpdateEvent(input)

        then: "Optional.empty is returned"
        result.isEmpty()
        0 * _
    }

    def "T-TH-3: Profile Update — missing category field returns empty"() {
        given: "A Profile Update event with no category"
        JsonNode input = objectMapper.readTree('''{
            "eventType": "ProfileUpdate",
            "eventDetails": {"individualId": "IND-001"}
        }''')

        when: "transformProfileUpdateEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformProfileUpdateEvent(input)

        then: "Optional.empty is returned"
        result.isEmpty()
        0 * _
    }

    @Unroll
    def "T-TH-4: Profile Update — clientId=#clientId maps to channel=#expectedChannel"() {
        given: "A valid Profile Update event with specified clientId"
        JsonNode input = objectMapper.readTree("""{
            "eventId": "evt-ch",
            "eventType": "ProfileUpdate",
            "category": "Passcode",
            "eventDetails": {"individualId": "IND-001", "clientId": "${clientId}"}
        }""")

        when: "transformProfileUpdateEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformProfileUpdateEvent(input)

        then: "Channel is correctly mapped"
        result.isPresent()
        result.get().channel == expectedChannel
        0 * _

        where:
        clientId       | expectedChannel
        "IVRSAG"       | "IVR"
        "IDP"          | "DIGITAL"
        "IDMPROFILEMS" | "DIGITAL"
        "CCMULE"       | "CARE"
        "BSSEMIPAAS"   | "MIGRATION"
    }

    def "T-TH-5: Profile Update — unknown clientId returns actual clientId as channel"() {
        given: "A valid Profile Update event with unknown clientId"
        JsonNode input = objectMapper.readTree('''{
            "eventId": "evt-unk",
            "eventType": "ProfileUpdate",
            "category": "Passcode",
            "eventDetails": {"individualId": "IND-001", "clientId": "UNKNOWN_CLIENT"}
        }''')

        when: "transformProfileUpdateEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformProfileUpdateEvent(input)

        then: "The incoming clientId is returned as the channel"
        result.isPresent()
        result.get().channel == "UNKNOWN_CLIENT"
        0 * _
    }

    def "T-TH-5A: Profile Update — passcodeType D produces Passcode Changed event"() {
        given: "A valid Profile Update event with passcodeType D"
        JsonNode input = objectMapper.readTree('''{
            "eventId": "evt-digital-passcode",
            "eventType": "ProfileUpdate",
            "category": "Passcode",
            "eventDetails": {
                "individualId": "IND-001",
                "clientId": "IDP",
                "attributes": [
                    {"attributeName": "passcodeType", "attributeValue": "D"}
                ]
            }
        }''')

        when: "transformProfileUpdateEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformProfileUpdateEvent(input)

        then: "Passcode Changed event is returned"
        result.isPresent()
        result.get().eventType == "Passcode Changed"
        0 * _
    }

    // ==================== Oracle Security Code Tests ====================

    def "T-TH-6: Oracle Security Code happy path — full filter match"() {
        given: "A valid Oracle Security Code event"
        JsonNode input = objectMapper.readTree('''{
            "eventId": "evt-ora-1",
            "eventType": "OracleSecurityCodeSync",
            "resourceName": "OTP",
            "event": {
                "type": "INSERT",
                "data": {
                    "accountId": "BAN-001",
                    "identificationType": "PORTOUTBSS",
                    "securityCode": {
                        "updatedBy": "IDP",
                        "createdDate": "2026-01-01",
                        "securityCodeExpires": "2026-01-02",
                        "deliveryDetail": "SMS"
                    }
                }
            }
        }''')

        when: "transformOracleSecurityCodeEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformOracleSecurityCodeEvent(input)

        then: "A valid event is returned with correct fields"
        result.isPresent()
        OdsGenerateNotesEvent event = result.get()
        event.transactionId == "evt-ora-1"
        event.id == "BAN-001"
        event.idType == "billingAccount"
        event.eventType == "Number Transfer PIN"
        event.channel == "DIGITAL"
        event.data.size() == 1
        event.data[0]["accountId"] == "BAN-001"
        event.data[0]["accountType"] == "postPaid"
        event.data[0]["portoutType"] == "PORTOUTBSS"
        event.data[0]["createdDate"] == "2026-01-01"
        event.data[0]["pinExpiryDate"] == "2026-01-02"
        event.data[0]["deliveredTo"] == "SMS"
        0 * _
    }

    def "T-TH-7: Oracle — event.type=DELETE returns empty"() {
        given: "An Oracle event with DELETE type"
        JsonNode input = objectMapper.readTree('''{
            "eventType": "OracleSecurityCodeSync",
            "resourceName": "OTP",
            "event": {"type": "DELETE", "data": {"identificationType": "PORTOUTBSS"}}
        }''')

        when: "transformOracleSecurityCodeEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformOracleSecurityCodeEvent(input)

        then: "Optional.empty is returned"
        result.isEmpty()
        0 * _
    }

    def "T-TH-8: Oracle — identificationType != PORTOUTBSS returns empty"() {
        given: "An Oracle event with wrong identificationType"
        JsonNode input = objectMapper.readTree('''{
            "eventType": "OracleSecurityCodeSync",
            "resourceName": "OTP",
            "event": {"type": "INSERT", "data": {"identificationType": "PORTIN"}}
        }''')

        when: "transformOracleSecurityCodeEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformOracleSecurityCodeEvent(input)

        then: "Optional.empty is returned"
        result.isEmpty()
        0 * _
    }

    def "T-TH-9: Oracle — resourceName != OTP returns empty"() {
        given: "An Oracle event with wrong resourceName"
        JsonNode input = objectMapper.readTree('''{
            "eventType": "OracleSecurityCodeSync",
            "resourceName": "PASSWORD",
            "event": {"type": "INSERT", "data": {"identificationType": "PORTOUTBSS"}}
        }''')

        when: "transformOracleSecurityCodeEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformOracleSecurityCodeEvent(input)

        then: "Optional.empty is returned"
        result.isEmpty()
        0 * _
    }

    @Unroll
    def "T-TH-10: Oracle — updatedBy=#updatedBy maps to channel=#expectedChannel"() {
        given: "A valid Oracle event with specified updatedBy"
        JsonNode input = objectMapper.readTree("""{
            "eventId": "evt-ora-ch",
            "eventType": "OracleSecurityCodeSync",
            "resourceName": "OTP",
            "event": {
                "type": "UPDATE",
                "data": {
                    "accountId": "BAN-002",
                    "identificationType": "PORTOUTBSS",
                    "securityCode": {"updatedBy": "${updatedBy}"}
                }
            }
        }""")

        when: "transformOracleSecurityCodeEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformOracleSecurityCodeEvent(input)

        then: "Channel is correctly mapped"
        result.isPresent()
        result.get().channel == expectedChannel
        0 * _

        where:
        updatedBy | expectedChannel
        "IDPWAM"  | "DIGITAL"
        "IDP"     | "DIGITAL"
        "IVRSAG"  | "IVR"
        "UNKNOWN" | "UNKNOWN"
    }

    @Unroll
    def "T-TH-10A: Oracle INSERT identificationType=#identificationType produces #expectedEventType"() {
        given: "A valid Oracle BSSE OTP event"
        JsonNode input = objectMapper.readTree("""{
            "eventId": "evt-bsse-otp",
            "eventType": "OracleSecurityCodeSync",
            "resourceName": "OTP",
            "event": {
                "type": "INSERT",
                "data": {
                    "accountId": "BAN-003",
                    "identificationType": "${identificationType}",
                    "securityCode": {
                        "updatedBy": "BSSE_CHANNEL",
                        "createdDate": "2026-02-01",
                        "securityCodeExpires": "2026-02-02",
                        "deliveryDetail": "EMAIL"
                    }
                }
            }
        }""")

        when: "transformOracleSecurityCodeEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformOracleSecurityCodeEvent(input)

        then: "The BSSE Generate PIN event is returned with otpType and updatedBy channel fallback"
        result.isPresent()
        OdsGenerateNotesEvent event = result.get()
        event.eventType == expectedEventType
        event.channel == "BSSE_CHANNEL"
        event.data[0]["otpType"] == identificationType
        !event.data[0].containsKey("portoutType")
        0 * _

        where:
        identificationType | expectedEventType
        "BSSEGENS"         | "Generate PIN - BSSEGENS"
        "BSSEGENE"         | "Generate PIN - BSSEGENE"
    }

    @Unroll
    def "T-TH-10B: Oracle UPDATE identificationType=#identificationType produces #expectedEventType"() {
        given: "A valid Oracle BSSE Verify PIN event"
        JsonNode input = objectMapper.readTree("""{
            "eventId": "evt-bsse-verify",
            "eventType": "OracleSecurityCodeSync",
            "resourceName": "OTP",
            "event": {
                "type": "UPDATE",
                "data": {
                    "accountId": "BAN-004",
                    "identificationType": "${identificationType}",
                    "agentId": "${agentId}",
                    "securityAccount": {
                        "accountType": "${accountType}"
                    },
                    "securityCode": {
                        "securityCodeStatus": "${validationStatus}",
                        "updatedBy": "${updatedBy}"
                    }
                }
            }
        }""")

        when: "transformOracleSecurityCodeEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformOracleSecurityCodeEvent(input)

        then: "The Verify PIN event is returned with the requested data payload"
        result.isPresent()
        OdsGenerateNotesEvent event = result.get()
        event.eventType == expectedEventType
        event.channel == expectedChannel
        event.data.size() == 1
        event.data[0] == [
                accountId       : "BAN-004",
                accountType     : accountType,
                otpType         : identificationType,
                validationStatus: validationStatus,
                agentId         : agentId
        ]
        0 * _

        where:
        identificationType | accountType | validationStatus | agentId  | updatedBy      | expectedChannel | expectedEventType
        "BSSEGENS"         | "WIRELESS" | "FAILED"         | "AGT001" | "BSSE_CHANNEL" | "BSSE_CHANNEL" | "Verify PIN - BSSEGENS"
        "BSSEGENE"         | "ECOMM"    | "REGISTERED"     | "AGT002" | "IDP"          | "DIGITAL"      | "Verify PIN - BSSEGENE"
    }

    def "T-TH-10C: Oracle UPDATE without optional agentId produces null agentId"() {
        given: "A valid Oracle BSSE Verify PIN event without agentId"
        JsonNode input = objectMapper.readTree('''{
            "eventType": "OracleSecurityCodeSync",
            "resourceName": "OTP",
            "event": {
                "type": "UPDATE",
                "data": {
                    "accountId": "BAN-005",
                    "identificationType": "BSSEGENS",
                    "securityAccount": {"accountType": "WIRELESS"},
                    "securityCode": {"securityCodeStatus": "FAILED", "updatedBy": "IDP"}
                }
            }
        }''')

        when: "transformOracleSecurityCodeEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformOracleSecurityCodeEvent(input)

        then: "The event is returned with a null agentId"
        result.isPresent()
        result.get().data[0]["agentId"] == null
        result.get().channel == "DIGITAL"
        0 * _
    }

    // ==================== Fraud Lock / Fraud Unlock Tests ====================

    def "T-TH-11: Fraud Lock happy path — subCategory=LVLONE_ACCESSID_LOCK"() {
        given: "A valid Fraud event with LVLONE lock"
        JsonNode input = objectMapper.readTree('''{
            "eventId": "evt-fraud-1",
            "eventName": "UpdateUserFraud",
            "eventDetails": {
                "individualId": "IND-FRAUD-1",
                "accessId": "ACC-FRAUD-1",
                "subCategory": "LVLONE_ACCESSID_LOCK",
                "clientId": "NEMESIS",
                "agentId": "AGT-FRAUD-001",
                "attributes": [
                    {"attributeName": "userLockedReasonCode", "attributeValue": "STOLEN_DEVICE"}
                ]
            }
        }''')

        when: "transformUserFraudEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformUserFraudEvent(input)

        then: "Fraud Lock event is returned"
        result.isPresent()
        OdsGenerateNotesEvent event = result.get()
        event.eventType == "Fraud Lock"
        event.channel == "Fraud Team"
        event.data[0]["individualId"] == "IND-FRAUD-1"
        event.data[0]["userId"] == "ACC-FRAUD-1"
        event.data[0]["userLockType"] == "LVLONE_ACCESSID_LOCK"
        event.data[0]["userLockedReasonCode"] == "STOLEN_DEVICE"
        event.data[0]["agentId"] == "AGT-FRAUD-001"
        0 * _
    }

    def "T-TH-12: Fraud Lock — subCategory=LVLTWO_ACCESSID_LOCK"() {
        given: "A valid Fraud event with LVLTWO lock"
        JsonNode input = objectMapper.readTree('''{
            "eventId": "evt-fraud-2",
            "eventName": "UpdateUserFraud",
            "eventDetails": {
                "individualId": "IND-FRAUD-2",
                "accessId": "ACC-FRAUD-2",
                "subCategory": "LVLTWO_ACCESSID_LOCK",
                "clientId": "AVERTACK",
                "attributes": [
                    {"attributeName": "userLockedReasonCode", "attributeValue": "SIM_SWAP"}
                ]
            }
        }''')

        when: "transformUserFraudEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformUserFraudEvent(input)

        then: "Fraud Lock event is returned"
        result.isPresent()
        result.get().eventType == "Fraud Lock"
        result.get().channel == "AVERTACK"
        0 * _
    }

    def "T-TH-13: Fraud Unlock — subCategory=ACCESSID_FRAUD_UNLOCK"() {
        given: "A valid Fraud Unlock event"
        JsonNode input = objectMapper.readTree('''{
            "eventId": "evt-fraud-3",
            "eventName": "UpdateUserFraud",
            "eventDetails": {
                "individualId": "IND-FRAUD-3",
                "accessId": "ACC-FRAUD-3",
                "subCategory": "ACCESSID_FRAUD_UNLOCK",
                "clientId": "CSRIDP",
                "attributes": [
                    {"attributeName": "userLockedReasonCode", "attributeValue": "VERIFIED_CUSTOMER"}
                ]
            }
        }''')

        when: "transformUserFraudEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformUserFraudEvent(input)

        then: "Fraud Unlock event is returned"
        result.isPresent()
        result.get().eventType == "Fraud Unlock"
        result.get().channel == "CARE"
        0 * _
    }

    def "T-TH-14: Fraud — subCategory not in allowed list returns empty"() {
        given: "A Fraud event with disallowed subCategory"
        JsonNode input = objectMapper.readTree('''{
            "eventName": "UpdateUserFraud",
            "eventDetails": {
                "individualId": "IND-001",
                "subCategory": "ACCOUNT_LOCK",
                "attributes": []
            }
        }''')

        when: "transformUserFraudEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformUserFraudEvent(input)

        then: "Optional.empty is returned"
        result.isEmpty()
        0 * _
    }

    def "T-TH-15: Fraud — individualId is null returns empty"() {
        given: "A Fraud event with null individualId"
        JsonNode input = objectMapper.readTree('''{
            "eventName": "UpdateUserFraud",
            "eventDetails": {
                "subCategory": "LVLONE_ACCESSID_LOCK",
                "attributes": []
            }
        }''')

        when: "transformUserFraudEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformUserFraudEvent(input)

        then: "Optional.empty is returned"
        result.isEmpty()
        0 * _
    }

    def "T-TH-16: Fraud — empty attributes array results in userLockedReasonCode=null"() {
        given: "A valid Fraud event with empty attributes"
        JsonNode input = objectMapper.readTree('''{
            "eventId": "evt-fraud-empty",
            "eventName": "UpdateUserFraud",
            "eventDetails": {
                "individualId": "IND-FRAUD-4",
                "accessId": "ACC-FRAUD-4",
                "subCategory": "LVLONE_ACCESSID_LOCK",
                "clientId": "YAHOO",
                "attributes": []
            }
        }''')

        when: "transformUserFraudEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformUserFraudEvent(input)

        then: "Event is returned with userLockedReasonCode=null"
        result.isPresent()
        result.get().data[0]["userLockedReasonCode"] == null
        0 * _
    }

    def "T-TH-17: Fraud — no userLockedReasonCode attribute results in null"() {
        given: "A Fraud event with attributes but no userLockedReasonCode"
        JsonNode input = objectMapper.readTree('''{
            "eventId": "evt-fraud-noattr",
            "eventName": "UpdateUserFraud",
            "eventDetails": {
                "individualId": "IND-FRAUD-5",
                "accessId": "ACC-FRAUD-5",
                "subCategory": "LVLONE_ACCESSID_LOCK",
                "clientId": "IDPCOMENBSER",
                "attributes": [
                    {"attributeName": "otherAttr", "attributeValue": "someValue"}
                ]
            }
        }''')

        when: "transformUserFraudEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformUserFraudEvent(input)

        then: "Event is returned with userLockedReasonCode=null"
        result.isPresent()
        result.get().data[0]["userLockedReasonCode"] == null
        result.get().channel == "Digital"
        0 * _
    }

    @Unroll
    def "T-TH-18: Fraud — clientId=#clientId maps to channel=#expectedChannel"() {
        given: "A valid Fraud event with specified clientId"
        JsonNode input = objectMapper.readTree("""{
            "eventId": "evt-fraud-ch",
            "eventName": "UpdateUserFraud",
            "eventDetails": {
                "individualId": "IND-001",
                "accessId": "ACC-001",
                "subCategory": "LVLONE_ACCESSID_LOCK",
                "clientId": "${clientId}",
                "attributes": [
                    {"attributeName": "userLockedReasonCode", "attributeValue": "REASON"}
                ]
            }
        }""")

        when: "transformUserFraudEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformUserFraudEvent(input)

        then: "Channel is correctly mapped"
        result.isPresent()
        result.get().channel == expectedChannel
        0 * _

        where:
        clientId        | expectedChannel
        "AVERTACK"      | "AVERTACK"
        "YAHOO"         | "YAHOO"
        "NEMESIS"       | "Fraud Team"
        "CSRIDP"        | "CARE"
        "IDPCALM"       | "CARE"
        "IDPCOMENBSER"  | "Digital"
        "UNKNOWN_FR"    | "NA"
    }

    // ==================== Common Tests ====================

    def "T-TH-19: Null JsonNode input throws exception"() {
        when: "transformProfileUpdateEvent is called with null"
        helper.transformProfileUpdateEvent(null)

        then: "NullPointerException is thrown"
        thrown(NullPointerException)
        0 * _
    }

    def "T-TH-20: Common buildEvent — domain and compareType set consistently"() {
        given: "A valid Profile Update event"
        JsonNode input = objectMapper.readTree('''{
            "eventId": "evt-common",
            "eventType": "ProfileUpdate",
            "category": "Passcode",
            "eventDetails": {"individualId": "IND-COM", "clientId": "IDP"}
        }''')

        when: "transformProfileUpdateEvent is called"
        Optional<OdsGenerateNotesEvent> result = helper.transformProfileUpdateEvent(input)

        then: "Domain and compareType are consistent"
        result.isPresent()
        result.get().domain == "idGraph"
        result.get().compareType == "NA"
        0 * _
    }
}
