# Contributing to IDGraph API Collections

This repository contains **Bruno** collections and shared environments used to exercise the IDGraph microservices. The goal is to keep these collections:

- Accurate representations of current APIs
- Safe (no secrets in source control)
- Easy to navigate by microservice

Follow the guidelines below when adding or updating content.

---

## 1. File Types and Format

- **Use Bruno collections only**:
  - Add requests and collections as `*.bru` files.
  - Do **not** introduce Postman YAML/JSON or other client formats into this repo.
- **Root descriptors**:
  - Keep `bruno.json` at the appropriate collection root.

---

## 2. Repository Structure

- **Per-microservice folders**
  - Under `IDGraph-Collections/`, create or use a **dedicated folder per microservice**, matching its service name.
  - Example folders (non-exhaustive):
    - `IDGraphConsumerms/`
    - `IDGraphContactInfoMs/`
    - `IDGraphMpsAdapterMs/`
    - `IDGraphSubSvcMs/`
    - `IDGraphUserAssociationMs/`
    - `IDGraphUserManagementMs/`
    - `IDGraphUserProfileMs/`
    - `IDGraphUserRegistrationMs/`
  - Group scenario-specific flows in subfolders (e.g. `BSSE Migration Status/`, `Credentials/`) when helpful.

- **Environments**
  - Shared environments live in `IDGraph-Environments/`.
  - Reuse existing environments when possible (e.g. TEST, STAGE, PROD, LOCAL) instead of duplicating URLs per collection.

- **Legacy flows**
  - Historical or deprecated flows should be moved into `Legacy-Collections/` rather than deleted, if they are still occasionally referenced.

---

## 3. Secrets and Sensitive Data

**Never commit secrets or sensitive values.** This includes, but is not limited to:

- Passwords, API keys, client secrets
- Mech IDs or user IDs that are not anonymized
- Access tokens, refresh tokens, or cookies
- Internal certificates or private keys

### Best practices

- Use **environment variables** and Bruno environments:
  - Keep placeholders like `{{password}}`, `{{token}}`, `{{mechid}}` in `.bru` files.
  - Store actual values only in **local** Bruno environments or secret stores, not in this repository.
- If you accidentally commit a secret:
  - Rotate the secret following your standard process.
  - Remove/replace the value in the collection.
  - Coordinate with repo owners for any required history cleanup.

---

## 4. Adding or Updating Collections

When you add or change requests:

1. **Choose the correct microservice folder** under `IDGraph-Collections/`.
2. **Name requests clearly**:
   - Include the resource and main behavior, e.g. `GetProfileByIndividualId.bru`, `GeneratePIN - SMS.bru`.
3. **Reuse shared pieces** where possible:
   - Common headers, auth, and base URLs should come from environments, not duplicated literals in every request.
4. **Keep flows minimal but complete**:
   - Include just enough steps to exercise the scenario or reproduce a bug.
   - Avoid adding very similar duplicates; extend existing flows when reasonable.

---

## 5. Environments and URLs

- Prefer using the **global environments** in `IDGraph-Environments/_global-environments.json` for standard test, stage, and prod endpoints.
- If you must add a new environment:
  - Use consistent variable names (`url`, `cgurl`, `mechid`, `password`, etc.).
  - Do not hardcode sensitive values; leave secrets blank or obviously placeholder.

---

## 6. Reviews and Code Owners

- All changes should go through the normal PR process.
- `CODEOWNERS` defines default reviewers; ensure at least one owner reviews Bruno changes that:
  - Introduce new APIs or flows
  - Change environment semantics (URLs, variable names)
  - Remove or significantly alter existing collections

---

## 7. Common Pitfalls to Avoid

- Adding non-Bruno formats (Postman exports, raw JSON/YAML collections) to this repo.
- Committing local override or machine-specific files (these are generally covered by `.gitignore`).
- Duplicating the same scenario across multiple folders instead of organizing under the appropriate microservice.
- Embedding environment-specific URLs directly in `.bru` files where an environment variable should be used.

---

## 8. Getting Help

If you are unsure where to place a new collection or how to model a scenario:

- Check the existing structure under `IDGraph-Collections/` for a similar microservice or pattern.
- Ask the repo CODEOWNERS or IDGraph platform team for guidance before introducing new top-level folders.

Keeping these practices in mind will help ensure the collections remain clean, safe, and easy for the entire team to use.
