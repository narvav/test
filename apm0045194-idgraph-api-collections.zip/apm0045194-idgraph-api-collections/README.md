# IDGraph API Collections

This repository contains Bruno collections and shared environments for the IDGraph microservices. It is intended for exercising and regression‑testing the **current** IDGraph APIs.

> **Scope:** This documentation covers only the **IDGraph-Collections** and **IDGraph-Environments** folders. The `Legacy-Collections` folder is intentionally **excluded** from this README.

## Structure

- **IDGraph-Collections/**  
  Bruno collections grouped by microservice or upstream system:
  - **BizGateway/** – Requests and flows for BizGateway integration endpoints.
  - **CG API/** – Collections for the CG (Customer Graph) API surface.
  - **IDGraphConsumerms/** – Endpoints for the IDGraph Consumer MS.
  - **IDGraphContactInfoMs/** – Contact information read/write operations.
  - **IDGraphMpsAdapterMs/** – MPS adapter microservice endpoints.
  - **IDGraphSubSvcMs/** – Subscription service endpoints.
  - **IDGraphUserAssociationMs/** – User association API flows, including:
    - **BSSE Migration Status/** – scenarios for BSSE migration status checks.
    - **Credentials/** – credential‑related user association flows.
  - **IDGraphUserManagementMs/** – User management administrative APIs.
  - **IDGraphUserProfileMs/** – User profile query and update APIs.
  - **IDGraphUserRegistrationMs/** – User registration and onboarding flows.

- **IDGraph-Environments/**  
  Shared Bruno environments (for dev/test/prod‑like targets, hosts, and common headers). These environments are referenced by the collections under `IDGraph-Collections`.

- **Legacy-Collections/**  
  Contains historical collections for older patterns and external systems.  
  **Note:** This README intentionally does **not** describe or document these legacy collections.

## Usage

1. **Open in Bruno**
   - Launch the Bruno API client.
   - Open this repository as a workspace or import the desired collection folder from `IDGraph-Collections/`.

2. **Select an environment**
   - Load an environment from `IDGraph-Environments/` (for example, a global or environment‑specific file) and adjust hostnames, credentials, and secrets as appropriate for your local setup.

3. **Run requests**
   - Use the per‑microservice collections to:
     - Exercise new features.
     - Reproduce issues.
     - Run quick regression checks against IDGraph services.

## Conventions

- Collections are organized **by microservice**, using the same names as the runtime services in the IDGraph platform.
- Environment files are designed to be **shared** across collections where possible (common base URLs, headers, and auth wiring).
- Secrets (tokens, connection strings, passwords) should **not** be committed here; use local Bruno secrets or your standard secret‑management approach.

## Contribution Guidelines

- Add new requests to the appropriate microservice folder under `IDGraph-Collections/`.
- Prefer updating or extending existing collections over creating duplicate ones.
- Keep naming consistent with the corresponding microservice and API resource names.
- When removing or heavily changing an API, consider moving old flows into `Legacy-Collections/` rather than deleting them outright.
