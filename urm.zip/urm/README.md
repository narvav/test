# IDGraphUserRegistrationMs — User Registration & Profile Sync Microservice

| Field | Value |
|---|---|
| **Domain / Team** | `IDGraph` |
| **Artifact ID** | `IDGraphUserRegistrationMs` |
| **Version** | `0.0.1-SNAPSHOT` |
| **Component Type** | `REST API + SOAP + JMS + Kafka` |
| **Runtime / Parent** | `sdk-java-parent 3.0.0` |
| **Language / Java Version** | `Java 17` |
| **Base Path / Entry Point** | `/msapi/idgraphuserregistrationms/v1` |
| **API / Contract Docs** | Swagger UI at `/idgraphuserregistrationms/swagger/index.html` |

---

## Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Project Structure](#project-structure)
4. [Domain Capability Map](#domain-capability-map)
5. [Integration Context](#integration-context)
6. [Process Flows](#process-flows)
7. [Interfaces & Endpoints](#interfaces--endpoints)
8. [Data Stores & State Management](#data-stores--state-management)
9. [Configuration](#configuration)
10. [Dependencies](#dependencies)
11. [Observability and Operations](#observability-and-operations)
12. [Security and Compliance](#security-and-compliance)
13. [Build and Test](#build-and-test)
14. [Deployment](#deployment)
15. [Change Log / History](#change-log--history)

---

## Overview

**IDGraphUserRegistrationMs** is an IDGraph platform microservice responsible for **user registration, account activation, profile synchronization, and Terms of Service management** within the MPSYS identity ecosystem.
It acts as the central registration orchestrator, handling:

- **LS User Registration**: Register new LightStream users via SOAP calls to MPS backend (`RegisterUser`)
- **Wireless Auto-Registration**: End-to-end wireless account auto-registration with LDAP provisioning, HaloC sync, G2 sync, and MQ event publishing
- **Quick Account Review (QAR) Retrigger**: Resend QAR email/SMS notifications via CLM/MuleSoft integration
- **User Profile Sync**: Synchronize shared user profile data from MPSYS to destination systems (Yahoo, MPSLDAP, G2LDAP, HaloC, CCR) via SOAP
- **Validate & Sync G2**: Validate and activate Uverse BAN data in the G2 system
- **Reprovision Uverse**: Disconnect and re-provision a user's Uverse profile data via SOAP ReconnectWrapper
- **Unified TOS Management**: Query and update Terms of Service acceptance flags across the MPSYS system
- **Pre-Account Registration**: Store SOR ID, SOR invariant ID, and accessId GUID for deferred account setup
- **Auto-Generate Temp Access ID**: Create temporary access identifiers for pre-registration flows
- **Query By IP Eligibility**: Query G2 by IP address to retrieve Uverse BAN eligibility
- **Verify Existing Member Eligibility**: Check whether an existing member is eligible for registration with a given BAN
- **Email App Password**: List email application passwords for a member
- **External Event Publishing**: Publish registration and profile events to Azure Event Hub via Kafka (Spring Cloud Stream)
- **MQ Event Publishing**: Send DBUS events to IBM MQ for downstream legacy processing

This component uses JAX-RS (Jersey) for REST APIs, Spring WS + JAXB for SOAP integrations, IBM MQ (JMS) for legacy messaging, and Spring Cloud Stream (Kafka) for Event Hub publishing.

---

## Architecture

```mermaid
graph TD
    subgraph EntryPoints["Inbound Callers"]
        IDP["IDP Platform"]
        DATAMGT["DATAMGT"]
        ATLAS["ATLAS-UI"]
        OPUS["OPUS"]
        OCE["OCE"]
        CCMULE["CCMULE"]
    end

    subgraph URM["IDGraphUserRegistrationMs"]
        subgraph Interface_Layer["Interface Layer (JAX-RS Resources)"]
            LsReg["LsRegResource"]
            AutoReg["AutoRegResource"]
            SyncProfile["SyncUserProfileResource"]
            TOS["UnifiedTOSResource"]
            QAR["RetriggerQARResource"]
            WirelessAR["WirelessAutoRegResource"]
            EmailPwd["EmailAppPasswordResource"]
        end

        subgraph Service_Layer["Service Layer"]
            SvcImpl["*ServiceImpl classes"]
        end

        subgraph Validator_Layer["Validator Layer"]
            Validators["*RequestValidator classes"]
        end

        subgraph Helper_Layer["Helper / Business Logic"]
            Helpers["*Helper classes"]
            DBHelpers["*DBHelper classes"]
            VoltageHelpers["Voltage encrypt/decrypt"]
            SyncOps["SyncOperation / HaloSyncOperation"]
        end

        subgraph Client_Layer["Client Layer"]
            SoapHandlers["SOAP Handlers (MPS, CSI, G2)"]
            RestClient["MPSYSInternalRestClient"]
            CLMClient["CLMRestClient"]
            QueueSender["JMSQueueSender"]
            EventPublisher["PublishEventHelper"]
        end
    end

    subgraph Downstream["Downstream Dependencies"]
        OracleDB[("Oracle DB (MPSYS)")]
        MPS_SOAP["MPS SOAP (RegisterUser, SyncDestination, ReconnectWrapper)"]
        CSI_SOAP["CSI SOAP (InquireAccountProfile)"]
        G2_SOAP["G2 SOAP (GetBANByIP, G2MPSPort, G2MPSDSLPort)"]
        IDG_UM["IDGraph UserManagementMs"]
        IDG_UA["IDGraph UserAssociationMs"]
        IDG_UP["IDGraph UserProfileMs"]
        OG["OrderGraph"]
        CG["CustomerGraph"]
        HaloC["HaloC Identity Services"]
        CLM["CLM / MuleSoft"]
        MQ["IBM MQ (DBUS)"]
        EventHub["Azure Event Hub (Kafka)"]
    end

    EntryPoints --> Interface_Layer
    Interface_Layer --> Validator_Layer
    Validator_Layer --> Service_Layer
    Service_Layer --> Helper_Layer
    Helper_Layer --> Client_Layer
    Helper_Layer --> OracleDB
    SoapHandlers --> MPS_SOAP
    SoapHandlers --> CSI_SOAP
    SoapHandlers --> G2_SOAP
    RestClient --> IDG_UM
    RestClient --> IDG_UA
    RestClient --> IDG_UP
    RestClient --> OG
    CLMClient --> CLM
    QueueSender --> MQ
    EventPublisher --> EventHub
```

**Key Architectural Patterns:**
- **JAX-RS Interface + Impl Split**: Resource interfaces define contracts; `*ResourceImpl` classes implement them
- **Layered Architecture**: Resource → Validator → Service → ServiceImpl → Helper → DBHelper/Client
- **SOAP Client Abstraction**: `BaseSoapHandler` with service-specific subclasses for MPS, CSI
- **Sync Operation Factory**: `SyncOperationFactory` selects `SyncOperation`, `G2SyncOperation`, or `HaloSyncOperation` by destination
- **JMS Queue Helpers**: Domain-specific queue helpers (`RetriggerQARQueueHelper`, `WirelessAutoRegQueueHelper`, etc.) for MQ publishing
- **Azure App Configuration**: Dynamic config refresh via `IDGraphAzureAppConfig` with `@RefreshScope` support
- **CommonErrorMap**: All error responses use `CommonErrorMap` + `CErrorDefs` (IDGraph hard-stop HS-1)

---

## Project Structure

```
apm0045194-idgraph-idgraphuserregistrationms/
├── pom.xml                                         # Maven build (sdk-java-parent 3.0.0)
├── Jenkinsfile                                     # CI/CD pipeline (idp-shared-library 3.0.0)
├── idpsecretsloader.yaml                           # Key Vault secrets loader config
├── CODEOWNERS                                      # Code ownership
├── sum_junit_tests.sh                              # Test summary script
├── docs/
│   └── SPTAUTHREG-34640/                           # Execution plan docs
│       └── assets/
│           ├── wiki/
│           └── work-item/
├── opt/ajsc/etc/config/                            # Runtime configuration
│   ├── application.properties                      # Core application config
│   ├── userRegistration.properties                 # Business-specific properties
│   ├── userRegistrationCredentials.properties      # Encrypted credentials
│   ├── bootstrap.properties                        # Spring Boot bootstrap
│   ├── security-filter-config.yaml                 # Security filter rules
│   ├── cadi.properties                             # CADI/AAF config
│   ├── application-voltage-config.properties       # Voltage encryption config
│   ├── masking.properties                          # Log masking rules
│   ├── custom-mdc-headers.properties               # MDC header mapping
│   ├── AAFUserRoles.properties                     # AAF role definitions
│   ├── system.properties                           # System-level settings
│   ├── CommonConfiguration.xml                     # Common bean config
│   ├── CommonConfigurationTest.xml                 # Test bean config
│   ├── logback.xml                                 # Logback root config
│   ├── logback-custom.properties                   # Custom log levels
│   ├── logback/baselogback.xml                     # Base logback config
│   ├── audit4j.conf.yaml                           # Audit config
│   ├── guide-file.yaml                             # Secrets guide file
│   └── keys/                                       # Secret key placeholders
├── src/
│   ├── main/
│   │   ├── docker/
│   │   │   ├── Dockerfile                          # Container image definition
│   │   │   └── startService.sh                     # Container entrypoint
│   │   ├── java/com/att/idp/
│   │   │   ├── idgraph/commons/                    # Shared commons (CLM client, models)
│   │   │   │   ├── integration/
│   │   │   │   │   ├── CLMRestClient.java          # CLM/MuleSoft REST client
│   │   │   │   │   └── model/                      # CLM request/response models
│   │   │   │   └── utils/
│   │   │   │       └── DateUtil.java
│   │   │   └── idgraphuserregistrationms/
│   │   │       ├── Application.java                # Spring Boot entry point
│   │   │       ├── appconfig/config/               # Azure App Configuration
│   │   │       │   ├── IDGraphAzureAppConfig.java  # Dynamic config properties
│   │   │       │   ├── ConfigChangeEventListener.java
│   │   │       │   ├── ScheduledTaskConfiguration.java
│   │   │       │   └── SchedulerConfig.java
│   │   │       ├── client/                         # SOAP client handlers
│   │   │       │   ├── BaseSoapHandler.java        # Base SOAP handler
│   │   │       │   ├── CSIIAPSoapHandler.java      # CSI InquireAccountProfile
│   │   │       │   ├── MPSReconnectWrapperSoapHandler.java
│   │   │       │   ├── MPSRegisterUserSoapHandler.java
│   │   │       │   ├── MPSSyncDestinationSoapHandler.java
│   │   │       │   └── csi/                        # CSI request builders
│   │   │       ├── config/                         # Spring configuration
│   │   │       │   ├── BeanConfiguration.java
│   │   │       │   ├── JerseyConfiguration.java    # JAX-RS resource registration
│   │   │       │   ├── DataBaseConfiguration.java  # Oracle XA datasource
│   │   │       │   ├── JMSConfiguration.java       # IBM MQ connection factory
│   │   │       │   ├── CSISoapConfig.java          # CSI SOAP config
│   │   │       │   ├── MPSSOAPConfig.java          # MPS SOAP config
│   │   │       │   ├── CacheConfiguration.java
│   │   │       │   ├── TransactionConfiguration.java
│   │   │       │   └── ManagedShutdownConfiguration.java
│   │   │       ├── db/healthcheck/
│   │   │       │   └── DatabaseHealthIndicator.java
│   │   │       ├── exceptions/                     # Exception mappers
│   │   │       │   ├── InvalidInputDataException.java
│   │   │       │   ├── InvalidInputDataExceptionMapper.java
│   │   │       │   ├── MPSException.java
│   │   │       │   ├── MPSExceptionMapper.java
│   │   │       │   └── ValidationExceptionMapper.java
│   │   │       ├── healthcheck/
│   │   │       │   └── JMHealthCheckIndicator.java # JMS health check
│   │   │       ├── helper/                         # Business logic helpers
│   │   │       │   ├── WirelessAutoRegHelper.java
│   │   │       │   ├── VerifyExistingMemberEligibilityHelper.java
│   │   │       │   ├── RetriggerQARHelper.java
│   │   │       │   ├── ValidateAndSyncG2Helper.java
│   │   │       │   ├── SyncUserProfileHelper.java
│   │   │       │   ├── HaloSyncOperation.java
│   │   │       │   ├── SyncOperation.java
│   │   │       │   ├── G2SyncOperation.java
│   │   │       │   ├── SyncOperationFactory.java
│   │   │       │   ├── ConsolidatedProfileHelper.java
│   │   │       │   ├── QueryProfileProofingInfoHelper.java
│   │   │       │   ├── QueryUnifiedTOSHelper.java
│   │   │       │   ├── UpdateUnifiedTOSHelper.java
│   │   │       │   ├── RegisterLSUserHelper.java
│   │   │       │   ├── PreAccountRegHelper.java
│   │   │       │   ├── AutoGenTempAIDHelper.java
│   │   │       │   ├── QueryByIPEligibilityHelper.java
│   │   │       │   ├── ReprovisionUverseHelper.java
│   │   │       │   ├── G2GetBANByIPHelper.java
│   │   │       │   ├── G2LDAPHelper.java
│   │   │       │   ├── LDAPValidator.java
│   │   │       │   ├── LockoutHelper.java
│   │   │       │   ├── HaloSyncHelper.java
│   │   │       │   ├── SyncCCRHelper.java
│   │   │       │   ├── ExternalDestinationHelper.java
│   │   │       │   ├── UserProfileAutoregUtility.java
│   │   │       │   ├── LockOutValidation.java
│   │   │       │   ├── MPSLockOutHelper.java
│   │   │       │   ├── MbrAttributes.java
│   │   │       │   ├── dbhelpers/                  # Oracle DB access helpers (17 classes)
│   │   │       │   └── voltage/                    # Voltage encryption helpers (6 classes)
│   │   │       ├── integration/
│   │   │       │   └── MPSYSInternalRestClient.java # IDGraph MS-to-MS REST client
│   │   │       ├── message/                        # Error/log message constants
│   │   │       ├── model/
│   │   │       │   └── ErrorMessage.java
│   │   │       ├── queue/message/                  # JMS queue helpers
│   │   │       │   ├── helpers/                    # Domain queue helpers (5 classes)
│   │   │       │   └── sender/
│   │   │       │       └── JMSQueueSender.java     # IBM MQ sender
│   │   │       ├── request/validator/              # Request validators (13 classes)
│   │   │       ├── resource/                       # JAX-RS resource interfaces (8)
│   │   │       │   ├── impl/                       # Resource implementations (8)
│   │   │       │   ├── request/                    # Request DTOs (14)
│   │   │       │   └── response/                   # Response DTOs (12)
│   │   │       ├── service/                        # Service interfaces (13)
│   │   │       │   └── impl/                       # Service implementations (13)
│   │   │       └── utils/                          # Utility classes
│   │   │           ├── CommonUtilHelper.java       # Shared utilities
│   │   │           ├── JsonService.java            # JSON serialization
│   │   │           ├── ProfileOrchestrationConstants.java
│   │   │           ├── RILCheckAndEncryptPasswordHelper.java
│   │   │           └── UnifiedTOSUtilHelper.java
│   │   ├── jenkins/
│   │   │   └── versioning.groovy                   # Jenkins versioning script
│   │   └── resources/
│   │       ├── banner.txt                          # Spring Boot banner
│   │       ├── errormessages.properties            # Error message definitions
│   │       ├── logmessages.properties              # Log message definitions
│   │       ├── bindings/                           # JAXB binding customizations
│   │       │   ├── registerUser.xjb
│   │       │   ├── reconnectWrapper.xjb
│   │       │   └── syncDestination.xjb
│   │       ├── schemas/
│   │       │   ├── csi/                            # CSI WSDL/XSD (9 files)
│   │       │   └── mpsys/                          # MPS WSDL/XSD
│   │       │       ├── registerUser/               # RegisterUser WSDL (4 files)
│   │       │       ├── reconnectWrapper/           # ReconnectWrapper WSDL (4 files)
│   │       │       └── syncDestination/            # SyncDestination WSDL (4 files)
│   │       └── META-INF/resources/
│   │           └── idgraphuserregistrationms/swagger/  # Swagger UI assets
│   └── test/
│       ├── groovy/com/att/idp/                     # Spock test suites
│       │   ├── component/                          # Component tests (16 classes)
│       │   ├── integration/                        # Integration tests (2 classes)
│       │   ├── message/                            # Message tests (2 classes)
│       │   ├── idgraph/commons/integration/        # CLM client tests (2 classes)
│       │   └── idgraphuserregistrationms/          # Unit tests
│       │       ├── client/                         # SOAP handler tests (4 classes)
│       │       ├── helper/                         # Helper tests (26 classes)
│       │       │   ├── dbhelpers/                  # DB helper tests (16 classes)
│       │       │   └── voltage/                    # Voltage tests (4 classes)
│       │       ├── queue/message/                  # Queue tests (6 classes)
│       │       ├── request/validator/              # Validator tests (14 classes)
│       │       ├── resource/impl/                  # Resource impl tests (8 classes)
│       │       └── service/impl/                   # Service impl tests (13 classes)
│       ├── ist/cadevtest/                          # CA DevTest IST tests
│       └── resources/
│           ├── application-test.properties         # Test configuration
│           ├── testmessages.properties             # Test message definitions
│           └── mockResponse/                       # Mock JSON responses (14 files)
└── .github/
    └── copilot-instructions.md                     # AI assistant instructions
```

---

## Domain Capability Map

| Capability | Description | Primary Interfaces |
|------------|-------------|-------------------|
| **LS User Registration** | Register new LightStream users via MPS SOAP backend | `POST /lsreg/registerUser` |
| **Wireless Auto-Registration** | Full wireless account auto-reg with LDAP, HaloC, G2, MQ events | `POST /orchestration/wireless` |
| **QAR Retrigger** | Resend Quick Account Review email/SMS notifications | `POST /account/qar/retrigger` |
| **User Profile Sync** | Sync profile data from MPSYS to destination systems | `POST /userprofile/sync` |
| **Validate & Sync G2** | Validate and activate Uverse BAN in G2 | `POST /userprofile/activate/uban` |
| **Reprovision Uverse** | Disconnect and re-provision Uverse profile | `POST /userprofile/reprovision/uban` |
| **Query Unified TOS** | Query Terms of Service acceptance flags | `POST /unifiedTOS/query` |
| **Update Unified TOS** | Update Terms of Service acceptance flags | `POST /unifiedTOS/update` |
| **Pre-Account Registration** | Store SOR/accessId data for deferred account setup | `POST /autoreg/preAccountReg` |
| **Auto-Generate Temp Access ID** | Generate temporary access identifiers | `POST /autoreg/tempAccessId` |
| **Query By IP Eligibility** | Query G2 by IP address for Uverse BAN | `POST /lsreg/queryByIPEligibility` |
| **Verify Member Eligibility** | Verify existing member eligibility with BAN | `POST /lsreg/verifyExistingMemberEligibility` |
| **Email App Password** | List email application passwords | `GET /emailapppassword` |
| **External Event Publishing** | Publish events to Azure Event Hub | Internal (via `PublishEventHelper`) |
| **MQ Event Publishing** | Publish DBUS events to IBM MQ | Internal (via `JMSQueueSender`) |

---

## Integration Context

| Interface / Dependency | Direction | Type | Purpose | Notes |
|------------------------|-----------|------|---------|-------|
| IDP, DATAMGT, ATLAS-UI, OPUS, OCE, CCMULE, etc. | Inbound | REST | API callers identified by `X-ATT-ClientId` header | Per-operation allowed calling system IDs |
| **IDGraph UserManagementMs** | Outbound | REST | CheckUserIdAvailability, AddUser | Via `MPSYSInternalRestClient` |
| **IDGraph UserAssociationMs** | Outbound | REST | AddAssociation | Via `MPSYSInternalRestClient` |
| **IDGraph UserProfileMs** | Outbound | REST | InquireProfile, InquireAssociatedAccessIds | Via `MPSYSInternalRestClient` |
| **OrderGraph** | Outbound | REST (GraphQL) | OrderGraph search | Via `MPSYSInternalRestClient` |
| **CustomerGraph** | Outbound | REST | Customer search / Secure Account Profile | Via `CGClientHelpers` library |
| **HaloC Identity Services** | Outbound | REST | Identity sync operations | Via `idgraphextclienthelpers` library |
| **CLM / MuleSoft** | Outbound | REST | QAR email/SMS notifications | Via `CLMRestClient` with retry |
| **MPS SOAP** | Outbound | SOAP | RegisterUser, SyncDestination, ReconnectWrapper | Via `BaseSoapHandler` subclasses |
| **CSI SOAP** | Outbound | SOAP | InquireAccountProfile | Via `CSIIAPSoapHandler` |
| **G2 SOAP** | Outbound | SOAP | GetBANByIP, G2MPSPort, G2MPSDSLPort | Via `idgraphextclienthelpers` + direct SOAP |
| **Oracle DB (MPSYS)** | Outbound | JDBC/JPA | Member data, services, lockouts, account info | Via 17 `*DBHelper` classes |
| **IBM MQ (DBUS)** | Outbound | JMS | Legacy event publishing | Via `JMSQueueSender` |
| **Azure Event Hub** | Outbound | Kafka | External event notifications | Via Spring Cloud Stream binder |
| **Azure App Configuration** | Inbound | Config | Dynamic runtime configuration refresh | Via `spring-cloud-azure-appconfiguration-config-web` |
| **Azure Key Vault** | Startup | Secrets | Secret loading before Spring context | Via `idpsecretsloader.yaml` |

---

## Process Flows

### 1. Wireless Auto-Registration

```mermaid
sequenceDiagram
    participant Caller as Inbound Caller
    participant Resource as WirelessAutoRegResource
    participant Validator as WirelessAutoRegRequestValidator
    participant Service as WirelessAutoRegServiceImpl
    participant Helper as WirelessAutoRegHelper
    participant DB as Oracle DB (MPSYS)
    participant IDG as IDGraph MS (UM/UA/UP)
    participant HaloC as HaloC
    participant G2 as G2 SOAP
    participant MQ as IBM MQ

    Caller->>Resource: POST /orchestration/wireless
    Resource->>Validator: validate request
    Validator->>Service: invoke service
    Service->>Helper: processWirelessAutoReg()
    Helper->>DB: query member data
    Helper->>IDG: CheckUserIdAvailability / AddUser / AddAssociation
    Helper->>HaloC: sync identity (via extclienthelpers)
    Helper->>G2: sync G2 LDAP
    Helper->>MQ: publish DBUS event
    Helper-->>Service: result
    Service-->>Resource: WirelessAutoRegResponse
```

| Input | Output |
|-------|--------|
| `WirelessAutoRegRequest` (BAN, accessId, SOR, services) | `WirelessAutoRegResponse` with registration result |

> **Code Reference**: `WirelessAutoRegResourceImpl.wirelessAutoReg()` → `WirelessAutoRegServiceImpl` → `WirelessAutoRegHelper`

### 2. User Profile Sync

```mermaid
sequenceDiagram
    participant Caller as Inbound Caller
    participant Resource as SyncUserProfileResource
    participant Service as SyncUserProfileServiceImpl
    participant Helper as SyncUserProfileHelper
    participant Factory as SyncOperationFactory
    participant SyncOp as SyncOperation / HaloSyncOperation
    participant SOAP as MPS SOAP (SyncDestination)
    participant DB as Oracle DB

    Caller->>Resource: POST /userprofile/sync
    Resource->>Service: invoke
    Service->>Helper: syncUserProfile()
    Helper->>Factory: getSyncOperation(destination)
    Factory-->>Helper: SyncOperation instance
    Helper->>SyncOp: execute sync
    SyncOp->>DB: query member services
    SyncOp->>SOAP: SyncDestination SOAP call
    SyncOp-->>Helper: sync result
    Helper-->>Resource: SyncUserProfileResponse
```

| Input | Output |
|-------|--------|
| `SyncUserProfileRequest` (accessId, destination, BAN) | `SyncUserProfileResponse` with sync status |

> **Code Reference**: `SyncUserProfileResourceImpl.syncUserProfile()` → `SyncUserProfileServiceImpl` → `SyncUserProfileHelper` → `SyncOperationFactory`

### 3. QAR Retrigger

```mermaid
sequenceDiagram
    participant Caller as Inbound Caller
    participant Resource as RetriggerQARResource
    participant Service as RetriggerQARServiceImpl
    participant Helper as RetriggerQARHelper
    participant DB as Oracle DB
    participant CLM as CLM / MuleSoft
    participant MQ as IBM MQ
    participant EventHub as Azure Event Hub

    Caller->>Resource: POST /account/qar/retrigger
    Resource->>Service: invoke
    Service->>Helper: retriggerQAR()
    Helper->>DB: query account info, member services
    Helper->>CLM: send notification (with retry)
    Helper->>MQ: publish DBUS event
    Helper->>EventHub: publish external event
    Helper-->>Resource: RetriggerQARResponse
```

| Input | Output |
|-------|--------|
| `RetriggerQARRequest` (BAN, accountType, deliveryMethod) | `RetriggerQARResponse` with QAR URL and status |

> **Code Reference**: `RetriggerQARResourceImpl.retriggerQAR()` → `RetriggerQARServiceImpl` → `RetriggerQARHelper` → `RetriggerQARQueueHelper` + `PublishEventHelper`

---

## Interfaces & Endpoints

### REST Endpoints

All endpoints are under base path `/msapi/idgraphuserregistrationms/v1`. Required header: `X-ATT-ClientId`.

| # | Tag | Method | Path | Description | Code Reference |
|---|-----|--------|------|-------------|----------------|
| 1 | `lsreg` | `POST` | `/lsreg/queryByIPEligibility` | Query G2 by IP for Uverse BAN | `LsRegResourceImpl.queryByIPEligibility()` |
| 2 | `lsreg` | `POST` | `/lsreg/verifyExistingMemberEligibility` | Verify member eligibility with BAN | `LsRegResourceImpl.verifyExistingMemberEligibility()` |
| 3 | `lsreg` | `POST` | `/lsreg/registerUser` | Register new LS user via MPS SOAP | `LsRegResourceImpl.registerLSUser()` |
| 4 | `autoreg` | `POST` | `/autoreg/tempAccessId` | Auto-generate temporary access ID | `AutoRegResourceImpl.autogenTempAccessId()` |
| 5 | `autoreg` | `POST` | `/autoreg/preAccountReg` | Store SOR/accessId for deferred setup | `AutoRegResourceImpl.preAccountReg()` |
| 6 | `userprofile` | `POST` | `/userprofile/sync` | Sync user profile to destination | `SyncUserProfileResourceImpl.syncUserProfile()` |
| 7 | `userprofile` | `POST` | `/userprofile/activate/uban` | Validate and sync G2 | `SyncUserProfileResourceImpl.validateAndSyncG2()` |
| 8 | `userprofile` | `POST` | `/userprofile/reprovision/uban` | Reprovision Uverse | `SyncUserProfileResourceImpl.reprovisionUverse()` |
| 9 | `unifiedTOS` | `POST` | `/unifiedTOS/query` | Query Unified TOS flags | `UnifiedTOSResourceImpl.queryUnifiedTos()` |
| 10 | `unifiedTOS` | `POST` | `/unifiedTOS/update` | Update Unified TOS flags | `UnifiedTOSResourceImpl.updateUnifiedTos()` |
| 11 | `qar` | `POST` | `/account/qar/retrigger` | Retrigger QAR email/SMS | `RetriggerQARResourceImpl.retriggerQAR()` |
| 12 | `orchestration` | `POST` | `/orchestration/wireless` | Wireless auto-registration | `WirelessAutoRegResourceImpl.wirelessAutoReg()` |
| 13 | `emailapppassword` | `GET` | `/emailapppassword` | List email app passwords | `EmailAppPasswordResourceImpl.listEmailAppPassword()` |
| 14 | `helloworld` | `POST` | `/helloworld/getHelloWorld` | Health check endpoint | `HelloWorldResourceImpl.getHelloWorld()` |

### Downstream Service Integrations

| # | Dependency | Protocol | Backend Resource Endpoint URL | Purpose | Code Reference |
|---|------------|----------|-------------------------------|---------|----------------|
| 1 | IDGraph UserManagementMs | REST | `/msapi/idgraph/idgraphusermanagementms/v1/user/checkUserIdAvailability` | Check user ID availability | `MPSYSInternalRestClient` |
| 2 | IDGraph UserManagementMs | REST | `/msapi/idgraph/idgraphusermanagementms/v1/user/add` | Add user | `MPSYSInternalRestClient` |
| 3 | IDGraph UserAssociationMs | REST | `/msapi/idgraph/idgraphuserassociationms/v1/association/add` | Add association | `MPSYSInternalRestClient` |
| 4 | IDGraph UserProfileMs | REST | `/msapi/idgraph/idgraphuserprofilems/v1/user/inquireDetails` | Inquire profile | `MPSYSInternalRestClient` |
| 5 | IDGraph UserProfileMs | REST | `/msapi/idgraph/idgraphuserprofilems/v1/user/inquireAssociatedAccessIds` | Inquire associated access IDs | `MPSYSInternalRestClient` |
| 6 | OrderGraph | REST | `/msapi/ordergraphsearch/v1/graphql` | GraphQL order queries | `MPSYSInternalRestClient` |
| 7 | CustomerGraph | REST | `/msapi/cgraph/customergraphorchestrationms/v2/customer` | Customer search | `CGClientHelpers` |
| 8 | CLM / MuleSoft | REST | `/api/v1.0/msgasyncevents` | CLM notifications | `CLMRestClient` |
| 9 | MPS RegisterUser | SOAP | `LSRegRILMPSWeb/LSRegRILService` | Register LS user | `MPSRegisterUserSoapHandler` |
| 10 | MPS SyncDestination | SOAP | `SyncDestinationRILMPSWeb/SyncDestinationRILService` | Sync user profile | `MPSSyncDestinationSoapHandler` |
| 11 | MPS ReconnectWrapper | SOAP | `ReconnectWrapperRILMPSWeb/ReconnectWrapperRILService` | Reprovision Uverse | `MPSReconnectWrapperSoapHandler` |
| 12 | CSI | SOAP | InquireAccountProfile endpoint | Account profile inquiry | `CSIIAPSoapHandler` |
| 13 | G2 | SOAP | G2MPSPort / G2MPSDSLPort | BAN lookup, DSL provisioning | `idgraphextclienthelpers` |
| 14 | HaloC | REST | `/identity-services/v1/auth/identity` | Identity sync | `idgraphextclienthelpers` |

---

## Data Stores & State Management

| Store / State | Type | Purpose | Access Pattern | Notes |
|---------------|------|---------|----------------|-------|
| Oracle DB (MPSYS) | DB | Member data, services, roles, lockouts, account info, TOS flags | `*DBHelper` classes via JPA/JdbcTemplate | LDAP-resolved connection, AES-encrypted password |
| IBM MQ (DBUS) | Queue | Legacy downstream event delivery | `JMSQueueSender` via Spring JMS | Failover host configuration |
| Azure Event Hub | Event Stream | External event notifications | `PublishEventHelper` via Spring Cloud Stream (Kafka) | Primary + secondary binder configuration |
| Spring Cache | In-memory | Caching for performance | `@EnableCaching` / `CacheConfiguration` | Caffeine-based |

---

## Configuration

| Setting Group | File / Source | Purpose |
|---------------|---------------|---------|
| **Application Properties** | `opt/ajsc/etc/config/application.properties` | Core runtime config (datasource, REST clients, SOAP, Kafka, health checks) |
| **Business Properties** | `opt/ajsc/etc/config/userRegistration.properties` | Per-operation calling system IDs, voltage fields, SOR lists, service rules |
| **Credentials** | `opt/ajsc/etc/config/userRegistrationCredentials.properties` | Encrypted DB/SOAP credentials (loaded from secrets) |
| **Voltage Config** | `opt/ajsc/etc/config/application-voltage-config.properties` | Voltage encryption/decryption settings |
| **Security Filter** | `opt/ajsc/etc/config/security-filter-config.yaml` | URL security filter rules |
| **AAF Roles** | `opt/ajsc/etc/config/AAFUserRoles.properties` | AAF role definitions |
| **Masking** | `opt/ajsc/etc/config/masking.properties` | Log field masking rules |
| **MDC Headers** | `opt/ajsc/etc/config/custom-mdc-headers.properties` | Custom MDC header mappings |
| **CADI** | `opt/ajsc/etc/config/cadi.properties` | CADI authentication config |
| **Feature Flags** | Azure App Configuration | Dynamic config via `IDGraphAzureAppConfig` with `@RefreshScope` |
| **Secrets** | Azure Key Vault via `idpsecretsloader.yaml` | Secrets loaded before Spring context startup |

---

## Dependencies

### Runtime / Parent

| Dependency | Version | Purpose |
|------------|---------|---------|
| `sdk-java-parent` | `3.0.0` | IDP Seed parent POM |
| `idp-seed-sdk-core` | Managed | Core seed SDK |

### Key Dependencies

| Dependency | Version | Purpose |
|------------|---------|---------|
| `IDGraphCommonHelper` | `1.0.1` | IDGraph shared utilities (`CommonErrorMap`, `CErrorDefs`, `CommonDefs`) |
| `CGClientHelpers` | `1.2.0-SNAPSHOT` | CustomerGraph client helpers |
| `idgraphextclienthelpers` | `3.0.8` | External client helpers (HaloC, G2, LSCRM) |
| `IDGraphStaticHelper` | `0.0.1-SNAPSHOT` | Static data helper |
| `idgrapheventshelper` | `4.0.2` | Event Hub publishing helper |
| `rest-api-client` | `3.0.204-SNAPSHOT` | IDP REST client framework |
| `soap-api-client` | Managed | IDP SOAP client framework |
| `idp-voltage-encrypt` | Managed | Voltage SPI/PII encryption |
| `idp-voltage-decrypt` | Managed | Voltage SPI/PII decryption |
| `idp-aaf` | Managed | AAF authentication |
| `idp-shutdown-jersey` | Managed | Jersey graceful shutdown |
| `idp-config` | Managed | IDP configuration framework |
| `spring-cloud-azure-appconfiguration-config-web` | `5.18.0` | Azure App Configuration integration |
| `ojdbc8` | `19.8.0.0` | Oracle JDBC driver |
| `com.ibm.mq.jakarta.client` | `9.4.2.1` | IBM MQ Jakarta JMS client |
| `HikariCP` | `6.3.0` | Connection pooling |
| `spock-core` | `2.3-groovy-4.0` | Spock testing framework |
| `springdoc-openapi-starter-webmvc-ui` | Managed | OpenAPI / Swagger UI |
| `lombok` | `1.18.32` | Boilerplate reduction |

---

## Observability and Operations

| Area | Mechanism | Notes |
|------|-----------|-------|
| **Logging** | SLF4J / Logback (`logback/baselogback.xml`) | Structured logging with ESAPI sanitization |
| **MDC Context** | `idpctx-uuid`, `idpctx-customerstate`, `idpctx-callcontext`, `idpctx-loggedinid`, `idpctx-logintype`, `x-att-clientid`, `x-b3-traceid` | Mandatory MDC headers |
| **Log Masking** | `masking.properties` | Sensitive field masking in logs |
| **Health Checks** | Spring Boot Actuator | DB health (`management.health.db.enabled=true`), JMS health (`management.health.jms.enabled=true`), disk space |
| **Readiness** | Actuator readiness endpoint | AAF readiness check enabled |
| **Metrics** | Spring Boot Actuator (`management.endpoints.web.exposure.include=*`) | All actuator endpoints exposed |
| **Tracing** | `x-b3-traceid`, `idp-trace-id` | Distributed tracing correlation |
| **Operational Tasks** | `JMHealthCheckIndicator`, `DatabaseHealthIndicator` | Custom health indicators for JMS and DB connectivity |

---

## Security and Compliance

| Area | Approach | Notes |
|------|----------|-------|
| **Authentication / Authorization** | AAF (disabled in dev: `idp.aaf.enabled=false`) | CADI-based auth with role definitions in `AAFUserRoles.properties` |
| **XSS Protection** | IDP XSS filter (`idp.xss.filter.enabled=true`) | Enabled globally |
| **Sensitive Data Handling** | Voltage encryption/decryption for SPI/PII fields | Passcode, SSN, DOB, security answers, CBR encrypted via Voltage |
| **Secrets Management** | Azure Key Vault via `idpsecretsloader.yaml` | Secrets loaded before Spring context; references via `${idp-secrets-v1:...}` |
| **Input Validation** | 13 dedicated `*RequestValidator` classes | Per-endpoint validation with calling system ID allowlists |
| **Error Responses** | `CommonErrorMap` + `CErrorDefs` | Standardized error codes (IDGraph hard-stop HS-1) |
| **Log Sanitization** | ESAPI sanitization | No raw external values in logs (IDGraph hard-stop HS-3) |
| **DB Password Encryption** | AES-256 encrypted DB password | Decrypted at runtime via `CommonUtilHelper.getAESDecryption()` |
| **SOAP Security** | WS-Security headers for CSI/MPS | Username/password tokens in SOAP envelope |
| **Compliance** | PII/SPI encryption, audit logging | Voltage-encrypted fields for passcode, SSN, DOB, security answers |

---

## Build and Test

### Build

```bash
mvn clean install
```

### Run Tests

```bash
# Unit tests only (default profile)
mvn test

# Integration tests
mvn verify -P integration-test

# Component tests
mvn test -Dtest="*CompTest"
```

### Profiles

| Profile | Description |
|---------|-------------|
| `local` | Default profile — runs unit tests, skips integration tests |
| `integration-test` | Skips unit tests, runs integration tests |
| `azure` | Adds `idp-spring-boot-autoconfigure` dependency for Azure deployment |

### Code Coverage

- **Coverage Report**: `target/site/jacoco/index.html`
- **Quality Dashboard**: Veracode profile `33944-IDGraph-IDGraphUserRegistrationMs`
- **JAXB Code Generation**: SOAP models auto-generated from WSDL/XSD in `src/main/resources/schemas/`

### Test Structure

| Type | Location | Framework | Count |
|------|----------|-----------|-------|
| Unit tests | `src/test/groovy/.../idgraphuserregistrationms/` | Spock 2.3 | ~91 classes |
| Component tests | `src/test/groovy/.../component/` | Spock 2.3 | 16 classes |
| Integration tests | `src/test/groovy/.../integration/` | Spock 2.3 | 2 classes |
| IST tests | `src/test/ist/cadevtest/` | CA DevTest | Legacy |

---

## Deployment

### Build Artifact / Image

```bash
# Docker image build
docker build -f src/main/docker/Dockerfile -t idgraphuserregistrationms .
```

### Pipeline

- **Jenkinsfile**: Uses `idp-shared-library@release/3.0.0` with `pl_idp_ms` pipeline
- **Default Cluster**: `Graph1EUS2-dev2` / `com-att-idp-idgraph-dev2`
- **Veracode**: Profile `33944-IDGraph-IDGraphUserRegistrationMs` (CRED_ID override enabled)
- **Skipped QGs**: `QG4.1`, `QG4.2`, `QG7`
- **GitHub Migrated**: `true`

### Runtime Notes

| Area | Value |
|------|-------|
| **Deployment Target** | AKS (Kubernetes) — Helm chart in `apm0045194-idgraph-idgraphuserregistrationms-helm` |
| **Namespace** | `com-att-idp-idgraph` |
| **Service DNS** | `idgraphuserregistrationms.com-att-idp.svc.cluster.local` |
| **Tomcat Threads** | Max: 200, Min Spare: 25 |
| **Graceful Shutdown** | Jersey shutdown adapter with 45s wait timeout |
| **Config Sync** | Helm configs must sync with `opt/ajsc/etc/config/` (IDGraph hard-stop HS-7) |

---

## Change Log / History

| Ticket | Description |
|--------|-------------|
| **SPTAUTHREG-34640** | Current execution plan (see `docs/SPTAUTHREG-34640/`) |
| — | OMNI-standard README generation (v4.0.0) |
