# AGENTS.md — IDGraphUserRegistrationMs

> AI/developer orientation file for the IDGraph User Registration microservice.

## Repository Purpose

**IDGraphUserRegistrationMs** is a Java 17 / Spring Boot 3.x microservice in the IDGraph platform responsible for user registration, account activation, profile synchronization, and Terms of Service management within the MPSYS identity ecosystem.

It exposes 14 JAX-RS (Jersey) REST endpoints and integrates with Oracle DB, multiple SOAP backends (MPS, CSI, G2), IBM MQ (JMS), Azure Event Hub (Kafka), and several IDGraph sibling microservices via REST.

## Key Technical Facts

- **Parent POM**: `sdk-java-parent:3.0.0`
- **REST Framework**: JAX-RS (Jersey) — interface + impl split pattern
- **Base Path**: `/msapi/idgraphuserregistrationms/v1`
- **Package Root**: `com.att.idp.idgraphuserregistrationms`
- **Error Handling**: `CommonErrorMap` + `CErrorDefs` (IDGraph hard-stop HS-1)
- **Log Sanitization**: ESAPI required for all log statements (IDGraph hard-stop HS-3)
- **Secrets**: Azure Key Vault loaded before Spring context (IDGraph hard-stop HS-4)
- **Testing**: Spock 2.3 (Groovy 4.0) — unit, component, and integration tests
- **Build Gate**: `mvn clean install` (must pass before any phase completion)
- **Config Sync**: Changes to `opt/ajsc/etc/config/` must sync with Helm chart repo (IDGraph hard-stop HS-7)

## Layered Architecture

```
Resource (JAX-RS interface) → ResourceImpl → RequestValidator → Service (interface) → ServiceImpl → Helper → DBHelper / Client
```

## Project Directory Structure

```
apm0045194-idgraph-idgraphuserregistrationms/
├── pom.xml
├── Jenkinsfile
├── idpsecretsloader.yaml
├── CODEOWNERS
├── sum_junit_tests.sh
├── docs/
│   └── SPTAUTHREG-34640/
│       └── assets/
│           ├── wiki/
│           └── work-item/
├── opt/ajsc/etc/config/
│   ├── application.properties
│   ├── userRegistration.properties
│   ├── userRegistrationCredentials.properties
│   ├── bootstrap.properties
│   ├── security-filter-config.yaml
│   ├── cadi.properties
│   ├── application-voltage-config.properties
│   ├── masking.properties
│   ├── custom-mdc-headers.properties
│   ├── AAFUserRoles.properties
│   ├── system.properties
│   ├── CommonConfiguration.xml
│   ├── CommonConfigurationTest.xml
│   ├── logback.xml
│   ├── logback-custom.properties
│   ├── logback/baselogback.xml
│   ├── audit4j.conf.yaml
│   ├── guide-file.yaml
│   └── keys/
├── src/
│   ├── main/
│   │   ├── docker/
│   │   │   ├── Dockerfile
│   │   │   └── startService.sh
│   │   ├── java/com/att/idp/
│   │   │   ├── idgraph/commons/
│   │   │   │   ├── integration/
│   │   │   │   │   ├── CLMRestClient.java
│   │   │   │   │   └── model/ (7 classes)
│   │   │   │   └── utils/DateUtil.java
│   │   │   └── idgraphuserregistrationms/
│   │   │       ├── Application.java
│   │   │       ├── appconfig/config/ (5 classes)
│   │   │       ├── client/ (5 classes + csi/ 2 classes)
│   │   │       ├── config/ (9 classes)
│   │   │       ├── db/healthcheck/ (1 class)
│   │   │       ├── exceptions/ (5 classes)
│   │   │       ├── healthcheck/ (1 class)
│   │   │       ├── helper/ (29 classes)
│   │   │       │   ├── dbhelpers/ (17 classes)
│   │   │       │   └── voltage/ (6 classes)
│   │   │       ├── integration/ (1 class)
│   │   │       ├── message/ (3 classes)
│   │   │       ├── model/ (1 class)
│   │   │       ├── queue/message/
│   │   │       │   ├── helpers/ (5 classes)
│   │   │       │   └── sender/ (1 class)
│   │   │       ├── request/validator/ (13 classes)
│   │   │       ├── resource/ (8 interfaces)
│   │   │       │   ├── impl/ (8 classes)
│   │   │       │   ├── request/ (14 classes)
│   │   │       │   └── response/ (12 classes)
│   │   │       ├── service/ (13 interfaces)
│   │   │       │   └── impl/ (13 classes)
│   │   │       └── utils/ (5 classes)
│   │   ├── jenkins/versioning.groovy
│   │   └── resources/
│   │       ├── banner.txt
│   │       ├── errormessages.properties
│   │       ├── logmessages.properties
│   │       ├── bindings/ (3 xjb files)
│   │       ├── schemas/
│   │       │   ├── csi/ (9 files)
│   │       │   └── mpsys/
│   │       │       ├── registerUser/ (4 files)
│   │       │       ├── reconnectWrapper/ (4 files)
│   │       │       └── syncDestination/ (4 files)
│   │       └── META-INF/resources/idgraphuserregistrationms/swagger/
│   └── test/
│       ├── groovy/com/att/idp/
│       │   ├── component/ (16 classes)
│       │   ├── integration/ (2 classes)
│       │   ├── message/ (2 classes)
│       │   ├── idgraph/commons/integration/ (2 classes)
│       │   └── idgraphuserregistrationms/
│       │       ├── client/ (3 classes + csi/ 1 class)
│       │       ├── helper/ (26 classes)
│       │       │   ├── dbhelpers/ (16 classes)
│       │       │   └── voltage/ (4 classes)
│       │       ├── queue/message/ (6 classes)
│       │       ├── request/validator/ (14 classes)
│       │       ├── resource/impl/ (8 classes)
│       │       └── service/impl/ (13 classes)
│       ├── ist/cadevtest/ (CA DevTest IST)
│       └── resources/
│           ├── application-test.properties
│           ├── testmessages.properties
│           └── mockResponse/ (14 JSON files)
└── .github/copilot-instructions.md
```

## IDGraph Shared Libraries Used

| Library | Version | Package |
|---------|---------|---------|
| `IDGraphCommonHelper` | `1.0.1` | `com.att.mpsys.common.*` |
| `CGClientHelpers` | `1.2.0-SNAPSHOT` | CG client utilities |
| `idgraphextclienthelpers` | `3.0.8` | `com.att.idp.idgraph.extclient.*` |
| `IDGraphStaticHelper` | `0.0.1-SNAPSHOT` | Static data |
| `idgrapheventshelper` | `4.0.2` | Event Hub publishing |

## Critical Conventions

1. **Never remove existing code** without explicit approval (OMNI hard-stop)
2. **Use `CommonErrorMap` + `CErrorDefs`** for all error responses (HS-1)
3. **Reuse shared helpers** from IDGraph libraries before adding new code (HS-2)
4. **Sanitize logs via ESAPI** — no raw external values (HS-3)
5. **Key Vault secrets load before Spring context** — preserve startup sequence (HS-4)
6. **No wildcard imports** — all imports must be explicit (HS-6)
7. **Sync config across MS + Helm repos** for every config change (HS-7)
8. **`0 * _` mandatory** in every Spock `then:` block (HS-8)
9. **Execution plans commit to** `docs/{TICKET-ID}/` in component repo (HS-9)

## Downstream Dependencies Quick Reference

- **IDGraph MS (REST)**: UserManagement, UserAssociation, UserProfile → via `MPSYSInternalRestClient`
- **OrderGraph (REST/GraphQL)** → via `MPSYSInternalRestClient`
- **CustomerGraph (REST)** → via `CGClientHelpers`
- **HaloC (REST)** → via `idgraphextclienthelpers`
- **CLM/MuleSoft (REST)** → via `CLMRestClient` (with retry)
- **MPS (SOAP)**: RegisterUser, SyncDestination, ReconnectWrapper → via `*SoapHandler`
- **CSI (SOAP)**: InquireAccountProfile → via `CSIIAPSoapHandler`
- **G2 (SOAP)**: GetBANByIP, G2MPSPort, G2MPSDSLPort → via `idgraphextclienthelpers` + direct
- **Oracle DB (MPSYS)** → via 17 `*DBHelper` classes
- **IBM MQ** → via `JMSQueueSender`
- **Azure Event Hub (Kafka)** → via `PublishEventHelper` / Spring Cloud Stream
