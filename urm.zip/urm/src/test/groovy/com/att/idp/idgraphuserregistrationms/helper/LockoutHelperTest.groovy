package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.MemberLockoutDBHelper
import com.att.mpsys.common.utils.*
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Specification


class LockoutHelperTest extends Specification {

    LockOutValidation objLockOutValidation = Mock(LockOutValidation)

    MemberLockoutDBHelper oMPSDB_TMEMBERLOCKOUT_H = Mock(MemberLockoutDBHelper)

    def testObj = new LockoutHelper()

    Logger logger = null
    HashMap hmResult = null
    HashMap hmInput = null
    HashMap resultHashSuccess=null
    HashMap errResponse=null
    HashMap hmDBLockout = CommonUtil.hashMap
    HashMap hmDBLockout1 = CommonUtil.hashMap
    ArrayList alDBMemberLockout = CommonUtil.arrayList
    ArrayList alDBMemberLockout1 = CommonUtil.arrayList
    HashMap hmConfigLockoutValues = CommonUtil.hashMap


    def setup(){
        System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')
        testObj.objLockOutValidation = objLockOutValidation
        testObj.memberLockoutDBHelper = oMPSDB_TMEMBERLOCKOUT_H
        logger = LoggerFactory.getLogger('LockoutHelperTest')

        //System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')

        resultHashSuccess= CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG)
        errResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, CErrorDefs.COMMON_ERR_CATEGORY_ID)

        hmDBLockout[MPSDefs.DB_LOCKOUT_ID] = '1234'
        hmDBLockout[MPSDefs.DB_REINITIALIZE_INTERVAL_MINUTES] = '30'
        hmDBLockout[MPSDefs.DB_SET_NUMBER] = '1934'
        hmDBLockout[MPSDefs.DB_MEMBER_NUM] = '12456347'
        hmDBLockout[MPSDefs.DB_ACCOUNT_ID] = '12456634'
        hmDBLockout[MPSDefs.DB_FAILED_AUTH_COUNT] = '1'
        hmDBLockout[MPSDefs.DB_ATTEMPTS_ALLOWED] = '5'
        hmDBLockout[MPSDefs.DB_LOCKOUT_EXPIRATION] = '02282019 08:18:05'
        hmDBLockout[MPSDefs.DB_LOCKOUT_NAME] = 'SOFT'
        hmDBLockout[MPSDefs.DB_LOCK_TYPE] = 'SOFT'
        hmDBLockout[MPSDefs.DB_LAST_FAILED_AUTH] = '02102019 08:18:05'

        hmDBLockout1[MPSDefs.DB_LOCKOUT_ID] = '1234'
        hmDBLockout1[MPSDefs.DB_REINITIALIZE_INTERVAL_MINUTES] = '30'
        hmDBLockout1[MPSDefs.DB_SET_NUMBER] = '1935'
        hmDBLockout1[MPSDefs.DB_MEMBER_NUM] = '12456347'
        hmDBLockout1[MPSDefs.DB_ACCOUNT_ID] = '12456634'
        hmDBLockout1[MPSDefs.DB_FAILED_AUTH_COUNT] = '1'
        hmDBLockout1[MPSDefs.DB_ATTEMPTS_ALLOWED] = '5'
        hmDBLockout1[MPSDefs.DB_LOCKOUT_EXPIRATION] = '02282019 08:18:05'
        hmDBLockout1[MPSDefs.DB_LOCKOUT_NAME] = 'SOFT'
        hmDBLockout1[MPSDefs.DB_LOCK_TYPE] = 'SOFT'
        hmDBLockout1[MPSDefs.DB_LAST_FAILED_AUTH] = '02102019 08:18:05'
        alDBMemberLockout.add(hmDBLockout)
        alDBMemberLockout.add(hmDBLockout1)

        hmConfigLockoutValues['1234'] = alDBMemberLockout


        hmInput = CommonUtil.hashMap
        hmInput[CommonDefs.HANDLE] = 'qayma0034567'
        hmInput[CommonDefs.DOMAIN] = 'att.net'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmInput['identificationType'] = 'BTN'
        hmInput[CommonDefs.ACTIVE_LOCKS] = alDBMemberLockout
        hmInput[CommonDefs.EXPIRED_LOCKS] = alDBMemberLockout
        hmInput['nonExpiredNonActiveLocks'] = alDBMemberLockout
        hmInput['newLock'] = alDBMemberLockout
        hmInput[CommonDefs.MEMBER_LOCKOUT] = alDBMemberLockout
        hmInput[CommonDefs.VALIDATION_STATUS] = 'SUCCESS'
    }


    def "query lockout test null check"(){
        when:
        hmResult = testObj.queryLockout(null)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.ERR_SYS_APPL
        hmResult[CommonDefs.COMMON_APP_INFO] == ' Input Hash is NULL / EMPTY '
    }


    def "query lockout test missing lockout details"(){
        given:
        hmInput[CommonDefs.MEMBER_LOCKOUT] = null
        when:
        hmResult = testObj.queryLockout(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.ERR_INVALID_DATA
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Lockout details missing in input'
    }


    def "query lockout test missing lockout entry"() throws Exception{
        given:
        objLockOutValidation.lockOuts >> null
        when:
        hmResult = testObj.queryLockout(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == '100'
        hmResult[CommonDefs.COMMON_APP_INFO] == 'No LockId found in DB'
    }


    def "query lockout test s o f t lock"() throws Exception{
        given:
        hmInput['accountlockout'] = alDBMemberLockout
        objLockOutValidation.lockOuts >> hmConfigLockoutValues
        when:
        hmResult = testObj.queryLockout(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.COMMON_SUCCESS
        hmResult[CommonDefs.COMMON_APP_INFO] == null
    }


    def "query lockout test h a r d lock"() throws Exception{
        given:
        hmDBLockout[MPSDefs.DB_LOCK_TYPE] = 'HARD'
        hmDBLockout[MPSDefs.DB_FAILED_AUTH_COUNT] = '5'
        objLockOutValidation.lockOuts >> hmConfigLockoutValues
        when:
        hmResult = testObj.queryLockout(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.COMMON_SUCCESS
        hmResult[CommonDefs.COMMON_APP_INFO] == null
    }


    def "query lockout test lock excp"() throws Exception{
        given:
        hmDBLockout[MPSDefs.DB_LOCKOUT_EXPIRATION] = '5'
        objLockOutValidation.lockOuts >> hmConfigLockoutValues
        when:
        hmResult = testObj.queryLockout(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.ERR_SYS_APPL
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "query lockout test s o f t lock expiry after"() throws Exception{
        given:
        hmDBLockout[MPSDefs.DB_LOCKOUT_EXPIRATION] = '02282099 08:18:05'
        objLockOutValidation.lockOuts >> hmConfigLockoutValues
        when:
        hmResult = testObj.queryLockout(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.COMMON_SUCCESS
        hmResult[CommonDefs.COMMON_APP_INFO] == null
    }


    def "query lockout test s o f t lock failed auth after"() throws Exception{
        given:
        hmDBLockout[MPSDefs.DB_LAST_FAILED_AUTH] = '02102099 08:18:05'
        objLockOutValidation.lockOuts >> hmConfigLockoutValues
        when:
        hmResult = testObj.queryLockout(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.COMMON_SUCCESS
        hmResult[CommonDefs.COMMON_APP_INFO] == null
    }


    def "query lockout test s o f t lock failed auth null"() throws Exception{
        given:
        hmDBLockout.remove(MPSDefs.DB_LAST_FAILED_AUTH)
        objLockOutValidation.lockOuts >> hmConfigLockoutValues
        when:
        hmResult = testObj.queryLockout(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.COMMON_SUCCESS
        hmResult[CommonDefs.COMMON_APP_INFO] == null
    }


    def "query lockout test no lock d b"() throws Exception{
        given:
        hmDBLockout.remove(MPSDefs.DB_LOCK_TYPE)
        hmDBLockout1.remove(MPSDefs.DB_LOCK_TYPE)
        objLockOutValidation.lockOuts >> hmConfigLockoutValues
        when:
        hmResult = testObj.queryLockout(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] == CErrorDefs.ERR_INVALID_DATA
        hmResult[CommonDefs.COMMON_APP_INFO] == 'No LockId found in DB'
    }
}
