package com.att.idp.idgraphuserregistrationms.service.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.helper.RegisterLSUserHelper
import com.att.idp.idgraphuserregistrationms.resource.request.RegisterLSUserRequest
import com.att.idp.idgraphuserregistrationms.resource.response.RegisterLSUserResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.junit.jupiter.api.Assertions
import spock.lang.Specification

import jakarta.ws.rs.core.MultivaluedHashMap
import jakarta.ws.rs.core.MultivaluedMap


class RegisterLSUserServiceImplTest extends Specification {

	def registerLSUserServiceImplObj = new RegisterLSUserServiceImpl()
    RegisterLSUserHelper registerLSUserHelperObj=Mock(RegisterLSUserHelper)

	private RegisterLSUserRequest registerLSUserRequest = null
	public MultivaluedMap<String, String> requestHeader = null
	private Map<String, String> headers = new HashMap<>()


	def setup() throws Exception {
		registerLSUserServiceImplObj.registerLSUserHelper = registerLSUserHelperObj
		registerLSUserRequest = new RegisterLSUserRequest()
		requestHeader = new MultivaluedHashMap<>(headers)

		registerLSUserRequest.callingSystemId = 'IDP'
		registerLSUserRequest.isExternalCall = 'Y'
		registerLSUserRequest.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
		registerLSUserRequest.ban = '876110000'
		registerLSUserRequest.dateOfBirth = '20200404'
		registerLSUserRequest.regType = 'NEW'
		registerLSUserRequest.slid = 'crissydee73@gmail.com'
		registerLSUserRequest.handle = 'crissyechev74@aatt.net'
	}
	
	@SuppressWarnings('unchecked')

	def "test registerlsuser null response"() {
		when:
		RegisterLSUserResponse response = registerLSUserServiceImplObj.registerLSUser(registerLSUserRequest, requestHeader)

		then:
		response.appInfo == 'Null response from registerLSUserHelper.registerUser'
		HashMap hmResponse = new HashMap()

		when:
		hmResponse[MPSDefs.APP_STATUS_CODE] = null
		registerLSUserHelperObj.registerUser(_ as HashMap)>>hmResponse

		and:
		response = registerLSUserServiceImplObj.registerLSUser(registerLSUserRequest, requestHeader)

		then:
		response.appInfo == 'Null response from registerLSUserHelper.registerUser'
	}


	def "test register lsuser invaliddataexcep"() {

		given:
		HashMap hmResponse = new HashMap()
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_16374856'
		hmResponse['isTransactionRollback'] = 'true'
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		registerLSUserHelperObj.registerUser(_ as HashMap)>>hmResponse

		expect:
		InvalidInputDataException excep = Assertions.assertThrows(InvalidInputDataException.class, () -> {
			registerLSUserServiceImplObj.registerLSUser(registerLSUserRequest, requestHeader)
		})

	}
	
	@SuppressWarnings('unchecked')

	def "test registerlsuser success"() {

		given:
		HashMap hmResponse = new HashMap()
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		hmResponse['appInfo'] = 'Success'
		hmResponse['ErrorEnum'] = CommonDefs.COMMON_SUCCESS_MSG
		registerLSUserHelperObj.registerUser(_ as HashMap)>>hmResponse

		when:
		RegisterLSUserResponse response = registerLSUserServiceImplObj.registerLSUser(registerLSUserRequest, requestHeader)

		then:
		response.appStatusCode == '0'
	}

}
