package com.att.idp.component

import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.EmailAppPasswordDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetMemberServicesDBHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.MPSDefs
import org.hamcrest.CoreMatchers
import org.spockframework.spring.SpringBean

import java.sql.SQLException

/**
 * Component test for GET /emailapppassword endpoint.
 *
 * Dependency chain:
 *   EmailAppPasswordResourceImpl (INTERNAL — real)
 *     ├── EmailAppPasswordRequestValidator (INTERNAL — real)
 *     ├── GetMemberServicesDBHelper (EXTERNAL — mock)
 *     └── EmailAppPasswordDBHelper (EXTERNAL — mock)
 */
class EmailAppPasswordCompTest extends CompTestBase {

    private String uri = '/emailapppassword'

    // TECH_DEBT: DUPLICATE — GetMemberServicesDBHelper is also mocked in other CTs; should be consolidated in CompTestBase (Phase 4)
    @SpringBean
    GetMemberServicesDBHelper getMemberServicesDBHelper = Mock()

    @SpringBean
    EmailAppPasswordDBHelper emailAppPasswordDBHelper = Mock()

    private Map<String, String> validHeaders() {
        [
            'Content-Type' : 'application/json',
            'X-ATT-ClientId': 'IDMPROFILE',
            'idp-trace-id' : 'trace123:trace123:0:0'
        ]
    }

    private HashMap<String, Object> memberServicesSuccess(String memberNum, String memberName = 'testUser', String domainName = 'att.net') {
        HashMap<String, Object> resp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        resp.put(MPSDefs.DB_MEMBER_NUM, memberNum)
        resp.put(MPSDefs.DB_MEMBER_NAME, memberName)
        resp.put(MPSDefs.DB_DOMAIN_NAME, domainName)
        return resp
    }

    private HashMap<String, Object> emailAppPwdSuccess() {
        HashMap<String, Object> row = new HashMap<>()
        row.put(MPSDefs.DB_PASSWORD_NAME, 'testAppPwd')
        row.put(MPSDefs.DB_CREATE_DATE, '01012025 00:00:00')
        row.put(MPSDefs.DB_MEMBER_NUM, '12345')

        ArrayList rows = new ArrayList()
        rows.add(row)

        HashMap<String, Object> resp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        resp.put(MPSDefs.DB_APPEMAILPASSWORD_TABLE, rows)
        return resp
    }

    // ========== Success Scenarios ==========

    def "success with memberId and domain returns 200 with password data"() {
        given:
        def headers = validHeaders()

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .queryParam('memberId', 'testUser')
                .queryParam('domain', 'att.net')
                .when().get(uri)

        then:
        1 * getMemberServicesDBHelper.getMemberServices(_) >> memberServicesSuccess('12345')
        1 * emailAppPasswordDBHelper.listEmailAppPwd(_) >> emailAppPwdSuccess()
        0 * _

        and:
        response.statusCode() == 200
        response.then()
                .body('memberId', CoreMatchers.equalTo('testUser'))
                .body('domain', CoreMatchers.equalTo('att.net'))
                .body('passwordNames[0].passwordName', CoreMatchers.equalTo('testAppPwd'))
    }

    def "success with guid returns 200 with password data"() {
        given:
        def headers = validHeaders()

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .queryParam('guid', '12345')
                .when().get(uri)

        then:
        1 * getMemberServicesDBHelper.getMemberServices(_) >> memberServicesSuccess('12345')
        1 * emailAppPasswordDBHelper.listEmailAppPwd(_) >> emailAppPwdSuccess()
        0 * _

        and:
        response.statusCode() == 200
        response.then()
                .body('guid', CoreMatchers.equalTo('12345'))
                .body('passwordNames[0].passwordName', CoreMatchers.equalTo('testAppPwd'))
    }

    // ========== Validation Error Scenarios ==========

    def "invalid X-ATT-ClientId returns 400"() {
        given:
        Map<String, String> headers = validHeaders()
        headers['X-ATT-ClientId'] = 'IDP'

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .queryParam('memberId', 'testUser')
                .queryParam('domain', 'att.net')
                .when().get(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
    }

    def "missing X-ATT-ClientId returns 400"() {
        given:
        Map<String, String> headers = [
            'Content-Type' : 'application/json',
            'idp-trace-id' : 'trace123:trace123:0:0'
        ]

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .queryParam('memberId', 'testUser')
                .queryParam('domain', 'att.net')
                .when().get(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
    }

    def "missing memberId and domain without guid returns 400"() {
        given:
        def headers = validHeaders()

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .when().get(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
    }

    // ========== Not Found Scenarios ==========

    def "member num not found returns error response"() {
        given:
        def headers = validHeaders()
        HashMap memberResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        // getMemberServices returns success but WITHOUT DB_MEMBER_NUM — resource skips queryEmailAppPwd and returns error

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .queryParam('memberId', 'unknownUser')
                .queryParam('domain', 'att.net')
                .when().get(uri)

        then:
        1 * getMemberServicesDBHelper.getMemberServices(_) >> memberResp
        0 * _

        and:
        response.statusCode() != 200
    }

    def "emailAppPwd query returns 200 with empty passwordNames when no records found"() {
        given:
        def headers = validHeaders()
        HashMap emptyResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CommonDefs.COMMON_SUCCESS_MSG)
        emptyResp.put(MPSDefs.DB_APPEMAILPASSWORD_TABLE, [])

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .queryParam('guid', '12345')
                .when().get(uri)

        then:
        1 * getMemberServicesDBHelper.getMemberServices(_) >> memberServicesSuccess('12345')
        1 * emailAppPasswordDBHelper.listEmailAppPwd(_) >> emptyResp
        0 * _

        and:
        response.statusCode() == 200
        response.then().body('passwordNames', CoreMatchers.nullValue())
    }

    def "non-numeric guid returns 400"() {
        given:
        def headers = validHeaders()

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .queryParam('guid', 'abc-123')
                .when().get(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
    }

    // ========== Exception Scenarios ==========

    def "SQLException from getMemberServices returns 500 with ERR_DB"() {
        given:
        def headers = validHeaders()

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .queryParam('guid', '12345')
                .when().get(uri)

        then:
        1 * getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> { throw new SQLException('DB connection failed') }
        0 * _

        and:
        response.statusCode() == 500
    }

    def "general exception from getMemberServices returns 500 with ERR_SYS_APPL"() {
        given:
        def headers = validHeaders()

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .queryParam('guid', '12345')
                .when().get(uri)

        then:
        1 * getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> { throw new RuntimeException('Unexpected error') }
        0 * _

        and:
        response.statusCode() == 500
    }
}
