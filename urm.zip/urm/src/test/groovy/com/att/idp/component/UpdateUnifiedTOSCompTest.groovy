package com.att.idp.component

import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetAssociatedMembersDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetMemberServicesDBHelper
import com.att.idp.idgraphuserregistrationms.integration.MPSYSInternalRestClient
import com.att.idp.idgraphuserregistrationms.queue.message.helpers.UpdateTOSQueueHelper
import org.hamcrest.CoreMatchers
import org.spockframework.spring.SpringBean
import org.springframework.jdbc.core.JdbcTemplate


class UpdateUnifiedTOSCompTest extends CompTestBase {
	String uri = '/unifiedTOS/update'



	@SpringBean
	MPSYSInternalRestClient idpRestClient = Mock()

	private Map<String, String> getHeaders() {
		Map<String, String> headers = new HashMap<String, String>()
		headers['Content-Type'] = 'application/json'
		headers['X-ATT-ClientId'] ='IDP'
		headers['idp-trace-id'] = 'cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0'
		return headers
	}

	def "update unified t o s success"() {
		given:
		List accountInfoResponse = readJsonFileToList("mockResponse/AccountInfoUpdateResponse.json") as List;
		HashMap associatedMembersResponse = readJsonFileToMap("mockResponse/AssociatedMemberResponse.json") as HashMap;

		Map memberServiceResp= new HashMap();
		memberServiceResp.put("appStatusMsg","REC_NOT_FOUND");
		memberServiceResp.put("sqlMsg","N/A");
		memberServiceResp.put("appCategoryCode","3");
		memberServiceResp.put("appStatusCode","303");
		memberServiceResp.put("sqlCode","N/A");
		memberServiceResp.put("numRowsUpdated","0");
		HashMap resultMap = new HashMap();
		resultMap.put("appStatusMsg", "SUCCESS");
		resultMap.put("appStatusCode", "0");
		resultMap.put("isTransactionRollback", "true");
		resultMap.put("appInfo", "UpdateUnifiedTOS Message sent successfully from sendmessagetoQueue");
		resultMap.put("appCategoryCode","0")
		HashMap restClientResultMap = new HashMap();
		restClientResultMap.put("appStatusMsg", "SUCCESS");
		restClientResultMap.put("appStatusCode", "0");
		restClientResultMap.put("appInfo", "UpdateUnifiedTOS processed successfully via REST client");
		restClientResultMap.put("appCategoryCode","0")
		jdbcTemplate.queryForList(_ as String, _ as Object)	>> accountInfoResponse
		getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> associatedMembersResponse
		getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> memberServiceResp
		updateTOSQueueHelper.sendMessage(_ as HashMap, _ as Map) >> resultMap
		idpRestClient.callIDPRestClient(_ as Map) >> restClientResultMap
		String req = '{  "ban" : "222222301", "hsiaTOSAcceptance" : "Y", "e911TOSAcceptance" : "Y" }'

		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(200).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
				.body("appStatusCode", CoreMatchers.equalTo("0"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))

	}

	def "update unified t o s no associated member record found"() {
		given:
		List accountInfoResponse = readJsonFileToList("mockResponse/AccountInfoUpdateResponse.json") as List;
		HashMap associatedMembers = new HashMap();
		associatedMembers.put("appStatusMsg","REC_NOT_FOUND")
		associatedMembers.put("appCategoryCode","0")
		associatedMembers.put("appInfo","REC_NOT_FOUND")
		associatedMembers.put("appStatusCode","285")

		Map memberServiceResp= new HashMap();
		memberServiceResp.put("appStatusMsg","REC_NOT_FOUND");
		memberServiceResp.put("sqlMsg","N/A");
		memberServiceResp.put("appCategoryCode","3");
		memberServiceResp.put("appStatusCode","303");
		memberServiceResp.put("sqlCode","N/A");
		memberServiceResp.put("numRowsUpdated","0");
		HashMap resultMap = new HashMap();
		resultMap.put("appStatusMsg", "SUCCESS");
		resultMap.put("appStatusCode", "0");
		resultMap.put("isTransactionRollback", "true");
		resultMap.put("appInfo", "UpdateUnifiedTOS Message sent successfully from sendmessagetoQueue");
		resultMap.put("appCategoryCode","0")
		HashMap restClientResultMap = new HashMap();
		restClientResultMap.put("appStatusMsg", "SUCCESS");
		restClientResultMap.put("appStatusCode", "0");
		restClientResultMap.put("appInfo", "UpdateUnifiedTOS processed successfully via REST client");
		restClientResultMap.put("appCategoryCode","0")
		jdbcTemplate.queryForList(_ as String, _ as Object)	>> accountInfoResponse
		getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> associatedMembers
		getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> memberServiceResp
		updateTOSQueueHelper.sendMessage(_ as HashMap, _ as Map) >> resultMap
		idpRestClient.callIDPRestClient(_ as Map) >> restClientResultMap
		String req = '{  "ban" : "222222301", "hsiaTOSAcceptance" : "Y", "e911TOSAcceptance" : "Y" }'

		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(200).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
				.body("appStatusCode", CoreMatchers.equalTo("0"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))

	}

	def "update unified t o s success member service record found"() {
		given:
		List accountInfoResponse = readJsonFileToList("mockResponse/AccountInfoUpdateResponse.json") as List;
		HashMap memberServiceResp = readJsonFileToMap("mockResponse/MemberService.json") as HashMap;
		HashMap associatedMembers = new HashMap();
		associatedMembers.put("appStatusMsg","REC_NOT_FOUND")
		associatedMembers.put("appCategoryCode","0")
		associatedMembers.put("appInfo","REC_NOT_FOUND")
		associatedMembers.put("appStatusCode","285")
		HashMap resultMap = new HashMap();
		resultMap.put("appStatusMsg", "SUCCESS");
		resultMap.put("appStatusCode", "0");
		resultMap.put("isTransactionRollback", "true");
		resultMap.put("appInfo", "UpdateUnifiedTOS Message sent successfully from sendmessagetoQueue");
		resultMap.put("appCategoryCode","0")
		HashMap restClientResultMap = new HashMap();
		restClientResultMap.put("appStatusMsg", "SUCCESS");
		restClientResultMap.put("appStatusCode", "0");
		restClientResultMap.put("appInfo", "UpdateUnifiedTOS processed successfully via REST client");
		restClientResultMap.put("appCategoryCode","0")
		jdbcTemplate.queryForList(_ as String, _ as Object)	>> accountInfoResponse
		getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> associatedMembers
		getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> memberServiceResp
		updateTOSQueueHelper.sendMessage(_ as HashMap, _ as Map) >> resultMap
		idpRestClient.callIDPRestClient(_ as Map) >> restClientResultMap
		String req = '{  "ban" : "222222301", "hsiaTOSAcceptance" : "Y", "e911TOSAcceptance" : "Y" }'

		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(200).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
				.body("appStatusCode", CoreMatchers.equalTo("0"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))

	}

	def "update unified t o s null value for ban"() {
		given:
		jdbcTemplate.queryForList(_ as String, _ as Object)	>> 0
		String req = '{  "ban" : "", "hsiaTOSAcceptance" : "Y", "e911TOSAcceptance" : "Y" }'

		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(400).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
				.body("appStatusCode", CoreMatchers.equalTo("100"))
				.body("appInfo", CoreMatchers.equalTo("ban length is invalid"))
				.body("error.errorId", CoreMatchers.equalTo("MS_MPSYS_BE_100"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))


	}

	def "update unified t o s invalid value for hsiaTOSAcceptance"() {
		given:
		jdbcTemplate.queryForList(_ as String, _ as Object)	>> 0
		String req = '{  "ban" : "759208275", "hsiaTOSAcceptance" : "9", "e911TOSAcceptance" : "Y" }'

		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(400).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
				.body("appStatusCode", CoreMatchers.equalTo("100"))
				.body("appInfo", CoreMatchers.equalTo("Value of hsiaTOSAcceptance should be Y or N"))
				.body("error.errorId", CoreMatchers.equalTo("MS_MPSYS_BE_100"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))


	}

	def "update unified t o s associatedMembers error "() {
		given:
		List accountInfoResponse = readJsonFileToList("mockResponse/AccountInfoUpdateResponse.json") as List;

		Map memberServiceResp= new HashMap();
		memberServiceResp.put("appStatusMsg","REC_NOT_FOUND");
		memberServiceResp.put("sqlMsg","N/A");
		memberServiceResp.put("appCategoryCode","3");
		memberServiceResp.put("appStatusCode","303");
		memberServiceResp.put("sqlCode","N/A");
		memberServiceResp.put("numRowsUpdated","0");
		HashMap resultMap = new HashMap();
		resultMap.put("appStatusMsg", "SUCCESS");
		resultMap.put("appStatusCode", "0");
		resultMap.put("isTransactionRollback", "true");
		resultMap.put("appInfo", "UpdateUnifiedTOS Message sent successfully from sendmessagetoQueue");
		resultMap.put("appCategoryCode","0")
		jdbcTemplate.queryForList(_ as String, _ as Object)	>> accountInfoResponse
		getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> null
		getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> memberServiceResp
		updateTOSQueueHelper.sendMessage(_ as HashMap, _ as Map) >> resultMap
		String req = '{  "ban" : "222222301", "hsiaTOSAcceptance" : "Y", "e911TOSAcceptance" : "Y" }'

		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(500).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_SYS_APPL"))
				.body("appStatusCode", CoreMatchers.equalTo("602"))
				.body("appInfo", CoreMatchers.equalTo("Null or empty response MPSDB_GetAssocicatedMembers_H"))
				.body("error.errorId", CoreMatchers.equalTo("MS_MPSYS_BE_602"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))

	}

	def "update unified t o s memberService error"() {
		given:
		List accountInfoResponse = readJsonFileToList("mockResponse/AccountInfoUpdateResponse.json") as List;
		HashMap associatedMembersResponse = readJsonFileToMap("mockResponse/AssociatedMemberResponse.json") as HashMap;
		HashMap resultMap = new HashMap();
		resultMap.put("appStatusMsg", "SUCCESS");
		resultMap.put("appStatusCode", "0");
		resultMap.put("isTransactionRollback", "true");
		resultMap.put("appInfo", "UpdateUnifiedTOS Message sent successfully from sendmessagetoQueue");
		resultMap.put("appCategoryCode","0")
		jdbcTemplate.queryForList(_ as String, _ as Object)	>> accountInfoResponse
		getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> associatedMembersResponse
		getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> null
		updateTOSQueueHelper.sendMessage(_ as HashMap, _ as Map) >> resultMap
		String req = '{  "ban" : "222222301", "hsiaTOSAcceptance" : "Y", "e911TOSAcceptance" : "Y" }'

		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(500).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_SYS_APPL"))
				.body("appStatusCode", CoreMatchers.equalTo("602"))
				.body("appInfo", CoreMatchers.equalTo("Null or empty response MPSDB_GetMemberServices_H"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))

	}


	def "update unified t o s error jmsQueueSender error"() {
		given:
		List accountInfoResponse = readJsonFileToList("mockResponse/AccountInfoUpdateResponse.json") as List;
		HashMap associatedMembersResponse = readJsonFileToMap("mockResponse/AssociatedMemberResponse.json") as HashMap;
		HashMap memberServiceResp = readJsonFileToMap("mockResponse/MemberService.json") as HashMap;

		jdbcTemplate.queryForList(_ as String, _ as Object)	>> accountInfoResponse
		getAssociatedMembersDBHelperObj.getAssociatedMembers(_ as HashMap) >> associatedMembersResponse
		getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> memberServiceResp
		updateTOSQueueHelper.sendMessage(_ as HashMap, _ as Map) >> null
		String req = '{  "ban" : "222222301", "hsiaTOSAcceptance" : "Y", "e911TOSAcceptance" : "Y" }'

		expect:
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(500).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_SYS_APPL"))
				.body("appStatusCode", CoreMatchers.equalTo("602"))
				.body("appInfo", CoreMatchers.equalTo("Null or empty response UpdateTOSQueueHelper"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))

	}
}
