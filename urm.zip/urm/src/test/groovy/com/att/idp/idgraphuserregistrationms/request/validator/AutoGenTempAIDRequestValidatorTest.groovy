package com.att.idp.idgraphuserregistrationms.request.validator

import com.att.idp.idgraphuserregistrationms.resource.request.AutoGenTempAIDRequest
import com.att.idp.idgraphuserregistrationms.resource.request.SorInvariantId
import com.att.idp.idgraphuserregistrationms.resource.response.AutoGenTempAIDResponse
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap


class AutoGenTempAIDRequestValidatorTest extends Specification {


	def autoGenTempAIDRequestValidator=new AutoGenTempAIDRequestValidator()

	AutoGenTempAIDRequest requestObj = null
	AutoGenTempAIDResponse responseObj = null

	private Map<String, String> headers = new HashMap<>()

	public HttpHeaders requestHeader = null
	MultivaluedHashMap requestHeaders =null


	def setup() throws Exception {
		requestObj = new AutoGenTempAIDRequest()
		responseObj= new AutoGenTempAIDResponse()
		requestHeader= Mock(HttpHeaders)
	    requestHeaders = new MultivaluedHashMap<>(headers)

		requestObj.callingSystemId = 'IDP'
		requestObj.isExternalCall = 'Y'
		requestObj.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
		requestObj.firstName = 'test'
		requestObj.lastName = 'testing'
		requestObj.contactEmail = 'test@testing.com'
		requestObj.agentId = 'tt1234'
		requestObj.contactEmailRTValidFlag = 'Y'

		SorInvariantId sor = new SorInvariantId()
		sor.sorName = 'LS'
		sor.sorInvariantId = '1234567890123'
		List<SorInvariantId> lstSor = new ArrayList<SorInvariantId>()
		lstSor.add(sor)
		requestObj.sorInvariantIdList = lstSor

		ReflectionTestUtils.setField(autoGenTempAIDRequestValidator, 'propValidCallers', 'DATAMGT|OPUS|IDP|CSRIDP')
		ReflectionTestUtils.setField(autoGenTempAIDRequestValidator, 'propCSIReqAgentId', 'OPUS')

	}


	def "autogentempaid request validator null req test"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		AutoGenTempAIDResponse responseObj = autoGenTempAIDRequestValidator.autoGenTempAIDReqValidator(requestHeader, null)
		then:
		responseObj.appInfo == 'Input Request is NULL / Empty.'

	}
	def "query autogentemp req validator success without trace id test"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		//Mockito.doReturn(null).when(requestHeader).getHeaderString("idp-trace-id");
		//	requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'

		when:
		AutoGenTempAIDResponse response = autoGenTempAIDRequestValidator.autoGenTempAIDReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Missing or Invalid IdpTraceId'
	}
	def "autogentempaid requestunknownattribues"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		Map<String,Object> allUnknownAttributes =new HashMap<>()
		requestObj.setUnknownAttributes(allUnknownAttributes)
		allUnknownAttributes.put("test","test")
		when:
		AutoGenTempAIDResponse responseObj = autoGenTempAIDRequestValidator.autoGenTempAIDReqValidator(requestHeader, requestObj)
		then:
		responseObj.appInfo == 'Invalid Attributes passed in AutogenTempAccessIdRequest : {test=test}'

	}

	def "autogentempaid request validator success test"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		AutoGenTempAIDResponse response = autoGenTempAIDRequestValidator.autoGenTempAIDReqValidator(requestHeader, requestObj)
		then:
		response == null

	}

	def "registerlsuser requestnullclientid test"() throws Exception{
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId')>>null
		when:
		AutoGenTempAIDResponse responseObj = autoGenTempAIDRequestValidator.autoGenTempAIDReqValidator(requestHeader, requestObj)
		then:
		responseObj.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}

	def "registerlsuser request emptyclientid test"() throws Exception{
		given:
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId')>>' '
		when:
		AutoGenTempAIDResponse response = autoGenTempAIDRequestValidator.autoGenTempAIDReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}


	def "registerlsuser requestinvalid clientid test"() throws Exception{
		given:
		//Mockito.doReturn('ILM').when(requestHeader).getHeaderString('X-ATT-ClientId')
		requestHeader.getHeaderString('X-ATT-ClientId')>>'ILM'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		AutoGenTempAIDResponse response = autoGenTempAIDRequestValidator.autoGenTempAIDReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}


	def "autogentempaid requestvalidator null first name test"() throws Exception {
		given:
		requestObj.contactEmail = null
		requestObj.firstName = null
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		AutoGenTempAIDResponse response = autoGenTempAIDRequestValidator.autoGenTempAIDReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'One of the input FirstName/LastName or ContactEmail must be present.'

	}

	def "autogentempaid request validator sor invariant id test"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		SorInvariantId sor = new SorInvariantId()
		sor.sorName = null
		List<SorInvariantId> lst = new ArrayList<>()
		lst.add(sor)
		requestObj.sorInvariantIdList = lst
		when:
		AutoGenTempAIDResponse response = autoGenTempAIDRequestValidator.autoGenTempAIDReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Input sorName is null or empty'

		when:
		sor.sorName = 'LS'
		sor.sorInvariantId = null
		lst.clear()
		lst.add(sor)
		requestObj.sorInvariantIdList = lst
		AutoGenTempAIDResponse response2 = autoGenTempAIDRequestValidator.autoGenTempAIDReqValidator(requestHeader, requestObj)
		then:
		response2.appInfo == 'Input sorInvariantId is null or empty'

	}

	def "autogentempaid request validator null is external call test"() throws Exception {
		given:
		requestObj.isExternalCall = null
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'

		when:
		requestObj.isExternalCall = 'K'
		AutoGenTempAIDResponse response2 = autoGenTempAIDRequestValidator.autoGenTempAIDReqValidator(requestHeader, requestObj)
		then:
		response2.appInfo == 'isExternalCall must be one of Y or N'

	}

	def "autogentempaid request validator contact rtv flag test"() throws Exception {
		given:
		requestObj.contactEmailRTValidFlag = null
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		requestObj.contactEmailRTValidFlag = 'K'
		AutoGenTempAIDResponse response2 = autoGenTempAIDRequestValidator.autoGenTempAIDReqValidator(requestHeader, requestObj)
		then:
		response2.appInfo == 'contactEmailRTValidFlag must be one of Y or N'

	}


	def "autogentempaid request validator missing agent id test"() throws Exception {
		given:
		//requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		//Mockito.doReturn('OPUS').when(requestHeader).getHeaderString('X-ATT-ClientId')
		requestHeader.getHeaderString('X-ATT-ClientId')>>'OPUS'
		requestObj.agentId = null
		when:
		AutoGenTempAIDResponse response = autoGenTempAIDRequestValidator.autoGenTempAIDReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'agentId is required for the caller'

	}

	def autoGenTempAIDRequestValidatorExceptionTest() throws Exception {
		given:
		//requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		//Mockito.doThrow(new RuntimeException()).when(requestHeader).getHeaderString('X-ATT-ClientId')
		requestHeader.getHeaderString('X-ATT-ClientId')>> { throw ex }

		when:
		AutoGenTempAIDResponse response = autoGenTempAIDRequestValidator.autoGenTempAIDReqValidator(requestHeader, requestObj)

		then:
		thrown(RuntimeException.class)
	}
}
