package com.att.idp.idgraphuserregistrationms.request.validator

import com.att.idp.idgraphuserregistrationms.resource.request.QueryByIPEligibilityRequest
import com.att.idp.idgraphuserregistrationms.resource.response.QueryByIPEligibilityResponse
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap


class QueryByIPEligibilityReqValidatorTest extends Specification {


	def queryByIPEligibilityReqValidObj = new QueryByIPEligibilityReqValidator()

	QueryByIPEligibilityRequest requestObj = null
	QueryByIPEligibilityResponse responseObj = null

	private Map<String, String> headers = new HashMap<>()


	public HttpHeaders requestHeader = null
	MultivaluedHashMap requestHeaders = null


	def setup() throws Exception {
		requestObj = new QueryByIPEligibilityRequest()
		responseObj = new QueryByIPEligibilityResponse()
		requestHeader = Mock(HttpHeaders)

		requestObj.callingSystemId = 'IDP'
		requestObj.isExternalCall = 'Y'
		requestObj.ipAddress = '2611:1711:4881:3931:2a16:adsf:fe19:7be4'
		requestObj.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'

		//MockitoAnnotations.initMocks(this)
		ReflectionTestUtils.setField(queryByIPEligibilityReqValidObj, 'propCallingSystemId', 'IDP|CSRIDP|DATAMGT')
		//requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		//	requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
	}


	def "querybyipelig reqvalidator success test"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		when:
		QueryByIPEligibilityResponse response = queryByIPEligibilityReqValidObj.queryByIPEligibilityReqValidator(requestHeader, requestObj)
		then:
		response == null

	}


	def "querybyipelig req null test"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		requestObj = null
		when:
		QueryByIPEligibilityResponse response = queryByIPEligibilityReqValidObj.queryByIPEligibilityReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Input Request Parameter is NULL / Empty.'

	}


	def "querybyipelig req valid csi test"() throws Exception {

		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId') >> null

		when:
		QueryByIPEligibilityResponse response = queryByIPEligibilityReqValidObj.queryByIPEligibilityReqValidator(requestHeader, requestObj)
		then:

		response.appInfo == 'Missing or invalid X-ATT-ClientId in request header'

		// when X-ATT-ClientId not populated
		when:
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'ILM'
		response = queryByIPEligibilityReqValidObj.queryByIPEligibilityReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}

	def "querybyipelig requestunknownattribues"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		Map<String, Object> allUnknownAttributes = new HashMap<>()
		requestObj.setUnknownAttributes(allUnknownAttributes)
		allUnknownAttributes.put("test", "test")
		when:
		QueryByIPEligibilityResponse responseObj = queryByIPEligibilityReqValidObj.queryByIPEligibilityReqValidator(requestHeader, requestObj)
		then:
		responseObj.appInfo == 'Invalid Attributes passed in QueryByIPEligibilityRequest : {test=test}'

	}

	def "querybyipelig req empty value test"() throws Exception {

		// when ipaddress is empty
		given:
		requestObj.ipAddress = ''
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		when:
		QueryByIPEligibilityResponse response = queryByIPEligibilityReqValidObj.queryByIPEligibilityReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'IpAddress cannot be null or empty'

	}


	def "querybyipelig autogen traceid test"() throws Exception {

		given:
		//Mockito.doReturn(null).when(requestHeader).getHeaderString('idp-trace-id')
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		when:
		QueryByIPEligibilityResponse response = queryByIPEligibilityReqValidObj.queryByIPEligibilityReqValidator(requestHeader, requestObj)
		then:
		//response != null
		response.appInfo == 'Missing or Invalid IdpTraceId'
	}


	def "querybyipelig external call test as N"() throws Exception {

		// when externalCall set as N
		given:
		requestObj.isExternalCall = 'N'
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'ILM'
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		when:
		QueryByIPEligibilityResponse response = queryByIPEligibilityReqValidObj.queryByIPEligibilityReqValidator(requestHeader, requestObj)
		then:
		response == null


	}

	def "querybyipelig external call test as null"() throws Exception {
		// when externalCall set as null
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'IDP'
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		when:
		requestObj.isExternalCall = null
		QueryByIPEligibilityResponse response = queryByIPEligibilityReqValidObj.queryByIPEligibilityReqValidator(requestHeader, requestObj)
		then:
		response == null
	}

	def "querybyipelig external call test as Y"() throws Exception {
		// when invalid externalCall value is passed
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'ILM'
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		when:
		requestObj.isExternalCall = 'I'
		QueryByIPEligibilityResponse response = queryByIPEligibilityReqValidObj.queryByIPEligibilityReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'isExternalCall must be one of Y or N'
	}
	def "querybyipelig external call test as Y and not valid csi"() throws Exception {
		// when invalid externalCall value is passed
		requestHeader.getHeaderString('X-ATT-ClientId') >> 'ILM'
		requestHeader.getHeaderString('idp-trace-id') >> '99dfs999:8dfs8888:77777:66666ccc'
		when:
		requestObj.isExternalCall = 'Y'
		QueryByIPEligibilityResponse response = queryByIPEligibilityReqValidObj.queryByIPEligibilityReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}
	def "querybyipeligRequestValidatorExceptionTest"() throws Exception {
		given:
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId')>> { throw ex }

		when:
		QueryByIPEligibilityResponse response = queryByIPEligibilityReqValidObj.queryByIPEligibilityReqValidator(requestHeader, requestObj)

		then:
		thrown(RuntimeException.class)
	}

}