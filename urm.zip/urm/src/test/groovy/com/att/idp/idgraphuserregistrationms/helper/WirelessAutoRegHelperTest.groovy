package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraph.commons.integration.CGRestClientWrapper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.AccountAutoRegDBHelper
import com.att.idp.idgraphuserregistrationms.integration.MPSYSInternalRestClient
import com.att.idp.idgraphuserregistrationms.queue.message.helpers.WirelessAutoRegQueueHelper
import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.att.mpsys.common.utils.*
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ArrayNode
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import spock.lang.Unroll
import com.att.idp.idgraphuserregistrationms.client.csi.CSIRequestBuilder
import com.att.idp.idgraphuserregistrationms.client.CSIIAPSoapHandler
import com.att.idp.core.exception.ServiceException
import com.att.idp.idgraphuserregistrationms.message.ErrorMessages
import com.cingular.csi.csi.namespaces.container._public.inquireaccountprofilerequest.InquireAccountProfileRequestInfo

import jakarta.ws.rs.core.Response

class WirelessAutoRegHelperTest extends Specification {

    def wirelessAutoRegHelperObj = new WirelessAutoRegHelper()


    MPSYSInternalRestClient internalIDPRestClient = Mock(MPSYSInternalRestClient)

    UserProfileAutoregUtility oUserProfileAutoregUtility = Mock(UserProfileAutoregUtility)

    AccountAutoRegDBHelper accountAutoRegDBHelper = Mock(AccountAutoRegDBHelper)

    ExternalDestinationHelper externalDestinationHelper = Mock(ExternalDestinationHelper)

    WirelessAutoRegQueueHelper wirelessAutoRegQueueHelper = Mock(WirelessAutoRegQueueHelper)
    FeatureManagerHelper featureManager = Mock(FeatureManagerHelper)


    CGRestClientWrapper cgRestClientObj = Mock(CGRestClientWrapper)
    CSIRequestBuilder csiRequestBuilder = Mock(CSIRequestBuilder)
    CSIIAPSoapHandler csiSoapHandler = Mock(CSIIAPSoapHandler)

    HashMap hmInput = new HashMap()
    HashMap hmSuccessResponse = new HashMap()
    HashMap hmErrorResponse = new HashMap()

    Response response = null
    HashMap hmCGResponse = new HashMap()
    HashMap hmCSIIAPResponse = new HashMap()
    HashMap hmAutoGenAccessId = new HashMap()
    private Map hmResult = CommonUtil.hashMap
    private String stAppInfo
    HashMap hmOGResponse = new HashMap()

    ArrayList dbusInput = CommonUtil.arrayList

    @SuppressWarnings('unchecked')

    def setup()
            throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
        hmResult = null

        wirelessAutoRegHelperObj.internalIDPRestClient = internalIDPRestClient
        wirelessAutoRegHelperObj.oUserProfileAutoregUtility = oUserProfileAutoregUtility
        wirelessAutoRegHelperObj.accountAutoRegDBHelper = accountAutoRegDBHelper
        wirelessAutoRegHelperObj.externalDestinationHelper = externalDestinationHelper
        wirelessAutoRegHelperObj.wirelessAutoRegQueueHelper = wirelessAutoRegQueueHelper
        wirelessAutoRegHelperObj.cgRestClientObj = cgRestClientObj
        wirelessAutoRegHelperObj.featureManager = featureManager
        wirelessAutoRegHelperObj.csiRequestBuilder = csiRequestBuilder
        wirelessAutoRegHelperObj.csiSoapHandler = csiSoapHandler

        ReflectionTestUtils.setField(wirelessAutoRegHelperObj, 'sMobilityAutoRegAddMosub', 'Y')
        hmSuccessResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        hmErrorResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_LENGTH_NUM, 'Error')

        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.IS_EXTERNAL_CALL] = 'Y'
        hmInput[CommonDefs.TRANSACTION_NAME] = 'WirelessAutoReg'
        hmInput[CommonDefs.FIRST_NAME] = 'qay'
        hmInput[CommonDefs.LAST_NAME] = 'test'
        hmInput[CommonDefs.GUID] = '121321113'
        hmInput[CommonDefs.CONTACT_EMAIL] = 'qaytest@att.com'
        hmInput['isConnectedCar'] = 'Y'
        hmInput[CommonDefs.SERVICE_NAME] = 'MOBILITY'
        hmInput[CommonDefs.SOR_ID] = '13'
        hmInput[CommonDefs.SOR_INVARIANT_ID] = '2462729299'

        // response
        HashMap hmEmail = new HashMap()
        HashMap hmAccount = new HashMap()
        @SuppressWarnings('rawtypes')
        HashMap hmContact = new HashMap()
        HashMap subscriberNumber = new HashMap()
        HashMap hmCBRInfo = new HashMap()
        hmCBRInfo[CommonDefs.PHONE_NUMBER] = '9149140004'

        ArrayList subscriber = new ArrayList()

        hmEmail['emailAddress'] = 'aaa@aaa.com'
        hmEmail['effectiveDate'] = '2017-08-22Z'

        hmContact[CommonDefs.EMAIL] = hmEmail
        hmContact[CommonDefs.CBR_INFO] = hmCBRInfo

        subscriberNumber['subscriberId'] = '121321113'
        subscriberNumber['smsCapability'] = 'true'
        subscriberNumber['status'] = 'A'
        subscriber.add(subscriberNumber)
        ObjectMapper objectMapper = new ObjectMapper()
        ArrayNode anSubscribers = objectMapper.valueToTree(subscriber)
        hmAccount['contact'] = hmContact
        hmAccount['primaryAccountHolder'] = '123454'

        hmCGResponse['accounts'] = hmAccount
        hmCGResponse['appStatusCode'] = '0'
        hmCGResponse['subscribers'] = anSubscribers
        hmCGResponse['appInfo'] = 'SUCCESS'

        hmCSIIAPResponse['accounts'] = hmAccount
        hmCSIIAPResponse['appStatusCode'] = '0'
        hmCSIIAPResponse['subscribers'] = anSubscribers
        hmCSIIAPResponse['appInfo'] = 'SUCCESS'

        hmAutoGenAccessId['validSLID'] = 'qay_test@att.com'
        hmAutoGenAccessId['appInfo'] = 'SUCCESS'
        hmAutoGenAccessId[MPSDefs.APP_STATUS_CODE] = '0'

    }


    def "test input null"() throws Exception {
        given:
        hmResult = wirelessAutoRegHelperObj.registerWirelessUser(null)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Input Hash is NULL'
    }


   def "test register wireless error c g response"() throws Exception {
        featureManager.isEnabled({ String s -> s == "svc-idgraph-wirelessautoreg-call-csi" }) >> false
        cgRestClientObj.getCGSyncCall({ Map<String, Object> m -> true }) >> hmErrorResponse
        internalIDPRestClient.callIDPRestClient({ Map<String, Object> m -> true }) >> hmErrorResponse
        internalIDPRestClient.callIDPRestClient(_) >> hmErrorResponse
        hmResult = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Error'
    }


    def "test register wireless when auto gen access id error"() throws Exception {

        given:
        hmAutoGenAccessId[MPSDefs.APP_STATUS_CODE] = '2'
        hmAutoGenAccessId['appInfo'] = 'Error from AutoGen Access Id'
        oUserProfileAutoregUtility.generateAutoGenAccessId({ Map<String, Object> m -> true }) >> hmAutoGenAccessId
        cgRestClientObj.getCGSyncCall({ Map<String, Object> m -> true }) >> hmCGResponse
        internalIDPRestClient.callIDPRestClient({ Map<String, Object> m -> true }) >> hmCGResponse
        internalIDPRestClient.callIDPRestClient(_) >> hmCGResponse
        hmResult = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)
        // when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        // then:
        // stAppInfo == 'Error from AutoGen Access Id'
    }


    def "test register wireless null response"() throws Exception {

        given:
        hmResult = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Null response returned from CGRestClient'
    }


    def "test register wireless success"() throws Exception {

        given:
        HashMap hmSuccessRetuenGuid = new HashMap()
        hmSuccessRetuenGuid.putAll(hmSuccessResponse)
        hmSuccessRetuenGuid['guid'] = '12345678'
        hmInput['isConnectedCar'] = 'N'
        oUserProfileAutoregUtility.generateAutoGenAccessId({ Map<String, Object> m -> true }) >> hmAutoGenAccessId
        internalIDPRestClient.callIDPRestClient({ Map<String, Object> m -> true }) >> hmCGResponse
        internalIDPRestClient.callIDPRestClient(_) >> hmCGResponse
        cgRestClientObj.getCGSyncCall({ Map<String, Object> m -> true }) >> hmCGResponse
        accountAutoRegDBHelper.queryAccountAutoReg({ Map<String, Object> m -> true }) >> hmSuccessRetuenGuid
        accountAutoRegDBHelper.queryAccountAutoReg(_) >> hmSuccessRetuenGuid

        hmResult = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'
    }

    def "test register wireless success case2"() throws Exception {

        given:
        HashMap hmSuccessRetuenGuid = new HashMap()
        hmSuccessRetuenGuid.putAll(hmSuccessResponse)
        hmSuccessRetuenGuid['guid'] = '12345678'
        hmInput['isConnectedCar'] = 'N'

        HashMap subscriberNumber = new HashMap()
        HashMap hmAccount = new HashMap()
        HashMap hmContact = new HashMap()
        ArrayList subscriber = new ArrayList()
        subscriberNumber['subscriberId'] = '121321113'
        subscriberNumber['smsCapability'] = 'false'
        subscriberNumber['status'] = 'A'
        subscriber.add(subscriberNumber)
        ObjectMapper objectMapper = new ObjectMapper()
        ArrayNode anSubscribers = objectMapper.valueToTree(subscriber)
        hmAccount['contact'] = hmContact
        hmAccount['primaryAccountHolder'] = '123454'

        hmCGResponse['accounts'] = hmAccount
        hmCGResponse['appStatusCode'] = '0'
        hmCGResponse['subscribers'] = anSubscribers
        oUserProfileAutoregUtility.generateAutoGenAccessId({ Map<String, Object> m -> true }) >> hmAutoGenAccessId
        internalIDPRestClient.callIDPRestClient({ Map<String, Object> m -> true }) >> hmCGResponse
        internalIDPRestClient.callIDPRestClient(_) >> hmCGResponse
        cgRestClientObj.getCGSyncCall({ Map<String, Object> m -> true }) >> hmCGResponse
        accountAutoRegDBHelper.queryAccountAutoReg({ Map<String, Object> m -> true }) >> hmSuccessRetuenGuid
        accountAutoRegDBHelper.queryAccountAutoReg(_) >> hmSuccessRetuenGuid

        hmResult = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'
    }

    def "test register wireless success case3"() throws Exception {

        given:
        HashMap hmSuccessRetuenGuid = new HashMap()
        hmSuccessRetuenGuid.putAll(hmSuccessResponse)
        hmSuccessRetuenGuid['guid'] = '12345678'
        hmInput['isConnectedCar'] = 'N'
        HashMap subscriberNumber = new HashMap()
        HashMap hmAccount = new HashMap()
        HashMap hmContact = new HashMap()
        ArrayList subscriber = new ArrayList()
        subscriberNumber['subscriberId'] = '121321113'
        subscriberNumber['status'] = 'A'
        subscriber.add(subscriberNumber)
        ObjectMapper objectMapper = new ObjectMapper()
        ArrayNode anSubscribers = objectMapper.valueToTree(subscriber)
        hmAccount['contact'] = hmContact
        hmAccount['primaryAccountHolder'] = '123454'

        hmCGResponse['accounts'] = hmAccount
        hmCGResponse['appStatusCode'] = '0'
        hmCGResponse['subscribers'] = anSubscribers
        oUserProfileAutoregUtility.generateAutoGenAccessId({ Map<String, Object> m -> true }) >> hmAutoGenAccessId
        internalIDPRestClient.callIDPRestClient({ Map<String, Object> m -> true }) >> hmCGResponse
        internalIDPRestClient.callIDPRestClient(_) >> hmCGResponse
        cgRestClientObj.getCGSyncCall({ Map<String, Object> m -> true }) >> hmCGResponse
        accountAutoRegDBHelper.queryAccountAutoReg({ Map<String, Object> m -> true }) >> hmSuccessRetuenGuid
        accountAutoRegDBHelper.queryAccountAutoReg(_) >> hmSuccessRetuenGuid

        hmResult = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'
    }


    // Test for callCGInquireAcctProfile method when hmCGResponse is null or empty
    def "test callCGInquireAcctProfile null response"() throws Exception {
        given:
        cgRestClientObj.getCGSyncCall(_) >> null
        when:
        def result = wirelessAutoRegHelperObj.callCGInquireAcctProfile(hmInput)
        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Null response returned from CGRestClient'
    }

// Test for callInquireAssociatedAccessIds method when hmResponse is null or empty
    def "test callInquireAssociatedAccessIds null response"() throws Exception {
        given:
        internalIDPRestClient.callIDPRestClient(_) >> null
        when:
        def result = wirelessAutoRegHelperObj.callInquireAssociatedAccessIds(hmInput)
        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Null Response returned from MPSYSInternalRestClient.callIDPRestClient()'
    }

// Test for callInquireProfile method when hmResponse is null or empty
    def "test callInquireProfile null response"() throws Exception {
        given:
        internalIDPRestClient.callIDPRestClient(_) >> null
        when:
        def result = wirelessAutoRegHelperObj.callInquireProfile(hmInput, '123456')
        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Null Response returned from MPSYSInternalRestClient.callIDPRestClient()'
    }

// Test for callAddAssociation method when hmResponse is null or empty
    def "test callAddAssociation null response"() throws Exception {
        given:
        internalIDPRestClient.callIDPRestClient(_) >> null
        when:
        def result = wirelessAutoRegHelperObj.callAddAssociation(hmInput, 'MOBILITY', 'N')
        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Null Response returned from MPSYSInternalRestClient.callIDPRestClient()'
    }


    def "should call AddAssociation once with MOBILITY only when MOSUB is not eligible"() throws Exception {
        given:
        featureManager.isEnabled({ String s -> s == "svc-idgraph-wirelessautoreg-call-csi" }) >> false

        HashMap hmSuccessRetuenGuid = new HashMap()
        hmSuccessRetuenGuid.putAll(hmSuccessResponse)
        hmSuccessRetuenGuid['guid'] = '12345678'
        hmInput['isConnectedCar'] = 'N'
        hmInput['totalSubscribers'] = 2
    // Force MOSUB ineligible: missing MOSUB identifiers
    hmInput['mosubCTN'] = null
    hmInput['mosubSubId'] = null
        hmInput['SMSCapabilityIndicator'] = 'true'

        oUserProfileAutoregUtility.generateAutoGenAccessId({ Map<String, Object> m -> true }) >> hmAutoGenAccessId
        cgRestClientObj.getCGSyncCall({ Map<String, Object> m -> true }) >> hmCGResponse
        accountAutoRegDBHelper.queryAccountAutoReg({ Map<String, Object> m -> true }) >> hmSuccessRetuenGuid

        // InquireAssociatedAccessIds + InquireProfile should not block; return ERR_USER_NOT_FOUND so flow continues.
        HashMap inquireAAResp = new HashMap()
        inquireAAResp[MPSDefs.APP_STATUS_CODE] = MPSDefs.ERR_USER_NOT_FOUND
        inquireAAResp[CommonDefs.ASSOCIATED_USERS] = []
        // InquireProfile ignored for this scenario (GUID already present)
        HashMap inqProfileResp = new HashMap()
        inqProfileResp[MPSDefs.APP_STATUS_CODE] = MPSDefs.ERR_USER_NOT_FOUND

        // Batch AddAssociation success
        HashMap addAssocSuccess = new HashMap()
        addAssocSuccess[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        addAssocSuccess[MPSDefs.APP_INFO] = CommonDefs.COMMON_SUCCESS_MSG

    // Default internal calls succeed (explicit AddAssociation will still be asserted in then:)
    internalIDPRestClient.callIDPRestClient({ Map<String, Object> m -> true }) >> hmSuccessResponse
        List<Map<String, Object>> addAssociationRequestHolder = new ArrayList<>()

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
    1 * featureManager.isEnabled("svc-idgraph-wirelessautoreg-call-csi") >> false

        // Allow non-AddAssociation internal calls without over-specifying the whole flow
        2 * internalIDPRestClient.callIDPRestClient({ Map<String, Object> req ->
            req[CommonDefs.TRANSACTION_NAME] != "AddAssociation"
        }) >>> [inquireAAResp, inqProfileResp]

        1 * cgRestClientObj.getCGSyncCall({ Map<String, Object> req ->
            req["serviceType"] == "wireless" &&
                    req["apiName"] == "CGCustomerSearch" &&
                    req["topics"] == "accounts,subscribers"
        }) >> hmCGResponse

    1 * accountAutoRegDBHelper.queryAccountAutoReg({ Map<String, Object> req ->
        req[CommonDefs.SOR_ID] == hmInput[CommonDefs.SOR_ID] &&
            req[CommonDefs.SOR_INVARIANT_ID] == hmInput[CommonDefs.SOR_INVARIANT_ID] &&
            req[CommonDefs.TRANSACTION_NAME] == hmInput[CommonDefs.TRANSACTION_NAME] &&
            req[CommonDefs.CALLING_SYSTEM_ID] == hmInput[CommonDefs.CALLING_SYSTEM_ID]
    }) >> hmSuccessRetuenGuid

    1 * oUserProfileAutoregUtility.generateAutoGenAccessId({ Map<String, Object> req ->
        req[CommonDefs.SOR_ID] == hmInput[CommonDefs.SOR_ID] &&
            req[CommonDefs.SOR_INVARIANT_ID] == hmInput[CommonDefs.SOR_INVARIANT_ID] &&
            req["serviceName"] == "MOBILITY" &&
            req["isConnectedCar"] == "N"
    }) >> hmAutoGenAccessId

        1 * oUserProfileAutoregUtility.callAddUser({ Map<String, Object> req ->
            req[CommonDefs.SOR_ID] == hmInput[CommonDefs.SOR_ID] &&
                    req[CommonDefs.SOR_INVARIANT_ID] == hmInput[CommonDefs.SOR_INVARIANT_ID] &&
                    req["serviceName"] == "MOBILITY"
        }, "qay_test@att.com") >> hmSuccessResponse

        1 * internalIDPRestClient.callIDPRestClient({ Map<String, Object> req ->
            req[CommonDefs.TRANSACTION_NAME] == "AddAssociation" &&
                    req.containsKey("associationList")
        }) >> { Map<String, Object> req ->
            addAssociationRequestHolder.clear()
            addAssociationRequestHolder.add(req)
            return addAssocSuccess
        }

        1 * wirelessAutoRegQueueHelper.prepareEDDDataForAsyncCall({ Map<String, Object> req ->
            req[CommonDefs.SOR_ID] == hmInput[CommonDefs.SOR_ID] &&
                    req[CommonDefs.SOR_INVARIANT_ID] == hmInput[CommonDefs.SOR_INVARIANT_ID]
        }, "qay_test@att.com") >> hmSuccessResponse

        0 * _

        and:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == CommonDefs.COMMON_SUCCESS_MSG
    addAssociationRequestHolder.size() == 1
    Map<String, Object> addAssociationRequest = addAssociationRequestHolder.get(0)
    addAssociationRequest[CommonDefs.TRANSACTION_NAME] == "AddAssociation"
    ((List) addAssociationRequest["associationList"]).size() == 1
    ((Map) ((List) addAssociationRequest["associationList"])[0])["serviceName"] == "MOBILITY"
    }


    def "should call AddAssociation once with MOBILITY+MOSUB when MOSUB is eligible"() throws Exception {
        given:
        featureManager.isEnabled({ String s -> s == "svc-idgraph-wirelessautoreg-call-csi" }) >> false

        HashMap hmSuccessRetuenGuid = new HashMap()
        hmSuccessRetuenGuid.putAll(hmSuccessResponse)
        hmSuccessRetuenGuid['guid'] = '12345678'
        hmInput['isConnectedCar'] = 'N'
        hmInput['totalSubscribers'] = 1
        hmInput['mosubCTN'] = '2222222222'
        hmInput['mosubSubId'] = 'sub-2'
        hmInput['SMSCapabilityIndicator'] = 'true'

        oUserProfileAutoregUtility.generateAutoGenAccessId({ Map<String, Object> m -> true }) >> hmAutoGenAccessId
        cgRestClientObj.getCGSyncCall({ Map<String, Object> m -> true }) >> hmCGResponse
        accountAutoRegDBHelper.queryAccountAutoReg({ Map<String, Object> m -> true }) >> hmSuccessRetuenGuid

        HashMap inquireAAResp = new HashMap()
        inquireAAResp[MPSDefs.APP_STATUS_CODE] = MPSDefs.ERR_USER_NOT_FOUND
        inquireAAResp[CommonDefs.ASSOCIATED_USERS] = []
        HashMap inqProfileResp = new HashMap()
        inqProfileResp[MPSDefs.APP_STATUS_CODE] = MPSDefs.ERR_USER_NOT_FOUND

        HashMap addAssocSuccess = new HashMap()
        addAssocSuccess[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        addAssocSuccess[MPSDefs.APP_INFO] = CommonDefs.COMMON_SUCCESS_MSG

    // Default internal calls succeed (explicit AddAssociation will still be asserted in then:)
    internalIDPRestClient.callIDPRestClient({ Map<String, Object> m -> true }) >> hmSuccessResponse
        List<Map<String, Object>> addAssociationRequestHolder = new ArrayList<>()

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        1 * featureManager.isEnabled("svc-idgraph-wirelessautoreg-call-csi") >> false

        // Allow non-AddAssociation internal calls without over-specifying the whole flow
        2 * internalIDPRestClient.callIDPRestClient({ Map<String, Object> req ->
            req[CommonDefs.TRANSACTION_NAME] != "AddAssociation"
        }) >>> [inquireAAResp, inqProfileResp]

        1 * cgRestClientObj.getCGSyncCall({ Map<String, Object> req ->
            req["serviceType"] == "wireless" &&
                    req["apiName"] == "CGCustomerSearch" &&
                    req["topics"] == "accounts,subscribers"
        }) >> hmCGResponse

    1 * accountAutoRegDBHelper.queryAccountAutoReg({ Map<String, Object> req ->
        req[CommonDefs.SOR_ID] == hmInput[CommonDefs.SOR_ID] &&
            req[CommonDefs.SOR_INVARIANT_ID] == hmInput[CommonDefs.SOR_INVARIANT_ID] &&
            req[CommonDefs.TRANSACTION_NAME] == hmInput[CommonDefs.TRANSACTION_NAME] &&
            req[CommonDefs.CALLING_SYSTEM_ID] == hmInput[CommonDefs.CALLING_SYSTEM_ID]
    }) >> hmSuccessRetuenGuid

    1 * oUserProfileAutoregUtility.generateAutoGenAccessId({ Map<String, Object> req ->
        req[CommonDefs.SOR_ID] == hmInput[CommonDefs.SOR_ID] &&
            req[CommonDefs.SOR_INVARIANT_ID] == hmInput[CommonDefs.SOR_INVARIANT_ID] &&
            req["serviceName"] == "MOBILITY" &&
            req["isConnectedCar"] == "N"
    }) >> hmAutoGenAccessId

        1 * oUserProfileAutoregUtility.callAddUser({ Map<String, Object> req ->
            req[CommonDefs.SOR_ID] == hmInput[CommonDefs.SOR_ID] &&
                    req[CommonDefs.SOR_INVARIANT_ID] == hmInput[CommonDefs.SOR_INVARIANT_ID] &&
                    req["serviceName"] == "MOBILITY"
        }, "qay_test@att.com") >> hmSuccessResponse

        1 * internalIDPRestClient.callIDPRestClient({ Map<String, Object> req ->
            req[CommonDefs.TRANSACTION_NAME] == "AddAssociation" &&
                    req.containsKey("associationList")
        }) >> { Map<String, Object> req ->
            addAssociationRequestHolder.clear()
            addAssociationRequestHolder.add(req)
            return addAssocSuccess
        }

        1 * wirelessAutoRegQueueHelper.prepareEDDDataForAsyncCall({ Map<String, Object> req ->
            req[CommonDefs.SOR_ID] == hmInput[CommonDefs.SOR_ID] &&
                    req[CommonDefs.SOR_INVARIANT_ID] == hmInput[CommonDefs.SOR_INVARIANT_ID]
        }, "qay_test@att.com") >> hmSuccessResponse

        0 * _

        and:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == CommonDefs.COMMON_SUCCESS_MSG
    addAssociationRequestHolder.size() == 1
    Map<String, Object> addAssociationRequest = addAssociationRequestHolder.get(0)
    addAssociationRequest[CommonDefs.TRANSACTION_NAME] == "AddAssociation"
    ((List) addAssociationRequest["associationList"]).size() == 2
    ((Map) ((List) addAssociationRequest["associationList"])[0])["serviceName"] == "MOBILITY"
    ((Map) ((List) addAssociationRequest["associationList"])[1])["serviceName"] == "MOSUB"
    }


    def "should not include MOSUB in batch when ConnectedCar ban even if eligible"() throws Exception {
        given:
        featureManager.isEnabled({ String s -> s == "svc-idgraph-wirelessautoreg-call-csi" }) >> false

        HashMap hmSuccessRetuenGuid = new HashMap()
        hmSuccessRetuenGuid.putAll(hmSuccessResponse)
        hmSuccessRetuenGuid['guid'] = '12345678'

        hmInput['isConnectedCar'] = 'Y'
        hmInput['totalSubscribers'] = 1
        hmInput['mosubCTN'] = '3333333333'
        hmInput['mosubSubId'] = 'sub-3'
        hmInput['SMSCapabilityIndicator'] = 'true'

        oUserProfileAutoregUtility.generateAutoGenAccessId({ Map<String, Object> m -> true }) >> hmAutoGenAccessId
        cgRestClientObj.getCGSyncCall({ Map<String, Object> m -> true }) >> hmCGResponse
        accountAutoRegDBHelper.queryAccountAutoReg({ Map<String, Object> m -> true }) >> hmSuccessRetuenGuid

        HashMap inquireAAResp = new HashMap()
        inquireAAResp[MPSDefs.APP_STATUS_CODE] = MPSDefs.ERR_USER_NOT_FOUND
        inquireAAResp[CommonDefs.ASSOCIATED_USERS] = []
        HashMap inqProfileResp = new HashMap()
        inqProfileResp[MPSDefs.APP_STATUS_CODE] = MPSDefs.ERR_USER_NOT_FOUND

        HashMap addAssocSuccess = new HashMap()
        addAssocSuccess[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        addAssocSuccess[MPSDefs.APP_INFO] = CommonDefs.COMMON_SUCCESS_MSG

    // Default internal calls succeed (explicit AddAssociation will still be asserted in then:)
    internalIDPRestClient.callIDPRestClient({ Map<String, Object> m -> true }) >> hmSuccessResponse
        List<Map<String, Object>> addAssociationRequestHolder = new ArrayList<>()

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        1 * featureManager.isEnabled("svc-idgraph-wirelessautoreg-call-csi") >> false

        // Allow non-AddAssociation internal calls without over-specifying the whole flow
        2 * internalIDPRestClient.callIDPRestClient({ Map<String, Object> req ->
            req[CommonDefs.TRANSACTION_NAME] != "AddAssociation"
        }) >>> [inquireAAResp, inqProfileResp]

        1 * cgRestClientObj.getCGSyncCall({ Map<String, Object> req ->
            req["serviceType"] == "wireless" &&
                    req["apiName"] == "CGCustomerSearch" &&
                    req["topics"] == "accounts,subscribers"
        }) >> hmCGResponse

    1 * accountAutoRegDBHelper.queryAccountAutoReg({ Map<String, Object> req ->
        req[CommonDefs.SOR_ID] == hmInput[CommonDefs.SOR_ID] &&
            req[CommonDefs.SOR_INVARIANT_ID] == hmInput[CommonDefs.SOR_INVARIANT_ID] &&
            req[CommonDefs.TRANSACTION_NAME] == hmInput[CommonDefs.TRANSACTION_NAME] &&
            req[CommonDefs.CALLING_SYSTEM_ID] == hmInput[CommonDefs.CALLING_SYSTEM_ID]
    }) >> hmSuccessRetuenGuid

    1 * oUserProfileAutoregUtility.generateAutoGenAccessId({ Map<String, Object> req ->
        req[CommonDefs.SOR_ID] == hmInput[CommonDefs.SOR_ID] &&
            req[CommonDefs.SOR_INVARIANT_ID] == hmInput[CommonDefs.SOR_INVARIANT_ID] &&
            req["serviceName"] == "MOBILITY" &&
            req["isConnectedCar"] == "Y"
    }) >> hmAutoGenAccessId

        1 * oUserProfileAutoregUtility.callAddUser({ Map<String, Object> req ->
            req[CommonDefs.SOR_ID] == hmInput[CommonDefs.SOR_ID] &&
                    req[CommonDefs.SOR_INVARIANT_ID] == hmInput[CommonDefs.SOR_INVARIANT_ID] &&
                    req["serviceName"] == "MOBILITY"
        }, "qay_test@att.com") >> hmSuccessResponse

        1 * internalIDPRestClient.callIDPRestClient({ Map<String, Object> req ->
            req[CommonDefs.TRANSACTION_NAME] == "AddAssociation" &&
                    req.containsKey("associationList")
        }) >> { Map<String, Object> req ->
            addAssociationRequestHolder.clear()
            addAssociationRequestHolder.add(req)
            return addAssocSuccess
        }

        1 * wirelessAutoRegQueueHelper.prepareEDDDataForAsyncCall({ Map<String, Object> req ->
            req[CommonDefs.SOR_ID] == hmInput[CommonDefs.SOR_ID] &&
                    req[CommonDefs.SOR_INVARIANT_ID] == hmInput[CommonDefs.SOR_INVARIANT_ID]
        }, "qay_test@att.com") >> hmSuccessResponse

        0 * _

        and:
        result != null
        result[CommonDefs.COMMON_APP_INFO] == CommonDefs.COMMON_SUCCESS_MSG
    addAssociationRequestHolder.size() == 1
    Map<String, Object> addAssociationRequest = addAssociationRequestHolder.get(0)
    addAssociationRequest[CommonDefs.TRANSACTION_NAME] == "AddAssociation"
    ((List) addAssociationRequest["associationList"]).size() == 1
    ((Map) ((List) addAssociationRequest["associationList"])[0])["serviceName"] == "MOBILITY"
    }

// Test for callEDDNotification method when hmResult is null or empty
    def "test callEDDNotification null response"() throws Exception {
        given:
        wirelessAutoRegQueueHelper.prepareEDDDataForAsyncCall(_, _) >> null
        when:
        def result = wirelessAutoRegHelperObj.callEDDNotification(hmInput, 'validSLID')
        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Null Response returned from prepareEDDDataForAsyncCall()'
    }

    def "test sGlobalUniqueId is null and callOrderGraph returns successful response"() {
        given:
        hmOGResponse.put(MPSDefs.APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)

        def dataMap = new HashMap()
        def getOrdersMap = new HashMap()
        def ordersList = new ArrayList()
        def orderMap = new HashMap()
        def customerMap = new HashMap()
        customerMap.put("globalUserId", "123456")
        orderMap.put("customer", customerMap)
        ordersList.add(orderMap)
        getOrdersMap.put("orders", ordersList)
        dataMap.put("getOrders", getOrdersMap)
        hmOGResponse.put("data", dataMap)
        externalDestinationHelper.callOrderGraph(_) >> hmOGResponse

        HashMap hmSuccessRetuenGuid = new HashMap()
        hmSuccessRetuenGuid.putAll(hmSuccessResponse)
        hmSuccessRetuenGuid['guid'] = '12345678'
        oUserProfileAutoregUtility.generateAutoGenAccessId({ Map<String, Object> m -> true }) >> hmAutoGenAccessId
        internalIDPRestClient.callIDPRestClient({ Map<String, Object> m -> true }) >> hmCGResponse
        internalIDPRestClient.callIDPRestClient(_) >> hmCGResponse
        cgRestClientObj.getCGSyncCall({ Map<String, Object> m -> true }) >> hmCGResponse
        accountAutoRegDBHelper.queryAccountAutoReg({ Map<String, Object> m -> true }) >> hmSuccessResponse
        accountAutoRegDBHelper.queryAccountAutoReg(_) >> hmSuccessResponse

        hmResult = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'
    }

    def "test wireless autoreg when account already registered"() throws Exception {

        given:
        HashMap hmSuccess = new HashMap()
        hmSuccess.putAll(hmSuccessResponse)
        hmSuccess['guid'] = '12345678'

        //inquire associated response
        def hmAAResponse = new HashMap()
        def associatedUsersList = new ArrayList()

        def user1 = new HashMap()
        user1.put(CommonDefs.GUID, "123456")
        user1.put(CommonDefs.FIRST_NAME, "John")
        user1.put(CommonDefs.LAST_NAME, "Doe")
        user1.put(CommonDefs.CONTACT_EMAIL, "john.doe@example.com")

        def user2 = new HashMap()
        user2.put(CommonDefs.GUID, "789012")
        user2.put(CommonDefs.FIRST_NAME, "Jane")
        user2.put(CommonDefs.LAST_NAME, "Smith")
        user2.put(CommonDefs.CONTACT_EMAIL, "jane.smith@example.com")

        associatedUsersList.add(user1)
        associatedUsersList.add(user2)

        hmAAResponse.put(CommonDefs.ASSOCIATED_USERS, associatedUsersList)
        hmAAResponse.put(MPSDefs.APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        hmAAResponse.put(CommonDefs.COMMON_APP_INFO, "Success")

        cgRestClientObj.getCGSyncCall(_) >> null
        internalIDPRestClient.callIDPRestClient(_) >> hmAAResponse

        hmResult = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Null response returned from CGRestClient'
    }

    def "test valid InquireProfile response with member details"() {
        given:
        hmInput[CommonDefs.SOR_INVARIANT_ID] = '2462729299'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.TRANSACTION_NAME] = 'WirelessAutoReg'
        hmInput[CommonDefs.GUID] = '12345678'
        hmCGResponse[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        HashMap hmIPResponse = new HashMap()
        HashMap hmDBMember = new HashMap()
        hmDBMember[CommonDefs.MEMBER_NUM] = '987654321'
        hmDBMember[CommonDefs.MIGRATION_IND] = 'Y'
        hmDBMember[CommonDefs.ACTIVATED_IND] = 'Y'
        hmDBMember[CommonDefs.AUTO_GENERATED_IND] = 'N'
        hmDBMember[CommonDefs.MEMBER_NAME] = 'John Doe'
        hmDBMember['parentChildInd'] = 'S'
        hmIPResponse['member'] = hmDBMember
        hmIPResponse[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        Map hmResult = CommonUtil.hashMap
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] = "SUCCESS"
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] = "0"
        hmResult[CommonDefs.GUID] = '12345678'
        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        internalIDPRestClient.callIDPRestClient(_ as HashMap) >> hmIPResponse
        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmResult
        wirelessAutoRegHelperObj.sMaxAllowedSvcsAccounts = "5"

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result['appStatusCode'] == "0"
    }

    def "test active fraud lock"() {
        given:
        hmInput[CommonDefs.SOR_INVARIANT_ID] = '2462729299'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.TRANSACTION_NAME] = 'WirelessAutoReg'
        hmInput[CommonDefs.GUID] = '12345678'
        hmCGResponse[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        HashMap hmIPResponse = new HashMap()
        HashMap hmDBUserFraudLock = new HashMap()
        hmDBUserFraudLock['userLockLevel'] = 'HIGH'
        hmIPResponse[CommonDefs.USER_FRAUD_LOCK] = hmDBUserFraudLock
        hmIPResponse[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        Map hmResult = CommonUtil.hashMap
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] = "SUCCESS"
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] = "0"
        hmResult[CommonDefs.GUID] = '12345678'
        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        internalIDPRestClient.callIDPRestClient(_ as HashMap) >> hmIPResponse
        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmResult

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result['appStatusCode'] == "602"
    }



    def "handle digital life service present"() {
        given:
        hmInput[CommonDefs.SOR_INVARIANT_ID] = '2462729299'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.TRANSACTION_NAME] = 'WirelessAutoReg'
        hmInput[CommonDefs.GUID] = '12345678'
        hmCGResponse[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        HashMap hmIPResponse = new HashMap()
        HashMap hmDBMember = new HashMap()
        hmDBMember['parentChildInd'] = 'S'
        hmIPResponse['member'] = hmDBMember
        ArrayList alDBMemSvcs = new ArrayList()
        HashMap hmDBSvc = new HashMap()
        hmDBSvc['sorName'] = 'DL'
        alDBMemSvcs.add(hmDBSvc)
        hmIPResponse['memberservicerole'] = alDBMemSvcs
        hmIPResponse[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        Map hmResult = CommonUtil.hashMap
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] = "SUCCESS"
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] = "0"
        hmResult[CommonDefs.GUID] = '12345678'
        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        internalIDPRestClient.callIDPRestClient(_ as HashMap) >> hmIPResponse
        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmResult
        wirelessAutoRegHelperObj.sMaxAllowedSvcsAccounts = "5"

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result['appStatusCode'] == "602"
    }


    def "handle max allowed services accounts exceeded"() {
        given:
        hmInput[CommonDefs.SOR_INVARIANT_ID] = '2462729299'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.TRANSACTION_NAME] = 'WirelessAutoReg'
        hmInput[CommonDefs.GUID] = '12345678'
        hmCGResponse[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        HashMap hmIPResponse = new HashMap()
        HashMap hmDBMember = new HashMap()
        hmDBMember['parentChildInd'] = 'S'
        hmIPResponse['member'] = hmDBMember
        ArrayList alDBMemSvcs = new ArrayList()
        alDBMemSvcs.add(new HashMap())
        alDBMemSvcs.add(new HashMap())
        hmIPResponse['memberservicerole'] = alDBMemSvcs
        hmIPResponse[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        Map hmResult = CommonUtil.hashMap
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] = "SUCCESS"
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] = "0"
        hmResult[CommonDefs.GUID] = '12345678'
        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        internalIDPRestClient.callIDPRestClient(_ as HashMap) >> hmIPResponse
        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmResult
        wirelessAutoRegHelperObj.sMaxAllowedSvcsAccounts = "1"

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result['appStatusCode'] == "602"
    }


    def "handle max allowed services accounts not configured"() {
        given:
        hmInput[CommonDefs.SOR_INVARIANT_ID] = '2462729299'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.TRANSACTION_NAME] = 'WirelessAutoReg'
        hmInput[CommonDefs.GUID] = '12345678'
        hmCGResponse[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        HashMap hmIPResponse = new HashMap()
        HashMap hmDBMember = new HashMap()
        hmDBMember['parentChildInd'] = 'S'
        hmIPResponse['member'] = hmDBMember
        hmIPResponse[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        Map hmResult = CommonUtil.hashMap
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] = "SUCCESS"
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] = "0"
        hmResult[CommonDefs.GUID] = '12345678'
        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        internalIDPRestClient.callIDPRestClient(_ as HashMap) >> hmIPResponse
        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmResult
        wirelessAutoRegHelperObj.sMaxAllowedSvcsAccounts = null

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result['appInfo'] == "The value of checkAccessIdMergeEligibility MaxAllowedSvcsAccounts is not configured in property files"
    }

    def "handle null or empty OrderGraph response"() {
        given:
        hmInput[CommonDefs.SOR_INVARIANT_ID] = '2462729299'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.TRANSACTION_NAME] = 'WirelessAutoReg'
        hmInput[CommonDefs.GUID] = '12345678'
        hmCGResponse[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        HashMap hmOGResponse = new HashMap()
        hmOGResponse[MPSDefs.APP_STATUS_MSG] = "Null Response returned from IDP MS call for OrderGraph"
        Map hmResult = CommonUtil.hashMap
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] = "SUCCESS"
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] = "0"
        hmResult[CommonDefs.GUID] = null
        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        internalIDPRestClient.callIDPRestClient(_ as HashMap) >> hmCGResponse
        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmResult
        externalDestinationHelper.callOrderGraph(_ as HashMap) >> hmOGResponse

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result['appInfo'] == "SYSTEM ERROR"
    }
    def "handle error from inquireProfile operation call"() {
        given:
        hmInput[CommonDefs.SOR_INVARIANT_ID] = '2462729299'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.TRANSACTION_NAME] = 'WirelessAutoReg'
        hmInput[CommonDefs.GUID] = '12345678'
        hmCGResponse[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        HashMap hmIPResponse = new HashMap()
        hmIPResponse[MPSDefs.APP_STATUS_CODE] = "602"
        hmIPResponse[MPSDefs.APP_INFO] = 'SYSTEM ERROR'
        Map hmResult = CommonUtil.hashMap
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] = "SUCCESS"
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] = "0"
        hmResult[CommonDefs.GUID] = '12345678'
        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        internalIDPRestClient.callIDPRestClient(_ as HashMap) >> hmIPResponse
        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmResult

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result['appInfo'] == "SYSTEM ERROR"
    }

    def "handle parentChildInd not S"() {
        given:
        hmInput[CommonDefs.SOR_INVARIANT_ID] = '2462729299'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.TRANSACTION_NAME] = 'WirelessAutoReg'
        hmInput[CommonDefs.GUID] = '12345678'
        hmCGResponse[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        HashMap hmIPResponse = new HashMap()
        HashMap hmDBMember = new HashMap()
        hmDBMember['parentChildInd'] = 'P'
        hmIPResponse['member'] = hmDBMember
        hmIPResponse[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        Map hmResult = CommonUtil.hashMap
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] = "SUCCESS"
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] = "0"
        hmResult[CommonDefs.GUID] = '12345678'
        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse
        internalIDPRestClient.callIDPRestClient(_ as HashMap) >> hmIPResponse
        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmResult

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result['appStatusMsg'] == "ERR_CONFIG"
    }

    // Spock tests for callCSIInquireAcctProfile
    @Unroll
    def "should handle CSIInquireAcctProfile response for #scenarioName"() {
        given: "Mocks and input for CSIInquireAcctProfile"
        featureManager.isEnabled(_)>>true
        Map<String, Object> hmInput = new HashMap<>()
        hmInput.put("idpTraceId", "trace-123")
        hmInput.put(CommonDefs.SOR_INVARIANT_ID, "BAN123")
        hmInput.put(CommonDefs.TRANSACTION_NAME, "CSIInquireAccountProfile")
        hmInput.put(CommonDefs.CALLING_SYSTEM_ID, "IDP")

        Map<String, Object> hmCSIIAPinput = new HashMap<>()
        hmCSIIAPinput.put(CommonDefs.TRANSACTION_ID, "trace-123")
        hmCSIIAPinput.put(CommonDefs.TRANSACTION_NAME, "CSIInquireAccountProfile")
        hmCSIIAPinput.put(CommonDefs.CALLING_SYSTEM_ID, "IDP")
        hmCSIIAPinput.put(CommonDefs.EVENTNAME, "CSIInquireAccountProfile")
        hmCSIIAPinput.put(CommonDefs.SUBSCRIBER_MASK, "SL:SN:SD")
        hmCSIIAPinput.put(CommonDefs.BILLING_ACCOUNT_NUMBER, "BAN123")

        InquireAccountProfileRequestInfo requestInfo = new InquireAccountProfileRequestInfo()
        Map<String, Object> expectedResponse = responseType == "valid" ? ["status": "SUCCESS", "account": "ACC123"] : null
        Map<String, Object> expectedErrorMap = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "Null response returned from CGRestClient")

        0 * csiRequestBuilder.buildCSIIAPRequest({ Map<String, Object> req ->
            req == hmCSIIAPinput
        }) >> requestInfo
        0 * csiSoapHandler.invokeCSIIAP(requestInfo) >> (responseType == "empty" ? [:] : expectedResponse)

        when: "callCSIInquireAcctProfile is called"
        Map<String, Object> result = wirelessAutoRegHelperObj.callCSIInquireAcctProfile(hmInput)

        then: "Validate result attributes"
        if (responseType == "valid") {
            result != null
            result["status"] == "SUCCESS"
            result["account"] == "ACC123"
        } else {
            result != null
            result[CommonDefs.COMMON_APP_INFO] == "Null response returned from CSIIAP"
            result[CErrorDefs.ERR_SYS_APPL_NUM] != null
        }

        where: "Different CSI response scenarios"
        scenarioName         | responseType
        "null response"      | "null"

    }


    def "should return true for numeric string in isNumeric"() {
        expect:
        WirelessAutoRegHelper.isNumeric("12345")
        WirelessAutoRegHelper.isNumeric("-12345")
        !WirelessAutoRegHelper.isNumeric("12a45")
        !WirelessAutoRegHelper.isNumeric("")
    }

    @Unroll
    def "should populate hmInput correctly in processCSIIAPResponse for #scenarioName"() {
        given: "A CSI IAP response and input map"
        Map<String, Object> hmInput = new HashMap<>()
        Map<String, Object> hmIAPResponse = inputResponse

        when: "processCSIIAPResponse is called"
        wirelessAutoRegHelperObj.processCSIIAPResponse(hmIAPResponse, hmInput)

        then: "hmInput is populated as expected"
        hmInput.get("MOBILITY_ACCOUNT_TYPE") == expectedAcctType
        hmInput.get("MOBILITY_ACCOUNT_SUBTYPE") == expectedAcctSubType
        hmInput.get(CommonDefs.CONTACT_EMAIL) == expectedEmail
        hmInput.get("CBRCTN") == expectedCBRCTN
        hmInput.get("totalSubscribers") == expectedTotalSubscribers
        hmInput.get("mosubCTN") == expectedMosubCTN
        hmInput.get("mosubSubId") == expectedMosubSubId
        hmInput.get("SMSCapabilityIndicator") == expectedSMSCap

        where:
        scenarioName | inputResponse | expectedAcctType | expectedAcctSubType | expectedEmail | expectedCBRCTN | expectedTotalSubscribers | expectedMosubCTN | expectedMosubSubId | expectedSMSCap
        "all fields present, single subscriber, device info"
                     | [(CommonDefs.ACCOUNT): [
                (CommonDefs.ACCOUNT_TYPE): [(CommonDefs.ACCOUNT_TYPE): "POSTPAID", (CommonDefs.ACCOUNT_SUB_TYPE): "CONSUMER"],
                customer: [
                        email: [(CommonDefs.EMAIL_ADDRESS): "user@email.com"],
                        phone: [(CommonDefs.CAN_BE_REACHED_PHONE): "5551234"]
                ],
                subscriber: [[
                                     subscriber: [
                                             (CommonDefs.SUBSCRIBER_NUMBER): "1234567890",
                                             (CommonDefs.KEY_SUBSCRIPTION_ID): "subid1",
                                             deviceInformation: [device: [[smsCapabilityIndicator: true]]]
                                     ]
                             ]]
        ]]
                                     | "POSTPAID" | "CONSUMER" | "user@email.com" | "5551234" | 1 | "1234567890" | "subid1" | "true"
        "no account type, no customer, no subscriber" | [(CommonDefs.ACCOUNT): [:]] | null | null | null | null | null | null | null | null
        "email only in subscriber" | [
                (CommonDefs.ACCOUNT): [
                        (CommonDefs.ACCOUNT_TYPE): [:],
                        customer: [:],
                        subscriber: [[subscriber: [email: [(CommonDefs.EMAIL_ADDRESS): "sub@email.com"]]]]
                ]
        ] | null | null | "sub@email.com" | null | 1 | null | null | null

        "no device info" | [
                (CommonDefs.ACCOUNT): [
                        (CommonDefs.ACCOUNT_TYPE): [(CommonDefs.ACCOUNT_TYPE): "POSTPAID", (CommonDefs.ACCOUNT_SUB_TYPE): "CONSUMER"],
                        customer: [email: [(CommonDefs.EMAIL_ADDRESS): "user@email.com"]],
                        subscriber: [[subscriber: [
                                (CommonDefs.SUBSCRIBER_NUMBER): "1234567890",
                                (CommonDefs.KEY_SUBSCRIPTION_ID): "subid1"
                        ]]]
                ]
        ] | "POSTPAID" | "CONSUMER" | "user@email.com" | null | 1 | "1234567890" | "subid1" | null
        "empty response map" | [:] | null | null | null | null | null | null | null | null
    }


    def "test callCGInquireAcctProfile with error status"() {
        given:
        cgRestClientObj.getCGSyncCall(_) >> hmErrorResponse

        when:
        def result = wirelessAutoRegHelperObj.callCGInquireAcctProfile(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == "Error"
    }

    def "test callCSIInquireAcctProfile with error status"() {
        given:
        featureManager.isEnabled(_)>>true
        Map<String, Object> hmInput = new HashMap<>()
        hmInput.put("idpTraceId", "trace-123")
        hmInput.put(CommonDefs.SOR_INVARIANT_ID, "BAN123")
        hmInput.put(CommonDefs.TRANSACTION_NAME, "CSIInquireAccountProfile")
        hmInput.put(CommonDefs.CALLING_SYSTEM_ID, "IDP")

        Map<String, Object> hmCSIIAPinput = new HashMap<>()
        hmCSIIAPinput.put(CommonDefs.TRANSACTION_ID, "trace-123")
        hmCSIIAPinput.put(CommonDefs.TRANSACTION_NAME, "CSIInquireAccountProfile")
        hmCSIIAPinput.put(CommonDefs.CALLING_SYSTEM_ID, "IDP")
        hmCSIIAPinput.put(CommonDefs.EVENTNAME, "CSIInquireAccountProfile")
        hmCSIIAPinput.put(CommonDefs.SUBSCRIBER_MASK, "SL:SN:SD")
        hmCSIIAPinput.put(CommonDefs.BILLING_ACCOUNT_NUMBER, "BAN123")

        InquireAccountProfileRequestInfo requestInfo = new InquireAccountProfileRequestInfo()
        Map<String, Object> expectedResponse = ["status": "ERROR"]
        Map<String, Object> expectedErrorMap = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "Null response returned from CGRestClient")

        0 * csiRequestBuilder.buildCSIIAPRequest({ Map<String, Object> req ->
            req == hmCSIIAPinput
        }) >> requestInfo
        0 * csiSoapHandler.invokeCSIIAP(requestInfo) >> expectedResponse

        when: "callCSIInquireAcctProfile is called"
        Map<String, Object> result = wirelessAutoRegHelperObj.callCSIInquireAcctProfile(hmInput)

        then: "Validate result attributes"
        result != null
        result[CommonDefs.COMMON_APP_INFO] == "Null response returned from CSIIAP"
        result[CErrorDefs.ERR_SYS_APPL_NUM] != 602
    }

    def "test callEDDNotification with null from makeAsyncCall"() {
        given:
        wirelessAutoRegQueueHelper.prepareEDDDataForAsyncCall(_, _) >> null

        when:
        def result = wirelessAutoRegHelperObj.callEDDNotification(hmInput, 'validSLID')

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Null Response returned from prepareEDDDataForAsyncCall()'
    }

    @Unroll
    def "should handle callEDDNotification makeAsyncCall edge cases for #scenarioName"() {
        given: "Mocks and input for callEDDNotification edge cases"
        Map<String, Object> hmInput = new HashMap<>()
        String sValidSLID = "testSLID"
        Map<String, Object> prepareEDDResult = new HashMap<>()
        Map<String, Object> makeAsyncCallResult = new HashMap<>()
        ArrayList<Object> dbusInputList = new ArrayList<>()
        prepareEDDResult.put(MPSDefs.APP_STATUS_CODE, prepareStatusCode)
        prepareEDDResult.put(CommonDefs.CONSOLIDATED_DBUS_INPUT, dbusInputList)
        if (dbusInputPresent) {
            dbusInputList.add(new HashMap<>())
        }
        if (prepareStatusCode == CommonDefs.COMMON_SUCCESS && dbusInputPresent && makeAsyncCallResultStatus != null) {
            makeAsyncCallResult.put(MPSDefs.APP_STATUS_CODE, makeAsyncCallResultStatus)
            if (makeAsyncCallResultStatus != CommonDefs.COMMON_SUCCESS) {
                makeAsyncCallResult.put(CommonDefs.COMMON_APP_INFO, "ASYNC ERROR")
            }
        }
        wirelessAutoRegQueueHelper.prepareEDDDataForAsyncCall(_, _) >> prepareEDDResult
        if (prepareStatusCode == CommonDefs.COMMON_SUCCESS && dbusInputPresent) {
            wirelessAutoRegQueueHelper.makeAsyncCall(_, _) >> (makeAsyncCallResultStatus != null ? makeAsyncCallResult : null)
        }
        WirelessAutoRegHelper helper = new WirelessAutoRegHelper()
        helper.wirelessAutoRegQueueHelper = wirelessAutoRegQueueHelper


        when: "callEDDNotification is called"
        Map<String, Object> result = helper.callEDDNotification(hmInput, sValidSLID)

        then: "Validate all edge case outcomes"
        if (!prepareResultPresent) {
            result[CommonDefs.COMMON_APP_INFO] == 'Null Response returned from prepareEDDDataForAsyncCall()'
        } else if (prepareStatusCode != CommonDefs.COMMON_SUCCESS) {
            result[CommonDefs.COMMON_APP_INFO] == null || result[CommonDefs.COMMON_APP_INFO] == prepareEDDResult.get(CommonDefs.COMMON_APP_INFO)
        } else if (!dbusInputPresent) {
            result[CommonDefs.COMMON_APP_INFO] == 'dbus input is null from WirelessAutoRegQueueHelper. prepareEDDDataForAsyncCall()'
        } else if (makeAsyncCallResultStatus == null) {
            result[CommonDefs.COMMON_APP_INFO] == 'Null Response returned from makeAsyncCall()'
        } else if (makeAsyncCallResultStatus != CommonDefs.COMMON_SUCCESS) {
            result[CommonDefs.COMMON_APP_INFO] == 'ASYNC ERROR'
        } else {
            result[MPSDefs.APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
        }

        where: "All edge case scenarios for callEDDNotification"
        scenarioName                                 | prepareResultPresent | prepareStatusCode         | dbusInputPresent | makeAsyncCallResultStatus
        "prepareEDDDataForAsyncCall returns null"    | false               | null                     | false            | null
        "prepareEDDDataForAsyncCall error status"    | true                | '2'                      | false            | null
        "dbus input is null/empty"                   | true                | CommonDefs.COMMON_SUCCESS | false            | null
        "makeAsyncCall returns null"                 | true                | CommonDefs.COMMON_SUCCESS | true             | null
        "makeAsyncCall error status"                 | true                | CommonDefs.COMMON_SUCCESS | true             | '2'
        "makeAsyncCall success"                      | true                | CommonDefs.COMMON_SUCCESS | true             | CommonDefs.COMMON_SUCCESS
    }

    @Unroll
    def "should build correct attributeList and MOSUB fields in callAddAssociation for #scenarioName"() {
        given: "Mocks and input for callAddAssociation edge cases"
        Map<String, Object> hmInput = new HashMap<>()
        hmInput.put(CommonDefs.CALLING_SYSTEM_ID, "IDP")
        hmInput.put(CommonDefs.GUID, "12345678")
        if (mobilityAcctType != null) {
            hmInput.put("MOBILITY_ACCOUNT_TYPE", mobilityAcctType)
        }
        if (mobilityAcctSubType != null) {
            hmInput.put("MOBILITY_ACCOUNT_SUBTYPE", mobilityAcctSubType)
        }
        if (mosubSubId != null) {
            hmInput.put("mosubSubId", mosubSubId)
        }
        if (mosubCTN != null) {
            hmInput.put("mosubCTN", mosubCTN)
        }
        WirelessAutoRegHelper helper = new WirelessAutoRegHelper()
        helper.internalIDPRestClient = internalIDPRestClient

        when: "callAddAssociation is called"
        Map<String, Object> result = helper.callAddAssociation(hmInput, svcType, "N")

        then: "Validate attributeList and MOSUB fields via captured argument"
        1 * internalIDPRestClient.callIDPRestClient({ Map<String, Object> req ->
            List<Map<String, Object>> assocList = (List<Map<String, Object>>) req.get("associationList")
            assert assocList != null && assocList.size() == 1
            Map<String, Object> assoc = assocList.get(0)

            if (svcType == "MOBILITY") {
                if (mobilityAcctType != null && mobilityAcctSubType != null) {
                    List<Map<String, Object>> attrList = (List<Map<String, Object>>) assoc.get("attributeList")
                    assert attrList != null && attrList.size() == 2
                    assert attrList.any { it.attributeName == "MOBILITY_ACCOUNT_TYPE" && it.attributeValue == mobilityAcctType }
                    assert attrList.any { it.attributeName == "MOBILITY_ACCOUNT_SUBTYPE" && it.attributeValue == mobilityAcctSubType }
                } else if (mobilityAcctType != null) {
                    List<Map<String, Object>> attrList = (List<Map<String, Object>>) assoc.get("attributeList")
                    assert attrList != null && attrList.size() == 1
                    assert attrList[0].attributeName == "MOBILITY_ACCOUNT_TYPE"
                    assert attrList[0].attributeValue == mobilityAcctType
                } else if (mobilityAcctSubType != null) {
                    List<Map<String, Object>> attrList = (List<Map<String, Object>>) assoc.get("attributeList")
                    assert attrList != null && attrList.size() == 1
                    assert attrList[0].attributeName == "MOBILITY_ACCOUNT_SUBTYPE"
                    assert attrList[0].attributeValue == mobilityAcctSubType
                } else {
                    assert assoc.get("attributeList") == null
                }
                assert assoc.get(CommonDefs.SOR_INVARIANT_ID) == null
                assert assoc.get(CommonDefs.INSTANCE_ID) == null
            } else if (svcType == "MOSUB") {
                assert assoc.get(CommonDefs.SOR_INVARIANT_ID) == mosubSubId
                assert assoc.get(CommonDefs.INSTANCE_ID) == mosubCTN
                assert assoc.get("attributeList") == null
            } else {
                assert assoc.get("attributeList") == null
                assert assoc.get(CommonDefs.SOR_INVARIANT_ID) == null
                assert assoc.get(CommonDefs.INSTANCE_ID) == null
            }
            true
        }) >> [(CommonDefs.COMMON_APP_STATUS_CODE): CErrorDefs.COMMON_SUCCESS]

        and: "Result is success"
        result[CommonDefs.COMMON_APP_STATUS_CODE] == "0"

        where: "All edge case scenarios for callAddAssociation attribute block"
        scenarioName                                 | svcType     | mobilityAcctType | mobilityAcctSubType | mosubSubId | mosubCTN
        "Both account type and subtype present"      | "MOBILITY"  | "POSTPAID"       | "CONSUMER"          | null       | null
        "Only account type present"                  | "MOBILITY"  | "POSTPAID"       | null                | null       | null
        "Only account subtype present"               | "MOBILITY"  | null             | "CONSUMER"          | null       | null
        "Neither type nor subtype present"           | "MOBILITY"  | null             | null                | null       | null
        "MOSUB service type sets fields"             | "MOSUB"     | null             | null                | "subid1"   | "ctn1"
        "Other service type does nothing"            | "OTHER"     | null             | null                | null       | null
    }

    @Unroll
    def "should populate CBRCTN for #scenarioName"() {
        given: "A CG response containing cbrInfo data"
        WirelessAutoRegHelper helper = new WirelessAutoRegHelper()
        Map<String, Object> hmCGResponse = new HashMap<>()
        Map<String, Object> accounts = new HashMap<>()
        Map<String, Object> contact = new HashMap<>()
        Map<String, Object> cbrInfo = new HashMap<>()
        if (subContactType != null || phoneNumber != null) {
            if (subContactType != null) {
                cbrInfo.put("subContactType", subContactType)
            }
            if (phoneNumber != null) {
                cbrInfo.put("phoneNumber", phoneNumber)
            }
            contact.put("cbrInfo", cbrInfo)
        }
        accounts.put("contact", contact)
        hmCGResponse.put(CommonDefs.ACCOUNTS, accounts)
        Map<String, Object> hmInput = new HashMap<>()

        when: "populateInputFromCGResponse is invoked"
        ReflectionTestUtils.invokeMethod(helper, "populateInputFromCGResponse", hmCGResponse, hmInput)

        then: "CBRCTN presence matches expectation"
        if (expectedPresent) {
            assert hmInput.containsKey("CBRCTN")
            assert hmInput.get("CBRCTN") == expectedValue
        } else {
            assert !hmInput.containsKey("CBRCTN")
        }
        where: "Different cbrInfo scenarios"
        scenarioName        | subContactType | phoneNumber     | expectedPresent | expectedValue
        "primary valid"     | "primary"      | "1234567890"    | true            | "1234567890"
        "primary blank"     | "primary"      | ""              | false           | null
        "non primary"       | "secondary"    | "1234567890"    | false           | null
        "primary null phone"| "primary"      | null            | false           | null
    }


    // ===========================================================================================
    // NEW TESTS — Uncovered branches in WirelessAutoRegHelper
    // ===========================================================================================

    // ----- InquireAssociatedAccessIds error (non-success, non-USER_NOT_FOUND, non-400) -----

    def "verify InquireAssociatedAccessIds error halts registration"() {
        given:
        featureManager.isEnabled(_ as String) >> false

        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse

        HashMap hmAAErrorResp = new HashMap()
        hmAAErrorResp[MPSDefs.APP_STATUS_CODE] = '602'
        hmAAErrorResp[MPSDefs.APP_INFO] = 'System error from InquireAssociatedAccessIds'

        internalIDPRestClient.callIDPRestClient(_ as HashMap) >> hmAAErrorResp

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'System error from InquireAssociatedAccessIds'
    }

    // ----- callAddUser error when sValidSLID is present -----

    def "verify callAddUser error halts registration"() {
        given:
        featureManager.isEnabled(_ as String) >> false

        HashMap hmSuccessRetGuid = new HashMap()
        hmSuccessRetGuid.putAll(hmSuccessResponse)
        // No guid returned → triggers autoGenAccessId → callAddUser
        hmInput['isConnectedCar'] = 'N'

        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse

        // InquireAssociatedAccessIds returns user-not-found → continues flow
        HashMap hmAAResp = new HashMap()
        hmAAResp[MPSDefs.APP_STATUS_CODE] = MPSDefs.ERR_USER_NOT_FOUND
        hmAAResp[CommonDefs.ASSOCIATED_USERS] = []

        // queryAccountAutoReg returns no guid → triggers OrderGraph → no guid → autoGen
        HashMap hmDBResult = new HashMap()
        hmDBResult.putAll(hmSuccessResponse)
        hmDBResult[CommonDefs.GUID] = null

        // OrderGraph returns null
        externalDestinationHelper.callOrderGraph(_ as HashMap) >> null

        // AutoGenAccessId succeeds
        oUserProfileAutoregUtility.generateAutoGenAccessId(_ as HashMap) >> hmAutoGenAccessId

        // callAddUser fails
        HashMap hmAddUserError = new HashMap()
        hmAddUserError[MPSDefs.APP_STATUS_CODE] = '602'
        hmAddUserError[MPSDefs.APP_INFO] = 'Error from AddUser'
        oUserProfileAutoregUtility.callAddUser(_ as HashMap, _ as String) >> hmAddUserError

        internalIDPRestClient.callIDPRestClient(_ as HashMap) >>> [hmAAResp]
        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmDBResult

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Error from AddUser'
    }

    // ----- callAddAssociations error in main flow -----

    def "verify callAddAssociations error halts registration"() {
        given:
        featureManager.isEnabled(_ as String) >> false
        hmInput['isConnectedCar'] = 'N'

        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse

        HashMap hmAAResp = new HashMap()
        hmAAResp[MPSDefs.APP_STATUS_CODE] = MPSDefs.ERR_USER_NOT_FOUND
        hmAAResp[CommonDefs.ASSOCIATED_USERS] = []

        HashMap hmDBResult = new HashMap()
        hmDBResult.putAll(hmSuccessResponse)
        hmDBResult[CommonDefs.GUID] = '12345678'

        oUserProfileAutoregUtility.generateAutoGenAccessId(_ as HashMap) >> hmAutoGenAccessId
        oUserProfileAutoregUtility.callAddUser(_ as HashMap, _ as String) >> hmSuccessResponse

        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmDBResult

        // AddAssociation fails
        HashMap hmAddAssocError = new HashMap()
        hmAddAssocError[MPSDefs.APP_STATUS_CODE] = '602'
        hmAddAssocError[MPSDefs.APP_INFO] = 'Error from AddAssociation'

        // First call = InquireAssociatedAccessIds, second call = AddAssociation
        internalIDPRestClient.callIDPRestClient(_ as HashMap) >>> [hmAAResp, hmAddAssocError]

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Error from AddAssociation'
    }

    // ----- EDD notification error in main flow -----

    def "verify EDD notification error does not block overall success"() {
        given:
        featureManager.isEnabled(_ as String) >> false
        hmInput['isConnectedCar'] = 'N'

        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse

        HashMap hmAAResp = new HashMap()
        hmAAResp[MPSDefs.APP_STATUS_CODE] = MPSDefs.ERR_USER_NOT_FOUND
        hmAAResp[CommonDefs.ASSOCIATED_USERS] = []

        HashMap hmDBResult = new HashMap()
        hmDBResult.putAll(hmSuccessResponse)
        hmDBResult[CommonDefs.GUID] = '12345678'

        oUserProfileAutoregUtility.generateAutoGenAccessId(_ as HashMap) >> hmAutoGenAccessId
        oUserProfileAutoregUtility.callAddUser(_ as HashMap, _ as String) >> hmSuccessResponse

        HashMap hmAddAssocSuccess = new HashMap()
        hmAddAssocSuccess[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmAddAssocSuccess[MPSDefs.APP_INFO] = CommonDefs.COMMON_SUCCESS_MSG

        internalIDPRestClient.callIDPRestClient(_ as HashMap) >>> [hmAAResp, hmAddAssocSuccess]
        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmDBResult

        // EDD notification error
        HashMap hmEDDError = new HashMap()
        hmEDDError[MPSDefs.APP_STATUS_CODE] = '602'
        hmEDDError[MPSDefs.APP_INFO] = 'EDD notification failed'

        wirelessAutoRegQueueHelper.prepareEDDDataForAsyncCall(_ as HashMap, _ as String) >> hmEDDError

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        // EDD error is non-blocking — main flow returns success after EDD error
        result[CommonDefs.COMMON_APP_INFO] == CommonDefs.COMMON_SUCCESS_MSG
    }

    // ----- qarNotification="Y" path -----

    def "verify qarNotification Y when existing user with autoGenInd Y and no services"() {
        given:
        featureManager.isEnabled(_ as String) >> false
        hmInput['isConnectedCar'] = 'N'
        hmInput[CommonDefs.GUID] = '12345678'

        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse

        HashMap hmAAResp = new HashMap()
        hmAAResp[MPSDefs.APP_STATUS_CODE] = MPSDefs.ERR_USER_NOT_FOUND
        hmAAResp[CommonDefs.ASSOCIATED_USERS] = []

        // DB returns GUID → triggers InquireProfile
        HashMap hmDBResult = new HashMap()
        hmDBResult.putAll(hmSuccessResponse)
        hmDBResult[CommonDefs.GUID] = '12345678'

        // InquireProfile response — existing user with parentChildInd=S, autoGenInd=Y, migrationInd=N, activatedInd=N, no services
        HashMap hmIPResponse = new HashMap()
        HashMap hmDBMember = new HashMap()
        hmDBMember['parentChildInd'] = 'S'
        hmDBMember[CommonDefs.MEMBER_NUM] = '12345678'
        hmDBMember[CommonDefs.MIGRATION_IND] = 'N'
        hmDBMember[CommonDefs.ACTIVATED_IND] = 'N'
        hmDBMember[CommonDefs.AUTO_GENERATED_IND] = 'Y'
        hmDBMember[CommonDefs.MEMBER_NAME] = 'testuser'
        hmIPResponse['member'] = hmDBMember
        hmIPResponse['memberservicerole'] = null
        hmIPResponse[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        wirelessAutoRegHelperObj.sMaxAllowedSvcsAccounts = '5'

        HashMap hmAddAssocSuccess = new HashMap()
        hmAddAssocSuccess[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmAddAssocSuccess[MPSDefs.APP_INFO] = CommonDefs.COMMON_SUCCESS_MSG

        // InquireAssociatedAccessIds, InquireProfile, AddAssociation
        internalIDPRestClient.callIDPRestClient(_ as HashMap) >>> [hmAAResp, hmIPResponse, hmAddAssocSuccess]
        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmDBResult

        // EDD notification success
        wirelessAutoRegQueueHelper.prepareEDDDataForAsyncCall(_ as HashMap, _ as String) >> hmSuccessResponse

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == CommonDefs.COMMON_SUCCESS_MSG
    }

    // ----- isTransactionRollbackOnError=true in finally block -----

    def "verify isTransactionRollbackOnError sets rollback flag"() {
        given:
        featureManager.isEnabled(_ as String) >> false
        wirelessAutoRegHelperObj.isTransactionRollbackOnError = true

        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmErrorResponse
        internalIDPRestClient.callIDPRestClient(_ as HashMap) >> hmErrorResponse

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result['isTransactionRollback'] == 'Y'
    }

    // ----- ServiceException catch block -----
 
     def "verify ServiceException is caught and returns error map"() {
         given:
         featureManager.isEnabled(_ as String) >> false
 
         def serviceException = new ServiceException(ErrorMessages.MS_MPSYS_BE_602, 'CSI service unavailable')
 
         cgRestClientObj.getCGSyncCall(_ as HashMap) >> { throw serviceException }
 
         when:
         Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'ERR_SYS_APPL : CSI service unavailable'
    }

    // ----- General exception in registerWirelessUser -----
 
     def "verify general Exception is caught in registerWirelessUser"() {
         given:
         featureManager.isEnabled(_ as String) >> false
         cgRestClientObj.getCGSyncCall(_ as HashMap) >> { throw new RuntimeException('Unexpected error') }
 
         when:
         Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)
 
         then:
        result != null
        result[CommonDefs.COMMON_APP_INFO] != null
    }

    // ----- OrderGraph error response (non-success status code) -----

    def "verify OrderGraph error response is handled gracefully"() {
        given:
        featureManager.isEnabled(_ as String) >> false
        hmInput['isConnectedCar'] = 'N'

        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse

        HashMap hmAAResp = new HashMap()
        hmAAResp[MPSDefs.APP_STATUS_CODE] = MPSDefs.ERR_USER_NOT_FOUND
        hmAAResp[CommonDefs.ASSOCIATED_USERS] = []

        HashMap hmDBResult = new HashMap()
        hmDBResult.putAll(hmSuccessResponse)
        hmDBResult[CommonDefs.GUID] = null

        // OrderGraph returns error status
        HashMap hmOGError = new HashMap()
        hmOGError[MPSDefs.APP_STATUS_CODE] = '602'
        hmOGError[CommonDefs.COMMON_APP_INFO] = 'OrderGraph failed'
        externalDestinationHelper.callOrderGraph(_ as HashMap) >> hmOGError

        oUserProfileAutoregUtility.generateAutoGenAccessId(_ as HashMap) >> hmAutoGenAccessId
        oUserProfileAutoregUtility.callAddUser(_ as HashMap, _ as String) >> hmSuccessResponse

        HashMap hmAddAssocSuccess = new HashMap()
        hmAddAssocSuccess[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmAddAssocSuccess[MPSDefs.APP_INFO] = CommonDefs.COMMON_SUCCESS_MSG

        internalIDPRestClient.callIDPRestClient(_ as HashMap) >>> [hmAAResp, hmAddAssocSuccess]
        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmDBResult

        wirelessAutoRegQueueHelper.prepareEDDDataForAsyncCall(_ as HashMap, _ as String) >> hmSuccessResponse

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        // OG error is non-blocking, flow continues with autoGenAccessId
        result[CommonDefs.COMMON_APP_INFO] == CommonDefs.COMMON_SUCCESS_MSG
    }

    // ----- getGlobalUniqueIdFromOG edge cases -----

    def "verify getGlobalUniqueIdFromOG with null data returns null"() {
        given:
        HashMap hmOGResponse = new HashMap()
        hmOGResponse['data'] = null

        when:
        String guid = ReflectionTestUtils.invokeMethod(wirelessAutoRegHelperObj, 'getGlobalUniqueIdFromOG', hmOGResponse)

        then:
        guid == null
    }

    def "verify getGlobalUniqueIdFromOG with empty getOrders returns null"() {
        given:
        HashMap hmOGResponse = new HashMap()
        HashMap dataMap = new HashMap()
        dataMap['getOrders'] = null
        hmOGResponse['data'] = dataMap

        when:
        String guid = ReflectionTestUtils.invokeMethod(wirelessAutoRegHelperObj, 'getGlobalUniqueIdFromOG', hmOGResponse)

        then:
        guid == null
    }

    def "verify getGlobalUniqueIdFromOG with empty orders list returns null"() {
        given:
        HashMap hmOGResponse = new HashMap()
        HashMap dataMap = new HashMap()
        HashMap getOrdersMap = new HashMap()
        getOrdersMap['orders'] = new ArrayList()
        dataMap['getOrders'] = getOrdersMap
        hmOGResponse['data'] = dataMap

        when:
        String guid = ReflectionTestUtils.invokeMethod(wirelessAutoRegHelperObj, 'getGlobalUniqueIdFromOG', hmOGResponse)

        then:
        guid == null
    }

    def "verify getGlobalUniqueIdFromOG with null customer returns null"() {
        given:
        HashMap hmOGResponse = new HashMap()
        HashMap dataMap = new HashMap()
        HashMap getOrdersMap = new HashMap()
        ArrayList ordersList = new ArrayList()
        HashMap orderMap = new HashMap()
        orderMap['customer'] = null
        ordersList.add(orderMap)
        getOrdersMap['orders'] = ordersList
        dataMap['getOrders'] = getOrdersMap
        hmOGResponse['data'] = dataMap

        when:
        String guid = ReflectionTestUtils.invokeMethod(wirelessAutoRegHelperObj, 'getGlobalUniqueIdFromOG', hmOGResponse)

        then:
        guid == null
    }

    def "verify getGlobalUniqueIdFromOG extracts globalUserId successfully"() {
        given:
        HashMap hmOGResponse = new HashMap()
        HashMap dataMap = new HashMap()
        HashMap getOrdersMap = new HashMap()
        ArrayList ordersList = new ArrayList()
        HashMap orderMap = new HashMap()
        HashMap customerMap = new HashMap()
        customerMap['globalUserId'] = '987654321'
        orderMap['customer'] = customerMap
        ordersList.add(orderMap)
        getOrdersMap['orders'] = ordersList
        dataMap['getOrders'] = getOrdersMap
        hmOGResponse['data'] = dataMap

        when:
        String guid = ReflectionTestUtils.invokeMethod(wirelessAutoRegHelperObj, 'getGlobalUniqueIdFromOG', hmOGResponse)

        then:
        guid == '987654321'
    }

    // ----- getErrorcode method -----

    def "verify getErrorcode extracts last 3 digits"() {
        expect:
        wirelessAutoRegHelperObj.getErrorcode('SVC0602') == 602
    }

    def "verify getErrorcode with null returns -1"() {
        expect:
        wirelessAutoRegHelperObj.getErrorcode(null) == -1
    }

    def "verify getErrorcode with short string returns -1"() {
        expect:
        wirelessAutoRegHelperObj.getErrorcode('AB') == -1
    }

    def "verify getErrorcode with exactly 3 digit string"() {
        expect:
        wirelessAutoRegHelperObj.getErrorcode('100') == 100
    }

    // ----- CSI path through registerWirelessUser -----

    def "verify CSI path success through registerWirelessUser"() {
        given:
        featureManager.isEnabled(_ as String) >> true
        hmInput['isConnectedCar'] = 'N'

        HashMap hmCSIResp = new HashMap()
        hmCSIResp[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmCSIResp[MPSDefs.APP_INFO] = 'SUCCESS'
        hmCSIResp[CommonDefs.ACCOUNT] = [
            (CommonDefs.ACCOUNT_TYPE): [(CommonDefs.ACCOUNT_TYPE): 'POSTPAID', (CommonDefs.ACCOUNT_SUB_TYPE): 'CONSUMER'],
            customer: [email: [(CommonDefs.EMAIL_ADDRESS): 'test@att.com']],
            subscriber: []
        ]

        csiRequestBuilder.buildCSIIAPRequest(_ as HashMap) >> new InquireAccountProfileRequestInfo()
        csiSoapHandler.invokeCSIIAP(_) >> hmCSIResp

        HashMap hmAAResp = new HashMap()
        hmAAResp[MPSDefs.APP_STATUS_CODE] = MPSDefs.ERR_USER_NOT_FOUND
        hmAAResp[CommonDefs.ASSOCIATED_USERS] = []

        HashMap hmDBResult = new HashMap()
        hmDBResult.putAll(hmSuccessResponse)
        hmDBResult[CommonDefs.GUID] = '12345678'

        oUserProfileAutoregUtility.generateAutoGenAccessId(_ as HashMap) >> hmAutoGenAccessId
        oUserProfileAutoregUtility.callAddUser(_ as HashMap, _ as String) >> hmSuccessResponse

        HashMap hmAddAssocSuccess = new HashMap()
        hmAddAssocSuccess[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmAddAssocSuccess[MPSDefs.APP_INFO] = CommonDefs.COMMON_SUCCESS_MSG

        internalIDPRestClient.callIDPRestClient(_ as HashMap) >>> [hmAAResp, hmAddAssocSuccess]
        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmDBResult
        wirelessAutoRegQueueHelper.prepareEDDDataForAsyncCall(_ as HashMap, _ as String) >> hmSuccessResponse

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == CommonDefs.COMMON_SUCCESS_MSG
    }

    // ----- CSI IAP error response through registerWirelessUser -----

    def "verify CSI IAP error halts registration"() {
        given:
        featureManager.isEnabled(_ as String) >> true

        HashMap hmCSIError = new HashMap()
        hmCSIError[MPSDefs.APP_STATUS_CODE] = '602'
        hmCSIError[MPSDefs.APP_INFO] = 'CSI IAP failed'

        csiRequestBuilder.buildCSIIAPRequest(_ as HashMap) >> new InquireAccountProfileRequestInfo()
        csiSoapHandler.invokeCSIIAP(_) >> hmCSIError

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'CSI IAP failed'
    }

    
    // ----- callInquireAssociatedAccessIds success response -----

    def "verify callInquireAssociatedAccessIds success response"() {
        given:
        HashMap hmSuccess = new HashMap()
        hmSuccess[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmSuccess[CommonDefs.ASSOCIATED_USERS] = new ArrayList()
        internalIDPRestClient.callIDPRestClient(_ as HashMap) >> hmSuccess

        when:
        def result = wirelessAutoRegHelperObj.callInquireAssociatedAccessIds(hmInput)

        then:
        result[MPSDefs.APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    // ----- callInquireProfile success response -----

    def "verify callInquireProfile success response"() {
        given:
        HashMap hmSuccess = new HashMap()
        hmSuccess[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmSuccess['member'] = new HashMap()
        internalIDPRestClient.callIDPRestClient(_ as HashMap) >> hmSuccess

        when:
        def result = wirelessAutoRegHelperObj.callInquireProfile(hmInput, '123456')

        then:
        result[MPSDefs.APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    // ----- callCGInquireAcctProfile success response -----

    def "verify callCGInquireAcctProfile success response"() {
        given:
        HashMap hmSuccess = new HashMap()
        hmSuccess[CErrorDefs.COMMON_APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmSuccess[CErrorDefs.COMMON_APP_INFO] = 'Success'
        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmSuccess

        when:
        def result = wirelessAutoRegHelperObj.callCGInquireAcctProfile(hmInput)

        then:
        result[CErrorDefs.COMMON_APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    // ----- callCSIInquireAcctProfile success with valid response -----

    def "verify callCSIInquireAcctProfile returns valid response"() {
        given:
        HashMap hmCSISuccess = new HashMap()
        hmCSISuccess['status'] = 'SUCCESS'
        hmCSISuccess['account'] = 'ACC123'

        csiRequestBuilder.buildCSIIAPRequest(_ as HashMap) >> new InquireAccountProfileRequestInfo()
        csiSoapHandler.invokeCSIIAP(_) >> hmCSISuccess

        when:
        def result = wirelessAutoRegHelperObj.callCSIInquireAcctProfile(hmInput)

        then:
        result['status'] == 'SUCCESS'
        result['account'] == 'ACC123'
    }

    // ----- Non-numeric globalUniqueId skips InquireProfile -----

    def "verify non-numeric globalUniqueId skips InquireProfile"() {
        given:
        featureManager.isEnabled(_ as String) >> false
        hmInput['isConnectedCar'] = 'N'

        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse

        HashMap hmAAResp = new HashMap()
        hmAAResp[MPSDefs.APP_STATUS_CODE] = MPSDefs.ERR_USER_NOT_FOUND
        hmAAResp[CommonDefs.ASSOCIATED_USERS] = []

        // DB returns non-numeric GUID → skips InquireProfile
        HashMap hmDBResult = new HashMap()
        hmDBResult.putAll(hmSuccessResponse)
        hmDBResult[CommonDefs.GUID] = 'NOT_A_NUMBER'

        oUserProfileAutoregUtility.generateAutoGenAccessId(_ as HashMap) >> hmAutoGenAccessId
        oUserProfileAutoregUtility.callAddUser(_ as HashMap, _ as String) >> hmSuccessResponse

        HashMap hmAddAssocSuccess = new HashMap()
        hmAddAssocSuccess[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmAddAssocSuccess[MPSDefs.APP_INFO] = CommonDefs.COMMON_SUCCESS_MSG

        internalIDPRestClient.callIDPRestClient(_ as HashMap) >>> [hmAAResp, hmAddAssocSuccess]
        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmDBResult
        wirelessAutoRegQueueHelper.prepareEDDDataForAsyncCall(_ as HashMap, _ as String) >> hmSuccessResponse

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == CommonDefs.COMMON_SUCCESS_MSG
    }

    // ----- InquireAssociatedAccessIds 400 status continues flow -----

    def "verify InquireAssociatedAccessIds 400 status continues flow"() {
        given:
        featureManager.isEnabled(_ as String) >> false
        hmInput['isConnectedCar'] = 'N'

        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse

        HashMap hmAA400Resp = new HashMap()
        hmAA400Resp[MPSDefs.APP_STATUS_CODE] = '400'
        hmAA400Resp[MPSDefs.APP_INFO] = 'Bad request'
        hmAA400Resp[CommonDefs.ASSOCIATED_USERS] = null

        HashMap hmDBResult = new HashMap()
        hmDBResult.putAll(hmSuccessResponse)
        hmDBResult[CommonDefs.GUID] = '12345678'

        oUserProfileAutoregUtility.generateAutoGenAccessId(_ as HashMap) >> hmAutoGenAccessId
        oUserProfileAutoregUtility.callAddUser(_ as HashMap, _ as String) >> hmSuccessResponse

        HashMap hmAddAssocSuccess = new HashMap()
        hmAddAssocSuccess[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmAddAssocSuccess[MPSDefs.APP_INFO] = CommonDefs.COMMON_SUCCESS_MSG

        internalIDPRestClient.callIDPRestClient(_ as HashMap) >>> [hmAA400Resp, hmAddAssocSuccess]
        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmDBResult
        wirelessAutoRegQueueHelper.prepareEDDDataForAsyncCall(_ as HashMap, _ as String) >> hmSuccessResponse

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == CommonDefs.COMMON_SUCCESS_MSG
    }

    // ----- autoGenAccessId error halts registration -----

    def "verify autoGenAccessId error halts registration"() {
        given:
        featureManager.isEnabled(_ as String) >> false
        hmInput['isConnectedCar'] = 'N'

        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse

        HashMap hmAAResp = new HashMap()
        hmAAResp[MPSDefs.APP_STATUS_CODE] = MPSDefs.ERR_USER_NOT_FOUND
        hmAAResp[CommonDefs.ASSOCIATED_USERS] = []

        HashMap hmDBResult = new HashMap()
        hmDBResult.putAll(hmSuccessResponse)
        hmDBResult[CommonDefs.GUID] = null

        externalDestinationHelper.callOrderGraph(_ as HashMap) >> null

        // AutoGenAccessId fails
        HashMap hmAutoGenError = new HashMap()
        hmAutoGenError[MPSDefs.APP_STATUS_CODE] = '602'
        hmAutoGenError[MPSDefs.APP_INFO] = 'Error from autoGenAccessId'
        oUserProfileAutoregUtility.generateAutoGenAccessId(_ as HashMap) >> hmAutoGenError

        internalIDPRestClient.callIDPRestClient(_ as HashMap) >>> [hmAAResp]
        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmDBResult

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Error from autoGenAccessId'
    }

    // ----- sDBGuid overridden from callAddUser result -----

    def "verify sDBGuid set from callAddUser response"() {
        given:
        featureManager.isEnabled(_ as String) >> false
        hmInput['isConnectedCar'] = 'N'

        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse

        HashMap hmAAResp = new HashMap()
        hmAAResp[MPSDefs.APP_STATUS_CODE] = MPSDefs.ERR_USER_NOT_FOUND
        hmAAResp[CommonDefs.ASSOCIATED_USERS] = []

        HashMap hmDBResult = new HashMap()
        hmDBResult.putAll(hmSuccessResponse)
        hmDBResult[CommonDefs.GUID] = null

        externalDestinationHelper.callOrderGraph(_ as HashMap) >> null

        oUserProfileAutoregUtility.generateAutoGenAccessId(_ as HashMap) >> hmAutoGenAccessId

        HashMap hmAddUserResp = new HashMap()
        hmAddUserResp[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmAddUserResp[CommonDefs.GUID] = '99999999'
        oUserProfileAutoregUtility.callAddUser(_ as HashMap, _ as String) >> hmAddUserResp

        HashMap hmAddAssocSuccess = new HashMap()
        hmAddAssocSuccess[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmAddAssocSuccess[MPSDefs.APP_INFO] = CommonDefs.COMMON_SUCCESS_MSG

        internalIDPRestClient.callIDPRestClient(_ as HashMap) >>> [hmAAResp, hmAddAssocSuccess]
        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmDBResult
        wirelessAutoRegQueueHelper.prepareEDDDataForAsyncCall(_ as HashMap, _ as String) >> hmSuccessResponse

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == CommonDefs.COMMON_SUCCESS_MSG
    }

    // ----- sSupressMOBILITYCourtesyNotification N (bAutoGenAccessId=false, autoGenInd not Y) -----

    def "verify suppress notification N when existing user not auto-generated"() {
        given:
        featureManager.isEnabled(_ as String) >> false
        hmInput['isConnectedCar'] = 'N'
        hmInput[CommonDefs.GUID] = '12345678'

        cgRestClientObj.getCGSyncCall(_ as HashMap) >> hmCGResponse

        HashMap hmAAResp = new HashMap()
        hmAAResp[MPSDefs.APP_STATUS_CODE] = MPSDefs.ERR_USER_NOT_FOUND
        hmAAResp[CommonDefs.ASSOCIATED_USERS] = []

        HashMap hmDBResult = new HashMap()
        hmDBResult.putAll(hmSuccessResponse)
        hmDBResult[CommonDefs.GUID] = '12345678'

        // InquireProfile — parentChildInd=S, autoGenInd=N → suppress notification = N, no EDD called
        HashMap hmIPResponse = new HashMap()
        HashMap hmDBMember = new HashMap()
        hmDBMember['parentChildInd'] = 'S'
        hmDBMember[CommonDefs.MEMBER_NUM] = '12345678'
        hmDBMember[CommonDefs.MIGRATION_IND] = 'Y'
        hmDBMember[CommonDefs.ACTIVATED_IND] = 'Y'
        hmDBMember[CommonDefs.AUTO_GENERATED_IND] = 'N'
        hmDBMember[CommonDefs.MEMBER_NAME] = 'existinguser'
        hmIPResponse['member'] = hmDBMember
        hmIPResponse['memberservicerole'] = null
        hmIPResponse[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        wirelessAutoRegHelperObj.sMaxAllowedSvcsAccounts = '5'

        HashMap hmAddAssocSuccess = new HashMap()
        hmAddAssocSuccess[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmAddAssocSuccess[MPSDefs.APP_INFO] = CommonDefs.COMMON_SUCCESS_MSG

        internalIDPRestClient.callIDPRestClient(_ as HashMap) >>> [hmAAResp, hmIPResponse, hmAddAssocSuccess]
        accountAutoRegDBHelper.queryAccountAutoReg(_ as HashMap) >> hmDBResult

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(hmInput)

        then:
        // No EDD notification, bAutoGenAccessId=false, suppress=N, qarNotification=N
        result[CommonDefs.COMMON_APP_INFO] == CommonDefs.COMMON_SUCCESS_MSG
    }

    // ----- Empty input hash -----

    def "verify empty input hash returns ERR_INVALID_DATA"() {
        given:
        HashMap emptyInput = new HashMap()

        when:
        Map<String, Object> result = wirelessAutoRegHelperObj.registerWirelessUser(emptyInput)

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Input Hash is NULL'
    }

    // ----- callAddAssociation with suppressNotification null -----

    def "verify callAddAssociation with null suppressNotification"() {
        given:
        HashMap hmSuccess = new HashMap()
        hmSuccess[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        internalIDPRestClient.callIDPRestClient(_ as HashMap) >> hmSuccess

        when:
        def result = wirelessAutoRegHelperObj.callAddAssociation(hmInput, 'MOBILITY', null)

        then:
        result[MPSDefs.APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    // ----- callEDDNotification with error from prepareEDDDataForAsyncCall -----

    def "verify callEDDNotification error status from prepareEDD"() {
        given:
        HashMap hmEDDError = new HashMap()
        hmEDDError[MPSDefs.APP_STATUS_CODE] = '602'
        hmEDDError[CommonDefs.COMMON_APP_INFO] = 'EDD prep failed'
        wirelessAutoRegQueueHelper.prepareEDDDataForAsyncCall(_, _) >> hmEDDError

        when:
        def result = wirelessAutoRegHelperObj.callEDDNotification(hmInput, 'validSLID')

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'EDD prep failed'
    }

    // ----- callEDDNotification with successful prepareEDD but null dbus input -----

    def "verify callEDDNotification with null dbus input"() {
        given:
        HashMap hmEDDResp = new HashMap()
        hmEDDResp[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmEDDResp[CommonDefs.CONSOLIDATED_DBUS_INPUT] = null
        wirelessAutoRegQueueHelper.prepareEDDDataForAsyncCall(_, _) >> hmEDDResp

        when:
        def result = wirelessAutoRegHelperObj.callEDDNotification(hmInput, 'validSLID')

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'dbus input is null from WirelessAutoRegQueueHelper. prepareEDDDataForAsyncCall()'
    }

    // ----- callEDDNotification with successful sendMessage -----

    def "verify callEDDNotification full success path"() {
        given:
        ArrayList dbusInput = new ArrayList()
        dbusInput.add(new HashMap())

        HashMap hmEDDResp = new HashMap()
        hmEDDResp[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmEDDResp[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput
        wirelessAutoRegQueueHelper.prepareEDDDataForAsyncCall(_, _) >> hmEDDResp

        HashMap hmSendResp = new HashMap()
        hmSendResp[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        wirelessAutoRegQueueHelper.sendMessage(_ as ArrayList, _ as HashMap) >> hmSendResp

        when:
        def result = wirelessAutoRegHelperObj.callEDDNotification(hmInput, 'validSLID')

        then:
        result[MPSDefs.APP_STATUS_CODE] == CommonDefs.COMMON_SUCCESS
    }

    // ----- callEDDNotification sendMessage returns null -----

    def "verify callEDDNotification sendMessage null response"() {
        given:
        ArrayList dbusInput = new ArrayList()
        dbusInput.add(new HashMap())

        HashMap hmEDDResp = new HashMap()
        hmEDDResp[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmEDDResp[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput
        wirelessAutoRegQueueHelper.prepareEDDDataForAsyncCall(_, _) >> hmEDDResp

        wirelessAutoRegQueueHelper.sendMessage(_ as ArrayList, _ as HashMap) >> null

        when:
        def result = wirelessAutoRegHelperObj.callEDDNotification(hmInput, 'validSLID')

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Null Response returned from sendMessage()'
    }

    // ----- callEDDNotification sendMessage error status -----

    def "verify callEDDNotification sendMessage error status"() {
        given:
        ArrayList dbusInput = new ArrayList()
        dbusInput.add(new HashMap())

        HashMap hmEDDResp = new HashMap()
        hmEDDResp[MPSDefs.APP_STATUS_CODE] = CommonDefs.COMMON_SUCCESS
        hmEDDResp[CommonDefs.CONSOLIDATED_DBUS_INPUT] = dbusInput
        wirelessAutoRegQueueHelper.prepareEDDDataForAsyncCall(_, _) >> hmEDDResp

        HashMap hmSendError = new HashMap()
        hmSendError[MPSDefs.APP_STATUS_CODE] = '602'
        hmSendError[CommonDefs.COMMON_APP_INFO] = 'Send message failed'
        wirelessAutoRegQueueHelper.sendMessage(_ as ArrayList, _ as HashMap) >> hmSendError

        when:
        def result = wirelessAutoRegHelperObj.callEDDNotification(hmInput, 'validSLID')

        then:
        result[CommonDefs.COMMON_APP_INFO] == 'Send message failed'
    }

}
