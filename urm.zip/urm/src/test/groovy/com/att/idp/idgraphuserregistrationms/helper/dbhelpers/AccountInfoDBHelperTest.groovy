package com.att.idp.idgraphuserregistrationms.helper.dbhelpers

import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.JdbcTemplate
import com.att.idp.idgraphuserregistrationms.metrics.ErrorMetricHandler
import spock.lang.Specification
/**
 * 
 * @author gs799f
 *
 */
class AccountInfoDBHelperTest extends Specification {

	JdbcTemplate jdbcTemplate = Mock(JdbcTemplate)
	ErrorMetricHandler errorMetricHandler = Mock(ErrorMetricHandler)

	def testObj = new AccountInfoDBHelper()

	Logger logger = null
	HashMap hmDBInput = null
	String stAppStatusMsg = null
	List alQueryResponse = CommonUtil.arrayList
	HashMap hmQueryResponse = CommonUtil.hashMap
	List<Object> objectList = CommonUtil.arrayList
	HashMap hmResult = CommonUtil.hashMap

	private static String sClassName = 'MPSDB_GetAccountInfo_H'
	private static String sOrderDateFormat = 'YYYY-MM-DD"T"HH24:MI:SS.ff3"Z"'
	private static String sTosDateFormat = 'MMddyyyy HH24:mi:ss'

	private static String queryAccountInfo = "SELECT ban,bill_cycle, legal_entity, fullname,account_type,account_subtype, create_date,last_modified,last_modified_by, " +
			 "site_id, street1, street2, street3, street4, street5, city, state, zip, ipdslam_ind, superseded_main_mid, tos_acceptance_flags, wll_tos_acceptance_flags, " +
			 "preprovision_ind, TO_CHAR(order_due_date, '" + sOrderDateFormat + "') as order_due_date, " +
			 "TO_CHAR (hsia_tos_date, '" + sTosDateFormat + "') as hsia_tos_date, TO_CHAR (e911_tos_date, '" +
			 sTosDateFormat + "') as e911_tos_date, " + "TO_CHAR (iptv_tos_date, '" + sTosDateFormat +
			 "') as iptv_tos_date, TO_CHAR (wdm_tos_date, '" + sTosDateFormat + "') as wdm_tos_date, " +
			 "TO_CHAR (wvm_tos_date, '" + sTosDateFormat + "') as wvm_tos_date, " + "TO_CHAR (order_taken_date, '" +
			 sOrderDateFormat + "') as order_taken_date, rg_activated, tn_activated FROM AccountInfo " +
			 "WHERE ban = ?";


	def setup() throws Exception {
	    testObj.jdbcTemplate=jdbcTemplate
	    testObj.errorMetricHandler=errorMetricHandler
		logger = LoggerFactory.getLogger('ValidateAndSyncG2')
		//System.setProperty('CommonConfigurationFilePath', './opt/att/ajsc/config/CommonConfigurationTest.xml')

		hmQueryResponse[MPSDefs.DB_BAN] = '123456'
		hmQueryResponse[MPSDefs.DB_BILL_CYCLE] = '07'
		hmQueryResponse[MPSDefs.DB_LEGAL_ENTITY] = 'PC00'
		hmQueryResponse[MPSDefs.DB_FULLNAME] = 'JamesConnor'
		hmQueryResponse[MPSDefs.DB_ACCOUNT_TYPE] = 'R'
		hmQueryResponse[MPSDefs.DB_ACCOUNT_SUBTYPE] = 'H'
		hmQueryResponse[MPSDefs.DB_CREATE_DATE] = '2005-10-05 13:39:17.0'
		hmQueryResponse[MPSDefs.DB_LAST_MODIFIED] = '2016-11-10 14:52:16.0'
		hmQueryResponse[MPSDefs.DB_LAST_MODIFIED_BY] = 'DATAMGT_20161107_TOS_UPDATE'
		hmQueryResponse[MPSDefs.DB_E911_TOS_DATE] = '17'
		hmQueryResponse[MPSDefs.DB_HSIA_TOS_DATE] = '10052005 13:40:53'
		hmQueryResponse[MPSDefs.DB_IPTV_TOS_DATE] = '17'
		hmQueryResponse[MPSDefs.DB_WDM_TOS_DATE] = ''
		hmQueryResponse[MPSDefs.DB_WVM_TOS_DATE] = '17'
		hmQueryResponse[MPSDefs.DB_WLL_TOS_ACCEPTANCE_FLAGS] = '|WDM|'
		hmQueryResponse[MPSDefs.DB_TOS_ACCEPTANCE_FLAGS] = '|HSIA|'
		hmQueryResponse[MPSDefs.DB_RG_ACTIVATED] = 'Y'
		hmQueryResponse[MPSDefs.DB_TN_ACTIVATED] = '17'
		hmQueryResponse[MPSDefs.DB_ORDER_TAKEN_DATE] = '2000-01-01T00:00:00.000Z'
		hmQueryResponse[MPSDefs.DB_STREET1] = 'FrontStreet'
		hmQueryResponse[MPSDefs.DB_STREET2] = 'ad'
		hmQueryResponse[MPSDefs.DB_STREET3] = 'wqe'
		hmQueryResponse[MPSDefs.DB_STREET4] = '234'
		hmQueryResponse[MPSDefs.DB_STREET5] = 'sdfsaf'
		hmQueryResponse[MPSDefs.DB_SITE_ID] = 'S123456'
		hmQueryResponse[MPSDefs.DB_CITY] = 'YorkTown'
		hmQueryResponse[MPSDefs.DB_ZIP] = '10598'
		hmQueryResponse[MPSDefs.DB_IPDSLAM_IND] = ''
		hmQueryResponse[MPSDefs.DB_SUPERSEDED_MAIN_MID] = ''
		hmQueryResponse[MPSDefs.DB_ORDER_DUE_DATE] = '2000-01-01T00:00:00.000Z'

		alQueryResponse.add(hmQueryResponse)
	}


	def "get account info e r r e m p t y"() {
		given:
		hmResult = testObj.getAccountInfo('')
		when:
		stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
		then:
		stAppStatusMsg == 'ERR_EMPTY'
	}


	def "get account info no b a n error case"() {
		given:
		hmResult = testObj.getAccountInfo('12345')
		when:
		stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
		then:
		stAppStatusMsg == 'REC_NOT_FOUND'
	}


	def "get account info t o s h s i a"() {
		given:
		objectList.add('123456')
		jdbcTemplate.queryForList(_ , _) >> alQueryResponse
		hmResult = testObj.getAccountInfo('123456')
		when:
		stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
		then:
		stAppStatusMsg == 'SUCCESS'
	}


	def "get account info success"() {
		given:
		hmQueryResponse[MPSDefs.DB_WLL_TOS_ACCEPTANCE_FLAGS] = '|WVM|'
		hmQueryResponse[MPSDefs.DB_TOS_ACCEPTANCE_FLAGS] = '|E911|'
		hmQueryResponse.remove(MPSDefs.DB_ORDER_DUE_DATE)
		hmQueryResponse.remove(MPSDefs.DB_ORDER_TAKEN_DATE)
		hmQueryResponse.remove(MPSDefs.DB_STREET2)
		hmQueryResponse.remove(MPSDefs.DB_STREET1)
		hmQueryResponse.remove(MPSDefs.DB_STREET3)
		hmQueryResponse.remove(MPSDefs.DB_STREET4)
		hmQueryResponse.remove(MPSDefs.DB_STREET5)
		objectList.add('123456')
		jdbcTemplate.queryForList(new String(queryAccountInfo), _) >> alQueryResponse
		hmResult = testObj.getAccountInfo('123456')
		when:
		stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
		then:
		stAppStatusMsg == 'SUCCESS'
	}


	def "get account info t o s i p t v"() {
		given:
		hmQueryResponse[MPSDefs.DB_TOS_ACCEPTANCE_FLAGS] = '|IPTV|'
		objectList.add('123456')
		jdbcTemplate.queryForList(new String(queryAccountInfo),_) >> alQueryResponse
		hmResult = testObj.getAccountInfo('123456')
		when:
		stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
		then:
		stAppStatusMsg == 'SUCCESS'
	}

}
