package com.att.idp.idgraphuserregistrationms.client

import com.att.cio.commonheader.v3.sd.WSException
import com.att.cio.commonheader.v3.sd.WSNameValueType
import com.att.idp.core.exception.ServiceException
import com.att.idp.soap.config.SOAPClientConfigurer
import com.att.mpsys.common.utils.MPSDefs
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.ws.client.core.WebServiceTemplate
import org.springframework.ws.soap.SoapBody
import org.springframework.ws.soap.SoapFault
import org.springframework.ws.soap.SoapFaultDetail
import org.springframework.ws.soap.SoapFaultDetailElement
import org.springframework.ws.soap.client.SoapFaultClientException
import org.springframework.ws.transport.http.HttpComponentsMessageSender
import spock.lang.Specification
import spock.lang.Unroll

import javax.xml.transform.dom.DOMSource
import java.lang.reflect.Field

class BaseSoapHandlerTest extends Specification {

    // Concrete test subclass for the abstract BaseSoapHandler
    static class TestSoapHandler extends BaseSoapHandler<String, String> {
        private static final Logger log = LoggerFactory.getLogger(TestSoapHandler.class)

        @Override
        protected Logger getLogger() { return log }

        @Override
        protected String getApiName() { return "TestApi" }

        @Override
        protected String extractAppInfo(String response) { return response }
    }

    TestSoapHandler handler
    HttpComponentsMessageSender mockMessageSender
    SOAPClientConfigurer mockConfigurer
    WebServiceTemplate mockTemplate

    private static void setField(Object target, String fieldName, Object value) {
        Class<?> type = target.getClass()
        Field field = null
        while (type != null) {
            try {
                field = type.getDeclaredField(fieldName)
                break
            } catch (NoSuchFieldException ignored) {
                type = type.getSuperclass()
            }
        }
        if (field == null) {
            throw new IllegalArgumentException("Field '" + fieldName + "' not found")
        }
        field.setAccessible(true)
        field.set(target, value)
    }

    void setup() {
        handler = new TestSoapHandler()
        mockMessageSender = Mock(HttpComponentsMessageSender)
        mockConfigurer = Mock(SOAPClientConfigurer)
        mockTemplate = Mock(WebServiceTemplate)

        setField(handler, 'httpComponentsMessageSender', mockMessageSender)
        setField(handler, 'soapClientConfigurer', mockConfigurer)
    }

    def "init should configure soap client when configurer is not null"() {
        when: "init is called"
        handler.init()

        then: "soapClientConfigurer.configure is called"
        1 * mockConfigurer.configure(handler, "TestApi")
        0 * _
    }

    def "init should not fail when configurer is null"() {
        given: "configurer is null"
        setField(handler, 'soapClientConfigurer', null)

        when: "init is called"
        handler.init()

        then: "No exception thrown"
        noExceptionThrown()
        0 * _
    }

    def "handleSOAPFault should return error map with 602 when detail is null"() {
        given: "SoapFault with null detail"
        SoapFaultClientException soapFault = Stub(SoapFaultClientException)
        SoapFault fault = Stub(SoapFault)
        soapFault.getSoapFault() >> fault
        fault.getFaultDetail() >> null
        soapFault.getFaultStringOrReason() >> "Some fault reason"

        when: "handleSOAPFault is called"
        def result = handler.handleSOAPFault(soapFault)

        then: "error map returned with 602"
        result.get("appStatusCode") == "602"
        0 * _
    }

    def "handleSOAPFault should return error map with 602 when detail entries are null"() {
        given: "SoapFault with detail but null entries"
        SoapFaultClientException soapFault = Stub(SoapFaultClientException)
        SoapFault fault = Stub(SoapFault)
        SoapFaultDetail detail = Stub(SoapFaultDetail)
        soapFault.getSoapFault() >> fault
        fault.getFaultDetail() >> detail
        detail.getDetailEntries() >> null
        soapFault.getFaultStringOrReason() >> "Detail entries null"

        when: "handleSOAPFault is called"
        def result = handler.handleSOAPFault(soapFault)

        then: "error map returned with 602"
        result.get("appStatusCode") == "602"
        0 * _
    }

    def "handleSOAPFault should return error map with 602 when detail entries has no next"() {
        given: "SoapFault with detail but empty entries iterator"
        SoapFaultClientException soapFault = Stub(SoapFaultClientException)
        SoapFault fault = Stub(SoapFault)
        SoapFaultDetail detail = Stub(SoapFaultDetail)
        Iterator<SoapFaultDetailElement> emptyIterator = Stub(Iterator)
        emptyIterator.hasNext() >> false

        soapFault.getSoapFault() >> fault
        fault.getFaultDetail() >> detail
        detail.getDetailEntries() >> emptyIterator
        soapFault.getFaultStringOrReason() >> "Empty entries"

        when: "handleSOAPFault is called"
        def result = handler.handleSOAPFault(soapFault)

        then: "error map returned with 602"
        result.get("appStatusCode") == "602"
        0 * _
    }

    // ---- Tests for successful unmarshalling path (CWE-611 XXE fix + review comments) ----

    /**
     * Helper to build a WSException XML as a DOM Document for JAXB unmarshalling.
     */
    private static DOMSource buildWSExceptionDomSource(String errorCode, String message, String errorType, Map<String, String> nameValues) {
        def ns = "http://cio.att.com/commonheader/v3"
        def sb = new StringBuilder()
        sb.append("<WSException xmlns=\"${ns}\">")
        sb.append("<Message>${message}</Message>")
        sb.append("<ErrorCode>${errorCode}</ErrorCode>")
        if (errorType != null) {
            sb.append("<ErrorType>${errorType}</ErrorType>")
        }
        if (nameValues != null) {
            nameValues.each { name, value ->
                sb.append("<WSNameValue><Name>${name}</Name><Value>${value}</Value></WSNameValue>")
            }
        }
        sb.append("</WSException>")

        def factory = javax.xml.parsers.DocumentBuilderFactory.newInstance()
        factory.setNamespaceAware(true)
        def docBuilder = factory.newDocumentBuilder()
        def doc = docBuilder.parse(new org.xml.sax.InputSource(new StringReader(sb.toString())))
        return new DOMSource(doc)
    }

    /**
     * Helper to stub a SoapFaultClientException with a given DOMSource detail element.
     */
    private SoapFaultClientException buildSoapFaultWithDetail(DOMSource domSource) {
        SoapFaultDetailElement detailElement = Stub(SoapFaultDetailElement)
        detailElement.getSource() >> domSource

        Iterator<SoapFaultDetailElement> iterator = Stub(Iterator)
        iterator.hasNext() >> true
        iterator.next() >> detailElement

        SoapFaultDetail detail = Stub(SoapFaultDetail)
        detail.getDetailEntries() >> iterator

        SoapFault fault = Stub(SoapFault)
        fault.getFaultDetail() >> detail

        SoapFaultClientException soapFault = Stub(SoapFaultClientException)
        soapFault.getSoapFault() >> fault

        return soapFault
    }

    def "handleSOAPFault should unmarshal WSException with Functional errorType and return appCategoryCode 3"() {
        given: "SoapFault with a valid WSException containing Functional errorType"
        def domSource = buildWSExceptionDomSource("ERR-001", "Test Error", "Functional",
                [(MPSDefs.APP_INFO): "Some app info"])
        def soapFault = buildSoapFaultWithDetail(domSource)

        when: "handleSOAPFault is called"
        def result = handler.handleSOAPFault(soapFault)

        then: "map contains correct fields with appCategoryCode 3"
        result.get("appCategoryCode") == "3"
        result.get("appStatusCode") == "ERR-001"
        result.get("appStatusMsg") == "Test Error"
        result.get("appInfo") == "Some app info"
        0 * _
    }

    def "handleSOAPFault should unmarshal WSException with System errorType and return appCategoryCode 2"() {
        given: "SoapFault with a valid WSException containing System errorType"
        def domSource = buildWSExceptionDomSource("SYS-500", "System Failure", "System",
                [(MPSDefs.APP_INFO): "System error details"])
        def soapFault = buildSoapFaultWithDetail(domSource)

        when: "handleSOAPFault is called"
        def result = handler.handleSOAPFault(soapFault)

        then: "map contains correct fields with appCategoryCode 2"
        result.get("appCategoryCode") == "2"
        result.get("appStatusCode") == "SYS-500"
        result.get("appStatusMsg") == "System Failure"
        result.get("appInfo") == "System error details"
        0 * _
    }

    def "handleSOAPFault should return empty map when errorCode is 0"() {
        given: "SoapFault with errorCode 0 (success)"
        def domSource = buildWSExceptionDomSource("0", "No Error", "Functional", null)
        def soapFault = buildSoapFaultWithDetail(domSource)

        when: "handleSOAPFault is called"
        def result = handler.handleSOAPFault(soapFault)

        then: "map does not contain error fields since errorCode is 0"
        result.get("appStatusCode") == null
        result.get("appCategoryCode") == null
        0 * _
    }

    def "handleSOAPFault should return null appInfo when WSNameValue is absent"() {
        given: "SoapFault with no WSNameValue entries"
        def domSource = buildWSExceptionDomSource("ERR-002", "Missing Info", "Functional", null)
        def soapFault = buildSoapFaultWithDetail(domSource)

        when: "handleSOAPFault is called"
        def result = handler.handleSOAPFault(soapFault)

        then: "appInfo is null since no WSNameValue entries"
        result.get("appStatusCode") == "ERR-002"
        result.get("appInfo") == null
        0 * _
    }

    def "handleSOAPFault should return null appCategoryCode when errorType is missing"() {
        given: "SoapFault with no errorType element"
        def domSource = buildWSExceptionDomSource("ERR-003", "No Type", null, null)
        def soapFault = buildSoapFaultWithDetail(domSource)

        when: "handleSOAPFault is called"
        def result = handler.handleSOAPFault(soapFault)

        then: "appCategoryCode is null"
        result.get("appStatusCode") == "ERR-003"
        result.get("appCategoryCode") == null
        0 * _
    }

    def "handleSOAPFault should resolve wrapped 602 to real error code when appInfo matches CErrorDefs"() {
        given: "SoapFault with errorCode 602 and appInfo matching ERR_TERMS_AND_CONDITION_NOT_ACCEPTED"
        def domSource = buildWSExceptionDomSource("602", "ERR_SYS_APPL", "Functional",
                [(MPSDefs.APP_INFO): "ERR_TERMS_AND_CONDITION_NOT_ACCEPTED"])
        def soapFault = buildSoapFaultWithDetail(domSource)

        when: "handleSOAPFault is called"
        def result = handler.handleSOAPFault(soapFault)

        then: "appStatusCode is resolved to 426 instead of 602"
        result.get("appStatusCode") == "426"
        result.get("appInfo") == "ERR_TERMS_AND_CONDITION_NOT_ACCEPTED"
        0 * _
    }

    def "handleSOAPFault should keep 602 when appInfo does not match any CErrorDefs entry"() {
        given: "SoapFault with errorCode 602 and unknown appInfo"
        def domSource = buildWSExceptionDomSource("602", "ERR_SYS_APPL", "System",
                [(MPSDefs.APP_INFO): "SOME_UNKNOWN_ERROR"])
        def soapFault = buildSoapFaultWithDetail(domSource)

        when: "handleSOAPFault is called"
        def result = handler.handleSOAPFault(soapFault)

        then: "appStatusCode stays 602"
        result.get("appStatusCode") == "602"
        result.get("appStatusMsg") == "ERR_SYS_APPL"
        result.get("appInfo") == "SOME_UNKNOWN_ERROR"
        0 * _
    }

    def "handleSOAPFault should return error map via XML extraction when unmarshalling fails with invalid XML"() {
        given: "SoapFault with a DOMSource containing non-WSException XML"
        def factory = javax.xml.parsers.DocumentBuilderFactory.newInstance()
        factory.setNamespaceAware(true)
        def docBuilder = factory.newDocumentBuilder()
        def doc = docBuilder.parse(new org.xml.sax.InputSource(new StringReader("<InvalidRoot/>")))
        def domSource = new DOMSource(doc)
        def soapFault = buildSoapFaultWithDetail(domSource)
        soapFault.getFaultStringOrReason() >> "Invalid XML fault"

        when: "handleSOAPFault is called"
        def result = handler.handleSOAPFault(soapFault)

        then: "error map returned with 602 as XML extraction finds no errorCode"
        result.get("appStatusCode") == "602"
        0 * _
    }

    // ---- Tests for XML extraction fallback path (namespace-prefixed tags) ----

    /**
     * Helper to build a namespace-prefixed WSException XML as a DOM Document.
     * JAXB will fail to unmarshal this (different namespace package), triggering XML extraction.
     */
    private static DOMSource buildNamespacedWSExceptionDomSource(String errorCode, String message,
            String errorType, Map<String, String> nameValues) {
        // Root element uses a default namespace that differs from the JAXB-bound namespace,
        // causing JAXB to throw a catchable JAXBException (not AssertionError) and fall through
        // to the XML extraction fallback. Child elements use ns3: prefix to exercise the
        // namespace-aware regex extraction logic.
        def wrongNs = "http://mpsys.ril.att.com/registeruserrequest/v1"
        def childNs = "http://cio.att.com/commonheader/v3"
        def sb = new StringBuilder()
        sb.append("<WSException xmlns=\"${wrongNs}\" xmlns:ns3=\"${childNs}\">")
        sb.append("<ns3:Message>${message}</ns3:Message>")
        sb.append("<ns3:ErrorCode>${errorCode}</ns3:ErrorCode>")
        if (errorType != null) {
            sb.append("<ns3:ErrorType>${errorType}</ns3:ErrorType>")
        }
        if (nameValues != null) {
            nameValues.each { name, value ->
                sb.append("<ns3:WSNameValue><ns3:Name>${name}</ns3:Name><ns3:Value>${value}</ns3:Value></ns3:WSNameValue>")
            }
        }
        sb.append("</WSException>")

        def factory = javax.xml.parsers.DocumentBuilderFactory.newInstance()
        factory.setNamespaceAware(true)
        def docBuilder = factory.newDocumentBuilder()
        def doc = docBuilder.parse(new org.xml.sax.InputSource(new StringReader(sb.toString())))
        return new DOMSource(doc)
    }

    def "XML extraction should parse namespace-prefixed tags correctly"() {
        given: "SoapFault with namespace-prefixed WSException that fails JAXB unmarshalling"
        def domSource = buildNamespacedWSExceptionDomSource("249", "ERR_BAN_NOT_FOUND_IN_CRM", "Functional",
                ["transactionId": "abc123", (MPSDefs.APP_INFO): "BAN is NOT found in LS CRM", "transactionName": "RegisterUser"])
        def soapFault = buildSoapFaultWithDetail(domSource)
        soapFault.getFaultStringOrReason() >> "ERR_BAN_NOT_FOUND_IN_CRM"

        when: "handleSOAPFault is called"
        def result = handler.handleSOAPFault(soapFault)

        then: "XML extraction returns correct values with namespace handling"
        result.get("appStatusCode") == "249"
        result.get("appStatusMsg") == "ERR_BAN_NOT_FOUND_IN_CRM"
        result.get("appCategoryCode") == "3"
        result.get("appInfo") == "BAN is NOT found in LS CRM"
        0 * _
    }

    def "XML extraction should find correct appInfo WSNameValue among multiple entries"() {
        given: "SoapFault with multiple WSNameValue entries"
        def domSource = buildNamespacedWSExceptionDomSource("100", "ERR_INVALID_DATA", "Functional",
                ["transactionId": "xyz789", "transactionName": "RegisterUser", (MPSDefs.APP_INFO): "Input Titan SLID does not match with DB Titan SLID"])
        def soapFault = buildSoapFaultWithDetail(domSource)
        soapFault.getFaultStringOrReason() >> "ERR_INVALID_DATA"

        when: "handleSOAPFault is called"
        def result = handler.handleSOAPFault(soapFault)

        then: "appInfo is extracted from the correct WSNameValue block"
        result.get("appStatusCode") == "100"
        result.get("appInfo") == "Input Titan SLID does not match with DB Titan SLID"
        0 * _
    }

    def "XML extraction should resolve wrapped 602 to specific error code"() {
        given: "SoapFault with 602 errorCode and appInfo matching CErrorDefs entry"
        def domSource = buildNamespacedWSExceptionDomSource("602", "ERR_SYS_APPL", "System",
                [(MPSDefs.APP_INFO): "ERR_TERMS_AND_CONDITION_NOT_ACCEPTED"])
        def soapFault = buildSoapFaultWithDetail(domSource)
        soapFault.getFaultStringOrReason() >> "ERR_SYS_APPL"

        when: "handleSOAPFault is called"
        def result = handler.handleSOAPFault(soapFault)

        then: "appStatusCode is resolved to 426 via XML extraction path"
        result.get("appStatusCode") == "426"
        result.get("appInfo") == "ERR_TERMS_AND_CONDITION_NOT_ACCEPTED"
        0 * _
    }

    def "XML extraction should return System appCategoryCode for System errorType"() {
        given: "SoapFault with System errorType"
        def domSource = buildNamespacedWSExceptionDomSource("602", "ERR_SYS_APPL", "System",
                [(MPSDefs.APP_INFO): "UNKNOWN_ERROR"])
        def soapFault = buildSoapFaultWithDetail(domSource)
        soapFault.getFaultStringOrReason() >> "ERR_SYS_APPL"

        when: "handleSOAPFault is called"
        def result = handler.handleSOAPFault(soapFault)

        then: "appCategoryCode is 2 for System type"
        result.get("appStatusCode") == "602"
        result.get("appCategoryCode") == "2"
        0 * _
    }

    def "XML extraction should return null appInfo when no appInfo WSNameValue exists"() {
        given: "SoapFault with WSNameValue entries but no appInfo"
        def domSource = buildNamespacedWSExceptionDomSource("500", "ERR_SYSTEM", "System",
                ["transactionId": "abc123"])
        def soapFault = buildSoapFaultWithDetail(domSource)
        soapFault.getFaultStringOrReason() >> "ERR_SYSTEM"

        when: "handleSOAPFault is called"
        def result = handler.handleSOAPFault(soapFault)

        then: "appInfo is null"
        result.get("appStatusCode") == "500"
        result.get("appInfo") == null
        0 * _
    }

    def "getApiName returns TestApi for test handler"() {
        expect:
        handler.getApiName() == "TestApi"
    }

    def "getLogger returns non-null logger"() {
        expect:
        handler.getLogger() != null
    }
}
