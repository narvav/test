package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraph.extclient.db.service.TworkitemService
import com.att.idp.idgraph.extclient.g2.service.G2SoapClientHandler
import com.att.idp.idgraph.extclient.model.ExtClientResponse
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetMemberServicesDBHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.fasterxml.jackson.databind.node.ObjectNode
import org.slf4j.Logger
import spock.lang.Specification
import spock.lang.Unroll
import com.att.mpsys.common.utils.MPSDefs;

import java.lang.reflect.Field


class G2SyncOperationTest  extends Specification {

    G2LDAPHelper g2LDAPHelper
    G2SoapClientHandler g2SoapClientHandler
    TworkitemService tworkitemService
    GetMemberServicesDBHelper getMemberServicesDBHelper
    def g2SyncOperation

    // Helper: set field value via reflection (searches superclasses)
    private static void setField(Object target, String fieldName, Object value) {
        Class<?> type = target.getClass()
        Field field = null
        while (type != null) {
            try {
                field = type.getDeclaredField(fieldName)
                break
            } catch (NoSuchFieldException ignored) {
                type = type.getSuperclass()
            }
        }
        if (field == null) {
            throw new IllegalArgumentException("Field '" + fieldName + "' not found on " + target.getClass().getName())
        }
        field.setAccessible(true)
        field.set(target, value)
    }

    void setup() {
        g2LDAPHelper = Mock(G2LDAPHelper)
        g2SoapClientHandler = Mock(G2SoapClientHandler)
        tworkitemService = Mock(TworkitemService)
        getMemberServicesDBHelper = Mock(GetMemberServicesDBHelper) // Initialize the mock

        g2SyncOperation = new G2SyncOperation(g2LDAPHelper, g2SoapClientHandler, tworkitemService)
        setField(g2SyncOperation,'getMemberServicesDBHelper',getMemberServicesDBHelper)
      //  g2SyncOperation.logger = Mock(Logger)

    }

    @Unroll
    def "should return error map when input is null or empty for #scenarioName"() {
        given: "Null or empty input"
        HashMap<String, Object> input = testInput

        when: "performSync is called"
        HashMap<String, Object> result = g2SyncOperation.performSync(input)


        then: "Result contains error code and message"
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_SYS_APPL
        result.get(CErrorDefs.COMMON_APP_INFO) == "Input to performSync is either null or empty"

        where:
        scenarioName      | testInput
        "null input"      | null
        "empty input"     | [:]
    }

    @Unroll
    def "should return error map when getMemberServicesByBan returns null or empty for #scenarioName"() {
        given: "Valid input and getMemberServicesByBan returns null/empty"
        HashMap<String, Object> input = [idpTraceId: "trace-1", ban: "ban-1"]
        getMemberServicesDBHelper.getMemberServices(_)>> { HashMap<String, Object> _ -> getMemberServicesResponse }

        when: "performSync is called"
        HashMap<String, Object> result = g2SyncOperation.performSync(input)


        then: "Result contains error code and message"
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_SYS_APPL
        result.get(CErrorDefs.COMMON_APP_INFO) == "Response from getMemberServices is either null or empty"

        where:
        scenarioName         | getMemberServicesResponse
        "null response"      | null
        "empty response"     | [:]
    }

    @Unroll
    def "should return user not found error when getMemberServicesByBan returns not found for #scenarioName"() {
        given: "Valid input and getMemberServicesByBan returns not found"
        HashMap<String, Object> input = [idpTraceId: "trace-2", ban: "ban-2"]
        HashMap<String, Object> getMemberServicesResponse = [
                (CErrorDefs.COMMON_APP_STATUS_CODE): CErrorDefs.ERR_REC_NOT_FOUND
        ]
        getMemberServicesDBHelper.getMemberServices(_) >>{ HashMap<String, Object> _ -> getMemberServicesResponse }

        when: "performSync is called"
        HashMap<String, Object> result = g2SyncOperation.performSync(input)

        then: "Result contains user not found error"
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_USER_NOT_FOUND
        result.get(CErrorDefs.COMMON_APP_INFO) == "User not found with input access id."

        where:
        scenarioName | _
        "not found"  | _
    }

    @Unroll
    def "should return error map when mqToLdap returns null or empty for #scenarioName"() {
        given: "Valid input and mqToLdap returns null/empty"
        HashMap<String, Object> input = [idpTraceId: "trace-3", ban: "ban-3"]
        HashMap<String, Object> getMemberServicesResponse = [
                (CErrorDefs.COMMON_APP_STATUS_CODE): CommonDefs.COMMON_SUCCESS,
                (MPSDefs.DB_MEMBER_NAME): "user1",
                (MPSDefs.DB_DOMAIN_NAME): "domain1"
        ]
        getMemberServicesDBHelper.getMemberServices(_) >>{ HashMap<String, Object> _ -> getMemberServicesResponse }
        1 * g2LDAPHelper.mqToLdap(input, getMemberServicesResponse) >> mqToLdapResponse

        when: "performSync is called"
        HashMap<String, Object> result = g2SyncOperation.performSync(input)

        then: "Result contains error code and message"
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_SYS_APPL
        result.get(CErrorDefs.COMMON_APP_INFO) == "Response from mqToLdap method is either null or empty"

        where:
        scenarioName      | mqToLdapResponse
        "null response"   | null
        "empty response"  | [:]
    }

    @Unroll
    def "should return error map when dbusInput is missing or empty for #scenarioName"() {
        given: "Valid input and mqToLdap returns missing/empty dbusInput"
        HashMap<String, Object> input = [idpTraceId: "trace-4", ban: "ban-4"]
        HashMap<String, Object> getMemberServicesResponse = [
                (CErrorDefs.COMMON_APP_STATUS_CODE): CommonDefs.COMMON_SUCCESS,
                (MPSDefs.DB_MEMBER_NAME): "user2",
                (MPSDefs.DB_DOMAIN_NAME): "domain2"
        ]
        HashMap<String, Object> mqToLdapResponse = mqToLdapMap
        getMemberServicesDBHelper.getMemberServices(_)    >>  { HashMap<String, Object> _ -> getMemberServicesResponse }
        1 * g2LDAPHelper.mqToLdap(input, getMemberServicesResponse) >> mqToLdapResponse

        when: "performSync is called"
        HashMap<String, Object> result = g2SyncOperation.performSync(input)

        then: "Result contains error code and message"
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_SYS_APPL
        result.get(CErrorDefs.COMMON_APP_INFO) == "dbusInput missing or empty in mqToLdap response"

        where:
        scenarioName         | mqToLdapMap
        "dbusInput missing"  | [dbusInput: null]
        "dbusInput empty"    | [dbusInput: [:]]
    }

    @Unroll
    def "should process dbusInput and return success for #scenarioName"() {
        given: "Valid input and all dependencies return success"
        HashMap<String, Object> input = [idpTraceId: "trace-5", ban: "ban-5"]
        HashMap<String, Object> getMemberServicesResponse = [
                (CErrorDefs.COMMON_APP_STATUS_CODE): CommonDefs.COMMON_SUCCESS,
                (MPSDefs.DB_MEMBER_NAME): "user3",
                (MPSDefs.DB_DOMAIN_NAME): "domain3"
        ]
        HashMap<String, Object> mqToLdapResponse = [dbusInput: [field: "value"]]
        HashMap<String, Object> processResponse = [
                (CommonDefs.COMMON_APP_STATUS_CODE): CommonDefs.COMMON_SUCCESS
        ]
        ExtClientResponse resp = Mock(ExtClientResponse)
        resp.getAppStatusCode() >> '0'
        resp.getAppInfo() >> 'SUCCESS'
        getMemberServicesDBHelper.getMemberServices(_) >>{ HashMap<String, Object> _ -> getMemberServicesResponse }
        1 * g2LDAPHelper.mqToLdap(input, getMemberServicesResponse) >> mqToLdapResponse
        1 * g2SoapClientHandler.process({ ObjectNode node -> node != null }) >> resp
        1 * tworkitemService.deleteByStopKeyAndStopValue("stopfield", "g2ldapstopuser3@domain3")

        when: "performSync is called"
        HashMap<String, Object> result = g2SyncOperation.performSync(input)

        then: "Result contains success code and message"
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.COMMON_SUCCESS
        result.get(CErrorDefs.COMMON_APP_INFO) == CommonDefs.COMMON_SUCCESS_MSG

        where:
        scenarioName | _
        "happy path" | _
    }

    @Unroll
    def "should handle exception and return error map for #scenarioName"() {
        given: "Valid input and exception thrown"
        HashMap<String, Object> input = [idpTraceId: "trace-6", ban: "ban-6"]
        getMemberServicesDBHelper.getMemberServices(_) >> { HashMap<String, Object> _ -> throw new RuntimeException("fail") }

        when: "performSync is called"
        HashMap<String, Object> result = g2SyncOperation.performSync(input)

        then: "Result contains error code and message"
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_SYS_APPL
        result.get(CErrorDefs.COMMON_APP_INFO) .toString().contains("fail")

        where:
        scenarioName | _
        "exception"  | _
    }

}
