package com.att.idp.idgraphuserregistrationms.service.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.helper.UpdateUnifiedTOSHelper
import com.att.idp.idgraphuserregistrationms.resource.request.UpdateUnifiedTOSRequest
import com.att.idp.idgraphuserregistrationms.resource.response.UpdateUnifiedTOSResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.junit.jupiter.api.Assertions
import spock.lang.Specification

import jakarta.ws.rs.core.MultivaluedHashMap
import jakarta.ws.rs.core.MultivaluedMap


class UpdateUnifiedTOSServiceImplTest extends Specification {

	 def updateUnifiedTOSServiceImplObj =new UpdateUnifiedTOSServiceImpl()


	 UpdateUnifiedTOSHelper updateUnifiedTOSHelperObj=Mock(UpdateUnifiedTOSHelper)

	UpdateUnifiedTOSRequest requestObj = null
	public MultivaluedMap<String, String> requestHeader = null
	private Map<String, String> headers = new HashMap<>()


	def setup() throws Exception {
		updateUnifiedTOSServiceImplObj.updateUnifiedTOSHelper=updateUnifiedTOSHelperObj
		requestObj = new UpdateUnifiedTOSRequest()
		requestHeader = new MultivaluedHashMap<>(headers)

		requestObj.callingSystemId = 'IDP'
		requestObj.ban = '112222222'
		requestObj.hsiaTOSAcceptance = 'Y'
		requestObj.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'

	}


	def "test update unified t o s null case"() {
		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSServiceImplObj.updateUnifiedTOS(requestObj, requestHeader)

		then:
		response.appInfo == 'Null response from updateUnifiedTOSHelper.updateUnifiedTOS'
		HashMap hmResponse = new HashMap()

		when:
		hmResponse[MPSDefs.APP_STATUS_CODE] = null
		updateUnifiedTOSHelperObj.updateUnifiedTOS(_)>>hmResponse
		response = updateUnifiedTOSServiceImplObj.updateUnifiedTOS(requestObj, requestHeader)

		then:
		response.appInfo == 'Null response from updateUnifiedTOSHelper.updateUnifiedTOS'


	}


	def "test update unified t o s success case"() {

		given:
		HashMap hmResponse = new HashMap()
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_16374856'
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		hmResponse['appInfo'] = 'Success'
		updateUnifiedTOSHelperObj.updateUnifiedTOS(_ as HashMap)>>hmResponse

		when:
		UpdateUnifiedTOSResponse response = updateUnifiedTOSServiceImplObj.updateUnifiedTOS(requestObj, requestHeader)

		then:
		response != null
		response.idpTraceId != null

	}

}
