package com.att.idp.idgraphuserregistrationms.client.csi

import com.att.mpsys.common.utils.CommonDefs
import com.cingular.csi.csi.namespaces.container._public.inquireaccountprofilerequest.InquireAccountProfileRequestInfo
import spock.lang.Specification
import spock.lang.Unroll

class CSIRequestBuilderTest extends Specification {

    CSIRequestBuilder builder

    void setup() {
        builder = new CSIRequestBuilder()
    }

    def "should build CSI IAP request with billing account number and mask"() {
        given: "Input with billing account number and subscriber mask"
        HashMap<String, Object> hmInput = new HashMap<>()
        hmInput.put(CommonDefs.BILLING_ACCOUNT_NUMBER, "123456789")
        hmInput.put(CommonDefs.SUBSCRIBER_MASK, "ALL")

        when: "buildCSIIAPRequest is called"
        InquireAccountProfileRequestInfo result = builder.buildCSIIAPRequest(hmInput)

        then: "Request is properly built"
        result != null
        result.getAccountOrSubscriptionIDSelector() != null
        result.getAccountOrSubscriptionIDSelector().getAccountSelector() != null
        result.getAccountOrSubscriptionIDSelector().getAccountSelector().getBillingAccountNumber() == "123456789"
        result.getAccountOrSubscriptionIDSelector().getAccountSelector().getMarketServiceInfo() != null
        result.getAccountOrSubscriptionIDSelector().getAccountSelector().getMarketServiceInfo().getServiceZipCode() == "12345"
        result.getMask() == "ALL"
        result.getFilterSubscribersByStatus().contains("S")
        result.getFilterSubscribersByStatus().contains("A")
        result.getFilterSubscribersByStatus().size() == 2
        0 * _
    }

    def "should build request with null billing account number"() {
        given: "Input with null billing account number"
        HashMap<String, Object> hmInput = new HashMap<>()
        hmInput.put(CommonDefs.BILLING_ACCOUNT_NUMBER, null)
        hmInput.put(CommonDefs.SUBSCRIBER_MASK, null)

        when: "buildCSIIAPRequest is called"
        InquireAccountProfileRequestInfo result = builder.buildCSIIAPRequest(hmInput)

        then: "Request is built with null values"
        result != null
        result.getAccountOrSubscriptionIDSelector().getAccountSelector().getBillingAccountNumber() == null
        result.getMask() == null
        0 * _
    }

    def "should build request with empty input"() {
        given: "Empty input map"
        HashMap<String, Object> hmInput = new HashMap<>()

        when: "buildCSIIAPRequest is called"
        InquireAccountProfileRequestInfo result = builder.buildCSIIAPRequest(hmInput)

        then: "Request is built with null BAN"
        result != null
        result.getAccountOrSubscriptionIDSelector().getAccountSelector().getBillingAccountNumber() == null
        result.getMask() == null
        0 * _
    }
}
