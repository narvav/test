package com.att.idp.idgraphuserregistrationms.helper.dbhelpers

import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.JdbcTemplate
import com.att.idp.idgraphuserregistrationms.metrics.ErrorMetricHandler
import spock.lang.Specification

class SubAccountsDBHelperTest extends Specification {

    def testObj = new SubAccountsDBHelper()

	String stTransactionId = null
    Logger logger = null
    HashMap inpParamHash = CommonUtil.hashMap

    String stAppStatusMsg
    String stAppInfo

	JdbcTemplate jdbcTemplate = Mock(JdbcTemplate)
    ErrorMetricHandler errorMetricHandler = Mock(ErrorMetricHandler)

    HashMap hmResult
    HashMap MemServices = CommonUtil.hashMap

    List<Object> objectList = null
    private static String dateFormat = 'MMDDYYYY HH24:mi:ss'
    List alQueryResponse = new ArrayList()
    HashMap hmQueryResponse = CommonUtil.hashMap


    def setup() {

        testObj.jdbcTemplate = jdbcTemplate
        testObj.errorMetricHandler = errorMetricHandler

        objectList = new ArrayList<Object>()

        System.setProperty('CommonConfigurationFilePath', './opt/att/ajsc/config/CommonConfigurationTest.xml')
        logger = LoggerFactory.getLogger('AubAccount')

        hmQueryResponse[MPSDefs.DB_BAN] = 'VD0011010'
        hmQueryResponse[MPSDefs.DB_SOR_NAME] = 'NA'
        hmQueryResponse[MPSDefs.DB_DELETE_REQUEST_DATE] = '20122018'
        hmQueryResponse[MPSDefs.DB_TOKEN] = '12312134234'
        hmQueryResponse[MPSDefs.DB_REMARKS] = 'NA'

    }


    def "get all sub info error hash map"() {

        given:
        hmResult = testObj.getAllSubInfo(null)
        logger.info('getAllSubInfoErrorHashMap:' + hmResult)

        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppStatusMsg == 'ERR_HASHMAP_EMP'

    }


    def "get all sub info error empty"() {

        given:
        hmResult = testObj.getAllSubInfo(inpParamHash)
        logger.info('getAllSubInfoErrorEmpty:' + hmResult)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppStatusMsg == 'ERR_EMPTY'
    }


    def "get all sub info with null group num"() {
        given:
        inpParamHash[MPSDefs.DB_GROUP_NUM] = null
        objectList.add('VD0011010')
	    jdbcTemplate.queryForList(_,	_) >> null

        hmResult = testObj.getAllSubInfo(inpParamHash)
        logger.info('getAllSubInfoWithException:' + hmResult)

        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppStatusMsg == 'ERR_EMPTY'
    }


    def "get member serviceswith record not foud"() {

        given:
        inpParamHash[MPSDefs.DB_GROUP_NUM] = '20002094'

        hmQueryResponse[MPSDefs.DB_MEMBER_NAME] = 'qay2002'

        hmQueryResponse[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmQueryResponse[MPSDefs.DB_DOMAIN_ID] = '11'

        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = 'PORTAL'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'Y'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_GROUP_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse['agg_service_status'] = '0'
        hmQueryResponse['last_member_status_name'] = null
        hmQueryResponse[MPSDefs.DB_SUSPEND_REASON_CODE] = '0'
        hmQueryResponse['portal_provider'] = 'AT&T NAP'
        hmQueryResponse['member_state'] = 'INUSE'

        alQueryResponse.add(hmQueryResponse)

        HashMap resultHashSuccess = new HashMap()

        hmResult = testObj.getAllSubInfo(inpParamHash)
        logger.info('GetMemberServiceswithRecordNotFoud' + hmResult)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppStatusMsg == 'REC_NOT_FOUND'
    }


    def "get member serviceswith record success"() {

        given:
        inpParamHash[MPSDefs.DB_GROUP_NUM] = '20002094'

        objectList.add('20002094')

        hmQueryResponse[MPSDefs.DB_MEMBER_NAME] = 'qay2002'

        hmQueryResponse[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmQueryResponse[MPSDefs.DB_DOMAIN_ID] = '11'

        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = 'PORTAL'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'Y'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_GROUP_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse['agg_service_status'] = '0'
		hmQueryResponse['last_member_status_name'] = null
		hmQueryResponse[MPSDefs.DB_SUSPEND_REASON_CODE] = '0'
		hmQueryResponse['portal_provider'] = 'AT&T NAP'
		hmQueryResponse['member_state'] = 'INUSE'

		alQueryResponse.add(hmQueryResponse)

		HashMap resultHashSuccess = new HashMap()
		resultHashSuccess[MPSDefs.APP_STATUS_CODE] = '0'
		jdbcTemplate.queryForList(_,	_) >> alQueryResponse

		hmResult = testObj.getAllSubInfo(inpParamHash)
		stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppStatusMsg == 'SUCCESS'
    }

}
