package com.att.idp.idgraphuserregistrationms.request.validator

import com.att.idp.idgraphuserregistrationms.resource.request.CreateEmailAppPasswordRequest
import com.att.idp.idgraphuserregistrationms.resource.response.CreateEmailAppPasswordResponse
import com.att.mpsys.common.utils.CommonDefs
import jakarta.ws.rs.core.HttpHeaders
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import spock.lang.Unroll

class CreateEmailAppPasswordRequestValidatorTest extends Specification {

    CreateEmailAppPasswordRequestValidator validator
    HttpHeaders mockHeaders

    void setup() {
        validator = new CreateEmailAppPasswordRequestValidator()
        mockHeaders = Mock(HttpHeaders)
        ReflectionTestUtils.setField(validator, "propValidCallers", "IDMPROFILE,IDMREG")
    }

    def "should return error when idpTraceId is null"() {
        given: "HttpHeaders with null idp-trace-id"
        mockHeaders.getHeaderString("idp-trace-id") >> null
        mockHeaders.getHeaderString("X-ATT-ClientId") >> { throw new RuntimeException() }

        and: "Valid request object"
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setMemberId("testUser")
        request.setDomain("att.net")
        request.setPasswordName("imap")

        when: "createEmailAppPasswordReqValidator is called"
        CreateEmailAppPasswordResponse result = validator.createEmailAppPasswordReqValidator(request, mockHeaders)

        then: "Error response is returned"
        result != null
        result.errors.errorId == "MS_MPSYS_BE_100"
        result.errors.message == "ERR_INVALID_DATA : Missing or Invalid IdpTraceId"

     
    }

    def "should return error when idpTraceId starts with AutoGen_"() {
        given: "HttpHeaders with AutoGen_ idp-trace-id"
        mockHeaders.getHeaderString("idp-trace-id") >> "AutoGen_12345"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> { throw new RuntimeException() }

        and: "Valid request object"
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setMemberId("testUser")
        request.setDomain("att.net")
        request.setPasswordName("imap")

        when: "createEmailAppPasswordReqValidator is called"
        CreateEmailAppPasswordResponse result = validator.createEmailAppPasswordReqValidator(request, mockHeaders)

        then: "Error response is returned"
        result != null
        result.errors.errorId == "MS_MPSYS_BE_100"
        result.errors.message == "ERR_INVALID_DATA : Missing or Invalid IdpTraceId"
    }

    def "should return error when request is null"() {
        given: "HttpHeaders with valid idp-trace-id"
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-123"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        and: "Null request"
        CreateEmailAppPasswordRequest request = null

        when: "createEmailAppPasswordReqValidator is called"
        CreateEmailAppPasswordResponse result = validator.createEmailAppPasswordReqValidator(request, mockHeaders)

        then: "Error response is returned"
        result != null
        result.errors.errorId == "MS_MPSYS_BE_100"
        result.errors.message == "ERR_INVALID_DATA : Input Request is NULL / Empty."

    }


    @Unroll
    def "should return error when missing handle/domain/guid for #scenarioName"() {
        given: "HttpHeaders with valid idp-trace-id and X-ATT-ClientId"
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-789"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        and: "Request with missing fields"
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setMemberId(memberId)
        request.setDomain(domain)
        request.setGuid(guid)
        request.setPasswordName("imap")

        when: "createEmailAppPasswordReqValidator is called"
        CreateEmailAppPasswordResponse result = validator.createEmailAppPasswordReqValidator(request, mockHeaders)

        then: "Error response is returned"
        result != null
        result.errors.errorId == "MS_MPSYS_BE_100"


        where:
        scenarioName                 | memberId   | domain    | guid
        "missing all identifiers"    | null       | null      | null
        "missing handle with domain" | null       | "att.net" | null
        "missing domain with handle" | "testUser" | null      | null
        "all three present"          | "testUser" | "att.net" | "123"
    }

    def "should return error when passwordName is missing"() {
        given: "HttpHeaders with valid headers"
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-101"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        and: "Request with missing passwordName"
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setMemberId("testUser")
        request.setDomain("att.net")

        when: "createEmailAppPasswordReqValidator is called"
        CreateEmailAppPasswordResponse result = validator.createEmailAppPasswordReqValidator(request, mockHeaders)

        then: "Error response is returned"
        result != null
        result.errors.errorId == "MS_MPSYS_BE_100"
        result.errors.message == "ERR_INVALID_DATA : passwordName is required in input request."

    }

    def "should return error when passwordName is empty"() {
        given: "HttpHeaders with valid headers"
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-102"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        and: "Request with empty passwordName"
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setMemberId("testUser")
        request.setDomain("att.net")
        request.setPasswordName("")

        when: "createEmailAppPasswordReqValidator is called"
        CreateEmailAppPasswordResponse result = validator.createEmailAppPasswordReqValidator(request, mockHeaders)

        then: "Error response is returned"
        result != null
        result.errors.errorId == "MS_MPSYS_BE_100"
        result.errors.message == "ERR_INVALID_DATA : passwordName is required in input request."

    }

    @Unroll
    def "should return error when X-ATT-ClientId is #scenarioName"() {
        given: "HttpHeaders with invalid X-ATT-ClientId"
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-202"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> clientId

        and: "Valid request"
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setMemberId("testUser")
        request.setDomain("att.net")
        request.setPasswordName("imap")

        when: "createEmailAppPasswordReqValidator is called"
        CreateEmailAppPasswordResponse result = validator.createEmailAppPasswordReqValidator(request, mockHeaders)

        then: "Error response is returned"
        result != null
        result.errors.errorId == "MS_MPSYS_BE_100"
        result.errors.message == "ERR_INVALID_DATA : Missing or invalid X-ATT-ClientId in request header"


        where:
        scenarioName | clientId
        "null"       | null
        "empty"      | ""
        "invalid"    | "INVALID_CLIENT"
    }

    def "should return error when domain is SLID_DUM"() {
        given: "HttpHeaders with valid headers"
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-303"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        and: "Request with SLID_DUM domain"
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setMemberId("testUser")
        request.setDomain(CommonDefs.SLID_DUM)
        request.setPasswordName("imap")

        when: "createEmailAppPasswordReqValidator is called"
        CreateEmailAppPasswordResponse result = validator.createEmailAppPasswordReqValidator(request, mockHeaders)

        then: "Error response is returned"
        result != null
        result.errors.errorId == "MS_MPSYS_BE_442"
        result.errors.message == "ERR_NOT_MEMBER_ID: accessID is not allowed in input request."

    }

    def "should return null when request is valid with memberId and domain"() {
        given: "HttpHeaders with valid headers"
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-404"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        and: "Valid request with memberId and domain"
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setMemberId("testUser")
        request.setDomain("att.net")
        request.setPasswordName("imap")
        request.setSourceIPAddress("192.168.1.1")

        when: "createEmailAppPasswordReqValidator is called"
        CreateEmailAppPasswordResponse result = validator.createEmailAppPasswordReqValidator(request, mockHeaders)

        then: "Null is returned indicating valid request"
        result == null
        request.getIdpTraceId() == "trace-404"

    }

    def "should return null when request is valid with guid"() {
        given: "HttpHeaders with valid headers"
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-505"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        and: "Valid request with numerical guid"
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setGuid("12345")
        request.setPasswordName("imap")
        request.setSourceIPAddress("192.168.1.1")

        when: "createEmailAppPasswordReqValidator is called"
        CreateEmailAppPasswordResponse result = validator.createEmailAppPasswordReqValidator(request, mockHeaders)

        then: "Null is returned indicating valid request"
        result == null
        request.getIdpTraceId() == "trace-505"

    }

    def "should trim sourceIPAddress when present"() {
        given: "HttpHeaders with valid headers"
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-606"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        and: "Request with untrimmed sourceIPAddress"
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setMemberId("testUser")
        request.setDomain("att.net")
        request.setPasswordName("imap")
        request.setSourceIPAddress("  192.168.1.1  ")

        when: "createEmailAppPasswordReqValidator is called"
        CreateEmailAppPasswordResponse result = validator.createEmailAppPasswordReqValidator(request, mockHeaders)

        then: "Null is returned and sourceIPAddress is trimmed"
        result == null
        request.getSourceIPAddress() == "192.168.1.1"

    }

    def "should handle exception and return error response"() {
        given: "HttpHeaders with valid idp-trace-id"
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-exception"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> { throw new RuntimeException("Test exception") }

        and: "Valid request"
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setMemberId("testUser")
        request.setDomain("att.net")
        request.setPasswordName("imap")

        when: "createEmailAppPasswordReqValidator is called"
        CreateEmailAppPasswordResponse result = validator.createEmailAppPasswordReqValidator(request, mockHeaders)

        then: "Error response is returned with system error"
        result != null
        result.errors.errorId == "MS_MPSYS_BE_602"
        result.errors.message == "ERR_SYS_APPL : Exception thrown in CreateEmailAppPasswordRequestValidator : Test exception"

    }

    def "should validate valid calling system ID IDMPROFILE"() {
        given: "HttpHeaders with valid clientId"
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-707"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        and: "Valid request with numerical guid"
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setGuid("123")
        request.setPasswordName("imap")

        when: "createEmailAppPasswordReqValidator is called"
        CreateEmailAppPasswordResponse result = validator.createEmailAppPasswordReqValidator(request, mockHeaders)

        then: "Null is returned for valid calling system id"
        result == null

    }

    def "should return error when GUID contains non-numerical characters"() {
        given: "HttpHeaders with valid headers"
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-808"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        and: "Request with non-numerical GUID"
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setGuid("guid-abc123")
        request.setPasswordName("imap")

        when: "createEmailAppPasswordReqValidator is called"
        CreateEmailAppPasswordResponse result = validator.createEmailAppPasswordReqValidator(request, mockHeaders)

        then: "Error response is returned"
        result != null
        result.errors.errorId == "MS_MPSYS_BE_100"
        result.errors.message == "ERR_INVALID_DATA : GUID must contain only numerical values."

    }

    def "should accept GUID with only numerical characters"() {
        given: "HttpHeaders with valid headers"
        mockHeaders.getHeaderString("idp-trace-id") >> "trace-909"
        mockHeaders.getHeaderString("X-ATT-ClientId") >> "IDMPROFILE"

        and: "Request with numerical GUID"
        CreateEmailAppPasswordRequest request = new CreateEmailAppPasswordRequest()
        request.setGuid("123456789")
        request.setPasswordName("imap")

        when: "createEmailAppPasswordReqValidator is called"
        CreateEmailAppPasswordResponse result = validator.createEmailAppPasswordReqValidator(request, mockHeaders)

        then: "Null is returned for valid numerical GUID"
        result == null

    }
}