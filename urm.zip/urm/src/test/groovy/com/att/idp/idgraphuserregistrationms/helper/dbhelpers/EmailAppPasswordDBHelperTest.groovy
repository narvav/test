package com.att.idp.idgraphuserregistrationms.helper.dbhelpers

import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.JdbcTemplate
import com.att.idp.idgraphuserregistrationms.metrics.ErrorMetricHandler
import spock.lang.Specification

class EmailAppPasswordDBHelperTest extends Specification {
	
	JdbcTemplate jdbcTemplate = Mock(JdbcTemplate)
	ErrorMetricHandler errorMetricHandler = Mock(ErrorMetricHandler)
    def testObj = new EmailAppPasswordDBHelper()
    Logger logger = null
    HashMap<String, Object> hmDBInput = null
    List alQueryResponse = CommonUtil.arrayList
    HashMap<String, Object> hmQueryResponse = CommonUtil.hashMap
    List<Object> objectList = CommonUtil.arrayList
    HashMap<String, Object> hmResult = CommonUtil.hashMap
    String dateFormat = 'MMDDYYYY HH24:mi:ss'


    String sQuery = 'SELECT ' +
            'member_num, ' +
            'password_name, ' +
            'password_venc, ' +
            'TO_CHAR(create_date, \'' + dateFormat + '\') AS create_date, ' +
            'TO_CHAR(last_modified, \'' + dateFormat + '\') AS last_modified, ' +
            'last_modified_by ' +
            'FROM APPEMAILPASSWORD WHERE member_num = ?'


    def setup() throws Exception {
        testObj.jdbcTemplate=jdbcTemplate
        testObj.errorMetricHandler=errorMetricHandler
		logger = LoggerFactory.getLogger('ResetUserPassword')
        hmDBInput = CommonUtil.hashMap
        hmDBInput[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmDBInput[CommonDefs.HANDLE] = 'qyma123'
        hmDBInput[CommonDefs.DOMAIN] = 'slid.dum'

        hmDBInput[MPSDefs.DB_MEMBER_NUM] = '234782221'
        alQueryResponse.add(hmDBInput)
    }


    def "query email app pwd null input error case"() {
        when:
        HashMap resp = testObj.queryEmailAppPwd(null)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }


    def "query email app pwd null member num"() {
        given:
        hmDBInput.remove(MPSDefs.DB_MEMBER_NUM)
        when:
        hmResult= testObj.queryEmailAppPwd(hmDBInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }


    def "query email app pwd e r r r e c n o t f o u n d"() {
        when:
        HashMap resp = testObj.queryEmailAppPwd(hmDBInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'REC_NOT_FOUND'
    }


    def "query email app pwd s u c c e s s"() {
        given:
        objectList = new ArrayList<Object>()
        objectList.add('234782221')
        jdbcTemplate.queryForList(new String(sQuery), _) >> alQueryResponse
        when:
        HashMap resp = testObj.queryEmailAppPwd(hmDBInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }
    
     def "query email app pwd exception"() {
        given:
        hmDBInput[MPSDefs.DB_MEMBER_NUM] = 234782221
        when:
        hmResult = testObj.queryEmailAppPwd(hmDBInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }



    def "add email app pwd null input error case"() {
        when:
        HashMap resp = testObj.addEmailAppPwd(null)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }


    def "add email app pwd null fields"() {
        given:
        hmDBInput.remove(MPSDefs.DB_MEMBER_NUM)
        when:
        HashMap resp = testObj.addEmailAppPwd(hmDBInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }


    def "add email app pwd s u c c e s s password ox"() {
        given:
        hmDBInput[MPSDefs.DB_PASSWORD_NAME] = 'password'
        hmDBInput[MPSDefs.DB_PASSWORD_VENC] = '2347822'
        hmDBInput['password_ox'] = 'ps123'
        when:
        HashMap resp = testObj.addEmailAppPwd(hmDBInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }


    def "add email app pwd s u c c e s s"() {
        given:
        hmDBInput[MPSDefs.DB_PASSWORD_NAME] = 'password'
        hmDBInput[MPSDefs.DB_PASSWORD_VENC] = '2347822'
        when:
        HashMap resp = testObj.addEmailAppPwd(hmDBInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }


    def "add email app pwd e x p"() {
        given:
        hmDBInput[MPSDefs.DB_PASSWORD_NAME] = 'password'
        hmDBInput[MPSDefs.DB_PASSWORD_VENC] = '2347822'
		hmDBInput['password_ox'] = hmDBInput
        when:
        HashMap resp = testObj.addEmailAppPwd(hmDBInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "delete email app pwd null input error case"() {
        when:
        HashMap resp = testObj.deleteEmailAppPwd(null)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }


    def "delete email app pwd null member num"() {
        given:
        hmDBInput.remove(MPSDefs.DB_MEMBER_NUM)
        when:
        HashMap resp = testObj.deleteEmailAppPwd(hmDBInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }


    def "delete email app pwd s u c c e s s"() {
        given:
        hmDBInput[MPSDefs.DB_PASSWORD_NAME] = 'password'
        when:
        HashMap resp = testObj.deleteEmailAppPwd(hmDBInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }


    def "delete email app pwd e x p"() {
        given:
        hmDBInput[MPSDefs.DB_PASSWORD_NAME] = hmDBInput
        when:
        HashMap resp = testObj.deleteEmailAppPwd(hmDBInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "list email app pwd null input error case"() {
        when:
        HashMap resp = testObj.listEmailAppPwd(null)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
        0 * _
    }


    def "list email app pwd null member num"() {
        given:
        hmDBInput.remove(MPSDefs.DB_MEMBER_NUM)
        when:
        HashMap resp = testObj.listEmailAppPwd(hmDBInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
        0 * _
    }


    def "list email app pwd returns success with empty list when no records found"() {
        when:
        HashMap resp = testObj.listEmailAppPwd(hmDBInput)
        then:
        1 * jdbcTemplate.queryForList(_, _) >> []
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
        (resp[MPSDefs.DB_APPEMAILPASSWORD_TABLE] as List).isEmpty()
        0 * _
    }


    def "list email app pwd returns success with populated list when records found"() {
        given:
        HashMap row = new HashMap()
        row[MPSDefs.DB_MEMBER_NUM.toLowerCase()] = '234782221'
        row['password_name'] = 'testpwd'
        row['create_date'] = '01012025 00:00:00'
        when:
        HashMap resp = testObj.listEmailAppPwd(hmDBInput)
        then:
        1 * jdbcTemplate.queryForList(_, _) >> [row]
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
        !(resp[MPSDefs.DB_APPEMAILPASSWORD_TABLE] as List).isEmpty()
        0 * _
    }


    def "list email app pwd exception"() {
        when:
        HashMap resp = testObj.listEmailAppPwd(hmDBInput)
        then:
        1 * jdbcTemplate.queryForList(_, _) >> { throw new RuntimeException('DB error') }
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
        0 * _
    }
}
