package com.att.idp.idgraphuserregistrationms.helper

import com.att.mpsys.common.helpers.SoapHttpClient
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

class QueryProfileProofingInfoHelperTest extends Specification {
	
	def queryProfileProofingInfo_HObj = new QueryProfileProofingInfoHelper()

    SoapHttpClient oSoapHttpClient = Mock()

    String stTransactionId = null
    HashMap hmResult = null
    HashMap hmInput = null
    String stAppStatusMsg = null
    HashMap resultHashSuccess = null
    HashMap resultHashError = null
    HashMap getAuthInfoHs = new HashMap()
    HashMap hmResponse = null


    def setup() {
        queryProfileProofingInfo_HObj.oSoapHttpClient = oSoapHttpClient
        System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')
        stTransactionId = 'kan_00007186901'

        resultHashSuccess= CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG)
        resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, 'Error Returned')

        hmResponse = new HashMap()
        hmInput = new HashMap()
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmInput[CommonDefs.BAN] = '132456'

        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCallUpdateGetAuthInfoXML', 'Y')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfoURL', 'https://mps.red.dev.att.com/wsstubWeb/test?return=crm-Response.vm')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfoConnectTimeout', '5000')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfoReadTimeout', '10000')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfoMethodRequest', 'getAuthInfoRequest')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfom1NS', 'urn:mps.api.clarify.cc.sbc.com/message')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfom1NSPrefix', 'm1')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfom2NS', 'urn:mps.api.clarify.cc.sbc.com/types')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfom2NSPrefix', 'm2')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfom3NS', 'http://cio.att.com/commonheader/v3')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfom3NSPrefix', 'm3')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfom4NS', 'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfom4NSPrefix', 'm4')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfoTypeNS', 'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfoPasswordType', 'm4:PasswordString')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfoUserNameTokenType', 'm4:UsernameTokenType')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfoSbcUID', 'MPS_USER')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfoLoginName', 'MPS_USER')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfoPassword', 'm4:PasswordString')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfoApplicationId', 'MPS')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropLSCRMSecurityHeaderUser', 'm84196')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropLSCRMSecurityHeaderPassword', '1cf74c92bf4f0e70dd8b1b5d38eb1436')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sCfgIsParserNamespaceAware', 'Y')
        ReflectionTestUtils.setField(queryProfileProofingInfo_HObj, 'sPropCRMLSGetAuthInfom0NS', 'http://cio.att.com/commonheader/v3')
	}


    def "query c r m proofing no b a n error case"() throws Exception {
        given:
        hmInput[CommonDefs.BAN] = ''
        when:
        hmResult = queryProfileProofingInfo_HObj.queryCRMProofingInfo(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'ban is NULL'
    }


    def "query c r m proofing no c s i error case"() throws Exception {
        given:
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = ''
        when:
        hmResult = queryProfileProofingInfo_HObj.queryCRMProofingInfo(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'callingSystemId is NULL'
    }


   /* def "query c r m proofing s u c c e s s"() throws Exception {
        given:
        getAuthInfoHs[CommonDefs.COMMON_APP_CATEGORY_CODE] = CErrorDefs.COMMON_SUCCESS_MSG
        when:
        hmResult = queryProfileProofingInfo_HObj.queryCRMProofingInfo(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }


    def "query c r m proofing s u c c e s s case"() throws Exception {
        given:
        hmResult = queryProfileProofingInfo_HObj.queryCRMProofingInfo(hmInput)
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == 'SUCCESS'
    }*/


    def "query c r m proofing exception case"() throws Exception {
        when:
        hmResult = queryProfileProofingInfo_HObj.queryCRMProofingInfo(null)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "parse new get auth info response with n s support exception case"() throws Exception {
		//String str = "";
        when:
        hmResult = queryProfileProofingInfo_HObj.parseNewGetAuthInfoResponseWithNSSupport(null)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "parse new get auth info response exception case"() throws Exception {
        when:
        hmResult = queryProfileProofingInfo_HObj.parseNewGetAuthInfoResponse('9274uujkwqdmm')

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }
}
