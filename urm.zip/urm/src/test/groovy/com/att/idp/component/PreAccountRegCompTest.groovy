package com.att.idp.component

import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.AccountAutoRegDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.DBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetAllInfoDBHelper
import org.hamcrest.CoreMatchers
import org.spockframework.spring.SpringBean
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.transaction.PlatformTransactionManager
import org.springframework.transaction.TransactionStatus

import javax.swing.Spring

import static org.hamcrest.Matchers.anyOf

class PreAccountRegCompTest extends CompTestBase {

	private String uri = '/autoreg/preAccountReg'

	@SpringBean
	PlatformTransactionManager transactionManager = Stub(PlatformTransactionManager) {
		getTransaction(_) >> Stub(TransactionStatus)
	}

	@SpringBean
	DBHelper oDBHelper=Mock()


	private Map<String, String> getHeaders() {
		Map<String, String> headers = new HashMap<String, String>()
		headers['Content-Type'] = 'application/json'
		headers['X-ATT-ClientId'] ='DATAMGT'
		headers['idp-trace-id'] = 'cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0'
		return headers
	}


	def "pre account reg success"() {

		given:
		HashMap allInfo = readJsonFileToMap("mockResponse/allInfoResponse.json") as HashMap
		HashMap hmResponse =new HashMap()
		hmResponse.put("appStatusMsg", "SUCCESS")
		hmResponse.put("appInfo", " accountautoreg updated successfully")
		hmResponse.put("appStatusCode", "0")
		hmResponse.put("appCategoryCode", "0")
		accountAutoRegDBHelperObj.updateAccountAutoReg(_ as HashMap)>> hmResponse
		oDBHelper.getSorId(_ as String)>>3
		getAllInfo.getInfo(_ as HashMap) >> allInfo

		String req = '{\r\n' +
				'    "guid": "1020441427",\r\n' +
				'    "sorInvariantIdList": [\r\n' +
				'        {\r\n' +
				'            "sorName": "MO",\r\n' +
				'            "sorInvariantId": "328027688330"\r\n' +
				'        }\r\n' +
				'    ]\r\n' +
				'}\r\n' +
				''

		expect:
		givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then()
				.statusCode(200).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
				.body("appStatusCode", CoreMatchers.equalTo("0"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
}

	def "pre account reg sor Id error "() {

		given:
		HashMap allInfo = readJsonFileToMap("mockResponse/allInfoResponse.json") as HashMap

		oDBHelper.getSorId(_ as String)>>null
		getAllInfo.getInfo(_ as HashMap) >> allInfo

		String req = '{\r\n' +
				'    "guid": "1020441427",\r\n' +
				'    "sorInvariantIdList": [\r\n' +
				'        {\r\n' +
				'            "sorName": "MO",\r\n' +
				'            "sorInvariantId": "328027688330"\r\n' +
				'        }\r\n' +
				'    ]\r\n' +
				'}\r\n' +
				''

		expect:
		givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then()
				.statusCode(400).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
				.body("appStatusCode", CoreMatchers.equalTo("100"))
				.body("appInfo", CoreMatchers.equalTo("Invalid SorName"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}

	def "pre account reg update account null error"() {

		given:
		HashMap allInfo = readJsonFileToMap("mockResponse/allInfoResponse.json") as HashMap

		accountAutoRegDBHelperObj.updateAccountAutoReg(_ as HashMap)>> null
		oDBHelper.getSorId(_ as String)>>3
		getAllInfo.getInfo(_ as HashMap) >> allInfo

		String req = '{\r\n' +
				'    "guid": "1020441427",\r\n' +
				'    "sorInvariantIdList": [\r\n' +
				'        {\r\n' +
				'            "sorName": "MO",\r\n' +
				'            "sorInvariantId": "328027688330"\r\n' +
				'        }\r\n' +
				'    ]\r\n' +
				'}\r\n' +
				''

		expect:
		givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then()
				.statusCode(500).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_SYS_APPL"))
				.body("appStatusCode", CoreMatchers.equalTo("602"))
				.body("appInfo", CoreMatchers.equalTo("Null Response returned from AccountAutoRegDBHelper.updateAccountAutoReg"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}

	def "pre account reg all info error"() {

		given:
		getAllInfo.getInfo(_ as HashMap) >> null

		String req = '{\r\n' +
				'    "guid": "1020441427",\r\n' +
				'    "sorInvariantIdList": [\r\n' +
				'        {\r\n' +
				'            "sorName": "MO",\r\n' +
				'            "sorInvariantId": "328027688330"\r\n' +
				'        }\r\n' +
				'    ]\r\n' +
				'}\r\n' +
				''

		expect:
		givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then()
				.statusCode(500).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_SYS_APPL"))
				.body("appStatusCode", CoreMatchers.equalTo("602"))
				.body("appInfo", CoreMatchers.equalTo("Null Response returned from getAllInfo"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}

	def "pre account reg all info record not found"() {
		given:
		HashMap response = new HashMap()
		response.put("appStatusMsg", "REC_NOT_FOUND")
		response.put("sqlMsg", "N/A")
		response.put("appCategoryCode", "3")
		response.put("numRowsUpdated", "0")
		response.put("appStatusCode", "303")

		getAllInfo.getInfo(_ as HashMap) >> response

		String req = '{\r\n' +
				'    "guid": "1020441427",\r\n' +
				'    "sorInvariantIdList": [\r\n' +
				'        {\r\n' +
				'            "sorName": "MO",\r\n' +
				'            "sorInvariantId": "328027688330"\r\n' +
				'        }\r\n' +
				'    ]\r\n' +
				'}\r\n' +
				''

		expect:
		givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then()
				.statusCode(404).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_USER_NOT_FOUND"))
				.body("appStatusCode", CoreMatchers.equalTo("121"))
				.body("appInfo", CoreMatchers.equalTo("Input guid not found"))
				.body("error.errorId",CoreMatchers.equalTo("MS_MPSYS_BE_121"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}

	def "pre account reg update account error"() {

		given:
		HashMap allInfo = readJsonFileToMap("mockResponse/allInfoResponse.json") as HashMap
		HashMap hmResponse =new HashMap()
		hmResponse.put("appStatusMsg", "ERR_INVALID_DATA")
		hmResponse.put("appInfo", "Input sor_name/sor_id is not valid")
		hmResponse.put("appStatusCode", "100")
		hmResponse.put("appCategoryCode", "100")
		accountAutoRegDBHelperObj.updateAccountAutoReg(_ as HashMap)>> hmResponse
		oDBHelper.getSorId(_ as String)>>3
		getAllInfo.getInfo(_ as HashMap) >> allInfo

		String req = '{\r\n' +
				'    "guid": "1020441427",\r\n' +
				'    "sorInvariantIdList": [\r\n' +
				'        {\r\n' +
				'            "sorName": "MO",\r\n' +
				'            "sorInvariantId": "328027688330"\r\n' +
				'        }\r\n' +
				'    ]\r\n' +
				'}\r\n' +
				''

		expect:
		givenBaseSpec().headers(getHeaders()).body(req).when().post(uri).then()
				.statusCode(400).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
				.body("appStatusCode", CoreMatchers.equalTo("100"))
				.body("appInfo", CoreMatchers.equalTo("Input sor_name/sor_id is not valid"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}
}
