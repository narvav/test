package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.AccountInfoDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetMemberServicesDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetProvisionedServicesDBHelper
import com.att.idp.idgraphuserregistrationms.queue.message.helpers.ValidateAndSyncG2QueueHelper
import com.att.idp.idgraphuserregistrationms.resource.request.SyncUserProfileRequest
import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.att.mpsys.common.utils.*
import org.bouncycastle.util.Exceptions
import org.springframework.beans.factory.annotation.Autowired
import spock.lang.Specification
import spock.lang.Unroll


class ValidateAndSyncG2HelperTest extends Specification {

    def validateAndSyncG2Helper=new ValidateAndSyncG2Helper();

    AccountInfoDBHelper accountInfoDBHelper=Mock(AccountInfoDBHelper)

    GetProvisionedServicesDBHelper provisionedServicesDBHelper=Mock(GetProvisionedServicesDBHelper)

    SyncUserProfileRequest validateAndSyncG2Request=Mock(SyncUserProfileRequest)

    FeatureManagerHelper featureManager = Mock(FeatureManagerHelper)
    SyncOperationFactory syncOperationFactory = Mock(SyncOperationFactory)
    SyncOperation syncOperation = Mock(SyncOperation)


    GetMemberServicesDBHelper memberServicesDBHelper=Mock(GetMemberServicesDBHelper)
    ValidateAndSyncG2QueueHelper validateAndSyncG2QueueHelper=Mock(ValidateAndSyncG2QueueHelper)
    private SyncUserProfileHelper syncUserProfileHelper
    private HashMap hmAccountInfo = CommonUtil.hashMap
    private ArrayList alQueryResponse = CommonUtil.arrayList
    private HashMap hmAccInfoResponse = CommonUtil.hashMap

    private HashMap asyncResponse = CommonUtil.hashMap


    def setup() {
    
        validateAndSyncG2Helper.accountInfoDBHelper=accountInfoDBHelper
        validateAndSyncG2Helper.provisionedServicesDBHelper=provisionedServicesDBHelper
        validateAndSyncG2Helper.validateAndSyncG2QueueHelper=validateAndSyncG2QueueHelper
        validateAndSyncG2Helper.memberServicesDBHelper=memberServicesDBHelper
   /*     validateAndSyncG2Helper.featureManager=featureManager
        validateAndSyncG2Helper.syncOperationFactory=syncOperationFactory*/
        //validateAndSyncG2Helper.syncUserProfileHelper=validateAndSyncG2Request
        
        validateAndSyncG2Request = new SyncUserProfileRequest()
        validateAndSyncG2Request.idpTraceId = 'idp-trace-id'
    }


    def "validate and sync g2 returns expected result when account info is empty test"() {

        given:
        validateAndSyncG2Request.idpTraceId = 'traceId'
        validateAndSyncG2Request.transactionName = 'transactionName'
        validateAndSyncG2Request.callingSystemId = 'callingSystemId'
        validateAndSyncG2Request.ban = 'ban'

        HashMap<String, Object> accountInfo = new HashMap<>()
        accountInfo[CommonDefs.ACCOUNT_INFO_KEY] = new HashMap<>()
        accountInfoDBHelper.getAccountInfo(_) >> accountInfo

        HashMap<String, Object> expectedResponse = new HashMap<>()
        expectedResponse['appStatusCode'] = 'SUCCESS'
        HashMap<String, Object> provServicesMap = new HashMap<>()
        provServicesMap['HSIA'] = 'HSIA'
        expectedResponse[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        // provServicesMap.put("services", provServicesMap);
        expectedResponse['services'] = provServicesMap
        
        memberServicesDBHelper.getMemberServices(_) >> expectedResponse
        validateAndSyncG2QueueHelper.makeAsyncCall(_,_) >> expectedResponse
        syncUserProfileHelper.syncUserProfile(_) >> expectedResponse
        
        //when:
        HashMap<String, Object> result = (HashMap<String, Object>) validateAndSyncG2Helper.validateAndSyncG2SoapAPI(validateAndSyncG2Request)
       // then:
       // result == expectedResponse
    }


    def "validate and sync g2 customer not registered test"() {

        given:
        validateAndSyncG2Request.idpTraceId = 'traceId'
        validateAndSyncG2Request.transactionName = 'transactionName'
        validateAndSyncG2Request.callingSystemId = 'callingSystemId'
        validateAndSyncG2Request.ban = 'ban'

        HashMap<String, Object> accountInfo = new HashMap<>()
        accountInfo[CommonDefs.ACCOUNT_INFO_KEY] = new HashMap<>()
        accountInfoDBHelper.getAccountInfo(_) >> accountInfo

        HashMap<String, Object> expectedResponse = new HashMap<>()
        expectedResponse['appStatusCode'] = '0'
        HashMap<String, Object> asyncResponse = new HashMap<>()
        asyncResponse['appStatusCode'] = '285'
        validateAndSyncG2QueueHelper.makeAsyncCall(_,_) >> asyncResponse
        HashMap<String, Object> provServicesMap = new HashMap<>()
        provServicesMap['HSIA'] = 'HSIA'
        expectedResponse['services'] = provServicesMap
        provisionedServicesDBHelper.getProvisionedServices(_) >> expectedResponse
        when:
        HashMap<String, Object> result = (HashMap<String, Object>) validateAndSyncG2Helper.validateAndSyncG2SoapAPI(validateAndSyncG2Request)
        then:
        result['appInfo'] == 'Customer not registered'
    }


    def "validate and sync g2 get memeber services with empty response test"() {
        given:
        validateAndSyncG2Request.idpTraceId = 'traceId'
        validateAndSyncG2Request.transactionName = 'transactionName'
        validateAndSyncG2Request.callingSystemId = 'callingSystemId'
        validateAndSyncG2Request.ban = 'ban'

        HashMap<String, Object> accountInfo = new HashMap<>()
        accountInfo[CommonDefs.ACCOUNT_INFO_KEY] = new HashMap<>()
        accountInfoDBHelper.getAccountInfo(_) >> accountInfo

        HashMap<String, Object> expectedResponse = new HashMap<>()
        expectedResponse['appStatusCode'] = '0'
        HashMap<String, Object> asyncResponse = new HashMap<>()
        asyncResponse['appStatusCode'] = '285'
        validateAndSyncG2QueueHelper.makeAsyncCall(_,_) >> asyncResponse
        HashMap<String, Object> provServicesMap = new HashMap<>()
        provServicesMap['HS-IA'] = 'HSIA'
        expectedResponse['services'] = provServicesMap
        provisionedServicesDBHelper.getProvisionedServices(_) >> expectedResponse
        memberServicesDBHelper.getMemberServices(_) >> null

        when:
        HashMap<String, Object> result = (HashMap<String, Object>) validateAndSyncG2Helper.validateAndSyncG2SoapAPI(validateAndSyncG2Request)
        then:
        result['appInfo'] == 'MemberServicesDBHelper returned null / empty response'
    }


    def "validate and sync g2 get sync user profile with empty response test"() {
        given:
        validateAndSyncG2Request.idpTraceId = 'idp-trace-id'
        validateAndSyncG2Request.transactionName = 'transactionName'
        validateAndSyncG2Request.callingSystemId = 'callingSystemId'
        validateAndSyncG2Request.ban = 'ban'
        HashMap<String, Object> accountInfo = new HashMap<>()
        accountInfo[CommonDefs.ACCOUNT_INFO_KEY] = new HashMap<>()
        accountInfoDBHelper.getAccountInfo(_) >> accountInfo
        HashMap<String, Object> expectedResponse = new HashMap<>()
        expectedResponse['appStatusCode'] = '0'
        HashMap<String, Object> asyncResponse = new HashMap<>()
        asyncResponse['appStatusCode'] = '285'
        validateAndSyncG2QueueHelper.makeAsyncCall(_,_) >> asyncResponse
        HashMap<String, Object> provServicesMap = new HashMap<>()
        provServicesMap['HS-IA'] = 'HSIA'
        expectedResponse['services'] = provServicesMap
        provisionedServicesDBHelper.getProvisionedServices(_) >> expectedResponse
        HashMap<String, Object> memberResponse = new HashMap<>()
        HashMap<String, Object> memServicesMap = new HashMap<>()
        memServicesMap['HSIA'] = 'HSIA'
        memberResponse['parent_child_ind'] = 'P'
        memberResponse['services'] = memServicesMap

        memberServicesDBHelper.getMemberServices(_) >> memberResponse
        syncUserProfileHelper.syncUserProfile(_) >> null

        //when:
        HashMap<String, Object> result = (HashMap<String, Object>) validateAndSyncG2Helper.validateAndSyncG2SoapAPI(validateAndSyncG2Request)
       // then:
       // result['appInfo'] == 'Null Response returned from oSyncUserProfileHelper.syncUserProfileRequest()'
    }


    def "validate and sync g2 customer not provisioned test"() {

        given:
        validateAndSyncG2Request.transactionName = 'transactionName'
        validateAndSyncG2Request.callingSystemId = 'callingSystemId'
        validateAndSyncG2Request.ban = 'ban'

        HashMap<String, Object> accountInfo = new HashMap<>()
        accountInfo[CommonDefs.ACCOUNT_INFO_KEY] = new HashMap<>()
        accountInfoDBHelper.getAccountInfo(_) >> accountInfo

        HashMap<String, Object> expectedResponse = new HashMap<>()
        expectedResponse['appStatusCode'] = '0'
        HashMap<String, Object> asyncResponse = new HashMap<>()
        asyncResponse['appStatusCode'] = '285'
        validateAndSyncG2QueueHelper.makeAsyncCall(_,_) >> asyncResponse
        HashMap<String, Object> provServicesMap = new HashMap<>()
        provServicesMap['HS-IA'] = 'HSIA'
        expectedResponse['services'] = provServicesMap
        provisionedServicesDBHelper.getProvisionedServices(_) >> expectedResponse
        HashMap<String, Object> memberResponse = new HashMap<>()
        HashMap<String, Object> memServicesMap = new HashMap<>()
        memServicesMap['HSIA'] = 'HSIA'
        memberResponse['parent_child_ind'] = 'S'
        memberResponse['services'] = memServicesMap

        memberServicesDBHelper.getMemberServices(_) >> memberResponse

        when:
        HashMap<String, Object> result = (HashMap<String, Object>) validateAndSyncG2Helper.validateAndSyncG2SoapAPI(validateAndSyncG2Request)
        then:
        result['appInfo'] == 'Customer not provisioned'
    }


    def "validate and sync g2 returns empty result when account info is empty"() {
        given:
        accountInfoDBHelper.getAccountInfo(_)>> null
        when:
        HashMap<String, Object> result = (HashMap<String, Object>) validateAndSyncG2Helper.validateAndSyncG2SoapAPI(validateAndSyncG2Request)
        then:
        result['appInfo'] == 'Null Response returned from accountInfoDBHelper.getAccountInfo'
    }


    def "validate and sync g2 returns empty result when account info does not contain key test"() {

        given:
        hmAccountInfo[CommonDefs.HSIA_TOS] = CommonDefs.IND_Y

        hmAccountInfo['hsia_tos_date'] = '04152014 06:58:58'

        alQueryResponse.add(hmAccountInfo)
        hmAccInfoResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAccInfoResponse[CommonDefs.ACCOUNT_INFO_KEY] = alQueryResponse
        validateAndSyncG2Request.idpTraceId = '998734:4e4w2r3:4e4w2r3:4e4w2r3'
        validateAndSyncG2Request.ban = '1234Vd'
        accountInfoDBHelper.getAccountInfo(_ as String)>> hmAccInfoResponse
        when:
        HashMap<String, Object> result = (HashMap<String, Object>) validateAndSyncG2Helper.validateAndSyncG2SoapAPI(validateAndSyncG2Request)

        then:
        Integer.parseInt((String) result[CommonDefs.COMMON_APP_STATUS_CODE]) == CErrorDefs.ERR_SYS_APPL_NUM
    }


    def "validate and sync g2 ban not found in account info test"() {

        given:
        SyncUserProfileRequest syncUserProfileRequest = new SyncUserProfileRequest()
        alQueryResponse.add(hmAccountInfo)
        hmAccInfoResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAccInfoResponse[CommonDefs.ACCOUNT_INFO_KEY] = alQueryResponse
        hmAccInfoResponse['appStatusCode'] = '285'
        syncUserProfileRequest.idpTraceId = '998734:4e4w2r3:4e4w2r3:4e4w2r3'
        syncUserProfileRequest.ban = '1234Vd'
        accountInfoDBHelper.getAccountInfo(_ as String)>> hmAccInfoResponse
        when:
        HashMap<String, Object> result = (HashMap<String, Object>) validateAndSyncG2Helper.validateAndSyncG2SoapAPI(syncUserProfileRequest)
        then:
        result['appInfo'] == 'BAN not found in MPS'
    }


    def "validate and sync g2 make async call test"() {
        given:
        hmAccountInfo[CommonDefs.HSIA_TOS] = CommonDefs.IND_Y
        hmAccountInfo['hsia_tos_date'] = '04152014 06:58:58'
        alQueryResponse.add(hmAccountInfo)
        hmAccInfoResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        hmAccInfoResponse[CommonDefs.ACCOUNT_INFO_KEY] = alQueryResponse
        validateAndSyncG2Request.idpTraceId = '998734:4e4w2r3:4e4w2r3:4e4w2r3'
        validateAndSyncG2Request.ban = '1234Vd'
        accountInfoDBHelper.getAccountInfo(_ as String)>> hmAccInfoResponse
        asyncResponse['appStatusCode'] = 'SUCCESS'
        asyncResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        asyncResponse['appStatusCode'] = 'SUCCESS'
        validateAndSyncG2QueueHelper.makeAsyncCall(_ , _ as String)>> asyncResponse
        when:
        HashMap<String, Object> result = (HashMap<String, Object>) validateAndSyncG2Helper.validateAndSyncG2SoapAPI(validateAndSyncG2Request)
        then:
        Integer.parseInt((String) result[CommonDefs.COMMON_APP_STATUS_CODE]) == CErrorDefs.ERR_SYS_APPL_NUM
    }

    /*def "should perform sync operation when G2 feature is enabled for G2ldap"() {
        given: "A SyncUserProfileRequest and mocks for feature flag and sync operation"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.ban = "123456789"
        Map<String, Object> expectedResult = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        featureManager.isEnabled("svc-idgraph-userreg-enable-g2sync-extclient") >> true
        syncOperationFactory.getSyncOperation("G2LDAP") >> syncOperation
        syncOperation.performSync(_ as HashMap) >> expectedResult

        when: "validateAndSyncG2 is called"
        Map<String, Object> result = validateAndSyncG2Helper.validateAndSyncG2(request)

        then: "Result is as expected"
        result == expectedResult

    }

    def "shouldnt perform sync operation when G2 feature is enabled for  others"() {
        given:
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.ban = "123456789"
        featureManager.isEnabled("svc-idgraph-userreg-enable-g2sync-extclient") >> true
        syncOperationFactory.getSyncOperation("g2") >>{throw new IllegalArgumentException("Invalid destination")}

        when: "validateAndSyncG2 is called"
        Map<String, Object> result = validateAndSyncG2Helper.validateAndSyncG2(request)

        then: "Result is as expected"
        result == CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "SYSTEM ERROR")
    }*/
}
