package com.att.idp.idgraphuserregistrationms.service.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.helper.ReprovisionUverseHelper
import com.att.idp.idgraphuserregistrationms.resource.request.SyncUserProfileRequest
import com.att.idp.idgraphuserregistrationms.resource.response.SyncUserProfileResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.junit.jupiter.api.Assertions

import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedMap


class ReprovisionUverseServiceImplTest extends Specification {


    def reprovisionUverseServiceImplObj=new ReprovisionUverseServiceImpl()

    ReprovisionUverseHelper reprovisionUverseHelperObj=Mock(ReprovisionUverseHelper)

    SyncUserProfileRequest requestObj = null

    private HttpHeaders httpHeaders


    def setup() throws Exception {
        reprovisionUverseServiceImplObj.reprovisionUverseHelper = reprovisionUverseHelperObj
        requestObj = new SyncUserProfileRequest()
        requestObj.callingSystemId = 'IDP'
        requestObj.unvalidatedHandle = 'handle'
        requestObj.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
    }


    def "test reprovisionuverse null case"() {
        when:
        SyncUserProfileResponse response = reprovisionUverseServiceImplObj.reprovisionUverse(requestObj, (MultivaluedMap<String, String>) httpHeaders)
        then:
        response.appInfo == 'Null response from reprovisionUverseHelper.disconnectReconnect'
        HashMap hmResponse = new HashMap()
        when:
        hmResponse[MPSDefs.APP_STATUS_CODE] = null
        reprovisionUverseHelperObj.disconnectReconnect(_ as Map as SyncUserProfileRequest)>>hmResponse
        and:
        response = reprovisionUverseServiceImplObj.reprovisionUverse(requestObj, (MultivaluedMap<String, String>) httpHeaders)
        then:
        response.appInfo == 'Null response from reprovisionUverseHelper.disconnectReconnect'
    }


    def "test reprovisionuverse success case"() {
        given:
        HashMap hmResponse = new HashMap()
        hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_16374856'
        hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
        hmResponse['appInfo'] = 'Success'
        reprovisionUverseHelperObj.disconnectReconnect(_)>>hmResponse
        when:
        SyncUserProfileResponse response = reprovisionUverseServiceImplObj.reprovisionUverse(requestObj, (MultivaluedMap<String, String>) httpHeaders)
        then:
        response.appStatusMsg == 'SUCCESS'
    }

}
