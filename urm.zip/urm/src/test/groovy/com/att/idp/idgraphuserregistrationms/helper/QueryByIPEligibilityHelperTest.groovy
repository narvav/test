package com.att.idp.idgraphuserregistrationms.helper

import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Specification

import jakarta.ws.rs.core.Response

class QueryByIPEligibilityHelperTest extends Specification {

	Map<String, Object> hmInput = new HashMap()
    Map<String, Object> hmResult = null
    HashMap hmSuccessResponse = new HashMap()
    HashMap hmErrorResponse = new HashMap()
    String transId = 'QIEtest123'
    Response response = null
    private Logger logger = null
    private String stAppInfo
    HashMap hmResponse = null
	
	def oQueryByIPEligibilityHelper = new QueryByIPEligibilityHelper()
	G2GetBANByIPHelper g2GetBANByIP = Mock(G2GetBANByIPHelper)


    def setup() {
    
        oQueryByIPEligibilityHelper.g2GetBANByIP=g2GetBANByIP
        
        logger = LoggerFactory.getLogger('.queryByIPEligibility.')
        //System.setProperty('CommonConfigurationFilePath', './opt/att/ajsc/config/CommonConfigurationTest.xml')
        hmSuccessResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        hmErrorResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_LENGTH_NUM, 'Error')
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.IS_EXTERNAL_CALL] = 'Y'
        hmInput[CommonDefs.TRANSACTION_NAME] = 'QueryByIPEligibility'
        hmInput[CommonDefs.IP_ADDRESS] = '2611:1711:4881:3931:2a16:adsf:fe19:7be4'
        hmInput[CommonDefs.TRANSACTION_ID] = transId

    }


    def "test query by i p eligibility null input hash case"() throws Exception {
        when:
        hmResult = oQueryByIPEligibilityHelper.queryByIPEligibility(null)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Input Hash is NULL'
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }


    def "test query by i p eligibility success"() throws Exception {
        given:
        hmSuccessResponse[CommonDefs.G2_RESULTCODE] = '100'
        hmSuccessResponse[CommonDefs.G2_BAN] = '1234567890'
        hmSuccessResponse['gSiteID'] = '123 '
        g2GetBANByIP.getBANByIP(_ as HashMap) >> hmSuccessResponse
        hmResult = oQueryByIPEligibilityHelper.queryByIPEligibility(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'

    }


    def "test g2 result code null"() throws Exception {
        given:
        hmSuccessResponse[CommonDefs.G2_RESULTCODE] = null
        g2GetBANByIP.getBANByIP(_ as HashMap) >> hmSuccessResponse
        hmResult = oQueryByIPEligibilityHelper.queryByIPEligibility(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'BAN could not be retrieved from LDAP RG record'

    }


    def "test g2 get b a n null"() throws Exception {
        given:
        hmSuccessResponse[CommonDefs.G2_RESULTCODE] = '100'
        hmSuccessResponse[CommonDefs.G2_BAN] = null
        g2GetBANByIP.getBANByIP(_ as HashMap) >> hmSuccessResponse
        hmResult = oQueryByIPEligibilityHelper.queryByIPEligibility(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'BAN could not be retrieved from LDAP RG record'

    }


    def "test site id null"() throws Exception {
        given:
        hmSuccessResponse[CommonDefs.G2_RESULTCODE] = '100'
        hmSuccessResponse[CommonDefs.G2_BAN] = '1234567890'
		hmSuccessResponse[CommonDefs.SITE_ID] = ' '
		g2GetBANByIP.getBANByIP(_ as HashMap) >> hmSuccessResponse
		hmResult = oQueryByIPEligibilityHelper.queryByIPEligibility(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Site_Id could not be retrieved from LDAP RG record'

    }


    def "test query i p eligibility null"() throws Exception {
        given:
        hmErrorResponse = null
        g2GetBANByIP.getBANByIP(_ as HashMap) >> hmErrorResponse
		hmResult = oQueryByIPEligibilityHelper.queryByIPEligibility(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Null Response from G2GetBANByIPHelper'

    }

    def "test g2ban helper error case"() throws Exception {
        given:
        hmErrorResponse[CommonDefs.COMMON_APP_STATUS_CODE] = '100'
        hmErrorResponse[CommonDefs.COMMON_APP_INFO] = 'G2GetBANByIPHelper returned an error'
		g2GetBANByIP.getBANByIP(_ as HashMap) >> hmErrorResponse
		hmResult = oQueryByIPEligibilityHelper.queryByIPEligibility(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'G2GetBANByIPHelper returned an error'

    }
    def "test exception handling in queryByIPEligibility"() throws Exception {
        given:
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.IP_ADDRESS] = '2611:1711:4881:3931:2a16:adsf:fe19:7be4'
        hmInput[CommonDefs.TRANSACTION_ID] = transId
        g2GetBANByIP.getBANByIP(_ as HashMap) >> new RuntimeException("Test Exception")

        when:
        hmResult = oQueryByIPEligibilityHelper.queryByIPEligibility(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

 /*   def "test null app status code"() throws Exception {
        given:
        hmSuccessResponse[CommonDefs.G2_RESULTCODE] = '100'
        hmSuccessResponse[CommonDefs.G2_BAN] = '1234567890'
        hmSuccessResponse[CommonDefs.COMMON_APP_STATUS_CODE] = null
        g2GetBANByIP.getBANByIP(_ as HashMap) >> hmSuccessResponse


        when:
        hmResult = oQueryByIPEligibilityHelper.queryByIPEligibility(hmInput)
        then:
        stAppInfo == 'null response from G2GetBANByIPHelper'                 //else block doesn't get covered
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }*/
}
