package com.att.idp.idgraphuserregistrationms.helper.dbhelpers

import com.att.common.validators.ServiceValidation
import com.att.common.validators.SystemOfRecordValidation
import com.att.idp.idgraphuserregistrationms.exceptions.MPSException
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs
import org.springframework.jdbc.core.JdbcTemplate
import com.att.idp.idgraphuserregistrationms.metrics.ErrorMetricHandler
import spock.lang.Specification


class MemberServiceAttributeDBHelperTest extends Specification {
	
	def testObj = new MemberServiceAttributeDBHelper()

	JdbcTemplate jdbcTemplate = Mock(JdbcTemplate)
	ErrorMetricHandler errorMetricHandler = Mock(ErrorMetricHandler)

	DBHelper oDBHelper = Mock(DBHelper)

    ServiceValidation oServiceValidation = Mock(ServiceValidation)

    SystemOfRecordValidation oSystemOfRecordValidation = Mock(SystemOfRecordValidation)

    private HashMap<String, Object> hmResult = null
    private HashMap<String, Object> hmInput = null


    def setup() {
    
        testObj.jdbcTemplate = jdbcTemplate
        testObj.errorMetricHandler = errorMetricHandler
        testObj.oDBHelper = oDBHelper
        testObj.oServiceValidation = oServiceValidation
        testObj.oSystemOfRecordValidation = oSystemOfRecordValidation
    
		hmInput = CommonUtil.hashMap
        hmInput[MPSDefs.DB_MEMBER_NUM] = '25345273'
        hmInput[MPSDefs.DB_SERVICE_ID] = '32'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[MPSDefs.DB_SERVICE_NAME] = 'MOBILITY'
        hmInput[MPSDefs.DB_SOR_ID] = '2'
        hmInput[MPSDefs.DB_SOR_NAME] = 'MO'
        hmInput[MPSDefs.DB_INSTANCE_ID] = '23473846223'
        hmInput[MPSDefs.DB_SOR_INVARIANT_ID] = '23473846223'
        hmInput[MPSDefs.DB_ATTRIBUTE_ID] = '1'
        hmInput['attributeName'] = 'O'
        hmInput['attributeValue'] = 'ac'
    }


    def "add service attributenull input"() {
        when:
        hmResult = testObj.addServiceAttribute(null)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'hmInput is null'
    }


    def "add service attributenull service id and name"() {
        given:
        hmInput[MPSDefs.DB_SERVICE_ID] = null
        hmInput[MPSDefs.DB_SERVICE_NAME] = null

        when:
        hmResult = testObj.addServiceAttribute(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'service_id or service_name is required'
    }


    def "add service attributenull attribute name"() {
        given:
        hmInput['attributeName'] = null

        when:
        hmResult = testObj.addServiceAttribute(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Required Parameter attribute_Name is missing'
    }


    def "add service attributenull member num"() {
        given:
        hmInput[MPSDefs.DB_MEMBER_NUM] = null

        when:
        hmResult = testObj.addServiceAttribute(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Required Parameter member_num / last_modified_by / attribute_value is missing'
    }


    def "add service attributenull ids success"() throws MPSException {
        given:
        hmInput[MPSDefs.DB_SERVICE_ID] = null
        hmInput[MPSDefs.DB_SOR_ID] = null
        hmInput[MPSDefs.DB_ATTRIBUTE_ID] = null

        oDBHelper.getServiceId(_) >> 32

        when:
        hmResult = testObj.addServiceAttribute(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "add service attributenull names success"() throws MPSException {
        given:
        hmInput[MPSDefs.DB_SERVICE_NAME] = null
        hmInput[MPSDefs.DB_SOR_ID] = null
        hmInput[MPSDefs.DB_SOR_NAME] = null
        hmInput[MPSDefs.DB_INSTANCE_ID] = null
        hmInput[MPSDefs.DB_SOR_INVARIANT_ID] = null
        hmInput[MPSDefs.DB_ATTRIBUTE_ID] = null

        when:
        hmResult = testObj.addServiceAttribute(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "add service attributenull i ds exception"() throws MPSException {
        given:
        hmInput[MPSDefs.DB_SERVICE_ID] = 32

        when:
        hmResult = testObj.addServiceAttribute(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "get serv attributes by member num null input"() throws MPSException {
        given:
        hmInput[MPSDefs.DB_MEMBER_NUM] = null

        when:
        hmResult = testObj.getServiceAttributesByMemberNum(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'member_num is null or missing in input'
    }


    def "get service attributes by member num rec not found"() {
        
        given:
        List alQueryResponse = new ArrayList<Object>()
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        when:
        hmResult = testObj.getServiceAttributesByMemberNum(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'REC_NOT_FOUND'
    }


    def "get service attributes by member num success"() {
        given:
        String dateFormat = 'MMDDYYYY HH24:mi:ss'
        HashMap<String, Object> hmQuerySvcAttributeResp = CommonUtil.hashMap
        List alQueryResponse = CommonUtil.arrayList

        hmQuerySvcAttributeResp[MPSDefs.DB_SOR_ID] = '17'
        hmQuerySvcAttributeResp[MPSDefs.DB_SOR_NAME] = 'MO'

        hmQuerySvcAttributeResp[MPSDefs.DB_SERVICE_ID] = '24'
        hmQuerySvcAttributeResp[MPSDefs.DB_SERVICE_NAME] = 'MOSUB'
        hmQuerySvcAttributeResp[MPSDefs.DB_INSTANCE_ID] = '7000035190'
        hmQuerySvcAttributeResp[MPSDefs.DB_SOR_INVARIANT_ID] = '7000035190'

        hmQuerySvcAttributeResp[MPSDefs.DB_ATTRIBUTE_ID] = '297'
        hmQuerySvcAttributeResp[MPSDefs.DB_ATTRIBUTE_NAME] = 'MOBILITY_ACCOUNT_SUBTYPE'
        hmQuerySvcAttributeResp[MPSDefs.DB_ATTRIBUTE_VALUE] = 'O'
		hmQuerySvcAttributeResp[MPSDefs.DB_CREATE_DATE] = '03052023 02:52:21'
		hmQuerySvcAttributeResp[MPSDefs.DB_LAST_MODIFIED] = '03052023 02:52:21'
		hmQuerySvcAttributeResp[MPSDefs.DB_LAST_MODIFIED_BY] = 'DATAMGT'

		alQueryResponse.add(hmQuerySvcAttributeResp)

        jdbcTemplate.queryForList(_,_) >> alQueryResponse
		//Mockito.when(jdbcTemplate.queryForList(_, '25345273'))
		//		.thenReturn(alQueryResponse)

        when:
        hmResult = testObj.getServiceAttributesByMemberNum(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Success'
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }


    def "get service attributes by member num exception"() {
        when:
        hmResult = testObj.getServiceAttributesByMemberNum(null)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SYSTEM ERROR'
    }
}
