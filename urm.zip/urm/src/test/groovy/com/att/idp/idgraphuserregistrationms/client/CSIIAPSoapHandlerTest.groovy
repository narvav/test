import com.att.idp.core.exception.ServiceException
import com.att.idp.idgraphuserregistrationms.client.CSIIAPSoapHandler
import com.att.idp.idgraphuserregistrationms.client.csi.CSIHeader
import com.att.idp.idgraphuserregistrationms.message.ErrorMessages
import com.att.idp.idgraphuserregistrationms.utils.CommonUtilHelper
import com.att.idp.soap.csi.config.CsiSoapClientConfigurer
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.CommonUtil
import com.cingular.csi.csi.namespaces.container._public.inquireaccountprofileresponse.InquireAccountProfileResponseInfo
import com.cingular.csi.csi.namespaces.container._public.inquireaccountprofilerequest.InquireAccountProfileRequestInfo
import jakarta.xml.bind.JAXBElement
import org.springframework.ws.client.core.WebServiceTemplate
import org.springframework.ws.soap.SoapFaultDetail
import org.springframework.ws.soap.client.SoapFaultClientException
import spock.lang.Specification
import spock.lang.Unroll

/**
 * Spock test for CSISoapHandler covering all success and error scenarios.
 */
class CSIIAPSoapHandlerTest extends Specification {

    CsiSoapClientConfigurer csiSoapClientConfigurer
    WebServiceTemplate webServiceTemplate
    CommonUtilHelper commonUtilHelper
    CSIIAPSoapHandler<InquireAccountProfileRequestInfo> csiSoapHandler

    void setup() {
        csiSoapClientConfigurer = Mock(CsiSoapClientConfigurer)
        webServiceTemplate = Mock(WebServiceTemplate)
        commonUtilHelper = Mock(CommonUtilHelper)
        csiSoapHandler = new CSIIAPSoapHandler<InquireAccountProfileRequestInfo>()
        csiSoapHandler.csiSoapClientConfigurer = csiSoapClientConfigurer
        csiSoapHandler.setWebServiceTemplate(webServiceTemplate)
    }

    @Unroll
    def "should initialize SOAP client configuration for #scenarioName"() {
        given: "A CSISoapHandler with or without configurer"
        csiSoapHandler.csiSoapClientConfigurer = configurer

        when: "init is called"
        csiSoapHandler.init()

        then: "Configurer is called only if not null"
        callCount * configurer?.configure(csiSoapHandler, 'iap')

        where:
        scenarioName         | configurer                | callCount
        'configurer present' | Mock(CsiSoapClientConfigurer) | 0
        'configurer null'    | null                      | 0
    }


    @Unroll
    def "should handle null or empty response for #scenarioName2"() {
        given: "A valid IAP request but null/empty SOAP response"
        InquireAccountProfileRequestInfo iapRequest = new InquireAccountProfileRequestInfo()
        JAXBElement<InquireAccountProfileResponseInfo> jaxbResponse = Mock(JAXBElement)
        Map<String, Object> emptyMap = emptyResp
        Map<String, Object> errorMap = [appStatusCode: CErrorDefs.ERR_SYS_APPL_NUM, appInfo: 'Null response returned from CSIIAP',appCategoryCode:2,appStatusMsg:'ERR_SYS_APPL']

        and: "Mock static helpers"
        GroovyMock(CommonUtilHelper, global: true)
        GroovyMock(CommonErrorMap, global: true)

        when: "invokeCSIIAP is called"
        Map<String, Object> result = csiSoapHandler.invokeCSIIAP(iapRequest)

        then: "WebServiceTemplate returns a response wrapper whose value is null; handler maps to error"
        1 * webServiceTemplate.marshalSendAndReceive(_, _) >> jaxbResponse
        1 * jaxbResponse.getValue() >> null
        0 * CommonUtilHelper.objectToMap(null) >> emptyMap
        0 * CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, 'Null response returned from CSIIAP') >> errorMap

        result != null

        where:
        scenarioName2     | emptyResp
        'null response'  | null
        'empty response' | [:]
    }
    @Unroll
    def "should throw ServiceException for non-SOAP exceptions for #scenarioName"() {
        given: "A SOAP call that throws a non-SOAP exception"
        InquireAccountProfileRequestInfo iapRequest = new InquireAccountProfileRequestInfo()
        JAXBElement<InquireAccountProfileRequestInfo> jaxbRequest = Mock(JAXBElement)
        Exception genericEx = new RuntimeException('fail')

        and: "Mock static factory and helpers"
        GroovyMock(com.cingular.csi.csi.namespaces.container._public.inquireaccountprofilerequest.ObjectFactory, global: true)
        com.cingular.csi.csi.namespaces.container._public.inquireaccountprofilerequest.ObjectFactory factory = Mock()
        factory.createInquireAccountProfileRequest(iapRequest) >> jaxbRequest
        webServiceTemplate.marshalSendAndReceive(jaxbRequest, _) >> { throw genericEx }
        GroovyMock(CommonUtilHelper, global: true)
        GroovyMock(CommonErrorMap, global: true)

        when: "invokeCSIIAP is called"
        csiSoapHandler.invokeCSIIAP(iapRequest)

        then: "ServiceException is thrown"
        ServiceException ex = thrown()
        ex.message.contains('MS_MPSYS_BE_602')

        where:
        scenarioName | _
        'non-SOAP'   | _
    }


    def "should create error map with error code"() {
        given: "An error message enum"
        ErrorMessages error = ErrorMessages.MS_MPSYS_BE_602

        when: "makeErrorMap is called"
        Map<String, Object> result = csiSoapHandler.makeErrorMap(error)

        then: "Result contains errorCode key"
        result.errorCode == error.toString()
        0 * _
    }


    def "should throw ServiceException for generic SOAP fault"() {
        given: "Generic SOAP fault message"
        SoapFaultClientException soapFault = Mock(SoapFaultClientException)
        org.springframework.ws.soap.SoapFault internalFault = Mock(org.springframework.ws.soap.SoapFault)
        SoapFaultDetail faultDetail = Mock(SoapFaultDetail)
        GroovyMock(CommonUtil, global: true)
        GroovyMock(CommonErrorMap, global: true)
        Map<String, Object> baseMap = new HashMap<>()
        String faultMessage = "Unexpected remote error occurred"

        when: "handleSOAPFault is invoked"
        csiSoapHandler.handleSOAPFault(soapFault)

        then: "Generic ServiceException is thrown"
        0 * CommonUtil.getHashMap() >> baseMap
        7 * soapFault.getMessage() >> faultMessage
        1 * soapFault.getFaultCode() >> null
        1 * soapFault.getFaultStringOrReason() >> "faultReason"
        1 * soapFault.getSoapFault() >> internalFault
        1 * internalFault.getFaultDetail() >> faultDetail


        and: "Exception validated"
        ServiceException ex = thrown()
        ex.getMessage().contains("MS_MPSYS_BE_276")
    }
    def "should return error map when handleSOAPFault throws IOException"() {
        given: "A SOAP call causing SoapFaultClientException and overridden handleSOAPFault throwing IOException"
        InquireAccountProfileRequestInfo iapRequest = new InquireAccountProfileRequestInfo()
        SoapFaultClientException soapFault = Mock(SoapFaultClientException)
        CSIIAPSoapHandler<InquireAccountProfileRequestInfo> csiSoapHandlerOverride =
                new CSIIAPSoapHandler<InquireAccountProfileRequestInfo>() {
                    @Override
                    Map<String, Object> handleSOAPFault(SoapFaultClientException sf) throws IOException {
                        throw new IOException("IO issue")
                    }
                }
        csiSoapHandlerOverride.setWebServiceTemplate(webServiceTemplate)

        when: "invokeCSIIAP is executed"
        Map<String, Object> result = csiSoapHandlerOverride.invokeCSIIAP(iapRequest)

        then: "SOAP send raises fault and overridden handleSOAPFault throws IOException, triggering fallback error map"
        1 * webServiceTemplate.marshalSendAndReceive(_ as JAXBElement, _ as CSIHeader) >> { throw soapFault }


        and: "Returned map contains only fallback error code"
        result != null
        result.size() == 1
        result.get("errorCode") == ErrorMessages.MS_MPSYS_BE_602.toString()
    }
}

