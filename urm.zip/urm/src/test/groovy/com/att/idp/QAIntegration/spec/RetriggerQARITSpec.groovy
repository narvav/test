package com.att.idp.QAIntegration.spec

import com.att.idp.QAIntegration.Base.TestBase
import com.att.idp.QAIntegration.Config.GlobalConfig
import com.att.idp.QAIntegration.Helpers.ApiHelpers
import groovy.util.logging.Slf4j
import io.restassured.response.Response
import spock.lang.IgnoreIf
import spock.lang.Tag
import spock.lang.Unroll

@Slf4j
@Tag("Regression")
@Tag("IdGraphUserRegistrationMs")
@IgnoreIf({ !GlobalConfig.isTestCaseEnabled("RetriggerQARITSpec") })
class RetriggerQARITSpec extends TestBase {

    @Unroll
    def "RetriggerQAR negative - #scenario.name"() {
        setup:
        TestBase.setTestName("RetriggerQAR Negative — ${scenario.name}")
        TestBase.logStep("POST ${GlobalConfig.Endpoints.RETRIGGER_QAR} — ${scenario.name}")

        Map<String, Object> payload = [:]
        if (scenario.ban != null) payload.ban = scenario.ban
        if (scenario.guid != null) payload.guid = scenario.guid
        if (scenario.accessId != null) payload.accessId = scenario.accessId
        if (scenario.accountType != null) payload.accountType = scenario.accountType
        if (scenario.returnQARToken != null) payload.returnQARToken = scenario.returnQARToken
        if (scenario.returnQARTokenSHM != null) payload.returnQARTokenSHM = scenario.returnQARTokenSHM

        when: "RetriggerQAR API is called with invalid parameters"
        Response response = ApiHelpers.retriggerQAR(payload, "IDP")

        then: "No mock interactions — real HTTP call"
        0 * _

        and: "API returns expected error response"
        def expectedStatuses = scenario.expectedStatus instanceof List ? scenario.expectedStatus : [scenario.expectedStatus]
        assert response.statusCode() in expectedStatuses :
                "Expected HTTP ${expectedStatuses} but got: ${response.statusCode()}"

        where:
        scenario << getNegativeScenarios()
    }

    static List getNegativeScenarios() {
        GlobalConfig.getTestData()?.retriggerQAR?.negative ?: []
    }
}
