package com.att.idp.idgraphuserregistrationms.request.validator

import com.att.idp.idgraphuserregistrationms.resource.request.SyncUserProfileRequest
import com.att.idp.idgraphuserregistrationms.resource.response.SyncUserProfileResponse
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap


class ValidateAndSyncG2RequestValidatorTest extends Specification {

    def validateAndSyncG2RequestValidator= new ValidateAndSyncG2RequestValidator()

    SyncUserProfileRequest requestObj = null
    SyncUserProfileResponse responseObj = null

    private Map<String, String> headers = new HashMap<>()
    public HttpHeaders requestHeader = null
    MultivaluedHashMap requestHeaders =null


    def setup() throws Exception {

        requestObj = new SyncUserProfileRequest()
        responseObj = new SyncUserProfileResponse()
        requestHeader = Mock(HttpHeaders)

        requestObj.callingSystemId = 'ATLAS-UI'
        requestObj.transactionName = 'ValidateAndSyncG2'
        requestObj.ban = 'VD0007556'
        requestObj.agentId = '12345'
        requestObj.isExternalCall = 'N'

        ReflectionTestUtils.setField(validateAndSyncG2RequestValidator, 'propValidateSyncG2Af', 'ATLAS-UI')
        ReflectionTestUtils.setField(validateAndSyncG2RequestValidator, 'propValidateSyncG2Csi', 'DATAMGT|UST|ATLAS-UI')
    }

    def "validate and sync g2 request validator null req test"() throws Exception {
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        when:
        SyncUserProfileResponse response = validateAndSyncG2RequestValidator.validatAndSyncG2(null, requestHeader)
        then:
        response.appInfo == 'Input Request is NULL / Empty.'
    }

    def "query autogentemp req validator success without trace id test"() throws Exception {
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        when:
        SyncUserProfileResponse response = validateAndSyncG2RequestValidator.validatAndSyncG2(requestObj,requestHeader)
        then:
        response.appInfo == 'Missing or Invalid IdpTraceId'
    }


    def "validate and sync g2 request validator success test"() throws Exception {
        given:
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        requestObj.guid = null
        when:
        SyncUserProfileResponse response = validateAndSyncG2RequestValidator.validatAndSyncG2( requestObj, requestHeader)
        then:
        response == null
    }


    def "validate and sync g2 null client id test"() throws Exception{
        given:
        requestHeader.getHeaderString('X-ATT-ClientId')>>null
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        when:
        SyncUserProfileResponse response = validateAndSyncG2RequestValidator.validatAndSyncG2( requestObj, requestHeader)
        then:
        response.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
    }


    def "validate and sync g2 request empty client id test"() throws Exception{
        given:
        requestObj.agentId = null
        requestObj.callingSystemId == 'ATLAS-UI'
        requestHeader.getHeaderString('X-ATT-ClientId')>>'ATLAS-UI'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(validateAndSyncG2RequestValidator, 'propValidateSyncG2Csi', 'ATLAS-UI')
        when:
        SyncUserProfileResponse response = validateAndSyncG2RequestValidator.validatAndSyncG2( requestObj, requestHeader)
        then:
        response.appInfo == 'AgentId is required for caller ATLAS-UI'
    }


    def "validate and sync g2 empty client i d is invalid"() throws Exception{
        given:
        requestObj.agentId = 'agentId'
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(validateAndSyncG2RequestValidator, 'propValidateSyncG2Af', null)
        when:
        SyncUserProfileResponse response = validateAndSyncG2RequestValidator.validatAndSyncG2( requestObj, requestHeader)
        then:
        response.appInfo == 'PROP_VALIDATE_SYNC_G2_AF is not present in property file. '
    }


    def "validate and sync g2 empty is external call is invalid"() throws Exception{
        given:
        requestObj.agentId = 'agentId'
        requestObj.isExternalCall = 'Y'
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        ReflectionTestUtils.setField(validateAndSyncG2RequestValidator, 'propValidateSyncG2Csi', null)
        when:
        SyncUserProfileResponse response = validateAndSyncG2RequestValidator.validatAndSyncG2( requestObj, requestHeader)
        then:
        response.appStatusMsg == 'ERR_SYS_APPL'
    }


    def "validate and sync g2 unknown attributes test"() throws Exception{
        given:
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        Map<String,Object> allUnknownAttributes =new HashMap<>()
        allUnknownAttributes['test'] = 'test'
        requestObj.guid = '12345657'
        requestObj.handle = 'Query_11232'
        requestObj.source = 'YAHOO'
        requestObj.domain = 'slid.dum'
        requestObj.unvalidatedDomain = 'Query_1234'
        requestObj.unvalidatedHandle = 'slid.dum'
        requestObj.setDestination('G2LDAP')
        requestObj.unknownAttributes = allUnknownAttributes
        when:
        SyncUserProfileResponse response = validateAndSyncG2RequestValidator.validatAndSyncG2( requestObj, requestHeader)
        then:
        response.appInfo == 'Invalid Attributes passed in ValidatAndSyncG2 Request : {unvalidatedDomain=YAHOO, test=test, domain=slid.dum, destination=G2LDAP, guid=12345657, handle=Query_11232, unvalidatedUserId=G2LDAP, source=YAHOO}'    }


    def "validate and sync g2 is external call test"() throws Exception{
        given:
        requestObj.isExternalCall = 'Test'
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        when:
        SyncUserProfileResponse response = validateAndSyncG2RequestValidator.validatAndSyncG2( requestObj, requestHeader)
        then:
        response.appInfo == 'IsExternalCall should be Y or N.'
    }


    def "validate and sync g2 if ban not null test"() throws Exception{
        given:
        requestObj.ban = null
        requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        when:
        SyncUserProfileResponse response = validateAndSyncG2RequestValidator.validatAndSyncG2( requestObj, requestHeader)
        then:
        response.appInfo == 'BAN is required in input request.'
    }


    def "validate and sync g2 if validate calling system id test"() throws Exception{
        given:
        requestHeader.getHeaderString('X-ATT-ClientId')>>'TEST'
        requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
        requestObj.isExternalCall = 'Y'
        when:
        SyncUserProfileResponse response = validateAndSyncG2RequestValidator.validatAndSyncG2( requestObj, requestHeader)
        then:
        response.appInfo == 'Input callingSystemId is invalid'
    }
}
