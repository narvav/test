package com.att.idp.idgraphuserregistrationms.helper

import spock.lang.Specification

import java.util.ArrayList
import java.util.HashMap
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.AccountAutoRegDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.DBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetAllInfoDBHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs

class PreAccountRegHelperTest extends Specification {
	
	def testObj = new PreAccountRegHelper()
	
	DBHelper oDBHelper = Mock(DBHelper)
	
	AccountAutoRegDBHelper oMPSDB_AccountAutoReg_H = Mock(AccountAutoRegDBHelper)
	
	GetAllInfoDBHelper getAllInfo = Mock(GetAllInfoDBHelper)

    String stTransactionId = null
    Logger log = null
    HashMap hmResult = null
    HashMap hmInput = null
    HashMap hmSorInvariantId = null
    String stAppInfo = null
    String stAppStatusMsg = null
    String stAppStatusCode = null
    HashMap resultHashSuccess=null
    HashMap resultHashError=null
    HashMap resultHashNoUserError = null
    ArrayList<HashMap> alSorInvariantIds = CommonUtil.arrayList


    def setup() {
    
        testObj.oDBHelper=oDBHelper
        testObj.accountAutoRegDBHelperObj=oMPSDB_AccountAutoReg_H
        testObj.getAllInfo=getAllInfo
        
		//GroovySpy(G2GetBANByIPHelper, global: true)
        log = LoggerFactory.getLogger('PreAutoReg')

       // System.setProperty('CommonConfigurationFilePath', './opt/att/ajsc/config/CommonConfigurationTest.xml')
        stTransactionId = 'kan_00007186901'

        resultHashSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, CErrorDefs.COMMON_SUCCESS_MSG)
        resultHashNoUserError= CommonErrorMap.makeCategoryMap(MPSDefs.REC_NOT_FOUND_NUM, 'REC_NOT_FOUND')
        resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, 'Error Returned')
        hmInput = new HashMap()
        hmSorInvariantId = new HashMap<>()
        hmSorInvariantId[CommonDefs.KEY_SOR_NAME] = 'MO'
        hmSorInvariantId[CommonDefs.SOR_INVARIANT_ID] = '123456789'
        alSorInvariantIds.add(hmSorInvariantId)
        hmInput[CommonDefs.SOR_INVARIANT_ID_LIST] = alSorInvariantIds
        hmInput[CommonDefs.TRANSACTION_ID] = stTransactionId
        hmInput[CommonDefs.TRANSACTION_NAME] = 'PreAccountReg'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'

        hmInput[CommonDefs.GUID] = '1234534235'
        hmInput['isExternalCall'] = 'Y'
    }


    def "test pre account reg helper success scenario"() throws Exception {
        given:
       getAllInfo.getInfo(_ as HashMap) >> resultHashSuccess
       oDBHelper.getSorId(_ as String) >> 13
       oMPSDB_AccountAutoReg_H.updateAccountAutoReg(_ as HashMap) >> resultHashSuccess
        hmResult = testObj.preAccountReg(hmInput)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == CErrorDefs.COMMON_SUCCESS_MSG
        stAppStatusMsg == CErrorDefs.COMMON_SUCCESS_MSG
    }

    def "test pre account reg helper null account reg d b scenario"() throws Exception {
        given:
       getAllInfo.getInfo(_ as HashMap) >> resultHashSuccess
       oDBHelper.getSorId(_ as String) >> 13
       oMPSDB_AccountAutoReg_H.updateAccountAutoReg(_ as HashMap) >> null
        hmResult = testObj.preAccountReg(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Null Response returned from AccountAutoRegDBHelper.updateAccountAutoReg'
    }
	
	def testPreAccountRegHelperAccountRegDBFailScenario() throws Exception {
		given:
		getAllInfo.getInfo(_ as HashMap) >> resultHashSuccess
       oDBHelper.getSorId(_ as String) >> 13
       oMPSDB_AccountAutoReg_H.updateAccountAutoReg(_ as HashMap) >> resultHashError
        hmResult = testObj.preAccountReg(hmInput)
		when:
        stAppStatusCode = (String) hmResult[CommonDefs.COMMON_APP_STATUS_CODE]
        then:
        stAppStatusCode == CErrorDefs.ERR_INVALID_DATA
    }

    void testPreAccountRegHelperInvalidSorName() throws Exception {
    	given:
		getAllInfo.getInfo(_ as HashMap) >> resultHashSuccess
       oDBHelper.getSorId(_ as String) >> 0
        hmResult = testObj.preAccountReg(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Invalid SorName'
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == CErrorDefs.ERR_INVALID_DATA_MSG
    }
	
	void testPreAccountRegHelperUserNotFoundScenario() throws Exception {
		given:
		getAllInfo.getInfo(_ as HashMap) >> resultHashNoUserError
		hmResult = testObj.preAccountReg(hmInput)
		when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Input guid not found'
        when:
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppStatusMsg == CErrorDefs.ERR_USER_NOT_FOUND_MSG
	}
	
	void testPreAccountRegHelperNullGetInfoScenario() throws Exception {
		given:
		getAllInfo.getInfo(_ as HashMap) >> null
		hmResult = testObj.preAccountReg(hmInput)
		when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Null Response returned from getAllInfo'
	}
	
	void testPreAccountRegHelperGetInfoErrorScenario() throws Exception {
		given:
		getAllInfo.getInfo(_ as HashMap) >> resultHashError
		hmResult = testObj.preAccountReg(hmInput)
		when:
        stAppStatusCode = (String) hmResult[CommonDefs.COMMON_APP_STATUS_CODE]
        then:
        stAppStatusCode == CErrorDefs.ERR_INVALID_DATA
	}
	
	void testPreAccountRegHelperExceptionScenario() throws Exception {
		given:
		getAllInfo.getInfo(_ as HashMap) >>{throw new RuntimeException('null')}
		hmResult = testObj.preAccountReg(hmInput)
		when:
        stAppStatusCode = (String) hmResult[CommonDefs.COMMON_APP_STATUS_CODE]
        then:
        stAppStatusCode == CErrorDefs.ERR_SYS_APPL
	}
}
