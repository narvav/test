package com.att.idp.QAIntegration.spec

import com.att.idp.QAIntegration.Base.TestBase
import com.att.idp.QAIntegration.Config.GlobalConfig
import com.att.idp.QAIntegration.Helpers.ApiHelpers
import groovy.util.logging.Slf4j
import io.restassured.response.Response
import spock.lang.IgnoreIf
import spock.lang.Tag
import spock.lang.Unroll

@Slf4j
@Tag("Regression")
@Tag("IdGraphUserRegistrationMs")
@IgnoreIf({ !GlobalConfig.isTestCaseEnabled("UnifiedTOSITSpec") })
class UnifiedTOSITSpec extends TestBase {

    @Unroll
    def "QueryUnifiedTOS negative - #scenario.name"() {
        setup:
        TestBase.setTestName("QueryUnifiedTOS Negative — ${scenario.name}")
        TestBase.logStep("POST ${GlobalConfig.Endpoints.QUERY_UNIFIED_TOS} — ${scenario.name}")

        Map<String, Object> payload = [:]
        if (scenario.accessId != null) payload.accessId = scenario.accessId
        if (scenario.domain != null) payload.domain = scenario.domain

        when: "QueryUnifiedTOS API is called with invalid parameters"
        Response response = ApiHelpers.queryUnifiedTOS(payload, "IDP")

        then: "No mock interactions — real HTTP call"
        0 * _

        and: "API returns expected error response"
        def expectedStatuses = scenario.expectedStatus instanceof List ? scenario.expectedStatus : [scenario.expectedStatus]
        assert response.statusCode() in expectedStatuses :
                "Expected HTTP ${expectedStatuses} but got: ${response.statusCode()}"

        where:
        scenario << getQueryNegativeScenarios()
    }

    @Unroll
    def "UpdateUnifiedTOS negative - #scenario.name"() {
        setup:
        TestBase.setTestName("UpdateUnifiedTOS Negative — ${scenario.name}")
        TestBase.logStep("POST ${GlobalConfig.Endpoints.UPDATE_UNIFIED_TOS} — ${scenario.name}")

        Map<String, Object> payload = [:]
        if (scenario.accessId != null) payload.accessId = scenario.accessId
        if (scenario.domain != null) payload.domain = scenario.domain
        if (scenario.tosAccepted != null) payload.tosAccepted = scenario.tosAccepted
        if (scenario.tosVersion != null) payload.tosVersion = scenario.tosVersion

        when: "UpdateUnifiedTOS API is called with invalid parameters"
        Response response = ApiHelpers.updateUnifiedTOS(payload, "IDP")

        then: "No mock interactions — real HTTP call"
        0 * _

        and: "API returns expected error response"
        def expectedStatuses = scenario.expectedStatus instanceof List ? scenario.expectedStatus : [scenario.expectedStatus]
        assert response.statusCode() in expectedStatuses :
                "Expected HTTP ${expectedStatuses} but got: ${response.statusCode()}"

        where:
        scenario << getUpdateNegativeScenarios()
    }

    static List getQueryNegativeScenarios() {
        GlobalConfig.getTestData()?.queryUnifiedTOS?.negative ?: []
    }

    static List getUpdateNegativeScenarios() {
        GlobalConfig.getTestData()?.updateUnifiedTOS?.negative ?: []
    }
}
