package com.att.idp.QAIntegration.spec

import com.att.idp.QAIntegration.Base.TestBase
import com.att.idp.QAIntegration.Config.GlobalConfig
import com.att.idp.QAIntegration.Helpers.ApiHelpers
import groovy.util.logging.Slf4j
import io.restassured.response.Response
import spock.lang.IgnoreIf
import spock.lang.Tag
import spock.lang.Unroll

@Slf4j
@Tag("Regression")
@Tag("IdGraphUserRegistrationMs")
@IgnoreIf({ !GlobalConfig.isTestCaseEnabled("WirelessAutoRegITSpec") })
class WirelessAutoRegITSpec extends TestBase {

    @Unroll
    def "WirelessAutoReg negative - #scenario.name"() {
        setup:
        TestBase.setTestName("WirelessAutoReg Negative — ${scenario.name}")
        TestBase.logStep("POST ${GlobalConfig.Endpoints.WIRELESS_AUTO_REG} — ${scenario.name}")

        Map<String, Object> payload = [:]
        if (scenario.ban != null) payload.ban = scenario.ban
        if (scenario.ctn != null) payload.ctn = scenario.ctn
        if (scenario.accountType != null) payload.accountType = scenario.accountType

        when: "WirelessAutoReg API is called with invalid parameters"
        Response response = ApiHelpers.wirelessAutoReg(payload, "IDP")

        then: "No mock interactions — real HTTP call"
        0 * _

        and: "API returns expected error response"
        def expectedStatuses = scenario.expectedStatus instanceof List ? scenario.expectedStatus : [scenario.expectedStatus]
        assert response.statusCode() in expectedStatuses :
                "Expected HTTP ${expectedStatuses} but got: ${response.statusCode()}"

        where:
        scenario << getNegativeScenarios()
    }

    static List getNegativeScenarios() {
        GlobalConfig.getTestData()?.wirelessAutoReg?.negative ?: []
    }
}
