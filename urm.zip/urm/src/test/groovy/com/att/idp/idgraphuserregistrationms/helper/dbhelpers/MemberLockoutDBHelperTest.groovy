package com.att.idp.idgraphuserregistrationms.helper.dbhelpers

import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.jboss.logging.MDC
import org.junit.jupiter.api.extension.ExtendWith
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.JdbcTemplate
import com.att.idp.idgraphuserregistrationms.metrics.ErrorMetricHandler
import spock.lang.Specification

import java.text.ParseException
import java.text.SimpleDateFormat

class MemberLockoutDBHelperTest extends Specification {

	Logger logger

    JdbcTemplate jdbcTemplate = Mock(JdbcTemplate)
    ErrorMetricHandler errorMetricHandler = Mock(ErrorMetricHandler)
	MemberLockoutDBHelper  mpsDB_memberLockoutHelper=new MemberLockoutDBHelper()

    List<Object> objectList = new ArrayList<Object>()
    ArrayList alLockoutOperations=new ArrayList()
    HashMap hmLockoutOperation=new HashMap()

    String dateFormat = 'MMDDYYYY HH24:mi:ss'
    HashMap hmInput=new HashMap()
    HashMap hmDbInput=new HashMap()

   // String sInsertMemberLockoutSql = 'INSERT INTO MEMBERLOCKOUT ('+
	//		" MEMBER_NUM, LOCKOUT_ID, SET_NUMBER, FAILED_AUTH_COUNT, LOCKOUT_EXPIRATION, "+
	//		" LAST_FAILED_AUTH, LAST_MODIFIED_BY) " + " VALUES (?, ?, ?, ?, ?, ?, ?)";



	StringBuilder query = new StringBuilder(' UPDATE MEMBERLOCKOUT ')


    def setup() throws Exception {
    mpsDB_memberLockoutHelper.jdbcTemplate=jdbcTemplate
    mpsDB_memberLockoutHelper.errorMetricHandler=errorMetricHandler
		logger = LoggerFactory.getLogger('UpdateUserPassword')
        MDC.put('transid', 'test123')
        System.setProperty('CommonConfigurationFilePath', './opt/att/ajsc/config/CommonConfigurationTest.xml')

        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
        hmLockoutOperation[MPSDefs.DB_OPERATION] = 'delete'


        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '123456'
        hmDbInput[MPSDefs.DB_LOCKOUT_ID] = '1'
        hmDbInput[MPSDefs.DB_SET_NUMBER] = '12'
        hmDbInput[MPSDefs.DB_FAILED_AUTH_COUNT] = '2'
        hmDbInput[MPSDefs.DB_LOCKOUT_EXPIRATION] = '02022019 20:19:20'
        hmDbInput[MPSDefs.DB_LAST_FAILED_AUTH] = '02022019 20:19:20'
        hmDbInput[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'

        SimpleDateFormat sdf = new SimpleDateFormat('MMddyyyy HH:mm:ss')
        java.util.Date util_date = sdf.parse('02022019 20:19:20')
        java.sql.Timestamp timeVal = new java.sql.Timestamp(util_date.time)

        objectList.add('123456')
        objectList.add(1)
        objectList.add(12)
        objectList.add(2)
        objectList.add(timeVal)
        objectList.add(timeVal)
        objectList.add('DATAMGT')


        query.append(' SET ')
        query.append('lockout_expiration = ?')
        query.append(' , ')
        query.append('set_number = ?')
        query.append(' , ')
        query.append('failed_auth_count = ?')
        query.append(' , ')
        query.append('last_modified_by = ?')
        query.append(' , ')
        query.append('last_failed_auth = ?')
        String whereClause = 'member_num =? AND lockout_id = ?'
        query.append(' WHERE ' + whereClause)
    }


    def cleanup() throws Exception {

	}


    def "testprocess data calling system id null input"() {
        given:
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = null
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_EMPTY'
    }


    def "testprocess data exception"() {
        given:
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 1
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "testprocess data lockout operations null input"() {
		//alLockoutOperations.add(null);
        given:
        hmInput[MPSDefs.DB_MEMBERLOCKOUT] = null
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_EMPTY'
    }


    def "testprocess data lockout null input"() {
        given:
        alLockoutOperations.add(null)
        hmInput[MPSDefs.DB_MEMBERLOCKOUT] = alLockoutOperations
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_EMPTY'
    }


    def "testprocess data lockout operation null input"() {
        given:
        hmLockoutOperation[MPSDefs.DB_OPERATION] = null
        alLockoutOperations.add(hmLockoutOperation)
        hmInput[MPSDefs.DB_MEMBERLOCKOUT] = alLockoutOperations
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_EMPTY'
    }


    def "testprocess data lockout operation add input"() {
        given:
        hmLockoutOperation[MPSDefs.DB_OPERATION] = MPSDefs.DB_OPERATION_INSERT
        alLockoutOperations.add(hmLockoutOperation)
        hmInput[MPSDefs.DB_MEMBERLOCKOUT] = alLockoutOperations
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_EMPTY'
    }


    def "testprocess data lockout operation update input"() {
        given:
        hmLockoutOperation[MPSDefs.DB_OPERATION] = MPSDefs.DB_OPERATION_UPDATE
        alLockoutOperations.add(hmLockoutOperation)
        hmInput[MPSDefs.DB_MEMBERLOCKOUT] = alLockoutOperations
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_EMPTY'
    }


    def "testprocess data lockout operationinvalid input"() {
        given:
        hmLockoutOperation[MPSDefs.DB_OPERATION] = 'invalid'
        alLockoutOperations.add(hmLockoutOperation)
        hmInput[MPSDefs.DB_MEMBERLOCKOUT] = alLockoutOperations
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_INVALID_DATA'
    }


    def "testprocess data calling system id input"() {
        given:
        alLockoutOperations.add(hmLockoutOperation)

        hmInput[MPSDefs.DB_MEMBERLOCKOUT] = alLockoutOperations
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.processData(hmInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_EMPTY'
    }


    def "test add success"() {

        given:
        jdbcTemplate.update(_,_) >> 1
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.add(hmDbInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
	}


    def "test addwith null success"() {

        given:
        hmDbInput.remove(MPSDefs.DB_SET_NUMBER)
        hmDbInput.remove(MPSDefs.DB_FAILED_AUTH_COUNT)
        hmDbInput.remove(MPSDefs.DB_LOCKOUT_EXPIRATION)
        hmDbInput.remove(MPSDefs.DB_LAST_FAILED_AUTH)

        objectList=new ArrayList()
        objectList.add('123456')
        objectList.add(1)
        objectList.add(null)
        objectList.add(null)
        objectList.add(null)
        objectList.add(null)
        objectList.add('DATAMGT')

        jdbcTemplate.update(_,_) >> 0
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.add(hmDbInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }


    def "test add exception"() {
        given:
        hmDbInput[MPSDefs.DB_LOCKOUT_EXPIRATION] = '2'
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.add(hmDbInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "test delete error lockout id null"() {
         given:
        hmDbInput=new HashMap()
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '123456'
        hmDbInput[MPSDefs.DB_LOCKOUT_ID] = null
        hmDbInput[MPSDefs.DELETE_LOCKS_BY_MEMBER_NUM_FLAG] = 'N'
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.delete(hmDbInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_EMPTY'
    }


    def "test delete delete locks by member num flag y"() {
        given:
        hmDbInput=new HashMap()
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '123456'
        hmDbInput[MPSDefs.DB_LOCKOUT_ID] = '11'
        hmDbInput[MPSDefs.DELETE_LOCKS_BY_MEMBER_NUM_FLAG] = 'Y'
        objectList=new ArrayList()
        objectList.add('123456')
        jdbcTemplate.update(_,_) >> 1
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.delete(hmDbInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }


    def "test delete delete locks by member num flag n"() {
        given:
        hmDbInput=new HashMap()
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '123456'
        hmDbInput[MPSDefs.DB_LOCKOUT_ID] = '11'
        hmDbInput[MPSDefs.DELETE_LOCKS_BY_MEMBER_NUM_FLAG] = 'N'
        String sDeleteMemberLocksByMemberNumSql = 'DELETE FROM MEMBERLOCKOUT where MEMBER_NUM = ?'
        objectList=new ArrayList()
        objectList.add('123456')
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.delete(hmDbInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }


    def "test update null input"() {
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.update(null)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_EMPTY'
    }


    def "test update null lockout input"() {

        given:
        hmDbInput.remove(MPSDefs.DB_LOCKOUT_ID)
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.update(hmDbInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_EMPTY'
    }


    def "test update exception"() {

        given:
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = 123456
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.update(hmDbInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }


    def "test update success"() throws ParseException {
       given:
        SimpleDateFormat sdf = new SimpleDateFormat('MMddyyyy HH:mm:ss')
        java.util.Date util_date = sdf.parse('02022019 20:19:20')
        java.sql.Timestamp timeVal = new java.sql.Timestamp(util_date.time)
        objectList=new ArrayList()
		objectList.add(timeVal)
        objectList.add(12)
        objectList.add(2)
        objectList.add('DATAMGT')
        objectList.add(timeVal)
        objectList.add('123456')
        objectList.add('1')
        jdbcTemplate.update(_,_) >> 1
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.update(hmDbInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'SUCCESS'
    }


    def "test updatenullinput success"() throws ParseException {

        given:
        hmDbInput=new HashMap()
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '123456'
        hmDbInput[MPSDefs.DB_LOCKOUT_ID] = '1'
        hmDbInput[MPSDefs.DB_SET_NUMBER] = '12'
        hmDbInput[MPSDefs.DB_FAILED_AUTH_COUNT] = null
        hmDbInput[MPSDefs.DB_LOCKOUT_EXPIRATION] = null
        hmDbInput[MPSDefs.DB_LAST_FAILED_AUTH] = null
        hmDbInput[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'

        objectList=new ArrayList()
		objectList.add(null)
        objectList.add('12')
        objectList.add(null)
        objectList.add('DATAMGT')
        objectList.add(null)
        objectList.add('123456')
        objectList.add(1)
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.update(hmDbInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'REC_NOT_FOUND'
    }


    def "test update2 success"() throws ParseException {

       given:
        hmDbInput=new HashMap()
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '123456'
		hmDbInput[CommonDefs.CALLING_SYSTEM_ID] = 'DATAMGT'
		hmDbInput[MPSDefs.DB_LOCKOUT_ID] = '1'
		objectList=new ArrayList()
		objectList.add('DATAMGT')
		objectList.add('123456')
		objectList.add('1')
		StringBuilder query = new StringBuilder(' UPDATE MEMBERLOCKOUT ')
		query.append(' SET ')
		query.append('last_modified_by = ?')
		String whereClause = 'member_num =? AND lockout_id = ?'
		query.append(' WHERE ' + whereClause)
		jdbcTemplate.update(_,_) >> 0
        when:
        HashMap<String, Object> resp = mpsDB_memberLockoutHelper.update(hmDbInput)
        then:
        resp[CommonDefs.COMMON_APP_STATUS_MSG] == 'REC_NOT_FOUND'
    }


}
