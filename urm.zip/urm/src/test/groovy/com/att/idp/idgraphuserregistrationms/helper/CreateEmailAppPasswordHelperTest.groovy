package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.EmailAppPasswordDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetMemberServicesDBHelper
import com.att.idp.idgraphuserregistrationms.helper.voltage.VoltageEncryptionHelper
import com.att.idp.idgraphuserregistrationms.queue.message.helpers.PublishEventHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.MPSDefs
import spock.lang.Specification

import java.lang.reflect.Field

class CreateEmailAppPasswordHelperTest extends Specification {

    private GetMemberServicesDBHelper getMemberServicesDBHelper
    private VoltageEncryptionHelper voltageEncryptionHelper
    private EmailAppPasswordDBHelper emailAppPasswordDBHelper
    private YahooSMKHelper yahooSmkHelper
    private PublishEventHelper publishEventHelper
    private CreateEmailAppPasswordHelper helperUnderTest

    void setup() {
        getMemberServicesDBHelper = Mock(GetMemberServicesDBHelper)
        voltageEncryptionHelper = Mock(VoltageEncryptionHelper)
        emailAppPasswordDBHelper = Mock(EmailAppPasswordDBHelper)
        yahooSmkHelper = Mock(YahooSMKHelper)
        publishEventHelper = Mock(PublishEventHelper)

        helperUnderTest = new CreateEmailAppPasswordHelper(publishEventHelper)
        setField(helperUnderTest, "oGetMemberServicesDBHelper", getMemberServicesDBHelper)
        setField(helperUnderTest, "voltageEncryptionHelperObj", voltageEncryptionHelper)
        setField(helperUnderTest, "emailAppPasswordDBHelper", emailAppPasswordDBHelper)
        setField(helperUnderTest, "yahooSmkHelper", yahooSmkHelper)
    }

    def "should return invalid data when input is null"() {
        when: "the helper is invoked with null input"
        Map<String, Object> result = helperUnderTest.createEmailAppPassword(null)

        then: "no collaborators are called"
        0 * _

        and: "a validation error is returned"
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == String.valueOf(CErrorDefs.ERR_INVALID_DATA_NUM)
        result.get(CommonDefs.COMMON_APP_INFO) == "Input Hash is NULL"
    }

    def "should use resolved member number and caller id for handle domain requests"() {
        given: "a handle/domain request without guid"
        Map<String, Object> input = new HashMap<>()
        input.put(CommonDefs.MEMBERID, "testUser")
        input.put(CommonDefs.DOMAIN, "att.net")
        input.put(CommonDefs.PASSWORD_NAME, "imap")
        input.put(CommonDefs.TRANSACTION_ID, "trace123")
        input.put(CommonDefs.CALLING_SYSTEM_ID, "IDMPROFILE")

        HashMap<String, Object> memberServicesResponse = successResponse("Success")
        memberServicesResponse.put(MPSDefs.DB_MEMBER_NUM, "12345")
        memberServicesResponse.put(MPSDefs.DB_MEMBER_NAME, "testUser")
        memberServicesResponse.put(MPSDefs.DB_DOMAIN_NAME, "att.net")
        memberServicesResponse.put(MPSDefs.DB_CONTACT_EMAIL, "testUser@att.net")
        memberServicesResponse.put(MPSDefs.DB_ACCOUNT_TYPE, "UVERSE")
        memberServicesResponse.put(MPSDefs.DB_LANGUAGE, "en")

        HashMap<String, Object> yahooResponse = successResponse("Success")
        yahooResponse.put("ApplicationPassword", "clear-secret")

        HashMap<String, Object> voltageResponse = successResponse("Success")
        voltageResponse.put(MPSDefs.APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        voltageResponse.put("voltage_yahoo_app_pwd", "enc-secret")

        HashMap<String, Object> publishResponse = successResponse("Success")

        when: "the helper creates the email app password"
        Map<String, Object> result = helperUnderTest.createEmailAppPassword(input)

        then: "the downstream helpers receive the resolved identifiers"
        1 * getMemberServicesDBHelper.getMemberServices({ HashMap request ->
            request.get(MPSDefs.DB_MEMBER_NAME) == "testUser" &&
                    request.get(MPSDefs.DB_DOMAIN_NAME) == "att.net"
        }) >> memberServicesResponse
        1 * yahooSmkHelper.callYahoo({ Map<String, Object> request ->
            request.get(CommonDefs.MEMBERID) == "testUser" &&
                    request.get(CommonDefs.HANDLE) == "testUser" &&
                    request.get(CommonDefs.DOMAIN) == "att.net" &&
                    request.get(CommonDefs.GUID) == "12345" &&
                    request.get(CommonDefs.LANGUAGE) == "en"
        }) >> yahooResponse
        1 * voltageEncryptionHelper.getEFPEEncryptedValues({ HashMap request ->
            request.get("yahoo_app_pwd") == "clear-secret"
        }) >> voltageResponse
        1 * emailAppPasswordDBHelper.deleteEmailAppPwd({ HashMap request ->
            request.get(MPSDefs.DB_MEMBER_NUM) == "12345" &&
                    request.get(MPSDefs.DB_PASSWORD_NAME) == "imap"
        }) >> successResponse("Deleted")
        1 * emailAppPasswordDBHelper.addEmailAppPwd({ HashMap request ->
            request.get(MPSDefs.DB_MEMBER_NUM) == "12345" &&
                    request.get(MPSDefs.DB_PASSWORD_NAME) == "imap" &&
                    request.get(MPSDefs.DB_PASSWORD_VENC) == "enc-secret" &&
                    request.get(CommonDefs.CALLING_SYSTEM_ID) == "IDMPROFILE"
        }) >> successResponse("Inserted")
        1 * publishEventHelper.publishEvent(
                "cfg-idgraph-emailapppassword-mq-aeh-switch",
                "cfg-idgraph-emailapppassword-notification-clm-switch",
                { Map<String, Object> eventPayload ->
                    eventPayload.get(CommonDefs.HANDLE) == "testUser" &&
                            eventPayload.get(CommonDefs.DOMAIN) == "att.net" &&
                            eventPayload.get(CommonDefs.ACCOUNT_TYPE) == "UVERSE" &&
                            eventPayload.get("mainHashKey") == "testUser" &&
                            ((List) eventPayload.get(CommonDefs.NOTIFICATION_DATA)).size() == 1
                },
                { Map<String, Object> helperInput ->
                    helperInput.get(CommonDefs.GUID) == "12345" &&
                            helperInput.get(CommonDefs.MEMBERID) == "testUser"
                }) >> publishResponse
        0 * _

        and: "the helper returns the generated password and guid"
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get(CommonDefs.GUID) == "12345"
        result.get(CommonDefs.PASSWORD) == "clear-secret"
    }

    def "should resolve member data before yahoo call for guid requests"() {
        given: "a guid-only request"
        Map<String, Object> input = new HashMap<>()
        input.put(CommonDefs.GUID, "67890")
        input.put(CommonDefs.PASSWORD_NAME, "imap")
        input.put(CommonDefs.TRANSACTION_ID, "trace456")
        input.put(CommonDefs.CALLING_SYSTEM_ID, "IDMPROFILE")
        input.put("suppressEDD", CommonDefs.IND_Y)

        HashMap<String, Object> memberServicesResponse = successResponse("Success")
        memberServicesResponse.put(MPSDefs.DB_MEMBER_NUM, "67890")
        memberServicesResponse.put(MPSDefs.DB_MEMBER_NAME, "resolvedUser")
        memberServicesResponse.put(MPSDefs.DB_DOMAIN_NAME, "bellsouth.net")
        memberServicesResponse.put(MPSDefs.DB_CONTACT_EMAIL, "resolvedUser@bellsouth.net")
        memberServicesResponse.put(MPSDefs.DB_ACCOUNT_TYPE, "UVERSE")
        memberServicesResponse.put(MPSDefs.DB_LANGUAGE, "fr")

        HashMap<String, Object> yahooResponse = successResponse("Success")
        yahooResponse.put("ApplicationPassword", "guid-secret")

        HashMap<String, Object> voltageResponse = successResponse("Success")
        voltageResponse.put(MPSDefs.APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        voltageResponse.put("voltage_yahoo_app_pwd", "guid-enc-secret")

        when: "the helper processes the guid request"
        Map<String, Object> result = helperUnderTest.createEmailAppPassword(input)

        then: "member data is resolved before downstream calls"
        1 * getMemberServicesDBHelper.getMemberServices({ HashMap request ->
            request.get(MPSDefs.DB_MEMBER_NUM) == "67890"
        }) >> memberServicesResponse
        1 * yahooSmkHelper.callYahoo({ Map<String, Object> request ->
            request.get(CommonDefs.MEMBERID) == "resolvedUser" &&
                    request.get(CommonDefs.HANDLE) == "resolvedUser" &&
                    request.get(CommonDefs.DOMAIN) == "bellsouth.net" &&
                    request.get(CommonDefs.GUID) == "67890" &&
                    request.get(CommonDefs.LANGUAGE) == "fr"
        }) >> yahooResponse
        1 * voltageEncryptionHelper.getEFPEEncryptedValues({ HashMap request ->
            request.get("yahoo_app_pwd") == "guid-secret"
        }) >> voltageResponse
        1 * emailAppPasswordDBHelper.deleteEmailAppPwd({ HashMap request ->
            request.get(MPSDefs.DB_MEMBER_NUM) == "67890" &&
                    request.get(MPSDefs.DB_PASSWORD_NAME) == "imap"
        }) >> successResponse("Deleted")
        1 * emailAppPasswordDBHelper.addEmailAppPwd({ HashMap request ->
            request.get(MPSDefs.DB_MEMBER_NUM) == "67890" &&
                    request.get(MPSDefs.DB_PASSWORD_NAME) == "imap" &&
                    request.get(CommonDefs.CALLING_SYSTEM_ID) == "IDMPROFILE"
        }) >> successResponse("Inserted")
        0 * _

        and: "the helper returns success"
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get(CommonDefs.GUID) == "67890"
        result.get(CommonDefs.PASSWORD) == "guid-secret"
    }

    def "should bypass PublishEventHelper failure and return success"() {
        given: "a handle/domain request"
        Map<String, Object> input = new HashMap<>()
        input.put(CommonDefs.MEMBERID, "testUser")
        input.put(CommonDefs.DOMAIN, "att.net")
        input.put(CommonDefs.PASSWORD_NAME, "imap")
        input.put(CommonDefs.TRANSACTION_ID, "trace123")
        input.put(CommonDefs.CALLING_SYSTEM_ID, "IDMPROFILE")

        HashMap<String, Object> memberServicesResponse = successResponse("Success")
        memberServicesResponse.put(MPSDefs.DB_MEMBER_NUM, "12345")
        memberServicesResponse.put(MPSDefs.DB_MEMBER_NAME, "testUser")
        memberServicesResponse.put(MPSDefs.DB_DOMAIN_NAME, "att.net")
        memberServicesResponse.put(MPSDefs.DB_CONTACT_EMAIL, "testUser@att.net")
        memberServicesResponse.put(MPSDefs.DB_ACCOUNT_TYPE, "UVERSE")
        memberServicesResponse.put(MPSDefs.DB_LANGUAGE, "en")

        HashMap<String, Object> yahooResponse = successResponse("Success")
        yahooResponse.put("ApplicationPassword", "clear-secret")

        HashMap<String, Object> voltageResponse = successResponse("Success")
        voltageResponse.put(MPSDefs.APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        voltageResponse.put("voltage_yahoo_app_pwd", "enc-secret")

        HashMap<String, Object> publishFailureResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "PublishEventHelper failed")

        when: "the helper creates the email app password but PublishEventHelper fails"
        Map<String, Object> result = helperUnderTest.createEmailAppPassword(input)

        then: "the helper bypasses the PublishEventHelper failure"
        1 * getMemberServicesDBHelper.getMemberServices(_) >> memberServicesResponse
        1 * yahooSmkHelper.callYahoo(_) >> yahooResponse
        1 * voltageEncryptionHelper.getEFPEEncryptedValues(_) >> voltageResponse
        1 * emailAppPasswordDBHelper.deleteEmailAppPwd(_) >> successResponse("Deleted")
        1 * emailAppPasswordDBHelper.addEmailAppPwd(_) >> successResponse("Inserted")
        1 * publishEventHelper.publishEvent(
                "cfg-idgraph-emailapppassword-mq-aeh-switch",
                "cfg-idgraph-emailapppassword-notification-clm-switch",
                { Map<String, Object> eventPayload ->
                    eventPayload.get("mainHashKey") == "testUser"
                },
                _) >> publishFailureResponse
        0 * _

        and: "the helper returns success"
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS
        result.get(CommonDefs.GUID) == "12345"
        result.get(CommonDefs.PASSWORD) == "clear-secret"
    }

    private static HashMap<String, Object> successResponse(String appInfo) {
        return CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, appInfo)
    }

    private static void setField(Object target, String fieldName, Object value) {
        Field field = target.getClass().getDeclaredField(fieldName)
        field.accessible = true
        field.set(target, value)
    }
}

