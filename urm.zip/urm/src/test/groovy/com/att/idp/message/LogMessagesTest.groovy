package com.att.idp.message

import com.att.idp.idgraphuserregistrationms.message.LogMessages
import spock.lang.Specification

import static org.assertj.core.api.Assertions.assertThat

class LogMessagesTest extends Specification {


	def setup() throws Exception
	{
	}


	def cleanup() throws Exception {

	}


	def "test log messages"()
	{
		when:
		LogMessages[] values = LogMessages.values()
		then:
		assertThat(values).isNotNull()
	}

}
