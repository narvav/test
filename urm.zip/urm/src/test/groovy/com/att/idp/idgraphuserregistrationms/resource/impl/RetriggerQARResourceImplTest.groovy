package com.att.idp.idgraphuserregistrationms.resource.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.exceptions.MPSException
import com.att.idp.idgraphuserregistrationms.request.validator.RetriggerQARRequestValidator
import com.att.idp.idgraphuserregistrationms.resource.request.RetriggerQARRequest
import com.att.idp.idgraphuserregistrationms.resource.response.RetriggerQARResponse
import com.att.idp.idgraphuserregistrationms.service.RetriggerQARService
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.Response
import java.sql.SQLException


class RetriggerQARResourceImplTest extends Specification {

    def retriggerQARResourceImplObj=new RetriggerQARResourceImpl()

	RetriggerQARRequestValidator retriggerQARReqValidator=Mock(RetriggerQARRequestValidator)

	RetriggerQARService retriggerQARService=Mock(RetriggerQARService)

	HttpHeaders requestHeader=Mock(HttpHeaders)

	RetriggerQARRequest retriggerQARRequestObj
	
	def setup() {
		retriggerQARResourceImplObj.retriggerQARServiceObj = retriggerQARService
		retriggerQARResourceImplObj.retriggerQARRequestvalidatorObj = retriggerQARReqValidator
		
	}
	


	def "test retrigger q a r success"() throws Exception {
		given:
		RetriggerQARResponse retriggerQARResponse = new RetriggerQARResponse()
		retriggerQARResponse.appCategoryCode = '0'

        retriggerQARReqValidator.retriggerQARReqValidator(_ as HttpHeaders, _ as RetriggerQARRequest)>>null
        retriggerQARService.retriggerQAR(_ as RetriggerQARRequest, _)>>retriggerQARResponse

		when:
		Response response = retriggerQARResourceImplObj.retriggerQAR(new RetriggerQARRequest(), requestHeader)
		then:
		response.status == 200
	}


	def "test retrigger q a r error"() throws Exception {

		given:
		RetriggerQARResponse retriggerQARResponse = new RetriggerQARResponse()
		retriggerQARResponse.appCategoryCode = '2'
		retriggerQARReqValidator.retriggerQARReqValidator(_ as HttpHeaders, _ as RetriggerQARRequest)>>retriggerQARResponse
		when:
		Response response = retriggerQARResourceImplObj.retriggerQAR(new RetriggerQARRequest(), requestHeader)
		then:
		response.status == 500
		when:
		retriggerQARResourceImplObj.retriggerQAR(retriggerQARRequestObj, requestHeader)

		retriggerQARResponse.appCategoryCode = '3'
		response = retriggerQARResourceImplObj.retriggerQAR(new RetriggerQARRequest(), requestHeader)
		then:
		response.status == 400
	}


	def "test retrigger q a r invalid input data exception"() throws Exception {

		given:
		InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
		when:retriggerQARService.retriggerQAR(_ as RetriggerQARRequest, _) >> { throw ex }
		retriggerQARResourceImplObj.retriggerQAR(new RetriggerQARRequest(), requestHeader)
        then:
		thrown(InvalidInputDataException.class)

	}


	def "test retrigger q a r null pointer exception"() throws MPSException {
		given:
		NullPointerException ex = new NullPointerException('NullPointerException thrown')
		when:retriggerQARService.retriggerQAR(_ as RetriggerQARRequest, _) >> { throw ex }
		Response response = retriggerQARResourceImplObj.retriggerQAR(new RetriggerQARRequest(), requestHeader)
		then:
		response.status == 500
	}
	def "test retrigger q a r sql exception"() throws Exception {
		given:
		SQLException ex = new SQLException('SQLException thrown')
		retriggerQARService.retriggerQAR(_ as RetriggerQARRequest, _) >> { throw ex }

		when:
		Response response = retriggerQARResourceImplObj.retriggerQAR(new RetriggerQARRequest(), requestHeader)

		then:
		response.status == 500
	}
}
