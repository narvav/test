package com.att.idp.idgraphuserregistrationms.helper

import com.fasterxml.jackson.core.JsonProcessingException;
import com.att.idp.idgraphuserregistrationms.integration.MPSYSInternalRestClient
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.CommonUtil
import com.fasterxml.jackson.core.JsonProcessingException
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Specification
import org.springframework.test.util.ReflectionTestUtils

class ExternalDestinationHelperTest extends Specification {

	
	def externalDestinationHelperObj = new ExternalDestinationHelper()

    MPSYSInternalRestClient idpInternalRestClient = Mock(MPSYSInternalRestClient)

    String stTransactionId = null
    Logger logger = null
    HashMap resultHashSuccess = null
    HashMap resultHashError = null
    HashMap hmResult = null
    HashMap hmInput = null
    String stAppStatusMsg = null
    String stAppInfo = null
    HashMap ctnHash = null


    def setup() {
		logger = LoggerFactory.getLogger('WirelessAutoReg')
		
		 externalDestinationHelperObj.idpInternalRestClient=idpInternalRestClient

       // System.setProperty('CommonConfigurationFilePath', './opt/att/ajsc/config/CommonConfigurationTest.xml')
        stTransactionId = 'kan_123'

        hmInput = CommonUtil.hashMap
        ctnHash = CommonUtil.hashMap

        hmInput[CommonDefs.TRANSACTION_ID] = stTransactionId
        hmInput[CommonDefs.TRANSACTION_NAME] = 'WirelessAutoReg'
        hmInput[CommonDefs.SOR_INVARIANT_ID] = '23324332'
		hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'MYWORLD'

		resultHashSuccess = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM,
				CErrorDefs.COMMON_SUCCESS_MSG)
		stAppInfo = 'Error returned from Helper'
		resultHashError = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_DATA_NUM, stAppInfo)
		GroovySpy(ExternalDestinationHelper, global: true)
		ReflectionTestUtils.setField(externalDestinationHelperObj, 'propCallOGStub', 'Y')

	}


    def "test order graph stub"() {
		// when OG stub enabled
        when:
        hmResult = (HashMap) externalDestinationHelperObj.callOrderGraph(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "test order graph success"() throws JsonProcessingException, IOException {
		// OG stub disabled
        given:
        ReflectionTestUtils.setField(externalDestinationHelperObj, 'propCallOGStub', 'N')
        idpInternalRestClient.callIDPRestClient(_ as HashMap) >> resultHashSuccess
        when:
        hmResult = (HashMap) externalDestinationHelperObj.callOrderGraph(hmInput)
        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "test order graph exception"() throws JsonProcessingException, IOException {
        given:
        ReflectionTestUtils.setField(externalDestinationHelperObj, 'propCallOGStub', 'N')
        idpInternalRestClient.callIDPRestClient(_ as HashMap) >> { throw new JsonProcessingException("Test Exception") }

        when:
        hmResult = (HashMap) externalDestinationHelperObj.callOrderGraph(hmInput)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "callStubOrderGraphMS handles exception"() {
        given:
        ReflectionTestUtils.setField(externalDestinationHelperObj, 'propCallOGStub', 'Y')


        when:
        Map<String, Object> result = externalDestinationHelperObj.callStubOrderGraphMS()

        then:
        result.containsKey(CommonDefs.COMMON_APP_STATUS_CODE)

    }
}
