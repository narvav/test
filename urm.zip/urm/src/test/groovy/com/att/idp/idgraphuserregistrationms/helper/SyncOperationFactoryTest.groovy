package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraph.extclient.db.service.TworkitemService
import com.att.idp.idgraph.extclient.g2.service.G2SoapClientHandler
import com.att.idp.idgraph.extclient.haloc.service.HaloCService
import com.att.idp.idgraphuserregistrationms.helper.voltage.ProofingEncryptionHelper
import com.att.idp.idgraphuserregistrationms.utils.RILCheckAndEncryptPasswordHelper
import org.springframework.beans.BeansException
import org.springframework.context.ApplicationContext
import spock.lang.Specification
import spock.lang.Unroll

/**
 * Spock tests for SyncOperationFactory covering 100% lines, methods, and branches.
 * Follows user testing guidelines: concrete types, comprehensive assertions, explicit interactions, ending with 0 * _.
 */
class SyncOperationFactoryTest extends Specification {

    ApplicationContext applicationContext
    SyncOperationFactory factory

    // Dependencies for constructing a real HaloSyncOperation instance
    HaloCService haloCService
    ConsolidatedProfileHelper consolidatedProfileHelper
    ProofingEncryptionHelper proofingEncryptionHelper
    TworkitemService tworkitemService
    HaloSyncHelper haloSyncHelper
    RILCheckAndEncryptPasswordHelper oRilCheckAndEncryptPasswordHelper

    def setup() {
        applicationContext = Mock(ApplicationContext)
        factory = new SyncOperationFactory(applicationContext)
    }

    private static void setHaloEnabled(SyncOperationFactory target, boolean enabled) {
        java.lang.reflect.Field f = SyncOperationFactory.class.getDeclaredField("haloCEnabled")
        f.setAccessible(true)
        f.setBoolean(target, enabled)
    }

    private HaloSyncOperation buildRealHaloSyncOp() {
        haloCService = Mock(HaloCService)
        consolidatedProfileHelper = Mock(ConsolidatedProfileHelper)
        proofingEncryptionHelper = Mock(ProofingEncryptionHelper)
        tworkitemService = Mock(TworkitemService)
        haloSyncHelper = new HaloSyncHelper()
        oRilCheckAndEncryptPasswordHelper = Mock(RILCheckAndEncryptPasswordHelper)
        return new HaloSyncOperation(haloCService, consolidatedProfileHelper, proofingEncryptionHelper, tworkitemService, haloSyncHelper, oRilCheckAndEncryptPasswordHelper)
    }

    @Unroll
    def "should return HaloSyncOperation instance successfully for destination variant #destinationValue"() {
        given: "Feature enabled and applicationContext returns HaloSyncOperation bean"
        setHaloEnabled(factory, true)
        HaloSyncOperation haloSyncOp = buildRealHaloSyncOp()

        when: "getSyncOperation invoked"
        SyncOperation op = factory.getSyncOperation(destinationValue)

        then: "Bean fetched from context and returned"
        1 * applicationContext.getBean(HaloSyncOperation.class) >> haloSyncOp
        op.is(haloSyncOp)
        0 * _

        where: "Case-insensitive destination inputs"
        destinationValue | _
        'HALOC'          | _
        'haloc'          | _
        'HaLoC'          | _
    }

    def "should throw IllegalStateException when HaloC disabled"() {
        given: "Feature flag disabled"
        setHaloEnabled(factory, false)

        when: "getSyncOperation called for HALOC"
        factory.getSyncOperation('HALOC')

        then: "IllegalStateException with feature disabled message"
        IllegalStateException ex = thrown()
        ex.message.contains('haloc feature is disabled')
        0 * applicationContext.getBean(_)
        0 * _
    }

    def "should throw IllegalStateException when bean retrieval fails"() {
        given: "Feature enabled but applicationContext throws BeansException"
        setHaloEnabled(factory, true)
        applicationContext.getBean(HaloSyncOperation.class) >> { throw new BeansException('FAIL_BEAN') {} }

        when: "getSyncOperation invoked"
        factory.getSyncOperation('HALOC')

        then: "Factory wraps BeansException in IllegalStateException"
        IllegalStateException ex = thrown()
        ex.message.contains('Unable to obtain HaloSyncOperation bean')
        ex.cause instanceof BeansException
        1 * applicationContext.getBean(HaloSyncOperation.class) >> { throw new BeansException('FAIL_BEAN') {} }
        0 * _
    }

    def "should throw IllegalArgumentException for unsupported destination"() {
        given: "Feature flag value irrelevant"
        setHaloEnabled(factory, true)

        when: "getSyncOperation invoked with OTHER"
        factory.getSyncOperation('OTHER')

        then: "IllegalArgumentException thrown with destination in message"
        IllegalArgumentException ex = thrown()
        ex.message == 'Invalid operation type: OTHER'
        0 * applicationContext.getBean(_)
        0 * _
    }

    // --- G2LDAP branch coverage ---

    private static void setG2Enabled(SyncOperationFactory target, boolean enabled) {
        java.lang.reflect.Field f = SyncOperationFactory.class.getDeclaredField("g2Enabled")
        f.setAccessible(true)
        f.setBoolean(target, enabled)
    }

    @Unroll
    def "should return G2SyncOperation instance successfully for destination variant #destinationValue"() {
        given: "G2 feature enabled and applicationContext returns G2SyncOperation bean"
        setG2Enabled(factory, true)
        G2SyncOperation g2Op = Mock(G2SyncOperation)

        when: "getSyncOperation invoked"
        SyncOperation op = factory.getSyncOperation(destinationValue)

        then: "Bean fetched from context and returned"
        1 * applicationContext.getBean(G2SyncOperation.class) >> g2Op
        op.is(g2Op)
        0 * _

        where: "Case-insensitive destination inputs"
        destinationValue | _
        'G2LDAP'         | _
        'g2ldap'         | _
        'G2Ldap'         | _
    }

    def "should throw IllegalStateException when G2 disabled"() {
        given: "G2 feature flag disabled"
        setG2Enabled(factory, false)

        when: "getSyncOperation called for G2LDAP"
        factory.getSyncOperation('G2LDAP')

        then: "IllegalStateException with feature disabled message"
        IllegalStateException ex = thrown()
        ex.message.contains('G2 feature is disabled')
        0 * applicationContext.getBean(_)
        0 * _
    }

    def "should throw IllegalStateException when G2 bean retrieval fails"() {
        given: "G2 feature enabled but applicationContext throws BeansException"
        setG2Enabled(factory, true)
        applicationContext.getBean(G2SyncOperation.class) >> { throw new BeansException('FAIL_G2') {} }

        when: "getSyncOperation invoked"
        factory.getSyncOperation('G2LDAP')

        then: "Factory wraps BeansException in IllegalStateException"
        IllegalStateException ex = thrown()
        ex.message.contains('Unable to obtain G2SyncOperation bean')
        ex.cause instanceof BeansException
        1 * applicationContext.getBean(G2SyncOperation.class) >> { throw new BeansException('FAIL_G2') {} }
        0 * _
    }

    // --- YAHOO branch coverage ---

    private static void setYahooEnabled(SyncOperationFactory target, boolean enabled) {
        java.lang.reflect.Field f = SyncOperationFactory.class.getDeclaredField("yahooEnabled")
        f.setAccessible(true)
        f.setBoolean(target, enabled)
    }

    @Unroll
    def "should return YahooSyncOperation instance successfully for destination variant #destinationValue"() {
        given: "Yahoo feature enabled and applicationContext returns YahooSyncOperation bean"
        setYahooEnabled(factory, true)
        YahooSyncOperation yahooOp = Mock(YahooSyncOperation)

        when: "getSyncOperation invoked"
        SyncOperation op = factory.getSyncOperation(destinationValue)

        then: "Bean fetched from context and returned"
        1 * applicationContext.getBean(YahooSyncOperation.class) >> yahooOp
        op.is(yahooOp)
        0 * _

        where: "Case-insensitive destination inputs"
        destinationValue | _
        'YAHOO'          | _
        'yahoo'          | _
        'Yahoo'          | _
    }

    def "should throw IllegalStateException when Yahoo disabled"() {
        given: "Yahoo feature flag disabled"
        setYahooEnabled(factory, false)

        when: "getSyncOperation called for YAHOO"
        factory.getSyncOperation('YAHOO')

        then: "IllegalStateException with feature disabled message"
        IllegalStateException ex = thrown()
        ex.message.contains('yahoo feature is disabled')
        0 * applicationContext.getBean(_)
        0 * _
    }

    def "should throw IllegalStateException when Yahoo bean retrieval fails"() {
        given: "Yahoo feature enabled but applicationContext throws BeansException"
        setYahooEnabled(factory, true)
        applicationContext.getBean(YahooSyncOperation.class) >> { throw new BeansException('FAIL_YAHOO') {} }

        when: "getSyncOperation invoked"
        factory.getSyncOperation('YAHOO')

        then: "Factory wraps BeansException in IllegalStateException"
        IllegalStateException ex = thrown()
        ex.message.contains('Unable to obtain YahooSyncOperation bean')
        ex.cause instanceof BeansException
        1 * applicationContext.getBean(YahooSyncOperation.class) >> { throw new BeansException('FAIL_YAHOO') {} }
        0 * _
    }
}

