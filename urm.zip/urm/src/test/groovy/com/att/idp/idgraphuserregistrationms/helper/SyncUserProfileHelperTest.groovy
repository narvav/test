package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraphuserregistrationms.client.MPSSyncDestinationSoapHandler
import com.att.idp.idgraphuserregistrationms.resource.request.SyncUserProfileRequest
import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.ril.mpsys.syncdestinationrequest.v1.SyncDestinationRequest
import spock.lang.Specification
import spock.lang.Unroll

class SyncUserProfileHelperTest extends Specification {

    // Concrete type mocks
    MPSSyncDestinationSoapHandler<SyncDestinationRequest> mpsSyncDestinationSoapHandler
    SyncOperationFactory syncOperationFactory
    SyncOperation haloSyncOperation
    FeatureManagerHelper featureManager = Mock(FeatureManagerHelper)

    // System under test (constructed with required args)
    SyncUserProfileHelper testObj

    HashMap<String, Object> hmSoapHelperResponse

    def setup() {
        mpsSyncDestinationSoapHandler = Mock(MPSSyncDestinationSoapHandler)
        syncOperationFactory = Mock(SyncOperationFactory)
        haloSyncOperation = Mock(SyncOperation)
        testObj = new SyncUserProfileHelper(mpsSyncDestinationSoapHandler, syncOperationFactory)
        testObj.featureManager = featureManager
    }

    private static SyncUserProfileRequest buildBaseRequest(String destination) {
        SyncUserProfileRequest req = new SyncUserProfileRequest()
        req.transactionName = 'SyncUserProfile'
        req.callingSystemId = 'ATLAS-UI'
        req.guid = '12345'
        req.source = 'MPS'
        req.destination = destination
        req.isExternalCall = 'N'
        req.idpTraceId = 'tx999:seg2:seg3'
        req.handle = 'userA'
        req.domain = 'att.net'
        req.ban = '555'
        return req
    }

    def "should sync successfully for non-HALOC destination and verify outbound request mapping"() {
        given: "Valid request and SOAP success response"
        featureManager.isEnabled(_)>>false
        SyncUserProfileRequest req = buildBaseRequest('MPSLDAP')
        hmSoapHelperResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')

        when: "Invoke syncUserProfile"
        Map<String,Object> result = testObj.syncUserProfile(req)

        then: "SOAP helper called with populated SyncDestinationRequest"
        1 * mpsSyncDestinationSoapHandler.invokeAPI({ SyncDestinationRequest r ->
            r.transactionId == 'tx999' && // first segment from idpTraceId
            r.transactionName == 'SyncDestination' &&
            r.callingSystemId == 'ATLAS-UI' &&
            r.handle == 'userA' &&
            r.domain == 'att.net' &&
            r.guid == '12345' &&
            r.ban == '555' &&
            r.source == 'MPS' &&
            r.destination == 'MPSLDAP'
        }) >> hmSoapHelperResponse
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) == String.valueOf(CErrorDefs.COMMON_SUCCESS_NUM)

    }

    def "should return null response fallback error when SOAP helper returns null"() {
        given: "SOAP helper returns null"
        featureManager.isEnabled(_)>>false
        SyncUserProfileRequest req = buildBaseRequest('MPSLDAP')
        mpsSyncDestinationSoapHandler.invokeAPI(_ as SyncDestinationRequest) >> null

        when: "Invoke"
        Map<String,Object> result = testObj.syncUserProfile(req)

        then: "Fallback error produced"
        result.get(CommonDefs.COMMON_APP_INFO) == 'Response from SyncDestinationRILMPS is NULL'

    }

    def "should handle exception thrown by SOAP helper and produce exception map"() {
        given: "SOAP helper throws runtime exception"
        featureManager.isEnabled(_)>>false
        SyncUserProfileRequest req = buildBaseRequest('MPSLDAP')
        mpsSyncDestinationSoapHandler.invokeAPI(_ as SyncDestinationRequest) >> { throw new RuntimeException('FAIL') }

        when: "Invoke"
        Map<String,Object> result = testObj.syncUserProfile(req)

        then: "Exception path covered"
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) != String.valueOf(CErrorDefs.COMMON_SUCCESS_NUM)
        String appInfo = (String) result.get(CommonDefs.COMMON_APP_INFO)
        appInfo != null && appInfo.toLowerCase().contains('fail')

    }

    def "should delegate to HaloC SyncOperation when destination HALOC"() {
        given: "HALOC destination request"
        featureManager.isEnabled(_)>>true
        SyncUserProfileRequest req = buildBaseRequest('HALOC')
        HashMap<String,Object> haloResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        syncOperationFactory.getSyncOperation('HALOC') >> haloSyncOperation
        haloSyncOperation.performSync(_ as HashMap<String,Object>) >> haloResp

        when: "Invoke"
        Map<String,Object> result = testObj.syncUserProfile(req)

        then: "Delegation occurred; SOAP not called"
       result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) == String.valueOf(CErrorDefs.COMMON_SUCCESS_NUM)

    }

    @Unroll
    def "should extract transactionId first segment for #scenarioName"() {
        given: "Request with varying idpTraceId"
        SyncUserProfileRequest req = buildBaseRequest('MPSLDAP')
        req.idpTraceId = traceId
        hmSoapHelperResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')

        when: "Invoke"
        Map<String,Object> result = testObj.syncUserProfile(req)

        then: "Invocation captured with correct transactionId"
        mpsSyncDestinationSoapHandler.invokeAPI({ SyncDestinationRequest r -> r.transactionId == expectedId }) >> hmSoapHelperResponse
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) == String.valueOf(CErrorDefs.COMMON_SUCCESS_NUM)

        where:
        scenarioName            | traceId                         | expectedId
        'multi segments'        | 'abc123:one:two'                | 'abc123'
        'single segment only'   | 'xyz999'                        | 'xyz999'
        'long id first segment' | 'segmentOneExtra:rest:later'    | 'segmentOneExtra'
    }

    def "should delegate to Yahoo SyncOperation when destination YAHOO (always uses factory)"() {
        given: "YAHOO destination request with Yahoo flag enabled"
        featureManager.isEnabled("svc-idgraph-userreg-enable-haloc-sync") >> false
        featureManager.isEnabled("svc-idgraph-userreg-enable-yahoo-sync") >> true
        SyncUserProfileRequest req = buildBaseRequest('YAHOO')
        SyncOperation yahooSyncOp = Mock(SyncOperation)
        HashMap<String, Object> yahooResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        syncOperationFactory.getSyncOperation('YAHOO') >> yahooSyncOp
        yahooSyncOp.performSync(_ as HashMap<String, Object>) >> yahooResp

        when: "Invoke syncUserProfile"
        Map<String, Object> result = testObj.syncUserProfile(req)

        then: "Delegation to factory occurred; SOAP not called"
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) == String.valueOf(CErrorDefs.COMMON_SUCCESS_NUM)
        0 * mpsSyncDestinationSoapHandler.invokeAPI(_)
    }

    def "should delegate to Yahoo SyncOperation even when HaloC flag disabled"() {
        given: "YAHOO destination request with HaloC flag disabled and Yahoo flag enabled"
        featureManager.isEnabled("svc-idgraph-userreg-enable-haloc-sync") >> false
        featureManager.isEnabled("svc-idgraph-userreg-enable-yahoo-sync") >> true
        SyncUserProfileRequest req = buildBaseRequest('YAHOO')
        SyncOperation yahooSyncOp = Mock(SyncOperation)
        HashMap<String, Object> yahooResp = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        syncOperationFactory.getSyncOperation('YAHOO') >> yahooSyncOp
        yahooSyncOp.performSync(_ as HashMap<String, Object>) >> yahooResp

        when: "Invoke syncUserProfile"
        Map<String, Object> result = testObj.syncUserProfile(req)

        then: "Factory called for Yahoo regardless of flag; SOAP not called"
        result.get(CommonDefs.COMMON_APP_CATEGORY_CODE) == String.valueOf(CErrorDefs.COMMON_SUCCESS_NUM)
        1 * syncOperationFactory.getSyncOperation('YAHOO') >> yahooSyncOp
        0 * mpsSyncDestinationSoapHandler.invokeAPI(_)
    }
}