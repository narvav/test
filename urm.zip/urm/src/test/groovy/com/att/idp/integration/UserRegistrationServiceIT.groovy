///**
// *
// */
//package com.att.idp.integration
//
//
//import static org.hamcrest.Matchers.anyOf
///**
// * @author gs799f
// *
// */
//class UserRegistrationServiceIT extends IntegrationTestBase {
//
//	private String queryUnifiedTOS = '/unifiedTOS/query'
//    private String updateUnifiedTOS = '/unifiedTOS/update'
//    private String queryByIPEligibility = '/lsreg/queryByIPEligibility'
//    private String registerLSUser = '/lsreg/registerUser'
//    private String verifyExistingMemberEligibility = '/lsreg/verifyExistingMemberEligibility'
//    private String wirelessAutoReg = '/orchestration/wireless'
//    private String retriggerQAR = '/account/qar/retrigger'
//    private String autoGenTempAID = '/autoreg/tempAccessId'
//    private String preAccountReg = '/register/preAccountReg'
//    private String reprovisionUverse = '/userprofile/reprovision/uban'
//    private String ValidateAndSyncG2 = '/userprofile/activate/uban'
//    private String SyncUserProfile = '/userprofile/sync'
//
//
//    def "query unified t o s success"() {
//        given:
//        String req = '{\r\n' + '    "transactionName": "QueryUnifiedTOS",\r\n'
//        +'    "callingSystemId": "IDP",\r\n' + '    "ban": "000932335",\r\n'
//				+'    "agentId": "1321",\r\n' + '    "isExternalCall": "N"\r\n' + '}'
//
//        Map<String, String> headers = setHeaders()
//
//        expect:
//        givenBaseSpec().headers(headers).body(req).when().post(queryUnifiedTOS).then()
//				.statusCode(anyOf(org.hamcrest.CoreMatchers.is(200), org.hamcrest.CoreMatchers.is(400)))
//    }
//
//
//    def "query by i p eligibility success"() {
//        given:
//        String req = '{\n' + '        "ipAddress": "2611:1711:4881:3931:2a16:adsf:fe19:7be4" ' + '\n}'
//
//        Map<String, String> headers = setHeaders()
//
//        expect:
//        givenBaseSpec().headers(headers).body(req).when().post(queryByIPEligibility).then()
//				.statusCode(anyOf(org.hamcrest.CoreMatchers.is(200), org.hamcrest.CoreMatchers.is(400)))
//    }
//
//
//    def "update unified t o s success"() {
//        given:
//        String req = '{\n' + '  \n' + '  "ban" : "VD0016685",\n' + '  "hsiaTOSAcceptance" : "Y",\n'
//        +'  "iptvTOSAcceptance" : "Y",\n' + '  "e911TOSAcceptance" : "Y",\n'
//				+'  "wdmTOSAcceptance"  : "N",\n' + '  "wvmTOSAcceptance"  : "N",\n'
//				+'  "agentId" : "2222"\n' + '}\n' + ''
//
//        Map<String, String> headers = setHeaders()
//
//        expect:
//        givenBaseSpec().headers(headers).body(req).when().post(updateUnifiedTOS).then()
//				.statusCode(anyOf(org.hamcrest.CoreMatchers.is(200), org.hamcrest.CoreMatchers.is(400)))
//    }
//
//
//    def "register l s user success"() {
//        given:
//        String req = '{\r\n' + '    "ban": "121212321",\r\n' + '    "dateOfBirth": "20200404",\r\n'
//        +'    "userId": "crissyechev74",\r\n' + '    "domain": "att.net",\r\n'
//				+'    "slid": "crissydee73@gmail.com",\r\n' + '    "regType": "NEW"\r\n' + '}'
//
//        Map<String, String> headers = setHeaders()
//
//        expect:
//        givenBaseSpec().headers(headers).body(req).when().post(registerLSUser).then()
//				.statusCode(anyOf(org.hamcrest.CoreMatchers.is(200), org.hamcrest.CoreMatchers.is(400)))
//    }
//
//
//    def "verify existing member eligibility success"() {
//        given:
//        String req = '{\n' + '    "userId": "qayma0089706",\n' + '    "domain": "att.net",\n'
//        +'    "ban": "VD0015088"\n' + '}'
//
//        Map<String, String> headers = setHeaders()
//
//        expect:
//        givenBaseSpec().headers(headers).body(req).when().post(verifyExistingMemberEligibility).then()
//				.statusCode(anyOf(org.hamcrest.CoreMatchers.is(200), org.hamcrest.CoreMatchers.is(400)))
//    }
//
//
//    def "wireless auto reg success"() {
//        given:
//        String req = '{\r\n' + '    "firstName": "Att",\r\n' + '    "lastName": "Network",\r\n'
//        +'    "sorId": "11",\r\n' + '    "sorInvariantId": "57378282888",\r\n'
//				+'    "serviceName": "MOBILITY"\r\n' + '}'
//
//        Map<String, String> headers = setHeaders()
//
//        expect:
//        givenBaseSpec().headers(headers).body(req).when().post(wirelessAutoReg).then()
//				.statusCode(anyOf(org.hamcrest.CoreMatchers.is(200), org.hamcrest.CoreMatchers.is(400)))
//    }
//
//
//    def "retrigger q a r success"() {
//        given:
//        String req = '{\n' +
//'  "ban":"251154606",\n' +
//'  "accountType":"TITAN"\n' +
//'}'
//
//        Map<String, String> headers = setHeaders()
//
//        expect:
//        givenBaseSpec().headers(headers).body(req).when().post(retriggerQAR).then()
//				.statusCode(anyOf(org.hamcrest.CoreMatchers.is(200), org.hamcrest.CoreMatchers.is(400)))
//    }
//
//
//    def "auto gen temp a i d success"() {
//        given:
//        String req = '{\n'
//        +'  "contactEmail" : "vl1122@gmail.com",\n'
//				+'  "firstName" : "Tony",\n'
//				+'  "lastName" : "Stark",\n'
//				+'  "contactEmailRTValidFlag" : "Y",\n'
//				+'  "agentId" : "gd6435",\n'
//				+'  "sorInvariantIdList" :\n'
//				+'  [\n'
//				+'\n'
//				+'    {\n'
//				+'    "sorName" : "LS000",\n'
//				+'    "sorInvariantId" : "100889097"\n'
//				+'    }\n'
//				+'  ]\n'
//				+'}'
//
//      Map<String, String> headers = setHeaders()
//
//        expect:
//        givenBaseSpec().headers(headers).body(req).when().post(autoGenTempAID).then()
//                  .statusCode(anyOf(org.hamcrest.CoreMatchers.is(200), org.hamcrest.CoreMatchers.is(400)))
//    }
//
//
//    def "pre account reg success"() {
//
//        given:
//        String req = '{\r\n' + '    "transactionName": "PreAccountReg",\r\n'
//        +'    "callingSystemId": "IDP",\r\n'
//				+'    "guid": "34545354354",\r\n'
//				+'    "isExternalCall": "N"\r\n'
//				+'}'
//
//        Map<String, String> headers = setHeaders()
//
//        expect:
//        givenBaseSpec().headers(headers).body(req).when().post(preAccountReg).then()
//				.statusCode(anyOf(org.hamcrest.CoreMatchers.is(200), org.hamcrest.CoreMatchers.is(400)))
//    }
//
//    def "reprovision uverse success"() {
//
//        given:
//        String req = '{\r\n' + '    "transactionName": "ReprovisionUverse",\r\n'
//        +'    "callingSystemId": "ATLAS-UI",\r\n'
//				+'    "ban": "123456789",\r\n'
//				+'    "agentId": "ak1568",\r\n'
//				+'    "unvalidatedHandle": "",\r\n'
//				+'    "unvalidatedDomain": ""\r\n'
//				+'}'
//
//        Map<String, String> headers = setHeaders()
//
//        expect:
//        givenBaseSpec().headers(headers).body(req).when().post(reprovisionUverse).then()
//				.statusCode(anyOf(org.hamcrest.CoreMatchers.is(200), org.hamcrest.CoreMatchers.is(400)))
//    }
//
//
//    def "validate and sync g2 success"() {
//
//        given:
//        String req = '{\r\n' + '    "transactionName": "ValidateAndSyncG2",\r\n'
//        +'    "callingSystemId": "ATLAS-UI",\r\n'
//				+'    "ban": "123456789",\r\n'
//				+'    "agentId": "ak1568"\r\n'
//				+'}'
//
//        Map<String, String> headers = setHeaders()
//
//        expect:
//        givenBaseSpec().headers(headers).body(req).when().post(ValidateAndSyncG2).then()
//				.statusCode(anyOf(org.hamcrest.CoreMatchers.is(200), org.hamcrest.CoreMatchers.is(400)))
//    }
//
//
//    def "sync user profile success"() {
//
//        given:
//        String req = '{\r\n' + '    "userId": "dgeurts6571@att.net",\r\n'
//        +'    "domain": "att.net",\r\n' + '    "destination": "HALOC",\r\n'
//				+'    "agentId": "ak1568",\r\n' + '}'
//
//		Map<String, String> headers = setHeaders()
//
//        expect:
//        givenBaseSpec().headers(headers).body(req).when().post(SyncUserProfile).then()
//                .statusCode(anyOf(org.hamcrest.CoreMatchers.is(200), org.hamcrest.CoreMatchers.is(400)))
//    }
//
//	private Map<String, String> setHeaders() {
//
//		Map<String, String> headers = new HashMap<>()
//		headers['idp-trace-id'] = traceId
//		headers['Content-Type'] = 'application/json'
//		headers['idp.trace_id'] = '01234567'
//		headers['X-ATT-ClientId'] = 'IDP'
//		return headers
//	}
//
//}
