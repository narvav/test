package com.att.idp.QAIntegration.spec

import com.att.idp.QAIntegration.Base.TestBase
import com.att.idp.QAIntegration.Config.GlobalConfig
import com.att.idp.QAIntegration.Helpers.ApiHelpers
import groovy.util.logging.Slf4j
import io.restassured.response.Response
import spock.lang.IgnoreIf
import spock.lang.Tag
import spock.lang.Unroll

@Slf4j
@Tag("Regression")
@Tag("IdGraphUserRegistrationMs")
@IgnoreIf({ !GlobalConfig.isTestCaseEnabled("PreAccountRegITSpec") })
class PreAccountRegITSpec extends TestBase {

    @Unroll
    def "PreAccountReg negative - #scenario.name"() {
        setup:
        TestBase.setTestName("PreAccountReg Negative — ${scenario.name}")
        TestBase.logStep("POST ${GlobalConfig.Endpoints.PRE_ACCOUNT_REG} — ${scenario.name}")

        Map<String, Object> payload = [:]
        if (scenario.sorId != null) payload.sorId = scenario.sorId
        if (scenario.sorInvariantId != null) payload.sorInvariantId = scenario.sorInvariantId
        if (scenario.guid != null) payload.guid = scenario.guid

        when: "PreAccountReg API is called with invalid parameters"
        Response response = ApiHelpers.preAccountReg(payload, "IDP")

        then: "No mock interactions — real HTTP call"
        0 * _

        and: "API returns expected error response"
        def expectedStatuses = scenario.expectedStatus instanceof List ? scenario.expectedStatus : [scenario.expectedStatus]
        assert response.statusCode() in expectedStatuses :
                "Expected HTTP ${expectedStatuses} but got: ${response.statusCode()}"

        where:
        scenario << getNegativeScenarios()
    }

    static List getNegativeScenarios() {
        GlobalConfig.getTestData()?.preAccountReg?.negative ?: []
    }
}
