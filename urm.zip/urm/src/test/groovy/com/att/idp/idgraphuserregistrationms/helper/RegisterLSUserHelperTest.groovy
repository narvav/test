package com.att.idp.idgraphuserregistrationms.helper

import com.att.idp.idgraphuserregistrationms.client.MPSRegisterUserSoapHandler
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.ril.mpsys.registeruserrequest.v1.RegisterUserRequest
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Specification

import jakarta.ws.rs.core.Response

class RegisterLSUserHelperTest extends Specification {
	
	HashMap hmInput = new HashMap()
    HashMap hmResult = null
    HashMap hmSuccessResponse = new HashMap()
    HashMap hmErrorResponse = new HashMap()
    String transId = 'RUHtest123'
    Response response = null
    private Logger logger = null
    private String stAppInfo
    HashMap hmResponse = null

    MPSRegisterUserSoapHandler<RegisterUserRequest> mpsRegisterUserSoapHandler = Mock()
	def oRegisterLSUserHelper = new RegisterLSUserHelper()


    def setup() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
        oRegisterLSUserHelper.mpsRegisterUserSoapHandler = mpsRegisterUserSoapHandler
        logger = LoggerFactory.getLogger('.registerUser.')
        hmSuccessResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')
        hmErrorResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_INVALID_LENGTH_NUM, 'Error')
        hmInput[CommonDefs.HANDLE] = 'crissyechev74'
        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.IS_EXTERNAL_CALL] = 'Y'
        hmInput[CommonDefs.TRANSACTION_NAME] = 'RegisterUser'
        hmInput[CommonDefs.TRANSACTION_ID] = transId
        hmInput[CommonDefs.REG_TYPE] = 'NEW'
		hmInput[CommonDefs.SLID] = 'crissydee73@gmail.com'
		hmInput[CommonDefs.BAN] = '121321113'
		hmInput[CommonDefs.DOMAIN] = 'att.net'
		hmInput[CommonDefs.DATE_OF_BIRTH] = '01011970'
	}


    def "test ril soap call null"() throws Exception {
        given:
        hmResult = oRegisterLSUserHelper.registerUser(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'Response from RegisterUser is NULL'
    }


    def "test register user success"() throws Exception
	{
        given:
        mpsRegisterUserSoapHandler.invokeAPI(_) >> hmSuccessResponse
        hmResult = oRegisterLSUserHelper.registerUser(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SUCCESS'
    }


    def "test register user exception"() throws Exception
	{
        given:
        mpsRegisterUserSoapHandler.invokeAPI(_ as HashMap) >> new RuntimeException('null')
        hmResult = oRegisterLSUserHelper.registerUser(hmInput)
        when:
        stAppInfo = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        then:
        stAppInfo == 'ERR_SYS_APPL'
    }
	

}

