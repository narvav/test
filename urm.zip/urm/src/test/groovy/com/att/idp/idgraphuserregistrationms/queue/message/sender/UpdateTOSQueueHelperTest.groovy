package com.att.idp.idgraphuserregistrationms.queue.message.sender

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.queue.message.helpers.PublishEventHelper
import com.att.idp.idgraphuserregistrationms.queue.message.helpers.UpdateTOSQueueHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Specification

class UpdateTOSQueueHelperTest extends Specification {

    PublishEventHelper publishEventHelper = Mock(PublishEventHelper)
    def updateTOSQueueHelper = new UpdateTOSQueueHelper(publishEventHelper)

    Map<String, Object> hmInput = null
    Map<String, Object> hmResult = null
    HashMap hmEventsInp = null
    Logger logger = null


    def setup() {
        //updateTOSQueueHelper.oJMSQueueSender=jMSQueueSender
		hmInput = CommonUtil.hashMap
        hmEventsInp = CommonUtil.hashMap
        hmResult = CommonUtil.hashMap
        logger = LoggerFactory.getLogger('AddUser')

        hmInput['msOperation'] = 'AddUser'
		hmInput[CommonDefs.TRANSACTION_NAME] = 'UpdateTOS'
		hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
		hmEventsInp[CommonDefs.TRANSACTION_ID] = 'trma_ng56734'
		hmEventsInp[CommonDefs.BAN] = '121212120'

	}


    def "test send with null output"() {
        given:
        hmResult = null
        publishEventHelper.publishEvent(_ as String, _ as String, _ as Map<String, Object>, _ as Map<String, Object>) >> hmResult
        when:
        hmResult = updateTOSQueueHelper.sendMessage(hmEventsInp, hmInput)
        then:
        hmResult['appStatusCode'] == CErrorDefs.ERR_SYS_APPL
    }


    def "test send with error output"() {
        given:
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.ERR_SYS_MQ
        hmResult[CommonDefs.COMMON_APP_INFO] = 'Error sending message'
        publishEventHelper.publishEvent(_ as String, _ as String, _ as Map<String, Object>, _ as Map<String, Object>) >> hmResult
        when:
        hmResult = updateTOSQueueHelper.sendMessage(hmEventsInp, hmInput)
        then:
        hmResult['appStatusCode'] == CErrorDefs.ERR_SYS_MQ
    }


    def "test send with exception"() {
        given:
        hmResult[CommonDefs.COMMON_APP_STATUS_CODE] = CErrorDefs.ERR_SYS_MQ
        InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
        publishEventHelper.publishEvent(_ as String, _ as String, _ as Map<String, Object>, _ as Map<String, Object>)  >> { throw ex }
        when:
        hmResult = updateTOSQueueHelper.sendMessage(hmEventsInp, hmInput)
        then:
        hmResult['appStatusCode'] == CErrorDefs.ERR_SYS_APPL
    }
}
