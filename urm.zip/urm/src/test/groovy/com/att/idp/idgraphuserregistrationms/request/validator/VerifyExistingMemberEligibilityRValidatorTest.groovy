package com.att.idp.idgraphuserregistrationms.request.validator

import com.att.idp.idgraphuserregistrationms.resource.request.VerifyExistingMemberEligibilityRequest
import com.att.idp.idgraphuserregistrationms.resource.response.AutoGenTempAIDResponse
import com.att.idp.idgraphuserregistrationms.resource.response.VerifyExistingMemberEligibilityResponse
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap


class VerifyExistingMemberEligibilityRValidatorTest extends Specification {


	def requestValidatorObj=new VerifyExistingMemberEligibilityRequestValidator()

	VerifyExistingMemberEligibilityRequest verifyExistingMemberEligibilityRequest = null
	VerifyExistingMemberEligibilityResponse verifyExistingMemberEligibilityResponseObj =null

	public HttpHeaders requestHeader = null


	def setup() throws Exception {
		verifyExistingMemberEligibilityRequest = new VerifyExistingMemberEligibilityRequest()
		verifyExistingMemberEligibilityResponseObj = new VerifyExistingMemberEligibilityResponse()
		requestHeader = Mock(HttpHeaders)

		verifyExistingMemberEligibilityRequest.ban = 'VD123456'
		verifyExistingMemberEligibilityRequest.handle = 'qay_test'
		verifyExistingMemberEligibilityRequest.isExternalCall = 'Y'
		verifyExistingMemberEligibilityRequest.domain = 'att.net'

			ReflectionTestUtils.setField(requestValidatorObj, 'propValidCallers',
				'IDP|DATAMGT')


	}

	def "test verify existing me request"() throws Exception {
		given:
		verifyExistingMemberEligibilityRequest = null
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		verifyExistingMemberEligibilityResponseObj = requestValidatorObj
				.verifyExistingMemberEligibilityReqValidator(requestHeader, verifyExistingMemberEligibilityRequest)
		then:
		verifyExistingMemberEligibilityResponseObj.appInfo == 'Input Request is NULL / Empty.'
	}

	def "verify existing without trace id test"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		//Mockito.doReturn(null).when(requestHeader).getHeaderString("idp-trace-id");
		//	requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'

		when:
		verifyExistingMemberEligibilityResponseObj = requestValidatorObj
				.verifyExistingMemberEligibilityReqValidator(requestHeader, verifyExistingMemberEligibilityRequest)

		then:
		verifyExistingMemberEligibilityResponseObj .appInfo == 'Missing or Invalid IdpTraceId'
	}

	def "test verify existing me invalid csi error"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>''
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		verifyExistingMemberEligibilityResponseObj = requestValidatorObj
				.verifyExistingMemberEligibilityReqValidator(requestHeader, verifyExistingMemberEligibilityRequest)
		then:
		verifyExistingMemberEligibilityResponseObj.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}


	def "test verify existing me null error"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>null
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		verifyExistingMemberEligibilityResponseObj = requestValidatorObj
				.verifyExistingMemberEligibilityReqValidator(requestHeader, verifyExistingMemberEligibilityRequest)
		then:
		verifyExistingMemberEligibilityResponseObj.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}
	def "test verify existing me success case"() {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		verifyExistingMemberEligibilityResponseObj = requestValidatorObj
				.verifyExistingMemberEligibilityReqValidator(requestHeader, verifyExistingMemberEligibilityRequest)
		then:
		verifyExistingMemberEligibilityResponseObj == null
	}


	def "test verify existing me is external call level"() {
		given:
		verifyExistingMemberEligibilityRequest.isExternalCall = 'A'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		verifyExistingMemberEligibilityResponseObj = requestValidatorObj
				.verifyExistingMemberEligibilityReqValidator(requestHeader, verifyExistingMemberEligibilityRequest)
		then:
		verifyExistingMemberEligibilityResponseObj.appInfo == 'isExternalCall must be one of Y or N'
	}


	def "test verify existing me null ban"() {
		given:
		verifyExistingMemberEligibilityRequest.ban = null
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		verifyExistingMemberEligibilityResponseObj = requestValidatorObj
				.verifyExistingMemberEligibilityReqValidator(requestHeader, verifyExistingMemberEligibilityRequest)
		then:
		verifyExistingMemberEligibilityResponseObj.appInfo == 'Input ban is null or empty'
	}

	def "test verify existing me null handle"() {
		given:
		verifyExistingMemberEligibilityRequest.handle = null
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		verifyExistingMemberEligibilityResponseObj = requestValidatorObj
				.verifyExistingMemberEligibilityReqValidator(requestHeader, verifyExistingMemberEligibilityRequest)
		then:
		verifyExistingMemberEligibilityResponseObj.appInfo == 'userId is missing.'
	}




	def "verify existing member eligibility invalid attributes test"() throws Exception{
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		Map<String,Object> allUnknownAttributes =new HashMap<>()
		allUnknownAttributes['test'] = 'test'
		verifyExistingMemberEligibilityRequest.unknownAttributes = allUnknownAttributes
		when:
		verifyExistingMemberEligibilityResponseObj = requestValidatorObj.verifyExistingMemberEligibilityReqValidator( requestHeader,verifyExistingMemberEligibilityRequest)
		then:
		verifyExistingMemberEligibilityResponseObj.appInfo == 'Invalid Attributes passed in VerifyExistingMemberEligibilityRequest : {test=test}'
	}
	def "test verify existing me handle error case"() {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		given:
		verifyExistingMemberEligibilityRequest.handle = 'sbciptvtest'
		when:
		verifyExistingMemberEligibilityResponseObj = requestValidatorObj
				.verifyExistingMemberEligibilityReqValidator(requestHeader, verifyExistingMemberEligibilityRequest)
		then:
		verifyExistingMemberEligibilityResponseObj.appInfo == 'userId can NOT start with sbciptv or attaab'
	}


	def "test verify existing me property error case"() {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		given:
		ReflectionTestUtils.setField(requestValidatorObj, 'propValidCallers',
				'')

		when:
		verifyExistingMemberEligibilityResponseObj = requestValidatorObj
				.verifyExistingMemberEligibilityReqValidator(requestHeader, verifyExistingMemberEligibilityRequest)
		then:
		verifyExistingMemberEligibilityResponseObj.appInfo == 'VerifyExistingMemberEligibility CallingSystemIds config is not set'
	}
	def "test verify existing me property err case"() {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		given:
		ReflectionTestUtils.setField(requestValidatorObj, 'propValidCallers',
				'ABC')

		when:
		verifyExistingMemberEligibilityResponseObj = requestValidatorObj
				.verifyExistingMemberEligibilityReqValidator(requestHeader, verifyExistingMemberEligibilityRequest)
		then:
		verifyExistingMemberEligibilityResponseObj.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}

}
