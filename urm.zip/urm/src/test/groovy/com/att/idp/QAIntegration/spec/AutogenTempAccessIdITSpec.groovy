package com.att.idp.QAIntegration.spec

import com.att.idp.QAIntegration.Base.TestBase
import com.att.idp.QAIntegration.Config.GlobalConfig
import com.att.idp.QAIntegration.Helpers.ApiHelpers
import groovy.util.logging.Slf4j
import io.restassured.response.Response
import spock.lang.IgnoreIf
import spock.lang.Tag
import spock.lang.Unroll

@Slf4j
@Tag("Regression")
@Tag("IdGraphUserRegistrationMs")
@IgnoreIf({ !GlobalConfig.isTestCaseEnabled("AutogenTempAccessIdITSpec") })
class AutogenTempAccessIdITSpec extends TestBase {

    @Unroll
    def "AutogenTempAccessId negative - #scenario.name"() {
        setup:
        TestBase.setTestName("AutogenTempAccessId Negative — ${scenario.name}")
        TestBase.logStep("POST ${GlobalConfig.Endpoints.AUTOGEN_TEMP_ACCESS_ID} — ${scenario.name}")

        Map<String, Object> payload = [:]
        if (scenario.ban != null) payload.ban = scenario.ban
        if (scenario.accountType) payload.accountType = scenario.accountType
        if (scenario.firstName) payload.firstName = scenario.firstName

        when: "Autogen Temp AccessId API is called with invalid parameters"
        Response response = ApiHelpers.autogenTempAccessId(payload, "IDP")

        then: "No mock interactions — real HTTP call"
        0 * _

        and: "API returns expected error response"
        def expectedStatuses = scenario.expectedStatus instanceof List ? scenario.expectedStatus : [scenario.expectedStatus]
        assert response.statusCode() in expectedStatuses :
                "Expected HTTP ${expectedStatuses} but got: ${response.statusCode()}"

        where:
        scenario << getNegativeScenarios()
    }

    static List getNegativeScenarios() {
        GlobalConfig.getTestData()?.autogenTempAccessId?.negative ?: []
    }
}
