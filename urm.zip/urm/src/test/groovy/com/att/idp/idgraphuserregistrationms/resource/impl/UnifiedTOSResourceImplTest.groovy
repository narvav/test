package com.att.idp.idgraphuserregistrationms.resource.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.request.validator.QueryUnifiedTOSRequestValidator
import com.att.idp.idgraphuserregistrationms.request.validator.UpdateUnifiedTOSRequestValidator
import com.att.idp.idgraphuserregistrationms.resource.request.QueryUnifiedTOSRequest
import com.att.idp.idgraphuserregistrationms.resource.request.UpdateUnifiedTOSRequest
import com.att.idp.idgraphuserregistrationms.resource.response.QueryUnifiedTOSResponse
import com.att.idp.idgraphuserregistrationms.resource.response.UpdateUnifiedTOSResponse
import com.att.idp.idgraphuserregistrationms.service.QueryUnifiedTOSService
import com.att.idp.idgraphuserregistrationms.service.UpdateUnifiedTOSService
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.Response
import java.sql.SQLException

class UnifiedTOSResourceImplTest extends Specification {
	
	def unifiedTOSResourceImplObj=new UnifiedTOSResourceImpl()

	QueryUnifiedTOSRequestValidator requestValidatorObject = Mock(QueryUnifiedTOSRequestValidator)

	UpdateUnifiedTOSService updateUnifiedTOSServiceObj = Mock(UpdateUnifiedTOSService)

	UpdateUnifiedTOSRequestValidator UpdateUnifiedTOSRequestValidatorObj = Mock(UpdateUnifiedTOSRequestValidator)

	QueryUnifiedTOSService queryUnifiedTOSServiceObj = Mock(QueryUnifiedTOSService)

	HttpHeaders httpHeaders = Mock(HttpHeaders)

	QueryUnifiedTOSRequest requestObject = Mock(QueryUnifiedTOSRequest)

	UpdateUnifiedTOSRequest updateUnifiedTOSRequestObj = Mock(UpdateUnifiedTOSRequest)

	private QueryUnifiedTOSResponse responseObject = null

	private UpdateUnifiedTOSResponse updateUnifiedTOSResponseObj = null
	
	def setup() {
		unifiedTOSResourceImplObj.queryUnifiedTOSRequestValidator = requestValidatorObject
		unifiedTOSResourceImplObj.queryUnifiedTOSService = queryUnifiedTOSServiceObj
		
		unifiedTOSResourceImplObj.updateUnifiedTOSService = updateUnifiedTOSServiceObj
		unifiedTOSResourceImplObj.updateUnifiedTOSRequestValidator = UpdateUnifiedTOSRequestValidatorObj
		
	}


	def "test query unified t o s success"() throws Exception {
		given:
		responseObject = new QueryUnifiedTOSResponse()
		responseObject.appCategoryCode = '0'
		queryUnifiedTOSServiceObj.queryUnifiedTOS(_ as QueryUnifiedTOSRequest, _) >> responseObject
		when:
		Response response = unifiedTOSResourceImplObj.queryUnifiedTos(requestObject, httpHeaders)
		then:
		response.status == 200
	}


	def "test query unified t o s error"() throws Exception {
		
		// error from request validator
		given:
		responseObject = new QueryUnifiedTOSResponse()
		responseObject.appCategoryCode = '2'
		requestValidatorObject.queryUnifiedTOSReqValidator(_ as HttpHeaders, _ as QueryUnifiedTOSRequest) >> responseObject
		when:
		Response response = unifiedTOSResourceImplObj.queryUnifiedTos(requestObject, httpHeaders)
		then:
		response.status == 500

		// error from service
		when:
		responseObject.appCategoryCode = '3'
		response = unifiedTOSResourceImplObj.queryUnifiedTos(requestObject, httpHeaders)
		then:
		response.status == 400
	}


	def "test query unified t o s data exception"() throws Exception {

		given:
		InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
		when:queryUnifiedTOSServiceObj.queryUnifiedTOS(_ as QueryUnifiedTOSRequest, _) >> { throw ex }
		unifiedTOSResourceImplObj.queryUnifiedTos(requestObject, httpHeaders)
        then:
        thrown(InvalidInputDataException.class)
	}


	def "test query unified t o s exception"() throws Exception {

		given:
		NullPointerException ex = new NullPointerException('NullPointerException thrown')
		when:queryUnifiedTOSServiceObj.queryUnifiedTOS(_ as QueryUnifiedTOSRequest, _) >> { throw ex }
		Response response = unifiedTOSResourceImplObj.queryUnifiedTos(requestObject, httpHeaders)
		then:
		response.status == 500
	}


	def "test update unified t o s success"() throws Exception {
		given:
		updateUnifiedTOSResponseObj = new UpdateUnifiedTOSResponse()
		updateUnifiedTOSResponseObj.appCategoryCode = '0'
		UpdateUnifiedTOSRequestValidatorObj.updateUnifiedTOSRequestValidator(_ as HttpHeaders, _ as UpdateUnifiedTOSRequest) >> null
		updateUnifiedTOSServiceObj.updateUnifiedTOS(_ as UpdateUnifiedTOSRequest, _) >> updateUnifiedTOSResponseObj
		when:
		Response response = unifiedTOSResourceImplObj.updateUnifiedTos(updateUnifiedTOSRequestObj, httpHeaders)
		then:
		response.status == 200
	}


	def "test update unified t o s error from validator"() throws Exception {
		given:
		updateUnifiedTOSResponseObj = new UpdateUnifiedTOSResponse()
		updateUnifiedTOSResponseObj.appCategoryCode = '2'
		UpdateUnifiedTOSRequestValidatorObj.updateUnifiedTOSRequestValidator(_ as HttpHeaders, _ as UpdateUnifiedTOSRequest) >> updateUnifiedTOSResponseObj
		when:
		Response response = unifiedTOSResourceImplObj.updateUnifiedTos(updateUnifiedTOSRequestObj, httpHeaders)
		then:
		response.status == 500
	}


	def "test update unified t o s error from service"() throws Exception {
		given:
		updateUnifiedTOSResponseObj = new UpdateUnifiedTOSResponse()
		updateUnifiedTOSResponseObj.appCategoryCode = '3'
		updateUnifiedTOSServiceObj.updateUnifiedTOS(_ as UpdateUnifiedTOSRequest, _) >> updateUnifiedTOSResponseObj
		when:
		Response response = unifiedTOSResourceImplObj.updateUnifiedTos(updateUnifiedTOSRequestObj, httpHeaders)
		then:
		response.status == 400
	}


	def "test update unified t o s invalid input data exception"() throws Exception {
		given:
		InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
		when:updateUnifiedTOSServiceObj.updateUnifiedTOS(_ as UpdateUnifiedTOSRequest, _) >> { throw ex }
		unifiedTOSResourceImplObj.updateUnifiedTos(updateUnifiedTOSRequestObj, httpHeaders)
        then:
        thrown(InvalidInputDataException.class)
	}


	def "test update unified t o s exception"() throws Exception {
		//when(updateUnifiedTOSRequestObj.getTransactionName()).thenReturn("UpdateUnifiedTOS");
		given:
		NullPointerException ex = new NullPointerException('NullPointerException thrown')
		when:updateUnifiedTOSServiceObj.updateUnifiedTOS(_ as UpdateUnifiedTOSRequest, _) >> { throw ex }
		Response response = unifiedTOSResourceImplObj.updateUnifiedTos(updateUnifiedTOSRequestObj, httpHeaders)
		then:
		response.status == 500
	}

	def "test query unified t o s sql exception"() throws Exception {
		given:
		SQLException ex = new SQLException('SQLException thrown')
		queryUnifiedTOSServiceObj.queryUnifiedTOS(_ , _) >> { throw ex }
		when:
		Response response = unifiedTOSResourceImplObj.queryUnifiedTos(requestObject, httpHeaders)
		then:
		response.status == 500
	}

	def "test update unified t o s sql exception"() throws Exception {
		given:
		SQLException ex = new SQLException('SQLException thrown')
		updateUnifiedTOSServiceObj.updateUnifiedTOS(_ , _) >> { throw ex }
		when:
		Response response = unifiedTOSResourceImplObj.updateUnifiedTos(updateUnifiedTOSRequestObj, httpHeaders)
		then:
		response.status == 500
	}
}
