package com.att.idp.idgraphuserregistrationms.helper.dbhelpers

import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonUtil
import com.att.mpsys.common.utils.MPSDefs
import org.junit.jupiter.api.extension.ExtendWith
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.JdbcTemplate
import com.att.idp.idgraphuserregistrationms.metrics.ErrorMetricHandler
import spock.lang.Specification

class GetMemberServicesDBHelperTest extends Specification {
	String stTransactionId = null
    Logger logger = null
    HashMap inpParamHash = CommonUtil.hashMap

    String stAppStatusMsg
    String stAppInfo

    def testObj = new GetMemberServicesDBHelper()

	JdbcTemplate jdbcTemplate = Mock(JdbcTemplate)
	ErrorMetricHandler errorMetricHandler = Mock(ErrorMetricHandler)

	GetMemberRolesDBHelper oMPSDB_GetMemberRoles_H = Mock(GetMemberRolesDBHelper)

    HashMap hmResult
    HashMap MemServices = CommonUtil.hashMap

    List<Object> objectList = null
    private static String dateFormat = 'MMDDYYYY HH24:mi:ss'
    List alQueryResponse = new ArrayList()
    HashMap hmQueryResponse = CommonUtil.hashMap

   def setup() {
        objectList = new ArrayList<Object>()

        testObj.jdbcTemplate=jdbcTemplate
        testObj.errorMetricHandler=errorMetricHandler
        testObj.oGetMemberRolesDBHelper=oMPSDB_GetMemberRoles_H        
        logger = LoggerFactory.getLogger('AddAssociation')
       // System.setProperty('CommonConfigurationFilePath', './opt/att/ajsc/config/CommonConfigurationTest.xml')

        hmQueryResponse[MPSDefs.DB_BAN] = 'VD0011010'
        hmQueryResponse[MPSDefs.DB_SOR_NAME] = 'NA'
        hmQueryResponse[MPSDefs.DB_DELETE_REQUEST_DATE] = '20122018'
        hmQueryResponse[MPSDefs.DB_TOKEN] = '12312134234'
        hmQueryResponse[MPSDefs.DB_REMARKS] = 'NA'
        hmQueryResponse[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_MEMBER_NAME] = 'qay2002'
        hmQueryResponse[MPSDefs.DB_GROUP_NUM] = '213232'
        hmQueryResponse[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        hmQueryResponse[MPSDefs.DB_DOMAIN_ID] = '15'
        hmQueryResponse[MPSDefs.DB_ENC_PASSWORD] = 'adsfdsf133243fdcsvdfdgf'
        hmQueryResponse[MPSDefs.DB_MD5_PASSWORD] = '1jdbshdb29920329092sdfd'
        hmQueryResponse[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = 'DSL'
        hmQueryResponse[MPSDefs.DB_INSTANCE_ID] = '1'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATE] = null
        hmQueryResponse[MPSDefs.DB_AGG_ACCESS_STATUS] = null
        hmQueryResponse[MPSDefs.DB_AGG_SERVICE_STATUS] = null
        hmQueryResponse[MPSDefs.DB_MAILHOST] = null
        hmQueryResponse[MPSDefs.DB_FULLNAME] = null
        hmQueryResponse[MPSDefs.DB_ACCOUNT_TYPE] = null
        hmQueryResponse[MPSDefs.DB_OPTOUT_IND] = null
        hmQueryResponse[MPSDefs.DB_MIGRATION_IND] = null
        hmQueryResponse[MPSDefs.DB_MIGRATION_DATE] = null
        hmQueryResponse[MPSDefs.DB_PARENT_NAME] = null
        hmQueryResponse[MPSDefs.DB_PARENT_DOMAIN] = null
        hmQueryResponse[MPSDefs.DB_PREMIUM_800_IND] = null
        hmQueryResponse[MPSDefs.DB_BULK_BILLING_IND] = null
        hmQueryResponse[MPSDefs.DB_ACCESS_CODE] = null
        hmQueryResponse[MPSDefs.DB_SOR_ID] = null
        hmQueryResponse[MPSDefs.DB_SOR_NAME] = null
        hmQueryResponse[MPSDefs.DB_ACCESS_ID] = null
        hmQueryResponse[MPSDefs.DB_ACCESS_NAME] = null
        hmQueryResponse[MPSDefs.DB_CREATE_DATE] = null
        hmQueryResponse[MPSDefs.DB_LAST_MODIFIED] = null
        hmQueryResponse[MPSDefs.DB_LAST_MODIFIED_BY] = null
        hmQueryResponse[MPSDefs.DB_SHA1_PASSWORD] = null
        hmQueryResponse[MPSDefs.DB_DES3_PASSWORD] = null
        hmQueryResponse[MPSDefs.DB_FAILED_AUTH_COUNT] = null
        hmQueryResponse[MPSDefs.DB_PASSWORD_DIRTY] = null
        hmQueryResponse[MPSDefs.DB_CONTACT_EMAIL] = null
        hmQueryResponse[MPSDefs.DB_CONTACT_EMAIL_VALID] = null
        hmQueryResponse[MPSDefs.DB_LANGUAGE] = null
        hmQueryResponse[MPSDefs.DB_TOS_REJECT_DATE] = null
        hmQueryResponse[MPSDefs.DB_NUM_TOS_REJECTS] = null
        hmQueryResponse[MPSDefs.DB_ALERT_IND] = null
        hmQueryResponse[MPSDefs.DB_CREDIT_CHECKED_IND] = null
        hmQueryResponse[MPSDefs.DB_YREG_COMPLETE_IND] = null
        hmQueryResponse[MPSDefs.DB_LOCKOUT_TIMESTAMP] = null
        hmQueryResponse[MPSDefs.DB_LC_FIRSTNAME] = null
        hmQueryResponse[MPSDefs.DB_LC_LASTNAME] = null
        hmQueryResponse[MPSDefs.DB_NICKNAME] = null
        hmQueryResponse[MPSDefs.DB_GENDER] = null
        hmQueryResponse[MPSDefs.DB_PROOFING_ZIP] = null
        hmQueryResponse[MPSDefs.DB_LAST_MEMBER_STATUS_NAME] = null
        hmQueryResponse[MPSDefs.DB_LAST_MEMBER_STATUS_CODE] = null
        hmQueryResponse[MPSDefs.DB_AGG_EMAIL_STATUS] = null
        hmQueryResponse[MPSDefs.DB_CONTACT_EMAIL_EST_DATE] = null
        hmQueryResponse[MPSDefs.DB_PREVIOUS_CONTACT_EMAIL] = null
        hmQueryResponse[MPSDefs.DB_CSR_INITIATED_LOCKOUT_TS] = null
        hmQueryResponse[MPSDefs.DB_BROWSER_LANGUAGE] = null
        hmQueryResponse[MPSDefs.DB_DSL_NET_PASSWORD] = null
        hmQueryResponse[MPSDefs.DB_DSL_NET_ENCR_TYPE] = null
        hmQueryResponse[MPSDefs.DB_CONTACT_EMAIL_STATUS] = null
        hmQueryResponse[MPSDefs.DB_SSHA_PASSWORD] = null
        hmQueryResponse[MPSDefs.DB_SLID_MEMBER_NUM] = null
        hmQueryResponse[MPSDefs.DB_AUTOGENERATED_IND] = null
        hmQueryResponse[MPSDefs.DB_ACTIVATED_IND] = null
        hmQueryResponse[MPSDefs.DB_BIRTHDATE_VENC] = null
        hmQueryResponse[MPSDefs.DB_PASSCODE_VENC] = null
        hmQueryResponse[MPSDefs.DB_SECURITY_ANSWER_VENC] = null
        hmQueryResponse[MPSDefs.DB_LAST_VERIFIED] = null
        hmQueryResponse[MPSDefs.DB_CREATED_BY] = null
        hmQueryResponse[MPSDefs.DB_MAIN_CTN_OPT_OUT] = null
        hmQueryResponse[MPSDefs.DB_ONL_QA_EST_DATE] = null
        hmQueryResponse[MPSDefs.DB_ENC_PASSWORD_VENC] = null
        hmQueryResponse[MPSDefs.DB_MD5_PASSWORD_VENC] = null
        hmQueryResponse[MPSDefs.DB_SHA1_PASSWORD_VENC] = null
        hmQueryResponse[MPSDefs.DB_DES3_PASSWORD_VENC] = null
        hmQueryResponse[MPSDefs.DB_SSHA_PASSWORD_VENC] = null
        hmQueryResponse[MPSDefs.DB_MEMBER_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_GROUP_STATUS_NAME] = MPSDefs.ENABLED

        MemServices[MPSDefs.APP_STATUS_CODE] = MPSDefs.MPS_SUCCESS
        MemServices[MPSDefs.APP_STATUS_MSG] = MPSDefs.MPS_ALL_OK
        MemServices[MPSDefs.SQLCODE] = MPSDefs.SQL_SUCCESS
        MemServices[MPSDefs.SQLMSG] = MPSDefs.SQL_SUCCESS_MSG
        MemServices[MPSDefs.DB_BAN] = 'VD0011010'
        MemServices[MPSDefs.DB_SOR_NAME] = 'NA'
        MemServices[MPSDefs.DB_DELETE_REQUEST_DATE] = '20122018'
        MemServices[MPSDefs.DB_TOKEN] = '12312134234'
        MemServices[MPSDefs.DB_REMARKS] = 'NA'
        MemServices[MPSDefs.DB_MEMBER_NUM] = '13232322'
        MemServices[MPSDefs.DB_MEMBER_NAME] = 'qay2002'
        MemServices[MPSDefs.DB_GROUP_NUM] = '213232'
        MemServices[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        MemServices[MPSDefs.DB_DOMAIN_ID] = '15'
        MemServices[MPSDefs.DB_ENC_PASSWORD] = 'adsfdsf133243fdcsvdfdgf'
        MemServices[MPSDefs.DB_MD5_PASSWORD] = '1jdbshdb29920329092sdfd'
        MemServices[MPSDefs.DB_PARENT_CHILD_IND] = 'P'
        MemServices[MPSDefs.DB_SECURITY_QUESTION_TYPE] = null
        MemServices[MPSDefs.DB_SECURITY_QUESTION_ID_2] = null
        MemServices[MPSDefs.DB_SECURITY_QUESTION] = null
        MemServices[MPSDefs.DB_SECURITY_QUESTION_2] = null
        MemServices[MPSDefs.DB_SECURITY_QUESTION_ID_1] = null
        MemServices[MPSDefs.DB_SECURITY_ANSWER_2] = null
        MemServices[MPSDefs.DB_SECURITY_ANSWER_1] = null
        MemServices[MPSDefs.DB_SECURITY_QUESTION_ACTIVE] = null
        MemServices[MPSDefs.DB_SECURITY_ANSWER_2_VENC] = null
        MemServices[MPSDefs.DB_SECURITY_QUESTION_2_ACTIVE] = null
        MemServices[MPSDefs.DB_SECURITY_QUESTION_1_TYPE] = null
        MemServices[MPSDefs.DB_SECURITY_QUESTION_2_TYPE] = null
        MemServices[MPSDefs.DB_SECURITY_QUESTION_1_ACTIVE] = null
        MemServices[MPSDefs.DB_SECURITY_ANSWER_1_VENC] = null
        MemServices['security_question_id'] = null
        MemServices[MPSDefs.DB_SECURITY_QUESTION_1] = null
        MemServices[MPSDefs.DB_MEMBER_STATE] = null
        MemServices[MPSDefs.DB_AGG_ACCESS_STATUS] = null
        MemServices[MPSDefs.DB_AGG_SERVICE_STATUS] = null
        MemServices[MPSDefs.DB_MAILHOST] = null
        MemServices[MPSDefs.DB_FULLNAME] = null
        MemServices[MPSDefs.DB_ACCOUNT_TYPE] = null
        MemServices[MPSDefs.DB_OPTOUT_IND] = null
        MemServices[MPSDefs.DB_MIGRATION_IND] = null
        MemServices[MPSDefs.DB_MIGRATION_DATE] = null
        MemServices[MPSDefs.DB_PARENT_NAME] = null
        MemServices[MPSDefs.DB_PARENT_DOMAIN] = null
        MemServices[MPSDefs.DB_PREMIUM_800_IND] = null
        MemServices[MPSDefs.DB_BULK_BILLING_IND] = null
        MemServices[MPSDefs.DB_ACCESS_CODE] = null
        MemServices[MPSDefs.DB_SOR_ID] = null
        MemServices[MPSDefs.DB_SOR_NAME] = null
        MemServices[MPSDefs.DB_ACCESS_ID] = null
        MemServices[MPSDefs.DB_ACCESS_NAME] = null
        MemServices[MPSDefs.DB_CREATE_DATE] = null
        MemServices[MPSDefs.DB_LAST_MODIFIED] = null
        MemServices[MPSDefs.DB_LAST_MODIFIED_BY] = null
        MemServices[MPSDefs.DB_SHA1_PASSWORD] = null
        MemServices[MPSDefs.DB_DES3_PASSWORD] = null
        MemServices[MPSDefs.DB_FAILED_AUTH_COUNT] = null
        MemServices[MPSDefs.DB_PASSWORD_DIRTY] = null
        MemServices[MPSDefs.DB_CONTACT_EMAIL] = null
        MemServices[MPSDefs.DB_CONTACT_EMAIL_VALID] = null
        MemServices[MPSDefs.DB_LANGUAGE] = null
        MemServices[MPSDefs.DB_TOS_REJECT_DATE] = null
        MemServices[MPSDefs.DB_NUM_TOS_REJECTS] = null
        MemServices[MPSDefs.DB_ALERT_IND] = null
        MemServices[MPSDefs.DB_CREDIT_CHECKED_IND] = null
        MemServices[MPSDefs.DB_YREG_COMPLETE_IND] = null
        MemServices[MPSDefs.DB_LOCKOUT_TIMESTAMP] = null
        MemServices[MPSDefs.DB_LC_FIRSTNAME] = null
        MemServices[MPSDefs.DB_LC_LASTNAME] = null
        MemServices[MPSDefs.DB_NICKNAME] = null
        MemServices[MPSDefs.DB_GENDER] = null
        MemServices[MPSDefs.DB_PROOFING_ZIP] = null
        MemServices[MPSDefs.DB_LAST_MEMBER_STATUS_NAME] = null
        MemServices[MPSDefs.DB_LAST_MEMBER_STATUS_CODE] = null
        MemServices[MPSDefs.DB_AGG_EMAIL_STATUS] = null
        MemServices[MPSDefs.DB_CONTACT_EMAIL_EST_DATE] = null
        MemServices[MPSDefs.DB_PREVIOUS_CONTACT_EMAIL] = null
        MemServices[MPSDefs.DB_CSR_INITIATED_LOCKOUT_TS] = null
        MemServices[MPSDefs.DB_BROWSER_LANGUAGE] = null
        MemServices[MPSDefs.DB_DSL_NET_PASSWORD] = null
        MemServices[MPSDefs.DB_DSL_NET_ENCR_TYPE] = null
        MemServices[MPSDefs.DB_CONTACT_EMAIL_STATUS] = null
        MemServices[MPSDefs.DB_SSHA_PASSWORD] = null
        MemServices[MPSDefs.DB_SLID_MEMBER_NUM] = null
        MemServices[MPSDefs.DB_AUTOGENERATED_IND] = null
        MemServices[MPSDefs.DB_ACTIVATED_IND] = null
        MemServices[MPSDefs.DB_BIRTHDATE_VENC] = null
        MemServices[MPSDefs.DB_PASSCODE_VENC] = null
        MemServices[MPSDefs.DB_SECURITY_ANSWER_VENC] = null
        MemServices[MPSDefs.DB_LAST_VERIFIED] = null
        MemServices[MPSDefs.DB_CREATED_BY] = null
        MemServices[MPSDefs.DB_MAIN_CTN_OPT_OUT] = null
        MemServices[MPSDefs.DB_ONL_QA_EST_DATE] = null
        MemServices[MPSDefs.DB_ENC_PASSWORD_VENC] = null
        MemServices[MPSDefs.DB_MD5_PASSWORD_VENC] = null
        MemServices[MPSDefs.DB_SHA1_PASSWORD_VENC] = null
        MemServices[MPSDefs.DB_DES3_PASSWORD_VENC] = null
        MemServices[MPSDefs.DB_SSHA_PASSWORD_VENC] = null

    }


    def "get member services null error"() {

        given:
        hmResult = testObj.getMemberServices(null)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppStatusMsg == 'ERR_HASHMAP_EMP'

    }


    def "get member services error"() {

        given:
        hmResult = testObj.getMemberServices(inpParamHash)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppStatusMsg == 'ERR_EMPTY'
    }


    def "get member serviceswith ban exception"() {
        given:
        inpParamHash[MPSDefs.DB_BAN] = 'VD0011010'
        objectList.add('VD0011010')
        jdbcTemplate.queryForList(_, _) >> null

        hmResult = testObj.getMemberServices(inpParamHash)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppStatusMsg == 'ERR_SYS_APPL'
    }


    def "get member serviceswith ban"() {
        given:
        inpParamHash[MPSDefs.DB_BAN] = 'VD0011010'
        inpParamHash[MPSDefs.SECURITY_ALL_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_QUESTION_REQ] = 'Y'
        objectList.add('VD0011010')
        alQueryResponse.add(hmQueryResponse)

        MemServices[MPSDefs.DB_LAST_FOUR_SSN] = null
        HashMap resultHashSuccess = new HashMap()
        resultHashSuccess[MPSDefs.APP_STATUS_CODE] = '0'
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        hmResult = testObj.getMemberServices(inpParamHash)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppStatusMsg == 'OK'
    }



    def "get member serviceswith group num value"() {
        given:
        inpParamHash[MPSDefs.DB_GROUP_NUM] = '213232'
        inpParamHash[MPSDefs.QUERY_ONLY_SLIDS_FLAG] = 'Y'
        inpParamHash[MPSDefs.AGG_SUB_ELIGIBLE_STATUS_REQUIRED] = 'Y'
        inpParamHash[MPSDefs.LAST_FOUR_SSN_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_QUESTION_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_ANSWER_REQ] = 'Y'
        objectList.add('213232')

        String dynSql = ' AND mem.parent_child_ind=\'S\' '

        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = 'MOSUB'
        hmQueryResponse[MPSDefs.DB_LAST_FOUR_SSN] = '1234'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'Y'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATUS_NAME] = MPSDefs.SUSPENDED
        hmQueryResponse[MPSDefs.DB_GROUP_STATUS_NAME] = MPSDefs.SUSPENDED
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID2] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID2] = '17'

        alQueryResponse.add(hmQueryResponse)

        MemServices[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        MemServices[MPSDefs.DB_DOMAIN_ID] = '15'
        MemServices[MPSDefs.DB_LAST_FOUR_SSN] = '1234'
        HashMap resultHashSuccess = new HashMap()
        resultHashSuccess[MPSDefs.APP_STATUS_CODE] = '0'
        
				jdbcTemplate.queryForList(_, _) >> alQueryResponse
        hmResult = testObj.getMemberServices(inpParamHash)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppInfo == '0'
    }


    def "get member serviceswith member name value"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NAME] = 'qay2002'
        inpParamHash[MPSDefs.QUERY_ONLY_SLIDS_FLAG] = 'Y'
        inpParamHash[MPSDefs.AGG_SUB_ELIGIBLE_STATUS_REQUIRED] = 'Y'
        inpParamHash[MPSDefs.LAST_FOUR_SSN_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_QUESTION_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_ANSWER_REQ] = 'Y'
        inpParamHash[MPSDefs.WS_PORTAL_PROVIDER_UPDATE_DATE] = 'Y'
        inpParamHash[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        objectList.add('qay2002')
        objectList.add('slid.dum')

        String dynSql = ' AND mem.parent_child_ind=\'S\' '

        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = 'PORTAL'
        hmQueryResponse[MPSDefs.DB_LAST_FOUR_SSN] = '1234'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'Y'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATUS_NAME] = MPSDefs.TERMINATED
        hmQueryResponse[MPSDefs.DB_GROUP_STATUS_NAME] = MPSDefs.TERMINATED
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID2] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID2] = '17'
        hmQueryResponse[MPSDefs.DB_PORTAL_PROVIDER_LAST_MODIFIED] = '17122018'
        hmQueryResponse[MPSDefs.DB_PORTAL_PROVIDER_CREATE_DATE] = '17122018'
        hmQueryResponse[MPSDefs.DB_PORTAL_PROVIDER_LAST_MODIFIED_BY] = '17122018'

        alQueryResponse.add(hmQueryResponse)
        MemServices[MPSDefs.DB_LAST_FOUR_SSN] = '1234'

        HashMap resultHashSuccess = new HashMap()
        resultHashSuccess[MPSDefs.APP_STATUS_CODE] = '0'
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        hmResult = testObj.getMemberServices(inpParamHash)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppInfo == '0'
    }


    def "get member serviceswith member name value withou domain"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NAME] = 'qay2002'
        inpParamHash[MPSDefs.QUERY_ONLY_SLIDS_FLAG] = 'Y'
        inpParamHash[MPSDefs.AGG_SUB_ELIGIBLE_STATUS_REQUIRED] = 'Y'
        inpParamHash[MPSDefs.LAST_FOUR_SSN_REQ] = 'Y'; inpParamHash[MPSDefs.SECURITY_QUESTION_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_ANSWER_REQ] = 'Y'
        inpParamHash[MPSDefs.WS_PORTAL_PROVIDER_UPDATE_DATE] = 'Y'
        inpParamHash[MPSDefs.DB_DOMAIN_NAME] = 'att.net'

        ArrayList Roles = new ArrayList()
        Roles.add('ALL')

        inpParamHash[MPSDefs.QUERY_ROLES_INFO_FLAG] = Roles
        objectList.add('qay2002')
        objectList.add('att.net')

        String dynSql = ' AND mem.parent_child_ind in (\'P\',\'C\') '

        hmQueryResponse[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmQueryResponse[MPSDefs.DB_DOMAIN_ID] = '11'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = MPSDefs.IPTV_SERVICE
        hmQueryResponse[MPSDefs.DB_LAST_FOUR_SSN] = '1234'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'Y'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATUS_NAME] = MPSDefs.PENDING
        hmQueryResponse[MPSDefs.DB_GROUP_STATUS_NAME] = MPSDefs.PENDING
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID2] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID2] = '17'

        alQueryResponse.add(hmQueryResponse)

        MemServices[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        MemServices[MPSDefs.DB_DOMAIN_ID] = '11'
        MemServices[MPSDefs.DB_LAST_FOUR_SSN] = '1234'

        HashMap hmDbInput = CommonUtil.hashMap
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '13232322'

        HashMap resultMap = new HashMap()
        HashMap resultHashSuccess = new HashMap()
        resultHashSuccess[MPSDefs.APP_STATUS_CODE] = '0'

        HashMap MemberServiceHashmap = new HashMap()
        ArrayList alRoles = new ArrayList()
        HashMap eachRole = new HashMap()
        eachRole[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        alRoles.add(eachRole)
        MemberServiceHashmap[MPSDefs.IPTV_SERVICE] = alRoles

        resultMap[MPSDefs.APP_STATUS_CODE] = '0'
        resultMap[MPSDefs.DB_MEMBER_SERVICE_ROLES] = MemberServiceHashmap

        oMPSDB_GetMemberRoles_H.getMemberServiceRoles(_ as HashMap) >> resultMap
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        hmResult = testObj.getMemberServices(inpParamHash)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppInfo == '0'
    }


    def "get member services with member name value withs query only slids flag"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        inpParamHash[MPSDefs.QUERY_PARENTS_AND_SLIDS_FLAG] = 'Y'
        inpParamHash[MPSDefs.AGG_SUB_ELIGIBLE_STATUS_REQUIRED] = 'Y'
        inpParamHash[MPSDefs.LAST_FOUR_SSN_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_QUESTION_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_ANSWER_REQ] = 'Y'
        inpParamHash[MPSDefs.WS_PORTAL_PROVIDER_UPDATE_DATE] = 'Y'
        inpParamHash[MPSDefs.DB_DOMAIN_NAME] = 'att.net'

        ArrayList Roles = new ArrayList()
        Roles.add('1544')

        inpParamHash[MPSDefs.QUERY_ROLES_INFO_FLAG] = Roles
        objectList.add('13232322')

        String dynSql = ' AND mem.parent_child_ind in (\'P\',\'S\') '

        hmQueryResponse[MPSDefs.DB_MEMBER_NAME] = 'qay2002'

        hmQueryResponse[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmQueryResponse[MPSDefs.DB_DOMAIN_ID] = '11'

        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = '1544'
        hmQueryResponse[MPSDefs.DB_LAST_FOUR_SSN] = '1234'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'Y'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_GROUP_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID2] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID2] = '17'
        hmQueryResponse[MPSDefs.DB_SUSPEND_REASON_CODE] = '0'

        alQueryResponse.add(hmQueryResponse)

        MemServices[MPSDefs.DB_MEMBER_NAME] = 'qay2002'
        MemServices[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        MemServices[MPSDefs.DB_DOMAIN_ID] = '11'

        MemServices[MPSDefs.DB_LAST_FOUR_SSN] = '1234'

        HashMap hmDbInput = CommonUtil.hashMap
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '13232322'

        HashMap resultMap = new HashMap()
        HashMap resultHashSuccess = new HashMap()
        resultHashSuccess[MPSDefs.APP_STATUS_CODE] = '0'

        HashMap MemberServiceHashmap = new HashMap()
        ArrayList alRoles = new ArrayList()
        HashMap eachRole = new HashMap()
        eachRole[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        alRoles.add(eachRole)
        MemberServiceHashmap['1544'] = alRoles

        resultMap[MPSDefs.APP_STATUS_CODE] = '0'
        resultMap[MPSDefs.DB_MEMBER_SERVICE_ROLES] = MemberServiceHashmap

        oMPSDB_GetMemberRoles_H.getMemberServiceRoles(_ as HashMap) >> resultMap
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        hmResult = testObj.getMemberServices(inpParamHash)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppInfo == '0'
    }


    def "get member services with member name valuewith a g g flag"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        inpParamHash[MPSDefs.AGG_SUB_ELIGIBLE_STATUS_REQUIRED] = 'Y'
        inpParamHash[MPSDefs.LAST_FOUR_SSN_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_QUESTION_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_ANSWER_REQ] = 'Y'
        inpParamHash[MPSDefs.WS_PORTAL_PROVIDER_UPDATE_DATE] = 'Y'
        inpParamHash[MPSDefs.DB_DOMAIN_NAME] = 'att.net'

        ArrayList Roles = new ArrayList()
        Roles.add('1544')

        inpParamHash[MPSDefs.QUERY_ROLES_INFO_FLAG] = Roles
        objectList.add('13232322')

        String dynSql = ' AND mem.parent_child_ind in (\'P\',\'C\',\'S\') '

        hmQueryResponse[MPSDefs.DB_MEMBER_NAME] = 'qay2002'
        hmQueryResponse[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmQueryResponse[MPSDefs.DB_DOMAIN_ID] = '11'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = '1544'
        hmQueryResponse[MPSDefs.DB_LAST_FOUR_SSN] = '1234'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'Y'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_GROUP_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID2] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID2] = '17'

        hmQueryResponse[MPSDefs.DB_SUSPEND_REASON_CODE] = '0'

        alQueryResponse.add(hmQueryResponse)

        MemServices[MPSDefs.DB_MEMBER_NAME] = 'qay2002'
        MemServices[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        MemServices[MPSDefs.DB_DOMAIN_ID] = '11'

        MemServices[MPSDefs.DB_LAST_FOUR_SSN] = '1234'

        HashMap hmDbInput = CommonUtil.hashMap
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '13232322'

        HashMap resultMap = new HashMap()
        HashMap resultHashSuccess = new HashMap()
        resultHashSuccess[MPSDefs.APP_STATUS_CODE] = '0'

        HashMap MemberServiceHashmap = new HashMap()
        ArrayList alRoles = new ArrayList()
        HashMap eachRole = new HashMap()
        eachRole[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        alRoles.add(eachRole)
        MemberServiceHashmap['1544'] = alRoles

        resultMap[MPSDefs.APP_STATUS_CODE] = '0'
        resultMap[MPSDefs.DB_MEMBER_SERVICE_ROLES] = MemberServiceHashmap

        oMPSDB_GetMemberRoles_H.getMemberServiceRoles(_ as HashMap) >> null
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        hmResult = testObj.getMemberServices(inpParamHash)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppInfo == '602'
    }


    def "get member serviceswithmember name valuewiths query only slids flag success"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        inpParamHash[MPSDefs.AGG_SUB_ELIGIBLE_STATUS_REQUIRED] = 'Y'
        inpParamHash[MPSDefs.LAST_FOUR_SSN_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_QUESTION_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_ANSWER_REQ] = 'Y'
        inpParamHash[MPSDefs.WS_PORTAL_PROVIDER_UPDATE_DATE] = 'Y'
        inpParamHash[MPSDefs.DB_DOMAIN_NAME] = 'att.net'

        ArrayList Roles = new ArrayList()
        Roles.add('1544')

        inpParamHash[MPSDefs.QUERY_ROLES_INFO_FLAG] = Roles
        objectList.add('13232322')

        String dynSql = ' AND mem.parent_child_ind in (\'P\',\'C\',\'S\') '

        hmQueryResponse[MPSDefs.DB_MEMBER_NAME] = 'qay2002'
        hmQueryResponse[MPSDefs.DB_GROUP_NUM] = '213232'
        hmQueryResponse[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmQueryResponse[MPSDefs.DB_DOMAIN_ID] = '11'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = '1544'
        hmQueryResponse[MPSDefs.DB_LAST_FOUR_SSN] = '1234'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'Y'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_GROUP_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID2] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID2] = '17'
        hmQueryResponse[MPSDefs.DB_SUSPEND_REASON_CODE] = '0'

        alQueryResponse.add(hmQueryResponse)

        MemServices[MPSDefs.DB_MEMBER_NAME] = 'qay2002'
        MemServices[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        MemServices[MPSDefs.DB_DOMAIN_ID] = '11'
        MemServices[MPSDefs.DB_LAST_FOUR_SSN] = '1234'

        HashMap hmDbInput = CommonUtil.hashMap
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '13232322'
        HashMap resultMap = new HashMap()
        HashMap resultHashSuccess = new HashMap()
        resultHashSuccess[MPSDefs.APP_STATUS_CODE] = '0'

        List<Object> objectListDSLUser = new ArrayList<Object>()
        objectListDSLUser.add('13232322')

        HashMap MemberServiceHashmap = new HashMap()
        ArrayList alRoles = new ArrayList()
        HashMap eachRole = new HashMap()
        eachRole[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        alRoles.add(eachRole)
        MemberServiceHashmap['1544'] = alRoles

        resultMap[MPSDefs.APP_STATUS_CODE] = '285'
        resultMap[MPSDefs.DB_MEMBER_SERVICE_ROLES] = MemberServiceHashmap

        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        oMPSDB_GetMemberRoles_H.getMemberServiceRoles(_ as HashMap) >> resultMap
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        hmResult = testObj.getMemberServices(inpParamHash)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppInfo == '0'
    }


    def "get member serviceswithmember name valuewiths query only slids flag error"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        inpParamHash[MPSDefs.AGG_SUB_ELIGIBLE_STATUS_REQUIRED] = 'Y'
        inpParamHash[MPSDefs.LAST_FOUR_SSN_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_QUESTION_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_ANSWER_REQ] = 'Y'
        inpParamHash[MPSDefs.WS_PORTAL_PROVIDER_UPDATE_DATE] = 'Y'
        inpParamHash[MPSDefs.DB_DOMAIN_NAME] = 'att.net'

        ArrayList Roles = new ArrayList()
        Roles.add('1544')

        inpParamHash[MPSDefs.QUERY_ROLES_INFO_FLAG] = Roles
        objectList.add('13232322')

        String dynSql = ' AND mem.parent_child_ind in (\'P\',\'C\',\'S\') '

        hmQueryResponse[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmQueryResponse[MPSDefs.DB_DOMAIN_ID] = '11'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = '1544'
        hmQueryResponse[MPSDefs.DB_SUSPEND_REASON_CODE] = '0'

        alQueryResponse.add(hmQueryResponse)
        alQueryResponse = new ArrayList()

        MemServices[MPSDefs.DB_DELETE_REQUEST_DATE] = '20122018'
        MemServices[MPSDefs.DB_TOKEN] = '12312134234'
        MemServices[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        MemServices[MPSDefs.DB_DOMAIN_ID] = '11'
        MemServices[MPSDefs.DB_LAST_FOUR_SSN] = '1234'

        HashMap hmDbInput = CommonUtil.hashMap
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '13232322'

        HashMap resultMap = new HashMap()
        HashMap resultHashSuccess = new HashMap()
        resultHashSuccess[MPSDefs.APP_STATUS_CODE] = '0'

        HashMap MemberServiceHashmap = new HashMap()
        ArrayList alRoles = new ArrayList()
        HashMap eachRole = new HashMap()
        eachRole[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        alRoles.add(eachRole)
        MemberServiceHashmap['1544'] = alRoles

        resultMap[MPSDefs.APP_STATUS_CODE] = '285'
        resultMap[MPSDefs.DB_MEMBER_SERVICE_ROLES] = MemberServiceHashmap

        //oMPSDB_GetMemberRoles_H.getMemberServiceRoles(hmDbInput) >> resultMap);
		jdbcTemplate.queryForList(_,_) >> alQueryResponse
        hmResult = testObj.getMemberServices(inpParamHash)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppInfo == '303'
    }


    def "get member serviceswithmember name d i a l service case"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        inpParamHash[MPSDefs.AGG_SUB_ELIGIBLE_STATUS_REQUIRED] = 'Y'
        inpParamHash[MPSDefs.LAST_FOUR_SSN_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_QUESTION_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_ANSWER_REQ] = 'Y'
        inpParamHash[MPSDefs.WS_PORTAL_PROVIDER_UPDATE_DATE] = 'Y'
        inpParamHash[MPSDefs.DB_DOMAIN_NAME] = 'att.net'

        ArrayList Roles = new ArrayList()
        Roles.add('1544')

        inpParamHash[MPSDefs.QUERY_ROLES_INFO_FLAG] = Roles
        objectList.add('13232322')

        String dynSql = ' AND mem.parent_child_ind in (\'P\',\'C\',\'S\') '

        hmQueryResponse[MPSDefs.DB_MEMBER_NAME] = 'qay2002'
        hmQueryResponse[MPSDefs.DB_GROUP_NUM] = '213232'
        hmQueryResponse[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmQueryResponse[MPSDefs.DB_DOMAIN_ID] = '11'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = '1544'
        hmQueryResponse[MPSDefs.DB_LAST_FOUR_SSN] = '1234'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'Y'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_GROUP_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID2] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID2] = '17'
        hmQueryResponse[MPSDefs.DB_SUSPEND_REASON_CODE] = '0'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = 'A'

        alQueryResponse.add(hmQueryResponse)

        MemServices[MPSDefs.DB_MEMBER_NAME] = 'qay2002'
        MemServices[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        MemServices[MPSDefs.DB_DOMAIN_ID] = '11'
        MemServices[MPSDefs.DB_LAST_FOUR_SSN] = '1234'

        HashMap hmDbInput = CommonUtil.hashMap
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '13232322'
        HashMap resultMap = new HashMap()
        HashMap resultHashSuccess = new HashMap()
        resultHashSuccess[MPSDefs.APP_STATUS_CODE] = '0'

        List<Object> objectListDialUser = new ArrayList<Object>()
        objectListDialUser.add('13232322')

        HashMap MemberServiceHashmap = new HashMap()
        ArrayList alRoles = new ArrayList()
        HashMap eachRole = new HashMap()
        eachRole[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        alRoles.add(eachRole)
        MemberServiceHashmap['1544'] = alRoles

        resultMap[MPSDefs.APP_STATUS_CODE] = '285'
        resultMap[MPSDefs.DB_MEMBER_SERVICE_ROLES] = MemberServiceHashmap

        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        oMPSDB_GetMemberRoles_H.getMemberServiceRoles(_ as HashMap) >> resultMap
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        hmResult = testObj.getMemberServices(inpParamHash)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppInfo == '0'
    }


    def "get member serviceswithmember name i s d n service case"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        inpParamHash[MPSDefs.AGG_SUB_ELIGIBLE_STATUS_REQUIRED] = 'Y'
        inpParamHash[MPSDefs.LAST_FOUR_SSN_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_QUESTION_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_ANSWER_REQ] = 'Y'
        inpParamHash[MPSDefs.WS_PORTAL_PROVIDER_UPDATE_DATE] = 'Y'
        inpParamHash[MPSDefs.DB_DOMAIN_NAME] = 'att.net'

        ArrayList Roles = new ArrayList()
        Roles.add('1544')

        inpParamHash[MPSDefs.QUERY_ROLES_INFO_FLAG] = Roles
        objectList.add('13232322')

        String dynSql = ' AND mem.parent_child_ind in (\'P\',\'C\',\'S\') '

        hmQueryResponse[MPSDefs.DB_MEMBER_NAME] = 'qay2002'
        hmQueryResponse[MPSDefs.DB_GROUP_NUM] = '213232'
        hmQueryResponse[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmQueryResponse[MPSDefs.DB_DOMAIN_ID] = '11'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = '1544'
        hmQueryResponse[MPSDefs.DB_LAST_FOUR_SSN] = '1234'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'Y'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_GROUP_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID2] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID2] = '17'
        hmQueryResponse[MPSDefs.DB_SUSPEND_REASON_CODE] = '0'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = 'I2'

        alQueryResponse.add(hmQueryResponse)

        MemServices[MPSDefs.DB_MEMBER_NAME] = 'qay2002'
        MemServices[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        MemServices[MPSDefs.DB_DOMAIN_ID] = '11'
        MemServices[MPSDefs.DB_LAST_FOUR_SSN] = '1234'

        HashMap hmDbInput = CommonUtil.hashMap
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '13232322'
        HashMap resultMap = new HashMap()
        HashMap resultHashSuccess = new HashMap()
        resultHashSuccess[MPSDefs.APP_STATUS_CODE] = '0'

        List<Object> objectListISDNUser = new ArrayList<Object>()
        objectListISDNUser.add('13232322')

        HashMap MemberServiceHashmap = new HashMap()
        ArrayList alRoles = new ArrayList()
        HashMap eachRole = new HashMap()
        eachRole[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        alRoles.add(eachRole)
        MemberServiceHashmap['1544'] = alRoles

        resultMap[MPSDefs.APP_STATUS_CODE] = '285'
        resultMap[MPSDefs.DB_MEMBER_SERVICE_ROLES] = MemberServiceHashmap

        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        oMPSDB_GetMemberRoles_H.getMemberServiceRoles(_ as HashMap) >> resultMap
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        hmResult = testObj.getMemberServices(inpParamHash)
        stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppInfo == '0'
    }


    def "get member serviceswithmember name w i f i service case"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        inpParamHash[MPSDefs.AGG_SUB_ELIGIBLE_STATUS_REQUIRED] = 'Y'
        inpParamHash[MPSDefs.LAST_FOUR_SSN_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_QUESTION_REQ] = 'Y'
        inpParamHash[MPSDefs.SECURITY_ANSWER_REQ] = 'Y'
        inpParamHash[MPSDefs.WS_PORTAL_PROVIDER_UPDATE_DATE] = 'Y'
        inpParamHash[MPSDefs.DB_DOMAIN_NAME] = 'att.net'

        ArrayList Roles = new ArrayList()
        Roles.add('1544')

        inpParamHash[MPSDefs.QUERY_ROLES_INFO_FLAG] = Roles
        objectList.add('13232322')

        String dynSql = ' AND mem.parent_child_ind in (\'P\',\'C\',\'S\') '

        hmQueryResponse[MPSDefs.DB_MEMBER_NAME] = 'qay2002'
        hmQueryResponse[MPSDefs.DB_GROUP_NUM] = '213232'
        hmQueryResponse[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        hmQueryResponse[MPSDefs.DB_DOMAIN_ID] = '11'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = '1544'
        hmQueryResponse[MPSDefs.DB_LAST_FOUR_SSN] = '1234'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'Y'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_GROUP_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID2] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID2] = '17'
        hmQueryResponse[MPSDefs.DB_SUSPEND_REASON_CODE] = '0'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = 'WIFI'

        alQueryResponse.add(hmQueryResponse)

        MemServices[MPSDefs.DB_MEMBER_NAME] = 'qay2002'
        MemServices[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        MemServices[MPSDefs.DB_DOMAIN_ID] = '11'
        MemServices[MPSDefs.DB_LAST_FOUR_SSN] = '1234'

        HashMap hmDbInput = CommonUtil.hashMap
        hmDbInput[MPSDefs.DB_MEMBER_NUM] = '13232322'
        HashMap resultMap = new HashMap()
        HashMap resultHashSuccess = new HashMap()
        resultHashSuccess[MPSDefs.APP_STATUS_CODE] = '0'

        List<Object> objectListWIFIUser = new ArrayList<Object>()
        objectListWIFIUser.add('13232322')

        HashMap MemberServiceHashmap = new HashMap()
        ArrayList alRoles = new ArrayList()
        HashMap eachRole = new HashMap()
        eachRole[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        alRoles.add(eachRole)
        MemberServiceHashmap['1544'] = alRoles

        resultMap[MPSDefs.APP_STATUS_CODE] = '285'
		resultMap[MPSDefs.DB_MEMBER_SERVICE_ROLES] = MemberServiceHashmap

		jdbcTemplate.queryForList(_,_) >> alQueryResponse
		oMPSDB_GetMemberRoles_H.getMemberServiceRoles(_ as HashMap) >> resultMap
		jdbcTemplate.queryForList(_,_) >> alQueryResponse
		hmResult = testObj.getMemberServices(inpParamHash)
		stAppStatusMsg = (String) hmResult[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) hmResult[MPSDefs.APP_STATUS_CODE]

        then:
        stAppInfo == '0'
    }

    // --- Additional tests for uncovered paths ---

    def "get member services with null jdbcTemplate"() {
        given:
        testObj.jdbcTemplate = null
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "get member services with member num and no other flags"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >> alQueryResponse

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
        hmResult[MPSDefs.DB_MEMBER_NUM] == '13232322'
    }

    def "get member services with member num query only slids"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        inpParamHash[MPSDefs.QUERY_ONLY_SLIDS_FLAG] = 'Y'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >> alQueryResponse

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
    }

    def "get member services with member num empty result set"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        jdbcTemplate.queryForList(_, _) >> new ArrayList()

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'REC_NOT_FOUND'
    }

    def "get member services with ban and memberlockout query"() {
        given:
        inpParamHash[MPSDefs.DB_BAN] = 'VD0011010'
        inpParamHash[MPSDefs.DB_QUERY_MEMBERLOCKOUT_FLAG] = 'Y'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)

        HashMap hmLockoutRow = new HashMap()
        hmLockoutRow[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmLockoutRow[MPSDefs.DB_LOCKOUT_ID] = '1'
        hmLockoutRow[MPSDefs.DB_LOCKOUT_NAME] = 'PASSWORD_LOCKOUT'
        hmLockoutRow[MPSDefs.DB_SET_NUMBER] = '1'
        hmLockoutRow[MPSDefs.DB_FAILED_AUTH_COUNT] = '3'
        hmLockoutRow[MPSDefs.DB_LOCKOUT_EXPIRATION] = '03292026'
        hmLockoutRow[MPSDefs.DB_LAST_FAILED_AUTH] = '03292026'
        hmLockoutRow[MPSDefs.DB_CREATE_DATE] = '03292026'
        hmLockoutRow[MPSDefs.DB_LAST_MODIFIED] = '03292026'
        hmLockoutRow[MPSDefs.DB_LAST_MODIFIED_BY] = 'SYSTEM'
        List alLockoutResponse = new ArrayList()
        alLockoutResponse.add(hmLockoutRow)

        jdbcTemplate.queryForList(_, _) >>> [alQueryResponse, alLockoutResponse]

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
        hmResult[MPSDefs.DB_MEMBERLOCKOUT] != null
    }

    def "get member services with memberlockout query empty result"() {
        given:
        inpParamHash[MPSDefs.DB_BAN] = 'VD0011010'
        inpParamHash[MPSDefs.DB_QUERY_MEMBERLOCKOUT_FLAG] = 'Y'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >>> [alQueryResponse, new ArrayList()]

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
        hmResult[MPSDefs.DB_MEMBERLOCKOUT] == null
    }

    def "get member services with slid member num for lockout query"() {
        given:
        inpParamHash[MPSDefs.DB_BAN] = 'VD0011010'
        inpParamHash[MPSDefs.DB_QUERY_MEMBERLOCKOUT_FLAG] = 'Y'
        hmQueryResponse[MPSDefs.DB_SLID_MEMBER_NUM] = '99999999'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >>> [alQueryResponse, new ArrayList()]

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
        hmResult[MPSDefs.DB_SLID_MEMBER_NUM] == '99999999'
    }

    def "get member services with ban and individual last_four_ssn_req only"() {
        given:
        inpParamHash[MPSDefs.DB_BAN] = 'VD0011010'
        inpParamHash[MPSDefs.LAST_FOUR_SSN_REQ] = 'Y'
        hmQueryResponse[MPSDefs.DB_LAST_FOUR_SSN] = '1234'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >> alQueryResponse

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
        hmResult[MPSDefs.DB_LAST_FOUR_SSN] == '1234'
    }

    def "get member services with ban and individual security_answer_req only"() {
        given:
        inpParamHash[MPSDefs.DB_BAN] = 'VD0011010'
        inpParamHash[MPSDefs.SECURITY_ANSWER_REQ] = 'Y'
        hmQueryResponse[MPSDefs.DB_SECURITY_ANSWER_1] = 'answer1'
        hmQueryResponse[MPSDefs.DB_SECURITY_ANSWER_2] = 'answer2'
        hmQueryResponse[MPSDefs.DB_SECURITY_ANSWER_1_VENC] = 'venc1'
        hmQueryResponse[MPSDefs.DB_SECURITY_ANSWER_2_VENC] = 'venc2'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >> alQueryResponse

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
        hmResult[MPSDefs.DB_SECURITY_ANSWER_1] == 'answer1'
        hmResult[MPSDefs.DB_SECURITY_ANSWER_2] == 'answer2'
    }

    def "get member services with ban and individual security_question_req only"() {
        given:
        inpParamHash[MPSDefs.DB_BAN] = 'VD0011010'
        inpParamHash[MPSDefs.SECURITY_QUESTION_REQ] = 'Y'
        hmQueryResponse[MPSDefs.DB_SECURITY_QUESTION] = 'fav color?'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >> alQueryResponse

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
        hmResult[MPSDefs.DB_SECURITY_QUESTION] == 'fav color?'
    }

    def "get member services DSL service with dsluser data"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = 'DSL'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'N'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)

        HashMap hmDSLUser = new HashMap()
        hmDSLUser[MPSDefs.DB_CIRCUIT_ID] = 'CIRC001'
        hmDSLUser[MPSDefs.DB_VIRTUAL_PATH] = 'VP1'
        hmDSLUser[MPSDefs.DB_VIRTUAL_CIRCUIT] = 'VC1'
        hmDSLUser[MPSDefs.DB_INCOMING_BURST] = '1000'
        hmDSLUser[MPSDefs.DB_INCOMING_LIMIT] = '2000'
        hmDSLUser[MPSDefs.DB_OUTGOING_BURST] = '500'
        hmDSLUser[MPSDefs.DB_OUTGOING_LIMIT] = '1000'
        hmDSLUser[MPSDefs.DB_PROTOCOL_TYPE] = 'PPPoE'
        hmDSLUser[MPSDefs.DB_IP_ADDRESS] = '10.0.0.1'
        hmDSLUser[MPSDefs.DB_IP_NETBLOCK] = '24'
        hmDSLUser[MPSDefs.DB_IP_SUBNET] = '255.255.255.0'
        hmDSLUser[MPSDefs.DB_WTN] = '2145551234'
        hmDSLUser[MPSDefs.DSL_USER_CREATE_DATE] = '03292026'
        hmDSLUser[MPSDefs.DSL_USER_LAST_MODIFIED] = '03292026'
        hmDSLUser[MPSDefs.DSL_USER_LAST_MODIFIED_BY] = 'SYSTEM'
        hmDSLUser[MPSDefs.DB_DSLAM_TYPE] = 'ADSL'
        hmDSLUser[MPSDefs.DB_TDSL_IND] = 'N'
        hmDSLUser[MPSDefs.DB_IPV6RD_ENABLED] = 'N'
        hmDSLUser[MPSDefs.DB_IPV6RD_MANUALLY_DISABLED] = 'N'
        hmDSLUser[MPSDefs.DB_NETWORK_PROFILE_NAME] = 'DEFAULT'
        hmDSLUser[MPSDefs.DB_NETWORK_PROFILE_ID] = '1'
        hmDSLUser[MPSDefs.DB_DNS_ERR_OPTOUT_IND] = 'N'
        List alDSLResp = new ArrayList()
        alDSLResp.add(hmDSLUser)

        jdbcTemplate.queryForList(_, _) >>> [alQueryResponse, alDSLResp]

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
        hmResult[MPSDefs.SERVICES] != null
    }

    def "get member services DSL service with empty dsluser result"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = 'DSL'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'N'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >>> [alQueryResponse, new ArrayList()]

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
    }

    def "get member services DIAL service with dialuser data"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = MPSDefs.DIAL_SERVICE
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'N'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)

        HashMap hmDialUser = new HashMap()
        hmDialUser[MPSDefs.DIAL_USER_CREATE_DATE] = '03292026'
        hmDialUser[MPSDefs.DIAL_USER_LAST_MODIFIED] = '03292026'
        hmDialUser[MPSDefs.DIAL_USER_LAST_MODIFIED_BY] = 'SYSTEM'
        hmDialUser[MPSDefs.DB_NETWORK_PROFILE_NAME] = 'DEFAULT'
        hmDialUser[MPSDefs.DB_NETWORK_PROFILE_ID] = '1'
        List alDialResp = new ArrayList()
        alDialResp.add(hmDialUser)

        jdbcTemplate.queryForList(_, _) >>> [alQueryResponse, alDialResp]

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
    }

    def "get member services DIAL service with empty dialuser result"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = MPSDefs.DIAL_SERVICE
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'N'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >>> [alQueryResponse, new ArrayList()]

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
    }

    def "get member services ISDN service with isdnuser data"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = MPSDefs.ISDN_SERVICE
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'N'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)

        HashMap hmISDNUser = new HashMap()
        hmISDNUser[MPSDefs.DB_IP_ADDRESS] = '10.0.0.2'
        hmISDNUser[MPSDefs.DB_IP_NETBLOCK] = '24'
        hmISDNUser[MPSDefs.DB_IP_SUBNET] = '255.255.255.0'
        hmISDNUser[MPSDefs.DB_NETWORK_PROFILE_NAME] = 'ISDN_DEFAULT'
        hmISDNUser[MPSDefs.DB_NETWORK_PROFILE_ID] = '2'
        hmISDNUser[MPSDefs.ISDN_USER_CREATE_DATE] = '03292026'
        hmISDNUser[MPSDefs.ISDN_USER_LAST_MODIFIED] = '03292026'
        hmISDNUser[MPSDefs.ISDN_USER_LAST_MODIFIED_BY] = 'SYSTEM'
        List alISDNResp = new ArrayList()
        alISDNResp.add(hmISDNUser)

        jdbcTemplate.queryForList(_, _) >>> [alQueryResponse, alISDNResp]

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
    }

    def "get member services ISDN service with empty isdnuser result"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = MPSDefs.ISDN_SERVICE
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'N'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >>> [alQueryResponse, new ArrayList()]

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
    }

    def "get member services ISDN2 service path"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = MPSDefs.ISDN2_SERVICE
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'N'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >>> [alQueryResponse, new ArrayList()]

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
    }

    def "get member services WIFI service with wifiuser data"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = MPSDefs.WIFI_SERVICE
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'N'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)

        HashMap hmWIFIUser = new HashMap()
        hmWIFIUser[MPSDefs.DB_WIFI_SERVICE_TYPE] = 'BASIC'
        hmWIFIUser[MPSDefs.DB_ROAMING_BLOCK_IND] = 'N'
        hmWIFIUser[MPSDefs.DB_WIFI_USER_CREATE_DATE] = '03292026'
        hmWIFIUser[MPSDefs.DB_WIFI_USER_LAST_MODIFIED] = '03292026'
        hmWIFIUser[MPSDefs.DB_WIFI_USER_LAST_MODIFIED_BY] = 'SYSTEM'
        List alWIFIResp = new ArrayList()
        alWIFIResp.add(hmWIFIUser)

        jdbcTemplate.queryForList(_, _) >>> [alQueryResponse, alWIFIResp]

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
    }

    def "get member services WIFI service with empty wifiuser result"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = MPSDefs.WIFI_SERVICE
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'N'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >>> [alQueryResponse, new ArrayList()]

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
    }

    def "get member services with roles returning non-success non-rec-not-found error"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        ArrayList Roles = new ArrayList()
        Roles.add('ALL')
        inpParamHash[MPSDefs.QUERY_ROLES_INFO_FLAG] = Roles
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)

        HashMap resultMap = new HashMap()
        resultMap[MPSDefs.APP_STATUS_CODE] = '602'
        resultMap[CommonDefs.COMMON_APP_STATUS_MSG] = 'ERR_SYS_APPL'

        jdbcTemplate.queryForList(_, _) >> alQueryResponse
        oMPSDB_GetMemberRoles_H.getMemberServiceRoles(_ as HashMap) >> resultMap

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '602'
    }

    def "get member services PORTAL service without portal provider update date"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = 'PORTAL'
        hmQueryResponse[MPSDefs.DB_PORTAL_PROVIDER] = 'ATT'
        hmQueryResponse[MPSDefs.DB_PLITE_IND] = 'Y'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'N'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >> alQueryResponse

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
    }

    def "get member services with null service name in result"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = null
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >> alQueryResponse

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
    }

    def "get member services calculateStatus terminated takes precedence over suspended"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = 'DSL'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATUS_NAME] = MPSDefs.TERMINATED
        hmQueryResponse[MPSDefs.DB_GROUP_STATUS_NAME] = MPSDefs.SUSPENDED
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'N'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >>> [alQueryResponse, new ArrayList()]

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
        HashMap services = (HashMap) hmResult[MPSDefs.SERVICES]
        services != null
    }

    def "get member services calculateStatus suspended when group suspended"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = 'DSL'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_GROUP_STATUS_NAME] = MPSDefs.SUSPENDED
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'N'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >>> [alQueryResponse, new ArrayList()]

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
    }

    def "get member services calculateStatus pending when member pending"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = 'DSL'
        hmQueryResponse[MPSDefs.DB_MEMBER_STATUS_NAME] = MPSDefs.PENDING
        hmQueryResponse[MPSDefs.DB_GROUP_STATUS_NAME] = MPSDefs.ENABLED
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'N'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >>> [alQueryResponse, new ArrayList()]

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
    }

    def "get member services with agg sub eligible status terminated then suspended"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        inpParamHash[MPSDefs.AGG_SUB_ELIGIBLE_STATUS_REQUIRED] = 'Y'

        HashMap hmRow1 = new HashMap(hmQueryResponse)
        hmRow1[MPSDefs.DB_SERVICE_NAME] = 'DSL'
        hmRow1[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'Y'
        hmRow1[MPSDefs.DB_MEMBER_STATUS_NAME] = MPSDefs.TERMINATED
        hmRow1[MPSDefs.DB_GROUP_STATUS_NAME] = MPSDefs.TERMINATED
        hmRow1[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmRow1)

        jdbcTemplate.queryForList(_, _) >>> [alQueryResponse, new ArrayList()]

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
    }

    def "get member services with MOSUB service and association data"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = MPSDefs.MOSUB_SERVICE
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID1] = '5'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID2] = '6'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID2] = '18'
        hmQueryResponse[MPSDefs.DB_SOR_NAME1] = 'ATT'
        hmQueryResponse[MPSDefs.DB_SOR_NAME2] = 'CINGULAR'
        hmQueryResponse['asso_assigned_by'] = 'SYSTEM'
        hmQueryResponse['asso_create_date'] = '03292026'
        hmQueryResponse['asso_last_modified'] = '03292026'
        hmQueryResponse['asso_last_modified_by'] = 'SYSTEM'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'N'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >> alQueryResponse

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
        hmResult[MPSDefs.SERVICES] != null
    }

    def "get member services with AAB service and association data"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = MPSDefs.AAB_SERVICE
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID1] = '5'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID1] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID2] = '6'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID2] = '18'
        hmQueryResponse[MPSDefs.DB_SOR_NAME1] = 'ATT'
        hmQueryResponse[MPSDefs.DB_SOR_NAME2] = 'CINGULAR'
        hmQueryResponse['asso_assigned_by'] = 'SYSTEM'
        hmQueryResponse['asso_create_date'] = '03292026'
        hmQueryResponse['asso_last_modified'] = '03292026'
        hmQueryResponse['asso_last_modified_by'] = 'SYSTEM'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'N'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >> alQueryResponse

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
    }

    def "get member services with MOSUB non-matching sor invariant id association"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = MPSDefs.MOSUB_SERVICE
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID] = '17'
        hmQueryResponse[MPSDefs.DB_SOR_ID1] = '5'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID1] = '99'
        hmQueryResponse[MPSDefs.DB_SOR_ID2] = '6'
        hmQueryResponse[MPSDefs.DB_SOR_INVARIANT_ID2] = '18'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'N'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >> alQueryResponse

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
    }

    def "get member services with IPTV service portal_svc_provider"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = MPSDefs.IPTV_SERVICE
        hmQueryResponse[MPSDefs.DB_PORTAL_SVC_PROVIDER] = 'UVERSE'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'N'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >> alQueryResponse

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
    }

    def "get member services with service name 1544 and suspend reason code"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        hmQueryResponse[MPSDefs.DB_SERVICE_NAME] = '1544'
        hmQueryResponse[MPSDefs.DB_SUSPEND_REASON_CODE] = 'FRAUD'
        hmQueryResponse[MPSDefs.DB_SUBACCOUNT_ELIGIBLE] = 'N'
        hmQueryResponse[MPSDefs.DB_RECENT_FRAUD_PW_DATE] = null
        alQueryResponse.add(hmQueryResponse)
        jdbcTemplate.queryForList(_, _) >> alQueryResponse

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[MPSDefs.APP_STATUS_CODE] == '0'
    }

    def "get member services exception during query"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NUM] = '13232322'
        jdbcTemplate.queryForList(_, _) >> { throw new RuntimeException('DB connection failed') }

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult != null
        hmResult[MPSDefs.APP_STATUS_CODE] != '0'
    }

    def "get member services with group num and empty result set"() {
        given:
        inpParamHash[MPSDefs.DB_GROUP_NUM] = '213232'
        jdbcTemplate.queryForList(_, _) >> new ArrayList()

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'REC_NOT_FOUND'
    }

    def "get member services with member name domain and empty result set"() {
        given:
        inpParamHash[MPSDefs.DB_MEMBER_NAME] = 'qay2002'
        inpParamHash[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        jdbcTemplate.queryForList(_, _) >> new ArrayList()

        when:
        hmResult = testObj.getMemberServices(inpParamHash)

        then:
        hmResult[CommonDefs.COMMON_APP_STATUS_MSG] == 'REC_NOT_FOUND'
    }
}
