package com.att.idp.component

import com.att.idp.idgraph.extclient.db.service.TworkitemService
import com.att.idp.idgraph.extclient.g2.service.G2SoapClientHandler
import com.att.idp.idgraph.extclient.model.ExtClientResponse
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.AccountInfoDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetMemberServicesDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetProvisionedServicesDBHelper
import com.att.idp.idgraphuserregistrationms.queue.message.helpers.ValidateAndSyncG2QueueHelper
import com.att.idp.idgraphuserregistrationms.resource.request.SyncUserProfileRequest
import com.att.mpsys.common.helpers.FeatureManagerHelper
import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import org.spockframework.spring.SpringBean

/**
 * Component test for POST /userprofile/activate/uban endpoint — G2 LDAP sync path.
 *
 * Dependency chain:
 *   SyncUserProfileResourceImpl (INTERNAL — real)
 *     ├── SyncUserProfileRequestValidator (INTERNAL — real)
 *     └── G2SyncServiceImpl (INTERNAL — real)
 *          └── G2LDAPHelper (INTERNAL — real)
 *               ├── GetMemberServicesDBHelper (EXTERNAL — mock)
 *               ├── G2SoapClientHandler (EXTERNAL — mock, SOAP)
 *               ├── TworkitemService (EXTERNAL — mock, DB)
 *               └── FeatureManagerHelper (EXTERNAL — mock)
 */
class G2SyncOperationCompTest extends CompTestBase {

    private final String uri = '/userprofile/activate/uban'

    // TECH_DEBT: DUPLICATE — GetMemberServicesDBHelper also mocked in other CTs; consolidate in CompTestBase (Phase 4)
    @SpringBean
    G2SoapClientHandler g2SoapClientHandler = Mock()

    @SpringBean
    TworkitemService tworkitemService = Mock()

    @SpringBean
    GetMemberServicesDBHelper getMemberServicesDBHelper = Mock()

    @SpringBean
    FeatureManagerHelper featureManager = Mock()

    @SpringBean
    AccountInfoDBHelper accountInfoDBHelper = Mock()

    @SpringBean
    GetProvisionedServicesDBHelper getProvisionedServicesDBHelper = Mock()

    @SpringBean
    ValidateAndSyncG2QueueHelper validateAndSyncG2QueueHelper = Mock()

    private Map<String, String> headers() {
        [
            'Content-Type' : 'application/json',
            'X-ATT-ClientId': 'DATAMGT',
            'idp-trace-id' : 'traceid:traceid:0:0'
        ]
    }

    private SyncUserProfileRequest validRequest() {
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.setBan("285698993")
        return request
    }

    private ExtClientResponse successResp() {
        def e = new ExtClientResponse()
        e.appStatusCode = '0'
        e.appInfo = 'SUCCESS'
        return e
    }

    private ExtClientResponse g2SuccessResp() {
        def e = new ExtClientResponse()
        e.appStatusCode = '100'
        e.appInfo = 'Ok - Modified'
        return e
    }

    private ExtClientResponse errorResp(String code, String info) {
        def e = new ExtClientResponse()
        e.appStatusCode = code
        e.appInfo = info
        return e
    }

    // ========== Success Scenarios ==========

    def "G2 ldap sync path should execute successfully"() {
        given:
        HashMap getMemberResp = readJsonFileToMap("mockResponse/GetMemberServices.json") as HashMap
        HashMap accountInfo = [ban: '285698993', account_type: 'Consumer', fullname: 'Test User', bill_cycle: '1', legal_entity: 'ATT']
        ArrayList accountInfoList = [accountInfo]
        HashMap accountInfoResp = CommonErrorMap.makeCategoryMap(0, 'Success')
        accountInfoResp.put('ACCOUNT_INFO', accountInfoList)
        HashMap provisionedServicesResp = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, 'No provisioned services found')

        when:
        def resp = givenBaseSpec().headers(headers()).body(validRequest()).post(uri)

        then:
        accountInfoDBHelper.getAccountInfo(_) >> accountInfoResp
        validateAndSyncG2QueueHelper.makeAsyncCall(_, _) >> CommonErrorMap.makeCategoryMap(303, 'REC_NOT_FOUND')
        getProvisionedServicesDBHelper.getProvisionedServices(_) >> provisionedServicesResp
        featureManager.isEnabled("svc-idgraph-userreg-enable-g2sync-extclient") >> true

        getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> getMemberResp
        g2SoapClientHandler.process(_) >> g2SuccessResp()
        tworkitemService.deleteByStopKeyAndStopValue(_, _) >> _


        and:
        resp.statusCode() == 200
        resp.body().asString().contains('"appStatusCode":"0"')
        resp.body().asString().contains('"appStatusMsg":"SUCCESS"')
    }

    // ========== Error Scenarios ==========

    def "G2 soap handler returns error should propagate error response"() {
        given:
        HashMap getMemberResp = readJsonFileToMap("mockResponse/GetMemberServices.json") as HashMap
        HashMap accountInfo = [ban: '285698993', account_type: 'Consumer', fullname: 'Test User', bill_cycle: '1', legal_entity: 'ATT']
        ArrayList accountInfoList = [accountInfo]
        HashMap accountInfoResp = CommonErrorMap.makeCategoryMap(0, 'Success')
        accountInfoResp.put(CommonDefs.ACCOUNT_INFO_KEY, accountInfoList)
        HashMap provisionedServicesResp = [:]
        provisionedServicesResp['services'] = [:]

        when:
        def resp = givenBaseSpec().headers(headers()).body(validRequest()).post(uri)

        then:
        _ * accountInfoDBHelper.getAccountInfo(_) >> accountInfoResp
        _ * validateAndSyncG2QueueHelper.makeAsyncCall(_, _) >> CommonErrorMap.makeCategoryMap(303, 'REC_NOT_FOUND')
        _ * getProvisionedServicesDBHelper.getProvisionedServices(_) >> provisionedServicesResp
        _ * featureManager.isEnabled("svc-idgraph-userreg-enable-g2sync-extclient") >> true
        _ * tworkitemService.deleteByStopKeyAndStopValue(_, _) >> _
        getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> getMemberResp


        and:
        resp.statusCode() == 400
        resp.body().asString().contains('"appStatusCode":"202"')
        resp.body().asString().contains('"appStatusMsg":"ERR_NOT_PROVISIONED"')
    }
/*
    def "G2 soap handler throws exception should return error response"() {
        given:
        HashMap getMemberResp = readJsonFileToMap("mockResponse/GetMemberServices.json") as HashMap
        HashMap accountInfo = [ban: '285698993', account_type: 'Consumer', fullname: 'Test User', bill_cycle: '1', legal_entity: 'ATT']
        ArrayList accountInfoList = [accountInfo]
        HashMap accountInfoResp = CommonErrorMap.makeCategoryMap(0, 'Success')
        accountInfoResp.put(CommonDefs.ACCOUNT_INFO_KEY, accountInfoList)
        HashMap provisionedServicesResp = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, 'No provisioned services found')


        when:
        def resp = givenBaseSpec().headers(headers()).body(validRequest()).post(uri)

        then:
        _ * accountInfoDBHelper.getAccountInfo(_) >> accountInfoResp
        _ * validateAndSyncG2QueueHelper.makeAsyncCall(_, _) >> CommonErrorMap.makeCategoryMap(303, 'REC_NOT_FOUND')
        _ * getProvisionedServicesDBHelper.getProvisionedServices(_) >> provisionedServicesResp
        _ * featureManager.isEnabled("svc-idgraph-userreg-enable-g2sync-extclient") >> true
        _ * featureManager.isEnabled("svc-idgraph-userreg-enable-haloc-sync") >> true
        _ * featureManager.isEnabled("svc-idgraph-userreg-enable-yahoo-sync") >> true
         getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> getMemberResp
        1 * g2SoapClientHandler.process(_) >> { throw new RuntimeException('G2 connection failed') }


        and:
        resp.statusCode() == 500
    }*/

    def "getMemberServices returns error should propagate error"() {
        given:
        HashMap errorResp = CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_REC_NOT_FOUND_NUM, 'No member services found')
        HashMap accountInfo = [ban: '285698993', account_type: 'Consumer', fullname: 'Test User', bill_cycle: '1', legal_entity: 'ATT']
        ArrayList accountInfoList = [accountInfo]
        HashMap accountInfoResp = CommonErrorMap.makeCategoryMap(0, 'Success')
        accountInfoResp.put(CommonDefs.ACCOUNT_INFO_KEY, accountInfoList)
        HashMap provisionedServicesResp = [:]
        provisionedServicesResp['services'] = [:]

        when:
        def resp = givenBaseSpec().headers(headers()).body(validRequest()).post(uri)

        then:
        _ * accountInfoDBHelper.getAccountInfo(_) >> accountInfoResp
        _ * validateAndSyncG2QueueHelper.makeAsyncCall(_, _) >> CommonErrorMap.makeCategoryMap(303, 'REC_NOT_FOUND')
        _ * getProvisionedServicesDBHelper.getProvisionedServices(_) >> provisionedServicesResp
        _ * featureManager.isEnabled("svc-idgraph-userreg-enable-g2sync-extclient") >> true
        _ * featureManager.isEnabled("svc-idgraph-userreg-enable-haloc-sync") >> true
        _ * featureManager.isEnabled("svc-idgraph-userreg-enable-yahoo-sync") >> true
         getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> errorResp
        0 * _

        and:
        resp.statusCode() != 200
    }
}
