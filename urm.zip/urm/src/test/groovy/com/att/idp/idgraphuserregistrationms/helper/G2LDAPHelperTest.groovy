package com.att.idp.idgraphuserregistrationms.helper

import com.att.mpsys.common.utils.CErrorDefs
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.CommonErrorMap
import com.att.mpsys.common.utils.MPSDefs
import org.slf4j.Logger
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification
import spock.lang.Unroll

class G2LDAPHelperTest extends Specification {

    G2LDAPHelper  g2LDAPHelper

    LDAPValidator oLDAPValidator = Mock(LDAPValidator)

    HashMap hmLDAPValidatorResp =  null
    int retCode = -1

    String stAppStatusMsg = null
    String stAppInfo = null

    private Logger logger = Mock(Logger)

    private HashMap<String, Object> member
    private HashMap<String, Object> input

    def setup() {
       g2LDAPHelper = new G2LDAPHelper(oLDAPValidator)
        hmLDAPValidatorResp=new HashMap()

        member = new HashMap<>()
        member['member_state'] = 'ACTIVE'
        member['sor_name'] = 'COLA'
        member['domain_name'] = 'att.net'
        member['parent_child_ind'] = 'C'

        input = new HashMap<>()
        input['member_state'] = 'ACTIVE'
        input['sor_name'] = 'COLA'
        input['domain_name'] = 'att.net'

        System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')
        //System.setProperty('G2ConfigurationFilePath', './opt/ajsc/etc/config/G2ConfigurationTest.xml')
        ReflectionTestUtils.setField(g2LDAPHelper, "g2BlockDomains",
                "portal.att.net|myaccount.bellsouth.net|attworld.com|slid.dum|foreign.dum")
        ReflectionTestUtils.setField(g2LDAPHelper, "g2LdapRestrictedSor", "COLA")
        ReflectionTestUtils.setField(g2LDAPHelper, "nonLdapServices",
                "IPTV|ECOMM|VOIP|YPAGES|PORTAL|ISS|MOSUB|AAB|UVERSE|FULCRUM|TITAN|XDCP|MAINUVERSE|MOBILITY|DLIFE|XANBOO|NEWSROOM|DLIFELIGHT")
        ReflectionTestUtils.setField(g2LDAPHelper, "skipLdap", "N")
    }

    def "mq to ldap returns success"() {

        given:
        hmLDAPValidatorResp['appStatusCode'] = '0'
        hmLDAPValidatorResp['retCode'] = '0'
        oLDAPValidator.validate(_,_,_) >> hmLDAPValidatorResp
        HashMap<String, Object> result = g2LDAPHelper.mqToLdap(input, member)

        stAppStatusMsg = (String) result[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) result[CommonDefs.COMMON_APP_INFO]
        then:
        stAppStatusMsg == 'SUCCESS'
        stAppInfo == 'COLA user should not go to LDAP....... Returning SUCCESS'
    }

    def "mq to ldap returns success when domain is blocked"() {
        given:
        HashMap<String, Object> input = new HashMap<>()
        HashMap<String, Object> member = new HashMap<>()
        member['domain_name'] = 'attworld.com'
        HashMap<String, Object> result = g2LDAPHelper.mqToLdap(input, member)
        stAppStatusMsg = (String) result[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) result[CommonDefs.COMMON_APP_INFO]
        then:
        stAppStatusMsg == 'SUCCESS'
    }

    def "mq to ldap returns success when sor is restricted"() {
        given:
        member['sor_name'] = 'COLA'
        HashMap<String, Object> result = g2LDAPHelper.mqToLdap(input, member)
        stAppStatusMsg = (String) result[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) result[CommonDefs.COMMON_APP_INFO]
        then:
        stAppStatusMsg == 'SUCCESS'
        stAppInfo == 'COLA user should not go to LDAP....... Returning SUCCESS'
    }

    def "mq to ldap returns success when sor name as b l s"() {
        given:
        member['sor_name'] = 'BLS'
        member['parent_child_ind'] = 'C'
        HashMap<String, Object> result = g2LDAPHelper.mqToLdap(input, member)
        stAppStatusMsg = (String) result[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) result[CommonDefs.COMMON_APP_INFO]
        then:
        stAppStatusMsg == 'SUCCESS'
        stAppInfo == 'sor_name = BLS AND parent_child_ind = C. No need to PUT a message on G2 Queue. Returning SUCCESS'
    }

    def "mq to ldap returns success member state is reserved"() {
        given:
        member['member_state'] = 'RES'
        member['sor_name'] = 'NOTCOLA'
        HashMap<String, Object> result = g2LDAPHelper.mqToLdap(input, member)
        stAppStatusMsg = (String) result[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) result[CommonDefs.COMMON_APP_INFO]
        then:
        stAppStatusMsg == 'SUCCESS'
        stAppInfo == 'RESERVED user should not go to LDAP....... Returning SUCCESS'
    }

    def "mq to ldap returns s u c c e s s"() {
        given:
        member['sor_name'] = 'restrictedSor'
        hmLDAPValidatorResp['appStatusCode'] = '0'
        hmLDAPValidatorResp['retCode'] = '0'
        hmLDAPValidatorResp['guserid'] = 'testuser'
        hmLDAPValidatorResp['gdomain'] = 'testdomain'
        hmLDAPValidatorResp['SyncG2'] = 'Sync'
        hmLDAPValidatorResp['gassociateddomain'] = 'LS'
        hmLDAPValidatorResp['dslam_type'] = 'DSLAM'
        hmLDAPValidatorResp['parent_child_ind'] = 'P'

        HashMap hmResponse  = new HashMap()
        hmResponse[hmLDAPValidatorResp] = hmLDAPValidatorResp
        oLDAPValidator.validate(_,_,_) >> hmLDAPValidatorResp

        HashMap<String, Object> result = g2LDAPHelper.mqToLdap(input, member)
        stAppStatusMsg = (String) result[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) result[CommonDefs.COMMON_APP_INFO]

        then:
        stAppStatusMsg == 'SUCCESS'
    }

    def "mq to ldap returns s u c c e s s when domain l s"() {
        given:
        member['sor_name'] = 'restrictedSor'
        hmLDAPValidatorResp['appStatusCode'] = '0'
        hmLDAPValidatorResp['retCode'] = '0'
        hmLDAPValidatorResp['guserid'] = 'testuser'
        hmLDAPValidatorResp['gdomain'] = 'testdomain'
        hmLDAPValidatorResp['SyncG2'] = 'Sync1'
        hmLDAPValidatorResp['gassociateddomain'] = 'LS'
        hmLDAPValidatorResp['dslam_type'] = 'IP'
        hmLDAPValidatorResp['parent_child_ind'] = 'P'

        HashMap hmResponse  = new HashMap()
        hmResponse[hmLDAPValidatorResp] = hmLDAPValidatorResp
        oLDAPValidator.validate(_,_,_) >> hmLDAPValidatorResp

        HashMap<String, Object> result = g2LDAPHelper.mqToLdap(input, member)
        stAppStatusMsg = (String) result[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) result[CommonDefs.COMMON_APP_INFO]

        then:
        stAppStatusMsg == 'SUCCESS'
    }

    def "mq to ldap returns s u c c e s s when domain b l s"() {
        given:
        member['sor_name'] = 'restrictedSor'
        hmLDAPValidatorResp['appStatusCode'] = '0'
        hmLDAPValidatorResp['retCode'] = '0'
        hmLDAPValidatorResp['guserid'] = 'testuser'
        hmLDAPValidatorResp['gdomain'] = 'testdomain'
        hmLDAPValidatorResp['SyncG2'] = 'Sync2'
        hmLDAPValidatorResp['gassociateddomain'] = 'BLS'
        hmLDAPValidatorResp['dslam_type'] = 'DSLM'
        hmLDAPValidatorResp['parent_child_ind'] = 'C'
        hmLDAPValidatorResp['deleting'] = 'true'

        HashMap hmResponse  = new HashMap()
        hmResponse[hmLDAPValidatorResp] = hmLDAPValidatorResp
        oLDAPValidator.validate(_,_,_) >> hmLDAPValidatorResp

        HashMap<String, Object> result = g2LDAPHelper.mqToLdap(input, member)
        stAppStatusMsg = (String) result[CommonDefs.COMMON_APP_STATUS_MSG]
        when:
        stAppInfo = (String) result[CommonDefs.COMMON_APP_INFO]
        then:
        stAppStatusMsg == 'SUCCESS'
    }

    def "mq to ldap returns success when services are null"() {
        given:
        HashMap<String, Object> member = new HashMap<>()
        member['sor_name'] = 'restrictedSor'
        hmLDAPValidatorResp['appStatusCode'] = '1'
        hmLDAPValidatorResp['retCode'] = '1'
        oLDAPValidator.validate(_,_,_) >> hmLDAPValidatorResp
        HashMap<String, Object> result = g2LDAPHelper.mqToLdap(input, member)
        when:
        stAppStatusMsg = (String) result[CommonDefs.COMMON_APP_STATUS_CODE]
        then:
        stAppStatusMsg == '1'
    }

    def "test doldap returns system error"() {
        given:
        HashMap<String, Object> input = new HashMap<>()
        HashMap<String, Object> member = new HashMap<>()
        String sG2LDAPRestrictedSor= null
        String stG2BlockDomains = 'portal.att.net|myacount.bellsouth.net|attworld.com|slid.dum|foreign.dum'
        String sNonLDAPServices = 'IPTV|ECOMM|VOIP|YPAGES|PORTAL|ISS|MOSUB|AAB|UVERSE|FULCRUM|TITAN|XDCP|MAINUVERSE|MOBILITY|DLIFE|XANBOO|NEWSROOM|DLIFELIGHT'

        when:
        HashMap<String, Object> result = g2LDAPHelper.mqToLdap(input, member)
        stAppInfo = (String) result[CommonDefs.COMMON_APP_INFO]
        then:
        stAppInfo == 'SYSTEM ERROR'
    }

    @Unroll
    def "should return config error when config values are missing for #scenarioName"() {
        given: "Input and member maps with missing config"
        HashMap input = new HashMap()
        HashMap member = new HashMap()
        ReflectionTestUtils.setField(g2LDAPHelper, "g2BlockDomains", blockDomains)
        ReflectionTestUtils.setField(g2LDAPHelper, "g2LdapRestrictedSor", restrictedSor)
        ReflectionTestUtils.setField(g2LDAPHelper, "nonLdapServices", nonLdapServices)
        when: "mqToLdap is called"
        HashMap result = g2LDAPHelper.mqToLdap(input, member)

        then:
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_CONFIG_NUM.toString()
        result.get(CErrorDefs.COMMON_APP_INFO) == "Config value is missing"

        where:
        scenarioName              | blockDomains | restrictedSor | nonLdapServices
        "all null"                | null         | null          | null
        "blockDomains missing"    | null         | "A"           | "B"
        "restrictedSor missing"   | "A"          | null          | "B"
        "nonLdapServices missing" | "A"          | "B"           | null
        "all empty"               | ""           | ""            | ""
    }

    @Unroll
    def "should return success and skip LDAP when doldap returns false for #scenarioName"() {
        given: "Input and member maps, and PropertyManager configured to skip LDAP"
        HashMap input = new HashMap()
        HashMap member = new HashMap()
        ReflectionTestUtils.setField(g2LDAPHelper, "g2BlockDomains", "A|B|C")
        ReflectionTestUtils.setField(g2LDAPHelper, "g2LdapRestrictedSor", "X|Y|Z")
        ReflectionTestUtils.setField(g2LDAPHelper, "nonLdapServices", "S1|S2")
        ReflectionTestUtils.setField(g2LDAPHelper, "skipLdap", skipLdapValue)

        when: "mqToLdap is called"
        HashMap result = g2LDAPHelper.mqToLdap(input, member)

        then:
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.COMMON_SUCCESS

        where: "Different skipLdap values are tested"
        scenarioName      | skipLdapValue
        "lowercase y"     | "y"
        "uppercase Y"     | "Y"
        "Y with trailing" | "Yes"
    }

    @Unroll
    def "should return error when guserid or gdomain is missing for #scenarioName"() {
        given: "A HashMap missing guserid or gdomain"
        HashMap inputToDbus = new HashMap()
        if (hasUserId) inputToDbus.put(MPSDefs.G2_USERID, "1020445950")
        if (hasDomain) inputToDbus.put(MPSDefs.G2_DOMAIN, "att.net")

        when: "callDbusForG2Queue is called"
        HashMap result = g2LDAPHelper.callDbusForG2Queue(inputToDbus)

        then:
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_INVALID_DATA_NUM.toString()
        result.get(CErrorDefs.COMMON_APP_INFO) == "guserid or gdomain is missing in InputToDbus hash"

        where: "Different missing key scenarios"
        scenarioName      | hasUserId | hasDomain
        "missing both"    | false     | false
        "missing guserid" | false     | true
        "missing gdomain" | true      | false
    }

    @Unroll
    def "should return error when gclassofservice is missing and gaccessenabled is true for #scenarioName"() {
        given: "A HashMap with gaccessenabled true and no gclassofservice"
        HashMap inputToDbus = new HashMap()
        inputToDbus.put(MPSDefs.G2_USERID, "1020445950")
        inputToDbus.put(MPSDefs.G2_DOMAIN, "att.net")
        inputToDbus.put(MPSDefs.G2_ACCESSENABLED, CommonDefs.DEFAULT_TRUE)
        if (hasDeleting) inputToDbus.put(MPSDefs.DELETING, "true")

        when: "callDbusForG2Queue is called"
        HashMap result = g2LDAPHelper.callDbusForG2Queue(inputToDbus)

        then:
        result.get(CErrorDefs.COMMON_APP_STATUS_CODE) == CErrorDefs.ERR_INVALID_DATA_NUM.toString()
        result.get(CErrorDefs.COMMON_APP_INFO) == "gclassofservice is not present in InputToDbus hash"

        where: "Different deleting flag scenarios"
        scenarioName      | hasDeleting
        "no deleting key" | false
    }

    def "mqToLdap returns success when all services are non LDAP"() {
        given:
        ReflectionTestUtils.setField(g2LDAPHelper, "g2BlockDomains", "A|B")
        ReflectionTestUtils.setField(g2LDAPHelper, "g2LdapRestrictedSor", "X")
        // include key name "services" so areNonLdapServices returns true
        ReflectionTestUtils.setField(g2LDAPHelper, "nonLdapServices", "services")
        ReflectionTestUtils.setField(g2LDAPHelper, "skipLdap", "N")

        HashMap<String, Object> localInput = new HashMap<>()
        HashMap<String, Object> localMember = new HashMap<>()
        localMember[MPSDefs.DB_DOMAIN_NAME] = "domain"
        localMember[MPSDefs.DB_SOR_NAME] = "Y"
        localMember[MPSDefs.DB_MEMBER_STATE] = "ACTIVE"
        localMember[MPSDefs.SERVICES] = new HashMap<>()

        when:
        Map<String, Object> result = g2LDAPHelper.mqToLdap(localInput, localMember)

        then:
        result.get(CommonDefs.COMMON_APP_STATUS_CODE) == CommonDefs.COMMON_SUCCESS_NUM.toString()
        result.get(CommonDefs.COMMON_APP_INFO) == "MPS DB services are Non LDAP services. No need to call LDAP. Return Success"
    }

    def "callDbusForG2Queue sync LS or IP non-deleting sets G2LSmoduserEvent with subevent"() {
        given:
        HashMap inputToDbus = new HashMap()
        inputToDbus[MPSDefs.MPSTRANSID] = "TXN1"
        inputToDbus[MPSDefs.G2_USERID] = "user1"
        inputToDbus[MPSDefs.G2_DOMAIN] = "att.net"
        inputToDbus["SyncG2"] = "Sync"
        inputToDbus[MPSDefs.G2_ASSOCIATEDDOMAIN] = MPSDefs.SOR_LS
        inputToDbus[MPSDefs.DB_DSLAM_TYPE] = MPSDefs.IP
        inputToDbus[MPSDefs.G2_ACCESSENABLED] = "N"

        when:
        Map<String, Object> result = g2LDAPHelper.callDbusForG2Queue(inputToDbus)

        then:
        Map<String, Object> consolidated = (Map<String, Object>) result.get(CommonDefs.CONSOLIDATED_DBUS_INPUT)
        consolidated.get(CommonDefs.EVENTNAME) == "G2LSmoduserEvent"
        consolidated.containsKey(CommonDefs.SUBEVENT)
        consolidated.get(CommonDefs.TRANSACTION_ID) == "TXN1"
        !consolidated.containsKey(MPSDefs.DB_DSLAM_TYPE)
        !consolidated.containsKey(MPSDefs.DB_PARENT_CHILD_IND)
        !consolidated.containsKey("SyncG2")
    }

    def "callDbusForG2Queue sync non LS IP deleting sets G2DSLdeluserEvent"() {
        given:
        HashMap inputToDbus = new HashMap()
        inputToDbus[MPSDefs.MPSTRANSID] = "TXN2"
        inputToDbus[MPSDefs.G2_USERID] = "user2"
        inputToDbus[MPSDefs.G2_DOMAIN] = "att.net"
        inputToDbus["SyncG2"] = "Sync"
        inputToDbus[MPSDefs.DB_DSLAM_TYPE] = "OTHER"
        inputToDbus[MPSDefs.DELETING] = "true"
        inputToDbus[MPSDefs.G2_ACCESSENABLED] = "N"

        when:
        Map<String, Object> result = g2LDAPHelper.callDbusForG2Queue(inputToDbus)

        then:
        Map<String, Object> consolidated = (Map<String, Object>) result.get(CommonDefs.CONSOLIDATED_DBUS_INPUT)
        consolidated.get(CommonDefs.EVENTNAME) == "G2DSLdeluserEvent"
        consolidated.containsKey(CommonDefs.SUBEVENT)
    }

    def "callDbusForG2Queue non-sync LS parent uses LSLDAP subevent"() {
        given:
        HashMap inputToDbus = new HashMap()
        inputToDbus[MPSDefs.MPSTRANSID] = "TXN3"
        inputToDbus[MPSDefs.G2_USERID] = "user3"
        inputToDbus[MPSDefs.G2_DOMAIN] = "att.net"
        inputToDbus["SyncG2"] = "Sync"
        inputToDbus[MPSDefs.G2_ASSOCIATEDDOMAIN] = MPSDefs.SOR_LS
        inputToDbus[MPSDefs.DB_PARENT_CHILD_IND] = MPSDefs.MPS_PARENT
        inputToDbus[MPSDefs.G2_ACCESSENABLED] = "N"

        when:
        Map<String, Object> result = g2LDAPHelper.callDbusForG2Queue(inputToDbus)

        then:
        Map<String, Object> consolidated = (Map<String, Object>) result.get(CommonDefs.CONSOLIDATED_DBUS_INPUT)
        consolidated.get(CommonDefs.EVENTNAME) == "G2LSmoduserEvent"
        consolidated.get(CommonDefs.SUBEVENT) == "LSLDAP"
    }

    def "callDbusForG2Queue non-sync LS child uses LSSUBLDAP subevent"() {
        given:
        HashMap inputToDbus = new HashMap()
        inputToDbus[MPSDefs.MPSTRANSID] = "TXN4"
        inputToDbus[MPSDefs.G2_USERID] = "user4"
        inputToDbus[MPSDefs.G2_DOMAIN] = "att.net"
        inputToDbus["SyncG2"] = "Sync"
        inputToDbus[MPSDefs.G2_ASSOCIATEDDOMAIN] = MPSDefs.SOR_LS
        inputToDbus[MPSDefs.DB_PARENT_CHILD_IND] = MPSDefs.MPS_CHILD
        inputToDbus[MPSDefs.G2_ACCESSENABLED] = "N"

        when:
        Map<String, Object> result = g2LDAPHelper.callDbusForG2Queue(inputToDbus)

        then:
        Map<String, Object> consolidated = (Map<String, Object>) result.get(CommonDefs.CONSOLIDATED_DBUS_INPUT)
        consolidated.get(CommonDefs.EVENTNAME) == "G2LSmoduserEvent"
        consolidated.get(CommonDefs.SUBEVENT) == "LSSUBLDAP"
    }

    def "callDbusForG2Queue non-sync BLS uses BLSLDAP subevent"() {
        given:
        HashMap inputToDbus = new HashMap()
        inputToDbus[MPSDefs.MPSTRANSID] = "TXN5"
        inputToDbus[MPSDefs.G2_USERID] = "user5"
        inputToDbus[MPSDefs.G2_DOMAIN] = "att.net"
        inputToDbus["SyncG2"] = "Sync"
        inputToDbus[MPSDefs.G2_ASSOCIATEDDOMAIN] = MPSDefs.SOR_BLS
        inputToDbus[MPSDefs.G2_ACCESSENABLED] = "N"

        when:
        Map<String, Object> result = g2LDAPHelper.callDbusForG2Queue(inputToDbus)

        then:
        Map<String, Object> consolidated = (Map<String, Object>) result.get(CommonDefs.CONSOLIDATED_DBUS_INPUT)
        consolidated.get(CommonDefs.EVENTNAME) == "G2DSLmoduserEvent"
        consolidated.get(CommonDefs.SUBEVENT) == "BLSLDAP"
    }

    def "callDbusForG2Queue non-sync non BLS uses LDAP subevent"() {
        given:
        HashMap inputToDbus = new HashMap()
        inputToDbus[MPSDefs.MPSTRANSID] = "TXN6"
        inputToDbus[MPSDefs.G2_USERID] = "user6"
        inputToDbus[MPSDefs.G2_DOMAIN] = "att.net"
        inputToDbus["SyncG2"] = "Sync"
        inputToDbus[MPSDefs.G2_ASSOCIATEDDOMAIN] = "OTHER"
        inputToDbus[MPSDefs.G2_ACCESSENABLED] = "N"

        when:
        Map<String, Object> result = g2LDAPHelper.callDbusForG2Queue(inputToDbus)

        then:
        Map<String, Object> consolidated = (Map<String, Object>) result.get(CommonDefs.CONSOLIDATED_DBUS_INPUT)
        consolidated.get(CommonDefs.EVENTNAME) == "G2DSLmoduserEvent"
        consolidated.get(CommonDefs.SUBEVENT) == "LDAP"
    }
    def "mqToLdap returns exception map when LDAPValidator throws exception"() {
        given:
        HashMap input = new HashMap()
        HashMap member = new HashMap()
        // minimal member so validatePreconditions() does not short-circuit
        member[MPSDefs.DB_DOMAIN_NAME] = "att.net"
        member[MPSDefs.DB_SOR_NAME] = "SOME_SOR"
        member[MPSDefs.DB_MEMBER_STATE] = "ACTIVE"

        RuntimeException validatorException = new RuntimeException("LDAP failure")

        // configure the mock to throw when validate is called
        oLDAPValidator.validate(_, _, _) >> { throw validatorException }

        when:
        Boolean doldap = g2LDAPHelper.doldap()

        then: "Exception path in mqToLdap catch block is used"
        def exceptionMap = g2LDAPHelper.mqToLdap(input, member)
        exceptionMap == CommonErrorMap.makeCategoryMap(CErrorDefs.ERR_SYS_APPL_NUM, "Exception :LDAP failure")
    }

}