package com.att.idp.component

import org.hamcrest.CoreMatchers

/**
 * Component test for POST /autoreg/tempAccessId endpoint.
 *
 * Dependency chain:
 *   AutoRegResourceImpl (INTERNAL — real)
 *     ├── AutoGenTempAIDRequestValidator (INTERNAL — real)
 *     └── AutoGenTempAIDServiceImpl (INTERNAL — real)
 *          └── AutoGenTempAIDHelper (INTERNAL — real)
 *               ├── UserProfileAutoregUtility (INTERNAL — real)
 *               │    ├── MPSYSInternalRestClient (EXTERNAL — mock)
 *               │    └── RILCheckAndEncryptPasswordHelper (INTERNAL — real, uses EncryptUtil from CompTestBase)
 *               └── AccountAutoRegDBHelper (EXTERNAL — mock)
 */
class AutoGenTempAIDCompTest extends CompTestBase {

    private String uri = '/autoreg/tempAccessId'

    private Map<String, String> validHeaders() {
        [
            'Content-Type' : 'application/json',
            'X-ATT-ClientId': 'IDP',
            'idp-trace-id' : 'trace123:trace123:0:0'
        ]
    }

    private String validRequest() {
        '{"contactEmail":"test@att.com","firstName":"Joe","lastName":"Taft","agentId":"1321","contactEmailRTValidFlag":"Y","isExternalCall":"N"}'
    }

    // ========== Validation Error Scenarios ==========
    // NOTE: 'missing idp-trace-id' is not testable at CT level — SDK auto-generates trace IDs via CommonUtil.getTraceId()

    def "missing X-ATT-ClientId returns 400"() {
        given:
        Map<String, String> headers = [
            'Content-Type' : 'application/json',
            'idp-trace-id' : 'trace123:trace123:0:0'
        ]

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .body(validRequest())
                .when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then()
                .body('appStatusCode', CoreMatchers.equalTo('100'))
                .body('appInfo', CoreMatchers.containsString('Missing or invalid X-ATT-ClientId'))
    }

    def "missing contactEmail and firstName returns 400"() {
        given:
        def headers = validHeaders()
        String req = '{"lastName":"Taft","isExternalCall":"N"}'

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .body(req)
                .when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then()
                .body('appStatusCode', CoreMatchers.equalTo('100'))
                .body('appInfo', CoreMatchers.containsString('One of the input FirstName/LastName or ContactEmail must be present'))
    }

    def "invalid isExternalCall returns 400"() {
        given:
        def headers = validHeaders()
        String req = '{"contactEmail":"test@att.com","firstName":"Joe","lastName":"Taft","isExternalCall":"X"}'

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .body(req)
                .when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then()
                .body('appStatusCode', CoreMatchers.equalTo('100'))
                .body('appInfo', CoreMatchers.containsString('isExternalCall must be one of Y or N'))
    }

    def "invalid contactEmailRTValidFlag returns 400"() {
        given:
        def headers = validHeaders()
        String req = '{"contactEmail":"test@att.com","firstName":"Joe","lastName":"Taft","contactEmailRTValidFlag":"X","isExternalCall":"N"}'

        when:
        def response = givenBaseSpec()
                .headers(headers)
                .body(req)
                .when().post(uri)

        then:
        0 * _

        and:
        response.statusCode() == 400
        response.then()
                .body('appStatusCode', CoreMatchers.equalTo('100'))
                .body('appInfo', CoreMatchers.containsString('contactEmailRTValidFlag must be one of Y or N'))
    }

    // TECH_DEBT: MISSING_TEST — Success path CT not feasible. The AutoGen flow traverses
    // ResourceImpl → ServiceImpl → Helper → UserProfileAutoregUtility → internalIDPRestClient
    // with 2 separate REST calls (CheckUserIdAvailability + AddUser) through the same mock,
    // each requiring different response structures (suggestList vs success map).
    // Success path is covered by unit tests: AutoGenTempAIDHelperTest, UserProfileAutoregUtilityTest.
}
