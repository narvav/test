package com.att.idp.QAIntegration.Report

import com.aventstack.extentreports.ExtentReports
import com.aventstack.extentreports.ExtentTest
import com.aventstack.extentreports.reporter.ExtentSparkReporter
import com.aventstack.extentreports.reporter.configuration.Theme
import groovy.json.JsonOutput
import groovy.util.logging.Slf4j
import org.spockframework.runtime.IRunListener
import org.spockframework.runtime.extension.IGlobalExtension
import org.spockframework.runtime.model.ErrorInfo
import org.spockframework.runtime.model.FeatureInfo
import org.spockframework.runtime.model.IterationInfo
import org.spockframework.runtime.model.SpecInfo

import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Spock IGlobalExtension that integrates ExtentReports 5.x into the
 * IDGraphUserRegistrationMs QG7 integration test run.
 */
@Slf4j
class QG7ExtentReportListener implements IGlobalExtension {

    private static final String REPORT_DIR         = "target/SparkReport"
    private static final String REPORT_FILE        = "${REPORT_DIR}/UserRegistrationMs-QG7-Report.html"
    private static final String CUSTOM_REPORT_DIR  = "target/CustomReport"
    private static final String CUSTOM_REPORT_FILE = "${CUSTOM_REPORT_DIR}/Email.html"
    private static final String SUMMARY_JSON       = "target/qg7-test-results-summary.json"

    private static ExtentReports extentReports
    private static final ThreadLocal<ExtentTest> currentTest   = new ThreadLocal<>()
    private static final ThreadLocal<ExtentTest> specLevelTest = new ThreadLocal<>()
    private static final AtomicBoolean active = new AtomicBoolean(false)

    private static final QG7TestResultCollector collector = QG7TestResultCollector.getInstance()

    static ExtentTest getCurrent() { currentTest.get() ?: specLevelTest.get() }

    @Override
    void start() {
        active.set(true)
        collector.reset()
        collector.startTimeMs = System.currentTimeMillis()

        try {
            new File(REPORT_DIR).mkdirs()
            extentReports = new ExtentReports()

            ExtentSparkReporter spark = new ExtentSparkReporter(REPORT_FILE)
            spark.config().setTheme(Theme.STANDARD)
            spark.config().setDocumentTitle("IDGraphUserRegistrationMs — QG7 Integration Report")
            spark.config().setReportName("IDGraphUserRegistrationMs QG7 Integration Tests")
            spark.config().setEncoding("UTF-8")
            spark.config().setTimeStampFormat("MMM dd, yyyy HH:mm:ss a")

            try { spark.config().setTimelineEnabled(true) } catch (Exception ignored) {}
            try { spark.config().setCss(CUSTOM_CSS)       } catch (Exception ignored) {}
            try { spark.config().setJs(CUSTOM_JS)         } catch (Exception ignored) {}

            extentReports.attachReporter(spark)
            extentReports.setSystemInfo("Service",      "IDGraphUserRegistrationMs")
            extentReports.setSystemInfo("Environment",  collector.getEnvironment())
            extentReports.setSystemInfo("Framework",    "Spock 2.3 + Groovy 4.0")
            extentReports.setSystemInfo("Java Version", System.getProperty("java.version"))
            extentReports.setSystemInfo("Run Date",     new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss z").format(new Date()))
            log.info("QG7ExtentReportListener started — report will be written to: {}", new File(REPORT_FILE).absolutePath)
        } catch (Exception e) {
            log.error("QG7ExtentReportListener start() failed: {}", e.message, e)
        }
    }

    @Override
    void visitSpec(SpecInfo spec) {
        if (!active.get() || extentReports == null) return
        spec.addListener(new QG7SpecRunListener())
    }

    @Override
    void stop() {
        if (!active.get()) return
        try {
            extentReports?.flush()
            log.info("QG7 Extent report written → {}", new File(REPORT_FILE).absolutePath)
        } catch (Exception e) {
            log.error("Failed to flush ExtentReports: {}", e.message)
        }
        collector.endTimeMs = System.currentTimeMillis()

        writeTestSummaryJson()
        generateCustomHtmlReport()

        println ""
        println "══════════════════════════════════════════════════════════════════"
        println "  UserRegistrationMs QG7 Reports"
        println "  Spark  → ${new File(REPORT_FILE).absolutePath}"
        println "  Custom → ${new File(CUSTOM_REPORT_FILE).absolutePath}"
        println "  JSON   → ${new File(SUMMARY_JSON).absolutePath}"
        println "══════════════════════════════════════════════════════════════════"
        println ""
    }

    private static void writeTestSummaryJson() {
        try {
            Map<String, Object> data = [:]
            Map<String, Map<String, Integer>> specs = [:]
            collector.specTotal.each { String spec, val ->
                specs[spec] = [
                        total  : val.get(),
                        passed : collector.specPassed.getOrDefault(spec, new AtomicInteger(0)).get(),
                        failed : collector.specFailed.getOrDefault(spec, new AtomicInteger(0)).get(),
                        skipped: collector.specSkipped.getOrDefault(spec, new AtomicInteger(0)).get()
                ]
            }
            data.specs = specs
            data.overall = [
                    total  : collector.totalTests.get(),
                    passed : collector.passedTests.get(),
                    failed : collector.failedTests.get(),
                    skipped: collector.skippedTests.get()
            ]
            data.failedTests = collector.failedFlows.collect { [spec: it.spec, feature: it.feature, error: it.error] }
            Map<String, Integer> srvErrors = [:]
            collector.getServerErrorsByEndpoint().each { Map<String, Object> e ->
                srvErrors[(String) e.endpoint] = e.count as int
            }
            data.serverErrors  = srvErrors
            data.environment   = collector.getEnvironment()
            data.duration      = collector.getDuration()
            data.passRate      = String.format("%.1f", collector.getPassRate())
            data.githubRunUrl  = collector.getGitHubRunUrl()
            data.githubRun     = collector.getGitHubRunNumber()
            data.githubActor   = collector.getGitHubActor()
            data.githubWorkflow = collector.getGitHubWorkflow()

            File outFile = new File(SUMMARY_JSON)
            outFile.text = JsonOutput.prettyPrint(JsonOutput.toJson(data))
            log.info("QG7 test summary written → {}", outFile.absolutePath)
        } catch (Exception e) {
            log.warn("Failed to write QG7 test summary: {}", e.message)
        }
    }

    private static void generateCustomHtmlReport() {
        try {
            new File(CUSTOM_REPORT_DIR).mkdirs()
            String html = QG7EmailReportBuilder.build(collector)
            File outFile = new File(CUSTOM_REPORT_FILE)
            outFile.text = html
            log.info("QG7 custom HTML report written → {}", outFile.absolutePath)
        } catch (Exception e) {
            log.warn("Failed to generate custom HTML report: {}", e.message)
        }
    }

    private static class QG7SpecRunListener implements IRunListener {

        private boolean iterationFailed
        private String  currentSpecName
        private String  currentFeatureName
        private String  currentIterationError

        @Override
        void beforeSpec(SpecInfo spec) {
            currentSpecName = spec.name
            if (extentReports == null) return
            synchronized (extentReports) {
                ExtentTest st = extentReports.createTest(spec.name).assignCategory("QG7-Integration")
                specLevelTest.set(st)
                currentTest.set(st)
            }
        }

        @Override
        void beforeFeature(FeatureInfo feature) {
            currentFeatureName = feature.name
            if (feature.isSkipped()) {
                collector.recordSkip(currentSpecName, feature.name)
                if (extentReports != null) {
                    synchronized (extentReports) {
                        specLevelTest.get()?.createNode(feature.name)?.skip("Feature skipped")
                    }
                }
            }
        }

        @Override
        void beforeIteration(IterationInfo iteration) {
            iterationFailed = false
            currentIterationError = null
            String iterName = safeIterName(iteration)
            if (extentReports != null) {
                synchronized (extentReports) {
                    ExtentTest node = specLevelTest.get()?.createNode(iterName)
                    currentTest.set(node)
                }
            }
        }

        @Override
        void afterIteration(IterationInfo iteration) {
            String iterName = safeIterName(iteration)
            if (!iterationFailed) {
                currentTest.get()?.pass("Test passed")
                collector.recordPass(currentSpecName, iterName)
            } else {
                collector.recordFail(currentSpecName, iterName, currentIterationError)
            }
            currentTest.set(specLevelTest.get())
        }

        @Override
        void afterFeature(FeatureInfo feature) {}

        @Override
        void afterSpec(SpecInfo spec) {
            currentTest.remove()
            specLevelTest.remove()
        }

        @Override
        void error(ErrorInfo error) {
            iterationFailed = true
            currentIterationError = error.exception?.toString()
            currentTest.get()?.fail(error.exception)
        }

        @Override
        void specSkipped(SpecInfo spec) {
            collector.recordSkip(spec.name, "(entire spec)")
            if (extentReports != null) {
                synchronized (extentReports) {
                    extentReports.createTest(spec.name).assignCategory("QG7-Integration").skip("Spec skipped")
                }
            }
        }

        @Override
        void featureSkipped(FeatureInfo feature) {
            collector.recordSkip(currentSpecName, feature.name)
            if (extentReports != null) {
                synchronized (extentReports) {
                    specLevelTest.get()?.createNode(feature.name)?.skip("Feature skipped")
                }
            }
        }

        private static String safeIterName(IterationInfo iteration) {
            try { return iteration.displayName ?: iteration.name ?: "Test" } catch (ignored) { return "Test" }
        }
    }

    private static final String CUSTOM_CSS = '''
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    body, .side-nav, .test-content, .card { font-family: 'Inter', 'Segoe UI', -apple-system, sans-serif !important; }
    .navbar { background: linear-gradient(135deg, #0d47a1 0%, #1565c0 50%, #1976d2 100%) !important; box-shadow: 0 4px 20px rgba(13,71,161,.3) !important; }
    .side-nav { background: #fafbfc !important; border-right: 1px solid #e1e4e8 !important; }
    .side-nav li a { color: #2c3e50 !important; border-radius: 6px !important; margin: 2px 8px !important; transition: all .2s !important; }
    .side-nav li a:hover { background: #e3f2fd !important; color: #1565c0 !important; }
    .side-nav li.active > a { background: #1565c0 !important; color: #fff !important; }
    .dashboard-view .card { border: none !important; border-radius: 16px !important; box-shadow: 0 4px 16px rgba(0,0,0,.06) !important; transition: transform .25s, box-shadow .25s !important; }
    .dashboard-view .card:hover { transform: translateY(-4px) !important; box-shadow: 0 12px 32px rgba(0,0,0,.12) !important; }
    .badge-success,.badge.pass { background: linear-gradient(135deg,#00c853,#69f0ae) !important; color:#fff !important; font-weight:600 !important; border-radius:20px !important; padding:4px 14px !important; }
    .badge-danger,.badge.fail  { background: linear-gradient(135deg,#d50000,#ff5252) !important; color:#fff !important; font-weight:600 !important; border-radius:20px !important; padding:4px 14px !important; }
    .badge-warning,.badge.skip { background: linear-gradient(135deg,#ff6d00,#ffab40) !important; color:#fff !important; font-weight:600 !important; border-radius:20px !important; padding:4px 14px !important; }
    .node { border-left: 4px solid #1565c0 !important; margin: 10px 4px !important; padding: 14px 18px !important; border-radius: 0 10px 10px 0 !important; background: #f8f9fa !important; }
    .node.pass,.node.has-pass { border-left-color: #00c853 !important; }
    .node.fail,.node.has-fail { border-left-color: #d50000 !important; }
    pre { background: #f4f6f8 !important; border-radius: 8px !important; padding: 14px !important; border: 1px solid #e1e4e8 !important; font-size: .85rem !important; overflow-x: auto !important; }
    @keyframes fadeInUp { from { opacity:0; transform:translateY(14px); } to { opacity:1; transform:translateY(0); } }
    .test-detail { animation: fadeInUp .4s ease both; border-radius: 12px !important; border: 1px solid #e1e4e8 !important; box-shadow: 0 2px 8px rgba(0,0,0,.04) !important; }
    '''

    private static final String CUSTOM_JS = '''
    $(document).ready(function() {
        $("html").css("scroll-behavior","smooth");
        $(".test-detail").each(function(i){ $(this).css("animation-delay",(i*.06)+"s"); });
        $("pre").each(function(){
            var t=$(this).text().trim();
            if(t.startsWith("{") || t.startsWith("[")) $(this).css({"border-left":"4px solid #1565c0","background":"#f8f9fa"});
        });
    });
    '''
}
