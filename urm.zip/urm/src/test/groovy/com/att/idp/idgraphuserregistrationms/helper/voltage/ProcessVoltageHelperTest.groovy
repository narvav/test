package com.att.idp.idgraphuserregistrationms.helper.voltage

import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import spock.lang.Specification

class ProcessVoltageHelperTest extends Specification {

    def processVoltageHelper = new ProcessVoltageHelper()

    VoltageEncryptionHelper oVoltageEncryption_H = Mock(VoltageEncryptionHelper)

    public static final Logger logger = LoggerFactory.getLogger(VoltageEncryptionHelper.class)

    HashMap hmMemberInfo = null
    HashMap hmResponse = null

    def setup() throws Exception {

        processVoltageHelper.oVoltageEncryption_H = oVoltageEncryption_H
        System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')
        hmMemberInfo = new HashMap()
        hmResponse = new HashMap()
    }

    def "test voltage decrypt spi field shm member info null"() {
        when:
        HashMap<String, Object> hmResult =processVoltageHelper.voltageDecryptSPIFields(hmMemberInfo)
        then:
        hmResult['appInfo'] == 'hmMemberInfo is null or empty.'
    }

    def "test voltage decrypt spi field sif"() {
        given:
        hmMemberInfo[MPSDefs.DB_MD5_PASSWORD_VENC] = 'shebgfhbskegjn'
        hmMemberInfo[MPSDefs.DB_ENC_PASSWORD_VENC] = 'ajhsdbgh'
        hmMemberInfo[MPSDefs.DB_SHA1_PASSWORD_VENC] = 'jsdngjseng'
        hmMemberInfo[MPSDefs.DB_GEN_PASSWORD_VENC] = 'Nsdgsdg'
        hmMemberInfo[MPSDefs.DB_DES3_PASSWORD_VENC] = 'Nsdgg'
        hmMemberInfo[MPSDefs.DB_SSHA_PASSWORD_VENC] = '913478924'
        hmMemberInfo[MPSDefs.DB_SECURITY_ANSWER_1_VENC] = 'ieahfi'
        hmMemberInfo[MPSDefs.DB_SECURITY_ANSWER_2_VENC] = '8347883873'
        hmMemberInfo[MPSDefs.DB_PASSWORD_VENC] = 'N'
        hmMemberInfo[MPSDefs.PROP_GET_MEMBER_SPI] = 'N'
        hmResponse['fedTaxId'] = 'trma6f99'
        hmResponse[MPSDefs.DB_MD5_PASSWORD_VENC] = 'N'
        hmResponse[MPSDefs.DB_ENC_PASSWORD_VENC] = 'N'
        hmResponse[MPSDefs.DB_SHA1_PASSWORD_VENC] = 'N'
        hmResponse[MPSDefs.DB_GEN_PASSWORD_VENC] = 'N'
        hmResponse[MPSDefs.DB_DES3_PASSWORD_VENC] = 'N'
        hmResponse[MPSDefs.DB_SSHA_PASSWORD_VENC] = 'N'
        hmResponse[MPSDefs.DB_SECURITY_ANSWER_1_VENC] = 'N'
        hmResponse[MPSDefs.DB_SECURITY_ANSWER_2_VENC] = 'N'
        hmResponse[MPSDefs.DB_PASSWORD_VENC] = 'N'

        oVoltageEncryption_H.getEFPEDecryptedValues(_) >> hmResponse

        when:
        HashMap<String, Object> hmResult =processVoltageHelper.voltageDecryptSPIFields(hmMemberInfo)
        then:
        hmResult['appStatusMsg'] == 'SUCCESS'
    }

    def "test voltage decrypt spi fields app status code null"() {
        given:
        hmMemberInfo[MPSDefs.DB_MD5_PASSWORD_VENC] = 'shebgfhbskegjn'
        hmMemberInfo[MPSDefs.DB_ENC_PASSWORD_VENC] = 'ajhsdbgh'
        hmMemberInfo[MPSDefs.DB_SHA1_PASSWORD_VENC] = 'jsdngjseng'
        hmMemberInfo[MPSDefs.DB_GEN_PASSWORD_VENC] = 'Nsdgsdg'
        hmMemberInfo[MPSDefs.DB_DES3_PASSWORD_VENC] = 'Nsdgg'
        hmMemberInfo[MPSDefs.DB_SSHA_PASSWORD_VENC] = '913478924'
        hmMemberInfo[MPSDefs.DB_SECURITY_ANSWER_1_VENC] = 'ieahfi'
        hmMemberInfo[MPSDefs.DB_SECURITY_ANSWER_2_VENC] = '8347883873'
        hmMemberInfo[MPSDefs.DB_PASSWORD_VENC] = 'N'
        hmMemberInfo[MPSDefs.PROP_GET_MEMBER_SPI] = 'N'

        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] = '5384900'
        oVoltageEncryption_H.getEFPEDecryptedValues(_) >> hmResponse
        when:
        HashMap<String, Object> hmResult =processVoltageHelper.voltageDecryptSPIFields(hmMemberInfo)
        then:
        hmResult['appStatusCode'] == '5384900'
    }

    def "test voltage decrypt spi fields null exception"() {
        given:
        hmMemberInfo[MPSDefs.DB_MD5_PASSWORD_VENC] = 'shebgfhbskegjn'
        hmMemberInfo[MPSDefs.DB_ENC_PASSWORD_VENC] = 'ajhsdbgh'
        hmMemberInfo[MPSDefs.DB_SHA1_PASSWORD_VENC] = 'jsdngjseng'
        hmMemberInfo[MPSDefs.DB_GEN_PASSWORD_VENC] = 'Nsdgsdg'
        hmMemberInfo[MPSDefs.DB_DES3_PASSWORD_VENC] = 'Nsdgg'
        hmMemberInfo[MPSDefs.DB_SSHA_PASSWORD_VENC] = '913478924'
        hmMemberInfo[MPSDefs.DB_SECURITY_ANSWER_1_VENC] = 'ieahfi'
        hmMemberInfo[MPSDefs.DB_SECURITY_ANSWER_2_VENC] = '8347883873'
        hmMemberInfo[MPSDefs.DB_PASSWORD_VENC] = 'N'
        hmMemberInfo[MPSDefs.PROP_GET_MEMBER_SPI] = 'N'
        oVoltageEncryption_H.getEFPEDecryptedValues(_) >> NullPointerException.class
        when:
        HashMap<String, Object> hmResult =processVoltageHelper.voltageDecryptSPIFields(hmMemberInfo)
        then:
        hmResult['appStatusMsg'] == 'ERR_SYS_APPL'
    }

    def "test voltage decrypt spi fields hm response null"() {
        given:
        hmMemberInfo['oisnco'] = 'jbiubiu'
        when:
        HashMap<String, Object> hmResult =processVoltageHelper.voltageDecryptSPIFields(hmMemberInfo)
        then:
        hmResult['appStatusCode'] == '602'
    }

    def "test voltage encrypt spi fields hm member info null"() {
        when:
        HashMap<String, Object> hmResult =processVoltageHelper.voltageEncryptSPIFields(hmMemberInfo)
        then:
        hmResult['appInfo'] == 'hmMemberInfo is null or empty.'
    }

    def "test voltage encrypt spi fields"() {
        given:
        hmMemberInfo[MPSDefs.DB_MD5_PASSWORD] = '2'
        hmMemberInfo[MPSDefs.DB_ENC_PASSWORD] = 'kuewghiewkbg'
        hmMemberInfo[MPSDefs.DB_SHA1_PASSWORD] = 'kefuhjf'
        hmMemberInfo[MPSDefs.DB_GEN_PASSWORD] = 'khvv'
        hmMemberInfo[MPSDefs.DB_DES3_PASSWORD] = '0976855'
        hmMemberInfo[MPSDefs.DB_SSHA_PASSWORD] = 'jhyv'
        hmMemberInfo[MPSDefs.DB_SECURITY_ANSWER_1] = 'SECURITY_ANSWER_1_VENC'
        hmMemberInfo[MPSDefs.DB_SECURITY_ANSWER_2] = 'SECURITY_ANSWER_2_VENC'

        hmResponse[MPSDefs.DB_MD5_PASSWORD_VENC] = 'N'
        hmResponse[MPSDefs.DB_ENC_PASSWORD_VENC] = 'N'
        hmResponse[MPSDefs.DB_SHA1_PASSWORD_VENC] = 'N'
        hmResponse[MPSDefs.DB_GEN_PASSWORD_VENC] = 'N'
        hmResponse[MPSDefs.DB_DES3_PASSWORD_VENC] = 'N'
        hmResponse[MPSDefs.DB_SSHA_PASSWORD_VENC] = 'N'
        hmResponse[MPSDefs.DB_SECURITY_ANSWER_1_VENC] = 'N'
        hmResponse[MPSDefs.DB_SECURITY_ANSWER_2_VENC] = 'N'
        hmResponse[MPSDefs.DB_PASSWORD_VENC] = 'N'

        oVoltageEncryption_H.getEFPEEncryptedValues(_) >> hmResponse

        when:
        HashMap<String, Object> hmResult =processVoltageHelper.voltageEncryptSPIFields(hmMemberInfo)
        then:
        hmResult['appStatusMsg'] == 'SUCCESS'
    }

    def "test voltage encrypt spi field sif"() {
        given:
        hmMemberInfo[MPSDefs.DB_MD5_PASSWORD] = '2'
        hmMemberInfo[MPSDefs.DB_ENC_PASSWORD] = 'kuewghiewkbg'
        hmMemberInfo[MPSDefs.DB_SHA1_PASSWORD] = 'kefuhjf'
        hmMemberInfo[MPSDefs.DB_GEN_PASSWORD] = 'khvv'
        hmMemberInfo[MPSDefs.DB_DES3_PASSWORD] = '0976855'
        hmMemberInfo[MPSDefs.DB_SSHA_PASSWORD] = 'jhyv'
        hmMemberInfo[MPSDefs.DB_SECURITY_ANSWER_1] = 'SECURITY_ANSWER_1_VENC'
        hmMemberInfo[MPSDefs.DB_SECURITY_ANSWER_2] = 'SECURITY_ANSWER_2_VENC'

        hmResponse['voltage_' + MPSDefs.DB_MD5_PASSWORD_VENC] = 'N'
        hmResponse['voltage_' + MPSDefs.DB_ENC_PASSWORD_VENC] = 'N'
        hmResponse['voltage_' + MPSDefs.DB_SHA1_PASSWORD_VENC] = 'N'
        hmResponse['voltage_' + MPSDefs.DB_GEN_PASSWORD_VENC] = 'N'
        hmResponse['voltage_' + MPSDefs.DB_DES3_PASSWORD_VENC] = 'N'
        hmResponse['voltage_' + MPSDefs.DB_SSHA_PASSWORD_VENC] = 'N'
        hmResponse['voltage_' + MPSDefs.DB_SECURITY_ANSWER_1_VENC] = 'N'
        hmResponse['voltage_' + MPSDefs.DB_SECURITY_ANSWER_2_VENC] = 'N'
        hmResponse['voltage_' + MPSDefs.DB_PASSWORD_VENC] = 'N'

        oVoltageEncryption_H.getEFPEEncryptedValues(_) >> hmResponse

        when:
        HashMap<String, Object> hmResult =processVoltageHelper.voltageEncryptSPIFields(hmMemberInfo)
        then:
        hmResult['appStatusMsg'] == 'SUCCESS'
    }

    def "test voltage decrypt spi fieldss app status code null"() {
        given:
        hmMemberInfo[MPSDefs.DB_MD5_PASSWORD] = '2'
        hmMemberInfo[MPSDefs.DB_ENC_PASSWORD] = 'kuewghiewkbg'
        hmMemberInfo[MPSDefs.DB_SHA1_PASSWORD] = 'kefuhjf'
        hmMemberInfo[MPSDefs.DB_GEN_PASSWORD] = 'khvv'
        hmMemberInfo[MPSDefs.DB_DES3_PASSWORD] = '0976855'
        hmMemberInfo[MPSDefs.DB_SSHA_PASSWORD] = 'jhyv'
        hmMemberInfo[MPSDefs.DB_SECURITY_ANSWER_1] = 'SECURITY_ANSWER_1_VENC'
        hmMemberInfo[MPSDefs.DB_SECURITY_ANSWER_2] = 'SECURITY_ANSWER_2_VENC'

        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] = '118'
        oVoltageEncryption_H.getEFPEEncryptedValues(_) >> hmResponse
        when:
        HashMap<String, Object> hmResult =processVoltageHelper.voltageEncryptSPIFields(hmMemberInfo)
        then:
        hmResult['appStatusCode'] == '118'
    }

    def "test voltage decrypt spi fields app status code exception"() {
        given:
        hmMemberInfo[MPSDefs.DB_MD5_PASSWORD] = '2'
        hmMemberInfo[MPSDefs.DB_ENC_PASSWORD] = 'kuewghiewkbg'
        hmMemberInfo[MPSDefs.DB_SHA1_PASSWORD] = 'kefuhjf'
        hmMemberInfo[MPSDefs.DB_GEN_PASSWORD] = 'khvv'
        hmMemberInfo[MPSDefs.DB_DES3_PASSWORD] = '0976855'
        hmMemberInfo[MPSDefs.DB_SSHA_PASSWORD] = 'jhyv'
        hmMemberInfo[MPSDefs.DB_SECURITY_ANSWER_1] = 'SECURITY_ANSWER_1_VENC'
        hmMemberInfo[MPSDefs.DB_SECURITY_ANSWER_2] = 'SECURITY_ANSWER_2_VENC'

        hmResponse[CommonDefs.COMMON_APP_STATUS_CODE] = '118'
        oVoltageEncryption_H.getEFPEEncryptedValues(_) >> NullPointerException.class
        when:
        HashMap<String, Object> hmResult =processVoltageHelper.voltageEncryptSPIFields(hmMemberInfo)
        then:
        hmResult['appStatusMsg'] == 'ERR_SYS_APPL'
    }

    def "test voltage encrypt spi field sm response null"() {
        given:
        hmMemberInfo['oisnco'] = 'jbiubiu'
        when:
        HashMap<String, Object> hmResult =processVoltageHelper.voltageEncryptSPIFields(hmMemberInfo)
        then:
        hmResult['appStatusCode'] == '602'
    }
}