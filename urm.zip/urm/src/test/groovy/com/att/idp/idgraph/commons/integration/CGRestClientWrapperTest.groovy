package com.att.idp.idgraph.commons.integration

import com.att.idp.cd.observability.metrics.annotation.TimedMetrics
import com.att.idp.cgclienthelpers.integration.CGRestClient
import spock.lang.Specification

import static com.att.idp.cd.observability.metrics.utils.Constants.METHOD
import static com.att.idp.cd.observability.metrics.utils.Constants.POST
import static com.att.idp.cd.observability.metrics.utils.Constants.REST_OB
import static com.att.idp.cd.observability.metrics.utils.Constants.URI
import static com.att.idp.idgraphuserregistrationms.utils.ProfileOrchestrationConstants.IDGRAPH_USERREGMS_OB

class CGRestClientWrapperTest extends Specification {

    CGRestClient cgRestClient = Mock(CGRestClient)
    CGRestClientWrapper wrapper

    def setup() {
        wrapper = new CGRestClientWrapper(cgRestClient)
    }

    def "getCGSyncCall delegates to CGRestClient and returns response"() {
        given:
        HashMap<String, Object> hmCGInput = new HashMap<>()
        hmCGInput.put("apiName", "CGCustomerSearch")
        hmCGInput.put("serviceType", "wireless")

        HashMap<String, Object> expectedResponse = new HashMap<>()
        expectedResponse.put("appStatusCode", "0")
        expectedResponse.put("appInfo", "Success")

        cgRestClient.getCGSyncCall(hmCGInput) >> expectedResponse

        when:
        def result = wrapper.getCGSyncCall(hmCGInput)

        then:
        result == expectedResponse
        result["appStatusCode"] == "0"
    }

    def "getCGSyncCall passes input unchanged to CGRestClient"() {
        given:
        HashMap<String, Object> hmCGInput = new HashMap<>()
        hmCGInput.put("ban", "VD0015088")
        hmCGInput.put("cgEndPoint", "/cg/customer/search")

        cgRestClient.getCGSyncCall(_) >> new HashMap<>()

        when:
        wrapper.getCGSyncCall(hmCGInput)

        then:
        1 * cgRestClient.getCGSyncCall({ HashMap<String, Object> input ->
            input["ban"] == "VD0015088" &&
            input["cgEndPoint"] == "/cg/customer/search"
        }) >> new HashMap<>()
        0 * _
    }

    def "getCGSyncCall returns null when CGRestClient returns null"() {
        given:
        HashMap<String, Object> hmCGInput = new HashMap<>()
        cgRestClient.getCGSyncCall(hmCGInput) >> null

        when:
        def result = wrapper.getCGSyncCall(hmCGInput)

        then:
        result == null
    }

    def "getCGSyncCall propagates IOException from CGRestClient"() {
        given:
        HashMap<String, Object> hmCGInput = new HashMap<>()
        cgRestClient.getCGSyncCall(hmCGInput) >> { throw new IOException("Connection refused") }

        when:
        wrapper.getCGSyncCall(hmCGInput)

        then:
        def ex = thrown(IOException)
        ex.message == "Connection refused"
    }

    def "getCGSyncCall propagates RuntimeException from CGRestClient"() {
        given:
        HashMap<String, Object> hmCGInput = new HashMap<>()
        cgRestClient.getCGSyncCall(hmCGInput) >> { throw new RuntimeException("Unexpected error") }

        when:
        wrapper.getCGSyncCall(hmCGInput)

        then:
        def ex = thrown(RuntimeException)
        ex.message == "Unexpected error"
    }

    def "getCGSyncCall handles empty input map"() {
        given:
        HashMap<String, Object> hmCGInput = new HashMap<>()
        HashMap<String, Object> expectedResponse = new HashMap<>()
        expectedResponse.put("appStatusCode", "602")

        cgRestClient.getCGSyncCall(hmCGInput) >> expectedResponse

        when:
        def result = wrapper.getCGSyncCall(hmCGInput)

        then:
        result["appStatusCode"] == "602"
    }

    def "getCGSyncCall method has @TimedMetrics annotation with correct attributes"() {
        when:
        def method = CGRestClientWrapper.getDeclaredMethod("getCGSyncCall", HashMap)
        def annotation = method.getAnnotation(TimedMetrics)

        then:
        annotation != null
        annotation.name() == IDGRAPH_USERREGMS_OB
        annotation.type() == REST_OB
        annotation.description() == "CG CustomerSearch outbound call"
        annotation.histogram() == true
        annotation.tags() == [com.att.idp.cd.observability.metrics.utils.Constants.URI, "/cg/customer/search", METHOD, POST] as String[]
    }
}
