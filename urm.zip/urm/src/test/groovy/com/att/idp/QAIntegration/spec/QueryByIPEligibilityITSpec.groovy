package com.att.idp.QAIntegration.spec

import com.att.idp.QAIntegration.Base.TestBase
import com.att.idp.QAIntegration.Config.GlobalConfig
import com.att.idp.QAIntegration.Helpers.ApiHelpers
import groovy.util.logging.Slf4j
import io.restassured.response.Response
import spock.lang.IgnoreIf
import spock.lang.Tag
import spock.lang.Unroll

@Slf4j
@Tag("Regression")
@Tag("IdGraphUserRegistrationMs")
@IgnoreIf({ !GlobalConfig.isTestCaseEnabled("QueryByIPEligibilityITSpec") })
class QueryByIPEligibilityITSpec extends TestBase {

    @Unroll
    def "QueryByIPEligibility negative - #scenario.name"() {
        setup:
        TestBase.setTestName("QueryByIPEligibility Negative — ${scenario.name}")
        TestBase.logStep("POST ${GlobalConfig.Endpoints.QUERY_BY_IP_ELIGIBILITY} — ${scenario.name}")

        Map<String, Object> payload = [:]
        if (scenario.ipAddress != null) payload.ipAddress = scenario.ipAddress

        when: "QueryByIPEligibility API is called with invalid parameters"
        Response response = ApiHelpers.queryByIPEligibility(payload, "IDP")

        then: "No mock interactions — real HTTP call"
        0 * _

        and: "API returns expected error response"
        def expectedStatuses = scenario.expectedStatus instanceof List ? scenario.expectedStatus : [scenario.expectedStatus]
        assert response.statusCode() in expectedStatuses :
                "Expected HTTP ${expectedStatuses} but got: ${response.statusCode()}"

        where:
        scenario << getNegativeScenarios()
    }

    static List getNegativeScenarios() {
        GlobalConfig.getTestData()?.queryByIPEligibility?.negative ?: []
    }
}
