package com.att.idp.idgraphuserregistrationms.helper.dbhelpers

import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import com.att.mpsys.common.utils.PropertyManager
import org.jboss.logging.MDC
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.jdbc.core.JdbcTemplate
import com.att.idp.idgraphuserregistrationms.metrics.ErrorMetricHandler
import spock.lang.Specification

class GetAllInfoDBHelperTest extends Specification {
	
	def mpsDB_GetAllInfo_Object = new GetAllInfoDBHelper()
	
	JdbcTemplate jdbcTemplate = Mock()
	ErrorMetricHandler errorMetricHandler = Mock(ErrorMetricHandler)

    Logger logger

    HashMap hmDBInput
    HashMap hmResposne
    List objectList = new ArrayList()
    List alQueryResponse = new ArrayList()
	
    def setup() throws Exception {
        PropertyManager.setProperty("MSCONFIG", "GENERIC_PASSWORD_ENCRYPTION_TYPE",null);
		mpsDB_GetAllInfo_Object.jdbcTemplate = jdbcTemplate
		mpsDB_GetAllInfo_Object.errorMetricHandler = errorMetricHandler
		logger = LoggerFactory.getLogger('CheckUserIdAvailability')
        MDC.put('transid', 'test123')
        System.setProperty('CommonConfigurationFilePath', './opt/ajsc/etc/config/CommonConfigurationTest.xml')
    }
    def cleanup() throws Exception {
	}
	
    def "success get info test case for handle and domain security all required"() {
        given:
        hmDBInput = new HashMap()

        hmDBInput[CommonDefs.TRANSACTION_NAME] = 'CheckUserIdAvailability'
        hmDBInput[MPSDefs.DB_MEMBER_NAME] = 'qayma0060805'
        hmDBInput[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        hmDBInput[MPSDefs.SECURITY_ALL_REQ] = 'Y'

        objectList.add('qayma0060805')
        objectList.add('slid.dum')

        HashMap dbResposne = new HashMap()

        dbResposne[MPSDefs.APP_STATUS_CODE] = MPSDefs.MPS_SUCCESS
        dbResposne[MPSDefs.APP_STATUS_MSG] = MPSDefs.MPS_ALL_OK
        dbResposne[MPSDefs.SQLCODE] = MPSDefs.SQL_SUCCESS
        dbResposne[MPSDefs.SQLMSG] = MPSDefs.SQL_SUCCESS_MSG
        dbResposne[MPSDefs.DB_MEMBER_NUM] = '1020371069'
        dbResposne[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        dbResposne[MPSDefs.DB_MEMBER_STATE] = 'RES'
        dbResposne[MPSDefs.DB_BAN] = '1020374553'
        dbResposne[MPSDefs.DB_SOR_NAME] = 'NA'
        dbResposne[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        dbResposne[MPSDefs.DB_ENC_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_MD5_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_SHA1_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_DES3_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_SSHA_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_GROUP_NUM] = '1020361572'
        dbResposne[MPSDefs.DB_DOMAIN_ID] = '15'
        dbResposne[MPSDefs.DB_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_PASSWORD_TYPE] = 'SSHA256'

        alQueryResponse.add(dbResposne)

		jdbcTemplate.queryForList( _,_) >> alQueryResponse

        when:
        hmResposne = mpsDB_GetAllInfo_Object.getInfo(hmDBInput)
        then:
        hmResposne[CommonDefs.COMMON_APP_STATUS_MSG] == 'OK'
    }

    def "success get info test case for handle and domain security question required"() {

        given:
        hmDBInput = new HashMap()

        hmDBInput[CommonDefs.TRANSACTION_NAME] = 'CheckUserIdAvailability'
        hmDBInput[MPSDefs.DB_MEMBER_NAME] = 'qayma0060805'
        hmDBInput[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        hmDBInput[MPSDefs.SECURITY_QUESTION_REQ] = 'Y'

        objectList.add('qayma0060805')
        objectList.add('slid.dum')

        HashMap dbResposne = new HashMap()

        dbResposne[MPSDefs.APP_STATUS_CODE] = MPSDefs.MPS_SUCCESS
        dbResposne[MPSDefs.APP_STATUS_MSG] = MPSDefs.MPS_ALL_OK
        dbResposne[MPSDefs.SQLCODE] = MPSDefs.SQL_SUCCESS
        dbResposne[MPSDefs.SQLMSG] = MPSDefs.SQL_SUCCESS_MSG
        dbResposne[MPSDefs.DB_MEMBER_NUM] = '1020371069'
        dbResposne[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        dbResposne[MPSDefs.DB_MEMBER_STATE] = 'RES'
        dbResposne[MPSDefs.DB_BAN] = '1020374553'
        dbResposne[MPSDefs.DB_SOR_NAME] = 'NA'
        dbResposne[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        dbResposne[MPSDefs.DB_ENC_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_MD5_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_SHA1_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_DES3_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_SSHA_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_GROUP_NUM] = '1020361572'
        dbResposne[MPSDefs.DB_DOMAIN_ID] = '15'

        alQueryResponse.add(dbResposne)

        jdbcTemplate.queryForList( _,_) >> alQueryResponse

        when:
        hmResposne = mpsDB_GetAllInfo_Object.getInfo(hmDBInput)
        then:
        hmResposne[CommonDefs.COMMON_APP_STATUS_MSG] == 'OK'
    }

    def "success get info test case for handle and domain security answer required"() {

        given:
        hmDBInput = new HashMap()

        hmDBInput[CommonDefs.TRANSACTION_NAME] = 'CheckUserIdAvailability'
        hmDBInput[MPSDefs.DB_MEMBER_NAME] = 'qayma0060805'
        hmDBInput[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        hmDBInput[MPSDefs.SECURITY_ANSWER_REQ] = 'Y'

        objectList.add('qayma0060805')
        objectList.add('slid.dum')

        HashMap dbResposne = new HashMap()

        dbResposne[MPSDefs.APP_STATUS_CODE] = MPSDefs.MPS_SUCCESS
        dbResposne[MPSDefs.APP_STATUS_MSG] = MPSDefs.MPS_ALL_OK
        dbResposne[MPSDefs.SQLCODE] = MPSDefs.SQL_SUCCESS
        dbResposne[MPSDefs.SQLMSG] = MPSDefs.SQL_SUCCESS_MSG
        dbResposne[MPSDefs.DB_MEMBER_NUM] = '1020371069'
        dbResposne[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        dbResposne[MPSDefs.DB_MEMBER_STATE] = 'RES'
        dbResposne[MPSDefs.DB_BAN] = '1020374553'
        dbResposne[MPSDefs.DB_SOR_NAME] = 'NA'
        dbResposne[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        dbResposne[MPSDefs.DB_ENC_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_MD5_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_SHA1_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_DES3_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_SSHA_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_GROUP_NUM] = '1020361572'
        dbResposne[MPSDefs.DB_DOMAIN_ID] = '15'

        alQueryResponse.add(dbResposne)

        jdbcTemplate.queryForList( _,_) >> alQueryResponse

        when:
        hmResposne = mpsDB_GetAllInfo_Object.getInfo(hmDBInput)
        then:
        hmResposne[CommonDefs.COMMON_APP_STATUS_MSG] == 'OK'
    }

    def "success get info test case for handle and domain last four ssn required"() {
        given:
        hmDBInput = new HashMap()

        hmDBInput[CommonDefs.TRANSACTION_NAME] = 'CheckUserIdAvailability'
        hmDBInput[MPSDefs.DB_MEMBER_NAME] = 'qayma0060805'
        hmDBInput[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        hmDBInput[MPSDefs.LAST_FOUR_SSN_REQ] = 'Y'

        objectList.add('qayma0060805')
        objectList.add('slid.dum')

        HashMap dbResposne = new HashMap()

        dbResposne[MPSDefs.APP_STATUS_CODE] = MPSDefs.MPS_SUCCESS
        dbResposne[MPSDefs.APP_STATUS_MSG] = MPSDefs.MPS_ALL_OK
        dbResposne[MPSDefs.SQLCODE] = MPSDefs.SQL_SUCCESS
        dbResposne[MPSDefs.SQLMSG] = MPSDefs.SQL_SUCCESS_MSG
        dbResposne[MPSDefs.DB_MEMBER_NUM] = '1020371069'
        dbResposne[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        dbResposne[MPSDefs.DB_MEMBER_STATE] = 'RES'
        dbResposne[MPSDefs.DB_BAN] = '1020374553'
        dbResposne[MPSDefs.DB_SOR_NAME] = 'NA'
        dbResposne[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        dbResposne[MPSDefs.DB_ENC_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_MD5_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_SHA1_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_DES3_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_SSHA_PASSWORD_VENC] = '******'
        dbResposne[MPSDefs.DB_GROUP_NUM] = '1020361572'
        dbResposne[MPSDefs.DB_DOMAIN_ID] = '15'

        alQueryResponse.add(dbResposne)

        jdbcTemplate.queryForList( _,_) >> alQueryResponse

        when:
        hmResposne = mpsDB_GetAllInfo_Object.getInfo(hmDBInput)
        then:
        hmResposne[CommonDefs.COMMON_APP_STATUS_MSG] == 'OK'
    }

    def "error test case for empty input hash map"() {

        given:
        hmDBInput = new HashMap()

        hmDBInput[CommonDefs.TRANSACTION_NAME] = 'CheckUserIdAvailability'
        when:
        hmResposne = mpsDB_GetAllInfo_Object.getInfo(hmDBInput)
        then:
        hmResposne[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_EMPTY'

    }

    def "error test case for null db input"() {

        given:
        hmDBInput = new HashMap()
        hmDBInput[MPSDefs.DB_BAN] = '134567987'
        when:
        hmResposne = mpsDB_GetAllInfo_Object.getInfo(hmDBInput)
        then:
        hmResposne[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }

    def "error test case for email alias handle"() {

        given:
        hmDBInput = new HashMap()
        hmDBInput[MPSDefs.DB_MEMBER_NAME] = 'qay_45678h'
        hmDBInput[MPSDefs.DB_DOMAIN_NAME] = 'att.net'
        jdbcTemplate.queryForList(_,_) >> alQueryResponse
        when:
        hmResposne = mpsDB_GetAllInfo_Object.getInfo(hmDBInput)
        then:
        hmResposne[CommonDefs.COMMON_APP_STATUS_MSG] == 'REC_NOT_FOUND'
        when:
        hmDBInput[MPSDefs.QUERY_BY_EMAIL_ALIAS_HANDLE_FLAG] = MPSDefs.YES
        hmResposne = mpsDB_GetAllInfo_Object.getInfo(hmDBInput)
        then:
        hmResposne[CommonDefs.COMMON_APP_STATUS_MSG] == 'REC_NOT_FOUND'

    }

    def "get info exception"() {

        given:
        hmDBInput = new HashMap()
        hmDBInput[CommonDefs.TRANSACTION_NAME] = 'CheckUserIdAvailability'
        hmDBInput[MPSDefs.DB_MEMBER_NAME] = 'qayma0060805'
        hmDBInput[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        hmDBInput[MPSDefs.LAST_FOUR_SSN_REQ] = 'Y'
        objectList.add('qayma0060805')
        objectList.add('slid.dum')
        HashMap dbResposne = new HashMap()
        dbResposne[MPSDefs.APP_STATUS_CODE] = MPSDefs.MPS_SUCCESS
        dbResposne[MPSDefs.APP_STATUS_MSG] = MPSDefs.MPS_ALL_OK
        dbResposne[MPSDefs.SQLCODE] = MPSDefs.SQL_SUCCESS
        dbResposne[MPSDefs.SQLMSG] = MPSDefs.SQL_SUCCESS_MSG
        dbResposne[MPSDefs.DB_MEMBER_NUM] = '1020371069'
        dbResposne[MPSDefs.DB_ACCESS_NAME] = 'NONE'
        dbResposne[MPSDefs.DB_MEMBER_STATE] = 'RES'
        dbResposne[MPSDefs.DB_BAN] = '1020374553'
		dbResposne[MPSDefs.DB_SOR_NAME] = 'NA'
		dbResposne[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
		dbResposne[MPSDefs.DB_GROUP_NUM] = '1020361572'
		dbResposne[MPSDefs.DB_DOMAIN_ID] = '15'

		alQueryResponse.add(dbResposne)
		 jdbcTemplate.queryForList( _,_) >> null
        when:
        hmResposne = mpsDB_GetAllInfo_Object.getInfo(hmDBInput)
        then:
        hmResposne[CommonDefs.COMMON_APP_STATUS_MSG] == 'ERR_SYS_APPL'
    }
}