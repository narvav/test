package com.att.idp.idgraphuserregistrationms.service.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.helper.AutoGenTempAIDHelper
import com.att.idp.idgraphuserregistrationms.resource.request.AutoGenTempAIDRequest
import com.att.idp.idgraphuserregistrationms.resource.request.SorInvariantId
import com.att.idp.idgraphuserregistrationms.resource.response.AutoGenTempAIDResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.junit.jupiter.api.Assertions

import spock.lang.Specification

import jakarta.ws.rs.core.MultivaluedHashMap
import jakarta.ws.rs.core.MultivaluedMap


class AutoGenTempAIDServiceImplTest extends Specification {

	def autoGenTempAIDServiceImpl=new AutoGenTempAIDServiceImpl();
	AutoGenTempAIDHelper oAutoGenTempAIDHelper=Mock(AutoGenTempAIDHelper)

	private AutoGenTempAIDRequest autoGenTempAIDRequest = null
	public MultivaluedMap<String, String> requestHeader = null
	private Map<String, String> headers = new HashMap<>()


	def setup() throws Exception {
		autoGenTempAIDServiceImpl.autogenTempAIDHelper = oAutoGenTempAIDHelper
		autoGenTempAIDRequest = new AutoGenTempAIDRequest()
		MultivaluedHashMap requestHeaders = new MultivaluedHashMap<>(headers)

		autoGenTempAIDRequest.callingSystemId = 'IDP'
		autoGenTempAIDRequest.isExternalCall = 'Y'
		autoGenTempAIDRequest.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
		autoGenTempAIDRequest.firstName = 'test'
		autoGenTempAIDRequest.lastName = 'testing'
		autoGenTempAIDRequest.contactEmail = 'test@testing.com'
		autoGenTempAIDRequest.agentId = 'tt1234'
		autoGenTempAIDRequest.contactEmailRTValidFlag = 'Y'

		SorInvariantId sor = new SorInvariantId()
		sor.sorName = 'LS'
		sor.sorInvariantId = '1234567890123'
		List<SorInvariantId> lstSor = new ArrayList<SorInvariantId>()
		lstSor.add(sor)
		autoGenTempAIDRequest.sorInvariantIdList = lstSor
	}
	
	@SuppressWarnings('unchecked')
	def "test autogentempaid null response"() {
		when:
		AutoGenTempAIDResponse response = autoGenTempAIDServiceImpl.autoGenTempAID(autoGenTempAIDRequest, requestHeader)

		then:
		response.appInfo == 'Null response from autogenTempAIDHelper.autogenTempAccessId'
		HashMap hmResponse = new HashMap()

		when:
		hmResponse[MPSDefs.APP_STATUS_CODE] = null
		oAutoGenTempAIDHelper.autogenTempAccessId(_ as HashMap)>> hmResponse

		then:
		response.appInfo == 'Null response from autogenTempAIDHelper.autogenTempAccessId'
	}


	def "test auto gentempaid invaliddata excep"() {

		given:
		HashMap hmResponse = new HashMap()
		hmResponse[CommonDefs.TRANSACTION_ID] = 'trma_16374856'
		hmResponse['isTransactionRollback'] = 'true'
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		oAutoGenTempAIDHelper.autogenTempAccessId(_ as Map<String, Object> as HashMap)>>(hmResponse)

		expect:
		InvalidInputDataException excep = Assertions.assertThrows(InvalidInputDataException.class, () -> {
			autoGenTempAIDServiceImpl.autoGenTempAID(autoGenTempAIDRequest, requestHeader)
		})

	}
	
	@SuppressWarnings('unchecked')
	def "test auto gentempaid success"() {

		given:
		HashMap hmResponse = new HashMap()
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		hmResponse['appInfo'] = 'Success'
		hmResponse['ErrorEnum'] = CommonDefs.COMMON_SUCCESS_MSG
		oAutoGenTempAIDHelper.autogenTempAccessId(_ as Map<String, Object> as HashMap)>>(hmResponse)

		when:
		AutoGenTempAIDResponse response = autoGenTempAIDServiceImpl.autoGenTempAID(autoGenTempAIDRequest, requestHeader)

		then:
		response.appStatusCode == '0'
	}

	def "test autoGenTempAID null appStatusCode"() {
		given:
		HashMap hmResponse = new HashMap()
		hmResponse[MPSDefs.APP_STATUS_CODE] = null
		oAutoGenTempAIDHelper.autogenTempAccessId(_ as Map<String, Object> as HashMap) >> hmResponse

		when:
		AutoGenTempAIDResponse response = autoGenTempAIDServiceImpl.autoGenTempAID(autoGenTempAIDRequest, requestHeader)

		then:
		response.appInfo == 'Null response from autogenTempAIDHelper.autogenTempAccessId'
	}

}
