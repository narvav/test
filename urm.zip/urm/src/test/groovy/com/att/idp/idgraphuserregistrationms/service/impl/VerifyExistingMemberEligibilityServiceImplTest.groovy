package com.att.idp.idgraphuserregistrationms.service.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.helper.VerifyExistingMemberEligibilityHelper
import com.att.idp.idgraphuserregistrationms.resource.request.VerifyExistingMemberEligibilityRequest
import com.att.idp.idgraphuserregistrationms.resource.response.VerifyExistingMemberEligibilityResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import org.junit.jupiter.api.Assertions
import spock.lang.Specification

import jakarta.ws.rs.core.MultivaluedHashMap
import jakarta.ws.rs.core.MultivaluedMap

class VerifyExistingMemberEligibilityServiceImplTest extends Specification {

	
	def verifyExistingMemberEligibilityServiceImpl =new VerifyExistingMemberEligibilityServiceImpl()

	VerifyExistingMemberEligibilityHelper verifyExistingMemberEligibilityHelperObj=Mock(VerifyExistingMemberEligibilityHelper)

	private VerifyExistingMemberEligibilityRequest verifyExistingMemberEligibilityRequestObj = null
	public MultivaluedMap<String, String> requestHeader = null
	private Map<String, String> headers = new HashMap<>()


	def setup() throws Exception {
		verifyExistingMemberEligibilityServiceImpl.verifyEMEHelperObj	= verifyExistingMemberEligibilityHelperObj
		verifyExistingMemberEligibilityRequestObj = new VerifyExistingMemberEligibilityRequest()
		requestHeader = new MultivaluedHashMap<>(headers)

		verifyExistingMemberEligibilityRequestObj.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
		verifyExistingMemberEligibilityRequestObj.callingSystemId = 'IDP'
		verifyExistingMemberEligibilityRequestObj.domain = 'slid.dum'
		verifyExistingMemberEligibilityRequestObj.handle = 'qaytest1'
		verifyExistingMemberEligibilityRequestObj.ban = '12345678'
		verifyExistingMemberEligibilityRequestObj.isExternalCall = 'Y'
	}
	
	@SuppressWarnings('unchecked')

	def "test verify existing member eligibility null response"() {
		when:
		VerifyExistingMemberEligibilityResponse response = verifyExistingMemberEligibilityServiceImpl.verifyExistingMemberEligibility(verifyExistingMemberEligibilityRequestObj, requestHeader)

		then:
		response.appInfo == 'Null response from verifyEMEHelperObj.verifyExistingMemberEligibility'
		HashMap hmResponse = new HashMap()

		when:
		hmResponse[MPSDefs.APP_STATUS_CODE] = null
		verifyExistingMemberEligibilityHelperObj.verifyExistingMemberEligibility(_)>>hmResponse
		response = verifyExistingMemberEligibilityServiceImpl.verifyExistingMemberEligibility(verifyExistingMemberEligibilityRequestObj, requestHeader)

		then:
		response.appInfo == 'Null response from verifyEMEHelperObj.verifyExistingMemberEligibility'
	}
	
	@SuppressWarnings('unchecked')

	def "test verify existing member eligibility success"() {

		given:
		HashMap hmResponse = new HashMap()
		hmResponse[MPSDefs.APP_STATUS_CODE] = '0'
		hmResponse['appInfo'] = 'Success'
		hmResponse['ErrorEnum'] = CommonDefs.COMMON_SUCCESS_MSG
		verifyExistingMemberEligibilityHelperObj.verifyExistingMemberEligibility(_ as HashMap)>>hmResponse

		when:
		VerifyExistingMemberEligibilityResponse response = verifyExistingMemberEligibilityServiceImpl.verifyExistingMemberEligibility(verifyExistingMemberEligibilityRequestObj, requestHeader)

		then:
		response.appStatusCode == '0'
	}

}
