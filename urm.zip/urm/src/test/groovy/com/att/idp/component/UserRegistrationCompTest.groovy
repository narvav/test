package com.att.idp.component

import com.att.idp.idgraph.commons.integration.CGRestClientWrapper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetMemberServicesDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetProvisionedServicesDBHelper
import org.hamcrest.CoreMatchers
import org.spockframework.spring.SpringBean
import org.springframework.jdbc.core.JdbcTemplate


class UserRegistrationCompTest extends CompTestBase {

	String uri = '/unifiedTOS/query'

	@SpringBean
	JdbcTemplate jdbcTemplate=Mock()

	@SpringBean
	CGRestClientWrapper cgRestClient = Mock()


	private Map<String, String> getHeaders() {
		Map<String, String> headers = new HashMap<String, String>()
		headers['Content-Type'] = 'application/json'
		headers['X-ATT-ClientId'] ='IDP'
		headers['idp-trace-id'] = 'cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0'
		return headers
	}


	def "query unified t o s success no record found in memberservice"() {
		given:
		List accountInfoResponse = readJsonFileToList("mockResponse/AccountInfo.json") as List;
		HashMap provisionedServicesResponse = readJsonFileToMap("mockResponse/ProvisionedServices.json") as HashMap;
		HashMap cgResponse = readJsonFileToMap("mockResponse/CGSyncResponse.json") as HashMap;

		Map memberServiceResp= new HashMap();
		memberServiceResp.put("appStatusMsg","REC_NOT_FOUND");
		memberServiceResp.put("sqlMsg","N/A");
		memberServiceResp.put("appCategoryCode","3");
		memberServiceResp.put("appStatusCode","303");
		memberServiceResp.put("sqlCode","N/A");
		memberServiceResp.put("numRowsUpdated","0");
		jdbcTemplate.queryForList(_ as String, _ as Object)	>> accountInfoResponse
		getProvisionedServicesDBHelper.getProvisionedServices(_ as HashMap)	>> provisionedServicesResponse
		getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> memberServiceResp
		cgRestClient.getCGSyncCall(_ as HashMap) >> cgResponse;

		String req = '{ "ban": "000932335" }'
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(200).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
				.body("appStatusCode", CoreMatchers.equalTo("0"))
				.body("tosFlags.hsiaTOSAcceptance", CoreMatchers.equalTo("N"))
	}

	def "query unified t o s success no customer account found"() {
		given:
		List accountInfoResponse = readJsonFileToList("mockResponse/AccountInfo.json") as List;
		HashMap provisionedServicesResponse = readJsonFileToMap("mockResponse/ProvisionedServices.json") as HashMap;
		HashMap memberServiceResp = readJsonFileToMap("mockResponse/MemberService.json") as HashMap;
		Map resultMap = new HashMap();
		resultMap.put("appStatusMsg", "ERR_INVALID_DATA");
		resultMap.put("appStatusCode", "3");
		resultMap.put("appStatusCode", "100");
		resultMap.put("appInfo", "Customer account profile data not found");

		jdbcTemplate.queryForList(_ as String, _ as Object)	>> accountInfoResponse
		getProvisionedServicesDBHelper.getProvisionedServices(_ as HashMap)	>> provisionedServicesResponse
		getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> memberServiceResp
		cgRestClient.getCGSyncCall(_ as HashMap) >> resultMap;

		String req = '{ "ban": "000932335" }'
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(200).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("SUCCESS"))
				.body("appStatusCode", CoreMatchers.equalTo("0"))
				.body("tosFlags.hsiaTOSAcceptance", CoreMatchers.equalTo("N"))
	}

	def "query unified t o s invalid input"() {
		given:

		String req = '{ "ban": "" }'
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(400).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_INVALID_DATA"))
				.body("appStatusCode", CoreMatchers.equalTo("100"))
				.body("appInfo", CoreMatchers.equalTo("ban length is invalid"))
				.body("error.errorId", CoreMatchers.equalTo("MS_MPSYS_BE_100"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}


	def "query unified t o s accountInfo error"() {
		given:
		jdbcTemplate.queryForList(_ as String, _ as Object)	>> null
		String req = '{ "ban": "000932" }'
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(404).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_BAN_NOT_FOUND"))
				.body("appStatusCode", CoreMatchers.equalTo("130"))
				.body("appInfo", CoreMatchers.equalTo("Ban not found"))
				.body("error.errorId", CoreMatchers.equalTo("MS_MPSYS_BE_130"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}

	def "query unified t o s provisionedServices error"() {


		given:
		List accountInfoResponse = readJsonFileToList("mockResponse/AccountInfo.json") as List;
		HashMap memberServiceResp = readJsonFileToMap("mockResponse/MemberService.json") as HashMap;
		jdbcTemplate.queryForList(_ as String, _ as Object)	>> accountInfoResponse
		getProvisionedServicesDBHelper.getProvisionedServices(_ as HashMap)>>null
		getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> memberServiceResp
		String req = '{ "ban": "000932335" }'
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(500).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_SYS_APPL"))
				.body("appStatusCode", CoreMatchers.equalTo("602"))
				.body("appInfo", CoreMatchers.equalTo("Null or empty response GetProvisionedServicesDBHelper"))
				.body("error.errorId", CoreMatchers.equalTo("MS_MPSYS_BE_602"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}


	def "query unified t o s  member service error"() {
		given:
		List accountInfoResponse = readJsonFileToList("mockResponse/AccountInfo.json") as List;
		HashMap provisionedServicesResponse = readJsonFileToMap("mockResponse/ProvisionedServices.json") as HashMap;
		Map resultMap = new HashMap();
		resultMap.put("appStatusMsg", "ERR_INVALID_DATA");
		resultMap.put("appStatusCode", "3");
		resultMap.put("appStatusCode", "100");
		resultMap.put("appInfo", "Customer account profile data not found");

		jdbcTemplate.queryForList(_ as String, _ as Object)	>> accountInfoResponse
		getProvisionedServicesDBHelper.getProvisionedServices(_ as HashMap)	>> provisionedServicesResponse
		getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> null
		cgRestClient.getCGSyncCall(_ as HashMap) >> resultMap;

		String req = '{ "ban": "000932335" }'
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(500).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_SYS_APPL"))
				.body("appStatusCode", CoreMatchers.equalTo("602"))
				.body("appInfo", CoreMatchers.equalTo("Null or empty response GetMemberServicesDBHelper"))
				.body("error.errorId", CoreMatchers.equalTo("MS_MPSYS_BE_602"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}


	def "query unified t o s CG Sync error"() {
		given:
		List accountInfoResponse = readJsonFileToList("mockResponse/AccountInfo.json") as List;
		HashMap provisionedServicesResponse = readJsonFileToMap("mockResponse/ProvisionedServices.json") as HashMap;
		HashMap memberServiceResp = readJsonFileToMap("mockResponse/MemberService.json") as HashMap;


		jdbcTemplate.queryForList(_ as String, _ as Object)	>> accountInfoResponse
		getProvisionedServicesDBHelper.getProvisionedServices(_ as HashMap)	>> provisionedServicesResponse
		getMemberServicesDBHelper.getMemberServices(_ as HashMap) >> memberServiceResp
		cgRestClient.getCGSyncCall(_ as HashMap) >> null;

		String req = '{ "ban": "000932335" }'
		givenBaseSpec()
				.body(req)
				.when().headers(getHeaders())
				.post(uri)
				.then()
				.statusCode(500).assertThat()
				.body("appStatusMsg", CoreMatchers.equalTo("ERR_SYS_APPL"))
				.body("appStatusCode", CoreMatchers.equalTo("602"))
				.body("appInfo", CoreMatchers.equalTo("cgRestClient.getCGSyncCall returned empty response."))
				.body("error.errorId", CoreMatchers.equalTo("MS_MPSYS_BE_602"))
				.body("idp-trace-id", CoreMatchers.equalTo("cbc12f35d5da7f2e:cbc12f35d5da7f2e:0:0"))
	}
}
