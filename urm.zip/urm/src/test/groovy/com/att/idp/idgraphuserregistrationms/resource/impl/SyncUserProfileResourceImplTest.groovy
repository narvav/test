package com.att.idp.idgraphuserregistrationms.resource.impl

import com.att.idp.idgraphuserregistrationms.exceptions.InvalidInputDataException
import com.att.idp.idgraphuserregistrationms.exceptions.MPSException
import com.att.idp.idgraphuserregistrationms.request.validator.ReprovisionUverseRequestValidator
import com.att.idp.idgraphuserregistrationms.request.validator.SyncUserProfileRequestValidator
import com.att.idp.idgraphuserregistrationms.request.validator.ValidateAndSyncG2RequestValidator
import com.att.idp.idgraphuserregistrationms.resource.request.SyncUserProfileRequest
import com.att.idp.idgraphuserregistrationms.resource.response.SyncUserProfileResponse
import com.att.idp.idgraphuserregistrationms.service.ReprovisionUverseService
import com.att.idp.idgraphuserregistrationms.service.SyncCCRService
import com.att.idp.idgraphuserregistrationms.service.SyncCGService
import com.att.idp.idgraphuserregistrationms.service.SyncUserProfileService
import jakarta.ws.rs.core.MultivaluedHashMap
import spock.lang.Specification
import com.att.idp.idgraphuserregistrationms.service.ValidateAndSyncG2Service

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap
import jakarta.ws.rs.core.MultivaluedMap
import jakarta.ws.rs.core.Response
import spock.lang.Unroll

import java.sql.SQLException

class SyncUserProfileResourceImplTest extends Specification {

    def syncUserProfileResourceImplObj=new SyncUserProfileResourceImpl()

    SyncUserProfileRequestValidator syncUserProfileReqValidator = Mock(SyncUserProfileRequestValidator)

    SyncUserProfileService syncUserProfileService = Mock(SyncUserProfileService)

    HttpHeaders requestHeader = Mock(HttpHeaders)

    ValidateAndSyncG2RequestValidator validateAndSyncG2RequestValidatorObj = Mock(ValidateAndSyncG2RequestValidator)

    ValidateAndSyncG2Service validateAndSyncG2ServiceObj = Mock(ValidateAndSyncG2Service)

    ReprovisionUverseRequestValidator reprovisionUverseRequestValidatorObj = Mock(ReprovisionUverseRequestValidator)

    ReprovisionUverseService reprovisionUverseServiceObj = Mock(ReprovisionUverseService)
    private SyncUserProfileResponse syncUserProfileResponse = null

    SyncUserProfileRequest syncUserProfileRequestObj
    SyncCCRService syncCCService = Mock(SyncCCRService)
    SyncCGService syncCGService = Mock(SyncCGService)


    def setup() {
		syncUserProfileResourceImplObj.syncUserProfileReqValidator = syncUserProfileReqValidator
		syncUserProfileResourceImplObj.syncUserProfileService = syncUserProfileService
		
		syncUserProfileResourceImplObj.validateAndSyncG2Service = validateAndSyncG2ServiceObj
		syncUserProfileResourceImplObj.validateAndSyncG2RequestValidator = validateAndSyncG2RequestValidatorObj
		
		syncUserProfileResourceImplObj.reprovisionUverseService = reprovisionUverseServiceObj
		syncUserProfileResourceImplObj.reprovisionUverseRequestValidator = reprovisionUverseRequestValidatorObj
		
		syncUserProfileResourceImplObj.syncCCRService = syncCCService
		syncUserProfileResourceImplObj.syncCGService = syncCGService
	}


    def "test sync user profile success"() throws Exception {
        given:
        SyncUserProfileResponse syncUserProfileResponse = new SyncUserProfileResponse()
        syncUserProfileResponse.appCategoryCode = '0'
        syncUserProfileReqValidator.syncUserProfileRequestValidator(_ as HttpHeaders, _ as SyncUserProfileRequest) >> syncUserProfileResponse

        syncUserProfileService.syncUserProfile(_ as SyncUserProfileRequest, _ as HttpHeaders) >> syncUserProfileResponse
        when:
        Response response = syncUserProfileResourceImplObj.syncUserProfile(new SyncUserProfileRequest(), requestHeader)
        then:
        response.status == 200
    }


    @Unroll
    def "should return 400 for sync user profile error when appCategoryCode is 3 for #scenarioName"() {
        given: "A SyncUserProfileRequest and a response with appCategoryCode 3"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        SyncUserProfileResponse errorResponse = new SyncUserProfileResponse()
        errorResponse.appCategoryCode = "3"

        when: "Validator returns error response and syncUserProfile is called"
        syncUserProfileReqValidator.syncUserProfileRequestValidator(requestHeader, request) >> errorResponse

        Response response = syncUserProfileResourceImplObj.syncUserProfile(request, requestHeader)

        then: "Validator is called with correct arguments, service is not called, and response is 400"
        syncUserProfileReqValidator.syncUserProfileRequestValidator(requestHeader, request) >> errorResponse
        syncUserProfileService.syncUserProfile(_, _)>>errorResponse
        and: "Response status is 400"
        response != null
        response.status == 400

        where: "Different error scenarios"
        scenarioName | _
        "appCategoryCode 3" | _
    }

    def "should return 500 for sync user profile error when appCategoryCode is 2 for #scenarioName"() {
        given: "A SyncUserProfileRequest and a response with appCategoryCode 2"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        SyncUserProfileResponse errorResponse = new SyncUserProfileResponse()
        errorResponse.appCategoryCode = "2"

        when: "Validator returns error response and syncUserProfile is called"
        syncUserProfileReqValidator.syncUserProfileRequestValidator(requestHeader, request) >> errorResponse

        Response response = syncUserProfileResourceImplObj.syncUserProfile(request, requestHeader)

        then: "Validator is called with correct arguments, service is not called, and response is 500"
        syncUserProfileReqValidator.syncUserProfileRequestValidator(requestHeader, request) >> errorResponse
        syncUserProfileService.syncUserProfile(_, _)>>errorResponse

        and: "Response status is 500"
        response != null
        response.status == 500

        where: "Different error scenarios"
        scenarioName | _
        "appCategoryCode 2" | _
    }


    def "test sync user profile invalid input data exception"() throws Exception {
        given:
        InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
        syncUserProfileReqValidator.syncUserProfileRequestValidator(_ as HttpHeaders, _ as SyncUserProfileRequest) >> { throw ex }

        when:
        syncUserProfileResourceImplObj.syncUserProfile(new SyncUserProfileRequest(), requestHeader)

        then:
        thrown(InvalidInputDataException.class)
    }


    def "test sync user profile null pointer exception"() throws MPSException {
        given:
        NullPointerException ex = new NullPointerException('NullPointerException thrown')
        syncUserProfileReqValidator.syncUserProfileRequestValidator(_ as HttpHeaders, _ as SyncUserProfileRequest) >> { throw ex }

        when:
        Response response = syncUserProfileResourceImplObj.syncUserProfile(new SyncUserProfileRequest(), requestHeader)

        then:
        response.status == 500
    }

    def "test validate and sync g2 success"() throws Exception {
        given:
        SyncUserProfileResponse syncUserProfileResponse = new SyncUserProfileResponse()
        syncUserProfileResponse.appCategoryCode = '0'

        validateAndSyncG2RequestValidatorObj.validatAndSyncG2(_ as SyncUserProfileRequest, _ as HttpHeaders) >> null
        validateAndSyncG2ServiceObj.validateAndSyncG2(_,_) >> syncUserProfileResponse      

        when:
        Response response = syncUserProfileResourceImplObj.validateAndSyncG2(syncUserProfileRequestObj, requestHeader)
        then:
        response.status == 200
    }

    def "test validate and sync g2 error from request validator"() throws Exception {
        given:
        syncUserProfileRequestObj = new SyncUserProfileRequest()
        syncUserProfileRequestObj.agentId = 'xxx'
        syncUserProfileResponse = new SyncUserProfileResponse()
        syncUserProfileResponse.appCategoryCode = '2'
        validateAndSyncG2RequestValidatorObj.validatAndSyncG2(_ as SyncUserProfileRequest, _ as HttpHeaders) >> syncUserProfileResponse
        when:
        Response response = syncUserProfileResourceImplObj.validateAndSyncG2(syncUserProfileRequestObj, requestHeader)
        then:
        response.status == 500
    }

    def "test validate and sync g2 bad request"() throws Exception {
        given:
        syncUserProfileRequestObj = new SyncUserProfileRequest()
        syncUserProfileRequestObj.agentId = 'xxx'
        syncUserProfileResponse = new SyncUserProfileResponse()
        syncUserProfileResponse.appCategoryCode = '3'
        validateAndSyncG2RequestValidatorObj.validatAndSyncG2(_ as SyncUserProfileRequest, _ as HttpHeaders) >> syncUserProfileResponse
        when:
        Response response = syncUserProfileResourceImplObj.validateAndSyncG2(syncUserProfileRequestObj, requestHeader)
        then:
        response.status == 400
    }

    def "test validate and sync g2 invalid input data exception"() throws Exception {
        given:
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
        requestHeader.getRequestHeaders() >> new MultivaluedHashMap<String, String>()
        validateAndSyncG2RequestValidatorObj.validatAndSyncG2(request, requestHeader) >> { throw ex }

        when:
        syncUserProfileResourceImplObj.validateAndSyncG2(request, requestHeader)

        then:
        thrown(InvalidInputDataException.class)
    }


    def "test validate and sync g2 null pointer exception"() throws MPSException {
        given:
        NullPointerException ex = new NullPointerException('NullPointerException thrown')
        requestHeader.getRequestHeaders() >> new MultivaluedHashMap<String, String>()

        validateAndSyncG2ServiceObj.validateAndSyncG2(_ as SyncUserProfileRequest, _ as MultivaluedMap) >> { throw ex }

        when:
        Response response = syncUserProfileResourceImplObj.validateAndSyncG2(new SyncUserProfileRequest(), requestHeader)

        then:
        response.status == 500
    }


    def "test reprovision uverse null pointer exception"() throws MPSException {
        given:
        NullPointerException ex = new NullPointerException('NullPointerException thrown')
        requestHeader.getRequestHeaders() >> new MultivaluedHashMap<String, String>()

        reprovisionUverseServiceObj.reprovisionUverse(_ as SyncUserProfileRequest, _ as MultivaluedMap) >> { throw ex }

        when:
        Response response = syncUserProfileResourceImplObj.reprovisionUverse(new SyncUserProfileRequest(), requestHeader)

        then:
        response.status == 500
    }


    def "test reprovision uverse invalid input data exception"() throws Exception {
        given:
        InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException thrown')
        reprovisionUverseRequestValidatorObj.reprovisionUverse(_ as SyncUserProfileRequest, _ as HttpHeaders) >> { throw ex }

        when:
        syncUserProfileResourceImplObj.reprovisionUverse(new SyncUserProfileRequest(), requestHeader)

        then:
        thrown(InvalidInputDataException.class)
    }


    def "test reprovision uverse success"() throws Exception {
        given:
        SyncUserProfileResponse syncUserProfileResponse = new SyncUserProfileResponse()
        syncUserProfileResponse.appCategoryCode = '0'

        reprovisionUverseRequestValidatorObj.reprovisionUverse(_ as SyncUserProfileRequest, _ as HttpHeaders) >> null
        reprovisionUverseServiceObj.reprovisionUverse(_ as SyncUserProfileRequest, _) >> syncUserProfileResponse

        //when:
        Response response = syncUserProfileResourceImplObj.reprovisionUverse(syncUserProfileRequestObj, requestHeader)
        //then:
        //response.status == 200
    }


    def "test reprovision uverse bad request"() throws Exception {
        given:
        syncUserProfileRequestObj = new SyncUserProfileRequest()
        syncUserProfileRequestObj.agentId = 'xxx'
        syncUserProfileResponse = new SyncUserProfileResponse()
        syncUserProfileResponse.appCategoryCode = '3'
        reprovisionUverseRequestValidatorObj.reprovisionUverse(_ as SyncUserProfileRequest, _ as HttpHeaders) >> syncUserProfileResponse
        when:
        Response response = syncUserProfileResourceImplObj.reprovisionUverse(syncUserProfileRequestObj, requestHeader)
        then:
        response.status == 400
    }

    def "test sync user profile SQL exception"() throws Exception {
        given:
        SQLException ex = new SQLException('SQLException thrown')
        syncUserProfileReqValidator.syncUserProfileRequestValidator(_ as HttpHeaders, _ as SyncUserProfileRequest) >> { throw ex }

        when:
        Response response = syncUserProfileResourceImplObj.syncUserProfile(new SyncUserProfileRequest(), requestHeader)

        then:
        response.status == 500
    }

    def "test validate and sync g2 SQL exception"() throws Exception {
        given:
        SQLException ex = new SQLException('SQLException thrown')
        validateAndSyncG2ServiceObj.validateAndSyncG2(_, _) >> new SQLException('SQLException thrown')

        when:
        Response response = syncUserProfileResourceImplObj.validateAndSyncG2(new SyncUserProfileRequest(), requestHeader)

        then:
        response.status == 500
    }

    def "test reprovisionUverse handles SQLException"() {
        given:
        SQLException ex = new SQLException('SQLException thrown')
        reprovisionUverseServiceObj.reprovisionUverse(_ , _ ) >> { throw ex }

        when:
        Response response = syncUserProfileResourceImplObj.reprovisionUverse(new SyncUserProfileRequest(), requestHeader)

        then:
        response.status == 500
    }

    // Tests for SyncCCR destination
    def "test sync user profile success for CCR destination"() throws Exception {
        given: "A SyncUserProfileRequest with CCR destination"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.destination = "CCR"
        SyncUserProfileResponse successResponse = new SyncUserProfileResponse()
        successResponse.appCategoryCode = '0'

        syncUserProfileReqValidator.syncUserProfileRequestValidator(_ as HttpHeaders, _ as SyncUserProfileRequest) >> null
        syncCCService.syncCCR(_ as SyncUserProfileRequest, _ as HttpHeaders) >> successResponse

        when: "syncUserProfile is called with CCR destination"
        Response response = syncUserProfileResourceImplObj.syncUserProfile(request, requestHeader)

        then: "CCR service is called and response is successful"
        response.status == 200
    }

    def "test sync user profile success for CCR destination lowercase"() throws Exception {
        given: "A SyncUserProfileRequest with ccr destination"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.destination = "ccr"
        SyncUserProfileResponse successResponse = new SyncUserProfileResponse()
        successResponse.appCategoryCode = '0'

        syncUserProfileReqValidator.syncUserProfileRequestValidator(_ as HttpHeaders, _ as SyncUserProfileRequest) >> null
        syncCCService.syncCCR(_ as SyncUserProfileRequest, _ as HttpHeaders) >> successResponse

        when: "syncUserProfile is called with lowercase ccr destination"
        Response response = syncUserProfileResourceImplObj.syncUserProfile(request, requestHeader)

        then: "CCR service is called and response is successful"
        response.status == 200
    }

    def "test sync user profile error from CCR service with appCategoryCode 3"() throws Exception {
        given: "A SyncUserProfileRequest with CCR destination and error response"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.destination = "CCR"
        SyncUserProfileResponse errorResponse = new SyncUserProfileResponse()
        errorResponse.appCategoryCode = '3'

        syncUserProfileReqValidator.syncUserProfileRequestValidator(_ as HttpHeaders, _ as SyncUserProfileRequest) >> null
        syncCCService.syncCCR(_ as SyncUserProfileRequest, _ as HttpHeaders) >> errorResponse

        when: "syncUserProfile is called for CCR with error response"
        Response response = syncUserProfileResourceImplObj.syncUserProfile(request, requestHeader)

        then: "Response status is 400"
        response.status == 400
    }

    def "test sync user profile error from CCR service with appCategoryCode 2"() throws Exception {
        given: "A SyncUserProfileRequest with CCR destination and error response"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.destination = "CCR"
        SyncUserProfileResponse errorResponse = new SyncUserProfileResponse()
        errorResponse.appCategoryCode = '2'

        syncUserProfileReqValidator.syncUserProfileRequestValidator(_ as HttpHeaders, _ as SyncUserProfileRequest) >> null
        syncCCService.syncCCR(_ as SyncUserProfileRequest, _ as HttpHeaders) >> errorResponse

        when: "syncUserProfile is called for CCR with error response"
        Response response = syncUserProfileResourceImplObj.syncUserProfile(request, requestHeader)

        then: "Response status is 500"
        response.status == 500
    }

    def "test sync user profile InvalidInputDataException from CCR service"() throws Exception {
        given: "A SyncUserProfileRequest with CCR destination and exception"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.destination = "CCR"
        InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException from CCR')

        syncUserProfileReqValidator.syncUserProfileRequestValidator(_ as HttpHeaders, _ as SyncUserProfileRequest) >> null
        syncCCService.syncCCR(_ as SyncUserProfileRequest, _ as HttpHeaders) >> { throw ex }

        when: "syncUserProfile is called for CCR with exception"
        syncUserProfileResourceImplObj.syncUserProfile(request, requestHeader)

        then: "InvalidInputDataException is thrown"
        thrown(InvalidInputDataException.class)
    }

    def "test sync user profile SQLException from CCR service"() throws Exception {
        given: "A SyncUserProfileRequest with CCR destination and SQL exception"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.destination = "CCR"
        SQLException ex = new SQLException('SQLException from CCR')

        syncUserProfileReqValidator.syncUserProfileRequestValidator(_ as HttpHeaders, _ as SyncUserProfileRequest) >> null
        syncCCService.syncCCR(_ as SyncUserProfileRequest, _ as HttpHeaders) >> { throw ex }

        when: "syncUserProfile is called for CCR with SQL exception"
        Response response = syncUserProfileResourceImplObj.syncUserProfile(request, requestHeader)

        then: "Response status is 500"
        response.status == 500
    }

    def "test sync user profile NullPointerException from CCR service"() throws Exception {
        given: "A SyncUserProfileRequest with CCR destination and null pointer exception"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.destination = "CCR"
        NullPointerException ex = new NullPointerException('NullPointerException from CCR')

        syncUserProfileReqValidator.syncUserProfileRequestValidator(_ as HttpHeaders, _ as SyncUserProfileRequest) >> null
        syncCCService.syncCCR(_ as SyncUserProfileRequest, _ as HttpHeaders) >> { throw ex }

        when: "syncUserProfile is called for CCR with null pointer exception"
        Response response = syncUserProfileResourceImplObj.syncUserProfile(request, requestHeader)

        then: "Response status is 500"
        response.status == 500
    }

    // Tests for SyncCG destination
    def "test sync user profile success for CG destination"() throws Exception {
        given: "A SyncUserProfileRequest with CG destination"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.destination = "CG"
        SyncUserProfileResponse successResponse = new SyncUserProfileResponse()
        successResponse.appCategoryCode = '0'

        syncUserProfileReqValidator.syncUserProfileRequestValidator(_ as HttpHeaders, _ as SyncUserProfileRequest) >> null
        syncCGService.syncCG(_ as SyncUserProfileRequest, _ as HttpHeaders) >> successResponse

        when: "syncUserProfile is called with CG destination"
        Response response = syncUserProfileResourceImplObj.syncUserProfile(request, requestHeader)

        then: "CG service is called and response is successful"
        response.status == 200
    }

    def "test sync user profile success for CG destination lowercase"() throws Exception {
        given: "A SyncUserProfileRequest with cg destination"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.destination = "cg"
        SyncUserProfileResponse successResponse = new SyncUserProfileResponse()
        successResponse.appCategoryCode = '0'

        syncUserProfileReqValidator.syncUserProfileRequestValidator(_ as HttpHeaders, _ as SyncUserProfileRequest) >> null
        syncCGService.syncCG(_ as SyncUserProfileRequest, _ as HttpHeaders) >> successResponse

        when: "syncUserProfile is called with lowercase cg destination"
        Response response = syncUserProfileResourceImplObj.syncUserProfile(request, requestHeader)

        then: "CG service is called and response is successful"
        response.status == 200
    }

    def "test sync user profile error from CG service with appCategoryCode 3"() throws Exception {
        given: "A SyncUserProfileRequest with CG destination and error response"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.destination = "CG"
        SyncUserProfileResponse errorResponse = new SyncUserProfileResponse()
        errorResponse.appCategoryCode = '3'

        syncUserProfileReqValidator.syncUserProfileRequestValidator(_ as HttpHeaders, _ as SyncUserProfileRequest) >> null
        syncCGService.syncCG(_ as SyncUserProfileRequest, _ as HttpHeaders) >> errorResponse

        when: "syncUserProfile is called for CG with error response"
        Response response = syncUserProfileResourceImplObj.syncUserProfile(request, requestHeader)

        then: "Response status is 400"
        response.status == 400
    }

    def "test sync user profile error from CG service with appCategoryCode 2"() throws Exception {
        given: "A SyncUserProfileRequest with CG destination and error response"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.destination = "CG"
        SyncUserProfileResponse errorResponse = new SyncUserProfileResponse()
        errorResponse.appCategoryCode = '2'

        syncUserProfileReqValidator.syncUserProfileRequestValidator(_ as HttpHeaders, _ as SyncUserProfileRequest) >> null
        syncCGService.syncCG(_ as SyncUserProfileRequest, _ as HttpHeaders) >> errorResponse

        when: "syncUserProfile is called for CG with error response"
        Response response = syncUserProfileResourceImplObj.syncUserProfile(request, requestHeader)

        then: "Response status is 500"
        response.status == 500
    }

    def "test sync user profile InvalidInputDataException from CG service"() throws Exception {
        given: "A SyncUserProfileRequest with CG destination and exception"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.destination = "CG"
        InvalidInputDataException ex = new InvalidInputDataException('InvalidInputDataException from CG')

        syncUserProfileReqValidator.syncUserProfileRequestValidator(_ as HttpHeaders, _ as SyncUserProfileRequest) >> null
        syncCGService.syncCG(_ as SyncUserProfileRequest, _ as HttpHeaders) >> { throw ex }

        when: "syncUserProfile is called for CG with exception"
        syncUserProfileResourceImplObj.syncUserProfile(request, requestHeader)

        then: "InvalidInputDataException is thrown"
        thrown(InvalidInputDataException.class)
    }

    def "test sync user profile SQLException from CG service"() throws Exception {
        given: "A SyncUserProfileRequest with CG destination and SQL exception"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.destination = "CG"
        SQLException ex = new SQLException('SQLException from CG')

        syncUserProfileReqValidator.syncUserProfileRequestValidator(_ as HttpHeaders, _ as SyncUserProfileRequest) >> null
        syncCGService.syncCG(_ as SyncUserProfileRequest, _ as HttpHeaders) >> { throw ex }

        when: "syncUserProfile is called for CG with SQL exception"
        Response response = syncUserProfileResourceImplObj.syncUserProfile(request, requestHeader)

        then: "Response status is 500"
        response.status == 500
    }

    def "test sync user profile NullPointerException from CG service"() throws Exception {
        given: "A SyncUserProfileRequest with CG destination and null pointer exception"
        SyncUserProfileRequest request = new SyncUserProfileRequest()
        request.destination = "CG"
        NullPointerException ex = new NullPointerException('NullPointerException from CG')

        syncUserProfileReqValidator.syncUserProfileRequestValidator(_ as HttpHeaders, _ as SyncUserProfileRequest) >> null
        syncCGService.syncCG(_ as SyncUserProfileRequest, _ as HttpHeaders) >> { throw ex }

        when: "syncUserProfile is called for CG with null pointer exception"
        Response response = syncUserProfileResourceImplObj.syncUserProfile(request, requestHeader)

        then: "Response status is 500"
        response.status == 500
    }
}