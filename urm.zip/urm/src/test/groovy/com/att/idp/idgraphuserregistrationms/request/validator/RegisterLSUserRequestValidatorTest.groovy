package com.att.idp.idgraphuserregistrationms.request.validator

import com.att.idp.idgraphuserregistrationms.resource.request.RegisterLSUserRequest
import com.att.idp.idgraphuserregistrationms.resource.response.RegisterLSUserResponse
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import jakarta.ws.rs.core.HttpHeaders
import jakarta.ws.rs.core.MultivaluedHashMap

class RegisterLSUserRequestValidatorTest extends Specification {
	

	def registerLSUserRequestValidator = new RegisterLSUserRequestValidator()

	RegisterLSUserRequest requestObj = null
	RegisterLSUserResponse responseObj = null

	private Map<String, String> headers = new HashMap<>()


	public HttpHeaders requestHeader = null
	MultivaluedHashMap requestHeaders =null


	def setup() throws Exception {
		requestObj = new RegisterLSUserRequest()
		responseObj= new RegisterLSUserResponse()
		requestHeader= Mock(HttpHeaders)

		requestObj.callingSystemId = 'IDP'
		requestObj.isExternalCall = 'Y'
		requestObj.idpTraceId = '99dfs999:8dfs8888:77777:66666ccc'
		requestObj.ban = '876110000'
		requestObj.dateOfBirth = '20200404'
		requestObj.regType = 'NEW'
		requestObj.slid = 'crissydee73@gmail.com'
		requestObj.handle = 'crissyechev74@aatt.net'

	//	MockitoAnnotations.initMocks(this)
		ReflectionTestUtils.setField(registerLSUserRequestValidator, 'propValidCallers', 'IDP|DATAMGT')
	}


	def "register ls user request validator null req test"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'

		when:
		RegisterLSUserResponse response = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, null)
		then:
		response.appInfo == 'Input Request is NULL / Empty.'

	}
	def "register ls user request trace id test"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		//	requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'

		when:
		RegisterLSUserResponse response = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Missing or Invalid IdpTraceId'
	}
	def "register ls user request unknownattribues"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		Map<String,Object> allUnknownAttributes =new HashMap<>()
		requestObj.setUnknownAttributes(allUnknownAttributes)
		allUnknownAttributes.put("test","test")
		when:
		RegisterLSUserResponse responseObj = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, requestObj)
		then:
		responseObj.appInfo == 'Invalid Attributes passed in RegisterUserRequest : {test=test}'

	}

	def "register ls user request validator success test"() throws Exception {
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		RegisterLSUserResponse response = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, requestObj)
		then:
		response == null

	}


	def "register ls user request null client  id test"() throws Exception{
		//Mockito.doReturn(null).when(requestHeader).getHeaderString("idp-trace-id");
		given:
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId')>>null
		when:
		RegisterLSUserResponse response = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}


	def "register ls user request empty client id test"() throws Exception{
		given:
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId')>>' '
		when:
		RegisterLSUserResponse response = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}


	def "register ls user request invalid client id test"() throws Exception{
		given:
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		requestHeader.getHeaderString('X-ATT-ClientId')>>'ILM'
		when:
		RegisterLSUserResponse response = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Missing or invalid X-ATT-ClientId in request header'
	}


	def "register ls user request validator null ban test"() throws Exception {
		given:
		requestObj.ban = null
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		RegisterLSUserResponse response = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Ban is missing.'

		when:
		requestObj.ban = ''
		RegisterLSUserResponse response2 = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, requestObj)
		then:
		response2.appInfo == 'Ban is missing.'

	}


	def "register ls user request validator null handle test"() throws Exception {
		given:
		requestObj.handle = null
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		RegisterLSUserResponse response = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'User Id is missing.'

		when:
		requestObj.handle = ''
		RegisterLSUserResponse response2 = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, requestObj)
		then:
		response2.appInfo == 'User Id is missing.'

	}


	def "register ls user request validator null reg type test"() throws Exception {
		given:
		requestObj.regType = null
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		RegisterLSUserResponse response = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'RegType is missing.'

		when:
		requestObj.regType = ''
		RegisterLSUserResponse response2 = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, requestObj)
		then:
		response2.appInfo == 'RegType is missing.'

	}

	def "register ls user request validator null slid test"() throws Exception {
		given:
		requestObj.slid = null
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		RegisterLSUserResponse response = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Slid is missing.'

		when:
		requestObj.slid = ''
		RegisterLSUserResponse response2 = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, requestObj)
		then:
		response2.appInfo == 'Slid is missing.'

	}


	def "register ls user request validator null is external call test"() throws Exception {
		given:
		requestObj.isExternalCall = null
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		RegisterLSUserResponse response = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, requestObj)
		then:
		requestObj.isExternalCall == 'Y'

		when:
		requestObj.isExternalCall = 'K'
		RegisterLSUserResponse response2 = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, requestObj)
		then:
		response2.appInfo == 'isExternalCall must be one of Y or N'

	}


	def "register ls user request validator missing agent id test"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>'CSRIDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		when:
		RegisterLSUserResponse response = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'Missing or invalid X-ATT-ClientId in request header'

	}


	def "register ls user request validator missing prop test"() throws Exception {
		given:
		requestHeader.getHeaderString('X-ATT-ClientId')>>'IDP'
		requestHeader.getHeaderString('idp-trace-id')>>'99dfs999:8dfs8888:77777:66666ccc'
		ReflectionTestUtils.setField(registerLSUserRequestValidator, 'propValidCallers', null)
		when:
		RegisterLSUserResponse response = registerLSUserRequestValidator.registerLSUserReqValidator(requestHeader, requestObj)
		then:
		response.appInfo == 'RegisterLSUser CallingSystemIds config is not set'

	}
	
}
