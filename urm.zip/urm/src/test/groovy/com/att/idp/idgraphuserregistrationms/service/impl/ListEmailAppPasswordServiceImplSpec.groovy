package com.att.idp.idgraphuserregistrationms.service.impl

import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.EmailAppPasswordDBHelper
import com.att.idp.idgraphuserregistrationms.helper.dbhelpers.GetMemberServicesDBHelper
import com.att.idp.idgraphuserregistrationms.resource.response.EmailAppPasswordResponse
import com.att.mpsys.common.utils.CommonDefs
import com.att.mpsys.common.utils.MPSDefs
import jakarta.ws.rs.core.HttpHeaders
import spock.lang.Specification

class ListEmailAppPasswordServiceImplSpec extends Specification {

    GetMemberServicesDBHelper mockGetMemberServicesDBHelper
    EmailAppPasswordDBHelper mockEmailAppPasswordDBHelper
    HttpHeaders mockHttpHeaders
    ListEmailAppPasswordServiceImpl serviceUnderTest

    void setup() {
        mockGetMemberServicesDBHelper = Mock(GetMemberServicesDBHelper)
        mockEmailAppPasswordDBHelper = Mock(EmailAppPasswordDBHelper)
        mockHttpHeaders = Mock(HttpHeaders)
        serviceUnderTest = new ListEmailAppPasswordServiceImpl(mockGetMemberServicesDBHelper, mockEmailAppPasswordDBHelper)
    }

    def "should call listEmailAppPwd with guid when guid is provided"() {
        given:
        String guid = "guid-123"
        HashMap memberResult = new HashMap()
        memberResult.put(MPSDefs.DB_MEMBER_NUM, guid)
        HashMap emailPwdResult = new HashMap()
        emailPwdResult.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        emailPwdResult.put(MPSDefs.DB_APPEMAILPASSWORD_TABLE, [new HashMap()])

        when:
        EmailAppPasswordResponse response = serviceUnderTest.listEmailAppPassword(null, null, guid, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices({ it.get(MPSDefs.DB_MEMBER_NUM) == guid }) >> memberResult
        1 * mockEmailAppPasswordDBHelper.listEmailAppPwd({ it.get(MPSDefs.DB_MEMBER_NUM) == guid }) >> emailPwdResult
        _ * mockHttpHeaders.getHeaderString(_) >> "trace-guid"
        0 * _

        and:
        response != null
        response.idpTraceId == "trace-guid"
    }

    def "should resolve member_num via getMemberServices then call listEmailAppPwd when memberId and domain are provided"() {
        given:
        String memberId = "user1"
        String domain = "att.net"
        String memberNum = "12345"
        HashMap memberResult = new HashMap()
        memberResult.put(MPSDefs.DB_MEMBER_NUM, memberNum)
        memberResult.put(MPSDefs.DB_MEMBER_NAME, memberId)
        memberResult.put(MPSDefs.DB_DOMAIN_NAME, domain)
        HashMap emailPwdResult = new HashMap()
        emailPwdResult.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        emailPwdResult.put(MPSDefs.DB_APPEMAILPASSWORD_TABLE, [new HashMap()])

        when:
        EmailAppPasswordResponse response = serviceUnderTest.listEmailAppPassword(memberId, domain, null, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices(_) >> memberResult
        1 * mockEmailAppPasswordDBHelper.listEmailAppPwd({ it.get(MPSDefs.DB_MEMBER_NUM) == memberNum }) >> emailPwdResult
        _ * mockHttpHeaders.getHeaderString(_) >> "trace-member"
        0 * _

        and:
        response != null
        response.idpTraceId == "trace-member"
    }

    def "should return not-found response and skip listEmailAppPwd when getMemberServices returns null member_num"() {
        given:
        HashMap memberResult = new HashMap()
        memberResult.put(MPSDefs.DB_MEMBER_NUM, null)

        when:
        EmailAppPasswordResponse response = serviceUnderTest.listEmailAppPassword("user1", "att.net", null, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices(_) >> memberResult
        0 * mockEmailAppPasswordDBHelper.listEmailAppPwd(_)
        _ * mockHttpHeaders.getHeaderString(_) >> "trace-notfound-1"
        0 * _

        and:
        response != null
        response.idpTraceId == "trace-notfound-1"
    }

    def "should return not-found response and skip listEmailAppPwd when getMemberServices returns null map"() {
        when:
        EmailAppPasswordResponse response = serviceUnderTest.listEmailAppPassword("user1", "att.net", null, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices(_) >> null
        0 * mockEmailAppPasswordDBHelper.listEmailAppPwd(_)
        _ * mockHttpHeaders.getHeaderString(_) >> "trace-notfound-2"
        0 * _

        and:
        response != null
        response.idpTraceId == "trace-notfound-2"
    }

    def "should return not-found response when listEmailAppPwd returns null"() {
        given:
        String guid = "guid-456"
        HashMap memberResult = new HashMap()
        memberResult.put(MPSDefs.DB_MEMBER_NUM, guid)

        when:
        EmailAppPasswordResponse response = serviceUnderTest.listEmailAppPassword(null, null, guid, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices(_) >> memberResult
        1 * mockEmailAppPasswordDBHelper.listEmailAppPwd(_) >> null
        _ * mockHttpHeaders.getHeaderString(_) >> "trace-nullpwd"
        0 * _

        and:
        response != null
        response.idpTraceId == "trace-nullpwd"
    }

    def "should fall back to COMMON_SUCCESS when COMMON_APP_STATUS_CODE is absent in emailAppPasswordResp"() {
        given:
        String guid = "guid-fallback"
        HashMap memberResult = new HashMap()
        memberResult.put(MPSDefs.DB_MEMBER_NUM, guid)
        HashMap emailPwdResult = new HashMap()
        emailPwdResult.put(MPSDefs.DB_APPEMAILPASSWORD_TABLE, [new HashMap()])

        when:
        EmailAppPasswordResponse response = serviceUnderTest.listEmailAppPassword(null, null, guid, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices(_) >> memberResult
        1 * mockEmailAppPasswordDBHelper.listEmailAppPwd(_) >> emailPwdResult
        _ * mockHttpHeaders.getHeaderString(_) >> "trace-fallback"
        0 * _

        and:
        response != null
        response.idpTraceId == "trace-fallback"
    }

    def "should propagate member name and domain from getMemberServices into success response"() {
        given:
        String memberId = "user2"
        String domain = "sbcglobal.net"
        HashMap memberResult = new HashMap()
        memberResult.put(MPSDefs.DB_MEMBER_NUM, "99999")
        memberResult.put(MPSDefs.DB_MEMBER_NAME, memberId)
        memberResult.put(MPSDefs.DB_DOMAIN_NAME, domain)
        HashMap emailPwdResult = new HashMap()
        emailPwdResult.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        emailPwdResult.put(MPSDefs.DB_APPEMAILPASSWORD_TABLE, [new HashMap()])

        when:
        EmailAppPasswordResponse response = serviceUnderTest.listEmailAppPassword(memberId, domain, null, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices(_) >> memberResult
        1 * mockEmailAppPasswordDBHelper.listEmailAppPwd(_) >> emailPwdResult
        _ * mockHttpHeaders.getHeaderString(_) >> "trace-propagate"
        0 * _

        and:
        response != null
        response.idpTraceId == "trace-propagate"
        response.memberId == memberId
        response.domain == domain
    }

    def "should return not-found response when getMemberServices returns null for guid path"() {
        given:
        String guid = "guid-nullresult"

        when:
        EmailAppPasswordResponse response = serviceUnderTest.listEmailAppPassword(null, null, guid, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices({ it.get(MPSDefs.DB_MEMBER_NUM) == guid }) >> null
        0 * mockEmailAppPasswordDBHelper.listEmailAppPwd(_)
        _ * mockHttpHeaders.getHeaderString(_) >> "trace-nullresult"
        0 * _

        and:
        response != null
        response.idpTraceId == "trace-nullresult"
    }

    def "should treat empty string guid as absent and use memberId/domain path"() {
        given:
        String memberId = "user3"
        String domain = "att.net"
        String memberNum = "77777"
        HashMap memberResult = new HashMap()
        memberResult.put(MPSDefs.DB_MEMBER_NUM, memberNum)
        memberResult.put(MPSDefs.DB_MEMBER_NAME, memberId)
        memberResult.put(MPSDefs.DB_DOMAIN_NAME, domain)
        HashMap emailPwdResult = new HashMap()
        emailPwdResult.put(CommonDefs.COMMON_APP_STATUS_CODE, CommonDefs.COMMON_SUCCESS)
        emailPwdResult.put(MPSDefs.DB_APPEMAILPASSWORD_TABLE, [new HashMap()])

        when:
        EmailAppPasswordResponse response = serviceUnderTest.listEmailAppPassword(memberId, domain, "", mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices({ !it.containsKey(MPSDefs.DB_MEMBER_NUM) }) >> memberResult
        1 * mockEmailAppPasswordDBHelper.listEmailAppPwd({ it.get(MPSDefs.DB_MEMBER_NUM) == memberNum }) >> emailPwdResult
        _ * mockHttpHeaders.getHeaderString(_) >> "trace-empty-guid"
        0 * _

        and:
        response != null
        response.idpTraceId == "trace-empty-guid"
    }

    def "should return not-found response and skip listEmailAppPwd when getMemberServices returns empty string for member_num"() {
        given:
        HashMap memberResult = new HashMap()
        memberResult.put(MPSDefs.DB_MEMBER_NUM, "")

        when:
        EmailAppPasswordResponse response = serviceUnderTest.listEmailAppPassword("user1", "att.net", null, mockHttpHeaders)

        then:
        1 * mockGetMemberServicesDBHelper.getMemberServices(_) >> memberResult
        0 * mockEmailAppPasswordDBHelper.listEmailAppPwd(_)
        _ * mockHttpHeaders.getHeaderString(_) >> "trace-empty-membernum"
        0 * _

        and:
        response != null
        response.idpTraceId == "trace-empty-membernum"
    }
}
