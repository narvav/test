package com.att.idp.idgraphuserregistrationms.queue.message.helpers

import com.att.idp.idgraphuserregistrationms.helper.voltage.VoltageEncryptionHelper
import com.att.idp.idgraphuserregistrationms.queue.message.sender.JMSQueueSender
import com.att.mpsys.common.utils.*
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.test.util.ReflectionTestUtils
import spock.lang.Specification

import java.text.SimpleDateFormat

class RetriggerQARQueueHelperTest extends Specification {

	def retriggerQARQueueHelperObj = new RetriggerQARQueueHelper()

	JMSQueueSender jMSQueueSender = Mock(JMSQueueSender)

    VoltageEncryptionHelper voltageHelper = Mock(VoltageEncryptionHelper)

    Map<String, Object> hmInput = null
    Map<String, Object> hmResult = null
    HashMap<String, Object> hmEncInput = null
    HashMap<String, Object> hmSuccessResponse = null
    Map<String, Object> hmDBMember = null
    Logger logger = null

    ArrayList dbusInput = null


    def setup() {
    
        retriggerQARQueueHelperObj.oJMSQueueSender = jMSQueueSender
        retriggerQARQueueHelperObj.voltageEncryptionHelperObj = voltageHelper
		hmInput = CommonUtil.hashMap
        hmDBMember = CommonUtil.hashMap
        hmResult = CommonUtil.hashMap

        logger = LoggerFactory.getLogger('RetriggerQARQueueHelper')

        hmInput[CommonDefs.CALLING_SYSTEM_ID] = 'IDP'
        hmInput[CommonDefs.BAN] = '121212120'
        hmInput[CommonDefs.ACCOUNT_TYPE] = 'MOBILITY'
        hmInput[CommonDefs.SOR_ID] = '13'
        hmInput[CommonDefs.CONTACT_EMAIL] = hmInput[CommonDefs.CONTACT_EMAIL]
        hmInput[CommonDefs.SOR_NAME] = hmInput[CommonDefs.KEY_SOR_NAME]
        hmInput[CommonDefs.TRANSACTION_ID] = 'bc6253c94e0d42b4'
        hmInput[CommonDefs.ORIG_TRANSID] = 'bc6253c94e0d42b4'
        hmInput[CommonDefs.CTN] = '12345678'
        hmInput[CommonDefs.CONTACT_EMAIL] = 'qay_test'

        hmDBMember[MPSDefs.DB_MEMBER_NAME] = 'qay_test'
        hmDBMember[MPSDefs.DB_DOMAIN_NAME] = 'slid.dum'
        hmDBMember[MPSDefs.DB_LC_FIRSTNAME] = 'Tony'
        hmDBMember[MPSDefs.DB_LC_LASTNAME] = 'Stark'

        hmEncInput = new HashMap<String, Object>()

        SimpleDateFormat dateformat = new SimpleDateFormat('YYYYMMdd')
        Calendar cal = Calendar.instance


        cal.add(Calendar.DAY_OF_MONTH, Integer.parseInt('30'))
        String date = (dateformat.format(cal.time))

        String sVoltageEncryptString = hmInput[CommonDefs.SOR_ID] + '_' + hmInput[CommonDefs.BAN] + '_' + date
        hmEncInput['CBR'] = sVoltageEncryptString

        hmSuccessResponse = CommonErrorMap.makeCategoryMap(CErrorDefs.COMMON_SUCCESS_NUM, 'Success')

    }


    def "test property error"() {
        when:
        hmResult = retriggerQARQueueHelperObj.prepareDataForAsyncCall(hmInput, hmDBMember)
        then:
        hmResult['appInfo'] == 'The value of QAR_EXPIRY_DAYS is not configured in property files'
    }


    def "test prepare data for async call success"() {

        given:
        ReflectionTestUtils.setField(retriggerQARQueueHelperObj, 'sPropQarExpiryDays', '30')
        HashMap<String, Object> voltageResult = new HashMap<String, Object>()
        voltageResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'
        voltageHelper.getEFPEEncryptedValues(_ as HashMap) >> voltageResult
        when:
        hmResult = retriggerQARQueueHelperObj.prepareDataForAsyncCall(hmInput, hmDBMember)

        then:
        hmResult[CommonDefs.COMMON_APP_INFO] == 'SUCCESS'
    }


    def "test prepare data for async call error"() {

        given:
        ReflectionTestUtils.setField(retriggerQARQueueHelperObj, 'sPropQarExpiryDays', '30')

        HashMap<String, Object> voltageResult = new HashMap<String, Object>()
        voltageResult[CommonDefs.COMMON_APP_STATUS_CODE] = '118'

        voltageHelper.getEFPEEncryptedValues(_ as HashMap) >> voltageResult

        //when:
        hmResult = retriggerQARQueueHelperObj.prepareDataForAsyncCall(hmInput, hmDBMember)

        //then:
        //hmResult['appStatusCode'] == '118'
    }


    def "test prepare data for async call system error"() {

        given:
        ReflectionTestUtils.setField(retriggerQARQueueHelperObj, 'sPropQarExpiryDays', '30')
        NullPointerException ex = new NullPointerException('NullPointerException thrown')
        voltageHelper.getEFPEEncryptedValues(_ as HashMap) >> { throw ex }
        when:
        hmResult = retriggerQARQueueHelperObj.prepareDataForAsyncCall(hmInput, hmDBMember)
        then:
        hmResult['appStatusCode'] == '602'
        
    }


    def "test prepare data for async call data error"() {

        given:
        ReflectionTestUtils.setField(retriggerQARQueueHelperObj, 'sPropQarExpiryDays', '30')
        hmInput[CommonDefs.CTN] = null
		hmInput[CommonDefs.CONTACT_EMAIL] = null

		HashMap<String, Object> voltageResult = new HashMap<String, Object>()
		voltageResult[CommonDefs.COMMON_APP_STATUS_CODE] = '0'

		voltageHelper.getEFPEEncryptedValues(_ as HashMap) >> voltageResult
        when:
        hmResult = retriggerQARQueueHelperObj.prepareDataForAsyncCall(hmInput, hmDBMember)

        then:
        hmResult['appStatusCode'] == '100'
        hmResult['appInfo'] == 'Neither ContactEmail nor PhoneNumber is present hence can\'t send EDD Notification'
    }


    def "test make async call error output"() {
        given:
        jMSQueueSender.send(_ as Map<String, Object>) >> hmSuccessResponse
        when:
        hmResult = retriggerQARQueueHelperObj.makeAsyncCall(dbusInput, hmInput)
        then:
        hmResult['appStatusCode'] == '0'
        hmResult[CommonDefs.COMMON_APP_INFO] == 'Success'
    }
}
